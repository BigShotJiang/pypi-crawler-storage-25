# Phase 6: Production Hardening Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add NIST-compliant RBAC sessions, prompt-injection-resistant policy isolation, and CAEP-style push revocation to make open-guard production-ready for cerebrio-sapience v1.0.

**Architecture:** Three additive deliverables on the existing clean/hexagonal architecture. Sessions follow the same entity + port + store + manager + evaluator pattern established in Phases 1-5. Policy isolation wraps the existing `PolicyStorePort` in a read-only view at evaluation time and adds taint-checking to the ABAC evaluator. Push revocation adds a new `RevocationStreamPort` that DelegationManager and SessionManager publish to.

**Tech Stack:** Python 3.12+, Pydantic v2 (frozen models), SQLAlchemy 2.0 (optional `[sql]` extra), pytest, ruff, mypy --strict.

---

## File Map

### New Files

| File | Responsibility |
|------|---------------|
| `src/open_guard/domain/entities.py` | + `Session`, `SessionStatus`, `RevocationEvent`, `RevocationEventType` |
| `src/open_guard/domain/exceptions.py` | + `SessionError`, `SessionNotFoundError`, `SessionExpiredError`, `RevocationError` |
| `src/open_guard/domain/ports/session_store.py` | `SessionStorePort` abstract interface |
| `src/open_guard/domain/ports/revocation_stream.py` | `RevocationStreamPort` abstract interface |
| `src/open_guard/domain/services/session_manager.py` | `SessionManager` — create, activate, deactivate, expire |
| `src/open_guard/adapters/stores/memory_session.py` | `InMemorySessionStore` |
| `src/open_guard/adapters/stores/sql_session.py` | `SQLAlchemySessionStore` |
| `src/open_guard/adapters/stores/memory_revocation.py` | `InMemoryRevocationStream` |
| `tests/unit/test_session_entity.py` | Session entity validation tests |
| `tests/unit/test_session_store_memory.py` | InMemorySessionStore tests |
| `tests/unit/test_session_store_sql.py` | SQLAlchemySessionStore tests |
| `tests/unit/test_session_manager.py` | SessionManager service tests |
| `tests/unit/test_rbac_session.py` | RBACEvaluator with session context |
| `tests/unit/test_policy_isolation.py` | Policy isolation + taint marking tests |
| `tests/unit/test_revocation_stream.py` | RevocationStreamPort + InMemory tests |
| `tests/unit/test_revocation_events.py` | Event emission integration tests |
| `tests/integration/test_session_integration.py` | End-to-end session authorization flows |
| `tests/integration/test_prompt_injection.py` | Adversarial prompt-injection scenarios |
| `tests/integration/test_revocation_integration.py` | Push revocation end-to-end |
| `tests/integration/test_integration_guide_phase6_examples.py` | Integration guide executable mirrors |
| `specs/decisions/0006-rbac-sessions.md` | ADR-0006 |
| `specs/decisions/0007-policy-isolation.md` | ADR-0007 |
| `specs/decisions/0008-push-revocation.md` | ADR-0008 |

### Modified Files

| File | Changes |
|------|---------|
| `src/open_guard/adapters/evaluators/rbac.py` | Session-aware role intersection in `_get_subject_roles` |
| `src/open_guard/adapters/evaluators/abac.py` | `session.*` attribute namespace in `_build_attribute_map`, `trusted_only` condition modifier |
| `src/open_guard/domain/services/guard.py` | `session_store` + `revocation_stream` constructor params, `session_id` on authorize/list_authorized |
| `src/open_guard/domain/services/delegation_manager.py` | Emit `delegation_revoked` event on revoke |
| `src/open_guard/domain/services/policy_router.py` | Pass read-only policy view to evaluators |
| `src/open_guard/adapters/stores/sql_models.py` | + `SessionTable` |
| `src/open_guard/__init__.py` | Re-exports for new types |

---

## Deliverable 1: RBAC Sessions (ENH-001)

### Task 1: Session Entity + SessionStatus

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `src/open_guard/domain/exceptions.py`
- Create: `tests/unit/test_session_entity.py`

- [ ] **Step 1: Write failing tests for Session entity**

```python
# tests/unit/test_session_entity.py
"""Tests for Session entity (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionError


class TestSessionEntity:
    """Session entity construction and validation."""

    def test_create_session_defaults(self) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["editor", "viewer"],
        )
        assert session.tenant_id == "t1"
        assert session.subject_id == "user-1"
        assert session.activated_roles == ["editor", "viewer"]
        assert session.status == SessionStatus.ACTIVE
        assert session.metadata == {}
        assert session.id  # auto-generated UUID

    def test_create_session_with_expiry(self) -> None:
        expires = datetime.now(UTC) + timedelta(hours=1)
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["admin"],
            expires_at=expires,
        )
        assert session.expires_at == expires

    def test_session_frozen(self) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["viewer"],
        )
        with pytest.raises(Exception):  # Pydantic frozen model
            session.status = SessionStatus.DEACTIVATED  # type: ignore[misc]

    def test_session_empty_roles_rejected(self) -> None:
        with pytest.raises(ValueError):
            Session(
                tenant_id="t1",
                subject_id="user-1",
                activated_roles=[],
            )

    def test_session_metadata(self) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["viewer"],
            metadata={"scope": "PROJECT"},
        )
        assert session.metadata["scope"] == "PROJECT"


class TestSessionStatus:
    """SessionStatus enum values."""

    def test_status_values(self) -> None:
        assert SessionStatus.ACTIVE == "active"
        assert SessionStatus.DEACTIVATED == "deactivated"
        assert SessionStatus.EXPIRED == "expired"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_session_entity.py -v`
Expected: ImportError — `Session` and `SessionStatus` don't exist yet.

- [ ] **Step 3: Implement Session entity and SessionStatus**

Add to `src/open_guard/domain/entities.py` (after the Delegation block at the end):

```python
# ---------------------------------------------------------------------------
# Phase 6 — RBAC Sessions (ENH-001)
# ---------------------------------------------------------------------------


class SessionStatus(StrEnum):
    """Lifecycle states for an RBAC Session."""

    ACTIVE = "active"
    DEACTIVATED = "deactivated"
    EXPIRED = "expired"


class Session(Entity):
    """An RBAC session — a subject activates a subset of assigned roles.

    NIST Core RBAC: a session maps a user to a set of activated roles.
    Multiple concurrent sessions per subject are allowed (different scopes
    or contexts can have different active role sets).

    Phase 6 (ENH-001).
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(..., description="Tenant scope")
    subject_id: str = Field(..., description="Subject this session belongs to")
    activated_roles: list[str] = Field(
        ..., min_length=1, description="Subset of subject's assigned roles"
    )
    status: SessionStatus = Field(default=SessionStatus.ACTIVE)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    expires_at: datetime | None = Field(
        default=None, description="Session expiry (None = no expiry)"
    )
    deactivated_at: datetime | None = Field(default=None)
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Consumer context (scope, device, IP, etc.)",
    )
```

Add to `src/open_guard/domain/exceptions.py`:

```python
# ---------------------------------------------------------------------------
# Phase 6 — Session exceptions
# ---------------------------------------------------------------------------


class SessionError(OpenGuardError):
    """Raised for session-related errors."""


class SessionNotFoundError(SessionError):
    """Raised when a session id does not exist in the store."""


class SessionExpiredError(SessionError):
    """Raised when operating on an expired session."""
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_session_entity.py -v`
Expected: All 6 tests PASS.

- [ ] **Step 5: Commit**

```
feat(session): add Session entity + SessionStatus enum (Phase 6 T1)
```

---

### Task 2: SessionStorePort

**Files:**
- Create: `src/open_guard/domain/ports/session_store.py`

- [ ] **Step 1: Create the port interface**

```python
# src/open_guard/domain/ports/session_store.py
"""Abstract interface for session storage (Phase 6, ENH-001)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from open_guard.domain.entities import Session, SessionStatus


class SessionStorePort(ABC):
    """Port for Session operational state."""

    @abstractmethod
    def create(self, session: Session) -> Session:
        """Persist a new Session and return it."""

    @abstractmethod
    def get(self, session_id: str, tenant_id: str) -> Session | None:
        """Retrieve a Session by id within a tenant."""

    @abstractmethod
    def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        """List all ACTIVE sessions for a subject within a tenant."""

    @abstractmethod
    def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        """Transition a Session to a new status. Returns the updated entity."""

    @abstractmethod
    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition ACTIVE sessions past their expires_at to EXPIRED.

        Returns the count of sessions transitioned.
        """
```

- [ ] **Step 2: Commit**

```
feat(session): add SessionStorePort abstract interface (Phase 6 T2)
```

---

### Task 3: InMemorySessionStore

**Files:**
- Create: `src/open_guard/adapters/stores/memory_session.py`
- Create: `tests/unit/test_session_store_memory.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_session_store_memory.py
"""Tests for InMemorySessionStore (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError


class TestInMemorySessionStore:
    def setup_method(self) -> None:
        self.store = InMemorySessionStore()

    def _make_session(self, **kwargs) -> Session:
        defaults = {
            "tenant_id": "t1",
            "subject_id": "user-1",
            "activated_roles": ["editor"],
        }
        defaults.update(kwargs)
        return Session(**defaults)

    def test_create_and_get(self) -> None:
        session = self._make_session()
        created = self.store.create(session)
        assert created.id == session.id
        got = self.store.get(session.id, "t1")
        assert got is not None
        assert got.id == session.id

    def test_get_nonexistent_returns_none(self) -> None:
        assert self.store.get("nope", "t1") is None

    def test_tenant_isolation(self) -> None:
        session = self._make_session(tenant_id="t1")
        self.store.create(session)
        assert self.store.get(session.id, "t2") is None

    def test_get_active_for_subject(self) -> None:
        s1 = self._make_session(subject_id="alice")
        s2 = self._make_session(subject_id="alice")
        s3 = self._make_session(subject_id="bob")
        self.store.create(s1)
        self.store.create(s2)
        self.store.create(s3)
        active = self.store.get_active_for_subject("alice", "t1")
        assert len(active) == 2
        assert all(s.subject_id == "alice" for s in active)

    def test_get_active_excludes_deactivated(self) -> None:
        s1 = self._make_session(subject_id="alice")
        self.store.create(s1)
        self.store.update_status(s1.id, "t1", SessionStatus.DEACTIVATED)
        active = self.store.get_active_for_subject("alice", "t1")
        assert len(active) == 0

    def test_update_status(self) -> None:
        session = self._make_session()
        self.store.create(session)
        now = datetime.now(UTC)
        updated = self.store.update_status(
            session.id, "t1", SessionStatus.DEACTIVATED, deactivated_at=now
        )
        assert updated.status == SessionStatus.DEACTIVATED
        assert updated.deactivated_at == now

    def test_update_status_not_found_raises(self) -> None:
        with pytest.raises(SessionNotFoundError):
            self.store.update_status("nope", "t1", SessionStatus.DEACTIVATED)

    def test_expire_stale(self) -> None:
        now = datetime.now(UTC)
        past = now - timedelta(hours=1)
        future = now + timedelta(hours=1)
        s_expired = self._make_session(expires_at=past)
        s_active = self._make_session(expires_at=future)
        s_no_expiry = self._make_session()
        self.store.create(s_expired)
        self.store.create(s_active)
        self.store.create(s_no_expiry)
        count = self.store.expire_stale("t1", now)
        assert count == 1
        assert self.store.get(s_expired.id, "t1").status == SessionStatus.EXPIRED
        assert self.store.get(s_active.id, "t1").status == SessionStatus.ACTIVE
        assert self.store.get(s_no_expiry.id, "t1").status == SessionStatus.ACTIVE

    def test_multiple_concurrent_sessions(self) -> None:
        """Same subject can have multiple active sessions (different scopes)."""
        s1 = self._make_session(
            subject_id="alice",
            activated_roles=["project:editor"],
            metadata={"scope": "PROJECT"},
        )
        s2 = self._make_session(
            subject_id="alice",
            activated_roles=["workspace:viewer"],
            metadata={"scope": "WORKSPACE"},
        )
        self.store.create(s1)
        self.store.create(s2)
        active = self.store.get_active_for_subject("alice", "t1")
        assert len(active) == 2
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_session_store_memory.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement InMemorySessionStore**

```python
# src/open_guard/adapters/stores/memory_session.py
"""Thread-safe in-memory session store (Phase 6, ENH-001)."""

from __future__ import annotations

import threading
from datetime import datetime

from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError
from open_guard.domain.ports.session_store import SessionStorePort


class InMemorySessionStore(SessionStorePort):
    """In-memory implementation of SessionStorePort.

    Thread-safe via a reentrant lock. Suitable for testing and
    single-process deployments.
    """

    def __init__(self) -> None:
        self._sessions: dict[str, Session] = {}
        self._lock = threading.RLock()

    def create(self, session: Session) -> Session:
        with self._lock:
            self._sessions[session.id] = session
            return session

    def get(self, session_id: str, tenant_id: str) -> Session | None:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is not None and session.tenant_id == tenant_id:
                return session
            return None

    def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        with self._lock:
            return [
                s
                for s in self._sessions.values()
                if s.tenant_id == tenant_id
                and s.subject_id == subject_id
                and s.status == SessionStatus.ACTIVE
            ]

    def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None or session.tenant_id != tenant_id:
                raise SessionNotFoundError(
                    f"Session {session_id!r} not found in tenant {tenant_id!r}"
                )
            updates: dict = {"status": status}
            if deactivated_at is not None:
                updates["deactivated_at"] = deactivated_at
            updated = session.model_copy(update=updates)
            self._sessions[session_id] = updated
            return updated

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._lock:
            count = 0
            for sid, session in list(self._sessions.items()):
                if (
                    session.tenant_id == tenant_id
                    and session.status == SessionStatus.ACTIVE
                    and session.expires_at is not None
                    and session.expires_at <= now
                ):
                    self._sessions[sid] = session.model_copy(
                        update={"status": SessionStatus.EXPIRED}
                    )
                    count += 1
            return count
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_session_store_memory.py -v`
Expected: All 10 tests PASS.

- [ ] **Step 5: Commit**

```
feat(session): add InMemorySessionStore (Phase 6 T3)
```

---

### Task 4: SessionManager Service

**Files:**
- Create: `src/open_guard/domain/services/session_manager.py`
- Create: `tests/unit/test_session_manager.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_session_manager.py
"""Tests for SessionManager service (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import Session, SessionStatus, Subject
from open_guard.domain.exceptions import SessionError, SessionExpiredError, SessionNotFoundError
from open_guard.domain.services.session_manager import SessionManager


class TestSessionManager:
    def setup_method(self) -> None:
        self.store = InMemorySessionStore()
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.manager = SessionManager(
            session_store=self.store, clock=lambda: self.now
        )

    def test_create_session_validates_role_subset(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["admin", "editor", "viewer"]},
        )
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor", "viewer"],
        )
        assert session.status == SessionStatus.ACTIVE
        assert session.activated_roles == ["editor", "viewer"]
        assert session.subject_id == "alice"

    def test_create_session_rejects_non_subset_roles(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["editor", "viewer"]},
        )
        with pytest.raises(SessionError, match="not a subset"):
            self.manager.create_session(
                subject=subject,
                tenant_id="t1",
                activated_roles=["admin", "editor"],
            )

    def test_create_session_with_expiry(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["editor"]},
        )
        ttl = timedelta(hours=2)
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            ttl=ttl,
        )
        assert session.expires_at == self.now + ttl

    def test_create_session_with_metadata(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["editor"]},
        )
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )
        assert session.metadata["scope"] == "PROJECT"

    def test_deactivate_session(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        deactivated = self.manager.deactivate(session.id, "t1")
        assert deactivated.status == SessionStatus.DEACTIVATED
        assert deactivated.deactivated_at == self.now

    def test_deactivate_not_found_raises(self) -> None:
        with pytest.raises(SessionNotFoundError):
            self.manager.deactivate("nope", "t1")

    def test_deactivate_already_deactivated_raises(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        self.manager.deactivate(session.id, "t1")
        with pytest.raises(SessionError, match="not active"):
            self.manager.deactivate(session.id, "t1")

    def test_expire_stale_sessions(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            ttl=timedelta(hours=-1),  # already expired
        )
        count = self.manager.expire_stale("t1")
        assert count == 1

    def test_get_active_sessions(self) -> None:
        subject = Subject(
            id="alice", attributes={"roles": ["editor", "viewer"]}
        )
        self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )
        self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["viewer"],
            metadata={"scope": "WORKSPACE"},
        )
        sessions = self.manager.get_active_sessions("alice", "t1")
        assert len(sessions) == 2

    def test_get_session(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        created = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        got = self.manager.get_session(created.id, "t1")
        assert got.id == created.id

    def test_get_session_auto_expires(self) -> None:
        """Getting an expired session returns it as EXPIRED."""
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"],
            ttl=timedelta(hours=1),
        )
        # Advance clock past expiry
        self.now = self.now + timedelta(hours=2)
        got = self.manager.get_session(session.id, "t1")
        assert got.status == SessionStatus.EXPIRED
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_session_manager.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement SessionManager**

```python
# src/open_guard/domain/services/session_manager.py
"""SessionManager — RBAC session lifecycle management (Phase 6, ENH-001)."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any

from open_guard.domain.entities import Session, SessionStatus, Subject
from open_guard.domain.exceptions import SessionError, SessionExpiredError, SessionNotFoundError
from open_guard.domain.ports.session_store import SessionStorePort


class SessionManager:
    """Manages RBAC session lifecycle: create, deactivate, expire.

    NIST Core RBAC: sessions let a subject activate a subset of their
    assigned roles. Multiple concurrent sessions per subject are allowed
    (e.g., different scopes or devices).
    """

    def __init__(
        self,
        session_store: SessionStorePort,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._store = session_store
        self._clock = clock or (lambda: datetime.now(UTC))

    def create_session(
        self,
        subject: Subject,
        tenant_id: str,
        activated_roles: list[str],
        ttl: timedelta | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        """Create a new session with a validated role subset.

        Args:
            subject: The subject creating the session.
            tenant_id: Tenant scope.
            activated_roles: Roles to activate (must be subset of subject's roles).
            ttl: Optional time-to-live from now.
            metadata: Consumer context (scope, device, etc.).

        Raises:
            SessionError: If activated_roles is not a subset of subject's assigned roles.
        """
        assigned = set(subject.attributes.get("roles", []))
        requested = set(activated_roles)
        if not requested.issubset(assigned):
            extra = requested - assigned
            raise SessionError(
                f"Requested roles {extra} not a subset of assigned roles {assigned}"
            )
        now = self._clock()
        expires_at = (now + ttl) if ttl is not None else None
        session = Session(
            tenant_id=tenant_id,
            subject_id=subject.id,
            activated_roles=list(activated_roles),
            status=SessionStatus.ACTIVE,
            created_at=now,
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return self._store.create(session)

    def get_session(self, session_id: str, tenant_id: str) -> Session:
        """Retrieve a session, auto-expiring if past expiry.

        Raises:
            SessionNotFoundError: If session doesn't exist.
        """
        session = self._store.get(session_id, tenant_id)
        if session is None:
            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        # Lazy expiry — same pattern as ApprovalRequest and Delegation
        if (
            session.status == SessionStatus.ACTIVE
            and session.expires_at is not None
            and session.expires_at <= self._clock()
        ):
            session = self._store.update_status(
                session_id, tenant_id, SessionStatus.EXPIRED
            )
        return session

    def get_active_sessions(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        """List all active sessions for a subject."""
        return self._store.get_active_for_subject(subject_id, tenant_id)

    def deactivate(self, session_id: str, tenant_id: str) -> Session:
        """Deactivate an active session.

        Raises:
            SessionNotFoundError: If session doesn't exist.
            SessionError: If session is not active.
        """
        session = self._store.get(session_id, tenant_id)
        if session is None:
            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        if session.status != SessionStatus.ACTIVE:
            raise SessionError(
                f"Session {session_id!r} is not active (status={session.status})"
            )
        return self._store.update_status(
            session_id,
            tenant_id,
            SessionStatus.DEACTIVATED,
            deactivated_at=self._clock(),
        )

    def expire_stale(self, tenant_id: str) -> int:
        """Expire all sessions past their expiry time."""
        return self._store.expire_stale(tenant_id, self._clock())
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_session_manager.py -v`
Expected: All 11 tests PASS.

- [ ] **Step 5: Commit**

```
feat(session): add SessionManager service with role subset validation (Phase 6 T4)
```

---

### Task 5: RBACEvaluator Session-Aware Evaluation

**Files:**
- Modify: `src/open_guard/adapters/evaluators/rbac.py:157-164`
- Create: `tests/unit/test_rbac_session.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_rbac_session.py
"""Tests for RBACEvaluator with session context (Phase 6 — ENH-001)."""

from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Session,
    SessionStatus,
    Subject,
)


def _request(
    roles: list[str],
    action: str = "read",
    session: Session | None = None,
) -> AuthorizationRequest:
    context = {}
    if session is not None:
        context["_session"] = session
    return AuthorizationRequest(
        subject=Subject(id="alice", attributes={"roles": roles}),
        action=Action(name=action),
        resource=Resource(id="r1", resource_type="doc"),
        tenant_id="t1",
        context=context,
    )


def _policy(roles: list[str], effect: str = "allow") -> Policy:
    return Policy(
        id="p1",
        tenant_id="t1",
        evaluator_type="rbac",
        subject_match={"roles": roles},
        action_match="read",
        effect=PolicyEffect(effect),
    )


class TestRBACWithSession:
    def setup_method(self) -> None:
        self.evaluator = RBACEvaluator()

    def test_without_session_uses_all_roles(self) -> None:
        """No session → all subject roles are used."""
        req = _request(roles=["admin", "editor", "viewer"])
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is True

    def test_with_session_uses_only_activated_roles(self) -> None:
        """Session activates [editor, viewer] → admin policy should NOT match."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor", "viewer"],
        )
        req = _request(
            roles=["admin", "editor", "viewer"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is False

    def test_with_session_activated_role_matches(self) -> None:
        """Session activates [editor] → editor policy matches."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        req = _request(
            roles=["admin", "editor", "viewer"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["editor"])])
        assert result.allowed is True

    def test_expired_session_uses_all_roles(self) -> None:
        """Expired session is ignored — all roles are used."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["viewer"],
            status=SessionStatus.EXPIRED,
        )
        req = _request(
            roles=["admin", "editor"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is True

    def test_deactivated_session_uses_all_roles(self) -> None:
        """Deactivated session is ignored — all roles are used."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["viewer"],
            status=SessionStatus.DEACTIVATED,
        )
        req = _request(
            roles=["admin", "editor"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is True

    def test_session_with_hierarchy(self) -> None:
        """Session roles also expand through hierarchy."""
        evaluator = RBACEvaluator(role_hierarchy={"editor": ["viewer"]})
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        req = _request(
            roles=["admin", "editor"],
            session=session,
        )
        # editor inherits viewer, so viewer policy should match
        result = evaluator.evaluate(req, [_policy(["viewer"])])
        assert result.allowed is True

    def test_session_with_hierarchy_blocks_non_activated(self) -> None:
        """Session activates [viewer] → even with hierarchy, admin doesn't match."""
        evaluator = RBACEvaluator(role_hierarchy={"admin": ["editor"]})
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["viewer"],
        )
        req = _request(
            roles=["admin", "editor", "viewer"],
            session=session,
        )
        result = evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_rbac_session.py -v`
Expected: `test_with_session_uses_only_activated_roles` FAILS (returns True because session is not checked yet).

- [ ] **Step 3: Modify RBACEvaluator._get_subject_roles to be session-aware**

In `src/open_guard/adapters/evaluators/rbac.py`, replace the `_get_subject_roles` method (lines 157-164):

```python
    def _get_subject_roles(self, request: AuthorizationRequest) -> list[str]:
        """Extract roles from subject attributes, narrowed by session if present.

        Phase 6 (ENH-001): If an active Session is present in
        ``request.context["_session"]``, only the intersection of the
        subject's assigned roles and the session's activated roles is used.
        Expired or deactivated sessions are ignored (fail-open to full roles).
        """
        roles = request.subject.attributes.get("roles", [])
        if isinstance(roles, str):
            roles = [roles]
        elif isinstance(roles, list):
            roles = [str(r) for r in roles]
        else:
            return []

        # Check for active session in context
        session = request.context.get("_session")
        if session is not None:
            from open_guard.domain.entities import SessionStatus

            if hasattr(session, "status") and hasattr(session, "activated_roles"):
                if session.status == SessionStatus.ACTIVE:
                    activated = set(session.activated_roles)
                    roles = [r for r in roles if r in activated]

        return roles
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_rbac_session.py -v`
Expected: All 7 tests PASS.

- [ ] **Step 5: Run full regression**

Run: `pytest --tb=short -q`
Expected: All 712+ existing tests PASS (no breaking changes).

- [ ] **Step 6: Commit**

```
feat(rbac): session-aware role intersection in RBACEvaluator (Phase 6 T5)
```

---

### Task 6: Guard Session Integration

**Files:**
- Modify: `src/open_guard/domain/services/guard.py:72-84` (constructor), `:140-158` (authorize)
- Create: `tests/integration/test_session_integration.py`

- [ ] **Step 1: Write failing integration tests**

```python
# tests/integration/test_session_integration.py
"""End-to-end session authorization tests (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard import (
    ABACEvaluator,
    Action,
    Guard,
    InMemoryPolicyStore,
    Policy,
    PolicyEffect,
    Resource,
    RBACEvaluator,
    Subject,
)
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError
from open_guard.domain.services.session_manager import SessionManager


class TestSessionIntegration:
    def setup_method(self) -> None:
        self.policy_store = InMemoryPolicyStore()
        self.session_store = InMemorySessionStore()
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.rbac = RBACEvaluator()
        self.guard = Guard(
            policy_store=self.policy_store,
            evaluators=[self.rbac],
            session_store=self.session_store,
            clock=lambda: self.now,
        )

        # Policies
        self.policy_store.add(Policy(
            id="p-admin",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="delete",
            resource_match={"type": "doc"},
        ))
        self.policy_store.add(Policy(
            id="p-editor",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match="write",
            resource_match={"type": "doc"},
        ))

    def test_authorize_with_session_id(self) -> None:
        """session_id on authorize() scopes the evaluation to session roles."""
        alice = Subject(
            id="alice",
            attributes={"roles": ["admin", "editor", "viewer"]},
        )
        session_mgr = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        session = session_mgr.create_session(
            subject=alice,
            tenant_id="t1",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )

        # With session: editor can write, but NOT delete (admin-only)
        decision = self.guard.authorize(
            alice,
            Action(name="write"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
            session_id=session.id,
        )
        assert decision.allowed is True

        decision = self.guard.authorize(
            alice,
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
            session_id=session.id,
        )
        assert decision.allowed is False

    def test_authorize_without_session_uses_all_roles(self) -> None:
        """No session_id → all roles are used."""
        alice = Subject(
            id="alice",
            attributes={"roles": ["admin", "editor"]},
        )
        decision = self.guard.authorize(
            alice,
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
        )
        assert decision.allowed is True

    def test_authorize_with_expired_session_denies(self) -> None:
        """Expired session → deny (no active session to provide roles)."""
        alice = Subject(id="alice", attributes={"roles": ["admin"]})
        session_mgr = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        session = session_mgr.create_session(
            subject=alice,
            tenant_id="t1",
            activated_roles=["admin"],
            ttl=timedelta(hours=-1),  # already expired
        )
        # Guard should detect expired session and use it as expired
        decision = self.guard.authorize(
            alice,
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
            session_id=session.id,
        )
        # Expired session is ignored → falls back to all roles
        assert decision.allowed is True

    def test_authorize_invalid_session_id_raises(self) -> None:
        """Non-existent session_id raises SessionNotFoundError."""
        alice = Subject(id="alice", attributes={"roles": ["admin"]})
        with pytest.raises(SessionNotFoundError):
            self.guard.authorize(
                alice,
                Action(name="delete"),
                Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
                "t1",
                session_id="nonexistent",
            )

    def test_list_authorized_with_session(self) -> None:
        """list_authorized also respects session_id."""
        alice = Subject(id="alice", attributes={"roles": ["editor", "admin"]})
        session_mgr = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        session = session_mgr.create_session(
            subject=alice,
            tenant_id="t1",
            activated_roles=["editor"],
        )
        # list_authorized with session_id should only use editor role
        # (This test verifies session context flows through to evaluator)
        from open_guard.domain.ports.candidate_resource import CandidateResourcePort
        from open_guard.domain.entities import Resource as ResEntity

        class FakeCandidates(CandidateResourcePort):
            def fetch_candidates(self, resource_type, tenant_id, prefilter=None, cursor=None, limit=100):
                return [
                    ResEntity(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
                ], None

        result = self.guard.list_authorized(
            alice, "write", "doc", "t1",
            candidate_source=FakeCandidates(),
            session_id=session.id,
        )
        assert "doc-1" in result.ids
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/integration/test_session_integration.py -v`
Expected: TypeError — `session_id` is not a parameter on `Guard.authorize()` yet.

- [ ] **Step 3: Modify Guard to accept session_store and session_id**

In `src/open_guard/domain/services/guard.py`:

**Constructor** — add `session_store` parameter (after `candidate_source`):

```python
    def __init__(
        self,
        policy_store: PolicyStorePort,
        evaluators: list[EvaluatorPort] | None = None,
        approval_store: ApprovalStorePort | None = None,
        clock: Callable[[], datetime] | None = None,
        max_chain_depth: int = 5,
        relationship_store: RelationshipStorePort | None = None,
        candidate_source: CandidateResourcePort | None = None,
        delegation_store: DelegationStorePort | None = None,
        max_delegation_depth: int = 10,
        default_delegate_policy: str | None = "self_only",
        session_store: SessionStorePort | None = None,
    ) -> None:
```

Add after `self._candidate_source = candidate_source`:

```python
        self._session_store = session_store
```

Add import at top:

```python
from open_guard.domain.ports.session_store import SessionStorePort
```

**authorize()** — add `session_id` parameter and resolve session into context:

```python
    def authorize(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
        _skip_delegation: bool = False,
        _recheck_cache: dict[tuple[str, ...], Any] | None = None,
    ) -> Decision:
```

Inside `authorize()`, before the `AuthorizationRequest` construction, add session resolution:

```python
        ctx = dict(context) if context else {}
        if session_id is not None and self._session_store is not None:
            session = self._session_store.get(session_id, tenant_id)
            if session is None:
                from open_guard.domain.exceptions import SessionNotFoundError
                raise SessionNotFoundError(
                    f"Session {session_id!r} not found in tenant {tenant_id!r}"
                )
            # Lazy expiry check
            if (
                session.status == SessionStatus.ACTIVE
                and session.expires_at is not None
                and session.expires_at <= self._clock()
            ):
                from open_guard.domain.entities import SessionStatus
                session = self._session_store.update_status(
                    session_id, tenant_id, SessionStatus.EXPIRED
                )
            ctx["_session"] = session
```

Add `SessionStatus` to the entity imports at the top of guard.py.

**list_authorized()** — add `session_id` parameter and pass through context:

```python
    def list_authorized(
        self,
        subject: Subject,
        action: str,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None = None,
        limit: int = 100,
        cursor: str | None = None,
        context: dict[str, Any] | None = None,
        relationship_store: RelationshipStorePort | None = None,
        candidate_source: CandidateResourcePort | None = None,
        session_id: str | None = None,
    ) -> ListResult:
```

Inside `list_authorized()`, resolve session into context (same logic as authorize), then pass `ctx` through to the `self.authorize()` calls.

**authorize_traced()** — add `session_id` parameter with same resolution logic.

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/integration/test_session_integration.py -v`
Expected: All 5 tests PASS.

- [ ] **Step 5: Run full regression**

Run: `pytest --tb=short -q`
Expected: All 712+ existing tests PASS.

- [ ] **Step 6: Commit**

```
feat(guard): add session_id parameter to authorize/list_authorized (Phase 6 T6)
```

---

### Task 7: session.* ABAC Attribute Namespace

**Files:**
- Modify: `src/open_guard/adapters/evaluators/abac.py:185-217` (\_build\_attribute\_map)
- Add tests to `tests/unit/test_rbac_session.py` or create separate test file

- [ ] **Step 1: Write failing tests**

Add to `tests/unit/test_rbac_session.py` (or a new file `tests/unit/test_abac_session.py`):

```python
# tests/unit/test_abac_session.py
"""Tests for session.* ABAC namespace (Phase 6 — ENH-001)."""

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    Resource,
    Session,
    Subject,
)


def _abac_request(session: Session | None = None) -> AuthorizationRequest:
    ctx = {}
    if session is not None:
        ctx["_session"] = session
    return AuthorizationRequest(
        subject=Subject(id="alice", attributes={"roles": ["editor"]}),
        action=Action(name="promote"),
        resource=Resource(id="knowledge-1", resource_type="knowledge"),
        tenant_id="t1",
        context=ctx,
    )


class TestABACSessionNamespace:
    def setup_method(self) -> None:
        self.evaluator = ABACEvaluator()

    def test_session_scope_condition(self) -> None:
        """Policy requiring session.scope == 'WORKSPACE' matches."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
            metadata={"scope": "WORKSPACE"},
        )
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.scope": {"op": "eq", "value": "WORKSPACE"},
            },
        )
        req = _abac_request(session=session)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_session_scope_mismatch_denies(self) -> None:
        """Policy requiring WORKSPACE, but session is PROJECT → deny."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.scope": {"op": "eq", "value": "WORKSPACE"},
            },
        )
        req = _abac_request(session=session)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False

    def test_session_activated_roles_condition(self) -> None:
        """Policy checking if 'editor' is in session.activated_roles."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor", "viewer"],
        )
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.activated_roles": {"op": "contains", "value": "editor"},
            },
        )
        req = _abac_request(session=session)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_no_session_session_path_resolves_to_none(self) -> None:
        """Without a session, session.* paths resolve to None → condition fails."""
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.scope": {"op": "eq", "value": "WORKSPACE"},
            },
        )
        req = _abac_request(session=None)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_abac_session.py -v`
Expected: `session.scope` path resolves to None → condition fails for all.

- [ ] **Step 3: Add session namespace to ABAC _build_attribute_map**

In `src/open_guard/adapters/evaluators/abac.py`, inside `_build_attribute_map()`, add after the `chain` namespace block:

```python
        # Phase 6 (ENH-001): session.* namespace
        session = request.context.get("_session")
        if session is not None and hasattr(session, "activated_roles"):
            attr_map["session"] = {
                "activated_roles": session.activated_roles,
                "status": session.status if hasattr(session, "status") else None,
                "id": session.id if hasattr(session, "id") else None,
                **session.metadata if hasattr(session, "metadata") else {},
            }
        else:
            attr_map["session"] = {}
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_abac_session.py -v`
Expected: All 4 tests PASS.

- [ ] **Step 5: Run full regression**

Run: `pytest --tb=short -q`
Expected: All existing tests PASS.

- [ ] **Step 6: Commit**

```
feat(abac): add session.* attribute namespace for scope-aware policies (Phase 6 T7)
```

---

### Task 8: SQLAlchemySessionStore

**Files:**
- Modify: `src/open_guard/adapters/stores/sql_models.py` — add `SessionTable`
- Create: `src/open_guard/adapters/stores/sql_session.py`
- Create: `tests/unit/test_session_store_sql.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_session_store_sql.py
"""Tests for SQLAlchemySessionStore (Phase 6 — ENH-001)."""

import pytest
from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine

from open_guard.adapters.stores.sql_session import SQLAlchemySessionStore
from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError


@pytest.fixture
def store():
    engine = create_engine("sqlite:///:memory:")
    s = SQLAlchemySessionStore(engine)
    s.create_tables()
    return s


class TestSQLAlchemySessionStore:
    def test_create_and_get(self, store) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        created = store.create(session)
        got = store.get(created.id, "t1")
        assert got is not None
        assert got.activated_roles == ["editor"]

    def test_tenant_isolation(self, store) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        store.create(session)
        assert store.get(session.id, "t2") is None

    def test_get_active_for_subject(self, store) -> None:
        s1 = Session(tenant_id="t1", subject_id="alice", activated_roles=["editor"])
        s2 = Session(tenant_id="t1", subject_id="alice", activated_roles=["viewer"])
        store.create(s1)
        store.create(s2)
        active = store.get_active_for_subject("alice", "t1")
        assert len(active) == 2

    def test_update_status(self, store) -> None:
        session = Session(
            tenant_id="t1", subject_id="alice", activated_roles=["editor"]
        )
        store.create(session)
        now = datetime.now(UTC)
        updated = store.update_status(
            session.id, "t1", SessionStatus.DEACTIVATED, deactivated_at=now
        )
        assert updated.status == SessionStatus.DEACTIVATED

    def test_update_status_not_found(self, store) -> None:
        with pytest.raises(SessionNotFoundError):
            store.update_status("nope", "t1", SessionStatus.DEACTIVATED)

    def test_expire_stale(self, store) -> None:
        now = datetime.now(UTC)
        s_expired = Session(
            tenant_id="t1", subject_id="alice",
            activated_roles=["editor"], expires_at=now - timedelta(hours=1),
        )
        s_active = Session(
            tenant_id="t1", subject_id="bob",
            activated_roles=["viewer"], expires_at=now + timedelta(hours=1),
        )
        store.create(s_expired)
        store.create(s_active)
        count = store.expire_stale("t1", now)
        assert count == 1
        assert store.get(s_expired.id, "t1").status == SessionStatus.EXPIRED
        assert store.get(s_active.id, "t1").status == SessionStatus.ACTIVE
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_session_store_sql.py -v`
Expected: ImportError.

- [ ] **Step 3: Add SessionTable to sql_models.py**

Add to `src/open_guard/adapters/stores/sql_models.py`:

```python
session_table = Table(
    "open_guard_sessions",
    metadata,
    Column("id", String, primary_key=True),
    Column("tenant_id", String, nullable=False, index=True),
    Column("subject_id", String, nullable=False, index=True),
    Column("activated_roles", JSON, nullable=False),
    Column("status", String, nullable=False, default="active"),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("expires_at", DateTime(timezone=True), nullable=True),
    Column("deactivated_at", DateTime(timezone=True), nullable=True),
    Column("metadata_", JSON, nullable=False, default=dict),
)
```

- [ ] **Step 4: Implement SQLAlchemySessionStore**

```python
# src/open_guard/adapters/stores/sql_session.py
"""SQLAlchemy-backed session store (Phase 6, ENH-001)."""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Engine, and_, select, update

from open_guard.adapters.stores.sql_models import metadata, session_table
from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError
from open_guard.domain.ports.session_store import SessionStorePort


class SQLAlchemySessionStore(SessionStorePort):
    """SQLAlchemy implementation of SessionStorePort.

    Consumer-owned engine pattern (same as other SQL stores).
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def create_tables(self) -> None:
        metadata.create_all(self._engine, tables=[session_table])

    @classmethod
    def from_url(cls, url: str, **engine_kwargs) -> SQLAlchemySessionStore:
        from sqlalchemy import create_engine
        engine = create_engine(url, **engine_kwargs)
        store = cls(engine)
        store.create_tables()
        return store

    def create(self, session: Session) -> Session:
        with self._engine.begin() as conn:
            conn.execute(
                session_table.insert().values(
                    id=session.id,
                    tenant_id=session.tenant_id,
                    subject_id=session.subject_id,
                    activated_roles=session.activated_roles,
                    status=session.status.value,
                    created_at=session.created_at,
                    expires_at=session.expires_at,
                    deactivated_at=session.deactivated_at,
                    metadata_=session.metadata,
                )
            )
        return session

    def get(self, session_id: str, tenant_id: str) -> Session | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(session_table).where(
                    and_(
                        session_table.c.id == session_id,
                        session_table.c.tenant_id == tenant_id,
                    )
                )
            ).first()
            if row is None:
                return None
            return self._row_to_session(row)

    def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(session_table).where(
                    and_(
                        session_table.c.tenant_id == tenant_id,
                        session_table.c.subject_id == subject_id,
                        session_table.c.status == SessionStatus.ACTIVE.value,
                    )
                )
            ).fetchall()
            return [self._row_to_session(r) for r in rows]

    def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        values: dict = {"status": status.value}
        if deactivated_at is not None:
            values["deactivated_at"] = deactivated_at
        with self._engine.begin() as conn:
            result = conn.execute(
                update(session_table)
                .where(
                    and_(
                        session_table.c.id == session_id,
                        session_table.c.tenant_id == tenant_id,
                    )
                )
                .values(**values)
            )
            if result.rowcount == 0:
                raise SessionNotFoundError(
                    f"Session {session_id!r} not found in tenant {tenant_id!r}"
                )
        return self.get(session_id, tenant_id)  # type: ignore[return-value]

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._engine.begin() as conn:
            result = conn.execute(
                update(session_table)
                .where(
                    and_(
                        session_table.c.tenant_id == tenant_id,
                        session_table.c.status == SessionStatus.ACTIVE.value,
                        session_table.c.expires_at <= now,
                    )
                )
                .values(status=SessionStatus.EXPIRED.value)
            )
            return result.rowcount

    @staticmethod
    def _row_to_session(row) -> Session:
        return Session(
            id=row.id,
            tenant_id=row.tenant_id,
            subject_id=row.subject_id,
            activated_roles=row.activated_roles,
            status=SessionStatus(row.status),
            created_at=row.created_at,
            expires_at=row.expires_at,
            deactivated_at=row.deactivated_at,
            metadata=row.metadata_ or {},
        )
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `pytest tests/unit/test_session_store_sql.py -v`
Expected: All 7 tests PASS.

- [ ] **Step 6: Commit**

```
feat(session): add SQLAlchemySessionStore + table (Phase 6 T8)
```

---

## Deliverable 2: Policy Isolation (FEAT-010)

### Task 9: Read-Only Policy View for Evaluation Path

**Files:**
- Modify: `src/open_guard/domain/services/policy_router.py`
- Create: `tests/unit/test_policy_isolation.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_policy_isolation.py
"""Tests for prompt-injection-resistant policy isolation (Phase 6 — FEAT-010)."""

import pytest

from open_guard.domain.entities import Policy
from open_guard.domain.services.policy_router import ReadOnlyPolicyView


class TestReadOnlyPolicyView:
    def test_get_by_tenant_returns_policies(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        store = InMemoryPolicyStore()
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]}, action_match="read",
        )
        store.add(policy)
        view = ReadOnlyPolicyView(store)
        policies = view.get_by_tenant("t1")
        assert len(policies) == 1
        assert policies[0].id == "p1"

    def test_get_by_tenant_and_type(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            action_match="read",
        ))
        store.add(Policy(
            id="p2", tenant_id="t1", evaluator_type="abac",
            action_match="read",
        ))
        view = ReadOnlyPolicyView(store)
        rbac = view.get_by_tenant_and_type("t1", "rbac")
        assert len(rbac) == 1
        assert rbac[0].id == "p1"

    def test_add_raises_attribute_error(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        store = InMemoryPolicyStore()
        view = ReadOnlyPolicyView(store)
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            action_match="read",
        )
        with pytest.raises(AttributeError, match="read-only"):
            view.add(policy)

    def test_remove_raises_attribute_error(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        store = InMemoryPolicyStore()
        view = ReadOnlyPolicyView(store)
        with pytest.raises(AttributeError, match="read-only"):
            view.remove("p1", "t1")
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_policy_isolation.py -v`
Expected: ImportError — `ReadOnlyPolicyView` doesn't exist.

- [ ] **Step 3: Implement ReadOnlyPolicyView and wire into PolicyRouter**

Add to `src/open_guard/domain/services/policy_router.py`:

```python
class ReadOnlyPolicyView:
    """Read-only wrapper around PolicyStorePort.

    Phase 6 (FEAT-010): prevents the evaluation path from mutating policies.
    Evaluators receive policies through this view — add/remove are blocked.
    """

    def __init__(self, store: PolicyStorePort) -> None:
        self._store = store

    def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        return self._store.get_by_tenant(tenant_id)

    def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        return self._store.get_by_tenant_and_type(tenant_id, evaluator_type)

    def add(self, policy: Policy) -> Policy:
        raise AttributeError(
            "PolicyStore is read-only during evaluation — "
            "mutations are not permitted on the evaluation path"
        )

    def remove(self, policy_id: str, tenant_id: str) -> None:
        raise AttributeError(
            "PolicyStore is read-only during evaluation — "
            "mutations are not permitted on the evaluation path"
        )
```

In `PolicyRouter.__init__`, wrap the store:

```python
        self._policy_store = ReadOnlyPolicyView(policy_store)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_policy_isolation.py -v`
Expected: All 4 tests PASS.

- [ ] **Step 5: Run full regression**

Run: `pytest --tb=short -q`
Expected: All existing tests PASS (ReadOnlyPolicyView exposes the same read methods).

- [ ] **Step 6: Commit**

```
feat(isolation): add ReadOnlyPolicyView to block eval-path mutations (Phase 6 T9)
```

---

### Task 10: Taint Marking + trusted_only Condition Modifier

**Files:**
- Modify: `src/open_guard/adapters/evaluators/abac.py` — add `trusted_only` support
- Add tests to `tests/unit/test_policy_isolation.py`

- [ ] **Step 1: Write failing tests**

Append to `tests/unit/test_policy_isolation.py`:

```python
from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    PolicyEffect,
    Resource,
    Subject,
)


class TestTaintMarking:
    """Attributes with _trusted=false should be rejected by trusted_only conditions."""

    def setup_method(self) -> None:
        self.evaluator = ABACEvaluator()

    def _request(self, resource_attrs: dict) -> AuthorizationRequest:
        return AuthorizationRequest(
            subject=Subject(id="alice", attributes={"roles": ["editor"]}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc", attributes=resource_attrs),
            tenant_id="t1",
        )

    def test_trusted_only_allows_trusted_attributes(self) -> None:
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.classification": {
                    "op": "eq", "value": "public", "trusted_only": True,
                },
            },
        )
        req = self._request({"classification": "public"})
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_trusted_only_rejects_untrusted_attributes(self) -> None:
        """Attribute with _trusted=false on the resource is rejected."""
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.classification": {
                    "op": "eq", "value": "public", "trusted_only": True,
                },
            },
        )
        req = self._request({
            "classification": "public",
            "_trusted": {"classification": False},
        })
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False

    def test_without_trusted_only_untrusted_still_works(self) -> None:
        """Without trusted_only, untrusted attributes are evaluated normally."""
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.classification": {"op": "eq", "value": "public"},
            },
        )
        req = self._request({
            "classification": "public",
            "_trusted": {"classification": False},
        })
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_trusted_only_with_subject_attributes(self) -> None:
        """Taint works on subject attributes too."""
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "subject.department": {
                    "op": "eq", "value": "engineering", "trusted_only": True,
                },
            },
        )
        req = AuthorizationRequest(
            subject=Subject(
                id="alice",
                attributes={
                    "department": "engineering",
                    "_trusted": {"department": False},
                },
            ),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_policy_isolation.py::TestTaintMarking -v`
Expected: `test_trusted_only_rejects_untrusted_attributes` FAILS (taint check not implemented).

- [ ] **Step 3: Add taint checking to ABAC evaluator**

In `src/open_guard/adapters/evaluators/abac.py`, modify the condition evaluation to check `trusted_only`:

In `_evaluate_condition` (or wherever individual conditions are checked), before evaluating the operator:

```python
        # Phase 6 (FEAT-010): trusted_only taint check
        if condition_spec.get("trusted_only", False):
            if self._is_untrusted(attr_map, path):
                return ConditionResult(
                    path=path,
                    operator=op,
                    expected=expected,
                    actual=actual,
                    matched=False,
                )
```

Add helper method:

```python
    def _is_untrusted(self, attr_map: dict[str, Any], path: str) -> bool:
        """Check if an attribute is marked untrusted via _trusted metadata.

        Convention: the attribute source (subject, resource, etc.) can carry
        a ``_trusted`` dict mapping attribute names to booleans. If
        ``_trusted[attr_name]`` is False, the attribute is considered
        untrusted (e.g., sourced from LLM output).
        """
        parts = path.split(".")
        if len(parts) < 2:
            return False
        # Navigate to the source dict (subject, resource, etc.)
        source_key = parts[0]  # "subject", "resource", "action", "context"
        attr_name = parts[-1]  # leaf attribute name
        source = attr_map.get(source_key)
        if isinstance(source, dict):
            trusted_map = source.get("_trusted", {})
            if isinstance(trusted_map, dict) and trusted_map.get(attr_name) is False:
                return True
        return False
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_policy_isolation.py -v`
Expected: All 8 tests PASS.

- [ ] **Step 5: Commit**

```
feat(isolation): add trusted_only condition modifier + taint checking (Phase 6 T10)
```

---

### Task 11: Adversarial Prompt-Injection Test Suite

**Files:**
- Create: `tests/integration/test_prompt_injection.py`

- [ ] **Step 1: Write comprehensive adversarial tests**

```python
# tests/integration/test_prompt_injection.py
"""Adversarial prompt-injection test suite (Phase 6 — FEAT-010).

Demonstrates that LLM-generated data cannot influence policy evaluation
in ways that bypass authorization.
"""

import pytest

from open_guard import (
    ABACEvaluator,
    Action,
    Guard,
    InMemoryPolicyStore,
    Policy,
    PolicyEffect,
    RBACEvaluator,
    Resource,
    Subject,
)


@pytest.fixture
def guard():
    store = InMemoryPolicyStore()
    store.add(Policy(
        id="p-secret", tenant_id="t1", evaluator_type="abac",
        action_match="read",
        conditions={
            "resource.classification": {
                "op": "eq", "value": "public", "trusted_only": True,
            },
        },
    ))
    store.add(Policy(
        id="p-admin", tenant_id="t1", evaluator_type="rbac",
        subject_match={"roles": ["admin"]},
        action_match="*",
    ))
    return Guard(
        policy_store=store,
        evaluators=[RBACEvaluator(), ABACEvaluator()],
    )


class TestPromptInjectionDefenses:
    """10+ adversarial scenarios proving LLM-generated data cannot bypass authz."""

    def test_llm_injected_classification_blocked_by_taint(self, guard) -> None:
        """LLM sets classification=public on a secret doc → trusted_only blocks it."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="secret-doc", resource_type="doc", attributes={
                "classification": "public",  # LLM injected
                "_trusted": {"classification": False},
            }),
            "t1",
        )
        assert decision.allowed is False

    def test_trusted_classification_is_allowed(self, guard) -> None:
        """Same resource with trusted classification → allowed."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="public-doc", resource_type="doc", attributes={
                "classification": "public",
            }),
            "t1",
        )
        assert decision.allowed is True

    def test_llm_cannot_inject_roles_on_subject(self, guard) -> None:
        """LLM-crafted Subject attributes don't bypass RBAC."""
        # Even if the LLM generates a subject with admin role,
        # the actual Subject passed to authorize() is what the consumer builds.
        # This test documents that the consumer controls Subject construction.
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc"),
            "t1",
        )
        assert decision.allowed is False

    def test_policy_store_not_writable_from_evaluation(self, guard) -> None:
        """Policy store is read-only during evaluation — direct mutation blocked."""
        # The router wraps the store in ReadOnlyPolicyView
        from open_guard.domain.services.policy_router import ReadOnlyPolicyView
        # Access the router's policy store reference — it should be read-only
        router = guard._router
        assert isinstance(router._policy_store, ReadOnlyPolicyView)
        with pytest.raises(AttributeError, match="read-only"):
            router._policy_store.add(Policy(
                id="injected", tenant_id="t1", evaluator_type="rbac",
                subject_match={"roles": ["*"]}, action_match="*",
            ))

    def test_tenant_isolation_under_adversarial_input(self, guard) -> None:
        """Cross-tenant access impossible even with adversarial attributes."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={
                "roles": ["admin"],
                "tenant_id": "t1",  # attempted injection
            }),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc", attributes={
                "classification": "public",
            }),
            "other-tenant",  # actual tenant
        )
        # No policies exist for "other-tenant"
        assert decision.allowed is False

    def test_attribute_path_traversal_blocked(self, guard) -> None:
        """Dotted paths cannot traverse into internal state."""
        # Attempt: resource attribute with nested path that looks like
        # it could traverse into policy internals
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc", attributes={
                "classification": "public",
                "__class__": "Policy",  # injection attempt
                "_trusted": {"classification": False},
            }),
            "t1",
        )
        # trusted_only blocks it regardless of __class__ injection
        assert decision.allowed is False

    def test_condition_value_injection_via_operator_string(self, guard) -> None:
        """LLM cannot inject operator syntax through attribute values."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.label": {"op": "eq", "value": "safe"},
            },
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        # Attempt: set label to {"op": "eq", "value": "safe"} (dict, not string)
        decision = g.authorize(
            Subject(id="a1", attributes={}),
            Action(name="read"),
            Resource(id="r1", resource_type="doc", attributes={
                "label": {"op": "eq", "value": "safe"},
            }),
            "t1",
        )
        # The actual value is a dict, not "safe" → eq comparison fails
        assert decision.allowed is False

    def test_deny_policy_cannot_be_bypassed_by_taint(self, guard) -> None:
        """Deny policies are not affected by taint marking (deny always wins)."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p-deny", tenant_id="t1", evaluator_type="abac",
            action_match="delete", effect=PolicyEffect.DENY,
            conditions={"resource.type": {"op": "eq", "value": "doc"}},
            priority=100,
        ))
        store.add(Policy(
            id="p-allow", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]}, action_match="delete",
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator(), RBACEvaluator()])
        decision = g.authorize(
            Subject(id="admin-1", attributes={"roles": ["admin"]}),
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
        )
        assert decision.allowed is False

    def test_obo_chain_taint_propagation(self, guard) -> None:
        """Tainted attributes on an OBO chain member are caught by trusted_only."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "chain.root_actor.clearance": {
                    "op": "eq", "value": "top_secret", "trusted_only": True,
                },
            },
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        root = Subject(id="user-1", attributes={
            "clearance": "top_secret",
            "_trusted": {"clearance": False},  # LLM injected
        })
        agent = Subject(id="agent-1", attributes={"roles": []}, on_behalf_of=root)
        decision = g.authorize(
            agent,
            Action(name="read"),
            Resource(id="r1", resource_type="doc"),
            "t1",
        )
        assert decision.allowed is False

    def test_llm_output_as_resource_attributes_safe(self, guard) -> None:
        """Resource built from LLM output with taint marking is safe."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="promote",
            conditions={
                "resource.confidence": {
                    "op": "gte", "value": 0.9, "trusted_only": True,
                },
            },
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        # LLM claims confidence=0.95 — but it's untrusted
        decision = g.authorize(
            Subject(id="agent-1", attributes={}),
            Action(name="promote"),
            Resource(id="k1", resource_type="knowledge", attributes={
                "confidence": 0.95,
                "_trusted": {"confidence": False},
            }),
            "t1",
        )
        assert decision.allowed is False
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `pytest tests/integration/test_prompt_injection.py -v`
Expected: All 10 tests PASS (defenses already implemented in T9-T10).

- [ ] **Step 3: Commit**

```
test(isolation): add 10 adversarial prompt-injection defense scenarios (Phase 6 T11)
```

---

## Deliverable 3: Push Revocation (ENH-010)

### Task 12: RevocationEvent Entity + RevocationStreamPort

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `src/open_guard/domain/exceptions.py`
- Create: `src/open_guard/domain/ports/revocation_stream.py`

- [ ] **Step 1: Add RevocationEvent entity**

Add to `src/open_guard/domain/entities.py` (after Session block):

```python
# ---------------------------------------------------------------------------
# Phase 6 — Push Revocation (ENH-010)
# ---------------------------------------------------------------------------


class RevocationEventType(StrEnum):
    """Types of revocation events."""

    DELEGATION_REVOKED = "delegation_revoked"
    DELEGATION_EXPIRED = "delegation_expired"
    SESSION_DEACTIVATED = "session_deactivated"
    POLICY_REMOVED = "policy_removed"


class RevocationEvent(Entity):
    """A push notification that a permission/session/delegation was revoked.

    Phase 6 (ENH-010): emitted by DelegationManager, SessionManager, or
    Guard when permissions change. Long-running agents subscribe to these
    events for immediate re-authorization.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    event_type: RevocationEventType
    tenant_id: str
    subject_id: str | None = Field(
        default=None, description="Affected subject (if applicable)"
    )
    delegation_id: str | None = Field(
        default=None, description="Affected delegation (if applicable)"
    )
    session_id: str | None = Field(
        default=None, description="Affected session (if applicable)"
    )
    policy_id: str | None = Field(
        default=None, description="Affected policy (if applicable)"
    )
    reason: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
```

Add to exceptions.py:

```python
class RevocationError(OpenGuardError):
    """Raised for revocation stream errors."""
```

- [ ] **Step 2: Create RevocationStreamPort**

```python
# src/open_guard/domain/ports/revocation_stream.py
"""Abstract interface for push-based revocation events (Phase 6, ENH-010)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable

from open_guard.domain.entities import RevocationEvent


RevocationCallback = Callable[[RevocationEvent], None]


class RevocationStreamPort(ABC):
    """Port for publishing and subscribing to revocation events.

    CAEP-style push: when a permission/session/delegation is revoked,
    subscribers are notified immediately so long-running agents can
    re-check their authorization.
    """

    @abstractmethod
    def publish(self, event: RevocationEvent) -> None:
        """Publish a revocation event to all subscribers."""

    @abstractmethod
    def subscribe(
        self,
        tenant_id: str,
        callback: RevocationCallback,
        subject_id: str | None = None,
    ) -> str:
        """Subscribe to revocation events for a tenant.

        Args:
            tenant_id: Tenant to subscribe to.
            callback: Called with each RevocationEvent.
            subject_id: Optional filter — only events affecting this subject.

        Returns:
            Subscription ID for unsubscribe.
        """

    @abstractmethod
    def unsubscribe(self, subscription_id: str) -> None:
        """Remove a subscription."""
```

- [ ] **Step 3: Commit**

```
feat(revocation): add RevocationEvent entity + RevocationStreamPort (Phase 6 T12)
```

---

### Task 13: InMemoryRevocationStream

**Files:**
- Create: `src/open_guard/adapters/stores/memory_revocation.py`
- Create: `tests/unit/test_revocation_stream.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_revocation_stream.py
"""Tests for InMemoryRevocationStream (Phase 6 — ENH-010)."""

from datetime import UTC, datetime

from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.domain.entities import RevocationEvent, RevocationEventType


class TestInMemoryRevocationStream:
    def setup_method(self) -> None:
        self.stream = InMemoryRevocationStream()
        self.received: list[RevocationEvent] = []

    def _callback(self, event: RevocationEvent) -> None:
        self.received.append(event)

    def test_publish_to_subscriber(self) -> None:
        self.stream.subscribe("t1", self._callback)
        event = RevocationEvent(
            event_type=RevocationEventType.DELEGATION_REVOKED,
            tenant_id="t1",
            delegation_id="d1",
            reason="manual revoke",
        )
        self.stream.publish(event)
        assert len(self.received) == 1
        assert self.received[0].delegation_id == "d1"

    def test_tenant_isolation(self) -> None:
        self.stream.subscribe("t1", self._callback)
        event = RevocationEvent(
            event_type=RevocationEventType.DELEGATION_REVOKED,
            tenant_id="t2",  # different tenant
            delegation_id="d1",
        )
        self.stream.publish(event)
        assert len(self.received) == 0

    def test_subject_filter(self) -> None:
        self.stream.subscribe("t1", self._callback, subject_id="alice")
        # Event for alice
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.SESSION_DEACTIVATED,
            tenant_id="t1", subject_id="alice", session_id="s1",
        ))
        # Event for bob
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.SESSION_DEACTIVATED,
            tenant_id="t1", subject_id="bob", session_id="s2",
        ))
        assert len(self.received) == 1
        assert self.received[0].subject_id == "alice"

    def test_unsubscribe(self) -> None:
        sub_id = self.stream.subscribe("t1", self._callback)
        self.stream.unsubscribe(sub_id)
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.DELEGATION_REVOKED,
            tenant_id="t1", delegation_id="d1",
        ))
        assert len(self.received) == 0

    def test_multiple_subscribers(self) -> None:
        other_received: list[RevocationEvent] = []
        self.stream.subscribe("t1", self._callback)
        self.stream.subscribe("t1", lambda e: other_received.append(e))
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.POLICY_REMOVED,
            tenant_id="t1", policy_id="p1",
        ))
        assert len(self.received) == 1
        assert len(other_received) == 1

    def test_subject_filter_none_receives_all(self) -> None:
        """Subscribe without subject_id filter receives all tenant events."""
        self.stream.subscribe("t1", self._callback)
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.DELEGATION_EXPIRED,
            tenant_id="t1", subject_id="alice",
        ))
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.DELEGATION_EXPIRED,
            tenant_id="t1", subject_id="bob",
        ))
        assert len(self.received) == 2

    def test_event_with_no_subject_delivered_to_all(self) -> None:
        """Events without subject_id are delivered to all subscribers."""
        self.stream.subscribe("t1", self._callback, subject_id="alice")
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.POLICY_REMOVED,
            tenant_id="t1", policy_id="p1",
            # no subject_id — affects everyone
        ))
        assert len(self.received) == 1
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_revocation_stream.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement InMemoryRevocationStream**

```python
# src/open_guard/adapters/stores/memory_revocation.py
"""In-memory revocation stream (Phase 6, ENH-010)."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from uuid import uuid4

from open_guard.domain.entities import RevocationEvent
from open_guard.domain.ports.revocation_stream import RevocationCallback, RevocationStreamPort


@dataclass
class _Subscription:
    id: str
    tenant_id: str
    callback: RevocationCallback
    subject_id: str | None = None


class InMemoryRevocationStream(RevocationStreamPort):
    """Thread-safe in-memory pub/sub for revocation events."""

    def __init__(self) -> None:
        self._subscriptions: dict[str, _Subscription] = {}
        self._lock = threading.RLock()

    def publish(self, event: RevocationEvent) -> None:
        with self._lock:
            for sub in list(self._subscriptions.values()):
                if sub.tenant_id != event.tenant_id:
                    continue
                # Subject filter: if subscriber filtered by subject_id,
                # only deliver if event's subject_id matches or is None
                # (None = affects everyone, e.g., policy_removed)
                if sub.subject_id is not None:
                    if event.subject_id is not None and event.subject_id != sub.subject_id:
                        continue
                sub.callback(event)

    def subscribe(
        self,
        tenant_id: str,
        callback: RevocationCallback,
        subject_id: str | None = None,
    ) -> str:
        sub_id = str(uuid4())
        with self._lock:
            self._subscriptions[sub_id] = _Subscription(
                id=sub_id,
                tenant_id=tenant_id,
                callback=callback,
                subject_id=subject_id,
            )
        return sub_id

    def unsubscribe(self, subscription_id: str) -> None:
        with self._lock:
            self._subscriptions.pop(subscription_id, None)
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/test_revocation_stream.py -v`
Expected: All 7 tests PASS.

- [ ] **Step 5: Commit**

```
feat(revocation): add InMemoryRevocationStream with tenant + subject filtering (Phase 6 T13)
```

---

### Task 14: Event Emission from DelegationManager + SessionManager

**Files:**
- Modify: `src/open_guard/domain/services/delegation_manager.py`
- Modify: `src/open_guard/domain/services/session_manager.py`
- Create: `tests/unit/test_revocation_events.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_revocation_events.py
"""Tests for revocation event emission (Phase 6 — ENH-010)."""

from datetime import UTC, datetime, timedelta
from decimal import Decimal

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
    RevocationEvent,
    RevocationEventType,
    Session,
    Subject,
)
from open_guard.domain.services.session_manager import SessionManager


class TestSessionManagerEmitsEvents:
    def setup_method(self) -> None:
        self.session_store = InMemorySessionStore()
        self.stream = InMemoryRevocationStream()
        self.received: list[RevocationEvent] = []
        self.stream.subscribe("t1", self.received.append)
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.manager = SessionManager(
            session_store=self.session_store,
            clock=lambda: self.now,
            revocation_stream=self.stream,
        )

    def test_deactivate_emits_session_deactivated(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        self.manager.deactivate(session.id, "t1")
        assert len(self.received) == 1
        assert self.received[0].event_type == RevocationEventType.SESSION_DEACTIVATED
        assert self.received[0].session_id == session.id
        assert self.received[0].subject_id == "alice"

    def test_no_event_on_create(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        assert len(self.received) == 0

    def test_no_stream_no_error(self) -> None:
        """Manager without a stream still works."""
        manager = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        manager.deactivate(session.id, "t1")  # no error
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/test_revocation_events.py -v`
Expected: TypeError — `SessionManager.__init__` doesn't accept `revocation_stream`.

- [ ] **Step 3: Add revocation_stream to SessionManager**

In `src/open_guard/domain/services/session_manager.py`:

Add `revocation_stream` parameter:

```python
    def __init__(
        self,
        session_store: SessionStorePort,
        clock: Callable[[], datetime] | None = None,
        revocation_stream: RevocationStreamPort | None = None,
    ) -> None:
        self._store = session_store
        self._clock = clock or (lambda: datetime.now(UTC))
        self._revocation_stream = revocation_stream
```

Add import:

```python
from open_guard.domain.ports.revocation_stream import RevocationStreamPort
```

In `deactivate()`, after the status update, emit event:

```python
        if self._revocation_stream is not None:
            from open_guard.domain.entities import RevocationEvent, RevocationEventType
            self._revocation_stream.publish(RevocationEvent(
                event_type=RevocationEventType.SESSION_DEACTIVATED,
                tenant_id=tenant_id,
                subject_id=session.subject_id,
                session_id=session_id,
                reason="session deactivated",
                timestamp=self._clock(),
            ))
        return updated_session
```

- [ ] **Step 4: Add revocation_stream to DelegationManager.revoke()**

In `src/open_guard/domain/services/delegation_manager.py`:

Add `revocation_stream` parameter to `__init__`:

```python
        self._revocation_stream = revocation_stream
```

In `revoke()` method, after cascade revocation completes, emit event for each revoked delegation:

```python
        if self._revocation_stream is not None:
            from open_guard.domain.entities import RevocationEvent, RevocationEventType
            self._revocation_stream.publish(RevocationEvent(
                event_type=RevocationEventType.DELEGATION_REVOKED,
                tenant_id=tenant_id,
                subject_id=delegation.to_subject_id,
                delegation_id=delegation_id,
                reason=f"revoked by {caller.id}",
                timestamp=self._clock(),
            ))
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `pytest tests/unit/test_revocation_events.py -v`
Expected: All 3 tests PASS.

- [ ] **Step 6: Run full regression**

Run: `pytest --tb=short -q`
Expected: All existing tests PASS (revocation_stream defaults to None).

- [ ] **Step 7: Commit**

```
feat(revocation): emit events from SessionManager.deactivate + DelegationManager.revoke (Phase 6 T14)
```

---

### Task 15: Guard Revocation Stream Wiring

**Files:**
- Modify: `src/open_guard/domain/services/guard.py`
- Create: `tests/integration/test_revocation_integration.py`

- [ ] **Step 1: Write failing integration tests**

```python
# tests/integration/test_revocation_integration.py
"""End-to-end push revocation tests (Phase 6 — ENH-010)."""

from datetime import UTC, datetime, timedelta
from decimal import Decimal

from open_guard import (
    Action,
    ActorType,
    Guard,
    InMemoryDelegationStore,
    InMemoryPolicyStore,
    Policy,
    RBACEvaluator,
    Resource,
    Subject,
)
from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import (
    DelegationScope,
    RevocationEvent,
    RevocationEventType,
)
from open_guard.domain.services.session_manager import SessionManager


class TestRevocationIntegration:
    def setup_method(self) -> None:
        self.policy_store = InMemoryPolicyStore()
        self.delegation_store = InMemoryDelegationStore()
        self.session_store = InMemorySessionStore()
        self.stream = InMemoryRevocationStream()
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.received: list[RevocationEvent] = []

        self.guard = Guard(
            policy_store=self.policy_store,
            evaluators=[RBACEvaluator()],
            delegation_store=self.delegation_store,
            session_store=self.session_store,
            revocation_stream=self.stream,
            clock=lambda: self.now,
        )

        self.policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="read",
            resource_match={"type": "doc"},
        ))

    def test_delegation_revoke_emits_event(self) -> None:
        self.stream.subscribe("t1", self.received.append)
        admin = Subject(id="admin", attributes={"roles": ["admin"]},
                        actor_type=ActorType.USER)
        agent = Subject(id="agent-1", attributes={"roles": []},
                        actor_type=ActorType.AGENT)

        delegation = self.guard.delegate(
            from_subject=admin,
            to_subject=agent,
            scopes=[DelegationScope(
                action_match="read", resource_type="doc",
            )],
            tenant_id="t1",
        )
        self.guard.revoke_delegation(delegation.id, caller=admin, tenant_id="t1")

        assert len(self.received) >= 1
        revoke_events = [
            e for e in self.received
            if e.event_type == RevocationEventType.DELEGATION_REVOKED
        ]
        assert len(revoke_events) >= 1
        assert revoke_events[0].delegation_id == delegation.id

    def test_session_deactivate_emits_event(self) -> None:
        self.stream.subscribe("t1", self.received.append)
        alice = Subject(id="alice", attributes={"roles": ["admin"]})
        session_mgr = SessionManager(
            session_store=self.session_store,
            clock=lambda: self.now,
            revocation_stream=self.stream,
        )
        session = session_mgr.create_session(
            subject=alice, tenant_id="t1", activated_roles=["admin"]
        )
        session_mgr.deactivate(session.id, "t1")

        deactivate_events = [
            e for e in self.received
            if e.event_type == RevocationEventType.SESSION_DEACTIVATED
        ]
        assert len(deactivate_events) == 1
        assert deactivate_events[0].session_id == session.id

    def test_subscriber_can_trigger_recheck(self) -> None:
        """Subscriber receives event and triggers re-authorization."""
        recheck_results = []

        def on_revoke(event: RevocationEvent) -> None:
            # Simulate agent re-checking its authorization
            decision = self.guard.authorize(
                Subject(id="agent-1", attributes={"roles": []}),
                Action(name="read"),
                Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
                "t1",
            )
            recheck_results.append(decision.allowed)

        self.stream.subscribe("t1", on_revoke)
        admin = Subject(id="admin", attributes={"roles": ["admin"]},
                        actor_type=ActorType.USER)
        agent = Subject(id="agent-1", attributes={"roles": []},
                        actor_type=ActorType.AGENT)

        delegation = self.guard.delegate(
            from_subject=admin, to_subject=agent,
            scopes=[DelegationScope(action_match="read", resource_type="doc")],
            tenant_id="t1",
        )
        # Before revoke: agent has access via delegation
        decision = self.guard.authorize(
            agent, Action(name="read"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
        )
        assert decision.allowed is True

        # Revoke triggers subscriber which re-checks
        self.guard.revoke_delegation(delegation.id, caller=admin, tenant_id="t1")

        # Subscriber's recheck should show agent no longer has access
        assert len(recheck_results) >= 1
        assert recheck_results[0] is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/integration/test_revocation_integration.py -v`
Expected: TypeError — Guard doesn't accept `revocation_stream` yet.

- [ ] **Step 3: Wire revocation_stream into Guard**

In `src/open_guard/domain/services/guard.py`:

Add `revocation_stream` parameter to `__init__`:

```python
        revocation_stream: RevocationStreamPort | None = None,
```

Store it:

```python
        self._revocation_stream = revocation_stream
```

Pass it to DelegationManager (in the `if delegation_store is not None` block):

```python
            self._delegation_manager = DelegationManager(
                delegation_store=delegation_store,
                guard=self,
                approval_store=approval_store,
                clock=self._clock,
                max_delegation_depth=max_delegation_depth,
                default_delegate_policy=default_delegate_policy,
                revocation_stream=revocation_stream,
            )
```

Add import:

```python
from open_guard.domain.ports.revocation_stream import RevocationStreamPort
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/integration/test_revocation_integration.py -v`
Expected: All 3 tests PASS.

- [ ] **Step 5: Run full regression**

Run: `pytest --tb=short -q`
Expected: All existing tests PASS.

- [ ] **Step 6: Commit**

```
feat(revocation): wire RevocationStreamPort into Guard + DelegationManager (Phase 6 T15)
```

---

## Wrap-up Tasks

### Task 16: ADRs (0006, 0007, 0008)

**Files:**
- Create: `specs/decisions/0006-rbac-sessions.md`
- Create: `specs/decisions/0007-policy-isolation.md`
- Create: `specs/decisions/0008-push-revocation.md`

- [ ] **Step 1: Write ADR-0006 (RBAC Sessions)**

Key content: Session as first-class entity (not metadata), multiple concurrent sessions, `session.*` ABAC namespace, Guard `session_id` parameter. Prior art: NIST RBAC standard (Sandhu et al. 2000), AWS IAM session policies, Google Cloud Workload Identity session tokens.

- [ ] **Step 2: Write ADR-0007 (Policy Isolation)**

Key content: ReadOnlyPolicyView, taint marking via `_trusted` convention, `trusted_only` condition modifier. Prior art: OWASP prompt injection guidance, LangChain security advisories, content security policies (CSP web analogue).

- [ ] **Step 3: Write ADR-0008 (Push Revocation)**

Key content: RevocationStreamPort, event types, subscriber filtering, integration with DelegationManager + SessionManager. Prior art: CAEP/SSF (OpenID Foundation), Google Zanzibar watch API, Vault lease revocation.

- [ ] **Step 4: Commit**

```
docs: write ADR-0006 (sessions), ADR-0007 (isolation), ADR-0008 (revocation) (Phase 6 T16)
```

---

### Task 17: Integration Guide Phase 6 Section + Executable Mirrors

**Files:**
- Modify: `specs/architecture/integration-guide.md`
- Create: `tests/integration/test_integration_guide_phase6_examples.py`

- [ ] **Step 1: Add Phase 6 section to integration guide**

Cover:
- Creating sessions with scope metadata
- Authorize with `session_id` (editor at PROJECT scope can't delete)
- Taint marking for LLM-generated attributes
- `trusted_only` conditions
- Setting up push revocation subscribers
- Agent re-check pattern on revocation event

- [ ] **Step 2: Write executable mirror tests matching every code block in the guide**

Each demonstrative code block in the guide gets a corresponding test.

- [ ] **Step 3: Run mirror tests**

Run: `pytest tests/integration/test_integration_guide_phase6_examples.py -v`
Expected: All tests PASS.

- [ ] **Step 4: Commit**

```
docs: Phase 6 integration guide section + executable mirrors (Phase 6 T17)
```

---

### Task 18: Re-exports + Version Bump + Full Regression

**Files:**
- Modify: `src/open_guard/__init__.py`

- [ ] **Step 1: Add new types to __init__.py re-exports**

Add to imports and `__all__`:
- `Session`, `SessionStatus`, `SessionError`, `SessionNotFoundError`, `SessionExpiredError`
- `SessionStorePort`, `SessionManager`, `InMemorySessionStore`
- `RevocationEvent`, `RevocationEventType`, `RevocationError`
- `RevocationStreamPort`, `InMemoryRevocationStream`
- `ReadOnlyPolicyView`

- [ ] **Step 2: Bump version**

```python
__version__ = "0.7.0"
```

- [ ] **Step 3: Run full regression**

Run: `pytest --tb=short -q`
Expected: All tests PASS (712+ existing + ~130-180 new).

- [ ] **Step 4: Run quality gates**

Run: `ruff check src/ tests/`
Expected: Clean.

Run: `mypy --strict src/`
Expected: Clean.

- [ ] **Step 5: Commit**

```
chore: re-exports + v0.7.0 version bump (Phase 6 T18)
```

---

## Summary

| Task | Deliverable | What |
|------|-------------|------|
| T1 | ENH-001 | Session entity + SessionStatus |
| T2 | ENH-001 | SessionStorePort interface |
| T3 | ENH-001 | InMemorySessionStore |
| T4 | ENH-001 | SessionManager service |
| T5 | ENH-001 | RBACEvaluator session-aware evaluation |
| T6 | ENH-001 | Guard session_id integration |
| T7 | ENH-001 | session.* ABAC namespace |
| T8 | ENH-001 | SQLAlchemySessionStore |
| T9 | FEAT-010 | ReadOnlyPolicyView |
| T10 | FEAT-010 | Taint marking + trusted_only |
| T11 | FEAT-010 | Adversarial test suite (10 scenarios) |
| T12 | ENH-010 | RevocationEvent + RevocationStreamPort |
| T13 | ENH-010 | InMemoryRevocationStream |
| T14 | ENH-010 | Event emission (SessionManager + DelegationManager) |
| T15 | ENH-010 | Guard revocation_stream wiring |
| T16 | — | ADR-0006, ADR-0007, ADR-0008 |
| T17 | — | Integration guide + executable mirrors |
| T18 | — | Re-exports + version bump + full regression |
