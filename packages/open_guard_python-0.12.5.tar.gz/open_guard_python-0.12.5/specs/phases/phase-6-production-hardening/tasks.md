# Phase 6 — Production Hardening: Task Checklist

> Mirrors `plan.md` tasks. Mark `[x]` on completion, `[/]` for in-progress.

## Deliverable 1: RBAC Sessions (ENH-001)

- [x] **T1** — Session entity + SessionStatus enum + exceptions
- [x] **T2** — SessionStorePort abstract interface
- [x] **T3** — InMemorySessionStore + tests (10 tests)
- [x] **T4** — SessionManager service + tests (11 tests)
- [x] **T5** — RBACEvaluator session-aware role intersection + tests (7 tests)
- [x] **T6** — Guard session_id integration (authorize + list_authorized + authorize_traced) + integration tests (5 tests)
- [x] **T7** — session.* ABAC attribute namespace + tests (4 tests)
- [x] **T8** — SQLAlchemySessionStore + session table + tests (7 tests)

## Deliverable 2: Policy Isolation (FEAT-010)

- [x] **T9** — ReadOnlyPolicyView + wire into PolicyRouter + tests (4 tests)
- [x] **T10** — Taint marking + trusted_only condition modifier + tests (4 tests)
- [x] **T11** — Adversarial prompt-injection test suite (10 tests)

## Deliverable 3: Push Revocation (ENH-010)

- [x] **T12** — RevocationEvent entity + RevocationEventType + RevocationStreamPort
- [x] **T13** — InMemoryRevocationStream + tests (7 tests)
- [x] **T14** — Event emission from SessionManager.deactivate + DelegationManager.revoke + tests (3 tests)
- [x] **T15** — Guard revocation_stream wiring + integration tests (3 tests)

## Wrap-up

- [x] **T16** — ADR-0006 (sessions), ADR-0007 (policy isolation), ADR-0008 (push revocation)
- [x] **T17** — Integration guide Phase 6 section + executable mirror tests
- [x] **T18** — Re-exports in __init__.py + version bump to v0.7.0 + full regression + quality gates

## Quality Gates

- [x] All 712+ existing tests pass unchanged (806 total, zero breaking changes)
- [x] Coverage >= 97% (floor 95%)
- [x] `ruff check src/ tests/` clean
- [x] `mypy --strict src/` clean
