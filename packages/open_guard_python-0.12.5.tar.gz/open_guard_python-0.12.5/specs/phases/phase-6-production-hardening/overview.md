# Phase 6 — Production Hardening: Sessions, Policy Isolation & Push Revocation

> **Status**: Planned
> **Target Version**: v0.7.0
> **Breaking Changes**: None (fully additive to v0.6.0)

## Goal

Make open-guard production-ready for cerebrio-sapience v1.0 by adding NIST-compliant RBAC sessions (role subset activation per scope), securing the evaluation path against prompt-injection attacks, and closing the agent revocation loop with push-based events.

## Motivation

cerebrio-sapience is a multi-tenant agentic platform where actors operate across epistemic scopes (SESSION → PRIVATE → PROJECT → WORKSPACE → ORG). Each scope carries different trust levels and permission sets. Three gaps remain before open-guard can serve as the authorization substrate:

1. **No session concept** — actors activate *all* assigned roles on every request. In a scope-based system, an agent at PROJECT scope should only use PROJECT-level roles, not WORKSPACE or ORG roles it also holds. NIST RBAC sessions solve this.
2. **No prompt-injection defense** — cerebrio processes LLM outputs through evaluation pipelines. If LLM-generated data can influence policy evaluation (attribute injection, policy self-reference), agents could bypass authorization gates during knowledge promotion.
3. **No push revocation** — Phase 5 added pull-based heartbeat/lease renewal. But when permissions are revoked, long-running agents continue operating until their next heartbeat. Push-based revocation events close this window.

## Key Decisions

| # | Decision | Status | ADR |
|---|----------|--------|-----|
| 1 | Session as first-class entity with `SessionStorePort` (not metadata on Subject) | Locked | ADR-0006 |
| 2 | Multiple concurrent sessions per subject allowed | Locked | ADR-0006 |
| 3 | `session.*` ABAC attribute namespace (mirrors `chain.*` from Phase 3) | Locked | ADR-0006 |
| 4 | Guard gains `session_id` parameter; RBACEvaluator intersects with activated roles | Locked | ADR-0006 |
| 5 | Read-only policy view for evaluation path; taint marking on LLM-sourced attributes | Locked | ADR-0007 |
| 6 | `trusted_only` condition modifier rejects untrusted attribute values | Locked | ADR-0007 |
| 7 | `RevocationStreamPort` as abstract push interface (publish/subscribe) | Locked | ADR-0008 |
| 8 | Events emitted on delegation revoke, session deactivate, policy remove | Locked | ADR-0008 |

## Source Structure (New/Modified)

```
src/open_guard/
├── domain/
│   ├── entities.py                    # + Session, RevocationEvent
│   ├── exceptions.py                  # + SessionError, RevocationError
│   ├── ports/
│   │   ├── session_store.py           # NEW — SessionStorePort
│   │   └── revocation_stream.py       # NEW — RevocationStreamPort
│   └── services/
│       ├── session_manager.py         # NEW — SessionManager
│       ├── guard.py                   # MODIFIED — session_id param, revocation_stream
│       └── policy_router.py           # MODIFIED — read-only policy view, taint checks
├── adapters/
│   ├── evaluators/
│   │   └── rbac.py                    # MODIFIED — session-aware role intersection
���   └── stores/
│       ├── memory_session.py          # NEW — InMemorySessionStore
│       └── sql_session.py             # NEW — SQLAlchemySessionStore + table
│       └── memory_revocation.py       # NEW — InMemoryRevocationStream
└── __init__.py                        # + re-exports

tests/
├── unit/
│   ├── test_session_entity.py         # NEW
│   ├── test_session_manager.py        # NEW
│   ├── test_session_store_memory.py   # NEW
��   ├── test_session_store_sql.py      # NEW
│   ├── test_rbac_session.py           # NEW — evaluator with session context
│   ├── test_policy_isolation.py       # NEW — prompt-injection defense suite
│   ��── test_revocation_stream.py      # NEW
│   └── test_revocation_events.py      # NEW — integration with DelegationManager/SessionManager
├── integration/
│   ├── test_session_integration.py    # NEW — end-to-end session flows
��   ├── test_prompt_injection.py       # NEW — adversarial scenarios
│   └── test_revocation_integration.py # NEW — push revocation end-to-end
│   └── test_integration_guide_phase6_examples.py  # NEW — executable mirrors
```

## Scope

### In Scope

| ID | Deliverable | Description |
|----|-------------|-------------|
| ENH-001 | RBAC Sessions | `Session` entity, `SessionStorePort` (memory + SQL), `SessionManager`, RBACEvaluator session-aware evaluation, `Guard.authorize(session_id=...)`, `session.*` ABAC namespace, multiple concurrent sessions per subject |
| FEAT-010 | Prompt-injection policy isolation | Read-only policy view for evaluators, taint marking (`_trusted` attribute flag), `trusted_only` condition modifier, attribute path validation, adversarial test suite (10+ scenarios), security model documentation |
| ENH-010 | CAEP-style push revocation | `RevocationEvent` entity, `RevocationStreamPort` (publish/subscribe/unsubscribe), `InMemoryRevocationStream`, integration with `DelegationManager.revoke()` and `SessionManager.deactivate()`, event types: `delegation_revoked`, `delegation_expired`, `session_deactivated`, `policy_removed` |
| — | ADRs | ADR-0006 (sessions), ADR-0007 (policy isolation), ADR-0008 (push revocation) |
| — | Integration guide | Phase 6 section with executable mirror tests |

### Out of Scope (explicit non-goals)

| Item | Reason | Backlog |
|------|--------|---------|
| Management APIs (Role/Policy/Delegation CRUD) | Next phase — distinct concern | FEAT-011 |
| Service mode (HTTP/gRPC wrapper) | Depends on management APIs | FEAT-012 |
| Language SDKs (Python/TS/Go) | Depends on service mode | FEAT-013 |
| Policy DSL (Cedar/Rego) | Tenants use console UI; Pydantic models serialize to JSON | Dropped |
| External adapters (Casbin/OPA/OpenFGA) | Build our own — explicit decision | Dropped |
| Static/Dynamic Separation of Duty (SSD/DSD) | Sessions enable DSD later; not v1 | ENH-002/003 |
| Subscription API for decision changes | Builds on ENH-010; not v1 | ENH-011 |

## Deliverables & Verification

| # | Deliverable | Verification Command |
|---|-------------|---------------------|
| 1 | Session entity + stores | `pytest tests/unit/test_session_entity.py tests/unit/test_session_store_*.py -v` |
| 2 | SessionManager service | `pytest tests/unit/test_session_manager.py -v` |
| 3 | RBAC session-aware evaluation | `pytest tests/unit/test_rbac_session.py -v` |
| 4 | Guard session_id integration | `pytest tests/integration/test_session_integration.py -v` |
| 5 | Policy isolation + taint marking | `pytest tests/unit/test_policy_isolation.py tests/integration/test_prompt_injection.py -v` |
| 6 | Revocation stream + events | `pytest tests/unit/test_revocation_stream.py tests/unit/test_revocation_events.py -v` |
| 7 | Revocation end-to-end | `pytest tests/integration/test_revocation_integration.py -v` |
| 8 | Integration guide mirrors | `pytest tests/integration/test_integration_guide_phase6_examples.py -v` |
| 9 | Full regression | `pytest --tb=short -q` (all 712+ existing tests pass) |
| 10 | Quality gates | `ruff check src/ tests/` and `mypy --strict src/` |

## Acceptance Criteria

1. All existing 712+ tests pass unchanged (zero breaking changes)
2. RBAC session-scoped authorization works end-to-end (activate subset, evaluate, deactivate)
3. Multiple concurrent sessions per subject supported
4. `session.*` ABAC namespace available for scope-aware policies
5. Prompt-injection test suite passes (minimum 10 adversarial scenarios)
6. Read-only evaluation path structurally enforced
7. Push revocation events fire on delegation revoke, session deactivate, policy remove
8. Subscribers receive events and can trigger re-authorization
9. Coverage >= 97% (floor 95%)
10. `ruff` clean, `mypy --strict` clean
11. ADR-0006, ADR-0007, ADR-0008 written with prior-art citations
12. Integration guide Phase 6 section with executable mirrors

## Reference Specs

| Spec | Path | Sections Referenced |
|------|------|-------------------|
| Auth Model | `specs/architecture/auth-model.md` | RBAC, ABAC, Multi-Tenancy |
| Integration Guide | `specs/architecture/integration-guide.md` | All sections (Phase 6 section to be added) |
| Phase 5 History | `specs/phases/phase-5-delegation-bounds/history.md` | Delegation entity shape, evaluator wiring |
| Backlog | `specs/backlog/backlog.md` | ENH-001, FEAT-010, ENH-010 |

## Estimated Test Count

| Area | New Tests |
|------|-----------|
| Session entity + exceptions | 10-15 |
| SessionStorePort (memory) | 15-20 |
| SessionStorePort (SQL) | 15-20 |
| SessionManager | 15-20 |
| RBACEvaluator session-aware | 10-15 |
| Guard session_id integration | 10-15 |
| Policy isolation + taint | 15-20 |
| Prompt-injection adversarial | 10-15 |
| RevocationStreamPort | 10-15 |
| Revocation events integration | 10-15 |
| Integration guide mirrors | 8-12 |
| **Total** | **~128-182** |

Target: 840-894 total tests (712 existing + new).
