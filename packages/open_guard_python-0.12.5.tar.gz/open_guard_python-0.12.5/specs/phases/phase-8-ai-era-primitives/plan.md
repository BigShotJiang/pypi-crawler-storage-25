# Phase 8 — AI-Era Primitives: Implementation Plan

> **Approach**: Bottom-up — entities first, then evaluator, then chain config, then router integration, then Guard wiring, then factory, then integration tests.
> **Breaking changes**: One minor contract change (EvaluatorPort gains `evaluator_type` property). Pre-1.0, acceptable.
> **Commit convention**: `feat(scope):` for new features, `refactor(scope):` for EvaluatorPort change.

---

## Task 1: EvaluatorPort.evaluator_type abstract property

**Why first**: OperationChain and TrustGate both depend on evaluators declaring their type.

### 1.1 Add `evaluator_type` to EvaluatorPort

```python
# src/open_guard/domain/ports/evaluator.py
class EvaluatorPort(ABC):
    @property
    @abstractmethod
    def evaluator_type(self) -> str:
        """The evaluator type identifier (e.g., 'rbac', 'abac', 'trust')."""

    @abstractmethod
    def evaluate(self, request, policies) -> Evaluation: ...

    @abstractmethod
    def supports(self, policy) -> bool: ...
```

### 1.2 Add `evaluator_type` to AsyncEvaluatorPort

Same abstract property on the async port.

### 1.3 Implement on all existing evaluators

Each adapter already has the string internally — expose it:

| Evaluator | `evaluator_type` |
|-----------|-----------------|
| `RBACEvaluator` | `"rbac"` |
| `ABACEvaluator` | `"abac"` |
| `TBACEvaluator` | `"tbac"` |
| `ReBACEvaluator` | `"rebac"` |
| `AsyncReBACEvaluator` | `"rebac"` |
| `DelegationEvaluator` | `"delegation"` |

```python
# Example — src/open_guard/adapters/evaluators/rbac.py
@property
def evaluator_type(self) -> str:
    return "rbac"
```

### 1.4 Tests

- Verify each evaluator exposes the correct `evaluator_type` string.
- Full regression run — existing tests must pass unchanged.

**Commit**: `refactor(evaluator): add evaluator_type abstract property to EvaluatorPort`

---

## Task 2: ActorType extension

### 2.1 Add ROBOT and EDGE_DEVICE

```python
# src/open_guard/domain/entities.py
class ActorType(StrEnum):
    USER = "user"
    AGENT = "agent"
    SERVICE = "service"
    DEVICE = "device"
    CONVERSATION = "conversation"
    ROBOT = "robot"
    EDGE_DEVICE = "edge_device"
```

### 2.2 Tests

- Verify `ActorType.ROBOT.value == "robot"` and `ActorType.EDGE_DEVICE.value == "edge_device"`.
- Create a Subject with each new type, verify it round-trips.
- Existing tests pass unchanged (additive change).

**Commit**: `feat(entities): add ROBOT and EDGE_DEVICE actor types`

---

## Task 3: TrustGateEvaluator

### 3.1 Domain — trust policy conditions

TrustGate policies use the existing `Policy` entity with `evaluator_type="trust"` and conditions:

```python
Policy(
    id="trust-policy-1",
    tenant_id="t1",
    evaluator_type="trust",
    effect=PolicyEffect.ALLOW,
    conditions={
        "min_trust_score": 0.7,       # required — threshold
        "trust_scope": "immediate",    # optional — "immediate" | "all" | "root"
    },
    action_match="knowledge:write",    # optional — restrict to specific actions
    subject_match={"actor_type": "agent"},  # optional — restrict to actor types
)
```

No new entities needed — the existing Policy conditions dict is sufficient.

### 3.2 TrustGateEvaluator implementation

```python
# src/open_guard/adapters/evaluators/trust.py

class TrustGateEvaluator(EvaluatorPort):
    """Evaluator that gates authorization on actor trust scores.

    Checks subject.attributes["trust_score"] against a policy-defined
    threshold. Chain-aware: can check trust on immediate actor, root
    actor, or all actors in the OBO chain.
    """

    @property
    def evaluator_type(self) -> str:
        return "trust"

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "trust"

    def evaluate(self, request: AuthorizationRequest, policies: list[Policy]) -> Evaluation:
        # For each policy:
        #   1. Check subject_match (actor_type filter)
        #   2. Check action_match
        #   3. Extract min_trust_score from conditions
        #   4. Extract trust_scope from conditions (default: "immediate")
        #   5. Resolve trust_score(s) based on scope:
        #      - "immediate": subject.attributes.get("trust_score")
        #      - "root": subject.root_actor.attributes.get("trust_score")
        #      - "all": check every actor in the chain
        #   6. Compare: trust_score >= min_trust_score
        #   7. Priority-based conflict resolution (same as RBAC/ABAC)
        ...
```

**Key behaviors**:
- Missing `trust_score` attribute → DENY (fail closed)
- `trust_scope="all"` → ALL actors in chain must meet threshold
- `trust_scope="root"` → only root actor checked
- `trust_scope="immediate"` (default) → only immediate subject checked
- Subject/action matching reuses the same logic as other evaluators
- Priority-based: higher priority policy wins on conflict (deny at equal/higher priority overrides allow)

### 3.3 Evaluation result

```python
Evaluation(
    evaluator="trust",
    allowed=True,
    reason="Trust score 0.85 meets threshold 0.7",
    matched_policies=["trust-policy-1"],
    matched_policies_detail=[...],  # PolicyMatch with trust-specific info
    attributes_read=["trust_score"],
    duration_ms=0.1,
)
```

### 3.4 DecisionTrace integration

TrustGate produces `PolicyMatch` records with `ConditionResult` entries:

```python
ConditionResult(
    path="subject.trust_score",
    operator="gte",
    expected=0.7,
    actual=0.85,
    matched=True,
)
```

### 3.5 Tests

- Basic: trust_score >= threshold → ALLOW
- Basic: trust_score < threshold → DENY
- Missing trust_score → DENY
- trust_scope="root" — checks root actor
- trust_scope="all" — checks all actors in chain; one low score → DENY
- trust_scope="immediate" — checks only immediate subject (default)
- Action matching: policy with action_match only applies to matching actions
- Subject matching: policy with subject_match filters by actor_type
- Priority: higher priority deny overrides lower priority allow
- Multiple policies: composition within evaluator
- DecisionTrace: verify trust evaluator appears in trace
- Edge cases: trust_score=0.0, trust_score=1.0, threshold=0.0, threshold=1.0

**Commit**: `feat(trust): add TrustGateEvaluator — trust-score threshold authorization`

---

## Task 4: OperationChain entities

### 4.1 OperationRule and OperationChainConfig

```python
# src/open_guard/domain/entities.py (add to entities)

class OperationRule(Entity):
    """Maps an action pattern to a list of evaluator types.

    When OperationChainConfig is active, PolicyRouter uses these rules
    to select which evaluators participate for a given action.
    First match wins (like nginx location blocks).
    """
    action_pattern: str = Field(
        ..., description="Glob pattern for action names (e.g., 'knowledge:write', 'knowledge:*', '*')"
    )
    evaluators: list[str] = Field(
        ..., description="Evaluator type strings to activate (e.g., ['rbac', 'abac', 'tbac'])"
    )


class OperationChainConfig(Entity):
    """Configuration for action-pattern-based evaluator selection.

    Routes actions to specific evaluator subsets. First matching rule wins.
    If no rule matches, falls back to default_evaluators. If default_evaluators
    is None, all evaluators participate (backward compatible).
    """
    rules: list[OperationRule] = Field(
        ..., description="Ordered list of rules — first match wins"
    )
    default_evaluators: list[str] | None = Field(
        default=None,
        description="Fallback evaluator types when no rule matches. None = all evaluators."
    )

    def resolve(self, action_name: str) -> list[str] | None:
        """Return evaluator types for the given action, or None for 'use all'.

        Uses fnmatch-style glob matching. First match wins.
        """
        import fnmatch
        for rule in self.rules:
            if fnmatch.fnmatch(action_name, rule.action_pattern):
                return list(rule.evaluators)
        return list(self.default_evaluators) if self.default_evaluators else None
```

### 4.2 Tests

- Exact match: `"knowledge:write"` matches `"knowledge:write"`
- Glob match: `"knowledge:*"` matches `"knowledge:write"`, `"knowledge:read"`
- Wildcard: `"*"` matches everything
- First-match wins: more specific rule before glob
- No match + default_evaluators set → returns default list
- No match + default_evaluators=None → returns None (all evaluators)
- Empty rules list → always falls back to default
- Frozen model validation

**Commit**: `feat(entities): add OperationRule and OperationChainConfig`

---

## Task 5: PolicyRouter + AsyncPolicyRouter integration

### 5.1 PolicyRouter — operation_chain parameter

```python
# src/open_guard/domain/services/policy_router.py

class PolicyRouter:
    def __init__(
        self,
        evaluators: list[EvaluatorPort],
        policy_store: PolicyStorePort,
        clock: Callable[[], datetime] | None = None,
        operation_chain: OperationChainConfig | None = None,  # NEW
    ) -> None:
        self._evaluators = evaluators
        self._policy_store = ReadOnlyPolicyView(policy_store)
        self._clock = clock or (lambda: datetime.now(UTC))
        self._operation_chain = operation_chain

    def _get_active_evaluators(self, action_name: str) -> list[EvaluatorPort]:
        """Filter evaluators based on operation chain config."""
        if self._operation_chain is None:
            return self._evaluators
        allowed_types = self._operation_chain.resolve(action_name)
        if allowed_types is None:
            return self._evaluators
        return [e for e in self._evaluators if e.evaluator_type in allowed_types]
```

### 5.2 Update _run_against and _run_against_timed

Replace `self._evaluators` with `self._get_active_evaluators(request.action.name)`:

```python
def _run_against(self, request, policies):
    evaluations = []
    active = self._get_active_evaluators(request.action.name)
    for evaluator in active:
        matching = [p for p in policies if evaluator.supports(p)]
        if not matching:
            continue
        evaluations.append(evaluator.evaluate(request, matching))
    return evaluations
```

Same change in `_run_against_timed`.

### 5.3 AsyncPolicyRouter — same change

Mirror the `operation_chain` parameter and `_get_active_evaluators` method in AsyncPolicyRouter.

### 5.4 Tests

- No operation_chain → all evaluators run (backward compatible)
- With chain: action matches rule → only listed evaluators run
- With chain: action has no match + default set → default evaluators run
- With chain: action has no match + no default → all evaluators run
- Verify excluded evaluators do NOT participate
- Traced path: only active evaluators appear in DecisionTrace
- Async: same behavior in AsyncPolicyRouter

**Commit**: `feat(router): operation-chain-aware evaluator dispatch in PolicyRouter`

---

## Task 6: Guard + AsyncGuard passthrough

### 6.1 Guard.__init__ accepts operation_chain

```python
class Guard:
    def __init__(
        self,
        policy_store: PolicyStorePort,
        evaluators: list[EvaluatorPort] | None = None,
        ...,
        operation_chain: OperationChainConfig | None = None,  # NEW
    ) -> None:
        ...
        self._router = PolicyRouter(
            evaluators=evaluators or [...],
            policy_store=policy_store,
            clock=clock,
            operation_chain=operation_chain,  # pass through
        )
```

### 6.2 AsyncGuard.__init__ accepts operation_chain

Same passthrough to AsyncPolicyRouter.

### 6.3 Tests

- Guard with operation_chain → chain filtering active
- Guard without operation_chain → backward compatible
- AsyncGuard same
- Guard.authorize() with chain: verify correct evaluators fire

**Commit**: `feat(guard): pass operation_chain to PolicyRouter`

---

## Task 7: Guard.from_config() support

### 7.1 Factory accepts operation_chain kwarg

```python
# src/open_guard/adapters/factory.py

def build_guard(dsn, *, backend=None, operation_chain=None, **kwargs):
    ...
    return Guard(
        policy_store=policy_store,
        evaluators=evaluators,  # include TrustGateEvaluator
        ...,
        operation_chain=operation_chain,
    )
```

### 7.2 Factory auto-includes TrustGateEvaluator

The factory's default evaluator list gains TrustGateEvaluator:

```python
evaluators = [
    RBACEvaluator(role_hierarchy=kwargs.get("role_hierarchy")),
    ABACEvaluator(),
    TBACEvaluator(task_store=task_store, clock=clock),
    ReBACEvaluator(relationship_store=rel_store, type_defs=kwargs.get("type_definitions", [])),
    TrustGateEvaluator(),  # NEW
]
```

### 7.3 Tests

- `Guard.from_config(backend="memory")` includes TrustGateEvaluator
- `Guard.from_config(backend="memory", operation_chain=config)` wires chain
- `AsyncGuard.from_config(backend="memory", operation_chain=config)` same
- Trust policies work end-to-end through from_config()

**Commit**: `feat(factory): wire TrustGateEvaluator + operation_chain in from_config()`

---

## Task 8: Integration tests

### 8.1 AI-era scenario: multi-evaluator chain with trust gating

```python
# tests/integration/test_ai_era_integration.py

async def test_knowledge_write_requires_rbac_abac_tbac_trust():
    """Scenario: cerebrio-style knowledge:write requires all four evaluators."""
    chain = OperationChainConfig(rules=[
        OperationRule(action_pattern="knowledge:write", evaluators=["rbac", "abac", "tbac", "trust"]),
        OperationRule(action_pattern="knowledge:read",  evaluators=["rbac", "abac"]),
        OperationRule(action_pattern="knowledge:*",     evaluators=["rbac"]),
    ])
    guard = Guard.from_config(backend="memory", operation_chain=chain)
    ...
```

### 8.2 Scenarios to cover

1. **Full chain**: `knowledge:write` → RBAC + ABAC + TBAC + Trust all pass → ALLOWED
2. **Trust gate blocks**: same as above but trust_score too low → DENIED
3. **Read bypasses trust**: `knowledge:read` → only RBAC + ABAC checked, trust not evaluated
4. **Glob fallback**: `knowledge:trace` matches `knowledge:*` → only RBAC
5. **Robot actor**: Subject with `ActorType.ROBOT` + trust policies
6. **OBO chain trust**: agent on behalf of user, `trust_scope="all"` — both must be trusted
7. **Root trust only**: `trust_scope="root"` — only root actor's trust matters
8. **No chain config**: backward compatible — all evaluators participate
9. **Traced path**: verify DecisionTrace shows only active evaluators
10. **Async guard**: same scenarios via AsyncGuard

**Commit**: `test(integration): AI-era primitives end-to-end scenarios`

---

## Task 9: Package exports + cleanup

### 9.1 Export new symbols

Ensure `__init__.py` exports:
- `TrustGateEvaluator`
- `OperationRule`, `OperationChainConfig`
- `ActorType.ROBOT`, `ActorType.EDGE_DEVICE` (already via enum)

### 9.2 Final verification

```bash
pytest tests/ -x -q          # all tests pass
pytest tests/ --cov --cov-report=term-missing  # coverage >= 94%
```

**Commit**: `feat(exports): expose TrustGateEvaluator + OperationChain in public API`

---

## Commit Sequence

| Order | Message | Scope |
|-------|---------|-------|
| 1 | `refactor(evaluator): add evaluator_type abstract property to EvaluatorPort` | Ports + all adapters |
| 2 | `feat(entities): add ROBOT and EDGE_DEVICE actor types` | entities.py |
| 3 | `feat(trust): add TrustGateEvaluator — trust-score threshold authorization` | New evaluator |
| 4 | `feat(entities): add OperationRule and OperationChainConfig` | entities.py |
| 5 | `feat(router): operation-chain-aware evaluator dispatch in PolicyRouter` | PolicyRouter + AsyncPolicyRouter |
| 6 | `feat(guard): pass operation_chain to PolicyRouter` | Guard + AsyncGuard |
| 7 | `feat(factory): wire TrustGateEvaluator + operation_chain in from_config()` | Factory |
| 8 | `test(integration): AI-era primitives end-to-end scenarios` | Integration tests |
| 9 | `feat(exports): expose TrustGateEvaluator + OperationChain in public API` | __init__.py |
