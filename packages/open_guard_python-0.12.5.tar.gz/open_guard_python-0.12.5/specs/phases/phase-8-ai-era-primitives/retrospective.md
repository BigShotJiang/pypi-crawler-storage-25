# Phase 8 — AI-Era Primitives: Retrospective

> **Completed**: 2026-04-20
> **Version**: v0.9.0
> **Duration**: ~1 session
> **Tests**: 1037 (959 baseline + 78 new) | **Coverage**: 94%

## What Went Well

1. **Bottom-up plan worked perfectly.** Building evaluator_type property first, then TrustGate + OperationChain entities, then router integration, then Guard wiring, then factory — each layer built cleanly on the previous with zero rework.

2. **Existing patterns made the 5th evaluator trivial.** TrustGateEvaluator followed the exact same structure as RBAC/ABAC evaluators. The architecture's open/closed principle paid off — adding a new evaluator required zero changes to existing evaluator code.

3. **OperationChain is elegantly simple.** Using stdlib `fnmatch` for glob matching + first-match-wins semantics covers real use cases without over-engineering. No custom DSL, no complex config — just an ordered list of rules.

4. **Zero breaking changes.** `operation_chain=None` defaults preserve all existing behavior. The `evaluator_type` abstract property on EvaluatorPort is the one contract change, but pre-1.0 with no external consumers.

5. **Subagent-driven development was effective.** Dispatching implementer subagents per task with clear specs produced clean code that followed existing patterns. Review caught minor issues (dead `hasattr` check, `assert` in security code).

## What Didn't Go Well

1. **Test count slightly below target.** Plan targeted ~1050+ tests, delivered 1037. The 78 new tests provide solid coverage, but a few more edge cases (e.g., OperationChain with async factory for SQL backends) would strengthen confidence.

2. **Integration test 2 required adjustment.** The plan's "trust gate blocks write" scenario assumed trust denial would override RBAC+ABAC allows, but the deny-wins composition means an evaluator that fails to match a policy abstains rather than denies. Had to adjust the test to use trust as the sole evaluator to properly demonstrate blocking.

## Lessons Learned

1. **Evaluator abstention semantics matter.** When an evaluator's allow-policy conditions aren't met, it abstains rather than denying. This is correct (allows other evaluators to grant), but it means you can't rely on trust "blocking" a request when other evaluators allow it — the trust policy must be the sole ALLOW path, or a DENY policy must be used. This is a documentation gap worth addressing.

2. **The architecture scales well.** 8 phases in, the clean/hexagonal architecture continues to absorb new features cleanly. Adding a 5th evaluator + a dispatch mechanism + new actor types required no structural changes — just additive code at each layer.

3. **Phase reframing was the right call.** Pushing Service Mode to Phase 9 and doing AI-era primitives first means the library has a more compelling feature set for the service mode to expose. TrustGate + OperationChain make the "IAM for AI systems" story concrete.

## Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| Tests | ~1050+ | 1037 |
| Coverage | >=94% | 94% |
| Breaking changes | 0 | 0 (1 pre-1.0 contract change) |
| New evaluators | 1 | 1 (TrustGateEvaluator) |
| New entities | 2 | 2 (OperationRule, OperationChainConfig) |
| New actor types | 2 | 2 (ROBOT, EDGE_DEVICE) |
| Commits | 9 planned | 10 (+ 1 review fix) |
