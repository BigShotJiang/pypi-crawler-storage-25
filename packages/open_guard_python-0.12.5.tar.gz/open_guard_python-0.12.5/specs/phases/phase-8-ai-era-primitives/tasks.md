# Phase 8 — AI-Era Primitives: Task Checklist

> **Convention**: `[ ]` = not started, `[/]` = in progress, `[x]` = complete

## Task 1: EvaluatorPort.evaluator_type abstract property
- [x] 1.1 Add `evaluator_type` abstract property to `EvaluatorPort`
- [x] 1.2 Add `evaluator_type` abstract property to `AsyncEvaluatorPort`
- [x] 1.3 Implement `evaluator_type` on RBACEvaluator (`"rbac"`)
- [x] 1.4 Implement `evaluator_type` on ABACEvaluator (`"abac"`)
- [x] 1.5 Implement `evaluator_type` on TBACEvaluator (`"tbac"`)
- [x] 1.6 Implement `evaluator_type` on ReBACEvaluator (`"rebac"`)
- [x] 1.7 Implement `evaluator_type` on AsyncReBACEvaluator (`"rebac"`)
- [x] 1.8 Implement `evaluator_type` on DelegationEvaluator (`"delegation"`)
- [x] 1.9 Tests: verify each evaluator's `evaluator_type` string
- [x] 1.10 Full regression run — all 959+ existing tests pass

## Task 2: ActorType extension
- [x] 2.1 Add `ROBOT = "robot"` to ActorType enum
- [x] 2.2 Add `EDGE_DEVICE = "edge_device"` to ActorType enum
- [x] 2.3 Tests: verify values, create Subjects with new types

## Task 3: TrustGateEvaluator
- [x] 3.1 Create `src/open_guard/adapters/evaluators/trust.py`
- [x] 3.2 Implement `supports()` — matches `evaluator_type="trust"`
- [x] 3.3 Implement `evaluate()` — trust_score threshold checking
- [x] 3.4 Implement chain-aware trust scopes (immediate/all/root)
- [x] 3.5 Implement subject_match and action_match filtering
- [x] 3.6 Implement priority-based conflict resolution
- [x] 3.7 Implement PolicyMatch + ConditionResult for DecisionTrace
- [x] 3.8 Tests: basic allow/deny on trust_score
- [x] 3.9 Tests: missing trust_score → DENY
- [x] 3.10 Tests: trust_scope="root" — checks root actor
- [x] 3.11 Tests: trust_scope="all" — all actors in chain
- [x] 3.12 Tests: action_match filtering
- [x] 3.13 Tests: subject_match filtering
- [x] 3.14 Tests: priority-based conflict resolution
- [x] 3.15 Tests: DecisionTrace includes trust evaluator
- [x] 3.16 Tests: edge cases (0.0, 1.0 scores/thresholds)

## Task 4: OperationChain entities
- [x] 4.1 Add `OperationRule` entity to `entities.py`
- [x] 4.2 Add `OperationChainConfig` entity with `resolve()` method
- [x] 4.3 Tests: exact pattern matching
- [x] 4.4 Tests: glob pattern matching (`knowledge:*`)
- [x] 4.5 Tests: wildcard (`*`) matching
- [x] 4.6 Tests: first-match-wins ordering
- [x] 4.7 Tests: default_evaluators fallback
- [x] 4.8 Tests: no match + no default → None (all evaluators)

## Task 5: PolicyRouter + AsyncPolicyRouter integration
- [x] 5.1 Add `operation_chain` parameter to `PolicyRouter.__init__`
- [x] 5.2 Implement `_get_active_evaluators()` method
- [x] 5.3 Update `_run_against()` to use active evaluators
- [x] 5.4 Update `_run_against_timed()` to use active evaluators
- [x] 5.5 Mirror changes in `AsyncPolicyRouter`
- [x] 5.6 Tests: no chain → all evaluators (backward compatible)
- [x] 5.7 Tests: with chain → only matching evaluators
- [x] 5.8 Tests: traced path shows only active evaluators
- [x] 5.9 Tests: async router chain behavior

## Task 6: Guard + AsyncGuard passthrough
- [x] 6.1 Add `operation_chain` parameter to `Guard.__init__`
- [x] 6.2 Pass through to PolicyRouter
- [x] 6.3 Add `operation_chain` parameter to `AsyncGuard.__init__`
- [x] 6.4 Pass through to AsyncPolicyRouter
- [x] 6.5 Tests: Guard with/without operation_chain
- [x] 6.6 Tests: AsyncGuard with/without operation_chain

## Task 7: Guard.from_config() support
- [x] 7.1 Factory includes TrustGateEvaluator in default evaluator list
- [x] 7.2 Factory accepts `operation_chain` kwarg
- [x] 7.3 Async factory includes TrustGateEvaluator + operation_chain
- [x] 7.4 Tests: from_config() includes TrustGateEvaluator
- [x] 7.5 Tests: from_config() with operation_chain

## Task 8: Integration tests
- [x] 8.1 Full chain: write → RBAC+ABAC+TBAC+Trust all pass
- [x] 8.2 Trust gate blocks write
- [x] 8.3 Read bypasses trust (different chain rule)
- [x] 8.4 Glob fallback routing
- [x] 8.5 Robot actor with trust policies
- [x] 8.6 OBO chain trust — trust_scope="all"
- [x] 8.7 Root trust only — trust_scope="root"
- [x] 8.8 No chain config — backward compatible
- [x] 8.9 Traced path — DecisionTrace correctness
- [x] 8.10 AsyncGuard variants

## Task 9: Package exports + final verification
- [x] 9.1 Export TrustGateEvaluator in `__init__.py`
- [x] 9.2 Export OperationRule + OperationChainConfig in `__init__.py`
- [x] 9.3 Full test suite passes
- [x] 9.4 Coverage >= 94%
