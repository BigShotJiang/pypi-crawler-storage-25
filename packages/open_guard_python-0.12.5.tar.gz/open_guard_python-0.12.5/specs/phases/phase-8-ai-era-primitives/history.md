# Phase 8 — AI-Era Primitives: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [DECISION] 2026-04-20 — Phase 8 reframed from "Service Mode + SDKs" to "AI-Era Primitives"
Topics: scope, phase-theme, roadmap, ai-authorization
Affects-phases: phase-8-ai-era-primitives, phase-9-service-mode (future)
Affects-specs: specs/planning/roadmap.md, specs/status.md
Detail: Original Phase 8 was "Service Mode + SDKs" (FEAT-012, FEAT-013). Reframed to "AI-Era Primitives" — TrustGate evaluator, OperationChain evaluator dispatch, ActorType extension. Service Mode pushed to Phase 9. Motivated by brainstorm: open-guard should be the enforcement engine for AI-era authorization (like AWS IAM for AI systems), not just a library with RBAC/ABAC/TBAC/ReBAC primitives.

---

### [DECISION] 2026-04-20 — TrustGate as dedicated evaluator, not ABAC conditions
Topics: trust, evaluator, architecture
Affects-phases: phase-8-ai-era-primitives
Affects-specs: specs/architecture/auth-model.md
Detail: Trust gating could be done via ABAC conditions (`subject.trust_score >= 0.7`), but a dedicated evaluator provides: (1) semantic clarity, (2) independent composition in OperationChain, (3) chain-aware trust scopes (immediate/all/root) as first-class logic. Every AI system — robotics, healthcare, finance — needs trust gating; it's a universal primitive, not an attribute check.

---

### [DECISION] 2026-04-20 — OperationChain is light: action-pattern → evaluator-list
Topics: operation-chain, evaluator-dispatch, architecture
Affects-phases: phase-8-ai-era-primitives
Affects-specs: specs/architecture/policy-engine.md
Detail: OperationChain routes actions to evaluator subsets via fnmatch-style glob patterns (first match wins). Combination strategy stays deny-wins (same as today). Custom combination strategies per rule deferred — adds complexity without proven need. Any system defines its own action patterns and evaluator chains; open-guard doesn't know what the actions mean.

---

### [DECISION] 2026-04-20 — EvaluatorPort gains evaluator_type abstract property
Topics: evaluator, ports, contract
Affects-phases: phase-8-ai-era-primitives
Affects-specs: specs/architecture/auth-model.md
Detail: OperationChain needs to select evaluators by type string. Each adapter already uses one internally (e.g., `policy.evaluator_type == "rbac"`). Making it an abstract property on EvaluatorPort is a minor pre-1.0 contract change that formalizes what was already implicit.

---

### [DECISION] 2026-04-20 — HierarchicalScope deferred to post-cerebrio validation
Topics: scope-hierarchy, deferred, architecture
Affects-phases: none (future)
Affects-specs: none
Detail: Every AI system has a scope hierarchy (cerebrio: SESSION→ORG, robotics: SENSOR→CLOUD, healthcare: PATIENT→NETWORK). The pattern is universal but the labels differ. Rather than standardize prematurely, let cerebrio prove the pattern in its GovernanceSpineService, then extract a generic ScopeHierarchy config + ScopeEvaluator into open-guard in a future phase.

---

### [DECISION] 2026-04-20 — CapabilityEvaluator deferred
Topics: capability, deferred
Affects-phases: none (future)
Affects-specs: none
Detail: Capability-based access (is this agent authorized to use model X for operation Y?) is universal in AI systems. Deferred because it needs more design work — capability schemas vary widely across systems. Will revisit after TrustGate and OperationChain prove the evaluator extension pattern.

---
