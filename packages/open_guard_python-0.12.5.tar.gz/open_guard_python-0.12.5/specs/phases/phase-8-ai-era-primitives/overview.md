# Phase 8 — AI-Era Primitives (TrustGate + OperationChain + ActorType)

> **Version**: v0.9.0
> **Status**: Planned
> **Predecessor**: Phase 7 — Consumer Integration (v0.8.0)
> **Theme**: Evolve open-guard from a traditional authorization library to the enforcement engine for AI-era systems

## Goal

Add three universal AI-era authorization primitives that any AI system needs — without coupling to any specific domain (cerebrio, robotics, healthcare, etc.). open-guard becomes the **engine**; consumers provide the **configuration** (what actions exist, what policies govern them).

The mental model: open-guard is to AI authorization what AWS IAM is to AWS services. IAM doesn't know what S3 or EC2 are — it knows subjects, actions, resources, conditions, and evaluators. Each service defines its action names and policies. open-guard should work the same way.

## Key Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | TrustGate as a dedicated 5th evaluator, not ABAC conditions | Semantic clarity; composes independently in OperationChain; enables trust-specific chain-aware logic (root actor trust, all-in-chain trust) |
| 2 | OperationChain is action-pattern → evaluator-list mapping (light version) | First-match routing like nginx location blocks; deny-wins combination stays unchanged; full custom combination strategies deferred |
| 3 | `evaluator_type` abstract property added to EvaluatorPort | OperationChain needs to select evaluators by type string; each adapter already uses one internally — making it explicit is a clean contract change |
| 4 | ActorType extended, not replaced | Add ROBOT + EDGE_DEVICE; keep existing DEVICE (generic IoT sensors); pre-1.0, no backward compatibility concern |
| 5 | HierarchicalScope deferred | Universal pattern but needs validation — let cerebrio prove it, extract later |
| 6 | CapabilityEvaluator deferred | Needs more design work; lower priority than TrustGate + OperationChain |
| 7 | Service Mode pushed to Phase 9 | AI-era primitives are prerequisite for meaningful cross-system consumption |

## Source Structure

```
src/open_guard/
├── domain/
│   ├── entities.py                          # ActorType extension + OperationRule + OperationChainConfig
│   ├── ports/
│   │   └── evaluator.py                     # Add evaluator_type abstract property
│   └── services/
│       ├── policy_router.py                 # OperationChain-aware evaluator filtering
│       └── async_policy_router.py           # Same for async path
├── adapters/
│   ├── evaluators/
│   │   └── trust.py                         # NEW — TrustGateEvaluator
│   ├── factory.py                           # Wire TrustGate + accept operation_chain config
│   └── config.py                            # OperationChainConfig builder (optional)
```

## Scope

### In Scope

1. **TrustGateEvaluator** — 5th evaluator
   - Policy type: `evaluator_type="trust"`
   - Policy conditions: `{"min_trust_score": float}`
   - Subject attribute: `subject.attributes["trust_score"]` (0.0–1.0)
   - Chain-aware: `trust_scope` condition — `"immediate"` (default) | `"all"` | `"root"`
   - Integrates with DecisionTrace (Phase 3), PolicyRouter, AsyncPolicyRouter
   - InMemory + SQL stores already work (generic policy storage)

2. **OperationChain** — configurable evaluator selection per action pattern
   - `OperationRule(action_pattern: str, evaluators: list[str])` — e.g., `("knowledge:write", ["rbac", "abac", "tbac"])`
   - `OperationChainConfig(rules: list[OperationRule], default_evaluators: list[str] | None)` — first-match routing
   - `PolicyRouter` and `AsyncPolicyRouter` accept optional `operation_chain` parameter
   - When set, only matching evaluator types participate for the given action
   - When unset, all evaluators participate (backward compatible — existing behavior)
   - `Guard` and `AsyncGuard` pass through to PolicyRouter
   - `Guard.from_config()` accepts `operation_chain` kwarg

3. **ActorType extension**
   - Add `ROBOT = "robot"` and `EDGE_DEVICE = "edge_device"` to the enum
   - Update auth-model.md Actor Types table

4. **EvaluatorPort.evaluator_type** — abstract property
   - All existing evaluators (RBAC, ABAC, TBAC, ReBAC, Delegation) gain explicit `evaluator_type` property
   - AsyncEvaluatorPort gains the same property
   - AsyncReBACEvaluator gains it

### Out of Scope (Deferred)

- HierarchicalScope / ScopeEvaluator — cerebrio validates first
- CapabilityEvaluator — needs design work
- Custom combination strategies per chain rule — deny-wins stays
- Service Mode + SDKs — pushed to Phase 9
- OperationChain persistence (storing chain config in DB) — config is code, not data

## Deliverables

| # | Deliverable | Verification |
|---|-------------|-------------|
| 1 | TrustGateEvaluator with chain-aware trust checking | `pytest tests/ -k trust` — all pass |
| 2 | OperationRule + OperationChainConfig entities | `pytest tests/ -k operation_chain` — all pass |
| 3 | PolicyRouter + AsyncPolicyRouter chain-aware dispatch | `pytest tests/ -k "policy_router and chain"` — all pass |
| 4 | Guard/AsyncGuard operation_chain passthrough | `pytest tests/ -k "guard and chain"` — all pass |
| 5 | Guard.from_config() with operation_chain support | `pytest tests/ -k "from_config and chain"` — all pass |
| 6 | ActorType.ROBOT + ActorType.EDGE_DEVICE | `pytest tests/ -k actor_type` — all pass |
| 7 | EvaluatorPort.evaluator_type on all evaluators | `pytest tests/` — full suite green, no regressions |
| 8 | Integration tests: end-to-end AI-era scenarios | `pytest tests/integration/ -k ai_era` — all pass |

## Acceptance Criteria

1. All existing tests pass (zero regressions) — 959+ tests green
2. TrustGateEvaluator correctly gates on trust_score thresholds with immediate/all/root chain scopes
3. OperationChain correctly filters evaluators per action pattern with first-match semantics
4. Unset OperationChain behaves identically to pre-Phase-8 (backward compatible)
5. Guard.from_config() accepts and wires operation_chain
6. DecisionTrace includes TrustGate evaluator results
7. New tests bring total to ~1050+
8. Coverage stays above 94%

## Reference Specs

| Spec | Path | Sections |
|------|------|----------|
| Auth Model | `specs/architecture/auth-model.md` | Actor Types, Evaluation Flow |
| Policy Engine | `specs/architecture/policy-engine.md` | Evaluator dispatch |
| Integration Guide | `specs/architecture/integration-guide.md` | Guard construction, evaluator wiring |
