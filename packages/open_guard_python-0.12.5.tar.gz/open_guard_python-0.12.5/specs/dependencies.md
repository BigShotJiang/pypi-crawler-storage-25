# Dependencies

## This Repo

- **Name**: open-guard
- **Type**: Independent, open-standard authorization library
- **Owns**: RBAC, ABAC, TBAC, ReBAC, and policy engine design and implementation

## Dependencies

None — this is a standalone library. It does not depend on any Cerebrio repo.

## Consumers (for awareness, not dependencies)

| Consumer | Repo | How They Use Us |
|----------|------|-----------------|
| cerebrio-sapience | `../cerebrio-sapience` | Governance layer (Layer 6) via adapter pattern |
| Any external project | N/A | Direct import as authorization library |

## Local Architecture Docs

These docs are owned by this repo and live here:

| Doc | Path | Scope |
|-----|------|-------|
| Auth Model | `specs/architecture/auth-model.md` | RBAC + ABAC + TBAC + ReBAC unified design |
| Policy Engine | `specs/architecture/policy-engine.md` | Declarative policy language and evaluation |
| Integration Guide | `specs/architecture/integration-guide.md` | How consumers integrate open-guard |
