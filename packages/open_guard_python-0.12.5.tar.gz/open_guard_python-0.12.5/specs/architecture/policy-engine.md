# Open Guard: Policy Engine

> **Status**: Updated for Phase 8 (v0.9.0)
> **Owner**: open-guard (standalone)

## Overview

The policy engine evaluates declarative authorization policies against the unified auth model. `PolicyRouter` dispatches authorization requests to typed evaluators and combines their results.

## Evaluator Dispatch

### Default (all evaluators)

When no `OperationChainConfig` is provided, `PolicyRouter` dispatches to all registered evaluators. Each evaluator filters policies via `evaluator.supports(policy)` (checks `policy.evaluator_type`). This is the behavior from v0.1.0 through v0.8.0.

### OperationChain — Phase 8

`OperationChainConfig` enables action-pattern-based evaluator selection. Instead of all evaluators participating in every decision, consumers configure which evaluator subset handles which action patterns.

**Entities:**

```python
OperationRule(
    action_pattern="knowledge:write",     # fnmatch glob pattern
    evaluators=["rbac", "abac", "trust"], # evaluator types to activate
)

OperationChainConfig(
    rules=[
        OperationRule(action_pattern="knowledge:write", evaluators=["rbac", "abac", "trust"]),
        OperationRule(action_pattern="knowledge:read",  evaluators=["rbac", "abac"]),
        OperationRule(action_pattern="knowledge:*",     evaluators=["rbac"]),
    ],
    default_evaluators=None,  # None = all evaluators when no rule matches
)
```

**Resolution:** `OperationChainConfig.resolve(action_name)` uses `fnmatch` glob matching with **first-match-wins** semantics (like nginx `location` blocks). Returns:
- A list of evaluator type strings if a rule matches
- The `default_evaluators` list if no rule matches and defaults are set
- `None` if no rule matches and no defaults — meaning all evaluators participate

**Wiring:**

```python
guard = Guard(
    policy_store=store,
    evaluators=[rbac, abac, tbac, rebac, trust],
    operation_chain=chain,  # optional — None means all evaluators always
)

# or via factory:
guard = Guard.from_config(backend="memory", operation_chain=chain)
```

**Combination strategy:** unchanged. Within the active evaluator subset, deny-wins composition applies. Custom per-rule combination strategies are deferred.

### EvaluatorPort.evaluator_type — Phase 8

Every evaluator declares its type via an abstract property:

| Evaluator | `evaluator_type` |
|-----------|-----------------|
| `RBACEvaluator` | `"rbac"` |
| `ABACEvaluator` | `"abac"` |
| `TBACEvaluator` | `"tbac"` |
| `ReBACEvaluator` | `"rebac"` |
| `AsyncReBACEvaluator` | `"rebac"` |
| `TrustGateEvaluator` | `"trust"` |
| `DelegationEvaluator` | `"delegation"` |

This property is used by OperationChain to filter evaluators and by `supports()` to match policies.

## Combination Logic

```
Evaluations from active evaluators:
  1. Any explicit deny (DENY policy matched) → DENIED
  2. No allow-domain evaluator (only deny-effect policies, none matched) → DENIED
  3. At least one evaluator matched an allow policy → ALLOWED
  4. No evaluator matched any allow policy → DENIED (fail closed)
```

Evaluators that have no matching policies for a given request **abstain** — they don't block other evaluators from granting access. This allows, for example, ABAC to grant access when RBAC has no applicable policies for the subject.
