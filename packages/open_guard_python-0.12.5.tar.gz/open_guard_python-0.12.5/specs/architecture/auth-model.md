# Open Guard: Authorization Model

> **Status**: Phase 8 complete — RBAC + ABAC + TBAC + ReBAC + Trust + Delegation + Sessions + Async + Admin SDK + AI-Era Primitives (v0.9.0)
> **Owner**: open-guard (standalone)

## Overview

Open Guard provides a unified authorization framework combining five models:
- **RBAC** — Role-Based Access Control (Phase 0 — implemented)
- **ABAC** — Attribute-Based Access Control (Phase 0 — implemented)
- **TBAC** — Time-Based / Task-Based Access Control (Phase 1 — implemented)
- **ReBAC** — Relationship-Based Access Control (Phase 2 — implemented)
- **Trust** — Trust-score gating with chain-aware scopes (Phase 8 — implemented)

This document defines the authorization model independently of any consuming application.

## Principles

### Engineering Principles
1. **Vendor Neutrality** — Core logic never depends on specific policy engines or frameworks
2. **Fail Closed** — Authorization defaults to denial. Missing policies = denied
3. **No Sensitive Leakage** — Error messages don't expose policy internals
4. **Clean Architecture** — Domain is pure Python, isolated from IO and frameworks
5. **Strict Typing** — All public interfaces strictly typed. `mypy --strict`
6. **Test Everything** — Unit + integration + E2E. >95% coverage
7. **Conventional Commits** — For automated changelog
8. **Standards First** — Align with XACML concepts, OAuth 2.0, AAP standards

### SOLID Principles
- **S**: Each evaluator handles one auth model. PolicyStore handles storage. PolicyRouter handles combining.
- **O**: New auth models added by implementing EvaluatorPort — no existing code changes.
- **L**: Any EvaluatorPort implementation is interchangeable.
- **I**: Separate ports for separate concerns.
- **D**: Domain depends on abstractions (ports), never on concrete adapters.

### Design Principles
- Composition over inheritance
- Separation of concerns (data ownership, computation, orchestration)
- Least privilege by default (default deny)
- Immutable domain entities (frozen Pydantic models)
- Tenant isolation (every query scoped to tenant)

## Design

### Architecture

Clean/hexagonal architecture with three layers:

```
┌─────────────────────────────────┐
│  API Layer (FastAPI, etc.)       │  ← thin framework integration
├─────────────────────────────────┤
│  Domain Layer (pure Python)      │  ← entities, ports, services
│  Guard → PolicyRouter → Evaluators
├─────────────────────────────────┤
│  Adapter Layer                   │  ← concrete implementations
│  RBACEvaluator, ABACEvaluator,   │
│  TBACEvaluator, TrustGateEval-   │
│  uator, InMemoryPolicyStore      │
└─────────────────────────────────┘
```

- **Domain**: Zero external dependencies. All business logic.
- **Ports**: Abstract interfaces (EvaluatorPort, PolicyStorePort, TaskStorePort).
- **Adapters**: Swappable implementations.
- **API**: Thin framework wrappers (FastAPI middleware, dependencies).

### Evaluation Flow

```
guard.authorize(subject, action, resource, tenant_id)
  → PolicyRouter.evaluate(AuthorizationRequest)
    → PolicyStore.get_by_tenant(tenant_id)
    → _get_active_evaluators(action.name)  ← Phase 8: OperationChain filter
    → For each active evaluator:
        → Filter policies by evaluator.supports()
        → evaluator.evaluate(request, policies) → Evaluation
    → Combine: any deny → denied, all allow → allowed
  → Decision(allowed, reason, evaluations[])
```

**EvaluatorPort contract (Phase 8):** Every evaluator declares an `evaluator_type` abstract property (`"rbac"`, `"abac"`, `"tbac"`, `"rebac"`, `"trust"`). Used by OperationChain to select which evaluators participate for a given action.

**OperationChain (Phase 8):** Optional `OperationChainConfig` on Guard/PolicyRouter. Routes action patterns (fnmatch glob) to evaluator subsets. First match wins. When unset, all evaluators participate (backward compatible). See Policy Engine doc.

### Data Ownership

open-guard owns all policy data. Evaluators are compute-only.
- Policies stored in `PolicyStorePort` implementations
- Tasks stored in `TaskStorePort` implementations
- Relationship tuples stored in `RelationshipStorePort` implementations
- In-memory stores ship by default; SQLAlchemy-backed stores (`SQLAlchemyPolicyStore`, `SQLAlchemyTaskStore`, `SQLAlchemyRelationshipStore`) available via `pip install open-guard[sql]`
- SQLAlchemy stores follow the consumer-owned engine pattern (accept `Engine`, offer `from_url()` + `create_tables()`); metadata is exportable for consumer-managed Alembic migrations
- External engines (Casbin, OPA, OpenFGA) receive policies at evaluation time as optional adapters (Phase 3)
- No lock-in to any external engine's storage

## Entities

| Entity | Purpose |
|--------|---------|
| Subject | Who is requesting access (id, actor_type, attributes, metadata, **on_behalf_of** — Phase 3 OBO chain) |
| Resource | What is being accessed (id, resource_type, attributes) |
| Action | What operation (name, attributes) |
| AuthorizationRequest | Bundles subject + action + resource + context + tenant_id |
| Policy | A single authorization rule (subject_match, action_match, resource_match, conditions, effect, priority, **requires_approval** — Phase 3) |
| Task | A unit of work with scoped permissions and lifecycle (id, tenant_id, actor_id, status, allowed_actions, allowed_resource_types, expires_at) |
| TaskStatus | Lifecycle state enum: created, active, completed, failed, expired |
| RelationTuple | Zanzibar-style relation fact (tenant_id, object_type, object_id, relation, subject_type, subject_id, subject_relation) |
| TypeDefinition | ReBAC schema (name, relations, permissions) |
| PermissionRule | Computed permission (kind, relations, base, subtract, from_relation, to_permission) |
| Decision | Final result (**status** — Phase 3 tri-state, reason, evaluations[], approval_request_id) |
| DecisionStatus | Tri-state enum (Phase 3): ALLOWED / DENIED / PENDING_APPROVAL |
| Evaluation | Per-evaluator result (evaluator, allowed, reason, matched_policies, **matched_policies_detail** — Phase 3, **duration_ms**, **attributes_read**) |
| PolicyMatch | Per-policy trace (Phase 3) — policy_id, effect, matched, reason, matched_conditions[], matched_relations[], task_scope_ok |
| ConditionResult | ABAC condition trace (Phase 3) — path, operator, expected, actual, matched |
| RelationMatch | ReBAC traversal trace (Phase 3) — object_type, object_id, relation, subject, path[] |
| EvaluatorTrace | Per-evaluator rollup in DecisionTrace (Phase 3) — evaluator, status, matched_policies[], rejected_policies[], attributes_read[], duration_ms |
| SubjectSnapshot | Immutable actor snapshot for DecisionTrace (Phase 3) — id, actor_type, attributes |
| DecisionTrace | Structured explainability output (Phase 3) — schema_version, decision_status, final_reason, evaluator_results[], composition, actor_chain[], duration_ms, timestamp |
| ApprovalRequirement | Policy-level approval gate (Phase 3) — approvers[], quorum (any/all/int N), ttl, channel |
| ApprovalRequest | Pending/resolved approval (Phase 3) — id, tenant_id, request_hash, subject_id, action_name, resource_id, resource_type, status, requirement, approvers_received[], created_at, expires_at, resolved_at, reason |
| ApprovalDecision | Single approver vote (Phase 3) — approver, decision (approve/reject), reason, at |
| ApprovalStatus | Approval lifecycle enum (Phase 3) — PENDING / APPROVED / REJECTED / EXPIRED |

### Actor Types

| Type | Examples |
|------|----------|
| user | Human SaaS user, admin |
| agent | AI agent, agent in a swarm |
| service | M2M API client, webhook |
| device | IoT sensor, generic embedded device |
| conversation | AI conversation thread |
| robot | Physical robot, autonomous system (Phase 8) |
| edge_device | Edge computing node, gateway (Phase 8) |

## Identity Chains (OBO) — Phase 3 (FEAT-005)

A `Subject` may act **on behalf of** another `Subject`, forming a chain. This models the 2026 agentic pattern: a user delegates to an agent, which may spawn a subagent that invokes a tool — three distinct identities flowing through one authorization.

### Model

- `Subject.on_behalf_of: Subject | None` — recursive field, default `None`
- `Subject.chain_depth` — derived integer (0 = root, no delegation)
- `Subject.root_actor` — walks to the top of the chain
- `Subject.ancestors()` — iterator over delegators (immediate → root)
- Depth cap enforced at both construction time (`MAX_CHAIN_DEPTH_DEFAULT = 5` → raises `ChainDepthExceededError`) and Guard runtime (`Guard(max_chain_depth=...)`, also default 5)

### Policy semantics

Each evaluator chooses how to read the chain:

- **RBAC**: matches the **immediate** subject's roles
- **ReBAC**: tuples identify the **immediate** subject
- **TBAC**: task scope binds to the immediate subject
- **ABAC**: full chain exposed via the `chain.*` attribute namespace (see ABAC section)

### Design rationale

Chose a recursive field on `Subject` over alternatives (separate ChainLink entity, ReBAC tuples): minimal surface, additive, composes with all four evaluators without special-casing, typed traversal. The chain carries identity, not permission — permission-flow delegation (push/pull, scope narrowing) is separate and deferred to Phase 5 (FEAT-001).

## RBAC

Role-Based Access Control with hierarchy support.

- Roles extracted from `subject.attributes["roles"]`
- Role hierarchy: configurable parent-child (e.g., admin → editor → viewer)
- Priority-based conflict resolution (higher priority wins)
- Deny at equal/higher priority overrides allow

### Resource-Scoped Role Assignment — Phase 9 (FEAT-017)

`PolicyAdmin.assign_role(subject_id, role, resource_type=None, resource_match=None, ...)` — bind a role to a subject within an arbitrary resource scope. Industry-standard pattern: Google IAM resource bindings, AWS resource-scoped policies, Azure RBAC role assignments at resource group scope.

- `resource_match: dict[str, Any] | None` — arbitrary attribute constraints (e.g., `{"department": "engineering"}`, `{"region": "us-east"}`, `{"workspace_id": "ws-123"}`)
- Consumer defines what scoping means for their domain — open-guard stays vendor-neutral
- Implemented as RBAC policy `resource_match` filter; **no evaluator changes required**
- `revoke_role(subject_id, role, resource_match=...)` matches on the same scope — revoke one scope, keep others
- Backward-compatible: omitting `resource_match` retains tenant-global behavior

### Sessions — Phase 6 (ENH-001)

NIST Core RBAC sessions allow a subject to activate a subset of their assigned roles per request context. This enables scope-aware authorization (e.g., an agent operating at PROJECT scope activates only PROJECT-level roles, not WORKSPACE or ORG roles it also holds).

**Session entity fields:**
- `id` — UUID
- `tenant_id`, `subject_id` — scoped to a tenant
- `activated_roles: list[str]` — must be a subset of the subject's assigned roles; validated at `SessionManager.create_session()`
- `status: SessionStatus` — `ACTIVE` | `DEACTIVATED` | `EXPIRED`
- `expires_at: datetime | None` — optional TTL; lazy expiry checked by Guard and `SessionManager.get_session()`
- `metadata: dict[str, Any]` — consumer-defined context (e.g., `{"scope": "PROJECT"}`)

**Semantics:**
- Multiple concurrent sessions per subject are allowed (no single-active-session constraint)
- `Guard.authorize(request, session_id=None)` — if `session_id` is provided, Guard resolves the session and injects it into `request.context["_session"]`; if omitted, full roles are used (backward-compatible)
- `RBACEvaluator` intersects subject roles with `session.activated_roles` when an ACTIVE session is present
- Expired or deactivated sessions **fail-open**: evaluator falls back to full subject roles rather than denying
- See ADR-0006

## ABAC

Attribute-Based Access Control with condition operators.

Conditions evaluated against subject, resource, action, and context attributes using dotted paths (e.g., `subject.department`, `resource.classification`).

| Operator | Description |
|----------|-------------|
| eq / neq | Equals / not equals |
| in / not_in | In list / not in list |
| contains / not_contains | List or string contains / does not contain value |
| gt / gte / lt / lte | Numeric comparisons |
| regex / not_regex | Regular expression match / non-match |
| exists | Attribute exists (true/false) |
| contains_any | At least one set element overlaps (Cedar `containsAny`) |
| contains_all | All specified elements present (Cedar `containsAll`) |
| is_subset | Left is subset of right (XACML `string-subset`) |

### Logical Composition

**AND (within a group)** — all conditions in a single dict must match. This is the default for the legacy shorthand:

```json
{
  "subject.department": {"op": "eq", "value": "engineering"},
  "subject.clearance": {"op": "eq", "value": "high"}
}
```

**OR (across groups)** — use `condition_groups` with a list of dicts. Any group match = policy matches:

```json
{
  "condition_groups": [
    {"subject.department": {"op": "eq", "value": "engineering"}},
    {"subject.department": {"op": "eq", "value": "security"}}
  ]
}
```

### Chain-aware predicates (Phase 3)

When the `Subject` carries an OBO chain, ABAC exposes a `chain.*` attribute namespace so policies can reason over the full delegation chain without introducing a parallel language:

| Path | Meaning |
|------|---------|
| `chain.depth` | Integer hop count (0 for non-delegated) |
| `chain.immediate_actor.*` | Alias for the authorizing subject's attributes |
| `chain.root_actor.*` | The top of the chain — the originating actor |
| `chain.ancestors` | List of delegator dicts (immediate excluded) |

Plus a new operator:

| Operator | Description |
|----------|-------------|
| `any_matches` | For `chain.ancestors`: takes `{path, op, value}` sub-condition, returns True iff any item matches |

Example — "allow only if the root delegator is a trusted user":

```json
{
  "chain.root_actor.trusted": {"op": "eq", "value": true},
  "chain.depth": {"op": "lte", "value": 3}
}
```

Groups follow XACML's "multiple rules with permit-overrides" pattern. Legacy `conditions` dicts continue to work as a single group (backward-compatible).

### Session attribute paths — Phase 6 (ENH-001) {#session-attribute-paths}

When a session is active (`request.context["_session"]`), ABAC exposes a `session.*` namespace mirroring the `chain.*` namespace from Phase 3:

| Path | Meaning |
|------|---------|
| `session.id` | Session UUID |
| `session.status` | `"active"` / `"deactivated"` / `"expired"` |
| `session.activated_roles` | List of roles activated in this session |
| `session.<key>` | Any key from `session.metadata` (e.g., `session.scope`) |

Example — "allow only for PROJECT-scoped sessions with editor role activated":

```json
{
  "session.scope": {"op": "eq", "value": "PROJECT"},
  "session.activated_roles": {"op": "contains", "value": "editor"}
}
```

If no session is present in context, all `session.*` paths resolve to `None` and fail condition evaluation.

### Taint marking and trusted_only — Phase 6 (FEAT-010)

LLM-generated or externally sourced attribute values can be marked as untrusted to prevent prompt-injection attacks from influencing authorization decisions.

**Convention:** inject `_trusted: {attr_name: False}` into the attribute dict alongside the attribute value:

```python
subject = Subject(
    id="agent-1",
    attributes={
        "classification": llm_output,
        "_trusted": {"classification": False},  # marks as LLM-sourced
    }
)
```

**Condition modifier:** add `"trusted_only": true` to any ABAC condition. The evaluator will skip/deny if the attribute is marked untrusted:

```json
{
  "subject.classification": {"op": "eq", "value": "internal", "trusted_only": true}
}
```

The `_trusted` map is checked on the owning object (the source dict) via dotted path resolution. See ADR-0007.

## TBAC

Time-Based and Task-Based Access Control. Implemented by `TBACEvaluator` (evaluator_type="tbac").

### Time Conditions

All time conditions stored in `policy.conditions` and evaluated with AND logic.

**Absolute time windows:**
```json
{"time_window": {"not_before": "2026-04-16T00:00:00Z", "not_after": "2026-04-17T00:00:00Z"}}
```

**Recurring schedules** (IANA timezone, DST-aware):
```json
{"schedule": {"days": [1,2,3,4,5], "time_range": ["09:00","17:00"], "timezone": "Asia/Kolkata"}}
```
- Days use ISO weekday (Monday=1, Sunday=7)
- Time internally stored as UTC; converted to local timezone for schedule evaluation
- Uses Python stdlib `zoneinfo` (not pytz)

**TTL / duration** (ISO 8601):
```json
{"ttl": {"duration": "PT2H", "reference": "2026-04-16T12:00:00Z"}}
```
- Supports P[n]D, PT[n]H[n]M[n]S combinations
- Evaluated as: now <= reference + duration

### Task-Based Access Control

Tasks are first-class authorization objects. Permissions scoped to a task are only active while the task is in ACTIVE status.

**Task lifecycle** (Thomas & Sandhu 1997 model):
```
CREATED → ACTIVE → COMPLETED
                 → FAILED
                 → EXPIRED (auto, at evaluation time)
```

**Task-scoped policies** reference a task by ID:
```json
{"task_id": "task-123"}
```

The evaluator checks:
1. Task exists in TaskStore for the request's tenant
2. Task status is ACTIVE (auto-expires if past `expires_at`)
3. Requested action is in `task.allowed_actions`
4. Requested resource type is in `task.allowed_resource_types`

**Parent-child hierarchy** with permission narrowing:
- Child `allowed_actions` must be a subset of parent's
- Child `allowed_resource_types` must be a subset of parent's
- Child `expires_at` must not exceed parent's
- Parent must be ACTIVE to create a child
- Enforced by `TaskManager` service

**Clock injection:** Both `TBACEvaluator` and `TaskManager` accept a `Callable[[], datetime]` clock parameter for deterministic testing.

**Services:**
- `TaskManager` — lifecycle management (create, activate, complete, fail, expire, create_child)
- `TaskStorePort` — abstract storage interface (tenant-scoped)
- `InMemoryTaskStore` — thread-safe in-memory implementation

### Deferred TBAC Features

| Feature | Backlog | Priority |
|---------|---------|----------|
| Push/pull delegation | FEAT-001 | P2 |
| Usage-counted permissions | FEAT-002 | P2 |
| Heartbeat/lease renewal | FEAT-003 | P3 |
| Cron expression schedules | FEAT-004 | P3 |

## ReBAC

Relationship-Based Access Control following the Google Zanzibar model. Implemented by `ReBACEvaluator` (evaluator_type="rebac").

### Data Model

**Relation tuple** — a fact of the form `object_type:object_id#relation@subject_type:subject_id[#subject_relation]`:

```python
RelationTuple(
    tenant_id="t1",
    object_type="document", object_id="readme",
    relation="viewer",
    subject_type="user", subject_id="alice",
    subject_relation=None,  # optional, for usersets
)
```

- **Direct relation**: `subject_relation is None` — subject has the relation directly.
- **Subject set (userset)**: `subject_relation` is a string — all subjects with that relation on the subject object inherit the outer relation (e.g. `document:readme#viewer@group:devs#member`).
- **Wildcard**: `subject_id = "*"` — all subjects of that type (e.g. public access).

Tuples are stored per-tenant via `RelationshipStorePort`. Implementations: `InMemoryRelationshipStore`, `SQLAlchemyRelationshipStore` (optional `[sql]` extra).

### Type Definitions

Schemas declare relations and computed permissions per type:

```python
TypeDefinition(
    name="document",
    relations={"owner": ["user"], "editor": ["user"], "viewer": ["user"]},
    permissions={
        "can_edit": PermissionRule(kind="union", relations=["owner", "editor"]),
        "can_view": PermissionRule(kind="union", relations=["owner", "editor", "viewer"]),
    },
)
```

**Permission rule kinds:**
| Kind | Semantics |
|------|-----------|
| `self` | Direct relation exists (implicit — handled before rules) |
| `union` | Any listed relation holds (short-circuits on first YES) |
| `intersection` | All listed relations hold (short-circuits on first NO) |
| `exclusion` | `base` holds AND `subtract` doesn't |
| `arrow` | Walk `from_relation` to get target objects, then check `to_permission` on each |

### Check Algorithm

Recursive subproblem decomposition, consistent with Zanzibar/OpenFGA/SpiceDB:

1. Direct tuple check (including wildcards on subject_id).
2. Subject set expansion: for each tuple with `subject_relation`, recurse on the subject object with `subject_relation`.
3. Computed permission: resolve the rule via recursion.
4. Memoization per check (same subproblem cached).
5. Max depth limit (default 25) prevents infinite traversal on cycles.

### Policy Binding

ReBAC policies bind an object type + permission to an action:

```json
{
  "evaluator_type": "rebac",
  "action_match": "read",
  "conditions": {
    "object_type": "document",
    "permission": "can_view",
    "subject_type": "user"
  }
}
```

The evaluator honors `action_match` (same as ABAC), so multiple ReBAC policies can coexist per object type (e.g. `can_view` for reads, `can_edit` for writes).

### Relationship Query API — Phase 9 (ENH-021)

`PolicyAdmin.check_relationship(subject_type, subject_id, relation, object_type, object_id)` — direct query against the relationship store. Standard Zanzibar `Check` operation (OpenFGA `Check`, SpiceDB `CheckPermission`).

- Returns `bool` — does the relation tuple exist?
- No policy/authorize round-trip — pure data query, separate from authorization decisions
- Tenant-scoped (PolicyAdmin is bound to a tenant)
- Standard membership patterns work out of the box: group/team membership, org hierarchy, ownership
- Exposed at `POST /relationships/check` on `AdminRouter`
- Lives on PolicyAdmin (admin/data API), not Guard (authorization API) — by design: `Guard.authorize()` answers "can X do Y to Z?", `check_relationship()` answers "does relation R exist?"

### Deferred ReBAC Features

| Feature | Backlog | Priority |
|---------|---------|----------|
| Conditional relations (caveats / ABAC-in-ReBAC) | — | Phase 3+ |
| ListObjects / ListSubjects (reverse lookup) | — | Phase 3+ |
| Consistency tokens (zookies) | — | Phase 3+ |
| Watch/changelog API | — | Phase 3+ |

## Trust Gate — Phase 8

Trust-score-based authorization gating. Implemented by `TrustGateEvaluator` (evaluator_type="trust"). The 5th evaluator — purpose-built for AI-era systems where actors carry trust scores that can change dynamically.

### Trust Policies

Trust policies use the existing `Policy` entity with `evaluator_type="trust"`:

```python
Policy(
    id="trust-policy-1",
    tenant_id="t1",
    evaluator_type="trust",
    effect=PolicyEffect.ALLOW,
    conditions={
        "min_trust_score": 0.7,       # required — threshold (float 0.0–1.0)
        "trust_scope": "immediate",    # optional — "immediate" | "all" | "root"
    },
    action_match="knowledge:write",    # optional — restrict to specific actions
    subject_match={"actor_type": "agent"},  # optional — restrict to actor types
)
```

### Trust Scopes (chain-aware)

| Scope | Behavior |
|-------|----------|
| `immediate` (default) | Check `subject.attributes["trust_score"]` on the authorizing actor |
| `root` | Check trust_score on `subject.root_actor` — the top of the OBO chain |
| `all` | ALL actors in the chain must meet the threshold — one low score denies |

### Key Behaviors

- Missing `trust_score` attribute → DENY (fail closed)
- Subject/action matching reuses the same patterns as RBAC/ABAC
- Priority-based conflict resolution: higher priority deny overrides allow
- DecisionTrace includes `ConditionResult` with path (`subject.trust_score`, `chain.root.trust_score`, `chain.all.trust_score`), operator `gte`, expected threshold, actual score

### Design Rationale

Chose a dedicated evaluator over ABAC conditions (`subject.trust_score >= 0.7`) because:
1. Semantic clarity — trust gating is a distinct authorization concern
2. Independent composition in OperationChain — consumers can include/exclude trust per action pattern
3. Chain-aware trust scopes are first-class logic, not attribute path tricks

## Multi-Tenancy

Every policy is tenant-scoped. Cross-tenant access is impossible by design.
- All PolicyStore queries filtered by tenant_id
- tenant_id is required on AuthorizationRequest
- Tenants manage their own roles, policies, and access rules

### Service-mode tenancy — Phase 10

When open-guard runs as a service (`open_guard.service.create_app`), the
effective `tenant_id` for every request is sourced from the calling
identity, never from the request body. This eliminates a class of
cross-tenant bugs by construction.

- `CallerContext.tenant_id` is the only legitimate source — populated
  from the API key record (`ApiKeyAuth`) or the JWT claim
  (`ShieldAuth`).
- The request body never carries `tenant_id`; if it did, the field
  would be stripped server-side.
- `X-Tenant-ID` request header overrides the caller's tenant **only**
  when the caller's scopes include `cross_tenant_admin`. Without the
  scope, a mismatched override returns 403 `cross_tenant_forbidden`.
- Mirrors OpenFGA `store_id` and Auth0 FGA tenancy patterns.

## Service Mode Authentication — Phase 10 (FEAT-012)

Phase 10 adds an HTTP service mode (`open_guard.service.create_app`).
Service-mode authentication is distinct from authorization:

- **Authentication** (this section) answers "which service is asking?"
  → produces a `CallerContext`.
- **Authorization** (the rest of this document) answers "can the
  Subject in the request body do this action on this resource?"
  → returns a `Decision`.

The two never overload each other: the JWT or API key never carries
`Subject` data, and the request body never carries `tenant_id`. The
`Subject` and its optional `on_behalf_of` chain remain explicit in the
request body, identical to the embedded library.

### AuthBackend protocol

```python
class AuthBackend(Protocol):
    async def authenticate(self, request: Request) -> CallerContext: ...

@dataclass(frozen=True)
class CallerContext:
    tenant_id: str
    service_identity: str
    scopes: frozenset[str]
```

`authenticate` raises `AuthenticationError` on missing or invalid
credentials; the service-level exception handler renders this as a
401 envelope.

### Built-in backends

| Backend | Header | Backing store | Install |
|---------|--------|---------------|---------|
| `ApiKeyAuth` | `Authorization: ApiKey <k>` | `ApiKeyStorePort` (sha256-hashed records) | built-in |
| `ShieldAuth` | `Authorization: Bearer <jwt>` | open-shield `TokenValidatorPort` | optional `[shield]` extra |
| `CallableAuth` | (any) | user-supplied async callable | escape hatch |

#### `ApiKeyAuth`

- Keys are SHA-256 hashed at storage time; cleartext is shown to the
  operator exactly once (`ApiKeyAuth.generate()` returns
  `(cleartext, hash)`).
- Each `ApiKeyRecord` binds `(key_hash, tenant_id, service_identity,
  scopes, revoked)`.
- The default `InMemoryApiKeyStore` is sufficient for single-replica
  and test deployments. SQL-backed stores can land later when
  multi-replica deployments demand it.

#### `ShieldAuth`

- Wraps an open-shield `TokenValidatorPort` (typically
  `PyJWTValidator`). The validator is *injected* — open-guard does not
  pin the shield API surface beyond what's needed to extract claims.
- Claim names are configurable: `tenant_claim`, `identity_claim`,
  `scopes_claim`. Defaults match common JWT conventions
  (`tenant_id`, `sub`, `scope`).
- Open-shield is integrated as an *optional dependency*. The "should
  we merge open-shield into open-guard?" question stays explicitly
  deferred — Phase 10 leaves it as an `[shield]` extra; the merge
  question reopens if Phase 10 deployments expose ergonomics issues.

#### `CallableAuth`

- BYO escape hatch: accepts a `Callable[[Request], Awaitable[CallerContext]]`.
- Lets consumers plug mTLS verification, custom JWT validators,
  proxy-header passthrough, or anything else the built-ins don't
  cover.

### Auth is required by default

`create_app(...)` requires a non-`None` `auth` argument. Both the
DecisionRouter and the AdminRouter mount with the same
`make_tenant_dep(auth)` FastAPI dependency, so an unauthenticated
request returns `401` with the error envelope before any handler runs.

For full design rationale see ADR-0009 (wire contract).

## Decision & DecisionStatus — Phase 3 (FEAT-007)

`Decision` is the tri-state return value of `Guard.authorize()`.

### Shape

| Field | Type | Purpose |
|-------|------|---------|
| `status` | `DecisionStatus` | Source of truth: ALLOWED / DENIED / PENDING_APPROVAL |
| `reason` | `str` | Human-readable summary |
| `evaluations` | `list[Evaluation]` | Per-evaluator audit trail |
| `approval_request_id` | `str \| None` | When status=PENDING_APPROVAL, the id for resume |
| `allowed` | `bool` (computed) | True iff `status == ALLOWED` — API readability |

### Semantics

- **ALLOWED** — at least one matched allow policy AND no deny policy wins
- **DENIED** — explicit deny, no policies matched, or approval failed (rejected/expired)
- **PENDING_APPROVAL** — a matched allow policy had `requires_approval` set and no approved/rejected/expired approval for this request exists yet

The `allowed` property makes `if decision.allowed: ...` natural while keeping `status` as the canonical shape. Construction uses `Decision(status=DecisionStatus.X, ...)`.

## Approval Workflow — Phase 3 (FEAT-007)

Policies can declare that a match requires explicit human approval before resolving:

```python
Policy(
    ...,
    effect=PolicyEffect.ALLOW,
    requires_approval=ApprovalRequirement(
        approvers=["role:manager"],
        quorum="any",              # "any" | "all" | int N
        ttl=timedelta(hours=4),
        channel="slack",            # advisory hint for consumer dispatch
    ),
)
```

### Flow

1. `guard.authorize(...)` matches a policy with `requires_approval`
2. Guard checks `ApprovalStorePort.find_latest_by_hash(...)` for any historical decision for this (tenant, subject, action, resource)
3. Outcomes:
   - None → create a fresh PENDING request, return `Decision(status=PENDING_APPROVAL, approval_request_id=...)`
   - PENDING → return the same pending decision (idempotent by SHA-256 of the 5-tuple)
   - APPROVED → allow (historical approval honored)
   - REJECTED → deny with the rejector's reason
   - EXPIRED → create a fresh PENDING for this attempt
4. Consumer dispatches to the approval channel (Slack, email, webhook) using `requirement.channel` as a hint
5. On approval: `guard.approve(request_id, tenant, approver)` → next `authorize()` returns ALLOWED
6. On rejection: `guard.reject(request_id, tenant, approver, reason)` → next `authorize()` returns DENIED

### Quorum

- `"any"` (default) — first approve wins
- `"all"` — every listed approver must approve; any rejection finalizes as REJECTED
- integer N — N distinct approvers suffice

### Transport neutrality

open-guard never sends messages. The `channel` field is an advisory string (`"slack"`, `"email"`, etc.); the consumer owns dispatch. This keeps the library dependency-free of transport SDKs and keeps the security boundary clean.

### Idempotency

Request deduplicated by `SHA-256(tenant|subject.id|action.name|resource.id|resource.resource_type)`. Repeated `authorize()` calls while one PENDING request exists return the same `approval_request_id`.

### Storage

`ApprovalStorePort` is a distinct port from `PolicyStorePort` (rules vs. operational state). Implementations: `InMemoryApprovalStore`, `SQLAlchemyApprovalStore` (new `open_guard_approval_requests` table). `ApprovalManager` service encapsulates the idempotency + quorum + TTL logic; Clock-injected for deterministic tests.

## Decision Trace — Phase 3 (FEAT-008)

`Guard.authorize_traced(...)` returns `(Decision, DecisionTrace)` — the standard `authorize()` never materializes a trace (hot path stays cheap, trace privacy defaults to off).

### Trace structure

- `schema_version: str = "1.0"` — consumers may pin against breaking schema changes
- `decision_status`, `final_reason` — mirror the decision
- `evaluator_results: list[EvaluatorTrace]` — one per participating evaluator
- `composition: str` — how results combined: `all-allow`, `deny-wins`, `no-policies`, `no-allow-matched`, `pending-approval`
- `actor_chain: list[SubjectSnapshot]` — the resolved OBO chain, immediate → root
- `duration_ms`, `timestamp`

Each `EvaluatorTrace` carries `matched_policies[]` and `rejected_policies[]` as `PolicyMatch` records with:
- Per-condition results (`ConditionResult` — path, operator, expected, actual, matched)
- Per-relation traversal steps (`RelationMatch` — object_type, object_id, relation, subject) for ReBAC
- `task_scope_ok: bool | None` for TBAC

Traces are JSON-serializable via Pydantic — safe to log, ship to SIEM, or hand to an agent for reasoning.

### Design rationale

Dual API rather than flag: (1) hot path stays cheap; (2) trace privacy defaults to off — prevents leaking policy internals through API responses; (3) cleaner type signatures. `schema_version` is versioned because trace shape changes are contract changes for downstream consumers.

## list_authorized — Phase 4 (FEAT-006)

`Guard.list_authorized(subject, action, resource_type, tenant_id, prefilter=None, limit=100, cursor=None) -> ListResult` is the inverse of `authorize()` — given a subject, action, and resource type, return the IDs the subject can act on. Used by RAG pipelines, MCP filtered tool discovery, and any "which resources can this actor see?" query.

### Approach

Composition is identical to `authorize()` **by construction**: open-guard literally calls `authorize()` per candidate and returns IDs where the decision is `ALLOWED`. Pending-approval and denied resources are excluded.

Candidates come from two sources:

1. **`RelationshipStorePort.find_object_ids_for_subject(subject_id, subject_type, object_type, tenant_id, offset, limit)`** — native ReBAC enumeration. Returns the direct-membership superset of object IDs where the subject appears in any tuple. Sorted by `object_id` for stable pagination.
2. **`CandidateResourcePort.fetch_candidates(resource_type, tenant_id, prefilter, cursor, limit)`** — consumer-provided. Returns `(list[Resource], next_cursor)`. Carries the full resource attribute payload for ABAC / RBAC matching. open-guard does not own resource storage.

Iteration order: candidate source first (richer attributes), ReBAC enumeration second. Resources materialized from ReBAC tuples carry only `attributes={"type": resource_type}` — sufficient for ReBAC policies but not for attribute-matching ABAC. Wiring a `CandidateResourcePort` for the resource type fills that gap.

### Pagination

Opaque base64-URL-safe JSON token (`Cursor.encode()` / `Cursor.decode()`). Round-trips per-source continuation state plus a `seen_ids` set for cross-source dedupe. Default `limit=100`. Stability under concurrent policy changes is **undefined** — Zanzibar-style zookies (snapshot consistency) deferred to ENH-015.

### Why not reverse-ABAC

ADR-0001 records the rationale. Compiling ABAC conditions into store-native queries (Cerbos `PlanResources`, OPA partial evaluation) is one compiler per store backend, doesn't lower chain predicates / regex / set ops cleanly, and risks long-tail divergence from `authorize()`. Iterate-per-candidate matches AWS Verified Permissions / Casbin `enforce_batch` and is the standard hybrid-engine pattern. Targeted compilation for simple condition shapes can bolt on later as ENH-014.

## MCP Adapter — Phase 4 (FEAT-009)

`open_guard.adapters.mcp.MCPGuard(guard, resolver, default_tenant_id, resource_namespace="tool:{server_id}:{tool_name}")` maps Model Context Protocol tool invocations onto `Guard.authorize()`.

### Surface

- `check_tool_call(session_id, tool_name, params, server_id, tool_schema=None, claims=None) -> MCPAuthorizationResult` — the main entry point.
- `check_tool_call_traced(...)` — same, plus `(result, DecisionTrace)`.
- `list_authorized_tools(session_id, server_id=None, limit=100, cursor=None, claims=None) -> ListResult` — wraps `Guard.list_authorized(action="invoke", resource_type="tool", ...)` for filtered discovery.

`MCPAuthorizationResult` is a tagged union with `status ∈ {"allow", "deny", "pending"}`. Pending results carry `MCPAuthorizationPending` with the approval request id, approvers, quorum, channel hint, and TTL — hydrated from the approval store for consumer dispatch.

### Design

- **SDK-agnostic core, optional `[mcp]` extra**: Core takes plain dict / protocol shapes. The optional extra ships `open_guard.adapters.mcp.sdk` with a duck-typed `from_sdk_call_request` helper that reads `.name` / `.tool_name` and `.arguments` / `.params` — survives 2026+ SDK drift.
- **Resource namespace**: default `tool:{server_id}:{tool_name}` disambiguates multi-server deployments. Configurable.
- **Parameter-level ABAC via existing dot-paths**: tool `params` flatten into `resource.attributes["params"]`, so policies like `{"resource.params.query": {"op": "not_regex", "value": r"\bDROP\b"}}` work without new condition language.
- **Chain propagation via `MCPSessionResolver`**: a consumer-provided protocol that maps session claims to a `Subject` (with optional `on_behalf_of`). Phase 3 chain machinery flows through unchanged.
- **Pre-authorization schema hygiene**: `tool_schema` is optional; when supplied, malformed calls are rejected before policy evaluation with `status="deny", reason="schema_violation:..."`. Keeps policies from having to encode structural invariants and prevents fuzzing via policy-eval errors.

### Out of scope (ADR-0002 references)

- MCP transport security (TLS / mTLS / session auth) — consumer's concern.
- Streaming-tool chunk authorization — distinct data-flow pattern, tracked as ENH-017.
- MCP server / capability negotiation — consumer's MCP infrastructure.

## Policy Isolation — Phase 6 (FEAT-010)

Structural defense against prompt-injection attacks on the evaluation path.

**`ReadOnlyPolicyView`**: `PolicyRouter` automatically wraps the consumer-provided `PolicyStorePort` in a read-only view before passing policies to evaluators. `add()` and `remove()` on the view raise `AttributeError("PolicyStore is read-only during evaluation...")`. Evaluators can never mutate policies regardless of how they are invoked.

**Two-layer defense:**

| Layer | Mechanism | Threat mitigated |
|-------|-----------|-----------------|
| Structural | `ReadOnlyPolicyView` | LLM-induced `policy_store.add()` call during evaluation |
| Attribute-level | `_trusted` + `trusted_only` | LLM-generated attribute values influencing ABAC decisions |

See ABAC section for taint marking details. See ADR-0007.

## Push Revocation — Phase 6 (ENH-010)

CAEP-style (Continuous Access Evaluation Profile) push events close the window between permission revocation and long-running agent awareness.

**`RevocationStreamPort`** — abstract publish/subscribe interface:
- `publish(event: RevocationEvent) → None` — emit a revocation event
- `subscribe(tenant_id, callback, subject_id=None) → str` — register a callback; returns `subscription_id`; `subject_id=None` means all subjects in the tenant
- `unsubscribe(subscription_id: str) → None` — deregister

**Event types (`RevocationEventType`):**

| Event | When emitted |
|-------|-------------|
| `DELEGATION_REVOKED` | `DelegationManager.revoke()` — top-level delegation only |
| `DELEGATION_EXPIRED` | (consumer-emitted on stale expiry sweep) |
| `SESSION_DEACTIVATED` | `SessionManager.deactivate()` |
| `POLICY_REMOVED` | (consumer-emitted on policy removal) |

**`InMemoryRevocationStream`**: synchronous in-process delivery, at-most-once, subscriber snapshot taken before callback invocation (callbacks do not hold the lock). Suitable for single-process deployments; multi-process deployments extend via custom `RevocationStreamPort` adapters (Kafka, Redis PubSub, etc.).

**Guard wiring**: `Guard.__init__(revocation_stream=...)` passes the stream to `DelegationManager`. `SessionManager` accepts its own `revocation_stream` at construction (consumer-owned). See ADR-0008.

## Consumer Integration — Phase 7

Phase 7 makes open-guard consumable by any Python application — sync or async — with minimal wiring.

### Guard Factory

`Guard.from_config()` and `AsyncGuard.from_config()` — one-liner construction that wires all stores, evaluators, and managers from a DSN string or backend name:

| Backend | DSN Pattern | Stores |
|---------|------------|--------|
| Memory | `backend="memory"` (or no args) | In-memory (all 6 stores) |
| SQLite | `"sqlite:///path.db"` | SQLAlchemy sync |
| PostgreSQL | `"postgresql://user:pass@host/db"` | SQLAlchemy sync |
| Async SQLite | `"sqlite+aiosqlite:///path.db"` | SQLAlchemy async |
| Async PostgreSQL | `"postgresql+asyncpg://..."` | SQLAlchemy async |

### Async Architecture

**Dual API**: sync `Guard` unchanged, new `AsyncGuard` with native async I/O. No `to_thread()` wrapper — native async prevents thread pool saturation at scale.

**Evaluator dispatch**: RBAC, ABAC, and TBAC evaluators remain sync (pure CPU, dict matching on pre-fetched policies). Only `AsyncReBACEvaluator` is truly async because it calls the relationship store mid-traversal. `AsyncPolicyRouter` dispatches to both sync and async evaluators via `isinstance` check.

**Async ports**: all 7 store ports have async counterparts (`AsyncPolicyStorePort`, `AsyncRelationshipStorePort`, `AsyncDelegationStorePort`, `AsyncSessionStorePort`, `AsyncApprovalStorePort`, `AsyncTaskStorePort`, `AsyncCandidateResourcePort`) plus `AsyncEvaluatorPort`.

**Async stores**: in-memory (thin wrappers around sync stores) and SQLAlchemy async (using `AsyncEngine` + `async_sessionmaker`). Optional `[sql-async]` extra. As of Phase 9 (FEAT-016), `build_async_guard(dsn=...)` accepts `sqlite+aiosqlite://` and `postgresql+asyncpg://` DSNs and wires all 6 async SQL stores; the factory creates a separate sync engine internally for `TBACEvaluator` (which remains sync — `AsyncTBACEvaluator` deferred to a later phase).

**Public sync_store accessor (Phase 9 / ENH-020)**: all 6 `AsyncInMemory*Store` classes expose a typed `@property sync_store` that returns the underlying sync store. Consumers sharing state between `AsyncGuard` and sync `Guard` / `PolicyAdmin` use this property instead of touching the private `_sync` attribute.

### PolicyAdmin SDK

`PolicyAdmin(guard)` — in-process, tenant-scoped CRUD for all entity types:

| Domain | Operations |
|--------|-----------|
| Policies | `create_policy`, `list_policies`, `get_policy`, `delete_policy` |
| Roles | `assign_role(..., resource_match=)`, `revoke_role(..., resource_match=)` — convenience, creates/removes RBAC policies; resource-scoped via `resource_match` (Phase 9 / FEAT-017) |
| Relationships | `add_relationship`, `list_relationships`, `delete_relationship`, `check_relationship` (Phase 9 / ENH-021) |
| Delegations | `create_delegation`, `list_delegations`, `revoke_delegation` |
| Sessions | `create_session`, `deactivate_session`, `get_session`, `list_sessions` |

### Admin REST API

`AdminRouter(admin=admin)` — mountable FastAPI `APIRouter`. Routes: `POST/GET/DELETE` for policies, roles, relationships, delegations, sessions, plus `POST /relationships/check` (Phase 9 / ENH-021) and `GET /health`. Standalone server deferred to Phase 10 (Service Mode).

### DB Schema Tooling

- `create_all_tables(engine)` — idempotent, creates all 6 tables
- `get_ddl(dialect)` — returns DDL SQL for `sqlite` or `postgresql`
- CLI: `open-guard db init --dsn ...`, `open-guard db schema --dialect ...`
- No Alembic — schema creation is library concern, migration history is consumer concern

## Async Surfaces — Phase 11 (Async Parity, v0.12.0)

After Phase 11, `AsyncGuard` exposes the same authorization surface as
sync `Guard`. Every primitive has an async sibling that mirrors the sync
signature, return shape, idempotency rules, and error semantics
(see ADR-0012).

| Primitive | Sync | Async | Phase |
|-----------|------|-------|-------|
| `authorize` | `Guard.authorize` | `AsyncGuard.authorize` | 7 (core); 11 (delegation fallback + approval gating) |
| `authorize_traced` | `Guard.authorize_traced` | `AsyncGuard.authorize_traced` | 7 (core); 11 (approval gate applied) |
| `list_authorized` | `Guard.list_authorized` | `AsyncGuard.list_authorized` | 11 (FEAT-018) |
| `authorize_and_consume` | `Guard.authorize_and_consume` | `AsyncGuard.authorize_and_consume` | 11 (FEAT-014) |
| `delegate` / `revoke_delegation` / `renew_delegation` / `consume_delegation` | `DelegationManager` | `AsyncDelegationManager` | 11 (FEAT-014) |
| `approve` / `reject` | `ApprovalManager` | `AsyncApprovalManager` | 11 (FEAT-015) |

**Concurrency** — `AsyncGuard.list_authorized` evaluates candidates
sequentially (one `await self.authorize(...)` per candidate), matching
sync semantics exactly. ADR-0011 captures the rationale and the
explicit deferral of bounded concurrency until profiling data justifies
it.

**Industry alignment (vendor-neutral)** — the async surface lands on the
same shape as the rest of the field:

- `list_authorized` ↔ OpenFGA `ListObjects` · Zanzibar / SpiceDB
  `LookupResources` · AWS Verified Permissions `BatchIsAuthorized` ·
  Auth0 FGA `listObjects` · Cerbos `PlanResources` · Casbin
  `getImplicitResourcesForUser`
- Delegation ↔ NIST RBAC delegation (Sandhu et al.) · Vault / etcd
  lease-bound capability passing · capability-based security models
- Approval ↔ XACML Obligations · OAuth 2.0 Rich Authorization Requests
  (RFC 9396) · NIST SP 800-162 approval workflows

**Service mode** — `POST /v1/list_authorized` and
`POST /v1/authorize_and_consume` are engine-agnostic from v0.12.0.
`SERVICE_API_VERSION` stays `"v1"`; no wire-contract changes.

**Idempotency hashing** — `ApprovalRequest.make_hash` is the single
canonical SHA-256 helper used by both sync `ApprovalManager` and
`AsyncApprovalManager`. A mixed deployment (sync `Guard` + async
`AsyncGuard` sharing an approval store) sees deterministic collisions
on the same `(tenant, subject, action, resource)` key — no async-only
hash function.
