# Open Guard: Integration Guide

> **Status**: Current for v0.8.0 (Phase 7 — Consumer Integration)
> **Owner**: open-guard (standalone)
> **Audience**: Python application developers integrating open-guard as their authorization layer

---

## Overview

Open-guard is a vendor-neutral Python authorization library. It combines four models — **RBAC**, **ABAC**, **TBAC**, and **ReBAC** — behind a single `Guard` API that any Python app can adopt. It is dependency-free in core; optional extras (`sql`, `fastapi`, `mcp`) unlock specific integrations.

Key design rules:

- **Clean / hexagonal architecture** — domain entities, ports, and adapters are separated. You bring your own stores, candidate sources, and session resolvers.
- **Open-guard doesn't own resource storage.** Your application tells us what a `Resource` is and, when enumerating, where candidates come from (`CandidateResourcePort`).
- **Tenant isolation is explicit.** Every operation takes a `tenant_id`.
- **Composition is fail-closed.** If any registered evaluator denies (or no evaluator matches), the combined decision is DENY. This matches AWS Verified Permissions / Casbin semantics.

---

## Quick Start

Install:

```bash
pip install open-guard
```

Ten-line RBAC example:

```python
from open_guard import (
    ABACEvaluator, Action, Guard, InMemoryPolicyStore,
    Policy, RBACEvaluator, Resource, Subject,
)

store = InMemoryPolicyStore()
store.add(Policy(
    tenant_id="acme", evaluator_type="rbac",
    subject_match={"roles": ["editor"]},
    action_match="read",
    resource_match={"type": "doc"},
))
guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])
alice = Subject(id="alice", attributes={"roles": ["editor"]})
decision = guard.authorize(
    alice, Action(name="read"),
    Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
    tenant_id="acme",
)
assert decision.allowed
```

---

## Phase 0 — RBAC + ABAC

### RBAC with role hierarchy

```python
rbac = RBACEvaluator(role_hierarchy={
    "admin": ["editor"],
    "editor": ["viewer"],
})
# An admin inherits editor + viewer implicitly.
```

### ABAC conditions

Conditions are a dict of `path -> {"op": operator, "value": ...}`. Paths support dot notation into `subject`, `resource`, `action`, `context`, and `chain` namespaces.

```python
Policy(
    tenant_id="acme", evaluator_type="abac",
    action_match="read",
    resource_match={"type": "doc"},
    conditions={
        "resource.classification": {"op": "eq", "value": "public"},
    },
)
```

Operators: `eq`, `neq`, `in`, `contains`, `not_contains`, `regex`, `not_regex`, `contains_any`, `contains_all`, `is_subset`, and more. See `ABACEvaluator` docstring for the full set.

OR across groups:

```python
conditions={
    "condition_groups": [
        {"subject.department": {"op": "eq", "value": "engineering"}},
        {"subject.department": {"op": "eq", "value": "security"}},
    ],
}
```

### FastAPI integration

```python
from fastapi import FastAPI
from open_guard.api.fastapi import OpenGuardMiddleware, RequirePermission

app = FastAPI()
app.add_middleware(OpenGuardMiddleware, guard=guard)

@app.get("/docs/{doc_id}")
def read_doc(
    doc_id: str,
    _ok: None = RequirePermission(action="read", resource_type="doc"),
):
    ...
```

Middleware resolves a subject from request state (populated by your authentication layer — e.g., open-shield-python) and calls `guard.authorize` before the handler runs.

---

## Phase 1 — TBAC (Time + Task)

### Time windows

```python
from datetime import datetime, UTC

Policy(
    tenant_id="acme", evaluator_type="tbac",
    action_match="deploy",
    conditions={
        "window_start": datetime(2026, 4, 1, tzinfo=UTC),
        "window_end":   datetime(2026, 4, 30, tzinfo=UTC),
    },
)
```

### Recurring schedules (IANA timezone)

```python
Policy(
    tenant_id="acme", evaluator_type="tbac",
    action_match="run_batch",
    conditions={
        "schedule": {
            "timezone": "America/New_York",
            "days": ["mon", "tue", "wed", "thu", "fri"],
            "hours_start": 9, "hours_end": 18,
        },
    },
)
```

### Task-scoped permissions

Tasks are first-class authorization objects with their own lifecycle. Permissions scoped to a task are only active while the task is in `ACTIVE` status.

```python
from open_guard import InMemoryTaskStore, Task, TaskManager, TaskStatus

tasks = InMemoryTaskStore()
mgr = TaskManager(task_store=tasks)
task = mgr.create(
    Task(
        tenant_id="acme", actor_id="agent-1",
        allowed_actions=["read", "summarize"],
        allowed_resource_types=["doc"],
        created_at=datetime.now(UTC),
    )
)
mgr.activate(task.id, "acme")
# ... agent does its work ...
mgr.complete(task.id, "acme")
```

Parent-child hierarchy narrows permissions — children cannot exceed their parent.

---

## Phase 2 — ReBAC + SQLAlchemy

### Relation tuples (Zanzibar-style)

```python
from open_guard import (
    InMemoryRelationshipStore, PermissionRule, ReBACEvaluator,
    RelationTuple, TypeDefinition,
)

rel = InMemoryRelationshipStore()
rel.write_tuple(RelationTuple(
    tenant_id="acme", object_type="doc", object_id="d1",
    relation="owner", subject_type="user", subject_id="alice",
))

type_defs = {
    "doc": TypeDefinition(
        name="doc",
        relations={"owner": ["user"], "editor": ["user"], "viewer": ["user"]},
        permissions={
            "can_edit": PermissionRule(kind="union", relations=["owner", "editor"]),
            "can_view": PermissionRule(kind="union", relations=["owner", "editor", "viewer"]),
        },
    ),
}

rebac = ReBACEvaluator(relationship_store=rel, type_definitions=type_defs)
```

Policy referencing a computed permission:

```python
Policy(
    tenant_id="acme", evaluator_type="rebac",
    action_match="read",
    conditions={
        "object_type": "doc",
        "permission": "can_view",
        "subject_type": "user",
    },
)
```

### SQLAlchemy stores (optional `[sql]` extra)

```bash
pip install 'open-guard[sql]'
```

```python
from open_guard.adapters.stores.sql import SQLAlchemyPolicyStore, SQLAlchemyTaskStore
from open_guard.adapters.stores.sql_relationship import SQLAlchemyRelationshipStore

policy_store = SQLAlchemyPolicyStore.from_url("postgresql://.../authz")
policy_store.create_tables()
rel_store = SQLAlchemyRelationshipStore.from_url("postgresql://.../authz")
rel_store.create_tables()
```

Consumer owns the engine lifecycle; open-guard reuses it.

---

## Phase 3 — Agentic Core (chains, approvals, traces)

### Identity chains (on-behalf-of)

```python
from open_guard import ActorType, Subject

user  = Subject(id="alice", attributes={"trusted": True})
agent = Subject(
    id="agent-research", actor_type=ActorType.AGENT,
    on_behalf_of=user,
)
print(agent.chain_depth)     # 1
print(agent.root_actor.id)   # alice
```

### Chain-aware ABAC

```python
Policy(
    tenant_id="acme", evaluator_type="abac",
    action_match="read",
    resource_match={"type": "doc"},
    conditions={
        "chain.root_actor.trusted": {"op": "eq", "value": True},
    },
)
```

Paths available: `chain.depth`, `chain.immediate_actor.*`, `chain.root_actor.*`, `chain.ancestors` (for use with `any_matches`).

### Async approval

```python
from datetime import timedelta
from open_guard import (
    ApprovalRequirement, InMemoryApprovalStore, Policy,
)

approval_store = InMemoryApprovalStore()
store.add(Policy(
    tenant_id="acme", evaluator_type="rbac",
    subject_match={"roles": ["researcher"]},
    action_match="delete",
    resource_match={"type": "file"},
    requires_approval=ApprovalRequirement(
        approvers=["admin@corp"], quorum="any",
        ttl=timedelta(minutes=30), channel="slack",
    ),
))
guard = Guard(
    policy_store=store, evaluators=[RBACEvaluator()],
    approval_store=approval_store,
)

decision = guard.authorize(agent, Action(name="delete"), file_res, "acme")
if decision.status.name == "PENDING_APPROVAL":
    # Consumer dispatches to Slack/email using decision.approval_request_id
    ...

# Later, when the human approves:
guard.approve(decision.approval_request_id, "acme", approver="admin@corp")

# Next authorize() returns ALLOWED.
```

### Explainability — `authorize_traced`

```python
decision, trace = guard.authorize_traced(
    agent, Action(name="read"), doc, "acme",
)
trace.schema_version  # "1.0"
for evaluator_trace in trace.evaluator_results:
    print(evaluator_trace.evaluator, evaluator_trace.status)
    for pm in evaluator_trace.matched_policies:
        print("  matched", pm.policy_id, pm.reason)
# Chain is rendered:
for snap in trace.actor_chain:
    print(snap.id, snap.actor_type)
```

Traces are **opt-in** — never materialized on the hot path.

---

## Phase 4 — Agent Integration Surface

### `list_authorized` — the RAG filter primitive

`guard.list_authorized(subject, action, resource_type, tenant_id, ...)` returns the IDs of resources the subject can `action`, as a paginated list. Composition is identical to `authorize()` by construction — we literally call `authorize()` per candidate.

Candidate sources:
- **ReBAC native enumeration**: when a `relationship_store` is wired, we enumerate via `RelationshipStorePort.find_object_ids_for_subject` for the subject's direct relation tuples.
- **Application-provided `CandidateResourcePort`**: for ABAC/RBAC-driven resources the consumer provides candidate resources from their own data store (SQL, Elastic, etc.).

If both are wired, the candidate source is iterated first (richer attributes).

Minimal `CandidateResourcePort`:

```python
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.entities import Resource

class PGDocSource(CandidateResourcePort):
    def __init__(self, conn):
        self._conn = conn

    def fetch_candidates(
        self, resource_type, tenant_id, prefilter, cursor, limit,
    ):
        offset = int((cursor or {}).get("offset", 0))
        rows = self._conn.execute(
            "SELECT id, classification, owner FROM docs WHERE tenant_id=%s "
            "ORDER BY id OFFSET %s LIMIT %s",
            (tenant_id, offset, limit),
        ).fetchall()
        resources = [
            Resource(
                id=r["id"], resource_type=resource_type, tenant_id=tenant_id,
                attributes={
                    "type": resource_type,
                    "classification": r["classification"],
                    "owner": r["owner"],
                },
            )
            for r in rows
        ]
        next_cursor = {"offset": offset + limit} if len(rows) == limit else None
        return resources, next_cursor
```

Usage:

```python
guard = Guard(
    policy_store=policy_store,
    evaluators=[RBACEvaluator(), ABACEvaluator()],
    candidate_source=PGDocSource(pg_conn),
)
result = guard.list_authorized(alice, "read", "doc", "acme", limit=50)
print(result.ids)
if result.has_more():
    next_page = guard.list_authorized(
        alice, "read", "doc", "acme", limit=50, cursor=result.next_cursor,
    )
```

**Cursor stability**: opaque base64-JSON token that round-trips per-source offsets + seen IDs. Stability under *concurrent policy changes* between paginated calls is undefined (snapshot isolation requires Zanzibar-style zookies, deferred to ENH-015).

### End-to-end RAG walk-through

```python
# 1. Grant access via ReBAC tuples as documents are ingested
rel_store.write_tuple(RelationTuple(
    tenant_id="acme", object_type="doc", object_id="report-q1",
    relation="viewer", subject_type="user", subject_id="alice",
))

# 2. ABAC deny for anything classified "secret" unless clearance=="secret"
store.add(Policy(
    tenant_id="acme", evaluator_type="abac", effect="deny",
    action_match="read",
    conditions={
        "resource.classification": {"op": "eq", "value": "secret"},
        "subject.clearance": {"op": "neq", "value": "secret"},
    },
    priority=10,
))
# (+ a matching abac allow for non-secret docs; see integration tests)

# 3. List at retrieval time
guard = Guard(
    policy_store=store,
    evaluators=[ReBACEvaluator(...), ABACEvaluator()],
    relationship_store=rel_store,
    candidate_source=PGDocSource(pg_conn),
)
result = guard.list_authorized(alice, "read", "doc", "acme")
retrieved_docs = pg_conn.execute(
    "SELECT * FROM docs WHERE id = ANY(%s)", (result.ids,)
).fetchall()
```

### MCP adapter — tool-call authorization

Install the optional extra:

```bash
pip install 'open-guard[mcp]'
```

Implement a session resolver that maps MCP session claims to a `Subject` — this is where your authentication layer plugs in:

```python
from open_guard.adapters.mcp import MCPGuard, MCPSessionResolver
from open_guard import Subject, ActorType

class MySessionResolver:
    def resolve(self, session_id, claims):
        # claims['sub'] is the agent; claims['delegated_for'] is the user
        user = Subject(id=claims["delegated_for"], attributes={...})
        agent = Subject(
            id=claims["sub"], actor_type=ActorType.AGENT,
            attributes={"roles": claims.get("roles", [])},
            on_behalf_of=user,
        )
        return agent

resolver: MCPSessionResolver = MySessionResolver()
mcp = MCPGuard(
    guard=guard, resolver=resolver, default_tenant_id="acme",
)
```

Check a tool invocation:

```python
result = mcp.check_tool_call(
    session_id="sess-42",
    tool_name="query_db",
    params={"query": "SELECT * FROM users"},
    server_id="prod",
    tool_schema={  # optional — pre-authorization structural hygiene
        "type": "object",
        "required": ["query"],
        "properties": {"query": {"type": "string"}},
    },
)
if result.is_allowed():
    return run_tool(...)
elif result.is_pending():
    # decision.approval_request_id + approvers + TTL available on result.pending
    dispatch_to_slack(result.pending)
    return {"status": "awaiting_approval"}
else:
    raise PermissionDenied(result.reason)
```

Parameter-level ABAC (without new syntax):

```python
Policy(
    tenant_id="acme", evaluator_type="abac",
    action_match="invoke",
    resource_match={"tool_name": "query_db"},
    conditions={
        "resource.params.query": {
            "op": "not_regex",
            "value": r"(?i)\b(DROP|DELETE|TRUNCATE)\b",
        }
    },
)
```

Filtered tool discovery:

```python
# Requires a CandidateResourcePort scoped to resource_type="tool" wired on Guard.
tools = mcp.list_authorized_tools("sess-42", server_id="prod")
```

Resource namespace default is `tool:{server_id}:{tool_name}`. Customize via `MCPGuard(resource_namespace=...)`.

### SDK binding (optional)

```python
from open_guard.adapters.mcp.sdk import from_sdk_call_request, HAS_SDK

if HAS_SDK:
    req = from_sdk_call_request(
        sdk_request, session_id="sess-42", server_id="prod",
    )
    result = mcp.check_tool_call(
        req.session_id, req.tool_name, req.params, req.server_id,
        claims=req.claims,
    )
```

Duck-typed over the SDK's `.name`/`.arguments` or `.tool_name`/`.params` attributes so version drift doesn't break consumers.

---

## Phase 5 — Delegation & Bounds (v0.6.0)

### Overview

Phase 5 adds a push/pull delegation primitive to open-guard. A **delegation** is a grant that lets one subject (the *grantor*) authorize another (the *grantee*) to exercise a scoped subset of permissions — including human→agent, agent→agent, or user→user chains.

Key concepts:
- **DelegationScope** — action + resource_type + optional `resource_match` predicates
- **DelegationManager** — lifecycle: delegate, revoke (cascade), renew (heartbeat), consume (usage/budget)
- **DelegationEvaluator** — runtime scope matching + optional grantor re-check
- **Bounds** — `max_uses` / `budget` / `lease_ttl` + `expires_at`; CAS-safe decrements

### Wiring Guard with delegation

```python
from open_guard import (
    Guard, InMemoryDelegationStore,
    Delegation, DelegationScope, DelegationStatus,
    ActorType, Subject, Action, Resource,
)
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.evaluators.rbac import RBACEvaluator

ds = InMemoryDelegationStore()
guard = Guard(
    policy_store=InMemoryPolicyStore(),
    evaluators=[RBACEvaluator()],
    delegation_store=ds,
    default_delegate_policy="self_only",  # callers can only delegate their own perms
)
```

### Delegate + authorize

```python
alice = Subject(id="alice", actor_type=ActorType.USER)
bob   = Subject(id="bob",   actor_type=ActorType.AGENT)

scope = DelegationScope(
    action_match="read",
    resource_type="document",
    resource_match={"id": {"op": "eq", "value": "doc-42"}},
)

delegation = guard.delegate(
    caller=alice,
    from_subject=alice,
    to_subject=bob,
    scopes=[scope],
    tenant_id="acme",
    max_uses=10,
)

decision = guard.authorize(
    bob, Action(name="read"), Resource(id="doc-42", resource_type="document"), "acme"
)
assert decision.status.value == "allowed"
assert decision.reason == "delegation"
```

### authorize_and_consume

Combines authorization and usage-counter decrement atomically at the service layer:

```python
decision = guard.authorize_and_consume(
    bob, Action(name="read"), Resource(id="doc-42", resource_type="document"), "acme",
    amount=1,
)
# uses_remaining is now 9
```

### Bounds: budget

```python
from decimal import Decimal

delegation = guard.delegate(
    caller=alice, from_subject=alice, to_subject=bob,
    scopes=[scope], tenant_id="acme",
    budget=Decimal("100.00"),
)
guard.authorize_and_consume(
    bob, Action(name="read"), Resource(id="doc-42", resource_type="document"), "acme",
    cost=Decimal("1.50"),
)
# budget_remaining is now 98.50
```

### Revoke (with cascade)

```python
guard.revoke_delegation(delegation.id, caller=alice, tenant_id="acme")
# All descendant delegations are also set to REVOKED
```

### list_authorized with delegation contribution

Delegations with concrete `id:eq` or `id:in` scopes automatically contribute to `list_authorized` without requiring a `CandidateResourcePort`:

```python
result = guard.list_authorized(bob, "read", "document", "acme", limit=100)
assert "doc-42" in result.ids
```

### MCP + delegation budget

```python
from open_guard.adapters.mcp.guard import MCPGuard

mcp = MCPGuard(guard=guard, resolver=resolver, default_tenant_id="acme")

result = mcp.check_tool_call(
    session_id="sess-1", tool_name="search", params={}, server_id="rag",
    claims={"sub": "bob", "tenant_id": "acme"},
)
if result.status == "allow":
    mcp.consume_tool_call_budget(result, "acme", amount=1, cost=Decimal("0.01"))
# result.attributed_delegation_ids carries the matched delegation IDs
```

### Non-delegable policies

Mark a policy `non_delegable=True` to prevent its permissions from being re-delegated downstream. When `DelegationEvaluator` calls back into `Guard.authorize(_skip_delegation=True)` for a grantor re-check and the grantor's policy is `non_delegable`, the delegation is blocked even if the grantor still holds the permission.

```python
from open_guard import Policy

policy = Policy(
    tenant_id="acme",
    evaluator_type="rbac",
    non_delegable=True,  # grants from this policy cannot be delegated further
)
```

---

## Phase 6 — Production Hardening (v0.7.0)

### Overview

Phase 6 adds three production-hardening primitives to open-guard:

- **RBAC Sessions (ENH-001)** — a `Session` entity narrows a subject's active roles for the lifetime of a request context; expired or deactivated sessions fail-open (full roles apply) so revocation is explicit rather than accidental lockout.
- **Policy Isolation (FEAT-010)** — the policy store becomes read-only during evaluation (via `ReadOnlyPolicyView`) preventing injected code from mutating policies at runtime; attribute-level taint marking (`_trusted`) combined with a `trusted_only` condition modifier lets evaluators reject LLM-generated attribute values.
- **Push Revocation (ENH-010)** — a `RevocationStreamPort` / `InMemoryRevocationStream` lets subscribers (agents, sessions, cache invalidators) react to delegation or session revocations in real-time without polling.

### Wiring Guard with sessions

```python
from open_guard import Guard, Policy, Subject, Action, Resource, RBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.services.session_manager import SessionManager

session_store = InMemorySessionStore()
session_mgr = SessionManager(session_store=session_store)

guard = Guard(
    policy_store=InMemoryPolicyStore(),
    evaluators=[RBACEvaluator()],
    session_store=session_store,
)
```

### Creating a session

A session activates a subset of a subject's assigned roles. The `activated_roles` list must be a subset of the subject's roles.

```python
alice = Subject(id="alice", attributes={"roles": ["admin", "editor"]})

session = session_mgr.create_session(
    subject=alice,
    tenant_id="acme",
    activated_roles=["editor"],  # subset of alice's roles
)

from open_guard.domain.entities import SessionStatus
assert session.status == SessionStatus.ACTIVE
assert "editor" in session.activated_roles
assert "admin" not in session.activated_roles
```

### Authorize with session_id

Pass `session_id` to `guard.authorize()` to scope evaluation to the session's activated roles. Actions requiring roles outside the activated set are denied.

```python
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard import Policy

store = InMemoryPolicyStore()
store.add(Policy(
    tenant_id="acme", evaluator_type="rbac",
    subject_match={"roles": ["admin"]},
    action_match="delete",
    resource_match={"type": "doc"},
))
store.add(Policy(
    tenant_id="acme", evaluator_type="rbac",
    subject_match={"roles": ["editor"]},
    action_match="write",
    resource_match={"type": "doc"},
))

guard = Guard(
    policy_store=store,
    evaluators=[RBACEvaluator()],
    session_store=session_store,
)

# Alice has admin+editor roles, but session only activates editor
doc = Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"})

write_ok = guard.authorize(alice, Action(name="write"), doc, "acme",
                           session_id=session.id)
assert write_ok.allowed is True   # editor role is in session

delete_ok = guard.authorize(alice, Action(name="delete"), doc, "acme",
                            session_id=session.id)
assert delete_ok.allowed is False  # admin role is NOT in session
```

### session.* ABAC namespace

The `session.*` path namespace in ABAC conditions lets policies inspect the active session. Metadata keys surface directly as `session.<key>`.

```python
from open_guard import ABACEvaluator

store = InMemoryPolicyStore()
store.add(Policy(
    tenant_id="acme", evaluator_type="abac",
    action_match="promote",
    conditions={
        "session.activated_roles": {"op": "contains", "value": "editor"},
    },
))

guard = Guard(
    policy_store=store,
    evaluators=[ABACEvaluator()],
    session_store=session_store,
)

session_with_editor = session_mgr.create_session(
    subject=alice, tenant_id="acme", activated_roles=["editor"],
)
decision = guard.authorize(
    alice, Action(name="promote"),
    Resource(id="k1", resource_type="knowledge"),
    "acme",
    session_id=session_with_editor.id,
)
assert decision.allowed is True

# Session without editor role → condition fails
session_viewer_only = session_mgr.create_session(
    subject=Subject(id="bob", attributes={"roles": ["viewer"]}),
    tenant_id="acme",
    activated_roles=["viewer"],
)
decision2 = guard.authorize(
    Subject(id="bob", attributes={"roles": ["viewer"]}),
    Action(name="promote"),
    Resource(id="k2", resource_type="knowledge"),
    "acme",
    session_id=session_viewer_only.id,
)
assert decision2.allowed is False
```

### Taint marking for LLM-generated attributes

Inject `_trusted: {field: False}` into `subject` or `resource` attributes to mark fields as untrusted (e.g. values filled in by an LLM). Policies with `"trusted_only": True` on a condition skip evaluation when the matched attribute is untrusted, preventing privilege escalation via injected values.

```python
store = InMemoryPolicyStore()
store.add(Policy(
    tenant_id="acme", evaluator_type="abac",
    action_match="read",
    conditions={
        "resource.classification": {
            "op": "eq", "value": "public",
            "trusted_only": True,   # reject untrusted attribute values
        },
    },
))
guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

# LLM claims classification=public, but we mark it untrusted
llm_resource = Resource(
    id="secret-doc", resource_type="doc",
    attributes={
        "classification": "public",          # LLM-generated
        "_trusted": {"classification": False},  # taint marker
    },
)
decision = guard.authorize(
    Subject(id="agent-1", attributes={}),
    Action(name="read"),
    llm_resource,
    "acme",
)
assert decision.allowed is False  # trusted_only skipped the condition → deny

# Trusted resource (no taint marker) → passes
trusted_resource = Resource(
    id="pub-doc", resource_type="doc",
    attributes={"classification": "public"},
)
decision2 = guard.authorize(
    Subject(id="agent-1", attributes={}),
    Action(name="read"),
    trusted_resource,
    "acme",
)
assert decision2.allowed is True
```

### Setting up push revocation

Wire an `InMemoryRevocationStream` to receive real-time events when sessions are deactivated or delegations are revoked.

```python
from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.domain.entities import RevocationEvent, RevocationEventType

stream = InMemoryRevocationStream()
received: list[RevocationEvent] = []
stream.subscribe("acme", received.append)

session_store2 = InMemorySessionStore()
session_mgr2 = SessionManager(
    session_store=session_store2,
    revocation_stream=stream,
)

alice2 = Subject(id="alice", attributes={"roles": ["admin"]})
sess = session_mgr2.create_session(
    subject=alice2, tenant_id="acme", activated_roles=["admin"],
)
session_mgr2.deactivate(sess.id, "acme")

assert len(received) == 1
assert received[0].event_type == RevocationEventType.SESSION_DEACTIVATED
assert received[0].session_id == sess.id
```

### Agent re-check pattern

Subscribers can trigger immediate re-authorization when a revocation event arrives — the agent's cached decision becomes invalid as soon as the event fires.

```python
recheck_results: list[bool] = []

def on_revocation(event: RevocationEvent) -> None:
    # Re-authorize without delegation — expect DENY
    recheck = guard_with_delegation.authorize(
        agent_subject,
        Action(name="read"),
        Resource(id="doc-42", resource_type="document"),
        "acme",
    )
    recheck_results.append(recheck.allowed)

from open_guard import InMemoryDelegationStore, ActorType
from open_guard.domain.entities import DelegationScope

delegation_store = InMemoryDelegationStore()
revocation_stream2 = InMemoryRevocationStream()
revocation_stream2.subscribe("acme", on_revocation)

policy_store2 = InMemoryPolicyStore()
policy_store2.add(Policy(
    tenant_id="acme", evaluator_type="rbac",
    subject_match={"roles": ["admin"]},
    action_match="read",
    resource_match={},
))

guard_with_delegation = Guard(
    policy_store=policy_store2,
    evaluators=[RBACEvaluator()],
    delegation_store=delegation_store,
    revocation_stream=revocation_stream2,
)

admin_subject = Subject(id="admin-1", attributes={"roles": ["admin"]},
                        actor_type=ActorType.USER)
agent_subject = Subject(id="agent-1", attributes={"roles": []},
                        actor_type=ActorType.AGENT)

delegation = guard_with_delegation.delegate(
    caller=admin_subject,
    from_subject=admin_subject,
    to_subject=agent_subject,
    scopes=[DelegationScope(action_match="read", resource_type="document")],
    tenant_id="acme",
    re_check_on_use=False,
)

# Before revoke: agent has access via delegation
before = guard_with_delegation.authorize(
    agent_subject, Action(name="read"),
    Resource(id="doc-42", resource_type="document"),
    "acme",
)
assert before.allowed is True

# Revoke → subscriber fires → re-check → DENY
guard_with_delegation.revoke_delegation(delegation.id, caller=admin_subject,
                                        tenant_id="acme")
assert len(recheck_results) >= 1
assert recheck_results[0] is False
```

---

## Phase 7 — Consumer Integration (v0.8.0)

### Overview

Phase 7 adds zero-config wiring, an async entry point, an in-process admin SDK, a REST admin surface, and database schema tooling — everything a consumer needs to go from `pip install` to production without reading internal source.

### 7.1 Guard Factory — Zero-Config Setup

```python
from open_guard import Guard

# Memory (tests, development)
guard = Guard.from_config(backend="memory")

# SQLite (edge, single-node)
guard = Guard.from_config("sqlite:///local.db")

# PostgreSQL (production)
guard = Guard.from_config("postgresql://user:pass@host/db")
```

The factory wires evaluators, stores, and delegation support automatically based on the backend.

### 7.2 AsyncGuard — Native Async

```python
from open_guard import AsyncGuard

guard = await AsyncGuard.from_config(backend="memory")
decision = await guard.authorize(subject, action, resource, tenant_id="t1")
```

`AsyncGuard` mirrors the synchronous `Guard` API with `async def`. All store ports have async counterparts (`AsyncPolicyStorePort`, `AsyncRelationshipStorePort`, etc.) that the factory wires automatically.

### 7.3 PolicyAdmin SDK

```python
from open_guard import Guard, PolicyAdmin

guard = Guard.from_config(backend="memory")
admin = PolicyAdmin(guard)

# Create policy
admin.create_policy(tenant_id="t1", evaluator_type="rbac",
                    subject_match={"roles": ["editor"]}, action_match="write")

# Assign role
admin.assign_role(tenant_id="t1", subject_id="alice", role="editor")

# Add relationship
admin.add_relationship(tenant_id="t1", subject_id="alice", subject_type="user",
                       relation="member", object_type="project", object_id="p1")
```

`PolicyAdmin` also exposes `list_policies`, `delete_policy`, `revoke_role`, `create_delegation`, `revoke_delegation`, `create_session`, `deactivate_session`, and more — see the class docstring for the full surface.

### 7.4 Admin REST API

```python
from fastapi import FastAPI
from open_guard import Guard, PolicyAdmin
from open_guard.api.fastapi import AdminRouter

guard = Guard.from_config(backend="memory")
admin = PolicyAdmin(guard)

app = FastAPI()
app.include_router(AdminRouter(admin=admin), prefix="/admin")
# Routes: POST/GET/DELETE /admin/policies, /admin/roles, etc.
```

The router exposes CRUD endpoints for policies, roles, relationships, delegations, and sessions, plus a `/admin/health` endpoint.

### 7.5 Database Schema Tooling

```python
from sqlalchemy import create_engine
from open_guard.db import create_all_tables, get_ddl

# Create tables
engine = create_engine("sqlite:///local.db")
create_all_tables(engine)

# Export DDL
ddl = get_ddl(dialect="postgresql")
```

```bash
# CLI
open-guard db init --dsn "sqlite:///local.db"
open-guard db schema --dialect postgresql
```

---

## Phase 9 — Production Integration (v0.10.0)

### Overview

Phase 9 closes four production-readiness gaps for any open-guard consumer:

- **FEAT-016** — `build_async_guard()` now accepts SQL DSNs, wiring all 6 async SQL stores
- **FEAT-017** — Resource-scoped role assignment via `resource_match` on `assign_role` / `revoke_role`
- **ENH-020** — Public `sync_store` property on async in-memory stores (no more `._sync`)
- **ENH-021** — `check_relationship()` query API on `PolicyAdmin` + `AdminRouter`

Zero breaking changes.

### 9.1 Async SQL Backend (FEAT-016)

```python
from open_guard.adapters.factory import build_async_guard

# SQLite (testing/local)
guard = build_async_guard(dsn="sqlite+aiosqlite:///./og.db")

# PostgreSQL (production)
guard = build_async_guard(dsn="postgresql+asyncpg://user:pass@host/db")

decision = await guard.authorize(request)
```

The factory auto-creates all tables (`create_all_tables` for both async and a peer sync engine — TBACEvaluator stays sync). Memory backend remains the default when no DSN is provided.

### 9.2 Resource-Scoped Roles (FEAT-017)

```python
from open_guard.adapters.admin import PolicyAdmin

admin = PolicyAdmin(guard, tenant_id="t1")

# Assign a role scoped to a specific resource attribute
admin.assign_role(
    subject_id="alice",
    role="editor",
    resource_type="document",
    resource_match={"department": "engineering"},
)

# Different scope, same actor + role
admin.assign_role(
    subject_id="alice",
    role="viewer",
    resource_type="document",
    resource_match={"department": "support"},
)

# Revoke one scope; the other survives
admin.revoke_role(
    subject_id="alice",
    role="editor",
    resource_type="document",
    resource_match={"department": "engineering"},
)
```

The consumer defines what `resource_match` keys mean — open-guard stays vendor-neutral. Common patterns: `{"department": "..."}`, `{"region": "..."}`, `{"workspace_id": "..."}`, `{"project_id": "..."}`.

### 9.3 Public sync_store Accessor (ENH-020)

```python
from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore

async_store = AsyncInMemoryPolicyStore()
sync_store = async_store.sync_store  # typed: InMemoryPolicyStore

# Share state between AsyncGuard and sync Guard / PolicyAdmin
admin = PolicyAdmin(sync_guard_using(sync_store), tenant_id="t1")
```

All 6 async in-memory stores (`AsyncInMemory{Policy,Relationship,Task,Approval,Delegation,Session}Store`) expose `.sync_store`.

### 9.4 Relationship Query API (ENH-021)

```python
admin.add_relationship(
    object_type="group", object_id="devs",
    relation="member",
    subject_type="user", subject_id="alice",
)

is_member = admin.check_relationship(
    subject_type="user", subject_id="alice",
    relation="member",
    object_type="group", object_id="devs",
)
# True
```

Standard membership patterns work directly: group membership, team membership, org hierarchy, ownership. Tenant-scoped, no policy round-trip. Exposed as `POST /relationships/check` on `AdminRouter`.

---

## Phase 10 — Over the wire (Service + SDK) (v0.11.0)

Phase 10 lets non-Python consumers (and Python ones that prefer
out-of-process deployment) talk to open-guard over HTTP. The same
`Guard` / `AsyncGuard` you build in-process now mounts behind a
FastAPI app via `create_app(...)`; a typed Python SDK
(`open_guard.client`) calls it.

**When to use embedded vs service mode:**

| Use embedded (`Guard` directly) when... | Use service mode when... |
|---|---|
| Your consumer is Python and co-deployed | Your consumer is non-Python or out-of-process |
| Authorization latency budget is microseconds | Latency budget tolerates a network hop |
| One process owns the policy store | Multiple processes / replicas share state |
| You want zero deployment surface | You want one authorization service per environment |

### Install

```bash
# server-only
pip install open-guard[service,sql-async]

# server + open-shield JWT auth
pip install open-guard[service,sql-async,shield]

# client-only (no FastAPI dep pulled)
pip install open-guard[client]

# both, e.g. for local dev
pip install open-guard[service,client,sql-async]
```

### Quickstart — service

```python
from open_guard import build_guard, PolicyAdmin
from open_guard.service.app import create_app, ServiceConfig
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)

# 1. wire a Guard exactly as before (or build_async_guard for async)
guard = build_guard()
admin = PolicyAdmin(guard)

# 2. register at least one API key
import asyncio
store = InMemoryApiKeyStore()
cleartext, digest = ApiKeyAuth.generate()
asyncio.run(
    store.add(
        ApiKeyRecord(
            key_hash=digest,
            tenant_id="t1",
            service_identity="svc-cerebrio",
        )
    )
)
print("API key (show once):", cleartext)

# 3. build the FastAPI app
app = create_app(
    guard=guard,
    admin=admin,
    auth=ApiKeyAuth(store),
    config=ServiceConfig(prefix="/v1"),  # default
)

# 4. run it
# uvicorn open_guard.service.app:create_app --factory ...
```

### Quickstart — Python SDK

```python
from open_guard.client import OpenGuardClient, ApiKey

with OpenGuardClient(
    "https://authz.example.com",
    auth=ApiKey("og_..."),
) as client:
    decision = client.decisions.authorize(
        subject={"id": "alice", "actor_type": "user"},
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    if decision["allowed"]:
        ...
```

Async equivalent:

```python
from open_guard.client import AsyncOpenGuardClient, ApiKey

async with AsyncOpenGuardClient("https://authz.example.com", auth=ApiKey("og_...")) as client:
    decision = await client.decisions.authorize(...)
```

### Auth modes

| Mode | Header | Backend | Install |
|------|--------|---------|---------|
| API key | `Authorization: ApiKey <k>` | `ApiKeyAuth(ApiKeyStorePort)` | built-in |
| JWT (open-shield) | `Authorization: Bearer <jwt>` | `ShieldAuth(TokenValidatorPort)` | `[shield]` |
| BYO | any | `CallableAuth(Callable[[Request], Awaitable[CallerContext]])` | escape hatch |

API keys are SHA-256 hashed before storage; cleartext is shown once at
generation time. ShieldAuth wraps an open-shield validator and
extracts tenant + identity + scopes from JWT claims.

### Tenancy model

The caller's `tenant_id` is sourced from the auth claim — never the
request body. To allow ops tooling to act across tenants, scope the
caller with `cross_tenant_admin` and send `X-Tenant-ID: <other-tenant>`
on the request:

```python
ApiKeyRecord(
    key_hash=digest,
    tenant_id="ops",
    service_identity="ops-tooling",
    scopes=["cross_tenant_admin"],
)
```

Without that scope, an `X-Tenant-ID` mismatch returns 403
`cross_tenant_forbidden`.

### Error envelope

All non-2xx responses share a single shape:

```json
{
  "error": {
    "code": "missing_api_key",
    "message": "missing API key",
    "details": null
  }
}
```

The Python SDK maps these to typed exceptions (`AuthenticationError`,
`AuthorizationServiceError`, `NotFoundError`, `ValidationError`,
`RateLimitedError`, `ServerError`, `TransportError`) that all carry
the original `.code` for stable branching.

### Idempotency note for `authorize_and_consume`

`authorize_and_consume` decrements delegation budget on the server.
The default `RetryPolicy` skips retries for non-idempotent operations,
so a 5xx surfaces as `ServerError` on the first attempt rather than
risking double-decrement. Other endpoints retry transient 502/503/504
+ connection errors with exponential backoff (3 attempts, 100ms → 2s).

### Endpoint reference

| Method | Path | Maps to |
|--------|------|---------|
| `POST` | `/v1/authorize` | `Guard.authorize` / `AsyncGuard.authorize` |
| `POST` | `/v1/authorize/traced` | `Guard.authorize_traced` / `AsyncGuard.authorize_traced` |
| `POST` | `/v1/list_authorized` | `Guard.list_authorized` (sync only) |
| `POST` | `/v1/authorize_and_consume` | `Guard.authorize_and_consume` (sync only) |
| `POST/GET/DELETE` | `/v1/admin/...` | `PolicyAdmin.*` (Phase 7 surface) |

When mounted with an `AsyncGuard`, only the first two register;
`list_authorized` and `authorize_and_consume` are sync-only because
they depend on the sync delegation evaluator.

### Reference container

A reference Dockerfile and entrypoint live under `deploy/service/`.
No image is published — copy and customize for your platform.

### Migrating from embedded to service

Phase 10 is purely additive. Embedded `Guard` / `AsyncGuard` /
`PolicyAdmin` / `AdminRouter` continue to work unchanged. Migrate
one consumer at a time by swapping the embedded `Guard` for an
`OpenGuardClient` pointed at your deployed service — the public
surface (`decisions.authorize`, `admin.policies.create`, etc.)
mirrors the in-process API.

### See also

- ADR-0009 — service mode wire contract
- ADR-0010 — Python SDK shape
- `tests/integration/test_integration_guide_phase10_examples.py` —
  these snippets as executable tests
- `tests/e2e/test_service_client_e2e.py` — round-trip SDK ↔ service
- `tests/e2e/test_service_sql_e2e.py` — same with the async SQL backend
- `deploy/service/README.md` — Dockerfile + ops notes

---

## Phase 11 — Async Parity (v0.12.0)

### Overview

Phase 11 closes the remaining async-parity gaps. Before v0.12.0,
`AsyncGuard` was missing `list_authorized`, delegation fallback,
`authorize_and_consume`, approval gating, and `approve` / `reject`.
Consumers running async SQL stores (`postgresql+asyncpg://`,
`sqlite+aiosqlite://`) had to threadpool-wrap a sync `Guard` for those
paths.

v0.12.0 ships the async siblings of every sync primitive, with the
mirror-not-redesign rule from **ADR-0012** — same signatures, same
return shapes, same idempotency hashing, same error semantics. The
sync surface is the contract; the async surface inherits it.

**Industry alignment (vendor-neutral)** — open-guard's async surface
lands on the same shape as the rest of the field:

| Primitive | Industry reference |
|-----------|--------------------|
| `AsyncGuard.list_authorized` | OpenFGA `ListObjects` · Zanzibar / SpiceDB `LookupResources` · AWS Verified Permissions `BatchIsAuthorized` · Auth0 FGA `listObjects` · Cerbos `PlanResources` · Casbin `getImplicitResourcesForUser` |
| `AsyncDelegationEvaluator` | NIST RBAC delegation (Sandhu et al.) · Vault / etcd lease-bound capability passing · capability-based security |
| `AsyncApprovalManager` | XACML Obligations · OAuth 2.0 Rich Authorization Requests (RFC 9396) · NIST SP 800-162 approval workflows |

### 11.1 `AsyncGuard.list_authorized` (FEAT-018)

```python
from open_guard.domain.services.async_guard import AsyncGuard
from open_guard.domain.entities import Policy, Subject

guard = await AsyncGuard.from_config(backend="memory")
await guard.policy_store.add(
    Policy(
        tenant_id="t1",
        evaluator_type="rbac",
        subject_match={"roles": ["reader"]},
        action_match="read",
        resource_match={"type": "doc"},
    )
)
result = await guard.list_authorized(
    Subject(id="alice", attributes={"roles": ["reader"]}),
    "read",
    "doc",
    tenant_id="t1",
)
# result.ids — same ListResult entity sync uses; cursor pagination via
# result.next_cursor passed back as `cursor=...` on the next call.
```

Sequential per-candidate evaluation — see **ADR-0011**. Bounded
concurrency is deliberately not exposed; sync semantics set the bar.

### 11.2 Delegation fallback + `authorize_and_consume` (FEAT-014)

```python
from open_guard.domain.entities import (
    Action, ActorType, DelegationScope, Resource, Subject,
)

alice = Subject(id="alice", actor_type=ActorType.USER,
                attributes={"roles": ["owner"]})
bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})

# Alice has read access via policy; bob does not. Alice delegates to bob.
await guard.delegate(
    caller=alice,
    from_subject=alice,
    to_subject=bob,
    scopes=[DelegationScope(action_match="read", resource_type="doc")],
    tenant_id="t1",
    max_uses=10,
    re_check_on_use=False,
)

# Bob's authorize is denied by the policy router but allowed via
# delegation fallback. Same fallback wiring as sync Guard.authorize.
decision = await guard.authorize_and_consume(
    bob, Action(name="read"),
    Resource(id="doc-1", resource_type="doc"),
    "t1",
)
# decision.status == ALLOWED; one usage consumed CAS-safely.
```

`AsyncGuard.delegate / revoke_delegation / renew_delegation /
consume_delegation` proxy through `AsyncDelegationManager`. Cascade
revocation, lease renewal, and chain-depth enforcement all match sync.

### 11.3 Approval gating + `approve` / `reject` (FEAT-015)

```python
from open_guard.domain.entities import ApprovalRequirement, Policy

await guard.policy_store.add(
    Policy(
        tenant_id="t1",
        evaluator_type="rbac",
        subject_match={"roles": ["editor"]},
        action_match="write",
        requires_approval=ApprovalRequirement(
            approvers=["manager-1"], quorum="any",
        ),
    )
)

# First authorize returns PENDING_APPROVAL with an approval_request_id
pending = await guard.authorize(
    Subject(id="alice", attributes={"roles": ["editor"]}),
    Action(name="write"),
    Resource(id="doc-1", resource_type="document"),
    "t1",
)
assert pending.approval_request_id is not None

# Resolve out-of-band
await guard.approve(
    pending.approval_request_id, "t1", "manager-1", "looks fine",
)

# Next authorize honors the historical APPROVED record
decision = await guard.authorize(
    Subject(id="alice", attributes={"roles": ["editor"]}),
    Action(name="write"),
    Resource(id="doc-1", resource_type="document"),
    "t1",
)
# decision.status == ALLOWED
```

SHA-256 idempotency hashing reused from sync. A pending request created
by sync `Guard` and one created by `AsyncGuard` for the same `(tenant,
subject, action, resource)` collide deterministically — mixed
deployments are safe.

### 11.4 Service mode — engine-agnostic decision endpoints

```python
from open_guard.service import create_app

# Same create_app() factory whether the embedded guard is sync or async.
app = create_app(guard=guard, auth=auth)
# POST /v1/authorize             — both engines
# POST /v1/authorize/traced      — both engines
# POST /v1/list_authorized       — both engines (NEW in v0.12.0 for async)
# POST /v1/authorize_and_consume — both engines (NEW in v0.12.0 for async)
```

`SERVICE_API_VERSION` stays `"v1"`. No schema changes; no new endpoints;
the wire contract is unchanged.

### See also

- ADR-0011 — `AsyncGuard.list_authorized` concurrency model (sequential)
- ADR-0012 — Async parity composition (mirror, don't redesign)
- `tests/integration/test_integration_guide_phase11_examples.py` —
  these snippets as executable tests
- `tests/unit/test_async_list_authorized.py` — parity matrix vs sync
- `tests/unit/test_async_delegation.py` — delegation fallback + cascade + CAS
- `tests/unit/test_async_approval.py` — approval gating + idempotency + TTL

---

## Composition rules (important)

Open-guard combines evaluator results with **fail-closed AND** semantics:
- If ANY registered evaluator denies (or fails to match), the combined decision is DENY.
- If ALL participating evaluators allow at least one policy, the decision is ALLOW.
- Evaluators without any matching policies for the request (via `evaluator.supports()`) are skipped.

Practical implication for `list_authorized`: if your Guard has both ABAC and ReBAC evaluators, your ABAC policy set must include an ALLOW policy (even if it's broad) — otherwise ABAC's "no matching allow" result counts as a deny and nothing makes it through.

---

## References

- `specs/architecture/auth-model.md` — full model specification
- `specs/backlog/details/FEAT-006.md` — `list_authorized` design doc
- `specs/backlog/details/FEAT-009.md` — MCP adapter design doc
- `specs/decisions/0001-list-authorized-composition.md` — composition ADR
- `specs/decisions/0002-mcp-adapter-design.md` — MCP adapter ADR
- `specs/decisions/0003-delegation-entity-and-api-shape.md` — delegation entity ADR
- `specs/decisions/0004-delegation-evaluator-and-meta-authz.md` — evaluator + meta-authz ADR
- `specs/decisions/0005-delegation-bounds-usage-budget-lease.md` — bounds (usage/budget/lease) ADR
- `tests/integration/test_list_authorized.py` — runnable list flows
- `tests/integration/test_mcp_adapter.py` — runnable MCP flows
- `tests/integration/test_delegation_e2e.py` — delegation lifecycle flows
- `tests/integration/test_delegation_cascade.py` — cascade revoke + non-delegable flows
- `tests/integration/test_delegation_mcp.py` — MCP + delegation budget flows
- `tests/integration/test_integration_guide_examples.py` — this guide's snippets as executable tests
- `specs/decisions/0006-rbac-sessions.md` — RBAC sessions ADR
- `specs/decisions/0007-policy-isolation.md` — policy isolation (ReadOnlyPolicyView + taint) ADR
- `specs/decisions/0008-push-revocation.md` — push revocation stream ADR
- `tests/integration/test_session_integration.py` — session lifecycle flows
- `tests/integration/test_revocation_integration.py` — push revocation flows
- `tests/integration/test_prompt_injection.py` — taint marking + adversarial scenarios
- `tests/integration/test_integration_guide_phase6_examples.py` — Phase 6 guide snippets as executable tests
- `tests/integration/test_integration_guide_phase7_examples.py` — Phase 7 guide snippets as executable tests
- `specs/decisions/0009-service-mode-wire-contract.md` — service-mode wire contract ADR
- `specs/decisions/0010-python-sdk-shape.md` — Python SDK shape ADR
- `tests/integration/test_integration_guide_phase10_examples.py` — Phase 10 guide snippets as executable tests
- `specs/decisions/0011-async-list-authorized-concurrency.md` — async list_authorized concurrency ADR
- `specs/decisions/0012-async-parity-composition.md` — async-parity composition ADR
- `tests/integration/test_integration_guide_phase11_examples.py` — Phase 11 guide snippets as executable tests
- `tests/unit/test_async_list_authorized.py` — AsyncGuard.list_authorized parity matrix
- `tests/unit/test_async_delegation.py` — AsyncDelegationEvaluator + fallback + cascade tests
- `tests/unit/test_async_approval.py` — AsyncApprovalManager + approval gating tests
