---
id: "0012"
title: "Async parity composition: mirror sync surfaces; do not redesign"
status: accepted
date: 2026-05-18
---

# ADR-0012: Async Parity Composition — Mirror, Don't Redesign

## Status

`accepted` (Phase 11, v0.12.0)

## Context

Phase 11 bundled three async-parity gaps into one minor release:

- **FEAT-018** — `AsyncGuard.list_authorized`
- **FEAT-014** — `AsyncDelegationEvaluator`, `AsyncDelegationManager`,
  `AsyncGuard.delegate` / `revoke_delegation` / `renew_delegation` /
  `consume_delegation` / `authorize_and_consume`, delegation fallback
  in `AsyncGuard.authorize`
- **FEAT-015** — `AsyncApprovalManager`, approval gating in
  `AsyncGuard.authorize` and `AsyncGuard.authorize_traced`,
  `AsyncGuard.approve` / `reject`

Each gap could have been an opportunity to re-examine the sync surface
that the async sibling was being modeled on. Approval semantics,
delegation manager shape, list_authorized cursor layout — none of them
are perfect. We could have introduced renamed parameters, structured
return types, new fluent builders, or a different idempotency hash on
the async side.

We didn't. This ADR captures why.

## Decision

For Phase 11, async siblings **mirror** sync siblings exactly. Concretely:

1. **Method signatures match.** Same positional/keyword argument names,
   same defaults, same return types. The only difference is `async def`
   in place of `def` and `await` where the sync version blocks. This
   includes internal kwargs like `_skip_delegation` and `_recheck_cache`
   used by `AsyncDelegationEvaluator` re-check.
2. **Return shapes match.** `AsyncGuard.list_authorized` returns
   `ListResult` — the same entity sync returns. `AsyncApprovalManager.
   request_or_existing` returns `ApprovalRequest` — the same.
   `AsyncDelegationEvaluator.evaluate` returns `DelegationDecision` —
   the same dataclass.
3. **Idempotency rules match.** `ApprovalRequest.make_hash` is the
   single canonical SHA-256 helper used by both sync and async paths.
   The async manager imports it; it does not re-implement.
4. **Pure helpers are shared, not re-implemented.** Module-level
   functions in the sync modules (e.g.
   `_scopes_match`, `_extract_concrete_ids` in
   `delegation_evaluator.py`; `_approver_allowed`, `_quorum_met` in
   `approval_manager.py`) are imported by their async counterparts. If
   a helper was class-private on the sync side and could not be
   imported, it is promoted to module-level before being shared — it
   is never re-implemented async-side.
5. **Error semantics match.** Same exception types (`ApprovalError`,
   `DelegateNotPermittedError`, `DelegationChainDepthExceededError`,
   `LeaseExpiredError`, `UsageExhaustedError`, `ChainDepthExceededError`)
   raised in the same conditions.
6. **Cursor format matches.** `AsyncGuard.list_authorized` uses
   `Cursor.encode` / `Cursor.decode` unchanged. No async-only cursor.
7. **Wire contract is engine-agnostic.** The service-mode endpoints
   `/v1/list_authorized` and `/v1/authorize_and_consume` register the
   same way whether the embedded guard is sync or async. No new
   endpoints, no new schemas, `SERVICE_API_VERSION` stays `"v1"`.

## Consequences

### Why this matters

- **Documentation works.** Anyone reading the sync `Guard` reference
  documentation can substitute `await guard.method(...)` and have the
  code work. We don't maintain two parallel narrative documents.
- **Test coverage works.** Sync test patterns transfer directly to
  async tests with `@pytest.mark.asyncio` and `await`. The Phase 11
  test suites (`test_async_list_authorized.py`,
  `test_async_delegation.py`, `test_async_approval.py`) follow the
  sync test files almost line for line.
- **Bug fixes apply once.** A semantic correction to sync auto-applies
  to async because they share helpers and entity shapes; a fix to
  shared helpers fixes both. The opposite — having to remember to
  patch the async path separately — has been the source of subtle
  bugs in other codebases that took the redesign path.
- **Cross-API hash collisions are deterministic.** A sync-created
  pending approval and an async-created request for the same
  `(tenant, subject, action, resource)` share `request_hash` and
  collide deterministically. Mixed deployments work.

### What this rules out, going forward

- An async-only API improvement (e.g. a new `AsyncGuard.approve_many`)
  is **not** introduced before the same shape lands on sync. Either
  both surfaces evolve together, or neither does.
- An "async is the future, sync will catch up later" argument is
  rejected. Sync is not a deprecation target; both surfaces are
  first-class.
- Async-only error types, async-only return shapes, async-only kwargs
  are explicitly out of bounds for Phase 11. A future ADR may amend
  this, but it would need to overturn the parity rule.

### Trade-offs accepted

- **Latency**: the async path can sometimes "feel" slower than a
  hypothetically redesigned async-native API would. For `list_authorized`
  this is locked in by ADR-0011 (sequential per-candidate evaluation).
- **No async-only optimizations** without first profiling and surfacing
  the same opportunity to sync — even when the optimization technically
  only applies to async (e.g. `gather`-based concurrency would be
  inert for sync, but the *concept* would still need sync sign-off).

### Rejected alternatives

| Option | Why rejected |
|--------|--------------|
| Redesign `list_authorized` for async (new cursor, structured pagination response) | No empirical pressure; would diverge the docs; would create migration cost for any existing sync consumer |
| Different idempotency hash for async approval requests | Mixed-engine deployments would silently fail to deduplicate — a quiet correctness bug, not a performance question |
| Async-only `AsyncDelegationEvaluator` with a different `EvaluationResult` shape | Sync and async results flow through the same `Guard.authorize` / `AsyncGuard.authorize` evaluation chain; divergent shapes would require a per-path adapter |

## References

- ADR-0001 — `list_authorized` composition strategy (sync)
- ADR-0011 — `AsyncGuard.list_authorized` concurrency model (Phase 11)
- Phase 11 `overview.md` Decision #5 — "Mirror sync signatures and
  semantics exactly"
- `src/open_guard/domain/services/async_*.py` — sibling modules
  demonstrating the parity-by-construction pattern
- Phase 11 `history.md` — bundling and parity decisions captured
  alongside this ADR
