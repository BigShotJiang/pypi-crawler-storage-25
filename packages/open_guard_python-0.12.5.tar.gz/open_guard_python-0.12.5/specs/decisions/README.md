# Decision Records

> Captures significant decisions and their rationale.

| ID | Title | Status | Date |
|----|-------|--------|------|
| [0000](0000-template.md) | ADR Template | template | — |

## Creating a New ADR

1. Copy `0000-template.md` to `NNNN-short-title.md`
2. Fill in Context, Decision, Alternatives, Consequences
3. Add a row to the table above
4. Commit: `git commit -m "docs(adr): NNNN — <title>"`
