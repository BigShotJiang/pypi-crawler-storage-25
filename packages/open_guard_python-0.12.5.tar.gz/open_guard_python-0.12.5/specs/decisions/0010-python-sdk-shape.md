---
id: "0010"
title: "Python SDK shape: sync + async clients with namespaced API and idempotent retry"
status: accepted
date: 2026-05-04
---

# ADR-0010: Python SDK Shape — Sync + Async, Namespaced, Idempotent-Retry

## Status

`accepted` (Phase 10, v0.11.0)

## Context

ADR-0009 settles the wire contract. This ADR settles the Python SDK
shape — the surface every Python consumer uses to call open-guard
over HTTP.

Three shape decisions had to be made before code:

1. **Sync vs async** — both, one, neither?
2. **Flat vs namespaced API** — `client.authorize(...)` or
   `client.decisions.authorize(...)`?
3. **Retry semantics** — what to retry, when, how?

## Decision

### Sync and async, sharing a `_BaseClient`

The library already exposes both `Guard` (sync) and `AsyncGuard`
(async). The SDK preserves that choice:

- `OpenGuardClient` — sync, backed by `httpx.Client`, supports
  context manager (`with OpenGuardClient(...) as c:`).
- `AsyncOpenGuardClient` — async, backed by `httpx.AsyncClient`,
  supports async context manager (`async with ...`).

Both inherit a shared `_BaseClient` that owns URL construction,
default headers, error mapping, and retry policy. The sync and async
clients each implement the request loop in their respective styles
(`time.sleep` vs `asyncio.sleep`); body shaping and namespace
delegation are shared.

Result: ~1.5x the code of a single-flavor SDK, not 2x. Forcing
consumers to bridge sync→async or async→sync at every call would be
worse than maintaining two implementations.

### Namespaced API

```python
client.decisions.authorize(...)
client.decisions.authorize_traced(...)
client.decisions.list_authorized(...)
client.decisions.authorize_and_consume(...)

client.admin.policies.create(...)
client.admin.policies.list(...)
client.admin.roles.assign(...)
client.admin.relationships.add(...)
client.admin.relationships.check(...)
client.admin.delegations.create(...)
client.admin.sessions.create(...)
client.admin.health()
```

A flat `client.authorize(...)` would collide once the admin surface
(~20 methods) is exposed. Stripe and AWS SDKs both use this pattern;
it scales cleanly and keeps the namespace explorable. There is no
flat shortcut — `client.authorize` does not exist. (Tested.)

### Credential helpers

```python
from open_guard import ApiKey, BearerToken

OpenGuardClient(url, auth=ApiKey("og_..."))
OpenGuardClient(url, auth=BearerToken("eyJ..."))
```

`ApiKey` and `BearerToken` are factories returning a frozen
`ClientAuth(header_name, header_value)`. Lowercase factory naming
intentionally mimics class instantiation — consumers don't need to
know whether a credential type is a class or a function. This is
the same pattern Pydantic uses for `Field(...)`.

### Retry: 5xx + connection errors, idempotent only by default

```python
RetryPolicy(
    attempts=3,
    base_delay=0.1,         # exponential backoff: 0.1s, 0.2s, 0.4s ...
    max_delay=2.0,          # capped at 2s
    retry_on_status=frozenset({502, 503, 504}),
    retry_on_connection_error=True,
    idempotent_only=True,
)
```

Retries apply to idempotent operations only:

- All decision endpoints **except** `authorize_and_consume`.
- All admin reads (list / get / health).
- Admin creates: idempotent at the SDK layer (the service handles
  duplicate creation as 200 / 201 / 409 deterministically).

`authorize_and_consume` decrements delegation budget on the server.
Retrying a 5xx that may have already executed would double-decrement.
The SDK marks this method `idempotent=False`; with default
`idempotent_only=True` it makes exactly one attempt and surfaces the
5xx as `ServerError`. Consumers who can prove their flow is safe
(e.g., they tag delegations with idempotency keys themselves) can
disable `idempotent_only` per `RetryPolicy` instance.

### Typed exception hierarchy

```
OpenGuardError
├── AuthenticationError      (401)
├── AuthorizationServiceError (403)
├── NotFoundError            (404)
├── ValidationError          (422)
├── RateLimitedError         (429)
├── ServerError              (5xx)
└── TransportError           (httpx connection/timeout failures)
```

Each exception carries `.code` (machine-readable from the envelope),
`.status_code` (HTTP), and `.details` (structured per-error data).
Consumers branch on `.code` for the stable contract; `isinstance`
checks on the typed class for catch-all error categories.

### Optional `http_client` injection

The sync client accepts an optional pre-built `httpx.Client` via
`http_client=...`. This serves two needs:

- Tests use `fastapi.testclient.TestClient` (an `httpx.Client`
  subclass) to exercise the SDK against an in-process ASGI app
  without spinning up a real server.
- Consumers sharing a configured `httpx.Client` (custom timeouts,
  proxies, observability hooks) can hand it to the SDK directly
  rather than reconfigure transport / timeout via the SDK
  constructor.

### Top-level package re-exports

```python
from open_guard import (
    OpenGuardClient,
    AsyncOpenGuardClient,
    ApiKey,
    BearerToken,
    RetryPolicy,
)
```

These names appear at the top level only when `httpx` is installed
(via the `[client]` extra). When `httpx` is absent, the imports
silently no-op so server-only deployments installing
`open-guard[service]` without `[client]` don't fail at import time.

## Consequences

### Positive

- Sync and async consumers each get an idiomatic API.
- Namespacing prevents future surface collisions and keeps the API
  explorable.
- Idempotent-only retry prevents double-charging delegation budgets.
- Typed exceptions surface stable `.code` for branch logic plus
  isinstance-able classes for catch-alls.

### Negative

- Two client implementations to keep in sync. Mitigated by the shared
  `_BaseClient` plus identical method signatures across
  `DecisionsAPI` / `AsyncDecisionsAPI` etc.
- Namespaced calls are slightly more verbose than flat. We consider
  this a feature: the SDK shape is read more often than it's typed.

### Open

- Whether to expose a higher-level `client.authorize(subject, action,
  resource)` shortcut once the namespace is established. Punted to
  Phase 11 — wait for real consumer feedback on what feels
  natural.

## References

- ADR-0009 — Service mode wire contract
- Stripe Python SDK namespacing pattern
- AWS boto3 client / resource namespacing
- httpx retry guidance: https://www.python-httpx.org/
