---
id: "0008"
title: "Push revocation: event-driven stream for delegation, session, and policy invalidation"
status: accepted
date: 2026-04-19
---

# ADR-0008: Push Revocation — Event-Driven Stream for Delegation, Session, and Policy Invalidation

## Status

`accepted` (Phase 6, v0.7.0)

## Context

open-guard's authorization checks are pull-based: each call to `Guard.authorize()` evaluates
the current state of policies, roles, and delegations at that instant. For short-lived request
handlers this is correct and sufficient. For long-running agentic workflows — where a single
agent session may span minutes or hours and issue hundreds of authorization checks — pull-based
checking creates a gap: a delegation or session revoked between two checks is still considered
valid until the next check reaches the revocation. An adversary or operator who revokes access
mid-flight has no way to interrupt a running agent until the agent's next natural check point.

The OpenID Foundation's Continuous Access Evaluation Profile (CAEP) and the broader Shared
Signals Framework (SSF) define a push model for this problem: when an authorization-relevant
event occurs (session revocation, credential change, policy removal), the event is pushed to
all registered subscribers in near-real-time, rather than waiting for the next pull. Google
Zanzibar's watch API offers a similar primitive: callers subscribe to a change feed and are
notified when a tuple affecting a subject changes. HashiCorp Vault's lease revocation model
publishes lease-expiry events so that consumers of short-lived secrets can react immediately.

open-guard needed a minimal revocation stream abstraction that: (1) fits the existing
port/adapter hexagonal architecture, (2) is synchronous and in-process for the common single-
process case, and (3) is extensible to external brokers for distributed deployments.

## Decision

### RevocationStreamPort

`RevocationStreamPort` is a hexagonal port in `domain/ports/revocation_stream.py`:

```python
class RevocationStreamPort(ABC):
    def publish(self, event: RevocationEvent) -> None: ...
    def subscribe(
        self,
        tenant_id: str,
        callback: Callable[[RevocationEvent], None],
        subject_id: str | None = None,
    ) -> str: ...   # returns subscription_id
    def unsubscribe(self, subscription_id: str) -> None: ...
```

The interface is intentionally minimal. `publish()` is fire-and-forget from the caller's
perspective. `subscribe()` returns an opaque `subscription_id` for later cancellation.
`subject_id=None` means "all subjects in this tenant"; a non-None value filters delivery
to events for that specific subject.

### RevocationEvent and event types

```python
class RevocationEventType(StrEnum):
    DELEGATION_REVOKED   = "delegation_revoked"
    DELEGATION_EXPIRED   = "delegation_expired"
    SESSION_DEACTIVATED  = "session_deactivated"
    POLICY_REMOVED       = "policy_removed"

class RevocationEvent(Entity):
    id: str
    event_type: RevocationEventType
    tenant_id: str
    subject_id: str | None
    delegation_id: str | None
    session_id: str | None
    policy_id: str | None
    reason: str
    timestamp: datetime
```

Fields not relevant to the event type are `None`. This keeps the entity flat and avoids
a union-discriminated hierarchy for a small, bounded set of event types.

### InMemoryRevocationStream (default adapter)

`InMemoryRevocationStream` implements the port using an in-process callback registry.
Subscriptions are stored as `(tenant_id, subject_id | None, callback)` tuples keyed by a
UUID subscription ID. On `publish()`, the stream iterates all subscriptions for the event's
`tenant_id`, applies the subject filter, and calls matching callbacks synchronously in
registration order.

**Delivery guarantee: at-most-once, synchronous.**  If a callback raises, the stream logs the
exception and continues delivering to remaining subscribers. There is no persistence, no
message queue, and no retry. This is appropriate for a single-process, in-memory deployment.

Subject filtering: a subscription with `subject_id=None` receives all events for the tenant.
A subscription with `subject_id="alice"` receives events where `event.subject_id == "alice"`
OR `event.subject_id is None` (tenant-wide events such as `POLICY_REMOVED` are broadcast to
all subject-filtered subscriptions in the tenant).

### Event emission by domain services

`SessionManager.deactivate(session_id)` publishes `SESSION_DEACTIVATED` after marking the
session status as `DEACTIVATED`.

`DelegationManager.revoke(delegation_id)` publishes `DELEGATION_REVOKED` for top-level
delegations. Sub-delegations (chains) are revoked recursively by the store; the stream
receives one event per top-level `revoke()` call. Callers that need per-link events must
subscribe and inspect `delegation_id` chains themselves.

### Guard wiring

`Guard.__init__` accepts `revocation_stream: RevocationStreamPort | None = None`. When
provided, it is passed to `DelegationManager` only. `SessionManager` is constructed
independently by the consumer and must receive its own `revocation_stream` reference directly
at construction time — Guard does not wire the stream to `SessionManager`. When `None`, no
events are published and no subscribers are notified — the stream is fully opt-in and backward
compatible.

### Agent re-check pattern

The intended consumer pattern is:

```python
stream.subscribe(
    tenant_id="acme",
    callback=lambda event: agent.invalidate_authorization_cache(event),
    subject_id=agent.subject_id,
)
```

The callback triggers a re-authorization check or cache invalidation in the agent's execution
loop. The agent is responsible for deciding what to do in response (pause, re-check, abort).
The stream does not enforce any response; it only delivers the signal.

### Extension to external brokers

External broker adapters (Kafka, Redis PubSub, AMQP) implement `RevocationStreamPort` as
an infrastructure adapter. `publish()` writes to the broker topic; `subscribe()` registers
a consumer that calls the callback on message receipt. No changes to domain services or
`Guard` are needed. This is the standard hexagonal extension point.

## Consequences

- `InMemoryRevocationStream` is synchronous: a slow or blocking callback will delay delivery
  to subsequent subscribers and delay the return of `DelegationManager.revoke()`. Callbacks
  must be fast (cache invalidation, flag setting) and must not call back into `Guard.authorize()`
  synchronously within the callback (risk of deadlock in the same call stack).
- At-most-once delivery means a subscriber that is unregistered, raises, or is not yet
  registered at the time of publish will miss the event. Callers requiring guaranteed delivery
  must use an external broker adapter with durable subscriptions.
- `POLICY_REMOVED` events are emitted only if the caller explicitly publishes them; the
  `PolicyRouter` (which holds a `ReadOnlyPolicyView`) does not emit events. Policy removal
  events must be published by the administrative layer that writes to the raw `PolicyStorePort`.
- Sub-delegation revocation emits one event per top-level `revoke()` call, not one per chain
  link. Subscribers that need to track chain-level revocation must query the delegation store
  for the full chain after receiving the event.
- `Guard` with `revocation_stream=None` behaves identically to the pre-Phase-6 implementation.
  No existing call sites are affected.
