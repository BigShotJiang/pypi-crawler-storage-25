---
id: "0009"
title: "Service mode wire contract: HTTP-only with versioned /v1 prefix and pluggable auth"
status: accepted
date: 2026-05-04
---

# ADR-0009: Service Mode Wire Contract — HTTP-Only with Versioned /v1 Prefix

## Status

`accepted` (Phase 10, v0.11.0)

## Context

open-guard has shipped exclusively as an embedded Python library. Phase 10
adds out-of-process consumption: any service over HTTP (regardless of
language) can now call `authorize`, `list_authorized`,
`authorize_and_consume`, `authorize_traced`, and the full admin surface.

The brainstorm considered three scopes for Phase 10:

1. **Slim** — HTTP service + Python SDK only (chosen).
2. **Standard** — HTTP + gRPC services + Python SDK.
3. **Full** — HTTP + gRPC + Python/TypeScript/Go SDKs.

We chose Slim. HTTP unblocks 100% of cross-language consumers via plain
HTTP libraries — gRPC adds proto schema, codegen, and streaming
semantics that deserve their own design pass. Validating the wire
contract once with a Python SDK before duplicating it across languages
reduces the cost of iterating. gRPC + TS/Go SDKs land in Phase 11.

The wire-contract decisions made here are the surface that future
clients (TypeScript, Go, gRPC) will inherit. Once a real consumer
exercises them, breaking changes get expensive — so this ADR captures
the constraints and the rationale.

## Decision

### One service, two routers, configurable prefix

`open_guard.service.create_app(...)` returns a FastAPI app that mounts
two routers under a single configurable prefix:

- `DecisionRouter` — runtime hot path: `/authorize`, `/authorize/traced`,
  `/list_authorized`, `/authorize_and_consume`.
- `AdminRouter` — existing CRUD surface, mounted at `{prefix}/admin`.

The default prefix is `/v1`. Operators may mount under
`/openguard/v1`, `/api/auth/v1`, or any other path via
`ServiceConfig(prefix=...)`. The routers themselves contain no
hard-coded prefix — `app.include_router(prefix=...)` injects it.

Rationale: hot-path decision endpoints have different latency,
observability, and rate-limiting needs than admin CRUD. Two routers
makes per-router middleware trivial. One mounted FastAPI app keeps
deployment surface simple.

### Versioned API constant

```python
SERVICE_API_VERSION = "v1"
```

Wire-contract decisions made in Phase 10 may need revision once real
consumers exercise them. Rather than risk silent drift, future
breaking changes mount under a new prefix (`/v2/...`). Within the
`v1` prefix, additions are allowed; semantics may not change.

### Pluggable auth via `AuthBackend` protocol

Three backends ship in Phase 10:

| Backend | Mode | Header | Status |
|---------|------|--------|--------|
| `ApiKeyAuth` | sha256-hashed keys via `ApiKeyStorePort` | `Authorization: ApiKey <k>` | built-in |
| `ShieldAuth` | open-shield JWT validator | `Authorization: Bearer <jwt>` | optional `[shield]` extra |
| `CallableAuth` | user-supplied callable → `CallerContext` | any | escape hatch |

`ApiKeyAuth` is the floor every deployment can use — no external
dependency, hash-stored, simple. `ShieldAuth` is the Cerebrio default —
wraps an open-shield `TokenValidatorPort`. `CallableAuth` covers
mTLS, proxy headers, custom JWT validators, anything we didn't
anticipate. The "should we merge open-shield into open-guard?"
question stays explicitly deferred — open-shield is integrated as
an *optional* dependency, not absorbed.

### Caller authenticates the service; subject lives in the request body

The JWT or API key answers "which service is asking?" — never
"who is the subject being authorized?". `Subject` plus the optional
`on_behalf_of` chain remain explicit in the request body. This
preserves the embedded-library semantics and avoids overloading
authentication input with authorization input.

### Tenant ID sourced from auth claim only

`CallerContext.tenant_id` (extracted from the API key record or JWT
claim) is the only legitimate source of `tenant_id`. The request
body never carries `tenant_id`; if it did, the field would be
stripped server-side. The `X-Tenant-ID` request header is honored
*only* when the caller's scopes include `cross_tenant_admin` — rare,
intended for ops/console tooling.

This eliminates a class of cross-tenant bugs by construction. Mirrors
OpenFGA `store_id` and Auth0 FGA tenancy patterns.

### Error envelope

All non-2xx responses use a uniform shape:

```json
{
  "error": {
    "code": "string_machine_readable",
    "message": "Human-readable summary",
    "details": null | { ... }
  }
}
```

`code` is the machine-readable surface SDKs branch on; `message` is
free-form for logs; `details` is structured (e.g., validation errors
under `{"errors": [...]}`).

| Status | When |
|--------|------|
| 401 | missing or invalid credentials |
| 403 | valid credentials, insufficient scope (incl. cross-tenant override without scope) |
| 404 | unknown policy / relationship / delegation / session id |
| 422 | request body fails Pydantic validation |
| 5xx | upstream failure or unhandled exception (traceback hidden) |

### Endpoint set

Decision endpoints are versioned under `{prefix}`:

- `POST /authorize`
- `POST /authorize/traced`
- `POST /list_authorized` *(sync `Guard` only)*
- `POST /authorize_and_consume` *(sync `Guard` only)*

`AsyncGuard` exposes only the first two; `list_authorized` and
`authorize_and_consume` depend on the sync delegation evaluator.
The router introspects the supplied guard at build time and only
registers endpoints the guard supports — async deployments get a
clean OpenAPI schema rather than 501 placeholders.

Admin endpoints sit under `{prefix}/admin/*` and are unchanged in
semantics from Phase 7.

### Python SDK is the validation signal for the wire contract

Phase 10 ships only the Python SDK. cerebrio-sapience will be the
first real consumer; its experience tells us whether wire-contract
decisions held up before we duplicate the surface in TypeScript / Go
or wrap it in gRPC.

## Consequences

### Positive

- One deployable artifact, one wire contract, one Python SDK to
  validate it. Iteration cost stays bounded.
- HTTP works from every language without proto compilation or
  runtime codegen — unblocks all cross-language consumers immediately.
- Auth is pluggable from day one — no migration path needed when
  deployments outgrow `ApiKeyAuth`.
- Tenant isolation is enforced by construction. The body cannot
  forge a tenant.

### Negative

- gRPC consumers must wait for Phase 11. Streaming endpoints
  (revocation push, change feeds) are blocked on that.
- Wire-contract decisions made here become hard to change once
  real consumers exist. The `SERVICE_API_VERSION` constant +
  `/v2` migration path is the only out.
- HTTP + JSON is heavier than gRPC for high-decision-rate paths.
  Real consumers will tell us if this is a problem in practice.

### Open

- Whether `Guard.authorize_traced` JSON payload size becomes a
  problem at scale. If so, Phase 11 may add a `trace=summary` mode
  alongside the full trace. Current view: ship full trace, measure,
  optimize on demand.
- Whether `open-shield-python` gets absorbed into open-guard.
  Phase 10 leaves it as an optional dep; the merge question reopens
  if Phase 10 deployments expose ergonomics issues.

## References

- Brainstorm record: `specs/phases/phase-10-service-mode-sdk/history.md`
- OpenFGA tenancy model (store_id pattern)
- Auth0 FGA tenancy guidance
- ADR-0010 — Python SDK shape
