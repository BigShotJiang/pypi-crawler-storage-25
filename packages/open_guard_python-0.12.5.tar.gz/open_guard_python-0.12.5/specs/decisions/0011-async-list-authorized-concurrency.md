---
id: "0011"
title: "AsyncGuard.list_authorized concurrency model: sequential per-candidate evaluation"
status: accepted
date: 2026-05-18
---

# ADR-0011: `AsyncGuard.list_authorized` Concurrency Model — Sequential per-Candidate Evaluation

## Status

`accepted` (Phase 11, v0.12.0)

## Context

Phase 11 added `AsyncGuard.list_authorized` as the async sibling of sync
`Guard.list_authorized` (FEAT-018). The sync implementation iterates
candidates *sequentially* — each candidate is evaluated by calling
`Guard.authorize(...)` once. The async port had an obvious-looking
optimization on the table: replace the sequential loop with a bounded
`asyncio.gather(N)` so candidates are evaluated concurrently. Pursued
this would matter most for async SQL backends, where each `authorize()`
call hits the database.

Three design forces pushed back on the bounded-concurrency option:

1. **Sync parity** is the contract for the Phase 11 bundle (ADR-0012).
   If async semantics drift from sync, anyone reading sync docs and
   substituting `await` will hit a surprise. Sequential is the safe
   default; sync sets the bar.

2. **Per-decision side effects.** `authorize()` is mostly a pure
   evaluation, but `_apply_approval_gate` (FEAT-015) can *create* an
   `ApprovalRequest` when none exists — a side effect that interacts
   poorly with concurrent execution. Two concurrent `authorize()`
   calls against the same `(tenant, subject, action, resource)` could
   each find no existing request via `find_latest_by_hash` and each
   create one. `ApprovalManager.request_or_existing` is idempotent at
   the hash level, but only when serialized; under `gather` there is no
   serialization guarantee. Sync `Guard.list_authorized` does not have
   this risk because Python's GIL serializes the call chain anyway.

3. **Cursor stability.** The list cursor encodes `rebac_offset`,
   `candidate_cursor`, and `seen_ids`. Sequential evaluation makes
   `seen_ids` linear-additive and the per-source cursor advance
   deterministic. Bounded concurrency over a single page is safe;
   bounded concurrency across pages requires a re-ordering policy and
   a notion of "hit-limit-early-keep-the-rest". Neither is hard to
   build, but they're not free.

No real workload has been profiled and shown to require concurrency.
The motivation is aesthetic, not empirical.

## Decision

`AsyncGuard.list_authorized` iterates candidates **sequentially**:
each candidate is `await self.authorize(...)`-ed one at a time, matching
sync `Guard.list_authorized` exactly. No `gather`, no per-candidate task
spawning, no bounded-concurrency knob in the public API.

The decision applies to all three composition sources:
1. `AsyncCandidateResourcePort` fetch_candidates results
2. ReBAC native enumeration (`find_object_ids_for_subject`)
3. `AsyncDelegationEvaluator.list_contribution` results

Cursor format (`Cursor.encode` / `Cursor.decode`) is reused unchanged
from sync — there is no async-only cursor shape.

## Consequences

### Accepted trade-offs

- **Latency**: a `list_authorized` call over an async SQL backend with
  N candidates will issue N serialized `authorize()` calls. For small
  pages (default `limit=100`) this is acceptable; for very large pages
  on slow stores, it is the bottleneck.
- **No public concurrency knob** until profiling data justifies it.
- **Code parity** with sync is preserved — bug fixes and feature
  additions to one path will land on the other simultaneously.

### Open follow-ons

- A future `ENH` may add **bounded-concurrency** for the candidate-source
  source only (where side-effect risk is lowest), gated on a real
  workload showing it matters. The shape we would consider:

  ```python
  await guard.list_authorized(
      subject, action, resource_type, tenant_id,
      candidate_concurrency=8,  # opt-in only, default = sequential
  )
  ```

  Out of scope for Phase 11.

- The same `ENH` could target the **ReBAC source** if concurrent
  enumeration over a hot relationship store becomes a profiling
  bottleneck. Sources have different concurrency-safety profiles, so
  the knob would likely be source-scoped.

### Rejected alternatives

| Option | Why rejected |
|--------|--------------|
| Bounded `asyncio.gather(N)` on per-candidate `authorize()` | Side-effect risk from `_apply_approval_gate` request creation; cursor logic complication; no profiling data to justify |
| `AsyncIterator`-based candidate source | Would require new port shape `AsyncCandidateResourcePort` already shipped in Phase 7 with `fetch_candidates(...)` — redesign costs outweigh consistency wins |
| Work-stealing across tasks | Same side-effect issue plus speculative work-cancellation cost — premature optimization |

## References

- ADR-0001 — `list_authorized` composition strategy (sync, Phase 4)
- ADR-0012 — Async parity composition (Phase 11) — establishes the
  mirror-not-redesign stance that ADR-0011 inherits
- `src/open_guard/domain/services/async_guard.py` — `AsyncGuard.list_authorized`
- `src/open_guard/domain/services/guard.py` — sync sibling
- Phase 11 `tasks.md` (Task 1) — implementation tracking
