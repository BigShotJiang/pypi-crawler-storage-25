---
id: "0007"
title: "Policy isolation: read-only evaluation view and taint-marking for untrusted attributes"
status: accepted
date: 2026-04-19
---

# ADR-0007: Policy Isolation — Read-Only Evaluation View and Taint-Marking for Untrusted Attributes

## Status

`accepted` (Phase 6, v0.7.0)

## Context

open-guard is increasingly used in agentic systems where the authorization library is invoked
inside an LLM tool-call chain. In these environments, an adversary can craft a prompt that
causes the agent to call `policy_store.add()` or `policy_store.remove()` at evaluation time,
effectively granting or removing permissions within the same call that should only be reading
them. This class of attack is described in OWASP's prompt injection guidance and has been
demonstrated in LangChain-based deployments (LangChain security advisory, 2023-2024) where
tool call injection caused privilege escalation by invoking permission-modifying tools.

The Content Security Policy (CSP) web standard addresses a structural analogue: scripts
delivered from a page may not modify the policy namespace that governs which scripts run.
The enforcement is structural — the policy namespace is not exposed to the script context at
all. open-guard needed an equivalent structural control.

A second, related problem is attribute provenance. ABAC policies evaluate attributes drawn from
multiple sources: identity providers, user-supplied input, LLM-generated metadata, and internal
services. These sources have different trust levels. A policy condition that evaluates
`request.context["user_intent"] == "read"` may be exploited if `user_intent` was populated by
an LLM that was itself prompted adversarially. There was no mechanism to annotate attributes by
trust level or to express policy conditions that only apply to trusted attribute sources.

## Decision

### Layer 1: ReadOnlyPolicyView (structural isolation)

`ReadOnlyPolicyView` is a wrapper around `PolicyStorePort` that proxies all read methods
transparently and raises `AttributeError` on any mutation method:

```python
class ReadOnlyPolicyView:
    def __init__(self, store: PolicyStorePort) -> None:
        self._store = store

    def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        return self._store.get_by_tenant(tenant_id)

    def get_by_tenant_and_type(self, tenant_id: str, evaluator_type: str) -> list[Policy]:
        return self._store.get_by_tenant_and_type(tenant_id, evaluator_type)

    def add(self, policy: Policy) -> Policy:
        raise AttributeError(
            "PolicyStore is read-only during evaluation — "
            "mutations are not permitted on the evaluation path"
        )

    def remove(self, policy_id: str, tenant_id: str) -> None:
        raise AttributeError(
            "PolicyStore is read-only during evaluation — "
            "mutations are not permitted on the evaluation path"
        )
```

The view is wired automatically in `PolicyRouter.__init__`:

```python
self._policy_store = ReadOnlyPolicyView(policy_store)
```

All evaluators (`RBACEvaluator`, `ABACEvaluator`, `TBACEvaluator`, `DelegationEvaluator`)
receive the view through `PolicyRouter`, not the raw store. No evaluator interface change is
required — they call the same `PolicyStorePort` API, but mutations are blocked at runtime.
Administrative code that legitimately needs to write policies holds a reference to the raw store
directly; it does not go through `PolicyRouter`.

This is a structural control: it does not depend on the evaluator being well-behaved, policy
correctness, or runtime input validation. Even if an evaluator is compromised or tricked into
calling `add()`, the call fails immediately.

### Layer 2: Taint marking (`_trusted` convention)

Attribute dictionaries passed to ABAC evaluation may contain a `_trusted` key:

```python
{
    "user_intent": "read",
    "risk_score": 0.1,
    "_trusted": {"user_intent": False}   # user_intent is untrusted (LLM-generated)
}
```

A value of `False` for a key in `_trusted` marks that attribute as untrusted. Absent keys
default to trusted. The ABAC evaluator's `_is_untrusted()` helper walks nested attribute
paths (dot-notation) to determine trust status before evaluating each condition.

### `trusted_only` condition modifier

Conditions in ABAC policies may set `trusted_only: True`:

```python
condition:
  attribute: "user_intent"
  operator: "eq"
  value: "read"
  trusted_only: true
```

When `trusted_only: True` is set and the attribute's source is untrusted (per `_trusted`),
the evaluator treats the condition as **not matching** — the condition contributes neither
a permit nor a deny, as if the attribute were absent. This prevents untrusted data from
satisfying a condition that a policy author intended only for verified attributes.

### Two-layer defense

The two controls are independent and address different threat surfaces:

| Control | Threat | Mechanism |
|---|---|---|
| `ReadOnlyPolicyView` | Agent writes new policies at eval time | `AttributeError` on mutation methods |
| `_trusted` / `trusted_only` | Untrusted attribute satisfies a policy condition | Condition skipped when source is untrusted |

Both layers must be present: structural isolation blocks policy mutation; taint marking
prevents untrusted inputs from satisfying conditions that require verified data.

## Consequences

- Administrative code (policy management APIs, migration scripts) must hold a reference to
  the raw `PolicyStorePort` instance, not the `PolicyRouter`. This is already the case for all
  existing callers; the view is only injected at the evaluator layer.
- `AttributeError` is raised synchronously on any `add()` or `remove()` call reaching an
  evaluator. Callers that inadvertently pass a `PolicyRouter` reference to administrative code
  will receive a clear error rather than a silent no-op.
- The `_trusted` convention is advisory — it relies on attribute builders populating `_trusted`
  correctly. Code that assembles attribute dicts from untrusted sources (LLM output, user
  input, external APIs) must annotate affected keys as `False` in `_trusted`. This is not
  enforced automatically.
- `trusted_only: True` causes a condition to be skipped (not to deny). Policies that require
  a trusted attribute to be present must combine `trusted_only: True` with an explicit
  deny-if-absent condition, or use a deny-default policy posture.
- The `ReadOnlyPolicyView` does not cache; all read calls pass through to the underlying store.
  Performance characteristics of the store are unchanged.
