---
id: "0005"
title: "Delegation bounds: usage counters, budget tracking, and lease TTL"
status: accepted
date: 2026-04-19
---

# ADR-0005: Delegation Bounds — Usage Counters, Budget Tracking, and Lease TTL

## Status

`accepted` (Phase 5, v0.6.0)

## Context

Delegation bounds are the enforcement mechanisms that limit how much a delegation can be
used. Three orthogonal bound types are required:

1. **Usage counters** (`max_uses` / `uses_remaining`) — how many times a delegation may be
   exercised before auto-expiry.
2. **Budget** (`budget` / `budget_remaining`) — monetary or token cost tracked as a `Decimal`
   for exact arithmetic.
3. **Lease TTL** (`lease_ttl` + `last_heartbeat_at`) + **wall-clock expiry** (`expires_at`)
   — time-based bounds requiring active heartbeating or passive cutoff.

Key constraint: **all counter decrements must be CAS-safe** (Compare-and-Swap) to prevent
over-consumption under concurrent access.

Prior art:
- **etcd transactions** — CAS on version; basis for distributed counters
- **AWS STS SessionDuration** — passive time bound only, no active heartbeating
- **Vault leases** — heartbeat (renew) model for secret leases; directly influenced `renew()`
- **Stripe idempotency keys** — idempotent create pattern; influenced `make_hash()`

## Decision

### CAS-safe decrements

#### In-memory store

`InMemoryDelegationStore` uses a single `threading.RLock` per store instance. All reads
and writes inside `decrement_uses` and `decrement_budget` are done under the lock:

```python
with self._lock:
    if d.uses_remaining < amount:
        raise UsageExhaustedError(...)
    updated = d.model_copy(update={"uses_remaining": d.uses_remaining - amount})
    if updated.uses_remaining == 0:
        updated = updated.model_copy(update={"status": DelegationStatus.EXHAUSTED})
    self._store[delegation_id] = updated
```

This is correct for a single-process environment. Multi-process environments must use the
SQL store.

#### SQL store

`SQLAlchemyDelegationStore` uses a `UPDATE ... WHERE uses_remaining >= :amount RETURNING *`
pattern. If the UPDATE returns 0 rows, it raises `UsageExhaustedError`. This is equivalent
to a CAS loop on the row version without explicit locking. The same pattern applies to
`decrement_budget` using SQL `NUMERIC` (mapped to Python `Decimal`).

### Budget: Decimal arithmetic

`budget` and `budget_remaining` use Python's `decimal.Decimal` for exact arithmetic.
The SQL column type is `NUMERIC(precision=20, scale=10)`. No rounding is applied at the
storage layer; rounding is the caller's responsibility.

### Lease TTL and heartbeating

A delegation with `lease_ttl` set requires active heartbeating via `DelegationManager.renew()`.
The heartbeat updates `last_heartbeat_at`. The `expire_stale()` method marks delegations
`EXPIRED` when `now - last_heartbeat_at > lease_ttl`.

`expires_at` is a passive wall-clock cutoff checked during evaluation by
`DelegationEvaluator`: delegations with `expires_at < now` are filtered out.

`renewable_by` is an optional list of subject IDs permitted to call `renew()`. If `None`,
any subject may renew. If set, only listed subjects may renew.

### consume vs authorize_and_consume

- `DelegationManager.consume()` is the low-level primitive — it takes a delegation ID and
  decrements directly. Callers must first call `authorize()` to get the delegation ID.
- `Guard.authorize_and_consume()` is the recommended high-level API. It calls `authorize()`,
  extracts delegation IDs from evaluations where `ev.evaluator == "delegation"`, and calls
  `consume()` on each.
- `MCPGuard.consume_tool_call_budget()` is a convenience wrapper for the MCP layer —
  it reads `result.attributed_delegation_ids` from `MCPAuthorizationResult` and calls
  `Guard.consume_delegation()` for each.

### list_authorized does not consume

`Guard.list_authorized()` calls `guard.authorize()` (not `authorize_and_consume()`) for
each delegation-contributed candidate. Usage counters are never decremented during listing.

## Consequences

- The CAS-safe pattern for the SQL store requires testing under concurrent writes (WAL mode
  on SQLite, or `REPEATABLE READ` on PostgreSQL).
- `Decimal` fields in Pydantic must be declared with `Decimal` Python type; JSON round-trips
  require explicit `str` ↔ `Decimal` coercion in the SQL model layer.
- Callers using `authorize_and_consume()` will decrement counters even if the action
  ultimately fails at the application layer (e.g. tool execution crashes). This is intentional:
  the authorization was granted and the attempt was made.
