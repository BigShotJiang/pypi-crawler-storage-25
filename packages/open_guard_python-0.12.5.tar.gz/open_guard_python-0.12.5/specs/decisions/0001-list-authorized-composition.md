---
id: "0001"
title: "list_authorized composition and reverse-ABAC strategy"
status: accepted
date: 2026-04-18
---

# ADR-0001: `list_authorized` Composition and Reverse-ABAC Strategy

## Status

`accepted` (Phase 4, v0.5.0)

## Context

Phase 4 delivers `Guard.list_authorized(subject, action, resource_type, tenant_id, ...)` — the inverse of `authorize()`. RAG pipelines, filtered tool discovery, and any "which resources can this subject act on?" query need it. Without it, consumers either (a) retrieve everything and filter with N round-trip `authorize()` calls (O(N) latency), or (b) skip filtering and leak data to the LLM.

Open-guard is a **hybrid engine**: policies combine attribute matching (`Policy.resource_match`, `Policy.conditions`) with ReBAC relation tuples. Unlike pure-ReBAC engines (OpenFGA, SpiceDB) where graph walk enumerates authorized objects directly, open-guard's ABAC/RBAC policies match on resource attributes the library doesn't own — it's the consumer's data store that knows them.

Two forces:
1. Users expect `list_authorized` composition to be **identical** to `authorize()`. Divergence between "can Alice see doc X?" and "which docs can Alice see?" is a class of bug nobody wants.
2. Reverse-ABAC (compiling conditions into store-native queries) is hard: chain predicates, regex operators, set operators, dynamic PIP lookups — none push down cleanly to SQL. Every major hybrid engine that tried this has a long tail of edge cases.

## Decision

**Adopt the AWS Verified Permissions / Casbin `enforce_batch` pattern: iterate-per-candidate, calling the full `authorize()` for each.**

Concretely, `Guard.list_authorized` composes two candidate sources:

1. **`CandidateResourcePort`** — consumer-provided. `fetch_candidates(resource_type, tenant_id, prefilter, cursor, limit)` returns `(list[Resource], next_cursor)`. Consumer's data store (SQL, Elastic, Mongo, custom) feeds open-guard candidates with their full attribute payload.
2. **`RelationshipStorePort.find_object_ids_for_subject`** — added in Phase 4. When a `relationship_store` is wired on `Guard`, the ReBAC enumeration yields direct-relation tuple IDs natively (no candidate source needed for ReBAC-only deployments).

For each candidate, open-guard calls the existing `Guard.authorize()` and includes the resource ID in the result iff the decision is `ALLOWED`. Deny precedence, chain enforcement, pending-approval exclusion, and tenant isolation all "just work" — they're properties of `authorize()` itself, and `list_authorized` inherits them by construction.

**Composition semantics match `authorize()`** by literal reuse. There is no parallel composition algorithm to test or document.

**Reverse-ABAC query compilation is explicitly out of scope.** Tracked as ENH-014 for future optimization on specific condition shapes (simple equality / prefix / range) if profiling ever demands it. Never for the full operator set.

### Ordering

Candidate source iterates FIRST, ReBAC enumeration SECOND. Rationale: the candidate source carries the full resource attribute payload (classification, owner, type, etc.) that ABAC / RBAC policies match against. ReBAC tuples carry only object IDs, so materializing resources from them loses attribute context — using ReBAC-materialized resources with ABAC policies can miss their targets. Preferring the candidate source when both are wired avoids this gap.

### Cursor

Opaque base64-URL-safe JSON. Round-trips `rebac_offset` (enumeration progress), `candidate_cursor` (opaque source continuation), and `seen_ids` (dedupe across sources). Default `limit=100`, no upper bound enforced. Stability under *concurrent policy changes* between paginated calls is explicitly undefined — snapshot isolation requires Zanzibar-style zookies, deferred to ENH-015.

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Pure-ReBAC graph walk (OpenFGA / SpiceDB style) | Native enumeration; no candidate source needed | Only covers ReBAC policies; ABAC/RBAC remain un-enumerable |
| Per-evaluator `list_authorized` method on `EvaluatorPort` | Matches `evaluate()` architecture | No meaningful implementation for RBAC/ABAC without candidates — composition becomes "evaluator returns NotSupported, fall back to iteration", i.e., the same as the chosen design but with an extra abstraction layer |
| Reverse-ABAC partial evaluation (Cerbos `PlanResources` / OPA partial eval) | Scales to millions when it works | Chain predicates, regex, set operators, dynamic PIP don't lower cleanly to SQL; one compiler per store backend; long-tail divergence from `authorize()`; Cerbos/OPA users repeatedly hit plan-vs-check edge cases |
| Pattern-based enumeration ("role X grants doc:*") | No iteration cost | Requires policies to encode resource patterns — open-guard uses attribute matching, not patterns. Would force a parallel policy model. No production hybrid engine works this way |
| **Chosen: iterate-per-candidate + native ReBAC via `RelationshipStorePort`** | Composition identical to `authorize()` by construction; standard pattern (AWS VP, Casbin); clean/hexagonal architecture preserved — consumers own resource storage; ReBAC-only deployments pay O(results), ABAC deployments pay O(candidates) honestly | O(candidates) where candidates is the app's data store size; partial evaluation optimization deferred |

## Consequences

**Easier:**
- Composition semantics are trivially auditable — `list_authorized` ⊆ `{r | authorize(r)==ALLOWED}` by construction.
- Consumers already have the mental model — "the list is what would pass authorize".
- Chain propagation, deny precedence, pending-approval exclusion all flow through without special casing.
- Works in any deployment shape — pure ReBAC, pure ABAC, hybrid — as long as the consumer wires the matching source.

**Harder:**
- ABAC-heavy deployments must implement a `CandidateResourcePort`. This is exactly the level of integration work a real authorization layer needs (open-guard doesn't own resource storage), but it's more work than a magic "tell me the authorized IDs" API would imply.
- For very large candidate pools (>100k docs) without ReBAC tuples, iteration has a real cost. If this becomes a real bottleneck, ENH-014 (partial evaluation on simple condition shapes) is the escape valve.
- Fail-closed AND composition means a Guard with multiple evaluators (e.g., ABAC + ReBAC) requires each evaluator type to have at least one matching ALLOW policy for a resource to make it through `list_authorized`. Documented in the integration guide's "Composition rules" section.

## References

- `specs/architecture/integration-guide.md` — consumer-facing usage with `CandidateResourcePort` example
- `specs/backlog/details/FEAT-006.md` — original detail doc
- `specs/phases/phase-4-agent-integration/history.md` — brainstorm + pivot decisions
- `src/open_guard/domain/ports/candidate_resource.py` — port
- `src/open_guard/domain/services/guard.py` — `Guard.list_authorized` implementation
- `tests/integration/test_list_authorized.py` — end-to-end scenarios
- AWS Verified Permissions `is_authorized_batch` — iterate-per-candidate prior art
- Casbin `enforce_batch` — same pattern
- Google Zanzibar paper — graph walk enumeration for ReBAC
- OpenFGA `ListObjects`, SpiceDB `LookupResources` — pure-ReBAC reference
- Cerbos `PlanResources`, OPA partial evaluation — partial-evaluation alternative (deferred)
- ENH-014 — reverse-ABAC query compilation follow-up
- ENH-015 — zookie-style consistency tokens follow-up
