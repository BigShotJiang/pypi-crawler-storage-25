---
id: "0004"
title: "DelegationEvaluator design and meta-authorization strategy"
status: accepted
date: 2026-04-19
---

# ADR-0004: DelegationEvaluator Design and Meta-Authorization Strategy

## Status

`accepted` (Phase 5, v0.6.0)

## Context

Several design questions arose when wiring delegation evaluation into `Guard.authorize`:

1. **Where does delegation evaluation live?** Options: inside the existing evaluator pipeline
   (EvaluatorPort), as a parallel Guard path, or as a post-processing step.

2. **How do we prevent delegation recursion?** The `DelegationEvaluator` needs to call
   `Guard.authorize` to check grantee re-check (`re_check_on_use=True`). This would loop.

3. **How is meta-authorization handled?** A caller wants to delegate "alice's read on docs"
   to "bob". Who is allowed to initiate that delegation?

4. **Non-delegable permissions** — Some policies should not be re-delegatable downstream.
   How do we signal this without adding policy-store access to DelegationEvaluator?

5. **Memoization** — Re-check calls (grantor's permission check per delegation hop) can fan
   out quadratically in large chains. How do we bound the call count?

Prior art:
- **Zanzibar** — explicit `userset rewrite` rules govern re-delegation semantics; no native
  budget or usage bounds
- **XACML delegation profile** — complex XML delegation chains; good theory, poor ergonomics
- **Thomas & Sandhu (1994)** — role delegation theory: Delegator Must Have (DMH) + Grantee
  Must Not Exceed (GME). Directly influenced our narrowing check.

## Decision

### DelegationEvaluator position

`DelegationEvaluator` is a separate service, not an `EvaluatorPort`. It is consulted by
`Guard.authorize` as a **fallback** only when the policy path returns `DENIED`. This preserves
fail-closed AND semantics: if a policy explicitly allows, delegation is never consulted.

### Recursion prevention

`Guard.authorize` accepts an internal `_skip_delegation: bool = False` parameter.
When `DelegationEvaluator` calls back for a re-check, it passes `_skip_delegation=True`.
This flag is never part of the public API signature and is not exposed to callers.

### Meta-authorization: SelfDelegateOnly

The default `default_delegate_policy="self_only"` on `Guard` (and `DelegationManager`)
implements Thomas & Sandhu's DMH principle: a caller may only delegate permissions that
they themselves hold, and only from their own subject. Cross-subject delegation requires
an explicit policy grant (`authorize(caller, "delegate", resource_type="delegation", ...)`).

Setting `default_delegate_policy=None` disables the built-in shortcut and requires every
delegation to pass through `Guard.authorize`.

### Narrowing check

For every scope in a `delegate()` call, `DelegationManager` calls
`guard.authorize(from_subject, action, Resource(id="*", resource_type=...), _skip_delegation=True)`
to verify the grantor actually holds that permission. This implements GME: grantees can
never receive more than the grantor has.

### Non-delegable flag

`Policy.non_delegable: bool = False` marks a policy's grants as non-re-delegatable.
When `Guard.authorize(_skip_delegation=True)` produces an ALLOW and the matched policy
has `non_delegable=True`, the `Decision` gets `non_delegable_policy=True`.
`DelegationEvaluator._grantor_still_permitted()` checks this flag and returns `False`,
blocking the delegation.

This design keeps `DelegationEvaluator` independent of the policy store: it only sees
the `Decision` object returned by `Guard.authorize`.

### Memoization

`DelegationEvaluator.evaluate()` accepts an optional `recheck_cache: dict` that is
threaded through by `Guard.authorize`. The cache key is
`(grantor_id, action_name, tenant_id)`. This bounds re-check calls to O(unique grantors)
across a single request, not O(delegations).

### list_authorized contribution

`DelegationEvaluator.list_contribution(subject, tenant_id, resource_type)` extracts
concrete resource IDs from delegations with `id:eq` or `id:in` scopes. `Guard.list_authorized`
calls this after the candidate-source + ReBAC step and authorizes each candidate with
`guard.authorize` (not `authorize_and_consume`) to avoid consuming usage during listing.

## Consequences

- The `_skip_delegation` flag must be carefully maintained across any refactor to `Guard.authorize`.
- The narrowing check on `id="*"` is intentionally broad — it verifies the grantor holds the
  action/type permission, not necessarily on every specific resource. Tighter narrowing is a
  future enhancement.
- Non-delegable semantics rely on `Guard.authorize` including `non_delegable_policy` in its
  `Decision`. This field must be preserved through any pipeline changes.
