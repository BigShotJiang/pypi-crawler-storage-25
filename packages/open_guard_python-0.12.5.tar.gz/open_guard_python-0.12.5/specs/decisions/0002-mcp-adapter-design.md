---
id: "0002"
title: "MCP tool-call adapter design (SDK strategy, namespace, chain, hygiene)"
status: accepted
date: 2026-04-18
---

# ADR-0002: MCP Adapter Design

## Status

`accepted` (Phase 4, v0.5.0)

## Context

Model Context Protocol (MCP) is the emerging standard (2025-2026) for exposing tools and data sources to LLM agents. An MCP server exposes a set of tools with parameter schemas; an MCP client (the agent) invokes them at runtime. Without authorization, any agent with an MCP connection can invoke any tool with any parameters — which is what every serious agent deployment needs to prevent.

Cerbos, Kong, LiteLLM, AWS Bedrock AgentCore, and Gravitee have all shipped MCP authorization products. Open-guard needs a first-class MCP adapter — or cedes the most important agentic-authz surface.

Open-guard's `Guard.authorize(subject, action, resource)` maps cleanly onto MCP tool calls if we model each tool as a `Resource(resource_type="tool")`. The open questions this ADR resolves:

1. How tightly do we couple to the Python MCP SDK (`mcp` package)?
2. How do multiple MCP servers disambiguate overlapping tool names?
3. How do parameter-level restrictions ("agent may call `query_db` but only for non-destructive queries") express themselves?
4. How do agent-to-user delegation chains (Phase 3 OBO) flow through MCP?
5. Where does parameter-schema validation sit relative to policy evaluation?

## Decision

**A thin, SDK-agnostic adapter at `open_guard.adapters.mcp` with an optional `[mcp]` extra for duck-typed SDK binding.**

Concretely:

### SDK strategy — SDK-agnostic core, optional `[mcp]` extra

Core `MCPGuard.check_tool_call(session_id, tool_name, params, server_id, tool_schema=None, claims=None)` takes plain values. No MCP SDK types appear in the core signature.

The `[mcp]` optional extra ships `open_guard.adapters.mcp.sdk` with a **duck-typed** `from_sdk_call_request(sdk_request, session_id, server_id, claims=None)` helper that reads `.name`/`.tool_name` and `.arguments`/`.params` attributes. This means:

- The Python MCP SDK is not a mandatory dependency of open-guard.
- Users who prefer to integrate without the SDK (e.g., using their own JSON-RPC handler) pay nothing.
- Users who use the SDK get a convenience binding — duck-typed so SDK version drift across 2026 doesn't break consumers.
- Mirrors the existing `[sql]` extra pattern.

### Resource namespace — `tool:{server_id}:{tool_name}` (configurable)

An MCP client may connect to multiple MCP servers; same `tool_name` can exist on different servers with different semantics. Default namespace disambiguates by server:

- `tool:prod:query_db` ≠ `tool:staging:query_db`

Configurable via `MCPGuard(resource_namespace="...")` for single-server deployments where the extra prefix is noise. Policies use the familiar glob patterns open-guard already supports (`tool:prod:*`, `tool:*:query_db`).

### Parameter-level ABAC — dot-paths on existing attribute machinery

Tool parameters flatten into `resource.attributes["params"]`. The existing ABAC dot-path resolver already handles nested dicts, so policies like:

```python
conditions={"resource.params.query": {"op": "not_regex", "value": r"(?i)\bDROP\b"}}
conditions={"resource.params.options.safe": {"op": "eq", "value": True}}
conditions={"resource.params.tables": {"op": "is_subset", "value": [...]}}
```

work out of the box. **No new condition language or operator** — this is critical for policy author ergonomics.

### Chain propagation — consumer-provided `MCPSessionResolver`

Open-guard doesn't know how MCP session claims are minted or verified (OAuth, open-shield-python, custom JWT issuers, etc.). The adapter defines a minimal `MCPSessionResolver` protocol:

```python
class MCPSessionResolver(Protocol):
    def resolve(self, session_id: str, claims: dict[str, Any]) -> Subject: ...
```

Implementations may return a `Subject(on_behalf_of=...)` chain. Phase 3 chain machinery then flows through every `authorize()` call and every `authorize_traced()` trace without special casing.

### Schema hygiene — pre-authorization

Optional `tool_schema` argument on `check_tool_call`. When supplied, open-guard validates structural invariants (required fields present, basic type match) BEFORE calling `Guard.authorize`. Malformed calls return `MCPAuthorizationResult(status="deny", reason="schema_violation:<detail>")` without the policy layer seeing them.

Rationale:
- Policies don't have to encode "required field present" checks.
- Attackers can't use policy-eval error messages as fuzzing signal.
- Matches "reject garbage at the boundary" discipline other adapters follow (FastAPI validators, etc.).

The validator is deliberately minimal (JSON-Schema-style `required` + `properties[type]`) — more elaborate schema validation belongs in the caller's stack.

### Pending-approval response shape

When a policy has `requires_approval` and the decision is `PENDING_APPROVAL`, the result's `.pending` field carries an `MCPAuthorizationPending` with `approval_request_id`, approvers list, quorum, channel hint, TTL in seconds — fetched from the `ApprovalStore`. The consumer dispatches the approval request to Slack / email / webhook. Next call resolves to ALLOW after `Guard.approve()`.

### Filtered tool discovery — `MCPGuard.list_authorized_tools`

Thin wrapper around `Guard.list_authorized(action="invoke", resource_type="tool", ...)`. Returns namespaced tool IDs the resolved subject may invoke. Requires a `CandidateResourcePort` scoped to tools to be wired on `Guard` (open-guard doesn't enumerate MCP tool catalogs — the consumer knows their MCP server inventory).

### Out of scope

- **Streaming-tool chunk authorization** — per-chunk content filtering is a distinct data-flow authz pattern. Tracked as ENH-017.
- **MCP transport security** (TLS, mTLS, session auth) — consumer's concern.
- **MCP server/client implementation** — open-guard is purely the authz layer.
- **Capability negotiation / tool discovery protocol** — consumer's MCP infrastructure.

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Hard-pin `python-mcp-sdk` as core dep | Typed end-to-end | Forces every open-guard consumer onto one SDK version; breaks when the SDK changes; core becomes "MCP-flavored" |
| Ship a full MCP server from open-guard | Turnkey | Scope explosion; ties us to MCP protocol evolution; most users want to integrate authz into their existing server |
| Single "`tool:<name>`" namespace (no server prefix) | Simpler | Multi-server deployments have identity collisions; agent can escalate by choosing servers |
| Parameter-level authz via new DSL / JSONPath | More expressive for some shapes | New language to learn and maintain; our ABAC dot-path + set/regex operators cover the real cases |
| Skip schema hygiene, let policies handle it | Fewer code paths | Policies become defensive and brittle; structural violations leak into policy-eval error messages |
| Built-in session resolver tied to open-shield-python | Convenient for this ecosystem | Violates open-guard's "no hard dependencies on other repos" invariant; different consumers have different auth stacks |
| **Chosen: SDK-agnostic core + duck-typed binding + consumer-provided resolver + dot-path params + pre-authz schema check + `tool:{server}:{tool}` namespace** | Clean architecture; no mandatory dependencies; policies use one language; chain flows through unchanged; multi-server safe; reject garbage at the edge | Consumers write the `MCPSessionResolver` (expected) and the `CandidateResourcePort` for tool discovery (new work) |

## Consequences

**Easier:**
- Core remains dependency-free — `pip install open-guard` never pulls MCP SDK.
- Policy authors use the same ABAC dot-path language for resource attributes and tool parameters.
- Chain, approval, and trace surface work through MCP without special casing.
- SDK version drift across 2026+ releases is absorbed by duck-typing.

**Harder:**
- Consumers must implement `MCPSessionResolver` (straightforward — a few lines for most auth stacks).
- Filtered tool discovery requires a `CandidateResourcePort` wired for `resource_type="tool"` — open-guard doesn't know what tools your MCP servers expose.
- Pending-approval integration requires consumer to dispatch the approval (to Slack/email/etc.) — open-guard stays transport-neutral per Phase 3 decisions.

## References

- `specs/architecture/integration-guide.md` — consumer-facing MCP usage
- `specs/backlog/details/FEAT-009.md` — original detail doc
- `specs/phases/phase-4-agent-integration/history.md` — brainstorm + pivot
- `src/open_guard/adapters/mcp/` — package
- `src/open_guard/adapters/mcp/guard.py` — `MCPGuard`
- `src/open_guard/adapters/mcp/resolver.py` — `MCPSessionResolver` protocol
- `src/open_guard/adapters/mcp/sdk.py` — duck-typed SDK binding
- `tests/integration/test_mcp_adapter.py` — end-to-end flows
- Anthropic MCP specification — https://modelcontextprotocol.io/
- Cerbos MCP authorization — *Fine-Grained Permissions in MCP Servers*
- Kong AI Gateway — MCP Tool ACLs
- LiteLLM — MCP Permission Management
- AWS Bedrock AgentCore Gateway interceptors
- AgentBound (arXiv 2510.21236) — academic framing of MCP access control
- ADR-0001 — `list_authorized` (used by `MCPGuard.list_authorized_tools`)
- ENH-012 — `ApprovalRequirement.channel` as enum follow-up
- ENH-013 — reference `ApprovalDispatcher` protocol follow-up
- ENH-017 — MCP streaming-chunk authorization follow-up
