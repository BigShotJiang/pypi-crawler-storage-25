---
id: "0003"
title: "Delegation entity shape and public API surface"
status: accepted
date: 2026-04-19
---

# ADR-0003: Delegation Entity Shape and Public API Surface

## Status

`accepted` (Phase 5, v0.6.0)

## Context

Open-guard needed a push/pull delegation primitive — a way for one subject (grantor) to
authorize another (grantee) to exercise a scoped subset of permissions. Key design pressures:

1. **Immutability** — Delegation objects must be fully describable by a SHA-256 hash for
   idempotent creation (re-delegation with the same parameters returns the existing object).
2. **Scope flexibility** — A delegation may cover action lists (ABAC-style), resource types,
   and optional resource-match predicates (eq / in operators on id or attributes).
3. **Bounds expressiveness** — Three orthogonal bound types: `max_uses` (count), `budget`
   (Decimal monetary), `lease_ttl` + `expires_at` (time). Any combination is valid.
4. **Lineage tracking** — Delegations form a tree via `parent_delegation_id`, enabling cascade
   revocation and chain-depth enforcement.
5. **Approval integration** — Delegations can start `PENDING_APPROVAL` and transition to
   `ACTIVE` via the existing `ApprovalManager` flow.

Prior art considered:
- **AWS STS AssumeRole** — token-based, no explicit lineage or re-delegation chain
- **Auth0 Token Vault** — opaque token exchange, no resource-scoped predicates
- **Cerbos delegations** — similar scope but no budget/usage tracking
- **RFC 8693 (OAuth 2.0 Token Exchange)** — act/may_act claims, no tree model

## Decision

1. `DelegationScope` is a flat Pydantic model: `action_match: str | list[str]`,
   `resource_type: str`, `resource_match: dict` (predicate language: `{"id": {"op": "eq/in",
   "value": ...}}`). ABAC dot-path conditions are out of scope for Phase 5.

2. `Delegation` entity carries all bounds (`max_uses`, `uses_remaining`, `budget`,
   `budget_remaining`, `lease_ttl`, `last_heartbeat_at`, `expires_at`, `renewable_by`) as
   nullable first-class fields. Pydantic validators enforce that `uses_remaining <= max_uses`
   on construction.

3. `DelegationStatus` is a `StrEnum`: `ACTIVE`, `REVOKED`, `EXHAUSTED`, `EXPIRED`,
   `PENDING_APPROVAL`.

4. `Delegation.make_hash()` produces a SHA-256 digest over a canonical JSON representation of
   the creation parameters. This hash is stored as `request_hash` and used by the store's
   `find_by_hash()` for idempotent creates.

5. Public API exports all delegation symbols from `open_guard.__init__`: `Delegation`,
   `DelegationScope`, `DelegationStatus`, `DelegationManager`, `DelegationStorePort`,
   `InMemoryDelegationStore`, and the five delegation exceptions.

## Consequences

- The hash-based idempotency pattern is the same as `ApprovalRequest.request_hash` — consistent
  across the library.
- `resource_match` uses a mini predicate language rather than full ABAC conditions; this keeps
  matching logic simple and avoids dependency on the ABAC evaluator.
- `max_uses` and `budget` are independently nullable — a delegation can have both, either, or
  neither. The store enforces both constraints independently via CAS-safe decrements.
