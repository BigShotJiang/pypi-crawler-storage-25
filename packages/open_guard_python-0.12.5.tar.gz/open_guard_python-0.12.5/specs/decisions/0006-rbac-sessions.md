---
id: "0006"
title: "RBAC sessions: role subset activation and session-scoped evaluation"
status: accepted
date: 2026-04-19
---

# ADR-0006: RBAC Sessions — Role Subset Activation and Session-Scoped Evaluation

## Status

`accepted` (Phase 6, v0.7.0)

## Context

NIST Core RBAC (Sandhu et al. 2000) defines sessions as a first-class concept: a user
activates a subset of their assigned roles for a bounded interaction window. Without sessions,
every authorization check implicitly uses the full role set of the subject — the equivalent of
running with all permissions all the time. This violates the principle of least privilege for
agent workflows, interactive sessions, and delegated task execution.

The prior implementation stored role information only in subject records and context dictionaries.
There was no structured entity capturing which roles were active, when the window opened, or
when it should expire. Agents calling `Guard.authorize()` always evaluated against the complete
role assignment, with no mechanism to restrict scope to the current task.

AWS IAM session policies address a related problem by allowing inline policy narrowing at
session creation time: a session may only exercise a subset of the permissions the principal
is entitled to. Google Cloud Workload Identity similarly binds session tokens to scoped
identity claims. Both treat the session as an independent authorization artifact rather than
a mutable attribute of the principal record.

open-guard needed an equivalent model that integrated with the existing `RBACEvaluator`,
`ABACEvaluator`, and `Guard` without requiring callers to restructure their authorization calls.

## Decision

### Session as a first-class entity

`Session` is a Pydantic entity in `domain/entities.py`, not a metadata key or context dict
entry. It carries identity (`id`, `tenant_id`, `subject_id`), scope (`activated_roles`),
lifecycle (`status`, `created_at`, `expires_at`, `deactivated_at`), and arbitrary extension
data (`metadata`). This makes sessions auditable, storable, and inspectable independently of
the subject record.

```python
class Session(Entity):
    id: str                       # UUID
    tenant_id: str
    subject_id: str
    activated_roles: list[str]    # subset of subject's assigned roles
    status: SessionStatus         # ACTIVE | DEACTIVATED | EXPIRED
    created_at: datetime
    expires_at: datetime | None
    deactivated_at: datetime | None
    metadata: dict[str, Any]
```

### Role subset activation

`activated_roles` must be a subset of the subject's assigned roles at session creation time.
`SessionManager.create_session()` validates this constraint and raises `SessionError` if any
role in `activated_roles` is not held by the subject. Validation is enforced once at creation;
subsequent role revocations on the subject do not retroactively invalidate the session (this
is consistent with the NIST model where sessions are snapshots of role assignments at
activation time).

Multiple concurrent sessions per subject are allowed. There is no single-active-session
constraint. This supports agent orchestration scenarios where a subject drives several
parallel task threads, each scoped to a different role subset.

### Session-aware RBAC evaluation

`RBACEvaluator._get_subject_roles()` checks `request.context["_session"]`. If a `Session`
object is present and its status is `ACTIVE` (and not expired), the evaluator intersects the
subject's full role set with `session.activated_roles`. Only roles present in both sets are
used for evaluation.

Expired or deactivated sessions **fail-open**: the evaluator falls back to the subject's full
role set rather than denying the request. This is a deliberate choice — the session narrowing
is a scope-reduction convenience, not a security gate. When `Guard.authorize()` encounters an
expired session, it performs a lazy expiry check (marks the session `EXPIRED` in the store),
then injects the now-EXPIRED session into context. The `RBACEvaluator` sees
`status != ACTIVE` and falls back to the subject's full role set. Guard does not raise or deny
on expiry — the request proceeds with full roles.

### `session.*` ABAC namespace

When a `Session` is present in context, the ABAC evaluator builds a `session.*` attribute
namespace from the session object. This exposes `session.activated_roles`, `session.status`,
`session.id`, and all keys from `session.metadata` as evaluable ABAC attributes. Policies can
therefore express conditions like `session.activated_roles contains "data-analyst"` without
requiring custom attribute providers.

### Guard `session_id` parameter

`Guard.authorize(request, session_id=None)` accepts an optional `session_id`. When provided,
Guard loads the session from `SessionStore`, validates it is ACTIVE and not expired, and injects
it into `request.context["_session"]`. When `session_id` is `None`, no session is injected and
the full role set is used — preserving full backward compatibility for callers that do not use
sessions.

## Consequences

- Callers that do not pass `session_id` experience no behavior change.
- `activated_roles` are validated at creation time only. Subsequent role changes on the
  subject do not affect existing sessions; callers managing role revocation must also
  deactivate relevant sessions explicitly.
- Fail-open on expired sessions means a session that has passed its `expires_at` but has not
  been cleaned up still results in full-role evaluation. Callers requiring strict expiry
  enforcement must call `SessionManager.expire()` or use `Guard`'s built-in expiry check.
- Multiple concurrent sessions per subject can produce unexpected interactions if activated
  role sets overlap. The session selected by `session_id` is the only one used per request;
  callers control which session is active per call.
- `session.metadata` is included in the `session.*` ABAC namespace without sanitization.
  Policies using `session.metadata` attributes should apply `trusted_only: True` (see
  ADR-0007) if the metadata originates from untrusted sources.
