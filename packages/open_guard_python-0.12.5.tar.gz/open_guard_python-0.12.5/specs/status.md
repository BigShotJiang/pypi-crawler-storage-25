# Project Status

> **Last Updated**: 2026-05-25
> **Current Phase**: _between phases — v0.12.5 README positioning rewrite, first tag-driven auto-publish_
> **Latest Release**: v0.12.5 — universal-authz positioning README + first release via Trusted Publisher (OIDC) workflow
> **PyPI**: https://pypi.org/project/open-guard-python/ (owner: avinash-singh-io)
> **Health**: On Track

## Summary

open-guard is a standalone, vendor-neutral authorization library for Python providing unified RBAC + ABAC + TBAC + ReBAC evaluation for all actor types — human users, AI agents, API services, IoT devices, and AI conversations. Built with clean/hexagonal architecture (mirroring open-shield-python's design principles). Fills the gap left by Oso's move to SaaS: no existing open-source library combines all four authorization models with native AI agent support.

## Active Phase

| Phase | Name | Status | Progress |
|-------|------|--------|----------|
| _none_ | _Phase 11 (Async Parity) complete; v0.12.0 awaiting merge → tag_ | — | 7 / 7 tasks |

> Phase 11 (Async Parity, v0.12.0) shipped 2026-05-18 on branch `phase-11-async-parity`. 1235 tests passing (+49), 93% coverage, zero breaking changes. Awaiting user approval to merge to staging → main and tag. Phase 12 (gRPC + non-Python SDKs) is not yet scheduled.

## Completed Phases

| Phase | Name | Version | Date |
|-------|------|---------|------|
| 0 | RBAC + ABAC Core | v0.1.0 | 2026-04-16 |
| 1 | TBAC (Time + Task) | v0.2.0 | 2026-04-16 |
| 2 | ReBAC + SQLAlchemy + ABAC Enhancements | v0.3.0 | 2026-04-17 |
| 3 | Agentic Core Contract | v0.4.0 | 2026-04-18 |
| 4 | Agent Integration Surface (list_authorized + MCP adapter + integration guide) | v0.5.0 | 2026-04-18 |
| 5 | Delegation & Bounds (push/pull delegation + usage caps + leases) | v0.6.0 | 2026-04-19 |
| 6 | Production Hardening (sessions, policy isolation, push revocation) | v0.7.0 | 2026-04-19 |
| 7 | Consumer Integration (factory, admin SDK, REST API, async, CLI) | v0.8.0 | 2026-04-19 |
| 8 | AI-Era Primitives (TrustGate + OperationChain + ActorType) | v0.9.0 | 2026-04-20 |
| 9 | Production Integration (Cerebrio P0 Blockers) | v0.10.0 | 2026-04-28 |
| 10 | Service Mode + Python SDK | v0.11.0 | 2026-05-04 |
| 11 | Async Parity (AsyncGuard.list_authorized + AsyncDelegationEvaluator + AsyncApprovalManager) | v0.12.0 (pending release) | 2026-05-18 |

## Upcoming Phases

| Phase | Name | Status | Key Deliverables |
|-------|------|--------|-----------------|
| 12 | gRPC + non-Python SDKs (renumbered from prior Phase 11) | Not Scheduled | gRPC wrapper, TypeScript + Go SDKs, MCP `/tools/check` endpoint, possibly streaming endpoints |

## Blockers

| ID | Description | Severity |
|----|-------------|----------|
| _(none)_ | | |

## Critical Items (P0)

| ID | Type | Description |
|----|------|-------------|
| _(none)_ | | All Phase 9 P0 items resolved (FEAT-016, FEAT-017, ENH-020, ENH-021) |

## P1 Items (for awareness)

> All P1 items resolved through Phase 8. Phase 9 closed the 4 P0 cerebrio-sapience blockers.

| ID | Type | Description | Target Phase |
|----|------|-------------|--------------|
| FEAT-012 | Feature | Service Mode — HTTP wrapper around AdminRouter + Guard (gRPC split to Phase 11) | 10 |
| FEAT-013-py | Feature | Python SDK — sync + async clients with namespaced API | 10 |
| FEAT-013-ts-go | Feature | TypeScript + Go SDKs (deferred from Phase 10) | 12 |

## Cross-Repo Coordination

| This Phase | Blocks | Blocked By |
|------------|--------|------------|
| _(none — between phases)_ | — | — |

> Phase 10 (Service Mode + Python SDK) shipped 2026-05-04 — cerebrio-sapience can now consume open-guard over the wire via `OpenGuardClient`. Phase 11 (gRPC + TypeScript/Go SDKs) lands when a real non-Python consumer needs it; the Python SDK is the validation signal for the wire contract before that duplication.

## Next Actions

1. ~~Phase 8 complete~~ ✅ released as v0.9.0 on 2026-04-20
2. ~~Phase 9 complete~~ ✅ released as v0.10.0 on 2026-04-28
3. ~~Brainstorm Phase 10~~ ✅ done 2026-05-04 (slim scope: HTTP service + Python SDK; gRPC + TS/Go → later phase)
4. ~~Start Phase 10~~ ✅ started 2026-05-04 — branch `phase-10-service-mode-sdk`
5. ~~Implement Phase 10~~ ✅ all 14 task groups complete; 1186 tests passing (+117), 93% coverage
6. ~~Sync docs~~ ✅ Phase 10 history propagated to auth-model.md (Service Mode Authentication section) + roadmap.md
7. ~~Complete Phase 10~~ ✅ retrospective written; tracking updated; v0.11.0 released
8. ~~Plan Phase 11 (Async Parity)~~ ✅ 2026-05-18 — phase files at `specs/phases/phase-11-async-parity/`; gRPC + TS/Go renumbered to Phase 12
9. ~~Start Phase 11~~ ✅ 2026-05-18 — branch `phase-11-async-parity` active
10. ~~Implement Phase 11~~ ✅ 2026-05-18 — all 7 task groups complete; 1235 tests passing (+49), 93% coverage, zero breaking changes
11. ~~Write retrospective + version bump to v0.12.0~~ ✅ 2026-05-18
12. Merge `phase-11-async-parity` → staging → main and tag v0.12.0 (user approval required per Rule 6)
13. Schedule Phase 12 (gRPC + non-Python SDKs) when a non-Python consumer needs it
14. Resolve open question (open-shield merge) if Phase 10/11 deployments expose real ergonomics issues

## Key Decisions Made

- **2026-04-28**: Resource-scoped RBAC implemented via `resource_match` dict on `assign_role` — reuses existing RBAC `resource_match` filter, no dedicated `RoleAssignment` entity, no evaluator changes. Standard pattern (Google IAM, AWS IAM, Azure RBAC).
- **2026-04-28**: `check_relationship` placed on `PolicyAdmin`, not `Guard` — it's a data query (does relation R exist?), not an authorization decision (can X do Y to Z?). Mirrors Zanzibar `Check`.
- **2026-04-28**: Async SQL guard uses a peer sync engine for `TBACEvaluator` — avoids forcing `AsyncTBACEvaluator` build-out (FEAT-014 stays P2). Both engines share the database.
- **2026-04-28**: All Phase 9 examples and tests use domain-neutral vocabulary (department, region, group, team) — open-guard stays vendor-neutral.
- **2026-04-20**: Phase 8 reframed from "Service Mode + SDKs" to "AI-Era Primitives" — TrustGate + OperationChain + ActorType extension. Service Mode pushed to Phase 9.
- **2026-04-20**: TrustGate as dedicated 5th evaluator (not ABAC conditions) — semantic clarity, independent OperationChain composition, chain-aware trust scopes.
- **2026-04-20**: OperationChain is light — action-pattern → evaluator-list mapping with fnmatch glob, first-match-wins. Custom combination strategies deferred.
- **2026-04-20**: EvaluatorPort gains `evaluator_type` abstract property — formalizes what was already implicit in `supports()`.
- **2026-04-19**: Session entity (not Subject.metadata) — dedicated `Session` + `SessionStorePort`; multiple concurrent sessions per subject; fail-open on expiry. ADR-0006.
- **2026-04-19**: `ReadOnlyPolicyView` auto-wired in `PolicyRouter.__init__` — structural defense against eval-path policy mutation. ADR-0007.
- **2026-04-19**: `_trusted: {attr: False}` taint convention + `trusted_only: True` modifier — two-layer prompt-injection defense. ADR-0007.
- **2026-04-19**: `RevocationStreamPort` as callback-based pub/sub — synchronous in-process, at-most-once, consumer extends to Kafka/Redis. ADR-0008.
- **2026-04-19**: Guard.from_config() uses DSN string, no dict/YAML/TOML config — follows SQLAlchemy create_engine(url), Redis from_url() pattern. Config file parsing is consumer responsibility.
- **2026-04-19**: Dual API: sync Guard unchanged, new AsyncGuard with native async stores — to_thread() wrapper rejected (thread pool saturation at scale). Evaluator logic stays sync inside AsyncGuard except AsyncReBACEvaluator.
- **2026-04-19**: AdminRouter as mountable FastAPI router, standalone server deferred to Phase 8.
- **2026-04-19**: DB tooling: create_all_tables() + CLI + DDL export, no Alembic — schema creation is library concern, migration history is consumer concern.
- **2026-04-19**: External adapters (Casbin/OPA/OpenFGA) dropped permanently — open-guard builds all four models from scratch. Policy DSL dropped — tenants use console UI + Pydantic models.
- **2026-04-18**: Phase 3 delivers additive v0.4.0 (not breaking) — `Decision.allowed` as `@computed_field` alongside new `status: DecisionStatus`
- **2026-04-18**: Dropped the `Decision(allowed=True/False)` legacy-kwarg BC shim — pre-1.0, no consumers; `status=` is the one construction path
- **2026-04-17**: OBO identity chain = recursive `Subject.on_behalf_of` field, not a separate entity or ReBAC relation
- **2026-04-17**: `DecisionTrace` via opt-in `authorize_traced()`, not a flag on `authorize()`; `schema_version="1.0"` baked in
- **2026-04-17**: `ApprovalStorePort` as a new port (rules vs. operational state separation); idempotency via SHA-256 of `(tenant, subject.id, action.name, resource.id, resource.resource_type)`
- **2026-04-17**: Approval dispatch is consumer responsibility — open-guard returns metadata, never sends messages
- **2026-04-17**: Chain-aware ABAC via `chain.*` attribute paths + `any_matches` operator — reuses existing ABAC DSL, no parallel language
- **2026-04-17**: Chain depth default 5, configurable on `Guard`
- **2026-04-17**: ReBAC data model — Zanzibar-style relation tuples (industry standard: OpenFGA, SpiceDB, Ory Keto)
- **2026-04-17**: Recursive subproblem decomposition for graph traversal with memoization + max-depth
- **2026-04-17**: ABAC OR logic via structural `condition_groups` (XACML pattern) — backward-compatible
- **2026-04-17**: Negated operators (`not_contains`, `not_regex`) over general NOT wrapper (AWS IAM style)
- **2026-04-17**: Set operators — `contains_any`, `contains_all`, `is_subset` (Cedar + XACML)
- **2026-04-17**: SQLAlchemy stores — consumer-owned engine, `create_tables()`, `from_url()`; `[sql]` optional extra
- **2026-04-17**: Separate `RelationshipStorePort` for ReBAC tuples (distinct from `PolicyStorePort`)
- **2026-04-17**: Application-level duplicate check for SQL relationship tuples (NULL-safe across dialects)
- **2026-04-16**: Adopted clean/hexagonal architecture from open-shield-python
- **2026-04-16**: Build evaluators from scratch (no Casbin/OPA dependency) — open-guard owns data + compute
- **2026-04-16**: Hybrid evaluation: unified Guard.authorize() + typed evaluator ports
- **2026-04-16**: Flexible actor model (user, agent, service, device, conversation)
- **2026-04-16**: SOLID + design principles as project standards
- **2026-04-16**: Split Phase 1 into TBAC-only; ReBAC moves to Phase 2
- **2026-04-16**: UTC internally, IANA timezone for recurring schedules
- **2026-04-16**: Standard-level task lifecycle (delegation/usage-counting deferred)

## Recent Changes

- **2026-05-25**: First public PyPI release — v0.12.1 published as `open-guard-python` (distribution-name choice forced by PyPI similarity filter blocking `open-guard` due to active `OpenGuard` project; import path unchanged at `import open_guard`). LICENSE file added, README badge fixed, `.github/workflows/publish.yml` scaffolded with OIDC + `pypi` environment for future tag-driven releases. v0.12.0 was uploaded then immediately yanked due to BUG-001 (unconditional fastapi+sqlalchemy imports in `__init__.py` — bare install was unimportable). v0.12.1 fixes the bug by wrapping the imports in `try/except ImportError` to match the existing `[client]` extra pattern; bare `pip install open-guard-python` now imports cleanly.
- **2026-05-18**: Phase 11 complete — v0.12.0 ready to release (1235 tests, +49 from baseline of 1186; 93% coverage, zero breaking changes; AsyncGuard.list_authorized (FEAT-018), AsyncDelegationEvaluator + delegation fallback + AsyncGuard.authorize_and_consume (FEAT-014), AsyncApprovalManager + approval gating + AsyncGuard.approve/reject (FEAT-015); service mode POST /list_authorized + /authorize_and_consume now engine-agnostic (SERVICE_API_VERSION unchanged at "v1"); ADR-0011 (sequential per-candidate evaluation) + ADR-0012 (mirror-not-redesign composition); auth-model.md + integration-guide.md updated with Phase 11 sections; impact-map updated with adr-0011, adr-0012, feat-014, feat-015, feat-018, async-parity, v0.12.0 topics).
- **2026-05-18**: Phase 11 planned — "Async Parity" (v0.12.0). Bundles FEAT-014 + FEAT-015 + FEAT-018 as async siblings of existing sync primitives. Phase files at `specs/phases/phase-11-async-parity/` (overview + plan + tasks + history seed). FEAT-014 / FEAT-015 promoted P2→P1 for the bundle. Prior Phase 11 (gRPC + non-Python SDKs) renumbered to Phase 12. Zero new abstractions, zero wire-contract changes, `SERVICE_API_VERSION` unchanged. ADR-0011 (sequential per-candidate evaluation) + ADR-0012 (mirror-not-redesign composition) to be authored during implementation.
- **2026-05-18**: FEAT-018 added to backlog (P1, open) — `AsyncGuard.list_authorized` async parity with sync `Guard.list_authorized`. Vendor-neutral library primitive aligned with industry-standard reverse-lookup APIs (OpenFGA `ListObjects`, Zanzibar/SpiceDB `LookupResources`, AWS Verified Permissions `BatchIsAuthorized`, Auth0 FGA, Cerbos `PlanResources`, Casbin). Detail doc at `specs/backlog/details/FEAT-018.md`.
- **2026-05-04**: Phase 10 brainstormed — slim scope locked: **HTTP service + Python SDK only** (gRPC + TS/Go SDKs → Phase 11). Auth: built-in API keys + open-shield JWT (`[shield]` extra) + BYO callable. Tenant from auth claim, `X-Tenant-ID` override gated by `cross_tenant_admin` scope. SDK: sync + async clients, namespaced API (`client.decisions.*`, `client.admin.*`), shared `_BaseClient`, idempotent-only retry. ADR-0009 + ADR-0010 to be written during implementation. Phase files at `specs/phases/phase-10-service-mode-sdk/`.
- **2026-04-28**: Phase 9 completed — v0.10.0 released (1069 tests, 94% coverage; FEAT-016 async SQL backend wired in `build_async_guard()` for `sqlite+aiosqlite://` and `postgresql+asyncpg://`; FEAT-017 resource-scoped RBAC via `resource_match` on `assign_role`/`revoke_role`; ENH-020 typed public `sync_store` property on all 6 async in-memory stores; ENH-021 `PolicyAdmin.check_relationship()` + `POST /relationships/check` AdminRouter endpoint; zero breaking changes; all 4 cerebrio-sapience P0 blockers cleared)
- **2026-04-20**: Phase 8 completed — v0.9.0 released (1037 tests, 94% coverage; TrustGateEvaluator — 5th evaluator with chain-aware trust scopes (immediate/all/root); OperationChainConfig — action-pattern evaluator selection via fnmatch; ActorType.ROBOT + ActorType.EDGE_DEVICE; EvaluatorPort.evaluator_type abstract property on all evaluators; Guard/AsyncGuard/factory wired; zero breaking changes)
- **2026-04-19**: Phase 7 completed — v0.8.0 released (959 tests, 94% coverage; Guard.from_config() factory for memory/SQLite/PostgreSQL; AsyncGuard with native async stores + AsyncReBACEvaluator; PolicyAdmin SDK: tenant-scoped CRUD for policies, roles, relationships, delegations, sessions; AdminRouter mountable FastAPI REST API; DB tooling: create_all_tables() + CLI (open-guard db init/schema) + DDL export; 8 async port ABCs + 6 async memory stores + 5 async SQL stores; [sql-async] optional extra; zero breaking changes)
- **2026-04-19**: Phase 6 completed — v0.7.0 released (806 tests, 97% coverage; RBAC sessions ENH-001: `Session` entity + `SessionStorePort` (memory + SQL) + `SessionManager` + session-aware RBAC + `session.*` ABAC namespace + `Guard(session_id=...)`; policy isolation FEAT-010: `ReadOnlyPolicyView` + `_trusted` taint marking + `trusted_only` modifier + 10-scenario adversarial suite; push revocation ENH-010: `RevocationStreamPort` + `InMemoryRevocationStream` + event emission; ADR-0006 + ADR-0007 + ADR-0008; Phase 6 integration guide section + executable mirrors, zero breaking changes)
- **2026-04-15**: Project management structure initialized
- **2026-04-16**: Phase 0 completed — v0.1.0 released (107 tests, 98% coverage)
- **2026-04-16**: Phase 1 completed — v0.2.0 released (178 tests, 98% coverage)
- **2026-04-17**: Phase 2 completed — v0.3.0 released (270 tests, 91% coverage; ReBAC + SQLAlchemy + ABAC enhancements)
- **2026-04-18**: Phase 3 completed — v0.4.0 released (406 tests, 98% coverage; OBO chains + tri-state Decision with async approval + DecisionTrace, zero breaking changes)
- **2026-04-18**: Phase 4 completed — v0.5.0 released (505 tests, 97% coverage; `Guard.list_authorized` via iterate-per-candidate + ReBAC native enumeration + new `CandidateResourcePort`; `MCPGuard` with chain-aware tool-call authz + parameter-level ABAC + optional `[mcp]` extra; `integration-guide.md` rewrite with executable mirrors; ADR-0001 + ADR-0002, zero breaking changes)
- **2026-04-19**: Phase 5 completed — v0.6.0 released (712 tests, 97% coverage; `Delegation` entity + `DelegationScope` + `DelegationStatus`; `DelegationManager` (delegate/revoke/renew/consume/expire_stale); `DelegationEvaluator` (scope match + re-check + memoization + list_contribution); `Guard` wired with delegation fallback + `authorize_and_consume` + proxy methods; `Policy.non_delegable` flag; `SelfDelegateOnly` default meta-authz; `Guard.list_authorized` delegation contribution; `MCPGuard.consume_tool_call_budget` + `attributed_delegation_ids`; CAS-safe counters (RLock in-memory, UPDATE WHERE in SQL); cascade revocation; chain-depth limits; `InMemoryDelegationStore` + `SQLAlchemyDelegationStore`; ADR-0003 + ADR-0004 + ADR-0005; Phase 5 integration guide section + executable mirrors, zero breaking changes)
