# Specs

> Spec-driven project management for open-guard.

## Structure

| Directory | Purpose |
|-----------|---------|
| `status.md` | Current phase, blockers, P0 items — **read this first** |
| `dependencies.md` | Cross-repo dependency map |
| `architecture/` | Long-lived design docs (auth model, policy engine, integration guide) |
| `backlog/` | All bugs, features, tech debt, enhancements — triage table + detail docs |
| `backlog/details/` | Per-item design sketches for complex backlog entries |
| `changelog/` | Monthly changelogs |
| `decisions/` | Architecture Decision Records (ADRs) + impact-map.json |
| `phases/` | Per-phase plans, tasks, history, retrospective + index.json |
| `planning/` | Roadmap and timeline |

## The Spec Flow

Specs-driven development here is a **three-layer flow** from rough idea to implemented feature. Each layer has a clear trigger; you only climb to the next when the trigger fires.

```
┌─────────────────────┐
│ 1. Backlog row      │  All items start here.
│    (table)          │  One-line triage entry in backlog.md.
└──────────┬──────────┘
           │  Item is complex / likely to be phased /
           │  touches architecture
           ▼
┌─────────────────────┐
│ 2. Backlog detail   │  A spec-in-miniature: problem,
│    (details/*.md)   │  motivation, solution sketch,
│                     │  alternatives, open questions,
│                     │  references, graduation criteria.
└──────────┬──────────┘
           │  A specific design choice gets locked
           ▼
┌─────────────────────┐
│ 3. ADR              │  Permanent record of the decision,
│    (decisions/*.md) │  why it was made, what it rules out.
└──────────┬──────────┘
           │  Phase pulls the item in
           ▼
┌─────────────────────┐
│ 4. Phase plan       │  Tasks reference the detail doc + ADRs.
│    (phases/N/*)     │  History records the journey.
│                     │  Retrospective closes the loop.
└─────────────────────┘
```

### Layer triggers

| Layer | Write when | File |
|-------|-----------|------|
| **Row** | Item first captured | `backlog/backlog.md` table |
| **Detail** | Item needs design thinking before a phase plans it | `backlog/details/<ID>.md` — use `TEMPLATE.md` |
| **ADR** | A specific choice is locked and must not drift | `decisions/NNNN-title.md` — use `0000-template.md` |
| **Phase plan** | Work actually starts | `phases/phase-N-*/plan.md` |

### What NOT to do

- Don't jump straight from a backlog row to a phase plan on a complex item — the design thinking belongs in a detail doc first, so brainstorming is grounded.
- Don't put locked decisions in detail docs — those are ADR territory. Detail docs sketch direction; ADRs record commitment.
- Don't duplicate content across layers — each layer links the previous.
- Don't update architecture docs mid-phase — that's `/sync-docs` territory at phase close (see CLAUDE.md Rule 9).
