"""open-guard: Vendor-neutral authorization library for all actor types."""

from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.adapters.config import OpenGuardConfig
from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.evaluators.trust import TrustGateEvaluator
from open_guard.adapters.factory import build_async_guard, build_guard
from open_guard.adapters.stores.async_memory import (
    AsyncInMemoryApprovalStore,
    AsyncInMemoryDelegationStore,
    AsyncInMemoryPolicyStore,
    AsyncInMemoryRelationshipStore,
    AsyncInMemorySessionStore,
    AsyncInMemoryTaskStore,
)
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    ApprovalDecision,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
    AuthorizationRequest,
    ConditionResult,
    Cursor,
    Decision,
    DecisionStatus,
    DecisionTrace,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Evaluation,
    EvaluatorTrace,
    ListRequest,
    ListResult,
    OperationChainConfig,
    OperationRule,
    PermissionRule,
    Policy,
    PolicyEffect,
    PolicyMatch,
    RelationMatch,
    RelationTuple,
    Resource,
    RevocationEvent,
    RevocationEventType,
    Session,
    SessionStatus,
    Subject,
    SubjectSnapshot,
    Task,
    TaskStatus,
    TypeDefinition,
)
from open_guard.domain.exceptions import (
    ApprovalError,
    AuthorizationDeniedError,
    ChainDepthExceededError,
    ConfigurationError,
    DelegateNotPermittedError,
    DelegationChainDepthExceededError,
    DelegationNotFoundError,
    DelegationRevokedError,
    LeaseExpiredError,
    OpenGuardError,
    PolicyError,
    RelationshipError,
    RevocationError,
    SessionError,
    SessionExpiredError,
    SessionNotFoundError,
    TaskError,
    UsageExhaustedError,
)
from open_guard.domain.ports.approval_store import ApprovalStorePort
from open_guard.domain.ports.async_approval_store import AsyncApprovalStorePort
from open_guard.domain.ports.async_candidate_resource import AsyncCandidateResourcePort
from open_guard.domain.ports.async_delegation_store import AsyncDelegationStorePort
from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
from open_guard.domain.ports.async_policy_store import AsyncPolicyStorePort
from open_guard.domain.ports.async_relationship_store import AsyncRelationshipStorePort
from open_guard.domain.ports.async_session_store import AsyncSessionStorePort
from open_guard.domain.ports.async_task_store import AsyncTaskStorePort
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.ports.delegation_store import DelegationStorePort
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.policy_store import PolicyStorePort
from open_guard.domain.ports.relationship_store import RelationshipStorePort
from open_guard.domain.ports.revocation_stream import RevocationStreamPort
from open_guard.domain.ports.session_store import SessionStorePort
from open_guard.domain.ports.task_store import TaskStorePort
from open_guard.domain.services.approval_manager import ApprovalManager
from open_guard.domain.services.async_guard import AsyncGuard
from open_guard.domain.services.async_policy_router import AsyncPolicyRouter
from open_guard.domain.services.delegation_manager import DelegationManager
from open_guard.domain.services.guard import Guard
from open_guard.domain.services.policy_router import ReadOnlyPolicyView
from open_guard.domain.services.session_manager import SessionManager
from open_guard.domain.services.task_manager import TaskManager

__version__ = "0.12.5"

# Extras-gated re-exports. Each block depends on an optional extra and is
# wrapped in try/except so the bare ``import open_guard`` always succeeds.
# Names only appear at the top level when the corresponding extra is installed.

try:  # [fastapi] / [service] — AdminRouter requires fastapi
    from open_guard.api.fastapi.admin_router import AdminRouter  # noqa: F401
except ImportError:  # pragma: no cover — extras-gated
    pass

try:  # [sql] / [sql-async] — db helpers require sqlalchemy
    from open_guard.db import create_all_tables, get_ddl  # noqa: F401
except ImportError:  # pragma: no cover — extras-gated
    pass

try:  # [client] — SDK requires httpx
    from open_guard.client.async_client import AsyncOpenGuardClient  # noqa: F401
    from open_guard.client.base import (  # noqa: F401
        ApiKey,
        BearerToken,
        ClientAuth,
    )
    from open_guard.client.exceptions import (  # noqa: F401
        OpenGuardError as ClientOpenGuardError,
    )
    from open_guard.client.retry import RetryPolicy  # noqa: F401
    from open_guard.client.sync_client import OpenGuardClient  # noqa: F401
except ImportError:  # pragma: no cover — extras-gated
    pass

__all__ = [
    "ABACEvaluator",
    "Action",
    "ActorType",
    # Phase 7 — Admin SDK & Router
    "AdminRouter",
    # Phase 3 approval (FEAT-007)
    "ApprovalDecision",
    "ApprovalError",
    "ApprovalManager",
    "ApprovalRequest",
    "ApprovalRequirement",
    "ApprovalStatus",
    "ApprovalStorePort",
    # Phase 7 — Async ports
    "AsyncApprovalStorePort",
    "AsyncCandidateResourcePort",
    "AsyncDelegationStorePort",
    "AsyncEvaluatorPort",
    # Phase 7 — AsyncGuard
    "AsyncGuard",
    # Phase 7 — Async memory stores
    "AsyncInMemoryApprovalStore",
    "AsyncInMemoryDelegationStore",
    "AsyncInMemoryPolicyStore",
    "AsyncInMemoryRelationshipStore",
    "AsyncInMemorySessionStore",
    "AsyncInMemoryTaskStore",
    # Phase 7 — Async evaluator & router
    "AsyncPolicyRouter",
    "AsyncPolicyStorePort",
    "AsyncReBACEvaluator",
    "AsyncRelationshipStorePort",
    "AsyncSessionStorePort",
    "AsyncTaskStorePort",
    "AuthorizationDeniedError",
    "AuthorizationRequest",
    # Phase 4 list_authorized (FEAT-006)
    "CandidateResourcePort",
    # Phase 3 chain (FEAT-005)
    "ChainDepthExceededError",
    # Phase 3 trace (FEAT-008)
    "ConditionResult",
    "ConfigurationError",
    "Cursor",
    "Decision",
    "DecisionStatus",
    "DecisionTrace",
    # Phase 5 delegation (FEAT-001/002/003)
    "DelegateNotPermittedError",
    "Delegation",
    "DelegationChainDepthExceededError",
    "DelegationManager",
    "DelegationNotFoundError",
    "DelegationRevokedError",
    "DelegationScope",
    "DelegationStatus",
    "DelegationStorePort",
    "Evaluation",
    "EvaluatorPort",
    "EvaluatorTrace",
    "Guard",
    "InMemoryApprovalStore",
    "InMemoryDelegationStore",
    "InMemoryPolicyStore",
    "InMemoryRelationshipStore",
    "InMemoryRevocationStream",
    "InMemorySessionStore",
    "InMemoryTaskStore",
    "LeaseExpiredError",
    "ListRequest",
    "ListResult",
    "OpenGuardConfig",
    "OpenGuardError",
    # Phase 8 — OperationChain
    "OperationChainConfig",
    "OperationRule",
    "PermissionRule",
    "Policy",
    # Phase 7 — Admin SDK
    "PolicyAdmin",
    "PolicyEffect",
    "PolicyError",
    "PolicyMatch",
    "PolicyStorePort",
    "RBACEvaluator",
    "ReBACEvaluator",
    "ReadOnlyPolicyView",
    "RelationMatch",
    "RelationTuple",
    "RelationshipError",
    "RelationshipStorePort",
    "Resource",
    "RevocationError",
    "RevocationEvent",
    "RevocationEventType",
    "RevocationStreamPort",
    "Session",
    "SessionError",
    "SessionExpiredError",
    "SessionManager",
    "SessionNotFoundError",
    "SessionStatus",
    "SessionStorePort",
    "Subject",
    "SubjectSnapshot",
    "TBACEvaluator",
    "Task",
    "TaskError",
    "TaskManager",
    "TaskStatus",
    "TaskStorePort",
    # Phase 8 — TrustGateEvaluator
    "TrustGateEvaluator",
    "TypeDefinition",
    "UsageExhaustedError",
    # Phase 7 — Factory helpers
    "build_async_guard",
    "build_guard",
    # Phase 7 — DB helpers
    "create_all_tables",
    "get_ddl",
]
