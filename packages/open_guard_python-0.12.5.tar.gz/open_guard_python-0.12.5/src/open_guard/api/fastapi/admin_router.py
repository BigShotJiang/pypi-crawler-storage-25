"""Mountable FastAPI router for open-guard administration (Phase 7)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query

from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.api.fastapi.schemas import (
    AddRelationshipRequest,
    AssignRoleRequest,
    CheckRelationshipRequest,
    CreateDelegationRequest,
    CreatePolicyRequest,
    CreateSessionRequest,
    DelegationResponse,
    HealthResponse,
    PolicyResponse,
    RelationshipResponse,
    SessionResponse,
)


class AdminRouter(APIRouter):
    """Mountable FastAPI router for open-guard administration.

    Usage::

        from open_guard.api.fastapi.admin_router import AdminRouter
        app.include_router(AdminRouter(admin=admin), prefix="/admin")
    """

    def __init__(self, admin: PolicyAdmin, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._admin = admin
        self._register_routes()

    def _register_routes(self) -> None:
        # -- Policies --

        @self.post("/policies", response_model=PolicyResponse, status_code=201)
        def create_policy(req: CreatePolicyRequest) -> Any:
            return self._admin.create_policy(
                tenant_id=req.tenant_id,
                evaluator_type=req.evaluator_type,
                subject_match=req.subject_match,
                action_match=req.action_match,
                resource_match=req.resource_match,
                conditions=req.conditions,
                effect=req.effect,
                priority=req.priority,
            )

        @self.get("/policies", response_model=list[PolicyResponse])
        def list_policies(
            tenant_id: str = Query(...),
            evaluator_type: str | None = Query(None),
        ) -> Any:
            return self._admin.list_policies(
                tenant_id, evaluator_type=evaluator_type
            )

        @self.get("/policies/{policy_id}", response_model=PolicyResponse)
        def get_policy(
            policy_id: str, tenant_id: str = Query(...)
        ) -> Any:
            policy = self._admin.get_policy(policy_id, tenant_id)
            if not policy:
                raise HTTPException(status_code=404, detail="Policy not found")
            return policy

        @self.delete("/policies/{policy_id}", status_code=204)
        def delete_policy(
            policy_id: str, tenant_id: str = Query(...)
        ) -> None:
            try:
                self._admin.delete_policy(policy_id, tenant_id)
            except Exception:
                raise HTTPException(
                    status_code=404, detail="Policy not found"
                ) from None

        # -- Roles --

        @self.post("/roles", response_model=PolicyResponse, status_code=201)
        def assign_role(req: AssignRoleRequest) -> Any:
            return self._admin.assign_role(
                tenant_id=req.tenant_id,
                subject_id=req.subject_id,
                role=req.role,
                resource_type=req.resource_type,
                resource_match=req.resource_match,
                actions=req.actions,
            )

        # -- Relationships --

        @self.post(
            "/relationships",
            response_model=RelationshipResponse,
            status_code=201,
        )
        def add_relationship(req: AddRelationshipRequest) -> Any:
            return self._admin.add_relationship(
                tenant_id=req.tenant_id,
                subject_id=req.subject_id,
                subject_type=req.subject_type,
                relation=req.relation,
                object_type=req.object_type,
                object_id=req.object_id,
                subject_relation=req.subject_relation,
            )

        @self.get(
            "/relationships", response_model=list[RelationshipResponse]
        )
        def list_relationships(
            tenant_id: str = Query(...),
            object_type: str | None = Query(None),
            subject_id: str | None = Query(None),
        ) -> Any:
            return self._admin.list_relationships(
                tenant_id,
                object_type=object_type,
                subject_id=subject_id,
            )

        @self.post("/relationships/check")
        def check_relationship(req: CheckRelationshipRequest) -> dict:
            result = self._admin.check_relationship(
                tenant_id=req.tenant_id,
                subject_id=req.subject_id,
                subject_type=req.subject_type,
                relation=req.relation,
                object_type=req.object_type,
                object_id=req.object_id,
            )
            return {"exists": result}

        @self.delete("/relationships/{tuple_id}", status_code=204)
        def delete_relationship(
            tuple_id: str, tenant_id: str = Query(...)
        ) -> None:
            try:
                self._admin.delete_relationship(tuple_id, tenant_id)
            except Exception:
                raise HTTPException(
                    status_code=404, detail="Relationship not found"
                ) from None

        # -- Delegations --

        @self.post(
            "/delegations",
            response_model=DelegationResponse,
            status_code=201,
        )
        def create_delegation(req: CreateDelegationRequest) -> Any:
            scopes = [
                {
                    "action_match": s.action_match,
                    "resource_type": s.resource_type,
                    "resource_match": s.resource_match,
                    "conditions": s.conditions,
                }
                for s in req.scopes
            ]
            return self._admin.create_delegation(
                tenant_id=req.tenant_id,
                from_subject_id=req.from_subject_id,
                to_subject_id=req.to_subject_id,
                scopes=scopes,
                from_subject_type=req.from_subject_type,
                to_subject_type=req.to_subject_type,
                max_uses=req.max_uses,
                budget=req.budget,
                expires_at=req.expires_at,
            )

        @self.get("/delegations", response_model=list[DelegationResponse])
        def list_delegations(
            tenant_id: str = Query(...),
            subject_id: str | None = Query(None),
        ) -> Any:
            if not subject_id:
                raise HTTPException(
                    status_code=400,
                    detail="subject_id query parameter is required",
                )
            return self._admin.list_delegations(
                tenant_id, subject_id=subject_id
            )

        @self.delete("/delegations/{delegation_id}", status_code=204)
        def revoke_delegation(
            delegation_id: str, tenant_id: str = Query(...)
        ) -> None:
            try:
                self._admin.revoke_delegation(delegation_id, tenant_id)
            except Exception:
                raise HTTPException(
                    status_code=404, detail="Delegation not found"
                ) from None

        # -- Sessions --

        @self.post(
            "/sessions", response_model=SessionResponse, status_code=201
        )
        def create_session(req: CreateSessionRequest) -> Any:
            return self._admin.create_session(
                tenant_id=req.tenant_id,
                subject_id=req.subject_id,
                activated_roles=req.activated_roles,
                metadata=req.metadata,
            )

        @self.delete("/sessions/{session_id}", status_code=204)
        def deactivate_session(
            session_id: str, tenant_id: str = Query(...)
        ) -> None:
            try:
                self._admin.deactivate_session(session_id, tenant_id)
            except Exception:
                raise HTTPException(
                    status_code=404, detail="Session not found"
                ) from None

        @self.get("/sessions", response_model=list[SessionResponse])
        def list_sessions(
            tenant_id: str = Query(...),
            subject_id: str | None = Query(None),
        ) -> Any:
            if not subject_id:
                raise HTTPException(
                    status_code=400,
                    detail="subject_id query parameter is required",
                )
            return self._admin.list_sessions(
                tenant_id, subject_id=subject_id
            )

        # -- Health --

        @self.get("/health", response_model=HealthResponse)
        def health() -> Any:
            import open_guard

            return HealthResponse(
                status="ok", version=open_guard.__version__
            )
