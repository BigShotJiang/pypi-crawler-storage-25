"""FastAPI dependencies for open-guard authorization."""

from __future__ import annotations

from fastapi import Depends, HTTPException, Request

from open_guard.domain.entities import (
    Action,
    ActorType,
    Decision,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard


def get_guard(request: Request) -> Guard:
    """Retrieve the Guard instance from request.state.

    Requires OpenGuardMiddleware to be installed.
    """
    if not hasattr(request.state, "guard"):
        raise HTTPException(
            status_code=500,
            detail="OpenGuardMiddleware not configured",
        )
    guard: Guard = request.state.guard
    return guard


def get_subject(request: Request) -> Subject:
    """Retrieve the Subject from request.state.

    Uses the bridge-converted subject if available (from open-shield-python),
    otherwise raises 401.
    """
    if hasattr(request.state, "open_guard_subject"):
        subject: Subject = request.state.open_guard_subject
        return subject
    raise HTTPException(status_code=401, detail="Authentication required")


def get_optional_subject(request: Request) -> Subject | None:
    """Retrieve the Subject if available, or None."""
    if hasattr(request.state, "open_guard_subject"):
        subject: Subject = request.state.open_guard_subject
        return subject
    return None


class RequirePermission:
    """FastAPI dependency that enforces an authorization check.

    Usage:
        @app.get("/docs/{doc_id}")
        def get_doc(
            doc_id: str,
            _auth=Depends(RequirePermission("read", "document")),
        ):
            ...
    """

    def __init__(self, action: str, resource_type: str) -> None:
        self.action = action
        self.resource_type = resource_type

    def __call__(
        self,
        request: Request,
        guard: Guard = Depends(get_guard),
        subject: Subject = Depends(get_subject),
    ) -> Decision:
        # Extract resource ID from path params if available
        resource_id = ""
        if request.path_params:
            # Use first path param as resource ID
            resource_id = str(next(iter(request.path_params.values())))

        # Extract tenant_id from subject attributes
        tenant_id = subject.attributes.get("tenant_id", "")
        if not tenant_id:
            raise HTTPException(status_code=403, detail="Access denied")

        decision = guard.authorize(
            subject=subject,
            action=Action(name=self.action),
            resource=Resource(id=resource_id, resource_type=self.resource_type),
            tenant_id=str(tenant_id),
        )

        if not decision.allowed:
            raise HTTPException(status_code=403, detail="Access denied")

        return decision


class RequireActor:
    """FastAPI dependency that restricts access by actor type.

    Usage:
        @app.get("/human-only")
        def human_only(_auth=Depends(RequireActor(ActorType.USER))):
            ...
    """

    def __init__(self, *allowed_types: ActorType) -> None:
        self.allowed_types = set(allowed_types)

    def __call__(self, subject: Subject = Depends(get_subject)) -> Subject:
        if subject.actor_type not in self.allowed_types:
            raise HTTPException(status_code=403, detail="Access denied")
        return subject
