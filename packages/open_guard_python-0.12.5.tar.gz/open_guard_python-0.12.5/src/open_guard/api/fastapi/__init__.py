"""FastAPI integration for open-guard."""

from open_guard.api.fastapi.admin_router import AdminRouter
from open_guard.api.fastapi.dependencies import (
    RequireActor,
    RequirePermission,
    get_guard,
    get_optional_subject,
    get_subject,
)
from open_guard.api.fastapi.middleware import OpenGuardMiddleware

__all__ = [
    "AdminRouter",
    "OpenGuardMiddleware",
    "RequireActor",
    "RequirePermission",
    "get_guard",
    "get_optional_subject",
    "get_subject",
]
