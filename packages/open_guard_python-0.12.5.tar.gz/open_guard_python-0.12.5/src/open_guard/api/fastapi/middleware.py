"""FastAPI middleware for open-guard authorization."""

from __future__ import annotations

from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

from open_guard.domain.entities import ActorType, Subject
from open_guard.domain.services.guard import Guard


class OpenGuardMiddleware(BaseHTTPMiddleware):
    """ASGI middleware that attaches a Guard instance to request.state.

    If open-shield-python's UserContext is found on request.state,
    automatically converts it to a Subject.

    Usage:
        app.add_middleware(OpenGuardMiddleware, guard=guard)
    """

    def __init__(self, app: Any, guard: Guard) -> None:
        super().__init__(app)
        self.guard = guard

    async def dispatch(
        self, request: Request, call_next: RequestResponseEndpoint
    ) -> Response:
        request.state.guard = self.guard

        # Bridge: if open-shield-python attached a UserContext, convert to Subject
        if hasattr(request.state, "user_context"):
            user_context = request.state.user_context
            request.state.open_guard_subject = _subject_from_user_context(user_context)

        return await call_next(request)


def _subject_from_user_context(user_context: Any) -> Subject:
    """Convert open-shield-python's UserContext to an open-guard Subject."""
    user = user_context.user
    tenant = user_context.tenant

    attributes: dict[str, Any] = {
        "roles": list(user.roles) if hasattr(user, "roles") else [],
        "scopes": list(user.scopes) if hasattr(user, "scopes") else [],
    }

    if tenant is not None:
        attributes["tenant_id"] = tenant.tenant_id

    # Map metadata
    metadata: dict[str, Any] = {}
    if hasattr(user, "metadata"):
        metadata = dict(user.metadata)

    actor_type_str = getattr(user, "actor_type", "user")
    try:
        actor_type = ActorType(actor_type_str)
    except ValueError:
        actor_type = ActorType.USER

    return Subject(
        id=user.id,
        actor_type=actor_type,
        attributes=attributes,
        metadata=metadata,
    )
