"""Request/response Pydantic models for the admin REST API (Phase 7)."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal
from typing import Any

from pydantic import BaseModel, Field

# -- Policies --


class CreatePolicyRequest(BaseModel):
    """Create a new authorization policy."""

    tenant_id: str
    evaluator_type: str
    subject_match: dict[str, Any] = Field(default_factory=dict)
    action_match: str | list[str] = "*"
    resource_match: dict[str, Any] = Field(default_factory=dict)
    conditions: dict[str, Any] = Field(default_factory=dict)
    effect: str = "allow"
    priority: int = 0


class PolicyResponse(BaseModel):
    """Serialized policy returned by the API."""

    id: str
    tenant_id: str
    evaluator_type: str
    subject_match: dict[str, Any]
    action_match: str | list[str]
    resource_match: dict[str, Any]
    conditions: dict[str, Any]
    effect: str
    priority: int

    model_config = {"from_attributes": True}


# -- Roles --


class AssignRoleRequest(BaseModel):
    """Assign a role to a subject."""

    tenant_id: str
    subject_id: str
    role: str
    resource_type: str | None = None
    resource_match: dict[str, Any] | None = None
    actions: list[str] | None = None


# -- Relationships --


class CheckRelationshipRequest(BaseModel):
    """Check if a relationship exists (Zanzibar Check operation)."""

    tenant_id: str
    subject_id: str
    subject_type: str = "user"
    relation: str
    object_type: str
    object_id: str


class AddRelationshipRequest(BaseModel):
    """Add a ReBAC relationship tuple."""

    tenant_id: str
    subject_id: str
    subject_type: str = "user"
    relation: str
    object_type: str
    object_id: str
    subject_relation: str | None = None


class RelationshipResponse(BaseModel):
    """Serialized relationship tuple returned by the API."""

    id: str
    tenant_id: str
    object_type: str
    object_id: str
    relation: str
    subject_type: str
    subject_id: str
    subject_relation: str | None = None

    model_config = {"from_attributes": True}


# -- Delegations --


class DelegationScopeRequest(BaseModel):
    """A single scope entry within a delegation request."""

    action_match: str | list[str]
    resource_type: str
    resource_match: dict[str, Any] = Field(default_factory=dict)
    conditions: dict[str, Any] = Field(default_factory=dict)


class CreateDelegationRequest(BaseModel):
    """Create a new delegation from one subject to another."""

    tenant_id: str
    from_subject_id: str
    to_subject_id: str
    scopes: list[DelegationScopeRequest] = Field(..., min_length=1)
    from_subject_type: str = "user"
    to_subject_type: str = "user"
    max_uses: int | None = None
    budget: Decimal | None = None
    expires_at: datetime | None = None


class DelegationResponse(BaseModel):
    """Serialized delegation returned by the API."""

    id: str
    tenant_id: str
    from_subject_id: str
    to_subject_id: str
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}


# -- Sessions --


class CreateSessionRequest(BaseModel):
    """Create an RBAC session with activated roles."""

    tenant_id: str
    subject_id: str
    activated_roles: list[str] = Field(..., min_length=1)
    expires_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SessionResponse(BaseModel):
    """Serialized RBAC session returned by the API."""

    id: str
    tenant_id: str
    subject_id: str
    activated_roles: list[str]
    status: str
    created_at: datetime
    expires_at: datetime | None = None
    deactivated_at: datetime | None = None

    model_config = {"from_attributes": True}


# -- Pagination --


class PaginatedResponse(BaseModel):
    """Wrapper for paginated list endpoints."""

    items: list[Any]
    total: int


# -- Health --


class HealthResponse(BaseModel):
    """Health check response."""

    status: str = "ok"
    version: str
