"""open-guard CLI — database management commands."""
from __future__ import annotations

import click


@click.group()
def cli() -> None:
    """open-guard — authorization management CLI."""


@cli.group()
def db() -> None:
    """Database schema management."""


@db.command()
@click.option("--dsn", required=True, help="Database connection string (e.g. sqlite:///local.db)")
def init(dsn: str) -> None:
    """Create all open-guard tables."""
    from sqlalchemy import create_engine

    from open_guard.db import create_all_tables

    engine = create_engine(dsn)
    create_all_tables(engine)
    click.echo("Tables created successfully.")


@db.command()
@click.option(
    "--dialect",
    default="sqlite",
    type=click.Choice(["sqlite", "postgresql"]),
    help="SQL dialect for DDL output.",
)
def schema(dialect: str) -> None:
    """Output DDL SQL for all open-guard tables."""
    from open_guard.db import get_ddl

    click.echo(get_ddl(dialect=dialect))
