"""Service-mode FastAPI app factory (Phase 10).

Usage::

    from open_guard import build_guard
    from open_guard.service.app import create_app, ServiceConfig
    from open_guard.service.auth import ApiKeyAuth, InMemoryApiKeyStore

    guard = build_guard()
    auth = ApiKeyAuth(InMemoryApiKeyStore())
    app = create_app(guard=guard, auth=auth)

    # uvicorn open_guard.service.app:create_app --factory  (with kwargs via env)

The factory mounts a :class:`DecisionRouter` and (optionally) the
existing :class:`AdminRouter` under a configurable prefix (default
``/v1``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from fastapi import Depends, FastAPI

from open_guard.domain.services.async_guard import AsyncGuard
from open_guard.domain.services.guard import Guard
from open_guard.service.auth import AuthBackend, CallerContext
from open_guard.service.decision_router import build_decision_router
from open_guard.service.errors import install_exception_handlers
from open_guard.service.tenant import make_tenant_dep
from open_guard.service.version import DEFAULT_PREFIX

if TYPE_CHECKING:
    from open_guard.adapters.admin.sdk import PolicyAdmin


@dataclass
class ServiceConfig:
    """Configuration for :func:`create_app`.

    Attributes:
        prefix: Mount prefix for both routers (default ``/v1``).
        title: OpenAPI title.
        docs_url: Swagger UI path. Set ``None`` to disable.
        openapi_url: OpenAPI JSON path. Set ``None`` to disable.
        expose_admin: When ``True`` and ``admin`` is provided to
            :func:`create_app`, mount the :class:`AdminRouter`.
    """

    prefix: str = DEFAULT_PREFIX
    title: str = "open-guard"
    docs_url: str | None = "/docs"
    openapi_url: str | None = "/openapi.json"
    expose_admin: bool = True


def create_app(
    *,
    guard: Guard | AsyncGuard,
    auth: AuthBackend,
    admin: PolicyAdmin | None = None,
    config: ServiceConfig | None = None,
) -> FastAPI:
    """Build and return a FastAPI app exposing open-guard over HTTP."""
    if not isinstance(guard, (Guard, AsyncGuard)):
        raise TypeError(
            "create_app(guard=...) must be a Guard or AsyncGuard instance"
        )
    if auth is None:
        raise TypeError("create_app(auth=...) is required")

    cfg = config or ServiceConfig()
    app = FastAPI(
        title=cfg.title,
        docs_url=cfg.docs_url,
        openapi_url=cfg.openapi_url,
    )
    install_exception_handlers(app)

    decision_router = build_decision_router(guard=guard, auth=auth)
    app.include_router(decision_router, prefix=cfg.prefix)

    if cfg.expose_admin and admin is not None:
        from open_guard.api.fastapi.admin_router import AdminRouter

        tenant_dep = make_tenant_dep(auth)

        async def _admin_guard(
            ctx: tuple[CallerContext, str] = Depends(tenant_dep),
        ) -> str:
            return ctx[1]

        admin_router = AdminRouter(
            admin=admin, dependencies=[Depends(_admin_guard)]
        )
        app.include_router(
            admin_router, prefix=f"{cfg.prefix}/admin"
        )

    return app
