"""DecisionRouter — runtime decision endpoints.

Endpoints registered for both sync and async guards (Phase 11 / FEAT-018
+ FEAT-014 closed the async parity gap):

- ``POST /authorize``
- ``POST /authorize/traced``
- ``POST /list_authorized``
- ``POST /authorize_and_consume``

The router is the only place that touches ``Guard`` / ``AsyncGuard``
directly. All inputs flow through the auth + tenant dependency.
"""

from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends

from open_guard.domain.entities import Decision, DecisionStatus
from open_guard.domain.services.async_guard import AsyncGuard
from open_guard.domain.services.guard import Guard
from open_guard.service.auth import AuthBackend, CallerContext
from open_guard.service.schemas import (
    AuthorizeAndConsumeRequest,
    AuthorizeAndConsumeResponse,
    AuthorizeRequest,
    AuthorizeResponse,
    AuthorizeTracedResponse,
    ListAuthorizedRequest,
    ListAuthorizedResponse,
)
from open_guard.service.tenant import make_tenant_dep


def _decision_to_response(decision: Decision) -> AuthorizeResponse:
    return AuthorizeResponse(
        status=decision.status.value,
        allowed=decision.allowed,
        reason=decision.reason,
        approval_request_id=decision.approval_request_id,
    )


def _consumed_delegation_ids(decision: Decision) -> list[str]:
    if decision.status != DecisionStatus.ALLOWED:
        return []
    ids: list[str] = []
    for ev in decision.evaluations:
        if ev.evaluator == "delegation":
            ids.extend(ev.matched_policies)
    return ids


def build_decision_router(
    *, guard: Guard | AsyncGuard, auth: AuthBackend
) -> APIRouter:
    """Construct the DecisionRouter bound to a ``Guard`` or ``AsyncGuard``."""
    router = APIRouter(tags=["decisions"])
    tenant_dep = make_tenant_dep(auth)
    is_async = isinstance(guard, AsyncGuard)

    async def _authorize(
        body: AuthorizeRequest, tenant_id: str
    ) -> Decision:
        if is_async:
            assert isinstance(guard, AsyncGuard)
            return await guard.authorize(
                body.subject,
                body.action,
                body.resource,
                tenant_id,
                body.context,
                session_id=body.session_id,
            )
        assert isinstance(guard, Guard)
        return await asyncio.to_thread(
            guard.authorize,
            body.subject,
            body.action,
            body.resource,
            tenant_id,
            body.context,
            session_id=body.session_id,
        )

    @router.post("/authorize", response_model=AuthorizeResponse)
    async def authorize(
        body: AuthorizeRequest,
        ctx: tuple[CallerContext, str] = Depends(tenant_dep),
    ) -> AuthorizeResponse:
        _, tenant_id = ctx
        decision = await _authorize(body, tenant_id)
        return _decision_to_response(decision)

    @router.post(
        "/authorize/traced", response_model=AuthorizeTracedResponse
    )
    async def authorize_traced(
        body: AuthorizeRequest,
        ctx: tuple[CallerContext, str] = Depends(tenant_dep),
    ) -> AuthorizeTracedResponse:
        _, tenant_id = ctx
        if is_async:
            assert isinstance(guard, AsyncGuard)
            decision, trace = await guard.authorize_traced(
                body.subject,
                body.action,
                body.resource,
                tenant_id,
                body.context,
                session_id=body.session_id,
            )
        else:
            assert isinstance(guard, Guard)
            decision, trace = await asyncio.to_thread(
                guard.authorize_traced,
                body.subject,
                body.action,
                body.resource,
                tenant_id,
                body.context,
                session_id=body.session_id,
            )
        base = _decision_to_response(decision)
        return AuthorizeTracedResponse(
            **base.model_dump(),
            trace=trace.model_dump(mode="json"),
        )

    @router.post("/list_authorized", response_model=ListAuthorizedResponse)
    async def list_authorized(
        body: ListAuthorizedRequest,
        ctx: tuple[CallerContext, str] = Depends(tenant_dep),
    ) -> ListAuthorizedResponse:
        _, tenant_id = ctx
        if is_async:
            assert isinstance(guard, AsyncGuard)
            result = await guard.list_authorized(
                body.subject,
                body.action,
                body.resource_type,
                tenant_id,
                body.prefilter or None,
                body.limit,
                body.cursor,
                body.context or None,
            )
        else:
            assert isinstance(guard, Guard)
            result = await asyncio.to_thread(
                guard.list_authorized,
                body.subject,
                body.action,
                body.resource_type,
                tenant_id,
                body.prefilter or None,
                body.limit,
                body.cursor,
                body.context or None,
            )
        return ListAuthorizedResponse(
            resource_ids=list(result.ids),
            next_cursor=result.next_cursor,
        )

    @router.post(
        "/authorize_and_consume",
        response_model=AuthorizeAndConsumeResponse,
    )
    async def authorize_and_consume(
        body: AuthorizeAndConsumeRequest,
        ctx: tuple[CallerContext, str] = Depends(tenant_dep),
    ) -> AuthorizeAndConsumeResponse:
        _, tenant_id = ctx
        if is_async:
            assert isinstance(guard, AsyncGuard)
            decision = await guard.authorize_and_consume(
                body.subject,
                body.action,
                body.resource,
                tenant_id,
                body.context,
                amount=body.amount,
                cost=body.cost,
            )
        else:
            assert isinstance(guard, Guard)
            decision = await asyncio.to_thread(
                guard.authorize_and_consume,
                body.subject,
                body.action,
                body.resource,
                tenant_id,
                body.context,
                amount=body.amount,
                cost=body.cost,
            )
        base = _decision_to_response(decision)
        return AuthorizeAndConsumeResponse(
            **base.model_dump(),
            consumed_delegation_ids=_consumed_delegation_ids(decision),
        )

    return router
