"""Pydantic request/response schemas for the DecisionRouter (Phase 10)."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from pydantic import BaseModel, Field

from open_guard.domain.entities import Action, Resource, Subject


class AuthorizeRequest(BaseModel):
    """Request body for ``POST /v1/authorize`` and friends."""

    subject: Subject
    action: Action
    resource: Resource
    session_id: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)


class AuthorizeResponse(BaseModel):
    status: str
    allowed: bool
    reason: str = ""
    approval_request_id: str | None = None


class AuthorizeTracedResponse(AuthorizeResponse):
    trace: dict[str, Any]


class ListAuthorizedRequest(BaseModel):
    subject: Subject
    action: str
    resource_type: str
    cursor: str | None = None
    limit: int = Field(default=100, ge=1, le=1000)
    prefilter: dict[str, Any] = Field(default_factory=dict)
    context: dict[str, Any] = Field(default_factory=dict)


class ListAuthorizedResponse(BaseModel):
    resource_ids: list[str]
    next_cursor: str | None = None


class AuthorizeAndConsumeRequest(AuthorizeRequest):
    amount: int = 1
    cost: Decimal | None = None


class AuthorizeAndConsumeResponse(AuthorizeResponse):
    consumed_delegation_ids: list[str] = Field(default_factory=list)
