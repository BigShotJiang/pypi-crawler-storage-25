"""Service-mode wire-contract version constant (Phase 10).

Changes that break wire compatibility move under a new prefix
(``/v2/...``). Within the ``v1`` prefix, all changes must remain
backward compatible. See ADR-0009.
"""

from __future__ import annotations

SERVICE_API_VERSION = "v1"
DEFAULT_PREFIX = f"/{SERVICE_API_VERSION}"

__all__ = ["DEFAULT_PREFIX", "SERVICE_API_VERSION"]
