"""ShieldAuth — open-shield JWT authentication backend (Phase 10).

Optional. Requires ``pip install open-guard-python[shield]``.

Wraps an ``open_shield.domain.ports.TokenValidatorPort`` (typically
``open_shield.adapters.token_validator.PyJWTValidator``). Tenant,
identity, and scopes are extracted from the validated JWT claims.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fastapi import Request

from open_guard.service.errors import AuthenticationError

if TYPE_CHECKING:
    from open_shield.domain.ports import TokenValidatorPort

    from open_guard.service.auth import CallerContext


def _coerce_scopes(value: Any) -> frozenset[str]:
    if value is None:
        return frozenset()
    if isinstance(value, str):
        return frozenset(value.split())
    if isinstance(value, (list, tuple, set, frozenset)):
        return frozenset(str(v) for v in value)
    return frozenset()


class ShieldAuth:
    """Authenticate via an ``Authorization: Bearer <jwt>`` header validated
    by open-shield.

    The validator is *injected* — wire any open-shield-compatible
    ``TokenValidatorPort`` (most often ``PyJWTValidator``). Claim names
    are configurable for deployments using non-standard mappings.
    """

    def __init__(
        self,
        validator: TokenValidatorPort,
        *,
        tenant_claim: str = "tenant_id",
        identity_claim: str = "sub",
        scopes_claim: str = "scope",
    ) -> None:
        try:
            import open_shield.domain.ports  # noqa: F401 — install probe
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "ShieldAuth requires `pip install open-guard-python[shield]`"
            ) from exc
        self._validator = validator
        self._tenant_claim = tenant_claim
        self._identity_claim = identity_claim
        self._scopes_claim = scopes_claim

    async def authenticate(self, request: Request) -> CallerContext:
        from open_guard.service.auth import CallerContext

        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            raise AuthenticationError(
                "missing bearer token", code="missing_bearer_token"
            )
        token = header.removeprefix("Bearer ").strip()
        if not token:
            raise AuthenticationError(
                "missing bearer token", code="missing_bearer_token"
            )
        try:
            parsed = self._validator.validate_token(token)
        except Exception as exc:
            raise AuthenticationError(
                "invalid token", code="invalid_token"
            ) from exc

        claims: dict[str, Any] = getattr(parsed, "claims", parsed)  # type: ignore[assignment]
        if not isinstance(claims, dict):
            raise AuthenticationError(
                "invalid token claims", code="invalid_token_claims"
            )

        tenant = claims.get(self._tenant_claim)
        identity = claims.get(self._identity_claim)
        if tenant is None or identity is None:
            raise AuthenticationError(
                "token missing required claims",
                code="missing_required_claims",
                details={
                    "missing": [
                        c
                        for c, v in (
                            (self._tenant_claim, tenant),
                            (self._identity_claim, identity),
                        )
                        if v is None
                    ]
                },
            )
        return CallerContext(
            tenant_id=str(tenant),
            service_identity=str(identity),
            scopes=_coerce_scopes(claims.get(self._scopes_claim)),
        )
