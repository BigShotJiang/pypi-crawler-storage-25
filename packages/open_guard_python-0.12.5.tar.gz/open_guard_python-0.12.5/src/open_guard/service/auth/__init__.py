"""Pluggable authentication backends for service mode (Phase 10).

The :class:`AuthBackend` protocol authenticates *callers* of the service
(not the subjects being authorized). Concrete backends:

- :class:`ApiKeyAuth` — built-in, hash-stored API keys
- :class:`ShieldAuth` — open-shield JWT validation (optional ``[shield]`` extra)
- :class:`CallableAuth` — BYO callable for mTLS / custom JWT / proxy auth
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from fastapi import Request


@dataclass(frozen=True)
class CallerContext:
    """Identity of the calling service or operator.

    Distinct from the ``Subject`` being authorized: ``CallerContext``
    answers "which service is asking?", while the subject lives in the
    request body.
    """

    tenant_id: str
    service_identity: str
    scopes: frozenset[str] = field(default_factory=frozenset)

    def has_scope(self, name: str) -> bool:
        return name in self.scopes


@runtime_checkable
class AuthBackend(Protocol):
    """Protocol every auth backend implements.

    ``authenticate`` must raise :class:`AuthenticationError` on missing
    or invalid credentials; otherwise it returns a populated
    :class:`CallerContext`.
    """

    async def authenticate(self, request: Request) -> CallerContext: ...


from open_guard.service.auth.api_key import ApiKeyAuth  # noqa: E402
from open_guard.service.auth.api_key_store import (  # noqa: E402
    ApiKeyRecord,
    ApiKeyStorePort,
    InMemoryApiKeyStore,
)
from open_guard.service.auth.byo import CallableAuth  # noqa: E402

__all__ = [
    "ApiKeyAuth",
    "ApiKeyRecord",
    "ApiKeyStorePort",
    "AuthBackend",
    "CallableAuth",
    "CallerContext",
    "InMemoryApiKeyStore",
]
