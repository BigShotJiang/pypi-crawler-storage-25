"""FastAPI dependency factory for authentication (Phase 10)."""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from typing import Any

from fastapi import Request

from open_guard.service.auth import AuthBackend, CallerContext


def make_auth_dep(
    auth: AuthBackend,
) -> Callable[[Request], Coroutine[Any, Any, CallerContext]]:
    """Return a FastAPI dependency that resolves to a :class:`CallerContext`.

    Endpoints wire this via ``Depends(make_auth_dep(auth))``. Failed
    authentication raises :class:`AuthenticationError`, which the
    service-level exception handler renders as a 401 envelope.
    """

    async def _dep(request: Request) -> CallerContext:
        return await auth.authenticate(request)

    return _dep
