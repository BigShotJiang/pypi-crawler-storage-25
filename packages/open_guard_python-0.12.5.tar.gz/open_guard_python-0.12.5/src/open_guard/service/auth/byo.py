"""CallableAuth — bring-your-own auth via a callable (Phase 10)."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING

from fastapi import Request

if TYPE_CHECKING:
    from open_guard.service.auth import CallerContext


class CallableAuth:
    """Authenticate by deferring to a user-supplied async callable.

    Use this for mTLS, custom JWT validation, proxy header passthrough,
    or any scheme not covered by the built-in backends. The callable
    must return a :class:`CallerContext` or raise
    :class:`AuthenticationError`.
    """

    def __init__(
        self, fn: Callable[[Request], Awaitable[CallerContext]]
    ) -> None:
        self._fn = fn

    async def authenticate(self, request: Request) -> CallerContext:
        return await self._fn(request)
