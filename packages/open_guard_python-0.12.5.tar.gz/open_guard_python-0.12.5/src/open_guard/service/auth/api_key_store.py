"""ApiKeyStorePort — abstract storage for hashed API key records (Phase 10)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol


@dataclass
class ApiKeyRecord:
    """Stored representation of an API key.

    Only the SHA-256 hash of the cleartext is stored. The cleartext value
    is shown to the operator exactly once at generation time.
    """

    key_hash: str
    tenant_id: str
    service_identity: str
    scopes: list[str] = field(default_factory=list)
    created_at: datetime | None = None
    revoked: bool = False


class ApiKeyStorePort(Protocol):
    async def get_by_hash(self, key_hash: str) -> ApiKeyRecord | None: ...
    async def add(self, record: ApiKeyRecord) -> None: ...
    async def revoke(self, key_hash: str) -> None: ...
    async def list_for_tenant(self, tenant_id: str) -> list[ApiKeyRecord]: ...


class InMemoryApiKeyStore:
    """In-memory `ApiKeyStorePort` impl. Suitable for tests and small deployments."""

    def __init__(self) -> None:
        self._records: dict[str, ApiKeyRecord] = {}

    async def get_by_hash(self, key_hash: str) -> ApiKeyRecord | None:
        return self._records.get(key_hash)

    async def add(self, record: ApiKeyRecord) -> None:
        self._records[record.key_hash] = record

    async def revoke(self, key_hash: str) -> None:
        record = self._records.get(key_hash)
        if record is not None:
            record.revoked = True

    async def list_for_tenant(self, tenant_id: str) -> list[ApiKeyRecord]:
        return [r for r in self._records.values() if r.tenant_id == tenant_id]
