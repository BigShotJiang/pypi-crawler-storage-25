"""ApiKeyAuth — built-in API-key authentication backend (Phase 10)."""

from __future__ import annotations

import hashlib
import secrets
from typing import TYPE_CHECKING

from fastapi import Request

from open_guard.service.auth.api_key_store import ApiKeyStorePort
from open_guard.service.errors import AuthenticationError

if TYPE_CHECKING:
    from open_guard.service.auth import CallerContext


class ApiKeyAuth:
    """Authenticate via an ``Authorization: ApiKey <key>`` header.

    Keys are hashed with SHA-256 and looked up in an
    :class:`ApiKeyStorePort`. Each record carries its tenant, service
    identity, and scopes — these populate the returned
    :class:`CallerContext`.
    """

    def __init__(self, store: ApiKeyStorePort) -> None:
        self._store = store

    async def authenticate(self, request: Request) -> CallerContext:
        from open_guard.service.auth import CallerContext

        header = request.headers.get("Authorization", "")
        if not header.startswith("ApiKey "):
            raise AuthenticationError(
                "missing API key", code="missing_api_key"
            )
        raw = header.removeprefix("ApiKey ").strip()
        if not raw:
            raise AuthenticationError(
                "missing API key", code="missing_api_key"
            )
        digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
        record = await self._store.get_by_hash(digest)
        if record is None or record.revoked:
            raise AuthenticationError(
                "invalid API key", code="invalid_api_key"
            )
        return CallerContext(
            tenant_id=record.tenant_id,
            service_identity=record.service_identity,
            scopes=frozenset(record.scopes),
        )

    @staticmethod
    def generate(prefix: str = "og_") -> tuple[str, str]:
        """Return ``(cleartext, sha256_hash)``.

        The cleartext is the value to hand to the consumer (shown once).
        The hash is what gets stored in the :class:`ApiKeyStorePort`.
        """
        cleartext = prefix + secrets.token_urlsafe(32)
        digest = hashlib.sha256(cleartext.encode("utf-8")).hexdigest()
        return cleartext, digest
