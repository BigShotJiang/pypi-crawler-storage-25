"""Tenant context resolution with cross-tenant admin override (Phase 10).

The effective ``tenant_id`` is sourced from the auth claim. The
``X-Tenant-ID`` request header may override it only when the calling
identity carries the ``cross_tenant_admin`` scope. Request bodies
never carry ``tenant_id``.
"""

from __future__ import annotations

from collections.abc import Callable, Coroutine
from typing import Any

from fastapi import Depends, Request

from open_guard.service.auth import AuthBackend, CallerContext
from open_guard.service.auth.dep import make_auth_dep
from open_guard.service.errors import AuthorizationServiceError

CROSS_TENANT_ADMIN_SCOPE = "cross_tenant_admin"
TENANT_OVERRIDE_HEADER = "X-Tenant-ID"


def make_tenant_dep(
    auth: AuthBackend,
) -> Callable[..., Coroutine[Any, Any, tuple[CallerContext, str]]]:
    """Return a FastAPI dependency that yields ``(caller, effective_tenant_id)``.

    Honors ``X-Tenant-ID`` only when the caller has the
    ``cross_tenant_admin`` scope. Otherwise rejects mismatched override
    with 403.
    """
    auth_dep = make_auth_dep(auth)

    async def _dep(
        request: Request,
        caller: CallerContext = Depends(auth_dep),
    ) -> tuple[CallerContext, str]:
        override = request.headers.get(TENANT_OVERRIDE_HEADER)
        if override and override != caller.tenant_id:
            if not caller.has_scope(CROSS_TENANT_ADMIN_SCOPE):
                raise AuthorizationServiceError(
                    f"{TENANT_OVERRIDE_HEADER} override requires "
                    f"{CROSS_TENANT_ADMIN_SCOPE} scope",
                    code="cross_tenant_forbidden",
                    status_code=403,
                )
            return caller, override
        return caller, caller.tenant_id

    return _dep
