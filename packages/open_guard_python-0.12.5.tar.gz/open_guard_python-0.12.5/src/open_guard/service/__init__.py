"""open-guard service mode — HTTP wrapper around Guard + AdminRouter (Phase 10).

Install: ``pip install open-guard-python[service]``.

Public API:

- :func:`create_app` — FastAPI app factory
- :class:`ServiceConfig` — factory configuration
- :class:`AuthBackend` — protocol for authentication backends
- :class:`CallerContext` — identity of the calling service
- :data:`SERVICE_API_VERSION` — wire-contract version
"""

from __future__ import annotations

from open_guard.service.app import ServiceConfig, create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    ApiKeyStorePort,
    AuthBackend,
    CallableAuth,
    CallerContext,
    InMemoryApiKeyStore,
)
from open_guard.service.errors import (
    AuthenticationError,
    AuthorizationServiceError,
    NotFoundError,
    ServiceError,
)
from open_guard.service.version import DEFAULT_PREFIX, SERVICE_API_VERSION

__all__ = [
    "DEFAULT_PREFIX",
    "SERVICE_API_VERSION",
    "ApiKeyAuth",
    "ApiKeyRecord",
    "ApiKeyStorePort",
    "AuthBackend",
    "AuthenticationError",
    "AuthorizationServiceError",
    "CallableAuth",
    "CallerContext",
    "InMemoryApiKeyStore",
    "NotFoundError",
    "ServiceConfig",
    "ServiceError",
    "create_app",
]
