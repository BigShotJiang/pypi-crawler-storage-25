"""Async relationship tuple storage port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from open_guard.domain.entities import RelationTuple


class AsyncRelationshipStorePort(ABC):
    """Async counterpart of RelationshipStorePort."""

    @abstractmethod
    async def write_tuple(self, relation_tuple: RelationTuple) -> RelationTuple:
        """Write a relation tuple to the store.

        Args:
            relation_tuple: The tuple to store.

        Returns:
            The stored tuple.

        Raises:
            RelationshipError: If a duplicate tuple already exists.
        """

    @abstractmethod
    async def delete_tuple(self, tuple_id: str, tenant_id: str) -> None:
        """Delete a relation tuple by ID.

        Args:
            tuple_id: The ID of the tuple to delete.
            tenant_id: The tenant the tuple belongs to.

        Raises:
            RelationshipError: If the tuple does not exist.
        """

    @abstractmethod
    async def read_tuples(
        self,
        tenant_id: str,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        """Read tuples matching the given filters.

        All filter parameters are optional; omitted filters match everything.

        Args:
            tenant_id: Required tenant scope.
            object_type: Filter by object type.
            object_id: Filter by object ID.
            relation: Filter by relation name.
            subject_type: Filter by subject type.
            subject_id: Filter by subject ID.

        Returns:
            List of matching tuples.
        """

    @abstractmethod
    async def tuple_exists(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        relation: str,
        subject_type: str,
        subject_id: str,
        subject_relation: str | None = None,
    ) -> bool:
        """Check if an exact tuple exists.

        Args:
            tenant_id: Tenant scope.
            object_type: Object type.
            object_id: Object ID.
            relation: Relation name.
            subject_type: Subject type.
            subject_id: Subject ID.
            subject_relation: Optional subject relation for subject sets.

        Returns:
            True if the tuple exists.
        """

    @abstractmethod
    async def find_object_ids_for_subject(
        self,
        subject_id: str,
        subject_type: str,
        object_type: str,
        tenant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> list[str]:
        """Return distinct object IDs of a type where a subject appears in any tuple.

        Returns the direct-membership superset — computed permissions and
        subject-set expansions are resolved by the ReBAC evaluator against
        candidates from this method. Results are deterministically ordered
        by object_id so callers can paginate with a stable offset.

        Args:
            subject_id: Subject ID.
            subject_type: Subject type (e.g., "user", "agent").
            object_type: Resource type to enumerate (e.g., "doc").
            tenant_id: Tenant scope.
            offset: Pagination offset (default 0).
            limit: Max IDs to return (default 100).

        Returns:
            Deduped, sorted list of object IDs.
        """
