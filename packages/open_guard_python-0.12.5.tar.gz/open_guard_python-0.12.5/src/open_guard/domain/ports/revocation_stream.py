# src/open_guard/domain/ports/revocation_stream.py
"""Abstract interface for push-based revocation events (Phase 6, ENH-010)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable

from open_guard.domain.entities import RevocationEvent

RevocationCallback = Callable[[RevocationEvent], None]


class RevocationStreamPort(ABC):
    """Port for publishing and subscribing to revocation events.

    CAEP-style push: when a permission/session/delegation is revoked,
    subscribers are notified immediately so long-running agents can
    re-check their authorization.
    """

    @abstractmethod
    def publish(self, event: RevocationEvent) -> None:
        """Publish a revocation event to all subscribers."""

    @abstractmethod
    def subscribe(
        self,
        tenant_id: str,
        callback: RevocationCallback,
        subject_id: str | None = None,
    ) -> str:
        """Subscribe to revocation events for a tenant.

        Args:
            tenant_id: Tenant to subscribe to.
            callback: Called with each RevocationEvent.
            subject_id: Optional filter — only events affecting this subject.

        Returns:
            Subscription ID for unsubscribe.
        """

    @abstractmethod
    def unsubscribe(self, subscription_id: str) -> None:
        """Remove a subscription."""
