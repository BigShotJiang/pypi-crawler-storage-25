"""Async approval-request storage port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime

    from open_guard.domain.entities import ApprovalRequest


class AsyncApprovalStorePort(ABC):
    """Async counterpart of ApprovalStorePort."""

    @abstractmethod
    async def create(self, request: ApprovalRequest) -> ApprovalRequest:
        """Persist a new ApprovalRequest.

        Implementations MAY reject creation of a second PENDING request
        with the same (tenant_id, request_hash) — the application-level
        ApprovalManager is expected to call `find_by_hash` first.
        """

    @abstractmethod
    async def get(
        self, request_id: str, tenant_id: str
    ) -> ApprovalRequest | None:
        """Retrieve a request by id within a tenant."""

    @abstractmethod
    async def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        """Return the current PENDING request for this hash, or None.

        If no PENDING exists (only historical APPROVED/REJECTED/EXPIRED),
        returns None — the next authorize() call should create a fresh
        pending request.
        """

    @abstractmethod
    async def find_latest_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        """Return the most recently created request for this hash, any status.

        Used by Guard to resolve an authorize() call by consulting historical
        APPROVED / REJECTED / EXPIRED state — not only active PENDING.
        """

    @abstractmethod
    async def update(self, request: ApprovalRequest) -> ApprovalRequest:
        """Replace the stored request (same id) with an updated copy."""

    @abstractmethod
    async def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        """List all currently-PENDING requests for a tenant."""

    @abstractmethod
    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition PENDING requests with `expires_at <= now` to EXPIRED.

        Returns the number of requests expired.
        """
