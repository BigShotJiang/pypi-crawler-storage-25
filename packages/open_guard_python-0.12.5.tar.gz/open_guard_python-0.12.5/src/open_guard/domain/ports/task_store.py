"""Abstract interface for task storage."""

from __future__ import annotations

from abc import ABC, abstractmethod

from open_guard.domain.entities import Task


class TaskStorePort(ABC):
    """Port for task storage — all operations are tenant-scoped.

    Implementations store task lifecycle state for TBAC evaluation.
    """

    @abstractmethod
    def add(self, task: Task) -> Task:
        """Add a task to the store."""

    @abstractmethod
    def get(self, task_id: str, tenant_id: str) -> Task | None:
        """Get a task by ID and tenant. Returns None if not found."""

    @abstractmethod
    def update(self, task: Task) -> Task:
        """Update an existing task. Raises TaskError if not found."""

    @abstractmethod
    def get_active_by_actor(self, actor_id: str, tenant_id: str) -> list[Task]:
        """Get all active tasks for an actor in a tenant."""

    @abstractmethod
    def remove(self, task_id: str, tenant_id: str) -> None:
        """Remove a task. Raises TaskError if not found."""
