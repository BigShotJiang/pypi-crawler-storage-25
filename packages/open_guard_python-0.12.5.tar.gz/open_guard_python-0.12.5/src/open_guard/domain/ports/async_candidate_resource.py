"""Async candidate-resource enumeration port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from open_guard.domain.entities import Resource


class AsyncCandidateResourcePort(ABC):
    """Async counterpart of CandidateResourcePort."""

    @abstractmethod
    async def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        """Return ``(candidates, next_cursor)``.

        Args:
            resource_type: The resource type being enumerated (e.g. ``"doc"``).
            tenant_id: Tenant scope — implementations MUST honor this.
            prefilter: Optional attribute prefilter. When provided, returned
                resources should match these attributes. Semantics are
                implementation-defined (exact equality is the usual choice).
            cursor: Opaque continuation from a prior call, or ``None`` for
                the first call.
            limit: Maximum number of resources to return in this page.

        Returns:
            A tuple of ``(resources, next_cursor)``. ``next_cursor`` is
            ``None`` when the source is exhausted. Returning an empty list
            with a non-None cursor is allowed (e.g., prefilter excludes an
            entire page) — callers iterate until cursor is None.
        """
