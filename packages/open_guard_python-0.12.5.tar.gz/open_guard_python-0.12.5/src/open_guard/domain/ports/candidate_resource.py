"""Abstract interface for candidate-resource enumeration (Phase 4, FEAT-006).

Consumers implement this port to feed `Guard.list_authorized` the pool of
resources it should iterate over for ABAC/RBAC-driven policies. ReBAC
enumeration is handled separately via `RelationshipStorePort` — consumers
only need this port for resource types that don't live in ReBAC tuples.

Design note: open-guard deliberately does NOT own resource storage. This
port is how the library asks the consumer's data layer "give me candidate
resources of type X in tenant T". The consumer is free to implement it over
SQL, Elasticsearch, Mongo, a REST API, or any other store.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from open_guard.domain.entities import Resource


class CandidateResourcePort(ABC):
    """Produces candidate :class:`Resource` objects for list enumeration.

    The cursor is opaque to open-guard — implementations choose their own
    continuation shape (offset, token, row id, etc.). open-guard round-trips
    the cursor between paginated `list_authorized` calls.

    Tenant isolation is the implementation's responsibility: the `tenant_id`
    argument MUST scope the returned resources. open-guard does not post-filter.
    """

    @abstractmethod
    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        """Return ``(candidates, next_cursor)``.

        Args:
            resource_type: The resource type being enumerated (e.g. ``"doc"``).
            tenant_id: Tenant scope — implementations MUST honor this.
            prefilter: Optional attribute prefilter. When provided, returned
                resources should match these attributes. Semantics are
                implementation-defined (exact equality is the usual choice).
            cursor: Opaque continuation from a prior call, or ``None`` for
                the first call.
            limit: Maximum number of resources to return in this page.

        Returns:
            A tuple of ``(resources, next_cursor)``. ``next_cursor`` is
            ``None`` when the source is exhausted. Returning an empty list
            with a non-None cursor is allowed (e.g., prefilter excludes an
            entire page) — callers iterate until cursor is None.
        """
