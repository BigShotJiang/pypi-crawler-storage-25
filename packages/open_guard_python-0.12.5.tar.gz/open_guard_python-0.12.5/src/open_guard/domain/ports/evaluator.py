"""Abstract interface for authorization evaluators."""

from __future__ import annotations

from abc import ABC, abstractmethod

from open_guard.domain.entities import AuthorizationRequest, Evaluation, Policy


class EvaluatorPort(ABC):
    """Port for authorization evaluators.

    Each evaluator handles one authorization model (RBAC, ABAC, etc.).
    Implements the Strategy pattern — new models are added by implementing
    this port, with no changes to existing code (Open/Closed principle).
    """

    @property
    @abstractmethod
    def evaluator_type(self) -> str:
        """The evaluator type identifier (e.g., 'rbac', 'abac', 'trust')."""

    @abstractmethod
    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        """Evaluate an authorization request against a set of policies.

        Args:
            request: The authorization request to evaluate.
            policies: Policies relevant to this evaluator (pre-filtered by type).

        Returns:
            Evaluation result with allowed/denied, reason, and matched policies.
        """

    @abstractmethod
    def supports(self, policy: Policy) -> bool:
        """Check if this evaluator handles the given policy type.

        Args:
            policy: The policy to check.

        Returns:
            True if this evaluator can evaluate the policy.
        """
