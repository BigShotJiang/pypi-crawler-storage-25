"""Abstract interface for delegation storage (Phase 5, FEAT-001/002/003)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
from decimal import Decimal

from open_guard.domain.entities import Delegation, DelegationStatus


class DelegationStorePort(ABC):
    """Port for Delegation operational state — not a policy store."""

    @abstractmethod
    def create(self, delegation: Delegation) -> Delegation:
        """Persist a new Delegation and return it."""

    @abstractmethod
    def get(self, delegation_id: str, tenant_id: str) -> Delegation | None:
        """Retrieve a Delegation by id within a tenant."""

    @abstractmethod
    def find_by_hash(self, request_hash: str, tenant_id: str) -> Delegation | None:
        """Return an existing Delegation with this idempotency hash, or None."""

    @abstractmethod
    def list_active_for_grantee(
        self,
        to_subject_id: str,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[Delegation]:
        """List ACTIVE delegations granted to a subject, filtered by resource_type."""

    @abstractmethod
    def list_descendants(
        self, parent_delegation_id: str, tenant_id: str
    ) -> list[Delegation]:
        """Return all delegations descending from parent_delegation_id."""

    @abstractmethod
    def update_status(
        self, delegation_id: str, tenant_id: str, status: DelegationStatus
    ) -> Delegation:
        """Transition a Delegation to a new status. Returns the updated entity."""

    @abstractmethod
    def decrement_uses(
        self, delegation_id: str, tenant_id: str, amount: int
    ) -> Delegation:
        """Atomically decrement uses_remaining by amount.

        Raises UsageExhaustedError if uses_remaining < amount.
        Transitions status to EXHAUSTED when uses_remaining reaches 0.
        """

    @abstractmethod
    def decrement_budget(
        self, delegation_id: str, tenant_id: str, cost: Decimal
    ) -> Delegation:
        """Atomically decrement budget_remaining by cost.

        Raises UsageExhaustedError if budget_remaining < cost.
        Transitions status to EXHAUSTED when budget_remaining reaches 0.
        """

    @abstractmethod
    def touch_heartbeat(
        self, delegation_id: str, tenant_id: str, now: datetime
    ) -> Delegation:
        """Set last_heartbeat_at = now. Returns the updated entity."""

    @abstractmethod
    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition delegations past their effective_expiry to EXPIRED.

        Returns the count of delegations transitioned.
        """
