"""Abstract interface for approval-request storage (Phase 3, FEAT-007)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime

from open_guard.domain.entities import ApprovalRequest


class ApprovalStorePort(ABC):
    """Port for ApprovalRequest storage — all operations are tenant-scoped.

    Pending requests are deduplicated externally (by ApprovalManager) using
    `find_by_hash`. Stores implement basic CRUD; they do not enforce the
    hash-uniqueness invariant themselves (except as a data-integrity backstop
    via `create` failing on duplicate pending hash).
    """

    @abstractmethod
    def create(self, request: ApprovalRequest) -> ApprovalRequest:
        """Persist a new ApprovalRequest.

        Implementations MAY reject creation of a second PENDING request
        with the same (tenant_id, request_hash) — the application-level
        ApprovalManager is expected to call `find_by_hash` first.
        """

    @abstractmethod
    def get(self, request_id: str, tenant_id: str) -> ApprovalRequest | None:
        """Retrieve a request by id within a tenant."""

    @abstractmethod
    def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        """Return the current PENDING request for this hash, or None.

        If no PENDING exists (only historical APPROVED/REJECTED/EXPIRED),
        returns None — the next authorize() call should create a fresh
        pending request.
        """

    @abstractmethod
    def find_latest_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        """Return the most recently created request for this hash, any status.

        Used by Guard to resolve an authorize() call by consulting historical
        APPROVED / REJECTED / EXPIRED state — not only active PENDING.
        """

    @abstractmethod
    def update(self, request: ApprovalRequest) -> ApprovalRequest:
        """Replace the stored request (same id) with an updated copy."""

    @abstractmethod
    def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        """List all currently-PENDING requests for a tenant."""

    @abstractmethod
    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition PENDING requests with `expires_at <= now` to EXPIRED.

        Returns the number of requests expired.
        """
