"""Async delegation storage port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime
    from decimal import Decimal

    from open_guard.domain.entities import Delegation, DelegationStatus


class AsyncDelegationStorePort(ABC):
    """Async counterpart of DelegationStorePort."""

    @abstractmethod
    async def create(self, delegation: Delegation) -> Delegation:
        """Persist a new Delegation and return it."""

    @abstractmethod
    async def get(self, delegation_id: str, tenant_id: str) -> Delegation | None:
        """Retrieve a Delegation by id within a tenant."""

    @abstractmethod
    async def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> Delegation | None:
        """Return an existing Delegation with this idempotency hash, or None."""

    @abstractmethod
    async def list_active_for_grantee(
        self,
        to_subject_id: str,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[Delegation]:
        """List ACTIVE delegations granted to a subject, filtered by resource_type."""

    @abstractmethod
    async def list_descendants(
        self, parent_delegation_id: str, tenant_id: str
    ) -> list[Delegation]:
        """Return all delegations descending from parent_delegation_id."""

    @abstractmethod
    async def update_status(
        self, delegation_id: str, tenant_id: str, status: DelegationStatus
    ) -> Delegation:
        """Transition a Delegation to a new status. Returns the updated entity."""

    @abstractmethod
    async def decrement_uses(
        self, delegation_id: str, tenant_id: str, amount: int
    ) -> Delegation:
        """Atomically decrement uses_remaining by amount.

        Raises UsageExhaustedError if uses_remaining < amount.
        Transitions status to EXHAUSTED when uses_remaining reaches 0.
        """

    @abstractmethod
    async def decrement_budget(
        self, delegation_id: str, tenant_id: str, cost: Decimal
    ) -> Delegation:
        """Atomically decrement budget_remaining by cost.

        Raises UsageExhaustedError if budget_remaining < cost.
        Transitions status to EXHAUSTED when budget_remaining reaches 0.
        """

    @abstractmethod
    async def touch_heartbeat(
        self, delegation_id: str, tenant_id: str, now: datetime
    ) -> Delegation:
        """Set last_heartbeat_at = now. Returns the updated entity."""

    @abstractmethod
    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition delegations past their effective_expiry to EXPIRED.

        Returns the count of delegations transitioned.
        """
