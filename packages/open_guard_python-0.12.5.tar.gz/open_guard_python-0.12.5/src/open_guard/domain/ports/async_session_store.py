"""Async session storage port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime

    from open_guard.domain.entities import Session, SessionStatus


class AsyncSessionStorePort(ABC):
    """Async counterpart of SessionStorePort."""

    @abstractmethod
    async def create(self, session: Session) -> Session:
        """Persist a new Session and return it."""

    @abstractmethod
    async def get(self, session_id: str, tenant_id: str) -> Session | None:
        """Retrieve a Session by id within a tenant."""

    @abstractmethod
    async def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        """List all ACTIVE sessions for a subject within a tenant."""

    @abstractmethod
    async def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        """Transition a Session to a new status. Returns the updated entity."""

    @abstractmethod
    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition ACTIVE sessions past their expires_at to EXPIRED.

        Returns the count of sessions transitioned.
        """
