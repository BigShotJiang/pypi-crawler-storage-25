"""Async task storage port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from open_guard.domain.entities import Task


class AsyncTaskStorePort(ABC):
    """Async counterpart of TaskStorePort."""

    @abstractmethod
    async def add(self, task: Task) -> Task:
        """Add a task to the store."""

    @abstractmethod
    async def get(self, task_id: str, tenant_id: str) -> Task | None:
        """Get a task by ID and tenant. Returns None if not found."""

    @abstractmethod
    async def update(self, task: Task) -> Task:
        """Update an existing task. Raises TaskError if not found."""

    @abstractmethod
    async def get_active_by_actor(
        self, actor_id: str, tenant_id: str
    ) -> list[Task]:
        """Get all active tasks for an actor in a tenant."""

    @abstractmethod
    async def remove(self, task_id: str, tenant_id: str) -> None:
        """Remove a task. Raises TaskError if not found."""
