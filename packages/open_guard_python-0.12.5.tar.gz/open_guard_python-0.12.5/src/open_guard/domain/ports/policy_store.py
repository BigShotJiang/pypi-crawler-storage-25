"""Abstract interface for policy storage."""

from __future__ import annotations

from abc import ABC, abstractmethod

from open_guard.domain.entities import Policy


class PolicyStorePort(ABC):
    """Port for policy storage — all operations are tenant-scoped.

    Implementations can use in-memory dicts, SQL databases, YAML files, etc.
    The domain never depends on a concrete storage implementation.
    """

    @abstractmethod
    def add(self, policy: Policy) -> Policy:
        """Add a policy to the store.

        Args:
            policy: The policy to store.

        Returns:
            The stored policy (may have an auto-generated ID).
        """

    @abstractmethod
    def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        """Get all policies for a tenant.

        Args:
            tenant_id: The tenant to query.

        Returns:
            All policies belonging to the tenant.
        """

    @abstractmethod
    def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        """Get policies for a tenant filtered by evaluator type.

        Args:
            tenant_id: The tenant to query.
            evaluator_type: The evaluator type to filter by (e.g., "rbac", "abac").

        Returns:
            Matching policies.
        """

    @abstractmethod
    def remove(self, policy_id: str, tenant_id: str) -> None:
        """Remove a policy from the store.

        Args:
            policy_id: The ID of the policy to remove.
            tenant_id: The tenant the policy belongs to.

        Raises:
            PolicyError: If the policy does not exist.
        """
