"""Async evaluator port (Phase 7)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from open_guard.domain.entities import AuthorizationRequest, Evaluation, Policy


class AsyncEvaluatorPort(ABC):
    """Async counterpart of EvaluatorPort.

    ``supports()`` remains synchronous — it is a pure type check with no I/O.
    Only ``evaluate()`` is async.
    """

    @property
    @abstractmethod
    def evaluator_type(self) -> str:
        """The evaluator type identifier (e.g., 'rbac', 'abac', 'trust')."""

    @abstractmethod
    async def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        """Evaluate an authorization request against a set of policies.

        Args:
            request: The authorization request to evaluate.
            policies: Policies relevant to this evaluator (pre-filtered by type).

        Returns:
            Evaluation result with allowed/denied, reason, and matched policies.
        """

    @abstractmethod
    def supports(self, policy: Policy) -> bool:
        """Check if this evaluator handles the given policy type.

        Args:
            policy: The policy to check.

        Returns:
            True if this evaluator can evaluate the policy.
        """
