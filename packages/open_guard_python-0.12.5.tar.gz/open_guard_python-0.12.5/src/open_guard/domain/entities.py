"""Core domain entities for open-guard authorization."""

from __future__ import annotations

import base64
import hashlib
import json
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from enum import StrEnum
from typing import Any, Literal
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field, computed_field, model_validator

from open_guard.domain.exceptions import ChainDepthExceededError

MAX_CHAIN_DEPTH_DEFAULT: int = 5
"""Default upper bound on Subject.on_behalf_of chain length.

Enforced at Subject construction time via a model validator. Guard also
enforces this at runtime and accepts a per-instance override.
"""


class Entity(BaseModel):
    """Base class for all domain entities."""

    model_config = ConfigDict(frozen=True)


class ActorType(StrEnum):
    """Types of actors that can request authorization."""

    USER = "user"
    AGENT = "agent"
    SERVICE = "service"
    DEVICE = "device"
    CONVERSATION = "conversation"
    ROBOT = "robot"
    EDGE_DEVICE = "edge_device"


class Subject(Entity):
    """Who is requesting access.

    Phase 3: gains `on_behalf_of` — a recursive chain link for agents
    acting on behalf of users or other agents. The chain is enforced at
    construction time (depth <= MAX_CHAIN_DEPTH_DEFAULT). Guard also
    enforces a configurable runtime limit.
    """

    id: str = Field(..., description="Unique identifier for the subject")
    actor_type: ActorType = Field(default=ActorType.USER, description="Type of actor")
    attributes: dict[str, Any] = Field(
        default_factory=dict,
        description="Subject attributes (roles, department, clearance, etc.)",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata (resolution source, session info)",
    )
    on_behalf_of: Subject | None = Field(
        default=None,
        description="Delegator: the Subject this one is acting on behalf of",
    )

    @model_validator(mode="after")
    def _check_chain_depth(self) -> Subject:
        if self.chain_depth > MAX_CHAIN_DEPTH_DEFAULT:
            raise ChainDepthExceededError(
                f"Subject chain depth {self.chain_depth} exceeds max "
                f"{MAX_CHAIN_DEPTH_DEFAULT}"
            )
        return self

    @computed_field  # type: ignore[prop-decorator]
    @property
    def chain_depth(self) -> int:
        """Number of on_behalf_of hops from this subject to the root actor."""
        if self.on_behalf_of is None:
            return 0
        return 1 + self.on_behalf_of.chain_depth

    @property
    def root_actor(self) -> Subject:
        """The top of the chain — the originating actor."""
        if self.on_behalf_of is None:
            return self
        return self.on_behalf_of.root_actor

    def ancestors(self) -> Iterator[Subject]:
        """Iterate delegators from immediate on_behalf_of up to the root."""
        cur = self.on_behalf_of
        while cur is not None:
            yield cur
            cur = cur.on_behalf_of


class Resource(Entity):
    """What is being accessed."""

    id: str = Field(..., description="Unique identifier for the resource")
    resource_type: str = Field(
        ..., description="Type of resource (document, endpoint, model)"
    )
    attributes: dict[str, Any] = Field(
        default_factory=dict,
        description="Resource attributes (owner, classification, labels)",
    )


class Action(Entity):
    """What operation is being performed."""

    name: str = Field(..., description="Action name (read, write, execute, invoke)")
    attributes: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional action context",
    )


class AuthorizationRequest(Entity):
    """Bundles subject, action, resource, and context for evaluation."""

    subject: Subject
    action: Action
    resource: Resource
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Environment context (time, IP, request metadata)",
    )
    tenant_id: str = Field(..., description="Tenant scope — required for isolation")


class PolicyEffect(StrEnum):
    """Whether a policy allows or denies access."""

    ALLOW = "allow"
    DENY = "deny"


class Policy(Entity):
    """A single authorization policy rule."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique policy identifier",
    )
    tenant_id: str = Field(..., description="Tenant this policy belongs to")
    evaluator_type: str = Field(
        ..., description="Which evaluator handles this (rbac, abac, tbac, rebac)"
    )
    subject_match: dict[str, Any] = Field(
        default_factory=dict,
        description="Conditions the subject must match",
    )
    action_match: str | list[str] = Field(
        default="*", description="Action(s) this policy applies to"
    )
    resource_match: dict[str, Any] = Field(
        default_factory=dict,
        description="Conditions the resource must match",
    )
    conditions: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional conditions (time windows, task scopes)",
    )
    effect: PolicyEffect = Field(
        default=PolicyEffect.ALLOW, description="Allow or deny"
    )
    priority: int = Field(default=0, description="Higher priority wins on conflict")
    requires_approval: ApprovalRequirement | None = Field(
        default=None,
        description=(
            "Phase 3 (FEAT-007): if set on an allow policy, matching this policy "
            "yields a pending_approval Decision instead of allow until an approver "
            "approves via Guard.approve()"
        ),
    )
    non_delegable: bool = Field(
        default=False,
        description=(
            "Phase 5 (FEAT-001): when True, the permission granted by this policy "
            "cannot be delegated further — DelegationEvaluator re-checks block "
            "delegations whose grantor's permission comes from a non_delegable policy."
        ),
    )


class TaskStatus(StrEnum):
    """Lifecycle states for a task."""

    CREATED = "created"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


class Task(Entity):
    """A unit of work with scoped permissions and lifecycle.

    Tasks are first-class authorization objects. Permissions can be scoped
    to a task — they are only active while the task is in ACTIVE status.
    Parent-child hierarchy enforces permission narrowing (child <= parent).
    """

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique task identifier",
    )
    tenant_id: str = Field(..., description="Tenant this task belongs to")
    actor_id: str = Field(..., description="Subject who owns this task")
    actor_type: ActorType = Field(
        default=ActorType.AGENT, description="Type of actor owning the task"
    )
    parent_task_id: str | None = Field(
        default=None, description="Parent task ID for hierarchy"
    )
    status: TaskStatus = Field(
        default=TaskStatus.CREATED, description="Current lifecycle state"
    )
    allowed_actions: list[str] = Field(
        default_factory=lambda: ["*"],
        description="Actions this task can perform (* = all)",
    )
    allowed_resource_types: list[str] = Field(
        default_factory=lambda: ["*"],
        description="Resource types this task can access (* = all)",
    )
    created_at: datetime = Field(..., description="When the task was created (UTC)")
    activated_at: datetime | None = Field(
        default=None, description="When the task was activated (UTC)"
    )
    expires_at: datetime | None = Field(
        default=None, description="When the task expires (UTC, absolute)"
    )
    completed_at: datetime | None = Field(
        default=None, description="When the task completed/failed (UTC)"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional task context",
    )


class RelationTuple(Entity):
    """A relationship fact: object#relation@subject[#subject_relation].

    Zanzibar-style relation tuple used by the ReBAC evaluator.
    """

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique tuple identifier",
    )
    tenant_id: str = Field(..., description="Tenant this tuple belongs to")
    object_type: str = Field(..., description="Type of the object (e.g. document)")
    object_id: str = Field(..., description="ID of the object (e.g. readme)")
    relation: str = Field(..., description="Relation name (e.g. viewer)")
    subject_type: str = Field(..., description="Type of the subject (e.g. user)")
    subject_id: str = Field(
        ..., description="ID of the subject (* = wildcard, all of type)"
    )
    subject_relation: str | None = Field(
        default=None,
        description="For subject sets / usersets (e.g. member)",
    )


class PermissionRule(Entity):
    """A computed permission rule within a type definition.

    Kinds:
        self — check if the relation exists directly
        union — any sub-relation holds
        intersection — all sub-relations hold
        exclusion — base holds AND subtract doesn't
        arrow — walk from_relation, then check to_permission on target
    """

    kind: str = Field(
        ..., description="self | union | intersection | exclusion | arrow"
    )
    relations: list[str] = Field(
        default_factory=list,
        description="For union/intersection: relations to combine",
    )
    base: str | None = Field(
        default=None, description="For exclusion: base relation"
    )
    subtract: str | None = Field(
        default=None, description="For exclusion: relation to subtract"
    )
    from_relation: str | None = Field(
        default=None, description="For arrow: walk this relation"
    )
    to_permission: str | None = Field(
        default=None, description="For arrow: then check this permission"
    )


class TypeDefinition(Entity):
    """Defines a type, its relations, and computed permissions.

    Used by the ReBAC evaluator for schema-based permission resolution.
    """

    name: str = Field(..., description="Type name (e.g. document, folder)")
    relations: dict[str, list[str]] = Field(
        ..., description="relation_name -> allowed subject types"
    )
    permissions: dict[str, PermissionRule] = Field(
        default_factory=dict,
        description="permission_name -> computed permission rule",
    )


class Evaluation(Entity):
    """Result from a single evaluator.

    Phase 3: extended additively with structured detail, timing, and
    attributes-read tracking. Legacy `matched_policies: list[str]` retained
    for backward compatibility; new code reads `matched_policies_detail`.
    """

    evaluator: str = Field(..., description="Which evaluator produced this")
    allowed: bool = Field(..., description="Whether access was granted")
    reason: str = Field(default="", description="Explanation of the decision")
    matched_policies: list[str] = Field(
        default_factory=list, description="IDs of policies that matched (BC)"
    )
    matched_policies_detail: list[PolicyMatch] = Field(
        default_factory=list,
        description="Phase 3: structured per-policy match detail for traces",
    )
    duration_ms: float = Field(
        default=0.0,
        description="Phase 3: evaluator runtime in milliseconds",
    )
    attributes_read: list[str] = Field(
        default_factory=list,
        description="Phase 3: attribute paths touched during evaluation (audit)",
    )


class DecisionStatus(StrEnum):
    """Tri-state authorization decision status.

    Added in Phase 3 (FEAT-007). Replaces the binary allowed/denied model
    with an explicit third state for policies that require human approval
    before they can resolve. `Decision.allowed` remains as a derived property
    for backward compatibility — returns True iff status == ALLOWED.
    """

    ALLOWED = "allowed"
    DENIED = "denied"
    PENDING_APPROVAL = "pending_approval"


class Decision(Entity):
    """Final authorization decision combining all evaluator results.

    ``status`` is the source of truth. ``allowed`` is a derived convenience
    property — True iff ``status == ALLOWED`` — so callers can write
    ``if decision.allowed: ...`` naturally.
    """

    status: DecisionStatus = Field(
        default=DecisionStatus.DENIED,
        description="Tri-state decision: allowed | denied | pending_approval",
    )
    reason: str = Field(default="", description="Summary explanation")
    evaluations: list[Evaluation] = Field(
        default_factory=list, description="Per-evaluator audit trail"
    )
    approval_request_id: str | None = Field(
        default=None,
        description="ApprovalRequest id when status=pending_approval",
    )
    non_delegable_policy: bool = Field(
        default=False,
        description=(
            "Phase 5 (T9): True when _skip_delegation=True and the matched ALLOW "
            "policy has non_delegable=True. Signals to DelegationEvaluator that "
            "the grantor's permission cannot be re-delegated."
        ),
    )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def allowed(self) -> bool:
        """True iff status is ALLOWED."""
        return self.status == DecisionStatus.ALLOWED


# ---------------------------------------------------------------------------
# Phase 3 — trace entities (FEAT-008)
# ---------------------------------------------------------------------------


class ConditionResult(Entity):
    """Single-condition evaluation trace (Phase 3)."""

    path: str = Field(..., description="Attribute path evaluated (e.g. subject.dept)")
    operator: str = Field(..., description="Condition operator (eq, in, regex, ...)")
    expected: Any = Field(..., description="Expected value from policy")
    actual: Any = Field(default=None, description="Actual value read from request")
    matched: bool = Field(..., description="Whether the condition matched")


class RelationMatch(Entity):
    """Single ReBAC relation traversal trace (Phase 3)."""

    object_type: str
    object_id: str
    relation: str
    subject: str = Field(..., description="subject_type:subject_id")
    path: list[str] = Field(
        default_factory=list,
        description="Traversal path (relation names) from root to this match",
    )


class PolicyMatch(Entity):
    """Per-policy trace emitted by an evaluator.

    Captures whether a policy matched, which conditions passed, which
    relations were traversed, and (for TBAC) whether task scope was
    satisfied. Used inside EvaluatorTrace.matched_policies /
    rejected_policies.
    """

    policy_id: str
    effect: PolicyEffect
    matched: bool = Field(..., description="Whether this policy matched")
    reason: str = Field(default="", description="Why matched or rejected")
    matched_conditions: list[ConditionResult] = Field(default_factory=list)
    matched_relations: list[RelationMatch] = Field(default_factory=list)
    task_scope_ok: bool | None = Field(
        default=None, description="For TBAC: whether task scope was satisfied"
    )


class SubjectSnapshot(Entity):
    """Immutable snapshot of a Subject for inclusion in DecisionTrace."""

    id: str
    actor_type: ActorType
    attributes: dict[str, Any] = Field(default_factory=dict)


class EvaluatorTrace(Entity):
    """Per-evaluator result inside a DecisionTrace (Phase 3)."""

    evaluator: str
    status: DecisionStatus
    matched_policies: list[PolicyMatch] = Field(default_factory=list)
    rejected_policies: list[PolicyMatch] = Field(default_factory=list)
    attributes_read: list[str] = Field(default_factory=list)
    duration_ms: float = 0.0


class DecisionTrace(Entity):
    """Full structured trace of an authorization decision (Phase 3).

    Returned by `Guard.authorize_traced()`. Not returned by the standard
    `authorize()` hot path.
    """

    schema_version: str = Field(
        default="1.0",
        description="DecisionTrace schema version — consumers may pin against this",
    )
    decision_status: DecisionStatus
    final_reason: str = Field(default="")
    evaluator_results: list[EvaluatorTrace] = Field(default_factory=list)
    composition: str = Field(
        default="",
        description="How evaluator results were combined (all-allow, deny-wins, ...)",
    )
    actor_chain: list[SubjectSnapshot] = Field(
        default_factory=list,
        description="Resolved Subject chain, from immediate actor to root",
    )
    duration_ms: float = 0.0
    timestamp: datetime = Field(
        ..., description="When authorize_traced() was invoked (UTC)"
    )


# ---------------------------------------------------------------------------
# Phase 3 — approval entities (FEAT-007)
# ---------------------------------------------------------------------------


class ApprovalStatus(StrEnum):
    """Lifecycle states for an ApprovalRequest."""

    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class ApprovalRequirement(Entity):
    """Policy-level declaration that a human approval gate is required.

    Attached to a Policy via `Policy.requires_approval`. When an allow
    policy with this field matches, the Guard returns a pending decision
    and records an ApprovalRequest via the ApprovalStorePort.
    """

    approvers: list[str] = Field(
        ..., description="Allowed approver identifiers (subject ids, role names)"
    )
    quorum: int | Literal["any", "all"] = Field(
        default="any",
        description="'any' (first approval resolves), 'all' (every approver), or int N",
    )
    ttl: timedelta | None = Field(
        default=None,
        description="Request expires this long after creation (None = no TTL)",
    )
    channel: str | None = Field(
        default=None,
        description="Advisory dispatch channel hint (slack, email, webhook)",
    )


class ApprovalDecision(Entity):
    """A single approver's vote on an ApprovalRequest."""

    approver: str
    decision: Literal["approve", "reject"]
    reason: str = ""
    at: datetime


class ApprovalRequest(Entity):
    """Pending/resolved request for human approval on an authorize() call.

    Deduplicated by `request_hash`: repeated authorize() calls with the
    same (tenant, subject, action, resource) collapse to one PENDING
    request while any prior PENDING for that hash exists.
    """

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique request identifier",
    )
    tenant_id: str
    request_hash: str = Field(
        ..., description="sha256 of (tenant, subject_id, action, resource_id, type)"
    )
    subject_id: str
    action_name: str
    resource_id: str
    resource_type: str
    status: ApprovalStatus = ApprovalStatus.PENDING
    requirement: ApprovalRequirement
    approvers_received: list[ApprovalDecision] = Field(default_factory=list)
    created_at: datetime
    expires_at: datetime | None = None
    resolved_at: datetime | None = None
    reason: str = ""

    @staticmethod
    def make_hash(
        tenant_id: str,
        subject_id: str,
        action_name: str,
        resource_id: str,
        resource_type: str,
    ) -> str:
        """SHA-256 hex digest of the idempotency-key fields."""
        raw = f"{tenant_id}|{subject_id}|{action_name}|{resource_id}|{resource_type}"
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


# --- Phase 4 (FEAT-006): list_authorized pagination entities -----------------


class Cursor(Entity):
    """Opaque pagination cursor for `Guard.list_authorized`.

    Encodes continuation state for the two candidate sources:
      * `rebac_offset` — progress through ReBAC tuple enumeration
      * `candidate_cursor` — opaque continuation for `CandidateResourcePort`
      * `seen_ids` — resource IDs already returned (dedupe across sources)

    Stability of the returned ID set under *concurrent policy changes*
    between paginated calls is explicitly undefined. Snapshot isolation
    requires Zanzibar-style zookies, deferred to ENH-015.
    """

    rebac_offset: int = Field(
        default=0,
        description="Offset into the ReBAC enumeration stream",
    )
    candidate_cursor: dict[str, Any] = Field(
        default_factory=dict,
        description="Opaque continuation token from CandidateResourcePort",
    )
    seen_ids: set[str] = Field(
        default_factory=set,
        description="IDs already returned — prevents duplicates across sources",
    )

    def is_empty(self) -> bool:
        return (
            self.rebac_offset == 0
            and not self.candidate_cursor
            and not self.seen_ids
        )

    def encode(self) -> str:
        """Serialize to a compact base64-URL-safe JSON token."""
        payload = {
            "r": self.rebac_offset,
            "c": self.candidate_cursor,
            "s": sorted(self.seen_ids),
        }
        return base64.urlsafe_b64encode(
            json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
        ).decode()

    @classmethod
    def decode(cls, token: str) -> Cursor:
        """Deserialize a token produced by :meth:`encode`.

        Raises ValueError if the token is malformed.
        """
        try:
            raw = json.loads(base64.urlsafe_b64decode(token.encode()).decode())
        except (ValueError, json.JSONDecodeError) as exc:
            raise ValueError(f"invalid cursor token: {exc}") from exc
        if not isinstance(raw, dict):
            raise ValueError("invalid cursor token: not a JSON object")
        return cls(
            rebac_offset=int(raw.get("r", 0)),
            candidate_cursor=dict(raw.get("c", {})),
            seen_ids=set(raw.get("s", [])),
        )


class ListRequest(Entity):
    """Inputs to `Guard.list_authorized`.

    Consumers typically call `Guard.list_authorized(subject, action, ...)`
    directly — this entity is the internal normalized request shape.
    """

    subject_id: str = Field(..., description="Requesting subject's id")
    action: str = Field(..., description="Action name (e.g., 'read', 'invoke')")
    resource_type: str = Field(
        ..., description="Resource type to enumerate (e.g., 'doc', 'tool')"
    )
    tenant_id: str = Field(..., description="Tenant scope")
    prefilter: dict[str, Any] | None = Field(
        default=None,
        description="Optional attribute prefilter passed to CandidateResourcePort",
    )
    limit: int = Field(default=100, description="Max IDs to return")
    cursor: Cursor | None = Field(
        default=None,
        description="Continuation cursor from a previous response",
    )


class ListResult(Entity):
    """Result of `Guard.list_authorized`.

    Contains allowed resource IDs and an optional opaque cursor to fetch
    the next page. `next_cursor` is `None` when both candidate sources
    are exhausted.
    """

    ids: list[str] = Field(default_factory=list, description="Authorized ids")
    next_cursor: str | None = Field(
        default=None, description="Opaque continuation token, or None when done"
    )

    def has_more(self) -> bool:
        return self.next_cursor is not None


# ---------------------------------------------------------------------------
# Phase 5 — Delegation & Bounds (FEAT-001 + FEAT-002 + FEAT-003)
# ---------------------------------------------------------------------------


class DelegationStatus(StrEnum):
    """Lifecycle states for a Delegation."""

    PENDING_APPROVAL = "pending_approval"
    ACTIVE = "active"
    REVOKED = "revoked"
    EXPIRED = "expired"
    EXHAUSTED = "exhausted"


class DelegationScope(Entity):
    """A single (action, resource_type, match) tuple within a delegation.

    OR across scopes on a Delegation; AND within resource_match/conditions.
    Reuses ABAC's dict + operator language (eq, in, contains_any, any_matches, …).
    """

    action_match: str | list[str] = Field(
        ..., description="Action name(s); supports glob patterns"
    )
    resource_type: str = Field(..., description="Resource type this scope targets")
    resource_match: dict[str, Any] = Field(
        default_factory=dict,
        description="ABAC-style match conditions on the resource",
    )
    conditions: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional ABAC conditions (chain.*, params.*, etc.)",
    )

    @classmethod
    def from_policy(cls, policy: Policy) -> DelegationScope:
        """Derive a DelegationScope from an existing Policy for convenience."""
        resource_type = policy.resource_match.get("type") or policy.resource_match.get(
            "resource_type"
        )
        if not isinstance(resource_type, str):
            raise ValueError(
                "Policy must have resource_match.type (or .resource_type) set "
                "to derive a DelegationScope"
            )
        remaining = {
            k: v
            for k, v in policy.resource_match.items()
            if k not in {"type", "resource_type"}
        }
        return cls(
            action_match=policy.action_match,
            resource_type=resource_type,
            resource_match=remaining,
            conditions=dict(policy.conditions),
        )


class Delegation(Entity):
    """A bounded permission grant from one subject to another.

    Operational state — created/consumed/revoked live, counters decay.
    Separate from Policy rules (same rule/state split as ApprovalStorePort).
    Covers FEAT-001 (push/pull), FEAT-002 (usage/budget), FEAT-003 (lease).
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(..., description="Tenant scope")
    from_subject_id: str = Field(..., description="Grantor subject id")
    from_subject_type: ActorType = Field(..., description="Grantor actor type")
    to_subject_id: str = Field(..., description="Grantee subject id")
    to_subject_type: ActorType = Field(..., description="Grantee actor type")
    scopes: list[DelegationScope] = Field(
        ..., min_length=1, description="OR across scopes"
    )
    parent_delegation_id: str | None = Field(
        default=None, description="For chained delegations"
    )

    # FEAT-002 — usage / budget
    max_uses: int | None = Field(default=None, ge=1)
    uses_remaining: int | None = Field(default=None, ge=0)
    budget: Decimal | None = Field(default=None)
    budget_remaining: Decimal | None = Field(default=None)

    # FEAT-003 — lease
    lease_ttl: timedelta | None = Field(default=None)
    last_heartbeat_at: datetime | None = Field(default=None)
    renewable_by: list[str] | None = Field(default=None)
    expires_at: datetime | None = Field(
        default=None, description="Immutable hard ceiling"
    )

    re_check_on_use: bool = Field(
        default=True,
        description="Re-verify grantor still has permission at each authorize()",
    )

    status: DelegationStatus = Field(default=DelegationStatus.ACTIVE)
    approval_request_id: str | None = Field(default=None)
    request_hash: str = Field(
        ..., description="SHA-256 of canonical args — idempotency key"
    )

    created_at: datetime = Field(...)
    created_by: str = Field(..., description="Subject id that called guard.delegate()")
    reason: str | None = Field(default=None)

    @model_validator(mode="after")
    def _check_counter_initial_state(self) -> Delegation:
        if self.max_uses is not None and self.uses_remaining is None:
            raise ValueError("uses_remaining required when max_uses is set")
        if (
            self.max_uses is not None
            and self.uses_remaining is not None
            and self.uses_remaining > self.max_uses
        ):
            raise ValueError("uses_remaining cannot exceed max_uses")
        if self.budget is not None and self.budget_remaining is None:
            raise ValueError("budget_remaining required when budget is set")
        if (
            self.budget is not None
            and self.budget_remaining is not None
            and self.budget_remaining > self.budget
        ):
            raise ValueError("budget_remaining cannot exceed budget")
        return self

    @staticmethod
    def make_hash(
        tenant_id: str,
        from_subject_id: str,
        to_subject_id: str,
        scopes: list[DelegationScope],
        parent_delegation_id: str | None,
        max_uses: int | None,
        budget: Decimal | None,
        lease_ttl: timedelta | None,
        expires_at: datetime | None,
    ) -> str:
        """Deterministic SHA-256 over canonical args."""
        canonical_scopes = json.dumps(
            [s.model_dump(mode="json") for s in scopes],
            sort_keys=True,
            separators=(",", ":"),
        )
        parts = [
            tenant_id,
            from_subject_id,
            to_subject_id,
            canonical_scopes,
            parent_delegation_id or "",
            str(max_uses) if max_uses is not None else "",
            str(budget) if budget is not None else "",
            str(lease_ttl.total_seconds()) if lease_ttl is not None else "",
            expires_at.isoformat() if expires_at is not None else "",
        ]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


# ---------------------------------------------------------------------------
# Phase 6 — RBAC Sessions (ENH-001)
# ---------------------------------------------------------------------------


class SessionStatus(StrEnum):
    """Lifecycle states for an RBAC Session."""

    ACTIVE = "active"
    DEACTIVATED = "deactivated"
    EXPIRED = "expired"


class Session(Entity):
    """An RBAC session — a subject activates a subset of assigned roles.

    NIST Core RBAC: a session maps a user to a set of activated roles.
    Multiple concurrent sessions per subject are allowed (different scopes
    or contexts can have different active role sets).

    Phase 6 (ENH-001).
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(..., description="Tenant scope")
    subject_id: str = Field(..., description="Subject this session belongs to")
    activated_roles: list[str] = Field(
        ..., min_length=1, description="Subset of subject's assigned roles"
    )
    status: SessionStatus = Field(default=SessionStatus.ACTIVE)
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    expires_at: datetime | None = Field(
        default=None, description="Session expiry (None = no expiry)"
    )
    deactivated_at: datetime | None = Field(default=None)
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Consumer context (scope, device, IP, etc.)",
    )


# ---------------------------------------------------------------------------
# Phase 6 — Push Revocation (ENH-010)
# ---------------------------------------------------------------------------


class RevocationEventType(StrEnum):
    """Types of revocation events."""

    DELEGATION_REVOKED = "delegation_revoked"
    DELEGATION_EXPIRED = "delegation_expired"
    SESSION_DEACTIVATED = "session_deactivated"
    POLICY_REMOVED = "policy_removed"


class RevocationEvent(Entity):
    """A push notification that a permission/session/delegation was revoked.

    Phase 6 (ENH-010): emitted by DelegationManager, SessionManager, or
    Guard when permissions change. Long-running agents subscribe to these
    events for immediate re-authorization.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    event_type: RevocationEventType
    tenant_id: str
    subject_id: str | None = Field(
        default=None, description="Affected subject (if applicable)"
    )
    delegation_id: str | None = Field(
        default=None, description="Affected delegation (if applicable)"
    )
    session_id: str | None = Field(
        default=None, description="Affected session (if applicable)"
    )
    policy_id: str | None = Field(
        default=None, description="Affected policy (if applicable)"
    )
    reason: str = ""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))


# ---------------------------------------------------------------------------
# Phase 8 — AI-Era Primitives: OperationChain
# ---------------------------------------------------------------------------


class OperationRule(Entity):
    """Maps an action pattern to a list of evaluator types.

    When OperationChainConfig is active, PolicyRouter uses these rules
    to select which evaluators participate for a given action.
    First match wins (like nginx location blocks).
    """

    action_pattern: str = Field(
        ..., description="Glob pattern for action names (e.g., 'knowledge:write', 'knowledge:*', '*')"
    )
    evaluators: list[str] = Field(
        ..., description="Evaluator type strings to activate (e.g., ['rbac', 'abac', 'tbac'])"
    )


class OperationChainConfig(Entity):
    """Configuration for action-pattern-based evaluator selection.

    Routes actions to specific evaluator subsets. First matching rule wins.
    If no rule matches, falls back to default_evaluators. If default_evaluators
    is None, all evaluators participate (backward compatible).
    """

    rules: list[OperationRule] = Field(
        ..., description="Ordered list of rules — first match wins"
    )
    default_evaluators: list[str] | None = Field(
        default=None,
        description="Fallback evaluator types when no rule matches. None = all evaluators."
    )

    def resolve(self, action_name: str) -> list[str] | None:
        """Return evaluator types for the given action, or None for 'use all'.

        Uses fnmatch-style glob matching. First match wins.
        """
        import fnmatch
        for rule in self.rules:
            if fnmatch.fnmatch(action_name, rule.action_pattern):
                return list(rule.evaluators)
        return list(self.default_evaluators) if self.default_evaluators else None
