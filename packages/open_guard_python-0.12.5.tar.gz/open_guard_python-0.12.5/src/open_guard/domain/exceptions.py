"""Domain exceptions for open-guard."""


class OpenGuardError(Exception):
    """Base exception for all open-guard errors."""


class AuthorizationDeniedError(OpenGuardError):
    """Raised when authorization is denied."""


class PolicyError(OpenGuardError):
    """Raised for policy-related errors (invalid policy, missing fields)."""


class ConfigurationError(OpenGuardError):
    """Raised for configuration errors."""


class TaskError(OpenGuardError):
    """Raised for task-related errors (invalid state transition, not found)."""


class RelationshipError(OpenGuardError):
    """Raised for relationship tuple errors (not found, duplicate)."""


class ChainDepthExceededError(OpenGuardError):
    """Raised when a Subject.on_behalf_of chain exceeds the maximum depth.

    Phase 3 — prevents runaway subagent delegation trees.
    """


class ApprovalError(OpenGuardError):
    """Raised for approval workflow errors (missing store, unknown approver, etc.)."""


# ---------------------------------------------------------------------------
# Phase 5 — Delegation & Bounds exceptions
# ---------------------------------------------------------------------------


class DelegateNotPermittedError(OpenGuardError):
    """Raised when a caller cannot create, revoke, or renew a delegation."""


class UsageExhaustedError(OpenGuardError):
    """Raised when consume_delegation would take a counter below zero."""


class LeaseExpiredError(OpenGuardError):
    """Raised when renewing an already-expired delegation."""


class DelegationRevokedError(OpenGuardError):
    """Raised when operating on a revoked delegation."""


class DelegationNotFoundError(OpenGuardError):
    """Raised when a delegation id does not exist in the store."""


class DelegationChainDepthExceededError(OpenGuardError):
    """Raised when parent_delegation_id chain exceeds max_delegation_depth."""


# ---------------------------------------------------------------------------
# Phase 6 — Session exceptions
# ---------------------------------------------------------------------------


class SessionError(OpenGuardError):
    """Raised for session-related errors."""


class SessionNotFoundError(SessionError):
    """Raised when a session id does not exist in the store."""


class SessionExpiredError(SessionError):
    """Raised when operating on an expired session."""


# ---------------------------------------------------------------------------
# Phase 6 — Revocation exceptions
# ---------------------------------------------------------------------------


class RevocationError(OpenGuardError):
    """Raised for revocation stream errors."""
