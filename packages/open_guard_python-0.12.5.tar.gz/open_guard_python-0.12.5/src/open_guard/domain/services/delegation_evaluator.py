"""DelegationEvaluator — scope matching, dynamic re-check, and memoization (Phase 5)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from open_guard.domain.entities import (
    Action,
    DecisionStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Resource,
    Subject,
)
from open_guard.domain.ports.delegation_store import DelegationStorePort


@dataclass
class DelegationDecision:
    """Result returned by DelegationEvaluator.evaluate."""

    allowed: bool
    matched_delegation_ids: list[str] = field(default_factory=list)


class DelegationEvaluator:
    """Evaluate whether a subject's access is satisfied by an active delegation.

    For each active delegation granted to *subject*, checks:
    1. Scope match: action, resource_type, and resource_match predicates.
    2. Re-check (when re_check_on_use=True): the grantor still holds the
       delegated permission (guard.authorize with _skip_delegation=True).
       Memoized per (grantor, action, resource) key within a call via
       recheck_cache.

    Args:
        delegation_store: Active delegations backend.
        guard: Guard (duck-typed to avoid circular import).
    """

    def __init__(
        self,
        delegation_store: DelegationStorePort,
        guard: Any,
    ) -> None:
        self._store = delegation_store
        self._guard = guard

    @property
    def evaluator_type(self) -> str:
        return "delegation"

    def evaluate(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        *,
        recheck_cache: dict[tuple[str, ...], Any] | None = None,
    ) -> DelegationDecision:
        """Return whether any active delegation permits subject's request."""
        if recheck_cache is None:
            recheck_cache = {}

        delegations = self._store.list_active_for_grantee(
            subject.id, tenant_id, resource_type=resource.resource_type
        )

        matched_ids: list[str] = []
        for d in delegations:
            if d.status != DelegationStatus.ACTIVE:
                continue
            if not _scopes_match(d.scopes, action, resource):
                continue
            if d.re_check_on_use and not self._grantor_still_permitted(
                d, action, resource, tenant_id, recheck_cache
            ):
                continue
            matched_ids.append(d.id)

        return DelegationDecision(
            allowed=len(matched_ids) > 0,
            matched_delegation_ids=matched_ids,
        )

    def list_contribution(
        self,
        subject: Subject,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[str]:
        """Return concrete resource IDs this subject can access via delegations.

        Only scopes with explicit ``id: {op: eq|in}`` resource_match constraints
        contribute IDs. Wildcard / pattern scopes are not enumerable.
        """
        delegations = self._store.list_active_for_grantee(
            subject.id, tenant_id, resource_type=resource_type
        )
        seen: dict[str, None] = {}  # ordered dedup
        for d in delegations:
            for scope in d.scopes:
                if resource_type is not None and scope.resource_type != resource_type:
                    continue
                for resource_ids in _extract_concrete_ids(scope):
                    seen[resource_ids] = None
        return list(seen.keys())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _grantor_still_permitted(
        self,
        delegation: Delegation,
        action: Action,
        resource: Resource,
        tenant_id: str,
        cache: dict[tuple[str, ...], Any],
    ) -> bool:
        key = (
            delegation.from_subject_id,
            action.name,
            resource.id,
            resource.resource_type,
        )
        if key not in cache:
            grantor = Subject(
                id=delegation.from_subject_id,
                actor_type=delegation.from_subject_type,
            )
            cache[key] = self._guard.authorize(
                grantor,
                action,
                resource,
                tenant_id,
                _skip_delegation=True,
            )
        decision = cache[key]
        if decision.status != DecisionStatus.ALLOWED:
            return False
        # Non-delegable policy: grantor's permission cannot be re-delegated
        return not getattr(decision, "non_delegable_policy", False)


# ------------------------------------------------------------------
# Module-level pure helpers
# ------------------------------------------------------------------


def _scopes_match(
    scopes: list[DelegationScope], action: Action, resource: Resource
) -> bool:
    """Return True if any scope in the list covers (action, resource)."""
    return any(_scope_matches(s, action, resource) for s in scopes)


def _scope_matches(scope: DelegationScope, action: Action, resource: Resource) -> bool:
    # Action match
    if isinstance(scope.action_match, str):
        if scope.action_match != action.name:
            return False
    elif action.name not in scope.action_match:
        return False

    # Resource type match
    if scope.resource_type != resource.resource_type:
        return False

    # Resource attribute predicates
    for attr, matcher in scope.resource_match.items():
        op = matcher.get("op")
        value = matcher.get("value")
        resource_value = resource.id if attr == "id" else resource.attributes.get(attr)
        if (op == "eq" and resource_value != value) or (
            op == "in" and resource_value not in value
        ):
            return False
        # Unknown ops are ignored (forward-compatible)

    return True


def _extract_concrete_ids(scope: DelegationScope) -> list[str]:
    """Extract concrete resource IDs from a scope's resource_match, if any."""
    id_matcher = scope.resource_match.get("id")
    if id_matcher is None:
        return []
    op = id_matcher.get("op")
    value = id_matcher.get("value")
    if op == "eq" and isinstance(value, str):
        return [value]
    if op == "in" and isinstance(value, list):
        return [v for v in value if isinstance(v, str)]
    return []
