"""TaskManager — lifecycle management for task-based access control."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from open_guard.domain.entities import ActorType, Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.ports.task_store import TaskStorePort


class TaskManager:
    """Manages task lifecycle: create, activate, complete, fail, expire.

    Enforces state machine transitions and parent-child permission narrowing.

    Args:
        task_store: Storage for task state.
        clock: Optional callable returning current UTC datetime (for testing).
    """

    def __init__(
        self,
        task_store: TaskStorePort,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._task_store = task_store
        self._clock = clock or (lambda: datetime.now(UTC))

    def create_task(
        self,
        tenant_id: str,
        actor_id: str,
        actor_type: ActorType = ActorType.AGENT,
        allowed_actions: list[str] | None = None,
        allowed_resource_types: list[str] | None = None,
        expires_at: datetime | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Task:
        """Create a new task in CREATED state."""
        task = Task(
            id=str(uuid4()),
            tenant_id=tenant_id,
            actor_id=actor_id,
            actor_type=actor_type,
            status=TaskStatus.CREATED,
            allowed_actions=allowed_actions or ["*"],
            allowed_resource_types=allowed_resource_types or ["*"],
            created_at=self._clock(),
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return self._task_store.add(task)

    def activate_task(self, task_id: str, tenant_id: str) -> Task:
        """Transition task from CREATED to ACTIVE."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.CREATED:
            msg = (
                f"Cannot activate task '{task_id}': "
                f"status is '{task.status}', expected 'created'"
            )
            raise TaskError(msg)
        updated = task.model_copy(
            update={"status": TaskStatus.ACTIVE, "activated_at": self._clock()}
        )
        return self._task_store.update(updated)

    def complete_task(self, task_id: str, tenant_id: str) -> Task:
        """Transition task from ACTIVE to COMPLETED."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.ACTIVE:
            msg = (
                f"Cannot complete task '{task_id}': "
                f"status is '{task.status}', expected 'active'"
            )
            raise TaskError(msg)
        updated = task.model_copy(
            update={"status": TaskStatus.COMPLETED, "completed_at": self._clock()}
        )
        return self._task_store.update(updated)

    def fail_task(self, task_id: str, tenant_id: str) -> Task:
        """Transition task from ACTIVE to FAILED."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.ACTIVE:
            msg = (
                f"Cannot fail task '{task_id}': "
                f"status is '{task.status}', expected 'active'"
            )
            raise TaskError(msg)
        updated = task.model_copy(
            update={"status": TaskStatus.FAILED, "completed_at": self._clock()}
        )
        return self._task_store.update(updated)

    def check_expiry(self, task_id: str, tenant_id: str) -> Task:
        """Check if an active task has expired. Auto-transitions to EXPIRED if so."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.ACTIVE:
            return task
        if task.expires_at is None:
            return task
        if self._clock() > task.expires_at:
            updated = task.model_copy(update={"status": TaskStatus.EXPIRED})
            return self._task_store.update(updated)
        return task

    def create_child_task(
        self,
        parent_task_id: str,
        tenant_id: str,
        actor_id: str,
        actor_type: ActorType = ActorType.AGENT,
        allowed_actions: list[str] | None = None,
        allowed_resource_types: list[str] | None = None,
        expires_at: datetime | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Task:
        """Create a child task narrowed to parent's scope.

        Validates: child <= parent for actions, resource types,
        and expiry.
        """
        parent = self._get_task(parent_task_id, tenant_id)
        if parent.status != TaskStatus.ACTIVE:
            msg = (
                f"Parent task '{parent_task_id}' is not active "
                f"(status: '{parent.status}')"
            )
            raise TaskError(msg)

        child_actions = allowed_actions or ["*"]
        child_resources = allowed_resource_types or ["*"]

        self._validate_narrowing(parent, child_actions, child_resources, expires_at)

        task = Task(
            id=str(uuid4()),
            tenant_id=tenant_id,
            actor_id=actor_id,
            actor_type=actor_type,
            parent_task_id=parent_task_id,
            status=TaskStatus.CREATED,
            allowed_actions=child_actions,
            allowed_resource_types=child_resources,
            created_at=self._clock(),
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return self._task_store.add(task)

    def _get_task(self, task_id: str, tenant_id: str) -> Task:
        task = self._task_store.get(task_id, tenant_id)
        if task is None:
            msg = f"Task '{task_id}' not found in tenant '{tenant_id}'"
            raise TaskError(msg)
        return task

    def _validate_narrowing(
        self,
        parent: Task,
        child_actions: list[str],
        child_resources: list[str],
        child_expires_at: datetime | None,
    ) -> None:
        """Validate child permissions don't exceed parent's scope."""
        # Actions narrowing
        if "*" not in parent.allowed_actions and (
            "*" in child_actions
            or not set(child_actions).issubset(set(parent.allowed_actions))
        ):
            msg = (
                f"Child actions {child_actions} exceeds parent "
                f"scope {parent.allowed_actions}"
            )
            raise TaskError(msg)

        # Resource types narrowing
        if "*" not in parent.allowed_resource_types and (
            "*" in child_resources
            or not set(child_resources).issubset(
                set(parent.allowed_resource_types)
            )
        ):
            msg = (
                f"Child resource types {child_resources} exceeds "
                f"parent scope {parent.allowed_resource_types}"
            )
            raise TaskError(msg)

        # Expiry narrowing
        if (
            parent.expires_at is not None
            and child_expires_at is not None
            and child_expires_at > parent.expires_at
        ):
            msg = (
                f"Child expires_at {child_expires_at} exceeds "
                f"parent expires_at {parent.expires_at}"
            )
            raise TaskError(msg)
