"""AsyncDelegationEvaluator — async sibling of DelegationEvaluator (Phase 11, FEAT-014).

Mirrors :class:`DelegationEvaluator` exactly; only the I/O over the
delegation store becomes ``await``-able. Pure helpers (scope match,
concrete-id extraction) are imported from the sync module — no parallel
logic.
"""

from __future__ import annotations

from typing import Any

from open_guard.domain.entities import (
    Action,
    DecisionStatus,
    Delegation,
    DelegationStatus,
    Resource,
    Subject,
)
from open_guard.domain.ports.async_delegation_store import AsyncDelegationStorePort
from open_guard.domain.services.delegation_evaluator import (
    DelegationDecision,
    _scopes_match,
    _extract_concrete_ids,
)


class AsyncDelegationEvaluator:
    """Async counterpart of :class:`DelegationEvaluator`.

    For each active delegation granted to *subject*, checks:
    1. Scope match: action, resource_type, and resource_match predicates.
    2. Re-check (when ``re_check_on_use=True``): the grantor still holds
       the delegated permission via ``await guard.authorize(_skip_delegation=True)``.
       Memoized per (grantor, action, resource) within a call.
    """

    def __init__(
        self,
        delegation_store: AsyncDelegationStorePort,
        guard: Any,
    ) -> None:
        self._store = delegation_store
        self._guard = guard

    @property
    def evaluator_type(self) -> str:
        return "delegation"

    async def evaluate(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        *,
        recheck_cache: dict[tuple[str, ...], Any] | None = None,
    ) -> DelegationDecision:
        """Return whether any active delegation permits subject's request."""
        if recheck_cache is None:
            recheck_cache = {}

        delegations = await self._store.list_active_for_grantee(
            subject.id, tenant_id, resource_type=resource.resource_type
        )

        matched_ids: list[str] = []
        for d in delegations:
            if d.status != DelegationStatus.ACTIVE:
                continue
            if not _scopes_match(d.scopes, action, resource):
                continue
            if d.re_check_on_use and not await self._grantor_still_permitted(
                d, action, resource, tenant_id, recheck_cache
            ):
                continue
            matched_ids.append(d.id)

        return DelegationDecision(
            allowed=len(matched_ids) > 0,
            matched_delegation_ids=matched_ids,
        )

    async def list_contribution(
        self,
        subject: Subject,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[str]:
        """Return concrete resource IDs this subject can access via delegations.

        Only scopes with explicit ``id: {op: eq|in}`` resource_match constraints
        contribute IDs. Wildcard / pattern scopes are not enumerable.
        """
        delegations = await self._store.list_active_for_grantee(
            subject.id, tenant_id, resource_type=resource_type
        )
        seen: dict[str, None] = {}  # ordered dedup
        for d in delegations:
            for scope in d.scopes:
                if resource_type is not None and scope.resource_type != resource_type:
                    continue
                for rid in _extract_concrete_ids(scope):
                    seen[rid] = None
        return list(seen.keys())

    async def _grantor_still_permitted(
        self,
        delegation: Delegation,
        action: Action,
        resource: Resource,
        tenant_id: str,
        cache: dict[tuple[str, ...], Any],
    ) -> bool:
        key = (
            delegation.from_subject_id,
            action.name,
            resource.id,
            resource.resource_type,
        )
        if key not in cache:
            grantor = Subject(
                id=delegation.from_subject_id,
                actor_type=delegation.from_subject_type,
            )
            cache[key] = await self._guard.authorize(
                grantor,
                action,
                resource,
                tenant_id,
                _skip_delegation=True,
            )
        decision = cache[key]
        if decision.status != DecisionStatus.ALLOWED:
            return False
        return not getattr(decision, "non_delegable_policy", False)
