"""SessionManager — RBAC session lifecycle management (Phase 6, ENH-001)."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any

from open_guard.domain.entities import Session, SessionStatus, Subject
from open_guard.domain.exceptions import SessionError, SessionNotFoundError
from open_guard.domain.ports.revocation_stream import RevocationStreamPort
from open_guard.domain.ports.session_store import SessionStorePort


class SessionManager:
    """Manages RBAC session lifecycle: create, deactivate, expire.

    NIST Core RBAC: sessions let a subject activate a subset of their
    assigned roles. Multiple concurrent sessions per subject are allowed
    (e.g., different scopes or devices).
    """

    def __init__(
        self,
        session_store: SessionStorePort,
        clock: Callable[[], datetime] | None = None,
        revocation_stream: RevocationStreamPort | None = None,
    ) -> None:
        self._store = session_store
        self._clock = clock or (lambda: datetime.now(UTC))
        self._revocation_stream = revocation_stream

    def create_session(
        self,
        subject: Subject,
        tenant_id: str,
        activated_roles: list[str],
        ttl: timedelta | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        """Create a new session with a validated role subset.

        Args:
            subject: The subject creating the session.
            tenant_id: Tenant scope.
            activated_roles: Roles to activate (must be subset of subject's roles).
            ttl: Optional time-to-live from now.
            metadata: Consumer context (scope, device, etc.).

        Raises:
            SessionError: If activated_roles is not a subset of subject's
                assigned roles.
        """
        assigned = set(subject.attributes.get("roles", []))
        requested = set(activated_roles)
        if not requested.issubset(assigned):
            extra = requested - assigned
            raise SessionError(
                f"Requested roles {extra} not a subset of assigned roles {assigned}"
            )
        now = self._clock()
        expires_at = (now + ttl) if ttl is not None else None
        session = Session(
            tenant_id=tenant_id,
            subject_id=subject.id,
            activated_roles=list(activated_roles),
            status=SessionStatus.ACTIVE,
            created_at=now,
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return self._store.create(session)

    def get_session(self, session_id: str, tenant_id: str) -> Session:
        """Retrieve a session, auto-expiring if past expiry.

        Raises:
            SessionNotFoundError: If session doesn't exist.
        """
        session = self._store.get(session_id, tenant_id)
        if session is None:
            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        # Lazy expiry — same pattern as ApprovalRequest and Delegation
        if (
            session.status == SessionStatus.ACTIVE
            and session.expires_at is not None
            and session.expires_at <= self._clock()
        ):
            session = self._store.update_status(
                session_id, tenant_id, SessionStatus.EXPIRED
            )
        return session

    def get_active_sessions(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        """List all active sessions for a subject."""
        return self._store.get_active_for_subject(subject_id, tenant_id)

    def deactivate(self, session_id: str, tenant_id: str) -> Session:
        """Deactivate an active session.

        Raises:
            SessionNotFoundError: If session doesn't exist.
            SessionError: If session is not active.
        """
        session = self._store.get(session_id, tenant_id)
        if session is None:
            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        if session.status != SessionStatus.ACTIVE:
            raise SessionError(
                f"Session {session_id!r} is not active (status={session.status})"
            )
        updated = self._store.update_status(
            session_id,
            tenant_id,
            SessionStatus.DEACTIVATED,
            deactivated_at=self._clock(),
        )
        if self._revocation_stream is not None:
            from open_guard.domain.entities import RevocationEvent, RevocationEventType
            self._revocation_stream.publish(RevocationEvent(
                event_type=RevocationEventType.SESSION_DEACTIVATED,
                tenant_id=tenant_id,
                subject_id=session.subject_id,
                session_id=session_id,
                reason="session deactivated",
                timestamp=self._clock(),
            ))
        return updated

    def expire_stale(self, tenant_id: str) -> int:
        """Expire all sessions past their expiry time."""
        return self._store.expire_stale(tenant_id, self._clock())
