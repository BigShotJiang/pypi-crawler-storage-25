"""DelegationManager — delegate / revoke / renew / consume / expire (Phase 5)."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

from open_guard.domain.entities import (
    Action,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
    DecisionStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import (
    DelegateNotPermittedError,
    DelegationChainDepthExceededError,
    DelegationNotFoundError,
    LeaseExpiredError,
)
from open_guard.domain.ports.delegation_store import DelegationStorePort
from open_guard.domain.ports.revocation_stream import RevocationStreamPort


class DelegationManager:
    """Lifecycle manager for Delegation — the push/pull delegation primitive.

    Validates meta-authorization and narrowing, enforces chain-depth limits,
    manages CAS-safe counter consumption, and cascades revocations.

    Args:
        delegation_store: Persistence backend for Delegation objects.
        guard: Guard instance for meta-authz and narrowing checks (duck-typed
            to avoid circular import; T8 wires this fully).
        approval_store: Optional; required when callers pass requires_approval.
        clock: Callable returning current UTC datetime.
        max_delegation_depth: Maximum delegation chain depth (default 10).
    """

    def __init__(
        self,
        delegation_store: DelegationStorePort,
        guard: Any,
        approval_store: Any | None = None,
        clock: Callable[[], datetime] | None = None,
        max_delegation_depth: int = 10,
        default_delegate_policy: str | None = "self_only",
        revocation_stream: RevocationStreamPort | None = None,
    ) -> None:
        self._store = delegation_store
        self._guard = guard
        self._approval_store = approval_store
        self._clock = clock or (lambda: datetime.now(UTC))
        self._max_delegation_depth = max_delegation_depth
        self._default_delegate_policy = default_delegate_policy
        self._revocation_stream = revocation_stream
        # Maps approval_request_id → delegation_id for pending-approval lookups.
        self._pending_approval: dict[str, str] = {}

    # ------------------------------------------------------------------
    # delegate
    # ------------------------------------------------------------------

    def delegate(
        self,
        *,
        caller: Subject,
        from_subject: Subject,
        to_subject: Subject,
        scopes: list[DelegationScope],
        tenant_id: str,
        parent_delegation_id: str | None = None,
        max_uses: int | None = None,
        budget: Decimal | None = None,
        lease_ttl: Any | None = None,
        expires_at: datetime | None = None,
        renewable_by: list[str] | None = None,
        re_check_on_use: bool = True,
        requires_approval: ApprovalRequirement | None = None,
        reason: str | None = None,
    ) -> Delegation:
        """Create or return an existing delegation.

        Performs two guard checks:
        1. Meta-authz: can *caller* delegate to *to_subject*?
        2. Narrowing: does *from_subject* hold each delegated scope?
        """
        now = self._clock()

        # 1. Meta-authz — apply default_delegate_policy first, then guard.authorize
        meta_allowed = self._resolve_meta_authz(
            caller, from_subject, to_subject, tenant_id
        )
        if not meta_allowed:
            raise DelegateNotPermittedError(
                f"{caller.id!r} is not permitted to delegate to {to_subject.id!r}"
            )

        # 2. Narrowing — from_subject must hold each scope being delegated
        for scope in scopes:
            action_name = (
                scope.action_match
                if isinstance(scope.action_match, str)
                else scope.action_match[0]
            )
            narrowing = self._guard.authorize(
                from_subject,
                Action(name=action_name),
                Resource(id="*", resource_type=scope.resource_type),
                tenant_id,
                _skip_delegation=True,
            )
            if narrowing.status != DecisionStatus.ALLOWED:
                raise DelegateNotPermittedError(
                    f"{from_subject.id!r} does not have permission for "
                    f"scope {scope.action_match!r} on {scope.resource_type!r}"
                )

        # 3. Chain-depth guard
        if parent_delegation_id is not None:
            existing_depth = self._chain_depth(parent_delegation_id, tenant_id)
            if existing_depth + 1 > self._max_delegation_depth:
                raise DelegationChainDepthExceededError(
                    f"Delegation chain depth {existing_depth + 1} exceeds "
                    f"maximum {self._max_delegation_depth}"
                )

        # 4. Idempotency — return existing if same request was already made
        req_hash = Delegation.make_hash(
            tenant_id=tenant_id,
            from_subject_id=from_subject.id,
            to_subject_id=to_subject.id,
            scopes=scopes,
            parent_delegation_id=parent_delegation_id,
            max_uses=max_uses,
            budget=budget,
            lease_ttl=lease_ttl,
            expires_at=expires_at,
        )
        existing = self._store.find_by_hash(req_hash, tenant_id)
        if existing is not None:
            return existing

        # 5. Initial state
        initial_status = (
            DelegationStatus.PENDING_APPROVAL
            if requires_approval is not None
            else DelegationStatus.ACTIVE
        )
        last_heartbeat_at = (
            now
            if lease_ttl is not None and initial_status == DelegationStatus.ACTIVE
            else None
        )

        delegation = Delegation(
            tenant_id=tenant_id,
            from_subject_id=from_subject.id,
            from_subject_type=from_subject.actor_type,
            to_subject_id=to_subject.id,
            to_subject_type=to_subject.actor_type,
            scopes=scopes,
            parent_delegation_id=parent_delegation_id,
            max_uses=max_uses,
            uses_remaining=max_uses,
            budget=budget,
            budget_remaining=budget,
            lease_ttl=lease_ttl,
            last_heartbeat_at=last_heartbeat_at,
            renewable_by=renewable_by,
            expires_at=expires_at,
            re_check_on_use=re_check_on_use,
            status=initial_status,
            request_hash=req_hash,
            created_at=now,
            created_by=caller.id,
            reason=reason,
        )

        # 6. Approval request
        if requires_approval is not None:
            approval_id = self._create_approval_request(
                requires_approval, delegation, tenant_id
            )
            delegation = delegation.model_copy(
                update={"approval_request_id": approval_id}
            )

        saved = self._store.create(delegation)

        if requires_approval is not None and saved.approval_request_id:
            self._pending_approval[saved.approval_request_id] = saved.id

        return saved

    # ------------------------------------------------------------------
    # on_approval_resolved
    # ------------------------------------------------------------------

    def on_approval_resolved(
        self, approval_request_id: str, tenant_id: str
    ) -> Delegation | None:
        """Transition the delegation tied to this approval to ACTIVE."""
        delegation_id = self._pending_approval.get(approval_request_id)
        if delegation_id is None:
            return None

        now = self._clock()
        d = self._store.get(delegation_id, tenant_id)
        if d is None:
            return None

        self._store.update_status(delegation_id, tenant_id, DelegationStatus.ACTIVE)

        if d.lease_ttl is not None:
            self._store.touch_heartbeat(delegation_id, tenant_id, now)

        return self._store.get(delegation_id, tenant_id)

    # ------------------------------------------------------------------
    # revoke
    # ------------------------------------------------------------------

    def revoke(
        self, delegation_id: str, *, caller: Subject, tenant_id: str
    ) -> Delegation:
        """Revoke a delegation and all its descendants (cascade)."""
        delegation = self._store.get(delegation_id, tenant_id)
        descendants = self._store.list_descendants(delegation_id, tenant_id)
        for desc in descendants:
            self._store.update_status(desc.id, tenant_id, DelegationStatus.REVOKED)
        result = self._store.update_status(
            delegation_id, tenant_id, DelegationStatus.REVOKED
        )
        if self._revocation_stream is not None:
            from open_guard.domain.entities import RevocationEvent, RevocationEventType
            self._revocation_stream.publish(RevocationEvent(
                event_type=RevocationEventType.DELEGATION_REVOKED,
                tenant_id=tenant_id,
                subject_id=delegation.to_subject_id if delegation is not None else None,
                delegation_id=delegation_id,
                reason=f"revoked by {caller.id}",
                timestamp=self._clock(),
            ))
        return result

    # ------------------------------------------------------------------
    # renew (heartbeat)
    # ------------------------------------------------------------------

    def renew(
        self,
        delegation_id: str,
        *,
        caller: Subject,
        tenant_id: str,
        now: datetime | None = None,
    ) -> Delegation:
        """Touch the heartbeat timestamp to keep the lease alive."""
        current_time = now or self._clock()

        d = self._store.get(delegation_id, tenant_id)
        if d is None:
            raise DelegationNotFoundError(
                f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
            )

        if d.renewable_by is not None and caller.id not in d.renewable_by:
            raise DelegateNotPermittedError(
                f"{caller.id!r} is not authorized to renew delegation {delegation_id!r}"
            )

        if d.expires_at is not None and current_time >= d.expires_at:
            raise LeaseExpiredError(
                f"Delegation {delegation_id!r} has expired at {d.expires_at}"
            )

        return self._store.touch_heartbeat(delegation_id, tenant_id, current_time)

    # ------------------------------------------------------------------
    # consume
    # ------------------------------------------------------------------

    def consume(
        self,
        delegation_id: str,
        tenant_id: str,
        *,
        amount: int = 1,
        cost: Decimal | None = None,
    ) -> Delegation:
        """Decrement uses and/or budget. Raises UsageExhaustedError if depleted."""
        d = self._store.decrement_uses(delegation_id, tenant_id, amount)
        if cost is not None:
            d = self._store.decrement_budget(delegation_id, tenant_id, cost)
        return d

    # ------------------------------------------------------------------
    # expire_stale
    # ------------------------------------------------------------------

    def expire_stale(self, tenant_id: str) -> int:
        """Expire stale delegations in the given tenant. Returns count expired."""
        return self._store.expire_stale(tenant_id, self._clock())

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _resolve_meta_authz(
        self,
        caller: Subject,
        from_subject: Subject,
        to_subject: Subject,
        tenant_id: str,
    ) -> bool:
        """Evaluate whether caller is permitted to delegate from_subject's permissions.

        Resolution order:
        1. ``default_delegate_policy="self_only"``: caller == from_subject → True.
           caller != from_subject → fall through to guard.authorize.
        2. ``default_delegate_policy=None``: skip built-in; must pass guard.authorize.
        3. guard.authorize call for explicit policy-based delegation permission.
        """
        if (
            self._default_delegate_policy == "self_only"
            and caller.id == from_subject.id
        ):
            return True
        # fall through to guard.authorize for explicit grants
        meta = self._guard.authorize(
            caller,
            Action(name="delegate"),
            Resource(id=to_subject.id, resource_type="delegation"),
            tenant_id,
        )
        return bool(meta.status == DecisionStatus.ALLOWED)

    def _chain_depth(self, delegation_id: str, tenant_id: str) -> int:
        """Walk the parent chain and return depth (root = 1)."""
        depth = 0
        current_id: str | None = delegation_id
        while current_id is not None:
            d = self._store.get(current_id, tenant_id)
            if d is None:
                break
            depth += 1
            current_id = d.parent_delegation_id
        return depth

    def _create_approval_request(
        self,
        requirement: ApprovalRequirement,
        delegation: Delegation,
        tenant_id: str,
    ) -> str:
        now = self._clock()
        expires_at = now + requirement.ttl if requirement.ttl is not None else None
        req = ApprovalRequest(
            tenant_id=tenant_id,
            request_hash=f"del-{delegation.request_hash}",
            subject_id=delegation.from_subject_id,
            action_name="delegate",
            resource_id=delegation.to_subject_id,
            resource_type="delegation",
            status=ApprovalStatus.PENDING,
            requirement=requirement,
            created_at=now,
            expires_at=expires_at,
        )
        if self._approval_store is None:
            raise RuntimeError(
                "approval_store is required when requires_approval is set"
            )
        self._approval_store.create(req)
        return req.id
