"""Async policy router — async policy fetch + evaluator dispatch (Phase 7)."""

from __future__ import annotations

import time
from collections.abc import Callable
from datetime import UTC, datetime

from open_guard.domain.entities import (
    AuthorizationRequest,
    Decision,
    DecisionStatus,
    DecisionTrace,
    Evaluation,
    EvaluatorTrace,
    OperationChainConfig,
    Policy,
    PolicyEffect,
    PolicyMatch,
    Subject,
    SubjectSnapshot,
)
from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
from open_guard.domain.ports.async_policy_store import AsyncPolicyStorePort
from open_guard.domain.ports.evaluator import EvaluatorPort


class AsyncReadOnlyPolicyView:
    """Read-only async wrapper around AsyncPolicyStorePort.

    Prevents the evaluation path from mutating policies.
    Evaluators receive policies through this view — add/remove are blocked.
    """

    def __init__(self, store: AsyncPolicyStorePort) -> None:
        self._store = store

    async def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        return await self._store.get_by_tenant(tenant_id)

    async def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        return await self._store.get_by_tenant_and_type(tenant_id, evaluator_type)

    async def add(self, policy: Policy) -> Policy:
        raise AttributeError(
            "PolicyStore is read-only during evaluation — "
            "mutations are not permitted on the evaluation path"
        )

    async def remove(self, policy_id: str, tenant_id: str) -> None:
        raise AttributeError(
            "PolicyStore is read-only during evaluation — "
            "mutations are not permitted on the evaluation path"
        )


class AsyncPolicyRouter:
    """Async dispatches authorization requests to typed evaluators and combines.

    Fetches policies asynchronously from the store, then dispatches to
    evaluators. Sync evaluators (RBAC/ABAC/TBAC) are called inline — they
    are pure CPU computation on pre-fetched policies. Async evaluators
    (e.g. AsyncReBACEvaluator) are awaited.

    Combination logic: any explicit deny → denied. All allow → allowed.
    No matching policies → denied (fail closed).
    """

    def __init__(
        self,
        evaluators: list[EvaluatorPort | AsyncEvaluatorPort],
        policy_store: AsyncPolicyStorePort,
        clock: Callable[[], datetime] | None = None,
        operation_chain: OperationChainConfig | None = None,
    ) -> None:
        self._evaluators = evaluators
        self._policy_store = AsyncReadOnlyPolicyView(policy_store)
        self._clock = clock or (lambda: datetime.now(UTC))
        self._operation_chain = operation_chain

    def _get_active_evaluators(
        self, action_name: str
    ) -> list[EvaluatorPort | AsyncEvaluatorPort]:
        """Filter evaluators based on operation chain config."""
        if self._operation_chain is None:
            return self._evaluators
        allowed_types = self._operation_chain.resolve(action_name)
        if allowed_types is None:
            return self._evaluators
        return [e for e in self._evaluators if e.evaluator_type in allowed_types]

    # ------------------------------------------------------------------
    # Standard path — returns Decision only
    # ------------------------------------------------------------------

    async def evaluate(self, request: AuthorizationRequest) -> Decision:
        """Evaluate an authorization request against all configured evaluators.

        Args:
            request: The authorization request.

        Returns:
            Combined decision from all evaluators.
        """
        policies = await self._policy_store.get_by_tenant(request.tenant_id)
        if not policies:
            return Decision(
                status=DecisionStatus.DENIED,
                reason="No policies found for tenant",
                evaluations=[],
            )
        evaluations = await self._run_against(request, policies)
        if not evaluations:
            return Decision(
                status=DecisionStatus.DENIED,
                reason="No evaluators matched any policies",
                evaluations=[],
            )
        return self._combine(evaluations)

    # ------------------------------------------------------------------
    # Traced path — returns Decision plus DecisionTrace
    # ------------------------------------------------------------------

    async def evaluate_traced(
        self, request: AuthorizationRequest
    ) -> tuple[Decision, DecisionTrace]:
        """Evaluate and return both the decision and a structured trace."""
        start_ns = time.perf_counter_ns()
        policies = await self._policy_store.get_by_tenant(request.tenant_id)
        if not policies:
            decision = Decision(
                allowed=False,
                reason="No policies found for tenant",
                evaluations=[],
            )
            duration_ms = (time.perf_counter_ns() - start_ns) / 1_000_000.0
            return decision, DecisionTrace(
                decision_status=decision.status,
                final_reason=decision.reason,
                composition="no-policies",
                actor_chain=self._render_chain(request.subject),
                duration_ms=duration_ms,
                timestamp=self._clock(),
            )

        evaluations, evaluator_times = await self._run_against_timed(
            request, policies
        )
        if not evaluations:
            decision = Decision(
                status=DecisionStatus.DENIED,
                reason="No evaluators matched any policies",
                evaluations=[],
            )
        else:
            decision = self._combine(evaluations)
        duration_ms = (time.perf_counter_ns() - start_ns) / 1_000_000.0

        eval_traces = [
            self._build_evaluator_trace(ev, evaluator_times.get(ev.evaluator, 0.0))
            for ev in evaluations
        ]
        actor_chain = self._render_chain(request.subject)

        trace = DecisionTrace(
            decision_status=decision.status,
            final_reason=decision.reason,
            evaluator_results=eval_traces,
            composition=_compose_label(evaluations, decision.status),
            actor_chain=actor_chain,
            duration_ms=duration_ms,
            timestamp=self._clock(),
        )
        return decision, trace

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _run_against(
        self,
        request: AuthorizationRequest,
        policies: list[Policy],
    ) -> list[Evaluation]:
        evaluations: list[Evaluation] = []
        for evaluator in self._get_active_evaluators(request.action.name):
            matching = [p for p in policies if evaluator.supports(p)]
            if not matching:
                continue
            if isinstance(evaluator, AsyncEvaluatorPort):
                evaluations.append(await evaluator.evaluate(request, matching))
            else:
                evaluations.append(evaluator.evaluate(request, matching))
        return evaluations

    async def _run_against_timed(
        self,
        request: AuthorizationRequest,
        policies: list[Policy],
    ) -> tuple[list[Evaluation], dict[str, float]]:
        evaluations: list[Evaluation] = []
        times: dict[str, float] = {}
        for evaluator in self._get_active_evaluators(request.action.name):
            matching = [p for p in policies if evaluator.supports(p)]
            if not matching:
                continue
            t0 = time.perf_counter_ns()
            if isinstance(evaluator, AsyncEvaluatorPort):
                ev = await evaluator.evaluate(request, matching)
            else:
                ev = evaluator.evaluate(request, matching)
            elapsed_ms = (time.perf_counter_ns() - t0) / 1_000_000.0
            evaluations.append(ev)
            times[ev.evaluator] = ev.duration_ms or elapsed_ms
        return evaluations, times

    def _combine(self, evaluations: list[Evaluation]) -> Decision:
        # Combine evaluator results with the following semantics:
        #
        # 1. Explicit deny: evaluator matched a DENY policy → always deny.
        # 2. No-allow-domain: evaluator processed policies but has NO allow-effect
        #    policies at all (only deny-effect ones, none of which matched) →
        #    treat as deny because the evaluator domain has no path to allow.
        # 3. Abstain: evaluator processed allow-effect policies but none matched
        #    the current request → abstain (allow another evaluator to grant).
        #    Example: RBAC has an allow policy for admins; a viewer subject gets
        #    no RBAC grant, but ABAC may still allow them independently.
        denied = [e for e in evaluations if self._is_denial(e)]
        if denied:
            reasons = "; ".join(e.reason for e in denied if e.reason)
            return Decision(
                status=DecisionStatus.DENIED,
                reason=f"Denied: {reasons}" if reasons else "Access denied",
                evaluations=evaluations,
            )

        # At least one evaluator must have actually matched an allow policy
        has_allow = any(e.allowed and e.matched_policies for e in evaluations)
        if not has_allow:
            return Decision(
                status=DecisionStatus.DENIED,
                reason="No allow policies matched",
                evaluations=evaluations,
            )

        reasons = "; ".join(e.reason for e in evaluations if e.reason)
        return Decision(
            status=DecisionStatus.ALLOWED,
            reason=f"Allowed: {reasons}" if reasons else "Access granted",
            evaluations=evaluations,
        )

    # Rejection reasons that constitute active access denials — the evaluator
    # had an applicable rule and it explicitly blocked the request.
    _ACTIVE_DENIAL_REASONS: frozenset[str] = frozenset({"condition(s) failed"})

    @staticmethod
    def _is_denial(evaluation: Evaluation) -> bool:
        """Determine whether an evaluator result constitutes an active denial.

        Semantics:
        - ``allowed=True`` → not a denial.
        - ``allowed=False`` with ``matched_policies`` non-empty → explicit deny
          (the evaluator matched a DENY policy and it won on priority).
        - ``allowed=False`` where any detail entry has reason
          ``"condition(s) failed"`` → active denial: attribute conditions or
          explicit conditions explicitly blocked the request.
        - ``allowed=False`` where all detail entries reflect mismatches
          (role, action, resource) → abstain: the evaluator's policies don't
          cover this subject/resource; another evaluator may still grant.
        - ``allowed=False`` with no detail → fail-closed denial.
        """
        if evaluation.allowed:
            return False
        # Explicit deny: a DENY policy was matched (priority-based win)
        if evaluation.matched_policies:
            return True
        detail = evaluation.matched_policies_detail
        if not detail:
            # No policies were applicable — fail-closed
            return True
        # If any rejection was due to a condition failing → active denial.
        # Otherwise all rejections are mismatches → evaluator abstains.
        return any(
            m.reason in AsyncPolicyRouter._ACTIVE_DENIAL_REASONS for m in detail
        )

    @staticmethod
    def _build_evaluator_trace(
        evaluation: Evaluation, duration_ms: float
    ) -> EvaluatorTrace:
        """Lift an Evaluation into an EvaluatorTrace for DecisionTrace."""
        status = (
            DecisionStatus.ALLOWED if evaluation.allowed else DecisionStatus.DENIED
        )

        # Prefer evaluator-emitted structured detail; else synthesize stubs
        # from the legacy matched_policies IDs so traces are never empty.
        if evaluation.matched_policies_detail:
            matched = [
                m for m in evaluation.matched_policies_detail if m.matched
            ]
            rejected = [
                m for m in evaluation.matched_policies_detail if not m.matched
            ]
        else:
            matched = [
                PolicyMatch(
                    policy_id=pid,
                    effect=(
                        PolicyEffect.ALLOW
                        if evaluation.allowed
                        else PolicyEffect.DENY
                    ),
                    matched=True,
                    reason=evaluation.reason,
                )
                for pid in evaluation.matched_policies
            ]
            rejected = []

        return EvaluatorTrace(
            evaluator=evaluation.evaluator,
            status=status,
            matched_policies=matched,
            rejected_policies=rejected,
            attributes_read=list(evaluation.attributes_read),
            duration_ms=evaluation.duration_ms or duration_ms,
        )

    @staticmethod
    def _render_chain(subject: Subject) -> list[SubjectSnapshot]:
        """Snapshot the actor chain from immediate actor up to the root."""
        chain: list[SubjectSnapshot] = [
            SubjectSnapshot(
                id=subject.id,
                actor_type=subject.actor_type,
                attributes=dict(subject.attributes),
            )
        ]
        for ancestor in subject.ancestors():
            chain.append(
                SubjectSnapshot(
                    id=ancestor.id,
                    actor_type=ancestor.actor_type,
                    attributes=dict(ancestor.attributes),
                )
            )
        return chain


def _compose_label(
    evaluations: list[Evaluation], final_status: DecisionStatus
) -> str:
    """Human-readable label for how results were combined."""
    if not evaluations:
        return "no-evaluators"
    if final_status == DecisionStatus.DENIED:
        if any(not e.allowed for e in evaluations):
            return "deny-wins"
        return "no-allow-matched"
    if final_status == DecisionStatus.PENDING_APPROVAL:
        return "pending-approval"
    return "all-allow"
