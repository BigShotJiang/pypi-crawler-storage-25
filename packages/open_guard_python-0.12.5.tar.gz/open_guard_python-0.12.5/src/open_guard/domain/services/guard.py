"""Guard — main entry point for authorization."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from open_guard.domain.entities import (
    Action,
    ApprovalRequest,
    ApprovalStatus,
    AuthorizationRequest,
    Cursor,
    Decision,
    DecisionStatus,
    DecisionTrace,
    ListResult,
    OperationChainConfig,
    Policy,
    PolicyEffect,
    Resource,
    SessionStatus,
    Subject,
)
from open_guard.domain.exceptions import (
    ApprovalError,
    ChainDepthExceededError,
)
from open_guard.domain.ports.approval_store import ApprovalStorePort
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.ports.delegation_store import DelegationStorePort
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.policy_store import PolicyStorePort
from open_guard.domain.ports.relationship_store import RelationshipStorePort
from open_guard.domain.ports.revocation_stream import RevocationStreamPort
from open_guard.domain.ports.session_store import SessionStorePort
from open_guard.domain.services.approval_manager import ApprovalManager
from open_guard.domain.services.policy_router import PolicyRouter


class Guard:
    """Unified authorization entry point.

    Provides ``authorize()`` for standard decisions and ``authorize_traced()``
    for decisions with a structured ``DecisionTrace`` (Phase 3).

    Phase 3 also adds the async-approval flow: policies with
    ``requires_approval`` cause ``authorize()`` to return a pending decision;
    consumers resume via ``approve()`` / ``reject()`` using the returned
    ``approval_request_id``.

    Usage:
        guard = Guard(
            policy_store=store,
            evaluators=[rbac, abac],
            approval_store=approvals,  # needed if any policy sets requires_approval
            max_chain_depth=5,
        )
        decision = guard.authorize(sub, act, res, tenant_id="t1")
        decision, trace = guard.authorize_traced(sub, act, res, tenant_id="t1")

    Args:
        policy_store: Where policies are fetched from.
        evaluators: Typed evaluators that participate in the decision.
        approval_store: Optional; required when any policy carries
            ``requires_approval``. ``Guard.approve()``/``reject()`` fail
            cleanly if absent.
        clock: Optional callable returning current UTC datetime. Defaults
            to ``datetime.now(UTC)``.
        max_chain_depth: Runtime cap on ``Subject.on_behalf_of`` depth
            (default 5). Construction-time cap is also enforced on the
            entity itself.
    """

    def __init__(
        self,
        policy_store: PolicyStorePort,
        evaluators: list[EvaluatorPort] | None = None,
        approval_store: ApprovalStorePort | None = None,
        clock: Callable[[], datetime] | None = None,
        max_chain_depth: int = 5,
        relationship_store: RelationshipStorePort | None = None,
        candidate_source: CandidateResourcePort | None = None,
        delegation_store: DelegationStorePort | None = None,
        max_delegation_depth: int = 10,
        default_delegate_policy: str | None = "self_only",
        session_store: SessionStorePort | None = None,
        revocation_stream: RevocationStreamPort | None = None,
        operation_chain: OperationChainConfig | None = None,
    ) -> None:
        self._policy_store = policy_store
        self._evaluators = evaluators or []
        self._clock = clock or (lambda: datetime.now(UTC))
        self._max_chain_depth = max_chain_depth
        self._router = PolicyRouter(
            evaluators=self._evaluators,
            policy_store=self._policy_store,
            clock=self._clock,
            operation_chain=operation_chain,
        )
        self._approval_store = approval_store
        self._approval_mgr = (
            ApprovalManager(approval_store=approval_store, clock=self._clock)
            if approval_store is not None
            else None
        )
        self._relationship_store = relationship_store
        self._candidate_source = candidate_source
        self._session_store = session_store
        self._revocation_stream = revocation_stream

        # Phase 5 — delegation wiring (optional; no-op when delegation_store is None)
        self._delegation_store = delegation_store
        self._delegation_evaluator = None
        self._delegation_manager = None
        if delegation_store is not None:
            # Late imports avoid circular dependency at module load time
            from open_guard.domain.services.delegation_evaluator import (
                DelegationEvaluator,
            )
            from open_guard.domain.services.delegation_manager import DelegationManager

            self._delegation_evaluator = DelegationEvaluator(
                delegation_store=delegation_store, guard=self
            )
            self._delegation_manager = DelegationManager(
                delegation_store=delegation_store,
                guard=self,
                approval_store=approval_store,
                clock=self._clock,
                max_delegation_depth=max_delegation_depth,
                default_delegate_policy=default_delegate_policy,
                revocation_stream=revocation_stream,
            )

    @classmethod
    def from_config(
        cls,
        dsn: str | None = None,
        *,
        backend: str | None = None,
        **kwargs: Any,
    ) -> Guard:
        """Create a fully-wired Guard from a DSN or backend name.

        Examples::

            guard = Guard.from_config(backend="memory")
            guard = Guard.from_config("sqlite:///local.db")
            guard = Guard.from_config("postgresql://user:pass@host/db")
        """
        from open_guard.adapters.factory import build_guard

        return build_guard(dsn, backend=backend, **kwargs)

    @property
    def policy_store(self) -> PolicyStorePort:
        """Access the policy store for CRUD operations."""
        return self._policy_store

    @property
    def approval_store(self) -> ApprovalStorePort | None:
        """The configured approval store (None if not provided)."""
        return self._approval_store

    # ------------------------------------------------------------------
    # authorize() — standard path
    # ------------------------------------------------------------------

    def authorize(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
        _skip_delegation: bool = False,
        _recheck_cache: dict[tuple[str, ...], Any] | None = None,
    ) -> Decision:
        """Authorize a subject to perform an action on a resource.

        Returns:
            Decision with status ∈ {ALLOWED, DENIED, PENDING_APPROVAL}.

        _skip_delegation: internal flag set by DelegationEvaluator to prevent
            recursive delegation lookup when re-checking grantor permissions.
        """
        self._enforce_chain_depth(subject)
        ctx = dict(context) if context else {}
        self._resolve_session(session_id, tenant_id, ctx)
        request = AuthorizationRequest(
            subject=subject,
            action=action,
            resource=resource,
            tenant_id=tenant_id,
            context=ctx,
        )
        decision = self._evaluate_with_approval(request)

        # Phase 5 (T9): mark non_delegable_policy on re-check calls so
        # DelegationEvaluator can block delegations of non-delegable permissions.
        if (
            _skip_delegation
            and decision.status == DecisionStatus.ALLOWED
            and self._any_matched_policy_non_delegable(decision, request)
        ):
            decision = decision.model_copy(update={"non_delegable_policy": True})

        if (
            decision.status == DecisionStatus.DENIED
            and not _skip_delegation
            and self._delegation_evaluator is not None
        ):
            from open_guard.domain.entities import Evaluation

            d_result = self._delegation_evaluator.evaluate(
                subject, action, resource, tenant_id,
                recheck_cache=_recheck_cache,
            )
            if d_result.allowed:
                return Decision(
                    status=DecisionStatus.ALLOWED,
                    reason="delegation",
                    evaluations=[
                        *decision.evaluations,
                        Evaluation(
                            evaluator="delegation",
                            allowed=True,
                            reason="delegation",
                            matched_policies=d_result.matched_delegation_ids,
                        ),
                    ],
                )

        return decision

    # ------------------------------------------------------------------
    # authorize_traced() — explainability path
    # ------------------------------------------------------------------

    def authorize_traced(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
    ) -> tuple[Decision, DecisionTrace]:
        """Authorize and return a structured ``DecisionTrace`` alongside.

        Trace is always built here; hot-path ``authorize()`` never materializes
        one (privacy + performance).
        """
        self._enforce_chain_depth(subject)
        ctx = dict(context) if context else {}
        self._resolve_session(session_id, tenant_id, ctx)
        request = AuthorizationRequest(
            subject=subject,
            action=action,
            resource=resource,
            tenant_id=tenant_id,
            context=ctx,
        )
        # For pending_approval, we still build a trace from the router's
        # pre-approval evaluation; the status on the trace reflects the final
        # outcome (pending_approval when the approval gate fires).
        decision, trace = self._router.evaluate_traced(request)
        final = self._apply_approval_gate(decision, request)
        if final.status == decision.status:
            return final, trace
        # Rebuild trace decision_status so consumers see the approval state
        traced = trace.model_copy(
            update={
                "decision_status": final.status,
                "final_reason": final.reason,
                "composition": (
                    "pending-approval"
                    if final.status == DecisionStatus.PENDING_APPROVAL
                    else trace.composition
                ),
            }
        )
        return final, traced

    # ------------------------------------------------------------------
    # approve() / reject()
    # ------------------------------------------------------------------

    def approve(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record an approval for a pending request."""
        if self._approval_mgr is None:
            raise ApprovalError(
                "Guard has no approval_store configured — cannot approve requests"
            )
        return self._approval_mgr.approve(request_id, tenant_id, approver, reason)

    def reject(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record a rejection for a pending request."""
        if self._approval_mgr is None:
            raise ApprovalError(
                "Guard has no approval_store configured — cannot reject requests"
            )
        return self._approval_mgr.reject(request_id, tenant_id, approver, reason)

    # ------------------------------------------------------------------
    # list_authorized() — Phase 4 (FEAT-006)
    # ------------------------------------------------------------------

    def list_authorized(
        self,
        subject: Subject,
        action: str,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None = None,
        limit: int = 100,
        cursor: str | None = None,
        context: dict[str, Any] | None = None,
        relationship_store: RelationshipStorePort | None = None,
        candidate_source: CandidateResourcePort | None = None,
        session_id: str | None = None,
    ) -> ListResult:
        """Enumerate resource IDs the subject may perform ``action`` on.

        Industry-standard hybrid approach (AWS Verified Permissions /
        Casbin ``enforce_batch``):
          1. Collect candidate IDs from ReBAC tuples via
             ``RelationshipStorePort.find_object_ids_for_subject``.
          2. Collect candidates from a consumer-provided
             ``CandidateResourcePort`` (for ABAC/RBAC-driven resources).
          3. Iterate candidates calling :meth:`authorize` per resource.
             IDs where the decision is ``ALLOWED`` are returned.

        Composition is identical to :meth:`authorize` by construction.
        Pending-approval and deny decisions are excluded from the list —
        only ``ALLOWED`` lands in the result set.

        Cursor stability under concurrent policy changes is explicitly
        undefined (Zanzibar-style zookies deferred to ENH-015).

        Args:
            subject: The requesting subject (chain depth enforced).
            action: Action name (e.g., ``"read"``, ``"invoke"``).
            resource_type: Type to enumerate (e.g., ``"doc"``, ``"tool"``).
            tenant_id: Tenant scope.
            prefilter: Optional attribute prefilter passed to the candidate
                source. Not applied to ReBAC tuples (they encode their own
                filtering via relation/object_type).
            limit: Max IDs to return (default 100).
            cursor: Opaque continuation token from a prior call.
            context: Optional authorization context (same as :meth:`authorize`).
            relationship_store: Overrides the Guard-level relationship
                store for this call.
            candidate_source: Overrides the Guard-level candidate source
                for this call.
        """
        self._enforce_chain_depth(subject)

        if limit <= 0:
            return ListResult(ids=[], next_cursor=None)

        rel_store = relationship_store or self._relationship_store
        cand_source = candidate_source or self._candidate_source

        cur = Cursor.decode(cursor) if cursor else Cursor()
        action_obj = Action(name=action)
        ctx = dict(context) if context else {}
        self._resolve_session(session_id, tenant_id, ctx)

        allow_ids: list[str] = []
        seen: set[str] = set(cur.seen_ids)

        chunk_size = max(limit, 50)

        # 1. Candidate source first — when it's wired, it carries richer
        #    resource attributes (classification, owner, etc.) that ABAC
        #    and RBAC policies can match against. ReBAC tuples only carry
        #    IDs, so materializing resources from them loses attribute
        #    context. Preferring the candidate source avoids that gap.
        source_cursor: dict[str, Any] | None = cur.candidate_cursor or None
        source_exhausted = cand_source is None
        while not source_exhausted and len(allow_ids) < limit:
            assert cand_source is not None
            # Fetch at most the remaining slack so we don't over-pull from
            # the source and strand un-inspected rows behind a terminal
            # cursor. A small floor keeps single-call efficiency reasonable
            # when most candidates are denied.
            remaining = limit - len(allow_ids)
            fetch_size = max(remaining, 10)
            candidates, next_source_cursor = cand_source.fetch_candidates(
                resource_type=resource_type,
                tenant_id=tenant_id,
                prefilter=prefilter,
                cursor=source_cursor,
                limit=fetch_size,
            )
            if not candidates and next_source_cursor is None:
                source_exhausted = True
                break
            hit_limit = False
            for resource in candidates:
                if resource.id in seen:
                    continue
                seen.add(resource.id)
                decision = self.authorize(
                    subject, action_obj, resource, tenant_id, ctx
                )
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(resource.id)
                    if len(allow_ids) >= limit:
                        hit_limit = True
                        break
            # Only advance to the next page when we fully consumed this one.
            # If we hit the limit early, the remaining candidates in this
            # batch stay behind `source_cursor`, to be re-fetched next call.
            if hit_limit:
                break
            if next_source_cursor is None:
                source_exhausted = True
                break
            source_cursor = next_source_cursor

        # 2. ReBAC native enumeration — picks up IDs the candidate source
        #    didn't yield (or runs as the sole source when no candidate
        #    source is wired). Resources are materialized with minimal
        #    attributes (``type`` mirrors ``resource_type``), so policies
        #    that depend on richer resource attributes should rely on a
        #    candidate source being wired.
        rebac_offset = cur.rebac_offset
        rebac_exhausted = rel_store is None
        while not rebac_exhausted and len(allow_ids) < limit:
            assert rel_store is not None
            batch = rel_store.find_object_ids_for_subject(
                subject_id=subject.id,
                subject_type=subject.actor_type.value,
                object_type=resource_type,
                tenant_id=tenant_id,
                offset=rebac_offset,
                limit=chunk_size,
            )
            if not batch:
                rebac_exhausted = True
                break
            processed = 0
            hit_limit = False
            for obj_id in batch:
                processed += 1
                if obj_id in seen:
                    continue
                seen.add(obj_id)
                resource = Resource(
                    id=obj_id,
                    resource_type=resource_type,
                    tenant_id=tenant_id,
                    attributes={"type": resource_type},
                )
                decision = self.authorize(
                    subject, action_obj, resource, tenant_id, ctx
                )
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(obj_id)
                    if len(allow_ids) >= limit:
                        hit_limit = True
                        break
            rebac_offset += processed
            if not hit_limit and len(batch) < chunk_size:
                rebac_exhausted = True

        # 3. Delegation concrete-ID contribution — Phase 5 (T11).
        #    list_contribution emits only id:eq/in scopes, so it can be enumerated
        #    without a candidate source. These calls use authorize() which never
        #    consumes usage (only authorize_and_consume does).
        if self._delegation_evaluator is not None and len(allow_ids) < limit:
            delegation_ids = self._delegation_evaluator.list_contribution(
                subject, tenant_id, resource_type=resource_type
            )
            for obj_id in delegation_ids:
                if obj_id in seen:
                    continue
                seen.add(obj_id)
                resource = Resource(
                    id=obj_id,
                    resource_type=resource_type,
                    tenant_id=tenant_id,
                    attributes={"type": resource_type},
                )
                decision = self.authorize(subject, action_obj, resource, tenant_id, ctx)
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(obj_id)
                    if len(allow_ids) >= limit:
                        break

        has_more = len(allow_ids) >= limit and not (
            rebac_exhausted and source_exhausted
        )
        next_token: str | None = None
        if has_more:
            next_token = Cursor(
                rebac_offset=rebac_offset,
                candidate_cursor=source_cursor or {},
                seen_ids=seen,
            ).encode()
        return ListResult(ids=allow_ids, next_cursor=next_token)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _resolve_session(
        self,
        session_id: str | None,
        tenant_id: str,
        ctx: dict[str, Any],
    ) -> None:
        """Resolve a session and inject it into ``ctx["_session"]``.

        Mutates ``ctx`` in place. Raises ``SessionNotFoundError`` if
        ``session_id`` is provided but no matching session can be found
        (either because the session store is unconfigured or the session
        does not exist).
        """
        if session_id is None:
            return
        if self._session_store is None:
            from open_guard.domain.exceptions import SessionNotFoundError
            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        session = self._session_store.get(session_id, tenant_id)
        if session is None:
            from open_guard.domain.exceptions import SessionNotFoundError
            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        # Lazy expiry check
        if (
            session.status == SessionStatus.ACTIVE
            and session.expires_at is not None
            and session.expires_at <= self._clock()
        ):
            session = self._session_store.update_status(
                session_id, tenant_id, SessionStatus.EXPIRED
            )
        ctx["_session"] = session

    def _enforce_chain_depth(self, subject: Subject) -> None:
        if subject.chain_depth > self._max_chain_depth:
            raise ChainDepthExceededError(
                f"Subject chain depth {subject.chain_depth} exceeds "
                f"Guard.max_chain_depth {self._max_chain_depth}"
            )

    def _evaluate_with_approval(
        self, request: AuthorizationRequest
    ) -> Decision:
        decision = self._router.evaluate(request)
        return self._apply_approval_gate(decision, request)

    def _apply_approval_gate(
        self, decision: Decision, request: AuthorizationRequest
    ) -> Decision:
        """Intercept ALLOWED decisions from allow policies that require approval.

        Resolution rules:
        - The router returns ALLOWED only when at least one allow policy
          matched. We inspect those policies: if any has ``requires_approval``,
          we enter the approval gate.
        - If an existing request is APPROVED, we allow.
        - If REJECTED or EXPIRED, we deny.
        - If PENDING (or we must create one), we return PENDING_APPROVAL.
        - If the policy requires approval but no approval_store is configured,
          we raise ApprovalError so the consumer misconfiguration surfaces.
        """
        if decision.status != DecisionStatus.ALLOWED:
            return decision

        matched_policy = self._find_requires_approval_policy(decision, request)
        if matched_policy is None:
            return decision

        if self._approval_mgr is None:
            raise ApprovalError(
                "Policy requires_approval is set but Guard has no "
                "approval_store configured"
            )
        requirement = matched_policy.requires_approval
        assert requirement is not None  # narrowed by _find_...

        store = self._approval_store
        assert store is not None
        store.expire_stale(request.tenant_id, self._clock())

        req_hash = ApprovalRequest.make_hash(
            request.tenant_id,
            request.subject.id,
            request.action.name,
            request.resource.id,
            request.resource.resource_type,
        )
        # Consult the latest record for this (tenant, hash) regardless of status
        latest = store.find_latest_by_hash(req_hash, request.tenant_id)

        if latest is None:
            # Never requested — create fresh PENDING
            created = self._approval_mgr.request_or_existing(
                tenant_id=request.tenant_id,
                subject=request.subject,
                action=request.action,
                resource=request.resource,
                requirement=requirement,
            )
            return Decision(
                status=DecisionStatus.PENDING_APPROVAL,
                reason="Awaiting approval",
                evaluations=decision.evaluations,
                approval_request_id=created.id,
            )

        if latest.status == ApprovalStatus.PENDING:
            return Decision(
                status=DecisionStatus.PENDING_APPROVAL,
                reason="Awaiting approval",
                evaluations=decision.evaluations,
                approval_request_id=latest.id,
            )
        if latest.status == ApprovalStatus.APPROVED:
            return decision  # allow — historical approval honored
        if latest.status == ApprovalStatus.REJECTED:
            reason = "approval rejected"
            if latest.reason:
                reason = f"{reason}: {latest.reason}"
            return Decision(
                status=DecisionStatus.DENIED,
                reason=reason,
                evaluations=decision.evaluations,
            )
        # EXPIRED — create a fresh PENDING for this attempt
        created = self._approval_mgr.request_or_existing(
            tenant_id=request.tenant_id,
            subject=request.subject,
            action=request.action,
            resource=request.resource,
            requirement=requirement,
        )
        return Decision(
            status=DecisionStatus.PENDING_APPROVAL,
            reason="Awaiting approval (previous request expired)",
            evaluations=decision.evaluations,
            approval_request_id=created.id,
        )

    def _find_requires_approval_policy(
        self,
        decision: Decision,
        request: AuthorizationRequest,
    ) -> Policy | None:
        """Find a matched ALLOW policy for this request that requires approval."""
        matched_ids = {
            pid
            for ev in decision.evaluations
            if ev.allowed
            for pid in ev.matched_policies
        }
        if not matched_ids:
            return None
        all_policies = self._policy_store.get_by_tenant(request.tenant_id)
        for p in all_policies:
            if (
                p.id in matched_ids
                and p.effect == PolicyEffect.ALLOW
                and p.requires_approval is not None
            ):
                return p
        return None

    # ------------------------------------------------------------------
    # Phase 5 — Delegation proxy methods
    # ------------------------------------------------------------------

    def _any_matched_policy_non_delegable(
        self, decision: Decision, request: AuthorizationRequest
    ) -> bool:
        matched_ids = {
            pid for ev in decision.evaluations for pid in ev.matched_policies
        }
        if not matched_ids:
            return False
        all_policies = self._policy_store.get_by_tenant(request.tenant_id)
        return any(
            p.id in matched_ids and getattr(p, "non_delegable", False)
            for p in all_policies
        )

    def _require_delegation_manager(self) -> Any:
        if self._delegation_manager is None:
            raise RuntimeError(
                "Guard is not configured with a delegation_store. "
                "Pass delegation_store= to Guard.__init__ to enable delegation."
            )
        return self._delegation_manager

    def delegate(self, **kwargs: Any) -> Any:
        """Create or return an existing delegation. Proxies to DelegationManager."""
        return self._require_delegation_manager().delegate(**kwargs)

    def revoke_delegation(
        self, delegation_id: str, *, caller: Subject, tenant_id: str
    ) -> Any:
        """Revoke a delegation and all its descendants."""
        return self._require_delegation_manager().revoke(
            delegation_id, caller=caller, tenant_id=tenant_id
        )

    def renew_delegation(
        self,
        delegation_id: str,
        *,
        caller: Subject,
        tenant_id: str,
        now: Any | None = None,
    ) -> Any:
        """Touch the heartbeat timestamp to keep a lease-based delegation alive."""
        return self._require_delegation_manager().renew(
            delegation_id, caller=caller, tenant_id=tenant_id, now=now
        )

    def consume_delegation(
        self,
        delegation_id: str,
        tenant_id: str,
        *,
        amount: int = 1,
        cost: Any | None = None,
    ) -> Any:
        """Decrement delegation usage counters."""
        return self._require_delegation_manager().consume(
            delegation_id, tenant_id, amount=amount, cost=cost
        )

    def authorize_and_consume(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        amount: int = 1,
        cost: Any | None = None,
    ) -> Decision:
        """Authorize and, if delegation grants access, consume usage counters.

        Policy-based grants and DENIED decisions never touch delegation counters.
        """
        decision = self.authorize(subject, action, resource, tenant_id, context)
        if decision.status == DecisionStatus.ALLOWED:
            delegation_ids = [
                pid
                for ev in decision.evaluations
                if ev.evaluator == "delegation"
                for pid in ev.matched_policies
            ]
            mgr = self._delegation_manager
            if mgr is not None and delegation_ids:
                for did in delegation_ids:
                    mgr.consume(did, tenant_id, amount=amount, cost=cost)
        return decision
