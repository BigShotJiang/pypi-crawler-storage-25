"""AsyncApprovalManager — async sibling of ApprovalManager (Phase 11, FEAT-015).

Mirrors :class:`ApprovalManager`. Async I/O over the async approval store.
Pure helpers (approver match, quorum count, SHA-256 idempotency hashing via
:meth:`ApprovalRequest.make_hash`) are reused from the sync module — no
parallel logic.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from open_guard.domain.entities import (
    Action,
    ApprovalDecision,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.ports.async_approval_store import AsyncApprovalStorePort
from open_guard.domain.services.approval_manager import (
    _approver_allowed,
    _quorum_met,
)


class AsyncApprovalManager:
    """Async counterpart of :class:`ApprovalManager`."""

    def __init__(
        self,
        approval_store: AsyncApprovalStorePort,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._store = approval_store
        self._clock = clock or (lambda: datetime.now(UTC))

    # ------------------------------------------------------------------
    # Creation / lookup
    # ------------------------------------------------------------------

    async def request_or_existing(
        self,
        *,
        tenant_id: str,
        subject: Subject,
        action: Action,
        resource: Resource,
        requirement: ApprovalRequirement,
    ) -> ApprovalRequest:
        """Return the PENDING request for this key, creating if absent."""
        now = self._clock()
        await self._store.expire_stale(tenant_id, now)

        req_hash = ApprovalRequest.make_hash(
            tenant_id, subject.id, action.name, resource.id, resource.resource_type
        )
        existing = await self._store.find_by_hash(req_hash, tenant_id)
        if existing is not None:
            return existing

        expires_at: datetime | None = None
        if requirement.ttl is not None:
            expires_at = now + requirement.ttl

        request = ApprovalRequest(
            tenant_id=tenant_id,
            request_hash=req_hash,
            subject_id=subject.id,
            action_name=action.name,
            resource_id=resource.id,
            resource_type=resource.resource_type,
            status=ApprovalStatus.PENDING,
            requirement=requirement,
            created_at=now,
            expires_at=expires_at,
        )
        return await self._store.create(request)

    async def check_status(
        self, request_id: str, tenant_id: str
    ) -> ApprovalRequest:
        """Return the request, auto-expiring it if past TTL."""
        now = self._clock()
        await self._store.expire_stale(tenant_id, now)
        req = await self._store.get(request_id, tenant_id)
        if req is None:
            raise ApprovalError(
                f"ApprovalRequest {request_id} not found in tenant {tenant_id}"
            )
        return req

    # ------------------------------------------------------------------
    # Resolution: approve / reject
    # ------------------------------------------------------------------

    async def approve(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record an approval. Transitions to APPROVED when quorum is met."""
        req = await self.check_status(request_id, tenant_id)
        if req.status != ApprovalStatus.PENDING:
            raise ApprovalError(
                f"ApprovalRequest {request_id} is {req.status.value}, not pending"
            )
        if not _approver_allowed(approver, req.requirement):
            raise ApprovalError(
                f"Approver {approver!r} not in allowed approvers for "
                f"request {request_id}"
            )
        if any(d.approver == approver for d in req.approvers_received):
            raise ApprovalError(
                f"Approver {approver!r} already voted on request {request_id}"
            )

        now = self._clock()
        decision = ApprovalDecision(
            approver=approver, decision="approve", reason=reason, at=now
        )
        new_received = [*req.approvers_received, decision]
        approvals = [d for d in new_received if d.decision == "approve"]

        if _quorum_met(approvals, req.requirement):
            updated = req.model_copy(
                update={
                    "status": ApprovalStatus.APPROVED,
                    "approvers_received": new_received,
                    "resolved_at": now,
                    "reason": reason,
                }
            )
        else:
            updated = req.model_copy(
                update={"approvers_received": new_received}
            )
        return await self._store.update(updated)

    async def reject(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record a rejection. Any single rejection finalizes as REJECTED."""
        req = await self.check_status(request_id, tenant_id)
        if req.status != ApprovalStatus.PENDING:
            raise ApprovalError(
                f"ApprovalRequest {request_id} is {req.status.value}, not pending"
            )
        if not _approver_allowed(approver, req.requirement):
            raise ApprovalError(
                f"Approver {approver!r} not in allowed approvers for "
                f"request {request_id}"
            )

        now = self._clock()
        decision = ApprovalDecision(
            approver=approver, decision="reject", reason=reason, at=now
        )
        updated = req.model_copy(
            update={
                "status": ApprovalStatus.REJECTED,
                "approvers_received": [*req.approvers_received, decision],
                "resolved_at": now,
                "reason": reason or "rejected",
            }
        )
        return await self._store.update(updated)
