"""AsyncGuard -- async authorization entry point (Phase 7)."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from open_guard.domain.entities import (
    Action,
    ApprovalRequest,
    ApprovalStatus,
    AuthorizationRequest,
    Cursor,
    Decision,
    DecisionStatus,
    DecisionTrace,
    ListResult,
    OperationChainConfig,
    Policy,
    PolicyEffect,
    Resource,
    SessionStatus,
    Subject,
)
from open_guard.domain.exceptions import ApprovalError, ChainDepthExceededError
from open_guard.domain.ports.async_approval_store import AsyncApprovalStorePort
from open_guard.domain.ports.async_candidate_resource import AsyncCandidateResourcePort
from open_guard.domain.ports.async_delegation_store import AsyncDelegationStorePort
from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
from open_guard.domain.ports.async_policy_store import AsyncPolicyStorePort
from open_guard.domain.ports.async_relationship_store import AsyncRelationshipStorePort
from open_guard.domain.ports.async_session_store import AsyncSessionStorePort
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.services.async_policy_router import AsyncPolicyRouter


class AsyncGuard:
    """Async authorization entry point.  Mirrors :class:`Guard` with ``async def``.

    Provides ``authorize()`` for standard decisions and ``authorize_traced()``
    for decisions with a structured ``DecisionTrace``.

    Usage::

        guard = await AsyncGuard.from_config(backend="memory")
        decision = await guard.authorize(sub, act, res, tenant_id="t1")
        decision, trace = await guard.authorize_traced(sub, act, res, tenant_id="t1")
        result = await guard.list_authorized(sub, "read", "doc", tenant_id="t1")
    """

    def __init__(
        self,
        policy_store: AsyncPolicyStorePort,
        evaluators: list[EvaluatorPort | AsyncEvaluatorPort] | None = None,
        approval_store: AsyncApprovalStorePort | None = None,
        clock: Callable[[], datetime] | None = None,
        max_chain_depth: int = 5,
        relationship_store: AsyncRelationshipStorePort | None = None,
        candidate_source: AsyncCandidateResourcePort | None = None,
        delegation_store: AsyncDelegationStorePort | None = None,
        max_delegation_depth: int = 10,
        session_store: AsyncSessionStorePort | None = None,
        operation_chain: OperationChainConfig | None = None,
    ) -> None:
        self._policy_store = policy_store
        self._evaluators = evaluators or []
        self._clock = clock or (lambda: datetime.now(UTC))
        self._max_chain_depth = max_chain_depth
        self._relationship_store = relationship_store
        self._candidate_source = candidate_source
        self._delegation_store = delegation_store
        self._session_store = session_store
        self._approval_store = approval_store
        self._max_delegation_depth = max_delegation_depth

        # Phase 11 (FEAT-015) — approval manager
        self._approval_mgr: Any = None
        if approval_store is not None:
            from open_guard.domain.services.async_approval_manager import (
                AsyncApprovalManager,
            )

            self._approval_mgr = AsyncApprovalManager(
                approval_store=approval_store, clock=self._clock
            )
        # Delegation wiring (FEAT-014) — eager if delegation_store provided
        self._delegation_evaluator: Any = None
        self._delegation_manager: Any = None
        if delegation_store is not None:
            from open_guard.domain.services.async_delegation_evaluator import (
                AsyncDelegationEvaluator,
            )
            from open_guard.domain.services.async_delegation_manager import (
                AsyncDelegationManager,
            )

            self._delegation_evaluator = AsyncDelegationEvaluator(
                delegation_store=delegation_store, guard=self
            )
            self._delegation_manager = AsyncDelegationManager(
                delegation_store=delegation_store,
                guard=self,
                approval_store=approval_store,
                clock=self._clock,
                max_delegation_depth=max_delegation_depth,
            )

        self._policy_router = AsyncPolicyRouter(
            evaluators=self._evaluators,
            policy_store=self._policy_store,
            clock=self._clock,
            operation_chain=operation_chain,
        )

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------

    @classmethod
    async def from_config(
        cls,
        dsn: str | None = None,
        *,
        backend: str | None = None,
        **kwargs: Any,
    ) -> AsyncGuard:
        """Create a fully-wired AsyncGuard from a DSN or backend name.

        Examples::

            guard = await AsyncGuard.from_config(backend="memory")
            guard = await AsyncGuard.from_config("sqlite:///local.db")
        """
        from open_guard.adapters.factory import build_async_guard

        guard: AsyncGuard = await build_async_guard(dsn, backend=backend, **kwargs)
        return guard

    # ------------------------------------------------------------------
    # Public properties
    # ------------------------------------------------------------------

    @property
    def policy_store(self) -> AsyncPolicyStorePort:
        """Access the policy store for CRUD operations."""
        return self._policy_store

    @property
    def approval_store(self) -> AsyncApprovalStorePort | None:
        """The configured approval store (None if not provided)."""
        return self._approval_store

    # ------------------------------------------------------------------
    # authorize()
    # ------------------------------------------------------------------

    async def authorize(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
        _skip_delegation: bool = False,
        _recheck_cache: dict[tuple[str, ...], Any] | None = None,
    ) -> Decision:
        """Authorize a subject to perform an action on a resource.

        Returns:
            Decision with status in {ALLOWED, DENIED, PENDING_APPROVAL}.

        ``_skip_delegation``: internal flag set by AsyncDelegationEvaluator
        to prevent recursive delegation lookup when re-checking grantor
        permissions.
        """
        self._enforce_chain_depth(subject)
        ctx = dict(context) if context else {}
        await self._resolve_session(session_id, tenant_id, ctx)
        request = AuthorizationRequest(
            subject=subject,
            action=action,
            resource=resource,
            tenant_id=tenant_id,
            context=ctx,
        )
        decision = await self._evaluate_with_approval(request)

        # Mark non_delegable_policy on re-check calls so AsyncDelegationEvaluator
        # can block delegations of non-delegable permissions.
        if (
            _skip_delegation
            and decision.status == DecisionStatus.ALLOWED
            and await self._any_matched_policy_non_delegable(decision, request)
        ):
            decision = decision.model_copy(update={"non_delegable_policy": True})

        # Phase 11 (FEAT-014): delegation fallback on DENIED.
        if (
            decision.status == DecisionStatus.DENIED
            and not _skip_delegation
            and self._delegation_evaluator is not None
        ):
            from open_guard.domain.entities import Evaluation

            d_result = await self._delegation_evaluator.evaluate(
                subject,
                action,
                resource,
                tenant_id,
                recheck_cache=_recheck_cache,
            )
            if d_result.allowed:
                return Decision(
                    status=DecisionStatus.ALLOWED,
                    reason="delegation",
                    evaluations=[
                        *decision.evaluations,
                        Evaluation(
                            evaluator="delegation",
                            allowed=True,
                            reason="delegation",
                            matched_policies=d_result.matched_delegation_ids,
                        ),
                    ],
                )

        return decision

    # ------------------------------------------------------------------
    # authorize_traced()
    # ------------------------------------------------------------------

    async def authorize_traced(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        session_id: str | None = None,
    ) -> tuple[Decision, DecisionTrace]:
        """Authorize and return a structured ``DecisionTrace`` alongside.

        Trace is always built here; hot-path ``authorize()`` never
        materializes one (privacy + performance).
        """
        self._enforce_chain_depth(subject)
        ctx = dict(context) if context else {}
        await self._resolve_session(session_id, tenant_id, ctx)
        request = AuthorizationRequest(
            subject=subject,
            action=action,
            resource=resource,
            tenant_id=tenant_id,
            context=ctx,
        )
        decision, trace = await self._policy_router.evaluate_traced(request)
        final = await self._apply_approval_gate(decision, request)
        if final.status == decision.status:
            return final, trace
        # Rebuild trace decision_status so consumers see the approval state
        traced = trace.model_copy(
            update={
                "decision_status": final.status,
                "final_reason": final.reason,
                "composition": (
                    "pending-approval"
                    if final.status == DecisionStatus.PENDING_APPROVAL
                    else trace.composition
                ),
            }
        )
        return final, traced

    # ------------------------------------------------------------------
    # list_authorized() — Phase 11 (FEAT-018) async parity of Phase 4 sync version
    # ------------------------------------------------------------------

    async def list_authorized(
        self,
        subject: Subject,
        action: str,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None = None,
        limit: int = 100,
        cursor: str | None = None,
        context: dict[str, Any] | None = None,
        relationship_store: AsyncRelationshipStorePort | None = None,
        candidate_source: AsyncCandidateResourcePort | None = None,
        session_id: str | None = None,
    ) -> ListResult:
        """Async parity of :meth:`Guard.list_authorized`.

        Industry-standard reverse-lookup primitive — same shape as OpenFGA
        ``ListObjects`` / Auth0 FGA ``listObjects`` / Zanzibar /
        SpiceDB ``LookupResources`` / AWS Verified Permissions
        ``BatchIsAuthorized`` / Cerbos ``PlanResources`` /
        Casbin ``getImplicitResourcesForUser``.

        Composes three sources sequentially (see ADR-0001):
          1. Consumer-provided ``AsyncCandidateResourcePort`` (ABAC/RBAC).
          2. ReBAC native enumeration via
             ``AsyncRelationshipStorePort.find_object_ids_for_subject``.
          3. Delegation concrete-ID contribution (lit up by FEAT-014).

        Composition is identical to :meth:`authorize` by construction —
        pending-approval and deny decisions are excluded from the result.

        Cursor stability under concurrent policy changes is explicitly
        undefined (Zanzibar-style zookies deferred to ENH-015).
        """
        self._enforce_chain_depth(subject)

        if limit <= 0:
            return ListResult(ids=[], next_cursor=None)

        rel_store = relationship_store or self._relationship_store
        cand_source = candidate_source or self._candidate_source

        cur = Cursor.decode(cursor) if cursor else Cursor()
        action_obj = Action(name=action)
        ctx = dict(context) if context else {}
        await self._resolve_session(session_id, tenant_id, ctx)

        allow_ids: list[str] = []
        seen: set[str] = set(cur.seen_ids)

        chunk_size = max(limit, 50)

        # 1. Candidate source — preferred when wired (carries richer attrs).
        source_cursor: dict[str, Any] | None = cur.candidate_cursor or None
        source_exhausted = cand_source is None
        while not source_exhausted and len(allow_ids) < limit:
            assert cand_source is not None
            remaining = limit - len(allow_ids)
            fetch_size = max(remaining, 10)
            candidates, next_source_cursor = await cand_source.fetch_candidates(
                resource_type=resource_type,
                tenant_id=tenant_id,
                prefilter=prefilter,
                cursor=source_cursor,
                limit=fetch_size,
            )
            if not candidates and next_source_cursor is None:
                source_exhausted = True
                break
            hit_limit = False
            for resource in candidates:
                if resource.id in seen:
                    continue
                seen.add(resource.id)
                decision = await self.authorize(
                    subject, action_obj, resource, tenant_id, ctx
                )
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(resource.id)
                    if len(allow_ids) >= limit:
                        hit_limit = True
                        break
            if hit_limit:
                break
            if next_source_cursor is None:
                source_exhausted = True
                break
            source_cursor = next_source_cursor

        # 2. ReBAC native enumeration.
        rebac_offset = cur.rebac_offset
        rebac_exhausted = rel_store is None
        while not rebac_exhausted and len(allow_ids) < limit:
            assert rel_store is not None
            batch = await rel_store.find_object_ids_for_subject(
                subject_id=subject.id,
                subject_type=subject.actor_type.value,
                object_type=resource_type,
                tenant_id=tenant_id,
                offset=rebac_offset,
                limit=chunk_size,
            )
            if not batch:
                rebac_exhausted = True
                break
            processed = 0
            hit_limit = False
            for obj_id in batch:
                processed += 1
                if obj_id in seen:
                    continue
                seen.add(obj_id)
                resource = Resource(
                    id=obj_id,
                    resource_type=resource_type,
                    tenant_id=tenant_id,
                    attributes={"type": resource_type},
                )
                decision = await self.authorize(
                    subject, action_obj, resource, tenant_id, ctx
                )
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(obj_id)
                    if len(allow_ids) >= limit:
                        hit_limit = True
                        break
            rebac_offset += processed
            if not hit_limit and len(batch) < chunk_size:
                rebac_exhausted = True

        # 3. Delegation concrete-ID contribution — lit up by FEAT-014
        #    (Task 2). When AsyncDelegationEvaluator is wired, this branch
        #    contributes ids from id:eq / id:in scopes the same way sync
        #    Guard.list_authorized does. Until then, this is a no-op.
        if self._delegation_evaluator is not None and len(allow_ids) < limit:
            delegation_ids = await self._delegation_evaluator.list_contribution(
                subject, tenant_id, resource_type=resource_type
            )
            for obj_id in delegation_ids:
                if obj_id in seen:
                    continue
                seen.add(obj_id)
                resource = Resource(
                    id=obj_id,
                    resource_type=resource_type,
                    tenant_id=tenant_id,
                    attributes={"type": resource_type},
                )
                decision = await self.authorize(
                    subject, action_obj, resource, tenant_id, ctx
                )
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(obj_id)
                    if len(allow_ids) >= limit:
                        break

        has_more = len(allow_ids) >= limit and not (
            rebac_exhausted and source_exhausted
        )
        next_token: str | None = None
        if has_more:
            next_token = Cursor(
                rebac_offset=rebac_offset,
                candidate_cursor=source_cursor or {},
                seen_ids=seen,
            ).encode()
        return ListResult(ids=allow_ids, next_cursor=next_token)

    # ------------------------------------------------------------------
    # Phase 11 (FEAT-015) — approve / reject
    # ------------------------------------------------------------------

    async def approve(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record an approval for a pending request."""
        if self._approval_mgr is None:
            raise ApprovalError(
                "AsyncGuard has no approval_store configured — cannot approve requests"
            )
        return await self._approval_mgr.approve(
            request_id, tenant_id, approver, reason
        )

    async def reject(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record a rejection for a pending request."""
        if self._approval_mgr is None:
            raise ApprovalError(
                "AsyncGuard has no approval_store configured — cannot reject requests"
            )
        return await self._approval_mgr.reject(
            request_id, tenant_id, approver, reason
        )

    # ------------------------------------------------------------------
    # Phase 11 (FEAT-014) — Delegation proxy methods
    # ------------------------------------------------------------------

    def _require_delegation_manager(self) -> Any:
        if self._delegation_manager is None:
            raise RuntimeError(
                "AsyncGuard is not configured with a delegation_store. "
                "Pass delegation_store= to AsyncGuard.__init__ to enable delegation."
            )
        return self._delegation_manager

    async def delegate(self, **kwargs: Any) -> Any:
        """Create or return an existing delegation. Proxies to AsyncDelegationManager."""
        return await self._require_delegation_manager().delegate(**kwargs)

    async def revoke_delegation(
        self, delegation_id: str, *, caller: Subject, tenant_id: str
    ) -> Any:
        """Revoke a delegation and all its descendants."""
        return await self._require_delegation_manager().revoke(
            delegation_id, caller=caller, tenant_id=tenant_id
        )

    async def renew_delegation(
        self,
        delegation_id: str,
        *,
        caller: Subject,
        tenant_id: str,
        now: Any | None = None,
    ) -> Any:
        """Touch the heartbeat timestamp to keep a lease-based delegation alive."""
        return await self._require_delegation_manager().renew(
            delegation_id, caller=caller, tenant_id=tenant_id, now=now
        )

    async def consume_delegation(
        self,
        delegation_id: str,
        tenant_id: str,
        *,
        amount: int = 1,
        cost: Any | None = None,
    ) -> Any:
        """Decrement delegation usage counters."""
        return await self._require_delegation_manager().consume(
            delegation_id, tenant_id, amount=amount, cost=cost
        )

    async def authorize_and_consume(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        amount: int = 1,
        cost: Any | None = None,
    ) -> Decision:
        """Authorize and, if delegation grants access, consume usage counters.

        Policy-based grants and DENIED decisions never touch delegation counters.
        """
        decision = await self.authorize(subject, action, resource, tenant_id, context)
        if decision.status == DecisionStatus.ALLOWED:
            delegation_ids = [
                pid
                for ev in decision.evaluations
                if ev.evaluator == "delegation"
                for pid in ev.matched_policies
            ]
            mgr = self._delegation_manager
            if mgr is not None and delegation_ids:
                for did in delegation_ids:
                    await mgr.consume(did, tenant_id, amount=amount, cost=cost)
        return decision

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _evaluate_with_approval(
        self, request: AuthorizationRequest
    ) -> Decision:
        """Apply policy router; approval gate is layered in Task 3 (FEAT-015)."""
        decision = await self._policy_router.evaluate(request)
        return await self._apply_approval_gate(decision, request)

    async def _apply_approval_gate(
        self, decision: Decision, request: AuthorizationRequest
    ) -> Decision:
        """Intercept ALLOWED decisions from allow policies that require approval.

        Resolution rules mirror sync :meth:`Guard._apply_approval_gate`:
        - The router returns ALLOWED only when at least one allow policy
          matched. If any matched ALLOW policy has ``requires_approval``,
          enter the approval gate.
        - If existing request is APPROVED, allow.
        - REJECTED → deny with reason.
        - PENDING or EXPIRED → return PENDING_APPROVAL.
        - Misconfiguration (policy requires approval but no approval_store)
          → raise ApprovalError.
        """
        if decision.status != DecisionStatus.ALLOWED:
            return decision

        matched_policy = await self._find_requires_approval_policy(decision, request)
        if matched_policy is None:
            return decision

        if self._approval_mgr is None:
            raise ApprovalError(
                "Policy requires_approval is set but AsyncGuard has no "
                "approval_store configured"
            )
        requirement = matched_policy.requires_approval
        assert requirement is not None

        store = self._approval_store
        assert store is not None
        await store.expire_stale(request.tenant_id, self._clock())

        req_hash = ApprovalRequest.make_hash(
            request.tenant_id,
            request.subject.id,
            request.action.name,
            request.resource.id,
            request.resource.resource_type,
        )
        latest = await store.find_latest_by_hash(req_hash, request.tenant_id)

        if latest is None:
            created = await self._approval_mgr.request_or_existing(
                tenant_id=request.tenant_id,
                subject=request.subject,
                action=request.action,
                resource=request.resource,
                requirement=requirement,
            )
            return Decision(
                status=DecisionStatus.PENDING_APPROVAL,
                reason="Awaiting approval",
                evaluations=decision.evaluations,
                approval_request_id=created.id,
            )

        if latest.status == ApprovalStatus.PENDING:
            return Decision(
                status=DecisionStatus.PENDING_APPROVAL,
                reason="Awaiting approval",
                evaluations=decision.evaluations,
                approval_request_id=latest.id,
            )
        if latest.status == ApprovalStatus.APPROVED:
            return decision
        if latest.status == ApprovalStatus.REJECTED:
            reason = "approval rejected"
            if latest.reason:
                reason = f"{reason}: {latest.reason}"
            return Decision(
                status=DecisionStatus.DENIED,
                reason=reason,
                evaluations=decision.evaluations,
            )
        # EXPIRED — open a fresh PENDING for this attempt
        created = await self._approval_mgr.request_or_existing(
            tenant_id=request.tenant_id,
            subject=request.subject,
            action=request.action,
            resource=request.resource,
            requirement=requirement,
        )
        return Decision(
            status=DecisionStatus.PENDING_APPROVAL,
            reason="Awaiting approval (previous request expired)",
            evaluations=decision.evaluations,
            approval_request_id=created.id,
        )

    async def _find_requires_approval_policy(
        self,
        decision: Decision,
        request: AuthorizationRequest,
    ) -> Policy | None:
        """Find a matched ALLOW policy for this request that requires approval."""
        matched_ids = {
            pid
            for ev in decision.evaluations
            if ev.allowed
            for pid in ev.matched_policies
        }
        if not matched_ids:
            return None
        all_policies = await self._policy_store.get_by_tenant(request.tenant_id)
        for p in all_policies:
            if (
                p.id in matched_ids
                and p.effect == PolicyEffect.ALLOW
                and p.requires_approval is not None
            ):
                return p
        return None

    async def _any_matched_policy_non_delegable(
        self, decision: Decision, request: AuthorizationRequest
    ) -> bool:
        matched_ids = {
            pid for ev in decision.evaluations for pid in ev.matched_policies
        }
        if not matched_ids:
            return False
        all_policies = await self._policy_store.get_by_tenant(request.tenant_id)
        return any(
            p.id in matched_ids and getattr(p, "non_delegable", False)
            for p in all_policies
        )

    def _enforce_chain_depth(self, subject: Subject) -> None:
        if subject.chain_depth > self._max_chain_depth:
            raise ChainDepthExceededError(
                f"Subject chain depth {subject.chain_depth} exceeds "
                f"Guard.max_chain_depth {self._max_chain_depth}"
            )

    async def _resolve_session(
        self,
        session_id: str | None,
        tenant_id: str,
        ctx: dict[str, Any],
    ) -> None:
        """Resolve a session and inject it into ``ctx["_session"]``.

        Mutates ``ctx`` in place.  Raises ``SessionNotFoundError`` if
        ``session_id`` is provided but no matching session can be found.
        """
        if session_id is None:
            return
        if self._session_store is None:
            from open_guard.domain.exceptions import SessionNotFoundError

            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        session = await self._session_store.get(session_id, tenant_id)
        if session is None:
            from open_guard.domain.exceptions import SessionNotFoundError

            raise SessionNotFoundError(
                f"Session {session_id!r} not found in tenant {tenant_id!r}"
            )
        # Lazy expiry check
        if (
            session.status == SessionStatus.ACTIVE
            and session.expires_at is not None
            and session.expires_at <= self._clock()
        ):
            session = await self._session_store.update_status(
                session_id, tenant_id, SessionStatus.EXPIRED
            )
        ctx["_session"] = session
