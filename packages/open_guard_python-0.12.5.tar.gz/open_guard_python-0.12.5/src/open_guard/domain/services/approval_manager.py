"""ApprovalManager — lifecycle for async approval requests (Phase 3, FEAT-007)."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime

from open_guard.domain.entities import (
    Action,
    ApprovalDecision,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.ports.approval_store import ApprovalStorePort


class ApprovalManager:
    """Create, resolve, and query ApprovalRequests.

    - Idempotent creation via `request_or_existing()` — same (tenant, subject,
      action, resource) returns the same PENDING request
    - Quorum-aware approval: "any" (first approve wins), "all" (every
      approver), or an integer N
    - Auto-expires stale PENDING requests on read
    - Clock injection for testability

    Args:
        approval_store: Persistence backend.
        clock: Callable returning current UTC datetime. Defaults to
            ``datetime.now(UTC)``.
    """

    def __init__(
        self,
        approval_store: ApprovalStorePort,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._store = approval_store
        self._clock = clock or (lambda: datetime.now(UTC))

    # ------------------------------------------------------------------
    # Creation / lookup
    # ------------------------------------------------------------------

    def request_or_existing(
        self,
        *,
        tenant_id: str,
        subject: Subject,
        action: Action,
        resource: Resource,
        requirement: ApprovalRequirement,
    ) -> ApprovalRequest:
        """Return the PENDING request for this key, creating if absent.

        Auto-expires stale pending requests before lookup so expired ones
        don't shadow a fresh attempt.
        """
        now = self._clock()
        # Expire stale first so they don't block new attempts
        self._store.expire_stale(tenant_id, now)

        req_hash = ApprovalRequest.make_hash(
            tenant_id, subject.id, action.name, resource.id, resource.resource_type
        )
        existing = self._store.find_by_hash(req_hash, tenant_id)
        if existing is not None:
            return existing

        expires_at: datetime | None = None
        if requirement.ttl is not None:
            expires_at = now + requirement.ttl

        request = ApprovalRequest(
            tenant_id=tenant_id,
            request_hash=req_hash,
            subject_id=subject.id,
            action_name=action.name,
            resource_id=resource.id,
            resource_type=resource.resource_type,
            status=ApprovalStatus.PENDING,
            requirement=requirement,
            created_at=now,
            expires_at=expires_at,
        )
        return self._store.create(request)

    def check_status(
        self, request_id: str, tenant_id: str
    ) -> ApprovalRequest:
        """Return the request, auto-expiring it if past TTL."""
        now = self._clock()
        self._store.expire_stale(tenant_id, now)
        req = self._store.get(request_id, tenant_id)
        if req is None:
            raise ApprovalError(
                f"ApprovalRequest {request_id} not found in tenant {tenant_id}"
            )
        return req

    # ------------------------------------------------------------------
    # Resolution: approve / reject
    # ------------------------------------------------------------------

    def approve(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record an approval. Transitions to APPROVED when quorum is met."""
        req = self.check_status(request_id, tenant_id)
        if req.status != ApprovalStatus.PENDING:
            raise ApprovalError(
                f"ApprovalRequest {request_id} is {req.status.value}, not pending"
            )
        if not _approver_allowed(approver, req.requirement):
            raise ApprovalError(
                f"Approver {approver!r} not in allowed approvers for "
                f"request {request_id}"
            )
        if any(d.approver == approver for d in req.approvers_received):
            raise ApprovalError(
                f"Approver {approver!r} already voted on request {request_id}"
            )

        now = self._clock()
        decision = ApprovalDecision(
            approver=approver, decision="approve", reason=reason, at=now
        )
        new_received = [*req.approvers_received, decision]
        approvals = [d for d in new_received if d.decision == "approve"]

        if _quorum_met(approvals, req.requirement):
            updated = req.model_copy(
                update={
                    "status": ApprovalStatus.APPROVED,
                    "approvers_received": new_received,
                    "resolved_at": now,
                    "reason": reason,
                }
            )
        else:
            updated = req.model_copy(
                update={"approvers_received": new_received}
            )
        return self._store.update(updated)

    def reject(
        self,
        request_id: str,
        tenant_id: str,
        approver: str,
        reason: str = "",
    ) -> ApprovalRequest:
        """Record a rejection. Any single rejection finalizes as REJECTED."""
        req = self.check_status(request_id, tenant_id)
        if req.status != ApprovalStatus.PENDING:
            raise ApprovalError(
                f"ApprovalRequest {request_id} is {req.status.value}, not pending"
            )
        if not _approver_allowed(approver, req.requirement):
            raise ApprovalError(
                f"Approver {approver!r} not in allowed approvers for "
                f"request {request_id}"
            )

        now = self._clock()
        decision = ApprovalDecision(
            approver=approver, decision="reject", reason=reason, at=now
        )
        updated = req.model_copy(
            update={
                "status": ApprovalStatus.REJECTED,
                "approvers_received": [*req.approvers_received, decision],
                "resolved_at": now,
                "reason": reason or "rejected",
            }
        )
        return self._store.update(updated)


def _approver_allowed(approver: str, requirement: ApprovalRequirement) -> bool:
    """Whether `approver` matches any entry in the requirement's approver list.

    Phase 3 keeps this simple: exact-string match. Role-prefix ("role:manager")
    semantics are the consumer's responsibility to expand into concrete
    approver ids before calling approve(). Future phases may add structural
    role-matching.
    """
    return approver in requirement.approvers


def _quorum_met(
    approvals: list[ApprovalDecision], requirement: ApprovalRequirement
) -> bool:
    """Whether the quorum condition is satisfied by the given approval list."""
    quorum = requirement.quorum
    if quorum == "any":
        return len(approvals) >= 1
    if quorum == "all":
        # All listed approvers must have approved (at least one vote each)
        approvers_set = {d.approver for d in approvals}
        return approvers_set.issuperset(set(requirement.approvers))
    # Integer N
    return len(approvals) >= int(quorum)
