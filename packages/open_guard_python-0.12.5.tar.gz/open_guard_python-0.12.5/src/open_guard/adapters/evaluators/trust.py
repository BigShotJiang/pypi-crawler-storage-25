"""Trust-gate evaluator — gates authorization on actor trust scores."""

from __future__ import annotations

import time

from open_guard.domain.entities import (
    AuthorizationRequest,
    ConditionResult,
    Evaluation,
    Policy,
    PolicyEffect,
    PolicyMatch,
)
from open_guard.domain.ports.evaluator import EvaluatorPort


class TrustGateEvaluator(EvaluatorPort):
    """Evaluator that gates authorization on actor trust scores.

    Checks subject.attributes["trust_score"] against a policy-defined
    threshold. Chain-aware: can check trust on immediate actor, root
    actor, or all actors in the OBO chain.
    """

    @property
    def evaluator_type(self) -> str:
        return "trust"

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "trust"

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        t0 = time.perf_counter_ns()
        attrs_read = ["trust_score"]

        matched_allow: list[str] = []
        matched_deny: list[str] = []
        best_deny_priority = -1
        best_allow_priority = -1
        details: list[PolicyMatch] = []

        for policy in sorted(policies, key=lambda p: p.priority, reverse=True):
            # Subject match filter
            if not self._subject_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="subject mismatch",
                    )
                )
                continue

            # Action match filter
            if not self._action_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="action mismatch",
                    )
                )
                continue

            # Extract trust conditions
            min_trust_score = policy.conditions.get("min_trust_score")
            if min_trust_score is None:
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="missing min_trust_score in conditions",
                    )
                )
                continue
            min_trust_score = float(min_trust_score)

            trust_scope = policy.conditions.get("trust_scope", "immediate")

            # Resolve trust score(s) based on scope
            trust_ok, condition_result = self._check_trust(
                request, min_trust_score, trust_scope
            )

            details.append(
                PolicyMatch(
                    policy_id=policy.id,
                    effect=policy.effect,
                    matched=True,
                    reason="",
                    matched_conditions=[condition_result],
                )
            )

            if policy.effect == PolicyEffect.DENY:
                if trust_ok:
                    # Trust meets threshold — deny policy's trust gate is satisfied
                    matched_deny.append(policy.id)
                    best_deny_priority = max(best_deny_priority, policy.priority)
            else:
                if trust_ok:
                    matched_allow.append(policy.id)
                    best_allow_priority = max(best_allow_priority, policy.priority)
                else:
                    # Allow policy but trust insufficient — treat as unmatched
                    details[-1] = PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason=self._deny_reason(condition_result),
                        matched_conditions=[condition_result],
                    )

        duration_ms = (time.perf_counter_ns() - t0) / 1_000_000.0

        # Deny with higher or equal priority wins
        if matched_deny and best_deny_priority >= best_allow_priority:
            return Evaluation(
                evaluator="trust",
                allowed=False,
                reason="Deny policy matched",
                matched_policies=matched_deny,
                matched_policies_detail=details,
                duration_ms=duration_ms,
                attributes_read=attrs_read,
            )

        if matched_allow:
            # Build reason from the first allow's condition result
            reason = "Trust score meets threshold"
            for d in details:
                if d.matched and d.effect == PolicyEffect.ALLOW and d.matched_conditions:
                    cr = d.matched_conditions[0]
                    reason = (
                        f"Trust score {cr.actual} meets threshold {cr.expected}"
                    )
                    break
            return Evaluation(
                evaluator="trust",
                allowed=True,
                reason=reason,
                matched_policies=matched_allow,
                matched_policies_detail=details,
                duration_ms=duration_ms,
                attributes_read=attrs_read,
            )

        # No matching policy — figure out best reason
        reason = "No matching trust policy"
        for d in details:
            if not d.matched and d.matched_conditions:
                cr = d.matched_conditions[0]
                reason = self._deny_reason(cr)
                break

        return Evaluation(
            evaluator="trust",
            allowed=False,
            reason=reason,
            matched_policies=[],
            matched_policies_detail=details,
            duration_ms=duration_ms,
            attributes_read=attrs_read,
        )

    def _check_trust(
        self,
        request: AuthorizationRequest,
        min_trust_score: float,
        trust_scope: str,
    ) -> tuple[bool, ConditionResult]:
        """Resolve trust score(s) and compare against threshold.

        Returns (passed, ConditionResult).
        """
        subject = request.subject

        if trust_scope == "root":
            root = subject.root_actor
            score = root.attributes.get("trust_score")
            path = "chain.root.trust_score"
            if score is None:
                return False, ConditionResult(
                    path=path,
                    operator="gte",
                    expected=min_trust_score,
                    actual=None,
                    matched=False,
                )
            score = float(score)
            ok = score >= min_trust_score
            return ok, ConditionResult(
                path=path,
                operator="gte",
                expected=min_trust_score,
                actual=score,
                matched=ok,
            )

        if trust_scope == "all":
            actors = [subject] + list(subject.ancestors())
            path = "chain.all.trust_score"
            # All actors must meet threshold
            min_actual: float | None = None
            for actor in actors:
                score = actor.attributes.get("trust_score")
                if score is None:
                    return False, ConditionResult(
                        path=path,
                        operator="gte",
                        expected=min_trust_score,
                        actual=None,
                        matched=False,
                    )
                score = float(score)
                if min_actual is None or score < min_actual:
                    min_actual = score
            if min_actual is None:  # pragma: no cover — at least one actor exists
                min_actual = 0.0
            ok = min_actual >= min_trust_score
            return ok, ConditionResult(
                path=path,
                operator="gte",
                expected=min_trust_score,
                actual=min_actual,
                matched=ok,
            )

        # Default: "immediate"
        score = subject.attributes.get("trust_score")
        path = "subject.trust_score"
        if score is None:
            return False, ConditionResult(
                path=path,
                operator="gte",
                expected=min_trust_score,
                actual=None,
                matched=False,
            )
        score = float(score)
        ok = score >= min_trust_score
        return ok, ConditionResult(
            path=path,
            operator="gte",
            expected=min_trust_score,
            actual=score,
            matched=ok,
        )

    def _deny_reason(self, cr: ConditionResult) -> str:
        """Build a human-readable deny reason from a ConditionResult."""
        if cr.actual is None:
            return "Missing trust_score attribute"
        return f"Trust score {cr.actual} below threshold {cr.expected}"

    def _action_matches(
        self, request: AuthorizationRequest, policy: Policy
    ) -> bool:
        """Check if the request action matches the policy action."""
        action_match = policy.action_match
        if action_match == "*":
            return True
        if isinstance(action_match, str):
            return request.action.name == action_match
        if isinstance(action_match, list):
            return request.action.name in action_match
        return False

    def _subject_matches(
        self, request: AuthorizationRequest, policy: Policy
    ) -> bool:
        """Check if the subject matches the policy's subject_match filter."""
        if not policy.subject_match:
            return True
        actor_type_filter = policy.subject_match.get("actor_type")
        if actor_type_filter is None:
            return True
        if isinstance(actor_type_filter, str):
            return request.subject.actor_type.value == actor_type_filter
        if isinstance(actor_type_filter, list):
            return request.subject.actor_type.value in actor_type_filter
        return True
