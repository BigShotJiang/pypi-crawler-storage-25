"""ReBAC evaluator — Zanzibar-style relationship-based access control."""

from __future__ import annotations

import time
from typing import Any

from open_guard.domain.entities import (
    AuthorizationRequest,
    Evaluation,
    Policy,
    PolicyEffect,
    PolicyMatch,
    RelationMatch,
    TypeDefinition,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.relationship_store import RelationshipStorePort


class ReBACEvaluator(EvaluatorPort):
    """Relationship-Based Access Control evaluator.

    Evaluates authorization by traversing a graph of relation tuples,
    following the Google Zanzibar model. Supports:
    - Direct relations
    - Wildcards (* = all subjects of a type)
    - Subject sets (indirect membership via group#member)
    - Computed permissions (union, intersection, exclusion, arrow)
    - Max depth limiting for cycle prevention
    - Result memoization within a single check
    """

    def __init__(
        self,
        relationship_store: RelationshipStorePort,
        type_definitions: dict[str, TypeDefinition] | None = None,
        max_depth: int = 25,
    ) -> None:
        self._store = relationship_store
        self._type_defs = type_definitions or {}
        self._max_depth = max_depth

    @property
    def evaluator_type(self) -> str:
        return "rebac"

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "rebac"

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        t0 = time.perf_counter_ns()
        matched_allow: list[str] = []
        matched_deny: list[str] = []
        best_deny_priority = -1
        best_allow_priority = -1
        details: list[PolicyMatch] = []

        for policy in sorted(policies, key=lambda p: p.priority, reverse=True):
            if not self._action_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="action mismatch",
                    )
                )
                continue
            conditions = policy.conditions
            object_type = conditions.get(
                "object_type", request.resource.resource_type
            )
            permission = conditions.get("permission", request.action.name)
            subject_type = conditions.get("subject_type", "user")

            memo: dict[tuple[str, ...], bool] = {}
            has_relation = self._check(
                tenant_id=request.tenant_id,
                object_type=object_type,
                object_id=request.resource.id,
                permission_or_relation=permission,
                subject_type=subject_type,
                subject_id=request.subject.id,
                depth=0,
                memo=memo,
            )

            if has_relation:
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=True,
                        reason=(
                            "deny relationship matched"
                            if policy.effect == PolicyEffect.DENY
                            else "relationship matched"
                        ),
                        matched_relations=[
                            RelationMatch(
                                object_type=object_type,
                                object_id=request.resource.id,
                                relation=permission,
                                subject=f"{subject_type}:{request.subject.id}",
                            )
                        ],
                    )
                )
                if policy.effect == PolicyEffect.DENY:
                    matched_deny.append(policy.id)
                    best_deny_priority = max(best_deny_priority, policy.priority)
                else:
                    matched_allow.append(policy.id)
                    best_allow_priority = max(best_allow_priority, policy.priority)
            else:
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="no relationship path found",
                    )
                )

        duration_ms = (time.perf_counter_ns() - t0) / 1_000_000.0

        if matched_deny and best_deny_priority >= best_allow_priority:
            return Evaluation(
                evaluator="rebac",
                allowed=False,
                reason="Deny relationship matched",
                matched_policies=matched_deny,
                matched_policies_detail=details,
                duration_ms=duration_ms,
            )

        if matched_allow:
            return Evaluation(
                evaluator="rebac",
                allowed=True,
                reason="Relationship matched",
                matched_policies=matched_allow,
                matched_policies_detail=details,
                duration_ms=duration_ms,
            )

        return Evaluation(
            evaluator="rebac",
            allowed=False,
            reason="No matching relationship",
            matched_policies=[],
            matched_policies_detail=details,
            duration_ms=duration_ms,
        )

    def _action_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        action_match = policy.action_match
        if action_match == "*":
            return True
        if isinstance(action_match, str):
            return request.action.name == action_match
        if isinstance(action_match, list):
            return request.action.name in action_match
        return False

    def _check(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        permission_or_relation: str,
        subject_type: str,
        subject_id: str,
        depth: int,
        memo: dict[tuple[str, ...], bool],
    ) -> bool:
        """Recursive Zanzibar Check: does subject have permission on object?"""
        if depth >= self._max_depth:
            return False

        memo_key = (
            object_type, object_id, permission_or_relation,
            subject_type, subject_id,
        )
        if memo_key in memo:
            return memo[memo_key]

        # Prevent infinite recursion by marking as False before recursing
        memo[memo_key] = False

        result = self._check_inner(
            tenant_id, object_type, object_id,
            permission_or_relation, subject_type, subject_id,
            depth, memo,
        )
        memo[memo_key] = result
        return result

    def _check_inner(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        permission_or_relation: str,
        subject_type: str,
        subject_id: str,
        depth: int,
        memo: dict[tuple[str, ...], bool],
    ) -> bool:
        # 1. Check direct tuples (including wildcards)
        if self._store.tuple_exists(
            tenant_id, object_type, object_id,
            permission_or_relation, subject_type, subject_id,
        ):
            return True

        # Check wildcard
        if self._store.tuple_exists(
            tenant_id, object_type, object_id,
            permission_or_relation, subject_type, "*",
        ):
            return True

        # 2. Check subject sets: tuples where subject has a subject_relation
        tuples_with_subject_set = self._store.read_tuples(
            tenant_id,
            object_type=object_type,
            object_id=object_id,
            relation=permission_or_relation,
        )
        for t in tuples_with_subject_set:
            # Check if our subject is a member of the subject set
            if t.subject_relation is not None and self._check(
                tenant_id,
                t.subject_type, t.subject_id,
                t.subject_relation,
                subject_type, subject_id,
                depth + 1, memo,
            ):
                return True

        # 3. Check computed permissions from type definitions
        type_def = self._type_defs.get(object_type)
        if type_def and permission_or_relation in type_def.permissions:
            rule = type_def.permissions[permission_or_relation]
            return self._resolve_permission(
                tenant_id, object_type, object_id,
                rule, subject_type, subject_id,
                depth, memo,
            )

        return False

    def _resolve_permission(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        rule: Any,
        subject_type: str,
        subject_id: str,
        depth: int,
        memo: dict[tuple[str, ...], bool],
    ) -> bool:
        """Resolve a computed permission rule."""
        if rule.kind == "self":
            return False  # Already checked direct in _check_inner

        if rule.kind == "union":
            return any(
                self._check(
                    tenant_id, object_type, object_id,
                    rel, subject_type, subject_id,
                    depth + 1, memo,
                )
                for rel in rule.relations
            )

        if rule.kind == "intersection":
            return all(
                self._check(
                    tenant_id, object_type, object_id,
                    rel, subject_type, subject_id,
                    depth + 1, memo,
                )
                for rel in rule.relations
            )

        if rule.kind == "exclusion":
            base_ok = self._check(
                tenant_id, object_type, object_id,
                rule.base, subject_type, subject_id,
                depth + 1, memo,
            )
            if not base_ok:
                return False
            subtract_ok = self._check(
                tenant_id, object_type, object_id,
                rule.subtract, subject_type, subject_id,
                depth + 1, memo,
            )
            return not subtract_ok

        if rule.kind == "arrow":
            # Walk from_relation to get target objects, then check to_permission
            targets = self._store.read_tuples(
                tenant_id,
                object_type=object_type,
                object_id=object_id,
                relation=rule.from_relation,
            )
            return any(
                self._check(
                    tenant_id,
                    t.subject_type, t.subject_id,
                    rule.to_permission,
                    subject_type, subject_id,
                    depth + 1, memo,
                )
                for t in targets
            )

        return False
