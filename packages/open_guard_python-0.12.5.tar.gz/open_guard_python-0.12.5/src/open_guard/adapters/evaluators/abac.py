"""ABAC evaluator — attribute-based access control with condition operators."""

from __future__ import annotations

import re
import time
from typing import Any

from open_guard.domain.entities import (
    AuthorizationRequest,
    Evaluation,
    Policy,
    PolicyEffect,
    PolicyMatch,
)
from open_guard.domain.ports.evaluator import EvaluatorPort


class ABACEvaluator(EvaluatorPort):
    """Attribute-Based Access Control evaluator.

    Evaluates conditions against subject, resource, action, and context attributes.
    All conditions within a policy must match (AND logic).

    Condition format in policy.conditions:
        {
            "subject.department": {"op": "eq", "value": "engineering"},
            "resource.classification": {"op": "in", "value": ["public", "internal"]},
            "context.hour": {"op": "gte", "value": 9},
        }

    Supported operators: eq, neq, in, not_in, contains, gt, gte, lt, lte, regex, exists
    """

    @property
    def evaluator_type(self) -> str:
        return "abac"

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "abac"

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        t0 = time.perf_counter_ns()
        matched_allow: list[str] = []
        matched_deny: list[str] = []
        best_deny_priority = -1
        best_allow_priority = -1
        details: list[PolicyMatch] = []
        attrs_read: set[str] = set()

        for policy in sorted(policies, key=lambda p: p.priority, reverse=True):
            if not self._action_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="action mismatch",
                    )
                )
                continue
            if not self._resource_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="resource mismatch",
                    )
                )
                continue
            conds_matched = self._conditions_match(request, policy, attrs_read)
            if not conds_matched:
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="condition(s) failed",
                    )
                )
                continue

            details.append(
                PolicyMatch(
                    policy_id=policy.id,
                    effect=policy.effect,
                    matched=True,
                    reason=(
                        "deny condition matched"
                        if policy.effect == PolicyEffect.DENY
                        else "attribute conditions matched"
                    ),
                )
            )

            if policy.effect == PolicyEffect.DENY:
                matched_deny.append(policy.id)
                best_deny_priority = max(best_deny_priority, policy.priority)
            else:
                matched_allow.append(policy.id)
                best_allow_priority = max(best_allow_priority, policy.priority)

        duration_ms = (time.perf_counter_ns() - t0) / 1_000_000.0

        if matched_deny and best_deny_priority >= best_allow_priority:
            return Evaluation(
                evaluator="abac",
                allowed=False,
                reason="Deny condition matched",
                matched_policies=matched_deny,
                matched_policies_detail=details,
                duration_ms=duration_ms,
                attributes_read=sorted(attrs_read),
            )

        if matched_allow:
            return Evaluation(
                evaluator="abac",
                allowed=True,
                reason="Attribute conditions matched",
                matched_policies=matched_allow,
                matched_policies_detail=details,
                duration_ms=duration_ms,
                attributes_read=sorted(attrs_read),
            )

        return Evaluation(
            evaluator="abac",
            allowed=False,
            reason="No matching attribute policy",
            matched_policies=[],
            matched_policies_detail=details,
            duration_ms=duration_ms,
            attributes_read=sorted(attrs_read),
        )

    def _action_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        action_match = policy.action_match
        if action_match == "*":
            return True
        if isinstance(action_match, str):
            return request.action.name == action_match
        if isinstance(action_match, list):
            return request.action.name in action_match
        return False

    def _resource_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        """Check if the request resource matches the policy's resource_match filter.

        If the policy has no resource_match (empty dict), it applies to all
        resources. Otherwise, all key-value pairs in resource_match must be
        present on the resource's attributes (or top-level fields).
        """
        if not policy.resource_match:
            return True
        resource_attrs = {
            "id": request.resource.id,
            "resource_type": request.resource.resource_type,
            **request.resource.attributes,
        }
        for key, expected in policy.resource_match.items():
            if resource_attrs.get(key) != expected:
                return False
        return True

    def _conditions_match(
        self,
        request: AuthorizationRequest,
        policy: Policy,
        attrs_read: set[str] | None = None,
    ) -> bool:
        """Evaluate conditions with OR logic across groups, AND within each group."""
        condition_groups = policy.conditions.get("condition_groups")

        if condition_groups is not None:
            # New OR path: any group match = pass
            if not isinstance(condition_groups, list) or len(condition_groups) == 0:
                return True
            attr_map = self._build_attribute_map(request)
            return any(
                self._group_matches(attr_map, group, attrs_read)
                for group in condition_groups
            )

        # Legacy path: single conditions dict (AND logic, backward-compatible)
        if not policy.conditions:
            return True
        attr_map = self._build_attribute_map(request)
        return self._group_matches(attr_map, policy.conditions, attrs_read)

    def _group_matches(
        self,
        attr_map: dict[str, Any],
        group: dict[str, Any],
        attrs_read: set[str] | None = None,
    ) -> bool:
        """All conditions in a group must match (AND logic)."""
        for path, condition in group.items():
            if path == "condition_groups":
                continue  # skip the meta-key
            if attrs_read is not None:
                attrs_read.add(path)
            if not isinstance(condition, dict):
                actual = self._resolve_path(attr_map, path)
                if actual != condition:
                    return False
                continue
            op = condition.get("op", "eq")
            expected = condition.get("value")
            actual = self._resolve_path(attr_map, path)
            # Phase 6 (FEAT-010): trusted_only taint check
            if condition.get("trusted_only", False) and self._is_untrusted(
                attr_map, path
            ):
                return False
            if not self._evaluate_operator(op, actual, expected):
                return False
        return True

    def _is_untrusted(self, attr_map: dict[str, Any], path: str) -> bool:
        """Check if an attribute is marked untrusted via _trusted metadata.

        Convention: the attribute source (subject, resource, etc.) can carry
        a ``_trusted`` dict mapping attribute names to booleans. If
        ``_trusted[attr_name]`` is False, the attribute is considered
        untrusted (e.g., sourced from LLM output).

        For simple paths like ``resource.classification``:
            attr_map["resource"]["_trusted"]["classification"] == False

        For nested paths like ``chain.root_actor.clearance``:
            Walk down to the nested object that owns the leaf attribute and
            check ``_trusted`` there. E.g. for ``chain.root_actor.clearance``
            check attr_map["chain"]["root_actor"]["_trusted"]["clearance"].
        """
        parts = path.split(".")
        if len(parts) < 2:
            return False
        attr_name = parts[-1]  # leaf attribute name

        # Walk all possible owner-objects along the path (any prefix ending
        # one level before the leaf may carry a ``_trusted`` map).
        # For "resource.classification": owner = attr_map["resource"]
        # For "chain.root_actor.clearance": try attr_map["chain"]["root_actor"]
        #   first (exact parent), then fall back to attr_map["chain"].
        for depth in range(len(parts) - 1, 0, -1):
            node: Any = attr_map
            for key in parts[:depth]:
                if isinstance(node, dict):
                    node = node.get(key)
                else:
                    node = None
                    break
            if isinstance(node, dict):
                trusted_map = node.get("_trusted", {})
                if (
                    isinstance(trusted_map, dict)
                    and trusted_map.get(attr_name) is False
                ):
                    return True
                # Only check the immediate parent (deepest prefix that resolves)
                # — stop after finding first valid dict node.
                break
        return False

    def _build_attribute_map(self, request: AuthorizationRequest) -> dict[str, Any]:
        """Build a flat attribute map from the request for path resolution.

        Phase 3: added a ``chain.*`` namespace that exposes the full
        Subject.on_behalf_of chain:

        - ``chain.depth`` — integer hop count (0 for non-delegated)
        - ``chain.immediate_actor.*`` — alias for the authorizing subject
        - ``chain.root_actor.*`` — the top of the chain
        - ``chain.ancestors`` — list of delegator dicts (excludes immediate);
          combine with the ``any_matches`` operator to express "any ancestor
          satisfies sub-condition" predicates.

        Phase 6 (ENH-001): added a ``session.*`` namespace that exposes the current
        session:

        - ``session.activated_roles`` — list of roles active in this session
        - ``session.status`` — session status (active, suspended, expired)
        - ``session.id`` — session UUID
        - ``session.<metadata_key>`` — any metadata fields (e.g., scope, scope_id)
        """
        subj = request.subject

        # Phase 6 (ENH-001): build session namespace
        session = request.context.get("_session")
        if session is not None and hasattr(session, "activated_roles"):
            session_ns: dict[str, Any] = {
                "activated_roles": session.activated_roles,
                "status": session.status if hasattr(session, "status") else None,
                "id": session.id if hasattr(session, "id") else None,
                **(session.metadata if hasattr(session, "metadata") else {}),
            }
        else:
            session_ns = {}

        return {
            "subject": _subject_dict(subj),
            "resource": {
                "id": request.resource.id,
                "resource_type": request.resource.resource_type,
                **request.resource.attributes,
            },
            "action": {
                "name": request.action.name,
                **request.action.attributes,
            },
            "context": dict(request.context),
            "chain": {
                "depth": subj.chain_depth,
                "immediate_actor": _subject_dict(subj),
                "root_actor": _subject_dict(subj.root_actor),
                "ancestors": [_subject_dict(a) for a in subj.ancestors()],
            },
            "session": session_ns,
        }

    def _resolve_path(self, attr_map: dict[str, Any], path: str) -> Any:
        """Resolve a dotted path like 'subject.department' to a value."""
        parts = path.split(".")
        current: Any = attr_map
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            else:
                return None
        return current

    def _evaluate_operator(self, op: str, actual: Any, expected: Any) -> bool:
        """Evaluate a condition operator."""
        if op == "eq":
            return bool(actual == expected)
        if op == "neq":
            return bool(actual != expected)
        if op == "in":
            if not isinstance(expected, list):
                return False
            return actual in expected
        if op == "not_in":
            if not isinstance(expected, list):
                return True
            return actual not in expected
        if op == "contains":
            if isinstance(actual, (list, str)):
                return expected in actual
            return False
        if op == "gt":
            return _safe_compare(actual, expected, lambda a, b: a > b)
        if op == "gte":
            return _safe_compare(actual, expected, lambda a, b: a >= b)
        if op == "lt":
            return _safe_compare(actual, expected, lambda a, b: a < b)
        if op == "lte":
            return _safe_compare(actual, expected, lambda a, b: a <= b)
        if op == "regex":
            if not isinstance(actual, str) or not isinstance(expected, str):
                return False
            return bool(re.search(expected, actual))
        if op == "exists":
            return (actual is not None) == bool(expected)
        if op == "not_contains":
            if isinstance(actual, (list, str)):
                return expected not in actual
            return True
        if op == "not_regex":
            if not isinstance(actual, str) or not isinstance(expected, str):
                return True
            return not bool(re.search(expected, actual))
        if op == "contains_any":
            if not isinstance(actual, list) or not isinstance(expected, list):
                return False
            return bool(set(actual) & set(expected))
        if op == "contains_all":
            if not isinstance(actual, list) or not isinstance(expected, list):
                return False
            return set(expected).issubset(set(actual))
        if op == "is_subset":
            if not isinstance(actual, list) or not isinstance(expected, list):
                return False
            return set(actual).issubset(set(expected))
        if op == "any_matches":
            # Chain-aware "any of these items satisfies a sub-condition".
            # `actual` must be a list of dicts (e.g. chain.ancestors).
            # `expected` is {"path": "<dotted>", "op": "<op>", "value": <v>}.
            if not isinstance(actual, list) or not isinstance(expected, dict):
                return False
            sub_path = expected.get("path", "")
            sub_op = expected.get("op", "eq")
            sub_value = expected.get("value")
            for item in actual:
                item_map = {"_": item}
                item_val = self._resolve_path(
                    item_map, f"_.{sub_path}" if sub_path else "_"
                )
                if self._evaluate_operator(sub_op, item_val, sub_value):
                    return True
            return False
        return False


def _safe_compare(
    actual: Any,
    expected: Any,
    comparator: Any,
) -> bool:
    """Safely compare two values, returning False if types are incompatible."""
    if actual is None or expected is None:
        return False
    try:
        return bool(comparator(actual, expected))
    except TypeError:
        return False


def _subject_dict(subject: Any) -> dict[str, Any]:
    """Flatten a Subject for attribute-path lookup.

    Produces a dict with id, actor_type (as string), and spreads attributes
    at the top level so `chain.root_actor.trusted` works without a
    "attributes." prefix (consistent with how `subject.department` works).
    """
    return {
        "id": subject.id,
        "actor_type": subject.actor_type.value,
        **subject.attributes,
    }
