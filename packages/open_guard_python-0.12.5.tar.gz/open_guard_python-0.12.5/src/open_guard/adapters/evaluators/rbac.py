"""RBAC evaluator — role-based access control with hierarchy support."""

from __future__ import annotations

import time
from typing import Any

from open_guard.domain.entities import (
    AuthorizationRequest,
    Evaluation,
    Policy,
    PolicyEffect,
    PolicyMatch,
)
from open_guard.domain.ports.evaluator import EvaluatorPort


class RBACEvaluator(EvaluatorPort):
    """Role-Based Access Control evaluator.

    Checks if the subject's roles match policy role requirements.
    Supports role hierarchy (e.g., admin inherits editor, editor inherits viewer).

    Args:
        role_hierarchy: Mapping of role → list of roles it inherits.
            Example: {"admin": ["editor"], "editor": ["viewer"]}
    """

    def __init__(self, role_hierarchy: dict[str, list[str]] | None = None) -> None:
        self._hierarchy = role_hierarchy or {}
        self._resolved_cache: dict[str, set[str]] = {}

    @property
    def evaluator_type(self) -> str:
        return "rbac"

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "rbac"

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        t0 = time.perf_counter_ns()
        subject_roles = self._get_subject_roles(request)
        attrs_read = ["subject.roles"]
        if not subject_roles:
            return Evaluation(
                evaluator="rbac",
                allowed=False,
                reason="Subject has no roles",
                matched_policies=[],
                matched_policies_detail=[
                    PolicyMatch(
                        policy_id=p.id,
                        effect=p.effect,
                        matched=False,
                        reason="subject has no roles",
                    )
                    for p in policies
                ],
                duration_ms=(time.perf_counter_ns() - t0) / 1_000_000.0,
                attributes_read=attrs_read,
            )

        # Resolve inherited roles
        effective_roles = self._resolve_roles(subject_roles)

        matched_allow: list[str] = []
        matched_deny: list[str] = []
        best_deny_priority = -1
        best_allow_priority = -1
        details: list[PolicyMatch] = []

        for policy in sorted(policies, key=lambda p: p.priority, reverse=True):
            if not self._action_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="action mismatch",
                    )
                )
                continue
            if not self._resource_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="resource mismatch",
                    )
                )
                continue
            if not self._role_matches(effective_roles, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="no role overlap",
                    )
                )
                continue

            details.append(
                PolicyMatch(
                    policy_id=policy.id,
                    effect=policy.effect,
                    matched=True,
                    reason=(
                        "deny role matched"
                        if policy.effect == PolicyEffect.DENY
                        else "role matched"
                    ),
                )
            )

            if policy.effect == PolicyEffect.DENY:
                matched_deny.append(policy.id)
                best_deny_priority = max(best_deny_priority, policy.priority)
            else:
                matched_allow.append(policy.id)
                best_allow_priority = max(best_allow_priority, policy.priority)

        duration_ms = (time.perf_counter_ns() - t0) / 1_000_000.0

        # Deny with higher or equal priority wins
        if matched_deny and best_deny_priority >= best_allow_priority:
            return Evaluation(
                evaluator="rbac",
                allowed=False,
                reason="Deny policy matched",
                matched_policies=matched_deny,
                matched_policies_detail=details,
                duration_ms=duration_ms,
                attributes_read=attrs_read,
            )

        if matched_allow:
            return Evaluation(
                evaluator="rbac",
                allowed=True,
                reason="Role matched",
                matched_policies=matched_allow,
                matched_policies_detail=details,
                duration_ms=duration_ms,
                attributes_read=attrs_read,
            )

        return Evaluation(
            evaluator="rbac",
            allowed=False,
            reason="No matching role policy",
            matched_policies=[],
            matched_policies_detail=details,
            duration_ms=duration_ms,
            attributes_read=attrs_read,
        )

    def _get_subject_roles(self, request: AuthorizationRequest) -> list[str]:
        """Extract roles from subject attributes, narrowed by session if present.

        Phase 6 (ENH-001): If an active Session is present in
        ``request.context["_session"]``, only the intersection of the
        subject's assigned roles and the session's activated roles is used.
        Expired or deactivated sessions are ignored (fail-open to full roles).
        """
        roles = request.subject.attributes.get("roles", [])
        if isinstance(roles, str):
            roles = [roles]
        elif isinstance(roles, list):
            roles = [str(r) for r in roles]
        else:
            return []

        # Check for active session in context
        session = request.context.get("_session")
        if session is not None:
            from open_guard.domain.entities import SessionStatus

            if (
                hasattr(session, "status")
                and hasattr(session, "activated_roles")
                and session.status == SessionStatus.ACTIVE
            ):
                activated = set(session.activated_roles)
                roles = [r for r in roles if r in activated]

        return roles

    def _resolve_roles(self, roles: list[str]) -> set[str]:
        """Resolve role hierarchy — expand roles to include inherited ones."""
        effective: set[str] = set()
        for role in roles:
            if role in self._resolved_cache:
                effective.update(self._resolved_cache[role])
            else:
                resolved = self._expand_role(role)
                self._resolved_cache[role] = resolved
                effective.update(resolved)
        return effective

    def _expand_role(self, role: str) -> set[str]:
        """Recursively expand a role to include all inherited roles."""
        result: set[str] = {role}
        parents = self._hierarchy.get(role, [])
        for parent in parents:
            if parent not in result:  # prevent cycles
                result.update(self._expand_role(parent))
        return result

    def _action_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        """Check if the request action matches the policy action."""
        action_match = policy.action_match
        if action_match == "*":
            return True
        if isinstance(action_match, str):
            return request.action.name == action_match
        if isinstance(action_match, list):
            return request.action.name in action_match
        return False

    def _resource_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        """Check if the request resource matches the policy resource conditions."""
        if not policy.resource_match:
            return True
        return self._dict_matches(request.resource.attributes, policy.resource_match)

    def _role_matches(self, effective_roles: set[str], policy: Policy) -> bool:
        """Check if subject's effective roles match policy requirements."""
        required_roles = policy.subject_match.get("roles", [])
        if not required_roles:
            return True
        if isinstance(required_roles, str):
            required_roles = [required_roles]
        return bool(effective_roles.intersection(required_roles))

    def _dict_matches(self, actual: dict[str, Any], expected: dict[str, Any]) -> bool:
        """Check if actual dict contains all key-value pairs from expected."""
        for key, value in expected.items():
            if key not in actual:
                return False
            if actual[key] != value:
                return False
        return True
