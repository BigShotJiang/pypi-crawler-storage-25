"""TBAC evaluator — time-based and task-based access control."""

from __future__ import annotations

import re
import time
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from open_guard.domain.entities import (
    AuthorizationRequest,
    Evaluation,
    Policy,
    PolicyEffect,
    PolicyMatch,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.task_store import TaskStorePort


class TBACEvaluator(EvaluatorPort):
    """Time-Based and Task-Based Access Control evaluator.

    Evaluates time conditions (absolute windows, recurring schedules, TTL)
    and task scoping (task must be active, permissions narrowed).

    Time conditions in policy.conditions:
        {
            "time_window": {"not_before": "ISO8601", "not_after": "ISO8601"},
            "schedule": {
                "days": [1-7], "time_range": ["HH:MM", "HH:MM"],
                "timezone": "IANA",
            },
            "ttl": {"duration": "ISO8601_DURATION", "reference": "ISO8601"},
            "task_id": "task-123",
        }

    Args:
        task_store: Optional task store for task-scoped policy evaluation.
        clock: Optional callable returning current UTC datetime (for testing).
    """

    def __init__(
        self,
        task_store: TaskStorePort | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._task_store = task_store
        self._clock = clock or (lambda: datetime.now(UTC))

    @property
    def evaluator_type(self) -> str:
        return "tbac"

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "tbac"

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        t0 = time.perf_counter_ns()
        now = self._clock()

        matched_allow: list[str] = []
        matched_deny: list[str] = []
        best_deny_priority = -1
        best_allow_priority = -1
        details: list[PolicyMatch] = []

        for policy in sorted(policies, key=lambda p: p.priority, reverse=True):
            if not self._action_matches(request, policy):
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="action mismatch",
                    )
                )
                continue
            time_ok = self._time_conditions_met(policy.conditions, now)
            if not time_ok:
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="time window/schedule/ttl failed",
                    )
                )
                continue
            task_ok = self._task_conditions_met(policy.conditions, request)
            if not task_ok:
                details.append(
                    PolicyMatch(
                        policy_id=policy.id,
                        effect=policy.effect,
                        matched=False,
                        reason="task scope failed",
                        task_scope_ok=False,
                    )
                )
                continue

            details.append(
                PolicyMatch(
                    policy_id=policy.id,
                    effect=policy.effect,
                    matched=True,
                    reason="time/task conditions met",
                    task_scope_ok=True if policy.conditions.get("task_id") else None,
                )
            )

            if policy.effect == PolicyEffect.DENY:
                matched_deny.append(policy.id)
                best_deny_priority = max(best_deny_priority, policy.priority)
            else:
                matched_allow.append(policy.id)
                best_allow_priority = max(best_allow_priority, policy.priority)

        duration_ms = (time.perf_counter_ns() - t0) / 1_000_000.0

        if matched_deny and best_deny_priority >= best_allow_priority:
            return Evaluation(
                evaluator="tbac",
                allowed=False,
                reason="Deny policy matched",
                matched_policies=matched_deny,
                matched_policies_detail=details,
                duration_ms=duration_ms,
            )

        if matched_allow:
            return Evaluation(
                evaluator="tbac",
                allowed=True,
                reason="Time/task conditions met",
                matched_policies=matched_allow,
                matched_policies_detail=details,
                duration_ms=duration_ms,
            )

        return Evaluation(
            evaluator="tbac",
            allowed=False,
            reason="No matching TBAC policy",
            matched_policies=[],
            matched_policies_detail=details,
            duration_ms=duration_ms,
        )

    def _action_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        action_match = policy.action_match
        if action_match == "*":
            return True
        if isinstance(action_match, str):
            return request.action.name == action_match
        if isinstance(action_match, list):
            return request.action.name in action_match
        return False  # pragma: no cover

    # --- Time condition evaluation ---

    def _time_conditions_met(
        self, conditions: dict[str, Any], now: datetime
    ) -> bool:
        """Evaluate all time conditions (AND logic). Returns True if all pass."""
        if "time_window" in conditions and not self._check_time_window(
            conditions["time_window"], now
        ):
            return False

        if "schedule" in conditions and not self._check_schedule(
            conditions["schedule"], now
        ):
            return False

        return not (
            "ttl" in conditions
            and not self._check_ttl(conditions["ttl"], now)
        )

    def _check_time_window(
        self, window: dict[str, str], now: datetime
    ) -> bool:
        """Check absolute time window (not_before / not_after)."""
        if "not_before" in window:
            not_before = datetime.fromisoformat(window["not_before"])
            if now < not_before:
                return False
        if "not_after" in window:
            not_after = datetime.fromisoformat(window["not_after"])
            if now > not_after:
                return False
        return True

    def _check_schedule(
        self, schedule: dict[str, Any], now: datetime
    ) -> bool:
        """Check recurring schedule (days + time range + timezone)."""
        tz_name = schedule.get("timezone", "UTC")
        local_now = now.astimezone(ZoneInfo(tz_name))

        # Check day of week (ISO: Monday=1, Sunday=7)
        if "days" in schedule and local_now.isoweekday() not in schedule["days"]:
            return False

        # Check time range
        if "time_range" in schedule:
            time_range = schedule["time_range"]
            start_parts = time_range[0].split(":")
            end_parts = time_range[1].split(":")
            start_minutes = int(start_parts[0]) * 60 + int(start_parts[1])
            end_minutes = int(end_parts[0]) * 60 + int(end_parts[1])
            current_minutes = local_now.hour * 60 + local_now.minute

            if not (start_minutes <= current_minutes < end_minutes):
                return False

        return True

    def _check_ttl(self, ttl: dict[str, str], now: datetime) -> bool:
        """Check TTL / duration relative to a reference time."""
        reference = datetime.fromisoformat(ttl["reference"])
        duration = _parse_iso8601_duration(ttl["duration"])
        expiry = reference + duration
        return now <= expiry

    # --- Task condition evaluation ---

    def _task_conditions_met(
        self, conditions: dict[str, Any], request: AuthorizationRequest
    ) -> bool:
        """Check task-related conditions. Returns True if no task conditions."""
        task_id = conditions.get("task_id")
        if task_id is None:
            return True

        if self._task_store is None:
            return False  # task_id referenced but no store configured

        from open_guard.domain.entities import TaskStatus

        task = self._task_store.get(task_id, request.tenant_id)
        if task is None:
            return False

        # Auto-expire if past TTL
        if task.status == TaskStatus.ACTIVE and task.expires_at is not None:
            now = self._clock()
            if now > task.expires_at:
                expired_task = task.model_copy(update={"status": TaskStatus.EXPIRED})
                self._task_store.update(expired_task)
                return False

        if task.status != TaskStatus.ACTIVE:
            return False

        # Check task scope — does the task allow this action + resource type?
        if (
            "*" not in task.allowed_actions
            and request.action.name not in task.allowed_actions
        ):
            return False

        return not (
            "*" not in task.allowed_resource_types
            and request.resource.resource_type
            not in task.allowed_resource_types
        )


def _parse_iso8601_duration(duration_str: str) -> timedelta:
    """Parse a subset of ISO 8601 durations: P[n]D, PT[n]H[n]M[n]S, P[n]DT[n]H[n]M[n]S.

    Examples: PT2H, PT30M, P7D, P1DT12H, PT1H30M
    """
    pattern = r"^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$"
    match = re.match(pattern, duration_str)
    if not match:
        msg = f"Invalid ISO 8601 duration: {duration_str}"
        raise ValueError(msg)

    days = int(match.group(1) or 0)
    hours = int(match.group(2) or 0)
    minutes = int(match.group(3) or 0)
    seconds = int(match.group(4) or 0)

    return timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)
