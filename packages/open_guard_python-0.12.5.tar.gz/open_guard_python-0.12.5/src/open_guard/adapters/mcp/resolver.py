"""MCPSessionResolver — consumer-provided claims-to-Subject mapping."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from open_guard.domain.entities import Subject


@runtime_checkable
class MCPSessionResolver(Protocol):
    """Map an MCP session's claims to an open-guard :class:`Subject`.

    Open-guard does not know how consumers mint or verify session claims
    (OAuth, open-shield-python, custom JWT issuers, etc.). Consumers
    implement this protocol so the adapter can build the Subject that
    :meth:`Guard.authorize` accepts.

    Implementations may return a Subject with ``on_behalf_of=...`` set
    to represent agent-to-user delegation chains — the Phase 3 chain
    machinery then flows through every authorization decision naturally.
    """

    def resolve(
        self, session_id: str, claims: dict[str, Any]
    ) -> Subject: ...
