"""MCP (Model Context Protocol) authorization adapter — Phase 4 (FEAT-009).

Provides :class:`MCPGuard`, an SDK-agnostic adapter that maps MCP
tool-call invocations onto :meth:`Guard.authorize` with parameter-level
ABAC, session-to-Subject resolution (chain-aware), and Phase 3 pending
approval flow for dangerous tools.

For consumers of the official Python MCP SDK, an optional ``[mcp]`` extra
ships a thin binding in :mod:`open_guard.adapters.mcp.sdk`.
"""

from open_guard.adapters.mcp.entities import (
    MCPAuthorizationPending,
    MCPAuthorizationResult,
    MCPToolRequest,
    MCPToolResponse,
)
from open_guard.adapters.mcp.guard import MCPGuard
from open_guard.adapters.mcp.resolver import MCPSessionResolver

__all__ = [
    "MCPAuthorizationPending",
    "MCPAuthorizationResult",
    "MCPGuard",
    "MCPSessionResolver",
    "MCPToolRequest",
    "MCPToolResponse",
]
