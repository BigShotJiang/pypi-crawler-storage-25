"""MCP adapter entities — SDK-agnostic dict/protocol shapes."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

from open_guard.domain.entities import Entity


class MCPToolRequest(Entity):
    """A tool invocation passed to :meth:`MCPGuard.check_tool_call`.

    SDK-agnostic — consumers construct this from their MCP server's
    middleware layer (or via the optional ``[mcp]`` extra binding).
    """

    session_id: str = Field(..., description="MCP session identifier")
    server_id: str = Field(
        ..., description="MCP server identifier (for multi-server namespace)"
    )
    tool_name: str = Field(..., description="Name of the tool being invoked")
    params: dict[str, Any] = Field(
        default_factory=dict, description="Tool arguments"
    )
    claims: dict[str, Any] = Field(
        default_factory=dict,
        description="Session claims (tenant_id, sub, etc.) for the resolver",
    )


class MCPToolResponse(Entity):
    """A tool invocation's result (passed back to the MCP client)."""

    content: Any = Field(..., description="Tool result content")
    is_error: bool = Field(
        default=False, description="Whether the tool returned an error"
    )


class MCPAuthorizationPending(Entity):
    """Metadata attached when a tool call needs human approval.

    Mirrors :class:`ApprovalRequirement` fields that are useful for a
    consumer-side dispatcher (Slack, email, webhook, etc.).
    """

    approval_request_id: str = Field(..., description="Approval request id")
    approvers: list[str] = Field(
        default_factory=list, description="Allowed approver identifiers"
    )
    quorum: str | int = Field(
        default="any", description="'any' | 'all' | integer N"
    )
    channel: str | None = Field(
        default=None, description="Advisory dispatch channel hint"
    )
    ttl_seconds: int | None = Field(
        default=None, description="TTL in seconds (None = no TTL)"
    )


class MCPAuthorizationResult(Entity):
    """Outcome of :meth:`MCPGuard.check_tool_call`."""

    status: Literal["allow", "deny", "pending"] = Field(
        ..., description="Terminal outcome of the check"
    )
    reason: str | None = Field(
        default=None, description="Human-readable reason"
    )
    pending: MCPAuthorizationPending | None = Field(
        default=None,
        description="Approval metadata when status == 'pending'",
    )
    attributed_delegation_ids: list[str] = Field(
        default_factory=list,
        description=(
            "Delegation IDs that granted this allow (empty when policy or deny)"
        ),
    )

    def is_allowed(self) -> bool:
        return self.status == "allow"

    def is_denied(self) -> bool:
        return self.status == "deny"

    def is_pending(self) -> bool:
        return self.status == "pending"
