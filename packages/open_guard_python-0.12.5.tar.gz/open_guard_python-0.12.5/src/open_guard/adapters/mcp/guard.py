"""MCPGuard — the MCP-facing adapter around a core :class:`Guard`."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from open_guard.adapters.mcp.entities import (
    MCPAuthorizationPending,
    MCPAuthorizationResult,
)
from open_guard.adapters.mcp.resolver import MCPSessionResolver
from open_guard.domain.entities import (
    Action,
    Decision,
    DecisionStatus,
    DecisionTrace,
    ListResult,
    Resource,
)
from open_guard.domain.services.guard import Guard

DEFAULT_RESOURCE_NAMESPACE = "tool:{server_id}:{tool_name}"


class MCPGuard:
    """MCP tool-call authorization adapter.

    Composes a core :class:`Guard` with a consumer-provided
    :class:`MCPSessionResolver` to authorize MCP ``call_tool`` invocations.
    Tool calls are modeled as resources of type ``"tool"`` whose
    ``id`` is built from ``resource_namespace`` (default
    ``"tool:{server_id}:{tool_name}"``) and whose ``attributes["params"]``
    carries the tool arguments — so existing ABAC dot-path conditions
    (``"params.query"``, ``"params.options.safe"``) apply naturally.

    Flow of :meth:`check_tool_call`:

    1. Optional structural schema hygiene against ``tool_schema`` — malformed
       calls fail fast before policy evaluation.
    2. Resolve the MCP session claims to a :class:`Subject` (including any
       ``on_behalf_of`` chain).
    3. Build a :class:`Resource` and call :meth:`Guard.authorize` with
       action ``"invoke"``.
    4. Map the :class:`Decision` to an :class:`MCPAuthorizationResult`,
       carrying pending-approval metadata when the decision is PENDING.

    Args:
        guard: The core Guard.
        resolver: Claims-to-Subject resolver (protocol).
        default_tenant_id: Tenant used when the resolver doesn't populate
            ``claims['tenant_id']``.
        resource_namespace: Python format string for the tool resource id,
            fields: ``server_id`` and ``tool_name``. Defaults to
            ``"tool:{server_id}:{tool_name}"``.
    """

    def __init__(
        self,
        guard: Guard,
        resolver: MCPSessionResolver,
        default_tenant_id: str,
        resource_namespace: str = DEFAULT_RESOURCE_NAMESPACE,
    ) -> None:
        self._guard = guard
        self._resolver = resolver
        self._default_tenant_id = default_tenant_id
        self.resource_namespace = resource_namespace

    # --- Public API ----------------------------------------------------

    def check_tool_call(
        self,
        session_id: str,
        tool_name: str,
        params: dict[str, Any],
        server_id: str,
        tool_schema: dict[str, Any] | None = None,
        claims: dict[str, Any] | None = None,
    ) -> MCPAuthorizationResult:
        """Authorize an MCP tool invocation."""
        hygiene_err = (
            self._validate_schema(params, tool_schema)
            if tool_schema is not None
            else None
        )
        if hygiene_err:
            return MCPAuthorizationResult(
                status="deny", reason=f"schema_violation:{hygiene_err}"
            )

        subject = self._resolver.resolve(session_id, claims or {})
        tenant_id = self._infer_tenant(claims)
        resource = self._build_resource(
            server_id=server_id, tool_name=tool_name,
            params=params, tenant_id=tenant_id,
        )
        decision = self._guard.authorize(
            subject, Action(name="invoke"), resource, tenant_id
        )
        return self._map_decision(decision, tenant_id)

    def check_tool_call_traced(
        self,
        session_id: str,
        tool_name: str,
        params: dict[str, Any],
        server_id: str,
        tool_schema: dict[str, Any] | None = None,
        claims: dict[str, Any] | None = None,
    ) -> tuple[MCPAuthorizationResult, DecisionTrace | None]:
        """Like :meth:`check_tool_call` but also returns a :class:`DecisionTrace`.

        Returns ``(result, None)`` when the call fails pre-authorization
        schema hygiene (no policy evaluation occurred, so no trace exists).
        """
        hygiene_err = (
            self._validate_schema(params, tool_schema)
            if tool_schema is not None
            else None
        )
        if hygiene_err:
            return (
                MCPAuthorizationResult(
                    status="deny", reason=f"schema_violation:{hygiene_err}"
                ),
                None,
            )

        subject = self._resolver.resolve(session_id, claims or {})
        tenant_id = self._infer_tenant(claims)
        resource = self._build_resource(
            server_id=server_id, tool_name=tool_name,
            params=params, tenant_id=tenant_id,
        )
        decision, trace = self._guard.authorize_traced(
            subject, Action(name="invoke"), resource, tenant_id
        )
        return self._map_decision(decision, tenant_id), trace

    def list_authorized_tools(
        self,
        session_id: str,
        server_id: str | None = None,
        limit: int = 100,
        cursor: str | None = None,
        claims: dict[str, Any] | None = None,
    ) -> ListResult:
        """Return tool resource IDs the resolved subject may invoke.

        Wraps :meth:`Guard.list_authorized(action="invoke", resource_type="tool")`.
        A ``CandidateResourcePort`` scoped to ``resource_type == "tool"`` must
        be wired on the underlying Guard (or there must be ReBAC tuples for
        the subject) — see the integration guide for patterns.
        """
        subject = self._resolver.resolve(session_id, claims or {})
        tenant_id = self._infer_tenant(claims)
        prefilter: dict[str, Any] | None = (
            {"server_id": server_id} if server_id else None
        )
        return self._guard.list_authorized(
            subject=subject,
            action="invoke",
            resource_type="tool",
            tenant_id=tenant_id,
            prefilter=prefilter,
            limit=limit,
            cursor=cursor,
        )

    # --- Helpers -------------------------------------------------------

    def _make_resource_id(self, server_id: str, tool_name: str) -> str:
        return self.resource_namespace.format(
            server_id=server_id, tool_name=tool_name
        )

    def _infer_tenant(self, claims: dict[str, Any] | None) -> str:
        if claims and "tenant_id" in claims and claims["tenant_id"]:
            return str(claims["tenant_id"])
        return self._default_tenant_id

    def _build_resource(
        self,
        server_id: str,
        tool_name: str,
        params: dict[str, Any],
        tenant_id: str,
    ) -> Resource:
        return Resource(
            id=self._make_resource_id(server_id, tool_name),
            resource_type="tool",
            tenant_id=tenant_id,
            attributes={
                "type": "tool",
                "params": params,
                "server_id": server_id,
                "tool_name": tool_name,
            },
        )

    @staticmethod
    def _validate_schema(
        params: dict[str, Any], schema: dict[str, Any]
    ) -> str | None:
        """Minimal structural hygiene: required fields + basic type match."""
        required = schema.get("required", [])
        if not isinstance(required, list):
            required = []
        for field in required:
            if field not in params:
                return f"missing required field '{field}'"
        properties = schema.get("properties", {})
        if not isinstance(properties, dict):
            return None
        for field, spec in properties.items():
            if field not in params:
                continue
            if not isinstance(spec, dict):
                continue
            expected = spec.get("type")
            if expected and not _type_matches(params[field], expected):
                return f"field '{field}' expected {expected}"
        return None

    def consume_tool_call_budget(
        self,
        result: MCPAuthorizationResult,
        tenant_id: str,
        *,
        amount: int = 1,
        cost: Decimal | None = None,
    ) -> None:
        """Decrement budget on delegations that granted an allow result."""
        if result.status != "allow":
            return
        for did in result.attributed_delegation_ids:
            self._guard.consume_delegation(did, tenant_id, amount=amount, cost=cost)

    def _map_decision(
        self, decision: Decision, tenant_id: str
    ) -> MCPAuthorizationResult:
        if decision.status == DecisionStatus.ALLOWED:
            delegation_ids = [
                pid
                for ev in decision.evaluations
                if ev.evaluator == "delegation"
                for pid in ev.matched_policies
            ]
            return MCPAuthorizationResult(
                status="allow",
                reason=decision.reason or None,
                attributed_delegation_ids=delegation_ids,
            )
        if decision.status == DecisionStatus.DENIED:
            return MCPAuthorizationResult(
                status="deny", reason=decision.reason or None
            )
        # PENDING_APPROVAL — hydrate requirement from the approval store
        pending = MCPAuthorizationPending(
            approval_request_id=decision.approval_request_id or "",
        )
        store = self._guard.approval_store
        if store is not None and decision.approval_request_id:
            req = store.get(decision.approval_request_id, tenant_id)
            if req is not None:
                ttl_seconds: int | None = (
                    int(req.requirement.ttl.total_seconds())
                    if req.requirement.ttl
                    else None
                )
                pending = MCPAuthorizationPending(
                    approval_request_id=req.id,
                    approvers=list(req.requirement.approvers),
                    quorum=req.requirement.quorum,
                    channel=req.requirement.channel,
                    ttl_seconds=ttl_seconds,
                )
        return MCPAuthorizationResult(
            status="pending",
            reason=decision.reason or None,
            pending=pending,
        )


def _type_matches(value: Any, expected: str) -> bool:
    """Map JSON-schema-style type names to isinstance checks."""
    mapping: dict[str, type | tuple[type, ...]] = {
        "string": str,
        "integer": int,
        "number": (int, float),
        "boolean": bool,
        "array": list,
        "object": dict,
        "null": type(None),
    }
    py_type = mapping.get(expected)
    if py_type is None:
        return True  # unknown type → don't block
    # bool is a subclass of int; narrow when expected is number/integer
    if expected in {"integer", "number"} and isinstance(value, bool):
        return False
    return isinstance(value, py_type)
