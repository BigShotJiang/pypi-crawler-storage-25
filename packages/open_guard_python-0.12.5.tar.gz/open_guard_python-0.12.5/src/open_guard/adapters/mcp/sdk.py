"""Thin binding from the ``mcp`` SDK to open-guard's adapter shapes.

Optional — requires the ``[mcp]`` extra for the SDK itself::

    pip install 'open-guard[mcp]'

The helpers here are intentionally duck-typed over the SDK's types
(``.name`` / ``.arguments``, with ``.tool_name`` / ``.params`` as
fallbacks) so that Python MCP SDK version drift in 2026+ doesn't
break consumers. They work with any object that exposes those
attributes — including plain dicts wrapped via ``types.SimpleNamespace``.

For consumers who want to fail fast when the SDK isn't installed, check
:data:`HAS_SDK` before calling.
"""

from __future__ import annotations

from typing import Any

from open_guard.adapters.mcp.entities import MCPToolRequest

try:
    import mcp  # noqa: F401

    HAS_SDK: bool = True
except ImportError:  # pragma: no cover
    HAS_SDK = False


def from_sdk_call_request(
    sdk_request: Any,
    *,
    session_id: str,
    server_id: str,
    claims: dict[str, Any] | None = None,
) -> MCPToolRequest:
    """Convert an SDK ``CallToolRequest`` (or similar) to :class:`MCPToolRequest`.

    Accepts anything with ``.name``/``.tool_name`` and ``.arguments``/
    ``.params`` attributes so that future MCP SDK evolutions that rename
    fields don't break existing consumers.
    """
    name = getattr(sdk_request, "name", None) or getattr(
        sdk_request, "tool_name", None
    )
    if name is None:
        raise ValueError(
            "SDK request object has no .name or .tool_name attribute"
        )
    arguments = (
        getattr(sdk_request, "arguments", None)
        or getattr(sdk_request, "params", None)
        or {}
    )
    return MCPToolRequest(
        session_id=session_id,
        server_id=server_id,
        tool_name=str(name),
        params=dict(arguments),
        claims=claims or {},
    )
