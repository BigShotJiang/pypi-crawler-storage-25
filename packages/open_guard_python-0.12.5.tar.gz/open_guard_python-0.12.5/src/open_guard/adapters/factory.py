"""Factory wiring for Guard and AsyncGuard (Phase 7)."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from open_guard.domain.services.guard import Guard


def _resolve_backend(dsn: str | None, backend: str | None) -> str:
    """Determine backend from DSN scheme or explicit name."""
    if backend:
        return backend
    if dsn is None:
        return "memory"
    if dsn.startswith("sqlite"):
        return "sqlite"
    if dsn.startswith("postgresql") or dsn.startswith("postgres"):
        return "postgresql"
    raise ValueError(
        f"Cannot auto-detect backend from DSN: {dsn!r}. Use backend= explicitly."
    )


def _build_memory_guard(**kwargs: Any) -> Guard:
    """Wire Guard with all in-memory stores and all 5 evaluators."""
    from open_guard.adapters.evaluators.abac import ABACEvaluator
    from open_guard.adapters.evaluators.rbac import RBACEvaluator
    from open_guard.adapters.evaluators.rebac import ReBACEvaluator
    from open_guard.adapters.evaluators.tbac import TBACEvaluator
    from open_guard.adapters.evaluators.trust import TrustGateEvaluator
    from open_guard.adapters.stores.memory import InMemoryPolicyStore
    from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
    from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
    from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
    from open_guard.adapters.stores.memory_session import InMemorySessionStore
    from open_guard.adapters.stores.memory_task import InMemoryTaskStore
    from open_guard.domain.services.guard import Guard

    policy_store = InMemoryPolicyStore()
    relationship_store = InMemoryRelationshipStore()
    task_store = InMemoryTaskStore()

    evaluators = [
        RBACEvaluator(),
        ABACEvaluator(),
        TBACEvaluator(task_store=task_store),
        ReBACEvaluator(relationship_store=relationship_store),
        TrustGateEvaluator(),
    ]

    return Guard(
        policy_store=policy_store,
        evaluators=evaluators,
        approval_store=InMemoryApprovalStore(),
        relationship_store=relationship_store,
        delegation_store=InMemoryDelegationStore(),
        session_store=InMemorySessionStore(),
        **kwargs,
    )


def _build_sql_guard(dsn: str, **kwargs: Any) -> Guard:
    """Wire Guard with SQLAlchemy stores and all 5 evaluators."""
    from sqlalchemy import create_engine

    from open_guard.adapters.evaluators.abac import ABACEvaluator
    from open_guard.adapters.evaluators.rbac import RBACEvaluator
    from open_guard.adapters.evaluators.rebac import ReBACEvaluator
    from open_guard.adapters.evaluators.tbac import TBACEvaluator
    from open_guard.adapters.evaluators.trust import TrustGateEvaluator
    from open_guard.adapters.stores.sql import (
        SQLAlchemyPolicyStore,
        SQLAlchemyTaskStore,
    )
    from open_guard.adapters.stores.sql_approval import SQLAlchemyApprovalStore
    from open_guard.adapters.stores.sql_delegation import SQLAlchemyDelegationStore
    from open_guard.adapters.stores.sql_models import metadata
    from open_guard.adapters.stores.sql_relationship import SQLAlchemyRelationshipStore
    from open_guard.adapters.stores.sql_session import SQLAlchemySessionStore
    from open_guard.domain.services.guard import Guard

    engine = create_engine(dsn)
    metadata.create_all(engine)

    policy_store = SQLAlchemyPolicyStore(engine)
    task_store = SQLAlchemyTaskStore(engine)
    relationship_store = SQLAlchemyRelationshipStore(engine)

    evaluators = [
        RBACEvaluator(),
        ABACEvaluator(),
        TBACEvaluator(task_store=task_store),
        ReBACEvaluator(relationship_store=relationship_store),
        TrustGateEvaluator(),
    ]

    return Guard(
        policy_store=policy_store,
        evaluators=evaluators,
        approval_store=SQLAlchemyApprovalStore(engine),
        relationship_store=relationship_store,
        delegation_store=SQLAlchemyDelegationStore(engine),
        session_store=SQLAlchemySessionStore(engine),
        **kwargs,
    )


def build_guard(
    dsn: str | None = None, *, backend: str | None = None, **kwargs: Any
) -> Guard:
    """Wire all stores + evaluators from a DSN or backend name.

    Backend auto-detection:
      - "memory" or no dsn -> in-memory stores
      - "sqlite://..." -> SQLAlchemy + SQLite
      - "postgresql://..." -> SQLAlchemy + PostgreSQL

    Extra kwargs forwarded to Guard.__init__ (max_chain_depth, etc.).
    """
    resolved = _resolve_backend(dsn, backend)

    if resolved == "memory":
        return _build_memory_guard(**kwargs)
    if resolved in ("sqlite", "postgresql"):
        return _build_sql_guard(dsn, **kwargs)  # type: ignore[arg-type]
    raise ValueError(f"Unsupported backend: {resolved!r}")


# ---------------------------------------------------------------------------
# Async factory (Phase 7)
# ---------------------------------------------------------------------------


async def build_async_guard(
    dsn: str | None = None, *, backend: str | None = None, **kwargs: Any
) -> Any:
    """Wire AsyncGuard with async stores + evaluators.

    Backend auto-detection mirrors :func:`build_guard`:
      - "memory" or no dsn -> async in-memory stores
      - "sqlite+aiosqlite://..." -> AsyncSQLAlchemy + aiosqlite
      - "postgresql+asyncpg://..." -> AsyncSQLAlchemy + asyncpg

    Extra kwargs forwarded to AsyncGuard.__init__.
    """
    resolved = _resolve_backend(dsn, backend)

    if resolved == "memory":
        return _build_async_memory_guard(**kwargs)
    if resolved in ("sqlite", "postgresql"):
        return await _build_async_sql_guard(dsn, **kwargs)  # type: ignore[arg-type]
    raise ValueError(f"Unsupported async backend: {resolved!r}")


async def _build_async_sql_guard(dsn: str, **kwargs: Any) -> Any:
    """Wire AsyncGuard with async SQLAlchemy stores and all 5 evaluators."""
    from sqlalchemy import create_engine
    from sqlalchemy.ext.asyncio import create_async_engine

    from open_guard.adapters.evaluators.abac import ABACEvaluator
    from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
    from open_guard.adapters.evaluators.rbac import RBACEvaluator
    from open_guard.adapters.evaluators.tbac import TBACEvaluator
    from open_guard.adapters.evaluators.trust import TrustGateEvaluator
    from open_guard.adapters.stores.async_sql import (
        AsyncSQLAlchemyPolicyStore,
        AsyncSQLAlchemyTaskStore,
    )
    from open_guard.adapters.stores.async_sql_approval import AsyncSQLAlchemyApprovalStore
    from open_guard.adapters.stores.async_sql_delegation import AsyncSQLAlchemyDelegationStore
    from open_guard.adapters.stores.async_sql_relationship import (
        AsyncSQLAlchemyRelationshipStore,
    )
    from open_guard.adapters.stores.async_sql_session import AsyncSQLAlchemySessionStore
    from open_guard.adapters.stores.sql import SQLAlchemyTaskStore
    from open_guard.adapters.stores.sql_models import metadata
    from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
    from open_guard.domain.ports.evaluator import EvaluatorPort
    from open_guard.domain.services.async_guard import AsyncGuard

    engine = create_async_engine(dsn)

    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    policy_store = AsyncSQLAlchemyPolicyStore(engine)
    task_store = AsyncSQLAlchemyTaskStore(engine)
    relationship_store = AsyncSQLAlchemyRelationshipStore(engine)

    # TBACEvaluator is synchronous — needs a sync task store.
    # Strip the async driver suffix to get a sync-compatible DSN.
    sync_dsn = dsn.replace("+asyncpg", "").replace("+aiosqlite", "")
    sync_engine = create_engine(sync_dsn)
    sync_task_store = SQLAlchemyTaskStore(sync_engine)

    evaluators: list[EvaluatorPort | AsyncEvaluatorPort] = [
        RBACEvaluator(),
        ABACEvaluator(),
        TBACEvaluator(task_store=sync_task_store),
        AsyncReBACEvaluator(relationship_store=relationship_store),
        TrustGateEvaluator(),
    ]

    return AsyncGuard(
        policy_store=policy_store,
        evaluators=evaluators,
        approval_store=AsyncSQLAlchemyApprovalStore(engine),
        relationship_store=relationship_store,
        delegation_store=AsyncSQLAlchemyDelegationStore(engine),
        session_store=AsyncSQLAlchemySessionStore(engine),
        **kwargs,
    )


def _build_async_memory_guard(**kwargs: Any) -> Any:
    """Wire AsyncGuard with all async in-memory stores and evaluators."""
    from open_guard.adapters.evaluators.abac import ABACEvaluator
    from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
    from open_guard.adapters.evaluators.rbac import RBACEvaluator
    from open_guard.adapters.evaluators.tbac import TBACEvaluator
    from open_guard.adapters.evaluators.trust import TrustGateEvaluator
    from open_guard.adapters.stores.async_memory import (
        AsyncInMemoryApprovalStore,
        AsyncInMemoryDelegationStore,
        AsyncInMemoryPolicyStore,
        AsyncInMemoryRelationshipStore,
        AsyncInMemorySessionStore,
        AsyncInMemoryTaskStore,
    )
    from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
    from open_guard.domain.ports.evaluator import EvaluatorPort
    from open_guard.domain.services.async_guard import AsyncGuard

    policy_store = AsyncInMemoryPolicyStore()
    relationship_store = AsyncInMemoryRelationshipStore()
    task_store = AsyncInMemoryTaskStore()

    evaluators: list[EvaluatorPort | AsyncEvaluatorPort] = [
        RBACEvaluator(),
        ABACEvaluator(),
        TBACEvaluator(task_store=task_store.sync_store),
        AsyncReBACEvaluator(relationship_store=relationship_store),
        TrustGateEvaluator(),
    ]

    return AsyncGuard(
        policy_store=policy_store,
        evaluators=evaluators,
        approval_store=AsyncInMemoryApprovalStore(),
        relationship_store=relationship_store,
        delegation_store=AsyncInMemoryDelegationStore(),
        session_store=AsyncInMemorySessionStore(),
        **kwargs,
    )
