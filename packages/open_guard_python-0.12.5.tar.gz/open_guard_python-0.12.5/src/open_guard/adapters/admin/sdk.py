"""PolicyAdmin — in-process administration SDK for open-guard."""

from __future__ import annotations

from typing import Any

from open_guard.domain.entities import (
    Delegation,
    DelegationScope,
    Policy,
    RelationTuple,
    Session,
    Subject,
)
from open_guard.domain.services.guard import Guard
from open_guard.domain.services.session_manager import SessionManager


class PolicyAdmin:
    """Tenant-scoped CRUD for policies, relationships, delegations, and sessions.

    Wraps a fully-wired :class:`Guard` and exposes ergonomic create / list /
    delete helpers that construct the correct domain entities internally.

    Usage::

        guard = Guard.from_config(backend="memory")
        admin = PolicyAdmin(guard)
        admin.create_policy(tenant_id="t1", evaluator_type="rbac", ...)
    """

    def __init__(self, guard: Guard) -> None:
        self._guard = guard
        # Build a SessionManager from the guard's session store (if wired).
        self._session_manager: SessionManager | None = None
        if guard._session_store is not None:
            self._session_manager = SessionManager(
                session_store=guard._session_store,
                clock=guard._clock,
                revocation_stream=guard._revocation_stream,
            )

    # ------------------------------------------------------------------
    # Policies
    # ------------------------------------------------------------------

    def create_policy(
        self,
        *,
        tenant_id: str,
        evaluator_type: str,
        subject_match: dict[str, Any] | None = None,
        action_match: str | list[str] | None = None,
        resource_match: dict[str, Any] | None = None,
        conditions: dict[str, Any] | None = None,
        effect: str = "allow",
        priority: int = 0,
    ) -> Policy:
        """Create and store a policy."""
        policy = Policy(
            tenant_id=tenant_id,
            evaluator_type=evaluator_type,
            subject_match=subject_match or {},
            action_match=action_match or "*",
            resource_match=resource_match or {},
            conditions=conditions or {},
            effect=effect,
            priority=priority,
        )
        return self._guard.policy_store.add(policy)

    def list_policies(
        self, tenant_id: str, *, evaluator_type: str | None = None
    ) -> list[Policy]:
        """List policies for a tenant, optionally filtered by evaluator type."""
        if evaluator_type:
            return self._guard.policy_store.get_by_tenant_and_type(
                tenant_id, evaluator_type
            )
        return self._guard.policy_store.get_by_tenant(tenant_id)

    def get_policy(self, policy_id: str, tenant_id: str) -> Policy | None:
        """Get a specific policy by ID.

        Scans tenant policies since the store has no get-by-id method.
        """
        policies = self._guard.policy_store.get_by_tenant(tenant_id)
        return next((p for p in policies if p.id == policy_id), None)

    def delete_policy(self, policy_id: str, tenant_id: str) -> None:
        """Delete a policy."""
        self._guard.policy_store.remove(policy_id, tenant_id)

    # ------------------------------------------------------------------
    # Roles (convenience — creates/removes RBAC policies)
    # ------------------------------------------------------------------

    def assign_role(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        role: str,
        resource_type: str | None = None,
        resource_match: dict[str, Any] | None = None,
        actions: list[str] | None = None,
    ) -> Policy:
        """Assign a role by creating an RBAC policy scoped to the subject.

        If *resource_match* is provided, the role only applies when the
        resource being accessed has matching attributes.  This enables
        resource-scoped role bindings (standard in Google IAM, AWS IAM,
        Azure RBAC).  Consumer defines what scoping means for their domain.

        Examples::

            # Global role — applies everywhere
            assign_role(tenant_id="t1", subject_id="alice", role="admin")

            # Scoped to a department
            assign_role(tenant_id="t1", subject_id="alice", role="writer",
                        resource_match={"department": "engineering"})
        """
        rm: dict[str, Any] = dict(resource_match) if resource_match else {}
        if resource_type:
            rm["type"] = resource_type
        return self.create_policy(
            tenant_id=tenant_id,
            evaluator_type="rbac",
            subject_match={"roles": [role], "id": subject_id},
            action_match=actions[0] if actions and len(actions) == 1 else "*",
            resource_match=rm,
        )

    def revoke_role(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        role: str,
        resource_match: dict[str, Any] | None = None,
    ) -> None:
        """Revoke a role by removing matching RBAC policies.

        If *resource_match* is provided, only the policy with that exact
        resource scope is removed (global roles with no scope are unaffected).
        """
        policies = self.list_policies(tenant_id, evaluator_type="rbac")
        for p in policies:
            sm = p.subject_match
            if (
                isinstance(sm, dict)
                and sm.get("id") == subject_id
                and role in sm.get("roles", [])
            ):
                if resource_match is not None:
                    rm = p.resource_match
                    if not isinstance(rm, dict) or rm != resource_match:
                        continue
                self.delete_policy(p.id, tenant_id)

    # ------------------------------------------------------------------
    # Relationships
    # ------------------------------------------------------------------

    def add_relationship(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        subject_type: str = "user",
        relation: str,
        object_type: str,
        object_id: str,
        subject_relation: str | None = None,
    ) -> RelationTuple:
        """Add a relationship tuple."""
        if not self._guard._relationship_store:
            raise ValueError("No relationship store configured")
        rt = RelationTuple(
            tenant_id=tenant_id,
            object_type=object_type,
            object_id=object_id,
            relation=relation,
            subject_type=subject_type,
            subject_id=subject_id,
            subject_relation=subject_relation,
        )
        return self._guard._relationship_store.write_tuple(rt)

    def list_relationships(
        self,
        tenant_id: str,
        *,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        """List relationship tuples with optional filters."""
        if not self._guard._relationship_store:
            raise ValueError("No relationship store configured")
        return self._guard._relationship_store.read_tuples(
            tenant_id=tenant_id,
            object_type=object_type,
            object_id=object_id,
            relation=relation,
            subject_type=subject_type,
            subject_id=subject_id,
        )

    def delete_relationship(self, tuple_id: str, tenant_id: str) -> None:
        """Delete a relationship tuple."""
        if not self._guard._relationship_store:
            raise ValueError("No relationship store configured")
        self._guard._relationship_store.delete_tuple(tuple_id, tenant_id)

    def check_relationship(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        subject_type: str = "user",
        relation: str,
        object_type: str,
        object_id: str,
    ) -> bool:
        """Check if a direct relationship exists between subject and object.

        Standard Zanzibar Check operation (OpenFGA ``Check``,
        SpiceDB ``CheckPermission``).  Returns ``True`` if the relationship
        tuple exists, ``False`` otherwise.  Checks direct tuples only —
        does not traverse computed permissions.
        """
        if not self._guard._relationship_store:
            raise ValueError("No relationship store configured")
        return self._guard._relationship_store.tuple_exists(
            tenant_id=tenant_id,
            object_type=object_type,
            object_id=object_id,
            relation=relation,
            subject_type=subject_type,
            subject_id=subject_id,
        )

    # ------------------------------------------------------------------
    # Delegations
    # ------------------------------------------------------------------

    def create_delegation(
        self,
        *,
        tenant_id: str,
        from_subject_id: str,
        to_subject_id: str,
        scopes: list[dict[str, Any]],
        from_subject_type: str = "user",
        to_subject_type: str = "user",
        **kwargs: Any,
    ) -> Delegation:
        """Create a delegation.

        ``scopes`` is a list of dicts, each with keys ``action_match``,
        ``resource_type``, and optionally ``resource_match`` / ``conditions``.
        """
        if not self._guard._delegation_manager:
            raise ValueError("No delegation store configured")

        delegation_scopes = [
            DelegationScope(
                action_match=s.get("action_match", "*"),
                resource_type=s["resource_type"],
                resource_match=s.get("resource_match", {}),
                conditions=s.get("conditions", {}),
            )
            for s in scopes
        ]

        from_subject = Subject(
            id=from_subject_id,
            actor_type=from_subject_type,
        )
        to_subject = Subject(
            id=to_subject_id,
            actor_type=to_subject_type,
        )

        result: Delegation = self._guard.delegate(
            caller=from_subject,
            from_subject=from_subject,
            to_subject=to_subject,
            scopes=delegation_scopes,
            tenant_id=tenant_id,
            **kwargs,
        )
        return result

    def list_delegations(
        self, tenant_id: str, *, subject_id: str
    ) -> list[Delegation]:
        """List active delegations where ``subject_id`` is the grantee."""
        if not self._guard._delegation_manager:
            raise ValueError("No delegation store configured")
        return self._guard._delegation_manager._store.list_active_for_grantee(
            to_subject_id=subject_id, tenant_id=tenant_id
        )

    def revoke_delegation(
        self,
        delegation_id: str,
        tenant_id: str,
        *,
        caller_id: str = "admin",
    ) -> None:
        """Revoke a delegation."""
        caller = Subject(id=caller_id)
        self._guard.revoke_delegation(
            delegation_id, caller=caller, tenant_id=tenant_id
        )

    # ------------------------------------------------------------------
    # Sessions
    # ------------------------------------------------------------------

    def create_session(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        activated_roles: list[str],
        ttl: Any | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Session:
        """Create an RBAC session.

        The subject must have ``activated_roles`` as a subset of their
        assigned roles in ``attributes["roles"]``. Pass a :class:`Subject`
        with the correct attributes, or use this convenience method which
        builds the Subject for you (with ``roles`` set to ``activated_roles``
        so validation passes).
        """
        if not self._session_manager:
            raise ValueError("No session store configured")
        subject = Subject(
            id=subject_id,
            attributes={"roles": list(activated_roles)},
        )
        return self._session_manager.create_session(
            subject=subject,
            tenant_id=tenant_id,
            activated_roles=activated_roles,
            ttl=ttl,
            metadata=metadata,
        )

    def deactivate_session(self, session_id: str, tenant_id: str) -> Session:
        """Deactivate an active session."""
        if not self._session_manager:
            raise ValueError("No session store configured")
        return self._session_manager.deactivate(session_id, tenant_id)

    def get_session(self, session_id: str, tenant_id: str) -> Session:
        """Get a session by ID.

        Raises ``SessionNotFoundError`` if the session does not exist.
        """
        if not self._session_manager:
            raise ValueError("No session store configured")
        return self._session_manager.get_session(session_id, tenant_id)

    def list_sessions(
        self, tenant_id: str, *, subject_id: str
    ) -> list[Session]:
        """List active sessions for a subject."""
        if not self._session_manager:
            raise ValueError("No session store configured")
        return self._session_manager.get_active_sessions(
            subject_id, tenant_id
        )
