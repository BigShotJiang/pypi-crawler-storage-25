"""Administration SDK for open-guard."""

from open_guard.adapters.admin.sdk import PolicyAdmin

__all__ = ["PolicyAdmin"]
