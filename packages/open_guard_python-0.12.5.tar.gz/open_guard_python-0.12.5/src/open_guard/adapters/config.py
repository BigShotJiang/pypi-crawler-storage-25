"""Configuration for open-guard using Pydantic settings."""

from __future__ import annotations

from pydantic_settings import BaseSettings


class OpenGuardConfig(BaseSettings):
    """Configuration for open-guard.

    Settings can be overridden via environment variables with the
    OPEN_GUARD_ prefix (e.g., OPEN_GUARD_DEFAULT_EFFECT=deny).
    """

    model_config = {"env_prefix": "OPEN_GUARD_"}

    DEFAULT_EFFECT: str = "deny"
    TENANT_REQUIRED: bool = True
