"""In-memory relationship store — thread-safe, tenant-scoped."""

from __future__ import annotations

import threading

from open_guard.domain.entities import RelationTuple
from open_guard.domain.exceptions import RelationshipError
from open_guard.domain.ports.relationship_store import RelationshipStorePort


class InMemoryRelationshipStore(RelationshipStorePort):
    """Thread-safe in-memory relationship tuple store.

    Suitable for development, testing, and single-process deployments.
    """

    def __init__(self) -> None:
        self._tuples: dict[
            str, dict[str, RelationTuple]
        ] = {}  # tenant_id → {tuple_id → RelationTuple}
        self._lock = threading.Lock()

    def write_tuple(self, relation_tuple: RelationTuple) -> RelationTuple:
        with self._lock:
            tid = relation_tuple.tenant_id
            if tid not in self._tuples:
                self._tuples[tid] = {}

            # Check for duplicate
            for existing in self._tuples[tid].values():
                if (
                    existing.object_type == relation_tuple.object_type
                    and existing.object_id == relation_tuple.object_id
                    and existing.relation == relation_tuple.relation
                    and existing.subject_type == relation_tuple.subject_type
                    and existing.subject_id == relation_tuple.subject_id
                    and existing.subject_relation == relation_tuple.subject_relation
                ):
                    raise RelationshipError(
                        f"Duplicate tuple: {relation_tuple.object_type}:"
                        f"{relation_tuple.object_id}#{relation_tuple.relation}"
                        f"@{relation_tuple.subject_type}:{relation_tuple.subject_id}"
                    )

            self._tuples[tid][relation_tuple.id] = relation_tuple
        return relation_tuple

    def delete_tuple(self, tuple_id: str, tenant_id: str) -> None:
        with self._lock:
            tenant_tuples = self._tuples.get(tenant_id, {})
            if tuple_id not in tenant_tuples:
                raise RelationshipError(
                    f"Tuple '{tuple_id}' not found in tenant '{tenant_id}'"
                )
            del tenant_tuples[tuple_id]

    def read_tuples(
        self,
        tenant_id: str,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        with self._lock:
            tenant_tuples = self._tuples.get(tenant_id, {})
            results: list[RelationTuple] = []
            for t in tenant_tuples.values():
                if object_type is not None and t.object_type != object_type:
                    continue
                if object_id is not None and t.object_id != object_id:
                    continue
                if relation is not None and t.relation != relation:
                    continue
                if subject_type is not None and t.subject_type != subject_type:
                    continue
                if subject_id is not None and t.subject_id != subject_id:
                    continue
                results.append(t)
            return results

    def tuple_exists(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        relation: str,
        subject_type: str,
        subject_id: str,
        subject_relation: str | None = None,
    ) -> bool:
        with self._lock:
            tenant_tuples = self._tuples.get(tenant_id, {})
            for t in tenant_tuples.values():
                if (
                    t.object_type == object_type
                    and t.object_id == object_id
                    and t.relation == relation
                    and t.subject_type == subject_type
                    and t.subject_id == subject_id
                    and t.subject_relation == subject_relation
                ):
                    return True
            return False

    def find_object_ids_for_subject(
        self,
        subject_id: str,
        subject_type: str,
        object_type: str,
        tenant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> list[str]:
        with self._lock:
            tenant_tuples = self._tuples.get(tenant_id, {})
            matching: set[str] = {
                t.object_id
                for t in tenant_tuples.values()
                if t.subject_id == subject_id
                and t.subject_type == subject_type
                and t.object_type == object_type
            }
        ordered = sorted(matching)
        return ordered[offset : offset + limit]
