"""In-memory DelegationStore — thread-safe, CAS-safe counters (Phase 5)."""

from __future__ import annotations

import threading
from datetime import datetime
from decimal import Decimal

from open_guard.domain.entities import Delegation, DelegationStatus
from open_guard.domain.exceptions import DelegationNotFoundError, UsageExhaustedError
from open_guard.domain.ports.delegation_store import DelegationStorePort


class InMemoryDelegationStore(DelegationStorePort):
    """Thread-safe in-memory Delegation store with RLock-protected mutations."""

    def __init__(self) -> None:
        # (tenant_id, delegation_id) -> Delegation
        self._by_id: dict[tuple[str, str], Delegation] = {}
        # (tenant_id, request_hash) -> delegation_id
        self._by_hash: dict[tuple[str, str], str] = {}
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    # Basic CRUD
    # ------------------------------------------------------------------

    def create(self, delegation: Delegation) -> Delegation:
        with self._lock:
            self._by_id[(delegation.tenant_id, delegation.id)] = delegation
            self._by_hash[
                (delegation.tenant_id, delegation.request_hash)
            ] = delegation.id
            return delegation

    def get(self, delegation_id: str, tenant_id: str) -> Delegation | None:
        with self._lock:
            return self._by_id.get((tenant_id, delegation_id))

    def find_by_hash(self, request_hash: str, tenant_id: str) -> Delegation | None:
        with self._lock:
            did = self._by_hash.get((tenant_id, request_hash))
            if did is None:
                return None
            return self._by_id.get((tenant_id, did))

    def list_active_for_grantee(
        self,
        to_subject_id: str,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[Delegation]:
        with self._lock:
            results = []
            for (tid, _), d in self._by_id.items():
                if tid != tenant_id:
                    continue
                if d.to_subject_id != to_subject_id:
                    continue
                if d.status != DelegationStatus.ACTIVE:
                    continue
                if resource_type is not None and not any(
                    s.resource_type == resource_type for s in d.scopes
                ):
                    continue
                results.append(d)
            return results

    def list_descendants(
        self, parent_delegation_id: str, tenant_id: str
    ) -> list[Delegation]:
        with self._lock:
            return self._collect_descendants(parent_delegation_id, tenant_id)

    def _collect_descendants(
        self, parent_id: str, tenant_id: str
    ) -> list[Delegation]:
        direct = [
            d
            for (tid, _), d in self._by_id.items()
            if tid == tenant_id and d.parent_delegation_id == parent_id
        ]
        result = list(direct)
        for child in direct:
            result.extend(self._collect_descendants(child.id, tenant_id))
        return result

    def update_status(
        self, delegation_id: str, tenant_id: str, status: DelegationStatus
    ) -> Delegation:
        with self._lock:
            d = self._by_id.get((tenant_id, delegation_id))
            if d is None:
                raise DelegationNotFoundError(
                    f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
                )
            updated = d.model_copy(update={"status": status})
            self._by_id[(tenant_id, delegation_id)] = updated
            return updated

    # ------------------------------------------------------------------
    # CAS-safe counter operations
    # ------------------------------------------------------------------

    def decrement_uses(
        self, delegation_id: str, tenant_id: str, amount: int
    ) -> Delegation:
        with self._lock:
            d = self._by_id.get((tenant_id, delegation_id))
            if d is None:
                raise DelegationNotFoundError(
                    f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
                )
            if d.uses_remaining is None:
                return d  # no counter — idempotent no-op
            if d.uses_remaining < amount:
                raise UsageExhaustedError(
                    f"Delegation {delegation_id!r} has {d.uses_remaining} use(s) "
                    f"remaining; requested {amount}"
                )
            new_remaining = d.uses_remaining - amount
            new_status = (
                DelegationStatus.EXHAUSTED
                if new_remaining == 0
                and (d.budget_remaining is None or d.budget_remaining <= Decimal(0))
                else d.status
            )
            updated = d.model_copy(
                update={"uses_remaining": new_remaining, "status": new_status}
            )
            self._by_id[(tenant_id, delegation_id)] = updated
            return updated

    def decrement_budget(
        self, delegation_id: str, tenant_id: str, cost: Decimal
    ) -> Delegation:
        with self._lock:
            d = self._by_id.get((tenant_id, delegation_id))
            if d is None:
                raise DelegationNotFoundError(
                    f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
                )
            if d.budget_remaining is None:
                return d  # no budget — idempotent no-op
            if d.budget_remaining < cost:
                raise UsageExhaustedError(
                    f"Delegation {delegation_id!r} has budget_remaining "
                    f"{d.budget_remaining}; requested cost {cost}"
                )
            new_remaining = d.budget_remaining - cost
            new_status = (
                DelegationStatus.EXHAUSTED
                if new_remaining <= Decimal(0)
                and (d.uses_remaining is None or d.uses_remaining == 0)
                else d.status
            )
            updated = d.model_copy(
                update={"budget_remaining": new_remaining, "status": new_status}
            )
            self._by_id[(tenant_id, delegation_id)] = updated
            return updated

    # ------------------------------------------------------------------
    # Lease
    # ------------------------------------------------------------------

    def touch_heartbeat(
        self, delegation_id: str, tenant_id: str, now: datetime
    ) -> Delegation:
        with self._lock:
            d = self._by_id.get((tenant_id, delegation_id))
            if d is None:
                raise DelegationNotFoundError(
                    f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
                )
            updated = d.model_copy(update={"last_heartbeat_at": now})
            self._by_id[(tenant_id, delegation_id)] = updated
            return updated

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._lock:
            count = 0
            for key, d in list(self._by_id.items()):
                if key[0] != tenant_id:
                    continue
                active_statuses = (
                    DelegationStatus.ACTIVE,
                    DelegationStatus.PENDING_APPROVAL,
                )
                if d.status not in active_statuses:
                    continue
                if self._is_expired(d, now):
                    self._by_id[key] = d.model_copy(
                        update={"status": DelegationStatus.EXPIRED}
                    )
                    count += 1
            return count

    @staticmethod
    def _is_expired(d: Delegation, now: datetime) -> bool:
        if d.expires_at is not None and now >= d.expires_at:
            return True
        return (
            d.lease_ttl is not None
            and d.last_heartbeat_at is not None
            and now >= d.last_heartbeat_at + d.lease_ttl
        )
