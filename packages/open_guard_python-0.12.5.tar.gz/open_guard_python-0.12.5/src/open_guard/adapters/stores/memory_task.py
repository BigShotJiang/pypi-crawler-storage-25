"""In-memory task store — thread-safe, tenant-scoped."""

from __future__ import annotations

import threading

from open_guard.domain.entities import Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.ports.task_store import TaskStorePort


class InMemoryTaskStore(TaskStorePort):
    """Thread-safe in-memory task store.

    All operations are tenant-scoped. Suitable for development and testing.
    """

    def __init__(self) -> None:
        self._tasks: dict[str, dict[str, Task]] = {}  # tenant_id -> {task_id -> Task}
        self._lock = threading.Lock()

    def add(self, task: Task) -> Task:
        with self._lock:
            if task.tenant_id not in self._tasks:
                self._tasks[task.tenant_id] = {}
            self._tasks[task.tenant_id][task.id] = task
        return task

    def get(self, task_id: str, tenant_id: str) -> Task | None:
        with self._lock:
            return self._tasks.get(tenant_id, {}).get(task_id)

    def update(self, task: Task) -> Task:
        with self._lock:
            tenant_tasks = self._tasks.get(task.tenant_id, {})
            if task.id not in tenant_tasks:
                raise TaskError(
                    f"Task '{task.id}' not found in tenant '{task.tenant_id}'"
                )
            tenant_tasks[task.id] = task
        return task

    def get_active_by_actor(self, actor_id: str, tenant_id: str) -> list[Task]:
        with self._lock:
            tenant_tasks = self._tasks.get(tenant_id, {})
            return [
                t
                for t in tenant_tasks.values()
                if t.actor_id == actor_id and t.status == TaskStatus.ACTIVE
            ]

    def remove(self, task_id: str, tenant_id: str) -> None:
        with self._lock:
            tenant_tasks = self._tasks.get(tenant_id, {})
            if task_id not in tenant_tasks:
                raise TaskError(
                    f"Task '{task_id}' not found in tenant '{tenant_id}'"
                )
            del tenant_tasks[task_id]
