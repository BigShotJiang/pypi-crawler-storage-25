"""SQLAlchemy table definitions for open-guard stores.

Tables use the ``open_guard_`` prefix to avoid collisions.
All tables include a ``tenant_id`` column for row-level tenant isolation.

Usage:
    from open_guard.adapters.stores.sql_models import metadata
    metadata.create_all(engine)

Consumers can include ``metadata`` in their own Alembic ``env.py``
for managed migrations.
"""

from __future__ import annotations

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Index,
    Integer,
    MetaData,
    Numeric,
    String,
    Table,
    UniqueConstraint,
)
from sqlalchemy.types import JSON

metadata = MetaData()

policies_table = Table(
    "open_guard_policies",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("evaluator_type", String(32), nullable=False),
    Column("subject_match", JSON, nullable=False),
    Column("action_match", JSON, nullable=False),
    Column("resource_match", JSON, nullable=False),
    Column("conditions", JSON, nullable=False),
    Column("effect", String(16), nullable=False),
    Column("priority", Integer, nullable=False, default=0),
    Index("ix_og_policies_tenant_type", "tenant_id", "evaluator_type"),
)

tasks_table = Table(
    "open_guard_tasks",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("actor_id", String(256), nullable=False),
    Column("actor_type", String(32), nullable=False),
    Column("parent_task_id", String(36), nullable=True),
    Column("status", String(32), nullable=False),
    Column("allowed_actions", JSON, nullable=False),
    Column("allowed_resource_types", JSON, nullable=False),
    Column("created_at", DateTime, nullable=False),
    Column("activated_at", DateTime, nullable=True),
    Column("expires_at", DateTime, nullable=True),
    Column("completed_at", DateTime, nullable=True),
    Column("metadata_", JSON, nullable=False),
    Index("ix_og_tasks_tenant_actor", "tenant_id", "actor_id"),
    Index("ix_og_tasks_tenant_status", "tenant_id", "status"),
)

relationship_tuples_table = Table(
    "open_guard_relationship_tuples",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("object_type", String(128), nullable=False),
    Column("object_id", String(256), nullable=False),
    Column("relation", String(128), nullable=False),
    Column("subject_type", String(128), nullable=False),
    Column("subject_id", String(256), nullable=False),
    Column("subject_relation", String(128), nullable=True),
    Index(
        "ix_og_tuples_object",
        "tenant_id", "object_type", "object_id", "relation",
    ),
    Index(
        "ix_og_tuples_subject",
        "tenant_id", "subject_type", "subject_id",
    ),
    UniqueConstraint(
        "tenant_id", "object_type", "object_id", "relation",
        "subject_type", "subject_id", "subject_relation",
        name="uq_og_tuples_unique",
    ),
)

delegations_table = Table(
    "open_guard_delegations",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("from_subject_id", String(256), nullable=False),
    Column("from_subject_type", String(32), nullable=False),
    Column("to_subject_id", String(256), nullable=False),
    Column("to_subject_type", String(32), nullable=False),
    Column("scopes", JSON, nullable=False),
    Column("parent_delegation_id", String(36), nullable=True),
    Column("max_uses", Integer, nullable=True),
    Column("uses_remaining", Integer, nullable=True),
    Column("budget", Numeric(precision=20, scale=8), nullable=True),
    Column("budget_remaining", Numeric(precision=20, scale=8), nullable=True),
    Column("lease_ttl_seconds", Numeric(precision=20, scale=6), nullable=True),
    Column("last_heartbeat_at", DateTime(timezone=True), nullable=True),
    Column("renewable_by", JSON, nullable=True),
    Column("expires_at", DateTime(timezone=True), nullable=True),
    Column("re_check_on_use", Boolean, nullable=False, default=True),
    Column("status", String(32), nullable=False),
    Column("approval_request_id", String(36), nullable=True),
    Column("request_hash", String(64), nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("created_by", String(256), nullable=False),
    Column("reason", String(1024), nullable=True),
    Index("ix_og_delegations_tenant_grantee", "tenant_id", "to_subject_id"),
    Index("ix_og_delegations_tenant_hash", "tenant_id", "request_hash"),
    Index("ix_og_delegations_tenant_status", "tenant_id", "status"),
    Index("ix_og_delegations_parent", "tenant_id", "parent_delegation_id"),
)

approval_requests_table = Table(
    "open_guard_approval_requests",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("request_hash", String(64), nullable=False),
    Column("subject_id", String(256), nullable=False),
    Column("action_name", String(128), nullable=False),
    Column("resource_id", String(256), nullable=False),
    Column("resource_type", String(128), nullable=False),
    Column("status", String(32), nullable=False),
    Column("requirement", JSON, nullable=False),
    Column("approvers_received", JSON, nullable=False),
    Column("created_at", DateTime, nullable=False),
    Column("expires_at", DateTime, nullable=True),
    Column("resolved_at", DateTime, nullable=True),
    Column("reason", String(1024), nullable=False, default=""),
    Index("ix_og_approvals_tenant_hash", "tenant_id", "request_hash"),
    Index("ix_og_approvals_tenant_status", "tenant_id", "status"),
)

session_table = Table(
    "open_guard_sessions",
    metadata,
    Column("id", String, primary_key=True),
    Column("tenant_id", String, nullable=False, index=True),
    Column("subject_id", String, nullable=False, index=True),
    Column("activated_roles", JSON, nullable=False),
    Column("status", String, nullable=False, default="active"),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("expires_at", DateTime(timezone=True), nullable=True),
    Column("deactivated_at", DateTime(timezone=True), nullable=True),
    Column("metadata_", JSON, nullable=False, default=dict),
)
