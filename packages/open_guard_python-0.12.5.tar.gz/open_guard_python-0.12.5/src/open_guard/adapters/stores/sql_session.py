"""SQLAlchemy-backed session store (Phase 6, ENH-001)."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy import Engine, and_, select, update

from open_guard.adapters.stores.sql_models import metadata, session_table
from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError
from open_guard.domain.ports.session_store import SessionStorePort


class SQLAlchemySessionStore(SessionStorePort):
    """SQLAlchemy implementation of SessionStorePort.

    Consumer-owned engine pattern (same as other SQL stores).
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    def create_tables(self) -> None:
        metadata.create_all(self._engine, tables=[session_table])

    @classmethod
    def from_url(cls, url: str, **engine_kwargs: object) -> SQLAlchemySessionStore:
        from sqlalchemy import create_engine
        engine = create_engine(url, **engine_kwargs)
        store = cls(engine)
        store.create_tables()
        return store

    def create(self, session: Session) -> Session:
        with self._engine.begin() as conn:
            conn.execute(
                session_table.insert().values(
                    id=session.id,
                    tenant_id=session.tenant_id,
                    subject_id=session.subject_id,
                    activated_roles=session.activated_roles,
                    status=session.status.value,
                    created_at=session.created_at,
                    expires_at=session.expires_at,
                    deactivated_at=session.deactivated_at,
                    metadata_=session.metadata,
                )
            )
        return session

    def get(self, session_id: str, tenant_id: str) -> Session | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(session_table).where(
                    and_(
                        session_table.c.id == session_id,
                        session_table.c.tenant_id == tenant_id,
                    )
                )
            ).first()
            if row is None:
                return None
            return self._row_to_session(row)

    def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(session_table).where(
                    and_(
                        session_table.c.tenant_id == tenant_id,
                        session_table.c.subject_id == subject_id,
                        session_table.c.status == SessionStatus.ACTIVE.value,
                    )
                )
            ).fetchall()
            return [self._row_to_session(r) for r in rows]

    def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        values: dict[str, object] = {"status": status.value}
        if deactivated_at is not None:
            values["deactivated_at"] = deactivated_at
        with self._engine.begin() as conn:
            result = conn.execute(
                update(session_table)
                .where(
                    and_(
                        session_table.c.id == session_id,
                        session_table.c.tenant_id == tenant_id,
                    )
                )
                .values(**values)
            )
            if result.rowcount == 0:
                raise SessionNotFoundError(
                    f"Session {session_id!r} not found in tenant {tenant_id!r}"
                )
        return self.get(session_id, tenant_id)  # type: ignore[return-value]

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._engine.begin() as conn:
            result = conn.execute(
                update(session_table)
                .where(
                    and_(
                        session_table.c.tenant_id == tenant_id,
                        session_table.c.status == SessionStatus.ACTIVE.value,
                        session_table.c.expires_at <= now,
                    )
                )
                .values(status=SessionStatus.EXPIRED.value)
            )
            return result.rowcount

    @staticmethod
    def _row_to_session(row: Any) -> Session:
        created_at = row.created_at
        if created_at.tzinfo is None:
            created_at = created_at.replace(tzinfo=UTC)

        expires_at = row.expires_at
        if expires_at is not None and expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=UTC)

        deactivated_at = row.deactivated_at
        if deactivated_at is not None and deactivated_at.tzinfo is None:
            deactivated_at = deactivated_at.replace(tzinfo=UTC)

        return Session(
            id=row.id,
            tenant_id=row.tenant_id,
            subject_id=row.subject_id,
            activated_roles=row.activated_roles,
            status=SessionStatus(row.status),
            created_at=created_at,
            expires_at=expires_at,
            deactivated_at=deactivated_at,
            metadata=row.metadata_ or {},
        )
