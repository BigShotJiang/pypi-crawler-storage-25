"""In-memory ApprovalStore — thread-safe, tenant-scoped (Phase 3, FEAT-007)."""

from __future__ import annotations

import threading
from datetime import datetime

from open_guard.domain.entities import ApprovalRequest, ApprovalStatus
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.ports.approval_store import ApprovalStorePort


class InMemoryApprovalStore(ApprovalStorePort):
    """Thread-safe in-memory ApprovalRequest store.

    Enforces at most one PENDING request per (tenant_id, request_hash) —
    attempting `create()` with an existing PENDING for the same hash raises
    `ApprovalError`.
    """

    def __init__(self) -> None:
        # tenant_id -> request_id -> ApprovalRequest
        self._requests: dict[str, dict[str, ApprovalRequest]] = {}
        self._lock = threading.Lock()

    def create(self, request: ApprovalRequest) -> ApprovalRequest:
        with self._lock:
            tenant_bucket = self._requests.setdefault(request.tenant_id, {})
            # Backstop: no duplicate PENDING for same hash
            for existing in tenant_bucket.values():
                if (
                    existing.request_hash == request.request_hash
                    and existing.status == ApprovalStatus.PENDING
                ):
                    raise ApprovalError(
                        f"Pending approval already exists for hash "
                        f"{request.request_hash[:12]}... in tenant {request.tenant_id}"
                    )
            tenant_bucket[request.id] = request
            return request

    def get(self, request_id: str, tenant_id: str) -> ApprovalRequest | None:
        with self._lock:
            return self._requests.get(tenant_id, {}).get(request_id)

    def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        with self._lock:
            for req in self._requests.get(tenant_id, {}).values():
                if (
                    req.request_hash == request_hash
                    and req.status == ApprovalStatus.PENDING
                ):
                    return req
            return None

    def find_latest_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        with self._lock:
            matches = [
                r
                for r in self._requests.get(tenant_id, {}).values()
                if r.request_hash == request_hash
            ]
            if not matches:
                return None
            return max(matches, key=lambda r: r.created_at)

    def update(self, request: ApprovalRequest) -> ApprovalRequest:
        with self._lock:
            tenant_bucket = self._requests.get(request.tenant_id, {})
            if request.id not in tenant_bucket:
                raise ApprovalError(
                    f"ApprovalRequest {request.id} not found in tenant "
                    f"{request.tenant_id}"
                )
            tenant_bucket[request.id] = request
            return request

    def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        with self._lock:
            return [
                r
                for r in self._requests.get(tenant_id, {}).values()
                if r.status == ApprovalStatus.PENDING
            ]

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._lock:
            tenant_bucket = self._requests.get(tenant_id, {})
            expired_count = 0
            for req_id, req in list(tenant_bucket.items()):
                if (
                    req.status == ApprovalStatus.PENDING
                    and req.expires_at is not None
                    and req.expires_at <= now
                ):
                    tenant_bucket[req_id] = req.model_copy(
                        update={
                            "status": ApprovalStatus.EXPIRED,
                            "resolved_at": now,
                            "reason": "approval expired",
                        }
                    )
                    expired_count += 1
            return expired_count
