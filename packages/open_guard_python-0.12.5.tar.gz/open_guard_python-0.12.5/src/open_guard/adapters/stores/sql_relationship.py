"""SQLAlchemy-backed relationship tuple store."""

from __future__ import annotations

from typing import Any

from sqlalchemy import Engine, create_engine, select

from open_guard.adapters.stores.sql_models import (
    metadata,
    relationship_tuples_table,
)
from open_guard.domain.entities import RelationTuple
from open_guard.domain.exceptions import RelationshipError
from open_guard.domain.ports.relationship_store import RelationshipStorePort


class SQLAlchemyRelationshipStore(RelationshipStorePort):
    """SQLAlchemy-backed relationship tuple store.

    Accepts an externally-owned Engine. Use ``from_url()`` for convenience.
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    @classmethod
    def from_url(cls, url: str, **kwargs: Any) -> SQLAlchemyRelationshipStore:
        engine = create_engine(url, **kwargs)
        return cls(engine)

    def create_tables(self) -> None:
        metadata.create_all(self._engine)

    def write_tuple(self, relation_tuple: RelationTuple) -> RelationTuple:
        # Application-level duplicate check (SQLite treats NULL as distinct
        # in unique constraints, so we cannot rely on DB-level enforcement
        # when subject_relation is NULL).
        if self.tuple_exists(
            relation_tuple.tenant_id,
            relation_tuple.object_type,
            relation_tuple.object_id,
            relation_tuple.relation,
            relation_tuple.subject_type,
            relation_tuple.subject_id,
            relation_tuple.subject_relation,
        ):
            raise RelationshipError(
                f"Duplicate tuple: {relation_tuple.object_type}:"
                f"{relation_tuple.object_id}#{relation_tuple.relation}"
                f"@{relation_tuple.subject_type}:{relation_tuple.subject_id}"
            )

        with self._engine.connect() as conn:
            conn.execute(
                relationship_tuples_table.insert().values(
                    id=relation_tuple.id,
                    tenant_id=relation_tuple.tenant_id,
                    object_type=relation_tuple.object_type,
                    object_id=relation_tuple.object_id,
                    relation=relation_tuple.relation,
                    subject_type=relation_tuple.subject_type,
                    subject_id=relation_tuple.subject_id,
                    subject_relation=relation_tuple.subject_relation,
                )
            )
            conn.commit()
        return relation_tuple

    def delete_tuple(self, tuple_id: str, tenant_id: str) -> None:
        with self._engine.connect() as conn:
            result = conn.execute(
                relationship_tuples_table.delete().where(
                    relationship_tuples_table.c.id == tuple_id,
                    relationship_tuples_table.c.tenant_id == tenant_id,
                )
            )
            if result.rowcount == 0:
                raise RelationshipError(
                    f"Tuple '{tuple_id}' not found in tenant '{tenant_id}'"
                )
            conn.commit()

    def read_tuples(
        self,
        tenant_id: str,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        t = relationship_tuples_table
        stmt = select(t).where(t.c.tenant_id == tenant_id)

        if object_type is not None:
            stmt = stmt.where(t.c.object_type == object_type)
        if object_id is not None:
            stmt = stmt.where(t.c.object_id == object_id)
        if relation is not None:
            stmt = stmt.where(t.c.relation == relation)
        if subject_type is not None:
            stmt = stmt.where(t.c.subject_type == subject_type)
        if subject_id is not None:
            stmt = stmt.where(t.c.subject_id == subject_id)

        with self._engine.connect() as conn:
            result = conn.execute(stmt)
            return [self._row_to_tuple(row) for row in result]

    def tuple_exists(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        relation: str,
        subject_type: str,
        subject_id: str,
        subject_relation: str | None = None,
    ) -> bool:
        t = relationship_tuples_table
        stmt = select(t.c.id).where(
            t.c.tenant_id == tenant_id,
            t.c.object_type == object_type,
            t.c.object_id == object_id,
            t.c.relation == relation,
            t.c.subject_type == subject_type,
            t.c.subject_id == subject_id,
        )
        if subject_relation is not None:
            stmt = stmt.where(t.c.subject_relation == subject_relation)
        else:
            stmt = stmt.where(t.c.subject_relation.is_(None))

        with self._engine.connect() as conn:
            result = conn.execute(stmt)
            return result.first() is not None

    def find_object_ids_for_subject(
        self,
        subject_id: str,
        subject_type: str,
        object_type: str,
        tenant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> list[str]:
        t = relationship_tuples_table
        stmt = (
            select(t.c.object_id)
            .where(
                t.c.tenant_id == tenant_id,
                t.c.subject_id == subject_id,
                t.c.subject_type == subject_type,
                t.c.object_type == object_type,
            )
            .distinct()
            .order_by(t.c.object_id)
            .offset(offset)
            .limit(limit)
        )
        with self._engine.connect() as conn:
            return [row.object_id for row in conn.execute(stmt)]

    @staticmethod
    def _row_to_tuple(row: Any) -> RelationTuple:
        return RelationTuple(
            id=row.id,
            tenant_id=row.tenant_id,
            object_type=row.object_type,
            object_id=row.object_id,
            relation=row.relation,
            subject_type=row.subject_type,
            subject_id=row.subject_id,
            subject_relation=row.subject_relation,
        )
