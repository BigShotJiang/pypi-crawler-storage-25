"""Thread-safe in-memory session store (Phase 6, ENH-001)."""

from __future__ import annotations

import threading
from datetime import datetime

from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError
from open_guard.domain.ports.session_store import SessionStorePort


class InMemorySessionStore(SessionStorePort):
    """In-memory implementation of SessionStorePort.

    Thread-safe via a reentrant lock. Suitable for testing and
    single-process deployments.
    """

    def __init__(self) -> None:
        self._sessions: dict[str, Session] = {}
        self._lock = threading.RLock()

    def create(self, session: Session) -> Session:
        with self._lock:
            self._sessions[session.id] = session
            return session

    def get(self, session_id: str, tenant_id: str) -> Session | None:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is not None and session.tenant_id == tenant_id:
                return session
            return None

    def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        with self._lock:
            return [
                s
                for s in self._sessions.values()
                if s.tenant_id == tenant_id
                and s.subject_id == subject_id
                and s.status == SessionStatus.ACTIVE
            ]

    def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None or session.tenant_id != tenant_id:
                raise SessionNotFoundError(
                    f"Session {session_id!r} not found in tenant {tenant_id!r}"
                )
            updates: dict[str, object] = {"status": status}
            if deactivated_at is not None:
                updates["deactivated_at"] = deactivated_at
            updated = session.model_copy(update=updates)
            self._sessions[session_id] = updated
            return updated

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._lock:
            count = 0
            for sid, session in list(self._sessions.items()):
                if (
                    session.tenant_id == tenant_id
                    and session.status == SessionStatus.ACTIVE
                    and session.expires_at is not None
                    and session.expires_at <= now
                ):
                    self._sessions[sid] = session.model_copy(
                        update={"status": SessionStatus.EXPIRED}
                    )
                    count += 1
            return count
