"""Async SQLAlchemy-backed ApprovalStore (Phase 7 — T9)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import and_, select, update
from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker

from open_guard.adapters.stores.sql_approval import (
    _decision_from_json,
    _decision_to_json,
    _requirement_from_json,
    _requirement_to_json,
)
from open_guard.adapters.stores.sql_models import (
    approval_requests_table,
    metadata,
)
from open_guard.domain.entities import (
    ApprovalRequest,
    ApprovalStatus,
)
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.ports.async_approval_store import AsyncApprovalStorePort


def _row_to_request(row: Any) -> ApprovalRequest:
    return ApprovalRequest(
        id=row["id"],
        tenant_id=row["tenant_id"],
        request_hash=row["request_hash"],
        subject_id=row["subject_id"],
        action_name=row["action_name"],
        resource_id=row["resource_id"],
        resource_type=row["resource_type"],
        status=ApprovalStatus(row["status"]),
        requirement=_requirement_from_json(row["requirement"]),
        approvers_received=[
            _decision_from_json(d) for d in row["approvers_received"]
        ],
        created_at=row["created_at"],
        expires_at=row["expires_at"],
        resolved_at=row["resolved_at"],
        reason=row["reason"] or "",
    )


class AsyncSQLAlchemyApprovalStore(AsyncApprovalStorePort):
    """Async SQLAlchemy-backed ApprovalRequest store.

    Accepts an externally-owned ``AsyncEngine``.
    Call ``create_tables()`` to create tables (idempotent).

    Portable across SQLite / PostgreSQL / MySQL via JSON columns for
    ``requirement`` and ``approvers_received``. Application-level check against
    duplicate PENDING requests for the same (tenant, request_hash).
    """

    def __init__(self, engine: AsyncEngine) -> None:
        self._engine = engine
        self._session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async def create_tables(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

    async def create(self, request: ApprovalRequest) -> ApprovalRequest:
        # Application-level backstop: reject if a PENDING exists for this hash
        existing = await self.find_by_hash(request.request_hash, request.tenant_id)
        if existing is not None:
            raise ApprovalError(
                f"Pending approval already exists for hash "
                f"{request.request_hash[:12]}... in tenant {request.tenant_id}"
            )
        async with self._engine.begin() as conn:
            await conn.execute(
                approval_requests_table.insert().values(
                    id=request.id,
                    tenant_id=request.tenant_id,
                    request_hash=request.request_hash,
                    subject_id=request.subject_id,
                    action_name=request.action_name,
                    resource_id=request.resource_id,
                    resource_type=request.resource_type,
                    status=request.status.value,
                    requirement=_requirement_to_json(request.requirement),
                    approvers_received=[
                        _decision_to_json(d) for d in request.approvers_received
                    ],
                    created_at=request.created_at,
                    expires_at=request.expires_at,
                    resolved_at=request.resolved_at,
                    reason=request.reason,
                )
            )
        return request

    async def get(
        self, request_id: str, tenant_id: str
    ) -> ApprovalRequest | None:
        async with self._engine.connect() as conn:
            row = (
                await conn.execute(
                    select(approval_requests_table).where(
                        and_(
                            approval_requests_table.c.id == request_id,
                            approval_requests_table.c.tenant_id == tenant_id,
                        )
                    )
                )
            ).first()
        if row is None:
            return None
        return _row_to_request(row._mapping)

    async def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        async with self._engine.connect() as conn:
            row = (
                await conn.execute(
                    select(approval_requests_table).where(
                        and_(
                            approval_requests_table.c.tenant_id == tenant_id,
                            approval_requests_table.c.request_hash == request_hash,
                            approval_requests_table.c.status
                            == ApprovalStatus.PENDING.value,
                        )
                    )
                )
            ).first()
        if row is None:
            return None
        return _row_to_request(row._mapping)

    async def find_latest_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        async with self._engine.connect() as conn:
            row = (
                await conn.execute(
                    select(approval_requests_table)
                    .where(
                        and_(
                            approval_requests_table.c.tenant_id == tenant_id,
                            approval_requests_table.c.request_hash == request_hash,
                        )
                    )
                    .order_by(approval_requests_table.c.created_at.desc())
                    .limit(1)
                )
            ).first()
        if row is None:
            return None
        return _row_to_request(row._mapping)

    async def update(self, request: ApprovalRequest) -> ApprovalRequest:
        async with self._engine.begin() as conn:
            result = await conn.execute(
                update(approval_requests_table)
                .where(
                    and_(
                        approval_requests_table.c.id == request.id,
                        approval_requests_table.c.tenant_id == request.tenant_id,
                    )
                )
                .values(
                    status=request.status.value,
                    approvers_received=[
                        _decision_to_json(d) for d in request.approvers_received
                    ],
                    resolved_at=request.resolved_at,
                    reason=request.reason,
                )
            )
            if result.rowcount == 0:
                raise ApprovalError(
                    f"ApprovalRequest {request.id} not found in tenant "
                    f"{request.tenant_id}"
                )
        return request

    async def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        async with self._engine.connect() as conn:
            rows = (
                await conn.execute(
                    select(approval_requests_table).where(
                        and_(
                            approval_requests_table.c.tenant_id == tenant_id,
                            approval_requests_table.c.status
                            == ApprovalStatus.PENDING.value,
                        )
                    )
                )
            ).all()
        return [_row_to_request(r._mapping) for r in rows]

    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        async with self._engine.begin() as conn:
            result = await conn.execute(
                update(approval_requests_table)
                .where(
                    and_(
                        approval_requests_table.c.tenant_id == tenant_id,
                        approval_requests_table.c.status
                        == ApprovalStatus.PENDING.value,
                        approval_requests_table.c.expires_at.is_not(None),
                        approval_requests_table.c.expires_at <= now,
                    )
                )
                .values(
                    status=ApprovalStatus.EXPIRED.value,
                    resolved_at=now,
                    reason="approval expired",
                )
            )
            return int(result.rowcount)
