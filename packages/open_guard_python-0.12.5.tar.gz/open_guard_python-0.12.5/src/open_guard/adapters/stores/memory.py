"""In-memory policy store — thread-safe, tenant-scoped."""

from __future__ import annotations

import threading

from open_guard.domain.entities import Policy
from open_guard.domain.exceptions import PolicyError
from open_guard.domain.ports.policy_store import PolicyStorePort


class InMemoryPolicyStore(PolicyStorePort):
    """Thread-safe in-memory policy store.

    All operations are tenant-scoped. Suitable for development, testing,
    and single-process deployments.
    """

    def __init__(self) -> None:
        self._policies: dict[
            str, dict[str, Policy]
        ] = {}  # tenant_id → {policy_id → Policy}
        self._lock = threading.Lock()

    def add(self, policy: Policy) -> Policy:
        with self._lock:
            if policy.tenant_id not in self._policies:
                self._policies[policy.tenant_id] = {}
            self._policies[policy.tenant_id][policy.id] = policy

        return policy

    def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        with self._lock:
            tenant_policies = self._policies.get(tenant_id, {})
            return list(tenant_policies.values())

    def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        with self._lock:
            tenant_policies = self._policies.get(tenant_id, {})
            return [
                p
                for p in tenant_policies.values()
                if p.evaluator_type == evaluator_type
            ]

    def remove(self, policy_id: str, tenant_id: str) -> None:
        with self._lock:
            tenant_policies = self._policies.get(tenant_id, {})
            if policy_id not in tenant_policies:
                raise PolicyError(
                    f"Policy '{policy_id}' not found in tenant '{tenant_id}'"
                )
            del tenant_policies[policy_id]
