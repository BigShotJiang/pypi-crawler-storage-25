"""Async SQLAlchemy-backed relationship tuple store (Phase 7 — T9)."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker

from open_guard.adapters.stores.sql_models import (
    metadata,
    relationship_tuples_table,
)
from open_guard.domain.entities import RelationTuple
from open_guard.domain.exceptions import RelationshipError
from open_guard.domain.ports.async_relationship_store import (
    AsyncRelationshipStorePort,
)


class AsyncSQLAlchemyRelationshipStore(AsyncRelationshipStorePort):
    """Async SQLAlchemy-backed relationship tuple store.

    Accepts an externally-owned ``AsyncEngine``.
    """

    def __init__(self, engine: AsyncEngine) -> None:
        self._engine = engine
        self._session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async def create_tables(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

    async def write_tuple(self, relation_tuple: RelationTuple) -> RelationTuple:
        # Application-level duplicate check (SQLite treats NULL as distinct
        # in unique constraints, so we cannot rely on DB-level enforcement
        # when subject_relation is NULL).
        if await self.tuple_exists(
            relation_tuple.tenant_id,
            relation_tuple.object_type,
            relation_tuple.object_id,
            relation_tuple.relation,
            relation_tuple.subject_type,
            relation_tuple.subject_id,
            relation_tuple.subject_relation,
        ):
            raise RelationshipError(
                f"Duplicate tuple: {relation_tuple.object_type}:"
                f"{relation_tuple.object_id}#{relation_tuple.relation}"
                f"@{relation_tuple.subject_type}:{relation_tuple.subject_id}"
            )

        async with self._engine.begin() as conn:
            await conn.execute(
                relationship_tuples_table.insert().values(
                    id=relation_tuple.id,
                    tenant_id=relation_tuple.tenant_id,
                    object_type=relation_tuple.object_type,
                    object_id=relation_tuple.object_id,
                    relation=relation_tuple.relation,
                    subject_type=relation_tuple.subject_type,
                    subject_id=relation_tuple.subject_id,
                    subject_relation=relation_tuple.subject_relation,
                )
            )
        return relation_tuple

    async def delete_tuple(self, tuple_id: str, tenant_id: str) -> None:
        async with self._engine.begin() as conn:
            result = await conn.execute(
                relationship_tuples_table.delete().where(
                    relationship_tuples_table.c.id == tuple_id,
                    relationship_tuples_table.c.tenant_id == tenant_id,
                )
            )
            if result.rowcount == 0:
                raise RelationshipError(
                    f"Tuple '{tuple_id}' not found in tenant '{tenant_id}'"
                )

    async def read_tuples(
        self,
        tenant_id: str,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        t = relationship_tuples_table
        stmt = select(t).where(t.c.tenant_id == tenant_id)

        if object_type is not None:
            stmt = stmt.where(t.c.object_type == object_type)
        if object_id is not None:
            stmt = stmt.where(t.c.object_id == object_id)
        if relation is not None:
            stmt = stmt.where(t.c.relation == relation)
        if subject_type is not None:
            stmt = stmt.where(t.c.subject_type == subject_type)
        if subject_id is not None:
            stmt = stmt.where(t.c.subject_id == subject_id)

        async with self._engine.connect() as conn:
            result = await conn.execute(stmt)
            return [self._row_to_tuple(row) for row in result]

    async def tuple_exists(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        relation: str,
        subject_type: str,
        subject_id: str,
        subject_relation: str | None = None,
    ) -> bool:
        t = relationship_tuples_table
        stmt = select(t.c.id).where(
            t.c.tenant_id == tenant_id,
            t.c.object_type == object_type,
            t.c.object_id == object_id,
            t.c.relation == relation,
            t.c.subject_type == subject_type,
            t.c.subject_id == subject_id,
        )
        if subject_relation is not None:
            stmt = stmt.where(t.c.subject_relation == subject_relation)
        else:
            stmt = stmt.where(t.c.subject_relation.is_(None))

        async with self._engine.connect() as conn:
            result = await conn.execute(stmt)
            return result.first() is not None

    async def find_object_ids_for_subject(
        self,
        subject_id: str,
        subject_type: str,
        object_type: str,
        tenant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> list[str]:
        t = relationship_tuples_table
        stmt = (
            select(t.c.object_id)
            .where(
                t.c.tenant_id == tenant_id,
                t.c.subject_id == subject_id,
                t.c.subject_type == subject_type,
                t.c.object_type == object_type,
            )
            .distinct()
            .order_by(t.c.object_id)
            .offset(offset)
            .limit(limit)
        )
        async with self._engine.connect() as conn:
            result = await conn.execute(stmt)
            return [row.object_id for row in result]

    @staticmethod
    def _row_to_tuple(row: Any) -> RelationTuple:
        return RelationTuple(
            id=row.id,
            tenant_id=row.tenant_id,
            object_type=row.object_type,
            object_id=row.object_id,
            relation=row.relation,
            subject_type=row.subject_type,
            subject_id=row.subject_id,
            subject_relation=row.subject_relation,
        )
