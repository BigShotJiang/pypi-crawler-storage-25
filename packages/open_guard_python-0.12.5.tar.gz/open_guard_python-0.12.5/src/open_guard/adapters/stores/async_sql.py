"""Async SQLAlchemy-backed policy and task stores (Phase 7 — T9)."""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker

from open_guard.adapters.stores.sql_models import (
    metadata,
    policies_table,
    tasks_table,
)
from open_guard.domain.entities import (
    ActorType,
    Policy,
    PolicyEffect,
    Task,
    TaskStatus,
)
from open_guard.domain.exceptions import PolicyError, TaskError
from open_guard.domain.ports.async_policy_store import AsyncPolicyStorePort
from open_guard.domain.ports.async_task_store import AsyncTaskStorePort


class AsyncSQLAlchemyPolicyStore(AsyncPolicyStorePort):
    """Async SQLAlchemy-backed policy store.

    Accepts an externally-owned ``AsyncEngine``.
    Call ``create_tables()`` to create tables (idempotent).
    """

    def __init__(self, engine: AsyncEngine) -> None:
        self._engine = engine
        self._session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async def create_tables(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

    async def add(self, policy: Policy) -> Policy:
        action_match: Any = policy.action_match
        async with self._engine.begin() as conn:
            await conn.execute(
                policies_table.insert().values(
                    id=policy.id,
                    tenant_id=policy.tenant_id,
                    evaluator_type=policy.evaluator_type,
                    subject_match=dict(policy.subject_match),
                    action_match=action_match,
                    resource_match=dict(policy.resource_match),
                    conditions=dict(policy.conditions),
                    effect=policy.effect.value,
                    priority=policy.priority,
                )
            )
        return policy

    async def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(policies_table).where(
                    policies_table.c.tenant_id == tenant_id
                )
            )
            return [self._row_to_policy(row) for row in result]

    async def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(policies_table).where(
                    policies_table.c.tenant_id == tenant_id,
                    policies_table.c.evaluator_type == evaluator_type,
                )
            )
            return [self._row_to_policy(row) for row in result]

    async def remove(self, policy_id: str, tenant_id: str) -> None:
        async with self._engine.begin() as conn:
            result = await conn.execute(
                policies_table.delete().where(
                    policies_table.c.id == policy_id,
                    policies_table.c.tenant_id == tenant_id,
                )
            )
            if result.rowcount == 0:
                raise PolicyError(
                    f"Policy '{policy_id}' not found in tenant '{tenant_id}'"
                )

    @staticmethod
    def _row_to_policy(row: Any) -> Policy:
        return Policy(
            id=row.id,
            tenant_id=row.tenant_id,
            evaluator_type=row.evaluator_type,
            subject_match=row.subject_match or {},
            action_match=row.action_match,
            resource_match=row.resource_match or {},
            conditions=row.conditions or {},
            effect=PolicyEffect(row.effect),
            priority=row.priority,
        )


class AsyncSQLAlchemyTaskStore(AsyncTaskStorePort):
    """Async SQLAlchemy-backed task store.

    Accepts an externally-owned ``AsyncEngine``.
    """

    def __init__(self, engine: AsyncEngine) -> None:
        self._engine = engine
        self._session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async def create_tables(self) -> None:
        async with self._engine.begin() as conn:
            await conn.run_sync(metadata.create_all)

    async def add(self, task: Task) -> Task:
        async with self._engine.begin() as conn:
            await conn.execute(
                tasks_table.insert().values(
                    id=task.id,
                    tenant_id=task.tenant_id,
                    actor_id=task.actor_id,
                    actor_type=task.actor_type.value,
                    parent_task_id=task.parent_task_id,
                    status=task.status.value,
                    allowed_actions=task.allowed_actions,
                    allowed_resource_types=task.allowed_resource_types,
                    created_at=task.created_at,
                    activated_at=task.activated_at,
                    expires_at=task.expires_at,
                    completed_at=task.completed_at,
                    metadata_=dict(task.metadata),
                )
            )
        return task

    async def get(self, task_id: str, tenant_id: str) -> Task | None:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(tasks_table).where(
                    tasks_table.c.id == task_id,
                    tasks_table.c.tenant_id == tenant_id,
                )
            )
            row = result.first()
            return self._row_to_task(row) if row else None

    async def update(self, task: Task) -> Task:
        async with self._engine.begin() as conn:
            result = await conn.execute(
                tasks_table.update()
                .where(
                    tasks_table.c.id == task.id,
                    tasks_table.c.tenant_id == task.tenant_id,
                )
                .values(
                    status=task.status.value,
                    activated_at=task.activated_at,
                    expires_at=task.expires_at,
                    completed_at=task.completed_at,
                    metadata_=dict(task.metadata),
                )
            )
            if result.rowcount == 0:
                raise TaskError(
                    f"Task '{task.id}' not found in tenant '{task.tenant_id}'"
                )
        return task

    async def get_active_by_actor(
        self, actor_id: str, tenant_id: str
    ) -> list[Task]:
        async with self._engine.connect() as conn:
            result = await conn.execute(
                select(tasks_table).where(
                    tasks_table.c.tenant_id == tenant_id,
                    tasks_table.c.actor_id == actor_id,
                    tasks_table.c.status == TaskStatus.ACTIVE.value,
                )
            )
            return [self._row_to_task(row) for row in result]

    async def remove(self, task_id: str, tenant_id: str) -> None:
        async with self._engine.begin() as conn:
            result = await conn.execute(
                tasks_table.delete().where(
                    tasks_table.c.id == task_id,
                    tasks_table.c.tenant_id == tenant_id,
                )
            )
            if result.rowcount == 0:
                raise TaskError(
                    f"Task '{task_id}' not found in tenant '{tenant_id}'"
                )

    @staticmethod
    def _row_to_task(row: Any) -> Task:
        return Task(
            id=row.id,
            tenant_id=row.tenant_id,
            actor_id=row.actor_id,
            actor_type=ActorType(row.actor_type),
            parent_task_id=row.parent_task_id,
            status=TaskStatus(row.status),
            allowed_actions=row.allowed_actions,
            allowed_resource_types=row.allowed_resource_types,
            created_at=row.created_at,
            activated_at=row.activated_at,
            expires_at=row.expires_at,
            completed_at=row.completed_at,
            metadata=row.metadata_ or {},
        )
