# src/open_guard/adapters/stores/memory_revocation.py
"""In-memory revocation stream (Phase 6, ENH-010)."""

from __future__ import annotations

import contextlib
import threading
from dataclasses import dataclass
from uuid import uuid4

from open_guard.domain.entities import RevocationEvent
from open_guard.domain.ports.revocation_stream import (
    RevocationCallback,
    RevocationStreamPort,
)


@dataclass
class _Subscription:
    id: str
    tenant_id: str
    callback: RevocationCallback
    subject_id: str | None = None


class InMemoryRevocationStream(RevocationStreamPort):
    """Thread-safe in-memory pub/sub for revocation events."""

    def __init__(self) -> None:
        self._subscriptions: dict[str, _Subscription] = {}
        self._lock = threading.RLock()

    def publish(self, event: RevocationEvent) -> None:
        with self._lock:
            targets = [
                sub for sub in self._subscriptions.values()
                if sub.tenant_id == event.tenant_id
                and (
                    sub.subject_id is None
                    or event.subject_id is None
                    or event.subject_id == sub.subject_id
                )
            ]
        for sub in targets:
            with contextlib.suppress(Exception):
                # at-most-once: continue delivery even if one callback fails
                sub.callback(event)

    def subscribe(
        self,
        tenant_id: str,
        callback: RevocationCallback,
        subject_id: str | None = None,
    ) -> str:
        sub_id = str(uuid4())
        with self._lock:
            self._subscriptions[sub_id] = _Subscription(
                id=sub_id,
                tenant_id=tenant_id,
                callback=callback,
                subject_id=subject_id,
            )
        return sub_id

    def unsubscribe(self, subscription_id: str) -> None:
        with self._lock:
            self._subscriptions.pop(subscription_id, None)
