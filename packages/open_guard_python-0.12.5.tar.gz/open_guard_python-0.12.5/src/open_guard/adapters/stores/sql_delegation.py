"""SQLAlchemy-backed DelegationStore with CAS-safe counters (Phase 5)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Any

import sqlalchemy as sa
from sqlalchemy import Engine, create_engine

from open_guard.adapters.stores.sql_models import delegations_table, metadata
from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
)
from open_guard.domain.exceptions import DelegationNotFoundError, UsageExhaustedError
from open_guard.domain.ports.delegation_store import DelegationStorePort


def _to_aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC)
    return dt


def _row_to_delegation(row: Any) -> Delegation:
    scopes = [DelegationScope(**s) for s in (row.scopes or [])]
    lease_ttl = (
        timedelta(seconds=float(row.lease_ttl_seconds))
        if row.lease_ttl_seconds is not None
        else None
    )
    budget = Decimal(str(row.budget)) if row.budget is not None else None
    budget_remaining = (
        Decimal(str(row.budget_remaining)) if row.budget_remaining is not None else None
    )
    return Delegation(
        id=row.id,
        tenant_id=row.tenant_id,
        from_subject_id=row.from_subject_id,
        from_subject_type=ActorType(row.from_subject_type),
        to_subject_id=row.to_subject_id,
        to_subject_type=ActorType(row.to_subject_type),
        scopes=scopes,
        parent_delegation_id=row.parent_delegation_id,
        max_uses=row.max_uses,
        uses_remaining=row.uses_remaining,
        budget=budget,
        budget_remaining=budget_remaining,
        lease_ttl=lease_ttl,
        last_heartbeat_at=_to_aware(row.last_heartbeat_at),
        renewable_by=row.renewable_by,
        expires_at=_to_aware(row.expires_at),
        re_check_on_use=bool(row.re_check_on_use),
        status=DelegationStatus(row.status),
        approval_request_id=row.approval_request_id,
        request_hash=row.request_hash,
        created_at=_to_aware(row.created_at),
        created_by=row.created_by,
        reason=row.reason,
    )


def _delegation_to_values(d: Delegation) -> dict[str, Any]:
    return {
        "id": d.id,
        "tenant_id": d.tenant_id,
        "from_subject_id": d.from_subject_id,
        "from_subject_type": str(d.from_subject_type),
        "to_subject_id": d.to_subject_id,
        "to_subject_type": str(d.to_subject_type),
        "scopes": [s.model_dump(mode="json") for s in d.scopes],
        "parent_delegation_id": d.parent_delegation_id,
        "max_uses": d.max_uses,
        "uses_remaining": d.uses_remaining,
        "budget": str(d.budget) if d.budget is not None else None,
        "budget_remaining": (
            str(d.budget_remaining) if d.budget_remaining is not None else None
        ),
        "lease_ttl_seconds": (
            d.lease_ttl.total_seconds() if d.lease_ttl is not None else None
        ),
        "last_heartbeat_at": d.last_heartbeat_at,
        "renewable_by": d.renewable_by,
        "expires_at": d.expires_at,
        "re_check_on_use": d.re_check_on_use,
        "status": str(d.status),
        "approval_request_id": d.approval_request_id,
        "request_hash": d.request_hash,
        "created_at": d.created_at,
        "created_by": d.created_by,
        "reason": d.reason,
    }


class SQLAlchemyDelegationStore(DelegationStorePort):
    """SQLAlchemy-backed Delegation store.

    Accepts an externally-owned Engine. Use ``from_url()`` for convenience.
    Call ``create_tables()`` to create tables (idempotent).

    CAS-safe counter decrement uses ``UPDATE ... WHERE uses_remaining >= :amount``
    and checks the row-count to detect lost races — portable across SQLite/PostgreSQL.
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    @classmethod
    def from_url(cls, url: str, **kwargs: Any) -> SQLAlchemyDelegationStore:
        return cls(create_engine(url, **kwargs))

    def create_tables(self) -> None:
        metadata.create_all(self._engine)

    # ------------------------------------------------------------------
    # Basic CRUD
    # ------------------------------------------------------------------

    def create(self, delegation: Delegation) -> Delegation:
        with self._engine.begin() as conn:
            conn.execute(
                delegations_table.insert().values(**_delegation_to_values(delegation))
            )
        return delegation

    def get(self, delegation_id: str, tenant_id: str) -> Delegation | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                sa.select(delegations_table).where(
                    sa.and_(
                        delegations_table.c.id == delegation_id,
                        delegations_table.c.tenant_id == tenant_id,
                    )
                )
            ).fetchone()
        return _row_to_delegation(row) if row else None

    def find_by_hash(self, request_hash: str, tenant_id: str) -> Delegation | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                sa.select(delegations_table).where(
                    sa.and_(
                        delegations_table.c.request_hash == request_hash,
                        delegations_table.c.tenant_id == tenant_id,
                    )
                )
            ).fetchone()
        return _row_to_delegation(row) if row else None

    def list_active_for_grantee(
        self,
        to_subject_id: str,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[Delegation]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                sa.select(delegations_table).where(
                    sa.and_(
                        delegations_table.c.to_subject_id == to_subject_id,
                        delegations_table.c.tenant_id == tenant_id,
                        delegations_table.c.status == str(DelegationStatus.ACTIVE),
                    )
                )
            ).fetchall()
        delegations = [_row_to_delegation(r) for r in rows]
        if resource_type is not None:
            delegations = [
                d
                for d in delegations
                if any(s.resource_type == resource_type for s in d.scopes)
            ]
        return delegations

    def list_descendants(
        self, parent_delegation_id: str, tenant_id: str
    ) -> list[Delegation]:
        with self._engine.connect() as conn:
            return self._collect_descendants(conn, parent_delegation_id, tenant_id)

    def _collect_descendants(
        self, conn: Any, parent_id: str, tenant_id: str
    ) -> list[Delegation]:
        rows = conn.execute(
            sa.select(delegations_table).where(
                sa.and_(
                    delegations_table.c.parent_delegation_id == parent_id,
                    delegations_table.c.tenant_id == tenant_id,
                )
            )
        ).fetchall()
        result = []
        for row in rows:
            d = _row_to_delegation(row)
            result.append(d)
            result.extend(self._collect_descendants(conn, d.id, tenant_id))
        return result

    def update_status(
        self, delegation_id: str, tenant_id: str, status: DelegationStatus
    ) -> Delegation:
        with self._engine.begin() as conn:
            result = conn.execute(
                sa.update(delegations_table)
                .where(
                    sa.and_(
                        delegations_table.c.id == delegation_id,
                        delegations_table.c.tenant_id == tenant_id,
                    )
                )
                .values(status=str(status))
            )
            if result.rowcount == 0:
                raise DelegationNotFoundError(
                    f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
                )
        d = self.get(delegation_id, tenant_id)
        assert d is not None
        return d

    # ------------------------------------------------------------------
    # CAS-safe counter operations
    # ------------------------------------------------------------------

    def decrement_uses(
        self, delegation_id: str, tenant_id: str, amount: int
    ) -> Delegation:
        with self._engine.begin() as conn:
            # CAS: only update rows where uses_remaining >= amount
            exhausted_status = str(DelegationStatus.EXHAUSTED)
            active_status = str(DelegationStatus.ACTIVE)
            result = conn.execute(
                sa.text(
                    """
                    UPDATE open_guard_delegations
                    SET uses_remaining = uses_remaining - :amount,
                        status = CASE
                            WHEN uses_remaining - :amount <= 0
                                 AND (budget_remaining IS NULL OR budget_remaining <= 0)
                            THEN :exhausted
                            ELSE status
                        END
                    WHERE id = :id
                      AND tenant_id = :tenant
                      AND uses_remaining >= :amount
                    """
                ),
                {
                    "amount": amount,
                    "id": delegation_id,
                    "tenant": tenant_id,
                    "exhausted": exhausted_status,
                    "active": active_status,
                },
            )
            if result.rowcount == 0:
                existing = self.get(delegation_id, tenant_id)
                if existing is None:
                    raise DelegationNotFoundError(
                        f"Delegation {delegation_id!r} not found "
                        f"in tenant {tenant_id!r}"
                    )
                raise UsageExhaustedError(
                    f"Delegation {delegation_id!r} has insufficient uses_remaining"
                )
        d = self.get(delegation_id, tenant_id)
        assert d is not None
        return d

    def decrement_budget(
        self, delegation_id: str, tenant_id: str, cost: Decimal
    ) -> Delegation:
        with self._engine.begin() as conn:
            exhausted_status = str(DelegationStatus.EXHAUSTED)
            result = conn.execute(
                sa.text(
                    """
                    UPDATE open_guard_delegations
                    SET budget_remaining = budget_remaining - :cost,
                        status = CASE
                            WHEN budget_remaining - :cost <= 0
                                 AND (uses_remaining IS NULL OR uses_remaining <= 0)
                            THEN :exhausted
                            ELSE status
                        END
                    WHERE id = :id
                      AND tenant_id = :tenant
                      AND budget_remaining >= :cost
                    """
                ),
                {
                    "cost": str(cost),
                    "id": delegation_id,
                    "tenant": tenant_id,
                    "exhausted": exhausted_status,
                },
            )
            if result.rowcount == 0:
                existing = self.get(delegation_id, tenant_id)
                if existing is None:
                    raise DelegationNotFoundError(
                        f"Delegation {delegation_id!r} not found "
                        f"in tenant {tenant_id!r}"
                    )
                raise UsageExhaustedError(
                    f"Delegation {delegation_id!r} has insufficient budget_remaining"
                )
        d = self.get(delegation_id, tenant_id)
        assert d is not None
        return d

    # ------------------------------------------------------------------
    # Lease
    # ------------------------------------------------------------------

    def touch_heartbeat(
        self, delegation_id: str, tenant_id: str, now: datetime
    ) -> Delegation:
        with self._engine.begin() as conn:
            result = conn.execute(
                sa.update(delegations_table)
                .where(
                    sa.and_(
                        delegations_table.c.id == delegation_id,
                        delegations_table.c.tenant_id == tenant_id,
                    )
                )
                .values(last_heartbeat_at=now)
            )
            if result.rowcount == 0:
                raise DelegationNotFoundError(
                    f"Delegation {delegation_id!r} not found in tenant {tenant_id!r}"
                )
        d = self.get(delegation_id, tenant_id)
        assert d is not None
        return d

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition stale delegations to EXPIRED."""
        active_statuses = [
            str(DelegationStatus.ACTIVE),
            str(DelegationStatus.PENDING_APPROVAL),
        ]
        with self._engine.connect() as conn:
            rows = conn.execute(
                sa.select(delegations_table).where(
                    sa.and_(
                        delegations_table.c.tenant_id == tenant_id,
                        delegations_table.c.status.in_(active_statuses),
                    )
                )
            ).fetchall()

        to_expire = []
        for row in rows:
            d = _row_to_delegation(row)
            if _is_expired(d, now):
                to_expire.append(d.id)

        if not to_expire:
            return 0

        with self._engine.begin() as conn:
            result = conn.execute(
                sa.update(delegations_table)
                .where(
                    sa.and_(
                        delegations_table.c.tenant_id == tenant_id,
                        delegations_table.c.id.in_(to_expire),
                    )
                )
                .values(status=str(DelegationStatus.EXPIRED))
            )
            return result.rowcount


def _is_expired(d: Delegation, now: datetime) -> bool:
    if d.expires_at is not None and now >= d.expires_at:
        return True
    return (
        d.lease_ttl is not None
        and d.last_heartbeat_at is not None
        and now >= d.last_heartbeat_at + d.lease_ttl
    )
