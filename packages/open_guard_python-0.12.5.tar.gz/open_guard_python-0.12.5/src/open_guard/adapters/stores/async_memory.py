"""Async in-memory store implementations (Phase 7 — T8).

Thin wrappers around the existing sync memory stores. Each async store
delegates to its sync counterpart (no real I/O, so the async is purely
for port contract compliance).
"""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import (
    ApprovalRequest,
    Delegation,
    DelegationStatus,
    Policy,
    RelationTuple,
    Session,
    SessionStatus,
    Task,
)
from open_guard.domain.ports.async_approval_store import AsyncApprovalStorePort
from open_guard.domain.ports.async_delegation_store import AsyncDelegationStorePort
from open_guard.domain.ports.async_policy_store import AsyncPolicyStorePort
from open_guard.domain.ports.async_relationship_store import AsyncRelationshipStorePort
from open_guard.domain.ports.async_session_store import AsyncSessionStorePort
from open_guard.domain.ports.async_task_store import AsyncTaskStorePort

# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------


class AsyncInMemoryPolicyStore(AsyncPolicyStorePort):
    """Async wrapper around InMemoryPolicyStore."""

    def __init__(self) -> None:
        self._sync = InMemoryPolicyStore()

    @property
    def sync_store(self) -> InMemoryPolicyStore:
        """Public accessor for the underlying sync store."""
        return self._sync

    async def add(self, policy: Policy) -> Policy:
        return self._sync.add(policy)

    async def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        return self._sync.get_by_tenant(tenant_id)

    async def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        return self._sync.get_by_tenant_and_type(tenant_id, evaluator_type)

    async def remove(self, policy_id: str, tenant_id: str) -> None:
        self._sync.remove(policy_id, tenant_id)


# ---------------------------------------------------------------------------
# Relationship
# ---------------------------------------------------------------------------


class AsyncInMemoryRelationshipStore(AsyncRelationshipStorePort):
    """Async wrapper around InMemoryRelationshipStore."""

    def __init__(self) -> None:
        self._sync = InMemoryRelationshipStore()

    @property
    def sync_store(self) -> InMemoryRelationshipStore:
        """Public accessor for the underlying sync store."""
        return self._sync

    async def write_tuple(self, relation_tuple: RelationTuple) -> RelationTuple:
        return self._sync.write_tuple(relation_tuple)

    async def delete_tuple(self, tuple_id: str, tenant_id: str) -> None:
        self._sync.delete_tuple(tuple_id, tenant_id)

    async def read_tuples(
        self,
        tenant_id: str,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        return self._sync.read_tuples(
            tenant_id,
            object_type=object_type,
            object_id=object_id,
            relation=relation,
            subject_type=subject_type,
            subject_id=subject_id,
        )

    async def tuple_exists(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        relation: str,
        subject_type: str,
        subject_id: str,
        subject_relation: str | None = None,
    ) -> bool:
        return self._sync.tuple_exists(
            tenant_id,
            object_type,
            object_id,
            relation,
            subject_type,
            subject_id,
            subject_relation=subject_relation,
        )

    async def find_object_ids_for_subject(
        self,
        subject_id: str,
        subject_type: str,
        object_type: str,
        tenant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> list[str]:
        return self._sync.find_object_ids_for_subject(
            subject_id, subject_type, object_type, tenant_id, offset=offset, limit=limit
        )


# ---------------------------------------------------------------------------
# Delegation
# ---------------------------------------------------------------------------


class AsyncInMemoryDelegationStore(AsyncDelegationStorePort):
    """Async wrapper around InMemoryDelegationStore."""

    def __init__(self) -> None:
        self._sync = InMemoryDelegationStore()

    @property
    def sync_store(self) -> InMemoryDelegationStore:
        """Public accessor for the underlying sync store."""
        return self._sync

    async def create(self, delegation: Delegation) -> Delegation:
        return self._sync.create(delegation)

    async def get(self, delegation_id: str, tenant_id: str) -> Delegation | None:
        return self._sync.get(delegation_id, tenant_id)

    async def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> Delegation | None:
        return self._sync.find_by_hash(request_hash, tenant_id)

    async def list_active_for_grantee(
        self,
        to_subject_id: str,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[Delegation]:
        return self._sync.list_active_for_grantee(
            to_subject_id, tenant_id, resource_type=resource_type
        )

    async def list_descendants(
        self, parent_delegation_id: str, tenant_id: str
    ) -> list[Delegation]:
        return self._sync.list_descendants(parent_delegation_id, tenant_id)

    async def update_status(
        self, delegation_id: str, tenant_id: str, status: DelegationStatus
    ) -> Delegation:
        return self._sync.update_status(delegation_id, tenant_id, status)

    async def decrement_uses(
        self, delegation_id: str, tenant_id: str, amount: int
    ) -> Delegation:
        return self._sync.decrement_uses(delegation_id, tenant_id, amount)

    async def decrement_budget(
        self, delegation_id: str, tenant_id: str, cost: Decimal
    ) -> Delegation:
        return self._sync.decrement_budget(delegation_id, tenant_id, cost)

    async def touch_heartbeat(
        self, delegation_id: str, tenant_id: str, now: datetime
    ) -> Delegation:
        return self._sync.touch_heartbeat(delegation_id, tenant_id, now)

    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        return self._sync.expire_stale(tenant_id, now)


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


class AsyncInMemorySessionStore(AsyncSessionStorePort):
    """Async wrapper around InMemorySessionStore."""

    def __init__(self) -> None:
        self._sync = InMemorySessionStore()

    @property
    def sync_store(self) -> InMemorySessionStore:
        """Public accessor for the underlying sync store."""
        return self._sync

    async def create(self, session: Session) -> Session:
        return self._sync.create(session)

    async def get(self, session_id: str, tenant_id: str) -> Session | None:
        return self._sync.get(session_id, tenant_id)

    async def get_active_for_subject(
        self, subject_id: str, tenant_id: str
    ) -> list[Session]:
        return self._sync.get_active_for_subject(subject_id, tenant_id)

    async def update_status(
        self,
        session_id: str,
        tenant_id: str,
        status: SessionStatus,
        deactivated_at: datetime | None = None,
    ) -> Session:
        return self._sync.update_status(
            session_id, tenant_id, status, deactivated_at=deactivated_at
        )

    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        return self._sync.expire_stale(tenant_id, now)


# ---------------------------------------------------------------------------
# Approval
# ---------------------------------------------------------------------------


class AsyncInMemoryApprovalStore(AsyncApprovalStorePort):
    """Async wrapper around InMemoryApprovalStore."""

    def __init__(self) -> None:
        self._sync = InMemoryApprovalStore()

    @property
    def sync_store(self) -> InMemoryApprovalStore:
        """Public accessor for the underlying sync store."""
        return self._sync

    async def create(self, request: ApprovalRequest) -> ApprovalRequest:
        return self._sync.create(request)

    async def get(
        self, request_id: str, tenant_id: str
    ) -> ApprovalRequest | None:
        return self._sync.get(request_id, tenant_id)

    async def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        return self._sync.find_by_hash(request_hash, tenant_id)

    async def find_latest_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        return self._sync.find_latest_by_hash(request_hash, tenant_id)

    async def update(self, request: ApprovalRequest) -> ApprovalRequest:
        return self._sync.update(request)

    async def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        return self._sync.list_pending(tenant_id)

    async def expire_stale(self, tenant_id: str, now: datetime) -> int:
        return self._sync.expire_stale(tenant_id, now)


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------


class AsyncInMemoryTaskStore(AsyncTaskStorePort):
    """Async wrapper around InMemoryTaskStore."""

    def __init__(self) -> None:
        self._sync = InMemoryTaskStore()

    @property
    def sync_store(self) -> InMemoryTaskStore:
        """Public accessor for the underlying sync store."""
        return self._sync

    async def add(self, task: Task) -> Task:
        return self._sync.add(task)

    async def get(self, task_id: str, tenant_id: str) -> Task | None:
        return self._sync.get(task_id, tenant_id)

    async def update(self, task: Task) -> Task:
        return self._sync.update(task)

    async def get_active_by_actor(
        self, actor_id: str, tenant_id: str
    ) -> list[Task]:
        return self._sync.get_active_by_actor(actor_id, tenant_id)

    async def remove(self, task_id: str, tenant_id: str) -> None:
        self._sync.remove(task_id, tenant_id)
