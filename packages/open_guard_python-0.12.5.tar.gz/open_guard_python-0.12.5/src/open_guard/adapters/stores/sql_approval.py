"""SQLAlchemy-backed ApprovalStore (Phase 3, FEAT-007)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import Engine, and_, create_engine, select, update

from open_guard.adapters.stores.sql_models import (
    approval_requests_table,
    metadata,
)
from open_guard.domain.entities import (
    ApprovalDecision,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
)
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.ports.approval_store import ApprovalStorePort


class SQLAlchemyApprovalStore(ApprovalStorePort):
    """SQLAlchemy-backed ApprovalRequest store.

    Accepts an externally-owned Engine. Use ``from_url()`` for convenience.
    Call ``create_tables()`` to create tables (idempotent).

    Portable across SQLite / PostgreSQL / MySQL via JSON columns for
    `requirement` and `approvers_received`. Application-level check against
    duplicate PENDING requests for the same (tenant, request_hash) — SQLite's
    NULL-is-distinct behavior on unique constraints means we cannot rely on a
    DB-level unique index for "one PENDING per hash."
    """

    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    @classmethod
    def from_url(cls, url: str, **kwargs: Any) -> SQLAlchemyApprovalStore:
        engine = create_engine(url, **kwargs)
        return cls(engine)

    def create_tables(self) -> None:
        metadata.create_all(self._engine)

    def create(self, request: ApprovalRequest) -> ApprovalRequest:
        # Application-level backstop: reject if a PENDING exists for this hash
        existing = self.find_by_hash(request.request_hash, request.tenant_id)
        if existing is not None:
            raise ApprovalError(
                f"Pending approval already exists for hash "
                f"{request.request_hash[:12]}... in tenant {request.tenant_id}"
            )
        with self._engine.begin() as conn:
            conn.execute(
                approval_requests_table.insert().values(
                    id=request.id,
                    tenant_id=request.tenant_id,
                    request_hash=request.request_hash,
                    subject_id=request.subject_id,
                    action_name=request.action_name,
                    resource_id=request.resource_id,
                    resource_type=request.resource_type,
                    status=request.status.value,
                    requirement=_requirement_to_json(request.requirement),
                    approvers_received=[
                        _decision_to_json(d) for d in request.approvers_received
                    ],
                    created_at=request.created_at,
                    expires_at=request.expires_at,
                    resolved_at=request.resolved_at,
                    reason=request.reason,
                )
            )
        return request

    def get(self, request_id: str, tenant_id: str) -> ApprovalRequest | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(approval_requests_table).where(
                    and_(
                        approval_requests_table.c.id == request_id,
                        approval_requests_table.c.tenant_id == tenant_id,
                    )
                )
            ).first()
        if row is None:
            return None
        return _row_to_request(row._mapping)

    def find_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(approval_requests_table).where(
                    and_(
                        approval_requests_table.c.tenant_id == tenant_id,
                        approval_requests_table.c.request_hash == request_hash,
                        approval_requests_table.c.status
                        == ApprovalStatus.PENDING.value,
                    )
                )
            ).first()
        if row is None:
            return None
        return _row_to_request(row._mapping)

    def find_latest_by_hash(
        self, request_hash: str, tenant_id: str
    ) -> ApprovalRequest | None:
        with self._engine.connect() as conn:
            row = conn.execute(
                select(approval_requests_table)
                .where(
                    and_(
                        approval_requests_table.c.tenant_id == tenant_id,
                        approval_requests_table.c.request_hash == request_hash,
                    )
                )
                .order_by(approval_requests_table.c.created_at.desc())
                .limit(1)
            ).first()
        if row is None:
            return None
        return _row_to_request(row._mapping)

    def update(self, request: ApprovalRequest) -> ApprovalRequest:
        with self._engine.begin() as conn:
            result = conn.execute(
                update(approval_requests_table)
                .where(
                    and_(
                        approval_requests_table.c.id == request.id,
                        approval_requests_table.c.tenant_id == request.tenant_id,
                    )
                )
                .values(
                    status=request.status.value,
                    approvers_received=[
                        _decision_to_json(d) for d in request.approvers_received
                    ],
                    resolved_at=request.resolved_at,
                    reason=request.reason,
                )
            )
            if result.rowcount == 0:
                raise ApprovalError(
                    f"ApprovalRequest {request.id} not found in tenant "
                    f"{request.tenant_id}"
                )
        return request

    def list_pending(self, tenant_id: str) -> list[ApprovalRequest]:
        with self._engine.connect() as conn:
            rows = conn.execute(
                select(approval_requests_table).where(
                    and_(
                        approval_requests_table.c.tenant_id == tenant_id,
                        approval_requests_table.c.status
                        == ApprovalStatus.PENDING.value,
                    )
                )
            ).all()
        return [_row_to_request(r._mapping) for r in rows]

    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        with self._engine.begin() as conn:
            result = conn.execute(
                update(approval_requests_table)
                .where(
                    and_(
                        approval_requests_table.c.tenant_id == tenant_id,
                        approval_requests_table.c.status
                        == ApprovalStatus.PENDING.value,
                        approval_requests_table.c.expires_at.is_not(None),
                        approval_requests_table.c.expires_at <= now,
                    )
                )
                .values(
                    status=ApprovalStatus.EXPIRED.value,
                    resolved_at=now,
                    reason="approval expired",
                )
            )
            return int(result.rowcount)


def _requirement_to_json(req: ApprovalRequirement) -> dict[str, Any]:
    return {
        "approvers": list(req.approvers),
        "quorum": req.quorum,
        "ttl_seconds": req.ttl.total_seconds() if req.ttl is not None else None,
        "channel": req.channel,
    }


def _requirement_from_json(data: dict[str, Any]) -> ApprovalRequirement:
    from datetime import timedelta

    ttl_seconds = data.get("ttl_seconds")
    ttl = timedelta(seconds=ttl_seconds) if ttl_seconds is not None else None
    return ApprovalRequirement(
        approvers=data["approvers"],
        quorum=data.get("quorum", "any"),
        ttl=ttl,
        channel=data.get("channel"),
    )


def _decision_to_json(d: ApprovalDecision) -> dict[str, Any]:
    return {
        "approver": d.approver,
        "decision": d.decision,
        "reason": d.reason,
        "at": d.at.isoformat(),
    }


def _decision_from_json(data: dict[str, Any]) -> ApprovalDecision:
    return ApprovalDecision(
        approver=data["approver"],
        decision=data["decision"],
        reason=data.get("reason", ""),
        at=datetime.fromisoformat(data["at"]),
    )


def _row_to_request(row: Any) -> ApprovalRequest:
    return ApprovalRequest(
        id=row["id"],
        tenant_id=row["tenant_id"],
        request_hash=row["request_hash"],
        subject_id=row["subject_id"],
        action_name=row["action_name"],
        resource_id=row["resource_id"],
        resource_type=row["resource_type"],
        status=ApprovalStatus(row["status"]),
        requirement=_requirement_from_json(row["requirement"]),
        approvers_received=[
            _decision_from_json(d) for d in row["approvers_received"]
        ],
        created_at=row["created_at"],
        expires_at=row["expires_at"],
        resolved_at=row["resolved_at"],
        reason=row["reason"] or "",
    )
