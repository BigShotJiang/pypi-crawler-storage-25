"""Shared SDK base client + auth helpers (Phase 10)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from open_guard.client.exceptions import (
    AuthenticationError,
    AuthorizationServiceError,
    NotFoundError,
    OpenGuardError,
    RateLimitedError,
    ServerError,
    ValidationError,
)
from open_guard.client.retry import RetryPolicy


@dataclass(frozen=True)
class ClientAuth:
    """Authentication credentials for a client request.

    Construct via the :func:`ApiKey` or :func:`BearerToken` helpers.
    """

    header_name: str
    header_value: str


def ApiKey(key: str) -> ClientAuth:  # noqa: N802 — factory mimics class form
    """Authenticate via an open-guard API key.

    Sets ``Authorization: ApiKey <key>``.
    """
    return ClientAuth("Authorization", f"ApiKey {key}")


def BearerToken(token: str) -> ClientAuth:  # noqa: N802 — factory mimics class form
    """Authenticate via a JWT Bearer token (validated by ShieldAuth)."""
    return ClientAuth("Authorization", f"Bearer {token}")


_STATUS_TO_EXC: dict[int, type[OpenGuardError]] = {
    401: AuthenticationError,
    403: AuthorizationServiceError,
    404: NotFoundError,
    422: ValidationError,
    429: RateLimitedError,
}


class _BaseClient:
    """URL builder, default headers, and error mapping for the SDK clients."""

    def __init__(
        self,
        base_url: str,
        *,
        auth: ClientAuth,
        prefix: str = "/v1",
        retry: RetryPolicy | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._prefix = "/" + prefix.strip("/") if prefix else ""
        self._auth = auth
        self._retry = retry or RetryPolicy()
        self._headers: dict[str, str] = {auth.header_name: auth.header_value}

    @property
    def retry(self) -> RetryPolicy:
        return self._retry

    @property
    def headers(self) -> dict[str, str]:
        return dict(self._headers)

    def _url(self, path: str) -> str:
        if not path.startswith("/"):
            path = "/" + path
        return f"{self._base_url}{self._prefix}{path}"

    def _map_error(self, status: int, body: Any) -> OpenGuardError:
        envelope = (
            (body or {}).get("error") if isinstance(body, dict) else None
        ) or {}
        code = envelope.get("code", f"http_{status}")
        message = envelope.get("message") or f"HTTP {status}"
        details = envelope.get("details")
        if status >= 500:
            cls: type[OpenGuardError] = ServerError
        else:
            cls = _STATUS_TO_EXC.get(status, OpenGuardError)
        return cls(
            message,
            code=code,
            status_code=status,
            details=details,
        )
