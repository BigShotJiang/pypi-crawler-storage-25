"""SDK exception hierarchy (Phase 10).

All exceptions inherit from :class:`OpenGuardError`. Concrete subclasses
map 1:1 to HTTP status codes returned by service mode:

==============  ========  =========================
HTTP            Exception                        Code (default)
401             AuthenticationError              authentication_failed
403             AuthorizationServiceError        forbidden
404             NotFoundError                    not_found
422             ValidationError                  validation_error
429             RateLimitedError                 rate_limited
5xx             ServerError                      internal_error
N/A             TransportError                   transport_error
==============  ========  =========================

Exceptions carry the original ``code``, ``status_code``, and ``details``
fields from the service envelope so callers can branch on the typed
machine-readable code.
"""

from __future__ import annotations

from typing import Any


class OpenGuardError(Exception):
    """Base class for every SDK error."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "unknown",
        status_code: int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.details = details


class AuthenticationError(OpenGuardError): ...


class AuthorizationServiceError(OpenGuardError): ...


class NotFoundError(OpenGuardError): ...


class ValidationError(OpenGuardError): ...


class RateLimitedError(OpenGuardError): ...


class ServerError(OpenGuardError): ...


class TransportError(OpenGuardError): ...
