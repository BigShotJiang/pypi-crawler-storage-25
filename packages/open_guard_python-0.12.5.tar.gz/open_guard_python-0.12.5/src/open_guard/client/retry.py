"""SDK retry policy (Phase 10).

Defaults: 3 attempts, exponential backoff (100ms → 400ms → 1.6s, capped
at 2s), retry on 502/503/504 + connection/timeout errors. Retries apply
to idempotent operations only — non-idempotent calls
(``authorize_and_consume``) make exactly one attempt unless
``idempotent_only`` is disabled.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class RetryPolicy:
    attempts: int = 3
    base_delay: float = 0.1
    max_delay: float = 2.0
    retry_on_status: frozenset[int] = field(
        default_factory=lambda: frozenset({502, 503, 504})
    )
    retry_on_connection_error: bool = True
    idempotent_only: bool = True
