"""Sync OpenGuardClient (Phase 10)."""

from __future__ import annotations

import random
import time
from types import TracebackType
from typing import Any

import httpx

from open_guard.client.base import ClientAuth, _BaseClient
from open_guard.client.exceptions import (
    ServerError,
    TransportError,
)
from open_guard.client.namespaces.admin import AdminAPI
from open_guard.client.namespaces.decisions import DecisionsAPI
from open_guard.client.retry import RetryPolicy


class OpenGuardClient(_BaseClient):
    """Synchronous client for the open-guard service.

    Usage::

        from open_guard.client import OpenGuardClient, ApiKey

        with OpenGuardClient("http://localhost:8000", auth=ApiKey("og_...")) as c:
            decision = c.decisions.authorize(
                subject={"id": "alice"},
                action="read",
                resource={"id": "doc-1", "resource_type": "document"},
            )
    """

    def __init__(
        self,
        base_url: str,
        *,
        auth: ClientAuth,
        prefix: str = "/v1",
        retry: RetryPolicy | None = None,
        timeout: float = 5.0,
        transport: httpx.BaseTransport | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        super().__init__(base_url, auth=auth, prefix=prefix, retry=retry)
        if http_client is not None:
            self._http = http_client
            self._http.headers.update(self._headers)
        else:
            self._http = httpx.Client(
                timeout=timeout,
                headers=self._headers,
                transport=transport,
            )
        self.decisions = DecisionsAPI(self)
        self.admin = AdminAPI(self)

    def __enter__(self) -> OpenGuardClient:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def close(self) -> None:
        self._http.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any | None = None,
        params: Any | None = None,
        idempotent: bool = True,
    ) -> Any:
        url = self._url(path)
        attempts = (
            self._retry.attempts
            if (idempotent or not self._retry.idempotent_only)
            else 1
        )
        last_exc: Exception | None = None
        for i in range(attempts):
            try:
                resp = self._http.request(
                    method, url, json=json, params=params
                )
            except httpx.HTTPError as exc:
                last_exc = TransportError(
                    str(exc), code="transport_error"
                )
                if not self._retry.retry_on_connection_error or i == attempts - 1:
                    raise last_exc from exc
            else:
                if resp.status_code < 400:
                    if resp.status_code == 204 or not resp.content:
                        return None
                    return resp.json()
                retryable = (
                    resp.status_code in self._retry.retry_on_status
                    and i < attempts - 1
                )
                if not retryable:
                    body: Any = None
                    if resp.content:
                        try:
                            body = resp.json()
                        except Exception:
                            body = None
                    raise self._map_error(resp.status_code, body)
            delay = min(self._retry.base_delay * (2**i), self._retry.max_delay)
            time.sleep(delay + random.uniform(0, delay * 0.1))
        if last_exc is not None:
            raise last_exc
        raise ServerError("retries exhausted", code="retries_exhausted")
