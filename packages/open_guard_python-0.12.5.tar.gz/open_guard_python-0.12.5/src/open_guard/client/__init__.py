"""open-guard Python SDK (Phase 10).

Install: ``pip install open-guard-python[client]``.

Public API:

- :class:`OpenGuardClient` — sync client
- :class:`AsyncOpenGuardClient` — async client
- :func:`ApiKey`, :func:`BearerToken` — credential helpers
- :class:`RetryPolicy` — retry configuration
- :class:`OpenGuardError` and subclasses — typed exception hierarchy
"""

from __future__ import annotations

from open_guard.client.async_client import AsyncOpenGuardClient
from open_guard.client.base import ApiKey, BearerToken, ClientAuth
from open_guard.client.exceptions import (
    AuthenticationError,
    AuthorizationServiceError,
    NotFoundError,
    OpenGuardError,
    RateLimitedError,
    ServerError,
    TransportError,
    ValidationError,
)
from open_guard.client.retry import RetryPolicy
from open_guard.client.sync_client import OpenGuardClient

__all__ = [
    "ApiKey",
    "AsyncOpenGuardClient",
    "AuthenticationError",
    "AuthorizationServiceError",
    "BearerToken",
    "ClientAuth",
    "NotFoundError",
    "OpenGuardClient",
    "OpenGuardError",
    "RateLimitedError",
    "RetryPolicy",
    "ServerError",
    "TransportError",
    "ValidationError",
]
