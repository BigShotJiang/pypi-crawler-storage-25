"""Admin namespaces (Phase 10) — CRUD over the AdminRouter wire surface."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover
    from open_guard.client.async_client import AsyncOpenGuardClient
    from open_guard.client.sync_client import OpenGuardClient


# ---------------------------------------------------------------------------
# Sync namespaces
# ---------------------------------------------------------------------------


class PoliciesAPI:
    def __init__(self, client: OpenGuardClient) -> None:
        self._c = client

    def create(
        self,
        *,
        tenant_id: str,
        evaluator_type: str,
        subject_match: dict[str, Any] | None = None,
        action_match: str | list[str] = "*",
        resource_match: dict[str, Any] | None = None,
        conditions: dict[str, Any] | None = None,
        effect: str = "allow",
        priority: int = 0,
    ) -> dict[str, Any]:
        body = {
            "tenant_id": tenant_id,
            "evaluator_type": evaluator_type,
            "subject_match": subject_match or {},
            "action_match": action_match,
            "resource_match": resource_match or {},
            "conditions": conditions or {},
            "effect": effect,
            "priority": priority,
        }
        return self._c._request("POST", "/admin/policies", json=body)

    def list(
        self, *, tenant_id: str, evaluator_type: str | None = None
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"tenant_id": tenant_id}
        if evaluator_type is not None:
            params["evaluator_type"] = evaluator_type
        return self._c._request("GET", "/admin/policies", params=params)

    def get(self, policy_id: str, *, tenant_id: str) -> dict[str, Any]:
        return self._c._request(
            "GET",
            f"/admin/policies/{policy_id}",
            params={"tenant_id": tenant_id},
        )

    def delete(self, policy_id: str, *, tenant_id: str) -> None:
        self._c._request(
            "DELETE",
            f"/admin/policies/{policy_id}",
            params={"tenant_id": tenant_id},
        )


class RolesAPI:
    def __init__(self, client: OpenGuardClient) -> None:
        self._c = client

    def assign(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        role: str,
        resource_type: str | None = None,
        resource_match: dict[str, Any] | None = None,
        actions: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "role": role,
        }
        if resource_type is not None:
            body["resource_type"] = resource_type
        if resource_match is not None:
            body["resource_match"] = resource_match
        if actions is not None:
            body["actions"] = actions
        return self._c._request("POST", "/admin/roles", json=body)


class RelationshipsAPI:
    def __init__(self, client: OpenGuardClient) -> None:
        self._c = client

    def add(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        relation: str,
        object_type: str,
        object_id: str,
        subject_type: str = "user",
        subject_relation: str | None = None,
    ) -> dict[str, Any]:
        body = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "subject_type": subject_type,
            "relation": relation,
            "object_type": object_type,
            "object_id": object_id,
            "subject_relation": subject_relation,
        }
        return self._c._request("POST", "/admin/relationships", json=body)

    def list(
        self,
        *,
        tenant_id: str,
        object_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"tenant_id": tenant_id}
        if object_type is not None:
            params["object_type"] = object_type
        if subject_id is not None:
            params["subject_id"] = subject_id
        return self._c._request(
            "GET", "/admin/relationships", params=params
        )

    def check(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        relation: str,
        object_type: str,
        object_id: str,
        subject_type: str = "user",
    ) -> bool:
        body = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "subject_type": subject_type,
            "relation": relation,
            "object_type": object_type,
            "object_id": object_id,
        }
        result = self._c._request(
            "POST", "/admin/relationships/check", json=body
        )
        return bool(result.get("exists", False))

    def delete(self, tuple_id: str, *, tenant_id: str) -> None:
        self._c._request(
            "DELETE",
            f"/admin/relationships/{tuple_id}",
            params={"tenant_id": tenant_id},
        )


class DelegationsAPI:
    def __init__(self, client: OpenGuardClient) -> None:
        self._c = client

    def create(
        self,
        *,
        tenant_id: str,
        from_subject_id: str,
        to_subject_id: str,
        scopes: list[dict[str, Any]],
        from_subject_type: str = "user",
        to_subject_type: str = "user",
        max_uses: int | None = None,
        budget: str | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "from_subject_id": from_subject_id,
            "to_subject_id": to_subject_id,
            "scopes": scopes,
            "from_subject_type": from_subject_type,
            "to_subject_type": to_subject_type,
        }
        if max_uses is not None:
            body["max_uses"] = max_uses
        if budget is not None:
            body["budget"] = budget
        if expires_at is not None:
            body["expires_at"] = expires_at
        return self._c._request("POST", "/admin/delegations", json=body)

    def list(
        self, *, tenant_id: str, subject_id: str
    ) -> list[dict[str, Any]]:
        return self._c._request(
            "GET",
            "/admin/delegations",
            params={"tenant_id": tenant_id, "subject_id": subject_id},
        )

    def revoke(self, delegation_id: str, *, tenant_id: str) -> None:
        self._c._request(
            "DELETE",
            f"/admin/delegations/{delegation_id}",
            params={"tenant_id": tenant_id},
        )


class SessionsAPI:
    def __init__(self, client: OpenGuardClient) -> None:
        self._c = client

    def create(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        activated_roles: list[str],
        expires_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "activated_roles": activated_roles,
        }
        if expires_at is not None:
            body["expires_at"] = expires_at
        if metadata is not None:
            body["metadata"] = metadata
        return self._c._request("POST", "/admin/sessions", json=body)

    def list(
        self, *, tenant_id: str, subject_id: str
    ) -> list[dict[str, Any]]:
        return self._c._request(
            "GET",
            "/admin/sessions",
            params={"tenant_id": tenant_id, "subject_id": subject_id},
        )

    def deactivate(self, session_id: str, *, tenant_id: str) -> None:
        self._c._request(
            "DELETE",
            f"/admin/sessions/{session_id}",
            params={"tenant_id": tenant_id},
        )


class AdminAPI:
    """Aggregator exposing every admin sub-namespace."""

    def __init__(self, client: OpenGuardClient) -> None:
        self.policies = PoliciesAPI(client)
        self.roles = RolesAPI(client)
        self.relationships = RelationshipsAPI(client)
        self.delegations = DelegationsAPI(client)
        self.sessions = SessionsAPI(client)

    def health(self) -> dict[str, Any]:
        return self.policies._c._request("GET", "/admin/health")


# ---------------------------------------------------------------------------
# Async namespaces — mirror sync surface 1:1
# ---------------------------------------------------------------------------


class AsyncPoliciesAPI:
    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self._c = client

    async def create(
        self,
        *,
        tenant_id: str,
        evaluator_type: str,
        subject_match: dict[str, Any] | None = None,
        action_match: str | list[str] = "*",
        resource_match: dict[str, Any] | None = None,
        conditions: dict[str, Any] | None = None,
        effect: str = "allow",
        priority: int = 0,
    ) -> dict[str, Any]:
        body = {
            "tenant_id": tenant_id,
            "evaluator_type": evaluator_type,
            "subject_match": subject_match or {},
            "action_match": action_match,
            "resource_match": resource_match or {},
            "conditions": conditions or {},
            "effect": effect,
            "priority": priority,
        }
        return await self._c._request("POST", "/admin/policies", json=body)

    async def list(
        self, *, tenant_id: str, evaluator_type: str | None = None
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"tenant_id": tenant_id}
        if evaluator_type is not None:
            params["evaluator_type"] = evaluator_type
        return await self._c._request(
            "GET", "/admin/policies", params=params
        )

    async def get(self, policy_id: str, *, tenant_id: str) -> dict[str, Any]:
        return await self._c._request(
            "GET",
            f"/admin/policies/{policy_id}",
            params={"tenant_id": tenant_id},
        )

    async def delete(self, policy_id: str, *, tenant_id: str) -> None:
        await self._c._request(
            "DELETE",
            f"/admin/policies/{policy_id}",
            params={"tenant_id": tenant_id},
        )


class AsyncRolesAPI:
    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self._c = client

    async def assign(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        role: str,
        resource_type: str | None = None,
        resource_match: dict[str, Any] | None = None,
        actions: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "role": role,
        }
        if resource_type is not None:
            body["resource_type"] = resource_type
        if resource_match is not None:
            body["resource_match"] = resource_match
        if actions is not None:
            body["actions"] = actions
        return await self._c._request("POST", "/admin/roles", json=body)


class AsyncRelationshipsAPI:
    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self._c = client

    async def add(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        relation: str,
        object_type: str,
        object_id: str,
        subject_type: str = "user",
        subject_relation: str | None = None,
    ) -> dict[str, Any]:
        body = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "subject_type": subject_type,
            "relation": relation,
            "object_type": object_type,
            "object_id": object_id,
            "subject_relation": subject_relation,
        }
        return await self._c._request(
            "POST", "/admin/relationships", json=body
        )

    async def list(
        self,
        *,
        tenant_id: str,
        object_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"tenant_id": tenant_id}
        if object_type is not None:
            params["object_type"] = object_type
        if subject_id is not None:
            params["subject_id"] = subject_id
        return await self._c._request(
            "GET", "/admin/relationships", params=params
        )

    async def check(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        relation: str,
        object_type: str,
        object_id: str,
        subject_type: str = "user",
    ) -> bool:
        body = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "subject_type": subject_type,
            "relation": relation,
            "object_type": object_type,
            "object_id": object_id,
        }
        result = await self._c._request(
            "POST", "/admin/relationships/check", json=body
        )
        return bool(result.get("exists", False))

    async def delete(self, tuple_id: str, *, tenant_id: str) -> None:
        await self._c._request(
            "DELETE",
            f"/admin/relationships/{tuple_id}",
            params={"tenant_id": tenant_id},
        )


class AsyncDelegationsAPI:
    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self._c = client

    async def create(
        self,
        *,
        tenant_id: str,
        from_subject_id: str,
        to_subject_id: str,
        scopes: list[dict[str, Any]],
        from_subject_type: str = "user",
        to_subject_type: str = "user",
        max_uses: int | None = None,
        budget: str | None = None,
        expires_at: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "from_subject_id": from_subject_id,
            "to_subject_id": to_subject_id,
            "scopes": scopes,
            "from_subject_type": from_subject_type,
            "to_subject_type": to_subject_type,
        }
        if max_uses is not None:
            body["max_uses"] = max_uses
        if budget is not None:
            body["budget"] = budget
        if expires_at is not None:
            body["expires_at"] = expires_at
        return await self._c._request(
            "POST", "/admin/delegations", json=body
        )

    async def list(
        self, *, tenant_id: str, subject_id: str
    ) -> list[dict[str, Any]]:
        return await self._c._request(
            "GET",
            "/admin/delegations",
            params={"tenant_id": tenant_id, "subject_id": subject_id},
        )

    async def revoke(self, delegation_id: str, *, tenant_id: str) -> None:
        await self._c._request(
            "DELETE",
            f"/admin/delegations/{delegation_id}",
            params={"tenant_id": tenant_id},
        )


class AsyncSessionsAPI:
    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self._c = client

    async def create(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        activated_roles: list[str],
        expires_at: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "subject_id": subject_id,
            "activated_roles": activated_roles,
        }
        if expires_at is not None:
            body["expires_at"] = expires_at
        if metadata is not None:
            body["metadata"] = metadata
        return await self._c._request(
            "POST", "/admin/sessions", json=body
        )

    async def list(
        self, *, tenant_id: str, subject_id: str
    ) -> list[dict[str, Any]]:
        return await self._c._request(
            "GET",
            "/admin/sessions",
            params={"tenant_id": tenant_id, "subject_id": subject_id},
        )

    async def deactivate(self, session_id: str, *, tenant_id: str) -> None:
        await self._c._request(
            "DELETE",
            f"/admin/sessions/{session_id}",
            params={"tenant_id": tenant_id},
        )


class AsyncAdminAPI:
    """Aggregator exposing every async admin sub-namespace."""

    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self.policies = AsyncPoliciesAPI(client)
        self.roles = AsyncRolesAPI(client)
        self.relationships = AsyncRelationshipsAPI(client)
        self.delegations = AsyncDelegationsAPI(client)
        self.sessions = AsyncSessionsAPI(client)

    async def health(self) -> dict[str, Any]:
        return await self.policies._c._request("GET", "/admin/health")
