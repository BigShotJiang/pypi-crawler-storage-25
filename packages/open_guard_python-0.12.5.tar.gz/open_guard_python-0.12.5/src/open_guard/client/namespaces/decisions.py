"""Decisions namespace (Phase 10) — runtime decisions over the wire."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from open_guard.domain.entities import Action, Resource, Subject


def _to_dict(value: Any) -> Any:
    """Convert a Pydantic model to a dict; pass dicts through unchanged."""
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    return value


def _authorize_body(
    *,
    subject: Subject | dict[str, Any],
    action: Action | str | dict[str, Any],
    resource: Resource | dict[str, Any],
    session_id: str | None,
    context: dict[str, Any] | None,
) -> dict[str, Any]:
    if isinstance(action, str):
        action_payload: Any = {"name": action}
    else:
        action_payload = _to_dict(action)
    body: dict[str, Any] = {
        "subject": _to_dict(subject),
        "action": action_payload,
        "resource": _to_dict(resource),
    }
    if session_id is not None:
        body["session_id"] = session_id
    if context:
        body["context"] = context
    return body


class DecisionsAPI:
    """Sync decisions namespace."""

    def __init__(self, client: OpenGuardClient) -> None:
        self._c = client

    def authorize(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: Action | str | dict[str, Any],
        resource: Resource | dict[str, Any],
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = _authorize_body(
            subject=subject,
            action=action,
            resource=resource,
            session_id=session_id,
            context=context,
        )
        return self._c._request("POST", "/authorize", json=body)

    def authorize_traced(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: Action | str | dict[str, Any],
        resource: Resource | dict[str, Any],
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = _authorize_body(
            subject=subject,
            action=action,
            resource=resource,
            session_id=session_id,
            context=context,
        )
        return self._c._request("POST", "/authorize/traced", json=body)

    def list_authorized(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: str,
        resource_type: str,
        cursor: str | None = None,
        limit: int = 100,
        prefilter: dict[str, Any] | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "subject": _to_dict(subject),
            "action": action,
            "resource_type": resource_type,
            "limit": limit,
        }
        if cursor is not None:
            body["cursor"] = cursor
        if prefilter:
            body["prefilter"] = prefilter
        if context:
            body["context"] = context
        return self._c._request("POST", "/list_authorized", json=body)

    def authorize_and_consume(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: Action | str | dict[str, Any],
        resource: Resource | dict[str, Any],
        amount: int = 1,
        cost: Decimal | str | None = None,
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = _authorize_body(
            subject=subject,
            action=action,
            resource=resource,
            session_id=session_id,
            context=context,
        )
        body["amount"] = amount
        if cost is not None:
            body["cost"] = str(cost)
        return self._c._request(
            "POST", "/authorize_and_consume", json=body, idempotent=False
        )


class AsyncDecisionsAPI:
    """Async decisions namespace — mirrors :class:`DecisionsAPI`."""

    def __init__(self, client: AsyncOpenGuardClient) -> None:
        self._c = client

    async def authorize(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: Action | str | dict[str, Any],
        resource: Resource | dict[str, Any],
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = _authorize_body(
            subject=subject,
            action=action,
            resource=resource,
            session_id=session_id,
            context=context,
        )
        return await self._c._request("POST", "/authorize", json=body)

    async def authorize_traced(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: Action | str | dict[str, Any],
        resource: Resource | dict[str, Any],
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = _authorize_body(
            subject=subject,
            action=action,
            resource=resource,
            session_id=session_id,
            context=context,
        )
        return await self._c._request(
            "POST", "/authorize/traced", json=body
        )

    async def list_authorized(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: str,
        resource_type: str,
        cursor: str | None = None,
        limit: int = 100,
        prefilter: dict[str, Any] | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "subject": _to_dict(subject),
            "action": action,
            "resource_type": resource_type,
            "limit": limit,
        }
        if cursor is not None:
            body["cursor"] = cursor
        if prefilter:
            body["prefilter"] = prefilter
        if context:
            body["context"] = context
        return await self._c._request(
            "POST", "/list_authorized", json=body
        )

    async def authorize_and_consume(
        self,
        *,
        subject: Subject | dict[str, Any],
        action: Action | str | dict[str, Any],
        resource: Resource | dict[str, Any],
        amount: int = 1,
        cost: Decimal | str | None = None,
        session_id: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        body = _authorize_body(
            subject=subject,
            action=action,
            resource=resource,
            session_id=session_id,
            context=context,
        )
        body["amount"] = amount
        if cost is not None:
            body["cost"] = str(cost)
        return await self._c._request(
            "POST", "/authorize_and_consume", json=body, idempotent=False
        )


# Late binding for type checkers — actual classes import this module.
from typing import TYPE_CHECKING  # noqa: E402

if TYPE_CHECKING:  # pragma: no cover
    from open_guard.client.async_client import AsyncOpenGuardClient
    from open_guard.client.sync_client import OpenGuardClient
