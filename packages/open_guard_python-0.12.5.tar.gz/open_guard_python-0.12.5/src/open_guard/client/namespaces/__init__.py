"""SDK namespaces (Phase 10).

The SDK API is organized into namespaces to avoid name collisions and
keep the surface explorable:

- ``client.decisions.*`` — runtime decisions
- ``client.admin.policies.*``, ``client.admin.roles.*``,
  ``client.admin.relationships.*``, ``client.admin.delegations.*``,
  ``client.admin.sessions.*``
"""
