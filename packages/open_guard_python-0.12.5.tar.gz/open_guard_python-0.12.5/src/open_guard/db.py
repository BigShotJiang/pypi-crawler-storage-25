"""Database schema utilities for open-guard."""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sqlalchemy import Engine

from open_guard.adapters.stores.sql_models import metadata


def create_all_tables(engine: Engine) -> None:
    """Create all open-guard tables in the database.

    Uses SQLAlchemy ``metadata.create_all()`` which is idempotent —
    existing tables are left unchanged.
    """
    metadata.create_all(engine)


def get_ddl(dialect: str = "sqlite") -> str:
    """Return the DDL SQL for all open-guard tables.

    Args:
        dialect: SQL dialect name (``"sqlite"`` or ``"postgresql"``).

    Returns:
        DDL SQL string with CREATE TABLE statements.
    """
    from sqlalchemy.engine.interfaces import Dialect
    from sqlalchemy.schema import CreateTable

    chosen_dialect: Dialect
    if dialect == "sqlite":
        from sqlalchemy.dialects import sqlite

        chosen_dialect = sqlite.dialect()
    elif dialect == "postgresql":
        from sqlalchemy.dialects import postgresql

        chosen_dialect = postgresql.dialect()  # type: ignore[no-untyped-call]
    else:
        raise ValueError(
            f"Unsupported dialect: {dialect!r}. Supported: 'sqlite', 'postgresql'."
        )

    statements: list[str] = []
    for table in metadata.sorted_tables:
        compiled = CreateTable(table).compile(dialect=chosen_dialect)
        statements.append(str(compiled).strip() + ";")

    return "\n\n".join(statements)
