Sync all relevant documents based on the active phase's history log.
Token-efficient: reads history + 2 tiny indexes first, then only targeted files.

## Steps

### Step 1: Load history and indexes (cheap reads)
- Read `specs/status.md` → identify active phase
- Read `specs/phases/<active-phase>/history.md` → extract all entries
- Read `specs/phases/index.json` (~2KB)
- Read `specs/decisions/impact-map.json` (~3KB)

### Step 2: Build targeted file list
For each history entry:
  - Extract Topics list
  - Look up each topic in index.json → collect affected phase tasks.md files
  - Look up each topic in impact-map.json → collect affected spec files/sections
  - Deduplicate the combined list

### Step 3: Show sync plan (ALWAYS show before touching anything)
Present to user:
  "Based on phase history, I will check and potentially update:
  - [list of files]
  Proceed? (yes/no)"

If user says no → stop.

### Step 4: Read and assess (targeted reads only)
For each file in the list:
  - Read only the relevant section
  - Assess: does it need updating based on history entries?

### Step 5: Make updates (one at a time, fully visible)
For each file that needs updating:
  - Show the user what will change
  - Use the Edit tool to make the change

### Step 6: Update phase index if scope changed
If any [SCOPE_CHANGE] entries exist:
  - Update `specs/phases/index.json` for the active phase's topic list

### Step 7: Commit all changes
```bash
git add all modified spec files
git commit -m "docs(phase-N): sync docs from phase history"
```

### Step 8: Confirm completion
"Doc sync complete. Updated N files:
- [list]
Ready to run /complete-phase."

## Safeguards
- NEVER update files not in the targeted list
- ALWAYS show the plan (Step 3) before making any edits
- History entries are NEVER modified — only read
- NEVER update docs in another repo — only sync docs THIS repo owns
- If a history entry has `Affects-specs: ../other-repo/...`, flag it to the user:
  "Cross-repo doc update needed in [repo]: [file]. Please update it in that repo's session."
