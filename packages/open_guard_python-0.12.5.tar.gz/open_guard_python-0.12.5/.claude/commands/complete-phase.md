Verify, finalize, and release a completed phase.

## Steps

### Verify

1. Read the phase's acceptance criteria:
   - Read `specs/phases/phase-N-*/overview.md`

2. Verify all tasks are done:
   - Read `specs/phases/phase-N-*/tasks.md`
   - If any `[ ]` unchecked items remain → report to user, do NOT proceed

3. Run project-specific validation (tests, linting, type checks).

4. If this phase built a learning loop (Rule 11), verify:
   - Locked evaluator exists in `tests/benchmarks/`
   - Convergence measurement logged (scalar improved)
   - If not → report to user, do NOT proceed

5. Check for new bugs discovered during the phase:
   - Grep `specs/backlog/backlog.md` for items tagged to this phase

### Finalize

**Step F0: Sync docs from phase history (run BEFORE other finalize steps)**
- Run `/sync-docs` to propagate all history-recorded changes to relevant documents
- If /sync-docs finds nothing to update, proceed directly

6. Create retrospective in the phase directory:
   - `specs/phases/phase-N-*/retrospective.md`
   - What went well, what didn't, lessons learned

7. Update all tracking:
   - `specs/phases/README.md` → mark `Complete`
   - `specs/status.md` → update current phase to next, add release version
   - `specs/planning/roadmap.md` → update phase status
   - `specs/changelog/YYYY-MM.md` → add release entry

### Release

**Git flow: `phase-N-shortname → staging → main → tag + GitHub Release`**

8. Commit all remaining changes on phase branch and push:
   ```bash
   git add -A
   git commit -m "docs: complete Phase N - {phase name}"
   git push origin phase-N-shortname
   ```

9. Merge phase branch → staging (ask user for approval first):
   ```bash
   git checkout staging
   git merge --no-ff phase-N-shortname -m "merge: phase-N-shortname → staging (vX.Y.Z)"
   git push origin staging
   ```

10. Merge staging → main (ask user for approval first):
    ```bash
    git checkout main
    git merge --no-ff staging -m "merge: staging → main (vX.Y.Z — Phase N: {phase name})"
    git push origin main
    ```

11. Tag on main + create GitHub Release (ask user for approval first):
    ```bash
    git checkout main
    git tag -a vX.Y.Z -m "Phase N: {phase name}"
    git push origin vX.Y.Z

    gh release create vX.Y.Z \
      --title "vX.Y.Z — Phase N: {phase name}" \
      --notes "## Phase N: {phase name}

    {bullet summary of what was delivered}

    ### Next: Phase N+1 — {next phase name}
    {key deliverables of next phase}" \
      --target main
    ```

12. Report summary to user:
    - What was delivered
    - GitHub Release URL
    - What's next
    - Remind to delete phase branch: `git push origin --delete phase-N-shortname`
