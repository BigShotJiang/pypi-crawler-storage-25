Brainstorm the next phase before creating it.

Run this AFTER completing a phase and BEFORE `/start-phase`.

## IMPORTANT: Output Location Override

If the brainstorming skill tries to save a design spec to `docs/superpowers/specs/` — **do NOT do that**. All brainstorm output goes directly into the phase directory as the standard phase files. There is no separate design document. The brainstorm output IS the phase files.

## Phase File Structure

Every phase produces exactly these files (no `design.md`, no separate spec):

```
specs/phases/phase-N-shortname/
├── overview.md    — Goal, key decisions, source structure, scope, deliverables, acceptance criteria
├── plan.md        — Implementation approach with complete task breakdown and code
├── tasks.md       — Granular checklist [ ] / [x] mirroring plan.md tasks
└── history.md     — Append-only log of decisions and discoveries from brainstorm
```

## Steps

1. Review current state:
   - Read `specs/status.md` — what phase just completed?
   - Read the completed phase's `history.md` — what was learned?
   - Read `specs/backlog/backlog.md` — any P0/P1 items to address?
   - Read `specs/dependencies.md` — any cross-repo impacts to consider?

2. Check the roadmap:
   - Read `specs/planning/roadmap.md` — what's the next planned phase?
   - Is the planned phase still the right next step given what was learned?

3. Define scope with the user (ask one question at a time):
   - What is the goal of this phase?
   - What are the key deliverables?
   - What are the acceptance criteria?
   - What are the non-goals (explicitly out of scope)?
   - Are there dependencies on other repos' phases?

4. Identify reference specs:
   - Which architecture docs (local or cross-repo) are relevant?
   - Are there any spec gaps that need to be filled first?
   - If gaps exist, propose an addendum or ADR before proceeding.

5. Gap analysis:
   - Cross-reference the brainstormed design against architecture specs
   - Verify counts and structures match exactly
   - Identify any spec ambiguities or defects
   - Record findings and resolutions

6. Draft the phase files directly:
   - Draft `overview.md`: goal, key decisions table, source structure, scope (in/out), deliverables with verification commands, acceptance criteria, reference specs
   - Draft `plan.md`: full implementation plan with ordered tasks, code patterns, test patterns, commit messages (use writing-plans skill)
   - Draft `tasks.md`: granular checklist mirroring plan.md tasks
   - Draft `history.md`: log all decisions and discoveries from the brainstorm

7. Present for user approval:
   - Show key sections of overview.md and plan.md
   - Ask: "Does this look right? Any changes before we create the phase?"

8. On approval, write all files to `specs/phases/phase-N-shortname/`:
   - Commit: `docs: brainstorm Phase N — {phase name}`

9. Prompt user: "Phase N is planned. Run `/start-phase` when ready to begin."

## Key Principles
- One question at a time — don't overwhelm
- Reference architecture specs, don't reinvent
- Each phase should be completable in a focused sprint
- If scope is too large, suggest splitting into sub-phases
- Record any architectural discoveries in history.md
- No separate design documents — brainstorm output goes directly into phase files
- Gap analysis against architecture specs is mandatory before finalizing
