---
name: User Profile
description: Avinash — Cerebrio founder building a multi-tenant agentic AI platform with epistemic architecture
type: user
---

Building cerebrio-sapience (multi-tenant agentic AI platform) and open-guard (standalone authorization library). Thinks architecturally, makes decisive priority calls (v1.0 triage of backlog items). Prefers understanding trade-offs before committing to scope. Comfortable with deep technical discussions on authorization models, deployment patterns, and system design.
