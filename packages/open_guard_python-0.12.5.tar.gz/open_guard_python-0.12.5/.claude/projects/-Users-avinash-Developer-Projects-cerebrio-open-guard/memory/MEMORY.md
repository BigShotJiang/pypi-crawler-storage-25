# Memory Index

- [User Profile](user_role.md) — Cerebrio founder, building multi-tenant agentic platform
- [Deployment Architecture](project_deployment.md) — cerebrio-sapience monorepo, multi-service, future non-Python services, tenant console
- [No External Libraries](feedback_no_external_libs.md) — Build authorization capabilities from scratch, no Casbin/OPA/OpenFGA
