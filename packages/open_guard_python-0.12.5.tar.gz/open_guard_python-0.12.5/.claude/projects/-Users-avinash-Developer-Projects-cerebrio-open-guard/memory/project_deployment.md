---
name: Cerebrio Sapience Deployment Architecture
description: cerebrio-sapience is a monorepo with flexible deployment (single binary OR multi-service), future non-Python services possible, tenant console for RBAC/permission management planned
type: project
---

cerebrio-sapience is a monorepo where multiple services may use different deployment methods — single binary or multi-service deployment.

**Why:** The platform serves multiple tenants, each with multiple actors (humans, AI agents, AI software). Tenants need a console (not a separate admin portal, but integrated into the product) to manage roles, permissions, and access control.

**How to apply:**
- open-guard must support both library mode (direct import) and service mode (HTTP/gRPC) for cross-language/cross-service consumption
- Policy management APIs are needed for the tenant console (CRUD on roles, permissions, policies)
- Multi-tenant is first-class — every tenant manages their own RBAC/ABAC configuration
- Future non-Python services mean language-agnostic access (service mode + SDKs) matters
- Design APIs assuming a UI will consume them (pagination, filtering, validation errors)
