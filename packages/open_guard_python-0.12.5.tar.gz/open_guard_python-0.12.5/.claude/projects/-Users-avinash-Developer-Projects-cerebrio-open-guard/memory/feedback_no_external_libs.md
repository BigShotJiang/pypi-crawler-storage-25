---
name: No External Authorization Libraries
description: Build all authorization capabilities from scratch — no Casbin, OPA, OpenFGA, or other external authz libraries
type: feedback
---

Do not use external authorization libraries (Casbin, OPA, OpenFGA, SpiceDB, etc.) as dependencies. open-guard builds all four authorization models (RBAC, ABAC, TBAC, ReBAC) from scratch.

**Why:** User's explicit architectural decision — own the data and compute, no vendor dependency. External adapters (originally Phase 6) are dropped from the plan.

**How to apply:** When designing new features, never propose integrating with external authz engines. Reference their designs as prior art in ADRs, but implement independently. External adapters may be revisited far-future but are not on any numbered phase.
