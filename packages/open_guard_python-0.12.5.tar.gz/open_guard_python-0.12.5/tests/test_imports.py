"""Top-level imports work and key SDK / service names are exposed (Phase 10)."""

from __future__ import annotations


def test_import_open_guard_succeeds():
    import open_guard

    assert open_guard.__version__ == "0.12.5"


def test_top_level_sdk_names_present_when_httpx_installed():
    import open_guard

    # [client] extra is part of the dev install — these names must
    # surface at the package root.
    assert hasattr(open_guard, "OpenGuardClient")
    assert hasattr(open_guard, "AsyncOpenGuardClient")
    assert hasattr(open_guard, "ApiKey")
    assert hasattr(open_guard, "BearerToken")
    assert hasattr(open_guard, "RetryPolicy")


def test_service_module_does_not_auto_load():
    """Service module must be opt-in — keeps FastAPI optional.

    Run in a subprocess to avoid polluting the test process's sys.modules
    (which would break later tests holding references to the previously
    imported open_guard module).
    """
    import subprocess
    import sys
    import textwrap

    code = textwrap.dedent(
        """
        import sys
        import open_guard  # noqa: F401
        assert "open_guard.service" not in sys.modules, sorted(
            n for n in sys.modules if n.startswith("open_guard.service")
        )
        assert "open_guard.service.app" not in sys.modules
        print("ok")
        """
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "ok" in result.stdout


def test_service_module_explicit_import_works():
    from open_guard.service import (
        ApiKeyAuth,
        AuthBackend,
        CallerContext,
        ServiceConfig,
        create_app,
    )

    assert callable(create_app)
    assert ApiKeyAuth is not None
    assert AuthBackend is not None
    assert CallerContext is not None
    assert ServiceConfig is not None


def test_client_module_explicit_import_works():
    from open_guard.client import (
        ApiKey,
        AsyncOpenGuardClient,
        BearerToken,
        OpenGuardClient,
        RetryPolicy,
    )

    assert OpenGuardClient is not None
    assert AsyncOpenGuardClient is not None
    assert ApiKey("og_x").header_name == "Authorization"
    assert BearerToken("eyJ").header_value == "Bearer eyJ"
    assert RetryPolicy().attempts == 3
