"""Tests for AdminRouter REST API (Phase 7 -- T6)."""

from __future__ import annotations

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from open_guard import Guard
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.api.fastapi.admin_router import AdminRouter


@pytest.fixture
def client() -> TestClient:
    guard = Guard.from_config(backend="memory")
    admin = PolicyAdmin(guard)
    app = FastAPI()
    app.include_router(AdminRouter(admin=admin), prefix="/admin")
    return TestClient(app)


class TestPolicyRoutes:
    def test_create_policy(self, client: TestClient) -> None:
        resp = client.post(
            "/admin/policies",
            json={
                "tenant_id": "t1",
                "evaluator_type": "rbac",
                "subject_match": {"roles": ["admin"]},
                "action_match": "*",
            },
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["tenant_id"] == "t1"
        assert data["evaluator_type"] == "rbac"
        assert "id" in data

    def test_list_policies(self, client: TestClient) -> None:
        client.post(
            "/admin/policies",
            json={
                "tenant_id": "t1",
                "evaluator_type": "rbac",
                "subject_match": {"roles": ["viewer"]},
            },
        )
        resp = client.get("/admin/policies", params={"tenant_id": "t1"})
        assert resp.status_code == 200
        assert len(resp.json()) >= 1

    def test_get_policy(self, client: TestClient) -> None:
        create_resp = client.post(
            "/admin/policies",
            json={
                "tenant_id": "t1",
                "evaluator_type": "rbac",
                "subject_match": {"roles": ["viewer"]},
            },
        )
        policy_id = create_resp.json()["id"]
        resp = client.get(
            f"/admin/policies/{policy_id}", params={"tenant_id": "t1"}
        )
        assert resp.status_code == 200
        assert resp.json()["id"] == policy_id

    def test_get_policy_not_found(self, client: TestClient) -> None:
        resp = client.get(
            "/admin/policies/nonexistent", params={"tenant_id": "t1"}
        )
        assert resp.status_code == 404

    def test_delete_policy(self, client: TestClient) -> None:
        create_resp = client.post(
            "/admin/policies",
            json={
                "tenant_id": "t1",
                "evaluator_type": "rbac",
                "subject_match": {"roles": ["viewer"]},
            },
        )
        policy_id = create_resp.json()["id"]
        resp = client.delete(
            f"/admin/policies/{policy_id}", params={"tenant_id": "t1"}
        )
        assert resp.status_code == 204


class TestRoleRoutes:
    def test_assign_role(self, client: TestClient) -> None:
        resp = client.post(
            "/admin/roles",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "role": "editor",
            },
        )
        assert resp.status_code == 201


class TestRelationshipRoutes:
    def test_add_relationship(self, client: TestClient) -> None:
        resp = client.post(
            "/admin/relationships",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "subject_type": "user",
                "relation": "member",
                "object_type": "project",
                "object_id": "p1",
            },
        )
        assert resp.status_code == 201
        assert resp.json()["relation"] == "member"

    def test_list_relationships(self, client: TestClient) -> None:
        client.post(
            "/admin/relationships",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "subject_type": "user",
                "relation": "member",
                "object_type": "project",
                "object_id": "p1",
            },
        )
        resp = client.get(
            "/admin/relationships", params={"tenant_id": "t1"}
        )
        assert resp.status_code == 200
        assert len(resp.json()) >= 1

    def test_delete_relationship(self, client: TestClient) -> None:
        create_resp = client.post(
            "/admin/relationships",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "subject_type": "user",
                "relation": "member",
                "object_type": "project",
                "object_id": "p1",
            },
        )
        tuple_id = create_resp.json()["id"]
        resp = client.delete(
            f"/admin/relationships/{tuple_id}",
            params={"tenant_id": "t1"},
        )
        assert resp.status_code == 204


class TestDelegationRoutes:
    def _grant_alice_doc_access(self, client: TestClient) -> None:
        """Create a policy so alice can delegate doc permissions."""
        client.post(
            "/admin/policies",
            json={
                "tenant_id": "t1",
                "evaluator_type": "abac",
                "action_match": "*",
                "resource_match": {"resource_type": "doc"},
                "effect": "allow",
            },
        )

    def test_create_delegation(self, client: TestClient) -> None:
        self._grant_alice_doc_access(client)
        resp = client.post(
            "/admin/delegations",
            json={
                "tenant_id": "t1",
                "from_subject_id": "alice",
                "to_subject_id": "bob",
                "scopes": [
                    {
                        "resource_type": "doc",
                        "action_match": "read",
                    }
                ],
            },
        )
        assert resp.status_code == 201

    def test_list_delegations(self, client: TestClient) -> None:
        self._grant_alice_doc_access(client)
        client.post(
            "/admin/delegations",
            json={
                "tenant_id": "t1",
                "from_subject_id": "alice",
                "to_subject_id": "bob",
                "scopes": [
                    {
                        "resource_type": "doc",
                        "action_match": "*",
                    }
                ],
            },
        )
        resp = client.get(
            "/admin/delegations",
            params={"tenant_id": "t1", "subject_id": "bob"},
        )
        assert resp.status_code == 200
        assert len(resp.json()) >= 1


class TestSessionRoutes:
    def test_create_session(self, client: TestClient) -> None:
        resp = client.post(
            "/admin/sessions",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "activated_roles": ["editor", "viewer"],
            },
        )
        assert resp.status_code == 201
        assert resp.json()["subject_id"] == "alice"

    def test_deactivate_session(self, client: TestClient) -> None:
        create_resp = client.post(
            "/admin/sessions",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "activated_roles": ["editor"],
            },
        )
        session_id = create_resp.json()["id"]
        resp = client.delete(
            f"/admin/sessions/{session_id}", params={"tenant_id": "t1"}
        )
        assert resp.status_code == 204

    def test_list_sessions(self, client: TestClient) -> None:
        client.post(
            "/admin/sessions",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "activated_roles": ["editor"],
            },
        )
        resp = client.get(
            "/admin/sessions",
            params={"tenant_id": "t1", "subject_id": "alice"},
        )
        assert resp.status_code == 200


class TestHealthRoute:
    def test_health(self, client: TestClient) -> None:
        resp = client.get("/admin/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data
