"""Executable mirrors of every Phase 10 integration-guide snippet (anti-doc-rot)."""

from __future__ import annotations

import asyncio

import pytest
from fastapi.testclient import TestClient

from open_guard import PolicyAdmin, build_guard
from open_guard.client.async_client import AsyncOpenGuardClient
from open_guard.client.base import ApiKey
from open_guard.client.exceptions import AuthorizationServiceError
from open_guard.client.sync_client import OpenGuardClient
from open_guard.service.app import ServiceConfig, create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def test_quickstart_service_assembly():
    """Mirrors `Quickstart — service` snippet."""
    guard = build_guard()
    admin = PolicyAdmin(guard)

    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc-cerebrio",
            )
        )
    )
    assert cleartext.startswith("og_")

    app = create_app(
        guard=guard,
        admin=admin,
        auth=ApiKeyAuth(store),
        config=ServiceConfig(prefix="/v1"),
    )
    paths = app.openapi()["paths"]
    assert "/v1/authorize" in paths
    assert "/v1/admin/policies" in paths


def _service_with_key():
    guard = build_guard()
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    record = ApiKeyRecord(
        key_hash=digest,
        tenant_id="t1",
        service_identity="svc",
    )
    try:
        asyncio.get_running_loop()
        store._records[record.key_hash] = record
    except RuntimeError:
        asyncio.run(store.add(record))
    app = create_app(
        guard=guard, admin=PolicyAdmin(guard), auth=ApiKeyAuth(store)
    )
    return app, cleartext


def test_quickstart_python_sdk_sync():
    """Mirrors `Quickstart — Python SDK` (sync)."""
    app, cleartext = _service_with_key()
    test_client = TestClient(app, base_url="http://t")
    with OpenGuardClient(
        "http://t",
        auth=ApiKey(cleartext),
        http_client=test_client,
    ) as client:
        decision = client.decisions.authorize(
            subject={"id": "alice", "actor_type": "user"},
            action="read",
            resource={"id": "doc-1", "resource_type": "document"},
        )
        assert "allowed" in decision


@pytest.mark.asyncio
async def test_quickstart_python_sdk_async():
    """Mirrors `Quickstart — Python SDK` (async) — uses ASGITransport."""
    import httpx

    app, cleartext = _service_with_key()
    transport = httpx.ASGITransport(app=app)
    async with AsyncOpenGuardClient(
        "http://t", auth=ApiKey(cleartext), transport=transport
    ) as client:
        decision = await client.decisions.authorize(
            subject={"id": "alice", "actor_type": "user"},
            action="read",
            resource={"id": "doc-1", "resource_type": "document"},
        )
        assert "allowed" in decision


def test_tenancy_model_cross_tenant_admin_scope():
    """Mirrors `Tenancy model` snippet."""
    guard = build_guard()
    store = InMemoryApiKeyStore()
    cleartext_ops, digest_ops = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest_ops,
                tenant_id="ops",
                service_identity="ops-tooling",
                scopes=["cross_tenant_admin"],
            )
        )
    )
    app = create_app(guard=guard, auth=ApiKeyAuth(store))
    client = TestClient(app)
    r = client.post(
        "/v1/authorize",
        headers={
            "Authorization": f"ApiKey {cleartext_ops}",
            "X-Tenant-ID": "t-other",
        },
        json={
            "subject": {"id": "u", "actor_type": "user"},
            "action": {"name": "read"},
            "resource": {"id": "r", "resource_type": "doc"},
        },
    )
    assert r.status_code == 200


def test_tenancy_model_without_scope_is_403():
    guard = build_guard()
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc",
            )
        )
    )
    app = create_app(guard=guard, auth=ApiKeyAuth(store))
    test_client = TestClient(app, base_url="http://t")

    # Through the SDK — pulls the typed exception subclass.
    sdk = OpenGuardClient(
        "http://t",
        auth=ApiKey(cleartext),
        http_client=test_client,
    )
    sdk._http.headers["X-Tenant-ID"] = "t-other"
    with pytest.raises(AuthorizationServiceError) as exc:
        sdk.decisions.authorize(
            subject={"id": "u", "actor_type": "user"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    assert exc.value.code == "cross_tenant_forbidden"
    sdk.close()


def test_error_envelope_shape():
    """Mirrors `Error envelope` snippet."""
    guard = build_guard()
    app = create_app(
        guard=guard,
        auth=ApiKeyAuth(InMemoryApiKeyStore()),
    )
    r = TestClient(app).post(
        "/v1/authorize",
        json={
            "subject": {"id": "u", "actor_type": "user"},
            "action": {"name": "read"},
            "resource": {"id": "r", "resource_type": "doc"},
        },
    )
    assert r.status_code == 401
    body = r.json()
    assert set(body["error"]) == {"code", "message", "details"}
    assert body["error"]["code"] == "missing_api_key"


def test_endpoint_reference_listing():
    """Mirrors `Endpoint reference` table — verifies all endpoints register."""
    app, _ = _service_with_key()
    paths = app.openapi()["paths"]
    assert "/v1/authorize" in paths
    assert "/v1/authorize/traced" in paths
    assert "/v1/list_authorized" in paths
    assert "/v1/authorize_and_consume" in paths
    assert "/v1/admin/policies" in paths
    assert "/v1/admin/health" in paths


def test_async_guard_registers_all_decision_endpoints():
    """Phase 11 (FEAT-018 / FEAT-014) closed the async parity gap — async
    deployments now expose the full DecisionRouter just like sync.
    """
    from open_guard import build_async_guard

    guard = asyncio.run(build_async_guard())
    app = create_app(guard=guard, auth=ApiKeyAuth(InMemoryApiKeyStore()))
    paths = app.openapi()["paths"]
    assert "/v1/authorize" in paths
    assert "/v1/list_authorized" in paths
    assert "/v1/authorize_and_consume" in paths
