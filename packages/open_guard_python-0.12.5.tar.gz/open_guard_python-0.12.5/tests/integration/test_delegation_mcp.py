"""Integration: MCP tool-call authorization with delegation budget (T15).

Full path: Guard with DelegationStore + MCPGuard wired together.
- Tool call allowed via delegation
- consume_tool_call_budget decrements the correct delegation
- Tool call denied once delegation exhausted
- Budget tracking via MCPGuard.consume_tool_call_budget
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

from open_guard.adapters.mcp.guard import MCPGuard
from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    AuthorizationRequest,
    DelegationScope,
    Evaluation,
    Policy,
    Subject,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"
SERVER_ID = "srv"
TOOL_NAME = "my_tool"
TOOL_RESOURCE_ID = f"tool:{SERVER_ID}:{TOOL_NAME}"


class _FixedResolver:
    def resolve(self, session_id: str, claims: dict) -> Subject:
        return Subject(id=claims.get("sub", "agent-1"), actor_type=ActorType.AGENT)


def _user(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.USER)


def _tool_scope() -> DelegationScope:
    return DelegationScope(
        action_match="invoke",
        resource_type="tool",
        resource_match={"id": {"op": "eq", "value": TOOL_RESOURCE_ID}},
    )


def _make_mcp(
    *,
    policy_allowed_for: set[str] | None = None,
    ds: InMemoryDelegationStore | None = None,
) -> tuple[MCPGuard, Guard, InMemoryDelegationStore]:
    class SubjectEval(EvaluatorPort):
        @property
        def evaluator_type(self) -> str:
            return "rbac"

        def evaluate(self, req: AuthorizationRequest, policies: list) -> Evaluation:
            allowed = req.subject.id in (policy_allowed_for or set())
            return Evaluation(
                evaluator="rbac",
                allowed=allowed,
                matched_policies=[p.id for p in policies] if allowed else [],
            )

        def supports(self, policy: Policy) -> bool:
            return policy.evaluator_type == "rbac"

    delegation_store = ds or InMemoryDelegationStore()
    store = MockPolicyStore([Policy(tenant_id=TENANT, evaluator_type="rbac")])
    guard = Guard(
        policy_store=store,
        evaluators=[SubjectEval()],
        delegation_store=delegation_store,
        clock=lambda: NOW,
        default_delegate_policy="self_only",
    )
    mcp = MCPGuard(guard=guard, resolver=_FixedResolver(), default_tenant_id=TENANT)  # type: ignore[arg-type]
    return mcp, guard, delegation_store


class TestMCPDelegationBudgetIntegration:
    def test_tool_call_allowed_via_delegation(self) -> None:
        """MCPGuard check_tool_call allows when delegation exists for agent."""
        mcp, guard, _ds = _make_mcp(policy_allowed_for={"alice"})
        alice = _user("alice")
        agent = Subject(id="agent-1", actor_type=ActorType.AGENT)

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=agent,
            scopes=[_tool_scope()], tenant_id=TENANT,
        )

        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        assert len(result.attributed_delegation_ids) == 1

    def test_tool_call_denied_without_delegation(self) -> None:
        """Without any delegation, agent is denied."""
        mcp, _, _ = _make_mcp()

        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "deny"
        assert result.attributed_delegation_ids == []

    def test_consume_budget_decrements_uses_remaining(self) -> None:
        """consume_tool_call_budget decrements uses_remaining on the delegation."""
        mcp, guard, ds = _make_mcp(policy_allowed_for={"alice"})
        alice = _user("alice")
        agent = Subject(id="agent-1", actor_type=ActorType.AGENT)

        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=agent,
            scopes=[_tool_scope()], tenant_id=TENANT, max_uses=5,
        )

        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        mcp.consume_tool_call_budget(result, TENANT, amount=1)

        updated = ds.get(delegation.id, TENANT)
        assert updated is not None
        assert updated.uses_remaining == 4

    def test_consume_budget_decrements_financial_budget(self) -> None:
        """consume_tool_call_budget with cost decrements budget_remaining."""
        mcp, guard, ds = _make_mcp(policy_allowed_for={"alice"})
        alice = _user("alice")
        agent = Subject(id="agent-1", actor_type=ActorType.AGENT)

        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=agent,
            scopes=[_tool_scope()], tenant_id=TENANT, budget=Decimal("10.00"),
        )

        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        mcp.consume_tool_call_budget(result, TENANT, cost=Decimal("3.75"))

        updated = ds.get(delegation.id, TENANT)
        assert updated is not None
        assert updated.budget_remaining == Decimal("6.25")

    def test_tool_denied_after_delegation_exhausted(self) -> None:
        """After consuming all uses, next check_tool_call returns deny."""
        mcp, guard, _ds = _make_mcp(policy_allowed_for={"alice"})
        alice = _user("alice")
        agent = Subject(id="agent-1", actor_type=ActorType.AGENT)

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=agent,
            scopes=[_tool_scope()], tenant_id=TENANT, max_uses=1,
        )

        # Allow and consume
        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        mcp.consume_tool_call_budget(result, TENANT, amount=1)

        # Now should be denied
        result2 = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result2.status == "deny"

    def test_policy_allowed_tool_call_has_empty_delegation_ids(self) -> None:
        """Tool call allowed by policy → attributed_delegation_ids is empty."""
        mcp, _guard, _ds = _make_mcp(policy_allowed_for={"agent-1"})

        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        assert result.attributed_delegation_ids == []

    def test_consume_after_policy_allow_is_noop(self) -> None:
        """consume_tool_call_budget on a policy-allow result is a no-op."""
        mcp, guard, ds = _make_mcp(policy_allowed_for={"agent-1", "alice"})

        # Also create an unrelated delegation that should NOT be touched
        alice = _user("alice")
        other_agent = Subject(id="other-agent", actor_type=ActorType.AGENT)
        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=other_agent,
            scopes=[_tool_scope()], tenant_id=TENANT, max_uses=5,
        )

        result = mcp.check_tool_call(
            session_id="s1", tool_name=TOOL_NAME, params={}, server_id=SERVER_ID,
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        mcp.consume_tool_call_budget(result, TENANT, amount=1)

        unchanged = ds.get(delegation.id, TENANT)
        assert unchanged is not None
        assert unchanged.uses_remaining == 5
