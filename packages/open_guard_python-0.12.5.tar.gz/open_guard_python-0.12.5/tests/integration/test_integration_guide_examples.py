"""Executable mirrors of `specs/architecture/integration-guide.md` snippets.

Every code block in the guide that demonstrates behavior has a corresponding
test here. If a future change breaks a guide example, this file fails —
preventing the guide from drifting away from reality. The focus is Phase 3
(chain / approval / trace) and Phase 4 (list_authorized, MCP adapter) since
those are the newest and highest-risk-of-drift surface.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from open_guard import (
    ABACEvaluator,
    Action,
    ActorType,
    ApprovalRequirement,
    DecisionStatus,
    Guard,
    InMemoryApprovalStore,
    InMemoryPolicyStore,
    InMemoryRelationshipStore,
    PermissionRule,
    Policy,
    PolicyEffect,
    RBACEvaluator,
    ReBACEvaluator,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.adapters.mcp import MCPGuard
from open_guard.adapters.mcp.sdk import HAS_SDK, from_sdk_call_request
from open_guard.domain.entities import Cursor
from open_guard.domain.ports.candidate_resource import CandidateResourcePort

# -----------------------------------------------------------------------
# Quick Start
# -----------------------------------------------------------------------


class TestGuideQuickStart:
    def test_ten_line_rbac(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        decision = guard.authorize(
            alice,
            Action(name="read"),
            Resource(
                id="d1", resource_type="doc", attributes={"type": "doc"},
            ),
            tenant_id="acme",
        )
        assert decision.allowed is True


# -----------------------------------------------------------------------
# Phase 0 — ABAC condition groups (OR)
# -----------------------------------------------------------------------


class TestGuideABACOR:
    def test_condition_groups_or_semantics(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="abac",
                action_match="read",
                conditions={
                    "condition_groups": [
                        {"subject.department": {"op": "eq", "value": "engineering"}},
                        {"subject.department": {"op": "eq", "value": "security"}},
                    ],
                },
            )
        )
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        sec = Subject(id="u1", attributes={"department": "security"})
        decision = guard.authorize(
            sec,
            Action(name="read"),
            Resource(id="r1", resource_type="document"),
            tenant_id="acme",
        )
        assert decision.allowed is True


# -----------------------------------------------------------------------
# Phase 2 — ReBAC Google-Drive style hierarchy
# -----------------------------------------------------------------------


def _doc_typedefs() -> dict[str, TypeDefinition]:
    return {
        "doc": TypeDefinition(
            name="doc",
            relations={"owner": ["user"], "editor": ["user"], "viewer": ["user"]},
            permissions={
                "can_edit": PermissionRule(
                    kind="union", relations=["owner", "editor"]
                ),
                "can_view": PermissionRule(
                    kind="union", relations=["owner", "editor", "viewer"]
                ),
            },
        ),
    }


class TestGuideReBAC:
    def test_owner_can_view_via_computed_permission(self) -> None:
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rebac",
                action_match="read",
                conditions={
                    "object_type": "doc",
                    "permission": "can_view",
                    "subject_type": "user",
                },
            )
        )
        rel = InMemoryRelationshipStore()
        rel.write_tuple(
            RelationTuple(
                tenant_id="acme",
                object_type="doc",
                object_id="d1",
                relation="owner",
                subject_type="user",
                subject_id="alice",
            )
        )
        rebac = ReBACEvaluator(
            relationship_store=rel, type_definitions=_doc_typedefs()
        )
        guard = Guard(policy_store=policy_store, evaluators=[rebac])
        decision = guard.authorize(
            Subject(id="alice"),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="acme",
        )
        assert decision.allowed is True


# -----------------------------------------------------------------------
# Phase 3 — Identity chains, chain-aware ABAC, approval, trace
# -----------------------------------------------------------------------


class TestGuideChains:
    def test_subject_chain_construction(self) -> None:
        user = Subject(id="alice", attributes={"trusted": True})
        agent = Subject(
            id="agent-research",
            actor_type=ActorType.AGENT,
            on_behalf_of=user,
        )
        assert agent.chain_depth == 1
        assert agent.root_actor.id == "alice"

    def test_chain_aware_abac(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="abac",
                action_match="read",
                resource_match={"type": "doc"},
                conditions={
                    "chain.root_actor.trusted": {"op": "eq", "value": True},
                },
            )
        )
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        trusted_user = Subject(id="alice", attributes={"trusted": True})
        agent = Subject(
            id="agent",
            actor_type=ActorType.AGENT,
            on_behalf_of=trusted_user,
        )
        d = guard.authorize(
            agent,
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="acme",
        )
        assert d.allowed is True


class TestGuideApproval:
    def test_pending_then_approve_cycle(self) -> None:
        approval_store = InMemoryApprovalStore()
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rbac",
                subject_match={"roles": ["researcher"]},
                action_match="delete",
                resource_match={"type": "file"},
                requires_approval=ApprovalRequirement(
                    approvers=["admin@corp"],
                    quorum="any",
                    ttl=timedelta(minutes=30),
                    channel="slack",
                ),
            )
        )
        guard = Guard(
            policy_store=store,
            evaluators=[RBACEvaluator()],
            approval_store=approval_store,
        )
        agent = Subject(
            id="agent",
            actor_type=ActorType.AGENT,
            attributes={"roles": ["researcher"]},
        )
        file_res = Resource(
            id="f1", resource_type="file", attributes={"type": "file"},
        )
        d = guard.authorize(agent, Action(name="delete"), file_res, "acme")
        assert d.status == DecisionStatus.PENDING_APPROVAL
        assert d.approval_request_id is not None

        guard.approve(d.approval_request_id, "acme", approver="admin@corp")

        d2 = guard.authorize(agent, Action(name="delete"), file_res, "acme")
        assert d2.allowed is True


class TestGuideTrace:
    def test_authorize_traced_returns_populated_trace(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        d, trace = guard.authorize_traced(
            alice,
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            "acme",
        )
        assert d.allowed is True
        assert trace.schema_version == "1.0"
        assert any(snap.id == "alice" for snap in trace.actor_chain)


# -----------------------------------------------------------------------
# Phase 4 — list_authorized (RAG) + MCP adapter
# -----------------------------------------------------------------------


class _DocSource(CandidateResourcePort):
    """Mirrors the guide's PGDocSource shape in memory."""

    def __init__(self, docs: list[dict[str, Any]]) -> None:
        self._docs = docs

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        offset = int((cursor or {}).get("offset", 0))
        rows = self._docs[offset : offset + limit]
        resources = [
            Resource(
                id=r["id"],
                resource_type=resource_type,
                tenant_id=tenant_id,
                attributes={
                    "type": resource_type,
                    "classification": r["classification"],
                    "owner": r["owner"],
                },
            )
            for r in rows
        ]
        next_cursor = (
            {"offset": offset + limit} if offset + limit < len(self._docs) else None
        )
        return resources, next_cursor


class TestGuideListAuthorized:
    def test_basic_rag_list(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rbac",
                subject_match={"roles": ["researcher"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        source = _DocSource(
            [
                {"id": "r1", "classification": "public", "owner": "alice"},
                {"id": "r2", "classification": "public", "owner": "bob"},
            ]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[RBACEvaluator()],
            candidate_source=source,
        )
        alice = Subject(id="alice", attributes={"roles": ["researcher"]})
        result = guard.list_authorized(alice, "read", "doc", "acme", limit=50)
        assert sorted(result.ids) == ["r1", "r2"]
        assert result.has_more() is False

    def test_cursor_pagination_roundtrip(self) -> None:
        # 5 docs, page of 2 — walk the cursor to exhaustion
        source = _DocSource(
            [
                {"id": str(i), "classification": "public", "owner": "alice"}
                for i in range(5)
            ]
        )
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rbac",
                subject_match={"roles": ["researcher"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        guard = Guard(
            policy_store=store,
            evaluators=[RBACEvaluator()],
            candidate_source=source,
        )
        alice = Subject(id="alice", attributes={"roles": ["researcher"]})
        all_ids: list[str] = []
        cursor: str | None = None
        while True:
            r = guard.list_authorized(
                alice, "read", "doc", "acme", limit=2, cursor=cursor,
            )
            all_ids.extend(r.ids)
            if not r.has_more():
                break
            cursor = r.next_cursor
        assert sorted(all_ids) == ["0", "1", "2", "3", "4"]

    def test_cursor_decode_roundtrip(self) -> None:
        c = Cursor(rebac_offset=10, seen_ids={"a", "b"})
        assert Cursor.decode(c.encode()).seen_ids == {"a", "b"}


# -----------------------------------------------------------------------
# Phase 4 — MCP adapter
# -----------------------------------------------------------------------


class _SessionResolver:
    def __init__(self, subject: Subject) -> None:
        self._subject = subject

    def resolve(self, session_id: str, claims: dict[str, Any]) -> Subject:
        return self._subject


class _ToolSource(CandidateResourcePort):
    def __init__(self, tools: list[tuple[str, str]]) -> None:
        self._tools = tools

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._tools
        if prefilter and "server_id" in prefilter:
            items = [
                (s, t) for (s, t) in items if s == prefilter["server_id"]
            ]
        resources = [
            Resource(
                id=f"tool:{s}:{t}",
                resource_type="tool",
                tenant_id=tenant_id,
                attributes={
                    "type": "tool",
                    "server_id": s,
                    "tool_name": t,
                    "params": {},
                },
            )
            for (s, t) in items
        ]
        return resources, None


class TestGuideMCP:
    def test_check_tool_call_allow(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rbac",
                subject_match={"roles": ["researcher"]},
                action_match="invoke",
                resource_match={"tool_name": "query_db"},
            )
        )
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator(), ABACEvaluator()])
        subject = Subject(
            id="agent-a", attributes={"roles": ["researcher"]}
        )
        mcp = MCPGuard(
            guard=guard,
            resolver=_SessionResolver(subject),
            default_tenant_id="acme",
        )
        result = mcp.check_tool_call(
            session_id="sess-42",
            tool_name="query_db",
            params={"query": "SELECT * FROM users"},
            server_id="prod",
        )
        assert result.is_allowed()

    def test_param_level_abac_blocks_destructive(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="abac",
                action_match="invoke",
                resource_match={"tool_name": "query_db"},
                conditions={
                    "resource.params.query": {
                        "op": "not_regex",
                        "value": r"(?i)\b(DROP|DELETE|TRUNCATE)\b",
                    }
                },
            )
        )
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        mcp = MCPGuard(
            guard=guard,
            resolver=_SessionResolver(Subject(id="agent-a")),
            default_tenant_id="acme",
        )
        allowed = mcp.check_tool_call(
            "sess", "query_db", {"query": "SELECT 1"}, "prod"
        )
        blocked = mcp.check_tool_call(
            "sess", "query_db", {"query": "DROP TABLE users"}, "prod"
        )
        assert allowed.is_allowed()
        assert blocked.is_denied()

    def test_list_authorized_tools(self) -> None:
        store = InMemoryPolicyStore()
        for tn in ("query_db", "read_file"):
            store.add(
                Policy(
                    tenant_id="acme",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": tn},
                )
            )
        source = _ToolSource(
            [
                ("prod", "query_db"),
                ("prod", "read_file"),
                ("prod", "delete_file"),  # no policy → denied
            ]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[RBACEvaluator()],
            candidate_source=source,
        )
        agent = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=_SessionResolver(agent),
            default_tenant_id="acme",
        )
        result = mcp.list_authorized_tools("sess-42")
        assert sorted(result.ids) == [
            "tool:prod:query_db",
            "tool:prod:read_file",
        ]


class TestGuideSDKBinding:
    def test_duck_typed_from_sdk_call_request(self) -> None:
        """Guide shows `HAS_SDK` and `from_sdk_call_request` — verify here."""
        from types import SimpleNamespace

        sdk_req = SimpleNamespace(
            name="query_db", arguments={"table": "users"}
        )
        out = from_sdk_call_request(
            sdk_req, session_id="sess-42", server_id="prod"
        )
        assert out.tool_name == "query_db"
        assert out.params == {"table": "users"}
        assert isinstance(HAS_SDK, bool)


# -----------------------------------------------------------------------
# Composition rules (guide's "important" section)
# -----------------------------------------------------------------------


class TestGuideCompositionRules:
    def test_rebac_requires_abac_allow_when_both_wired(self) -> None:
        """Guide's warning: with ABAC + ReBAC both wired, ABAC must have
        an ALLOW policy or composition fails-closed to deny."""
        # Without an ABAC ALLOW: even a ReBAC allow doesn't make it through.
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="rebac",
                action_match="read",
                conditions={
                    "object_type": "doc",
                    "permission": "can_view",
                    "subject_type": "user",
                },
            )
        )
        # ABAC-typed policy with nothing allowing — forces ABAC into "no matching
        # attribute policy" → evaluation.allowed=False → composed DENY.
        policy_store.add(
            Policy(
                tenant_id="acme",
                evaluator_type="abac",
                effect=PolicyEffect.DENY,
                action_match="read",
                conditions={
                    "resource.classification": {"op": "eq", "value": "secret"},
                },
            )
        )
        rel = InMemoryRelationshipStore()
        rel.write_tuple(
            RelationTuple(
                tenant_id="acme", object_type="doc", object_id="d1",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel,
                    type_definitions=_doc_typedefs(),
                ),
                ABACEvaluator(),
            ],
        )
        decision = guard.authorize(
            Subject(id="alice"),
            Action(name="read"),
            Resource(
                id="d1",
                resource_type="doc",
                attributes={"type": "doc", "classification": "public"},
            ),
            "acme",
        )
        # ReBAC allows but ABAC has no ALLOW → composed DENY (fail-closed).
        assert decision.allowed is False


# -----------------------------------------------------------------------
# Phase 5 — Delegation & Bounds (guide section mirrors)
# -----------------------------------------------------------------------


class TestPhase5DelegationGuide:
    """Mirrors the Phase 5 integration-guide code blocks."""

    def _make_guard(self) -> tuple:
        from open_guard import (
            ActorType,
            DelegationScope,
            Guard,
            InMemoryDelegationStore,
            Subject,
        )
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        from open_guard.domain.entities import AuthorizationRequest, Evaluation, Policy
        from open_guard.domain.ports.evaluator import EvaluatorPort

        class AllowEval(EvaluatorPort):
            @property
            def evaluator_type(self) -> str:
                return "rbac"

            def evaluate(self, req: AuthorizationRequest, policies: list) -> Evaluation:
                allowed = req.subject.id == "alice"
                return Evaluation(
                    evaluator="rbac",
                    allowed=allowed,
                    matched_policies=[p.id for p in policies] if allowed else [],
                )

            def supports(self, policy) -> bool:
                return policy.evaluator_type == "rbac"

        ds = InMemoryDelegationStore()
        store = InMemoryPolicyStore()
        store.add(Policy(tenant_id="acme", evaluator_type="rbac"))
        guard = Guard(
            policy_store=store,
            evaluators=[AllowEval()],
            delegation_store=ds,
            default_delegate_policy="self_only",
        )
        alice = Subject(id="alice", actor_type=ActorType.USER)
        bob = Subject(id="bob", actor_type=ActorType.AGENT)
        scope = DelegationScope(
            action_match="read",
            resource_type="document",
            resource_match={"id": {"op": "eq", "value": "doc-42"}},
        )
        return guard, ds, alice, bob, scope

    def test_phase5_delegate_and_authorize(self) -> None:
        """Guide: delegate → authorize via delegation path."""
        from open_guard import Action, DecisionStatus, Resource
        guard, _ds, alice, bob, scope = self._make_guard()

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id="acme", max_uses=10,
        )
        resource = Resource(id="doc-42", resource_type="document")
        decision = guard.authorize(bob, Action(name="read"), resource, "acme")
        assert decision.status == DecisionStatus.ALLOWED
        assert decision.reason == "delegation"

    def test_phase5_authorize_and_consume(self) -> None:
        """Guide: authorize_and_consume decrements uses_remaining."""
        from open_guard import Action, Resource
        guard, ds, alice, bob, scope = self._make_guard()

        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id="acme", max_uses=10,
        )
        resource = Resource(id="doc-42", resource_type="document")
        guard.authorize_and_consume(
            bob, Action(name="read"), resource, "acme", amount=1,
        )
        updated = ds.get(delegation.id, "acme")
        assert updated is not None
        assert updated.uses_remaining == 9

    def test_phase5_budget_consumption(self) -> None:
        """Guide: authorize_and_consume with cost decrements budget_remaining."""
        from decimal import Decimal

        from open_guard import Action, Resource
        guard, ds, alice, bob, scope = self._make_guard()

        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id="acme", budget=Decimal("100.00"),
        )
        resource = Resource(id="doc-42", resource_type="document")
        guard.authorize_and_consume(
            bob, Action(name="read"), resource, "acme", cost=Decimal("1.50"),
        )
        updated = ds.get(delegation.id, "acme")
        assert updated is not None
        assert updated.budget_remaining == Decimal("98.50")

    def test_phase5_revoke_cascades(self) -> None:
        """Guide: revoke_delegation blocks further access."""
        from open_guard import Action, DecisionStatus, Resource
        guard, _ds, alice, bob, scope = self._make_guard()

        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id="acme",
        )
        guard.revoke_delegation(delegation.id, caller=alice, tenant_id="acme")

        resource = Resource(id="doc-42", resource_type="document")
        decision = guard.authorize(bob, Action(name="read"), resource, "acme")
        assert decision.status == DecisionStatus.DENIED

    def test_phase5_list_authorized_delegation_contribution(self) -> None:
        """Guide: list_authorized picks up concrete-id delegation scopes."""
        guard, _ds, alice, bob, scope = self._make_guard()

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id="acme",
        )
        result = guard.list_authorized(bob, "read", "document", "acme", limit=100)
        assert "doc-42" in result.ids

    def test_phase5_mcp_consume_tool_call_budget(self) -> None:
        """Guide: MCPGuard.consume_tool_call_budget decrements attribution."""
        from decimal import Decimal

        from open_guard import (
            ActorType,
            DelegationScope,
            InMemoryDelegationStore,
            Subject,
        )
        from open_guard.adapters.mcp.guard import MCPGuard
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        from open_guard.domain.entities import AuthorizationRequest, Evaluation, Policy
        from open_guard.domain.ports.evaluator import EvaluatorPort
        from open_guard.domain.services.guard import Guard

        class AllowAliceEval(EvaluatorPort):
            @property
            def evaluator_type(self) -> str:
                return "rbac"

            def evaluate(self, req: AuthorizationRequest, policies: list) -> Evaluation:
                allowed = req.subject.id == "alice"
                return Evaluation(
                    evaluator="rbac",
                    allowed=allowed,
                    matched_policies=[p.id for p in policies] if allowed else [],
                )

            def supports(self, policy) -> bool:
                return policy.evaluator_type == "rbac"

        class Resolver:
            def resolve(self, session_id, claims):
                return Subject(id=claims.get("sub", "bob"), actor_type=ActorType.AGENT)

        ds = InMemoryDelegationStore()
        store = InMemoryPolicyStore()
        store.add(Policy(tenant_id="acme", evaluator_type="rbac"))
        guard = Guard(
            policy_store=store,
            evaluators=[AllowAliceEval()],
            delegation_store=ds,
            default_delegate_policy="self_only",
        )
        mcp = MCPGuard(guard=guard, resolver=Resolver(), default_tenant_id="acme")

        alice = Subject(id="alice", actor_type=ActorType.USER)
        bob_sub = Subject(id="bob", actor_type=ActorType.AGENT)
        delegation = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob_sub,
            scopes=[DelegationScope(
                action_match="invoke",
                resource_type="tool",
                resource_match={"id": {"op": "eq", "value": "tool:rag:search"}},
            )],
            tenant_id="acme",
            budget=Decimal("10.00"),
        )

        result = mcp.check_tool_call(
            session_id="sess-1", tool_name="search", params={}, server_id="rag",
            claims={"sub": "bob", "tenant_id": "acme"},
        )
        assert result.status == "allow"
        assert len(result.attributed_delegation_ids) == 1

        mcp.consume_tool_call_budget(result, "acme", cost=Decimal("0.01"))
        updated = ds.get(delegation.id, "acme")
        assert updated is not None
        assert updated.budget_remaining == Decimal("9.99")
