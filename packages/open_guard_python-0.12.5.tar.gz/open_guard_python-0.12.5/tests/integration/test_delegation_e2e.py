"""Integration: end-to-end delegation lifecycle (T13).

Covers the full path: delegate → authorize_and_consume → exhaust → expire.
All wired through Guard with real DelegationManager + InMemoryDelegationStore.
"""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    DecisionStatus,
    DelegationScope,
    DelegationStatus,
    Policy,
    Subject,
)
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _user(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.USER)


def _agent(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.AGENT)


def _scope(
    action: str = "read", resource_type: str = "document", doc_id: str = "doc-1"
) -> DelegationScope:
    return DelegationScope(
        action_match=action,
        resource_type=resource_type,
        resource_match={"id": {"op": "eq", "value": doc_id}},
    )


def _make_guard(
    *,
    policy_allowed_for: set[str] | None = None,
    ds: InMemoryDelegationStore | None = None,
) -> tuple[Guard, InMemoryDelegationStore]:
    from open_guard.domain.entities import AuthorizationRequest, Evaluation
    from open_guard.domain.ports.evaluator import EvaluatorPort

    class SubjectEval(EvaluatorPort):
        @property
        def evaluator_type(self) -> str:
            return "rbac"

        def evaluate(self, req: AuthorizationRequest, policies: list) -> Evaluation:
            allowed = req.subject.id in (policy_allowed_for or set())
            return Evaluation(
                evaluator="rbac",
                allowed=allowed,
                matched_policies=[p.id for p in policies] if allowed else [],
            )

        def supports(self, policy: Policy) -> bool:
            return policy.evaluator_type == "rbac"

    delegation_store = ds or InMemoryDelegationStore()
    store = MockPolicyStore([Policy(tenant_id=TENANT, evaluator_type="rbac")])
    guard = Guard(
        policy_store=store,
        evaluators=[SubjectEval()],
        delegation_store=delegation_store,
        clock=lambda: NOW,
        default_delegate_policy="self_only",
    )
    return guard, delegation_store


class TestDelegationE2ELifecycle:
    def test_delegate_then_authorize_allows_agent(self) -> None:
        """Full path: alice delegates doc access to bob → bob's authorize passes."""
        guard, _ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        delegation = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )
        assert delegation.status == DelegationStatus.ACTIVE

        from open_guard.domain.entities import Action, Resource
        resource = Resource(id="doc-1", resource_type="document")
        decision = guard.authorize(bob, Action(name="read"), resource, TENANT)
        assert decision.status == DecisionStatus.ALLOWED
        assert decision.reason == "delegation"

    def test_authorize_and_consume_decrements_uses(self) -> None:
        """authorize_and_consume decrements uses_remaining on matching delegation."""
        guard, ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        delegation = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
            max_uses=3,
        )

        from open_guard.domain.entities import Action, Resource
        guard.authorize_and_consume(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
            amount=1,
        )

        updated = ds.get(delegation.id, TENANT)
        assert updated is not None
        assert updated.uses_remaining == 2

    def test_authorize_and_consume_exhausts_delegation(self) -> None:
        """After uses_remaining reaches 0, status becomes EXHAUSTED."""
        guard, ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        delegation = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
            max_uses=2,
        )

        from open_guard.domain.entities import Action, Resource
        resource = Resource(id="doc-1", resource_type="document")
        action = Action(name="read")

        guard.authorize_and_consume(bob, action, resource, TENANT, amount=1)
        guard.authorize_and_consume(bob, action, resource, TENANT, amount=1)

        exhausted = ds.get(delegation.id, TENANT)
        assert exhausted is not None
        assert exhausted.status == DelegationStatus.EXHAUSTED

    def test_exhausted_delegation_denies_further_requests(self) -> None:
        """Once exhausted, further authorize calls are denied (no fallback)."""
        guard, _ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
            max_uses=1,
        )

        from open_guard.domain.entities import Action, Resource
        resource = Resource(id="doc-1", resource_type="document")
        action = Action(name="read")

        guard.authorize_and_consume(bob, action, resource, TENANT, amount=1)

        # Now exhausted
        decision = guard.authorize(bob, action, resource, TENANT)
        assert decision.status == DecisionStatus.DENIED

    def test_revoke_blocks_delegate(self) -> None:
        """After revocation, bob's authorize is denied."""
        guard, _ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        delegation = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )

        guard.revoke_delegation(delegation.id, caller=alice, tenant_id=TENANT)

        from open_guard.domain.entities import Action, Resource
        resource = Resource(id="doc-1", resource_type="document")
        decision = guard.authorize(bob, Action(name="read"), resource, TENANT)
        assert decision.status == DecisionStatus.DENIED

    def test_budget_consumption_lifecycle(self) -> None:
        """Budget decrements correctly across multiple authorize_and_consume calls."""
        guard, ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        delegation = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
            budget=Decimal("9.00"),
        )

        from open_guard.domain.entities import Action, Resource
        resource = Resource(id="doc-1", resource_type="document")
        action = Action(name="read")

        guard.authorize_and_consume(bob, action, resource, TENANT, cost=Decimal("3.00"))
        guard.authorize_and_consume(bob, action, resource, TENANT, cost=Decimal("2.50"))

        updated = ds.get(delegation.id, TENANT)
        assert updated is not None
        assert updated.budget_remaining == Decimal("3.50")

    def test_idempotent_delegate_returns_same_delegation(self) -> None:
        """Duplicate delegate() calls with same parameters return the same."""
        guard, _ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")
        scopes = [_scope()]

        d1 = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=scopes, tenant_id=TENANT,
        )
        d2 = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=scopes, tenant_id=TENANT,
        )

        assert d1.id == d2.id

    def test_policy_allowed_user_not_affected_by_delegation_store(self) -> None:
        """Policy-allowed subject's Decision is unaffected by unrelated delegations."""
        guard, _ds = _make_guard(policy_allowed_for={"alice"})
        alice = _user("alice")
        bob = _agent("bob")

        guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )

        from open_guard.domain.entities import Action, Resource
        resource = Resource(id="doc-1", resource_type="document")
        decision = guard.authorize(alice, Action(name="read"), resource, TENANT)
        assert decision.status == DecisionStatus.ALLOWED
        assert decision.reason != "delegation"
