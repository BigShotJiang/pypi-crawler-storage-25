"""Integration — OBO chain propagation end-to-end through Guard + evaluators."""

from __future__ import annotations

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_relationship import (
    InMemoryRelationshipStore,
)
from open_guard.domain.entities import (
    Action,
    ActorType,
    DecisionStatus,
    PermissionRule,
    Policy,
    PolicyEffect,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.domain.services.guard import Guard


class TestChainIntegration:
    """FEAT-005 — chain data flows through every evaluator path."""

    def test_abac_policy_sees_chain_root_actor(self) -> None:
        """Agent delegated by trusted user is allowed by chain-aware ABAC."""
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="abac-trusted-delegator",
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                conditions={
                    "chain.root_actor.trusted": {"op": "eq", "value": True},
                },
            )
        )
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        user = Subject(id="alice", attributes={"trusted": True})
        agent = Subject(
            id="helper",
            actor_type=ActorType.AGENT,
            on_behalf_of=user,
        )
        decision = guard.authorize(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.status == DecisionStatus.ALLOWED

    def test_abac_deny_when_root_actor_untrusted(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="p1",
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                conditions={
                    "chain.root_actor.trusted": {"op": "eq", "value": True},
                },
            )
        )
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        user = Subject(id="alice", attributes={"trusted": False})
        agent = Subject(
            id="helper", actor_type=ActorType.AGENT, on_behalf_of=user
        )
        decision = guard.authorize(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_rbac_uses_immediate_subject_roles(self) -> None:
        """RBAC evaluates the immediate acting subject's roles, not root's."""
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="p1",
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                subject_match={"roles": ["agent-runner"]},
            )
        )
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])
        user = Subject(id="alice", attributes={"roles": ["viewer"]})
        agent = Subject(
            id="helper",
            actor_type=ActorType.AGENT,
            attributes={"roles": ["agent-runner"]},
            on_behalf_of=user,
        )
        decision = guard.authorize(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_rebac_uses_immediate_subject_id(self) -> None:
        """ReBAC tuples are about the immediate subject performing the action."""
        rel_store = InMemoryRelationshipStore()
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t1",
                object_type="document",
                object_id="doc1",
                relation="viewer",
                subject_type="agent",
                subject_id="helper",
            )
        )
        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={"viewer": ["agent"]},
                permissions={
                    "can_view": PermissionRule(kind="self"),
                },
            )
        }
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="p1",
                tenant_id="t1",
                evaluator_type="rebac",
                effect=PolicyEffect.ALLOW,
                action_match="view",
                conditions={
                    "object_type": "document",
                    "permission": "viewer",
                    "subject_type": "agent",
                },
            )
        )
        guard = Guard(
            policy_store=store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=type_defs,
                )
            ],
        )
        user = Subject(id="alice")
        agent = Subject(
            id="helper",
            actor_type=ActorType.AGENT,
            on_behalf_of=user,
        )
        decision = guard.authorize(
            subject=agent,
            action=Action(name="view"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_chain_appears_in_trace(self) -> None:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="p1",
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                subject_match={"roles": ["agent-runner"]},
            )
        )
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])
        user = Subject(id="alice", actor_type=ActorType.USER)
        agent = Subject(
            id="helper",
            actor_type=ActorType.AGENT,
            attributes={"roles": ["agent-runner"]},
            on_behalf_of=user,
        )
        _, trace = guard.authorize_traced(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert [s.id for s in trace.actor_chain] == ["helper", "alice"]
        assert trace.actor_chain[0].actor_type == ActorType.AGENT
        assert trace.actor_chain[1].actor_type == ActorType.USER
