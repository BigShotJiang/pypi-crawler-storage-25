"""Integration — AI-era primitives end-to-end (Phase 8).

Tests exercise TrustGateEvaluator, OperationChain evaluator dispatch,
new ActorType values, and OBO trust scoping through the Guard factory.
"""

from __future__ import annotations

import pytest

from open_guard.adapters.factory import build_guard
from open_guard.domain.entities import (
    Action,
    ActorType,
    OperationChainConfig,
    OperationRule,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.services.async_guard import AsyncGuard


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_TENANT = "t1"


def _chain() -> OperationChainConfig:
    """Cerebrio-style knowledge operation chain."""
    return OperationChainConfig(
        rules=[
            OperationRule(
                action_pattern="knowledge:write",
                evaluators=["rbac", "abac", "trust"],
            ),
            OperationRule(
                action_pattern="knowledge:read",
                evaluators=["rbac", "abac"],
            ),
            OperationRule(
                action_pattern="knowledge:*",
                evaluators=["rbac"],
            ),
        ]
    )


def _add_write_policies(guard: object) -> None:
    """Seed RBAC + ABAC + Trust allow policies for knowledge:write."""
    store = guard._policy_store  # type: ignore[attr-defined]
    store.add(
        Policy(
            id="rbac-write",
            tenant_id=_TENANT,
            evaluator_type="rbac",
            effect=PolicyEffect.ALLOW,
            action_match="knowledge:write",
            subject_match={"roles": ["editor"]},
        )
    )
    store.add(
        Policy(
            id="abac-write",
            tenant_id=_TENANT,
            evaluator_type="abac",
            effect=PolicyEffect.ALLOW,
            action_match="knowledge:write",
            conditions={
                "subject.department": {"op": "eq", "value": "research"},
            },
        )
    )
    store.add(
        Policy(
            id="trust-write",
            tenant_id=_TENANT,
            evaluator_type="trust",
            effect=PolicyEffect.ALLOW,
            action_match="knowledge:write",
            conditions={"min_trust_score": 0.6},
        )
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAIEraPrimitivesIntegration:
    """Phase 8 — end-to-end AI-era primitives through Guard."""

    # 1. Full chain write — all three evaluators pass
    def test_full_chain_write_allowed(self) -> None:
        guard = build_guard(backend="memory", operation_chain=_chain())
        _add_write_policies(guard)

        subject = Subject(
            id="alice",
            attributes={
                "roles": ["editor"],
                "department": "research",
                "trust_score": 0.9,
            },
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="knowledge:write"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert decision.allowed
        evaluator_names = {e.evaluator for e in decision.evaluations}
        assert evaluator_names == {"rbac", "abac", "trust"}

    # 2. Trust gate blocks write when it is the sole evaluator
    def test_trust_gate_blocks_write(self) -> None:
        """When trust is the only evaluator for an action and the score is
        below threshold, no evaluator grants → DENIED."""
        chain = OperationChainConfig(
            rules=[
                OperationRule(
                    action_pattern="secure:write",
                    evaluators=["trust"],
                ),
            ]
        )
        guard = build_guard(backend="memory", operation_chain=chain)

        guard._policy_store.add(
            Policy(
                id="trust-secure",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="secure:write",
                conditions={"min_trust_score": 0.6},
            )
        )

        subject = Subject(
            id="alice",
            attributes={"trust_score": 0.3},
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="secure:write"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert not decision.allowed
        evaluator_names = {e.evaluator for e in decision.evaluations}
        assert "trust" in evaluator_names
        # Trust was the only evaluator that participated
        assert len(decision.evaluations) == 1

    # 3. Read bypasses trust evaluator
    def test_read_bypasses_trust(self) -> None:
        guard = build_guard(backend="memory", operation_chain=_chain())

        store = guard._policy_store
        store.add(
            Policy(
                id="rbac-read",
                tenant_id=_TENANT,
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="knowledge:read",
                subject_match={"roles": ["viewer"]},
            )
        )
        store.add(
            Policy(
                id="abac-read",
                tenant_id=_TENANT,
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                action_match="knowledge:read",
                conditions={
                    "subject.department": {"op": "eq", "value": "research"},
                },
            )
        )

        subject = Subject(
            id="bob",
            attributes={
                "roles": ["viewer"],
                "department": "research",
                "trust_score": 0.1,  # low — but trust not evaluated for read
            },
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="knowledge:read"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert decision.allowed
        evaluator_names = {e.evaluator for e in decision.evaluations}
        assert "rbac" in evaluator_names
        assert "abac" in evaluator_names
        assert "trust" not in evaluator_names

    # 4. Glob fallback routing — knowledge:trace matches knowledge:*
    def test_glob_fallback_routing(self) -> None:
        guard = build_guard(backend="memory", operation_chain=_chain())

        guard._policy_store.add(
            Policy(
                id="rbac-all",
                tenant_id=_TENANT,
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="*",
                subject_match={"roles": ["viewer"]},
            )
        )

        subject = Subject(
            id="carol",
            attributes={"roles": ["viewer"]},
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="knowledge:trace"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert decision.allowed
        evaluator_names = {e.evaluator for e in decision.evaluations}
        assert evaluator_names == {"rbac"}

    # 5. ROBOT actor type with trust policies
    def test_robot_actor_with_trust(self) -> None:
        chain = OperationChainConfig(
            rules=[
                OperationRule(
                    action_pattern="sensor:read",
                    evaluators=["trust"],
                ),
            ]
        )
        guard = build_guard(backend="memory", operation_chain=chain)

        guard._policy_store.add(
            Policy(
                id="trust-robot",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="sensor:read",
                subject_match={"actor_type": "robot"},
                conditions={"min_trust_score": 0.5},
            )
        )

        subject = Subject(
            id="robot-1",
            actor_type=ActorType.ROBOT,
            attributes={"trust_score": 0.8, "roles": ["sensor"]},
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="sensor:read"),
            resource=Resource(id="sensor-hub", resource_type="device"),
            tenant_id=_TENANT,
        )
        assert decision.allowed

    # 6. OBO chain — trust_scope="all", agent fails threshold
    def test_obo_chain_trust_scope_all(self) -> None:
        chain = OperationChainConfig(
            rules=[
                OperationRule(
                    action_pattern="data:write",
                    evaluators=["trust"],
                ),
            ]
        )
        guard = build_guard(backend="memory", operation_chain=chain)

        guard._policy_store.add(
            Policy(
                id="trust-all",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="data:write",
                conditions={"min_trust_score": 0.5, "trust_scope": "all"},
            )
        )

        user = Subject(
            id="user-1",
            actor_type=ActorType.USER,
            attributes={"trust_score": 0.9},
        )
        agent = Subject(
            id="agent-1",
            actor_type=ActorType.AGENT,
            attributes={"trust_score": 0.4},
            on_behalf_of=user,
        )
        decision = guard.authorize(
            subject=agent,
            action=Action(name="data:write"),
            resource=Resource(id="r1", resource_type="data"),
            tenant_id=_TENANT,
        )
        assert not decision.allowed

    # 7. OBO chain — trust_scope="root", only root actor matters
    def test_root_trust_only(self) -> None:
        chain = OperationChainConfig(
            rules=[
                OperationRule(
                    action_pattern="data:read",
                    evaluators=["trust"],
                ),
            ]
        )
        guard = build_guard(backend="memory", operation_chain=chain)

        guard._policy_store.add(
            Policy(
                id="trust-root",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="data:read",
                conditions={"min_trust_score": 0.7, "trust_scope": "root"},
            )
        )

        user = Subject(
            id="user-1",
            attributes={"trust_score": 0.9},
        )
        agent = Subject(
            id="agent-1",
            attributes={"trust_score": 0.2},
            on_behalf_of=user,
        )
        decision = guard.authorize(
            subject=agent,
            action=Action(name="data:read"),
            resource=Resource(id="r1", resource_type="data"),
            tenant_id=_TENANT,
        )
        assert decision.allowed

    # 8. No operation_chain — backward compatible, all evaluators fire
    def test_no_chain_backward_compatible(self) -> None:
        guard = build_guard(backend="memory")

        guard._policy_store.add(
            Policy(
                id="rbac-allow",
                tenant_id=_TENANT,
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                subject_match={"roles": ["viewer"]},
            )
        )
        guard._policy_store.add(
            Policy(
                id="trust-allow",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                conditions={"min_trust_score": 0.5},
            )
        )

        subject = Subject(
            id="dave",
            attributes={"roles": ["viewer"], "trust_score": 0.8},
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="read"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert decision.allowed
        evaluator_names = {e.evaluator for e in decision.evaluations}
        assert "rbac" in evaluator_names
        assert "trust" in evaluator_names

    # 9. Traced path — only active evaluators appear in trace
    def test_traced_path_correctness(self) -> None:
        chain = OperationChainConfig(
            rules=[
                OperationRule(
                    action_pattern="write",
                    evaluators=["rbac", "trust"],
                ),
            ]
        )
        guard = build_guard(backend="memory", operation_chain=chain)

        guard._policy_store.add(
            Policy(
                id="rbac-write",
                tenant_id=_TENANT,
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="write",
                subject_match={"roles": ["writer"]},
            )
        )
        guard._policy_store.add(
            Policy(
                id="trust-write",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="write",
                conditions={"min_trust_score": 0.5},
            )
        )

        subject = Subject(
            id="eve",
            attributes={"roles": ["writer"], "trust_score": 0.9},
        )
        decision, trace = guard.authorize_traced(
            subject=subject,
            action=Action(name="write"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert decision.allowed
        trace_evaluators = {r.evaluator for r in trace.evaluator_results}
        assert "rbac" in trace_evaluators
        assert "trust" in trace_evaluators
        # Evaluators NOT in the chain rule must be absent
        assert "abac" not in trace_evaluators
        assert "tbac" not in trace_evaluators
        assert "rebac" not in trace_evaluators

    # 10. Async guard with chain filtering
    @pytest.mark.asyncio
    async def test_async_guard_chain_filtering(self) -> None:
        chain = _chain()
        guard = await AsyncGuard.from_config(
            backend="memory", operation_chain=chain
        )

        await guard.policy_store.add(
            Policy(
                id="rbac-write",
                tenant_id=_TENANT,
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="knowledge:write",
                subject_match={"roles": ["editor"]},
            )
        )
        await guard.policy_store.add(
            Policy(
                id="abac-write",
                tenant_id=_TENANT,
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                action_match="knowledge:write",
                conditions={
                    "subject.department": {"op": "eq", "value": "research"},
                },
            )
        )
        await guard.policy_store.add(
            Policy(
                id="trust-write",
                tenant_id=_TENANT,
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                action_match="knowledge:write",
                conditions={"min_trust_score": 0.6},
            )
        )

        subject = Subject(
            id="alice",
            attributes={
                "roles": ["editor"],
                "department": "research",
                "trust_score": 0.9,
            },
        )
        decision = await guard.authorize(
            subject=subject,
            action=Action(name="knowledge:write"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id=_TENANT,
        )
        assert decision.allowed
        evaluator_names = {e.evaluator for e in decision.evaluations}
        assert evaluator_names == {"rbac", "abac", "trust"}
