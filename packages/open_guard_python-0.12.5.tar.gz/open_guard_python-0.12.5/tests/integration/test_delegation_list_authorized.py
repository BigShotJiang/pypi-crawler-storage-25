"""Integration: Guard.list_authorized with delegation contribution (T11)."""

from __future__ import annotations

from datetime import UTC, datetime

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    Subject,
)
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockEvaluator, MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _user(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.USER)


def _agent(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.AGENT)


def _make_delegation(
    *,
    from_id: str,
    to_id: str,
    resource_match: dict | None = None,
    action: str = "read",
    resource_type: str = "document",
    status: DelegationStatus = DelegationStatus.ACTIVE,
    max_uses: int | None = None,
    re_check_on_use: bool = False,
    hash_suffix: str = "",
) -> Delegation:
    scope = DelegationScope(
        action_match=action,
        resource_type=resource_type,
        resource_match=resource_match or {},
    )
    uses_remaining = max_uses
    return Delegation(
        tenant_id=TENANT,
        from_subject_id=from_id,
        from_subject_type=ActorType.USER,
        to_subject_id=to_id,
        to_subject_type=ActorType.AGENT,
        scopes=[scope],
        status=status,
        re_check_on_use=re_check_on_use,
        max_uses=max_uses,
        uses_remaining=uses_remaining,
        request_hash=f"h-{from_id}-{to_id}-{resource_type}{hash_suffix}",
        created_at=NOW,
        created_by=from_id,
    )


def _guard_with_delegation(
    *,
    policy_allowed_for: set[str] | None = None,
    ds: InMemoryDelegationStore | None = None,
) -> tuple[Guard, InMemoryDelegationStore]:
    """Guard where policy only grants 'alice', delegation wired for bob."""
    from open_guard.domain.entities import AuthorizationRequest, Evaluation
    from open_guard.domain.ports.evaluator import EvaluatorPort

    class SubjectFilterEval(EvaluatorPort):
        @property
        def evaluator_type(self) -> str:
            return "rbac"

        def evaluate(self, req: AuthorizationRequest, policies: list) -> Evaluation:
            allowed = req.subject.id in (policy_allowed_for or set())
            return Evaluation(
                evaluator="rbac",
                allowed=allowed,
                matched_policies=[p.id for p in policies] if allowed else [],
            )

        def supports(self, policy: Policy) -> bool:
            return policy.evaluator_type == "rbac"

    delegation_store = ds or InMemoryDelegationStore()
    policy_store = MockPolicyStore([Policy(tenant_id=TENANT, evaluator_type="rbac")])
    g = Guard(
        policy_store=policy_store,
        evaluators=[SubjectFilterEval()],
        delegation_store=delegation_store,
        clock=lambda: NOW,
    )
    return g, delegation_store


class TestListAuthorizedDelegationContribution:
    def test_concrete_id_scope_appears_without_candidate_source(self) -> None:
        """Delegation with id:eq scope → ID appears in list_authorized."""
        guard, ds = _guard_with_delegation()
        d = _make_delegation(
            from_id="alice", to_id="bob",
            resource_match={"id": {"op": "eq", "value": "doc-42"}},
        )
        ds.create(d)

        result = guard.list_authorized(
            _agent("bob"), "read", "document", TENANT, limit=10
        )
        assert "doc-42" in result.ids

    def test_in_scope_emits_all_ids(self) -> None:
        """Delegation with id:in scope → all listed IDs appear."""
        guard, ds = _guard_with_delegation()
        d = _make_delegation(
            from_id="alice", to_id="bob",
            resource_match={"id": {"op": "in", "value": ["doc-1", "doc-2", "doc-3"]}},
        )
        ds.create(d)

        result = guard.list_authorized(
            _agent("bob"), "read", "document", TENANT, limit=10
        )
        assert "doc-1" in result.ids
        assert "doc-2" in result.ids
        assert "doc-3" in result.ids

    def test_exhausted_delegation_contributes_nothing(self) -> None:
        guard, ds = _guard_with_delegation()
        d = _make_delegation(
            from_id="alice", to_id="bob",
            resource_match={"id": {"op": "eq", "value": "doc-exhausted"}},
            status=DelegationStatus.EXHAUSTED,
        )
        ds.create(d)

        result = guard.list_authorized(
            _agent("bob"), "read", "document", TENANT, limit=10
        )
        assert "doc-exhausted" not in result.ids

    def test_revoked_delegation_contributes_nothing(self) -> None:
        guard, ds = _guard_with_delegation()
        d = _make_delegation(
            from_id="alice", to_id="bob",
            resource_match={"id": {"op": "eq", "value": "doc-revoked"}},
            status=DelegationStatus.REVOKED,
        )
        ds.create(d)

        result = guard.list_authorized(
            _agent("bob"), "read", "document", TENANT, limit=10
        )
        assert "doc-revoked" not in result.ids

    def test_list_authorized_does_not_consume_usage(self) -> None:
        """list_authorized must never decrement uses_remaining."""
        guard, ds = _guard_with_delegation()
        d = _make_delegation(
            from_id="alice", to_id="bob",
            resource_match={"id": {"op": "eq", "value": "doc-1"}},
            max_uses=5,
        )
        ds.create(d)

        for _ in range(3):
            guard.list_authorized(_agent("bob"), "read", "document", TENANT, limit=10)

        unchanged = ds.get(d.id, TENANT)
        assert unchanged is not None
        assert unchanged.uses_remaining == 5  # untouched by list_authorized

    def test_delegation_contribution_deduplicates_with_policy_ids(self) -> None:
        """Policy + delegation both grant doc-1 → it appears once in list_authorized."""
        guard, ds = _guard_with_delegation(policy_allowed_for={"alice"})
        d = _make_delegation(
            from_id="alice", to_id="bob",
            resource_match={"id": {"op": "eq", "value": "doc-1"}},
        )
        ds.create(d)

        result = guard.list_authorized(
            _agent("bob"), "read", "document", TENANT, limit=10
        )
        assert result.ids.count("doc-1") == 1

    def test_no_delegation_store_behavior_unchanged(self) -> None:
        """Guard without delegation_store: list_authorized returns empty."""
        from tests.unit.domain.services.test_policy_router import MockPolicyStore

        policy_store = MockPolicyStore(
            [Policy(tenant_id=TENANT, evaluator_type="rbac")]
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[MockEvaluator("rbac", allowed=False)],
        )
        result = guard.list_authorized(
            _agent("bob"), "read", "document", TENANT, limit=10
        )
        assert result.ids == []
