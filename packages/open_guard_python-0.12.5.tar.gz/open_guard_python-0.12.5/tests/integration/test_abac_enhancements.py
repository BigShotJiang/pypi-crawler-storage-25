"""Integration tests — ABAC OR logic, set ops, negated ops through Guard."""

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.domain.entities import (
    Action,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard


class TestABACEnhancementsThroughGuard:
    def test_or_condition_groups_allow(self) -> None:
        """OR logic: engineering OR security department can read."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="read",
            conditions={
                "condition_groups": [
                    {"subject.department": {"op": "eq", "value": "engineering"}},
                    {"subject.department": {"op": "eq", "value": "security"}},
                ],
            },
        ))

        # security matches second group
        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"department": "security"}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_or_condition_groups_deny(self) -> None:
        """No group matches → denied."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="read",
            conditions={
                "condition_groups": [
                    {"subject.department": {"op": "eq", "value": "engineering"}},
                    {"subject.department": {"op": "eq", "value": "security"}},
                ],
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"department": "marketing"}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_set_operators_contains_any(self) -> None:
        """Policy requires subject to have at least one of the required tags."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="deploy",
            conditions={
                "subject.certs": {
                    "op": "contains_any",
                    "value": ["soc2", "iso27001"],
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"certs": ["soc2", "gdpr"]}),
            action=Action(name="deploy"),
            resource=Resource(id="prod", resource_type="environment"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_set_operators_contains_all(self) -> None:
        """Policy requires subject to have ALL required certs."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="deploy",
            conditions={
                "subject.certs": {
                    "op": "contains_all",
                    "value": ["soc2", "hipaa"],
                },
            },
        ))

        # Missing hipaa
        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"certs": ["soc2"]}),
            action=Action(name="deploy"),
            resource=Resource(id="prod", resource_type="environment"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_negated_operator_blocks(self) -> None:
        """not_regex blocks emails from evil.com domain."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="*",
            conditions={
                "subject.email": {
                    "op": "not_regex",
                    "value": r".*@evil\.com",
                },
            },
        ))

        # evil.com blocked
        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"email": "hacker@evil.com"}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

        # company.com allowed
        decision = guard.authorize(
            subject=Subject(id="u2", attributes={"email": "alice@company.com"}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_abac_or_logic_with_multiple_evaluators(self) -> None:
        """ABAC OR conditions work when Guard has multiple evaluators registered."""
        store = InMemoryPolicyStore()
        guard = Guard(
            policy_store=store,
            evaluators=[RBACEvaluator(), ABACEvaluator()],
        )

        # Only ABAC policy — RBAC evaluator has no matching policies
        store.add(Policy(
            id="abac-dept",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="read",
            conditions={
                "condition_groups": [
                    {"subject.department": {"op": "eq", "value": "engineering"}},
                    {"subject.department": {"op": "eq", "value": "security"}},
                ],
            },
        ))

        # Security dept matches second group
        decision = guard.authorize(
            subject=Subject(
                id="u1",
                attributes={"department": "security"},
            ),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_or_groups_with_deny_override(self) -> None:
        """Deny policy with higher priority overrides OR allow."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

        store.add(Policy(
            id="allow",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="read",
            priority=0,
            conditions={
                "condition_groups": [
                    {"subject.department": {"op": "eq", "value": "engineering"}},
                ],
            },
        ))
        store.add(Policy(
            id="deny-banned",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="read",
            effect=PolicyEffect.DENY,
            priority=10,
            conditions={
                "subject.tags": {"op": "contains", "value": "banned"},
            },
        ))

        # Banned engineer → denied
        decision = guard.authorize(
            subject=Subject(
                id="u1",
                attributes={"department": "engineering", "tags": ["banned"]},
            ),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False
