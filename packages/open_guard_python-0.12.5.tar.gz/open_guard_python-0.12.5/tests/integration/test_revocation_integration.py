# tests/integration/test_revocation_integration.py
"""End-to-end push revocation tests (Phase 6 — ENH-010)."""

from datetime import UTC, datetime

from open_guard import (
    Action,
    ActorType,
    Guard,
    InMemoryDelegationStore,
    InMemoryPolicyStore,
    Policy,
    RBACEvaluator,
    Resource,
    Subject,
)
from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import (
    DelegationScope,
    RevocationEvent,
    RevocationEventType,
)
from open_guard.domain.services.session_manager import SessionManager


class TestRevocationIntegration:
    def setup_method(self) -> None:
        self.policy_store = InMemoryPolicyStore()
        self.delegation_store = InMemoryDelegationStore()
        self.session_store = InMemorySessionStore()
        self.stream = InMemoryRevocationStream()
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.received: list[RevocationEvent] = []

        self.guard = Guard(
            policy_store=self.policy_store,
            evaluators=[RBACEvaluator()],
            delegation_store=self.delegation_store,
            session_store=self.session_store,
            revocation_stream=self.stream,
            clock=lambda: self.now,
        )

        self.policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="read",
            resource_match={},
        ))

    def test_delegation_revoke_emits_event(self) -> None:
        self.stream.subscribe("t1", self.received.append)
        admin = Subject(id="admin", attributes={"roles": ["admin"]},
                        actor_type=ActorType.USER)
        agent = Subject(id="agent-1", attributes={"roles": []},
                        actor_type=ActorType.AGENT)

        delegation = self.guard.delegate(
            caller=admin,
            from_subject=admin,
            to_subject=agent,
            scopes=[DelegationScope(
                action_match="read", resource_type="doc",
            )],
            tenant_id="t1",
        )
        self.guard.revoke_delegation(delegation.id, caller=admin, tenant_id="t1")

        assert len(self.received) >= 1
        revoke_events = [
            e for e in self.received
            if e.event_type == RevocationEventType.DELEGATION_REVOKED
        ]
        assert len(revoke_events) >= 1
        assert revoke_events[0].delegation_id == delegation.id

    def test_session_deactivate_emits_event(self) -> None:
        self.stream.subscribe("t1", self.received.append)
        alice = Subject(id="alice", attributes={"roles": ["admin"]})
        session_mgr = SessionManager(
            session_store=self.session_store,
            clock=lambda: self.now,
            revocation_stream=self.stream,
        )
        session = session_mgr.create_session(
            subject=alice, tenant_id="t1", activated_roles=["admin"]
        )
        session_mgr.deactivate(session.id, "t1")

        deactivate_events = [
            e for e in self.received
            if e.event_type == RevocationEventType.SESSION_DEACTIVATED
        ]
        assert len(deactivate_events) == 1
        assert deactivate_events[0].session_id == session.id

    def test_subscriber_can_trigger_recheck(self) -> None:
        """Subscriber receives event and triggers re-authorization."""
        recheck_results = []

        def on_revoke(event: RevocationEvent) -> None:
            decision = self.guard.authorize(
                Subject(id="agent-1", attributes={"roles": []}),
                Action(name="read"),
                Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
                "t1",
            )
            recheck_results.append(decision.allowed)

        self.stream.subscribe("t1", on_revoke)
        admin = Subject(id="admin", attributes={"roles": ["admin"]},
                        actor_type=ActorType.USER)
        agent = Subject(id="agent-1", attributes={"roles": []},
                        actor_type=ActorType.AGENT)

        delegation = self.guard.delegate(
            caller=admin,
            from_subject=admin, to_subject=agent,
            scopes=[DelegationScope(action_match="read", resource_type="doc")],
            tenant_id="t1",
            re_check_on_use=False,
        )
        # Before revoke: agent has access via delegation
        decision = self.guard.authorize(
            agent, Action(name="read"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
        )
        assert decision.allowed is True

        # Revoke triggers subscriber which re-checks
        self.guard.revoke_delegation(delegation.id, caller=admin, tenant_id="t1")

        assert len(recheck_results) >= 1
        assert recheck_results[0] is False
