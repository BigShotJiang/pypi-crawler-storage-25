"""Integration tests — ReBAC through Guard end-to-end."""

from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import (
    Action,
    PermissionRule,
    Policy,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.domain.services.guard import Guard


class TestReBACGoogleDriveStyle:
    """Google Drive model: owner → editor → viewer role hierarchy via union."""

    def _setup(self) -> tuple[Guard, InMemoryRelationshipStore]:
        policy_store = InMemoryPolicyStore()
        rel_store = InMemoryRelationshipStore()

        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={
                    "owner": ["user"],
                    "editor": ["user"],
                    "viewer": ["user"],
                },
                permissions={
                    "can_edit": PermissionRule(
                        kind="union", relations=["owner", "editor"]
                    ),
                    "can_view": PermissionRule(
                        kind="union", relations=["owner", "editor", "viewer"]
                    ),
                },
            ),
        }

        evaluator = ReBACEvaluator(
            relationship_store=rel_store,
            type_definitions=type_defs,
        )
        guard = Guard(policy_store=policy_store, evaluators=[evaluator])

        policy_store.add(Policy(
            id="rebac-view",
            tenant_id="t1",
            evaluator_type="rebac",
            action_match="read",
            conditions={
                "object_type": "document",
                "permission": "can_view",
                "subject_type": "user",
            },
        ))
        policy_store.add(Policy(
            id="rebac-edit",
            tenant_id="t1",
            evaluator_type="rebac",
            action_match="write",
            conditions={
                "object_type": "document",
                "permission": "can_edit",
                "subject_type": "user",
            },
        ))

        return guard, rel_store

    def test_owner_can_view(self) -> None:
        guard, rel_store = self._setup()
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="owner",
            subject_type="user", subject_id="alice",
        ))

        decision = guard.authorize(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_viewer_cannot_edit(self) -> None:
        guard, rel_store = self._setup()
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="viewer",
            subject_type="user", subject_id="bob",
        ))

        decision = guard.authorize(
            subject=Subject(id="bob"),
            action=Action(name="write"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_editor_can_view(self) -> None:
        guard, rel_store = self._setup()
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="editor",
            subject_type="user", subject_id="charlie",
        ))

        decision = guard.authorize(
            subject=Subject(id="charlie"),
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True


class TestReBACTeamMembership:
    """Team membership: user in group → group has access → user has access."""

    def test_group_membership_grants_access(self) -> None:
        policy_store = InMemoryPolicyStore()
        rel_store = InMemoryRelationshipStore()

        evaluator = ReBACEvaluator(relationship_store=rel_store)
        guard = Guard(policy_store=policy_store, evaluators=[evaluator])

        policy_store.add(Policy(
            id="rebac-team",
            tenant_id="t1",
            evaluator_type="rebac",
            conditions={
                "object_type": "document",
                "permission": "viewer",
                "subject_type": "user",
            },
        ))

        # document:doc1#viewer@team:devs#member
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="viewer",
            subject_type="team", subject_id="devs",
            subject_relation="member",
        ))
        # team:devs#member@user:alice
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="team", object_id="devs",
            relation="member",
            subject_type="user", subject_id="alice",
        ))

        decision = guard.authorize(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True


class TestReBACArrowTraversal:
    """Folder inheritance: document.can_view = parent_folder->can_view."""

    def test_folder_viewer_can_view_child_documents(self) -> None:
        policy_store = InMemoryPolicyStore()
        rel_store = InMemoryRelationshipStore()

        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={"parent": ["folder"]},
                permissions={
                    "can_view": PermissionRule(
                        kind="arrow",
                        from_relation="parent",
                        to_permission="can_view",
                    ),
                },
            ),
            "folder": TypeDefinition(
                name="folder",
                relations={"viewer": ["user"]},
                permissions={
                    "can_view": PermissionRule(kind="union", relations=["viewer"]),
                },
            ),
        }

        evaluator = ReBACEvaluator(
            relationship_store=rel_store,
            type_definitions=type_defs,
        )
        guard = Guard(policy_store=policy_store, evaluators=[evaluator])

        policy_store.add(Policy(
            id="rebac-view",
            tenant_id="t1",
            evaluator_type="rebac",
            conditions={
                "object_type": "document",
                "permission": "can_view",
                "subject_type": "user",
            },
        ))

        # document:readme#parent@folder:engineering
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="readme",
            relation="parent",
            subject_type="folder", subject_id="engineering",
        ))
        # folder:engineering#viewer@user:alice
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="folder", object_id="engineering",
            relation="viewer",
            subject_type="user", subject_id="alice",
        ))

        decision = guard.authorize(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="readme", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True


class TestReBACDenyOverrideThroughGuard:
    """Deny policy at higher priority overrides allow."""

    def test_banned_user_denied_despite_relationship(self) -> None:
        policy_store = InMemoryPolicyStore()
        rel_store = InMemoryRelationshipStore()

        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={
                    "viewer": ["user"],
                    "banned": ["user"],
                },
                permissions={
                    "can_view_safe": PermissionRule(
                        kind="exclusion", base="viewer", subtract="banned"
                    ),
                },
            ),
        }

        evaluator = ReBACEvaluator(
            relationship_store=rel_store,
            type_definitions=type_defs,
        )
        guard = Guard(policy_store=policy_store, evaluators=[evaluator])

        policy_store.add(Policy(
            id="rebac-view",
            tenant_id="t1",
            evaluator_type="rebac",
            conditions={
                "object_type": "document",
                "permission": "can_view_safe",
                "subject_type": "user",
            },
        ))

        # alice is viewer AND banned
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="viewer",
            subject_type="user", subject_id="alice",
        ))
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="banned",
            subject_type="user", subject_id="alice",
        ))

        decision = guard.authorize(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False
