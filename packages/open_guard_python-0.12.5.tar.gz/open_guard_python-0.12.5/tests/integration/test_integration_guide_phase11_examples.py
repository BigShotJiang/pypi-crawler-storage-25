"""Executable mirrors of the Phase 11 (Async Parity) integration-guide snippets.

Each test corresponds to a code block in
``specs/architecture/integration-guide.md`` under the "Phase 11 — Async
Parity (v0.12.0)" section. If a snippet changes, the matching test
must change with it; CI surfaces any drift.
"""

from __future__ import annotations

from typing import Any

import pytest

from open_guard.domain.entities import (
    Action,
    ActorType,
    ApprovalRequirement,
    DecisionStatus,
    DelegationScope,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.services.async_guard import AsyncGuard


TENANT = "t1"


# 11.1 — AsyncGuard.list_authorized


class TestSection_11_1_ListAuthorized:
    @pytest.mark.asyncio
    async def test_basic_flow(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )

        # Wire a candidate source so there are docs to enumerate
        from open_guard.domain.ports.async_candidate_resource import (
            AsyncCandidateResourcePort,
        )

        class Cand(AsyncCandidateResourcePort):
            async def fetch_candidates(
                self,
                resource_type: str,
                tenant_id: str,
                prefilter: dict[str, Any] | None,
                cursor: dict[str, Any] | None,
                limit: int,
            ) -> tuple[list[Resource], dict[str, Any] | None]:
                return (
                    [
                        Resource(
                            id=f"d{i}",
                            resource_type="doc",
                            attributes={"type": "doc"},
                        )
                        for i in range(3)
                    ],
                    None,
                )

        guard._candidate_source = Cand()

        result = await guard.list_authorized(
            Subject(id="alice", attributes={"roles": ["reader"]}),
            "read",
            "doc",
            tenant_id=TENANT,
        )
        assert sorted(result.ids) == ["d0", "d1", "d2"]
        # next_cursor None when single page exhausts the source
        assert result.next_cursor is None


# 11.2 — Delegation fallback + authorize_and_consume


class TestSection_11_2_DelegationAndConsume:
    @pytest.mark.asyncio
    async def test_authorize_and_consume_via_delegation(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice",
            actor_type=ActorType.USER,
            attributes={"roles": ["owner"]},
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})

        await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[DelegationScope(action_match="read", resource_type="doc")],
            tenant_id=TENANT,
            max_uses=10,
            re_check_on_use=False,
        )

        decision = await guard.authorize_and_consume(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc"),
            TENANT,
        )
        assert decision.status == DecisionStatus.ALLOWED
        # Delegation contributed via "delegation" evaluator
        delegation_evals = [
            ev for ev in decision.evaluations if ev.evaluator == "delegation"
        ]
        assert len(delegation_evals) == 1


# 11.3 — Approval gating + approve / reject


class TestSection_11_3_ApprovalGating:
    @pytest.mark.asyncio
    async def test_pending_then_approve_then_allowed(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="write",
                requires_approval=ApprovalRequirement(
                    approvers=["manager-1"], quorum="any"
                ),
            )
        )

        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        doc = Resource(id="doc-1", resource_type="document")

        pending = await guard.authorize(alice, Action(name="write"), doc, TENANT)
        assert pending.status == DecisionStatus.PENDING_APPROVAL
        assert pending.approval_request_id is not None

        await guard.approve(
            pending.approval_request_id, TENANT, "manager-1", "looks fine"
        )

        decision = await guard.authorize(alice, Action(name="write"), doc, TENANT)
        assert decision.status == DecisionStatus.ALLOWED


# 11.4 — Service mode engine-agnostic registration


class TestSection_11_4_ServiceMode:
    def test_async_guard_registers_all_decision_endpoints(self) -> None:
        import asyncio

        from open_guard import build_async_guard
        from open_guard.service.app import create_app
        from open_guard.service.auth import ApiKeyAuth, InMemoryApiKeyStore

        guard = asyncio.run(build_async_guard())
        app = create_app(
            guard=guard, auth=ApiKeyAuth(InMemoryApiKeyStore())
        )
        paths = app.openapi()["paths"]
        # SERVICE_API_VERSION stays "v1"; all 4 decision endpoints register
        assert "/v1/authorize" in paths
        assert "/v1/authorize/traced" in paths
        assert "/v1/list_authorized" in paths
        assert "/v1/authorize_and_consume" in paths
