"""Integration tests for FastAPI middleware and dependencies."""

from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from open_guard import (
    ABACEvaluator,
    ActorType,
    Guard,
    InMemoryPolicyStore,
    Policy,
    RBACEvaluator,
    Subject,
)
from open_guard.api.fastapi import (
    OpenGuardMiddleware,
    RequireActor,
    RequirePermission,
    get_guard,
    get_optional_subject,
    get_subject,
)


def _create_app() -> tuple[FastAPI, Guard]:
    """Create a test FastAPI app with open-guard middleware."""
    store = InMemoryPolicyStore()
    rbac = RBACEvaluator(role_hierarchy={"admin": ["editor"], "editor": ["viewer"]})
    abac = ABACEvaluator()
    guard = Guard(policy_store=store, evaluators=[rbac, abac])

    # Add policies
    store.add(
        Policy(
            id="allow-viewer-read",
            tenant_id="tenant-1",
            evaluator_type="rbac",
            subject_match={"roles": ["viewer"]},
            action_match="read",
        )
    )
    store.add(
        Policy(
            id="allow-editor-write",
            tenant_id="tenant-1",
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match=["read", "write"],
        )
    )

    app = FastAPI()
    app.add_middleware(OpenGuardMiddleware, guard=guard)

    @app.get("/docs/{doc_id}")
    def get_doc(
        doc_id: str,
        _auth: object = Depends(RequirePermission("read", "document")),
    ) -> dict[str, str]:
        return {"doc_id": doc_id}

    @app.post("/docs/{doc_id}")
    def update_doc(
        doc_id: str,
        _auth: object = Depends(RequirePermission("write", "document")),
    ) -> dict[str, str]:
        return {"doc_id": doc_id, "status": "updated"}

    @app.get("/human-only")
    def human_only(
        subject: Subject = Depends(RequireActor(ActorType.USER)),
    ) -> dict[str, str]:
        return {"actor": subject.actor_type.value}

    @app.get("/guard-info")
    def guard_info(
        g: Guard = Depends(get_guard),
    ) -> dict[str, str]:
        return {"has_guard": "true"}

    @app.get("/subject-info")
    def subject_info(
        s: Subject = Depends(get_subject),
    ) -> dict[str, str]:
        return {"subject_id": s.id}

    @app.get("/optional-subject")
    def optional_subject(
        s: Subject | None = Depends(get_optional_subject),
    ) -> dict[str, str]:
        if s is None:
            return {"subject": "none"}
        return {"subject": s.id}

    return app, guard


def _set_subject_on_request(
    app: FastAPI,
    subject: Subject,
) -> None:
    """Add middleware to set subject on request.state for testing."""

    @app.middleware("http")
    async def set_subject(request: object, call_next: object) -> object:  # type: ignore[type-arg]
        from starlette.requests import Request

        req = request  # type: ignore[assignment]
        assert isinstance(req, Request)
        req.state.open_guard_subject = subject
        response = await call_next(req)  # type: ignore[misc]
        return response


class TestFastAPIIntegration:
    def test_guard_available(self) -> None:
        app, _ = _create_app()
        # Need subject for most endpoints, but guard-info just needs guard
        _set_subject_on_request(
            app,
            Subject(id="u1", attributes={"tenant_id": "tenant-1", "roles": ["viewer"]}),
        )
        client = TestClient(app)
        response = client.get("/guard-info")
        assert response.status_code == 200
        assert response.json()["has_guard"] == "true"

    def test_require_permission_allowed(self) -> None:
        app, _ = _create_app()
        _set_subject_on_request(
            app,
            Subject(id="u1", attributes={"tenant_id": "tenant-1", "roles": ["viewer"]}),
        )
        client = TestClient(app)
        response = client.get("/docs/doc-1")
        assert response.status_code == 200
        assert response.json()["doc_id"] == "doc-1"

    def test_require_permission_denied(self) -> None:
        app, _ = _create_app()
        # Viewer can't write
        _set_subject_on_request(
            app,
            Subject(id="u1", attributes={"tenant_id": "tenant-1", "roles": ["viewer"]}),
        )
        client = TestClient(app)
        response = client.post("/docs/doc-1")
        assert response.status_code == 403

    def test_require_permission_editor_can_write(self) -> None:
        app, _ = _create_app()
        _set_subject_on_request(
            app,
            Subject(id="u1", attributes={"tenant_id": "tenant-1", "roles": ["editor"]}),
        )
        client = TestClient(app)
        response = client.post("/docs/doc-1")
        assert response.status_code == 200

    def test_admin_inherits_editor(self) -> None:
        app, _ = _create_app()
        # Admin inherits editor which can write
        _set_subject_on_request(
            app,
            Subject(id="u1", attributes={"tenant_id": "tenant-1", "roles": ["admin"]}),
        )
        client = TestClient(app)
        response = client.post("/docs/doc-1")
        assert response.status_code == 200

    def test_no_subject_returns_401(self) -> None:
        app, _ = _create_app()
        client = TestClient(app)
        response = client.get("/subject-info")
        assert response.status_code == 401

    def test_require_actor_user_allowed(self) -> None:
        app, _ = _create_app()
        _set_subject_on_request(
            app,
            Subject(
                id="u1",
                actor_type=ActorType.USER,
                attributes={"tenant_id": "tenant-1"},
            ),
        )
        client = TestClient(app)
        response = client.get("/human-only")
        assert response.status_code == 200
        assert response.json()["actor"] == "user"

    def test_require_actor_agent_denied(self) -> None:
        app, _ = _create_app()
        _set_subject_on_request(
            app,
            Subject(
                id="agent-1",
                actor_type=ActorType.AGENT,
                attributes={"tenant_id": "tenant-1"},
            ),
        )
        client = TestClient(app)
        response = client.get("/human-only")
        assert response.status_code == 403

    def test_no_tenant_returns_403(self) -> None:
        app, _ = _create_app()
        # Subject without tenant_id
        _set_subject_on_request(app, Subject(id="u1", attributes={"roles": ["admin"]}))
        client = TestClient(app)
        response = client.get("/docs/doc-1")
        assert response.status_code == 403

    def test_optional_subject_present(self) -> None:
        app, _ = _create_app()
        _set_subject_on_request(
            app, Subject(id="u1", attributes={"tenant_id": "tenant-1"})
        )
        client = TestClient(app)
        response = client.get("/optional-subject")
        assert response.status_code == 200
        assert response.json()["subject"] == "u1"

    def test_optional_subject_absent(self) -> None:
        app, _ = _create_app()
        client = TestClient(app)
        response = client.get("/optional-subject")
        assert response.status_code == 200
        assert response.json()["subject"] == "none"

    def test_middleware_bridges_user_context(self) -> None:
        """Test that middleware converts UserContext to Subject."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])

        app = FastAPI()
        app.add_middleware(OpenGuardMiddleware, guard=guard)

        # Simulate open-shield-python's UserContext
        class MockUser:
            id = "user-from-shield"
            roles = ("admin",)
            scopes = ("read",)
            actor_type = "user"
            metadata = ()

        class MockTenant:
            tenant_id = "t1"

        class MockUserContext:
            user = MockUser()
            tenant = MockTenant()

        @app.middleware("http")
        async def inject_user_context(
            request: object, call_next: object
        ) -> object:  # type: ignore[type-arg]
            from starlette.requests import Request

            req = request  # type: ignore[assignment]
            assert isinstance(req, Request)
            req.state.user_context = MockUserContext()
            response = await call_next(req)  # type: ignore[misc]
            return response

        @app.get("/bridged")
        def bridged(s: Subject = Depends(get_subject)) -> dict[str, str]:
            return {"id": s.id, "actor": s.actor_type.value}

        client = TestClient(app)
        response = client.get("/bridged")
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == "user-from-shield"
        assert data["actor"] == "user"

    def test_middleware_bridges_user_context_no_tenant(self) -> None:
        """Test bridge when UserContext has no tenant."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[])

        app = FastAPI()
        app.add_middleware(OpenGuardMiddleware, guard=guard)

        class MockUser:
            id = "agent-1"
            roles = ()
            scopes = ()
            actor_type = "agent"
            metadata = ()

        class MockUserContext:
            user = MockUser()
            tenant = None

        @app.middleware("http")
        async def inject_user_context(
            request: object, call_next: object
        ) -> object:  # type: ignore[type-arg]
            from starlette.requests import Request

            req = request  # type: ignore[assignment]
            assert isinstance(req, Request)
            req.state.user_context = MockUserContext()
            response = await call_next(req)  # type: ignore[misc]
            return response

        @app.get("/bridged")
        def bridged(s: Subject = Depends(get_subject)) -> dict[str, str]:
            return {"id": s.id, "actor": s.actor_type.value}

        client = TestClient(app)
        response = client.get("/bridged")
        assert response.status_code == 200
        assert response.json()["actor"] == "agent"

    def test_middleware_bridges_unknown_actor_type(self) -> None:
        """Unknown actor_type defaults to USER."""
        store = InMemoryPolicyStore()
        guard = Guard(policy_store=store, evaluators=[])

        app = FastAPI()
        app.add_middleware(OpenGuardMiddleware, guard=guard)

        class MockUser:
            id = "bot-1"
            roles = ()
            scopes = ()
            actor_type = "unknown_type"
            metadata = ()

        class MockUserContext:
            user = MockUser()
            tenant = None

        @app.middleware("http")
        async def inject_user_context(
            request: object, call_next: object
        ) -> object:  # type: ignore[type-arg]
            from starlette.requests import Request

            req = request  # type: ignore[assignment]
            assert isinstance(req, Request)
            req.state.user_context = MockUserContext()
            response = await call_next(req)  # type: ignore[misc]
            return response

        @app.get("/bridged")
        def bridged(s: Subject = Depends(get_subject)) -> dict[str, str]:
            return {"id": s.id, "actor": s.actor_type.value}

        client = TestClient(app)
        response = client.get("/bridged")
        assert response.status_code == 200
        assert response.json()["actor"] == "user"  # fallback
