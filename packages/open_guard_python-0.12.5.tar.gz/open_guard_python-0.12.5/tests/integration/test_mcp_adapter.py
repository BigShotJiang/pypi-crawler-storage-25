"""Integration — end-to-end MCP adapter flows.

Exercises check_tool_call and list_authorized_tools through a complete
Guard stack (RBAC + ABAC + approvals) with a realistic MCP scenario:
- Agent acts on_behalf_of a user.
- Two MCP servers expose overlapping tool names.
- Policies use parameter-level ABAC for destructive operations.
- One tool requires approval before invocation.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.mcp.guard import MCPGuard
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequirement,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.services.guard import Guard


class _ToolSource(CandidateResourcePort):
    def __init__(self, tools: list[tuple[str, str]]) -> None:
        self._tools = tools

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._tools
        if prefilter and "server_id" in prefilter:
            items = [(s, t) for (s, t) in items if s == prefilter["server_id"]]
        resources = [
            Resource(
                id=f"tool:{s}:{t}",
                resource_type="tool",
                tenant_id=tenant_id,
                attributes={
                    "type": "tool",
                    "server_id": s,
                    "tool_name": t,
                    "params": {},
                },
            )
            for (s, t) in items
        ]
        return resources, None


class _StaticResolver:
    def __init__(self, subject: Subject) -> None:
        self._subject = subject

    def resolve(self, session_id: str, claims: dict[str, Any]) -> Subject:
        return self._subject


def _build_mcp_stack() -> tuple[MCPGuard, Guard, InMemoryApprovalStore]:
    policy_store = InMemoryPolicyStore()
    approval_store = InMemoryApprovalStore()

    # RBAC: researchers can invoke query_db and read_file (any server)
    for tn in ("query_db", "read_file"):
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["researcher"]},
                action_match="invoke",
                resource_match={"tool_name": tn},
            )
        )

    # ABAC: parameter-level restriction on query_db — no destructive SQL
    policy_store.add(
        Policy(
            tenant_id="t1",
            evaluator_type="abac",
            action_match="invoke",
            resource_match={"tool_name": "query_db"},
            conditions={
                "resource.params.query": {
                    "op": "not_regex",
                    "value": r"(?i)\b(DROP|DELETE|TRUNCATE)\b",
                }
            },
        )
    )

    # RBAC + approval: delete_file requires approval
    policy_store.add(
        Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["researcher"]},
            action_match="invoke",
            resource_match={"tool_name": "delete_file"},
            requires_approval=ApprovalRequirement(
                approvers=["admin"], quorum="any",
                ttl=timedelta(minutes=10), channel="slack",
            ),
        )
    )

    source = _ToolSource(
        [
            ("prod", "query_db"),
            ("prod", "read_file"),
            ("prod", "delete_file"),
            ("staging", "query_db"),
        ]
    )
    trusted_user = Subject(id="alice", attributes={"trusted": True})
    agent = Subject(
        id="agent-research",
        actor_type=ActorType.AGENT,
        attributes={"roles": ["researcher"]},
        on_behalf_of=trusted_user,
    )
    guard = Guard(
        policy_store=policy_store,
        evaluators=[RBACEvaluator(), ABACEvaluator()],
        approval_store=approval_store,
        candidate_source=source,
    )
    mcp = MCPGuard(
        guard=guard,
        resolver=_StaticResolver(agent),
        default_tenant_id="t1",
    )
    return mcp, guard, approval_store


class TestMCPEndToEnd:
    def test_safe_query_allowed(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        result = mcp.check_tool_call(
            "sess", "query_db", {"query": "SELECT 1"}, "prod"
        )
        assert result.is_allowed()

    def test_destructive_query_denied_by_param_abac(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        result = mcp.check_tool_call(
            "sess", "query_db", {"query": "DROP TABLE users"}, "prod"
        )
        assert result.is_denied()

    def test_unknown_tool_denied(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        result = mcp.check_tool_call(
            "sess", "send_email", {"to": "a@b.com"}, "prod"
        )
        assert result.is_denied()

    def test_schema_hygiene_denies_before_authz(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        schema = {
            "type": "object",
            "required": ["query"],
            "properties": {"query": {"type": "string"}},
        }
        result = mcp.check_tool_call(
            "sess", "query_db", {}, "prod", tool_schema=schema
        )
        assert result.is_denied()
        assert result.reason is not None
        assert result.reason.startswith("schema_violation")

    def test_delete_file_pending_then_approved(self) -> None:
        mcp, guard, _ = _build_mcp_stack()

        pending = mcp.check_tool_call(
            "sess", "delete_file", {"path": "/tmp/x"}, "prod"
        )
        assert pending.is_pending()
        assert pending.pending is not None
        assert pending.pending.approvers == ["admin"]
        assert pending.pending.channel == "slack"

        guard.approve(
            pending.pending.approval_request_id, "t1", approver="admin",
        )

        allowed = mcp.check_tool_call(
            "sess", "delete_file", {"path": "/tmp/x"}, "prod"
        )
        assert allowed.is_allowed()

    def test_traced_call_returns_decision_trace(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        result, trace = mcp.check_tool_call_traced(
            "sess", "query_db", {"query": "SELECT 1"}, "prod"
        )
        assert result.is_allowed()
        assert trace is not None
        assert trace.schema_version == "1.0"
        # Chain surfaces in trace
        assert any(snap.id == "alice" for snap in trace.actor_chain)

    def test_list_authorized_tools_multi_server(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        all_tools = mcp.list_authorized_tools("sess")
        # delete_file appears here because list_authorized filters by
        # ALLOWED decisions — and delete_file is PENDING, not ALLOWED,
        # so it's excluded. query_db and read_file across both servers
        # should appear.
        assert set(all_tools.ids) == {
            "tool:prod:query_db",
            "tool:prod:read_file",
            "tool:staging:query_db",
        }

    def test_list_authorized_tools_prefiltered_by_server(self) -> None:
        mcp, _, _ = _build_mcp_stack()
        prod_only = mcp.list_authorized_tools("sess", server_id="prod")
        assert set(prod_only.ids) == {
            "tool:prod:query_db",
            "tool:prod:read_file",
        }
