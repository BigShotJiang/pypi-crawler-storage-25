# tests/integration/test_integration_guide_phase6_examples.py
"""Executable mirrors of the Phase 6 section in integration-guide.md.

One test per code block in `## Phase 6 — Production Hardening (v0.7.0)`.
If a future change breaks a guide example this file fails — preventing
the guide from drifting away from reality.
"""

from __future__ import annotations

from open_guard import (
    ABACEvaluator,
    Action,
    ActorType,
    Guard,
    InMemoryDelegationStore,
    InMemoryPolicyStore,
    Policy,
    RBACEvaluator,
    Resource,
    Subject,
)
from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import (
    DelegationScope,
    RevocationEvent,
    RevocationEventType,
    SessionStatus,
)
from open_guard.domain.services.session_manager import SessionManager

# ---------------------------------------------------------------------------
# Wiring Guard with sessions
# ---------------------------------------------------------------------------


def test_wiring_guard_with_sessions() -> None:
    """Guard accepts session_store; SessionManager uses same store."""
    session_store = InMemorySessionStore()
    session_mgr = SessionManager(session_store=session_store)

    guard = Guard(
        policy_store=InMemoryPolicyStore(),
        evaluators=[RBACEvaluator()],
        session_store=session_store,
    )
    # Verify objects wired correctly (no errors)
    assert guard is not None
    assert session_mgr is not None


# ---------------------------------------------------------------------------
# Creating a session
# ---------------------------------------------------------------------------


def test_creating_a_session() -> None:
    """create_session returns an ACTIVE session with a subset of the subject's roles."""
    session_store = InMemorySessionStore()
    session_mgr = SessionManager(session_store=session_store)

    alice = Subject(id="alice", attributes={"roles": ["admin", "editor"]})

    session = session_mgr.create_session(
        subject=alice,
        tenant_id="acme",
        activated_roles=["editor"],
    )

    assert session.status == SessionStatus.ACTIVE
    assert "editor" in session.activated_roles
    assert "admin" not in session.activated_roles


# ---------------------------------------------------------------------------
# Authorize with session_id — role narrowing
# ---------------------------------------------------------------------------


def test_authorize_with_session_id_narrows_roles() -> None:
    """Admin+editor subject with editor-only session: write allowed, delete denied."""
    session_store = InMemorySessionStore()
    session_mgr = SessionManager(session_store=session_store)

    store = InMemoryPolicyStore()
    store.add(Policy(
        tenant_id="acme", evaluator_type="rbac",
        subject_match={"roles": ["admin"]},
        action_match="delete",
        resource_match={"type": "doc"},
    ))
    store.add(Policy(
        tenant_id="acme", evaluator_type="rbac",
        subject_match={"roles": ["editor"]},
        action_match="write",
        resource_match={"type": "doc"},
    ))

    guard = Guard(
        policy_store=store,
        evaluators=[RBACEvaluator()],
        session_store=session_store,
    )

    alice = Subject(id="alice", attributes={"roles": ["admin", "editor"]})

    # Session only activates editor
    session = session_mgr.create_session(
        subject=alice,
        tenant_id="acme",
        activated_roles=["editor"],
    )

    doc = Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"})

    write_ok = guard.authorize(alice, Action(name="write"), doc, "acme",
                               session_id=session.id)
    assert write_ok.allowed is True

    delete_ok = guard.authorize(alice, Action(name="delete"), doc, "acme",
                                session_id=session.id)
    assert delete_ok.allowed is False


# ---------------------------------------------------------------------------
# session.* ABAC namespace
# ---------------------------------------------------------------------------


def test_session_abac_namespace_activated_roles() -> None:
    """ABAC policy on session.activated_roles matches/misses correctly."""
    session_store = InMemorySessionStore()
    session_mgr = SessionManager(session_store=session_store)

    store = InMemoryPolicyStore()
    store.add(Policy(
        tenant_id="acme", evaluator_type="abac",
        action_match="promote",
        conditions={
            "session.activated_roles": {"op": "contains", "value": "editor"},
        },
    ))

    guard = Guard(
        policy_store=store,
        evaluators=[ABACEvaluator()],
        session_store=session_store,
    )

    alice = Subject(id="alice", attributes={"roles": ["editor"]})
    bob = Subject(id="bob", attributes={"roles": ["viewer"]})

    session_with_editor = session_mgr.create_session(
        subject=alice,
        tenant_id="acme",
        activated_roles=["editor"],
    )
    decision = guard.authorize(
        alice, Action(name="promote"),
        Resource(id="k1", resource_type="knowledge"),
        "acme",
        session_id=session_with_editor.id,
    )
    assert decision.allowed is True

    session_viewer_only = session_mgr.create_session(
        subject=bob,
        tenant_id="acme",
        activated_roles=["viewer"],
    )
    decision2 = guard.authorize(
        bob,
        Action(name="promote"),
        Resource(id="k2", resource_type="knowledge"),
        "acme",
        session_id=session_viewer_only.id,
    )
    assert decision2.allowed is False


# ---------------------------------------------------------------------------
# Taint marking for LLM-generated attributes
# ---------------------------------------------------------------------------


def test_taint_marking_blocks_untrusted_attributes() -> None:
    """trusted_only condition rejects tainted (LLM-generated) attributes."""
    store = InMemoryPolicyStore()
    store.add(Policy(
        tenant_id="acme", evaluator_type="abac",
        action_match="read",
        conditions={
            "resource.classification": {
                "op": "eq", "value": "public",
                "trusted_only": True,
            },
        },
    ))
    guard = Guard(policy_store=store, evaluators=[ABACEvaluator()])

    # LLM claims classification=public but it is untrusted
    llm_resource = Resource(
        id="secret-doc", resource_type="doc",
        attributes={
            "classification": "public",
            "_trusted": {"classification": False},
        },
    )
    decision = guard.authorize(
        Subject(id="agent-1", attributes={}),
        Action(name="read"),
        llm_resource,
        "acme",
    )
    assert decision.allowed is False

    # Trusted resource (no taint marker) — passes
    trusted_resource = Resource(
        id="pub-doc", resource_type="doc",
        attributes={"classification": "public"},
    )
    decision2 = guard.authorize(
        Subject(id="agent-1", attributes={}),
        Action(name="read"),
        trusted_resource,
        "acme",
    )
    assert decision2.allowed is True


# ---------------------------------------------------------------------------
# Setting up push revocation
# ---------------------------------------------------------------------------


def test_push_revocation_session_deactivation_fires_event() -> None:
    """Deactivating a session publishes SESSION_DEACTIVATED to the stream."""
    stream = InMemoryRevocationStream()
    received: list[RevocationEvent] = []
    stream.subscribe("acme", received.append)

    session_store2 = InMemorySessionStore()
    session_mgr2 = SessionManager(
        session_store=session_store2,
        revocation_stream=stream,
    )

    alice2 = Subject(id="alice", attributes={"roles": ["admin"]})
    sess = session_mgr2.create_session(
        subject=alice2, tenant_id="acme", activated_roles=["admin"],
    )
    session_mgr2.deactivate(sess.id, "acme")

    assert len(received) == 1
    assert received[0].event_type == RevocationEventType.SESSION_DEACTIVATED
    assert received[0].session_id == sess.id


# ---------------------------------------------------------------------------
# Agent re-check pattern
# ---------------------------------------------------------------------------


def test_agent_recheck_pattern_on_delegation_revoke() -> None:
    """Subscriber triggers re-authorization on DELEGATION_REVOKED; result is DENY."""
    recheck_results: list[bool] = []

    delegation_store = InMemoryDelegationStore()
    revocation_stream2 = InMemoryRevocationStream()

    policy_store2 = InMemoryPolicyStore()
    policy_store2.add(Policy(
        tenant_id="acme", evaluator_type="rbac",
        subject_match={"roles": ["admin"]},
        action_match="read",
        resource_match={},
    ))

    agent_subject = Subject(id="agent-1", attributes={"roles": []},
                            actor_type=ActorType.AGENT)

    guard_with_delegation = Guard(
        policy_store=policy_store2,
        evaluators=[RBACEvaluator()],
        delegation_store=delegation_store,
        revocation_stream=revocation_stream2,
    )

    def on_revocation(event: RevocationEvent) -> None:
        recheck = guard_with_delegation.authorize(
            agent_subject,
            Action(name="read"),
            Resource(id="doc-42", resource_type="document"),
            "acme",
        )
        recheck_results.append(recheck.allowed)

    revocation_stream2.subscribe("acme", on_revocation)

    admin_subject = Subject(id="admin-1", attributes={"roles": ["admin"]},
                            actor_type=ActorType.USER)

    delegation = guard_with_delegation.delegate(
        caller=admin_subject,
        from_subject=admin_subject,
        to_subject=agent_subject,
        scopes=[DelegationScope(action_match="read", resource_type="document")],
        tenant_id="acme",
        re_check_on_use=False,
    )

    # Before revoke: agent has access via delegation
    before = guard_with_delegation.authorize(
        agent_subject, Action(name="read"),
        Resource(id="doc-42", resource_type="document"),
        "acme",
    )
    assert before.allowed is True

    # Revoke → subscriber fires → re-check → DENY
    guard_with_delegation.revoke_delegation(delegation.id, caller=admin_subject,
                                            tenant_id="acme")
    assert len(recheck_results) >= 1
    assert recheck_results[0] is False
