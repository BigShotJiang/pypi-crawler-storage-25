"""Integration — pending_approval flow end-to-end through Guard."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.domain.entities import (
    Action,
    ApprovalRequirement,
    ApprovalStatus,
    DecisionStatus,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard


class _Clock:
    def __init__(self, start: datetime) -> None:
        self.now = start

    def advance(self, delta: timedelta) -> None:
        self.now += delta

    def __call__(self) -> datetime:
        return self.now


def _policy_requiring(
    approvers: list[str],
    quorum: int | str = "any",
    ttl: timedelta | None = None,
) -> Policy:
    return Policy(
        id="p-approval",
        tenant_id="t1",
        evaluator_type="rbac",
        effect=PolicyEffect.ALLOW,
        action_match="send",
        subject_match={"roles": ["user"]},
        requires_approval=ApprovalRequirement(
            approvers=approvers, quorum=quorum, ttl=ttl, channel="slack"
        ),
    )


def _guard(
    policies: list[Policy], clock: _Clock | None = None
) -> tuple[Guard, InMemoryApprovalStore]:
    ps = InMemoryPolicyStore()
    for p in policies:
        ps.add(p)
    approvals = InMemoryApprovalStore()
    return (
        Guard(
            policy_store=ps,
            evaluators=[RBACEvaluator()],
            approval_store=approvals,
            clock=clock,
        ),
        approvals,
    )


def _ctx() -> tuple[Subject, Action, Resource]:
    return (
        Subject(id="alice", attributes={"roles": ["user"]}),
        Action(name="send"),
        Resource(id="email-1", resource_type="email"),
    )


class TestApprovalFlow:
    def test_pending_then_approve_then_allow(self) -> None:
        guard, _ = _guard([_policy_requiring(["mgr"])])
        s, a, r = _ctx()
        pending = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert pending.status == DecisionStatus.PENDING_APPROVAL
        assert pending.approval_request_id is not None

        guard.approve(pending.approval_request_id, "t1", "mgr")
        final = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert final.status == DecisionStatus.ALLOWED

    def test_pending_then_reject_then_deny(self) -> None:
        guard, _ = _guard([_policy_requiring(["mgr"])])
        s, a, r = _ctx()
        pending = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert pending.approval_request_id is not None
        guard.reject(
            pending.approval_request_id, "t1", "mgr", reason="too risky"
        )
        final = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert final.status == DecisionStatus.DENIED
        assert "too risky" in final.reason

    def test_expired_creates_fresh_pending(self) -> None:
        clock = _Clock(datetime(2026, 4, 17, 12, tzinfo=UTC))
        guard, _ = _guard(
            [_policy_requiring(["mgr"], ttl=timedelta(minutes=5))],
            clock=clock,
        )
        s, a, r = _ctx()
        p1 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        clock.advance(timedelta(minutes=10))
        p2 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert p2.status == DecisionStatus.PENDING_APPROVAL
        assert p2.approval_request_id != p1.approval_request_id

    def test_quorum_all_requires_every_approver(self) -> None:
        guard, _ = _guard(
            [_policy_requiring(["alice", "bob"], quorum="all")]
        )
        s, a, r = _ctx()
        pending = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert pending.approval_request_id is not None
        guard.approve(pending.approval_request_id, "t1", "alice")
        # Still pending — need bob too
        mid = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert mid.status == DecisionStatus.PENDING_APPROVAL
        guard.approve(pending.approval_request_id, "t1", "bob")
        final = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert final.status == DecisionStatus.ALLOWED

    def test_idempotent_same_request_id_while_pending(self) -> None:
        guard, _ = _guard([_policy_requiring(["mgr"])])
        s, a, r = _ctx()
        d1 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        d2 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        d3 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        first_id = d1.approval_request_id
        assert d2.approval_request_id == first_id
        assert d3.approval_request_id == first_id

    def test_approval_status_stored(self) -> None:
        guard, approvals = _guard([_policy_requiring(["mgr"])])
        s, a, r = _ctx()
        pending = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert pending.approval_request_id is not None
        guard.approve(pending.approval_request_id, "t1", "mgr", reason="ok")
        stored = approvals.get(pending.approval_request_id, "t1")
        assert stored is not None
        assert stored.status == ApprovalStatus.APPROVED

    def test_different_resource_different_pending(self) -> None:
        guard, _ = _guard([_policy_requiring(["mgr"])])
        s = Subject(id="alice", attributes={"roles": ["user"]})
        a = Action(name="send")
        r1 = Resource(id="e1", resource_type="email")
        r2 = Resource(id="e2", resource_type="email")
        p1 = guard.authorize(subject=s, action=a, resource=r1, tenant_id="t1")
        p2 = guard.authorize(subject=s, action=a, resource=r2, tenant_id="t1")
        assert p1.approval_request_id != p2.approval_request_id
