"""Full async integration flow (Phase 7 -- T12)."""

from __future__ import annotations

import pytest

from open_guard.domain.entities import Action, Policy, Resource, Subject
from open_guard.domain.services.async_guard import AsyncGuard


class TestAsyncEndToEnd:
    @pytest.mark.asyncio
    async def test_full_rbac_flow_memory(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="write",
                resource_match={"type": "doc"},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        decision = await guard.authorize(
            Subject(id="bob", attributes={"roles": ["editor"]}),
            Action(name="write"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_abac_conditions(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="abac",
                subject_match={},
                action_match="read",
                resource_match={},
                conditions={
                    "resource.classification": {"op": "eq", "value": "public"},
                },
                effect="allow",
                priority=0,
            )
        )
        decision = await guard.authorize(
            Subject(id="anyone", attributes={}),
            Action(name="read"),
            Resource(
                id="d1",
                resource_type="doc",
                attributes={"classification": "public"},
            ),
            tenant_id="t1",
        )
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_deny_by_default(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        decision = await guard.authorize(
            Subject(id="alice", attributes={}),
            Action(name="anything"),
            Resource(id="r1", resource_type="stuff", attributes={}),
            tenant_id="t1",
        )
        assert not decision.allowed

    @pytest.mark.asyncio
    async def test_multiple_evaluators_deny_wins(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        # Allow via RBAC
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["admin"]},
                action_match="read",
                resource_match={"type": "doc"},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        # Deny via ABAC (higher priority)
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="abac",
                subject_match={},
                action_match="read",
                resource_match={},
                conditions={
                    "resource.classification": {"op": "eq", "value": "secret"},
                },
                effect="deny",
                priority=10,
            )
        )
        decision = await guard.authorize(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(
                id="d1",
                resource_type="doc",
                attributes={"type": "doc", "classification": "secret"},
            ),
            tenant_id="t1",
        )
        assert not decision.allowed

    @pytest.mark.asyncio
    async def test_traced_returns_evaluator_info(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["viewer"]},
                action_match="read",
                resource_match={},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        decision, trace = await guard.authorize_traced(
            Subject(id="alice", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={}),
            tenant_id="t1",
        )
        assert decision.allowed
        assert trace.duration_ms >= 0
        assert len(trace.actor_chain) >= 1
