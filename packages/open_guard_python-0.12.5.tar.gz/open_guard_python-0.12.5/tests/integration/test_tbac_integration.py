"""Integration tests — TBAC through Guard end-to-end."""

from datetime import UTC, datetime

from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard
from open_guard.domain.services.task_manager import TaskManager


def _clock(hour: int = 12, day: int = 16) -> datetime:
    return datetime(2026, 4, day, hour, 0, 0, tzinfo=UTC)


class TestTBACThroughGuard:
    def test_time_window_policy_allows(self) -> None:
        policy_store = InMemoryPolicyStore()
        tbac = TBACEvaluator(clock=lambda: _clock(hour=10))
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="read",
            conditions={
                "time_window": {
                    "not_before": "2026-04-16T00:00:00Z",
                    "not_after": "2026-04-17T00:00:00Z",
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_time_window_policy_denies_outside(self) -> None:
        policy_store = InMemoryPolicyStore()
        tbac = TBACEvaluator(clock=lambda: _clock(day=20))
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="read",
            conditions={
                "time_window": {
                    "not_before": "2026-04-16T00:00:00Z",
                    "not_after": "2026-04-17T00:00:00Z",
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_task_scoped_policy_with_guard(self) -> None:
        policy_store = InMemoryPolicyStore()
        task_store = InMemoryTaskStore()
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: _clock())
        task_mgr = TaskManager(task_store=task_store, clock=lambda: _clock())
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        # Create and activate a task
        task = task_mgr.create_task(
            tenant_id="t1",
            actor_id="agent-1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        task = task_mgr.activate_task(task.id, "t1")

        # Add task-scoped policy
        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="read",
            conditions={"task_id": task.id},
        ))

        # Allowed: action and resource match task scope
        decision = guard.authorize(
            subject=Subject(id="agent-1", actor_type=ActorType.AGENT),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

        # Denied: action outside task scope
        decision = guard.authorize(
            subject=Subject(id="agent-1", actor_type=ActorType.AGENT),
            action=Action(name="delete"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_task_completed_revokes_access(self) -> None:
        policy_store = InMemoryPolicyStore()
        task_store = InMemoryTaskStore()
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: _clock())
        task_mgr = TaskManager(task_store=task_store, clock=lambda: _clock())
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        task = task_mgr.create_task(tenant_id="t1", actor_id="agent-1")
        task = task_mgr.activate_task(task.id, "t1")

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="*",
            conditions={"task_id": task.id},
        ))

        # Allowed while active
        decision = guard.authorize(
            subject=Subject(id="agent-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

        # Complete the task
        task_mgr.complete_task(task.id, "t1")

        # Denied after completion
        decision = guard.authorize(
            subject=Subject(id="agent-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_rbac_and_tbac_combined(self) -> None:
        """RBAC + TBAC evaluators work together through Guard."""
        policy_store = InMemoryPolicyStore()
        task_store = InMemoryTaskStore()
        rbac = RBACEvaluator()
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: _clock(hour=10))
        guard = Guard(policy_store=policy_store, evaluators=[rbac, tbac])

        # RBAC allow
        policy_store.add(Policy(
            id="rbac-p1",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
        ))

        # TBAC deny (within time window — deny effect)
        policy_store.add(Policy(
            id="tbac-deny",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="*",
            effect=PolicyEffect.DENY,
            conditions={
                "time_window": {
                    "not_before": "2026-04-16T09:00:00Z",
                    "not_after": "2026-04-16T17:00:00Z",
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-1", attributes={"roles": ["admin"]}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        # RBAC allows, TBAC denies (within deny window) -> denied
        assert decision.allowed is False

    def test_schedule_with_timezone_through_guard(self) -> None:
        policy_store = InMemoryPolicyStore()
        # 2026-04-16 04:00 UTC = 09:30 IST
        tbac = TBACEvaluator(clock=lambda: _clock(hour=4))
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="*",
            conditions={
                "schedule": {
                    "days": [1, 2, 3, 4, 5],
                    "time_range": ["09:00", "18:00"],
                    "timezone": "Asia/Kolkata",
                }
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-in"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True
