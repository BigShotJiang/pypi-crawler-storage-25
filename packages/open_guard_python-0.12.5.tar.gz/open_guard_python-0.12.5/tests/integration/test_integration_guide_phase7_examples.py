"""Executable mirrors of Phase 7 integration guide examples.

Every code block in the Phase 7 section of ``specs/architecture/integration-guide.md``
has a corresponding test here. If a future change breaks a guide example, this file
fails -- preventing the guide from drifting away from reality.
"""

from __future__ import annotations

import pytest

from open_guard import (
    Action,
    AsyncGuard,
    Guard,
    Policy,
    PolicyAdmin,
    Resource,
    Subject,
)

# -----------------------------------------------------------------------
# 7.1 Guard Factory -- Zero-Config Setup
# -----------------------------------------------------------------------


class TestGuardFactory:
    """SS7.1 Guard Factory."""

    def test_memory_backend(self) -> None:
        guard = Guard.from_config(backend="memory")
        assert guard is not None

    def test_sqlite_backend(self, tmp_path) -> None:
        guard = Guard.from_config(f"sqlite:///{tmp_path}/test.db")
        assert guard is not None


# -----------------------------------------------------------------------
# 7.2 AsyncGuard -- Native Async
# -----------------------------------------------------------------------


class TestAsyncGuard:
    """SS7.2 AsyncGuard."""

    @pytest.mark.asyncio
    async def test_async_authorize(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["admin"]},
                action_match="*",
                resource_match={},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        decision = await guard.authorize(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={}),
            tenant_id="t1",
        )
        assert decision.allowed


# -----------------------------------------------------------------------
# 7.3 PolicyAdmin SDK
# -----------------------------------------------------------------------


class TestPolicyAdminSDK:
    """SS7.3 PolicyAdmin SDK."""

    def test_create_policy_and_authorize(self) -> None:
        guard = Guard.from_config(backend="memory")
        admin = PolicyAdmin(guard)
        admin.create_policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match="write",
            resource_match={"type": "doc"},
        )
        decision = guard.authorize(
            Subject(id="alice", attributes={"roles": ["editor"]}),
            Action(name="write"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    def test_assign_role(self) -> None:
        guard = Guard.from_config(backend="memory")
        admin = PolicyAdmin(guard)
        policy = admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="editor",
        )
        assert policy is not None

    def test_add_relationship(self) -> None:
        guard = Guard.from_config(backend="memory")
        admin = PolicyAdmin(guard)
        rel = admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member",
            object_type="project",
            object_id="p1",
        )
        assert rel is not None


# -----------------------------------------------------------------------
# 7.4 Admin REST API
# -----------------------------------------------------------------------


class TestAdminRouter:
    """SS7.4 Admin REST API."""

    def test_mount_and_create_policy(self) -> None:
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from open_guard.api.fastapi.admin_router import AdminRouter

        guard = Guard.from_config(backend="memory")
        admin = PolicyAdmin(guard)
        app = FastAPI()
        app.include_router(AdminRouter(admin=admin), prefix="/admin")
        client = TestClient(app)

        resp = client.post(
            "/admin/policies",
            json={
                "tenant_id": "t1",
                "evaluator_type": "rbac",
                "subject_match": {"roles": ["viewer"]},
                "action_match": "read",
            },
        )
        assert resp.status_code == 201

        resp = client.get("/admin/health")
        assert resp.status_code == 200


# -----------------------------------------------------------------------
# 7.5 Database Schema Tooling
# -----------------------------------------------------------------------


class TestDBTooling:
    """SS7.5 Database Schema Tooling."""

    def test_create_all_tables(self, tmp_path) -> None:
        from sqlalchemy import create_engine, inspect

        from open_guard.db import create_all_tables

        engine = create_engine(f"sqlite:///{tmp_path}/test.db")
        create_all_tables(engine)
        inspector = inspect(engine)
        assert "open_guard_policies" in inspector.get_table_names()

    def test_get_ddl(self) -> None:
        from open_guard.db import get_ddl

        ddl = get_ddl(dialect="postgresql")
        assert "CREATE TABLE" in ddl
        assert "open_guard_policies" in ddl
