"""Integration tests — SQLAlchemy stores through Guard end-to-end."""

from datetime import UTC, datetime

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.stores.sql import (
    SQLAlchemyPolicyStore,
    SQLAlchemyTaskStore,
)
from open_guard.adapters.stores.sql_relationship import SQLAlchemyRelationshipStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    PermissionRule,
    Policy,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.domain.services.guard import Guard
from open_guard.domain.services.task_manager import TaskManager


class TestGuardWithSQLStores:
    def test_rbac_through_sql_policy_store(self) -> None:
        policy_store = SQLAlchemyPolicyStore.from_url("sqlite://")
        policy_store.create_tables()
        guard = Guard(policy_store=policy_store, evaluators=[RBACEvaluator()])

        policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
        ))

        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"roles": ["admin"]}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_abac_with_or_logic_through_sql(self) -> None:
        policy_store = SQLAlchemyPolicyStore.from_url("sqlite://")
        policy_store.create_tables()
        guard = Guard(policy_store=policy_store, evaluators=[ABACEvaluator()])

        policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "condition_groups": [
                    {"subject.department": {"op": "eq", "value": "engineering"}},
                    {"subject.department": {"op": "eq", "value": "security"}},
                ],
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"department": "security"}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_tbac_through_sql_stores(self) -> None:
        policy_store = SQLAlchemyPolicyStore.from_url("sqlite://")
        task_store = SQLAlchemyTaskStore(policy_store._engine)  # share engine
        policy_store.create_tables()

        clock_time = datetime(2026, 4, 16, 12, 0, 0, tzinfo=UTC)
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: clock_time)
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        # Create active task
        task_manager = TaskManager(
            task_store=task_store, clock=lambda: clock_time
        )
        task = task_manager.create_task(
            tenant_id="t1",
            actor_id="agent-1",
            actor_type=ActorType.AGENT,
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        task = task_manager.activate_task(task.id, "t1")

        policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="tbac",
            action_match="read",
            conditions={"task_id": task.id},
        ))

        decision = guard.authorize(
            subject=Subject(id="agent-1", actor_type=ActorType.AGENT),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_rebac_through_sql_stores(self) -> None:
        policy_store = SQLAlchemyPolicyStore.from_url("sqlite://")
        rel_store = SQLAlchemyRelationshipStore(policy_store._engine)
        policy_store.create_tables()

        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={"owner": ["user"], "viewer": ["user"]},
                permissions={
                    "can_view": PermissionRule(
                        kind="union", relations=["owner", "viewer"]
                    ),
                },
            ),
        }

        evaluator = ReBACEvaluator(
            relationship_store=rel_store, type_definitions=type_defs,
        )
        guard = Guard(policy_store=policy_store, evaluators=[evaluator])

        policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rebac",
            action_match="read",
            conditions={
                "object_type": "document",
                "permission": "can_view",
                "subject_type": "user",
            },
        ))
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="owner",
            subject_type="user", subject_id="alice",
        ))

        decision = guard.authorize(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_rebac_team_membership_through_sql(self) -> None:
        """Indirect membership via subject set through SQL stores."""
        policy_store = SQLAlchemyPolicyStore.from_url("sqlite://")
        rel_store = SQLAlchemyRelationshipStore(policy_store._engine)
        policy_store.create_tables()

        evaluator = ReBACEvaluator(relationship_store=rel_store)
        guard = Guard(policy_store=policy_store, evaluators=[evaluator])

        policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rebac",
            conditions={
                "object_type": "document",
                "permission": "viewer",
                "subject_type": "user",
            },
        ))

        # document:doc1#viewer@team:devs#member
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="viewer",
            subject_type="team", subject_id="devs",
            subject_relation="member",
        ))
        # team:devs#member@user:alice
        rel_store.write_tuple(RelationTuple(
            tenant_id="t1",
            object_type="team", object_id="devs",
            relation="member",
            subject_type="user", subject_id="alice",
        ))

        decision = guard.authorize(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_tenant_isolation_across_sql_stores(self) -> None:
        """Policies in tenant t1 do not leak to tenant t2."""
        policy_store = SQLAlchemyPolicyStore.from_url("sqlite://")
        policy_store.create_tables()
        guard = Guard(policy_store=policy_store, evaluators=[RBACEvaluator()])

        policy_store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
        ))

        # t2 has no policies
        decision = guard.authorize(
            subject=Subject(id="u1", attributes={"roles": ["admin"]}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t2",
        )
        assert decision.allowed is False
