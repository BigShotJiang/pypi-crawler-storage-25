# tests/integration/test_session_integration.py
"""End-to-end session authorization tests (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard import (
    Action,
    Guard,
    InMemoryPolicyStore,
    Policy,
    RBACEvaluator,
    Resource,
    Subject,
)
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.exceptions import SessionNotFoundError
from open_guard.domain.services.session_manager import SessionManager


class TestSessionIntegration:
    def setup_method(self) -> None:
        self.policy_store = InMemoryPolicyStore()
        self.session_store = InMemorySessionStore()
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.rbac = RBACEvaluator()
        self.guard = Guard(
            policy_store=self.policy_store,
            evaluators=[self.rbac],
            session_store=self.session_store,
            clock=lambda: self.now,
        )

        # Policies
        self.policy_store.add(Policy(
            id="p-admin",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="delete",
            resource_match={"type": "doc"},
        ))
        self.policy_store.add(Policy(
            id="p-editor",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match="write",
            resource_match={"type": "doc"},
        ))

    def test_authorize_with_session_id(self) -> None:
        """session_id on authorize() scopes the evaluation to session roles."""
        alice = Subject(
            id="alice",
            attributes={"roles": ["admin", "editor", "viewer"]},
        )
        session_mgr = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        session = session_mgr.create_session(
            subject=alice,
            tenant_id="t1",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )

        # With session: editor can write, but NOT delete (admin-only)
        decision = self.guard.authorize(
            alice,
            Action(name="write"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
            session_id=session.id,
        )
        assert decision.allowed is True

        decision = self.guard.authorize(
            alice,
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
            session_id=session.id,
        )
        assert decision.allowed is False

    def test_authorize_without_session_uses_all_roles(self) -> None:
        """No session_id → all roles are used."""
        alice = Subject(
            id="alice",
            attributes={"roles": ["admin", "editor"]},
        )
        decision = self.guard.authorize(
            alice,
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
        )
        assert decision.allowed is True

    def test_authorize_with_expired_session_denies(self) -> None:
        """Expired session is ignored (fail-open) → all roles used."""
        alice = Subject(id="alice", attributes={"roles": ["admin"]})
        session_mgr = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        session = session_mgr.create_session(
            subject=alice,
            tenant_id="t1",
            activated_roles=["admin"],
            ttl=timedelta(hours=-1),  # already expired
        )
        # Expired session is ignored → falls back to all roles
        decision = self.guard.authorize(
            alice,
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
            session_id=session.id,
        )
        assert decision.allowed is True

    def test_authorize_invalid_session_id_raises(self) -> None:
        """Non-existent session_id raises SessionNotFoundError."""
        alice = Subject(id="alice", attributes={"roles": ["admin"]})
        with pytest.raises(SessionNotFoundError):
            self.guard.authorize(
                alice,
                Action(name="delete"),
                Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
                "t1",
                session_id="nonexistent",
            )

    def test_list_authorized_with_session(self) -> None:
        """list_authorized also respects session_id."""
        alice = Subject(id="alice", attributes={"roles": ["editor", "admin"]})
        session_mgr = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        session = session_mgr.create_session(
            subject=alice,
            tenant_id="t1",
            activated_roles=["editor"],
        )
        from open_guard.domain.entities import Resource as ResEntity
        from open_guard.domain.ports.candidate_resource import CandidateResourcePort

        class FakeCandidates(CandidateResourcePort):
            def fetch_candidates(
                self, resource_type, tenant_id, prefilter=None, cursor=None, limit=100
            ):
                return [
                    ResEntity(
                        id="doc-1",
                        resource_type="doc",
                        attributes={"type": "doc"},
                    ),
                ], None

        result = self.guard.list_authorized(
            alice, "write", "doc", "t1",
            candidate_source=FakeCandidates(),
            session_id=session.id,
        )
        assert "doc-1" in result.ids
