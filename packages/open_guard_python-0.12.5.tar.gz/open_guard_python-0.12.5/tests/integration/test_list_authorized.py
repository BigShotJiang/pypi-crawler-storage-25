"""Integration — end-to-end list_authorized scenarios.

Focuses on realistic RAG-style flows that compose ReBAC tuples with
ABAC conditions and deny precedence, plus pagination and
pending-approval exclusion across the full Guard pipeline.
"""

from __future__ import annotations

from datetime import timedelta
from typing import Any

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequirement,
    PermissionRule,
    Policy,
    PolicyEffect,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.services.guard import Guard


class InMemoryCandidateSource(CandidateResourcePort):
    def __init__(
        self,
        resources: dict[tuple[str, str], list[Resource]] | None = None,
    ) -> None:
        self._resources: dict[tuple[str, str], list[Resource]] = resources or {}

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._resources.get((tenant_id, resource_type), [])
        if prefilter:
            items = [
                r for r in items
                if all(r.attributes.get(k) == v for k, v in prefilter.items())
            ]
        offset = int((cursor or {}).get("offset", 0))
        page = items[offset : offset + limit]
        next_cursor = (
            {"offset": offset + limit} if offset + limit < len(items) else None
        )
        return page, next_cursor


def _doc_typedefs() -> dict[str, TypeDefinition]:
    return {
        "doc": TypeDefinition(
            name="doc",
            relations={"owner": ["user"], "viewer": ["user"]},
            permissions={
                "can_read": PermissionRule(
                    kind="union", relations=["owner", "viewer"]
                ),
            },
        ),
    }


class TestRAGFlowReBACPlusABAC:
    """Realistic RAG filter: ReBAC tuples grant access; ABAC narrows by
    document classification; deny strips sensitive ones.
    """

    def _setup(self) -> tuple[Guard, InMemoryRelationshipStore]:
        policy_store = InMemoryPolicyStore()
        rel_store = InMemoryRelationshipStore()

        # ReBAC: read if you're owner/viewer
        policy_store.add(
            Policy(
                id="rebac-read",
                tenant_id="t1",
                evaluator_type="rebac",
                action_match="read",
                conditions={
                    "object_type": "doc",
                    "permission": "can_read",
                    "subject_type": "user",
                },
            )
        )
        # ABAC allow: matches any doc read (clearance checks encoded as deny)
        policy_store.add(
            Policy(
                id="abac-allow-read",
                tenant_id="t1",
                evaluator_type="abac",
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        # ABAC deny: classification=secret unless clearance=secret.
        # Note: ABAC uses conditions (not resource_match) for predicate logic.
        policy_store.add(
            Policy(
                id="abac-deny-secret",
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.DENY,
                action_match="read",
                conditions={
                    "resource.classification": {
                        "op": "eq", "value": "secret",
                    },
                    "subject.clearance": {"op": "neq", "value": "secret"},
                },
                priority=10,
            )
        )

        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=_doc_typedefs(),
                ),
                ABACEvaluator(),
            ],
            relationship_store=rel_store,
        )

        # alice owns doc:1 (public), doc:2 (secret); viewer of doc:3 (public)
        for obj_id in ["1", "2", "3"]:
            rel = "owner" if obj_id in ("1", "2") else "viewer"
            rel_store.write_tuple(
                RelationTuple(
                    tenant_id="t1", object_type="doc", object_id=obj_id,
                    relation=rel, subject_type="user", subject_id="alice",
                )
            )
        return guard, rel_store

    def test_alice_without_clearance_sees_only_public_docs(self) -> None:
        guard, _ = self._setup()
        # Candidate source supplies attributes for ABAC to see classification.
        source = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "classification": "public"}),
                    Resource(id="2", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "classification": "secret"}),
                    Resource(id="3", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "classification": "public"}),
                ]
            }
        )
        alice = Subject(id="alice", attributes={"clearance": "public"})
        result = guard.list_authorized(
            alice, "read", "doc", "t1", candidate_source=source,
        )
        assert sorted(result.ids) == ["1", "3"]

    def test_alice_with_secret_clearance_sees_all(self) -> None:
        guard, _ = self._setup()
        source = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "classification": "public"}),
                    Resource(id="2", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "classification": "secret"}),
                    Resource(id="3", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "classification": "public"}),
                ]
            }
        )
        alice = Subject(id="alice", attributes={"clearance": "secret"})
        result = guard.list_authorized(
            alice, "read", "doc", "t1", candidate_source=source,
        )
        assert sorted(result.ids) == ["1", "2", "3"]


class TestChainScopedList:
    """Agent on_behalf_of trusted user can list; untrusted user cannot."""

    def test_chain_root_actor_attribute_filters_list(self) -> None:
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                id="abac-chain",
                tenant_id="t1",
                evaluator_type="abac",
                action_match="read",
                resource_match={"type": "doc"},
                conditions={
                    "chain.root_actor.trusted": {"op": "eq", "value": True},
                },
            )
        )
        source = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[ABACEvaluator()],
            candidate_source=source,
        )
        trusted_user = Subject(id="alice", attributes={"trusted": True})
        untrusted_user = Subject(id="bob", attributes={"trusted": False})
        agent_for_alice = Subject(
            id="agent",
            actor_type=ActorType.AGENT,
            on_behalf_of=trusted_user,
        )
        agent_for_bob = Subject(
            id="agent",
            actor_type=ActorType.AGENT,
            on_behalf_of=untrusted_user,
        )
        assert guard.list_authorized(
            agent_for_alice, "read", "doc", "t1"
        ).ids == ["1"]
        assert guard.list_authorized(
            agent_for_bob, "read", "doc", "t1"
        ).ids == []


class TestPendingApprovalExclusion:
    """Pending-approval resources stay excluded until approved; then they appear."""

    def test_pending_then_approved_appears_in_list(self) -> None:
        approval_store = InMemoryApprovalStore()
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                id="requires-approval",
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["researcher"]},
                action_match="read",
                resource_match={"type": "doc"},
                requires_approval=ApprovalRequirement(
                    approvers=["admin"],
                    quorum="any",
                    ttl=timedelta(minutes=30),
                ),
            )
        )
        source = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[RBACEvaluator()],
            approval_store=approval_store,
            candidate_source=source,
        )
        alice = Subject(id="alice", attributes={"roles": ["researcher"]})

        # Initially pending → excluded
        r1 = guard.list_authorized(alice, "read", "doc", "t1")
        assert r1.ids == []

        # Trigger authorize() to create a pending request, then approve it.
        from open_guard.domain.entities import Action as _Action
        d = guard.authorize(
            alice, _Action(name="read"),
            Resource(id="1", resource_type="doc", tenant_id="t1",
                     attributes={"type": "doc"}),
            "t1",
        )
        assert d.approval_request_id is not None
        guard.approve(d.approval_request_id, "t1", approver="admin")

        # After approval → included
        r2 = guard.list_authorized(alice, "read", "doc", "t1")
        assert r2.ids == ["1"]


class TestTenantIsolation:
    def test_tenants_cannot_see_each_others_ids(self) -> None:
        rel_store = InMemoryRelationshipStore()
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t1", object_type="doc", object_id="from-t1",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t2", object_type="doc", object_id="from-t2",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        policy_store = InMemoryPolicyStore()
        for tenant in ("t1", "t2"):
            policy_store.add(
                Policy(
                    id=f"rebac-{tenant}",
                    tenant_id=tenant,
                    evaluator_type="rebac",
                    action_match="read",
                    conditions={
                        "object_type": "doc",
                        "permission": "can_read",
                        "subject_type": "user",
                    },
                )
            )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=_doc_typedefs(),
                )
            ],
            relationship_store=rel_store,
        )
        alice = Subject(id="alice")
        assert guard.list_authorized(
            alice, "read", "doc", "t1"
        ).ids == ["from-t1"]
        assert guard.list_authorized(
            alice, "read", "doc", "t2"
        ).ids == ["from-t2"]
