"""Tests for open-guard CLI (Phase 7 — T3)."""
from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from open_guard.cli.main import cli


class TestDBInit:
    """open-guard db init command."""

    def test_creates_tables_sqlite(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["db", "init", "--dsn", f"sqlite:///{tmp_path}/test.db"])
        assert result.exit_code == 0
        assert "Tables created successfully" in result.output

    def test_missing_dsn_fails(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["db", "init"])
        assert result.exit_code != 0

    def test_idempotent(self, tmp_path: Path) -> None:
        runner = CliRunner()
        dsn = f"sqlite:///{tmp_path}/test.db"
        runner.invoke(cli, ["db", "init", "--dsn", dsn])
        result = runner.invoke(cli, ["db", "init", "--dsn", dsn])
        assert result.exit_code == 0


class TestDBSchema:
    """open-guard db schema command."""

    def test_outputs_sqlite_ddl(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["db", "schema"])
        assert result.exit_code == 0
        assert "CREATE TABLE" in result.output
        assert "open_guard_policies" in result.output

    def test_outputs_postgresql_ddl(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["db", "schema", "--dialect", "postgresql"])
        assert result.exit_code == 0
        assert "CREATE TABLE" in result.output

    def test_invalid_dialect_fails(self) -> None:
        runner = CliRunner()
        result = runner.invoke(cli, ["db", "schema", "--dialect", "mysql"])
        assert result.exit_code != 0
