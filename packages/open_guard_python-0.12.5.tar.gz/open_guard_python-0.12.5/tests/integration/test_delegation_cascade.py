"""Integration: cascade revocation + non-delegable policy (T14).

Tests the full assembled system for:
- Cascade revocation: revoking a parent delegation also revokes all descendants
- Non-delegable policies: guard.authorize with _skip_delegation marks
  non_delegable_policy=True and DelegationEvaluator blocks re-delegation
  from a policy-backed grant
"""

from __future__ import annotations

from datetime import UTC, datetime

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    AuthorizationRequest,
    DecisionStatus,
    DelegationScope,
    DelegationStatus,
    Evaluation,
    Policy,
    Subject,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _user(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.USER)


def _agent(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.AGENT)


def _scope(
    action: str = "read", resource_type: str = "document", doc_id: str = "doc-1"
) -> DelegationScope:
    return DelegationScope(
        action_match=action,
        resource_type=resource_type,
        resource_match={"id": {"op": "eq", "value": doc_id}},
    )


def _make_guard(
    *,
    policy_allowed_for: set[str] | None = None,
    non_delegable: bool = False,
    ds: InMemoryDelegationStore | None = None,
) -> tuple[Guard, InMemoryDelegationStore]:
    class SubjectEval(EvaluatorPort):
        @property
        def evaluator_type(self) -> str:
            return "rbac"

        def evaluate(self, req: AuthorizationRequest, policies: list) -> Evaluation:
            allowed = req.subject.id in (policy_allowed_for or set())
            return Evaluation(
                evaluator="rbac",
                allowed=allowed,
                matched_policies=[p.id for p in policies] if allowed else [],
            )

        def supports(self, policy: Policy) -> bool:
            return policy.evaluator_type == "rbac"

    delegation_store = ds or InMemoryDelegationStore()
    policy = Policy(
        tenant_id=TENANT, evaluator_type="rbac", non_delegable=non_delegable
    )
    store = MockPolicyStore([policy])
    guard = Guard(
        policy_store=store,
        evaluators=[SubjectEval()],
        delegation_store=delegation_store,
        clock=lambda: NOW,
        default_delegate_policy="self_only",
    )
    return guard, delegation_store


class TestCascadeRevocation:
    def test_revoking_parent_revokes_direct_child(self) -> None:
        """Revoking parent delegation also revokes child delegation."""
        guard, ds = _make_guard(policy_allowed_for={"alice", "bob"})
        alice = _user("alice")
        bob = _user("bob")
        charlie = _agent("charlie")

        parent = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        child = guard.delegate(
            caller=bob, from_subject=bob, to_subject=charlie,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=parent.id,
        )

        guard.revoke_delegation(parent.id, caller=alice, tenant_id=TENANT)

        parent_updated = ds.get(parent.id, TENANT)
        child_updated = ds.get(child.id, TENANT)
        assert parent_updated is not None
        assert parent_updated.status == DelegationStatus.REVOKED
        assert child_updated is not None
        assert child_updated.status == DelegationStatus.REVOKED

    def test_revoking_parent_blocks_grandchild_access(self) -> None:
        """After cascade revoke, grandchild agent is denied access."""
        guard, _ds = _make_guard(policy_allowed_for={"alice", "bob"})
        alice = _user("alice")
        bob = _user("bob")
        charlie = _agent("charlie")

        parent = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        guard.delegate(
            caller=bob, from_subject=bob, to_subject=charlie,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=parent.id,
        )

        guard.revoke_delegation(parent.id, caller=alice, tenant_id=TENANT)

        from open_guard.domain.entities import Action, Resource
        decision = guard.authorize(
            charlie,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert decision.status == DecisionStatus.DENIED

    def test_revoking_child_does_not_affect_parent(self) -> None:
        """Revoking a child delegation leaves the parent ACTIVE."""
        guard, ds = _make_guard(policy_allowed_for={"alice", "bob"})
        alice = _user("alice")
        bob = _user("bob")
        charlie = _agent("charlie")

        parent = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        child = guard.delegate(
            caller=bob, from_subject=bob, to_subject=charlie,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=parent.id,
        )

        guard.revoke_delegation(child.id, caller=bob, tenant_id=TENANT)

        parent_updated = ds.get(parent.id, TENANT)
        child_updated = ds.get(child.id, TENANT)
        assert parent_updated is not None
        assert parent_updated.status == DelegationStatus.ACTIVE
        assert child_updated is not None
        assert child_updated.status == DelegationStatus.REVOKED

    def test_deep_cascade_three_levels(self) -> None:
        """Cascade propagates three levels deep (A→B→C→D)."""
        guard, ds = _make_guard(policy_allowed_for={"alice", "bob", "charlie"})
        alice = _user("alice")
        bob = _user("bob")
        charlie = _user("charlie")
        dave = _agent("dave")

        d_ab = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        d_bc = guard.delegate(
            caller=bob, from_subject=bob, to_subject=charlie,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=d_ab.id,
        )
        d_cd = guard.delegate(
            caller=charlie, from_subject=charlie, to_subject=dave,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=d_bc.id,
        )

        guard.revoke_delegation(d_ab.id, caller=alice, tenant_id=TENANT)

        for d_id in [d_ab.id, d_bc.id, d_cd.id]:
            d = ds.get(d_id, TENANT)
            assert d is not None, f"{d_id} should exist"
            assert d.status == DelegationStatus.REVOKED, f"{d_id} should be REVOKED"


class TestNonDelegablePolicy:
    def test_non_delegable_policy_blocks_re_check_delegation(self) -> None:
        """Agent with delegation from a non_delegable policy is denied on re-check."""
        guard, _ds = _make_guard(
            policy_allowed_for={"alice"}, non_delegable=True
        )
        alice = _user("alice")
        bob = _agent("bob")

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope(action="read", resource_type="document", doc_id="doc-1")],
            tenant_id=TENANT,
            re_check_on_use=True,
        )

        from open_guard.domain.entities import Action, Resource
        decision = guard.authorize(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert decision.status == DecisionStatus.DENIED

    def test_delegable_policy_allows_re_check(self) -> None:
        """Agent with delegation from a delegable policy passes re-check."""
        guard, _ds = _make_guard(
            policy_allowed_for={"alice"}, non_delegable=False
        )
        alice = _user("alice")
        bob = _agent("bob")

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            re_check_on_use=True,
        )

        from open_guard.domain.entities import Action, Resource
        decision = guard.authorize(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert decision.status == DecisionStatus.ALLOWED

    def test_no_re_check_delegation_skips_non_delegable_check(self) -> None:
        """re_check_on_use=False skips grantor check; non_delegable is irrelevant."""
        guard, _ds = _make_guard(
            policy_allowed_for={"alice"}, non_delegable=True
        )
        alice = _user("alice")
        bob = _agent("bob")

        guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            re_check_on_use=False,
        )

        from open_guard.domain.entities import Action, Resource
        decision = guard.authorize(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert decision.status == DecisionStatus.ALLOWED

    def test_skip_delegation_flag_marks_decision_non_delegable(self) -> None:
        """Guard.authorize(_skip_delegation=True) on non_delegable policy sets flag."""
        guard, _ds = _make_guard(
            policy_allowed_for={"alice"}, non_delegable=True
        )
        alice = _user("alice")

        from open_guard.domain.entities import Action, Resource
        decision = guard.authorize(
            alice, Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
            _skip_delegation=True,
        )
        assert decision.status == DecisionStatus.ALLOWED
        assert getattr(decision, "non_delegable_policy", False) is True
