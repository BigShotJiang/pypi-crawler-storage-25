# tests/integration/test_prompt_injection.py
"""Adversarial prompt-injection test suite (Phase 6 — FEAT-010).

Demonstrates that LLM-generated data cannot influence policy evaluation
in ways that bypass authorization.
"""

import pytest

from open_guard import (
    ABACEvaluator,
    Action,
    Guard,
    InMemoryPolicyStore,
    Policy,
    PolicyEffect,
    RBACEvaluator,
    Resource,
    Subject,
)


@pytest.fixture
def guard():
    store = InMemoryPolicyStore()
    store.add(Policy(
        id="p-secret", tenant_id="t1", evaluator_type="abac",
        action_match="read",
        conditions={
            "resource.classification": {
                "op": "eq", "value": "public", "trusted_only": True,
            },
        },
    ))
    store.add(Policy(
        id="p-admin", tenant_id="t1", evaluator_type="rbac",
        subject_match={"roles": ["admin"]},
        action_match="*",
    ))
    return Guard(
        policy_store=store,
        evaluators=[RBACEvaluator(), ABACEvaluator()],
    )


class TestPromptInjectionDefenses:
    """10+ adversarial scenarios proving LLM-generated data cannot bypass authz."""

    def test_llm_injected_classification_blocked_by_taint(self, guard) -> None:
        """LLM sets classification=public on a secret doc → trusted_only blocks it."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="secret-doc", resource_type="doc", attributes={
                "classification": "public",  # LLM injected
                "_trusted": {"classification": False},
            }),
            "t1",
        )
        assert decision.allowed is False

    def test_trusted_classification_is_allowed(self, guard) -> None:
        """Same resource with trusted classification → allowed."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="public-doc", resource_type="doc", attributes={
                "classification": "public",
            }),
            "t1",
        )
        assert decision.allowed is True

    def test_llm_cannot_inject_roles_on_subject(self, guard) -> None:
        """LLM-crafted Subject attributes don't bypass RBAC."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc"),
            "t1",
        )
        assert decision.allowed is False

    def test_policy_store_not_writable_from_evaluation(self, guard) -> None:
        """Policy store is read-only during evaluation — direct mutation blocked."""
        from open_guard.domain.services.policy_router import ReadOnlyPolicyView
        router = guard._router
        assert isinstance(router._policy_store, ReadOnlyPolicyView)
        with pytest.raises(AttributeError, match="read-only"):
            router._policy_store.add(Policy(
                id="injected", tenant_id="t1", evaluator_type="rbac",
                subject_match={"roles": ["*"]}, action_match="*",
            ))

    def test_tenant_isolation_under_adversarial_input(self, guard) -> None:
        """Cross-tenant access impossible even with adversarial attributes."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={
                "roles": ["admin"],
                "tenant_id": "t1",  # attempted injection
            }),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc", attributes={
                "classification": "public",
            }),
            "other-tenant",  # actual tenant
        )
        # No policies exist for "other-tenant"
        assert decision.allowed is False

    def test_attribute_path_traversal_blocked(self, guard) -> None:
        """Dotted paths cannot traverse into internal state."""
        decision = guard.authorize(
            Subject(id="agent-1", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc", attributes={
                "classification": "public",
                "__class__": "Policy",  # injection attempt
                "_trusted": {"classification": False},
            }),
            "t1",
        )
        # trusted_only blocks it regardless of __class__ injection
        assert decision.allowed is False

    def test_condition_value_injection_via_operator_string(self, guard) -> None:
        """LLM cannot inject operator syntax through attribute values."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.label": {"op": "eq", "value": "safe"},
            },
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        # Attempt: set label to {"op": "eq", "value": "safe"} (dict, not string)
        decision = g.authorize(
            Subject(id="a1", attributes={}),
            Action(name="read"),
            Resource(id="r1", resource_type="doc", attributes={
                "label": {"op": "eq", "value": "safe"},
            }),
            "t1",
        )
        # The actual value is a dict, not "safe" → eq comparison fails
        assert decision.allowed is False

    def test_deny_policy_cannot_be_bypassed_by_taint(self, guard) -> None:
        """Deny policies are not affected by taint marking (deny always wins)."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p-deny", tenant_id="t1", evaluator_type="abac",
            action_match="delete", effect=PolicyEffect.DENY,
            conditions={"resource.type": {"op": "eq", "value": "doc"}},
            priority=100,
        ))
        store.add(Policy(
            id="p-allow", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]}, action_match="delete",
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator(), RBACEvaluator()])
        decision = g.authorize(
            Subject(id="admin-1", attributes={"roles": ["admin"]}),
            Action(name="delete"),
            Resource(id="doc-1", resource_type="doc", attributes={"type": "doc"}),
            "t1",
        )
        assert decision.allowed is False

    def test_obo_chain_taint_propagation(self, guard) -> None:
        """Tainted attributes on an OBO chain member are caught by trusted_only."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "chain.root_actor.clearance": {
                    "op": "eq", "value": "top_secret", "trusted_only": True,
                },
            },
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        root = Subject(id="user-1", attributes={
            "clearance": "top_secret",
            "_trusted": {"clearance": False},  # LLM injected
        })
        agent = Subject(id="agent-1", attributes={"roles": []}, on_behalf_of=root)
        decision = g.authorize(
            agent,
            Action(name="read"),
            Resource(id="r1", resource_type="doc"),
            "t1",
        )
        assert decision.allowed is False

    def test_llm_output_as_resource_attributes_safe(self, guard) -> None:
        """Resource built from LLM output with taint marking is safe."""
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="promote",
            conditions={
                "resource.confidence": {
                    "op": "gte", "value": 0.9, "trusted_only": True,
                },
            },
        ))
        g = Guard(policy_store=store, evaluators=[ABACEvaluator()])
        # LLM claims confidence=0.95 — but it's untrusted
        decision = g.authorize(
            Subject(id="agent-1", attributes={}),
            Action(name="promote"),
            Resource(id="k1", resource_type="knowledge", attributes={
                "confidence": 0.95,
                "_trusted": {"confidence": False},
            }),
            "t1",
        )
        assert decision.allowed is False
