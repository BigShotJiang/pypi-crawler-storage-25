"""Integration — DecisionTrace end-to-end with JSON roundtrip."""

from __future__ import annotations

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    DecisionStatus,
    DecisionTrace,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard


class TestDecisionTraceIntegration:
    """FEAT-008 — DecisionTrace end-to-end through Guard."""

    def _guard(self) -> Guard:
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="p-rbac",
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                subject_match={"roles": ["viewer"]},
            )
        )
        store.add(
            Policy(
                id="p-abac",
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                conditions={
                    "subject.department": {"op": "eq", "value": "eng"},
                },
            )
        )
        return Guard(
            policy_store=store,
            evaluators=[RBACEvaluator(), ABACEvaluator()],
        )

    def test_trace_covers_all_evaluators(self) -> None:
        guard = self._guard()
        subject = Subject(
            id="alice",
            attributes={"roles": ["viewer"], "department": "eng"},
        )
        decision, trace = guard.authorize_traced(
            subject=subject,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.status == DecisionStatus.ALLOWED
        assert {t.evaluator for t in trace.evaluator_results} == {"rbac", "abac"}

    def test_trace_populates_matched_policies_detail(self) -> None:
        guard = self._guard()
        subject = Subject(
            id="alice",
            attributes={"roles": ["viewer"], "department": "eng"},
        )
        _, trace = guard.authorize_traced(
            subject=subject,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        for et in trace.evaluator_results:
            # Each evaluator should have at least one matched policy
            assert len(et.matched_policies) >= 1
            assert et.duration_ms >= 0.0

    def test_trace_json_roundtrip(self) -> None:
        guard = self._guard()
        subject = Subject(
            id="alice",
            attributes={"roles": ["viewer"], "department": "eng"},
        )
        _, trace = guard.authorize_traced(
            subject=subject,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        js = trace.model_dump_json()
        restored = DecisionTrace.model_validate_json(js)
        assert restored.schema_version == "1.0"
        assert restored.decision_status == trace.decision_status
        assert len(restored.evaluator_results) == len(trace.evaluator_results)
        assert restored.actor_chain == trace.actor_chain

    def test_trace_deny_composition(self) -> None:
        """Deny path renders deny-wins composition with reasons."""
        store = InMemoryPolicyStore()
        store.add(
            Policy(
                id="p1",
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                action_match="read",
                subject_match={"roles": ["admin"]},
            )
        )
        guard = Guard(policy_store=store, evaluators=[RBACEvaluator()])
        subject = Subject(id="alice", attributes={"roles": ["viewer"]})
        _, trace = guard.authorize_traced(
            subject=subject,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert trace.decision_status == DecisionStatus.DENIED
        assert trace.composition == "deny-wins"
        # At least one rejected policy tracked
        assert sum(
            len(et.rejected_policies) for et in trace.evaluator_results
        ) >= 1

    def test_trace_with_chain_renders_chain(self) -> None:
        guard = self._guard()
        user = Subject(
            id="alice",
            attributes={"roles": ["viewer"], "department": "eng"},
        )
        agent = Subject(
            id="helper",
            actor_type=ActorType.AGENT,
            attributes={"roles": ["viewer"], "department": "eng"},
            on_behalf_of=user,
        )
        _, trace = guard.authorize_traced(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc1", resource_type="document"),
            tenant_id="t1",
        )
        assert [s.id for s in trace.actor_chain] == ["helper", "alice"]
