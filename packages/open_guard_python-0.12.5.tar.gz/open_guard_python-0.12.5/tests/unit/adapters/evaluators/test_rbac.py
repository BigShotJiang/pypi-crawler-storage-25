"""Tests for RBAC evaluator."""

from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)


def _request(
    roles: list[str] | None = None,
    action: str = "read",
    resource_type: str = "document",
    resource_attrs: dict | None = None,  # type: ignore[type-arg]
    tenant_id: str = "t1",
) -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(
            id="user-1",
            attributes={"roles": roles or []},
        ),
        action=Action(name=action),
        resource=Resource(
            id="res-1",
            resource_type=resource_type,
            attributes=resource_attrs or {},
        ),
        tenant_id=tenant_id,
    )


def _policy(
    roles: list[str] | None = None,
    action: str = "*",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    resource_match: dict | None = None,  # type: ignore[type-arg]
    policy_id: str = "p1",
) -> Policy:
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="rbac",
        subject_match={"roles": roles or []},
        action_match=action,
        effect=effect,
        priority=priority,
        resource_match=resource_match or {},
    )


class TestRBACEvaluator:
    def test_supports_rbac_policy(self) -> None:
        evaluator = RBACEvaluator()
        assert evaluator.supports(Policy(tenant_id="t", evaluator_type="rbac"))
        assert not evaluator.supports(Policy(tenant_id="t", evaluator_type="abac"))

    def test_basic_role_match(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["admin"]),
            [_policy(roles=["admin"])],
        )
        assert result.allowed is True
        assert result.evaluator == "rbac"

    def test_no_matching_role(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["viewer"]),
            [_policy(roles=["admin"])],
        )
        assert result.allowed is False

    def test_no_roles_on_subject(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=[]),
            [_policy(roles=["admin"])],
        )
        assert result.allowed is False
        assert "no roles" in result.reason.lower()

    def test_role_hierarchy(self) -> None:
        evaluator = RBACEvaluator(
            role_hierarchy={"admin": ["editor"], "editor": ["viewer"]}
        )
        # admin inherits editor which inherits viewer
        result = evaluator.evaluate(
            _request(roles=["admin"]),
            [_policy(roles=["viewer"])],
        )
        assert result.allowed is True

    def test_role_hierarchy_no_inherit(self) -> None:
        evaluator = RBACEvaluator(
            role_hierarchy={"admin": ["editor"], "editor": ["viewer"]}
        )
        # viewer does NOT inherit admin
        result = evaluator.evaluate(
            _request(roles=["viewer"]),
            [_policy(roles=["admin"])],
        )
        assert result.allowed is False

    def test_multiple_roles_on_subject(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["viewer", "editor"]),
            [_policy(roles=["editor"])],
        )
        assert result.allowed is True

    def test_deny_policy_overrides_allow(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["admin"]),
            [
                _policy(roles=["admin"], effect=PolicyEffect.ALLOW, policy_id="p1"),
                _policy(roles=["admin"], effect=PolicyEffect.DENY, policy_id="p2"),
            ],
        )
        assert result.allowed is False

    def test_priority_ordering(self) -> None:
        evaluator = RBACEvaluator()
        # Higher priority allow overrides lower priority deny
        result = evaluator.evaluate(
            _request(roles=["admin"]),
            [
                _policy(
                    roles=["admin"],
                    effect=PolicyEffect.DENY,
                    priority=1,
                    policy_id="p1",
                ),
                _policy(
                    roles=["admin"],
                    effect=PolicyEffect.ALLOW,
                    priority=10,
                    policy_id="p2",
                ),
            ],
        )
        assert result.allowed is True

    def test_action_matching(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["editor"], action="write"),
            [_policy(roles=["editor"], action="read")],
        )
        assert result.allowed is False

    def test_action_wildcard(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["admin"], action="delete"),
            [_policy(roles=["admin"], action="*")],
        )
        assert result.allowed is True

    def test_action_list_match(self) -> None:
        evaluator = RBACEvaluator()
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match=["read", "write"],
        )
        result = evaluator.evaluate(
            _request(roles=["editor"], action="write"),
            [policy],
        )
        assert result.allowed is True

    def test_resource_match(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["admin"], resource_attrs={"classification": "internal"}),
            [_policy(roles=["admin"], resource_match={"classification": "internal"})],
        )
        assert result.allowed is True

    def test_resource_mismatch(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["admin"], resource_attrs={"classification": "public"}),
            [
                _policy(
                    roles=["admin"], resource_match={"classification": "confidential"}
                )
            ],
        )
        assert result.allowed is False

    def test_empty_policies(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(_request(roles=["admin"]), [])
        assert result.allowed is False

    def test_matched_policies_in_result(self) -> None:
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["admin"]),
            [_policy(roles=["admin"], policy_id="policy-42")],
        )
        assert result.allowed is True
        assert "policy-42" in result.matched_policies

    def test_role_as_string_in_subject(self) -> None:
        """Subject roles can be a single string instead of list."""
        evaluator = RBACEvaluator()
        req = AuthorizationRequest(
            subject=Subject(id="u1", attributes={"roles": "admin"}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )
        result = evaluator.evaluate(req, [_policy(roles=["admin"])])
        assert result.allowed is True

    def test_roles_not_list_or_string(self) -> None:
        """Non-list/string roles attribute returns empty."""
        evaluator = RBACEvaluator()
        req = AuthorizationRequest(
            subject=Subject(id="u1", attributes={"roles": 42}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )
        result = evaluator.evaluate(req, [_policy(roles=["admin"])])
        assert result.allowed is False

    def test_role_hierarchy_cache_hit(self) -> None:
        """Second call uses cached role resolution."""
        evaluator = RBACEvaluator(
            role_hierarchy={"admin": ["viewer"]}
        )
        result1 = evaluator.evaluate(
            _request(roles=["admin"]),
            [_policy(roles=["viewer"])],
        )
        result2 = evaluator.evaluate(
            _request(roles=["admin"]),
            [_policy(roles=["viewer"])],
        )
        assert result1.allowed is True
        assert result2.allowed is True

    def test_policy_with_no_role_requirement(self) -> None:
        """Policy with empty roles matches any subject with roles."""
        evaluator = RBACEvaluator()
        result = evaluator.evaluate(
            _request(roles=["viewer"]),
            [_policy(roles=[])],
        )
        assert result.allowed is True

    def test_subject_match_role_as_string(self) -> None:
        """subject_match roles can be a string instead of list."""
        evaluator = RBACEvaluator()
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": "admin"},
            action_match="*",
        )
        result = evaluator.evaluate(
            _request(roles=["admin"]),
            [policy],
        )
        assert result.allowed is True
