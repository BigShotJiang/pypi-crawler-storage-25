"""Tests for RBACEvaluator with session context (Phase 6 — ENH-001)."""

from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Session,
    SessionStatus,
    Subject,
)


def _request(
    roles: list[str],
    action: str = "read",
    session: Session | None = None,
) -> AuthorizationRequest:
    context = {}
    if session is not None:
        context["_session"] = session
    return AuthorizationRequest(
        subject=Subject(id="alice", attributes={"roles": roles}),
        action=Action(name=action),
        resource=Resource(id="r1", resource_type="doc"),
        tenant_id="t1",
        context=context,
    )


def _policy(roles: list[str], effect: str = "allow") -> Policy:
    return Policy(
        id="p1",
        tenant_id="t1",
        evaluator_type="rbac",
        subject_match={"roles": roles},
        action_match="read",
        effect=PolicyEffect(effect),
    )


class TestRBACWithSession:
    def setup_method(self) -> None:
        self.evaluator = RBACEvaluator()

    def test_without_session_uses_all_roles(self) -> None:
        """No session → all subject roles are used."""
        req = _request(roles=["admin", "editor", "viewer"])
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is True

    def test_with_session_uses_only_activated_roles(self) -> None:
        """Session activates [editor, viewer] → admin policy should NOT match."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor", "viewer"],
        )
        req = _request(
            roles=["admin", "editor", "viewer"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is False

    def test_with_session_activated_role_matches(self) -> None:
        """Session activates [editor] → editor policy matches."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        req = _request(
            roles=["admin", "editor", "viewer"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["editor"])])
        assert result.allowed is True

    def test_expired_session_uses_all_roles(self) -> None:
        """Expired session is ignored — all roles are used."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["viewer"],
            status=SessionStatus.EXPIRED,
        )
        req = _request(
            roles=["admin", "editor"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is True

    def test_deactivated_session_uses_all_roles(self) -> None:
        """Deactivated session is ignored — all roles are used."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["viewer"],
            status=SessionStatus.DEACTIVATED,
        )
        req = _request(
            roles=["admin", "editor"],
            session=session,
        )
        result = self.evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is True

    def test_session_with_hierarchy(self) -> None:
        """Session roles also expand through hierarchy."""
        evaluator = RBACEvaluator(role_hierarchy={"editor": ["viewer"]})
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        req = _request(
            roles=["admin", "editor"],
            session=session,
        )
        # editor inherits viewer, so viewer policy should match
        result = evaluator.evaluate(req, [_policy(["viewer"])])
        assert result.allowed is True

    def test_session_with_hierarchy_blocks_non_activated(self) -> None:
        """Session activates [viewer] → even with hierarchy, admin doesn't match."""
        evaluator = RBACEvaluator(role_hierarchy={"admin": ["editor"]})
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["viewer"],
        )
        req = _request(
            roles=["admin", "editor", "viewer"],
            session=session,
        )
        result = evaluator.evaluate(req, [_policy(["admin"])])
        assert result.allowed is False
