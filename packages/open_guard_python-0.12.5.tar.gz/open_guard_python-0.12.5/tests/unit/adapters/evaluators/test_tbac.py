"""Tests for TBAC evaluator — time conditions."""

from datetime import UTC, datetime
from typing import Any

from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
    Task,
    TaskStatus,
)


def _request(
    action: str = "read",
    resource_type: str = "document",
    tenant_id: str = "t1",
    context: dict[str, Any] | None = None,
) -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(id="agent-1", attributes={}),
        action=Action(name=action),
        resource=Resource(id="res-1", resource_type=resource_type),
        tenant_id=tenant_id,
        context=context or {},
    )


def _policy(
    conditions: dict[str, Any] | None = None,
    action: str = "*",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    policy_id: str = "p1",
) -> Policy:
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="tbac",
        conditions=conditions or {},
        action_match=action,
        effect=effect,
        priority=priority,
    )


def _clock(
    year: int = 2026,
    month: int = 4,
    day: int = 16,
    hour: int = 12,
    minute: int = 0,
) -> datetime:
    """Create a UTC datetime for testing."""
    return datetime(year, month, day, hour, minute, 0, tzinfo=UTC)


class TestTBACEvaluatorSupports:
    def test_supports_tbac_policy(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        assert evaluator.supports(Policy(tenant_id="t", evaluator_type="tbac"))
        assert not evaluator.supports(Policy(tenant_id="t", evaluator_type="rbac"))


class TestTBACTimeWindow:
    def test_within_time_window(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=12))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_before_time_window(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=15))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_after_time_window(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=18))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_not_before_only(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=20))
        policy = _policy(conditions={
            "time_window": {"not_before": "2026-04-16T00:00:00Z"}
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_not_after_only(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=15))
        policy = _policy(conditions={
            "time_window": {"not_after": "2026-04-17T00:00:00Z"}
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True


class TestTBACSchedule:
    def test_within_schedule(self) -> None:
        # 2026-04-16 is a Thursday (weekday 4, iso weekday)
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],  # Mon-Fri (ISO weekday)
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_outside_schedule_wrong_day(self) -> None:
        # 2026-04-18 is a Saturday (weekday 6)
        evaluator = TBACEvaluator(clock=lambda: _clock(day=18, hour=10))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_outside_schedule_wrong_time(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=20))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_schedule_with_iana_timezone(self) -> None:
        # 2026-04-16 12:00 UTC = 17:30 IST (Asia/Kolkata is UTC+5:30)
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=12))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "18:00"],
                "timezone": "Asia/Kolkata",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_schedule_timezone_outside_range(self) -> None:
        # 2026-04-16 02:00 UTC = 07:30 IST — before 09:00 IST
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=2))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "18:00"],
                "timezone": "Asia/Kolkata",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_schedule_days_only_no_time_range(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=23))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True


class TestTBACTtl:
    def test_within_ttl(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=13))
        policy = _policy(conditions={
            "ttl": {
                "duration": "PT2H",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_expired_ttl(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=15))
        policy = _policy(conditions={
            "ttl": {
                "duration": "PT2H",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_ttl_days(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=17))
        policy = _policy(conditions={
            "ttl": {
                "duration": "P7D",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_ttl_minutes(self) -> None:
        evaluator = TBACEvaluator(
            clock=lambda: datetime(2026, 4, 16, 12, 45, 0, tzinfo=UTC)
        )
        policy = _policy(conditions={
            "ttl": {
                "duration": "PT30M",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False


class TestTBACCombinedConditions:
    def test_window_and_schedule_both_pass(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_window_passes_schedule_fails(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=20))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_no_time_conditions_allows(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        policy = _policy(conditions={})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_deny_policy(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        policy = _policy(
            conditions={
                "time_window": {
                    "not_before": "2026-04-01T00:00:00Z",
                    "not_after": "2026-04-30T00:00:00Z",
                },
            },
            effect=PolicyEffect.DENY,
        )
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_deny_overrides_allow_at_same_priority(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        allow = _policy(policy_id="allow-1", conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
        })
        deny = _policy(policy_id="deny-1", conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
        }, effect=PolicyEffect.DENY)
        result = evaluator.evaluate(_request(), [allow, deny])
        assert result.allowed is False

    def test_action_matching(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        policy = _policy(conditions={}, action="read")
        result = evaluator.evaluate(_request(action="write"), [policy])
        assert result.allowed is False

    def test_empty_policies(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        result = evaluator.evaluate(_request(), [])
        assert result.allowed is False


# --- Task-Scoped Policy Tests ---


def _active_task(
    task_id: str = "task-1",
    tenant_id: str = "t1",
    actor_id: str = "agent-1",
    allowed_actions: list[str] | None = None,
    allowed_resource_types: list[str] | None = None,
    expires_at: datetime | None = None,
) -> Task:
    return Task(
        id=task_id,
        tenant_id=tenant_id,
        actor_id=actor_id,
        status=TaskStatus.ACTIVE,
        allowed_actions=allowed_actions or ["*"],
        allowed_resource_types=allowed_resource_types or ["*"],
        created_at=_clock(),
        activated_at=_clock(),
        expires_at=expires_at,
    )


class TestTBACTaskScoping:
    def test_task_active_allows(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task())
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_task_not_found_denies(self) -> None:
        store = InMemoryTaskStore()
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "nonexistent"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_task_completed_denies(self) -> None:
        store = InMemoryTaskStore()
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="agent-1",
            status=TaskStatus.COMPLETED,
            created_at=_clock(),
            completed_at=_clock(),
        )
        store.add(task)
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_task_expired_auto_detected(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(expires_at=_clock(hour=11)))  # expired
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock(hour=12))

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

        # Verify task was auto-expired in store
        task = store.get("task-1", "t1")
        assert task is not None
        assert task.status == TaskStatus.EXPIRED

    def test_task_scoped_action_allowed(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(allowed_actions=["read", "write"]))
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(action="read"), [policy])
        assert result.allowed is True

    def test_task_scoped_action_denied(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(allowed_actions=["read"]))
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(action="delete"), [policy])
        assert result.allowed is False

    def test_task_scoped_resource_type_denied(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(allowed_resource_types=["image"]))
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(resource_type="document"), [policy])
        assert result.allowed is False

    def test_no_task_store_denies_task_policy(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())  # no task_store

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_task_and_time_conditions_combined(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task())
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock(hour=10))

        policy = _policy(conditions={
            "task_id": "task-1",
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_task_passes_time_fails(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task())
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock(day=20))

        policy = _policy(conditions={
            "task_id": "task-1",
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False
