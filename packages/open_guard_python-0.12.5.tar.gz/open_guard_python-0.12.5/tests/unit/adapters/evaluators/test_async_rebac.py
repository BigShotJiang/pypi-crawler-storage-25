"""Tests for async ReBAC evaluator — relationship-based access control."""

from __future__ import annotations

import pytest

from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    PermissionRule,
    Policy,
    PolicyEffect,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.domain.ports.async_relationship_store import AsyncRelationshipStorePort

# ---------------------------------------------------------------------------
# Minimal async wrapper around the sync in-memory store for testing
# ---------------------------------------------------------------------------


class _AsyncMemRelStore(AsyncRelationshipStorePort):
    """Thin async wrapper over InMemoryRelationshipStore for tests."""

    def __init__(self) -> None:
        self._sync = InMemoryRelationshipStore()

    async def write_tuple(self, relation_tuple: RelationTuple) -> RelationTuple:
        return self._sync.write_tuple(relation_tuple)

    async def delete_tuple(self, tuple_id: str, tenant_id: str) -> None:
        self._sync.delete_tuple(tuple_id, tenant_id)

    async def read_tuples(
        self,
        tenant_id: str,
        object_type: str | None = None,
        object_id: str | None = None,
        relation: str | None = None,
        subject_type: str | None = None,
        subject_id: str | None = None,
    ) -> list[RelationTuple]:
        return self._sync.read_tuples(
            tenant_id,
            object_type=object_type,
            object_id=object_id,
            relation=relation,
            subject_type=subject_type,
            subject_id=subject_id,
        )

    async def tuple_exists(
        self,
        tenant_id: str,
        object_type: str,
        object_id: str,
        relation: str,
        subject_type: str,
        subject_id: str,
        subject_relation: str | None = None,
    ) -> bool:
        return self._sync.tuple_exists(
            tenant_id,
            object_type,
            object_id,
            relation,
            subject_type,
            subject_id,
            subject_relation,
        )

    async def find_object_ids_for_subject(
        self,
        subject_id: str,
        subject_type: str,
        object_type: str,
        tenant_id: str,
        offset: int = 0,
        limit: int = 100,
    ) -> list[str]:
        return self._sync.find_object_ids_for_subject(
            subject_id, subject_type, object_type, tenant_id, offset, limit,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _request(
    subject_id: str = "alice",
    action: str = "read",
    resource_type: str = "document",
    resource_id: str = "readme",
    tenant_id: str = "t1",
) -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(id=subject_id),
        action=Action(name=action),
        resource=Resource(id=resource_id, resource_type=resource_type),
        tenant_id=tenant_id,
    )


def _policy(
    resource_type: str = "document",
    permission: str = "viewer",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    policy_id: str = "p1",
) -> Policy:
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="rebac",
        conditions={
            "object_type": resource_type,
            "permission": permission,
            "subject_type": "user",
        },
        effect=effect,
        priority=priority,
    )


async def _make_evaluator(
    tuples: list[RelationTuple] | None = None,
    type_defs: dict[str, TypeDefinition] | None = None,
    max_depth: int = 25,
) -> AsyncReBACEvaluator:
    store = _AsyncMemRelStore()
    if tuples:
        for t in tuples:
            await store.write_tuple(t)
    return AsyncReBACEvaluator(
        relationship_store=store,
        type_definitions=type_defs or {},
        max_depth=max_depth,
    )


def _tuple(
    object_type: str = "document",
    object_id: str = "readme",
    relation: str = "viewer",
    subject_type: str = "user",
    subject_id: str = "alice",
    subject_relation: str | None = None,
    tenant_id: str = "t1",
) -> RelationTuple:
    return RelationTuple(
        tenant_id=tenant_id,
        object_type=object_type,
        object_id=object_id,
        relation=relation,
        subject_type=subject_type,
        subject_id=subject_id,
        subject_relation=subject_relation,
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestAsyncReBACEvaluatorSupports:
    def test_supports_rebac_policy(self) -> None:
        store = _AsyncMemRelStore()
        evaluator = AsyncReBACEvaluator(relationship_store=store)
        assert evaluator.supports(Policy(tenant_id="t1", evaluator_type="rebac"))
        assert not evaluator.supports(Policy(tenant_id="t1", evaluator_type="rbac"))


class TestAsyncReBACDirectRelations:
    @pytest.mark.asyncio
    async def test_direct_relation_allows(self) -> None:
        evaluator = await _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")]
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is True

    @pytest.mark.asyncio
    async def test_no_relation_denies(self) -> None:
        evaluator = await _make_evaluator(tuples=[])
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is False

    @pytest.mark.asyncio
    async def test_wrong_relation_denies(self) -> None:
        evaluator = await _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")]
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="editor")],
        )
        assert result.allowed is False


class TestAsyncReBACSubjectSets:
    @pytest.mark.asyncio
    async def test_subject_set_indirect_membership(self) -> None:
        """document:readme#viewer@group:devs#member + group:devs#member@user:alice
        -> user:alice can view document:readme"""
        evaluator = await _make_evaluator(
            tuples=[
                _tuple(
                    relation="viewer",
                    subject_type="group",
                    subject_id="devs",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="devs",
                    relation="member",
                    subject_type="user",
                    subject_id="alice",
                ),
            ]
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is True


class TestAsyncReBACComputedPermissions:
    def _doc_type_def(self) -> dict[str, TypeDefinition]:
        return {
            "document": TypeDefinition(
                name="document",
                relations={
                    "owner": ["user"],
                    "editor": ["user"],
                    "viewer": ["user"],
                    "banned": ["user"],
                    "org_member": ["user"],
                },
                permissions={
                    "can_edit": PermissionRule(
                        kind="union", relations=["owner", "editor"]
                    ),
                    "can_view": PermissionRule(
                        kind="union", relations=["owner", "editor", "viewer"]
                    ),
                    "can_view_restricted": PermissionRule(
                        kind="intersection", relations=["viewer", "org_member"]
                    ),
                    "can_view_safe": PermissionRule(
                        kind="exclusion", base="viewer", subtract="banned"
                    ),
                },
            ),
        }

    @pytest.mark.asyncio
    async def test_union_permission(self) -> None:
        """can_view = owner + editor + viewer; editor has can_view."""
        evaluator = await _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="editor")],
            type_defs=self._doc_type_def(),
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view")],
        )
        assert result.allowed is True

    @pytest.mark.asyncio
    async def test_union_no_match(self) -> None:
        evaluator = await _make_evaluator(
            tuples=[],
            type_defs=self._doc_type_def(),
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view")],
        )
        assert result.allowed is False

    @pytest.mark.asyncio
    async def test_arrow_permission(self) -> None:
        """document.can_view = parent->can_view; traverse parent folder."""
        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={"parent": ["folder"]},
                permissions={
                    "can_view": PermissionRule(
                        kind="arrow",
                        from_relation="parent",
                        to_permission="can_view",
                    ),
                },
            ),
            "folder": TypeDefinition(
                name="folder",
                relations={"viewer": ["user"]},
                permissions={
                    "can_view": PermissionRule(
                        kind="union", relations=["viewer"]
                    ),
                },
            ),
        }
        evaluator = await _make_evaluator(
            tuples=[
                _tuple(
                    object_type="document",
                    object_id="readme",
                    relation="parent",
                    subject_type="folder",
                    subject_id="engineering",
                ),
                _tuple(
                    object_type="folder",
                    object_id="engineering",
                    relation="viewer",
                    subject_type="user",
                    subject_id="alice",
                ),
            ],
            type_defs=type_defs,
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view")],
        )
        assert result.allowed is True


class TestAsyncReBACMaxDepth:
    @pytest.mark.asyncio
    async def test_max_depth_prevents_infinite_recursion(self) -> None:
        """Circular group membership should not cause infinite loop."""
        evaluator = await _make_evaluator(
            tuples=[
                _tuple(
                    object_type="document",
                    object_id="readme",
                    relation="viewer",
                    subject_type="group",
                    subject_id="a",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="a",
                    relation="member",
                    subject_type="group",
                    subject_id="b",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="b",
                    relation="member",
                    subject_type="group",
                    subject_id="a",
                    subject_relation="member",
                ),
            ],
            max_depth=5,
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is False


class TestAsyncReBACDenyOverride:
    @pytest.mark.asyncio
    async def test_deny_policy_overrides_allow(self) -> None:
        evaluator = await _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")]
        )
        result = await evaluator.evaluate(
            _request(subject_id="alice"),
            [
                _policy(permission="viewer", effect=PolicyEffect.ALLOW, priority=0),
                _policy(
                    permission="viewer",
                    effect=PolicyEffect.DENY,
                    priority=10,
                    policy_id="deny-p",
                ),
            ],
        )
        assert result.allowed is False
