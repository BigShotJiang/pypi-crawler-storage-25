"""Tests for ReBAC evaluator — relationship-based access control."""

from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    PermissionRule,
    Policy,
    PolicyEffect,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)


def _request(
    subject_id: str = "alice",
    action: str = "read",
    resource_type: str = "document",
    resource_id: str = "readme",
    tenant_id: str = "t1",
) -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(id=subject_id),
        action=Action(name=action),
        resource=Resource(id=resource_id, resource_type=resource_type),
        tenant_id=tenant_id,
    )


def _policy(
    resource_type: str = "document",
    permission: str = "viewer",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    policy_id: str = "p1",
) -> Policy:
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="rebac",
        conditions={
            "object_type": resource_type,
            "permission": permission,
            "subject_type": "user",
        },
        effect=effect,
        priority=priority,
    )


def _make_evaluator(
    tuples: list[RelationTuple] | None = None,
    type_defs: dict[str, TypeDefinition] | None = None,
    max_depth: int = 25,
) -> ReBACEvaluator:
    store = InMemoryRelationshipStore()
    if tuples:
        for t in tuples:
            store.write_tuple(t)
    return ReBACEvaluator(
        relationship_store=store,
        type_definitions=type_defs or {},
        max_depth=max_depth,
    )


def _tuple(
    object_type: str = "document",
    object_id: str = "readme",
    relation: str = "viewer",
    subject_type: str = "user",
    subject_id: str = "alice",
    subject_relation: str | None = None,
    tenant_id: str = "t1",
) -> RelationTuple:
    return RelationTuple(
        tenant_id=tenant_id,
        object_type=object_type,
        object_id=object_id,
        relation=relation,
        subject_type=subject_type,
        subject_id=subject_id,
        subject_relation=subject_relation,
    )


class TestReBACEvaluatorSupports:
    def test_supports_rebac_policy(self) -> None:
        evaluator = _make_evaluator()
        assert evaluator.supports(
            Policy(tenant_id="t1", evaluator_type="rebac")
        )
        assert not evaluator.supports(
            Policy(tenant_id="t1", evaluator_type="rbac")
        )


class TestReBACDirectRelations:
    def test_direct_relation_allows(self) -> None:
        evaluator = _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")]
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is True

    def test_no_relation_denies(self) -> None:
        evaluator = _make_evaluator(tuples=[])
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is False

    def test_wrong_relation_denies(self) -> None:
        evaluator = _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")]
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="editor")],
        )
        assert result.allowed is False


class TestReBACWildcard:
    def test_wildcard_allows_any_subject(self) -> None:
        evaluator = _make_evaluator(
            tuples=[_tuple(subject_id="*", relation="viewer")]
        )
        result = evaluator.evaluate(
            _request(subject_id="bob"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is True


class TestReBACSubjectSets:
    def test_subject_set_indirect_membership(self) -> None:
        """document:readme#viewer@group:devs#member + group:devs#member@user:alice
        → user:alice can view document:readme"""
        evaluator = _make_evaluator(
            tuples=[
                _tuple(
                    relation="viewer",
                    subject_type="group",
                    subject_id="devs",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="devs",
                    relation="member",
                    subject_type="user",
                    subject_id="alice",
                ),
            ]
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is True

    def test_subject_set_non_member_denied(self) -> None:
        evaluator = _make_evaluator(
            tuples=[
                _tuple(
                    relation="viewer",
                    subject_type="group",
                    subject_id="devs",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="devs",
                    relation="member",
                    subject_type="user",
                    subject_id="alice",
                ),
            ]
        )
        result = evaluator.evaluate(
            _request(subject_id="bob"),
            [_policy(permission="viewer")],
        )
        assert result.allowed is False


class TestReBACComputedPermissions:
    def _doc_type_def(self) -> dict[str, TypeDefinition]:
        return {
            "document": TypeDefinition(
                name="document",
                relations={
                    "owner": ["user"],
                    "editor": ["user"],
                    "viewer": ["user"],
                    "banned": ["user"],
                    "org_member": ["user"],
                },
                permissions={
                    "can_edit": PermissionRule(
                        kind="union", relations=["owner", "editor"]
                    ),
                    "can_view": PermissionRule(
                        kind="union", relations=["owner", "editor", "viewer"]
                    ),
                    "can_view_restricted": PermissionRule(
                        kind="intersection", relations=["viewer", "org_member"]
                    ),
                    "can_view_safe": PermissionRule(
                        kind="exclusion", base="viewer", subtract="banned"
                    ),
                },
            ),
        }

    def test_union_permission(self) -> None:
        """can_view = owner + editor + viewer; editor has can_view."""
        evaluator = _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="editor")],
            type_defs=self._doc_type_def(),
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view")],
        )
        assert result.allowed is True

    def test_union_no_match(self) -> None:
        evaluator = _make_evaluator(
            tuples=[],
            type_defs=self._doc_type_def(),
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view")],
        )
        assert result.allowed is False

    def test_intersection_permission(self) -> None:
        """can_view_restricted = viewer & org_member; both must hold."""
        evaluator = _make_evaluator(
            tuples=[
                _tuple(subject_id="alice", relation="viewer"),
                _tuple(subject_id="alice", relation="org_member"),
            ],
            type_defs=self._doc_type_def(),
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view_restricted")],
        )
        assert result.allowed is True

    def test_intersection_fails_missing_one(self) -> None:
        evaluator = _make_evaluator(
            tuples=[
                _tuple(subject_id="alice", relation="viewer"),
                # missing org_member
            ],
            type_defs=self._doc_type_def(),
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view_restricted")],
        )
        assert result.allowed is False

    def test_exclusion_permission(self) -> None:
        """can_view_safe = viewer - banned; viewer allowed if not banned."""
        evaluator = _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")],
            type_defs=self._doc_type_def(),
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view_safe")],
        )
        assert result.allowed is True

    def test_exclusion_blocked_when_banned(self) -> None:
        evaluator = _make_evaluator(
            tuples=[
                _tuple(subject_id="alice", relation="viewer"),
                _tuple(subject_id="alice", relation="banned"),
            ],
            type_defs=self._doc_type_def(),
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view_safe")],
        )
        assert result.allowed is False

    def test_arrow_permission(self) -> None:
        """document.can_view = parent->can_view; traverse parent folder."""
        type_defs = {
            "document": TypeDefinition(
                name="document",
                relations={"parent": ["folder"]},
                permissions={
                    "can_view": PermissionRule(
                        kind="arrow",
                        from_relation="parent",
                        to_permission="can_view",
                    ),
                },
            ),
            "folder": TypeDefinition(
                name="folder",
                relations={"viewer": ["user"]},
                permissions={
                    "can_view": PermissionRule(
                        kind="union", relations=["viewer"]
                    ),
                },
            ),
        }
        evaluator = _make_evaluator(
            tuples=[
                _tuple(
                    object_type="document",
                    object_id="readme",
                    relation="parent",
                    subject_type="folder",
                    subject_id="engineering",
                ),
                _tuple(
                    object_type="folder",
                    object_id="engineering",
                    relation="viewer",
                    subject_type="user",
                    subject_id="alice",
                ),
            ],
            type_defs=type_defs,
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="can_view")],
        )
        assert result.allowed is True


class TestReBACMaxDepth:
    def test_max_depth_prevents_infinite_recursion(self) -> None:
        """Circular group membership should not cause infinite loop."""
        evaluator = _make_evaluator(
            tuples=[
                _tuple(
                    object_type="document",
                    object_id="readme",
                    relation="viewer",
                    subject_type="group",
                    subject_id="a",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="a",
                    relation="member",
                    subject_type="group",
                    subject_id="b",
                    subject_relation="member",
                ),
                _tuple(
                    object_type="group",
                    object_id="b",
                    relation="member",
                    subject_type="group",
                    subject_id="a",
                    subject_relation="member",
                ),
            ],
            max_depth=5,
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [_policy(permission="viewer")],
        )
        # Should terminate (not hang) and deny (alice not reachable)
        assert result.allowed is False


class TestReBACDenyOverride:
    def test_deny_policy_overrides_allow(self) -> None:
        evaluator = _make_evaluator(
            tuples=[_tuple(subject_id="alice", relation="viewer")]
        )
        result = evaluator.evaluate(
            _request(subject_id="alice"),
            [
                _policy(permission="viewer", effect=PolicyEffect.ALLOW, priority=0),
                _policy(
                    permission="viewer",
                    effect=PolicyEffect.DENY,
                    priority=10,
                    policy_id="deny-p",
                ),
            ],
        )
        assert result.allowed is False
