"""Tests for session.* ABAC namespace (Phase 6 — ENH-001)."""

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    Resource,
    Session,
    Subject,
)


def _abac_request(session: Session | None = None) -> AuthorizationRequest:
    ctx = {}
    if session is not None:
        ctx["_session"] = session
    return AuthorizationRequest(
        subject=Subject(id="alice", attributes={"roles": ["editor"]}),
        action=Action(name="promote"),
        resource=Resource(id="knowledge-1", resource_type="knowledge"),
        tenant_id="t1",
        context=ctx,
    )


class TestABACSessionNamespace:
    def setup_method(self) -> None:
        self.evaluator = ABACEvaluator()

    def test_session_scope_condition(self) -> None:
        """Policy requiring session.scope == 'WORKSPACE' matches."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
            metadata={"scope": "WORKSPACE"},
        )
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.scope": {"op": "eq", "value": "WORKSPACE"},
            },
        )
        req = _abac_request(session=session)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_session_scope_mismatch_denies(self) -> None:
        """Policy requiring WORKSPACE, but session is PROJECT → deny."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.scope": {"op": "eq", "value": "WORKSPACE"},
            },
        )
        req = _abac_request(session=session)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False

    def test_session_activated_roles_condition(self) -> None:
        """Policy checking if 'editor' is in session.activated_roles."""
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor", "viewer"],
        )
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.activated_roles": {"op": "contains", "value": "editor"},
            },
        )
        req = _abac_request(session=session)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_no_session_session_path_resolves_to_none(self) -> None:
        """Without a session, session.* paths resolve to None → condition fails."""
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match="promote",
            conditions={
                "session.scope": {"op": "eq", "value": "WORKSPACE"},
            },
        )
        req = _abac_request(session=None)
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False
