"""Tests for TrustGateEvaluator."""

from open_guard.adapters.evaluators.trust import TrustGateEvaluator
from open_guard.domain.entities import (
    Action,
    ActorType,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)


def _request(
    trust_score: float | None = None,
    actor_type: ActorType = ActorType.AGENT,
    action: str = "knowledge:write",
    resource_type: str = "document",
    tenant_id: str = "t1",
    on_behalf_of: Subject | None = None,
) -> AuthorizationRequest:
    attrs: dict = {}
    if trust_score is not None:
        attrs["trust_score"] = trust_score
    return AuthorizationRequest(
        subject=Subject(
            id="agent-1",
            actor_type=actor_type,
            attributes=attrs,
            on_behalf_of=on_behalf_of,
        ),
        action=Action(name=action),
        resource=Resource(id="doc-1", resource_type=resource_type),
        tenant_id=tenant_id,
    )


def _policy(
    min_trust_score: float = 0.7,
    trust_scope: str | None = None,
    action: str = "*",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    policy_id: str = "trust-p1",
    subject_match: dict | None = None,  # type: ignore[type-arg]
) -> Policy:
    conditions: dict = {"min_trust_score": min_trust_score}  # type: ignore[type-arg]
    if trust_scope is not None:
        conditions["trust_scope"] = trust_scope
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="trust",
        subject_match=subject_match or {},
        action_match=action,
        effect=effect,
        priority=priority,
        conditions=conditions,
    )


class TestTrustGateEvaluator:
    """TrustGateEvaluator tests."""

    def test_supports_trust_policy(self) -> None:
        ev = TrustGateEvaluator()
        assert ev.supports(Policy(tenant_id="t", evaluator_type="trust"))
        assert not ev.supports(Policy(tenant_id="t", evaluator_type="rbac"))

    def test_evaluator_type(self) -> None:
        assert TrustGateEvaluator().evaluator_type == "trust"

    # 1. trust_score >= threshold → ALLOW
    def test_trust_allow(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.85), [_policy(min_trust_score=0.7)])
        assert result.allowed is True
        assert result.evaluator == "trust"
        assert "trust-p1" in result.matched_policies
        assert "0.85" in result.reason
        assert "0.7" in result.reason

    # 2. trust_score < threshold → DENY
    def test_trust_deny_below_threshold(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.3), [_policy(min_trust_score=0.7)])
        assert result.allowed is False
        assert "0.3" in result.reason
        assert "0.7" in result.reason

    # 3. no trust_score attribute → DENY
    def test_trust_deny_missing_score(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=None), [_policy(min_trust_score=0.7)])
        assert result.allowed is False
        assert "Missing trust_score" in result.reason

    # 4. trust_scope="root" — root has high score, immediate has low → checks root only
    def test_trust_scope_root(self) -> None:
        ev = TrustGateEvaluator()
        root_user = Subject(
            id="user-1",
            actor_type=ActorType.USER,
            attributes={"trust_score": 0.9},
        )
        req = _request(trust_score=0.3, on_behalf_of=root_user)
        result = ev.evaluate(req, [_policy(min_trust_score=0.7, trust_scope="root")])
        assert result.allowed is True

    # 5. trust_scope="all" — one actor below threshold → DENY
    def test_trust_scope_all(self) -> None:
        ev = TrustGateEvaluator()
        root_user = Subject(
            id="user-1",
            actor_type=ActorType.USER,
            attributes={"trust_score": 0.9},
        )
        # Immediate agent has low trust
        req = _request(trust_score=0.3, on_behalf_of=root_user)
        result = ev.evaluate(req, [_policy(min_trust_score=0.7, trust_scope="all")])
        assert result.allowed is False

    # 6. trust_scope="all" — all actors meet threshold → ALLOW
    def test_trust_scope_all_pass(self) -> None:
        ev = TrustGateEvaluator()
        root_user = Subject(
            id="user-1",
            actor_type=ActorType.USER,
            attributes={"trust_score": 0.9},
        )
        req = _request(trust_score=0.8, on_behalf_of=root_user)
        result = ev.evaluate(req, [_policy(min_trust_score=0.7, trust_scope="all")])
        assert result.allowed is True

    # 7. no trust_scope → checks immediate only
    def test_trust_scope_immediate_default(self) -> None:
        ev = TrustGateEvaluator()
        root_user = Subject(
            id="user-1",
            actor_type=ActorType.USER,
            attributes={"trust_score": 0.2},
        )
        # Immediate has high trust, root has low — should pass (immediate default)
        req = _request(trust_score=0.9, on_behalf_of=root_user)
        result = ev.evaluate(req, [_policy(min_trust_score=0.7)])
        assert result.allowed is True

    # 8. action_match filters
    def test_trust_action_match(self) -> None:
        ev = TrustGateEvaluator()
        policy = _policy(min_trust_score=0.5, action="knowledge:read")
        # Request action is "knowledge:write" — doesn't match
        result = ev.evaluate(_request(trust_score=0.9, action="knowledge:write"), [policy])
        assert result.allowed is False
        # Now with matching action
        result = ev.evaluate(_request(trust_score=0.9, action="knowledge:read"), [policy])
        assert result.allowed is True

    # 9. subject_match filters by actor_type
    def test_trust_subject_match(self) -> None:
        ev = TrustGateEvaluator()
        policy = _policy(
            min_trust_score=0.5,
            subject_match={"actor_type": "user"},
        )
        # Agent doesn't match "user" filter
        result = ev.evaluate(
            _request(trust_score=0.9, actor_type=ActorType.AGENT), [policy]
        )
        assert result.allowed is False
        # User matches
        result = ev.evaluate(
            _request(trust_score=0.9, actor_type=ActorType.USER), [policy]
        )
        assert result.allowed is True

    # 10. higher priority deny overrides lower priority allow
    def test_trust_priority_deny_wins(self) -> None:
        ev = TrustGateEvaluator()
        allow_policy = _policy(
            min_trust_score=0.5, effect=PolicyEffect.ALLOW, priority=1, policy_id="allow-p"
        )
        deny_policy = _policy(
            min_trust_score=0.5, effect=PolicyEffect.DENY, priority=2, policy_id="deny-p"
        )
        result = ev.evaluate(_request(trust_score=0.9), [allow_policy, deny_policy])
        assert result.allowed is False
        assert "deny-p" in result.matched_policies

    # 11. multiple trust policies compose correctly
    def test_trust_multiple_policies(self) -> None:
        ev = TrustGateEvaluator()
        strict = _policy(
            min_trust_score=0.95, effect=PolicyEffect.ALLOW, priority=0, policy_id="strict"
        )
        lenient = _policy(
            min_trust_score=0.5, effect=PolicyEffect.ALLOW, priority=0, policy_id="lenient"
        )
        # Score 0.8 meets lenient but not strict
        result = ev.evaluate(_request(trust_score=0.8), [strict, lenient])
        assert result.allowed is True
        assert "lenient" in result.matched_policies

    # 12. edge: trust_score=0.0 with threshold=0.0 → ALLOW (gte)
    def test_trust_edge_zero(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.0), [_policy(min_trust_score=0.0)])
        assert result.allowed is True

    # 13. edge: trust_score=1.0 with threshold=1.0 → ALLOW
    def test_trust_edge_one(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=1.0), [_policy(min_trust_score=1.0)])
        assert result.allowed is True

    # 14. decision trace — verify PolicyMatch + ConditionResult populated
    def test_trust_decision_trace(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.85), [_policy(min_trust_score=0.7)])
        assert result.allowed is True
        assert len(result.matched_policies_detail) == 1
        pm = result.matched_policies_detail[0]
        assert pm.policy_id == "trust-p1"
        assert pm.matched is True
        assert len(pm.matched_conditions) == 1
        cr = pm.matched_conditions[0]
        assert cr.path == "subject.trust_score"
        assert cr.operator == "gte"
        assert cr.expected == 0.7
        assert cr.actual == 0.85
        assert cr.matched is True

    def test_trust_decision_trace_deny(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.3), [_policy(min_trust_score=0.7)])
        assert result.allowed is False
        assert len(result.matched_policies_detail) == 1
        pm = result.matched_policies_detail[0]
        assert pm.matched is False
        assert len(pm.matched_conditions) == 1
        cr = pm.matched_conditions[0]
        assert cr.actual == 0.3
        assert cr.matched is False

    def test_trust_decision_trace_root_scope(self) -> None:
        ev = TrustGateEvaluator()
        root_user = Subject(
            id="user-1",
            actor_type=ActorType.USER,
            attributes={"trust_score": 0.9},
        )
        req = _request(trust_score=0.3, on_behalf_of=root_user)
        result = ev.evaluate(req, [_policy(min_trust_score=0.7, trust_scope="root")])
        pm = result.matched_policies_detail[0]
        cr = pm.matched_conditions[0]
        assert cr.path == "chain.root.trust_score"
        assert cr.actual == 0.9

    def test_trust_attributes_read(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.85), [_policy()])
        assert "trust_score" in result.attributes_read

    def test_trust_duration_ms(self) -> None:
        ev = TrustGateEvaluator()
        result = ev.evaluate(_request(trust_score=0.85), [_policy()])
        assert result.duration_ms >= 0.0
