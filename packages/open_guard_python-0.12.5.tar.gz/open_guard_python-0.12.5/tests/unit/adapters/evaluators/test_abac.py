"""Tests for ABAC evaluator."""

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.domain.entities import (
    Action,
    ActorType,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)


def _request(
    subject_attrs: dict | None = None,  # type: ignore[type-arg]
    action: str = "read",
    resource_attrs: dict | None = None,  # type: ignore[type-arg]
    context: dict | None = None,  # type: ignore[type-arg]
    actor_type: ActorType = ActorType.USER,
) -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(
            id="user-1",
            actor_type=actor_type,
            attributes=subject_attrs or {},
        ),
        action=Action(name=action),
        resource=Resource(
            id="res-1",
            resource_type="document",
            attributes=resource_attrs or {},
        ),
        context=context or {},
        tenant_id="t1",
    )


def _policy(
    conditions: dict | None = None,  # type: ignore[type-arg]
    action: str = "*",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    policy_id: str = "p1",
) -> Policy:
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="abac",
        conditions=conditions or {},
        action_match=action,
        effect=effect,
        priority=priority,
    )


class TestABACEvaluator:
    def test_supports_abac_policy(self) -> None:
        evaluator = ABACEvaluator()
        assert evaluator.supports(Policy(tenant_id="t", evaluator_type="abac"))
        assert not evaluator.supports(Policy(tenant_id="t", evaluator_type="rbac"))

    def test_eq_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "engineering"}),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_eq_no_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "marketing"}),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"}
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_simple_equality_shorthand(self) -> None:
        """Conditions can use simple key=value without op/value wrapper."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "engineering"}),
            [_policy(conditions={"subject.department": "engineering"})],
        )
        assert result.allowed is True

    def test_in_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(resource_attrs={"classification": "internal"}),
            [
                _policy(
                    conditions={
                        "resource.classification": {
                            "op": "in",
                            "value": ["public", "internal"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_not_in_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(resource_attrs={"classification": "confidential"}),
            [
                _policy(
                    conditions={
                        "resource.classification": {
                            "op": "not_in",
                            "value": ["public", "internal"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_contains_operator_list(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": ["ml", "data", "infra"]}),
            [_policy(conditions={"subject.tags": {"op": "contains", "value": "ml"}})],
        )
        assert result.allowed is True

    def test_contains_operator_string(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"email": "user@engineering.com"}),
            [
                _policy(
                    conditions={
                        "subject.email": {"op": "contains", "value": "engineering"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_gt_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(context={"hour": 14}),
            [_policy(conditions={"context.hour": {"op": "gt", "value": 9}})],
        )
        assert result.allowed is True

    def test_lt_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(context={"hour": 8}),
            [_policy(conditions={"context.hour": {"op": "lt", "value": 9}})],
        )
        assert result.allowed is True

    def test_gte_lte_operators(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(context={"hour": 9}),
            [
                _policy(
                    conditions={
                        "context.hour": {"op": "gte", "value": 9},
                    }
                )
            ],
        )
        assert result.allowed is True

        result = evaluator.evaluate(
            _request(context={"hour": 17}),
            [
                _policy(
                    conditions={
                        "context.hour": {"op": "lte", "value": 17},
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_regex_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"email": "admin@company.com"}),
            [
                _policy(
                    conditions={
                        "subject.email": {"op": "regex", "value": r".*@company\.com$"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_exists_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"clearance": "top-secret"}),
            [
                _policy(
                    conditions={"subject.clearance": {"op": "exists", "value": True}}
                )
            ],
        )
        assert result.allowed is True

        result = evaluator.evaluate(
            _request(subject_attrs={}),
            [
                _policy(
                    conditions={"subject.clearance": {"op": "exists", "value": True}}
                )
            ],
        )
        assert result.allowed is False

    def test_neq_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"status": "active"}),
            [
                _policy(
                    conditions={"subject.status": {"op": "neq", "value": "suspended"}}
                )
            ],
        )
        assert result.allowed is True

    def test_multiple_conditions_and_logic(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(
                subject_attrs={"department": "engineering", "clearance": "high"},
                resource_attrs={"classification": "internal"},
            ),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"},
                        "subject.clearance": {"op": "eq", "value": "high"},
                        "resource.classification": {"op": "eq", "value": "internal"},
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_multiple_conditions_one_fails(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(
                subject_attrs={"department": "engineering", "clearance": "low"},
            ),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"},
                        "subject.clearance": {"op": "eq", "value": "high"},
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_actor_type_condition(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(actor_type=ActorType.AGENT),
            [
                _policy(
                    conditions={"subject.actor_type": {"op": "eq", "value": "agent"}}
                )
            ],
        )
        assert result.allowed is True

    def test_deny_effect(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "hr"}),
            [
                _policy(
                    conditions={"subject.department": {"op": "eq", "value": "hr"}},
                    effect=PolicyEffect.DENY,
                )
            ],
        )
        assert result.allowed is False

    def test_no_matching_policy(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "sales"}),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"}
                    }
                )
            ],
        )
        assert result.allowed is False
        assert "No matching" in result.reason

    def test_empty_policies(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(_request(), [])
        assert result.allowed is False

    def test_action_matching(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(action="write"),
            [_policy(conditions={}, action="read")],
        )
        assert result.allowed is False

    def test_action_list_matching(self) -> None:
        evaluator = ABACEvaluator()
        policy = Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="abac",
            action_match=["read", "write"],
            conditions={},
        )
        result = evaluator.evaluate(_request(action="write"), [policy])
        assert result.allowed is True

    def test_simple_equality_shorthand_no_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "sales"}),
            [_policy(conditions={"subject.department": "engineering"})],
        )
        assert result.allowed is False

    def test_contains_non_iterable(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"count": 42}),
            [
                _policy(
                    conditions={"subject.count": {"op": "contains", "value": 4}}
                )
            ],
        )
        assert result.allowed is False

    def test_in_non_list_expected(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"role": "admin"}),
            [
                _policy(
                    conditions={
                        "subject.role": {"op": "in", "value": "not-a-list"}
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_regex_non_string(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"count": 42}),
            [
                _policy(
                    conditions={
                        "subject.count": {"op": "regex", "value": ".*"}
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_exists_false(self) -> None:
        """exists with value=False means attribute should NOT exist."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={}),
            [
                _policy(
                    conditions={
                        "subject.clearance": {"op": "exists", "value": False}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_unknown_operator(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"x": 1}),
            [
                _policy(
                    conditions={
                        "subject.x": {"op": "unknown_op", "value": 1}
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_gt_with_none(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={}),
            [
                _policy(
                    conditions={
                        "subject.missing": {"op": "gt", "value": 5}
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_not_in_non_list(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"x": "a"}),
            [
                _policy(
                    conditions={
                        "subject.x": {"op": "not_in", "value": "not-a-list"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_resolve_deep_path(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(context={"geo": "US"}),
            [
                _policy(
                    conditions={"context.geo": {"op": "eq", "value": "US"}}
                )
            ],
        )
        assert result.allowed is True


class TestABACSetOperators:
    """Tests for set operators: contains_any, contains_all, is_subset."""

    def test_contains_any_match(self) -> None:
        """At least one element overlaps."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": ["admin", "dev"]}),
            [
                _policy(
                    conditions={
                        "subject.tags": {
                            "op": "contains_any",
                            "value": ["admin", "ops"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_contains_any_no_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": ["dev"]}),
            [
                _policy(
                    conditions={
                        "subject.tags": {
                            "op": "contains_any",
                            "value": ["admin", "ops"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_contains_any_empty_actual(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": []}),
            [
                _policy(
                    conditions={
                        "subject.tags": {
                            "op": "contains_any",
                            "value": ["admin"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_contains_all_match(self) -> None:
        """All specified elements present."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"certs": ["soc2", "hipaa", "gdpr"]}),
            [
                _policy(
                    conditions={
                        "subject.certs": {
                            "op": "contains_all",
                            "value": ["soc2", "hipaa"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_contains_all_partial_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"certs": ["soc2"]}),
            [
                _policy(
                    conditions={
                        "subject.certs": {
                            "op": "contains_all",
                            "value": ["soc2", "hipaa"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_is_subset_true(self) -> None:
        """Left is subset of right."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"roles": ["viewer"]}),
            [
                _policy(
                    conditions={
                        "subject.roles": {
                            "op": "is_subset",
                            "value": ["viewer", "editor", "admin"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_is_subset_false(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"roles": ["viewer", "superadmin"]}),
            [
                _policy(
                    conditions={
                        "subject.roles": {
                            "op": "is_subset",
                            "value": ["viewer", "editor"],
                        }
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_set_operators_with_non_list_actual(self) -> None:
        """Non-list attribute returns False for all set ops."""
        evaluator = ABACEvaluator()
        for op in ("contains_any", "contains_all", "is_subset"):
            result = evaluator.evaluate(
                _request(subject_attrs={"val": "string-not-list"}),
                [
                    _policy(
                        conditions={
                            "subject.val": {"op": op, "value": ["a"]}
                        }
                    )
                ],
            )
            assert result.allowed is False, f"Expected False for op={op}"


class TestABACNegatedOperators:
    """Tests for negated operators: not_contains, not_regex."""

    def test_not_contains_string(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"email": "alice@example.com"}),
            [
                _policy(
                    conditions={
                        "subject.email": {"op": "not_contains", "value": "evil.com"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_not_contains_list(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": ["admin", "dev"]}),
            [
                _policy(
                    conditions={
                        "subject.tags": {"op": "not_contains", "value": "banned"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_not_contains_fails(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": ["banned", "dev"]}),
            [
                _policy(
                    conditions={
                        "subject.tags": {"op": "not_contains", "value": "banned"}
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_not_contains_non_iterable(self) -> None:
        """Non-string/list attribute returns True (can't contain anything)."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"count": 42}),
            [
                _policy(
                    conditions={
                        "subject.count": {"op": "not_contains", "value": "x"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_not_regex_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"email": "alice@company.com"}),
            [
                _policy(
                    conditions={
                        "subject.email": {
                            "op": "not_regex",
                            "value": r".*@evil\.com",
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_not_regex_fails(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"email": "alice@evil.com"}),
            [
                _policy(
                    conditions={
                        "subject.email": {
                            "op": "not_regex",
                            "value": r".*@evil\.com",
                        }
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_not_regex_non_string(self) -> None:
        """Non-string attribute returns True."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"count": 42}),
            [
                _policy(
                    conditions={
                        "subject.count": {"op": "not_regex", "value": ".*"}
                    }
                )
            ],
        )
        assert result.allowed is True


class TestABACConditionGroups:
    """Tests for OR logic via condition_groups."""

    def test_single_group_matches(self) -> None:
        """Single condition group — same as legacy AND."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "engineering"}),
            [
                _policy(
                    conditions={
                        "condition_groups": [
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "engineering",
                                }
                            }
                        ]
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_any_group_matches_allows(self) -> None:
        """Multiple groups — OR semantics (any group match = pass)."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "security"}),
            [
                _policy(
                    conditions={
                        "condition_groups": [
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "engineering",
                                }
                            },
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "security",
                                }
                            },
                        ]
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_no_group_matches_denies(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "marketing"}),
            [
                _policy(
                    conditions={
                        "condition_groups": [
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "engineering",
                                }
                            },
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "security",
                                }
                            },
                        ]
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_backward_compatible_conditions_dict(self) -> None:
        """Legacy 'conditions' dict works as single group (AND-only)."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "engineering", "level": "senior"}),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"},
                        "subject.level": {"op": "eq", "value": "senior"},
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_empty_condition_groups_matches(self) -> None:
        """Empty condition_groups list matches (no conditions)."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(),
            [_policy(conditions={"condition_groups": []})],
        )
        assert result.allowed is True

    def test_condition_groups_with_set_operators(self) -> None:
        """OR logic combined with set operators."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"tags": ["admin", "dev"]}),
            [
                _policy(
                    conditions={
                        "condition_groups": [
                            {
                                "subject.tags": {
                                    "op": "contains_any",
                                    "value": ["admin"],
                                }
                            },
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "security",
                                }
                            },
                        ]
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_condition_groups_and_within_group(self) -> None:
        """AND logic within a single group still works."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "engineering", "level": "junior"}),
            [
                _policy(
                    conditions={
                        "condition_groups": [
                            {
                                "subject.department": {
                                    "op": "eq",
                                    "value": "engineering",
                                },
                                "subject.level": {
                                    "op": "eq",
                                    "value": "senior",
                                },
                            }
                        ]
                    }
                )
            ],
        )
        assert result.allowed is False  # department matches but level doesn't


class TestABACEvaluationDetail:
    """Phase 3 T12 — structured matched_policies_detail emission."""

    def test_detail_emitted_on_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "engineering"}),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"}
                    },
                    policy_id="p-match",
                )
            ],
        )
        assert result.allowed is True
        assert len(result.matched_policies_detail) == 1
        m = result.matched_policies_detail[0]
        assert m.policy_id == "p-match"
        assert m.matched is True
        assert "subject.department" in result.attributes_read
        assert result.duration_ms >= 0.0

    def test_detail_emitted_on_reject(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            _request(subject_attrs={"department": "marketing"}),
            [
                _policy(
                    conditions={
                        "subject.department": {"op": "eq", "value": "engineering"}
                    },
                    policy_id="p-reject",
                )
            ],
        )
        assert result.allowed is False
        assert len(result.matched_policies_detail) == 1
        assert result.matched_policies_detail[0].matched is False


class TestABACChainAware:
    """Phase 3 — chain-aware ABAC predicates (FEAT-005)."""

    @staticmethod
    def _request_with_chain(
        agent_attrs: dict | None = None,  # type: ignore[type-arg]
        user_attrs: dict | None = None,  # type: ignore[type-arg]
    ) -> AuthorizationRequest:
        user = Subject(
            id="alice", actor_type=ActorType.USER, attributes=user_attrs or {}
        )
        agent = Subject(
            id="helper",
            actor_type=ActorType.AGENT,
            attributes=agent_attrs or {},
            on_behalf_of=user,
        )
        return AuthorizationRequest(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id="t1",
        )

    def test_chain_depth_condition(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(),
            [_policy(conditions={"chain.depth": {"op": "eq", "value": 1}})],
        )
        assert result.allowed is True

    def test_chain_depth_deny_on_too_deep(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(),
            [_policy(conditions={"chain.depth": {"op": "lte", "value": 0}})],
        )
        assert result.allowed is False

    def test_chain_root_actor_attribute(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(user_attrs={"trusted": True}),
            [
                _policy(
                    conditions={
                        "chain.root_actor.trusted": {"op": "eq", "value": True}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_chain_root_actor_id(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(),
            [
                _policy(
                    conditions={
                        "chain.root_actor.id": {"op": "eq", "value": "alice"}
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_chain_immediate_actor_id(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(),
            [
                _policy(
                    conditions={
                        "chain.immediate_actor.id": {
                            "op": "eq", "value": "helper"
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_any_ancestor_matches_trusted(self) -> None:
        """Chain where the user (ancestor) is trusted."""
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(user_attrs={"trusted": True}),
            [
                _policy(
                    conditions={
                        "chain.ancestors": {
                            "op": "any_matches",
                            "value": {
                                "path": "trusted",
                                "op": "eq",
                                "value": True,
                            },
                        }
                    }
                )
            ],
        )
        assert result.allowed is True

    def test_any_ancestor_no_match(self) -> None:
        evaluator = ABACEvaluator()
        result = evaluator.evaluate(
            self._request_with_chain(user_attrs={"trusted": False}),
            [
                _policy(
                    conditions={
                        "chain.ancestors": {
                            "op": "any_matches",
                            "value": {
                                "path": "trusted",
                                "op": "eq",
                                "value": True,
                            },
                        }
                    }
                )
            ],
        )
        assert result.allowed is False

    def test_non_delegated_subject_has_empty_ancestors(self) -> None:
        """chain.depth=0 for direct subject."""
        evaluator = ABACEvaluator()
        req = AuthorizationRequest(
            subject=Subject(id="alice"),
            action=Action(name="read"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id="t1",
        )
        result = evaluator.evaluate(
            req,
            [_policy(conditions={"chain.depth": {"op": "eq", "value": 0}})],
        )
        assert result.allowed is True
