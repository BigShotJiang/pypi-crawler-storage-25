"""Tests for InMemoryRelationshipStore."""

import pytest

from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import RelationTuple
from open_guard.domain.exceptions import RelationshipError


def _tuple(
    tenant_id: str = "t1",
    object_type: str = "document",
    object_id: str = "readme",
    relation: str = "viewer",
    subject_type: str = "user",
    subject_id: str = "alice",
    subject_relation: str | None = None,
) -> RelationTuple:
    return RelationTuple(
        tenant_id=tenant_id,
        object_type=object_type,
        object_id=object_id,
        relation=relation,
        subject_type=subject_type,
        subject_id=subject_id,
        subject_relation=subject_relation,
    )


class TestInMemoryRelationshipStore:
    def test_write_and_read(self) -> None:
        store = InMemoryRelationshipStore()
        t = _tuple()
        store.write_tuple(t)
        results = store.read_tuples("t1")
        assert len(results) == 1
        assert results[0].subject_id == "alice"

    def test_delete_tuple(self) -> None:
        store = InMemoryRelationshipStore()
        t = _tuple()
        store.write_tuple(t)
        store.delete_tuple(t.id, "t1")
        assert store.read_tuples("t1") == []

    def test_delete_nonexistent_raises(self) -> None:
        store = InMemoryRelationshipStore()
        with pytest.raises(RelationshipError):
            store.delete_tuple("nonexistent", "t1")

    def test_read_by_object(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(object_id="readme", subject_id="alice"))
        store.write_tuple(_tuple(object_id="readme", subject_id="bob"))
        store.write_tuple(_tuple(object_id="other", subject_id="charlie"))

        results = store.read_tuples(
            "t1", object_type="document", object_id="readme"
        )
        assert len(results) == 2

    def test_read_by_subject(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(object_id="doc1", subject_id="alice"))
        store.write_tuple(_tuple(object_id="doc2", subject_id="alice"))
        store.write_tuple(_tuple(object_id="doc3", subject_id="bob"))

        results = store.read_tuples("t1", subject_type="user", subject_id="alice")
        assert len(results) == 2

    def test_read_by_relation(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(relation="viewer", subject_id="alice"))
        store.write_tuple(_tuple(relation="editor", subject_id="bob"))

        results = store.read_tuples("t1", relation="viewer")
        assert len(results) == 1
        assert results[0].subject_id == "alice"

    def test_tenant_isolation(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(tenant_id="t1", subject_id="alice"))
        store.write_tuple(_tuple(tenant_id="t2", subject_id="bob"))

        assert len(store.read_tuples("t1")) == 1
        assert len(store.read_tuples("t2")) == 1
        assert store.read_tuples("t1")[0].subject_id == "alice"

    def test_duplicate_prevention(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(subject_id="alice"))
        with pytest.raises(RelationshipError, match="Duplicate"):
            store.write_tuple(_tuple(subject_id="alice"))

    def test_tuple_exists(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(subject_id="alice"))

        assert store.tuple_exists(
            "t1", "document", "readme", "viewer", "user", "alice"
        )
        assert not store.tuple_exists(
            "t1", "document", "readme", "viewer", "user", "bob"
        )

    def test_tuple_exists_with_subject_relation(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(
            _tuple(
                subject_type="group",
                subject_id="devs",
                subject_relation="member",
            )
        )

        assert store.tuple_exists(
            "t1", "document", "readme", "viewer", "group", "devs", "member"
        )
        assert not store.tuple_exists(
            "t1", "document", "readme", "viewer", "group", "devs", None
        )

    def test_read_empty_tenant(self) -> None:
        store = InMemoryRelationshipStore()
        assert store.read_tuples("nonexistent") == []

    def test_read_with_all_filters(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple())
        store.write_tuple(
            _tuple(object_id="other", subject_id="bob", relation="editor")
        )

        results = store.read_tuples(
            "t1",
            object_type="document",
            object_id="readme",
            relation="viewer",
            subject_type="user",
            subject_id="alice",
        )
        assert len(results) == 1


class TestFindObjectIdsForSubject:
    """Phase 4 (FEAT-006) — native ReBAC candidate enumeration."""

    def test_returns_distinct_object_ids(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(object_id="1", relation="owner"))
        store.write_tuple(_tuple(object_id="1", relation="viewer"))  # dupe id
        store.write_tuple(_tuple(object_id="2", relation="viewer"))

        ids = store.find_object_ids_for_subject(
            subject_id="alice",
            subject_type="user",
            object_type="document",
            tenant_id="t1",
        )
        assert ids == ["1", "2"]

    def test_pagination_offset_and_limit(self) -> None:
        store = InMemoryRelationshipStore()
        for i in range(5):
            store.write_tuple(_tuple(object_id=str(i), relation=f"r{i}"))

        first = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1", offset=0, limit=2
        )
        assert first == ["0", "1"]

        second = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1", offset=2, limit=2
        )
        assert second == ["2", "3"]

        last = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1", offset=4, limit=2
        )
        assert last == ["4"]

    def test_cross_tenant_isolation(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(tenant_id="t1", object_id="1"))
        store.write_tuple(_tuple(tenant_id="t2", object_id="2"))

        assert store.find_object_ids_for_subject(
            "alice", "user", "document", "t1"
        ) == ["1"]
        assert store.find_object_ids_for_subject(
            "alice", "user", "document", "t2"
        ) == ["2"]

    def test_empty_when_no_tuples(self) -> None:
        store = InMemoryRelationshipStore()
        assert (
            store.find_object_ids_for_subject("ghost", "user", "doc", "t1") == []
        )

    def test_subject_type_mismatch_ignored(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(subject_type="user", subject_id="alice"))
        store.write_tuple(
            _tuple(
                subject_type="agent", subject_id="alice", object_id="99"
            )
        )
        ids = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1"
        )
        assert ids == ["readme"]

    def test_object_type_filter(self) -> None:
        store = InMemoryRelationshipStore()
        store.write_tuple(_tuple(object_type="document", object_id="d1"))
        store.write_tuple(_tuple(object_type="folder", object_id="f1"))
        assert store.find_object_ids_for_subject(
            "alice", "user", "folder", "t1"
        ) == ["f1"]
