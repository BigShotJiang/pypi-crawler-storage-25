"""Tests for InMemoryTaskStore."""

from datetime import UTC, datetime

import pytest

from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import Task, TaskStatus
from open_guard.domain.exceptions import TaskError


def _task(
    task_id: str = "task-1",
    tenant_id: str = "t1",
    actor_id: str = "agent-1",
    status: TaskStatus = TaskStatus.CREATED,
    parent_task_id: str | None = None,
) -> Task:
    return Task(
        id=task_id,
        tenant_id=tenant_id,
        actor_id=actor_id,
        status=status,
        parent_task_id=parent_task_id,
        created_at=datetime(2026, 4, 16, 12, 0, 0, tzinfo=UTC),
    )


class TestInMemoryTaskStore:
    def test_add_and_get(self) -> None:
        store = InMemoryTaskStore()
        task = _task()
        stored = store.add(task)
        assert stored.id == "task-1"

        retrieved = store.get("task-1", "t1")
        assert retrieved is not None
        assert retrieved.id == "task-1"

    def test_get_nonexistent_returns_none(self) -> None:
        store = InMemoryTaskStore()
        assert store.get("nope", "t1") is None

    def test_get_wrong_tenant_returns_none(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task(tenant_id="t1"))
        assert store.get("task-1", "t2") is None

    def test_update_replaces_task(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task())
        updated = _task(status=TaskStatus.ACTIVE)
        store.update(updated)

        retrieved = store.get("task-1", "t1")
        assert retrieved is not None
        assert retrieved.status == TaskStatus.ACTIVE

    def test_update_nonexistent_raises(self) -> None:
        store = InMemoryTaskStore()
        with pytest.raises(TaskError, match="not found"):
            store.update(_task())

    def test_get_active_by_actor(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task(task_id="t1", status=TaskStatus.ACTIVE))
        store.add(_task(task_id="t2", status=TaskStatus.CREATED))
        store.add(_task(task_id="t3", status=TaskStatus.ACTIVE, actor_id="other"))

        active = store.get_active_by_actor("agent-1", "t1")
        assert len(active) == 1
        assert active[0].id == "t1"

    def test_remove(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task())
        store.remove("task-1", "t1")
        assert store.get("task-1", "t1") is None

    def test_remove_nonexistent_raises(self) -> None:
        store = InMemoryTaskStore()
        with pytest.raises(TaskError, match="not found"):
            store.remove("nope", "t1")

    def test_tenant_isolation(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task(task_id="task-1", tenant_id="t1"))
        store.add(_task(task_id="task-2", tenant_id="t2"))

        assert store.get("task-1", "t1") is not None
        assert store.get("task-1", "t2") is None
        assert store.get("task-2", "t2") is not None
