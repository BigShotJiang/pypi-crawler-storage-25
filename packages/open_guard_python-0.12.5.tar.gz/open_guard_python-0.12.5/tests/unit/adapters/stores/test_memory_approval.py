"""Tests for InMemoryApprovalStore (Phase 3)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.domain.entities import (
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
)
from open_guard.domain.exceptions import ApprovalError


def _req(
    tenant_id: str = "t1",
    subject_id: str = "alice",
    action_name: str = "send",
    resource_id: str = "email-1",
    resource_type: str = "email",
    status: ApprovalStatus = ApprovalStatus.PENDING,
    ttl: timedelta | None = None,
    now: datetime | None = None,
) -> ApprovalRequest:
    now = now or datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    req = ApprovalRequirement(approvers=["role:manager"], ttl=ttl)
    return ApprovalRequest(
        tenant_id=tenant_id,
        request_hash=ApprovalRequest.make_hash(
            tenant_id, subject_id, action_name, resource_id, resource_type
        ),
        subject_id=subject_id,
        action_name=action_name,
        resource_id=resource_id,
        resource_type=resource_type,
        status=status,
        requirement=req,
        created_at=now,
        expires_at=now + ttl if ttl else None,
    )


class TestInMemoryApprovalStore:
    def test_create_and_get(self) -> None:
        store = InMemoryApprovalStore()
        r = _req()
        created = store.create(r)
        assert created.id == r.id
        assert store.get(r.id, "t1") == r

    def test_get_missing_returns_none(self) -> None:
        store = InMemoryApprovalStore()
        assert store.get("nope", "t1") is None

    def test_find_by_hash_returns_pending(self) -> None:
        store = InMemoryApprovalStore()
        r = _req()
        store.create(r)
        found = store.find_by_hash(r.request_hash, "t1")
        assert found is not None
        assert found.id == r.id

    def test_find_by_hash_ignores_resolved(self) -> None:
        store = InMemoryApprovalStore()
        r = _req(status=ApprovalStatus.APPROVED)
        store.create(r)
        assert store.find_by_hash(r.request_hash, "t1") is None

    def test_create_duplicate_pending_hash_raises(self) -> None:
        store = InMemoryApprovalStore()
        r1 = _req()
        r2 = _req()  # same idempotency key
        store.create(r1)
        with pytest.raises(ApprovalError):
            store.create(r2)

    def test_create_duplicate_after_resolved_succeeds(self) -> None:
        """Once the first request is APPROVED/REJECTED, a new PENDING is OK."""
        store = InMemoryApprovalStore()
        r1 = _req()
        store.create(r1)
        resolved = r1.model_copy(update={"status": ApprovalStatus.APPROVED})
        store.update(resolved)
        r2 = _req()
        # Not raising is the assertion
        store.create(r2)

    def test_update(self) -> None:
        store = InMemoryApprovalStore()
        r = _req()
        store.create(r)
        updated = r.model_copy(
            update={"status": ApprovalStatus.APPROVED, "reason": "ok"}
        )
        store.update(updated)
        got = store.get(r.id, "t1")
        assert got is not None
        assert got.status == ApprovalStatus.APPROVED
        assert got.reason == "ok"

    def test_update_missing_raises(self) -> None:
        store = InMemoryApprovalStore()
        r = _req()
        with pytest.raises(ApprovalError):
            store.update(r)  # never created

    def test_list_pending(self) -> None:
        store = InMemoryApprovalStore()
        store.create(_req(resource_id="a"))
        store.create(_req(resource_id="b"))
        approved = _req(resource_id="c", status=ApprovalStatus.APPROVED)
        store.create(approved)
        pending = store.list_pending("t1")
        assert len(pending) == 2

    def test_tenant_isolation(self) -> None:
        store = InMemoryApprovalStore()
        store.create(_req(tenant_id="t1"))
        # Same idempotency key but different tenant — separate bucket
        store.create(_req(tenant_id="t2"))
        assert len(store.list_pending("t1")) == 1
        assert len(store.list_pending("t2")) == 1

    def test_expire_stale(self) -> None:
        store = InMemoryApprovalStore()
        now = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
        store.create(_req(ttl=timedelta(minutes=5), now=now))
        # Advance past TTL
        later = now + timedelta(minutes=10)
        expired = store.expire_stale("t1", later)
        assert expired == 1
        assert store.list_pending("t1") == []

    def test_expire_stale_without_ttl_noop(self) -> None:
        store = InMemoryApprovalStore()
        store.create(_req())  # no TTL
        later = datetime(2026, 4, 18, tzinfo=UTC)
        assert store.expire_stale("t1", later) == 0
        assert len(store.list_pending("t1")) == 1
