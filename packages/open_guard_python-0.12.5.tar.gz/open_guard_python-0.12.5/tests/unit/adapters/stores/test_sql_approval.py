"""Tests for SQLAlchemyApprovalStore (Phase 3)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.sql_approval import SQLAlchemyApprovalStore
from open_guard.domain.entities import (
    ApprovalDecision,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
)
from open_guard.domain.exceptions import ApprovalError


@pytest.fixture
def store() -> SQLAlchemyApprovalStore:
    s = SQLAlchemyApprovalStore.from_url("sqlite:///:memory:")
    s.create_tables()
    return s


def _req(
    tenant_id: str = "t1",
    subject_id: str = "alice",
    action_name: str = "send",
    resource_id: str = "email-1",
    resource_type: str = "email",
    status: ApprovalStatus = ApprovalStatus.PENDING,
    ttl: timedelta | None = None,
    now: datetime | None = None,
) -> ApprovalRequest:
    now = now or datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
    req = ApprovalRequirement(
        approvers=["role:manager"], ttl=ttl, channel="slack"
    )
    return ApprovalRequest(
        tenant_id=tenant_id,
        request_hash=ApprovalRequest.make_hash(
            tenant_id, subject_id, action_name, resource_id, resource_type
        ),
        subject_id=subject_id,
        action_name=action_name,
        resource_id=resource_id,
        resource_type=resource_type,
        status=status,
        requirement=req,
        created_at=now,
        expires_at=now + ttl if ttl else None,
    )


class TestSQLAlchemyApprovalStore:
    def test_create_and_get(self, store: SQLAlchemyApprovalStore) -> None:
        r = _req()
        store.create(r)
        got = store.get(r.id, "t1")
        assert got is not None
        assert got.id == r.id
        assert got.status == ApprovalStatus.PENDING
        assert got.requirement.channel == "slack"

    def test_get_missing_returns_none(self, store: SQLAlchemyApprovalStore) -> None:
        assert store.get("nope", "t1") is None

    def test_find_by_hash_returns_pending(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        r = _req()
        store.create(r)
        found = store.find_by_hash(r.request_hash, "t1")
        assert found is not None
        assert found.id == r.id

    def test_find_by_hash_ignores_resolved(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        r = _req()
        store.create(r)
        resolved = r.model_copy(update={"status": ApprovalStatus.APPROVED})
        store.update(resolved)
        assert store.find_by_hash(r.request_hash, "t1") is None

    def test_create_duplicate_pending_hash_raises(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        store.create(_req())
        with pytest.raises(ApprovalError):
            store.create(_req())

    def test_update_records_approver(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        r = _req()
        store.create(r)
        now = datetime(2026, 4, 17, 13, tzinfo=UTC)
        d = ApprovalDecision(approver="bob", decision="approve", at=now)
        updated = r.model_copy(
            update={
                "status": ApprovalStatus.APPROVED,
                "approvers_received": [d],
                "resolved_at": now,
            }
        )
        store.update(updated)
        got = store.get(r.id, "t1")
        assert got is not None
        assert got.status == ApprovalStatus.APPROVED
        assert len(got.approvers_received) == 1
        assert got.approvers_received[0].approver == "bob"

    def test_update_missing_raises(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        r = _req()
        with pytest.raises(ApprovalError):
            store.update(r)  # never created

    def test_list_pending(self, store: SQLAlchemyApprovalStore) -> None:
        store.create(_req(resource_id="a"))
        store.create(_req(resource_id="b"))
        approved = _req(resource_id="c", status=ApprovalStatus.APPROVED)
        store.create(approved)
        pending = store.list_pending("t1")
        assert len(pending) == 2

    def test_tenant_isolation(self, store: SQLAlchemyApprovalStore) -> None:
        store.create(_req(tenant_id="t1"))
        store.create(_req(tenant_id="t2"))
        assert len(store.list_pending("t1")) == 1
        assert len(store.list_pending("t2")) == 1

    def test_expire_stale(self, store: SQLAlchemyApprovalStore) -> None:
        now = datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC)
        store.create(_req(ttl=timedelta(minutes=5), now=now))
        later = now + timedelta(minutes=10)
        assert store.expire_stale("t1", later) == 1
        assert store.list_pending("t1") == []

    def test_expire_stale_without_ttl_noop(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        store.create(_req())
        later = datetime(2026, 4, 18, tzinfo=UTC)
        assert store.expire_stale("t1", later) == 0

    def test_requirement_json_roundtrip(
        self, store: SQLAlchemyApprovalStore
    ) -> None:
        """ApprovalRequirement fields (including ttl, channel) survive."""
        r = _req(ttl=timedelta(hours=2))
        store.create(r)
        got = store.get(r.id, "t1")
        assert got is not None
        assert got.requirement.ttl == timedelta(hours=2)
        assert got.requirement.channel == "slack"
