"""Tests for SQLAlchemyRelationshipStore."""

import pytest

from open_guard.adapters.stores.sql_relationship import SQLAlchemyRelationshipStore
from open_guard.domain.entities import RelationTuple
from open_guard.domain.exceptions import RelationshipError


@pytest.fixture
def store() -> SQLAlchemyRelationshipStore:
    s = SQLAlchemyRelationshipStore.from_url("sqlite://")
    s.create_tables()
    return s


def _tuple(
    tenant_id: str = "t1",
    object_type: str = "document",
    object_id: str = "readme",
    relation: str = "viewer",
    subject_type: str = "user",
    subject_id: str = "alice",
    subject_relation: str | None = None,
) -> RelationTuple:
    return RelationTuple(
        tenant_id=tenant_id,
        object_type=object_type,
        object_id=object_id,
        relation=relation,
        subject_type=subject_type,
        subject_id=subject_id,
        subject_relation=subject_relation,
    )


class TestSQLAlchemyRelationshipStore:
    def test_write_and_read(self, store: SQLAlchemyRelationshipStore) -> None:
        t = _tuple()
        store.write_tuple(t)
        results = store.read_tuples("t1")
        assert len(results) == 1
        assert results[0].subject_id == "alice"

    def test_delete_tuple(self, store: SQLAlchemyRelationshipStore) -> None:
        t = _tuple()
        store.write_tuple(t)
        store.delete_tuple(t.id, "t1")
        assert store.read_tuples("t1") == []

    def test_delete_nonexistent_raises(
        self, store: SQLAlchemyRelationshipStore
    ) -> None:
        with pytest.raises(RelationshipError):
            store.delete_tuple("nonexistent", "t1")

    def test_duplicate_prevention(self, store: SQLAlchemyRelationshipStore) -> None:
        store.write_tuple(_tuple(subject_id="alice"))
        with pytest.raises(RelationshipError, match="Duplicate"):
            store.write_tuple(_tuple(subject_id="alice"))

    def test_read_by_object(self, store: SQLAlchemyRelationshipStore) -> None:
        store.write_tuple(_tuple(object_id="readme", subject_id="alice"))
        store.write_tuple(_tuple(object_id="readme", subject_id="bob"))
        store.write_tuple(_tuple(object_id="other", subject_id="charlie"))

        results = store.read_tuples("t1", object_type="document", object_id="readme")
        assert len(results) == 2

    def test_read_by_relation(self, store: SQLAlchemyRelationshipStore) -> None:
        store.write_tuple(_tuple(relation="viewer", subject_id="alice"))
        store.write_tuple(_tuple(relation="editor", subject_id="bob"))

        results = store.read_tuples("t1", relation="viewer")
        assert len(results) == 1

    def test_tenant_isolation(self, store: SQLAlchemyRelationshipStore) -> None:
        store.write_tuple(_tuple(tenant_id="t1", subject_id="alice"))
        store.write_tuple(_tuple(tenant_id="t2", subject_id="bob"))

        assert len(store.read_tuples("t1")) == 1
        assert len(store.read_tuples("t2")) == 1

    def test_tuple_exists(self, store: SQLAlchemyRelationshipStore) -> None:
        store.write_tuple(_tuple(subject_id="alice"))

        assert store.tuple_exists(
            "t1", "document", "readme", "viewer", "user", "alice"
        )
        assert not store.tuple_exists(
            "t1", "document", "readme", "viewer", "user", "bob"
        )

    def test_tuple_exists_with_subject_relation(
        self, store: SQLAlchemyRelationshipStore
    ) -> None:
        store.write_tuple(_tuple(
            subject_type="group", subject_id="devs", subject_relation="member",
        ))

        assert store.tuple_exists(
            "t1", "document", "readme", "viewer", "group", "devs", "member"
        )
        assert not store.tuple_exists(
            "t1", "document", "readme", "viewer", "group", "devs", None
        )


class TestSQLFindObjectIdsForSubject:
    """Phase 4 (FEAT-006) — native ReBAC candidate enumeration in SQL."""

    def test_returns_distinct_object_ids(
        self, store: SQLAlchemyRelationshipStore
    ) -> None:
        store.write_tuple(_tuple(object_id="1", relation="owner"))
        store.write_tuple(_tuple(object_id="1", relation="viewer"))
        store.write_tuple(_tuple(object_id="2", relation="viewer"))

        ids = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1"
        )
        assert ids == ["1", "2"]

    def test_pagination(self, store: SQLAlchemyRelationshipStore) -> None:
        for i in range(5):
            store.write_tuple(_tuple(object_id=str(i), relation=f"r{i}"))

        first = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1", offset=0, limit=2
        )
        assert first == ["0", "1"]

        last = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1", offset=4, limit=2
        )
        assert last == ["4"]

    def test_cross_tenant_isolation(
        self, store: SQLAlchemyRelationshipStore
    ) -> None:
        store.write_tuple(_tuple(tenant_id="t1", object_id="1"))
        store.write_tuple(_tuple(tenant_id="t2", object_id="2"))
        assert store.find_object_ids_for_subject(
            "alice", "user", "document", "t1"
        ) == ["1"]
        assert store.find_object_ids_for_subject(
            "alice", "user", "document", "t2"
        ) == ["2"]

    def test_empty_when_no_tuples(
        self, store: SQLAlchemyRelationshipStore
    ) -> None:
        assert (
            store.find_object_ids_for_subject("ghost", "user", "doc", "t1") == []
        )

    def test_subject_type_filter(
        self, store: SQLAlchemyRelationshipStore
    ) -> None:
        store.write_tuple(_tuple(subject_type="user", subject_id="alice"))
        store.write_tuple(
            _tuple(
                subject_type="agent",
                subject_id="alice",
                object_id="99",
                relation="owner",
            )
        )
        ids = store.find_object_ids_for_subject(
            "alice", "user", "document", "t1"
        )
        assert ids == ["readme"]
