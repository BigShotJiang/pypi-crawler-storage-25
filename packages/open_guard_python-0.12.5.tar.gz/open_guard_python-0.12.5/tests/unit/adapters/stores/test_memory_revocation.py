# tests/unit/adapters/stores/test_memory_revocation.py
"""Tests for InMemoryRevocationStream (Phase 6 — ENH-010)."""

from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.domain.entities import RevocationEvent, RevocationEventType


class TestInMemoryRevocationStream:
    def setup_method(self) -> None:
        self.stream = InMemoryRevocationStream()
        self.received: list[RevocationEvent] = []

    def _callback(self, event: RevocationEvent) -> None:
        self.received.append(event)

    def test_publish_to_subscriber(self) -> None:
        self.stream.subscribe("t1", self._callback)
        event = RevocationEvent(
            event_type=RevocationEventType.DELEGATION_REVOKED,
            tenant_id="t1",
            delegation_id="d1",
            reason="manual revoke",
        )
        self.stream.publish(event)
        assert len(self.received) == 1
        assert self.received[0].delegation_id == "d1"

    def test_tenant_isolation(self) -> None:
        self.stream.subscribe("t1", self._callback)
        event = RevocationEvent(
            event_type=RevocationEventType.DELEGATION_REVOKED,
            tenant_id="t2",  # different tenant
            delegation_id="d1",
        )
        self.stream.publish(event)
        assert len(self.received) == 0

    def test_subject_filter(self) -> None:
        self.stream.subscribe("t1", self._callback, subject_id="alice")
        # Event for alice
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.SESSION_DEACTIVATED,
            tenant_id="t1", subject_id="alice", session_id="s1",
        ))
        # Event for bob
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.SESSION_DEACTIVATED,
            tenant_id="t1", subject_id="bob", session_id="s2",
        ))
        assert len(self.received) == 1
        assert self.received[0].subject_id == "alice"

    def test_unsubscribe(self) -> None:
        sub_id = self.stream.subscribe("t1", self._callback)
        self.stream.unsubscribe(sub_id)
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.DELEGATION_REVOKED,
            tenant_id="t1", delegation_id="d1",
        ))
        assert len(self.received) == 0

    def test_multiple_subscribers(self) -> None:
        other_received: list[RevocationEvent] = []
        self.stream.subscribe("t1", self._callback)
        self.stream.subscribe("t1", lambda e: other_received.append(e))
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.POLICY_REMOVED,
            tenant_id="t1", policy_id="p1",
        ))
        assert len(self.received) == 1
        assert len(other_received) == 1

    def test_subject_filter_none_receives_all(self) -> None:
        """Subscribe without subject_id filter receives all tenant events."""
        self.stream.subscribe("t1", self._callback)
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.DELEGATION_EXPIRED,
            tenant_id="t1", subject_id="alice",
        ))
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.DELEGATION_EXPIRED,
            tenant_id="t1", subject_id="bob",
        ))
        assert len(self.received) == 2

    def test_event_with_no_subject_delivered_to_all(self) -> None:
        """Events without subject_id are delivered to all subscribers."""
        self.stream.subscribe("t1", self._callback, subject_id="alice")
        self.stream.publish(RevocationEvent(
            event_type=RevocationEventType.POLICY_REMOVED,
            tenant_id="t1", policy_id="p1",
            # no subject_id — affects everyone
        ))
        assert len(self.received) == 1
