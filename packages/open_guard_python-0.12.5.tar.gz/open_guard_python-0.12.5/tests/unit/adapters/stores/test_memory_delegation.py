"""Tests for InMemoryDelegationStore — CAS-safe counters and thread safety."""

from __future__ import annotations

import concurrent.futures
import threading
from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
)
from open_guard.domain.exceptions import DelegationNotFoundError, UsageExhaustedError

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _scope(action: str = "read", resource_type: str = "document") -> DelegationScope:
    return DelegationScope(action_match=action, resource_type=resource_type)


def _make_delegation(**overrides: object) -> Delegation:
    base: dict = {
        "tenant_id": TENANT,
        "from_subject_id": "alice",
        "from_subject_type": ActorType.USER,
        "to_subject_id": "bob",
        "to_subject_type": ActorType.AGENT,
        "scopes": [_scope()],
        "request_hash": "hash-001",
        "created_at": NOW,
        "created_by": "alice",
        "status": DelegationStatus.ACTIVE,
    }
    base.update(overrides)
    return Delegation(**base)  # type: ignore[arg-type]


class TestCreateAndGet:
    def test_create_and_get_roundtrip(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation()
        created = store.create(d)
        assert created.id == d.id
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.id == d.id

    def test_get_unknown_returns_none(self) -> None:
        store = InMemoryDelegationStore()
        assert store.get("no-such-id", TENANT) is None

    def test_get_wrong_tenant_returns_none(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation()
        store.create(d)
        assert store.get(d.id, "other-tenant") is None

    def test_find_by_hash(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(request_hash="unique-hash")
        store.create(d)
        found = store.find_by_hash("unique-hash", TENANT)
        assert found is not None
        assert found.id == d.id

    def test_find_by_hash_unknown_returns_none(self) -> None:
        store = InMemoryDelegationStore()
        assert store.find_by_hash("no-such-hash", TENANT) is None


class TestListActiveForGrantee:
    def test_returns_active_delegations_for_subject(self) -> None:
        store = InMemoryDelegationStore()
        d1 = _make_delegation(request_hash="h1")
        d2 = _make_delegation(to_subject_id="carol", request_hash="h2")
        store.create(d1)
        store.create(d2)
        results = store.list_active_for_grantee("bob", TENANT)
        assert len(results) == 1
        assert results[0].id == d1.id

    def test_filters_revoked_delegations(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(status=DelegationStatus.REVOKED, request_hash="h1")
        store.create(d)
        assert store.list_active_for_grantee("bob", TENANT) == []

    def test_filters_by_resource_type(self) -> None:
        store = InMemoryDelegationStore()
        doc_scope = _scope("read", "document")
        tool_scope = _scope("invoke", "tool")
        d_doc = _make_delegation(scopes=[doc_scope], request_hash="h-doc")
        d_tool = _make_delegation(scopes=[tool_scope], request_hash="h-tool")
        store.create(d_doc)
        store.create(d_tool)
        results = store.list_active_for_grantee("bob", TENANT, resource_type="document")
        assert len(results) == 1
        assert results[0].id == d_doc.id

    def test_no_filter_returns_all_active(self) -> None:
        store = InMemoryDelegationStore()
        doc_scope = _scope("read", "document")
        tool_scope = _scope("invoke", "tool")
        d1 = _make_delegation(scopes=[doc_scope], request_hash="h1")
        d2 = _make_delegation(scopes=[tool_scope], request_hash="h2")
        store.create(d1)
        store.create(d2)
        results = store.list_active_for_grantee("bob", TENANT)
        assert len(results) == 2


class TestListDescendants:
    def test_direct_children(self) -> None:
        store = InMemoryDelegationStore()
        parent = _make_delegation(request_hash="h-parent")
        store.create(parent)
        child1 = _make_delegation(
            parent_delegation_id=parent.id, request_hash="h-child1"
        )
        child2 = _make_delegation(
            parent_delegation_id=parent.id, request_hash="h-child2"
        )
        store.create(child1)
        store.create(child2)
        descendants = store.list_descendants(parent.id, TENANT)
        ids = {d.id for d in descendants}
        assert child1.id in ids
        assert child2.id in ids

    def test_transitive_descendants(self) -> None:
        store = InMemoryDelegationStore()
        root = _make_delegation(request_hash="h-root")
        store.create(root)
        child = _make_delegation(parent_delegation_id=root.id, request_hash="h-child")
        store.create(child)
        grandchild = _make_delegation(
            parent_delegation_id=child.id, request_hash="h-gc"
        )
        store.create(grandchild)
        descendants = store.list_descendants(root.id, TENANT)
        ids = {d.id for d in descendants}
        assert child.id in ids
        assert grandchild.id in ids

    def test_no_descendants(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation()
        store.create(d)
        assert store.list_descendants(d.id, TENANT) == []


class TestUpdateStatus:
    def test_update_to_revoked(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation()
        store.create(d)
        updated = store.update_status(d.id, TENANT, DelegationStatus.REVOKED)
        assert updated.status == DelegationStatus.REVOKED
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.REVOKED

    def test_update_unknown_raises(self) -> None:
        store = InMemoryDelegationStore()
        with pytest.raises(DelegationNotFoundError):
            store.update_status("no-such", TENANT, DelegationStatus.REVOKED)


class TestDecrementUses:
    def test_basic_decrement(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(max_uses=5, uses_remaining=5)
        store.create(d)
        updated = store.decrement_uses(d.id, TENANT, 1)
        assert updated.uses_remaining == 4
        assert updated.status == DelegationStatus.ACTIVE

    def test_last_decrement_transitions_to_exhausted(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(max_uses=1, uses_remaining=1)
        store.create(d)
        updated = store.decrement_uses(d.id, TENANT, 1)
        assert updated.uses_remaining == 0
        assert updated.status == DelegationStatus.EXHAUSTED

    def test_decrement_beyond_zero_raises(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(max_uses=2, uses_remaining=1)
        store.create(d)
        with pytest.raises(UsageExhaustedError):
            store.decrement_uses(d.id, TENANT, 2)

    def test_concurrent_race_exactly_n_succeed(self) -> None:
        """10 threads on max_uses=3 → exactly 3 succeed, 7 raise UsageExhaustedError."""
        store = InMemoryDelegationStore()
        d = _make_delegation(max_uses=3, uses_remaining=3)
        store.create(d)

        success_count = 0
        exhausted_count = 0
        lock = threading.Lock()

        def try_consume() -> None:
            nonlocal success_count, exhausted_count
            try:
                store.decrement_uses(d.id, TENANT, 1)
                with lock:
                    success_count += 1
            except UsageExhaustedError:
                with lock:
                    exhausted_count += 1

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(try_consume) for _ in range(10)]
            concurrent.futures.wait(futures)

        assert success_count == 3
        assert exhausted_count == 7
        final = store.get(d.id, TENANT)
        assert final is not None
        assert final.uses_remaining == 0
        assert final.status == DelegationStatus.EXHAUSTED

    def test_no_counter_set_noop(self) -> None:
        """Delegation with max_uses=None — decrement_uses is a no-op."""
        store = InMemoryDelegationStore()
        d = _make_delegation()  # no max_uses
        store.create(d)
        updated = store.decrement_uses(d.id, TENANT, 1)
        assert updated.uses_remaining is None

    def test_unknown_delegation_raises(self) -> None:
        store = InMemoryDelegationStore()
        with pytest.raises(DelegationNotFoundError):
            store.decrement_uses("no-such", TENANT, 1)


class TestDecrementBudget:
    def test_basic_decrement(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(budget=Decimal("10.00"), budget_remaining=Decimal("10.00"))
        store.create(d)
        updated = store.decrement_budget(d.id, TENANT, Decimal("3.50"))
        assert updated.budget_remaining == Decimal("6.50")
        assert updated.status == DelegationStatus.ACTIVE

    def test_last_decrement_transitions_to_exhausted(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(budget=Decimal("5.00"), budget_remaining=Decimal("5.00"))
        store.create(d)
        updated = store.decrement_budget(d.id, TENANT, Decimal("5.00"))
        assert updated.budget_remaining == Decimal("0.00")
        assert updated.status == DelegationStatus.EXHAUSTED

    def test_decrement_beyond_zero_raises(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(budget=Decimal("1.00"), budget_remaining=Decimal("1.00"))
        store.create(d)
        with pytest.raises(UsageExhaustedError):
            store.decrement_budget(d.id, TENANT, Decimal("2.00"))

    def test_concurrent_race_exact_3_succeed(self) -> None:
        """10 threads on budget=3 x Decimal("1") -> exactly 3 succeed."""
        store = InMemoryDelegationStore()
        d = _make_delegation(
            budget=Decimal("3.00"), budget_remaining=Decimal("3.00")
        )
        store.create(d)

        success_count = 0
        exhausted_count = 0
        lock = threading.Lock()

        def try_consume() -> None:
            nonlocal success_count, exhausted_count
            try:
                store.decrement_budget(d.id, TENANT, Decimal("1.00"))
                with lock:
                    success_count += 1
            except UsageExhaustedError:
                with lock:
                    exhausted_count += 1

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(try_consume) for _ in range(10)]
            concurrent.futures.wait(futures)

        assert success_count == 3
        assert exhausted_count == 7


class TestTouchHeartbeat:
    def test_updates_last_heartbeat_at(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation()
        store.create(d)
        new_now = NOW + timedelta(seconds=15)
        updated = store.touch_heartbeat(d.id, TENANT, new_now)
        assert updated.last_heartbeat_at == new_now
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.last_heartbeat_at == new_now

    def test_unknown_raises(self) -> None:
        store = InMemoryDelegationStore()
        with pytest.raises(DelegationNotFoundError):
            store.touch_heartbeat("no-such", TENANT, NOW)


class TestExpireStale:
    def test_transitions_lease_expired_to_expired(self) -> None:
        store = InMemoryDelegationStore()
        ttl = timedelta(seconds=30)
        heartbeat = NOW - timedelta(seconds=60)  # heartbeat was 60s ago
        d = _make_delegation(lease_ttl=ttl, last_heartbeat_at=heartbeat)
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 1
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.EXPIRED

    def test_transitions_absolute_expired_to_expired(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(expires_at=NOW - timedelta(seconds=1))
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 1
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.EXPIRED

    def test_not_yet_expired_stays_active(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(expires_at=NOW + timedelta(seconds=100))
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 0
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.ACTIVE

    def test_already_revoked_not_counted(self) -> None:
        store = InMemoryDelegationStore()
        d = _make_delegation(
            status=DelegationStatus.REVOKED,
            expires_at=NOW - timedelta(seconds=1),
        )
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 0
