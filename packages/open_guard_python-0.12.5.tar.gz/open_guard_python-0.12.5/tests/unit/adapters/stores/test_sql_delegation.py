"""Tests for SQLAlchemyDelegationStore — CAS-safe counters and SQL roundtrip."""

from __future__ import annotations

import concurrent.futures
import threading
from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest
from sqlalchemy import create_engine, event
from sqlalchemy.pool import StaticPool

from open_guard.adapters.stores.sql_delegation import SQLAlchemyDelegationStore
from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
)
from open_guard.domain.exceptions import DelegationNotFoundError, UsageExhaustedError

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


@pytest.fixture
def store() -> SQLAlchemyDelegationStore:
    s = SQLAlchemyDelegationStore.from_url(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    s.create_tables()
    return s


@pytest.fixture
def wal_store(tmp_path: pytest.TempPathFactory) -> SQLAlchemyDelegationStore:
    """File-based SQLite with WAL mode — supports concurrent multi-thread access."""
    db_path = str(tmp_path / "test_delegation.db")
    engine = create_engine(
        f"sqlite:///{db_path}",
        connect_args={"check_same_thread": False},
    )

    @event.listens_for(engine, "connect")
    def set_wal_mode(conn: object, _: object) -> None:
        import sqlite3
        assert isinstance(conn, sqlite3.Connection)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")

    s = SQLAlchemyDelegationStore(engine)
    s.create_tables()
    return s


def _scope(action: str = "read", resource_type: str = "document") -> DelegationScope:
    return DelegationScope(
        action_match=action,
        resource_type=resource_type,
        resource_match={"id": {"op": "eq", "value": "doc-1"}},
    )


def _make_delegation(**overrides: object) -> Delegation:
    base: dict = {
        "tenant_id": TENANT,
        "from_subject_id": "alice",
        "from_subject_type": ActorType.USER,
        "to_subject_id": "bob",
        "to_subject_type": ActorType.AGENT,
        "scopes": [_scope()],
        "request_hash": "hash-001",
        "created_at": NOW,
        "created_by": "alice",
        "status": DelegationStatus.ACTIVE,
    }
    base.update(overrides)
    return Delegation(**base)  # type: ignore[arg-type]


class TestSQLAlchemyDelegationStore:
    def test_create_and_get_roundtrip(self, store: SQLAlchemyDelegationStore) -> None:
        d = _make_delegation()
        store.create(d)
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.id == d.id
        assert fetched.tenant_id == TENANT
        assert fetched.from_subject_id == "alice"
        assert fetched.to_subject_id == "bob"
        assert fetched.status == DelegationStatus.ACTIVE
        assert len(fetched.scopes) == 1
        assert fetched.scopes[0].action_match == "read"
        assert fetched.scopes[0].resource_match["id"]["op"] == "eq"

    def test_get_missing_returns_none(self, store: SQLAlchemyDelegationStore) -> None:
        assert store.get("no-such", TENANT) is None

    def test_get_wrong_tenant_returns_none(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation()
        store.create(d)
        assert store.get(d.id, "other-tenant") is None

    def test_find_by_hash(self, store: SQLAlchemyDelegationStore) -> None:
        d = _make_delegation(request_hash="unique-hash")
        store.create(d)
        found = store.find_by_hash("unique-hash", TENANT)
        assert found is not None
        assert found.id == d.id

    def test_find_by_hash_missing_returns_none(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        assert store.find_by_hash("no-such-hash", TENANT) is None

    def test_metadata_exported_for_alembic(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        from open_guard.adapters.stores.sql_models import metadata

        assert "open_guard_delegations" in metadata.tables

    def test_create_tables_idempotent(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        store.create_tables()  # calling twice is safe
        d = _make_delegation()
        store.create(d)
        assert store.get(d.id, TENANT) is not None


class TestSQLListAndStatus:
    def test_list_active_for_grantee(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d1 = _make_delegation(request_hash="h1")
        d2 = _make_delegation(to_subject_id="carol", request_hash="h2")
        store.create(d1)
        store.create(d2)
        results = store.list_active_for_grantee("bob", TENANT)
        assert len(results) == 1
        assert results[0].id == d1.id

    def test_list_active_filters_revoked(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(status=DelegationStatus.REVOKED)
        store.create(d)
        assert store.list_active_for_grantee("bob", TENANT) == []

    def test_list_active_filters_by_resource_type(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        doc_scope = _scope("read", "document")
        tool_scope = _scope("invoke", "tool")
        d_doc = _make_delegation(scopes=[doc_scope], request_hash="h-doc")
        d_tool = _make_delegation(scopes=[tool_scope], request_hash="h-tool")
        store.create(d_doc)
        store.create(d_tool)
        results = store.list_active_for_grantee("bob", TENANT, resource_type="document")
        assert len(results) == 1
        assert results[0].id == d_doc.id

    def test_list_descendants_direct(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        parent = _make_delegation(request_hash="h-parent")
        store.create(parent)
        child = _make_delegation(
            parent_delegation_id=parent.id, request_hash="h-child"
        )
        store.create(child)
        descendants = store.list_descendants(parent.id, TENANT)
        assert len(descendants) == 1
        assert descendants[0].id == child.id

    def test_update_status(self, store: SQLAlchemyDelegationStore) -> None:
        d = _make_delegation()
        store.create(d)
        updated = store.update_status(d.id, TENANT, DelegationStatus.REVOKED)
        assert updated.status == DelegationStatus.REVOKED
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.REVOKED

    def test_update_status_unknown_raises(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        with pytest.raises(DelegationNotFoundError):
            store.update_status("no-such", TENANT, DelegationStatus.REVOKED)


class TestSQLDecrementUses:
    def test_basic_decrement(self, store: SQLAlchemyDelegationStore) -> None:
        d = _make_delegation(max_uses=5, uses_remaining=5)
        store.create(d)
        updated = store.decrement_uses(d.id, TENANT, 1)
        assert updated.uses_remaining == 4
        assert updated.status == DelegationStatus.ACTIVE

    def test_last_use_transitions_to_exhausted(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(max_uses=1, uses_remaining=1)
        store.create(d)
        updated = store.decrement_uses(d.id, TENANT, 1)
        assert updated.uses_remaining == 0
        assert updated.status == DelegationStatus.EXHAUSTED

    def test_decrement_beyond_zero_raises(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(max_uses=2, uses_remaining=1)
        store.create(d)
        with pytest.raises(UsageExhaustedError):
            store.decrement_uses(d.id, TENANT, 2)

    def test_concurrent_race_exactly_3_succeed(
        self, wal_store: SQLAlchemyDelegationStore
    ) -> None:
        """WAL-mode SQLite: 10 threads on max_uses=3 → exactly 3 succeed."""
        d = _make_delegation(max_uses=3, uses_remaining=3)
        wal_store.create(d)

        success_count = 0
        exhausted_count = 0
        lock = threading.Lock()

        def try_consume() -> None:
            nonlocal success_count, exhausted_count
            try:
                wal_store.decrement_uses(d.id, TENANT, 1)
                with lock:
                    success_count += 1
            except UsageExhaustedError:
                with lock:
                    exhausted_count += 1

        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = [executor.submit(try_consume) for _ in range(10)]
            concurrent.futures.wait(futures)

        assert success_count == 3
        assert exhausted_count == 7
        final = wal_store.get(d.id, TENANT)
        assert final is not None
        assert final.uses_remaining == 0
        assert final.status == DelegationStatus.EXHAUSTED

    def test_unknown_delegation_raises(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        with pytest.raises(DelegationNotFoundError):
            store.decrement_uses("no-such", TENANT, 1)


class TestSQLDecrementBudget:
    def test_basic_decrement(self, store: SQLAlchemyDelegationStore) -> None:
        d = _make_delegation(budget=Decimal("10.00"), budget_remaining=Decimal("10.00"))
        store.create(d)
        updated = store.decrement_budget(d.id, TENANT, Decimal("3.50"))
        assert updated.budget_remaining == Decimal("6.50")

    def test_last_decrement_transitions_to_exhausted(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(budget=Decimal("5.00"), budget_remaining=Decimal("5.00"))
        store.create(d)
        updated = store.decrement_budget(d.id, TENANT, Decimal("5.00"))
        assert updated.status == DelegationStatus.EXHAUSTED

    def test_decrement_beyond_zero_raises(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(budget=Decimal("1.00"), budget_remaining=Decimal("1.00"))
        store.create(d)
        with pytest.raises(UsageExhaustedError):
            store.decrement_budget(d.id, TENANT, Decimal("2.00"))


class TestSQLHeartbeatAndExpiry:
    def test_touch_heartbeat(self, store: SQLAlchemyDelegationStore) -> None:
        d = _make_delegation()
        store.create(d)
        new_now = NOW + timedelta(seconds=15)
        updated = store.touch_heartbeat(d.id, TENANT, new_now)
        assert updated.last_heartbeat_at == new_now
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.last_heartbeat_at == new_now

    def test_touch_heartbeat_unknown_raises(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        with pytest.raises(DelegationNotFoundError):
            store.touch_heartbeat("no-such", TENANT, NOW)

    def test_expire_stale_absolute_expiry(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(expires_at=NOW - timedelta(seconds=1))
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 1
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.EXPIRED

    def test_expire_stale_lease_expired(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        ttl = timedelta(seconds=30)
        heartbeat = NOW - timedelta(seconds=60)
        d = _make_delegation(lease_ttl=ttl, last_heartbeat_at=heartbeat)
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 1

    def test_not_yet_expired_stays_active(
        self, store: SQLAlchemyDelegationStore
    ) -> None:
        d = _make_delegation(expires_at=NOW + timedelta(seconds=100))
        store.create(d)
        count = store.expire_stale(TENANT, NOW)
        assert count == 0
