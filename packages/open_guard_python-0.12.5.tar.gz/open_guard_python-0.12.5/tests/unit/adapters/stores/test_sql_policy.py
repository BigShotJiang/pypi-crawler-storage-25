"""Tests for SQLAlchemyPolicyStore."""

import pytest

from open_guard.adapters.stores.sql import SQLAlchemyPolicyStore
from open_guard.domain.entities import Policy, PolicyEffect
from open_guard.domain.exceptions import PolicyError


@pytest.fixture
def store() -> SQLAlchemyPolicyStore:
    s = SQLAlchemyPolicyStore.from_url("sqlite://")
    s.create_tables()
    return s


class TestSQLAlchemyPolicyStore:
    def test_add_and_get_by_tenant(self, store: SQLAlchemyPolicyStore) -> None:
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            conditions={"subject.dept": {"op": "eq", "value": "eng"}},
        ))
        results = store.get_by_tenant("t1")
        assert len(results) == 1
        assert results[0].id == "p1"
        assert results[0].conditions == {"subject.dept": {"op": "eq", "value": "eng"}}

    def test_get_by_tenant_and_type(self, store: SQLAlchemyPolicyStore) -> None:
        store.add(Policy(id="p1", tenant_id="t1", evaluator_type="abac"))
        store.add(Policy(id="p2", tenant_id="t1", evaluator_type="rbac"))

        abac = store.get_by_tenant_and_type("t1", "abac")
        assert len(abac) == 1
        assert abac[0].id == "p1"

    def test_remove(self, store: SQLAlchemyPolicyStore) -> None:
        store.add(Policy(id="p1", tenant_id="t1", evaluator_type="abac"))
        store.remove("p1", "t1")
        assert store.get_by_tenant("t1") == []

    def test_remove_nonexistent_raises(self, store: SQLAlchemyPolicyStore) -> None:
        with pytest.raises(PolicyError):
            store.remove("nonexistent", "t1")

    def test_tenant_isolation(self, store: SQLAlchemyPolicyStore) -> None:
        store.add(Policy(id="p1", tenant_id="t1", evaluator_type="abac"))
        store.add(Policy(id="p2", tenant_id="t2", evaluator_type="abac"))

        assert len(store.get_by_tenant("t1")) == 1
        assert len(store.get_by_tenant("t2")) == 1

    def test_preserves_effect_and_priority(self, store: SQLAlchemyPolicyStore) -> None:
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            effect=PolicyEffect.DENY, priority=10,
        ))
        result = store.get_by_tenant("t1")[0]
        assert result.effect == PolicyEffect.DENY
        assert result.priority == 10

    def test_preserves_action_match_list(self, store: SQLAlchemyPolicyStore) -> None:
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match=["read", "write"],
        ))
        result = store.get_by_tenant("t1")[0]
        assert result.action_match == ["read", "write"]

    def test_from_url(self) -> None:
        store = SQLAlchemyPolicyStore.from_url("sqlite://")
        store.create_tables()
        store.add(Policy(id="p1", tenant_id="t1", evaluator_type="abac"))
        assert len(store.get_by_tenant("t1")) == 1

    def test_create_tables_idempotent(self) -> None:
        store = SQLAlchemyPolicyStore.from_url("sqlite://")
        store.create_tables()
        store.create_tables()  # Should not raise
