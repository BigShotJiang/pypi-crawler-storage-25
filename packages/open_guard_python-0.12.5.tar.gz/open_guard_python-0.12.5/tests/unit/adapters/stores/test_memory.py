"""Tests for InMemoryPolicyStore."""

import pytest

from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.domain.entities import Policy
from open_guard.domain.exceptions import PolicyError


class TestInMemoryPolicyStore:
    def test_add_and_retrieve(self) -> None:
        store = InMemoryPolicyStore()
        policy = Policy(tenant_id="t1", evaluator_type="rbac")
        stored = store.add(policy)
        assert stored.id == policy.id
        result = store.get_by_tenant("t1")
        assert len(result) == 1
        assert result[0].evaluator_type == "rbac"

    def test_tenant_isolation(self) -> None:
        store = InMemoryPolicyStore()
        store.add(Policy(tenant_id="t1", evaluator_type="rbac"))
        store.add(Policy(tenant_id="t2", evaluator_type="abac"))
        assert len(store.get_by_tenant("t1")) == 1
        assert len(store.get_by_tenant("t2")) == 1
        assert store.get_by_tenant("t1")[0].evaluator_type == "rbac"
        assert store.get_by_tenant("t2")[0].evaluator_type == "abac"

    def test_get_by_type(self) -> None:
        store = InMemoryPolicyStore()
        store.add(Policy(tenant_id="t1", evaluator_type="rbac"))
        store.add(Policy(tenant_id="t1", evaluator_type="abac"))
        store.add(Policy(tenant_id="t1", evaluator_type="rbac"))
        rbac = store.get_by_tenant_and_type("t1", "rbac")
        abac = store.get_by_tenant_and_type("t1", "abac")
        assert len(rbac) == 2
        assert len(abac) == 1

    def test_remove_policy(self) -> None:
        store = InMemoryPolicyStore()
        policy = Policy(id="p1", tenant_id="t1", evaluator_type="rbac")
        store.add(policy)
        assert len(store.get_by_tenant("t1")) == 1
        store.remove("p1", "t1")
        assert len(store.get_by_tenant("t1")) == 0

    def test_remove_nonexistent_raises(self) -> None:
        store = InMemoryPolicyStore()
        with pytest.raises(PolicyError, match="not found"):
            store.remove("nonexistent", "t1")

    def test_empty_store(self) -> None:
        store = InMemoryPolicyStore()
        assert store.get_by_tenant("t1") == []
        assert store.get_by_tenant_and_type("t1", "rbac") == []

    def test_multiple_policies_same_tenant(self) -> None:
        store = InMemoryPolicyStore()
        for i in range(5):
            store.add(
                Policy(
                    id=f"p{i}",
                    tenant_id="t1",
                    evaluator_type="rbac",
                    priority=i,
                )
            )
        result = store.get_by_tenant("t1")
        assert len(result) == 5

    def test_cross_tenant_removal(self) -> None:
        """Removing from wrong tenant should fail."""
        store = InMemoryPolicyStore()
        store.add(Policy(id="p1", tenant_id="t1", evaluator_type="rbac"))
        with pytest.raises(PolicyError):
            store.remove("p1", "t2")
        # Original still exists
        assert len(store.get_by_tenant("t1")) == 1
