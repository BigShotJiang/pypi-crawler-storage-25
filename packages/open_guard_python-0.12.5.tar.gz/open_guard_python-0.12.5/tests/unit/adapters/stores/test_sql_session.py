"""Tests for SQLAlchemySessionStore (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import create_engine

from open_guard.adapters.stores.sql_session import SQLAlchemySessionStore
from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError


@pytest.fixture
def store():
    engine = create_engine("sqlite:///:memory:")
    s = SQLAlchemySessionStore(engine)
    s.create_tables()
    return s


class TestSQLAlchemySessionStore:
    def test_create_and_get(self, store) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        created = store.create(session)
        got = store.get(created.id, "t1")
        assert got is not None
        assert got.activated_roles == ["editor"]

    def test_tenant_isolation(self, store) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        store.create(session)
        assert store.get(session.id, "t2") is None

    def test_get_active_for_subject(self, store) -> None:
        s1 = Session(tenant_id="t1", subject_id="alice", activated_roles=["editor"])
        s2 = Session(tenant_id="t1", subject_id="alice", activated_roles=["viewer"])
        store.create(s1)
        store.create(s2)
        active = store.get_active_for_subject("alice", "t1")
        assert len(active) == 2

    def test_update_status(self, store) -> None:
        session = Session(
            tenant_id="t1", subject_id="alice", activated_roles=["editor"]
        )
        store.create(session)
        now = datetime.now(UTC)
        updated = store.update_status(
            session.id, "t1", SessionStatus.DEACTIVATED, deactivated_at=now
        )
        assert updated.status == SessionStatus.DEACTIVATED

    def test_update_status_not_found(self, store) -> None:
        with pytest.raises(SessionNotFoundError):
            store.update_status("nope", "t1", SessionStatus.DEACTIVATED)

    def test_expire_stale(self, store) -> None:
        now = datetime.now(UTC)
        s_expired = Session(
            tenant_id="t1", subject_id="alice",
            activated_roles=["editor"], expires_at=now - timedelta(hours=1),
        )
        s_active = Session(
            tenant_id="t1", subject_id="bob",
            activated_roles=["viewer"], expires_at=now + timedelta(hours=1),
        )
        store.create(s_expired)
        store.create(s_active)
        count = store.expire_stale("t1", now)
        assert count == 1
        assert store.get(s_expired.id, "t1").status == SessionStatus.EXPIRED
        assert store.get(s_active.id, "t1").status == SessionStatus.ACTIVE

    def test_metadata_roundtrip(self, store) -> None:
        """Metadata is stored and retrieved correctly via JSON column."""
        session = Session(
            tenant_id="t1", subject_id="alice",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT", "device": "laptop"},
        )
        store.create(session)
        got = store.get(session.id, "t1")
        assert got.metadata == {"scope": "PROJECT", "device": "laptop"}
