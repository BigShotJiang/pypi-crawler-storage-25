"""Tests for InMemorySessionStore (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import Session, SessionStatus
from open_guard.domain.exceptions import SessionNotFoundError


class TestInMemorySessionStore:
    def setup_method(self) -> None:
        self.store = InMemorySessionStore()

    def _make_session(self, **kwargs) -> Session:
        defaults = {
            "tenant_id": "t1",
            "subject_id": "user-1",
            "activated_roles": ["editor"],
        }
        defaults.update(kwargs)
        return Session(**defaults)

    def test_create_and_get(self) -> None:
        session = self._make_session()
        created = self.store.create(session)
        assert created.id == session.id
        got = self.store.get(session.id, "t1")
        assert got is not None
        assert got.id == session.id

    def test_get_nonexistent_returns_none(self) -> None:
        assert self.store.get("nope", "t1") is None

    def test_tenant_isolation(self) -> None:
        session = self._make_session(tenant_id="t1")
        self.store.create(session)
        assert self.store.get(session.id, "t2") is None

    def test_get_active_for_subject(self) -> None:
        s1 = self._make_session(subject_id="alice")
        s2 = self._make_session(subject_id="alice")
        s3 = self._make_session(subject_id="bob")
        self.store.create(s1)
        self.store.create(s2)
        self.store.create(s3)
        active = self.store.get_active_for_subject("alice", "t1")
        assert len(active) == 2
        assert all(s.subject_id == "alice" for s in active)

    def test_get_active_excludes_deactivated(self) -> None:
        s1 = self._make_session(subject_id="alice")
        self.store.create(s1)
        self.store.update_status(s1.id, "t1", SessionStatus.DEACTIVATED)
        active = self.store.get_active_for_subject("alice", "t1")
        assert len(active) == 0

    def test_update_status(self) -> None:
        session = self._make_session()
        self.store.create(session)
        now = datetime.now(UTC)
        updated = self.store.update_status(
            session.id, "t1", SessionStatus.DEACTIVATED, deactivated_at=now
        )
        assert updated.status == SessionStatus.DEACTIVATED
        assert updated.deactivated_at == now

    def test_update_status_not_found_raises(self) -> None:
        with pytest.raises(SessionNotFoundError):
            self.store.update_status("nope", "t1", SessionStatus.DEACTIVATED)

    def test_expire_stale(self) -> None:
        now = datetime.now(UTC)
        past = now - timedelta(hours=1)
        future = now + timedelta(hours=1)
        s_expired = self._make_session(expires_at=past)
        s_active = self._make_session(expires_at=future)
        s_no_expiry = self._make_session()
        self.store.create(s_expired)
        self.store.create(s_active)
        self.store.create(s_no_expiry)
        count = self.store.expire_stale("t1", now)
        assert count == 1
        assert self.store.get(s_expired.id, "t1").status == SessionStatus.EXPIRED
        assert self.store.get(s_active.id, "t1").status == SessionStatus.ACTIVE
        assert self.store.get(s_no_expiry.id, "t1").status == SessionStatus.ACTIVE

    def test_multiple_concurrent_sessions(self) -> None:
        """Same subject can have multiple active sessions (different scopes)."""
        s1 = self._make_session(
            subject_id="alice",
            activated_roles=["project:editor"],
            metadata={"scope": "PROJECT"},
        )
        s2 = self._make_session(
            subject_id="alice",
            activated_roles=["workspace:viewer"],
            metadata={"scope": "WORKSPACE"},
        )
        self.store.create(s1)
        self.store.create(s2)
        active = self.store.get_active_for_subject("alice", "t1")
        assert len(active) == 2

    def test_expire_stale_tenant_scoped(self) -> None:
        """expire_stale only affects the specified tenant."""
        now = datetime.now(UTC)
        past = now - timedelta(hours=1)
        s_t1 = self._make_session(tenant_id="t1", expires_at=past)
        s_t2 = self._make_session(tenant_id="t2", expires_at=past)
        self.store.create(s_t1)
        self.store.create(s_t2)
        count = self.store.expire_stale("t1", now)
        assert count == 1
        assert self.store.get(s_t1.id, "t1").status == SessionStatus.EXPIRED
        assert self.store.get(s_t2.id, "t2").status == SessionStatus.ACTIVE
