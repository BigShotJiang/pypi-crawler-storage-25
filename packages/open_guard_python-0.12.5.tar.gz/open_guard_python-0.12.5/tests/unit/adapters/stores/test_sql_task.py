"""Tests for SQLAlchemyTaskStore."""

from datetime import UTC, datetime

import pytest

from open_guard.adapters.stores.sql import SQLAlchemyTaskStore
from open_guard.domain.entities import ActorType, Task, TaskStatus
from open_guard.domain.exceptions import TaskError


@pytest.fixture
def store() -> SQLAlchemyTaskStore:
    s = SQLAlchemyTaskStore.from_url("sqlite://")
    s.create_tables()
    return s


def _task(
    task_id: str = "task-1",
    tenant_id: str = "t1",
    actor_id: str = "agent-1",
    status: TaskStatus = TaskStatus.CREATED,
) -> Task:
    return Task(
        id=task_id,
        tenant_id=tenant_id,
        actor_id=actor_id,
        actor_type=ActorType.AGENT,
        status=status,
        allowed_actions=["read", "write"],
        allowed_resource_types=["document"],
        created_at=datetime(2026, 4, 16, 12, 0, 0, tzinfo=UTC),
    )


class TestSQLAlchemyTaskStore:
    def test_add_and_get(self, store: SQLAlchemyTaskStore) -> None:
        task = _task()
        store.add(task)
        result = store.get("task-1", "t1")
        assert result is not None
        assert result.id == "task-1"
        assert result.actor_id == "agent-1"
        assert result.allowed_actions == ["read", "write"]

    def test_get_nonexistent_returns_none(self, store: SQLAlchemyTaskStore) -> None:
        assert store.get("nonexistent", "t1") is None

    def test_update(self, store: SQLAlchemyTaskStore) -> None:
        task = _task()
        store.add(task)
        activated = task.model_copy(
            update={
                "status": TaskStatus.ACTIVE,
                "activated_at": datetime(2026, 4, 16, 13, 0, 0, tzinfo=UTC),
            }
        )
        store.update(activated)
        result = store.get("task-1", "t1")
        assert result is not None
        assert result.status == TaskStatus.ACTIVE
        assert result.activated_at is not None

    def test_update_nonexistent_raises(self, store: SQLAlchemyTaskStore) -> None:
        with pytest.raises(TaskError):
            store.update(_task(task_id="nonexistent"))

    def test_get_active_by_actor(self, store: SQLAlchemyTaskStore) -> None:
        store.add(_task(task_id="t1-active", status=TaskStatus.ACTIVE))
        store.add(_task(task_id="t2-created", status=TaskStatus.CREATED))

        active = store.get_active_by_actor("agent-1", "t1")
        assert len(active) == 1
        assert active[0].id == "t1-active"

    def test_remove(self, store: SQLAlchemyTaskStore) -> None:
        store.add(_task())
        store.remove("task-1", "t1")
        assert store.get("task-1", "t1") is None

    def test_remove_nonexistent_raises(self, store: SQLAlchemyTaskStore) -> None:
        with pytest.raises(TaskError):
            store.remove("nonexistent", "t1")

    def test_tenant_isolation(self, store: SQLAlchemyTaskStore) -> None:
        store.add(_task(task_id="t1", tenant_id="tenant-a"))
        store.add(_task(task_id="t2", tenant_id="tenant-b"))

        assert store.get("t1", "tenant-a") is not None
        assert store.get("t1", "tenant-b") is None
