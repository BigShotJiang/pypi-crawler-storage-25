"""Tests: Factory includes TrustGateEvaluator + operation_chain (Phase 8, Task 7)."""

from __future__ import annotations

import pytest

from open_guard.adapters.evaluators.trust import TrustGateEvaluator
from open_guard.adapters.factory import build_async_guard, build_guard
from open_guard.domain.entities import (
    Action,
    OperationChainConfig,
    OperationRule,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)


class TestFactoryTrustGate:
    """Verify factory wires TrustGateEvaluator by default."""

    def test_memory_guard_includes_trust(self) -> None:
        guard = build_guard(backend="memory")
        types = [e.evaluator_type for e in guard._evaluators]
        assert "trust" in types

    def test_memory_guard_trust_evaluator_type(self) -> None:
        guard = build_guard(backend="memory")
        trust_evals = [e for e in guard._evaluators if isinstance(e, TrustGateEvaluator)]
        assert len(trust_evals) == 1

    def test_memory_guard_with_operation_chain(self) -> None:
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac", "trust"])],
        )
        guard = build_guard(backend="memory", operation_chain=chain)
        assert guard._router._operation_chain is chain

    def test_trust_policy_via_factory(self) -> None:
        """End-to-end: trust policy works through factory-built guard."""
        guard = build_guard(backend="memory")
        guard._policy_store.add(
            Policy(
                id="trust-1",
                tenant_id="t1",
                evaluator_type="trust",
                effect=PolicyEffect.ALLOW,
                conditions={"min_trust_score": 0.5},
            )
        )
        subject = Subject(id="u1", attributes={"trust_score": 0.8})
        decision = guard.authorize(
            subject=subject,
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )
        assert decision.allowed


class TestAsyncFactoryTrustGate:
    """Verify async factory wires TrustGateEvaluator."""

    @pytest.mark.asyncio
    async def test_async_memory_guard_includes_trust(self) -> None:
        guard = await build_async_guard(backend="memory")
        types = [e.evaluator_type for e in guard._evaluators]
        assert "trust" in types

    @pytest.mark.asyncio
    async def test_async_memory_guard_with_operation_chain(self) -> None:
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
        )
        guard = await build_async_guard(backend="memory", operation_chain=chain)
        assert guard._policy_router._operation_chain is chain
