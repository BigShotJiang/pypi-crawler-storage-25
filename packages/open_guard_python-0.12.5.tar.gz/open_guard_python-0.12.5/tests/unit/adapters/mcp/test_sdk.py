"""Tests for the optional [mcp] SDK binding layer."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import pytest

from open_guard.adapters.mcp.sdk import from_sdk_call_request


@dataclass
class _FakeSDKRequest:
    name: str
    arguments: dict[str, Any]


@dataclass
class _FakeSDKRequestAlt:
    """Alternate shape — some versions use tool_name/params."""

    tool_name: str
    params: dict[str, Any]


class TestFromSDKCallRequest:
    def test_converts_name_and_arguments(self) -> None:
        sdk_req = _FakeSDKRequest(
            name="query_db", arguments={"table": "users"}
        )
        out = from_sdk_call_request(
            sdk_req, session_id="s1", server_id="prod"
        )
        assert out.tool_name == "query_db"
        assert out.params == {"table": "users"}
        assert out.session_id == "s1"
        assert out.server_id == "prod"

    def test_converts_tool_name_and_params_fallback(self) -> None:
        sdk_req = _FakeSDKRequestAlt(
            tool_name="read_file", params={"path": "/tmp/x"}
        )
        out = from_sdk_call_request(
            sdk_req, session_id="s1", server_id="prod"
        )
        assert out.tool_name == "read_file"
        assert out.params == {"path": "/tmp/x"}

    def test_claims_propagate(self) -> None:
        sdk_req = _FakeSDKRequest(name="t", arguments={})
        out = from_sdk_call_request(
            sdk_req, session_id="s1", server_id="prod",
            claims={"tenant_id": "t9", "sub": "agent-a"},
        )
        assert out.claims["tenant_id"] == "t9"

    def test_missing_name_raises(self) -> None:
        @dataclass
        class _Bogus:
            other: str = "x"

        with pytest.raises(ValueError, match=r"no \.name"):
            from_sdk_call_request(
                _Bogus(), session_id="s1", server_id="prod"
            )
