"""Tests for MCP adapter entities."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from open_guard.adapters.mcp.entities import (
    MCPAuthorizationPending,
    MCPAuthorizationResult,
    MCPToolRequest,
    MCPToolResponse,
)


class TestMCPToolRequest:
    def test_basic_shape(self) -> None:
        req = MCPToolRequest(
            session_id="s1",
            server_id="prod",
            tool_name="query_db",
            params={"table": "users"},
            claims={"sub": "agent-a"},
        )
        assert req.session_id == "s1"
        assert req.params["table"] == "users"
        assert req.claims["sub"] == "agent-a"

    def test_defaults(self) -> None:
        req = MCPToolRequest(session_id="s1", server_id="prod", tool_name="t")
        assert req.params == {}
        assert req.claims == {}


class TestMCPToolResponse:
    def test_content_and_error(self) -> None:
        ok = MCPToolResponse(content="hello")
        assert ok.is_error is False
        err = MCPToolResponse(content={"msg": "nope"}, is_error=True)
        assert err.is_error is True


class TestMCPAuthorizationResult:
    def test_allow(self) -> None:
        r = MCPAuthorizationResult(status="allow", reason="p1 matched")
        assert r.is_allowed() is True
        assert r.is_pending() is False
        assert r.is_denied() is False

    def test_deny(self) -> None:
        r = MCPAuthorizationResult(status="deny", reason="no policy")
        assert r.is_denied() is True
        assert r.is_allowed() is False

    def test_pending_carries_metadata(self) -> None:
        r = MCPAuthorizationResult(
            status="pending",
            reason="awaiting",
            pending=MCPAuthorizationPending(
                approval_request_id="req-1",
                approvers=["alice"],
                quorum="any",
                channel="slack",
                ttl_seconds=300,
            ),
        )
        assert r.is_pending() is True
        assert r.pending is not None
        assert r.pending.approval_request_id == "req-1"
        assert r.pending.channel == "slack"

    def test_status_must_be_known_literal(self) -> None:
        with pytest.raises(ValidationError):
            MCPAuthorizationResult(status="maybe")  # type: ignore[arg-type]
