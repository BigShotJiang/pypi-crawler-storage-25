"""Tests for MCPGuard — Phase 4 (FEAT-009)."""

from __future__ import annotations

from typing import Any

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.mcp.guard import DEFAULT_RESOURCE_NAMESPACE, MCPGuard
from open_guard.adapters.mcp.resolver import MCPSessionResolver
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequirement,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.services.guard import Guard

# --- Fixtures ---------------------------------------------------------------


class StaticResolver:
    """Test fixture resolver. Returns whatever Subject it was seeded with."""

    def __init__(self, subject: Subject) -> None:
        self._subject = subject

    def resolve(self, session_id: str, claims: dict[str, Any]) -> Subject:
        return self._subject


def _guard_with_policies(
    policies: list[Policy],
    *,
    approval_store: InMemoryApprovalStore | None = None,
    candidate_source: CandidateResourcePort | None = None,
) -> Guard:
    store = InMemoryPolicyStore()
    for p in policies:
        store.add(p)
    return Guard(
        policy_store=store,
        evaluators=[RBACEvaluator(), ABACEvaluator()],
        approval_store=approval_store,
        candidate_source=candidate_source,
    )


# --- Construction + namespace ----------------------------------------------


class TestMCPGuardConstruction:
    def test_resolver_protocol_satisfied_by_duck_typing(self) -> None:
        assert isinstance(
            StaticResolver(Subject(id="x")), MCPSessionResolver
        )

    def test_default_resource_namespace(self) -> None:
        mcp = MCPGuard(
            guard=_guard_with_policies([]),
            resolver=StaticResolver(Subject(id="x")),
            default_tenant_id="t1",
        )
        assert mcp.resource_namespace == DEFAULT_RESOURCE_NAMESPACE
        assert (
            mcp._make_resource_id("prod", "query_db")
            == "tool:prod:query_db"
        )

    def test_custom_resource_namespace(self) -> None:
        mcp = MCPGuard(
            guard=_guard_with_policies([]),
            resolver=StaticResolver(Subject(id="x")),
            default_tenant_id="t1",
            resource_namespace="mcp:{server_id}:{tool_name}",
        )
        assert (
            mcp._make_resource_id("staging", "send_email")
            == "mcp:staging:send_email"
        )


# --- check_tool_call — allow / deny -----------------------------------------


class TestMCPCheckToolCallBasic:
    def test_allow_when_rbac_policy_matches(self) -> None:
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                )
            ]
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )
        result = mcp.check_tool_call(
            session_id="s1",
            tool_name="query_db",
            params={"table": "users"},
            server_id="prod",
        )
        assert result.is_allowed()

    def test_deny_when_no_matching_policy(self) -> None:
        guard = _guard_with_policies([])
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(Subject(id="agent-a")),
            default_tenant_id="t1",
        )
        result = mcp.check_tool_call(
            "s1", "query_db", {"table": "users"}, "prod"
        )
        assert result.is_denied()

    def test_claims_tenant_id_overrides_default(self) -> None:
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="other-tenant",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                )
            ]
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )
        result = mcp.check_tool_call(
            session_id="s1",
            tool_name="query_db",
            params={"table": "users"},
            server_id="prod",
            claims={"tenant_id": "other-tenant"},
        )
        assert result.is_allowed()


# --- check_tool_call — pending approval -------------------------------------


class TestMCPCheckToolCallPending:
    def test_pending_approval_returns_metadata_with_ttl(self) -> None:
        """Policy requires approval → pending result carries request id, TTL."""
        from datetime import timedelta

        approval_store = InMemoryApprovalStore()
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "delete_file"},
                    requires_approval=ApprovalRequirement(
                        approvers=["admin@corp"],
                        quorum="any",
                        ttl=timedelta(minutes=5),
                        channel="slack",
                    ),
                )
            ],
            approval_store=approval_store,
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )
        result = mcp.check_tool_call(
            "s1", "delete_file", {"path": "/tmp/x"}, "prod"
        )
        assert result.is_pending()
        assert result.pending is not None
        assert result.pending.approvers == ["admin@corp"]
        assert result.pending.quorum == "any"
        assert result.pending.channel == "slack"
        assert result.pending.ttl_seconds == 300

    def test_pending_then_approve_resolves_to_allow(self) -> None:
        approval_store = InMemoryApprovalStore()
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "delete_file"},
                    requires_approval=ApprovalRequirement(
                        approvers=["admin@corp"], quorum="any",
                    ),
                )
            ],
            approval_store=approval_store,
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )

        result1 = mcp.check_tool_call(
            "s1", "delete_file", {"path": "/tmp/x"}, "prod"
        )
        assert result1.is_pending()
        guard.approve(
            result1.pending.approval_request_id,
            tenant_id="t1",
            approver="admin@corp",
        )

        result2 = mcp.check_tool_call(
            "s1", "delete_file", {"path": "/tmp/x"}, "prod"
        )
        assert result2.is_allowed()


# --- Schema hygiene ---------------------------------------------------------


class TestMCPSchemaHygiene:
    def test_missing_required_field_rejected_before_authz(self) -> None:
        """Malformed call denied with schema_violation reason; authz not hit."""
        class CountingGuard:
            def __init__(self, inner: Guard) -> None:
                self._inner = inner
                self.calls = 0

            @property
            def approval_store(self):  # type: ignore[no-untyped-def]
                return self._inner.approval_store

            def authorize(self, *args, **kwargs):  # type: ignore[no-untyped-def]
                self.calls += 1
                return self._inner.authorize(*args, **kwargs)

            def authorize_traced(self, *args, **kwargs):  # type: ignore[no-untyped-def]
                self.calls += 1
                return self._inner.authorize_traced(*args, **kwargs)

            def list_authorized(self, *args, **kwargs):  # type: ignore[no-untyped-def]
                return self._inner.list_authorized(*args, **kwargs)

        inner = _guard_with_policies([])
        spy = CountingGuard(inner)
        mcp = MCPGuard(
            guard=spy,  # type: ignore[arg-type]
            resolver=StaticResolver(Subject(id="agent-a")),
            default_tenant_id="t1",
        )
        schema = {"type": "object", "required": ["table"]}
        result = mcp.check_tool_call(
            "s1", "query_db", {"limit": 10}, "prod", tool_schema=schema
        )
        assert result.is_denied()
        assert result.reason is not None
        assert result.reason.startswith("schema_violation")
        assert spy.calls == 0

    def test_type_mismatch_rejected(self) -> None:
        mcp = MCPGuard(
            guard=_guard_with_policies([]),
            resolver=StaticResolver(Subject(id="agent-a")),
            default_tenant_id="t1",
        )
        schema = {
            "type": "object",
            "properties": {"limit": {"type": "integer"}},
        }
        result = mcp.check_tool_call(
            "s1", "query_db", {"limit": "ten"}, "prod", tool_schema=schema
        )
        assert result.is_denied()
        assert result.reason is not None
        assert "expected" in result.reason

    def test_valid_schema_passes_through(self) -> None:
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                )
            ]
        )
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(
                Subject(id="agent-a", attributes={"roles": ["researcher"]})
            ),
            default_tenant_id="t1",
        )
        schema = {
            "type": "object",
            "required": ["table"],
            "properties": {"table": {"type": "string"}},
        }
        result = mcp.check_tool_call(
            "s1", "query_db", {"table": "users"}, "prod",
            tool_schema=schema,
        )
        assert result.is_allowed()


# --- Chain propagation ------------------------------------------------------


class TestMCPChainPropagation:
    def test_chain_predicate_evaluated_on_tool_call(self) -> None:
        """Agent acts on_behalf_of user; ABAC chain predicate gates the call."""
        guard = _guard_with_policies(
            [
                # ABAC: allow when chain.root_actor.attributes.trusted is True
                Policy(
                    tenant_id="t1",
                    evaluator_type="abac",
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                    conditions={
                        "chain.root_actor.trusted": {
                            "op": "eq",
                            "value": True,
                        }
                    },
                )
            ]
        )
        trusted_user = Subject(
            id="alice", attributes={"trusted": True},
        )
        agent = Subject(
            id="agent-a",
            actor_type=ActorType.AGENT,
            on_behalf_of=trusted_user,
        )
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(agent),
            default_tenant_id="t1",
        )
        result = mcp.check_tool_call(
            "s1", "query_db", {"table": "users"}, "prod"
        )
        assert result.is_allowed()


# --- check_tool_call_traced -------------------------------------------------


class TestMCPCheckToolCallTraced:
    def test_traced_returns_trace_when_authz_runs(self) -> None:
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                )
            ]
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )
        result, trace = mcp.check_tool_call_traced(
            "s1", "query_db", {"table": "users"}, "prod"
        )
        assert result.is_allowed()
        assert trace is not None
        assert trace.schema_version == "1.0"

    def test_traced_returns_none_trace_on_schema_violation(self) -> None:
        mcp = MCPGuard(
            guard=_guard_with_policies([]),
            resolver=StaticResolver(Subject(id="agent-a")),
            default_tenant_id="t1",
        )
        schema = {"type": "object", "required": ["table"]}
        result, trace = mcp.check_tool_call_traced(
            "s1", "query_db", {"limit": 10}, "prod", tool_schema=schema
        )
        assert result.is_denied()
        assert trace is None


# --- Parameter-level ABAC ---------------------------------------------------


class TestMCPParamLevelABAC:
    def test_param_regex_blocks_destructive_query(self) -> None:
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="abac",
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                    conditions={
                        "resource.params.query": {
                            "op": "not_regex",
                            "value": r"(?i)\b(DROP|DELETE|TRUNCATE)\b",
                        }
                    },
                )
            ]
        )
        subject = Subject(id="agent-a")
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )

        allowed = mcp.check_tool_call(
            "s1", "query_db", {"query": "SELECT 1"}, "prod"
        )
        assert allowed.is_allowed()

        blocked = mcp.check_tool_call(
            "s1", "query_db", {"query": "DROP TABLE users"}, "prod"
        )
        assert blocked.is_denied()

    def test_nested_param_path(self) -> None:
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="abac",
                    action_match="invoke",
                    resource_match={"tool_name": "run"},
                    conditions={
                        "resource.params.options.safe": {
                            "op": "eq", "value": True,
                        }
                    },
                )
            ]
        )
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(Subject(id="agent-a")),
            default_tenant_id="t1",
        )
        allowed = mcp.check_tool_call(
            "s1", "run", {"options": {"safe": True}}, "prod"
        )
        assert allowed.is_allowed()
        denied = mcp.check_tool_call(
            "s1", "run", {"options": {"safe": False}}, "prod"
        )
        assert denied.is_denied()


# --- list_authorized_tools --------------------------------------------------


class InMemoryToolCandidateSource(CandidateResourcePort):
    def __init__(self, tools: list[tuple[str, str]]) -> None:
        # tools: list of (server_id, tool_name)
        self._tools = tools

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._tools
        if prefilter:
            items = [
                (s, t) for (s, t) in items
                if all(
                    (k == "server_id" and s == v) or k != "server_id"
                    for k, v in prefilter.items()
                )
            ]
        resources = [
            Resource(
                id=f"tool:{s}:{t}",
                resource_type="tool",
                tenant_id=tenant_id,
                attributes={
                    "type": "tool",
                    "tool_name": t,
                    "server_id": s,
                    "params": {},
                },
            )
            for (s, t) in items
        ]
        return resources, None


class TestMCPListAuthorizedTools:
    def test_returns_tool_ids_subject_can_invoke(self) -> None:
        source = InMemoryToolCandidateSource(
            [("prod", "query_db"), ("prod", "read_file"), ("prod", "delete_file")]
        )
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                ),
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "read_file"},
                ),
            ],
            candidate_source=source,
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )
        result = mcp.list_authorized_tools("s1")
        assert sorted(result.ids) == [
            "tool:prod:query_db",
            "tool:prod:read_file",
        ]

    def test_prefilter_by_server_id(self) -> None:
        source = InMemoryToolCandidateSource(
            [("prod", "query_db"), ("staging", "query_db")]
        )
        guard = _guard_with_policies(
            [
                Policy(
                    tenant_id="t1",
                    evaluator_type="rbac",
                    subject_match={"roles": ["researcher"]},
                    action_match="invoke",
                    resource_match={"tool_name": "query_db"},
                )
            ],
            candidate_source=source,
        )
        subject = Subject(id="agent-a", attributes={"roles": ["researcher"]})
        mcp = MCPGuard(
            guard=guard,
            resolver=StaticResolver(subject),
            default_tenant_id="t1",
        )
        result = mcp.list_authorized_tools("s1", server_id="prod")
        assert result.ids == ["tool:prod:query_db"]
