"""Tests for MCPGuard.consume_tool_call_budget + attributed_delegation_ids (T12)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

from open_guard.adapters.mcp.guard import MCPGuard
from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    Subject,
)
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockEvaluator, MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


class _MockResolver:
    """Returns a fixed agent subject."""
    def resolve(self, session_id: str, claims: dict) -> Subject:
        return Subject(id=claims.get("sub", "agent-1"), actor_type=ActorType.AGENT)


def _make_mcp_guard(
    *,
    policy_allowed: bool = False,
    delegation_store: InMemoryDelegationStore | None = None,
) -> tuple[MCPGuard, InMemoryDelegationStore]:
    ds = delegation_store or InMemoryDelegationStore()
    store = MockPolicyStore(
        [Policy(tenant_id=TENANT, evaluator_type="rbac")] if policy_allowed else []
    )
    evs = [MockEvaluator("rbac", allowed=policy_allowed)] if policy_allowed else []
    guard = Guard(
        policy_store=store,
        evaluators=evs,
        delegation_store=ds,
        clock=lambda: NOW,
    )
    mcp = MCPGuard(
        guard=guard,
        resolver=_MockResolver(),  # type: ignore[arg-type]
        default_tenant_id=TENANT,
    )
    return mcp, ds


def _tool_delegation(
    *,
    to_id: str = "agent-1",
    max_uses: int | None = None,
    budget: Decimal | None = None,
) -> Delegation:
    scope = DelegationScope(
        action_match="invoke",
        resource_type="tool",
        resource_match={"id": {"op": "eq", "value": "tool:srv:my_tool"}},
    )
    return Delegation(
        tenant_id=TENANT,
        from_subject_id="alice",
        from_subject_type=ActorType.USER,
        to_subject_id=to_id,
        to_subject_type=ActorType.AGENT,
        scopes=[scope],
        status=DelegationStatus.ACTIVE,
        re_check_on_use=False,
        max_uses=max_uses,
        uses_remaining=max_uses,
        budget=budget,
        budget_remaining=budget,
        request_hash=f"hash-tool-{to_id}",
        created_at=NOW,
        created_by="alice",
    )


class TestMCPAttributedDelegationIds:
    def test_delegation_allowed_populates_attributed_ids(self) -> None:
        """Delegation-allowed tool call populates attributed_delegation_ids."""
        mcp, ds = _make_mcp_guard(policy_allowed=False)
        d = _tool_delegation(to_id="agent-1")
        ds.create(d)

        result = mcp.check_tool_call(
            session_id="sess-1",
            tool_name="my_tool",
            params={},
            server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        assert d.id in result.attributed_delegation_ids

    def test_policy_allowed_attributed_ids_empty(self) -> None:
        """Tool call allowed via policy → attributed_delegation_ids is empty."""
        mcp, _ = _make_mcp_guard(policy_allowed=True)

        result = mcp.check_tool_call(
            session_id="sess-1",
            tool_name="my_tool",
            params={},
            server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        assert result.attributed_delegation_ids == []

    def test_denied_attributed_ids_empty(self) -> None:
        """Tool call denied → attributed_delegation_ids is empty."""
        mcp, _ = _make_mcp_guard(policy_allowed=False)

        result = mcp.check_tool_call(
            session_id="sess-1",
            tool_name="my_tool",
            params={},
            server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "deny"
        assert result.attributed_delegation_ids == []


class TestMCPConsumeToolCallBudget:
    def test_consume_decrements_uses_on_delegation_allow(self) -> None:
        mcp, ds = _make_mcp_guard(policy_allowed=False)
        d = _tool_delegation(to_id="agent-1", max_uses=5)
        ds.create(d)

        result = mcp.check_tool_call(
            session_id="sess-1", tool_name="my_tool", params={}, server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        mcp.consume_tool_call_budget(result, TENANT, amount=1)

        updated = ds.get(d.id, TENANT)
        assert updated is not None
        assert updated.uses_remaining == 4

    def test_consume_decrements_budget_on_delegation_allow(self) -> None:
        mcp, ds = _make_mcp_guard(policy_allowed=False)
        d = _tool_delegation(to_id="agent-1", budget=Decimal("10.00"))
        ds.create(d)

        result = mcp.check_tool_call(
            session_id="sess-1", tool_name="my_tool", params={}, server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        mcp.consume_tool_call_budget(result, TENANT, cost=Decimal("2.50"))

        updated = ds.get(d.id, TENANT)
        assert updated is not None
        assert updated.budget_remaining == Decimal("7.50")

    def test_consume_noop_on_policy_allow(self) -> None:
        """No delegation IDs → consume_tool_call_budget is a no-op."""
        mcp, ds = _make_mcp_guard(policy_allowed=True)
        d = _tool_delegation(to_id="agent-1", max_uses=5)
        ds.create(d)

        result = mcp.check_tool_call(
            session_id="sess-1", tool_name="my_tool", params={}, server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "allow"
        mcp.consume_tool_call_budget(result, TENANT, amount=1)

        unchanged = ds.get(d.id, TENANT)
        assert unchanged is not None
        assert unchanged.uses_remaining == 5  # untouched

    def test_consume_noop_on_deny(self) -> None:
        """Denied result → consume_tool_call_budget is a no-op."""
        mcp, ds = _make_mcp_guard(policy_allowed=False)
        d = _tool_delegation(to_id="agent-1", max_uses=5, budget=Decimal("10.00"))
        d = d.model_copy(update={"status": DelegationStatus.REVOKED})
        ds.create(d)

        result = mcp.check_tool_call(
            session_id="sess-1", tool_name="my_tool", params={}, server_id="srv",
            claims={"sub": "agent-1", "tenant_id": TENANT},
        )
        assert result.status == "deny"
        mcp.consume_tool_call_budget(result, TENANT, amount=1)
        # No exception, no change
