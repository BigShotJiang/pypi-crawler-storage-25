"""Tests for AsyncGuard SQL backend factory wiring (FEAT-016)."""

from __future__ import annotations

import pytest

from open_guard.adapters.factory import build_async_guard
from open_guard.domain.entities import Action, Policy, Resource, Subject


class TestBuildAsyncGuardSQL:
    @pytest.mark.asyncio
    async def test_sqlite_backend_creates_guard(self, tmp_path) -> None:
        """build_async_guard with aiosqlite DSN creates a working AsyncGuard."""
        dsn = f"sqlite+aiosqlite:///{tmp_path}/test.db"
        guard = await build_async_guard(dsn=dsn)
        assert guard is not None
        assert guard.policy_store is not None

    @pytest.mark.asyncio
    async def test_sqlite_backend_authorize_works(self, tmp_path) -> None:
        """Full authorize round-trip with SQL-backed AsyncGuard."""
        dsn = f"sqlite+aiosqlite:///{tmp_path}/test.db"
        guard = await build_async_guard(dsn=dsn)

        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["admin"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )

        decision = await guard.authorize(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_sqlite_backend_deny_works(self, tmp_path) -> None:
        """Deny case works with SQL-backed AsyncGuard."""
        dsn = f"sqlite+aiosqlite:///{tmp_path}/test.db"
        guard = await build_async_guard(dsn=dsn)

        decision = await guard.authorize(
            Subject(id="alice", attributes={"roles": ["viewer"]}),
            Action(name="delete"),
            Resource(id="d1", resource_type="doc", attributes={}),
            tenant_id="t1",
        )
        assert not decision.allowed

    @pytest.mark.asyncio
    async def test_sqlite_policy_persists_across_guard_rebuilds(
        self, tmp_path
    ) -> None:
        """Policies written by one guard instance are visible to the next."""
        dsn = f"sqlite+aiosqlite:///{tmp_path}/test.db"

        guard1 = await build_async_guard(dsn=dsn)
        await guard1.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="write",
                resource_match={},
            )
        )

        # Rebuild — same file, should see the same policy
        guard2 = await build_async_guard(dsn=dsn)
        policies = await guard2.policy_store.get_by_tenant("t1")
        assert len(policies) == 1
        assert "editor" in policies[0].subject_match.get("roles", [])

    @pytest.mark.asyncio
    async def test_sqlite_backend_has_sql_stores(self, tmp_path) -> None:
        """All stores are SQL-backed (not in-memory)."""
        from open_guard.adapters.stores.async_sql import AsyncSQLAlchemyPolicyStore
        from open_guard.adapters.stores.async_sql_relationship import (
            AsyncSQLAlchemyRelationshipStore,
        )

        dsn = f"sqlite+aiosqlite:///{tmp_path}/test.db"
        guard = await build_async_guard(dsn=dsn)
        assert isinstance(guard.policy_store, AsyncSQLAlchemyPolicyStore)
        assert isinstance(guard._relationship_store, AsyncSQLAlchemyRelationshipStore)

    @pytest.mark.asyncio
    async def test_memory_backend_still_works(self) -> None:
        """Memory backend unchanged after adding SQL support."""
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore

        guard = await build_async_guard()
        assert guard is not None
        assert isinstance(guard.policy_store, AsyncInMemoryPolicyStore)

    @pytest.mark.asyncio
    async def test_memory_backend_explicit_still_works(self) -> None:
        guard = await build_async_guard(backend="memory")
        assert guard is not None

    @pytest.mark.asyncio
    async def test_sqlite_backend_has_five_evaluators(self, tmp_path) -> None:
        """SQL-backed AsyncGuard has all 5 evaluators."""
        dsn = f"sqlite+aiosqlite:///{tmp_path}/test.db"
        guard = await build_async_guard(dsn=dsn)
        assert len(guard._evaluators) == 5
