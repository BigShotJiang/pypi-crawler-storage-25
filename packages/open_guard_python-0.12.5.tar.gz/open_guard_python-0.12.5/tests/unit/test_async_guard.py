"""Tests for AsyncGuard (Phase 7 -- T12)."""

from __future__ import annotations

import pytest

from open_guard.domain.entities import Action, Policy, Resource, Subject
from open_guard.domain.services.async_guard import AsyncGuard


class TestAsyncGuard:
    @pytest.mark.asyncio
    async def test_from_config_memory(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        assert guard is not None
        assert guard.policy_store is not None

    @pytest.mark.asyncio
    async def test_authorize_rbac_allow(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["admin"]},
                action_match="read",
                resource_match={"type": "doc"},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        decision = await guard.authorize(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_authorize_denied_no_matching_policy(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        decision = await guard.authorize(
            Subject(id="alice", attributes={"roles": ["viewer"]}),
            Action(name="delete"),
            Resource(id="d1", resource_type="doc", attributes={}),
            tenant_id="t1",
        )
        assert not decision.allowed

    @pytest.mark.asyncio
    async def test_authorize_traced_returns_trace(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["admin"]},
                action_match="*",
                resource_match={},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        decision, trace = await guard.authorize_traced(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={}),
            tenant_id="t1",
        )
        assert decision.allowed
        assert trace is not None
        assert trace.decision_status is not None

    @pytest.mark.asyncio
    async def test_authorize_with_context(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="write",
                resource_match={"type": "doc"},
                conditions={},
                effect="allow",
                priority=0,
            )
        )
        decision = await guard.authorize(
            Subject(id="bob", attributes={"roles": ["editor"]}),
            Action(name="write"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
            context={"ip": "10.0.0.1"},
        )
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_chain_depth_exceeded(self) -> None:
        from open_guard.domain.exceptions import ChainDepthExceededError

        guard = await AsyncGuard.from_config(backend="memory", max_chain_depth=1)
        deep_subject = Subject(
            id="proxy",
            attributes={},
            on_behalf_of=Subject(
                id="inner",
                attributes={},
                on_behalf_of=Subject(id="root", attributes={}),
            ),
        )
        with pytest.raises(ChainDepthExceededError):
            await guard.authorize(
                deep_subject,
                Action(name="read"),
                Resource(id="r1", resource_type="doc", attributes={}),
                tenant_id="t1",
            )

    @pytest.mark.asyncio
    async def test_session_not_found_raises(self) -> None:
        from open_guard.domain.exceptions import SessionNotFoundError

        guard = await AsyncGuard.from_config(backend="memory")
        with pytest.raises(SessionNotFoundError):
            await guard.authorize(
                Subject(id="alice", attributes={}),
                Action(name="read"),
                Resource(id="r1", resource_type="doc", attributes={}),
                tenant_id="t1",
                session_id="nonexistent",
            )

    @pytest.mark.asyncio
    async def test_unsupported_backend_raises(self) -> None:
        with pytest.raises(ValueError, match="Unsupported async backend"):
            await AsyncGuard.from_config(backend="redis")
