"""Tests for Guard.from_config() factory (Phase 7 — T1)."""

from __future__ import annotations

import pytest

from open_guard import Action, Guard, Policy, Resource, Subject


class TestGuardFromConfig:
    """Guard.from_config() factory method."""

    def test_memory_backend_explicit(self) -> None:
        guard = Guard.from_config(backend="memory")
        assert guard is not None
        assert len(guard._evaluators) == 5  # rbac, abac, tbac, rebac, trust

    def test_memory_backend_default(self) -> None:
        """No args defaults to memory."""
        guard = Guard.from_config()
        assert guard is not None

    def test_memory_backend_authorize_works(self) -> None:
        """Fully-wired guard can evaluate authorization."""
        guard = Guard.from_config(backend="memory")
        guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["admin"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        decision = guard.authorize(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    def test_sqlite_backend(self, tmp_path: object) -> None:
        dsn = f"sqlite:///{tmp_path}/test.db"
        guard = Guard.from_config(dsn)
        assert guard is not None

    def test_sqlite_backend_authorize_works(self, tmp_path: object) -> None:
        dsn = f"sqlite:///{tmp_path}/test.db"
        guard = Guard.from_config(dsn)
        guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["viewer"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        decision = guard.authorize(
            Subject(id="bob", attributes={"roles": ["viewer"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    def test_invalid_backend_raises(self) -> None:
        with pytest.raises(ValueError, match="Unsupported backend"):
            Guard.from_config(backend="redis")

    def test_invalid_dsn_raises(self) -> None:
        with pytest.raises(ValueError, match="Cannot auto-detect"):
            Guard.from_config("redis://localhost")

    def test_custom_kwargs_forwarded(self) -> None:
        guard = Guard.from_config(backend="memory", max_chain_depth=10)
        assert guard._max_chain_depth == 10

    def test_all_stores_wired_memory(self) -> None:
        """Memory backend wires all optional stores."""
        guard = Guard.from_config(backend="memory")
        assert guard.policy_store is not None
        assert guard._approval_mgr is not None
        assert guard._delegation_manager is not None
        assert guard._session_store is not None

    def test_all_stores_wired_sqlite(self, tmp_path: object) -> None:
        dsn = f"sqlite:///{tmp_path}/test.db"
        guard = Guard.from_config(dsn)
        assert guard.policy_store is not None
        assert guard._approval_mgr is not None
        assert guard._delegation_manager is not None
        assert guard._session_store is not None
