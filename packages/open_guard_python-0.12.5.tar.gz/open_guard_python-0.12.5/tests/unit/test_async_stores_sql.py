"""Tests for async SQLAlchemy stores (Phase 7 -- T9)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest
import pytest_asyncio
from sqlalchemy.ext.asyncio import create_async_engine

from open_guard.adapters.stores.sql_models import metadata
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    RelationTuple,
    Session,
    SessionStatus,
    Task,
    TaskStatus,
)

pytestmark = pytest.mark.asyncio


@pytest_asyncio.fixture
async def async_engine(tmp_path):  # type: ignore[no-untyped-def]
    engine = create_async_engine(f"sqlite+aiosqlite:///{tmp_path}/test.db")
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)
    yield engine
    await engine.dispose()


# -----------------------------------------------------------------------
# PolicyStore
# -----------------------------------------------------------------------


class TestAsyncSQLPolicyStore:
    async def test_add_and_get(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyPolicyStore,
        )

        store = AsyncSQLAlchemyPolicyStore(async_engine)
        policy = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
            resource_match={},
            conditions={},
            effect="allow",
            priority=0,
        )
        added = await store.add(policy)
        results = await store.get_by_tenant("t1")
        assert len(results) == 1
        assert results[0].id == added.id

    async def test_get_by_tenant_and_type(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyPolicyStore,
        )

        store = AsyncSQLAlchemyPolicyStore(async_engine)
        p1 = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={},
            action_match="*",
        )
        p2 = Policy(
            tenant_id="t1",
            evaluator_type="abac",
            subject_match={},
            action_match="*",
        )
        await store.add(p1)
        await store.add(p2)
        rbac = await store.get_by_tenant_and_type("t1", "rbac")
        assert len(rbac) == 1
        assert rbac[0].evaluator_type == "rbac"

    async def test_remove(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyPolicyStore,
        )

        store = AsyncSQLAlchemyPolicyStore(async_engine)
        policy = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
        )
        added = await store.add(policy)
        await store.remove(added.id, "t1")
        results = await store.get_by_tenant("t1")
        assert len(results) == 0

    async def test_remove_not_found_raises(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyPolicyStore,
        )
        from open_guard.domain.exceptions import PolicyError

        store = AsyncSQLAlchemyPolicyStore(async_engine)
        with pytest.raises(PolicyError):
            await store.remove("nonexistent", "t1")


# -----------------------------------------------------------------------
# TaskStore
# -----------------------------------------------------------------------


class TestAsyncSQLTaskStore:
    async def test_add_and_get(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyTaskStore,
        )

        store = AsyncSQLAlchemyTaskStore(async_engine)
        now = datetime.now(UTC)
        task = Task(
            tenant_id="t1",
            actor_id="agent-1",
            actor_type=ActorType.AGENT,
            status=TaskStatus.ACTIVE,
            created_at=now,
            activated_at=now,
        )
        added = await store.add(task)
        got = await store.get(added.id, "t1")
        assert got is not None
        assert got.id == added.id

    async def test_get_active_by_actor(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyTaskStore,
        )

        store = AsyncSQLAlchemyTaskStore(async_engine)
        now = datetime.now(UTC)
        active = Task(
            tenant_id="t1",
            actor_id="a1",
            actor_type=ActorType.AGENT,
            status=TaskStatus.ACTIVE,
            created_at=now,
            activated_at=now,
        )
        completed = Task(
            tenant_id="t1",
            actor_id="a1",
            actor_type=ActorType.AGENT,
            status=TaskStatus.COMPLETED,
            created_at=now,
            completed_at=now,
        )
        await store.add(active)
        await store.add(completed)
        results = await store.get_active_by_actor("a1", "t1")
        assert len(results) == 1
        assert results[0].status == TaskStatus.ACTIVE

    async def test_remove(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql import (
            AsyncSQLAlchemyTaskStore,
        )

        store = AsyncSQLAlchemyTaskStore(async_engine)
        task = Task(
            tenant_id="t1",
            actor_id="a1",
            actor_type=ActorType.AGENT,
            status=TaskStatus.ACTIVE,
            created_at=datetime.now(UTC),
        )
        added = await store.add(task)
        await store.remove(added.id, "t1")
        assert await store.get(added.id, "t1") is None


# -----------------------------------------------------------------------
# RelationshipStore
# -----------------------------------------------------------------------


class TestAsyncSQLRelationshipStore:
    async def test_write_and_read(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_relationship import (
            AsyncSQLAlchemyRelationshipStore,
        )

        store = AsyncSQLAlchemyRelationshipStore(async_engine)
        rt = RelationTuple(
            tenant_id="t1",
            object_type="doc",
            object_id="d1",
            relation="viewer",
            subject_type="user",
            subject_id="u1",
        )
        await store.write_tuple(rt)
        tuples = await store.read_tuples("t1", object_type="doc")
        assert len(tuples) == 1
        assert tuples[0].subject_id == "u1"

    async def test_duplicate_rejected(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_relationship import (
            AsyncSQLAlchemyRelationshipStore,
        )
        from open_guard.domain.exceptions import RelationshipError

        store = AsyncSQLAlchemyRelationshipStore(async_engine)
        rt = RelationTuple(
            tenant_id="t1",
            object_type="doc",
            object_id="d1",
            relation="viewer",
            subject_type="user",
            subject_id="u1",
        )
        await store.write_tuple(rt)
        rt2 = RelationTuple(
            tenant_id="t1",
            object_type="doc",
            object_id="d1",
            relation="viewer",
            subject_type="user",
            subject_id="u1",
        )
        with pytest.raises(RelationshipError, match="Duplicate"):
            await store.write_tuple(rt2)

    async def test_delete_tuple(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_relationship import (
            AsyncSQLAlchemyRelationshipStore,
        )

        store = AsyncSQLAlchemyRelationshipStore(async_engine)
        rt = RelationTuple(
            tenant_id="t1",
            object_type="doc",
            object_id="d1",
            relation="viewer",
            subject_type="user",
            subject_id="u1",
        )
        await store.write_tuple(rt)
        await store.delete_tuple(rt.id, "t1")
        tuples = await store.read_tuples("t1")
        assert len(tuples) == 0

    async def test_find_object_ids_for_subject(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_relationship import (
            AsyncSQLAlchemyRelationshipStore,
        )

        store = AsyncSQLAlchemyRelationshipStore(async_engine)
        for oid in ["d1", "d2", "d3"]:
            await store.write_tuple(
                RelationTuple(
                    tenant_id="t1",
                    object_type="doc",
                    object_id=oid,
                    relation="viewer",
                    subject_type="user",
                    subject_id="u1",
                )
            )
        ids = await store.find_object_ids_for_subject("u1", "user", "doc", "t1")
        assert ids == ["d1", "d2", "d3"]


# -----------------------------------------------------------------------
# DelegationStore
# -----------------------------------------------------------------------


def _make_delegation(
    tenant_id: str = "t1",
    **overrides: object,
) -> Delegation:
    now = datetime.now(UTC)
    defaults: dict[str, object] = {
        "tenant_id": tenant_id,
        "from_subject_id": "user-1",
        "from_subject_type": ActorType.USER,
        "to_subject_id": "agent-1",
        "to_subject_type": ActorType.AGENT,
        "scopes": [
            DelegationScope(action_match="read", resource_type="doc"),
        ],
        "request_hash": "abc123",
        "created_at": now,
        "created_by": "user-1",
        "status": DelegationStatus.ACTIVE,
    }
    defaults.update(overrides)
    return Delegation(**defaults)  # type: ignore[arg-type]


class TestAsyncSQLDelegationStore:
    async def test_create_and_get(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_delegation import (
            AsyncSQLAlchemyDelegationStore,
        )

        store = AsyncSQLAlchemyDelegationStore(async_engine)
        d = _make_delegation()
        await store.create(d)
        got = await store.get(d.id, "t1")
        assert got is not None
        assert got.id == d.id
        assert got.status == DelegationStatus.ACTIVE

    async def test_find_by_hash(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_delegation import (
            AsyncSQLAlchemyDelegationStore,
        )

        store = AsyncSQLAlchemyDelegationStore(async_engine)
        d = _make_delegation(request_hash="hash42")
        await store.create(d)
        found = await store.find_by_hash("hash42", "t1")
        assert found is not None
        assert found.id == d.id

    async def test_list_active_for_grantee(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_delegation import (
            AsyncSQLAlchemyDelegationStore,
        )

        store = AsyncSQLAlchemyDelegationStore(async_engine)
        d = _make_delegation()
        await store.create(d)
        active = await store.list_active_for_grantee("agent-1", "t1")
        assert len(active) == 1

    async def test_update_status(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_delegation import (
            AsyncSQLAlchemyDelegationStore,
        )

        store = AsyncSQLAlchemyDelegationStore(async_engine)
        d = _make_delegation()
        await store.create(d)
        updated = await store.update_status(d.id, "t1", DelegationStatus.REVOKED)
        assert updated.status == DelegationStatus.REVOKED

    async def test_expire_stale(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_delegation import (
            AsyncSQLAlchemyDelegationStore,
        )

        store = AsyncSQLAlchemyDelegationStore(async_engine)
        past = datetime.now(UTC) - timedelta(hours=1)
        d = _make_delegation(expires_at=past)
        await store.create(d)
        count = await store.expire_stale("t1", datetime.now(UTC))
        assert count == 1
        got = await store.get(d.id, "t1")
        assert got is not None
        assert got.status == DelegationStatus.EXPIRED


# -----------------------------------------------------------------------
# SessionStore
# -----------------------------------------------------------------------


class TestAsyncSQLSessionStore:
    async def test_create_and_get(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_session import (
            AsyncSQLAlchemySessionStore,
        )

        store = AsyncSQLAlchemySessionStore(async_engine)
        s = Session(
            tenant_id="t1",
            subject_id="u1",
            activated_roles=["admin"],
        )
        await store.create(s)
        got = await store.get(s.id, "t1")
        assert got is not None
        assert got.activated_roles == ["admin"]

    async def test_get_active_for_subject(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_session import (
            AsyncSQLAlchemySessionStore,
        )

        store = AsyncSQLAlchemySessionStore(async_engine)
        s = Session(
            tenant_id="t1",
            subject_id="u1",
            activated_roles=["admin"],
        )
        await store.create(s)
        active = await store.get_active_for_subject("u1", "t1")
        assert len(active) == 1

    async def test_update_status(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_session import (
            AsyncSQLAlchemySessionStore,
        )

        store = AsyncSQLAlchemySessionStore(async_engine)
        s = Session(
            tenant_id="t1",
            subject_id="u1",
            activated_roles=["admin"],
        )
        await store.create(s)
        now = datetime.now(UTC)
        updated = await store.update_status(
            s.id, "t1", SessionStatus.DEACTIVATED, deactivated_at=now
        )
        assert updated.status == SessionStatus.DEACTIVATED

    async def test_expire_stale(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_session import (
            AsyncSQLAlchemySessionStore,
        )

        store = AsyncSQLAlchemySessionStore(async_engine)
        past = datetime.now(UTC) - timedelta(hours=1)
        s = Session(
            tenant_id="t1",
            subject_id="u1",
            activated_roles=["admin"],
            expires_at=past,
        )
        await store.create(s)
        count = await store.expire_stale("t1", datetime.now(UTC))
        assert count == 1


# -----------------------------------------------------------------------
# ApprovalStore
# -----------------------------------------------------------------------


def _make_approval_request(
    tenant_id: str = "t1",
    **overrides: object,
) -> ApprovalRequest:
    now = datetime.now(UTC)
    defaults: dict[str, object] = {
        "tenant_id": tenant_id,
        "request_hash": "somehash",
        "subject_id": "u1",
        "action_name": "delete",
        "resource_id": "r1",
        "resource_type": "doc",
        "status": ApprovalStatus.PENDING,
        "requirement": ApprovalRequirement(approvers=["mgr1"]),
        "created_at": now,
    }
    defaults.update(overrides)
    return ApprovalRequest(**defaults)  # type: ignore[arg-type]


class TestAsyncSQLApprovalStore:
    async def test_create_and_get(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_approval import (
            AsyncSQLAlchemyApprovalStore,
        )

        store = AsyncSQLAlchemyApprovalStore(async_engine)
        req = _make_approval_request()
        await store.create(req)
        got = await store.get(req.id, "t1")
        assert got is not None
        assert got.action_name == "delete"

    async def test_find_by_hash(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_approval import (
            AsyncSQLAlchemyApprovalStore,
        )

        store = AsyncSQLAlchemyApprovalStore(async_engine)
        req = _make_approval_request(request_hash="h1")
        await store.create(req)
        found = await store.find_by_hash("h1", "t1")
        assert found is not None

    async def test_duplicate_pending_rejected(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_approval import (
            AsyncSQLAlchemyApprovalStore,
        )
        from open_guard.domain.exceptions import ApprovalError

        store = AsyncSQLAlchemyApprovalStore(async_engine)
        req1 = _make_approval_request(request_hash="dup1")
        await store.create(req1)
        req2 = _make_approval_request(request_hash="dup1")
        with pytest.raises(ApprovalError, match="Pending approval already exists"):
            await store.create(req2)

    async def test_list_pending(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_approval import (
            AsyncSQLAlchemyApprovalStore,
        )

        store = AsyncSQLAlchemyApprovalStore(async_engine)
        req = _make_approval_request()
        await store.create(req)
        pending = await store.list_pending("t1")
        assert len(pending) == 1

    async def test_expire_stale(self, async_engine) -> None:  # type: ignore[no-untyped-def]
        from open_guard.adapters.stores.async_sql_approval import (
            AsyncSQLAlchemyApprovalStore,
        )

        store = AsyncSQLAlchemyApprovalStore(async_engine)
        past = datetime.now(UTC) - timedelta(hours=1)
        req = _make_approval_request(expires_at=past)
        await store.create(req)
        count = await store.expire_stale("t1", datetime.now(UTC))
        assert count == 1
