"""Tests for database schema tooling (Phase 7 — T2)."""
from __future__ import annotations

import pytest
from sqlalchemy import create_engine, inspect

from open_guard.db import create_all_tables, get_ddl

EXPECTED_TABLES = {
    "open_guard_policies",
    "open_guard_tasks",
    "open_guard_relationship_tuples",
    "open_guard_delegations",
    "open_guard_approval_requests",
    "open_guard_sessions",
}


class TestCreateAllTables:
    """create_all_tables() function."""

    def test_creates_all_tables_sqlite(self, tmp_path: object) -> None:
        engine = create_engine(f"sqlite:///{tmp_path}/test.db")
        create_all_tables(engine)
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        assert EXPECTED_TABLES.issubset(tables)

    def test_idempotent(self, tmp_path: object) -> None:
        engine = create_engine(f"sqlite:///{tmp_path}/test.db")
        create_all_tables(engine)
        create_all_tables(engine)  # Should not raise
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        assert EXPECTED_TABLES.issubset(tables)


class TestGetDDL:
    """get_ddl() function."""

    def test_sqlite_ddl(self) -> None:
        ddl = get_ddl(dialect="sqlite")
        assert "CREATE TABLE" in ddl
        for table_name in EXPECTED_TABLES:
            assert table_name in ddl

    def test_postgresql_ddl(self) -> None:
        ddl = get_ddl(dialect="postgresql")
        assert "CREATE TABLE" in ddl
        for table_name in EXPECTED_TABLES:
            assert table_name in ddl

    def test_unsupported_dialect_raises(self) -> None:
        with pytest.raises(ValueError, match="Unsupported dialect"):
            get_ddl(dialect="mysql")

    def test_ddl_contains_indexes(self) -> None:
        ddl = get_ddl(dialect="sqlite")
        # Should contain CREATE TABLE statements at minimum
        assert "CREATE" in ddl
