"""Tests for async in-memory stores (Phase 7 — T8)."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from open_guard.adapters.stores.async_memory import (
    AsyncInMemoryApprovalStore,
    AsyncInMemoryDelegationStore,
    AsyncInMemoryPolicyStore,
    AsyncInMemoryRelationshipStore,
    AsyncInMemorySessionStore,
    AsyncInMemoryTaskStore,
)
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequest,
    ApprovalRequirement,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    RelationTuple,
    Session,
    Task,
    TaskStatus,
)

# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------


class TestAsyncInMemoryPolicyStore:
    @pytest.mark.asyncio
    async def test_add_and_get(self) -> None:
        store = AsyncInMemoryPolicyStore()
        policy = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
            resource_match={},
            conditions={},
            effect="allow",
            priority=0,
        )
        added = await store.add(policy)
        assert added.id is not None
        results = await store.get_by_tenant("t1")
        assert len(results) == 1
        assert results[0].id == added.id

    @pytest.mark.asyncio
    async def test_get_by_tenant_and_type(self) -> None:
        store = AsyncInMemoryPolicyStore()
        p1 = Policy(
            tenant_id="t1", evaluator_type="rbac",
            subject_match={}, action_match="*", resource_match={},
            conditions={}, effect="allow", priority=0,
        )
        p2 = Policy(
            tenant_id="t1", evaluator_type="abac",
            subject_match={}, action_match="*", resource_match={},
            conditions={}, effect="allow", priority=0,
        )
        await store.add(p1)
        await store.add(p2)
        rbac = await store.get_by_tenant_and_type("t1", "rbac")
        assert len(rbac) == 1
        assert rbac[0].evaluator_type == "rbac"

    @pytest.mark.asyncio
    async def test_remove(self) -> None:
        store = AsyncInMemoryPolicyStore()
        policy = Policy(
            tenant_id="t1", evaluator_type="rbac",
            subject_match={}, action_match="*", resource_match={},
            conditions={}, effect="allow", priority=0,
        )
        added = await store.add(policy)
        await store.remove(added.id, "t1")
        results = await store.get_by_tenant("t1")
        assert len(results) == 0


# ---------------------------------------------------------------------------
# Relationship
# ---------------------------------------------------------------------------


class TestAsyncInMemoryRelationshipStore:
    @pytest.mark.asyncio
    async def test_write_and_read(self) -> None:
        store = AsyncInMemoryRelationshipStore()
        rt = RelationTuple(
            tenant_id="t1",
            object_type="document",
            object_id="doc1",
            relation="viewer",
            subject_type="user",
            subject_id="alice",
        )
        written = await store.write_tuple(rt)
        assert written.id is not None

        results = await store.read_tuples("t1", object_type="document")
        assert len(results) == 1
        assert results[0].subject_id == "alice"

    @pytest.mark.asyncio
    async def test_tuple_exists(self) -> None:
        store = AsyncInMemoryRelationshipStore()
        rt = RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="viewer", subject_type="user", subject_id="alice",
        )
        await store.write_tuple(rt)
        assert await store.tuple_exists(
            "t1", "document", "doc1", "viewer", "user", "alice"
        )
        assert not await store.tuple_exists(
            "t1", "document", "doc1", "editor", "user", "alice"
        )

    @pytest.mark.asyncio
    async def test_delete_tuple(self) -> None:
        store = AsyncInMemoryRelationshipStore()
        rt = RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="doc1",
            relation="viewer", subject_type="user", subject_id="alice",
        )
        written = await store.write_tuple(rt)
        await store.delete_tuple(written.id, "t1")
        results = await store.read_tuples("t1")
        assert len(results) == 0

    @pytest.mark.asyncio
    async def test_find_object_ids_for_subject(self) -> None:
        store = AsyncInMemoryRelationshipStore()
        for doc_id in ("doc1", "doc2", "doc3"):
            await store.write_tuple(RelationTuple(
                tenant_id="t1",
                object_type="document", object_id=doc_id,
                relation="viewer", subject_type="user", subject_id="alice",
            ))
        ids = await store.find_object_ids_for_subject(
            "alice", "user", "document", "t1"
        )
        assert ids == ["doc1", "doc2", "doc3"]


# ---------------------------------------------------------------------------
# Delegation
# ---------------------------------------------------------------------------


class TestAsyncInMemoryDelegationStore:
    def _make_delegation(self, **overrides: object) -> Delegation:
        defaults: dict[str, object] = {
            "tenant_id": "t1",
            "from_subject_id": "alice",
            "from_subject_type": ActorType.USER,
            "to_subject_id": "bob",
            "to_subject_type": ActorType.AGENT,
            "scopes": [DelegationScope(
                action_match="read", resource_type="document",
            )],
            "request_hash": "abc123",
            "created_at": datetime.now(UTC),
            "created_by": "alice",
        }
        defaults.update(overrides)
        return Delegation(**defaults)  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_create_and_get(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = self._make_delegation()
        created = await store.create(d)
        assert created.id == d.id
        fetched = await store.get(d.id, "t1")
        assert fetched is not None
        assert fetched.id == d.id

    @pytest.mark.asyncio
    async def test_find_by_hash(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = self._make_delegation(request_hash="unique-hash")
        await store.create(d)
        found = await store.find_by_hash("unique-hash", "t1")
        assert found is not None
        assert found.id == d.id

    @pytest.mark.asyncio
    async def test_list_active_for_grantee(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = self._make_delegation(status=DelegationStatus.ACTIVE)
        await store.create(d)
        results = await store.list_active_for_grantee("bob", "t1")
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_update_status(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = self._make_delegation()
        await store.create(d)
        updated = await store.update_status(d.id, "t1", DelegationStatus.REVOKED)
        assert updated.status == DelegationStatus.REVOKED


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------


class TestAsyncInMemorySessionStore:
    @pytest.mark.asyncio
    async def test_create_and_get(self) -> None:
        store = AsyncInMemorySessionStore()
        session = Session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["admin"],
        )
        created = await store.create(session)
        assert created.id == session.id
        fetched = await store.get(session.id, "t1")
        assert fetched is not None
        assert fetched.subject_id == "alice"

    @pytest.mark.asyncio
    async def test_get_active_for_subject(self) -> None:
        store = AsyncInMemorySessionStore()
        s = Session(
            tenant_id="t1", subject_id="alice", activated_roles=["admin"],
        )
        await store.create(s)
        results = await store.get_active_for_subject("alice", "t1")
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_update_status(self) -> None:
        from open_guard.domain.entities import SessionStatus

        store = AsyncInMemorySessionStore()
        s = Session(
            tenant_id="t1", subject_id="alice", activated_roles=["admin"],
        )
        await store.create(s)
        now = datetime.now(UTC)
        updated = await store.update_status(
            s.id, "t1", SessionStatus.DEACTIVATED, deactivated_at=now
        )
        assert updated.status == SessionStatus.DEACTIVATED
        assert updated.deactivated_at == now


# ---------------------------------------------------------------------------
# Approval
# ---------------------------------------------------------------------------


class TestAsyncInMemoryApprovalStore:
    def _make_request(self, **overrides: object) -> ApprovalRequest:
        now = datetime.now(UTC)
        defaults: dict[str, object] = {
            "tenant_id": "t1",
            "request_hash": "hash123",
            "subject_id": "alice",
            "action_name": "read",
            "resource_id": "doc1",
            "resource_type": "document",
            "requirement": ApprovalRequirement(approvers=["mgr1"]),
            "created_at": now,
        }
        defaults.update(overrides)
        return ApprovalRequest(**defaults)  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_create_and_get(self) -> None:
        store = AsyncInMemoryApprovalStore()
        req = self._make_request()
        created = await store.create(req)
        assert created.id == req.id
        fetched = await store.get(req.id, "t1")
        assert fetched is not None

    @pytest.mark.asyncio
    async def test_find_by_hash(self) -> None:
        store = AsyncInMemoryApprovalStore()
        req = self._make_request(request_hash="unique-hash")
        await store.create(req)
        found = await store.find_by_hash("unique-hash", "t1")
        assert found is not None
        assert found.id == req.id

    @pytest.mark.asyncio
    async def test_list_pending(self) -> None:
        store = AsyncInMemoryApprovalStore()
        req = self._make_request()
        await store.create(req)
        pending = await store.list_pending("t1")
        assert len(pending) == 1

    @pytest.mark.asyncio
    async def test_update(self) -> None:
        from open_guard.domain.entities import ApprovalStatus

        store = AsyncInMemoryApprovalStore()
        req = self._make_request()
        await store.create(req)
        updated_req = req.model_copy(update={"status": ApprovalStatus.APPROVED})
        result = await store.update(updated_req)
        assert result.status == ApprovalStatus.APPROVED


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------


class TestAsyncInMemoryTaskStore:
    def _make_task(self, **overrides: object) -> Task:
        defaults: dict[str, object] = {
            "tenant_id": "t1",
            "actor_id": "agent-1",
            "actor_type": ActorType.AGENT,
            "status": TaskStatus.ACTIVE,
            "created_at": datetime.now(UTC),
        }
        defaults.update(overrides)
        return Task(**defaults)  # type: ignore[arg-type]

    @pytest.mark.asyncio
    async def test_add_and_get(self) -> None:
        store = AsyncInMemoryTaskStore()
        task = self._make_task()
        added = await store.add(task)
        assert added.id == task.id
        fetched = await store.get(task.id, "t1")
        assert fetched is not None
        assert fetched.actor_id == "agent-1"

    @pytest.mark.asyncio
    async def test_get_active_by_actor(self) -> None:
        store = AsyncInMemoryTaskStore()
        task = self._make_task()
        await store.add(task)
        results = await store.get_active_by_actor("agent-1", "t1")
        assert len(results) == 1

    @pytest.mark.asyncio
    async def test_remove(self) -> None:
        store = AsyncInMemoryTaskStore()
        task = self._make_task()
        await store.add(task)
        await store.remove(task.id, "t1")
        fetched = await store.get(task.id, "t1")
        assert fetched is None

    @pytest.mark.asyncio
    async def test_update(self) -> None:
        store = AsyncInMemoryTaskStore()
        task = self._make_task()
        await store.add(task)
        updated_task = task.model_copy(update={"status": TaskStatus.COMPLETED})
        result = await store.update(updated_task)
        assert result.status == TaskStatus.COMPLETED
