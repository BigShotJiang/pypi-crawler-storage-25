# tests/unit/domain/services/test_policy_isolation.py
"""Tests for prompt-injection-resistant policy isolation (Phase 6 — FEAT-010)."""

import pytest

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.services.policy_router import ReadOnlyPolicyView


class TestReadOnlyPolicyView:
    def test_get_by_tenant_returns_policies(self) -> None:
        store = InMemoryPolicyStore()
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]}, action_match="read",
        )
        store.add(policy)
        view = ReadOnlyPolicyView(store)
        policies = view.get_by_tenant("t1")
        assert len(policies) == 1
        assert policies[0].id == "p1"

    def test_get_by_tenant_and_type(self) -> None:
        store = InMemoryPolicyStore()
        store.add(Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            action_match="read",
        ))
        store.add(Policy(
            id="p2", tenant_id="t1", evaluator_type="abac",
            action_match="read",
        ))
        view = ReadOnlyPolicyView(store)
        rbac = view.get_by_tenant_and_type("t1", "rbac")
        assert len(rbac) == 1
        assert rbac[0].id == "p1"

    def test_add_raises_attribute_error(self) -> None:
        store = InMemoryPolicyStore()
        view = ReadOnlyPolicyView(store)
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="rbac",
            action_match="read",
        )
        with pytest.raises(AttributeError, match="read-only"):
            view.add(policy)

    def test_remove_raises_attribute_error(self) -> None:
        store = InMemoryPolicyStore()
        view = ReadOnlyPolicyView(store)
        with pytest.raises(AttributeError, match="read-only"):
            view.remove("p1", "t1")


class TestTaintMarking:
    """Attributes with _trusted=false should be rejected by trusted_only conditions."""

    def setup_method(self) -> None:
        self.evaluator = ABACEvaluator()

    def _request(self, resource_attrs: dict) -> AuthorizationRequest:
        return AuthorizationRequest(
            subject=Subject(id="alice", attributes={"roles": ["editor"]}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc", attributes=resource_attrs),
            tenant_id="t1",
        )

    def test_trusted_only_allows_trusted_attributes(self) -> None:
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.classification": {
                    "op": "eq", "value": "public", "trusted_only": True,
                },
            },
        )
        req = self._request({"classification": "public"})
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_trusted_only_rejects_untrusted_attributes(self) -> None:
        """Attribute with _trusted=false on the resource is rejected."""
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.classification": {
                    "op": "eq", "value": "public", "trusted_only": True,
                },
            },
        )
        req = self._request({
            "classification": "public",
            "_trusted": {"classification": False},
        })
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False

    def test_without_trusted_only_untrusted_still_works(self) -> None:
        """Without trusted_only, untrusted attributes are evaluated normally."""
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "resource.classification": {"op": "eq", "value": "public"},
            },
        )
        req = self._request({
            "classification": "public",
            "_trusted": {"classification": False},
        })
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is True

    def test_trusted_only_with_subject_attributes(self) -> None:
        """Taint works on subject attributes too."""
        policy = Policy(
            id="p1", tenant_id="t1", evaluator_type="abac",
            action_match="read",
            conditions={
                "subject.department": {
                    "op": "eq", "value": "engineering", "trusted_only": True,
                },
            },
        )
        req = AuthorizationRequest(
            subject=Subject(
                id="alice",
                attributes={
                    "department": "engineering",
                    "_trusted": {"department": False},
                },
            ),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )
        result = self.evaluator.evaluate(req, [policy])
        assert result.allowed is False
