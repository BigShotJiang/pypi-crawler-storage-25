"""Tests for PolicyRouter."""

from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Evaluation,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.policy_store import PolicyStorePort
from open_guard.domain.services.policy_router import PolicyRouter


class MockEvaluator(EvaluatorPort):
    """Mock evaluator that returns a fixed result."""

    def __init__(
        self,
        evaluator_type: str,
        allowed: bool,
        reason: str = "",
    ) -> None:
        self._type = evaluator_type
        self._allowed = allowed
        self._reason = reason

    @property
    def evaluator_type(self) -> str:
        return self._type

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        return Evaluation(
            evaluator=self._type,
            allowed=self._allowed,
            reason=self._reason,
            matched_policies=[p.id for p in policies],
        )

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == self._type


class MockPolicyStore(PolicyStorePort):
    """Mock policy store with pre-loaded policies."""

    def __init__(self, policies: list[Policy] | None = None) -> None:
        self._policies = list(policies or [])

    def add(self, policy: Policy) -> Policy:
        self._policies.append(policy)
        return policy

    def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        return [p for p in self._policies if p.tenant_id == tenant_id]

    def get_by_tenant_and_type(
        self, tenant_id: str, evaluator_type: str
    ) -> list[Policy]:
        return [
            p
            for p in self._policies
            if p.tenant_id == tenant_id and p.evaluator_type == evaluator_type
        ]

    def remove(self, policy_id: str, tenant_id: str) -> None:
        self._policies = [
            p
            for p in self._policies
            if not (p.id == policy_id and p.tenant_id == tenant_id)
        ]


def _make_request(tenant_id: str = "tenant-A") -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(id="user-1"),
        action=Action(name="read"),
        resource=Resource(id="doc-1", resource_type="document"),
        tenant_id=tenant_id,
    )


class TestPolicyRouter:
    def test_no_policies_returns_denied(self) -> None:
        store = MockPolicyStore()
        router = PolicyRouter(evaluators=[], policy_store=store)
        decision = router.evaluate(_make_request())
        assert decision.allowed is False
        assert "No policies found" in decision.reason

    def test_no_matching_evaluators_returns_denied(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="tenant-A", evaluator_type="rbac"),
            ]
        )
        # No evaluator registered for "rbac"
        router = PolicyRouter(evaluators=[], policy_store=store)
        decision = router.evaluate(_make_request())
        assert decision.allowed is False
        assert "No evaluators matched" in decision.reason

    def test_single_evaluator_allow(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="tenant-A", evaluator_type="rbac"),
            ]
        )
        evaluator = MockEvaluator("rbac", allowed=True, reason="role matched")
        router = PolicyRouter(evaluators=[evaluator], policy_store=store)
        decision = router.evaluate(_make_request())
        assert decision.allowed is True
        assert "role matched" in decision.reason

    def test_single_evaluator_deny(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="tenant-A", evaluator_type="rbac"),
            ]
        )
        evaluator = MockEvaluator("rbac", allowed=False, reason="no matching role")
        router = PolicyRouter(evaluators=[evaluator], policy_store=store)
        decision = router.evaluate(_make_request())
        assert decision.allowed is False
        assert "no matching role" in decision.reason

    def test_multi_evaluator_one_denies(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="tenant-A", evaluator_type="rbac"),
                Policy(tenant_id="tenant-A", evaluator_type="abac"),
            ]
        )
        rbac = MockEvaluator("rbac", allowed=True, reason="role ok")
        abac = MockEvaluator("abac", allowed=False, reason="attribute mismatch")
        router = PolicyRouter(evaluators=[rbac, abac], policy_store=store)
        decision = router.evaluate(_make_request())
        assert decision.allowed is False
        assert "attribute mismatch" in decision.reason
        assert len(decision.evaluations) == 2

    def test_multi_evaluator_all_allow(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="tenant-A", evaluator_type="rbac"),
                Policy(tenant_id="tenant-A", evaluator_type="abac"),
            ]
        )
        rbac = MockEvaluator("rbac", allowed=True, reason="role ok")
        abac = MockEvaluator("abac", allowed=True, reason="attrs ok")
        router = PolicyRouter(evaluators=[rbac, abac], policy_store=store)
        decision = router.evaluate(_make_request())
        assert decision.allowed is True
        assert len(decision.evaluations) == 2

    def test_tenant_isolation(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="tenant-A", evaluator_type="rbac"),
            ]
        )
        evaluator = MockEvaluator("rbac", allowed=True, reason="role matched")
        router = PolicyRouter(evaluators=[evaluator], policy_store=store)
        # Query tenant-B — should find no policies
        decision = router.evaluate(_make_request(tenant_id="tenant-B"))
        assert decision.allowed is False
        assert "No policies found" in decision.reason

    def test_evaluations_audit_trail(self) -> None:
        store = MockPolicyStore(
            [
                Policy(id="p1", tenant_id="tenant-A", evaluator_type="rbac"),
                Policy(id="p2", tenant_id="tenant-A", evaluator_type="abac"),
            ]
        )
        rbac = MockEvaluator("rbac", allowed=True, reason="ok")
        abac = MockEvaluator("abac", allowed=True, reason="ok")
        router = PolicyRouter(evaluators=[rbac, abac], policy_store=store)
        decision = router.evaluate(_make_request())
        assert len(decision.evaluations) == 2
        assert decision.evaluations[0].evaluator == "rbac"
        assert decision.evaluations[1].evaluator == "abac"
        assert "p1" in decision.evaluations[0].matched_policies
        assert "p2" in decision.evaluations[1].matched_policies

    def test_evaluate_traced_returns_decision_and_trace(self) -> None:
        store = MockPolicyStore(
            [
                Policy(id="p1", tenant_id="tenant-A", evaluator_type="rbac"),
                Policy(id="p2", tenant_id="tenant-A", evaluator_type="abac"),
            ]
        )
        rbac = MockEvaluator("rbac", allowed=True, reason="ok")
        abac = MockEvaluator("abac", allowed=True, reason="ok")
        router = PolicyRouter(evaluators=[rbac, abac], policy_store=store)
        decision, trace = router.evaluate_traced(_make_request())
        assert decision.allowed is True
        assert trace.schema_version == "1.0"
        assert len(trace.evaluator_results) == 2
        assert {t.evaluator for t in trace.evaluator_results} == {"rbac", "abac"}
        assert trace.composition == "all-allow"
        assert len(trace.actor_chain) == 1  # single non-delegated subject
        assert trace.duration_ms >= 0.0

    def test_evaluate_traced_renders_chain(self) -> None:
        from open_guard.domain.entities import ActorType

        user = Subject(id="alice", actor_type=ActorType.USER)
        agent = Subject(
            id="helper", actor_type=ActorType.AGENT, on_behalf_of=user
        )
        store = MockPolicyStore(
            [Policy(id="p1", tenant_id="tenant-A", evaluator_type="rbac")]
        )
        rbac = MockEvaluator("rbac", allowed=True, reason="ok")
        router = PolicyRouter(evaluators=[rbac], policy_store=store)
        req = AuthorizationRequest(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id="tenant-A",
        )
        _, trace = router.evaluate_traced(req)
        assert [s.id for s in trace.actor_chain] == ["helper", "alice"]

    def test_evaluate_traced_deny_composition(self) -> None:
        store = MockPolicyStore(
            [
                Policy(id="p1", tenant_id="tenant-A", evaluator_type="rbac"),
            ]
        )
        rbac = MockEvaluator("rbac", allowed=False, reason="no role")
        router = PolicyRouter(evaluators=[rbac], policy_store=store)
        decision, trace = router.evaluate_traced(_make_request())
        assert decision.allowed is False
        assert trace.composition == "deny-wins"

    def test_evaluate_traced_no_policies(self) -> None:
        store = MockPolicyStore()
        router = PolicyRouter(evaluators=[], policy_store=store)
        decision, trace = router.evaluate_traced(_make_request())
        assert decision.allowed is False
        assert trace.composition == "no-policies"
        assert trace.evaluator_results == []

    def test_evaluator_allows_but_no_matched_policies(self) -> None:
        """Evaluator returns allowed=True but empty matched_policies → denied."""

        class NoMatchEvaluator(EvaluatorPort):
            @property
            def evaluator_type(self) -> str:
                return "custom"

            def evaluate(
                self, request: AuthorizationRequest, policies: list[Policy]
            ) -> Evaluation:
                return Evaluation(
                    evaluator="custom",
                    allowed=True,
                    reason="vacuous allow",
                    matched_policies=[],
                )

            def supports(self, policy: Policy) -> bool:
                return policy.evaluator_type == "custom"

        store = MockPolicyStore(
            [Policy(tenant_id="tenant-A", evaluator_type="custom")]
        )
        router = PolicyRouter(
            evaluators=[NoMatchEvaluator()], policy_store=store
        )
        decision = router.evaluate(_make_request())
        assert decision.allowed is False
        assert "No allow policies matched" in decision.reason
