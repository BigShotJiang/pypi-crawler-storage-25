"""Tests for SelfDelegateOnly built-in default delegate policy (T10)."""

from __future__ import annotations

from datetime import UTC, datetime

import pytest

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    DelegationScope,
    DelegationStatus,
    Subject,
)
from open_guard.domain.exceptions import DelegateNotPermittedError
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockEvaluator, MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _scope() -> DelegationScope:
    return DelegationScope(action_match="read", resource_type="document")


def _user(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.USER)


def _agent(sid: str) -> Subject:
    return Subject(id=sid, actor_type=ActorType.AGENT)


def _guard(
    *,
    default_delegate_policy: str | None = "self_only",
    policy_allowed: bool = True,
) -> tuple[Guard, InMemoryDelegationStore]:
    ds = InMemoryDelegationStore()
    from open_guard.domain.entities import Policy

    store = MockPolicyStore(
        [Policy(tenant_id=TENANT, evaluator_type="rbac")] if policy_allowed else []
    )
    evs = [MockEvaluator("rbac", allowed=policy_allowed)] if policy_allowed else []
    g = Guard(
        policy_store=store,
        evaluators=evs,
        delegation_store=ds,
        clock=lambda: NOW,
        default_delegate_policy=default_delegate_policy,
    )
    return g, ds


class TestSelfDelegateOnly:
    def test_self_delegate_allowed_under_default(self) -> None:
        """caller == from_subject → delegation succeeds under 'self_only' default."""
        guard, _ = _guard(default_delegate_policy="self_only")
        alice = _user("alice")
        bob = _agent("bob")
        d = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )
        assert d.status == DelegationStatus.ACTIVE

    def test_cross_subject_delegation_raises_under_default(self) -> None:
        """caller != from_subject → DelegateNotPermittedError under 'self_only'."""
        guard, _ = _guard(default_delegate_policy="self_only", policy_allowed=False)
        alice = _user("alice")
        bob = _user("bob")
        carol = _agent("carol")
        with pytest.raises(DelegateNotPermittedError):
            guard.delegate(
                caller=alice,
                from_subject=bob,  # alice is delegating BOB's permissions
                to_subject=carol,
                scopes=[_scope()],
                tenant_id=TENANT,
            )

    def test_default_none_blocks_even_self_delegate(self) -> None:
        """default_delegate_policy=None: no built-in allowance, self-delegate raises."""
        guard, _ = _guard(default_delegate_policy=None, policy_allowed=False)
        alice = _user("alice")
        bob = _agent("bob")
        with pytest.raises(DelegateNotPermittedError):
            guard.delegate(
                caller=alice,
                from_subject=alice,  # self-delegate but policy=None
                to_subject=bob,
                scopes=[_scope()],
                tenant_id=TENANT,
            )

    def test_self_only_with_policy_allowed_uses_policy(self) -> None:
        """When policy also allows, delegation proceeds regardless of self/other."""
        guard, _ = _guard(default_delegate_policy="self_only", policy_allowed=True)
        alice = _user("alice")
        bob = _agent("bob")
        # Self-delegate with policy allowed → works
        d = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )
        assert d.status == DelegationStatus.ACTIVE

    def test_default_none_but_policy_allows_delegate(self) -> None:
        """default_delegate_policy=None but guard has explicit delegate policy → OK."""
        guard, _ = _guard(default_delegate_policy=None, policy_allowed=True)
        alice = _user("alice")
        bob = _agent("bob")
        d = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )
        assert d.status == DelegationStatus.ACTIVE
