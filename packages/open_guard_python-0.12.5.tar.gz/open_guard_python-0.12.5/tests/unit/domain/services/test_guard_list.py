"""Tests for Guard.list_authorized — Phase 4 (FEAT-006)."""

from __future__ import annotations

from typing import Any

import pytest

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequirement,
    PermissionRule,
    Policy,
    PolicyEffect,
    RelationTuple,
    Resource,
    Subject,
    TypeDefinition,
)
from open_guard.domain.exceptions import ChainDepthExceededError
from open_guard.domain.ports.candidate_resource import CandidateResourcePort
from open_guard.domain.services.guard import Guard

# --- Fixtures ---------------------------------------------------------------


class InMemoryCandidateSource(CandidateResourcePort):
    def __init__(
        self,
        resources: dict[tuple[str, str], list[Resource]] | None = None,
    ) -> None:
        self._resources: dict[tuple[str, str], list[Resource]] = resources or {}

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._resources.get((tenant_id, resource_type), [])
        if prefilter:
            items = [
                r
                for r in items
                if all(r.attributes.get(k) == v for k, v in prefilter.items())
            ]
        offset = int((cursor or {}).get("offset", 0))
        page = items[offset : offset + limit]
        next_cursor = (
            {"offset": offset + limit} if offset + limit < len(items) else None
        )
        return page, next_cursor


def _doc_typedefs() -> dict[str, TypeDefinition]:
    return {
        "doc": TypeDefinition(
            name="doc",
            relations={"owner": ["user"], "viewer": ["user"]},
            permissions={
                "can_read": PermissionRule(
                    kind="union", relations=["owner", "viewer"]
                ),
            },
        ),
    }


def _rebac_read_policy() -> Policy:
    return Policy(
        tenant_id="t1",
        evaluator_type="rebac",
        action_match="read",
        conditions={
            "object_type": "doc",
            "permission": "can_read",
            "subject_type": "user",
        },
    )


# --- ReBAC-only path --------------------------------------------------------


class TestListAuthorizedReBACOnly:
    def test_rebac_native_enumeration_without_candidate_source(self) -> None:
        """ReBAC tuples alone drive the list; no CandidateResourcePort needed."""
        rel_store = InMemoryRelationshipStore()
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t1", object_type="doc", object_id="1",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t1", object_type="doc", object_id="2",
                relation="viewer", subject_type="user", subject_id="alice",
            )
        )
        policy_store = InMemoryPolicyStore()
        policy_store.add(_rebac_read_policy())
        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=_doc_typedefs(),
                )
            ],
            relationship_store=rel_store,
        )
        result = guard.list_authorized(
            subject=Subject(id="alice"),
            action="read",
            resource_type="doc",
            tenant_id="t1",
        )
        assert result.ids == ["1", "2"]
        assert result.next_cursor is None

    def test_rebac_cross_tenant_isolation(self) -> None:
        rel_store = InMemoryRelationshipStore()
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t1", object_type="doc", object_id="1",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t2", object_type="doc", object_id="2",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        policy_store = InMemoryPolicyStore()
        policy_store.add(_rebac_read_policy())
        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=_doc_typedefs(),
                )
            ],
            relationship_store=rel_store,
        )
        result = guard.list_authorized(
            Subject(id="alice"), "read", "doc", "t1"
        )
        assert result.ids == ["1"]

    def test_empty_when_no_tuples(self) -> None:
        rel_store = InMemoryRelationshipStore()
        policy_store = InMemoryPolicyStore()
        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=_doc_typedefs(),
                )
            ],
            relationship_store=rel_store,
        )
        result = guard.list_authorized(
            Subject(id="alice"), "read", "doc", "t1"
        )
        assert result.ids == []
        assert result.next_cursor is None


# --- Candidate-source path --------------------------------------------------


class TestListAuthorizedWithCandidateSource:
    def test_rbac_filters_via_candidate_source(self) -> None:
        """RBAC grants role editor read access; candidate source provides docs."""
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        candidates = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                    Resource(id="2", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[RBACEvaluator()],
            candidate_source=candidates,
        )
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        result = guard.list_authorized(alice, "read", "doc", "t1")
        assert set(result.ids) == {"1", "2"}

    def test_abac_condition_filters_candidates(self) -> None:
        """ABAC condition on resource attribute filters the candidate pool."""
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="abac",
                action_match="read",
                resource_match={"type": "doc"},
                conditions={
                    "resource.owner": {"op": "eq", "value": "alice"},
                },
            )
        )
        candidates = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "owner": "alice"}),
                    Resource(id="2", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "owner": "bob"}),
                    Resource(id="3", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "owner": "alice"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[ABACEvaluator()],
            candidate_source=candidates,
        )
        alice = Subject(id="alice")
        result = guard.list_authorized(alice, "read", "doc", "t1")
        assert set(result.ids) == {"1", "3"}

    def test_no_candidate_source_returns_empty_for_abac_only(self) -> None:
        """Without a candidate source, ABAC-only policies yield empty."""
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="abac",
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[ABACEvaluator()],
        )
        result = guard.list_authorized(
            Subject(id="alice"), "read", "doc", "t1"
        )
        assert result.ids == []

    def test_prefilter_is_passed_to_candidate_source(self) -> None:
        """prefilter narrows the candidate pool before authorize()."""
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        candidates = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "team": "a"}),
                    Resource(id="2", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "team": "b"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[RBACEvaluator()],
            candidate_source=candidates,
        )
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        result = guard.list_authorized(
            alice, "read", "doc", "t1", prefilter={"team": "a"}
        )
        assert result.ids == ["1"]


# --- Combined ReBAC + candidate source -------------------------------------


class TestListAuthorizedCombined:
    def test_rebac_tuples_feed_candidate_pool_dedupe(self) -> None:
        """ReBAC tuples provide the same ID the candidate source does — dedupe.

        Open-guard's Guard combines evaluators with AND semantics (any
        evaluator denial → deny). For list_authorized this means ReBAC
        tuples act as a candidate source: enumerated IDs flow through
        authorize() where RBAC (or any other model) decides.
        """
        rel_store = InMemoryRelationshipStore()
        # Tuple marks alice as owner — but here we rely on RBAC for authz
        # (no ReBAC policy registered).
        rel_store.write_tuple(
            RelationTuple(
                tenant_id="t1", object_type="doc", object_id="shared",
                relation="owner", subject_type="user", subject_id="alice",
            )
        )
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        candidates = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="shared", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                    Resource(id="other", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[RBACEvaluator()],
            relationship_store=rel_store,
            candidate_source=candidates,
        )
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        result = guard.list_authorized(alice, "read", "doc", "t1")
        # "shared" enumerated by ReBAC store, "other" by candidate source,
        # both authorized by RBAC; "shared" only appears once (dedupe).
        assert sorted(result.ids) == ["other", "shared"]


# --- Deny precedence via authorize() ---------------------------------------


class TestListAuthorizedDenyPrecedence:
    def test_explicit_deny_removes_id_from_result(self) -> None:
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.DENY,
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc", "owner": "bob"},
                priority=10,
            )
        )
        candidates = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "owner": "alice"}),
                    Resource(id="2", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc", "owner": "bob"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[RBACEvaluator()],
            candidate_source=candidates,
        )
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        result = guard.list_authorized(alice, "read", "doc", "t1")
        assert result.ids == ["1"]


# --- Pending approval exclusion ---------------------------------------------


class TestListAuthorizedPendingApprovalExcluded:
    def test_resource_requiring_approval_not_in_list(self) -> None:
        """Pending approval is NOT yet allowed — excluded from list results."""
        policy_store = InMemoryPolicyStore()
        policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="read",
                resource_match={"type": "doc"},
                requires_approval=ApprovalRequirement(approvers=["admin"]),
            )
        )
        candidates = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(id="1", resource_type="doc", tenant_id="t1",
                             attributes={"type": "doc"}),
                ]
            }
        )
        guard = Guard(
            policy_store=policy_store,
            evaluators=[RBACEvaluator()],
            approval_store=InMemoryApprovalStore(),
            candidate_source=candidates,
        )
        alice = Subject(id="alice", attributes={"roles": ["editor"]})
        result = guard.list_authorized(alice, "read", "doc", "t1")
        assert result.ids == []


# --- Chain enforcement ------------------------------------------------------


class TestListAuthorizedChain:
    def test_chain_depth_enforced(self) -> None:
        """Guard.max_chain_depth rejects deep chains at list time too."""
        policy_store = InMemoryPolicyStore()
        guard = Guard(
            policy_store=policy_store, evaluators=[], max_chain_depth=1,
        )
        deep = Subject(
            id="a",
            actor_type=ActorType.AGENT,
            on_behalf_of=Subject(
                id="b",
                actor_type=ActorType.AGENT,
                on_behalf_of=Subject(id="c"),
            ),
        )
        with pytest.raises(ChainDepthExceededError):
            guard.list_authorized(deep, "read", "doc", "t1")


# --- Pagination -------------------------------------------------------------


class TestListAuthorizedPagination:
    def test_cursor_continues_across_calls(self) -> None:
        rel_store = InMemoryRelationshipStore()
        for i in range(5):
            rel_store.write_tuple(
                RelationTuple(
                    tenant_id="t1", object_type="doc", object_id=str(i),
                    relation="owner", subject_type="user", subject_id="alice",
                )
            )
        policy_store = InMemoryPolicyStore()
        policy_store.add(_rebac_read_policy())
        guard = Guard(
            policy_store=policy_store,
            evaluators=[
                ReBACEvaluator(
                    relationship_store=rel_store,
                    type_definitions=_doc_typedefs(),
                )
            ],
            relationship_store=rel_store,
        )
        alice = Subject(id="alice")

        first = guard.list_authorized(alice, "read", "doc", "t1", limit=2)
        assert first.ids == ["0", "1"]
        assert first.has_more() is True

        second = guard.list_authorized(
            alice, "read", "doc", "t1", limit=2, cursor=first.next_cursor,
        )
        assert second.ids == ["2", "3"]

        third = guard.list_authorized(
            alice, "read", "doc", "t1", limit=2, cursor=second.next_cursor,
        )
        assert third.ids == ["4"]
        assert third.has_more() is False

    def test_limit_zero_returns_empty(self) -> None:
        policy_store = InMemoryPolicyStore()
        guard = Guard(policy_store=policy_store, evaluators=[])
        result = guard.list_authorized(
            Subject(id="alice"), "read", "doc", "t1", limit=0,
        )
        assert result.ids == []
        assert result.has_more() is False
