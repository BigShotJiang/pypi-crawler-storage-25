"""Tests for DelegationEvaluator — scope matching, re-check, memoization."""

from __future__ import annotations

from datetime import UTC, datetime
from unittest.mock import MagicMock

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    Decision,
    DecisionStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Resource,
    Subject,
)
from open_guard.domain.services.delegation_evaluator import (
    DelegationEvaluator,
)

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _allowed() -> Decision:
    return Decision(status=DecisionStatus.ALLOWED)


def _denied() -> Decision:
    return Decision(status=DecisionStatus.DENIED)


def _subject(sid: str = "alice", actor_type: ActorType = ActorType.USER) -> Subject:
    return Subject(id=sid, actor_type=actor_type)


def _action(name: str = "read") -> Action:
    return Action(name=name)


def _resource(rid: str = "doc-1", rtype: str = "document") -> Resource:
    return Resource(id=rid, resource_type=rtype)


def _scope(
    action: str = "read",
    rtype: str = "document",
    resource_match: dict | None = None,
) -> DelegationScope:
    return DelegationScope(
        action_match=action,
        resource_type=rtype,
        resource_match=resource_match or {},
    )


def _make_delegation(
    *,
    from_id: str = "alice",
    to_id: str = "bob",
    scope: DelegationScope | None = None,
    status: DelegationStatus = DelegationStatus.ACTIVE,
    re_check_on_use: bool = True,
    parent_delegation_id: str | None = None,
) -> Delegation:
    return Delegation(
        tenant_id=TENANT,
        from_subject_id=from_id,
        from_subject_type=ActorType.USER,
        to_subject_id=to_id,
        to_subject_type=ActorType.AGENT,
        scopes=[scope or _scope()],
        status=status,
        re_check_on_use=re_check_on_use,
        parent_delegation_id=parent_delegation_id,
        request_hash=f"hash-{from_id}-{to_id}-{status}",
        created_at=NOW,
        created_by=from_id,
    )


def _make_evaluator(
    guard: object | None = None,
    store: InMemoryDelegationStore | None = None,
) -> tuple[DelegationEvaluator, InMemoryDelegationStore, MagicMock]:
    s = store or InMemoryDelegationStore()
    if guard is None:
        g: MagicMock = MagicMock()
        g.authorize.return_value = _allowed()
    else:
        g = guard  # type: ignore[assignment]
    ev = DelegationEvaluator(delegation_store=s, guard=g)
    return ev, s, g


class TestDelegationEvaluatorMatch:
    def test_no_delegations_returns_not_allowed(self) -> None:
        ev, _, _ = _make_evaluator()
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is False
        assert result.matched_delegation_ids == []

    def test_active_delegation_returns_allowed_with_id(self) -> None:
        ev, store, _ = _make_evaluator()
        d = _make_delegation(to_id="bob", re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is True
        assert d.id in result.matched_delegation_ids

    def test_action_mismatch_not_allowed(self) -> None:
        ev, store, _ = _make_evaluator()
        d = _make_delegation(
            to_id="bob", scope=_scope(action="write"), re_check_on_use=False
        )
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action("read"), _resource(), TENANT)
        assert result.allowed is False

    def test_resource_type_mismatch_not_allowed(self) -> None:
        ev, store, _ = _make_evaluator()
        d = _make_delegation(
            to_id="bob", scope=_scope(rtype="tool"), re_check_on_use=False
        )
        store.create(d)
        result = ev.evaluate(
            _subject("bob"), _action(), _resource(rtype="document"), TENANT
        )
        assert result.allowed is False

    def test_scope_resource_match_eq_matches(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "eq", "value": "doc-1"}})
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(rid="doc-1"), TENANT)
        assert result.allowed is True

    def test_scope_resource_match_eq_no_match(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "eq", "value": "doc-1"}})
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(rid="doc-2"), TENANT)
        assert result.allowed is False

    def test_scope_resource_match_in_matches(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "in", "value": ["doc-1", "doc-2"]}})
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(rid="doc-2"), TENANT)
        assert result.allowed is True

    def test_scope_resource_match_in_no_match(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "in", "value": ["doc-1", "doc-2"]}})
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(rid="doc-9"), TENANT)
        assert result.allowed is False

    def test_action_list_match(self) -> None:
        """action_match as list — any match succeeds."""
        ev, store, _ = _make_evaluator()
        scope = DelegationScope(
            action_match=["read", "write"], resource_type="document"
        )
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action("write"), _resource(), TENANT)
        assert result.allowed is True

    def test_revoked_delegation_not_allowed(self) -> None:
        ev, store, _ = _make_evaluator()
        d = _make_delegation(to_id="bob", status=DelegationStatus.REVOKED)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is False

    def test_exhausted_delegation_not_allowed(self) -> None:
        ev, store, _ = _make_evaluator()
        d = _make_delegation(to_id="bob", status=DelegationStatus.EXHAUSTED)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is False

    def test_expired_delegation_not_allowed(self) -> None:
        ev, store, _ = _make_evaluator()
        d = _make_delegation(to_id="bob", status=DelegationStatus.EXPIRED)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is False

    def test_different_subject_not_allowed(self) -> None:
        """Delegation granted to bob does not help carol."""
        ev, store, _ = _make_evaluator()
        d = _make_delegation(to_id="bob", re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("carol"), _action(), _resource(), TENANT)
        assert result.allowed is False


class TestDelegationEvaluatorRecheck:
    def test_recheck_true_grantor_permission_still_valid(self) -> None:
        """re_check_on_use=True + grantor still has perm → allowed."""
        guard = MagicMock()
        guard.authorize.return_value = _allowed()
        ev, store, _ = _make_evaluator(guard=guard)
        d = _make_delegation(to_id="bob", re_check_on_use=True)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is True

    def test_recheck_true_grantor_permission_lost_not_allowed(self) -> None:
        """re_check_on_use=True + grantor lost perm → denied."""
        guard = MagicMock()
        guard.authorize.return_value = _denied()
        ev, store, _ = _make_evaluator(guard=guard)
        d = _make_delegation(to_id="bob", re_check_on_use=True)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is False

    def test_recheck_false_grantor_permission_lost_still_allowed(self) -> None:
        """re_check_on_use=False → no re-check, delegation stands regardless."""
        guard = MagicMock()
        guard.authorize.return_value = _denied()
        ev, store, _ = _make_evaluator(guard=guard)
        d = _make_delegation(to_id="bob", re_check_on_use=False)
        store.create(d)
        result = ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        assert result.allowed is True
        # guard.authorize should NOT have been called for re-check
        guard.authorize.assert_not_called()

    def test_recheck_uses_skip_delegation_flag(self) -> None:
        """Re-check calls guard.authorize with _skip_delegation=True."""
        guard = MagicMock()
        guard.authorize.return_value = _allowed()
        ev, store, _ = _make_evaluator(guard=guard)
        d = _make_delegation(to_id="bob", re_check_on_use=True)
        store.create(d)
        ev.evaluate(_subject("bob"), _action(), _resource(), TENANT)
        _, kwargs = guard.authorize.call_args
        assert kwargs.get("_skip_delegation") is True

    def test_memoization_10_delegations_same_grantor_one_recheck(self) -> None:
        """10 delegations from same grantor → guard.authorize called once."""
        guard = MagicMock()
        guard.authorize.return_value = _allowed()
        ev, store, _ = _make_evaluator(guard=guard)

        for i in range(10):
            d = Delegation(
                tenant_id=TENANT,
                from_subject_id="alice",
                from_subject_type=ActorType.USER,
                to_subject_id="bob",
                to_subject_type=ActorType.AGENT,
                scopes=[_scope()],
                status=DelegationStatus.ACTIVE,
                re_check_on_use=True,
                request_hash=f"hash-{i}",
                created_at=NOW,
                created_by="alice",
            )
            store.create(d)

        recheck_cache: dict = {}
        ev.evaluate(
            _subject("bob"), _action(), _resource(), TENANT, recheck_cache=recheck_cache
        )
        # All 10 delegations share the same (alice, read, doc-1, document) key → 1 call
        assert guard.authorize.call_count == 1

    def test_recheck_cache_prevents_duplicate_calls_across_evaluate(self) -> None:
        """Shared recheck_cache across two evaluate() calls → only 1 guard call."""
        guard = MagicMock()
        guard.authorize.return_value = _allowed()
        ev, store, _ = _make_evaluator(guard=guard)
        d = _make_delegation(to_id="bob", re_check_on_use=True)
        store.create(d)

        cache: dict = {}
        evaluate = lambda: ev.evaluate(  # noqa: E731
            _subject("bob"), _action(), _resource(), TENANT, recheck_cache=cache
        )
        evaluate()
        evaluate()
        assert guard.authorize.call_count == 1


class TestDelegationEvaluatorListContribution:
    def test_eq_scope_emits_concrete_id(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "eq", "value": "doc-42"}})
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        ids = ev.list_contribution(_subject("bob"), TENANT, resource_type="document")
        assert "doc-42" in ids

    def test_in_scope_emits_all_ids(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "in", "value": ["doc-1", "doc-2"]}})
        d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
        store.create(d)
        ids = ev.list_contribution(_subject("bob"), TENANT, resource_type="document")
        assert "doc-1" in ids
        assert "doc-2" in ids

    def test_wildcard_scope_no_resource_match_emits_nothing(self) -> None:
        """Scope with no resource_match constraints → cannot enumerate specific IDs."""
        ev, store, _ = _make_evaluator()
        d = _make_delegation(to_id="bob", scope=_scope(), re_check_on_use=False)
        store.create(d)
        ids = ev.list_contribution(_subject("bob"), TENANT, resource_type="document")
        assert ids == []

    def test_revoked_delegation_contributes_nothing(self) -> None:
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "eq", "value": "doc-1"}})
        d = _make_delegation(to_id="bob", scope=scope, status=DelegationStatus.REVOKED)
        store.create(d)
        ids = ev.list_contribution(_subject("bob"), TENANT, resource_type="document")
        assert ids == []

    def test_deduplication(self) -> None:
        """Two delegations granting same doc-id → appears once."""
        ev, store, _ = _make_evaluator()
        scope = _scope(resource_match={"id": {"op": "eq", "value": "doc-1"}})
        for i in range(2):
            d = _make_delegation(to_id="bob", scope=scope, re_check_on_use=False)
            d = d.model_copy(update={"request_hash": f"h-dedup-{i}"})
            store.create(d)
        ids = ev.list_contribution(_subject("bob"), TENANT, resource_type="document")
        assert ids.count("doc-1") == 1
