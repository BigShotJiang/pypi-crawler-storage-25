"""Tests for Guard with delegation wiring (T8)."""

from __future__ import annotations

from datetime import UTC, datetime
from decimal import Decimal

import pytest

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    DecisionStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockEvaluator, MockPolicyStore

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _subject(sid: str = "alice", actor_type: ActorType = ActorType.USER) -> Subject:
    return Subject(id=sid, actor_type=actor_type)


def _action(name: str = "read") -> Action:
    return Action(name=name)


def _resource(rid: str = "doc-1", rtype: str = "document") -> Resource:
    return Resource(id=rid, resource_type=rtype)


def _scope(action: str = "read", rtype: str = "document") -> DelegationScope:
    return DelegationScope(action_match=action, resource_type=rtype)


def _make_guard_no_delegation(*, allowed: bool = False) -> Guard:
    store = MockPolicyStore(
        [Policy(tenant_id=TENANT, evaluator_type="rbac")] if allowed else []
    )
    evs = [MockEvaluator("rbac", allowed=allowed)] if allowed else []
    return Guard(policy_store=store, evaluators=evs)


def _make_guard_with_delegation(
    *,
    policy_allowed: bool = False,
    delegation_store: InMemoryDelegationStore | None = None,
    max_delegation_depth: int = 10,
) -> tuple[Guard, InMemoryDelegationStore]:
    ds = delegation_store or InMemoryDelegationStore()
    store = MockPolicyStore(
        [Policy(tenant_id=TENANT, evaluator_type="rbac")] if policy_allowed else []
    )
    evs = [MockEvaluator("rbac", allowed=policy_allowed)] if policy_allowed else []
    g = Guard(
        policy_store=store,
        evaluators=evs,
        delegation_store=ds,
        clock=lambda: NOW,
        max_delegation_depth=max_delegation_depth,
    )
    return g, ds


def _make_delegation(
    *,
    from_id: str = "alice",
    to_id: str = "bob",
    max_uses: int | None = None,
    budget: Decimal | None = None,
    re_check_on_use: bool = False,
    status: DelegationStatus = DelegationStatus.ACTIVE,
) -> Delegation:
    return Delegation(
        tenant_id=TENANT,
        from_subject_id=from_id,
        from_subject_type=ActorType.USER,
        to_subject_id=to_id,
        to_subject_type=ActorType.AGENT,
        scopes=[_scope()],
        status=status,
        re_check_on_use=re_check_on_use,
        max_uses=max_uses,
        uses_remaining=max_uses,
        budget=budget,
        budget_remaining=budget,
        request_hash=f"hash-{from_id}-{to_id}",
        created_at=NOW,
        created_by=from_id,
    )


class TestGuardDelegationWiring:
    def test_without_delegation_wiring_behavior_unchanged(self) -> None:
        """Guard constructed without delegation_store → existing behavior preserved."""
        guard = _make_guard_no_delegation(allowed=False)
        decision = guard.authorize(_subject("bob"), _action(), _resource(), TENANT)
        assert decision.status == DecisionStatus.DENIED

    def test_policy_allowed_delegation_evaluator_not_consulted(self) -> None:
        """Policy grants access → delegation path skipped entirely."""
        guard, ds = _make_guard_with_delegation(policy_allowed=True)
        d = _make_delegation(to_id="bob")
        ds.create(d)

        decision = guard.authorize(_subject("bob"), _action(), _resource(), TENANT)
        assert decision.status == DecisionStatus.ALLOWED
        # No delegation evaluation entry in the decision
        delegation_evals = [
            e for e in decision.evaluations if e.evaluator == "delegation"
        ]
        assert delegation_evals == []

    def test_policy_denied_delegation_allowed_returns_allowed(self) -> None:
        """Policy denies, active delegation exists → decision ALLOWED via delegation."""
        guard, ds = _make_guard_with_delegation(policy_allowed=False)
        d = _make_delegation(to_id="bob")
        ds.create(d)

        decision = guard.authorize(_subject("bob"), _action(), _resource(), TENANT)
        assert decision.status == DecisionStatus.ALLOWED
        delegation_evals = [
            e for e in decision.evaluations if e.evaluator == "delegation"
        ]
        assert len(delegation_evals) == 1
        assert d.id in delegation_evals[0].matched_policies

    def test_policy_denied_delegation_denied_returns_denied(self) -> None:
        """Policy denies, no active delegation → DENIED."""
        guard, _ = _make_guard_with_delegation(policy_allowed=False)
        decision = guard.authorize(_subject("bob"), _action(), _resource(), TENANT)
        assert decision.status == DecisionStatus.DENIED

    def test_skip_delegation_flag_bypasses_delegation(self) -> None:
        """_skip_delegation=True prevents delegation evaluation even when it exists."""
        guard, ds = _make_guard_with_delegation(policy_allowed=False)
        d = _make_delegation(to_id="bob")
        ds.create(d)

        decision = guard.authorize(
            _subject("bob"), _action(), _resource(), TENANT, _skip_delegation=True
        )
        assert decision.status == DecisionStatus.DENIED


class TestGuardDelegateProxy:
    def test_delegate_creates_active_delegation(self) -> None:
        """Guard.delegate proxies to DelegationManager and returns ACTIVE delegation."""
        guard, _ds = _make_guard_with_delegation(policy_allowed=True)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )
        assert d.status == DelegationStatus.ACTIVE
        assert d.to_subject_id == "bob"

    def test_delegate_without_wiring_raises(self) -> None:
        """Guard.delegate raises when no delegation_store configured."""
        guard = _make_guard_no_delegation(allowed=True)
        with pytest.raises(RuntimeError, match="delegation_store"):
            guard.delegate(
                caller=_subject("alice"),
                from_subject=_subject("alice"),
                to_subject=_subject("bob", ActorType.AGENT),
                scopes=[_scope()],
                tenant_id=TENANT,
            )

    def test_revoke_delegation_cascades(self) -> None:
        guard, _ds = _make_guard_with_delegation(policy_allowed=True)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        revoked = guard.revoke_delegation(d.id, caller=alice, tenant_id=TENANT)
        assert revoked.status == DelegationStatus.REVOKED

    def test_renew_delegation_updates_heartbeat(self) -> None:
        from datetime import timedelta
        guard, _ds = _make_guard_with_delegation(policy_allowed=True)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = guard.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            lease_ttl=timedelta(seconds=60),
        )
        later = NOW + timedelta(seconds=30)
        renewed = guard.renew_delegation(d.id, caller=bob, tenant_id=TENANT, now=later)
        assert renewed.last_heartbeat_at == later


class TestGuardAuthorizeAndConsume:
    def test_consume_on_delegation_allow(self) -> None:
        """authorize_and_consume decrements uses when access granted via delegation."""
        guard, ds = _make_guard_with_delegation(policy_allowed=False)
        d = _make_delegation(to_id="bob", max_uses=3)
        ds.create(d)

        decision = guard.authorize_and_consume(
            _subject("bob"), _action(), _resource(), TENANT, amount=1
        )
        assert decision.status == DecisionStatus.ALLOWED
        updated = ds.get(d.id, TENANT)
        assert updated is not None
        assert updated.uses_remaining == 2

    def test_no_consume_on_policy_allow(self) -> None:
        """authorize_and_consume does NOT touch delegation when policy grants access."""
        guard, ds = _make_guard_with_delegation(policy_allowed=True)
        d = _make_delegation(to_id="bob", max_uses=3)
        ds.create(d)

        guard.authorize_and_consume(
            _subject("bob"), _action(), _resource(), TENANT, amount=1
        )
        unchanged = ds.get(d.id, TENANT)
        assert unchanged is not None
        assert unchanged.uses_remaining == 3  # untouched

    def test_no_consume_on_denied(self) -> None:
        """authorize_and_consume does NOT consume when access is denied."""
        guard, ds = _make_guard_with_delegation(policy_allowed=False)
        d = _make_delegation(to_id="bob", max_uses=3, status=DelegationStatus.REVOKED)
        ds.create(d)

        decision = guard.authorize_and_consume(
            _subject("bob"), _action(), _resource(), TENANT, amount=1
        )
        assert decision.status == DecisionStatus.DENIED
