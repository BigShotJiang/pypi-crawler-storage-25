"""Tests for ApprovalManager (Phase 3, FEAT-007)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.domain.entities import (
    Action,
    ApprovalRequirement,
    ApprovalStatus,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.services.approval_manager import ApprovalManager


class _Clock:
    """Controllable clock for deterministic tests."""

    def __init__(self, start: datetime) -> None:
        self.now = start

    def advance(self, delta: timedelta) -> None:
        self.now = self.now + delta

    def __call__(self) -> datetime:
        return self.now


def _manager(start: datetime | None = None) -> tuple[ApprovalManager, _Clock]:
    clock = _Clock(start or datetime(2026, 4, 17, 12, 0, 0, tzinfo=UTC))
    store = InMemoryApprovalStore()
    mgr = ApprovalManager(approval_store=store, clock=clock)
    return mgr, clock


def _ctx(
    subject_id: str = "alice",
    action_name: str = "send",
    resource_id: str = "email-1",
    resource_type: str = "email",
) -> tuple[Subject, Action, Resource]:
    return (
        Subject(id=subject_id),
        Action(name=action_name),
        Resource(id=resource_id, resource_type=resource_type),
    )


class TestIdempotency:
    def test_request_or_existing_creates_new(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice"])
        req1 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        assert req1.status == ApprovalStatus.PENDING

    def test_request_or_existing_returns_same(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice"])
        req1 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        req2 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        assert req1.id == req2.id

    def test_request_different_resource_new_request(self) -> None:
        mgr, _ = _manager()
        s, a, r1 = _ctx(resource_id="e1")
        _, _, r2 = _ctx(resource_id="e2")
        req = ApprovalRequirement(approvers=["alice"])
        req1 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r1, requirement=req
        )
        req2 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r2, requirement=req
        )
        assert req1.id != req2.id


class TestApproveReject:
    def test_approve_any_quorum_resolves(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice", "bob"], quorum="any")
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        resolved = mgr.approve(pending.id, "t", "alice", reason="looks good")
        assert resolved.status == ApprovalStatus.APPROVED
        assert len(resolved.approvers_received) == 1

    def test_approve_all_quorum_needs_all(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice", "bob"], quorum="all")
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        mid = mgr.approve(pending.id, "t", "alice")
        assert mid.status == ApprovalStatus.PENDING  # still waiting
        final = mgr.approve(pending.id, "t", "bob")
        assert final.status == ApprovalStatus.APPROVED

    def test_approve_int_quorum(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["a", "b", "c"], quorum=2)
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        mid = mgr.approve(pending.id, "t", "a")
        assert mid.status == ApprovalStatus.PENDING
        final = mgr.approve(pending.id, "t", "b")
        assert final.status == ApprovalStatus.APPROVED

    def test_reject_finalizes_even_if_all_quorum(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice", "bob"], quorum="all")
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        resolved = mgr.reject(pending.id, "t", "bob", reason="no")
        assert resolved.status == ApprovalStatus.REJECTED
        assert resolved.reason == "no"

    def test_approve_unknown_approver_raises(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice"])
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        with pytest.raises(ApprovalError):
            mgr.approve(pending.id, "t", "eve")

    def test_double_vote_same_approver_raises(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["a", "b", "c"], quorum="all")
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        mgr.approve(pending.id, "t", "a")
        with pytest.raises(ApprovalError):
            mgr.approve(pending.id, "t", "a")

    def test_approve_already_resolved_raises(self) -> None:
        mgr, _ = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice"])
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        mgr.approve(pending.id, "t", "alice")
        with pytest.raises(ApprovalError):
            mgr.approve(pending.id, "t", "alice")


class TestTTL:
    def test_pending_expires_after_ttl(self) -> None:
        mgr, clock = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(
            approvers=["alice"], ttl=timedelta(minutes=5)
        )
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        clock.advance(timedelta(minutes=10))
        status = mgr.check_status(pending.id, "t")
        assert status.status == ApprovalStatus.EXPIRED

    def test_expired_pending_does_not_block_new(self) -> None:
        mgr, clock = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(
            approvers=["alice"], ttl=timedelta(minutes=5)
        )
        pending1 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        clock.advance(timedelta(minutes=10))
        # A fresh request after expiry should create a NEW PENDING
        pending2 = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        assert pending2.id != pending1.id
        assert pending2.status == ApprovalStatus.PENDING

    def test_approve_expired_raises(self) -> None:
        mgr, clock = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(
            approvers=["alice"], ttl=timedelta(minutes=5)
        )
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        clock.advance(timedelta(minutes=10))
        with pytest.raises(ApprovalError):
            mgr.approve(pending.id, "t", "alice")

    def test_no_ttl_no_expiry(self) -> None:
        mgr, clock = _manager()
        s, a, r = _ctx()
        req = ApprovalRequirement(approvers=["alice"])
        pending = mgr.request_or_existing(
            tenant_id="t", subject=s, action=a, resource=r, requirement=req
        )
        clock.advance(timedelta(days=365))
        status = mgr.check_status(pending.id, "t")
        assert status.status == ApprovalStatus.PENDING


class TestCheckStatus:
    def test_check_status_unknown_raises(self) -> None:
        mgr, _ = _manager()
        with pytest.raises(ApprovalError):
            mgr.check_status("nope", "t")
