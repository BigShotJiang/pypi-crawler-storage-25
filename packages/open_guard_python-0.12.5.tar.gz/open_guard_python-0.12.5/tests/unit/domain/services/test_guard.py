"""Tests for Guard — the main entry point."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    ApprovalRequirement,
    DecisionStatus,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import (
    ApprovalError,
    ChainDepthExceededError,
)
from open_guard.domain.services.guard import Guard

# Reuse mocks from router tests
from tests.unit.domain.services.test_policy_router import (
    MockEvaluator,
    MockPolicyStore,
)


class TestGuard:
    def test_authorize_allowed(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="t1", evaluator_type="rbac"),
            ]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
        )
        decision = guard.authorize(
            subject=Subject(id="u1"),
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_authorize_denied_no_policies(self) -> None:
        store = MockPolicyStore()
        guard = Guard(policy_store=store, evaluators=[])
        decision = guard.authorize(
            subject=Subject(id="u1"),
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_authorize_with_context(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="t1", evaluator_type="rbac"),
            ]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
        )
        decision = guard.authorize(
            subject=Subject(id="u1"),
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
            context={"ip": "192.168.1.1"},
        )
        assert decision.allowed is True

    def test_authorize_with_agent_subject(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="t1", evaluator_type="rbac"),
            ]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
        )
        decision = guard.authorize(
            subject=Subject(id="agent-1", actor_type=ActorType.AGENT),
            action=Action(name="execute"),
            resource=Resource(id="model-1", resource_type="model"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_policy_store_property(self) -> None:
        store = MockPolicyStore()
        guard = Guard(policy_store=store)
        assert guard.policy_store is store

    def test_default_no_evaluators(self) -> None:
        store = MockPolicyStore(
            [
                Policy(tenant_id="t1", evaluator_type="rbac"),
            ]
        )
        guard = Guard(policy_store=store)
        decision = guard.authorize(
            subject=Subject(id="u1"),
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
        )
        # No evaluators registered → no evaluators match → denied
        assert decision.allowed is False


class _Clock:
    def __init__(self, start: datetime) -> None:
        self.now = start

    def advance(self, delta: timedelta) -> None:
        self.now += delta

    def __call__(self) -> datetime:
        return self.now


class TestGuardChainDepth:
    """Phase 3 — runtime chain-depth enforcement on Guard."""

    def test_chain_within_limit_ok(self) -> None:
        store = MockPolicyStore(
            [Policy(id="p1", tenant_id="t1", evaluator_type="rbac")]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
            max_chain_depth=3,
        )
        user = Subject(id="alice")
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        decision = guard.authorize(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_chain_exceeds_guard_limit(self) -> None:
        store = MockPolicyStore()
        guard = Guard(
            policy_store=store,
            evaluators=[],
            max_chain_depth=1,
        )
        user = Subject(id="alice")
        a1 = Subject(id="a1", actor_type=ActorType.AGENT, on_behalf_of=user)
        a2 = Subject(id="a2", actor_type=ActorType.AGENT, on_behalf_of=a1)
        with pytest.raises(ChainDepthExceededError):
            guard.authorize(
                subject=a2,
                action=Action(name="read"),
                resource=Resource(id="d1", resource_type="doc"),
                tenant_id="t1",
            )


class TestGuardAuthorizeTraced:
    """Phase 3 — authorize_traced returns (Decision, DecisionTrace)."""

    def test_traced_returns_both(self) -> None:
        store = MockPolicyStore(
            [Policy(id="p1", tenant_id="t1", evaluator_type="rbac")]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
        )
        decision, trace = guard.authorize_traced(
            subject=Subject(id="u1"),
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
        )
        assert decision.allowed is True
        assert trace.decision_status == DecisionStatus.ALLOWED
        assert len(trace.evaluator_results) == 1

    def test_traced_with_chain_renders_chain(self) -> None:
        store = MockPolicyStore(
            [Policy(id="p1", tenant_id="t1", evaluator_type="rbac")]
        )
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
        )
        user = Subject(id="alice")
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        _, trace = guard.authorize_traced(
            subject=agent,
            action=Action(name="read"),
            resource=Resource(id="d1", resource_type="doc"),
            tenant_id="t1",
        )
        assert [s.id for s in trace.actor_chain] == ["helper", "alice"]


def _approval_policy(
    approvers: list[str] | None = None,
    quorum: int | str = "any",
    ttl: timedelta | None = None,
) -> Policy:
    """Build an allow policy that requires approval."""
    req = ApprovalRequirement(
        approvers=approvers or ["alice"],
        quorum=quorum,
        ttl=ttl,
    )
    return Policy(
        id="p-approval",
        tenant_id="t1",
        evaluator_type="rbac",
        requires_approval=req,
    )


class TestGuardApprovalFlow:
    """Phase 3 — pending_approval flow end-to-end through Guard."""

    def _guard_with_approval(
        self,
        policies: list[Policy],
        clock: _Clock | None = None,
    ) -> tuple[Guard, InMemoryApprovalStore]:
        store = MockPolicyStore(policies)
        approval_store = InMemoryApprovalStore()
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
            approval_store=approval_store,
            clock=clock,
        )
        return guard, approval_store

    def _authz(
        self, guard: Guard, *, subject_id: str = "u1"
    ) -> tuple[Subject, Action, Resource]:
        return (
            Subject(id=subject_id),
            Action(name="send"),
            Resource(id="email-1", resource_type="email"),
        )

    def test_authorize_creates_pending_decision(self) -> None:
        guard, _ = self._guard_with_approval([_approval_policy()])
        s, a, r = self._authz(guard)
        decision = guard.authorize(
            subject=s, action=a, resource=r, tenant_id="t1"
        )
        assert decision.status == DecisionStatus.PENDING_APPROVAL
        assert decision.approval_request_id is not None
        assert decision.allowed is False

    def test_second_authorize_same_pending_id(self) -> None:
        guard, _ = self._guard_with_approval([_approval_policy()])
        s, a, r = self._authz(guard)
        d1 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        d2 = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert d1.approval_request_id == d2.approval_request_id

    def test_approve_then_authorize_returns_allowed(self) -> None:
        guard, _ = self._guard_with_approval([_approval_policy()])
        s, a, r = self._authz(guard)
        pending = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert pending.approval_request_id is not None
        guard.approve(pending.approval_request_id, "t1", "alice")
        final = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert final.status == DecisionStatus.ALLOWED

    def test_reject_then_authorize_returns_denied(self) -> None:
        guard, _ = self._guard_with_approval([_approval_policy()])
        s, a, r = self._authz(guard)
        pending = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert pending.approval_request_id is not None
        guard.reject(pending.approval_request_id, "t1", "alice", reason="nope")
        final = guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")
        assert final.status == DecisionStatus.DENIED
        assert "rejected" in final.reason

    def test_expired_then_authorize_creates_fresh_pending(self) -> None:
        clock = _Clock(datetime(2026, 4, 17, 12, tzinfo=UTC))
        guard, _ = self._guard_with_approval(
            [_approval_policy(ttl=timedelta(minutes=5))], clock=clock
        )
        s, a, r = self._authz(guard)
        pending1 = guard.authorize(
            subject=s, action=a, resource=r, tenant_id="t1"
        )
        clock.advance(timedelta(minutes=10))
        # After expiry, next authorize creates a fresh PENDING (not deny).
        pending2 = guard.authorize(
            subject=s, action=a, resource=r, tenant_id="t1"
        )
        assert pending2.status == DecisionStatus.PENDING_APPROVAL
        assert pending2.approval_request_id != pending1.approval_request_id

    def test_policy_requires_approval_without_store_raises(self) -> None:
        store = MockPolicyStore([_approval_policy()])
        guard = Guard(
            policy_store=store,
            evaluators=[MockEvaluator("rbac", allowed=True, reason="ok")],
            # No approval_store!
        )
        s = Subject(id="u1")
        a = Action(name="send")
        r = Resource(id="email-1", resource_type="email")
        with pytest.raises(ApprovalError):
            guard.authorize(subject=s, action=a, resource=r, tenant_id="t1")

    def test_approve_without_store_raises(self) -> None:
        store = MockPolicyStore()
        guard = Guard(policy_store=store, evaluators=[])
        with pytest.raises(ApprovalError):
            guard.approve("nonexistent", "t1", "alice")

    def test_reject_without_store_raises(self) -> None:
        store = MockPolicyStore()
        guard = Guard(policy_store=store, evaluators=[])
        with pytest.raises(ApprovalError):
            guard.reject("nonexistent", "t1", "alice")

    def test_traced_pending_carries_pending_status(self) -> None:
        guard, _ = self._guard_with_approval([_approval_policy()])
        s, a, r = self._authz(guard)
        decision, trace = guard.authorize_traced(
            subject=s, action=a, resource=r, tenant_id="t1"
        )
        assert decision.status == DecisionStatus.PENDING_APPROVAL
        assert trace.decision_status == DecisionStatus.PENDING_APPROVAL
        assert trace.composition == "pending-approval"
