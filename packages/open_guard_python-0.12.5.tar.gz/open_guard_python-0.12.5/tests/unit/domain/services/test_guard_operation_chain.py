"""Tests: Guard + AsyncGuard operation_chain passthrough (Phase 8, Task 6)."""

from __future__ import annotations

import pytest

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    OperationChainConfig,
    OperationRule,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.services.guard import Guard


class TestGuardOperationChain:
    """Verify Guard passes operation_chain to its PolicyRouter."""

    def _make_guard(
        self, *, operation_chain: OperationChainConfig | None = None
    ) -> Guard:
        store = InMemoryPolicyStore()
        evaluators = [RBACEvaluator(), ABACEvaluator()]
        return Guard(
            policy_store=store,
            evaluators=evaluators,
            operation_chain=operation_chain,
        )

    def test_guard_without_chain(self) -> None:
        """Guard without operation_chain is backward compatible."""
        guard = self._make_guard()
        assert guard._router._operation_chain is None

    def test_guard_with_chain(self) -> None:
        """Guard with operation_chain passes it to PolicyRouter."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
        )
        guard = self._make_guard(operation_chain=chain)
        assert guard._router._operation_chain is chain

    def test_guard_chain_filtering(self) -> None:
        """Guard.authorize() with chain filters evaluators."""
        chain = OperationChainConfig(
            rules=[
                OperationRule(action_pattern="write", evaluators=["rbac"]),
                OperationRule(action_pattern="read", evaluators=["abac"]),
            ],
        )
        store = InMemoryPolicyStore()
        # Add an RBAC policy
        store.add(
            Policy(
                id="rbac-1",
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                subject_match={"roles": ["admin"]},
                action_match="write",
            )
        )
        # Add an ABAC policy
        store.add(
            Policy(
                id="abac-1",
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                conditions={"subject.department": {"op": "eq", "value": "eng"}},
                action_match="write",
            )
        )

        guard = Guard(
            policy_store=store,
            evaluators=[RBACEvaluator(), ABACEvaluator()],
            operation_chain=chain,
        )

        subject = Subject(
            id="u1",
            attributes={"roles": ["admin"], "department": "eng"},
        )
        decision = guard.authorize(
            subject=subject,
            action=Action(name="write"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )

        # Only RBAC should have fired (chain maps "write" → ["rbac"])
        evaluator_names = [e.evaluator for e in decision.evaluations]
        assert evaluator_names == ["rbac"]
        assert decision.allowed


class TestAsyncGuardOperationChain:
    """Verify AsyncGuard passes operation_chain to its AsyncPolicyRouter."""

    def test_async_guard_without_chain(self) -> None:
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore
        from open_guard.domain.services.async_guard import AsyncGuard

        guard = AsyncGuard(
            policy_store=AsyncInMemoryPolicyStore(),
        )
        assert guard._policy_router._operation_chain is None

    def test_async_guard_with_chain(self) -> None:
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore
        from open_guard.domain.services.async_guard import AsyncGuard

        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
        )
        guard = AsyncGuard(
            policy_store=AsyncInMemoryPolicyStore(),
            operation_chain=chain,
        )
        assert guard._policy_router._operation_chain is chain

    @pytest.mark.asyncio
    async def test_async_guard_chain_filtering(self) -> None:
        from open_guard.adapters.evaluators.rbac import RBACEvaluator
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore
        from open_guard.domain.services.async_guard import AsyncGuard

        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
        )
        store = AsyncInMemoryPolicyStore()
        await store.add(
            Policy(
                id="rbac-1",
                tenant_id="t1",
                evaluator_type="rbac",
                effect=PolicyEffect.ALLOW,
                subject_match={"roles": ["admin"]},
                action_match="write",
            )
        )
        await store.add(
            Policy(
                id="abac-1",
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.ALLOW,
                conditions={"subject.department": {"op": "eq", "value": "eng"}},
                action_match="write",
            )
        )

        guard = AsyncGuard(
            policy_store=store,
            evaluators=[RBACEvaluator(), ABACEvaluator()],
            operation_chain=chain,
        )

        subject = Subject(
            id="u1",
            attributes={"roles": ["admin"], "department": "eng"},
        )
        decision = await guard.authorize(
            subject=subject,
            action=Action(name="write"),
            resource=Resource(id="r1", resource_type="doc"),
            tenant_id="t1",
        )

        evaluator_names = [e.evaluator for e in decision.evaluations]
        assert evaluator_names == ["rbac"]
        assert decision.allowed
