"""Tests for SessionManager service (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import SessionStatus, Subject
from open_guard.domain.exceptions import SessionError, SessionNotFoundError
from open_guard.domain.services.session_manager import SessionManager


class TestSessionManager:
    def setup_method(self) -> None:
        self.store = InMemorySessionStore()
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.manager = SessionManager(
            session_store=self.store, clock=lambda: self.now
        )

    def test_create_session_validates_role_subset(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["admin", "editor", "viewer"]},
        )
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor", "viewer"],
        )
        assert session.status == SessionStatus.ACTIVE
        assert session.activated_roles == ["editor", "viewer"]
        assert session.subject_id == "alice"

    def test_create_session_rejects_non_subset_roles(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["editor", "viewer"]},
        )
        with pytest.raises(SessionError, match="not a subset"):
            self.manager.create_session(
                subject=subject,
                tenant_id="t1",
                activated_roles=["admin", "editor"],
            )

    def test_create_session_with_expiry(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["editor"]},
        )
        ttl = timedelta(hours=2)
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            ttl=ttl,
        )
        assert session.expires_at == self.now + ttl

    def test_create_session_with_metadata(self) -> None:
        subject = Subject(
            id="alice",
            attributes={"roles": ["editor"]},
        )
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )
        assert session.metadata["scope"] == "PROJECT"

    def test_deactivate_session(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        deactivated = self.manager.deactivate(session.id, "t1")
        assert deactivated.status == SessionStatus.DEACTIVATED
        assert deactivated.deactivated_at == self.now

    def test_deactivate_not_found_raises(self) -> None:
        with pytest.raises(SessionNotFoundError):
            self.manager.deactivate("nope", "t1")

    def test_deactivate_already_deactivated_raises(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        self.manager.deactivate(session.id, "t1")
        with pytest.raises(SessionError, match="not active"):
            self.manager.deactivate(session.id, "t1")

    def test_expire_stale_sessions(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            ttl=timedelta(hours=-1),  # already expired
        )
        count = self.manager.expire_stale("t1")
        assert count == 1

    def test_get_active_sessions(self) -> None:
        subject = Subject(
            id="alice", attributes={"roles": ["editor", "viewer"]}
        )
        self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            metadata={"scope": "PROJECT"},
        )
        self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["viewer"],
            metadata={"scope": "WORKSPACE"},
        )
        sessions = self.manager.get_active_sessions("alice", "t1")
        assert len(sessions) == 2

    def test_get_session(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        created = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        got = self.manager.get_session(created.id, "t1")
        assert got.id == created.id

    def test_get_session_auto_expires(self) -> None:
        """Getting an expired session returns it as EXPIRED."""
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject,
            tenant_id="t1",
            activated_roles=["editor"],
            ttl=timedelta(hours=1),
        )
        # Advance clock past expiry
        self.now = self.now + timedelta(hours=2)
        got = self.manager.get_session(session.id, "t1")
        assert got.status == SessionStatus.EXPIRED
