"""Tests for PolicyRouter + AsyncPolicyRouter operation_chain integration."""

from __future__ import annotations

import pytest

from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Evaluation,
    OperationChainConfig,
    OperationRule,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore
from open_guard.domain.services.policy_router import PolicyRouter
from open_guard.domain.services.async_policy_router import AsyncPolicyRouter


# ---------------------------------------------------------------------------
# Stub evaluators
# ---------------------------------------------------------------------------


class StubEvaluator(EvaluatorPort):
    def __init__(self, eval_type: str) -> None:
        self._type = eval_type
        self.called = False

    @property
    def evaluator_type(self) -> str:
        return self._type

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == self._type

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        self.called = True
        return Evaluation(
            evaluator=self._type,
            allowed=True,
            reason=f"{self._type} allowed",
            matched_policies=[p.id for p in policies],
        )


class AsyncStubEvaluator(AsyncEvaluatorPort):
    def __init__(self, eval_type: str) -> None:
        self._type = eval_type

    @property
    def evaluator_type(self) -> str:
        return self._type

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == self._type

    async def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        return Evaluation(
            evaluator=self._type,
            allowed=True,
            reason=f"{self._type} allowed",
            matched_policies=[p.id for p in policies],
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

TENANT = "t1"


def _policy(eval_type: str) -> Policy:
    return Policy(
        tenant_id=TENANT,
        evaluator_type=eval_type,
        effect=PolicyEffect.ALLOW,
    )


def _request(action: str = "read") -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(id="user-1", attributes={"roles": ["admin"]}),
        action=Action(name=action),
        resource=Resource(id="res-1", resource_type="document"),
        tenant_id=TENANT,
    )


def _store(*eval_types: str) -> InMemoryPolicyStore:
    store = InMemoryPolicyStore()
    for et in eval_types:
        store.add(_policy(et))
    return store


async def _async_store(*eval_types: str) -> AsyncInMemoryPolicyStore:
    store = AsyncInMemoryPolicyStore()
    for et in eval_types:
        await store.add(_policy(et))
    return store


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestPolicyRouterChain:
    """Operation chain integration for sync PolicyRouter."""

    def test_no_chain_all_evaluators(self) -> None:
        """No operation_chain → all evaluators run (backward compatible)."""
        evaluators = [StubEvaluator("rbac"), StubEvaluator("abac"), StubEvaluator("tbac")]
        router = PolicyRouter(
            evaluators=evaluators,
            policy_store=_store("rbac", "abac", "tbac"),
        )
        decision = router.evaluate(_request())
        assert len(decision.evaluations) == 3
        assert {e.evaluator for e in decision.evaluations} == {"rbac", "abac", "tbac"}

    def test_chain_filters_evaluators(self) -> None:
        """Chain rule matches → only listed evaluators run."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac", "abac"])],
        )
        evaluators = [StubEvaluator("rbac"), StubEvaluator("abac"), StubEvaluator("tbac")]
        router = PolicyRouter(
            evaluators=evaluators,
            policy_store=_store("rbac", "abac", "tbac"),
            operation_chain=chain,
        )
        decision = router.evaluate(_request(action="write"))
        assert len(decision.evaluations) == 2
        assert {e.evaluator for e in decision.evaluations} == {"rbac", "abac"}

    def test_chain_no_match_with_default(self) -> None:
        """Action doesn't match any rule, default_evaluators set → default evaluators run."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
            default_evaluators=["abac"],
        )
        evaluators = [StubEvaluator("rbac"), StubEvaluator("abac"), StubEvaluator("tbac")]
        router = PolicyRouter(
            evaluators=evaluators,
            policy_store=_store("rbac", "abac", "tbac"),
            operation_chain=chain,
        )
        decision = router.evaluate(_request(action="read"))
        assert len(decision.evaluations) == 1
        assert decision.evaluations[0].evaluator == "abac"

    def test_chain_no_match_no_default(self) -> None:
        """Action doesn't match any rule, no default → all evaluators run."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
            default_evaluators=None,
        )
        evaluators = [StubEvaluator("rbac"), StubEvaluator("abac"), StubEvaluator("tbac")]
        router = PolicyRouter(
            evaluators=evaluators,
            policy_store=_store("rbac", "abac", "tbac"),
            operation_chain=chain,
        )
        decision = router.evaluate(_request(action="read"))
        assert len(decision.evaluations) == 3

    def test_chain_excluded_evaluator_skipped(self) -> None:
        """Evaluator NOT in the chain's list is truly skipped."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac"])],
        )
        tbac_eval = StubEvaluator("tbac")
        evaluators = [StubEvaluator("rbac"), tbac_eval]
        router = PolicyRouter(
            evaluators=evaluators,
            policy_store=_store("rbac", "tbac"),
            operation_chain=chain,
        )
        router.evaluate(_request(action="write"))
        assert tbac_eval.called is False

    def test_traced_path_only_active(self) -> None:
        """evaluate_traced() only shows evaluators active for the chain."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac", "abac"])],
        )
        evaluators = [StubEvaluator("rbac"), StubEvaluator("abac"), StubEvaluator("tbac")]
        router = PolicyRouter(
            evaluators=evaluators,
            policy_store=_store("rbac", "abac", "tbac"),
            operation_chain=chain,
        )
        decision, trace = router.evaluate_traced(_request(action="write"))
        assert len(decision.evaluations) == 2
        trace_evaluators = {et.evaluator for et in trace.evaluator_results}
        assert trace_evaluators == {"rbac", "abac"}
        assert "tbac" not in trace_evaluators

    @pytest.mark.asyncio
    async def test_async_router_chain(self) -> None:
        """AsyncPolicyRouter respects operation_chain filtering."""
        chain = OperationChainConfig(
            rules=[OperationRule(action_pattern="write", evaluators=["rbac", "abac"])],
        )
        evaluators: list[EvaluatorPort | AsyncEvaluatorPort] = [
            AsyncStubEvaluator("rbac"),
            AsyncStubEvaluator("abac"),
            AsyncStubEvaluator("tbac"),
        ]
        store = await _async_store("rbac", "abac", "tbac")
        router = AsyncPolicyRouter(
            evaluators=evaluators,
            policy_store=store,
            operation_chain=chain,
        )
        decision = await router.evaluate(_request(action="write"))
        assert len(decision.evaluations) == 2
        assert {e.evaluator for e in decision.evaluations} == {"rbac", "abac"}
