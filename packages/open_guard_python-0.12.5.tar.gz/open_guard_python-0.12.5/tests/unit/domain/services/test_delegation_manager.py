"""Tests for DelegationManager — delegate / revoke / renew / consume / expire."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal
from unittest.mock import MagicMock

import pytest

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    ActorType,
    ApprovalRequirement,
    Decision,
    DecisionStatus,
    DelegationScope,
    DelegationStatus,
    Subject,
)
from open_guard.domain.exceptions import (
    DelegateNotPermittedError,
    DelegationChainDepthExceededError,
    LeaseExpiredError,
    UsageExhaustedError,
)
from open_guard.domain.services.delegation_manager import DelegationManager

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _allowed() -> Decision:
    return Decision(status=DecisionStatus.ALLOWED)


def _denied() -> Decision:
    return Decision(status=DecisionStatus.DENIED)


def _scope(action: str = "read", resource_type: str = "document") -> DelegationScope:
    return DelegationScope(action_match=action, resource_type=resource_type)


def _subject(sid: str = "alice", actor_type: ActorType = ActorType.USER) -> Subject:
    return Subject(id=sid, actor_type=actor_type)


def _make_manager(
    *,
    meta_authz_result: Decision | None = None,
    narrowing_result: Decision | None = None,
    approval_store: object = None,
    max_delegation_depth: int = 10,
    default_delegate_policy: str | None = None,  # None = call guard for meta-authz
) -> tuple[DelegationManager, InMemoryDelegationStore]:
    store = InMemoryDelegationStore()
    guard = MagicMock()
    guard.authorize.return_value = meta_authz_result or _allowed()
    guard._skip_delegation_authorize = narrowing_result or _allowed()

    # _skip_delegation=True → narrowing_result; otherwise meta_authz_result
    def smart_authorize(*args: object, **kwargs: object) -> Decision:
        if kwargs.get("_skip_delegation"):
            return narrowing_result or _allowed()
        return meta_authz_result or _allowed()

    guard.authorize.side_effect = smart_authorize

    mgr = DelegationManager(
        delegation_store=store,
        guard=guard,
        approval_store=approval_store,
        clock=lambda: NOW,
        max_delegation_depth=max_delegation_depth,
        default_delegate_policy=default_delegate_policy,
    )
    return mgr, store


class TestDelegate:
    def test_basic_delegate_creates_active_delegation(self) -> None:
        mgr, store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope()],
            tenant_id=TENANT,
        )
        assert d.status == DelegationStatus.ACTIVE
        assert d.from_subject_id == "alice"
        assert d.to_subject_id == "bob"
        assert d.tenant_id == TENANT
        persisted = store.get(d.id, TENANT)
        assert persisted is not None

    def test_idempotent_create_returns_same_delegation(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        scope = _scope()
        d1 = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id=TENANT,
        )
        d2 = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[scope], tenant_id=TENANT,
        )
        assert d1.id == d2.id
        assert d1.request_hash == d2.request_hash

    def test_meta_authz_denial_raises(self) -> None:
        mgr, _ = _make_manager(meta_authz_result=_denied(), narrowing_result=_allowed())
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        with pytest.raises(
            DelegateNotPermittedError, match="not permitted to delegate"
        ):
            mgr.delegate(
                caller=alice, from_subject=alice, to_subject=bob,
                scopes=[_scope()], tenant_id=TENANT,
            )

    def test_static_narrowing_failure_raises(self) -> None:
        mgr, _ = _make_manager(meta_authz_result=_allowed(), narrowing_result=_denied())
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        with pytest.raises(DelegateNotPermittedError, match="does not have permission"):
            mgr.delegate(
                caller=alice, from_subject=alice, to_subject=bob,
                scopes=[_scope()], tenant_id=TENANT,
            )

    def test_chain_depth_limit_exceeded_raises(self) -> None:
        mgr, _store = _make_manager(max_delegation_depth=2)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        carol = _subject("carol", ActorType.AGENT)
        dave = _subject("dave", ActorType.AGENT)

        d1 = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        d2 = mgr.delegate(
            caller=bob, from_subject=bob, to_subject=carol,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=d1.id,
        )
        with pytest.raises(DelegationChainDepthExceededError):
            mgr.delegate(
                caller=carol, from_subject=carol, to_subject=dave,
                scopes=[_scope()], tenant_id=TENANT,
                parent_delegation_id=d2.id,
            )

    def test_delegate_with_usage_sets_remaining(self) -> None:
        mgr, _ = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT, max_uses=5,
        )
        assert d.max_uses == 5
        assert d.uses_remaining == 5

    def test_delegate_with_budget_sets_remaining(self) -> None:
        mgr, _ = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT, budget=Decimal("10.00"),
        )
        assert d.budget == Decimal("10.00")
        assert d.budget_remaining == Decimal("10.00")

    def test_delegate_with_lease_ttl_sets_heartbeat(self) -> None:
        mgr, _ = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            lease_ttl=timedelta(seconds=30),
        )
        assert d.lease_ttl == timedelta(seconds=30)
        assert d.last_heartbeat_at == NOW  # set at creation

    def test_delegate_requires_approval_creates_pending(self) -> None:
        from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore

        approval_store = InMemoryApprovalStore()
        mgr, _ = _make_manager(approval_store=approval_store)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        req = ApprovalRequirement(approvers=["manager-1"])
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            requires_approval=req,
        )
        assert d.status == DelegationStatus.PENDING_APPROVAL
        assert d.approval_request_id is not None

    def test_on_approval_resolved_transitions_to_active(self) -> None:
        from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore

        approval_store = InMemoryApprovalStore()
        mgr, _ = _make_manager(approval_store=approval_store)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        req = ApprovalRequirement(approvers=["manager-1"])
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            requires_approval=req,
        )
        assert d.approval_request_id is not None
        resolved = mgr.on_approval_resolved(d.approval_request_id, TENANT)
        assert resolved is not None
        assert resolved.status == DelegationStatus.ACTIVE

    def test_on_approval_resolved_with_lease_sets_heartbeat(self) -> None:
        from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore

        approval_store = InMemoryApprovalStore()
        mgr, _ = _make_manager(approval_store=approval_store)
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        req = ApprovalRequirement(approvers=["manager-1"])
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            requires_approval=req,
            lease_ttl=timedelta(seconds=30),
        )
        resolved = mgr.on_approval_resolved(d.approval_request_id, TENANT)  # type: ignore[arg-type]
        assert resolved is not None
        assert resolved.last_heartbeat_at == NOW


class TestRevoke:
    def test_revoke_transitions_to_revoked(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        revoked = mgr.revoke(d.id, caller=alice, tenant_id=TENANT)
        assert revoked.status == DelegationStatus.REVOKED

    def test_revoke_cascades_to_descendants(self) -> None:
        mgr, store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        carol = _subject("carol", ActorType.AGENT)

        d_root = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        d_child = mgr.delegate(
            caller=bob, from_subject=bob, to_subject=carol,
            scopes=[_scope()], tenant_id=TENANT,
            parent_delegation_id=d_root.id,
        )
        mgr.revoke(d_root.id, caller=alice, tenant_id=TENANT)

        child_fetched = store.get(d_child.id, TENANT)
        assert child_fetched is not None
        assert child_fetched.status == DelegationStatus.REVOKED

    def test_revoke_3level_cascade(self) -> None:
        mgr, store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        carol = _subject("carol", ActorType.AGENT)
        dave = _subject("dave", ActorType.AGENT)

        d1 = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
        )
        d2 = mgr.delegate(
            caller=bob, from_subject=bob, to_subject=carol,
            scopes=[_scope()], tenant_id=TENANT, parent_delegation_id=d1.id,
        )
        d3 = mgr.delegate(
            caller=carol, from_subject=carol, to_subject=dave,
            scopes=[_scope()], tenant_id=TENANT, parent_delegation_id=d2.id,
        )

        mgr.revoke(d1.id, caller=alice, tenant_id=TENANT)

        for did in [d1.id, d2.id, d3.id]:
            fetched = store.get(did, TENANT)
            assert fetched is not None
            assert fetched.status == DelegationStatus.REVOKED


class TestRenew:
    def test_renew_updates_heartbeat(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            lease_ttl=timedelta(seconds=30),
        )
        later = NOW + timedelta(seconds=20)
        renewed = mgr.renew(d.id, caller=bob, tenant_id=TENANT, now=later)
        assert renewed.last_heartbeat_at == later

    def test_renew_by_non_renewable_raises(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        carol = _subject("carol", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            lease_ttl=timedelta(seconds=30),
            renewable_by=["bob"],
        )
        with pytest.raises(DelegateNotPermittedError, match="not authorized to renew"):
            mgr.renew(d.id, caller=carol, tenant_id=TENANT)

    def test_renew_expired_delegation_raises(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            expires_at=NOW - timedelta(seconds=1),
        )
        with pytest.raises(LeaseExpiredError):
            mgr.renew(d.id, caller=bob, tenant_id=TENANT)

    def test_renew_does_not_extend_expires_at(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        ceiling = NOW + timedelta(hours=1)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            lease_ttl=timedelta(seconds=30),
            expires_at=ceiling,
        )
        later = NOW + timedelta(seconds=25)
        renewed = mgr.renew(d.id, caller=bob, tenant_id=TENANT, now=later)
        assert renewed.expires_at == ceiling


class TestConsume:
    def test_consume_uses(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT, max_uses=3,
        )
        updated = mgr.consume(d.id, TENANT, amount=1)
        assert updated.uses_remaining == 2

    def test_consume_budget(self) -> None:
        mgr, _store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            budget=Decimal("10.00"),
        )
        updated = mgr.consume(d.id, TENANT, cost=Decimal("2.50"))
        assert updated.budget_remaining == Decimal("7.50")

    def test_consume_both_uses_and_budget(self) -> None:
        mgr, _ = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            max_uses=5, budget=Decimal("10.00"),
        )
        updated = mgr.consume(d.id, TENANT, amount=1, cost=Decimal("1.00"))
        assert updated.uses_remaining == 4
        assert updated.budget_remaining == Decimal("9.00")

    def test_consume_propagates_usage_exhausted(self) -> None:
        mgr, _ = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT, max_uses=1,
        )
        mgr.consume(d.id, TENANT, amount=1)
        with pytest.raises(UsageExhaustedError):
            mgr.consume(d.id, TENANT, amount=1)


class TestExpireStale:
    def test_expire_stale_delegates_to_store(self) -> None:
        mgr, store = _make_manager()
        alice = _subject("alice")
        bob = _subject("bob", ActorType.AGENT)
        d = mgr.delegate(
            caller=alice, from_subject=alice, to_subject=bob,
            scopes=[_scope()], tenant_id=TENANT,
            expires_at=NOW - timedelta(seconds=1),
        )
        count = mgr.expire_stale(TENANT)
        assert count == 1
        fetched = store.get(d.id, TENANT)
        assert fetched is not None
        assert fetched.status == DelegationStatus.EXPIRED
