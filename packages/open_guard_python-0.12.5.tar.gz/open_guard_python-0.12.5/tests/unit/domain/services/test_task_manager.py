"""Tests for TaskManager service."""

from datetime import UTC, datetime

import pytest

from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import ActorType, Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.services.task_manager import TaskManager


def _clock(hour: int = 12, day: int = 16) -> datetime:
    return datetime(2026, 4, day, hour, 0, 0, tzinfo=UTC)


class TestTaskManagerCreate:
    def test_create_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        task = mgr.create_task(
            tenant_id="t1",
            actor_id="agent-1",
        )
        assert task.status == TaskStatus.CREATED
        assert task.tenant_id == "t1"
        assert task.actor_id == "agent-1"
        assert task.actor_type == ActorType.AGENT
        assert task.created_at == _clock()
        assert store.get(task.id, "t1") is not None

    def test_create_task_with_scope(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        task = mgr.create_task(
            tenant_id="t1",
            actor_id="user-1",
            actor_type=ActorType.USER,
            allowed_actions=["read"],
            allowed_resource_types=["document"],
            expires_at=_clock(hour=14),
        )
        assert task.allowed_actions == ["read"]
        assert task.allowed_resource_types == ["document"]
        assert task.expires_at == _clock(hour=14)


class TestTaskManagerActivate:
    def test_activate_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")

        activated = mgr.activate_task(task.id, "t1")
        assert activated.status == TaskStatus.ACTIVE
        assert activated.activated_at == _clock()

    def test_activate_non_created_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")
        mgr.activate_task(task.id, "t1")

        with pytest.raises(TaskError, match="Cannot activate"):
            mgr.activate_task(task.id, "t1")

    def test_activate_nonexistent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        with pytest.raises(TaskError, match="not found"):
            mgr.activate_task("nope", "t1")


class TestTaskManagerComplete:
    def test_complete_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")
        mgr.activate_task(task.id, "t1")

        completed = mgr.complete_task(task.id, "t1")
        assert completed.status == TaskStatus.COMPLETED
        assert completed.completed_at == _clock()

    def test_complete_non_active_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")

        with pytest.raises(TaskError, match="Cannot complete"):
            mgr.complete_task(task.id, "t1")


class TestTaskManagerFail:
    def test_fail_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")
        mgr.activate_task(task.id, "t1")

        failed = mgr.fail_task(task.id, "t1")
        assert failed.status == TaskStatus.FAILED
        assert failed.completed_at == _clock()

    def test_fail_non_active_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")

        with pytest.raises(TaskError, match="Cannot fail"):
            mgr.fail_task(task.id, "t1")


class TestTaskManagerExpiry:
    def test_check_expiry_expires_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock(hour=15))
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="a1",
            status=TaskStatus.ACTIVE,
            created_at=_clock(hour=10),
            activated_at=_clock(hour=10),
            expires_at=_clock(hour=12),
        )
        store.add(task)

        expired = mgr.check_expiry("task-1", "t1")
        assert expired.status == TaskStatus.EXPIRED

    def test_check_expiry_not_expired(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock(hour=11))
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="a1",
            status=TaskStatus.ACTIVE,
            created_at=_clock(hour=10),
            activated_at=_clock(hour=10),
            expires_at=_clock(hour=12),
        )
        store.add(task)

        result = mgr.check_expiry("task-1", "t1")
        assert result.status == TaskStatus.ACTIVE

    def test_check_expiry_no_expires_at(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock(hour=20))
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="a1",
            status=TaskStatus.ACTIVE,
            created_at=_clock(hour=10),
            activated_at=_clock(hour=10),
        )
        store.add(task)

        result = mgr.check_expiry("task-1", "t1")
        assert result.status == TaskStatus.ACTIVE


class TestTaskManagerChildTasks:
    def test_create_child_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read", "write"],
            allowed_resource_types=["document", "image"],
            expires_at=_clock(hour=18),
        )
        mgr.activate_task(parent.id, "t1")

        child = mgr.create_child_task(
            parent_task_id=parent.id,
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
            expires_at=_clock(hour=14),
        )
        assert child.parent_task_id == parent.id
        assert child.allowed_actions == ["read"]
        assert child.allowed_resource_types == ["document"]

    def test_child_actions_exceed_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        mgr.activate_task(parent.id, "t1")

        with pytest.raises(TaskError, match="exceeds parent"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
                allowed_actions=["read", "write"],
                allowed_resource_types=["document"],
            )

    def test_child_resource_types_exceed_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        mgr.activate_task(parent.id, "t1")

        with pytest.raises(TaskError, match="exceeds parent"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
                allowed_actions=["read"],
                allowed_resource_types=["document", "image"],
            )

    def test_child_expiry_exceeds_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            expires_at=_clock(hour=14),
        )
        mgr.activate_task(parent.id, "t1")

        with pytest.raises(TaskError, match="exceeds parent"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
                expires_at=_clock(hour=18),
            )

    def test_child_inherits_wildcard_parent(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(tenant_id="t1", actor_id="a1")  # defaults: ["*"]
        mgr.activate_task(parent.id, "t1")

        child = mgr.create_child_task(
            parent_task_id=parent.id,
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read", "write"],
            allowed_resource_types=["document"],
        )
        assert child.allowed_actions == ["read", "write"]

    def test_child_of_non_active_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(tenant_id="t1", actor_id="a1")
        # Don't activate

        with pytest.raises(TaskError, match="not active"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
            )
