# tests/unit/domain/services/test_revocation_events.py
"""Tests for revocation event emission (Phase 6 — ENH-010)."""

from datetime import UTC, datetime

from open_guard.adapters.stores.memory_revocation import InMemoryRevocationStream
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.domain.entities import (
    RevocationEvent,
    RevocationEventType,
    Subject,
)
from open_guard.domain.services.session_manager import SessionManager


class TestSessionManagerEmitsEvents:
    def setup_method(self) -> None:
        self.session_store = InMemorySessionStore()
        self.stream = InMemoryRevocationStream()
        self.received: list[RevocationEvent] = []
        self.stream.subscribe("t1", self.received.append)
        self.now = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
        self.manager = SessionManager(
            session_store=self.session_store,
            clock=lambda: self.now,
            revocation_stream=self.stream,
        )

    def test_deactivate_emits_session_deactivated(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        self.manager.deactivate(session.id, "t1")
        assert len(self.received) == 1
        assert self.received[0].event_type == RevocationEventType.SESSION_DEACTIVATED
        assert self.received[0].session_id == session.id
        assert self.received[0].subject_id == "alice"

    def test_no_event_on_create(self) -> None:
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        self.manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        assert len(self.received) == 0

    def test_no_stream_no_error(self) -> None:
        """Manager without a stream still works."""
        manager = SessionManager(
            session_store=self.session_store, clock=lambda: self.now
        )
        subject = Subject(id="alice", attributes={"roles": ["editor"]})
        session = manager.create_session(
            subject=subject, tenant_id="t1", activated_roles=["editor"]
        )
        manager.deactivate(session.id, "t1")  # no error
