"""Unit tests for OperationRule and OperationChainConfig entities (Phase 8)."""

from __future__ import annotations

import pytest

from open_guard.domain.entities import OperationChainConfig, OperationRule


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _config(*patterns_and_evals: tuple[str, list[str]], default: list[str] | None = None) -> OperationChainConfig:
    rules = [OperationRule(action_pattern=p, evaluators=e) for p, e in patterns_and_evals]
    return OperationChainConfig(rules=rules, default_evaluators=default)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestOperationRuleBasics:
    def test_exact_match(self) -> None:
        config = _config(("knowledge:write", ["rbac", "abac"]))
        result = config.resolve("knowledge:write")
        assert result == ["rbac", "abac"]

    def test_exact_match_no_false_positive(self) -> None:
        config = _config(("knowledge:write", ["rbac", "abac"]))
        result = config.resolve("knowledge:read")
        assert result is None

    def test_glob_match_star(self) -> None:
        config = _config(("knowledge:*", ["rbac", "tbac"]))
        assert config.resolve("knowledge:write") == ["rbac", "tbac"]
        assert config.resolve("knowledge:read") == ["rbac", "tbac"]
        assert config.resolve("knowledge:delete") == ["rbac", "tbac"]

    def test_glob_no_match_different_namespace(self) -> None:
        config = _config(("knowledge:*", ["rbac"]))
        result = config.resolve("billing:read")
        assert result is None

    def test_wildcard_matches_anything(self) -> None:
        config = _config(("*", ["rbac"]))
        assert config.resolve("knowledge:write") == ["rbac"]
        assert config.resolve("billing:read") == ["rbac"]
        assert config.resolve("anything") == ["rbac"]


class TestFirstMatchWins:
    def test_specific_before_glob(self) -> None:
        config = _config(
            ("knowledge:write", ["rbac", "abac", "tbac"]),
            ("knowledge:*", ["rbac"]),
        )
        assert config.resolve("knowledge:write") == ["rbac", "abac", "tbac"]
        assert config.resolve("knowledge:read") == ["rbac"]

    def test_glob_before_wildcard(self) -> None:
        config = _config(
            ("knowledge:*", ["rbac", "tbac"]),
            ("*", ["rbac"]),
        )
        assert config.resolve("knowledge:write") == ["rbac", "tbac"]
        assert config.resolve("billing:read") == ["rbac"]

    def test_order_matters_reversed(self) -> None:
        # Reversed order — glob wins over specific because it comes first
        config = _config(
            ("knowledge:*", ["rbac"]),
            ("knowledge:write", ["rbac", "abac", "tbac"]),
        )
        # Both match, but glob is first → ["rbac"] wins
        assert config.resolve("knowledge:write") == ["rbac"]


class TestDefaultEvaluators:
    def test_default_evaluators_fallback(self) -> None:
        config = _config(("billing:*", ["rbac"]), default=["rbac", "abac"])
        result = config.resolve("knowledge:write")
        assert result == ["rbac", "abac"]

    def test_no_match_no_default_returns_none(self) -> None:
        config = _config(("billing:*", ["rbac"]))
        result = config.resolve("knowledge:write")
        assert result is None

    def test_empty_rules_uses_default(self) -> None:
        config = OperationChainConfig(rules=[], default_evaluators=["rbac", "tbac"])
        assert config.resolve("anything:at:all") == ["rbac", "tbac"]

    def test_empty_rules_no_default_returns_none(self) -> None:
        config = OperationChainConfig(rules=[], default_evaluators=None)
        assert config.resolve("knowledge:write") is None

    def test_empty_default_list_returns_none(self) -> None:
        # default_evaluators=[] is falsy, should behave like None
        config = OperationChainConfig(rules=[], default_evaluators=[])
        assert config.resolve("knowledge:write") is None


class TestFrozenModel:
    def test_operation_rule_is_frozen(self) -> None:
        rule = OperationRule(action_pattern="knowledge:*", evaluators=["rbac"])
        with pytest.raises((TypeError, Exception)):
            rule.action_pattern = "other:*"  # type: ignore[misc]

    def test_operation_chain_config_is_frozen(self) -> None:
        config = OperationChainConfig(rules=[], default_evaluators=None)
        with pytest.raises((TypeError, Exception)):
            config.default_evaluators = ["rbac"]  # type: ignore[misc]

    def test_resolve_returns_copy_not_original(self) -> None:
        """Mutating the returned list should not affect internal state."""
        config = _config(("knowledge:*", ["rbac", "abac"]))
        result = config.resolve("knowledge:write")
        assert result is not None
        result.append("tbac")
        # Resolve again — should still return original two evaluators
        assert config.resolve("knowledge:write") == ["rbac", "abac"]


class TestEdgeCases:
    def test_single_rule_exact(self) -> None:
        config = _config(("read", ["rbac"]))
        assert config.resolve("read") == ["rbac"]
        assert config.resolve("write") is None

    def test_question_mark_glob(self) -> None:
        # fnmatch supports ? as single-char wildcard
        config = _config(("knowledge:rea?", ["rbac"]))
        assert config.resolve("knowledge:read") == ["rbac"]
        assert config.resolve("knowledge:reads") is None

    def test_multiple_rules_all_miss(self) -> None:
        config = _config(
            ("billing:*", ["rbac"]),
            ("audit:*", ["abac"]),
            default=["rbac", "abac", "tbac"],
        )
        assert config.resolve("knowledge:write") == ["rbac", "abac", "tbac"]
