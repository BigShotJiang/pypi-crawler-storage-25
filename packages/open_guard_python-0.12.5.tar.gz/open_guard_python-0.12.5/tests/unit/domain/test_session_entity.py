# tests/unit/test_session_entity.py
"""Tests for Session entity (Phase 6 — ENH-001)."""

from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from open_guard.domain.entities import Session, SessionStatus


class TestSessionEntity:
    """Session entity construction and validation."""

    def test_create_session_defaults(self) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["editor", "viewer"],
        )
        assert session.tenant_id == "t1"
        assert session.subject_id == "user-1"
        assert session.activated_roles == ["editor", "viewer"]
        assert session.status == SessionStatus.ACTIVE
        assert session.metadata == {}
        assert session.id  # auto-generated UUID

    def test_create_session_with_expiry(self) -> None:
        expires = datetime.now(UTC) + timedelta(hours=1)
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["admin"],
            expires_at=expires,
        )
        assert session.expires_at == expires

    def test_session_frozen(self) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["viewer"],
        )
        with pytest.raises(ValidationError):
            session.status = SessionStatus.DEACTIVATED  # type: ignore[misc]

    def test_session_empty_roles_rejected(self) -> None:
        with pytest.raises(ValidationError):
            Session(
                tenant_id="t1",
                subject_id="user-1",
                activated_roles=[],
            )

    def test_session_metadata(self) -> None:
        session = Session(
            tenant_id="t1",
            subject_id="user-1",
            activated_roles=["viewer"],
            metadata={"scope": "PROJECT"},
        )
        assert session.metadata["scope"] == "PROJECT"


class TestSessionStatus:
    """SessionStatus enum values."""

    def test_status_values(self) -> None:
        assert SessionStatus.ACTIVE.value == "active"
        assert SessionStatus.DEACTIVATED.value == "deactivated"
        assert SessionStatus.EXPIRED.value == "expired"
