"""Tests for Phase 5 delegation exceptions."""

from open_guard.domain.exceptions import (
    DelegateNotPermittedError,
    DelegationChainDepthExceededError,
    DelegationNotFoundError,
    DelegationRevokedError,
    LeaseExpiredError,
    OpenGuardError,
    UsageExhaustedError,
)


class TestPhase5Exceptions:
    def test_delegate_not_permitted_error_is_open_guard_error(self) -> None:
        exc = DelegateNotPermittedError("caller cannot delegate")
        assert isinstance(exc, OpenGuardError)
        assert str(exc) == "caller cannot delegate"

    def test_usage_exhausted_error_is_open_guard_error(self) -> None:
        exc = UsageExhaustedError("no uses remaining")
        assert isinstance(exc, OpenGuardError)
        assert str(exc) == "no uses remaining"

    def test_lease_expired_error_is_open_guard_error(self) -> None:
        exc = LeaseExpiredError("lease has expired")
        assert isinstance(exc, OpenGuardError)
        assert str(exc) == "lease has expired"

    def test_delegation_revoked_error_is_open_guard_error(self) -> None:
        exc = DelegationRevokedError("delegation was revoked")
        assert isinstance(exc, OpenGuardError)
        assert str(exc) == "delegation was revoked"

    def test_delegation_not_found_error_is_open_guard_error(self) -> None:
        exc = DelegationNotFoundError("del-999 not found")
        assert isinstance(exc, OpenGuardError)
        assert str(exc) == "del-999 not found"

    def test_delegation_chain_depth_exceeded_is_open_guard_error(self) -> None:
        exc = DelegationChainDepthExceededError("chain depth 11 exceeds max 10")
        assert isinstance(exc, OpenGuardError)
        assert str(exc) == "chain depth 11 exceeds max 10"

    def test_all_are_exception_subclasses(self) -> None:
        for cls in (
            DelegateNotPermittedError,
            UsageExhaustedError,
            LeaseExpiredError,
            DelegationRevokedError,
            DelegationNotFoundError,
            DelegationChainDepthExceededError,
        ):
            assert issubclass(cls, Exception)

    def test_can_raise_and_catch_by_base(self) -> None:
        import pytest

        with pytest.raises(OpenGuardError):
            raise UsageExhaustedError("exhausted")
