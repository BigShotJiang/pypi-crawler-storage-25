"""Tests for DelegationStorePort abstract interface contract."""

import pytest

from open_guard.domain.ports.delegation_store import DelegationStorePort


class TestDelegationStorePort:
    def test_is_abstract_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError, match="abstract"):
            DelegationStorePort()  # type: ignore[abstract]

    def test_has_required_abstract_methods(self) -> None:
        expected = {
            "create",
            "get",
            "find_by_hash",
            "list_active_for_grantee",
            "list_descendants",
            "update_status",
            "decrement_uses",
            "decrement_budget",
            "touch_heartbeat",
            "expire_stale",
        }
        abstract_methods = getattr(DelegationStorePort, "__abstractmethods__", set())
        assert expected == abstract_methods

    def test_concrete_subclass_must_implement_all_methods(self) -> None:
        class Incomplete(DelegationStorePort):
            pass  # implements nothing

        with pytest.raises(TypeError, match="abstract"):
            Incomplete()  # type: ignore[abstract]
