"""Contract tests for CandidateResourcePort via an in-memory fixture."""

from __future__ import annotations

from typing import Any

import pytest

from open_guard.domain.entities import Resource
from open_guard.domain.ports.candidate_resource import CandidateResourcePort


class InMemoryCandidateSource(CandidateResourcePort):
    """Test fixture — a minimal list-backed CandidateResourcePort.

    Indexed by ``(tenant_id, resource_type)``. Supports offset pagination
    and equality-based prefiltering on resource attributes.
    """

    def __init__(
        self,
        resources: dict[tuple[str, str], list[Resource]] | None = None,
    ) -> None:
        self._resources: dict[tuple[str, str], list[Resource]] = resources or {}

    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._resources.get((tenant_id, resource_type), [])
        if prefilter:
            items = [
                r
                for r in items
                if all(r.attributes.get(k) == v for k, v in prefilter.items())
            ]
        offset = int((cursor or {}).get("offset", 0))
        page = items[offset : offset + limit]
        next_cursor = (
            {"offset": offset + limit} if offset + limit < len(items) else None
        )
        return page, next_cursor


def _mk(resource_type: str, rid: str, tenant: str, **attrs: Any) -> Resource:
    return Resource(
        id=rid, resource_type=resource_type, tenant_id=tenant, attributes=attrs
    )


class TestCandidateResourcePort:
    def test_is_abstract_cannot_be_instantiated(self) -> None:
        with pytest.raises(TypeError):
            CandidateResourcePort()  # type: ignore[abstract]

    def test_fetches_candidates_for_tenant_and_type(self) -> None:
        src = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    _mk("doc", "1", "t1"),
                    _mk("doc", "2", "t1"),
                ],
            }
        )
        page, next_cursor = src.fetch_candidates(
            resource_type="doc",
            tenant_id="t1",
            prefilter=None,
            cursor=None,
            limit=100,
        )
        assert [r.id for r in page] == ["1", "2"]
        assert next_cursor is None

    def test_pagination_via_cursor(self) -> None:
        src = InMemoryCandidateSource(
            {("t1", "doc"): [_mk("doc", str(i), "t1") for i in range(5)]}
        )
        page, cur = src.fetch_candidates("doc", "t1", None, None, 2)
        assert [r.id for r in page] == ["0", "1"]
        assert cur == {"offset": 2}

        page2, cur2 = src.fetch_candidates("doc", "t1", None, cur, 2)
        assert [r.id for r in page2] == ["2", "3"]
        assert cur2 == {"offset": 4}

        page3, cur3 = src.fetch_candidates("doc", "t1", None, cur2, 2)
        assert [r.id for r in page3] == ["4"]
        assert cur3 is None

    def test_prefilter_applied(self) -> None:
        src = InMemoryCandidateSource(
            {
                ("t1", "doc"): [
                    _mk("doc", "1", "t1", owner="alice"),
                    _mk("doc", "2", "t1", owner="bob"),
                    _mk("doc", "3", "t1", owner="alice"),
                ],
            }
        )
        page, _ = src.fetch_candidates("doc", "t1", {"owner": "alice"}, None, 10)
        assert {r.id for r in page} == {"1", "3"}

    def test_cross_tenant_isolation(self) -> None:
        src = InMemoryCandidateSource(
            {
                ("t1", "doc"): [_mk("doc", "1", "t1")],
                ("t2", "doc"): [_mk("doc", "2", "t2")],
            }
        )
        page_t1, _ = src.fetch_candidates("doc", "t1", None, None, 10)
        assert [r.id for r in page_t1] == ["1"]
        page_t2, _ = src.fetch_candidates("doc", "t2", None, None, 10)
        assert [r.id for r in page_t2] == ["2"]

    def test_unknown_type_returns_empty(self) -> None:
        src = InMemoryCandidateSource()
        page, cur = src.fetch_candidates("missing", "t1", None, None, 10)
        assert page == []
        assert cur is None
