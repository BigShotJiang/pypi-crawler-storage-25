"""Tests for domain entities."""

from datetime import UTC, datetime, timedelta

import pytest
from pydantic import ValidationError

from open_guard.domain.entities import (
    Action,
    ActorType,
    ApprovalDecision,
    ApprovalRequest,
    ApprovalRequirement,
    ApprovalStatus,
    AuthorizationRequest,
    ConditionResult,
    Decision,
    DecisionStatus,
    DecisionTrace,
    Evaluation,
    EvaluatorTrace,
    PermissionRule,
    Policy,
    PolicyEffect,
    PolicyMatch,
    RelationMatch,
    RelationTuple,
    Resource,
    Subject,
    SubjectSnapshot,
    Task,
    TaskStatus,
    TypeDefinition,
)
from open_guard.domain.exceptions import ChainDepthExceededError


class TestSubject:
    def test_create_with_defaults(self) -> None:
        subject = Subject(id="user-1")
        assert subject.id == "user-1"
        assert subject.actor_type == ActorType.USER
        assert subject.attributes == {}
        assert subject.metadata == {}

    def test_create_with_all_fields(self) -> None:
        subject = Subject(
            id="agent-42",
            actor_type=ActorType.AGENT,
            attributes={"roles": ["analyst"], "task_id": "task-789"},
            metadata={"source": "jwt"},
        )
        assert subject.actor_type == ActorType.AGENT
        assert subject.attributes["roles"] == ["analyst"]

    def test_immutable(self) -> None:
        subject = Subject(id="user-1")
        with pytest.raises(ValidationError):
            subject.id = "user-2"  # type: ignore[misc]

    def test_all_actor_types(self) -> None:
        for actor_type in ActorType:
            subject = Subject(id="test", actor_type=actor_type)
            assert subject.actor_type == actor_type


class TestSubjectChain:
    """Phase 3 — Subject.on_behalf_of recursive chain (FEAT-005)."""

    def test_no_chain_by_default(self) -> None:
        s = Subject(id="alice")
        assert s.on_behalf_of is None
        assert s.chain_depth == 0

    def test_two_link_chain(self) -> None:
        user = Subject(id="alice", actor_type=ActorType.USER)
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        assert agent.chain_depth == 1
        assert agent.on_behalf_of is not None
        assert agent.on_behalf_of.id == "alice"

    def test_three_link_chain(self) -> None:
        user = Subject(id="alice")
        a1 = Subject(id="agent1", actor_type=ActorType.AGENT, on_behalf_of=user)
        a2 = Subject(id="agent2", actor_type=ActorType.AGENT, on_behalf_of=a1)
        assert a2.chain_depth == 2

    def test_depth_exceeded_raises(self) -> None:
        """Chain with depth > 5 must raise ChainDepthExceededError."""
        # Build a depth-5 chain first (at the limit, allowed)
        s: Subject | None = None
        for i in range(6):
            s = Subject(id=f"a{i}", on_behalf_of=s)
        assert s is not None
        # Adding one more link puts us at depth 6 — should raise
        with pytest.raises(ChainDepthExceededError):
            Subject(id="overflow", on_behalf_of=s)

    def test_depth_at_limit_succeeds(self) -> None:
        """Chain with exactly MAX_CHAIN_DEPTH_DEFAULT=5 links is allowed."""
        s: Subject | None = None
        for i in range(6):  # root + 5 links = depth 5
            s = Subject(id=f"a{i}", on_behalf_of=s)
        assert s is not None
        assert s.chain_depth == 5

    def test_root_actor_single(self) -> None:
        s = Subject(id="alice")
        assert s.root_actor is s

    def test_root_actor_helper(self) -> None:
        user = Subject(id="alice")
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        sub = Subject(id="sub", actor_type=ActorType.AGENT, on_behalf_of=agent)
        assert sub.root_actor.id == "alice"

    def test_ancestors_iter_two_link(self) -> None:
        user = Subject(id="alice")
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        assert [a.id for a in agent.ancestors()] == ["alice"]

    def test_ancestors_iter_three_link(self) -> None:
        user = Subject(id="alice")
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        sub = Subject(id="sub", actor_type=ActorType.AGENT, on_behalf_of=agent)
        assert [a.id for a in sub.ancestors()] == ["helper", "alice"]

    def test_chain_preserves_attributes(self) -> None:
        user = Subject(id="alice", attributes={"trusted": True})
        agent = Subject(id="helper", on_behalf_of=user)
        assert agent.on_behalf_of is not None
        assert agent.on_behalf_of.attributes["trusted"] is True

    def test_subject_is_still_frozen_with_chain(self) -> None:
        user = Subject(id="alice")
        agent = Subject(id="helper", on_behalf_of=user)
        with pytest.raises(ValidationError):
            agent.on_behalf_of = None  # type: ignore[misc]


class TestResource:
    def test_create(self) -> None:
        resource = Resource(id="doc-1", resource_type="document")
        assert resource.id == "doc-1"
        assert resource.resource_type == "document"

    def test_with_attributes(self) -> None:
        resource = Resource(
            id="doc-1",
            resource_type="document",
            attributes={"classification": "confidential", "owner": "user-1"},
        )
        assert resource.attributes["classification"] == "confidential"

    def test_immutable(self) -> None:
        resource = Resource(id="doc-1", resource_type="document")
        with pytest.raises(ValidationError):
            resource.id = "doc-2"  # type: ignore[misc]


class TestAction:
    def test_create(self) -> None:
        action = Action(name="read")
        assert action.name == "read"
        assert action.attributes == {}

    def test_with_attributes(self) -> None:
        action = Action(name="execute", attributes={"timeout": 30})
        assert action.attributes["timeout"] == 30


class TestAuthorizationRequest:
    def test_create(self) -> None:
        request = AuthorizationRequest(
            subject=Subject(id="user-1"),
            action=Action(name="read"),
            resource=Resource(id="doc-1", resource_type="document"),
            tenant_id="tenant-A",
        )
        assert request.subject.id == "user-1"
        assert request.action.name == "read"
        assert request.resource.id == "doc-1"
        assert request.tenant_id == "tenant-A"
        assert request.context == {}

    def test_tenant_id_required(self) -> None:
        with pytest.raises(ValidationError):
            AuthorizationRequest(
                subject=Subject(id="user-1"),
                action=Action(name="read"),
                resource=Resource(id="doc-1", resource_type="document"),
            )  # type: ignore[call-arg]


class TestPolicy:
    def test_create_with_defaults(self) -> None:
        policy = Policy(tenant_id="tenant-A", evaluator_type="rbac")
        assert policy.tenant_id == "tenant-A"
        assert policy.evaluator_type == "rbac"
        assert policy.effect == PolicyEffect.ALLOW
        assert policy.priority == 0
        assert policy.action_match == "*"
        assert policy.id  # auto-generated UUID

    def test_auto_generates_id(self) -> None:
        p1 = Policy(tenant_id="t", evaluator_type="rbac")
        p2 = Policy(tenant_id="t", evaluator_type="rbac")
        assert p1.id != p2.id

    def test_create_with_all_fields(self) -> None:
        policy = Policy(
            id="policy-1",
            tenant_id="tenant-A",
            evaluator_type="abac",
            subject_match={"actor_type": "agent"},
            action_match=["read", "write"],
            resource_match={"resource_type": "document"},
            conditions={"time_after": "09:00"},
            effect=PolicyEffect.DENY,
            priority=10,
        )
        assert policy.id == "policy-1"
        assert policy.effect == PolicyEffect.DENY
        assert policy.priority == 10

    def test_immutable(self) -> None:
        policy = Policy(tenant_id="t", evaluator_type="rbac")
        with pytest.raises(ValidationError):
            policy.effect = PolicyEffect.DENY  # type: ignore[misc]


class TestEvaluation:
    def test_create(self) -> None:
        evaluation = Evaluation(
            evaluator="rbac",
            allowed=True,
            reason="Role 'admin' matched",
            matched_policies=["policy-1"],
        )
        assert evaluation.evaluator == "rbac"
        assert evaluation.allowed is True
        assert evaluation.matched_policies == ["policy-1"]


class TestDecision:
    def test_allowed(self) -> None:
        decision = Decision(
            status=DecisionStatus.ALLOWED,
            reason="All evaluators approved",
            evaluations=[
                Evaluation(evaluator="rbac", allowed=True, reason="role matched"),
            ],
        )
        assert decision.allowed is True
        assert len(decision.evaluations) == 1

    def test_denied(self) -> None:
        decision = Decision(
            status=DecisionStatus.DENIED,
            reason="ABAC denied: classification mismatch",
            evaluations=[
                Evaluation(evaluator="rbac", allowed=True, reason="role matched"),
                Evaluation(
                    evaluator="abac", allowed=False, reason="classification mismatch"
                ),
            ],
        )
        assert decision.allowed is False
        assert len(decision.evaluations) == 2


class TestTaskStatus:
    def test_task_status_values(self) -> None:
        assert TaskStatus.CREATED == "created"
        assert TaskStatus.ACTIVE == "active"
        assert TaskStatus.COMPLETED == "completed"
        assert TaskStatus.FAILED == "failed"
        assert TaskStatus.EXPIRED == "expired"

    def test_task_status_is_str_enum(self) -> None:
        assert isinstance(TaskStatus.CREATED, str)


class TestTask:
    def test_create_task_minimal(self) -> None:
        now = datetime(2026, 4, 16, 12, 0, 0, tzinfo=UTC)
        task = Task(
            tenant_id="t1",
            actor_id="agent-1",
            created_at=now,
        )
        assert task.id  # auto-generated UUID
        assert task.tenant_id == "t1"
        assert task.actor_id == "agent-1"
        assert task.actor_type == ActorType.AGENT
        assert task.status == TaskStatus.CREATED
        assert task.parent_task_id is None
        assert task.allowed_actions == ["*"]
        assert task.allowed_resource_types == ["*"]
        assert task.expires_at is None
        assert task.activated_at is None
        assert task.completed_at is None
        assert task.metadata == {}

    def test_create_task_full(self) -> None:
        now = datetime(2026, 4, 16, 12, 0, 0, tzinfo=UTC)
        later = datetime(2026, 4, 16, 14, 0, 0, tzinfo=UTC)
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="user-1",
            actor_type=ActorType.USER,
            status=TaskStatus.ACTIVE,
            parent_task_id="task-0",
            allowed_actions=["read", "write"],
            allowed_resource_types=["document"],
            created_at=now,
            activated_at=now,
            expires_at=later,
            metadata={"workflow": "review"},
        )
        assert task.id == "task-1"
        assert task.actor_type == ActorType.USER
        assert task.allowed_actions == ["read", "write"]
        assert task.expires_at == later

    def test_task_is_frozen(self) -> None:
        now = datetime(2026, 4, 16, 12, 0, 0, tzinfo=UTC)
        task = Task(tenant_id="t1", actor_id="a1", created_at=now)
        with pytest.raises(ValidationError):
            task.status = TaskStatus.ACTIVE  # type: ignore[misc]


class TestRelationTuple:
    def test_create_direct_relation(self) -> None:
        """document:readme#viewer@user:alice"""
        t = RelationTuple(
            tenant_id="t1",
            object_type="document",
            object_id="readme",
            relation="viewer",
            subject_type="user",
            subject_id="alice",
        )
        assert t.object_type == "document"
        assert t.object_id == "readme"
        assert t.relation == "viewer"
        assert t.subject_type == "user"
        assert t.subject_id == "alice"
        assert t.subject_relation is None
        assert t.id  # auto-generated UUID

    def test_create_subject_set(self) -> None:
        """document:readme#viewer@group:devs#member"""
        t = RelationTuple(
            tenant_id="t1",
            object_type="document",
            object_id="readme",
            relation="viewer",
            subject_type="group",
            subject_id="devs",
            subject_relation="member",
        )
        assert t.subject_relation == "member"

    def test_create_wildcard(self) -> None:
        """document:readme#viewer@user:*"""
        t = RelationTuple(
            tenant_id="t1",
            object_type="document",
            object_id="readme",
            relation="viewer",
            subject_type="user",
            subject_id="*",
        )
        assert t.subject_id == "*"

    def test_relation_tuple_is_frozen(self) -> None:
        t = RelationTuple(
            tenant_id="t1",
            object_type="doc",
            object_id="d1",
            relation="viewer",
            subject_type="user",
            subject_id="alice",
        )
        with pytest.raises(ValidationError):
            t.relation = "editor"  # type: ignore[misc]


class TestTypeDefinition:
    def test_create_type_definition(self) -> None:
        td = TypeDefinition(
            name="document",
            relations={
                "owner": ["user"],
                "editor": ["user", "group#member"],
                "viewer": ["user", "group#member"],
            },
            permissions={
                "can_edit": PermissionRule(
                    kind="union", relations=["owner", "editor"]
                ),
                "can_view": PermissionRule(
                    kind="union", relations=["owner", "editor", "viewer"]
                ),
            },
        )
        assert td.name == "document"
        assert "owner" in td.relations
        assert "can_edit" in td.permissions

    def test_type_definition_is_frozen(self) -> None:
        td = TypeDefinition(name="doc", relations={"owner": ["user"]})
        with pytest.raises(ValidationError):
            td.name = "other"  # type: ignore[misc]


class TestPermissionRule:
    def test_union_permission(self) -> None:
        rule = PermissionRule(kind="union", relations=["editor", "viewer"])
        assert rule.kind == "union"
        assert rule.relations == ["editor", "viewer"]

    def test_intersection_permission(self) -> None:
        rule = PermissionRule(kind="intersection", relations=["viewer", "org_member"])
        assert rule.kind == "intersection"

    def test_exclusion_permission(self) -> None:
        rule = PermissionRule(kind="exclusion", base="viewer", subtract="banned")
        assert rule.base == "viewer"
        assert rule.subtract == "banned"

    def test_arrow_permission(self) -> None:
        rule = PermissionRule(
            kind="arrow", from_relation="parent", to_permission="can_view"
        )
        assert rule.from_relation == "parent"
        assert rule.to_permission == "can_view"

    def test_self_permission(self) -> None:
        rule = PermissionRule(kind="self")
        assert rule.kind == "self"


class TestPolicyMatchAndConditions:
    """Phase 3 — T3 trace detail entities (FEAT-008)."""

    def test_condition_result_shape(self) -> None:
        cr = ConditionResult(
            path="subject.department",
            operator="eq",
            expected="eng",
            actual="eng",
            matched=True,
        )
        assert cr.path == "subject.department"
        assert cr.matched is True

    def test_relation_match_shape(self) -> None:
        rm = RelationMatch(
            object_type="document",
            object_id="doc1",
            relation="viewer",
            subject="user:alice",
        )
        assert rm.path == []

    def test_policy_match_defaults(self) -> None:
        m = PolicyMatch(
            policy_id="p1",
            effect=PolicyEffect.ALLOW,
            matched=True,
            reason="ok",
        )
        assert m.matched_conditions == []
        assert m.matched_relations == []
        assert m.task_scope_ok is None

    def test_policy_match_with_conditions(self) -> None:
        cr = ConditionResult(
            path="subject.dept", operator="eq", expected="eng",
            actual="eng", matched=True,
        )
        m = PolicyMatch(
            policy_id="p1",
            effect=PolicyEffect.ALLOW,
            matched=True,
            matched_conditions=[cr],
        )
        assert m.matched_conditions == [cr]


class TestEvaluationExtensions:
    """Phase 3 — extend Evaluation additively with detail/timing/attrs."""

    def test_evaluation_new_fields_default(self) -> None:
        ev = Evaluation(evaluator="rbac", allowed=True, reason="ok")
        assert ev.matched_policies_detail == []
        assert ev.duration_ms == 0.0
        assert ev.attributes_read == []

    def test_evaluation_legacy_fields_preserved(self) -> None:
        ev = Evaluation(
            evaluator="rbac",
            allowed=False,
            reason="nope",
            matched_policies=["p1", "p2"],
        )
        assert ev.matched_policies == ["p1", "p2"]

    def test_evaluation_with_detail(self) -> None:
        m = PolicyMatch(policy_id="p1", effect=PolicyEffect.ALLOW, matched=True)
        ev = Evaluation(
            evaluator="rbac",
            allowed=True,
            matched_policies_detail=[m],
            duration_ms=1.5,
            attributes_read=["subject.roles"],
        )
        assert ev.matched_policies_detail == [m]
        assert ev.duration_ms == 1.5


class TestDecisionTrace:
    """Phase 3 — T3 DecisionTrace JSON roundtrip and structure."""

    def test_evaluator_trace_shape(self) -> None:
        t = EvaluatorTrace(
            evaluator="rbac",
            status=DecisionStatus.ALLOWED,
            duration_ms=1.5,
        )
        assert t.matched_policies == []
        assert t.rejected_policies == []
        assert t.attributes_read == []

    def test_subject_snapshot(self) -> None:
        ss = SubjectSnapshot(id="alice", actor_type=ActorType.USER)
        assert ss.attributes == {}

    def test_decision_trace_default_schema_version(self) -> None:
        trace = DecisionTrace(
            decision_status=DecisionStatus.ALLOWED,
            timestamp=datetime(2026, 4, 17, tzinfo=UTC),
        )
        assert trace.schema_version == "1.0"

    def test_decision_trace_json_roundtrip(self) -> None:
        ss = SubjectSnapshot(id="alice", actor_type=ActorType.USER)
        et = EvaluatorTrace(
            evaluator="rbac",
            status=DecisionStatus.ALLOWED,
            duration_ms=0.5,
        )
        trace = DecisionTrace(
            decision_status=DecisionStatus.ALLOWED,
            final_reason="ok",
            evaluator_results=[et],
            composition="all-allow",
            actor_chain=[ss],
            duration_ms=2.0,
            timestamp=datetime(2026, 4, 17, tzinfo=UTC),
        )
        js = trace.model_dump_json()
        back = DecisionTrace.model_validate_json(js)
        assert back == trace


class TestApprovalEntities:
    """Phase 3 — T4 approval entities (FEAT-007)."""

    def test_approval_requirement_defaults(self) -> None:
        r = ApprovalRequirement(approvers=["role:manager"])
        assert r.quorum == "any"
        assert r.ttl is None
        assert r.channel is None

    def test_approval_requirement_quorum_all(self) -> None:
        r = ApprovalRequirement(approvers=["a", "b"], quorum="all")
        assert r.quorum == "all"

    def test_approval_requirement_quorum_int(self) -> None:
        r = ApprovalRequirement(approvers=["a", "b", "c"], quorum=2)
        assert r.quorum == 2

    def test_approval_requirement_with_ttl(self) -> None:
        r = ApprovalRequirement(
            approvers=["admin"],
            ttl=timedelta(hours=4),
            channel="slack",
        )
        assert r.ttl == timedelta(hours=4)
        assert r.channel == "slack"

    def test_approval_request_hash_stable(self) -> None:
        h1 = ApprovalRequest.make_hash("t", "alice", "send", "e1", "email")
        h2 = ApprovalRequest.make_hash("t", "alice", "send", "e1", "email")
        assert h1 == h2
        assert len(h1) == 64

    def test_approval_request_hash_differs_on_resource(self) -> None:
        h1 = ApprovalRequest.make_hash("t", "alice", "send", "e1", "email")
        h2 = ApprovalRequest.make_hash("t", "alice", "send", "e2", "email")
        assert h1 != h2

    def test_approval_request_defaults(self) -> None:
        now = datetime(2026, 4, 17, tzinfo=UTC)
        req = ApprovalRequirement(approvers=["mgr"])
        r = ApprovalRequest(
            tenant_id="t",
            request_hash="x" * 64,
            subject_id="alice",
            action_name="send",
            resource_id="e1",
            resource_type="email",
            requirement=req,
            created_at=now,
        )
        assert r.status == ApprovalStatus.PENDING
        assert r.approvers_received == []
        assert r.expires_at is None
        assert r.resolved_at is None
        assert r.reason == ""

    def test_approval_decision_shape(self) -> None:
        now = datetime(2026, 4, 17, tzinfo=UTC)
        d = ApprovalDecision(
            approver="alice",
            decision="approve",
            at=now,
        )
        assert d.reason == ""


class TestPolicyRequiresApproval:
    """Phase 3 — T5 Policy.requires_approval field."""

    def test_requires_approval_defaults_none(self) -> None:
        p = Policy(tenant_id="t", evaluator_type="rbac")
        assert p.requires_approval is None

    def test_policy_with_requires_approval(self) -> None:
        req = ApprovalRequirement(approvers=["role:manager"])
        p = Policy(tenant_id="t", evaluator_type="rbac", requires_approval=req)
        assert p.requires_approval is req


class TestDecisionStatus:
    """Tri-state Decision — status is source of truth, allowed is derived."""

    def test_status_pending_approval_not_allowed(self) -> None:
        d = Decision(status=DecisionStatus.PENDING_APPROVAL, reason="wait")
        assert d.status == DecisionStatus.PENDING_APPROVAL
        assert d.allowed is False

    def test_status_allowed(self) -> None:
        d = Decision(status=DecisionStatus.ALLOWED, reason="ok")
        assert d.allowed is True

    def test_status_denied(self) -> None:
        d = Decision(status=DecisionStatus.DENIED, reason="nope")
        assert d.allowed is False

    def test_default_is_denied(self) -> None:
        d = Decision()
        assert d.status == DecisionStatus.DENIED
        assert d.allowed is False

    def test_approval_request_id_default_none(self) -> None:
        d = Decision(status=DecisionStatus.ALLOWED)
        assert d.approval_request_id is None

    def test_decision_is_frozen(self) -> None:
        d = Decision(status=DecisionStatus.ALLOWED)
        with pytest.raises(ValidationError):
            d.status = DecisionStatus.DENIED  # type: ignore[misc]

    def test_evaluations_field(self) -> None:
        ev = Evaluation(evaluator="rbac", allowed=True, reason="r")
        d = Decision(status=DecisionStatus.ALLOWED, evaluations=[ev])
        assert d.evaluations == [ev]


# --- Phase 4 (FEAT-006): list_authorized pagination entities -----------------


class TestCursor:
    def test_empty_cursor(self) -> None:
        from open_guard.domain.entities import Cursor

        c = Cursor()
        assert c.is_empty() is True
        assert c.rebac_offset == 0
        assert c.candidate_cursor == {}
        assert c.seen_ids == set()

    def test_cursor_roundtrip(self) -> None:
        from open_guard.domain.entities import Cursor

        c = Cursor(
            rebac_offset=50,
            candidate_cursor={"offset": 200, "type": "doc"},
            seen_ids={"a", "b", "c"},
        )
        token = c.encode()
        assert isinstance(token, str)
        decoded = Cursor.decode(token)
        assert decoded.rebac_offset == 50
        assert decoded.candidate_cursor == {"offset": 200, "type": "doc"}
        assert decoded.seen_ids == {"a", "b", "c"}

    def test_cursor_encode_stable_for_equal_payload(self) -> None:
        """Same content → same token (sorted seen_ids)."""
        from open_guard.domain.entities import Cursor

        a = Cursor(rebac_offset=1, seen_ids={"x", "y", "z"})
        b = Cursor(rebac_offset=1, seen_ids={"z", "y", "x"})
        assert a.encode() == b.encode()

    def test_empty_cursor_roundtrip(self) -> None:
        from open_guard.domain.entities import Cursor

        c = Cursor()
        assert Cursor.decode(c.encode()).is_empty()

    def test_decode_invalid_token_raises_value_error(self) -> None:
        from open_guard.domain.entities import Cursor

        with pytest.raises(ValueError, match="invalid cursor token"):
            Cursor.decode("this-is-not-base64-json")

    def test_decode_missing_keys_defaults(self) -> None:
        """Partial payloads are tolerant (forward-compat)."""
        import base64
        import json

        from open_guard.domain.entities import Cursor

        token = base64.urlsafe_b64encode(json.dumps({}).encode()).decode()
        decoded = Cursor.decode(token)
        assert decoded.is_empty() is True


class TestListRequest:
    def test_defaults(self) -> None:
        from open_guard.domain.entities import ListRequest

        r = ListRequest(
            subject_id="u1", action="read", resource_type="doc", tenant_id="t1"
        )
        assert r.limit == 100
        assert r.cursor is None
        assert r.prefilter is None

    def test_with_cursor_and_prefilter(self) -> None:
        from open_guard.domain.entities import Cursor, ListRequest

        cur = Cursor(rebac_offset=10)
        r = ListRequest(
            subject_id="u1",
            action="read",
            resource_type="doc",
            tenant_id="t1",
            prefilter={"owner": "alice"},
            limit=50,
            cursor=cur,
        )
        assert r.limit == 50
        assert r.prefilter == {"owner": "alice"}
        assert r.cursor is cur


class TestListResult:
    def test_has_more_when_cursor_present(self) -> None:
        from open_guard.domain.entities import ListResult

        assert ListResult(ids=["a"], next_cursor="token").has_more() is True

    def test_no_more_when_cursor_absent(self) -> None:
        from open_guard.domain.entities import ListResult

        assert ListResult(ids=["a"], next_cursor=None).has_more() is False

    def test_empty_result(self) -> None:
        from open_guard.domain.entities import ListResult

        r = ListResult(ids=[])
        assert r.ids == []
        assert r.has_more() is False

    def test_frozen(self) -> None:
        from open_guard.domain.entities import ListResult

        r = ListResult(ids=["a"])
        with pytest.raises(ValidationError):
            r.ids = ["b"]  # type: ignore[misc]
