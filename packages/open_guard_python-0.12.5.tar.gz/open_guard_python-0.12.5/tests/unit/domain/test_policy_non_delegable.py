"""Tests for Policy.non_delegable flag (T9)."""

from __future__ import annotations

from datetime import UTC, datetime

from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    AuthorizationRequest,
    DecisionStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Evaluation,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.services.guard import Guard
from tests.unit.domain.services.test_policy_router import MockEvaluator, MockPolicyStore


class SubjectFilteredEvaluator(EvaluatorPort):
    """Evaluator that only allows specific subject IDs."""

    def __init__(self, evaluator_type: str, allowed_subject_ids: set[str]) -> None:
        self._type = evaluator_type
        self._allowed = allowed_subject_ids

    @property
    def evaluator_type(self) -> str:
        return self._type

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        allowed = request.subject.id in self._allowed
        return Evaluation(
            evaluator=self._type,
            allowed=allowed,
            matched_policies=[p.id for p in policies] if allowed else [],
        )

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == self._type

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


class TestPolicyNonDelegableEntity:
    def test_default_non_delegable_is_false(self) -> None:
        p = Policy(tenant_id=TENANT, evaluator_type="rbac")
        assert p.non_delegable is False

    def test_non_delegable_can_be_set_true(self) -> None:
        p = Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=True)
        assert p.non_delegable is True

    def test_non_delegable_roundtrip(self) -> None:
        p = Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=True)
        p2 = Policy.model_validate(p.model_dump())
        assert p2.non_delegable is True

    def test_non_delegable_false_roundtrip(self) -> None:
        p = Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=False)
        p2 = Policy.model_validate(p.model_dump())
        assert p2.non_delegable is False

    def test_non_delegable_does_not_affect_normal_authorize(self) -> None:
        """A non_delegable policy still grants access via normal authorize."""
        store = MockPolicyStore(
            [Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=True)]
        )
        guard = Guard(
            policy_store=store, evaluators=[MockEvaluator("rbac", allowed=True)]
        )
        decision = guard.authorize(
            Subject(id="alice"),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc"),
            TENANT,
        )
        assert decision.allowed is True


class TestNonDelegableDecision:
    def test_skip_delegation_with_non_delegable_policy_marks_decision(self) -> None:
        """_skip_delegation=True marks non_delegable_policy on non-delegable policy."""
        policy = Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=True)
        store = MockPolicyStore([policy])
        guard = Guard(
            policy_store=store, evaluators=[MockEvaluator("rbac", allowed=True)]
        )
        decision = guard.authorize(
            Subject(id="alice"),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc"),
            TENANT,
            _skip_delegation=True,
        )
        assert decision.allowed is True
        assert decision.non_delegable_policy is True

    def test_skip_delegation_delegable_policy_not_marked(self) -> None:
        """_skip_delegation=True with delegable policy → non_delegable_policy=False."""
        policy = Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=False)
        store = MockPolicyStore([policy])
        guard = Guard(
            policy_store=store, evaluators=[MockEvaluator("rbac", allowed=True)]
        )
        decision = guard.authorize(
            Subject(id="alice"),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc"),
            TENANT,
            _skip_delegation=True,
        )
        assert decision.allowed is True
        assert decision.non_delegable_policy is False

    def test_non_delegable_policy_blocks_delegation_recheck(self) -> None:
        """Delegation blocked when grantor's policy is non_delegable."""
        # Policy grants alice "read" but marks it non_delegable
        policy = Policy(tenant_id=TENANT, evaluator_type="rbac", non_delegable=True)
        store = MockPolicyStore([policy])
        ds = InMemoryDelegationStore()
        # alice → ALLOWED directly; bob → DENIED directly (no direct policy for bob)
        guard = Guard(
            policy_store=store,
            evaluators=[SubjectFilteredEvaluator("rbac", {"alice"})],
            delegation_store=ds,
            clock=lambda: NOW,
        )

        delegation = Delegation(
            tenant_id=TENANT,
            from_subject_id="alice",
            from_subject_type=ActorType.USER,
            to_subject_id="bob",
            to_subject_type=ActorType.AGENT,
            scopes=[DelegationScope(action_match="read", resource_type="doc")],
            status=DelegationStatus.ACTIVE,
            re_check_on_use=True,
            request_hash="hash-non-delegable",
            created_at=NOW,
            created_by="alice",
        )
        ds.create(delegation)

        # Bob: no direct policy → DENIED via policy path
        # Delegation: re-check alice → ALLOWED but non_delegable → BLOCKED
        decision = guard.authorize(
            Subject(id="bob", actor_type=ActorType.AGENT),
            Action(name="read"),
            Resource(id="doc-1", resource_type="doc"),
            TENANT,
        )
        assert decision.status == DecisionStatus.DENIED
