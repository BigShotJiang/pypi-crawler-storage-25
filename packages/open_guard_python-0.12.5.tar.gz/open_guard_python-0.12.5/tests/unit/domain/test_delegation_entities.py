"""Tests for Phase 5 delegation entities.

Covers: DelegationScope, Delegation, DelegationStatus.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from decimal import Decimal

import pytest
from pydantic import ValidationError

from open_guard.domain.entities import (
    ActorType,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    PolicyEffect,
)

# ---------------------------------------------------------------------------
# DelegationStatus
# ---------------------------------------------------------------------------


class TestDelegationStatus:
    def test_all_values_exist(self) -> None:
        assert DelegationStatus.PENDING_APPROVAL == "pending_approval"
        assert DelegationStatus.ACTIVE == "active"
        assert DelegationStatus.REVOKED == "revoked"
        assert DelegationStatus.EXPIRED == "expired"
        assert DelegationStatus.EXHAUSTED == "exhausted"

    def test_is_str_enum(self) -> None:
        assert isinstance(DelegationStatus.ACTIVE, str)


# ---------------------------------------------------------------------------
# DelegationScope
# ---------------------------------------------------------------------------


class TestDelegationScope:
    def test_minimal_construction(self) -> None:
        scope = DelegationScope(action_match="read", resource_type="document")
        assert scope.action_match == "read"
        assert scope.resource_type == "document"
        assert scope.resource_match == {}
        assert scope.conditions == {}

    def test_action_match_as_list(self) -> None:
        scope = DelegationScope(
            action_match=["read", "list"],
            resource_type="document",
        )
        assert scope.action_match == ["read", "list"]

    def test_resource_match_and_conditions(self) -> None:
        scope = DelegationScope(
            action_match="write",
            resource_type="document",
            resource_match={"id": {"op": "eq", "value": "doc-1"}},
            conditions={"chain.depth": {"op": "lte", "value": 2}},
        )
        assert scope.resource_match["id"]["op"] == "eq"
        assert scope.conditions["chain.depth"]["value"] == 2

    def test_immutable(self) -> None:
        scope = DelegationScope(action_match="read", resource_type="document")
        with pytest.raises(ValidationError):
            scope.action_match = "write"  # type: ignore[misc]

    def test_from_policy_classmethod(self) -> None:
        policy = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            action_match="read",
            resource_match={"type": "document", "owner": "alice"},
            effect=PolicyEffect.ALLOW,
        )
        scope = DelegationScope.from_policy(policy)
        assert scope.action_match == "read"
        assert scope.resource_type == "document"
        assert "owner" in scope.resource_match
        assert "type" not in scope.resource_match

    def test_from_policy_requires_type_in_resource_match(self) -> None:
        policy = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            action_match="read",
            resource_match={"owner": "alice"},  # no "type" key
            effect=PolicyEffect.ALLOW,
        )
        with pytest.raises(ValueError, match=r"resource_match\.type"):
            DelegationScope.from_policy(policy)


# ---------------------------------------------------------------------------
# Delegation
# ---------------------------------------------------------------------------

NOW = datetime(2026, 4, 19, 12, 0, 0, tzinfo=UTC)


def _minimal_scope() -> DelegationScope:
    return DelegationScope(action_match="read", resource_type="document")


def _minimal_delegation(**overrides: object) -> Delegation:
    base: dict = {
        "tenant_id": "t1",
        "from_subject_id": "alice",
        "from_subject_type": ActorType.USER,
        "to_subject_id": "bob-agent",
        "to_subject_type": ActorType.AGENT,
        "scopes": [_minimal_scope()],
        "request_hash": "abc123",
        "created_at": NOW,
        "created_by": "alice",
        "status": DelegationStatus.ACTIVE,
    }
    base.update(overrides)
    return Delegation(**base)  # type: ignore[arg-type]


class TestDelegationConstruction:
    def test_minimal_all_optionals_none(self) -> None:
        d = _minimal_delegation()
        assert d.tenant_id == "t1"
        assert d.from_subject_id == "alice"
        assert d.to_subject_id == "bob-agent"
        assert d.max_uses is None
        assert d.uses_remaining is None
        assert d.budget is None
        assert d.budget_remaining is None
        assert d.lease_ttl is None
        assert d.last_heartbeat_at is None
        assert d.renewable_by is None
        assert d.expires_at is None
        assert d.re_check_on_use is True
        assert d.parent_delegation_id is None
        assert d.approval_request_id is None
        assert d.reason is None
        assert d.status == DelegationStatus.ACTIVE

    def test_auto_generates_id(self) -> None:
        d = _minimal_delegation()
        assert d.id  # non-empty string
        assert len(d.id) > 8

    def test_two_instances_get_different_ids(self) -> None:
        d1 = _minimal_delegation()
        d2 = _minimal_delegation()
        assert d1.id != d2.id

    def test_immutable(self) -> None:
        d = _minimal_delegation()
        with pytest.raises(ValidationError):
            d.status = DelegationStatus.REVOKED  # type: ignore[misc]

    def test_scopes_must_be_non_empty(self) -> None:
        with pytest.raises(ValidationError):
            _minimal_delegation(scopes=[])


class TestDelegationUsageValidation:
    def test_max_uses_requires_uses_remaining(self) -> None:
        with pytest.raises(ValidationError, match="uses_remaining required"):
            _minimal_delegation(max_uses=5, uses_remaining=None)

    def test_uses_remaining_cannot_exceed_max_uses(self) -> None:
        with pytest.raises(ValidationError, match="cannot exceed max_uses"):
            _minimal_delegation(max_uses=3, uses_remaining=5)

    def test_valid_usage_counter(self) -> None:
        d = _minimal_delegation(max_uses=5, uses_remaining=5)
        assert d.max_uses == 5
        assert d.uses_remaining == 5

    def test_uses_remaining_can_be_zero(self) -> None:
        d = _minimal_delegation(max_uses=5, uses_remaining=0)
        assert d.uses_remaining == 0

    def test_budget_requires_budget_remaining(self) -> None:
        with pytest.raises(ValidationError, match="budget_remaining required"):
            _minimal_delegation(budget=Decimal("10.00"), budget_remaining=None)

    def test_budget_remaining_cannot_exceed_budget(self) -> None:
        with pytest.raises(ValidationError, match="cannot exceed budget"):
            _minimal_delegation(
                budget=Decimal("5.00"),
                budget_remaining=Decimal("10.00"),
            )

    def test_valid_budget(self) -> None:
        d = _minimal_delegation(
            budget=Decimal("10.00"),
            budget_remaining=Decimal("10.00"),
        )
        assert d.budget == Decimal("10.00")
        assert d.budget_remaining == Decimal("10.00")

    def test_no_max_uses_no_uses_remaining_ok(self) -> None:
        # max_uses=None, uses_remaining=None — valid (no counter)
        d = _minimal_delegation(max_uses=None, uses_remaining=None)
        assert d.max_uses is None

    def test_uses_remaining_without_max_uses_ok(self) -> None:
        # No constraint in this direction — uses_remaining may exist standalone
        # (e.g. store decrements it and clears max_uses separately); entity allows it
        d = _minimal_delegation(max_uses=None, uses_remaining=3)
        assert d.uses_remaining == 3


class TestDelegationLease:
    def test_lease_fields_optional(self) -> None:
        d = _minimal_delegation(
            lease_ttl=timedelta(seconds=30),
            last_heartbeat_at=NOW,
            renewable_by=["bob-agent"],
        )
        assert d.lease_ttl == timedelta(seconds=30)
        assert d.last_heartbeat_at == NOW
        assert d.renewable_by == ["bob-agent"]

    def test_expires_at_field(self) -> None:
        future = datetime(2026, 12, 31, tzinfo=UTC)
        d = _minimal_delegation(expires_at=future)
        assert d.expires_at == future


class TestDelegationMakeHash:
    def _scope(self) -> DelegationScope:
        return DelegationScope(
            action_match="read",
            resource_type="document",
            resource_match={"id": {"op": "eq", "value": "doc-1"}},
        )

    def test_deterministic_same_args(self) -> None:
        h1 = Delegation.make_hash(
            tenant_id="t1",
            from_subject_id="alice",
            to_subject_id="bob",
            scopes=[self._scope()],
            parent_delegation_id=None,
            max_uses=None,
            budget=None,
            lease_ttl=None,
            expires_at=None,
        )
        h2 = Delegation.make_hash(
            tenant_id="t1",
            from_subject_id="alice",
            to_subject_id="bob",
            scopes=[self._scope()],
            parent_delegation_id=None,
            max_uses=None,
            budget=None,
            lease_ttl=None,
            expires_at=None,
        )
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex digest

    def test_differs_on_tenant(self) -> None:
        kwargs = {
            "from_subject_id": "alice",
            "to_subject_id": "bob",
            "scopes": [self._scope()],
            "parent_delegation_id": None,
            "max_uses": None,
            "budget": None,
            "lease_ttl": None,
            "expires_at": None,
        }
        h1 = Delegation.make_hash(tenant_id="t1", **kwargs)  # type: ignore[arg-type]
        h2 = Delegation.make_hash(tenant_id="t2", **kwargs)  # type: ignore[arg-type]
        assert h1 != h2

    def test_differs_on_scopes(self) -> None:
        scope_a = DelegationScope(action_match="read", resource_type="document")
        scope_b = DelegationScope(action_match="write", resource_type="document")
        kwargs = {
            "tenant_id": "t1",
            "from_subject_id": "alice",
            "to_subject_id": "bob",
            "parent_delegation_id": None,
            "max_uses": None,
            "budget": None,
            "lease_ttl": None,
            "expires_at": None,
        }
        h1 = Delegation.make_hash(scopes=[scope_a], **kwargs)  # type: ignore[arg-type]
        h2 = Delegation.make_hash(scopes=[scope_b], **kwargs)  # type: ignore[arg-type]
        assert h1 != h2

    def test_differs_on_max_uses(self) -> None:
        kwargs = {
            "tenant_id": "t1",
            "from_subject_id": "alice",
            "to_subject_id": "bob",
            "scopes": [self._scope()],
            "parent_delegation_id": None,
            "budget": None,
            "lease_ttl": None,
            "expires_at": None,
        }
        h1 = Delegation.make_hash(max_uses=None, **kwargs)  # type: ignore[arg-type]
        h2 = Delegation.make_hash(max_uses=5, **kwargs)  # type: ignore[arg-type]
        assert h1 != h2

    def test_differs_on_budget(self) -> None:
        kwargs = {
            "tenant_id": "t1",
            "from_subject_id": "alice",
            "to_subject_id": "bob",
            "scopes": [self._scope()],
            "parent_delegation_id": None,
            "max_uses": None,
            "lease_ttl": None,
            "expires_at": None,
        }
        h1 = Delegation.make_hash(budget=None, **kwargs)  # type: ignore[arg-type]
        h2 = Delegation.make_hash(budget=Decimal("10.00"), **kwargs)  # type: ignore[arg-type]
        assert h1 != h2

    def test_differs_on_lease_ttl(self) -> None:
        kwargs = {
            "tenant_id": "t1",
            "from_subject_id": "alice",
            "to_subject_id": "bob",
            "scopes": [self._scope()],
            "parent_delegation_id": None,
            "max_uses": None,
            "budget": None,
            "expires_at": None,
        }
        h1 = Delegation.make_hash(lease_ttl=None, **kwargs)  # type: ignore[arg-type]
        h2 = Delegation.make_hash(lease_ttl=timedelta(seconds=60), **kwargs)  # type: ignore[arg-type]
        assert h1 != h2

    def test_differs_on_parent_delegation_id(self) -> None:
        kwargs = {
            "tenant_id": "t1",
            "from_subject_id": "alice",
            "to_subject_id": "bob",
            "scopes": [self._scope()],
            "max_uses": None,
            "budget": None,
            "lease_ttl": None,
            "expires_at": None,
        }
        h1 = Delegation.make_hash(parent_delegation_id=None, **kwargs)  # type: ignore[arg-type]
        h2 = Delegation.make_hash(parent_delegation_id="parent-del-1", **kwargs)  # type: ignore[arg-type]
        assert h1 != h2
