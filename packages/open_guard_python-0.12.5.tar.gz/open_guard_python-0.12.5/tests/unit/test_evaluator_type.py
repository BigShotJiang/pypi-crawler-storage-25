"""Tests for evaluator_type property on all evaluators (Phase 8, Task 1)."""

from __future__ import annotations

import pytest

from open_guard.adapters.evaluators.abac import ABACEvaluator
from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.stores.async_memory import AsyncInMemoryRelationshipStore
from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import ActorType, Resource, Subject
from open_guard.domain.services.delegation_evaluator import DelegationEvaluator


class TestEvaluatorTypeProperty:
    def test_rbac_evaluator_type(self) -> None:
        evaluator = RBACEvaluator()
        assert evaluator.evaluator_type == "rbac"

    def test_abac_evaluator_type(self) -> None:
        evaluator = ABACEvaluator()
        assert evaluator.evaluator_type == "abac"

    def test_tbac_evaluator_type(self) -> None:
        evaluator = TBACEvaluator(task_store=InMemoryTaskStore())
        assert evaluator.evaluator_type == "tbac"

    def test_rebac_evaluator_type(self) -> None:
        evaluator = ReBACEvaluator(relationship_store=InMemoryRelationshipStore())
        assert evaluator.evaluator_type == "rebac"

    def test_async_rebac_evaluator_type(self) -> None:
        evaluator = AsyncReBACEvaluator(
            relationship_store=AsyncInMemoryRelationshipStore()
        )
        assert evaluator.evaluator_type == "rebac"

    def test_delegation_evaluator_type(self) -> None:
        evaluator = DelegationEvaluator(
            delegation_store=InMemoryDelegationStore(),
            guard=None,
        )
        assert evaluator.evaluator_type == "delegation"


class TestActorTypeExtension:
    def test_robot_value(self) -> None:
        assert ActorType.ROBOT.value == "robot"

    def test_edge_device_value(self) -> None:
        assert ActorType.EDGE_DEVICE.value == "edge_device"

    def test_subject_with_robot_actor_type(self) -> None:
        subject = Subject(id="robot-1", actor_type=ActorType.ROBOT)
        assert subject.actor_type == ActorType.ROBOT
        assert subject.actor_type.value == "robot"

    def test_subject_with_edge_device_actor_type(self) -> None:
        subject = Subject(id="edge-1", actor_type=ActorType.EDGE_DEVICE)
        assert subject.actor_type == ActorType.EDGE_DEVICE
        assert subject.actor_type.value == "edge_device"
