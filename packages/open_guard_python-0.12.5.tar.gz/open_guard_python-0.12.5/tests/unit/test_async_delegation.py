"""Tests for AsyncDelegationEvaluator + AsyncGuard delegation wiring — Phase 11 (FEAT-014).

Parity matrix against sync DelegationEvaluator/Manager.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime, timedelta
from unittest.mock import AsyncMock

import pytest

from open_guard.adapters.stores.async_memory import AsyncInMemoryDelegationStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    Decision,
    DecisionStatus,
    Delegation,
    DelegationScope,
    DelegationStatus,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import UsageExhaustedError
from open_guard.domain.services.async_delegation_evaluator import (
    AsyncDelegationEvaluator,
)
from open_guard.domain.services.async_guard import AsyncGuard

NOW = datetime(2026, 5, 18, 12, 0, 0, tzinfo=UTC)
TENANT = "t1"


def _allowed() -> Decision:
    return Decision(status=DecisionStatus.ALLOWED)


def _scope(
    action: str = "read",
    rtype: str = "document",
    resource_match: dict | None = None,
) -> DelegationScope:
    return DelegationScope(
        action_match=action,
        resource_type=rtype,
        resource_match=resource_match or {},
    )


def _delegation(
    *,
    from_id: str = "alice",
    to_id: str = "bob",
    scope: DelegationScope | None = None,
    status: DelegationStatus = DelegationStatus.ACTIVE,
    re_check_on_use: bool = False,
    parent_delegation_id: str | None = None,
    max_uses: int | None = None,
) -> Delegation:
    return Delegation(
        tenant_id=TENANT,
        from_subject_id=from_id,
        from_subject_type=ActorType.USER,
        to_subject_id=to_id,
        to_subject_type=ActorType.AGENT,
        scopes=[scope or _scope()],
        status=status,
        re_check_on_use=re_check_on_use,
        parent_delegation_id=parent_delegation_id,
        max_uses=max_uses,
        uses_remaining=max_uses,
        request_hash=f"hash-{from_id}-{to_id}-{status}-{max_uses}",
        created_at=NOW,
        created_by=from_id,
    )


# ============================================================
# AsyncDelegationEvaluator — direct
# ============================================================


class TestAsyncDelegationEvaluator:
    @pytest.mark.asyncio
    async def test_no_delegations_returns_not_allowed(self) -> None:
        store = AsyncInMemoryDelegationStore()
        guard_mock = AsyncMock()
        guard_mock.authorize.return_value = _allowed()
        ev = AsyncDelegationEvaluator(delegation_store=store, guard=guard_mock)
        result = await ev.evaluate(
            Subject(id="bob", actor_type=ActorType.AGENT),
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert result.allowed is False
        assert result.matched_delegation_ids == []

    @pytest.mark.asyncio
    async def test_active_delegation_returns_allowed_with_id(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = _delegation(re_check_on_use=False)
        await store.create(d)
        guard_mock = AsyncMock()
        guard_mock.authorize.return_value = _allowed()
        ev = AsyncDelegationEvaluator(delegation_store=store, guard=guard_mock)
        result = await ev.evaluate(
            Subject(id="bob", actor_type=ActorType.AGENT),
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert result.allowed is True
        assert d.id in result.matched_delegation_ids

    @pytest.mark.asyncio
    async def test_re_check_calls_guard_authorize(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = _delegation(re_check_on_use=True)
        await store.create(d)
        guard_mock = AsyncMock()
        guard_mock.authorize.return_value = _allowed()
        ev = AsyncDelegationEvaluator(delegation_store=store, guard=guard_mock)
        result = await ev.evaluate(
            Subject(id="bob", actor_type=ActorType.AGENT),
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert result.allowed is True
        # _skip_delegation=True should have been passed
        call_kwargs = guard_mock.authorize.await_args.kwargs
        assert call_kwargs.get("_skip_delegation") is True

    @pytest.mark.asyncio
    async def test_re_check_denied_excludes_delegation(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = _delegation(re_check_on_use=True)
        await store.create(d)
        guard_mock = AsyncMock()
        guard_mock.authorize.return_value = Decision(status=DecisionStatus.DENIED)
        ev = AsyncDelegationEvaluator(delegation_store=store, guard=guard_mock)
        result = await ev.evaluate(
            Subject(id="bob", actor_type=ActorType.AGENT),
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert result.allowed is False

    @pytest.mark.asyncio
    async def test_list_contribution_id_eq_scope(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = _delegation(
            scope=_scope(
                resource_match={"id": {"op": "eq", "value": "doc-9"}}
            )
        )
        await store.create(d)
        ev = AsyncDelegationEvaluator(delegation_store=store, guard=AsyncMock())
        ids = await ev.list_contribution(
            Subject(id="bob", actor_type=ActorType.AGENT),
            TENANT,
            resource_type="document",
        )
        assert ids == ["doc-9"]

    @pytest.mark.asyncio
    async def test_list_contribution_id_in_scope(self) -> None:
        store = AsyncInMemoryDelegationStore()
        d = _delegation(
            scope=_scope(
                resource_match={
                    "id": {"op": "in", "value": ["doc-1", "doc-2"]}
                }
            )
        )
        await store.create(d)
        ev = AsyncDelegationEvaluator(delegation_store=store, guard=AsyncMock())
        ids = await ev.list_contribution(
            Subject(id="bob", actor_type=ActorType.AGENT),
            TENANT,
            resource_type="document",
        )
        assert sorted(ids) == ["doc-1", "doc-2"]


# ============================================================
# AsyncGuard delegation fallback
# ============================================================


class TestAsyncGuardDelegationFallback:
    @pytest.mark.asyncio
    async def test_policy_router_denied_then_delegation_allows(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        # Owner role grants read on document via policy
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        # Alice has owner role; bob does not
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            re_check_on_use=False,
        )
        # Sanity: bob is denied without delegation lookup
        bob_no_deleg = await guard.authorize(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
            _skip_delegation=True,
        )
        assert bob_no_deleg.status == DecisionStatus.DENIED
        # With delegation fallback, bob is allowed
        decision = await guard.authorize(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert decision.status == DecisionStatus.ALLOWED
        assert decision.reason == "delegation"

    @pytest.mark.asyncio
    async def test_authorize_and_consume_decrements_uses(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        d = await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            max_uses=3,
            re_check_on_use=False,
        )
        # Three consume_authorize calls should succeed
        for _ in range(3):
            decision = await guard.authorize_and_consume(
                bob,
                Action(name="read"),
                Resource(id="doc-1", resource_type="document"),
                TENANT,
            )
            assert decision.status == DecisionStatus.ALLOWED
        # Delegation is now exhausted — fourth call falls back to policy
        # (which denies bob); no UsageExhaustedError because consume only
        # fires on ALLOWED.
        refreshed = await guard._delegation_store.get(d.id, TENANT)
        assert refreshed is not None
        assert refreshed.status == DelegationStatus.EXHAUSTED
        decision = await guard.authorize_and_consume(
            bob,
            Action(name="read"),
            Resource(id="doc-1", resource_type="document"),
            TENANT,
        )
        assert decision.status == DecisionStatus.DENIED

    @pytest.mark.asyncio
    async def test_authorize_and_consume_concurrent_cas_safety(self) -> None:
        """N concurrent authorize_and_consume calls yield exactly min(N, max_uses) allows."""
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        max_uses = 5
        await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            max_uses=max_uses,
            re_check_on_use=False,
        )

        async def attempt() -> Decision | Exception:
            try:
                return await guard.authorize_and_consume(
                    bob,
                    Action(name="read"),
                    Resource(
                        id="doc-1",
                        resource_type="document",
                        attributes={"type": "document"},
                    ),
                    TENANT,
                )
            except UsageExhaustedError as e:
                return e

        results = await asyncio.gather(*[attempt() for _ in range(10)])
        allowed_count = sum(
            1 for r in results if isinstance(r, Decision) and r.status == DecisionStatus.ALLOWED
        )
        # The in-memory store uses an RLock; under asyncio.gather with single-
        # threaded event loop, the calls serialize anyway. The invariant we
        # care about: never more than max_uses allowed.
        assert allowed_count <= max_uses


# ============================================================
# Cascade revocation on async store
# ============================================================


class TestAsyncCascadeRevocation:
    @pytest.mark.asyncio
    async def test_revoke_cascades_to_descendants(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        # Owner role grants read on document. Both alice and bob hold it so
        # narrowing passes when each delegates forward. default_delegate_policy
        # ="self_only" handles meta-authz when caller==from_subject.
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )

        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(
            id="bob", actor_type=ActorType.AGENT, attributes={"roles": ["owner"]}
        )
        carol = Subject(id="carol", actor_type=ActorType.AGENT, attributes={})

        parent = await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            re_check_on_use=False,
        )
        child = await guard.delegate(
            caller=bob,
            from_subject=bob,
            to_subject=carol,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            parent_delegation_id=parent.id,
            re_check_on_use=False,
        )

        await guard.revoke_delegation(parent.id, caller=alice, tenant_id=TENANT)
        # Both parent and child should now be REVOKED
        parent_refresh = await guard._delegation_store.get(parent.id, TENANT)
        child_refresh = await guard._delegation_store.get(child.id, TENANT)
        assert parent_refresh is not None
        assert child_refresh is not None
        assert parent_refresh.status == DelegationStatus.REVOKED
        assert child_refresh.status == DelegationStatus.REVOKED


# ============================================================
# list_authorized delegation contribution (lights up source 3 from Task 1)
# ============================================================


class TestAsyncListAuthorizedDelegationContribution:
    @pytest.mark.asyncio
    async def test_meta_authz_blocks_non_self_delegate(self) -> None:
        """default_delegate_policy='self_only' + no policy → meta-authz denies."""
        from open_guard.domain.exceptions import DelegateNotPermittedError

        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(
            id="bob", actor_type=ActorType.AGENT, attributes={"roles": ["owner"]}
        )
        carol = Subject(id="carol", actor_type=ActorType.AGENT, attributes={})
        # alice tries to delegate from bob to carol — caller != from_subject,
        # self_only short-circuit doesn't help, and no delegate policy exists
        with pytest.raises(DelegateNotPermittedError):
            await guard.delegate(
                caller=alice,
                from_subject=bob,
                to_subject=carol,
                scopes=[_scope(action="read", rtype="document")],
                tenant_id=TENANT,
                re_check_on_use=False,
            )

    @pytest.mark.asyncio
    async def test_narrowing_blocks_when_grantor_lacks_permission(self) -> None:
        """Grantor must hold the scope being delegated."""
        from open_guard.domain.exceptions import DelegateNotPermittedError

        guard = await AsyncGuard.from_config(backend="memory")
        # No policy gives alice read on document
        alice = Subject(id="alice", actor_type=ActorType.USER, attributes={})
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        with pytest.raises(DelegateNotPermittedError):
            await guard.delegate(
                caller=alice,
                from_subject=alice,
                to_subject=bob,
                scopes=[_scope(action="read", rtype="document")],
                tenant_id=TENANT,
                re_check_on_use=False,
            )

    @pytest.mark.asyncio
    async def test_delegate_idempotent_returns_existing(self) -> None:
        """Two delegate() calls with same args return the same Delegation."""
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        d1 = await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            re_check_on_use=False,
        )
        d2 = await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            re_check_on_use=False,
        )
        assert d1.id == d2.id

    @pytest.mark.asyncio
    async def test_renew_unauthorized_caller_raises(self) -> None:
        from open_guard.domain.exceptions import DelegateNotPermittedError

        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        eve = Subject(id="eve", actor_type=ActorType.AGENT, attributes={})
        d = await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            lease_ttl=timedelta(minutes=5),
            renewable_by=[alice.id],
            re_check_on_use=False,
        )
        with pytest.raises(DelegateNotPermittedError):
            await guard.renew_delegation(d.id, caller=eve, tenant_id=TENANT)

    @pytest.mark.asyncio
    async def test_renew_unknown_delegation_raises(self) -> None:
        from open_guard.domain.exceptions import DelegationNotFoundError

        guard = await AsyncGuard.from_config(backend="memory")
        alice = Subject(id="alice", actor_type=ActorType.USER, attributes={})
        with pytest.raises(DelegationNotFoundError):
            await guard.renew_delegation(
                "nonexistent", caller=alice, tenant_id=TENANT
            )

    @pytest.mark.asyncio
    async def test_consume_delegation_proxy(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        d = await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[_scope(action="read", rtype="document")],
            tenant_id=TENANT,
            max_uses=3,
            re_check_on_use=False,
        )
        updated = await guard.consume_delegation(d.id, TENANT, amount=1)
        assert updated.uses_remaining == 2

    @pytest.mark.asyncio
    async def test_list_authorized_includes_delegated_id_eq(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        # Alice has read access via policy
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["owner"]},
                action_match="read",
            )
        )
        alice = Subject(
            id="alice", actor_type=ActorType.USER, attributes={"roles": ["owner"]}
        )
        bob = Subject(id="bob", actor_type=ActorType.AGENT, attributes={})
        await guard.delegate(
            caller=alice,
            from_subject=alice,
            to_subject=bob,
            scopes=[
                _scope(
                    action="read",
                    rtype="document",
                    resource_match={"id": {"op": "eq", "value": "doc-7"}},
                )
            ],
            tenant_id=TENANT,
            re_check_on_use=False,
        )
        result = await guard.list_authorized(
            bob, "read", "document", tenant_id=TENANT
        )
        assert "doc-7" in result.ids
