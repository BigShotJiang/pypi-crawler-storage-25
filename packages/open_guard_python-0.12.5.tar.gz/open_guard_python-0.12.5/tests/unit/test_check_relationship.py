"""Tests for PolicyAdmin.check_relationship() query API (ENH-021)."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient
from fastapi import FastAPI

from open_guard import Guard
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.api.fastapi.admin_router import AdminRouter


@pytest.fixture
def guard() -> Guard:
    return Guard.from_config(backend="memory")


@pytest.fixture
def admin(guard: Guard) -> PolicyAdmin:
    return PolicyAdmin(guard)


@pytest.fixture
def client(admin: PolicyAdmin) -> TestClient:
    app = FastAPI()
    app.include_router(AdminRouter(admin=admin), prefix="/admin")
    return TestClient(app)


class TestCheckRelationship:
    def test_group_membership_exists(self, admin: PolicyAdmin) -> None:
        """Standard pattern: is user X a member of group Y?"""
        admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        )

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        ) is True

    def test_group_membership_different_group_returns_false(
        self, admin: PolicyAdmin
    ) -> None:
        admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        )

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="sales",
        ) is False

    def test_group_membership_different_relation_returns_false(
        self, admin: PolicyAdmin
    ) -> None:
        admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        )

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="owner_of",
            object_type="group",
            object_id="engineering",
        ) is False

    def test_team_ownership_pattern(self, admin: PolicyAdmin) -> None:
        """Standard pattern: is user X an owner of team Y?"""
        admin.add_relationship(
            tenant_id="t1",
            subject_id="bob",
            subject_type="user",
            relation="owner_of",
            object_type="team",
            object_id="backend",
        )

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="bob",
            subject_type="user",
            relation="owner_of",
            object_type="team",
            object_id="backend",
        ) is True

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="owner_of",
            object_type="team",
            object_id="backend",
        ) is False

    def test_org_hierarchy_pattern(self, admin: PolicyAdmin) -> None:
        """Standard pattern: is team X part of org Y?"""
        admin.add_relationship(
            tenant_id="t1",
            subject_id="backend",
            subject_type="team",
            relation="part_of",
            object_type="org",
            object_id="acme",
        )

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="backend",
            subject_type="team",
            relation="part_of",
            object_type="org",
            object_id="acme",
        ) is True

    def test_cross_tenant_isolation(self, admin: PolicyAdmin) -> None:
        """Relationship in tenant A is not visible in tenant B."""
        admin.add_relationship(
            tenant_id="tenant-a",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        )

        assert admin.check_relationship(
            tenant_id="tenant-b",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        ) is False

    def test_after_delete_returns_false(self, admin: PolicyAdmin) -> None:
        """Removing the relationship tuple causes check to return False."""
        rt = admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        )

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        ) is True

        admin.delete_relationship(rt.id, "t1")

        assert admin.check_relationship(
            tenant_id="t1",
            subject_id="alice",
            subject_type="user",
            relation="member_of",
            object_type="group",
            object_id="engineering",
        ) is False

    def test_no_relationship_store_raises(self) -> None:
        """Guard without relationship store raises ValueError."""
        from open_guard.adapters.stores.memory import InMemoryPolicyStore
        from open_guard.domain.services.guard import Guard

        guard = Guard(policy_store=InMemoryPolicyStore())
        admin = PolicyAdmin(guard)
        with pytest.raises(ValueError, match="relationship store"):
            admin.check_relationship(
                tenant_id="t1",
                subject_id="alice",
                subject_type="user",
                relation="member_of",
                object_type="group",
                object_id="engineering",
            )

    def test_admin_router_check_relationship_endpoint(
        self, client: TestClient
    ) -> None:
        """AdminRouter /relationships/check returns correct JSON."""
        # Add via admin API first
        client.post(
            "/admin/relationships",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "subject_type": "user",
                "relation": "member_of",
                "object_type": "group",
                "object_id": "engineering",
            },
        )

        resp = client.post(
            "/admin/relationships/check",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "subject_type": "user",
                "relation": "member_of",
                "object_type": "group",
                "object_id": "engineering",
            },
        )
        assert resp.status_code == 200
        assert resp.json() == {"exists": True}

        resp2 = client.post(
            "/admin/relationships/check",
            json={
                "tenant_id": "t1",
                "subject_id": "bob",
                "subject_type": "user",
                "relation": "member_of",
                "object_type": "group",
                "object_id": "engineering",
            },
        )
        assert resp2.status_code == 200
        assert resp2.json() == {"exists": False}
