"""Tests for AsyncGuard.list_authorized — Phase 11 (FEAT-018).

Parity matrix against sync Guard.list_authorized. Industry alignment:
OpenFGA ListObjects / Auth0 FGA listObjects / Zanzibar / SpiceDB
LookupResources / AWS Verified Permissions BatchIsAuthorized /
Cerbos PlanResources / Casbin getImplicitResourcesForUser.
"""

from __future__ import annotations

from typing import Any

import pytest

from open_guard.domain.entities import (
    ActorType,
    Policy,
    PolicyEffect,
    RelationTuple,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import ChainDepthExceededError
from open_guard.domain.ports.async_candidate_resource import (
    AsyncCandidateResourcePort,
)
from open_guard.domain.services.async_guard import AsyncGuard
from open_guard.domain.services.guard import Guard


class InMemoryAsyncCandidateSource(AsyncCandidateResourcePort):
    """Test fixture mirroring the sync InMemoryCandidateSource pattern."""

    def __init__(
        self,
        resources: dict[tuple[str, str], list[Resource]] | None = None,
    ) -> None:
        self._resources: dict[tuple[str, str], list[Resource]] = resources or {}

    async def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        items = self._resources.get((tenant_id, resource_type), [])
        if prefilter:
            items = [
                r
                for r in items
                if all(r.attributes.get(k) == v for k, v in prefilter.items())
            ]
        offset = int((cursor or {}).get("offset", 0))
        page = items[offset : offset + limit]
        next_cursor = (
            {"offset": offset + limit} if offset + limit < len(items) else None
        )
        return page, next_cursor


# ============================================================
# 1. Empty / degenerate cases
# ============================================================


class TestEmptyAndDegenerate:
    @pytest.mark.asyncio
    async def test_limit_zero_returns_empty(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        result = await guard.list_authorized(
            Subject(id="alice", attributes={}),
            "read",
            "doc",
            tenant_id="t1",
            limit=0,
        )
        assert result.ids == []
        assert result.next_cursor is None

    @pytest.mark.asyncio
    async def test_no_sources_wired_returns_empty(self) -> None:
        # Default async memory guard HAS a relationship_store but no candidates;
        # subject has no relationships, so nothing matches.
        guard = await AsyncGuard.from_config(backend="memory")
        result = await guard.list_authorized(
            Subject(id="alice", attributes={}),
            "read",
            "doc",
            tenant_id="t1",
        )
        assert result.ids == []
        assert result.next_cursor is None


# ============================================================
# 2. Candidate source path
# ============================================================


class TestCandidateSource:
    @pytest.mark.asyncio
    async def test_candidate_source_yields_allowed_ids(self) -> None:
        cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id="d1", resource_type="doc", attributes={"type": "doc"}
                    ),
                    Resource(
                        id="d2", resource_type="doc", attributes={"type": "doc"}
                    ),
                ]
            }
        )
        guard = await AsyncGuard.from_config(
            backend="memory", candidate_source=cand
        )
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        result = await guard.list_authorized(
            Subject(id="alice", attributes={"roles": ["reader"]}),
            "read",
            "doc",
            tenant_id="t1",
        )
        assert sorted(result.ids) == ["d1", "d2"]
        assert result.next_cursor is None

    @pytest.mark.asyncio
    async def test_candidate_source_prefilter_forwarded(self) -> None:
        cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id="d1",
                        resource_type="doc",
                        attributes={"type": "doc", "team": "eng"},
                    ),
                    Resource(
                        id="d2",
                        resource_type="doc",
                        attributes={"type": "doc", "team": "sales"},
                    ),
                ]
            }
        )
        guard = await AsyncGuard.from_config(
            backend="memory", candidate_source=cand
        )
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        result = await guard.list_authorized(
            Subject(id="alice", attributes={"roles": ["reader"]}),
            "read",
            "doc",
            tenant_id="t1",
            prefilter={"team": "eng"},
        )
        assert result.ids == ["d1"]

    @pytest.mark.asyncio
    async def test_deny_excluded_from_candidate_results(self) -> None:
        cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id="d1",
                        resource_type="doc",
                        attributes={"type": "doc", "classification": "public"},
                    ),
                    Resource(
                        id="d2",
                        resource_type="doc",
                        attributes={"type": "doc", "classification": "secret"},
                    ),
                ]
            }
        )
        guard = await AsyncGuard.from_config(
            backend="memory", candidate_source=cand
        )
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="abac",
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="abac",
                effect=PolicyEffect.DENY,
                action_match="read",
                conditions={
                    "resource.classification": {"op": "eq", "value": "secret"}
                },
            )
        )
        result = await guard.list_authorized(
            Subject(id="alice", attributes={}),
            "read",
            "doc",
            tenant_id="t1",
        )
        assert result.ids == ["d1"]

    @pytest.mark.asyncio
    async def test_candidate_source_cursor_round_trip(self) -> None:
        # 7 resources, fetch_size honors limit, so we need multiple pages.
        cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id=f"d{i}", resource_type="doc", attributes={"type": "doc"}
                    )
                    for i in range(7)
                ]
            }
        )
        guard = await AsyncGuard.from_config(
            backend="memory", candidate_source=cand
        )
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        subject = Subject(id="alice", attributes={"roles": ["reader"]})
        all_ids: list[str] = []
        cursor: str | None = None
        for _ in range(10):  # safety bound
            result = await guard.list_authorized(
                subject,
                "read",
                "doc",
                tenant_id="t1",
                limit=3,
                cursor=cursor,
            )
            all_ids.extend(result.ids)
            cursor = result.next_cursor
            if cursor is None:
                break
        assert sorted(all_ids) == sorted([f"d{i}" for i in range(7)])


# ============================================================
# 3. ReBAC native enumeration
# ============================================================


class TestReBACEnumeration:
    @pytest.mark.asyncio
    async def test_rebac_only_path(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        # Direct-relation policy: action=read maps to relation=viewer
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rebac",
                action_match="read",
                conditions={
                    "object_type": "doc",
                    "permission": "viewer",
                    "subject_type": "user",
                },
            )
        )
        rel_store = guard._relationship_store
        assert rel_store is not None
        for did in ("d1", "d2", "d3"):
            await rel_store.write_tuple(
                RelationTuple(
                    tenant_id="t1",
                    object_type="doc",
                    object_id=did,
                    relation="viewer",
                    subject_type="user",
                    subject_id="alice",
                )
            )
        result = await guard.list_authorized(
            Subject(id="alice", attributes={}, actor_type=ActorType.USER),
            "read",
            "doc",
            tenant_id="t1",
        )
        assert sorted(result.ids) == ["d1", "d2", "d3"]

    @pytest.mark.asyncio
    async def test_rebac_pagination(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rebac",
                action_match="read",
                conditions={
                    "object_type": "doc",
                    "permission": "owner",
                    "subject_type": "user",
                },
            )
        )
        rel_store = guard._relationship_store
        assert rel_store is not None
        for i in range(120):
            await rel_store.write_tuple(
                RelationTuple(
                    tenant_id="t1",
                    object_type="doc",
                    object_id=f"d{i}",
                    relation="owner",
                    subject_type="user",
                    subject_id="alice",
                )
            )
        subject = Subject(id="alice", attributes={}, actor_type=ActorType.USER)
        ids: list[str] = []
        cursor: str | None = None
        for _ in range(20):
            result = await guard.list_authorized(
                subject, "read", "doc", tenant_id="t1", limit=25, cursor=cursor
            )
            ids.extend(result.ids)
            cursor = result.next_cursor
            if cursor is None:
                break
        assert len(ids) == 120
        assert len(set(ids)) == 120


# ============================================================
# 4. Composition: candidate source + ReBAC together
# ============================================================


class TestBothSourcesComposed:
    @pytest.mark.asyncio
    async def test_dedup_across_sources(self) -> None:
        # Candidate yields d1, d2; ReBAC tuples grant d2, d3 — d2 must not appear twice.
        cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id="d1", resource_type="doc", attributes={"type": "doc"}
                    ),
                    Resource(
                        id="d2", resource_type="doc", attributes={"type": "doc"}
                    ),
                ]
            }
        )
        guard = await AsyncGuard.from_config(
            backend="memory", candidate_source=cand
        )
        # RBAC policy allows d1, d2 from candidate source
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        # ReBAC policy allows d2, d3 via tuples (direct-relation match)
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rebac",
                action_match="read",
                conditions={
                    "object_type": "doc",
                    "permission": "viewer",
                    "subject_type": "user",
                },
            )
        )
        rel_store = guard._relationship_store
        assert rel_store is not None
        for did in ("d2", "d3"):
            await rel_store.write_tuple(
                RelationTuple(
                    tenant_id="t1",
                    object_type="doc",
                    object_id=did,
                    relation="viewer",
                    subject_type="user",
                    subject_id="alice",
                )
            )
        result = await guard.list_authorized(
            Subject(
                id="alice",
                attributes={"roles": ["reader"]},
                actor_type=ActorType.USER,
            ),
            "read",
            "doc",
            tenant_id="t1",
        )
        assert sorted(result.ids) == ["d1", "d2", "d3"]
        assert len(result.ids) == len(set(result.ids))


# ============================================================
# 5. Chain depth
# ============================================================


class TestChainEnforcement:
    @pytest.mark.asyncio
    async def test_chain_depth_exceeded_raises(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory", max_chain_depth=1)
        deep_subject = Subject(
            id="proxy",
            attributes={},
            on_behalf_of=Subject(
                id="inner",
                attributes={},
                on_behalf_of=Subject(id="root", attributes={}),
            ),
        )
        with pytest.raises(ChainDepthExceededError):
            await guard.list_authorized(
                deep_subject, "read", "doc", tenant_id="t1"
            )


# ============================================================
# 6. Parity with sync Guard.list_authorized
# ============================================================


class TestSyncParity:
    """Same fixture against sync Guard and async AsyncGuard returns equivalent IDs."""

    @pytest.mark.asyncio
    async def test_random_fixture_parity_candidate_source(self) -> None:
        from tests.integration.test_list_authorized import (  # type: ignore[import-not-found]
            InMemoryCandidateSource,
        )

        fixture_resources = [
            Resource(
                id=f"d{i}",
                resource_type="doc",
                attributes={"type": "doc", "team": "eng" if i % 2 else "sales"},
            )
            for i in range(10)
        ]
        sync_cand = InMemoryCandidateSource({("t1", "doc"): list(fixture_resources)})
        async_cand = InMemoryAsyncCandidateSource(
            {("t1", "doc"): list(fixture_resources)}
        )

        sync_guard = Guard.from_config(backend="memory", candidate_source=sync_cand)
        async_guard = await AsyncGuard.from_config(
            backend="memory", candidate_source=async_cand
        )
        policy = Policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["reader"]},
            action_match="read",
            resource_match={"type": "doc"},
        )
        sync_guard.policy_store.add(policy)
        await async_guard.policy_store.add(policy)

        subject = Subject(id="alice", attributes={"roles": ["reader"]})
        sync_result = sync_guard.list_authorized(
            subject, "read", "doc", tenant_id="t1", prefilter={"team": "eng"}
        )
        async_result = await async_guard.list_authorized(
            subject, "read", "doc", tenant_id="t1", prefilter={"team": "eng"}
        )
        assert sorted(sync_result.ids) == sorted(async_result.ids)
        assert async_result.ids  # not empty


# ============================================================
# 7. Override stores per call
# ============================================================


class TestPerCallOverrides:
    @pytest.mark.asyncio
    async def test_candidate_source_override(self) -> None:
        guard = await AsyncGuard.from_config(backend="memory")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        override_cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id="override-1",
                        resource_type="doc",
                        attributes={"type": "doc"},
                    )
                ]
            }
        )
        result = await guard.list_authorized(
            Subject(id="alice", attributes={"roles": ["reader"]}),
            "read",
            "doc",
            tenant_id="t1",
            candidate_source=override_cand,
        )
        assert result.ids == ["override-1"]


# ============================================================
# 8. SQL backend smoke
# ============================================================


class TestSQLBackend:
    @pytest.mark.asyncio
    async def test_sqlite_aiosqlite_smoke(self) -> None:
        guard = await AsyncGuard.from_config(dsn="sqlite+aiosqlite:///")
        await guard.policy_store.add(
            Policy(
                tenant_id="t1",
                evaluator_type="rbac",
                subject_match={"roles": ["reader"]},
                action_match="read",
                resource_match={"type": "doc"},
            )
        )
        cand = InMemoryAsyncCandidateSource(
            {
                ("t1", "doc"): [
                    Resource(
                        id="d1", resource_type="doc", attributes={"type": "doc"}
                    )
                ]
            }
        )
        result = await guard.list_authorized(
            Subject(id="alice", attributes={"roles": ["reader"]}),
            "read",
            "doc",
            tenant_id="t1",
            candidate_source=cand,
        )
        assert result.ids == ["d1"]
