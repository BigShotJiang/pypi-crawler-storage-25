"""Tests for resource-scoped RBAC role assignment (FEAT-017)."""

from __future__ import annotations

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from open_guard import Action, Guard, Resource, Subject
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.api.fastapi.admin_router import AdminRouter


@pytest.fixture
def guard() -> Guard:
    return Guard.from_config(backend="memory")


@pytest.fixture
def admin(guard: Guard) -> PolicyAdmin:
    return PolicyAdmin(guard)


@pytest.fixture
def client(admin: PolicyAdmin) -> TestClient:
    app = FastAPI()
    app.include_router(AdminRouter(admin=admin), prefix="/admin")
    return TestClient(app)


def _authorize(guard: Guard, subject_id: str, roles: list[str], action: str,
               resource_id: str, resource_type: str, resource_attrs: dict,
               tenant_id: str) -> bool:
    return guard.authorize(
        Subject(id=subject_id, attributes={"roles": roles}),
        Action(name=action),
        Resource(id=resource_id, resource_type=resource_type, attributes=resource_attrs),
        tenant_id,
    ).allowed


class TestResourceScopedRoles:
    def test_scoped_role_allows_matching_resource(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """Writer in engineering department can write to engineering resources."""
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "engineering"},
        )

        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-1", "document",
            {"department": "engineering"}, "t1",
        ) is True

    def test_scoped_role_denies_different_scope(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """Writer in engineering cannot write to support resources."""
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "engineering"},
        )

        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-2", "document",
            {"department": "support"}, "t1",
        ) is False

    def test_different_scopes_for_same_subject(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """Subject can have writer in one scope and reader in another."""
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "engineering"},
        )
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="reader",
            resource_match={"department": "support"},
        )

        # Writer access to engineering — allowed
        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-1", "document",
            {"department": "engineering"}, "t1",
        ) is True

        # Reader access to support — allowed
        assert _authorize(
            guard, "alice", ["reader"], "read", "doc-2", "document",
            {"department": "support"}, "t1",
        ) is True

        # Writer access to support — denied (only reader there)
        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-3", "document",
            {"department": "support"}, "t1",
        ) is False

    def test_global_role_still_works(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """No resource_match = role applies everywhere (backward compatible)."""
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="admin",
        )

        assert _authorize(
            guard, "alice", ["admin"], "write", "doc-1", "document",
            {"department": "engineering"}, "t1",
        ) is True

        assert _authorize(
            guard, "alice", ["admin"], "write", "doc-2", "document",
            {"department": "support"}, "t1",
        ) is True

    def test_multi_attribute_resource_match(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """Role scoped to multiple attributes only matches resources with all."""
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "engineering", "region": "us-east-1"},
        )

        # Both attributes match — allowed
        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-1", "document",
            {"department": "engineering", "region": "us-east-1"}, "t1",
        ) is True

        # Only one attribute matches — denied
        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-2", "document",
            {"department": "engineering", "region": "eu-west-1"}, "t1",
        ) is False

    def test_revoke_scoped_role_leaves_other_scopes(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """Revoking a scoped role removes only that scope, not others."""
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "engineering"},
        )
        admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "support"},
        )

        # Revoke only the engineering scope
        admin.revoke_role(
            tenant_id="t1",
            subject_id="alice",
            role="writer",
            resource_match={"department": "engineering"},
        )

        # Engineering scope gone
        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-1", "document",
            {"department": "engineering"}, "t1",
        ) is False

        # Support scope still active
        assert _authorize(
            guard, "alice", ["writer"], "write", "doc-2", "document",
            {"department": "support"}, "t1",
        ) is True

    def test_revoke_global_role_backward_compatible(
        self, guard: Guard, admin: PolicyAdmin
    ) -> None:
        """revoke_role() without resource_match removes all matching policies."""
        admin.assign_role(tenant_id="t1", subject_id="alice", role="admin")

        assert _authorize(
            guard, "alice", ["admin"], "write", "doc-1", "document", {}, "t1",
        ) is True

        admin.revoke_role(tenant_id="t1", subject_id="alice", role="admin")

        assert _authorize(
            guard, "alice", ["admin"], "write", "doc-1", "document", {}, "t1",
        ) is False

    def test_admin_router_assign_role_with_resource_match(
        self, client: TestClient, guard: Guard
    ) -> None:
        """AdminRouter /roles endpoint accepts resource_match."""
        resp = client.post(
            "/admin/roles",
            json={
                "tenant_id": "t1",
                "subject_id": "alice",
                "role": "writer",
                "resource_match": {"department": "engineering"},
            },
        )
        assert resp.status_code == 201
        body = resp.json()
        assert body["resource_match"] == {"department": "engineering"}
