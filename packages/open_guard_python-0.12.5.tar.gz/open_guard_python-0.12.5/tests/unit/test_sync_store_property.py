"""Tests for public sync_store property on async in-memory stores (ENH-020)."""

from __future__ import annotations

from open_guard.adapters.stores.async_memory import (
    AsyncInMemoryApprovalStore,
    AsyncInMemoryDelegationStore,
    AsyncInMemoryPolicyStore,
    AsyncInMemoryRelationshipStore,
    AsyncInMemorySessionStore,
    AsyncInMemoryTaskStore,
)
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_approval import InMemoryApprovalStore
from open_guard.adapters.stores.memory_delegation import InMemoryDelegationStore
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.adapters.stores.memory_session import InMemorySessionStore
from open_guard.adapters.stores.memory_task import InMemoryTaskStore


class TestSyncStoreProperty:
    def test_policy_store_exposes_sync_store(self) -> None:
        store = AsyncInMemoryPolicyStore()
        assert isinstance(store.sync_store, InMemoryPolicyStore)
        assert store.sync_store is store._sync

    def test_relationship_store_exposes_sync_store(self) -> None:
        store = AsyncInMemoryRelationshipStore()
        assert isinstance(store.sync_store, InMemoryRelationshipStore)
        assert store.sync_store is store._sync

    def test_task_store_exposes_sync_store(self) -> None:
        store = AsyncInMemoryTaskStore()
        assert isinstance(store.sync_store, InMemoryTaskStore)
        assert store.sync_store is store._sync

    def test_approval_store_exposes_sync_store(self) -> None:
        store = AsyncInMemoryApprovalStore()
        assert isinstance(store.sync_store, InMemoryApprovalStore)
        assert store.sync_store is store._sync

    def test_delegation_store_exposes_sync_store(self) -> None:
        store = AsyncInMemoryDelegationStore()
        assert isinstance(store.sync_store, InMemoryDelegationStore)
        assert store.sync_store is store._sync

    def test_session_store_exposes_sync_store(self) -> None:
        store = AsyncInMemorySessionStore()
        assert isinstance(store.sync_store, InMemorySessionStore)
        assert store.sync_store is store._sync

    def test_sync_store_is_same_instance_not_copy(self) -> None:
        """sync_store returns the same object — not a copy."""
        store = AsyncInMemoryPolicyStore()
        assert store.sync_store is store.sync_store  # idempotent
