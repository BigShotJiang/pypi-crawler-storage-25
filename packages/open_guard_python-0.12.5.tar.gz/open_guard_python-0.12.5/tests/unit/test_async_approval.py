"""Tests for AsyncApprovalManager + AsyncGuard approval gating — Phase 11 (FEAT-015)."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

import pytest

from open_guard.domain.entities import (
    Action,
    ApprovalRequirement,
    ApprovalStatus,
    DecisionStatus,
    Policy,
    Resource,
    Subject,
)
from open_guard.domain.exceptions import ApprovalError
from open_guard.domain.services.async_guard import AsyncGuard

TENANT = "t1"


def _alice() -> Subject:
    return Subject(id="alice", attributes={"roles": ["editor"]})


def _doc() -> Resource:
    return Resource(id="doc-1", resource_type="document")


async def _setup_guard_with_approval_policy(
    *, requirement: ApprovalRequirement | None = None
) -> AsyncGuard:
    guard = await AsyncGuard.from_config(backend="memory")
    requirement = requirement or ApprovalRequirement(
        approvers=["manager-1"], quorum="any"
    )
    await guard.policy_store.add(
        Policy(
            tenant_id=TENANT,
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match="write",
            requires_approval=requirement,
        )
    )
    return guard


# ============================================================
# Approval gating
# ============================================================


class TestApprovalGating:
    @pytest.mark.asyncio
    async def test_requires_approval_returns_pending(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        decision = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert decision.status == DecisionStatus.PENDING_APPROVAL
        assert decision.approval_request_id is not None
        assert decision.reason == "Awaiting approval"

    @pytest.mark.asyncio
    async def test_idempotent_re_call_returns_same_request(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        d1 = await guard.authorize(_alice(), Action(name="write"), _doc(), TENANT)
        d2 = await guard.authorize(_alice(), Action(name="write"), _doc(), TENANT)
        assert d1.approval_request_id == d2.approval_request_id

    @pytest.mark.asyncio
    async def test_approve_unblocks_subsequent_authorize(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        pending = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert pending.approval_request_id is not None
        await guard.approve(
            pending.approval_request_id, TENANT, "manager-1", "looks fine"
        )
        # Next authorize sees historical APPROVED and allows
        next_decision = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert next_decision.status == DecisionStatus.ALLOWED

    @pytest.mark.asyncio
    async def test_reject_transitions_to_denied(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        pending = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert pending.approval_request_id is not None
        await guard.reject(
            pending.approval_request_id, TENANT, "manager-1", "policy violation"
        )
        next_decision = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert next_decision.status == DecisionStatus.DENIED
        assert "approval rejected" in next_decision.reason
        assert "policy violation" in next_decision.reason

    @pytest.mark.asyncio
    async def test_quorum_all_requires_every_approver(self) -> None:
        requirement = ApprovalRequirement(
            approvers=["manager-1", "manager-2"], quorum="all"
        )
        guard = await _setup_guard_with_approval_policy(requirement=requirement)
        pending = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert pending.approval_request_id is not None
        # First approval: still pending
        await guard.approve(pending.approval_request_id, TENANT, "manager-1")
        next1 = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert next1.status == DecisionStatus.PENDING_APPROVAL
        # Second approval: now ALLOWED on next authorize
        await guard.approve(pending.approval_request_id, TENANT, "manager-2")
        next2 = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert next2.status == DecisionStatus.ALLOWED

    @pytest.mark.asyncio
    async def test_quorum_integer_n(self) -> None:
        requirement = ApprovalRequirement(
            approvers=["m1", "m2", "m3"], quorum=2
        )
        guard = await _setup_guard_with_approval_policy(requirement=requirement)
        pending = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert pending.approval_request_id is not None
        await guard.approve(pending.approval_request_id, TENANT, "m1")
        still_pending = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert still_pending.status == DecisionStatus.PENDING_APPROVAL
        await guard.approve(pending.approval_request_id, TENANT, "m2")
        allowed = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert allowed.status == DecisionStatus.ALLOWED

    @pytest.mark.asyncio
    async def test_pending_excluded_from_list_authorized(self) -> None:
        from open_guard.domain.ports.async_candidate_resource import (
            AsyncCandidateResourcePort,
        )
        from typing import Any

        class StaticCand(AsyncCandidateResourcePort):
            async def fetch_candidates(
                self,
                resource_type: str,
                tenant_id: str,
                prefilter: dict[str, Any] | None,
                cursor: dict[str, Any] | None,
                limit: int,
            ) -> tuple[list[Resource], dict[str, Any] | None]:
                return [_doc()], None

        cand = StaticCand()
        guard = await _setup_guard_with_approval_policy()
        guard._candidate_source = cand  # inject post-hoc
        result = await guard.list_authorized(
            _alice(), "write", "document", tenant_id=TENANT
        )
        # PENDING_APPROVAL is not ALLOWED — should be excluded
        assert "doc-1" not in result.ids


# ============================================================
# Idempotency
# ============================================================


class TestIdempotency:
    @pytest.mark.asyncio
    async def test_same_hash_returns_same_request(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        # Two independent authorize calls with the same key produce the
        # same approval_request_id.
        d1 = await guard.authorize(_alice(), Action(name="write"), _doc(), TENANT)
        d2 = await guard.authorize(_alice(), Action(name="write"), _doc(), TENANT)
        assert d1.approval_request_id == d2.approval_request_id


# ============================================================
# TTL expiry
# ============================================================


class TestTTLExpiry:
    @pytest.mark.asyncio
    async def test_expired_pending_creates_fresh_request(self) -> None:
        now_box = {"t": datetime(2026, 5, 18, 12, 0, 0, tzinfo=UTC)}

        def clock() -> datetime:
            return now_box["t"]

        # Build a guard with clock injection — bypass from_config so we can
        # pass clock=
        from open_guard.adapters.stores.async_memory import (
            AsyncInMemoryApprovalStore,
            AsyncInMemoryDelegationStore,
            AsyncInMemoryPolicyStore,
            AsyncInMemoryRelationshipStore,
            AsyncInMemorySessionStore,
            AsyncInMemoryTaskStore,
        )
        from open_guard.adapters.evaluators.abac import ABACEvaluator
        from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
        from open_guard.adapters.evaluators.rbac import RBACEvaluator
        from open_guard.adapters.evaluators.tbac import TBACEvaluator
        from open_guard.adapters.evaluators.trust import TrustGateEvaluator

        policy_store = AsyncInMemoryPolicyStore()
        rel_store = AsyncInMemoryRelationshipStore()
        task_store = AsyncInMemoryTaskStore()
        evaluators = [
            RBACEvaluator(),
            ABACEvaluator(),
            TBACEvaluator(task_store=task_store.sync_store),
            AsyncReBACEvaluator(relationship_store=rel_store),
            TrustGateEvaluator(),
        ]
        guard = AsyncGuard(
            policy_store=policy_store,
            evaluators=evaluators,
            approval_store=AsyncInMemoryApprovalStore(),
            relationship_store=rel_store,
            delegation_store=AsyncInMemoryDelegationStore(),
            session_store=AsyncInMemorySessionStore(),
            clock=clock,
        )
        await guard.policy_store.add(
            Policy(
                tenant_id=TENANT,
                evaluator_type="rbac",
                subject_match={"roles": ["editor"]},
                action_match="write",
                requires_approval=ApprovalRequirement(
                    approvers=["m1"], quorum="any", ttl=timedelta(minutes=5)
                ),
            )
        )
        d1 = await guard.authorize(_alice(), Action(name="write"), _doc(), TENANT)
        # Advance clock past TTL
        now_box["t"] = datetime(2026, 5, 18, 13, 0, 0, tzinfo=UTC)
        d2 = await guard.authorize(_alice(), Action(name="write"), _doc(), TENANT)
        assert d2.status == DecisionStatus.PENDING_APPROVAL
        # New request id — the previous one was expired
        assert d2.approval_request_id != d1.approval_request_id


# ============================================================
# Error handling
# ============================================================


class TestErrors:
    @pytest.mark.asyncio
    async def test_approve_without_approval_store_raises(self) -> None:
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore

        guard = AsyncGuard(policy_store=AsyncInMemoryPolicyStore())
        with pytest.raises(ApprovalError, match="no approval_store"):
            await guard.approve("nonexistent", TENANT, "m1")

    @pytest.mark.asyncio
    async def test_reject_without_approval_store_raises(self) -> None:
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore

        guard = AsyncGuard(policy_store=AsyncInMemoryPolicyStore())
        with pytest.raises(ApprovalError, match="no approval_store"):
            await guard.reject("nonexistent", TENANT, "m1")

    @pytest.mark.asyncio
    async def test_approve_unknown_request_raises(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        with pytest.raises(ApprovalError, match="not found"):
            await guard.approve("nonexistent-id", TENANT, "manager-1")

    @pytest.mark.asyncio
    async def test_double_vote_raises(self) -> None:
        guard = await _setup_guard_with_approval_policy(
            requirement=ApprovalRequirement(approvers=["m1", "m2"], quorum="all")
        )
        pending = await guard.authorize(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert pending.approval_request_id is not None
        await guard.approve(pending.approval_request_id, TENANT, "m1")
        with pytest.raises(ApprovalError, match="already voted"):
            await guard.approve(pending.approval_request_id, TENANT, "m1")


# ============================================================
# Traced path applies approval gate
# ============================================================


class TestTraced:
    @pytest.mark.asyncio
    async def test_authorize_traced_returns_pending_when_required(self) -> None:
        guard = await _setup_guard_with_approval_policy()
        decision, trace = await guard.authorize_traced(
            _alice(), Action(name="write"), _doc(), TENANT
        )
        assert decision.status == DecisionStatus.PENDING_APPROVAL
        assert trace.decision_status == DecisionStatus.PENDING_APPROVAL
