"""Tests for PolicyAdmin in-process SDK (Phase 7 — T4)."""

from __future__ import annotations

import pytest

from open_guard import Guard, Policy, Session, SessionStatus
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.domain.entities import (
    DelegationStatus,
    RelationTuple,
)
from open_guard.domain.exceptions import SessionNotFoundError


@pytest.fixture
def guard() -> Guard:
    return Guard.from_config(backend="memory")


@pytest.fixture
def admin(guard: Guard) -> PolicyAdmin:
    return PolicyAdmin(guard)


# ------------------------------------------------------------------
# Policies
# ------------------------------------------------------------------


class TestPolicyCRUD:
    """Create / list / get / delete policies."""

    def test_create_policy(self, admin: PolicyAdmin) -> None:
        p = admin.create_policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="read",
            resource_match={"type": "doc"},
        )
        assert isinstance(p, Policy)
        assert p.tenant_id == "t1"
        assert p.evaluator_type == "rbac"
        assert p.subject_match == {"roles": ["admin"]}
        assert p.action_match == "read"
        assert p.effect.value == "allow"

    def test_create_policy_defaults(self, admin: PolicyAdmin) -> None:
        p = admin.create_policy(tenant_id="t1", evaluator_type="abac")
        assert p.subject_match == {}
        assert p.action_match == "*"
        assert p.resource_match == {}
        assert p.conditions == {}
        assert p.priority == 0

    def test_create_policy_deny(self, admin: PolicyAdmin) -> None:
        p = admin.create_policy(
            tenant_id="t1", evaluator_type="rbac", effect="deny"
        )
        assert p.effect.value == "deny"

    def test_list_policies(self, admin: PolicyAdmin) -> None:
        admin.create_policy(tenant_id="t1", evaluator_type="rbac")
        admin.create_policy(tenant_id="t1", evaluator_type="abac")
        result = admin.list_policies("t1")
        assert len(result) == 2

    def test_list_policies_by_type(self, admin: PolicyAdmin) -> None:
        admin.create_policy(tenant_id="t1", evaluator_type="rbac")
        admin.create_policy(tenant_id="t1", evaluator_type="abac")
        result = admin.list_policies("t1", evaluator_type="rbac")
        assert len(result) == 1
        assert result[0].evaluator_type == "rbac"

    def test_get_policy(self, admin: PolicyAdmin) -> None:
        p = admin.create_policy(tenant_id="t1", evaluator_type="rbac")
        found = admin.get_policy(p.id, "t1")
        assert found is not None
        assert found.id == p.id

    def test_get_policy_not_found(self, admin: PolicyAdmin) -> None:
        result = admin.get_policy("nonexistent", "t1")
        assert result is None

    def test_delete_policy(self, admin: PolicyAdmin) -> None:
        p = admin.create_policy(tenant_id="t1", evaluator_type="rbac")
        admin.delete_policy(p.id, "t1")
        assert admin.get_policy(p.id, "t1") is None

    def test_list_policies_empty(self, admin: PolicyAdmin) -> None:
        assert admin.list_policies("t1") == []


# ------------------------------------------------------------------
# Tenant isolation
# ------------------------------------------------------------------


class TestTenantIsolation:
    """Policies from one tenant must not leak to another."""

    def test_policies_isolated(self, admin: PolicyAdmin) -> None:
        admin.create_policy(tenant_id="t1", evaluator_type="rbac")
        admin.create_policy(tenant_id="t2", evaluator_type="rbac")
        assert len(admin.list_policies("t1")) == 1
        assert len(admin.list_policies("t2")) == 1

    def test_relationships_isolated(self, admin: PolicyAdmin) -> None:
        admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            relation="viewer",
            object_type="doc",
            object_id="d1",
        )
        admin.add_relationship(
            tenant_id="t2",
            subject_id="bob",
            relation="viewer",
            object_type="doc",
            object_id="d2",
        )
        assert len(admin.list_relationships("t1")) == 1
        assert len(admin.list_relationships("t2")) == 1


# ------------------------------------------------------------------
# Roles (convenience)
# ------------------------------------------------------------------


class TestRoles:
    """Assign / revoke role convenience methods."""

    def test_assign_role(self, admin: PolicyAdmin) -> None:
        p = admin.assign_role(
            tenant_id="t1", subject_id="alice", role="editor"
        )
        assert p.evaluator_type == "rbac"
        assert p.subject_match["roles"] == ["editor"]
        assert p.subject_match["id"] == "alice"

    def test_assign_role_with_resource_type(self, admin: PolicyAdmin) -> None:
        p = admin.assign_role(
            tenant_id="t1",
            subject_id="alice",
            role="editor",
            resource_type="doc",
        )
        assert p.resource_match == {"type": "doc"}

    def test_revoke_role(self, admin: PolicyAdmin) -> None:
        admin.assign_role(tenant_id="t1", subject_id="alice", role="editor")
        admin.revoke_role(tenant_id="t1", subject_id="alice", role="editor")
        policies = admin.list_policies("t1", evaluator_type="rbac")
        assert len(policies) == 0

    def test_revoke_role_selective(self, admin: PolicyAdmin) -> None:
        """Revoking one role does not remove policies for other roles."""
        admin.assign_role(tenant_id="t1", subject_id="alice", role="editor")
        admin.assign_role(tenant_id="t1", subject_id="alice", role="admin")
        admin.revoke_role(tenant_id="t1", subject_id="alice", role="editor")
        policies = admin.list_policies("t1", evaluator_type="rbac")
        assert len(policies) == 1
        assert policies[0].subject_match["roles"] == ["admin"]


# ------------------------------------------------------------------
# Relationships
# ------------------------------------------------------------------


class TestRelationships:
    """Add / list / delete relationship tuples."""

    def test_add_relationship(self, admin: PolicyAdmin) -> None:
        rt = admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            relation="viewer",
            object_type="doc",
            object_id="d1",
        )
        assert isinstance(rt, RelationTuple)
        assert rt.tenant_id == "t1"
        assert rt.subject_id == "alice"
        assert rt.relation == "viewer"
        assert rt.object_type == "doc"
        assert rt.object_id == "d1"
        assert rt.subject_type == "user"

    def test_add_relationship_with_subject_relation(
        self, admin: PolicyAdmin
    ) -> None:
        rt = admin.add_relationship(
            tenant_id="t1",
            subject_id="eng",
            subject_type="group",
            relation="viewer",
            object_type="doc",
            object_id="d1",
            subject_relation="member",
        )
        assert rt.subject_relation == "member"
        assert rt.subject_type == "group"

    def test_list_relationships(self, admin: PolicyAdmin) -> None:
        admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            relation="viewer",
            object_type="doc",
            object_id="d1",
        )
        admin.add_relationship(
            tenant_id="t1",
            subject_id="bob",
            relation="editor",
            object_type="doc",
            object_id="d1",
        )
        result = admin.list_relationships("t1")
        assert len(result) == 2

    def test_list_relationships_filtered(self, admin: PolicyAdmin) -> None:
        admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            relation="viewer",
            object_type="doc",
            object_id="d1",
        )
        admin.add_relationship(
            tenant_id="t1",
            subject_id="bob",
            relation="editor",
            object_type="doc",
            object_id="d1",
        )
        result = admin.list_relationships("t1", relation="viewer")
        assert len(result) == 1
        assert result[0].subject_id == "alice"

    def test_delete_relationship(self, admin: PolicyAdmin) -> None:
        rt = admin.add_relationship(
            tenant_id="t1",
            subject_id="alice",
            relation="viewer",
            object_type="doc",
            object_id="d1",
        )
        admin.delete_relationship(rt.id, "t1")
        assert admin.list_relationships("t1") == []


# ------------------------------------------------------------------
# Delegations
# ------------------------------------------------------------------


class TestDelegations:
    """Create / list / revoke delegations."""

    def _grant_permission(self, admin: PolicyAdmin) -> None:
        """Create an ABAC policy so any subject can perform actions on docs.

        We use ABAC with no subject conditions so the narrowing check passes
        for any from_subject.
        """
        admin.create_policy(
            tenant_id="t1",
            evaluator_type="abac",
            subject_match={},
            action_match="*",
            resource_match={},
        )

    def test_create_delegation(self, admin: PolicyAdmin) -> None:
        self._grant_permission(admin)
        d = admin.create_delegation(
            tenant_id="t1",
            from_subject_id="alice",
            to_subject_id="bob",
            scopes=[{"action_match": "read", "resource_type": "doc"}],
        )
        assert d.tenant_id == "t1"
        assert d.from_subject_id == "alice"
        assert d.to_subject_id == "bob"
        assert d.status == DelegationStatus.ACTIVE
        assert len(d.scopes) == 1
        assert d.scopes[0].resource_type == "doc"

    def test_list_delegations(self, admin: PolicyAdmin) -> None:
        self._grant_permission(admin)
        admin.create_delegation(
            tenant_id="t1",
            from_subject_id="alice",
            to_subject_id="bob",
            scopes=[{"action_match": "read", "resource_type": "doc"}],
        )
        result = admin.list_delegations("t1", subject_id="bob")
        assert len(result) == 1
        assert result[0].to_subject_id == "bob"

    def test_list_delegations_empty(self, admin: PolicyAdmin) -> None:
        result = admin.list_delegations("t1", subject_id="nobody")
        assert result == []

    def test_revoke_delegation(self, admin: PolicyAdmin) -> None:
        self._grant_permission(admin)
        d = admin.create_delegation(
            tenant_id="t1",
            from_subject_id="alice",
            to_subject_id="bob",
            scopes=[{"action_match": "read", "resource_type": "doc"}],
        )
        admin.revoke_delegation(d.id, "t1", caller_id="alice")
        result = admin.list_delegations("t1", subject_id="bob")
        assert result == []

    def test_no_delegation_store_raises(self) -> None:
        """Guard without delegation store raises ValueError."""
        from open_guard.adapters.stores.memory import InMemoryPolicyStore

        guard = Guard(policy_store=InMemoryPolicyStore())
        local_admin = PolicyAdmin(guard)
        with pytest.raises(ValueError, match="No delegation store"):
            local_admin.create_delegation(
                tenant_id="t1",
                from_subject_id="alice",
                to_subject_id="bob",
                scopes=[{"action_match": "read", "resource_type": "doc"}],
            )


# ------------------------------------------------------------------
# Sessions
# ------------------------------------------------------------------


class TestSessions:
    """Create / deactivate / get / list sessions."""

    def test_create_session(self, admin: PolicyAdmin) -> None:
        s = admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        assert isinstance(s, Session)
        assert s.tenant_id == "t1"
        assert s.subject_id == "alice"
        assert s.activated_roles == ["editor"]
        assert s.status == SessionStatus.ACTIVE

    def test_create_session_with_metadata(self, admin: PolicyAdmin) -> None:
        s = admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
            metadata={"device": "laptop"},
        )
        assert s.metadata == {"device": "laptop"}

    def test_get_session(self, admin: PolicyAdmin) -> None:
        s = admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        found = admin.get_session(s.id, "t1")
        assert found.id == s.id

    def test_get_session_not_found(self, admin: PolicyAdmin) -> None:
        with pytest.raises(SessionNotFoundError):
            admin.get_session("nonexistent", "t1")

    def test_deactivate_session(self, admin: PolicyAdmin) -> None:
        s = admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        deactivated = admin.deactivate_session(s.id, "t1")
        assert deactivated.status == SessionStatus.DEACTIVATED

    def test_list_sessions(self, admin: PolicyAdmin) -> None:
        admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["admin"],
        )
        result = admin.list_sessions("t1", subject_id="alice")
        assert len(result) == 2

    def test_list_sessions_empty(self, admin: PolicyAdmin) -> None:
        result = admin.list_sessions("t1", subject_id="nobody")
        assert result == []

    def test_deactivated_session_not_in_active_list(
        self, admin: PolicyAdmin
    ) -> None:
        s = admin.create_session(
            tenant_id="t1",
            subject_id="alice",
            activated_roles=["editor"],
        )
        admin.deactivate_session(s.id, "t1")
        result = admin.list_sessions("t1", subject_id="alice")
        assert len(result) == 0

    def test_no_session_store_raises(self) -> None:
        """Guard without session store raises ValueError."""
        from open_guard.adapters.stores.memory import InMemoryPolicyStore

        guard = Guard(policy_store=InMemoryPolicyStore())
        local_admin = PolicyAdmin(guard)
        with pytest.raises(ValueError, match="No session store"):
            local_admin.create_session(
                tenant_id="t1",
                subject_id="alice",
                activated_roles=["editor"],
            )


# ------------------------------------------------------------------
# No relationship store
# ------------------------------------------------------------------


class TestNoRelationshipStore:
    """Relationship methods raise ValueError when store is missing."""

    def test_add_raises(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore

        guard = Guard(policy_store=InMemoryPolicyStore())
        local_admin = PolicyAdmin(guard)
        with pytest.raises(ValueError, match="No relationship store"):
            local_admin.add_relationship(
                tenant_id="t1",
                subject_id="alice",
                relation="viewer",
                object_type="doc",
                object_id="d1",
            )

    def test_list_raises(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore

        guard = Guard(policy_store=InMemoryPolicyStore())
        local_admin = PolicyAdmin(guard)
        with pytest.raises(ValueError, match="No relationship store"):
            local_admin.list_relationships("t1")

    def test_delete_raises(self) -> None:
        from open_guard.adapters.stores.memory import InMemoryPolicyStore

        guard = Guard(policy_store=InMemoryPolicyStore())
        local_admin = PolicyAdmin(guard)
        with pytest.raises(ValueError, match="No relationship store"):
            local_admin.delete_relationship("some-id", "t1")
