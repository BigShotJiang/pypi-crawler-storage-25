"""Async OpenGuardClient round-trip via in-process ASGI transport (Phase 10)."""

from __future__ import annotations

import pytest


def _subject(sid: str = "alice", **attrs) -> dict:
    return {"id": sid, "actor_type": "user", "attributes": attrs}


@pytest.mark.asyncio
async def test_async_authorize_round_trip(async_client_with_admin):
    client, _ = async_client_with_admin
    result = await client.decisions.authorize(
        subject=_subject(),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert result["allowed"] is False


@pytest.mark.asyncio
async def test_async_authorize_traced(async_client_with_admin):
    client, _ = async_client_with_admin
    result = await client.decisions.authorize_traced(
        subject=_subject(),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert "trace" in result


@pytest.mark.asyncio
async def test_async_list_authorized(async_client_with_admin):
    client, _ = async_client_with_admin
    result = await client.decisions.list_authorized(
        subject=_subject(),
        action="read",
        resource_type="document",
    )
    assert "resource_ids" in result


@pytest.mark.asyncio
async def test_async_authorize_and_consume(async_client_with_admin):
    client, _ = async_client_with_admin
    result = await client.decisions.authorize_and_consume(
        subject=_subject(),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert "consumed_delegation_ids" in result


@pytest.mark.asyncio
async def test_async_admin_policies_round_trip(async_client_with_admin):
    client, _ = async_client_with_admin
    created = await client.admin.policies.create(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "x"},
        action_match="read",
        resource_match={"resource_type": "doc"},
    )
    pid = created["id"]
    listed = await client.admin.policies.list(tenant_id="t1")
    assert any(p["id"] == pid for p in listed)
    await client.admin.policies.delete(pid, tenant_id="t1")


@pytest.mark.asyncio
async def test_async_admin_relationships_check(async_client_with_admin):
    client, _ = async_client_with_admin
    exists = await client.admin.relationships.check(
        tenant_id="t1",
        subject_id="u1",
        relation="viewer",
        object_type="doc",
        object_id="d1",
    )
    assert exists is False


@pytest.mark.asyncio
async def test_async_admin_health(async_client_with_admin):
    client, _ = async_client_with_admin
    h = await client.admin.health()
    assert h["status"] == "ok"


@pytest.mark.asyncio
async def test_async_admin_roles_assign(async_client_with_admin):
    client, _ = async_client_with_admin
    result = await client.admin.roles.assign(
        tenant_id="t1",
        subject_id="alice",
        role="reader",
        resource_type="document",
        resource_match={"workspace_id": "ws-1"},
        actions=["read"],
    )
    assert result["evaluator_type"] == "rbac"


@pytest.mark.asyncio
async def test_async_admin_relationships_add_then_list(async_client_with_admin):
    client, _ = async_client_with_admin
    await client.admin.relationships.add(
        tenant_id="t1",
        subject_id="u1",
        relation="member",
        object_type="team",
        object_id="t-7",
    )
    listed = await client.admin.relationships.list(
        tenant_id="t1", subject_id="u1"
    )
    assert any(r["object_id"] == "t-7" for r in listed)


@pytest.mark.asyncio
async def test_async_admin_sessions_create_then_list(async_client_with_admin):
    client, _ = async_client_with_admin
    await client.admin.roles.assign(
        tenant_id="t1", subject_id="alice", role="reader"
    )
    created = await client.admin.sessions.create(
        tenant_id="t1",
        subject_id="alice",
        activated_roles=["reader"],
        metadata={"src": "test"},
    )
    listed = await client.admin.sessions.list(
        tenant_id="t1", subject_id="alice"
    )
    assert any(s["id"] == created["id"] for s in listed)
    await client.admin.sessions.deactivate(
        created["id"], tenant_id="t1"
    )


@pytest.mark.asyncio
async def test_async_admin_delegations_list_empty(async_client_with_admin):
    client, _ = async_client_with_admin
    listed = await client.admin.delegations.list(
        tenant_id="t1", subject_id="alice"
    )
    assert listed == []


@pytest.mark.asyncio
async def test_async_admin_policies_get(async_client_with_admin):
    client, _ = async_client_with_admin
    created = await client.admin.policies.create(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "x"},
        action_match="read",
        resource_match={"resource_type": "doc"},
    )
    fetched = await client.admin.policies.get(
        created["id"], tenant_id="t1"
    )
    assert fetched["id"] == created["id"]


@pytest.mark.asyncio
async def test_async_admin_policies_list_by_evaluator(async_client_with_admin):
    client, _ = async_client_with_admin
    await client.admin.policies.create(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "x"},
    )
    abac = await client.admin.policies.list(
        tenant_id="t1", evaluator_type="abac"
    )
    assert all(p["evaluator_type"] == "abac" for p in abac)


@pytest.mark.asyncio
async def test_async_context_manager():
    import httpx

    from open_guard.client.async_client import AsyncOpenGuardClient
    from open_guard.client.base import ApiKey
    from tests.client.conftest import _make_app_and_key

    app, cleartext, _ = _make_app_and_key()
    async with AsyncOpenGuardClient(
        "http://t",
        auth=ApiKey(cleartext),
        transport=httpx.ASGITransport(app=app),
    ) as c:
        result = await c.decisions.authorize(
            subject=_subject(),
            action="read",
            resource={"id": "x", "resource_type": "y"},
        )
        assert "allowed" in result
