"""Sync OpenGuardClient round-trip via in-process ASGI transport (Phase 10)."""

from __future__ import annotations


def _subject(sid: str = "alice", **attrs) -> dict:
    return {"id": sid, "actor_type": "user", "attributes": attrs}


def test_decisions_authorize_round_trip(sync_client_with_admin):
    client, _ = sync_client_with_admin
    result = client.decisions.authorize(
        subject=_subject(),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert result["status"] in ("allowed", "denied")
    assert result["allowed"] is False  # no policies yet


def test_decisions_authorize_allowed_after_admin_create(sync_client_with_admin):
    client, _ = sync_client_with_admin
    client.admin.policies.create(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "reader"},
        action_match="read",
        resource_match={"resource_type": "document"},
    )
    result = client.decisions.authorize(
        subject=_subject(role="reader"),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert result["allowed"] is True


def test_decisions_authorize_traced_returns_trace(sync_client_with_admin):
    client, _ = sync_client_with_admin
    result = client.decisions.authorize_traced(
        subject=_subject(),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert "trace" in result
    assert "decision_status" in result["trace"]


def test_decisions_list_authorized(sync_client_with_admin):
    client, _ = sync_client_with_admin
    result = client.decisions.list_authorized(
        subject=_subject(),
        action="read",
        resource_type="document",
    )
    assert "resource_ids" in result
    assert "next_cursor" in result
    assert isinstance(result["resource_ids"], list)


def test_decisions_authorize_and_consume(sync_client_with_admin):
    client, _ = sync_client_with_admin
    result = client.decisions.authorize_and_consume(
        subject=_subject(),
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert "consumed_delegation_ids" in result


def test_admin_policies_crud_round_trip(sync_client_with_admin):
    client, _ = sync_client_with_admin
    created = client.admin.policies.create(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "x"},
        action_match="read",
        resource_match={"resource_type": "doc"},
    )
    pid = created["id"]
    listed = client.admin.policies.list(tenant_id="t1")
    assert any(p["id"] == pid for p in listed)
    fetched = client.admin.policies.get(pid, tenant_id="t1")
    assert fetched["id"] == pid
    client.admin.policies.delete(pid, tenant_id="t1")


def test_admin_relationships_check_returns_bool(sync_client_with_admin):
    client, _ = sync_client_with_admin
    exists = client.admin.relationships.check(
        tenant_id="t1",
        subject_id="u1",
        relation="viewer",
        object_type="doc",
        object_id="d1",
    )
    assert exists is False


def test_admin_relationships_add_then_check(sync_client_with_admin):
    client, _ = sync_client_with_admin
    client.admin.relationships.add(
        tenant_id="t1",
        subject_id="u1",
        relation="viewer",
        object_type="doc",
        object_id="d1",
    )
    exists = client.admin.relationships.check(
        tenant_id="t1",
        subject_id="u1",
        relation="viewer",
        object_type="doc",
        object_id="d1",
    )
    assert exists is True


def test_admin_health_endpoint(sync_client_with_admin):
    client, _ = sync_client_with_admin
    h = client.admin.health()
    assert h["status"] == "ok"


def test_context_manager_closes_http_client():
    from fastapi.testclient import TestClient

    from open_guard.client.base import ApiKey
    from open_guard.client.sync_client import OpenGuardClient
    from tests.client.conftest import _make_app_and_key

    app, cleartext, _ = _make_app_and_key()
    test_client = TestClient(app, base_url="http://t")
    with OpenGuardClient(
        "http://t",
        auth=ApiKey(cleartext),
        http_client=test_client,
    ) as client:
        assert client.decisions.authorize(
            subject=_subject(),
            action="read",
            resource={"id": "x", "resource_type": "y"},
        )
