"""Shared fixtures for SDK client tests (Phase 10)."""

from __future__ import annotations

import asyncio

import httpx
import pytest
from fastapi.testclient import TestClient

from open_guard import PolicyAdmin, build_guard
from open_guard.client.async_client import AsyncOpenGuardClient
from open_guard.client.base import ApiKey
from open_guard.client.sync_client import OpenGuardClient
from open_guard.service.app import create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def _make_app_and_key():
    guard = build_guard()
    admin = PolicyAdmin(guard)
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    record = ApiKeyRecord(
        key_hash=digest,
        tenant_id="t1",
        service_identity="svc",
    )
    try:
        asyncio.get_running_loop()
        # We're inside an event loop — populate sync (in-memory store
        # _records dict doesn't actually need awaiting for tests).
        store._records[record.key_hash] = record
    except RuntimeError:
        asyncio.run(store.add(record))
    auth = ApiKeyAuth(store)
    app = create_app(guard=guard, admin=admin, auth=auth)
    return app, cleartext, admin


@pytest.fixture
def sync_client_with_admin():
    app, cleartext, admin = _make_app_and_key()
    test_client = TestClient(app, base_url="http://test")
    client = OpenGuardClient(
        "http://test",
        auth=ApiKey(cleartext),
        http_client=test_client,
    )
    yield client, admin
    client.close()


@pytest.fixture
def async_client_with_admin():
    app, cleartext, admin = _make_app_and_key()
    transport = httpx.ASGITransport(app=app)
    client = AsyncOpenGuardClient(
        "http://test",
        auth=ApiKey(cleartext),
        transport=transport,
    )
    yield client, admin
    asyncio.run(client.close())
