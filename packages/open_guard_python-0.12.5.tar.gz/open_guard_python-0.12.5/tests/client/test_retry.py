"""Tests for SDK RetryPolicy behavior (Phase 10)."""

from __future__ import annotations

import httpx
import pytest

from open_guard.client.async_client import AsyncOpenGuardClient
from open_guard.client.base import ApiKey
from open_guard.client.exceptions import ServerError, TransportError
from open_guard.client.retry import RetryPolicy
from open_guard.client.sync_client import OpenGuardClient


def _scripted_handler(responses: list[httpx.Response]):
    state = {"i": 0}

    def handler(_request: httpx.Request) -> httpx.Response:
        i = state["i"]
        state["i"] = i + 1
        return responses[min(i, len(responses) - 1)]

    return handler


def _ok_response() -> httpx.Response:
    return httpx.Response(200, json={"status": "allowed", "allowed": True})


def _503() -> httpx.Response:
    return httpx.Response(
        503,
        json={"error": {"code": "service_unavailable", "message": "boom"}},
    )


def test_sync_retries_5xx_until_success():
    responses = [_503(), _503(), _ok_response()]
    transport = httpx.MockTransport(_scripted_handler(responses))
    client = OpenGuardClient(
        "http://t",
        auth=ApiKey("og_x"),
        transport=transport,
        retry=RetryPolicy(attempts=3, base_delay=0.0, max_delay=0.0),
    )
    result = client.decisions.authorize(
        subject={"id": "a"},
        action="read",
        resource={"id": "r", "resource_type": "doc"},
    )
    assert result["allowed"] is True


def test_sync_gives_up_after_attempts():
    responses = [_503(), _503(), _503()]
    transport = httpx.MockTransport(_scripted_handler(responses))
    client = OpenGuardClient(
        "http://t",
        auth=ApiKey("og_x"),
        transport=transport,
        retry=RetryPolicy(attempts=3, base_delay=0.0, max_delay=0.0),
    )
    with pytest.raises(ServerError) as exc:
        client.decisions.authorize(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    assert exc.value.status_code == 503


def test_non_idempotent_skips_retries_by_default():
    responses = [_503(), _ok_response(), _ok_response()]
    transport = httpx.MockTransport(_scripted_handler(responses))
    client = OpenGuardClient(
        "http://t",
        auth=ApiKey("og_x"),
        transport=transport,
        retry=RetryPolicy(attempts=3, base_delay=0.0, max_delay=0.0),
    )
    with pytest.raises(ServerError) as exc:
        client.decisions.authorize_and_consume(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    assert exc.value.status_code == 503


def test_sync_transport_error_raises_transport_error():
    def handler(_r: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused")

    client = OpenGuardClient(
        "http://t",
        auth=ApiKey("og_x"),
        transport=httpx.MockTransport(handler),
        retry=RetryPolicy(attempts=2, base_delay=0.0, max_delay=0.0),
    )
    with pytest.raises(TransportError):
        client.decisions.authorize(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )


@pytest.mark.asyncio
async def test_async_retries_5xx():
    responses = [_503(), _ok_response()]
    transport = httpx.MockTransport(_scripted_handler(responses))
    client = AsyncOpenGuardClient(
        "http://t",
        auth=ApiKey("og_x"),
        transport=transport,
        retry=RetryPolicy(attempts=3, base_delay=0.0, max_delay=0.0),
    )
    try:
        result = await client.decisions.authorize(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    finally:
        await client.close()
    assert result["allowed"] is True
