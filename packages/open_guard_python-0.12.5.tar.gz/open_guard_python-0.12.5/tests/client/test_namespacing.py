"""Verify the namespaced API does not expose flat shortcuts (Phase 10)."""

from __future__ import annotations

import httpx

from open_guard.client.async_client import AsyncOpenGuardClient
from open_guard.client.base import ApiKey
from open_guard.client.namespaces.admin import (
    AdminAPI,
    AsyncAdminAPI,
)
from open_guard.client.namespaces.decisions import (
    AsyncDecisionsAPI,
    DecisionsAPI,
)
from open_guard.client.sync_client import OpenGuardClient


def _make_clients():
    transport_sync = httpx.MockTransport(lambda r: httpx.Response(200, json={}))
    transport_async = httpx.MockTransport(lambda r: httpx.Response(200, json={}))
    sync_c = OpenGuardClient(
        "http://t", auth=ApiKey("og_x"), transport=transport_sync
    )
    async_c = AsyncOpenGuardClient(
        "http://t", auth=ApiKey("og_x"), transport=transport_async
    )
    return sync_c, async_c


def test_decisions_namespace_present():
    sync_c, async_c = _make_clients()
    assert isinstance(sync_c.decisions, DecisionsAPI)
    assert isinstance(async_c.decisions, AsyncDecisionsAPI)


def test_admin_namespace_present():
    sync_c, async_c = _make_clients()
    assert isinstance(sync_c.admin, AdminAPI)
    assert isinstance(async_c.admin, AsyncAdminAPI)
    assert hasattr(sync_c.admin, "policies")
    assert hasattr(sync_c.admin, "roles")
    assert hasattr(sync_c.admin, "relationships")
    assert hasattr(sync_c.admin, "delegations")
    assert hasattr(sync_c.admin, "sessions")


def test_no_flat_authorize_shortcut():
    sync_c, async_c = _make_clients()
    assert not hasattr(sync_c, "authorize")
    assert not hasattr(async_c, "authorize")


def test_decisions_methods_exist():
    sync_c, _ = _make_clients()
    for m in (
        "authorize",
        "authorize_traced",
        "list_authorized",
        "authorize_and_consume",
    ):
        assert hasattr(sync_c.decisions, m)


def test_admin_relationships_check_method_exists():
    sync_c, async_c = _make_clients()
    assert hasattr(sync_c.admin.relationships, "check")
    assert hasattr(async_c.admin.relationships, "check")
