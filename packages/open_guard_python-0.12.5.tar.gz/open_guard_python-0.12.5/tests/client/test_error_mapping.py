"""Verify HTTP status → typed exception mapping (Phase 10)."""

from __future__ import annotations

import httpx
import pytest

from open_guard.client.base import ApiKey
from open_guard.client.exceptions import (
    AuthenticationError,
    AuthorizationServiceError,
    NotFoundError,
    OpenGuardError,
    RateLimitedError,
    ServerError,
    ValidationError,
)
from open_guard.client.retry import RetryPolicy
from open_guard.client.sync_client import OpenGuardClient


def _client_with_response(resp: httpx.Response) -> OpenGuardClient:
    return OpenGuardClient(
        "http://t",
        auth=ApiKey("og_x"),
        transport=httpx.MockTransport(lambda _r: resp),
        retry=RetryPolicy(attempts=1, base_delay=0.0, max_delay=0.0),
    )


@pytest.mark.parametrize(
    ("status", "exc_cls", "code"),
    [
        (401, AuthenticationError, "missing_api_key"),
        (403, AuthorizationServiceError, "forbidden"),
        (404, NotFoundError, "not_found"),
        (422, ValidationError, "validation_error"),
        (429, RateLimitedError, "rate_limited"),
        (500, ServerError, "internal_error"),
        (502, ServerError, "bad_gateway"),
    ],
)
def test_status_maps_to_exception(status, exc_cls, code):
    body = {"error": {"code": code, "message": "x", "details": None}}
    client = _client_with_response(httpx.Response(status, json=body))
    with pytest.raises(exc_cls) as exc:
        client.decisions.authorize(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    assert exc.value.code == code
    assert exc.value.status_code == status


def test_unknown_status_raises_base_error():
    client = _client_with_response(httpx.Response(418, json={}))
    with pytest.raises(OpenGuardError) as exc:
        client.decisions.authorize(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    assert exc.value.status_code == 418


def test_message_falls_back_when_envelope_missing():
    client = _client_with_response(httpx.Response(403, json={}))
    with pytest.raises(AuthorizationServiceError) as exc:
        client.decisions.authorize(
            subject={"id": "a"},
            action="read",
            resource={"id": "r", "resource_type": "doc"},
        )
    assert "HTTP 403" in str(exc.value)
