"""Tests for client auth helpers (Phase 10 — Task 7)."""

from __future__ import annotations

from open_guard.client.base import ApiKey, BearerToken, ClientAuth


def test_api_key_helper_sets_authorization_header():
    auth = ApiKey("og_secret")
    assert isinstance(auth, ClientAuth)
    assert auth.header_name == "Authorization"
    assert auth.header_value == "ApiKey og_secret"


def test_bearer_token_helper_sets_authorization_header():
    auth = BearerToken("eyJabc")
    assert auth.header_value == "Bearer eyJabc"


def test_client_auth_is_immutable():
    auth = ApiKey("k")
    try:
        auth.header_name = "X"  # type: ignore[misc]
    except AttributeError:
        return
    raise AssertionError("ClientAuth should be frozen")
