"""Tests for AdminRouter mounted via create_app (Phase 10 — Task 5)."""

from __future__ import annotations

import asyncio

from fastapi.testclient import TestClient

from open_guard import PolicyAdmin, build_guard
from open_guard.service.app import ServiceConfig, create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def _make(prefix: str = "/v1"):
    guard = build_guard()
    admin = PolicyAdmin(guard)
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc",
            )
        )
    )
    auth = ApiKeyAuth(store)
    app = create_app(
        guard=guard,
        admin=admin,
        auth=auth,
        config=ServiceConfig(prefix=prefix),
    )
    return TestClient(app), cleartext


def _hdr(key: str) -> dict[str, str]:
    return {"Authorization": f"ApiKey {key}"}


def test_admin_policies_endpoint_under_default_prefix():
    client, key = _make()
    r = client.post(
        "/v1/admin/policies",
        headers=_hdr(key),
        json={
            "tenant_id": "t1",
            "evaluator_type": "abac",
            "subject_match": {"role": "reader"},
            "action_match": "read",
            "resource_match": {"resource_type": "doc"},
        },
    )
    assert r.status_code == 201
    body = r.json()
    assert body["evaluator_type"] == "abac"


def test_admin_endpoints_require_auth():
    client, _ = _make()
    r = client.get("/v1/admin/policies?tenant_id=t1")
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "missing_api_key"


def test_admin_health_endpoint_works():
    client, key = _make()
    r = client.get("/v1/admin/health", headers=_hdr(key))
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"


def test_admin_endpoint_under_custom_prefix():
    client, key = _make(prefix="/openguard/v1")
    r = client.get(
        "/openguard/v1/admin/health", headers=_hdr(key)
    )
    assert r.status_code == 200


def test_admin_relationships_check_endpoint():
    client, key = _make()
    r = client.post(
        "/v1/admin/relationships/check",
        headers=_hdr(key),
        json={
            "tenant_id": "t1",
            "subject_id": "u1",
            "subject_type": "user",
            "relation": "viewer",
            "object_type": "doc",
            "object_id": "d1",
        },
    )
    assert r.status_code == 200
    assert r.json() == {"exists": False}
