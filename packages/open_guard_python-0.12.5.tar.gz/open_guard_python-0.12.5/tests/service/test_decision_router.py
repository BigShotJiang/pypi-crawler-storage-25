"""Tests for DecisionRouter (Phase 10 — Task 4)."""

from __future__ import annotations

import asyncio

from fastapi.testclient import TestClient

from open_guard import (
    PolicyAdmin,
    build_async_guard,
    build_guard,
)
from open_guard.service.app import create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def _make_service(*, async_guard: bool = False):
    if async_guard:
        guard = asyncio.run(build_async_guard())
        admin = None
    else:
        guard = build_guard()
        admin = PolicyAdmin(guard)
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc",
            )
        )
    )
    auth = ApiKeyAuth(store)
    app = create_app(guard=guard, admin=admin, auth=auth)
    client = TestClient(app)
    return client, cleartext, guard, admin


def _subject_dict(sid: str = "alice", **attrs) -> dict:
    return {"id": sid, "actor_type": "user", "attributes": attrs or {}}


def _action_dict(name: str = "read") -> dict:
    return {"name": name}


def _resource_dict(rid: str = "doc-1", rtype: str = "document") -> dict:
    return {"id": rid, "resource_type": rtype}


def _hdr(key: str) -> dict[str, str]:
    return {"Authorization": f"ApiKey {key}"}


def test_authorize_denied_by_default():
    client, key, _, _ = _make_service()
    r = client.post(
        "/v1/authorize",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(),
            "action": _action_dict(),
            "resource": _resource_dict(),
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "denied"
    assert body["allowed"] is False


def test_authorize_allowed_after_policy_create():
    client, key, _, admin = _make_service()
    admin.create_policy(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "reader"},
        action_match="read",
        resource_match={"resource_type": "document"},
        effect="allow",
    )
    r = client.post(
        "/v1/authorize",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(attributes={"role": "reader"}),
            "action": _action_dict("read"),
            "resource": _resource_dict(),
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["allowed"] is True
    assert body["status"] == "allowed"


def test_authorize_traced_returns_trace_dict():
    client, key, _, _ = _make_service()
    r = client.post(
        "/v1/authorize/traced",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(),
            "action": _action_dict(),
            "resource": _resource_dict(),
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert "trace" in body
    assert isinstance(body["trace"], dict)
    assert "decision_status" in body["trace"]


def test_authorize_missing_auth_returns_401():
    client, _, _, _ = _make_service()
    r = client.post(
        "/v1/authorize",
        json={
            "subject": _subject_dict(),
            "action": _action_dict(),
            "resource": _resource_dict(),
        },
    )
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "missing_api_key"


def test_authorize_malformed_body_returns_422():
    client, key, _, _ = _make_service()
    r = client.post("/v1/authorize", headers=_hdr(key), json={})
    assert r.status_code == 422
    assert r.json()["error"]["code"] == "validation_error"


def test_list_authorized_returns_resource_ids_and_cursor_field():
    client, key, _, admin = _make_service()
    admin.create_policy(
        tenant_id="t1",
        evaluator_type="rbac",
        subject_match={"role": "reader"},
        action_match="read",
        resource_match={"resource_type": "document"},
    )
    r = client.post(
        "/v1/list_authorized",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(attributes={"role": "reader"}),
            "action": "read",
            "resource_type": "document",
            "limit": 100,
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert "resource_ids" in body
    assert isinstance(body["resource_ids"], list)
    assert "next_cursor" in body


def test_authorize_and_consume_decrements_delegation_budget():
    client, key, _guard, _admin = _make_service()
    # Without a delegation, route still works and returns no consumed ids.
    r = client.post(
        "/v1/authorize_and_consume",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(),
            "action": _action_dict(),
            "resource": _resource_dict(),
            "amount": 1,
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert "consumed_delegation_ids" in body
    assert isinstance(body["consumed_delegation_ids"], list)


def test_async_guard_list_authorized_works():
    """Phase 11 (FEAT-018): AsyncGuard.list_authorized is reachable over HTTP."""
    client, key, _, _ = _make_service(async_guard=True)
    r = client.post(
        "/v1/list_authorized",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(),
            "action": "read",
            "resource_type": "document",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert "resource_ids" in body
    assert isinstance(body["resource_ids"], list)


def test_async_guard_authorize_and_consume_works():
    """Phase 11 (FEAT-014): AsyncGuard.authorize_and_consume reachable over HTTP."""
    client, key, _, _ = _make_service(async_guard=True)
    r = client.post(
        "/v1/authorize_and_consume",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(),
            "action": _action_dict(),
            "resource": _resource_dict(),
        },
    )
    assert r.status_code == 200
    body = r.json()
    # Denied by default (no policy / no delegation), but the endpoint is wired
    assert body["status"] in ("denied", "allowed", "pending_approval")
    assert "consumed_delegation_ids" in body
    assert isinstance(body["consumed_delegation_ids"], list)


def test_async_guard_authorize_works():
    client, key, _, _ = _make_service(async_guard=True)
    r = client.post(
        "/v1/authorize",
        headers=_hdr(key),
        json={
            "subject": _subject_dict(),
            "action": _action_dict(),
            "resource": _resource_dict(),
        },
    )
    assert r.status_code == 200
    assert r.json()["allowed"] is False
