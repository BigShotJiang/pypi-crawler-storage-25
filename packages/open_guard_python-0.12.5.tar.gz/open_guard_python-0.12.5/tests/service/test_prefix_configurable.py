"""Verify any prefix mounts cleanly (Phase 10 — Task 5)."""

from __future__ import annotations

import asyncio

import pytest

from open_guard import PolicyAdmin, build_guard
from open_guard.service.app import ServiceConfig, create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


@pytest.mark.parametrize(
    "prefix",
    ["/v1", "/v2/foo", "/openguard/v1", "/api/auth/v1"],
)
def test_prefix_variants(prefix: str):
    guard = build_guard()
    admin = PolicyAdmin(guard)
    store = InMemoryApiKeyStore()
    _, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc",
            )
        )
    )
    app = create_app(
        guard=guard,
        admin=admin,
        auth=ApiKeyAuth(store),
        config=ServiceConfig(prefix=prefix),
    )
    paths = app.openapi()["paths"]
    assert f"{prefix}/authorize" in paths
    assert f"{prefix}/admin/policies" in paths
    assert f"{prefix}/admin/health" in paths
