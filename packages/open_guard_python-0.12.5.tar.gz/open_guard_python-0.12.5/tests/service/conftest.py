"""Shared fixtures for service-mode tests (Phase 10)."""

from __future__ import annotations

import pytest

from open_guard import (
    Action,
    PolicyAdmin,
    Resource,
    Subject,
    build_guard,
)
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


@pytest.fixture
def guard():
    return build_guard()


@pytest.fixture
def admin(guard) -> PolicyAdmin:
    return PolicyAdmin(guard)


@pytest.fixture
async def api_key_store_with_key():
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    await store.add(
        ApiKeyRecord(
            key_hash=digest,
            tenant_id="t1",
            service_identity="svc-test",
            scopes=[],
        )
    )
    return store, cleartext


@pytest.fixture
async def admin_api_key_store():
    """Store with a regular and a cross-tenant-admin key."""
    store = InMemoryApiKeyStore()
    keys: dict[str, str] = {}

    cleartext_t1, digest_t1 = ApiKeyAuth.generate()
    await store.add(
        ApiKeyRecord(
            key_hash=digest_t1,
            tenant_id="t1",
            service_identity="svc-t1",
            scopes=[],
        )
    )
    keys["t1"] = cleartext_t1

    cleartext_admin, digest_admin = ApiKeyAuth.generate()
    await store.add(
        ApiKeyRecord(
            key_hash=digest_admin,
            tenant_id="t1",
            service_identity="svc-admin",
            scopes=["cross_tenant_admin"],
        )
    )
    keys["admin"] = cleartext_admin

    return store, keys


def make_subject(subject_id: str = "alice") -> Subject:
    return Subject(id=subject_id, attributes={"role": "user"})


def make_action(name: str = "read") -> Action:
    return Action(name=name)


def make_resource(rid: str = "doc-1", rtype: str = "document") -> Resource:
    return Resource(id=rid, resource_type=rtype, attributes={})
