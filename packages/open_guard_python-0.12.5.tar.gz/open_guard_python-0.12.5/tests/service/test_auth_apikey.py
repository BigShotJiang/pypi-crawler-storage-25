"""Tests for ApiKeyAuth + InMemoryApiKeyStore (Phase 10 — Task 2)."""

from __future__ import annotations

import hashlib

import pytest
from fastapi import Request

from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)
from open_guard.service.errors import AuthenticationError


def _request_with_header(value: str | None) -> Request:
    headers: list[tuple[bytes, bytes]] = []
    if value is not None:
        headers.append((b"authorization", value.encode()))
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/v1/authorize",
        "headers": headers,
    }
    return Request(scope)  # type: ignore[arg-type]


def test_generate_returns_cleartext_and_hash():
    cleartext, digest = ApiKeyAuth.generate()
    assert cleartext.startswith("og_")
    assert digest == hashlib.sha256(cleartext.encode()).hexdigest()
    assert digest != cleartext


@pytest.mark.asyncio
async def test_authenticate_valid_key_returns_caller_context():
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    await store.add(
        ApiKeyRecord(
            key_hash=digest,
            tenant_id="t1",
            service_identity="svc",
            scopes=["read"],
        )
    )
    auth = ApiKeyAuth(store)
    ctx = await auth.authenticate(_request_with_header(f"ApiKey {cleartext}"))
    assert ctx.tenant_id == "t1"
    assert ctx.service_identity == "svc"
    assert ctx.has_scope("read")


@pytest.mark.asyncio
async def test_missing_header_raises():
    auth = ApiKeyAuth(InMemoryApiKeyStore())
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header(None))
    assert exc.value.code == "missing_api_key"
    assert exc.value.status_code == 401


@pytest.mark.asyncio
async def test_malformed_header_raises():
    auth = ApiKeyAuth(InMemoryApiKeyStore())
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header("Bearer abc"))
    assert exc.value.code == "missing_api_key"


@pytest.mark.asyncio
async def test_unknown_key_raises():
    store = InMemoryApiKeyStore()
    auth = ApiKeyAuth(store)
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header("ApiKey og_unknown"))
    assert exc.value.code == "invalid_api_key"


@pytest.mark.asyncio
async def test_revoked_key_raises():
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    await store.add(
        ApiKeyRecord(
            key_hash=digest,
            tenant_id="t1",
            service_identity="svc",
        )
    )
    await store.revoke(digest)
    auth = ApiKeyAuth(store)
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header(f"ApiKey {cleartext}"))
    assert exc.value.code == "invalid_api_key"


@pytest.mark.asyncio
async def test_empty_key_after_prefix_raises():
    auth = ApiKeyAuth(InMemoryApiKeyStore())
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header("ApiKey "))
    assert exc.value.code == "missing_api_key"


@pytest.mark.asyncio
async def test_list_for_tenant():
    store = InMemoryApiKeyStore()
    _, digest_a = ApiKeyAuth.generate()
    _, digest_b = ApiKeyAuth.generate()
    _, digest_c = ApiKeyAuth.generate()
    await store.add(
        ApiKeyRecord(key_hash=digest_a, tenant_id="t1", service_identity="a")
    )
    await store.add(
        ApiKeyRecord(key_hash=digest_b, tenant_id="t1", service_identity="b")
    )
    await store.add(
        ApiKeyRecord(key_hash=digest_c, tenant_id="t2", service_identity="c")
    )
    t1 = await store.list_for_tenant("t1")
    assert len(t1) == 2
    assert {r.service_identity for r in t1} == {"a", "b"}
