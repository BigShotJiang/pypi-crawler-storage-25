"""Tenant context + cross_tenant_admin override tests (Phase 10 — Task 3)."""

from __future__ import annotations

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)
from open_guard.service.errors import install_exception_handlers
from open_guard.service.tenant import (
    CROSS_TENANT_ADMIN_SCOPE,
    TENANT_OVERRIDE_HEADER,
    make_tenant_dep,
)


def _make_app(auth) -> FastAPI:
    app = FastAPI()
    install_exception_handlers(app)
    tenant_dep = make_tenant_dep(auth)

    @app.get("/whoami")
    async def whoami(ctx=Depends(tenant_dep)) -> dict:
        caller, tenant_id = ctx
        return {
            "tenant_id": tenant_id,
            "caller_tenant": caller.tenant_id,
            "scopes": sorted(caller.scopes),
        }

    return app


@pytest.fixture
def setup():
    import asyncio

    store = InMemoryApiKeyStore()
    cleartext_t1, digest_t1 = ApiKeyAuth.generate()
    cleartext_admin, digest_admin = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest_t1,
                tenant_id="t1",
                service_identity="svc-t1",
            )
        )
    )
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest_admin,
                tenant_id="t1",
                service_identity="svc-admin",
                scopes=[CROSS_TENANT_ADMIN_SCOPE],
            )
        )
    )
    auth = ApiKeyAuth(store)
    return TestClient(_make_app(auth)), cleartext_t1, cleartext_admin


def test_no_override_returns_caller_tenant(setup):
    client, key, _ = setup
    r = client.get("/whoami", headers={"Authorization": f"ApiKey {key}"})
    assert r.status_code == 200
    body = r.json()
    assert body["tenant_id"] == "t1"
    assert body["caller_tenant"] == "t1"


def test_matching_override_is_accepted(setup):
    client, key, _ = setup
    r = client.get(
        "/whoami",
        headers={
            "Authorization": f"ApiKey {key}",
            TENANT_OVERRIDE_HEADER: "t1",
        },
    )
    assert r.status_code == 200
    assert r.json()["tenant_id"] == "t1"


def test_mismatched_override_without_scope_is_403(setup):
    client, key, _ = setup
    r = client.get(
        "/whoami",
        headers={
            "Authorization": f"ApiKey {key}",
            TENANT_OVERRIDE_HEADER: "t2",
        },
    )
    assert r.status_code == 403
    body = r.json()
    assert body["error"]["code"] == "cross_tenant_forbidden"


def test_mismatched_override_with_scope_is_honored(setup):
    client, _, admin_key = setup
    r = client.get(
        "/whoami",
        headers={
            "Authorization": f"ApiKey {admin_key}",
            TENANT_OVERRIDE_HEADER: "t9",
        },
    )
    assert r.status_code == 200
    body = r.json()
    assert body["tenant_id"] == "t9"
    assert body["caller_tenant"] == "t1"


def test_unauthenticated_returns_401(setup):
    client, _, _ = setup
    r = client.get("/whoami")
    assert r.status_code == 401
    assert r.json()["error"]["code"] == "missing_api_key"
