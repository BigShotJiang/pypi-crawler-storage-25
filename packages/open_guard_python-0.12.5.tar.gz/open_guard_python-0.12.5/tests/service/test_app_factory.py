"""Tests for create_app() + ServiceConfig (Phase 10 — Task 1)."""

from __future__ import annotations

import pytest
from fastapi import FastAPI

from open_guard.service.app import ServiceConfig, create_app
from open_guard.service.auth import ApiKeyAuth, InMemoryApiKeyStore


def _auth() -> ApiKeyAuth:
    return ApiKeyAuth(InMemoryApiKeyStore())


def test_create_app_returns_fastapi(guard):
    app = create_app(guard=guard, auth=_auth())
    assert isinstance(app, FastAPI)


def test_create_app_requires_guard():
    with pytest.raises(TypeError):
        create_app(guard=None, auth=_auth())  # type: ignore[arg-type]


def test_create_app_requires_auth(guard):
    with pytest.raises(TypeError):
        create_app(guard=guard, auth=None)  # type: ignore[arg-type]


def test_openapi_lists_decision_endpoints(guard):
    app = create_app(guard=guard, auth=_auth())
    paths = app.openapi()["paths"]
    assert "/v1/authorize" in paths
    assert "/v1/authorize/traced" in paths
    assert "/v1/list_authorized" in paths
    assert "/v1/authorize_and_consume" in paths


def test_admin_router_mounted_when_admin_provided(guard, admin):
    app = create_app(guard=guard, admin=admin, auth=_auth())
    paths = app.openapi()["paths"]
    assert "/v1/admin/policies" in paths


def test_admin_router_omitted_when_admin_none(guard):
    app = create_app(guard=guard, auth=_auth())
    paths = app.openapi()["paths"]
    assert not any(p.startswith("/v1/admin/") for p in paths)


def test_expose_admin_false_omits_admin_routes(guard, admin):
    app = create_app(
        guard=guard,
        admin=admin,
        auth=_auth(),
        config=ServiceConfig(expose_admin=False),
    )
    paths = app.openapi()["paths"]
    assert not any(p.startswith("/v1/admin/") for p in paths)


def test_custom_prefix_is_honored(guard, admin):
    cfg = ServiceConfig(prefix="/openguard/v1")
    app = create_app(guard=guard, admin=admin, auth=_auth(), config=cfg)
    paths = app.openapi()["paths"]
    assert "/openguard/v1/authorize" in paths
    assert "/openguard/v1/admin/policies" in paths


def test_v2_prefix_works(guard):
    cfg = ServiceConfig(prefix="/v2/foo")
    app = create_app(guard=guard, auth=_auth(), config=cfg)
    paths = app.openapi()["paths"]
    assert "/v2/foo/authorize" in paths


def test_async_guard_registers_all_decision_endpoints():
    """Phase 11 (FEAT-018 / FEAT-014): AsyncGuard registers list_authorized
    and authorize_and_consume just like sync Guard."""
    import asyncio

    from open_guard import build_async_guard

    guard = asyncio.run(build_async_guard())
    app = create_app(guard=guard, auth=_auth())
    paths = app.openapi()["paths"]
    assert "/v1/authorize" in paths
    assert "/v1/authorize/traced" in paths
    assert "/v1/list_authorized" in paths
    assert "/v1/authorize_and_consume" in paths
