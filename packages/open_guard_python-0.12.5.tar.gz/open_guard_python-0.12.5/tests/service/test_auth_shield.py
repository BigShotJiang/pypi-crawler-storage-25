"""Tests for ShieldAuth (Phase 10 — Task 2). Skipped when open-shield not installed."""

from __future__ import annotations

from typing import Any

import pytest
from fastapi import Request

pytest.importorskip("open_shield")

from open_guard.service.auth.shield import ShieldAuth
from open_guard.service.errors import AuthenticationError


def _request_with_header(value: str | None) -> Request:
    headers: list[tuple[bytes, bytes]] = []
    if value is not None:
        headers.append((b"authorization", value.encode()))
    return Request(
        {
            "type": "http",
            "method": "POST",
            "path": "/v1/authorize",
            "headers": headers,
        }
    )  # type: ignore[arg-type]


class _MockToken:
    def __init__(self, claims: dict[str, Any]) -> None:
        self.claims = claims


class _MockValidator:
    def __init__(self, claims: dict[str, Any] | None = None, raise_exc: bool = False):
        self._claims = claims or {}
        self._raise = raise_exc

    def validate_token(self, token_string: str):
        if self._raise:
            raise ValueError("bad token")
        return _MockToken(self._claims)

    def decode_unverified(self, token_string: str) -> dict[str, Any]:
        return self._claims


@pytest.mark.asyncio
async def test_valid_token_returns_caller_context():
    validator = _MockValidator(
        claims={"tenant_id": "t1", "sub": "svc-x", "scope": "read write"}
    )
    auth = ShieldAuth(validator)
    ctx = await auth.authenticate(_request_with_header("Bearer eyJ..."))
    assert ctx.tenant_id == "t1"
    assert ctx.service_identity == "svc-x"
    assert ctx.has_scope("read")
    assert ctx.has_scope("write")


@pytest.mark.asyncio
async def test_scopes_as_list_claim():
    validator = _MockValidator(
        claims={"tenant_id": "t1", "sub": "svc", "scope": ["a", "b"]}
    )
    auth = ShieldAuth(validator)
    ctx = await auth.authenticate(_request_with_header("Bearer t"))
    assert ctx.scopes == frozenset({"a", "b"})


@pytest.mark.asyncio
async def test_missing_bearer_header_raises():
    auth = ShieldAuth(_MockValidator())
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header(None))
    assert exc.value.code == "missing_bearer_token"


@pytest.mark.asyncio
async def test_wrong_scheme_raises():
    auth = ShieldAuth(_MockValidator())
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header("ApiKey x"))
    assert exc.value.code == "missing_bearer_token"


@pytest.mark.asyncio
async def test_validator_failure_raises():
    auth = ShieldAuth(_MockValidator(raise_exc=True))
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header("Bearer bad"))
    assert exc.value.code == "invalid_token"


@pytest.mark.asyncio
async def test_missing_claims_raises():
    validator = _MockValidator(claims={"sub": "svc"})  # no tenant_id
    auth = ShieldAuth(validator)
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request_with_header("Bearer t"))
    assert exc.value.code == "missing_required_claims"


@pytest.mark.asyncio
async def test_custom_claim_names():
    validator = _MockValidator(
        claims={"org": "t9", "client_id": "svc", "scp": "x"}
    )
    auth = ShieldAuth(
        validator,
        tenant_claim="org",
        identity_claim="client_id",
        scopes_claim="scp",
    )
    ctx = await auth.authenticate(_request_with_header("Bearer t"))
    assert ctx.tenant_id == "t9"
    assert ctx.service_identity == "svc"
    assert ctx.has_scope("x")
