"""Tests for error envelope + exception handlers (Phase 10 — Task 6)."""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel

from open_guard.service.errors import (
    AuthenticationError,
    AuthorizationServiceError,
    NotFoundError,
    ServiceError,
    install_exception_handlers,
)


def _app() -> FastAPI:
    app = FastAPI()
    install_exception_handlers(app)

    class Body(BaseModel):
        x: int

    @app.post("/auth_err")
    def _auth_err() -> None:
        raise AuthenticationError("missing", code="missing_thing")

    @app.post("/forbidden")
    def _forbidden() -> None:
        raise AuthorizationServiceError("nope", code="not_allowed")

    @app.post("/not_found")
    def _not_found() -> None:
        raise NotFoundError("absent", code="absent_thing")

    @app.post("/internal")
    def _internal() -> None:
        raise ServiceError(
            "boom", code="custom_internal", status_code=500
        )

    @app.post("/with_details")
    def _with_details() -> None:
        raise ServiceError(
            "bad",
            code="bad_input",
            status_code=400,
            details={"field": "value"},
        )

    @app.post("/validate")
    def _validate(body: Body) -> dict:
        return {"x": body.x}

    @app.get("/unhandled")
    def _unhandled() -> None:
        raise RuntimeError("internal secret leak should not appear")

    return app


def _client() -> TestClient:
    return TestClient(_app(), raise_server_exceptions=False)


def test_authentication_error_returns_401_envelope():
    r = _client().post("/auth_err")
    assert r.status_code == 401
    body = r.json()
    assert body == {
        "error": {
            "code": "missing_thing",
            "message": "missing",
            "details": None,
        }
    }


def test_authorization_service_error_returns_403_envelope():
    r = _client().post("/forbidden")
    assert r.status_code == 403
    assert r.json()["error"]["code"] == "not_allowed"


def test_not_found_returns_404_envelope():
    r = _client().post("/not_found")
    assert r.status_code == 404
    assert r.json()["error"]["code"] == "absent_thing"


def test_service_error_default_500_envelope():
    r = _client().post("/internal")
    assert r.status_code == 500
    assert r.json()["error"]["code"] == "custom_internal"


def test_details_round_trip():
    r = _client().post("/with_details")
    assert r.status_code == 400
    assert r.json()["error"]["details"] == {"field": "value"}


def test_validation_error_returns_422_envelope():
    r = _client().post("/validate", json={"x": "not_int"})
    assert r.status_code == 422
    body = r.json()
    assert body["error"]["code"] == "validation_error"
    assert "errors" in body["error"]["details"]


def test_unhandled_exception_hides_traceback():
    r = _client().get("/unhandled")
    assert r.status_code == 500
    body = r.json()
    assert body["error"]["code"] == "internal_error"
    assert "secret" not in body["error"]["message"]
