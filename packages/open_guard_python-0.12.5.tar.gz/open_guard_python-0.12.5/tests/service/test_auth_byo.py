"""Tests for CallableAuth (Phase 10 — Task 2)."""

from __future__ import annotations

import pytest
from fastapi import Request

from open_guard.service.auth import CallableAuth, CallerContext
from open_guard.service.errors import AuthenticationError


def _request() -> Request:
    return Request(
        {"type": "http", "method": "POST", "path": "/", "headers": []}
    )  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_callable_auth_returns_context():
    async def fn(_: Request) -> CallerContext:
        return CallerContext(
            tenant_id="t1",
            service_identity="svc",
            scopes=frozenset({"read"}),
        )

    auth = CallableAuth(fn)
    ctx = await auth.authenticate(_request())
    assert ctx.tenant_id == "t1"
    assert ctx.service_identity == "svc"
    assert ctx.has_scope("read")


@pytest.mark.asyncio
async def test_callable_auth_can_raise():
    async def fn(_: Request) -> CallerContext:
        raise AuthenticationError("custom failure", code="custom_failure")

    auth = CallableAuth(fn)
    with pytest.raises(AuthenticationError) as exc:
        await auth.authenticate(_request())
    assert exc.value.code == "custom_failure"
