"""End-to-end: SDK → service → sqlite+aiosqlite async backend (Phase 10 — Task 9)."""

from __future__ import annotations

import asyncio
import os
import tempfile

import pytest
from fastapi.testclient import TestClient

from open_guard import build_async_guard
from open_guard.client.base import ApiKey
from open_guard.client.sync_client import OpenGuardClient
from open_guard.service.app import create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def _make_async_service():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    dsn = f"sqlite+aiosqlite:///{path}"
    guard = asyncio.run(build_async_guard(dsn=dsn))
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc",
            )
        )
    )
    app = create_app(guard=guard, auth=ApiKeyAuth(store))
    test_client = TestClient(app, base_url="http://e2e")
    sdk = OpenGuardClient(
        "http://e2e", auth=ApiKey(cleartext), http_client=test_client
    )
    return sdk, path


def test_async_sql_authorize_round_trip():
    sdk, path = _make_async_service()
    try:
        result = sdk.decisions.authorize(
            subject={"id": "u", "actor_type": "user"},
            action="read",
            resource={"id": "r", "resource_type": "document"},
        )
        # No policies yet — denied.
        assert result["allowed"] is False
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_async_sql_authorize_traced_round_trip():
    sdk, path = _make_async_service()
    try:
        result = sdk.decisions.authorize_traced(
            subject={"id": "u", "actor_type": "user"},
            action="read",
            resource={"id": "r", "resource_type": "document"},
        )
        assert "trace" in result
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_async_sql_list_authorized_works():
    """Phase 11 (FEAT-018): AsyncGuard.list_authorized over async SQL backend."""
    sdk, path = _make_async_service()
    try:
        result = sdk.decisions.list_authorized(
            subject={"id": "u", "actor_type": "user"},
            action="read",
            resource_type="document",
        )
        # Empty result (no policies / no relationships seeded), but the
        # endpoint is reachable and returns a valid response shape.
        assert "resource_ids" in result
        assert isinstance(result["resource_ids"], list)
    finally:
        if os.path.exists(path):
            os.remove(path)
