"""End-to-end: SDK → service → in-memory backend (Phase 10 — Task 9)."""

from __future__ import annotations

import asyncio

from fastapi.testclient import TestClient

from open_guard import PolicyAdmin, build_guard
from open_guard.client.base import ApiKey
from open_guard.client.sync_client import OpenGuardClient
from open_guard.service.app import create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def _bootstrap():
    guard = build_guard()
    admin = PolicyAdmin(guard)
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=digest,
                tenant_id="t1",
                service_identity="svc",
            )
        )
    )
    app = create_app(guard=guard, admin=admin, auth=ApiKeyAuth(store))
    test_client = TestClient(app, base_url="http://e2e")
    sdk = OpenGuardClient(
        "http://e2e", auth=ApiKey(cleartext), http_client=test_client
    )
    return sdk, guard, admin


def test_admin_create_then_decision_authorize_through_sdk():
    sdk, _, _ = _bootstrap()
    sdk.admin.policies.create(
        tenant_id="t1",
        evaluator_type="abac",
        subject_match={"role": "reader"},
        action_match="read",
        resource_match={"resource_type": "document"},
    )
    result = sdk.decisions.authorize(
        subject={
            "id": "alice",
            "actor_type": "user",
            "attributes": {"role": "reader"},
        },
        action="read",
        resource={"id": "doc-1", "resource_type": "document"},
    )
    assert result["allowed"] is True


def test_resource_scoped_role_then_list_authorized():
    sdk, _, _ = _bootstrap()
    sdk.admin.roles.assign(
        tenant_id="t1",
        subject_id="alice",
        role="editor",
        resource_type="document",
        resource_match={"workspace_id": "ws-1"},
        actions=["read"],
    )
    # Listed back through admin surface — SDK round-trip survives
    # over the wire.
    listed = sdk.admin.policies.list(tenant_id="t1", evaluator_type="rbac")
    assert any(
        p["subject_match"].get("id") == "alice"
        and p["resource_match"].get("workspace_id") == "ws-1"
        for p in listed
    )

    # list_authorized hits the wire end-to-end — empty resource ids list
    # for a memory backend without candidate sources is acceptable; the
    # signal is that the call succeeds, the route is wired, and the
    # SDK serializes both inputs and outputs correctly.
    listed_resources = sdk.decisions.list_authorized(
        subject={
            "id": "alice",
            "actor_type": "user",
            "attributes": {"roles": ["editor"]},
        },
        action="read",
        resource_type="document",
    )
    assert "resource_ids" in listed_resources
    assert "next_cursor" in listed_resources


def test_relationship_check_round_trip():
    sdk, _, _ = _bootstrap()
    sdk.admin.relationships.add(
        tenant_id="t1",
        subject_id="alice",
        relation="member",
        object_type="team",
        object_id="team-7",
    )
    assert (
        sdk.admin.relationships.check(
            tenant_id="t1",
            subject_id="alice",
            relation="member",
            object_type="team",
            object_id="team-7",
        )
        is True
    )


def test_authorize_traced_returns_full_trace():
    sdk, _, _ = _bootstrap()
    result = sdk.decisions.authorize_traced(
        subject={"id": "u", "actor_type": "user"},
        action="read",
        resource={"id": "r", "resource_type": "document"},
    )
    assert "trace" in result
    assert "decision_status" in result["trace"]


def test_health_endpoint_round_trip():
    sdk, _, _ = _bootstrap()
    health = sdk.admin.health()
    assert health["status"] == "ok"
    assert "version" in health
