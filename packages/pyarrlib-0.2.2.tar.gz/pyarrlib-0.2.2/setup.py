import setuptools

with open("README.md", "r", encoding="utf-8") as f:
    text = f.read()

setuptools.setup(
    name="pyarrlib",
    version="0.2.2",
    author="Sasha Yuvko",
    description="this module can help you work with arrays",
    long_description=text,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.8"
)
