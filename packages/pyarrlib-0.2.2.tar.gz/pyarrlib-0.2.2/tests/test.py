from pyarrlib.arrpy import *

from pyarrlib.multidim_arr import *

# multidim_arr
assert num_of_leafs([[[[2]], [4, [5, 6, [6], 6, 6, 6], 7]], [2, 4, 5, 6, 6, 6,  6, 6, 7]]) == 18        
assert num_of_leafs([[1, 2, 3], [1, 2, 3]]) == 6
assert len_arr([[1, 2, 3], [1, 2, 3]]) == 6
assert len_arr([[[12], [32, 54, [3], 5], 63, 6], [54, [43, 54, 65, 43, [1, 54, 6], 54], 64]])
assert leafs([1, [1, 3, [4, 3], 4]]) == [1, 1, 3, 4, 3, 4]
assert equation_system([[1, 1, 2], [1, -1, 0]]) == [1, 1]





# arrpy
assert reverse_arr([1, "hello", 3, True]) == [True, 3, "hello", 1]
assert sum_arr([1, 5, 4, 3, 8]) == 21
assert sum_arr(['int', 43, True]) == ArrayTypeError
assert multiplication_arr([4, 1, 2, 5, 7]) == 280
assert multiplication_arr(['int', 43, True]) == ArrayTypeError
assert min([1, 3, 6, -3, 2]) == -3
assert max([1, 5, 3, -5, 4, 10]) == 10
assert arifmetic_mean([4, 3, 2]) == 3
assert sort([1, 5, 3, False]) == [False, 1, 3, 5]
assert same([1, 4, 3, ], [5, 6, 3, 1]) == [1, 3]
assert step_filter([1, 4, 3, 5, 4, 2], 3) == [3, 2]



# dict