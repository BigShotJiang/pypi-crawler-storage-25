import pyarrlib.arrpy

def max(d: dict):
    values = list(d.values())      
    return pyarrlib.arrpy.max(*values)  

def min(d: dict):
    values = list(d.values())
    return pyarrlib.arrpy.min(*values)

def is_key_value_in_dict(d:dict, key, value):
    for i, j in d.items():
        if i == key and j ==value:
            return True
    return False

def key_sum(d:dict):
    res = 0
    for i in d.value():
        if isinstance(i, (int, float)):
            res += i
    
    return res

def key_multiplication(d:dict):
    res = 0
    for i in d.value():
        if isinstance(i, (int, float)):
            res *= i
    
    return res

def same_keys(d1:dict, d2:dict):
    arr2 = [i for i in d2]
    arr1 = [i for i in d1]
    return arr1 & arr2

def same_values(d1:dict, d2:dict):
    arr1 = [i for i in d1.values()]
    arr2 = [i for i in d2.values()]
    return arr1 & arr2