from .arrpy import *
from .dict import *
from ._checks import *
from .multidim_arr import *
__version__ = "0.2.2"