# framed_text

`framed_text` is a Python library for creating framed text with customizable frames and colors.

Full documentation can be found on [ReadTheDocs](https://framed-text.readthedocs.io/en/latest/)

## Features

- Display text output surrounded by a frame
- Customize the frame with different colors
- Optional title that can be colored and styled
- **Status**: Print text with a status icon preceeding it
- **LabeledData**: A string that consists of a label with different types of data following it
  - Both LabeledData and Status objects can be customized
- A version of framed text, but just for a title (or divider)

## Installation

`framed_text` can be installed from [PyPI](https://pypi.org/project/framed-text/) using **pip**:

```pip install framed-text```

Then import the necessary modules:

```py
# Main classes. See documentation for more details
from framed_text import FramedText, FramedHeader, LabeledData, Status
```

Additionally, the following objects are available to be imported:

- `framed_text.AnyLabeledData`
- `framed_text.AnyStatus`
- `framed_text.InvalidColorError`
- `framed_text.BaseStatus`

## Quickstart

The Quick-Start Guide can be found on [ReadTheDocs](https://framed-text.readthedocs.io/en/latest/quickstart.html)

## Credits

Thank you to the following:
- **[prompt_toolkit](https://github.com/prompt-toolkit/python-prompt-toolkit)**: Main inspiration for making FramedText as well as the source for the ASCII characters.
- **[termcolor](https://github.com/termcolor/termcolor)**: Most of the coloring is done by this package. Huge thanks to the devs for this amazing package!
- **[Sphinx](https://www.sphinx-doc.org)**: Used for building the documentation.
- **[ReadTheDocs](https://readthedocs.com)**: Used for hosting the documentation.

## License

    Copyright (C) 2026  AstroLightz

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
  
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.