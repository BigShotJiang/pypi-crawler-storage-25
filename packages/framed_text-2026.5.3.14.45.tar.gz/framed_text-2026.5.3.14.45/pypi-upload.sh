source .venv/bin/activate

# Clear releases
cd dist || exit
rm -rf ./*
cd .. || exit

# Build release
python -m build

# Publish
twine upload dist/*