import textwrap
from os import get_terminal_size
from typing import Literal

from termcolor import colored as col

from framed_text.labeled_data import LabeledData, AnyLabeledData
from framed_text.status import AnyStatus
from framed_text.utils import _validate_color, _remove_ansi, _shorten_framed_title, _validate_attrs, _center_text, \
    _calculate_dividers, _format_col_text


class FramedText:
    def __init__(self, text: str | AnyLabeledData | AnyStatus | list[str | AnyLabeledData | AnyStatus] = "",
                 title: str = "", frame_color: str | tuple[int, int, int] | None = None,
                 title_color: str | tuple[int, int, int] | None = None,
                 mode: Literal["char", "word", "middle"] = "char",
                 cutoff: bool = True, allow_ansi: bool = False, center_text: bool = False,
                 attrs: list[str] | None = None):
        """
        Creates a string with a customizable frame around it. Frame is based off of prompt_toolkit's show_frame option,
        but with more customization and designed for print statements.

        **Cutoff Modes:**

        - ``char``: Cutoff char at end of text (The quick brown fox jumped ove…)
        - ``word``: Cutoff word at end of text (The quick brown fox jumped…)
        - ``middle``: Cutoff chars at middle of text (The quick brown…the lazy dog)

        **Attributes:**

        All ``termcolor`` attributes are supported: ``"bold"``, ``"dark"``, ``"italic"``, ``"underline"``,
        ``"reverse"``, ``"concealed"``, ``"strike"``

        **NOTE:** Mode only supported with LabeledData and Status objects

        **NOTE:** ``allow_ansi`` only applies to strings

        :param text: Text to be framed. Can be a regular string or a LabeledData object
        :param title: Title of the frame
        :param mode: Mode for cutoff. "char" for character cutoff, "word" for word cutoff, "middle" for middle cutoff
        :param frame_color: Color of the frame. Valid colors based off of termcolor's color options: string color code or RGB tuple
        :param title_color: Color of the title. Valid colors based off of termcolor's color options: string color code or RGB tuple
        :param cutoff: If true, cut off text if it exceeds terminal width. Default is True (Recommended)
        :param allow_ansi: If True, Allows ANSI on long lines (Highly experimental. Use at your own risk). If False, removes all ANSI from non-LabeledData objects on long lines.
        :param center_text: If True, centers the text inside frame.
        :param attrs: Attributes to apply to the title. See list above for valid attributes
        """

        # Init public vars
        self.text: str = text
        self.title: str = title
        self.frame_color: str | tuple[int, int, int] | None = None
        self.title_color: str | tuple[int, int, int] | None = None
        self.allow_ansi: bool = allow_ansi
        self.center_text: bool = center_text
        self.attrs: list[str] | None = None

        # Init private vars
        self._framed_text: list[str] = []
        self._term_width: int = get_terminal_size().columns
        self._limit: int = self._term_width - 4

        # Validation
        if frame_color:
            _validate_color(color=frame_color)
            self.frame_color = frame_color

        if title_color:
            _validate_color(color=title_color)
            self.title_color = title_color

        if attrs:
            _validate_attrs(attrs=attrs)
            self.attrs = attrs

        # Setup title
        self.title = _shorten_framed_title(title=self.title, limit=self._term_width - 6)

        # Setup Title line and formatting
        title: str = _format_col_text(text=self.title, color=self.title_color, attrs=self.attrs)

        if self.frame_color and self.title:
            # Color and Title
            start_len, end_len = _calculate_dividers(offset=6, title_len=len(self.title))
            self._framed_text.append(
                f"{col(f"┌{'─' * start_len}| ", self.frame_color)}{title}{col(f" |{'─' * end_len}┐", self.frame_color)}")

        elif self.frame_color and not self.title:
            # Color
            line_len, _ = _calculate_dividers(offset=2)
            self._framed_text.append(col(f"┌{'─' * line_len}┐", self.frame_color))

        elif self.title:
            # Title
            start_len, end_len = _calculate_dividers(offset=6, title_len=len(self.title))

            self._framed_text.append(f"┌{'─' * start_len}| {title} |{'─' * end_len}┐")

        else:
            # None
            start_len, end_len = _calculate_dividers(offset=2)
            line_len: int = start_len + end_len
            self._framed_text.append(f"┌{'─' * line_len}┐")

        # Format text to insert vertical lines at start and end of each line
        for line in self.text:
            # Only strip trailing whitespace for termcolor compat
            if any(isinstance(line, T) for T in [AnyLabeledData, AnyStatus]):
                line_rstrip: str = line.__str__().rstrip()
            else:
                line_rstrip: str = line.rstrip()

            # Remove ANSI for len since it messes with its calculation
            line_no_ansi: str = _remove_ansi(line_rstrip)

            if not self.allow_ansi:
                # Use line_no_ansi except for LabeledData object

                if ((cutoff and len(line_no_ansi) > self._limit) or
                        (len(line_no_ansi) > self._limit and isinstance(line, AnyLabeledData))):
                    # Cutoff line
                    # Also used by LabeledData objects regardless of cutoff's value

                    # Do not block ANSI. Instead, use object's shorten value
                    if isinstance(line, LabeledData.Path):
                        line.cutoff_text(limit=self._limit, mode=mode)
                        line_txt: str = line.text_shorten

                    elif isinstance(line, LabeledData.String):
                        line.cutoff_text(limit=self._limit, mode=mode)
                        line_txt: str = line.text_shorten

                    elif isinstance(line, AnyLabeledData):
                        line.cutoff_text(limit=self._limit)
                        line_txt: str = line.text_shorten

                    elif isinstance(line, AnyStatus):
                        line.cutoff_text(limit=self._limit, mode=mode)
                        line_txt: str = line.text_shorten

                    else:
                        line_txt: str = textwrap.shorten(text=line_no_ansi, width=self._limit, placeholder="…")

                    # Center text
                    if self.center_text:
                        line_txt = _center_text(text=line_txt, line_len=self._limit)

                    line_len: int = len(_remove_ansi(text=line_txt))
                    space_cnt: int = self._term_width - line_len

                    if self.frame_color:
                        self._framed_text.append(
                            f"{col('│', self.frame_color)} {line_txt}{col(f"{' ' * (space_cnt - 3)}│", self.frame_color)}")
                    else:
                        self._framed_text.append(f"│ {line_txt}{' ' * (space_cnt - 3)}│")

                else:
                    # No edits needed or cutoff is false
                    # If cutoff is false, let line get wrapped. (Will break frame formatting!)

                    # Center text
                    if self.center_text:
                        line_rstrip = _center_text(text=line_rstrip, line_len=self._limit)
                        line_no_ansi = _remove_ansi(text=line_rstrip)

                    line_len: int = len(line_no_ansi)
                    space_cnt: int = self._term_width - line_len

                    if self.frame_color:
                        self._framed_text.append(
                            f"{col('│', self.frame_color)} {line_rstrip}{col(f"{' ' * (space_cnt - 3)}│", self.frame_color)}")
                    else:
                        self._framed_text.append(f"│ {line_rstrip}{' ' * (space_cnt - 3)}│")

            else:
                # Use line_no_ansi for calculations, but line for printing
                if ((cutoff and len(line_no_ansi) > self._limit) or
                        (len(line_no_ansi) > self._limit and isinstance(line, AnyLabeledData))):
                    # Get cutoff point.
                    # Also used by LabeledData objects regardless of cutoff's value
                    cutoff_point: int = self._get_cutoff_point(len_ansi=len(line_rstrip), len_no_ansi=len(line_no_ansi),
                                                               term_width=self._term_width, line_no_ansi=line_no_ansi)

                    # Adjust cutoff char if text is a labeled path
                    if isinstance(line, LabeledData.Path):
                        line.cutoff_text(limit=self._limit, mode=mode)
                        line_rstrip = line.text_shorten

                    elif isinstance(line, LabeledData.String):
                        line.cutoff_text(limit=self._limit, mode=mode)
                        line_rstrip = line.text_shorten

                    elif isinstance(line, AnyLabeledData):
                        line.cutoff_text(limit=self._limit)
                        line_rstrip = line.text_shorten

                    elif isinstance(line, AnyStatus):
                        line.cutoff_text(limit=self._limit, mode=mode)
                        line_rstrip: str = line.text_shorten

                    else:
                        line_rstrip = line_rstrip[:cutoff_point - 6] + "…"

                    # Center text
                    if self.center_text:
                        line_rstrip = _center_text(text=line_rstrip, line_len=self._limit)

                    line_no_ansi = _remove_ansi(line_rstrip)
                    line_len = len(line_no_ansi)
                    space_cnt = self._term_width - line_len

                    if self.frame_color:
                        self._framed_text.append(
                            f"{col('│', self.frame_color)} {line_rstrip}{col(f"{' ' * (space_cnt - 3)}│", self.frame_color)}")
                    else:
                        self._framed_text.append(f"│ {line_rstrip}{' ' * (space_cnt - 3)}│")

                else:
                    # No edits needed or cutoff is false
                    # If cutoff is false, let line get wrapped. (Will break frame formatting!)

                    # Center text
                    if self.center_text:
                        line_rstrip = _center_text(text=line_rstrip, line_len=self._limit)
                        line_no_ansi = _remove_ansi(text=line_rstrip)

                    line_len: int = len(line_no_ansi)
                    space_cnt: int = self._term_width - line_len

                    if self.frame_color:
                        self._framed_text.append(
                            f"{col('│', self.frame_color)} {line_rstrip}{col(f"{' ' * (space_cnt - 3)}│", self.frame_color)}")
                    else:
                        self._framed_text.append(f"│ {line_rstrip}{' ' * (space_cnt - 3)}│")

        # Bottom frame: Mirror of top without title
        if self.frame_color:
            self._framed_text.append(col(f"└{'─' * (self._term_width - 2)}┘", self.frame_color))
        else:
            self._framed_text.append(f"└{'─' * (self._term_width - 2)}┘")

    def __str__(self):
        return '\n'.join(self._framed_text)

    @staticmethod
    def _get_cutoff_point(len_ansi: int, len_no_ansi: int, term_width: int, line_no_ansi: str) -> int:
        """
        Get cutoff point when line exceeds terminal width
        :param len_ansi: Length of line with ANSI
        :param len_no_ansi: Length of line without ANSI
        :param term_width: Terminal width
        :param line_no_ansi: Line without ANSI
        :return: Cutoff point index for line
        """

        # Use length difference as offset
        len_diff: int = len_ansi - len_no_ansi
        cutoff_i_no_ansi: int = 0

        # Find which char exceeds length in the non-ansi line
        for i in range(len(line_no_ansi)):
            if len(line_no_ansi[:i]) > term_width:
                cutoff_i_no_ansi = i
                break

        # Cutoff point in ansi is the cutoff point in non-ansi + length difference
        return cutoff_i_no_ansi + len_diff
