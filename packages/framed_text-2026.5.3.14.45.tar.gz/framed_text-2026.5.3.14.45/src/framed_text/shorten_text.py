# TODO: This will replace the `mode` function of FramedText, and (possibly) the shorten stuff for LabeledData.
# It will behave like those, but allow for any string to be passed.
# It will take `allow_ansi` like FramedText, and behaves the same.

class ShortenText:
    pass