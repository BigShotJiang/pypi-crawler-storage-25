import re
from os import get_terminal_size
from typing import Any

from termcolor import COLORS, ATTRIBUTES
from termcolor import colored as col

# Setup valid attributes tuple
_VALID_ATTRS: set[str] = set(ATTRIBUTES.keys())


class InvalidColorError(Exception):
    def __init__(self, color: Any | None = None, message: str | None = None):
        """
        Exception raised for invalid colors

        :param color: Invalid color
        :param message: Exception message
        """
        self.color = color
        self.message = f"Not a valid color: '{self.color}'" if not message else message

        super().__init__(self.message)


def _calculate_dividers(offset: int = 6, title_len: int = 0) -> tuple[int, int]:
    """
    Calculates the length of the dividers for FramedText and FramedHeader. Uses terminal's width.
    :param offset: Integer offset to account for chars to add/remove. Default 6 for FramedText: +2 spaces, +2 edges, +2 title pipes
    :param title_len: Integer length of the title. Set to 0 for no title
    :return: Starting divider length, End divider length. If title length is 0, returns (terminal width - offset, 0)
    """

    term_width: int = get_terminal_size().columns

    end_len: int = 0

    if title_len >= 0:
        # Calculate needed space
        space_needed: int = term_width - title_len - offset

        # Calculate start and end lengths
        start_len: int = space_needed // 2

        # Ensure end length + start length equals space needed
        end_len = start_len + 1 if 2 * start_len != space_needed else start_len
    elif title_len < 0:
        raise ValueError("Title length must be 0 or greater")
    else:
        start_len: int = term_width - offset

    return start_len, end_len


def _remove_ansi(text: str) -> str:
    """
    Removes all ANSI from text. Mostly used for calculating length of a line since len counts each char, even ANSI
    :param text: Text to remove ANSI from
    :return: Text without ANSI
    """
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)


def _validate_color(color: str | tuple[int, int, int]) -> None:
    """
    Checks if a color is a valid termcolor color
    
    :param color: termcolor color code or RGB tuple
    """

    if isinstance(color, tuple) and not all(0 <= c <= 255 for c in color):
        raise InvalidColorError(message="RGB values must be between 0 and 255")

    elif isinstance(color, str) and color.lower() not in list(COLORS.keys()):
        raise InvalidColorError(message=color)


def _format_col_text(text: str,
                     color: str | tuple[int, int, int] | None = None,
                     attrs: list[str] | None = None) -> str:
    """
    Create a termcolor formatted string based on provided formatting options
    :param text: String text to format
    :param color: Valid termcolor color. String code or RGB tuple
    :param attrs: Valid termcolor attribute(s).
    :return: Formatted string
    """

    # Validation
    if color:
        _validate_color(color=color)

    if attrs:
        _validate_attrs(attrs=attrs)

    # Strip ANSI from text
    text = _remove_ansi(text=text)

    if attrs and all(attr in list(ATTRIBUTES.keys()) for attr in attrs):
        if color:
            return col(text=text, color=color, attrs=attrs)
        else:
            return col(text=text, attrs=attrs)

    elif color:
        return col(text=text, color=color)
    else:
        return text


def _shorten_framed_title(title: str, limit: int) -> str:
    """
    Shortens a title to fit in a limit. Used for FramedHeader and FramedText
    :param title: Title to shorten
    :param limit: Limit to shorten to
    :return: Shortened title
    """

    if len(title) > limit:
        return title[:limit - 1] + '…'

    return title


def _truncate_text_middle(text: str, limit: int) -> str:
    """
    Shortens a text to fit in a limit by truncating the middle
    :param text: Text to shorten
    :param limit: Limit to shorten to
    :return: Shortened text
    """

    # Calculate difference
    diff: int = len(text) - limit
    diff_start: int = diff // 2
    diff_end: int = diff_start + 1 if diff % 2 != 0 else diff_start
    txt_len: int = len(text)

    ### RANGE CALCULATION
    # Start: middle - diff_start (Start Length = 0 + Start --> Start Length = Start)
    # End: middle + diff_end. (End Length = Original length - End)
    # Length Relationships will be either Start = End or Start = End - 1
    # Original length = Start + End
    return text[:(txt_len // 2) - diff_start] + "…" + text[
        (txt_len // 2) + diff_end:]


def _validate_attrs(attrs: list[str]) -> None:
    """
    Validate attributes
    :param attrs: List of attributes
    """

    for attr in attrs:
        if attr not in _VALID_ATTRS:
            raise ValueError(f"Not a valid attribute: {attr}\n"
                             f"Valid attributes: {_VALID_ATTRS}")


def _center_text(text: str, line_len: int) -> str:
    """
    Centers text. Only adds leading spaces as trailing is handled by FramedText
    :param text: Text to center
    :param line_len: Length of the line
    :return: Centered text
    """

    return text.center(line_len).rstrip()
