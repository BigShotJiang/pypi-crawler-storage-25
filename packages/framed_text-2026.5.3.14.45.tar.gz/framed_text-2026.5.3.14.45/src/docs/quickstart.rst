=================
Quick-Start Guide
=================

.. important::

    Make sure to import the module first!

    .. code-block:: python3
        :linenos:

        from framed_text import FramedText, LabeledData, Status, ... # Any other items you need

The basic parameters for ``FramedText`` include:

- ``framed_color``: The color of the frame
- ``title``: The title of the frame
- ``title_color``: The color of the title
- ``attrs``: The attributes of the title
- ``text``: The text to display

We'll go over each of these parameters in detail.

Creating a Simple Frame Using ``FramedText``
--------------------------------------------

You can create a simple frame using the following code:

.. code-block:: python3
    :caption: Using the ``FramedText`` class
    :linenos:

    ft: FramedText = FramedText(
      text=[
        "Hello world"
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_1.png

We can add more text by adding more strings to the ``text`` list:

.. code-block:: python3
    :caption: Multiple lines can be added to the ``text`` list
    :linenos:

    ft: FramedText = FramedText(
      text=[
        "Hello world",
        "Another line",
        "Another Another line"
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_2.png

Adding Data to the Frame
------------------------

To add data to the text with a label, it's recommended to use ``LabeledData``.

``LabeledData`` is a collection of typed objects that can be used to display data in a frame.

Each class of ``LabeledData`` has the following base parameters:

- ``label``: A label to assign to the text
- ``value``: The value to display
- ``quotes``: Whether to add quotes around the value

.. versionchanged:: 2026.04.03.16.00

    Used to be ``color`` and ``attrs``.

    - ``val_color``: The color for the value [1]_.
    - ``val_attrs``: The attribute(s) for the value [2]_.

.. versionadded:: 2026.04.03.16.00

    - ``label_color``: The color for the label [1]_.
    - ``label_attrs``: The attribute(s) for the label [2]_.
    - ``colon_match``: If true, ``label_color`` and ``label_attrs`` will be applied to the colon.

.. versionadded:: 2026.05.03.14.45

    - ``no_colon``: If true, the colon will be omitted from the text. Overrides ``colon_match``

    .. code-block:: python3
        :caption: All ``LabeledData`` classes using ``colon_match``
        :linenos:

        ft: FramedText = FramedText(
        text=[
                LabeledData.String(
                    label="LabeledData.String",
                    value="A String value",
                    no_colon=True
                ),
                LabeledData.Number(
                    label="LabeledData.Number",
                    value=3.14159,
                    no_colon=True
                ),
                LabeledData.Boolean(
                    label="LabeledData.Boolean",
                    value=True,
                    no_colon=True
                ),
                LabeledData.Path(
                    label="LabeledData.Path",
                    value=Path("/path/to/a/file.txt"),
                    no_colon=True
                )
            ]
        )
        print(ft)
    .. image:: _static/imgs/quickstart_14.png

------------------------------------------------------------------------------------------------------------------------

    Added suffix support to each type of ``LabeledData``. Suffixes will appear after the value.
    The following parameters apply to the suffix:

    - ``suffix``: Optional text to appear after the value
    - ``suffix_color``: The color for the suffix [1]_.
    - ``suffix_attrs``: The attribute(s) for the suffix [2]_.

    .. note::
        The cut-off mode for suffixes is always ``"word"``. See `mode`_ for more information.

    .. code-block:: python3
        :caption: All ``LabeledData`` classes with suffixes
        :linenos:

        ft: FramedText = FramedText(
        text=[
                LabeledData.String(
                    label="LabeledData.String",
                    value="A String value",
                    suffix="with a suffix"
                ),
                LabeledData.Number(
                    label="LabeledData.Number",
                    value=3.14159,
                    suffix="with a suffix"
                ),
                LabeledData.Boolean(
                    label="LabeledData.Boolean",
                    value=True,
                    suffix="with a suffix"
                ),
                LabeledData.Path(
                    label="LabeledData.Path",
                    value=Path("/path/to/a/file.txt"),
                    suffix="with a suffix"
                )
            ]
        )
        print(ft)
    .. image:: _static/imgs/quickstart_15.png

------------------------------------------------------------------------------------------------------------------------

.. [1] See `Colors`_ for more information.
.. [2] See `Attributes`_ for more information.

------------------------------------------------------------------------------------------------------------------------

Below lists the classes with additional parameters or those that differ from the base parameters:

``LabeledData.Number``
    - ``round_to``: Number of decimal places to round to
    - ``leading_zeros``: Number of leading zeros to add
    - ``int_no_round``: Whether to display the value as an integer without rounding

``LabeledData.Boolean``
    This class splits ``text`` and ``color`` across seperate parameters for True and False values.

    - ``t_text``: Text to display when the value is True
    - ``f_text``: Text to display when the value is False
    - ``t_color``: Color to use when the value is True
    - ``f_color``: Color to use when the value is False

The following ``LabeledData`` types are supported:

+-------------------------+--------------------+
|         Class           | Supported Types    |
+=========================+====================+
| ``LabeledData.String``  |      ``str``       |
+-------------------------+--------------------+
| ``LabeledData.Number``  | ``int``, ``float`` |
+-------------------------+--------------------+
| ``LabeledData.Boolean`` |     ``bool``       |
+-------------------------+--------------------+
|  ``LabeledData.Path``   | ``pathlib.Path``   |
+-------------------------+--------------------+

Here is an example of using ``LabeledData`` to display a string value:

.. code-block:: python3
    :caption: Using the ``LabeledData`` class with ``FramedText``
    :linenos:

    ft: FramedText = FramedText(
        text=[
            LabeledData.String(
                label="LabeledData.String",
                value="A String value",
            )
        ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_3.png

.. figure:: _static/imgs/quickstart_4.png

    Ouptut of all of the ``LabeledData`` types printed together

Styling the Frame and Adding a Title
------------------------------------

You can color the frame using the ``framed_color`` parameter:

.. code-block:: python3
    :caption: Coloring the frame red
    :linenos:

    ft: FramedText = FramedText(
      frame_color="red",
      text=[
        "Hello world"
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_5.png

You can add a title to the frame using the ``title`` parameter:

.. code-block:: python3
    :caption: A simple title for the frame
    :linenos:

    ft: FramedText = FramedText(
      title="This is a title",
      frame_color="red",
      text=[
        "Hello world"
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_6.png

To color the title, use ``title_color``:

.. code-block:: python3
    :caption: Coloring the title green. Note that the frame color is still red.
    :linenos:

    ft: FramedText = FramedText(
      title="This is a title",
      frame_color="red",
      title_color="green",
      text=[
        "Hello world"
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_7.png

The title supports termcolor's formatting options using ``attrs`` parameter:

.. code-block:: python3
    :caption: Applying a bold and underline style to the title. The title color is still green.
    :linenos:

    ft: FramedText = FramedText(
      title="This is a title",
      frame_color="red",
      title_color="green",
      attrs=["bold", "underline"],
      text=[
        "Hello world"
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_8.png

Advanced ``FramedText`` Parameters
----------------------------------

In addition to the above parameters, ``FramedText`` also features:

- ``cutoff``: If true, will cut off text if it exceeds the terminal width
- ``mode``: Determines how text is cut off. Used with ``cutoff``
- ``allow_ansi``: If true, will allow ANSI codes to be displayed. By default, this is false for reasons we'll get to.
- ``center_text``: If true, will center the ``text`` display to the middle of the frame.

mode
~~~~

``mode`` can be one of the following:

- ``"char"``: Cut off the line based on which character surpasses the terminal width
- ``"word"``: Cut off the line based on which character surpasses the terminal width
- ``"middle"``: Trim the middle of the line until it fits the terminal width

Below are examples of each mode:

.. code-block:: python3
    :caption: When ``mode`` is set to ``"char"``

    "The quick brown fox jumped ove…"

.. code-block:: python3
    :caption: When ``mode`` is set to ``"word"``

    "The quick brown fox jumped…"

.. code-block:: python3
    :caption: When ``mode`` is set to ``"middle"``

    "The quick brown…the lazy dog"

.. note::
    ``LabeledData.Path`` behaves differently when ``mode`` is set to ``"word"``.

    Parts of the path will be cut and replaced with an ellipsis if the path exceeds the limit:

    - ``"/home/user/path/to/a/file.txt"`` becomes ``"/home/user/path/…/file.text"``

allow_ansi
~~~~~~~~~~

This parameter is present due to the way ``cutoff`` works.

``termcolor`` formatted strings contain ANSI codes (e.g. ``\x1b[31m`` for red). Normally, this wouldn't be an issue,
however, when ``cutoff`` is enabled, there is the issue of the ANSI codes being cut off, which could mess up the display
of the framed text.

Because of this, **any strings containing ANSI codes will have their codes removed!** The only exceptions are
for the objects provided by ``framed_text`` (e.g. ``Status`` and ``LabeledData``).

However, if you want to allow ANSI codes to be displayed, you can set ``allow_ansi`` to true.

Displaying Statuses
-------------------

``framed_text`` also features ``Status`` objects to display messages with a status icon.

``Status`` takes the following parameters:

- ``icon``: The icon to display
- ``icon_color``: The color of the icon
- ``sep``: The seperator between the icon and message
- ``msg``: The message to display
- ``text_color``: The color of the message

The Status is constructed as: ``<icon><sep><message>``

.. versionchanged:: 2026.04.04.14.00

    - If the ``icon`` is an empty string, the seperator will not be displayed.
    - The Status will be constructed as: ``<message>``
    - ``text_color`` will still be applied to ``msg``

------------------------------------------------------------------------------------------------------------------------

The default ``Status`` format is: ``<I>: <message>``

Below is a full list of each ``Status`` and their default output:

.. versionadded:: 2026.04.29.16.30

    Added ``Status.Hidden``

.. code-block:: python3
    :caption: Each status is printed on a new line. Note that some messages are colored.
    :linenos:

    ft: FramedText = FramedText(
      title="Status",
      frame_color="red",
      text=[
        Status.Info(msg="This is an info message"),
        Status.Action(msg="This is an action message"),
        Status.Success(msg="This is a success message"),
        Status.Warn(msg="This is a warning message"),
        Status.Fail(msg="This is a fail message")

        # You can omit the 'msg=' parameter and achieve the same result
        Status.Hidden("This is a hidden message. It just makes the text darker.")
      ]
    )
    print(ft)
.. image:: _static/imgs/quickstart_9.png

Displaying a Header and Divider
-------------------------------

``FramedHeader`` is like ``FramedText``, but it only displays a single line of the 'frame':

.. code-block:: python3
    :caption: A basic ``FramedHeader``. Without arguments, this is effectively a divider.
    :linenos:

    fh: FramedHeader = FramedHeader()
.. image:: _static/imgs/quickstart_10.png

Like ``FramedText``, we can color the header:

.. code-block:: python3
    :caption: Coloring the 'divider' red
    :linenos:

    fh: FramedHeader = FramedHeader(
      frame_color="red"
    )
.. image:: _static/imgs/quickstart_11.png

Currently, this 'header' is more of a divider. To actually make it a header and add a title, we can add:

.. code-block:: python3
    :caption: Adding a title makes it a header
    :linenos:

    fh: FramedHeader = FramedHeader(
      title="Header",
      frame_color="red"
    )
.. image:: _static/imgs/quickstart_12.png

``FrameHeader`` also supports the same title formatting as ``FramedText``:

.. code-block:: python3
    :caption: Same example as ``FramedText``, but adapted for ``FramedHeader``
    :linenos:

    fh: FramedHeader = FramedHeader(
      title="Header",
      frame_color="red",
      title_color="green",
      attrs=["bold", "underline"]
    )
.. image:: _static/imgs/quickstart_13.png

Colors
------

Most classes in ``framed_text`` have parameters for ``termcolor`` colors.

The value can be either a ``termcolor`` color code or an (R, G, B) tuple, where each value is between 0 and 255.

For a full list of ``termcolor`` color codes, see `termcolor's Text Properties <https://github.com/termcolor/termcolor#text-properties>`_.

Attributes
----------

.. attention::

    Not all of termcolor's attributes are supported by every terminal emulator or operating system.

    **Your milage may vary**

Most classes in ``framed_text`` have parameters for ``termcolor`` attributes.

All ``termcolor`` attributes are supported. Below is a list of all valid attributes currently available:

- ``bold``
- ``dark``
- ``italic``
- ``underline``
- ``blink``
- ``reverse``
- ``concealed``
- ``strike``

.. figure:: _static/imgs/quickstart_g1.webp

    Showcase of all attributes using ``FramedText`` and ``LabeledData.String``
