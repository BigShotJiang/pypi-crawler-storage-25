framed\_text package
====================

Submodules
----------

framed\_text.framed\_header module
----------------------------------

.. automodule:: framed_text.framed_header
   :members:
   :show-inheritance:
   :undoc-members:

framed\_text.framed\_text module
--------------------------------

.. automodule:: framed_text.framed_text
   :members:
   :show-inheritance:
   :undoc-members:

framed\_text.labeled\_data module
---------------------------------

.. automodule:: framed_text.labeled_data
   :members:
   :show-inheritance:
   :undoc-members:

framed\_text.shorten\_text module
---------------------------------

.. automodule:: framed_text.shorten_text
   :members:
   :show-inheritance:
   :undoc-members:

framed\_text.status module
--------------------------

.. automodule:: framed_text.status
   :members:
   :show-inheritance:
   :undoc-members:

framed\_text.utils module
-------------------------

.. automodule:: framed_text.utils
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: framed_text
   :members:
   :show-inheritance:
   :undoc-members:
