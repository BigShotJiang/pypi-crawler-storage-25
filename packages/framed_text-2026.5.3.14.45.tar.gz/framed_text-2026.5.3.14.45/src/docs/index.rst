.. framed_text documentation master file, created by
   sphinx-quickstart on Fri Mar 20 13:40:03 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

framed_text Documentation
=========================

Welcome to the documentation for ``framed_text``!

- To get started, see the :doc:`Quick-Start Guide <quickstart>`.
- Or if you want to know more about the module, see the :doc:`modules <modules>` section.


.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules
   quickstart
