source .venv/bin/activate

# Build Docs
cd src || exit
rm -f docs/framed_text.rst docs/modules.rst
sphinx-apidoc -o docs .
cd docs || exit
make html

# Update Docs dependencies
pip-compile requirements.in -o requirements.txt
