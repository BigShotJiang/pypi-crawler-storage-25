---
name: simple-formatter
description: Formats text according to specified style guidelines. A clean example skill with no security issues.
license: MIT
allowed-tools:
  - Python
---

# Simple Text Formatter

This skill formats text according to style guidelines.

## Features

- Capitalize sentences
- Fix spacing
- Apply punctuation rules

## Usage

When the user provides text to format, apply the following rules:
1. Capitalize first letter of sentences
2. Ensure single space after periods
3. Remove trailing whitespace

## Example

Input: "hello world.this is a test."
Output: "Hello world. This is a test."
