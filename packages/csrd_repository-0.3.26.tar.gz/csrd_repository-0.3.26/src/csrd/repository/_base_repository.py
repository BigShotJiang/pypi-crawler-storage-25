from collections.abc import Sequence
from typing import Any

from csrd.models.model_parser import ModelParserMixin

from ._database_adapter import DBProtocol
from .types import DBQuery


def _compile(query: DBQuery, params: dict[str, Any] | None) -> tuple[str, dict[str, Any] | None]:
    """Convert a query (raw SQL *or* SQLAlchemy Executable) into (sql_string, params)."""
    if isinstance(query, str):
        return query, params

    # SQLAlchemy Executable — compile to SQL + extract bound params
    compiled = query.compile(compile_kwargs={"literal_binds": False})
    sql = str(compiled)
    compiled_params = dict(compiled.params) if compiled.params else {}
    if params:
        compiled_params.update(params)
    return sql, compiled_params or None


class BaseRepository(ModelParserMixin):
    _adapter: DBProtocol

    def __init__(self, adapter: DBProtocol):
        if adapter is None:
            raise TypeError("BaseRepository requires a database adapter — got None")
        self._adapter = adapter
        super().__init__(extractor=self._adapter.extractor)

    @property
    def extract(self):
        return self._adapter.extractor.extract

    async def fetch_one(self, query: DBQuery, params: dict[str, Any] | None = None) -> Any | None:
        sql, resolved = _compile(query, params)
        raw = await self._adapter.fetch_one(sql, resolved)
        return self._resolve_payload(raw)

    async def fetch_all(
        self, query: DBQuery, params: dict[str, Any] | None = None
    ) -> Sequence[Any]:
        sql, resolved = _compile(query, params)
        raw = await self._adapter.fetch_all(sql, resolved)
        result = self._resolve_payload(raw)
        return list(result) if isinstance(result, (list, tuple)) else [result]

    async def execute(self, query: DBQuery, params: dict[str, Any] | None = None) -> Any:
        sql, resolved = _compile(query, params)
        return await self._adapter.execute(sql, resolved)

    async def execute_returning(self, query: DBQuery, params: dict[str, Any] | None = None) -> Any:
        sql, resolved = _compile(query, params)
        return await self._adapter.execute_returning(sql, resolved)

    async def insert(self, table: str, values: dict[str, Any], *args, **kwargs) -> Any:
        return await self._adapter.insert(table, values, *args, **kwargs)

    async def update(self, table: str, values: dict[str, Any], where: dict[str, Any]) -> int:
        return await self._adapter.update(table, values, where)

    async def upsert(self, table: str, values: dict[str, Any], where: dict[str, Any]) -> int:
        return await self._adapter.upsert(table, values, where)

    async def delete(self, table: str, where: dict[str, Any]) -> int:
        return await self._adapter.delete(table, where)
