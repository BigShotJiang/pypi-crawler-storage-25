 # csrd-repository

Base repository and database adapter abstractions for FastAPI microservices.

**Package**: `csrd.repository` · **Import**: `from csrd.repository import BaseRepository, SQLiteAdapter`

## What's included

- `BaseRepository` — abstract repository with model parsing (requires an adapter)
- `ABCDatabaseAdapter` / `DBProtocol` — async database adapter abstraction with lifecycle (`connect()` / `close()` / `async with`)
- `SQLiteAdapter` — async SQLite implementation via aiosqlite (persistent connection, atomic upsert)
- `ExecuteResult` — immutable snapshot of query metadata (replaces raw cursor return)
- Optional `sqlalchemy` integration for query building (`pip install csrd-repository[sql]`)

## Installation

```bash
uv pip install "csrd-repository @ git+ssh://git@github.com/csrd-api/fastapi-common.git#subdirectory=packages/repository"
```

## Dependencies

- `csrd-models` (Tier 2)
