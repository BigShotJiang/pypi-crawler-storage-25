from pathlib import Path
import os
import platform
import importlib.resources


godot_version = "4.6.2"
base_godot_url = "https://github.com/godotengine/godot/releases/download/VERSION-stable/Godot_vVERSION-stable_PLATFORM.zip"
base_sha_url = "https://github.com/godotengine/godot/releases/download/VERSION-stable/SHA512-SUMS.txt"

data_dir_name = "godoplot_data"
paths = {
    "win64.exe": Path(str(os.getenv("LOCALAPPDATA"))) / data_dir_name,
    "linux.x86_64": Path(str(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share" / data_dir_name))),
    "linux.arm64": Path(str(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share" / data_dir_name))),
    "macos.universal": Path.home() / "Library" / "Application Support" / data_dir_name
}

# Following block of code gets platform details
curr_platform = ""
os_name = platform.system().lower()
arch = platform.machine().lower()
if os_name == "windows" and arch in ["amd64", "x86_64"]:
    curr_platform = "win64.exe"
elif os_name == "linux":
    if arch in ["amd64", "x86_64"]:
        curr_platform = "linux.x86_64"
    elif arch in ["arm64", "aarch64"]:
        curr_platform = "linux.arm64"
elif os_name == "darwin" and arch in ["arm64", "x86_64"]:
    curr_platform = "macos.universal"
else:
    raise Exception(f"System type unsupported: OS={os_name}; arch={arch}")

# Following block of code sets platform-dependent variables.
data_path = paths[curr_platform]
data_path.mkdir(exist_ok=True)
(data_path / "executables").mkdir(exist_ok=True)
godot_url = base_godot_url.replace("VERSION", godot_version).replace("PLATFORM", curr_platform)

# Following block of code sets other miscellaneous variables.
sha_url = base_sha_url.replace("VERSION", godot_version)
sha_path = data_path / "executables" / f"godot_{godot_version}_SHA512-SUMS.txt"
zip_name = godot_url.split("/")[-1]
zip_path = data_path/ "executables"/ zip_name
exec_path = data_path/ "executables" /zip_name[:-4]    # Remove .zip from zipname to get executable
log_path = data_path / "logs"
log_path.mkdir(exist_ok=True)
pck_path = Path(str(importlib.resources.files("godoplot.assets").joinpath("viz.pck")))
pck_path = Path(__file__).parent / "assets" / "viz.pck"     # TEMP, DELETE!! (will be deleted when shipping)
godo_pong = "HELLO_FROM_GODOPLOT_:3"
show_godo_logs_in_stdout = True
buffer_size = 256
font_size=10.0
