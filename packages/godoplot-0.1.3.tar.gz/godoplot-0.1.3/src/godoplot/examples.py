import numpy as np
from . import api


def scatter_spiral(n_points: int = 5000, clear: bool | None = True):
    """
    Generates a 3D Archimedean spiral and renders it.
    Demonstrates the scatter API capability.
    """
    if clear:
        api.clear()

    z = np.linspace(0, 20, n_points)
    x = np.sin(z) * (z / 2)
    y = np.cos(z) * (z / 2)

    api.point_scatter3d(x, y, z, color="#B3FF0050")


def surface_terrain(resolution: int = 50, clear: bool | None = True):
    """
    Generates a mathematically displaced terrain surface.
    Demonstrates the surface3d API capability.
    """
    if clear:
        api.clear()

    x_val = np.linspace(-5, 5, resolution)
    z_val = np.linspace(-5, 5, resolution)
    x_grid, z_grid = np.meshgrid(x_val, z_val)
    
    y_grid = np.sin(np.sqrt(x_grid**2 + z_grid**2))
    
    x_flat = x_grid.ravel()
    y_flat = y_grid.ravel()
    z_flat = z_grid.ravel()
    
    vertices = np.column_stack((x_flat, y_flat, z_flat))
    
    faces = []
    for i in range(resolution - 1):
        for j in range(resolution - 1):
            top_left = i * resolution + j
            top_right = top_left + 1
            bottom_left = (i + 1) * resolution + j
            bottom_right = bottom_left + 1
            
            # Triangle 1
            faces.append([top_left, top_right, bottom_left])
            # Triangle 2
            faces.append([top_right, bottom_right, bottom_left])
            
    api.surface3d(vertices, faces, color="#00FFFF68", wireframe=True)


def _lorenz_deriv(xyz, s=10.0, r=28.0, b=2.667):
    """
    Computes the spatial derivative for the standard Lorenz system.
    """
    x, y, z = xyz
    return np.array([
        s * (y - x),
        x * (r - z) - y,
        x * y - b * z
    ])


def _rk4_step(xyz, dt):
    """
    4th-Order Runge-Kutta integration step for numerical stability.
    """
    k1 = _lorenz_deriv(xyz)
    k2 = _lorenz_deriv(xyz + k1 * dt / 2.0)
    k3 = _lorenz_deriv(xyz + k2 * dt / 2.0)
    k4 = _lorenz_deriv(xyz + k3 * dt)
    return xyz + (k1 + 2.0 * k2 + 2.0 * k3 + k4) * dt / 6.0


def scatter_lorenz_butterfly(steps: int = 50000, clear: bool | None = True):
    """
    Simulates three diverging Lorenz trajectories to test large-scale 
    rendering and IPC throughput.
    """
    if clear:
        api.clear()

    dt = 0.005
    
    p1 = np.array([0.0, 10.0, 0.0])
    p2 = p1 + np.array([10.0, -10.0, 10.0])
    p3 = p1 + np.array([0.0, 0.0, 10.0])

    traj1 = np.zeros((steps, 3))
    traj2 = np.zeros((steps, 3))
    traj3 = np.zeros((steps, 3))

    traj1[0], traj2[0], traj3[0] = p1, p2, p3

    # Numerical integration loop
    for i in range(1, steps):
        traj1[i] = _rk4_step(traj1[i-1], dt)
        traj2[i] = _rk4_step(traj2[i-1], dt)
        traj3[i] = _rk4_step(traj3[i-1], dt)

    # Rendering multiple scatter sets with alpha-enabled colors
    api.point_scatter3d(traj1[:, 0], traj1[:, 1], traj1[:, 2], radius=2, color="#2CBDFE80", name="Plot1")
    api.point_scatter3d(traj2[:, 0], traj2[:, 1], traj2[:, 2], radius=2, color="#F5345980", name="Plot2")
    api.point_scatter3d(traj3[:, 0], traj3[:, 1], traj3[:, 2], radius=2, color="#F5D32880", name="Plot3")


def surface_interference(resolution: int = 500, clear: bool | None = True):
    """
    Generates a high-density wave interference pattern with heatmap.
    Tests vertex throughput and heatmap color interpolation.
    """
    if clear:
        api.clear()

    # Create the spatial grid - using floats, not strings
    x_val = np.linspace(-30.0, 30.0, resolution)
    z_val = np.linspace(-30.0, 30.0, resolution)
    x_grid, z_grid = np.meshgrid(x_val, z_val)
    
    # Two oscillating sources at (-2, 0) and (2, 0)
    k = 2.5 
    r1 = np.sqrt((x_grid + 2.0)**2 + z_grid**2)
    r2 = np.sqrt((x_grid - 2.0)**2 + z_grid**2)
    y_grid = np.cos(k * r1) + np.cos(k * r2)
    
    # Flatten for the API
    x_flat = x_grid.ravel()
    y_flat = y_grid.ravel()
    z_flat = z_grid.ravel()
    vertices = np.column_stack((x_flat, y_flat, z_flat))
    
    # Heatmap Generation
    # Normalize y_grid from [-2, 2] to [0, 1] for color mapping
    norm_y = (y_flat + 2.0) / 4.0
    
    # Create an RGB heatmap (Deep Blue -> Cyan -> Yellow)
    colors = np.zeros((vertices.shape[0], 3))
    colors[:, 0] = np.clip(norm_y * 1.5 - 0.5, 0.0, 1.0) # Red
    colors[:, 1] = np.clip(norm_y * 1.5, 0.0, 1.0)       # Green
    colors[:, 2] = np.clip(1.0 - norm_y, 0.0, 1.0)      # Blue
    
    # Face Generation
    faces = []
    for i in range(resolution - 1):
        for j in range(resolution - 1):
            top_left = i * resolution + j
            top_right = top_left + 1
            bottom_left = (i + 1) * resolution + j
            bottom_right = bottom_left + 1
            
            # Triangle 1
            faces.append([top_left, top_right, bottom_left])
            # Triangle 2
            faces.append([top_right, bottom_right, bottom_left])
            
    # Send to Godot
    api.surface3d(
        vertices=vertices, 
        faces=faces, 
        vertex_colors=colors, 
        wireframe=False, 
        name="InterferencePattern"
    )
