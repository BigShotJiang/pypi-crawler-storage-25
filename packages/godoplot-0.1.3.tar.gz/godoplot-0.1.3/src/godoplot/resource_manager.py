from zipfile import ZipFile
from pathlib import Path
import hashlib
import shutil
import urllib.request


def _download_resource(url: str, file_path: Path):
    """
    Download a resource. Overwrite if resource already present
    """
    print(f"Fetching resource: {str(file_path)}")
    try:
        with urllib.request.urlopen(url=url) as response, open(file_path, 'wb') as out_file:
            shutil.copyfileobj(response, out_file)
    except Exception as e:
        print(f"Exception during download: {e}")


def _check_hash(file_path: Path, reference_hash: str) -> bool:
    """
    Check the hash of the file against the reference hash passed. Case Insensitive.
    """
    hash_chunk_size = 65536

    if not file_path.exists():
        print(f"File does not exist at {file_path}")
        return False

    sha_hash = hashlib.sha512()
    
    with open(file_path, "rb") as f:
        # Read the file in chunks
        for byte_block in iter(lambda: f.read(hash_chunk_size), b""):
            sha_hash.update(byte_block)
    hash = sha_hash.hexdigest()
    if hash.lower() == reference_hash.lower():
        print(f"HASH MATCHED for file at {str(file_path)}")
        return True
    else:
        print(f"HASH MISMATCH for file at {str(file_path)} is: {hash}; Expected: {reference_hash}")
        return False


def _extract_resource(file_path: Path, destination_path: Path) -> None:
    """
    Extract a file
    """
    try:
        with ZipFile(file_path) as gdzip:
            gdzip.extractall(path=destination_path)
    except Exception as e:
        print(f"Exception occurred during extraction: {e}")
