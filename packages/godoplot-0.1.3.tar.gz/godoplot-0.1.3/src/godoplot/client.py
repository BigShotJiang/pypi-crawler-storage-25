import websocket
import json
import time
import struct
from . import glossary


def _verify_process(port: int) -> bool:
    """
    Verifies whether the process running in this port is our godot executable
    by attempting a WebSocket handshake.
    """
    ws = websocket.WebSocket()
    ws.settimeout(0.3)  # Fail fast if it's not Godot
    try:
        ws.connect(f"ws://localhost:{port}")
        ws.send(json.dumps({"command": "identify"}))
        
        response = ws.recv()
        data = json.loads(response)
        
        if data.get("identity") == glossary.godo_pong:
            return True
    
    except Exception:
        pass
    finally:
        if ws.connected:
            ws.close()
    
    return False


class GodoClient:
    """
    Manages a persistent WebSocket connection to a Godoplot engine.
    """
    def __init__(self, port: int = 8080):
        self.port = port
        self.ws: websocket.WebSocket | None = None


    def connect(self) -> None:
        """
        Establishes the connection and performs the handshake.
        """
        if self.ws and self.ws.connected:
            return
            
        try:
            self.ws = websocket.WebSocket()
            self.ws.connect(f"ws://localhost:{self.port}")
            
            # The Handshake
            self.ws.send(json.dumps({"command": "identify"}), opcode=websocket.ABNF.OPCODE_TEXT)
            self.ws.recv()  # Block until ACK
        except ConnectionRefusedError:
            raise RuntimeError(f"Could not connect to Godoplot engine on port {self.port}. Is it running?")


    def send_command(self, command: str, kwargs: dict | None = None) -> dict:
        """
        Sends a text-based command and waits for response.
        """
        self.connect()
        assert self.ws is not None

        payload = {"command": command}
        if kwargs:
            payload.update(kwargs)
        
        self.ws.send(json.dumps(payload), opcode=websocket.ABNF.OPCODE_TEXT)
        response = self.ws.recv()
        return json.loads(response)


    def send_data(self, header: dict, binary_payload: bytes) -> None:
        """
        Packs and streams binary data to the engine.
        """
        self.connect()
        assert self.ws is not None

        header_bytes = json.dumps(header).encode('utf-8')
        header_length_prefix = struct.pack('<I', len(header_bytes))
        
        packet = header_length_prefix + header_bytes + binary_payload
        self.ws.send(packet, opcode=websocket.ABNF.OPCODE_BINARY)
        
        self.ws.recv()


    def reset_godot(self) -> None:
        """
        Reset the godot scene using the persistent connection.
        """
        try:
            self.send_command("clear_scene")
        except Exception as e:
            print(f"Warning: Failed to reset Godot scene: {e}")


    def close(self) -> None:
        """
        Gracefully shuts down the connection.
        """
        if self.ws:
            try:
                time.sleep(0.05)  # OS buffer flush
                self.ws.close()
            except Exception:
                # Already dead
                pass
            finally:
                self.ws = None
    

    @property
    def is_connected(self) -> bool:
        """
        Check if the WebSocket is currently open.
        """
        return self.ws is not None and self.ws.connected


    def __del__(self):
        """
        Failsafe to ensure the socket closes if the object is destroyed.
        """
        try:
            self.close()
        except Exception:
            pass


_default_client = GodoClient()


def _get_default_client() -> GodoClient:
    return _default_client
