import subprocess
import socket
import random
import time
from . import glossary
from . import client
from . import core
from .resource_manager import _download_resource, _check_hash, _extract_resource


def _fetch_expected_hash() -> str | None:
    """
    Fetches the expected hash for the Godot executable.
    """
    if not glossary.sha_path.exists():
        _download_resource(glossary.sha_url, glossary.sha_path)
    try:
        with open(glossary.sha_path, "r", encoding="utf-8") as f:
            for line in f:
                if glossary.zip_name in line:
                    parts = line.split("  ")
                    if parts:
                        return parts[0]
    except Exception as e:
        print(f"Error reading checksum file at {glossary.sha_path}: {e}")
        
    return None


def _source_godo() -> bool:
    """
    Sources a Godot executable. Return success bool.
    """
    if glossary.exec_path.exists():
        return True
    
    expected_hash = _fetch_expected_hash()
    if expected_hash is not None:
        try:
            if not glossary.zip_path.exists():
                _download_resource(glossary.godot_url, glossary.zip_path)
            if _check_hash(glossary.zip_path, reference_hash=expected_hash):
                _extract_resource(glossary.zip_path, glossary.zip_path.parent)
            else:
                print("Hash check failed - retrying download.")
                _download_resource(glossary.godot_url, glossary.zip_path)
                if _check_hash(glossary.zip_path, reference_hash=expected_hash):
                    _extract_resource(glossary.zip_path, glossary.zip_path.parent)
                else:
                    print(f"Hash check failed twice - exiting.")
                    return False
        except Exception as e:
            print(f"Failed acquiring executable: {e}")
            return False
        else:
            print("Sourced Godot executable successfully.")
            if glossary.os_name in ["linux", "darwin"]:
                glossary.exec_path.chmod(glossary.exec_path.stat().st_mode | 0o111) # CHMOD +X
            return True
    return False


def show(port: int | None = None, active_client: client.GodoClient | None = None, active_scene: core._SceneState | None = None) -> int | None:
    """
    Run a Godot instance, along with the .pck.
    Returns the port number the instance is running on.
    """     
    # Resolve active instances
    ws_client = active_client or client._get_default_client()
    scene_state = active_scene or core._get_default_scene()

    if ws_client.is_connected:
        scene_state.flush(active_client=ws_client)
        return ws_client.port

    res = _source_godo()
    if not res:
        print("Sourcing Godot Executable failed, exiting.")
        return None
    
    if port is None:
        port = ws_client.port or 8080
    
    random.seed()
    port_retries = 20
    godot_needs_launch = True
    
    # Port Discovery and Verification Loop
    while port_retries > 0:
        if client._verify_process(port):
            ws_client.port = port
            ws_client.reset_godot()
            print(f"Found running Godot process at port {port}, resetting the scene.")
            godot_needs_launch = False
            break 
            
        # Only if the WebSocket is dead, check if the port is physically free.
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("0.0.0.0", port))
        except OSError:
            s.close()
            port = random.randint(7000, 30000)
            print(f"Retrying with port {port}.")
            port_retries -= 1
        else:
            s.close()
            break
    
    if port_retries == 0:
        print(f"No port found after {port_retries} retries. Exiting.")
        return None

    # Launching Godot
    if godot_needs_launch:
        if glossary.show_godo_logs_in_stdout:
            stdout = None
            stderr = None
        else:
            stdout = subprocess.DEVNULL
            stderr = subprocess.PIPE
        try:
            godot_process = subprocess.Popen([
                str(glossary.exec_path),
                "--main-pack",
                str(glossary.pck_path),
                "--port",
                str(port),
                "--network_buffer_mb",
                str(glossary.buffer_size),
                "--label-scale=" + str(glossary.font_size * 3e-5),
                ],
                stdout=stdout,
                stderr=stderr,
                text=True,
            )
        except Exception as e:
            print(f"An exception occurred when sublaunching godot: {e}")
            return None
        
        print(f"Sublaunched Godot successfully, port = {port}")

        # Ensure Godot started
        startup_retries = 20
        while startup_retries > 0:
            time.sleep(0.15)
            if client._verify_process(port=port):
                ws_client.port = port
                break
            startup_retries -= 1
        
        if startup_retries == 0:
            print("Godot sublaunched, but WebSocket server failed to start in time.")
            return None
    
    scene_state.flush(active_client=ws_client)
    ws_client.send_command("identify")
    
    return port
