from . import client


class   _SceneState:
    """
    Holds the current state of all generated plots before rendering.
    """
    
    def __init__(self):
        # Stores a list of tuples: (header_dict, binary_payload)
        self._draw_queue: list[tuple[dict, bytes]] = []


    def enqueue(self, header: dict, payload: bytes) -> None:
        """
        Adds a compiled plot to the staging queue.
        """
        self._draw_queue.append((header, payload))


    def clear(self) -> None:
        """
        Wipes the internal data state.
        """
        self._draw_queue.clear()


    def flush(self, active_client: client.GodoClient) -> None:
        """
        Pipes all stored plots sequentially through the network client.
        """
        for header, payload in self._draw_queue:
            active_client.send_data(header, payload)


_default_scene = _SceneState()


def _get_default_scene() -> _SceneState:
    return _default_scene
