import numpy as np
from .core import _get_default_scene
from .client import _get_default_client


def clear() -> None:
    """
    Clears the Python memory buffer AND wipes the Godot scene if connected.
    """
    _get_default_scene().clear()
    
    try:
        _get_default_client().reset_godot()
    except RuntimeError:
        pass


def point_scatter3d(
        x: list[float] | np.ndarray, 
        y: list[float] | np.ndarray, 
        z: list[float] | np.ndarray, 
        radius: int | None = 2, 
        color: str | None = "#0099FF81", 
        name: str | None = "defaultplot"
    ) -> None:
    """
    Compiles scatter coordinates into binary and stages them for rendering.
    """
    x_np = np.asarray(x, dtype='<f4')
    y_np = np.asarray(y, dtype='<f4')
    z_np = np.asarray(z, dtype='<f4')
    
    points = np.column_stack((x_np, y_np, z_np)).ravel()
    
    binary_payload = points.tobytes()
    
    assert radius is not None
    header = {
        "type": "scatter",
        "name": name,
        "config": {
            "radius": int(radius),
            "mesh_color": color,
            "interactive": True
        }
    }
    
    _get_default_scene().enqueue(header, binary_payload)


def surface3d(
        vertices, 
        faces, 
        vertex_colors=None, 
        color: str | None = "#FF5500", 
        wireframe: bool | None = False, 
        name: str | None = "defaultplot"
    ) -> None:
    """
    Compiles surface coordinates into binary and stages them for rendering.
    
    vertices: Array-like of shape (N, 3) for X, Y, Z coordinates.
    faces: Array-like of shape (M, 3) representing vertex indices for triangles.
    vertex_colors: Optional array-like of shape (N, 3) or (N, 4) for RGB/RGBA floats.
    """
    verts_np = np.asarray(vertices, dtype='<f4').ravel()
    verts_bytes = verts_np.tobytes()
    v_size = len(verts_bytes)
    
    if vertex_colors is not None:
        colors_np = np.asarray(vertex_colors, dtype='<f4').ravel()
        colors_bytes = colors_np.tobytes()
    else:
        colors_bytes = b''
        
    c_size = len(colors_bytes)

    indices_np = np.asarray(faces, dtype='<i4').ravel()
    indices_bytes = indices_np.tobytes()
    
    binary_payload = verts_bytes + colors_bytes + indices_bytes
    
    payload_dict = {
        "type": "surface",
        "name": name,
        "v_size": v_size,
        "c_size": c_size,
        "config": {
            "mesh_color": color,
            "wireframe": wireframe,
            "interactive": True
        }
    }
    
    _get_default_scene().enqueue(payload_dict, binary_payload)
