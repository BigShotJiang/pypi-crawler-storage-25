import numpy as np
import pytest
from godoplot.api import point_scatter3d


def test_scatter_binary_packing():
    """
    Verifies that the scatter API correctly flattens and 
    packs coordinates into float32 binary.
    """
    x = [1.0, 2.0]
    y = [3.0, 4.0]
    z = [5.0, 6.0]
    
    from godoplot.core import _get_default_scene
    scene = _get_default_scene()
    scene.clear()
    
    point_scatter3d(x, y, z, name="test_plot")
    
    header, payload = scene._draw_queue[0]
    
    # Verification
    assert header["type"] == "scatter"
    assert header["name"] == "test_plot"
    
    unpacked = np.frombuffer(payload, dtype="<f4")
    expected = np.array([1.0, 3.0, 5.0, 2.0, 4.0, 6.0], dtype="<f4")
    
    assert np.allclose(unpacked, expected)
