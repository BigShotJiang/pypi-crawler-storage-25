# flake8: noqa
from __future__ import annotations

def get_data_dir() -> str:
    """Returns the directory path keplime uses for bundled data files.

    Resolved from (in order): the ``KEPLIME_ASSET_DIRECTORY`` environment
    variable, the legacy ``KEPLIME_DATA_DIR`` environment variable, or a
    platform-specific default (``%LOCALAPPDATA%/keplime`` on Windows,
    ``~/Library/Application Support/keplime`` on macOS, or
    ``$XDG_DATA_HOME/keplime`` / ``~/.local/share/keplime`` on Linux).

    Returns:
        Absolute path to the data directory.
    """
    ...

def set_data_dir(path: str) -> None:
    """Sets the directory keplime uses for bundled data files.

    Creates the directory if it does not exist and updates both the
    ``KEPLIME_ASSET_DIRECTORY`` and the legacy ``KEPLIME_DATA_DIR``
    environment variables for the current process.

    Args:
        path: Filesystem path to use as the data directory.

    Raises:
        ValueError: If the directory cannot be created or accessed.
    """
    ...

def load_data_files(force_update: bool = False) -> None:
    """Downloads (if necessary) and preloads all required data files.

    Ensures that every required asset (IERS finals.1980 / finals.2000A,
    leap-second table, JPL Sun/Moon ephemerides, Celestrak space weather)
    is present in `get_data_dir`, refreshing stale copies in the
    background, then preloads the EOP tables and ephemerides into the
    process-global caches.

    The Python GIL is released for the duration of the call so the
    download and preload can run concurrently with other Python threads.

    Args:
        force_update: When ``True``, redownload every managed file
            (including the optional JB2008 SOLFSMY/DTC inputs) regardless
            of cache freshness.

    Raises:
        ValueError: If a required file cannot be downloaded or parsed.
    """
    ...

def ensure_data_file(filename: str, force_update: bool = False) -> str:
    """Ensures a single managed data file is present on disk.

    Downloads the file when missing or stale (subject to the auto-update
    policy and the per-file ``max_age``).  Unknown filenames simply
    return the path within the data directory without downloading.

    The Python GIL is released during any network or filesystem work.

    Args:
        filename: Bare filename (e.g. ``"finals.2000"``) to ensure.
        force_update: When ``True``, redownload the file regardless of
            cache freshness.

    Returns:
        Absolute path to the data file on disk.

    Raises:
        ValueError: If the file cannot be downloaded and is required.
    """
    ...

def data_refresh_pending() -> bool:
    """Reports whether any in-memory data table is stale relative to disk.

    Returns ``True`` when at least one managed required file on disk has a
    newer modification time than the in-memory cache loaded by this
    process.  Long-running applications can poll this to decide when to
    restart and pick up newly downloaded data.

    Returns:
        ``True`` when at least one in-memory cache is older than its
        on-disk file; ``False`` otherwise.
    """
    ...

class Finals2000Fields:
    """A single record from the IERS finals.2000A Earth-Orientation table.

    Returned by `at` and represents the EOP values
    linearly interpolated to the requested epoch.  All angular quantities
    are in radians; ``ut1_utc`` is in seconds.

    Attributes:
        ut1_utc (float): UT1−UTC offset [s].
        ut1_utc_error (float): Formal uncertainty of ``ut1_utc`` [s].
        polar_x (float): Celestial pole x-offset xₚ [rad].
        polar_x_error (float): Formal uncertainty of ``polar_x`` [arcsec].
        polar_y (float): Celestial pole y-offset yₚ [rad].
        polar_y_error (float): Formal uncertainty of ``polar_y`` [arcsec].
        dx (float): CIP dX correction to IAU 2006/2000A X coordinate [rad].
        dx_error (float): Formal uncertainty of ``dx`` [mas].
        dy (float): CIP dY correction to IAU 2006/2000A Y coordinate [rad].
        dy_error (float): Formal uncertainty of ``dy`` [mas].
    """

    @property
    def ut1_utc(self) -> float:
        """UT1−UTC offset [s].

        Positive values indicate UT1 is ahead of UTC.  Magnitude never
        exceeds 0.9 s because leap seconds keep |UT1−UTC| < 0.9 s.
        """
        ...

    @property
    def ut1_utc_error(self) -> float:
        """Formal uncertainty of `ut1_utc` [s]."""
        ...

    @property
    def polar_x(self) -> float:
        """Celestial pole x-offset xₚ (IERS Bulletin A, IAU 2000) [rad].

        Positive xₚ tilts the pole toward the Greenwich meridian (0°E).
        """
        ...

    @property
    def polar_x_error(self) -> float:
        """Formal uncertainty of `polar_x` [arcsec]."""
        ...

    @property
    def polar_y(self) -> float:
        """Celestial pole y-offset yₚ (IERS Bulletin A, IAU 2000) [rad].

        Positive yₚ tilts the pole toward 270°E (the 90°W meridian).
        """
        ...

    @property
    def polar_y_error(self) -> float:
        """Formal uncertainty of `polar_y` [arcsec]."""
        ...

    @property
    def dx(self) -> float:
        """IAU 2006/2000A CIP dX correction [rad].

        Add directly to the X coordinate returned by ``erfa.xys06a`` to
        obtain the observed CIP position.
        """
        ...

    @property
    def dx_error(self) -> float:
        """Formal uncertainty of `dx` [mas]."""
        ...

    @property
    def dy(self) -> float:
        """IAU 2006/2000A CIP dY correction [rad].

        Add directly to the Y coordinate returned by ``erfa.xys06a`` to
        obtain the observed CIP position.
        """
        ...

    @property
    def dy_error(self) -> float:
        """Formal uncertainty of `dy` [mas]."""
        ...

class Finals2000:
    """Accessor for the IERS finals.2000A Earth-Orientation table.

    Provides interpolated EOP records at any UTC epoch within the table
    range.  This object is stateless — every lookup goes through the
    process-global table loaded from ``data/finals.2000``.  Reachable as
    `finals2000`.
    """

    def at(self, mjd_utc: float) -> Finals2000Fields:
        """Interpolate the EOP record at a UTC epoch.

        Linearly interpolates between the two integer-MJD entries in the
        finals.2000A table that bracket ``mjd_utc``.

        Args:
            mjd_utc: UTC epoch [MJD days since 1858-11-17].

        Returns:
            Interpolated EOP record at ``mjd_utc``.

        Raises:
            ValueError: If ``mjd_utc`` is outside the table range or the
                table has not been initialized.
        """
        ...

class KepLimeData:
    """Registry of bundled astrodynamics data tables.

    Class-level attribute access provides a stateless handle to each
    supported table.  Use the handle's lookup methods (e.g.
    `at`) to retrieve interpolated values at a
    particular epoch.

    Attributes:
        finals2000 (Finals2000): IERS IAU 2000A Earth-Orientation table
            accessor (polar motion xₚ/yₚ, UT1−UTC, CIP offsets dX/dY).
    """

    finals2000: Finals2000
