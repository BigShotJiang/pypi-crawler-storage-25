from __future__ import annotations

from ._keplime import LicenseError  # type: ignore  # noqa: E402
from ._keplime import licensing as _licensing  # type: ignore  # noqa: E402

info = _licensing.info
install = _licensing.install

__all__ = ["LicenseError", "info", "install"]
