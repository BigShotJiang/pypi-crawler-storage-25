# flake8: noqa
from __future__ import annotations

from keplime.time import TimeSpan


def get_citra_residuals(
    citra_elset: dict[str, object],
    citra_observations: dict[str, list[dict[str, object]]],
) -> list[dict[str, object]]:
    """Compute citra-format residuals for a batch of citra observations.

    Returns one dict per input observation (in input order: optical, then radar,
    then doa). Each dict carries identifiers (``satellite_id``,
    ``observation_id``, ``elset_id``, ``elset_username``,
    ``elset_user_group_name``, ``review_status``), the source observation
    ``epoch`` (echoed from input), the residual ``total_error``
    (cross-line-of-sight, km), the ``type``
    (``"optical"`` / ``"radar"`` / ``"doa"``), and the residual numbers
    (``range`` km, ``range_rate`` km/s, ``right_ascension`` /
    ``declination`` / ``right_ascension_rate`` / ``declination_rate`` in
    **degrees**, ``tdoa`` s, ``fdoa`` Hz). ``visual_magnitude`` is populated
    only for optical entries.

    Note: ``elset_username`` and ``elset_user_group_name`` are populated from
    the citra elset dict's ``user_id`` and ``user_group_id`` fields (UUID
    strings). If you need resolved human-readable names, do that join in
    your own DB after this call.

    Args:
        citra_elset: CITRA elset dict. Must carry at minimum
            ``satellite_id`` and ``id`` (UUID strings), plus ``user_id``
            and ``user_group_id`` to populate ``elset_username`` /
            ``elset_user_group_name``.
        citra_observations: ``{"optical": [...], "radar": [...],
            "doa": [...]}`` mapping. Each list contains CITRA observation
            dicts for that type. Missing keys default to empty lists.

    Returns:
        One residual dict per input observation, in input order
        (optical, then radar, then DOA). Each dict carries the identifier
        and residual fields described above.

    Raises:
        ValueError: If a CITRA record fails to parse, the satellite
            cannot be constructed from the elset, or residual computation
            fails.
    """


def audit_citra_optical(
    citra_elsets: list[dict[str, object]],
    citra_observations: list[dict[str, object]],
    latest_span: TimeSpan,
    full_span: TimeSpan,
    expected_limits: list[dict[str, object]] | None = ...,
) -> list[dict[str, object]]:
    """Summarize optical residual stats per telescope.

    Each optical observation is attributed to an elset by matching the
    observation's ``satellite_id`` to the elset's ``satellite_id``. Input
    elsets that share a ``satellite_id`` are deduped by **first
    occurrence**; later duplicates are silently dropped. Each observation
    also carries a sensor identifier (``telescope_id`` for optical), used
    to break the residual stats out per sensor. Observations whose
    ``satellite_id`` is ``None`` are reported as
    ``uncorrelated_observation_count`` under the sensor that produced
    them and contribute no residual samples. A sensor that produces no
    usable bias / noise values across any field — e.g., uncorrelated
    tracks only, with no upstream ``creation_epoch`` to populate
    ``ingest_delay`` — is omitted from the output entirely.

    Per-sensor window selection driven by ``expected_limits``:

    * Sensors **with** an entry in ``expected_limits`` are evaluated
      over the **short** window ``[S_last - latest_span, S_last]``,
      and the per-sensor ``status`` is checked against the supplied
      bias / noise bounds. ``latest_span`` is a **cap** — even a
      newly-active sensor with little data still gets a block.
    * Sensors **without** an entry in ``expected_limits`` (the
      un-characterized ones) are calibrated over **every sample**
      the sensor has produced. ``full_span`` here is a **minimum
      required calibration history**: if the sensor's
      ``S_last - S_first`` span is less than ``full_span``, the
      sensor is **omitted** from the output entirely — there isn't
      enough baseline to calibrate against. There is no cap on the
      long-baseline path: a 36-hour query against a 12-hour minimum
      runs over the full 36 hours.

    ``S_last`` is the sensor's own latest sample, so a sensor whose
    data ends earlier than another's still gets evaluated against
    its own recent activity.

    Args:
        citra_elsets: List of CITRA elset dicts (same per-element shape as
            the elset arg of `get_citra_residuals`).
        citra_observations: List of CITRA optical observation dicts.
        latest_span: Width of the short window applied to sensors
            that appear in ``expected_limits``. Acts as a **cap**.
            Must satisfy ``latest_span <= full_span``.
        full_span: **Minimum** calibration history required for
            sensors that do **not** appear in ``expected_limits``.
            Sensors with less than ``full_span`` of data are omitted
            from the output; sensors that meet the minimum are
            calibrated over their entire sample set (no cap).
        expected_limits: Optional list of per-sensor limit dicts. Each
            entry is ``{"sensor_id": <sensor_uuid>, "<field>_bias": float,
            "<field>_noise": float, ...}`` (other keys are silently
            ignored, so the prior audit's output list can be passed
            back in directly). Missing bias/noise keys mean "do not
            check that field". Sensors absent from the list go on
            the calibration (``full_span`` minimum) path with
            ``status = "nominal"``.

    Returns:
        List of per-sensor stat blocks (``[{...}, {...}]``). Each
        block contains:

        * ``id`` (str): fresh UUIDv4 identifying this audit
            *record* (generated per call). Use this when persisting
            audit history.
        * ``sensor_id`` (str): the telescope / antenna UUID this
            audit block is for. Match on this when correlating across
            runs or providing limits.
        * ``sensor_type`` (str): ``"telescope"`` or ``"antenna"``.
        * ``audit_type`` (str): ``"trend"`` when this sensor was
            listed in ``expected_limits`` (short window,
            status-checking path) or ``"baseline"`` when it wasn't
            (calibration path, full sample set).
        * ``uncorrelated_observation_count`` (int): observations from
            this sensor in the window with no ``satellite_id``.
        * ``correlated_observation_count`` (int): observations from
            this sensor in the window matched to a deduped elset.
        * ``observed_satellite_count`` (int): distinct correlated
            ``satellite_id`` values produced by this sensor in the
            window. Uncorrelated tracks contribute zero.
        * ``first_epoch`` (str | None): earliest sample epoch within
            this sensor's chosen window, ISO 8601 UTC.
        * ``last_epoch`` (str | None): the sensor's own latest sample
            epoch, ISO 8601 UTC. Anchors the window thresholds.
        * ``time_bias`` [s], ``time_noise`` [s], ``angular_bias``
            [deg], ``angular_noise`` [deg] (great-circle separation
            between observed and expected pointing direction),
            ``angular_rate_bias`` [deg/s], ``angular_rate_noise``
            [deg/s] (L2 magnitude with the standard ``cos(dec)`` scaling
            on the RA-rate component), ``ingest_delay_bias`` [s],
            ``ingest_delay_noise`` [s] (``creation_epoch - epoch`` when
            the upstream observation carried a ``creation_epoch``):
            each is either a float (``bias`` is the **signed** sample
            median, ``noise`` is the median absolute deviation, always
            ``>= 0``) or ``None`` when the field's sample pool in the
            window is empty.
        * ``<field>_status`` (str, one per measurement-quality
            field): ``"nominal"`` or ``"degraded"`` for *that field*.
            Flagged ``"degraded"`` when the sensor is listed in
            ``expected_limits``, the field's pool is non-empty, and
            **either** drift bound is exceeded:

            * ``|new_bias| > |expected_<field>_bias| + 3 * expected_<field>_noise``
            * ``new_noise > 2 * expected_<field>_noise``

            Both bounds use ``expected_<field>_noise`` (an observed
            MAD) as the measurement-uncertainty unit, so casual
            run-to-run variance doesn't trip the check. If the caller
            didn't supply ``<field>_noise``, neither bound fires. Empty
            pools, unlisted fields, and sensors absent from
            ``expected_limits`` all stay ``"nominal"``. ``ingest_delay``
            is informational metadata and does **not** get a
            ``_status`` key; ``ingest_delay_*`` entries in
            ``expected_limits`` are ignored.
        * ``status`` (str): aggregate, ``"nominal"`` or
            ``"degraded"``. ``"degraded"`` iff **any** per-field
            ``<field>_status`` is ``"degraded"`` — use the per-field
            keys to find which one tripped.

    Raises:
        ValueError: ``latest_span`` is greater than ``full_span``; or a
            CITRA record fails to parse.

    Per-satellite construction, ephemeris caching, or residual
    computation failures are logged at ``WARN`` and the offending
    satellite is dropped from the audit; they do not raise.
    """


def audit_citra_radar(
    citra_elsets: list[dict[str, object]],
    citra_observations: list[dict[str, object]],
    latest_span: TimeSpan,
    full_span: TimeSpan,
    expected_limits: list[dict[str, object]] | None = ...,
) -> list[dict[str, object]]:
    """Summarize radar residual stats per radar antenna.

    Grouping, dedupe, the count fields, the per-sensor windowing rule,
    and ``expected_limits`` semantics match
    `audit_citra_optical`. Per-sensor keys are the radar
    ``antenna_id``. Per-sensor stat-block fields:
    ``range_bias`` / ``range_noise`` [km], ``range_rate_bias`` /
    ``range_rate_noise`` [km/s], ``angular_bias`` / ``angular_noise``
    [deg], ``angular_rate_bias`` / ``angular_rate_noise`` [deg/s], and
    ``ingest_delay_bias`` / ``ingest_delay_noise`` [s]. Radar
    observations may carry RA/Dec independently of monostatic vs.
    bistatic geometry; the angular pools draw from any radar
    observation that has them. Observations whose measurement field is
    missing still count toward ``correlated_observation_count`` but
    contribute no samples to that field's pool.

    Args:
        citra_elsets: List of CITRA elset dicts (same per-element shape
            as the elset arg of `get_citra_residuals`).
        citra_observations: List of CITRA radar observation dicts.
        latest_span: Width of the short window applied to sensors that
            appear in ``expected_limits``. Acts as a **cap**. Must
            satisfy ``latest_span <= full_span``.
        full_span: **Minimum** calibration history required for sensors
            that do **not** appear in ``expected_limits``. Sensors with
            less than ``full_span`` of data are omitted from the output;
            sensors that meet the minimum are calibrated over their
            entire sample set (no cap).
        expected_limits: Optional list of per-sensor limit dicts. See
            `audit_citra_optical` for the full shape.

    Returns:
        List of per-sensor stat blocks (one per radar antenna that
        produced data and met the calibration minimum, or that is listed
        in ``expected_limits``). Each block contains the common fields
        documented on `audit_citra_optical` plus radar-specific
        measurement fields: ``range_bias`` / ``range_noise`` [km],
        ``range_rate_bias`` / ``range_rate_noise`` [km/s], ``angular_bias``
        / ``angular_noise`` [deg], ``angular_rate_bias`` /
        ``angular_rate_noise`` [deg/s], and ``ingest_delay_bias`` /
        ``ingest_delay_noise`` [s].

    Raises:
        ValueError: ``latest_span`` is greater than ``full_span``; or a
            CITRA record fails to parse.

    Per-satellite construction, ephemeris caching, or residual
    computation failures are logged at ``WARN`` and the offending
    satellite is dropped from the audit; they do not raise.
    """


def audit_citra_doa(
    citra_elsets: list[dict[str, object]],
    citra_observations: list[dict[str, object]],
    latest_span: TimeSpan,
    full_span: TimeSpan,
    expected_limits: list[dict[str, object]] | None = ...,
) -> list[dict[str, object]]:
    """Summarize direction-of-arrival (TDOA) residual stats per DOA antenna.

    Grouping, dedupe, the count fields, the per-sensor windowing rule,
    and ``expected_limits`` semantics match
    `audit_citra_optical`. Per-sensor keys are the DOA
    ``primary_antenna_id``. Per-sensor stat-block fields:
    ``tdoa_bias`` / ``tdoa_noise`` [s] and ``ingest_delay_bias`` /
    ``ingest_delay_noise`` [s]. ``angular`` / ``angular_rate`` are not
    exposed at this level because DOA observations don't carry
    pointing data; the unified antenna block
    (`audit_citra_sensors`) surfaces them when a sister radar
    observation provides them.

    Args:
        citra_elsets: List of CITRA elset dicts (same per-element shape
            as the elset arg of `get_citra_residuals`).
        citra_observations: List of CITRA DOA observation dicts.
        latest_span: Width of the short window applied to sensors that
            appear in ``expected_limits``. Acts as a **cap**. Must
            satisfy ``latest_span <= full_span``.
        full_span: **Minimum** calibration history required for sensors
            that do **not** appear in ``expected_limits``. Sensors with
            less than ``full_span`` of data are omitted from the output;
            sensors that meet the minimum are calibrated over their
            entire sample set (no cap).
        expected_limits: Optional list of per-sensor limit dicts. See
            `audit_citra_optical` for the full shape.

    Returns:
        List of per-sensor stat blocks (one per DOA antenna that
        produced data and met the calibration minimum, or that is listed
        in ``expected_limits``). Each block contains the common fields
        documented on `audit_citra_optical` plus DOA-specific
        measurement fields: ``tdoa_bias`` / ``tdoa_noise`` [s] and
        ``ingest_delay_bias`` / ``ingest_delay_noise`` [s]. Angular
        fields are not included because DOA observations do not carry
        pointing data.

    Raises:
        ValueError: ``latest_span`` is greater than ``full_span``; or a
            CITRA record fails to parse.

    Per-satellite construction, ephemeris caching, or residual
    computation failures are logged at ``WARN`` and the offending
    satellite is dropped from the audit; they do not raise.
    """


def audit_citra_sensors(
    citra_elsets: list[dict[str, object]],
    sensors: dict[str, list[dict[str, object]]],
    observations: dict[str, list[dict[str, object]]],
    latest_span: TimeSpan,
    full_span: TimeSpan,
    expected_limits: list[dict[str, object]] | None = ...,
) -> list[dict[str, object]]:
    """Audit a fleet of CITRA sensors per sensor.

    Unified entry point. Optical observations are aggregated per
    ``telescope_id`` (each block tagged ``"sensor_type":
    "telescope"``); radar and DOA observations are aggregated per
    antenna identifier (``antenna_id`` for radar,
    ``primary_antenna_id`` for DOA) and each block tagged
    ``"sensor_type": "antenna"``. Telescope and antenna blocks are
    returned in a single flat list — split downstream by the
    ``sensor_type`` key if you need per-type views.

    Only sensors that produced at least one usable bias / noise value
    appear in the output. Catalog sensors listed in ``sensors`` but with
    no observations are omitted regardless of whether they appear in
    ``expected_limits``, and sensors whose observations all
    fail to populate a bias / noise pool (e.g., uncorrelated tracks
    only, with no upstream ``creation_epoch``) are likewise omitted.
    Callers that need to detect silent or content-free sensors must
    cross-reference the input catalog themselves. Per-sensor windowing
    and ``expected_limits`` semantics match `audit_citra_optical`.

    Args:
        citra_elsets: List of CITRA elset dicts.
        sensors: ``{"telescopes": [<telescope_dict>, ...],
            "antennas": [<antenna_dict>, ...]}``. Each sensor dict must
            carry a string ``id``; richer schema fields are accepted
            and ignored. Missing top-level keys default to empty lists.
        observations: ``{"optical": [...], "radar": [...],
            "doa": [...]}``. Each list is the same shape as the
            observation arg of the per-type audit functions. Missing
            keys default to empty lists.
        latest_span: Width of the short window applied to sensors
            that appear in ``expected_limits``. Acts as a **cap**.
            Must satisfy ``latest_span <= full_span``.
        full_span: **Minimum** calibration history required for
            sensors that do **not** appear in ``expected_limits``.
            Sensors with less than ``full_span`` of data are omitted
            from the output; sensors that meet the minimum are
            calibrated over their entire sample set (no cap).
        expected_limits: Optional list of per-sensor limit dicts. Each
            entry is ``{"sensor_id": <sensor_uuid>, "<field>_bias": float,
            ...}``; non-bias/noise keys (counts, epochs, status,
            type, ...) are silently ignored, so the prior audit's
            output list can be passed back in directly. Sensors
            absent from this list go on the calibration
            (``full_span`` minimum) path.

    Returns:
        Flat list of per-sensor stat blocks
        (``[{"id": <audit_record_uuid>, "sensor_id": <sensor_uuid>,
        "sensor_type": "telescope" | "antenna", "audit_type":
        "trend" | "baseline", ...}, ...]``).
        Telescope blocks carry the optical fields documented on
        `audit_citra_optical`; antenna blocks carry the union
        of radar + DOA fields (``range_*``, ``range_rate_*``,
        ``angular_*``, ``angular_rate_*``, ``tdoa_*``,
        ``ingest_delay_*`` — each as a flat ``_bias`` / ``_noise``
        pair, plus ``_status`` for every measurement-quality field).

    Raises:
        ValueError: ``latest_span`` is greater than ``full_span``; or a
            CITRA record fails to parse.

    Per-satellite construction, ephemeris caching, or residual
    computation failures are logged at ``WARN`` and the offending
    satellite is dropped from the audit; they do not raise.
    """


__all__ = [
    "get_citra_residuals",
    "audit_citra_optical",
    "audit_citra_radar",
    "audit_citra_doa",
    "audit_citra_sensors",
]
