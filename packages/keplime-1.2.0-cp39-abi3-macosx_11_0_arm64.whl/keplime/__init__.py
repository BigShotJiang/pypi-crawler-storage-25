"""keplime — astrodynamics primitives with Rust-backed propagation and access analysis.

Logging
-------
keplime emits log records through Python's :mod:`logging` system.  Rust-side
``log::info!`` / ``log::warn!`` / ``log::debug!`` calls are bridged to Python
via ``pyo3-log`` at module import, then routed to the ``"keplime"`` logger and
its child loggers (one per module, e.g. ``"keplime::elements::ephemeris"``).

Following the standard convention for libraries, keplime attaches a
:class:`logging.NullHandler` to its package logger and **does not** configure
any output destination on its own.  The hosting application decides where
records go.  To surface keplime logs, the caller adds a handler and selects a
level::

    import logging
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    logging.getLogger("keplime").setLevel(logging.INFO)

The Python logger level controls Rust output through the bridge — no
``RUST_LOG`` environment variable is required.
"""

from __future__ import annotations

import logging

from . import bodies, catalogs, data, elements, enums, estimation, events, frames, iod, licensing, propagation, schemas, signatures, time
from ._keplime import LicenseError, get_thread_count, set_thread_count  # type: ignore  # noqa: E402

logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "LicenseError",
    "bodies",
    "catalogs",
    "data",
    "elements",
    "enums",
    "estimation",
    "events",
    "frames",
    "get_thread_count",
    "iod",
    "licensing",
    "propagation",
    "schemas",
    "set_thread_count",
    "signatures",
    "time",
]
