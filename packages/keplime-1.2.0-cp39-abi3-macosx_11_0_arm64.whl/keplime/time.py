from __future__ import annotations

from ._keplime import time as _time  # type: ignore  # noqa: E402

ModifiedJulianDate = _time.ModifiedJulianDate
TimeSpan = _time.TimeSpan

__all__ = ["ModifiedJulianDate", "TimeSpan"]
