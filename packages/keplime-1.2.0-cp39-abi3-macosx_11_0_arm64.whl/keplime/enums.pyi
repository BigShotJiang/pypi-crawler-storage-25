# flake8: noqa
from __future__ import annotations

class DevicePreference:
    """Controls whether batch propagation runs on CPU, GPU, or selects automatically.

    The default variant is `CPU`.

    Attributes:
        CPU (DevicePreference): Force CPU-only execution via the rayon thread pool
            (default).
        GPU (DevicePreference): Force GPU execution via wgpu.  The propagator raises
            ``RuntimeError`` when the ``gpu`` feature is disabled or no compatible
            adapter is found at propagation time.
        Auto (DevicePreference): Automatic selection based on workload size; falls
            back to CPU for small batches.
    """

    CPU: DevicePreference
    GPU: DevicePreference
    Auto: DevicePreference

    def get_name(self) -> str:
        """Returns the string name of this device preference.

        Returns:
            str: One of ``"CPU"``, ``"GPU"``, ``"Auto"``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class AssociationConfidence:
    """Confidence level for an observation-to-object association.

    Numeric values increase with confidence: ``Low=0``, ``Medium=1``,
    ``High=2``.

    Attributes:
        High (AssociationConfidence): Strong match across multiple metrics;
            association is reliable.
        Medium (AssociationConfidence): Partial or ambiguous match; should be
            reviewed before acting on.
        Low (AssociationConfidence): Weak or speculative match; treat with
            caution.
    """

    High: AssociationConfidence
    Medium: AssociationConfidence
    Low: AssociationConfidence

    def get_name(self) -> str:
        """Returns the string name of this confidence level.

        Returns:
            str: One of ``"High"``, ``"Medium"``, ``"Low"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this confidence level.

        Returns:
            int: ``Low=0``, ``Medium=1``, ``High=2``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class CitraObservationType:
    """Sensor modality of a Citra observation.

    The string value (returned by `get_value`) is the lowercase serde
    serialisation used in JSON payloads.

    Attributes:
        Optical (CitraObservationType): Passive optical measurement
            (right ascension / declination angles).
        Radar (CitraObservationType): Active radar measurement (range and/or
            range-rate).
        Doa (CitraObservationType): Direction-of-arrival (DOA) RF measurement
            (azimuth / elevation angles).
    """

    Optical: CitraObservationType
    Radar: CitraObservationType
    Doa: CitraObservationType

    def get_name(self) -> str:
        """Returns the display name of this observation type.

        Returns:
            str: One of ``"Optical"``, ``"Radar"``, ``"Doa"``.
        """
        ...

    def get_value(self) -> str:
        """Returns the lowercase serde serialisation string for this observation type.

        Returns:
            str: One of ``"optical"``, ``"radar"``, ``"doa"``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class CovarianceType:
    """Coordinate basis in which a state covariance matrix is expressed.

    Three variants are supported:

    * ``Inertial(frame)`` — Earth-centred inertial Cartesian covariance,
      parameterised by which inertial [`ReferenceFrame`][keplime.enums.ReferenceFrame]
      the matrix is expressed in. Must be one of ``TEME``, ``J2000``, or
      ``GCRS``. Constructed via the static method
      ``CovarianceType.Inertial(ReferenceFrame.TEME)``.
    * ``Relative`` — RIC (Radial-In-track-Cross-track) local frame defined
      by the reference state's r, v. Accessed as the class attribute
      ``CovarianceType.Relative``.
    * ``Equinoctial`` — covariance in equinoctial element space
      ``[a, h, k, p, q, L]``. Accessed as the class attribute
      ``CovarianceType.Equinoctial``.

    Attributes:
        Relative (CovarianceType): Covariance in the RIC
            (Radial-In-track-Cross-track) relative frame [km, km/s].
        Equinoctial (CovarianceType): Covariance in equinoctial element space.
    """

    Relative: CovarianceType
    Equinoctial: CovarianceType

    @staticmethod
    def Inertial(frame: ReferenceFrame) -> CovarianceType:
        """Constructs an Inertial covariance-type tag parameterised by the
        specific inertial frame.

        Args:
            frame: One of ``ReferenceFrame.TEME``, ``ReferenceFrame.J2000``,
                or ``ReferenceFrame.GCRS``.

        Returns:
            An ``Inertial(frame)`` tag.

        Raises:
            ValueError: If ``frame`` is ``ITRF``, ``PEF``, or ``RIC`` — those
                are not inertial Cartesian frames.
        """
        ...

    def get_name(self) -> str:
        """Returns the string name of this covariance type.

        Returns:
            str: ``"Inertial(<frame>)"`` for an ``Inertial`` variant,
            ``"Relative"`` or ``"Equinoctial"`` otherwise.
        """
        ...

    def get_inertial_frame(self) -> ReferenceFrame | None:
        """Returns the embedded inertial
        [`ReferenceFrame`][keplime.enums.ReferenceFrame] for the
        ``Inertial`` variant, or ``None`` for ``Relative`` / ``Equinoctial``.

        Returns:
            The embedded frame for the ``Inertial`` variant, otherwise
            ``None``.
        """
        ...

    def is_inertial(self) -> bool:
        """Returns ``True`` if this tag is the ``Inertial`` variant.

        Returns:
            ``True`` for ``Inertial(_)``, ``False`` otherwise.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this covariance type.

        The mapping is lossy for the ``Inertial`` variant: every embedded
        frame returns ``0``. Use
        [`get_inertial_frame`][keplime.enums.CovarianceType.get_inertial_frame]
        to recover the specific inertial frame.

        Returns:
            ``0`` for any ``Inertial(_)``, ``1`` for ``Relative``, ``2`` for
            ``Equinoctial``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class Classification:
    """Data classification level for observation and orbit products.

    Numeric values increase with sensitivity: ``Unclassified=0``,
    ``Confidential=1``, ``Secret=2``.

    Attributes:
        Unclassified (Classification): Publicly releasable data.
        Confidential (Classification): Sensitive data restricted to authorised
            personnel.
        Secret (Classification): Highly sensitive data with strict access
            controls.
    """

    Unclassified: Classification
    Confidential: Classification
    Secret: Classification

    def get_name(self) -> str:
        """Returns the string name of this classification level.

        Returns:
            str: One of ``"Unclassified"``, ``"Confidential"``, ``"Secret"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this classification level.

        Returns:
            int: ``Unclassified=0``, ``Confidential=1``, ``Secret=2``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class OrbitDeterminationQuality:
    """Quality classification for an orbit determination solution.

    Higher quality indicates more observations, better residuals, and smaller
    position uncertainty.  Numeric values: ``Low=0``, ``Medium=1``,
    ``High=2``.

    Attributes:
        High (OrbitDeterminationQuality): Well-determined orbit; low position
            uncertainty, many observations.
        Medium (OrbitDeterminationQuality): Moderately constrained orbit;
            acceptable for routine tasking.
        Low (OrbitDeterminationQuality): Poorly constrained orbit; large
            uncertainty, use with caution.
    """

    High: OrbitDeterminationQuality
    Medium: OrbitDeterminationQuality
    Low: OrbitDeterminationQuality

    def get_name(self) -> str:
        """Returns the string name of this quality level.

        Returns:
            str: One of ``"High"``, ``"Medium"``, ``"Low"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this quality level.

        Returns:
            int: ``Low=0``, ``Medium=1``, ``High=2``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class KeplerianType:
    """Orbit element type describing the averaging theory or osculating convention.

    The type determines the compatible propagator and gravitational parameter
    (μ).  GP types use WGS72 constants with SGP4/SDP4; XP and osculating types
    use EGM96 constants with the numerical XP integrator.

    Attributes:
        MeanKozaiGP (KeplerianType): Mean elements, Kozai SGP4/SDP4 secular
            theory, WGS72 μ.  Integer code 0.
        MeanBrouwerGP (KeplerianType): Mean elements, Brouwer
            general-perturbation theory, WGS72 μ.  Integer code 2.
        MeanBrouwerXP (KeplerianType): Mean elements, Brouwer
            extended-perturbation (XP) theory, EGM96 μ.  Integer code 4.
        Osculating (KeplerianType): Osculating (instantaneous) Keplerian
            elements, EGM96 μ.  Integer code 6.
    """

    MeanKozaiGP: KeplerianType
    MeanBrouwerGP: KeplerianType
    MeanBrouwerXP: KeplerianType
    Osculating: KeplerianType

    def get_name(self) -> str:
        """Returns the string name of this Keplerian type.

        Returns:
            str: One of ``"MeanKozaiGP"``, ``"MeanBrouwerGP"``,
            ``"MeanBrouwerXP"``, ``"Osculating"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this Keplerian type.

        Returns:
            int: ``MeanKozaiGP=0``, ``MeanBrouwerGP=2``, ``MeanBrouwerXP=4``,
            ``Osculating=6``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class PerformancePriority:
    """Performance/accuracy priority for frame transforms and force models.

    Used to select between full-precision, balanced, and fast model variants
    (e.g. IAU 2000A vs. IAU 2000B nutation series).

    Attributes:
        Precision (PerformancePriority): Full IAU 2000A nutation/precession
            series; highest accuracy, highest CPU cost.
        Balanced (PerformancePriority): Hybrid profile with IAU 2000B nutation
            and moderate-fidelity frame transforms.
        Speed (PerformancePriority): IAU 2000B nutation with IAU 2006 precession
            adjustments; fastest, lowest accuracy.
    """

    Precision: PerformancePriority
    Balanced: PerformancePriority
    Speed: PerformancePriority

    def get_name(self) -> str:
        """Returns the string name of this performance priority.

        Returns:
            str: One of ``"Precision"``, ``"Balanced"``, ``"Speed"``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class ReferenceFrame:
    """Cartesian reference frame for position and velocity vectors.

    Frames are divided into inertial (ECI), Earth-fixed (ECF), and relative
    categories.  The ``frames`` module provides transforms between all listed
    frames.

    Attributes:
        TEME (ReferenceFrame): True Equator, Mean Equinox – native SGP4/SDP4
            output frame.
        ITRF (ReferenceFrame): International Terrestrial Reference Frame;
            Earth-fixed, includes polar motion.
        PEF (ReferenceFrame): Pseudo-Earth-Fixed; Earth-fixed without
            polar-motion correction.
        J2000 (ReferenceFrame): J2000 mean-equatorial inertial frame
            (ECI / EME2000).
        GCRS (ReferenceFrame): Geocentric Celestial Reference System; ECI frame
            aligned to IAU 2000A.
        RIC (ReferenceFrame): Radial-In-track-Cross-track
            local-vertical/local-horizontal relative frame.
    """

    TEME: ReferenceFrame
    ITRF: ReferenceFrame
    PEF: ReferenceFrame
    J2000: ReferenceFrame
    GCRS: ReferenceFrame
    RIC: ReferenceFrame

    def get_name(self) -> str:
        """Returns the string name of this reference frame.

        Returns:
            str: One of ``"TEME"``, ``"ITRF"``, ``"PEF"``, ``"J2000"``,
            ``"GCRS"``, ``"RIC"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this reference frame.

        Returns:
            int: ``TEME=0``, ``ITRF=1``, ``PEF=2``, ``J2000=3``,
            ``GCRS=4``, ``RIC=5``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class RelativeFrame:
    """Describes whether a relative state is expressed in a rotating or inertial frame.

    Used when reporting proximity or close-approach states between two objects.

    Attributes:
        Rotating (RelativeFrame): RIC (Radial-In-track-Cross-track) rotating
            frame; co-rotates with the reference orbit.
        Inertial (RelativeFrame): Position and velocity difference expressed in
            the inertial ECI frame.
    """

    Rotating: RelativeFrame
    Inertial: RelativeFrame

    def get_name(self) -> str:
        """Returns the string name of this relative frame.

        Returns:
            str: One of ``"Rotating"``, ``"Inertial"``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class TimeSystem:
    """Time reference system for epoch values.

    Every [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] carries an explicit
    ``TimeSystem`` tag.  Use
    [`to_system`][keplime.time.ModifiedJulianDate.to_system] to convert between
    systems.

    The conversion graph supported by the library is:

    ```text
    UTC ↔ TAI ↔ TT ↔ TDB
    UTC ↔ UT1
    GPS ↔ TAI
    ```

    Attributes:
        UTC (TimeSystem): Coordinated Universal Time; the standard civil
            timescale with leap seconds.
        TAI (TimeSystem): International Atomic Time; continuous, no leap
            seconds.  TAI = UTC + (current leap-second offset).
        TT (TimeSystem): Terrestrial Time; TT = TAI + 32.184 s, used in modern
            ephemerides.
        UT1 (TimeSystem): Universal Time corrected for Earth rotation; offset
            from UTC provided by IERS Finals tables (|UT1−UTC| < 0.9 s).
        TDB (TimeSystem): Barycentric Dynamical Time; differs from TT by up to
            ~1.7 ms due to relativistic periodic terms.
        GPS (TimeSystem): Global Positioning System time; continuous atomic
            timescale used by GNSS. GPS = TAI − 19 s; epoch 1980-01-06T00:00:00
            UTC. No leap seconds.
    """

    UTC: TimeSystem
    TAI: TimeSystem
    TT: TimeSystem
    UT1: TimeSystem
    TDB: TimeSystem
    GPS: TimeSystem

    def get_name(self) -> str:
        """Returns the string name of this time system.

        Returns:
            str: One of ``"UTC"``, ``"TAI"``, ``"TT"``, ``"UT1"``, ``"TDB"``,
                ``"GPS"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this time system.

        Returns:
            int: ``UTC=0``, ``TAI=1``, ``TT=2``, ``UT1=3``, ``TDB=4``,
                ``GPS=5``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class UCTObservability:
    """Observability status of an uncorrelated track (UCT) against a sensor pass.

    Numeric values: ``Confirmed=0``, ``Possible=1``, ``Unavailable=2``.

    Attributes:
        Confirmed (UCTObservability): Object is geometrically confirmed within
            the sensor's field of view.
        Possible (UCTObservability): Object may be observable depending on
            attitude, obscuration, or sensitivity.
        Unavailable (UCTObservability): Object is not observable (geometry,
            Earth shadow, or out-of-range).
    """

    Confirmed: UCTObservability
    Possible: UCTObservability
    Unavailable: UCTObservability

    def get_name(self) -> str:
        """Returns the string name of this observability status.

        Returns:
            str: One of ``"Confirmed"``, ``"Possible"``, ``"Unavailable"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this observability status.

        Returns:
            int: ``Confirmed=0``, ``Possible=1``, ``Unavailable=2``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class UCTValidity:
    """Classifier for the physical validity of an uncorrelated track (UCT).

    Numeric values: ``LikelyReal=0``, ``PossibleCrossTag=1``,
    ``PossibleManeuver=2``, ``Inconclusive=3``.

    Attributes:
        LikelyReal (UCTValidity): Track residuals are consistent with a real,
            stable object.
        PossibleCrossTag (UCTValidity): Track may result from a cross-tag
            (misassociation) between two objects.
        PossibleManeuver (UCTValidity): Track exhibits dynamics consistent with
            a manoeuvre or unusual perturbation.
        Inconclusive (UCTValidity): Validity cannot be determined from available
            data.
    """

    LikelyReal: UCTValidity
    PossibleCrossTag: UCTValidity
    PossibleManeuver: UCTValidity
    Inconclusive: UCTValidity

    def get_name(self) -> str:
        """Returns the string name of this validity classification.

        Returns:
            str: One of ``"LikelyReal"``, ``"PossibleCrossTag"``,
            ``"PossibleManeuver"``, ``"Inconclusive"``.
        """
        ...

    def get_value(self) -> int:
        """Returns the integer code for this validity classification.

        Returns:
            int: ``LikelyReal=0``, ``PossibleCrossTag=1``,
            ``PossibleManeuver=2``, ``Inconclusive=3``.
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
