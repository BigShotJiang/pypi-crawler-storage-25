from __future__ import annotations

from ._keplime import events as _events  # type: ignore  # noqa: E402

CloseApproach = _events.CloseApproach
CloseApproachReport = _events.CloseApproachReport
FieldOfViewCandidate = _events.FieldOfViewCandidate
FieldOfViewReport = _events.FieldOfViewReport
HorizonAccess = _events.HorizonAccess
HorizonAccessReport = _events.HorizonAccessReport
ManeuverEvent = _events.ManeuverEvent
ManeuverReport = _events.ManeuverReport
ProximityEvent = _events.ProximityEvent
ProximityReport = _events.ProximityReport
SensorAccess = _events.SensorAccess
SensorAccessReport = _events.SensorAccessReport
UCTValidityReport = _events.UCTValidityReport

__all__ = [
    "CloseApproach",
    "CloseApproachReport",
    "FieldOfViewCandidate",
    "FieldOfViewReport",
    "HorizonAccess",
    "HorizonAccessReport",
    "ManeuverEvent",
    "ManeuverReport",
    "ProximityEvent",
    "ProximityReport",
    "SensorAccess",
    "SensorAccessReport",
    "UCTValidityReport",
]
