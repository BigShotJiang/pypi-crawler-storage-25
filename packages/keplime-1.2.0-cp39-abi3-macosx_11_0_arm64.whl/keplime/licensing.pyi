# flake8: noqa
from __future__ import annotations

from typing import Optional, TypedDict

class LicenseError(Exception):
    """Raised when keplime cannot validate the license.

    A single ``LicenseError`` type covers every license-validation
    outcome — missing file, malformed blob, bad Ed25519 signature,
    expired license, unsupported schema, or unsupported binding. The
    message embedded in the exception describes which case applies
    and what the user should do.

    Raised at:

    * ``import keplime`` — if no license can be resolved or the
      resolved license fails any check. The Python import fails;
      the rest of the package is not available in this process.
    * [`install`][keplime.licensing.install] — if the supplied source
      is not a readable file or does not contain a valid blob.

    Catch with:

    ```python
    try:
        import keplime
    except keplime.LicenseError as exc:
        print(f"license problem: {exc}")
    ```
    """
    ...

class LicenseInfo(TypedDict):
    """Dict shape returned by `info`."""

    license_id: str
    customer_id: str
    customer_name: str
    issued_at: int
    expires_at: Optional[int]
    schema_version: int

def info() -> LicenseInfo:
    """Returns metadata for the license active in this process.

    Reads from the in-process cache populated at import time — does
    not re-run signature verification. Safe to call from hot paths.

    Returns:
        Dict with keys ``license_id`` (str UUID), ``customer_id``
        (str), ``customer_name`` (str), ``issued_at`` (int
        [unix-epoch seconds]), ``expires_at`` (Optional[int]
        [unix-epoch seconds]; ``None`` for perpetual licenses), and
        ``schema_version`` (int).

    Raises:
        LicenseError: If no license has been validated in this
            process. In normal usage this is unreachable because
            ``import keplime`` would have failed first.
    """
    ...

def install(source: str) -> None:
    """Installs a license file at the default data-dir location.

    The argument may be either the license blob itself (a string
    containing exactly one ``.`` separator) or a filesystem path to
    a file containing one. In either case the contents are written
    verbatim to ``{data_dir}/license.key`` so the next process to
    ``import keplime`` picks them up automatically.

    Does **not** re-validate the current process — restart Python
    to pick up the new license.

    Args:
        source: License blob, or path to a file containing one.

    Raises:
        LicenseError: If the source is unreadable, does not look
            like a license blob (missing ``.`` separator), or if
            the destination path cannot be written.
    """
    ...

__all__ = ["LicenseError", "LicenseInfo", "info", "install"]
