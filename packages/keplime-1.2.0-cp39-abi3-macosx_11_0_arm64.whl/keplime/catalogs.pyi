# flake8: noqa
from __future__ import annotations

from typing import Optional

from .elements import OrbitPlotData, TLE

class TLECatalog:
    """A catalog mapping satellite IDs to TLE entries.

    Provides dictionary-like storage keyed by satellite identifier strings
    (NORAD catalog numbers or user-assigned labels).  Loading is supported
    from standard two-line or three-line element set files.

    Attributes:
        name (str | None): Optional human-readable catalog label.
            Set to the file path when loaded with `from_tle_file`.
        count (int): Number of TLE entries in the catalog [dimensionless; 0..].
    """

    def __init__(self, name: Optional[str] = ...) -> None:
        """Creates an empty TLECatalog.

        Args:
            name: Optional human-readable catalog label.
        """
        ...

    @staticmethod
    def from_tle_file(file_path: str) -> TLECatalog:
        """Loads a TLECatalog from a two-line or three-line element set file.

        Lines containing only whitespace are skipped.  Each entry is detected
        by its leading character: ``'1'`` starts a two-line set; any other
        character starts a three-line set (an optional ``"0 "`` name prefix is
        stripped).

        Args:
            file_path: Path to the TLE file.

        Returns:
            A populated TLECatalog whose `name` is set to ``file_path``.

        Raises:
            ValueError: If the file cannot be read, if a TLE block is
                incomplete, or if any TLE string fails to parse.
        """
        ...

    @property
    def name(self) -> Optional[str]:
        """Optional human-readable catalog label.

        Set to the file path when loaded with `from_tle_file`.
        """
        ...

    @name.setter
    def name(self, name: Optional[str]) -> None: ...

    def add(self, satellite_id: str, tle: TLE) -> None:
        """Inserts or replaces a TLE entry under the given satellite ID.

        Args:
            satellite_id: Unique key string (e.g., a NORAD number or custom
                label).
            tle: TLE entry to store.
        """
        ...

    def add_tle(self, tle: TLE) -> str:
        """Inserts or replaces a TLE entry, deriving the key from its NORAD number.

        For catalog numbers ≤ 99 999 the decimal string is used as the key.
        For Alpha-5 numbers (> 99 999) the key is a letter plus four digits
        (e.g., 100 001 → ``"A0001"``).

        Args:
            tle: TLE entry to store.

        Returns:
            The satellite ID string used as the catalog key.
        """
        ...

    def get(self, satellite_id: str) -> Optional[TLE]:
        """Retrieves a TLE entry by satellite ID.

        Args:
            satellite_id: Key string to look up.

        Returns:
            The TLE if found, or ``None``.
        """
        ...

    def get_by_norad_id(self, norad_id: int) -> Optional[TLE]:
        """Retrieves a TLE entry by its NORAD catalog number.

        Scans all entries; O(n) in catalog size.

        Args:
            norad_id: NORAD catalog number [dimensionless; 1..].

        Returns:
            The TLE if an entry with the given NORAD number is found,
            or ``None``.
        """
        ...

    def remove(self, satellite_id: str) -> Optional[TLE]:
        """Removes and returns the TLE entry for the given satellite ID.

        Args:
            satellite_id: Key string to remove.

        Returns:
            The removed TLE if the key existed, or ``None``.
        """
        ...

    def clear(self) -> None:
        """Removes all entries from the catalog."""
        ...

    @property
    def count(self) -> int:
        """Number of TLE entries in the catalog [dimensionless; 0..]."""
        ...

    def get_plot_data(self) -> OrbitPlotData:
        """Generates orbit plot data from the first catalog entry.

        Uses the earliest-keyed TLE's current Cartesian state as the initial
        orbit point.

        Returns:
            OrbitPlotData containing a single orbit point.

        Raises:
            ValueError: If the catalog is empty or if the TLE's Cartesian
                state cannot be evaluated.
        """
        ...

    def fit_best_tle(
        self,
        srp_coefficient: Optional[float] = ...,
        drag_coefficient: Optional[float] = ...,
    ) -> TLE:
        """Fits a single best-fit TLE from all catalog entries via Batch Least Squares.

        The earliest-epoch TLE in the catalog is used as the a-priori state.
        Synthetic range/range-rate observations are generated from each TLE's
        Cartesian state and fed to the BLS solver.

        Args:
            srp_coefficient: Optional solar radiation pressure coefficient to
                fix [km²/kg].  ``None`` preserves the a-priori value.
            drag_coefficient: Optional ballistic coefficient to fix [km²/kg].
                ``None`` preserves the a-priori value.

        Returns:
            The fitted TLE.

        Raises:
            ValueError: If the catalog is empty, if any TLE cannot be
                evaluated, or if the BLS solver fails to converge.
        """
        ...

    def keys(self) -> list[str]:
        """Returns all satellite ID keys in sorted order.

        Returns:
            Sorted list of satellite ID strings.
        """
        ...

    def __len__(self) -> int: ...
    def __contains__(self, satellite_id: str) -> bool: ...
    def __setitem__(self, satellite_id: str, tle: TLE) -> None: ...
    def __getitem__(self, satellite_id: str) -> TLE: ...
    def __delitem__(self, satellite_id: str) -> None: ...
