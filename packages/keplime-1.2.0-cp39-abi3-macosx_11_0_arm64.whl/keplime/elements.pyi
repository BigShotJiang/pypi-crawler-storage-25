# flake8: noqa
from __future__ import annotations

from typing import TYPE_CHECKING, Iterator, Optional, Tuple

from .enums import Classification, KeplerianType, PerformancePriority, ReferenceFrame, RelativeFrame
from .time import ModifiedJulianDate, TimeSpan

if TYPE_CHECKING:
    from .bodies import Constellation, Satellite, SensorConstraints
    from .events import FieldOfViewReport, HorizonAccessReport, SensorAccessReport

Vector3 = Tuple[float, float, float]

def mean_motion_from_semi_major_axis(sma_km: float, mu: float) -> float:
    """Converts semi-major axis to mean motion.

    Args:
        sma_km: Semi-major axis [km; > 0].
        mu: Standard gravitational parameter [km³/s²].

    Returns:
        Mean motion [rev/day].

    Raises:
        ValueError: If ``sma_km`` is not positive.
    """
    ...

def semi_major_axis_from_mean_motion(mean_motion_rev_day: float, mu: float) -> float:
    """Converts mean motion to semi-major axis.

    Args:
        mean_motion_rev_day: Mean motion [rev/day; > 0].
        mu: Standard gravitational parameter [km³/s²].

    Returns:
        Semi-major axis [km].

    Raises:
        ValueError: If ``mean_motion_rev_day`` is not positive.
    """
    ...

def kozai_to_brouwer(eccentricity: float, inclination: float, mean_motion_kozai: float) -> float:
    """Converts Kozai mean motion to Brouwer mean motion.

    Applies the J₂ SGP4 correction using WGS-72 constants.

    Args:
        eccentricity: Orbital eccentricity [dimensionless; 0..1).
        inclination: Orbital inclination [rad; 0..π].
        mean_motion_kozai: Kozai mean motion [rev/day].

    Returns:
        Brouwer mean motion [rev/day].
    """
    ...

def brouwer_to_kozai(eccentricity: float, inclination: float, mean_motion_brouwer: float) -> float:
    """Converts Brouwer mean motion to Kozai mean motion.

    Inverts `kozai_to_brouwer` iteratively using Newton–Raphson.

    Args:
        eccentricity: Orbital eccentricity [dimensionless; 0..1).
        inclination: Orbital inclination [rad; 0..π].
        mean_motion_brouwer: Brouwer mean motion [rev/day].

    Returns:
        Kozai mean motion [rev/day].
    """
    ...

class CartesianVector:
    """A three-component Cartesian vector.

    Components may represent position [km], velocity [km/s], or a
    dimensionless direction depending on context.

    Attributes:
        x (float): X component [km, km/s, or dimensionless].
        y (float): Y component [same units as x].
        z (float): Z component [same units as x].
        magnitude (float): Euclidean norm [same units as components].
    """

    def __init__(self, x: float, y: float, z: float) -> None:
        """Creates a CartesianVector from explicit component values.

        Args:
            x: X component [km, km/s, or dimensionless depending on context].
            y: Y component [same units as x].
            z: Z component [same units as x].
        """
        ...

    @property
    def x(self) -> float:
        """X component [km, km/s, or dimensionless depending on context]."""
        ...

    @property
    def y(self) -> float:
        """Y component [same units as x]."""
        ...

    @property
    def z(self) -> float:
        """Z component [same units as x]."""
        ...

    @property
    def magnitude(self) -> float:
        """Euclidean norm of the vector [same units as components]."""
        ...

    def get_angle(self, other: CartesianVector) -> float:
        """Returns the angle between this vector and another.

        Uses ``arccos(a · b / (‖a‖ ‖b‖))``. Undefined for zero-magnitude vectors.

        Args:
            other: The other vector.

        Returns:
            Angle between the two vectors [rad; 0..π].
        """
        ...

    def distance(self, other: CartesianVector) -> float:
        """Returns the Euclidean distance between this vector and another.

        Args:
            other: The other vector [same units].

        Returns:
            Distance [same units as components].
        """
        ...

    def as_tuple(self) -> Vector3:
        """Returns the components as an ``(x, y, z)`` tuple.

        Returns:
            ``(x, y, z)`` [same units as components].
        """
        ...

    def in_earth_shadow(self, sun_position: CartesianVector) -> bool:
        """Returns whether this position lies inside Earth's cylindrical shadow.

        ``self`` is treated as a body position relative to Earth's center,
        and ``sun_position`` as the Sun position in the same frame and
        units [km]. Cylindrical model only — no penumbra, no flattening.

        Args:
            sun_position: Sun position in the same frame as ``self`` [km].

        Returns:
            ``True`` if the body is inside Earth's cylindrical shadow,
            ``False`` otherwise. ``False`` when ``sun_position`` is the
            zero vector or non-finite.
        """
        ...

    def __add__(self, other: CartesianVector) -> CartesianVector: ...
    def __sub__(self, other: CartesianVector) -> CartesianVector: ...
    def __neg__(self) -> CartesianVector: ...
    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> float: ...
    def __iter__(self) -> Iterator[float]: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class CartesianState:
    """Cartesian state vector (position and optional velocity) at an epoch.

    All vector components are expressed in the associated reference frame.

    Attributes:
        epoch (ModifiedJulianDate): Epoch of the state.
        reference_frame (ReferenceFrame): Frame of the position and velocity.
        position (CartesianVector): Position [km].
        velocity (Optional[CartesianVector]): Velocity [km/s], or ``None``.
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        reference_frame: ReferenceFrame,
        position: CartesianVector,
        velocity: Optional[CartesianVector],
    ) -> None:
        """Creates a CartesianState.

        Args:
            epoch: Epoch of the state.
            reference_frame: Frame for position and velocity.
            position: Position vector [km].
            velocity: Velocity vector [km/s], or ``None``.
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch of the state."""
        ...

    @property
    def reference_frame(self) -> ReferenceFrame:
        """Reference frame of position and velocity."""
        ...

    @property
    def position(self) -> CartesianVector:
        """Position vector [km]."""
        ...

    @property
    def velocity(self) -> Optional[CartesianVector]:
        """Velocity vector [km/s], or ``None`` for position-only states."""
        ...

    def to_reference_frame(
        self, target: ReferenceFrame, priority: PerformancePriority
    ) -> CartesianState:
        """Converts this state to a different reference frame.

        Args:
            target: Destination reference frame.
            priority: Trade-off between speed and numerical precision.

        Returns:
            New state in ``target`` [position in km, velocity in km/s].

        Raises:
            ValueError: If the frame transformation is not supported.
        """
        ...

    def relative_to(self, origin_state: CartesianState, frame: RelativeFrame) -> CartesianState:
        """Computes this state relative to ``origin_state``.

        Both states must share the same epoch and reference frame.

        Args:
            origin_state: Origin (chief / reference) state.
            frame: Inertial or RIC (Radial–In-track–Cross-track) output frame.

        Returns:
            Relative state [position in km, velocity in km/s].

        Raises:
            ValueError: If epochs differ, frames differ, or either state lacks velocity.
        """
        ...

    def to_cartesian_vector(self) -> CartesianVector:
        """Returns the position as a CartesianVector.

        Returns:
            Position vector [km].
        """
        ...

    def to_keplerian(self, mu: float) -> KeplerianElements:
        """Converts this Cartesian state to classical Keplerian elements.

        Applies the standard rv2coe (r-v to classical elements) algorithm.
        Only elliptic orbits are supported.

        Args:
            mu: Gravitational parameter of the central body [km³/s²].
                Use 398600.4418 for WGS84 Earth, or 398600.8 for WGS72.

        Returns:
            KeplerianElements with semi_major_axis [km], eccentricity,
            inclination [rad], ascending_node [rad],
            argument_of_periapsis [rad], and mean_anomaly [rad].

        Raises:
            ValueError: If this state has no velocity, position is at the
                origin, angular momentum is zero, or the orbit is
                non-elliptic (energy ≥ 0).
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class Ephemeris:
    """A time-ordered collection of Cartesian states for a single object.

    Attributes:
        satellite_id (str): Identifier of the satellite.
        norad_id (int): NORAD catalog number (0 if not set).
        number_of_states (int): Number of states stored.
    """

    def __init__(
        self,
        satellite_id: str,
        state: CartesianState,
        norad_id: Optional[int] = ...,
    ) -> None:
        """Creates an Ephemeris with a single initial state.

        Args:
            satellite_id: Identifier of the satellite.
            state: Initial Cartesian state.
            norad_id: NORAD catalog number (optional).
        """
        ...

    @property
    def satellite_id(self) -> str:
        """Identifier of the satellite."""
        ...

    @property
    def norad_id(self) -> int:
        """NORAD catalog number (0 if not set)."""
        ...

    @property
    def number_of_states(self) -> int:
        """Number of states stored in this ephemeris."""
        ...

    def add_state(self, state: CartesianState) -> None:
        """Appends a state to the ephemeris.

        Args:
            state: Cartesian state to append.
        """
        ...

    def get_state_at_epoch(self, epoch: ModifiedJulianDate) -> Optional[CartesianState]:
        """Interpolates the state at the given epoch.

        Args:
            epoch: Desired epoch.

        Returns:
            Interpolated state [position in km, velocity in km/s], or ``None``
            if ``epoch`` is outside the covered range.
        """
        ...

    def get_epoch_range(self) -> Optional[tuple[ModifiedJulianDate, ModifiedJulianDate]]:
        """Returns the epoch range covered by this ephemeris.

        Returns:
            ``(start, end)`` pair, or ``None`` if the ephemeris is empty.
        """
        ...

    def covers_range(self, start: ModifiedJulianDate, end: ModifiedJulianDate) -> bool:
        """Returns whether the ephemeris fully covers ``[start, end]``.

        Args:
            start: Start of the desired range.
            end: End of the desired range.

        Returns:
            ``True`` if both endpoints lie within the coverage.
        """
        ...

    def covers_epoch(self, epoch: ModifiedJulianDate) -> bool:
        """Returns whether ``epoch`` falls within the ephemeris coverage.

        Args:
            epoch: Epoch to test.

        Returns:
            ``True`` if ``epoch`` is within the covered range.
        """
        ...

    def get_inertial_sensor_access(
        self,
        bore: TopocentricElements,
        target: Ephemeris,
        constraints: SensorConstraints,
    ) -> SensorAccessReport:
        """Reports access windows from this ephemeris (the sensor host) to a
        target ephemeris using a constant inertial boresight (RA/Dec).

        Args:
            bore: Boresight as `TopocentricElements`; both
                ``right_ascension`` and ``declination`` must be set.
            target: Body whose access is being reported.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport] over the
            intersection of observer/target coverage.

        Raises:
            ValueError: If ``bore`` lacks RA or Dec, or either ephemeris has
                no epoch range.
        """
        ...

    def get_horizon_sensor_access(
        self,
        bore: HorizonElements,
        target: Ephemeris,
        constraints: SensorConstraints,
    ) -> SensorAccessReport:
        """Reports access windows from this ephemeris (the sensor host) to a
        target ephemeris using a boresight fixed in the host's local
        horizon frame (Az/El).

        Args:
            bore: Boresight as `HorizonElements`.
            target: Body whose access is being reported.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport] over the
            intersection of observer/target coverage.

        Raises:
            ValueError: If either ephemeris has no epoch range.
        """
        ...

    def get_target_sensor_access(
        self,
        primary_target: Ephemeris,
        secondary_target: Ephemeris,
        constraints: SensorConstraints,
    ) -> SensorAccessReport:
        """Reports access windows from this ephemeris (the sensor host) to
        ``secondary_target`` while the host points at ``primary_target``.

        Args:
            primary_target: Body the boresight tracks.
            secondary_target: Body whose access is being reported.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport] over the
            intersection of observer/``secondary_target`` coverage.

        Raises:
            ValueError: If observer or ``secondary_target`` has no epoch
                range.
        """
        ...

class SphericalVector:
    """Spherical coordinates: range, right ascension, and declination.

    Attributes:
        range (float): Radial distance [km].
        right_ascension (float): Right ascension [rad; -π..π].
        declination (float): Declination [rad; -π/2..π/2].
    """

    def __init__(self, range: float, right_ascension: float, declination: float) -> None:
        """Creates a SphericalVector from explicit components.

        Args:
            range: Radial distance [km].
            right_ascension: Right ascension [rad; -π..π].
            declination: Declination [rad; -π/2..π/2].
        """
        ...

    @staticmethod
    def from_cartesian(vector: CartesianVector) -> SphericalVector:
        """Converts a CartesianVector to spherical coordinates.

        Args:
            vector: Input Cartesian vector [km].

        Returns:
            Equivalent `SphericalVector`.
        """
        ...

    def to_cartesian(self) -> CartesianVector:
        """Converts this SphericalVector to a CartesianVector.

        Returns:
            Equivalent Cartesian vector [km].
        """
        ...

    @property
    def range(self) -> float:
        """Radial distance [km]."""
        ...

    @property
    def right_ascension(self) -> float:
        """Right ascension [rad; -π..π]."""
        ...

    @property
    def declination(self) -> float:
        """Declination [rad; -π/2..π/2]."""
        ...

    def __repr__(self) -> str: ...

class GeodeticPosition:
    """Geodetic coordinates on the WGS-84 ellipsoid.

    Latitude and longitude are geodetic (not geocentric). Altitude is measured
    above the WGS-84 reference ellipsoid, not mean sea level.

    Attributes:
        latitude (float): Geodetic latitude [rad; -π/2..π/2].
        longitude (float): Geodetic longitude [rad; -π..π].
        altitude (float): Altitude above WGS-84 ellipsoid [km].
        id (str): Unique identifier (UUID by default; settable).
        name (str | None): Optional human-readable name.
    """

    def __init__(self, latitude: float, longitude: float, altitude: float) -> None:
        """Creates a GeodeticPosition on the WGS-84 ellipsoid.

        Args:
            latitude: Geodetic latitude [rad; -π/2..π/2].
            longitude: Geodetic longitude [rad; -π..π].
            altitude: Altitude above WGS-84 ellipsoid [km].
        """
        ...

    @staticmethod
    def from_cartesian_state(state: CartesianState) -> GeodeticPosition:
        """Converts an ITRF Cartesian state to geodetic coordinates.

        Uses an iterative Bowring method for WGS-84 inversion. The input
        state is converted to ITRF automatically if needed.

        Args:
            state: Cartesian state (any supported frame) [position in km].

        Returns:
            Geodetic position on the WGS-84 ellipsoid.

        Raises:
            ValueError: If the frame conversion to ITRF fails.
        """
        ...

    @property
    def latitude(self) -> float:
        """Geodetic latitude [rad; -π/2..π/2]."""
        ...

    @property
    def longitude(self) -> float:
        """Geodetic longitude [rad; -π..π]."""
        ...

    @property
    def altitude(self) -> float:
        """Altitude above WGS-84 ellipsoid [km]."""
        ...

    id: str
    name: str | None

    def get_state_at_epoch(
        self, epoch: ModifiedJulianDate, reference_frame: ReferenceFrame | None = ...
    ) -> CartesianState:
        """Returns the observer's inertial state at a given epoch.

        The observer has zero velocity in ITRF, converted to ``reference_frame``
        if provided.

        Args:
            epoch: Desired epoch.
            reference_frame: Output frame (default: ITRF).

        Returns:
            Cartesian state [position in km, zero velocity in km/s].

        Raises:
            ValueError: If the frame conversion fails.
        """
        ...

    def get_theta(self, epoch: ModifiedJulianDate) -> float:
        """Returns the local sidereal angle at the observer's longitude.

        Computed as GMST plus the observer's east longitude. Requires EOP data.

        Args:
            epoch: Desired epoch.

        Returns:
            Local sidereal angle [rad; 0..2π).
        """
        ...

    def get_topocentric_to_satellite(
        self,
        epoch: ModifiedJulianDate,
        sat: "Satellite",
        reference_frame: ReferenceFrame,
    ) -> TopocentricElements:
        """Computes the topocentric direction from this observer to a satellite.

        Includes range and range-rate when both states carry velocity.

        Args:
            epoch: Observation epoch.
            sat: Target satellite.
            reference_frame: Reference frame for the computation.

        Returns:
            Topocentric elements [range in km, range-rate in km/s,
            right_ascension and declination in rad].

        Raises:
            ValueError: If propagation or frame conversion fails.
        """
        ...

    def get_horizon_access_report(
        self,
        satellite: "Satellite",
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        min_elevation: float,
        min_duration: TimeSpan,
    ) -> "HorizonAccessReport":
        """Finds satellite access intervals above a minimum elevation.

        Steps at 60-second resolution and bisects each crossing for accuracy.

        Args:
            satellite: Target satellite.
            start: Start of the search window.
            end: End of the search window.
            min_elevation: Minimum elevation threshold [rad].
            min_duration: Minimum pass duration to include.

        Returns:
            `HorizonAccessReport` with qualifying passes.

        Raises:
            ValueError: If ``start > end`` or propagation fails.
        """
        ...

    def get_field_of_view_report(
        self,
        epoch: ModifiedJulianDate,
        sensor_direction: TopocentricElements,
        angular_threshold: float,
        sats: "Constellation",
        reference_frame: ReferenceFrame,
    ) -> "FieldOfViewReport":
        """Reports satellites within a sensor's angular field of view.

        A satellite is included when its angular separation from
        ``sensor_direction`` does not exceed ``angular_threshold``.

        Args:
            epoch: Observation epoch.
            sensor_direction: Boresight as topocentric elements (ra and dec required).
            angular_threshold: Half-angle of the field of view [rad].
            sats: Constellation to search.
            reference_frame: Reference frame for the computation.

        Returns:
            `FieldOfViewReport` with matching satellites.

        Raises:
            ValueError: If propagation fails or ``sensor_direction`` lacks angles.
        """
        ...

    def __repr__(self) -> str: ...

class BoreToBodyAngles:
    """Angular separations from a boresight direction to Earth, Sun, and Moon.

    Attributes:
        earth_angle (float): Angle from boresight to Earth center [rad; 0..π].
        sun_angle (float): Angle from boresight to Sun center [rad; 0..π].
        moon_angle (float): Angle from boresight to Moon center [rad; 0..π].
    """

    def __init__(self, earth_angle: float, sun_angle: float, moon_angle: float) -> None:
        """Creates BoreToBodyAngles from explicit angle values.

        Args:
            earth_angle: Angle from boresight to Earth center [rad; 0..π].
            sun_angle: Angle from boresight to Sun center [rad; 0..π].
            moon_angle: Angle from boresight to Moon center [rad; 0..π].
        """
        ...

    @property
    def earth_angle(self) -> float:
        """Angle from boresight to Earth center [rad; 0..π]."""
        ...

    @property
    def sun_angle(self) -> float:
        """Angle from boresight to Sun center [rad; 0..π]."""
        ...

    @property
    def moon_angle(self) -> float:
        """Angle from boresight to Moon center [rad; 0..π]."""
        ...

    def __repr__(self) -> str: ...

class TopocentricElements:
    """Angular and range observation in a topocentric (observer-centered) frame.

    All fields are optional to support partial observations (angles-only,
    range-only, or full six-component measurements).

    Attributes:
        range (Optional[float]): Slant range from observer to target [km].
        range_rate (Optional[float]): Range-rate [km/s].
        right_ascension (Optional[float]): Right ascension [rad; -π..π].
        declination (Optional[float]): Declination [rad; -π/2..π/2].
        right_ascension_rate (Optional[float]): Right ascension rate [rad/s].
        declination_rate (Optional[float]): Declination rate [rad/s].
        observed_direction (Optional[CartesianVector]): Unit direction vector
            from right ascension and declination; ``None`` if either angle is absent.
    """

    def __init__(self, right_ascension: Optional[float], declination: Optional[float]) -> None:
        """Creates TopocentricElements with angular components only.

        Use builder methods to attach optional range and rate fields.

        Args:
            right_ascension: Right ascension [rad; -π..π], or ``None``.
            declination: Declination [rad; -π/2..π/2], or ``None``.
        """
        ...

    def with_range(self, range: Optional[float]) -> TopocentricElements:
        """Returns a copy with the range field set.

        Args:
            range: Slant range [km], or ``None``.

        Returns:
            Updated `TopocentricElements`.
        """
        ...

    def with_range_rate(self, range_rate: Optional[float]) -> TopocentricElements:
        """Returns a copy with the range-rate field set.

        Args:
            range_rate: Range-rate [km/s], or ``None``.

        Returns:
            Updated `TopocentricElements`.
        """
        ...

    def with_right_ascension_rate(
        self, right_ascension_rate: Optional[float]
    ) -> TopocentricElements:
        """Returns a copy with the right-ascension-rate field set.

        Args:
            right_ascension_rate: Right ascension rate [rad/s], or ``None``.

        Returns:
            Updated `TopocentricElements`.
        """
        ...

    def with_declination_rate(
        self, declination_rate: Optional[float]
    ) -> TopocentricElements:
        """Returns a copy with the declination-rate field set.

        Args:
            declination_rate: Declination rate [rad/s], or ``None``.

        Returns:
            Updated `TopocentricElements`.
        """
        ...

    @property
    def range(self) -> Optional[float]:
        """Slant range from observer to target [km], or ``None``."""
        ...

    @property
    def range_rate(self) -> Optional[float]:
        """Range-rate [km/s], or ``None``."""
        ...

    @property
    def right_ascension(self) -> Optional[float]:
        """Right ascension [rad; -π..π], or ``None``."""
        ...

    @property
    def declination(self) -> Optional[float]:
        """Declination [rad; -π/2..π/2], or ``None``."""
        ...

    @property
    def right_ascension_rate(self) -> Optional[float]:
        """Right ascension rate [rad/s], or ``None``."""
        ...

    @property
    def declination_rate(self) -> Optional[float]:
        """Declination rate [rad/s], or ``None``."""
        ...

    @property
    def observed_direction(self) -> Optional[CartesianVector]:
        """Unit direction vector from right ascension and declination.

        Returns ``None`` when either angle is absent.
        """
        ...

    def __repr__(self) -> str: ...

class TopocentricState:
    """A topocentric observation at an epoch with an associated observer state.

    Attributes:
        epoch (ModifiedJulianDate): Observation epoch.
        elements (TopocentricElements): Angular and range measurements.
        reference_frame (ReferenceFrame): Frame in which angles are expressed.
        origin_state (CartesianState): Observer Cartesian state at the epoch.
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        elements: TopocentricElements,
        reference_frame: ReferenceFrame,
        origin_state: CartesianState,
    ) -> None:
        """Creates a TopocentricState.

        The ``origin_state`` epoch must match ``epoch``; it will be
        automatically converted to ``reference_frame``.

        Args:
            epoch: Observation epoch.
            elements: Angular and range measurements.
            reference_frame: Frame for the angular elements.
            origin_state: Observer Cartesian state.
        """
        ...

    @staticmethod
    def from_horizon_state(state: HorizonState, reference_frame: ReferenceFrame) -> TopocentricState:
        """Converts a HorizonState to a TopocentricState.

        Transforms azimuth/elevation to right ascension/declination.

        Args:
            state: Source horizon state.
            reference_frame: Frame for the output angles.

        Returns:
            Equivalent `TopocentricState` in ``reference_frame``.

        Raises:
            ValueError: If frame conversion fails.
        """
        ...

    def to_frame(self, reference_frame: ReferenceFrame) -> TopocentricState:
        """Converts this state to a different reference frame.

        Args:
            reference_frame: Target reference frame.

        Returns:
            Equivalent `TopocentricState` in ``reference_frame``.

        Raises:
            ValueError: If the frame conversion is not supported.
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Observation epoch."""
        ...

    @property
    def elements(self) -> TopocentricElements:
        """Angular and range measurements."""
        ...

    @property
    def reference_frame(self) -> ReferenceFrame:
        """Reference frame in which angles are expressed."""
        ...

    @property
    def origin_state(self) -> CartesianState:
        """Observer Cartesian state at the epoch."""
        ...

    def get_sensor_access_report(
        self,
        candidates: list[Ephemeris],
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
        tracking_ephemeris: Optional[Ephemeris] = ...,
    ) -> SensorAccessReport:
        """Reports access windows from this observation to candidates.

        The observer is treated as Earth-fixed (``origin_state`` is
        converted to ITRF and re-sampled into a TEME ephemeris over the
        search range). When ``tracking_ephemeris`` is ``None``, the
        stored RA/Dec drives the inertial boresight; when ``Some``, the
        stored RA/Dec is bypassed and the bore at each epoch is
        ``tracking_ephemeris_pos − observer_pos``.

        Args:
            candidates: Target ephemerides to evaluate against the bore.
            start: Start of the search range.
            end: End of the search range.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.
            tracking_ephemeris: Optional bore-pointing override; when
                provided, the stored RA/Dec is ignored.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport] aggregating
            all candidate access windows.

        Raises:
            ValueError: If ``start > end``, the observer cannot be lifted,
                the stored elements lack RA or Dec (and no override is
                supplied), or an inner gate evaluation fails.
        """
        ...

    def get_sensor_access_to_satellite(
        self,
        satellite: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
        tracking_ephemeris: Optional[Ephemeris] = ...,
    ) -> SensorAccessReport:
        """Convenience: reports access windows to ``satellite``'s cached
        ephemeris over ``[start, end]``.

        Args:
            satellite: Target [`Satellite`][keplime.bodies.Satellite]. Must
                have a cached ephemeris.
            start: Start of the search range.
            end: End of the search range.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.
            tracking_ephemeris: Optional bore-pointing override; when
                provided, the stored RA/Dec is ignored and the bore at
                each epoch is ``tracking_ephemeris_pos − observer_pos``.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport].

        Raises:
            ValueError: If the satellite has no cached ephemeris or an
                inner gate evaluation fails.
        """
        ...

    def get_sensor_access_to_constellation(
        self,
        constellation: Constellation,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
        tracking_ephemeris: Optional[Ephemeris] = ...,
    ) -> SensorAccessReport:
        """Convenience: reports access windows to every cached ephemeris
        in ``constellation`` over ``[start, end]``.

        Satellites are iterated in sorted-id order for deterministic
        output ordering.

        Args:
            constellation: Target [`Constellation`][keplime.bodies.Constellation].
                Every satellite must have a cached ephemeris.
            start: Start of the search range.
            end: End of the search range.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.
            tracking_ephemeris: Optional bore-pointing override; when
                provided, the stored RA/Dec is ignored and the bore at
                each epoch is ``tracking_ephemeris_pos − observer_pos``.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport].

        Raises:
            ValueError: If any satellite lacks a cached ephemeris or an
                inner gate evaluation fails.

        Logging:
            Emits ``info``-level entry/exit records on the ``keplime``
            logger with the constellation size, time window, and elapsed
            wall time; ``debug`` records per target with the target id,
            elapsed time, and access count; and ``warn`` records when
            ephemerides are missing or a per-target evaluation panics
            (panicking targets are returned as empty reports so the
            batch continues). See ``keplime.__doc__`` for how to surface
            these logs in the hosting application.
        """
        ...

    def __repr__(self) -> str: ...

class HorizonElements:
    """Local-horizon angular observation: azimuth and elevation.

    Azimuth is measured clockwise from north. Elevation is positive above
    the horizon. Rate fields are optional and may be ``None`` near singularities
    (zenith for azimuth rate, nadir for elevation rate).

    Attributes:
        azimuth (float): Azimuth angle [rad; 0..2π, clockwise from north].
        elevation (float): Elevation angle [rad; -π/2..π/2].
        range (Optional[float]): Slant range [km].
        range_rate (Optional[float]): Range-rate [km/s].
        azimuth_rate (Optional[float]): Azimuth rate [rad/s]; ``None`` near zenith.
        elevation_rate (Optional[float]): Elevation rate [rad/s].
    """

    def __init__(self, azimuth: float, elevation: float) -> None:
        """Creates HorizonElements with azimuth and elevation only.

        Args:
            azimuth: Azimuth angle [rad; 0..2π, clockwise from north].
            elevation: Elevation angle [rad; -π/2..π/2].
        """
        ...

    @property
    def range(self) -> Optional[float]:
        """Slant range [km], or ``None``."""
        ...

    @property
    def range_rate(self) -> Optional[float]:
        """Range-rate [km/s], or ``None``."""
        ...

    @property
    def azimuth(self) -> float:
        """Azimuth angle [rad; 0..2π, clockwise from north]."""
        ...

    @property
    def elevation(self) -> float:
        """Elevation angle [rad; -π/2..π/2]."""
        ...

    @property
    def azimuth_rate(self) -> Optional[float]:
        """Azimuth rate [rad/s], or ``None`` near zenith."""
        ...

    @property
    def elevation_rate(self) -> Optional[float]:
        """Elevation rate [rad/s], or ``None``."""
        ...

    def __repr__(self) -> str: ...

class HorizonState:
    """A horizon observation (azimuth/elevation) at an epoch.

    The observer position is normalised to ITRF on construction.

    Attributes:
        epoch (ModifiedJulianDate): Observation epoch.
        elements (HorizonElements): Azimuth, elevation, and optional rates.
        origin_state (CartesianState): Observer state in ITRF.
    """

    def __init__(
        self, epoch: ModifiedJulianDate, elements: HorizonElements, origin_state: CartesianState
    ) -> None:
        """Creates a HorizonState.

        The ``origin_state`` epoch must match ``epoch``; it will be
        automatically converted to ITRF.

        Args:
            epoch: Observation epoch.
            elements: Azimuth, elevation, and optional rates.
            origin_state: Observer Cartesian state (any supported frame).
        """
        ...

    @staticmethod
    def from_topocentric_state(state: TopocentricState) -> HorizonState:
        """Converts a TopocentricState to a HorizonState.

        Transforms right ascension/declination to azimuth/elevation using
        the observer's geodetic latitude and longitude.

        Args:
            state: Source topocentric state.

        Returns:
            Equivalent `HorizonState`.
        """
        ...

    @staticmethod
    def from_cartesian(
        observer_state: CartesianState, target_state: CartesianState
    ) -> HorizonState:
        """Computes the horizon observation from observer to target.

        Both states are converted to ITRF. Rates are computed when both
        states carry velocity; ``None`` is set near zenith.

        Args:
            observer_state: Observer Cartesian state (any supported frame).
            target_state: Target Cartesian state.

        Returns:
            `HorizonState` at the observer's position.

        Raises:
            ValueError: If epochs differ, positions coincide, or frame
                conversion fails.
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Observation epoch."""
        ...

    @property
    def elements(self) -> HorizonElements:
        """Azimuth, elevation, and optional rates."""
        ...

    @property
    def origin_state(self) -> CartesianState:
        """Observer state in ITRF."""
        ...

    def get_sensor_access_report(
        self,
        candidates: list[Ephemeris],
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
        tracking_ephemeris: Optional[Ephemeris] = ...,
    ) -> SensorAccessReport:
        """Reports access windows from this observation to candidates.

        The observer is already in ITRF; its TEME position is re-sampled
        over the search range. When ``tracking_ephemeris`` is ``None``,
        the stored Az/El drives the boresight; when ``Some``, the stored
        Az/El is bypassed and the bore at each epoch is
        ``tracking_ephemeris_pos − observer_pos``.

        Args:
            candidates: Target ephemerides to evaluate against the bore.
            start: Start of the search range.
            end: End of the search range.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.
            tracking_ephemeris: Optional bore-pointing override; when
                provided, the stored Az/El is ignored.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport] aggregating
            all candidate access windows.

        Raises:
            ValueError: If ``start > end``, the observer cannot be lifted,
                or an inner gate evaluation fails.
        """
        ...

    def get_sensor_access_to_satellite(
        self,
        satellite: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
        tracking_ephemeris: Optional[Ephemeris] = ...,
    ) -> SensorAccessReport:
        """Convenience: reports access windows to ``satellite``'s cached
        ephemeris over ``[start, end]``.

        Args:
            satellite: Target [`Satellite`][keplime.bodies.Satellite]. Must
                have a cached ephemeris.
            start: Start of the search range.
            end: End of the search range.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.
            tracking_ephemeris: Optional bore-pointing override; when
                provided, the stored Az/El is ignored and the bore at
                each epoch is ``tracking_ephemeris_pos − observer_pos``.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport].

        Raises:
            ValueError: If the satellite has no cached ephemeris or an
                inner gate evaluation fails.
        """
        ...

    def get_sensor_access_to_constellation(
        self,
        constellation: Constellation,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
        tracking_ephemeris: Optional[Ephemeris] = ...,
    ) -> SensorAccessReport:
        """Convenience: reports access windows to every cached ephemeris
        in ``constellation`` over ``[start, end]``.

        Satellites are iterated in sorted-id order for deterministic
        output ordering.

        Args:
            constellation: Target [`Constellation`][keplime.bodies.Constellation].
                Every satellite must have a cached ephemeris.
            start: Start of the search range.
            end: End of the search range.
            constraints: [`SensorConstraints`][keplime.bodies.SensorConstraints] to apply.
            tracking_ephemeris: Optional bore-pointing override; when
                provided, the stored Az/El is ignored and the bore at
                each epoch is ``tracking_ephemeris_pos − observer_pos``.

        Returns:
            A [`SensorAccessReport`][keplime.events.SensorAccessReport].

        Raises:
            ValueError: If any satellite lacks a cached ephemeris or an
                inner gate evaluation fails.

        Logging:
            Emits ``info``-level entry/exit records on the ``keplime``
            logger with the constellation size, time window, and elapsed
            wall time; ``debug`` records per target with the target id,
            elapsed time, and access count; and ``warn`` records when
            ephemerides are missing or a per-target evaluation panics
            (panicking targets are returned as empty reports so the
            batch continues). See ``keplime.__doc__`` for how to surface
            these logs in the hosting application.
        """
        ...

    def __repr__(self) -> str: ...

class KeplerianElements:
    """Classical Keplerian orbital elements for an elliptic orbit.

    Attributes:
        semi_major_axis (float): Semi-major axis [km; > 0].
        eccentricity (float): Eccentricity [dimensionless; 0..1).
        inclination (float): Inclination [rad; 0..π].
        ascending_node (float): Right ascension of the ascending node [rad; 0..2π).
        argument_of_periapsis (float): Argument of periapsis [rad; 0..2π).
        mean_anomaly (float): Mean anomaly [rad; 0..2π).
    """

    @property
    def semi_major_axis(self) -> float:
        """Semi-major axis [km; > 0]."""
        ...

    @property
    def eccentricity(self) -> float:
        """Eccentricity [dimensionless; 0..1)."""
        ...

    @property
    def inclination(self) -> float:
        """Inclination [rad; 0..π]."""
        ...

    @property
    def ascending_node(self) -> float:
        """Right ascension of the ascending node [rad; 0..2π)."""
        ...

    @property
    def argument_of_periapsis(self) -> float:
        """Argument of periapsis [rad; 0..2π)."""
        ...

    @property
    def mean_anomaly(self) -> float:
        """Mean anomaly [rad; 0..2π)."""
        ...

class KeplerianState:
    """Keplerian orbital state at an epoch.

    Attributes:
        epoch (ModifiedJulianDate): Epoch of the state.
        keplerian_elements (KeplerianElements): Classical orbital elements.
        keplerian_type (KeplerianType): Mean-motion theory classification.
        mean_motion (float): Mean motion derived from the semi-major axis [rev/day].
    """

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch of the state."""
        ...

    @property
    def keplerian_elements(self) -> KeplerianElements:
        """Classical orbital elements."""
        ...

    @property
    def keplerian_type(self) -> KeplerianType:
        """Mean-motion theory (Kozai, Brouwer, or osculating)."""
        ...

    @property
    def mean_motion(self) -> float:
        """Mean motion derived from the semi-major axis [rev/day]."""
        ...

    def to_cartesian(self) -> CartesianState:
        """Converts this state to an inertial Cartesian state.

        Returns:
            Cartesian state [position in km, velocity in km/s].

        Raises:
            ValueError: If the conversion fails.
        """
        ...

class OrbitPlotState:
    """A snapshot of geodetic and orbital parameters for orbit visualization.

    Attributes:
        epoch (ModifiedJulianDate): Epoch of the snapshot.
        latitude (float): Geodetic latitude [rad; -π/2..π/2].
        longitude (float): Geodetic longitude [rad; -π..π].
        altitude (float): Altitude above WGS-84 ellipsoid [km].
        semi_major_axis (float): Semi-major axis [km].
        eccentricity (float): Eccentricity [dimensionless; 0..1).
        inclination (float): Inclination [rad; 0..π].
        ascending_node (float): Right ascension of ascending node [rad; 0..2π).
        radius (float): Orbital radius at this epoch [km].
        apogee_radius (float): Apogee radius [km].
        perigee_radius (float): Perigee radius [km].
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        geodetic: tuple[float, float, float],
        orbital: tuple[float, float, float, float],
        radii: tuple[float, float, float],
    ) -> None:
        """Creates an OrbitPlotState.

        Args:
            epoch: Epoch of the snapshot.
            geodetic: ``(latitude [rad], longitude [rad], altitude [km])``.
            orbital: ``(semi_major_axis [km], eccentricity, inclination [rad],
                ascending_node [rad])``.
            radii: ``(radius [km], apogee_radius [km], perigee_radius [km])``.
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch of the snapshot."""
        ...

    @property
    def latitude(self) -> float:
        """Geodetic latitude [rad; -π/2..π/2]."""
        ...

    @property
    def longitude(self) -> float:
        """Geodetic longitude [rad; -π..π]."""
        ...

    @property
    def altitude(self) -> float:
        """Altitude above WGS-84 ellipsoid [km]."""
        ...

    @property
    def semi_major_axis(self) -> float:
        """Semi-major axis [km]."""
        ...

    @property
    def eccentricity(self) -> float:
        """Eccentricity [dimensionless; 0..1)."""
        ...

    @property
    def inclination(self) -> float:
        """Inclination [rad; 0..π]."""
        ...

    @property
    def ascending_node(self) -> float:
        """Right ascension of ascending node [rad; 0..2π)."""
        ...

    @property
    def radius(self) -> float:
        """Orbital radius at this epoch [km]."""
        ...

    @property
    def apogee_radius(self) -> float:
        """Apogee radius [km]."""
        ...

    @property
    def perigee_radius(self) -> float:
        """Perigee radius [km]."""
        ...

class OrbitPlotData:
    """An ordered collection of OrbitPlotState snapshots for a satellite.

    Attributes:
        satellite_id (str): Identifier of the satellite.
        epochs (list[str]): ISO 8601 epoch strings.
        latitudes (list[float]): Geodetic latitudes [rad].
        longitudes (list[float]): Geodetic longitudes [rad].
        altitudes (list[float]): Altitudes above WGS-84 ellipsoid [km].
        semi_major_axes (list[float]): Semi-major axes [km].
        eccentricities (list[float]): Eccentricities [dimensionless].
        inclinations (list[float]): Inclinations [rad].
        ascending_nodes (list[float]): Right ascensions of ascending node [rad].
        radii (list[float]): Orbital radii [km].
        apogee_radii (list[float]): Apogee radii [km].
        perigee_radii (list[float]): Perigee radii [km].
    """

    def __init__(self, satellite_id: str) -> None:
        """Creates an empty OrbitPlotData for the given satellite.

        Args:
            satellite_id: Identifier of the satellite.
        """
        ...

    def add_state(self, plot_state: OrbitPlotState) -> None:
        """Appends an OrbitPlotState to this collection.

        Args:
            plot_state: Snapshot to append.
        """
        ...

    @property
    def satellite_id(self) -> str:
        """Identifier of the satellite."""
        ...

    @property
    def epochs(self) -> list[str]:
        """ISO 8601 epoch strings for each snapshot."""
        ...

    @property
    def latitudes(self) -> list[float]:
        """Geodetic latitudes [rad; -π/2..π/2]."""
        ...

    @property
    def longitudes(self) -> list[float]:
        """Geodetic longitudes [rad; -π..π]."""
        ...

    @property
    def altitudes(self) -> list[float]:
        """Altitudes above WGS-84 ellipsoid [km]."""
        ...

    @property
    def semi_major_axes(self) -> list[float]:
        """Semi-major axes [km]."""
        ...

    @property
    def eccentricities(self) -> list[float]:
        """Eccentricities [dimensionless; 0..1)."""
        ...

    @property
    def inclinations(self) -> list[float]:
        """Inclinations [rad; 0..π]."""
        ...

    @property
    def ascending_nodes(self) -> list[float]:
        """Right ascensions of ascending node [rad; 0..2π)."""
        ...

    @property
    def radii(self) -> list[float]:
        """Orbital radii at each epoch [km]."""
        ...

    @property
    def apogee_radii(self) -> list[float]:
        """Apogee radii [km]."""
        ...

    @property
    def perigee_radii(self) -> list[float]:
        """Perigee radii [km]."""
        ...

class TLEForceTerms:
    """SGP4/SDP4 force model perturbation terms from a TLE.

    Attributes:
        mean_motion_dot (float): First-order mean motion derivative [(rev/day)/day].
        mean_motion_dot_dot (float): Second-order mean motion derivative [(rev/day)/day²].
        b_term (float): B* drag term [1/earth-radii].
        agom (Optional[float]): Area-to-mass ratio for XP propagator [m²/kg],
            or ``None`` if not present in the TLE.
    """

    @property
    def mean_motion_dot(self) -> float:
        """First-order mean motion derivative [(rev/day)/day]."""
        ...

    @property
    def mean_motion_dot_dot(self) -> float:
        """Second-order mean motion derivative [(rev/day)/day²]."""
        ...

    @property
    def b_term(self) -> float:
        """B* drag term [1/earth-radii]."""
        ...

    @property
    def agom(self) -> Optional[float]:
        """Area-to-mass ratio for the XP propagator [m²/kg], or ``None``."""
        ...

class TLE:
    """A Two-Line Element set for a space object.

    Parses the NORAD TLE format and exposes orbital elements, epoch, force
    terms, and conversions to Keplerian and Cartesian states.

    Attributes:
        id (str): Object identifier (settable; defaults to satellite number).
        name (Optional[str]): Optional common name from line 0.
        line1 (str): Reconstructed TLE line 1.
        line2 (str): Reconstructed TLE line 2.
        epoch (ModifiedJulianDate): TLE epoch (UTC).
        keplerian_state (KeplerianState): Keplerian state at TLE epoch.
        mean_motion (float): Mean motion [rev/day].
        force_terms (TLEForceTerms): SGP4/SDP4 perturbation parameters.
        cartesian_state (CartesianState): Cartesian state at TLE epoch in TEME.
        b_star (float): B* drag parameter [1/earth-radii].
        satellite_number (int): Satellite catalog number.
        norad_id (int): Alias for ``satellite_number``.
        classification (Classification): Security classification.
        international_designator (str): International launch designator.
        ephemeris_type (int): Ephemeris type field.
        element_set_number (int): Element set number.
        revolution_number (int): Revolution number at epoch.
        keplerian_type (KeplerianType): Mean-motion theory (Kozai GP).
        semi_major_axis (float): Semi-major axis derived from mean motion [km].
        inclination (float): Inclination [rad; 0..π].
        raan (float): Right ascension of ascending node [rad; 0..2π).
        eccentricity (float): Eccentricity [dimensionless; 0..1).
        argument_of_perigee (float): Argument of perigee [rad; 0..2π).
        mean_anomaly (float): Mean anomaly [rad; 0..2π).
        mean_motion_dot (float): First-order mean motion derivative [(rev/day)/day].
        mean_motion_dot_dot (float): Second-order mean motion derivative [(rev/day)/day²].
        b_term (float): B* in alternate notation [1/earth-radii].
        agom (Optional[float]): Area-to-mass ratio for XP [m²/kg], or ``None``.
        periapsis (float): Periapsis radius [km].
        apoapsis (float): Apoapsis radius [km].
    """

    def __init__(self, line1: str, line2: str, name: Optional[str] = None) -> None:
        """Parses a TLE from two lines and an optional name.

        Args:
            line1: TLE line 1 (69-character NORAD format).
            line2: TLE line 2 (69-character NORAD format).
            name: Optional object name (line 0).

        Raises:
            ValueError: If the TLE lines cannot be parsed.
        """
        ...

    @property
    def id(self) -> str:
        """Object identifier (settable)."""
        ...

    @id.setter
    def id(self, value: str) -> None: ...

    def with_id(self, id: str) -> TLE:
        """Returns a copy with a new identifier.

        Args:
            id: New identifier string.

        Returns:
            `TLE` with the updated ``id``.
        """
        ...

    @property
    def name(self) -> Optional[str]:
        """Optional common name from line 0."""
        ...

    @property
    def line1(self) -> str:
        """Reconstructed TLE line 1."""
        ...

    @property
    def line2(self) -> str:
        """Reconstructed TLE line 2."""
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """TLE epoch (UTC)."""
        ...

    @property
    def keplerian_state(self) -> KeplerianState:
        """Keplerian state at TLE epoch."""
        ...

    @property
    def mean_motion(self) -> float:
        """Mean motion [rev/day]."""
        ...

    @property
    def force_terms(self) -> TLEForceTerms:
        """SGP4/SDP4 perturbation parameters."""
        ...

    @property
    def cartesian_state(self) -> CartesianState:
        """Cartesian state at TLE epoch in TEME [position in km, velocity in km/s]."""
        ...

    @property
    def b_star(self) -> float:
        """B* drag parameter [1/earth-radii]."""
        ...

    @property
    def satellite_number(self) -> int:
        """Satellite catalog number."""
        ...

    @property
    def norad_id(self) -> int:
        """NORAD catalog number (alias for ``satellite_number``)."""
        ...

    @property
    def classification(self) -> Classification:
        """Security classification."""
        ...

    @property
    def international_designator(self) -> str:
        """International launch designator."""
        ...

    @property
    def ephemeris_type(self) -> int:
        """Ephemeris type field from the TLE."""
        ...

    @property
    def element_set_number(self) -> int:
        """Element set number."""
        ...

    @property
    def revolution_number(self) -> int:
        """Revolution number at epoch."""
        ...

    @property
    def keplerian_type(self) -> KeplerianType:
        """Mean-motion theory (Kozai GP / SGP4)."""
        ...

    @property
    def semi_major_axis(self) -> float:
        """Semi-major axis derived from mean motion [km]."""
        ...

    @property
    def inclination(self) -> float:
        """Inclination [rad; 0..π]."""
        ...

    @property
    def raan(self) -> float:
        """Right ascension of ascending node [rad; 0..2π)."""
        ...

    @property
    def eccentricity(self) -> float:
        """Eccentricity [dimensionless; 0..1)."""
        ...

    @property
    def argument_of_perigee(self) -> float:
        """Argument of perigee [rad; 0..2π)."""
        ...

    @property
    def mean_anomaly(self) -> float:
        """Mean anomaly [rad; 0..2π)."""
        ...

    @property
    def mean_motion_dot(self) -> float:
        """First-order mean motion derivative [(rev/day)/day]."""
        ...

    @property
    def mean_motion_dot_dot(self) -> float:
        """Second-order mean motion derivative [(rev/day)/day²]."""
        ...

    @property
    def b_term(self) -> float:
        """B* drag term [1/earth-radii]."""
        ...

    @property
    def agom(self) -> Optional[float]:
        """Area-to-mass ratio for XP [m²/kg], or ``None``."""
        ...

    @property
    def periapsis(self) -> float:
        """Periapsis radius [km]."""
        ...

    @property
    def apoapsis(self) -> float:
        """Apoapsis radius [km]."""
        ...

    def __repr__(self) -> str: ...
