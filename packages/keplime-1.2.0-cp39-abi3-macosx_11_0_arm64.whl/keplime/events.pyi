# flake8: noqa
from __future__ import annotations

from .bodies import SensorConstraints
from .elements import CartesianState, CartesianVector
from .elements import HorizonState, TopocentricElements
from .enums import ReferenceFrame, UCTObservability, UCTValidity
from .estimation import CovarianceMatrix, ObservationAssociation
from .time import ModifiedJulianDate
from .time import TimeSpan


class CloseApproach:
    """A single close-approach (TCA) record between two bodies.

    Produced by close-approach search routines that scan a pair of
    [`Ephemeris`][keplime.elements.Ephemeris] objects for local minima of the
    relative range and refine each candidate to its time of closest
    approach.  The ``epoch`` is the refined TCA; ``distance`` is the
    minimum slant range at that epoch in the inertial frame shared by the
    two ephemerides.

    Attributes:
        epoch (ModifiedJulianDate): Time of closest approach.
        primary_id (str): Identifier of the primary body.
        secondary_id (str): Identifier of the secondary body.
        distance (float): Minimum slant range at TCA [km].
    """

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Time of closest approach."""
        ...

    @property
    def primary_id(self) -> str:
        """Identifier of the primary body."""
        ...

    @property
    def secondary_id(self) -> str:
        """Identifier of the secondary body."""
        ...

    @property
    def distance(self) -> float:
        """Minimum slant range at TCA [km]."""
        ...


class CloseApproachReport:
    """Collection of `CloseApproach` records gathered over a search range.

    The search window is ``[start, end]``; only approaches whose distance is
    less than or equal to ``distance_threshold`` are retained.  Use
    `get_probability_of_collision` to evaluate Pc for a candidate
    encounter.

    Attributes:
        start (ModifiedJulianDate): Start of the search range.
        end (ModifiedJulianDate): End of the search range.
        distance_threshold (float): Maximum slant range retained as a close
            approach [km].
        close_approaches (list[CloseApproach]): Refined TCA records, one per
            qualifying minimum.
    """

    def __init__(
        self, start: ModifiedJulianDate, end: ModifiedJulianDate, distance_threshold: float
    ) -> None:
        """Creates an empty CloseApproachReport over the given range.

        Args:
            start: Start of the search range.
            end: End of the search range.
            distance_threshold: Maximum slant range retained as a close
                approach [km].
        """
        ...

    @property
    def start(self) -> ModifiedJulianDate:
        """Start of the search range."""
        ...

    @property
    def end(self) -> ModifiedJulianDate:
        """End of the search range."""
        ...

    @property
    def distance_threshold(self) -> float:
        """Maximum slant range retained as a close approach [km]."""
        ...

    @property
    def close_approaches(self) -> list[CloseApproach]:
        """Refined TCA records, ordered by epoch."""
        ...

    @staticmethod
    def get_probability_of_collision(
        state_a: CartesianState,
        state_b: CartesianState,
        cov_a: CovarianceMatrix,
        cov_b: CovarianceMatrix,
        hbr_a: float,
        hbr_b: float,
    ) -> float:
        """Probability of collision via Foster–Estes 2D / Chan series.

        Both states must be at the same TCA epoch in the same inertial
        reference frame (e.g. TEME).  Each `CovarianceMatrix`
        must be at least 6×6 with ``CovarianceType.Inertial(_)``; only the
        leading 3×3 (position) block is used.  The Chan series sums in
        the 2D encounter plane perpendicular to the relative velocity.

        Args:
            state_a: Cartesian state of body A at TCA [position km, velocity km/s].
            state_b: Cartesian state of body B at TCA [position km, velocity km/s].
            cov_a: 6×6 inertial covariance of body A [km², km²/s units in the
                position block].
            cov_b: 6×6 inertial covariance of body B [km², km²/s units in the
                position block].
            hbr_a: Hard-body radius of body A [m].
            hbr_b: Hard-body radius of body B [m].

        Returns:
            Probability of collision clamped to ``[0, 1]`` [dimensionless].

        Raises:
            ValueError: If the input states do not share a reference frame,
                their epochs differ by more than 1 ms, either covariance is
                not `Inertial`, either
                covariance is smaller than 6×6, either hard-body radius is
                non-positive or non-finite, the relative velocity magnitude
                is zero, or the projected encounter-plane covariance is
                singular.
        """
        ...


class ProximityEvent:
    """A single contiguous interval during which two bodies are within a
    distance threshold.

    The ``start_epoch`` and ``end_epoch`` bracket the interval; the minimum
    and maximum slant ranges across the interval are reported in km.

    Attributes:
        primary_id (str): Identifier of the primary body.
        secondary_id (str): Identifier of the secondary body.
        start_epoch (ModifiedJulianDate): Ingress epoch (gate first holds).
        end_epoch (ModifiedJulianDate): Egress epoch (gate last holds).
        minimum_distance (float): Minimum slant range over the interval [km].
        maximum_distance (float): Maximum slant range over the interval [km].
    """

    @property
    def primary_id(self) -> str:
        """Identifier of the primary body."""
        ...

    @property
    def secondary_id(self) -> str:
        """Identifier of the secondary body."""
        ...

    @property
    def start_epoch(self) -> ModifiedJulianDate:
        """Ingress epoch (the first epoch at which the gate holds)."""
        ...

    @property
    def end_epoch(self) -> ModifiedJulianDate:
        """Egress epoch (the last epoch at which the gate holds)."""
        ...

    @property
    def minimum_distance(self) -> float:
        """Minimum slant range observed within the interval [km]."""
        ...

    @property
    def maximum_distance(self) -> float:
        """Maximum slant range observed within the interval [km]."""
        ...


class ProximityReport:
    """Collection of `ProximityEvent` intervals gathered over a search range.

    A proximity event is any contiguous span over which the relative slant
    range between two bodies stays at or below ``distance_threshold``.

    Attributes:
        start (ModifiedJulianDate): Start of the search range.
        end (ModifiedJulianDate): End of the search range.
        distance_threshold (float): Slant-range gate for proximity [km].
        events (list[ProximityEvent]): Detected intervals, ordered by
            ``start_epoch``.
    """

    def __init__(
        self, start: ModifiedJulianDate, end: ModifiedJulianDate, distance_threshold: float
    ) -> None:
        """Creates an empty ProximityReport over the given range.

        Args:
            start: Start of the search range.
            end: End of the search range.
            distance_threshold: Slant-range gate for proximity [km].
        """
        ...

    @property
    def start(self) -> ModifiedJulianDate:
        """Start of the search range."""
        ...

    @property
    def end(self) -> ModifiedJulianDate:
        """End of the search range."""
        ...

    @property
    def distance_threshold(self) -> float:
        """Slant-range gate for proximity [km]."""
        ...

    @property
    def events(self) -> list[ProximityEvent]:
        """Detected proximity intervals, ordered by ``start_epoch``."""
        ...


class ManeuverEvent:
    """A single instantaneous maneuver inferred from a velocity discontinuity.

    Built by maneuver-detection routines that compare the velocity of a
    satellite immediately before and after a candidate epoch.  The reported
    ``delta_v`` is the post-minus-pre velocity vector in the same inertial
    frame as the underlying ephemeris.

    Attributes:
        satellite_id (str): Identifier of the maneuvering satellite.
        epoch (ModifiedJulianDate): Epoch of the inferred maneuver.
        delta_v (CartesianVector): Velocity change vector [m/s; 3 components].
    """

    @property
    def satellite_id(self) -> str:
        """Identifier of the maneuvering satellite."""
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch of the inferred maneuver."""
        ...

    @property
    def delta_v(self) -> CartesianVector:
        """Velocity change vector [m/s; 3 components, inertial frame]."""
        ...


class ManeuverReport:
    """Collection of `ManeuverEvent` records gathered over a search range.

    The detector flags candidates by close-approach proximity within
    ``distance_threshold`` and admits a candidate as a maneuver when the
    velocity discontinuity magnitude meets or exceeds ``velocity_threshold``.

    Attributes:
        start (ModifiedJulianDate): Start of the search range.
        end (ModifiedJulianDate): End of the search range.
        distance_threshold (float): Slant-range gate used to seed maneuver
            candidates [km].
        velocity_threshold (float): Minimum delta-v magnitude required to
            admit a candidate as a maneuver [m/s].
        maneuvers (list[ManeuverEvent]): Detected maneuvers, ordered by
            epoch.
    """

    def __init__(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
        velocity_threshold: float,
    ) -> None:
        """Creates an empty ManeuverReport over the given range.

        Args:
            start: Start of the search range.
            end: End of the search range.
            distance_threshold: Slant-range gate used to seed maneuver
                candidates [km].
            velocity_threshold: Minimum delta-v magnitude required to admit
                a candidate as a maneuver [m/s].
        """
        ...

    @property
    def start(self) -> ModifiedJulianDate:
        """Start of the search range."""
        ...

    @property
    def end(self) -> ModifiedJulianDate:
        """End of the search range."""
        ...

    @property
    def distance_threshold(self) -> float:
        """Slant-range gate used to seed maneuver candidates [km]."""
        ...

    @property
    def velocity_threshold(self) -> float:
        """Minimum delta-v magnitude required to admit a maneuver [m/s]."""
        ...

    @property
    def maneuvers(self) -> list[ManeuverEvent]:
        """Detected maneuvers, ordered by epoch."""
        ...


class FieldOfViewCandidate:
    """A single satellite that falls within a sensor's field of view.

    Reports the satellite identifier together with its topocentric direction
    relative to the sensor at the field-of-view epoch.

    Attributes:
        satellite_id (str): Identifier of the candidate satellite.
        direction (TopocentricElements): Topocentric direction (and optional
            range/rate fields) from the sensor to the satellite.
    """

    def __init__(self, satellite_id: str, direction: TopocentricElements) -> None:
        """Creates a FieldOfViewCandidate.

        Args:
            satellite_id: Identifier of the candidate satellite.
            direction: Topocentric direction from sensor to satellite.
        """
        ...

    @property
    def satellite_id(self) -> str:
        """Identifier of the candidate satellite."""
        ...

    @property
    def direction(self) -> TopocentricElements:
        """Topocentric direction from sensor to satellite."""
        ...


class FieldOfViewReport:
    """Snapshot of all satellites within a sensor's conical field of view at one epoch.

    The sensor is described by an inertial position, a topocentric pointing
    direction, and a half-angle ``fov_angle``.  ``candidates`` lists every
    satellite whose line-of-sight makes an angle no greater than ``fov_angle``
    with the sensor pointing direction at ``epoch``.

    Attributes:
        epoch (ModifiedJulianDate): Epoch at which the field-of-view scan was
            evaluated.
        sensor_position (CartesianVector): Sensor position [km; 3 components,
            ``reference_frame``].
        sensor_direction (TopocentricElements): Sensor pointing direction
            (right-ascension/declination in the topocentric frame at the
            sensor location).
        fov_angle (float): Field-of-view half-angle [rad; 0..π/2].
        candidates (list[FieldOfViewCandidate]): Satellites whose line-of-sight
            falls within ``fov_angle`` of ``sensor_direction``.
        reference_frame (ReferenceFrame): Inertial frame of
            ``sensor_position``.
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        sensor_position: CartesianVector,
        sensor_direction: TopocentricElements,
        fov_angle: float,
        reference_frame: ReferenceFrame,
    ) -> None:
        """Creates an empty FieldOfViewReport.

        Args:
            epoch: Epoch at which the field-of-view scan was evaluated.
            sensor_position: Sensor position [km; 3 components,
                ``reference_frame``].
            sensor_direction: Sensor pointing direction.
            fov_angle: Field-of-view half-angle [rad; 0..π/2].
            reference_frame: Inertial frame of ``sensor_position``.
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch at which the field-of-view scan was evaluated."""
        ...

    @property
    def sensor_position(self) -> CartesianVector:
        """Sensor position [km; 3 components, in `reference_frame`]."""
        ...

    @property
    def sensor_direction(self) -> TopocentricElements:
        """Sensor pointing direction (topocentric)."""
        ...

    @property
    def fov_angle(self) -> float:
        """Field-of-view half-angle [rad; 0..π/2]."""
        ...

    @property
    def candidates(self) -> list[FieldOfViewCandidate]:
        """Satellites within `fov_angle` of `sensor_direction`."""
        ...

    @property
    def reference_frame(self) -> ReferenceFrame:
        """Inertial frame of `sensor_position`."""
        ...


class HorizonAccess:
    """A single contiguous interval during which a target rises above an
    observer's local horizon at or above an elevation threshold.

    The window is bracketed by ingress and egress
    [`HorizonState`][keplime.elements.HorizonState] snapshots, each of which
    carries azimuth, elevation, and the observer state in ITRF at that
    boundary.

    Attributes:
        target_id (str): Identifier of the observed target.
        target_name (str | None): Optional human-readable target name.
        observer_id (str): Identifier of the observing site.
        observer_name (str | None): Optional human-readable observer name.
        start (HorizonState): Ingress horizon snapshot.
        end (HorizonState): Egress horizon snapshot.
    """

    def __init__(
        self,
        target_id: str,
        observer_id: str,
        start: HorizonState,
        end: HorizonState,
        target_name: str | None = ...,
        observer_name: str | None = ...,
    ) -> None:
        """Creates a HorizonAccess window.

        Args:
            target_id: Identifier of the observed target.
            observer_id: Identifier of the observing site.
            start: Ingress horizon snapshot.
            end: Egress horizon snapshot.
            target_name: Optional human-readable target name.
            observer_name: Optional human-readable observer name.
        """
        ...

    @property
    def target_id(self) -> str:
        """Identifier of the observed target."""
        ...

    @property
    def target_name(self) -> str | None:
        """Optional human-readable target name."""
        ...

    @property
    def observer_id(self) -> str:
        """Identifier of the observing site."""
        ...

    @property
    def observer_name(self) -> str | None:
        """Optional human-readable observer name."""
        ...

    @property
    def start(self) -> HorizonState:
        """Ingress [`HorizonState`][keplime.elements.HorizonState]."""
        ...

    @property
    def end(self) -> HorizonState:
        """Egress [`HorizonState`][keplime.elements.HorizonState]."""
        ...


class HorizonAccessReport:
    """Collection of `HorizonAccess` windows above an elevation gate.

    A window is admitted only if the target stays at or above
    ``elevation_threshold`` for at least ``duration_threshold``.

    Attributes:
        accesses (list[HorizonAccess]): Detected access windows ordered by
            ingress epoch.
        elevation_threshold (float): Minimum target elevation above the local
            horizon required for access [rad; -π/2..π/2].
        start (ModifiedJulianDate): Start of the search range.
        end (ModifiedJulianDate): End of the search range.
        duration_threshold (TimeSpan): Minimum window duration required for
            admission.
    """

    def __init__(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        min_elevation: float,
        min_duration: TimeSpan,
    ) -> None:
        """Creates an empty HorizonAccessReport over the given range.

        Args:
            start: Start of the search range.
            end: End of the search range.
            min_elevation: Minimum target elevation above the local horizon
                required for access [rad; -π/2..π/2].
            min_duration: Minimum window duration required for admission.
        """
        ...

    @property
    def accesses(self) -> list[HorizonAccess]:
        """Detected access windows ordered by ingress epoch."""
        ...

    @property
    def elevation_threshold(self) -> float:
        """Elevation gate above the local horizon [rad; -π/2..π/2]."""
        ...

    @property
    def start(self) -> ModifiedJulianDate:
        """Start of the search range."""
        ...

    @property
    def end(self) -> ModifiedJulianDate:
        """End of the search range."""
        ...

    @property
    def duration_threshold(self) -> TimeSpan:
        """Minimum window duration required for admission."""
        ...


class SensorAccess:
    """A single contiguous interval during which a target satisfies all
    [`SensorConstraints`][keplime.bodies.SensorConstraints] gates from a sensor host.

    Built by the ``*_sensor_access`` family on
    [`Ephemeris`][keplime.elements.Ephemeris]; see those methods for how
    the bore direction is derived per access mode.

    Attributes:
        observer_id (str): Identifier of the sensor host.
        target_id (str): Identifier of the body being observed.
        start_epoch (ModifiedJulianDate): Ingress epoch.
        end_epoch (ModifiedJulianDate): Egress epoch.
    """

    def __init__(
        self,
        observer_id: str,
        target_id: str,
        start_epoch: ModifiedJulianDate,
        end_epoch: ModifiedJulianDate,
    ) -> None:
        """Creates a new SensorAccess.

        Args:
            observer_id: Identifier of the sensor host.
            target_id: Identifier of the body being observed.
            start_epoch: Ingress epoch.
            end_epoch: Egress epoch.
        """
        ...

    @property
    def observer_id(self) -> str:
        """Returns the sensor-host identifier [str]."""
        ...

    @property
    def target_id(self) -> str:
        """Returns the observed-body identifier [str]."""
        ...

    @property
    def start_epoch(self) -> ModifiedJulianDate:
        """Returns the ingress epoch."""
        ...

    @property
    def end_epoch(self) -> ModifiedJulianDate:
        """Returns the egress epoch."""
        ...


class SensorAccessReport:
    """Collection of `SensorAccess` windows produced for a single
    observer/target/constraints triple.

    Attributes:
        start (ModifiedJulianDate): Start of the requested search range.
        end (ModifiedJulianDate): End of the requested search range.
        constraints (SensorConstraints): Constraints used in evaluation.
        accesses (list[SensorAccess]): Access windows ordered by
            ``start_epoch``.
    """

    def __init__(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        constraints: SensorConstraints,
    ) -> None:
        """Creates an empty SensorAccessReport over the given range.

        Args:
            start: Start of the requested search range.
            end: End of the requested search range.
            constraints: Constraints applied during evaluation.
        """
        ...

    @property
    def start(self) -> ModifiedJulianDate:
        """Returns the start of the requested search range."""
        ...

    @property
    def end(self) -> ModifiedJulianDate:
        """Returns the end of the requested search range."""
        ...

    @property
    def constraints(self) -> SensorConstraints:
        """Returns the constraints used to evaluate this report."""
        ...

    @property
    def accesses(self) -> list[SensorAccess]:
        """Returns the access windows ordered by ``start_epoch``."""
        ...


class UCTValidityReport:
    """Validity assessment for an Uncorrelated Track (UCT) candidate.

    Aggregates evidence used to classify a candidate UCT: any associations
    to existing tracks, possible cross-tags from proximity events, possible
    parent objects from close approaches, plus aggregate observability and
    validity verdicts.

    Attributes:
        satellite_id (str): Identifier of the candidate UCT.
        associations (list[ObservationAssociation]): Observation associations
            considered during assessment.
        possible_cross_tags (list[ProximityEvent]): Proximity events flagged
            as possible cross-tag sources.
        possible_origins (list[CloseApproach]): Close approaches flagged as
            possible origin events (e.g., breakup parents).
        observability (UCTObservability): Aggregate observability verdict
            for the candidate.
        validity (UCTValidity): Aggregate validity verdict for the candidate.
    """

    def __init__(
        self,
        satellite_id: str,
        associations: list[ObservationAssociation],
        possible_cross_tags: list[ProximityEvent],
        possible_origins: list[CloseApproach],
        observability: UCTObservability,
        validity: UCTValidity,
    ) -> None:
        """Creates a UCTValidityReport.

        Args:
            satellite_id: Identifier of the candidate UCT.
            associations: Observation associations considered during
                assessment.
            possible_cross_tags: Proximity events flagged as possible
                cross-tag sources.
            possible_origins: Close approaches flagged as possible origin
                events.
            observability: Aggregate observability verdict.
            validity: Aggregate validity verdict.
        """
        ...

    @property
    def satellite_id(self) -> str:
        """Identifier of the candidate UCT."""
        ...

    @property
    def associations(self) -> list[ObservationAssociation]:
        """Observation associations considered during assessment."""
        ...

    @property
    def possible_cross_tags(self) -> list[ProximityEvent]:
        """Proximity events flagged as possible cross-tag sources."""
        ...

    @property
    def possible_origins(self) -> list[CloseApproach]:
        """Close approaches flagged as possible origin events."""
        ...

    @property
    def observability(self) -> UCTObservability:
        """Aggregate observability verdict for the candidate."""
        ...

    @property
    def validity(self) -> UCTValidity:
        """Aggregate validity verdict for the candidate."""
        ...
