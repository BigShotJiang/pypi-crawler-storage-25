from __future__ import annotations

from ._keplime import signatures as _signatures  # type: ignore  # noqa: E402

AttitudeCharacterization = _signatures.AttitudeCharacterization

__all__ = [
    "AttitudeCharacterization",
]
