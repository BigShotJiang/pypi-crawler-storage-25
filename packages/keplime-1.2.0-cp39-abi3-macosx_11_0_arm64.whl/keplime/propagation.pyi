# flake8: noqa
from __future__ import annotations

from typing import Dict, Tuple

from .bodies import Satellite
from .elements import CartesianState, Ephemeris
from .enums import DevicePreference, PerformancePriority, ReferenceFrame
from .time import ModifiedJulianDate, TimeSpan

def b_star_to_drag_coefficient(b_star: float) -> float:
    """Convert a TLE ``B*`` drag term to the keplime ballistic coefficient.

    The keplime ballistic coefficient ``B`` is related to the TLE BSTAR term
    by the constant ``B_STAR_TO_B_TERM`` (≈ 12.74 km²/kg), which encodes
    the reference atmospheric density and drag coefficient conventions.

    Args:
        b_star: TLE BSTAR drag term [1/earth_radii; typically 1e-5..1e-3].

    Returns:
        Ballistic coefficient ``B = B* × B_STAR_TO_B_TERM`` [km²/kg].
    """
    ...

def drag_coefficient_to_b_star(drag_coefficient: float) -> float:
    """Convert a keplime ballistic coefficient to a TLE ``B*`` drag term.

    Inverts `b_star_to_drag_coefficient`:
    ``B* = B / B_STAR_TO_B_TERM``.

    Args:
        drag_coefficient: Ballistic coefficient ``B`` [km²/kg].

    Returns:
        TLE BSTAR drag term [1/earth_radii].
    """
    ...


class Maneuver:
    """A delta-V-driven maneuver specification.

    Describes what delta-V to apply, in what direction, and when.  Pass a
    `Maneuver` to the propagator's maneuver execution interface to
    apply it impulsively or as a finite burn.

    For impulsive maneuvers the full `magnitude` is applied
    instantaneously at `epoch`.  For finite burns the burn is
    centered on `epoch` with duration derived from the Tsiolkovsky
    rocket equation.

    Attributes:
        epoch (ModifiedJulianDate): Center epoch of the maneuver [MJD].
            For finite burns the burn is symmetric around this epoch
            (start = epoch − duration / 2).
        direction (tuple[float, float, float]): Unit direction of the
            delta-V in `reference_frame` [dimensionless;
            x, y, z; normalized internally].
        reference_frame (ReferenceFrame): Frame for the direction vector.
            Use `TEME` for inertial
            or `RIC` for
            radial/in-track/cross-track decomposition.
        magnitude (float): Target delta-V magnitude [km/s].
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        direction_x: float,
        direction_y: float,
        direction_z: float,
        reference_frame: ReferenceFrame,
        magnitude: float,
    ) -> None:
        """Creates a new Maneuver.

        Args:
            epoch: Center epoch of the maneuver [MJD].
            direction_x: X component of the delta-V direction in
                ``reference_frame`` [dimensionless; normalized internally].
            direction_y: Y component of the delta-V direction [dimensionless].
            direction_z: Z component of the delta-V direction [dimensionless].
            reference_frame: Frame for the direction vector.
            magnitude: Target delta-V magnitude [km/s].
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Center epoch of the maneuver [MJD].

        For finite burns the burn is centered on this epoch
        (start = epoch − duration / 2).

        Returns:
            Maneuver epoch.
        """
        ...

    @property
    def direction(self) -> Tuple[float, float, float]:
        """Unit direction of the delta-V in `reference_frame`
        [dimensionless; x, y, z].

        Returns:
            Direction vector components ``(x, y, z)`` [dimensionless].
        """
        ...

    @property
    def reference_frame(self) -> ReferenceFrame:
        """Reference frame in which `direction` is expressed.

        Returns:
            ReferenceFrame for the direction vector.
        """
        ...

    @property
    def magnitude(self) -> float:
        """Target delta-V magnitude [km/s].

        Returns:
            Delta-V magnitude [km/s].
        """
        ...

    def __repr__(self) -> str: ...


class BatchIntegrator:
    """Batched numerical Gauss-Jackson 8 propagator.

    Holds a satellite roster under a single
    [`PerformancePriority`][keplime.enums.PerformancePriority] preset and emits one
    [`Ephemeris`][keplime.elements.Ephemeris] per satellite over a requested
    window.  CPU and GPU backends are selected by
    [`DevicePreference`][keplime.enums.DevicePreference]; results are returned in
    the same order as `add_satellite` calls.

    The GPU backend (when ``feature = "gpu"`` is enabled at build time and
    a wgpu adapter is available) supports gravity, third-body Sun/Moon,
    cannonball SRP with cylindrical shadow, and NRLMSISE-00 atmospheric
    drag.  Other drag models (Harris-Priester, Jacchia-Bowman 2008,
    Jacchia-Roberts 71) force a CPU fallback transparently under
    `Auto` and raise
    ``GpuUnsupportedSetting`` under
    `GPU`.
    """

    def __init__(
        self,
        priority: PerformancePriority,
        drag: bool = True,
    ) -> None:
        """Creates a new ``BatchIntegrator``.

        Args:
            priority: Preset for force-model defaults
                (Precision / Balanced / Speed). Drag, SRP, third bodies,
                gravity order, and step size all derive from this preset.
            drag: Whether to include drag in the force model.  Defaults
                to ``True``.  Set to ``False`` for high-altitude orbits
                where drag is negligible — disabling drag widens GPU
                eligibility because only NRLMSISE-00 is supported on GPU.
        """
        ...

    def add_satellite(self, satellite: Satellite) -> None:
        """Append a satellite to the batch.

        Args:
            satellite: Satellite with a Cartesian state set.

        Raises:
            ValueError: If ``satellite.cartesian_state`` is ``None``.
        """
        ...

    @property
    def len(self) -> int:
        """Number of satellites currently in the batch.

        Returns:
            Satellite count.
        """
        ...

    @property
    def is_empty(self) -> bool:
        """True when no satellites have been added.

        Returns:
            Whether the batch is empty.
        """
        ...

    def propagate_ephemeris(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        step: TimeSpan,
        target_frame: ReferenceFrame,
        device: DevicePreference,
    ) -> Dict[str, Ephemeris]:
        """Propagate every satellite from ``start`` to ``end``.

        Args:
            start: Window start epoch.
            end: Window end epoch.
            step: Output sample cadence.
            target_frame: Frame for the output states.
            device: Backend selector. ``Auto`` consults the GPU
                work-item threshold and the force-model settings to
                decide CPU vs GPU.

        Returns:
            One [`Ephemeris`][keplime.elements.Ephemeris] per satellite,
            keyed by satellite id.

        Raises:
            RuntimeError: If every satellite returned an error.  Partial
                success returns a dict containing only successful entries.
        """
        ...


class ManeuverResult:
    """Result of executing a maneuver against a propagated state.

    Returned by the propagator's maneuver execution interface.  For impulsive
    maneuvers both `fuel_consumed` and `duration` are
    ``0.0``.

    Attributes:
        state (CartesianState): Post-maneuver orbital state in the TEME frame.
        fuel_consumed (float): Total propellant consumed during the burn [kg].
            Zero for impulsive maneuvers without fuel tracking.
        duration (float): Total burn duration [s].  Zero for impulsive
            maneuvers.
    """

    @property
    def state(self) -> CartesianState:
        """Post-maneuver orbital state in the TEME frame.

        Returns:
            CartesianState immediately after maneuver execution.
        """
        ...

    @property
    def fuel_consumed(self) -> float:
        """Total propellant consumed during the burn [kg].

        Returns:
            Fuel consumed [kg].  Zero for impulsive maneuvers.
        """
        ...

    @property
    def duration(self) -> float:
        """Total burn duration [s].

        Returns:
            Burn duration [s].  Zero for impulsive maneuvers.
        """
        ...

    def __repr__(self) -> str: ...
