from __future__ import annotations

from . import bodies, catalogs, data, elements, enums, estimation, events, frames, iod, licensing, propagation, schemas, signatures, time
from .licensing import LicenseError as LicenseError

def get_thread_count() -> int:
    """Returns the current rayon global thread pool size.

    Initializes the global pool with default settings (one thread per
    logical CPU) if it has not been built yet.  After calling this, any
    subsequent call to `set_thread_count` will fail because the
    rayon global pool can only be configured once per process.

    Returns:
        Number of threads in the rayon global pool [count; >= 1].
    """
    ...

def set_thread_count(n: int) -> None:
    """Sets the rayon global thread pool size.

    Must be called before any rayon parallel work runs and before
    `get_thread_count` is invoked, since the global thread pool
    can only be initialized once per process.  Subsequent calls — or
    calls made after rayon has lazily initialized — raise ``RuntimeError``.

    Args:
        n: Desired number of worker threads [count; >= 1].

    Raises:
        RuntimeError: If the rayon global thread pool has already been
            initialized.
    """
    ...

__all__ = [
    "LicenseError",
    "bodies",
    "catalogs",
    "data",
    "elements",
    "enums",
    "estimation",
    "events",
    "frames",
    "get_thread_count",
    "iod",
    "licensing",
    "propagation",
    "schemas",
    "set_thread_count",
    "signatures",
    "time",
]
