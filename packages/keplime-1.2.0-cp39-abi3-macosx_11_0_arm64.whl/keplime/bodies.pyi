# flake8: noqa
from __future__ import annotations

from typing import Iterator, Optional

from .catalogs import TLECatalog
from .elements import BoreToBodyAngles, CartesianState, Ephemeris, GeodeticPosition, KeplerianState, OrbitPlotData, TLE
from .estimation import CollectionAssociationReport, CovarianceMatrix, Observation, ObservationCollection, ObservationResidual
from .signatures import AttitudeCharacterization
from .enums import DevicePreference, PerformancePriority, ReferenceFrame
from .time import TimeSpan
from .events import (
    CloseApproach,
    CloseApproachReport,
    HorizonAccessReport,
    ManeuverEvent,
    ManeuverReport,
    ProximityReport,
    UCTValidityReport,
)
from .enums import KeplerianType, RelativeFrame
from .propagation import Maneuver, ManeuverResult
from .time import ModifiedJulianDate


class Tank:
    """A propellant tank on a satellite.

    Tracks the current propellant mass.  Multiple tanks may be connected
    to a single `Thruster` via `TankConnection`.

    Attributes:
        id (str): Human-readable identifier (e.g. ``"hydrazine"``).
        mass (float): Current propellant mass [kg; >= 0].
    """

    def __init__(self, id: str, mass: float) -> None:
        """Creates a new Tank.

        Args:
            id: Human-readable identifier (e.g. ``"hydrazine"``).
            mass: Initial propellant mass [kg; >= 0].
        """
        ...

    @property
    def id(self) -> str:
        """Returns the tank identifier [str]."""
        ...

    @property
    def mass(self) -> float:
        """Returns the current propellant mass [kg]."""
        ...

    def __repr__(self) -> str: ...


class TankConnection:
    """Links a thruster to a propellant tank with a fractional draw rate.

    All `TankConnection` fractions for a given `Thruster`
    must sum to 1.0.

    Attributes:
        tank_id (str): References a `id`.
        fraction (float): Fraction of total mass flow drawn from this
            tank [dimensionless; 0..=1].
    """

    def __init__(self, tank_id: str, fraction: float) -> None:
        """Creates a new TankConnection.

        Args:
            tank_id: References a `id`.
            fraction: Fraction of total mass flow drawn from this tank
                [dimensionless; 0..=1].
        """
        ...

    @property
    def tank_id(self) -> str:
        """Returns the referenced tank identifier [str]."""
        ...

    @property
    def fraction(self) -> float:
        """Returns the fractional mass-flow draw [dimensionless; 0..=1]."""
        ...

    def __repr__(self) -> str: ...


class Thruster:
    """A thruster with fixed performance characteristics.

    Connects to one or more `Tank` instances via
    `TankConnection`.  All connection fractions must sum to 1.0.

    Attributes:
        id (str): Human-readable identifier (e.g. ``"main_engine"``).
        thrust (float): Thrust force [N].
        isp (float): Specific impulse [s].
        connections (list[TankConnection]): Tank connections for propellant
            draw.
    """

    def __init__(self, id: str, thrust: float, isp: float) -> None:
        """Creates a new Thruster with no tank connections.

        Args:
            id: Human-readable identifier (e.g. ``"main_engine"``).
            thrust: Thrust force [N; > 0].
            isp: Specific impulse [s; > 0].
        """
        ...

    def with_connection(self, connection: TankConnection) -> Thruster:
        """Returns a copy of this thruster with the given tank connection added.

        Args:
            connection: Tank connection to append.

        Returns:
            `Thruster` with the connection added.
        """
        ...

    @property
    def id(self) -> str:
        """Returns the thruster identifier [str]."""
        ...

    @property
    def thrust(self) -> float:
        """Returns the thrust force [N]."""
        ...

    @property
    def isp(self) -> float:
        """Returns the specific impulse [s]."""
        ...

    @property
    def connections(self) -> list[TankConnection]:
        """Returns the list of tank connections."""
        ...

    def mass_flow_rate(self) -> float:
        """Computes the mass flow rate.

        Calculated as ``thrust / (isp * g0)`` where ``g0 = 9.80665 m/s²``.

        Returns:
            float: Mass flow rate [kg/s].
        """
        ...

    def exhaust_velocity(self) -> float:
        """Computes the effective exhaust velocity.

        Calculated as ``isp * g0`` where ``g0 = 9.80665e-3 km/s²``.

        Returns:
            float: Exhaust velocity [km/s].
        """
        ...

    def acceleration(self, mass_kg: float) -> float:
        """Computes the instantaneous thrust acceleration.

        Args:
            mass_kg: Current total spacecraft mass [kg; > 0].

        Returns:
            float: Acceleration magnitude [km/s²].
        """
        ...

    def __repr__(self) -> str: ...


class Sun:
    """Low-precision analytical Sun ephemeris.

    All methods are static; no instantiation is required.  Position accuracy
    is approximately 1 arcminute over a ±50-year range around J2000.
    """

    @staticmethod
    def get_state_at_epoch(epoch: ModifiedJulianDate) -> Optional[CartesianState]:
        """Returns the Sun's Cartesian state in J2000/ECI at the given epoch.

        Uses a low-precision analytical model (truncated Meeus series).
        Position accuracy is approximately 1 arcminute; velocity is derived
        analytically from the same series.

        Args:
            epoch: Epoch in any supported time system.

        Returns:
            [`CartesianState`][keplime.elements.CartesianState] if the ephemeris can
            be evaluated, otherwise ``None``.
        """
        ...


class Moon:
    """Low-precision analytical Moon ephemeris.

    All methods are static; no instantiation is required.  Position accuracy
    is on the order of arcminutes over a ±50-year range around J2000.
    """

    @staticmethod
    def get_state_at_epoch(epoch: ModifiedJulianDate) -> Optional[CartesianState]:
        """Returns the Moon's Cartesian state in J2000/ECI at the given epoch.

        Uses a low-precision analytical model (truncated series).
        Position accuracy is on the order of arcminutes; velocity is derived
        analytically from the same series.

        Args:
            epoch: Epoch in any supported time system.

        Returns:
            [`CartesianState`][keplime.elements.CartesianState] if the ephemeris can
            be evaluated, otherwise ``None``.
        """
        ...


class EarthModel:
    """Constant parameters for an Earth gravity and geodetic model.

    Instances are obtained from the `Earth` class attributes
    (e.g. ``Earth.egm_96``).  All values are static and zero-allocation.

    Attributes:
        equatorial_radius (float): Equatorial radius [km].
        mu (float): Gravitational parameter GM [km³/s²].
        j2 (float): Second zonal harmonic coefficient [dimensionless].
        j3 (float): Third zonal harmonic coefficient [dimensionless].
        j4 (float): Fourth zonal harmonic coefficient [dimensionless].
        flattening (float): Flattening factor f = (a − b) / a
            [dimensionless].
    """

    @property
    def equatorial_radius(self) -> float:
        """Returns the equatorial radius [km]."""
        ...

    @property
    def mu(self) -> float:
        """Returns the gravitational parameter GM [km³/s²]."""
        ...

    @property
    def j2(self) -> float:
        """Returns the second zonal harmonic coefficient J₂ [dimensionless]."""
        ...

    @property
    def j3(self) -> float:
        """Returns the third zonal harmonic coefficient J₃ [dimensionless]."""
        ...

    @property
    def j4(self) -> float:
        """Returns the fourth zonal harmonic coefficient J₄ [dimensionless]."""
        ...

    @property
    def flattening(self) -> float:
        """Returns the flattening factor f = (a − b) / a [dimensionless]."""
        ...


class Earth:
    """Factory for Earth gravity and geodetic model constants.

    Access pre-resolved model constants as class attributes.  Use
    `wgs_72` for SGP4/SDP4 propagation; use `egm_96`
    or `egm_2008` for numerical (XP) propagation.

    Attributes:
        wgs_72 (EarthModel): World Geodetic System 1972 constants.
        wgs_84 (EarthModel): World Geodetic System 1984 constants.
        egm_96 (EarthModel): Earth Gravitational Model 1996 constants.
        egm_2008 (EarthModel): Earth Gravitational Model 2008 constants.
    """

    wgs_72: EarthModel
    wgs_84: EarthModel
    egm_96: EarthModel
    egm_2008: EarthModel


class Sensor:
    """A measurement sensor attached to a satellite or ground station.

    Noise parameters are 1-sigma values for each measurement type.  Set only
    the parameters relevant to the sensor's modality; unused noise fields
    default to ``None``.

    Attributes:
        id (str): Auto-generated UUID identifier.
        name (str | None): Optional human-readable label.
        angular_noise (float | None): 1-sigma angular measurement noise [rad].
        range_noise (float | None): 1-sigma range measurement noise [km].
        range_rate_noise (float | None): 1-sigma range-rate measurement
            noise [km/s].
        angular_rate_noise (float | None): 1-sigma angular-rate measurement
            noise [rad/s].
    """

    def __init__(self, angular_noise: Optional[float] = ...) -> None:
        """Creates a new Sensor with a random UUID identifier.

        All noise fields except ``angular_noise`` are initialised to ``None``.

        Args:
            angular_noise: 1-sigma angular measurement noise [rad].
                Pass ``None`` for a non-optical sensor.
        """
        ...

    @property
    def id(self) -> str:
        """Returns the auto-generated UUID identifier [str]."""
        ...

    @id.setter
    def id(self, value: str) -> None:
        """Sets the sensor identifier.

        Args:
            value: New identifier string.
        """
        ...

    @property
    def name(self) -> Optional[str]:
        """Returns the optional human-readable sensor name [str | None]."""
        ...

    @name.setter
    def name(self, value: Optional[str]) -> None:
        """Sets the optional human-readable sensor name.

        Args:
            value: Sensor name, or ``None`` to clear.
        """
        ...

    @property
    def angular_noise(self) -> Optional[float]:
        """Returns the 1-sigma angular measurement noise [rad | None]."""
        ...

    @angular_noise.setter
    def angular_noise(self, value: Optional[float]) -> None:
        """Sets the 1-sigma angular measurement noise.

        Args:
            value: Angular noise [rad], or ``None`` to clear.
        """
        ...

    @property
    def range_noise(self) -> Optional[float]:
        """Returns the 1-sigma range measurement noise [km | None]."""
        ...

    @range_noise.setter
    def range_noise(self, value: Optional[float]) -> None:
        """Sets the 1-sigma range measurement noise.

        Args:
            value: Range noise [km], or ``None`` to clear.
        """
        ...

    @property
    def range_rate_noise(self) -> Optional[float]:
        """Returns the 1-sigma range-rate measurement noise [km/s | None]."""
        ...

    @range_rate_noise.setter
    def range_rate_noise(self, value: Optional[float]) -> None:
        """Sets the 1-sigma range-rate measurement noise.

        Args:
            value: Range-rate noise [km/s], or ``None`` to clear.
        """
        ...

    @property
    def angular_rate_noise(self) -> Optional[float]:
        """Returns the 1-sigma angular-rate measurement noise [rad/s | None]."""
        ...

    @angular_rate_noise.setter
    def angular_rate_noise(self, value: Optional[float]) -> None:
        """Sets the 1-sigma angular-rate measurement noise.

        Args:
            value: Angular-rate noise [rad/s], or ``None`` to clear.
        """
        ...


class SensorConstraints:
    """Geometry, lighting, and dwell-time gates applied to a sensor's line
    of sight.

    Permissive defaults — ``maximum_target_angle = π``, all minimum angles
    ``0``, both eclipse flags ``True``, ``minimum_duration`` zero — make a
    default-constructed `SensorConstraints` impose no gating, so
    downstream access methods can apply the same predicate regardless of
    whether the user customised any field.

    Attributes:
        maximum_target_angle (float): Max angle from boresight at which a
            target remains in the field of view [rad; 0..π].
        minimum_sun_angle (float): Minimum angle between the line of sight
            and the Sun direction [rad; 0..π].
        minimum_earth_angle (float): Minimum angle between the line of sight
            and the Earth-center direction [rad; 0..π].
        minimum_moon_angle (float): Minimum angle between the line of sight
            and the Moon direction [rad; 0..π].
        allow_target_eclipse (bool): If ``False``, the observed body must
            not be in Earth's shadow.
        allow_sensor_eclipse (bool): If ``False``, the sensor host must not
            be in Earth's shadow.
        minimum_duration (TimeSpan): Minimum dwell time required for an
            access window to be reported. Windows shorter than this are
            filtered out of the final report. Default zero (no filter).
    """

    def __init__(
        self,
        maximum_target_angle: float = ...,
        minimum_sun_angle: float = ...,
        minimum_earth_angle: float = ...,
        minimum_moon_angle: float = ...,
        allow_target_eclipse: bool = ...,
        allow_sensor_eclipse: bool = ...,
        minimum_duration: Optional[TimeSpan] = ...,
    ) -> None:
        """Creates a new SensorConstraints.

        All arguments default to the permissive values described in the
        class docstring.

        Args:
            maximum_target_angle: Max angle from boresight at which a target
                remains in the field of view [rad; 0..π].
            minimum_sun_angle: Minimum angle between the line of sight and
                the Sun direction [rad; 0..π].
            minimum_earth_angle: Minimum angle between the line of sight and
                the Earth-center direction [rad; 0..π].
            minimum_moon_angle: Minimum angle between the line of sight and
                the Moon direction [rad; 0..π].
            allow_target_eclipse: If ``False``, the observed body must not
                be in Earth's shadow.
            allow_sensor_eclipse: If ``False``, the sensor host must not be
                in Earth's shadow.
            minimum_duration: Minimum dwell time required for an access
                window to survive the report. ``None`` (the default) is
                equivalent to a zero [`TimeSpan`][keplime.time.TimeSpan] and
                disables the filter.
        """
        ...

    @property
    def maximum_target_angle(self) -> float:
        """Returns the maximum target angle [rad; 0..π]."""
        ...

    @maximum_target_angle.setter
    def maximum_target_angle(self, value: float) -> None:
        """Sets the maximum angle from boresight at which a target is still in
        the field of view.

        Args:
            value: Maximum target angle [rad; 0..π].
        """
        ...

    @property
    def minimum_sun_angle(self) -> float:
        """Returns the minimum Sun angle [rad; 0..π]."""
        ...

    @minimum_sun_angle.setter
    def minimum_sun_angle(self, value: float) -> None:
        """Sets the minimum angle between the line of sight and the Sun direction.

        Args:
            value: Minimum Sun angle [rad; 0..π].
        """
        ...

    @property
    def minimum_earth_angle(self) -> float:
        """Returns the minimum Earth angle [rad; 0..π]."""
        ...

    @minimum_earth_angle.setter
    def minimum_earth_angle(self, value: float) -> None:
        """Sets the minimum angle between the line of sight and the Earth-center
        direction.

        Args:
            value: Minimum Earth angle [rad; 0..π].
        """
        ...

    @property
    def minimum_moon_angle(self) -> float:
        """Returns the minimum Moon angle [rad; 0..π]."""
        ...

    @minimum_moon_angle.setter
    def minimum_moon_angle(self, value: float) -> None:
        """Sets the minimum angle between the line of sight and the Moon direction.

        Args:
            value: Minimum Moon angle [rad; 0..π].
        """
        ...

    @property
    def allow_target_eclipse(self) -> bool:
        """Returns whether observed-body eclipses are permitted [bool]."""
        ...

    @allow_target_eclipse.setter
    def allow_target_eclipse(self, value: bool) -> None:
        """Sets whether accesses where the observed body is in Earth's shadow
        are permitted.

        Args:
            value: ``True`` to allow target eclipses, ``False`` to reject them.
        """
        ...

    @property
    def allow_sensor_eclipse(self) -> bool:
        """Returns whether sensor-host eclipses are permitted [bool]."""
        ...

    @allow_sensor_eclipse.setter
    def allow_sensor_eclipse(self, value: bool) -> None:
        """Sets whether accesses where the sensor host is in Earth's shadow are
        permitted.

        Args:
            value: ``True`` to allow host eclipses, ``False`` to reject them.
        """
        ...

    @property
    def minimum_duration(self) -> TimeSpan:
        """Returns the minimum window duration; zero disables the filter."""
        ...

    @minimum_duration.setter
    def minimum_duration(self, value: TimeSpan) -> None:
        """Sets the minimum dwell time required for an access window to be reported.

        Args:
            value: Minimum window duration; zero disables the filter.
        """
        ...


class Satellite:
    """A spacecraft that can be propagated, analysed, and used for event detection.

    A `Satellite` may hold a [`TLE`][keplime.elements.TLE], a
    Cartesian state, or a pre-computed [`Ephemeris`][keplime.elements.Ephemeris].
    The propagator is chosen automatically: SGP4/SDP4 for TLE-backed satellites,
    numerical XP integration otherwise.

    State mutations follow a builder pattern for the ``with_*`` methods
    (which return a new copy) and direct property assignment for mutable
    fields such as `id` and `dry_mass`.

    Attributes:
        id (str): Unique string identifier.
        name (str | None): Optional human-readable name.
        norad_id (int | None): NORAD catalog number, if known.
        tle (TLE | None): Two-Line Element set.
        keplerian_state (KeplerianState | None): Keplerian state derived from
            the TLE or Cartesian state.
        cartesian_state (CartesianState | None): Current Cartesian state in
            TEME [km, km/s].
        ephemeris (Ephemeris | None): Pre-computed ephemeris.
        dry_mass (float): Structural mass without propellant [kg].
        wet_mass (float): Total mass including propellant in all tanks [kg].
        drag_area (float): Effective aerodynamic cross-sectional area [m²].
        drag_coefficient (float): Aerodynamic drag coefficient
            [dimensionless; typically 2.0–2.5].
        srp_area (float): Effective solar-radiation-pressure area [m²].
        srp_coefficient (float): SRP reflectivity coefficient
            [dimensionless; typically 1.0–2.0].
        tanks (list[Tank]): Propellant tanks.
        thrusters (list[Thruster]): Thrusters with tank connections.
        periapsis (float | None): Periapsis altitude above Earth's surface
            [km], or ``None`` if no orbit is defined.
        apoapsis (float | None): Apoapsis altitude above Earth's surface
            [km], or ``None`` if no orbit is defined.
        period (float | None): Orbital period [s], or ``None`` if no orbit
            is defined.
        geodetic_position (GeodeticPosition | None): WGS84 geodetic position
            derived from the current state.
    """

    def __init__(self) -> None:
        """Creates a default Satellite with no orbit, no mass, and a blank ID."""
        ...

    @staticmethod
    def from_tle(tle: TLE) -> Satellite:
        """Creates a Satellite from a Two-Line Element set.

        The satellite `id` is set to the TLE name if non-empty,
        otherwise to the NORAD catalog number string.

        Args:
            tle: Two-Line Element set to initialise the satellite.

        Returns:
            `Satellite` backed by SGP4/SDP4 propagation.
        """
        ...

    @staticmethod
    def from_citra_elset(payload: dict[str, object]) -> Satellite:
        """Creates a Satellite from a CITRA elset dictionary.

        Required keys: ``id``, ``satellite_id``, ``epoch``, ``type``,
        ``semi_major_axis``, ``inclination``, ``raan``, ``eccentricity``,
        ``argument_of_perigee``, ``mean_anomaly``, ``mean_motion_dot``,
        ``mean_motion_dot_dot``, ``b_star``, ``ballistic_coefficient``,
        ``srp_coefficient``.  Optional key: ``satellite_name``.

        Args:
            payload: Dictionary containing the CITRA elset fields.

        Returns:
            `Satellite` initialised from the elset.

        Raises:
            ValueError: If a required key is missing or the epoch string
                cannot be parsed.
        """
        ...

    def with_id(self, id: str) -> Satellite:
        """Returns a copy of this satellite with the given identifier.

        Args:
            id: New unique string identifier.

        Returns:
            `Satellite` with the updated identifier.
        """
        ...

    def with_name(self, name: Optional[str]) -> Satellite:
        """Returns a copy of this satellite with the given name.

        Args:
            name: Human-readable name, or ``None`` to clear it.

        Returns:
            `Satellite` with the updated name.
        """
        ...

    def with_tle(self, tle: TLE) -> Satellite:
        """Returns a copy of this satellite with the given TLE.

        Setting a TLE clears any existing Cartesian state and ephemeris.

        Args:
            tle: Two-Line Element set to assign.

        Returns:
            `Satellite` backed by the new TLE.
        """
        ...

    def with_cartesian_state(self, cartesian_state: CartesianState) -> Satellite:
        """Returns a copy of this satellite with the given Cartesian state.

        Args:
            cartesian_state: State vector in TEME [km, km/s].

        Returns:
            `Satellite` with the updated Cartesian state.
        """
        ...

    def with_ephemeris(self, ephemeris: Ephemeris) -> Satellite:
        """Returns a copy of this satellite with the given pre-computed ephemeris.

        Args:
            ephemeris: Pre-computed ephemeris to assign.

        Returns:
            `Satellite` with the updated ephemeris.
        """
        ...

    def with_dry_mass(self, kg: float) -> Satellite:
        """Returns a copy of this satellite with the given dry mass.

        Args:
            kg: Structural mass without propellant [kg; >= 0].

        Returns:
            `Satellite` with the updated dry mass.
        """
        ...

    def with_tank(self, tank: Tank) -> Satellite:
        """Returns a copy of this satellite with the given tank added.

        Args:
            tank: Propellant tank to add.

        Returns:
            `Satellite` with the tank appended.
        """
        ...

    def with_thruster(self, thruster: Thruster) -> Satellite:
        """Returns a copy of this satellite with the given thruster added.

        Args:
            thruster: Thruster to add.

        Returns:
            `Satellite` with the thruster appended.
        """
        ...

    def with_covariance(self, covariance: CovarianceMatrix) -> Satellite:
        """Returns a copy of this satellite with the given state covariance
        attached.

        State propagation via :meth:`get_state_at_epoch` is unaffected — the
        covariance only participates when :meth:`covariance_at_epoch` is
        called explicitly.

        Args:
            covariance: Covariance to attach. Its ``covariance_type``
                determines how the matrix entries are interpreted (Cartesian
                inertial / Cartesian RIC / equinoctial element-set).

        Returns:
            Satellite with the covariance attached.
        """
        ...

    def covariance_at_epoch(
        self,
        target_epoch: ModifiedJulianDate,
        priority: PerformancePriority | None = None,
    ) -> CovarianceMatrix:
        """Propagates the attached covariance to ``target_epoch``.

        Algorithm selection follows ``PerformancePriority``:

        * ``Speed`` — series-truncated two-body STM. Cheap, accurate only
          for short arcs in near-Keplerian regimes.
        * ``Balanced`` — Van der Merwe scaled Unscented Transform with 13
          sigma points propagated through the configured integrator.
        * ``Precision`` — Monte Carlo with 1000 samples through the
          configured integrator. Gold-standard reference. Significantly
          slower than ``Balanced``; deterministic (fixed PRNG seed).

        ``priority = None`` defers to the priority configured on this
        satellite's integrator.

        Covariance propagation requires :attr:`cartesian_state` to be set
        (it defines the source-epoch reference). SGP4-backed satellites
        should call :meth:`with_cartesian_state` first to pin the initial
        state into the integrator path.

        Args:
            target_epoch: Target propagation epoch.
            priority: Algorithm selector; ``None`` uses the integrator's
                configured priority.

        Returns:
            Propagated covariance at ``target_epoch``. The
            ``covariance_type`` of the result matches the input — RIC in →
            RIC out (re-rotated against the propagated state),
            ``Inertial(F)`` in → ``Inertial(F)`` out.

        Raises:
            ValueError: If no covariance is attached, no
                ``cartesian_state`` is set, propagation fails, or Cholesky
                decomposition of the input covariance fails (UT path
                requires positive-definite input).
        """
        ...

    def clear_ephemeris_cache(self) -> Satellite:
        """Returns a copy of this satellite with the ephemeris cache cleared.

        Returns:
            `Satellite` with no cached ephemeris.
        """
        ...

    def execute_maneuver(
        self, maneuver: Maneuver, thruster: str | None = ...
    ) -> ManeuverResult:
        """Executes an impulsive or finite-burn maneuver.

        Updates the satellite's state in place and returns a summary of the
        burn.

        Args:
            maneuver: Maneuver definition (epoch, delta-v or burn duration).
            thruster: Identifier of the thruster to use, or ``None`` to use
                the first available thruster.

        Returns:
            [`ManeuverResult`][keplime.propagation.ManeuverResult] with pre/post-burn
            states and propellant consumed.

        Raises:
            ValueError: If no orbit is set, the thruster is not found, or
                propagation fails.
        """
        ...

    def get_next_apogee_epoch(self) -> ModifiedJulianDate:
        """Propagates forward to find the next apogee epoch.

        Returns:
            [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] of the next apogee.

        Raises:
            ValueError: If no orbit is set or propagation fails.
        """
        ...

    def get_next_perigee_epoch(self) -> ModifiedJulianDate:
        """Propagates forward to find the next perigee epoch.

        Returns:
            [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] of the next perigee.

        Raises:
            ValueError: If no orbit is set or propagation fails.
        """
        ...

    def get_next_ascending_node_epoch(self) -> ModifiedJulianDate:
        """Propagates forward to find the next ascending node epoch.

        Returns:
            [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] of the next ascending
            node crossing.

        Raises:
            ValueError: If no orbit is set or propagation fails.
        """
        ...

    def get_next_descending_node_epoch(self) -> ModifiedJulianDate:
        """Propagates forward to find the next descending node epoch.

        Returns:
            [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] of the next descending
            node crossing.

        Raises:
            ValueError: If no orbit is set or propagation fails.
        """
        ...

    def get_next_tangent_epoch(self) -> ModifiedJulianDate:
        """Propagates forward to find the next tangent-pass epoch.

        A tangent pass is the moment when the line-of-sight from the satellite
        to a ground observer is tangent to Earth's surface.

        Returns:
            [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] of the next tangent
            pass.

        Raises:
            ValueError: If no orbit is set or propagation fails.
        """
        ...

    def get_next_node_epoch(self) -> ModifiedJulianDate:
        """Propagates forward to find the next equatorial node crossing.

        Returns the earlier of the next ascending or descending node.

        Returns:
            [`ModifiedJulianDate`][keplime.time.ModifiedJulianDate] of the next node.

        Raises:
            ValueError: If no orbit is set or propagation fails.
        """
        ...

    def get_state_at_epoch(
        self, epoch: ModifiedJulianDate, reference_frame: ReferenceFrame | None = ...
    ) -> CartesianState:
        """Propagates the satellite to the given epoch and returns the state.

        Uses SGP4/SDP4 for TLE-backed satellites; uses the numerical XP
        integrator otherwise.  The result frame defaults to TEME.

        Args:
            epoch: Target propagation epoch.
            reference_frame: Output reference frame; defaults to TEME.

        Returns:
            [`CartesianState`][keplime.elements.CartesianState] at the requested epoch
            in the requested frame.

        Raises:
            ValueError: If no orbit is set, the frame transform fails, or
                propagation fails.
        """
        ...

    def cache_ephemeris(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        step: TimeSpan,
        reference_frame: ReferenceFrame | None = ...,
    ) -> Ephemeris:
        """Generates and caches an ephemeris over the specified time window.

        Propagates at each step from ``start`` to ``end`` (inclusive) and
        stores the states for fast lookup.

        Args:
            start: Start of the ephemeris window.
            end: End of the ephemeris window.
            step: Propagation step size.
            reference_frame: Frame for the cached states; defaults to TEME.

        Returns:
            [`Ephemeris`][keplime.elements.Ephemeris] over the requested window.

        Raises:
            ValueError: If no orbit is set, or propagation or frame transform
                fails.
        """
        ...

    def to_tle(self, keplerian_type: KeplerianType) -> TLE:
        """Converts the current state to a Two-Line Element set.

        Args:
            keplerian_type: Averaging theory for the output TLE.

        Returns:
            [`TLE`][keplime.elements.TLE] in the requested element type.

        Raises:
            ValueError: If no state is set or the conversion fails.
        """
        ...

    def get_plot_data(
        self, start: ModifiedJulianDate, end: ModifiedJulianDate, step: TimeSpan
    ) -> Optional[OrbitPlotData]:
        """Generates orbit plot data over a time window.

        Args:
            start: Start of the plot window.
            end: End of the plot window.
            step: Propagation step size.

        Returns:
            [`OrbitPlotData`][keplime.elements.OrbitPlotData] if the satellite has
            an orbit, otherwise ``None``.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_relative_state_at_epoch(
        self, other: Satellite, epoch: ModifiedJulianDate
    ) -> Optional[CartesianState]:
        """Computes the RIC relative state of this satellite with respect to another.

        Equivalent to calling `relative_to` with
        `Rotating`.

        Args:
            other: Reference satellite (origin of the RIC frame).
            epoch: Epoch at which to compute the relative state.

        Returns:
            [`CartesianState`][keplime.elements.CartesianState] in the RIC frame,
            or ``None`` if either satellite has no state at the epoch.

        Raises:
            ValueError: If propagation or frame transform fails.
        """
        ...

    def get_horizon_access_report(
        self,
        observers: list[GeodeticPosition],
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        min_elevation: float,
        min_duration: TimeSpan,
    ) -> Optional[HorizonAccessReport]:
        """Computes horizon access intervals for a set of ground observers.

        Returns all pass windows where the satellite elevation exceeds
        ``min_elevation`` for at least ``min_duration``.

        Args:
            observers: List of ground observer positions.
            start: Start of the search window.
            end: End of the search window.
            min_elevation: Minimum elevation angle [rad; >= 0].
            min_duration: Minimum pass duration.

        Returns:
            [`HorizonAccessReport`][keplime.events.HorizonAccessReport] if any passes
            occur, otherwise ``None``.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_body_angles_at_epoch(
        self, other: Satellite, epoch: ModifiedJulianDate
    ) -> Optional[BoreToBodyAngles]:
        """Computes the boresight-to-body angles between this satellite and another.

        Args:
            other: Target satellite.
            epoch: Epoch at which to compute the angles.

        Returns:
            [`BoreToBodyAngles`][keplime.elements.BoreToBodyAngles] if both states are
            available, otherwise ``None``.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_residuals(self, obs: list[Observation]) -> list[ObservationResidual]:
        """Computes observation residuals against a set of measurements.

        Args:
            obs: List of observations to compute residuals for.

        Returns:
            list[[`ObservationResidual`][keplime.estimation.ObservationResidual]]: One
            residual per observation.

        Raises:
            ValueError: If propagation fails for any observation epoch.
        """
        ...

    def get_rms(self, obs: list[Observation]) -> float:
        """Computes the RMS observation residual.

        Args:
            obs: List of observations to evaluate.

        Returns:
            float: Root-mean-square residual [rad for optical; km for radar].

        Raises:
            ValueError: If propagation fails or the list is empty.
        """
        ...

    def get_weighted_rms(self, obs: list[Observation]) -> float:
        """Computes the noise-weighted RMS observation residual.

        Each residual is divided by the sensor's 1-sigma noise before
        squaring, so the result is dimensionless (number of sigma).

        Args:
            obs: List of observations to evaluate.

        Returns:
            float: Noise-weighted RMS residual [dimensionless; number of σ].

        Raises:
            ValueError: If propagation fails, the list is empty, or any
                observation has no associated noise value.
        """
        ...

    def get_close_approach(
        self,
        other: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
    ) -> Optional[CloseApproach]:
        """Searches for the first close approach to another satellite.

        Args:
            other: The other satellite to check against.
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Maximum range to count as a close approach
                [km; > 0].

        Returns:
            [`CloseApproach`][keplime.events.CloseApproach] if one occurs,
            otherwise ``None``.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_proximity_report(
        self,
        other: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
    ) -> Optional[ProximityReport]:
        """Generates a proximity event report between this satellite and another.

        Records all intervals where the inter-satellite range is within
        ``distance_threshold``.

        Args:
            other: The other satellite to check against.
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Maximum range to count as a proximity event
                [km; > 0].

        Returns:
            [`ProximityReport`][keplime.events.ProximityReport] if any events occur,
            otherwise ``None``.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_maneuver_event(
        self,
        future_sat: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
        velocity_threshold: float,
    ) -> Optional[ManeuverEvent]:
        """Detects whether a maneuver occurred between two ephemeris epochs.

        Compares states from this satellite and ``future_sat`` over
        ``[start, end]``.

        Args:
            future_sat: The satellite representing the post-maneuver state.
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Position difference threshold [km; > 0].
            velocity_threshold: Velocity difference threshold [km/s; > 0].

        Returns:
            [`ManeuverEvent`][keplime.events.ManeuverEvent] if a maneuver is
            detected, otherwise ``None``.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def relative_to(
        self, origin: Satellite, epoch: ModifiedJulianDate, frame: RelativeFrame
    ) -> Optional[CartesianState]:
        """Computes the relative state of this satellite with respect to another.

        Args:
            origin: Reference satellite (origin of the relative frame).
            epoch: Epoch at which to compute the relative state.
            frame: Reference frame for the output
                (`Rotating` or
                `Inertial`).

        Returns:
            [`CartesianState`][keplime.elements.CartesianState] in the requested
            frame, or ``None`` if either satellite has no state at the epoch.

        Raises:
            ValueError: If propagation or frame transform fails.
        """
        ...

    @property
    def id(self) -> str:
        """Returns the unique string identifier [str]."""
        ...

    @id.setter
    def id(self, value: str) -> None:
        """Sets the unique string identifier.

        Args:
            value: New identifier string.
        """
        ...

    @property
    def name(self) -> Optional[str]:
        """Returns the optional human-readable name [str | None]."""
        ...

    @name.setter
    def name(self, value: Optional[str]) -> None:
        """Sets the optional human-readable satellite name.

        Args:
            value: Satellite name, or ``None`` to clear.
        """
        ...

    @property
    def tle(self) -> Optional[TLE]:
        """Returns the Two-Line Element set [TLE | None]."""
        ...

    @tle.setter
    def tle(self, value: Optional[TLE]) -> None:
        """Sets the Two-Line Element set.

        Setting a TLE reinitialises the SGP4 propagator and clears any
        existing ``cartesian_state`` and ``ephemeris``.  Pass ``None`` to
        remove the TLE and disable SGP4 propagation.

        Args:
            value: New TLE, or ``None`` to clear.
        """
        ...

    @property
    def keplerian_state(self) -> Optional[KeplerianState]:
        """Returns the Keplerian state derived from the TLE or Cartesian state.

        Raises:
            ValueError: If the Cartesian-to-Keplerian conversion fails.
        """
        ...

    @property
    def cartesian_state(self) -> Optional[CartesianState]:
        """Returns the current Cartesian state in TEME [km, km/s | None]."""
        ...

    @cartesian_state.setter
    def cartesian_state(self, value: Optional[CartesianState]) -> None:
        """Sets the current Cartesian state in TEME.

        Args:
            value: State vector [km, km/s] in TEME, or ``None`` to clear.
        """
        ...

    @property
    def ephemeris(self) -> Optional[Ephemeris]:
        """Returns the pre-computed ephemeris [Ephemeris | None]."""
        ...

    @ephemeris.setter
    def ephemeris(self, value: Optional[Ephemeris]) -> None:
        """Sets the pre-computed ephemeris.

        Args:
            value: Cached ephemeris, or ``None`` to clear.
        """
        ...

    @property
    def norad_id(self) -> Optional[int]:
        """Returns the NORAD catalog number [int | None]."""
        ...

    @norad_id.setter
    def norad_id(self, value: Optional[int]) -> None:
        """Sets the NORAD catalog number.

        Args:
            value: NORAD catalog number, or ``None`` to clear the direct
                override (the TLE satellite number is still returned as a
                fallback).
        """
        ...

    @property
    def periapsis(self) -> Optional[float]:
        """Returns the periapsis altitude above Earth's surface [km | None]."""
        ...

    @property
    def apoapsis(self) -> Optional[float]:
        """Returns the apoapsis altitude above Earth's surface [km | None]."""
        ...

    @property
    def period(self) -> Optional[float]:
        """Returns the orbital period [s | None]."""
        ...

    @property
    def covariance(self) -> Optional[CovarianceMatrix]:
        """Returns the attached state covariance, or ``None`` if no
        covariance has been set.

        State propagation does **not** touch the covariance; see
        :meth:`covariance_at_epoch` for the opt-in propagation entry point.
        """
        ...

    @property
    def dry_mass(self) -> float:
        """Returns the structural mass without propellant [kg]."""
        ...

    @dry_mass.setter
    def dry_mass(self, value: float) -> None:
        """Sets the structural mass without propellant.

        Args:
            value: Dry mass [kg].
        """
        ...

    @property
    def wet_mass(self) -> float:
        """Returns the total mass including all tank propellant [kg]."""
        ...

    @property
    def drag_area(self) -> float:
        """Returns the effective aerodynamic cross-sectional area [m²]."""
        ...

    @drag_area.setter
    def drag_area(self, value: float) -> None:
        """Sets the effective aerodynamic cross-sectional area.

        Args:
            value: Drag area [m²].
        """
        ...

    @property
    def drag_coefficient(self) -> float:
        """Returns the aerodynamic drag coefficient Cd [dimensionless]."""
        ...

    @drag_coefficient.setter
    def drag_coefficient(self, value: float) -> None:
        """Sets the aerodynamic drag coefficient.

        Args:
            value: Drag coefficient Cd [dimensionless; typically 2.0–2.5].
        """
        ...

    @property
    def srp_area(self) -> float:
        """Returns the effective solar-radiation-pressure area [m²]."""
        ...

    @srp_area.setter
    def srp_area(self, value: float) -> None:
        """Sets the effective solar-radiation-pressure area.

        Args:
            value: SRP area [m²].
        """
        ...

    @property
    def srp_coefficient(self) -> float:
        """Returns the SRP reflectivity coefficient Cr [dimensionless]."""
        ...

    @srp_coefficient.setter
    def srp_coefficient(self, value: float) -> None:
        """Sets the solar-radiation-pressure reflectivity coefficient.

        Args:
            value: SRP coefficient Cr [dimensionless; typically 1.0–2.0].
        """
        ...

    @property
    def geodetic_position(self) -> Optional[GeodeticPosition]:
        """Returns the current WGS84 geodetic position [GeodeticPosition | None].

        Raises:
            ValueError: If the coordinate conversion fails.
        """
        ...

    def characterize_stability(
        self,
        observations: list[Observation],
        min_period: float,
        max_period: float,
        max_fractional_error: float = ...,
        threshold_odds_ratio: float = ...,
    ) -> AttitudeCharacterization:
        """Characterize stability via phase-folding string length.

        Searches a grid of candidate periods, phase-folds the
        lightcurve at each, and scores it by the total Euclidean path
        length around the phase-magnitude loop. The period that
        minimizes the path length is the best fit; reported only when
        it beats a randomized baseline by ``threshold_odds_ratio``.

        Args:
            observations: Photometric observations. Entries without
                ``visual_magnitude`` are dropped.
            min_period: Lower bound of the search [s; > 0].
            max_period: Upper bound of the search [s; >= min_period].
            max_fractional_error: Target relative grid resolution per
                period [dimensionless; > 0]. Defaults to ``0.001``.
            threshold_odds_ratio: Detection threshold; the best string
                length must be no more than ``prior / threshold_odds_ratio``
                for a period to be reported [dimensionless; > 1].
                Defaults to ``2.0``.

        Returns:
            `AttitudeCharacterization` with ``log_odds`` set
            to ``None`` (string-length does not produce a log-odds
            score).
        """
        ...

    def characterize_stability_gregory_loredo(
        self,
        observations: list[Observation],
        min_period: float,
        max_period: float,
        max_fractional_error: float = ...,
        log_odds_threshold: float = ...,
    ) -> AttitudeCharacterization:
        """Characterize stability via the Gregory-Loredo Bayesian
        binned-phase periodogram.

        Marginalizes over phase-bin counts (default ``(2, 12)``) so
        the data picks the model complexity. Rejects ``P/2`` aliases
        on multi-peaked tumblers — a fixed ``m=2`` model would prefer
        the half-period because two flashes per rotation fold onto
        each other.

        Args:
            observations: Photometric observations. Entries without
                ``visual_magnitude`` are dropped.
            min_period: Lower bound of the search [s; > 0].
            max_period: Upper bound of the search [s; >= min_period].
            max_fractional_error: Target relative grid resolution per
                period [dimensionless; > 0]. Defaults to ``0.005``.
            log_odds_threshold: Detection threshold [nats; >= 0]. The
                best log Bayes factor must exceed this to report a
                period (e.g. ``5.0`` ~ 148x more likely than the
                constant-brightness model). Defaults to ``5.0``.

        Returns:
            `AttitudeCharacterization` with ``log_odds``
            populated.
        """
        ...

    def characterize_stability_quasi_periodic_gp(
        self,
        observations: list[Observation],
        min_period: float,
        max_period: float,
        max_fractional_error: float = ...,
        log_odds_threshold: float = ...,
    ) -> AttitudeCharacterization:
        """Characterize stability via the quasi-periodic Gaussian-process
        periodogram.

        Models the lightcurve with a quasi-periodic kernel
        ``k(tau) = sigma_f^2 * exp(-tau^2/(2 L^2)) *
        exp(-2 sin^2(pi tau / P) / lambda^2)`` (MacKay 1998). The
        squared-exponential envelope of length scale ``L`` lets
        correlation decay over time, so a tumbler whose spin rate
        drifts across a campaign isn't unfairly penalized — unlike the
        binned-phase Gregory-Loredo model, which assumes a stationary
        period.

        Hyperparameters are auto-derived from the data. Requires at
        least 10 valid observations.

        Args:
            observations: Photometric observations. Entries without
                ``visual_magnitude`` are dropped.
            min_period: Lower bound of the search [s; > 0].
            max_period: Upper bound of the search [s; >= min_period].
            max_fractional_error: Target relative grid resolution per
                period [dimensionless; > 0]. Defaults to ``0.01``.
            log_odds_threshold: Detection threshold [nats; >= 0]. The
                best QP-GP log marginal likelihood must exceed the
                noise-only baseline by this margin to report a period.
                Defaults to ``5.0``.

        Returns:
            `AttitudeCharacterization` with ``log_odds``
            populated.
        """
        ...

    def get_observation_at_epoch(
        self,
        sensor: Sensor,
        epoch: ModifiedJulianDate,
        observer: GeodeticPosition | None = ...,
        reference_frame: ReferenceFrame | None = ...,
    ) -> Observation:
        """Simulates an observation of this satellite from a sensor at the given epoch.

        Args:
            sensor: Sensor model providing noise parameters and modality.
            epoch: Epoch at which to generate the observation.
            observer: Ground observer location; required for topocentric
                observations (optical / DOA), ignored for space-based.
            reference_frame: Reference frame for propagation; defaults to TEME.

        Returns:
            [`Observation`][keplime.estimation.Observation] with simulated
            measurements.

        Raises:
            ValueError: If no orbit is set, propagation fails, or the sensor
                type is incompatible with the observer configuration.
        """
        ...


class Constellation:
    """A collection of satellites that can be operated on together.

    Supports batch propagation, ephemeris caching, conjunction analysis,
    and observation association.  Implements the Python mapping protocol
    (``[]``, ``in``, ``len``, iteration) keyed by satellite ID string.

    Attributes:
        name (str | None): Optional human-readable constellation name.
        count (int): Number of satellites in the constellation.
        ephemeris_cache_start (ModifiedJulianDate | None): Start of the
            currently cached ephemeris window, or ``None`` if uncached.
        ephemeris_cache_end (ModifiedJulianDate | None): End of the
            currently cached ephemeris window, or ``None`` if uncached.
    """

    def __init__(self, name: Optional[str] = ...) -> None:
        """Creates an empty Constellation.

        Args:
            name: Optional human-readable constellation name.
        """
        ...

    @staticmethod
    def from_tle_catalog(catalog: TLECatalog) -> Constellation:
        """Creates a Constellation from a TLE catalog.

        Each TLE in the catalog becomes a `Satellite` backed by
        SGP4/SDP4 propagation.

        Args:
            catalog: Source TLE catalog.

        Returns:
            `Constellation` with one satellite per catalog entry.
        """
        ...

    @property
    def name(self) -> Optional[str]:
        """Returns the optional constellation name [str | None]."""
        ...

    @name.setter
    def name(self, name: Optional[str]) -> None:
        """Sets the optional constellation name.

        Args:
            name: Constellation name, or ``None`` to clear.
        """
        ...

    def add_satellite(self, satellite_id: str, satellite: Satellite) -> None:
        """Adds a satellite to the constellation.

        If a satellite with the same ``satellite_id`` already exists it is
        replaced.

        Args:
            satellite_id: Unique string key for this satellite.
            satellite: Satellite to add.
        """
        ...

    def get_satellite(self, satellite_id: str) -> Optional[Satellite]:
        """Returns the satellite with the given identifier.

        Args:
            satellite_id: Unique string key to look up.

        Returns:
            `Satellite` if found, otherwise ``None``.
        """
        ...

    def remove_satellite(self, satellite_id: str) -> Optional[Satellite]:
        """Removes and returns the satellite with the given identifier.

        Args:
            satellite_id: Unique string key of the satellite to remove.

        Returns:
            `Satellite` if it existed, otherwise ``None``.
        """
        ...

    def with_ephemeris_cache_range(
        self, start: ModifiedJulianDate, end: ModifiedJulianDate
    ) -> Constellation:
        """Returns a copy of this constellation with the ephemeris cache window set.

        Args:
            start: Start of the desired cache window.
            end: End of the desired cache window.

        Returns:
            `Constellation` with the updated cache window metadata.
        """
        ...

    def cache_ephemeris(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        step: TimeSpan,
        purge_on_fail: bool = ...,
        reference_frame: ReferenceFrame | None = ...,
        device: DevicePreference | None = ...,
    ) -> None:
        """Batch-propagates all satellites and caches their ephemerides.

        If ``purge_on_fail`` is ``True``, satellites that fail to propagate
        are removed from the constellation rather than raising.

        Args:
            start: Start of the ephemeris window.
            end: End of the ephemeris window.
            step: Propagation step size.
            purge_on_fail: If ``True``, remove failing satellites instead of
                raising.  Defaults to ``False``.
            reference_frame: Frame for the cached states; defaults to TEME.
            device: Compute device preference; defaults to CPU.
        """
        ...

    def clear_ephemeris_cache(self) -> None:
        """Clears cached ephemerides for all satellites in the constellation."""
        ...

    def get_horizon_access_report(
        self,
        observers: list[GeodeticPosition],
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        min_elevation: float,
        min_duration: TimeSpan,
    ) -> HorizonAccessReport:
        """Computes horizon access intervals for all satellites against ground observers.

        Args:
            observers: List of ground observer positions.
            start: Start of the search window.
            end: End of the search window.
            min_elevation: Minimum elevation angle [rad; >= 0].
            min_duration: Minimum pass duration.

        Returns:
            [`HorizonAccessReport`][keplime.events.HorizonAccessReport] for the
            constellation.

        Raises:
            ValueError: If propagation fails for any satellite.
        """
        ...

    def get_ca_report_vs_one(
        self,
        other: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
        device: Optional[DevicePreference] = None,
    ) -> CloseApproachReport:
        """Computes close-approach events between the constellation and one satellite.

        Args:
            other: The single satellite to check against.
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Maximum range [km; > 0].
            device: Compute device preference; defaults to CPU.

        Returns:
            [`CloseApproachReport`][keplime.events.CloseApproachReport] for all events.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_ca_report_vs_many(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
        other: Optional[Constellation] = None,
        device: Optional[DevicePreference] = None,
    ) -> CloseApproachReport:
        """Computes close-approach events within the constellation or against another.

        If ``other`` is ``None``, performs intra-constellation analysis.

        Args:
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Maximum range [km; > 0].
            other: Optional second constellation; ``None`` for
                intra-constellation analysis.
            device: Compute device preference; defaults to CPU.

        Returns:
            [`CloseApproachReport`][keplime.events.CloseApproachReport] for all events.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_proximity_report_vs_one(
        self,
        other: Satellite,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
    ) -> ProximityReport:
        """Computes proximity events between the constellation and one satellite.

        Args:
            other: The single satellite to check against.
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Maximum range [km; > 0].

        Returns:
            [`ProximityReport`][keplime.events.ProximityReport] for all intervals.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_proximity_report_vs_many(
        self,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
        other: Optional[Constellation] = None,
        device: Optional[DevicePreference] = None,
    ) -> ProximityReport:
        """Computes proximity events within the constellation or against another.

        If ``other`` is ``None``, performs intra-constellation analysis.

        Args:
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Maximum range [km; > 0].
            other: Optional second constellation; ``None`` for
                intra-constellation analysis.
            device: Compute device preference; defaults to CPU.

        Returns:
            [`ProximityReport`][keplime.events.ProximityReport] for all intervals.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_maneuver_events(
        self,
        future_sats: Constellation,
        start: ModifiedJulianDate,
        end: ModifiedJulianDate,
        distance_threshold: float,
        velocity_threshold: float,
        device: Optional[DevicePreference] = None,
    ) -> ManeuverReport:
        """Detects maneuver events by comparing current and future constellation states.

        Args:
            future_sats: Constellation representing the post-maneuver states.
            start: Start of the search window.
            end: End of the search window.
            distance_threshold: Position difference threshold [km; > 0].
            velocity_threshold: Velocity difference threshold [km/s; > 0].
            device: Compute device preference; defaults to CPU.

        Returns:
            [`ManeuverReport`][keplime.events.ManeuverReport] for all detected events.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def get_states_at_epoch(self, epoch: ModifiedJulianDate) -> dict[str, CartesianState]:
        """Propagates all satellites to the given epoch and returns their states.

        Args:
            epoch: Target epoch for all propagations.

        Returns:
            dict[str, CartesianState]: Mapping from satellite ID to state in
            TEME.

        Raises:
            ValueError: If propagation fails for any satellite.
        """
        ...

    def get_ephemeris(
        self, start: ModifiedJulianDate, end: ModifiedJulianDate, step: TimeSpan
    ) -> dict[str, Ephemeris]:
        """Generates ephemerides for all satellites over a time window.

        Args:
            start: Start of the ephemeris window.
            end: End of the ephemeris window.
            step: Propagation step size.

        Returns:
            dict[str, Ephemeris]: Mapping from satellite ID to ephemeris.

        Raises:
            ValueError: If propagation fails for any satellite.
        """
        ...

    def get_plot_data(
        self, start: ModifiedJulianDate, end: ModifiedJulianDate, step: TimeSpan
    ) -> dict[str, OrbitPlotData]:
        """Generates orbit plot data for all satellites over a time window.

        Args:
            start: Start of the plot window.
            end: End of the plot window.
            step: Propagation step size.

        Returns:
            dict[str, OrbitPlotData]: Mapping from satellite ID to plot data.

        Raises:
            ValueError: If propagation fails for any satellite.
        """
        ...

    def get_association_reports(
        self, collections: list[ObservationCollection]
    ) -> list[CollectionAssociationReport]:
        """Associates observation collections to constellation members.

        Args:
            collections: Observation collections to associate.

        Returns:
            list[[`CollectionAssociationReport`][keplime.estimation.CollectionAssociationReport]]:
            One report per collection.

        Raises:
            ValueError: If propagation fails for any satellite or collection.
        """
        ...

    def get_uct_validity(
        self,
        uct: Satellite,
        all_collections: list[ObservationCollection],
        orphan_collections: list[ObservationCollection],
    ) -> UCTValidityReport:
        """Classifies the physical validity of an uncorrelated track.

        Args:
            uct: Satellite representing the uncorrelated track.
            all_collections: All available observation collections.
            orphan_collections: Collections not yet associated with any
                known object.

        Returns:
            [`UCTValidityReport`][keplime.events.UCTValidityReport] with validity
            classification and supporting evidence.

        Raises:
            ValueError: If propagation fails.
        """
        ...

    def keys(self) -> list[str]:
        """Returns a sorted list of all satellite IDs in the constellation.

        Returns:
            list[str]: Sorted satellite ID strings.
        """
        ...

    def __iter__(self) -> Iterator[str]: ...
    def __len__(self) -> int: ...

    @property
    def count(self) -> int:
        """Returns the number of satellites in the constellation [int]."""
        ...

    def __contains__(self, satellite_id: str) -> bool: ...
    def __setitem__(self, satellite_id: str, satellite: Satellite) -> None: ...
    def __getitem__(self, satellite_id: str) -> Satellite: ...
    def __delitem__(self, satellite_id: str) -> None: ...

    @property
    def ephemeris_cache_start(self) -> Optional[ModifiedJulianDate]:
        """Returns the start of the cached ephemeris window [ModifiedJulianDate | None]."""
        ...

    @property
    def ephemeris_cache_end(self) -> Optional[ModifiedJulianDate]:
        """Returns the end of the cached ephemeris window [ModifiedJulianDate | None]."""
        ...
