# flake8: noqa
from __future__ import annotations

import datetime as _datetime
from typing import overload

from .enums import TimeSystem

class ModifiedJulianDate:
    """A high-precision epoch represented as a Modified Julian Date (MJD).

    The value is stored as a split ``(days, nanoseconds)`` pair to avoid
    floating-point rounding at sub-second resolution.  MJD zero corresponds
    to 1858-11-17T00:00:00.

    Every instance carries an explicit time-system tag (UTC, TAI, TT, UT1,
    TDB, or GPS).  Use `to_system` to convert between systems.

    Attributes:
        days (int): Whole-day MJD component [days since 1858-11-17].
        nanoseconds (int): Intra-day nanosecond component
            [ns; 0..86_400_000_000_000).
        time_system (TimeSystem): Time system of this epoch.
        greenwich_angle (float): Greenwich Mean Sidereal Time (GMST) computed
            on access [rad; 0..2π); requires EOP data.
    """

    def __init__(self, days: int, nanoseconds: int, time_system: TimeSystem) -> None:
        """Creates a ModifiedJulianDate from explicit component parts.

        Args:
            days: Whole-day MJD component [days since 1858-11-17].
            nanoseconds: Intra-day nanosecond component [ns].
            time_system: Time system of the epoch.
        """
        ...

    @staticmethod
    def from_float(mjd: float, time_system: TimeSystem) -> ModifiedJulianDate:
        """Creates a ModifiedJulianDate from a floating-point MJD value.

        The fractional day is rounded to the nearest nanosecond.

        Args:
            mjd: Modified Julian Date [days since 1858-11-17].
            time_system: Time system of the epoch.

        Returns:
            Epoch rounded to nanosecond precision.
        """
        ...

    @staticmethod
    def from_saal_ds50(ds50: float, time_system: TimeSystem) -> ModifiedJulianDate:
        """Creates a ModifiedJulianDate from a Saal / AFSPC days-since-1950 (DS50) epoch.

        DS50 counts days elapsed since 1950-01-00.0 (= 1949-12-31T00:00:00).
        This format appears in TLE data and legacy AFSPC software.

        Args:
            ds50: Days since 1950-01-00.0 [days].
            time_system: Time system of the epoch.

        Returns:
            Epoch rounded to nanosecond precision.
        """
        ...

    @staticmethod
    def from_gps_seconds(gps_seconds: float) -> ModifiedJulianDate:
        """Creates a ModifiedJulianDate from continuous GPS seconds since the GPS epoch.

        The GPS epoch is 1980-01-06T00:00:00 UTC (MJD 44244). GPS time runs
        continuously without leap seconds, so the input is interpreted directly
        in the GPS timescale: the returned value is tagged ``TimeSystem.GPS``
        and conversion to other systems goes through TAI (``TAI = GPS + 19 s``).

        Args:
            gps_seconds: Continuous seconds since the GPS epoch in the GPS
                timescale [s].

        Returns:
            Epoch tagged ``TimeSystem.GPS``, rounded to nanosecond precision.
        """
        ...

    @staticmethod
    def from_datetime(dt: _datetime.datetime) -> ModifiedJulianDate:
        """Creates a ModifiedJulianDate from a timezone-aware ``datetime.datetime``.

        The datetime is converted to UTC via ``astimezone(timezone.utc)`` before
        parsing, so any timezone-aware input is accepted.  Precision is limited to
        microseconds by the ``datetime`` type.

        Args:
            dt: A timezone-aware datetime object.

        Returns:
            Epoch in UTC rounded to microsecond precision.

        Raises:
            TypeError: If ``dt`` is not a ``datetime.datetime`` instance.
            ValueError: If the ISO string produced by ``isoformat()`` cannot be parsed.
        """
        ...

    @staticmethod
    def now() -> ModifiedJulianDate:
        """Returns the current UTC time as a ModifiedJulianDate.

        Precision is limited to microseconds by Python's ``datetime.datetime``.

        Returns:
            Current time in UTC.

        Raises:
            ValueError: If the system clock cannot be converted.
        """
        ...

    @staticmethod
    def from_iso(iso: str) -> ModifiedJulianDate:
        """Parses a ModifiedJulianDate from an ISO 8601 datetime string.

        Supported formats:

        * ``"YYYY-MM-DDTHH:MM:SS[.nnnnnnnnn]Z"`` – parsed as UTC.
        * ``"YYYY-MM-DDTHH:MM:SS[.nnnnnnnnn] <TS>"`` – where ``<TS>`` is one of
          ``UTC``, ``TAI``, ``TT``, ``UT1``, ``TDB``.

        Fractional seconds accept 1–9 digits; shorter strings are zero-padded on
        the right to nanosecond precision.

        Args:
            iso: ISO 8601 datetime string.

        Returns:
            Parsed epoch.

        Raises:
            ValueError: If the string cannot be parsed.
        """
        ...

    def to_datetime(self) -> _datetime.datetime:
        """Converts this epoch to a timezone-aware ``datetime.datetime``.

        Only UTC epochs are supported.  Sub-microsecond precision is truncated
        (not rounded) to fit the ``datetime`` type.

        Returns:
            UTC-aware datetime object.

        Raises:
            ValueError: If the epoch is not in the UTC time system.
        """
        ...

    def to_iso(self) -> str:
        """Formats this epoch as an ISO 8601 datetime string.

        UTC epochs are formatted with a trailing ``Z``; all other time systems
        append the abbreviation (e.g. ``" TAI"``).  The fractional seconds field
        always contains exactly 9 digits (nanosecond precision).

        Returns:
            ISO 8601 string, e.g. ``"2025-04-02T04:02:42.419999926Z"``.
        """
        ...

    def to_system(self, time_system: TimeSystem) -> ModifiedJulianDate:
        """Converts this epoch to a different time system.

        Uses the IERS Finals 2000A table for UTC↔UT1 offsets.

        Args:
            time_system: Target time system.

        Returns:
            A new epoch in ``time_system`` representing the same physical instant.

        Raises:
            ValueError: If the conversion path is unsupported or EOP lookup fails.
        """
        ...

    def to_tdb(self) -> ModifiedJulianDate:
        """Converts this epoch to Barycentric Dynamical Time (TDB).

        Convenience alias for ``to_system(TimeSystem.TDB)``.

        Returns:
            A new epoch in TDB.

        Raises:
            ValueError: If EOP lookup fails.
        """
        ...

    def as_julian_date(self) -> float:
        """Returns the epoch as a Julian Date (JD).

        JD zero is 4713-01-01T12:00:00 UT (proleptic Julian calendar).

        Returns:
            Julian Date [days since JD 0.0].
        """
        ...

    def as_julian_centuries_past_j2000(self) -> float:
        """Returns elapsed Julian centuries since J2000.0.

        J2000.0 is defined as 2000-01-01T12:00:00 TT (MJD 51544.5 TT).

        Returns:
            Elapsed time since J2000.0 [Julian centuries; 1 century = 36 525 days].
            Negative for epochs before J2000.0.
        """
        ...

    @property
    def days(self) -> int:
        """Whole-day MJD component [days since 1858-11-17]."""
        ...

    @property
    def nanoseconds(self) -> int:
        """Intra-day nanosecond component [ns; 0..86_400_000_000_000)."""
        ...

    @property
    def time_system(self) -> TimeSystem:
        """Time system of this epoch."""
        ...

    @property
    def greenwich_angle(self) -> float:
        """Greenwich Mean Sidereal Time (GMST) angle [rad; 0..2π).

        Computed using the IAU 1982 formula (Vallado 2006 §2.6.2).  Requires EOP
        data to be loaded for the UT1 conversion.

        Raises:
            ValueError: If the UT1 conversion or EOP lookup fails.
        """
        ...

    def __add__(self, other: TimeSpan) -> ModifiedJulianDate: ...
    def __radd__(self, other: TimeSpan) -> ModifiedJulianDate: ...
    @overload
    def __sub__(self, other: TimeSpan) -> ModifiedJulianDate: ...
    @overload
    def __sub__(self, other: ModifiedJulianDate) -> TimeSpan: ...
    def __eq__(self, other: object) -> bool: ...
    def __ne__(self, other: object) -> bool: ...
    def __lt__(self, other: ModifiedJulianDate) -> bool: ...
    def __le__(self, other: ModifiedJulianDate) -> bool: ...
    def __gt__(self, other: ModifiedJulianDate) -> bool: ...
    def __ge__(self, other: ModifiedJulianDate) -> bool: ...
    def __hash__(self) -> int: ...
    def __float__(self) -> float: ...
    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...

class TimeSpan:
    """A signed duration with nanosecond precision.

    Stored internally as a ``(days, nanoseconds)`` pair so that sub-second
    arithmetic does not lose precision to floating-point rounding.
    """

    def __init__(self, days: int, nanoseconds: int) -> None:
        """Creates a TimeSpan from explicit days and nanoseconds components.

        Args:
            days: Whole-day component [days]. May be negative.
            nanoseconds: Intra-day nanosecond component [ns].
        """
        ...

    @classmethod
    def from_days(cls, days: float) -> TimeSpan:
        """Creates a TimeSpan from a duration in days.

        Args:
            days: Duration [days]. May be negative.

        Returns:
            A normalized TimeSpan rounded to nanosecond precision.
        """
        ...

    @classmethod
    def from_seconds(cls, seconds: float) -> TimeSpan:
        """Creates a TimeSpan from a duration in seconds.

        Args:
            seconds: Duration [s]. May be negative.

        Returns:
            A normalized TimeSpan rounded to nanosecond precision.
        """
        ...

    @classmethod
    def from_minutes(cls, minutes: float) -> TimeSpan:
        """Creates a TimeSpan from a duration in minutes.

        Args:
            minutes: Duration [min]. May be negative.

        Returns:
            A normalized TimeSpan rounded to nanosecond precision.
        """
        ...

    @classmethod
    def from_hours(cls, hours: float) -> TimeSpan:
        """Creates a TimeSpan from a duration in hours.

        Args:
            hours: Duration [hr]. May be negative.

        Returns:
            A normalized TimeSpan rounded to nanosecond precision.
        """
        ...

    def in_seconds(self) -> float:
        """Returns the total duration as seconds.

        Returns:
            Total duration [s]. Precision degrades for spans exceeding
            roughly ±104 days due to f64 mantissa limits.
        """
        ...

    def in_days(self) -> float:
        """Returns the total duration as days.

        Returns:
            Total duration [days].
        """
        ...

    def in_minutes(self) -> float:
        """Returns the total duration as minutes.

        Returns:
            Total duration [min].
        """
        ...

    def in_hours(self) -> float:
        """Returns the total duration as hours.

        Returns:
            Total duration [hr].
        """
        ...

    def in_centuries(self) -> float:
        """Returns the total duration in Julian centuries (36 525 days each).

        Returns:
            Total duration [Julian centuries].
        """
        ...

    def __repr__(self) -> str: ...
    def __str__(self) -> str: ...
