# flake8: noqa
from __future__ import annotations

from .elements import CartesianState
from .time import ModifiedJulianDate

class AnglesOnlyObservation:
    """A single angles-only observation used as input to `GaussIOD`.

    Carries the observer position together with the observed right-ascension
    and declination to a target body at a given epoch.

    Attributes:
        epoch (ModifiedJulianDate): Epoch of the measurement.
        right_ascension (float): Right ascension of the line-of-sight to
            the target [rad; 0..2π).
        declination (float): Declination of the line-of-sight to the target
            [rad; -π/2..π/2].
        observer_position (list[float]): Inertial observer position
            [km; 3 components].
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        right_ascension: float,
        declination: float,
        observer_position: list[float],
    ) -> None:
        """Creates an angles-only observation.

        Args:
            epoch: Epoch of the measurement.
            right_ascension: Right ascension of the line-of-sight [rad].
            declination: Declination of the line-of-sight [rad].
            observer_position: Inertial observer position [km; 3 components].
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch of the measurement."""
        ...

    @property
    def right_ascension(self) -> float:
        """Right ascension of the line-of-sight [rad; 0..2π)."""
        ...

    @property
    def declination(self) -> float:
        """Declination of the line-of-sight [rad; -π/2..π/2]."""
        ...

    @property
    def observer_position(self) -> list[float]:
        """Inertial observer position [km; 3 components]."""
        ...


class LambertSolution:
    """Solution of Lambert's problem.

    Terminal velocity vectors of the two-body transfer between two known
    position vectors.  Velocities are expressed in the same inertial frame
    as the input states and apply at the corresponding endpoint epochs.

    Attributes:
        v1 (list[float]): Velocity at the departure position [km/s; 3
            components].
        v2 (list[float]): Velocity at the arrival position [km/s; 3
            components].
    """

    @property
    def v1(self) -> list[float]:
        """Velocity at the departure position [km/s; 3 components]."""
        ...

    @property
    def v2(self) -> list[float]:
        """Velocity at the arrival position [km/s; 3 components]."""
        ...


class GaussIOD:
    """Gauss angles-only initial orbit determination.

    Estimates a [`CartesianState`][keplime.elements.CartesianState] at the middle
    observation epoch given exactly three angles-only observations of the
    same target.  Uses the classical Gauss method with iterative refinement
    of the Lagrange ratios via the f and g series.

    The output state is expressed in the TEME frame.  Recovery accuracy
    depends strongly on observation geometry; coplanar line-of-sight vectors
    yield a singular system and raise ``ValueError`` from `solve`.

    Construct with the three observations and the central-body gravitational
    parameter; call `solve` to run the iteration.

    Attributes:
        observations (list[AnglesOnlyObservation]): The three observations
            (mutable; setter validates length).
        mu (float): Central-body gravitational parameter [km³/s²].
        max_iterations (int): Maximum f/g series refinement iterations.
    """

    def __init__(
        self,
        observations: list[AnglesOnlyObservation],
        mu: float,
        max_iterations: int = 50,
    ) -> None:
        """Creates a Gauss IOD solver for three angles-only observations.

        Args:
            observations: Exactly three observations of the same target,
                in time order.
            mu: Central-body gravitational parameter [km³/s²].
            max_iterations: Maximum f/g series refinement iterations.

        Raises:
            ValueError: If ``observations`` does not have length 3.
        """
        ...

    def solve(self) -> CartesianState:
        """Runs the Gauss IOD iteration.

        Returns:
            CartesianState: Estimated state at the middle observation epoch
            [position in km, velocity in km/s, TEME frame].

        Raises:
            ValueError: If ``mu`` is non-positive, observation epochs are
                not distinct, the line-of-sight vectors are coplanar, or
                the f/g series fails to produce a finite estimate.
        """
        ...

    @property
    def observations(self) -> list[AnglesOnlyObservation]:
        """The three observations supplied at construction."""
        ...

    @observations.setter
    def observations(self, value: list[AnglesOnlyObservation]) -> None: ...

    @property
    def mu(self) -> float:
        """Central-body gravitational parameter [km³/s²]."""
        ...

    @mu.setter
    def mu(self, value: float) -> None: ...

    @property
    def max_iterations(self) -> int:
        """Maximum f/g series refinement iterations."""
        ...

    @max_iterations.setter
    def max_iterations(self, value: int) -> None: ...


class HerrickGibbsIOD:
    """Herrick–Gibbs initial orbit determination from three position states.

    Estimates a [`CartesianState`][keplime.elements.CartesianState] at the middle
    state's epoch given three position-bearing
    [`CartesianState`][keplime.elements.CartesianState] inputs.  The method is
    O(Δt⁴) accurate for two-body motion and is best suited to closely
    spaced (small angular separation) observations.

    Only the ``position`` and ``epoch`` of each input state are read;
    ``velocity`` may be ``None``.  The output state is expressed in the
    TEME frame.

    Construct with the three states and the central-body gravitational
    parameter; call `solve` to compute the velocity at the middle
    epoch.

    Attributes:
        states (list[CartesianState]): The three position states (mutable;
            setter validates length).
        mu (float): Central-body gravitational parameter [km³/s²].
    """

    def __init__(self, states: list[CartesianState], mu: float) -> None:
        """Creates a Herrick–Gibbs IOD solver for three position states.

        Args:
            states: Exactly three position-bearing states of the same
                target, in time order.  Velocities may be ``None`` — only
                ``position`` and ``epoch`` are used.
            mu: Central-body gravitational parameter [km³/s²].

        Raises:
            ValueError: If ``states`` does not have length 3.
        """
        ...

    def solve(self) -> CartesianState:
        """Runs the Herrick–Gibbs estimator.

        Returns:
            CartesianState: State at the middle input epoch with the
            Herrick–Gibbs velocity estimate
            [position in km, velocity in km/s, TEME frame].

        Raises:
            ValueError: If ``mu`` is non-positive, any input position is
                near-zero, the three positions are not sufficiently
                coplanar, or the input epochs are not distinct.
        """
        ...

    @property
    def states(self) -> list[CartesianState]:
        """The three input states supplied at construction."""
        ...

    @states.setter
    def states(self, value: list[CartesianState]) -> None: ...

    @property
    def mu(self) -> float:
        """Central-body gravitational parameter [km³/s²]."""
        ...

    @mu.setter
    def mu(self, value: float) -> None: ...


class LambertIOD:
    """Lambert two-body boundary value problem solver.

    Given two [`CartesianState`][keplime.elements.CartesianState] boundary points
    with known positions and epochs, computes the departure and arrival
    velocity vectors of the connecting two-body trajectory.  Uses the
    universal-variable formulation from Vallado, *Fundamentals of
    Astrodynamics and Applications*.

    Time of flight is derived as ``state_2.epoch − state_1.epoch`` and
    must be strictly positive.  Only the ``position`` and ``epoch`` of
    each input state are read; ``velocity`` may be ``None``.

    Construct with the two endpoint states, the central-body gravitational
    parameter, and the direction-of-motion flag; call `solve` to
    obtain the `LambertSolution`.

    Attributes:
        state_1 (CartesianState): Departure state (position + epoch).
        state_2 (CartesianState): Arrival state (position + epoch).
        mu (float): Central-body gravitational parameter [km³/s²].
        prograde (bool): If ``True``, select the prograde
            (counter-clockwise about +Z) branch of the transfer; otherwise
            retrograde.
        max_iterations (int): Maximum Newton–Raphson iterations on the
            universal variable.
    """

    def __init__(
        self,
        state_1: CartesianState,
        state_2: CartesianState,
        mu: float,
        prograde: bool,
        max_iterations: int = 100,
    ) -> None:
        """Creates a Lambert solver between two boundary states.

        Args:
            state_1: Departure state.  Only ``position`` and ``epoch`` are
                read; ``velocity`` may be ``None``.
            state_2: Arrival state.  Only ``position`` and ``epoch`` are
                read; ``velocity`` may be ``None``.
            mu: Central-body gravitational parameter [km³/s²].
            prograde: If ``True``, choose the prograde branch.
            max_iterations: Maximum Newton–Raphson iterations on the
                universal variable.
        """
        ...

    def solve(self) -> LambertSolution:
        """Runs the Lambert solver.

        Returns:
            LambertSolution: Departure (``v1``) and arrival (``v2``)
            velocity vectors [km/s; 3 components each].

        Raises:
            ValueError: If the time of flight is non-positive, ``mu`` is
                non-positive, either input position is near zero, the
                transfer angle is 0 or 180 degrees, or the universal
                variable iteration fails to converge.
        """
        ...

    @property
    def state_1(self) -> CartesianState:
        """Departure state."""
        ...

    @state_1.setter
    def state_1(self, value: CartesianState) -> None: ...

    @property
    def state_2(self) -> CartesianState:
        """Arrival state."""
        ...

    @state_2.setter
    def state_2(self, value: CartesianState) -> None: ...

    @property
    def mu(self) -> float:
        """Central-body gravitational parameter [km³/s²]."""
        ...

    @mu.setter
    def mu(self, value: float) -> None: ...

    @property
    def prograde(self) -> bool:
        """Prograde (``True``) vs retrograde (``False``) branch flag."""
        ...

    @prograde.setter
    def prograde(self, value: bool) -> None: ...

    @property
    def max_iterations(self) -> int:
        """Maximum Newton–Raphson iterations on the universal variable."""
        ...

    @max_iterations.setter
    def max_iterations(self, value: int) -> None: ...
