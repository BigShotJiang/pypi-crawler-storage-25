# flake8: noqa
from __future__ import annotations

from .bodies import Constellation, Satellite, Sensor
from .elements import CartesianState, CartesianVector, TopocentricState
from .enums import AssociationConfidence, CovarianceType, KeplerianType, OrbitDeterminationQuality, ReferenceFrame
from .time import ModifiedJulianDate, TimeSpan


class SignalMeasurement:
    """Bistatic / passive-RF signal measurement attached to an observation.

    Carries the second sensor location together with the time-difference-of-arrival
    (TDOA) and optional frequency-difference-of-arrival (FDOA) used for
    multi-static geolocation. Presence of a `SignalMeasurement` on an
    `Observation` triggers the bistatic-residual code path in
    `get_residual`.

    Attributes:
        second_origin_state (CartesianState): Inertial state of the second sensor
            at the measurement epoch [km, km/s].
        tdoa (float): Time-difference-of-arrival (path 2 minus path 1) [s].
        fdoa (float | None): Frequency-difference-of-arrival [Hz]. ``None`` when
            the system did not measure FDOA.
        transmission_frequency (float | None): Carrier frequency of the emitter
            [Hz], required to convert FDOA to a range-rate residual.
    """

    def __init__(
        self,
        second_origin_state: CartesianState,
        tdoa: float,
        fdoa: float | None = ...,
        transmission_frequency: float | None = ...,
    ) -> None:
        """Creates a SignalMeasurement.

        Args:
            second_origin_state: Inertial state of the second sensor at the
                measurement epoch [km, km/s].
            tdoa: Time-difference-of-arrival (path 2 minus path 1) [s].
            fdoa: Frequency-difference-of-arrival [Hz]. Optional.
            transmission_frequency: Carrier frequency of the emitter [Hz].
                Required to convert FDOA into a range-rate residual.
        """
        ...

    @property
    def second_origin_state(self) -> CartesianState:
        """Inertial state of the second sensor at the measurement epoch
        [km, km/s]."""
        ...

    @property
    def tdoa(self) -> float:
        """Time-difference-of-arrival (path 2 minus path 1) [s]."""
        ...

    @property
    def fdoa(self) -> float | None:
        """Frequency-difference-of-arrival [Hz], or ``None``."""
        ...

    @property
    def transmission_frequency(self) -> float | None:
        """Carrier frequency of the emitter [Hz], or ``None``."""
        ...


class Covariance:
    """Lightweight diagonal-only covariance description.

    Stores per-element 1-σ standard deviations together with the frame
    convention used to interpret them. For full off-diagonal covariance use
    `CovarianceMatrix` instead.

    Attributes:
        sigmas (list[float]): Per-element 1-σ standard deviations. Units depend
            on ``covariance_type``: ``Relative`` / ``Inertial`` Cartesian use
            [km] for position elements and [km/s] for velocity elements;
            ``Equinoctial`` uses [km] for the semi-major-axis element and
            [dimensionless] or [rad] for the remaining equinoctial elements.
        covariance_type (CovarianceType): Frame and parameterization the
            sigmas are expressed in.
    """

    def __init__(
        self,
        sigmas: list[float] | None = ...,
        covariance_type: CovarianceType | None = ...,
    ) -> None:
        """Creates a Covariance from per-element sigmas.

        Args:
            sigmas: Per-element 1-σ standard deviations. Defaults to an empty
                list when omitted.
            covariance_type: Frame and parameterization the sigmas are
                expressed in. Defaults to ``CovarianceType.Relative`` when
                omitted.
        """
        ...

    @property
    def sigmas(self) -> list[float]:
        """Per-element 1-σ standard deviations. Units depend on
        `covariance_type`."""
        ...

    @property
    def covariance_type(self) -> CovarianceType:
        """Frame and parameterization the sigmas are expressed in."""
        ...


class Observation:
    """A single sensor observation of a space object.

    An observation pairs a `Sensor` with a `TopocentricState`
    that captures epoch, observer location, and any subset of measured
    quantities (right ascension, declination, range, range-rate, angle rates).
    Optional `SignalMeasurement` payloads carry TDOA/FDOA pairs for
    bistatic geometries. Observations are the primary input to
    `BatchLeastSquares`, `ExtendedKalmanFilter`, and
    `UnscentedKalmanFilter`.

    Attributes:
        id (str): Unique identifier (UUID4 by default) used to identify
            rejected residuals in the BLS report.
        sensor (Sensor): Sensor that produced the observation, including
            measurement-noise sigmas used to weight residuals.
        epoch (ModifiedJulianDate): Observation epoch (read from
            ``topocentric_state``).
        topocentric_state (TopocentricState): Observer location and observed
            elements (RA/Dec [rad], range [km], range-rate [km/s], angle rates
            [rad/s]).
        signal_measurement (SignalMeasurement | None): Optional bistatic /
            DOA payload.
        observed_satellite_id (str | None): Optional truth-association tag
            propagated into the residual when the observation came from a
            tagged catalog.
        tdoa (float | None): Convenience accessor for
            ``signal_measurement.tdoa`` [s].
        fdoa (float | None): Convenience accessor for
            ``signal_measurement.fdoa`` [Hz].
        visual_magnitude (float | None): Optional measured visual magnitude
            [mag]. Used by the photometric residual computations.
        phase_angle (float | None): Sun-target-observer phase angle [rad],
            computed on demand. ``None`` when geometry information is absent.
    """

    def __init__(self, sensor: Sensor, topocentric_state: TopocentricState) -> None:
        """Creates an Observation from a sensor and topocentric state.

        The new observation receives a fresh UUID4 ``id`` and no signal
        measurement.

        Args:
            sensor: Sensor that produced the measurement.
            topocentric_state: Observer location and observed angle/range
                elements.
        """
        ...

    @staticmethod
    def from_citra_optical_observation(payload: dict[str, object]) -> Observation:
        """Builds an Observation from a CITRA optical-observation record.

        Sensor latitude and longitude are read in degrees and converted to
        radians internally; right ascension, declination, and angle-rate noise
        fields likewise convert from degrees to radians.

        Args:
            payload: Mapping with the CITRA optical schema fields (``id``,
                ``telescope_id``, ``epoch``, ``right_ascension``,
                ``declination``, ``angular_noise``, sensor latitude/longitude/
                altitude, optional rate fields).

        Returns:
            Optical observation in the TEME frame.

        Raises:
            ValueError: If required fields are missing or the epoch fails to
                parse.
        """
        ...

    @staticmethod
    def from_citra_radar_observation(payload: dict[str, object]) -> Observation:
        """Builds an Observation from a CITRA radar-observation record.

        When all three secondary-sensor coordinates are present the observation
        is treated as bistatic and a `SignalMeasurement` is attached;
        the ``range`` field is then interpreted as the bistatic path length
        ``ρ₁ + ρ₂``.

        Args:
            payload: Mapping with the CITRA radar schema fields (``id``,
                ``antenna_id``, ``epoch``, optional ``range`` [km] /
                ``range_rate`` [km/s], optional angles, sensor location).

        Returns:
            Radar (mono- or bistatic) observation in the TEME frame.

        Raises:
            ValueError: If required fields are missing or the epoch fails to
                parse.
        """
        ...

    @staticmethod
    def from_citra_doa_observation(payload: dict[str, object]) -> Observation:
        """Builds an Observation from a CITRA DOA (TDOA/FDOA) record.

        The resulting observation has no angle elements; only the
        `SignalMeasurement` payload (TDOA [s], optional FDOA [Hz]).

        Args:
            payload: Mapping with the CITRA DOA schema fields (``id``,
                primary/secondary antenna ids, ``epoch``, ``tdoa`` [s],
                ``tdoa_noise`` [s], optional ``fdoa`` [Hz], primary/secondary
                sensor lat/lon/alt).

        Returns:
            DOA observation in the TEME frame.

        Raises:
            ValueError: If required fields are missing or the epoch fails to
                parse.
        """
        ...

    def with_signal_measurement(
        self, signal_measurement: SignalMeasurement | None
    ) -> Observation:
        """Returns a copy with the signal-measurement payload replaced.

        Args:
            signal_measurement: Bistatic / DOA payload, or ``None`` to clear.

        Returns:
            New observation with ``signal_measurement`` replaced.
        """
        ...

    def with_tdoa(self, tdoa: float | None) -> Observation:
        """Returns a copy with the TDOA component of the signal measurement
        replaced.

        Args:
            tdoa: New time-difference-of-arrival [s], or ``None`` to clear.

        Returns:
            New observation with the updated TDOA value.
        """
        ...

    def with_fdoa(self, fdoa: float | None) -> Observation:
        """Returns a copy with the FDOA component of the signal measurement
        replaced.

        Args:
            fdoa: New frequency-difference-of-arrival [Hz], or ``None`` to
                clear.

        Returns:
            New observation with the updated FDOA value.
        """
        ...

    @property
    def sensor(self) -> Sensor:
        """Sensor that produced the observation."""
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Observation epoch."""
        ...

    @property
    def topocentric_state(self) -> TopocentricState:
        """Observer location and observed elements (RA/Dec [rad], range [km],
        range-rate [km/s])."""
        ...

    @property
    def id(self) -> str:
        """Unique identifier (UUID4 by default)."""
        ...

    @id.setter
    def id(self, value: str) -> None: ...

    @property
    def signal_measurement(self) -> SignalMeasurement | None:
        """Optional bistatic / DOA signal payload."""
        ...

    @property
    def observed_satellite_id(self) -> str | None:
        """Optional truth-association tag of the observed object."""
        ...

    @observed_satellite_id.setter
    def observed_satellite_id(self, value: str | None) -> None: ...

    @property
    def tdoa(self) -> float | None:
        """Convenience accessor for ``signal_measurement.tdoa`` [s]."""
        ...

    @property
    def fdoa(self) -> float | None:
        """Convenience accessor for ``signal_measurement.fdoa`` [Hz]."""
        ...

    @property
    def visual_magnitude(self) -> float | None:
        """Measured visual magnitude [mag], or ``None``."""
        ...

    @visual_magnitude.setter
    def visual_magnitude(self, value: float | None) -> None: ...

    def with_visual_magnitude(self, vismag: float | None) -> Observation:
        """Returns a copy with the visual magnitude replaced.

        Args:
            vismag: Visual magnitude [mag], or ``None`` to clear.

        Returns:
            New observation with the updated visual magnitude.
        """
        ...

    @property
    def phase_angle(self) -> float | None:
        """Sun-target-observer phase angle [rad; 0..π], computed on demand.

        ``None`` when the geometry needed to compute the phase angle is
        unavailable (e.g., missing topocentric direction)."""
        ...

    def get_residual(self, sat: Satellite) -> ObservationResidual | None:
        """Computes the observed-minus-expected residual against a satellite.

        Propagates ``sat`` to `epoch` in TEME and forms the residual
        from the predicted topocentric state. ``None`` when the observation
        cannot be projected against the given satellite (e.g., line of sight
        below the horizon for an angles-only optical observation).

        Args:
            sat: Candidate satellite to evaluate against.

        Returns:
            Populated residual, or ``None``.

        Raises:
            ValueError: If satellite propagation fails.
        """
        ...

    def get_associations(self, sats: Constellation) -> list[ObservationAssociation]:
        """Returns the candidate associations of this observation against a
        constellation.

        Internally evaluates `get_residual` for every member and keeps
        the candidates whose residuals fall inside the per-confidence-level
        gates configured on the sensor.

        Args:
            sats: Catalog of candidate satellites.

        Returns:
            All candidate associations sorted strongest-first.

        Raises:
            ValueError: If propagation fails for any catalog member.
        """
        ...


class ObservationResidual:
    """Observed-minus-expected residual in topocentric and orbit-relative frames.

    The residual carries both raw topocentric deltas (RA/Dec/range/range-rate)
    and a derived orbit-relative ("RIC") closure expressed in radial /
    in-track / cross-track components, so downstream consumers (BLS, Kalman
    filter, association report) can pick whichever projection they need.

    Attributes:
        epoch (ModifiedJulianDate): Epoch the residual is evaluated at.
        cross_line_of_sight (float): Cross-line-of-sight closure magnitude
            [km; ≥ 0]. For angle-only observations this is the magnitude of the
            relative position vector between the observed line of sight
            (extended to the expected slant range) and the expected satellite
            position.
        time (float): Along-track time offset [s].
        radial (float): Radial position component [km].
        in_track (float): In-track position component [km].
        cross_track (float): Cross-track position component [km].
        velocity (float): Relative velocity magnitude [km/s; ≥ 0].
        radial_velocity (float): Radial velocity component [km/s].
        in_track_velocity (float): In-track velocity component [km/s].
        cross_track_velocity (float): Cross-track velocity component [km/s].
        beta (float): Cross-track beta angle [rad].
        height (float): Height residual [km].
        range (float | None): Observed-minus-expected range [km].
        right_ascension (float | None): Observed-minus-expected right
            ascension [rad; wrapped to (-π, π]].
        declination (float | None): Observed-minus-expected declination [rad].
        range_rate (float | None): Observed-minus-expected range-rate [km/s].
        right_ascension_rate (float | None): Observed-minus-expected right
            ascension rate [rad/s].
        declination_rate (float | None): Observed-minus-expected declination
            rate [rad/s].
        tdoa (float | None): Observed-minus-expected time-difference-of-arrival
            [s].
        fdoa (float | None): Observed-minus-expected
            frequency-difference-of-arrival [Hz].
        angle (float | None): Great-circle angular separation between observed
            and expected pointing [rad; ≥ 0]. ``None`` when the observation
            lacks RA or Dec.
        angular_rate (float | None): Magnitude of the angular-rate residual
            with the standard ``cos(dec)`` scaling on the right-ascension-rate
            component [rad/s; ≥ 0]. ``None`` when the observation lacks an
            angle-rate measurement.
    """

    def __init__(
        self,
        epoch: ModifiedJulianDate,
        cross_line_of_sight: float,
        time: float,
        radial: float,
        in_track: float,
        cross_track: float,
        velocity: float,
        radial_velocity: float,
        in_track_velocity: float,
        cross_track_velocity: float,
        beta: float,
        height: float,
    ) -> None:
        """Creates an ObservationResidual from the orbit-relative components.

        Optional measurement-frame residuals (RA/Dec/range/...) start as
        ``None`` and are populated separately by the residual builder.

        Args:
            epoch: Epoch the residual is evaluated at.
            cross_line_of_sight: Cross-line-of-sight closure magnitude
                [km; ≥ 0].
            time: Along-track time offset [s].
            radial: Radial position component [km].
            in_track: In-track position component [km].
            cross_track: Cross-track position component [km].
            velocity: Relative velocity magnitude [km/s; ≥ 0].
            radial_velocity: Radial velocity component [km/s].
            in_track_velocity: In-track velocity component [km/s].
            cross_track_velocity: Cross-track velocity component [km/s].
            beta: Cross-track beta angle [rad].
            height: Height residual [km].
        """
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Epoch the residual is evaluated at."""
        ...

    @property
    def range(self) -> float | None:
        """Observed-minus-expected range [km]."""
        ...

    @property
    def cross_line_of_sight(self) -> float:
        """Cross-line-of-sight closure magnitude [km; ≥ 0].

        For angle-only observations this is the magnitude of the relative
        position vector between the observed line of sight (extended to the
        expected slant range) and the expected satellite position.
        """
        ...

    @property
    def right_ascension(self) -> float | None:
        """Observed-minus-expected right ascension [rad; wrapped to (-π, π]]."""
        ...

    @property
    def declination(self) -> float | None:
        """Observed-minus-expected declination [rad]."""
        ...

    @property
    def range_rate(self) -> float | None:
        """Observed-minus-expected range-rate [km/s]."""
        ...

    @property
    def right_ascension_rate(self) -> float | None:
        """Observed-minus-expected right ascension rate [rad/s]."""
        ...

    @property
    def declination_rate(self) -> float | None:
        """Observed-minus-expected declination rate [rad/s]."""
        ...

    @property
    def tdoa(self) -> float | None:
        """Observed-minus-expected time-difference-of-arrival [s]."""
        ...

    @property
    def fdoa(self) -> float | None:
        """Observed-minus-expected frequency-difference-of-arrival [Hz]."""
        ...

    @property
    def angle(self) -> float | None:
        """Great-circle angular separation between observed and expected
        pointing [rad; ≥ 0]. ``None`` when the observation lacks RA or Dec."""
        ...

    @property
    def angular_rate(self) -> float | None:
        """Magnitude of the angular-rate residual with the standard
        ``cos(dec)`` scaling on the right-ascension-rate component [rad/s;
        ≥ 0]. ``None`` when the observation lacks an angle-rate measurement."""
        ...

    @property
    def time(self) -> float:
        """Along-track time offset [s]."""
        ...

    @property
    def radial(self) -> float:
        """Radial position component [km]."""
        ...

    @property
    def in_track(self) -> float:
        """In-track position component [km]."""
        ...

    @property
    def cross_track(self) -> float:
        """Cross-track position component [km]."""
        ...

    @property
    def velocity(self) -> float:
        """Relative velocity magnitude [km/s; ≥ 0]."""
        ...

    @property
    def radial_velocity(self) -> float:
        """Radial velocity component [km/s]."""
        ...

    @property
    def in_track_velocity(self) -> float:
        """In-track velocity component [km/s]."""
        ...

    @property
    def cross_track_velocity(self) -> float:
        """Cross-track velocity component [km/s]."""
        ...

    @property
    def beta(self) -> float:
        """Cross-track beta angle [rad]."""
        ...

    @property
    def height(self) -> float:
        """Height residual [km]."""
        ...


class ObservationAssociation:
    """Association between an observation and a candidate satellite.

    Produced by `get_associations` and
    `get_association_report`. Carries the
    residual that drove the gate-pass plus the discrete confidence level
    assigned by the sensor's noise model.

    Attributes:
        observation_id (str): Identifier of the source observation.
        satellite_id (str): Identifier of the associated satellite.
        residual (ObservationResidual): Residual evaluated for this pairing.
        confidence (AssociationConfidence): Discrete association confidence
            level (None / Low / Medium / High).
    """

    def __init__(
        self,
        observation_id: str,
        satellite_id: str,
        residual: ObservationResidual,
        confidence: AssociationConfidence,
    ) -> None:
        """Creates an ObservationAssociation.

        Args:
            observation_id: Identifier of the source observation.
            satellite_id: Identifier of the associated satellite.
            residual: Residual evaluated for this pairing.
            confidence: Discrete association confidence level.
        """
        ...

    @property
    def observation_id(self) -> str:
        """Identifier of the source observation."""
        ...

    @property
    def satellite_id(self) -> str:
        """Identifier of the associated satellite."""
        ...

    @property
    def residual(self) -> ObservationResidual:
        """Residual evaluated for this pairing."""
        ...

    @property
    def confidence(self) -> AssociationConfidence:
        """Discrete association confidence level."""
        ...


class CollectionAssociationReport:
    """Result of associating a single `ObservationCollection` against
    a constellation.

    Attributes:
        orphan_observations (list[Observation]): Observations from the
            collection that did not associate with any catalog member.
        associations (list[ObservationAssociation]): All gate-passing
            associations, including duplicates when multiple satellites match
            a single observation.
        moving_satellite_ids (list[str]): Identifiers of catalog satellites
            whose predicted state moved across the collection's field of view
            during the epoch (used for streak detection).
    """

    @property
    def orphan_observations(self) -> list[Observation]:
        """Observations that did not associate with any catalog member."""
        ...

    @property
    def associations(self) -> list[ObservationAssociation]:
        """All gate-passing associations."""
        ...

    @property
    def moving_satellite_ids(self) -> list[str]:
        """Identifiers of catalog satellites that moved across the field of
        view during the collection epoch."""
        ...


class ObservationCollection:
    """A group of observations sharing one epoch, sensor, and observer
    location.

    The constructor enforces this invariant: every observation must share
    exactly the same `epoch`, `id`, and observer
    position. The aggregate boresight direction and field-of-view diameter are
    derived from the spread of observed line-of-sight vectors.

    Attributes:
        sensor_position (CartesianVector): Inertial position of the sensor at
            the collection epoch [km].
        sensor_direction (CartesianVector): Unit vector of the mean boresight
            across the collection [dimensionless].
        field_of_view (float): Twice the maximum angular distance from any
            observation's line of sight to `sensor_direction` [rad].
        observations (list[Observation]): Observations in the collection.
        epoch (ModifiedJulianDate): Shared epoch of all observations.
    """

    def __init__(self, observations: list[Observation]) -> None:
        """Creates an ObservationCollection.

        Args:
            observations: Observations to group. Must be non-empty and share
                a single epoch, sensor id, and observer position.

        Raises:
            ValueError: If the list is empty or any observation violates the
                shared-epoch / shared-sensor / shared-position invariant.
        """
        ...

    @staticmethod
    def get_list(observations: list[Observation]) -> list[ObservationCollection]:
        """Groups a flat list of observations into collections by
        ``(epoch, sensor_id)``.

        Observations whose grouping fails the collection invariant (e.g.,
        differing observer positions for the same sensor id) are silently
        dropped; this is intended for converting a heterogeneous CITRA dump
        into an iterable of well-formed collections.

        Args:
            observations: Mixed observations.

        Returns:
            One `ObservationCollection` per ``(epoch, sensor_id)``
            group that satisfied the invariant.
        """
        ...

    def get_association_report(
        self, satellites: Constellation
    ) -> CollectionAssociationReport:
        """Associates this collection against a constellation.

        Args:
            satellites: Catalog of candidate satellites.

        Returns:
            Per-collection report of orphan observations and associations.

        Raises:
            ValueError: If the constellation argument is missing or
                propagation of any catalog member fails.
        """
        ...

    def get_visibility(self, satellite: Satellite) -> bool:
        """Checks whether a satellite is geometrically inside the collection's
        field of view at `epoch`.

        Args:
            satellite: Candidate satellite.

        Returns:
            ``True`` when the satellite's predicted line of sight from
            `sensor_position` falls within
            `field_of_view` / 2 of `sensor_direction`.
        """
        ...

    def get_association(self, satellite: Satellite) -> ObservationAssociation | None:
        """Returns the strongest association of this collection with a single
        satellite.

        Args:
            satellite: Candidate satellite.

        Returns:
            Strongest gate-passing association, or ``None`` when no
            observation in the collection associates with ``satellite``.

        Raises:
            ValueError: If propagation of ``satellite`` fails.
        """
        ...

    @property
    def sensor_position(self) -> CartesianVector:
        """Inertial position of the sensor at the collection epoch [km]."""
        ...

    @property
    def sensor_direction(self) -> CartesianVector:
        """Unit vector of the mean boresight across the collection
        [dimensionless]."""
        ...

    @property
    def field_of_view(self) -> float:
        """Twice the maximum angular distance from any observation's line of
        sight to `sensor_direction` [rad]."""
        ...

    @property
    def observations(self) -> list[Observation]:
        """Observations in the collection."""
        ...

    @property
    def epoch(self) -> ModifiedJulianDate:
        """Shared epoch of all observations."""
        ...


class OrbitDeterminationReport:
    """Quality summary produced after a `BatchLeastSquares` solve.

    The metrics are computed from the post-fit residuals, the post-fit
    covariance, and a single propagation pass over the fit observations. The
    overall `quality` label is computed from a fixed ruleset over the
    individual metrics; see `OrbitDeterminationQuality`.

    Attributes:
        coverage (float): Fraction of 24 mean-anomaly bins (15° wide) covered
            by the fit observations [dimensionless; 0..1].
        periods (float): Span of the fit window expressed in orbital periods
            [dimensionless; ≥ 0].
        number_of_sensors (int): Count of distinct sensor ids that contributed
            observations to the fit.
        number_of_phenomenologies (int): Count of distinct measurement
            phenomenologies (range / angles-only / TDOA) used in the fit
            [dimensionless; 0..3].
        position_sigma (float): Trace-RSS position sigma from the post-fit
            covariance, in the RIC frame [km; ≥ 0].
        velocity_sigma (float): Trace-RSS velocity sigma from the post-fit
            covariance, in the RIC frame [km/s; ≥ 0].
        geometry (float): Sensor-to-target geometric diversity expressed as a
            ``2·atan(s_mid / s_max)`` mapping of the mid/max singular values
            of the line-of-sight matrix [deg; 0..90].
        rms (float | None): Unweighted RMS of the dominant residual component
            (range when present, else cross-line-of-sight) [km; ≥ 0]. ``None``
            when no residuals are available.
        weighted_rms (float | None): Weighted RMS in measurement-sigma units
            [dimensionless; ≥ 0]. ``None`` when the solver has not yet built a
            weighted residual.
        converged (bool): Whether the solver reported convergence.
        residual_trend_r_squared (float): R² of a linear fit of the dominant
            residual component versus epoch [dimensionless; 0..1]. Used to
            flag systematic post-fit drift.
        quality (OrbitDeterminationQuality): Discrete overall quality label
            (Low / Medium / High).
    """

    @property
    def coverage(self) -> float:
        """Fraction of the 24 mean-anomaly bins covered by the fit
        [dimensionless; 0..1]."""
        ...

    @property
    def periods(self) -> float:
        """Span of the fit window in orbital periods [dimensionless; ≥ 0]."""
        ...

    @property
    def number_of_sensors(self) -> int:
        """Count of distinct sensor ids that contributed to the fit."""
        ...

    @property
    def number_of_phenomenologies(self) -> int:
        """Count of distinct phenomenologies (range / angles-only / TDOA)
        used in the fit [0..3]."""
        ...

    @property
    def position_sigma(self) -> float:
        """Trace-RSS position sigma from the post-fit RIC covariance [km;
        ≥ 0]."""
        ...

    @property
    def velocity_sigma(self) -> float:
        """Trace-RSS velocity sigma from the post-fit RIC covariance [km/s;
        ≥ 0]."""
        ...

    @property
    def geometry(self) -> float:
        """Sensor-to-target geometric diversity from the line-of-sight SVD
        [deg; 0..90]."""
        ...

    @property
    def rms(self) -> float | None:
        """Unweighted RMS of the dominant residual component [km; ≥ 0]."""
        ...

    @property
    def weighted_rms(self) -> float | None:
        """Weighted RMS in measurement-sigma units [dimensionless; ≥ 0]."""
        ...

    @property
    def converged(self) -> bool:
        """Whether the solver reported convergence."""
        ...

    @property
    def residual_trend_r_squared(self) -> float:
        """R² of a linear fit of residual versus epoch [dimensionless;
        0..1]."""
        ...

    @property
    def quality(self) -> OrbitDeterminationQuality:
        """Discrete overall quality label."""
        ...


class CovarianceMatrix:
    """Square covariance matrix with an explicit frame convention.

    Used to express both a priori filter covariances and post-fit BLS
    covariances. The Cartesian 6×6 layout is ordered ``[r_x, r_y, r_z, v_x,
    v_y, v_z]`` with position elements in [km] and velocity elements in
    [km/s]; the upper-left 3×3 block is position [km²] and the lower-right
    3×3 block is velocity [km²/s²]. Larger Cartesian matrices append
    uncoupled drag (``B*``) and SRP (``A/m``) terms. The equinoctial 6×6
    layout is ordered ``[a, h, k, p, q, L]``.

    The `covariance_type` tag distinguishes Cartesian-in-an-inertial frame
    (``Inertial``, parameterised by which inertial frame), Cartesian-in-RIC
    (``Relative``), and equinoctial element-set covariance (``Equinoctial``).

    Attributes:
        sigmas (list[float]): Per-element 1-σ standard deviations
            (``sqrt`` of diagonal entries).
        covariance_type (CovarianceType): Frame and parameterization the
            matrix is expressed in.
        dimension (int): Number of rows / columns.
        matrix (list[list[float]]): Full square matrix as a list of rows.
        position_sigma (float): RSS of the first three diagonal sigmas (the
            position block), in [km]. Requires a ≥ 6×6 matrix.
        velocity_sigma (float): RSS of diagonal sigmas 3..6 (the velocity
            block), in [km/s]. Requires a ≥ 6×6 matrix.
    """

    def __init__(self, sigmas: list[float], covariance_type: CovarianceType) -> None:
        """Creates a diagonal CovarianceMatrix from per-element sigmas.

        For full off-diagonal terms (e.g., from a filter solution), use
        `from_matrix` instead.

        Args:
            sigmas: Per-element 1-σ standard deviations. Units depend on
                ``covariance_type``: see class docstring.
            covariance_type: Frame and parameterization the sigmas are
                expressed in.

        Raises:
            ValueError: If ``covariance_type`` is ``Inertial(_)`` with an
                embedded frame that is not ``TEME``, ``J2000``, or ``GCRS``.
        """
        ...

    @staticmethod
    def from_matrix(
        rows: list[list[float]], covariance_type: CovarianceType
    ) -> CovarianceMatrix:
        """Builds a CovarianceMatrix from an explicit square matrix.

        Use this instead of the diagonal-only `__init__` when full
        off-diagonal terms (e.g., from a filter solution) need to be carried.

        Args:
            rows: List of N rows of length N (any positive N).
            covariance_type: Frame and parameterization the matrix is
                expressed in.

        Returns:
            New `CovarianceMatrix`.

        Raises:
            ValueError: If ``rows`` is empty or non-square, or if
                ``covariance_type`` is ``Inertial(_)`` with an embedded frame
                that is not ``TEME``, ``J2000``, or ``GCRS``.
        """
        ...

    @property
    def sigmas(self) -> list[float]:
        """Per-element 1-σ standard deviations (``sqrt`` of diagonal
        entries)."""
        ...

    @property
    def covariance_type(self) -> CovarianceType:
        """Frame and parameterization the matrix is expressed in."""
        ...

    @property
    def dimension(self) -> int:
        """Number of rows / columns."""
        ...

    @property
    def matrix(self) -> list[list[float]]:
        """Full square matrix as a list of rows."""
        ...

    @property
    def position_sigma(self) -> float:
        """RSS of the first three diagonal sigmas (position block) [km]."""
        ...

    @property
    def velocity_sigma(self) -> float:
        """RSS of diagonal sigmas 3..6 (velocity block) [km/s]."""
        ...

    def to_type(
        self, target: CovarianceType, reference_state: CartesianState
    ) -> CovarianceMatrix:
        """Converts this covariance to a different :class:`CovarianceType`.

        Single unified method for all covariance-type conversions:
        inertial↔inertial rotations, inertial↔RIC, and inertial↔equinoctial.

        Args:
            target: Target type. Construct ``CovarianceType.Inertial(frame)``
                with a valid inertial frame, or use
                ``CovarianceType.Relative`` / ``CovarianceType.Equinoctial``.
            reference_state: State used to define RIC axes, supply the
                epoch for epoch-dependent inertial-inertial rotations, and
                evaluate the equinoctial jacobian. Must be in an inertial
                frame and carry a velocity.

        Returns:
            New covariance with ``covariance_type == target``.

        Raises:
            ValueError: If the matrix is not 6×6, ``reference_state`` is
                not in an inertial frame, ``reference_state`` lacks a
                velocity, or the equinoctial jacobian is singular.
        """
        ...


class ProcessNoise:
    """Continuous-to-discrete process-noise model for Kalman filters.

    Two layouts are supported:

    * **Diagonal** (uncoupled): one spectral density per state element. Builds
      ``Q = diag(spectral_densities) · |dt|`` and is intended for equinoctial
      states or any parameterization without explicit pos/vel pairing.
    * **Coupled Cartesian**: per-axis acceleration spectral densities drive
      paired ``(position_i, velocity_{i + n_axes})`` 2×2 blocks using the
      piecewise-constant acceleration model
      (``Q_pp = q · dt³/3``, ``Q_pv = q · dt²/2``, ``Q_vv = q · dt``).
      Optional uncoupled ``extra_psd`` terms are appended for drag (``B*``)
      and SRP (``A/m``) parameters.

    See `default_cartesian` and `default_equinoctial` for
    the canonical defaults used throughout the filter test suite.

    Attributes:
        dimension (int): Total state-vector dimension covered by the model.
    """

    def __init__(self, spectral_densities: list[float]) -> None:
        """Creates an uncoupled diagonal ProcessNoise.

        Args:
            spectral_densities: Per-element continuous spectral densities
                [unit² / s]; multiplied by ``|dt|`` to form the discrete Q.
        """
        ...

    @staticmethod
    def default_equinoctial() -> ProcessNoise:
        """Default 6-element equinoctial process noise.

        Layout ``[a (km), af, ag, chi, psi, mean_longitude (rad)]`` with
        spectral densities chosen to match canonical equinoctial filter
        tuning (semi-major-axis term ``1e-6 km²/s``; angular terms
        ``1e-12 rad²/s``).

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @staticmethod
    def default_equinoctial_with_drag() -> ProcessNoise:
        """Default 7-element equinoctial process noise (adds drag B-term).

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @staticmethod
    def default_equinoctial_with_drag_srp() -> ProcessNoise:
        """Default 8-element equinoctial process noise (adds drag and SRP).

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @staticmethod
    def default_cartesian() -> ProcessNoise:
        """Default 6-element Cartesian process noise.

        Uses the piecewise-constant acceleration model with per-axis spectral
        density ``5e-18 km²/s⁵`` on each of the three position/velocity pairs.

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @staticmethod
    def default_cartesian_with_drag() -> ProcessNoise:
        """Default 7-element Cartesian process noise (adds drag B-term).

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @staticmethod
    def default_cartesian_with_drag_srp() -> ProcessNoise:
        """Default 8-element Cartesian process noise (adds drag and SRP).

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @staticmethod
    def cartesian(acceleration_psd: list[float], extra_psd: list[float]) -> ProcessNoise:
        """Builds coupled-Cartesian process noise from acceleration spectral
        densities.

        Args:
            acceleration_psd: Per-axis acceleration spectral densities
                [km²/s⁵]; one entry per Cartesian axis. Three entries produce
                a 6-element pos/vel block.
            extra_psd: Spectral densities for additional uncoupled parameters
                appended after the pos/vel block (drag, SRP, etc.).

        Returns:
            Configured `ProcessNoise`.
        """
        ...

    @property
    def dimension(self) -> int:
        """Total state-vector dimension covered by the model."""
        ...


class BatchLeastSquares:
    """Batch weighted-least-squares orbit-determination solver.

    Implements a Gauss-Newton iteration in equinoctial elements, optionally
    including drag (``B*``) and SRP (``A/m``) parameters. Convergence is
    declared when the relative change in weighted RMS between iterations
    falls below ``1e-4`` (i.e., a 0.01 % improvement). Up to
    `max_iterations` Gauss-Newton steps are run; the default is
    ``20``. Reference: Vallado §10.3 (batch differential correction) and the
    Orekit ``BatchLSEstimator`` / GMAT ``BatchEstimator`` formulations.

    The post-fit covariance returned by `covariance` is rotated into
    the orbit-relative ``RIC`` frame (Cartesian position [km], velocity
    [km/s]); see `CovarianceMatrix` for the layout.

    Optional maneuver estimation (`estimate_maneuver`) jointly solves
    for a single Cartesian Δv and its epoch within the fit window; by default
    the radial component is unconstrained, but
    `allow_radial_delta_v` may be set to ``False`` to penalize it.

    Attributes:
        a_priori (Satellite): A-priori satellite, used as the initial guess
            and force-model template.
        observations (list[Observation]): Observations being fit.
        residuals (list[ObservationResidual]): Residuals at the current
            estimate. Available after `solve` or `iterate`.
        rms (float | None): Unweighted RMS [km; ≥ 0] of the dominant residual
            component over active (non-rejected) observations.
        weighted_rms (float | None): Weighted RMS in measurement-sigma units
            [dimensionless; ≥ 0].
        converged (bool): Whether the last solve met the convergence
            criterion.
        iteration_count (int): Number of Gauss-Newton steps taken in the most
            recent solve.
        max_iterations (int): Maximum number of Gauss-Newton steps. Default
            ``20``.
        estimate_drag (bool): If ``True``, solve for the TLE B-term
            (ballistic coefficient).
        estimate_srp (bool): If ``True``, solve for the TLE A/m (SRP) term.
        analytic_jacobian (bool): If ``True``, build the measurement Jacobian
            analytically (default). If ``False``, use finite differences.
        covariance (CovarianceMatrix): 6×6 post-fit covariance in the RIC
            frame.
        report (OrbitDeterminationReport): Quality report computed from the
            post-fit residuals and covariance.
        current_estimate (Satellite): Current best satellite estimate.
        estimate_maneuver (bool): If ``True``, jointly solve for a single Δv
            within the fit window.
        maneuver_epoch (ModifiedJulianDate | None): Epoch of the recovered
            maneuver, when one was solved for.
        delta_v (CartesianVector | None): Recovered Δv [km/s], when one was
            solved for.
        allow_radial_delta_v (bool): When maneuver estimation is on, allow
            the radial component of Δv (default ``True``).
        reject_bad_observations (bool): If ``True``, iteratively flag and
            reject observations whose post-fit residual exceeds the gating
            threshold and re-solve.
        rejected_observation_ids (list[str]): Identifiers of observations
            rejected by the last solve.
        minimum_maneuver_epoch (ModifiedJulianDate | None): Lower bound on
            the maneuver-search window. ``None`` to use the default
            ``first_obs - 3/4 period`` window.
        minimum_fit_span (TimeSpan | None): Lower bound on the fit-window
            duration. ``None`` to use the natural span of the observations.
        output_type (KeplerianType): Keplerian flavor of the satellite written
            on output (mean Kozai GP, osculating, etc.).
    """

    def __init__(self, observations: list[Observation], a_priori: Satellite) -> None:
        """Creates a BatchLeastSquares solver.

        Args:
            observations: Observations to fit.
            a_priori: A-priori satellite. The solver inherits the keplerian
                type of ``a_priori.tle`` when present; otherwise it defaults
                to ``MeanKozaiGP``.
        """
        ...

    def solve(self) -> None:
        """Runs Gauss-Newton iterations until convergence or
        `max_iterations` is reached.

        Updates `current_estimate`, `residuals`,
        `rms`, `weighted_rms`, `converged`, and
        `iteration_count`.

        Raises:
            ValueError: If the observation list is empty or any propagation
                fails during the solve.
        """
        ...

    def iterate(self) -> None:
        """Runs a single Gauss-Newton step.

        Useful for stepping through the solver one iteration at a time
        (debugging or interactive convergence monitoring).

        Raises:
            ValueError: If the observation list is empty or propagation fails.
        """
        ...

    def reset(self) -> None:
        """Discards solve state and reverts `current_estimate` to
        `a_priori`."""
        ...

    @property
    def a_priori(self) -> Satellite:
        """A-priori satellite (initial guess and force-model template)."""
        ...

    @a_priori.setter
    def a_priori(self, value: Satellite) -> None: ...

    @property
    def observations(self) -> list[Observation]:
        """Observations being fit."""
        ...

    @observations.setter
    def observations(self, value: list[Observation]) -> None: ...

    @property
    def residuals(self) -> list[ObservationResidual]:
        """Residuals at the current estimate.

        Raises:
            ValueError: If propagation of the current estimate fails.
        """
        ...

    @property
    def rms(self) -> float | None:
        """Unweighted RMS [km; ≥ 0] of the dominant residual component."""
        ...

    @property
    def converged(self) -> bool:
        """Whether the last solve met the convergence criterion (relative
        weighted-RMS change below 1e-4)."""
        ...

    @property
    def iteration_count(self) -> int:
        """Number of Gauss-Newton steps taken in the most recent solve."""
        ...

    @property
    def weighted_rms(self) -> float | None:
        """Weighted RMS in measurement-sigma units [dimensionless; ≥ 0]."""
        ...

    @property
    def max_iterations(self) -> int:
        """Maximum number of Gauss-Newton steps. Default ``20``."""
        ...

    @max_iterations.setter
    def max_iterations(self, value: int) -> None: ...

    @property
    def estimate_drag(self) -> bool:
        """Whether to solve for the TLE B-term (ballistic coefficient)."""
        ...

    @estimate_drag.setter
    def estimate_drag(self, value: bool) -> None: ...

    @property
    def estimate_srp(self) -> bool:
        """Whether to solve for the TLE A/m (SRP) term."""
        ...

    @estimate_srp.setter
    def estimate_srp(self, value: bool) -> None: ...

    @property
    def analytic_jacobian(self) -> bool:
        """If ``True``, build the measurement Jacobian analytically (default).
        If ``False``, use finite differences."""
        ...

    @analytic_jacobian.setter
    def analytic_jacobian(self, value: bool) -> None: ...

    @property
    def covariance(self) -> CovarianceMatrix:
        """6×6 post-fit covariance in the orbit-relative RIC frame.

        Raises:
            ValueError: If `solve` has not yet been called or the
                normal matrix is not positive definite.
        """
        ...

    @property
    def report(self) -> OrbitDeterminationReport:
        """Quality report computed from the post-fit residuals and covariance.

        Raises:
            ValueError: If the report cannot be computed (e.g., no
                observations or covariance unavailable).
        """
        ...

    @property
    def current_estimate(self) -> Satellite:
        """Current best satellite estimate."""
        ...

    @property
    def estimate_maneuver(self) -> bool:
        """If ``True``, jointly solve for a single Δv within the fit
        window."""
        ...

    @estimate_maneuver.setter
    def estimate_maneuver(self, value: bool) -> None: ...

    @property
    def maneuver_epoch(self) -> ModifiedJulianDate | None:
        """Epoch of the recovered maneuver, or ``None``."""
        ...

    @property
    def delta_v(self) -> CartesianVector | None:
        """Recovered Δv [km/s], or ``None``."""
        ...

    @property
    def allow_radial_delta_v(self) -> bool:
        """When maneuver estimation is on, allow the radial component of Δv
        (default ``True``)."""
        ...

    @allow_radial_delta_v.setter
    def allow_radial_delta_v(self, value: bool) -> None: ...

    @property
    def reject_bad_observations(self) -> bool:
        """If ``True``, iteratively flag and reject observations whose
        post-fit residual exceeds the gating threshold."""
        ...

    @reject_bad_observations.setter
    def reject_bad_observations(self, value: bool) -> None: ...

    @property
    def rejected_observation_ids(self) -> list[str]:
        """Identifiers of observations rejected by the last solve."""
        ...

    @property
    def minimum_maneuver_epoch(self) -> ModifiedJulianDate | None:
        """Lower bound on the maneuver-search window."""
        ...

    @minimum_maneuver_epoch.setter
    def minimum_maneuver_epoch(self, value: ModifiedJulianDate | None) -> None: ...

    @property
    def minimum_fit_span(self) -> TimeSpan | None:
        """Lower bound on the fit-window duration, or ``None``."""
        ...

    @minimum_fit_span.setter
    def minimum_fit_span(self, value: TimeSpan | None) -> None: ...

    @property
    def output_type(self) -> KeplerianType:
        """Keplerian flavor of the satellite written on output."""
        ...

    @output_type.setter
    def output_type(self, value: KeplerianType) -> None: ...


class ExtendedKalmanFilter:
    """Extended Kalman Filter for sequential orbit determination.

    Linearizes the propagation through the two-body state-transition matrix
    (or a finite-difference STM for longer steps; threshold is set internally)
    and the measurement model around the current estimate. Reference:
    Vallado §10.4 (sequential filters) and the Orekit
    ``KalmanEstimator`` formulation.

    The internal state vector is Cartesian ``[x, y, z, vx, vy, vz]`` in [km]
    and [km/s], optionally extended with drag (``B*``) and SRP (``A/m``)
    parameters when `estimate_drag` or `estimate_srp` is
    enabled.

    Attributes:
        residuals (list[ObservationResidual]): Residuals from the last solve.
        estimate_drag (bool): Whether the drag B-term is part of the
            estimated state. Defaults to ``False``.
        estimate_srp (bool): Whether the SRP A/m term is part of the
            estimated state. Defaults to ``False``.
        analytic_jacobian (bool): If ``True``, build the measurement Jacobian
            analytically. Defaults to ``False`` (finite differences).
        current_estimate (Satellite): Current best satellite estimate.
    """

    def __init__(
        self,
        observations: list[Observation],
        a_priori: Satellite,
        initial_covariance: CovarianceMatrix,
    ) -> None:
        """Creates an ExtendedKalmanFilter.

        Args:
            observations: Observations to process. Must be in chronological
                order.
            a_priori: A-priori satellite providing the initial state and
                force-model template.
            initial_covariance: A-priori 6×6 (or larger) Cartesian covariance
                in [km, km/s].
        """
        ...

    def solve(self) -> None:
        """Processes every observation in chronological order, alternating
        propagate and measurement-update steps.

        Updates `current_estimate` and `residuals` in place.

        Raises:
            ValueError: If propagation or measurement update fails.
        """
        ...

    def set_process_noise(self, process_noise: ProcessNoise) -> None:
        """Sets the process-noise model used during the propagation step.

        Args:
            process_noise: Process-noise model to apply between observations.
        """
        ...

    def set_observations(self, observations: list[Observation]) -> None:
        """Replaces the filter's observation queue.

        Args:
            observations: New observation queue. Must be chronologically
                ordered.
        """
        ...

    def set_a_priori(self, a_priori: Satellite) -> None:
        """Replaces the a-priori satellite used as the initial state.

        Args:
            a_priori: New a-priori satellite.
        """
        ...

    @property
    def residuals(self) -> list[ObservationResidual]:
        """Residuals from the last solve."""
        ...

    @property
    def estimate_drag(self) -> bool:
        """Whether the drag B-term is part of the estimated state."""
        ...

    @estimate_drag.setter
    def estimate_drag(self, value: bool) -> None: ...

    @property
    def estimate_srp(self) -> bool:
        """Whether the SRP A/m term is part of the estimated state."""
        ...

    @estimate_srp.setter
    def estimate_srp(self, value: bool) -> None: ...

    @property
    def analytic_jacobian(self) -> bool:
        """If ``True``, build the measurement Jacobian analytically. If
        ``False``, use finite differences (default)."""
        ...

    @analytic_jacobian.setter
    def analytic_jacobian(self, value: bool) -> None: ...

    @property
    def current_estimate(self) -> Satellite:
        """Current best satellite estimate.

        Raises:
            ValueError: If no state has been produced yet (e.g., `solve`
                has not been called).
        """
        ...


class SigmaPointParameters:
    """Sigma-point scaling parameters for the Van der Merwe scaled UKF.

    Attributes:
        alpha (float): Sigma-point spread parameter [dimensionless; small
            positive]. Default ``1e-3``.
        beta (float): Distribution-shape parameter [dimensionless]. ``2.0`` is
            optimal for Gaussian state distributions.
        kappa (float): Secondary scaling parameter [dimensionless]. ``0.0`` is
            the standard choice for state estimation.
    """

    def __init__(
        self, alpha: float = 1e-3, beta: float = 2.0, kappa: float = 0.0
    ) -> None:
        """Creates a SigmaPointParameters tuple.

        Args:
            alpha: Sigma-point spread parameter. Defaults to ``1e-3``.
            beta: Distribution-shape parameter. Defaults to ``2.0`` (Gaussian
                optimum).
            kappa: Secondary scaling parameter. Defaults to ``0.0``.
        """
        ...

    @property
    def alpha(self) -> float:
        """Sigma-point spread parameter [dimensionless]."""
        ...

    @property
    def beta(self) -> float:
        """Distribution-shape parameter [dimensionless]."""
        ...

    @property
    def kappa(self) -> float:
        """Secondary scaling parameter [dimensionless]."""
        ...


class UnscentedKalmanFilter:
    """Unscented Kalman Filter for sequential orbit determination.

    Uses the Van der Merwe scaled sigma-point formulation
    (parameters configured by `set_sigma_parameters`) to propagate
    the state distribution through the (nonlinear) propagation and
    measurement models without requiring analytic Jacobians. Reference:
    Vallado §10.4 and the Orekit ``UnscentedKalmanEstimator`` formulation.

    The internal state vector is Cartesian ``[x, y, z, vx, vy, vz]`` in [km]
    and [km/s], optionally extended with drag and SRP parameters when those
    flags are enabled.

    Attributes:
        residuals (list[ObservationResidual]): Residuals from the last solve.
        estimate_drag (bool): Whether the drag B-term is part of the
            estimated state.
        estimate_srp (bool): Whether the SRP A/m term is part of the
            estimated state.
        current_estimate (Satellite): Current best satellite estimate.
    """

    def __init__(
        self,
        observations: list[Observation],
        a_priori: Satellite,
        initial_covariance: CovarianceMatrix,
    ) -> None:
        """Creates an UnscentedKalmanFilter.

        Args:
            observations: Observations to process, in chronological order.
            a_priori: A-priori satellite providing the initial state.
            initial_covariance: A-priori Cartesian covariance [km, km/s].
        """
        ...

    def solve(self) -> None:
        """Processes every observation in chronological order, alternating
        sigma-point propagation and measurement-update steps.

        Raises:
            ValueError: If propagation or measurement update fails.
        """
        ...

    def set_sigma_parameters(self, params: SigmaPointParameters) -> None:
        """Sets the sigma-point scaling parameters.

        Args:
            params: New scaling parameters.
        """
        ...

    def set_process_noise(self, process_noise: ProcessNoise) -> None:
        """Sets the process-noise model used during the propagation step.

        Args:
            process_noise: Process-noise model to apply between observations.
        """
        ...

    @property
    def residuals(self) -> list[ObservationResidual]:
        """Residuals from the last solve."""
        ...

    @property
    def estimate_drag(self) -> bool:
        """Whether the drag B-term is part of the estimated state."""
        ...

    @estimate_drag.setter
    def estimate_drag(self, value: bool) -> None: ...

    @property
    def estimate_srp(self) -> bool:
        """Whether the SRP A/m term is part of the estimated state."""
        ...

    @estimate_srp.setter
    def estimate_srp(self, value: bool) -> None: ...

    @property
    def current_estimate(self) -> Satellite:
        """Current best satellite estimate.

        Raises:
            ValueError: If no state has been produced yet.
        """
        ...
