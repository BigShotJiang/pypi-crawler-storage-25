from __future__ import annotations

from ._keplime import catalogs as _catalogs  # type: ignore  # noqa: E402

TLECatalog = _catalogs.TLECatalog

_native_add = TLECatalog.add


def _add(self, *args):
    if len(args) == 1:
        return self.add_tle(args[0])
    if len(args) == 2:
        return _native_add(self, args[0], args[1])
    raise TypeError("add expects (tle) or (satellite_id, tle)")


setattr(TLECatalog, "add", _add)

__all__ = ["TLECatalog"]
