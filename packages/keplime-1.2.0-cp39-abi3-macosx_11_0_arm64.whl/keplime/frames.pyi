# flake8: noqa
from __future__ import annotations

from typing import Optional, Tuple

from .enums import PerformancePriority
from .time import ModifiedJulianDate

Vector3 = Tuple[float, float, float]

class GCRS:
    """Geocentric Celestial Reference System (GCRS).

    An Earth-centred inertial (ECI) frame aligned to the IAU 2000A/2006
    precession-nutation models.  Use `from_itrf` / `to_itrf`
    for the most common Earth-fixed ↔ inertial conversions, or
    `from_teme` / `to_teme` when working with SGP4 output.

    All epoch-dependent methods load IERS Finals 2000A EOP data; call
    ``keplime.data.load_finals_2000`` before using them.  The bias rotation
    methods (`from_j2000`, `to_j2000`) are epoch-independent.
    """

    @staticmethod
    def from_itrf(
        epoch: ModifiedJulianDate,
        position: Vector3,
        velocity: Optional[Vector3],
        priority: PerformancePriority,
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from ITRF to GCRS.

        Loads IERS Finals 2000A EOP data for ``epoch`` and applies the full
        Earth-orientation rotation (precession, nutation, sidereal, polar motion).
        The Coriolis velocity correction is included when ``velocity`` is not
        ``None``.

        Args:
            epoch: Epoch of the state vector.
            position: Position in ITRF [km].
            velocity: Velocity in ITRF [km/s], or ``None`` for position-only.
            priority: Accuracy/speed trade-off for the nutation-precession
                computation.

        Returns:
            ``(position_gcrs, velocity_gcrs)`` [km; km/s].  Velocity is ``None``
            if the input velocity was ``None``.
        """
        ...

    @staticmethod
    def to_itrf(
        epoch: ModifiedJulianDate,
        position: Vector3,
        velocity: Optional[Vector3],
        priority: PerformancePriority,
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from GCRS to ITRF.

        The inverse of `from_itrf`.  Applies the full Earth-orientation
        rotation at ``epoch`` including the Coriolis velocity correction.

        Args:
            epoch: Epoch of the state vector.
            position: Position in GCRS [km].
            velocity: Velocity in GCRS [km/s], or ``None`` for position-only.
            priority: Accuracy/speed trade-off for the nutation-precession
                computation.

        Returns:
            ``(position_itrf, velocity_itrf)`` [km; km/s].
        """
        ...

    @staticmethod
    def from_teme(
        epoch: ModifiedJulianDate,
        position: Vector3,
        velocity: Optional[Vector3],
        priority: PerformancePriority,
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from TEME to GCRS.

        Converts via the ITRF intermediate frame:
        TEME → ITRF (IAU 1980) → GCRS (IAU 2006/2000A CIO).
        Loads both Finals 1980 and Finals 2000A EOP tables.

        Args:
            epoch: Epoch of the state vector.
            position: Position in TEME [km].
            velocity: Velocity in TEME [km/s], or ``None`` for position-only.
            priority: Accuracy/speed trade-off for the GCRS ← ITRF rotation.

        Returns:
            ``(position_gcrs, velocity_gcrs)`` [km; km/s].
        """
        ...

    @staticmethod
    def to_teme(
        epoch: ModifiedJulianDate,
        position: Vector3,
        velocity: Optional[Vector3],
        priority: PerformancePriority,
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from GCRS to TEME.

        Converts via the ITRF intermediate frame:
        GCRS → ITRF → TEME (IAU 1980).

        Args:
            epoch: Epoch of the state vector.
            position: Position in GCRS [km].
            velocity: Velocity in GCRS [km/s], or ``None`` for position-only.
            priority: Accuracy/speed trade-off for the GCRS → ITRF rotation.

        Returns:
            ``(position_teme, velocity_teme)`` [km; km/s].
        """
        ...

    @staticmethod
    def from_j2000(
        position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from J2000 to GCRS.

        Applies the constant IAU 2006 frame-bias rotation (~84 mas).
        This transform is epoch-independent and requires no EOP data.

        Args:
            position: Position in J2000 (EME2000) [km].
            velocity: Velocity in J2000 [km/s], or ``None`` for position-only.

        Returns:
            ``(position_gcrs, velocity_gcrs)`` [km; km/s].
        """
        ...

    @staticmethod
    def to_j2000(
        position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from GCRS to J2000.

        Applies the transpose of the IAU 2006 frame-bias rotation (~84 mas).
        This transform is epoch-independent and requires no EOP data.

        Args:
            position: Position in GCRS [km].
            velocity: Velocity in GCRS [km/s], or ``None`` for position-only.

        Returns:
            ``(position_j2000, velocity_j2000)`` [km; km/s].
        """
        ...

class J2000:
    """J2000 mean-equatorial inertial frame (EME2000).

    Differs from GCRS by the constant IAU 2006 frame-bias rotation (~84 mas).
    Use when working with legacy SGP4 output or external tools that report
    state vectors in J2000/EME2000.  Epoch-dependent methods require IERS
    Finals 2000A EOP data; call ``keplime.data.load_finals_2000`` first.
    The bias rotation methods (`from_gcrs`, `to_gcrs`) are
    epoch-independent.
    """

    @staticmethod
    def from_itrf(
        epoch: ModifiedJulianDate,
        position: Vector3,
        velocity: Optional[Vector3],
        priority: PerformancePriority,
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from ITRF to J2000.

        Converts via GCRS: ITRF → GCRS (IAU 2006 CIO) → J2000 (bias rotation).
        Requires IERS Finals 2000A EOP data for the epoch.

        Args:
            epoch: Epoch of the state vector.
            position: Position in ITRF [km].
            velocity: Velocity in ITRF [km/s], or ``None`` for position-only.
            priority: Accuracy/speed trade-off for the nutation-precession
                computation.

        Returns:
            ``(position_j2000, velocity_j2000)`` [km; km/s].
        """
        ...

    @staticmethod
    def to_itrf(
        epoch: ModifiedJulianDate,
        position: Vector3,
        velocity: Optional[Vector3],
        priority: PerformancePriority,
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from J2000 to ITRF.

        Converts via GCRS: J2000 (bias rotation) → GCRS → ITRF (IAU 2006 CIO).
        Requires IERS Finals 2000A EOP data for the epoch.

        Args:
            epoch: Epoch of the state vector.
            position: Position in J2000 [km].
            velocity: Velocity in J2000 [km/s], or ``None`` for position-only.
            priority: Accuracy/speed trade-off for the nutation-precession
                computation.

        Returns:
            ``(position_itrf, velocity_itrf)`` [km; km/s].
        """
        ...

    @staticmethod
    def from_gcrs(
        position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from GCRS to J2000.

        Applies the constant IAU 2006 frame-bias transpose rotation (~84 mas).
        This transform is epoch-independent and requires no EOP data.

        Args:
            position: Position in GCRS [km].
            velocity: Velocity in GCRS [km/s], or ``None`` for position-only.

        Returns:
            ``(position_j2000, velocity_j2000)`` [km; km/s].
        """
        ...

    @staticmethod
    def to_gcrs(
        position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from J2000 to GCRS.

        Applies the constant IAU 2006 frame-bias rotation (~84 mas).
        This transform is epoch-independent and requires no EOP data.

        Args:
            position: Position in J2000 [km].
            velocity: Velocity in J2000 [km/s], or ``None`` for position-only.

        Returns:
            ``(position_gcrs, velocity_gcrs)`` [km; km/s].
        """
        ...

    @staticmethod
    def to_teme(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from J2000 to TEME.

        Applies the IAU 1980 nutation-precession rotation using nutation offsets
        (Δε, Δψ) from IERS Finals 1980 EOP data for ``epoch``.

        Args:
            epoch: Epoch at which to evaluate the rotation.
            position: Position in J2000 [km].
            velocity: Velocity in J2000 [km/s], or ``None`` for position-only.

        Returns:
            ``(position_teme, velocity_teme)`` [km; km/s].
        """
        ...

    @staticmethod
    def from_teme(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from TEME to J2000.

        Applies the transpose of the IAU 1980 nutation-precession matrix using
        nutation offsets (Δε, Δψ) from IERS Finals 1980 EOP data for ``epoch``.

        Args:
            epoch: Epoch at which to evaluate the rotation.
            position: Position in TEME [km].
            velocity: Velocity in TEME [km/s], or ``None`` for position-only.

        Returns:
            ``(position_j2000, velocity_j2000)`` [km; km/s].
        """
        ...

class ITRF:
    """International Terrestrial Reference Frame (ITRF).

    An Earth-fixed frame that includes the polar-motion correction.  Provides
    static methods for converting between ITRF and the Pseudo-Earth-Fixed (PEF)
    frame.  Polar-motion parameters are loaded from IERS Finals 2000A EOP tables;
    call ``keplime.data.load_finals_2000`` before using epoch-dependent methods.
    """

    @staticmethod
    def to_pef(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from ITRF to PEF.

        Applies the polar-motion rotation (xp, yp) looked up from IERS Finals
        2000A EOP data at ``epoch``.  The transform is a pure rotation; no
        Coriolis term is needed because polar-motion rates are negligible.

        Args:
            epoch: Epoch of the state vector; used to look up polar-motion
                parameters.
            position: Position in ITRF [km].
            velocity: Velocity in ITRF [km/s], or ``None`` for position-only.

        Returns:
            ``(position_pef, velocity_pef)`` [km; km/s].
        """
        ...

    @staticmethod
    def from_pef(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from PEF to ITRF.

        Applies the inverse polar-motion rotation using parameters from IERS Finals
        2000A EOP data at ``epoch``.  The inverse of `to_pef`.

        Args:
            epoch: Epoch of the state vector; used to look up polar-motion
                parameters.
            position: Position in PEF [km].
            velocity: Velocity in PEF [km/s], or ``None`` for position-only.

        Returns:
            ``(position_itrf, velocity_itrf)`` [km; km/s].
        """
        ...

class TEME:
    """True Equator, Mean Equinox (TEME) frame.

    The native output frame of the SGP4/SDP4 propagators.  Provides static methods
    for converting between TEME and ITRF or PEF.  All epoch-dependent methods
    require IERS Finals 1980 EOP data; call ``keplime.data.load_finals_1980`` before
    using them.

    !!! note
        These methods may raise `ValueError` if EOP data is not loaded
        and the UTC → UT1 conversion cannot be completed.
    """

    @staticmethod
    def from_itrf(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from ITRF to TEME.

        Loads IERS Finals 1980 EOP data and converts
        ITRF → PEF (polar motion) → TEME (sidereal rotation).

        Args:
            epoch: Epoch of the state vector.
            position: Position in ITRF [km].
            velocity: Velocity in ITRF [km/s], or ``None`` for position-only.

        Returns:
            ``(position_teme, velocity_teme)`` [km; km/s].

        Raises:
            ValueError: If the UTC time-system conversion fails (EOP data missing).
        """
        ...

    @staticmethod
    def to_itrf(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from TEME to ITRF.

        Loads IERS Finals 1980 EOP data and converts
        TEME → PEF (sidereal rotation) → ITRF (polar motion).

        Args:
            epoch: Epoch of the state vector.
            position: Position in TEME [km].
            velocity: Velocity in TEME [km/s], or ``None`` for position-only.

        Returns:
            ``(position_itrf, velocity_itrf)`` [km; km/s].

        Raises:
            ValueError: If the UTC time-system conversion fails (EOP data missing).
        """
        ...

    @staticmethod
    def to_pef(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from TEME to PEF.

        Applies the GMST (IAU 1982) sidereal rotation derived from ``epoch``
        (converted to UT1) and subtracts the Earth-rotation Coriolis term
        (ω × r_teme) from the velocity.

        Args:
            epoch: Epoch of the state vector.
            position: Position in TEME [km].
            velocity: Velocity in TEME [km/s], or ``None`` for position-only.

        Returns:
            ``(position_pef, velocity_pef)`` [km; km/s].

        Raises:
            ValueError: If the UT1 time-system conversion fails (EOP data missing).
        """
        ...

    @staticmethod
    def from_pef(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from PEF to TEME.

        Applies the inverse GMST sidereal rotation derived from ``epoch``
        (converted to UT1) and adds the Earth-rotation Coriolis term
        (ω × r_teme) to the velocity.

        Args:
            epoch: Epoch of the state vector.
            position: Position in PEF [km].
            velocity: Velocity in PEF [km/s], or ``None`` for position-only.

        Returns:
            ``(position_teme, velocity_teme)`` [km; km/s].

        Raises:
            ValueError: If the UT1 time-system conversion fails (EOP data missing).
        """
        ...

class PEF:
    """Pseudo-Earth-Fixed (PEF) frame.

    An Earth-fixed frame that excludes the polar-motion correction.  PEF is
    intermediate between TEME (after the sidereal rotation) and ITRF (after
    adding polar motion).  The TEME ↔ PEF rotation is driven purely by GMST
    using UT1; call ``keplime.data.load_finals_2000`` so that UTC → UT1
    conversion succeeds.
    """

    @staticmethod
    def to_teme(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from PEF to TEME.

        Converts ``epoch`` to UT1, builds the GMST (IAU 1982) sidereal rotation,
        and adds the Earth-rotation Coriolis term (ω × r_teme) to the velocity.

        Args:
            epoch: Epoch of the state vector.
            position: Position in PEF [km].
            velocity: Velocity in PEF [km/s], or ``None`` for position-only.

        Returns:
            ``(position_teme, velocity_teme)`` [km; km/s].

        Raises:
            ValueError: If the UT1 time-system conversion fails (EOP data missing).
        """
        ...

    @staticmethod
    def from_teme(
        epoch: ModifiedJulianDate, position: Vector3, velocity: Optional[Vector3]
    ) -> Tuple[Vector3, Optional[Vector3]]:
        """Transforms a position (and optionally velocity) from TEME to PEF.

        Converts ``epoch`` to UT1, builds the GMST (IAU 1982) sidereal rotation,
        and subtracts the Earth-rotation Coriolis term (ω × r_teme) from the velocity.

        Args:
            epoch: Epoch of the state vector.
            position: Position in TEME [km].
            velocity: Velocity in TEME [km/s], or ``None`` for position-only.

        Returns:
            ``(position_pef, velocity_pef)`` [km; km/s].

        Raises:
            ValueError: If the UT1 time-system conversion fails (EOP data missing).
        """
        ...
