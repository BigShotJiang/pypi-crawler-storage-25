# flake8: noqa
from __future__ import annotations

from typing import Optional

class AttitudeCharacterization:
    """Result of a satellite-stability characterization run.

    Returned by `characterize_stability` and the
    related `characterize_stability_gregory_loredo` /
    `characterize_stability_quasi_periodic_gp`
    methods. The ``log_odds`` attribute is populated only by the
    Bayesian methods; the string-length method does not produce a
    log-odds score.

    Attributes:
        is_stable: ``True`` when no period was detected (rotationally
            stable); ``False`` when a period was detected (tumbling).
        period_sec: Detected rotation period [s], or ``None`` when no
            period was detected.
        log_odds: Log Bayes factor of the best period vs. the
            no-periodicity baseline [nats]. ``None`` for the
            string-length method; ``float`` for the Bayesian methods
            (Gregory-Loredo, quasi-periodic GP).
    """

    @property
    def is_stable(self) -> bool:
        """``True`` when no period was detected (rotationally stable).

        ``False`` when a period was detected (the satellite is tumbling).
        """
        ...

    @property
    def period_sec(self) -> Optional[float]:
        """Detected rotation period [s], or ``None`` when no period was detected."""
        ...

    @property
    def log_odds(self) -> Optional[float]:
        """Log Bayes factor of the best period vs. the no-periodicity baseline [nats].

        ``None`` for the string-length method
        (`characterize_stability`); ``float`` for the
        Bayesian methods
        (`characterize_stability_gregory_loredo`,
        `characterize_stability_quasi_periodic_gp`).
        """
        ...
