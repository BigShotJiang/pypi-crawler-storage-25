"""Agents commands — manage AI agent runs and BYOK configuration."""

import typer
import httpx
from rich.console import Console
from rich.table import Table

from mushu.config import get_config

app = typer.Typer(help="AI agent runs and BYOK configuration")
console = Console()


def _get_headers(api_key: str | None = None) -> dict:
    if api_key:
        return {"X-API-Key": api_key}
    from mushu.config import get_auth_token
    token = get_auth_token()
    if not token:
        console.print("[red]Not authenticated. Run 'mushu auth login' or use --api-key.[/red]")
        raise typer.Exit(1)
    return {"Authorization": f"Bearer {token}"}


@app.command("run")
def create_run(
    user_id: str = typer.Option(..., "--user", "-u", help="User ID"),
    media_url: str = typer.Option(..., "--media", "-m", help="mushu-media R2 URL"),
    workflow: str = typer.Option("food-log", "--workflow", "-w", help="Workflow name"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
    poll: bool = typer.Option(True, "--poll/--no-poll", help="Poll for result (max 45s)"),
):
    """Submit an agent run and optionally wait for the result."""
    import time
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.post(
            f"{agents_url}/runs",
            headers=headers,
            json={"user_id": user_id, "workflow": workflow, "media_url": media_url},
        )

    if response.status_code != 200:
        console.print(f"[red]✗ Failed: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    job_id = response.json()["job_id"]
    console.print(f"[green]✓ Run submitted:[/green] {job_id}")

    if not poll:
        return

    console.print("Polling for result (max 45s)...")
    for attempt in range(15):
        time.sleep(3)
        with httpx.Client() as client:
            r = client.get(f"{agents_url}/runs/{job_id}", headers=headers)
        if r.status_code != 200:
            console.print(f"[red]Poll error: {r.status_code}[/red]")
            raise typer.Exit(1)

        data = r.json()
        status = data["status"]
        if status == "complete":
            console.print(f"[green]✓ Complete[/green]")
            if data.get("result"):
                import json
                console.print(json.dumps(data["result"], indent=2))
            return
        elif status == "failed":
            console.print(f"[red]✗ Failed: {data.get('error', 'unknown error')}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"  [{attempt + 1}/15] status={status}...")

    console.print("[yellow]Timed out after 45s. Run may still be in progress.[/yellow]")
    console.print(f"Check: mushu agents status --job-id {job_id}")


@app.command("status")
def get_run_status(
    job_id: str = typer.Option(..., "--job-id", "-j", help="Job ID"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
):
    """Check the status of an agent run."""
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.get(f"{agents_url}/runs/{job_id}", headers=headers)

    if response.status_code == 404:
        console.print(f"[red]Run not found: {job_id}[/red]")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    data = response.json()
    status = data["status"]
    color = {"complete": "green", "failed": "red", "running": "yellow", "pending": "blue"}.get(
        status, "white"
    )
    console.print(f"[{color}]Status: {status}[/{color}]")
    if data.get("result"):
        import json
        console.print(json.dumps(data["result"], indent=2))
    if data.get("error"):
        console.print(f"[red]Error: {data['error']}[/red]")
