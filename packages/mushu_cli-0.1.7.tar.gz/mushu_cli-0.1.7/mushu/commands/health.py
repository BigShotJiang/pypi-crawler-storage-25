"""Health metrics commands."""

from datetime import date

import httpx
import typer
from rich.console import Console
from rich.table import Table

from mushu.config import get_config

app = typer.Typer(help="Health metrics and longevity commands")
console = Console()


def _headers(api_key: str) -> dict:
    return {"x-api-key": api_key}


def _resolve_app(app_id: str | None, config) -> str:
    resolved = app_id or config.app_id
    if not resolved:
        console.print("[red]No app specified. Use --app or set default with 'mushu app use'[/red]")
        raise typer.Exit(1)
    return resolved


@app.command("ingest")
def ingest(
    user_id: str = typer.Argument(..., help="User ID"),
    metric: list[str] = typer.Option(
        ...,
        "--metric",
        "-m",
        help="Metric in format name:value[:unit] e.g. vo2_max:52.3:mL/kg/min",
    ),
    on: str = typer.Option(None, "--on", help="Date YYYY-MM-DD (default: today)"),
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
    api_key: str = typer.Option(..., "--key", "-k", envvar="MUSHU_API_KEY", help="API key"),
):
    """Ingest health metrics for a user.

    Examples:
        mushu health ingest user_123 -m vo2_max:52.3:mL/kg/min -m hrv_rmssd:45:ms --key sk_...
        mushu health ingest user_123 -m resting_heart_rate:58:bpm --on 2026-04-01 --key sk_...
    """
    config = get_config()
    resolved_app = _resolve_app(app_id, config)
    record_date = on or date.today().isoformat()

    metrics = []
    for m in metric:
        parts = m.split(":")
        if len(parts) < 2:
            console.print(
                f"[red]Invalid metric format '{m}'. Use name:value or name:value:unit[/red]"
            )
            raise typer.Exit(1)
        entry: dict = {"metric": parts[0], "value": float(parts[1]), "date": record_date}
        if len(parts) >= 3:
            entry["unit"] = parts[2]
        metrics.append(entry)

    try:
        with httpx.Client(timeout=30) as client:
            r = client.post(
                f"{config.health_url}/apps/{resolved_app}/metrics/{user_id}/ingest",
                headers=_headers(api_key),
                json={"metrics": metrics},
            )
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        data = r.json()
        console.print(f"[green]Wrote {data['rows_written']} metric(s)[/green]")
    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)


@app.command("get")
def get_metrics(
    user_id: str = typer.Argument(..., help="User ID"),
    days: int = typer.Option(30, "--days", "-d", help="Number of days back (default: 30)"),
    metric: list[str] = typer.Option(None, "--metric", "-m", help="Filter to specific metrics"),
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
    api_key: str = typer.Option(..., "--key", "-k", envvar="MUSHU_API_KEY", help="API key"),
):
    """Get health metrics for a user.

    Examples:
        mushu health get user_123 --key sk_...
        mushu health get user_123 --days 90 -m vo2_max -m hrv_rmssd --key sk_...
    """
    config = get_config()
    resolved_app = _resolve_app(app_id, config)

    params: dict = {"days": days}
    if metric:
        params["metrics"] = ",".join(metric)

    try:
        with httpx.Client(timeout=30) as client:
            r = client.get(
                f"{config.health_url}/apps/{resolved_app}/metrics/{user_id}",
                headers=_headers(api_key),
                params=params,
            )
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        data = r.json()
        series = data.get("series", [])

        if not series:
            console.print("[dim]No metrics found[/dim]")
            return

        for s in series:
            table = Table(title=f"{s['metric']}" + (f" ({s['unit']})" if s.get("unit") else ""))
            table.add_column("Date", style="dim")
            table.add_column("Value", justify="right")
            for dt, val in s["points"]:
                table.add_row(dt, str(val))
            console.print(table)

    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)


@app.command("longevity")
def longevity(
    user_id: str = typer.Argument(..., help="User ID"),
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
    api_key: str = typer.Option(..., "--key", "-k", envvar="MUSHU_API_KEY", help="API key"),
):
    """Get longevity score for a user.

    Composite score (0-100) based on VO2 max, HRV, resting heart rate,
    sleep, steps, SpO2, and respiratory rate.

    Example:
        mushu health longevity user_123 --key sk_...
    """
    config = get_config()
    resolved_app = _resolve_app(app_id, config)

    try:
        with httpx.Client(timeout=30) as client:
            r = client.get(
                f"{config.health_url}/apps/{resolved_app}/metrics/{user_id}/longevity",
                headers=_headers(api_key),
            )
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        data = r.json()
        composite = data["composite"]
        sub_scores = data.get("sub_scores", {})
        targets = data.get("targets", {})
        age = data.get("age")
        sex = data.get("sex")

        # Composite score with color
        color = "green" if composite >= 70 else "yellow" if composite >= 40 else "red"
        console.print(f"\n[bold]Longevity Score: [{color}]{composite:.1f}[/{color}] / 100[/bold]")
        if age and sex:
            console.print(f"[dim]  Age {age}, {sex}[/dim]")
        console.print()

        if sub_scores:
            table = Table(title="Sub-scores")
            table.add_column("Metric")
            table.add_column("Score", justify="right")
            table.add_column("Concern", justify="right", style="dim")
            table.add_column("Target", justify="right", style="dim")
            table.add_column("Elite", justify="right", style="dim")

            for metric_name, score in sub_scores.items():
                t = targets.get(metric_name, {})
                score_color = "green" if score >= 67 else "yellow" if score >= 33 else "red"
                table.add_row(
                    metric_name,
                    f"[{score_color}]{score:.1f}[/{score_color}]",
                    str(t.get("concern", "")),
                    str(t.get("target", "")),
                    str(t.get("elite", "")),
                )
            console.print(table)

    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)


redirect_uri_app = typer.Typer(help="Manage Withings OAuth allowed redirect URIs")
app.add_typer(redirect_uri_app, name="redirect-uri")


def _require_auth_for_health():
    """Require Bearer token auth (redirect URI config is org-admin-gated)."""
    from mushu.config import StoredTokens, get_global_config

    tokens = StoredTokens.load()
    config = get_global_config()
    if not tokens:
        console.print("[red]Not logged in. Run 'mushu auth login' first.[/red]")
        raise typer.Exit(1)
    return tokens, config


def _ensure_health_config(client: httpx.Client, tokens, global_config, app_id: str) -> list[str]:
    """Return current redirect_uris, auto-creating the health config if it doesn't exist yet."""
    r = client.get(
        f"{global_config.health_url}/apps/{app_id}/health-config",
        headers={"Authorization": f"Bearer {tokens.access_token}"},
    )
    if r.status_code == 200:
        return r.json().get("redirect_uris", [])

    if r.status_code != 404:
        console.print(f"[red]Failed to fetch health config: {r.text}[/red]")
        raise typer.Exit(1)

    # Config doesn't exist — look up the app's org_id from core, then create it
    app_r = client.get(
        f"{global_config.core_url}/apps/{app_id}",
        headers={"Authorization": f"Bearer {tokens.access_token}"},
    )
    if app_r.status_code != 200:
        console.print(f"[red]Could not look up app {app_id}: {app_r.text}[/red]")
        raise typer.Exit(1)

    org_id = app_r.json().get("org_id")
    if not org_id:
        console.print("[red]App record missing org_id[/red]")
        raise typer.Exit(1)

    create_r = client.post(
        f"{global_config.health_url}/apps",
        headers={"Authorization": f"Bearer {tokens.access_token}"},
        json={"app_id": app_id, "org_id": org_id},
    )
    if create_r.status_code not in (200, 201):
        console.print(f"[red]Failed to initialize health config: {create_r.text}[/red]")
        raise typer.Exit(1)

    return create_r.json().get("redirect_uris", [])


@redirect_uri_app.command("list")
def redirect_uri_list(
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
):
    """List allowed Withings OAuth redirect URIs for an app.

    Example:
        mushu health redirect-uri list --app app_fbce5dbd
    """
    tokens, global_config = _require_auth_for_health()
    config = get_config()
    resolved_app = _resolve_app(app_id, config)

    try:
        with httpx.Client(timeout=30) as client:
            r = client.get(
                f"{global_config.health_url}/apps/{resolved_app}/health-config",
                headers={"Authorization": f"Bearer {tokens.access_token}"},
            )
        if r.status_code == 404:
            console.print(
                "[dim]No health config found for this app. Run 'mushu health redirect-uri add' to create one.[/dim]"
            )
            return
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        uris = r.json().get("redirect_uris", [])
        if not uris:
            console.print("[dim]No redirect URIs configured.[/dim]")
        else:
            for uri in uris:
                console.print(uri)
    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)


@redirect_uri_app.command("add")
def redirect_uri_add(
    uri: str = typer.Argument(..., help="Redirect URI to add (e.g. womoji://withings/success)"),
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
):
    """Add a redirect URI to the Withings OAuth allowlist.

    Example:
        mushu health redirect-uri add womoji://withings/success --app app_fbce5dbd
    """
    tokens, global_config = _require_auth_for_health()
    config = get_config()
    resolved_app = _resolve_app(app_id, config)

    try:
        with httpx.Client(timeout=30) as client:
            current = _ensure_health_config(client, tokens, global_config, resolved_app)
            if uri in current:
                console.print(f"[yellow]{uri} is already in the allowlist[/yellow]")
                return

            r = client.patch(
                f"{global_config.health_url}/apps/{resolved_app}/health-config",
                headers={"Authorization": f"Bearer {tokens.access_token}"},
                json={"redirect_uris": current + [uri]},
            )
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        console.print(f"[green]Added {uri}[/green]")
        for u in r.json().get("redirect_uris", []):
            console.print(f"  {u}")
    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)


@redirect_uri_app.command("remove")
def redirect_uri_remove(
    uri: str = typer.Argument(..., help="Redirect URI to remove"),
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
):
    """Remove a redirect URI from the Withings OAuth allowlist.

    Example:
        mushu health redirect-uri remove womoji://withings/success --app app_fbce5dbd
    """
    tokens, global_config = _require_auth_for_health()
    config = get_config()
    resolved_app = _resolve_app(app_id, config)

    try:
        with httpx.Client(timeout=30) as client:
            current = _ensure_health_config(client, tokens, global_config, resolved_app)
            if uri not in current:
                console.print(f"[yellow]{uri} is not in the allowlist[/yellow]")
                return

            r = client.patch(
                f"{global_config.health_url}/apps/{resolved_app}/health-config",
                headers={"Authorization": f"Bearer {tokens.access_token}"},
                json={"redirect_uris": [u for u in current if u != uri]},
            )
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        console.print(f"[green]Removed {uri}[/green]")
        remaining = r.json().get("redirect_uris", [])
        if remaining:
            for u in remaining:
                console.print(f"  {u}")
        else:
            console.print("[dim]  (no URIs remaining)[/dim]")
    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)


@app.command("profile")
def profile(
    user_id: str = typer.Argument(..., help="User ID"),
    dob: str = typer.Option(None, "--dob", help="Date of birth YYYY-MM-DD"),
    sex: str = typer.Option(None, "--sex", help="Biological sex (male/female)"),
    height: float = typer.Option(None, "--height-m", help="Height in meters"),
    app_id: str = typer.Option(None, "--app", "-a", help="App ID"),
    api_key: str = typer.Option(..., "--key", "-k", envvar="MUSHU_API_KEY", help="API key"),
):
    """Get or set health profile for a user.

    With no options, shows the current profile.
    With options, updates the profile.

    Examples:
        mushu health profile user_123 --key sk_...
        mushu health profile user_123 --dob 1989-01-01 --sex male --height-m 1.78 --key sk_...
    """
    config = get_config()
    resolved_app = _resolve_app(app_id, config)

    try:
        with httpx.Client(timeout=30) as client:
            if dob or sex or height:
                # Upsert
                body: dict = {}
                if dob:
                    body["date_of_birth"] = dob
                if sex:
                    body["biological_sex"] = sex
                if height:
                    body["height_m"] = height
                r = client.put(
                    f"{config.health_url}/apps/{resolved_app}/profile/{user_id}",
                    headers=_headers(api_key),
                    json=body,
                )
            else:
                # Get
                r = client.get(
                    f"{config.health_url}/apps/{resolved_app}/profile/{user_id}",
                    headers=_headers(api_key),
                )

        if r.status_code == 404:
            console.print("[dim]No profile set[/dim]")
            return
        if r.status_code != 200:
            console.print(f"[red]Failed: {r.text}[/red]")
            raise typer.Exit(1)

        data = r.json()
        console.print("[bold]Health Profile[/bold]")
        if data.get("date_of_birth"):
            console.print(f"  Date of birth: {data['date_of_birth']}")
        if data.get("biological_sex"):
            console.print(f"  Biological sex: {data['biological_sex']}")
        if data.get("height_m"):
            console.print(f"  Height: {data['height_m']} m")

    except httpx.RequestError as e:
        console.print(f"[red]Network error: {e}[/red]")
        raise typer.Exit(1)
