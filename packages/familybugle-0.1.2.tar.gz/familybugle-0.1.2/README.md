# familybugle

CLI for [Family Bugle](https://familybugle.com/ai) — Park City activities, providers, school breaks, and AI Q&A, straight from your terminal.

```
$ familybugle search "ski lessons" --age 7 --limit 5
╭─────────────────────────────────────────────────────────────────────────╮
│ Name                   │ Provider          │ Ages       │ Date       │ Price │
│ Youth Ski Camp         │ Basin Recreation  │ 6-12 years │ 2026-01-15 │ $150  │
│ Ski Explorers          │ Park City Mtn     │ 5-10 years │ 2026-01-08 │ $200  │
╰─────────────────────────────────────────────────────────────────────────╯
  Showing 2 of 2  —  familybugle show activity <id> for details
```

## Install

```bash
# Recommended: pipx (isolated environment)
pipx install familybugle

# Or: uvx (no install needed)
uvx familybugle search "spring break camps"

# Or: pip
pip install familybugle
```

## Quickstart

```bash
# Search activities
familybugle search "ski lessons" --age 7
familybugle search "swim" --category Sports --limit 10

# List providers
familybugle providers
familybugle providers --type daycare --location "Old Town"
familybugle providers --search "ymca"

# Full detail
familybugle show activity <uuid>
familybugle show provider <uuid>

# Utility
familybugle categories
familybugle breaks

# Tuition rates for a daycare or school
familybugle providers --type daycare     # find a provider UUID first
familybugle tuition <uuid>

# Ask the AI
familybugle ask "when is spring break?"
familybugle ask "what swim lessons are available for a 5-year-old?"
```

## API Key

All commands work without a key (public tier: 100 requests/hour). For higher limits (2,000 requests/hour), get a free key:

1. Sign in at [familybugle.com/account](https://familybugle.com/account) → **Developer** tab
2. Click **Create API key**, copy the `fb_live_...` value
3. Save it locally:

```bash
familybugle config set api-key fb_live_YOUR_KEY_HERE
```

The key is stored in `~/.config/familybugle/config.toml` (mode 0600) and sent automatically on every request. Override with `FAMILYBUGLE_API_KEY` env var.

```bash
# Check stored key (masked)
familybugle config get api-key
# → API key: fb_live_abc1…

# Remove key
familybugle config unset api-key
```

## Rate limits

| Tier            | Reads     | /ask      |
|-----------------|-----------|-----------|
| Public (no key) | 30/hour   | 3/minute  |
| API key         | 2000/hour | 30/minute |

## Local development

```bash
# Point at a local backend
familybugle --api-url http://localhost:8000 search "ski"
familybugle --api-url http://localhost:8000 categories

# Or set via env var
export FAMILYBUGLE_API_URL=http://localhost:8000
familybugle categories
```

## Raw JSON output

Every command supports `--json` for scripting:

```bash
familybugle search "camps" --json | jq '.data[].title'
familybugle tuition <uuid> --json | jq '.[].rates[].amount'
familybugle ask "spring break dates?" --json | jq '.answer'
```

## Links

- [Interactive API reference](https://familybugle.com/ai/reference) — try every endpoint in the browser
- [Developer hub](https://familybugle.com/ai) — MCP server, API docs, key management
- [Family Bugle](https://familybugle.com) — the full site for Park City families
