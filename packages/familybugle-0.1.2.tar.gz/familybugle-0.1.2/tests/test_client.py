"""Tests for FamilyBugleClient.

Uses respx to mock httpx transport, keeping tests fast and deterministic.
"""

from __future__ import annotations

import httpx
import pytest
import respx

from familybugle_cli.client import _USER_AGENT, FamilyBugleClient
from familybugle_cli.exceptions import FamilyBugleError

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def base_url() -> str:
    return "http://test.local"


@pytest.fixture
def client(base_url: str) -> FamilyBugleClient:
    return FamilyBugleClient(base_url=base_url, api_key=None)


@pytest.fixture
def authed_client(base_url: str) -> FamilyBugleClient:
    return FamilyBugleClient(base_url=base_url, api_key="fb_live_testkey123")


# ---------------------------------------------------------------------------
# User-Agent header
# ---------------------------------------------------------------------------


@respx.mock
def test_user_agent_sent(client: FamilyBugleClient, base_url: str) -> None:
    """Every request should include the User-Agent header."""
    route = respx.get(f"{base_url}/api/v1/categories").mock(
        return_value=httpx.Response(200, json=[])
    )
    client.list_categories()
    assert route.called
    request = route.calls.last.request
    assert _USER_AGENT in request.headers.get("user-agent", "")


# ---------------------------------------------------------------------------
# API key header
# ---------------------------------------------------------------------------


@respx.mock
def test_api_key_sent_when_set(authed_client: FamilyBugleClient, base_url: str) -> None:
    """API key should be included as X-API-Key when provided."""
    route = respx.get(f"{base_url}/api/v1/categories").mock(
        return_value=httpx.Response(200, json=[])
    )
    authed_client.list_categories()
    request = route.calls.last.request
    assert request.headers.get("x-api-key") == "fb_live_testkey123"


@respx.mock
def test_api_key_absent_when_not_set(client: FamilyBugleClient, base_url: str) -> None:
    """X-API-Key header must NOT be sent for unauthenticated clients."""
    route = respx.get(f"{base_url}/api/v1/categories").mock(
        return_value=httpx.Response(200, json=[])
    )
    client.list_categories()
    request = route.calls.last.request
    assert "x-api-key" not in request.headers


# ---------------------------------------------------------------------------
# Error mapping
# ---------------------------------------------------------------------------


@respx.mock
def test_429_raises_rate_limit_error(client: FamilyBugleClient, base_url: str) -> None:
    """HTTP 429 should raise FamilyBugleError with rate-limit message."""
    respx.get(f"{base_url}/api/v1/categories").mock(
        return_value=httpx.Response(429, json={"detail": "Too Many Requests"})
    )
    with pytest.raises(FamilyBugleError, match="Rate limit reached"):
        client.list_categories()


@respx.mock
def test_404_raises_api_error(client: FamilyBugleClient, base_url: str) -> None:
    """HTTP 404 should raise FamilyBugleError with API error detail."""
    respx.get(f"{base_url}/api/v1/activities/missing-id").mock(
        return_value=httpx.Response(404, json={"detail": "Activity not found"})
    )
    with pytest.raises(FamilyBugleError, match="Activity not found"):
        client.get_activity("missing-id")


@respx.mock
def test_500_raises_server_error(client: FamilyBugleClient, base_url: str) -> None:
    """HTTP 5xx should raise FamilyBugleError with generic server error message."""
    respx.get(f"{base_url}/api/v1/categories").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )
    with pytest.raises(FamilyBugleError, match="Server error"):
        client.list_categories()


def test_transport_error_raises_friendly_message(base_url: str) -> None:
    """Network errors should raise FamilyBugleError with connectivity message."""
    with respx.mock:
        respx.get(f"{base_url}/api/v1/categories").mock(
            side_effect=httpx.ConnectError("connection refused")
        )
        client = FamilyBugleClient(base_url=base_url)
        with pytest.raises(FamilyBugleError, match="Network error"):
            client.list_categories()


# ---------------------------------------------------------------------------
# Param handling
# ---------------------------------------------------------------------------


@respx.mock
def test_none_params_not_sent(client: FamilyBugleClient, base_url: str) -> None:
    """None-valued query parameters must be omitted from the request URL."""
    route = respx.get(f"{base_url}/api/v1/activities").mock(
        return_value=httpx.Response(200, json={"data": [], "total": 0, "page": 1, "limit": 20, "pages": 0})
    )
    client.list_activities(category=None, age=None)
    request = route.calls.last.request
    # Only page and limit should appear (no "age=None" or "category=None").
    url = str(request.url)
    assert "age=None" not in url
    assert "category=None" not in url


@respx.mock
def test_list_activities_passes_filters(client: FamilyBugleClient, base_url: str) -> None:
    """Filter parameters should be forwarded to the API."""
    route = respx.get(f"{base_url}/api/v1/activities").mock(
        return_value=httpx.Response(200, json={"data": [], "total": 0, "page": 1, "limit": 5, "pages": 0})
    )
    client.list_activities(category="Sports", age=7, limit=5)
    request = route.calls.last.request
    url = str(request.url)
    assert "category=Sports" in url
    assert "age=7" in url
    assert "limit=5" in url


@respx.mock
def test_list_activities_search_forwarded(client: FamilyBugleClient, base_url: str) -> None:
    """list_activities(search='x') must send ?search=x to the API."""
    route = respx.get(f"{base_url}/api/v1/activities").mock(
        return_value=httpx.Response(
            200,
            json={"data": [], "total": 0, "page": 1, "limit": 20, "pages": 0},
        )
    )
    client.list_activities(search="ski lessons")
    request = route.calls.last.request
    url = str(request.url)
    assert "search=ski+lessons" in url or "search=ski%20lessons" in url or "search=ski lessons" in url


@respx.mock
def test_list_activities_search_none_not_sent(client: FamilyBugleClient, base_url: str) -> None:
    """list_activities() with no search must NOT send search= to the API."""
    route = respx.get(f"{base_url}/api/v1/activities").mock(
        return_value=httpx.Response(
            200,
            json={"data": [], "total": 0, "page": 1, "limit": 20, "pages": 0},
        )
    )
    client.list_activities()
    request = route.calls.last.request
    url = str(request.url)
    assert "search=" not in url


@respx.mock
def test_ask_sends_post_with_question(client: FamilyBugleClient, base_url: str) -> None:
    """ask() should POST to /api/v1/ask with a JSON body."""
    route = respx.post(f"{base_url}/api/v1/ask").mock(
        return_value=httpx.Response(200, json={"answer": "Spring break is April 6-10.", "citations": []})
    )
    result = client.ask("when is spring break?")
    assert route.called
    assert result["answer"] == "Spring break is April 6-10."
    # Verify body was JSON with the question field.
    import json
    body = json.loads(route.calls.last.request.content)
    assert body["question"] == "when is spring break?"


@respx.mock
def test_get_tuition_passes_provider_id(client: FamilyBugleClient, base_url: str) -> None:
    """get_tuition() must send provider_id as a query parameter to /api/v1/tuition."""
    provider_uuid = "bbbb0000-0000-0000-0000-000000000002"
    route = respx.get(f"{base_url}/api/v1/tuition").mock(
        return_value=httpx.Response(200, json=[])
    )
    result = client.get_tuition(provider_uuid)
    assert route.called
    url = str(route.calls.last.request.url)
    assert provider_uuid in url
    assert result == []


@respx.mock
def test_get_tuition_returns_schedule_list(client: FamilyBugleClient, base_url: str) -> None:
    """get_tuition() should return the parsed JSON list from the API."""
    provider_uuid = "bbbb0000-0000-0000-0000-000000000002"
    schedules = [{"id": "s1", "name": "2026-2027 Tuition", "rates": []}]
    respx.get(f"{base_url}/api/v1/tuition").mock(
        return_value=httpx.Response(200, json=schedules)
    )
    result = client.get_tuition(provider_uuid)
    assert len(result) == 1
    assert result[0]["name"] == "2026-2027 Tuition"
