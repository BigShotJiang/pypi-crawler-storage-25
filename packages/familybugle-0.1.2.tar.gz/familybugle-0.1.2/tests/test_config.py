"""Tests for config.py — get/set/unset API key and file permissions.

Uses monkeypatching to redirect platformdirs to a tmp directory so tests
never touch the real ~/.config/familybugle/config.toml.
"""

from __future__ import annotations

import stat
from pathlib import Path

import pytest

import familybugle_cli.config as cfg_module
from familybugle_cli.config import (
    get_api_key,
    mask_key,
    set_api_key,
    unset_api_key,
)

# ---------------------------------------------------------------------------
# Fixture: redirect config to a tmp path
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def tmp_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect config_path() to a temp directory for isolation."""
    config_file = tmp_path / "config.toml"

    monkeypatch.setattr(cfg_module, "config_path", lambda: config_file)
    # Also clear the env var so it doesn't shadow the file.
    monkeypatch.delenv("FAMILYBUGLE_API_KEY", raising=False)
    return config_file


# ---------------------------------------------------------------------------
# set / get / unset roundtrip
# ---------------------------------------------------------------------------


def test_set_then_get_returns_key() -> None:
    """set_api_key → get_api_key should round-trip correctly."""
    set_api_key("fb_live_abc123")
    assert get_api_key() == "fb_live_abc123"


def test_unset_removes_key() -> None:
    """unset_api_key should remove the key so get returns None."""
    set_api_key("fb_live_abc123")
    unset_api_key()
    assert get_api_key() is None


def test_unset_when_no_key_does_not_error() -> None:
    """unset_api_key must not raise if no key is stored."""
    unset_api_key()  # Should be a no-op.


def test_get_returns_none_when_no_config() -> None:
    """get_api_key returns None when no config file exists and no env var set."""
    assert get_api_key() is None


# ---------------------------------------------------------------------------
# File permissions
# ---------------------------------------------------------------------------


def test_config_file_mode_is_0600(tmp_config: Path) -> None:
    """Config file must be written with mode 0600 (owner read/write only)."""
    set_api_key("fb_live_secret")
    mode = tmp_config.stat().st_mode
    # Extract permission bits.
    perms = stat.S_IMODE(mode)
    assert perms == 0o600, f"Expected 0600, got {oct(perms)}"


def test_no_leftover_tempfiles_after_save(tmp_config: Path) -> None:
    """The atomic tempfile must be cleaned up after a successful save.

    The tempfile is written to the same directory as the config, prefixed
    with '.config_'.  A successful write-and-replace must leave no such
    file behind.
    """
    set_api_key("fb_live_secret")
    config_dir = tmp_config.parent
    leftover = list(config_dir.glob(".config_*"))
    assert leftover == [], f"Leftover tempfiles found: {leftover}"


def test_config_file_mode_is_0600_after_overwrite(tmp_config: Path) -> None:
    """Mode 0600 is preserved when overwriting an existing config file."""
    set_api_key("fb_live_first")
    set_api_key("fb_live_second")
    perms = stat.S_IMODE(tmp_config.stat().st_mode)
    assert perms == 0o600, f"Expected 0600 after overwrite, got {oct(perms)}"


# ---------------------------------------------------------------------------
# Env var override
# ---------------------------------------------------------------------------


def test_env_var_overrides_config_file(monkeypatch: pytest.MonkeyPatch) -> None:
    """FAMILYBUGLE_API_KEY env var should take precedence over the config file."""
    set_api_key("fb_live_from_file")
    monkeypatch.setenv("FAMILYBUGLE_API_KEY", "fb_live_from_env")
    assert get_api_key() == "fb_live_from_env"


def test_env_var_used_when_no_file(monkeypatch: pytest.MonkeyPatch) -> None:
    """FAMILYBUGLE_API_KEY env var works even when no config file exists."""
    monkeypatch.setenv("FAMILYBUGLE_API_KEY", "fb_live_env_only")
    assert get_api_key() == "fb_live_env_only"


# ---------------------------------------------------------------------------
# mask_key
# ---------------------------------------------------------------------------


def test_mask_key_short_key() -> None:
    """Keys <= 12 chars should be shortened with ellipsis."""
    result = mask_key("fb_abc")
    assert result.endswith("…")


def test_mask_key_long_key() -> None:
    """Long keys should be truncated to 12 chars + ellipsis."""
    key = "fb_live_abc1def2ghij_morestuff"
    masked = mask_key(key)
    assert masked.endswith("…")
    assert len(masked) == 13  # 12 chars + ellipsis


def test_mask_key_shows_prefix() -> None:
    """Masked key should start with the real key prefix."""
    key = "fb_live_testkey999"
    masked = mask_key(key)
    assert masked.startswith("fb_live_test")


# ---------------------------------------------------------------------------
# Idempotent write (multiple sets)
# ---------------------------------------------------------------------------


def test_set_twice_overwrites() -> None:
    """set_api_key called twice should store only the latest key."""
    set_api_key("fb_live_first")
    set_api_key("fb_live_second")
    assert get_api_key() == "fb_live_second"
