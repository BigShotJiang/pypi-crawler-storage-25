"""Tests for CLI commands using typer.testing.CliRunner.

Commands that make network calls have their client mocked via monkeypatch so
tests run offline. The focus is on:
- Command exits with code 0 on success, code 1 on FamilyBugleError.
- Key output substrings are present (table headers, panel titles, etc.).
- config set/get/unset roundtrip through the in-memory patched config.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from typer.testing import CliRunner

import familybugle_cli.config as cfg_module
from familybugle_cli.exceptions import FamilyBugleError
from familybugle_cli.main import app

runner = CliRunner()


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def tmp_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect config_path() to a temp dir and clear env var."""
    config_file = tmp_path / "config.toml"
    monkeypatch.setattr(cfg_module, "config_path", lambda: config_file)
    monkeypatch.delenv("FAMILYBUGLE_API_KEY", raising=False)
    monkeypatch.delenv("FAMILYBUGLE_API_URL", raising=False)
    return config_file


def _mock_client(return_values: dict) -> MagicMock:
    """Build a MagicMock FamilyBugleClient with preset return values.

    ``return_values`` maps method names → return values.
    """
    client = MagicMock()
    for method, value in return_values.items():
        getattr(client, method).return_value = value
    return client


# Sample data fixtures
_ACTIVITY_LIST = {
    "data": [
        {
            "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            "title": "Youth Basketball League",
            "provider_name": "Basin Recreation",
            "category": "Sports",
            "age_min": 6,
            "age_max": 12,
            "age_display": "6-12 years",
            "start_date": "2026-01-15",
            "end_date": "2026-03-25",
            "price": "150.00",
            "price_display": "$150",
        }
    ],
    "total": 1,
    "page": 1,
    "limit": 10,
    "pages": 1,
}

_PROVIDER_LIST = {
    "data": [
        {
            "id": "2fa85f64-5717-4562-b3fc-2c963f66afa6",
            "name": "Basin Recreation",
            "type": "recreation",
            "location_area": "Park City",
            "ages_served_min": 2,
            "ages_served_max": 18,
            "website": "https://basinrec.com",
        }
    ],
    "total": 1,
    "page": 1,
    "limit": 20,
    "pages": 1,
}

_ACTIVITY_DETAIL = {
    "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "title": "Youth Basketball League",
    "provider_name": "Basin Recreation",
    "category": "Sports",
    "age_display": "6-12 years",
    "start_date": "2026-01-15",
    "price_display": "$150",
    "source_url": "https://basinrec.com/basketball",
    "description": "10-week recreational basketball league.",
}

_PROVIDER_DETAIL = {
    "id": "2fa85f64-5717-4562-b3fc-2c963f66afa6",
    "name": "Basin Recreation",
    "type": "recreation",
    "location_area": "Park City",
    "website": "https://basinrec.com",
    "description": "Park City's premier recreation provider.",
}

_CATEGORIES = [{"name": "Sports"}, {"name": "Camps"}, {"name": "Classes"}]

_BREAKS = [
    {
        "id": "4fa85f64-5717-4562-b3fc-2c963f66afa6",
        "name": "Spring Break",
        "provider_name": "Park City School District",
        "break_type": "vacation",
        "start_date": "2026-04-06",
        "end_date": "2026-04-10",
    }
]

_ASK_RESULT = {
    "answer": "Spring break runs April 6–10, 2026.",
    "citations": [
        {
            "type": "activity",
            "id": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
            "name": "Spring Break Camp",
            "url": "https://basinrec.com/spring-camp",
        }
    ],
}


# ---------------------------------------------------------------------------
# --help and --version
# ---------------------------------------------------------------------------


def test_help_exits_zero() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "familybugle" in result.output.lower()


def test_version() -> None:
    from familybugle_cli import __version__

    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.output


# ---------------------------------------------------------------------------
# search command
# ---------------------------------------------------------------------------


def test_search_renders_table() -> None:
    """search should output a table containing the activity title."""
    mock_client = _mock_client({"list_activities": _ACTIVITY_LIST})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["search", "basketball"])
    assert result.exit_code == 0
    assert "Youth Basketball League" in result.output
    assert "Basin Recreation" in result.output


def test_search_with_age_filter() -> None:
    """--age flag should be forwarded to the client."""
    mock_client = _mock_client({"list_activities": _ACTIVITY_LIST})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["search", "basketball", "--age", "8"])
    assert result.exit_code == 0
    mock_client.list_activities.assert_called_once()
    call_kwargs = mock_client.list_activities.call_args.kwargs
    assert call_kwargs["age"] == 8


def test_search_json_flag() -> None:
    """--json should output raw JSON (contains 'data' key)."""
    mock_client = _mock_client({"list_activities": _ACTIVITY_LIST})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["search", "basketball", "--json"])
    assert result.exit_code == 0
    assert '"data"' in result.output


def test_search_api_error_exits_nonzero() -> None:
    """FamilyBugleError from search should exit with code 1."""
    mock_client = MagicMock()
    mock_client.list_activities.side_effect = FamilyBugleError("Rate limit reached.")
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["search", "ski"])
    assert result.exit_code == 1
    assert "Error" in result.output


# ---------------------------------------------------------------------------
# providers command
# ---------------------------------------------------------------------------


def test_providers_renders_table() -> None:
    mock_client = _mock_client({"list_providers": _PROVIDER_LIST})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["providers"])
    assert result.exit_code == 0
    assert "Basin Recreation" in result.output


def test_providers_type_filter() -> None:
    mock_client = _mock_client({"list_providers": _PROVIDER_LIST})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["providers", "--type", "recreation"])
    assert result.exit_code == 0
    call_kwargs = mock_client.list_providers.call_args.kwargs
    assert call_kwargs["type"] == "recreation"


# ---------------------------------------------------------------------------
# show activity / provider
# ---------------------------------------------------------------------------


def test_show_activity_renders_panel() -> None:
    mock_client = _mock_client({"get_activity": _ACTIVITY_DETAIL})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["show", "activity", "3fa85f64-5717-4562-b3fc-2c963f66afa6"])
    assert result.exit_code == 0
    assert "Youth Basketball League" in result.output


def test_show_provider_renders_panel() -> None:
    mock_client = _mock_client({"get_provider": _PROVIDER_DETAIL})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["show", "provider", "2fa85f64-5717-4562-b3fc-2c963f66afa6"])
    assert result.exit_code == 0
    assert "Basin Recreation" in result.output


# ---------------------------------------------------------------------------
# categories
# ---------------------------------------------------------------------------


def test_categories_renders_table() -> None:
    mock_client = _mock_client({"list_categories": _CATEGORIES})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["categories"])
    assert result.exit_code == 0
    assert "Sports" in result.output
    assert "Camps" in result.output


# ---------------------------------------------------------------------------
# breaks
# ---------------------------------------------------------------------------


def test_breaks_renders_table() -> None:
    mock_client = _mock_client({"list_school_breaks": _BREAKS})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["breaks"])
    assert result.exit_code == 0
    assert "Spring Break" in result.output
    assert "2026-04-06" in result.output


# ---------------------------------------------------------------------------
# ask command
# ---------------------------------------------------------------------------


def test_ask_renders_panel() -> None:
    """ask should output the answer in a panel."""
    mock_client = _mock_client({"ask": _ASK_RESULT})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["ask", "when is spring break?"])
    assert result.exit_code == 0
    assert "Spring break runs April 6" in result.output
    # Citations section
    assert "Sources" in result.output
    assert "Spring Break Camp" in result.output


def test_ask_json_flag() -> None:
    mock_client = _mock_client({"ask": _ASK_RESULT})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["ask", "when is spring break?", "--json"])
    assert result.exit_code == 0
    assert '"answer"' in result.output


def test_ask_api_error_exits_nonzero() -> None:
    mock_client = MagicMock()
    mock_client.ask.side_effect = FamilyBugleError("Server error (HTTP 500), please try again.")
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["ask", "test question"])
    assert result.exit_code == 1
    assert "Error" in result.output


# ---------------------------------------------------------------------------
# config set / get / unset
# ---------------------------------------------------------------------------


def test_config_set_and_get_api_key() -> None:
    """config set api-key then config get api-key should show masked key."""
    set_result = runner.invoke(app, ["config", "set", "api-key", "fb_live_abc123def456"])
    assert set_result.exit_code == 0
    assert "saved" in set_result.output.lower()

    get_result = runner.invoke(app, ["config", "get", "api-key"])
    assert get_result.exit_code == 0
    # Should show masked version (12 chars + ellipsis).
    assert "fb_live_abc1" in get_result.output
    assert "…" in get_result.output


def test_config_get_no_key_shows_help() -> None:
    """config get with no key stored should print guidance."""
    result = runner.invoke(app, ["config", "get", "api-key"])
    assert result.exit_code == 0
    assert "No API key" in result.output


def test_config_unset_api_key() -> None:
    """config unset api-key should remove the key."""
    runner.invoke(app, ["config", "set", "api-key", "fb_live_abc123def456"])
    unset_result = runner.invoke(app, ["config", "unset", "api-key"])
    assert unset_result.exit_code == 0

    get_result = runner.invoke(app, ["config", "get", "api-key"])
    assert "No API key" in get_result.output


# ---------------------------------------------------------------------------
# tuition command
# ---------------------------------------------------------------------------

_TUITION_RATE = {
    "id": "dddd0000-0000-0000-0000-000000000004",
    "program_name": "Full Day Preschool",
    "program_type": "preschool",
    "age_group": "3_to_4",
    "age_display": "3-4 years",
    "amount": "1200.00",
    "rate_type": "monthly",
    "category": "tuition",
    "days_per_week": 5,
    "notes": None,
}

_TUITION_RESULT = [
    {
        "id": "eeee0000-0000-0000-0000-000000000005",
        "provider_id": "bbbb0000-0000-0000-0000-000000000002",
        "provider_name": "Little Sprouts Preschool",
        "name": "2026-2027 Tuition",
        "season": "academic_year",
        "school_year": "2026-2027",
        "effective_date": "2026-09-01",
        "end_date": None,
        "payment_frequency": "monthly",
        "payment_notes": "Due on the 1st of each month.",
        "source_url": "https://littlesprouts.com/tuition",
        "notes": None,
        "rates": [_TUITION_RATE],
    }
]

_PROVIDER_UUID = "bbbb0000-0000-0000-0000-000000000002"


def test_tuition_renders_table() -> None:
    """tuition should output a rate table containing the program name."""
    mock_client = _mock_client({"get_tuition": _TUITION_RESULT})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["tuition", _PROVIDER_UUID])
    assert result.exit_code == 0
    assert "Full Day Preschool" in result.output
    assert "1200" in result.output


def test_tuition_renders_empty_gracefully() -> None:
    """tuition with no schedules should print a friendly message."""
    mock_client = _mock_client({"get_tuition": []})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["tuition", _PROVIDER_UUID])
    assert result.exit_code == 0
    assert "No tuition data" in result.output


def test_tuition_json_flag() -> None:
    """--json should output raw JSON."""
    mock_client = _mock_client({"get_tuition": _TUITION_RESULT})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["tuition", _PROVIDER_UUID, "--json"])
    assert result.exit_code == 0
    assert '"2026-2027 Tuition"' in result.output


def test_tuition_forwards_provider_id() -> None:
    """tuition should call get_tuition with the given provider UUID."""
    mock_client = _mock_client({"get_tuition": _TUITION_RESULT})
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        runner.invoke(app, ["tuition", _PROVIDER_UUID])
    mock_client.get_tuition.assert_called_once_with(_PROVIDER_UUID)


def test_tuition_api_error_exits_nonzero() -> None:
    """FamilyBugleError from get_tuition should exit with code 1."""
    mock_client = MagicMock()
    mock_client.get_tuition.side_effect = FamilyBugleError("Provider not found.")
    with patch("familybugle_cli.main._make_client", return_value=mock_client):
        result = runner.invoke(app, ["tuition", "no-such-id"])
    assert result.exit_code == 1
    assert "Error" in result.output
