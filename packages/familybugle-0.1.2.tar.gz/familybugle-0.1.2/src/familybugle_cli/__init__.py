"""Family Bugle CLI — Park City family activities, providers, and AI Q&A."""

__version__ = "0.1.2"
