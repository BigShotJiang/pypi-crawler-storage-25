"""User-facing exceptions for the familybugle CLI.

All errors raised by the client layer are converted to FamilyBugleError so
that command handlers can catch one exception type and display a clean,
human-readable message via Rich without leaking tracebacks.
"""


class FamilyBugleError(Exception):
    """Raised for any API or transport error that should be shown to the user.

    The message is meant to be printed directly — it should be clear and
    actionable, not a raw exception string.

    Example::

        raise FamilyBugleError(
            "Rate limit reached. Configure an API key via "
            "`familybugle config set api-key ...` for higher limits."
        )
    """
