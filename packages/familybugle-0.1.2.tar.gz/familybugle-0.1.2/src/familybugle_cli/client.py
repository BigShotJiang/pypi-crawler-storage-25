"""HTTP client for the Family Bugle public API v1.

Uses synchronous httpx — keeps the CLI simple and avoids async boilerplate
in command handlers. All methods raise ``FamilyBugleError`` on 4xx/5xx so
callers never have to inspect response status codes.

Error mapping:
    429 → rate limit message with hint to add an API key
    4xx → body detail from the API JSON error response
    5xx → generic "server error, please try again"
    transport error → network connectivity message

Usage::

    from familybugle_cli.client import FamilyBugleClient

    client = FamilyBugleClient(base_url="https://api.familybugle.com")
    result = client.list_activities(category="Sports", limit=10)
"""

from __future__ import annotations

from typing import Any

import httpx

from familybugle_cli import __version__
from familybugle_cli.exceptions import FamilyBugleError

_USER_AGENT = f"familybugle-cli/{__version__}"
_API_PREFIX = "/api/v1"


class FamilyBugleClient:
    """Thin synchronous wrapper around the Family Bugle REST API v1.

    Args:
        base_url: Base URL of the API server (no trailing slash).
        api_key:  Optional ``fb_live_...`` key sent as ``X-API-Key``.
        timeout:  Request timeout in seconds (default 30).
    """

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 30,
    ) -> None:
        headers: dict[str, str] = {"User-Agent": _USER_AGENT}
        if api_key:
            headers["X-API-Key"] = api_key

        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers=headers,
            timeout=timeout,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send a GET request and return the parsed JSON body.

        Raises:
            FamilyBugleError: on any HTTP 4xx/5xx or transport failure.
        """
        url = f"{_API_PREFIX}{path}"
        # Remove None-valued params so they're not sent as the string "None".
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        try:
            resp = self._client.get(url, params=clean_params)
        except httpx.TransportError as exc:
            raise FamilyBugleError(
                f"Network error — could not reach the API: {exc}"
            ) from exc

        self._raise_for_status(resp)
        return resp.json()

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        """Send a POST request with JSON body and return the parsed JSON body."""
        url = f"{_API_PREFIX}{path}"
        try:
            resp = self._client.post(url, json=body)
        except httpx.TransportError as exc:
            raise FamilyBugleError(
                f"Network error — could not reach the API: {exc}"
            ) from exc

        self._raise_for_status(resp)
        return resp.json()

    @staticmethod
    def _raise_for_status(resp: httpx.Response) -> None:
        """Map HTTP error status codes to FamilyBugleError."""
        if resp.is_success:
            return

        if resp.status_code == 429:
            raise FamilyBugleError(
                "Rate limit reached. Configure an API key via "
                "`familybugle config set api-key <key>` for higher limits."
            )

        if 400 <= resp.status_code < 500:
            # Try to pull a detail message from the response body.
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text or f"HTTP {resp.status_code}"
            raise FamilyBugleError(f"API error ({resp.status_code}): {detail}")

        # 5xx
        raise FamilyBugleError(
            f"Server error (HTTP {resp.status_code}), please try again."
        )

    # ------------------------------------------------------------------
    # API methods — one per v1 endpoint
    # ------------------------------------------------------------------

    def list_activities(
        self,
        *,
        search: str | None = None,
        category: str | None = None,
        age: int | None = None,
        date_from: str | None = None,
        date_to: str | None = None,
        provider_id: str | None = None,
        price_max: int | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> dict[str, Any]:
        """Fetch a paginated list of activities.

        Returns the raw ``ActivityListV1`` dict with keys
        ``data``, ``total``, ``page``, ``limit``, ``pages``.

        Args:
            search: Optional free-text search on activity name/description.
        """
        return self._get(
            "/activities",
            {
                "search": search,
                "category": category,
                "age": age,
                "date_from": date_from,
                "date_to": date_to,
                "provider_id": provider_id,
                "price_max": price_max,
                "page": page,
                "limit": limit,
            },
        )

    def get_activity(self, activity_id: str) -> dict[str, Any]:
        """Fetch a single activity by UUID."""
        return self._get(f"/activities/{activity_id}")

    def list_providers(
        self,
        *,
        type: str | None = None,
        location_area: str | None = None,
        search: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> dict[str, Any]:
        """Fetch a paginated list of providers.

        Returns the raw ``ProviderListV1`` dict.
        """
        return self._get(
            "/providers",
            {
                "type": type,
                "location_area": location_area,
                "search": search,
                "page": page,
                "limit": limit,
            },
        )

    def get_provider(self, provider_id: str) -> dict[str, Any]:
        """Fetch a single provider by UUID."""
        return self._get(f"/providers/{provider_id}")

    def list_categories(self) -> list[dict[str, Any]]:
        """Fetch all activity categories."""
        return self._get("/categories")  # type: ignore[return-value]

    def list_school_breaks(self, *, limit: int = 20) -> list[dict[str, Any]]:
        """Fetch upcoming school breaks."""
        return self._get("/school-breaks", {"limit": limit})  # type: ignore[return-value]

    def get_tuition(self, provider_id: str) -> list[dict[str, Any]]:
        """Fetch tuition schedules for a provider by UUID."""
        return self._get("/tuition", {"provider_id": provider_id})  # type: ignore[return-value]

    def ask(self, question: str) -> dict[str, Any]:
        """Send a natural-language question and receive an answer with citations."""
        return self._post("/ask", {"question": question})
