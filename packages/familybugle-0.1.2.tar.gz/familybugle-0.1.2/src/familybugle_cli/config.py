"""Configuration management for the familybugle CLI.

Stores user settings in ``~/.config/familybugle/config.toml`` (XDG-compliant
via platformdirs). The API key is sensitive, so the config file is written with
mode 0600 on every save.

Resolution order for API key:
    1. ``FAMILYBUGLE_API_KEY`` environment variable
    2. ``api_key`` in config file
    3. ``None`` (public/unauthenticated tier)

Resolution order for API URL:
    1. ``FAMILYBUGLE_API_URL`` environment variable
    2. ``--api-url`` CLI flag (handled in main.py)
    3. Default ``https://api.familybugle.com``
"""

from __future__ import annotations

import os
import tempfile
import tomllib
from pathlib import Path

import platformdirs
import tomli_w

# ---------------------------------------------------------------------------
# Config file path
# ---------------------------------------------------------------------------

_APP_NAME = "familybugle"
_APP_AUTHOR = "FamilyBugle"


def config_path() -> Path:
    """Return the path to the config file (may not exist yet).

    Uses platformdirs for cross-platform XDG compliance::

        macOS:   ~/Library/Application Support/FamilyBugle/familybugle/config.toml
        Linux:   ~/.config/familybugle/config.toml
        Windows: %APPDATA%/FamilyBugle/familybugle/config.toml
    """
    config_dir = Path(platformdirs.user_config_dir(_APP_NAME, _APP_AUTHOR))
    return config_dir / "config.toml"


# ---------------------------------------------------------------------------
# Load / save helpers
# ---------------------------------------------------------------------------


def _load_raw() -> dict:
    """Load the raw config dict from disk. Returns empty dict if file absent."""
    path = config_path()
    if not path.exists():
        return {}
    with path.open("rb") as fh:
        return tomllib.load(fh)


def _save_raw(data: dict) -> None:
    """Write ``data`` to the config file with mode 0600.

    Uses a tempfile + os.replace pattern to avoid a race window where
    the file sits world-readable between write and chmod.  The fd is
    fchmod'd to 0600 before any content is written, so the file is
    never visible at a less-restrictive mode.

    Creates parent directories as needed.
    """
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(dir=path.parent, prefix=".config_")
    try:
        # Restrict permissions before writing — no window where the file
        # exists at the umask default (often 0644).
        os.fchmod(tmp_fd, 0o600)
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as fh:
            fh.write(tomli_w.dumps(data))
        # Atomic replace — the final path goes from old content directly
        # to new content; no intermediate state is ever visible.
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass
        raise


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_api_key() -> str | None:
    """Return the resolved API key, or None if unset.

    Checks ``FAMILYBUGLE_API_KEY`` env var first, then the config file.
    """
    env_key = os.environ.get("FAMILYBUGLE_API_KEY")
    if env_key:
        return env_key
    data = _load_raw()
    return data.get("api_key") or None


def set_api_key(key: str) -> None:
    """Store *key* in the config file (mode 0600)."""
    data = _load_raw()
    data["api_key"] = key
    _save_raw(data)


def unset_api_key() -> None:
    """Remove the stored API key from the config file.

    Does nothing if no key is stored.
    """
    data = _load_raw()
    data.pop("api_key", None)
    _save_raw(data)


def get_api_url() -> str | None:
    """Return ``FAMILYBUGLE_API_URL`` env override, or None if unset."""
    return os.environ.get("FAMILYBUGLE_API_URL") or None


def mask_key(key: str) -> str:
    """Return a masked representation of an API key for display.

    Shows the prefix up to and including the first underscore-separated
    segment after the scheme (``fb_live_``) plus the first four characters
    of the secret, then an ellipsis::

        fb_live_abc1def2ghij…
    """
    if len(key) <= 12:
        return key[:4] + "…"
    # Show everything up to 12 chars, then ellipsis.
    return key[:12] + "…"
