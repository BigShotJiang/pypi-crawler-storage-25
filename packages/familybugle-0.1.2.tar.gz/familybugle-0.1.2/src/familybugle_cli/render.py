"""Rich rendering helpers for familybugle CLI output.

Each public function either returns a Rich renderable or prints directly to
the console using ``rich.print``.  All tables use ``box.ROUNDED`` for a modern
look. Color palette: orange/amber accent (matching the brand), dim text for
secondary info, green for free prices.

Design principles:
- Bold name/title in the first column.
- Dim text for secondary columns (provider, date, category).
- Price column: green + bold for free, default otherwise.
- Every table-based view ends with a footer hint showing how to get more detail.
"""

from __future__ import annotations

from typing import Any

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()

# Brand-aligned accent colour used for panel borders and section headers.
_ACCENT = "bold orange1"
_DIM = "dim"
_FREE_STYLE = "bold green"
_PRICE_STYLE = "default"


# ---------------------------------------------------------------------------
# Activity helpers
# ---------------------------------------------------------------------------


def _fmt_price(item: dict[str, Any]) -> Text:
    """Return a styled price cell.

    Uses ``price_display`` if available; falls back to raw ``price``.
    Free activities get a green "Free" label.
    """
    display = item.get("price_display") or ""
    price = item.get("price")

    # Treat display text as "Free" if it parses to zero or is a known free label.
    # This catches "0.00", "$0", "0", and "free" without an exhaustive list.
    if display:
        try:
            if float(display.lstrip("$")) == 0.0:
                return Text("Free", style=_FREE_STYLE)
        except ValueError:
            pass
        if display.lower() == "free":
            return Text("Free", style=_FREE_STYLE)
        return Text(display, style=_PRICE_STYLE, justify="right")
    if price is not None:
        if float(price) == 0:
            return Text("Free", style=_FREE_STYLE)
        return Text(f"${float(price):.0f}", style=_PRICE_STYLE, justify="right")
    return Text("—", style=_DIM, justify="right")


def _fmt_ages(item: dict[str, Any]) -> str:
    """Return a compact age-range string."""
    display = item.get("age_display")
    if display:
        return display
    age_min = item.get("age_min")
    age_max = item.get("age_max")
    if age_min is not None and age_max is not None:
        return f"{age_min}–{age_max} yrs"
    if age_min is not None:
        return f"{age_min}+ yrs"
    if age_max is not None:
        return f"up to {age_max} yrs"
    return "—"


def _fmt_date(item: dict[str, Any]) -> str:
    """Return start date or '—'."""
    d = item.get("start_date")
    return d if d else "—"


# ---------------------------------------------------------------------------
# Public render functions
# ---------------------------------------------------------------------------


def render_activity_table(result: dict[str, Any]) -> None:
    """Print a Rich table of activities from a ``ActivityListV1`` dict.

    Columns: Name, Provider, Ages, Date, Price.
    Footer shows count and a hint to use ``show activity <id>``.
    """
    items: list[dict[str, Any]] = result.get("data", [])
    total: int = result.get("total", 0)
    page: int = result.get("page", 1)
    limit: int = result.get("limit", 20)

    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold",
        expand=False,
        title=None,
    )

    table.add_column("Name", style="bold", min_width=24, max_width=40)
    table.add_column("Provider", style=_DIM, max_width=22)
    table.add_column("Ages", max_width=14)
    table.add_column("Date", max_width=12)
    table.add_column("Price", justify="right", max_width=10)

    for item in items:
        table.add_row(
            item.get("title", "—"),
            item.get("provider_name") or "—",
            _fmt_ages(item),
            _fmt_date(item),
            _fmt_price(item),
        )

    console.print(table)

    # Footer
    if not items:
        console.print(Text("  No activities found.", style=_DIM))
        return

    shown = (page - 1) * limit + len(items)
    footer = Text()
    footer.append(f"  Showing {shown} of {total}", style=_DIM)
    if items:
        sample_id = items[0].get("id", "<id>")
        footer.append(f"  —  familybugle show activity {sample_id}", style="dim italic")
    console.print(footer)


def render_activity_detail(item: dict[str, Any]) -> None:
    """Print a Rich Panel showing full activity detail."""
    title_text = Text()
    title_text.append(item.get("title", "Activity"), style=_ACCENT)

    lines: list[str] = []
    if prov := item.get("provider_name"):
        lines.append(f"[dim]Provider:[/dim]  {prov}")
    if cat := item.get("category"):
        sub = item.get("subcategory")
        lines.append(f"[dim]Category:[/dim]  {cat}" + (f" › {sub}" if sub else ""))
    lines.append(f"[dim]Ages:[/dim]      {_fmt_ages(item)}")

    if item.get("start_date"):
        date_str = item["start_date"]
        if item.get("end_date") and item["end_date"] != date_str:
            date_str += f" – {item['end_date']}"
        lines.append(f"[dim]Dates:[/dim]     {date_str}")

    if item.get("schedule_description"):
        lines.append(f"[dim]Schedule:[/dim] {item['schedule_description']}")

    if item.get("location_name"):
        loc = item["location_name"]
        if item.get("address"):
            loc += f", {item['address']}"
        lines.append(f"[dim]Location:[/dim] {loc}")

    price_text = _fmt_price(item)
    lines.append(f"[dim]Price:[/dim]     {price_text.plain}")

    if item.get("registration_status"):
        spots = item.get("spots_remaining")
        status = item["registration_status"]
        if spots is not None:
            status += f" ({spots} spots remaining)"
        lines.append(f"[dim]Status:[/dim]   {status}")

    if item.get("description"):
        lines.append("")
        lines.append(item["description"])

    if item.get("source_url"):
        lines.append("")
        lines.append(f"[dim]More info:[/dim] {item['source_url']}")

    panel = Panel(
        "\n".join(lines),
        title=item.get("title", "Activity"),
        border_style="orange1",
        expand=False,
    )
    console.print(panel)


# ---------------------------------------------------------------------------
# Provider rendering
# ---------------------------------------------------------------------------


def render_provider_table(result: dict[str, Any]) -> None:
    """Print a Rich table of providers from a ``ProviderListV1`` dict."""
    items: list[dict[str, Any]] = result.get("data", [])
    total: int = result.get("total", 0)
    page: int = result.get("page", 1)
    limit: int = result.get("limit", 20)

    table = Table(
        box=box.ROUNDED,
        show_header=True,
        header_style="bold",
        expand=False,
    )

    table.add_column("Name", style="bold", min_width=22, max_width=36)
    table.add_column("Type", style=_DIM, max_width=14)
    table.add_column("Location", max_width=20)
    table.add_column("Ages", max_width=14)
    table.add_column("Website", style=_DIM, max_width=32)

    for item in items:
        age_min = item.get("ages_served_min")
        age_max = item.get("ages_served_max")
        if age_min is not None and age_max is not None:
            ages = f"{age_min}–{age_max} yrs"
        elif age_min is not None:
            ages = f"{age_min}+ yrs"
        else:
            ages = "—"

        table.add_row(
            item.get("name", "—"),
            item.get("type", "—"),
            item.get("location_area") or "—",
            ages,
            item.get("website") or "—",
        )

    console.print(table)

    if not items:
        console.print(Text("  No providers found.", style=_DIM))
        return

    shown = (page - 1) * limit + len(items)
    footer = Text()
    footer.append(f"  Showing {shown} of {total}", style=_DIM)
    if items:
        sample_id = items[0].get("id", "<id>")
        footer.append(f"  —  familybugle show provider {sample_id}", style="dim italic")
    console.print(footer)


def render_provider_detail(item: dict[str, Any]) -> None:
    """Print a Rich Panel showing full provider detail."""
    lines: list[str] = []
    if item.get("type"):
        lines.append(f"[dim]Type:[/dim]     {item['type']}")
    if item.get("location_area"):
        lines.append(f"[dim]Location:[/dim] {item['location_area']}")
    if item.get("address"):
        lines.append(f"[dim]Address:[/dim]  {item['address']}")
    if item.get("phone"):
        lines.append(f"[dim]Phone:[/dim]    {item['phone']}")
    if item.get("email"):
        lines.append(f"[dim]Email:[/dim]    {item['email']}")
    if item.get("website"):
        lines.append(f"[dim]Website:[/dim]  {item['website']}")
    if item.get("hours_of_operation"):
        lines.append(f"[dim]Hours:[/dim]    {item['hours_of_operation']}")

    age_min = item.get("ages_served_min")
    age_max = item.get("ages_served_max")
    if age_min is not None or age_max is not None:
        if age_min is not None and age_max is not None:
            ages = f"{age_min}–{age_max} yrs"
        elif age_min is not None:
            ages = f"{age_min}+ yrs"
        else:
            ages = f"up to {age_max} yrs"
        lines.append(f"[dim]Ages served:[/dim] {ages}")

    if item.get("programs_offered"):
        lines.append(f"[dim]Programs:[/dim] {', '.join(item['programs_offered'])}")
    if item.get("features"):
        lines.append(f"[dim]Features:[/dim] {', '.join(item['features'])}")
    if item.get("accreditations"):
        lines.append(f"[dim]Accreditations:[/dim] {', '.join(item['accreditations'])}")
    if item.get("has_waitlist"):
        lines.append("[yellow]⚠ This provider currently has a waitlist.[/yellow]")

    if item.get("description"):
        lines.append("")
        lines.append(item["description"])

    panel = Panel(
        "\n".join(lines),
        title=item.get("name", "Provider"),
        border_style="orange1",
        expand=False,
    )
    console.print(panel)


# ---------------------------------------------------------------------------
# Categories
# ---------------------------------------------------------------------------


def render_categories(categories: list[dict[str, Any]]) -> None:
    """Print a compact list of category names."""
    if not categories:
        console.print(Text("  No categories found.", style=_DIM))
        return

    table = Table(box=box.ROUNDED, header_style="bold", expand=False, show_header=True)
    table.add_column("Category", style="bold", min_width=20)
    for cat in categories:
        table.add_row(cat.get("name", "—"))
    console.print(table)


# ---------------------------------------------------------------------------
# School breaks
# ---------------------------------------------------------------------------


def render_breaks(breaks: list[dict[str, Any]]) -> None:
    """Print upcoming school breaks as a table."""
    if not breaks:
        console.print(Text("  No upcoming school breaks.", style=_DIM))
        return

    table = Table(box=box.ROUNDED, header_style="bold", expand=False, show_header=True)
    table.add_column("Name", style="bold", min_width=20)
    table.add_column("School / Provider", style=_DIM, max_width=28)
    table.add_column("Type", max_width=16)
    table.add_column("Start", max_width=12)
    table.add_column("End", max_width=12)

    for brk in breaks:
        table.add_row(
            brk.get("name", "—"),
            brk.get("provider_name") or "—",
            brk.get("break_type", "—").replace("_", " ").title(),
            brk.get("start_date", "—"),
            brk.get("end_date", "—"),
        )

    console.print(table)


# ---------------------------------------------------------------------------
# Tuition
# ---------------------------------------------------------------------------


def render_tuition(schedules: list[dict[str, Any]]) -> None:
    """Print tuition schedules as tables, one per schedule."""
    if not schedules:
        console.print(Text("  No tuition data found for this provider.", style=_DIM))
        return

    for schedule in schedules:
        name = schedule.get("name", "Tuition")
        season = schedule.get("season", "")
        year = schedule.get("school_year", "")
        subtitle_parts = [s for s in [season.title() if season else "", year] if s]
        subtitle = " · ".join(subtitle_parts)

        rates: list[dict[str, Any]] = schedule.get("rates", [])

        table = Table(
            box=box.ROUNDED,
            header_style="bold",
            expand=False,
            show_header=True,
            title=name + (f"  ({subtitle})" if subtitle else ""),
        )
        table.add_column("Program", style="bold", min_width=20, max_width=36)
        table.add_column("Age Group", max_width=14)
        table.add_column("Days/Wk", max_width=8, justify="right")
        table.add_column("Amount", max_width=12, justify="right")
        table.add_column("Per", max_width=12)

        for rate in rates:
            amount = rate.get("amount")
            rate_type = rate.get("rate_type", "")
            amount_str = f"${float(amount):.0f}" if amount is not None else "—"
            days = rate.get("days_per_week")

            table.add_row(
                rate.get("program_name") or rate.get("program_type", "—"),
                rate.get("age_display") or rate.get("age_group", "—"),
                str(days) if days is not None else "—",
                amount_str,
                rate_type.replace("_", " ").title() if rate_type else "—",
            )

        if not rates:
            console.print(Text("  No rate line items found.", style=_DIM))
        else:
            console.print(table)

        if schedule.get("payment_notes"):
            console.print(Text(f"  {schedule['payment_notes']}", style=_DIM))
        if schedule.get("source_url"):
            console.print(Text(f"  More info: {schedule['source_url']}", style=_DIM))


# ---------------------------------------------------------------------------
# Ask / Q&A
# ---------------------------------------------------------------------------


def render_ask(result: dict[str, Any]) -> None:
    """Print the AI answer and citations as a Rich Panel."""
    answer = result.get("answer", "")
    citations: list[dict[str, Any]] = result.get("citations", [])

    body_lines = [answer]

    if citations:
        body_lines.append("")
        body_lines.append("[dim]Sources:[/dim]")
        for cite in citations:
            name = cite.get("name", "—")
            url = cite.get("url") or ""
            ctype = cite.get("type", "")
            cite_line = f"  [dim]• {ctype}:[/dim] {name}"
            if url:
                cite_line += f"  [dim italic]{url}[/dim italic]"
            body_lines.append(cite_line)

    panel = Panel(
        "\n".join(body_lines),
        title="[bold orange1]Family Bugle AI[/bold orange1]",
        border_style="orange1",
        expand=False,
        padding=(1, 2),
    )
    console.print(panel)
