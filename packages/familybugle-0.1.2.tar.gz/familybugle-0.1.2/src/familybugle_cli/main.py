"""familybugle CLI — command definitions and wiring.

Entry point: ``familybugle_cli.main:app``

All commands share a ``--api-url`` option (resolved from FAMILYBUGLE_API_URL
env var first, then the flag default). The API key is always read from config
automatically — no per-command auth flag needed.

Command tree:
    familybugle search <query>               # search activities
    familybugle providers                    # list providers
    familybugle show activity <id>           # activity detail
    familybugle show provider <id>           # provider detail
    familybugle categories                   # list categories
    familybugle breaks                       # list upcoming school breaks
    familybugle tuition <provider_id>        # show tuition rates for a provider
    familybugle ask <question>               # natural-language Q&A
    familybugle config set api-key <key>     # store API key
    familybugle config get api-key           # display masked API key
    familybugle config unset api-key         # remove API key
    familybugle --version                    # print version
"""

from __future__ import annotations

from typing import Annotated

import typer

from familybugle_cli import __version__
from familybugle_cli.client import FamilyBugleClient
from familybugle_cli.config import (
    get_api_key,
    get_api_url,
    mask_key,
    set_api_key,
    unset_api_key,
)
from familybugle_cli.exceptions import FamilyBugleError
from familybugle_cli.render import (
    console,
    render_activity_detail,
    render_activity_table,
    render_ask,
    render_breaks,
    render_categories,
    render_provider_detail,
    render_provider_table,
    render_tuition,
)

# ---------------------------------------------------------------------------
# App & callback
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="familybugle",
    help=(
        "Family Bugle CLI — browse Park City activities, providers, school breaks, "
        "and ask AI questions about local family resources."
    ),
    add_completion=False,
    no_args_is_help=True,
)

_DEFAULT_API_URL = "https://api.familybugle.com"

# Annotated type alias for the shared --api-url flag used across commands.
# Declared once and reused so each handler just annotates with ApiUrlArg.
ApiUrlArg = Annotated[
    str,
    typer.Option(
        "--api-url",
        help="Override the API base URL (e.g. http://localhost:8000 for local dev). "
        "Env: FAMILYBUGLE_API_URL",
        envvar="FAMILYBUGLE_API_URL",
    ),
]


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"familybugle {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Family Bugle CLI."""


# ---------------------------------------------------------------------------
# Shared helper
# ---------------------------------------------------------------------------


def _make_client(api_url: str) -> FamilyBugleClient:
    """Build a client using the resolved URL and stored API key."""
    # FAMILYBUGLE_API_URL env var is already handled by typer envvar= above.
    # get_api_url() provides a second env-var lookup for completeness; the
    # typer envvar path takes precedence when the flag is processed.
    url = api_url or get_api_url() or _DEFAULT_API_URL
    return FamilyBugleClient(base_url=url, api_key=get_api_key())


def _handle_error(exc: FamilyBugleError) -> None:
    """Print a user-friendly error and exit non-zero."""
    console.print(f"[bold red]Error:[/bold red] {exc}")
    raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# search command
# ---------------------------------------------------------------------------


@app.command()
def search(
    query: Annotated[str, typer.Argument(help="Search term, e.g. 'ski lessons'")],
    age: Annotated[int | None, typer.Option("--age", "-a", help="Child age in years")] = None,
    category: Annotated[
        str | None, typer.Option("--category", "-c", help="Category filter, e.g. Sports")
    ] = None,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Max results (1-100)")] = 10,
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a table")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """Search activities by keyword, with optional age and category filters."""
    client = _make_client(api_url)
    with console.status("Searching activities…", spinner="dots"):
        try:
            result = client.list_activities(
                search=query,
                category=category,
                age=age,
                limit=min(limit, 100),
            )
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(result))
        return

    render_activity_table(result)


# ---------------------------------------------------------------------------
# providers command
# ---------------------------------------------------------------------------


@app.command()
def providers(
    type: Annotated[
        str | None,
        typer.Option("--type", "-t", help="Provider type: recreation, daycare, school, gym, camp"),
    ] = None,
    location: Annotated[
        str | None, typer.Option("--location", "-l", help="Location area, e.g. 'Old Town'")
    ] = None,
    search: Annotated[
        str | None, typer.Option("--search", "-s", help="Text search by provider name")
    ] = None,
    limit: Annotated[int, typer.Option("--limit", "-n", help="Max results (1-100)")] = 20,
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a table")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """List providers, with optional type, location, and name filters."""
    client = _make_client(api_url)
    with console.status("Loading providers…", spinner="dots"):
        try:
            result = client.list_providers(
                type=type,
                location_area=location,
                search=search,
                limit=min(limit, 100),
            )
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(result))
        return

    render_provider_table(result)


# ---------------------------------------------------------------------------
# show command group
# ---------------------------------------------------------------------------

show_app = typer.Typer(help="Show full details for a single activity or provider.")
app.add_typer(show_app, name="show")


@show_app.command("activity")
def show_activity(
    id: Annotated[str, typer.Argument(help="Activity UUID")],
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a panel")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """Show full detail for a single activity."""
    client = _make_client(api_url)
    with console.status("Loading activity…", spinner="dots"):
        try:
            item = client.get_activity(id)
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(item))
        return

    render_activity_detail(item)


@show_app.command("provider")
def show_provider(
    id: Annotated[str, typer.Argument(help="Provider UUID")],
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a panel")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """Show full detail for a single provider."""
    client = _make_client(api_url)
    with console.status("Loading provider…", spinner="dots"):
        try:
            item = client.get_provider(id)
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(item))
        return

    render_provider_detail(item)


# ---------------------------------------------------------------------------
# categories command
# ---------------------------------------------------------------------------


@app.command()
def categories(
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a table")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """List all available activity categories."""
    client = _make_client(api_url)
    with console.status("Loading categories…", spinner="dots"):
        try:
            result = client.list_categories()
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(result))
        return

    render_categories(result)


# ---------------------------------------------------------------------------
# breaks command
# ---------------------------------------------------------------------------


@app.command()
def breaks(
    limit: Annotated[
        int, typer.Option("--limit", "-n", help="Number of upcoming breaks to show")
    ] = 20,
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a table")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """List upcoming school calendar breaks."""
    client = _make_client(api_url)
    with console.status("Loading school breaks…", spinner="dots"):
        try:
            result = client.list_school_breaks(limit=min(limit, 100))
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(result))
        return

    render_breaks(result)


# ---------------------------------------------------------------------------
# tuition command
# ---------------------------------------------------------------------------


@app.command()
def tuition(
    provider_id: Annotated[
        str,
        typer.Argument(
            help="Provider UUID — get this from 'familybugle providers' or 'familybugle show provider'"
        ),
    ],
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of tables")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """Show tuition rate schedules for a daycare or school."""
    client = _make_client(api_url)
    with console.status("Loading tuition schedules…", spinner="dots"):
        try:
            result = client.get_tuition(provider_id)
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(result))
        return

    render_tuition(result)


# ---------------------------------------------------------------------------
# ask command
# ---------------------------------------------------------------------------


@app.command()
def ask(
    question: Annotated[
        str,
        typer.Argument(help="Natural-language question, e.g. 'when is spring break?'"),
    ],
    json_output: Annotated[
        bool, typer.Option("--json", help="Output raw JSON instead of a panel")
    ] = False,
    api_url: ApiUrlArg = _DEFAULT_API_URL,
) -> None:
    """Ask a natural-language question about Park City family resources."""
    client = _make_client(api_url)
    with console.status("Thinking…", spinner="dots"):
        try:
            result = client.ask(question)
        except FamilyBugleError as exc:
            _handle_error(exc)
            return

    if json_output:
        import json

        console.print_json(json.dumps(result))
        return

    render_ask(result)


# ---------------------------------------------------------------------------
# config command group
# ---------------------------------------------------------------------------

config_app = typer.Typer(help="Manage familybugle CLI configuration.")
app.add_typer(config_app, name="config")

# ---- config set ----
set_app = typer.Typer(help="Set a configuration value.")
config_app.add_typer(set_app, name="set")


@set_app.command("api-key")
def config_set_api_key(
    key: Annotated[str, typer.Argument(help="API key starting with fb_live_...")],
) -> None:
    """Store an API key in the local config file (~/.config/familybugle/config.toml)."""
    if not key.startswith("fb_"):
        console.print(
            "[yellow]Warning:[/yellow] Key does not start with 'fb_'. "
            "Double-check you have the right value."
        )
    set_api_key(key)
    console.print(f"[green]API key saved.[/green] ({mask_key(key)})")


# ---- config get ----
get_app = typer.Typer(help="Get a configuration value.")
config_app.add_typer(get_app, name="get")


@get_app.command("api-key")
def config_get_api_key() -> None:
    """Print the currently stored API key (masked)."""
    key = get_api_key()
    if not key:
        console.print("[dim]No API key configured.[/dim]")
        console.print(
            "Run [bold]familybugle config set api-key <key>[/bold] to add one, "
            "or sign in at [bold]familybugle.com/account[/bold] → Developer tab."
        )
        return
    console.print(f"API key: [bold]{mask_key(key)}[/bold]")


# ---- config unset ----
unset_app = typer.Typer(help="Remove a configuration value.")
config_app.add_typer(unset_app, name="unset")


@unset_app.command("api-key")
def config_unset_api_key() -> None:
    """Remove the stored API key from the local config file."""
    unset_api_key()
    console.print("[green]API key removed.[/green]")
