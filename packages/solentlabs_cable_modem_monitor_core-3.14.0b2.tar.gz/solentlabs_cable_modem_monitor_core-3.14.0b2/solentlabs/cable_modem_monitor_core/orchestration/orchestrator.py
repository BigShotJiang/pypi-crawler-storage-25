"""Orchestrator — policy engine for modem data collection.

Coordinates ModemDataCollector, HealthMonitor, and Recovery.
Delegates signal policy to SignalPolicy, status derivation to pure
functions, and restart dispatch to :func:`run_restart`.

Consumers call get_modem_data() when they want data. The orchestrator
applies backoff and lockout protection regardless of why it was called.
No scheduling or threads — consumers manage their own cadence.

See ORCHESTRATION_SPEC.md for interface contracts and
RUNTIME_POLLING_SPEC.md for behavioral rules.
"""

from __future__ import annotations

import logging
import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from .models import ModemSnapshot, OrchestratorDiagnostics, RestartResult
from .policy import SignalPolicy
from .recovery import Recovery
from .restart import RestartNotSupportedError, run_restart
from .signals import (
    CollectorSignal,
    ConnectionStatus,
    DocsisStatus,
    HealthStatus,
)
from .status import derive_connection_status, enrich_docsis_status

if TYPE_CHECKING:
    from collections.abc import Callable

    from ..models.modem_config.config import ModemConfig
    from .collector import ModemDataCollector
    from .models import HealthInfo, ModemResult
    from .modem_health import HealthMonitor

_logger = logging.getLogger(__name__)

# Re-export so existing imports (tests, HA) keep working.
__all__ = ["Orchestrator", "RestartNotSupportedError"]


class Orchestrator:
    """Policy engine for modem data collection.

    Coordinates the collector with backoff, circuit breaker, and status
    derivation. Exposes a synchronous API — consumers wrap it for their
    platform's scheduling model.

    Args:
        collector: ModemDataCollector instance (reused across polls).
        health_monitor: Optional health probe monitor. None if the
            modem doesn't support ICMP or HTTP HEAD probes.
        modem_config: Parsed modem.yaml config. Used for identity
            (model) and actions (restart, logout).
    """

    AUTH_FAILURE_THRESHOLD: int = 6

    def __init__(
        self,
        collector: ModemDataCollector,
        health_monitor: HealthMonitor | None,
        modem_config: ModemConfig,
    ) -> None:
        self._collector = collector
        self._health_monitor = health_monitor
        self._modem_config = modem_config

        # Policy — signal→policy mapping, auth circuit breaker, and
        # connectivity backoff all live in SignalPolicy.
        self._policy = SignalPolicy(collector, self.AUTH_FAILURE_THRESHOLD, model=modem_config.model)

        # Recovery — owns the polling-cadence window triggered by
        # restart, connectivity outage, or the reboot-signal vote.
        # 2C wires tick/evaluate_snapshot/evaluate_failure into the
        # collection flow; here we only construct it so run_restart
        # has a destination for recovery.begin().
        self._recovery = Recovery(collector=collector, modem_config=modem_config)

        # Last connection status — used to detect UNREACHABLE→ONLINE
        # transitions and emit a single INFO log line.
        self._last_status: ConnectionStatus | None = None

        # First-poll verbose logging — INFO on first poll and after
        # reset_auth(), DEBUG on steady-state
        self._first_poll_complete: bool = False

        # Counter-reset detection — proxy for "last boot time" when
        # the modem doesn't report native uptime (see #110)
        self._prev_error_totals: tuple[int, int] | None = None  # (corrected, uncorrected)
        self._stats_last_reset: datetime | None = None

        # Diagnostics state
        self._last_poll_duration: float | None = None
        self._last_poll_timestamp: float | None = None

        # Monotonic timestamp of the last CONNECTIVITY failure. Used
        # by the "health recovery clears connectivity backoff"
        # shortcut in _execute_poll() to avoid trusting a cached
        # RESPONSIVE reading that pre-dates the outage. The health
        # coordinator runs on its own (slower) cadence, so between
        # a modem going down and the next health probe, latest
        # would otherwise report stale RESPONSIVE.
        self._last_connectivity_failure_at: float | None = None

    def get_modem_data(self) -> ModemSnapshot:
        """Execute a data collection cycle.

        Sequence:
        1. Check circuit breaker — if open, return AUTH_FAILED
        2. Check backoff — if active, decrement and return AUTH_FAILED
        3. Run ModemDataCollector
        4. If collection failed, apply signal policy
        5. On success: reset streak, derive statuses
        6. Detect state transitions
        7. Return ModemSnapshot

        Returns:
            ModemSnapshot with modem data, health info, and derived
            status fields.
        """
        start = time.monotonic()

        try:
            snapshot = self._execute_poll()
        finally:
            self._last_poll_duration = time.monotonic() - start
            self._last_poll_timestamp = start

        return snapshot

    def restart(self) -> RestartResult:
        """Send the restart command. One-shot; does not wait.

        Bypasses the auth circuit breaker — the user pressed the
        button, so a recent auth failure should not block the
        restart. Returns quickly (2–5 s): authenticate, dispatch the
        reboot command, clear the session, trigger a recovery window,
        return.

        Does NOT observe the reboot. The snapshot stream surfaces
        real modem state (UNREACHABLE → ranging → ONLINE) as normal
        polling runs at recovery cadence.

        Returns:
            RestartResult — ``success`` is True iff the command
            dispatched cleanly; ``error="command_failed"`` otherwise.

        Raises:
            RestartNotSupportedError: If modem has no restart action.
        """
        return run_restart(self._collector, self._modem_config, self._recovery)

    def reset_auth(self) -> None:
        """Reset auth state after credential reconfiguration.

        Called by the client after the user updates credentials.
        Clears all auth-related state so the next get_modem_data()
        starts with a clean slate.
        """
        self._policy.reset()
        self._collector.clear_session()
        self._first_poll_complete = False
        _logger.info("Auth state reset — next poll will attempt fresh login")

    def reset_connectivity(self) -> None:
        """Reset connectivity backoff for immediate retry.

        Called when the user requests a manual refresh. Clears the
        connectivity backoff so the next get_modem_data() attempts
        a real connection regardless of prior failures.
        """
        was_backing_off = self._policy.connectivity_streak > 0
        self._policy.reset_connectivity()
        if was_backing_off:
            _logger.info("Connectivity backoff reset — next poll will attempt connection")

    def diagnostics(self) -> OrchestratorDiagnostics:
        """Return a read-only snapshot of operational diagnostics.

        No side effects — safe to call at any time.
        """
        auth = self._modem_config.auth
        return OrchestratorDiagnostics(
            poll_duration=self._last_poll_duration,
            auth_failure_streak=self._policy.auth_failure_streak,
            circuit_breaker_open=self._policy.circuit_open,
            session_is_valid=self._collector.session_is_valid,
            auth_strategy=auth.strategy if auth else "",
            connectivity_streak=self._policy.connectivity_streak,
            connectivity_backoff_remaining=self._policy.connectivity_backoff_remaining,
            resource_fetches=self._collector.last_resource_fetches,
            last_poll_timestamp=self._last_poll_timestamp,
        )

    @property
    def status(self) -> ConnectionStatus:
        """Current connection status from the last get_modem_data() call.

        Returns UNREACHABLE if never polled.
        """
        if self._last_status is None:
            return ConnectionStatus.UNREACHABLE
        return self._last_status

    @property
    def supports_restart(self) -> bool:
        """Whether the modem declares a restart action in modem.yaml."""
        actions = self._modem_config.actions
        return actions is not None and actions.restart is not None

    @property
    def recovery_active(self) -> bool:
        """Whether a recovery window is currently open.

        True while the :class:`Recovery` module is running an
        aggressive-polling window — triggered by ``restart()``, a
        connectivity outage, or the reboot-signal vote.

        Consumers read this to decide whether to poll at recovery
        cadence. HA subscribes to the observer (see
        :meth:`set_recovery_observer`) for immediate notification
        rather than polling this flag.

        Thread-safe: a boolean read is atomic under the GIL.
        """
        return self._recovery.active

    def set_recovery_observer(self, observer: Callable[[], None] | None) -> None:
        """Register a callback fired on ``recovery_active`` transitions.

        Invoked from the poll thread on both False→True and
        True→False transitions (plus on :meth:`Recovery.begin`
        re-entry while already active — useful for kicking HA's
        ``async_request_refresh`` timing).

        The callback must be thread-safe. HA implementations
        typically hop to the event loop via ``dispatcher_send``
        (which internally uses ``call_soon_threadsafe``).

        Pass ``None`` to clear a previously registered observer.
        """
        # The Recovery instance owns observer dispatch — here we
        # just install the callable. Exceptions raised by the
        # observer are swallowed inside Recovery so they can't
        # break orchestration on the poll thread.
        self._recovery._on_state_change = observer

    # ------------------------------------------------------------------
    # Internal — poll execution
    # ------------------------------------------------------------------

    def _execute_poll(self) -> ModemSnapshot:
        """Run the collection pipeline with policy checks."""
        # Recovery tick — advance the window clock and fire the
        # True→False observer if the deadline just passed. Runs
        # before any short-circuit so the window always closes
        # promptly even when polling is blocked (circuit open,
        # backoff active). Cheap — constant-time no-op when idle.
        self._recovery.tick()

        # Circuit breaker
        if self._policy.circuit_open:
            _logger.error(
                "Circuit breaker OPEN [%s] — polling stopped. Reconfigure credentials to resume.",
                self._modem_config.model,
            )
            return self._make_snapshot(
                ConnectionStatus.AUTH_FAILED,
                DocsisStatus.UNKNOWN,
                error="Circuit breaker open — reconfigure credentials",
            )

        # Health recovery — clear connectivity backoff if the modem
        # is proven reachable. The freshness gate matters: the health
        # coordinator is on a slower cadence than the data coordinator
        # during a recovery window, so ``latest`` may still hold a
        # pre-outage RESPONSIVE reading. Only trust it if the probe
        # ran AFTER our last observed connectivity failure.
        if (
            self._health_monitor is not None
            and self._policy.connectivity_backoff_remaining > 0
            and self._health_monitor.latest.health_status == HealthStatus.RESPONSIVE
            and self._is_health_probe_fresh()
        ):
            _logger.info(
                "Health recovery detected [%s] — clearing connectivity backoff",
                self._modem_config.model,
            )
            self._policy.reset_connectivity()

        # Connectivity backoff
        if self._policy.check_connectivity_backoff():
            return self._make_snapshot(
                ConnectionStatus.UNREACHABLE,
                DocsisStatus.UNKNOWN,
                error="Connectivity backoff active",
            )

        # Log poll context — INFO on first poll, DEBUG on steady-state
        self._log_poll_context()

        # Notify health monitor — avoids redundant HTTP probe during collection
        if self._health_monitor is not None:
            self._health_monitor.record_collection_start()

        collection_success = False
        try:
            result = self._collector.execute()
            collection_success = result.success

            if not result.success:
                self._log_poll_result(result)
                return self._handle_failure(result)

            self._first_poll_complete = True
            self._log_poll_result(result)
            return self._handle_success(result)
        finally:
            if self._health_monitor is not None:
                self._health_monitor.record_collection_end(collection_success)

    def _handle_failure(self, result: ModemResult) -> ModemSnapshot:
        """Apply signal policy for a failed collection."""
        status = self._policy.apply(result)

        # Freshness watermark — remember when we last saw
        # connectivity actually fail so the health-recovery
        # shortcut in _execute_poll() can distinguish a genuine
        # health-recovery probe from a stale pre-outage reading.
        if result.signal is CollectorSignal.CONNECTIVITY:
            self._last_connectivity_failure_at = time.monotonic()

        # Recovery hook — on CONNECTIVITY failures, Recovery opens a
        # window so HA drops to the faster cadence. Other failure
        # signals (AUTH_FAILED, PARSE_ERROR, LOAD_*) are no-ops
        # inside evaluate_failure — those aren't "modem is
        # rebooting" signals.
        self._recovery.evaluate_failure(result)

        self._detect_transition(status)
        return self._make_snapshot(
            status,
            DocsisStatus.UNKNOWN,
            collector_signal=result.signal,
            error=result.error,
        )

    def _handle_success(self, result: ModemResult) -> ModemSnapshot:
        """Process a successful collection result."""
        self._policy.clear_streak()

        modem_data = result.modem_data
        assert modem_data is not None  # guaranteed by success=True

        # Derive statuses
        connection_status = derive_connection_status(modem_data)
        enrich_docsis_status(modem_data)
        docsis_status = modem_data.get("system_info", {}).get("docsis_status", DocsisStatus.UNKNOWN)

        # Counter-reset detection — proxy for "last boot time" when
        # the modem doesn't report native uptime (see #110). This
        # updates orchestrator state only; it does NOT feed the
        # reboot-signal vote (that's Recovery's own history).
        self._check_counter_reset(modem_data)

        # Recovery hook — runs the reboot-signal vote (may open a
        # window) and always refreshes Recovery's own baselines.
        # When a window is already open, evaluate_snapshot only
        # updates history; the window ticks to completion via
        # tick() at the top of the next poll.
        self._recovery.evaluate_snapshot(modem_data)

        # Read latest health info
        health_info: HealthInfo | None = None
        if self._health_monitor is not None:
            health_info = self._health_monitor.latest

        self._detect_transition(connection_status)

        return self._make_snapshot(
            connection_status,
            docsis_status,
            modem_data=modem_data,
            health_info=health_info,
            collector_signal=CollectorSignal.OK,
            stats_last_reset=self._stats_last_reset,
        )

    # ------------------------------------------------------------------
    # Internal — health freshness
    # ------------------------------------------------------------------

    def _is_health_probe_fresh(self) -> bool:
        """Whether the latest health probe happened after the last
        observed CONNECTIVITY failure.

        Used to gate the "health recovery clears connectivity backoff"
        shortcut so we don't trust a cached RESPONSIVE reading from
        before a modem outage. Returns True when either:

        - No connectivity failure has been observed yet (nothing to
          invalidate against), or
        - A health probe has run since the last failure.
        """
        if self._last_connectivity_failure_at is None:
            return True
        if self._health_monitor is None:
            return False
        probe_at = self._health_monitor.latest_probe_at
        if probe_at is None:
            return False
        return probe_at > self._last_connectivity_failure_at

    # ------------------------------------------------------------------
    # Internal — transition detection
    # ------------------------------------------------------------------

    def _detect_transition(self, new_status: ConnectionStatus) -> None:
        """Log status transitions for diagnostics."""
        old_status = self._last_status
        self._last_status = new_status

        if old_status is not None and old_status != new_status:
            _logger.info(
                "Status transition [%s]: %s → %s",
                self._modem_config.model,
                old_status.value,
                new_status.value,
            )

    # ------------------------------------------------------------------
    # Internal — first-poll verbose logging
    # ------------------------------------------------------------------

    def _log_poll_context(self) -> None:
        """Log auth context before poll. INFO on first poll, DEBUG after."""
        log = _logger.info if not self._first_poll_complete else _logger.debug

        auth = self._modem_config.auth
        strategy = type(auth).__name__ if auth is not None else "none"
        has_creds = bool(self._collector._username or self._collector._password)

        session = "active" if self._collector.session_is_valid else "none"

        log(
            "Poll [%s] — auth: %s, url: %s, credentials: %s, session: %s",
            self._modem_config.model,
            strategy,
            self._collector._base_url,
            "yes" if has_creds else "no",
            session,
        )

    def _log_poll_result(self, result: ModemResult) -> None:
        """Log poll outcome. Parse line at INFO always. Failure at WARNING."""
        model = self._modem_config.model

        if not result.success:
            _logger.warning(
                "Poll failed [%s] — signal: %s, error: %s",
                model,
                result.signal.value,
                result.error,
            )
            return

        ds = len(result.modem_data.get("downstream", [])) if result.modem_data else 0
        us = len(result.modem_data.get("upstream", [])) if result.modem_data else 0

        _logger.info(
            "Parse complete [%s]: %d DS, %d US channels",
            model,
            ds,
            us,
        )

    # ------------------------------------------------------------------
    # Internal — counter-reset detection (#110)
    # ------------------------------------------------------------------

    def _check_counter_reset(self, modem_data: dict[str, Any]) -> None:
        """Detect error counter resets between polls.

        When total corrected or uncorrected counts decrease, the modem
        has likely rebooted and cleared its stats. Records the timestamp
        as a proxy for last boot time.
        """
        current = self._sum_error_totals(modem_data)
        if current is None:
            return

        prev = self._prev_error_totals
        self._prev_error_totals = current

        if prev is None:
            # First poll — no comparison possible
            return

        prev_corrected, prev_uncorrected = prev
        cur_corrected, cur_uncorrected = current

        if cur_corrected < prev_corrected or cur_uncorrected < prev_uncorrected:
            self._stats_last_reset = datetime.now(UTC)
            _logger.info(
                "Counter reset detected [%s] — corrected: %d→%d, uncorrected: %d→%d",
                self._modem_config.model,
                prev_corrected,
                cur_corrected,
                prev_uncorrected,
                cur_uncorrected,
            )

    @staticmethod
    def _sum_error_totals(modem_data: dict[str, Any]) -> tuple[int, int] | None:
        """Sum corrected and uncorrected counts across all channels.

        Returns None if no channels have error count fields.
        """
        total_corrected = 0
        total_uncorrected = 0
        found = False

        for direction in ("downstream", "upstream"):
            for channel in modem_data.get(direction, []):
                corrected = channel.get("corrected")
                uncorrected = channel.get("uncorrected")
                if corrected is not None or uncorrected is not None:
                    found = True
                    total_corrected += int(corrected or 0)
                    total_uncorrected += int(uncorrected or 0)

        return (total_corrected, total_uncorrected) if found else None

    # ------------------------------------------------------------------
    # Internal — snapshot construction
    # ------------------------------------------------------------------

    def _make_snapshot(
        self,
        connection_status: ConnectionStatus,
        docsis_status: str,
        *,
        modem_data: dict[str, Any] | None = None,
        health_info: HealthInfo | None = None,
        collector_signal: CollectorSignal = CollectorSignal.OK,
        error: str = "",
        stats_last_reset: datetime | None = None,
    ) -> ModemSnapshot:
        """Build a ModemSnapshot with defaults."""
        return ModemSnapshot(
            connection_status=connection_status,
            docsis_status=docsis_status,
            modem_data=modem_data,
            health_info=health_info,
            collector_signal=collector_signal,
            error=error,
            stats_last_reset=stats_last_reset,
        )
