"""
Context tools — authentication check, permissions, and subject selection.

get_permissions() should be called first to understand what the user can access.
set_subject() must be called before using any personalization tools.
"""

from fastmcp import Context

from ..server import mcp
from ..client import get_client


@mcp.tool(annotations={"readOnlyHint": True})
async def get_permissions(ctx: Context = None) -> str:
    """Get the current user's subscription tier and domain access permissions.
    Call this first to understand what entities and features you can access.
    Returns: tier level, accessible domains, and entity-level overrides."""
    client = await get_client(ctx)
    result = await client.get("/nexotype/permissions/")
    data = result.get("data", result)

    lines = [f"Subscription Tier: {data.get('tier', 'unknown')}\n"]

    # Domain access
    domains = data.get("domains", {})
    if domains:
        lines.append("Domain Access:")
        for domain, access in domains.items():
            read = access.get("read", False)
            write = access.get("write", False)
            if read and write:
                perm = "read + write"
            elif read:
                perm = "read only"
            else:
                perm = "no access"
            lines.append(f"  - {domain}: {perm}")

    # Entity overrides
    overrides = data.get("entity_overrides", {})
    if overrides:
        lines.append("\nEntity-Level Overrides:")
        for entity, access in overrides.items():
            read = access.get("read", False)
            write = access.get("write", False)
            if read and write:
                perm = "read + write"
            elif read:
                perm = "read only"
            else:
                perm = "no access"
            lines.append(f"  - {entity}: {perm}")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": True})
async def list_subjects(ctx: Context = None) -> str:
    """List all subjects the user has access to. Use this to find subject IDs for set_subject().
    A subject is a biological identity (human, animal) whose data you want to access."""
    client = await get_client(ctx)
    result = await client.get("/nexotype/subjects/")
    items = result.get("data", [])

    if not items:
        return "No subjects found. Create one in the Nexotype dashboard first."

    lines = [f"Subjects ({len(items)}):"]
    for s in items:
        identifier = s.get("subject_identifier", f"#{s['id']}")
        organism = s.get("organism_id", "?")
        sex = s.get("sex", "—")
        cohort = s.get("cohort_name", "—")
        lines.append(f"  - {identifier} (id={s['id']}, organism={organism}, sex={sex}, cohort={cohort})")

    # Show active subject from session state
    if client.subject_id:
        lines.append(f"\nActive subject: {client.subject_id}")
    else:
        lines.append("\nNo active subject. Use set_subject() to select one.")

    return "\n".join(lines)


@mcp.tool(annotations={"readOnlyHint": False, "destructiveHint": False, "openWorldHint": False})
async def set_subject(subject_id: int, ctx: Context = None) -> str:
    """Set the active subject for personalization tools (variants, biomarkers, treatments, etc.).
    Use list_subjects() first to find available subject IDs.
    All personalization tools will use this subject context automatically."""
    client = await get_client(ctx)
    # Validate by fetching the subject
    try:
        result = await client.get(f"/nexotype/subjects/{subject_id}")
        data = result.get("data", result)

        # Store subject_id in session state (persists across tool calls for this user)
        if ctx:
            await ctx.set_state("subject_id", subject_id)

        identifier = data.get("subject_identifier", f"#{subject_id}")
        return (
            f"Subject set successfully.\n"
            f"Subject: {identifier} (id={subject_id})"
        )
    except Exception:
        if ctx:
            await ctx.set_state("subject_id", None)
        return "Error: Cannot access this subject. Check the subject_id is correct and you have access."
