from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from sheltron_core import ForwardedEvidenceClaim
from sheltron_mcp.broker import DOWNSTREAM_BROKER_ENV_VAR, DownstreamMcpBroker, load_downstream_broker
from sheltron_mcp.service import (
    SHELTRON_BROKER_TOOL_NAMES,
    SHELTRON_EXEC_TOOL_NAMES,
    SHELTRON_FILESYSTEM_TOOL_NAMES,
    SHELTRON_NETWORK_TOOL_NAMES,
    SHELTRON_STATUS_TOOL_NAMES,
    SHELTRON_TOOL_NAMES,
    SheltronMcpService,
    FileSystemMcpService,
    default_filesystem_protected_paths,
    default_workspace_approval_store_path,
)

MCP_REQUEST_LOGGER_NAME = 'mcp.server.lowlevel.server'


def build_mcp_server(
    workspace: str | Path | None = None,
    *,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
    system_name: str = 'sheltron_mcp',
    downstream_broker: DownstreamMcpBroker | None = None,
) -> FastMCP:
    service = SheltronMcpService.for_workspace(
        workspace,
        approval_store_path=approval_store_path,
        audit_log_path=audit_log_path,
        system_name=system_name,
        downstream_broker=downstream_broker,
    )
    server = FastMCP(
        name='Sheltron',
        instructions='Safe filesystem, exec, and network tools with approval-aware blocking and resumption.',
    )

    @server.tool(
        name='sheltron_read_file',
        description='Read a text file through the Sheltron filesystem guard.',
    )
    def read_file(
        path: str,
        encoding: str = 'utf-8',
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.read_file(
                path,
                encoding=encoding,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_write_file',
        description='Write a text file through the Sheltron filesystem guard.',
    )
    def write_file(
        path: str,
        content: str,
        encoding: str = 'utf-8',
        create_parents: bool = False,
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.write_file(
                path,
                content=content,
                encoding=encoding,
                create_parents=create_parents,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_edit_file',
        description='Edit a text file through the Sheltron filesystem guard.',
    )
    def edit_file(
        path: str,
        old_text: str,
        new_text: str,
        encoding: str = 'utf-8',
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.edit_file(
                path,
                old_text=old_text,
                new_text=new_text,
                encoding=encoding,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_list_dir',
        description='List a directory through the Sheltron filesystem guard.',
    )
    def list_dir(
        path: str,
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.list_dir(
                path,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_exec',
        description='Execute a command through the Sheltron exec guard.',
    )
    def execute_command(
        command: list[str],
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        stdin: str | None = None,
        timeout_seconds: int | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.execute_command(
                command,
                cwd=cwd,
                env=env,
                stdin=stdin,
                timeout_seconds=timeout_seconds,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_fetch_url',
        description='Fetch a URL through the Sheltron network guard.',
    )
    def fetch_url(
        url: str,
        headers: dict[str, str] | None = None,
        max_bytes: int | None = None,
        timeout_seconds: int | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.fetch_url(
                url,
                headers=headers,
                max_bytes=max_bytes,
                timeout_seconds=timeout_seconds,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_post_url',
        description='Send an HTTP POST through the Sheltron network guard.',
    )
    def post_url(
        url: str,
        body: str | dict[str, object] | list[object] | int | float | bool | None = None,
        headers: dict[str, str] | None = None,
        max_bytes: int | None = None,
        timeout_seconds: int | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.post_url(
                url,
                body=body,
                headers=headers,
                max_bytes=max_bytes,
                timeout_seconds=timeout_seconds,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_brokered_mcp_call',
        description='Call a namespaced downstream MCP tool through the Sheltron broker.',
    )
    def brokered_mcp_call(
        namespaced_tool: str,
        arguments: dict[str, object] | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: list[ForwardedEvidenceClaim] | None = None,
    ) -> str:
        return json.dumps(
            service.invoke_brokered_tool(
                namespaced_tool,
                arguments=arguments,
                approval_ticket_id=approval_ticket_id,
                sheltron_evidence=sheltron_evidence,
            ),
            sort_keys=True,
        )

    @server.tool(
        name='sheltron_status',
        description=(
            'Report whether Sheltron protection is active for this agent session. '
            'Use this only when the user explicitly asks about Sheltron status, '
            'for example whether Sheltron is on, enabled, active, or protecting this session.'
        ),
    )
    def status() -> str:
        return json.dumps(service.status(), sort_keys=True)

    return server


def configure_mcp_framework_logging(*, system_name: str) -> None:
    if system_name == 'nanobot':
        logging.getLogger(MCP_REQUEST_LOGGER_NAME).setLevel(logging.WARNING)


def serve_stdio(
    workspace: str | Path | None = None,
    *,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
    system_name: str = 'sheltron_mcp',
    downstream_broker_spec: str | None = None,
) -> None:
    configure_mcp_framework_logging(system_name=system_name)
    broker_spec = downstream_broker_spec or os.environ.get(DOWNSTREAM_BROKER_ENV_VAR)
    downstream_broker = load_downstream_broker(broker_spec) if broker_spec else None
    server = build_mcp_server(
        workspace,
        approval_store_path=approval_store_path,
        audit_log_path=audit_log_path,
        system_name=system_name,
        downstream_broker=downstream_broker,
    )
    server.run(transport='stdio')


__all__ = [
    'SHELTRON_BROKER_TOOL_NAMES',
    'SHELTRON_EXEC_TOOL_NAMES',
    'SHELTRON_FILESYSTEM_TOOL_NAMES',
    'SHELTRON_NETWORK_TOOL_NAMES',
    'SHELTRON_STATUS_TOOL_NAMES',
    'SHELTRON_TOOL_NAMES',
    'SheltronMcpService',
    'FileSystemMcpService',
    'build_mcp_server',
    'default_filesystem_protected_paths',
    'default_workspace_approval_store_path',
    'serve_stdio',
]
