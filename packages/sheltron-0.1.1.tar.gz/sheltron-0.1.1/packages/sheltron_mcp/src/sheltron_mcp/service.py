from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import json
from pathlib import Path

from sheltron_core import (
    ActionRequest,
    Capability,
    CapabilityAllowlistPolicy,
    DefenseRouter,
    DownstreamMcpAccessPolicy,
    Evidence,
    ForwardedEvidenceClaim,
    JsonObject,
    PolicyEngine,
    PolicyResult,
    Provenance,
    ResourceKind,
    TrustLevel,
)
from sheltron_runtime import (
    SheltronGateway,
    SheltronGatewayAdapter,
    CommandOutput,
    CommandSpec,
    DirectoryListSpec,
    FetchSpec,
    FileEditSpec,
    FileReadSpec,
    FileWriteSpec,
    GatewayAction,
    GuardResult,
    LocalToolBrokerPipeline,
    NetworkResponse,
    PostSpec,
    build_broker_action_request,
    default_filesystem_protected_paths as _default_filesystem_protected_paths,
    default_workspace_approval_store_path as _default_workspace_approval_store_path,
)
from sheltron_mcp.broker import (
    DownstreamMcpBroker,
    McpToolBrokerBackend,
    split_namespaced_tool_name,
)

default_filesystem_protected_paths = _default_filesystem_protected_paths
default_workspace_approval_store_path = _default_workspace_approval_store_path

SHELTRON_FILESYSTEM_TOOL_NAMES = (
    'sheltron_read_file',
    'sheltron_write_file',
    'sheltron_edit_file',
    'sheltron_list_dir',
)
SHELTRON_EXEC_TOOL_NAMES = ('sheltron_exec',)
SHELTRON_NETWORK_TOOL_NAMES = (
    'sheltron_fetch_url',
    'sheltron_post_url',
)
SHELTRON_BROKER_TOOL_NAMES = ('sheltron_brokered_mcp_call',)
SHELTRON_STATUS_TOOL_NAMES = ('sheltron_status',)
SHELTRON_TOOL_NAMES = (
    SHELTRON_FILESYSTEM_TOOL_NAMES
    + SHELTRON_EXEC_TOOL_NAMES
    + SHELTRON_NETWORK_TOOL_NAMES
    + SHELTRON_BROKER_TOOL_NAMES
    + SHELTRON_STATUS_TOOL_NAMES
)
_MAX_FORWARDED_EVIDENCE_ITEMS = 4
_MAX_FORWARDED_SNIPPET_CHARS = 512
_MAX_FORWARDED_REFERENCE_CHARS = 512
_FORWARDED_EVIDENCE_TRUST_LEVELS: dict[str, TrustLevel] = {
    'web_fetch': TrustLevel.WEB_UNTRUSTED,
    'web_search': TrustLevel.WEB_UNTRUSTED,
    'tool_output': TrustLevel.MCP_UNTRUSTED,
    'mcp_tool_output': TrustLevel.MCP_UNTRUSTED,
    'file_read': TrustLevel.FILE_UNTRUSTED,
    'file_output': TrustLevel.FILE_UNTRUSTED,
    'file_content': TrustLevel.FILE_UNTRUSTED,
}


@dataclass(slots=True)
class SheltronMcpService:
    workspace: Path
    approval_store_path: Path
    audit_log_path: Path
    gateway: SheltronGateway
    adapter: SheltronGatewayAdapter
    provenance: Provenance
    system_name: str
    downstream_broker: DownstreamMcpBroker | None = None
    broker_pipeline: LocalToolBrokerPipeline | None = None

    @property
    def filesystem_guard(self):
        return self.gateway.filesystem_guard

    @filesystem_guard.setter
    def filesystem_guard(self, value) -> None:
        self.gateway.filesystem_guard = value

    @property
    def exec_guard(self):
        return self.gateway.exec_guard

    @exec_guard.setter
    def exec_guard(self, value) -> None:
        self.gateway.exec_guard = value

    @property
    def network_guard(self):
        return self.gateway.network_guard

    @network_guard.setter
    def network_guard(self, value) -> None:
        self.gateway.network_guard = value

    @classmethod
    def for_workspace(
        cls,
        workspace: str | Path | None = None,
        *,
        approval_store_path: str | Path | None = None,
        audit_log_path: str | Path | None = None,
        system_name: str = 'sheltron_mcp',
        defense_router: DefenseRouter | None = None,
        downstream_broker: DownstreamMcpBroker | None = None,
    ) -> 'SheltronMcpService':
        gateway = SheltronGateway.for_workspace(
            workspace,
            approval_store_path=approval_store_path,
            audit_log_path=audit_log_path,
            system_name=system_name,
            defense_router=defense_router,
        )
        provenance = Provenance(
            session_id=f'{system_name}:mcp',
            channel='mcp',
            actor_id=system_name,
            source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
            trigger=f'{system_name} mcp tool call',
        )
        return cls(
            workspace=gateway.workspace,
            approval_store_path=gateway.approval_store_path,
            audit_log_path=gateway.audit_log_path,
            gateway=gateway,
            adapter=SheltronGatewayAdapter(gateway),
            provenance=provenance,
            system_name=system_name,
            downstream_broker=downstream_broker,
            broker_pipeline=(
                None
                if downstream_broker is None
                else LocalToolBrokerPipeline(
                    backend=McpToolBrokerBackend(downstream_broker),
                    policy_engine=PolicyEngine(
                        [
                            DownstreamMcpAccessPolicy(),
                            CapabilityAllowlistPolicy({Capability.MCP_BROKER_CALL}),
                        ],
                        defense_router=defense_router,
                    ),
                    approval_store=gateway.approval_store,
                    capability=Capability.MCP_BROKER_CALL,
                    resource_kind=ResourceKind.MCP_TOOL,
                )
            ),
        )

    def read_file(
        self,
        path: str,
        *,
        encoding: str = 'utf-8',
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        result = self.adapter.before_action(
            GatewayAction.READ_FILE,
            FileReadSpec(path=Path(path), encoding=encoding),
            provenance=self._resolve_provenance(
                sheltron_evidence=sheltron_evidence,
                _sheltron_evidence=_sheltron_evidence,
            ),
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary=(
                f'content_chars={len(result.value)}'
                if result.executed and result.value is not None
                else None
            ),
        )
        return self._serialize_result(result, content=result.value if result.executed else None)

    def write_file(
        self,
        path: str,
        *,
        content: str,
        encoding: str = 'utf-8',
        create_parents: bool = False,
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        result = self.adapter.before_action(
            GatewayAction.WRITE_FILE,
            FileWriteSpec(
                path=Path(path),
                content=content,
                encoding=encoding,
                create_parents=create_parents,
            ),
            provenance=self._resolve_provenance(
                sheltron_evidence=sheltron_evidence,
                _sheltron_evidence=_sheltron_evidence,
            ),
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary='write_applied=true' if result.executed else None,
        )
        return self._serialize_result(result)

    def edit_file(
        self,
        path: str,
        *,
        old_text: str,
        new_text: str,
        encoding: str = 'utf-8',
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        result = self.adapter.before_action(
            GatewayAction.EDIT_FILE,
            FileEditSpec(
                path=Path(path),
                old_text=old_text,
                new_text=new_text,
                encoding=encoding,
            ),
            provenance=self._resolve_provenance(
                sheltron_evidence=sheltron_evidence,
                _sheltron_evidence=_sheltron_evidence,
            ),
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary='edit_applied=true' if result.executed else None,
        )
        return self._serialize_result(result)

    def list_dir(
        self,
        path: str,
        *,
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        result = self.adapter.before_action(
            GatewayAction.LIST_DIRECTORY,
            DirectoryListSpec(path=Path(path)),
            provenance=self._resolve_provenance(
                sheltron_evidence=sheltron_evidence,
                _sheltron_evidence=_sheltron_evidence,
            ),
            approval_ticket_id=approval_ticket_id,
        )
        entries = None
        if result.executed:
            entries = [
                {
                    'path': str(entry.path),
                    'name': entry.path.name,
                    'is_dir': entry.is_dir,
                    'size_bytes': entry.size_bytes,
                }
                for entry in result.value or ()
            ]
        result = self.adapter.after_action(
            result,
            result_summary=f'entries={len(entries or [])}' if result.executed else None,
        )
        return self._serialize_result(result, entries=entries)

    def execute_command(
        self,
        command: list[str],
        *,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        stdin: str | None = None,
        timeout_seconds: int | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        result = self.adapter.before_action(
            GatewayAction.EXECUTE_COMMAND,
            CommandSpec(
                command=tuple(command),
                cwd=None if cwd is None else Path(cwd),
                env=env or {},
                stdin=stdin,
                timeout_seconds=timeout_seconds,
            ),
            provenance=self._augment_provenance(
                evidence_payload=(
                    sheltron_evidence
                    if sheltron_evidence is not None
                    else _sheltron_evidence
                ),
            ),
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary=(
                f'exit_code={result.value.exit_code} '
                f'stdout_chars={len(result.value.stdout)} '
                f'stderr_chars={len(result.value.stderr)}'
            )
            if result.executed and result.value is not None
            else None,
        )
        return self._serialize_result(result, command_output=result.value if result.executed else None)

    def fetch_url(
        self,
        url: str,
        *,
        headers: dict[str, str] | None = None,
        max_bytes: int | None = None,
        timeout_seconds: int | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        result = self.adapter.before_action(
            GatewayAction.FETCH_URL,
            FetchSpec(
                url=url,
                headers=headers or {},
                max_bytes=max_bytes,
                timeout_seconds=timeout_seconds,
            ),
            provenance=self._resolve_provenance(
                sheltron_evidence=sheltron_evidence,
                _sheltron_evidence=_sheltron_evidence,
            ),
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary=self._network_result_summary(result.value) if result.executed else None,
        )
        return self._serialize_result(result, network_response=result.value if result.executed else None)

    def post_url(
        self,
        url: str,
        *,
        body: str | dict[str, object] | list[object] | int | float | bool | bytes | bytearray | None = None,
        headers: dict[str, str] | None = None,
        max_bytes: int | None = None,
        timeout_seconds: int | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        normalized_body = self._normalize_post_body(body)
        result = self.adapter.before_action(
            GatewayAction.POST_URL,
            PostSpec(
                url=url,
                body=None if normalized_body is None else normalized_body.encode('utf-8'),
                headers=headers or {},
                max_bytes=max_bytes,
                timeout_seconds=timeout_seconds,
            ),
            provenance=self._resolve_provenance(
                sheltron_evidence=sheltron_evidence,
                _sheltron_evidence=_sheltron_evidence,
            ),
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary=self._network_result_summary(result.value) if result.executed else None,
        )
        return self._serialize_result(result, network_response=result.value if result.executed else None)

    def invoke_brokered_tool(
        self,
        namespaced_tool: str,
        *,
        arguments: dict[str, object] | None = None,
        approval_ticket_id: str | None = None,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> dict[str, object]:
        normalized_arguments = dict(arguments or {})
        provenance = self._augment_provenance(evidence_payload=sheltron_evidence)
        if self.downstream_broker is None or self.broker_pipeline is None:
            request = self._build_broker_request(
                namespaced_tool,
                arguments=normalized_arguments,
                provenance=provenance,
            )
            result = GuardResult.rejected(
                request,
                PolicyResult.deny(
                    'downstream_mcp_access',
                    code='downstream_mcp_not_configured',
                    message='No downstream MCP broker is configured for this Sheltron server.',
                    details={'namespaced_tool': namespaced_tool},
                ),
            )
            result = self.adapter.after_action(
                result,
                result_summary=f'brokered_mcp_call={namespaced_tool}',
            )
            payload = self.gateway.serialize_blocked_result(result)
            payload.update({'brokered': True, 'namespaced_tool': namespaced_tool})
            return payload

        before = self.adapter.before_tool_broker(
            namespaced_tool=namespaced_tool,
            arguments=normalized_arguments,
            provenance=provenance,
        )
        if before.blocked_result is not None:
            request = self._build_broker_request(
                namespaced_tool,
                arguments=normalized_arguments,
                provenance=provenance,
            )
            if isinstance(before.blocked_result, GuardResult):
                if before.blocked_result.executed:
                    raise TypeError(
                        'Hook event `before_tool_broker` returned an executed GuardResult as blocked_result.'
                    )
                result = before.blocked_result
            else:
                hook_reason = (
                    before.blocked_result.get('reason')
                    if isinstance(before.blocked_result, dict)
                    and isinstance(before.blocked_result.get('reason'), str)
                    else str(before.blocked_result)
                )
                result = GuardResult.rejected(
                    request,
                    PolicyResult.deny(
                        'gateway_hook',
                        code='broker_hook_blocked',
                        message=hook_reason or 'A gateway hook blocked this brokered MCP call.',
                        details={'namespaced_tool': namespaced_tool},
                    ),
                )
            result = self.adapter.after_action(
                result,
                result_summary=f'brokered_mcp_call={namespaced_tool}',
            )
            payload = self.gateway.serialize_blocked_result(result)
            payload.update({'brokered': True, 'namespaced_tool': namespaced_tool})
            return payload

        result = self.broker_pipeline.invoke(
            namespaced_tool,
            arguments=normalized_arguments,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )
        result = self.adapter.after_action(
            result,
            result_summary=f'brokered_mcp_call={namespaced_tool}',
        )
        if not result.executed:
            payload = self.gateway.serialize_blocked_result(result)
            payload.update({'brokered': True, 'namespaced_tool': namespaced_tool})
            return payload

        brokered = result.value
        if brokered is None:
            raise RuntimeError('Brokered MCP guard completed without a downstream tool result.')
        primary_reason = result.policy_result.reasons[0]
        payload: dict[str, object] = {
            'executed': True,
            'brokered': True,
            'request_id': result.request.request_id,
            'capability': result.request.capability.value,
            'resource': result.request.resource.locator,
            'decision': result.policy_result.decision.value,
            'matched_policy': result.policy_result.matched_policy,
            'reason_code': primary_reason.code,
            'reason': primary_reason.message,
            'details': primary_reason.details,
            'approval_ticket_id': result.policy_result.approval_ticket_id,
            'namespaced_tool': brokered.registration.locator,
            'server_name': brokered.registration.namespace,
            'tool_name': brokered.registration.tool_name,
            'description': brokered.registration.description,
            'trust_level': brokered.registration.trust_level.value,
            'result': brokered.result,
        }
        after = self.adapter.after_tool_broker(
            namespaced_tool=brokered.registration.locator,
            arguments=brokered.arguments,
            result=payload,
            provenance=provenance,
            metadata={'trust_level': brokered.registration.trust_level.value},
        )
        if isinstance(after.transformed_result, dict):
            return dict(after.transformed_result)
        return payload

    def status(self) -> dict[str, object]:
        return {
            'enabled': True,
            'status': 'on',
            'mode': 'mcp-session',
            'system': self.system_name,
            'message': 'Sheltron is active for this MCP-backed agent session.',
        }

    def _resolve_provenance(
        self,
        *,
        sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
        _sheltron_evidence: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> Provenance:
        return self._augment_provenance(
            evidence_payload=(
                sheltron_evidence
                if sheltron_evidence is not None
                else _sheltron_evidence
            ),
        )

    def _augment_provenance(
        self,
        *,
        evidence_payload: Sequence[ForwardedEvidenceClaim] | None = None,
    ) -> Provenance:
        if not evidence_payload:
            return self.provenance

        evidence = list(self.provenance.evidence)
        trust_levels = list(self.provenance.source_trust_levels)
        for payload in tuple(evidence_payload or ())[:_MAX_FORWARDED_EVIDENCE_ITEMS]:
            if not isinstance(payload, dict):
                continue
            source = payload.get('source')
            snippet = payload.get('snippet')
            reference = payload.get('reference')
            if not isinstance(source, str) or not isinstance(snippet, str):
                continue
            normalized_source = source.strip().lower()
            normalized_snippet = snippet.strip()
            if not normalized_source or not normalized_snippet:
                continue
            derived_trust = _FORWARDED_EVIDENCE_TRUST_LEVELS.get(normalized_source)
            if derived_trust is None:
                continue
            evidence.append(
                Evidence(
                    source=normalized_source,
                    reference=(
                        _truncate_forwarded_text(reference, max_chars=_MAX_FORWARDED_REFERENCE_CHARS)
                        if isinstance(reference, str)
                        else None
                    ),
                    snippet=normalized_snippet[:_MAX_FORWARDED_SNIPPET_CHARS],
                )
            )
            if derived_trust not in trust_levels:
                trust_levels.append(derived_trust)

        return self.provenance.model_copy(
            update={
                'source_trust_levels': tuple(trust_levels),
                'evidence': tuple(evidence),
            }
        )

    def _build_broker_request(
        self,
        namespaced_tool: str,
        *,
        arguments: dict[str, object],
        provenance: Provenance,
    ) -> ActionRequest:
        backend = (
            McpToolBrokerBackend(self.downstream_broker)
            if self.downstream_broker is not None
            else None
        )
        registration = backend.get_registration(namespaced_tool) if backend is not None else None
        parsed_server_name, parsed_tool_name = split_namespaced_tool_name(namespaced_tool)
        if registration is None and parsed_server_name and parsed_tool_name:
            namespace = parsed_server_name
        else:
            namespace = registration.namespace if registration is not None else None
        namespace_allowed = backend.is_namespace_allowed(namespace) if backend is not None else False
        return build_broker_action_request(
            backend_kind='mcp',
            locator=namespaced_tool,
            provenance=provenance,
            arguments=dict(arguments),
            registration=registration,
            namespace_allowed=namespace_allowed,
            namespace=namespace,
            tool_name=parsed_tool_name,
            capability=Capability.MCP_BROKER_CALL,
            resource_kind=ResourceKind.MCP_TOOL,
        )

    @staticmethod
    def _network_result_summary(response: NetworkResponse | None) -> str | None:
        if response is None:
            return None
        return (
            f'status_code={response.status_code} '
            f'body_bytes={len(response.body)} '
            f'truncated={str(response.truncated).lower()}'
        )

    def _serialize_result(
        self,
        result: GuardResult[object],
        *,
        content: str | None = None,
        entries: list[JsonObject] | None = None,
        command_output: CommandOutput | None = None,
        network_response: NetworkResponse | None = None,
    ) -> dict[str, object]:
        if not result.executed:
            return self.gateway.serialize_blocked_result(result)
        primary_reason = result.policy_result.reasons[0]
        payload: dict[str, object] = {
            'executed': result.executed,
            'request_id': result.request.request_id,
            'capability': result.request.capability.value,
            'resource': result.request.resource.locator,
            'decision': result.policy_result.decision.value,
            'matched_policy': result.policy_result.matched_policy,
            'reason_code': primary_reason.code,
            'reason': primary_reason.message,
            'details': primary_reason.details,
            'approval_ticket_id': result.policy_result.approval_ticket_id,
        }
        if content is not None:
            payload['content'] = content
        if entries is not None:
            payload['entries'] = entries
        if command_output is not None:
            payload['exit_code'] = command_output.exit_code
            payload['stdout'] = command_output.stdout
            payload['stderr'] = command_output.stderr
        if network_response is not None:
            payload['status_code'] = network_response.status_code
            payload['content_type'] = network_response.content_type
            payload['final_url'] = network_response.final_url
            payload['truncated'] = network_response.truncated
            payload['error'] = network_response.error
            payload['body_text'] = network_response.body.decode('utf-8', errors='replace')
        return payload

    @staticmethod
    def _normalize_post_body(
        body: str | dict[str, object] | list[object] | int | float | bool | bytes | bytearray | None
    ) -> str | None:
        if body is None:
            return None
        if isinstance(body, str):
            return body
        if isinstance(body, (bytes, bytearray)):
            return bytes(body).decode('utf-8')
        if isinstance(body, (Mapping, Sequence)) and not isinstance(body, (str, bytes, bytearray)):
            return json.dumps(body, ensure_ascii=False, separators=(',', ':'))
        if isinstance(body, (int, float, bool)):
            return json.dumps(body, ensure_ascii=False, separators=(',', ':'))
        raise ValueError('POST body must be a string, bytes, or JSON-serializable value.')


def _truncate_forwarded_text(value: str, *, max_chars: int) -> str | None:
    normalized = value.strip()
    if not normalized:
        return None
    if len(normalized) <= max_chars:
        return normalized
    return normalized[: max_chars - 3] + '...'


FileSystemMcpService = SheltronMcpService
