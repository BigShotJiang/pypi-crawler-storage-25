from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Callable

from sheltron_core import TrustLevel
from sheltron_runtime.tool_broker import ToolBrokerRegistration, ToolBrokerResult

DOWNSTREAM_BROKER_ENV_VAR = 'SHELTRON_DOWNSTREAM_BROKER'


BrokerHandler = Callable[[dict[str, object]], object]


def split_namespaced_tool_name(value: str) -> tuple[str | None, str | None]:
    if '::' not in value:
        return None, None
    server_name, tool_name = value.split('::', 1)
    normalized_server = server_name.strip()
    normalized_tool = tool_name.strip()
    if not normalized_server or not normalized_tool:
        return None, None
    return normalized_server, normalized_tool


def namespaced_tool_name(server_name: str, tool_name: str) -> str:
    normalized_server = server_name.strip()
    normalized_tool = tool_name.strip()
    if not normalized_server or not normalized_tool:
        raise ValueError('Downstream MCP server_name and tool_name must be non-empty.')
    return f'{normalized_server}::{normalized_tool}'


@dataclass(frozen=True, slots=True)
class DownstreamMcpToolRegistration:
    server_name: str
    tool_name: str
    description: str
    trust_level: TrustLevel = TrustLevel.MCP_UNTRUSTED
    enabled: bool = True

    @property
    def namespaced_name(self) -> str:
        return namespaced_tool_name(self.server_name, self.tool_name)


@dataclass(frozen=True, slots=True)
class DownstreamMcpToolResult:
    registration: DownstreamMcpToolRegistration
    arguments: dict[str, object]
    result: object


class DownstreamMcpBroker:
    def __init__(
        self,
        *,
        allowed_servers: frozenset[str] | None = None,
    ) -> None:
        self._allowed_servers = allowed_servers
        self._tools: dict[str, tuple[DownstreamMcpToolRegistration, BrokerHandler]] = {}

    def register_tool(
        self,
        *,
        server_name: str,
        tool_name: str,
        description: str,
        handler: BrokerHandler,
        trust_level: TrustLevel = TrustLevel.MCP_UNTRUSTED,
        enabled: bool = True,
    ) -> DownstreamMcpToolRegistration:
        registration = DownstreamMcpToolRegistration(
            server_name=server_name.strip(),
            tool_name=tool_name.strip(),
            description=description,
            trust_level=trust_level,
            enabled=enabled,
        )
        self._tools[registration.namespaced_name] = (registration, handler)
        return registration

    def list_tools(self) -> tuple[DownstreamMcpToolRegistration, ...]:
        return tuple(
            registration
            for registration, _handler in sorted(
                self._tools.values(),
                key=lambda item: item[0].namespaced_name,
            )
        )

    def get_tool(self, namespaced_name_value: str) -> DownstreamMcpToolRegistration | None:
        tool = self._tools.get(namespaced_name_value)
        if tool is None:
            return None
        registration, _handler = tool
        return registration

    def is_server_allowed(self, server_name: str) -> bool:
        if self._allowed_servers is None:
            return True
        return server_name in self._allowed_servers

    def invoke(
        self,
        namespaced_name_value: str,
        *,
        arguments: dict[str, object] | None = None,
    ) -> DownstreamMcpToolResult:
        tool = self._tools.get(namespaced_name_value)
        if tool is None:
            raise KeyError(f'Unknown downstream MCP tool: {namespaced_name_value}')
        registration, handler = tool
        if not registration.enabled:
            raise PermissionError(f'Downstream MCP tool is disabled: {namespaced_name_value}')
        if self._allowed_servers is not None and registration.server_name not in self._allowed_servers:
            raise PermissionError(
                f'Downstream MCP server is not allowed by this broker: {registration.server_name}'
            )
        normalized_arguments = dict(arguments or {})
        return DownstreamMcpToolResult(
            registration=registration,
            arguments=normalized_arguments,
            result=handler(normalized_arguments),
        )


@dataclass(frozen=True, slots=True)
class McpToolBrokerBackend:
    broker: DownstreamMcpBroker
    backend_kind: str = 'mcp'

    @staticmethod
    def parse_locator(locator: str) -> tuple[str | None, str | None]:
        return split_namespaced_tool_name(locator)

    def get_registration(self, locator: str) -> ToolBrokerRegistration | None:
        registration = self.broker.get_tool(locator)
        if registration is None:
            return None
        return ToolBrokerRegistration(
            backend_kind=self.backend_kind,
            locator=registration.namespaced_name,
            description=registration.description,
            trust_level=registration.trust_level,
            enabled=registration.enabled,
            namespace=registration.server_name,
            tool_name=registration.tool_name,
        )

    def is_namespace_allowed(self, namespace: str | None) -> bool:
        if not isinstance(namespace, str) or not namespace:
            return False
        return self.broker.is_server_allowed(namespace)

    def invoke(
        self,
        locator: str,
        *,
        arguments: dict[str, object] | None = None,
    ) -> ToolBrokerResult:
        downstream = self.broker.invoke(locator, arguments=arguments)
        registration = self.get_registration(locator)
        if registration is None:
            registration = ToolBrokerRegistration(
                backend_kind=self.backend_kind,
                locator=downstream.registration.namespaced_name,
                description=downstream.registration.description,
                trust_level=downstream.registration.trust_level,
                enabled=downstream.registration.enabled,
                namespace=downstream.registration.server_name,
                tool_name=downstream.registration.tool_name,
            )
        return ToolBrokerResult(
            registration=registration,
            arguments=downstream.arguments,
            result=downstream.result,
        )


def load_downstream_broker(spec: str) -> DownstreamMcpBroker:
    module_name, separator, attribute_name = spec.partition(':')
    if not separator or not module_name or not attribute_name:
        raise ValueError(
            'Downstream broker spec must look like `package.module:broker` or `package.module:factory`.'
        )
    module = importlib.import_module(module_name)
    target = getattr(module, attribute_name)
    broker = target() if callable(target) else target
    if not isinstance(broker, DownstreamMcpBroker):
        raise TypeError(
            'Downstream broker spec did not resolve to a DownstreamMcpBroker instance.'
        )
    return broker
