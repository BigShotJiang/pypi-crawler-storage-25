from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import shutil
import sys


@dataclass(frozen=True)
class SheltronCommand:
    command_path: Path
    bin_dir: Path


def resolve_installed_sheltron_command() -> SheltronCommand:
    """Return the Sheltron CLI path to pin into agent adapters."""

    command_path = _candidate_sheltron_command()
    if command_path is None:
        raise FileNotFoundError(
            'Could not locate `sheltron` on PATH. Install Sheltron first with '
            '`uv tool install sheltron`, or run from a source checkout with '
            '`uv run --python 3.11 sheltron link <agent>`.'
        )

    return SheltronCommand(command_path=command_path, bin_dir=command_path.parent)


def _candidate_sheltron_command() -> Path | None:
    current_script = Path(sys.argv[0]).expanduser()
    if current_script.name in {'sheltron', 'sheltron.exe'} and current_script.exists():
        return _normalize_command_path(current_script)

    detected = shutil.which('sheltron')
    if detected is not None:
        return _normalize_command_path(detected)
    return None


def _normalize_command_path(raw_path: str | Path) -> Path:
    expanded = Path(raw_path).expanduser()
    return Path(os.path.abspath(os.fspath(expanded)))
