from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Callable

from sheltron_adapters.base import CliHostAdapter, HostAdapterProbe, UnavailableCliHostAdapter


@dataclass(frozen=True)
class BuiltinHostAdapterSpec:
    name: str
    summary: str
    loader: Callable[[], CliHostAdapter]


def _load_nanobot_cli_adapter() -> CliHostAdapter:
    from sheltron_adapters.nanobot.cli_adapter import build_nanobot_cli_adapter

    return build_nanobot_cli_adapter()


def _load_openclaw_cli_adapter() -> CliHostAdapter:
    from sheltron_adapters.openclaw.cli_adapter import build_openclaw_cli_adapter

    return build_openclaw_cli_adapter()


_BUILTIN_HOST_ADAPTER_SPECS: tuple[BuiltinHostAdapterSpec, ...] = (
    BuiltinHostAdapterSpec(
        name='nanobot',
        summary='manage and run nanobot through Sheltron',
        loader=_load_nanobot_cli_adapter,
    ),
    BuiltinHostAdapterSpec(
        name='openclaw',
        summary='manage OpenClaw through Sheltron',
        loader=_load_openclaw_cli_adapter,
    ),
)


def get_builtin_host_adapter_specs() -> tuple[BuiltinHostAdapterSpec, ...]:
    return _BUILTIN_HOST_ADAPTER_SPECS


@lru_cache(maxsize=None)
def _load_builtin_host_adapter(name: str) -> CliHostAdapter:
    spec = next((candidate for candidate in _BUILTIN_HOST_ADAPTER_SPECS if candidate.name == name), None)
    if spec is None:
        raise KeyError(f'unknown built-in host adapter: {name}')
    try:
        return spec.loader()
    except Exception as exc:
        return UnavailableCliHostAdapter(
            name=spec.name,
            summary=spec.summary,
            detail=f'import failed: {exc}',
        )


def clear_builtin_host_adapter_cache() -> None:
    _load_builtin_host_adapter.cache_clear()


def get_builtin_host_adapters() -> tuple[CliHostAdapter, ...]:
    return tuple(_load_builtin_host_adapter(spec.name) for spec in _BUILTIN_HOST_ADAPTER_SPECS)


def get_builtin_host_adapter(name: str) -> CliHostAdapter | None:
    if not any(spec.name == name for spec in _BUILTIN_HOST_ADAPTER_SPECS):
        return None
    return _load_builtin_host_adapter(name)


def probe_builtin_host_adapters() -> tuple[HostAdapterProbe, ...]:
    return tuple(adapter.probe() for adapter in get_builtin_host_adapters())
