from __future__ import annotations

import inspect
import json
import shlex
from collections.abc import Callable, Mapping
from pathlib import Path
from typing import Any

from loguru import logger

from sheltron_core import Provenance, TrustLevel
from sheltron_mcp import SheltronMcpService
from sheltron_adapters.nanobot.defense_context import augment_provenance, consume_internal_provenance_kwargs
from sheltron_adapters.nanobot.result_guard import (
    WEB_FETCH_MAX_CHARS,
    WEB_FETCH_TRUNCATION_NOTICE,
    WEB_FETCH_UNTRUSTED_BANNER,
    format_untrusted_tool_text,
)
from sheltron_adapters.nanobot.search_tool import build_governed_search_tool
from sheltron_adapters.nanobot.tool_support import (
    approval_ticket_schema,
    resolve_search_default_count,
    resolve_search_provider_name,
)
from nanobot.agent.hook import AgentHook, AgentHookContext
from nanobot.agent.runner import AgentRunSpec
from nanobot.agent.subagent import SubagentManager
from nanobot.agent.tools.base import Tool
from nanobot.agent.tools.registry import ToolRegistry
from nanobot.agent.tools.web import WebSearchTool
from nanobot.config.schema import WebSearchConfig


def build_governed_subagent_tools(
    *,
    workspace: Path,
    task_id: str,
    origin: Mapping[str, str],
    web_search_config: WebSearchConfig | None,
    web_proxy: str | None,
    exec_timeout: int,
) -> ToolRegistry:
    service = _build_subagent_service(
        workspace=workspace,
        task_id=task_id,
        origin=origin,
    )
    registry = ToolRegistry()
    registry.register(SheltronSubagentReadFileTool(service=service))
    registry.register(SheltronSubagentWriteFileTool(service=service))
    registry.register(SheltronSubagentEditFileTool(service=service))
    registry.register(SheltronSubagentListDirTool(service=service))
    registry.register(
        SheltronSubagentExecTool(
            service=service,
            default_cwd=workspace,
            default_timeout=exec_timeout,
        )
    )
    if web_search_config is not None:
        registry.register(
            build_governed_search_tool(
                workspace=workspace,
                backend_tool=WebSearchTool(config=web_search_config, proxy=web_proxy),
                provider=resolve_search_provider_name(web_search_config),
                default_count=resolve_search_default_count(web_search_config),
                provenance_factory=lambda: _build_subagent_search_provenance(
                    task_id=task_id,
                    origin=origin,
                ),
            )
        )
    registry.register(SheltronSubagentFetchTool(service=service))
    return registry


async def run_governed_subagent(
    manager: SubagentManager,
    *,
    task_id: str,
    task: str,
    label: str,
    origin: Mapping[str, str],
    status: Any | None = None,
) -> None:
    logger.info('Subagent [{}] starting task: {}', task_id, label)

    try:
        web_enabled, web_search_config, web_proxy = _subagent_web_settings(manager)
        tools = build_governed_subagent_tools(
            workspace=manager.workspace,
            task_id=task_id,
            origin=origin,
            web_search_config=web_search_config if web_enabled else None,
            web_proxy=web_proxy,
            exec_timeout=manager.exec_config.timeout,
        )

        system_prompt = manager._build_subagent_prompt()
        messages: list[dict[str, str]] = [
            {'role': 'system', 'content': system_prompt},
            {'role': 'user', 'content': task},
        ]

        class _SubagentHook(AgentHook):
            async def before_execute_tools(self, context: AgentHookContext) -> None:
                for tool_call in context.tool_calls:
                    args_str = json.dumps(tool_call.arguments, ensure_ascii=False)
                    logger.debug(
                        'Subagent [{}] executing: {} with arguments: {}',
                        task_id,
                        tool_call.name,
                        args_str,
                    )

        result = await manager.runner.run(
            _build_nanobot_agent_run_spec(
                initial_messages=messages,
                tools=tools,
                model=manager.model,
                max_iterations=15,
                max_tool_result_chars=getattr(manager, 'max_tool_result_chars', 50_000),
                hook=_SubagentHook(),
                max_iterations_message='Task completed but no final response was generated.',
                error_message=None,
                fail_on_tool_error=True,
            )
        )
        if status is not None:
            status.phase = 'done'
            status.stop_reason = result.stop_reason
        if result.stop_reason == 'tool_error':
            if status is not None:
                status.tool_events = list(result.tool_events)
            await manager._announce_result(
                task_id,
                label,
                task,
                manager._format_partial_progress(result),
                origin,
                'error',
            )
            return
        if result.stop_reason == 'error':
            await manager._announce_result(
                task_id,
                label,
                task,
                result.error or 'Error: subagent execution failed.',
                origin,
                'error',
            )
            return
        final_result = result.final_content or 'Task completed but no final response was generated.'

        logger.info('Subagent [{}] completed successfully', task_id)
        await manager._announce_result(task_id, label, task, final_result, origin, 'ok')

    except Exception as exc:
        if status is not None:
            status.phase = 'error'
            status.error = str(exc)
        error_msg = f'Error: {str(exc)}'
        logger.error('Subagent [{}] failed: {}', task_id, exc)
        await manager._announce_result(task_id, label, task, error_msg, origin, 'error')


def _build_nanobot_agent_run_spec(**kwargs: Any) -> AgentRunSpec:
    parameters = inspect.signature(AgentRunSpec).parameters
    filtered = {key: value for key, value in kwargs.items() if key in parameters}
    if 'max_tool_result_chars' in parameters and filtered.get('max_tool_result_chars') is None:
        filtered['max_tool_result_chars'] = 50_000
    return AgentRunSpec(**filtered)


def _subagent_web_settings(manager: Any) -> tuple[bool, WebSearchConfig | None, str | None]:
    web_config = getattr(manager, 'web_config', None)
    if web_config is not None:
        return (
            bool(getattr(web_config, 'enable', True)),
            getattr(web_config, 'search', None),
            getattr(web_config, 'proxy', None),
        )
    return True, getattr(manager, 'web_search_config', None), getattr(manager, 'web_proxy', None)


def _build_subagent_service(
    *,
    workspace: Path,
    task_id: str,
    origin: Mapping[str, str],
) -> SheltronMcpService:
    service = SheltronMcpService.for_workspace(workspace, system_name='nanobot')
    channel = origin.get('channel') or 'system'
    chat_id = origin.get('chat_id') or 'direct'
    service.provenance = Provenance(
        session_id=f'nanobot:subagent:{channel}:{chat_id}:{task_id}',
        channel=channel,
        actor_id='nanobot_subagent',
        source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
        trigger='nanobot subagent tool call',
    )
    return service


def _build_subagent_search_provenance(
    *,
    task_id: str,
    origin: Mapping[str, str],
) -> Provenance:
    channel = origin.get('channel') or 'system'
    chat_id = origin.get('chat_id') or 'direct'
    return augment_provenance(
        Provenance(
            session_id=f'nanobot:subagent:{channel}:{chat_id}:{task_id}',
            channel=channel,
            actor_id='nanobot_subagent',
            source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
            trigger='nanobot subagent web_search tool call',
        )
    )


class _SheltronSubagentTool(Tool):
    def __init__(self, *, service: SheltronMcpService) -> None:
        self._service = service

    def _blocked_result(self, payload: object) -> str:
        return json.dumps(payload, sort_keys=True)

    @staticmethod
    def _service_payload_or_error(
        action: str,
        call: Callable[[], dict[str, object]],
    ) -> tuple[dict[str, object] | None, str | None]:
        try:
            return call(), None
        except Exception as exc:
            return None, f'Error {action}: {exc}'


class SheltronSubagentReadFileTool(_SheltronSubagentTool):
    _MAX_CHARS = 128_000
    _DEFAULT_LIMIT = 2000

    @property
    def name(self) -> str:
        return 'read_file'

    @property
    def description(self) -> str:
        return (
            'Read the contents of a file through Sheltron policy. '
            'Returns numbered lines. Use offset and limit to paginate through large files.'
        )

    @property
    def parameters(self) -> dict[str, object]:
        return {
            'type': 'object',
            'properties': {
                'path': {'type': 'string', 'description': 'The file path to read'},
                'offset': {
                    'type': 'integer',
                    'description': 'Line number to start reading from (1-indexed, default 1)',
                    'minimum': 1,
                },
                'limit': {
                    'type': 'integer',
                    'description': 'Maximum number of lines to read (default 2000)',
                    'minimum': 1,
                },
                'approval_ticket_id': approval_ticket_schema(
                    'Optional approval ticket id used to resume an approval-required read.'
                ),
            },
            'required': ['path'],
        }

    async def execute(
        self,
        path: str | None = None,
        offset: int = 1,
        limit: int | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        if not path:
            return 'Error reading file: Unknown path'
        payload, error = self._service_payload_or_error(
            'reading file',
            lambda: self._service.read_file(
                path,
                approval_ticket_id=approval_ticket_id,
            ),
        )
        if error is not None:
            return error
        if payload is None:
            return 'Error reading file: no service payload'
        if not payload['executed']:
            return self._blocked_result(payload)

        text_content = payload.get('content') or ''
        if not text_content:
            return f'(Empty file: {path})'

        all_lines = text_content.splitlines()
        total = len(all_lines)
        if offset < 1:
            offset = 1
        if offset > total:
            return f'Error: offset {offset} is beyond end of file ({total} lines)'

        start = offset - 1
        end = min(start + (limit or self._DEFAULT_LIMIT), total)
        numbered = [f'{start + i + 1}| {line}' for i, line in enumerate(all_lines[start:end])]
        result = '\n'.join(numbered)

        if len(result) > self._MAX_CHARS:
            trimmed: list[str] = []
            chars = 0
            for line in numbered:
                chars += len(line) + 1
                if chars > self._MAX_CHARS:
                    break
                trimmed.append(line)
            end = start + len(trimmed)
            result = '\n'.join(trimmed)

        if end < total:
            result += f'\n\n(Showing lines {offset}-{end} of {total}. Use offset={end + 1} to continue.)'
        else:
            result += f'\n\n(End of file — {total} lines total)'
        return result


class SheltronSubagentWriteFileTool(_SheltronSubagentTool):
    @property
    def name(self) -> str:
        return 'write_file'

    @property
    def description(self) -> str:
        return 'Write content to a file through Sheltron policy. Creates parent directories if needed.'

    @property
    def parameters(self) -> dict[str, object]:
        return {
            'type': 'object',
            'properties': {
                'path': {'type': 'string', 'description': 'The file path to write to'},
                'content': {'type': 'string', 'description': 'The content to write'},
                'approval_ticket_id': approval_ticket_schema(
                    'Optional approval ticket id used to resume an approval-required write.'
                ),
            },
            'required': ['path', 'content'],
        }

    async def execute(
        self,
        path: str | None = None,
        content: str | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        if not path:
            return 'Error writing file: Unknown path'
        if content is None:
            return 'Error writing file: Unknown content'
        payload, error = self._service_payload_or_error(
            'writing file',
            lambda: self._service.write_file(
                path,
                content=content,
                create_parents=True,
                approval_ticket_id=approval_ticket_id,
            ),
        )
        if error is not None:
            return error
        if payload is None:
            return 'Error writing file: no service payload'
        if not payload['executed']:
            return self._blocked_result(payload)
        return f"Successfully wrote {len(content)} bytes to {payload['resource']}"


class SheltronSubagentEditFileTool(_SheltronSubagentTool):
    @property
    def name(self) -> str:
        return 'edit_file'

    @property
    def description(self) -> str:
        return 'Edit a file through Sheltron policy by replacing old_text with new_text.'

    @property
    def parameters(self) -> dict[str, object]:
        return {
            'type': 'object',
            'properties': {
                'path': {'type': 'string', 'description': 'The file path to edit'},
                'old_text': {'type': 'string', 'description': 'The text to find and replace'},
                'new_text': {'type': 'string', 'description': 'The text to replace with'},
                'approval_ticket_id': approval_ticket_schema(
                    'Optional approval ticket id used to resume an approval-required edit.'
                ),
            },
            'required': ['path', 'old_text', 'new_text'],
        }

    async def execute(
        self,
        path: str | None = None,
        old_text: str | None = None,
        new_text: str | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        if not path:
            return 'Error editing file: Unknown path'
        if old_text is None:
            return 'Error editing file: Unknown old_text'
        if new_text is None:
            return 'Error editing file: Unknown new_text'
        payload, error = self._service_payload_or_error(
            'editing file',
            lambda: self._service.edit_file(
                path,
                old_text=old_text,
                new_text=new_text,
                approval_ticket_id=approval_ticket_id,
            ),
        )
        if error is not None:
            return error
        if payload is None:
            return 'Error editing file: no service payload'
        if not payload['executed']:
            return self._blocked_result(payload)
        return f"Successfully edited {payload['resource']}"


class SheltronSubagentListDirTool(_SheltronSubagentTool):
    _DEFAULT_MAX = 200
    _IGNORE_DIRS = {
        '.git',
        'node_modules',
        '__pycache__',
        '.venv',
        'venv',
        'dist',
        'build',
        '.tox',
        '.mypy_cache',
        '.pytest_cache',
        '.ruff_cache',
        '.coverage',
        'htmlcov',
    }

    @property
    def name(self) -> str:
        return 'list_dir'

    @property
    def description(self) -> str:
        return (
            'List the contents of a directory through Sheltron policy. '
            'Set recursive=true to explore nested structure.'
        )

    @property
    def parameters(self) -> dict[str, object]:
        return {
            'type': 'object',
            'properties': {
                'path': {'type': 'string', 'description': 'The directory path to list'},
                'recursive': {
                    'type': 'boolean',
                    'description': 'Recursively list all files (default false)',
                },
                'max_entries': {
                    'type': 'integer',
                    'description': 'Maximum entries to return (default 200)',
                    'minimum': 1,
                },
                'approval_ticket_id': approval_ticket_schema(
                    'Optional approval ticket id used to resume an approval-required directory listing.'
                ),
            },
            'required': ['path'],
        }

    async def execute(
        self,
        path: str | None = None,
        recursive: bool = False,
        max_entries: int | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        if path is None:
            return 'Error listing directory: Unknown path'
        payload, error = self._service_payload_or_error(
            'listing directory',
            lambda: self._service.list_dir(
                path,
                approval_ticket_id=approval_ticket_id,
            ),
        )
        if error is not None:
            return error
        if payload is None:
            return 'Error listing directory: no service payload'
        if not payload['executed']:
            return self._blocked_result(payload)

        root = Path(payload['resource'])
        if not root.exists():
            return f'Error: Directory not found: {path}'
        if not root.is_dir():
            return f'Error: Not a directory: {path}'

        cap = max_entries or self._DEFAULT_MAX
        items: list[str] = []
        total = 0

        if recursive:
            for item in sorted(root.rglob('*')):
                if any(part in self._IGNORE_DIRS for part in item.parts):
                    continue
                total += 1
                if len(items) < cap:
                    rel = item.relative_to(root)
                    items.append(f'{rel}/' if item.is_dir() else str(rel))
        else:
            for item in sorted(root.iterdir()):
                if item.name in self._IGNORE_DIRS:
                    continue
                total += 1
                if len(items) < cap:
                    prefix = '📁 ' if item.is_dir() else '📄 '
                    items.append(f'{prefix}{item.name}')

        if not items and total == 0:
            return f'Directory {path} is empty'

        result = '\n'.join(items)
        if total > cap:
            result += f'\n\n(truncated, showing first {cap} of {total} entries)'
        return result


class SheltronSubagentExecTool(_SheltronSubagentTool):
    _MAX_OUTPUT = 10_000

    def __init__(
        self,
        *,
        service: SheltronMcpService,
        default_cwd: Path,
        default_timeout: int,
    ) -> None:
        super().__init__(service=service)
        self._default_cwd = default_cwd
        self._default_timeout = default_timeout

    @property
    def name(self) -> str:
        return 'exec'

    @property
    def description(self) -> str:
        return (
            'Execute a command through Sheltron policy. '
            'Provide command as an argv array when possible; string commands are split without shell expansion.'
        )

    @property
    def parameters(self) -> dict[str, object]:
        return {
            'type': 'object',
            'properties': {
                'command': {
                    'description': 'The command to execute as argv array or plain string.',
                    'oneOf': [
                        {'type': 'array', 'items': {'type': 'string'}},
                        {'type': 'string'},
                    ],
                },
                'working_dir': {
                    'type': 'string',
                    'description': 'Optional working directory for the command',
                },
                'timeout': {
                    'type': 'integer',
                    'description': 'Timeout in seconds.',
                    'minimum': 1,
                    'maximum': 600,
                },
                'approval_ticket_id': approval_ticket_schema(
                    'Optional approval ticket id used to resume an approval-required exec.'
                ),
            },
            'required': ['command'],
        }

    async def execute(
        self,
        command: str | list[str] | None = None,
        working_dir: str | None = None,
        timeout: int | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        if command is None:
            return 'Error executing command: Unknown command'
        try:
            argv = _normalize_command_argv(command)
        except ValueError as exc:
            return f'Error executing command: {exc}'
        payload, error = self._service_payload_or_error(
            'executing command',
            lambda: self._service.execute_command(
                argv,
                cwd=working_dir or str(self._default_cwd),
                timeout_seconds=timeout or self._default_timeout,
                approval_ticket_id=approval_ticket_id,
                **consume_internal_provenance_kwargs(),
            ),
        )
        if error is not None:
            return error
        if payload is None:
            return 'Error executing command: no service payload'
        if not payload['executed']:
            return self._blocked_result(payload)

        output_parts: list[str] = []
        stdout = payload.get('stdout') or ''
        stderr = payload.get('stderr') or ''
        if stdout:
            output_parts.append(stdout)
        if stderr.strip():
            output_parts.append(f'STDERR:\n{stderr}')
        output_parts.append(f"\nExit code: {payload.get('exit_code', 0)}")
        result = '\n'.join(output_parts) if output_parts else '(no output)'
        if len(result) > self._MAX_OUTPUT:
            half = self._MAX_OUTPUT // 2
            result = (
                result[:half]
                + f"\n\n... ({len(result) - self._MAX_OUTPUT:,} chars truncated) ...\n\n"
                + result[-half:]
            )
        return result


class SheltronSubagentFetchTool(_SheltronSubagentTool):
    _DEFAULT_MAX_CHARS = WEB_FETCH_MAX_CHARS

    @property
    def name(self) -> str:
        return 'web_fetch'

    @property
    def description(self) -> str:
        return 'Fetch a URL through Sheltron policy and return untrusted extracted content.'

    @property
    def parameters(self) -> dict[str, object]:
        return {
            'type': 'object',
            'properties': {
                'url': {'type': 'string', 'description': 'URL to fetch'},
                'extractMode': {'type': 'string', 'enum': ['markdown', 'text'], 'default': 'markdown'},
                'maxChars': {'type': 'integer', 'minimum': 100},
                'approval_ticket_id': approval_ticket_schema(
                    'Optional approval ticket id used to resume an approval-required fetch.'
                ),
            },
            'required': ['url'],
        }

    async def execute(
        self,
        url: str,
        extractMode: str = 'markdown',
        maxChars: int | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs, extractMode
        payload, error = self._service_payload_or_error(
            'fetching URL',
            lambda: self._service.fetch_url(
                url,
                approval_ticket_id=approval_ticket_id,
            ),
        )
        if error is not None:
            return json.dumps({'error': error.removeprefix('Error fetching URL: '), 'url': url}, ensure_ascii=False)
        if payload is None:
            return json.dumps({'error': 'no service payload', 'url': url}, ensure_ascii=False)
        if not payload['executed']:
            return self._blocked_result(payload)

        text = payload.get('body_text') or ''
        max_chars = maxChars or self._DEFAULT_MAX_CHARS
        truncated = bool(payload.get('truncated'))
        if len(text) > max_chars:
            text = text[:max_chars]
            truncated = True
        text = format_untrusted_tool_text(
            text,
            banner=WEB_FETCH_UNTRUSTED_BANNER,
            max_chars=max_chars,
            truncation_notice=WEB_FETCH_TRUNCATION_NOTICE,
        )
        return json.dumps(
            {
                'url': url,
                'finalUrl': payload.get('final_url') or url,
                'status': payload.get('status_code'),
                'extractor': 'sheltron',
                'truncated': truncated,
                'length': len(text),
                'untrusted': True,
                'text': text,
                'contentType': payload.get('content_type'),
                'error': payload.get('error'),
            },
            ensure_ascii=False,
        )


def _normalize_command_argv(command: str | list[str]) -> list[str]:
    if isinstance(command, list):
        argv = [str(part) for part in command if str(part)]
    else:
        argv = shlex.split(command)
    if not argv:
        raise ValueError('Command must not be empty.')
    return argv
