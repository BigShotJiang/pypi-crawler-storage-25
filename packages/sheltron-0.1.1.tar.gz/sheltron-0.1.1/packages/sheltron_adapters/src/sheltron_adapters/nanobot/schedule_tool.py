from __future__ import annotations

from collections.abc import Callable
import inspect
from pathlib import Path
from typing import Any

from sheltron_core import (
    Provenance,
    TrustLevel,
)
from sheltron_adapters.nanobot.defense_context import augment_provenance
from sheltron_adapters.nanobot.gateway_context import get_workspace_gateway_adapter
from sheltron_adapters.nanobot.runtime_session import standalone_runtime_session
from sheltron_adapters.nanobot.tool_support import schema_with_approval_ticket, serialize_blocked_result
from sheltron_runtime import ScheduledTaskSpec
from nanobot.agent.subagent import SubagentManager
from nanobot.agent.tools.cron import CronTool
from nanobot.agent.tools.registry import ToolRegistry
from nanobot.agent.tools.spawn import SpawnTool
from nanobot.cron.service import CronService


class SheltronSpawnTool(SpawnTool):
    def __init__(self, *, workspace: Path, manager: SubagentManager) -> None:
        super().__init__(manager=manager)
        self._adapter = get_workspace_gateway_adapter(workspace, system_name='nanobot')

    @property
    def description(self) -> str:
        return (
            'Spawn a background subagent subject to Sheltron policy. '
            'Spawn itself requires approval, and the spawned subagent runs with Sheltron-governed file, exec, and fetch tools.'
        )

    @property
    def parameters(self) -> dict[str, object]:
        return schema_with_approval_ticket(
            super().parameters,
            description='Optional approval ticket id used to resume an approval-required spawn request.',
        )

    async def execute(
        self,
        task: str,
        label: str | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        with standalone_runtime_session():
            result = self._adapter.before_schedule_task(
                ScheduledTaskSpec(
                    task_kind='spawn',
                    task=task,
                    label=label,
                    default_channel=self._origin_channel or None,
                    default_recipient=self._origin_chat_id or None,
                ),
                provenance=self._build_provenance(),
                approval_ticket_id=approval_ticket_id,
            )
            if not result.executed:
                result = self._adapter.after_action(result, result_summary='spawn=blocked')
                return serialize_blocked_result(self._adapter, result)

            response = await self._manager.spawn(
                task=task,
                label=label,
                origin_channel=self._origin_channel,
                origin_chat_id=self._origin_chat_id,
                session_key=self._session_key,
            )
            result = self._adapter.after_action(result, result_summary='spawn=started')
            if not result.executed:
                return serialize_blocked_result(self._adapter, result)
            return response

    def _build_provenance(self) -> Provenance:
        return augment_provenance(
            Provenance(
                session_id=self._session_key,
                channel=self._origin_channel,
                actor_id='nanobot',
                source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
                trigger='nanobot spawn tool call',
            )
        )


class SheltronCronTool(CronTool):
    def __init__(
        self,
        *,
        workspace: Path,
        cron_service: CronService,
        default_timezone: str = 'UTC',
    ) -> None:
        super().__init__(cron_service, default_timezone=default_timezone)
        self._adapter = get_workspace_gateway_adapter(workspace, system_name='nanobot')

    @property
    def description(self) -> str:
        return (
            'Schedule reminders and recurring tasks subject to Sheltron policy. '
            'Creating jobs requires approval, listing and removing jobs are allowed, and unsafe cron patterns are denied.'
        )

    @property
    def parameters(self) -> dict[str, object]:
        return schema_with_approval_ticket(
            super().parameters,
            description='Optional approval ticket id used to resume an approval-required cron add request.',
        )

    async def execute(
        self,
        action: str,
        name: str | None = None,
        message: str = '',
        every_seconds: int | None = None,
        cron_expr: str | None = None,
        tz: str | None = None,
        at: str | None = None,
        job_id: str | None = None,
        deliver: bool = True,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        with standalone_runtime_session():
            result = self._adapter.before_schedule_task(
                ScheduledTaskSpec(
                    task_kind='cron',
                    action=action,
                    label=name,
                    message=message,
                    every_seconds=every_seconds,
                    cron_expr=cron_expr,
                    tz=tz,
                    at=at,
                    job_id=job_id,
                    default_channel=self._channel or None,
                    default_recipient=self._chat_id or None,
                    in_cron_context=self._in_cron_context.get(),
                ),
                provenance=self._build_provenance(),
                approval_ticket_id=approval_ticket_id,
            )
            if not result.executed:
                result = self._adapter.after_action(result, result_summary=f'cron_action={action} blocked')
                return serialize_blocked_result(self._adapter, result)

            response = await _call_nanobot_cron_execute(
                super().execute,
                action=action,
                name=name,
                message=message,
                every_seconds=every_seconds,
                cron_expr=cron_expr,
                tz=tz,
                at=at,
                job_id=job_id,
                deliver=deliver,
            )
            result = self._adapter.after_action(result, result_summary=f'cron_action={action}')
            if not result.executed:
                return serialize_blocked_result(self._adapter, result)
            return response

    def _build_provenance(self) -> Provenance:
        channel = self._channel or 'system'
        chat_id = self._chat_id or 'direct'
        return augment_provenance(
            Provenance(
                session_id=f'nanobot:{channel}:{chat_id}',
                channel=channel,
                actor_id='nanobot',
                source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
                trigger='nanobot cron tool call',
            )
        )


async def _call_nanobot_cron_execute(
    execute: Callable[..., Any],
    *,
    action: str,
    name: str | None,
    message: str,
    every_seconds: int | None,
    cron_expr: str | None,
    tz: str | None,
    at: str | None,
    job_id: str | None,
    deliver: bool,
) -> str:
    parameters = inspect.signature(execute).parameters
    accepts_var_kwargs = any(parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values())
    call_kwargs: dict[str, Any] = {
        'action': action,
        'name': name,
        'message': message,
        'every_seconds': every_seconds,
        'cron_expr': cron_expr,
        'tz': tz,
        'at': at,
        'job_id': job_id,
        'deliver': deliver,
    }
    if not accepts_var_kwargs:
        call_kwargs = {key: value for key, value in call_kwargs.items() if key in parameters}
    return await execute(**call_kwargs)


def replace_schedule_tools(
    registry: ToolRegistry,
    *,
    workspace: Path,
    subagent_manager: SubagentManager,
    cron_service: CronService | None,
    default_timezone: str = 'UTC',
) -> None:
    registry.register(
        SheltronSpawnTool(
            workspace=workspace,
            manager=subagent_manager,
        )
    )
    if cron_service is not None:
        registry.register(
            SheltronCronTool(
                workspace=workspace,
                cron_service=cron_service,
                default_timezone=default_timezone,
            )
        )
