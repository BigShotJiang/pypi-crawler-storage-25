from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from sheltron_core import DefenseRouter
from sheltron_runtime import SheltronGateway, SheltronGatewayAdapter
from sheltron_adapters.nanobot.runtime_session import (
    ActiveGatewayContext,
    current_runtime_session,
    reset_runtime_session,
    with_gateway_context,
)


@contextmanager
def active_gateway_context(
    *,
    system_name: str = 'nanobot',
    defense_router: DefenseRouter | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
    candidate_memory_store_path: str | Path | None = None,
    message_secret_values: tuple[str, ...] | None = None,
    message_max_content_chars: int = 4_000,
    allowed_target_locators: frozenset[str] | None = None,
) -> Iterator[None]:
    token = with_gateway_context(
        ActiveGatewayContext(
            system_name=system_name,
            defense_router=defense_router,
            approval_store_path=approval_store_path,
            audit_log_path=audit_log_path,
            candidate_memory_store_path=candidate_memory_store_path,
            message_secret_values=message_secret_values,
            message_max_content_chars=message_max_content_chars,
            allowed_target_locators=allowed_target_locators,
        )
    )
    try:
        yield
    finally:
        reset_runtime_session(token)


def get_workspace_gateway(
    workspace: str | Path,
    *,
    system_name: str | None = None,
    defense_router: DefenseRouter | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
    candidate_memory_store_path: str | Path | None = None,
    message_secret_values: tuple[str, ...] | None = None,
    message_max_content_chars: int | None = None,
    allowed_target_locators: frozenset[str] | None = None,
) -> SheltronGateway:
    resolved_workspace = Path(workspace).expanduser().resolve(strict=False)
    context = current_runtime_session().gateway_context
    if context is None:
        return SheltronGateway.for_workspace(
            resolved_workspace,
            system_name=system_name or 'nanobot',
            defense_router=defense_router,
            approval_store_path=approval_store_path,
            audit_log_path=audit_log_path,
            candidate_memory_store_path=candidate_memory_store_path,
            message_secret_values=message_secret_values,
            message_max_content_chars=message_max_content_chars or 4_000,
            allowed_target_locators=allowed_target_locators,
        )

    gateway = context.gateways.get(resolved_workspace)
    if gateway is None:
        gateway = SheltronGateway.for_workspace(
            resolved_workspace,
            system_name=system_name or context.system_name,
            defense_router=defense_router if defense_router is not None else context.defense_router,
            approval_store_path=approval_store_path or context.approval_store_path,
            audit_log_path=audit_log_path or context.audit_log_path,
            candidate_memory_store_path=candidate_memory_store_path or context.candidate_memory_store_path,
            message_secret_values=message_secret_values or context.message_secret_values,
            message_max_content_chars=message_max_content_chars or context.message_max_content_chars,
            allowed_target_locators=allowed_target_locators or context.allowed_target_locators,
        )
        context.gateways[resolved_workspace] = gateway
    elif (
        message_secret_values
        or message_max_content_chars is not None
        or allowed_target_locators is not None
    ):
        gateway = SheltronGateway.for_workspace(
            resolved_workspace,
            system_name=system_name or context.system_name,
            defense_router=defense_router if defense_router is not None else context.defense_router,
            approval_store_path=approval_store_path or context.approval_store_path or gateway.approval_store_path,
            audit_log_path=audit_log_path or context.audit_log_path or gateway.audit_log_path,
            candidate_memory_store_path=(
                candidate_memory_store_path
                or context.candidate_memory_store_path
                or gateway.candidate_memory_store_path
            ),
            message_secret_values=message_secret_values or context.message_secret_values,
            message_max_content_chars=message_max_content_chars or context.message_max_content_chars,
            allowed_target_locators=allowed_target_locators or context.allowed_target_locators,
        )
        context.gateways[resolved_workspace] = gateway
    return gateway


def get_workspace_gateway_adapter(
    workspace: str | Path,
    *,
    system_name: str | None = None,
    defense_router: DefenseRouter | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
    candidate_memory_store_path: str | Path | None = None,
    message_secret_values: tuple[str, ...] | None = None,
    message_max_content_chars: int | None = None,
    allowed_target_locators: frozenset[str] | None = None,
) -> SheltronGatewayAdapter:
    return SheltronGatewayAdapter(
        get_workspace_gateway(
            workspace,
            system_name=system_name,
            defense_router=defense_router,
            approval_store_path=approval_store_path,
            audit_log_path=audit_log_path,
            candidate_memory_store_path=candidate_memory_store_path,
            message_secret_values=message_secret_values,
            message_max_content_chars=message_max_content_chars,
            allowed_target_locators=allowed_target_locators,
        )
    )
