from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar, Token
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Iterator

from sheltron_core import DefenseRouter, Evidence, TrustLevel
from sheltron_runtime import SheltronGateway


@dataclass(slots=True)
class ActiveGatewayContext:
    system_name: str = 'nanobot'
    defense_router: DefenseRouter | None = None
    approval_store_path: str | Path | None = None
    audit_log_path: str | Path | None = None
    candidate_memory_store_path: str | Path | None = None
    message_secret_values: tuple[str, ...] | None = None
    message_max_content_chars: int = 4_000
    allowed_target_locators: frozenset[str] | None = None
    gateways: dict[Path, SheltronGateway] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class PendingDefenseEvidence:
    evidence: tuple[Evidence, ...] = ()
    trust_levels: tuple[TrustLevel, ...] = ()


@dataclass(slots=True)
class NanobotRuntimeSession:
    gateway_context: ActiveGatewayContext | None = None
    pending_defense_evidence: PendingDefenseEvidence = field(default_factory=PendingDefenseEvidence)


_ACTIVE_RUNTIME_SESSION: ContextVar[NanobotRuntimeSession | None] = ContextVar(
    'sheltron_nanobot_runtime_session',
    default=None,
)
_AMBIENT_STANDALONE_SESSION: NanobotRuntimeSession | None = None


def current_runtime_session() -> NanobotRuntimeSession:
    current = active_runtime_session()
    if current is not None:
        return current
    return NanobotRuntimeSession()


def active_runtime_session() -> NanobotRuntimeSession | None:
    current = _ACTIVE_RUNTIME_SESSION.get()
    if current is not None:
        return current
    return _AMBIENT_STANDALONE_SESSION


def set_runtime_session(session: NanobotRuntimeSession | None) -> Token[NanobotRuntimeSession | None]:
    return _ACTIVE_RUNTIME_SESSION.set(session)


def reset_runtime_session(token: Token[NanobotRuntimeSession | None]) -> None:
    _ACTIVE_RUNTIME_SESSION.reset(token)


def clear_runtime_session() -> None:
    global _AMBIENT_STANDALONE_SESSION
    _AMBIENT_STANDALONE_SESSION = None
    _ACTIVE_RUNTIME_SESSION.set(None)


def with_gateway_context(context: ActiveGatewayContext | None) -> Token[NanobotRuntimeSession | None]:
    current = current_runtime_session()
    return set_runtime_session(replace(current, gateway_context=context))


def update_pending_defense_evidence(pending: PendingDefenseEvidence) -> None:
    global _AMBIENT_STANDALONE_SESSION
    current = current_runtime_session()
    updated = replace(current, pending_defense_evidence=pending)
    if _ACTIVE_RUNTIME_SESSION.get() is not None:
        _ACTIVE_RUNTIME_SESSION.set(updated)
    else:
        _AMBIENT_STANDALONE_SESSION = updated


def clear_pending_defense_evidence() -> PendingDefenseEvidence:
    global _AMBIENT_STANDALONE_SESSION
    current = active_runtime_session()
    if current is None:
        return PendingDefenseEvidence()
    pending = current.pending_defense_evidence
    updated = replace(current, pending_defense_evidence=PendingDefenseEvidence())
    if _ACTIVE_RUNTIME_SESSION.get() is not None:
        _ACTIVE_RUNTIME_SESSION.set(updated)
    elif updated.gateway_context is None:
        _AMBIENT_STANDALONE_SESSION = None
    else:
        _AMBIENT_STANDALONE_SESSION = updated
    return pending


@contextmanager
def standalone_runtime_session() -> Iterator[None]:
    global _AMBIENT_STANDALONE_SESSION
    current = _ACTIVE_RUNTIME_SESSION.get()
    if current is not None:
        yield
        return
    token = set_runtime_session(_AMBIENT_STANDALONE_SESSION or NanobotRuntimeSession())
    try:
        yield
    finally:
        active = _ACTIVE_RUNTIME_SESSION.get()
        if active is not None and active.gateway_context is None:
            if active.pending_defense_evidence.evidence or active.pending_defense_evidence.trust_levels:
                _AMBIENT_STANDALONE_SESSION = active
            else:
                _AMBIENT_STANDALONE_SESSION = None
        reset_runtime_session(token)
