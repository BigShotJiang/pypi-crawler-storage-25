from __future__ import annotations

from importlib import import_module
from typing import Any

_EXPORTS = {
    'SHELTRON_NANOBOT_SERVER_NAME': ('sheltron_adapters.nanobot.compat', 'SHELTRON_NANOBOT_SERVER_NAME'),
    'DANGEROUS_BUILTIN_TOOL_NAMES': ('sheltron_adapters.nanobot.compat', 'DANGEROUS_BUILTIN_TOOL_NAMES'),
    'apply_sheltron_runtime_profile': ('sheltron_adapters.nanobot.compat', 'apply_sheltron_runtime_profile'),
    'build_sheltron_mcp_server_data': ('sheltron_adapters.nanobot.compat', 'build_sheltron_mcp_server_data'),
    'strip_dangerous_builtin_tools': ('sheltron_adapters.nanobot.compat', 'strip_dangerous_builtin_tools'),
    'patched_nanobot_runtime': ('sheltron_adapters.nanobot.launcher', 'patched_nanobot_runtime'),
    'run_nanobot_agent': ('sheltron_adapters.nanobot.launcher', 'run_nanobot_agent'),
    'run_nanobot_command': ('sheltron_adapters.nanobot.launcher', 'run_nanobot_command'),
    'run_nanobot_gateway': ('sheltron_adapters.nanobot.launcher', 'run_nanobot_gateway'),
    'maybe_resume_with_inline_approval': (
        'sheltron_adapters.nanobot.approval_bridge',
        'maybe_resume_with_inline_approval',
    ),
    'parse_approval_required_result': (
        'sheltron_adapters.nanobot.approval_bridge',
        'parse_approval_required_result',
    ),
    'finalize_tool_result': ('sheltron_adapters.nanobot.tool_bridge', 'finalize_tool_result'),
    'SUPPORTED_NANOBOT_PROFILES': ('sheltron_adapters.nanobot.install', 'SUPPORTED_NANOBOT_PROFILES'),
    'DoctorCheck': ('sheltron_adapters.nanobot.install', 'DoctorCheck'),
    'DoctorStatus': ('sheltron_adapters.nanobot.install', 'DoctorStatus'),
    'NanobotDisableResult': ('sheltron_adapters.nanobot.install', 'NanobotDisableResult'),
    'NanobotDoctorReport': ('sheltron_adapters.nanobot.install', 'NanobotDoctorReport'),
    'NanobotEnableResult': ('sheltron_adapters.nanobot.install', 'NanobotEnableResult'),
    'NanobotInstallResult': ('sheltron_adapters.nanobot.install', 'NanobotInstallResult'),
    'NanobotInstallState': ('sheltron_adapters.nanobot.install', 'NanobotInstallState'),
    'NanobotInstallationTarget': ('sheltron_adapters.nanobot.install', 'NanobotInstallationTarget'),
    'NanobotProtectionState': ('sheltron_adapters.nanobot.install', 'NanobotProtectionState'),
    'NanobotUninstallResult': ('sheltron_adapters.nanobot.install', 'NanobotUninstallResult'),
    'default_nanobot_config_path': ('sheltron_adapters.nanobot.install', 'default_nanobot_config_path'),
    'default_nanobot_install_state_path': (
        'sheltron_adapters.nanobot.install',
        'default_nanobot_install_state_path',
    ),
    'disable_nanobot': ('sheltron_adapters.nanobot.install', 'disable_nanobot'),
    'discover_nanobot_targets': ('sheltron_adapters.nanobot.install', 'discover_nanobot_targets'),
    'doctor_nanobot': ('sheltron_adapters.nanobot.install', 'doctor_nanobot'),
    'enable_nanobot': ('sheltron_adapters.nanobot.install', 'enable_nanobot'),
    'install_nanobot': ('sheltron_adapters.nanobot.install', 'install_nanobot'),
    'uninstall_nanobot': ('sheltron_adapters.nanobot.install', 'uninstall_nanobot'),
    'default_workspace_candidate_memory_store_path': (
        'sheltron_adapters.nanobot.memory_bridge',
        'default_workspace_candidate_memory_store_path',
    ),
    'save_history_candidate': ('sheltron_adapters.nanobot.memory_bridge', 'save_history_candidate'),
    'save_long_term_candidate': ('sheltron_adapters.nanobot.memory_bridge', 'save_long_term_candidate'),
    'BLOCKED_TOOL_RESULT_HEADER': (
        'sheltron_adapters.nanobot.result_guard',
        'BLOCKED_TOOL_RESULT_HEADER',
    ),
    'NO_WORKAROUND_GUIDANCE': ('sheltron_adapters.nanobot.result_guard', 'NO_WORKAROUND_GUIDANCE'),
    'WEB_FETCH_MAX_CHARS': ('sheltron_adapters.nanobot.result_guard', 'WEB_FETCH_MAX_CHARS'),
    'WEB_FETCH_TRUNCATION_NOTICE': (
        'sheltron_adapters.nanobot.result_guard',
        'WEB_FETCH_TRUNCATION_NOTICE',
    ),
    'WEB_FETCH_UNTRUSTED_BANNER': (
        'sheltron_adapters.nanobot.result_guard',
        'WEB_FETCH_UNTRUSTED_BANNER',
    ),
    'WEB_SEARCH_MAX_CHARS': ('sheltron_adapters.nanobot.result_guard', 'WEB_SEARCH_MAX_CHARS'),
    'WEB_SEARCH_TRUNCATION_NOTICE': (
        'sheltron_adapters.nanobot.result_guard',
        'WEB_SEARCH_TRUNCATION_NOTICE',
    ),
    'WEB_SEARCH_UNTRUSTED_BANNER': (
        'sheltron_adapters.nanobot.result_guard',
        'WEB_SEARCH_UNTRUSTED_BANNER',
    ),
    'format_untrusted_tool_text': (
        'sheltron_adapters.nanobot.result_guard',
        'format_untrusted_tool_text',
    ),
    'harden_tool_result': ('sheltron_adapters.nanobot.result_guard', 'harden_tool_result'),
    'NanobotAttackHarness': ('sheltron_adapters.nanobot.attack_harness', 'NanobotAttackHarness'),
    'SheltronMessageTool': ('sheltron_adapters.nanobot.message_tool', 'SheltronMessageTool'),
    'discover_env_secret_values': (
        'sheltron_adapters.nanobot.message_tool',
        'discover_env_secret_values',
    ),
    'replace_message_tool': ('sheltron_adapters.nanobot.message_tool', 'replace_message_tool'),
    'SheltronCronTool': ('sheltron_adapters.nanobot.schedule_tool', 'SheltronCronTool'),
    'SheltronSpawnTool': ('sheltron_adapters.nanobot.schedule_tool', 'SheltronSpawnTool'),
    'replace_schedule_tools': ('sheltron_adapters.nanobot.schedule_tool', 'replace_schedule_tools'),
    'SheltronGovernedSearchTool': (
        'sheltron_adapters.nanobot.search_tool',
        'SheltronGovernedSearchTool',
    ),
    'build_governed_search_tool': (
        'sheltron_adapters.nanobot.search_tool',
        'build_governed_search_tool',
    ),
    'replace_search_tool': ('sheltron_adapters.nanobot.search_tool', 'replace_search_tool'),
    'build_governed_subagent_tools': (
        'sheltron_adapters.nanobot.subagent_tools',
        'build_governed_subagent_tools',
    ),
    'run_governed_subagent': ('sheltron_adapters.nanobot.subagent_tools', 'run_governed_subagent'),
}

_OPTIONAL_NANOBOT_EXPORTS = frozenset(
    {
        'NanobotAttackHarness',
        'SheltronMessageTool',
        'discover_env_secret_values',
        'replace_message_tool',
        'SheltronCronTool',
        'SheltronSpawnTool',
        'replace_schedule_tools',
        'SheltronGovernedSearchTool',
        'build_governed_search_tool',
        'replace_search_tool',
        'build_governed_subagent_tools',
        'run_governed_subagent',
    }
)

__all__ = list(_EXPORTS)


def __getattr__(name: str) -> Any:
    try:
        module_name, attr_name = _EXPORTS[name]
    except KeyError as exc:
        raise AttributeError(f'module {__name__!r} has no attribute {name!r}') from exc

    try:
        value = getattr(import_module(module_name), attr_name)
    except ModuleNotFoundError as exc:
        if name in _OPTIONAL_NANOBOT_EXPORTS and _missing_nanobot_dependency(exc):
            value = None
        else:
            raise
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))


def _missing_nanobot_dependency(exc: ModuleNotFoundError) -> bool:
    name = exc.name or ''
    message = str(exc)
    if name:
        return name == 'nanobot' or name.startswith('nanobot.')
    return "No module named 'nanobot" in message or 'No module named "nanobot' in message
