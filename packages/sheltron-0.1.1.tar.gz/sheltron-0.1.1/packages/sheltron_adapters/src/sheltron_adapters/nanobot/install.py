from __future__ import annotations

import json
import os
import shlex
import shutil
import stat
import subprocess
import sys
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from sheltron_adapters.nanobot.compat import SHELTRON_NANOBOT_SERVER_NAME, build_sheltron_mcp_server_data
from sheltron_adapters.tool_command import resolve_installed_sheltron_command
from sheltron_runtime import DoctorCheck, DoctorStatus

MANAGED_NANOBOT_SHIM_MARKER = 'Sheltron-managed nanobot shim'
SUPPORTED_NANOBOT_PROFILES = ('strict',)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def default_nanobot_config_path() -> Path:
    return Path.home() / '.nanobot' / 'config.json'


def default_nanobot_install_state_path() -> Path:
    return Path.home() / '.sheltron' / 'nanobot' / 'install.json'


def _default_backup_dir(state_path: Path) -> Path:
    return state_path.parent / 'backups'


class NanobotInstallState(BaseModel):
    model_config = ConfigDict(extra='forbid')

    profile: str
    enabled: bool = True
    installed_at: datetime = Field(default_factory=_utcnow)
    config_path: str
    config_backup_path: str
    disabled_config_snapshot_path: str | None = None
    nanobot_command_path: str
    nanobot_command_kind: str
    nanobot_command_backup_path: str | None = None
    nanobot_command_backup_symlink_target: str | None = None
    real_nanobot_command_path: str
    real_nanobot_command_mode: int | None = None
    sheltron_bin_dir: str
    sheltron_command_path: str | None = None
    nanobot_site_packages: str


class NanobotInstallResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    state: NanobotInstallState
    state_path: str


class NanobotUninstallResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    restored_command_path: str
    restored_config_path: str
    state_path: str
    already_uninstalled: bool = False


class NanobotProtectionState(str, Enum):
    NOT_INSTALLED = 'not-installed'
    READY = 'ready'
    ALWAYS_ON = 'always-on'
    BROKEN = 'broken'


class NanobotDoctorReport(BaseModel):
    model_config = ConfigDict(extra='forbid')

    protection_state: NanobotProtectionState
    checks: tuple[DoctorCheck, ...]

    @property
    def healthy(self) -> bool:
        return self.protection_state in {
            NanobotProtectionState.READY,
            NanobotProtectionState.ALWAYS_ON,
        }


class NanobotEnableResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    state: NanobotInstallState
    state_path: str


class NanobotDisableResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    state: NanobotInstallState
    state_path: str


class NanobotInstallationTarget(BaseModel):
    model_config = ConfigDict(extra='forbid')

    command_path: str
    real_command_path: str
    install_kind: str
    environment_root: str


def install_nanobot(
    *,
    profile: str = 'strict',
    config_path: str | Path | None = None,
    nanobot_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
    force: bool = False,
) -> NanobotInstallResult:
    _require_supported_profile(profile)
    resolved_config_path = Path(config_path or default_nanobot_config_path()).expanduser().resolve(strict=False)
    resolved_command_path = _select_nanobot_install_command_path(nanobot_command_path)
    resolved_state_path = Path(state_path or default_nanobot_install_state_path()).expanduser().resolve(strict=False)
    backup_dir = _default_backup_dir(resolved_state_path)

    if not resolved_config_path.exists():
        raise FileNotFoundError(f'Nanobot config not found: {resolved_config_path}')
    if not resolved_command_path.exists() and not resolved_command_path.is_symlink():
        raise FileNotFoundError(f'Nanobot command not found: {resolved_command_path}')

    existing_state = _load_install_state(resolved_state_path)
    if existing_state is not None:
        if not force:
            raise RuntimeError(
                f'Sheltron nanobot install state already exists: {resolved_state_path}. '
                'Run `sheltron unlink nanobot` first or pass --force.'
            )
        uninstall_nanobot(
            config_path=resolved_config_path,
            nanobot_command_path=resolved_command_path,
            state_path=resolved_state_path,
            missing_ok=True,
        )

    config_backup_path = backup_dir / 'config.json'
    disabled_config_snapshot_path = backup_dir / 'disabled-config.json'
    command_backup_path = backup_dir / 'nanobot.command'
    backup_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(resolved_config_path, config_backup_path)

    command_kind: str
    backup_symlink_target: str | None = None
    restored_real_command_path: Path
    original_mode: int | None = None
    if resolved_command_path.is_symlink():
        command_kind = 'symlink'
        raw_target = os.readlink(resolved_command_path)
        backup_symlink_target = raw_target
        restored_real_command_path = (resolved_command_path.parent / raw_target).resolve(strict=False)
        original_mode = _stat_mode(restored_real_command_path)
    else:
        command_kind = 'file'
        shutil.copy2(resolved_command_path, command_backup_path)
        restored_real_command_path = command_backup_path
        original_mode = _stat_mode(resolved_command_path)

    nanobot_site_packages = _derive_nanobot_site_packages(restored_real_command_path)
    sheltron_command_path = _discover_sheltron_command_path()
    sheltron_bin_dir = sheltron_command_path.parent

    state = NanobotInstallState(
        profile=profile,
        enabled=False,
        config_path=str(resolved_config_path),
        config_backup_path=str(config_backup_path),
        disabled_config_snapshot_path=str(disabled_config_snapshot_path),
        nanobot_command_path=str(resolved_command_path),
        nanobot_command_kind=command_kind,
        nanobot_command_backup_path=str(command_backup_path) if command_kind == 'file' else None,
        nanobot_command_backup_symlink_target=backup_symlink_target,
        real_nanobot_command_path=str(restored_real_command_path),
        real_nanobot_command_mode=original_mode,
        sheltron_bin_dir=str(sheltron_bin_dir),
        sheltron_command_path=str(sheltron_command_path),
        nanobot_site_packages=str(nanobot_site_packages),
    )
    _write_nanobot_install_state(state=state, state_path=resolved_state_path)
    return NanobotInstallResult(state=state, state_path=str(resolved_state_path))


def uninstall_nanobot(
    *,
    config_path: str | Path | None = None,
    nanobot_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
    missing_ok: bool = True,
) -> NanobotUninstallResult:
    resolved_state_path = Path(state_path or default_nanobot_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        if missing_ok:
            return NanobotUninstallResult(
                restored_command_path=str(Path(nanobot_command_path or '').expanduser()) if nanobot_command_path else '',
                restored_config_path=str(Path(config_path or '').expanduser()) if config_path else '',
                state_path=str(resolved_state_path),
                already_uninstalled=True,
            )
        raise FileNotFoundError(f'Sheltron nanobot install state not found: {resolved_state_path}')

    resolved_config_path = Path(config_path or state.config_path).expanduser().resolve(strict=False)
    resolved_command_path = _normalize_command_path(nanobot_command_path or state.nanobot_command_path)
    _restore_original_nanobot_surface(
        state=state,
        config_path=resolved_config_path,
        command_path=resolved_command_path,
        source_config_path=Path(state.config_backup_path),
    )

    _cleanup_install_artifacts(state, resolved_state_path)
    return NanobotUninstallResult(
        restored_command_path=str(resolved_command_path),
        restored_config_path=str(resolved_config_path),
        state_path=str(resolved_state_path),
    )


def disable_nanobot(
    *,
    config_path: str | Path | None = None,
    nanobot_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> NanobotDisableResult:
    resolved_state_path = Path(state_path or default_nanobot_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        raise FileNotFoundError(f'Sheltron nanobot install state not found: {resolved_state_path}')

    resolved_config_path = Path(config_path or state.config_path).expanduser().resolve(strict=False)
    resolved_command_path = _normalize_command_path(nanobot_command_path or state.nanobot_command_path)
    disabled_snapshot_path = _nanobot_disabled_snapshot_path(state)
    source_config_path = disabled_snapshot_path if disabled_snapshot_path.exists() else Path(state.config_backup_path)

    _restore_original_nanobot_surface(
        state=state,
        config_path=resolved_config_path,
        command_path=resolved_command_path,
        source_config_path=source_config_path,
    )
    if not disabled_snapshot_path.exists() and resolved_config_path.exists():
        disabled_snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(resolved_config_path, disabled_snapshot_path)
    state.enabled = False
    _write_nanobot_install_state(state=state, state_path=resolved_state_path)
    return NanobotDisableResult(state=state, state_path=str(resolved_state_path))


def enable_nanobot(
    *,
    config_path: str | Path | None = None,
    nanobot_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> NanobotEnableResult:
    resolved_state_path = Path(state_path or default_nanobot_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        raise FileNotFoundError(f'Sheltron nanobot install state not found: {resolved_state_path}')
    sheltron_command_path = _discover_sheltron_command_path()
    state.sheltron_command_path = str(sheltron_command_path)
    state.sheltron_bin_dir = str(sheltron_command_path.parent)

    resolved_config_path = Path(config_path or state.config_path).expanduser().resolve(strict=False)
    resolved_command_path = _normalize_command_path(nanobot_command_path or state.nanobot_command_path)
    disabled_snapshot_path = _nanobot_disabled_snapshot_path(state)
    if resolved_config_path.exists():
        disabled_snapshot_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(resolved_config_path, disabled_snapshot_path)
    _activate_nanobot_management(
        state=state,
        config_path=resolved_config_path,
        command_path=resolved_command_path,
    )
    state.enabled = True
    _write_nanobot_install_state(state=state, state_path=resolved_state_path)
    return NanobotEnableResult(state=state, state_path=str(resolved_state_path))


def discover_nanobot_targets() -> tuple[NanobotInstallationTarget, ...]:
    return tuple(_describe_nanobot_target(candidate) for candidate in _path_command_candidates('nanobot'))


def doctor_nanobot(
    *,
    config_path: str | Path | None = None,
    nanobot_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> NanobotDoctorReport:
    checks: list[DoctorCheck] = []
    resolved_state_path = Path(state_path or default_nanobot_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    state_paths_match = False
    config_backup_ok = False
    sheltron_bin_dir_ok = False
    site_packages_ok = False
    real_command_ok = False
    sheltron_command_exists = False
    managed_shim_active = False
    managed_install_proof_ok = False
    restrict_to_workspace_ok = False
    exec_disabled_ok = False
    sheltron_mcp_configured = False
    exclusive_mcp_gateway_ok = False
    mcp_command_pinned_ok = False

    try:
        resolved_command_path = _resolve_nanobot_runtime_command_path(
            raw_path=nanobot_command_path,
            state=state,
        )
    except FileNotFoundError:
        resolved_command_path = None
    if resolved_command_path is None:
        checks.append(DoctorCheck(name='nanobot_command', status=DoctorStatus.FAIL, detail='`nanobot` command not found on PATH.'))
    else:
        checks.append(
            DoctorCheck(
                name='nanobot_command',
                status=DoctorStatus.OK,
                detail=f'Found nanobot command at {resolved_command_path}',
            )
        )

    resolved_config_path = Path(config_path or (state.config_path if state else default_nanobot_config_path())).expanduser().resolve(strict=False)
    if not resolved_config_path.exists():
        checks.append(DoctorCheck(name='config_path', status=DoctorStatus.FAIL, detail=f'Nanobot config not found: {resolved_config_path}'))
        config_data: dict[str, Any] | None = None
    else:
        config_data = _load_json_file(resolved_config_path)
        checks.append(DoctorCheck(name='config_path', status=DoctorStatus.OK, detail=f'Found nanobot config at {resolved_config_path}'))

    if state is None:
        checks.append(
            DoctorCheck(
                name='install_state',
                status=DoctorStatus.WARN,
                detail=f'No Sheltron nanobot install state found at {resolved_state_path}',
            )
        )
    else:
        checks.append(
            DoctorCheck(
                name='install_state',
                status=DoctorStatus.OK,
                detail=f'Found install state at {resolved_state_path}',
            )
        )

    if resolved_command_path is not None:
        managed_shim_active = _is_managed_nanobot_shim(resolved_command_path)

    if state is not None:
        normalized_state_config_path = Path(state.config_path).expanduser().resolve(strict=False)
        normalized_state_command_path = _normalize_command_path(state.nanobot_command_path)
        backup_config_path = Path(state.config_backup_path)
        config_backup_ok = backup_config_path.exists()
        state_paths_match = (
            normalized_state_config_path == resolved_config_path
            and resolved_command_path is not None
            and normalized_state_command_path == resolved_command_path
        )
        checks.append(
            DoctorCheck(
                name='config_backup',
                status=DoctorStatus.OK if config_backup_ok else DoctorStatus.FAIL,
                detail=(
                    f'Config backup found at {backup_config_path}'
                    if config_backup_ok
                    else f'Config backup missing at {backup_config_path}'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='install_state_paths_match',
                status=DoctorStatus.OK if state_paths_match else DoctorStatus.WARN,
                detail=(
                    'Install state matches the active nanobot command and config paths.'
                    if state_paths_match
                    else (
                        'Install state paths do not match the active nanobot command/config: '
                        f'state_command={normalized_state_command_path} active_command={resolved_command_path} '
                        f'state_config={normalized_state_config_path} active_config={resolved_config_path}'
                    )
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='sheltron_bin_dir',
                status=DoctorStatus.OK if Path(state.sheltron_bin_dir).exists() else DoctorStatus.FAIL,
                detail=f'Sheltron bin dir: {state.sheltron_bin_dir}',
            )
        )
        sheltron_bin_dir_ok = Path(state.sheltron_bin_dir).exists()
        if state.sheltron_command_path:
            sheltron_command = Path(state.sheltron_command_path)
            sheltron_command_exists = sheltron_command.exists()
            checks.append(
                DoctorCheck(
                    name='sheltron_command',
                    status=DoctorStatus.OK if sheltron_command_exists else DoctorStatus.FAIL,
                    detail=f'Sheltron command: {sheltron_command}',
                )
            )
        else:
            checks.append(
                DoctorCheck(
                    name='sheltron_command',
                    status=DoctorStatus.WARN,
                    detail='Managed install state predates explicit Sheltron command pinning.',
                )
            )
        site_packages = Path(state.nanobot_site_packages)
        site_packages_ok = (site_packages / 'nanobot').exists()
        checks.append(
            DoctorCheck(
                name='nanobot_site_packages',
                status=DoctorStatus.OK if site_packages_ok else DoctorStatus.FAIL,
                detail=f'Nanobot site-packages: {site_packages}',
            )
        )
        real_command = Path(state.real_nanobot_command_path)
        real_command_ok = real_command.exists()
        checks.append(
            DoctorCheck(
                name='real_nanobot_command',
                status=DoctorStatus.OK if real_command_ok else DoctorStatus.FAIL,
                detail=f'Real nanobot command target: {real_command}',
            )
        )
        checks.append(
            DoctorCheck(
                name='activation_state',
                status=DoctorStatus.OK,
                detail='Persistent always-on activation is enabled.' if state.enabled else 'Persistent always-on activation is off.',
            )
        )
        managed_install_proof_ok = (
            config_backup_ok
            and state_paths_match
            and sheltron_bin_dir_ok
            and site_packages_ok
            and real_command_ok
            and state.nanobot_command_kind in {'file', 'symlink'}
        )

    if config_data is not None:
        tools = _ensure_dict(config_data, 'tools')
        mcp_servers = _ensure_dict(tools, 'mcpServers')
        restrict_to_workspace = tools.get('restrictToWorkspace')
        exec_enabled = _ensure_dict(tools, 'exec').get('enable')
        mcp_entry = mcp_servers.get(SHELTRON_NANOBOT_SERVER_NAME)
        parallel_mcp_servers = tuple(
            sorted(
                name
                for name in mcp_servers
                if isinstance(name, str) and name != SHELTRON_NANOBOT_SERVER_NAME
            )
        )
        restrict_to_workspace_ok = restrict_to_workspace is True
        exec_disabled_ok = exec_enabled is False
        sheltron_mcp_configured = isinstance(mcp_entry, dict)
        exclusive_mcp_gateway_ok = sheltron_mcp_configured and not parallel_mcp_servers
        expecting_persistent_surface = state.enabled if state is not None else False
        checks.append(
            DoctorCheck(
                name='restrict_to_workspace',
                status=(
                    DoctorStatus.OK
                    if (restrict_to_workspace_ok if expecting_persistent_surface else True)
                    else DoctorStatus.WARN
                ),
                detail=(
                    f'tools.restrictToWorkspace={restrict_to_workspace!r}'
                    if expecting_persistent_surface
                    else f'tools.restrictToWorkspace={restrict_to_workspace!r} (not required while always-on is off)'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='exec_disabled',
                status=(
                    DoctorStatus.OK
                    if (exec_disabled_ok if expecting_persistent_surface else True)
                    else DoctorStatus.WARN
                ),
                detail=(
                    f'tools.exec.enable={exec_enabled!r}'
                    if expecting_persistent_surface
                    else f'tools.exec.enable={exec_enabled!r} (not required while always-on is off)'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='sheltron_mcp_config',
                status=(
                    DoctorStatus.OK
                    if (
                        sheltron_mcp_configured
                        if expecting_persistent_surface
                        else not sheltron_mcp_configured
                    )
                    else DoctorStatus.FAIL
                ),
                detail=(
                    'Sheltron MCP server is configured in nanobot config.'
                    if expecting_persistent_surface and sheltron_mcp_configured
                    else 'Sheltron MCP server is missing from nanobot config.'
                    if expecting_persistent_surface
                    else 'Nanobot config is native and does not persist Sheltron MCP.'
                    if not sheltron_mcp_configured
                    else 'Sheltron MCP server remains in nanobot config while always-on is off.'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='parallel_mcp_servers',
                status=(
                    DoctorStatus.OK
                    if (
                        not parallel_mcp_servers
                        if expecting_persistent_surface
                        else True
                    )
                    else DoctorStatus.WARN
                ),
                detail=(
                    'Sheltron is the only active MCP server in nanobot config.'
                    if expecting_persistent_surface and not parallel_mcp_servers
                    else 'Parallel MCP servers remain active outside the Sheltron gateway: '
                    + ', '.join(parallel_mcp_servers)
                    if expecting_persistent_surface
                    else 'Parallel MCP servers are not relevant while always-on is off.'
                ),
            )
        )
        if sheltron_mcp_configured:
            command = mcp_entry.get('command')
            args = mcp_entry.get('args')
            expected_command = None
            if state is not None and state.sheltron_command_path:
                expected_command = str(_effective_sheltron_command_path(state))
            command_ok = (
                isinstance(command, str)
                and isinstance(args, list)
                and args[:2] == ['mcp', 'serve']
                and (
                    command == expected_command
                    if expected_command is not None
                    else bool(command)
                )
            )
            mcp_command_pinned_ok = command_ok if expected_command is not None else sheltron_mcp_configured
            checks.append(
                DoctorCheck(
                    name='sheltron_mcp_command',
                    status=DoctorStatus.OK if command_ok else DoctorStatus.WARN,
                    detail=(
                        f'command={command!r} args={args!r}'
                        if expected_command is None
                        else f'command={command!r} expected={expected_command!r} args={args!r}'
                    ),
                )
            )
        wildcard_channels = _find_wildcard_allow_from_paths(config_data)
        if wildcard_channels:
            checks.append(
                DoctorCheck(
                    name='allow_from_scope',
                    status=DoctorStatus.WARN,
                    detail='Broad allowFrom=* detected at ' + ', '.join(wildcard_channels),
                )
            )
        else:
            checks.append(
                DoctorCheck(
                    name='allow_from_scope',
                    status=DoctorStatus.OK,
                    detail='No broad allowFrom=* entries detected.',
                )
            )

    if state is not None and state.nanobot_command_kind not in {'file', 'symlink'}:
        checks.append(
            DoctorCheck(
                name='install_state_kind',
                status=DoctorStatus.FAIL,
                detail=f'Unsupported nanobot command kind in state: {state.nanobot_command_kind}',
            )
        )

    managed_contract_issues: list[str] = []
    if state is None:
        pass
    elif not managed_install_proof_ok:
        if not state_paths_match:
            managed_contract_issues.append(
                'install state paths do not match the active nanobot command and config'
            )
        if not config_backup_ok:
            managed_contract_issues.append('managed config backup is missing')
        if not sheltron_bin_dir_ok:
            managed_contract_issues.append('managed Sheltron bin dir is missing')
        if not state.sheltron_command_path:
            managed_contract_issues.append('managed install state predates explicit Sheltron command pinning')
        elif not sheltron_command_exists:
            managed_contract_issues.append('pinned Sheltron command is missing')
        if not site_packages_ok:
            managed_contract_issues.append('managed nanobot site-packages path is missing the nanobot install')
        if not real_command_ok:
            managed_contract_issues.append('managed real nanobot command target is missing')
    elif state.enabled:
        if not managed_shim_active:
            managed_contract_issues.append(
                'always-on activation is enabled but the active nanobot command is not the Sheltron-managed shim'
            )
        if not sheltron_mcp_configured:
            managed_contract_issues.append('always-on config is missing the Sheltron MCP server')
        if sheltron_mcp_configured and not mcp_command_pinned_ok:
            managed_contract_issues.append('always-on config does not pin the expected Sheltron MCP command')
        if not restrict_to_workspace_ok:
            managed_contract_issues.append('always-on config no longer forces restrictToWorkspace=true')
        if not exec_disabled_ok:
            managed_contract_issues.append('always-on config no longer disables built-in exec')
        if not exclusive_mcp_gateway_ok:
            managed_contract_issues.append('always-on config still exposes parallel MCP servers outside Sheltron')
    else:
        if managed_shim_active:
            managed_contract_issues.append(
                'always-on activation is off but the active nanobot command is still the Sheltron-managed shim'
            )
        if sheltron_mcp_configured:
            managed_contract_issues.append(
                'always-on activation is off but nanobot config still persists Sheltron MCP wiring'
            )

    checks.append(
        DoctorCheck(
            name='managed_shim',
            status=(
                DoctorStatus.OK
                if (
                    managed_shim_active
                    if (state.enabled if state is not None else False)
                    else not managed_shim_active
                )
                else DoctorStatus.WARN
            ),
            detail=(
                f'Sheltron-managed nanobot shim is active at {resolved_command_path}'
                if managed_shim_active
                else 'The active `nanobot` command is native, not the Sheltron-managed shim.'
            ),
        )
    )

    checks.append(
        DoctorCheck(
            name='managed_contract',
            status=DoctorStatus.FAIL if managed_contract_issues else DoctorStatus.OK,
            detail=(
                'Managed nanobot contract is consistent.'
                if not managed_contract_issues
                else '; '.join(managed_contract_issues)
            ),
        )
    )

    return NanobotDoctorReport(
        protection_state=_infer_nanobot_protection_state(
            state=state,
            managed_install_proof_ok=managed_install_proof_ok,
            managed_contract_ok=not managed_contract_issues,
        ),
        checks=tuple(checks),
    )


def _require_supported_profile(profile: str) -> None:
    if profile not in SUPPORTED_NANOBOT_PROFILES:
        raise ValueError(
            f'Unsupported nanobot profile: {profile}. Supported profiles: {", ".join(SUPPORTED_NANOBOT_PROFILES)}'
        )


def _select_nanobot_install_command_path(raw_path: str | Path | None) -> Path:
    if raw_path is not None:
        return _normalize_command_path(raw_path)
    targets = _preferred_nanobot_targets(discover_nanobot_targets())
    if not targets:
        raise FileNotFoundError(
            '`nanobot` command not found on PATH. Install nanobot, fix PATH, or rerun with an explicit command path, for example:\n'
            '  sheltron link nanobot --nanobot-command /path/to/nanobot'
        )
    if len(targets) > 1:
        choices = '\n'.join(
            f'  sheltron link nanobot --nanobot-command {shlex.quote(target.command_path)}'
            for target in targets
        )
        details = '\n'.join(f'- {target.command_path} ({target.install_kind})' for target in targets)
        raise RuntimeError(
            'Multiple nanobot installations were found. Choose one explicit target and rerun one of:\n'
            f'{choices}\n'
            '\n'
            'Detected targets:\n'
            f'{details}'
        )
    return Path(targets[0].command_path)


def _resolve_nanobot_runtime_command_path(*, raw_path: str | Path | None, state: NanobotInstallState | None) -> Path:
    if raw_path is not None:
        return _normalize_command_path(raw_path)
    if state is not None:
        return _normalize_command_path(state.nanobot_command_path)
    return _select_nanobot_install_command_path(None)


def _path_command_candidates(name: str) -> tuple[Path, ...]:
    candidates: list[Path] = []
    seen: set[Path] = set()
    path_value = os.environ.get('PATH', '')
    for raw_dir in path_value.split(os.pathsep):
        if not raw_dir:
            continue
        candidate = _normalize_command_path(Path(raw_dir) / name)
        if candidate in seen:
            continue
        if candidate.exists():
            seen.add(candidate)
            candidates.append(candidate)
    return tuple(candidates)


def _active_repo_venv_root() -> Path | None:
    current_env_root = _normalize_command_path(sys.executable).parent.parent
    repo_venv_root = _normalize_command_path(Path.cwd() / '.venv')
    if current_env_root == repo_venv_root:
        return repo_venv_root
    return None


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def _normalize_command_path(raw_path: str | Path) -> Path:
    expanded = Path(raw_path).expanduser()
    return Path(os.path.abspath(os.fspath(expanded)))


def _install_kind_for_command_path(command_path: Path, *, environment_root: Path) -> str:
    path_text = str(environment_root)
    if '/.local/share/uv/tools/' in path_text or '/uv/tools/' in path_text:
        return 'uv-tool'
    if (environment_root / 'pyvenv.cfg').exists() or environment_root.name == '.venv':
        return 'pip-venv'
    return 'unknown'


def _describe_nanobot_target(command_path: Path) -> NanobotInstallationTarget:
    real_command_path = command_path.resolve(strict=False)
    environment_root = real_command_path.parent.parent
    install_kind = 'managed-shim' if _is_managed_nanobot_shim(command_path) else _install_kind_for_command_path(
        command_path,
        environment_root=environment_root,
    )
    return NanobotInstallationTarget(
        command_path=str(command_path),
        real_command_path=str(real_command_path),
        install_kind=install_kind,
        environment_root=str(environment_root),
    )


def _preferred_nanobot_targets(
    targets: tuple[NanobotInstallationTarget, ...],
) -> tuple[NanobotInstallationTarget, ...]:
    repo_venv_root = _active_repo_venv_root()
    if repo_venv_root is None or len(targets) <= 1:
        return targets
    filtered = tuple(target for target in targets if not _is_within(Path(target.command_path), repo_venv_root))
    return filtered or targets


def _load_json_file(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding='utf-8'))


def _write_json_file(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')


def _workspace_from_config(config_data: dict[str, Any]) -> str:
    agents = _ensure_dict(config_data, 'agents')
    defaults = _ensure_dict(agents, 'defaults')
    workspace = defaults.get('workspace')
    if isinstance(workspace, str) and workspace.strip():
        return workspace
    return '~/.nanobot/workspace'


def _discover_sheltron_bin_dir() -> Path:
    return _discover_sheltron_command_path().parent


def _discover_sheltron_command_path() -> Path:
    return resolve_installed_sheltron_command().command_path


def _derive_nanobot_site_packages(real_nanobot_command: Path) -> Path:
    interpreter = _derive_python_from_command(real_nanobot_command)
    candidates = _nanobot_site_package_candidates(
        env_roots=(
            real_nanobot_command.parent.parent,
            interpreter.parent.parent,
            interpreter.resolve(strict=False).parent.parent,
        )
    )
    for candidate in candidates:
        if _contains_nanobot_install(candidate):
            return candidate

    discovered = _query_nanobot_site_packages_from_interpreter(interpreter)
    if discovered is not None:
        return discovered

    roots_text = ', '.join(str(root) for root in (real_nanobot_command.parent.parent, interpreter.parent.parent))
    raise FileNotFoundError(f'Could not locate nanobot site-packages under any supported environment layout: {roots_text}')


def _derive_python_from_command(real_nanobot_command: Path) -> Path:
    try:
        first_line = real_nanobot_command.read_text(encoding='utf-8').splitlines()[0]
    except (IndexError, OSError, UnicodeDecodeError) as exc:  # pragma: no cover - command inspection failure
        raise RuntimeError(f'Failed to inspect nanobot command at {real_nanobot_command}: {exc}') from exc
    if first_line.startswith('#!'):
        interpreter = Path(first_line[2:].strip()).expanduser()
        if interpreter.exists():
            return interpreter
    raise RuntimeError(f'Could not derive the nanobot Python interpreter from {real_nanobot_command}')


def _query_nanobot_site_packages_from_interpreter(interpreter: Path) -> Path | None:
    script = (
        'import importlib.metadata as m\n'
        'names = ("nanobot-ai", "nanobot_ai", "nanobot")\n'
        'for name in names:\n'
        '    try:\n'
        '        dist = m.distribution(name)\n'
        '    except m.PackageNotFoundError:\n'
        '        continue\n'
        '    print(dist.locate_file(""))\n'
        '    raise SystemExit(0)\n'
        'raise SystemExit(1)\n'
    )
    try:
        completed = subprocess.run(
            [os.fspath(interpreter), '-c', script],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return None
    if completed.returncode != 0:
        return None
    discovered = Path(completed.stdout.strip()).expanduser()
    if not discovered.exists():
        return None
    return discovered.resolve(strict=False)


def _nanobot_site_package_candidates(*, env_roots: tuple[Path, ...]) -> tuple[Path, ...]:
    candidates: list[Path] = []
    seen: set[Path] = set()
    for env_root in env_roots:
        for pattern in (
            'lib/python*/site-packages',
            'lib/python*/dist-packages',
            'lib64/python*/site-packages',
            'lib64/python*/dist-packages',
            'Lib/site-packages',
        ):
            for candidate in sorted(env_root.glob(pattern)):
                resolved = candidate.resolve(strict=False)
                if resolved in seen:
                    continue
                seen.add(resolved)
                candidates.append(resolved)
    return tuple(candidates)


def _contains_nanobot_install(site_packages: Path) -> bool:
    if (site_packages / 'nanobot').exists():
        return True
    for pattern in ('nanobot*.dist-info', 'nanobot*.egg-info', 'nanobot_ai*.dist-info', 'nanobot_ai*.egg-info'):
        if any(site_packages.glob(pattern)):
            return True
    return False


def _patch_config_data(
    config_data: dict[str, Any],
    *,
    workspace: str,
    sheltron_bin_dir: Path,
    sheltron_command_path: Path,
) -> dict[str, Any]:
    patched = json.loads(json.dumps(config_data))
    tools = _ensure_dict(patched, 'tools')
    exec_config = _ensure_dict(tools, 'exec')

    tools['restrictToWorkspace'] = True
    exec_config['enable'] = False

    server_data = build_sheltron_mcp_server_data(
        workspace,
        sheltron_command_path=sheltron_command_path,
    )
    env = dict(server_data.get('env') or {})
    current_path = os.environ.get('PATH', '')
    env['PATH'] = f'{sheltron_bin_dir}:{current_path}' if current_path else str(sheltron_bin_dir)
    server_data['env'] = env
    tools['mcpServers'] = {
        SHELTRON_NANOBOT_SERVER_NAME: server_data,
    }
    return patched


def _ensure_dict(parent: dict[str, Any], key: str) -> dict[str, Any]:
    current = parent.get(key)
    if not isinstance(current, dict):
        current = {}
        parent[key] = current
    return current


def _install_managed_shim(
    *,
    command_path: Path,
    real_nanobot_command: Path,
    sheltron_bin_dir: Path,
    sheltron_command_path: Path,
    nanobot_site_packages: Path,
) -> None:
    if command_path.exists() or command_path.is_symlink():
        command_path.unlink()
    command_path.parent.mkdir(parents=True, exist_ok=True)
    command_path.write_text(
        _render_managed_shim(
            real_nanobot_command=real_nanobot_command,
            sheltron_bin_dir=sheltron_bin_dir,
            sheltron_command_path=sheltron_command_path,
            nanobot_site_packages=nanobot_site_packages,
        ),
        encoding='utf-8',
    )
    command_path.chmod(0o755)


def _render_managed_shim(
    *,
    real_nanobot_command: Path,
    sheltron_bin_dir: Path,
    sheltron_command_path: Path,
    nanobot_site_packages: Path,
) -> str:
    return '\n'.join(
        [
            '#!/bin/sh',
            f'# {MANAGED_NANOBOT_SHIM_MARKER}',
            f'REAL_NANOBOT={shlex.quote(str(real_nanobot_command))}',
            f'SHELTRON_BIN_DIR={shlex.quote(str(sheltron_bin_dir))}',
            f'SHELTRON_COMMAND={shlex.quote(str(sheltron_command_path))}',
            f'NANOBOT_SITE_PACKAGES={shlex.quote(str(nanobot_site_packages))}',
            '',
            'if [ "$1" = "agent" ] || [ "$1" = "gateway" ]; then',
            '  if [ -n "$PATH" ]; then',
            '    export PATH="$SHELTRON_BIN_DIR:$PATH"',
            '  else',
            '    export PATH="$SHELTRON_BIN_DIR"',
            '  fi',
            '  if [ -n "$PYTHONPATH" ]; then',
            '    export PYTHONPATH="$NANOBOT_SITE_PACKAGES:$PYTHONPATH"',
            '  else',
            '    export PYTHONPATH="$NANOBOT_SITE_PACKAGES"',
            '  fi',
            '  if [ ! -x "$SHELTRON_COMMAND" ]; then',
            '    echo "Sheltron command not found: $SHELTRON_COMMAND" >&2',
            '    exit 127',
            '  fi',
            '  exec "$SHELTRON_COMMAND" nanobot "$@"',
            'fi',
            '',
            'exec "$REAL_NANOBOT" "$@"',
            '',
        ]
    )


def _is_managed_nanobot_shim(path: Path) -> bool:
    if path.is_symlink() or not path.exists():
        return False
    try:
        return MANAGED_NANOBOT_SHIM_MARKER in path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        return False


def _load_install_state(path: Path) -> NanobotInstallState | None:
    if not path.exists():
        return None
    return NanobotInstallState.model_validate_json(path.read_text(encoding='utf-8'))


def _write_nanobot_install_state(*, state: NanobotInstallState, state_path: Path) -> None:
    state_path.parent.mkdir(parents=True, exist_ok=True)
    state_path.write_text(state.model_dump_json(indent=2), encoding='utf-8')


def _effective_sheltron_command_path(state: NanobotInstallState) -> Path:
    if state.sheltron_command_path:
        return _normalize_command_path(state.sheltron_command_path)
    return _discover_sheltron_command_path()


def _nanobot_disabled_snapshot_path(state: NanobotInstallState) -> Path:
    if state.disabled_config_snapshot_path:
        return Path(state.disabled_config_snapshot_path)
    return Path(state.config_backup_path).parent / 'disabled-config.json'


def _activate_nanobot_management(
    *,
    state: NanobotInstallState,
    config_path: Path,
    command_path: Path,
) -> None:
    config_data = _load_json_file(config_path)
    workspace = _workspace_from_config(config_data)
    patched = _patch_config_data(
        config_data,
        workspace=workspace,
        sheltron_bin_dir=Path(state.sheltron_bin_dir),
        sheltron_command_path=_effective_sheltron_command_path(state),
    )
    _write_json_file(config_path, patched)
    _install_managed_shim(
        command_path=command_path,
        real_nanobot_command=Path(state.real_nanobot_command_path),
        sheltron_bin_dir=Path(state.sheltron_bin_dir),
        sheltron_command_path=_effective_sheltron_command_path(state),
        nanobot_site_packages=Path(state.nanobot_site_packages),
    )


def _restore_original_nanobot_surface(
    *,
    state: NanobotInstallState,
    config_path: Path,
    command_path: Path,
    source_config_path: Path,
) -> None:
    if source_config_path.exists():
        config_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_config_path, config_path)

    if command_path.exists() or command_path.is_symlink():
        command_path.unlink()

    if state.nanobot_command_kind == 'symlink':
        if not state.nanobot_command_backup_symlink_target:
            raise RuntimeError('Managed nanobot state is missing the original symlink target.')
        command_path.symlink_to(state.nanobot_command_backup_symlink_target)
    else:
        if not state.nanobot_command_backup_path:
            raise RuntimeError('Managed nanobot state is missing the original command backup path.')
        backup_path = Path(state.nanobot_command_backup_path)
        if not backup_path.exists():
            raise FileNotFoundError(f'Original nanobot command backup not found: {backup_path}')
        shutil.copy2(backup_path, command_path)
        if state.real_nanobot_command_mode is not None:
            command_path.chmod(state.real_nanobot_command_mode)


def _cleanup_install_artifacts(state: NanobotInstallState, state_path: Path) -> None:
    if state_path.exists():
        state_path.unlink()

    config_backup_path = Path(state.config_backup_path)
    if config_backup_path.exists():
        config_backup_path.unlink()
    disabled_snapshot_path = _nanobot_disabled_snapshot_path(state)
    if disabled_snapshot_path.exists():
        disabled_snapshot_path.unlink()

    if state.nanobot_command_backup_path:
        backup_command_path = Path(state.nanobot_command_backup_path)
        if backup_command_path.exists():
            backup_command_path.unlink()

    for directory in (config_backup_path.parent, state_path.parent):
        try:
            directory.rmdir()
        except OSError:
            continue


def _find_wildcard_allow_from_paths(payload: Any, *, path: str = '') -> list[str]:
    matches: list[str] = []
    if isinstance(payload, dict):
        for key, value in payload.items():
            child_path = f'{path}.{key}' if path else key
            normalized_key = key.lower()
            if normalized_key in {'allowfrom', 'allow_from', 'groupallowfrom', 'group_allow_from'}:
                if isinstance(value, list) and any(isinstance(item, str) and item == '*' for item in value):
                    matches.append(child_path)
            matches.extend(_find_wildcard_allow_from_paths(value, path=child_path))
    elif isinstance(payload, list):
        for index, value in enumerate(payload):
            matches.extend(_find_wildcard_allow_from_paths(value, path=f'{path}[{index}]'))
    return matches


def _infer_nanobot_protection_state(
    *,
    state: NanobotInstallState | None,
    managed_install_proof_ok: bool,
    managed_contract_ok: bool,
) -> NanobotProtectionState:
    if state is None:
        return NanobotProtectionState.NOT_INSTALLED
    if not managed_install_proof_ok or not managed_contract_ok:
        return NanobotProtectionState.BROKEN
    if state.enabled:
        return NanobotProtectionState.ALWAYS_ON
    return NanobotProtectionState.READY


def _stat_mode(path: Path) -> int | None:
    try:
        return stat.S_IMODE(path.stat().st_mode)
    except FileNotFoundError:
        return None
