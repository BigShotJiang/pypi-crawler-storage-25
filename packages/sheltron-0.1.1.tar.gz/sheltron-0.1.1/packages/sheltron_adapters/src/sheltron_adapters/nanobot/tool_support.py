from __future__ import annotations

import json
from collections.abc import Mapping

from nanobot.config.schema import WebSearchConfig

from sheltron_runtime import SheltronGatewayAdapter


def serialize_blocked_result(adapter: SheltronGatewayAdapter, result: object) -> str:
    return json.dumps(adapter.serialize_blocked_result(result), sort_keys=True)


def approval_ticket_schema(description: str) -> dict[str, object]:
    return {
        'type': ['string', 'null'],
        'description': description,
    }


def schema_with_approval_ticket(
    schema: Mapping[str, object],
    *,
    description: str,
) -> dict[str, object]:
    normalized = dict(schema)
    raw_properties = normalized.get('properties')
    properties = dict(raw_properties) if isinstance(raw_properties, Mapping) else {}
    properties['approval_ticket_id'] = approval_ticket_schema(description)
    normalized['properties'] = properties
    return normalized


def resolve_search_provider_name(config: WebSearchConfig) -> str:
    provider = config.provider
    if provider.strip():
        return provider.strip().lower()
    return 'brave'


def resolve_search_default_count(config: WebSearchConfig) -> int:
    return normalize_search_count(config.max_results)


def normalize_search_count(raw_count: int) -> int:
    return min(max(int(raw_count), 1), 10)
