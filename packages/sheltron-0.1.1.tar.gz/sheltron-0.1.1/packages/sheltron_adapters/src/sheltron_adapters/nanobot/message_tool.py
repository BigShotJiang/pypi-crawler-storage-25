from __future__ import annotations

import os
from pathlib import Path
from typing import Awaitable, Callable

from sheltron_core import (
    Provenance,
    TrustLevel,
)
from sheltron_adapters.nanobot.gateway_context import get_workspace_gateway_adapter
from sheltron_adapters.nanobot.runtime_session import standalone_runtime_session
from sheltron_adapters.nanobot.tool_support import schema_with_approval_ticket, serialize_blocked_result
from sheltron_runtime import SendMessageSpec
from nanobot.agent.tools.message import MessageTool
from nanobot.agent.tools.registry import ToolRegistry
from nanobot.bus.events import OutboundMessage

from sheltron_adapters.nanobot.defense_context import augment_provenance

_SECRET_ENV_SUFFIXES = ('_API_KEY', '_TOKEN', '_SECRET', '_PASSWORD')


def discover_env_secret_values() -> tuple[str, ...]:
    return tuple(
        sorted(
            {
                value
                for key, value in os.environ.items()
                if value and key.endswith(_SECRET_ENV_SUFFIXES)
            },
            key=len,
            reverse=True,
        )
    )


class SheltronMessageTool(MessageTool):
    def __init__(
        self,
        *,
        workspace: Path,
        send_callback: Callable[[OutboundMessage], Awaitable[None]] | None,
        secrets: tuple[str, ...] | None = None,
        max_content_chars: int = 4_000,
        allowed_target_locators: frozenset[str] | None = None,
    ) -> None:
        super().__init__(send_callback=send_callback)
        self._adapter = get_workspace_gateway_adapter(
            workspace,
            system_name='nanobot',
            message_secret_values=secrets or discover_env_secret_values(),
            message_max_content_chars=max_content_chars,
            allowed_target_locators=allowed_target_locators,
        )

    @property
    def description(self) -> str:
        return (
            "Send a message subject to Sheltron policy. Messages to the current user are allowed by default; "
            "attachments, secret-like content, unscoped targets, or non-default targets require approval."
        )

    @property
    def parameters(self) -> dict[str, object]:
        return schema_with_approval_ticket(
            super().parameters,
            description='Optional approval ticket id used to resume an approval-required send.',
        )

    async def execute(
        self,
        content: str,
        channel: str | None = None,
        chat_id: str | None = None,
        message_id: str | None = None,
        media: list[str] | None = None,
        approval_ticket_id: str | None = None,
        **kwargs: object,
    ) -> str:
        del kwargs
        with standalone_runtime_session():
            channel = channel or self._default_channel
            chat_id = chat_id or self._default_chat_id
            message_id = message_id or self._default_message_id

            if not channel or not chat_id:
                return 'Error: No target channel/chat specified'
            if not self._send_callback:
                return 'Error: Message sending not configured'

            result = self._adapter.before_message_send(
                SendMessageSpec(
                    channel=channel,
                    recipient=chat_id,
                    content=content,
                    reply_to=message_id,
                    media=tuple(media or ()),
                    default_channel=self._default_channel or None,
                    default_recipient=self._default_chat_id or None,
                ),
                provenance=self._build_provenance(channel, chat_id),
                approval_ticket_id=approval_ticket_id,
            )
            if not result.executed:
                result = self._adapter.after_action(result)
                return serialize_blocked_result(self._adapter, result)

            output = result.value
            if output is None:
                raise RuntimeError('Message guard completed without a message output.')
            msg = OutboundMessage(
                channel=output.channel,
                chat_id=output.recipient,
                content=output.content,
                media=list(output.media),
                metadata={'message_id': output.reply_to},
            )
            try:
                await self._send_callback(msg)
                if output.channel == self._default_channel and output.recipient == self._default_chat_id:
                    self._sent_in_turn = True
                result = self._adapter.after_action(
                    result,
                    result_summary=f'delivery=sent media_count={len(output.media)}',
                    redactions=('message_content',) if output.redacted else (),
                )
                if not result.executed:
                    return serialize_blocked_result(self._adapter, result)
                output = result.value or output
                media_info = f' with {len(output.media)} attachments' if output.media else ''
                redaction_info = ' (content redacted)' if output.redacted else ''
                self._adapter.after_message_send(
                    output=output,
                    provenance=result.request.provenance,
                    delivery='sent',
                )
                return f'Message sent to {output.channel}:{output.recipient}{media_info}{redaction_info}'
            except Exception as exc:
                result = self._adapter.after_action(
                    result,
                    result_summary=f'delivery_error={str(exc)}',
                    redactions=('message_content',) if output.redacted else (),
                )
                if result.executed and result.value is not None:
                    output = result.value
                self._adapter.after_message_send(
                    output=output,
                    provenance=result.request.provenance,
                    delivery='error',
                    metadata={'error': str(exc)},
                )
                return f'Error sending message: {str(exc)}'

    @staticmethod
    def _build_provenance(channel: str, recipient: str) -> Provenance:
        return augment_provenance(
            Provenance(
                session_id=f'nanobot:{channel}:{recipient}',
                channel=channel,
                actor_id='nanobot',
                source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
                trigger='nanobot message tool call',
            )
        )

def replace_message_tool(
    registry: ToolRegistry,
    *,
    workspace: Path,
    send_callback: Callable[[OutboundMessage], Awaitable[None]] | None,
) -> None:
    registry.register(
        SheltronMessageTool(
            workspace=workspace,
            send_callback=send_callback,
        )
    )
