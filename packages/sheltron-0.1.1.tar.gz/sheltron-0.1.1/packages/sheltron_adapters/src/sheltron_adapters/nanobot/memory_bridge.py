from __future__ import annotations

from pathlib import Path
from typing import Literal

from sheltron_core import (
    Decision,
    JsonlCandidateMemoryStore,
    Provenance,
    TrustLevel,
)
from sheltron_adapters.nanobot.approval_bridge import prompt_inline_decision
from sheltron_adapters.nanobot.defense_context import augment_provenance
from sheltron_adapters.nanobot.gateway_context import get_workspace_gateway_adapter
from sheltron_runtime import (
    CandidateMemoryOutput,
    CandidateMemorySpec,
    GuardResult,
    default_workspace_candidate_memory_store_path as runtime_default_candidate_memory_store_path,
)


def default_workspace_candidate_memory_store_path(workspace: Path) -> Path:
    return runtime_default_candidate_memory_store_path(workspace)


MemoryCandidateStatus = Literal['committed', 'rejected', 'pending']


def save_history_candidate(
    *,
    workspace: Path,
    content: str,
    target_path: Path | None = None,
) -> str | None:
    candidate_id, _status = save_history_candidate_with_status(
        workspace=workspace,
        content=content,
        target_path=target_path,
    )
    return candidate_id


def save_history_candidate_with_status(
    *,
    workspace: Path,
    content: str,
    target_path: Path | None = None,
) -> tuple[str | None, MemoryCandidateStatus]:
    resolved_target_path = target_path or workspace / 'memory' / 'HISTORY.md'
    result = _adapter(workspace).before_memory_write(
        CandidateMemorySpec(
            key='nanobot:history',
            content=content,
            summary=_summarize(content),
            mode='append',
            target_path=resolved_target_path,
        ),
        provenance=_build_provenance('nanobot history consolidation'),
    )
    try:
        candidate_id, status = _finalize_candidate(
            workspace=workspace,
            result=result,
            action_label='Commit this history memory update?',
        )
    except RuntimeError:
        result = _audit_memory_result(
            workspace=workspace,
            result=result,
            outcome='memory_candidate_denied',
            result_summary='candidate_status=not_created',
        )
        raise
    result = _audit_memory_result(
        workspace=workspace,
        result=result,
        outcome=f'memory_candidate_{status}',
        result_summary=f'candidate_id={candidate_id} candidate_status={status}',
    )
    return candidate_id, status


def save_long_term_candidate(*, workspace: Path, content: str) -> str | None:
    result = _adapter(workspace).before_memory_write(
        CandidateMemorySpec(
            key='nanobot:long_term',
            content=content,
            summary='Nanobot long-term memory update',
            mode='replace',
            target_path=workspace / 'memory' / 'MEMORY.md',
        ),
        provenance=_build_provenance('nanobot long-term memory consolidation'),
    )
    try:
        candidate_id, status = _finalize_candidate(
            workspace=workspace,
            result=result,
            action_label='Commit this long-term memory update?',
        )
    except RuntimeError:
        result = _audit_memory_result(
            workspace=workspace,
            result=result,
            outcome='memory_candidate_denied',
            result_summary='candidate_status=not_created',
        )
        raise
    result = _audit_memory_result(
        workspace=workspace,
        result=result,
        outcome=f'memory_candidate_{status}',
        result_summary=f'candidate_id={candidate_id} candidate_status={status}',
    )
    return candidate_id


def _finalize_candidate(
    *,
    workspace: Path,
    result: GuardResult[CandidateMemoryOutput],
    action_label: str,
) -> tuple[str, str]:
    if not result.executed or result.value is None:
        reason = result.policy_result.reasons[0]
        raise RuntimeError(f'Sheltron blocked memory candidate creation: {reason.code}: {reason.message}')

    candidate_id = result.value.candidate_id
    store = JsonlCandidateMemoryStore(default_workspace_candidate_memory_store_path(workspace))
    if result.policy_result.decision is Decision.ALLOW:
        store.commit(
            candidate_id,
            reviewer_id='system',
            note='auto-committed by Sheltron memory policy',
        )
        return candidate_id, 'committed'

    approved = prompt_inline_decision(
        header='Sheltron memory review required.',
        lines=tuple(
            line
            for line in (
                f'Candidate: {candidate_id}',
                f'Key: {result.value.key}',
                f'Summary: {result.value.summary}' if result.value.summary else '',
                f'Reason: {result.policy_result.reasons[0].message}',
                f'Candidate store: {default_workspace_candidate_memory_store_path(workspace)}',
            )
            if line
        ),
        prompt=f'{action_label} [y/N]: ',
    )
    if approved is True:
        store.commit(
            candidate_id,
            reviewer_id='owner',
            note='approved via inline nanobot memory prompt',
        )
        return candidate_id, 'committed'
    elif approved is False:
        store.reject(
            candidate_id,
            reviewer_id='owner',
            note='rejected via inline nanobot memory prompt',
        )
        return candidate_id, 'rejected'
    return candidate_id, 'pending'


def _adapter(workspace: Path):
    return get_workspace_gateway_adapter(workspace, system_name='nanobot')


def _build_provenance(trigger: str) -> Provenance:
    return augment_provenance(
        Provenance(
            session_id='nanobot:memory',
            channel='system',
            actor_id='nanobot',
            source_trust_levels=(TrustLevel.MODEL_INFERENCE,),
            trigger=trigger,
        )
    )


def _audit_memory_result(
    *,
    workspace: Path,
    result: GuardResult[CandidateMemoryOutput],
    outcome: str,
    result_summary: str | None = None,
) -> GuardResult[CandidateMemoryOutput]:
    return _adapter(workspace).after_action(
        result,
        outcome=outcome,
        result_summary=result_summary,
    )


def _summarize(content: str, limit: int = 120) -> str:
    normalized = ' '.join(content.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3] + '...'
