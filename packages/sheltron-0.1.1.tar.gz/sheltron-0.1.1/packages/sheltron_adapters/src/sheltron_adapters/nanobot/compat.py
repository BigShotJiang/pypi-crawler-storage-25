from __future__ import annotations

import os
from pathlib import Path
import shutil
import sys
from typing import Protocol, TypedDict

from sheltron_core import default_workspace_audit_log_path
from sheltron_mcp import (
    SHELTRON_TOOL_NAMES,
    DOWNSTREAM_BROKER_ENV_VAR,
    default_workspace_approval_store_path,
)

SHELTRON_NANOBOT_SERVER_NAME = 'sheltron'
DANGEROUS_BUILTIN_TOOL_NAMES = (
    'read_file',
    'write_file',
    'edit_file',
    'list_dir',
    'exec',
    'web_fetch',
    'spawn',
    'cron',
)


class NanobotMcpServerData(TypedDict):
    type: str
    command: str
    args: list[str]
    env: dict[str, str]
    toolTimeout: int
    enabledTools: list[str]


class _McpConfigFactory(Protocol):
    def __call__(self, **kwargs: object) -> object:
        ...


class _ExecConfigLike(Protocol):
    enable: bool


class _ToolsConfigLike(Protocol):
    restrict_to_workspace: bool
    exec: _ExecConfigLike
    mcp_servers: dict[str, object]


class RuntimeProfileConfigLike(Protocol):
    workspace_path: Path
    tools: _ToolsConfigLike


class ToolRegistryLike(Protocol):
    def has(self, name: str) -> bool:
        ...

    def unregister(self, name: str) -> None:
        ...


def _default_sheltron_command_path() -> Path:
    detected = shutil.which('sheltron')
    if detected is not None:
        return Path(detected).expanduser().resolve(strict=False)
    sibling = Path(sys.executable).resolve(strict=False).with_name('sheltron')
    if sibling.exists():
        return sibling
    raise FileNotFoundError('Could not locate the `sheltron` command for the nanobot MCP sidecar.')


def build_sheltron_mcp_server_data(
    workspace: str | Path,
    *,
    sheltron_command_path: str | Path | None = None,
) -> NanobotMcpServerData:
    resolved_workspace = Path(workspace).expanduser().resolve(strict=False)
    resolved_sheltron_command = (
        Path(sheltron_command_path).expanduser().resolve(strict=False)
        if sheltron_command_path is not None
        else _default_sheltron_command_path()
    )
    approval_store_path = default_workspace_approval_store_path(resolved_workspace)
    audit_log_path = default_workspace_audit_log_path(resolved_workspace)
    env: dict[str, str] = {}
    downstream_broker_spec = os.environ.get(DOWNSTREAM_BROKER_ENV_VAR)
    if downstream_broker_spec:
        env[DOWNSTREAM_BROKER_ENV_VAR] = downstream_broker_spec
    return {
        'type': 'stdio',
        'command': str(resolved_sheltron_command),
        'args': [
            'mcp',
            'serve',
            '--workspace',
            str(resolved_workspace),
            '--approval-store',
            str(approval_store_path),
            '--audit-log',
            str(audit_log_path),
            '--system',
            'nanobot',
        ],
        'env': env,
        'toolTimeout': 30,
        'enabledTools': list(SHELTRON_TOOL_NAMES),
    }


def apply_sheltron_runtime_profile(
    config: RuntimeProfileConfigLike,
    *,
    mcp_config_factory: _McpConfigFactory,
    sheltron_command_path: str | Path | None = None,
) -> RuntimeProfileConfigLike:
    config.tools.restrict_to_workspace = True
    config.tools.exec.enable = False
    mcp_servers = config.tools.mcp_servers
    mcp_servers.clear()
    mcp_servers[SHELTRON_NANOBOT_SERVER_NAME] = mcp_config_factory(
        **build_sheltron_mcp_server_data(
            config.workspace_path,
            sheltron_command_path=sheltron_command_path,
        )
    )
    return config


def strip_dangerous_builtin_tools(registry: ToolRegistryLike) -> tuple[str, ...]:
    removed: list[str] = []
    for name in DANGEROUS_BUILTIN_TOOL_NAMES:
        if registry.has(name):
            removed.append(name)
        registry.unregister(name)
    return tuple(removed)
