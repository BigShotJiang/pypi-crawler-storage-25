from sheltron_runtime import result_guard as _shared_result_guard

BLOCKED_TOOL_RESULT_HEADER = _shared_result_guard.BLOCKED_TOOL_RESULT_HEADER
NO_WORKAROUND_GUIDANCE = _shared_result_guard.NO_WORKAROUND_GUIDANCE
UNTRUSTED_CONTENT_GUIDANCE = _shared_result_guard.UNTRUSTED_CONTENT_GUIDANCE
WEB_FETCH_MAX_CHARS = _shared_result_guard.WEB_FETCH_MAX_CHARS
WEB_FETCH_TRUNCATION_NOTICE = _shared_result_guard.WEB_FETCH_TRUNCATION_NOTICE
WEB_FETCH_UNTRUSTED_BANNER = _shared_result_guard.WEB_FETCH_UNTRUSTED_BANNER
WEB_SEARCH_MAX_CHARS = _shared_result_guard.WEB_SEARCH_MAX_CHARS
WEB_SEARCH_TRUNCATION_NOTICE = _shared_result_guard.WEB_SEARCH_TRUNCATION_NOTICE
WEB_SEARCH_UNTRUSTED_BANNER = _shared_result_guard.WEB_SEARCH_UNTRUSTED_BANNER
format_untrusted_tool_text = _shared_result_guard.format_untrusted_tool_text
harden_tool_result = _shared_result_guard.harden_tool_result

__all__ = [
    'BLOCKED_TOOL_RESULT_HEADER',
    'NO_WORKAROUND_GUIDANCE',
    'UNTRUSTED_CONTENT_GUIDANCE',
    'WEB_FETCH_MAX_CHARS',
    'WEB_FETCH_TRUNCATION_NOTICE',
    'WEB_FETCH_UNTRUSTED_BANNER',
    'WEB_SEARCH_MAX_CHARS',
    'WEB_SEARCH_TRUNCATION_NOTICE',
    'WEB_SEARCH_UNTRUSTED_BANNER',
    'format_untrusted_tool_text',
    'harden_tool_result',
]
