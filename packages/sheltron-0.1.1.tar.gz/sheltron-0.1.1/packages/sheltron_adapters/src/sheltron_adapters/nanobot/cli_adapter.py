from __future__ import annotations

import argparse

from sheltron_adapters.base import (
    HostAdapterProbe,
    HostInternalCommand,
    ManagedHostCliAdapter,
)
from sheltron_adapters.nanobot.install import (
    SUPPORTED_NANOBOT_PROFILES,
    NanobotDisableResult,
    NanobotDoctorReport,
    NanobotEnableResult,
    NanobotInstallResult,
    NanobotInstallationTarget,
    NanobotUninstallResult,
)


class NanobotHostDelegate:
    name = 'nanobot'
    summary = 'manage and run nanobot through Sheltron'
    supported_profiles = SUPPORTED_NANOBOT_PROFILES
    install_help = 'install the Sheltron-managed nanobot shim and config profile'
    targets_help = 'list discovered nanobot installation targets on PATH'
    uninstall_help = 'restore the original nanobot command and config backup'
    off_help = 'temporarily restore the original nanobot command and config while keeping Sheltron state'
    on_help = 're-enable a previously disabled Sheltron-managed nanobot install'
    doctor_help = 'check whether nanobot is currently protected by Sheltron'
    status_help = 'print concise Sheltron protection status for nanobot'
    force_install_help = 'replace an existing Sheltron-managed nanobot link state'
    no_targets_message = 'No nanobot installations found on PATH.'

    def add_target_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument('--config', '-c', help='nanobot config file path')
        parser.add_argument(
            '--nanobot-command',
            dest='nanobot_command_path',
            help='path to the user-facing nanobot command to manage',
        )
        parser.add_argument('--state-path', help='path to the Sheltron nanobot link state file')

    def add_install_arguments(self, parser: argparse.ArgumentParser) -> None:
        return None

    def install(self, args: argparse.Namespace) -> NanobotInstallResult:
        from sheltron_adapters.nanobot import install_nanobot

        return install_nanobot(
            profile=args.profile,
            config_path=args.config,
            nanobot_command_path=args.nanobot_command_path,
            state_path=args.state_path,
            force=args.force,
        )

    def emit_install_result(self, result: NanobotInstallResult) -> None:
        print(f'Installed Sheltron nanobot profile `{result.state.profile}`.')
        print(f'Config: {result.state.config_path}')
        print(f'Managed command: {result.state.nanobot_command_path}')
        if sheltron_command_path := getattr(result.state, 'sheltron_command_path', None):
            print(f'Sheltron command: {sheltron_command_path}')
        print(f'State: {result.state_path}')

    def discover_targets(self) -> tuple[NanobotInstallationTarget, ...]:
        from sheltron_adapters.nanobot import discover_nanobot_targets

        return discover_nanobot_targets()

    def serialize_target(self, target: NanobotInstallationTarget) -> dict[str, object]:
        return target.model_dump(mode='json')

    def format_target(self, target: NanobotInstallationTarget) -> str:
        return f'{target.command_path} {target.install_kind} real={target.real_command_path}'

    def uninstall(self, args: argparse.Namespace) -> NanobotUninstallResult:
        from sheltron_adapters.nanobot import uninstall_nanobot

        return uninstall_nanobot(
            config_path=args.config,
            nanobot_command_path=args.nanobot_command_path,
            state_path=args.state_path,
        )

    def emit_uninstall_result(self, result: NanobotUninstallResult) -> None:
        if getattr(result, 'already_uninstalled', False):
            print('Sheltron nanobot is already uninstalled. Nothing to remove.')
            print(f'State: {result.state_path}')
            return
        print('Removed the Sheltron-managed nanobot install.')
        print(f'Config: {result.restored_config_path}')
        print(f'Command: {result.restored_command_path}')
        print(f'State: {result.state_path}')

    def turn_off(self, args: argparse.Namespace) -> NanobotDisableResult:
        from sheltron_adapters.nanobot import disable_nanobot

        return disable_nanobot(
            config_path=args.config,
            nanobot_command_path=args.nanobot_command_path,
            state_path=args.state_path,
        )

    def turn_on(self, args: argparse.Namespace) -> NanobotEnableResult:
        from sheltron_adapters.nanobot import enable_nanobot

        return enable_nanobot(
            config_path=args.config,
            nanobot_command_path=args.nanobot_command_path,
            state_path=args.state_path,
        )

    def emit_activation_result(
        self,
        *,
        enabled: bool,
        result: NanobotEnableResult | NanobotDisableResult,
    ) -> None:
        state = 'on' if enabled else 'off'
        print(f'Turned the Sheltron-managed nanobot install {state}.')
        print(f'Command: {result.state.nanobot_command_path}')
        print(f'State: {result.state_path}')
        if not enabled:
            print('Note: plain `nanobot ...` is now native and cannot query `sheltron_status`.')
            print('Use `sheltron status nanobot` for status, `sheltron nanobot ...` for a protected run, or `sheltron on nanobot` for always-on.')

    def doctor(self, args: argparse.Namespace) -> NanobotDoctorReport:
        from sheltron_adapters.nanobot import doctor_nanobot

        return doctor_nanobot(
            config_path=args.config,
            nanobot_command_path=args.nanobot_command_path,
            state_path=args.state_path,
        )

    def emit_doctor_report(self, report: NanobotDoctorReport) -> None:
        print(f'Protection state: {report.protection_state.value}')
        for check in report.checks:
            print(f'{check.status.value.upper():<4} {check.name}: {check.detail}')

    def emit_status_report(self, report: NanobotDoctorReport) -> None:
        print(f'Sheltron nanobot: {report.protection_state.value}')

    def internal_commands(self) -> tuple[HostInternalCommand, ...]:
        return ()

    def probe(self) -> HostAdapterProbe:
        try:
            targets = self.discover_targets()
        except Exception as exc:
            return HostAdapterProbe(
                name=self.name,
                summary=self.summary,
                bundled=True,
                importable=True,
                detected_targets=0,
                detail=f'probe failed: {exc}',
            )
        count = len(targets)
        detail = (
            f'{count} nanobot installation target(s) found on PATH.'
            if count
            else 'No nanobot installation targets found on PATH.'
        )
        return HostAdapterProbe(
            name=self.name,
            summary=self.summary,
            bundled=True,
            importable=True,
            detected_targets=count,
            detail=detail,
        )

    def dispatch_passthrough(self, argv: list[str], *, forced: bool = False) -> int:
        from sheltron_adapters.nanobot import run_nanobot_command

        del forced
        try:
            return run_nanobot_command(command_args=argv)
        except RuntimeError as exc:
            print(str(exc))
            return 1


NANOBOT_CLI_ADAPTER = ManagedHostCliAdapter[
    NanobotInstallationTarget,
    NanobotInstallResult,
    NanobotUninstallResult,
    NanobotEnableResult | NanobotDisableResult,
    NanobotDoctorReport,
](NanobotHostDelegate())


def build_nanobot_cli_adapter() -> ManagedHostCliAdapter[
    NanobotInstallationTarget,
    NanobotInstallResult,
    NanobotUninstallResult,
    NanobotEnableResult | NanobotDisableResult,
    NanobotDoctorReport,
]:
    return NANOBOT_CLI_ADAPTER
