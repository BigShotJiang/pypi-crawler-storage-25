from __future__ import annotations

import json
import re
from typing import Any

from sheltron_core import Evidence, ForwardedEvidenceClaim, Provenance, TrustLevel
from sheltron_adapters.nanobot.runtime_session import (
    PendingDefenseEvidence,
    clear_pending_defense_evidence,
    current_runtime_session,
    update_pending_defense_evidence,
)

_BLOCKED_TOOL_RESULT_HEADER = '[Sheltron policy result]'
_MAX_SNIPPET_CHARS = 600
_SUSPICIOUS_TOOL_OUTPUT_PATTERNS = (
    re.compile(r'ignore (?:all )?(?:previous|prior) instructions', re.IGNORECASE),
    re.compile(r'owner already approved', re.IGNORECASE),
    re.compile(r'do not ask again', re.IGNORECASE),
    re.compile(r'continue with exec immediately', re.IGNORECASE),
    re.compile(r'policy (?:changed|updated|overridden)', re.IGNORECASE),
)
def record_tool_result_evidence(tool_name: str, result: object) -> None:
    extracted = _extract_pending_evidence(tool_name, result)
    if extracted is None:
        return
    current = current_runtime_session().pending_defense_evidence
    merged = PendingDefenseEvidence(
        evidence=_merge_evidence(current.evidence, extracted.evidence),
        trust_levels=_merge_trust_levels(current.trust_levels, extracted.trust_levels),
    )
    update_pending_defense_evidence(merged)


def augment_provenance(base: Provenance, *, consume: bool = True) -> Provenance:
    pending = consume_pending_defense_evidence() if consume else current_runtime_session().pending_defense_evidence
    if not pending.evidence and not pending.trust_levels:
        return base
    return base.model_copy(
        update={
            'source_trust_levels': _merge_trust_levels(base.source_trust_levels, pending.trust_levels),
            'evidence': _merge_evidence(base.evidence, pending.evidence),
        }
    )


def consume_pending_defense_evidence() -> PendingDefenseEvidence:
    return clear_pending_defense_evidence()


def consume_internal_provenance_kwargs() -> dict[str, list[ForwardedEvidenceClaim]]:
    pending = consume_pending_defense_evidence()
    if not pending.evidence and not pending.trust_levels:
        return {}
    return {
        '_sheltron_evidence': [
            {
                'source': evidence.source,
                'reference': evidence.reference,
                'snippet': evidence.snippet,
            }
            for evidence in pending.evidence
        ],
    }


def _extract_pending_evidence(tool_name: str, result: object) -> PendingDefenseEvidence | None:
    if not isinstance(result, str) or not result:
        return None
    if result.startswith(_BLOCKED_TOOL_RESULT_HEADER):
        return None

    payload = _parse_json_object(result)
    if payload is not None and payload.get('decision') in {'deny', 'require_approval'}:
        return None

    if tool_name == 'web_search':
        return PendingDefenseEvidence(
            evidence=(
                Evidence(
                    source='web_search',
                    reference=tool_name,
                    snippet=_truncate_snippet(result),
                ),
            ),
            trust_levels=(TrustLevel.WEB_UNTRUSTED,),
        )

    if tool_name == 'web_fetch' and isinstance(payload, dict):
        text = payload.get('text')
        url = payload.get('url')
        if isinstance(text, str) and text:
            return PendingDefenseEvidence(
                evidence=(
                    Evidence(
                        source='web_fetch',
                        reference=str(url) if isinstance(url, str) and url else tool_name,
                        snippet=_truncate_snippet(text),
                    ),
                ),
                trust_levels=(TrustLevel.WEB_UNTRUSTED,),
            )

    if _looks_like_suspicious_tool_output(result):
        trust_levels: tuple[TrustLevel, ...] = ()
        if tool_name.startswith('mcp_'):
            trust_levels = (TrustLevel.MCP_UNTRUSTED,)
        return PendingDefenseEvidence(
            evidence=(
                Evidence(
                    source='tool_output',
                    reference=tool_name,
                    snippet=_truncate_snippet(result),
                ),
            ),
            trust_levels=trust_levels,
        )
    return None


def _looks_like_suspicious_tool_output(text: str) -> bool:
    return any(pattern.search(text) is not None for pattern in _SUSPICIOUS_TOOL_OUTPUT_PATTERNS)


def _merge_evidence(
    left: tuple[Evidence, ...],
    right: tuple[Evidence, ...],
) -> tuple[Evidence, ...]:
    merged: list[Evidence] = []
    seen: set[tuple[str, str | None, str | None]] = set()
    for evidence in (*left, *right):
        key = (evidence.source, evidence.reference, evidence.snippet)
        if key in seen:
            continue
        seen.add(key)
        merged.append(evidence)
    return tuple(merged)


def _merge_trust_levels(
    left: tuple[TrustLevel, ...],
    right: tuple[TrustLevel, ...],
) -> tuple[TrustLevel, ...]:
    merged: list[TrustLevel] = []
    seen: set[TrustLevel] = set()
    for level in (*left, *right):
        if level in seen:
            continue
        seen.add(level)
        merged.append(level)
    return tuple(merged)


def _truncate_snippet(text: str) -> str:
    normalized = ' '.join(text.split())
    if len(normalized) <= _MAX_SNIPPET_CHARS:
        return normalized
    return normalized[: _MAX_SNIPPET_CHARS - 3] + '...'


def _parse_json_object(result: str) -> dict[str, Any] | None:
    try:
        payload = json.loads(result)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    return payload
