from __future__ import annotations

import asyncio
from contextlib import nullcontext
import json
from pathlib import Path
import sys
from threading import Lock
from typing import Awaitable, Callable, ContextManager, Literal, NotRequired, Protocol, Required, TypedDict

from sheltron_core import ApprovalStore, JsonObject, load_json_approval_store
from sheltron_core.json_types import is_json_object

SHELTRON_MCP_TOOL_PREFIX = 'mcp_sheltron_'
_INLINE_APPROVAL_LOCK = asyncio.Lock()
_INLINE_PROMPT_LOCK = Lock()
_INLINE_PROMPTS_ENABLED = True


class ApprovalRequiredPayload(TypedDict):
    approval_store: Required[str]
    approval_ticket_id: Required[str]
    capability: Required[str]
    decision: Required[Literal['require_approval']]
    reason: Required[str]
    reason_code: Required[str]
    resource: Required[str]
    details: NotRequired[JsonObject]
    audit_log: NotRequired[str]
    matched_policy: NotRequired[str]
    request_id: NotRequired[str]
    executed: NotRequired[bool]
    inline_review: NotRequired[str]


class _Spinner(Protocol):
    def pause(self) -> ContextManager[object]:
        ...


_ACTIVE_SPINNER: _Spinner | None = None


def supports_inline_approval() -> bool:
    return _INLINE_PROMPTS_ENABLED and hasattr(sys.stdin, 'isatty') and sys.stdin.isatty()


def set_active_spinner(spinner: _Spinner | None) -> None:
    global _ACTIVE_SPINNER
    _ACTIVE_SPINNER = spinner


def set_inline_prompts_enabled(enabled: bool) -> None:
    global _INLINE_PROMPTS_ENABLED
    _INLINE_PROMPTS_ENABLED = enabled


def prompt_inline_decision(
    *,
    header: str,
    lines: tuple[str, ...] = (),
    prompt: str = 'Approve this request? [y/N]: ',
) -> bool | None:
    if not supports_inline_approval():
        return None

    with _INLINE_PROMPT_LOCK:
        pause_context = _ACTIVE_SPINNER.pause() if _ACTIVE_SPINNER is not None else nullcontext()
        with pause_context:
            print()
            print(header)
            for line in lines:
                if line:
                    print(line)
            response = input(prompt).strip().lower()
    return response in {'y', 'yes'}


def _approval_required_payload(payload: JsonObject) -> ApprovalRequiredPayload | None:
    approval_store = payload.get('approval_store')
    approval_ticket_id = payload.get('approval_ticket_id')
    capability = payload.get('capability')
    decision = payload.get('decision')
    reason = payload.get('reason')
    reason_code = payload.get('reason_code')
    resource = payload.get('resource')
    if not all(
        isinstance(value, str) and value
        for value in (
            approval_store,
            approval_ticket_id,
            capability,
            decision,
            reason,
            reason_code,
            resource,
        )
    ):
        return None
    if decision != 'require_approval':
        return None

    typed_payload: ApprovalRequiredPayload = {
        'approval_store': approval_store,
        'approval_ticket_id': approval_ticket_id,
        'capability': capability,
        'decision': 'require_approval',
        'reason': reason,
        'reason_code': reason_code,
        'resource': resource,
    }
    details = payload.get('details')
    if isinstance(details, dict) and is_json_object(details):
        typed_payload['details'] = details
    audit_log = payload.get('audit_log')
    if isinstance(audit_log, str) and audit_log:
        typed_payload['audit_log'] = audit_log
    matched_policy = payload.get('matched_policy')
    if isinstance(matched_policy, str) and matched_policy:
        typed_payload['matched_policy'] = matched_policy
    request_id = payload.get('request_id')
    if isinstance(request_id, str) and request_id:
        typed_payload['request_id'] = request_id
    executed = payload.get('executed')
    if isinstance(executed, bool):
        typed_payload['executed'] = executed
    inline_review = payload.get('inline_review')
    if isinstance(inline_review, str) and inline_review:
        typed_payload['inline_review'] = inline_review
    return typed_payload


def parse_approval_required_result(tool_name: str, result: object) -> ApprovalRequiredPayload | None:
    if not isinstance(result, str):
        return None
    try:
        payload = json.loads(result)
    except json.JSONDecodeError:
        return None
    if not is_json_object(payload):
        return None
    typed_payload = _approval_required_payload(payload)
    if typed_payload is None:
        return None
    if tool_name.startswith(SHELTRON_MCP_TOOL_PREFIX):
        return typed_payload
    if tool_name in {'read_file', 'write_file', 'edit_file', 'list_dir'} and typed_payload['capability'] in {
        'read_file',
        'write_file',
        'edit_file',
    }:
        return typed_payload
    if tool_name == 'exec' and typed_payload['capability'] == 'exec':
        return typed_payload
    if tool_name == 'web_fetch' and typed_payload['capability'] == 'network_fetch':
        return typed_payload
    if tool_name == 'message' and typed_payload['capability'] == 'send_message':
        return typed_payload
    if tool_name in {'spawn', 'cron'} and typed_payload['capability'] == 'schedule_task':
        return typed_payload
    return None


def _build_rejected_result(payload: ApprovalRequiredPayload) -> str:
    updated: JsonObject = dict(payload)
    details: JsonObject = dict(payload.get('details') or {})
    details['approval_ticket_id'] = payload['approval_ticket_id']
    details['original_reason_code'] = payload['reason_code']
    updated['matched_policy'] = 'approval_bridge'
    updated['reason_code'] = 'approval_rejected_by_user'
    updated['reason'] = 'The owner rejected this request in the Sheltron approval prompt.'
    updated['details'] = details
    updated['inline_review'] = 'rejected'
    return json.dumps(updated, sort_keys=True)


def _reject_ticket(payload: ApprovalRequiredPayload) -> None:
    store, ticket_id = _load_store_from_payload(payload)
    store.reject(
        ticket_id,
        reviewer_id='owner',
        note='rejected via inline nanobot prompt',
    )


def _approve_ticket(payload: ApprovalRequiredPayload) -> None:
    store, ticket_id = _load_store_from_payload(payload)
    store.approve(
        ticket_id,
        reviewer_id='owner',
        note='approved via inline nanobot prompt',
    )


def _load_store_from_payload(payload: ApprovalRequiredPayload) -> tuple[ApprovalStore, str]:
    store = load_json_approval_store(
        Path(payload['approval_store']),
        audit_log_path=payload.get('audit_log'),
    )
    return store, payload['approval_ticket_id']


async def maybe_resume_with_inline_approval(
    *,
    tool_name: str,
    params: JsonObject,
    result: object,
    retry_call: Callable[[JsonObject], Awaitable[object]],
) -> object:
    payload = parse_approval_required_result(tool_name, result)
    if payload is None or not supports_inline_approval():
        return result

    async with _INLINE_APPROVAL_LOCK:
        resource = payload['resource']
        capability = payload['capability']
        reason = payload['reason']
        ticket_id = payload['approval_ticket_id']
        approved = prompt_inline_decision(
            header='Sheltron approval required.',
            lines=tuple(
                line
                for line in (
                    f'Action: {capability} {resource}'.strip() if capability or resource else '',
                    f'Reason: {reason}' if reason else '',
                )
                if line
            ),
        )
        if approved is not True:
            _reject_ticket(payload)
            return _build_rejected_result(payload)

        _approve_ticket(payload)
        retry_params = dict(params)
        retry_params['approval_ticket_id'] = ticket_id
        return await retry_call(retry_params)
