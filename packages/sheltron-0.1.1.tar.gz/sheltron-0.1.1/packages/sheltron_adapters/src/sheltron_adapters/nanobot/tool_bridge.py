from __future__ import annotations

from typing import Awaitable, Callable

from sheltron_core import JsonObject
from sheltron_adapters.nanobot.approval_bridge import maybe_resume_with_inline_approval
from sheltron_adapters.nanobot.defense_context import record_tool_result_evidence
from sheltron_adapters.nanobot.result_guard import harden_tool_result


async def finalize_tool_result(
    *,
    tool_name: str,
    params: JsonObject,
    result: object,
    retry_call: Callable[[JsonObject], Awaitable[object]],
    inline_approvals: bool,
) -> object:
    bridged_result = result
    if inline_approvals:
        bridged_result = await maybe_resume_with_inline_approval(
            tool_name=tool_name,
            params=params,
            result=bridged_result,
            retry_call=retry_call,
        )
    hardened_result = harden_tool_result(tool_name, bridged_result)
    record_tool_result_evidence(tool_name, hardened_result)
    return hardened_result
