from __future__ import annotations

from collections.abc import Callable
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime
import inspect
import json
from pathlib import Path
import sys
from typing import Any, Iterator

from sheltron_adapters.nanobot.approval_bridge import (
    set_active_spinner,
    set_inline_prompts_enabled,
)
from sheltron_adapters.nanobot.compat import apply_sheltron_runtime_profile, strip_dangerous_builtin_tools
from sheltron_adapters.nanobot.defense_context import consume_internal_provenance_kwargs
from sheltron_adapters.nanobot.gateway_context import active_gateway_context
from sheltron_adapters.nanobot.tool_bridge import finalize_tool_result

_SHELTRON_ATTRIBUTION_GUIDANCE = """## Sheltron Attribution
- Only say Sheltron blocked, denied, or required approval for an action if this turn actually produced a Sheltron policy result, blocked tool result, or approval prompt.
- If a tool was not called yet, say you have not verified the action instead of blaming Sheltron.
- If a tool failed for another reason, report that specific failure instead of attributing it to Sheltron.
- If the user explicitly asks whether Sheltron is on, enabled, active, or protecting this session, call `sheltron_status` before answering. If the host shows a prefixed MCP name, use that `sheltron_status` equivalent.
- Do not call `sheltron_status` for generic safety questions, unrelated plugin status, or other safety systems unless the user specifically names Sheltron.
"""

_SUPPORTED_NANOBOT_MEMORY_APIS = (
    'nanobot-ai 0.1.4.post6 (write_long_term + HISTORY.md) and '
    'nanobot-ai 0.1.5.post2 (write_memory + history.jsonl)'
)
_PREPARE_CALL_INLINE_BRIDGE_ENABLED: ContextVar[bool] = ContextVar(
    'sheltron_prepare_call_inline_bridge_enabled',
    default=True,
)


def _nanobot_not_installed_message() -> str:
    project_python = Path.cwd() / '.venv' / 'bin' / 'python'
    remedies = [
        'nanobot is not importable in the current Python environment.',
        '`sheltron link nanobot` records the managed nanobot site-packages path so the Sheltron CLI can import nanobot for protected runs.',
    ]
    if project_python.exists():
        remedies.append(
            f'Install nanobot into this environment with: uv pip install --python {project_python} nanobot-ai'
        )
    remedies.append(
        'If this is a fresh machine, install nanobot first with `uv tool install nanobot-ai`, then run `sheltron link nanobot`.'
    )
    return ' '.join(remedies)


def _missing_nanobot_dependency(exc: ModuleNotFoundError) -> bool:
    name = exc.name or ''
    message = str(exc)
    if name:
        return name == 'nanobot' or name.startswith('nanobot.')
    if "No module named 'nanobot" in message or 'No module named "nanobot' in message:
        return True
    return False


def _nanobot_import_error_message(exc: ImportError) -> str:
    if isinstance(exc, ModuleNotFoundError) and _missing_nanobot_dependency(exc):
        return _nanobot_not_installed_message()
    return (
        'nanobot is importable, but the installed nanobot package is incompatible with the current '
        f'Sheltron adapter: {exc}. Run `sheltron doctor nanobot` and verify the supported nanobot version.'
    )


def _unsupported_nanobot_memory_api_message(detail: str) -> str:
    return (
        'The installed nanobot MemoryStore API is not supported by the current Sheltron adapter. '
        f'Supported memory APIs: {_SUPPORTED_NANOBOT_MEMORY_APIS}. {detail}'
    )


def _select_nanobot_long_term_writer(memory_store_cls: type[Any]) -> str:
    for method_name in ('write_long_term', 'write_memory'):
        if callable(getattr(memory_store_cls, method_name, None)):
            return method_name
    raise RuntimeError(
        _unsupported_nanobot_memory_api_message(
            'Expected MemoryStore.write_long_term or MemoryStore.write_memory.'
        )
    )


def _nanobot_memory_workspace(memory_store: Any) -> Path:
    workspace = getattr(memory_store, 'workspace', None)
    if workspace is not None:
        return Path(workspace)
    memory_dir = getattr(memory_store, 'memory_dir', None)
    if memory_dir is not None:
        return Path(memory_dir).parent
    raise RuntimeError(
        _unsupported_nanobot_memory_api_message(
            'Expected MemoryStore.workspace or MemoryStore.memory_dir.'
        )
    )


def _nanobot_history_path(memory_store: Any, *, workspace: Path) -> Path:
    history_file = getattr(memory_store, 'history_file', None)
    if history_file is not None:
        return Path(history_file)
    return workspace / 'memory' / 'HISTORY.md'


def _nanobot_uses_jsonl_history(memory_store: Any) -> bool:
    history_file = getattr(memory_store, 'history_file', None)
    return history_file is not None and Path(history_file).name == 'history.jsonl'


def _strip_nanobot_think(text: str) -> str:
    try:
        from nanobot.agent.memory import strip_think
    except (ImportError, AttributeError):
        return text
    return strip_think(text)


def _format_nanobot_jsonl_history_entry(memory_store: Any, entry: str) -> tuple[int, str]:
    next_cursor = getattr(memory_store, '_next_cursor', None)
    if not callable(next_cursor):
        raise RuntimeError(
            _unsupported_nanobot_memory_api_message(
                'Expected MemoryStore._next_cursor for history.jsonl support.'
            )
        )
    cursor = int(next_cursor())
    record = {
        'cursor': cursor,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M'),
        'content': _strip_nanobot_think(entry.rstrip()),
    }
    return cursor, json.dumps(record, ensure_ascii=False) + '\n'


def _write_nanobot_history_cursor(memory_store: Any, cursor: int) -> None:
    cursor_file = getattr(memory_store, '_cursor_file', None)
    if cursor_file is None:
        return
    path = Path(cursor_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(cursor), encoding='utf-8')


def _save_nanobot_history_entry(memory_store: Any, entry: str) -> int | None:
    from sheltron_adapters.nanobot.memory_bridge import save_history_candidate_with_status

    workspace = _nanobot_memory_workspace(memory_store)
    target_path = _nanobot_history_path(memory_store, workspace=workspace)
    if _nanobot_uses_jsonl_history(memory_store):
        cursor, content = _format_nanobot_jsonl_history_entry(memory_store, entry)
        _candidate_id, status = save_history_candidate_with_status(
            workspace=workspace,
            content=content,
            target_path=target_path,
        )
        if status == 'committed':
            _write_nanobot_history_cursor(memory_store, cursor)
        return cursor

    save_history_candidate_with_status(
        workspace=workspace,
        content=entry.rstrip() + '\n\n',
        target_path=target_path,
    )
    return None


def _patch_nanobot_memory_store(memory_store_cls: type[Any]) -> Callable[[], None]:
    long_term_writer_name = _select_nanobot_long_term_writer(memory_store_cls)
    original_long_term_writer = getattr(memory_store_cls, long_term_writer_name)
    original_append_history = getattr(memory_store_cls, 'append_history', None)
    if not callable(original_append_history):
        raise RuntimeError(
            _unsupported_nanobot_memory_api_message('Expected MemoryStore.append_history.')
        )

    def patched_write_long_term(self, content: str) -> None:
        from sheltron_adapters.nanobot.memory_bridge import save_long_term_candidate

        save_long_term_candidate(workspace=_nanobot_memory_workspace(self), content=content)

    def patched_append_history(self, entry: str) -> int | None:
        return _save_nanobot_history_entry(self, entry)

    setattr(memory_store_cls, long_term_writer_name, patched_write_long_term)
    memory_store_cls.append_history = patched_append_history

    def restore() -> None:
        setattr(memory_store_cls, long_term_writer_name, original_long_term_writer)
        memory_store_cls.append_history = original_append_history

    return restore


class _InlineApprovalToolProxy:
    def __init__(self, *, tool: Any, tool_name: str, inline_approvals: bool) -> None:
        self._tool = tool
        self._tool_name = tool_name
        self._inline_approvals = inline_approvals

    def __getattr__(self, name: str) -> Any:
        return getattr(self._tool, name)

    async def execute(self, **params: Any) -> object:
        result = await self._tool.execute(**params)
        return await finalize_tool_result(
            tool_name=self._tool_name,
            params=dict(params),
            result=result,
            retry_call=lambda retry_params: self._tool.execute(**retry_params),
            inline_approvals=self._inline_approvals,
        )


def _patch_nanobot_tool_registry_prepare_call(
    tool_registry_cls: type[Any],
    *,
    inline_approvals: bool,
) -> Callable[[], None]:
    original_prepare_call = getattr(tool_registry_cls, 'prepare_call', None)
    if not callable(original_prepare_call):
        return lambda: None

    def patched_prepare_call(self, name: str, params: dict[str, Any]):
        prepared = original_prepare_call(self, name, params)
        if not _PREPARE_CALL_INLINE_BRIDGE_ENABLED.get():
            return prepared
        if not isinstance(prepared, tuple) or len(prepared) != 3:
            return prepared
        tool, cast_params, error = prepared
        if tool is None or error:
            return prepared
        return (
            _InlineApprovalToolProxy(
                tool=tool,
                tool_name=name,
                inline_approvals=inline_approvals,
            ),
            cast_params,
            error,
        )

    tool_registry_cls.prepare_call = patched_prepare_call

    def restore() -> None:
        tool_registry_cls.prepare_call = original_prepare_call

    return restore


def _nanobot_loop_web_settings(loop: Any) -> tuple[bool, Any, str | None]:
    web_config = getattr(loop, 'web_config', None)
    if web_config is not None:
        return (
            bool(getattr(web_config, 'enable', True)),
            getattr(web_config, 'search', None),
            getattr(web_config, 'proxy', None),
        )

    web_search_config = getattr(loop, 'web_search_config', None)
    if web_search_config is None:
        try:
            from nanobot.config.schema import WebSearchConfig
        except ImportError as exc:
            raise RuntimeError(_nanobot_import_error_message(exc)) from exc
        web_search_config = WebSearchConfig()
    return True, web_search_config, getattr(loop, 'web_proxy', None)


def _call_nanobot_process_message(
    original_process_message: Callable[..., Any],
    loop: Any,
    msg: Any,
    *,
    session_key: str | None,
    on_progress: Any,
    on_stream: Any,
    on_stream_end: Any,
    extra_kwargs: dict[str, Any],
) -> Any:
    parameters = inspect.signature(original_process_message).parameters
    accepts_var_kwargs = any(parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values())
    call_kwargs: dict[str, Any] = {
        'session_key': session_key,
        'on_progress': on_progress,
        'on_stream': on_stream,
        'on_stream_end': on_stream_end,
    }
    if accepts_var_kwargs:
        call_kwargs.update(extra_kwargs)
    else:
        call_kwargs.update({key: value for key, value in extra_kwargs.items() if key in parameters})
    return original_process_message(loop, msg, **call_kwargs)


def _call_nanobot_build_system_prompt(
    original_build_system_prompt: Callable[..., str],
    builder: Any,
    *,
    skill_names: list[str] | None,
    extra_kwargs: dict[str, Any],
) -> str:
    parameters = inspect.signature(original_build_system_prompt).parameters
    accepts_var_kwargs = any(parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values())
    call_kwargs: dict[str, Any] = {'skill_names': skill_names}
    if accepts_var_kwargs:
        call_kwargs.update(extra_kwargs)
    else:
        call_kwargs.update({key: value for key, value in extra_kwargs.items() if key in parameters})
    return original_build_system_prompt(builder, **call_kwargs)


@contextmanager
def patched_nanobot_runtime(*, inline_approvals: bool = True) -> Iterator[None]:
    _prepend_managed_nanobot_site_packages()
    try:
        from nanobot.agent.loop import AgentLoop
        from nanobot.agent.context import ContextBuilder
        from nanobot.agent.memory import MemoryStore
        from nanobot.agent.subagent import SubagentManager
        from nanobot.cli import commands
        from nanobot.cli.stream import ThinkingSpinner
        from nanobot.config.schema import MCPServerConfig
        from nanobot.agent.tools.registry import ToolRegistry
    except ImportError as exc:
        raise RuntimeError(_nanobot_import_error_message(exc)) from exc

    original_load_runtime_config = commands._load_runtime_config
    original_register_default_tools = AgentLoop._register_default_tools
    original_process_message = AgentLoop._process_message
    original_set_tool_context = AgentLoop._set_tool_context
    original_build_system_prompt = ContextBuilder.build_system_prompt
    original_execute = ToolRegistry.execute
    original_spinner_enter = ThinkingSpinner.__enter__
    original_spinner_exit = ThinkingSpinner.__exit__
    original_run_subagent = SubagentManager._run_subagent
    restore_memory_store = _patch_nanobot_memory_store(MemoryStore)
    restore_prepare_call = _patch_nanobot_tool_registry_prepare_call(
        ToolRegistry,
        inline_approvals=inline_approvals,
    )

    def patched_load_runtime_config(config: str | None, workspace: str | None):
        runtime_config = original_load_runtime_config(config, workspace)
        return apply_sheltron_runtime_profile(
            runtime_config,
            mcp_config_factory=MCPServerConfig,
            sheltron_command_path=Path(sys.argv[0]).resolve(strict=False),
        )

    def patched_register_default_tools(self) -> None:
        from sheltron_adapters.nanobot.message_tool import replace_message_tool
        from sheltron_adapters.nanobot.search_tool import replace_search_tool
        from sheltron_adapters.nanobot.schedule_tool import replace_schedule_tools

        original_register_default_tools(self)
        strip_dangerous_builtin_tools(self.tools)
        web_enabled, web_search_config, web_proxy = _nanobot_loop_web_settings(self)
        replace_search_tool(
            self.tools,
            workspace=self.workspace,
            web_search_config=web_search_config,
            web_proxy=web_proxy,
            enabled=web_enabled,
        )
        replace_message_tool(
            self.tools,
            workspace=self.workspace,
            send_callback=self.bus.publish_outbound,
        )
        replace_schedule_tools(
            self.tools,
            workspace=self.workspace,
            subagent_manager=self.subagents,
            cron_service=self.cron_service,
            default_timezone=self.context.timezone or 'UTC',
        )

    def patched_set_tool_context(self, channel: str, chat_id: str, message_id: str | None = None) -> None:
        original_set_tool_context(self, channel, chat_id, message_id)
        _set_search_tool_context(self, channel, chat_id, message_id)

    def patched_build_system_prompt(self, skill_names: list[str] | None = None, **kwargs) -> str:
        prompt = _call_nanobot_build_system_prompt(
            original_build_system_prompt,
            self,
            skill_names=skill_names,
            extra_kwargs=kwargs,
        )
        if _SHELTRON_ATTRIBUTION_GUIDANCE in prompt:
            return prompt
        return f'{prompt}\n\n---\n\n{_SHELTRON_ATTRIBUTION_GUIDANCE}'

    async def patched_process_message(
        self,
        msg,
        session_key: str | None = None,
        on_progress=None,
        on_stream=None,
        on_stream_end=None,
        **kwargs,
    ):
        if msg.channel == 'system':
            resolved_channel, resolved_chat_id = (
                msg.chat_id.split(':', 1) if ':' in msg.chat_id else ('cli', msg.chat_id)
            )
            resolved_session_key = f'{resolved_channel}:{resolved_chat_id}'
        else:
            resolved_channel = msg.channel
            resolved_chat_id = msg.chat_id
            resolved_session_key = session_key or getattr(msg, 'session_key', None)
        message_id = (msg.metadata or {}).get('message_id')
        _set_search_tool_context(
            self,
            resolved_channel,
            resolved_chat_id,
            message_id,
            session_id=resolved_session_key,
        )
        return await _call_nanobot_process_message(
            original_process_message,
            self,
            msg,
            session_key=session_key,
            on_progress=on_progress,
            on_stream=on_stream,
            on_stream_end=on_stream_end,
            extra_kwargs=kwargs,
        )

    async def patched_execute(self, name: str, params: dict):
        patched_params = dict(params)
        if name == 'mcp_sheltron_sheltron_exec':
            patched_params.update(consume_internal_provenance_kwargs())
        token = _PREPARE_CALL_INLINE_BRIDGE_ENABLED.set(False)
        try:
            result = await original_execute(self, name, patched_params)
        finally:
            _PREPARE_CALL_INLINE_BRIDGE_ENABLED.reset(token)
        return await finalize_tool_result(
            tool_name=name,
            params=patched_params,
            result=result,
            retry_call=lambda retry_params: original_execute(self, name, retry_params),
            inline_approvals=inline_approvals,
        )

    def patched_spinner_enter(self):
        spinner = original_spinner_enter(self)
        set_active_spinner(self)
        return spinner

    def patched_spinner_exit(self, *exc):
        set_active_spinner(None)
        return original_spinner_exit(self, *exc)

    async def patched_run_subagent(
        self,
        task_id: str,
        task: str,
        label: str,
        origin: dict[str, str],
        *args,
        **kwargs,
    ) -> None:
        from sheltron_adapters.nanobot.subagent_tools import run_governed_subagent

        status = args[0] if args else kwargs.get('status')
        await run_governed_subagent(
            self,
            task_id=task_id,
            task=task,
            label=label,
            origin=origin,
            status=status,
        )

    commands._load_runtime_config = patched_load_runtime_config
    AgentLoop._register_default_tools = patched_register_default_tools
    AgentLoop._process_message = patched_process_message
    AgentLoop._set_tool_context = patched_set_tool_context
    ContextBuilder.build_system_prompt = patched_build_system_prompt
    ToolRegistry.execute = patched_execute
    ThinkingSpinner.__enter__ = patched_spinner_enter
    ThinkingSpinner.__exit__ = patched_spinner_exit
    SubagentManager._run_subagent = patched_run_subagent
    set_inline_prompts_enabled(inline_approvals)
    with active_gateway_context(system_name='nanobot'):
        try:
            yield
        finally:
            commands._load_runtime_config = original_load_runtime_config
            AgentLoop._register_default_tools = original_register_default_tools
            AgentLoop._process_message = original_process_message
            AgentLoop._set_tool_context = original_set_tool_context
            ContextBuilder.build_system_prompt = original_build_system_prompt
            ToolRegistry.execute = original_execute
            ThinkingSpinner.__enter__ = original_spinner_enter
            ThinkingSpinner.__exit__ = original_spinner_exit
            restore_prepare_call()
            restore_memory_store()
            SubagentManager._run_subagent = original_run_subagent
            set_active_spinner(None)
            set_inline_prompts_enabled(True)


def _set_search_tool_context(
    loop,
    channel: str,
    chat_id: str,
    message_id: str | None = None,
    *,
    session_id: str | None = None,
) -> None:
    if tool := loop.tools.get('web_search'):
        if hasattr(tool, 'set_context'):
            tool.set_context(
                channel,
                chat_id,
                message_id,
                session_id=session_id,
            )


def run_nanobot_agent(
    *,
    message: str | None = None,
    session_id: str = 'cli:direct',
    workspace: str | None = None,
    config: str | None = None,
    markdown: bool = True,
    logs: bool = False,
) -> int:
    command_args = ['agent']
    if message is not None:
        command_args.extend(['--message', message])
    if session_id != 'cli:direct':
        command_args.extend(['--session', session_id])
    if workspace is not None:
        command_args.extend(['--workspace', workspace])
    if config is not None:
        command_args.extend(['--config', config])
    if not markdown:
        command_args.append('--no-markdown')
    if logs:
        command_args.append('--logs')
    return run_nanobot_command(command_args=command_args)


def run_nanobot_gateway(
    *,
    port: int | None = None,
    workspace: str | None = None,
    verbose: bool = False,
    config: str | None = None,
) -> int:
    _prepend_managed_nanobot_site_packages()
    try:
        from nanobot.cli import commands
    except ImportError as exc:
        raise RuntimeError(_nanobot_import_error_message(exc)) from exc

    with patched_nanobot_runtime(inline_approvals=False):
        commands.gateway(
            port=port,
            workspace=workspace,
            verbose=verbose,
            config=config,
        )
    return 0


def _normalize_nanobot_command_args(command_args: list[str] | tuple[str, ...]) -> list[str]:
    forwarded_args = list(command_args)
    if forwarded_args[:1] == ['--']:
        return forwarded_args[1:]
    return forwarded_args


def _nanobot_inline_approvals(command_args: list[str]) -> bool:
    return command_args[:1] != ['gateway']


def run_nanobot_command(
    *,
    command_args: list[str] | tuple[str, ...] = (),
) -> int:
    _prepend_managed_nanobot_site_packages()
    try:
        from nanobot.cli.commands import app
    except ImportError as exc:
        raise RuntimeError(_nanobot_import_error_message(exc)) from exc

    forwarded_args = _normalize_nanobot_command_args(command_args)
    with patched_nanobot_runtime(inline_approvals=_nanobot_inline_approvals(forwarded_args)):
        try:
            result = app(
                args=forwarded_args,
                prog_name='nanobot',
                standalone_mode=False,
            )
        except SystemExit as exc:
            return int(exc.code or 0)
    return int(result) if isinstance(result, int) else 0


def _prepend_managed_nanobot_site_packages() -> None:
    try:
        from sheltron_adapters.nanobot.install import (
            _load_install_state,
            default_nanobot_install_state_path,
        )
    except ImportError:
        return
    state = _load_install_state(default_nanobot_install_state_path())
    if state is None:
        return
    site_packages = Path(state.nanobot_site_packages).expanduser().resolve(strict=False)
    if not site_packages.exists():
        return
    site_packages_text = str(site_packages)
    if site_packages_text not in sys.path:
        sys.path.insert(0, site_packages_text)
