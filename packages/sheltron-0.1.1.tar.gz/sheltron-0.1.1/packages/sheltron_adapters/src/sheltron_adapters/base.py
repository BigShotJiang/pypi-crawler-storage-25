from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
from typing import Callable, Generic, Protocol, Sequence, TypeVar

from sheltron_core import JsonObject

ParserSubcommands = argparse._SubParsersAction


class SupportsHealthyReport(Protocol):
    @property
    def healthy(self) -> bool:
        ...


TargetT = TypeVar('TargetT')
InstallResultT = TypeVar('InstallResultT')
UninstallResultT = TypeVar('UninstallResultT')
ActivationResultT = TypeVar('ActivationResultT')
DoctorReportT = TypeVar('DoctorReportT', bound=SupportsHealthyReport)


@dataclass(frozen=True)
class HostAdapterProbe:
    name: str
    summary: str
    bundled: bool
    importable: bool
    detected_targets: int
    detail: str

    @property
    def available(self) -> bool:
        return self.importable

    @property
    def status(self) -> str:
        if not self.importable:
            return 'unavailable'
        if self.detected_targets > 0:
            return 'supported'
        return 'available'


class CliHostAdapter(Protocol):
    name: str
    summary: str
    known_commands: tuple[str, ...]

    def register_parser(self, subparsers: ParserSubcommands) -> None:
        ...

    def dispatch(self, args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
        ...

    def dispatch_passthrough(self, argv: list[str], *, forced: bool = False) -> int:
        ...

    def dispatch_lifecycle(self, command: str, argv: list[str], *, prog: str | None = None) -> int:
        ...

    def uninstall_default(self) -> int:
        ...

    def probe(self) -> HostAdapterProbe:
        ...


@dataclass(frozen=True)
class HostInternalCommand:
    name: str
    register_parser: Callable[[ParserSubcommands], None]
    dispatch: Callable[[argparse.Namespace, argparse.ArgumentParser], int]


class HostCliDelegate(
    Protocol[TargetT, InstallResultT, UninstallResultT, ActivationResultT, DoctorReportT]
):
    name: str
    summary: str
    supported_profiles: tuple[str, ...]
    install_help: str
    targets_help: str
    uninstall_help: str
    off_help: str
    on_help: str
    doctor_help: str
    status_help: str
    force_install_help: str | None
    no_targets_message: str

    def add_target_arguments(self, parser: argparse.ArgumentParser) -> None:
        ...

    def add_install_arguments(self, parser: argparse.ArgumentParser) -> None:
        ...

    def install(self, args: argparse.Namespace) -> InstallResultT:
        ...

    def emit_install_result(self, result: InstallResultT) -> None:
        ...

    def discover_targets(self) -> Sequence[TargetT]:
        ...

    def serialize_target(self, target: TargetT) -> JsonObject:
        ...

    def format_target(self, target: TargetT) -> str:
        ...

    def uninstall(self, args: argparse.Namespace) -> UninstallResultT:
        ...

    def emit_uninstall_result(self, result: UninstallResultT) -> None:
        ...

    def turn_off(self, args: argparse.Namespace) -> ActivationResultT:
        ...

    def turn_on(self, args: argparse.Namespace) -> ActivationResultT:
        ...

    def emit_activation_result(self, *, enabled: bool, result: ActivationResultT) -> None:
        ...

    def doctor(self, args: argparse.Namespace) -> DoctorReportT:
        ...

    def emit_doctor_report(self, report: DoctorReportT) -> None:
        ...

    def emit_status_report(self, report: DoctorReportT) -> None:
        ...

    def internal_commands(self) -> Sequence[HostInternalCommand]:
        ...

    def dispatch_passthrough(self, argv: list[str], *, forced: bool = False) -> int:
        ...

    def dispatch_lifecycle(self, command: str, argv: list[str], *, prog: str | None = None) -> int:
        ...

    def probe(self) -> HostAdapterProbe:
        ...


class ManagedHostCliAdapter(
    Generic[TargetT, InstallResultT, UninstallResultT, ActivationResultT, DoctorReportT]
):
    def __init__(
        self,
        delegate: HostCliDelegate[
            TargetT,
            InstallResultT,
            UninstallResultT,
            ActivationResultT,
            DoctorReportT,
        ],
    ) -> None:
        self._delegate = delegate
        self.name = delegate.name
        self.summary = delegate.summary
        self._command_dest = f'{self.name}_command'
        self._internal_commands = tuple(delegate.internal_commands())
        self.known_commands = tuple(command.name for command in self._internal_commands)

    def register_parser(self, subparsers: ParserSubcommands) -> None:
        host_parser = subparsers.add_parser(self.name, help=self.summary)
        host_subparsers = host_parser.add_subparsers(dest=self._command_dest)

        for internal_command in self._internal_commands:
            internal_command.register_parser(host_subparsers)

    def _configure_lifecycle_parser(self, command: str, parser: argparse.ArgumentParser) -> None:
        if command == 'install':
            if self._delegate.supported_profiles:
                parser.add_argument(
                    '--profile',
                    default=self._delegate.supported_profiles[0],
                    choices=self._delegate.supported_profiles,
                    help=f'Sheltron {self.name} safety profile',
                )
            self._delegate.add_target_arguments(parser)
            self._delegate.add_install_arguments(parser)
            if self._delegate.force_install_help is not None:
                parser.add_argument(
                    '--force',
                    action='store_true',
                    help=self._delegate.force_install_help,
                )
            return

        if command == 'targets':
            parser.add_argument(
                '--json',
                action='store_true',
                help=f'print discovered {self.name} targets as JSON',
            )
            return

        if command in {'uninstall', 'off', 'on', 'doctor', 'status'}:
            self._delegate.add_target_arguments(parser)
            return

        raise ValueError(f'Unsupported lifecycle command for {self.name}: {command}')

    def dispatch(self, args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
        command = getattr(args, self._command_dest)

        if command == 'install':
            result = self._delegate.install(args)
            self._delegate.emit_install_result(result)
            return 0

        if command == 'targets':
            targets = tuple(self._delegate.discover_targets())
            if args.json:
                print(json.dumps([self._delegate.serialize_target(target) for target in targets], indent=2))
                return 0
            if not targets:
                print(self._delegate.no_targets_message)
                return 1
            for target in targets:
                print(self._delegate.format_target(target))
            return 0

        if command == 'uninstall':
            result = self._delegate.uninstall(args)
            self._delegate.emit_uninstall_result(result)
            return 0

        if command == 'off':
            result = self._delegate.turn_off(args)
            self._delegate.emit_activation_result(enabled=False, result=result)
            return 0

        if command == 'on':
            result = self._delegate.turn_on(args)
            self._delegate.emit_activation_result(enabled=True, result=result)
            return 0

        if command == 'doctor':
            report = self._delegate.doctor(args)
            self._delegate.emit_doctor_report(report)
            return 0 if report.healthy else 1

        if command == 'status':
            report = self._delegate.doctor(args)
            self._delegate.emit_status_report(report)
            return 0 if report.healthy else 1

        for internal_command in self._internal_commands:
            if command == internal_command.name:
                return internal_command.dispatch(args, parser)

        parser.error(f'a {self.name} subcommand is required')
        return 2

    def dispatch_passthrough(self, argv: list[str], *, forced: bool = False) -> int:
        return self._delegate.dispatch_passthrough(argv, forced=forced)

    def dispatch_lifecycle(self, command: str, argv: list[str], *, prog: str | None = None) -> int:
        parser = argparse.ArgumentParser(prog=prog or f'sheltron {self.name} {command}')
        self._configure_lifecycle_parser(command, parser)
        args = parser.parse_args(argv)
        setattr(args, self._command_dest, command)
        return self.dispatch(args, parser)

    def uninstall_default(self) -> int:
        return self.dispatch_lifecycle('uninstall', [], prog=f'sheltron unlink {self.name}')

    def probe(self) -> HostAdapterProbe:
        return self._delegate.probe()


class UnavailableCliHostAdapter:
    known_commands: tuple[str, ...] = ()

    def __init__(self, *, name: str, summary: str, detail: str) -> None:
        self.name = name
        self.summary = summary
        self._detail = detail

    def register_parser(self, subparsers: ParserSubcommands) -> None:
        unavailable_parser = subparsers.add_parser(
            self.name,
            help=f'{self.summary} (currently unavailable)',
        )
        unavailable_parser.add_argument(
            'unavailable_args',
            nargs=argparse.REMAINDER,
            help=argparse.SUPPRESS,
        )

    def dispatch(self, _args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
        print(f'The bundled Sheltron `{self.name}` adapter is unavailable: {self._detail}')
        return 1

    def dispatch_passthrough(self, _argv: list[str], *, forced: bool = False) -> int:
        del forced
        print(f'The bundled Sheltron `{self.name}` adapter is unavailable: {self._detail}')
        return 1

    def dispatch_lifecycle(self, _command: str, _argv: list[str], *, prog: str | None = None) -> int:
        del prog
        print(f'The bundled Sheltron `{self.name}` adapter is unavailable: {self._detail}')
        return 1

    def uninstall_default(self) -> int:
        print(f'The bundled Sheltron `{self.name}` adapter is unavailable: {self._detail}')
        return 1

    def probe(self) -> HostAdapterProbe:
        return HostAdapterProbe(
            name=self.name,
            summary=self.summary,
            bundled=True,
            importable=False,
            detected_targets=0,
            detail=self._detail,
        )
