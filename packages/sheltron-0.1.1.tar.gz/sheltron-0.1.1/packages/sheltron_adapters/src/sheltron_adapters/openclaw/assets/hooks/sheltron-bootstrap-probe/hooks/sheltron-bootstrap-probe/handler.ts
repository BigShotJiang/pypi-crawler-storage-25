import { appendFileSync, mkdirSync, readFileSync, readdirSync, statSync } from "node:fs";
import os from "node:os";
import { dirname, join } from "node:path";

const LOG_PATH = join(os.homedir(), ".sheltron", "openclaw", "hook-events.jsonl");
const STATE_PATH = join(os.homedir(), ".sheltron", "openclaw", "install.json");
const PROTECTED_RUN_DIR = join(os.homedir(), ".sheltron", "openclaw", "protected-runs");

type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonObject | JsonValue[];
type JsonObject = { [key: string]: JsonValue };

type BridgeState = {
  bridge_url?: string;
  bridge_token?: string;
  enabled?: boolean;
};

type BridgeDecision = {
  decision?: string;
  reason?: string | null;
  hook_response?: JsonObject | null;
};

type ProcessInfo = {
  pid: number;
  parentPid: number;
  processGroupId: number;
  sessionId: number;
};

type ProtectedRunMarker = {
  pid?: number;
  processGroupId?: number;
  sessionId?: number;
};

let cachedState: BridgeState | null = null;
let cachedStateMtimeMs: number | null = null;

function isJsonValue(value: unknown): value is JsonValue {
  if (value === null) {
    return true;
  }
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return true;
  }
  if (Array.isArray(value)) {
    return value.every((item) => isJsonValue(item));
  }
  if (typeof value === "object") {
    return Object.values(value).every((item) => isJsonValue(item));
  }
  return false;
}

function asJsonObject(value: unknown): JsonObject | null {
  if (typeof value !== "object" || value === null || Array.isArray(value)) {
    return null;
  }
  return isJsonValue(value) ? value : null;
}

function jsonValueProp(value: JsonObject | null, key: string): JsonValue | undefined {
  return value?.[key];
}

function stringProp(value: JsonObject | null, key: string): string | undefined {
  const candidate = jsonValueProp(value, key);
  return typeof candidate === "string" ? candidate : undefined;
}

function booleanProp(value: JsonObject | null, key: string): boolean | undefined {
  const candidate = jsonValueProp(value, key);
  return typeof candidate === "boolean" ? candidate : undefined;
}

function numberProp(value: JsonObject | null, key: string): number | undefined {
  const candidate = jsonValueProp(value, key);
  return typeof candidate === "number" && Number.isFinite(candidate) ? candidate : undefined;
}

function stringArrayProp(value: JsonObject | null, key: string): string[] | null {
  const candidate = jsonValueProp(value, key);
  if (!Array.isArray(candidate) || !candidate.every((item): item is string => typeof item === "string")) {
    return null;
  }
  return candidate;
}

function parseBridgeState(value: unknown): BridgeState {
  const record = asJsonObject(value);
  return {
    bridge_url: stringProp(record, "bridge_url"),
    bridge_token: stringProp(record, "bridge_token"),
    enabled: booleanProp(record, "enabled"),
  };
}

function readProcessInfo(pid: number): ProcessInfo | null {
  try {
    const statText = readFileSync(`/proc/${pid}/stat`, "utf8");
    const commandEnd = statText.lastIndexOf(")");
    if (commandEnd < 0) {
      return null;
    }
    const fields = statText.slice(commandEnd + 2).trim().split(/\s+/);
    const parentPid = Number(fields[1]);
    const processGroupId = Number(fields[2]);
    const sessionId = Number(fields[3]);
    if (!Number.isFinite(parentPid) || !Number.isFinite(processGroupId) || !Number.isFinite(sessionId)) {
      return null;
    }
    return { pid, parentPid, processGroupId, sessionId };
  } catch {
    return null;
  }
}

function readProtectedRunMarkers(): ProtectedRunMarker[] {
  try {
    return readdirSync(PROTECTED_RUN_DIR)
      .filter((name) => name.endsWith(".json"))
      .map((name) => {
        const markerPath = join(PROTECTED_RUN_DIR, name);
        const record = asJsonObject(JSON.parse(readFileSync(markerPath, "utf8")));
        const filenamePid = Number.parseInt(name.replace(/\.json$/, ""), 10);
        return {
          pid: numberProp(record, "pid") ?? (Number.isFinite(filenamePid) ? filenamePid : undefined),
          processGroupId: numberProp(record, "process_group_id"),
          sessionId: numberProp(record, "session_id"),
        };
      });
  } catch {
    return [];
  }
}

function isDescendantOfProcess(markerPid: number): boolean {
  let currentPid = process.pid;
  const seen = new Set<number>();
  for (let depth = 0; depth < 64; depth += 1) {
    if (currentPid === markerPid) {
      return true;
    }
    if (seen.has(currentPid)) {
      return false;
    }
    seen.add(currentPid);
    const currentInfo = readProcessInfo(currentPid);
    if (!currentInfo || currentInfo.parentPid <= 0) {
      return false;
    }
    currentPid = currentInfo.parentPid;
  }
  return false;
}

function hasProtectedRunMarker(): boolean {
  const currentInfo = readProcessInfo(process.pid);
  for (const marker of readProtectedRunMarkers()) {
    if (marker.pid === process.pid) {
      return true;
    }
    if (currentInfo && marker.sessionId !== undefined && marker.sessionId === currentInfo.sessionId) {
      return true;
    }
    if (
      currentInfo &&
      marker.processGroupId !== undefined &&
      marker.processGroupId === currentInfo.processGroupId
    ) {
      return true;
    }
    if (marker.pid !== undefined && isDescendantOfProcess(marker.pid)) {
      return true;
    }
  }
  return false;
}

function shouldEnforce(state: BridgeState): boolean {
  return state.enabled === true || hasProtectedRunMarker();
}

function parseBridgeDecision(value: unknown): BridgeDecision {
  const record = asJsonObject(value);
  return {
    decision: stringProp(record, "decision"),
    reason: stringProp(record, "reason") ?? null,
    hook_response: asJsonObject(jsonValueProp(record, "hook_response")),
  };
}

function loadState(): BridgeState {
  try {
    const mtimeMs = statSync(STATE_PATH).mtimeMs;
    if (cachedState && cachedStateMtimeMs === mtimeMs) {
      return cachedState;
    }
    cachedStateMtimeMs = mtimeMs;
    cachedState = parseBridgeState(JSON.parse(readFileSync(STATE_PATH, "utf8")));
    return cachedState;
  } catch {
    cachedState = {};
    cachedStateMtimeMs = null;
    return cachedState;
  }
}

async function runBridge(payload: unknown): Promise<BridgeDecision> {
  const state = loadState();
  if (typeof state.bridge_url !== "string" || !state.bridge_url || typeof state.bridge_token !== "string" || !state.bridge_token) {
    return { decision: "deny", reason: "Sheltron OpenClaw bootstrap bridge is not configured." };
  }
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4000);
  let responseText = "";
  try {
    const response = await fetch(`${state.bridge_url.replace(/\/$/, "")}/bridge/agent-bootstrap`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${state.bridge_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    responseText = await response.text();
    if (!response.ok) {
      return { decision: "deny", reason: "Sheltron OpenClaw bootstrap bridge failed." };
    }
  } catch {
    return { decision: "deny", reason: "Sheltron OpenClaw bootstrap bridge failed." };
  } finally {
    clearTimeout(timeout);
  }
  try {
    return parseBridgeDecision(JSON.parse(responseText));
  } catch {
    return { decision: "deny", reason: "Sheltron OpenClaw bootstrap bridge returned invalid output." };
  }
}

export default async function handler(event: unknown): Promise<void> {
  if (!shouldEnforce(loadState())) {
    return;
  }
  const eventRecord = asJsonObject(event);
  const contextRecord = asJsonObject(jsonValueProp(eventRecord, "context"));
  const decision = await runBridge(eventRecord ?? {});
  const hookResponse = decision.hook_response;
  const filteredBootstrapFiles = stringArrayProp(hookResponse, "bootstrapFiles") ?? [];
  const droppedBootstrapFiles = stringArrayProp(hookResponse, "droppedBootstrapFiles") ?? [];
  const currentBootstrapFiles = stringArrayProp(contextRecord, "bootstrapFiles");

  if (decision.decision === "deny" && currentBootstrapFiles) {
    currentBootstrapFiles.splice(0, currentBootstrapFiles.length);
  }
  if (hookResponse && currentBootstrapFiles) {
    currentBootstrapFiles.splice(
      0,
      currentBootstrapFiles.length,
      ...filteredBootstrapFiles,
    );
  }

  mkdirSync(dirname(LOG_PATH), { recursive: true });
  appendFileSync(
    LOG_PATH,
    `${JSON.stringify({
      kind: "agent:bootstrap",
      observedAt: new Date().toISOString(),
      sessionKey: stringProp(eventRecord, "sessionKey") ?? null,
      bridgeDecision: decision.decision ?? null,
      bootstrapFiles: currentBootstrapFiles ?? [],
      droppedBootstrapFiles,
    })}\n`,
    "utf8",
  );
}
