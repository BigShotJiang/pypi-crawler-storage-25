from __future__ import annotations

from collections.abc import Iterator
import json
import os
import secrets
import shlex
import signal
import shutil
import subprocess
import sys
import time
from contextlib import ExitStack
from datetime import datetime, timezone
from enum import Enum
from importlib.resources import as_file, files
from pathlib import Path
from urllib.error import URLError
from urllib.request import Request, urlopen

from pydantic import BaseModel, ConfigDict, Field

from sheltron_adapters.tool_command import resolve_installed_sheltron_command
from sheltron_runtime import DoctorCheck, DoctorStatus

OPENCLAW_PROBE_PLUGIN_ID = 'sheltron-openclaw-probe'
OPENCLAW_BOOTSTRAP_PACKAGE_ID = 'sheltron-bootstrap-probe'
OPENCLAW_BOOTSTRAP_HOOK_NAME = 'sheltron-bootstrap-probe'
OPENCLAW_STATUS_TOOL_NAME = 'sheltron_status'
SUPPORTED_OPENCLAW_PROFILES = ('strict',)
SUPPORTED_OPENCLAW_INSTALL_MODES = ('direct', 'official')
_LEGACY_INSTALL_STATE_FIELDS = frozenset(
    {
        'plugin_source_path',
        'hook_package_source_path',
        'plugin_event_log_path',
        'hook_event_log_path',
    }
)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def default_openclaw_config_path() -> Path:
    return Path.home() / '.openclaw' / 'openclaw.json'


def default_openclaw_workspace_path() -> Path:
    return Path.home() / '.openclaw' / 'workspace'


def default_openclaw_install_state_path() -> Path:
    return Path.home() / '.sheltron' / 'openclaw' / 'install.json'


def default_openclaw_bridge_log_path() -> Path:
    return Path.home() / '.sheltron' / 'openclaw' / 'bridge-server.log'


class OpenClawInstallState(BaseModel):
    model_config = ConfigDict(extra='forbid')

    profile: str
    install_mode: str = 'official'
    enabled: bool = False
    installed_at: datetime = Field(default_factory=_utcnow)
    config_path: str
    workspace_path: str
    openclaw_command_path: str
    sheltron_python_path: str
    sheltron_command_path: str | None = None
    sheltron_bin_dir: str | None = None
    runtime_state_path: str = Field(default_factory=lambda: str(default_openclaw_install_state_path()))
    management_state_path: str | None = None
    bridge_url: str | None = None
    bridge_token: str | None = None
    bridge_server_pid: int | None = None
    bridge_server_state_path: str | None = None
    plugin_allow_added_by_sheltron: bool = False
    plugin_allow_field_existed: bool = False
    status_tool_policy_key: str | None = None
    status_tool_policy_entry_added_by_sheltron: bool = False
    status_tool_policy_field_existed: bool = False
    plugin_id: str = OPENCLAW_PROBE_PLUGIN_ID
    bootstrap_package_id: str = OPENCLAW_BOOTSTRAP_PACKAGE_ID
    bootstrap_hook_name: str = OPENCLAW_BOOTSTRAP_HOOK_NAME


class OpenClawInstallResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    state: OpenClawInstallState
    state_path: str
    restart_required: bool = True


class OpenClawUninstallResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    openclaw_command_path: str
    state_path: str
    restart_required: bool = True
    already_uninstalled: bool = False
    cleaned_host_artifacts: bool = False


class OpenClawProtectionState(str, Enum):
    NOT_INSTALLED = 'not-installed'
    READY = 'ready'
    ALWAYS_ON = 'always-on'
    BROKEN = 'broken'


class OpenClawDoctorReport(BaseModel):
    model_config = ConfigDict(extra='forbid')

    protection_state: OpenClawProtectionState
    checks: tuple[DoctorCheck, ...]

    @property
    def healthy(self) -> bool:
        return self.protection_state in {
            OpenClawProtectionState.READY,
            OpenClawProtectionState.ALWAYS_ON,
        }


class OpenClawEnableResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    state: OpenClawInstallState
    state_path: str
    restart_required: bool = True


class OpenClawDisableResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    state: OpenClawInstallState
    state_path: str
    restart_required: bool = True


class OpenClawInstallationTarget(BaseModel):
    model_config = ConfigDict(extra='forbid')

    command_path: str
    install_kind: str


def install_openclaw(
    *,
    profile: str = 'strict',
    install_mode: str = 'direct',
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
    force: bool = False,
) -> OpenClawInstallResult:
    _require_supported_profile(profile)
    _require_supported_install_mode(install_mode)
    resolved_command_path = _select_openclaw_install_command_path(openclaw_command_path)
    config_path = default_openclaw_config_path().expanduser().resolve(strict=False)
    workspace_path = default_openclaw_workspace_path().expanduser().resolve(strict=False)
    if not config_path.exists():
        raise FileNotFoundError(f'OpenClaw config not found: {config_path}')

    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    runtime_state_path = default_openclaw_install_state_path().expanduser().resolve(strict=False)
    existing_state_path = _existing_install_state_path(
        resolved_state_path=resolved_state_path,
        runtime_state_path=runtime_state_path,
    )
    if existing_state_path is not None:
        if not force:
            raise RuntimeError(
                f'Sheltron OpenClaw link state already exists: {existing_state_path}. '
                'Run `sheltron unlink openclaw` first or pass --force.'
            )
        uninstall_openclaw(
            openclaw_command_path=resolved_command_path,
            state_path=existing_state_path,
            missing_ok=True,
        )
    sheltron_command_path = _discover_sheltron_command_path()
    sheltron_bin_dir = sheltron_command_path.parent
    _cleanup_openclaw_host_artifacts(
        config_path=config_path,
        plugin_id=OPENCLAW_PROBE_PLUGIN_ID,
        bootstrap_package_id=OPENCLAW_BOOTSTRAP_PACKAGE_ID,
        bootstrap_hook_name=OPENCLAW_BOOTSTRAP_HOOK_NAME,
    )

    with ExitStack() as stack:
        plugin_source_path = stack.enter_context(as_file(_asset_dir('plugins', OPENCLAW_PROBE_PLUGIN_ID)))
        hook_package_source_path = stack.enter_context(
            as_file(_asset_dir('hooks', OPENCLAW_BOOTSTRAP_PACKAGE_ID))
        )
        if install_mode == 'official':
            install_args = ['plugins', 'install', str(plugin_source_path)]
            install_hook_args = ['plugins', 'install', str(hook_package_source_path)]
            if force:
                install_args.append('--force')
                install_hook_args.append('--force')
            try:
                _run_openclaw_command(resolved_command_path, install_hook_args, assume_yes=True)
                _run_openclaw_command(resolved_command_path, install_args, assume_yes=True)
            except RuntimeError as exc:
                _cleanup_openclaw_host_artifacts(
                    config_path=config_path,
                    plugin_id=OPENCLAW_PROBE_PLUGIN_ID,
                    bootstrap_package_id=OPENCLAW_BOOTSTRAP_PACKAGE_ID,
                    bootstrap_hook_name=OPENCLAW_BOOTSTRAP_HOOK_NAME,
                )
                raise RuntimeError(
                    f'{exc}\n'
                    '\n'
                    'Official OpenClaw plugin link failed. '
                    'You can retry with `sheltron link openclaw --link-mode direct` '
                    'to use the Sheltron-managed direct asset link path.'
                ) from exc
        else:
            _install_openclaw_host_artifacts(
                config_path=config_path,
                plugin_source_path=plugin_source_path,
                hook_package_source_path=hook_package_source_path,
                enabled=True,
            )
        plugin_allow_added_by_sheltron, plugin_allow_field_existed = _ensure_openclaw_plugin_allow_entry(
            config_path=config_path,
            plugin_id=OPENCLAW_PROBE_PLUGIN_ID,
        )
        (
            status_tool_policy_key,
            status_tool_policy_entry_added_by_sheltron,
            status_tool_policy_field_existed,
        ) = _ensure_openclaw_status_tool_allowed(config_path=config_path)

        state = OpenClawInstallState(
            profile=profile,
            install_mode=install_mode,
            config_path=str(config_path),
            workspace_path=str(workspace_path),
            openclaw_command_path=str(resolved_command_path),
            sheltron_python_path=str(_current_environment_python()),
            sheltron_command_path=str(sheltron_command_path),
            sheltron_bin_dir=str(sheltron_bin_dir),
            runtime_state_path=str(runtime_state_path),
            management_state_path=(
                str(resolved_state_path) if resolved_state_path != runtime_state_path else None
            ),
            plugin_allow_added_by_sheltron=plugin_allow_added_by_sheltron,
            plugin_allow_field_existed=plugin_allow_field_existed,
            status_tool_policy_key=status_tool_policy_key,
            status_tool_policy_entry_added_by_sheltron=status_tool_policy_entry_added_by_sheltron,
            status_tool_policy_field_existed=status_tool_policy_field_existed,
        )

    _write_install_state(state=state, resolved_state_path=resolved_state_path)
    return OpenClawInstallResult(
        state=state,
        state_path=str(resolved_state_path),
        restart_required=False,
    )


def uninstall_openclaw(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
    missing_ok: bool = True,
) -> OpenClawUninstallResult:
    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        cleaned = _cleanup_openclaw_host_artifacts(
            config_path=default_openclaw_config_path().expanduser().resolve(strict=False),
            plugin_id=OPENCLAW_PROBE_PLUGIN_ID,
            bootstrap_package_id=OPENCLAW_BOOTSTRAP_PACKAGE_ID,
            bootstrap_hook_name=OPENCLAW_BOOTSTRAP_HOOK_NAME,
        )
        if missing_ok:
            return OpenClawUninstallResult(
                openclaw_command_path=str(Path(openclaw_command_path).expanduser()) if openclaw_command_path else '',
                state_path=str(resolved_state_path),
                restart_required=cleaned,
                already_uninstalled=not cleaned,
                cleaned_host_artifacts=cleaned,
            )
        raise FileNotFoundError(f'Sheltron OpenClaw link state not found: {resolved_state_path}')

    resolved_command_path = (
        _normalize_command_path(openclaw_command_path)
        if openclaw_command_path is not None
        else Path(state.openclaw_command_path)
    )

    _stop_openclaw_bridge_server(state)
    if state.install_mode == 'official':
        _run_openclaw_command(
            resolved_command_path,
            ['hooks', 'disable', state.bootstrap_hook_name],
            check=False,
            assume_yes=True,
        )
        _run_openclaw_command(
            resolved_command_path,
            ['plugins', 'uninstall', state.plugin_id],
            check=False,
            assume_yes=True,
        )
    cleaned = _cleanup_openclaw_host_artifacts(
        config_path=Path(state.config_path).expanduser().resolve(strict=False),
        plugin_id=state.plugin_id,
        bootstrap_package_id=state.bootstrap_package_id,
        bootstrap_hook_name=state.bootstrap_hook_name,
        plugin_allow_added_by_sheltron=state.plugin_allow_added_by_sheltron,
        plugin_allow_field_existed=state.plugin_allow_field_existed,
        status_tool_policy_key=state.status_tool_policy_key,
        status_tool_policy_entry_added_by_sheltron=state.status_tool_policy_entry_added_by_sheltron,
        status_tool_policy_field_existed=state.status_tool_policy_field_existed,
    )

    _cleanup_install_artifacts(state, resolved_state_path=resolved_state_path)
    return OpenClawUninstallResult(
        openclaw_command_path=str(resolved_command_path),
        state_path=str(resolved_state_path),
        restart_required=cleaned,
        cleaned_host_artifacts=cleaned,
    )


def disable_openclaw(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> OpenClawDisableResult:
    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        raise FileNotFoundError(f'Sheltron OpenClaw link state not found: {resolved_state_path}')

    _stop_openclaw_bridge_server(state)
    state.enabled = False
    _write_install_state(state=state, resolved_state_path=resolved_state_path)
    return OpenClawDisableResult(state=state, state_path=str(resolved_state_path), restart_required=False)


def enable_openclaw(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> OpenClawEnableResult:
    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        raise FileNotFoundError(f'Sheltron OpenClaw link state not found: {resolved_state_path}')

    _refresh_state_sheltron_command(state)
    assets_refreshed = _refresh_openclaw_host_artifacts(
        config_path=Path(state.config_path).expanduser().resolve(strict=False)
    )
    _ensure_openclaw_bridge_server(state, resolved_state_path=resolved_state_path)
    try:
        _set_openclaw_host_artifacts_enabled(
            config_path=Path(state.config_path).expanduser().resolve(strict=False),
            plugin_id=state.plugin_id,
            bootstrap_package_id=state.bootstrap_package_id,
            bootstrap_hook_name=state.bootstrap_hook_name,
            enabled=True,
        )
    except Exception:
        _stop_openclaw_bridge_server(state)
        raise
    _record_status_tool_policy_update(state, _ensure_openclaw_status_tool_allowed(config_path=Path(state.config_path)))
    state.enabled = True
    _write_install_state(state=state, resolved_state_path=resolved_state_path)
    return OpenClawEnableResult(
        state=state,
        state_path=str(resolved_state_path),
        restart_required=assets_refreshed,
    )


def prepare_openclaw_protected_run(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> OpenClawInstallState:
    del openclaw_command_path
    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    if state is None:
        raise FileNotFoundError(f'Sheltron OpenClaw link state not found: {resolved_state_path}')
    _refresh_state_sheltron_command(state)
    _refresh_openclaw_host_artifacts(
        config_path=Path(state.config_path).expanduser().resolve(strict=False)
    )
    _ensure_openclaw_bridge_server(state, resolved_state_path=resolved_state_path)
    _set_openclaw_host_artifacts_enabled(
        config_path=Path(state.config_path).expanduser().resolve(strict=False),
        plugin_id=state.plugin_id,
        bootstrap_package_id=state.bootstrap_package_id,
        bootstrap_hook_name=state.bootstrap_hook_name,
        enabled=True,
    )
    _record_status_tool_policy_update(state, _ensure_openclaw_status_tool_allowed(config_path=Path(state.config_path)))
    _write_install_state(state=state, resolved_state_path=resolved_state_path)
    return state


def discover_openclaw_targets() -> tuple[OpenClawInstallationTarget, ...]:
    return tuple(_describe_openclaw_target(candidate) for candidate in _path_command_candidates('openclaw'))


def doctor_openclaw(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
) -> OpenClawDoctorReport:
    checks: list[DoctorCheck] = []
    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    state = _load_install_state(resolved_state_path)
    config_path = default_openclaw_config_path().expanduser().resolve(strict=False)
    plugin_installed = False
    plugin_asset_current = False
    plugin_enabled = False
    hook_installed = False
    bootstrap_package_installed = False
    bootstrap_asset_current = False
    bootstrap_package_enabled = False
    status_tool_allowed = False
    install_state_present = state is not None
    runtime_state_matches = False
    install_state_paths_match = False
    install_state_proof_ok = False
    sheltron_command_ok = False

    resolved_command_path = _resolve_openclaw_runtime_command_path(
        raw_path=openclaw_command_path,
        state=state,
    )

    if resolved_command_path is None:
        checks.append(
            DoctorCheck(
                name='openclaw_command',
                status=DoctorStatus.FAIL,
                detail='`openclaw` command not found on PATH.',
            )
        )
    else:
        checks.append(
            DoctorCheck(
                name='openclaw_command',
                status=DoctorStatus.OK,
                detail=f'OpenClaw command resolved to {resolved_command_path}.',
            )
        )

    if config_path.exists():
        checks.append(
            DoctorCheck(
                name='openclaw_config',
                status=DoctorStatus.OK,
                detail=f'OpenClaw config exists at {config_path}.',
            )
        )
    else:
        checks.append(
            DoctorCheck(
                name='openclaw_config',
                status=DoctorStatus.FAIL,
                detail=f'OpenClaw config not found at {config_path}.',
            )
        )

    if state is None:
        checks.append(
            DoctorCheck(
                name='install_state',
                status=DoctorStatus.WARN,
                detail=f'Sheltron OpenClaw link state not found at {resolved_state_path}.',
            )
        )
    else:
        checks.append(
            DoctorCheck(
                name='install_state',
                status=DoctorStatus.OK,
                detail=f'Install state found at {resolved_state_path}.',
            )
        )
        runtime_state_path = Path(state.runtime_state_path).expanduser().resolve(strict=False)
        runtime_state = _load_install_state(runtime_state_path)
        runtime_state_matches = runtime_state is not None and runtime_state.model_dump() == state.model_dump()
        install_state_paths_match = (
            Path(state.config_path).expanduser().resolve(strict=False) == config_path
            and resolved_command_path is not None
            and Path(state.openclaw_command_path).expanduser().resolve(strict=False) == resolved_command_path
        )
        checks.append(
            DoctorCheck(
                name='runtime_state',
                status=DoctorStatus.OK if runtime_state_matches else DoctorStatus.FAIL,
                detail=(
                    f'Runtime install state is present at {runtime_state_path} and matches the managed state.'
                    if runtime_state_matches
                    else f'Runtime install state is missing or stale at {runtime_state_path}.'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='install_state_paths_match',
                status=DoctorStatus.OK if install_state_paths_match else DoctorStatus.WARN,
                detail=(
                    'Install state matches the active OpenClaw command and config paths.'
                    if install_state_paths_match
                    else (
                        'Install state paths do not match the active OpenClaw command/config: '
                        f'state_command={Path(state.openclaw_command_path).expanduser().resolve(strict=False)} '
                        f'active_command={resolved_command_path} '
                        f'state_config={Path(state.config_path).expanduser().resolve(strict=False)} '
                        f'active_config={config_path}'
                    )
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='activation_state',
                status=DoctorStatus.OK,
                detail=(
                    'Persistent always-on activation is enabled.'
                    if state.enabled
                    else 'Persistent always-on activation is off.'
                ),
            )
        )
        if state.sheltron_command_path:
            sheltron_command = Path(state.sheltron_command_path).expanduser().resolve(strict=False)
            sheltron_command_ok = sheltron_command.exists()
            checks.append(
                DoctorCheck(
                    name='sheltron_command',
                    status=DoctorStatus.OK if sheltron_command_ok else DoctorStatus.FAIL,
                    detail=f'Sheltron command: {sheltron_command}',
                )
            )
        else:
            sheltron_command_ok = True
            checks.append(
                DoctorCheck(
                    name='sheltron_command',
                    status=DoctorStatus.WARN,
                    detail='Install state predates global Sheltron command pinning; run `sheltron on openclaw` to refresh it.',
                )
            )
        if state.sheltron_bin_dir:
            sheltron_bin_dir = Path(state.sheltron_bin_dir).expanduser().resolve(strict=False)
            checks.append(
                DoctorCheck(
                    name='sheltron_bin_dir',
                    status=DoctorStatus.OK if sheltron_bin_dir.exists() else DoctorStatus.WARN,
                    detail=f'Sheltron bin dir: {sheltron_bin_dir}',
                )
            )
        bridge_server_running = _openclaw_bridge_server_running(state)
        checks.append(
            DoctorCheck(
                name='bridge_server',
                status=DoctorStatus.OK if bridge_server_running else DoctorStatus.WARN,
                detail=(
                    f'OpenClaw bridge server is reachable at {state.bridge_url}.'
                    if bridge_server_running
                    else 'OpenClaw bridge server is not currently reachable.'
                ),
            )
        )
        install_state_proof_ok = runtime_state_matches and install_state_paths_match and sheltron_command_ok

    config_payload = _load_openclaw_config_payload(config_path) if config_path.exists() else None
    if config_payload is not None:
        plugin_record = _openclaw_plugin_install_record(config_payload, OPENCLAW_PROBE_PLUGIN_ID)
        plugin_install_path = _openclaw_install_path_from_record(
            plugin_record,
            default_openclaw_plugin_install_path(OPENCLAW_PROBE_PLUGIN_ID),
        )
        plugin_installed = plugin_install_path.exists() and (plugin_install_path / 'openclaw.plugin.json').exists()
        plugin_asset_current = plugin_installed and _openclaw_asset_source_matches_install(
            _asset_dir('plugins', OPENCLAW_PROBE_PLUGIN_ID),
            plugin_install_path,
        )
        plugin_enabled = _openclaw_plugin_enabled(config_payload, OPENCLAW_PROBE_PLUGIN_ID)
        status_tool_allowed = _openclaw_status_tool_allowed(config_payload)
        checks.append(
            DoctorCheck(
                name='plugin_probe_installed',
                status=DoctorStatus.OK if plugin_installed else DoctorStatus.FAIL,
                detail=(
                    f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` is installed.'
                    if plugin_installed
                    else f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` is not installed.'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='plugin_probe_asset_current',
                status=DoctorStatus.OK if plugin_asset_current else DoctorStatus.WARN,
                detail=(
                    f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` matches the current Sheltron asset.'
                    if plugin_asset_current
                    else (
                        f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` is stale or missing. '
                        'Run `sheltron on openclaw` or a protected `sheltron openclaw ...` command to refresh it.'
                    )
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='plugin_probe_enabled',
                status=DoctorStatus.OK if plugin_installed and plugin_enabled else DoctorStatus.WARN,
                detail=(
                    f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` is not currently installed, so it cannot be enabled.'
                    if not plugin_installed
                    else
                    f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` is enabled as a dormant runtime shim.'
                    if plugin_enabled
                    else f'Native plugin `{OPENCLAW_PROBE_PLUGIN_ID}` is installed but currently disabled.'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='status_tool_allowed',
                status=DoctorStatus.OK if status_tool_allowed else DoctorStatus.WARN,
                detail=(
                    f'OpenClaw tool policy allows `{OPENCLAW_STATUS_TOOL_NAME}`.'
                    if status_tool_allowed
                    else (
                        f'OpenClaw tool policy does not currently allow `{OPENCLAW_STATUS_TOOL_NAME}`; '
                        'Sheltron status prompts may fall back to unreliable process/config checks.'
                    )
                ),
            )
        )

        bootstrap_record = _openclaw_hook_install_record(config_payload, OPENCLAW_BOOTSTRAP_PACKAGE_ID)
        hook_install_path = _openclaw_install_path_from_record(
            bootstrap_record,
            default_openclaw_hook_install_path(OPENCLAW_BOOTSTRAP_PACKAGE_ID),
        )
        bootstrap_package_installed = hook_install_path.exists() and (hook_install_path / 'package.json').exists()
        bootstrap_asset_current = bootstrap_package_installed and _openclaw_asset_source_matches_install(
            _asset_dir('hooks', OPENCLAW_BOOTSTRAP_PACKAGE_ID),
            hook_install_path,
        )
        bootstrap_package_enabled = _openclaw_hook_enabled(config_payload, OPENCLAW_BOOTSTRAP_HOOK_NAME)
        hook_installed = (
            bootstrap_package_installed
            and (hook_install_path / 'hooks' / OPENCLAW_BOOTSTRAP_HOOK_NAME / 'HOOK.md').exists()
            and (hook_install_path / 'hooks' / OPENCLAW_BOOTSTRAP_HOOK_NAME / 'handler.ts').exists()
        )
        checks.append(
            DoctorCheck(
                name='bootstrap_package_installed',
                status=DoctorStatus.OK if bootstrap_package_installed else DoctorStatus.FAIL,
                detail=(
                    f'Bootstrap package `{OPENCLAW_BOOTSTRAP_PACKAGE_ID}` is installed.'
                    if bootstrap_package_installed
                    else f'Bootstrap package `{OPENCLAW_BOOTSTRAP_PACKAGE_ID}` is not installed.'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='bootstrap_package_asset_current',
                status=DoctorStatus.OK if bootstrap_asset_current else DoctorStatus.WARN,
                detail=(
                    f'Bootstrap package `{OPENCLAW_BOOTSTRAP_PACKAGE_ID}` matches the current Sheltron asset.'
                    if bootstrap_asset_current
                    else (
                        f'Bootstrap package `{OPENCLAW_BOOTSTRAP_PACKAGE_ID}` is stale or missing. '
                        'Run `sheltron on openclaw` or a protected `sheltron openclaw ...` command to refresh it.'
                    )
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='bootstrap_hook_installed',
                status=DoctorStatus.OK if hook_installed else DoctorStatus.FAIL,
                detail=(
                    f'Hook `{OPENCLAW_BOOTSTRAP_HOOK_NAME}` is discoverable.'
                    if hook_installed
                    else f'Hook `{OPENCLAW_BOOTSTRAP_HOOK_NAME}` is not discoverable.'
                ),
            )
        )
        checks.append(
            DoctorCheck(
                name='bootstrap_hook_enabled',
                status=DoctorStatus.OK
                if bootstrap_package_installed and hook_installed and bootstrap_package_enabled
                else DoctorStatus.WARN,
                detail=(
                    f'Hook `{OPENCLAW_BOOTSTRAP_HOOK_NAME}` is not currently installed, so it cannot be enabled.'
                    if not bootstrap_package_installed or not hook_installed
                    else
                    f'Hook `{OPENCLAW_BOOTSTRAP_HOOK_NAME}` is enabled as a dormant runtime shim through bootstrap package `{OPENCLAW_BOOTSTRAP_PACKAGE_ID}`.'
                    if bootstrap_package_enabled
                    else f'Hook `{OPENCLAW_BOOTSTRAP_HOOK_NAME}` is installed but its owning bootstrap package is currently disabled.'
                ),
            )
        )

    expected_always_on = state.enabled if state is not None else False
    install_contract_issues: list[str] = []
    if state is None:
        if (
            plugin_installed
            or hook_installed
            or plugin_enabled
            or bootstrap_package_installed
            or bootstrap_package_enabled
        ):
            install_contract_issues.append(
                'OpenClaw plugin or hook assets are present without matching Sheltron install state'
            )
    elif not install_state_proof_ok:
        if not runtime_state_matches:
            install_contract_issues.append('runtime install state is missing or stale')
        if not install_state_paths_match:
            install_contract_issues.append('install state paths do not match the active OpenClaw command and config')
    else:
        if not plugin_installed:
            install_contract_issues.append('managed OpenClaw plugin is not installed')
        if not plugin_asset_current:
            install_contract_issues.append('managed OpenClaw plugin asset is stale')
        if not bootstrap_package_installed:
            install_contract_issues.append('managed OpenClaw bootstrap package is not installed')
        if not bootstrap_asset_current:
            install_contract_issues.append('managed OpenClaw bootstrap package asset is stale')
        if not hook_installed:
            install_contract_issues.append('managed OpenClaw bootstrap hook is not installed')
        if not status_tool_allowed:
            install_contract_issues.append('managed OpenClaw status tool is not allowed by OpenClaw tool policy')
        if expected_always_on:
            if not plugin_enabled:
                install_contract_issues.append('always-on activation is enabled but the native plugin is not enabled')
            if not bootstrap_package_enabled:
                install_contract_issues.append('always-on activation is enabled but the bootstrap package is not enabled')
            if not _openclaw_bridge_server_running(state):
                install_contract_issues.append('always-on activation is enabled but the OpenClaw bridge server is not reachable')
        else:
            if not plugin_enabled:
                install_contract_issues.append('dormant runtime shim is not loadable because the native plugin is disabled')
            if not bootstrap_package_enabled:
                install_contract_issues.append('dormant runtime shim is not loadable because the bootstrap package is disabled')

    openclaw_bridge_ready = (
        install_state_present
        and state is not None
        and install_state_proof_ok
        and plugin_installed
        and bootstrap_package_installed
        and hook_installed
        and not install_contract_issues
    )
    checks.append(
        DoctorCheck(
            name='authority_scope',
            status=DoctorStatus.OK if openclaw_bridge_ready else DoctorStatus.WARN,
            detail=(
                'OpenClaw hook assets are installed and dormant. Use `sheltron on openclaw` to make plain '
                '`openclaw ...` enforce Sheltron globally; use `sheltron openclaw ...` for a protected run.'
                if openclaw_bridge_ready and state is not None and not state.enabled
                else 'OpenClaw now routes `before_tool_call`, `message_sending`, bootstrap filtering, '
                'session send/spawn seams, and tool-mediated durable-memory writes through the Sheltron '
                'bridge. Persisted tool-result hardening now runs locally inside the plugin because '
                'OpenClaw requires that hook to stay synchronous. `before_prompt_build` remains advisory-only.'
                if openclaw_bridge_ready
                else 'OpenClaw hook assets are not currently in the expected Sheltron lifecycle state.'
            ),
        )
    )
    checks.append(
        DoctorCheck(
            name='install_contract',
            status=DoctorStatus.FAIL if install_contract_issues else DoctorStatus.OK,
            detail=(
                'Sheltron OpenClaw install contract is consistent.'
                if not install_contract_issues
                else '; '.join(install_contract_issues)
            ),
        )
    )
    checks.append(
        DoctorCheck(
            name='live_runtime_proof',
            status=DoctorStatus.WARN,
            detail=(
                'Deterministic bridge tests, asset-runtime tests, and the real-command smoke lane are in place, '
                'but real live OpenClaw session hook proof is still a recommended validation step.'
            ),
        )
    )

    return OpenClawDoctorReport(
        protection_state=_infer_protection_state(
            install_state_present=install_state_present,
            install_state_proof_ok=install_state_proof_ok,
            plugin_installed=plugin_installed,
            plugin_enabled=plugin_enabled,
            bootstrap_package_installed=bootstrap_package_installed,
            bootstrap_package_enabled=bootstrap_package_enabled,
            hook_installed=hook_installed,
            install_contract_ok=not install_contract_issues,
            expected_always_on=expected_always_on,
        ),
        checks=tuple(checks),
    )


def _infer_protection_state(
    *,
    install_state_present: bool,
    install_state_proof_ok: bool,
    plugin_installed: bool,
    plugin_enabled: bool,
    bootstrap_package_installed: bool,
    bootstrap_package_enabled: bool,
    hook_installed: bool,
    install_contract_ok: bool,
    expected_always_on: bool,
) -> OpenClawProtectionState:
    if not install_state_present:
        if (
            plugin_installed
            or hook_installed
            or plugin_enabled
            or bootstrap_package_installed
            or bootstrap_package_enabled
        ):
            return OpenClawProtectionState.BROKEN
        return OpenClawProtectionState.NOT_INSTALLED
    if not install_state_proof_ok or not install_contract_ok:
        return OpenClawProtectionState.BROKEN
    if expected_always_on:
        return OpenClawProtectionState.ALWAYS_ON
    return OpenClawProtectionState.READY


def _require_supported_profile(profile: str) -> None:
    if profile not in SUPPORTED_OPENCLAW_PROFILES:
        supported = ', '.join(SUPPORTED_OPENCLAW_PROFILES)
        raise ValueError(f'Unsupported OpenClaw profile `{profile}`. Supported profiles: {supported}.')


def _require_supported_install_mode(install_mode: str) -> None:
    if install_mode not in SUPPORTED_OPENCLAW_INSTALL_MODES:
        supported = ', '.join(SUPPORTED_OPENCLAW_INSTALL_MODES)
        raise ValueError(
            f'Unsupported OpenClaw link mode `{install_mode}`. Supported link modes: {supported}.'
        )


def _asset_dir(*parts: str):
    resource = files('sheltron_adapters.openclaw').joinpath('assets')
    for part in parts:
        resource = resource.joinpath(part)
    return resource


def _normalize_command_path(raw_path: str | Path) -> Path:
    return Path(raw_path).expanduser().resolve(strict=False)


def _current_environment_python() -> Path:
    scripts_dir = 'Scripts' if os.name == 'nt' else 'bin'
    candidate_names = ('python.exe',) if os.name == 'nt' else ('python', 'python3')
    for candidate_name in candidate_names:
        candidate = Path(sys.prefix) / scripts_dir / candidate_name
        if candidate.exists():
            return candidate.expanduser()
    return Path(sys.executable).expanduser()


def _discover_sheltron_command_path() -> Path:
    return resolve_installed_sheltron_command().command_path


def _refresh_state_sheltron_command(state: OpenClawInstallState) -> None:
    command_path = _discover_sheltron_command_path()
    state.sheltron_command_path = str(command_path)
    state.sheltron_bin_dir = str(command_path.parent)


def _select_openclaw_install_command_path(raw_path: str | Path | None) -> Path:
    if raw_path is not None:
        resolved = _normalize_command_path(raw_path)
    else:
        targets = _preferred_openclaw_targets(discover_openclaw_targets())
        if not targets:
            raise FileNotFoundError(
                '`openclaw` command not found on PATH. Install OpenClaw, fix PATH, or rerun with an explicit command path, for example:\n'
                '  sheltron link openclaw --openclaw-command /path/to/openclaw'
            )
        if len(targets) > 1:
            choices = '\n'.join(
                f'  sheltron link openclaw --openclaw-command {shlex.quote(target.command_path)}'
                for target in targets
            )
            details = '\n'.join(f'- {target.command_path} ({target.install_kind})' for target in targets)
            raise RuntimeError(
                'Multiple OpenClaw installations were found. Choose one explicit target and rerun one of:\n'
                f'{choices}\n'
                '\n'
                'Detected targets:\n'
                f'{details}'
            )
        resolved = Path(targets[0].command_path)
    if not resolved.exists():
        raise FileNotFoundError(f'OpenClaw command not found: {resolved}')
    return resolved


def _resolve_openclaw_runtime_command_path(
    *,
    raw_path: str | Path | None,
    state: OpenClawInstallState | None,
) -> Path | None:
    if raw_path is not None:
        return _normalize_command_path(raw_path)
    if state is not None:
        return Path(state.openclaw_command_path).expanduser().resolve(strict=False)
    targets = _preferred_openclaw_targets(discover_openclaw_targets())
    if not targets:
        return None
    if len(targets) > 1:
        raise RuntimeError(
            'Multiple OpenClaw installations were found. Run `sheltron targets openclaw` and rerun with '
            '`--openclaw-command <path>`.'
        )
    return Path(targets[0].command_path)


def _path_command_candidates(command: str) -> tuple[Path, ...]:
    candidates: list[Path] = []
    seen: set[Path] = set()
    for raw_dir in os.environ.get('PATH', '').split(os.pathsep):
        if not raw_dir:
            continue
        candidate = _normalize_command_path(Path(raw_dir) / command)
        if candidate in seen:
            continue
        if candidate.exists():
            seen.add(candidate)
            candidates.append(candidate)
    return tuple(candidates)


def _describe_openclaw_target(command_path: Path) -> OpenClawInstallationTarget:
    environment_root = command_path.resolve(strict=False).parent.parent
    install_state = _load_install_state(default_openclaw_install_state_path().expanduser().resolve(strict=False))
    if install_state is not None and _normalize_command_path(command_path) == Path(install_state.openclaw_command_path):
        install_kind = 'managed-plugin'
    elif '/.local/share/uv/tools/' in str(environment_root) or '/uv/tools/' in str(environment_root):
        install_kind = 'uv-tool'
    elif environment_root.name == '.venv' or (environment_root / 'pyvenv.cfg').exists():
        install_kind = 'pip-venv'
    else:
        install_kind = 'unknown'
    return OpenClawInstallationTarget(command_path=str(command_path), install_kind=install_kind)


def _preferred_openclaw_targets(
    targets: tuple[OpenClawInstallationTarget, ...],
) -> tuple[OpenClawInstallationTarget, ...]:
    repo_venv_root = _active_repo_venv_root()
    if repo_venv_root is None or len(targets) <= 1:
        return targets
    filtered = tuple(target for target in targets if not _is_within(Path(target.command_path), repo_venv_root))
    return filtered or targets


def _active_repo_venv_root() -> Path | None:
    current_env_root = _normalize_command_path(sys.executable).parent.parent
    repo_venv_root = _normalize_command_path(Path.cwd() / '.venv')
    if current_env_root == repo_venv_root:
        return repo_venv_root
    return None


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def _run_openclaw_command(
    command_path: Path,
    args: list[str],
    *,
    check: bool = True,
    assume_yes: bool = False,
) -> subprocess.CompletedProcess[str]:
    command = [str(command_path), *(('--yes',) if assume_yes else ()), *args]
    completed = subprocess.run(
        command,
        check=False,
        capture_output=True,
        text=True,
        stdin=subprocess.DEVNULL,
    )
    if assume_yes and completed.returncode != 0 and _openclaw_unknown_yes_option(completed):
        command = [str(command_path), *args]
        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
        )
    if check and completed.returncode != 0:
        stderr = completed.stderr.strip()
        stdout = completed.stdout.strip()
        detail = stderr or stdout or f'exit status {completed.returncode}'
        joined = ' '.join(command)
        raise RuntimeError(f'OpenClaw command failed: {joined}\n{detail}')
    return completed


def _openclaw_unknown_yes_option(completed: subprocess.CompletedProcess[str]) -> bool:
    stderr = completed.stderr or ''
    stdout = completed.stdout or ''
    combined = f'{stderr}\n{stdout}'
    return "unknown option '--yes'" in combined


def _try_openclaw_json_command(command_path: Path, args: list[str]) -> tuple[object | None, str | None]:
    completed = _run_openclaw_command(command_path, args, check=False)
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip() or f'exit status {completed.returncode}'
        return None, detail
    raw = completed.stdout.strip()
    if raw == '':
        return None, 'command returned no JSON output'
    try:
        return json.loads(raw), None
    except json.JSONDecodeError as exc:
        return None, f'invalid JSON output: {exc}'


def _find_named_record(payload: object, expected_name: str) -> dict[str, object] | None:
    for candidate in _iter_records(payload):
        for key in ('name', 'id', 'pluginId', 'hook', 'package', 'slug'):
            value = candidate.get(key)
            if value == expected_name:
                return candidate
    return None


def _iter_records(payload: object) -> Iterator[dict[str, object]]:
    if isinstance(payload, dict):
        yield payload
        for value in payload.values():
            yield from _iter_records(value)
    elif isinstance(payload, list):
        for item in payload:
            yield from _iter_records(item)


def _extract_enabled_flag(payload: object) -> bool | None:
    for candidate in _iter_records(payload):
        for key in ('enabled', 'active', 'loaded', 'ready'):
            value = candidate.get(key)
            if isinstance(value, bool):
                return value
        state = candidate.get('state')
        if isinstance(state, str):
            lowered = state.lower()
            if lowered in {'enabled', 'active', 'loaded', 'ready'}:
                return True
            if lowered in {'disabled', 'inactive'}:
                return False
    return None


def _load_install_state(state_path: Path) -> OpenClawInstallState | None:
    if not state_path.exists():
        return None
    payload = json.loads(state_path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError(f'Invalid OpenClaw link state payload in {state_path}: expected JSON object.')
    normalized_payload = {
        key: value
        for key, value in payload.items()
        if key not in _LEGACY_INSTALL_STATE_FIELDS
    }
    return OpenClawInstallState.model_validate(normalized_payload)


def _existing_install_state_path(*, resolved_state_path: Path, runtime_state_path: Path) -> Path | None:
    if _load_install_state(resolved_state_path) is not None:
        return resolved_state_path
    if runtime_state_path != resolved_state_path and _load_install_state(runtime_state_path) is not None:
        return runtime_state_path
    return None


def _write_install_state(*, state: OpenClawInstallState, resolved_state_path: Path) -> None:
    payload = state.model_dump_json(indent=2)
    runtime_state_path = Path(state.runtime_state_path).expanduser().resolve(strict=False)
    runtime_state_path.parent.mkdir(parents=True, exist_ok=True)
    runtime_state_path.write_text(payload, encoding='utf-8')
    if resolved_state_path != runtime_state_path:
        resolved_state_path.parent.mkdir(parents=True, exist_ok=True)
        resolved_state_path.write_text(payload, encoding='utf-8')


def _cleanup_install_artifacts(state: OpenClawInstallState, *, resolved_state_path: Path) -> None:
    paths = {
        resolved_state_path,
        Path(state.runtime_state_path).expanduser().resolve(strict=False),
    }
    if state.management_state_path is not None:
        paths.add(Path(state.management_state_path).expanduser().resolve(strict=False))
    for path in paths:
        if path.exists():
            path.unlink()


def _cleanup_openclaw_host_artifacts(
    *,
    config_path: Path,
    plugin_id: str,
    bootstrap_package_id: str,
    bootstrap_hook_name: str,
    plugin_allow_added_by_sheltron: bool = False,
    plugin_allow_field_existed: bool = False,
    status_tool_policy_key: str | None = None,
    status_tool_policy_entry_added_by_sheltron: bool = False,
    status_tool_policy_field_existed: bool = False,
) -> bool:
    config_payload = _load_openclaw_config_payload(config_path)
    plugin_install_path = default_openclaw_plugin_install_path(plugin_id)
    hook_install_path = default_openclaw_hook_install_path(bootstrap_package_id)
    changed = False

    if config_payload is not None:
        plugins_section = _dict_field(config_payload, 'plugins')
        plugin_entries = _dict_field(plugins_section, 'entries')
        plugin_installs = _dict_field(plugins_section, 'installs')
        for key in {plugin_id, bootstrap_package_id}:
            plugin_record = plugin_installs.pop(key, None)
            if isinstance(plugin_record, dict):
                install_path = plugin_record.get('installPath')
                if isinstance(install_path, str) and install_path.strip() and key == plugin_id:
                    plugin_install_path = Path(install_path).expanduser().resolve(strict=False)
                changed = True
            if plugin_entries.pop(key, None) is not None:
                changed = True

        hooks_section = _dict_field(config_payload, 'hooks')
        hooks_internal = _dict_field(hooks_section, 'internal')
        hook_entries = _dict_field(hooks_internal, 'entries')
        hook_installs = _dict_field(hooks_internal, 'installs')
        for key in {bootstrap_package_id, bootstrap_hook_name}:
            hook_record = hook_installs.pop(key, None)
            if isinstance(hook_record, dict):
                install_path = hook_record.get('installPath')
                if isinstance(install_path, str) and install_path.strip():
                    hook_install_path = Path(install_path).expanduser().resolve(strict=False)
                changed = True
            if hook_entries.pop(key, None) is not None:
                changed = True

        if plugin_allow_added_by_sheltron:
            plugins_allow = _string_list_field(plugins_section, 'allow')
            next_plugins_allow = [entry for entry in plugins_allow if entry != plugin_id]
            if next_plugins_allow != plugins_allow:
                changed = True
                if next_plugins_allow or plugin_allow_field_existed:
                    plugins_section['allow'] = next_plugins_allow
                else:
                    plugins_section.pop('allow', None)

        if _remove_openclaw_status_tool_policy_entry(
            config_payload,
            policy_key=status_tool_policy_key,
            entry_added_by_sheltron=status_tool_policy_entry_added_by_sheltron,
            field_existed=status_tool_policy_field_existed,
        ):
            changed = True

        if changed:
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(json.dumps(config_payload, indent=2) + '\n', encoding='utf-8')

    removed_plugin_path = _remove_openclaw_install_path(plugin_install_path)
    removed_hook_path = _remove_openclaw_install_path(hook_install_path)
    return changed or removed_plugin_path or removed_hook_path


def _install_openclaw_host_artifacts(
    *,
    config_path: Path,
    plugin_source_path: Path,
    hook_package_source_path: Path,
    enabled: bool,
) -> None:
    plugin_install_path = default_openclaw_plugin_install_path(OPENCLAW_PROBE_PLUGIN_ID)
    hook_install_path = default_openclaw_hook_install_path(OPENCLAW_BOOTSTRAP_PACKAGE_ID)
    _copy_openclaw_install_path(plugin_source_path, plugin_install_path)
    _copy_openclaw_install_path(hook_package_source_path, hook_install_path)

    config_payload = _load_openclaw_config_payload(config_path)
    if config_payload is None:
        raise FileNotFoundError(f'OpenClaw config not found: {config_path}')
    installed_at = _utcnow().isoformat().replace('+00:00', 'Z')

    plugins_section = _dict_field(config_payload, 'plugins')
    plugin_entries = _dict_field(plugins_section, 'entries')
    plugin_installs = _dict_field(plugins_section, 'installs')
    plugin_entries[OPENCLAW_PROBE_PLUGIN_ID] = {
        'enabled': enabled and plugins_section.get('enabled') is not False
    }
    plugin_installs[OPENCLAW_PROBE_PLUGIN_ID] = {
        'source': 'path',
        'sourcePath': str(plugin_source_path),
        'installPath': str(plugin_install_path),
        'version': _openclaw_package_version(plugin_source_path),
        'installedAt': installed_at,
    }

    hooks_section = _dict_field(config_payload, 'hooks')
    hooks_internal = _dict_field(hooks_section, 'internal')
    hooks_internal.setdefault('enabled', True)
    hook_entries = _dict_field(hooks_internal, 'entries')
    hook_installs = _dict_field(hooks_internal, 'installs')
    hook_entries[OPENCLAW_BOOTSTRAP_HOOK_NAME] = {
        'enabled': enabled and hooks_internal.get('enabled') is not False
    }
    hook_installs[OPENCLAW_BOOTSTRAP_PACKAGE_ID] = {
        'hooks': [OPENCLAW_BOOTSTRAP_HOOK_NAME],
        'source': 'path',
        'sourcePath': str(hook_package_source_path),
        'installPath': str(hook_install_path),
        'version': _openclaw_package_version(hook_package_source_path),
        'installedAt': installed_at,
    }
    _write_openclaw_config_payload(config_path, config_payload)


def _refresh_openclaw_host_artifacts(*, config_path: Path) -> bool:
    config_payload = _load_openclaw_config_payload(config_path)
    if config_payload is None:
        raise FileNotFoundError(f'OpenClaw config not found: {config_path}')

    plugin_record = _openclaw_plugin_install_record(config_payload, OPENCLAW_PROBE_PLUGIN_ID)
    plugin_install_path = _openclaw_install_path_from_record(
        plugin_record,
        default_openclaw_plugin_install_path(OPENCLAW_PROBE_PLUGIN_ID),
    )
    hook_record = _openclaw_hook_install_record(config_payload, OPENCLAW_BOOTSTRAP_PACKAGE_ID)
    hook_install_path = _openclaw_install_path_from_record(
        hook_record,
        default_openclaw_hook_install_path(OPENCLAW_BOOTSTRAP_PACKAGE_ID),
    )

    with ExitStack() as stack:
        plugin_source_path = stack.enter_context(as_file(_asset_dir('plugins', OPENCLAW_PROBE_PLUGIN_ID)))
        hook_package_source_path = stack.enter_context(
            as_file(_asset_dir('hooks', OPENCLAW_BOOTSTRAP_PACKAGE_ID))
        )
        plugin_refreshed = _sync_openclaw_install_path(plugin_source_path, plugin_install_path)
        hook_refreshed = _sync_openclaw_install_path(hook_package_source_path, hook_install_path)
    return plugin_refreshed or hook_refreshed


def _set_openclaw_host_artifacts_enabled(
    *,
    config_path: Path,
    plugin_id: str,
    bootstrap_package_id: str,
    bootstrap_hook_name: str,
    enabled: bool,
) -> None:
    config_payload = _load_openclaw_config_payload(config_path)
    if config_payload is None:
        raise FileNotFoundError(f'OpenClaw config not found: {config_path}')

    _set_openclaw_plugin_enabled_in_config(config_payload, plugin_id=plugin_id, enabled=enabled)
    _set_openclaw_hook_enabled_in_config(
        config_payload,
        hook_name=bootstrap_hook_name,
        enabled=enabled,
    )

    _write_openclaw_config_payload(config_path, config_payload)


def _set_openclaw_plugin_enabled_in_config(
    config_payload: dict[str, object],
    *,
    plugin_id: str,
    enabled: bool,
) -> None:
    plugins_section = _dict_field(config_payload, 'plugins')
    plugin_entries = _dict_field(plugins_section, 'entries')

    if enabled:
        if plugins_section.get('enabled') is False:
            return
        plugin_denylist = _string_list_field(plugins_section, 'deny')
        if plugin_id in plugin_denylist:
            return
        plugin_entry = _dict_field(plugin_entries, plugin_id)
        plugin_entry['enabled'] = True
        plugins_section['allow'] = _ensure_string_list_contains(
            _string_list_field(plugins_section, 'allow'),
            plugin_id,
        )
        return

    plugin_entry = _dict_field(plugin_entries, plugin_id)
    plugin_entry['enabled'] = False


def _set_openclaw_hook_enabled_in_config(
    config_payload: dict[str, object],
    *,
    hook_name: str,
    enabled: bool,
) -> None:
    hooks_section = _dict_field(config_payload, 'hooks')
    hooks_internal = _dict_field(hooks_section, 'internal')
    hook_entries = _dict_field(hooks_internal, 'entries')
    hook_entry = _dict_field(hook_entries, hook_name)
    hook_entry['enabled'] = enabled
    if enabled:
        hooks_internal['enabled'] = True


def _load_openclaw_config_payload(config_path: Path) -> dict[str, object] | None:
    if not config_path.exists():
        return None
    payload = json.loads(config_path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        raise ValueError(f'Invalid OpenClaw config payload in {config_path}: expected JSON object.')
    return payload


def _write_openclaw_config_payload(config_path: Path, payload: dict[str, object]) -> None:
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(payload, indent=2) + '\n', encoding='utf-8')


def default_openclaw_plugin_install_path(plugin_id: str) -> Path:
    return default_openclaw_config_path().expanduser().resolve(strict=False).parent / 'extensions' / plugin_id


def default_openclaw_hook_install_path(package_id: str) -> Path:
    return default_openclaw_config_path().expanduser().resolve(strict=False).parent / 'hooks' / package_id


def _dict_field(payload: dict[str, object], key: str) -> dict[str, object]:
    value = payload.get(key)
    if isinstance(value, dict):
        return value
    replacement: dict[str, object] = {}
    payload[key] = replacement
    return replacement


def _string_list_field(payload: dict[str, object], key: str) -> list[str]:
    value = payload.get(key)
    if isinstance(value, list):
        return [entry.strip() for entry in value if isinstance(entry, str) and entry.strip()]
    return []


def _ensure_string_list_contains(values: list[str], entry: str) -> list[str]:
    if entry in values:
        return values
    return [*values, entry]


def _ensure_openclaw_plugin_allow_entry(*, config_path: Path, plugin_id: str) -> tuple[bool, bool]:
    config_payload = _load_openclaw_config_payload(config_path)
    if config_payload is None:
        raise FileNotFoundError(f'OpenClaw config not found: {config_path}')

    plugins_section = _dict_field(config_payload, 'plugins')
    plugin_allow_field_existed = 'allow' in plugins_section
    plugins_allow = _string_list_field(plugins_section, 'allow')
    if plugin_id in plugins_allow:
        if isinstance(plugins_section.get('allow'), list):
            normalized_allow = plugins_allow
            if normalized_allow != plugins_section.get('allow'):
                plugins_section['allow'] = normalized_allow
                _write_openclaw_config_payload(config_path, config_payload)
        return False, plugin_allow_field_existed

    plugins_section['allow'] = [*plugins_allow, plugin_id]
    _write_openclaw_config_payload(config_path, config_payload)
    return True, plugin_allow_field_existed


def _ensure_openclaw_status_tool_allowed(*, config_path: Path) -> tuple[str | None, bool, bool]:
    resolved_config_path = config_path.expanduser().resolve(strict=False)
    config_payload = _load_openclaw_config_payload(resolved_config_path)
    if config_payload is None:
        raise FileNotFoundError(f'OpenClaw config not found: {resolved_config_path}')

    policy_key, entry_added_by_sheltron, field_existed, changed = (
        _ensure_openclaw_status_tool_allowed_in_config(config_payload)
    )
    if changed:
        _write_openclaw_config_payload(resolved_config_path, config_payload)
    return policy_key, entry_added_by_sheltron, field_existed


def _ensure_openclaw_status_tool_allowed_in_config(
    config_payload: dict[str, object],
) -> tuple[str | None, bool, bool, bool]:
    tools_section = _dict_field(config_payload, 'tools')
    denied_tools = _string_list_field(tools_section, 'deny')
    if OPENCLAW_STATUS_TOOL_NAME in denied_tools:
        return None, False, False, False

    if isinstance(tools_section.get('allow'), list):
        policy_key = 'allow'
    else:
        policy_key = 'alsoAllow'
    field_existed = policy_key in tools_section
    current_values = _string_list_field(tools_section, policy_key)
    if OPENCLAW_STATUS_TOOL_NAME in current_values:
        changed = isinstance(tools_section.get(policy_key), list) and tools_section.get(policy_key) != current_values
        if changed:
            tools_section[policy_key] = current_values
        return policy_key, False, field_existed, changed

    tools_section[policy_key] = [*current_values, OPENCLAW_STATUS_TOOL_NAME]
    return policy_key, True, field_existed, True


def _record_status_tool_policy_update(
    state: OpenClawInstallState,
    update: tuple[str | None, bool, bool],
) -> None:
    policy_key, entry_added_by_sheltron, field_existed = update
    if policy_key is None:
        return
    if state.status_tool_policy_entry_added_by_sheltron:
        return
    state.status_tool_policy_key = policy_key
    state.status_tool_policy_entry_added_by_sheltron = entry_added_by_sheltron
    state.status_tool_policy_field_existed = field_existed


def _remove_openclaw_status_tool_policy_entry(
    config_payload: dict[str, object],
    *,
    policy_key: str | None,
    entry_added_by_sheltron: bool,
    field_existed: bool,
) -> bool:
    if not entry_added_by_sheltron or policy_key not in {'allow', 'alsoAllow'}:
        return False
    tools_section = _dict_field(config_payload, 'tools')
    current_values = _string_list_field(tools_section, policy_key)
    next_values = [entry for entry in current_values if entry != OPENCLAW_STATUS_TOOL_NAME]
    if next_values == current_values:
        return False
    if next_values or field_existed:
        tools_section[policy_key] = next_values
    else:
        tools_section.pop(policy_key, None)
    return True


def _openclaw_status_tool_allowed(config_payload: dict[str, object]) -> bool:
    tools_section = config_payload.get('tools')
    if not isinstance(tools_section, dict):
        return False
    denied_tools = _string_list_field(tools_section, 'deny')
    if OPENCLAW_STATUS_TOOL_NAME in denied_tools:
        return False
    allowed_tools = {
        *_string_list_field(tools_section, 'allow'),
        *_string_list_field(tools_section, 'alsoAllow'),
    }
    return OPENCLAW_STATUS_TOOL_NAME in allowed_tools or 'group:plugins' in allowed_tools


def _remove_openclaw_install_path(path: Path) -> bool:
    if not path.exists():
        return False
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()
    return True


def _copy_openclaw_install_path(source_path: Path, install_path: Path) -> None:
    if install_path.exists():
        _remove_openclaw_install_path(install_path)
    install_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source_path, install_path)


def _sync_openclaw_install_path(source_path: Path, install_path: Path) -> bool:
    if _source_files_match_install_path(source_path, install_path):
        return False
    _copy_openclaw_install_path(source_path, install_path)
    return True


def _openclaw_asset_source_matches_install(source_resource, install_path: Path) -> bool:
    with as_file(source_resource) as source_path:
        return _source_files_match_install_path(source_path, install_path)


def _source_files_match_install_path(source_path: Path, install_path: Path) -> bool:
    if not source_path.exists() or not install_path.exists():
        return False
    if not source_path.is_dir() or not install_path.is_dir():
        return False
    for source_file in source_path.rglob('*'):
        if not source_file.is_file():
            continue
        target_file = install_path / source_file.relative_to(source_path)
        if not target_file.is_file():
            return False
        if source_file.read_bytes() != target_file.read_bytes():
            return False
    return True


def _openclaw_package_version(package_dir: Path) -> str | None:
    package_json_path = package_dir / 'package.json'
    if not package_json_path.exists():
        return None
    payload = json.loads(package_json_path.read_text(encoding='utf-8'))
    if not isinstance(payload, dict):
        return None
    version = payload.get('version')
    return version if isinstance(version, str) and version.strip() else None


def _openclaw_plugin_install_record(config_payload: dict[str, object], plugin_id: str) -> dict[str, object] | None:
    plugins_section = _dict_field(config_payload, 'plugins')
    plugin_installs = _dict_field(plugins_section, 'installs')
    value = plugin_installs.get(plugin_id)
    return value if isinstance(value, dict) else None


def _openclaw_hook_install_record(config_payload: dict[str, object], package_id: str) -> dict[str, object] | None:
    hooks_section = _dict_field(config_payload, 'hooks')
    hooks_internal = _dict_field(hooks_section, 'internal')
    hook_installs = _dict_field(hooks_internal, 'installs')
    value = hook_installs.get(package_id)
    return value if isinstance(value, dict) else None


def _openclaw_install_path_from_record(record: dict[str, object] | None, default_path: Path) -> Path:
    if record is None:
        return default_path
    install_path = record.get('installPath')
    if isinstance(install_path, str) and install_path.strip():
        return Path(install_path).expanduser().resolve(strict=False)
    return default_path


def _openclaw_plugin_enabled(config_payload: dict[str, object], plugin_id: str) -> bool:
    plugins_section = _dict_field(config_payload, 'plugins')
    plugin_entries = _dict_field(plugins_section, 'entries')
    value = plugin_entries.get(plugin_id)
    return isinstance(value, dict) and value.get('enabled') is True


def _openclaw_hook_enabled(config_payload: dict[str, object], hook_name: str) -> bool:
    hooks_section = _dict_field(config_payload, 'hooks')
    hooks_internal = _dict_field(hooks_section, 'internal')
    hook_entries = _dict_field(hooks_internal, 'entries')
    value = hook_entries.get(hook_name)
    return isinstance(value, dict) and value.get('enabled') is True


def _bridge_server_ready_path(state: OpenClawInstallState) -> Path:
    return Path(state.runtime_state_path).expanduser().resolve(strict=False).with_name('bridge-server-ready.json')


def _bridge_server_log_path(state: OpenClawInstallState) -> Path:
    runtime_dir = Path(state.runtime_state_path).expanduser().resolve(strict=False).parent
    return runtime_dir / default_openclaw_bridge_log_path().name


def _openclaw_bridge_server_running(state: OpenClawInstallState) -> bool:
    if not state.bridge_url or not state.bridge_token:
        return False
    request = Request(
        f'{state.bridge_url.rstrip("/")}/health',
        headers={
            'Authorization': f'Bearer {state.bridge_token}',
        },
    )
    try:
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode('utf-8'))
    except (OSError, URLError, TimeoutError, json.JSONDecodeError):
        return False
    return payload == {'ok': True}


def _ensure_openclaw_bridge_server(
    state: OpenClawInstallState,
    *,
    resolved_state_path: Path,
) -> None:
    if _openclaw_bridge_server_running(state):
        return
    _stop_openclaw_bridge_server(state, persist=False)

    ready_path = _bridge_server_ready_path(state)
    if ready_path.exists():
        ready_path.unlink()
    log_path = _bridge_server_log_path(state)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(24)
    with log_path.open('a', encoding='utf-8') as log_file:
        process = subprocess.Popen(
            _openclaw_bridge_server_command(
                state,
                resolved_state_path=resolved_state_path,
                token=token,
                ready_path=ready_path,
            ),
            stdout=log_file,
            stderr=log_file,
            text=True,
            start_new_session=True,
            env=_bridge_server_env(),
        )

    deadline = time.monotonic() + 5.0
    ready_payload: dict[str, object] | None = None
    while time.monotonic() < deadline:
        if process.poll() is not None:
            break
        if ready_path.exists():
            try:
                payload = json.loads(ready_path.read_text(encoding='utf-8'))
            except (OSError, json.JSONDecodeError):
                time.sleep(0.1)
                continue
            if isinstance(payload, dict) and isinstance(payload.get('bridge_url'), str):
                ready_payload = payload
                break
        time.sleep(0.1)

    if ready_path.exists():
        ready_path.unlink()

    if process.poll() is not None:
        detail = log_path.read_text(encoding='utf-8') if log_path.exists() else ''
        raise RuntimeError(
            'OpenClaw bridge server exited before it became ready.'
            + (f'\n{detail.strip()}' if detail.strip() else '')
        )

    if ready_payload is None:
        _terminate_openclaw_bridge_server(process.pid, resolved_state_path)
        detail = log_path.read_text(encoding='utf-8') if log_path.exists() else ''
        raise RuntimeError(
            'Timed out waiting for the OpenClaw bridge server to become ready.'
            + (f'\n{detail.strip()}' if detail.strip() else '')
        )

    state.bridge_url = str(ready_payload['bridge_url'])
    state.bridge_token = token
    state.bridge_server_pid = process.pid
    state.bridge_server_state_path = str(resolved_state_path)
    _write_install_state(state=state, resolved_state_path=resolved_state_path)


def _openclaw_bridge_server_command(
    state: OpenClawInstallState,
    *,
    resolved_state_path: Path,
    token: str,
    ready_path: Path,
) -> list[str]:
    command_args = [
        'openclaw',
        'bridge-server',
        '--state-path',
        str(resolved_state_path),
        f'--token={token}',
        f'--ready-file={ready_path}',
    ]
    if state.sheltron_command_path:
        return [state.sheltron_command_path, *command_args]
    return [
        state.sheltron_python_path,
        '-m',
        'sheltron',
        *command_args,
    ]


def _stop_openclaw_bridge_server(
    state: OpenClawInstallState,
    *,
    persist: bool = False,
) -> None:
    pid = state.bridge_server_pid
    state_path = Path(
        state.bridge_server_state_path
        or state.management_state_path
        or state.runtime_state_path
    ).expanduser().resolve(strict=False)
    if pid is not None:
        _terminate_openclaw_bridge_server(pid, state_path)
    state.bridge_url = None
    state.bridge_token = None
    state.bridge_server_pid = None
    state.bridge_server_state_path = None
    if persist:
        _write_install_state(state=state, resolved_state_path=state_path)


def _terminate_openclaw_bridge_server(pid: int, state_path: Path) -> None:
    if not _pid_matches_openclaw_bridge_server(pid, state_path):
        return
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    except OSError:
        return

    deadline = time.monotonic() + 3.0
    while time.monotonic() < deadline:
        if not _pid_matches_openclaw_bridge_server(pid, state_path):
            return
        time.sleep(0.1)
    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        return


def _pid_matches_openclaw_bridge_server(pid: int, state_path: Path) -> bool:
    proc_cmdline = Path('/proc') / str(pid) / 'cmdline'
    if proc_cmdline.exists():
        try:
            command = proc_cmdline.read_text(encoding='utf-8').replace('\x00', ' ')
        except OSError:
            return False
        return 'sheltron' in command and 'openclaw' in command and 'bridge-server' in command and str(state_path) in command
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _bridge_server_env() -> dict[str, str]:
    environment = os.environ.copy()
    pythonpath_entries = [entry for entry in sys.path if entry]
    existing_pythonpath = environment.get('PYTHONPATH')
    if existing_pythonpath:
        pythonpath_entries.extend(part for part in existing_pythonpath.split(os.pathsep) if part)
    if pythonpath_entries:
        seen: set[str] = set()
        ordered_entries: list[str] = []
        for entry in pythonpath_entries:
            if entry in seen:
                continue
            seen.add(entry)
            ordered_entries.append(entry)
        environment['PYTHONPATH'] = os.pathsep.join(ordered_entries)
    return environment
