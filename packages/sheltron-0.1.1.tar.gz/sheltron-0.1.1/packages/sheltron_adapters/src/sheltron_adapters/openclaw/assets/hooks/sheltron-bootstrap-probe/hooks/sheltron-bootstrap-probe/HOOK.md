---
name: sheltron-bootstrap-probe
description: Filter OpenClaw bootstrap files through the Sheltron bridge before injection.
events:
  - agent:bootstrap
---

This managed hook is installed by Sheltron so OpenClaw `agent:bootstrap` events can
filter the pending bootstrap file list through the Sheltron bridge before injection.
