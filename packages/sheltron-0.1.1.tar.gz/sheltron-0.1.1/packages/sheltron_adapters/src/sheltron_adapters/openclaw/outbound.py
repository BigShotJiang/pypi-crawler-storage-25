from __future__ import annotations

from datetime import datetime, timedelta, timezone
from enum import Enum
import hashlib
import json
import os
from pathlib import Path
import subprocess
from typing import Iterable
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from sheltron_core import ApprovalStatus, JsonApprovalStore, JsonlAuditLogger, build_audit_record
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    PolicyResult,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_core.file_lock import locked_path
from sheltron_adapters.openclaw.bridge_common import load_openclaw_install_state
from sheltron_adapters.openclaw.install import default_openclaw_workspace_path

OPENCLAW_OUTBOUND_REPLAY_ID_ENV = 'SHELTRON_OPENCLAW_OUTBOUND_REPLAY_ID'


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def default_openclaw_outbound_store_path(workspace: str | Path | None = None) -> Path:
    resolved_workspace = (
        Path(workspace).expanduser().resolve(strict=False)
        if workspace is not None
        else default_openclaw_workspace_path().expanduser().resolve(strict=False)
    )
    return resolved_workspace / '.sheltron' / 'outbound_messages.jsonl'


class OutboundMessageStatus(str, Enum):
    QUEUED = 'queued'
    ARMED = 'armed'
    SENT = 'sent'


class PendingOutboundMessage(BaseModel):
    model_config = ConfigDict(extra='forbid')

    outbound_id: str
    source: str
    session_id: str
    channel: str
    recipient: str
    default_channel: str
    default_recipient: str
    original_content: str
    deliver_content: str
    original_content_sha256: str
    deliver_content_sha256: str
    provenance: Provenance
    approval_ticket_id: str | None = None
    approval_store_path: str | None = None
    reason_code: str | None = None
    account_id: str | None = None
    reply_to: str | None = None
    thread_id: str | None = None
    status: OutboundMessageStatus = OutboundMessageStatus.QUEUED
    bridge_confirmed: bool = False
    created_at: datetime = Field(default_factory=_utcnow)
    updated_at: datetime = Field(default_factory=_utcnow)
    armed_until: datetime | None = None
    sent_at: datetime | None = None


class OpenClawOutboundResumeResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    entry: PendingOutboundMessage
    command: tuple[str, ...]


class JsonlOpenClawOutboundStore:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else default_openclaw_outbound_store_path()

    def create(
        self,
        *,
        source: str,
        session_id: str,
        channel: str,
        recipient: str,
        default_channel: str,
        default_recipient: str,
        original_content: str,
        deliver_content: str,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
        approval_store_path: str | Path | None = None,
        reason_code: str | None = None,
        account_id: str | None = None,
        reply_to: str | None = None,
        thread_id: str | None = None,
    ) -> PendingOutboundMessage:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            original_sha = _sha256_text(original_content)
            deliver_sha = _sha256_text(deliver_content)
            normalized_approval_store = str(approval_store_path) if approval_store_path is not None else None
            for entry in entries:
                if (
                    entry.status in {OutboundMessageStatus.QUEUED, OutboundMessageStatus.ARMED}
                    and entry.source == source
                    and entry.session_id == session_id
                    and entry.channel == channel
                    and entry.recipient == recipient
                    and entry.default_channel == default_channel
                    and entry.default_recipient == default_recipient
                    and entry.original_content_sha256 == original_sha
                    and entry.deliver_content_sha256 == deliver_sha
                    and entry.approval_ticket_id == approval_ticket_id
                    and entry.approval_store_path == normalized_approval_store
                    and entry.account_id == account_id
                    and entry.reply_to == reply_to
                    and entry.thread_id == thread_id
                ):
                    updated = entry.model_copy(
                        update={
                            'provenance': provenance,
                            'reason_code': reason_code,
                            'updated_at': _utcnow(),
                            'armed_until': None,
                            'status': OutboundMessageStatus.QUEUED,
                            'bridge_confirmed': False,
                        }
                    )
                    self._replace_entry(entries, updated)
                    self._write_entries_unlocked(entries)
                    return updated
            entry = PendingOutboundMessage(
                outbound_id=f'outbound-{uuid4().hex}',
                source=source,
                session_id=session_id,
                channel=channel,
                recipient=recipient,
                default_channel=default_channel,
                default_recipient=default_recipient,
                original_content=original_content,
                deliver_content=deliver_content,
                original_content_sha256=original_sha,
                deliver_content_sha256=deliver_sha,
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
                approval_store_path=normalized_approval_store,
                reason_code=reason_code,
                account_id=account_id,
                reply_to=reply_to,
                thread_id=thread_id,
            )
            entries.insert(0, entry)
            self._write_entries_unlocked(entries)
            return entry

    def get(self, outbound_id: str) -> PendingOutboundMessage | None:
        with locked_path(self.path):
            for entry in self._load_entries_unlocked():
                if entry.outbound_id == outbound_id:
                    return entry
            return None

    def list(self, *, status: OutboundMessageStatus | None = None) -> list[PendingOutboundMessage]:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            if status is None:
                return entries
            return [entry for entry in entries if entry.status is status]

    def arm(self, outbound_id: str, *, ttl_seconds: int = 30) -> PendingOutboundMessage:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            entry = self._require_entry(entries, outbound_id)
            updated = entry.model_copy(
                update={
                    'status': OutboundMessageStatus.ARMED,
                    'armed_until': _utcnow() + timedelta(seconds=ttl_seconds),
                    'updated_at': _utcnow(),
                }
            )
            self._replace_entry(entries, updated)
            self._write_entries_unlocked(entries)
            return updated

    def clear_arm(self, outbound_id: str) -> PendingOutboundMessage:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            entry = self._require_entry(entries, outbound_id)
            updated = entry.model_copy(
                update={
                    'status': OutboundMessageStatus.QUEUED,
                    'armed_until': None,
                    'updated_at': _utcnow(),
                }
            )
            self._replace_entry(entries, updated)
            self._write_entries_unlocked(entries)
            return updated

    def mark_sent(self, outbound_id: str) -> PendingOutboundMessage:
        return self._mark_sent(outbound_id, bridge_confirmed=True)

    def mark_sent_without_bridge_confirmation(self, outbound_id: str) -> PendingOutboundMessage:
        return self._mark_sent(outbound_id, bridge_confirmed=False)

    def _mark_sent(self, outbound_id: str, *, bridge_confirmed: bool) -> PendingOutboundMessage:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            entry = self._require_entry(entries, outbound_id)
            updated = entry.model_copy(
                update={
                    'status': OutboundMessageStatus.SENT,
                    'bridge_confirmed': bridge_confirmed,
                    'armed_until': None,
                    'sent_at': _utcnow(),
                    'updated_at': _utcnow(),
                }
            )
            self._replace_entry(entries, updated)
            self._write_entries_unlocked(entries)
            return updated

    def match_armed_by_id(
        self,
        *,
        outbound_id: str,
        source: str,
        session_id: str | None,
        channel: str,
        recipient: str,
        content: str,
    ) -> PendingOutboundMessage | None:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            now = _utcnow()
            match: PendingOutboundMessage | None = None
            changed = False
            for index, entry in enumerate(entries):
                if entry.status is not OutboundMessageStatus.ARMED:
                    continue
                if entry.armed_until is not None and entry.armed_until <= now:
                    entries[index] = entry.model_copy(
                        update={
                            'status': OutboundMessageStatus.QUEUED,
                            'armed_until': None,
                            'updated_at': now,
                        }
                    )
                    changed = True
                    continue
                if (
                    entry.outbound_id == outbound_id
                    and entry.source == source
                    and entry.channel == channel
                    and entry.recipient == recipient
                    and entry.deliver_content_sha256 == _sha256_text(content)
                    and (
                        session_id is None
                        or session_id == ''
                        or session_id == 'openclaw:unknown'
                        or entry.session_id == session_id
                    )
                ):
                    match = entry
                    break
            if changed:
                self._write_entries_unlocked(entries)
            return match

    def _load_entries_unlocked(self) -> list[PendingOutboundMessage]:
        if not self.path.exists():
            return []
        entries: list[PendingOutboundMessage] = []
        with self.path.open('r', encoding='utf-8') as handle:
            for line in handle:
                payload = line.strip()
                if not payload:
                    continue
                entries.append(PendingOutboundMessage.model_validate_json(payload))
        return entries

    def _write_entries_unlocked(self, entries: Iterable[PendingOutboundMessage]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open('w', encoding='utf-8') as handle:
            for entry in entries:
                handle.write(entry.model_dump_json())
                handle.write('\n')

    @staticmethod
    def _require_entry(entries: list[PendingOutboundMessage], outbound_id: str) -> PendingOutboundMessage:
        for entry in entries:
            if entry.outbound_id == outbound_id:
                return entry
        raise KeyError(f'Pending OpenClaw outbound message not found: {outbound_id}')

    @staticmethod
    def _replace_entry(entries: list[PendingOutboundMessage], updated: PendingOutboundMessage) -> None:
        for index, entry in enumerate(entries):
            if entry.outbound_id == updated.outbound_id:
                entries[index] = updated
                return
        raise KeyError(f'Pending OpenClaw outbound message not found: {updated.outbound_id}')


def resolve_openclaw_outbound_store_path(
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
) -> Path:
    if workspace is not None:
        return default_openclaw_outbound_store_path(workspace)
    install_state = load_openclaw_install_state(state_path)
    if install_state is not None:
        return default_openclaw_outbound_store_path(install_state.workspace_path)
    return default_openclaw_outbound_store_path()


def approval_status_for_outbound_message(
    entry: PendingOutboundMessage,
    *,
    approval_store_path: str | Path | None = None,
) -> ApprovalStatus | None:
    if entry.approval_ticket_id is None:
        return None
    resolved_store_path = (
        Path(approval_store_path)
        if approval_store_path is not None
        else Path(entry.approval_store_path)
        if entry.approval_store_path is not None
        else None
    )
    if resolved_store_path is None:
        return None
    ticket = JsonApprovalStore(resolved_store_path).get(entry.approval_ticket_id)
    if ticket is None:
        return None
    return ticket.status


def resume_openclaw_outbound_message(
    outbound_id: str,
    *,
    state_path: str | Path | None = None,
    openclaw_command_path: str | Path | None = None,
) -> OpenClawOutboundResumeResult:
    install_state = load_openclaw_install_state(state_path)
    if install_state is None:
        raise FileNotFoundError('Sheltron OpenClaw link state was not found.')
    store = JsonlOpenClawOutboundStore(
        resolve_openclaw_outbound_store_path(
            state_path=state_path,
            workspace=install_state.workspace_path,
        )
    )
    entry = store.get(outbound_id)
    if entry is None:
        raise KeyError(f'Pending OpenClaw outbound message not found: {outbound_id}')
    if entry.status is OutboundMessageStatus.SENT:
        return OpenClawOutboundResumeResult(entry=entry, command=())

    approval_store_path = (
        Path(entry.approval_store_path)
        if entry.approval_store_path is not None
        else Path(install_state.workspace_path) / '.sheltron' / 'approvals.json'
    )
    approval_status = approval_status_for_outbound_message(entry, approval_store_path=approval_store_path)
    if entry.approval_ticket_id is not None and approval_status is not ApprovalStatus.APPROVED:
        status_value = approval_status.value if approval_status is not None else 'missing'
        raise RuntimeError(
            f'Pending outbound message {outbound_id} is not approved yet (approval status: {status_value}).'
        )

    if entry.source == 'sessions_send':
        command = _sessions_send_command(
            Path(openclaw_command_path or install_state.openclaw_command_path).expanduser().resolve(strict=False),
            entry,
            install_state=install_state,
        )
        completed = subprocess.run(
            list(command),
            check=False,
            capture_output=True,
            text=True,
            env=os.environ.copy(),
        )
        if completed.returncode != 0:
            _append_replay_audit(
                entry,
                workspace=Path(install_state.workspace_path),
                outcome='openclaw_sessions_send_replay',
                result=PolicyResult.deny(
                    'openclaw_sessions_send_replay',
                    code='openclaw_sessions_send_replay_failed',
                    message='Managed OpenClaw sessions_send replay failed.',
                    details={'exit_code': completed.returncode},
                ),
                result_summary=f'command_failed exit_code={completed.returncode}',
            )
            raise RuntimeError(
                f'OpenClaw sessions_send replay failed with exit code {completed.returncode}: '
                f'{(completed.stderr or completed.stdout).strip()}'
            )
        try:
            if entry.approval_ticket_id is not None:
                JsonApprovalStore(approval_store_path).consume(entry.approval_ticket_id)
        except Exception as exc:
            updated = store.mark_sent_without_bridge_confirmation(outbound_id)
            _append_replay_audit(
                updated,
                workspace=Path(install_state.workspace_path),
                outcome='openclaw_sessions_send_replay',
                result=PolicyResult.allow(
                    'openclaw_sessions_send_replay',
                    code='openclaw_sessions_send_replayed',
                    message='Managed OpenClaw sessions_send replay completed.',
                ),
                result_summary='command_succeeded approval_consume_failed=true',
            )
            raise RuntimeError(
                'OpenClaw sessions_send replay completed, but Sheltron could not consume the approved ticket. '
                'The outbound entry remains marked sent to avoid duplicate delivery; inspect the approval store '
                f'before retrying: {exc}'
            ) from exc
        updated = store.mark_sent(outbound_id)
        _append_replay_audit(
            updated,
            workspace=Path(install_state.workspace_path),
            outcome='openclaw_sessions_send_replay',
            result=PolicyResult.allow(
                'openclaw_sessions_send_replay',
                code='openclaw_sessions_send_replayed',
                message='Managed OpenClaw sessions_send replay completed.',
            ),
            result_summary='command_succeeded',
        )
        return OpenClawOutboundResumeResult(entry=updated, command=command)

    armed_entry = store.arm(outbound_id)
    command = _message_send_command(
        Path(openclaw_command_path or install_state.openclaw_command_path).expanduser().resolve(strict=False),
        armed_entry,
    )
    completed = subprocess.run(
        list(command),
        check=False,
        capture_output=True,
        text=True,
        env={
            **os.environ,
            OPENCLAW_OUTBOUND_REPLAY_ID_ENV: outbound_id,
        },
    )
    if completed.returncode != 0:
        updated = store.get(outbound_id)
        if updated is not None and updated.status is OutboundMessageStatus.SENT:
            raise RuntimeError(
                'OpenClaw outbound replay command failed after Sheltron had already consumed the replay hook. '
                'The outbound entry remains marked sent to avoid duplicate delivery; inspect the managed hook bridge '
                f'and OpenClaw command failure details before retrying: {(completed.stderr or completed.stdout).strip()}'
            )
        store.clear_arm(outbound_id)
        raise RuntimeError(
            f'OpenClaw outbound replay failed with exit code {completed.returncode}: '
            f'{(completed.stderr or completed.stdout).strip()}'
        )

    updated = store.get(outbound_id)
    if updated is None:
        raise KeyError(f'Pending OpenClaw outbound message disappeared during replay: {outbound_id}')
    if updated.status is not OutboundMessageStatus.SENT:
        updated = store.mark_sent_without_bridge_confirmation(outbound_id)
        raise RuntimeError(
            'OpenClaw message send completed, but Sheltron did not observe bridge confirmation for the replay. '
            'The outbound entry was marked sent to avoid duplicate delivery; inspect the managed hook bridge before retrying.'
        )
    return OpenClawOutboundResumeResult(entry=updated, command=command)


def _message_send_command(
    openclaw_command_path: Path,
    entry: PendingOutboundMessage,
) -> tuple[str, ...]:
    command = [
        str(openclaw_command_path),
        'message',
        'send',
        '--channel',
        entry.channel,
        '--target',
        entry.recipient,
        '--message',
        entry.deliver_content,
    ]
    if entry.account_id:
        command.extend(['--account', entry.account_id])
    if entry.reply_to:
        command.extend(['--reply-to', entry.reply_to])
    if entry.thread_id:
        command.extend(['--thread-id', entry.thread_id])
    return tuple(command)


def _sessions_send_command(
    openclaw_command_path: Path,
    entry: PendingOutboundMessage,
    *,
    install_state: object,
) -> tuple[str, ...]:
    selector = _resolve_sessions_send_selector(entry, install_state=install_state)
    return (
        str(openclaw_command_path),
        'agent',
        *selector,
        '--message',
        entry.deliver_content,
    )


def _resolve_sessions_send_selector(
    entry: PendingOutboundMessage,
    *,
    install_state: object,
) -> tuple[str, str]:
    target_session = entry.recipient
    resolved_session_id = _resolve_openclaw_session_id(
        target_session,
        current_session_id=entry.session_id,
        install_state=install_state,
    )
    if resolved_session_id is not None:
        return ('--session-id', resolved_session_id)
    target_agent = _main_agent_from_target_session(target_session, current_session_id=entry.session_id)
    if target_agent is not None:
        return ('--agent', target_agent)
    return ('--session-id', target_session)


def _resolve_openclaw_session_id(
    target_session: str,
    *,
    current_session_id: str,
    install_state: object,
) -> str | None:
    candidate_agents = _candidate_agent_ids(target_session, current_session_id=current_session_id)
    config_path = getattr(install_state, 'config_path', None)
    if not isinstance(config_path, str) or not config_path:
        return None
    openclaw_home = Path(config_path).expanduser().resolve(strict=False).parent
    for agent_id in candidate_agents:
        store_path = openclaw_home / 'agents' / agent_id / 'sessions' / 'sessions.json'
        if not store_path.exists():
            continue
        try:
            payload = store_path.read_text(encoding='utf-8')
        except OSError:
            continue
        try:
            data = json.loads(payload)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict):
            continue
        for key in _candidate_session_keys(target_session, agent_id=agent_id):
            record = data.get(key)
            if isinstance(record, dict):
                session_id = record.get('sessionId')
                if isinstance(session_id, str) and session_id:
                    return session_id
    return None


def _candidate_agent_ids(target_session: str, *, current_session_id: str) -> tuple[str, ...]:
    explicit_agent = _agent_id_from_prefixed_session(target_session)
    current_agent = _agent_id_from_prefixed_session(current_session_id)
    candidates: list[str] = []
    if explicit_agent is not None:
        candidates.append(explicit_agent)
    if current_agent is not None and current_agent not in candidates:
        candidates.append(current_agent)
    if 'main' not in candidates:
        candidates.append('main')
    return tuple(candidates)


def _candidate_session_keys(target_session: str, *, agent_id: str) -> tuple[str, ...]:
    candidates = [target_session]
    prefix = f'agent:{agent_id}:'
    if target_session.startswith(prefix):
        stripped = target_session[len(prefix) :]
        if stripped and stripped not in candidates:
            candidates.append(stripped)
    return tuple(candidates)


def _agent_id_from_prefixed_session(session_key: str | None) -> str | None:
    if session_key is None:
        return None
    parts = session_key.split(':', 2)
    if len(parts) >= 3 and parts[0] == 'agent' and parts[1]:
        return parts[1]
    return None


def _main_agent_from_target_session(target_session: str, *, current_session_id: str) -> str | None:
    if target_session == 'main':
        return _agent_id_from_prefixed_session(current_session_id) or 'main'
    parts = target_session.split(':', 2)
    if len(parts) == 3 and parts[0] == 'agent' and parts[2] == 'main':
        return parts[1]
    return None


def _append_replay_audit(
    entry: PendingOutboundMessage,
    *,
    workspace: Path,
    outcome: str,
    result: PolicyResult,
    result_summary: str,
) -> None:
    request = ActionRequest(
        request_id=f'outbound-{uuid4().hex}',
        capability=Capability.SEND_MESSAGE,
        resource=ResourceDescriptor(
            kind=ResourceKind.MESSAGE_TARGET,
            locator=f'{entry.channel}:{entry.recipient}',
        ),
        provenance=entry.provenance,
        parameters={
            'channel': entry.channel,
            'recipient': entry.recipient,
            'default_channel': entry.default_channel,
            'default_recipient': entry.default_recipient,
            'source': entry.source,
            'content_chars': len(entry.deliver_content),
            'content_sha256': entry.deliver_content_sha256,
            'original_content_sha256': entry.original_content_sha256,
            'content_redacted': entry.deliver_content != entry.original_content,
        },
    )
    JsonlAuditLogger(workspace / '.sheltron' / 'audit.jsonl').append(
        build_audit_record(
            system='openclaw',
            request=request,
            result=result,
            outcome=outcome,
            result_summary=result_summary,
        )
    )


__all__ = [
    'JsonlOpenClawOutboundStore',
    'OpenClawOutboundResumeResult',
    'OPENCLAW_OUTBOUND_REPLAY_ID_ENV',
    'OutboundMessageStatus',
    'PendingOutboundMessage',
    'approval_status_for_outbound_message',
    'default_openclaw_outbound_store_path',
    'resolve_openclaw_outbound_store_path',
    'resume_openclaw_outbound_message',
]
