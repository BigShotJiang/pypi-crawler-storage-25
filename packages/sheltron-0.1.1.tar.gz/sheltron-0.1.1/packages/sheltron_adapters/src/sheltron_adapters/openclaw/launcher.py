from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from pathlib import Path

from sheltron_adapters.openclaw.install import (
    OpenClawProtectionState,
    _load_install_state,
    _normalize_command_path,
    default_openclaw_install_state_path,
    doctor_openclaw,
    prepare_openclaw_protected_run,
)

_PROTECTED_RUN_WRAPPER = """
import json
import os
import sys
import time

marker_dir = sys.argv[1]
target = sys.argv[2]
args = sys.argv[3:]
os.makedirs(marker_dir, exist_ok=True)
pid = os.getpid()
marker_path = os.path.join(marker_dir, f'{pid}.json')
with open(marker_path, 'w', encoding='utf-8') as marker_file:
    json.dump(
        {
            'pid': pid,
            'process_group_id': os.getpgrp(),
            'session_id': os.getsid(0),
            'target': target,
            'created_at': time.time(),
        },
        marker_file,
    )
os.execv(target, [target, *args])
""".strip()


def default_openclaw_protected_run_dir() -> Path:
    return Path.home() / '.sheltron' / 'openclaw' / 'protected-runs'


def _remove_protected_run_marker(pid: int) -> None:
    marker_path = default_openclaw_protected_run_dir() / f'{pid}.json'
    try:
        marker_path.unlink()
    except FileNotFoundError:
        return


def _terminate_process_group(process: subprocess.Popen[object], *, grace_seconds: float = 5.0) -> None:
    try:
        process_group_id = os.getpgid(process.pid)
    except ProcessLookupError:
        return
    except OSError:
        process_group_id = process.pid

    for shutdown_signal in (signal.SIGINT, signal.SIGTERM):
        try:
            os.killpg(process_group_id, shutdown_signal)
        except ProcessLookupError:
            return
        except OSError:
            return

        deadline = time.monotonic() + grace_seconds
        while time.monotonic() < deadline:
            if not _process_group_exists(process_group_id):
                return
            time.sleep(0.1)

    try:
        os.killpg(process_group_id, signal.SIGKILL)
    except OSError:
        return


def _process_group_exists(process_group_id: int) -> bool:
    try:
        os.killpg(process_group_id, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return False
    return True


def _normalize_forwarded_args(command_args: list[str] | tuple[str, ...]) -> list[str]:
    forwarded_args = list(command_args)
    if forwarded_args[:1] == ['--']:
        forwarded_args = forwarded_args[1:]
    if len(forwarded_args) >= 2 and forwarded_args[1] == '--':
        return [forwarded_args[0], *forwarded_args[2:]]
    return forwarded_args


def run_openclaw_command(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
    command_args: list[str] | tuple[str, ...] = (),
) -> int:
    forwarded_args = _normalize_forwarded_args(command_args)

    resolved_state_path = Path(state_path or default_openclaw_install_state_path()).expanduser().resolve(strict=False)
    report = doctor_openclaw(
        openclaw_command_path=openclaw_command_path,
        state_path=resolved_state_path,
    )
    if report.protection_state is OpenClawProtectionState.NOT_INSTALLED:
        raise RuntimeError(
            'Sheltron OpenClaw is not linked for this target. Run `sheltron link openclaw` first.'
        )
    if report.protection_state is OpenClawProtectionState.BROKEN:
        raise RuntimeError(
            'Sheltron OpenClaw is in a broken state for this target. Run `sheltron doctor openclaw` '
            'and repair the link before using the explicit protected path.'
        )

    state = _load_install_state(resolved_state_path)
    if state is None:
        raise RuntimeError(
            f'Sheltron OpenClaw link state not found: {resolved_state_path}. '
            'Run `sheltron link openclaw` first.'
        )

    resolved_command_path = (
        _normalize_command_path(openclaw_command_path)
        if openclaw_command_path is not None
        else Path(state.openclaw_command_path).expanduser().resolve(strict=False)
    )
    prepare_openclaw_protected_run(
        openclaw_command_path=resolved_command_path,
        state_path=resolved_state_path,
    )
    marker_dir = default_openclaw_protected_run_dir()
    process = subprocess.Popen(
        [
            sys.executable,
            '-c',
            _PROTECTED_RUN_WRAPPER,
            str(marker_dir),
            str(resolved_command_path),
            *forwarded_args,
        ],
        start_new_session=True,
    )
    try:
        return process.wait()
    except KeyboardInterrupt:
        _terminate_process_group(process)
        return 130
    finally:
        _remove_protected_run_marker(process.pid)


def run_openclaw_agent(
    *,
    openclaw_command_path: str | Path | None = None,
    state_path: str | Path | None = None,
    agent_args: list[str] | tuple[str, ...] = (),
) -> int:
    return run_openclaw_command(
        openclaw_command_path=openclaw_command_path,
        state_path=state_path,
        command_args=['agent', *_normalize_forwarded_args(agent_args)],
    )
