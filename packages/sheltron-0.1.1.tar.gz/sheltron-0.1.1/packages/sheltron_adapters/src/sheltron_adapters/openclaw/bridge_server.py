from __future__ import annotations

import json
import os
import signal
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Event
from typing import Callable

from sheltron_adapters.openclaw.bridge import (
    evaluate_agent_bootstrap,
    evaluate_before_prompt_build,
    evaluate_before_tool_call,
    evaluate_message_sending,
    evaluate_tool_result_persist,
    load_bridge_payload,
    record_plugin_approval_resolution,
    serialize_bridge_decision,
)

BridgeEvaluator = Callable[..., object]


_EVALUATORS: dict[str, BridgeEvaluator] = {
    'before-tool-call': evaluate_before_tool_call,
    'message-sending': evaluate_message_sending,
    'tool-result-persist': evaluate_tool_result_persist,
    'approval-resolution': record_plugin_approval_resolution,
    'agent-bootstrap': evaluate_agent_bootstrap,
    'before-prompt-build': evaluate_before_prompt_build,
}


def run_openclaw_bridge_server(
    *,
    state_path: str | Path | None,
    token: str,
    ready_file: str | Path | None = None,
    host: str = '127.0.0.1',
    port: int = 0,
) -> int:
    stop_event = Event()
    resolved_state_path = Path(state_path).expanduser().resolve(strict=False) if state_path is not None else None
    ready_path = Path(ready_file).expanduser().resolve(strict=False) if ready_file is not None else None

    class BridgeRequestHandler(BaseHTTPRequestHandler):
        server_version = 'SheltronOpenClawBridge/1.0'

        def do_GET(self) -> None:  # noqa: N802
            if self.path != '/health':
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            if not _authorized(self.headers.get('Authorization'), token):
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            self._write_json({'ok': True})

        def do_POST(self) -> None:  # noqa: N802
            command = self.path.removeprefix('/bridge/').strip('/')
            evaluator = _EVALUATORS.get(command)
            if evaluator is None:
                self.send_error(HTTPStatus.NOT_FOUND)
                return
            if not _authorized(self.headers.get('Authorization'), token):
                self.send_error(HTTPStatus.FORBIDDEN)
                return
            try:
                content_length = int(self.headers.get('Content-Length', '0'))
            except ValueError:
                self.send_error(HTTPStatus.BAD_REQUEST)
                return
            payload_text = self.rfile.read(content_length).decode('utf-8')
            try:
                payload = load_bridge_payload(payload_text)
            except ValueError as exc:
                self._write_json({'error': str(exc)}, status=HTTPStatus.BAD_REQUEST)
                return
            decision = evaluator(payload, state_path=resolved_state_path)
            self._write_raw_json(serialize_bridge_decision(decision))

        def log_message(self, format: str, *args: object) -> None:
            return

        def _write_json(self, payload: dict[str, object], *, status: HTTPStatus = HTTPStatus.OK) -> None:
            self._write_raw_json(json.dumps(payload), status=status)

        def _write_raw_json(self, payload: str, *, status: HTTPStatus = HTTPStatus.OK) -> None:
            encoded = payload.encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)

    server = ThreadingHTTPServer((host, port), BridgeRequestHandler)
    server.timeout = 0.5
    bridge_url = f'http://{host}:{server.server_port}'

    if ready_path is not None:
        ready_path.parent.mkdir(parents=True, exist_ok=True)
        ready_path.write_text(
            json.dumps(
                {
                    'bridge_url': bridge_url,
                    'pid': os.getpid(),
                }
            ),
            encoding='utf-8',
        )

    def _handle_signal(signum: int, frame: object) -> None:
        stop_event.set()

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    try:
        while not stop_event.is_set():
            server.handle_request()
    finally:
        server.server_close()
        if ready_path is not None and ready_path.exists():
            ready_path.unlink()
    return 0


def _authorized(header_value: str | None, token: str) -> bool:
    return header_value == f'Bearer {token}'
