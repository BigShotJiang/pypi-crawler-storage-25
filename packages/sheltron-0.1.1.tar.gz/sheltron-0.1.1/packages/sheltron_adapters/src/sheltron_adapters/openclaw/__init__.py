from __future__ import annotations

from importlib import import_module
from typing import Any

_EXPORTS = {
    'JsonObject': ('sheltron_core', 'JsonObject'),
    'JsonValue': ('sheltron_core', 'JsonValue'),
    'OpenClawBridgePayload': (
        'sheltron_adapters.openclaw.bridge_common',
        'OpenClawBridgePayload',
    ),
    'OpenClawBridgeDecision': ('sheltron_adapters.openclaw.bridge', 'OpenClawBridgeDecision'),
    'evaluate_agent_bootstrap': ('sheltron_adapters.openclaw.bridge', 'evaluate_agent_bootstrap'),
    'evaluate_before_prompt_build': (
        'sheltron_adapters.openclaw.bridge',
        'evaluate_before_prompt_build',
    ),
    'evaluate_before_tool_call': ('sheltron_adapters.openclaw.bridge', 'evaluate_before_tool_call'),
    'evaluate_message_sending': ('sheltron_adapters.openclaw.bridge', 'evaluate_message_sending'),
    'evaluate_tool_result_persist': (
        'sheltron_adapters.openclaw.bridge',
        'evaluate_tool_result_persist',
    ),
    'load_bridge_payload': ('sheltron_adapters.openclaw.bridge', 'load_bridge_payload'),
    'load_openclaw_install_state': (
        'sheltron_adapters.openclaw.bridge',
        'load_openclaw_install_state',
    ),
    'record_plugin_approval_resolution': (
        'sheltron_adapters.openclaw.bridge',
        'record_plugin_approval_resolution',
    ),
    'serialize_bridge_decision': ('sheltron_adapters.openclaw.bridge', 'serialize_bridge_decision'),
    'OPENCLAW_BOOTSTRAP_HOOK_NAME': (
        'sheltron_adapters.openclaw.install',
        'OPENCLAW_BOOTSTRAP_HOOK_NAME',
    ),
    'OPENCLAW_BOOTSTRAP_PACKAGE_ID': (
        'sheltron_adapters.openclaw.install',
        'OPENCLAW_BOOTSTRAP_PACKAGE_ID',
    ),
    'OPENCLAW_PROBE_PLUGIN_ID': ('sheltron_adapters.openclaw.install', 'OPENCLAW_PROBE_PLUGIN_ID'),
    'SUPPORTED_OPENCLAW_INSTALL_MODES': (
        'sheltron_adapters.openclaw.install',
        'SUPPORTED_OPENCLAW_INSTALL_MODES',
    ),
    'SUPPORTED_OPENCLAW_PROFILES': (
        'sheltron_adapters.openclaw.install',
        'SUPPORTED_OPENCLAW_PROFILES',
    ),
    'DoctorCheck': ('sheltron_adapters.openclaw.install', 'DoctorCheck'),
    'DoctorStatus': ('sheltron_adapters.openclaw.install', 'DoctorStatus'),
    'OpenClawDisableResult': ('sheltron_adapters.openclaw.install', 'OpenClawDisableResult'),
    'OpenClawDoctorReport': ('sheltron_adapters.openclaw.install', 'OpenClawDoctorReport'),
    'OpenClawEnableResult': ('sheltron_adapters.openclaw.install', 'OpenClawEnableResult'),
    'OpenClawInstallResult': ('sheltron_adapters.openclaw.install', 'OpenClawInstallResult'),
    'OpenClawInstallState': ('sheltron_adapters.openclaw.install', 'OpenClawInstallState'),
    'OpenClawInstallationTarget': (
        'sheltron_adapters.openclaw.install',
        'OpenClawInstallationTarget',
    ),
    'OpenClawProtectionState': ('sheltron_adapters.openclaw.install', 'OpenClawProtectionState'),
    'OpenClawUninstallResult': ('sheltron_adapters.openclaw.install', 'OpenClawUninstallResult'),
    'default_openclaw_config_path': (
        'sheltron_adapters.openclaw.install',
        'default_openclaw_config_path',
    ),
    'default_openclaw_install_state_path': (
        'sheltron_adapters.openclaw.install',
        'default_openclaw_install_state_path',
    ),
    'default_openclaw_workspace_path': (
        'sheltron_adapters.openclaw.install',
        'default_openclaw_workspace_path',
    ),
    'disable_openclaw': ('sheltron_adapters.openclaw.install', 'disable_openclaw'),
    'discover_openclaw_targets': ('sheltron_adapters.openclaw.install', 'discover_openclaw_targets'),
    'doctor_openclaw': ('sheltron_adapters.openclaw.install', 'doctor_openclaw'),
    'enable_openclaw': ('sheltron_adapters.openclaw.install', 'enable_openclaw'),
    'install_openclaw': ('sheltron_adapters.openclaw.install', 'install_openclaw'),
    'prepare_openclaw_protected_run': (
        'sheltron_adapters.openclaw.install',
        'prepare_openclaw_protected_run',
    ),
    'uninstall_openclaw': ('sheltron_adapters.openclaw.install', 'uninstall_openclaw'),
    'run_openclaw_agent': ('sheltron_adapters.openclaw.launcher', 'run_openclaw_agent'),
    'run_openclaw_command': ('sheltron_adapters.openclaw.launcher', 'run_openclaw_command'),
    'JsonlOpenClawOutboundStore': (
        'sheltron_adapters.openclaw.outbound',
        'JsonlOpenClawOutboundStore',
    ),
    'OpenClawOutboundResumeResult': (
        'sheltron_adapters.openclaw.outbound',
        'OpenClawOutboundResumeResult',
    ),
    'OutboundMessageStatus': ('sheltron_adapters.openclaw.outbound', 'OutboundMessageStatus'),
    'PendingOutboundMessage': ('sheltron_adapters.openclaw.outbound', 'PendingOutboundMessage'),
    'approval_status_for_outbound_message': (
        'sheltron_adapters.openclaw.outbound',
        'approval_status_for_outbound_message',
    ),
    'default_openclaw_outbound_store_path': (
        'sheltron_adapters.openclaw.outbound',
        'default_openclaw_outbound_store_path',
    ),
    'resolve_openclaw_outbound_store_path': (
        'sheltron_adapters.openclaw.outbound',
        'resolve_openclaw_outbound_store_path',
    ),
    'resume_openclaw_outbound_message': (
        'sheltron_adapters.openclaw.outbound',
        'resume_openclaw_outbound_message',
    ),
    'OPENCLAW_MAPPED_CANONICAL_TOOLS': (
        'sheltron_adapters.openclaw.tool_inventory',
        'OPENCLAW_MAPPED_CANONICAL_TOOLS',
    ),
    'canonical_openclaw_tool_name': (
        'sheltron_adapters.openclaw.tool_inventory',
        'canonical_openclaw_tool_name',
    ),
    'mapped_openclaw_tool_aliases': (
        'sheltron_adapters.openclaw.tool_inventory',
        'mapped_openclaw_tool_aliases',
    ),
    'OpenClawAttackHarness': ('sheltron_adapters.openclaw.attack_harness', 'OpenClawAttackHarness'),
}

__all__ = list(_EXPORTS)


def __getattr__(name: str) -> Any:
    try:
        module_name, attr_name = _EXPORTS[name]
    except KeyError as exc:
        raise AttributeError(f'module {__name__!r} has no attribute {name!r}') from exc
    value = getattr(import_module(module_name), attr_name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(__all__))
