from __future__ import annotations

OPENCLAW_TOOL_ALIASES: dict[str, str] = {
    'read': 'read_file',
    'read_file': 'read_file',
    'write': 'write_file',
    'write_file': 'write_file',
    'edit': 'edit_file',
    'edit_file': 'edit_file',
    'list_dir': 'list_dir',
    'list_directory': 'list_dir',
    'apply_patch': 'apply_patch',
    'exec': 'exec',
    'process': 'exec',
    'shell': 'exec',
    'web_search': 'web_search',
    'search_web': 'web_search',
    'web_fetch': 'web_fetch',
    'fetch_url': 'web_fetch',
    'sessions_send': 'sessions_send',
    'sessions_spawn': 'sessions_spawn',
    'sheltron_status': 'sheltron_status',
}

OPENCLAW_MAPPED_CANONICAL_TOOLS: frozenset[str] = frozenset(OPENCLAW_TOOL_ALIASES.values())


def canonical_openclaw_tool_name(raw_tool_name: str | None) -> str | None:
    if raw_tool_name is None:
        return None
    normalized = raw_tool_name.strip()
    if not normalized:
        return None
    return OPENCLAW_TOOL_ALIASES.get(normalized)


def mapped_openclaw_tool_aliases() -> tuple[str, ...]:
    return tuple(sorted(OPENCLAW_TOOL_ALIASES))


__all__ = [
    'OPENCLAW_MAPPED_CANONICAL_TOOLS',
    'OPENCLAW_TOOL_ALIASES',
    'canonical_openclaw_tool_name',
    'mapped_openclaw_tool_aliases',
]
