from __future__ import annotations

import os
from pathlib import Path

from sheltron_core import ApprovalStatus
from sheltron_core.schemas import Decision, PolicyResult
from sheltron_runtime import (
    SheltronGateway,
    CommandSpec,
    DirectoryListSpec,
    FetchSpec,
    FileEditSpec,
    FileReadSpec,
    FileWriteSpec,
    GuardResult,
    SearchSpec,
    ScheduledTaskSpec,
    SendMessageSpec,
)
from sheltron_runtime.approval_runtime import resolve_approval_requirement

from sheltron_adapters.openclaw.bridge_common import (
    BridgePayloadInput,
    OPENCLAW_PROMPT_CONTEXT,
    OpenClawBridgePayload,
    OpenClawBridgeDecision,
    allow_decision,
    approval_ticket_id,
    bootstrap_files,
    bootstrap_filter_result,
    bootstrap_provenance,
    build_bootstrap_gateway,
    build_gateway,
    command_from_params,
    coerce_bridge_payload,
    decision_from_result,
    first_int,
    first_string,
    intercept_memory_write,
    is_allowed_openclaw_bootstrap_path,
    is_openclaw_memory_target,
    load_bridge_payload,
    load_openclaw_install_state,
    message_provenance,
    normalize_openclaw_path,
    optional_path,
    patch_targets_durable_memory,
    serialize_bridge_decision,
    tool_call_provenance,
    tool_lifecycle_result,
    tool_name_from_payload,
    tool_params,
    tool_result_payload,
    transform_tool_result_payload,
)
from sheltron_adapters.openclaw.outbound import (
    OPENCLAW_OUTBOUND_REPLAY_ID_ENV,
    JsonlOpenClawOutboundStore,
    resolve_openclaw_outbound_store_path,
)
from sheltron_adapters.openclaw.tool_inventory import canonical_openclaw_tool_name


def evaluate_before_tool_call(
    payload: BridgePayloadInput,
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> OpenClawBridgeDecision:
    normalized_payload = coerce_bridge_payload(payload)
    gateway = build_gateway(
        state_path=state_path,
        workspace=workspace,
        approval_store_path=approval_store_path,
        audit_log_path=audit_log_path,
    )
    store = JsonlOpenClawOutboundStore(
        resolve_openclaw_outbound_store_path(workspace=gateway.workspace)
    )
    raw_tool_name = tool_name_from_payload(normalized_payload)
    ticket_id = approval_ticket_id(normalized_payload)
    if raw_tool_name is None:
        return _deny_tool_call(
            gateway,
            normalized_payload,
            tool_name='unknown_tool',
            code='openclaw_tool_name_missing',
            message='OpenClaw tool call is missing a stable tool name.',
        )
    tool_name = canonical_openclaw_tool_name(raw_tool_name)
    if tool_name is None:
        return _require_tool_call_approval(
            gateway,
            normalized_payload,
            tool_name=raw_tool_name,
            code='openclaw_tool_unmapped',
            message=(
                'This OpenClaw tool is not yet mapped into the Sheltron bridge. '
                'Continuing requires explicit approval.'
            ),
            approval_ticket_id=ticket_id,
        )
    if tool_name == 'sheltron_status':
        return allow_decision()
    provenance = tool_call_provenance(normalized_payload)
    params = tool_params(normalized_payload)

    if tool_name == 'read_file':
        path = first_string(params, 'path', 'file', 'filePath')
        if path is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw read tool payload is missing the target path.',
            )
        result = gateway.filesystem_guard.authorize_read_text(
            FileReadSpec(path=Path(path)),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'write_file':
        path = first_string(params, 'path', 'file', 'filePath')
        content = first_string(params, 'content', 'text', 'value')
        if path is None or content is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw write tool payload is missing a path or text content.',
            )
        if memory_decision := intercept_memory_write(
            gateway,
            tool_name=tool_name,
            normalized_path=normalize_openclaw_path(gateway, path),
            content=content,
            summary='OpenClaw durable memory write',
            provenance=provenance,
        ):
            return memory_decision
        result = gateway.filesystem_guard.authorize_write_text(
            FileWriteSpec(path=Path(path), content=content),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'edit_file':
        path = first_string(params, 'path', 'file', 'filePath')
        old_text = first_string(params, 'oldText', 'old_text', 'before')
        new_text = first_string(params, 'newText', 'new_text', 'after')
        if path is None or old_text is None or new_text is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw edit tool payload is missing the path or before/after text.',
            )
        normalized_path = normalize_openclaw_path(gateway, path)
        if is_openclaw_memory_target(normalized_path, gateway.workspace):
            if not normalized_path.exists():
                return _deny_tool_call(
                    gateway,
                    normalized_payload,
                    tool_name=tool_name,
                    code='openclaw_memory_target_missing',
                    message='The requested durable memory file does not exist for edit interception.',
                )
            current_text = normalized_path.read_text(encoding='utf-8')
            if old_text not in current_text:
                return _deny_tool_call(
                    gateway,
                    normalized_payload,
                    tool_name=tool_name,
                    code='openclaw_memory_edit_source_mismatch',
                    message='The requested old_text was not found in the durable memory file.',
                )
            updated_text = current_text.replace(old_text, new_text, 1)
            if memory_decision := intercept_memory_write(
                gateway,
                payload,
                tool_name=tool_name,
                normalized_path=normalized_path,
                content=updated_text,
                summary='OpenClaw durable memory edit',
                provenance=provenance,
            ):
                return memory_decision
        result = gateway.filesystem_guard.authorize_edit_text(
            FileEditSpec(path=Path(path), old_text=old_text, new_text=new_text),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'list_dir':
        path = first_string(params, 'path', 'dir', 'directory')
        if path is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw list-directory payload is missing the target path.',
            )
        result = gateway.filesystem_guard.authorize_list_directory(
            DirectoryListSpec(path=Path(path)),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'apply_patch':
        patch_text = first_string(params, 'patch', 'content', 'text', 'value')
        if patch_text is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw apply_patch payload is missing the patch text.',
            )
        if patch_targets_durable_memory(
            gateway,
            patch_text,
            cwd=optional_path(params, 'cwd', 'workingDirectory'),
        ):
            return _require_tool_call_approval(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_memory_patch_denied',
                message='Patch-based durable memory updates require explicit approval.',
                approval_ticket_id=ticket_id,
            )
        result = gateway.exec_guard.authorize_execute(
            CommandSpec(
                command=('bash', '-lc', 'apply_patch'),
                cwd=optional_path(params, 'cwd', 'workingDirectory'),
                stdin=patch_text,
            ),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'exec':
        command = command_from_params(params)
        if not command:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw exec payload is missing a command or argv vector.',
            )
        result = gateway.exec_guard.authorize_execute(
            CommandSpec(command=command, cwd=optional_path(params, 'cwd', 'workingDirectory')),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'web_search':
        query = first_string(params, 'query', 'q')
        if query is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw web-search payload is missing the query string.',
            )
        result = gateway.search_web(
            SearchSpec(
                query=query,
                count=first_int(params, 'count', 'limit') or 5,
                provider='openclaw',
                backend_kind='host_native',
            ),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'web_fetch':
        url = first_string(params, 'url', 'href')
        if url is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw fetch payload is missing the target URL.',
            )
        result = gateway.network_guard.authorize_fetch(
            FetchSpec(url=url),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    if tool_name == 'sessions_send':
        target_session = first_string(
            params,
            'sessionKey',
            'sessionId',
            'targetSessionKey',
            'targetSessionId',
            'target',
            'to',
        )
        message = first_string(params, 'message', 'content', 'text', 'body')
        if target_session is None or message is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw sessions_send payload is missing the target session or message.',
            )
        current_session = normalized_payload.first_string('sessionKey', 'session', 'session_id') or 'openclaw:unknown'
        result = gateway.send_message(
            SendMessageSpec(
                channel='openclaw_session',
                recipient=target_session,
                content=message,
                default_channel='openclaw_session',
                default_recipient=current_session,
            ),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        if result.policy_result.decision is Decision.REQUIRE_APPROVAL:
            primary_reason = result.policy_result.reasons[0]
            return OpenClawBridgeDecision(
                decision=Decision.REQUIRE_APPROVAL.value,
                reason=primary_reason.message,
                reason_code=primary_reason.code,
                matched_policy=result.policy_result.matched_policy,
                approval_ticket_id=result.policy_result.approval_ticket_id,
                blocked_result=gateway.serialize_blocked_result(result),
                hook_response=_approval_params_hook_response(
                    params,
                    content=_redacted_message_content(gateway, message),
                ),
            )
        if result.executed and result.value is not None and result.value.redacted:
            entry = store.create(
                source='sessions_send',
                session_id=current_session,
                channel='openclaw_session',
                recipient=target_session,
                default_channel='openclaw_session',
                default_recipient=current_session,
                original_content=message,
                deliver_content=result.value.content,
                provenance=provenance,
                approval_store_path=gateway.approval_store_path,
                reason_code='openclaw_sessions_send_resume_required',
            )
            return OpenClawBridgeDecision(
                decision=Decision.DENY.value,
                reason=(
                    'OpenClaw blocked the original sessions_send because Sheltron sanitized it. '
                    'Resume the exact sanitized send through `sheltron openclaw outbound resume`.'
                ),
                reason_code='openclaw_sessions_send_resume_required',
                matched_policy='openclaw_sessions_send_bridge',
                hook_response=_outbound_resume_hook_response(gateway, entry.outbound_id),
            )
        return decision_from_result(gateway, result)

    if tool_name == 'sessions_spawn':
        task = first_string(params, 'task', 'prompt', 'message')
        if task is None:
            return _deny_tool_call(
                gateway,
                normalized_payload,
                tool_name=tool_name,
                code='openclaw_tool_payload_unrecognized',
                message='OpenClaw sessions_spawn payload is missing the task text.',
            )
        current_session = normalized_payload.first_string('sessionKey', 'session', 'session_id') or 'openclaw:unknown'
        result = gateway.schedule_task(
            ScheduledTaskSpec(
                task_kind='spawn',
                action='sessions_spawn',
                task=task,
                label=first_string(params, 'label', 'name'),
                default_channel='openclaw_session',
                default_recipient=current_session,
            ),
            provenance=provenance,
            approval_ticket_id=ticket_id,
        )
        gateway.audit_result(result, outcome='openclaw_before_tool_call')
        return decision_from_result(gateway, result)

    return _require_tool_call_approval(
        gateway,
        normalized_payload,
        tool_name=raw_tool_name,
        code='openclaw_tool_unmapped',
        message=(
            'This OpenClaw tool is not yet mapped into the Sheltron bridge. '
            'Continuing requires explicit approval.'
        ),
        approval_ticket_id=ticket_id,
    )


def evaluate_message_sending(
    payload: BridgePayloadInput,
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> OpenClawBridgeDecision:
    normalized_payload = coerce_bridge_payload(payload)
    gateway = build_gateway(
        state_path=state_path,
        workspace=workspace,
        approval_store_path=approval_store_path,
        audit_log_path=audit_log_path,
    )
    store = JsonlOpenClawOutboundStore(
        resolve_openclaw_outbound_store_path(workspace=gateway.workspace)
    )
    session_id = normalized_payload.first_string('sessionKey', 'session', 'session_id') or 'openclaw:unknown'
    channel = normalized_payload.first_string('channel', 'channelId') or 'openclaw'
    recipient = normalized_payload.first_string('recipient', 'to', 'target', 'conversationId', 'chatId') or 'unknown'
    content = normalized_payload.first_string('content', 'text', 'message') or ''
    replay_entry = None
    replay_id = os.environ.get(OPENCLAW_OUTBOUND_REPLAY_ID_ENV)
    if replay_id:
        replay_entry = store.match_armed_by_id(
            outbound_id=replay_id,
            source='message_sending',
            session_id=session_id,
            channel=channel,
            recipient=recipient,
            content=content,
        )
    if replay_entry is not None:
        replay_result = gateway.send_message(
            SendMessageSpec(
                channel=replay_entry.channel,
                recipient=replay_entry.recipient,
                content=replay_entry.original_content,
                reply_to=replay_entry.reply_to,
                default_channel=replay_entry.default_channel,
                default_recipient=replay_entry.default_recipient,
            ),
            provenance=replay_entry.provenance,
            approval_ticket_id=replay_entry.approval_ticket_id,
        )
        gateway.audit_result(replay_result, outcome='openclaw_message_sending_replay')
        if replay_result.executed:
            store.mark_sent(replay_entry.outbound_id)
            return allow_decision()
        store.clear_arm(replay_entry.outbound_id)
        return decision_from_result(gateway, replay_result)

    provenance = message_provenance(normalized_payload)
    reply_to = normalized_payload.first_string('replyTo', 'reply_to')
    thread_id = normalized_payload.first_string('threadId', 'thread_id')
    account_id = normalized_payload.first_string('accountId', 'account_id')
    result = gateway.send_message(
        SendMessageSpec(
            channel=channel,
            recipient=recipient,
            content=content,
            reply_to=reply_to,
            default_channel=channel,
            default_recipient=recipient,
        ),
        provenance=provenance,
    )
    gateway.audit_result(result, outcome='openclaw_message_sending')
    if result.policy_result.decision is Decision.REQUIRE_APPROVAL:
        entry = store.create(
            source='message_sending',
            session_id=session_id,
            channel=channel,
            recipient=recipient,
            default_channel=channel,
            default_recipient=recipient,
            original_content=content,
            deliver_content=_redacted_message_content(gateway, content),
            provenance=provenance,
            approval_ticket_id=result.policy_result.approval_ticket_id,
            approval_store_path=gateway.approval_store_path,
            reason_code=result.policy_result.reasons[0].code,
            account_id=account_id,
            reply_to=reply_to,
            thread_id=thread_id,
        )
        primary_reason = result.policy_result.reasons[0]
        return OpenClawBridgeDecision(
            decision=Decision.REQUIRE_APPROVAL.value,
            reason=primary_reason.message,
            reason_code=primary_reason.code,
            matched_policy=result.policy_result.matched_policy,
            approval_ticket_id=result.policy_result.approval_ticket_id,
            blocked_result=gateway.serialize_blocked_result(result),
            hook_response=_outbound_resume_hook_response(gateway, entry.outbound_id),
        )
    if result.executed and result.value is not None and result.value.redacted:
        entry = store.create(
            source='message_sending',
            session_id=session_id,
            channel=channel,
            recipient=recipient,
            default_channel=channel,
            default_recipient=recipient,
            original_content=content,
            deliver_content=result.value.content,
            provenance=provenance,
            approval_store_path=gateway.approval_store_path,
            reason_code='openclaw_message_resume_required',
            account_id=account_id,
            reply_to=reply_to,
            thread_id=thread_id,
        )
        return OpenClawBridgeDecision(
            decision=Decision.DENY.value,
            reason=(
                'OpenClaw canceled the original outbound message because Sheltron sanitized it. '
                'Resume the exact sanitized send through `sheltron openclaw outbound resume`.'
            ),
            reason_code='openclaw_message_resume_required',
            matched_policy='openclaw_message_bridge',
            hook_response=_outbound_resume_hook_response(gateway, entry.outbound_id),
        )
    return decision_from_result(gateway, result)


def evaluate_tool_result_persist(
    payload: BridgePayloadInput,
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> OpenClawBridgeDecision:
    normalized_payload = coerce_bridge_payload(payload)
    gateway = build_gateway(
        state_path=state_path,
        workspace=workspace,
        approval_store_path=approval_store_path,
        audit_log_path=audit_log_path,
    )
    raw_tool_name = tool_name_from_payload(normalized_payload) or 'unknown_tool'
    tool_name = canonical_openclaw_tool_name(raw_tool_name) or raw_tool_name
    original_result = tool_result_payload(normalized_payload)
    transformed_result = transform_tool_result_payload(tool_name, original_result)
    result = tool_lifecycle_result(
        normalized_payload,
        tool_name=tool_name,
        hook_name='tool_result_persist',
        policy_result=PolicyResult.allow(
            'openclaw_tool_result_persist',
            code='tool_result_hardened' if transformed_result != original_result else 'tool_result_allowed',
            message=(
                'Persisted tool output was hardened before OpenClaw stored it.'
                if transformed_result != original_result
                else 'Persisted tool output was accepted without modification.'
            ),
        ),
        executed=True,
        value=transformed_result,
    )
    gateway.audit_result(
        result,
        result_summary=(
            f'persisted tool result hardened for {tool_name}'
            if transformed_result != original_result
            else f'persisted tool result allowed unchanged for {tool_name}'
        ),
        outcome='openclaw_tool_result_persist',
    )
    if transformed_result == original_result:
        return allow_decision()
    return OpenClawBridgeDecision(
        decision=Decision.ALLOW.value,
        hook_response={'result': transformed_result},
    )


def record_plugin_approval_resolution(
    payload: BridgePayloadInput,
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> OpenClawBridgeDecision:
    normalized_payload = coerce_bridge_payload(payload)
    gateway = build_gateway(
        state_path=state_path,
        workspace=workspace,
        approval_store_path=approval_store_path,
        audit_log_path=audit_log_path,
    )
    ticket_id = approval_ticket_id(normalized_payload)
    resolution = normalized_payload.first_string('resolution')
    reviewer_id = (
        normalized_payload.first_string('reviewerId', 'reviewer_id', 'deviceId', 'device_id')
        or 'openclaw_plugin_approval'
    )
    if ticket_id is None or resolution is None:
        return OpenClawBridgeDecision(
            decision=Decision.DENY.value,
            reason='OpenClaw plugin approval resolution payload is missing the ticket id or resolution.',
            reason_code='openclaw_plugin_approval_resolution_invalid',
            matched_policy='openclaw_plugin_approval_resolution',
        )

    ticket = gateway.approval_store.get(ticket_id)
    if ticket is None:
        return OpenClawBridgeDecision(
            decision=Decision.DENY.value,
            reason='OpenClaw plugin approval resolution referred to an unknown Sheltron approval ticket.',
            reason_code='openclaw_plugin_approval_ticket_missing',
            matched_policy='openclaw_plugin_approval_resolution',
        )
    if ticket.status is not ApprovalStatus.PENDING:
        return allow_decision()

    note = (
        f'OpenClaw plugin approval resolution: {resolution}'
        if resolution in {'allow-once', 'allow-always', 'deny'}
        else f'OpenClaw plugin approval ended without an explicit decision: {resolution}'
    )
    if resolution in {'allow-once', 'allow-always'}:
        gateway.approval_store.approve(ticket_id, reviewer_id=reviewer_id, note=note)
        return allow_decision()
    if resolution == 'deny':
        gateway.approval_store.reject(ticket_id, reviewer_id=reviewer_id, note=note)
        return allow_decision()
    gateway.approval_store.expire(ticket_id, note=note)
    return allow_decision()


def evaluate_agent_bootstrap(
    payload: BridgePayloadInput,
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> OpenClawBridgeDecision:
    normalized_payload = coerce_bridge_payload(payload)
    del approval_store_path
    gateway = build_bootstrap_gateway(
        state_path=state_path,
        workspace=workspace,
        audit_log_path=audit_log_path,
    )
    original_files = bootstrap_files(normalized_payload)
    filtered_files: list[str] = []
    dropped_files: list[str] = []

    for raw_path in original_files:
        candidate = Path(raw_path).expanduser().resolve(strict=False)
        if not is_allowed_openclaw_bootstrap_path(candidate, gateway.workspace):
            result = bootstrap_filter_result(
                normalized_payload,
                path=candidate,
                code='openclaw_bootstrap_path_not_allowed',
                message='Only canonical workspace bootstrap files may be injected into OpenClaw bootstrap.',
            )
            gateway.audit_result(
                result,
                outcome='openclaw_agent_bootstrap_dropped',
                result_summary='bootstrap candidate dropped before injection',
            )
            dropped_files.append(raw_path)
            continue
        if not candidate.exists() or not candidate.is_file():
            result = bootstrap_filter_result(
                normalized_payload,
                path=candidate,
                code='openclaw_bootstrap_path_missing',
                message='Bootstrap file does not exist as a regular file and was dropped before injection.',
            )
            gateway.audit_result(
                result,
                outcome='openclaw_agent_bootstrap_dropped',
                result_summary='bootstrap candidate dropped before injection',
            )
            dropped_files.append(raw_path)
            continue
        result = gateway.filesystem_guard.authorize_read_text(
            FileReadSpec(path=candidate),
            provenance=bootstrap_provenance(normalized_payload, candidate),
        )
        gateway.audit_result(result, outcome='openclaw_agent_bootstrap')
        if result.executed:
            filtered_files.append(str(candidate))
            continue
        dropped_files.append(raw_path)

    if tuple(filtered_files) == tuple(original_files):
        return allow_decision()
    return OpenClawBridgeDecision(
        decision=Decision.ALLOW.value,
        hook_response={
            'bootstrapFiles': filtered_files,
            'droppedBootstrapFiles': dropped_files,
        },
    )


def evaluate_before_prompt_build(
    payload: BridgePayloadInput,
    *,
    state_path: str | Path | None = None,
    workspace: str | Path | None = None,
    approval_store_path: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> OpenClawBridgeDecision:
    del payload, state_path, workspace, approval_store_path, audit_log_path
    return OpenClawBridgeDecision(
        decision=Decision.ALLOW.value,
        hook_response={'prependSystemContext': OPENCLAW_PROMPT_CONTEXT},
    )


def _deny_tool_call(
    gateway: SheltronGateway,
    payload: OpenClawBridgePayload,
    *,
    tool_name: str,
    code: str,
    message: str,
) -> OpenClawBridgeDecision:
    result = tool_lifecycle_result(
        payload,
        tool_name=tool_name,
        hook_name='before_tool_call',
        policy_result=PolicyResult.deny(
            'openclaw_bridge',
            code=code,
            message=message,
        ),
        executed=False,
    )
    gateway.audit_result(result, outcome='openclaw_before_tool_call')
    return decision_from_result(gateway, result)


def _require_tool_call_approval(
    gateway: SheltronGateway,
    payload: OpenClawBridgePayload,
    *,
    tool_name: str,
    code: str,
    message: str,
    approval_ticket_id: str | None,
) -> OpenClawBridgeDecision:
    base_result = tool_lifecycle_result(
        payload,
        tool_name=tool_name,
        hook_name='before_tool_call',
        policy_result=PolicyResult.require_approval(
            'openclaw_bridge',
            code=code,
            message=message,
        ),
        executed=False,
    )
    final_policy_result = resolve_approval_requirement(
        base_result.request,
        base_result.policy_result,
        approval_store=gateway.approval_store,
        approval_ticket_id=approval_ticket_id,
    )
    if final_policy_result.decision is Decision.ALLOW:
        result = GuardResult.completed(base_result.request, final_policy_result, None)
    else:
        result = GuardResult.rejected(base_result.request, final_policy_result)
    gateway.audit_result(result, outcome='openclaw_before_tool_call')
    return decision_from_result(gateway, result)

def _outbound_resume_hook_response(gateway: SheltronGateway, outbound_id: str) -> dict[str, str | bool]:
    return {
        'cancel': True,
        'pendingOutboundId': outbound_id,
        'outboundStore': str(resolve_openclaw_outbound_store_path(workspace=gateway.workspace)),
        'resumeCommand': f'sheltron openclaw outbound resume {outbound_id}',
    }


def _approval_params_hook_response(params: dict[str, object], *, content: str) -> dict[str, object]:
    for key in ('message', 'content', 'text', 'body'):
        if isinstance(params.get(key), str):
            return {'approvalParams': {key: content}}
    return {'approvalParams': {'message': content}}


def _redacted_message_content(gateway: SheltronGateway, content: str) -> str:
    redactor = gateway.message_guard.redactor
    if redactor is None:
        return content
    return redactor.redact_text(content)


__all__ = [
    'OpenClawBridgeDecision',
    'evaluate_agent_bootstrap',
    'evaluate_before_prompt_build',
    'evaluate_before_tool_call',
    'evaluate_message_sending',
    'evaluate_tool_result_persist',
    'load_bridge_payload',
    'load_openclaw_install_state',
    'serialize_bridge_decision',
]
