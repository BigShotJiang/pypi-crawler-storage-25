from __future__ import annotations

import argparse
import json
import sys

from sheltron_adapters.base import (
    HostAdapterProbe,
    HostInternalCommand,
    ParserSubcommands,
    ManagedHostCliAdapter,
)
from sheltron_adapters.openclaw.install import (
    SUPPORTED_OPENCLAW_PROFILES,
    SUPPORTED_OPENCLAW_INSTALL_MODES,
    OpenClawDisableResult,
    OpenClawDoctorReport,
    OpenClawEnableResult,
    OpenClawInstallResult,
    OpenClawInstallationTarget,
    OpenClawUninstallResult,
)


class OpenClawHostDelegate:
    name = 'openclaw'
    summary = 'manage OpenClaw through Sheltron'
    supported_profiles = SUPPORTED_OPENCLAW_PROFILES
    install_help = 'install the Sheltron-managed OpenClaw plugin and bootstrap hook'
    targets_help = 'list discovered OpenClaw installation targets on PATH'
    uninstall_help = 'remove the Sheltron-managed OpenClaw plugin and bootstrap hook'
    off_help = 'turn off global Sheltron enforcement for plain OpenClaw runs while keeping the dormant shim installed'
    on_help = 'turn on global Sheltron enforcement for plain OpenClaw runs'
    doctor_help = 'check whether OpenClaw is currently protected by Sheltron'
    status_help = 'print concise Sheltron protection status for OpenClaw'
    force_install_help = 'replace an existing Sheltron OpenClaw link state'
    no_targets_message = 'No OpenClaw installations found on PATH.'

    def add_target_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            '--openclaw-command',
            dest='openclaw_command_path',
            help='path to the user-facing openclaw command to manage',
        )
        parser.add_argument('--state-path', help='path to the Sheltron OpenClaw link state file')

    def add_install_arguments(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument(
            '--link-mode',
            dest='install_mode',
            default='direct',
            choices=SUPPORTED_OPENCLAW_INSTALL_MODES,
            help='OpenClaw link strategy: Sheltron direct asset link (default) or official plugin CLI',
        )

    def install(self, args: argparse.Namespace) -> OpenClawInstallResult:
        from sheltron_adapters.openclaw import install_openclaw

        return install_openclaw(
            profile=args.profile,
            install_mode=args.install_mode,
            openclaw_command_path=args.openclaw_command_path,
            state_path=args.state_path,
            force=args.force,
        )

    def emit_install_result(self, result: OpenClawInstallResult) -> None:
        print(f'Linked Sheltron OpenClaw profile `{result.state.profile}`.')
        print(f'Link mode: {result.state.install_mode}')
        if result.state.install_mode == 'official':
            print(
                'Official OpenClaw link mode can take longer because it shells through the OpenClaw '
                'plugin CLI. Use `sheltron link openclaw --link-mode direct` for faster link and unlink.'
            )
        print(f'OpenClaw command: {result.state.openclaw_command_path}')
        if sheltron_command_path := getattr(result.state, 'sheltron_command_path', None):
            print(f'Sheltron command: {sheltron_command_path}')
        print(f'Native plugin: {result.state.plugin_id}')
        print(f'Bootstrap hook: {result.state.bootstrap_hook_name}')
        print(f'State: {result.state_path}')
        if result.restart_required:
            print('Restart the OpenClaw Gateway to load the managed plugin and hook pack.')
        else:
            print('Global enforcement is off. Use `sheltron on openclaw` to protect plain `openclaw ...`.')

    def discover_targets(self) -> tuple[OpenClawInstallationTarget, ...]:
        from sheltron_adapters.openclaw import discover_openclaw_targets

        return discover_openclaw_targets()

    def serialize_target(self, target: OpenClawInstallationTarget) -> dict[str, object]:
        return target.model_dump(mode='json')

    def format_target(self, target: OpenClawInstallationTarget) -> str:
        return f'{target.command_path} {target.install_kind}'

    def uninstall(self, args: argparse.Namespace) -> OpenClawUninstallResult:
        from sheltron_adapters.openclaw import uninstall_openclaw

        return uninstall_openclaw(
            openclaw_command_path=args.openclaw_command_path,
            state_path=args.state_path,
        )

    def emit_uninstall_result(self, result: OpenClawUninstallResult) -> None:
        if getattr(result, 'already_uninstalled', False):
            print('Sheltron OpenClaw is already uninstalled. Nothing to remove.')
            print(f'State: {result.state_path}')
            return
        if getattr(result, 'cleaned_host_artifacts', False):
            print('Removed the Sheltron-managed OpenClaw plugin and bootstrap hook.')
            print(f'State: {result.state_path}')
            if result.restart_required:
                print('Restart the OpenClaw Gateway to unload the removed plugin and hook pack.')
            return
        print('Removed the Sheltron-managed OpenClaw plugin and bootstrap hook.')
        print(f'OpenClaw command: {result.openclaw_command_path}')
        print(f'State: {result.state_path}')
        if result.restart_required:
            print('Restart the OpenClaw Gateway to unload the removed plugin and hook pack.')

    def turn_off(self, args: argparse.Namespace) -> OpenClawDisableResult:
        from sheltron_adapters.openclaw import disable_openclaw

        return disable_openclaw(
            openclaw_command_path=args.openclaw_command_path,
            state_path=args.state_path,
        )

    def turn_on(self, args: argparse.Namespace) -> OpenClawEnableResult:
        from sheltron_adapters.openclaw import enable_openclaw

        return enable_openclaw(
            openclaw_command_path=args.openclaw_command_path,
            state_path=args.state_path,
        )

    def emit_activation_result(
        self,
        *,
        enabled: bool,
        result: OpenClawEnableResult | OpenClawDisableResult,
    ) -> None:
        state = 'on' if enabled else 'off'
        message = 'use global enforcement' if enabled else 'use dormant off mode'
        print(f'Turned Sheltron OpenClaw global enforcement {state}.')
        print(f'OpenClaw command: {result.state.openclaw_command_path}')
        print(f'State: {result.state_path}')
        if result.restart_required:
            print(f'Restart the OpenClaw Gateway to {message}.')

    def doctor(self, args: argparse.Namespace) -> OpenClawDoctorReport:
        from sheltron_adapters.openclaw import doctor_openclaw

        return doctor_openclaw(
            openclaw_command_path=args.openclaw_command_path,
            state_path=args.state_path,
        )

    def emit_doctor_report(self, report: OpenClawDoctorReport) -> None:
        print(f'Protection state: {report.protection_state.value}')
        for check in report.checks:
            print(f'{check.status.value.upper():<4} {check.name}: {check.detail}')

    def emit_status_report(self, report: OpenClawDoctorReport) -> None:
        print(f'Sheltron openclaw: {report.protection_state.value}')

    def internal_commands(self) -> tuple[HostInternalCommand, ...]:
        return (
            HostInternalCommand(
                name='outbound',
                register_parser=self._register_outbound_command,
                dispatch=self._dispatch_outbound_command,
            ),
            HostInternalCommand(
                name='bridge',
                register_parser=self._register_bridge_command,
                dispatch=self._dispatch_bridge_command,
            ),
            HostInternalCommand(
                name='bridge-server',
                register_parser=self._register_bridge_server_command,
                dispatch=self._dispatch_bridge_server_command,
            ),
        )

    def probe(self) -> HostAdapterProbe:
        try:
            targets = self.discover_targets()
        except Exception as exc:
            return HostAdapterProbe(
                name=self.name,
                summary=self.summary,
                bundled=True,
                importable=True,
                detected_targets=0,
                detail=f'probe failed: {exc}',
            )
        count = len(targets)
        detail = (
            f'{count} OpenClaw installation target(s) found on PATH.'
            if count
            else 'No OpenClaw installation targets found on PATH.'
        )
        return HostAdapterProbe(
            name=self.name,
            summary=self.summary,
            bundled=True,
            importable=True,
            detected_targets=count,
            detail=detail,
        )

    def dispatch_passthrough(self, argv: list[str], *, forced: bool = False) -> int:
        from sheltron_adapters.openclaw import run_openclaw_command

        openclaw_command_path: str | None = None
        state_path: str | None = None
        raw_args = list(argv)
        if forced:
            try:
                return run_openclaw_command(
                    openclaw_command_path=openclaw_command_path,
                    state_path=state_path,
                    command_args=raw_args,
                )
            except RuntimeError as exc:
                print(str(exc))
                return 1

        command_args: list[str] = []
        index = 0

        while index < len(raw_args):
            token = raw_args[index]
            if token == '--':
                command_args.extend(raw_args[index:])
                break
            if token == '--openclaw-command':
                if index + 1 >= len(raw_args):
                    print('missing value for `--openclaw-command`')
                    return 2
                openclaw_command_path = raw_args[index + 1]
                index += 2
                continue
            if token.startswith('--openclaw-command='):
                openclaw_command_path = token.split('=', 1)[1]
                index += 1
                continue
            if token == '--state-path':
                if index + 1 >= len(raw_args):
                    print('missing value for `--state-path`')
                    return 2
                state_path = raw_args[index + 1]
                index += 2
                continue
            if token.startswith('--state-path='):
                state_path = token.split('=', 1)[1]
                index += 1
                continue
            command_args.extend(raw_args[index:])
            break

        try:
            return run_openclaw_command(
                openclaw_command_path=openclaw_command_path,
                state_path=state_path,
                command_args=command_args,
            )
        except RuntimeError as exc:
            print(str(exc))
            return 1

    def _register_outbound_command(self, subparsers: ParserSubcommands) -> None:
        outbound_parser = subparsers.add_parser(
            'outbound',
            help='inspect and resume Sheltron-managed OpenClaw outbound messages',
        )
        outbound_subparsers = outbound_parser.add_subparsers(dest='openclaw_outbound_command')

        outbound_list_parser = outbound_subparsers.add_parser(
            'list',
            help='list pending or sent OpenClaw outbound messages',
        )
        outbound_list_parser.add_argument('--state-path', help='path to the Sheltron OpenClaw link state file')
        outbound_list_parser.add_argument(
            '--status',
            choices=['queued', 'armed', 'sent'],
            help='filter by outbound message status',
        )

        outbound_show_parser = outbound_subparsers.add_parser(
            'show',
            help='show one pending OpenClaw outbound message as JSON',
        )
        outbound_show_parser.add_argument('outbound_id')
        outbound_show_parser.add_argument('--state-path', help='path to the Sheltron OpenClaw link state file')

        outbound_resume_parser = outbound_subparsers.add_parser(
            'resume',
            help='resume one exact pending OpenClaw outbound message through the official message CLI',
        )
        outbound_resume_parser.add_argument('outbound_id')
        self.add_target_arguments(outbound_resume_parser)

    def _dispatch_outbound_command(self, args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
        from sheltron_adapters.openclaw import (
            JsonlOpenClawOutboundStore,
            OutboundMessageStatus,
            approval_status_for_outbound_message,
            resolve_openclaw_outbound_store_path,
            resume_openclaw_outbound_message,
        )

        store = JsonlOpenClawOutboundStore(resolve_openclaw_outbound_store_path(state_path=args.state_path))
        if args.openclaw_outbound_command == 'list':
            entries = store.list(
                status=None if args.status is None else OutboundMessageStatus(args.status)
            )
            if not entries:
                print('No OpenClaw outbound messages found.')
                return 0
            for entry in entries:
                approval = approval_status_for_outbound_message(entry)
                approval_label = approval.value if approval is not None else '-'
                confirmation_label = 'confirmed' if entry.bridge_confirmed else 'unconfirmed'
                print(
                    f'{entry.outbound_id} {entry.status.value} approval={approval_label} bridge={confirmation_label} '
                    f'{entry.channel} {entry.recipient} source={entry.source}'
                )
            return 0

        if args.openclaw_outbound_command == 'show':
            entry = store.get(args.outbound_id)
            if entry is None:
                print(f'OpenClaw outbound message not found: {args.outbound_id}')
                return 1
            payload = entry.model_dump(mode='json')
            approval = approval_status_for_outbound_message(entry)
            payload['approval_status'] = approval.value if approval is not None else None
            print(json.dumps(payload, indent=2, sort_keys=True))
            return 0

        if args.openclaw_outbound_command == 'resume':
            try:
                result = resume_openclaw_outbound_message(
                    args.outbound_id,
                    state_path=args.state_path,
                    openclaw_command_path=args.openclaw_command_path,
                )
            except (FileNotFoundError, KeyError, RuntimeError) as exc:
                print(str(exc))
                return 1
            print(f'{result.entry.outbound_id} -> {result.entry.status.value}')
            if result.command:
                print(' '.join(result.command))
            return 0

        parser.error('an openclaw outbound subcommand is required')
        return 2

    def _register_bridge_command(self, subparsers: ParserSubcommands) -> None:
        bridge_parser = subparsers.add_parser('bridge', help='internal bridge entrypoints for managed OpenClaw hooks')
        bridge_subparsers = bridge_parser.add_subparsers(dest='openclaw_bridge_command')

        for bridge_name, bridge_help in (
            ('before-tool-call', 'internal bridge entrypoint for OpenClaw before_tool_call hooks'),
            ('message-sending', 'internal bridge entrypoint for OpenClaw message_sending hooks'),
            ('tool-result-persist', 'internal bridge entrypoint for OpenClaw tool_result_persist hooks'),
            ('agent-bootstrap', 'internal bridge entrypoint for OpenClaw agent:bootstrap hooks'),
            ('before-prompt-build', 'internal bridge entrypoint for OpenClaw before_prompt_build hooks'),
        ):
            hidden_bridge_parser = bridge_subparsers.add_parser(bridge_name, help=bridge_help)
            hidden_bridge_parser.add_argument('--state-path')
            hidden_bridge_parser.add_argument('--workspace')
            hidden_bridge_parser.add_argument('--approval-store')
            hidden_bridge_parser.add_argument('--audit-log')

    def _dispatch_bridge_command(self, args: argparse.Namespace, parser: argparse.ArgumentParser) -> int:
        from sheltron_adapters.openclaw import (
            evaluate_agent_bootstrap,
            evaluate_before_prompt_build,
            evaluate_before_tool_call,
            evaluate_message_sending,
            evaluate_tool_result_persist,
            load_bridge_payload,
            serialize_bridge_decision,
        )

        payload = load_bridge_payload(sys.stdin.read())
        if args.openclaw_bridge_command == 'before-tool-call':
            decision = evaluate_before_tool_call(
                payload,
                state_path=args.state_path,
                workspace=args.workspace,
                approval_store_path=args.approval_store,
                audit_log_path=args.audit_log,
            )
            print(serialize_bridge_decision(decision))
            return 0
        if args.openclaw_bridge_command == 'message-sending':
            decision = evaluate_message_sending(
                payload,
                state_path=args.state_path,
                workspace=args.workspace,
                approval_store_path=args.approval_store,
                audit_log_path=args.audit_log,
            )
            print(serialize_bridge_decision(decision))
            return 0
        if args.openclaw_bridge_command == 'tool-result-persist':
            decision = evaluate_tool_result_persist(
                payload,
                state_path=args.state_path,
                workspace=args.workspace,
                approval_store_path=args.approval_store,
                audit_log_path=args.audit_log,
            )
            print(serialize_bridge_decision(decision))
            return 0
        if args.openclaw_bridge_command == 'agent-bootstrap':
            decision = evaluate_agent_bootstrap(
                payload,
                state_path=args.state_path,
                workspace=args.workspace,
                approval_store_path=args.approval_store,
                audit_log_path=args.audit_log,
            )
            print(serialize_bridge_decision(decision))
            return 0
        if args.openclaw_bridge_command == 'before-prompt-build':
            decision = evaluate_before_prompt_build(
                payload,
                state_path=args.state_path,
                workspace=args.workspace,
                approval_store_path=args.approval_store,
                audit_log_path=args.audit_log,
            )
            print(serialize_bridge_decision(decision))
            return 0
        parser.error('an openclaw bridge subcommand is required')
        return 2

    def _register_bridge_server_command(self, subparsers: ParserSubcommands) -> None:
        bridge_server_parser = subparsers.add_parser(
            'bridge-server',
            help='internal localhost bridge server for managed OpenClaw plugin and hook assets',
        )
        bridge_server_parser.add_argument('--state-path')
        bridge_server_parser.add_argument('--token', required=True)
        bridge_server_parser.add_argument('--ready-file')
        bridge_server_parser.add_argument('--host', default='127.0.0.1')
        bridge_server_parser.add_argument('--port', type=int, default=0)

    def _dispatch_bridge_server_command(self, args: argparse.Namespace, _parser: argparse.ArgumentParser) -> int:
        from sheltron_adapters.openclaw.bridge_server import run_openclaw_bridge_server

        return run_openclaw_bridge_server(
            state_path=args.state_path,
            token=args.token,
            ready_file=args.ready_file,
            host=args.host,
            port=args.port,
        )


OPENCLAW_CLI_ADAPTER = ManagedHostCliAdapter[
    OpenClawInstallationTarget,
    OpenClawInstallResult,
    OpenClawUninstallResult,
    OpenClawEnableResult | OpenClawDisableResult,
    OpenClawDoctorReport,
](OpenClawHostDelegate())


def build_openclaw_cli_adapter() -> ManagedHostCliAdapter[
    OpenClawInstallationTarget,
    OpenClawInstallResult,
    OpenClawUninstallResult,
    OpenClawEnableResult | OpenClawDisableResult,
    OpenClawDoctorReport,
]:
    return OPENCLAW_CLI_ADAPTER
