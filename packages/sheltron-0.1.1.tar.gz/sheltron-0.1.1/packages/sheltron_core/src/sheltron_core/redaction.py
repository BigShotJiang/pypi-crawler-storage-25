from __future__ import annotations

from collections.abc import Iterable


class SecretRedactor:
    def __init__(self, secrets: Iterable[str]) -> None:
        unique_secrets = {secret for secret in secrets if secret}
        self._secrets = tuple(sorted(unique_secrets, key=len, reverse=True))

    def redact_text(self, text: str) -> str:
        redacted = text
        for secret in self._secrets:
            redacted = redacted.replace(secret, '[REDACTED]')
        return redacted
