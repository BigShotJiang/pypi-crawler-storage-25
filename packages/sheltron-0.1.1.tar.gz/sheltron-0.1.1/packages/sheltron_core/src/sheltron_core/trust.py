from __future__ import annotations

from enum import Enum


class TrustLevel(str, Enum):
    SYSTEM = 'system'
    OWNER = 'owner'
    AUTHENTICATED_USER = 'authenticated_user'
    CHANNEL_METADATA = 'channel_metadata'
    MCP_TRUSTED = 'mcp_trusted'
    MCP_UNTRUSTED = 'mcp_untrusted'
    WEB_UNTRUSTED = 'web_untrusted'
    FILE_UNTRUSTED = 'file_untrusted'
    MODEL_INFERENCE = 'model_inference'
