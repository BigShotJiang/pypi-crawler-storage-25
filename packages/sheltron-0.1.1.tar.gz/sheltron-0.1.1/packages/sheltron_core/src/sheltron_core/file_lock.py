from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from threading import Lock
from typing import Iterator

try:
    import fcntl
except ImportError:  # pragma: no cover - non-Unix fallback
    fcntl = None

_LOCKS_GUARD = Lock()
_PATH_LOCKS: dict[str, Lock] = {}


def _resolve_lock_key(path: Path) -> str:
    return str(path.resolve(strict=False))


def _lock_file_path(path: Path) -> Path:
    return path.with_name(f'{path.name}.lock')


def _thread_lock_for(path: Path) -> Lock:
    key = _resolve_lock_key(path)
    with _LOCKS_GUARD:
        lock = _PATH_LOCKS.get(key)
        if lock is None:
            lock = Lock()
            _PATH_LOCKS[key] = lock
        return lock


@contextmanager
def locked_path(path: str | Path) -> Iterator[None]:
    target = Path(path)
    thread_lock = _thread_lock_for(target)
    thread_lock.acquire()
    handle = None
    try:
        if fcntl is not None:
            lock_path = _lock_file_path(target)
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            handle = lock_path.open('a+', encoding='utf-8')
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        yield
    finally:
        if handle is not None:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
            handle.close()
        thread_lock.release()
