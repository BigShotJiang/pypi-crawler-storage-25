from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from sheltron_core.defense import AutoDefenseRouter, DefenseRouter
from sheltron_core.resources import PathPolicyContext
from sheltron_core.schemas import ActionRequest, Capability, Decision, GuardAssessment, PolicyResult
from sheltron_core.trust import TrustLevel


@dataclass(slots=True)
class PolicyContext:
    path_policy: PathPolicyContext | None = None
    working_directory: Path | None = None
    guard_assessments: tuple[GuardAssessment, ...] = ()


class SafetyPolicy(Protocol):
    name: str

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        ...


@dataclass(slots=True)
class TrustBasedApprovalPolicy:
    risky_trust_levels: frozenset[TrustLevel] = field(
        default_factory=lambda: frozenset(
            {
                TrustLevel.MCP_UNTRUSTED,
                TrustLevel.WEB_UNTRUSTED,
                TrustLevel.FILE_UNTRUSTED,
                TrustLevel.MODEL_INFERENCE,
            }
        )
    )
    approval_capabilities: frozenset[Capability] = field(
        default_factory=lambda: frozenset(
            {
                Capability.EXEC,
                Capability.NETWORK_POST,
                Capability.SEND_MESSAGE,
                Capability.MEMORY_WRITE,
                Capability.SCHEDULE_TASK,
                Capability.READ_SECRET,
            }
        )
    )
    name: str = 'trust_based_approval'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability not in self.approval_capabilities:
            return None
        matched_trust_levels = tuple(
            trust_level.value
            for trust_level in request.provenance.source_trust_levels
            if trust_level in self.risky_trust_levels
        )
        if not matched_trust_levels:
            return None
        return PolicyResult.require_approval(
            self.name,
            code='untrusted_provenance_requires_approval',
            message='This action is sourced from untrusted or model-derived content and requires approval.',
            details={'trust_levels': matched_trust_levels},
        )


@dataclass(slots=True)
class PolicyEngine:
    policies: tuple[SafetyPolicy, ...]
    defense_router: DefenseRouter
    name: str = 'policy_engine'

    def __init__(
        self,
        policies: tuple[SafetyPolicy, ...] | list[SafetyPolicy],
        *,
        defense_router: DefenseRouter | None = None,
    ) -> None:
        self.policies = tuple(policies)
        self.defense_router = AutoDefenseRouter() if defense_router is None else defense_router
        self.name = 'policy_engine'

    def evaluate(self, request: ActionRequest, context: PolicyContext | None = None) -> PolicyResult:
        context = context or PolicyContext()
        guard_assessments = self._collect_guard_assessments(request, context)
        if guard_assessments:
            context.guard_assessments = guard_assessments
        allow_result: PolicyResult | None = None
        approval_result: PolicyResult | None = None

        for policy in self.policies:
            result = policy.evaluate(request, context)
            if result is None:
                continue
            if result.decision is Decision.DENY:
                return self._attach_guard_assessments(result, guard_assessments)
            if result.decision is Decision.REQUIRE_APPROVAL and approval_result is None:
                approval_result = result
                continue
            if result.decision is Decision.ALLOW and allow_result is None:
                allow_result = result

        if approval_result is not None:
            return self._attach_guard_assessments(approval_result, guard_assessments)
        guard_result = self._result_from_guard_assessments(guard_assessments)
        if guard_result is not None:
            return guard_result
        if allow_result is not None:
            return self._attach_guard_assessments(allow_result, guard_assessments)
        return PolicyResult.deny(
            self.name,
            code='default_deny',
            message='No policy explicitly allowed this request.',
            details={'request_id': request.request_id},
            guard_assessments=guard_assessments,
        )

    def _collect_guard_assessments(
        self,
        request: ActionRequest,
        context: PolicyContext,
    ) -> tuple[GuardAssessment, ...]:
        assessments: list[GuardAssessment] = []
        for backend in self.defense_router.route(request, context):
            assessment = backend.assess(request, context)
            if assessment is None:
                continue
            assessments.append(assessment)
        return tuple(assessments)

    @staticmethod
    def _attach_guard_assessments(
        result: PolicyResult,
        guard_assessments: tuple[GuardAssessment, ...],
    ) -> PolicyResult:
        if not guard_assessments:
            return result
        if result.guard_assessments == guard_assessments:
            return result
        return result.model_copy(update={'guard_assessments': guard_assessments})

    @staticmethod
    def _result_from_guard_assessments(
        guard_assessments: tuple[GuardAssessment, ...],
    ) -> PolicyResult | None:
        deny_assessment = next(
            (assessment for assessment in guard_assessments if assessment.recommended_decision is Decision.DENY),
            None,
        )
        if deny_assessment is not None:
            return PolicyResult.deny(
                'guard_backend',
                code='guard_backend_denied',
                message='A configured guard backend denied this request.',
                details={
                    'backend': deny_assessment.backend,
                    'labels': deny_assessment.labels,
                    'confidence': deny_assessment.confidence,
                    'reasons': deny_assessment.reasons,
                },
                guard_assessments=guard_assessments,
            )
        approval_assessment = next(
            (
                assessment
                for assessment in guard_assessments
                if assessment.recommended_decision is Decision.REQUIRE_APPROVAL
            ),
            None,
        )
        if approval_assessment is not None:
            return PolicyResult.require_approval(
                'guard_backend',
                code='guard_backend_requires_approval',
                message='A configured guard backend requires explicit approval for this request.',
                details={
                    'backend': approval_assessment.backend,
                    'labels': approval_assessment.labels,
                    'confidence': approval_assessment.confidence,
                    'reasons': approval_assessment.reasons,
                },
                guard_assessments=guard_assessments,
            )
        return None
