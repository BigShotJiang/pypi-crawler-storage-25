from __future__ import annotations

import os
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field


def normalize_user_path(raw_path: str | Path, *, cwd: Path | None = None, fallback_base: Path | None = None) -> Path:
    expanded = Path(os.path.expandvars(str(raw_path))).expanduser()
    if expanded.is_absolute():
        candidate = expanded
    else:
        base = cwd or fallback_base or Path.cwd()
        candidate = base / expanded
    return candidate.resolve(strict=False)


def _canonicalize_config_path(path: Path) -> Path:
    return Path(path).expanduser().resolve(strict=False)


def _path_matches(path: Path, target: Path) -> bool:
    return path == target or path.is_relative_to(target)


class PathAssessment(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra='forbid')

    normalized_path: Path
    within_workspace: bool
    protected: bool
    approval_required: bool
    secret: bool


class PathPolicyContext(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra='forbid')

    workspace_roots: tuple[Path, ...]
    protected_paths: tuple[Path, ...] = Field(default_factory=tuple)
    approval_required_paths: tuple[Path, ...] = Field(default_factory=tuple)
    secret_paths: tuple[Path, ...] = Field(default_factory=tuple)

    def assess_path(self, raw_path: str | Path, *, cwd: Path | None = None) -> PathAssessment:
        normalized_workspace_roots = tuple(_canonicalize_config_path(path) for path in self.workspace_roots)
        normalized_protected_paths = tuple(_canonicalize_config_path(path) for path in self.protected_paths)
        normalized_approval_required_paths = tuple(
            _canonicalize_config_path(path) for path in self.approval_required_paths
        )
        normalized_secret_paths = tuple(_canonicalize_config_path(path) for path in self.secret_paths)
        fallback_base = normalized_workspace_roots[0] if normalized_workspace_roots else None
        normalized_path = normalize_user_path(raw_path, cwd=cwd, fallback_base=fallback_base)
        within_workspace = any(_path_matches(normalized_path, root) for root in normalized_workspace_roots)
        protected = any(_path_matches(normalized_path, path) for path in normalized_protected_paths)
        approval_required = any(
            _path_matches(normalized_path, path) for path in normalized_approval_required_paths
        )
        secret = any(_path_matches(normalized_path, path) for path in normalized_secret_paths)
        return PathAssessment(
            normalized_path=normalized_path,
            within_workspace=within_workspace,
            protected=protected,
            approval_required=approval_required,
            secret=secret,
        )

    def normalize_path(self, raw_path: str | Path, *, cwd: Path | None = None) -> Path:
        return self.assess_path(raw_path, cwd=cwd).normalized_path

    def is_within_workspace(self, raw_path: str | Path, *, cwd: Path | None = None) -> bool:
        return self.assess_path(raw_path, cwd=cwd).within_workspace

    def is_protected(self, raw_path: str | Path, *, cwd: Path | None = None) -> bool:
        return self.assess_path(raw_path, cwd=cwd).protected

    def is_secret(self, raw_path: str | Path, *, cwd: Path | None = None) -> bool:
        return self.assess_path(raw_path, cwd=cwd).secret
