from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from sheltron_core.file_lock import locked_path
from sheltron_core.schemas import ActionRequest, PolicyResult


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def default_audit_log_path() -> Path:
    return Path.home() / '.sheltron' / 'audit.jsonl'


def default_workspace_audit_log_path(workspace: str | Path) -> Path:
    return Path(workspace).expanduser().resolve(strict=False) / '.sheltron' / 'audit.jsonl'


class AuditRecord(BaseModel):
    model_config = ConfigDict(extra='forbid')

    event_id: str
    occurred_at: datetime = Field(default_factory=_utcnow)
    system: str
    session_id: str
    capability: str
    resource: str
    decision: str
    reason_code: str
    reason: str
    trust_inputs: tuple[str, ...] = Field(default_factory=tuple)
    approval_id: str | None = None
    result_summary: str | None = None
    request: ActionRequest
    result: PolicyResult
    outcome: str = 'policy_decision'
    redactions: tuple[str, ...] = Field(default_factory=tuple)


def build_audit_record(
    *,
    system: str,
    request: ActionRequest,
    result: PolicyResult,
    outcome: str = 'policy_decision',
    result_summary: str | None = None,
    redactions: tuple[str, ...] = (),
    event_id: str | None = None,
    occurred_at: datetime | None = None,
) -> AuditRecord:
    primary_reason = result.reasons[0]
    return AuditRecord(
        event_id=event_id or f'audit-{uuid4().hex}',
        occurred_at=occurred_at or _utcnow(),
        system=system,
        session_id=request.provenance.session_id,
        capability=request.capability.value,
        resource=request.resource.locator,
        decision=result.decision.value,
        reason_code=primary_reason.code,
        reason=primary_reason.message,
        trust_inputs=tuple(level.value for level in request.provenance.source_trust_levels),
        approval_id=result.approval_ticket_id,
        result_summary=result_summary,
        request=request,
        result=result,
        outcome=outcome,
        redactions=redactions,
    )


class JsonlAuditLogger:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else default_audit_log_path()

    def serialize(self, record: AuditRecord) -> str:
        return record.model_dump_json()

    def deserialize(self, payload: str) -> AuditRecord:
        return AuditRecord.model_validate_json(payload)

    def append(self, record: AuditRecord) -> None:
        with locked_path(self.path):
            self.path.parent.mkdir(parents=True, exist_ok=True)
            with self.path.open('a', encoding='utf-8') as handle:
                handle.write(self.serialize(record))
                handle.write('\n')

    def read(self, *, since: datetime | None = None) -> list[AuditRecord]:
        with locked_path(self.path):
            records = self._read_unlocked()
        if since is None:
            return records
        return [record for record in records if record.occurred_at >= since]

    def tail(self, *, limit: int = 20, since: datetime | None = None) -> list[AuditRecord]:
        if limit <= 0:
            return []
        records = self.read(since=since)
        return records[-limit:]

    def get(self, event_id: str) -> AuditRecord | None:
        with locked_path(self.path):
            for record in self._read_unlocked():
                if record.event_id == event_id:
                    return record
        return None

    def _read_unlocked(self) -> list[AuditRecord]:
        if not self.path.exists():
            return []
        records: list[AuditRecord] = []
        with self.path.open('r', encoding='utf-8') as handle:
            for line in handle:
                payload = line.strip()
                if not payload:
                    continue
                records.append(self.deserialize(payload))
        return records
