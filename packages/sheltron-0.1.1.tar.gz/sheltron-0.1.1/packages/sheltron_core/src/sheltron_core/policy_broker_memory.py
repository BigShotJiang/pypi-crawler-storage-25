from __future__ import annotations

from dataclasses import dataclass

from sheltron_core.policy_engine import PolicyContext
from sheltron_core.schemas import ActionRequest, Capability, PolicyResult, ResourceKind
from sheltron_core.trust import TrustLevel

_TOOL_BROKER_CAPABILITIES = frozenset({Capability.MCP_BROKER_CALL, Capability.TOOL_BROKER_CALL})
_TOOL_BROKER_RESOURCE_KINDS = frozenset({ResourceKind.MCP_TOOL, ResourceKind.TOOL_TARGET})


@dataclass(slots=True)
class DownstreamMcpAccessPolicy:
    name: str = 'downstream_mcp_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability not in _TOOL_BROKER_CAPABILITIES:
            return None
        if request.resource.kind not in _TOOL_BROKER_RESOURCE_KINDS:
            return None

        namespaced_tool = request.resource.locator
        server_name = request.parameters.get('server_name')
        tool_name = request.parameters.get('tool_name')
        tool_known = bool(request.parameters.get('tool_known'))
        server_allowed = bool(request.parameters.get('server_allowed'))
        enabled = bool(request.parameters.get('enabled'))
        trust_level_raw = request.parameters.get('trust_level')
        details = {'namespaced_tool': namespaced_tool}

        if not isinstance(server_name, str) or not server_name:
            return PolicyResult.deny(
                self.name,
                code='downstream_mcp_server_missing',
                message='Brokered MCP calls require a normalized downstream server name.',
                details=details,
            )
        if not isinstance(tool_name, str) or not tool_name:
            return PolicyResult.deny(
                self.name,
                code='downstream_mcp_tool_missing',
                message='Brokered MCP calls require a normalized downstream tool name.',
                details={**details, 'server_name': server_name},
            )
        if not tool_known:
            return PolicyResult.deny(
                self.name,
                code='unknown_downstream_mcp_tool',
                message='The requested downstream MCP tool is not registered with this broker.',
                details={**details, 'server_name': server_name, 'tool_name': tool_name},
            )
        if not enabled:
            return PolicyResult.deny(
                self.name,
                code='downstream_mcp_tool_disabled',
                message='The requested downstream MCP tool is disabled.',
                details={**details, 'server_name': server_name, 'tool_name': tool_name},
            )
        if not server_allowed:
            return PolicyResult.deny(
                self.name,
                code='downstream_mcp_server_not_allowed',
                message='The requested downstream MCP server is not allowed by this broker.',
                details={**details, 'server_name': server_name, 'tool_name': tool_name},
            )
        try:
            trust_level = TrustLevel(str(trust_level_raw))
        except ValueError:
            return PolicyResult.deny(
                self.name,
                code='downstream_mcp_trust_invalid',
                message='Brokered MCP calls require a valid downstream trust level.',
                details={**details, 'server_name': server_name, 'tool_name': tool_name},
            )
        if trust_level is TrustLevel.MCP_UNTRUSTED:
            return PolicyResult.require_approval(
                self.name,
                code='downstream_mcp_untrusted_requires_approval',
                message='Calling an untrusted downstream MCP tool requires explicit approval.',
                details={
                    **details,
                    'server_name': server_name,
                    'tool_name': tool_name,
                    'trust_level': trust_level.value,
                },
            )
        return PolicyResult.allow(
            self.name,
            code='downstream_mcp_allowed',
            message='The downstream MCP tool is registered and allowed by the current broker policy.',
            details={
                **details,
                'server_name': server_name,
                'tool_name': tool_name,
                'trust_level': trust_level.value,
            },
        )


@dataclass(slots=True)
class MemoryWritePolicy:
    max_content_chars: int = 32_000
    name: str = 'memory_write'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability is not Capability.MEMORY_WRITE:
            return None
        if request.resource.kind is not ResourceKind.MEMORY_KEY:
            return None

        key = request.resource.locator
        content_chars = request.parameters.get('content_chars')
        mode = request.parameters.get('mode')
        suspicious_token_count = request.parameters.get('suspicious_token_count')
        suspicious_token_matches = request.parameters.get('suspicious_token_matches')
        suspicious_instruction_count = request.parameters.get('suspicious_instruction_count')
        suspicious_instruction_matches = request.parameters.get('suspicious_instruction_matches')
        private_key_markers = request.parameters.get('private_key_markers')
        details = {
            'key': key,
            'mode': mode,
        }

        if not isinstance(key, str) or not key:
            return PolicyResult.deny(
                self.name,
                code='memory_key_missing',
                message='Candidate memory writes require a normalized memory key.',
                details=details,
            )
        if not isinstance(content_chars, int) or content_chars <= 0:
            return PolicyResult.deny(
                self.name,
                code='memory_content_missing',
                message='Candidate memory writes require non-empty content.',
                details=details,
            )
        if mode not in {'replace', 'append'}:
            return PolicyResult.deny(
                self.name,
                code='memory_mode_invalid',
                message='Candidate memory writes require a valid write mode.',
                details=details,
            )
        if content_chars > self.max_content_chars:
            return PolicyResult.deny(
                self.name,
                code='memory_too_large',
                message='Candidate memory writes that exceed the configured size limit are denied.',
                details={**details, 'content_chars': content_chars, 'max_content_chars': self.max_content_chars},
            )
        if (
            isinstance(suspicious_token_count, int)
            and suspicious_token_count > 0
            or isinstance(suspicious_instruction_count, int)
            and suspicious_instruction_count > 0
            or isinstance(private_key_markers, (tuple, list))
            and len(private_key_markers) > 0
        ):
            return PolicyResult.require_approval(
                self.name,
                code='suspicious_memory_requires_approval',
                message='This memory candidate contains suspicious instructions or sensitive material and requires approval.',
                details={
                    **details,
                    'suspicious_token_matches': tuple(suspicious_token_matches or ()),
                    'suspicious_instruction_matches': tuple(suspicious_instruction_matches or ()),
                    'private_key_markers': tuple(private_key_markers or ()),
                },
            )
        return PolicyResult.allow(
            self.name,
            code='candidate_memory_allowed',
            message='The candidate memory write passed the current memory policy.',
            details=details,
        )
