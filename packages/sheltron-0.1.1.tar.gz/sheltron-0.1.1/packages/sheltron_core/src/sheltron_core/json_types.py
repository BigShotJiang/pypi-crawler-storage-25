from __future__ import annotations

from typing import TypeAlias, TypeGuard

JsonPrimitive: TypeAlias = str | int | float | bool | None
JsonValue: TypeAlias = JsonPrimitive | dict[str, 'JsonValue'] | list['JsonValue']
JsonObject: TypeAlias = dict[str, JsonValue]


def is_json_value(value: object) -> TypeGuard[JsonValue]:
    if value is None or isinstance(value, (str, int, float, bool)):
        return True
    if isinstance(value, list):
        return all(is_json_value(item) for item in value)
    if isinstance(value, dict):
        return all(isinstance(key, str) and is_json_value(item) for key, item in value.items())
    return False


def is_json_object(value: object) -> TypeGuard[JsonObject]:
    return isinstance(value, dict) and all(isinstance(key, str) and is_json_value(item) for key, item in value.items())


def json_object_or_none(value: object) -> JsonObject | None:
    if is_json_object(value):
        return value
    return None


def require_json_value(value: object, *, context: str) -> JsonValue:
    if not is_json_value(value):
        raise TypeError(f'{context} must stay JSON-serializable.')
    return value
