from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any

from typing_extensions import NotRequired, TypedDict

from pydantic import BaseModel, ConfigDict, Field, field_validator

from sheltron_core.trust import TrustLevel


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


_MAX_EVIDENCE_REFERENCE_CHARS = 512


def _truncate_optional_text(value: str | None, *, max_chars: int) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    if not normalized:
        return None
    if len(normalized) <= max_chars:
        return normalized
    return normalized[: max_chars - 3] + '...'


class Capability(str, Enum):
    READ_FILE = 'read_file'
    WRITE_FILE = 'write_file'
    EDIT_FILE = 'edit_file'
    EXEC = 'exec'
    SEARCH_WEB = 'search_web'
    NETWORK_FETCH = 'network_fetch'
    NETWORK_POST = 'network_post'
    SEND_MESSAGE = 'send_message'
    MEMORY_WRITE = 'memory_write'
    SCHEDULE_TASK = 'schedule_task'
    TOOL_BROKER_CALL = 'tool_broker_call'
    MCP_BROKER_CALL = 'mcp_broker_call'
    INSTALL_SKILL = 'install_skill'
    MODIFY_BOOTSTRAP = 'modify_bootstrap'
    READ_SECRET = 'read_secret'


class Decision(str, Enum):
    ALLOW = 'allow'
    DENY = 'deny'
    REQUIRE_APPROVAL = 'require_approval'


class ResourceKind(str, Enum):
    FILE_PATH = 'file_path'
    COMMAND = 'command'
    SEARCH_QUERY = 'search_query'
    URL = 'url'
    MESSAGE_TARGET = 'message_target'
    MEMORY_KEY = 'memory_key'
    TASK_TARGET = 'task_target'
    TOOL_TARGET = 'tool_target'
    MCP_TOOL = 'mcp_tool'


class Evidence(BaseModel):
    model_config = ConfigDict(extra='forbid')

    source: str
    reference: str | None = None
    snippet: str | None = None

    @field_validator('reference', mode='before')
    @classmethod
    def _normalize_reference(cls, value: object) -> object:
        if value is None or isinstance(value, str):
            return _truncate_optional_text(value, max_chars=_MAX_EVIDENCE_REFERENCE_CHARS)
        return value


class ForwardedEvidenceClaim(TypedDict):
    source: str
    snippet: str
    reference: NotRequired[str | None]


class Provenance(BaseModel):
    model_config = ConfigDict(extra='forbid')

    session_id: str
    channel: str
    actor_id: str
    source_trust_levels: tuple[TrustLevel, ...] = Field(default_factory=tuple)
    evidence: tuple[Evidence, ...] = Field(default_factory=tuple)
    trigger: str


class ResourceDescriptor(BaseModel):
    model_config = ConfigDict(extra='forbid')

    kind: ResourceKind
    locator: str
    display_name: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ActionRequest(BaseModel):
    model_config = ConfigDict(extra='forbid')

    request_id: str
    capability: Capability
    resource: ResourceDescriptor
    provenance: Provenance
    parameters: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=_utcnow)


class PolicyReason(BaseModel):
    model_config = ConfigDict(extra='forbid')

    code: str
    message: str
    details: dict[str, Any] = Field(default_factory=dict)


class GuardAssessment(BaseModel):
    model_config = ConfigDict(extra='forbid')

    backend: str
    recommended_decision: Decision | None = None
    labels: tuple[str, ...] = Field(default_factory=tuple)
    confidence: float | None = None
    reasons: tuple[str, ...] = Field(default_factory=tuple)
    details: dict[str, Any] = Field(default_factory=dict)


class PolicyResult(BaseModel):
    model_config = ConfigDict(extra='forbid')

    decision: Decision
    reasons: tuple[PolicyReason, ...]
    matched_policy: str
    approval_ticket_id: str | None = None
    guard_assessments: tuple[GuardAssessment, ...] = Field(default_factory=tuple)

    @classmethod
    def allow(
        cls,
        matched_policy: str,
        *,
        code: str,
        message: str,
        details: dict[str, Any] | None = None,
        guard_assessments: tuple[GuardAssessment, ...] = (),
    ) -> 'PolicyResult':
        return cls(
            decision=Decision.ALLOW,
            reasons=(PolicyReason(code=code, message=message, details=details or {}),),
            matched_policy=matched_policy,
            guard_assessments=guard_assessments,
        )

    @classmethod
    def deny(
        cls,
        matched_policy: str,
        *,
        code: str,
        message: str,
        details: dict[str, Any] | None = None,
        guard_assessments: tuple[GuardAssessment, ...] = (),
    ) -> 'PolicyResult':
        return cls(
            decision=Decision.DENY,
            reasons=(PolicyReason(code=code, message=message, details=details or {}),),
            matched_policy=matched_policy,
            guard_assessments=guard_assessments,
        )

    @classmethod
    def require_approval(
        cls,
        matched_policy: str,
        *,
        code: str,
        message: str,
        details: dict[str, Any] | None = None,
        approval_ticket_id: str | None = None,
        guard_assessments: tuple[GuardAssessment, ...] = (),
    ) -> 'PolicyResult':
        return cls(
            decision=Decision.REQUIRE_APPROVAL,
            reasons=(PolicyReason(code=code, message=message, details=details or {}),),
            matched_policy=matched_policy,
            approval_ticket_id=approval_ticket_id,
            guard_assessments=guard_assessments,
        )
