from __future__ import annotations

from dataclasses import dataclass, field

from sheltron_core.policy_engine import PolicyContext
from sheltron_core.schemas import ActionRequest, Capability, PolicyResult, ResourceKind


@dataclass(slots=True)
class CapabilityAllowlistPolicy:
    allowed_capabilities: frozenset[Capability]
    name: str = 'capability_allowlist'

    def __init__(self, allowed_capabilities: set[Capability] | frozenset[Capability]) -> None:
        self.allowed_capabilities = frozenset(allowed_capabilities)
        self.name = 'capability_allowlist'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability not in self.allowed_capabilities:
            return PolicyResult.require_approval(
                self.name,
                code='capability_not_allowed',
                message=f'Capability {request.capability.value} is not allowed by the current profile.',
                details={'capability': request.capability.value},
            )
        return PolicyResult.allow(
            self.name,
            code='capability_allowed',
            message=f'Capability {request.capability.value} is allowed by the current profile.',
            details={'capability': request.capability.value},
        )


@dataclass(slots=True)
class PathAccessPolicy:
    name: str = 'path_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        if request.resource.kind is not ResourceKind.FILE_PATH:
            return None
        if context.path_policy is None:
            return PolicyResult.deny(
                self.name,
                code='path_policy_missing',
                message='Filesystem access was requested without a configured path policy context.',
            )

        assessment = context.path_policy.assess_path(
            request.resource.locator,
            cwd=context.working_directory,
        )
        details = {'path': str(assessment.normalized_path)}

        if assessment.protected and assessment.approval_required:
            if request.capability is Capability.READ_FILE:
                return PolicyResult.allow(
                    self.name,
                    code='protected_path_read_allowed',
                    message='The requested managed path may be read directly.',
                    details=details,
                )
            return PolicyResult.require_approval(
                self.name,
                code='protected_path_requires_approval',
                message='The requested path is managed and requires explicit approval for direct modification.',
                details=details,
            )
        if assessment.protected:
            return PolicyResult.require_approval(
                self.name,
                code='protected_path_requires_approval',
                message='The requested path is protected and requires explicit approval.',
                details=details,
            )
        if assessment.secret and request.capability is Capability.READ_SECRET:
            return PolicyResult.require_approval(
                self.name,
                code='secret_read_requires_approval',
                message='Reading a configured secret path requires explicit approval.',
                details=details,
            )
        if assessment.secret:
            return PolicyResult.require_approval(
                self.name,
                code='secret_capability_required',
                message='Secret paths require explicit approval when accessed without the read_secret capability.',
                details=details,
            )
        if not assessment.within_workspace:
            return PolicyResult.require_approval(
                self.name,
                code='path_outside_workspace',
                message='The requested path escapes the configured workspace roots and requires approval.',
                details=details,
            )
        return PolicyResult.allow(
            self.name,
            code='path_allowed',
            message='The requested path is inside the workspace and not marked protected.',
            details=details,
        )


@dataclass(slots=True)
class WorkingDirectoryAccessPolicy:
    name: str = 'working_directory_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        if request.capability is not Capability.EXEC:
            return None
        if request.resource.kind is not ResourceKind.COMMAND:
            return None
        if context.path_policy is None:
            return PolicyResult.deny(
                self.name,
                code='path_policy_missing',
                message='Command execution was requested without a configured path policy context.',
            )

        raw_cwd = request.parameters.get('cwd')
        if not isinstance(raw_cwd, str) or not raw_cwd:
            return PolicyResult.deny(
                self.name,
                code='cwd_missing',
                message='Command execution requires a normalized working directory.',
            )

        assessment = context.path_policy.assess_path(raw_cwd, cwd=context.working_directory)
        details = {'cwd': str(assessment.normalized_path)}

        if assessment.protected:
            return PolicyResult.require_approval(
                self.name,
                code='protected_working_directory',
                message='The requested working directory is protected and requires approval for command execution.',
                details=details,
            )
        if assessment.secret:
            return PolicyResult.require_approval(
                self.name,
                code='secret_working_directory',
                message='The requested working directory is marked secret and requires approval for command execution.',
                details=details,
            )
        if not assessment.within_workspace:
            return PolicyResult.require_approval(
                self.name,
                code='cwd_outside_workspace',
                message='The requested working directory escapes the configured workspace roots and requires approval.',
                details=details,
            )
        return PolicyResult.allow(
            self.name,
            code='cwd_allowed',
            message='The requested working directory is inside the workspace and not marked protected.',
            details=details,
        )


@dataclass(slots=True)
class CommandAccessPolicy:
    shell_entrypoints: frozenset[str] = field(
        default_factory=lambda: frozenset(
            {
                'bash',
                'sh',
                'dash',
                'zsh',
                'ksh',
                'fish',
                'cmd',
                'cmd.exe',
                'powershell',
                'powershell.exe',
                'pwsh',
                'pwsh.exe',
            }
        )
    )
    interpreter_entrypoints: frozenset[str] = field(
        default_factory=lambda: frozenset(
            {
                'python',
                'python3',
                'python3.11',
                'node',
                'perl',
                'ruby',
                'php',
                'lua',
            }
        )
    )
    name: str = 'command_access'

    def evaluate(self, request: ActionRequest, context: PolicyContext) -> PolicyResult | None:
        del context
        if request.capability is not Capability.EXEC:
            return None
        if request.resource.kind is not ResourceKind.COMMAND:
            return None

        raw_argv = request.parameters.get('argv')
        if not isinstance(raw_argv, (tuple, list)) or not raw_argv:
            return PolicyResult.deny(
                self.name,
                code='command_argv_missing',
                message='Command execution requires a normalized argv tuple.',
            )
        if not all(isinstance(argument, str) and argument for argument in raw_argv):
            return PolicyResult.deny(
                self.name,
                code='command_argv_invalid',
                message='Command execution requires argv entries to be non-empty strings.',
            )

        entrypoint = raw_argv[0].split('/')[-1].lower()
        details = {'entrypoint': entrypoint}
        if entrypoint in self.shell_entrypoints:
            return PolicyResult.require_approval(
                self.name,
                code='shell_entrypoint_requires_approval',
                message='Shell entrypoints require explicit approval.',
                details=details,
            )
        if entrypoint in self.interpreter_entrypoints:
            return PolicyResult.require_approval(
                self.name,
                code='interpreter_requires_approval',
                message='General-purpose interpreters require explicit approval.',
                details=details,
            )
        return PolicyResult.allow(
            self.name,
            code='command_allowed',
            message='The command entrypoint is allowed without a shell-specific approval rule.',
            details=details,
        )
