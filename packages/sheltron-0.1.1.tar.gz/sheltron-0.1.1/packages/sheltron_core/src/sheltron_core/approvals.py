from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from datetime import timedelta
from enum import Enum
from pathlib import Path
from typing import Callable, Protocol
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from sheltron_core.audit import JsonlAuditLogger, build_audit_record
from sheltron_core.file_lock import locked_path
from sheltron_core.schemas import ActionRequest, Decision, PolicyReason, PolicyResult


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


DEFAULT_APPROVAL_RETENTION_HOURS = 4.0


def _ticket_activity_time(ticket: ApprovalTicket) -> datetime:
    timestamps = [ticket.requested_at]
    if ticket.resolved_at is not None:
        timestamps.append(ticket.resolved_at)
    if ticket.consumed_at is not None:
        timestamps.append(ticket.consumed_at)
    return max(timestamps)


def default_approval_retention_hours() -> float:
    raw_value = os.environ.get('SHELTRON_APPROVAL_RETENTION_HOURS')
    if raw_value is None or raw_value.strip() == '':
        return DEFAULT_APPROVAL_RETENTION_HOURS
    hours = float(raw_value)
    if hours <= 0:
        raise ValueError('SHELTRON_APPROVAL_RETENTION_HOURS must be positive.')
    return hours


class ApprovalStatus(str, Enum):
    PENDING = 'pending'
    APPROVED = 'approved'
    REJECTED = 'rejected'
    EXPIRED = 'expired'


class ApprovalTicket(BaseModel):
    model_config = ConfigDict(extra='forbid')

    ticket_id: str
    request_id: str
    request_fingerprint: str
    request: ActionRequest
    system_name: str = 'sheltron'
    status: ApprovalStatus = ApprovalStatus.PENDING
    requested_at: datetime = Field(default_factory=_utcnow)
    resolved_at: datetime | None = None
    reviewer_id: str | None = None
    note: str | None = None
    consumed_at: datetime | None = None


def fingerprint_action_request(request: ActionRequest) -> str:
    payload = request.model_dump(
        mode='json',
        exclude={'request_id', 'created_at'},
    )
    serialized = json.dumps(payload, sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(serialized.encode('utf-8')).hexdigest()


def default_approval_store_path() -> Path:
    return Path.home() / '.sheltron' / 'approvals.json'


def load_json_approval_store(
    path: str | Path,
    *,
    audit_log_path: str | Path | None = None,
    retention_hours: float | None = None,
    now_provider: Callable[[], datetime] = _utcnow,
    audit_system: str = 'sheltron',
) -> JsonApprovalStore:
    audit_logger = (
        JsonlAuditLogger(Path(audit_log_path))
        if audit_log_path is not None
        else None
    )
    return JsonApprovalStore(
        path,
        retention_hours=retention_hours,
        now_provider=now_provider,
        audit_logger=audit_logger,
        audit_system=audit_system,
    )


class ApprovalStore(Protocol):
    def create(
        self,
        request: ActionRequest,
        *,
        request_fingerprint: str,
        ticket_id: str | None = None,
    ) -> ApprovalTicket:
        ...

    def get(self, ticket_id: str) -> ApprovalTicket | None:
        ...

    def list(self, *, status: ApprovalStatus | None = None) -> tuple[ApprovalTicket, ...]:
        ...

    def approve(self, ticket_id: str, *, reviewer_id: str, note: str | None = None) -> ApprovalTicket:
        ...

    def reject(self, ticket_id: str, *, reviewer_id: str, note: str | None = None) -> ApprovalTicket:
        ...

    def expire(self, ticket_id: str, *, note: str | None = None) -> ApprovalTicket:
        ...

    def consume(self, ticket_id: str) -> ApprovalTicket:
        ...


class InMemoryApprovalStore:
    def __init__(
        self,
        *,
        audit_logger: JsonlAuditLogger | None = None,
        audit_system: str = 'sheltron',
    ) -> None:
        self._tickets: dict[str, ApprovalTicket] = {}
        self.audit_logger = audit_logger
        self.audit_system = audit_system

    def create(
        self,
        request: ActionRequest,
        *,
        request_fingerprint: str,
        ticket_id: str | None = None,
    ) -> ApprovalTicket:
        resolved_ticket_id = ticket_id or f'approval-{uuid4().hex}'
        ticket = ApprovalTicket(
            ticket_id=resolved_ticket_id,
            request_id=request.request_id,
            request_fingerprint=request_fingerprint,
            request=request,
            system_name=self.audit_system,
        )
        self._tickets[resolved_ticket_id] = ticket
        return ticket

    def get(self, ticket_id: str) -> ApprovalTicket | None:
        return self._tickets.get(ticket_id)

    def list(self, *, status: ApprovalStatus | None = None) -> tuple[ApprovalTicket, ...]:
        tickets = tuple(
            ticket
            for ticket in self._tickets.values()
            if status is None or ticket.status is status
        )
        return tuple(sorted(tickets, key=_ticket_activity_time, reverse=True))

    def approve(self, ticket_id: str, *, reviewer_id: str, note: str | None = None) -> ApprovalTicket:
        return self._transition(
            ticket_id,
            status=ApprovalStatus.APPROVED,
            reviewer_id=reviewer_id,
            note=note,
        )

    def reject(self, ticket_id: str, *, reviewer_id: str, note: str | None = None) -> ApprovalTicket:
        return self._transition(
            ticket_id,
            status=ApprovalStatus.REJECTED,
            reviewer_id=reviewer_id,
            note=note,
        )

    def expire(self, ticket_id: str, *, note: str | None = None) -> ApprovalTicket:
        return self._transition(
            ticket_id,
            status=ApprovalStatus.EXPIRED,
            reviewer_id=None,
            note=note,
        )

    def consume(self, ticket_id: str) -> ApprovalTicket:
        current = self._tickets[ticket_id]
        updated = current.model_copy(update={'consumed_at': _utcnow()})
        self._tickets[ticket_id] = updated
        self._append_audit_event(
            updated,
            result=_approval_event_result(
                decision=Decision.ALLOW,
                code='approval_consumed',
                message='Approval ticket was consumed by an approved action.',
                ticket=updated,
            ),
            outcome='approval_consumed',
            occurred_at=updated.consumed_at,
            result_summary=f'status={updated.status.value}',
        )
        return updated

    def _transition(
        self,
        ticket_id: str,
        *,
        status: ApprovalStatus,
        reviewer_id: str | None,
        note: str | None,
    ) -> ApprovalTicket:
        current = self._tickets[ticket_id]
        updated = current.model_copy(
            update={
                'status': status,
                'resolved_at': _utcnow(),
                'reviewer_id': reviewer_id,
                'note': note,
            }
        )
        self._tickets[ticket_id] = updated
        self._append_audit_event(
            updated,
            result=_transition_result(updated, status=status),
            outcome=f'approval_{status.value}',
            occurred_at=updated.resolved_at,
            result_summary=_transition_summary(updated),
        )
        return updated

    def _append_audit_event(
        self,
        ticket: ApprovalTicket,
        *,
        result: PolicyResult,
        outcome: str,
        occurred_at: datetime | None,
        result_summary: str | None,
    ) -> None:
        if self.audit_logger is None:
            return
        self.audit_logger.append(
            build_audit_record(
                system=ticket.system_name,
                request=ticket.request,
                result=result,
                outcome=outcome,
                occurred_at=occurred_at,
                result_summary=result_summary,
            )
        )


class JsonApprovalStore:
    def __init__(
        self,
        path: str | Path,
        *,
        retention_hours: float | None = None,
        now_provider: Callable[[], datetime] = _utcnow,
        audit_logger: JsonlAuditLogger | None = None,
        audit_system: str = 'sheltron',
    ) -> None:
        self.path = Path(path)
        self.retention_hours = (
            default_approval_retention_hours()
            if retention_hours is None
            else retention_hours
        )
        if self.retention_hours <= 0:
            raise ValueError('Approval retention must be positive.')
        self.now_provider = now_provider
        self.audit_logger = audit_logger or JsonlAuditLogger(self.path.with_name('audit.jsonl'))
        self.audit_system = audit_system

    def create(
        self,
        request: ActionRequest,
        *,
        request_fingerprint: str,
        ticket_id: str | None = None,
    ) -> ApprovalTicket:
        with locked_path(self.path):
            tickets = self._load_for_write_unlocked()
            resolved_ticket_id = ticket_id or f'approval-{uuid4().hex}'
            ticket = ApprovalTicket(
                ticket_id=resolved_ticket_id,
                request_id=request.request_id,
                request_fingerprint=request_fingerprint,
                request=request,
                system_name=self.audit_system,
                requested_at=self.now_provider(),
            )
            tickets[resolved_ticket_id] = ticket
            self._save_unlocked(tickets)
            return ticket

    def get(self, ticket_id: str) -> ApprovalTicket | None:
        with locked_path(self.path):
            return self._load_unlocked().get(ticket_id)

    def list(self, *, status: ApprovalStatus | None = None) -> tuple[ApprovalTicket, ...]:
        with locked_path(self.path):
            tickets = tuple(
                ticket
                for ticket in self._load_unlocked().values()
                if status is None or ticket.status is status
            )
            return tuple(sorted(tickets, key=_ticket_activity_time, reverse=True))

    def approve(self, ticket_id: str, *, reviewer_id: str, note: str | None = None) -> ApprovalTicket:
        return self._transition(
            ticket_id,
            status=ApprovalStatus.APPROVED,
            reviewer_id=reviewer_id,
            note=note,
        )

    def reject(self, ticket_id: str, *, reviewer_id: str, note: str | None = None) -> ApprovalTicket:
        return self._transition(
            ticket_id,
            status=ApprovalStatus.REJECTED,
            reviewer_id=reviewer_id,
            note=note,
        )

    def expire(self, ticket_id: str, *, note: str | None = None) -> ApprovalTicket:
        return self._transition(
            ticket_id,
            status=ApprovalStatus.EXPIRED,
            reviewer_id=None,
            note=note,
        )

    def consume(self, ticket_id: str) -> ApprovalTicket:
        with locked_path(self.path):
            tickets = self._load_for_write_unlocked()
            current = tickets[ticket_id]
            updated = current.model_copy(update={'consumed_at': self.now_provider()})
            tickets[ticket_id] = updated
            self._save_unlocked(tickets)
        self._append_audit_event(
            updated,
            result=_approval_event_result(
                decision=Decision.ALLOW,
                code='approval_consumed',
                message='Approval ticket was consumed by an approved action.',
                ticket=updated,
            ),
            outcome='approval_consumed',
            occurred_at=updated.consumed_at,
            result_summary=f'status={updated.status.value}',
        )
        return updated

    def _transition(
        self,
        ticket_id: str,
        *,
        status: ApprovalStatus,
        reviewer_id: str | None,
        note: str | None,
    ) -> ApprovalTicket:
        with locked_path(self.path):
            tickets = self._load_for_write_unlocked()
            current = tickets[ticket_id]
            updated = current.model_copy(
                update={
                    'status': status,
                    'resolved_at': self.now_provider(),
                    'reviewer_id': reviewer_id,
                    'note': note,
                }
            )
            tickets[ticket_id] = updated
            self._save_unlocked(tickets)
        self._append_audit_event(
            updated,
            result=_transition_result(updated, status=status),
            outcome=f'approval_{status.value}',
            occurred_at=updated.resolved_at,
            result_summary=_transition_summary(updated),
        )
        return updated

    def _load_unlocked(self) -> dict[str, ApprovalTicket]:
        tickets = self._read_unlocked()
        retained_tickets, _, _ = self._partition_retained_tickets(tickets)
        return retained_tickets

    def _load_for_write_unlocked(self) -> dict[str, ApprovalTicket]:
        tickets = self._read_unlocked()
        retained_tickets, pruned_tickets, occurred_at = self._partition_retained_tickets(tickets)
        if pruned_tickets:
            self._append_pruned_ticket_events(pruned_tickets, occurred_at=occurred_at)
        return retained_tickets

    def _read_unlocked(self) -> dict[str, ApprovalTicket]:
        if not self.path.exists():
            return {}
        payload = json.loads(self.path.read_text(encoding='utf-8'))
        return {
            ticket_id: ApprovalTicket.model_validate(ticket_payload)
            for ticket_id, ticket_payload in payload.items()
        }

    def _save_unlocked(self, tickets: dict[str, ApprovalTicket]) -> None:
        retained_tickets, pruned_tickets, occurred_at = self._partition_retained_tickets(tickets)
        if pruned_tickets:
            self._append_pruned_ticket_events(pruned_tickets, occurred_at=occurred_at)
        self._write_unlocked(retained_tickets)

    def _write_unlocked(self, tickets: dict[str, ApprovalTicket]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            ticket_id: ticket.model_dump(mode='json')
            for ticket_id, ticket in sorted(
                tickets.items(),
                key=lambda item: _ticket_activity_time(item[1]),
                reverse=True,
            )
        }
        temp_path = self.path.with_suffix(self.path.suffix + '.tmp')
        temp_path.write_text(
            json.dumps(payload, indent=2),
            encoding='utf-8',
        )
        temp_path.replace(self.path)

    def _partition_retained_tickets(
        self,
        tickets: dict[str, ApprovalTicket],
    ) -> tuple[dict[str, ApprovalTicket], dict[str, ApprovalTicket], datetime]:
        occurred_at = self.now_provider()
        cutoff = occurred_at - timedelta(hours=self.retention_hours)
        retained_tickets: dict[str, ApprovalTicket] = {}
        pruned_tickets: dict[str, ApprovalTicket] = {}
        for ticket_id, ticket in tickets.items():
            if _ticket_activity_time(ticket) >= cutoff:
                retained_tickets[ticket_id] = ticket
            else:
                pruned_tickets[ticket_id] = ticket
        return retained_tickets, pruned_tickets, occurred_at

    def _append_pruned_ticket_events(
        self,
        tickets: dict[str, ApprovalTicket],
        *,
        occurred_at: datetime,
    ) -> None:
        for ticket in sorted(tickets.values(), key=_ticket_activity_time):
            if ticket.status is ApprovalStatus.PENDING:
                expired_ticket = ticket.model_copy(
                    update={
                        'status': ApprovalStatus.EXPIRED,
                        'resolved_at': occurred_at,
                    }
                )
                self._append_audit_event(
                    expired_ticket,
                    result=_transition_result(expired_ticket, status=ApprovalStatus.EXPIRED),
                    outcome='approval_expired',
                    occurred_at=occurred_at,
                    result_summary='status=expired retention_pruned=true',
                )
                continue
            self._append_audit_event(
                ticket,
                result=_approval_retention_prune_result(ticket),
                outcome='approval_retention_pruned',
                occurred_at=occurred_at,
                result_summary=_retention_prune_summary(ticket),
            )

    def _append_audit_event(
        self,
        ticket: ApprovalTicket,
        *,
        result: PolicyResult,
        outcome: str,
        occurred_at: datetime | None,
        result_summary: str | None,
    ) -> None:
        self.audit_logger.append(
            build_audit_record(
                system=ticket.system_name,
                request=ticket.request,
                result=result,
                outcome=outcome,
                occurred_at=occurred_at,
                result_summary=result_summary,
            )
        )


def _transition_result(ticket: ApprovalTicket, *, status: ApprovalStatus) -> PolicyResult:
    if status is ApprovalStatus.APPROVED:
        return _approval_event_result(
            decision=Decision.ALLOW,
            code='approval_approved',
            message='Approval ticket was approved by a reviewer.',
            ticket=ticket,
        )
    if status is ApprovalStatus.REJECTED:
        return _approval_event_result(
            decision=Decision.DENY,
            code='approval_rejected',
            message='Approval ticket was rejected by a reviewer.',
            ticket=ticket,
        )
    if status is ApprovalStatus.EXPIRED:
        return _approval_event_result(
            decision=Decision.DENY,
            code='approval_expired',
            message='Approval ticket expired before it was used.',
            ticket=ticket,
        )
    raise ValueError(f'Unsupported approval transition status: {status.value}')


def _transition_summary(ticket: ApprovalTicket) -> str:
    parts = [f'status={ticket.status.value}']
    if ticket.reviewer_id:
        parts.append(f'reviewer_id={ticket.reviewer_id}')
    return ' '.join(parts)


def _approval_event_result(
    *,
    decision: Decision,
    code: str,
    message: str,
    ticket: ApprovalTicket,
    extra_details: dict[str, object] | None = None,
) -> PolicyResult:
    details = {
        'ticket_id': ticket.ticket_id,
        'reviewer_id': ticket.reviewer_id,
        'note': ticket.note,
    }
    if extra_details:
        details.update(extra_details)
    return PolicyResult(
        decision=decision,
        reasons=(
            PolicyReason(
                code=code,
                message=message,
                details=details,
            ),
        ),
        matched_policy='approval_store',
        approval_ticket_id=ticket.ticket_id,
    )


def _approval_retention_prune_result(ticket: ApprovalTicket) -> PolicyResult:
    decision = Decision.ALLOW if ticket.status is ApprovalStatus.APPROVED else Decision.DENY
    return _approval_event_result(
        decision=decision,
        code='approval_retention_pruned',
        message='Approval ticket aged out of the retention window and was removed from the store.',
        ticket=ticket,
        extra_details={
            'previous_status': ticket.status.value,
            'consumed_at': ticket.consumed_at.isoformat() if ticket.consumed_at is not None else None,
            'last_activity_at': _ticket_activity_time(ticket).isoformat(),
        },
    )


def _retention_prune_summary(ticket: ApprovalTicket) -> str:
    parts = [f'status={ticket.status.value}', 'retention_pruned=true']
    if ticket.consumed_at is not None:
        parts.append('consumed=true')
    return ' '.join(parts)
