from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field

from sheltron_core.file_lock import locked_path
from sheltron_core.schemas import ActionRequest


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def default_candidate_memory_store_path() -> Path:
    return Path.home() / '.sheltron' / 'candidate_memory.jsonl'


class CandidateMemoryStatus(str, Enum):
    PENDING = 'pending'
    COMMITTED = 'committed'
    REJECTED = 'rejected'


class CandidateMemoryEntry(BaseModel):
    model_config = ConfigDict(extra='forbid')

    candidate_id: str
    request: ActionRequest
    content: str
    summary: str | None = None
    mode: str = 'replace'
    target_path: str | None = None
    status: CandidateMemoryStatus = CandidateMemoryStatus.PENDING
    requested_at: datetime = Field(default_factory=_utcnow)
    resolved_at: datetime | None = None
    reviewer_id: str | None = None
    note: str | None = None


class JsonlCandidateMemoryStore:
    def __init__(self, path: str | Path | None = None) -> None:
        self.path = Path(path) if path is not None else default_candidate_memory_store_path()

    def create(
        self,
        request: ActionRequest,
        *,
        content: str,
        summary: str | None = None,
        mode: str = 'replace',
        target_path: str | Path | None = None,
    ) -> CandidateMemoryEntry:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            normalized_target = str(target_path) if target_path is not None else None
            for entry in entries:
                if (
                    entry.status is CandidateMemoryStatus.PENDING
                    and entry.request.resource.locator == request.resource.locator
                    and entry.content == content
                    and entry.summary == summary
                    and entry.mode == mode
                    and entry.target_path == normalized_target
                ):
                    return entry
            entry = CandidateMemoryEntry(
                candidate_id=f'candidate-{uuid4().hex}',
                request=request,
                content=content,
                summary=summary,
                mode=mode,
                target_path=normalized_target,
            )
            entries.insert(0, entry)
            self._write_entries_unlocked(entries)
            return entry

    def get(self, candidate_id: str) -> CandidateMemoryEntry | None:
        with locked_path(self.path):
            for entry in self._load_entries_unlocked():
                if entry.candidate_id == candidate_id:
                    return entry
            return None

    def list(self, *, status: CandidateMemoryStatus | None = None) -> list[CandidateMemoryEntry]:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            if status is None:
                return entries
            return [entry for entry in entries if entry.status is status]

    def commit(
        self,
        candidate_id: str,
        *,
        reviewer_id: str,
        note: str | None = None,
    ) -> CandidateMemoryEntry:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            entry = self._require_entry(entries, candidate_id)
            if entry.status is not CandidateMemoryStatus.PENDING:
                return entry
            self._apply_entry(entry)
            updated = entry.model_copy(
                update={
                    'status': CandidateMemoryStatus.COMMITTED,
                    'resolved_at': _utcnow(),
                    'reviewer_id': reviewer_id,
                    'note': note,
                }
            )
            self._replace_entry(entries, updated)
            self._write_entries_unlocked(entries)
            return updated

    def reject(
        self,
        candidate_id: str,
        *,
        reviewer_id: str,
        note: str | None = None,
    ) -> CandidateMemoryEntry:
        with locked_path(self.path):
            entries = self._load_entries_unlocked()
            entry = self._require_entry(entries, candidate_id)
            if entry.status is not CandidateMemoryStatus.PENDING:
                return entry
            updated = entry.model_copy(
                update={
                    'status': CandidateMemoryStatus.REJECTED,
                    'resolved_at': _utcnow(),
                    'reviewer_id': reviewer_id,
                    'note': note,
                }
            )
            self._replace_entry(entries, updated)
            self._write_entries_unlocked(entries)
            return updated

    def _apply_entry(self, entry: CandidateMemoryEntry) -> None:
        if entry.target_path is None:
            return
        target = Path(entry.target_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        if entry.mode == 'append':
            with target.open('a', encoding='utf-8') as handle:
                handle.write(entry.content)
            return
        target.write_text(entry.content, encoding='utf-8')

    def _load_entries_unlocked(self) -> list[CandidateMemoryEntry]:
        if not self.path.exists():
            return []
        entries: list[CandidateMemoryEntry] = []
        with self.path.open('r', encoding='utf-8') as handle:
            for line in handle:
                payload = line.strip()
                if not payload:
                    continue
                entries.append(CandidateMemoryEntry.model_validate_json(payload))
        return entries

    def _write_entries_unlocked(self, entries: list[CandidateMemoryEntry]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open('w', encoding='utf-8') as handle:
            for entry in entries:
                handle.write(entry.model_dump_json())
                handle.write('\n')

    @staticmethod
    def _require_entry(entries: list[CandidateMemoryEntry], candidate_id: str) -> CandidateMemoryEntry:
        for entry in entries:
            if entry.candidate_id == candidate_id:
                return entry
        raise KeyError(f'Candidate memory entry not found: {candidate_id}')

    @staticmethod
    def _replace_entry(entries: list[CandidateMemoryEntry], updated: CandidateMemoryEntry) -> None:
        for index, entry in enumerate(entries):
            if entry.candidate_id == updated.candidate_id:
                entries[index] = updated
                return
        raise KeyError(f'Candidate memory entry not found: {updated.candidate_id}')
