from __future__ import annotations

from dataclasses import dataclass
import re

_PRIVATE_KEY_MARKERS = (
    'BEGIN OPENSSH PRIVATE KEY',
    'BEGIN RSA PRIVATE KEY',
    'BEGIN EC PRIVATE KEY',
    'BEGIN DSA PRIVATE KEY',
    'BEGIN PRIVATE KEY',
)
_SUSPICIOUS_TOKEN_PATTERNS = (
    re.compile(r'AKIA[0-9A-Z]{16}'),
    re.compile(r'github_pat_[A-Za-z0-9_]{20,}'),
    re.compile(r'gh[pousr]_[A-Za-z0-9]{20,}'),
    re.compile(r'xox[baprs]-[A-Za-z0-9-]{10,}'),
    re.compile(r'sk[-_][A-Za-z0-9_-]{20,}'),
    re.compile(r'Bearer\s+[A-Za-z0-9._-]{20,}', re.IGNORECASE),
    re.compile(r'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}'),
)


@dataclass(frozen=True, slots=True)
class SecretLikeContentAssessment:
    suspicious_token_matches: tuple[str, ...] = ()
    private_key_markers: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class TextContentRisk:
    suspicious_token_matches: tuple[str, ...] = ()
    private_key_markers: tuple[str, ...] = ()

    @property
    def secret_like_present(self) -> bool:
        return bool(self.suspicious_token_matches)

    @property
    def private_key_present(self) -> bool:
        return bool(self.private_key_markers)


def assess_secret_like_content(content: str) -> SecretLikeContentAssessment:
    suspicious_matches: list[str] = []
    for pattern in _SUSPICIOUS_TOKEN_PATTERNS:
        suspicious_matches.extend(match.group(0) for match in pattern.finditer(content))

    private_key_markers = tuple(marker for marker in _PRIVATE_KEY_MARKERS if marker in content)
    return SecretLikeContentAssessment(
        suspicious_token_matches=tuple(dict.fromkeys(suspicious_matches)),
        private_key_markers=private_key_markers,
    )


def classify_text_content(content: str) -> TextContentRisk:
    assessment = assess_secret_like_content(content)
    return TextContentRisk(
        suspicious_token_matches=assessment.suspicious_token_matches,
        private_key_markers=assessment.private_key_markers,
    )
