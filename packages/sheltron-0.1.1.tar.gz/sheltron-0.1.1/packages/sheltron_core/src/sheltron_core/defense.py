from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import re
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from sheltron_core.schemas import ActionRequest, Capability, Decision, GuardAssessment
from sheltron_core.trust import TrustLevel

if TYPE_CHECKING:
    from sheltron_core.policy import PolicyContext


class GuardBackend(Protocol):
    name: str

    def assess(self, request: ActionRequest, context: PolicyContext) -> GuardAssessment | None:
        ...


class DefenseRouter(Protocol):
    def route(self, request: ActionRequest, context: PolicyContext) -> tuple[GuardBackend, ...]:
        ...


class DefenseMode(str, Enum):
    NONE = 'none'
    HEURISTIC = 'heuristic'


_PROMPT_INJECTION_PATTERNS = (
    re.compile(r'ignore (?:all )?(?:previous|prior) instructions', re.IGNORECASE),
    re.compile(r'owner already approved', re.IGNORECASE),
    re.compile(r'do not ask again', re.IGNORECASE),
    re.compile(r'continue with exec immediately', re.IGNORECASE),
    re.compile(r'policy (?:changed|updated|overridden)', re.IGNORECASE),
)
_MEMORY_OVERRIDE_PATTERNS = (
    re.compile(r'ignore (?:all )?(?:previous|prior) instructions', re.IGNORECASE),
    re.compile(r'always (?:allow|approve|permit)', re.IGNORECASE),
    re.compile(r'(?:permission|policy|rules?) (?:changed|updated|overridden)', re.IGNORECASE),
)
_SENSITIVE_CAPABILITIES = frozenset(
    {
        Capability.EXEC,
        Capability.NETWORK_POST,
        Capability.SEND_MESSAGE,
        Capability.MEMORY_WRITE,
        Capability.SCHEDULE_TASK,
        Capability.READ_SECRET,
    }
)


@dataclass(slots=True)
class HeuristicGuardBackend:
    name: str = 'heuristic_guard'
    prompt_injection_patterns: tuple[re.Pattern[str], ...] = _PROMPT_INJECTION_PATTERNS
    memory_override_patterns: tuple[re.Pattern[str], ...] = _MEMORY_OVERRIDE_PATTERNS
    shell_entrypoints: frozenset[str] = field(
        default_factory=lambda: frozenset(
            {
                'bash',
                'sh',
                'dash',
                'zsh',
                'ksh',
                'fish',
                'cmd',
                'cmd.exe',
                'powershell',
                'powershell.exe',
                'pwsh',
                'pwsh.exe',
            }
        )
    )

    def assess(self, request: ActionRequest, context: PolicyContext) -> GuardAssessment | None:
        del context
        labels: list[str] = []
        reasons: list[str] = []
        recommended_decision: Decision | None = None
        confidence: float | None = None

        trust_levels = set(request.provenance.source_trust_levels)
        evidence_text = ' '.join(
            snippet
            for snippet in (
                evidence.snippet
                for evidence in request.provenance.evidence
            )
            if isinstance(snippet, str) and snippet
        )

        if request.capability in _SENSITIVE_CAPABILITIES:
            prompt_match = self._find_match(self.prompt_injection_patterns, evidence_text)
            if prompt_match is not None:
                labels.append('prompt_injection_suspected')
                reasons.append(f'Untrusted evidence matched hostile instruction pattern: {prompt_match}')
                recommended_decision = Decision.REQUIRE_APPROVAL
                confidence = self._max_confidence(confidence, 0.92)

        if request.capability is Capability.EXEC:
            argv = request.parameters.get('argv')
            if isinstance(argv, (tuple, list)) and argv:
                entrypoint = Path(str(argv[0])).name.lower()
                if entrypoint in self.shell_entrypoints and self._contains_untrusted_content(trust_levels):
                    labels.append('shell_exec_from_untrusted_context')
                    reasons.append('Untrusted or model-derived context attempted a shell entrypoint.')
                    recommended_decision = self._stronger_decision(recommended_decision, Decision.REQUIRE_APPROVAL)
                    confidence = self._max_confidence(confidence, 0.88)

        if request.capability is Capability.SEND_MESSAGE:
            private_key_markers = request.parameters.get('private_key_markers')
            if isinstance(private_key_markers, (tuple, list)) and private_key_markers:
                labels.append('private_key_exfiltration')
                reasons.append('Outbound message matched private key markers.')
                recommended_decision = Decision.DENY
                confidence = self._max_confidence(confidence, 0.99)
            suspicious_token_count = request.parameters.get('suspicious_token_count')
            if isinstance(suspicious_token_count, int) and suspicious_token_count > 0:
                labels.append('secret_like_message_content')
                reasons.append('Outbound message matched secret-like token patterns.')
                recommended_decision = self._stronger_decision(recommended_decision, Decision.REQUIRE_APPROVAL)
                confidence = self._max_confidence(confidence, 0.93)

        if request.capability is Capability.MEMORY_WRITE:
            suspicious_instruction_matches = request.parameters.get('suspicious_instruction_matches')
            if isinstance(suspicious_instruction_matches, (tuple, list)) and suspicious_instruction_matches:
                labels.append('memory_policy_override_suspected')
                reasons.append('Candidate memory matched policy-override instruction patterns.')
                recommended_decision = self._stronger_decision(recommended_decision, Decision.REQUIRE_APPROVAL)
                confidence = self._max_confidence(confidence, 0.94)
            memory_match = self._find_match(self.memory_override_patterns, evidence_text)
            if memory_match is not None:
                labels.append('memory_prompt_injection_suspected')
                reasons.append(f'Untrusted evidence matched hostile memory pattern: {memory_match}')
                recommended_decision = self._stronger_decision(recommended_decision, Decision.REQUIRE_APPROVAL)
                confidence = self._max_confidence(confidence, 0.9)

        if not labels:
            return None
        return GuardAssessment(
            backend=self.name,
            recommended_decision=recommended_decision,
            labels=tuple(dict.fromkeys(labels)),
            confidence=confidence,
            reasons=tuple(dict.fromkeys(reasons)),
            details={'request_id': request.request_id},
        )

    @staticmethod
    def _contains_untrusted_content(trust_levels: set[TrustLevel]) -> bool:
        return bool(
            trust_levels.intersection(
                {
                    TrustLevel.MODEL_INFERENCE,
                    TrustLevel.WEB_UNTRUSTED,
                    TrustLevel.FILE_UNTRUSTED,
                    TrustLevel.MCP_UNTRUSTED,
                }
            )
        )

    @staticmethod
    def _find_match(patterns: tuple[re.Pattern[str], ...], text: str) -> str | None:
        for pattern in patterns:
            match = pattern.search(text)
            if match is not None:
                return match.group(0)
        return None

    @staticmethod
    def _stronger_decision(current: Decision | None, proposed: Decision) -> Decision:
        if current is Decision.DENY:
            return current
        if proposed is Decision.DENY:
            return proposed
        if current is Decision.REQUIRE_APPROVAL:
            return current
        return proposed

    @staticmethod
    def _max_confidence(current: float | None, proposed: float) -> float:
        if current is None:
            return proposed
        return max(current, proposed)


def build_guard_backends(mode: DefenseMode | str | None) -> tuple[GuardBackend, ...]:
    if mode is None:
        resolved = DefenseMode.NONE
    elif isinstance(mode, DefenseMode):
        resolved = mode
    else:
        resolved = DefenseMode(mode)

    if resolved is DefenseMode.NONE:
        return ()
    if resolved is DefenseMode.HEURISTIC:
        return (HeuristicGuardBackend(),)
    raise ValueError(f'Unsupported defense mode: {mode}')


@dataclass(slots=True)
class AutoDefenseRouter:
    mode: DefenseMode = DefenseMode.HEURISTIC
    _backends: tuple[GuardBackend, ...] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        self._backends = build_guard_backends(self.mode)

    def route(self, request: ActionRequest, context: PolicyContext) -> tuple[GuardBackend, ...]:
        del context
        if self.mode is DefenseMode.NONE:
            return ()
        if self.mode is DefenseMode.HEURISTIC and not self._should_route_heuristic(request):
            return ()
        return self._backends

    @staticmethod
    def _should_route_heuristic(request: ActionRequest) -> bool:
        trust_levels = set(request.provenance.source_trust_levels)
        has_untrusted_context = bool(
            trust_levels.intersection(
                {
                    TrustLevel.MODEL_INFERENCE,
                    TrustLevel.WEB_UNTRUSTED,
                    TrustLevel.FILE_UNTRUSTED,
                    TrustLevel.MCP_UNTRUSTED,
                }
            )
        )
        has_evidence = bool(request.provenance.evidence)

        if request.capability is Capability.EXEC:
            return has_untrusted_context and (
                has_evidence or AutoDefenseRouter._shell_entrypoint_requested(request)
            )
        if request.capability is Capability.NETWORK_POST:
            return has_untrusted_context and has_evidence
        if request.capability is Capability.MEMORY_WRITE:
            return (
                AutoDefenseRouter._positive_int_param(request, 'suspicious_instruction_count')
                or AutoDefenseRouter._positive_int_param(request, 'suspicious_token_count')
                or AutoDefenseRouter._non_empty_param(request, 'private_key_markers')
                or (has_untrusted_context and has_evidence)
            )
        if request.capability is Capability.SEND_MESSAGE:
            return (
                AutoDefenseRouter._positive_int_param(request, 'suspicious_token_count')
                or AutoDefenseRouter._non_empty_param(request, 'private_key_markers')
                or bool(request.parameters.get('content_redacted'))
                or (has_untrusted_context and has_evidence)
            )
        if request.capability is Capability.SCHEDULE_TASK:
            return has_untrusted_context and has_evidence
        return False

    @staticmethod
    def _shell_entrypoint_requested(request: ActionRequest) -> bool:
        argv = request.parameters.get('argv')
        if not isinstance(argv, (tuple, list)) or not argv:
            return False
        entrypoint = Path(str(argv[0])).name.lower()
        return entrypoint in HeuristicGuardBackend().shell_entrypoints

    @staticmethod
    def _positive_int_param(request: ActionRequest, name: str) -> bool:
        value = request.parameters.get(name)
        return isinstance(value, int) and value > 0

    @staticmethod
    def _non_empty_param(request: ActionRequest, name: str) -> bool:
        value = request.parameters.get(name)
        return isinstance(value, (tuple, list)) and bool(value)
