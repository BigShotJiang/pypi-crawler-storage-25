from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum

from sheltron_core import DefenseMode


class AttackHost(str, Enum):
    NANOBOT = 'nanobot'
    OPENCLAW = 'openclaw'


class AttackCategory(str, Enum):
    PROMPT_INJECTION = 'prompt_injection'
    CONFUSED_DEPUTY = 'confused_deputy'
    DENY_WORKAROUND = 'deny_workaround'
    MEMORY_POISONING = 'memory_poisoning'
    CHANNEL_ABUSE = 'channel_abuse'


class AttackFeature(str, Enum):
    WEB_FETCH = 'web_fetch'
    WEB_SEARCH = 'web_search'
    TOOL_OUTPUT = 'tool_output'
    MEMORY = 'memory'
    MESSAGE = 'message'
    SUBAGENTS = 'subagents'
    AUDIT = 'audit'
    APPROVALS = 'approvals'
    FILESYSTEM = 'filesystem'
    EXEC = 'exec'
    NETWORK = 'network'


class AttackCaseStatus(str, Enum):
    PLANNED = 'planned'
    READY = 'ready'


@dataclass(frozen=True, slots=True)
class AttackCase:
    case_id: str
    title: str
    category: AttackCategory
    status: AttackCaseStatus
    hosts: frozenset[AttackHost]
    required_features: frozenset[AttackFeature]
    objective: str
    setup: str
    expected_invariants: tuple[str, ...]
    notes: str | None = None

    def to_dict(self) -> dict[str, object]:
        payload = asdict(self)
        payload['category'] = self.category.value
        payload['status'] = self.status.value
        payload['hosts'] = [host.value for host in sorted(self.hosts, key=lambda item: item.value)]
        payload['required_features'] = [
            feature.value for feature in sorted(self.required_features, key=lambda item: item.value)
        ]
        return payload


@dataclass(frozen=True, slots=True)
class AttackHarnessProbe:
    host: AttackHost
    mode: str
    supported_features: frozenset[AttackFeature]
    supported_defense_modes: frozenset[DefenseMode] = field(default_factory=lambda: frozenset({DefenseMode.NONE}))
    version: str | None = None
    notes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, object]:
        return {
            'host': self.host.value,
            'mode': self.mode,
            'supported_features': [
                feature.value for feature in sorted(self.supported_features, key=lambda item: item.value)
            ],
            'supported_defense_modes': [
                mode.value for mode in sorted(self.supported_defense_modes, key=lambda item: item.value)
            ],
            'version': self.version,
            'notes': list(self.notes),
        }


@dataclass(frozen=True, slots=True)
class AttackTranscriptEvent:
    source: str
    content: str
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        return {
            'source': self.source,
            'content': self.content,
            'metadata': dict(self.metadata),
        }


@dataclass(frozen=True, slots=True)
class AttackRunResult:
    case: AttackCase
    host: AttackHost
    passed: bool
    defense_mode: DefenseMode = DefenseMode.NONE
    transcript: tuple[AttackTranscriptEvent, ...] = ()
    violated_invariants: tuple[str, ...] = ()
    notes: str | None = None
    probe: AttackHarnessProbe | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            'case': self.case.to_dict(),
            'host': self.host.value,
            'passed': self.passed,
            'defense_mode': self.defense_mode.value,
            'transcript': [event.to_dict() for event in self.transcript],
            'violated_invariants': list(self.violated_invariants),
            'notes': self.notes,
            'probe': None if self.probe is None else self.probe.to_dict(),
        }
