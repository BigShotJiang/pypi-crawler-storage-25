from __future__ import annotations

from typing import Protocol

from sheltron_attacklab.schemas import AttackCase, AttackHarnessProbe, AttackHost, AttackRunResult
from sheltron_core import DefenseMode


class HostAttackHarness(Protocol):
    host: AttackHost

    def probe(self) -> AttackHarnessProbe:
        ...

    def run_case(self, case: AttackCase, *, defense_mode: DefenseMode = DefenseMode.NONE) -> AttackRunResult:
        ...
