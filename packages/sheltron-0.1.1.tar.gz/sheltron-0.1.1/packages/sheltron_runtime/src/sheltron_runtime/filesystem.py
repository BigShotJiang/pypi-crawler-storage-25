from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.resources import PathPolicyContext
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    PolicyResult,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.guard_support import evaluate_policy, hash_text, new_request_id
from sheltron_runtime.runtime_types import (
    DirectoryEntry,
    DirectoryListSpec,
    FileEditSpec,
    FileReadSpec,
    FileWriteSpec,
    GuardResult,
)


@dataclass(slots=True)
class LocalFileSystemGuard:
    policy_engine: PolicyEngine
    path_policy: PathPolicyContext
    working_directory: Path | None = None
    approval_store: ApprovalStore | None = None

    def read_text(
        self,
        spec: FileReadSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[str]:
        request, final_policy_result, normalized_path = self._evaluate(
            spec.path,
            capability=Capability.READ_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={
                'operation': 'read_text',
                'encoding': spec.encoding,
            },
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        content = normalized_path.read_text(encoding=spec.encoding)
        return GuardResult.completed(request, final_policy_result, content)

    def authorize_read_text(
        self,
        spec: FileReadSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        request, final_policy_result, _ = self._evaluate(
            spec.path,
            capability=Capability.READ_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={
                'operation': 'read_text',
                'encoding': spec.encoding,
            },
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, None)

    def write_text(
        self,
        spec: FileWriteSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        request, final_policy_result, normalized_path = self._evaluate(
            spec.path,
            capability=Capability.WRITE_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={
                'operation': 'write_text',
                'encoding': spec.encoding,
                'create_parents': spec.create_parents,
                'content_sha256': hash_text(spec.content),
            },
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        if spec.create_parents:
            normalized_path.parent.mkdir(parents=True, exist_ok=True)
        normalized_path.write_text(spec.content, encoding=spec.encoding)
        return GuardResult.completed(request, final_policy_result, None)

    def authorize_write_text(
        self,
        spec: FileWriteSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        request, final_policy_result, _ = self._evaluate(
            spec.path,
            capability=Capability.WRITE_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={
                'operation': 'write_text',
                'encoding': spec.encoding,
                'create_parents': spec.create_parents,
                'content_sha256': hash_text(spec.content),
            },
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, None)

    def edit_text(
        self,
        spec: FileEditSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        request, final_policy_result, normalized_path = self._evaluate(
            spec.path,
            capability=Capability.EDIT_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={
                'operation': 'edit_text',
                'encoding': spec.encoding,
                'old_text_sha256': hash_text(spec.old_text),
                'new_text_sha256': hash_text(spec.new_text),
            },
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        current_text = normalized_path.read_text(encoding=spec.encoding)
        if spec.old_text not in current_text:
            raise ValueError("The requested old_text was not found in the target file.")
        updated_text = current_text.replace(spec.old_text, spec.new_text, 1)
        normalized_path.write_text(updated_text, encoding=spec.encoding)
        return GuardResult.completed(request, final_policy_result, None)

    def authorize_edit_text(
        self,
        spec: FileEditSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        request, final_policy_result, _ = self._evaluate(
            spec.path,
            capability=Capability.EDIT_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={
                'operation': 'edit_text',
                'encoding': spec.encoding,
                'old_text_sha256': hash_text(spec.old_text),
                'new_text_sha256': hash_text(spec.new_text),
            },
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, None)

    def list_directory(
        self,
        spec: DirectoryListSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[tuple[DirectoryEntry, ...]]:
        request, final_policy_result, normalized_path = self._evaluate(
            spec.path,
            capability=Capability.READ_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={'operation': 'list_directory'},
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        entries = tuple(
            DirectoryEntry(
                path=child,
                is_dir=child.is_dir(),
                size_bytes=None if child.is_dir() else child.stat().st_size,
            )
            for child in sorted(normalized_path.iterdir(), key=lambda item: item.name)
        )
        return GuardResult.completed(request, final_policy_result, entries)

    def authorize_list_directory(
        self,
        spec: DirectoryListSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        request, final_policy_result, _ = self._evaluate(
            spec.path,
            capability=Capability.READ_FILE,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
            parameters={'operation': 'list_directory'},
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, None)

    def _evaluate(
        self,
        raw_path: str | Path,
        *,
        capability: Capability,
        provenance: Provenance,
        approval_ticket_id: str | None,
        parameters: dict[str, str | bool],
    ) -> tuple[ActionRequest, PolicyResult, Path]:
        normalized_path = self.path_policy.normalize_path(raw_path, cwd=self.working_directory)
        request = ActionRequest(
            request_id=new_request_id('fs'),
            capability=capability,
            resource=ResourceDescriptor(kind=ResourceKind.FILE_PATH, locator=str(normalized_path)),
            provenance=provenance,
            parameters=parameters,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            path_policy=self.path_policy,
            working_directory=self.working_directory,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        return request, final_policy_result, normalized_path
