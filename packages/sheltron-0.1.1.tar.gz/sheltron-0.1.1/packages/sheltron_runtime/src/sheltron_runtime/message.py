from __future__ import annotations

from dataclasses import dataclass

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.redaction import SecretRedactor
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.content_risk import assess_secret_like_content
from sheltron_runtime.guard_support import evaluate_policy, hash_text, new_request_id
from sheltron_runtime.runtime_types import GuardResult, MessageOutput, SendMessageSpec


@dataclass(frozen=True, slots=True)
class MessageRiskAssessment:
    suspicious_token_matches: tuple[str, ...] = ()
    private_key_markers: tuple[str, ...] = ()


@dataclass(slots=True)
class LocalMessageGuard:
    policy_engine: PolicyEngine
    approval_store: ApprovalStore | None = None
    redactor: SecretRedactor | None = None

    def send_message(
        self,
        spec: SendMessageSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[MessageOutput]:
        risk = self._assess_content(spec.content)
        sent_content = self._redact(spec.content)
        output = MessageOutput(
            channel=spec.channel,
            recipient=spec.recipient,
            content=sent_content,
            reply_to=spec.reply_to,
            media=spec.media,
            redacted=sent_content != spec.content,
        )
        request = self._build_request(
            spec,
            provenance=provenance,
            output=output,
            risk=risk,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, output)

    def _build_request(
        self,
        spec: SendMessageSpec,
        *,
        provenance: Provenance,
        output: MessageOutput,
        risk: MessageRiskAssessment,
    ) -> ActionRequest:
        return ActionRequest(
            request_id=new_request_id('msg'),
            capability=Capability.SEND_MESSAGE,
            resource=ResourceDescriptor(
                kind=ResourceKind.MESSAGE_TARGET,
                locator=f'{output.channel}:{output.recipient}',
            ),
            provenance=provenance,
            parameters={
                'channel': output.channel,
                'recipient': output.recipient,
                'default_channel': spec.default_channel,
                'default_recipient': spec.default_recipient,
                'reply_to': output.reply_to,
                'media_count': len(output.media),
                'media': output.media,
                'content_chars': len(output.content),
                'content_redacted': output.redacted,
                'original_content_sha256': hash_text(spec.content),
                'content_sha256': hash_text(output.content),
                'suspicious_token_count': len(risk.suspicious_token_matches),
                'suspicious_token_matches': risk.suspicious_token_matches,
                'private_key_markers': risk.private_key_markers,
            },
        )

    def _redact(self, content: str) -> str:
        if self.redactor is None:
            return content
        return self.redactor.redact_text(content)

    @staticmethod
    def _assess_content(content: str) -> MessageRiskAssessment:
        assessment = assess_secret_like_content(content)
        return MessageRiskAssessment(
            suspicious_token_matches=assessment.suspicious_token_matches,
            private_key_markers=assessment.private_key_markers,
        )
