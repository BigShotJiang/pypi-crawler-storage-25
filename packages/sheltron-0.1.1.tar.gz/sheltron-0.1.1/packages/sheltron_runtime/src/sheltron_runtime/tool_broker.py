from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from os import PathLike, fspath
from typing import Protocol, runtime_checkable

from sheltron_core import (
    ActionRequest,
    ApprovalStore,
    Capability,
    Decision,
    PolicyEngine,
    PolicyResult,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
    TrustLevel,
)
from sheltron_runtime.guard_support import evaluate_policy, new_request_id
from sheltron_runtime.runtime_types import GuardResult


@dataclass(frozen=True, slots=True)
class ToolBrokerRegistration:
    backend_kind: str
    locator: str
    description: str | None = None
    trust_level: TrustLevel = TrustLevel.MCP_UNTRUSTED
    enabled: bool = True
    namespace: str | None = None
    tool_name: str | None = None
    metadata: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ToolBrokerResult:
    registration: ToolBrokerRegistration
    arguments: dict[str, object]
    result: object


@runtime_checkable
class ToolBrokerBackend(Protocol):
    backend_kind: str

    def get_registration(self, locator: str) -> ToolBrokerRegistration | None:
        ...

    def is_namespace_allowed(self, namespace: str | None) -> bool:
        ...

    def invoke(self, locator: str, *, arguments: dict[str, object] | None = None) -> ToolBrokerResult:
        ...


def build_broker_action_request(
    *,
    backend_kind: str,
    locator: str,
    provenance: Provenance,
    arguments: dict[str, object],
    registration: ToolBrokerRegistration | None,
    namespace_allowed: bool,
    namespace: str | None = None,
    tool_name: str | None = None,
    capability: Capability = Capability.TOOL_BROKER_CALL,
    resource_kind: ResourceKind = ResourceKind.TOOL_TARGET,
) -> ActionRequest:
    normalized_namespace = registration.namespace if registration is not None else namespace
    normalized_tool_name = registration.tool_name if registration is not None else tool_name
    return ActionRequest(
        request_id=new_request_id('broker'),
        capability=capability,
        resource=ResourceDescriptor(
            kind=resource_kind,
            locator=locator,
        ),
        provenance=provenance,
        parameters={
            'backend_kind': backend_kind,
            'locator': locator,
            'namespaced_tool': locator,
            'namespace': normalized_namespace,
            'tool_name': normalized_tool_name,
            'tool_known': registration is not None,
            'enabled': registration.enabled if registration is not None else False,
            'namespace_allowed': namespace_allowed,
            'trust_level': registration.trust_level.value if registration is not None else None,
            'description': registration.description if registration is not None else None,
            'arguments': normalized_json_arguments(arguments),
            # Current downstream MCP policy still expects these names.
            'server_name': normalized_namespace,
            'server_allowed': namespace_allowed,
        },
    )


@dataclass(slots=True)
class LocalToolBrokerPipeline:
    backend: ToolBrokerBackend
    policy_engine: PolicyEngine
    approval_store: ApprovalStore | None = None
    capability: Capability = Capability.TOOL_BROKER_CALL
    resource_kind: ResourceKind = ResourceKind.TOOL_TARGET

    def invoke(
        self,
        locator: str,
        *,
        arguments: dict[str, object] | None,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[ToolBrokerResult]:
        normalized_arguments = normalized_json_arguments(arguments or {})
        request = self.build_request(
            locator,
            arguments=normalized_arguments,
            provenance=provenance,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)

        try:
            brokered = self.backend.invoke(
                locator,
                arguments=normalized_arguments,
            )
        except KeyError:
            return GuardResult.rejected(
                request,
                PolicyResult.deny(
                    'tool_broker_access',
                    code='unknown_brokered_tool',
                    message='The requested brokered tool is not registered with this broker backend.',
                    details={
                        'backend_kind': self.backend.backend_kind,
                        'locator': locator,
                    },
                    guard_assessments=final_policy_result.guard_assessments,
                ),
            )
        except PermissionError as exc:
            return GuardResult.rejected(
                request,
                PolicyResult.deny(
                    'tool_broker_access',
                    code='broker_runtime_blocked',
                    message='The broker backend rejected this tool call at runtime.',
                    details={
                        'backend_kind': self.backend.backend_kind,
                        'locator': locator,
                        'error': str(exc),
                    },
                    guard_assessments=final_policy_result.guard_assessments,
                ),
            )
        return GuardResult.completed(request, final_policy_result, brokered)

    def build_request(
        self,
        locator: str,
        *,
        arguments: dict[str, object],
        provenance: Provenance,
    ) -> ActionRequest:
        registration = self.backend.get_registration(locator)
        namespace = registration.namespace if registration is not None else None
        tool_name = registration.tool_name if registration is not None else None
        if registration is None:
            parse_locator = getattr(self.backend, 'parse_locator', None)
            if callable(parse_locator):
                parsed_namespace, parsed_tool_name = parse_locator(locator)
                if isinstance(parsed_namespace, str) and parsed_namespace:
                    namespace = parsed_namespace
                if isinstance(parsed_tool_name, str) and parsed_tool_name:
                    tool_name = parsed_tool_name
        namespace_allowed = self.backend.is_namespace_allowed(namespace)
        return build_broker_action_request(
            backend_kind=self.backend.backend_kind,
            locator=locator,
            provenance=provenance,
            arguments=arguments,
            registration=registration,
            namespace_allowed=namespace_allowed,
            namespace=namespace,
            tool_name=tool_name,
            capability=self.capability,
            resource_kind=self.resource_kind,
        )


def normalized_json_arguments(arguments: dict[str, object]) -> dict[str, object]:
    return {
        str(key): _normalize_json_value(value)
        for key, value in arguments.items()
    }


def _normalize_json_value(value: object) -> object:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, PathLike):
        return fspath(value)
    if isinstance(value, dict):
        return normalized_json_arguments(value)
    if isinstance(value, (list, tuple)):
        return [_normalize_json_value(item) for item in value]
    return deepcopy(value)
