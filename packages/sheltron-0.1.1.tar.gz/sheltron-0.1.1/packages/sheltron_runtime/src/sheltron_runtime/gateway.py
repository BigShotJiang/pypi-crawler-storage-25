from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from sheltron_core import (
    Capability,
    CapabilityAllowlistPolicy,
    CommandAccessPolicy,
    DefenseRouter,
    JsonApprovalStore,
    JsonlAuditLogger,
    JsonlCandidateMemoryStore,
    MemoryWritePolicy,
    MessageAccessPolicy,
    NetworkAccessPolicy,
    PathAccessPolicy,
    PathPolicyContext,
    PolicyEngine,
    ScheduleTaskPolicy,
    SearchAccessPolicy,
    TrustBasedApprovalPolicy,
    WorkingDirectoryAccessPolicy,
    build_audit_record,
    default_workspace_audit_log_path,
)
from sheltron_core.redaction import SecretRedactor
from sheltron_core.schemas import Provenance
from sheltron_runtime.exec import LocalExecGuard
from sheltron_runtime.filesystem import LocalFileSystemGuard
from sheltron_runtime.memory import LocalMemoryGuard
from sheltron_runtime.message import LocalMessageGuard
from sheltron_runtime.network import LocalNetworkGuard
from sheltron_runtime.runtime_types import (
    CandidateMemoryOutput,
    CandidateMemorySpec,
    CommandOutput,
    CommandSpec,
    DirectoryEntry,
    DirectoryListSpec,
    FetchSpec,
    FileEditSpec,
    FileReadSpec,
    FileWriteSpec,
    GuardResult,
    MessageOutput,
    NetworkResponse,
    PostSpec,
    ScheduledTaskOutput,
    ScheduledTaskSpec,
    SearchSpec,
    SendMessageSpec,
)
from sheltron_runtime.schedule import LocalScheduleTaskGuard
from sheltron_runtime.search import LocalSearchGuard


def default_workspace_approval_store_path(workspace: Path) -> Path:
    return workspace / '.sheltron' / 'approvals.json'


def default_workspace_candidate_memory_store_path(workspace: Path) -> Path:
    return workspace / '.sheltron' / 'candidate_memory.jsonl'


def default_filesystem_protected_paths(workspace: Path) -> tuple[Path, ...]:
    return (
        workspace / 'AGENTS.md',
        workspace / 'SOUL.md',
        workspace / 'TOOLS.md',
        workspace / 'USER.md',
        workspace / 'memory' / 'MEMORY.md',
        workspace / 'memory' / 'HISTORY.md',
        workspace / 'skills',
        workspace / '.sheltron',
    )


def default_filesystem_approval_required_paths(workspace: Path, *, system_name: str) -> tuple[Path, ...]:
    if system_name != 'nanobot':
        return ()
    return (
        workspace / 'USER.md',
        workspace / 'memory' / 'MEMORY.md',
        workspace / 'memory' / 'HISTORY.md',
    )


@dataclass(slots=True)
class SheltronGateway:
    workspace: Path
    approval_store_path: Path
    audit_log_path: Path
    candidate_memory_store_path: Path
    approval_store: JsonApprovalStore
    filesystem_guard: LocalFileSystemGuard
    exec_guard: LocalExecGuard
    search_guard: LocalSearchGuard
    network_guard: LocalNetworkGuard
    message_guard: LocalMessageGuard
    schedule_guard: LocalScheduleTaskGuard
    memory_guard: LocalMemoryGuard
    audit_logger: JsonlAuditLogger
    system_name: str

    @classmethod
    def for_workspace(
        cls,
        workspace: str | Path | None = None,
        *,
        approval_store_path: str | Path | None = None,
        audit_log_path: str | Path | None = None,
        candidate_memory_store_path: str | Path | None = None,
        system_name: str = 'sheltron',
        defense_router: DefenseRouter | None = None,
        message_secret_values: tuple[str, ...] | None = None,
        message_max_content_chars: int = 4_000,
        allowed_target_locators: frozenset[str] | None = None,
        protected_paths: tuple[Path, ...] | None = None,
        approval_required_paths: tuple[Path, ...] | None = None,
        secret_paths: tuple[Path, ...] | None = None,
    ) -> SheltronGateway:
        resolved_workspace = Path(workspace or Path.cwd()).expanduser().resolve(strict=False)
        resolved_approval_store = Path(
            approval_store_path or default_workspace_approval_store_path(resolved_workspace)
        ).expanduser().resolve(strict=False)
        resolved_audit_log = Path(
            audit_log_path or default_workspace_audit_log_path(resolved_workspace)
        ).expanduser().resolve(strict=False)
        resolved_candidate_store = Path(
            candidate_memory_store_path
            or default_workspace_candidate_memory_store_path(resolved_workspace)
        ).expanduser().resolve(strict=False)
        audit_logger = JsonlAuditLogger(resolved_audit_log)

        path_policy = PathPolicyContext(
            workspace_roots=(resolved_workspace,),
            protected_paths=protected_paths or default_filesystem_protected_paths(resolved_workspace),
            approval_required_paths=(
                approval_required_paths
                or default_filesystem_approval_required_paths(
                    resolved_workspace,
                    system_name=system_name,
                )
            ),
            secret_paths=secret_paths or (),
        )
        approval_store = JsonApprovalStore(
            resolved_approval_store,
            audit_logger=audit_logger,
            audit_system=system_name,
        )
        candidate_store = JsonlCandidateMemoryStore(resolved_candidate_store)

        filesystem_guard = LocalFileSystemGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy(
                        {
                            Capability.READ_FILE,
                            Capability.WRITE_FILE,
                            Capability.EDIT_FILE,
                        }
                    ),
                    PathAccessPolicy(),
                ],
                defense_router=defense_router,
            ),
            path_policy=path_policy,
            working_directory=resolved_workspace,
            approval_store=approval_store,
        )
        exec_guard = LocalExecGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy({Capability.EXEC}),
                    WorkingDirectoryAccessPolicy(),
                    CommandAccessPolicy(),
                    TrustBasedApprovalPolicy(),
                ],
                defense_router=defense_router,
            ),
            path_policy=path_policy,
            working_directory=resolved_workspace,
            approval_store=approval_store,
        )
        search_guard = LocalSearchGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy({Capability.SEARCH_WEB}),
                    SearchAccessPolicy(),
                ],
                defense_router=defense_router,
            ),
            approval_store=approval_store,
        )
        network_guard = LocalNetworkGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy(
                        {
                            Capability.NETWORK_FETCH,
                            Capability.NETWORK_POST,
                        }
                    ),
                    NetworkAccessPolicy(),
                    TrustBasedApprovalPolicy(),
                ],
                defense_router=defense_router,
            ),
            approval_store=approval_store,
        )
        message_guard = LocalMessageGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy({Capability.SEND_MESSAGE}),
                    MessageAccessPolicy(
                        max_content_chars=message_max_content_chars,
                        allowed_target_locators=allowed_target_locators,
                    ),
                ],
                defense_router=defense_router,
            ),
            approval_store=approval_store,
            redactor=(
                SecretRedactor(message_secret_values)
                if message_secret_values
                else None
            ),
        )
        schedule_guard = LocalScheduleTaskGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy({Capability.SCHEDULE_TASK}),
                    ScheduleTaskPolicy(),
                ],
                defense_router=defense_router,
            ),
            approval_store=approval_store,
        )
        memory_guard = LocalMemoryGuard(
            policy_engine=PolicyEngine(
                [
                    CapabilityAllowlistPolicy({Capability.MEMORY_WRITE}),
                    MemoryWritePolicy(),
                ],
                defense_router=defense_router,
            ),
            candidate_store=candidate_store,
        )
        return cls(
            workspace=resolved_workspace,
            approval_store_path=resolved_approval_store,
            audit_log_path=resolved_audit_log,
            candidate_memory_store_path=resolved_candidate_store,
            approval_store=approval_store,
            filesystem_guard=filesystem_guard,
            exec_guard=exec_guard,
            search_guard=search_guard,
            network_guard=network_guard,
            message_guard=message_guard,
            schedule_guard=schedule_guard,
            memory_guard=memory_guard,
            audit_logger=audit_logger,
            system_name=system_name,
        )

    def read_file(
        self,
        spec: FileReadSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[str]:
        return self.filesystem_guard.read_text(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def write_file(
        self,
        spec: FileWriteSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        return self.filesystem_guard.write_text(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def edit_file(
        self,
        spec: FileEditSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        return self.filesystem_guard.edit_text(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def list_directory(
        self,
        spec: DirectoryListSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[tuple[DirectoryEntry, ...]]:
        return self.filesystem_guard.list_directory(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def execute_command(
        self,
        spec: CommandSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[CommandOutput]:
        return self.exec_guard.execute(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def search_web(
        self,
        spec: SearchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[SearchSpec]:
        return self.search_guard.search_web(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def fetch_url(
        self,
        spec: FetchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[NetworkResponse]:
        return self.network_guard.fetch(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def post_url(
        self,
        spec: PostSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[NetworkResponse]:
        return self.network_guard.post(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def send_message(
        self,
        spec: SendMessageSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[MessageOutput]:
        return self.message_guard.send_message(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def schedule_task(
        self,
        spec: ScheduledTaskSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[ScheduledTaskOutput]:
        return self.schedule_guard.schedule_task(
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def save_candidate_memory(
        self,
        spec: CandidateMemorySpec,
        *,
        provenance: Provenance,
    ) -> GuardResult[CandidateMemoryOutput]:
        return self.memory_guard.save_candidate_memory(
            spec,
            provenance=provenance,
        )

    def audit_result(
        self,
        result: GuardResult[Any],
        *,
        result_summary: str | None = None,
        redactions: tuple[str, ...] = (),
        outcome: str | None = None,
    ) -> None:
        self.audit_logger.append(
            build_audit_record(
                system=self.system_name,
                request=result.request,
                result=result.policy_result,
                outcome=outcome or 'policy_decision',
                result_summary=result_summary,
                redactions=redactions,
            )
        )

    def serialize_blocked_result(self, result: GuardResult[Any]) -> dict[str, Any]:
        primary_reason = result.policy_result.reasons[0]
        payload: dict[str, Any] = {
            'executed': False,
            'request_id': result.request.request_id,
            'capability': result.request.capability.value,
            'resource': result.request.resource.locator,
            'decision': result.policy_result.decision.value,
            'matched_policy': result.policy_result.matched_policy,
            'reason_code': primary_reason.code,
            'reason': primary_reason.message,
            'details': primary_reason.details,
            'approval_ticket_id': result.policy_result.approval_ticket_id,
            'approval_store': str(self.approval_store_path),
            'audit_log': str(self.audit_log_path),
        }
        return payload
