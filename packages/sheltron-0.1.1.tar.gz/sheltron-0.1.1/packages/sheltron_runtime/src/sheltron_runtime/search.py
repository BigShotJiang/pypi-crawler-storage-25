from __future__ import annotations

from dataclasses import dataclass

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.content_risk import assess_secret_like_content
from sheltron_runtime.guard_support import evaluate_policy, new_request_id
from sheltron_runtime.runtime_types import GuardResult, SearchSpec


@dataclass(slots=True)
class LocalSearchGuard:
    policy_engine: PolicyEngine
    approval_store: ApprovalStore | None = None

    def search_web(
        self,
        spec: SearchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[SearchSpec]:
        normalized_spec = self._normalize_spec(spec)
        request = self._build_request(normalized_spec, provenance=provenance)
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, normalized_spec)

    def _build_request(
        self,
        spec: SearchSpec,
        *,
        provenance: Provenance,
    ) -> ActionRequest:
        query = spec.query.strip()
        risk = assess_secret_like_content(query)
        provider = spec.provider.strip().lower()
        backend_kind = spec.backend_kind.strip().lower()
        return ActionRequest(
            request_id=new_request_id('search'),
            capability=Capability.SEARCH_WEB,
            resource=ResourceDescriptor(
                kind=ResourceKind.SEARCH_QUERY,
                locator=query,
            ),
            provenance=provenance,
            parameters={
                'query': query,
                'query_chars': len(query),
                'count': spec.count,
                'provider': provider,
                'backend_kind': backend_kind,
                'suspicious_token_count': len(risk.suspicious_token_matches),
                'suspicious_token_matches': risk.suspicious_token_matches,
                'private_key_markers': risk.private_key_markers,
            },
        )

    @staticmethod
    def _normalize_spec(spec: SearchSpec) -> SearchSpec:
        return SearchSpec(
            query=spec.query.strip(),
            count=spec.count,
            provider=spec.provider.strip().lower(),
            backend_kind=spec.backend_kind.strip().lower(),
        )
