from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Generic, TypeVar

from sheltron_core.schemas import ActionRequest, PolicyResult

T = TypeVar("T")


@dataclass(slots=True)
class CommandSpec:
    command: tuple[str, ...]
    cwd: Path | None = None
    env: dict[str, str] = field(default_factory=dict)
    stdin: str | None = None
    timeout_seconds: int | None = None


@dataclass(slots=True)
class CommandOutput:
    exit_code: int
    stdout: str
    stderr: str


@dataclass(slots=True)
class FileReadSpec:
    path: Path
    encoding: str = "utf-8"


@dataclass(slots=True)
class FileWriteSpec:
    path: Path
    content: str
    encoding: str = "utf-8"
    create_parents: bool = False


@dataclass(slots=True)
class FileEditSpec:
    path: Path
    old_text: str
    new_text: str
    encoding: str = "utf-8"


@dataclass(slots=True)
class DirectoryListSpec:
    path: Path


@dataclass(slots=True)
class DirectoryEntry:
    path: Path
    is_dir: bool
    size_bytes: int | None = None


@dataclass(slots=True)
class FetchSpec:
    url: str
    headers: dict[str, str] = field(default_factory=dict)
    max_bytes: int | None = None
    timeout_seconds: int | None = None


@dataclass(slots=True)
class SearchSpec:
    query: str
    count: int
    provider: str
    backend_kind: str = "host_native"


@dataclass(slots=True)
class PostSpec:
    url: str
    body: bytes | None = None
    headers: dict[str, str] = field(default_factory=dict)
    max_bytes: int | None = None
    timeout_seconds: int | None = None


@dataclass(slots=True)
class NetworkResponse:
    status_code: int
    body: bytes
    content_type: str | None = None
    final_url: str | None = None
    truncated: bool = False
    error: str | None = None


@dataclass(slots=True)
class SendMessageSpec:
    channel: str
    recipient: str
    content: str
    reply_to: str | None = None
    media: tuple[str, ...] = field(default_factory=tuple)
    default_channel: str | None = None
    default_recipient: str | None = None


@dataclass(slots=True)
class MessageOutput:
    channel: str
    recipient: str
    content: str
    reply_to: str | None = None
    media: tuple[str, ...] = field(default_factory=tuple)
    redacted: bool = False


@dataclass(slots=True)
class ScheduledTaskSpec:
    task_kind: str
    action: str | None = None
    task: str | None = None
    label: str | None = None
    message: str | None = None
    every_seconds: int | None = None
    cron_expr: str | None = None
    tz: str | None = None
    at: str | None = None
    job_id: str | None = None
    default_channel: str | None = None
    default_recipient: str | None = None
    in_cron_context: bool = False


@dataclass(slots=True)
class ScheduledTaskOutput:
    task_kind: str
    action: str | None = None
    target_locator: str | None = None


@dataclass(slots=True)
class CandidateMemorySpec:
    key: str
    content: str
    summary: str | None = None
    mode: str = "replace"
    target_path: Path | None = None


@dataclass(slots=True)
class CandidateMemoryOutput:
    candidate_id: str
    key: str
    summary: str | None = None
    mode: str = "replace"
    target_path: Path | None = None


@dataclass(slots=True)
class GuardResult(Generic[T]):
    request: ActionRequest
    policy_result: PolicyResult
    executed: bool
    value: T | None = None

    @property
    def blocked(self) -> bool:
        return not self.executed

    @classmethod
    def completed(
        cls,
        request: ActionRequest,
        policy_result: PolicyResult,
        value: T,
    ) -> GuardResult[T]:
        return cls(
            request=request,
            policy_result=policy_result,
            executed=True,
            value=value,
        )

    @classmethod
    def rejected(
        cls,
        request: ActionRequest,
        policy_result: PolicyResult,
    ) -> GuardResult[None]:
        return cls(
            request=request,
            policy_result=policy_result,
            executed=False,
            value=None,
        )
