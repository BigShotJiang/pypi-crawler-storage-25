from __future__ import annotations

from typing import Protocol, runtime_checkable

from sheltron_core.schemas import Provenance
from sheltron_runtime.runtime_types import (
    CandidateMemoryOutput,
    CandidateMemorySpec,
    CommandOutput,
    CommandSpec,
    DirectoryEntry,
    DirectoryListSpec,
    FetchSpec,
    FileEditSpec,
    FileReadSpec,
    FileWriteSpec,
    GuardResult,
    MessageOutput,
    NetworkResponse,
    PostSpec,
    ScheduledTaskOutput,
    ScheduledTaskSpec,
    SearchSpec,
    SendMessageSpec,
)


@runtime_checkable
class ExecGuard(Protocol):
    def execute(
        self,
        spec: CommandSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[CommandOutput]:
        ...


@runtime_checkable
class FileSystemGuard(Protocol):
    def read_text(
        self,
        spec: FileReadSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[str]:
        ...

    def write_text(
        self,
        spec: FileWriteSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        ...

    def edit_text(
        self,
        spec: FileEditSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        ...

    def list_directory(
        self,
        spec: DirectoryListSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[tuple[DirectoryEntry, ...]]:
        ...


@runtime_checkable
class SearchGuard(Protocol):
    def search_web(
        self,
        spec: SearchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[SearchSpec]:
        ...


@runtime_checkable
class NetworkGuard(Protocol):
    def fetch(
        self,
        spec: FetchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[NetworkResponse]:
        ...

    def post(
        self,
        spec: PostSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[NetworkResponse]:
        ...


@runtime_checkable
class MessageGuard(Protocol):
    def send_message(
        self,
        spec: SendMessageSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[MessageOutput]:
        ...


@runtime_checkable
class ScheduleTaskGuard(Protocol):
    def schedule_task(
        self,
        spec: ScheduledTaskSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[ScheduledTaskOutput]:
        ...


@runtime_checkable
class MemoryGuard(Protocol):
    def save_candidate_memory(
        self,
        spec: CandidateMemorySpec,
        *,
        provenance: Provenance,
    ) -> GuardResult[CandidateMemoryOutput]:
        ...
