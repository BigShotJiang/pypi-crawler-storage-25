from __future__ import annotations

from dataclasses import dataclass
import re

from sheltron_core.candidate_memory import JsonlCandidateMemoryStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.content_risk import assess_secret_like_content
from sheltron_runtime.guard_support import build_policy_context, hash_text, new_request_id
from sheltron_runtime.runtime_types import CandidateMemoryOutput, CandidateMemorySpec, GuardResult
_SUSPICIOUS_MEMORY_PATTERNS = (
    re.compile(r'ignore (?:all )?(?:previous|prior) instructions', re.IGNORECASE),
    re.compile(r'always (?:allow|approve|permit)', re.IGNORECASE),
    re.compile(r'(?:permission|policy|rules?) (?:changed|updated|overridden)', re.IGNORECASE),
    re.compile(r'(?:you|agent) (?:are|is) allowed to', re.IGNORECASE),
    re.compile(r'(?:remember|store).*(?:ignore|override).*(?:instructions|policy|rules?)', re.IGNORECASE),
)


@dataclass(frozen=True, slots=True)
class MemoryRiskAssessment:
    suspicious_token_matches: tuple[str, ...] = ()
    suspicious_instruction_matches: tuple[str, ...] = ()
    private_key_markers: tuple[str, ...] = ()


@dataclass(slots=True)
class LocalMemoryGuard:
    policy_engine: PolicyEngine
    candidate_store: JsonlCandidateMemoryStore

    def save_candidate_memory(
        self,
        spec: CandidateMemorySpec,
        *,
        provenance: Provenance,
    ) -> GuardResult[CandidateMemoryOutput]:
        risk = self._assess_content(spec.content)
        request = self._build_request(spec, provenance=provenance, risk=risk)
        policy_result = self.policy_engine.evaluate(request, build_policy_context())
        if policy_result.decision is Decision.DENY:
            return GuardResult.rejected(request, policy_result)

        # For memory, the guarded side effect is creating the candidate record.
        # Later host-specific flows decide whether to auto-commit or review it.
        entry = self.candidate_store.create(
            request,
            content=spec.content,
            summary=spec.summary,
            mode=spec.mode,
            target_path=spec.target_path,
        )
        output = CandidateMemoryOutput(
            candidate_id=entry.candidate_id,
            key=entry.request.resource.locator,
            summary=entry.summary,
            mode=entry.mode,
            target_path=None if entry.target_path is None else spec.target_path,
        )
        return GuardResult.completed(request, policy_result, output)

    def _build_request(
        self,
        spec: CandidateMemorySpec,
        *,
        provenance: Provenance,
        risk: MemoryRiskAssessment,
    ) -> ActionRequest:
        return ActionRequest(
            request_id=new_request_id('mem'),
            capability=Capability.MEMORY_WRITE,
            resource=ResourceDescriptor(
                kind=ResourceKind.MEMORY_KEY,
                locator=spec.key,
            ),
            provenance=provenance,
            parameters={
                'summary': spec.summary,
                'mode': spec.mode,
                'content_chars': len(spec.content),
                'content_sha256': hash_text(spec.content),
                'target_path': None if spec.target_path is None else str(spec.target_path),
                'suspicious_token_count': len(risk.suspicious_token_matches),
                'suspicious_token_matches': risk.suspicious_token_matches,
                'suspicious_instruction_count': len(risk.suspicious_instruction_matches),
                'suspicious_instruction_matches': risk.suspicious_instruction_matches,
                'private_key_markers': risk.private_key_markers,
            },
        )

    @staticmethod
    def _assess_content(content: str) -> MemoryRiskAssessment:
        assessment = assess_secret_like_content(content)

        suspicious_instruction_matches: list[str] = []
        for pattern in _SUSPICIOUS_MEMORY_PATTERNS:
            suspicious_instruction_matches.extend(match.group(0) for match in pattern.finditer(content))

        return MemoryRiskAssessment(
            suspicious_token_matches=assessment.suspicious_token_matches,
            suspicious_instruction_matches=tuple(dict.fromkeys(suspicious_instruction_matches)),
            private_key_markers=assessment.private_key_markers,
        )
