from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, ConfigDict

from sheltron_runtime.adapter import ProtectionMode


class DoctorStatus(str, Enum):
    OK = 'ok'
    WARN = 'warn'
    FAIL = 'fail'


class DoctorCheck(BaseModel):
    model_config = ConfigDict(extra='forbid')

    name: str
    status: DoctorStatus
    detail: str


class DoctorReport(BaseModel):
    model_config = ConfigDict(extra='forbid')

    protection_mode: ProtectionMode = ProtectionMode.UNPROTECTED
    checks: tuple[DoctorCheck, ...]

    @property
    def healthy(self) -> bool:
        return all(check.status is not DoctorStatus.FAIL for check in self.checks)
