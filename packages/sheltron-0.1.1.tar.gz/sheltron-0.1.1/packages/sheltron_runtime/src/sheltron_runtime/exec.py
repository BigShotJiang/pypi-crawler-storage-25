from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import subprocess

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.resources import PathPolicyContext
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.guard_support import evaluate_policy, hash_mapping, hash_text, new_request_id
from sheltron_runtime.runtime_types import CommandOutput, CommandSpec, GuardResult


@dataclass(slots=True)
class LocalExecGuard:
    policy_engine: PolicyEngine
    path_policy: PathPolicyContext
    working_directory: Path | None = None
    approval_store: ApprovalStore | None = None
    default_timeout_seconds: int = 60
    max_timeout_seconds: int = 600
    max_output_chars: int = 10_000
    inherited_env_keys: tuple[str, ...] = ('PATH', 'LANG', 'LC_ALL', 'TERM')

    def execute(
        self,
        spec: CommandSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[CommandOutput]:
        if not spec.command:
            raise ValueError('CommandSpec.command must not be empty.')

        normalized_cwd = self.path_policy.normalize_path(
            spec.cwd or Path('.'),
            cwd=self.working_directory,
        )
        timeout_seconds = self._resolve_timeout(spec.timeout_seconds)
        request = self._build_request(
            spec,
            provenance=provenance,
            normalized_cwd=normalized_cwd,
            timeout_seconds=timeout_seconds,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            path_policy=self.path_policy,
            working_directory=self.working_directory,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)

        completed = self._run_subprocess(
            spec,
            cwd=normalized_cwd,
            timeout_seconds=timeout_seconds,
        )
        return GuardResult.completed(request, final_policy_result, completed)

    def authorize_execute(
        self,
        spec: CommandSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        if not spec.command:
            raise ValueError('CommandSpec.command must not be empty.')

        normalized_cwd = self.path_policy.normalize_path(
            spec.cwd or Path('.'),
            cwd=self.working_directory,
        )
        timeout_seconds = self._resolve_timeout(spec.timeout_seconds)
        request = self._build_request(
            spec,
            provenance=provenance,
            normalized_cwd=normalized_cwd,
            timeout_seconds=timeout_seconds,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            path_policy=self.path_policy,
            working_directory=self.working_directory,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(request, final_policy_result, None)

    def _build_request(
        self,
        spec: CommandSpec,
        *,
        provenance: Provenance,
        normalized_cwd: Path,
        timeout_seconds: int,
    ) -> ActionRequest:
        return ActionRequest(
            request_id=new_request_id('exec'),
            capability=Capability.EXEC,
            resource=ResourceDescriptor(
                kind=ResourceKind.COMMAND,
                locator=' '.join(spec.command),
                metadata={'argv': list(spec.command)},
            ),
            provenance=provenance,
            parameters={
                'argv': spec.command,
                'cwd': str(normalized_cwd),
                'env_keys': tuple(sorted(spec.env)),
                'env_sha256': hash_mapping(spec.env),
                'stdin_sha256': None if spec.stdin is None else hash_text(spec.stdin),
                'timeout_seconds': timeout_seconds,
            },
        )

    def _run_subprocess(
        self,
        spec: CommandSpec,
        *,
        cwd: Path,
        timeout_seconds: int,
    ) -> CommandOutput:
        env = self._build_env(spec.env)
        try:
            completed = subprocess.run(
                spec.command,
                input=spec.stdin,
                capture_output=True,
                text=True,
                cwd=cwd,
                env=env,
                timeout=timeout_seconds,
                check=False,
            )
        except subprocess.TimeoutExpired as exc:
            stdout = self._coerce_text(exc.stdout)
            stderr = self._coerce_text(exc.stderr)
            timeout_message = f'Command timed out after {timeout_seconds} seconds.'
            stderr = timeout_message if not stderr else f'{stderr}\n{timeout_message}'
            return CommandOutput(
                exit_code=-1,
                stdout=self._truncate_output(stdout),
                stderr=self._truncate_output(stderr),
            )
        except FileNotFoundError as exc:
            return CommandOutput(
                exit_code=-1,
                stdout='',
                stderr=self._truncate_output(str(exc)),
            )
        except OSError as exc:
            return CommandOutput(
                exit_code=-1,
                stdout='',
                stderr=self._truncate_output(str(exc)),
            )

        return CommandOutput(
            exit_code=completed.returncode,
            stdout=self._truncate_output(completed.stdout),
            stderr=self._truncate_output(completed.stderr),
        )

    def _build_env(self, explicit_env: dict[str, str]) -> dict[str, str]:
        inherited = {
            key: os.environ[key]
            for key in self.inherited_env_keys
            if key in os.environ
        }
        inherited.update(explicit_env)
        return inherited

    def _resolve_timeout(self, requested_timeout: int | None) -> int:
        if requested_timeout is None:
            timeout = self.default_timeout_seconds
        else:
            timeout = requested_timeout
        if timeout <= 0:
            raise ValueError('CommandSpec.timeout_seconds must be positive when provided.')
        return min(timeout, self.max_timeout_seconds)

    def _truncate_output(self, value: str) -> str:
        if len(value) <= self.max_output_chars:
            return value
        half = max(1, self.max_output_chars // 2)
        truncated_count = len(value) - self.max_output_chars
        return (
            value[:half]
            + f'\n\n... ({truncated_count:,} chars truncated) ...\n\n'
            + value[-half:]
        )

    @staticmethod
    def _coerce_text(value: str | bytes | None) -> str:
        if value is None:
            return ''
        if isinstance(value, bytes):
            return value.decode('utf-8', errors='replace')
        return value
