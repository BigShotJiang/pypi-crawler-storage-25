from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from sheltron_core.schemas import Capability, Provenance
from sheltron_runtime.gateway import SheltronGateway
from sheltron_runtime.runtime_types import (
    CandidateMemoryOutput,
    CandidateMemorySpec,
    CommandSpec,
    DirectoryListSpec,
    FetchSpec,
    FileEditSpec,
    FileReadSpec,
    FileWriteSpec,
    GuardResult,
    MessageOutput,
    PostSpec,
    ScheduledTaskOutput,
    ScheduledTaskSpec,
    SearchSpec,
    SendMessageSpec,
)


class GatewayAction(str, Enum):
    READ_FILE = 'read_file'
    WRITE_FILE = 'write_file'
    EDIT_FILE = 'edit_file'
    LIST_DIRECTORY = 'list_directory'
    EXECUTE_COMMAND = 'execute_command'
    SEARCH_WEB = 'search_web'
    FETCH_URL = 'fetch_url'
    POST_URL = 'post_url'
    SEND_MESSAGE = 'send_message'
    SCHEDULE_TASK = 'schedule_task'
    SAVE_CANDIDATE_MEMORY = 'save_candidate_memory'
    BROKER_TOOL_CALL = 'broker_tool_call'


class ProtectionMode(str, Enum):
    UNPROTECTED = 'unprotected'
    CONNECTOR = 'connector'
    MANAGED_GATEWAY = 'managed-gateway'


class HookEventKind(str, Enum):
    SESSION_START = 'session_start'
    SESSION_END = 'session_end'
    BEFORE_ACTION = 'before_action'
    AFTER_ACTION = 'after_action'
    BEFORE_PROMPT_BUILD = 'before_prompt_build'
    MESSAGE_RECEIVED = 'message_received'
    BEFORE_MESSAGE_SEND = 'before_message_send'
    AFTER_MESSAGE_SEND = 'after_message_send'
    BEFORE_MEMORY_WRITE = 'before_memory_write'
    BEFORE_TOOL_BROKER = 'before_tool_broker'
    AFTER_TOOL_BROKER = 'after_tool_broker'
    TOOL_RESULT_PERSIST = 'tool_result_persist'


@dataclass(slots=True)
class HookEvent:
    kind: HookEventKind
    action: GatewayAction | None = None
    provenance: Provenance | None = None
    spec: object | None = None
    result: object | None = None
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class HookDecision:
    blocked_result: object | None = None
    transformed_result: object | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    stop_propagation: bool = False


@runtime_checkable
class GatewayHook(Protocol):
    def handle_event(self, event: HookEvent) -> HookDecision | None:
        ...


@runtime_checkable
class HookReadyGatewayAdapter(Protocol):
    workspace: Path
    approval_store_path: Path
    audit_log_path: Path
    candidate_memory_store_path: Path
    system_name: str
    hooks: tuple[GatewayHook, ...]

    def before_action(
        self,
        action: GatewayAction,
        spec: object,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[Any]:
        ...

    def after_action(
        self,
        result: GuardResult[Any],
        *,
        result_summary: str | None = None,
        redactions: tuple[str, ...] = (),
        outcome: str | None = None,
    ) -> GuardResult[Any]:
        ...

    def serialize_blocked_result(self, result: GuardResult[Any]) -> dict[str, Any]:
        ...

    def emit_hook_event(
        self,
        kind: HookEventKind,
        *,
        action: GatewayAction | None = None,
        provenance: Provenance | None = None,
        spec: object | None = None,
        result: object | None = None,
        payload: dict[str, Any] | None = None,
    ) -> HookDecision:
        ...


@dataclass(slots=True)
class SheltronGatewayAdapter:
    gateway: SheltronGateway
    hooks: tuple[GatewayHook, ...] = ()

    @classmethod
    def for_workspace(
        cls,
        workspace: str | Path | None = None,
        hooks: tuple[GatewayHook, ...] = (),
        **kwargs: Any,
    ) -> SheltronGatewayAdapter:
        return cls(
            SheltronGateway.for_workspace(workspace, **kwargs),
            hooks=hooks,
        )

    @property
    def workspace(self) -> Path:
        return self.gateway.workspace

    @property
    def approval_store_path(self) -> Path:
        return self.gateway.approval_store_path

    @property
    def audit_log_path(self) -> Path:
        return self.gateway.audit_log_path

    @property
    def candidate_memory_store_path(self) -> Path:
        return self.gateway.candidate_memory_store_path

    @property
    def system_name(self) -> str:
        return self.gateway.system_name

    def before_action(
        self,
        action: GatewayAction,
        spec: object,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[Any]:
        blocked = self._blocked_guard_result(
            self.emit_hook_event(
                HookEventKind.BEFORE_ACTION,
                action=action,
                provenance=provenance,
                spec=spec,
                payload={'approval_ticket_id': approval_ticket_id},
            ),
            kind=HookEventKind.BEFORE_ACTION,
        )
        if blocked is not None:
            return blocked
        if action is GatewayAction.READ_FILE:
            return self.gateway.read_file(
                _expect_spec(FileReadSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.WRITE_FILE:
            return self.gateway.write_file(
                _expect_spec(FileWriteSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.EDIT_FILE:
            return self.gateway.edit_file(
                _expect_spec(FileEditSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.LIST_DIRECTORY:
            return self.gateway.list_directory(
                _expect_spec(DirectoryListSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.EXECUTE_COMMAND:
            return self.gateway.execute_command(
                _expect_spec(CommandSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.SEARCH_WEB:
            return self.gateway.search_web(
                _expect_spec(SearchSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.FETCH_URL:
            return self.gateway.fetch_url(
                _expect_spec(FetchSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.POST_URL:
            return self.gateway.post_url(
                _expect_spec(PostSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.SEND_MESSAGE:
            return self.gateway.send_message(
                _expect_spec(SendMessageSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.SCHEDULE_TASK:
            return self.gateway.schedule_task(
                _expect_spec(ScheduledTaskSpec, spec, action),
                provenance=provenance,
                approval_ticket_id=approval_ticket_id,
            )
        if action is GatewayAction.SAVE_CANDIDATE_MEMORY:
            return self.gateway.save_candidate_memory(
                _expect_spec(CandidateMemorySpec, spec, action),
                provenance=provenance,
            )
        raise ValueError(f'Unsupported gateway action: {action.value}')

    def before_message_send(
        self,
        spec: SendMessageSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[MessageOutput]:
        blocked = self._blocked_guard_result(
            self.emit_hook_event(
                HookEventKind.BEFORE_MESSAGE_SEND,
                action=GatewayAction.SEND_MESSAGE,
                provenance=provenance,
                spec=spec,
                payload={
                    'channel': spec.channel,
                    'recipient': spec.recipient,
                    'approval_ticket_id': approval_ticket_id,
                },
            ),
            kind=HookEventKind.BEFORE_MESSAGE_SEND,
        )
        if blocked is not None:
            return blocked
        return self.before_action(
            GatewayAction.SEND_MESSAGE,
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def before_schedule_task(
        self,
        spec: ScheduledTaskSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[ScheduledTaskOutput]:
        return self.before_action(
            GatewayAction.SCHEDULE_TASK,
            spec,
            provenance=provenance,
            approval_ticket_id=approval_ticket_id,
        )

    def before_memory_write(
        self,
        spec: CandidateMemorySpec,
        *,
        provenance: Provenance,
    ) -> GuardResult[CandidateMemoryOutput]:
        blocked = self._blocked_guard_result(
            self.emit_hook_event(
                HookEventKind.BEFORE_MEMORY_WRITE,
                action=GatewayAction.SAVE_CANDIDATE_MEMORY,
                provenance=provenance,
                spec=spec,
                payload={'key': spec.key, 'mode': spec.mode},
            ),
            kind=HookEventKind.BEFORE_MEMORY_WRITE,
        )
        if blocked is not None:
            return blocked
        return self.before_action(
            GatewayAction.SAVE_CANDIDATE_MEMORY,
            spec,
            provenance=provenance,
        )

    def after_action(
        self,
        result: GuardResult[Any],
        *,
        result_summary: str | None = None,
        redactions: tuple[str, ...] = (),
        outcome: str | None = None,
    ) -> GuardResult[Any]:
        decision = self.emit_hook_event(
            HookEventKind.AFTER_ACTION,
            action=_action_from_request(result.request.capability, result.request.parameters),
            provenance=result.request.provenance,
            spec=result.request.parameters,
            result=result,
            payload={
                'result_summary': result_summary,
                'redactions': list(redactions),
                'outcome': outcome,
            },
        )
        effective_result = result
        transformed = decision.transformed_result
        if (
            isinstance(transformed, GuardResult)
            and not result.executed
            and not transformed.executed
        ):
            effective_result = transformed
        self.gateway.audit_result(
            effective_result,
            result_summary=result_summary,
            redactions=redactions,
            outcome=outcome,
        )
        return effective_result

    def serialize_blocked_result(self, result: GuardResult[Any]) -> dict[str, Any]:
        return self.gateway.serialize_blocked_result(result)

    def emit_hook_event(
        self,
        kind: HookEventKind,
        *,
        action: GatewayAction | None = None,
        provenance: Provenance | None = None,
        spec: object | None = None,
        result: object | None = None,
        payload: dict[str, Any] | None = None,
    ) -> HookDecision:
        event = HookEvent(
            kind=kind,
            action=action,
            provenance=provenance,
            spec=spec,
            result=result,
            payload=dict(payload or {}),
        )
        merged = HookDecision()
        for hook in self.hooks:
            decision = hook.handle_event(event)
            if decision is None:
                continue
            if decision.blocked_result is not None:
                merged.blocked_result = decision.blocked_result
            if decision.transformed_result is not None:
                merged.transformed_result = decision.transformed_result
            if decision.metadata:
                merged.metadata.update(decision.metadata)
            if decision.stop_propagation:
                merged.stop_propagation = True
                break
        return merged

    def session_start(
        self,
        *,
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        return self.emit_hook_event(
            HookEventKind.SESSION_START,
            provenance=provenance,
            payload=metadata,
        )

    def session_end(
        self,
        *,
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        return self.emit_hook_event(
            HookEventKind.SESSION_END,
            provenance=provenance,
            payload=metadata,
        )

    def before_prompt_build(
        self,
        prompt: str,
        *,
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        payload = dict(metadata or {})
        payload['prompt'] = prompt
        return self.emit_hook_event(
            HookEventKind.BEFORE_PROMPT_BUILD,
            provenance=provenance,
            payload=payload,
        )

    def message_received(
        self,
        *,
        channel: str,
        sender: str,
        content: str,
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        payload = dict(metadata or {})
        payload.update({'channel': channel, 'sender': sender, 'content': content})
        return self.emit_hook_event(
            HookEventKind.MESSAGE_RECEIVED,
            provenance=provenance,
            payload=payload,
        )

    def after_message_send(
        self,
        *,
        output: MessageOutput,
        provenance: Provenance | None = None,
        delivery: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        payload = dict(metadata or {})
        payload.update(
            {
                'channel': output.channel,
                'recipient': output.recipient,
                'reply_to': output.reply_to,
                'media_count': len(output.media),
                'delivery': delivery,
            }
        )
        return self.emit_hook_event(
            HookEventKind.AFTER_MESSAGE_SEND,
            action=GatewayAction.SEND_MESSAGE,
            provenance=provenance,
            spec=output,
            payload=payload,
        )

    def before_tool_broker(
        self,
        *,
        namespaced_tool: str,
        arguments: dict[str, Any],
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        payload = dict(metadata or {})
        payload.update({'namespaced_tool': namespaced_tool, 'arguments': dict(arguments)})
        return self.emit_hook_event(
            HookEventKind.BEFORE_TOOL_BROKER,
            provenance=provenance,
            payload=payload,
        )

    def after_tool_broker(
        self,
        *,
        namespaced_tool: str,
        arguments: dict[str, Any],
        result: object,
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        payload = dict(metadata or {})
        payload.update({'namespaced_tool': namespaced_tool, 'arguments': dict(arguments)})
        return self.emit_hook_event(
            HookEventKind.AFTER_TOOL_BROKER,
            provenance=provenance,
            result=result,
            payload=payload,
        )

    def tool_result_persist(
        self,
        *,
        tool_name: str,
        result: object,
        provenance: Provenance | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> HookDecision:
        payload = dict(metadata or {})
        payload['tool_name'] = tool_name
        return self.emit_hook_event(
            HookEventKind.TOOL_RESULT_PERSIST,
            provenance=provenance,
            result=result,
            payload=payload,
        )

    @staticmethod
    def _blocked_guard_result(
        decision: HookDecision,
        *,
        kind: HookEventKind,
    ) -> GuardResult[Any] | None:
        if decision.blocked_result is None:
            return None
        if isinstance(decision.blocked_result, GuardResult):
            if decision.blocked_result.executed:
                raise TypeError(
                    f'Hook event `{kind.value}` returned an executed GuardResult as blocked_result.'
                )
            return decision.blocked_result
        raise TypeError(
            f'Hook event `{kind.value}` returned a non-GuardResult blocked_result: '
            f'{type(decision.blocked_result).__name__}'
        )


def _expect_spec(expected_type: type[Any], spec: object, action: GatewayAction) -> Any:
    if not isinstance(spec, expected_type):
        raise TypeError(
            f'Gateway action `{action.value}` expected `{expected_type.__name__}`, '
            f'got `{type(spec).__name__}`.'
        )
    return spec


def _action_from_request(
    capability: Capability,
    parameters: dict[str, Any],
) -> GatewayAction | None:
    if capability is Capability.READ_FILE and parameters.get('operation') == 'list_directory':
        return GatewayAction.LIST_DIRECTORY
    if capability is Capability.READ_FILE:
        return GatewayAction.READ_FILE
    if capability is Capability.WRITE_FILE:
        return GatewayAction.WRITE_FILE
    if capability is Capability.EDIT_FILE:
        return GatewayAction.EDIT_FILE
    if capability is Capability.EXEC:
        return GatewayAction.EXECUTE_COMMAND
    if capability is Capability.SEARCH_WEB:
        return GatewayAction.SEARCH_WEB
    if capability is Capability.NETWORK_FETCH:
        return GatewayAction.FETCH_URL
    if capability is Capability.NETWORK_POST:
        return GatewayAction.POST_URL
    if capability is Capability.SEND_MESSAGE:
        return GatewayAction.SEND_MESSAGE
    if capability is Capability.SCHEDULE_TASK:
        return GatewayAction.SCHEDULE_TASK
    if capability is Capability.MEMORY_WRITE:
        return GatewayAction.SAVE_CANDIDATE_MEMORY
    if capability is Capability.TOOL_BROKER_CALL:
        return GatewayAction.BROKER_TOOL_CALL
    if capability is Capability.MCP_BROKER_CALL:
        return GatewayAction.BROKER_TOOL_CALL
    return None
