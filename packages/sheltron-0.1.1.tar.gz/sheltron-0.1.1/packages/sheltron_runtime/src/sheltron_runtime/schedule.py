from __future__ import annotations

from dataclasses import dataclass

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.guard_support import evaluate_policy, new_request_id
from sheltron_runtime.runtime_types import GuardResult, ScheduledTaskOutput, ScheduledTaskSpec


@dataclass(slots=True)
class LocalScheduleTaskGuard:
    policy_engine: PolicyEngine
    approval_store: ApprovalStore | None = None

    def schedule_task(
        self,
        spec: ScheduledTaskSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[ScheduledTaskOutput]:
        request = self._build_request(spec, provenance=provenance)
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request, final_policy_result)
        return GuardResult.completed(
            request,
            final_policy_result,
            ScheduledTaskOutput(
                task_kind=spec.task_kind,
                action=spec.action,
                target_locator=request.resource.locator,
            ),
        )

    def _build_request(
        self,
        spec: ScheduledTaskSpec,
        *,
        provenance: Provenance,
    ) -> ActionRequest:
        resource_locator = self._resource_locator(spec)
        return ActionRequest(
            request_id=new_request_id('task'),
            capability=Capability.SCHEDULE_TASK,
            resource=ResourceDescriptor(
                kind=ResourceKind.TASK_TARGET,
                locator=resource_locator,
            ),
            provenance=provenance,
            parameters={
                'task_kind': spec.task_kind,
                'action': spec.action,
                'task': spec.task,
                'task_chars': 0 if spec.task is None else len(spec.task),
                'label': spec.label,
                'message': spec.message,
                'message_chars': 0 if spec.message is None else len(spec.message),
                'every_seconds': spec.every_seconds,
                'cron_expr': spec.cron_expr,
                'tz': spec.tz,
                'at': spec.at,
                'job_id': spec.job_id,
                'default_channel': spec.default_channel,
                'default_recipient': spec.default_recipient,
                'in_cron_context': spec.in_cron_context,
            },
        )

    @staticmethod
    def _resource_locator(spec: ScheduledTaskSpec) -> str:
        channel = spec.default_channel or 'unknown'
        recipient = spec.default_recipient or 'unknown'
        return f'{spec.task_kind}:{channel}:{recipient}'
