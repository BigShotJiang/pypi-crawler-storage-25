from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from http import client
import socket
import ssl
from urllib import parse

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyEngine
from sheltron_core.schemas import (
    ActionRequest,
    Capability,
    Decision,
    Provenance,
    ResourceDescriptor,
    ResourceKind,
)
from sheltron_runtime.guard_support import evaluate_policy, hash_bytes, hash_mapping, new_request_id
from sheltron_runtime.runtime_types import FetchSpec, GuardResult, NetworkResponse, PostSpec


@dataclass(frozen=True, slots=True)
class _VerifiedNetworkTarget:
    url: str
    scheme: str
    hostname: str
    port: int | None
    path_and_query: str
    host_header: str
    resolved_ips: tuple[str, ...]


class _PinnedHTTPSConnection(client.HTTPSConnection):
    def __init__(
        self,
        *,
        connect_host: str,
        server_hostname: str,
        port: int | None,
        timeout: int,
    ) -> None:
        super().__init__(host=server_hostname, port=port, timeout=timeout)
        self._connect_host = connect_host

    def connect(self) -> None:
        sock = self._create_connection((self._connect_host, self.port), self.timeout, self.source_address)
        if self._tunnel_host:
            self.sock = sock
            self._tunnel()
        self.sock = self._context.wrap_socket(sock, server_hostname=self.host)


def resolve_host_ips(hostname: str, port: int | None) -> tuple[str, ...]:
    infos = socket.getaddrinfo(
        hostname,
        port,
        type=socket.SOCK_STREAM,
        proto=socket.IPPROTO_TCP,
    )
    return tuple(sorted({info[4][0] for info in infos}))


@dataclass(slots=True)
class LocalNetworkGuard:
    policy_engine: PolicyEngine
    approval_store: ApprovalStore | None = None
    default_timeout_seconds: int = 30
    max_timeout_seconds: int = 300
    default_max_bytes: int = 262_144
    max_response_bytes: int = 1_048_576
    resolver: Callable[[str, int | None], tuple[str, ...]] = resolve_host_ips
    transport: Callable[
        [str, str, dict[str, str], bytes | None, int, int],
        NetworkResponse,
    ] | None = None

    def fetch(
        self,
        spec: FetchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[NetworkResponse]:
        timeout_seconds = self._resolve_timeout(spec.timeout_seconds)
        max_bytes = self._resolve_max_bytes(spec.max_bytes)
        request_model = self._build_request(
            spec.url,
            capability=Capability.NETWORK_FETCH,
            provenance=provenance,
            headers=spec.headers,
            body=None,
            timeout_seconds=timeout_seconds,
            max_bytes=max_bytes,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request_model,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request_model, final_policy_result)

        target = self._build_transport_target(request_model)
        response = self._perform_request(
            'GET',
            target,
            spec.headers,
            None,
            timeout_seconds,
            max_bytes,
        )
        return GuardResult.completed(request_model, final_policy_result, response)

    def authorize_fetch(
        self,
        spec: FetchSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        timeout_seconds = self._resolve_timeout(spec.timeout_seconds)
        max_bytes = self._resolve_max_bytes(spec.max_bytes)
        request_model = self._build_request(
            spec.url,
            capability=Capability.NETWORK_FETCH,
            provenance=provenance,
            headers=spec.headers,
            body=None,
            timeout_seconds=timeout_seconds,
            max_bytes=max_bytes,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request_model,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request_model, final_policy_result)
        return GuardResult.completed(request_model, final_policy_result, None)

    def post(
        self,
        spec: PostSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[NetworkResponse]:
        timeout_seconds = self._resolve_timeout(spec.timeout_seconds)
        max_bytes = self._resolve_max_bytes(spec.max_bytes)
        request_model = self._build_request(
            spec.url,
            capability=Capability.NETWORK_POST,
            provenance=provenance,
            headers=spec.headers,
            body=spec.body,
            timeout_seconds=timeout_seconds,
            max_bytes=max_bytes,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request_model,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request_model, final_policy_result)

        target = self._build_transport_target(request_model)
        response = self._perform_request(
            'POST',
            target,
            spec.headers,
            spec.body,
            timeout_seconds,
            max_bytes,
        )
        return GuardResult.completed(request_model, final_policy_result, response)

    def authorize_post(
        self,
        spec: PostSpec,
        *,
        provenance: Provenance,
        approval_ticket_id: str | None = None,
    ) -> GuardResult[None]:
        timeout_seconds = self._resolve_timeout(spec.timeout_seconds)
        max_bytes = self._resolve_max_bytes(spec.max_bytes)
        request_model = self._build_request(
            spec.url,
            capability=Capability.NETWORK_POST,
            provenance=provenance,
            headers=spec.headers,
            body=spec.body,
            timeout_seconds=timeout_seconds,
            max_bytes=max_bytes,
        )
        final_policy_result = evaluate_policy(
            self.policy_engine,
            request_model,
            approval_store=self.approval_store,
            approval_ticket_id=approval_ticket_id,
        )
        if final_policy_result.decision is not Decision.ALLOW:
            return GuardResult.rejected(request_model, final_policy_result)
        return GuardResult.completed(request_model, final_policy_result, None)

    def _build_request(
        self,
        url: str,
        *,
        capability: Capability,
        provenance: Provenance,
        headers: dict[str, str],
        body: bytes | None,
        timeout_seconds: int,
        max_bytes: int,
    ) -> ActionRequest:
        normalized_url, metadata = self._normalize_url(url)
        return ActionRequest(
            request_id=new_request_id('net'),
            capability=capability,
            resource=ResourceDescriptor(
                kind=ResourceKind.URL,
                locator=normalized_url,
                metadata={'method': 'POST' if capability is Capability.NETWORK_POST else 'GET'},
            ),
            provenance=provenance,
            parameters={
                'scheme': metadata['scheme'],
                'hostname': metadata['hostname'],
                'port': metadata['port'],
                'credentials_present': metadata['credentials_present'],
                'resolved_ips': metadata['resolved_ips'],
                'resolution_error': metadata['resolution_error'],
                'header_names': tuple(sorted(header.lower() for header in headers)),
                'headers_sha256': hash_mapping(headers),
                'body_sha256': None if body is None else hash_bytes(body),
                'body_bytes': 0 if body is None else len(body),
                'timeout_seconds': timeout_seconds,
                'max_bytes': max_bytes,
            },
        )

    def _normalize_url(self, raw_url: str) -> tuple[str, dict[str, object]]:
        try:
            parsed = parse.urlsplit(raw_url)
        except ValueError as exc:
            return raw_url, {
                'scheme': '',
                'hostname': '',
                'port': None,
                'credentials_present': False,
                'resolved_ips': (),
                'resolution_error': str(exc),
            }

        scheme = parsed.scheme.lower()
        hostname = parsed.hostname.lower() if parsed.hostname else ''
        credentials_present = parsed.username is not None or parsed.password is not None
        try:
            port = parsed.port
        except ValueError as exc:
            return raw_url, {
                'scheme': scheme,
                'hostname': hostname,
                'port': None,
                'credentials_present': credentials_present,
                'resolved_ips': (),
                'resolution_error': str(exc),
            }

        path = parsed.path or '/'
        if ':' in hostname and not hostname.startswith('['):
            host_for_netloc = f'[{hostname}]'
        else:
            host_for_netloc = hostname
        netloc = host_for_netloc
        if port is not None:
            netloc = f'{netloc}:{port}'
        normalized_url = parse.urlunsplit((scheme, netloc, path, parsed.query, ''))

        resolved_ips: tuple[str, ...] = ()
        resolution_error: str | None = None
        if hostname:
            try:
                resolved_ips = self.resolver(hostname, port)
            except OSError as exc:
                resolution_error = str(exc)

        return normalized_url, {
            'scheme': scheme,
            'hostname': hostname,
            'port': port,
            'credentials_present': credentials_present,
            'resolved_ips': resolved_ips,
            'resolution_error': resolution_error,
        }

    def _perform_request(
        self,
        method: str,
        target: _VerifiedNetworkTarget,
        headers: dict[str, str],
        body: bytes | None,
        timeout_seconds: int,
        max_bytes: int,
    ) -> NetworkResponse:
        if self.transport is not None:
            return self.transport(method, target.url, headers, body, timeout_seconds, max_bytes)
        return self._default_transport(method, target, headers, body, timeout_seconds, max_bytes)

    @staticmethod
    def _build_transport_target(request_model: ActionRequest) -> _VerifiedNetworkTarget:
        url = request_model.resource.locator
        hostname = str(request_model.parameters.get('hostname') or '')
        scheme = str(request_model.parameters.get('scheme') or '')
        port_value = request_model.parameters.get('port')
        port = port_value if isinstance(port_value, int) else None
        resolved_ips = tuple(request_model.parameters.get('resolved_ips') or ())
        parsed = parse.urlsplit(url)
        path = parsed.path or '/'
        path_and_query = f'{path}?{parsed.query}' if parsed.query else path
        host_for_header = LocalNetworkGuard._format_host_for_header(hostname)
        if port is not None and port != LocalNetworkGuard._default_port_for_scheme(scheme):
            host_header = f'{host_for_header}:{port}'
        else:
            host_header = host_for_header
        return _VerifiedNetworkTarget(
            url=url,
            scheme=scheme,
            hostname=hostname,
            port=port,
            path_and_query=path_and_query,
            host_header=host_header,
            resolved_ips=resolved_ips,
        )

    @staticmethod
    def _default_transport(
        method: str,
        target: _VerifiedNetworkTarget,
        headers: dict[str, str],
        body: bytes | None,
        timeout_seconds: int,
        max_bytes: int,
    ) -> NetworkResponse:
        last_error: str | None = None
        for connect_ip in target.resolved_ips:
            try:
                return LocalNetworkGuard._perform_pinned_request(
                    method,
                    target,
                    connect_ip,
                    headers,
                    body,
                    timeout_seconds,
                    max_bytes,
                )
            except (client.HTTPException, OSError, ssl.SSLError) as exc:
                last_error = str(exc)
        return NetworkResponse(
            status_code=0,
            body=b'',
            content_type=None,
            final_url=target.url,
            truncated=False,
            error=last_error or 'No verified destination IPs were available for the network request.',
        )

    @staticmethod
    def _perform_pinned_request(
        method: str,
        target: _VerifiedNetworkTarget,
        connect_ip: str,
        headers: dict[str, str],
        body: bytes | None,
        timeout_seconds: int,
        max_bytes: int,
    ) -> NetworkResponse:
        prepared_headers = {key: value for key, value in headers.items() if key.lower() != 'host'}
        prepared_headers['Host'] = target.host_header
        port = target.port or LocalNetworkGuard._default_port_for_scheme(target.scheme)
        if target.scheme == 'https':
            connection: client.HTTPConnection = _PinnedHTTPSConnection(
                connect_host=connect_ip,
                server_hostname=target.hostname,
                port=port,
                timeout=timeout_seconds,
            )
        else:
            connection = client.HTTPConnection(host=connect_ip, port=port, timeout=timeout_seconds)
        try:
            connection.request(
                method,
                target.path_and_query,
                body=body,
                headers=prepared_headers,
            )
            response = connection.getresponse()
            return LocalNetworkGuard._read_response(
                response,
                max_bytes,
                default_final_url=target.url,
            )
        finally:
            connection.close()

    @staticmethod
    def _read_response(
        response,
        max_bytes: int,
        *,
        default_final_url: str | None = None,
    ) -> NetworkResponse:
        raw_body = response.read(max_bytes + 1)
        truncated = len(raw_body) > max_bytes
        body = raw_body[:max_bytes]
        content_type = response.headers.get_content_type() if response.headers is not None else None
        final_url = default_final_url
        geturl = getattr(response, 'geturl', None)
        if callable(geturl):
            try:
                resolved_url = geturl()
            except AttributeError:
                resolved_url = getattr(response, 'url', None)
            if isinstance(resolved_url, str) and resolved_url:
                final_url = resolved_url
        return NetworkResponse(
            status_code=int(getattr(response, 'code', getattr(response, 'status', 0)) or 0),
            body=body,
            content_type=content_type,
            final_url=final_url,
            truncated=truncated,
            error=None,
        )

    def _resolve_timeout(self, requested_timeout: int | None) -> int:
        timeout = self.default_timeout_seconds if requested_timeout is None else requested_timeout
        if timeout <= 0:
            raise ValueError('Network timeout must be positive when provided.')
        return min(timeout, self.max_timeout_seconds)

    def _resolve_max_bytes(self, requested_max_bytes: int | None) -> int:
        max_bytes = self.default_max_bytes if requested_max_bytes is None else requested_max_bytes
        if max_bytes <= 0:
            raise ValueError('Network max_bytes must be positive when provided.')
        return min(max_bytes, self.max_response_bytes)

    @staticmethod
    def _default_port_for_scheme(scheme: str) -> int:
        return 443 if scheme == 'https' else 80

    @staticmethod
    def _format_host_for_header(hostname: str) -> str:
        if ':' in hostname and not hostname.startswith('['):
            return f'[{hostname}]'
        return hostname
