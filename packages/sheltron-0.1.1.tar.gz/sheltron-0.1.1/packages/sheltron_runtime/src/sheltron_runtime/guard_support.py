from __future__ import annotations

from collections.abc import Mapping
import hashlib
import json
from pathlib import Path
from uuid import uuid4

from sheltron_core.approvals import ApprovalStore
from sheltron_core.policy import PolicyContext, PolicyEngine
from sheltron_core.resources import PathPolicyContext
from sheltron_core.schemas import ActionRequest, PolicyResult
from sheltron_runtime.approval_runtime import resolve_approval_requirement


def new_request_id(prefix: str) -> str:
    return f'{prefix}-{uuid4().hex}'


def hash_text(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def hash_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def hash_mapping(value: Mapping[str, str]) -> str:
    serialized = json.dumps(dict(value), sort_keys=True, separators=(',', ':'))
    return hashlib.sha256(serialized.encode('utf-8')).hexdigest()


def build_policy_context(
    *,
    path_policy: PathPolicyContext | None = None,
    working_directory: Path | None = None,
) -> PolicyContext:
    return PolicyContext(
        path_policy=path_policy,
        working_directory=working_directory,
    )


def evaluate_policy(
    policy_engine: PolicyEngine,
    request: ActionRequest,
    *,
    path_policy: PathPolicyContext | None = None,
    working_directory: Path | None = None,
    approval_store: ApprovalStore | None = None,
    approval_ticket_id: str | None = None,
) -> PolicyResult:
    policy_result = policy_engine.evaluate(
        request,
        build_policy_context(
            path_policy=path_policy,
            working_directory=working_directory,
        ),
    )
    return resolve_approval_requirement(
        request,
        policy_result,
        approval_store=approval_store,
        approval_ticket_id=approval_ticket_id,
    )
