from __future__ import annotations

from sheltron_core.approvals import ApprovalStatus, ApprovalStore, fingerprint_action_request
from sheltron_core.schemas import ActionRequest, Decision, PolicyResult


def resolve_approval_requirement(
    request: ActionRequest,
    policy_result: PolicyResult,
    *,
    approval_store: ApprovalStore | None,
    approval_ticket_id: str | None,
) -> PolicyResult:
    if policy_result.decision is not Decision.REQUIRE_APPROVAL:
        return policy_result
    if approval_store is None:
        return policy_result

    request_fingerprint = fingerprint_action_request(request)
    if approval_ticket_id is None:
        ticket = approval_store.create(
            request,
            request_fingerprint=request_fingerprint,
        )
        return policy_result.model_copy(update={'approval_ticket_id': ticket.ticket_id})

    ticket = approval_store.get(approval_ticket_id)
    if ticket is None:
        return PolicyResult.require_approval(
            'approval_runtime',
            code='approval_ticket_not_found',
            message='The supplied approval ticket was not found.',
            details={'approval_ticket_id': approval_ticket_id},
            guard_assessments=policy_result.guard_assessments,
        )
    if ticket.request_fingerprint != request_fingerprint:
        return PolicyResult.require_approval(
            'approval_runtime',
            code='approval_ticket_mismatch',
            message='The supplied approval ticket does not match this normalized request.',
            details={'approval_ticket_id': approval_ticket_id},
            guard_assessments=policy_result.guard_assessments,
        )
    if ticket.status is not ApprovalStatus.APPROVED:
        return PolicyResult.require_approval(
            'approval_runtime',
            code='approval_ticket_not_approved',
            message='The supplied approval ticket has not been approved.',
            details={
                'approval_ticket_id': approval_ticket_id,
                'approval_status': ticket.status.value,
            },
            guard_assessments=policy_result.guard_assessments,
        )
    if ticket.consumed_at is not None:
        return PolicyResult.require_approval(
            'approval_runtime',
            code='approval_ticket_already_used',
            message='The supplied approval ticket has already been used.',
            details={'approval_ticket_id': approval_ticket_id},
            guard_assessments=policy_result.guard_assessments,
        )

    consumed_ticket = approval_store.consume(approval_ticket_id)
    return PolicyResult.allow(
        'approval_runtime',
        code='approval_granted',
        message='A matching approval ticket was granted for this request.',
        details={
            'approval_ticket_id': consumed_ticket.ticket_id,
            'reviewer_id': consumed_ticket.reviewer_id or '',
            'original_policy': policy_result.matched_policy,
        },
        guard_assessments=policy_result.guard_assessments,
    )
