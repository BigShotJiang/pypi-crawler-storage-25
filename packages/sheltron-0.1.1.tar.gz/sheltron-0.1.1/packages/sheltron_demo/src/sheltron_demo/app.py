from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from sheltron_core import (
    ApprovalStatus,
    ApprovalTicket,
    Capability,
    CapabilityAllowlistPolicy,
    JsonApprovalStore,
    PathAccessPolicy,
    PathPolicyContext,
    PolicyEngine,
    Provenance,
    TrustLevel,
)
from sheltron_runtime import FileWriteSpec, LocalFileSystemGuard

DEMO_REQUESTED_PATH = '../state/outside.txt'
DEMO_CONTENT = 'approved by demo'


class DemoStatus(str, Enum):
    WAITING_FOR_REVIEW = 'waiting_for_review'
    REJECTED = 'rejected'
    COMPLETED = 'completed'


class DemoSession(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra='forbid')

    demo_dir: Path
    workspace_dir: Path
    state_dir: Path
    approval_store: Path
    session_file: Path
    requested_path: str
    target_path: Path
    content: str
    status: DemoStatus
    ticket_id: str | None = None
    last_decision: str | None = None
    last_reason_code: str | None = None


@dataclass(slots=True)
class DemoRunResult:
    session: DemoSession
    action: str
    detail: str


def default_demo_dir() -> Path:
    return Path.cwd().resolve() / 'examples' / 'sheltron_demo'


def run_demo(raw_demo_dir: str | Path, *, fresh: bool = False) -> DemoRunResult:
    session = _prepare_demo(raw_demo_dir, fresh=fresh)
    ticket = _load_ticket(session)

    if session.status is DemoStatus.COMPLETED:
        return DemoRunResult(
            session=session,
            action='completed',
            detail='The demo request already completed.',
        )

    if ticket is not None:
        if ticket.status is ApprovalStatus.REJECTED:
            session = _save_with(
                session,
                status=DemoStatus.REJECTED,
                last_decision='require_approval',
                last_reason_code='approval_rejected',
            )
            return DemoRunResult(
                session=session,
                action='rejected',
                detail='The current demo request was rejected. Run again with --fresh to start over.',
            )
        if ticket.status is ApprovalStatus.APPROVED and ticket.consumed_at is None:
            return _resume_demo(session)
        if ticket.status is ApprovalStatus.APPROVED and ticket.consumed_at is not None:
            session = _save_with(
                session,
                status=DemoStatus.COMPLETED,
                last_decision='allow',
                last_reason_code='approval_granted',
            )
            return DemoRunResult(
                session=session,
                action='completed',
                detail='The demo request already completed.',
            )
        return DemoRunResult(
            session=session,
            action='waiting',
            detail='Paused for approval.',
        )

    return _start_demo(session)


def approve_demo(raw_demo_dir: str | Path, *, reviewer_id: str = 'owner') -> DemoRunResult:
    session, ticket = load_demo_ticket(raw_demo_dir)
    store = JsonApprovalStore(session.approval_store, audit_system='sheltron_demo')
    if ticket.status is ApprovalStatus.PENDING:
        store.approve(ticket.ticket_id, reviewer_id=reviewer_id, note='approved via demo CLI')
    return run_demo(raw_demo_dir)


def reject_demo(raw_demo_dir: str | Path, *, reviewer_id: str = 'owner') -> DemoSession:
    session, ticket = load_demo_ticket(raw_demo_dir)
    store = JsonApprovalStore(session.approval_store, audit_system='sheltron_demo')
    if ticket.status is ApprovalStatus.PENDING:
        store.reject(ticket.ticket_id, reviewer_id=reviewer_id, note='rejected via demo CLI')
    return _save_with(
        session,
        status=DemoStatus.REJECTED,
        last_decision='require_approval',
        last_reason_code='approval_rejected',
    )


def load_demo_session(raw_demo_dir: str | Path) -> DemoSession:
    demo_dir = _resolve_demo_dir(raw_demo_dir)
    session_file = demo_dir / 'state' / 'session.json'
    if not session_file.exists():
        raise FileNotFoundError(f'Demo session not found: {session_file}')
    return DemoSession.model_validate_json(session_file.read_text(encoding='utf-8'))


def load_demo_ticket(raw_demo_dir: str | Path) -> tuple[DemoSession, ApprovalTicket]:
    session = load_demo_session(raw_demo_dir)
    if session.ticket_id is None:
        raise ValueError('The current demo session does not have an approval ticket.')
    ticket = _load_ticket(session)
    if ticket is None:
        raise ValueError(f'The demo approval ticket was not found: {session.ticket_id}')
    return session, ticket


def _prepare_demo(raw_demo_dir: str | Path, *, fresh: bool) -> DemoSession:
    demo_dir = _resolve_demo_dir(raw_demo_dir)
    workspace_dir = demo_dir / 'workspace'
    state_dir = demo_dir / 'state'
    session_file = state_dir / 'session.json'
    approval_store = state_dir / 'approvals.json'
    target_path = state_dir / 'outside.txt'

    _ensure_layout(demo_dir, workspace_dir, state_dir, fresh=fresh)

    if session_file.exists():
        return DemoSession.model_validate_json(session_file.read_text(encoding='utf-8'))

    session = DemoSession(
        demo_dir=demo_dir,
        workspace_dir=workspace_dir,
        state_dir=state_dir,
        approval_store=approval_store,
        session_file=session_file,
        requested_path=DEMO_REQUESTED_PATH,
        target_path=target_path,
        content=DEMO_CONTENT,
        status=DemoStatus.WAITING_FOR_REVIEW,
    )
    return _save_with(session)


def _ensure_layout(demo_dir: Path, workspace_dir: Path, state_dir: Path, *, fresh: bool) -> None:
    skills_dir = workspace_dir / 'skills'
    demo_dir.mkdir(parents=True, exist_ok=True)
    workspace_dir.mkdir(parents=True, exist_ok=True)
    skills_dir.mkdir(parents=True, exist_ok=True)
    state_dir.mkdir(parents=True, exist_ok=True)

    prompt_files = {
        workspace_dir / 'AGENTS.md': '# Demo AGENTS\n\nThis is a tiny Sheltron demo workspace.\n',
        workspace_dir / 'SOUL.md': '# Demo SOUL\n\nThe demo uses one fixed filesystem request.\n',
        workspace_dir / 'TOOLS.md': '# Demo TOOLS\n\nThe demo only exercises Sheltron approval flow.\n',
        skills_dir / 'README.md': '# Demo Skills\n\nThis folder is present to mirror host app layout.\n',
    }
    for path, content in prompt_files.items():
        if fresh or not path.exists():
            path.write_text(content, encoding='utf-8')

    if fresh:
        for path in (
            state_dir / 'approvals.json',
            state_dir / 'session.json',
            state_dir / 'outside.txt',
        ):
            if path.exists():
                path.unlink()


def _start_demo(session: DemoSession) -> DemoRunResult:
    result = _execute_demo_request(session)
    if result.executed:
        updated = _save_with(
            session,
            status=DemoStatus.COMPLETED,
            last_decision=result.policy_result.decision.value,
            last_reason_code=result.policy_result.reasons[0].code,
        )
        return DemoRunResult(
            session=updated,
            action='completed',
            detail='The demo request completed immediately.',
        )

    updated = _save_with(
        session,
        status=DemoStatus.WAITING_FOR_REVIEW,
        ticket_id=result.policy_result.approval_ticket_id,
        last_decision=result.policy_result.decision.value,
        last_reason_code=result.policy_result.reasons[0].code,
    )
    return DemoRunResult(
        session=updated,
        action='paused',
        detail='Paused for approval.',
    )


def _resume_demo(session: DemoSession) -> DemoRunResult:
    result = _execute_demo_request(session, approval_ticket_id=session.ticket_id)
    if result.executed:
        updated = _save_with(
            session,
            status=DemoStatus.COMPLETED,
            last_decision=result.policy_result.decision.value,
            last_reason_code=result.policy_result.reasons[0].code,
        )
        return DemoRunResult(
            session=updated,
            action='resumed',
            detail='Approved and resumed the paused request.',
        )

    updated = _save_with(
        session,
        status=DemoStatus.WAITING_FOR_REVIEW,
        ticket_id=result.policy_result.approval_ticket_id or session.ticket_id,
        last_decision=result.policy_result.decision.value,
        last_reason_code=result.policy_result.reasons[0].code,
    )
    return DemoRunResult(
        session=updated,
        action='waiting',
        detail='The current demo request is still blocked.',
    )


def _execute_demo_request(
    session: DemoSession,
    *,
    approval_ticket_id: str | None = None,
):
    guard = LocalFileSystemGuard(
        policy_engine=PolicyEngine(
            [CapabilityAllowlistPolicy({Capability.WRITE_FILE}), PathAccessPolicy()]
        ),
        path_policy=PathPolicyContext(workspace_roots=(session.workspace_dir,)),
        working_directory=session.workspace_dir,
        approval_store=JsonApprovalStore(session.approval_store, audit_system='sheltron_demo'),
    )
    return guard.write_text(
        FileWriteSpec(
            path=Path(session.requested_path),
            content=session.content,
            create_parents=True,
        ),
        provenance=_demo_provenance(),
        approval_ticket_id=approval_ticket_id,
    )


def _demo_provenance() -> Provenance:
    return Provenance(
        session_id='sheltron-demo',
        channel='demo',
        actor_id='owner',
        source_trust_levels=(TrustLevel.OWNER,),
        trigger='sheltron_demo fixed filesystem write',
    )


def _load_ticket(session: DemoSession) -> ApprovalTicket | None:
    if session.ticket_id is None:
        return None
    return JsonApprovalStore(session.approval_store, audit_system='sheltron_demo').get(session.ticket_id)


def _save_with(session: DemoSession, **updates: object) -> DemoSession:
    updated = session.model_copy(update=updates)
    updated.session_file.write_text(
        updated.model_dump_json(indent=2),
        encoding='utf-8',
    )
    return updated


def _resolve_demo_dir(raw_demo_dir: str | Path) -> Path:
    return Path(raw_demo_dir).expanduser().resolve(strict=False)
