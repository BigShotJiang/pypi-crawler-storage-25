from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class DemoScenarioStatus(str, Enum):
    ACTIVE = 'active'
    PLANNED = 'planned'


@dataclass(frozen=True, slots=True)
class DemoScenario:
    scenario_id: str
    status: DemoScenarioStatus
    summary: str


DEMO_SCENARIOS: tuple[DemoScenario, ...] = (
    DemoScenario(
        scenario_id='filesystem_approval',
        status=DemoScenarioStatus.ACTIVE,
        summary='Current scenario: approval-required filesystem write outside the demo workspace.',
    ),
    DemoScenario(
        scenario_id='exec_approval',
        status=DemoScenarioStatus.PLANNED,
        summary='Planned scenario for safe exec guard behavior and approval flow.',
    ),
    DemoScenario(
        scenario_id='network_approval',
        status=DemoScenarioStatus.PLANNED,
        summary='Planned scenario for network fetch/post policy and egress approval flow.',
    ),
    DemoScenario(
        scenario_id='message_approval',
        status=DemoScenarioStatus.PLANNED,
        summary='Planned scenario for outbound messaging policy and redaction flow.',
    ),
    DemoScenario(
        scenario_id='memory_approval',
        status=DemoScenarioStatus.PLANNED,
        summary='Planned scenario for candidate memory review and commit flow.',
    ),
)


def planned_demo_scenarios() -> tuple[DemoScenario, ...]:
    return tuple(
        scenario
        for scenario in DEMO_SCENARIOS
        if scenario.status is DemoScenarioStatus.PLANNED
    )
