from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path

from sheltron_attacklab import AttackCaseStatus, AttackCategory, AttackHost
from sheltron_demo import default_demo_dir
from sheltron_core import (
    ApprovalStatus,
    CandidateMemoryStatus,
    JsonApprovalStore,
    JsonlAuditLogger,
    JsonlCandidateMemoryStore,
    default_audit_log_path,
    default_approval_store_path,
    default_candidate_memory_store_path,
    load_json_approval_store,
)


def add_store_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        '--store',
        default=str(default_approval_store_path()),
        help='path to the approval store JSON file',
    )


def add_approval_audit_log_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        '--audit-log',
        help='path to the audit JSONL log file used for approval transition events',
    )


def load_store_with_audit(raw_path: str, audit_log: str | None) -> JsonApprovalStore:
    return load_json_approval_store(
        Path(raw_path),
        audit_log_path=Path(audit_log) if audit_log else None,
    )


def add_memory_store_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        '--store',
        default=str(default_candidate_memory_store_path()),
        help='path to the candidate memory JSONL file',
    )


def load_memory_store(raw_path: str) -> JsonlCandidateMemoryStore:
    return JsonlCandidateMemoryStore(Path(raw_path))


def add_audit_log_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        '--log',
        default=str(default_audit_log_path()),
        help='path to the audit JSONL log file',
    )


def load_audit_logger(raw_path: str) -> JsonlAuditLogger:
    return JsonlAuditLogger(Path(raw_path))


def add_demo_dir_argument(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        '--demo-dir',
        default=str(default_demo_dir()),
        help='path to the example sheltron_demo directory',
    )


def print_ticket(ticket: object) -> None:
    print(json.dumps(ticket.model_dump(mode='json'), indent=2, sort_keys=True))


def parse_status(raw_status: str | None) -> ApprovalStatus | None:
    if raw_status is None:
        return None
    return ApprovalStatus(raw_status)


def parse_memory_status(raw_status: str | None) -> CandidateMemoryStatus | None:
    if raw_status is None:
        return None
    return CandidateMemoryStatus(raw_status)


def parse_since(raw_since: str | None) -> datetime | None:
    if raw_since is None:
        return None
    value = raw_since.strip()
    if value == '':
        return None
    if value.endswith('Z'):
        return datetime.fromisoformat(value[:-1] + '+00:00')
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        parsed = None
    if parsed is not None:
        if parsed.tzinfo is None:
            return parsed.replace(tzinfo=timezone.utc)
        return parsed

    unit = value[-1].lower()
    amount = float(value[:-1])
    if unit == 's':
        delta = timedelta(seconds=amount)
    elif unit == 'm':
        delta = timedelta(minutes=amount)
    elif unit == 'h':
        delta = timedelta(hours=amount)
    elif unit == 'd':
        delta = timedelta(days=amount)
    else:
        raise ValueError(f'Unsupported --since value: {raw_since}')
    return datetime.now(timezone.utc) - delta


def resolve_attack_harness(
    *,
    case: object,
    requested_host: AttackHost | None,
):
    candidate_hosts = (
        (requested_host,)
        if requested_host is not None
        else tuple(sorted(case.hosts, key=lambda item: item.value))
    )
    for host in candidate_hosts:
        if host not in case.hosts:
            continue
        if host is AttackHost.NANOBOT:
            from sheltron_adapters.nanobot import NanobotAttackHarness
            if NanobotAttackHarness is None:
                continue
            return NanobotAttackHarness()
        if host is AttackHost.OPENCLAW:
            from sheltron_adapters.openclaw import OpenClawAttackHarness
            if OpenClawAttackHarness is None:
                continue
            return OpenClawAttackHarness()
    return None


__all__ = [
    'AttackCaseStatus',
    'AttackCategory',
    'AttackHost',
    'add_approval_audit_log_argument',
    'add_audit_log_argument',
    'add_demo_dir_argument',
    'add_memory_store_argument',
    'add_store_argument',
    'load_audit_logger',
    'load_memory_store',
    'load_store_with_audit',
    'parse_memory_status',
    'parse_since',
    'parse_status',
    'print_ticket',
    'resolve_attack_harness',
]
