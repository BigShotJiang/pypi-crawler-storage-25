from __future__ import annotations

from contextlib import redirect_stdout
from io import StringIO
import json
import sys

from sheltron_attacklab import AttackCaseStatus, AttackCategory, AttackHost, get_attack_case, select_attack_cases
from sheltron_demo import approve_demo, load_demo_session, load_demo_ticket, reject_demo, run_demo
from sheltron_core import ApprovalStatus, CandidateMemoryStatus, DefenseMode
from sheltron_runtime import run_runtime_suite

from sheltron_adapters.registry import get_builtin_host_adapter, get_builtin_host_adapters, probe_builtin_host_adapters
from sheltron.cli_parser import build_parser
from sheltron.cli_support import (
    load_audit_logger,
    load_memory_store,
    load_store_with_audit,
    parse_memory_status,
    parse_since,
    parse_status,
    print_ticket,
    resolve_attack_harness,
)

_AGENT_LIFECYCLE_COMMANDS = {
    'link': 'install',
    'unlink': 'uninstall',
    'targets': 'targets',
    'on': 'on',
    'off': 'off',
    'status': 'status',
    'doctor': 'doctor',
}


def _serialize_adapter_probe(probe: object) -> dict[str, object]:
    return {
        'name': probe.name,
        'summary': probe.summary,
        'bundled': probe.bundled,
        'status': probe.status,
        'importable': probe.importable,
        'available': probe.available,
        'detected_targets': probe.detected_targets,
        'detail': probe.detail,
    }


def _host_passthrough_target(argv: list[str]) -> tuple[object, list[str], bool] | None:
    if not argv:
        return None
    adapter = get_builtin_host_adapter(argv[0])
    if adapter is None:
        return None
    host_argv = argv[1:]
    if host_argv[:1] == ['--']:
        return adapter, host_argv[1:], True
    if not host_argv or host_argv[0] not in adapter.known_commands:
        return adapter, host_argv, False
    return None


def _available_agent_names() -> str:
    names = [adapter.name for adapter in get_builtin_host_adapters()]
    return ', '.join(names) if names else '(none)'


def _print_agent_lifecycle_usage(command: str) -> None:
    print(f'usage: sheltron {command} <agent>')
    print(f'Available agents: {_available_agent_names()}')


def _dispatch_agent_lifecycle(args: object) -> int:
    command = args.command
    if command == 'unlink' and args.all:
        if args.agent:
            print('usage: sheltron unlink --all [--json]')
            print('Do not provide an agent name when using --all.')
            return 2
        return _unlink_all_agents(json_output=args.json)

    if command == 'unlink' and args.json:
        print('`--json` is only supported with `sheltron unlink --all`.')
        return 2

    agent = args.agent
    if not agent:
        _print_agent_lifecycle_usage(command)
        return 2

    adapter = get_builtin_host_adapter(agent)
    if adapter is None:
        print(f'Unknown Sheltron agent: {agent}')
        print(f'Available agents: {_available_agent_names()}')
        return 2

    mapped_command = _AGENT_LIFECYCLE_COMMANDS[command]
    return adapter.dispatch_lifecycle(
        mapped_command,
        args.agent_args,
        prog=f'sheltron {command} {agent}',
    )


def _unlink_all_agents(*, json_output: bool = False) -> int:
    results: list[dict[str, object]] = []
    for adapter in get_builtin_host_adapters():
        if not json_output:
            print(f'[{adapter.name}]')
        try:
            if json_output:
                with redirect_stdout(StringIO()):
                    exit_code = adapter.uninstall_default()
            else:
                exit_code = adapter.uninstall_default()
        except Exception as exc:
            exit_code = 1
            if not json_output:
                print(f'Failed to unlink Sheltron {adapter.name}: {exc}')
            detail = str(exc)
        else:
            detail = 'ok' if exit_code == 0 else f'exited with code {exit_code}'
        results.append(
            {
                'agent': adapter.name,
                'ok': exit_code == 0,
                'exit_code': exit_code,
                'detail': detail,
            }
        )

    failed = [result for result in results if not result['ok']]
    if json_output:
        print(json.dumps(results, indent=2, sort_keys=True))
    elif not failed:
        print('Unlinked all detected Sheltron agent integrations.')
        print('You can now uninstall Sheltron itself with your package manager, for example: `uv tool uninstall sheltron`.')
    else:
        print('One or more Sheltron agent integrations could not be unlinked. Fix the failures above before uninstalling Sheltron itself.')
    return 1 if failed else 0


def main(argv: list[str] | None = None) -> int:
    parse_argv = list(sys.argv[1:] if argv is None else argv)
    passthrough = _host_passthrough_target(parse_argv)
    if passthrough is not None:
        adapter, host_argv, forced = passthrough
        return adapter.dispatch_passthrough(host_argv, forced=forced)

    parser = build_parser()
    args, unknown = parser.parse_known_args(parse_argv)
    if args.version:
        print('sheltron 0.1.1')
        return 0

    if args.command in _AGENT_LIFECYCLE_COMMANDS:
        return _dispatch_agent_lifecycle(args)

    selected_adapter = get_builtin_host_adapter(args.command or '')
    if unknown and (selected_adapter is None or selected_adapter.probe().importable):
        parser.error(f'unrecognized arguments: {" ".join(unknown)}')
        return 2

    if args.command == 'approvals':
        store = load_store_with_audit(args.store, getattr(args, 'audit_log', None))
        if args.approvals_command == 'list':
            tickets = store.list(status=parse_status(args.status))
            if not tickets:
                print('No approval tickets found.')
                return 0
            for ticket in tickets:
                resource = ticket.request.resource.locator
                capability = ticket.request.capability.value
                print(f'{ticket.ticket_id} {ticket.status.value} {capability} {resource}')
            return 0

        if args.approvals_command == 'show':
            ticket = store.get(args.ticket_id)
            if ticket is None:
                print(f'Approval ticket not found: {args.ticket_id}')
                return 1
            print_ticket(ticket)
            return 0

        if args.approvals_command == 'review':
            ticket = store.get(args.ticket_id)
            if ticket is None:
                print(f'Approval ticket not found: {args.ticket_id}')
                return 1
            print_ticket(ticket)
            if ticket.status is not ApprovalStatus.PENDING:
                print(f'Approval ticket is already {ticket.status.value}.')
                return 1
            response = input('Approve this request? [y/N]: ').strip().lower()
            if response in {'y', 'yes'}:
                resolved = store.approve(args.ticket_id, reviewer_id=args.reviewer_id, note='approved via CLI')
            else:
                resolved = store.reject(args.ticket_id, reviewer_id=args.reviewer_id, note='rejected via CLI')
            print(f'{resolved.ticket_id} -> {resolved.status.value}')
            return 0

        if args.approvals_command == 'approve':
            resolved = store.approve(args.ticket_id, reviewer_id=args.reviewer_id, note=args.note)
            print(f'{resolved.ticket_id} -> {resolved.status.value}')
            return 0

        if args.approvals_command == 'reject':
            resolved = store.reject(args.ticket_id, reviewer_id=args.reviewer_id, note=args.note)
            print(f'{resolved.ticket_id} -> {resolved.status.value}')
            return 0

        parser.error('an approvals subcommand is required')
        return 2

    if args.command == 'audit':
        logger = load_audit_logger(args.log)
        try:
            since = parse_since(getattr(args, 'since', None))
        except ValueError as exc:
            print(str(exc))
            return 1
        if args.audit_command == 'tail':
            records = logger.tail(limit=args.limit, since=since)
            if not records:
                print('No audit records found.')
                return 0
            for record in records:
                summary = f' | {record.result_summary}' if record.result_summary else ''
                approval = f' approval={record.approval_id}' if record.approval_id else ''
                print(
                    f'{record.occurred_at.isoformat()} {record.system} {record.decision} '
                    f'{record.capability} {record.resource} {record.reason_code}{approval}{summary}'
                )
            return 0

        if args.audit_command == 'explain':
            record = logger.get(args.event_id)
            if record is None:
                print(f'Audit event not found: {args.event_id}')
                return 1
            print_ticket(record)
            return 0

        if args.audit_command == 'export':
            records = logger.read(since=since)
            if not records:
                print('No audit records found.')
                return 0
            for record in records:
                print(logger.serialize(record))
            return 0

        parser.error('an audit subcommand is required')
        return 2

    if args.command == 'attacklab':
        if args.attacklab_command == 'list':
            cases = select_attack_cases(
                host=None if args.host is None else AttackHost(args.host),
                category=None if args.category is None else AttackCategory(args.category),
                status=None if args.status is None else AttackCaseStatus(args.status),
            )
            if not cases:
                print('No attacklab cases found.')
                return 0
            for case in cases:
                hosts = ','.join(host.value for host in sorted(case.hosts, key=lambda item: item.value))
                print(f'{case.case_id} {case.status.value} {case.category.value} {hosts} {case.title}')
            return 0

        if args.attacklab_command == 'show':
            case = get_attack_case(args.case_id)
            if case is None:
                print(f'Attacklab case not found: {args.case_id}')
                return 1
            print(json.dumps(case.to_dict(), indent=2, sort_keys=True))
            return 0

        if args.attacklab_command == 'run':
            case = get_attack_case(args.case_id)
            if case is None:
                print(f'Attacklab case not found: {args.case_id}')
                return 1
            if case.status is not AttackCaseStatus.READY:
                print(f'Attacklab case is not runnable yet: {case.case_id} ({case.status.value}).')
                return 1
            harness = resolve_attack_harness(
                case=case,
                requested_host=None if args.host is None else AttackHost(args.host),
            )
            if harness is None:
                print(f'No installed host harness can run attacklab case: {case.case_id}')
                return 1
            probe = harness.probe()
            missing_features = sorted(
                feature.value
                for feature in case.required_features
                if feature not in probe.supported_features
            )
            if missing_features:
                print(
                    f'Host harness `{probe.host.value}` does not support required features: '
                    + ', '.join(missing_features)
                )
                return 1
            defense_mode = DefenseMode(args.defender)
            if defense_mode not in probe.supported_defense_modes:
                print(
                    f'Host harness `{probe.host.value}` does not support defense mode: {defense_mode.value}'
                )
                return 1
            result = harness.run_case(case, defense_mode=defense_mode)
            if args.json:
                print(json.dumps(result.to_dict(), indent=2, sort_keys=True))
            else:
                status = 'PASS' if result.passed else 'FAIL'
                print(f'{status} {result.case.case_id} on {result.host.value} ({result.defense_mode.value})')
                if result.notes:
                    print(result.notes)
                if result.violated_invariants:
                    print('Violated invariants:')
                    for invariant in result.violated_invariants:
                        print(f'- {invariant}')
                if result.transcript:
                    print('Transcript:')
                    for event in result.transcript:
                        metadata = f' {json.dumps(event.metadata, sort_keys=True)}' if event.metadata else ''
                        print(f'- {event.source}:{metadata} {event.content}')
            return 0 if result.passed else 1

        parser.error('an attacklab subcommand is required')
        return 2

    if args.command == 'runtime-suite':
        if args.runtime_suite_command == 'run':
            report = run_runtime_suite(profile=args.profile)
            if args.json:
                print(json.dumps(report.to_dict(), indent=2, sort_keys=True))
            else:
                for result in report.results:
                    status = 'PASS' if result.passed else 'FAIL'
                    detail = f' | {result.detail}' if result.detail else ''
                    print(
                        f'{status} {result.case_id} {result.actual_decision} '
                        f'{result.actual_reason_code} executed={str(result.actual_executed).lower()}{detail}'
                    )
                print(
                    f'Summary: {report.passed_cases}/{report.total_cases} cases passed '
                    f'for profile `{report.profile}`.'
                )
            return 0 if report.succeeded else 1

        parser.error('a runtime-suite subcommand is required')
        return 2

    if args.command == 'memory':
        store = load_memory_store(args.store)
        if args.memory_command == 'list':
            entries = store.list(status=parse_memory_status(args.status))
            if not entries:
                print('No candidate memory entries found.')
                return 0
            for entry in entries:
                print(
                    f'{entry.candidate_id} {entry.status.value} {entry.request.resource.locator} '
                    f'{entry.mode} {entry.target_path or "-"}'
                )
            return 0

        if args.memory_command == 'show':
            entry = store.get(args.candidate_id)
            if entry is None:
                print(f'Candidate memory entry not found: {args.candidate_id}')
                return 1
            print_ticket(entry)
            return 0

        if args.memory_command == 'review':
            entry = store.get(args.candidate_id)
            if entry is None:
                print(f'Candidate memory entry not found: {args.candidate_id}')
                return 1
            print_ticket(entry)
            if entry.status is not CandidateMemoryStatus.PENDING:
                print(f'Candidate memory entry is already {entry.status.value}.')
                return 1
            response = input('Commit this candidate memory? [y/N]: ').strip().lower()
            if response in {'y', 'yes'}:
                resolved = store.commit(args.candidate_id, reviewer_id=args.reviewer_id, note='committed via CLI')
            else:
                resolved = store.reject(args.candidate_id, reviewer_id=args.reviewer_id, note='rejected via CLI')
            print(f'{resolved.candidate_id} -> {resolved.status.value}')
            return 0

        if args.memory_command == 'commit':
            if store.get(args.candidate_id) is None:
                print(f'Candidate memory entry not found: {args.candidate_id}')
                return 1
            resolved = store.commit(args.candidate_id, reviewer_id=args.reviewer_id, note=args.note)
            print(f'{resolved.candidate_id} -> {resolved.status.value}')
            return 0

        if args.memory_command == 'reject':
            if store.get(args.candidate_id) is None:
                print(f'Candidate memory entry not found: {args.candidate_id}')
                return 1
            resolved = store.reject(args.candidate_id, reviewer_id=args.reviewer_id, note=args.note)
            print(f'{resolved.candidate_id} -> {resolved.status.value}')
            return 0

        parser.error('a memory subcommand is required')
        return 2

    if args.command == 'demo':
        if args.demo_command == 'run':
            result = run_demo(args.demo_dir, fresh=args.fresh)
            print(f'Demo directory: {result.session.demo_dir}')
            print(f'Workspace: {result.session.workspace_dir}')
            print(result.detail)
            if result.action in {'paused', 'waiting'}:
                try:
                    _, ticket = load_demo_ticket(args.demo_dir)
                except (FileNotFoundError, ValueError) as exc:
                    print(str(exc))
                    return 1
                print_ticket(ticket)
                response = input('Approve the current demo request? [y/N]: ').strip().lower()
                if response in {'y', 'yes'}:
                    resumed = approve_demo(args.demo_dir, reviewer_id=args.reviewer_id)
                    print(resumed.detail)
                    print(f'Final status: {resumed.session.status.value}')
                    print(f'Outside file: {resumed.session.target_path}')
                    return 0
                rejected = reject_demo(args.demo_dir, reviewer_id=args.reviewer_id)
                print('Rejected the current demo request. The outside file was not created.')
                print(f'Final status: {rejected.status.value}')
                return 0
            print(f'Final status: {result.session.status.value}')
            if result.session.status.value == 'completed':
                print(f'Outside file: {result.session.target_path}')
            return 0

        if args.demo_command == 'show':
            try:
                session = load_demo_session(args.demo_dir)
            except FileNotFoundError as exc:
                print(str(exc))
                return 1
            print(session.model_dump_json(indent=2))
            return 0

        if args.demo_command is None:
            parser.error('a demo subcommand is required')
            return 2
        parser.error('an unknown demo subcommand was provided')
        return 2

    if args.command == 'mcp':
        if args.mcp_command == 'serve':
            from sheltron_mcp import serve_stdio

            serve_stdio(
                workspace=args.workspace,
                approval_store_path=args.approval_store,
                audit_log_path=args.audit_log,
                system_name=args.system,
                downstream_broker_spec=args.downstream_broker,
            )
            return 0
        parser.error('an mcp subcommand is required')
        return 2

    if args.command == 'adapters':
        if args.adapters_command == 'list':
            probes = probe_builtin_host_adapters()
            if args.json:
                print(json.dumps([_serialize_adapter_probe(probe) for probe in probes], indent=2, sort_keys=True))
                return 0
            for probe in probes:
                bundled_label = 'bundled' if probe.bundled else 'external'
                print(
                    f'{probe.name} {probe.status} {bundled_label} '
                    f'importable={"yes" if probe.importable else "no"} '
                    f'targets={probe.detected_targets} {probe.summary}'
                )
                if probe.detail:
                    print(f'  {probe.detail}')
            return 0
        parser.error('an adapters subcommand is required')
        return 2

    adapter = selected_adapter
    if adapter is not None:
        return adapter.dispatch(args, parser)

    host_labels = ', '.join(f'`sheltron {adapter.name}`' for adapter in get_builtin_host_adapters())
    print(
        'Sheltron is installed. Use `sheltron demo`, `sheltron approvals`, '
        f'`sheltron audit`, `sheltron mcp`, `sheltron adapters`, or one of the host commands: {host_labels}.'
    )
    return 0
