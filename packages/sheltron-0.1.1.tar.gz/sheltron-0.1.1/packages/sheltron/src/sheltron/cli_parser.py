from __future__ import annotations

import argparse

from sheltron_core import ApprovalStatus, CandidateMemoryStatus, DefenseMode
from sheltron_runtime import SUPPORTED_RUNTIME_SUITE_PROFILES

from sheltron_adapters.registry import get_builtin_host_adapters
from sheltron.cli_support import (
    AttackCaseStatus,
    AttackCategory,
    AttackHost,
    add_approval_audit_log_argument,
    add_audit_log_argument,
    add_demo_dir_argument,
    add_memory_store_argument,
    add_store_argument,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog='sheltron', description='Sheltron bootstrap CLI')
    parser.add_argument('--version', action='store_true', help='print the installed Sheltron version')
    subparsers = parser.add_subparsers(dest='command')

    link = subparsers.add_parser(
        'link',
        usage='sheltron link <agent> [options]',
        help='link Sheltron to one installed agent',
    )
    link.add_argument('agent', nargs='?', metavar='<agent>', help='agent adapter name, such as nanobot or openclaw')
    link.add_argument('agent_args', nargs=argparse.REMAINDER, metavar='options', help=argparse.SUPPRESS)

    unlink = subparsers.add_parser(
        'unlink',
        usage='sheltron unlink <agent> [options]\n       sheltron unlink --all [--json]',
        help='unlink Sheltron from one agent, or all linked agents with --all',
    )
    unlink.add_argument('--all', action='store_true', help='unlink every bundled Sheltron agent integration')
    unlink.add_argument('--json', action='store_true', help='print per-agent unlink results as JSON when used with --all')
    unlink.add_argument('agent', nargs='?', metavar='<agent>', help='agent adapter name, such as nanobot or openclaw')
    unlink.add_argument('agent_args', nargs=argparse.REMAINDER, metavar='options', help=argparse.SUPPRESS)

    for lifecycle_name, lifecycle_help in (
        ('targets', 'list discovered command targets for one agent'),
        ('on', 'turn on global Sheltron enforcement for one linked agent'),
        ('off', 'turn off global Sheltron enforcement for one linked agent'),
        ('status', 'print concise Sheltron protection status for one agent'),
        ('doctor', 'print detailed Sheltron diagnostics for one agent'),
    ):
        lifecycle = subparsers.add_parser(
            lifecycle_name,
            usage=f'sheltron {lifecycle_name} <agent> [options]',
            help=lifecycle_help,
        )
        lifecycle.add_argument(
            'agent',
            nargs='?',
            metavar='<agent>',
            help='agent adapter name, such as nanobot or openclaw',
        )
        lifecycle.add_argument('agent_args', nargs=argparse.REMAINDER, metavar='options', help=argparse.SUPPRESS)

    approvals = subparsers.add_parser('approvals', help='review and resolve approval tickets')
    approvals_subparsers = approvals.add_subparsers(dest='approvals_command')

    list_parser = approvals_subparsers.add_parser('list', help='list approval tickets')
    add_store_argument(list_parser)
    add_approval_audit_log_argument(list_parser)
    list_parser.add_argument(
        '--status',
        choices=[status.value for status in ApprovalStatus],
        help='filter by ticket status',
    )

    show_parser = approvals_subparsers.add_parser('show', help='show one approval ticket')
    add_store_argument(show_parser)
    add_approval_audit_log_argument(show_parser)
    show_parser.add_argument('ticket_id')

    review_parser = approvals_subparsers.add_parser('review', help='review one approval ticket')
    add_store_argument(review_parser)
    add_approval_audit_log_argument(review_parser)
    review_parser.add_argument('ticket_id')
    review_parser.add_argument('--reviewer-id', default='owner')

    approve_parser = approvals_subparsers.add_parser('approve', help='approve one ticket')
    add_store_argument(approve_parser)
    add_approval_audit_log_argument(approve_parser)
    approve_parser.add_argument('ticket_id')
    approve_parser.add_argument('--reviewer-id', default='owner')
    approve_parser.add_argument('--note')

    reject_parser = approvals_subparsers.add_parser('reject', help='reject one ticket')
    add_store_argument(reject_parser)
    add_approval_audit_log_argument(reject_parser)
    reject_parser.add_argument('ticket_id')
    reject_parser.add_argument('--reviewer-id', default='owner')
    reject_parser.add_argument('--note')

    audit = subparsers.add_parser('audit', help='inspect audit events')
    audit_subparsers = audit.add_subparsers(dest='audit_command')

    audit_tail_parser = audit_subparsers.add_parser('tail', help='show recent audit events')
    add_audit_log_argument(audit_tail_parser)
    audit_tail_parser.add_argument('--limit', type=int, default=20, help='maximum number of events to print')
    audit_tail_parser.add_argument('--since', help='only include events since an ISO timestamp or relative duration like 24h')

    audit_explain_parser = audit_subparsers.add_parser('explain', help='show one audit event as JSON')
    add_audit_log_argument(audit_explain_parser)
    audit_explain_parser.add_argument('event_id')

    audit_export_parser = audit_subparsers.add_parser('export', help='export audit events as JSONL')
    add_audit_log_argument(audit_export_parser)
    audit_export_parser.add_argument('--since', help='only include events since an ISO timestamp or relative duration like 24h')

    attacklab = subparsers.add_parser(
        'attacklab',
        help='inspect and run host-backed adversarial scenarios',
    )
    attacklab_subparsers = attacklab.add_subparsers(dest='attacklab_command')

    attacklab_list_parser = attacklab_subparsers.add_parser(
        'list',
        help='list attacklab cases',
    )
    attacklab_list_parser.add_argument(
        '--host',
        choices=[host.value for host in AttackHost],
        help='filter cases by host target',
    )
    attacklab_list_parser.add_argument(
        '--category',
        choices=[category.value for category in AttackCategory],
        help='filter cases by category',
    )
    attacklab_list_parser.add_argument(
        '--status',
        choices=[status.value for status in AttackCaseStatus],
        help='filter cases by case status',
    )

    attacklab_show_parser = attacklab_subparsers.add_parser(
        'show',
        help='show one attacklab case as JSON',
    )
    attacklab_show_parser.add_argument('case_id')

    attacklab_run_parser = attacklab_subparsers.add_parser(
        'run',
        help='run one ready host-backed adversarial attacklab case',
    )
    attacklab_run_parser.add_argument('case_id')
    attacklab_run_parser.add_argument(
        '--host',
        choices=[host.value for host in AttackHost],
        help='force one host harness when the case supports multiple hosts',
    )
    attacklab_run_parser.add_argument(
        '--json',
        action='store_true',
        help='print the full attacklab run result as JSON',
    )
    attacklab_run_parser.add_argument(
        '--defender',
        default=DefenseMode.NONE.value,
        choices=[mode.value for mode in DefenseMode],
        help='select the core defense mode for this attacklab run',
    )

    runtime_suite = subparsers.add_parser(
        'runtime-suite',
        help='run deterministic runtime security regression checks',
    )
    runtime_suite_subparsers = runtime_suite.add_subparsers(dest='runtime_suite_command')

    runtime_suite_run_parser = runtime_suite_subparsers.add_parser(
        'run',
        help='run the runtime suite for one supported profile',
    )
    runtime_suite_run_parser.add_argument(
        '--profile',
        default='strict',
        choices=SUPPORTED_RUNTIME_SUITE_PROFILES,
        help='runtime-suite profile to run',
    )
    runtime_suite_run_parser.add_argument(
        '--json',
        action='store_true',
        help='print the full runtime-suite report as JSON',
    )

    memory = subparsers.add_parser('memory', help='review and resolve candidate memory entries')
    memory_subparsers = memory.add_subparsers(dest='memory_command')

    memory_list_parser = memory_subparsers.add_parser('list', help='list candidate memory entries')
    add_memory_store_argument(memory_list_parser)
    memory_list_parser.add_argument(
        '--status',
        choices=[status.value for status in CandidateMemoryStatus],
        help='filter by candidate status',
    )

    memory_show_parser = memory_subparsers.add_parser('show', help='show one candidate memory entry')
    add_memory_store_argument(memory_show_parser)
    memory_show_parser.add_argument('candidate_id')

    memory_review_parser = memory_subparsers.add_parser('review', help='review one candidate memory entry')
    add_memory_store_argument(memory_review_parser)
    memory_review_parser.add_argument('candidate_id')
    memory_review_parser.add_argument('--reviewer-id', default='owner')

    memory_commit_parser = memory_subparsers.add_parser('commit', help='commit one candidate memory entry')
    add_memory_store_argument(memory_commit_parser)
    memory_commit_parser.add_argument('candidate_id')
    memory_commit_parser.add_argument('--reviewer-id', default='owner')
    memory_commit_parser.add_argument('--note')

    memory_reject_parser = memory_subparsers.add_parser('reject', help='reject one candidate memory entry')
    add_memory_store_argument(memory_reject_parser)
    memory_reject_parser.add_argument('candidate_id')
    memory_reject_parser.add_argument('--reviewer-id', default='owner')
    memory_reject_parser.add_argument('--note')

    demo = subparsers.add_parser('demo', help='run local demo flows')
    demo_subparsers = demo.add_subparsers(dest='demo_command')

    run_parser = demo_subparsers.add_parser('run', help='start or continue the current demo session')
    add_demo_dir_argument(run_parser)
    run_parser.add_argument(
        '--fresh',
        action='store_true',
        help='reset the saved demo state before starting again',
    )
    run_parser.add_argument('--reviewer-id', default='owner')

    demo_show_parser = demo_subparsers.add_parser('show', help='show the saved demo session')
    add_demo_dir_argument(demo_show_parser)

    mcp = subparsers.add_parser('mcp', help='run the Sheltron MCP server')
    mcp_subparsers = mcp.add_subparsers(dest='mcp_command')

    mcp_serve_parser = mcp_subparsers.add_parser('serve', help='serve Sheltron tools over MCP stdio')
    mcp_serve_parser.add_argument('--workspace', help='path to the guarded workspace')
    mcp_serve_parser.add_argument('--approval-store', help='path to the approval store JSON file')
    mcp_serve_parser.add_argument('--audit-log', help='path to the audit JSONL log file')
    mcp_serve_parser.add_argument('--system', default='sheltron_mcp', help='system name to include in audit events')
    mcp_serve_parser.add_argument(
        '--downstream-broker',
        help='optional broker spec like package.module:broker or package.module:factory',
    )

    adapters = subparsers.add_parser(
        'adapters',
        help='inspect the bundled Sheltron agent adapters available in this install',
    )
    adapters_subparsers = adapters.add_subparsers(dest='adapters_command')

    adapters_list_parser = adapters_subparsers.add_parser(
        'list',
        help='show the bundled Sheltron agent adapters plus importability and local support status',
    )
    adapters_list_parser.add_argument(
        '--json',
        action='store_true',
        help='print the adapter inventory as JSON',
    )

    for adapter in get_builtin_host_adapters():
        adapter.register_parser(subparsers)

    return parser
