from sheltron.cli_dispatch import main
from sheltron.cli_parser import build_parser

__all__ = ['build_parser', 'main']


if __name__ == '__main__':
    raise SystemExit(main())
