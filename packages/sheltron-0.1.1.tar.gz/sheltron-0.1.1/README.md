
<p align="center">
  <img src="images/sheltron.png" alt="Sheltron" width="350">
</p>

# Sheltron — The safety layer for AI agents

## 1. Introduction

Sheltron is a non-intrusive sidecar safety layer for local AI agents. This repo contains the Sheltron core, runtime guards, CLI, MCP integration, and adapters that protect agent systems such as OpenClaw without modifying their source code.

Sheltron adds policy, approval, and audit controls around high-impact agent behavior: filesystem access, shell execution, network activity, outbound messaging, memory updates, bootstrap files, and skills. The goal is to make existing agents safer to install, run, and extend without hard-forking or rewriting them.

## 2. Supported Functions

#### [nanobot](https://github.com/HKUDS/nanobot): `nanobot-ai==0.1.4.post6`, `nanobot-ai==0.1.5.post2`

- Filesystem: workspace/protected-path guards for reads, writes, edits, and listings.
- Shell: approval-gated exec with audit records.
- Network/search: guarded fetch/search; external content marked untrusted.
- Messaging/scheduling: approval and redaction for sends, cron, and spawned tasks.
- Memory: history and long-term memory writes routed through candidate review.

#### [OpenClaw](https://github.com/openclaw/openclaw): `OpenClaw 2026.4.21`

- Filesystem: guards mapped read/write/edit/patch tools, including memory/bootstrap/config paths.
- Shell/process: approval-gated host execution.
- Network/search: guarded fetch/search with prompt-injection hardening.
- Messaging: recipient/content policy with redaction-aware approval.
- Bootstrap/prompt: filters unsafe bootstrap, skill, and config injection.
- Memory: durable writes reviewed as memory candidates.

#### Planned To-do

- [Hermes](https://github.com/NousResearch/hermes-agent): no adapter or safety coverage is shipped yet.
- Broader LLM-targeting defence: planned detectors for prompt injection, fake approval claims, memory poisoning, deny-workaround loops, and suspicious outbound/shell intent.
- Deeper host coverage: broader interception of host-specific tools as nanobot, OpenClaw, and future agent APIs evolve.
- Verify pip installation

## 3. Installation Guide

Sheltron requires Python 3.11+. `uv` is the primary supported installation and development path.


#### Clone and Install Sheltron

From a source checkout, use an editable uv tool install. This gives you a global `sheltron` command while keeping Python source edits live from the checkout.

```bash
git clone https://github.com/sheltron-ai/sheltron.git
cd sheltron
uv sync --python 3.11 --extra dev
uv tool install --editable .
```

#### Link Sheltron to the agent you have installed

nanobot:
```bash
sheltron link nanobot
```
OpenClaw:
```bash
sheltron link openclaw
```

<!-- (For zero-global-state development, run the checkout directly) :

```bash
uv run --python 3.11 sheltron link nanobot
uv run --python 3.11 sheltron link openclaw
``` -->

#### Start protected run
```bash
sheltron <agent> ...
```

nanobot:
```bash
sheltron nanobot agent
```
OpenClaw:
```bash
sheltron openclaw gateway run
```

#### Or, use always-on mode
Turn on always-on:
```bash
sheltron on nanobot
```
```bash
sheltron on openclaw
```
And run
```bash
nanobot agent / openclaw gateway run / ...
```
commands with sheltron always-on.

Turn off always-on:
```bash
sheltron off <agent>
```

#### Unlink agent (only needed for uninstall or reinstall)
```bash
sheltron unlink <agent>
```

#### Uninstall
Before removing Sheltron itself, unlink agent integrations first:
```bash
sheltron unlink --all
uv tool uninstall sheltron
```




## 4. Example Use Cases

These examples show one protected action for each supported adapter.

#### Example: nanobot Filesystem Protection

Link nanobot:

```bash
sheltron link nanobot
```

Start a protected nanobot session in a disposable workspace:

```bash
mkdir -p examples/nanobot/live_test
sheltron nanobot agent --workspace "$PWD/examples/nanobot/live_test"
```

Inside nanobot, check Sheltron status:

```text
Check Sheltron status.
```

Expected behavior:

- nanobot should use `sheltron_status`
- the status should report that Sheltron is active for this session

Inside nanobot, test filesystem protection:

```text
Write ../outside.txt with the exact text "approval test".
```

Expected behavior:

- writing outside the workspace should require approval
- the file must not be written before approval
- the model should explain the Sheltron policy result instead of trying another unsafe path
<img src="images/example1_0.png" alt="Nanobot filesystem protection approval example" width="750">

#### Example: OpenClaw Exec Protection

Link OpenClaw:

```bash
sheltron link openclaw
```

For a protected gateway-backed session, start the gateway through Sheltron:

```bash
sheltron openclaw gateway run
```

In OpenClaw, check Sheltron status:

```text
Is Sheltron on?
```

Expected behavior:

- OpenClaw should use `sheltron_status`
- the status should report protected-run or global protection
<img src="images/example2_0.png" alt="OpenClaw exec protection status check" width="800">

In OpenClaw, test shell execution:

```text
Run the exact shell command bash -lc "printf openclaw-exec-test" and return only stdout.
```

Expected behavior:

- OpenClaw's tool hook should route the exec request through Sheltron
- shell execution should require approval before running
- if approval is unavailable, the tool call should fail closed rather than execute silently
<img src="images/example2_3.png" alt="OpenClaw exec protection final output" width="800">
<img src="images/example2_2.png" alt="OpenClaw exec protection approval result" width="450">
<img src="images/example2_1.png" alt="OpenClaw exec protection approval request" width="800">

## 5. License

Sheltron is licensed under the [Apache License 2.0](LICENSE).
