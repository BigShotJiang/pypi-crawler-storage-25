from setuptools import setup, find_packages

setup(
    name="pninfo", # PyPI da ko'rinadigan noyob nom
    version="0.0.1",
    author="G'ulomjonov Javohir",
    description="Ushbu kutubxona orqali istalgan raqamingizni taxmin qilib yaratib olishingiz mumkin!",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/ozodbekcommunity",
    packages=find_packages(),
    install_requires=[
        "requests",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)