# 📱 pninfo

O'zbekiston mobil raqamlarini generatsiya qilish, validatsiya qilish, detalizatsiya yig'ish va holatini tekshirish uchun mo'ljallangan Python kutubxonasi.

## ✨ Xususiyatlari
- ✅ **Generatsiya**: Operator, prefix, regex/oddiy shablon, format (+998, 99..., raw) bo'yicha
- ✅ **Validatsiya**: O'zbekiston raqamlash rejasiga moslikni tekshirish
- ✅ **Detalizatsiya**: Operator, prefix, mintaqa, format, uzunlik haqida to'liq ma'lumot
- ✅ **Holat tekshiruvi**: Simulyatsiya + API-integratsiya tayyor struktura
- ✅ **Kengaytiriluvchan**: Yangi operator/kod qo'shish, custom API callback ulash

## ⚖️ Huquqiy & Texnik Ogohlantirish
> 🔍 **Real vaqtda raqamning band/bo'sh yoki faol/nofaol ekanligini aniqlash** faqat litsenziyalangan HLR (Home Location Register) tizimlari, operatorlarning rasmiy API'lar yoki tegishli shartnomalar orqali amalga oshirilishi mumkin. Ochiq internetdagi "bepul skanerlash" usullari qonunga zid va texnik jihatdan ishonchsiz. `pninfo` kutubxonasi default holatda **xavfsiz simulyatsiya** qiladi. Real tekshiruv uchun litsenziyalangan API kalitlarini ulashingiz kerak.

## 📦 O'rnatish
```bash
pip install pninfo
# yoki lokal o'rnatish:
pip install .
```

## 🚀 Tez Boshlash

```python
from pninfo import generate, get_info, check_availability, configure_api

# 1. Generatsiya
nums = generate(operator="beeline", count=5, pattern="endswith:1234", format_type="local")
print(nums)  # ['9012341234', ...]

# 2. Ma'lumot yig'ish
info = get_info("+998901234567")
print(info.operator)       # beeline
print(info.is_valid_format)# True
print(info.metadata)       # {...}

# 3. Real holat tekshiruvi (API bilan)
configure_api("numverify", {"api_key": "SIZNING_API_KALITINGIZ"})
status = check_availability("+998901234567")
print("Faol" if status else "Nofaol/Band")
```