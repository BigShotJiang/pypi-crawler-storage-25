"""
pninfo - O'zbekiston mobil raqamlarini generatsiya qilish, validatsiya qilish va tahlil qilish kutubxonasi.

Qo'llab-quvvatlanuvchi operatorlar:
  Beeline, Ucell, Mobiuz, Uzmobile, Humans, Perfectum Mobile, O'q Mobile

Eslatma: Real vaqtda raqam holatini tekshirish faqat litsenziyalangan HLR/Verification API
yoki operatorlar bilan rasmiy shartnoma orqali amalga oshirilishi mumkin.
"""

import re
import random
import string
from typing import List, Optional, Dict, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
logger = logging.getLogger(__name__)

# ======================== ENUM & DATA ========================

class Operator(Enum):
    BEELINE = "beeline"
    UCELL = "ucell"
    MOBIUZ = "mobiuz"
    UZMOBILE = "uzmobile"
    HUMANS = "humans"
    PERFECTUM = "perfectum"
    OQ_MOBILE = "oq_mobile"

# O'zbekiston raqamlash rejasi (AURA ma'lumotlariga asoslangan, o'zgarishi mumkin)
OPERATOR_PREFIXES: Dict[str, List[str]] = {
    Operator.BEELINE.value: ["90", "91"],
    Operator.UCELL.value: ["93", "94", "50"],
    Operator.MOBIUZ.value: ["88", "97"],
    Operator.UZMOBILE.value: ["99", "95", "77"],
    Operator.HUMANS.value: ["33"],
    Operator.PERFECTUM.value: ["98"],
    Operator.OQ_MOBILE.value: ["20"],
}

# Validatsiya regexp
UZ_PHONE_REGEX = re.compile(r"^(?:\+998|998|88)?(\d{2})(\d{7})$")

@dataclass
class PhoneNumberInfo:
    number: str
    raw_number: str
    operator: Optional[str]
    country_code: str = "+998"
    is_valid_format: bool = False
    is_active: Optional[bool] = None
    metadata: Dict = field(default_factory=dict)

    def __post_init__(self):
        if not self.operator:
            self.metadata["note"] = "Operator aniqlanmadi yoki noma'lum prefix"
        if self.is_active is None:
            self.metadata["status_check"] = "Simulyatsiya/Sozlanmagan. Real tekshiruv uchun API ulash kerak."

# ======================== CORE CLASS ========================

class PnInfo:
    def __init__(self):
        self.prefix_db = OPERATOR_PREFIXES.copy()
        self._api_client: Optional[Callable] = None
        self._api_config: Dict = {}

    # ---------- GENERATOR ----------
    def generate(
        self,
        operator: Optional[str] = None,
        prefix: Optional[str] = None,
        pattern: Optional[str] = None,
        count: int = 1,
        format_type: str = "international"
    ) -> List[str]:
        """
        Raqam generatsiya qiladi.
        :param operator: Operator nomi yoki enum qiymati
        :param prefix: 2 xonali kod (masalan: '90', '99')
        :param pattern: Regex yoki oddiy shablon (masalan: r'.*1234$', 'contains:777')
        :param count: Nechta raqam generatsiya qilish
        :param format_type: 'international' (+998...), 'local' (99...), 'raw' (faqat raqamlar)
        """
        if count < 1:
            raise ValueError("count 1 dan kichik bo'lmasligi kerak")

        # Operator/Prefix validatsiyasi
        if operator and prefix:
            allowed_prefixes = self.prefix_db.get(operator, [])
            if prefix not in allowed_prefixes:
                logger.warning(f"{operator} operatori uchun {prefix} kodi noto'g'ri. Qo'lda prefix ishlatilmoqda.")
        
        target_prefix = prefix
        if operator and not prefix:
            available = self.prefix_db.get(operator, [])
            if not available:
                raise ValueError(f"Noma'lum operator: {operator}")
            target_prefix = random.choice(available)

        if not target_prefix:
            target_prefix = random.choice([p for prefixes in self.prefix_db.values() for p in prefixes])

        results = []
        pattern_func = self._compile_pattern(pattern)
        attempts = 0
        max_attempts = count * 50  # Cheklovsiz loop oldini olish

        while len(results) < count and attempts < max_attempts:
            attempts += 1
            suffix = "".join(random.choices(string.digits, k=7))
            candidate = f"998{target_prefix}{suffix}"

            if pattern_func and not pattern_func(candidate):
                continue

            formatted = self._format_number(candidate, format_type)
            results.append(formatted)

        if len(results) < count:
            logger.warning(f"Faqat {len(results)} ta raqam generatsiya qilindi. Pattern juda qattiq bo'lishi mumkin.")

        return results

    # ---------- INFO & VALIDATION ----------
    def get_info(self, number: str) -> PhoneNumberInfo:
        """Raqam haqida to'liq ma'lumot yig'adi."""
        raw = self._clean_number(number)
        match = UZ_PHONE_REGEX.match(raw)
        info = PhoneNumberInfo(number=number, raw_number=raw, operator=None)

        if not match:
            info.is_valid_format = False
            info.metadata["error"] = "Noto'g'ri format"
            return info

        info.is_valid_format = True
        prefix = match.group(1)
        info.country_code = "+998"

        # Operator aniqlash
        for op, prefixes in self.prefix_db.items():
            if prefix in prefixes:
                info.operator = op
                break

        # Detalizatsiya
        info.metadata.update({
            "prefix": prefix,
            "length": len(raw),
            "type": "mobile",
            "region": "O'zbekiston",
            "format": "international" if raw.startswith("+998") else "local"
        })

        # Aktivlik holati (agar API sozlangan bo'lsa)
        if self._api_client:
            try:
                info.is_active = self._api_client(raw, self._api_config)
                info.metadata["status_source"] = "API"
            except Exception as e:
                info.is_active = None
                info.metadata["status_error"] = str(e)

        return info

    def check_availability(self, number: str) -> Optional[bool]:
        """
        Raqamning band/bo'sh ekanligini tekshiradi.
        Eslatma: Default holatda simulyatsiya qiladi. Real tekshiruv uchun configure_status_api() chaqiring.
        """
        info = self.get_info(number)
        if not info.is_valid_format:
            return False
        return info.is_active

    # ---------- API INTEGRATION HOOK ----------
    def configure_status_api(self, api_type: str, config: Dict):
        """
        Real vaqtda raqam holatini tekshirish uchun API ulash.
        Qo'llab-quvvatlanadigan turlar: 'numverify', 'hlr_lookup', 'custom'
        """
        if api_type not in ("numverify", "hlr_lookup", "custom"):
            raise ValueError("Noma'lum API turi. Qo'llab-quvvatlanadigan: numverify, hlr_lookup, custom")

        self._api_config = config
        if api_type == "numverify":
            self._api_client = self._numverify_checker
        elif api_type == "hlr_lookup":
            self._api_client = self._hlr_lookup_checker
        elif api_type == "custom":
            if "callback" not in config:
                raise ValueError("custom API uchun 'callback' kaliti majburiy")
            self._api_client = config["callback"]

    def _numverify_checker(self, raw_number: str, config: Dict) -> Optional[bool]:
        import requests
        api_key = config.get("api_key", "")
        url = f"http://apilayer.net/api/validate?access_key={api_key}&number={raw_number}&country_code=UZ"
        resp = requests.get(url, timeout=5)
        data = resp.json()
        return data.get("valid", False) and data.get("carrier", {}).get("name") is not None

    def _hlr_lookup_checker(self, raw_number: str, config: Dict) -> Optional[bool]:
        import requests
        api_key = config.get("api_key", "")
        url = f"https://api.hlr-lookup.com/api/v2/check?api_key={api_key}&msisdn={raw_number}"
        resp = requests.get(url, timeout=5)
        data = resp.json()
        return data.get("status", "").lower() in ("active", "connected")

    # ---------- YORDAMCHI METODLAR ----------
    def _clean_number(self, number: str) -> str:
        cleaned = re.sub(r"[^\d+]", "", number)
        if cleaned.startswith("+998"):
            return cleaned
        if cleaned.startswith("998"):
            return f"+{cleaned}"
        if cleaned.startswith("88"):
            return f"+998{cleaned[2:]}"
        return cleaned

    def _format_number(self, number: str, fmt: str) -> str:
        raw = self._clean_number(number)
        if not raw.startswith("+998"):
            raw = f"+{raw}"
        if fmt == "international":
            return raw
        if fmt == "local":
            return raw[1:]
        if fmt == "raw":
            return raw.replace("+", "")
        return raw

    def _compile_pattern(self, pattern: Optional[str]):
        if not pattern:
            return None
        if pattern.startswith("contains:"):
            substr = pattern[9:]
            return lambda num: substr in num
        try:
            regex = re.compile(pattern)
            return lambda num: regex.search(num) is not None
        except re.error:
            raise ValueError(f"Noto'g'ri regex pattern: {pattern}")

    def add_custom_prefix(self, operator: str, prefix: str):
        """Yangi operator/kod qo'shish yoki mavjudini yangilash."""
        if operator not in self.prefix_db:
            self.prefix_db[operator] = []
        if prefix not in self.prefix_db[operator]:
            self.prefix_db[operator].append(prefix)
            logger.info(f"{operator} -> {prefix} qo'shildi")

# ======================== CONVENIENCE EXPORTS ========================

_pn = PnInfo()

def generate(
    operator: Optional[str] = None,
    prefix: Optional[str] = None,
    pattern: Optional[str] = None,
    count: int = 1,
    format_type: str = "international"
) -> List[str]:
    return _pn.generate(operator, prefix, pattern, count, format_type)

def get_info(number: str) -> PhoneNumberInfo:
    return _pn.get_info(number)

def check_availability(number: str) -> Optional[bool]:
    return _pn.check_availability(number)

def configure_api(api_type: str, config: Dict):
    return _pn.configure_status_api(api_type, config)