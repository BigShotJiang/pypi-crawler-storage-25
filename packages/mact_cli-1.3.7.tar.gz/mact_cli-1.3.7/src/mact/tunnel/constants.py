"""Defaults for frpc / `mact configure-frp` — single source of truth (avoid CLI vs client drift)."""

from __future__ import annotations

# frps control port (TCP)
DEFAULT_FRPS_ADDR = "m-act.live"
DEFAULT_FRPS_PORT = 7000

# HTTP vhost on frps (nginx terminates TLS and forwards here)
DEFAULT_VHOST_DOMAIN = "tunnel.m-act.live"
DEFAULT_VHOST_HTTP_PORT = 80
DEFAULT_PUBLIC_SCHEME = "https"

# Must match ``auth.token`` in frps (see ``deployment/frps/frps.toml`` for the checked-in template;
# production: ``/etc/mact/frps.toml`` on m-act.live).
# Self-hosted: override with ``mact configure-frp --auth-token ...`` or ``MACT_FRP_AUTH_TOKEN``.
DEFAULT_FRPS_AUTH_TOKEN = "hL6GGju93XMijbBszNRU6BHqIYEfDBshcj6wdaNSeyg="
