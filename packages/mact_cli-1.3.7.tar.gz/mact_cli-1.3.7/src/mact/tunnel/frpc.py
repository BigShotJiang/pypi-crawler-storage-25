from __future__ import annotations

import os
import signal
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

import requests

from mact.tunnel.base import Tunnel
from mact.tunnel.constants import (
    DEFAULT_FRPS_ADDR,
    DEFAULT_FRPS_PORT,
    DEFAULT_PUBLIC_SCHEME,
    DEFAULT_VHOST_DOMAIN,
    DEFAULT_VHOST_HTTP_PORT,
)
from mact.tunnel.frpc_download import ensure_frpc_executable


def _frpc_control_uses_tls() -> bool:
    """If true, frpc uses TLS to reach frps (must match server). Default: plain TCP."""
    raw = os.environ.get("MACT_FRPC_TRANSPORT_TLS", "").strip().lower()
    return raw in ("1", "true", "yes")


def _skip_tunnel_http_verify() -> bool:
    raw = os.environ.get("MACT_SKIP_TUNNEL_HTTP_VERIFY", "").strip().lower()
    return raw in ("1", "true", "yes")


def _tunnel_verify_max_attempts() -> int:
    raw = os.environ.get("MACT_TUNNEL_HTTP_VERIFY_ATTEMPTS", "20").strip()
    try:
        n = int(raw)
    except ValueError:
        return 20
    return max(1, min(n, 60))


def _tunnel_verify_initial_delay_sec() -> float:
    raw = os.environ.get("MACT_TUNNEL_HTTP_VERIFY_INITIAL_DELAY_SEC", "0.5").strip()
    try:
        return max(0.0, min(float(raw), 30.0))
    except ValueError:
        return 0.5


def _tunnel_verify_backoff_sec(attempt_index: int) -> float:
    """Between GET attempts; grows slightly so frps can finish vhost registration."""
    return min(3.0, 0.35 + attempt_index * 0.2)


def _tunnel_verify_strict() -> bool:
    """
    If true, repeated frp vhost-miss responses cause tunnel.start() to fail.
    Default is **soft**: warn and continue so heartbeats still register the public URL
    when frpc logged success but this machine's HTTPS check disagrees (edge DNS/TLS) or
    frps/nginx is misconfigured — fixing the mirror requires the tunnel URL in the API.
    """
    raw = os.environ.get("MACT_TUNNEL_HTTP_VERIFY_STRICT", "").strip().lower()
    return raw in ("1", "true", "yes")


def _requests_verify_for_tunnel_get() -> bool | str:
    """TLS verify= for the public tunnel URL check (defaults to True; override with MACT_SSL_VERIFY)."""
    ca = os.environ.get("MACT_CA_BUNDLE", "").strip()
    if ca:
        p = Path(ca)
        if p.is_file():
            return str(p)
    env = os.environ.get("MACT_SSL_VERIFY", "").strip().lower()
    if env in ("1", "true", "yes", "on"):
        return True
    if env in ("0", "false", "no", "off"):
        return False
    return True


def _is_frp_vhost_miss_page(status_code: int, body: str) -> bool:
    """frps returns this HTML when no proxy is registered for the Host (or frpc died)."""
    if status_code != 404:
        return False
    low = body.lower()
    return "faithfully yours" in low and "frp" in low


def _verify_public_url_after_proxy_ready(tunnel: FrpcTunnel) -> None:
    """
    After frpc logs 'start proxy success', confirm the public URL is not still frp's
    generic vhost-miss page. That page means nginx reached frps but no HTTP proxy matched
    the Host — wrong frps, token, or routing — not a PyPI/client version issue alone.

    The vhost can lag briefly after the log line; we retry frp-404 the same way as
    network errors instead of failing on the first GET.

    By default, a failed check does **not** abort ``tunnel.start()`` so the CLI can still
    send heartbeats with the public URL (otherwise the mirror stays on 127.0.0.1). Use
    ``MACT_TUNNEL_HTTP_VERIFY_STRICT=1`` to fail fast when this check never succeeds.
    """
    if _skip_tunnel_http_verify():
        return
    url = tunnel.public_url
    max_attempts = _tunnel_verify_max_attempts()
    initial_delay = _tunnel_verify_initial_delay_sec()
    if initial_delay > 0:
        time.sleep(initial_delay)

    verify_tls = _requests_verify_for_tunnel_get()
    last_err: BaseException | None = None
    for attempt in range(max_attempts):
        try:
            r = requests.get(url, timeout=15, verify=verify_tls)
            last_err = None
            if _is_frp_vhost_miss_page(r.status_code, r.text or ""):
                if attempt >= max_attempts - 1:
                    if _tunnel_verify_strict():
                        raise RuntimeError(
                            f"The tunnel URL {url!r} still returns frp's 'no proxy for this host' "
                            "page after the client registered the proxy. Traffic is reaching frps, "
                            "but frps has no matching HTTP route — often a second frps on a "
                            "different port, nginx proxy_pass not pointing at the same vhostHTTPPort "
                            "as this frpc, or the browser Host does not match customDomains "
                            f"(expected {tunnel._tunnel_fqdn!r}). On the machine running mact: "
                            "keep frpc running while testing; run `mact configure-frp` so the token "
                            "matches /etc/mact/frps.toml on the server. "
                            "(Unset MACT_TUNNEL_HTTP_VERIFY_STRICT for default soft mode, or "
                            "MACT_SKIP_TUNNEL_HTTP_VERIFY=1 to skip this check.)"
                        )
                    print(
                        f"mact: tunnel URL {url!r} still shows frp's vhost-miss page after "
                        f"{max_attempts} HTTPS check(s); frpc reported success — continuing so "
                        "heartbeats can register your public URL (mirror needs it, not 127.0.0.1). "
                        "If the site stays broken, fix frps/nginx or run with "
                        "MACT_TUNNEL_HTTP_VERIFY_STRICT=1 to fail here instead.",
                        file=sys.stderr,
                    )
                    return
                time.sleep(_tunnel_verify_backoff_sec(attempt))
                continue
            return
        except RuntimeError:
            raise
        except requests.RequestException as exc:
            last_err = exc
            if attempt >= max_attempts - 1:
                break
            time.sleep(_tunnel_verify_backoff_sec(attempt))
    print(
        f"mact: could not verify tunnel URL over HTTPS (attempted {url!r}): {last_err!r}. "
        "If the site works in a browser, ignore this. To skip verification: "
        "MACT_SKIP_TUNNEL_HTTP_VERIFY=1.",
        file=sys.stderr,
    )


def _tunnel_dns_label(segment: str) -> str:
    """
    Hostnames for ``customDomains`` must use labels that work in DNS and TLS.
    Developer/room ids may contain ``_`` (valid in MACT slugs) but not in host
    labels — normalize to ``-`` so nginx ``Host`` matches frps routing.
    """
    s = (segment or "").strip().lower()
    return s.replace("_", "-")


class FrpcTunnel(Tunnel):
    """Manages an frpc process that tunnels a local port via frps."""

    def __init__(
        self,
        local_port: int,
        room_id: str,
        developer_id: str,
        server_addr: str = DEFAULT_FRPS_ADDR,
        server_port: int = DEFAULT_FRPS_PORT,
        auth_token: str = "",
        vhost_domain: str = DEFAULT_VHOST_DOMAIN,
        vhost_http_port: int = DEFAULT_VHOST_HTTP_PORT,
        public_scheme: str = DEFAULT_PUBLIC_SCHEME,
    ) -> None:
        self._local_port = local_port
        self._room_id = room_id.strip()
        self._developer_id = developer_id.strip()
        self._label_dev = _tunnel_dns_label(self._developer_id)
        self._label_room = _tunnel_dns_label(self._room_id)
        addr = (server_addr or "").strip()
        self._server_addr = addr if addr else DEFAULT_FRPS_ADDR
        self._server_port = server_port
        self._auth_token = auth_token
        vd = (vhost_domain or "").strip()
        self._vhost_domain = vd if vd else DEFAULT_VHOST_DOMAIN
        self._vhost_http_port = vhost_http_port
        self._public_scheme = public_scheme if public_scheme in ("http", "https") else "https"
        self._process: subprocess.Popen | None = None
        self._config_path: Path | None = None
        self._stderr_thread: threading.Thread | None = None
        self._stderr_stop: threading.Event | None = None
        self._frpc_stderr_tail: list[str] = []

    @property
    def proxy_name(self) -> str:
        # frps proxy name; labels normalized (see _tunnel_dns_label).
        return f"mact-{self._label_dev}-{self._label_room}"

    @property
    def _tunnel_fqdn(self) -> str:
        """Must match `customDomains` in frpc and the Host header nginx forwards to frps."""
        v = self._vhost_domain.lower()
        return f"{self._label_dev}-{self._label_room}.{v}"

    @property
    def public_url(self) -> str:
        """URL registered with the API for mirroring; must match how nginx exposes the tunnel."""
        host = self._tunnel_fqdn
        port = self._vhost_http_port
        if self._public_scheme == "https":
            # Config may still say 80 from older installs; public TLS is on 443.
            if port and port not in (80, 443):
                return f"https://{host}:{port}"
            return f"https://{host}"
        if port and port != 80:
            return f"http://{host}:{port}"
        return f"http://{host}"

    def generate_config(self) -> str:
        # Minimal TOML-safe escaping for quoted string values.
        def _toml_escape(value: str) -> str:
            return value.replace("\\", "\\\\").replace('"', '\\"')

        # transport.tls.enable: frp v0.50+ defaults to true; public m-act.live frps uses
        # plain TCP on bindPort — TLS mismatch prevents login → no HTTP proxy registered
        # → vhost shows frp's "The page you requested was not found". Override with
        # MACT_FRPC_TRANSPORT_TLS=1 if your frps expects TLS on the control port.
        tls_line = (
            "transport.tls.enable = true"
            if _frpc_control_uses_tls()
            else "transport.tls.enable = false"
        )
        lines = [
            f'serverAddr = "{self._server_addr}"',
            f"serverPort = {self._server_port}",
            tls_line,
        ]
        if self._auth_token:
            lines.append('auth.method = "token"')
            lines.append(f'auth.token = "{_toml_escape(self._auth_token)}"')
        lines.extend(
            [
                "",
                "[[proxies]]",
                f'name = "{self.proxy_name}"',
                'type = "http"',
                'localIP = "127.0.0.1"',
                f"localPort = {self._local_port}",
                f'customDomains = ["{self._tunnel_fqdn}"]',
            ]
        )
        return "\n".join(lines) + "\n"

    def start(self) -> None:
        if self._process and self._process.poll() is None:
            return

        frpc = ensure_frpc_executable()

        config_content = self.generate_config()
        fd, path = tempfile.mkstemp(suffix=".toml", prefix="mact-frpc-")
        try:
            os.write(fd, config_content.encode())
        finally:
            os.close(fd)
        self._config_path = Path(path)

        try:
            verify = subprocess.run(
                [frpc, "verify", "-c", str(self._config_path)],
                capture_output=True,
                text=True,
                timeout=15,
            )
            if verify.returncode != 0:
                detail = (verify.stderr or verify.stdout or "").strip() or "(no output)"
                raise RuntimeError(f"frpc verify failed: {detail[:2000]}")

            self._frpc_stderr_tail = []
            self._stderr_stop = threading.Event()
            proxy_ready = threading.Event()
            proxy_failed = threading.Event()

            # frp writes INFO logs to stdout (with colors); stderr is separate. Merge
            # streams so one reader drains the pipe — avoids lost "start proxy success"
            # lines and avoids filling an unread pipe buffer (which would block frpc).
            self._process = subprocess.Popen(
                [frpc, "-c", str(self._config_path)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
            )

            pname = self.proxy_name

            def _drain_stderr() -> None:
                proc = self._process
                if not proc or not proc.stdout:
                    return
                try:
                    for raw in iter(proc.stdout.readline, b""):
                        if self._stderr_stop and self._stderr_stop.is_set():
                            break
                        line = raw.decode(errors="replace").rstrip()
                        self._frpc_stderr_tail.append(line)
                        if len(self._frpc_stderr_tail) > 300:
                            del self._frpc_stderr_tail[:100]
                        low = line.lower()
                        if pname in line and "start proxy success" in low:
                            proxy_ready.set()
                        if pname in line and "start error" in low:
                            proxy_failed.set()
                        if any(
                            x in low
                            for x in (
                                "login to server failed",
                                "authentication failed",
                                "invalid token",
                                "authorization failed",
                            )
                        ):
                            proxy_failed.set()
                except Exception:
                    pass

            self._stderr_thread = threading.Thread(
                target=_drain_stderr, name="mact-frpc-stderr", daemon=True
            )
            self._stderr_thread.start()

            # Auth / TCP to frps + NewProxy handshake; catch early exit.
            deadline = time.monotonic() + 20.0
            while time.monotonic() < deadline:
                if self._process.poll() is not None:
                    break
                if proxy_failed.is_set():
                    tail = "\n".join(self._frpc_stderr_tail[-50:])
                    raise RuntimeError(
                        "frpc reported a login or proxy error. Fix auth token, frps "
                        "address/port, or TLS (MACT_FRPC_TRANSPORT_TLS). Stderr:\n"
                        f"{tail}"
                    )
                if proxy_ready.is_set():
                    break
                time.sleep(0.05)

            if self._process.poll() is not None:
                time.sleep(0.05)
                tail = "\n".join(self._frpc_stderr_tail[-50:])
                detail = tail.strip() or "(no stderr captured)"
                raise RuntimeError(f"frpc exited before tunnel was ready: {detail[:4000]}")

            if not proxy_ready.is_set():
                tail = "\n".join(self._frpc_stderr_tail[-50:])
                raise RuntimeError(
                    "frpc did not confirm the HTTP proxy on frps within 20s. Without "
                    "'start proxy success', the public URL will show frp's "
                    "'page not found'. Typical causes: wrong auth.token, frpc cannot "
                    "reach frps :7000, TLS mismatch (try MACT_FRPC_TRANSPORT_TLS), or "
                    "stderr was not readable. Stderr:\n"
                    f"{tail}"
                )
            _verify_public_url_after_proxy_ready(self)
        except Exception:
            if self._stderr_stop:
                self._stderr_stop.set()
            if self._process and self._process.poll() is None:
                try:
                    self._process.kill()
                    self._process.wait(timeout=2)
                except Exception:
                    pass
            if self._stderr_thread and self._stderr_thread.is_alive():
                self._stderr_thread.join(timeout=0.5)
            self._unlink_config_file()
            self._process = None
            self._stderr_thread = None
            raise

    def _unlink_config_file(self) -> None:
        if self._config_path and self._config_path.exists():
            self._config_path.unlink(missing_ok=True)

    def stop(self) -> None:
        if self._stderr_stop:
            self._stderr_stop.set()
        if self._process and self._process.poll() is None:
            self._process.send_signal(signal.SIGTERM)
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
        if self._stderr_thread and self._stderr_thread.is_alive():
            self._stderr_thread.join(timeout=1.0)
        self._unlink_config_file()
        self._process = None
        self._config_path = None
        self._stderr_thread = None
        self._stderr_stop = None

    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None
