"""Tests for tunnel config generation and lifecycle (mocked subprocess)."""

import os
from unittest.mock import MagicMock, patch

import pytest

from mact.tunnel.frpc import FrpcTunnel, _is_frp_vhost_miss_page


def test_frp_vhost_miss_page_detection():
    assert _is_frp_vhost_miss_page(
        404,
        "The page you requested was not found. Faithfully yours, frp.",
    )
    assert not _is_frp_vhost_miss_page(404, "Not Found — my app")
    assert not _is_frp_vhost_miss_page(200, "Faithfully yours, frp.")


def test_public_url_format():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="tunnel.m-act.live",
        public_scheme="https",
    )
    assert t.public_url == "https://alice-demo.tunnel.m-act.live"


def test_public_url_https_custom_port():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="tunnel.example.com",
        vhost_http_port=8443,
        public_scheme="https",
    )
    assert t.public_url == "https://alice-demo.tunnel.example.com:8443"


def test_public_url_http_localhost():
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="alice",
        vhost_domain="localhost",
        vhost_http_port=18180,
        public_scheme="http",
    )
    assert t.public_url == "http://alice-demo.localhost:18180"


def test_proxy_name():
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="bob")
    assert t.proxy_name == "mact-bob-demo"


def test_mixed_case_developer_normalizes_for_dns_and_frps():
    """DEV_RE allows uppercase; Host / customDomains must be lowercase for stable routing."""
    t = FrpcTunnel(
        local_port=3000,
        room_id="demo",
        developer_id="Alice",
        vhost_domain="Tunnel.EXAMPLE.com",
        public_scheme="https",
    )
    assert t.proxy_name == "mact-alice-demo"
    assert t.public_url == "https://alice-demo.tunnel.example.com"
    cfg = t.generate_config()
    assert 'customDomains = ["alice-demo.tunnel.example.com"]' in cfg
    assert 'name = "mact-alice-demo"' in cfg
    assert "transport.tls.enable = false" in cfg


def test_frpc_transport_tls_env_enables_tls(monkeypatch):
    monkeypatch.setenv("MACT_FRPC_TRANSPORT_TLS", "1")
    t = FrpcTunnel(local_port=3000, room_id="r", developer_id="d", auth_token="t")
    assert "transport.tls.enable = true" in t.generate_config()


def test_underscore_in_ids_normalized_for_dns_labels():
    """Underscores in slugs are invalid in DNS host labels; use hyphens for customDomains."""
    t = FrpcTunnel(
        local_port=3000,
        room_id="my_room",
        developer_id="dev_user",
        vhost_domain="tunnel.example.com",
        public_scheme="https",
    )
    assert t.public_url == "https://dev-user-my-room.tunnel.example.com"
    assert t.proxy_name == "mact-dev-user-my-room"
    cfg = t.generate_config()
    assert 'customDomains = ["dev-user-my-room.tunnel.example.com"]' in cfg


def test_empty_server_addr_falls_back_to_default():
    t = FrpcTunnel(
        local_port=3000,
        room_id="r",
        developer_id="d",
        server_addr="   ",
        server_port=7000,
    )
    assert 'serverAddr = "m-act.live"' in t.generate_config()


def test_empty_vhost_domain_falls_back_to_default():
    t = FrpcTunnel(
        local_port=3000,
        room_id="r",
        developer_id="d",
        vhost_domain="",
    )
    assert "tunnel.m-act.live" in t.generate_config()


def test_generate_config_contains_essentials():
    t = FrpcTunnel(
        local_port=4000,
        room_id="proj",
        developer_id="carol",
        server_addr="frp.example.com",
        server_port=7777,
        auth_token="secret123",
        vhost_domain="tunnel.example.com",
    )
    cfg = t.generate_config()
    assert 'serverAddr = "frp.example.com"' in cfg
    assert "serverPort = 7777" in cfg
    assert 'auth.method = "token"' in cfg
    assert 'auth.token = "secret123"' in cfg
    assert "localPort = 4000" in cfg
    assert "carol-proj.tunnel.example.com" in cfg
    assert 'localIP = "127.0.0.1"' in cfg


def test_generate_config_no_auth_token():
    t = FrpcTunnel(
        local_port=3000, room_id="demo", developer_id="alice", auth_token=""
    )
    cfg = t.generate_config()
    assert "auth.token" not in cfg


def test_is_running_initially_false():
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    assert t.is_running() is False


@patch(
    "mact.tunnel.frpc.ensure_frpc_executable",
    side_effect=OSError("simulated frpc unavailable"),
)
def test_start_raises_when_frpc_unavailable(mock_ensure):
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    with pytest.raises(OSError, match="simulated frpc unavailable"):
        t.start()


class _FakeFrpcStderr:
    """Minimal stderr for tests: readline() feeds lines then EOF."""

    def __init__(self, lines: list[bytes]) -> None:
        self._lines = lines
        self._i = 0

    def readline(self) -> bytes:
        if self._i < len(self._lines):
            self._i += 1
            return self._lines[self._i - 1]
        return b""


@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_fails_when_frpc_exits_immediately(mock_popen, mock_run, mock_ensure, _mock_sleep):
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = 1
    mock_proc.stdout = _FakeFrpcStderr([b"login to server failed\n"])
    mock_popen.return_value = mock_proc
    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    with pytest.raises(RuntimeError, match="frpc exited before tunnel was ready"):
        t.start()


@patch.dict(os.environ, {"MACT_SKIP_TUNNEL_HTTP_VERIFY": "1"}, clear=False)
@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_spawns_frpc(mock_popen, mock_run, mock_ensure, _mock_sleep):
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.stdout = _FakeFrpcStderr(
        [b"2025/01/01 00:00:00 [I] [mact-alice-demo] start proxy success\n"]
    )
    mock_popen.return_value = mock_proc

    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    t.start()

    assert mock_popen.called
    call_args = mock_popen.call_args
    assert "/usr/bin/frpc" in call_args[0][0][0]
    assert t.is_running() is True

    t.stop()
    mock_proc.send_signal.assert_called()


@patch.dict(
    os.environ,
    {"MACT_TUNNEL_HTTP_VERIFY_ATTEMPTS": "1", "MACT_TUNNEL_HTTP_VERIFY_STRICT": "1"},
    clear=False,
)
@patch("mact.tunnel.frpc.requests.get")
@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_raises_when_verify_sees_frp_vhost_miss(
    mock_popen, mock_run, mock_ensure, _mock_sleep, mock_get
):
    """HTTPS GET still shows frp's no-vhost page — fail with a clear RuntimeError."""
    mock_get.return_value = MagicMock(
        status_code=404,
        text="<html>Faithfully yours, frp.</html>",
    )
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.stdout = _FakeFrpcStderr(
        [b"2025/01/01 00:00:00 [I] [mact-alice-demo] start proxy success\n"]
    )
    mock_popen.return_value = mock_proc

    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    with pytest.raises(RuntimeError, match="no matching HTTP route"):
        t.start()


@patch.dict(
    os.environ,
    {
        "MACT_TUNNEL_HTTP_VERIFY_ATTEMPTS": "4",
        "MACT_TUNNEL_HTTP_VERIFY_INITIAL_DELAY_SEC": "0",
    },
    clear=False,
)
@patch("mact.tunnel.frpc.requests.get")
@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_succeeds_when_verify_frp_miss_then_ok(
    mock_popen, mock_run, mock_ensure, _mock_sleep, mock_get
):
    """Frp vhost-miss 404 can be transient; we retry before failing."""
    miss = MagicMock(status_code=404, text="<html>Faithfully yours, frp.</html>")
    ok = MagicMock(status_code=200, text="upstream ok")
    mock_get.side_effect = [miss, miss, ok]
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.stdout = _FakeFrpcStderr(
        [b"2025/01/01 00:00:00 [I] [mact-alice-demo] start proxy success\n"]
    )
    mock_popen.return_value = mock_proc

    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    t.start()
    assert t.is_running()
    assert mock_get.call_count == 3


@patch.dict(
    os.environ,
    {
        "MACT_TUNNEL_HTTP_VERIFY_ATTEMPTS": "2",
        "MACT_TUNNEL_HTTP_VERIFY_INITIAL_DELAY_SEC": "0",
    },
    clear=False,
)
@patch("mact.tunnel.frpc.requests.get")
@patch("mact.tunnel.frpc.time.sleep", autospec=True)
@patch("mact.tunnel.frpc.ensure_frpc_executable", return_value="/usr/bin/frpc")
@patch("mact.tunnel.frpc.subprocess.run")
@patch("subprocess.Popen")
def test_start_continues_when_verify_always_frp_404_soft_default(
    mock_popen, mock_run, mock_ensure, _mock_sleep, mock_get
):
    """Default (non-strict): vhost-miss does not abort start — heartbeats can register URL."""
    miss = MagicMock(status_code=404, text="<html>Faithfully yours, frp.</html>")
    mock_get.return_value = miss
    mock_run.return_value = MagicMock(returncode=0, stderr="", stdout="")
    mock_proc = MagicMock()
    mock_proc.poll.return_value = None
    mock_proc.stdout = _FakeFrpcStderr(
        [b"2025/01/01 00:00:00 [I] [mact-alice-demo] start proxy success\n"]
    )
    mock_popen.return_value = mock_proc

    t = FrpcTunnel(local_port=3000, room_id="demo", developer_id="alice")
    t.start()
    assert t.is_running()
    assert mock_get.call_count == 2
