"""Ensure deployment/frps + nginx templates stay aligned with CLI defaults."""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from mact.tunnel.constants import DEFAULT_FRPS_AUTH_TOKEN, DEFAULT_FRPS_PORT

REPO_ROOT = Path(__file__).resolve().parents[1]


def _read_frps_toml() -> str:
    path = REPO_ROOT / "deployment" / "frps" / "frps.toml"
    return path.read_text(encoding="utf-8")


def _read_nginx_conf() -> str:
    path = REPO_ROOT / "deployment" / "nginx" / "mact.live.conf"
    return path.read_text(encoding="utf-8")


def test_frps_template_token_matches_cli_default():
    """frps auth.token must match what `mact configure-frp` uses by default."""
    text = _read_frps_toml()
    m = re.search(r'auth\.token\s*=\s*"([^"]*)"', text)
    assert m is not None, "auth.token not found in deployment/frps/frps.toml"
    assert m.group(1) == DEFAULT_FRPS_AUTH_TOKEN


def test_frps_template_ports_match_constants_and_nginx_upstream():
    """bindPort 7000, vhost 8080 — nginx frps_vhost must proxy to the same vhost port."""
    text = _read_frps_toml()
    assert f"bindPort = {DEFAULT_FRPS_PORT}" in text
    assert "vhostHTTPPort = 8080" in text

    ngx = _read_nginx_conf()
    assert "upstream frps_vhost" in ngx
    assert "server 127.0.0.1:8080" in ngx
    assert "proxy_pass http://frps_vhost" in ngx


def test_nginx_tunnel_server_name_matches_vhost_domain():
    ngx = _read_nginx_conf()
    assert "server_name *.tunnel.m-act.live" in ngx


@pytest.mark.parametrize(
    "path",
    [
        REPO_ROOT / "deployment" / "frps" / "frps.toml",
        REPO_ROOT / "deployment" / "nginx" / "mact.live.conf",
    ],
)
def test_deployment_templates_exist(path: Path):
    assert path.is_file(), f"missing {path}"
