"""
End-to-end tunnel test: real frps + frpc + local HTTP server + curl vhost.

Skips unless both frps and frpc are available (PATH or third_party/frp).
This is what proves localhost tunneling works — not mocked unit tests.
"""

from __future__ import annotations

import os
import shutil
import socket
import subprocess
import tempfile
import threading
import time
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import pytest

from mact.tunnel.frpc import FrpcTunnel

PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    _, port = s.getsockname()
    s.close()
    return int(port)


def _find_frp(name: str) -> str | None:
    p = shutil.which(name)
    if p:
        return p
    cand = PROJECT_ROOT / "third_party" / "frp" / name
    if cand.is_file() and os.access(cand, os.X_OK):
        return str(cand)
    return None


@pytest.mark.integration
def test_localhost_reaches_upstream_via_frps_vhost(monkeypatch):
    """
    Full chain: frps → frpc (FrpcTunnel) → http.server → GET vhost with Host header.

    Fails if: auth mismatch, TLS mismatch, customDomains ≠ Host, or pipe/stderr issues.
    """
    monkeypatch.setenv("MACT_SKIP_TUNNEL_HTTP_VERIFY", "1")
    frps_bin = _find_frp("frps")
    frpc_bin = _find_frp("frpc")
    if not frps_bin or not frpc_bin:
        pytest.skip("need frps and frpc on PATH or under third_party/frp/")

    bind_port = _free_port()
    vhost_port = _free_port()
    upstream_port = _free_port()
    token = "mact-e2e-integration-token"
    vhost_domain = "tunnel.localtest"

    tmp = tempfile.mkdtemp(prefix="mact-frp-e2e-")
    frps_cfg = Path(tmp) / "frps.toml"
    frps_cfg.write_text(
        f'bindPort = {bind_port}\nvhostHTTPPort = {vhost_port}\nauth.token = "{token}"\n',
        encoding="utf-8",
    )

    marker = "MACT_FRP_E2E_OK_MARKER"
    (Path(tmp) / "index.html").write_text(marker, encoding="utf-8")

    def _make_handler(directory: str):
        class _H(SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs) -> None:
                super().__init__(*args, directory=directory, **kwargs)

            def log_message(self, *_args) -> None:
                pass

        return _H

    srv = ThreadingHTTPServer(
        ("127.0.0.1", upstream_port), _make_handler(tmp)
    )
    srv_thread = threading.Thread(target=srv.serve_forever, daemon=True)
    srv_thread.start()
    time.sleep(0.2)

    frps_proc = subprocess.Popen(
        [frps_bin, "-c", str(frps_cfg)],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    time.sleep(0.6)
    try:
        if frps_proc.poll() is not None:
            err = frps_proc.stderr.read() if frps_proc.stderr else b""
            pytest.fail(f"frps exited: {err.decode(errors='replace')[:2000]}")

        tunnel = FrpcTunnel(
            local_port=upstream_port,
            room_id="e2e",
            developer_id="dev",
            server_addr="127.0.0.1",
            server_port=bind_port,
            auth_token=token,
            vhost_domain=vhost_domain,
            vhost_http_port=vhost_port,
            public_scheme="http",
        )
        try:
            tunnel.start()
        except Exception as exc:
            pytest.fail(f"FrpcTunnel.start failed: {exc}")

        host = tunnel._tunnel_fqdn  # noqa: SLF001 — contract under test
        assert host == "dev-e2e.tunnel.localtest"

        out = None
        for _ in range(40):
            try:
                r = subprocess.run(
                    [
                        "curl",
                        "-sS",
                        "--max-time",
                        "2",
                        "-H",
                        f"Host: {host}",
                        f"http://127.0.0.1:{vhost_port}/",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                out = r.stdout
                if marker in (out or ""):
                    break
            except (subprocess.TimeoutExpired, OSError):
                pass
            time.sleep(0.15)

        tunnel.stop()
        snippet = repr((out or "")[:500])
        assert out is not None and marker in out, (
            f"vhost did not return upstream marker; last body: {snippet}"
        )
    finally:
        srv.shutdown()
        frps_proc.terminate()
        try:
            frps_proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            frps_proc.kill()
        shutil.rmtree(tmp, ignore_errors=True)
