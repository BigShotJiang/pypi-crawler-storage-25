"""
命令行入口点。
"""

from devlake_mcp.cli import main

if __name__ == "__main__":
    main()
