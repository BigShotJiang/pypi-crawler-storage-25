"""
DevLake MCP

AI 编程数据采集工具，提供 IDE Hooks、transcript 同步和 Context Guardian 能力。
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("devlake-mcp")
except PackageNotFoundError:
    # 开发模式下未安装包时的 fallback
    __version__ = "0.0.0.dev"
