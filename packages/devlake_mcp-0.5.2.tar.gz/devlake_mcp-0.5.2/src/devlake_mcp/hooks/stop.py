#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
创建完整的 Prompt 记录（Stop Hook）

触发时机：Claude 完成一次回复时
触发频率：每次 Claude 完成回复时触发一次

功能：
1. 从 transcript 解析用户 prompt 的完整信息（内容、提交时间、UUID等）
2. 从 transcript 解析 Claude 响应信息（tokens、工具使用、结束时间等）
3. 计算 prompt 序号
4. 一次性创建完整的 prompt 记录（包含开始和结束信息）
5. 增量更新 session 的 conversation_rounds
6. 异步执行，立即返回，不阻塞 Claude 的下一次响应
"""

import json
import logging
import sys
import os
import random
from pathlib import Path
from datetime import datetime

# 导入公共工具（使用包导入）
from devlake_mcp.hooks.hook_utils import run_async, sync_transcripts_to_server
from devlake_mcp.hooks.transcript_utils import (
    parse_latest_response,
    parse_turn_total_usage,
    extract_tools_used,
    trace_to_user_message,
    get_user_message_by_uuid,
    count_user_messages,
    convert_to_utc_plus_8,
    safe_parse_hook_input,
    _parse_context_markdown,
)
from devlake_mcp.client import DevLakeClient
from devlake_mcp.retry_queue import save_failed_upload
from devlake_mcp.generation_manager import get_current_generation_id
from devlake_mcp.error_reporter import report_error
from devlake_mcp.logging_config import configure_logging, get_log_dir
from devlake_mcp.constants import CLAUDE_HOOK_LOG_FILE

# 配置日志（启动时调用一次）
configure_logging(log_dir=get_log_dir(), log_file=CLAUDE_HOOK_LOG_FILE)
logger = logging.getLogger(__name__)


def extract_usage_data(latest_response: dict) -> dict:
    """
    从响应中提取完整的 usage 数据

    Args:
        latest_response: Claude 响应消息字典

    Returns:
        usage 数据字典，包含 input_tokens、cache tokens、output_tokens、model
    """
    usage = latest_response.get('usage', {})

    # 提取所有 token 相关数据
    usage_data = {
        'input_tokens': usage.get('input_tokens', 0),
        'output_tokens': usage.get('output_tokens', 0),
        'cache_creation_input_tokens': usage.get('cache_creation_input_tokens', 0),
        'cache_read_input_tokens': usage.get('cache_read_input_tokens', 0),
        'model': latest_response.get('model')
    }

    return usage_data


def extract_response_content(latest_response: dict) -> str:
    """
    提取响应内容的文本部分

    Args:
        latest_response: Claude 响应消息字典

    Returns:
        完整的响应内容文本
    """
    response_content = ""
    content = latest_response.get('content', [])

    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get('type') == 'text':
                text = item.get('text', '')
                response_content = text if text else ""
                break

    return response_content


def calculate_prompt_duration(user_message: dict, latest_response: dict) -> int:
    """
    计算 prompt 时长

    Args:
        user_message: 用户消息字典
        latest_response: Claude 响应消息字典

    Returns:
        时长（秒），如果计算失败返回 None
    """
    try:
        submit_time_str = user_message.get('timestamp')
        end_time_str = latest_response.get('timestamp')

        if not submit_time_str or not end_time_str:
            return None

        submit_time = datetime.fromisoformat(submit_time_str.replace('Z', '+00:00'))
        end_time = datetime.fromisoformat(end_time_str.replace('Z', '+00:00'))
        duration_delta = end_time - submit_time

        return int(duration_delta.total_seconds())
    except Exception as e:
        logger.error(f'计算 prompt 时长失败: {e}')
        return None


def _parse_etime(s: str) -> int:
    """将 ps etime 格式 [[DD-]HH:]MM:SS 转换为秒数。

    macOS/Linux 的 ps -o etime 输出此格式，不同于 Linux 专属的 etimes（纯秒数）。
    """
    s = s.strip()
    days = 0
    if '-' in s:
        day_part, s = s.split('-', 1)
        try:
            days = int(day_part)
        except ValueError:
            return 0
    parts = s.split(':')
    try:
        if len(parts) == 2:
            return days * 86400 + int(parts[0]) * 60 + int(parts[1])
        if len(parts) == 3:
            return days * 86400 + int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
    except ValueError:
        pass
    return 0


def _kill_stale_claude_p_processes() -> None:
    """检测并 kill 超过5分钟的僵死 claude -p 进程（仅限自己代码启动的）。

    判定"自己启动"的依据：命令行同时含有
      --no-session-persistence + disableAllHooks + -p
    这三个特征是 session_start / stop 内部独有的，用户手动开启的 claude 不会带这些参数。

    使用 etime 字段（[[DD-]HH:]MM:SS 格式），macOS BSD ps 和 Linux procps 均支持。
    """
    import subprocess

    if sys.platform == 'win32':
        return  # Windows 无 ps 命令

    STALE_SECONDS = 300  # 5分钟

    try:
        result = subprocess.run(
            ['ps', '-eo', 'pid,etime,command'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode != 0:
            return

        killed = []
        for line in result.stdout.splitlines()[1:]:
            parts = line.strip().split(None, 2)
            if len(parts) < 3:
                continue
            pid_str, etime_str, cmd = parts
            try:
                pid = int(pid_str)
            except ValueError:
                continue

            elapsed = _parse_etime(etime_str)
            if elapsed < STALE_SECONDS:
                continue

            # 三特征同时满足，才认为是自己代码启动的 claude -p
            cmd_tokens = cmd.split()
            is_claude_bin = any(os.path.basename(t) == 'claude' for t in cmd_tokens[:2])
            if (is_claude_bin
                    and '-p' in cmd_tokens
                    and '--no-session-persistence' in cmd_tokens
                    and 'disableAllHooks' in cmd):
                try:
                    os.kill(pid, 9)
                    killed.append(pid)
                    logger.warning(f'[Stop] kill -9 僵死 claude -p pid={pid} elapsed={elapsed}s')
                except (ProcessLookupError, PermissionError):
                    pass

        if killed:
            logger.warning(f'[Stop] 共清理 {len(killed)} 个僵死 claude -p 进程: {killed}')

    except Exception as e:
        logger.debug(f'_kill_stale_claude_p_processes 失败（忽略）: {e}')


def _update_context_cache(cwd: str) -> None:
    """按需刷新 /context 缓存（在 daemon 孙进程中同步执行，不阻塞 IDE）。

    先比对配置文件 hash，只有在 MCP / skill / memory / CLAUDE.md 等配置
    真正发生变化时才调用 claude -p /context，否则跳过，避免产生多余的 Haiku 请求。

    注意：Stop hook 本身已通过 @run_async 双重 fork 成为 daemon 进程，
    IDE 不等待该进程，因此此处直接同步执行即可，无需再套 daemon 线程。
    """
    try:
        from devlake_mcp.context_guardian.state import is_context_cache_stale, save_context_cache_with_hash
        if not is_context_cache_stale(cwd):
            logger.debug('[Stop] context cache 未过期，跳过 /context 调用')
            return

        import subprocess
        result = subprocess.run(
            ['claude', '--no-session-persistence',
             '--settings', '{"disableAllHooks": true}',
             '-p', '/context', '--output-format', 'json'],
            capture_output=True, text=True, cwd=cwd, timeout=30,
        )
        if result.returncode != 0:
            logger.debug(f'[Stop] /context 命令失败: {result.stderr[:200]}')
            return
        import json as _json
        data = _json.loads(result.stdout)
        markdown = data.get('result', '')
        snapshot = _parse_context_markdown(markdown)
        if snapshot.get('static_total_tokens', 0) > 0:
            save_context_cache_with_hash(cwd, snapshot)
            logger.info(f'[Stop] context cache 已更新 static_tokens={snapshot["static_total_tokens"]}')
    except Exception as e:
        logger.debug(f'_update_context_cache 失败（忽略）: {e}')


@run_async
def main():
    """
    Stop Hook 主逻辑

    注意：所有异常都被捕获并静默处理，确保不阻塞 Claude
    """
    try:
        # 1. 从 stdin 读取 hook 输入（使用安全解析函数）
        input_data = safe_parse_hook_input(logger)
        if not input_data:
            logger.warning('Stop Hook 无法解析输入，触发降级方案：执行 devlake-mcp sync')
            # 降级方案：触发 transcript 同步
            try:
                sync_transcripts_to_server(check_server=False)
                logger.info('✓ 降级方案执行成功：transcript 同步完成')
            except Exception as sync_err:
                logger.error(f'降级方案执行失败: {sync_err}', exc_info=True)
            return  # 解析失败，执行降级方案后返回

        session_id = input_data.get('session_id')
        transcript_path = input_data.get('transcript_path')
        permission_mode = input_data.get('permission_mode')

        logger.info(f'[Stop] 触发 session={session_id}')

        if not session_id or not transcript_path:
            logger.warning('缺少必要的 session_id 或 transcript_path')
            return

        if not os.path.exists(transcript_path):
            logger.info(f'Transcript 文件尚不存在（可能是新会话初始化）: {transcript_path}')
            return

        # 2. 解析 transcript 获取最新的 Claude 响应
        latest_response = parse_latest_response(transcript_path)
        if not latest_response:
            logger.warning('无法解析最新的 Claude 响应')
            return


        # 3. 追溯到最初的 user 消息 UUID（处理 thinking 消息链）
        parent_uuid = latest_response.get('parent_uuid')
        if not parent_uuid:
            logger.error('响应中缺少 parent_uuid')
            return

        # 使用追溯函数找到真正的 user prompt UUID
        prompt_uuid = trace_to_user_message(transcript_path, parent_uuid)
        if not prompt_uuid:
            logger.warning(f'无法追溯到 user 消息（从 {parent_uuid}），可能是工具调用等特殊情况')
            return

        # 4. 获取完整的 user 消息信息
        user_message = get_user_message_by_uuid(transcript_path, prompt_uuid)
        if not user_message:
            logger.error(f'无法获取 user 消息 (UUID: {prompt_uuid})')
            return

        # 5. 提取响应信息
        tools_used = extract_tools_used(latest_response)
        usage_data = extract_usage_data(latest_response)
        response_content = extract_response_content(latest_response)
        is_interrupted = '[Request interrupted by user]' in str(latest_response.get('content', ''))
        prompt_duration = calculate_prompt_duration(user_message, latest_response)
        prompt_sequence = count_user_messages(transcript_path)

        # 6. 检查是否有 generation_id（决定使用哪个 UUID）
        generation_id = get_current_generation_id(session_id, ide_type='claude_code')

        # 优先使用 generation_id 作为 prompt_uuid，否则使用 transcript 中的 UUID
        final_prompt_uuid = generation_id if generation_id else prompt_uuid


        # 7. 构造完整的 prompt 数据（时区转换为 UTC+8）
        prompt_data = {
            'session_id': session_id,
            'prompt_uuid': final_prompt_uuid,
            'prompt_sequence': prompt_sequence,
            'prompt_content': user_message.get('content', ''),
            'prompt_submit_time': convert_to_utc_plus_8(user_message.get('timestamp')),
            'prompt_end_time': convert_to_utc_plus_8(latest_response.get('timestamp')),
            'prompt_duration': prompt_duration,
            'response_content': response_content if response_content else None,
            'response_tokens': usage_data['output_tokens'],
            'input_tokens': usage_data['input_tokens'],
            'cache_creation_input_tokens': usage_data['cache_creation_input_tokens'],
            'cache_read_input_tokens': usage_data['cache_read_input_tokens'],
            'model': usage_data['model'],
            'tools_used': json.dumps(tools_used) if tools_used else None,
            'cwd': user_message.get('cwd'),
            'permission_mode': permission_mode or user_message.get('permission_mode'),
            'is_interrupted': 1 if is_interrupted else 0
        }

        # 8. 决定创建还是更新
        if generation_id:
            try:
                with DevLakeClient() as client:
                    client.update_prompt(generation_id, prompt_data)
                logger.info(
                    f'[Stop] Prompt 已更新 uuid={generation_id} seq={prompt_sequence} '
                    f'duration={prompt_duration}s model={usage_data["model"]} '
                    f'in={usage_data["input_tokens"]} out={usage_data["output_tokens"]}'
                )
            except Exception as e:
                logger.error(f'更新 Prompt 失败 ({generation_id}): {e}')
                save_failed_upload(
                    queue_type='prompt_update',
                    data={'prompt_uuid': generation_id, **prompt_data},
                    error=str(e)
                )

        else:
            try:
                with DevLakeClient() as client:
                    client.create_prompt(prompt_data)
                logger.info(
                    f'[Stop] Prompt 已创建 uuid={final_prompt_uuid} seq={prompt_sequence} '
                    f'duration={prompt_duration}s model={usage_data["model"]} '
                    f'in={usage_data["input_tokens"]} out={usage_data["output_tokens"]}'
                )
            except Exception as e:
                logger.error(f'创建 Prompt 失败 ({final_prompt_uuid}): {e}')
                # 上报错误到服务端
                report_error(
                    error=e,
                    hook_name='stop',
                    api_endpoint='/api/ai-coding/prompts',
                    http_method='POST',
                    ide_type='claude_code'
                )
                # 保存到本地队列（支持自动重试）
                save_failed_upload(
                    queue_type='prompt',
                    data=prompt_data,
                    error=str(e)
                )

        # 9. 增量更新 session 的 conversation_rounds
        try:
            with DevLakeClient() as client:
                client.increment_session_rounds(session_id)
            logger.info(f'[Stop] Session 轮数 +1 session={session_id}')
        except Exception as e:
            logger.error(f'更新 session 对话轮数失败 ({session_id}): {e}')
            # 更新轮数失败不影响主流程，不保存到队列

        # 10. 10% 概率同步 transcript 到服务端
        if random.random() < 0.1:
            sync_transcripts_to_server(check_server=False)

        # 11. Context Guardian：记录活动状态 + 检测模型切换
        # 使用本轮所有 assistant 消息的 usage 汇总，确保 hist 统计准确
        try:
            from devlake_mcp.context_guardian import record_activity
            turn_usage = parse_turn_total_usage(transcript_path)
            record_activity(
                session_id=session_id,
                model=turn_usage.get('model') or usage_data.get('model'),
                input_tokens=turn_usage.get('input_tokens', 0) or 0,
                cache_read=turn_usage.get('cache_read_input_tokens', 0) or 0,
                cache_creation=turn_usage.get('cache_creation_input_tokens', 0) or 0,
                output_tokens=turn_usage.get('output_tokens', 0) or 0,
            )
        except Exception as e:
            logger.debug(f'Context Guardian record_activity 忽略异常: {e}')

        # 12. 按需更新全局 /context 快照（供下次 SessionStart 修正 0 值）
        cwd = input_data.get('cwd') or os.getcwd()
        _update_context_cache(cwd)

        # 13. 清理可能假死的 claude -p 进程（仅限自己代码启动的）
        _kill_stale_claude_p_processes()

    except Exception as e:
        # 任何异常都静默失败，不阻塞 Claude
        logger.error(f'Stop Hook 执行失败: {e}', exc_info=True)
        # 上报错误到服务端
        report_error(
            error=e,
            hook_name='stop',
            ide_type='claude_code'
        )


if __name__ == '__main__':
    main()
    sys.exit(0)  # 唯一的 exit 点
