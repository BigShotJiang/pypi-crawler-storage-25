#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
用户提示词提交时记录会话信息（UserPromptSubmit Hook）

触发时机: 用户点击发送按钮后、发起后端请求之前

Claude Code 输入格式:
{
  "session_id": "abc123",
  "transcript_path": "/Users/.../.claude/projects/.../xxx.jsonl",
  "cwd": "/Users/...",
  "permission_mode": "default",
  "hook_event_name": "UserPromptSubmit",
  "prompt": "Write a function to calculate the factorial of a number"
}

功能:
1. 调用 session_manager.start_new_session() 确保会话存在
   - 直接调用 API 创建会话，后端通过幂等性处理重复请求
2. 上传用户的 prompt 内容（记录用户输入）
3. 静默退出，不阻塞用户操作

数据流:
- Session: 由 session_manager 自动管理
- Prompt: 每次用户输入 → POST /api/ai-coding/prompts

注意:
- 所有会话管理逻辑已集中到 session_manager 模块
- API 调用使用 try-except 确保不阻塞用户
- 异步执行，立即返回
"""

import sys
import os
import io
import json
import logging
from datetime import datetime

# 导入公共工具
from devlake_mcp.hooks.hook_utils import run_async
from devlake_mcp.hooks.transcript_utils import safe_parse_hook_input, get_prompt_uuid_from_transcript
from devlake_mcp.client import DevLakeClient
from devlake_mcp.git_utils import get_git_info, get_git_repo_path
from devlake_mcp.retry_queue import save_failed_upload
from devlake_mcp.session_manager import start_new_session
from devlake_mcp.generation_manager import start_generation, save_generation_id
from devlake_mcp.error_reporter import report_error
from devlake_mcp.logging_config import configure_logging, get_log_dir
from devlake_mcp.constants import CLAUDE_HOOK_LOG_FILE
from devlake_mcp.enums import IDEType
from devlake_mcp.guardian_reporter import (
    report_guardian_block,
    report_guardian_block_sync,
    save_last_block_info,
    check_and_report_override,
)

# 配置日志（启动时调用一次）
configure_logging(log_dir=get_log_dir(), log_file=CLAUDE_HOOK_LOG_FILE)
logger = logging.getLogger(__name__)

_ALLOWED_EMAIL_DOMAINS = ('e6yun.com', 'g7e6.com.cn', 'g7.com.cn')


def upload_prompt(
    session_id: str,
    prompt_content: str,
    cwd: str,
    transcript_path: str = None,
    permission_mode: str = 'default'
):
    """
    上传 Prompt 记录到 DevLake API

    Args:
        session_id: Session ID
        prompt_content: 用户输入的 prompt 文本
        cwd: 当前工作目录
        transcript_path: 转录文件路径（可选）
    """
    prompt_data = None  # 初始化，确保 except 块可访问
    try:
        # 1. 获取 Git 信息（动态 + 静态）
        git_info = get_git_info(cwd, timeout=1, include_user_info=True)
        git_author = git_info.get('git_author', 'unknown')

        # 2. 获取 Git 仓库路径
        git_repo_path = get_git_repo_path(cwd)

        # 3. 从 git_repo_path 提取 project_name
        project_name = git_repo_path.split('/')[-1] if '/' in git_repo_path else git_repo_path

        # 4. 获取 prompt_uuid（优先从 transcript 解析，降级为生成）
        if transcript_path:
            transcript_uuid = get_prompt_uuid_from_transcript(
                transcript_path=transcript_path,
                current_prompt=prompt_content,
                max_wait=3.0,
                check_interval=0.5
            )
            if transcript_uuid:
                prompt_uuid = transcript_uuid
                save_generation_id(session_id, prompt_uuid, IDEType.CLAUDE_CODE)
            else:
                prompt_uuid = start_generation(session_id, ide_type=IDEType.CLAUDE_CODE)
        else:
            prompt_uuid = start_generation(session_id, ide_type=IDEType.CLAUDE_CODE)

        with DevLakeClient() as client:
            next_seq_response = client.get('/api/ai-coding/prompts/next-sequence', params={'session_id': session_id})
            prompt_sequence = next_seq_response.get('next_sequence', 1)

            prompt_data = {
                'session_id': session_id,
                'prompt_uuid': prompt_uuid,
                'prompt_sequence': prompt_sequence,
                'prompt_content': prompt_content,
                'prompt_submit_time': datetime.now().isoformat(),
                'cwd': cwd,
                'permission_mode': permission_mode,
            }
            if transcript_path:
                prompt_data['transcript_path'] = transcript_path

            client.create_prompt(prompt_data)

        logger.info('[UserPromptSubmit] Prompt 已上传 uuid=%s seq=%s', prompt_uuid, prompt_sequence)

    except Exception as e:
        # API 调用失败，记录错误但不阻塞
        logger.error(
            f'上传 Prompt 失败 ({session_id}): '
            f'异常类型={type(e).__name__}, '
            f'错误信息={str(e)}',
            exc_info=True  # 记录完整堆栈信息
        )
        # 保存到本地队列（支持自动重试）
        if prompt_data:
            save_failed_upload(
                queue_type='prompt',
                data=prompt_data,
                error=str(e)
            )


@run_async
def main():
    """
    UserPromptSubmit Hook 主逻辑

    注意：所有异常都被捕获并静默处理，确保不阻塞 Claude
    """
    try:
        # 1. 从 stdin 读取 hook 输入（使用安全解析函数）
        input_data = safe_parse_hook_input(logger)
        if not input_data:
            return  # 解析失败，跳过处理

        # 2. 获取关键字段
        session_id = input_data.get('session_id')
        prompt_content = input_data.get('prompt', '')
        transcript_path = input_data.get('transcript_path')
        permission_mode = input_data.get('permission_mode', 'default')
        model_name = input_data.get('model')

        raw_cwd = input_data.get('cwd')
        cwd = raw_cwd or os.getcwd()

        if not session_id:
            logger.error('[UserPromptSubmit] 缺少 session_id，跳过处理')
            return

        if not prompt_content:
            logger.error('[UserPromptSubmit] 缺少 prompt 内容，跳过上传')
            return

        logger.info(f'[UserPromptSubmit] 触发 session={session_id} prompt={prompt_content[:30]}')

        # 3. 刷新 TTL 倒计时（用户发出 prompt 即代表 API 即将活跃，防止 TTL 误红）
        try:
            from devlake_mcp.context_guardian.state import touch_last_activity
            touch_last_activity(session_id)
        except Exception:
            pass

        # 4. 会话管理（确保会话存在，依赖后端幂等性）
        try:
            start_new_session(
                session_id=session_id,
                cwd=cwd,
                ide_type=IDEType.CLAUDE_CODE,
                model_name=model_name
            )
        except Exception as e:
            logger.error(f'会话创建失败: {e}')
            # 上报错误到服务端
            report_error(
                error=e,
                hook_name='user_prompt_submit',
                api_endpoint='/api/ai-coding/sessions',
                http_method='POST',
                ide_type='claude_code'
            )

        # 5. 上传 prompt（记录用户输入）
        try:
            upload_prompt(
                session_id=session_id,
                prompt_content=prompt_content,
                cwd=cwd,
                transcript_path=transcript_path,
                permission_mode=permission_mode
            )
        except Exception as e:
            logger.error(f'上传 prompt 失败: {e}')
            # 上报错误到服务端
            report_error(
                error=e,
                hook_name='user_prompt_submit',
                api_endpoint='/api/ai-coding/prompts',
                http_method='POST',
                ide_type='claude_code'
            )

    except Exception as e:
        # 任何异常都静默失败（不阻塞用户）
        logger.error(f'UserPromptSubmit Hook 执行失败: {e}', exc_info=True)
        # 上报错误到服务端
        report_error(
            error=e,
            hook_name='user_prompt_submit',
            ide_type='claude_code'
        )


def validate_git_email_sync() -> bool:
    """
    同步校验 git_email 域名（在 main() 之前执行）

    注意：
    - 使用当前工作目录检查 git 配置，不读取 stdin
    - 这样避免消耗 stdin，确保 main() 可以正常读取

    Returns:
        True: 验证通过
        False: 验证失败（会输出错误到 stderr 并 exit 2）
    """
    try:
        # 1. 使用当前工作目录（不读取 stdin，避免消耗输入流）
        cwd = os.getcwd()

        git_info = get_git_info(cwd)
        git_email = git_info.get('git_email', 'unknown')
        # 3. 检查邮箱域名是否符合要求
        email_valid = False
        if git_email and git_email != 'unknown' and '@' in git_email:
            email_domain = git_email.split('@')[-1].lower()
            email_valid = email_domain in _ALLOWED_EMAIL_DOMAINS

        if not email_valid:
            error_msg = (
                f'\n⚠️  DevLake 邮箱校验失败\n'
                f'   当前 git_email: {git_email} 不是允许的邮箱配置\n'
                f'   允许的域名: {", ".join(_ALLOWED_EMAIL_DOMAINS)}\n'
                f'\n'
                f'   请使用以下命令修改:\n'
                f'   git config --global user.email "your_name@e6yun.com"\n'
            )
            # UserPromptSubmit hook 中 exit code 2 会阻止 prompt 处理，并清空提示
            # 参考: https://code.claude.com/docs/en/hooks.md#exit-code-2-behavior
            sys.stderr.write(error_msg)
            sys.stderr.flush()
            logger.warning(f'[UserPromptSubmit] 邮箱域名校验失败 {git_email}')
            # 同步上报 email_invalid（exit(2) 后 daemon thread 不会继续）
            try:
                report_guardian_block_sync(
                    session_id='',  # email 校验时 stdin 还未读取，session_id 不可用
                    block_kind='email_invalid',
                    user_email=git_email,
                    cwd=cwd,
                )
            except Exception:
                pass
            sys.exit(2)

        logger.debug(f'[UserPromptSubmit] 邮箱校验通过 {git_email}')
        return True

    except SystemExit:
        # 重新抛出 sys.exit() 调用
        raise
    except Exception as e:
        # 校验过程出错，记录日志但不阻止（降级处理）
        logger.warning(f'[UserPromptSubmit] 邮箱校验出错已跳过: {e}')
        return True


def check_and_inject_context_tokens(input_data: dict) -> None:
    """
    Context Guardian 入口：按阈值决策，组合静态开销 / Opus 切换 / Idle 阻塞。

    - DEVLAKE_GUARDIAN_ENABLED=false 时：静默放行
    - 仅 block 有输出；非 block 场景静默放行
    """
    from devlake_mcp.context_guardian import evaluate_prompt_submit, should_guard

    if not should_guard():
        return

    session_id = input_data.get('session_id', '')
    transcript_path = input_data.get('transcript_path')

    try:
        decision = evaluate_prompt_submit(
            session_id,
            transcript_path,
            current_model=input_data.get('model'),
        )
    except Exception as e:
        logger.warning(f'Context Guardian 决策失败（放行）: {e}')
        return

    if decision is None:
        return

    output = {}
    if decision.should_block:
        output['decision'] = 'block'
        output['reason'] = decision.reason
        logger.info(f'[UserPromptSubmit] guardian 拦截: {decision.reason[:60]}')
        # 上报 block 事件并持久化，供下次回填 was_overridden
        try:
            cwd = input_data.get('cwd', '')
            git_info = {}
            try:
                from devlake_mcp.git_utils import get_git_info, get_git_repo_path
                git_info = get_git_info(cwd, timeout=1)
            except Exception:
                pass
            git_repo = (git_info.get('git_repo_path') or '').split('/')[-1]
            block_id = report_guardian_block_sync(
                session_id=session_id,
                block_kind=decision.block_kind,
                context_tokens=decision.context_tokens,
                config_threshold=decision.config_threshold,
                current_model=decision.current_model,
                prev_model=decision.prev_model,
                idle_minutes=decision.idle_minutes,
                git_repo=git_repo,
                cwd=cwd,
                user_email=git_info.get('git_email', ''),
            )
            save_last_block_info(
                session_id=session_id,
                block_id=block_id,
                prompt_content=input_data.get('prompt', ''),
            )
        except Exception as e:
            logger.debug('Guardian block 上报失败（静默）: %s', e)

    print(json.dumps(output, ensure_ascii=False))
    sys.stdout.flush()

    if decision.should_block:
        sys.exit(0)


if __name__ == '__main__':
    # 1. 同步校验 git_email（在异步处理前执行，不消耗 stdin）
    validate_git_email_sync()

    # 2. 读取 stdin（只读一次，后续逻辑复用）
    raw_input = sys.stdin.read()
    try:
        input_data = json.loads(raw_input)
    except Exception:
        input_data = {}

    # 3. 检测是否重发了上次被 block 的 prompt（was_overridden 回填）
    _session_id = input_data.get('session_id', '')
    _prompt = input_data.get('prompt', '')
    if _session_id and _prompt:
        try:
            check_and_report_override(_session_id, _prompt)
        except Exception:
            pass

    # 4. 注入 context token 信息并 block（同步，必须在 fork 前）
    # 将 stdin 内容写回，供后续 safe_parse_hook_input 使用
    sys.stdin = io.StringIO(raw_input)
    check_and_inject_context_tokens(input_data)

    # 5. 异步执行主逻辑
    main()
    sys.exit(0)  # 唯一的 exit 点
