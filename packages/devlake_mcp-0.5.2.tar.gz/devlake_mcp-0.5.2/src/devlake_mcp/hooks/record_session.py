#!/usr/bin/env python3
# backward-compat shim - 已迁移到 devlake_mcp.hooks.session_end
# 保留此文件是为了兼容已配置旧路径的用户，未来大版本中将删除
from devlake_mcp.hooks.session_end import main  # noqa: F401

if __name__ == '__main__':
    main()
