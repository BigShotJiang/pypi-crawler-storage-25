#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
会话启动时记录会话信息（SessionStart Hook）

功能：
1. 读取 stdin 后立即启动后台进程，父进程返回 0 不阻塞 Claude Code
2. 后台进程切断继承的 stdin/stdout/stderr（防止 Claude Code 等待管道关闭）
3. 后台进程完成 session 创建
4. 错误只写日志，不影响 IDE 响应速度

注意：
- 使用 start_new_session 而非 check_and_switch_session
- SessionStart = 强制新建，UserPromptSubmit = 智能判断
- 即使 SessionStart 未触发，UserPromptSubmit 也会创建 session（容错）

@author wangzhong
"""

# 父进程只需要标准库，不加载任何重度依赖
import io
import os
import sys

from devlake_mcp.hooks.hook_utils import consume_async_stdin_file, run_raw_stdin_async



def _run_async(raw_stdin: str) -> None:
    """子进程中执行的所有实际逻辑。所有重度 import 放在这里，不影响父进程启动速度。"""
    import logging
    from datetime import datetime
    from pathlib import Path

    from devlake_mcp.enums import IDEType
    from devlake_mcp.session_manager import start_new_session
    from devlake_mcp.generation_manager import cleanup_old_generation_files
    from devlake_mcp.logging_config import configure_logging, get_log_dir
    from devlake_mcp.hooks.transcript_utils import safe_parse_hook_input
    from devlake_mcp.constants import CLAUDE_HOOK_LOG_FILE
    from devlake_mcp.client import (
        DevLakeAPIError,
        DevLakeConnectionError,
        DevLakeTimeoutError,
        DevLakeAuthError,
    )
    from devlake_mcp.retry_queue import save_failed_upload
    from devlake_mcp.error_reporter import report_error

    configure_logging(log_dir=get_log_dir(), log_file=CLAUDE_HOOK_LOG_FILE)
    logger = logging.getLogger(__name__)

    # 恢复 stdin 供 safe_parse_hook_input 使用
    sys.stdin = io.StringIO(raw_stdin)

    def collect_context_tokens(session_id: str, cwd: str) -> None:
        """从上次 Stop 留下的缓存中恢复静态快照，不再调用 /context。

        /context 在 SessionStart 时必然返回 0（Claude Code 新会话 bug），
        改为由 Stop hook 在配置变化时按需刷新缓存，SessionStart 直接复用。
        """
        try:
            from devlake_mcp.context_guardian.state import load_context_cache, write_static_snapshot
            cache = load_context_cache(cwd)
            if not cache:
                logger.debug('[SessionStart] 无 context cache，静态快照将在首次 Stop 后建立')
                return

            snapshot = {
                'session_id': session_id,
                'cwd': cwd,
                'collected_at': datetime.now().isoformat(),
                'summary': cache.get('summary', {}),
                'mcp_tools': cache.get('mcp_tools', {}),
                'skills': cache.get('skills', {}),
                'memory_files': cache.get('memory_files', {}),
                'static_total_tokens': cache.get('static_total_tokens', 0),
            }
            write_static_snapshot(session_id, snapshot)
            logger.debug(
                f'[SessionStart] guardian 静态快照已从缓存恢复 '
                f'static_tokens={snapshot["static_total_tokens"]}'
            )
        except Exception as e:
            logger.warning(f'collect_context_tokens 失败（不影响主流程）: {e}')

    session_id = None
    cwd = None

    try:
        try:
            cleanup_old_generation_files(max_age_days=7)
        except Exception as e:
            logger.warning(f'清理历史文件失败: {e}')

        input_data = safe_parse_hook_input(logger)
        if not input_data:
            logger.error('无法解析 hook 输入数据')
            return

        session_id = input_data.get('session_id')
        if not session_id:
            logger.warning('缺少 session_id')
            return

        logger.info(f'[SessionStart] 触发 session={session_id}')

        raw_cwd = input_data.get('cwd')
        cwd = raw_cwd or os.getcwd()
        model_name = input_data.get('model')

        import threading
        from devlake_mcp.context_guardian.key_rate import fetch_and_cache_key_rate

        session_errors = []

        def _upload_session():
            try:
                start_new_session(
                    session_id=session_id,
                    cwd=cwd,
                    ide_type=IDEType.CLAUDE_CODE,
                    model_name=model_name
                )
            except Exception as e:
                session_errors.append(e)

        def _fetch_key_rate():
            try:
                fetch_and_cache_key_rate()
            except Exception as e:
                logger.debug(f'key_rate 预取失败（忽略）: {e}')

        t_guardian = threading.Thread(
            target=collect_context_tokens,
            kwargs={'session_id': session_id, 'cwd': cwd},
            daemon=True,
        )
        t_session = threading.Thread(target=_upload_session, daemon=True)
        t_key_rate = threading.Thread(target=_fetch_key_rate, daemon=True)

        t_guardian.start()
        t_session.start()
        t_key_rate.start()
        t_guardian.join()
        t_session.join()
        t_key_rate.join(timeout=4)

        if session_errors:
            raise session_errors[0]

        logger.info(f'[SessionStart] 完成 session={session_id}')

    except DevLakeAuthError as e:
        logger.error(f'DevLake 认证失败: {e}', exc_info=True)
        report_error(error=e, hook_name='session_start',
                     api_endpoint='/api/ai-coding/sessions', http_method='POST', ide_type='claude_code')

    except (DevLakeConnectionError, DevLakeTimeoutError) as e:
        logger.warning(f'DevLake 网络错误（会话数据将延迟上传）: {e}')
        report_error(error=e, hook_name='session_start',
                     api_endpoint='/api/ai-coding/sessions', http_method='POST', ide_type='claude_code')
        if session_id and cwd:
            save_failed_upload(queue_type='session',
                               data={'session_id': session_id, 'cwd': cwd, 'ide_type': 'claude_code'},
                               error=str(e))

    except DevLakeAPIError as e:
        logger.error(f'DevLake API 错误: {e}', exc_info=True)
        report_error(error=e, hook_name='session_start',
                     api_endpoint='/api/ai-coding/sessions', http_method='POST', ide_type='claude_code')
        if session_id and cwd:
            save_failed_upload(queue_type='session',
                               data={'session_id': session_id, 'cwd': cwd, 'ide_type': 'claude_code'},
                               error=str(e))

    except Exception as e:
        logger.error(f'SessionStart Hook 执行失败: {e}', exc_info=True)
        report_error(error=e, hook_name='session_start', ide_type='claude_code')


def main():
    """
    SessionStart Hook 入口。

    流程：
    1. 父进程读取 stdin（管道只能读一次）
    2. 后台执行实际工作，父进程立即返回
    3. Windows 通过临时文件把 stdin 传给后台子进程
    """
    raw_stdin = consume_async_stdin_file()
    if raw_stdin:
        _run_async(raw_stdin)
        return

    try:
        raw_stdin = sys.stdin.read()
    except Exception:
        raw_stdin = ''

    run_raw_stdin_async(raw_stdin, _run_async)


if __name__ == '__main__':
    main()
    sys.exit(0)
