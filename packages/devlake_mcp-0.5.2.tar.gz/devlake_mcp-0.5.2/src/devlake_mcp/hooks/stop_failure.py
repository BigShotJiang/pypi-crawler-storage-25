#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
记录 Claude Code API 错误（StopFailure Hook）

触发时机：Claude 本轮因为 API 错误结束，且不会触发 Stop Hook。

功能：
1. 将错误类型、详情和 Claude Code 展示的错误文本写回当前 prompt
2. 补齐 prompt_end_time，避免失败轮次长期显示为未结束
3. 失败时写入本地重试队列，不影响 Claude Code 使用
"""

import logging
import sys
from datetime import datetime
from typing import Optional

from devlake_mcp.client import DevLakeClient
from devlake_mcp.constants import CLAUDE_HOOK_LOG_FILE
from devlake_mcp.enums import IDEType
from devlake_mcp.error_reporter import report_error
from devlake_mcp.generation_manager import get_current_generation_id
from devlake_mcp.hooks.hook_utils import run_async
from devlake_mcp.hooks.transcript_utils import (
    get_latest_user_message_uuid,
    safe_parse_hook_input,
)
from devlake_mcp.logging_config import configure_logging, get_log_dir
from devlake_mcp.retry_queue import save_failed_upload


configure_logging(log_dir=get_log_dir(), log_file=CLAUDE_HOOK_LOG_FILE)
logger = logging.getLogger(__name__)

MAX_ERROR_MESSAGE_LENGTH = 4000


def _truncate(value: Optional[str], max_length: int = MAX_ERROR_MESSAGE_LENGTH) -> str:
    """限制错误文本长度，避免单次 API 错误写入过大的字段。"""
    text = "" if value is None else str(value).strip()
    if len(text) <= max_length:
        return text
    return text[: max_length - 20] + "\n...<truncated>"


def build_error_message(
    error: Optional[str],
    error_details: Optional[str],
    last_assistant_message: Optional[str],
) -> str:
    """构造写入 ai_coding_prompt.error_message 的可读错误文本。"""
    parts = [f"error={error or 'unknown'}"]

    if error_details:
        parts.append(f"error_details={error_details}")

    if last_assistant_message:
        parts.append(f"last_assistant_message={last_assistant_message}")

    return _truncate("\n".join(parts))


def resolve_prompt_uuid(session_id: str, transcript_path: Optional[str]) -> Optional[str]:
    """
    定位 StopFailure 对应的 prompt_uuid。

    优先使用 UserPromptSubmit 保存的 generation_id；如果状态文件不存在，
    再降级从 transcript 取最新用户消息 UUID。
    """
    prompt_uuid = get_current_generation_id(session_id, ide_type=IDEType.CLAUDE_CODE)
    if prompt_uuid:
        return prompt_uuid

    if transcript_path:
        return get_latest_user_message_uuid(transcript_path)

    return None


def build_prompt_update(input_data: dict) -> dict:
    """从 StopFailure 输入构造 prompt PATCH 数据。"""
    last_assistant_message = input_data.get("last_assistant_message")
    model = input_data.get("model")
    error = input_data.get("error")

    patch_data = {
        "prompt_end_time": datetime.now().isoformat(),
        "error_message": build_error_message(
            error,
            input_data.get("error_details"),
            last_assistant_message,
        ),
        "response_content": last_assistant_message or None,
        "is_interrupted": 0,
    }

    if model:
        patch_data["model"] = model
    if error:
        patch_data["error_type"] = error

    return patch_data


def record_stop_failure(input_data: dict) -> bool:
    """将 StopFailure 错误写回服务端 prompt 记录。"""
    session_id = input_data.get("session_id")
    transcript_path = input_data.get("transcript_path")

    if not session_id:
        logger.warning("StopFailure 缺少 session_id，跳过")
        return False

    prompt_uuid = resolve_prompt_uuid(session_id, transcript_path)
    if not prompt_uuid:
        logger.warning("StopFailure 无法定位 prompt_uuid，跳过")
        return False

    patch_data = build_prompt_update(input_data)
    logger.info(
        "准备记录 StopFailure: session=%s, prompt=%s, error=%s",
        session_id,
        prompt_uuid,
        input_data.get("error") or "unknown",
    )

    try:
        with DevLakeClient() as client:
            client.update_prompt(prompt_uuid, patch_data)
            try:
                client.increment_session_rounds(session_id)
            except Exception as e:
                logger.debug("StopFailure 更新 session 轮数失败（忽略）: %s", e)

        logger.info("StopFailure 已写入 prompt: %s", prompt_uuid)
        return True
    except Exception as e:
        logger.error("StopFailure 写入 prompt 失败 (%s): %s", prompt_uuid, e, exc_info=True)
        save_failed_upload(
            queue_type="prompt_update",
            data={"prompt_uuid": prompt_uuid, **patch_data},
            error=str(e),
        )
        report_error(
            error=e,
            hook_name="stop_failure",
            api_endpoint="/api/ai-coding/prompts",
            http_method="PATCH",
            ide_type="claude_code",
        )
        return False


@run_async
def main():
    """StopFailure Hook 主入口。"""
    try:
        input_data = safe_parse_hook_input(logger)
        if not input_data:
            return

        hook_event_name = input_data.get("hook_event_name")
        if hook_event_name and hook_event_name != "StopFailure":
            logger.debug("忽略非 StopFailure 事件: %s", hook_event_name)
            return

        logger.info(
            "[StopFailure] 触发 session=%s, error=%s",
            input_data.get("session_id", "unknown"),
            input_data.get("error", "unknown"),
        )
        record_stop_failure(input_data)
    except Exception as e:
        logger.error("StopFailure Hook 执行失败: %s", e, exc_info=True)
        report_error(error=e, hook_name="stop_failure", ide_type="claude_code")


if __name__ == "__main__":
    main()
    sys.exit(0)
