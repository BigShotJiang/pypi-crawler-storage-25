#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Claude Code Hooks 公共工具模块

提供跨 hooks 脚本的通用功能：
- 错误日志记录
- 本地队列保存（降级方案）
- 统一的 logging 配置
- 异步执行包装

注意：临时目录等通用功能已移至 devlake_mcp.utils，避免重复代码
"""

import os
import sys
import json
import logging
import subprocess
import tempfile
from pathlib import Path
from datetime import datetime
from typing import Callable

# 导入通用工具函数（避免代码重复）
from devlake_mcp.utils import get_data_dir, get_temp_file_path
# 注意：hook_utils 是基础模块，不导入其他 hooks 模块以避免循环依赖


# 模块级 logger（Python logging 有 lastResort 机制，无需手动配置）
logger = logging.getLogger(__name__)


def save_to_local_queue(queue_name: str, data: dict):
    """
    保存数据到本地队列（降级方案）

    用于 API 上传失败时的备份，后续可通过定时脚本重试上传

    Args:
        queue_name: 队列名称（如 'failed_session_uploads'）
        data: 要保存的数据字典

    文件格式:
        ~/.devlake/{queue_name}/{timestamp}.json
    """
    try:
        queue_dir = get_data_dir(persistent=True) / queue_name
        queue_dir.mkdir(parents=True, exist_ok=True)

        # 使用时间戳作为文件名，确保唯一性
        filename = f"{int(datetime.now().timestamp() * 1000)}.json"
        queue_file = queue_dir / filename

        with open(queue_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        # 记录失败，不影响主流程（Python logging 会自动输出到 stderr）
        logger.error(
            f"Failed to save to local queue '{queue_name}': {e}",
            exc_info=True
        )


def cleanup_old_files(directory: str, max_age_hours: int = 24):
    """
    清理指定目录中的过期文件

    Args:
        directory: 目录名称（相对于持久化数据目录）
        max_age_hours: 最大保留时间（小时）

    示例:
        cleanup_old_files('failed_session_uploads', max_age_hours=168)  # 7天
    """
    try:
        target_dir = get_data_dir(persistent=True) / directory
        if not target_dir.exists():
            return

        now = datetime.now().timestamp()
        max_age_seconds = max_age_hours * 3600

        for file in target_dir.iterdir():
            if file.is_file():
                file_age = now - file.stat().st_mtime
                if file_age > max_age_seconds:
                    file.unlink()
    except Exception as e:
        # 记录失败，不影响主流程（Python logging 会自动输出到 stderr）
        logger.error(
            f"Failed to cleanup old files in '{directory}': {e}",
            exc_info=True
        )


__all__ = [
    'save_to_local_queue',
    'cleanup_old_files',
    'run_async',
    'run_raw_stdin_async',
    'consume_async_stdin_file',
    'sync_transcripts_to_server',
]


def consume_async_stdin_file(env_var: str = 'DEVLAKE_ASYNC_STDIN_FILE') -> str:
    """
    读取由 run_raw_stdin_async 写入临时文件的 stdin 内容。

    Windows 后台子进程会重新启动当前脚本，stdin 已被重定向到 DEVNULL，
    因此需要通过环境变量指向的临时文件恢复原始 hook 输入。
    """
    stdin_file = os.environ.pop(env_var, '')
    if not stdin_file:
        return ''

    try:
        with open(stdin_file, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception:
        return ''
    finally:
        try:
            os.remove(stdin_file)
        except Exception:
            pass


def run_raw_stdin_async(
    raw_stdin: str,
    func: Callable[[str], None],
    env_var: str = 'DEVLAKE_ASYNC_STDIN_FILE',
) -> None:
    """
    使用已读取的 stdin 内容跨平台后台执行 hook 主逻辑。

    Unix/macOS 使用 fork + setsid + stdio 重定向；Windows 使用 Popen
    重新启动当前脚本，并通过临时文件传递 stdin 内容。
    """
    if sys.platform == 'win32' or not hasattr(os, 'fork'):
        _run_raw_stdin_async_windows(raw_stdin, func, env_var)
        return

    try:
        pid = os.fork()
    except OSError:
        # fork 失败时降级为同步执行，保证 hook 逻辑仍有机会完成。
        func(raw_stdin)
        return

    if pid > 0:
        sys.exit(0)

    try:
        os.setsid()
    except OSError:
        pass

    try:
        devnull = os.open(os.devnull, os.O_RDWR)
        os.dup2(devnull, 0)
        os.dup2(devnull, 1)
        os.dup2(devnull, 2)
        if devnull > 2:
            os.close(devnull)
    except OSError:
        pass

    try:
        func(raw_stdin)
    finally:
        os._exit(0)


def _run_raw_stdin_async_windows(
    raw_stdin: str,
    func: Callable[[str], None],
    env_var: str,
) -> None:
    """Windows/no-fork 平台上的 raw stdin 后台执行实现。"""
    try:
        fd, stdin_file = tempfile.mkstemp(suffix='.json', prefix='devlake_hook_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(raw_stdin)
    except Exception:
        func(raw_stdin)
        return

    env = os.environ.copy()
    env[env_var] = stdin_file

    try:
        popen_kwargs = {
            'stdin': subprocess.DEVNULL,
            'stdout': subprocess.DEVNULL,
            'stderr': subprocess.DEVNULL,
            'env': env,
        }
        if sys.platform == 'win32':
            popen_kwargs['creationflags'] = (
                getattr(subprocess, 'DETACHED_PROCESS', 0)
                | getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)
            )
        subprocess.Popen([sys.executable] + sys.argv, **popen_kwargs)
    except Exception:
        try:
            os.remove(stdin_file)
        except Exception:
            pass
        func(raw_stdin)
        return

    sys.exit(0)


def run_async(func: Callable):
    """
    异步执行装饰器，让 hook 立即返回，后台执行任务

    原理（标准的双重 fork daemon 化）：
    1. 第一次 fork：创建子进程，父进程立即退出
    2. setsid()：子进程创建新会话，脱离控制终端
    3. 第二次 fork：创建孙进程，第一个子进程退出
    4. 孙进程（真正的 daemon）执行实际工作

    为什么需要双重 fork？
    - 单次 fork：子进程仍在父进程的会话中，可能被 Claude Code 等待
    - setsid()：创建新会话，但子进程成为 session leader
    - 第二次 fork：确保孙进程不是 session leader，完全独立

    参考：Stevens "Advanced Programming in the UNIX Environment"

    使用方法：
        @run_async
        def main():
            # 你的 hook 逻辑
            pass

        if __name__ == '__main__':
            main()

    优点：
    - hook 0 延迟，不阻塞 Claude 响应（即使 API 超时 10 秒）
    - 完全脱离父进程会话，不会被等待
    - API 调用慢或失败不影响用户体验
    - Windows 上等价实现：Popen + DETACHED_PROCESS，父进程立即退出

    注意：
    - 只在 Unix-like 系统（macOS/Linux）使用 fork
    - Windows 使用 subprocess.Popen + DETACHED_PROCESS 实现等价的后台执行
    """
    def wrapper(*args, **kwargs):
        # 检查是否支持 fork（Unix-like 系统）
        if sys.platform == 'win32' or not hasattr(os, 'fork'):
            _run_async_windows(func, *args, **kwargs)
            return

        # === 第一次 fork ===
        try:
            pid = os.fork()
        except OSError:
            # fork 失败，降级为同步执行
            func(*args, **kwargs)
            _check_and_retry_uploads()
            return

        if pid > 0:
            # 父进程：立即退出（返回给 Claude Code）
            os._exit(0)

        # === 第一个子进程 ===
        try:
            # 创建新会话，脱离控制终端
            # 此时子进程成为 session leader
            os.setsid()
        except OSError:
            # setsid 失败，退出
            os._exit(1)

        # === 第二次 fork ===
        try:
            pid = os.fork()
        except OSError:
            # fork 失败，退出
            os._exit(1)

        if pid > 0:
            # 第一个子进程：退出
            # 让孙进程被 init 进程接管
            os._exit(0)

        # === 孙进程（真正的 daemon）===
        try:
            # 1. 读取 stdin 内容（在关闭文件描述符之前）
            from io import StringIO
            try:
                stdin_content = sys.stdin.read()
            except Exception:
                stdin_content = ''

            # 2. 关闭并重定向标准文件描述符（关键！）
            # 这是 daemon 化的必要步骤，确保 subprocess.run 不会等待
            sys.stdout.flush()
            sys.stderr.flush()

            # 关闭标准输入/输出/错误的文件描述符
            os.close(0)  # stdin
            os.close(1)  # stdout
            os.close(2)  # stderr

            # 重新打开到 /dev/null 或日志文件
            # stdin -> /dev/null
            os.open(os.devnull, os.O_RDONLY)  # 返回 fd 0

            # stdout 和 stderr -> 保留日志功能
            # 注意：由于我们已经配置了 logging 到文件，这里重定向到 /dev/null 不影响日志
            os.open(os.devnull, os.O_WRONLY)  # 返回 fd 1 (stdout)
            os.open(os.devnull, os.O_WRONLY)  # 返回 fd 2 (stderr)

            # 3. 用 StringIO 替换 Python 的 sys.stdin（让代码能正常读取）
            sys.stdin = StringIO(stdin_content)

            # 4. 执行主 hook 逻辑
            func(*args, **kwargs)

            # 5. 检查并重试失败的上传记录（非阻塞）
            _check_and_retry_uploads()

            # daemon 正常退出
            os._exit(0)
        except Exception:
            # daemon 异常退出
            os._exit(1)

    return wrapper


def _run_async_windows(func: Callable, *args, **kwargs):
    """
    Windows 上的异步执行实现。

    原理：
    1. 父进程先读完 stdin，写入临时文件
    2. 用 subprocess.Popen + DETACHED_PROCESS 重新启动当前脚本
    3. 通过环境变量 DEVLAKE_ASYNC_STDIN_FILE 告知子进程读临时文件
    4. 父进程立即 sys.exit(0)，IDE 不再等待
    5. 子进程读临时文件执行逻辑，完成后删除临时文件

    注意：子进程检测到 DEVLAKE_ASYNC_STDIN_FILE 时会跳过再次 fork，直接同步执行。
    """
    # 如果已经是子进程（由本函数启动），直接同步执行
    if os.environ.get('DEVLAKE_ASYNC_STDIN_FILE'):
        stdin_file = os.environ['DEVLAKE_ASYNC_STDIN_FILE']
        try:
            with open(stdin_file, 'r', encoding='utf-8') as f:
                stdin_content = f.read()
        except Exception:
            stdin_content = ''
        finally:
            try:
                os.remove(stdin_file)
            except Exception:
                pass

        from io import StringIO
        sys.stdin = StringIO(stdin_content)
        func(*args, **kwargs)
        _check_and_retry_uploads()
        return

    # 父进程：读 stdin，启动后台子进程，立即退出
    try:
        stdin_content = sys.stdin.read()
    except Exception:
        stdin_content = ''

    # 把 stdin 内容写到临时文件
    try:
        fd, stdin_file = tempfile.mkstemp(suffix='.json', prefix='devlake_hook_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(stdin_content)
    except Exception:
        # 临时文件创建失败，降级为同步执行
        from io import StringIO
        sys.stdin = StringIO(stdin_content)
        func(*args, **kwargs)
        _check_and_retry_uploads()
        return

    env = os.environ.copy()
    env['DEVLAKE_ASYNC_STDIN_FILE'] = stdin_file

    try:
        subprocess.Popen(
            [sys.executable] + sys.argv,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=env,
            creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
        )
    except Exception:
        # Popen 失败，降级为同步执行（临时文件已存在，直接读）
        try:
            with open(stdin_file, 'r', encoding='utf-8') as f:
                stdin_content = f.read()
            os.remove(stdin_file)
        except Exception:
            pass
        from io import StringIO
        sys.stdin = StringIO(stdin_content)
        func(*args, **kwargs)
        _check_and_retry_uploads()
        return

    sys.exit(0)


def _check_and_retry_uploads():
    """
    检查并重试失败的上传记录（内部函数）

    说明：
    - 每次 Hook 执行时自动调用
    - 非阻塞，快速返回（默认最多重试3条记录）
    - 静默失败，不影响主流程
    """
    try:
        # 延迟导入，避免循环依赖
        from devlake_mcp.retry_queue import retry_failed_uploads, get_retry_config

        # 检查是否启用重试
        config = get_retry_config()
        if not config.get('check_on_hook', True):
            return

        # 执行重试（限制单次最多3条，避免阻塞）
        retry_failed_uploads(max_parallel=3)

    except Exception as e:
        # 静默失败，不影响主流程
        logger.debug(f"重试检查失败（不影响主流程）: {e}")


def sync_transcripts_to_server(check_server: bool = False):
    """
    同步本地 transcript 到服务端（用于 Hook 中静默执行）

    说明：
    - 扫描本地 transcript 文件，检查是否需要上传
    - check_server=True 时会向服务端确认是否已存在
    - 静默失败，不影响主流程

    Args:
        check_server: 是否向服务端检查（默认 False
    """
    try:
        # 延迟导入，避免循环依赖
        from devlake_mcp.transcript_cache import TranscriptCache
        from devlake_mcp.transcript_scanner import scan_local_transcripts
        from devlake_mcp.client import DevLakeClient

        logger.debug("开始同步 transcript 到服务端...")

        cache = TranscriptCache()
        with DevLakeClient() as client:
            report = scan_local_transcripts(
                cache=cache,
                client=client,
                check_server=check_server,
                force=False,
                dry_run=False,
            )

        logger.debug(
            f"Transcript 同步完成: "
            f"扫描={report.total_scanned}, "
            f"上传={report.uploaded_success}, "
            f"跳过(缓存)={report.skipped_cached}, "
            f"失败={report.uploaded_failed}"
        )

    except Exception as e:
        # 静默失败，不影响主流程
        logger.debug(f"Transcript 同步失败（不影响主流程）: {e}")
