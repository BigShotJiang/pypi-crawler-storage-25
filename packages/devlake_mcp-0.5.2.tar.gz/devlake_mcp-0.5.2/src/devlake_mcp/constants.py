#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DevLake MCP 常量配置

集中管理所有魔法值，提高代码可维护性。
"""

import os
from typing import Set

# ============================================================================
# Git 配置
# ============================================================================

# Git 命令超时时间（秒）
# Windows 上进程启动较慢，1 秒可能不够
GIT_COMMAND_TIMEOUT: int = int(os.getenv('DEVLAKE_GIT_TIMEOUT', '3'))


# ============================================================================
# 文件过滤配置
# ============================================================================

# 敏感文件模式（包含这些关键词的文件不采集）
SENSITIVE_FILE_PATTERNS: list[str] = [
    '.env',
    '.env.',           # .env.local, .env.production 等
    '.secret',
    '.secrets',
    '.key',
    '.pem',
    '.crt',
    '.p12',
    '.pfx',
    'credentials',
    'password',
    '.npmrc',          # npm 配置
    '.pypirc',         # PyPI 配置
    'id_rsa',          # SSH 私钥
    'id_dsa',
    'id_ecdsa',
    'id_ed25519',
]

# 敏感目录（这些目录下的文件不采集）
SENSITIVE_DIRS: list[str] = [
    '.ssh',
    '.gnupg',
    '.aws',
    '.azure',
    '.config',
    'node_modules',    # 前端依赖
    '.venv',           # Python 虚拟环境
    'venv',
    '__pycache__',
    '.git',            # Git 元数据
]

# 二进制文件扩展名（这些文件不采集）
BINARY_FILE_EXTENSIONS: Set[str] = {
    # 图片
    '.png', '.jpg', '.jpeg', '.gif', '.bmp', '.ico', '.svg', '.webp',
    # 压缩包
    '.zip', '.tar', '.gz', '.bz2', '.rar', '.7z', '.xz',
    # 文档
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
    # 可执行文件
    '.exe', '.dll', '.so', '.dylib', '.app', '.dmg',
    # 编译产物
    '.class', '.pyc', '.pyo', '.o', '.a', '.jar',
    # 音视频
    '.mp3', '.mp4', '.avi', '.mov', '.wav', '.flac',
    # 字体
    '.ttf', '.otf', '.woff', '.woff2', '.eot',
}


# ============================================================================
# API 配置
# ============================================================================

# API 请求超时时间（秒）
API_REQUEST_TIMEOUT: int = 15

# API 默认基础 URL
DEFAULT_API_BASE_URL: str = "http://devlake.test.chinawayltd.com"

# 最大内容大小（字节）- 10MB
MAX_CONTENT_SIZE: int = 10 * 1024 * 1024


# ============================================================================
# 临时文件配置
# ============================================================================

# 临时文件最大保留时间（小时）
TEMP_FILE_MAX_AGE_HOURS: int = 24

# 临时目录默认名称
TEMP_DIR_NAME: str = 'devlake_mcp'


# ============================================================================
# Hooks 配置
# ============================================================================

# Hook 执行超时时间（秒）
HOOK_EXECUTION_TIMEOUT: int = 15

# Hook 日志统一目录（~/.devlake/logs/）
DEVLAKE_LOG_DIR: str = '~/.devlake/logs'

# 各 IDE 对应的日志文件名
CLAUDE_HOOK_LOG_FILE: str = 'claude_hooks.log'
CURSOR_HOOK_LOG_FILE: str = 'cursor_hooks.log'
CODEX_HOOK_LOG_FILE: str = 'codex_hooks.log'

# 默认 IDE 类型
DEFAULT_IDE_TYPE: str = 'claude_code'

# 默认模型名称
DEFAULT_MODEL_NAME: str = 'claude-sonnet-4-6'


# ============================================================================
# Generation 配置
# ============================================================================

# Generation 状态文件名
GENERATION_STATE_FILE_NAME: str = 'generation_state.json'

# Generation 状态最大保留时间（小时）- 超过此时间的状态可以被清理
GENERATION_STATE_MAX_AGE_HOURS: int = 24


# ============================================================================
# Transcript 压缩配置
# ============================================================================

# Transcript 压缩阈值（字节）- 超过此大小才进行压缩
# 1MB = 1 * 1024 * 1024 bytes * 0.5
TRANSCRIPT_COMPRESSION_THRESHOLD: int = 1 * 1024 * 1024 * 0.5

# Transcript 压缩算法
TRANSCRIPT_COMPRESSION_ALGORITHM: str = 'gzip'


# ============================================================================
# 日志配置
# ============================================================================

# 日志级别映射（字符串 -> logging 常量）
VALID_LOG_LEVELS: dict[str, int] = {
    'DEBUG': 10,     # logging.DEBUG
    'INFO': 20,      # logging.INFO
    'WARNING': 30,   # logging.WARNING
    'ERROR': 40,     # logging.ERROR
    'CRITICAL': 50,  # logging.CRITICAL
}

# 默认日志级别
DEFAULT_LOG_LEVEL: str = 'INFO'


# ============================================================================
# 动态配置函数（支持环境变量覆盖）
# ============================================================================

def get_hook_timeout() -> int:
    """
    获取 Hook 执行超时时间（秒）

    环境变量：DEVLAKE_HOOK_TIMEOUT（默认 15 秒）

    Returns:
        int: Hook 执行超时时间（秒）
    """
    return int(os.getenv('DEVLAKE_HOOK_TIMEOUT', str(HOOK_EXECUTION_TIMEOUT)))


def get_http_retry_count() -> int:
    """
    获取 HTTP 请求重试次数

    环境变量：DEVLAKE_HTTP_RETRY_COUNT（默认 1 次）

    Returns:
        int: HTTP 请求失败后的重试次数
    """
    return int(os.getenv('DEVLAKE_HTTP_RETRY_COUNT', '1'))


# ============================================================================
# Transcript 缓存配置
# ============================================================================

# Transcript 缓存文件路径（默认 ~/.devlake/transcript_cache.json）
TRANSCRIPT_CACHE_DIR_NAME: str = '.devlake'
TRANSCRIPT_CACHE_FILE_NAME: str = 'transcript_cache.json'

# Transcript 缓存保留天数（默认 30 天）
TRANSCRIPT_CACHE_RETENTION_DAYS: int = 30

# 僵尸会话阈值（小时）- 超过此时间未结束的会话将被上传
ZOMBIE_SESSION_HOURS: int = 24

# Transcript 上传来源枚举
UPLOAD_SOURCE_AUTO: str = 'auto'  # SessionEnd hook 自动上传
UPLOAD_SOURCE_AUTO_BACKFILL: str = 'auto_backfill'  # 自动后补（僵尸会话）
UPLOAD_SOURCE_MANUAL: str = 'manual'  # 手动执行 sync 命令

# Claude Code projects 目录模式
CLAUDE_PROJECTS_DIR_PATTERN: str = '~/.claude/projects*'

# Codex sessions 目录（~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl）
CODEX_SESSIONS_DIR: str = '~/.codex/sessions'

# Cursor projects 目录（~/.cursor/projects/<workspace-hash>/agent-transcripts/*.jsonl）
CURSOR_PROJECTS_DIR: str = '~/.cursor/projects'
CURSOR_TRANSCRIPT_SUBDIR: str = 'agent-transcripts'

# 排除的 transcript 文件名前缀
EXCLUDED_TRANSCRIPT_PREFIX: str = 'agent-'


def get_auto_scan_enabled() -> bool:
    """
    获取是否启用自动扫描 transcript

    环境变量：DEVLAKE_AUTO_SCAN_ENABLED（默认 True）

    Returns:
        bool: 是否在 UserPromptSubmit hook 中自动扫描并上传 transcript
    """
    value = os.getenv('DEVLAKE_AUTO_SCAN_ENABLED', 'true').lower()
    return value in ('true', '1', 'yes', 'on')


def get_transcript_cache_retention_days() -> int:
    """
    获取 Transcript 缓存保留天数

    环境变量：DEVLAKE_CACHE_RETENTION_DAYS（默认 30 天）

    Returns:
        int: 缓存保留天数
    """
    return int(os.getenv('DEVLAKE_CACHE_RETENTION_DAYS', str(TRANSCRIPT_CACHE_RETENTION_DAYS)))


def get_zombie_session_hours() -> int:
    """
    获取僵尸会话阈值（小时）

    环境变量：DEVLAKE_ZOMBIE_SESSION_HOURS（默认 24 小时）

    Returns:
        int: 僵尸会话阈值（小时）
    """
    return int(os.getenv('DEVLAKE_ZOMBIE_SESSION_HOURS', str(ZOMBIE_SESSION_HOURS)))


# ============================================================================
# 错误上报配置
# ============================================================================

# 错误上报开关（默认开启）
ERROR_REPORT_ENABLED: bool = True

# 错误采样率（0.0 ~ 1.0，默认 100%）
ERROR_SAMPLE_RATE: float = 1.0

# 错误上报超时（秒，默认 3 秒，快速失败）
ERROR_REPORT_TIMEOUT: int = 3


def get_error_report_enabled() -> bool:
    """
    获取错误上报开关

    环境变量：DEVLAKE_ERROR_REPORT_ENABLED（默认 true）

    Returns:
        bool: 是否启用错误上报
    """
    value = os.getenv('DEVLAKE_ERROR_REPORT_ENABLED', 'true').lower()
    return value in ('true', '1', 'yes', 'on')


def get_error_sample_rate() -> float:
    """
    获取错误采样率

    环境变量：DEVLAKE_ERROR_SAMPLE_RATE（默认 1.0，即 100%）

    Returns:
        float: 采样率 (0.0 ~ 1.0)
    """
    try:
        rate = float(os.getenv('DEVLAKE_ERROR_SAMPLE_RATE', str(ERROR_SAMPLE_RATE)))
        # 限制在 0.0 ~ 1.0 之间
        return max(0.0, min(1.0, rate))
    except ValueError:
        return ERROR_SAMPLE_RATE


def get_error_report_timeout() -> int:
    """
    获取错误上报超时时间（秒）

    环境变量：DEVLAKE_ERROR_REPORT_TIMEOUT（默认 3 秒）

    Returns:
        int: 超时时间（秒）
    """
    return int(os.getenv('DEVLAKE_ERROR_REPORT_TIMEOUT', str(ERROR_REPORT_TIMEOUT)))


# ============================================================================
# Context Guardian 配置
# ============================================================================

# 静态上下文 token 阻塞阈值（decision:block + 重发）
GUARDIAN_DEFAULT_BLOCK_TOKENS: int = 60_000

# 空闲提示的 token 门槛（小于此值不提示，避免新会话干扰）
GUARDIAN_DEFAULT_IDLE_TOKENS: int = 250_000

# Opus 模型下的空闲 token 门槛（Opus cache 更贵，阈值更低）
GUARDIAN_DEFAULT_OPUS_IDLE_TOKENS: int = 180_000

# 同一会话内 idle 最多提示次数
GUARDIAN_MAX_IDLE_WARNINGS: int = 2

# 模型名识别为 Opus 的子字符串（大小写不敏感）
GUARDIAN_OPUS_MODEL_SUBSTRINGS = ('opus',)

# Opus 切换告警的最小上下文阈值（last_total_tokens 低于此值时不提示）
# cache 创建成本 ≈ 读成本 × 10，20K 对应 200K 等效读成本，值得提示
GUARDIAN_DEFAULT_OPUS_MIN_TOKENS: int = 180_000

# Guardian 文件统一存放在 ~/.devlake/guardian/ 子目录，与其他 devlake 文件隔离
GUARDIAN_SUBDIR: str = 'guardian'

# hooks 专属状态文件（Stop / UserPromptSubmit / SessionStart 写入）
GUARDIAN_STATE_FILENAME_TEMPLATE: str = 'state_{session_id}.json'

# statusLine 专属运行时文件（statusLine 每次轮询更新）
GUARDIAN_RUNTIME_FILENAME_TEMPLATE: str = 'runtime_{session_id}.json'

# 状态文件 schema 版本（用于未来升级）
GUARDIAN_STATE_SCHEMA_VERSION: int = 1

# model_history 最多保留条数
GUARDIAN_MODEL_HISTORY_MAX: int = 8

# 状态文件保留天数（session_start 清理时使用）
GUARDIAN_STATE_MAX_AGE_DAYS: int = 7

# Status Line 默认刷新间隔（秒）
# 设置为 3 秒以实时展示 token、成本、速率限制等动态数据
GUARDIAN_STATUSLINE_REFRESH_INTERVAL: int = 3

# Status Line 执行超时（秒，兜底）
GUARDIAN_STATUSLINE_TIMEOUT: int = 2


def get_guardian_enabled() -> bool:
    """Context Guardian 总开关。环境变量：DEVLAKE_GUARDIAN_ENABLED（默认 true）。"""
    value = os.getenv('DEVLAKE_GUARDIAN_ENABLED', 'true').lower()
    return value in ('true', '1', 'yes', 'on')


def get_prompt_cache_ttl_seconds() -> int:
    """返回 prompt cache TTL（秒）。ENABLE_PROMPT_CACHING_1H=1/true 时为 3600，否则 300。"""
    value = os.getenv('ENABLE_PROMPT_CACHING_1H', '').lower()
    return 3600 if value in ('1', 'true', 'yes', 'on') else 300


def get_guardian_block_tokens() -> int:
    """阻塞阈值（tokens）。环境变量：DEVLAKE_GUARDIAN_BLOCK_TOKENS（默认 60000）。"""
    try:
        return int(os.getenv('DEVLAKE_GUARDIAN_BLOCK_TOKENS', str(GUARDIAN_DEFAULT_BLOCK_TOKENS)))
    except ValueError:
        return GUARDIAN_DEFAULT_BLOCK_TOKENS


def get_guardian_idle_tokens() -> int:
    """空闲触发 token 门槛。环境变量：DEVLAKE_GUARDIAN_IDLE_TOKENS（默认 20000）。"""
    try:
        return int(os.getenv('DEVLAKE_GUARDIAN_IDLE_TOKENS', str(GUARDIAN_DEFAULT_IDLE_TOKENS)))
    except ValueError:
        return GUARDIAN_DEFAULT_IDLE_TOKENS


def get_guardian_opus_idle_tokens() -> int:
    """Opus 模型下的空闲 token 门槛。环境变量：DEVLAKE_GUARDIAN_OPUS_IDLE_TOKENS（默认 180000）。"""
    try:
        return int(os.getenv('DEVLAKE_GUARDIAN_OPUS_IDLE_TOKENS', str(GUARDIAN_DEFAULT_OPUS_IDLE_TOKENS)))
    except ValueError:
        return GUARDIAN_DEFAULT_OPUS_IDLE_TOKENS


def get_guardian_opus_warn() -> bool:
    """Opus 切换告警开关。环境变量：DEVLAKE_GUARDIAN_OPUS_WARN（默认 true）。"""
    value = os.getenv('DEVLAKE_GUARDIAN_OPUS_WARN', 'true').lower()
    return value in ('true', '1', 'yes', 'on')


def get_guardian_opus_always() -> bool:
    """Opus 每次切换都告警。环境变量：DEVLAKE_GUARDIAN_OPUS_ALWAYS（默认 false）。"""
    value = os.getenv('DEVLAKE_GUARDIAN_OPUS_ALWAYS', 'false').lower()
    return value in ('true', '1', 'yes', 'on')


def get_guardian_opus_min_tokens() -> int:
    """Opus 切换告警的最小上下文阈值。环境变量：DEVLAKE_GUARDIAN_OPUS_MIN_TOKENS（默认 20000）。

    last_total_tokens 低于此值时不提示，避免新会话/上下文很少时打扰。
    """
    try:
        return int(os.getenv('DEVLAKE_GUARDIAN_OPUS_MIN_TOKENS', str(GUARDIAN_DEFAULT_OPUS_MIN_TOKENS)))
    except ValueError:
        return GUARDIAN_DEFAULT_OPUS_MIN_TOKENS


def get_guardian_statusline_enabled() -> bool:
    """Status Line 开关。环境变量：DEVLAKE_GUARDIAN_STATUSLINE（默认 true）。"""
    value = os.getenv('DEVLAKE_GUARDIAN_STATUSLINE', 'true').lower()
    return value in ('true', '1', 'yes', 'on')
