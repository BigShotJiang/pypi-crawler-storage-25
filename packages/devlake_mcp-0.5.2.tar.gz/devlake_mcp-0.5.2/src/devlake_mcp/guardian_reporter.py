#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Context Guardian 阻止事件上报模块

功能：
1. 上报 4 类 block 事件（static_block / opus_switch / idle / email_invalid）
2. 本地持久化 last_block 信息，用于下次 UserPromptSubmit 时回填 was_overridden
3. 检测"重发同一条消息"行为并回填 was_overridden

设计原则：
- 异步发送（daemon thread），不阻塞 hook 主流程
- email_invalid 提供同步版本（因 exit(2) 后子进程不会继续）
- 静默失败：上报失败只记日志，不抛出
- 防循环：不在上报失败时再次上报

@author wangzhong
"""

import hashlib
import json
import logging
import os
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

import requests

from devlake_mcp.constants import DEFAULT_API_BASE_URL
from devlake_mcp.context_guardian.state import UTC_PLUS_8, _now_iso
from devlake_mcp.version_utils import get_devlake_mcp_version

logger = logging.getLogger(__name__)

_REPORT_TIMEOUT = 3  # 秒
_OVERRIDE_WINDOW_SECONDS = 300  # 5 分钟内重发视为绕过


def _get_base_url() -> str:
    return os.getenv("DEVLAKE_BASE_URL", DEFAULT_API_BASE_URL)


def _hash_value(value: str) -> str:
    """SHA256 前8位脱敏"""
    if not value:
        return "unknown"
    return hashlib.sha256(value.encode()).hexdigest()[:8]


def _last_block_path(session_id: str) -> Path:
    """last_block 持久化文件路径"""
    state_dir = Path.home() / ".devlake" / "guardian"
    state_dir.mkdir(parents=True, exist_ok=True)
    return state_dir / f"last_block_{session_id}.json"


def _build_payload(
    block_id: str,
    session_id: str,
    block_kind: str,
    context_tokens: Optional[int],
    config_threshold: Optional[int],
    current_model: Optional[str],
    prev_model: Optional[str],
    idle_minutes: Optional[float],
    git_repo: str,
    cwd: str,
    user_email: str,
    ide_type: str,
) -> dict:
    return {
        "block_id": block_id,
        "session_id": session_id,
        "block_kind": block_kind,
        "blocked_at": _now_iso(),
        "context_tokens": context_tokens,
        "config_threshold": config_threshold,
        "current_model": current_model,
        "prev_model": prev_model,
        "idle_minutes": round(idle_minutes, 2) if idle_minutes is not None else None,
        "git_repo": git_repo,
        "cwd_hash": _hash_value(cwd),
        "user_hash": _hash_value(user_email),
        "ide_type": ide_type,
        "client_version": get_devlake_mcp_version(),
    }


def _send_block(payload: dict) -> None:
    """实际发送上报请求（在 daemon thread 中执行）"""
    try:
        url = f"{_get_base_url()}/api/ai-coding/guardian-blocks"
        response = requests.post(
            url,
            json=payload,
            timeout=_REPORT_TIMEOUT,
            headers={"Content-Type": "application/json"},
        )
        if response.status_code in (200, 201):
            logger.debug("Guardian block 上报成功: %s", payload.get("block_id"))
        else:
            logger.debug("Guardian block 上报失败: HTTP %s", response.status_code)
    except Exception as e:
        logger.debug("Guardian block 上报请求失败（静默）: %s", e)


def _send_override_patch(block_id: str, override_at: str) -> None:
    """回填 was_overridden=true（在 daemon thread 中执行）"""
    try:
        url = f"{_get_base_url()}/api/ai-coding/guardian-blocks/{block_id}"
        response = requests.patch(
            url,
            json={"was_overridden": True, "override_at": override_at},
            timeout=_REPORT_TIMEOUT,
            headers={"Content-Type": "application/json"},
        )
        if response.status_code == 200:
            logger.debug("Guardian block override 回填成功: %s", block_id)
        else:
            logger.debug("Guardian block override 回填失败: HTTP %s", response.status_code)
    except Exception as e:
        logger.debug("Guardian block override 回填请求失败（静默）: %s", e)


def _run_in_background(target, *args) -> None:
    """用 daemon thread 跨平台提交后台任务，失败时静默降级。"""
    try:
        thread = threading.Thread(target=target, args=args, daemon=True)
        thread.start()
    except Exception as e:
        logger.debug("Guardian 后台任务启动失败（静默）: %s", e)


def save_last_block_info(
    session_id: str,
    block_id: str,
    prompt_content: str,
) -> None:
    """
    持久化本次 block 信息，供下次 UserPromptSubmit 判断 was_overridden。
    失败静默。
    """
    try:
        data = {
            "block_id": block_id,
            "prompt_content": prompt_content,
            "blocked_at": _now_iso(),
        }
        path = _last_block_path(session_id)
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        logger.debug("保存 last_block_info 失败（静默）: %s", e)


def _load_last_block_info(session_id: str) -> Optional[dict]:
    """读取上次 block 信息，读完后删除文件。"""
    path = _last_block_path(session_id)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data
    except Exception as e:
        logger.debug("读取 last_block_info 失败: %s", e)
        return None
    finally:
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass


def report_guardian_block(
    session_id: str,
    block_kind: str,
    context_tokens: Optional[int] = None,
    config_threshold: Optional[int] = None,
    current_model: Optional[str] = None,
    prev_model: Optional[str] = None,
    idle_minutes: Optional[float] = None,
    git_repo: str = "",
    cwd: str = "",
    user_email: str = "",
    ide_type: str = "claude_code",
) -> str:
    """
    异步上报一次 Guardian block 事件。

    Returns:
        block_id（UUID），调用方用来调用 save_last_block_info
    """
    block_id = str(uuid.uuid4())
    payload = _build_payload(
        block_id=block_id,
        session_id=session_id,
        block_kind=block_kind,
        context_tokens=context_tokens,
        config_threshold=config_threshold,
        current_model=current_model,
        prev_model=prev_model,
        idle_minutes=idle_minutes,
        git_repo=git_repo,
        cwd=cwd,
        user_email=user_email,
        ide_type=ide_type,
    )
    _run_in_background(_send_block, payload)
    logger.debug("Guardian block 上报已提交: kind=%s block_id=%s", block_kind, block_id)
    return block_id


def report_guardian_block_sync(
    session_id: str,
    block_kind: str,
    context_tokens: Optional[int] = None,
    config_threshold: Optional[int] = None,
    current_model: Optional[str] = None,
    prev_model: Optional[str] = None,
    idle_minutes: Optional[float] = None,
    git_repo: str = "",
    cwd: str = "",
    user_email: str = "",
    ide_type: str = "claude_code",
) -> str:
    """
    同步上报 Guardian block 事件（进程退出前调用，daemon thread 不会继续执行）。

    Returns:
        block_id（UUID）
    """
    block_id = str(uuid.uuid4())
    payload = _build_payload(
        block_id=block_id,
        session_id=session_id,
        block_kind=block_kind,
        context_tokens=context_tokens,
        config_threshold=config_threshold,
        current_model=current_model,
        prev_model=prev_model,
        idle_minutes=idle_minutes,
        git_repo=git_repo,
        cwd=cwd,
        user_email=user_email,
        ide_type=ide_type,
    )
    _send_block(payload)
    return block_id


def check_and_report_override(
    session_id: str,
    current_prompt: str,
) -> None:
    """
    在 UserPromptSubmit 入口处调用：检测是否重发了上次被 block 的 prompt，
    若是则异步回填 was_overridden=true 到服务端。

    无论是否 override，都会清除本地 last_block 文件。
    """
    info = _load_last_block_info(session_id)
    if not info:
        return

    block_id = info.get("block_id")
    prev_prompt = info.get("prompt_content", "")
    blocked_at_str = info.get("blocked_at", "")

    if not block_id:
        return

    # 判断是否在时间窗口内重发
    try:
        blocked_at = datetime.fromisoformat(blocked_at_str)
        now = datetime.now(UTC_PLUS_8)
        elapsed = (now - blocked_at).total_seconds()
    except Exception:
        elapsed = _OVERRIDE_WINDOW_SECONDS + 1  # 无法解析则视为超时

    is_same_prompt = current_prompt.strip() == prev_prompt.strip()
    within_window = elapsed <= _OVERRIDE_WINDOW_SECONDS

    if is_same_prompt and within_window:
        override_at = _now_iso()
        _run_in_background(_send_override_patch, block_id, override_at)
        logger.info(
            "检测到 Guardian block 被绕过（重发同一 prompt）: block_id=%s elapsed=%.0fs",
            block_id,
            elapsed,
        )
    else:
        logger.debug(
            "Guardian block 未被绕过: same_prompt=%s within_window=%s elapsed=%.0fs",
            is_same_prompt,
            within_window,
            elapsed,
        )
