"""
兼容性检测模块

提供 Python 版本检测和功能可用性检查。
当前项目只保留 IDE Hooks / transcript 同步等采集能力，不再内置 MCP Server。
"""

import sys

# 检测 Python 版本
PYTHON_VERSION = sys.version_info


def get_version_info() -> dict:
    """
    获取版本和功能支持信息

    Returns:
        dict: {
            "python_version": "3.10.19",
            "python_version_tuple": (3, 10, 19),
            "features": {
                "hooks": True,
                "transcript_sync": True,
                "context_guardian": True,
            },
            "recommended_action": "..."  # 推荐操作
        }
    """
    python_version_str = f"{PYTHON_VERSION.major}.{PYTHON_VERSION.minor}.{PYTHON_VERSION.micro}"

    return {
        "python_version": python_version_str,
        "python_version_tuple": (PYTHON_VERSION.major, PYTHON_VERSION.minor, PYTHON_VERSION.micro),
        "features": {
            "hooks": True,
            "transcript_sync": True,
            "context_guardian": True,
        },
        "recommended_action": "✓ 所有功能可用",
    }


def get_compatibility_warnings() -> list[str]:
    """
    获取兼容性警告信息

    Returns:
        list[str]: 警告信息列表
    """
    return []


def print_compatibility_info(verbose: bool = False):
    """
    打印兼容性信息

    Args:
        verbose: 是否显示详细信息
    """
    info = get_version_info()

    print("=" * 60)
    print("DevLake MCP - 版本信息")
    print("=" * 60)
    print(f"Python 版本: {info['python_version']}")
    print("✓ Hooks 模式: 可用")
    print("✓ Transcript 同步: 可用")
    print("✓ Context Guardian: 可用")
    print()

    # 显示警告
    warnings_list = get_compatibility_warnings()
    if warnings_list:
        print("注意事项:")
        for warning in warnings_list:
            print(f"  {warning}")
        print()

    # 显示推荐操作
    print(f"建议: {info['recommended_action']}")
    print("=" * 60)

    if verbose:
        print("\n功能详情:")
        print(f"  - Hooks 模式: {'✓' if info['features']['hooks'] else '✗'}")
        print(f"  - Transcript 同步: {'✓' if info['features']['transcript_sync'] else '✗'}")
        print(f"  - Context Guardian: {'✓' if info['features']['context_guardian'] else '✗'}")
        print()
