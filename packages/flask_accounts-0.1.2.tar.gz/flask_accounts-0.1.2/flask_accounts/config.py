# DO NOT COMMIT REAL SECRETS TO GIT

class Config:
    # Flask
    SECRET_KEY = "change-me-to-a-random-secret-key"

    # PostgreSQL
    DB_HOST = "localhost"
    DB_NAME = "accountdb"
    DB_USER = "accountuser"
    DB_PASSWORD = "mypassword"

    # SMTP (used later when you want real email sending)
    SMTP_HOST = "smtp.gmail.com"
    SMTP_PORT = 587
    SMTP_USERNAME = "youremail@gmail.com"
    SMTP_PASSWORD = "your_app_password"
    SMTP_FROM_EMAIL = "youremail@gmail.com"

    # Other useful configurations
    LOGIN_REDIRECT = "url"
    LOGIN_BANNER = "Welcome Back!!"
    REGISTER_BANNER = "Create Account"
    REGISTER_BANNER_MSG = "Register to get started"
    CSS_STYLE_FILE = ""

    # Dev mode:
    # True  -> print verification code in terminal instead of sending email
    # False -> actually send email through SMTP
    USE_TERMINAL_EMAIL = True