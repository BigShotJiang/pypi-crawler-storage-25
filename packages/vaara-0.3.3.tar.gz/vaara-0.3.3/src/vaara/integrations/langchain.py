"""LangChain integration — Vaara as a tool-calling callback handler.

LangChain's callback system fires events for every tool invocation.
This integration intercepts those events, scores them through Vaara's
pipeline, and blocks high-risk actions before they execute.

Two integration patterns:

1. **CallbackHandler** (recommended) — automatic, intercepts all tool calls:

    from vaara.integrations.langchain import VaaraCallbackHandler
    from vaara.pipeline import InterceptionPipeline

    pipeline = InterceptionPipeline()
    handler = VaaraCallbackHandler(pipeline, agent_id="my-agent")

    agent = create_react_agent(llm, tools)
    result = agent.invoke(
        {"messages": [("user", "...")]},
        config={"callbacks": [handler]},
    )

2. **Tool wrapper** — wraps individual tools for fine-grained control:

    from vaara.integrations.langchain import vaara_wrap_tool

    safe_tool = vaara_wrap_tool(dangerous_tool, pipeline, agent_id="my-agent")

Both patterns produce the same audit trail and risk scoring.

Requires: langchain-core >= 0.2 (not a hard dependency — imported at runtime)
"""

from __future__ import annotations

import logging
from typing import Any, Optional, Union
from uuid import UUID

from vaara.pipeline import InterceptionPipeline

logger = logging.getLogger(__name__)


class VaaraCallbackHandler:
    """LangChain callback handler that intercepts tool calls via Vaara.

    Implements the LangChain BaseCallbackHandler protocol without importing
    it — duck typing is sufficient and avoids a hard dependency.

    On tool_start:
      - Classifies the tool call through Vaara's taxonomy
      - Scores risk with conformal prediction interval
      - If DENY: raises ToolExecutionBlocked (LangChain will catch it)
      - If ESCALATE: raises ToolExecutionEscalated (agent can retry or stop)
      - If ALLOW: proceeds normally, records in audit trail

    On tool_end:
      - Reports successful outcome (severity 0.0) to close the feedback loop

    On tool_error:
      - Reports error outcome (severity configurable) to the scorer
    """

    def __init__(
        self,
        pipeline: InterceptionPipeline,
        agent_id: str = "langchain-agent",
        session_id: str = "",
        error_severity: float = 0.3,
        block_on_escalate: bool = False,
    ) -> None:
        """
        Args:
            pipeline: The Vaara interception pipeline.
            agent_id: Identifier for this agent instance.
            session_id: Session identifier for grouping actions.
            error_severity: Default outcome severity for tool errors (0.0-1.0).
            block_on_escalate: If True, escalated actions are also blocked.
        """
        self.pipeline = pipeline
        self.agent_id = agent_id
        self.session_id = session_id
        self.error_severity = error_severity
        self.block_on_escalate = block_on_escalate
        self._pending: dict[str, str] = {}  # run_id → action_id

    # ── LangChain callback protocol ──────────────────────────────

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[list[str]] = None,
        metadata: Optional[dict[str, Any]] = None,
        inputs: Optional[dict[str, Any]] = None,
        **kwargs: Any,
    ) -> None:
        """Intercept tool call before execution."""
        tool_name = serialized.get("name", "unknown_tool")

        # Build parameters from available sources
        parameters = {}
        if inputs:
            parameters = dict(inputs)
        elif input_str:
            parameters = {"input": input_str}

        result = self.pipeline.intercept(
            agent_id=self.agent_id,
            tool_name=tool_name,
            parameters=parameters,
            context={
                "framework": "langchain",
                "tags": tags or [],
                "metadata": metadata or {},
            },
            session_id=self.session_id,
            parent_action_id=str(parent_run_id) if parent_run_id else None,
        )

        # Store action_id for outcome reporting
        self._pending[str(run_id)] = result.action_id

        if not result.allowed:
            if result.decision == "deny":
                raise ToolExecutionBlocked(
                    tool_name=tool_name,
                    action_id=result.action_id,
                    risk_score=result.risk_score,
                    risk_interval=result.risk_interval,
                    reason=result.reason,
                )
            elif result.decision == "escalate" and self.block_on_escalate:
                raise ToolExecutionEscalated(
                    tool_name=tool_name,
                    action_id=result.action_id,
                    risk_score=result.risk_score,
                    risk_interval=result.risk_interval,
                    reason=result.reason,
                )

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Report successful tool execution."""
        action_id = self._pending.pop(str(run_id), None)
        if action_id:
            self.pipeline.report_outcome(
                action_id=action_id,
                outcome_severity=0.0,
                description="Tool completed successfully",
            )

    def on_tool_error(
        self,
        error: Union[Exception, KeyboardInterrupt],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> None:
        """Report tool execution error."""
        action_id = self._pending.pop(str(run_id), None)
        if action_id:
            self.pipeline.report_outcome(
                action_id=action_id,
                outcome_severity=self.error_severity,
                description=f"Tool error: {error}",
            )

    # Unused callbacks — must exist for protocol compliance
    def on_llm_start(self, *args, **kwargs): pass
    def on_llm_end(self, *args, **kwargs): pass
    def on_llm_error(self, *args, **kwargs): pass
    def on_chain_start(self, *args, **kwargs): pass
    def on_chain_end(self, *args, **kwargs): pass
    def on_chain_error(self, *args, **kwargs): pass
    def on_agent_action(self, *args, **kwargs): pass
    def on_agent_finish(self, *args, **kwargs): pass


# ── Tool wrapper ──────────────────────────────────────────────────────────

def vaara_wrap_tool(
    tool: Any,
    pipeline: InterceptionPipeline,
    agent_id: str = "langchain-agent",
    block_on_escalate: bool = False,
) -> Any:
    """Wrap a LangChain tool with Vaara interception.

    Returns a new tool that checks Vaara before executing.
    Works with both @tool functions and BaseTool subclasses.

    Example::

        from langchain_core.tools import tool
        from vaara.integrations.langchain import vaara_wrap_tool

        @tool
        def send_email(to: str, body: str) -> str:
            '''Send an email.'''
            return do_send(to, body)

        safe_email = vaara_wrap_tool(send_email, pipeline)
    """
    original_run = tool._run if hasattr(tool, "_run") else tool.func

    def wrapped_run(*args, **kwargs):
        result = pipeline.intercept(
            agent_id=agent_id,
            tool_name=getattr(tool, "name", str(tool)),
            parameters=kwargs or {"args": args},
            context={"framework": "langchain", "wrapper": True},
        )

        if result.decision == "deny":
            raise ToolExecutionBlocked(
                tool_name=getattr(tool, "name", str(tool)),
                action_id=result.action_id,
                risk_score=result.risk_score,
                risk_interval=result.risk_interval,
                reason=result.reason,
            )
        if result.decision == "escalate" and block_on_escalate:
            raise ToolExecutionEscalated(
                tool_name=getattr(tool, "name", str(tool)),
                action_id=result.action_id,
                risk_score=result.risk_score,
                risk_interval=result.risk_interval,
                reason=result.reason,
            )

        try:
            output = original_run(*args, **kwargs)
            pipeline.report_outcome(result.action_id, 0.0)
            return output
        except Exception as e:
            pipeline.report_outcome(result.action_id, 0.3, str(e))
            raise

    if hasattr(tool, "_run"):
        tool._run = wrapped_run
    elif hasattr(tool, "func"):
        tool.func = wrapped_run
    return tool


# ── Exceptions ────────────────────────────────────────────────────────────

class VaaraInterceptionError(Exception):
    """Base exception for Vaara interception events."""
    def __init__(
        self,
        tool_name: str,
        action_id: str,
        risk_score: float,
        risk_interval: tuple[float, float],
        reason: str,
    ):
        self.tool_name = tool_name
        self.action_id = action_id
        self.risk_score = risk_score
        self.risk_interval = risk_interval
        self.reason = reason
        super().__init__(reason)


class ToolExecutionBlocked(VaaraInterceptionError):
    """Raised when Vaara blocks a tool call due to high risk."""
    pass


class ToolExecutionEscalated(VaaraInterceptionError):
    """Raised when Vaara escalates a tool call for human review."""
    pass
