from __future__ import annotations

import sys
from pathlib import Path


def _ensure_sdk_on_path() -> None:
    cli_repo_root = Path(__file__).resolve().parents[1]
    cli_src = cli_repo_root / "src"
    sdk_src = cli_repo_root.parent / "python-sdk" / "src"
    if cli_src.exists():
        sys.path.insert(0, str(cli_src))
    if sdk_src.exists():
        sys.path.insert(0, str(sdk_src))


_ensure_sdk_on_path()
