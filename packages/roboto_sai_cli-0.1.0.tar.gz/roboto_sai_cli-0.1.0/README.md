# Roboto SAI CLI

Thin operator shell over `roboto-sai-sdk`.

The CLI is SDK-backed. It does not carry its own public model registry, worker defaults, routing logic, or key precedence rules.

## Install

```bash
pip install roboto-sai-cli
```

## Command Surface

```bash
roboto-sai version
roboto-sai models list
roboto-sai models show robotosai-heavy
roboto-sai agents
roboto-sai agent show codex
roboto-sai orchestrate "hello" --model robotosai
roboto-sai config show
```

## Models And Routing

The CLI reads model and runtime truth directly from the standalone SDK.

Supported public models:

- `robotosai`
- `robotosai-fast`
- `robotosai-codex`
- `robotosai-heavy`
- `robotosai-heavy-fast`
- `robotosai-heavy-codex`

## Worker Visibility

Only these worker agents are visible by default:

- `codex`
- `fast`
- `heavy`

`Roboto SAI` is the orchestrator identity only. It is not listed as a worker agent.

## Config

The CLI stores only local defaults for:

- `api_key`
- `provider`
- `base_url`
- `default_model`

The CLI does not store `SAI_MASTER_KEY`.
