"""Thin Roboto SAI CLI command loader."""

from __future__ import annotations

import typer

from .commands.agents import agent_app, agents
from .commands.config_cmd import config_app
from .commands.models import models_app
from .commands.orchestrate import orchestrate
from .commands.version import version

app = typer.Typer(
    name="roboto-sai",
    help="Thin SDK-backed operator shell for Roboto SAI",
    add_completion=False,
    no_args_is_help=True,
    pretty_exceptions_show_locals=False,
    context_settings={"help_option_names": ["-h", "--help"]},
)
app.add_typer(models_app, name="models")
app.add_typer(config_app, name="config")
app.add_typer(agent_app, name="agent")
app.command()(agents)
app.command()(orchestrate)
app.command()(version)


if __name__ == "__main__":
    app()
