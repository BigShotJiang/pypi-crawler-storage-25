"""Local CLI configuration helpers."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any


def get_config_dir() -> Path:
    override = os.getenv("ROBOTO_SAI_CONFIG_DIR")
    if override:
        return Path(override)
    return Path.home() / ".roboto-sai"


def get_config_path() -> Path:
    return get_config_dir() / "config.json"


def load_config() -> dict[str, Any]:
    path = get_config_path()
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {
            "api_key": "",
            "provider": "xai",
            "base_url": "",
            "default_model": "robotosai",
        }


def save_config(config: dict[str, Any]) -> None:
    path = get_config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2), encoding="utf-8")


def mask_value(value: str | None) -> str:
    normalized = (value or "").strip()
    if not normalized:
        return "(not set)"
    if len(normalized) <= 8:
        return normalized
    return f"{normalized[:4]}...{normalized[-4:]}"


def get_config_for_display() -> dict[str, Any]:
    config = load_config()
    return {
        **config,
        "api_key": mask_value(config.get("api_key")),
    }
