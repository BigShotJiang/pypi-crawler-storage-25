"""Roboto SAI CLI package."""

from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("roboto-sai-cli")
except Exception:  # pragma: no cover - development fallback
    __version__ = "0.0.0"

__author__ = "Roberto Villarreal Martinez"
__sigil__ = 929
