"""Model inspection commands backed by the standalone SDK."""

from __future__ import annotations

import json
from dataclasses import asdict

import typer

from roboto_sai_sdk import PUBLIC_MODEL_NAMES, get_runtime_profile

models_app = typer.Typer(help="Inspect Roboto SAI public models", invoke_without_command=True)


def _validate_public_model(model_name: str) -> str:
    candidate = (model_name or "").strip().lower()
    if candidate not in PUBLIC_MODEL_NAMES:
        supported = ", ".join(sorted(PUBLIC_MODEL_NAMES))
        raise typer.BadParameter(f"Unknown public model '{model_name}'. Choose one of: {supported}")
    return candidate


def _print_models() -> None:
    for model_name in sorted(PUBLIC_MODEL_NAMES):
        typer.echo(model_name)


@models_app.callback(invoke_without_command=True)
def models_callback(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        _print_models()


@models_app.command("list")
def list_models() -> None:
    _print_models()


@models_app.command("show")
def show_model(model_name: str) -> None:
    profile = get_runtime_profile(_validate_public_model(model_name))
    typer.echo(json.dumps(asdict(profile), indent=2))
