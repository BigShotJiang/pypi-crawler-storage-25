"""Prompt command that delegates to the current standalone SDK surface."""

from __future__ import annotations

import typer

from roboto_sai_sdk import PUBLIC_MODEL_NAMES, RobotoSAI

from ..config import load_config


def _validate_public_model(model_name: str | None) -> str | None:
    if model_name is None:
        return None
    candidate = model_name.strip().lower()
    if candidate not in PUBLIC_MODEL_NAMES:
        supported = ", ".join(sorted(PUBLIC_MODEL_NAMES))
        raise typer.BadParameter(f"Unknown public model '{model_name}'. Choose one of: {supported}")
    return candidate


def _resolve_model(config: dict[str, object], explicit_model: str | None) -> str | None:
    validated_explicit = _validate_public_model(explicit_model)
    if validated_explicit is not None:
        return validated_explicit

    configured_model = config.get("default_model")
    if isinstance(configured_model, str) and configured_model.strip():
        candidate = configured_model.strip().lower()
        if candidate in PUBLIC_MODEL_NAMES:
            return candidate

    return None


def orchestrate(
    prompt: str,
    model: str | None = typer.Option(None, "--model"),
) -> None:
    config = load_config()
    client = RobotoSAI(
        model=_resolve_model(config, model) or RobotoSAI.model,
        api_key=config.get("api_key") or None,
        base_url=config.get("base_url") or None,
    )
    result = client.send_message(prompt)
    typer.echo(result["text"])
