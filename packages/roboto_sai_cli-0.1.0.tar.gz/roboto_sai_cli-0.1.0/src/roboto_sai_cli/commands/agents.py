"""Agent inspection commands backed by the standalone SDK."""

from __future__ import annotations

import json
from dataclasses import asdict

import typer

from roboto_sai_sdk import get_agent, list_agents

agent_app = typer.Typer(help="Inspect a single registered worker agent", no_args_is_help=True)


def agents() -> None:
    for agent in list_agents():
        typer.echo(f"{agent.id}\t{agent.display_name}\t{agent.specialization}")


@agent_app.command("show")
def show_agent(agent_id: str) -> None:
    agent = get_agent(agent_id)
    if agent is None:
        supported = ", ".join(agent.id for agent in list_agents())
        raise typer.BadParameter(f"Unknown worker agent '{agent_id}'. Choose one of: {supported}")
    typer.echo(json.dumps(asdict(agent), indent=2))
