"""Version command."""

from __future__ import annotations

import typer

from .. import __version__


def version() -> None:
    typer.echo(__version__)
