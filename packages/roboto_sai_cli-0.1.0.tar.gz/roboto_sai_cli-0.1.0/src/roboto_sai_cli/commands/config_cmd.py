"""Config commands for local CLI defaults."""

from __future__ import annotations

import json

import typer

from roboto_sai_sdk import PUBLIC_MODEL_NAMES

from ..config import get_config_for_display, load_config, save_config

config_app = typer.Typer(help="Manage local CLI configuration", no_args_is_help=True)

_SUPPORTED_FIELDS = {
    "api-key": "api_key",
    "provider": "provider",
    "base-url": "base_url",
    "default-model": "default_model",
}
_SUPPORTED_PROVIDERS = {"xai", "openai"}


@config_app.command("show")
def show_config() -> None:
    typer.echo(json.dumps(get_config_for_display(), indent=2))


@config_app.command("set")
def set_config(field: str, value: str) -> None:
    if field not in _SUPPORTED_FIELDS:
        supported = ", ".join(_SUPPORTED_FIELDS)
        raise typer.BadParameter(f"Unsupported config field '{field}'. Choose one of: {supported}")

    normalized_value = value.strip()
    if field == "default-model" and normalized_value not in PUBLIC_MODEL_NAMES:
        supported = ", ".join(PUBLIC_MODEL_NAMES)
        raise typer.BadParameter(f"Unknown public model '{value}'. Choose one of: {supported}")
    if field == "provider" and normalized_value.lower() not in _SUPPORTED_PROVIDERS:
        supported = ", ".join(sorted(_SUPPORTED_PROVIDERS))
        raise typer.BadParameter(f"Unsupported provider '{value}'. Choose one of: {supported}")

    config = load_config()
    config[_SUPPORTED_FIELDS[field]] = normalized_value
    save_config(config)
    typer.echo(f"Saved {field}")
