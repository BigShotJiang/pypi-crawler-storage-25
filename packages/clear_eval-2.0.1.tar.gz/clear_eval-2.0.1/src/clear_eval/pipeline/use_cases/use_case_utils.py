from clear_eval.pipeline.use_cases.eval_use_case import MathUseCase, RAGUseCase, GeneralEvalUseCase, AgentEvalUseCase

def get_task_data_obj(use_case_name):
    if use_case_name == "math":
        return MathUseCase()
    elif use_case_name == "rag":
        return RAGUseCase()
    elif use_case_name == "general":
        return GeneralEvalUseCase()
    elif use_case_name == "agent":
        return AgentEvalUseCase()
    elif use_case_name == "tool_call":
        from clear_eval.pipeline.use_cases.tool_call_use_case import ToolCallEvalUseCase
        return ToolCallEvalUseCase()
    elif use_case_name == "external":
        from clear_eval.pipeline.use_cases.external_judge_use_case import ExternalJudgeUseCase
        return ExternalJudgeUseCase()
    raise ValueError(f"Unsupported use case: {use_case_name}")

