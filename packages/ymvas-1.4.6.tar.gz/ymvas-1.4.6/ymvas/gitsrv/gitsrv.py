from __future__ import annotations

import shutil
import os, tarfile, io, json

from os import makedirs, remove
from functools import lru_cache
from datetime import datetime as dt
from os.path import exists, expanduser, join, isdir, dirname, isfile, basename
from ymvas.utils.errors import YException
from ymvas.utils.files import get_yaml
from ymvas.utils.system import (
    get_pkg_localtion,
    get_global_config
)

class GitServer:
    # BASE CONFIG
    CONFIG:dict = get_global_config()

    # SERVER BASE DATA
    HOME            : str = str(CONFIG.get(
        "ymvas-server-home",
        expanduser("~/")
    ))

    AUTHORIZED_KEYS : str = join(
        HOME,
        '.ssh/authorized_keys'
    )
    REPOSITORIES    : str = str(CONFIG.get(
        "ymvas-server-repos-base",
        join(HOME,"repositories")
    ))




    def __init__(self) -> None:

        pass


    def exists(self,user:str,name:str) -> bool:
        return exists(
            join( self.REPOSITORIES , user, f"{name}.git" )
        )

    def setup(self, user:str, sshkey:str ):
        # this will create ssh record in the authorized_keys
        auth_keys = expanduser(self.AUTHORIZED_KEYS)
        sshkey    = expanduser(sshkey)

        if not exists(sshkey):
            raise YException('missing-ssh-key',amsg={
                "src" : sshkey
            })

        if not exists(sshkey):
            raise YException('missing-ssh-key',amsg={
                "src" : sshkey
            })

        content = None
        with open(sshkey) as f:
            content = f.read().strip()

        # in case of some strange file
        if content is None or content == '':
            raise YException('missing-ssh-key',amsg={
                "src" : sshkey
            })

        src = get_pkg_localtion()
        srv = join(src,'server.py')

        srv_exec = f"{srv} user='{user}'"

        full_command = (
            f"command=\"{srv_exec}\","
            f"no-port-forwarding,"
            f"no-X11-forwarding,"
            "no-agent-forwarding,"
            f"no-pty {content}"
        )

        if exists(auth_keys):
            with open(auth_keys) as f:
                for l in f:
                    if l.strip() == full_command:
                        print('access was already added!')
                        return

            with open(auth_keys,"a") as f:
                f.write(full_command + "\n")
        else:
            with open(auth_keys,"w") as f:
                f.write(full_command + "\n")

        print('succefully added access!')

    @lru_cache(maxsize=2)
    def _get_rep_access(self,repo:str) -> dict:
        fpath = join( self.REPOSITORIES , repo + '.git' )
        yconf = join( fpath , 'ymconf.yaml' )

        if not exists(yconf):
            return {}

        data = get_yaml(yconf)

        if not isinstance(data,dict):
            return {}

        return data

    def __has_access(self,repo:str,user:str,priv:str) -> bool:
        access = self._get_rep_access(repo)

        if 'users' not in access:
            return False

        users = access['users']
        if user not in users:
            return False

        privleg = users[user]
        if 'access' not in privleg:
            return False

        uacces = privleg['access']
        if not isinstance(uacces,str):
            return False

        return priv.lower() in uacces.lower()

    def has_read_privileges(self,repo:str, user:str) -> bool:
        return self.__has_access(repo,user,'r')

    def has_write_privileges(self,repo:str, user:str) -> bool:
        return self.__has_access(repo,user,'w')

    def backup(self , target:str ) -> str:
        src = join(
            target,
            dt.now().strftime("%Y%m%d%H%M%S") + ".tar.gz"
        )

        conf = GitServer.CONFIG
        extras = conf.get("ymvas-server-backup-extras",{})

        folders = {
            "repositories"    : self.REPOSITORIES,
            "authorized_keys" : expanduser(self.AUTHORIZED_KEYS)
        }

        if isinstance(extras,dict):
            for k,v in extras.items():
                if not isinstance(v, str):
                    continue
                folders[k] = v

        for path in folders.values():
            if not exists(path):
                raise YException('missing-backup-path', amsg={
                    "src" : path
                })

        makedirs(target,exist_ok=True)

        with tarfile.open(src, "w:gz") as tar:
            for k, path in folders.items():
                tar.add(path, arcname = k)
            
            from ymvas import __version__
            data = json.dumps(
                {
                    "info"    : folders,
                    "version" : __version__
                }, 
                indent=2
            ).encode("utf-8")

            info = tarfile.TarInfo(name="meta.json")
            info.size = len(data)

            tar.addfile(info, io.BytesIO(data))

        return src

    def restore(self, archive: str) -> bool:
        if not exists(archive):
            raise YException("backup-not-found", amsg={"src": archive})

        conf = GitServer.CONFIG
        extras = conf.get("ymvas-server-backup-extras",{})

        folders = {
            "repositories"    : self.REPOSITORIES,
            "authorized_keys" : expanduser(self.AUTHORIZED_KEYS)
        }

        restore = {}

        if isinstance(extras,dict):
            for k,v in extras.items():
                if not isinstance(v, str):
                    continue
                folders[k] = v

        with tarfile.open(archive, "r:gz") as tar:
            try:
                meta_file = tar.extractfile("meta.json")
                data = json.load(meta_file)
                meta = data.get("info",{})

                artifacts = list(meta.keys())
                
                # check if has where to export
                for a in artifacts:
                    if a not in folders:
                        raise YException(
                            'invalid-backup', 
                            amsg = {
                                'reason' : f"artifact [{a}] in backup is missing destination!"
                            }
                        )

                for k,_ in meta.items():
                    xpath = restore[k] = folders[k]
                    if isfile(xpath) and not isdir(xpath):
                        remove(xpath)
                    else:
                        shutil.rmtree(xpath,ignore_errors=True)

            except YException as e:
                raise e
            except Exception:
                raise YException("invalid-backup", amsg={"reason": "missing meta.json"})
            

            for member in tar.getmembers():
                if member.name == "meta.json":
                    continue
                
                start = member.name.split('/')[0]
                dest  = dirname(restore[start])

                if member.isfile():
                    fpath = join(dest,member.name)
                    with tar.extractfile(member) as src, open(fpath, "wb") as dst:
                        dst.write(src.read())
                else:
                    tar.extract(member, path=dest)

        return True
