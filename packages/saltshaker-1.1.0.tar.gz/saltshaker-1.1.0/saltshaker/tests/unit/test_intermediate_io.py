"""
Unit tests for intermediate file I/O

Covers read/write roundtrip for genome metadata including replication origins.
"""
import pytest
import pandas as pd
from pathlib import Path
from saltshaker.io.writers import write_intermediate
from saltshaker.io.readers import read_intermediate


def _minimal_events() -> pd.DataFrame:
    """Minimal events DataFrame for write/read roundtrip tests"""
    return pd.DataFrame({
        'cluster_id': ['c1', 'c2'],
        'del_start_median': [1000, 5000],
        'del_end_median': [2000, 6000],
        'final_event': ['del', 'dup'],
        'perc': [5.0, 12.0],
    })


class TestIntermediateRoundtrip:
    """write_intermediate → read_intermediate roundtrip"""

    def test_genome_length_preserved(self, tmp_path):
        out = str(tmp_path / "events.tsv")
        events = _minimal_events()
        write_intermediate(events, out, genome_length=16569)
        _, genome_length, _, _ = read_intermediate(out)
        assert genome_length == 16569

    def test_ori_h_preserved(self, tmp_path):
        out = str(tmp_path / "events.tsv")
        write_intermediate(_minimal_events(), out, 16569,
                           ori_h=(16081, 407), ori_l=(5730, 5763))
        _, _, ori_h, _ = read_intermediate(out)
        assert ori_h == (16081, 407)

    def test_ori_l_preserved(self, tmp_path):
        out = str(tmp_path / "events.tsv")
        write_intermediate(_minimal_events(), out, 16569,
                           ori_h=(16081, 407), ori_l=(5730, 5763))
        _, _, _, ori_l = read_intermediate(out)
        assert ori_l == (5730, 5763)

    def test_origins_absent_returns_none(self, tmp_path):
        """Files written without origins should return None for both."""
        out = str(tmp_path / "events.tsv")
        write_intermediate(_minimal_events(), out, 16569)
        _, _, ori_h, ori_l = read_intermediate(out)
        assert ori_h is None
        assert ori_l is None

    def test_data_preserved(self, tmp_path):
        """Event data should survive the roundtrip unchanged."""
        out = str(tmp_path / "events.tsv")
        events = _minimal_events()
        write_intermediate(events, out, 16569, ori_h=(16081, 407))
        result, _, _, _ = read_intermediate(out)
        assert list(result['cluster_id']) == list(events['cluster_id'])
        assert list(result['del_start_median']) == list(events['del_start_median'])

    def test_partial_origins_absent(self, tmp_path):
        """Only ori_h written — ori_l should come back as None."""
        out = str(tmp_path / "events.tsv")
        write_intermediate(_minimal_events(), out, 16569, ori_h=(16081, 407))
        _, _, ori_h, ori_l = read_intermediate(out)
        assert ori_h == (16081, 407)
        assert ori_l is None
