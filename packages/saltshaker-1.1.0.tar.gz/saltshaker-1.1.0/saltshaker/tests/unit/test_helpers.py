"""
Unit tests for helper functions.

Covers EventCaller static parsing methods and CircularPlotter._fmt_coverage.
"""
import pytest
from saltshaker.event_caller import EventCaller
from saltshaker.visualizer import CircularPlotter


@pytest.mark.unit
class TestParseCommaSeparatedMedian:
    """Tests for _parse_comma_separated_median"""
    
    def test_single_value(self):
        """Single value should return that value as float"""
        assert EventCaller._parse_comma_separated_median("100") == 100.0
    
    def test_two_values(self):
        """Two values should return their average"""
        assert EventCaller._parse_comma_separated_median("100,200") == 150.0
    
    def test_three_values_odd(self):
        """Three values should return middle value"""
        assert EventCaller._parse_comma_separated_median("100,102,104") == 102.0
    
    def test_unsorted_values(self):
        """Values should be sorted before finding median"""
        assert EventCaller._parse_comma_separated_median("50,10,30,20,40") == 30.0
    
    def test_with_spaces(self):
        """Should handle spaces after commas"""
        result = EventCaller._parse_comma_separated_median("100, 102, 104")
        assert result == 102.0
    
    def test_large_list(self):
        """Should handle larger lists correctly"""
        values = ",".join(str(i) for i in range(1, 101))
        assert EventCaller._parse_comma_separated_median(values) == 50.5


@pytest.mark.unit
class TestParseCommaSeparatedMin:
    """Tests for _parse_comma_separated_min"""
    
    def test_single_value(self):
        """Single value should return that value"""
        assert EventCaller._parse_comma_separated_min("100") == 100
    
    def test_multiple_values(self):
        """Should return minimum value"""
        assert EventCaller._parse_comma_separated_min("50,10,30,20,40") == 10
    
    def test_unsorted_values(self):
        """Should work with unsorted values"""
        assert EventCaller._parse_comma_separated_min("100,50,200,25") == 25


@pytest.mark.unit
class TestParseCommaSeparatedMax:
    """Tests for _parse_comma_separated_max"""
    
    def test_single_value(self):
        """Single value should return that value"""
        assert EventCaller._parse_comma_separated_max("100") == 100
    
    def test_multiple_values(self):
        """Should return maximum value"""
        assert EventCaller._parse_comma_separated_max("50,10,30,20,40") == 50
    
    def test_unsorted_values(self):
        """Should work with unsorted values"""
        assert EventCaller._parse_comma_separated_max("100,50,200,25") == 200


@pytest.mark.unit
class TestFmtCoverage:
    """Tests for CircularPlotter._fmt_coverage — coverage depth formatting."""

    def test_small_value(self):
        assert CircularPlotter._fmt_coverage(0) == "0"
        assert CircularPlotter._fmt_coverage(500) == "500"
        assert CircularPlotter._fmt_coverage(999) == "999"

    def test_thousands(self):
        assert CircularPlotter._fmt_coverage(1_000) == "1K"
        assert CircularPlotter._fmt_coverage(60_000) == "60K"
        assert CircularPlotter._fmt_coverage(999_499) == "999K"

    def test_boundary_rounds_to_M(self):
        """Values that round to 1000K must be promoted to 1.0M, not '1000K'."""
        assert CircularPlotter._fmt_coverage(999_500) == "1.0M"
        assert CircularPlotter._fmt_coverage(999_999) == "1.0M"

    def test_millions(self):
        assert CircularPlotter._fmt_coverage(1_000_000) == "1.0M"
        assert CircularPlotter._fmt_coverage(1_200_000) == "1.2M"
        assert CircularPlotter._fmt_coverage(10_000_000) == "10.0M"
