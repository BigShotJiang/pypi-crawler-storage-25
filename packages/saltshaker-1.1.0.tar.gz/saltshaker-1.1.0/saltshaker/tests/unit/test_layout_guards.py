"""
Layout engine guard tests

Covers edge cases introduced in the 11-cluster-blacklisted-events work:
  - All-large-arc singles: space estimation must allocate one level per event
  - BL-only sample: classifier + layout must not crash and must produce BL groups
  - 3-pass radius order: clean bands outermost, BL bands innermost within each ring
"""

import pytest
import pandas as pd
import numpy as np

from saltshaker.config import PlotConfig
from saltshaker.layout.engine import LayoutEngine


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

GENOME = 16569


def _make_events(rows: list[dict]) -> pd.DataFrame:
    """Build a minimal events DataFrame suitable for the layout engine."""
    df = pd.DataFrame(rows)
    # Ensure required columns have correct dtypes
    for col in ("deg1", "deg2", "delsize", "perc"):
        if col in df.columns:
            df[col] = df[col].astype(float)
    return df


def _large_arc_event(group: str, event_type: str = "del", idx: int = 0) -> dict:
    """Return a single event whose arc spans >270° (nearly full circle)."""
    return {
        "group": group,
        "final_event": event_type,
        "perc": 15.0,
        "delsize": 15000,   # large deletion → large arc
        "deg1": float(10 + idx * 5),
        "deg2": float(350 + idx * 5) % 360 or 359.0,  # ~340° arc
    }


def _small_arc_event(group: str, event_type: str = "del", idx: int = 0) -> dict:
    """Return a single event whose arc spans <270°."""
    return {
        "group": group,
        "final_event": event_type,
        "perc": 15.0,
        "delsize": 3000,
        "deg1": float(10 + idx * 30),
        "deg2": float(80 + idx * 30),
    }


def _bl_event(group: str, event_type: str = "del", idx: int = 0) -> dict:
    """Return a blacklist-group event (group starts with 'BL')."""
    return {
        "group": group,
        "final_event": event_type,
        "perc": 5.0,
        "delsize": 2000,
        "deg1": float(20 + idx * 10),
        "deg2": float(60 + idx * 10),
    }


# ---------------------------------------------------------------------------
# Test 1: Large-arc space estimation
# ---------------------------------------------------------------------------

@pytest.mark.unit
@pytest.mark.layout
class TestLargeArcSpaceEstimation:
    """_calculate_required_space must allocate one level per large-arc single."""

    def _engine(self) -> LayoutEngine:
        return LayoutEngine(PlotConfig(), genome_length=GENOME)

    def test_three_large_arc_singles_get_three_levels(self):
        """Three large-arc single events → space ≥ 3 × space_per_level."""
        engine = self._engine()
        cfg = engine.layout_config
        space_per_level = max(cfg.min_viable_band_height, cfg.group_gap * 2)

        events = _make_events([
            _large_arc_event("G1", idx=0),
            _large_arc_event("G2", idx=1),
            _large_arc_event("G3", idx=2),
        ])
        space = engine._calculate_required_space(events, "del")

        # 3 large-arc singles → 3 independent levels
        assert space >= 3 * space_per_level, (
            f"Expected ≥{3 * space_per_level:.1f}px for 3 large-arc singles, got {space:.1f}px"
        )

    def test_large_arc_needs_more_space_than_small_arc(self):
        """Two large-arc singles must request more space than two small-arc singles
        (small arcs can share a level; large arcs cannot)."""
        engine = self._engine()
        cfg = engine.layout_config

        # Two large-arc events each in their own group → each must get own level
        large_events = _make_events([
            _large_arc_event("G1", idx=0),
            _large_arc_event("G2", idx=1),
        ])
        small_events = _make_events([
            _small_arc_event("G1", idx=0),
            _small_arc_event("G2", idx=1),
        ])

        large_space = engine._calculate_required_space(large_events, "del")
        small_space = engine._calculate_required_space(small_events, "del")

        assert large_space >= small_space, (
            f"Large-arc space ({large_space:.1f}px) should be ≥ small-arc space ({small_space:.1f}px)"
        )

    def test_mixed_arc_types_counted_correctly(self):
        """One large + one small: space must reflect one own-level + one shared level."""
        engine = self._engine()
        cfg = engine.layout_config
        space_per_level = max(cfg.min_viable_band_height, cfg.group_gap * 2)

        events = _make_events([
            _large_arc_event("G1", idx=0),
            _small_arc_event("G2", idx=1),
        ])
        space = engine._calculate_required_space(events, "del")

        # Must be enough for at least 2 levels (1 large own + 1 small shared)
        assert space >= 2 * space_per_level, (
            f"Expected ≥{2 * space_per_level:.1f}px for 1 large + 1 small single, got {space:.1f}px"
        )

    def test_all_large_arc_layout_places_all_events(self):
        """Full layout with only large-arc singles must place every event."""
        engine = LayoutEngine(PlotConfig(), genome_length=GENOME)

        del_events = _make_events([
            _large_arc_event("G1", idx=0),
            _large_arc_event("G2", idx=1),
            _large_arc_event("G3", idx=2),
        ])
        dup_events = _make_events([])

        result = engine.calculate_layout(del_events, dup_events, requested_radius=400.0)

        placed_indices = {s.event_index for s in result.single_events}
        expected_indices = set(del_events.index)
        assert placed_indices == expected_indices, (
            f"Not all large-arc singles placed: missing {expected_indices - placed_indices}"
        )


# ---------------------------------------------------------------------------
# Test 2: BL-only sample
# ---------------------------------------------------------------------------

@pytest.mark.unit
@pytest.mark.layout
class TestBLOnlySample:
    """Layout must handle a ring containing only BL groups (no clean events)."""

    def test_bl_only_del_ring_produces_bl_bands(self):
        """When all del events are BL groups, they should appear as group bands."""
        engine = LayoutEngine(PlotConfig(), genome_length=GENOME)

        # Two BL groups each with 2 events (multi-event → BL bands)
        del_events = _make_events([
            _bl_event("BL1", idx=0),
            _bl_event("BL1", idx=1),
            _bl_event("BL2", idx=2),
            _bl_event("BL2", idx=3),
        ])
        dup_events = _make_events([])

        result = engine.calculate_layout(del_events, dup_events, requested_radius=400.0)

        bl_bands = [b for b in result.group_bands if b.group_id.startswith("BL")]
        assert len(bl_bands) >= 2, (
            f"Expected ≥2 BL group bands, got {len(bl_bands)}: {[b.group_id for b in bl_bands]}"
        )

    def test_bl_only_no_clean_singles_emitted(self):
        """BL events must not appear as clean singles."""
        engine = LayoutEngine(PlotConfig(), genome_length=GENOME)

        del_events = _make_events([
            _bl_event("BL1", idx=0),
            _bl_event("BL1", idx=1),
        ])
        dup_events = _make_events([])

        result = engine.calculate_layout(del_events, dup_events, requested_radius=400.0)

        # All BL events should be in group_bands, not single_events
        assert len(result.single_events) == 0, (
            f"BL events should not appear as singles: {result.single_events}"
        )

    def test_bl_classifier_edge_case_all_blacklist(self):
        """EventClassifier must return 'Blacklist-only' and BL groups when all events are BL."""
        from saltshaker.classifier import EventClassifier
        from saltshaker.types import BlacklistRegion

        classifier = EventClassifier(genome_length=GENOME)
        blacklist = [BlacklistRegion(start=1, end=16000, name="test_region")]

        events = pd.DataFrame({
            "del_start_median": [100, 500, 1000],
            "del_end_median":   [300, 700, 1200],
            "perc":             [5.0, 8.0, 3.0],
            "final_event":      ["del", "del", "del"],
            "delsize":          [200, 200, 200],
        })

        classification, reason, criteria, events_with_groups = classifier.classify(
            events, blacklist_regions=blacklist
        )

        assert classification == "Blacklist-only", f"Got: {classification}"
        assert len(events_with_groups) == 3, "All events should be returned with BL groups"
        assert all(
            g.startswith("BL") for g in events_with_groups["group"]
        ), f"All groups should be BL-prefixed: {events_with_groups['group'].tolist()}"


# ---------------------------------------------------------------------------
# Test 3: 3-pass radius ordering
# ---------------------------------------------------------------------------

@pytest.mark.unit
@pytest.mark.layout
class TestThreePassRadiusOrder:
    """Within each ring, clean bands must be outermost and BL bands innermost."""

    def _run_layout(self) -> "LayoutEngine":
        from saltshaker.layout.engine import LayoutEngine
        return LayoutEngine(PlotConfig(), genome_length=GENOME)

    def test_clean_bands_outermost_bl_bands_innermost(self):
        """The minimum radius of clean bands must be > maximum radius of BL bands."""
        engine = self._run_layout()

        # One clean multi-event group and one BL multi-event group
        del_events = _make_events([
            {"group": "G1", "final_event": "del", "perc": 15.0, "delsize": 3000, "deg1": 10.0, "deg2": 80.0},
            {"group": "G1", "final_event": "del", "perc": 12.0, "delsize": 3000, "deg1": 90.0, "deg2": 160.0},
            {"group": "BL1", "final_event": "del", "perc": 5.0, "delsize": 2000, "deg1": 200.0, "deg2": 240.0},
            {"group": "BL1", "final_event": "del", "perc": 4.0, "delsize": 2000, "deg1": 250.0, "deg2": 290.0},
        ])
        dup_events = _make_events([])

        result = engine.calculate_layout(del_events, dup_events, requested_radius=400.0)

        clean_bands = [b for b in result.group_bands if not b.group_id.startswith("BL")]
        bl_bands    = [b for b in result.group_bands if b.group_id.startswith("BL")]

        assert clean_bands, "Expected at least one clean band"
        assert bl_bands,    "Expected at least one BL band"

        # band_top is the outer edge, band_bottom is the inner edge
        min_clean_bottom = min(b.band_bottom for b in clean_bands)
        max_bl_top       = max(b.band_top    for b in bl_bands)

        assert min_clean_bottom > max_bl_top, (
            f"Clean bands should be fully outside BL bands: "
            f"min clean bottom={min_clean_bottom:.1f}px, max BL top={max_bl_top:.1f}px"
        )

    def test_clean_singles_between_clean_bands_and_bl_bands(self):
        """Clean single events must lie between clean multi-bands and BL bands."""
        engine = self._run_layout()

        del_events = _make_events([
            # Clean multi-event group (G1)
            {"group": "G1", "final_event": "del", "perc": 15.0, "delsize": 3000, "deg1": 10.0, "deg2": 80.0},
            {"group": "G1", "final_event": "del", "perc": 12.0, "delsize": 3000, "deg1": 90.0, "deg2": 160.0},
            # Clean single event (G2)
            {"group": "G2", "final_event": "del", "perc": 10.0, "delsize": 3000, "deg1": 200.0, "deg2": 260.0},
            # BL multi-event group (BL1)
            {"group": "BL1", "final_event": "del", "perc": 5.0, "delsize": 2000, "deg1": 300.0, "deg2": 340.0},
            {"group": "BL1", "final_event": "del", "perc": 4.0, "delsize": 2000, "deg1": 10.0, "deg2": 50.0},
        ])
        dup_events = _make_events([])

        result = engine.calculate_layout(del_events, dup_events, requested_radius=400.0)

        clean_bands = [b for b in result.group_bands if not b.group_id.startswith("BL")]
        bl_bands    = [b for b in result.group_bands if b.group_id.startswith("BL")]
        singles     = result.single_events

        assert clean_bands, "Expected clean multi-event bands"
        assert bl_bands,    "Expected BL bands"
        assert singles,     "Expected clean single events"

        min_clean_bottom = min(b.band_bottom for b in clean_bands)
        max_bl_top       = max(b.band_top    for b in bl_bands)
        single_radii     = [s.radius for s in singles]

        # Singles must be inside clean bands
        assert all(r <= min_clean_bottom for r in single_radii), (
            f"Singles ({single_radii}) must be ≤ min clean band bottom ({min_clean_bottom:.1f}px)"
        )
        # Singles must be outside BL bands
        assert all(r >= max_bl_top for r in single_radii), (
            f"Singles ({single_radii}) must be ≥ max BL band top ({max_bl_top:.1f}px)"
        )

    def test_large_arc_singles_get_own_level(self):
        """Two large-arc singles must land on different radius levels."""
        engine = self._run_layout()

        del_events = _make_events([
            _large_arc_event("G1", idx=0),
            _large_arc_event("G2", idx=1),
        ])
        dup_events = _make_events([])

        result = engine.calculate_layout(del_events, dup_events, requested_radius=400.0)

        radii = [s.radius for s in result.single_events]
        assert len(radii) == 2, f"Expected 2 placed singles, got {len(radii)}"
        assert radii[0] != radii[1], (
            f"Large-arc singles should be on different radius levels, both got {radii[0]:.1f}px"
        )
