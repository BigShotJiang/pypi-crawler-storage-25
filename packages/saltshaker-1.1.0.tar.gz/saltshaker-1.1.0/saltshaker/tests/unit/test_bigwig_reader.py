"""
Unit tests for BigWigReader

Tests validation and coverage reading using the sample BigWig file at
../results/Diag-wgs260.bw (relative to repo root).  Tests that require
the file are skipped when it is absent so CI stays green.
"""
import numpy as np
import pytest
from pathlib import Path
from unittest.mock import patch

from saltshaker.io import BigWigReader
from saltshaker.types import BigWigValidationResult

# Path to the sample file (may not exist in CI)
_SAMPLE_BW = Path(__file__).parent.parent.parent.parent / "results" / "Diag-wgs260.bw"
_HAS_SAMPLE = _SAMPLE_BW.exists()


# ---------------------------------------------------------------------------
# BigWigReader.validate — unit tests that don't need a real file
# ---------------------------------------------------------------------------

@pytest.mark.unit
class TestBigWigReaderMissingFile:
    def test_validate_nonexistent_file_returns_invalid(self):
        result = BigWigReader.validate("/nonexistent/path/file.bw")
        assert isinstance(result, BigWigValidationResult)
        assert result.is_valid is False
        assert result.error is not None

    def test_invalid_result_str(self):
        result = BigWigReader.validate("/nonexistent/path/file.bw")
        assert "INVALID" in str(result)

    def test_validate_returns_invalid_when_pybigwig_not_installed(self):
        """validate() must return is_valid=False (not raise) when pyBigWig is absent.
        Regression: previously _require_pybigwig() raised ImportError before _fail()
        was defined, causing CI failures in environments without the optional dep."""
        with patch.object(
            BigWigReader, "_require_pybigwig",
            side_effect=ImportError("pyBigWig is not installed"),
        ):
            result = BigWigReader.validate("any.bw")

        assert isinstance(result, BigWigValidationResult)
        assert result.is_valid is False
        assert "pyBigWig" in (result.error or "")


class TestBigWigReaderReadCoverageContract:
    """Contract tests for read_coverage — shape and value range."""

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_returns_ndarray(self):
        result = BigWigReader.read_coverage(
            str(_SAMPLE_BW), chrom="MT", genome_length=16569
        )
        assert isinstance(result, np.ndarray)

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_default_n_bins(self):
        result = BigWigReader.read_coverage(
            str(_SAMPLE_BW), chrom="MT", genome_length=16569
        )
        assert result.shape == (500,)

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_custom_n_bins(self):
        result = BigWigReader.read_coverage(
            str(_SAMPLE_BW), chrom="MT", genome_length=16569, n_bins=200
        )
        assert result.shape == (200,)

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_values_in_zero_one(self):
        result = BigWigReader.read_coverage(
            str(_SAMPLE_BW), chrom="MT", genome_length=16569
        )
        assert result.min() >= 0.0
        assert result.max() <= 1.0

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_max_is_one_log1p(self):
        """After log1p + normalisation the maximum should be exactly 1.0."""
        result = BigWigReader.read_coverage(
            str(_SAMPLE_BW), chrom="MT", genome_length=16569, normalisation='log1p'
        )
        assert pytest.approx(result.max(), abs=1e-9) == 1.0

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_linear_normalisation(self):
        result = BigWigReader.read_coverage(
            str(_SAMPLE_BW), chrom="MT", genome_length=16569, normalisation='linear'
        )
        assert pytest.approx(result.max(), abs=1e-9) == 1.0

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_invalid_normalisation_raises(self):
        with pytest.raises(ValueError, match="normalisation"):
            BigWigReader.read_coverage(
                str(_SAMPLE_BW), chrom="MT", genome_length=16569,
                normalisation='zscore'
            )


# ---------------------------------------------------------------------------
# BigWigReader.validate — integration tests against the real file
# ---------------------------------------------------------------------------

class TestBigWigValidation:
    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_valid_file_is_valid(self):
        result = BigWigReader.validate(str(_SAMPLE_BW))
        assert result.is_valid is True
        assert result.error is None

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_chrom_name_detected(self):
        result = BigWigReader.validate(str(_SAMPLE_BW))
        assert result.chrom_name in BigWigReader.MT_CHROM_CANDIDATES

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_genome_length_correct(self):
        result = BigWigReader.validate(str(_SAMPLE_BW))
        assert result.chrom_length == 16569

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_no_gaps(self):
        result = BigWigReader.validate(str(_SAMPLE_BW))
        assert result.none_bin_count == 0

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_coverage_stats_plausible(self):
        result = BigWigReader.validate(str(_SAMPLE_BW))
        assert result.mean_coverage > 0
        assert result.max_coverage >= result.mean_coverage
        assert result.min_coverage <= result.mean_coverage

    @pytest.mark.skipif(not _HAS_SAMPLE, reason="Sample BigWig not present")
    def test_str_representation(self):
        result = BigWigReader.validate(str(_SAMPLE_BW))
        s = str(result)
        assert "OK" in s
        assert "chrM" in s or "MT" in s
