"""
SaltShaker configuration
Clean configuration with only necessary parameters
"""
from dataclasses import dataclass, field
from typing import Tuple, List, Literal, Optional, Any




@dataclass
class ClassificationConfig:
    """
    Classification thresholds for Single vs Multiple patterns
    Based on Basu et al. PLoS Genetics 2020
    """
    
    HIGH_HET_THRESHOLD: float = 10.0
    """High heteroplasmy threshold - pathogenic significance (≥10%)"""
    
    NOISE_THRESHOLD: float = 0.3
    """Noise threshold - below this likely artifacts (<0.3%)"""
    
    CLUSTER_RADIUS: int = 600
    """Spatial grouping radius in base pairs"""
    
    MIN_CLUSTER_SIZE: int = 2
    """Minimum events to form a spatial cluster"""
    
    MULTIPLE_EVENT_THRESHOLD: int = 10
    """Event count threshold for Multiple pattern (>10 = Multiple)"""
    
    DOMINANT_GROUP_FRACTION: float = 0.5
    """Fraction of events in dominant group for Single pattern (≥50%)"""


@dataclass
class LayoutConfig:
    """
    Simplified layout configuration for radial positioning
    
    Uses simple radial stacking without sectors or complex budgets.
    """
    
    # ============================================================
    # SPACE ALLOCATION
    # ============================================================
    total_radius: int = 400
    """Total radius available for event placement (px)"""
    
    separator_fraction: float = 0.15
    """Fraction of total radius for del/dup separator band"""
    
    # ============================================================
    # GROUP BAND SIZING
    # ============================================================
    base_band_size: int = 25
    """Base band size for multi-event groups (px)"""
    
    band_size_scale_factor: float = 0.8
    """Linear scaling factor: pixels per event"""
    
    max_band_size: int = 200
    """Maximum band size for very large groups (px)"""
    
    min_viable_band_height: float = 12.0
    """Minimum height for any group band to be valid (px) - prevents invalid zero-height bands"""
    
    # ============================================================
    # SPACING
    # ============================================================
    min_event_spacing: float = 3.0
    """Minimum spacing between event centers within a group (px)"""
    
    uniform_within_group_spacing: bool = True
    """Use uniform dense spacing within all groups (True) or proportional spacing (False)"""
    
    target_event_spacing: float = 3.5
    """Target spacing between events within a group when uniform spacing enabled (px)"""
    
    group_gap: int = 6
    """Vertical gap between adjacent group bands (px)"""

    bl_section_gap: int = 14
    """Extra gap inserted before the BL band section, on top of the normal group_gap.
    Total clean→BL separation = group_gap + bl_section_gap, which should visually exceed
    the clean→clean gap (group_gap) to make the BL section boundary obvious."""
    
    # ============================================================
    # BLACKLIST VISUALIZATION
    # ============================================================
    blacklist_boundary_linewidth: float = 0.4
    """Line width for dashed boundary lines at blacklist edges (px)"""
    
    blacklist_boundary_alpha: float = 0.4
    """Transparency for blacklist boundary lines"""
    
    # ============================================================
    # LABEL STYLING
    # ============================================================
    label_fontsize: int = 7
    """Font size for group labels"""
    
    label_box_padding: float = 0.15
    """Padding inside label boxes"""
    
    label_box_linewidth: float = 0.8
    """Border width for label boxes (px)"""
    
    label_connector_linewidth: float = 0.4
    """Line width for label connector lines (px)"""
    
    label_min_angular_separation: float = 12.0
    """Minimum angular separation between labels (degrees) to avoid overlap"""
    
    label_radial_nudge: float = 8.0
    """Radial offset applied to conflicting labels (px) for vertical separation"""
    
    # ============================================================
    # RING LAYOUT
    # ============================================================
    min_ring_size: int = 50
    """Minimum pixels allocated per ring when events exist"""
    
    buffer_zone: int = 8
    """Buffer space around separator circle (px)"""
    
    single_event_min_angular_spacing: float = 45.0
    """Minimum angular separation between single events on shared level (degrees)"""
    
    single_event_max_per_level: int = 8
    """Maximum number of single events per shared radius level"""


@dataclass
class VisualizationConfig:
    """
    Adaptive visualization parameters
    Controls line width and transparency based on density
    """
    
    # ============================================================
    # ADAPTIVE LINE WIDTH
    # ============================================================
    adaptive_linewidth_enabled: bool = False
    """Enable adaptive line width based on local density (currently disabled, uses fixed width)"""
    
    fixed_event_linewidth: float = 2.5
    """Fixed line width for event arcs when adaptive linewidth is disabled (px)"""
    
    density_window_degrees: float = 30.0
    """Angular window for calculating local density (degrees)"""
    
    density_linewidth_min: float = 1.5
    """Minimum line width in very dense areas (px)"""
    
    density_linewidth_max: float = 3.5
    """Maximum line width in sparse areas (px)"""
    
    density_threshold_high: int = 20
    """Event count threshold for 'high density' in window"""
    
    density_threshold_medium: int = 10
    """Event count threshold for 'medium density' in window"""
    
    # ============================================================
    # FIXED LINE WIDTH (Fallback)
    # ============================================================
    event_linewidth_small: float = 3.0
    """Line width when ≤150 events (used when adaptive disabled)"""
    
    event_linewidth_medium: float = 2.5
    """Line width when ≤300 events (used when adaptive disabled)"""
    
    event_linewidth_large: float = 2.0
    """Line width when >300 events (used when adaptive disabled)"""
    
    event_linewidth_threshold_medium: int = 150
    """Event count threshold for medium line width"""
    
    event_linewidth_threshold_large: int = 300
    """Event count threshold for large line width"""
    
    # ============================================================
    # TRANSPARENCY
    # ============================================================
    alpha_min: float = 0.70
    """Minimum alpha (transparency) for low heteroplasmy events"""
    
    alpha_range: float = 0.25
    """Alpha range from min to max (max = alpha_min + alpha_range)"""


@dataclass
class CoverageTrackConfig:
    """
    Configuration for the optional BigWig coverage track.

    The track is drawn as a step-function ring just outside the gene annotation
    track (or the genome circle when no gene track is present).
    """

    track_height: int = 40
    """Radial height of the coverage ring (px)"""

    margin: int = 45
    """Gap between the preceding track and the coverage ring inner edge (px).
    Needs to be large enough that gene name labels AND kb coordinate labels
    remain in the white space between the gene track and the coverage ring."""

    n_bins: int = 500
    """Number of angular bins used when reading coverage from the BigWig file"""

    normalisation: Literal['log1p', 'linear', 'percentile'] = 'percentile'
    """
    Normalisation applied before scaling to [0, 1].
    'percentile' (default): clips to [percentile_low, percentile_high] then
        normalises — mirrors what IGV and other genome browsers do; best for
        mtDNA where the absolute coverage level is less interesting than
        relative variation.
    'log1p': log-compresses then normalises to [0, 1] — good when coverage
        spans many orders of magnitude.
    'linear': normalises by global max with no compression.
    """

    percentile_low: float = 2.0
    """Lower percentile clip for 'percentile' normalisation (default 2)"""

    percentile_high: float = 98.0
    """Upper percentile clip for 'percentile' normalisation (default 98)"""

    color: str = '#2E86AB'
    """Fill colour for the coverage histogram (default: steel blue)"""

    alpha: float = 0.65
    """Transparency of the coverage fill"""

    baseline_color: str = 'gray'
    """Colour of the inner baseline circle"""

    baseline_linewidth: float = 0.5
    """Line width of the inner baseline circle (px)"""

    baseline_alpha: float = 0.5
    """Transparency of the baseline circle"""

    scale_indicator: bool = True
    """Draw a small bracket at genome position 0 showing the track height scale"""

    scale_indicator_color: str = 'dimgray'
    """Colour for the scale bracket and label"""


@dataclass
class PlotConfig:
    """
    Complete plot configuration - SIMPLIFIED
    
    Clean configuration without legacy parameters.
    """
    
    # ============================================================
    # SUB-CONFIGURATIONS
    # ============================================================
    layout: LayoutConfig = field(default_factory=LayoutConfig)
    """Layout configuration"""

    visualization: VisualizationConfig = field(default_factory=VisualizationConfig)
    """Visualization configuration"""

    coverage: CoverageTrackConfig = field(default_factory=CoverageTrackConfig)
    """Coverage track configuration (used when --coverage is supplied)"""
    
    # ============================================================
    # RENDERING PARAMETERS
    # ============================================================
    arc_resolution: int = 100
    """Number of points for drawing event arcs (smoothness)"""
    
    # ============================================================
    # GENOME CIRCLE
    # ============================================================
    degrees_per_genome: int = 360
    """Total degrees around circle (360° = complete circle, no gap)"""
    
    genome_circle_linewidth: int = 2
    """Line width for main genome circle (px) - thinner for subtlety"""
    
    genome_circle_style: str = '--'
    """Line style for genome circle: '-' solid, '--' dashed, ':' dotted"""
    
    genome_circle_color: str = 'gray'
    """Color for genome circle: 'k' black, 'gray' gray"""
    
    genome_circle_alpha: float = 0.5
    """Transparency for genome circle (0=invisible, 1=solid)"""
    
    separator_circle_linewidth: float = 1.0
    """Line width for del/dup separator circle (px) - subtle dashed line"""
    
    separator_circle_alpha: float = 0.4
    """Transparency for separator circle - more subtle"""
    
    # ============================================================
    # FIGURE SETTINGS
    # ============================================================
    figure_size: float = 12.0
    """Figure size in inches (square plot)"""
    
    dpi: int = 300
    """DPI for saved figures"""
    
    title_fontsize: int = 14
    """Font size for main title"""
    
    title_y_position: float = 0.98
    """Vertical position of title in figure coordinates (0-1, where 1 is top)"""
    
    circle_offset: float = 20.0
    """Offset from outermost radius to figure edge (px)"""
    
    gene_track_offset: float = 35.0
    """Space reserved for gene annotation track (px)"""
    
    coordinate_label_offset: float = 20.0
    """Space reserved for coordinate labels (px)"""
    
    # ============================================================
    # PRESET CONFIGURATIONS
    # ============================================================
    
    @classmethod
    def publication(cls) -> 'PlotConfig':
        """
        High-quality settings for publication figures
        
        - 600 DPI
        - Larger figure size (14 inches)
        - Thicker lines for better visibility in print
        
        Example:
            >>> config = PlotConfig.publication()
            >>> plotter = CircularPlotter(16569, config)
        """
        config = cls()
        config.dpi = 600
        config.figure_size = 14.0
        config.genome_circle_linewidth = 4
        config.separator_circle_linewidth = 3
        config.visualization.density_linewidth_min = 2.0
        config.visualization.density_linewidth_max = 4.0
        return config
    
    @classmethod
    def presentation(cls) -> 'PlotConfig':
        """
        Settings optimized for presentations
        
        - Lower DPI (150) for smaller file size
        - Larger fonts and thicker lines for screen viewing
        - Higher contrast
        
        Example:
            >>> config = PlotConfig.presentation()
            >>> plotter = CircularPlotter(16569, config)
        """
        config = cls()
        config.dpi = 150
        config.figure_size = 10.0
        config.title_fontsize = 16
        config.genome_circle_linewidth = 5
        config.separator_circle_linewidth = 4
        config.visualization.density_linewidth_min = 2.5
        config.visualization.density_linewidth_max = 5.0
        config.visualization.alpha_min = 0.85
        return config
    
    @classmethod
    def compact(cls) -> 'PlotConfig':
        """
        Compact settings for many events
        
        - Smaller bands and gaps
        - Thinner lines
        - More events per band
        
        Example:
            >>> config = PlotConfig.compact()
            >>> plotter = CircularPlotter(16569, config)
        """
        config = cls()
        config.layout.base_band_size = 15
        config.layout.band_size_scale_factor = 0.5
        config.layout.group_gap = 3
        config.layout.min_event_spacing = 2.0
        config.visualization.density_linewidth_min = 1.0
        config.visualization.density_linewidth_max = 2.5
        return config
    
    @classmethod
    def debug(cls) -> 'PlotConfig':
        """
        Settings for debugging layout issues
        
        - Larger spacing for clarity
        - Maximum transparency
        - Thicker lines
        
        Example:
            >>> config = PlotConfig.debug()
            >>> plotter = CircularPlotter(16569, config)
        """
        config = cls()
        config.layout.min_event_spacing = 5.0
        config.layout.group_gap = 10
        config.visualization.alpha_min = 1.0
        config.visualization.alpha_range = 0.0
        config.visualization.density_linewidth_min = 3.0
        config.visualization.density_linewidth_max = 5.0
        return config