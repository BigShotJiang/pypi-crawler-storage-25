"""
I/O readers

Handles reading of various input files.
"""

from __future__ import annotations
from typing import List, Tuple, Optional
from importlib.resources import path
import numpy as np
import pandas as pd
from pathlib import Path
import logging

from ..types import BlacklistRegion, GeneAnnotation, BigWigValidationResult

logger = logging.getLogger(__name__)


class BlacklistReader:
    """Reads and parses blacklist BED files"""
    
    @staticmethod
    def load_blacklist_regions(blacklist_file: str) -> List[BlacklistRegion]:
        """
        Robustly load blacklist regions from BED file
        
        Tries multiple parsing strategies to handle various BED formats.
        
        Args:
            blacklist_file: Path to BED file with regions to exclude
            
        Returns:
            List of dicts with 'chr', 'start', 'end' keys
        """
        blacklist_regions: List[BlacklistRegion] = []
        if not blacklist_file or not Path(blacklist_file).exists():
            return blacklist_regions
        
        try:
            blacklist: Optional[pd.DataFrame] = None
            # Try different separators
            for sep in ['\t', None, ' ', '\\s+']:
                try:
                    if sep == '\\s+':
                        blacklist = pd.read_csv(blacklist_file, sep=sep, header=None, engine='python')
                    elif sep is None:
                        blacklist = pd.read_csv(blacklist_file, sep=sep, header=None, engine='python')
                    else:
                        blacklist = pd.read_csv(blacklist_file, sep=sep, header=None)
                    
                    if blacklist.shape[1] >= 3:
                        break
                    else:
                        blacklist = None
                except Exception:
                    continue
            
            # Fallback: manual parsing
            if blacklist is None or blacklist.shape[1] < 3:
                with open(blacklist_file, 'r') as f:
                    lines = f.readlines()
                parsed_lines = []
                for line in lines:
                    line = line.strip()
                    if line:
                        parts = line.split()
                        if len(parts) >= 3:
                            parsed_lines.append([parts[0], parts[1], parts[2]])
                if parsed_lines:
                    blacklist = pd.DataFrame(parsed_lines, columns=['chr', 'start', 'end'])
            
            if blacklist is not None:
                blacklist = blacklist.iloc[:, :3].copy()
                blacklist.columns = ['chr', 'start', 'end']
                blacklist['start'] = pd.to_numeric(blacklist['start'], errors='coerce')
                blacklist['end'] = pd.to_numeric(blacklist['end'], errors='coerce')
                blacklist = blacklist.dropna()
                blacklist_regions = blacklist.to_dict('records')  # type: ignore
        
        except Exception as e:
            logger.warning(f"Could not load blacklist file: {e}")
        
        return blacklist_regions
    

class IntermediateReader:
    """Reads events in internal format"""
    
    @staticmethod
    def read(
        filepath: str,
    ) -> Tuple[pd.DataFrame, int, Optional[Tuple[int, int]], Optional[Tuple[int, int]]]:
        """
        Read events with metadata

        Args:
            filepath: Path to intermediate TSV file

        Returns:
            Tuple of (events_df, genome_length, ori_h, ori_l).
            ori_h and ori_l are None when absent from the file header.
        """
        genome_length: Optional[int] = None
        ori_h_start: Optional[int] = None
        ori_h_end: Optional[int] = None
        ori_l_start: Optional[int] = None
        ori_l_end: Optional[int] = None

        # Read all header comment lines
        with open(filepath, 'r') as f:
            for line in f:
                if not line.startswith('#'):
                    break
                key, _, val = line.strip().lstrip('# ').partition('=')
                key = key.strip()
                if key == 'genome_length':
                    genome_length = int(val)
                elif key == 'ori_h_start':
                    ori_h_start = int(val)
                elif key == 'ori_h_end':
                    ori_h_end = int(val)
                elif key == 'ori_l_start':
                    ori_l_start = int(val)
                elif key == 'ori_l_end':
                    ori_l_end = int(val)

        # Read full dataframe
        events: pd.DataFrame = pd.read_csv(filepath, sep='\t', comment='#')

        if genome_length is None:
            raise ValueError(f"No genome_length metadata found in {filepath}")

        ori_h: Optional[Tuple[int, int]] = (
            (ori_h_start, ori_h_end)
            if ori_h_start is not None and ori_h_end is not None
            else None
        )
        ori_l: Optional[Tuple[int, int]] = (
            (ori_l_start, ori_l_end)
            if ori_l_start is not None and ori_l_end is not None
            else None
        )

        return events, genome_length, ori_h, ori_l


def read_intermediate(
    filepath: str,
) -> Tuple[pd.DataFrame, int, Optional[Tuple[int, int]], Optional[Tuple[int, int]]]:
    """
    Convenience function to read intermediate format

    Args:
        filepath: Path to intermediate TSV file

    Returns:
        Tuple of (events_df, genome_length, ori_h, ori_l).
        ori_h and ori_l are None when absent from the file header.
    """
    return IntermediateReader.read(filepath)


class GeneAnnotationReader:
    """Read mitochondrial gene annotations from BED file"""
    
    @staticmethod
    def load_gene_annotations(bed_file: str) -> List[GeneAnnotation]:
        """
        Load gene annotations from BED file
        
        Expected format:
        chr  start  end  name  score  strand  thickStart  thickEnd  itemRgb
        chrM 576    647  MT-TF 0      +       576         647       255,255,0
        
        Args:
            bed_file: Path to BED file with gene annotations
        
        Returns:
            List of dicts with gene info including chr, start, end, name, color
        """
        annotations: List[GeneAnnotation] = []
        
        with open(bed_file, 'r') as f:
            for line in f:
                if line.startswith('#') or not line.strip():
                    continue
                
                fields = line.strip().split('\t')
                if len(fields) < 9:
                    continue
                
                # Parse RGB color
                rgb: Tuple[float, float, float] = tuple(
                    int(x)/255.0 for x in fields[8].split(',')
                )  # type: ignore
                
                gene_annotation: GeneAnnotation = {
                    'chr': fields[0],
                    'start': int(fields[1]),
                    'end': int(fields[2]),
                    'name': fields[3],
                    'strand': fields[5] if len(fields) > 5 else '+',
                    'color': rgb
                }
                
                annotations.append(gene_annotation)

        return annotations


class BigWigReader:
    """Reads and validates BigWig coverage files."""

    # Mitochondrial chromosome name conventions to try, in order
    MT_CHROM_CANDIDATES: Tuple[str, ...] = ("chrM", "MT", "chrMT", "M")

    @staticmethod
    def _require_pybigwig():
        """Import pyBigWig or raise a clear error pointing to the extras install."""
        try:
            import pyBigWig  # type: ignore
            return pyBigWig
        except ImportError:
            raise ImportError(
                "pyBigWig is required for BigWig coverage tracks. "
                "Install with: pip install saltshaker[coverage]"
            )

    @classmethod
    def _find_mt_chrom(cls, chroms: dict) -> Optional[str]:
        """Return the first recognised MT chromosome name present in chroms dict."""
        for name in cls.MT_CHROM_CANDIDATES:
            if name in chroms:
                return name
        return None

    @classmethod
    def validate(cls, filepath: str, n_bins: int = 200) -> BigWigValidationResult:
        """
        Validate a BigWig file for use as a mitochondrial coverage track.

        Checks that the file opens cleanly, contains a recognised MT chromosome,
        and has no unexpected gaps in a binned sweep.

        Args:
            filepath: Path to .bw / .bigwig file.
            n_bins:   Number of bins for the gap-check sweep (default 200).

        Returns:
            BigWigValidationResult with is_valid=True on success, or
            is_valid=False with an error message on failure.
        """
        def _fail(msg: str) -> BigWigValidationResult:
            return BigWigValidationResult(
                is_valid=False, filepath=filepath,
                chrom_name=None, chrom_length=None,
                mean_coverage=None, min_coverage=None, max_coverage=None,
                none_bin_count=0, error=msg,
            )

        try:
            pyBigWig = cls._require_pybigwig()
        except ImportError as e:
            return _fail(str(e))

        try:
            bw = pyBigWig.open(filepath)
        except Exception as e:
            return _fail(f"Cannot open file: {e}")

        if not bw.isBigWig():
            bw.close()
            return _fail("File is not a BigWig (may be BigBed or corrupt)")

        chroms = bw.chroms()
        if not chroms:
            bw.close()
            return _fail("No chromosomes found — file may be empty or truncated")

        mt_chrom = cls._find_mt_chrom(chroms)
        if mt_chrom is None:
            bw.close()
            tried = ", ".join(cls.MT_CHROM_CANDIDATES)
            return _fail(
                f"No mitochondrial chromosome found (tried: {tried}). "
                f"Available: {list(chroms.keys())}"
            )

        length = chroms[mt_chrom]

        try:
            mean_val = bw.stats(mt_chrom, 0, length, type="mean", nBins=1)[0]
            min_val  = bw.stats(mt_chrom, 0, length, type="min",  nBins=1)[0]
            max_val  = bw.stats(mt_chrom, 0, length, type="max",  nBins=1)[0]
        except Exception as e:
            bw.close()
            return _fail(f"Stats call failed: {e}")

        try:
            bins = bw.stats(mt_chrom, 0, length, type="mean", nBins=n_bins)
            none_count = sum(1 for v in bins if v is None)
        except Exception as e:
            bw.close()
            return _fail(f"Binned stats call failed: {e}")

        bw.close()
        logger.info(
            "BigWig validated: %s  chrom=%s (%d bp)  mean=%.1fx  gaps=%d/%d bins",
            filepath, mt_chrom, length, mean_val or 0.0, none_count, n_bins,
        )
        return BigWigValidationResult(
            is_valid=True, filepath=filepath,
            chrom_name=mt_chrom, chrom_length=length,
            mean_coverage=mean_val, min_coverage=min_val, max_coverage=max_val,
            none_bin_count=none_count, error=None,
        )

    @classmethod
    def read_coverage(
        cls,
        filepath: str,
        chrom: str,
        genome_length: int,
        n_bins: int = 500,
        normalisation: str = 'percentile',
    ) -> np.ndarray:
        """
        Read binned coverage from a BigWig file, normalised to [0, 1].

        Args:
            filepath:      Path to .bw / .bigwig file.
            chrom:         Chromosome name to query (e.g. 'chrM' or 'MT').
                           Use BigWigReader.validate() first to discover the correct name.
            genome_length: Length of the chromosome in bp.
            n_bins:        Number of bins to divide the genome into (default 500).
            normalisation: 'log1p' (default) or 'linear'.
                           log1p strongly recommended for mtDNA where coverage
                           can vary 100-fold between regions.

        Returns:
            numpy array of shape (n_bins,) with values in [0, 1].
            Empty bins (None from pyBigWig) are treated as 0.
        """
        pyBigWig = cls._require_pybigwig()

        bw = pyBigWig.open(filepath)
        try:
            raw = bw.stats(chrom, 0, genome_length, type="mean", nBins=n_bins)
        finally:
            bw.close()

        values = np.array([v if v is not None else 0.0 for v in raw], dtype=float)

        if normalisation == 'log1p':
            values = np.log1p(values)
            max_val = values.max()
            if max_val > 0:
                values /= max_val
        elif normalisation == 'percentile':
            p_low  = float(np.percentile(values, 2))
            p_high = float(np.percentile(values, 98))
            values = np.clip(values, p_low, p_high)
            span = p_high - p_low
            if span > 0:
                values = (values - p_low) / span
            else:
                values = np.zeros_like(values)
        elif normalisation == 'linear':
            max_val = values.max()
            if max_val > 0:
                values /= max_val
        else:
            raise ValueError(
                f"Unknown normalisation '{normalisation}': use 'percentile', 'log1p' or 'linear'"
            )

        logger.debug(
            "read_coverage: %s  chrom=%s  bins=%d  norm=%s",
            filepath, chrom, n_bins, normalisation,
        )
        return values