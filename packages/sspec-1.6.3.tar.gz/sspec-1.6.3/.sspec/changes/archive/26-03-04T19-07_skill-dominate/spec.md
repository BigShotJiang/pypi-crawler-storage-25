---
name: skill-dominate
status: DONE
type: bugfix
change-type: single
created: 2026-03-04 19:07:51
reference:
- source: .sspec/requests/archive/26-03-04T18-37_skill-dominate.md
  type: request
  note: Linked from request
archived: '2026-03-04T19:28:03'
---
<!-- @RULE: Frontmatter
status: PLANNING | DOING | REVIEW | DONE | BLOCKED
change-type: single | sub
reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'prev-change' |'doc', note?}>

Sub-change MUST link root:
reference:
  - source: ".sspec/changes/<root-change-dir>"
    type: "root-change"
    note: "Phase <n>: <phase-name>"

Single-change common reference:
reference:
  - source: ".sspec/requests/<request-file>.md"
    type: "request"
  - source: ".sspec/changes/<change-dir>"
    type: "prev-change"
    note: "This change is a follow-up to <change-name> which introduced <feature/bug>. This change addresses <issue> with that feature/bug."
-->

# skill-dominate

## A. Problem Statement
`sspec skill dominate .claude` can create a valid spoke link, but it leaves project metadata and ignore behavior inconsistent: missing `skill_install_strategies[".claude/skills"]` breaks install-strategy observability/recovery, and missing `.claude/.gitignore` (`skills`) can cause spoke path noise in Git workflows.

<!-- @RULE: Quantify impact. Format: "[metric] causing [impact]".
Simple: single paragraph. Complex: split "Current Situation" + "User Requirement". -->

## B. Proposed Solution
通过在 `skill dominate` 命令成功路径补齐两类“后置状态同步”，让 dominate 行为与 `project init/update` 的 hub-spoke 约定保持一致。

### Approach
在不改动 `dominate_skills_location()` 核心链接/合并逻辑的前提下，仅增强命令层收尾：

1) 记录元数据时同时更新 `skill_locations` 与 `skill_install_strategies`；
2) 在 dominated 目录父层写入受管 `.gitignore` block，确保 `skills` 被忽略。

选择命令层修复而非服务层改造，原因是这两个动作都属于“CLI 侧状态落盘与仓库协作体验”责任，不影响底层 link/merge 的纯业务判断，可最小化改动面与回归风险。

### Key Design
**Fix A: Dominate 元数据补齐**

#### Interface Design
```python
def _record_dominate_location(
    sspec_root: Path,
    dominate_dir: Path,
    *,
    strategy: str,
) -> None:
    """Persist dominated spoke location + strategy into `.sspec/.meta.json`."""
```

写入规则：
- `skill_locations`：补充 `<dominate_dir>/skills`（project-relative posix；若在项目外则 absolute posix）
- `skill_install_strategies`：写入同一 key，对应 `result.link_kind`（`symlink|junction|copy`）

**Fix B: Spoke 父目录 gitignore 补齐**

#### Interface Design
```python
def _ensure_spoke_gitignore(dominate_dir: Path) -> None:
    """Ensure `<dominate_dir>/.gitignore` ignores `skills` via managed fence block."""
```

实现方式：复用 `SkillInstaller.add_skill_to_gitignore(dominate_dir / "skills")`，由 installer 统一维护 fence block 幂等行为。

#### Data Flow
```text
sspec skill dominate <dir>
  │
  ├── dominate_skills_location(sspec_root, dominate_dir)
  │     └── returns status/link_kind/target_dir/source_dir
  │
  ├── if status in {linked,relinked,merged,skipped}
  │     ├── _record_dominate_location(..., strategy=result.link_kind)
  │     └── _ensure_spoke_gitignore(dominate_dir)
  │
  └── print result summary
```

`_ensure_spoke_gitignore` 只写父目录 `.gitignore` 的 `skills` 规则，不在逻辑上把 spoke 目录视作可跟踪源。

#### Key Logic
- 仅在成功状态更新元数据/忽略规则，避免 `needs_relink` 等未生效场景产生虚假记录。
- `skipped` 仍执行补齐，保证历史项目可被幂等修复（已有 link 但缺少 meta 或 `.gitignore`）。

#### Scope Summary
| File | Change |
|------|--------|
| `src/sspec/commands/skill.py` | Dominate 后置流程新增：同时记录 strategy，并写 spoke 父目录 `.gitignore` |
| `tests/test_skill_command_error_handling.py` | 补充 dominate 成功路径行为测试（meta + gitignore） |
| `tests/test_skill_dominate_service.py` | 保持现有服务测试，覆盖 dominate 核心路径不回归 |
| `tests/test_project_command.py` | 修正 schema 断言避免版本硬编码导致的全量测试失败 |
