---
change: "skill-dominate"
updated: "2026-03-04 19:23:00"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: Dominate metadata & gitignore fix ✅
- [x] Update dominate metadata persistence in `src/sspec/commands/skill.py`
- [x] Add spoke-parent gitignore sync in `src/sspec/commands/skill.py`
- [x] Add command-level regression test in `tests/test_skill_command_error_handling.py`
**Verification**: `uv run pytest tests/test_skill_command_error_handling.py tests/test_skill_dominate_service.py`

### Feedback Tasks ✅
- [x] Fix unrelated full-suite failure in `tests/test_project_command.py` by asserting `SCHEMA_VERSION`
**Verification**: `uv run pytest tests -q`

<!-- @RULE: Organize by phases. Each task <2h, independently testable.
Phase emoji: ⏳ pending | 🚧 in progress | ✅ done

### Phase 1: <name> ⏳
- [ ] Task description `path/file.py`
- [ ] Task description `path/file.py`
**Verification**: <how to verify this phase>

### Feedback Tasks
Use this section for tasks added during review/feedback loop.
-->

---

## Progress

Implemented command-layer dominate post-sync behavior and added regression coverage.

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |

**Recent**:
- Implemented metadata strategy persistence and spoke-parent `.gitignore` sync.
- Added command-level regression test and passed targeted pytest.
- Fixed full-suite flaky expectation (`9.1` hardcode) and now full tests pass.
