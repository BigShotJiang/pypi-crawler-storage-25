---
change: "meta-update-hardening"
updated: "2026-03-03"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: Meta Schema Strictness ⏳
- [x] Treat declared-but-unparseable `meta_schema`/`meta_schema_version` as error (do not coerce to `0.0`) `src/sspec/services/meta_service.py`
- [x] Ensure `load_meta()` / non-update call sites fail with CLI-friendly error (no traceback) when meta schema is future/invalid `src/sspec/services/meta_service.py`
**Verification**: `uv run pytest -q` (schema strictness tests); manually set `.sspec/.meta.json` to `{"meta_schema":"2.0-beta"}` and confirm `sspec project update --dry-run` errors cleanly.

### Phase 2: Project Update Correctness (Unknown/Hashes) ⏳
- [x] Do not print "All files are up to date" when any candidate is `unknown` or `modified` and blocks safe update `src/sspec/commands/project.py`
- [x] When `file_hashes` missing/empty, backfill hashes for verifiably `current` candidates so the project becomes updateable without `--force` `src/sspec/commands/project.py`
- [x] Ensure migration-only write path also persists `file_hashes`/`managed_skills` when needed `src/sspec/commands/project.py`
**Verification**: construct a project with empty `.meta.json` and verify `project update --dry-run` reports blockers; run non-dry-run and verify `.meta.json` gains hashes for current files.

### Phase 3: Path Normalization & Input Validation ⏳
- [x] Normalize `skill_locations` storage to POSIX (`as_posix()`) during init `src/sspec/services/project_init_service.py`
- [x] Normalize/clean existing `skill_locations` during meta upgrade (optional if minimal) `src/sspec/services/meta_service.py`
- [x] `skill dominate` resolves relative paths from project root (not CWD) `src/sspec/commands/skill.py`
- [x] `skill dominate` records location even if already linked (`skipped`) `src/sspec/commands/skill.py`
- [x] Validate skill name to prevent path traversal `src/sspec/services/skill_service.py`
- [x] Validate `--skill-loc` and custom path input: must be relative and inside project root `src/sspec/commands/project.py`
**Verification**: add tests for path validation and normalization; manually run `sspec skill dominate .claude` from a nested directory.

### Phase 4: Bug Fixes (Small but Critical) ⏳
- [x] Remove duplicate/unreachable return in `create_skill_in_hub()` `src/sspec/services/skill_service.py`
**Verification**: `uv run ruff check src tests`

### Phase 5: Tests ⏳
- [x] Add tests for invalid schema marker (declared but unparsable) `tests/test_meta_service.py`
- [x] Add tests ensuring `project update` doesn't claim up-to-date with unknown candidates and backfills hashes `tests/test_project_command.py`
- [x] Add tests for `--skill-loc` and skill name validation `tests/`
**Verification**: `uv run pytest -q`

<!-- @RULE: Organize by phases. Each task <2h, independently testable.
Phase emoji: ⏳ pending | 🚧 in progress | ✅ done

### Phase 1: <name> ⏳
- [ ] Task description `path/file.py`
- [ ] Task description `path/file.py`
**Verification**: <how to verify this phase>

### Feedback Tasks
Use this section for tasks added during review/feedback loop.
-->

---

## Progress

- Status: DONE
- Notes: Implemented hardening fixes; lint + full test suite passing.

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |
| Phase 4 | 100% | ✅ |
| Phase 5 | 100% | ✅ |

**Recent**:
- Implemented strict meta_schema parsing + CLI-friendly errors
- Fixed project update blockers messaging + hash backfill
- Normalized/validated skill location paths + skill names; fixed dominate skipped recording
- Hardened `skill new` to handle filesystem errors cleanly
- Hardened questionary prompts to avoid crashing in non-interactive consoles
- Added tests; `uv run pytest -q` passes
