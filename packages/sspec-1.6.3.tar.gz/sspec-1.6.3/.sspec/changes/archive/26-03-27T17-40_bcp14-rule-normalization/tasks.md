---
change: "bcp14-rule-normalization"
updated: "2026-03-27T18:36"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: Audit normalization scope ✅
- [x] Inventory the main rule-bearing template files under `src/sspec/templates/`
- [x] Record BCP 14 consistency risks and duplicate hotspots in `reference/bcp14-audit.md`
- [x] Draft `spec.md` to define the conservative normalization approach and target files
**Verification**: `spec.md` references the audit file and predicts both wording changes and unchanged workflow boundaries

### Phase 2: Normalize protocol wording ✅
- [x] Add a concise BCP 14 declaration to `src/sspec/templates/AGENTS.md`
- [x] Normalize rule-strength wording in core phase SKILLs under `src/sspec/templates/skills/`
- [x] Normalize rule-strength wording in `src/sspec/templates/change/` and `src/sspec/templates/change-root/` templates
**Verification**: Target files consistently use BCP 14 keywords for normative rules and avoid competing markers where the text is meant as protocol language

### Phase 3: Sync self-hosted copies and verify ✅
- [x] Run `uv pip install -e .`
- [x] Run `uv run sspec project update`
- [x] Run focused checks to confirm generated `.sspec/skills/` and root `AGENTS.md` reflect the template edits
**Verification**: Synced generated copies match the normalized templates and no stale wording remains in managed outputs

### Phase 4: Address staged review feedback ✅
- [x] Expand the BCP 14 keyword list in `src/sspec/templates/AGENTS.md`
- [x] Restore stronger handover wording for context-compression risk
- [x] Fix awkward subject-less normative phrasing in template comments and bullets
**Verification**: Review findings are resolved without broadening scope beyond wording consistency

## Progress

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |
| Phase 4 | 100% | ✅ |

**Recent**:
- Completed: expanded the BCP 14 keyword declaration and fixed review-flagged wording issues
- Completed: re-synced managed copies and verified the updated root `AGENTS.md` plus `.sspec/skills/` outputs
