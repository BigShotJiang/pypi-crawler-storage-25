# BCP 14 Audit

Initial reconnaissance for change `bcp14-rule-normalization`.

## Goal

Establish where SSPEC template text currently uses normative rule language, where that wording is inconsistent with BCP 14 style, and which duplicate hotspots should be normalized first.

## Findings Summary

### 1. No explicit BCP 14 declaration

No `BCP 14`, `RFC 2119`, or `RFC 8174` declaration was found under `src/sspec/templates/`.
That means current uppercase keywords like `MUST` are not yet formally anchored to a shared interpretation.

### 2. Normative rule language is spread across multiple template layers

Highest-signal rule-bearing files from the scan:

- `src/sspec/templates/AGENTS.md`
- `src/sspec/templates/skills/sspec-align/SKILL.md`
- `src/sspec/templates/skills/sspec-design/SKILL.md`
- `src/sspec/templates/skills/sspec-plan/SKILL.md`
- `src/sspec/templates/skills/sspec-implement/SKILL.md`
- `src/sspec/templates/skills/sspec-review/SKILL.md`
- `src/sspec/templates/skills/sspec-handover/SKILL.md`
- `src/sspec/templates/skills/sspec-research/SKILL.md`
- `src/sspec/templates/change/spec.md`
- `src/sspec/templates/change/tasks.md`
- `src/sspec/templates/change/handover.md`
- `src/sspec/templates/change-root/spec.md`
- `src/sspec/templates/change-root/tasks.md`
- `src/sspec/templates/change-root/handover.md`

### 3. Mixed strength markers currently blur rule severity

Observed markers include:

- BCP-14-like: `MUST`, `SHOULD`, `MAY`, `MUST NOT`
- non-BCP but strong: `MANDATORY`, `FORBIDDEN`, `ALWAYS`, `STOP`, `hard gate`
- lowercase normative prose: `must`, `should`, `never`, `do not`, `must not`

This makes it harder for an independent Agent to compare requirement strength across files.

### 4. Duplicate rule hotspots

The same policies are restated in multiple files, sometimes with different strength wording:

- handover is required at session end
- design requires user confirmation before planning
- `Git Baseline (Immutable)` is read-only
- follow-up / replacement / split work requires `@align`
- do not copy design details into `tasks.md`
- question-tool fallback behavior for `@align`
- spec-doc follow-up after architectural changes

## Normalization Target

This change should normalize wording, not redesign workflow semantics.

### Preferred mapping

- hard requirement → `MUST` / `MUST NOT`
- strong recommendation → `SHOULD` / `SHOULD NOT`
- permission / optional path → `MAY`
- plain descriptive prose stays plain prose

### Avoid where possible

- `MANDATORY`
- `FORBIDDEN`
- `ALWAYS`
- lowercase `must` / `should` when the text is meant to express a protocol rule keyword

## Notes

- Source: `explore` subagent audit performed during design.
- This file is a change-local research artifact, not a long-lived spec-doc.
