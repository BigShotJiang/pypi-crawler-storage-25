---
name: bcp14-rule-normalization
status: DONE
type: ''
change-type: single
created: 2026-03-27 17:40:02
reference:
- source: .sspec/changes/archive/26-03-27T17-40_bcp14-rule-normalization/reference/bcp14-audit.md
  type: doc
  note: Initial audit of normative rule language and duplication hotspots
archived: '2026-03-27T18:38:45'
---
<!-- @RULE: Frontmatter
status: PLANNING | DOING | REVIEW | DONE | BLOCKED
change-type: single | sub
reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'prev-change' |'doc', note?}>

Sub-change MUST link root:
reference:
  - source: ".sspec/changes/<root-change-dir>"
    type: "root-change"
    note: "Phase <n>: <phase-name>"

Single-change common reference:
reference:
  - source: ".sspec/requests/<request-file>.md"
    type: "request"
  - source: ".sspec/changes/<change-dir>"
    type: "prev-change"
    note: "This change is a follow-up to <change-name> which introduced <feature/bug>. This change addresses <issue> with that feature/bug."
-->

# bcp14-rule-normalization

## A. Problem Statement

### Current Situation

SSPEC template protocol text currently mixes several kinds of rule language across `AGENTS.md`, core phase SKILLs, and change templates: uppercase keywords such as `MUST`, non-BCP strength markers such as `MANDATORY` / `FORBIDDEN` / `ALWAYS`, and lowercase normative prose such as `must`, `should`, and `do not`. No explicit BCP 14 declaration exists in the template set. That inconsistency makes it harder for an independent Agent to compare rule strength across files and weakens the protocol's readability as a rule system.

### User Requirement

Introduce a clear BCP 14 interpretation rule for SSPEC normative keywords, starting in `AGENTS.md`, then scan and normalize the core template protocol so hard requirements, recommendations, and permissions use consistent wording. Keep workflow semantics unchanged; this change is about rule language clarity and consistency, not a lifecycle redesign.

<!-- @RULE: Quantify impact. Format: "[metric] causing [impact]".
Simple: single paragraph. Complex: split "Current Situation" + "User Requirement". -->

## B. Proposed Solution

<!-- @RULE: Accepted review-stage changes belong here as formal design.
If user feedback changes the current change's scope/design and the work still belongs to this change,
update A/B directly instead of leaving the accepted change only in handover.md.
If review history matters, add `### Review Amendments` under B as part of the design. -->

### Approach

Treat this as an audit-first wording normalization change.

First, add an explicit BCP 14 declaration to the SSPEC protocol entry point so Agents have a single interpretation rule for normative keywords. Then normalize the main rule-bearing templates to use uppercase BCP 14 keywords only when the text is intended as protocol language, while keeping descriptive or explanatory prose in normal sentence case.

This approach is intentionally conservative: it improves clarity without redesigning lifecycle phases, state transitions, or document ownership boundaries. The implementation should prefer semantic preservation over mechanical keyword replacement.

### Key Design

#### Content Outline

The revised protocol wording should follow this structure:

```text
AGENTS.md
  - Add one explicit BCP 14 rule-language note near the protocol overview/reference area
  - Clarify that all-caps keywords carry normative meaning; ordinary prose does not

Core SKILLs and change templates
  - Normalize hard requirements to MUST / MUST NOT
  - Normalize recommendations to SHOULD / SHOULD NOT where appropriate
  - Normalize optional paths and permissions to MAY where appropriate
  - Remove or reduce competing strength markers such as MANDATORY / FORBIDDEN / ALWAYS
  - Keep plain explanatory text as plain prose instead of forcing every sentence into keyword form

Audit coverage
  - Primary targets: AGENTS + core phase SKILLs + change/change-root templates
  - Secondary targets: other template docs only when they act like protocol rules or repeat core rule text
```

#### Migration Path

```text
Before
  Mixed rule markers:
  MUST / must / MANDATORY / FORBIDDEN / ALWAYS / never / do not

After
  One declared interpretation rule:
  BCP 14 keywords apply when, and only when, they appear in all capitals.

  Normalized usage:
  - hard requirement -> MUST / MUST NOT
  - recommendation -> SHOULD / SHOULD NOT
  - permission / optional path -> MAY
  - explanation / rationale -> normal prose
```

### Key Change

**Rule A: BCP 14 declaration** — `src/sspec/templates/AGENTS.md` MUST state that SSPEC normative rule keywords are to be interpreted according to BCP 14 (RFC 2119 / RFC 8174) when, and only when, they appear in all capitals. The wording SHOULD be concise and placed where future Agents will see it before reading the rest of the protocol.

**Fix B: Keyword normalization across core protocol templates** — Core rule-bearing templates SHOULD be normalized so equivalent requirement strength uses equivalent keywords. Hard requirements become `MUST` / `MUST NOT`; strong recommendations become `SHOULD` / `SHOULD NOT`; optional paths become `MAY` where permission is intended.

**Fix C: Competing strength markers removal** — Terms such as `MANDATORY`, `FORBIDDEN`, and `ALWAYS` SHOULD be removed or rewritten when they are functioning as protocol keywords. They MAY remain only when they are part of non-normative explanation or rhetorical emphasis and do not compete with the BCP 14 vocabulary.

**Fix D: Duplicate hotspot harmonization** — Repeated rules such as handover requirements, design confirmation, immutable git baseline handling, `@align` gating behavior, and design-vs-tasks boundaries SHOULD use consistent normative strength across their duplicate locations unless a file intentionally narrows or broadens the rule.

**Ref E: Audit-backed implementation** — The initial normalization pass MUST be guided by the change-local audit in `reference/bcp14-audit.md` so edits are traceable and focused. If scan coverage expands during implementation, the audit notes SHOULD be updated before or alongside the wording edits.

### Scope Summary

| File | Change |
|------|--------|
| `src/sspec/templates/AGENTS.md` | Add BCP 14 interpretation note and normalize core protocol wording hotspots |
| `src/sspec/templates/skills/sspec-align/SKILL.md` | Normalize rule-strength wording for `report` / `gate`, fallback ask flow, and record-keeping guidance |
| `src/sspec/templates/skills/sspec-design/SKILL.md` | Normalize design gate and format requirement wording |
| `src/sspec/templates/skills/sspec-plan/SKILL.md` | Normalize planning requirements and verification wording |
| `src/sspec/templates/skills/sspec-implement/SKILL.md` | Normalize execution and pause-condition wording |
| `src/sspec/templates/skills/sspec-review/SKILL.md` | Normalize review-loop restrictions and completion rules |
| `src/sspec/templates/skills/sspec-handover/SKILL.md` | Normalize session-end and handover-record requirements |
| `src/sspec/templates/skills/sspec-research/SKILL.md` | Normalize research-phase no-code and question-trigger wording where it is intended as protocol guidance |
| `src/sspec/templates/change/spec.md` | Normalize `@RULE` comments and mandatory section wording |
| `src/sspec/templates/change/tasks.md` | Normalize follow-up/replacement gating wording in `@RULE` comments |
| `src/sspec/templates/change/handover.md` | Normalize immutable baseline and session-log wording |
| `src/sspec/templates/change-root/spec.md` | Normalize root-template `@RULE` wording where needed |
| `src/sspec/templates/change-root/tasks.md` | Normalize milestone-template `@RULE` wording where needed |
| `src/sspec/templates/change-root/handover.md` | Normalize immutable baseline and session-log wording for root changes |
| `.sspec/changes/archive/26-03-27T17-40_bcp14-rule-normalization/reference/bcp14-audit.md` | Maintain audit notes that justify normalization scope and hotspot selection |

### What Stays Unchanged

- Research → Design → Plan → Implement → Review → Handover lifecycle
- `@align` two-level model (`report` / `gate`)
- `spec.md` / `tasks.md` / `handover.md` ownership boundaries
- root vs sub-change workflow
- existing change-status state machine and review gate semantics
