# Handover: bcp14-rule-normalization

**Updated**: 2026-03-27T18:40

---

## Background

This change introduces an explicit BCP 14 interpretation rule for SSPEC protocol language, then normalizes core template wording to use consistent normative keywords. The scope is intentionally conservative: improve rule clarity without changing lifecycle semantics.

## Git Baseline (Immutable)
<!-- Captured during `sspec change new` before any change files are written.
This section records the change starting point in git and must not be edited or refreshed later. -->

- Captured: before change file creation
- Repository: `H:/SrcCode/playground/sspec`
- Branch: `main`
- HEAD: `7faa2a4fba76a09d9a35a5ef59873e001b4357ec`
- Worktree: `clean`
- Status Snapshot: raw `git status --short --branch` output

```text
## main...origin/main
```

## Working Memory (Stable)
<!-- Curated, long-lived context. Survives context compression and session boundaries.
If something becomes obsolete, mark it as obsolete with a timestamp instead of deleting silently. -->

### Key Files
- `src/sspec/templates/AGENTS.md` - protocol entry point; now declares the expanded BCP 14 keyword list for SSPEC Rule text
- `src/sspec/templates/skills/sspec-handover/SKILL.md` - largest wording normalization hotspot; follow-up review restored stronger wording for context-compression handover triggers
- `src/sspec/templates/skills/sspec-design/SKILL.md` - design gate and spec-boundary wording were normalized without changing lifecycle behavior
- `src/sspec/templates/change/spec.md` - template comments now use clearer normative wording for mandatory spec sections
- `.sspec/changes/archive/26-03-27T17-40_bcp14-rule-normalization/reference/bcp14-audit.md` - audit note capturing hotspot inventory and preferred normalization mapping

### Durable Memory (Typed, Timestamped)
- [2026-03-27T17:43] [Decision] This change is wording normalization only; workflow semantics MUST stay unchanged unless the user later expands scope.
- [2026-03-27T17:43] [VitalFinding] `src/sspec/templates/` currently has no explicit BCP 14 declaration, so uppercase keywords lack a formal shared interpretation anchor.
- [2026-03-27T17:43] [Constraint] Template changes MUST be made only under `src/sspec/templates/`, then synced with `uv run sspec project update`.
- [2026-03-27T17:43] [Risk] Mechanical replacement of words like `MANDATORY` or lowercase `must` could accidentally change semantics; each hotspot needs meaning-preserving review.
- [2026-03-27T17:43] [VerificationShortcut] Re-scan `src/sspec/templates/` for `MANDATORY|FORBIDDEN|ALWAYS|\bmust\b|\bshould\b|\bmust not\b` after edits to catch leftover inconsistent normative wording.
- [2026-03-27T17:57] [Decision] The initial normalization pass focused on `AGENTS.md`, the six core phase skills most directly involved in SSPEC workflow control, and change/change-root templates; auxiliary skills such as `write-spec-doc` and `use-powershell` were left for later passes.
- [2026-03-27T17:57] [VitalFinding] Root `AGENTS.md` and managed `.sspec/skills/` copies updated cleanly after `uv run sspec project update`, confirming the template-source-only workflow held.
- [2026-03-27T18:36] [Decision] Review follow-up kept `SHOULD` wording where the user preferred softer strength, but restored stronger wording for handover-trigger guidance tied to context-loss risk.
- [2026-03-27T18:36] [VitalFinding] Expanding the BCP 14 keyword list in `AGENTS.md` resolved the internal inconsistency introduced by `REQUIRED` in normalized template text.

## Session Log (Append-Only)
<!-- Newest entry first. Each entry is an atomic batch (one cohesive work record).

Header format:
### 2026-03-06T20:39 [work-log] <short title>

Tags are freeform but must be readable. Examples: work-log, user-feedback, argue, risk.
Any user interaction (feedback, @align, @argue) MUST start a new log entry. -->

### 2026-03-27T18:40 [user-feedback] approve archive and commit

**Accomplished**
- User accepted the BCP 14 normalization follow-up and requested archiving plus commit
- Synced the change record to a completed state so archive can reflect the accepted result cleanly

**Next**
- Archive the change directory
- Commit the staged diff with a templates-focused message

**Notes**
- User acceptance serves as the review completion signal for this change

### 2026-03-27T18:36 [user-feedback] apply staged review fixes

**Accomplished**
- Reviewed subagent audit findings with the user and accepted a targeted follow-up pass
- Expanded the BCP 14 declaration to include `REQUIRED`, `SHALL`, `SHALL NOT`, `RECOMMENDED`, and `OPTIONAL`
- Restored stronger handover wording for context-compression risk
- Added explicit subjects to awkward normative sentences in `change-root/spec.md` and `change/tasks.md`
- Improved the `sspec-implement` bullet to read naturally while keeping `MUST NOT`
- Reinstalled and re-synced managed outputs, then verified updated matches in template and root `AGENTS.md`

**Next**
- Present the updated staged-review result to the user
- If accepted, the change can stay in review-ready state pending commit or broader follow-up work

**Notes**
- Per user instruction, this follow-up kept `SHOULD`-level wording where softer strength was acceptable and only strengthened handover text where urgency matters

### 2026-03-27T17:57 [work-log] implement BCP 14 normalization pass

**Accomplished**
- Diagnosed repeated edit-tool failures as invalid mixed-mode `edit` calls and switched to `patch-edit`
- Added the BCP 14 declaration to `src/sspec/templates/AGENTS.md`
- Normalized wording in core phase skills and change templates to prefer MUST / MUST NOT / SHOULD phrasing over mixed markers such as `MANDATORY`, `FORBIDDEN`, and `ALWAYS`
- Reinstalled the package and ran `uv run sspec project update`
- Verified that root `AGENTS.md` and managed `.sspec/skills/` copies reflected the template changes

**Next**
- Present implementation completion for user review
- If accepted, optionally plan a second-pass change to extend BCP 14 normalization into auxiliary skills and repo-level development protocol text above the managed SSPEC block

**Notes**
- Focused residual scan shows the new BCP 14 declaration in template and synced root `AGENTS.md`; remaining lowercase `must` matches in the repo are outside this change scope or appear in non-target auxiliary skills

### 2026-03-27T17:43 [work-log] create BCP 14 normalization change

**Accomplished**
- Created change `26-03-27T17-40_bcp14-rule-normalization`
- Read `write-agents` and `pi-subagent` skills because the work touches protocol text and benefits from delegated scanning
- Used `explore` subagent to scan template protocol files for normative wording, duplicate hotspots, and likely BCP 14 inconsistencies
- Wrote `reference/bcp14-audit.md`, filled `spec.md`, and created phased `tasks.md`

**Next**
- Present the proposed change design to the user as the mandatory design gate
- If approved, normalize wording in template sources only, then reinstall and sync managed copies

**Notes**
- The exploratory scan highlighted repeated hotspots around handover requirements, design confirmation, git-baseline immutability, and `@align` fallback behavior
