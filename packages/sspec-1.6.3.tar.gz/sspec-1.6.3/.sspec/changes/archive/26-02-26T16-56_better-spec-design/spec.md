---
name: better-spec-design
status: REVIEW
type: ''
change-type: single
created: 2026-02-26 16:56:37
reference:
- source: .sspec/requests/26-02-26T16-42_better-spec-design.md
  type: request
  note: Linked from request
archived: '2026-03-03T20:19:07'
---
<!-- @RULE: Frontmatter
status: PLANNING | DOING | REVIEW | DONE | BLOCKED
change-type: single | sub
reference?: Array<{source, type: 'request'|'root-change'|'sub-change'|'prev-change' |'doc', note?}>

Sub-change MUST link root:
reference:
  - source: ".sspec/changes/<root-change-dir>"
    type: "root-change"
    note: "Phase <n>: <phase-name>"

Single-change common reference:
reference:
  - source: ".sspec/requests/<request-file>.md"
    type: "request"
  - source: ".sspec/changes/<change-dir>"
    type: "prev-change"
    note: "This change is a follow-up to <change-name> which introduced <feature/bug>. This change addresses <issue> with that feature/bug."
-->

# better-spec-design

## A. Problem Statement

The `sspec-design` SKILL describes *what elements* must appear in Section B (interfaces, data flow, logic) but not *how* they must be expressed. Models default to dense prose, producing specs that are correct in structure but weak in clarity — hard to review, hard to audit, and hard to implement from.

Concrete evidence from two real specs in `sy-f-misc`:

- **`other-provide-type/spec.md`** (older): Interface Design section lists fields and new modules in prose. No code blocks for signatures, no data-flow diagrams, no scope summary. Technically complete but requires the reader to mentally reconstruct what changes where.
- **`feedback-from-others/spec.md`** (better): Each fix is labeled (Fix A–G), every interface change shows a typed code block with `// ADD` annotations, data flow is shown as an ASCII tree, and a Scope Summary table (`File | Changes`) closes Key Design. Implementation intent is immediately graspable.

The better spec, and the accompanying `src/func/gpt/openai/README.md` (Architecture Overview, Tool Call Lifecycle sections), demonstrate that three presentation patterns — **code-block signatures, ASCII flow diagrams, scope summary table** — are the primary drivers of the quality gap. The SKILL currently mentions these element types but does not mandate these patterns, so the gap persists across models and sessions.

## B. Proposed Solution

### Approach

Upgrade `sspec-design` SKILL.md (and related templates/examples) with explicit, pattern-level prescription. Two categories of change:

**Category 1 — Presentation Rules for spec.md Section B**: Add mandatory "Presentation Rules" to the SKILL — four rules that govern *how* design content must be expressed, not just *what* to include. Update Single Change and Root Change sections accordingly, keeping them separate.

**Category 2 — Structural separation of Single vs. Root**: The current SKILL mixes single-change and root-change guidance in one Step 3. Separate them into Step 3 (Single) and Step 4 (Root) with parallel structure and dedicated examples.

Why SKILL + examples, not template enforcement: spec.md templates are intentionally minimal (structure only). Writing quality guidance belongs in the SKILL. Examples are the highest-leverage lever — models pattern-match to them.

### Presentation Rules (Rule 1–4)

To be added to SKILL.md after "What MUST appear in B":

**Rule 1 — Code blocks for interfaces**

Any interface, signature, or type definition MUST appear in a fenced typed code block. Prose is supplementary only.

```python
# ✅ Good — concrete, typed, annotatable
@dataclass
class ChangeRef:
    source: str            # workspace-relative path
    type: RefType          # 'request' | 'root-change' | 'sub-change' | 'doc'
    note: str | None = None  # NEW: optional annotation
```

```
# ❌ Bad — reader must mentally reconstruct the shape
Add an optional `note` field to ChangeRef. It stores an annotation string.
```

**Rule 2 — ASCII diagrams for data flow**

Any data-flow or call-path description MUST include an ASCII tree or flowchart (using `│ ├── └──` notation). A diagram + short accompanying text is the target form; text-only is insufficient.

```
# ✅ Good — tree diagram with companion text
sspec change new --from <req>
  │
  ├── parse_request(req_path)       → reads frontmatter
  ├── create_change_dir(name)       → mkdir .sspec/changes/<timestamp>_<name>/
  ├── copy_templates()              → spec.md, tasks.md, handover.md
  └── link_request(req, change)     → writes reference in both directions

The `link_request` step is bidirectional: request frontmatter gets
`attach-change` updated; spec.md `reference` gets a `type: request` entry.
```

```
# ❌ Bad — text-only narration
When creating a change from a request, the system reads the request, creates a
directory, copies templates, then links them bidirectionally.
```

**Rule 3 — Scope Summary Table**

Key Design MUST end with a `File | Change` table for changes affecting ≥3 files. This gives reviewers and implementers a fast orientation map.

```markdown
### Scope Summary
| File | Change |
|------|--------|
| `src/sspec/services/change_service.py` | Add `--from-request` linking logic |
| `src/sspec/templates/change/spec.md`   | Update Key Design comment |
| `src/sspec/templates/AGENTS.md`        | (no change needed) |
```

**Rule 4 — Change Item Labeling**

For changes with ≥3 independent items (fixes, features, or refactors), label each item in Section B (Label A, B, C… or descriptive slug). This creates stable cross-references for tasks.md.

```markdown
# ✅ Good — labeled, addressable
**Fix A: Token name reconstruction** — Add `name` to `IToolMessage`; use directly in adapter.
**Feat B: Multimodal image** — Handle `image_url` parts in message conversion.
**Refactor C: ID stability** — Replace `Date.now()` with per-invocation counter.

# In tasks.md:
- [ ] Implement Fix A per spec §B
- [ ] Implement Feat B per spec §B
```

```markdown
# ❌ Bad — unlabeled, tasks.md must repeat the design
### Interface Changes
Add name to IToolMessage. Update adapter to use it.
### Multimodal
Handle image_url in toGeminiContents.
```

### Structural Separation: Single vs. Root

Current SKILL.md Step 3 mixes both. Change to:

- **Step 3: Fill Single Change spec.md** (current Step 3 content, cleaned up, with Presentation Rules added)
- **Step 4: Fill Root Change spec.md** (extracted from current "Root Change" sub-section, elevated to a top-level step with same Presentation Rules adapted for phase-level thinking)

Root Change Step 4 additions:
- Phase Overview should use the same diagram/table conventions but at phase scope (each phase is a row in a dependency table, or a branch in an ASCII dependency tree)
- Root spec.md does NOT use Scope Summary (it belongs in sub-change specs)

### Template File Adjustments

**`src/sspec/templates/change/spec.md`**: Strengthen the `### Key Design` comment to reference the Presentation Rules:
```
<!-- Follow SKILL.md Presentation Rules:
  Rule 1: interfaces/types → typed code block (not prose)
  Rule 2: data flow → ASCII diagram (│ ├── └── notation) + text
  Rule 3: ≥3 files → Scope Summary Table at end
  Rule 4: ≥3 independent items → label each (Fix A / Feat B / Refactor C…) -->
```

**`src/sspec/templates/change-root/spec.md`**: Strengthen the `### Phase Overview` comment to reference Rule 1–2 equivalents at phase level (e.g. dependency trees between phases).

**`src/sspec/templates/AGENTS.md`**: Review whether §2 Change Workflow table (Phase → SKILL → Files) needs updating to reflect Step 4. Likely minimal or no change needed since the AGENTS block only references the SKILL by name.

### examples.md Updates

Replace the current medium example with one that:
- Uses a **sspec-domain scenario** (e.g. a change to sspec's own `change_service.py`) — not LLM-adapter-specific
- Shows Rule 1 (typed code block with annotations)
- Shows Rule 2 (ASCII tree for the service call flow)
- Shows Rule 3 (Scope Summary Table)
- Shows Rule 4 (labeled items, at least 2-3)

Also ensure the Root Change example explicitly demonstrates phase-level dependency notation.

### Scope Summary

| File | Change |
|------|--------|
| `src/sspec/templates/skills/sspec-design/SKILL.md` | Add Presentation Rules 1–4; rename Step 3 → "Fill Single Change spec.md"; add Step 4 "Fill Root Change spec.md"; update References table |
| `src/sspec/templates/skills/sspec-design/examples.md` | **Delete** (replaced by two separate files below) |
| `src/sspec/templates/skills/sspec-design/examples-single.md` | **New** — single-change examples (Simple + updated Medium with all 4 rules + Complex + B→tasks boundary) |
| `src/sspec/templates/skills/sspec-design/examples-root.md` | **New** — root-change examples (Root with phase-level diagrams/tables + sub-change B guidance) |
| `src/sspec/templates/change/spec.md` | Strengthen Key Design comment |
| `src/sspec/templates/change-root/spec.md` | Strengthen Phase Overview comment for phase-level diagrams |
| `src/sspec/templates/AGENTS.md` | Review Step references; likely minor/no change |
