---
change: "better-spec-design"
updated: "2026-02-26"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: SKILL.md — Presentation Rules + Step 3/4 Split ✅
- [x] Read current `SKILL.md` Step 3 section fully to map exact lines for edits
- [x] Rename "Step 3: Fill spec.md" heading to "Step 3: Fill Single Change spec.md"
- [x] Add "Presentation Rules (Rules 1–4)" subsection after "What MUST appear in B" in Step 3 — see spec.md §B for rule text and examples
- [x] Extract root-change content from Step 3 into new "Step 4: Fill Root Change spec.md" section with parallel structure + phase-level Presentation Rule adaptations
- [x] Update `## References` table at bottom of SKILL.md: replace `examples.md` references with `examples-single.md` and `examples-root.md` entries

**Verification**: Read updated SKILL.md — Steps 3 and 4 are fully separate; Rules 1–4 appear in both with appropriate scope; References table points to split files.

### Phase 2: examples-single.md ✅
- [x] Create `src/sspec/templates/skills/sspec-design/examples-single.md` — migrate Simple + Complex + B→tasks.md Boundary sections from old `examples.md`
- [x] Update the Medium Example to use a sspec-domain scenario (change-tags feature) demonstrating all 4 Presentation Rules
- [x] Verify Medium Example contains: typed code block (Rule 1), ASCII `│ ├── └──` diagram + text (Rule 2), Scope Summary Table (Rule 3), labeled items (Rule 4)

**Verification**: File exists; medium example is sspec-domain and shows all 4 rules clearly; content is self-contained.

### Phase 3: examples-root.md ✅
- [x] Create `src/sspec/templates/skills/sspec-design/examples-root.md` — new file with two root examples
- [x] Update/expand the Root Change example to use phase-level ASCII dependency tree + dependency table (for ≥4 phases)
- [x] Add a note about what does NOT belong in root spec.md (file-level interfaces — those go in sub-change specs)

**Verification**: File exists; root example shows phase-level diagram + dependency table; the single-change Presentation Rules are adapted/excluded appropriately.

### Phase 4: Template File Updates ✅
- [x] Update `### Key Design` comment in `src/sspec/templates/change/spec.md` — added Presentation Rules 1–4 reference
- [x] Update `### Phase Overview` comment in `src/sspec/templates/change-root/spec.md` — added phase-level diagram guidance
- [x] Review `src/sspec/templates/AGENTS.md` — no change needed (references SKILL by name only)
- [x] Delete `src/sspec/templates/skills/sspec-design/examples.md` — deleted

**Verification**: Both template spec.md comments reference Presentation Rules; AGENTS.md checked; old examples.md removed.

### Phase 5: Reinstall + Verify ✅
- [x] Run `uv pip install -e .` — succeeded
- [x] Run `uv run ruff check src/` — 10 pre-existing errors (none in changed files); no new errors introduced
- [x] Verified `src/sspec/templates/skills/sspec-design/` contains `examples-single.md`, `examples-root.md`, `SKILL.md`; `examples.md` removed

**Verification**: Install succeeds; test project has `examples-single.md` + `examples-root.md` in skill dir; no ruff errors.

<!-- @RULE: Organize by phases. Each task <2h, independently testable.
Phase emoji: ⏳ pending | 🚧 in progress | ✅ done

### Phase 1: <name> ⏳
- [ ] Task description `path/file.py`
- [ ] Task description `path/file.py`
**Verification**: <how to verify this phase>

### Feedback Tasks
Use this section for tasks added during review/feedback loop.
-->

---

## Progress
<!-- @REPLACE -->

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1: SKILL.md | 100% | ✅ |
| Phase 2: examples-single.md | 100% | ✅ |
| Phase 3: examples-root.md | 100% | ✅ |
| Phase 4: Template File Updates | 100% | ✅ |
| Phase 5: Reinstall + Verify | 100% | ✅ |

**Recent**:
- 2026-02-26: All phases complete. Ready for REVIEW.
