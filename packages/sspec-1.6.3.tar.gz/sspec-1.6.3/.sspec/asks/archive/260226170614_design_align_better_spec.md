---
created: '2026-02-26T17:06:14'
name: design_align_better_spec
why: 'Design alignment checkpoint for change `better-spec-design`.

  Presenting root cause analysis and proposed solution for review before planning.'
---

**Ask**: design_align_better_spec

# User Answer #

感觉分析基本都是合理的；这几点提的也有道理
补充一些意见，不要陷入 YOLO 思考中，看到给你的 f-misc 下的样例就死板照着填充，请从第一性原理出发考虑我们需要什么

- 其实不光是 fix，其他的例如 feat 等 label 也可以放上去啊；不然只专门强调 fix 有点奇怪
- 你在 **Rule 2 — ASCII diagrams for data flow** 中给的 chart 的样例不够好，不够清晰明了，还用到了一些奇怪的符号比如 `|| ` 我感觉H:\SrcCode\SiYuanDevelopment\sy-f-misc\src\func\gpt\openai\README.md中的图表例子更加清晰；并且建议要图 + 文字配合说明更加清晰；
- 另外不要陷入必须要用 sy-f-misc 的 LLM Tool Call 的例子中作为 sspec 的样例；请独立思考在 sspec 编写的时候，使用什么样例最好、 最清晰
- 当前 sspec-design 中，对 root change 的论述还不够，和 single change 混在一起
  所以我建议： ## Step 3: Fill spec.md 明确定义为 Fill Single Change spec.md ；并增加独立的 Fill Root Change spec.md 的小姐
  并配合思考是否需要相应更新 sspec-design 下其他部分，比如 example 等
- 结合 src/sspec/templates/change, change-root 模板；考虑是否有需要微调的地方；还有 src/sspec/templates/AGENTS.md 是否有必要调整

# Agent Question History #

## Design Alignment — better-spec-design

Change: `.sspec/changes/archive/26-02-26T16-56_better-spec-design/spec.md`

---

### Root Cause (A)

The `sspec-design` SKILL describes *what elements* should appear in Section B
(interfaces, data flow, logic) but not *how* they must be expressed. This leaves
models free to use prose, which structurally satisfies the template but produces
specs that are hard to review and audit.

Evidence: comparing `other-provide-type/spec.md` (older, prose-heavy) vs.
`feedback-from-others/spec.md` (better, code-blocks + diagrams + table) in
`sy-f-misc`. The quality gap comes from three concrete presentation patterns
that the better spec uses and the older one doesn't.

---

### Proposed Solution (B)

Add four explicit **Presentation Rules** to the `sspec-design` SKILL + update
the medium example in `examples.md` to demonstrate all patterns:

**Rule 1 — Code-block interfaces**: Interface/type changes MUST appear in a
fenced typed code block, not prose. (e.g. `typescript` block showing the
`interface` with `// NEW` annotations)

**Rule 2 — ASCII diagrams for data flow**: Data-flow sections MUST include an
ASCII tree/flowchart. Text narration may accompany but not replace the diagram.

**Rule 3 — Scope Summary Table**: For changes affecting ≥3 files, Key Design
MUST end with a `File | Change` table.

**Rule 4 — Fix labeling**: For bug-fix/multi-fix changes, label each fix
(Fix A, B, …) to create addressable references for tasks.md.

**Files affected** (3 files):
- `src/sspec/templates/skills/sspec-design/SKILL.md` — add Presentation Rules subsection
- `src/sspec/templates/skills/sspec-design/examples.md` — update medium example
- `src/sspec/templates/change/spec.md` — strengthen Key Design comment

---

### Questions

1. Does this root cause analysis match your observation? (The gap is presentation
   prescription, not structural completeness)

2. Are the four Presentation Rules the right levers, or do you want to add/drop any?
   (e.g. should Rule 3 threshold be ≥2 files instead of ≥3?)

3. Any specific patterns from the `feedback-from-others` spec or the `README.md`
   that you want captured as an additional rule?

4. Confirm scope: SKILL.md + examples.md + spec.md template (3 files). Good to proceed?