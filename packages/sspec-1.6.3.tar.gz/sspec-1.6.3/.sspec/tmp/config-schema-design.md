---
name: config-schema-design
description: A design specification for config file version migration (Schema Migration Pattern). Use this skill when the user asks about design of config versioning, schema evolution, migrating old config formats to new ones, or making configs backward-compatible. This skill describes a recommended pattern — if the user's system already has an established migration mechanism, apply the underlying principles selectively rather than enforcing a full rewrite.
---

# Schema Migration Pattern

A design specification for automatically migrating config files across format versions (v1 → v2 → v3 → ...), ensuring any older config can be upgraded to the latest version without manual intervention.

> **Scope note**: This is a design pattern, not a mandatory framework. If the project already has an established migration mechanism (e.g., Alembic for databases, a custom versioning layer), apply the core principles — explicit version fields, linear migration chains, no structural inference — within that existing system rather than replacing it wholesale.

---

## Core Design Principles

### 1. Schema Field as Single Source of Truth

Every config file **must** carry a `schema` field (string) identifying its format version, e.g. `"1.0"`, `"2.1"`.

- A matching `schema` value is the only authoritative signal that the data conforms to that version's structure.
- Configs missing a `schema` field are treated as version `"0.0"` and migrated from the beginning.

### 2. Markov-Chain Migration

Each migration function handles **only one step** (e.g. `1.0 → 2.0`). By running the migration chain sequentially, any old version reaches the latest through composed steps. The `schema` field **must be updated at each step** so subsequent migrations start from the correct baseline.

---

## Anti-Pattern: Never Infer Version from Data Structure

❌ **Wrong** — guessing the version by inspecting field presence, types, or array contents:

```typescript
if ('oldField' in data && !('newField' in data)) { /* guessing version */ }
if (typeof data.config === 'string') { /* guessing version */ }
```

**Why this breaks down**: data can be partially migrated, manually edited, or corrupted — making structural heuristics unreliable. Multiple versions may share identical field shapes. As versions multiply, the conditional logic becomes an unmaintainable branching tree. Each branch is also hard to unit-test in isolation.

✅ **Correct** — rely solely on the explicit `schema` field. The version number is the single fact to trust.

---

## Reference Implementation (TypeScript)

> The pattern is language-agnostic. See the Python example at the end; adapt to Go structs, Java Maps, Rust enums, etc. as needed.

### Type Definitions

```typescript
interface Config {
  schema: string;  // e.g. "1.0", "2.1"
  // ... other config fields
}

type MigrationFn = (data: any) => any;

interface MigrationEntry {
  version: string;       // target version this function migrates TO
  migrate: MigrationFn;  // pure function: previous version → this version
}
```

### Version Comparator

```typescript
/**
 * Compares two semantic version strings.
 * Returns: < 0 if v1 < v2 | 0 if equal | > 0 if v1 > v2
 */
const compareSchema = (v1: string, v2: string): number => {
  const parse = (v: string) => v.split('.').map(Number);
  const [maj1, min1 = 0] = parse(v1);
  const [maj2, min2 = 0] = parse(v2);
  return (maj1 - maj2) || (min1 - min2);
};
```

### Migration Table

```typescript
const CURRENT_SCHEMA = '3.0';  // always points to the latest version

const migrations: MigrationEntry[] = [
  {
    version: '1.0',
    // 0.x → 1.0: introduce `newField` with a default value
    migrate: (data) => ({ ...data, newField: 'default' })
  },
  {
    version: '2.0',
    // 1.x → 2.0: rename `oldField` to `renamedField`
    migrate: ({ oldField, ...rest }) => ({ ...rest, renamedField: oldField })
  },
  {
    version: '3.0',
    // 2.x → 3.0: promote flat `flatConfig` into a nested object
    migrate: ({ flatConfig, ...rest }) => ({ ...rest, nestedConfig: { ...flatConfig } })
  }
];
```

### Migration Runner

```typescript
const migration = (data: any): any => {
  const dataSchema = data.schema ?? '0.0';

  if (dataSchema === CURRENT_SCHEMA) return data;

  if (compareSchema(dataSchema, CURRENT_SCHEMA) > 0) {
    throw new Error(`Unsupported future schema: ${dataSchema}`);
  }

  // Defensive sort — guards against accidental ordering mistakes in the table
  const sortedMigrations = [...migrations].sort((a, b) =>
    compareSchema(a.version, b.version)
  );

  let result = { ...data };
  let current = dataSchema;

  for (const entry of sortedMigrations) {
    if (compareSchema(current, entry.version) < 0) {
      result = entry.migrate(result);
      current = entry.version;  // critical: advance the version cursor
    }
  }

  result.schema = CURRENT_SCHEMA;
  return result;
};
```

### Entry Point

```typescript
const loadConfig = (rawData: any): Config => {
  return migration(rawData) as Config;
};
```

---

## Adding a New Version

When the config format needs to change, only three steps are required — **no existing migration code is touched**:

1. Bump `CURRENT_SCHEMA` to the new version (e.g. `'4.0'`)
2. Append a new entry to the `migrations` array:
   ```typescript
   {
     version: '4.0',
     // 3.x → 4.0: describe what changed and why
     migrate: (data) => transformData(data)
   }
   ```
3. Add tests covering every starting version to `4.0` (e.g. `0.0→4.0`, `3.0→4.0`)

---

## Python Reference

```python
from functools import cmp_to_key

CURRENT_SCHEMA = "3.0"

def compare_schema(v1: str, v2: str) -> int:
    def parse(v): return list(map(int, v.split(".")))
    a, b = parse(v1), parse(v2)
    length = max(len(a), len(b))
    a += [0] * (length - len(a))
    b += [0] * (length - len(b))
    for x, y in zip(a, b):
        if x != y: return x - y
    return 0

def _migrate_to_1_0(data):
    # 0.x → 1.0: introduce new_field
    return {**data, "new_field": "default"}

def _migrate_to_2_0(data):
    # 1.x → 2.0: rename old_field → renamed_field
    d = {k: v for k, v in data.items() if k != "old_field"}
    return {**d, "renamed_field": data.get("old_field")}

def _migrate_to_3_0(data):
    # 2.x → 3.0: nest flat_config
    d = {k: v for k, v in data.items() if k != "flat_config"}
    return {**d, "nested_config": dict(data.get("flat_config", {}))}

migrations = [
    {"version": "1.0", "migrate": _migrate_to_1_0},
    {"version": "2.0", "migrate": _migrate_to_2_0},
    {"version": "3.0", "migrate": _migrate_to_3_0},
]

def migration(data: dict) -> dict:
    data_schema = data.get("schema", "0.0")

    if data_schema == CURRENT_SCHEMA:
        return data
    if compare_schema(data_schema, CURRENT_SCHEMA) > 0:
        raise ValueError(f"Unsupported future schema: {data_schema}")

    sorted_migrations = sorted(
        migrations,
        key=cmp_to_key(lambda a, b: compare_schema(a["version"], b["version"]))
    )

    result = dict(data)
    current = data_schema

    for entry in sorted_migrations:
        if compare_schema(current, entry["version"]) < 0:
            result = entry["migrate"](result)
            current = entry["version"]

    result["schema"] = CURRENT_SCHEMA
    return result
```

---

## Guarantees

| Property | Description |
|----------|-------------|
| **Unidirectional** | Forward upgrades only; downgrade is not supported |
| **Idempotent** | Running migration on a current-version config returns it unchanged |
| **Complete** | Any version — including `"0.0"` (missing schema field) — reaches the latest |
| **Extensible** | Adding a version requires only appending one entry; nothing else changes |
| **Deterministic** | Same input version always produces the same migration path |

---

## Design Checklist

Before generating migration code, confirm these decisions with the user:

- [ ] Version string format (`major` only / `major.minor` / custom)
- [ ] Behavior when `schema` field is absent (default `"0.0"` vs. hard error)
- [ ] Behavior on future/unknown versions (throw vs. pass-through)
- [ ] Whether the project already has a migration system — if so, identify which principles to adopt rather than replacing the whole mechanism
- [ ] Error handling strategy (fail-fast, rollback, log-and-skip)
- [ ] Whether pre-migration backup of original data is needed
- [ ] Test coverage requirement (minimum: each version → latest)
