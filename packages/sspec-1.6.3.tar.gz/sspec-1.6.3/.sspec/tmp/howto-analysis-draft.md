---
name: howto-optimizes-sspec-knowledge
created: 2026-03-10
status: draft
---

# Draft: Does HOWTO reduce SKILL + AGENTS.md bloat?

## 1. Problem framing

In sspec today, durable guidance mainly lives in two places:

- `AGENTS.md`: repo-wide protocol + hard guardrails.
- SKILL docs: phase contracts + multi-step workflows.

This creates a practical scaling problem:

- As rules accumulate, both documents drift toward "everything lives here".
- Agents pay a high retrieval cost (scroll/search/parse) for a small action.
- Long documents increase the chance of partial reading, wrong section selection, or rule omission.

The key issue is not "missing information"; it is "wrong granularity" for disclosure.

## 2. What HOWTO adds (distinct from SKILL)

HOWTO is best treated as a *micro operating procedure*:

- One concrete job, one outcome.
- Actionable without human interpretation.
- Fast to discover and retrieve via `sspec howto`.

In contrast:

- `AGENTS.md` is the *constitution* (global invariants).
- SKILL is the *workflow contract* (phase-scoped, multi-step, usually long-lived).
- HOWTO is the *standard operating procedure* (1 task, minimal context).

If each layer keeps its job, the overall system becomes composable.

## 3. How HOWTO reduces bloat in practice

### 3.1 Replace repeated "how to" paragraphs with pointers

Common pattern in `AGENTS.md` / SKILL: a short sub-procedure keeps getting appended:

- "How to read long markdown"
- "How to find the active change"
- "How to record a durable decision"

These are better as HOWTO:

- Keep the detailed steps in `src/sspec/howto/<name>.md` or `.sspec/howto/<name>.md`.
- In `AGENTS.md` / SKILL, keep only:
  - the *rule trigger* (when to do it)
  - the *pointer* (which HOWTO)
  - optionally one-line rationale

This reduces the tendency to grow `AGENTS.md` indefinitely.

### 3.2 Lower retrieval cost => fewer "guessing" behaviors

When an agent is uncertain, it chooses between:

- search/scan a long doc, or
- guess based on prior habits.

HOWTO makes "retrieve exact procedure" cheaper than guessing.
This translates into:

- fewer mistakes (wrong command, wrong file, wrong phase transition)
- fewer follow-up questions
- fewer rework loops

### 3.3 Enable progressive disclosure

`AGENTS.md` stays readable by acting as an index + hard rules.
HOWTO can grow without breaking the first read experience.

This is the core bloat-control mechanism: move details out of the top layer.

## 4. Governance: what goes where (recommended policy)

Use this decision table when adding new guidance:

| Guidance type | Best home | Why |
|---|---|---|
| Non-negotiable global rule | `AGENTS.md` | Must be visible on cold start |
| Phase contract / lifecycle workflow | SKILL | Needs structure + larger context |
| One concrete job / procedure | HOWTO | Low context, high retrieval frequency |
| Architecture / interfaces / schemas | spec-docs | Needs longevity + depth |

Extraction rule of thumb:

- If a section can be executed as a checklist and is <= ~50 lines, make it a HOWTO.
- If it is needed only inside one phase and spans many branches, keep in SKILL.

## 5. Risks and mitigations

### 5.1 Fragmentation (too many tiny docs)

Mitigations:

- Enforce verb-led names (`find-change`, `get-current-time`).
- Keep `desc` short and searchable.
- Prefer "one job" but avoid splitting into single-line fragments.

### 5.2 Staleness / drift between layers

Mitigations:

- Treat `AGENTS.md` / SKILL as triggers + pointers, not duplicated procedures.
- Add lightweight tests for CLI behavior (already done for `sspec howto`).
- Add a simple content lint later (missing `desc`, obviously wrong `desc`).

### 5.3 Discoverability (agents do not think of HOWTO)

Mitigations:

- Mention `sspec howto --list` in `AGENTS.md` as the default "I am unsure" lookup.
- Add 3-5 high-frequency builtin HOWTO topics to seed the habit loop.

## 6. Expected impact (qualitative)

If adopted consistently:

- `AGENTS.md` becomes shorter and more index-like.
- SKILL docs become more phase-focused, less cluttered with operational trivia.
- Agents spend less time scanning and more time executing correct steps.

The strongest effect shows up in:

- cold start sessions
- mid-implementation uncertainty
- review/handover accuracy

## 7. Next experiments to validate impact

1) Move 2-3 common sub-procedures out of `AGENTS.md` into HOWTO, leave pointers.
2) Track: number of times agents need to reread large docs; number of wrong-phase transitions.
3) Add a "howto discover" hint in `sspec --help` or `project status` output.
