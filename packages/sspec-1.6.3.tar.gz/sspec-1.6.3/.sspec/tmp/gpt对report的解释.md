---
link: wip/analysis-report.md
created: 2026-03-06 00:20
---

是的，J 和 L 我们已经做完了，并且我已经在报告里标记“✅ 已完成”，然后把这次改动提交了。

- 建议 J（减少 SKILL 与 `AGENTS.md` 重复）：已落到 `src/sspec/templates/skills/sspec-design/SKILL.md`（现在 scale/CLI quick ref 走 `AGENTS.md`，并加了极小的 fallback heuristic 防止上下文缺失时卡死）
- 建议 L（sspec-plan 的 Phase Structure 模板外链）：已落到 `src/sspec/templates/skills/sspec-plan/SKILL.md`（移除内嵌模板，改为指向 `examples.md`/`tasks.md` 模板 `@RULE`）
- 报告标记：`wip/analysis-report.md` 的 “建议 J / 建议 L” 下已加 “✅ 已完成（2026-03-06）”
- commit：`9a6dcf6` `📝 docs(skills): trim sspec design/plan skills`（仅改了 3 个文件：两份 SKILL + 报告）

## 我认为最“值得做”的建议（Agent 视角重要性排序）

我按“对 Agent 成功率提升 + 对维护/一致性影响 + 落地成本”综合排：

1) 建议 I：handover 增加 `30-second Resume` 卡片 ✅
价值最大、成本最低。Agent resume 时最缺的是“现在处于哪个 phase、下一步做什么、风险是什么”。这块直接减少误读/漏读整份 handover 的概率。

2) 建议 A：`sspec change status --json`（配套机器可读状态摘要）✅
这是让 Agent/工具“可靠读状态”的关键一步。没有它，Agent 要靠解析 `spec.md` frontmatter + `tasks.md` checkbox + `handover.md` 推断，脆弱且不可组合。
你在 §7.2 提的 `.state.yaml`/“放进 handover frontmatter”都是可渐进落地的实现路线。

3) 建议 M：SKILL 内部区分 REQUIRED / REFERENCE
和 J/L 同一个方向，但比 J/L 更进一步：不只是去重，而是显式告诉 Agent“必须读哪些、按需查哪些”，对 token/注意力分配提升很直接，且几乎不引入架构风险。

4) 建议 C：强化 `sspec change validate`（占位符/缺 section/空 @REPLACE 等检查）
属于“早发现、低返工”。Agent 很容易在 spec/tasks 留下空模板占位，validate 能把这些问题前置拦截。

5) 建议 H：为各个 @ask 关口提供“问题模板”（含场景 label）✅
能显著提升对齐质量的一致性，成本很低；而且和 sspec 的“用户在环”哲学完全一致。

6) 建议 D：Explore 模式（明确“可读可分析，不写代码不改文件”）
对复杂任务/陌生仓库非常有用，能降低“研究阶段就开始动刀”的失控概率。属于中等成本、中等到高收益。

7) 建议 F：Capabilities / Affected Scope 显式化
提升 design 阶段的“影响面声明”，减少实现阶段才发现范围扩大的情况。收益中等，但要小心别把 spec 写作负担拉太高。

8) 建议 E：Micro-change 判定/入口优化（或 user 指定 scale）
能减少“该走 micro 还是 change”的摇摆，但可能增加流程摩擦，需要权衡目标用户（严肃开发 vs 快速小改）。

9) 建议 G：research 声明 investigation depth（orienting vs focused）
属于“锦上添花”：能改善研究行为的收敛度，但通常不如 status/resume/validate 这种硬能力提升显著。

10) 建议 B（以及 §8 的 K 延伸）：`sspec instructions <phase> --json`（运行时注入）
从“最终形态价值”看非常高（能系统性解决 SKILL 文本膨胀、规则更新分散、Agent 每步不知道模板的问题），但这是一次 CLI/Schema 层的重构升级：成本高、边界要重新设计，适合在你确认要走“CLI=prompt factory”路线后再做。
如果你要的是近期 ROI，我会优先做 1-5；如果你要的是长期体系化升级，B/K 会进入前 3。

## 你看不懂的那段：openspec 到底在说什么？它怎么做到的？

这段核心在讲一个模式：**把“规则/模板/依赖图”从 SKILL 文本里抽出来，变成 CLI 可查询的结构化数据**。

在你报告 §7.1 已经写了 openspec 的关键结构（我按你的描述解释，不额外臆造实现细节）：

1) `schema.yaml` 定义“工作流图”（机器可读）
里面声明 artifacts（proposal/design/tasks…）各自：
- 生成哪个文件（`generates`/`outputPath`）
- 用哪个模板（`template`）
- 给 Agent 的指令文本（`instruction`）
- 依赖谁（`requires`）
以及 apply 阶段需要哪些产物（`apply.requires`）、tasks 完成度怎么追踪（比如 `tracks: tasks.md` 这种）

2) `openspec instructions <artifact> --json` 做的事（本质：按需“吐出 prompt 包”）
CLI 读取 `schema.yaml`，定位你要的 artifact，然后把这一步需要的：
- `instruction`（要写什么、规则是什么）
- `template`（要填的骨架长什么样）
- `context`（当前 change/项目的上下文）
- `outputPath`（写到哪里）
- `dependencies`（依赖是否已满足）
组装成 JSON 返回。
所以 Agent 不需要“记住一大坨 SKILL 文本”，而是每一步现查现用。

3) `openspec status --json` 做的事（本质：把依赖图 + 完成情况结构化输出）
同样基于 `schema.yaml` 的依赖图，CLI 扫描当前 change 目录里各个 artifact 文件是否存在/是否完成（以及 applyRequires 等），然后把“图 + 状态”以 JSON 输出给 Agent/工具消费。

你报告里建议 A/B 的意思就是：**让 sspec 也拥有这种“CLI 可查询的机器可读 API”**。这样：
- Agent 判断状态不用解析 markdown（或至少不用“临场猜”）
- SKILL 可以更短（只描述 flow / 哲学 / 人在环关口），模板和规则从 CLI/模板文件按需拿

如果你愿意，我建议下一步你选一个方向继续（我会按你选的做实现/改模板）：
1) 先做建议 I（handover 加 30-second resume card，纯模板改动，立竿见影）
2) 先做建议 A 的最小版（先不引入 `.state.yaml`，用 CLI 解析现有 spec/tasks/handover 输出 `--json`）
3) 先做建议 M（REQUIRED/REFERENCE 分区，继续压 token 和阅读成本）