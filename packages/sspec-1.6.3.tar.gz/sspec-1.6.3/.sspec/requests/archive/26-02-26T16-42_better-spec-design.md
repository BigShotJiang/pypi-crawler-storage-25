---
name: better-spec-design
created: 2026-02-26 16:42:22
status: DOING
attach-change: .sspec/changes/archive/26-02-26T16-56_better-spec-design/spec.md
tldr: ''
---
<!-- @RULE: Frontmatter Type
status: OPEN | DOING | DONE | CLOSED;
tldr: One-sentence summary for list views — fill this!
 -->

# Request: better-spec-design

## Background
<!-- Current situation, background information -->
我刚刚在别的项目使用了 sspec ，然后发现了一些问题
这个项目中我创建了两个 change
H:\SrcCode\SiYuanDevelopment\sy-f-misc\.sspec\changes\26-02-25T20-53_other-provide-type
H:\SrcCode\SiYuanDevelopment\sy-f-misc\.sspec\changes\26-02-26T15-16_feedback-from-others

## Problem
<!-- What is not working or missing -->
其中后者的 spec.md 中的 design 部分编写的感觉远远好于前者。可能一方面是模型的缘故，另一方面是我在 request 的时候有强调 design 要编写的什么。
后者有更加清晰可理解可跟踪的接口类型等规范，有重要核心的代码片段，还有看起来不错的 Flow Chart
我还很喜欢写的 "H:\SrcCode\SiYuanDevelopment\sy-f-misc\src\func\gpt\openai\README.md" 里面 ‘## Tool Call Lifecycle’‘## Architecture Overview’的图表，对我而言表现形式和可理解性比之前 change 看起来漂亮的多。

这里的关键不是说死板模仿后者，而是后者呈现的 design 信息更加有效、 更加方便我抓住他的设计要点并方便我思考、 审核、 评估。

我在想要如何优化 SSPEC 相关的 Agnets.md 或者 SKILL 才能让后来的模型都稳定产出这种优秀的 spec design 而非前一个版本那样语焉不详的 spec 呢？

## Initial Direction
<!-- Your rough idea or preferred direction — details are fine but not required.
This becomes the starting point for the change's spec.md Section A/B. -->

请仔细调研相关的代码、 文件等，给出建议，并通过 @ask 和我交流
设计明确的改进方案；本 change 需要的变动应该不会很大，可以只填写 spec。

## Success Criteria
<!-- The conditions or criteria that indicate
the problem has been resolved and meets the user's intention -->

作为 Agnet 独立思考，让改进之后的 sspec 能稳定复现更加优秀、 可以落实、 抓住整体框架 + 重要要点的设计方案。

---

## @AGENT
<!-- What should Agent do to implement this request -->
Adhere to the SSPEC protocol specifications and commence development from the current Request file, following the SSPEC/Development Lifecycle.
Next step: Read `sspec-research` SKILL + `sspec-design` SKILLs + `sspec change new --from <this>`.

本次涉及到读取外部的文件代码，目前 vscode 中应该已经允许这种做法；你也可以有效利用 powrshell 绕开 workspace 的限制。
