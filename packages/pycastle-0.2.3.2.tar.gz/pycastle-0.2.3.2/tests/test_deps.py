import asyncio
import dataclasses

import pytest

from pycastle.agent_output_protocol import CompletionOutput
from pycastle.errors import PreflightFailure
from pycastle.agent_runner import RunRequest
from pycastle.prompt_pipeline import PromptTemplate
from pycastle.iteration._deps import Deps, FakeAgentRunner, RecordingLogger, _make_deps


@pytest.fixture
def logger() -> RecordingLogger:
    return RecordingLogger()


def test_starts_with_no_records(logger: RecordingLogger) -> None:
    assert logger.errors == []
    assert logger.agent_outputs == []


def test_log_error_is_recorded(logger: RecordingLogger) -> None:
    issue = {"number": 1, "title": "Fix bug"}
    error = ValueError("something went wrong")

    logger.log_error(issue, error)

    assert logger.errors == [(issue, error)]


def test_log_error_records_preflight_failure(logger: RecordingLogger) -> None:
    issue = {"number": 42}
    failure = PreflightFailure(
        failures=(("ruff check", "ruff check .", "E501 line too long"),)
    )

    logger.log_error(issue, failure)

    assert logger.errors == [(issue, failure)]


def test_log_agent_output_is_recorded(logger: RecordingLogger) -> None:
    logger.log_agent_output("implementer", "some output")

    assert logger.agent_outputs == [("implementer", "some output")]


def test_multiple_log_error_calls_accumulate(logger: RecordingLogger) -> None:
    issue1 = {"number": 1}
    issue2 = {"number": 2}
    error1 = RuntimeError("first")
    error2 = RuntimeError("second")

    logger.log_error(issue1, error1)
    logger.log_error(issue2, error2)

    assert logger.errors == [(issue1, error1), (issue2, error2)]


def test_multiple_log_agent_output_calls_accumulate(logger: RecordingLogger) -> None:
    logger.log_agent_output("planner", "plan output")
    logger.log_agent_output("implementer", "impl output")

    assert logger.agent_outputs == [
        ("planner", "plan output"),
        ("implementer", "impl output"),
    ]


# --- Deps ---


def test_deps_does_not_carry_env() -> None:
    field_names = {f.name for f in dataclasses.fields(Deps)}
    assert "env" not in field_names


# --- _make_deps ---


def test_make_deps_returns_deps_instance(tmp_path) -> None:
    """_make_deps creates a fully-populated Deps with sensible defaults."""
    runner = FakeAgentRunner(responses=[])
    deps = _make_deps(tmp_path, runner)
    assert isinstance(deps, Deps)


# --- FakeAgentRunner ---


@pytest.fixture
def mount_path(tmp_path):
    return tmp_path


def test_fake_agent_runner_starts_with_no_calls() -> None:
    runner = FakeAgentRunner(responses=[CompletionOutput()])

    assert runner.calls == []


def test_fake_agent_runner_returns_queued_response(mount_path) -> None:
    runner = FakeAgentRunner(responses=[CompletionOutput()])

    result = asyncio.run(
        runner.run(
            RunRequest(
                name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
    )

    assert isinstance(result, CompletionOutput)


def test_fake_agent_runner_returns_responses_in_order(mount_path) -> None:
    r1, r2, r3 = CompletionOutput(), CompletionOutput(), CompletionOutput()
    runner = FakeAgentRunner(responses=[r1, r2, r3])

    async def _run():
        return [
            await runner.run(
                RunRequest(
                    name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
                )
            ),
            await runner.run(
                RunRequest(
                    name="implementer",
                    template=PromptTemplate.PLAN,
                    mount_path=mount_path,
                )
            ),
            await runner.run(
                RunRequest(
                    name="merger", template=PromptTemplate.PLAN, mount_path=mount_path
                )
            ),
        ]

    assert asyncio.run(_run()) == [r1, r2, r3]


def test_fake_agent_runner_records_call_arguments(mount_path) -> None:
    runner = FakeAgentRunner(responses=[CompletionOutput()])

    asyncio.run(
        runner.run(
            RunRequest(
                name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
    )

    assert len(runner.calls) == 1
    assert runner.calls[0].name == "planner"
    assert runner.calls[0].template == PromptTemplate.PLAN
    assert runner.calls[0].mount_path == mount_path


def test_fake_agent_runner_records_all_calls(mount_path) -> None:
    runner = FakeAgentRunner(responses=[CompletionOutput(), CompletionOutput()])

    async def _run():
        await runner.run(
            RunRequest(
                name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
        await runner.run(
            RunRequest(
                name="implementer", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )

    asyncio.run(_run())

    assert [c.name for c in runner.calls] == ["planner", "implementer"]


def test_fake_agent_runner_records_call_even_on_queue_exhaustion(mount_path) -> None:
    runner = FakeAgentRunner(responses=[])

    with pytest.raises(AssertionError):
        asyncio.run(
            runner.run(
                RunRequest(
                    name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
                )
            )
        )

    assert len(runner.calls) == 1


def test_fake_agent_runner_queue_exhaustion_raises(mount_path) -> None:
    runner = FakeAgentRunner(responses=[CompletionOutput()])

    async def _run():
        await runner.run(
            RunRequest(
                name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
        await runner.run(
            RunRequest(
                name="implementer", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )

    with pytest.raises(AssertionError, match="queue exhausted"):
        asyncio.run(_run())


def test_fake_agent_runner_queue_exhaustion_error_names_agent(mount_path) -> None:
    runner = FakeAgentRunner(responses=[])

    with pytest.raises(AssertionError, match="unexpected-agent"):
        asyncio.run(
            runner.run(
                RunRequest(
                    name="unexpected-agent",
                    template=PromptTemplate.PLAN,
                    mount_path=mount_path,
                )
            )
        )


def test_fake_agent_runner_raises_queued_preflight_failure(mount_path) -> None:
    failure = PreflightFailure(failures=(("ruff", "ruff check .", "E501"),))
    runner = FakeAgentRunner(responses=[failure])

    with pytest.raises(PreflightFailure) as exc_info:
        asyncio.run(
            runner.run(
                RunRequest(
                    name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
                )
            )
        )

    assert exc_info.value.failures == (("ruff", "ruff check .", "E501"),)


def test_fake_agent_runner_raises_queued_exception(mount_path) -> None:
    runner = FakeAgentRunner(responses=[RuntimeError("agent crashed")])

    with pytest.raises(RuntimeError, match="agent crashed"):
        asyncio.run(
            runner.run(
                RunRequest(
                    name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
                )
            )
        )


def test_fake_agent_runner_side_effect_bypasses_queue(mount_path) -> None:
    expected = CompletionOutput()
    runner = FakeAgentRunner(responses=[], side_effect=lambda _: expected)

    result = asyncio.run(
        runner.run(
            RunRequest(
                name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
    )

    assert result is expected


def test_fake_agent_runner_async_side_effect_is_awaited(mount_path) -> None:
    expected = CompletionOutput()

    async def async_effect(_) -> CompletionOutput:
        return expected

    runner = FakeAgentRunner(side_effect=async_effect)

    result = asyncio.run(
        runner.run(
            RunRequest(
                name="planner", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
    )

    assert result is expected


def test_fake_agent_runner_side_effect_records_call(mount_path) -> None:
    runner = FakeAgentRunner(side_effect=lambda _: CompletionOutput())

    asyncio.run(
        runner.run(
            RunRequest(
                name="implementer", template=PromptTemplate.PLAN, mount_path=mount_path
            )
        )
    )

    assert len(runner.calls) == 1
    assert runner.calls[0].name == "implementer"


# --- FakeAgentRunner.run_preflight ---


def test_fake_agent_runner_run_preflight_returns_queued_empty_list(
    mount_path,
) -> None:
    runner = FakeAgentRunner(preflight_responses=[[]])

    result = asyncio.run(
        runner.run_preflight(name="plan-sandbox", mount_path=mount_path)
    )

    assert result == []


def test_fake_agent_runner_run_preflight_returns_queued_failures(
    mount_path,
) -> None:
    failures = [("ruff", "ruff check .", "E501 line too long")]
    runner = FakeAgentRunner(preflight_responses=[failures])

    result = asyncio.run(
        runner.run_preflight(name="plan-sandbox", mount_path=mount_path)
    )

    assert result == failures


def test_fake_agent_runner_run_preflight_records_call_args(mount_path) -> None:
    runner = FakeAgentRunner(preflight_responses=[[]])

    asyncio.run(
        runner.run_preflight(name="plan-sandbox", mount_path=mount_path, stage="plan")
    )

    assert len(runner.preflight_calls) == 1
    assert runner.preflight_calls[0]["name"] == "plan-sandbox"
    assert runner.preflight_calls[0]["mount_path"] == mount_path
    assert runner.preflight_calls[0]["stage"] == "plan"


def test_fake_agent_runner_run_preflight_raises_when_queue_exhausted(
    mount_path,
) -> None:
    runner = FakeAgentRunner(preflight_responses=[])

    with pytest.raises(AssertionError, match="queue exhausted"):
        asyncio.run(runner.run_preflight(name="plan-sandbox", mount_path=mount_path))


def test_fake_agent_runner_run_preflight_exhaustion_error_names_agent(
    mount_path,
) -> None:
    runner = FakeAgentRunner(preflight_responses=[])

    with pytest.raises(AssertionError, match="plan-sandbox"):
        asyncio.run(runner.run_preflight(name="plan-sandbox", mount_path=mount_path))


def test_fake_agent_runner_run_preflight_raises_queued_exception(mount_path) -> None:
    runner = FakeAgentRunner(preflight_responses=[RuntimeError("docker failure")])

    with pytest.raises(RuntimeError, match="docker failure"):
        asyncio.run(runner.run_preflight(name="plan-sandbox", mount_path=mount_path))


def test_fake_agent_runner_run_preflight_starts_with_empty_preflight_calls() -> None:
    runner = FakeAgentRunner(preflight_responses=[[]])

    assert runner.preflight_calls == []


def test_fake_agent_runner_run_preflight_returns_responses_in_order(mount_path) -> None:
    failures_1 = [("ruff", "ruff check .", "E501")]
    failures_2: list[tuple[str, str, str]] = []
    runner = FakeAgentRunner(preflight_responses=[failures_1, failures_2])

    async def _run():
        return [
            await runner.run_preflight(name="sandbox-1", mount_path=mount_path),
            await runner.run_preflight(name="sandbox-2", mount_path=mount_path),
        ]

    assert asyncio.run(_run()) == [failures_1, failures_2]


def test_fake_agent_runner_run_preflight_records_call_even_on_queue_exhaustion(
    mount_path,
) -> None:
    runner = FakeAgentRunner(preflight_responses=[])

    with pytest.raises(AssertionError):
        asyncio.run(runner.run_preflight(name="plan-sandbox", mount_path=mount_path))

    assert len(runner.preflight_calls) == 1
