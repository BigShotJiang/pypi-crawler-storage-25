## Trading Domain Knowledge

**Carry polarity**: Positive funding = longs pay shorts. Carry strategies SHORT high-funded assets to COLLECT funding. Always use NegateTransform after FundingDataLoader for carry signals. Without it, the strategy pays funding instead of earning it. Standard carry branch: `FundingDataLoader → TargetSignalResampler(method="mean") → NegateTransform → CrossSectionalZScore`. Exception: FundingLevelRegime (regime detector) handles polarity internally.

**Mean reversion polarity**: Oscillators (RSI, Stochastic, WilliamsR, CMO) are designed so HIGH = overbought, LOW = oversold. For trend following, this polarity is correct. For mean reversion, INVERT with NegateTransform so oversold → positive forecast (long). Without negation, a 'mean reversion' RSI strategy actually buys overbought assets. Exception: TimeSeriesMeanReversionForecast and WingsTransform handle inversion internally.

**Signal diversity > quantity**: Three uncorrelated Sharpe-0.5 signals beat three correlated Sharpe-1.0 signals. Prioritize different families (trend vs carry vs mean reversion) over parameter variants (EWMAC at 5 speeds). Lowest correlation pairs in crypto: trend vs carry, trend vs mean reversion, price-based vs funding-based.

**Required component pairs** (always use together):
- ForecastScaler + ForecastCapper (scale then cap)
- TopNAssetSelector + SelectionToSignalConverter (select then manage exits)
- VolatilityAdjustedPriceSeries + BreakoutDistance (vol-adjust then breakout)
- CorrelationEstimator + AnalyticalFDM (estimate then diversify)
- Store + Load (matching slot names)

**Stream data alignment**: Funding/OI data (1h) must be resampled to the target timeframe before mixing with price data. Standard pattern: `FundingDataLoader → TargetSignalResampler(method="mean")`. TargetSignalResampler reads target_timeframe from Globals and handles resampling + alignment automatically. Choose method by data type: "mean" for rates (funding), "last" for levels (OI), "sum" for flows. The Universe selector passes the same resolved universe to all data loaders, so assets already match — AssetAligner is NOT needed in the standard case. Old pattern (EWMATransform → SignalResampleTransform → AssetAligner) is unnecessary with Universe selection.

**Multi-data shape alignment**: When Parallel branches use different data sources (price vs funding vs OI), use TargetSignalResampler in each branch to align timeframes. Assets already match because the Universe selector passes the same resolved list to all data loaders. AssetAligner is only needed when a component explicitly drops assets from the universe (VolumeUniverseReducer, GroupAssetFilter). In that case, Store the reduced OHLCV BEFORE the Parallel and use AssetAligner(reference_slot='ohlcv_1d') in other branches. Note: TopNAssetSelector does NOT change dimensions — it produces a mask, not a reduced universe.

**Complexity ladder** — match pipeline complexity to intent:
- Level 1 (single signal): 4-6 components, 2-4 params. Use ForecastWeightNormalizer for sizing.
- Level 2 (dual signal blend): 8-12 components, 5-8 params. ForecastCombiner → ForecastWeightNormalizer.
- Level 3 (multi-signal + vol targeting): 15-25 components. Upgrade to ReturnVolatility + VolTargetWeightConverter chain.
- Level 4 (regime-adaptive portfolio): 25-40 components, 15-20 params
More than 25 free parameters almost certainly means overfitting. Suggest complexity ONE level at a time, not jumps.

**Regime models**: Prefer single-component detectors (FundingLevelRegime, RealizedVolatilityRegime) over composites. Prefer RegimeWeightedBlender (soft modulation) over RegimeGate (hard on/off). Regime conditioning enhances alpha — it does NOT replace it. Build and test base signal first. Value hierarchy: Alpha > Breadth > Conditioning > Risk Management.

**Hierarchical combination**: Equal weights within a signal family (e.g., EWMAC at 3 speeds) is fine. Across families (trend + carry + MR), set explicit weights — otherwise 5 trend + 1 carry = 83% trend. Use EmpiricalFDM or AnalyticalFDM after ForecastCombiner.

**Post-backtest reasoning — never overfit to results.** When a backtest shows losses in a specific period, DO NOT make changes designed to avoid that specific period. That is curve-fitting. Instead:

1. **Diagnose the mechanism, not the outcome.** "Shorts lost money in Nov 2024" is an outcome. "Mean reversion shorts during a parabolic breakout with no trend filter" is a mechanism. Fix mechanisms, not outcomes.
2. **Changes must have principled reasons independent of the backtest.** "Go long-only because the Nov 2024 wipeout was short-side" = overfitting. "Go long-only because crypto has a structural long bias and mean reversion shorts in trending markets are inherently risky" = principled. The change should make sense even without seeing the backtest.
3. **Removing trades to avoid losses is a red flag.** A strategy that takes fewer trades is more fragile and more likely to be overfit. If a strategy loses money in some periods, the first question is whether the signal was wrong or the risk management was missing — not whether to eliminate that side entirely.
4. **Prefer adding robustness over removing exposure.** Instead of "remove shorts," consider: add a trend filter, add position sizing, add a regime gate, reduce leverage. These address the mechanism (unfiltered mean reversion in strong trends) without eliminating half the strategy.
5. **Always state the principled reason.** When suggesting a post-backtest change, lead with the trading principle, not the backtest result. "Mean reversion strategies benefit from a trend filter because reversals fail in strong trends" — not "Adding this filter because the strategy lost money here."

**Start simple, suggest improvements.** Default to the minimal viable pipeline for the user's intent. Normalization (CrossSectionalZScore), volatility standardization (VolatilityStandardizer), and forecast diversification (FDM) are valuable but should be suggested as follow-up improvements after the base pipeline works — not included by default in every initial build. A single-signal strategy that produces correct WeightSeries is more useful than a complex one with normalization issues.

