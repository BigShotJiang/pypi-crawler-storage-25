## Key Mistakes to Avoid

**M-01: Equal weights on continuous forecasts.** ForecastSeries values carry conviction. Using EqualWeightAllocator after continuous forecasts discards signal magnitude. Use ForecastWeightNormalizer (simple) or VolTargetWeightConverter (production) instead. Note: EqualWeightAllocator IS correct for Path 3 (TopN/filter → equal-weight selected assets) where selection is the signal.

**M-09: Pipeline without WeightSeries output.** The backtester needs WeightSeries. A pipeline ending at SignalSeries or ForecastSeries cannot be tested. Always check the output type.

**M-10: Missing data pipeline.** Every pipeline needs data. Globals(target_timeframe='1d'), PriceDataLoader, TargetTimeframeResampler are the standard opening. Use Globals for config, not StoreValue.

**M-11: TopN without exit logic.** TopNAssetSelector selects entries but doesn't manage exits. Always follow with SelectionToSignalConverter (hold_periods) to manage hold duration and exit timing.

**M-12: Unconsumed Parallel.** After a Parallel block (dict output), you MUST add a Composer, Extract, or Load. A pipeline ending at dict is incomplete.

**M-16: Over-indexing on one pattern.** Not every strategy needs hierarchical multi-signal forecast-combine. A simple factor tilt or entry/exit strategy may be exactly what the user wants.

**M-03: Normalizing binary signals.** CrossSectionalZScore on {-1,0,1} is meaningless. Binary signals follow Path 2 (entry/exit), not Path 1 (continuous forecast).

**M-18: Parallel branch shape mismatch.** If any branch drops assets from the universe (VolumeUniverseReducer, GroupAssetFilter), ALL other branches must use AssetAligner(reference_slot='ohlcv_1d') to match. Store the reduced OHLCV BEFORE the Parallel block.

**M-19: Serial Store/Load chain when Parallel should be used.** When two computations share the same input but are otherwise independent (e.g., a filter and a signal), use Parallel branches — not a serial Store → compute A → Store result → Load → compute B → apply A to B chain. The serial pattern obscures data flow and prevents the engine from expressing independence. Rule of thumb: if you Store a value only to Load it one step later, the two paths should be Parallel branches instead.

Bad (serial anti-pattern):
```
Store('ohlcv') → ADX → BelowThreshold → Store('mask') → Load('ohlcv') → Keltner → ZScore → ApplyUniverseMask(mask_slot='mask')
```

Good (parallel — branches receive current automatically, no Load needed):
```
{ "signal": [Keltner, ZScore], "filter": [ADX, BelowThreshold] } → ApplyMask("signal", "filter")
```

Note: ApplyMask is a SignalComposer that consumes the Parallel dict directly — no Store, Load, or Extract needed. This applies to any case where a filter or confirmation signal is independent of the main signal path. Always ask: "does computation B depend on the output of computation A?" If not, they belong in Parallel.

**M-20: Using ApplyUniverseMask with boolean filter masks.** ApplyUniverseMask expects 1.0/NaN masks (from RollingVolumeUniverseMask). Boolean masks from threshold filters (True/False) give 0.0 (not NaN) when multiplied, which has different semantics. Use ApplyMask (SignalComposer) for boolean filter masks from Parallel branches. Use ApplyUniverseMask only with 1.0/NaN universe masks.

