## Paths From Data to Weights

**Normalization applies to ALL paths** — not just continuous. Discrete strategies commonly normalize signals before applying thresholds (e.g., RollingZScoreTransform → ThresholdCross at ±2). CrossSectionalZScore is useful when combining multiple signals on different scales, regardless of path.

**Path 1 — Continuous Forecast**:
Data → Indicator → Normalize → ForecastScaler → ForecastCapper → ForecastWeightNormalizer → WeightSeries. Signal values carry conviction — stronger signals get larger positions. When combining multiple signals, add CrossSectionalZScore before ForecastScaler to put them on comparable scales. For single signals, ForecastScaler handles scaling directly. For production vol-targeted sizing, replace ForecastWeightNormalizer with the ReturnVolatility → VolTargetWeightConverter chain (Level 3+).

**Path 2 — Discrete Entry/Exit** (most requested):
Decisions are in/out, not continuous. Build entry and exit signals separately, combine with PositionStateMachine. Best for mean-reversion, breakout, event-driven.

Simple (stateless): Data → Indicator → Normalize → ThresholdCross → BinaryToWeight. Re-evaluates every bar — no position memory. Good for starting, but exits at entry threshold, not at a separate exit level.

Stateful (entry + exit): Build entry and exit signals independently (often in Parallel), Store each to slots, combine with PositionStateMachine → BinaryToWeight. Enables different entry/exit thresholds (e.g., enter at z=±2, exit at z=0).

Entry signal: Normalize → ThresholdCross(upper=2, lower=-2) → Store('entries')
Exit signal: Normalize → ThresholdCross(upper=0, lower=0) → Store('exits') — produces +1/-1 indicating which side of zero
Position state: PositionStateMachine(entry_slot='entries', exit_slot='exits', exit_mode='directional') → holds until exit opposes position

Multiple signals may feed into entry (e.g., 2-3 indicators combined or gated) and different signals into exit (e.g., separate exit indicator + time-based). Long-only or short-only: use ThresholdCross(mode='long_only') or ThresholdCross(mode='short_only').

Filters and confirmations are independent of the signal → compute in Parallel branches, merge with ApplyMask before the entry threshold.

**Path 3 — Screen-Select-Allocate**:
Data → Indicator → TopNAssetSelector → SelectionToSignalConverter(hold_periods) → EqualWeightAllocator → WeightSeries. Selects top N assets by rank, equal-weights them. Assets rotate in and out based on ranking changes and hold periods. Best for rotation strategies.

**Hybrid: Screen → Entry/Exit**: Narrow the universe with TopNAssetSelector or cross-sectional ranking, then apply entry/exit logic on the selected assets. Use TopNAssetSelector to produce a mask → ApplyMask on the signal, then ThresholdCross for entry/exit within the screened set.

**Path 4 — Direct Allocation**:
Data → Indicator → EqualWeightAllocator or RiskParityAllocator → WeightSeries. Skips the forecast stage entirely. Simple but effective for factor tilts.

