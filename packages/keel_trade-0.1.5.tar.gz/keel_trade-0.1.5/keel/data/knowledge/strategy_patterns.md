## Common Strategy Patterns

These are recognition aids, not templates. Novel strategies may not fit any pattern — that's fine. Use component discovery tools for creative composition.

**Forecast-Combine** — Multiple signals normalized, scaled to forecasts, combined with ForecastCombiner, then sized. Simple flow: ForecastCombiner → ForecastCapper → ForecastWeightNormalizer. Add EmpiricalFDM or AnalyticalFDM between combiner and capper for diversification benefit (optional, Level 2+). For production vol-targeted sizing, replace ForecastWeightNormalizer with ReturnVolatility + VolTargetWeightConverter chain (Level 3+).

**Screen-Select** — Filter universe by signal, equal-weight survivors. Components: indicator, TopNAssetSelector, SelectionToSignalConverter (hold_periods), EqualWeightAllocator. Assets rotate in/out based on ranking and hold periods.

**Screen → Entry/Exit (hybrid)** — Narrow universe with cross-sectional ranking or TopN, then apply entry/exit logic on selected assets. TopNAssetSelector produces a mask → ApplyMask gates the signal → ThresholdCross for entry/exit within the screened set.

**Entry/Exit** — Threshold-based buy/sell signals with position state. Normalize BEFORE thresholds (z-score, cross-sectional). Multiple signals may combine: 2-3 for entry decisions, different signals for exit. When a filter gates entries independently of the signal, compute signal and filter in Parallel branches, then merge with ApplyMask (consumes dict directly, zeroes out filtered cells).

**Factor Tilt** — Single signal directly to weights. Simplest pattern. Components: indicator, ForecastWeightNormalizer or EqualWeightAllocator.

**Multi-Signal Hierarchy** — Parallel branches of signals, composed at multiple levels (within-bucket, across-bucket). Uses Parallel + Composers at each level.

**Regime-Conditioned** — Base strategy modulated by regime detection (funding rates, volatility). Uses RegimeWeightedBlender, RegimeGate, or RegimeScale to adjust weights based on market conditions.

