<!-- keywords: entry, exit, threshold, binary, RSI, overbought, oversold, buy, sell, state, PositionStateMachine, ThresholdCross, mean reversion, breakout, zero cross -->
<!-- pattern: entry_exit -->

# Discrete Entry/Exit

Threshold-based buy/sell signals with explicit position state management.
Best for mean-reversion (buy oversold, sell overbought) and breakout strategies.

## Two Approaches

### Stateless (simpler, start here)
ThresholdCross re-evaluates every bar — no position memory. Position is active only while signal stays beyond threshold. Good for first iteration.

### Stateful (separate entry/exit signals)
Build entry and exit signals independently, combine with PositionStateMachine. Enables different entry and exit thresholds (e.g., enter at z=±2, exit when z crosses 0). Use when the user specifies distinct entry and exit conditions.

## Component Sequence — Stateless

1. **PriceDataLoader** + **TargetTimeframeResampler** - Load and resample data
2. **Indicator** (KeltnerChannel, RSI, etc.) - Compute signal
3. **Normalization** (optional) - RollingZScoreTransform, CrossSectionalZScore
4. **NegateTransform** (if needed) - Flip polarity for mean reversion
5. **ThresholdCross** (upper=2, lower=-2) - Generate positions → BinarySignal
6. **BinaryToWeight** - Allocate → WeightSeries

## Component Sequence — Stateful

1. **Data pipeline** - PriceDataLoader, TargetTimeframeResampler
2. **Signal computation** (Parallel if filter/confirm needed):
   - Signal branch: Indicator → Normalize → NegateTransform (if MR)
   - Filter branch: ADX/other → ThresholdFilter (independent, in Parallel)
3. **ApplyMask** - Merge signal + filter from Parallel dict
4. **Entry signal**: ThresholdCross(upper=2, lower=-2) → Store('entries')
5. **Exit signal**: ThresholdCross(upper=0, lower=0) → Store('exits')
   - Or: TimeBasedExitFilter(entry_slot='entries', hold_periods=5) → Store('exits')
6. **PositionStateMachine**(entry_slot='entries', exit_slot='exits', exit_mode='directional')
7. **BinaryToWeight** → WeightSeries

## Directional Exits with PositionStateMachine

`exit_mode='directional'`: exit fires when exit signal **opposes** current position (exit × state < 0).

Use ThresholdCross(upper=0, lower=0) as exit signal:
- Signal > 0 → exit_signal = +1 → exits shorts (state=-1), holds longs (state=+1)
- Signal < 0 → exit_signal = -1 → exits longs (state=+1), holds shorts (state=-1)

This enables "enter at extreme, exit at mean" — the most common mean-reversion pattern.

`exit_mode='scalar'` (default): exit fires when exit_signal == 1.0, direction-blind. Use with TimeBasedExitFilter or ValueStopExitFilter.

## Stateful Example — Enter at ±2, Exit at Zero Cross, with Filter + Confirm

Decomposition for: "KeltnerChannel z-score, enter at ±2, exit at z=0, skip strong trends, confirm with RSI(3) extremes"

| Block | Intent | Component(s) |
|-------|--------|--------------|
| Signal | (close-EMA20)/ATR20 | KeltnerChannel(20,1) |
| Normalize | 60-bar z-score | RollingZScoreTransform(60), NegateTransform |
| Entry | z > 2 short, z < -2 long | ThresholdCross(2, -2) |
| Exit | z crosses 0 | ThresholdCross(0, 0) + directional PSM |
| Filter | skip strong trends | ADX(14) → BelowThresholdFilter(25) |
| Confirm | RSI(3) > 90 or < 10 | RSI → AboveThreshold(90) + BelowThreshold(10) → MaskOr |

Bar-by-bar trace (negated z-score, directional exit):
```
negated_z  entry        exit         PSM state
+2.5       +1 (long)    +1 (z>0)     entry wins  → LONG
+1.5       0            +1 (z>0)     same sign   → HOLD
-0.3       0            -1 (z<0)     opposes +1  → EXIT  ← z crossed 0
-2.5       -1 (short)   -1 (z<0)     entry wins  → SHORT
-1.5       0            -1 (z<0)     same sign   → HOLD
+0.3       0            +1 (z>0)     opposes -1  → EXIT  ← z crossed 0
```

```python
Pipeline([
    PriceDataLoader(timeframe='15min'),
    TargetTimeframeResampler(),

    # ── signal + filter + confirm (all independent → parallel) ──
    {
        "signal": [
            KeltnerChannel(period=20, multiplier=1),
            RollingZScoreTransform(window=60),
            NegateTransform(),
        ],
        "trend_filter": [
            ADX(period=14),
            BelowThresholdFilter(threshold=25, inclusive=True),
        ],
        "rsi_confirm": Pipeline([
            RSI(period=3),
            {
                "overbought": [AboveThresholdFilter(threshold=90)],
                "oversold":   [BelowThresholdFilter(threshold=10)],
            },
            MaskOr(),
        ]),
    },

    # ── combine filters, then apply to signal ──
    #   trend_filter AND rsi_confirm → single mask, then mask the signal
    # (For simplicity, apply sequentially or combine with nested MaskAnd)

    # ── entry + exit (both consume masked z-score → parallel) ──
    {
        "entry": [ThresholdCross(upper=2, lower=-2), Store('entries')],
        "exit":  [ThresholdCross(upper=0, lower=0), Store('exits')],
    },

    # ── position management + sizing ──
    PositionStateMachine(entry_slot='entries', exit_slot='exits', exit_mode='directional'),
    BinaryToWeight(),
], name="keltner_mean_reversion")
```

Key composition patterns shown:
- **Nested Parallel**: RSI branch contains its own inner Parallel (overbought/oversold) → MaskOr
- **MaskOr**: composes two boolean filters (RSI > 90 OR RSI < 10) into a single mask
- **Three independent branches**: signal, trend filter, RSI confirm all receive OHLCV as `current`
- **Entry/exit in Parallel**: both consume the same masked z-score, Store to separate slots
- **Directional PSM**: exit_mode='directional' holds until exit signal opposes position

## Common Mistakes

- **M-03**: Normalizing binary signals with CrossSectionalZScore — meaningless
  on {-1, 0, +1} values. Binary signals skip normalization entirely.
- **Missing exit logic**: ThresholdCross alone is stateless. If the user specifies
  separate entry/exit conditions, use PositionStateMachine.
- **Wrong polarity for mean reversion**: High indicator value = overbought. For mean
  reversion, use NegateTransform BEFORE ThresholdCross so overbought → short.
- **Using ApplyUniverseMask for signal filters**: Threshold filters produce True/False
  (boolean). Use ApplyMask (SignalComposer), not ApplyUniverseMask (expects 1.0/NaN).
- **Loading inside Parallel when unnecessary**: Parallel branches receive `current`
  automatically. Only Load when you need data from a different pipeline point.
