"""Local workspace for strategy development.

Provides a checkout/push/pull model for working on platform strategies
locally. Agents and MCP tools use this to iterate on strategies with
full local validation, then sync back to the platform for backtesting
and deployment.

Workspace layout:
    ~/.keel/workspace/
    └── {strategy_id}/
        ├── strategy.py          # Working copy (editable)
        └── .keel-meta.json      # Sync metadata
"""

from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


WORKSPACE_ROOT = Path.home() / ".keel" / "workspace"
META_FILE = ".keel-meta.json"
STRATEGY_FILE = "strategy.py"


@dataclass
class WorkspaceMeta:
    """Sync metadata for a checked-out strategy."""

    strategy_id: str
    name: str
    source_hash: str  # Platform source_hash at checkout/last sync
    checked_out_at: str
    org_id: str | None = None
    current_sequence: int | None = None

    def save(self, workspace_dir: Path) -> None:
        meta_path = workspace_dir / META_FILE
        meta_path.write_text(json.dumps(asdict(self), indent=2) + "\n")

    @classmethod
    def load(cls, workspace_dir: Path) -> WorkspaceMeta:
        meta_path = workspace_dir / META_FILE
        data = json.loads(meta_path.read_text())
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class WorkspaceStatus:
    """Comparison of local vs remote state."""

    strategy_id: str
    name: str
    local_hash: str
    remote_hash: str | None
    remote_sequence: int | None
    local_modified: bool
    remote_modified: bool
    conflict: bool
    workspace_dir: str

    @property
    def state(self) -> str:
        if self.conflict:
            return "conflict"
        if self.local_modified and self.remote_modified:
            return "conflict"
        if self.local_modified:
            return "ahead"
        if self.remote_modified:
            return "behind"
        return "current"


def _compute_hash(source: str) -> str:
    """Compute SHA256 hash matching the platform's compute_source_hash."""
    return hashlib.sha256(source.encode()).hexdigest()


def get_workspace_dir(strategy_id: str) -> Path:
    """Get the workspace directory for a strategy."""
    return WORKSPACE_ROOT / strategy_id


def list_workspaces() -> list[WorkspaceMeta]:
    """List all checked-out strategies."""
    if not WORKSPACE_ROOT.exists():
        return []
    result = []
    for d in sorted(WORKSPACE_ROOT.iterdir()):
        meta_path = d / META_FILE
        if meta_path.exists():
            try:
                result.append(WorkspaceMeta.load(d))
            except (json.JSONDecodeError, KeyError):
                continue
    return result


def get_workspace(strategy_id: str) -> WorkspaceMeta | None:
    """Load workspace metadata for a strategy, or None if not checked out."""
    ws_dir = get_workspace_dir(strategy_id)
    meta_path = ws_dir / META_FILE
    if not meta_path.exists():
        return None
    try:
        return WorkspaceMeta.load(ws_dir)
    except (json.JSONDecodeError, KeyError):
        return None


def find_workspace_strategy() -> WorkspaceMeta | None:
    """Auto-detect workspace strategy from CWD or single checkout.

    Resolution order:
    1. If CWD is inside a workspace dir → use that strategy
    2. If exactly one strategy is checked out → use it
    3. Otherwise → None
    """
    cwd = Path.cwd()

    # Check if CWD is inside a workspace
    if WORKSPACE_ROOT.exists():
        try:
            cwd.relative_to(WORKSPACE_ROOT)
            # CWD is inside workspace root — find which strategy
            for d in WORKSPACE_ROOT.iterdir():
                try:
                    cwd.relative_to(d)
                    meta_path = d / META_FILE
                    if meta_path.exists():
                        return WorkspaceMeta.load(d)
                except ValueError:
                    continue
        except ValueError:
            pass

    # Check for single checkout
    workspaces = list_workspaces()
    if len(workspaces) == 1:
        return workspaces[0]

    return None


def read_local_source(strategy_id: str) -> str:
    """Read the local working copy source."""
    ws_dir = get_workspace_dir(strategy_id)
    strategy_path = ws_dir / STRATEGY_FILE
    if not strategy_path.exists():
        raise FileNotFoundError(f"No local copy for strategy '{strategy_id}'")
    return strategy_path.read_text()


def write_local_source(strategy_id: str, source: str) -> None:
    """Write to the local working copy."""
    ws_dir = get_workspace_dir(strategy_id)
    strategy_path = ws_dir / STRATEGY_FILE
    strategy_path.write_text(source)


def checkout(strategy_id: str) -> dict[str, Any]:
    """Pull a platform strategy into a local workspace.

    Fetches the strategy source from the API and creates a local
    working copy that can be edited, validated, and pushed back.

    Returns:
        Dict with workspace path and strategy metadata.
    """
    from keel.client import KeelClient

    client = KeelClient()
    try:
        strategy = client.get(f"/v1/strategies/{strategy_id}")
    finally:
        client.close()

    source = strategy.get("source")
    if not source:
        raise ValueError(f"Strategy '{strategy_id}' has no source code")

    ws_dir = get_workspace_dir(strategy_id)
    ws_dir.mkdir(parents=True, exist_ok=True)

    # Write strategy source
    (ws_dir / STRATEGY_FILE).write_text(source)

    # Write sync metadata
    meta = WorkspaceMeta(
        strategy_id=strategy_id,
        name=strategy.get("name", "unnamed"),
        source_hash=strategy.get("source_hash", _compute_hash(source)),
        checked_out_at=datetime.now(timezone.utc).isoformat(),
        org_id=strategy.get("org_id"),
        current_sequence=strategy.get("current_sequence"),
    )
    meta.save(ws_dir)

    return {
        "strategy_id": strategy_id,
        "name": meta.name,
        "workspace": str(ws_dir),
        "file": str(ws_dir / STRATEGY_FILE),
        "source_hash": meta.source_hash,
        "sequence": meta.current_sequence,
        "status": "checked_out",
    }


def push(
    strategy_id: str | None = None,
    message: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Push local changes to the platform.

    Sends the local working copy to the API via PATCH, using
    expected_source_hash for conflict detection unless force=True.

    Args:
        strategy_id: Strategy to push. Auto-detected if None.
        message: Commit message (optional).
        force: Skip conflict detection.

    Returns:
        Dict with push result including new source_hash and sequence.
    """
    if strategy_id is None:
        ws = find_workspace_strategy()
        if ws is None:
            raise ValueError("No workspace strategy found. Specify --strategy or checkout a strategy first.")
        strategy_id = ws.strategy_id

    meta = get_workspace(strategy_id)
    if meta is None:
        raise ValueError(f"Strategy '{strategy_id}' is not checked out")

    source = read_local_source(strategy_id)
    local_hash = _compute_hash(source)

    # Check if anything changed
    if local_hash == meta.source_hash:
        return {
            "strategy_id": strategy_id,
            "status": "no_changes",
            "source_hash": local_hash,
        }

    from keel.client import KeelClient

    body: dict[str, Any] = {"source": source}
    if not force:
        body["expected_source_hash"] = meta.source_hash
    if message:
        body["message"] = message

    client = KeelClient()
    try:
        result = client.patch(f"/v1/strategies/{strategy_id}", json=body)
    finally:
        client.close()

    # Update local metadata
    new_hash = result.get("source_hash", local_hash)
    meta.source_hash = new_hash
    meta.current_sequence = result.get("current_sequence", meta.current_sequence)
    meta.name = result.get("name", meta.name)
    ws_dir = get_workspace_dir(strategy_id)
    meta.save(ws_dir)

    return {
        "strategy_id": strategy_id,
        "name": meta.name,
        "status": "pushed",
        "source_hash": new_hash,
        "sequence": meta.current_sequence,
        "compilation_error": result.get("compilation_error"),
    }


def pull(strategy_id: str | None = None) -> dict[str, Any]:
    """Pull latest source from the platform into local workspace.

    Args:
        strategy_id: Strategy to pull. Auto-detected if None.

    Returns:
        Dict with pull result.
    """
    if strategy_id is None:
        ws = find_workspace_strategy()
        if ws is None:
            raise ValueError("No workspace strategy found. Specify --strategy or checkout a strategy first.")
        strategy_id = ws.strategy_id

    meta = get_workspace(strategy_id)
    if meta is None:
        raise ValueError(f"Strategy '{strategy_id}' is not checked out")

    from keel.client import KeelClient

    client = KeelClient()
    try:
        strategy = client.get(f"/v1/strategies/{strategy_id}")
    finally:
        client.close()

    remote_source = strategy.get("source")
    if not remote_source:
        raise ValueError(f"Strategy '{strategy_id}' has no source on platform")

    remote_hash = strategy.get("source_hash", _compute_hash(remote_source))

    # Check if remote has changed
    if remote_hash == meta.source_hash:
        # Check if local has uncommitted changes
        local_source = read_local_source(strategy_id)
        local_hash = _compute_hash(local_source)
        if local_hash != meta.source_hash:
            return {
                "strategy_id": strategy_id,
                "status": "local_changes",
                "message": "Remote is unchanged but you have local edits. Push when ready.",
                "local_hash": local_hash,
                "remote_hash": remote_hash,
            }
        return {
            "strategy_id": strategy_id,
            "status": "current",
            "source_hash": remote_hash,
        }

    # Check for conflict (local modified AND remote modified)
    local_source = read_local_source(strategy_id)
    local_hash = _compute_hash(local_source)
    local_modified = local_hash != meta.source_hash

    if local_modified:
        return {
            "strategy_id": strategy_id,
            "status": "conflict",
            "message": "Both local and remote have changed. Use 'pull --force' to overwrite local, or 'push --force' to overwrite remote.",
            "local_hash": local_hash,
            "remote_hash": remote_hash,
            "base_hash": meta.source_hash,
        }

    # No local changes — safe to overwrite
    ws_dir = get_workspace_dir(strategy_id)
    (ws_dir / STRATEGY_FILE).write_text(remote_source)

    meta.source_hash = remote_hash
    meta.current_sequence = strategy.get("current_sequence", meta.current_sequence)
    meta.name = strategy.get("name", meta.name)
    meta.save(ws_dir)

    return {
        "strategy_id": strategy_id,
        "name": meta.name,
        "status": "pulled",
        "source_hash": remote_hash,
        "sequence": meta.current_sequence,
    }


def pull_force(strategy_id: str) -> dict[str, Any]:
    """Force-pull remote source, discarding local changes."""
    meta = get_workspace(strategy_id)
    if meta is None:
        raise ValueError(f"Strategy '{strategy_id}' is not checked out")

    from keel.client import KeelClient

    client = KeelClient()
    try:
        strategy = client.get(f"/v1/strategies/{strategy_id}")
    finally:
        client.close()

    remote_source = strategy.get("source")
    if not remote_source:
        raise ValueError(f"Strategy '{strategy_id}' has no source on platform")

    remote_hash = strategy.get("source_hash", _compute_hash(remote_source))
    ws_dir = get_workspace_dir(strategy_id)
    (ws_dir / STRATEGY_FILE).write_text(remote_source)

    meta.source_hash = remote_hash
    meta.current_sequence = strategy.get("current_sequence", meta.current_sequence)
    meta.name = strategy.get("name", meta.name)
    meta.save(ws_dir)

    return {
        "strategy_id": strategy_id,
        "name": meta.name,
        "status": "force_pulled",
        "source_hash": remote_hash,
        "sequence": meta.current_sequence,
    }


def status(strategy_id: str | None = None) -> dict[str, Any]:
    """Compare local workspace state against the platform.

    Args:
        strategy_id: Strategy to check. Auto-detected if None.

    Returns:
        Dict with local vs remote state comparison.
    """
    if strategy_id is None:
        ws = find_workspace_strategy()
        if ws is None:
            raise ValueError("No workspace strategy found. Specify --strategy or checkout a strategy first.")
        strategy_id = ws.strategy_id

    meta = get_workspace(strategy_id)
    if meta is None:
        raise ValueError(f"Strategy '{strategy_id}' is not checked out")

    # Local state
    local_source = read_local_source(strategy_id)
    local_hash = _compute_hash(local_source)
    local_modified = local_hash != meta.source_hash

    # Remote state
    remote_hash = None
    remote_sequence = None
    remote_name = meta.name
    try:
        from keel.client import KeelClient

        client = KeelClient()
        try:
            strategy = client.get(f"/v1/strategies/{strategy_id}")
            remote_hash = strategy.get("source_hash")
            remote_sequence = strategy.get("current_sequence")
            remote_name = strategy.get("name", meta.name)
        finally:
            client.close()
    except Exception:
        # Offline or no API key — show local state only
        pass

    remote_modified = remote_hash is not None and remote_hash != meta.source_hash

    ws_status = WorkspaceStatus(
        strategy_id=strategy_id,
        name=remote_name or meta.name,
        local_hash=local_hash,
        remote_hash=remote_hash,
        remote_sequence=remote_sequence,
        local_modified=local_modified,
        remote_modified=remote_modified,
        conflict=local_modified and remote_modified,
        workspace_dir=str(get_workspace_dir(strategy_id)),
    )

    return {
        "strategy_id": strategy_id,
        "name": ws_status.name,
        "state": ws_status.state,
        "local_hash": local_hash,
        "remote_hash": remote_hash,
        "base_hash": meta.source_hash,
        "local_modified": local_modified,
        "remote_modified": remote_modified,
        "sequence": remote_sequence,
        "workspace": ws_status.workspace_dir,
        "file": str(get_workspace_dir(strategy_id) / STRATEGY_FILE),
    }


def discard(strategy_id: str | None = None) -> dict[str, Any]:
    """Remove a local workspace (does not affect the platform strategy)."""
    if strategy_id is None:
        ws = find_workspace_strategy()
        if ws is None:
            raise ValueError("No workspace strategy found.")
        strategy_id = ws.strategy_id

    ws_dir = get_workspace_dir(strategy_id)
    if not ws_dir.exists():
        raise ValueError(f"Strategy '{strategy_id}' is not checked out")

    import shutil

    shutil.rmtree(ws_dir)

    return {
        "strategy_id": strategy_id,
        "status": "discarded",
    }
