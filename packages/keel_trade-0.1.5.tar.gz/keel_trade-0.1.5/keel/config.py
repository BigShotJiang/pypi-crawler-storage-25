"""Configuration management — ~/.keel/config.yaml + env vars."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

CONFIG_DIR = Path.home() / ".keel"
CONFIG_FILE = CONFIG_DIR / "config.yaml"


@dataclass
class KeelConfig:
    api_key: str | None = None
    api_url: str = "https://api.usekeel.io"


def load_config() -> KeelConfig:
    """Load config with env var precedence: KEEL_API_KEY > config file."""
    import os

    config = KeelConfig()

    # Load from file
    if CONFIG_FILE.exists():
        try:
            data = yaml.safe_load(CONFIG_FILE.read_text()) or {}
            config.api_key = data.get("api_key", config.api_key)
            config.api_url = data.get("api_url", config.api_url)
        except Exception:
            pass  # Corrupt config — use defaults

    # Env vars override
    env_key = os.environ.get("KEEL_API_KEY")
    if env_key:
        config.api_key = env_key
    env_url = os.environ.get("KEEL_API_URL")
    if env_url:
        config.api_url = env_url

    return config


def save_config(config: KeelConfig) -> None:
    """Write config to ~/.keel/config.yaml."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    data: dict = {}
    if config.api_key:
        data["api_key"] = config.api_key
    if config.api_url != "https://api.usekeel.io":
        data["api_url"] = config.api_url
    CONFIG_FILE.write_text(yaml.dump(data, default_flow_style=False))
