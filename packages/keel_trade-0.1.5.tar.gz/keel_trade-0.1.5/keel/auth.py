"""Authentication helpers — validate, store, and retrieve API keys."""

from __future__ import annotations

from keel.client import KeelClient
from keel.config import KeelConfig, load_config, save_config


def validate_api_key(api_key: str, api_url: str | None = None) -> dict:
    """Validate an API key by calling GET /v1/me. Returns principal info."""
    config = KeelConfig(api_key=api_key)
    if api_url:
        config.api_url = api_url
    client = KeelClient(config=config)
    try:
        return client.get("/v1/me")
    finally:
        client.close()


def store_api_key(api_key: str, api_url: str | None = None) -> dict:
    """Validate and store an API key. Returns principal info."""
    info = validate_api_key(api_key, api_url)
    config = load_config()
    config.api_key = api_key
    if api_url:
        config.api_url = api_url
    save_config(config)
    return info


def clear_credentials() -> None:
    """Remove stored API key."""
    config = load_config()
    config.api_key = None
    save_config(config)


def get_identity() -> dict:
    """Get current identity via GET /v1/me."""
    client = KeelClient()
    try:
        return client.get("/v1/me")
    finally:
        client.close()


def get_status() -> dict:
    """Get identity + entitlements via GET /v1/me and GET /v1/entitlements."""
    client = KeelClient()
    try:
        me = client.get("/v1/me")
        entitlements = client.get("/v1/entitlements")
        return {**me, "entitlements": entitlements}
    finally:
        client.close()
