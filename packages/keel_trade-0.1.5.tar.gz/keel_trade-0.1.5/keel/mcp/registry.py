"""Tool registry — powers progressive discovery via search_tools/describe_tool.

Builds a unified registry from bundled tool schemas (local) and remote API tools.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import lru_cache
from importlib import resources
from typing import Any


@dataclass
class ToolSummary:
    name: str
    domain: str
    description: str
    execution: str  # "local" or "remote"


@dataclass
class ToolDetail:
    name: str
    domain: str
    description: str
    input_schema: dict
    execution: str
    examples: list[str] = field(default_factory=list)
    related_tools: list[str] = field(default_factory=list)


# Domain grouping for tools
_DOMAIN_MAP = {
    # Components
    "strategy_components_search": "components",
    "strategy_component_detail": "components",
    "strategy_components_after": "components",
    "strategy_components_before": "components",
    "strategy_components_dump": "components",
    "dsl_reference": "components",
    # Strategy (local)
    "strategy_new": "strategy",
    "strategy_validate": "strategy",
    "strategy_compile": "strategy",
    "strategy_explain": "strategy",
    "strategy_diff": "strategy",
    "strategy_examples": "strategy",
    "composition_patterns": "strategy",
    "pipeline_stage": "strategy",
    "update_strategy": "strategy",
    "strategy_lock_generate": "strategy",
    "strategy_lock_status": "strategy",
    "strategy_lock_upgrade": "strategy",
    # Strategy workspace
    "strategy_checkout": "strategy",
    "strategy_push": "strategy",
    "strategy_pull": "strategy",
    "strategy_status": "strategy",
    "strategy_workspaces": "strategy",
    "strategy_discard": "strategy",
    # Strategy (remote)
    "strategy_create": "strategy_platform",
    "strategy_list": "strategy_platform",
    "strategy_show": "strategy_platform",
    "strategy_update": "strategy_platform",
    "strategy_versions": "strategy_platform",
    "strategy_source": "strategy_platform",
    "strategy_archive": "strategy_platform",
    # Universe
    "universe_set": "universe",
    "universe_get": "universe",
    "universe_add_group": "universe",
    "universe_modify_group": "universe",
    "universe_remove_group": "universe",
    "strategy_find_local": "strategy",
    "universe_resolve": "universe",
    "universe_categories": "universe",
    "universe_instruments": "universe",
    # Backtest
    "backtest_run": "backtest",
    "backtest_status": "backtest",
    "backtest_results": "backtest",
    "backtest_list": "backtest",
    # Live
    "live_deploy": "live",
    "live_list": "live",
    "live_show": "live",
    "live_pause": "live",
    "live_resume": "live",
    "live_stop": "live",
    "live_positions": "live",
    "live_equity": "live",
    "live_pnl": "live",
    "live_stats": "live",
    "live_weights": "live",
    "live_portfolio": "live",
    # Market data
    "market_data_prices": "market_data",
    # Sharing
    "sharing_create_link": "sharing",
    "sharing_fork": "sharing",
    # Audit
    "audit_list": "audit",
}

# Tools that execute locally (no API key needed)
_LOCAL_TOOLS = {
    "strategy_components_search",
    "strategy_component_detail",
    "strategy_components_after",
    "strategy_components_before",
    "strategy_components_dump",
    "dsl_reference",
    "strategy_new",
    "strategy_validate",
    "strategy_explain",
    "strategy_diff",
    "strategy_examples",
    "composition_patterns",
    "pipeline_stage",
    "strategy_lock_generate",
    "strategy_lock_status",
    "strategy_lock_upgrade",
    "strategy_checkout",
    "strategy_push",
    "strategy_pull",
    "strategy_status",
    "strategy_workspaces",
    "strategy_discard",
    "universe_set",
    "universe_get",
    "universe_add_group",
    "universe_modify_group",
    "universe_remove_group",
    "strategy_find_local",
}

# Remote tool definitions (name → path + method + description)
_REMOTE_TOOLS: dict[str, dict[str, Any]] = {
    # Strategy (need live component classes)
    "strategy_compile": {"method": "POST", "path": "/v1/strategies/compile", "description": "Compile a strategy to executable artifacts"},
    "update_strategy": {"method": "POST", "path": "/v1/strategies/update-source", "description": "Validate + lock + graph a strategy"},
    # Strategy platform CRUD
    "strategy_create": {"method": "POST", "path": "/v1/strategies", "description": "Create a strategy on the platform"},
    "strategy_list": {"method": "GET", "path": "/v1/strategies", "description": "List strategies"},
    "strategy_show": {"method": "GET", "path": "/v1/strategies/{strategy_id}", "description": "Show strategy details"},
    "strategy_update": {"method": "PATCH", "path": "/v1/strategies/{strategy_id}", "description": "Update a strategy"},
    "strategy_versions": {"method": "GET", "path": "/v1/strategies/{strategy_id}/versions", "description": "List strategy versions"},
    "strategy_source": {"method": "GET", "path": "/v1/strategies/{strategy_id}/versions/{ref}/source", "description": "Get strategy source at version"},
    "strategy_archive": {"method": "POST", "path": "/v1/strategies/{strategy_id}/archive", "description": "Archive a strategy"},
    "universe_resolve": {"method": "POST", "path": "/v1/universe/resolve", "description": "Resolve universe criteria to symbol list"},
    "universe_categories": {"method": "GET", "path": "/v1/universe/categories", "description": "List instrument categories"},
    "universe_instruments": {"method": "GET", "path": "/v1/universe/instruments", "description": "List available instruments"},
    "backtest_run": {"method": "POST", "path": "/v1/backtests", "description": "Start a backtest"},
    "backtest_status": {"method": "GET", "path": "/v1/backtests/{backtest_id}", "description": "Get backtest status"},
    "backtest_results": {"method": "GET", "path": "/v1/backtests/{backtest_id}/results", "description": "Get backtest results"},
    "backtest_list": {"method": "GET", "path": "/v1/backtests", "description": "List backtests"},
    "live_deploy": {"method": "POST", "path": "/v1/live", "description": "Deploy strategy for live trading"},
    "live_list": {"method": "GET", "path": "/v1/live", "description": "List live deployments"},
    "live_show": {"method": "GET", "path": "/v1/live/{deployment_id}", "description": "Show deployment details"},
    "live_pause": {"method": "POST", "path": "/v1/live/{deployment_id}/pause", "description": "Pause deployment"},
    "live_resume": {"method": "POST", "path": "/v1/live/{deployment_id}/resume", "description": "Resume deployment"},
    "live_stop": {"method": "DELETE", "path": "/v1/live/{deployment_id}", "description": "Stop deployment"},
    "live_positions": {"method": "GET", "path": "/v1/live/{deployment_id}/positions", "description": "View positions"},
    "live_equity": {"method": "GET", "path": "/v1/live/{deployment_id}/equity", "description": "View equity curve"},
    "live_pnl": {"method": "GET", "path": "/v1/live/{deployment_id}/daily-pnl", "description": "View daily P&L"},
    "live_stats": {"method": "GET", "path": "/v1/live/{deployment_id}/stats", "description": "View deployment stats"},
    "live_weights": {"method": "GET", "path": "/v1/live/{deployment_id}/weights", "description": "View portfolio weights"},
    "live_portfolio": {"method": "GET", "path": "/v1/live/portfolio/summary", "description": "Aggregate portfolio summary"},
    "market_data_prices": {"method": "GET", "path": "/v1/market-data/prices", "description": "Fetch price data"},
    "sharing_create_link": {"method": "POST", "path": "/v1/strategies/{strategy_id}/share-links", "description": "Create a shareable link for a strategy"},
    "sharing_fork": {"method": "POST", "path": "/v1/strategies/fork-with-edits", "description": "Fork a shared strategy"},
    "audit_list": {"method": "GET", "path": "/v1/audit", "description": "List recent audit events"},
}


@lru_cache(maxsize=1)
def _load_tool_schemas() -> list[dict]:
    """Load tool schemas from bundled JSON."""
    ref = resources.files("keel.data").joinpath("tool_schemas.json")
    return json.loads(ref.read_text())


def _build_registry() -> dict[str, ToolSummary]:
    """Build the unified tool registry."""
    registry: dict[str, ToolSummary] = {}

    # Local tools from bundled schemas (skip tools that are now remote)
    for tool in _load_tool_schemas():
        name = tool["name"]
        if name in _DOMAIN_MAP and name not in _REMOTE_TOOLS:
            registry[name] = ToolSummary(
                name=name,
                domain=_DOMAIN_MAP[name],
                description=tool["description"],
                execution="local",
            )

    # Remote tools
    for name, info in _REMOTE_TOOLS.items():
        registry[name] = ToolSummary(
            name=name,
            domain=_DOMAIN_MAP.get(name, "platform"),
            description=info["description"],
            execution="remote",
        )

    return registry


_REGISTRY: dict[str, ToolSummary] | None = None


def get_registry() -> dict[str, ToolSummary]:
    """Get or build the tool registry (lazy singleton)."""
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = _build_registry()
    return _REGISTRY


def search_tool_registry(query: str) -> list[dict]:
    """Search tools by keyword matching against names, descriptions, and domains."""
    registry = get_registry()
    query_lower = query.lower()
    results = []
    for tool in registry.values():
        score = 0
        if query_lower in tool.name.lower():
            score += 3
        if query_lower in tool.description.lower():
            score += 2
        if query_lower in tool.domain.lower():
            score += 1
        if score > 0:
            results.append({
                "name": tool.name,
                "domain": tool.domain,
                "description": tool.description,
                "execution": tool.execution,
                "score": score,
            })
    results.sort(key=lambda r: r["score"], reverse=True)
    return results


def get_tool_detail(name: str) -> dict | None:
    """Get full detail for a tool including schema."""
    registry = get_registry()
    summary = registry.get(name)
    if not summary:
        return None

    result: dict = {
        "name": summary.name,
        "domain": summary.domain,
        "description": summary.description,
        "execution": summary.execution,
    }

    # Get schema from bundled tool schemas for local tools
    if summary.execution == "local":
        for tool in _load_tool_schemas():
            if tool["name"] == name:
                result["input_schema"] = tool["inputSchema"]
                break

    # For remote tools, include API info
    if name in _REMOTE_TOOLS:
        info = _REMOTE_TOOLS[name]
        result["method"] = info["method"]
        result["path"] = info["path"]
        if "input_schema" not in result:
            result["input_schema"] = {"type": "object", "properties": {}}

    return result
