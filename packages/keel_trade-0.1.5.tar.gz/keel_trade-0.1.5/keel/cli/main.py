"""Keel CLI — main entry point.

Usage:
    keel components search "momentum"
    keel strategy validate strategy.py
    keel auth login
"""

from __future__ import annotations

import sys

import click

from keel.cli.agent_mode import default_format


@click.group()
@click.version_option(version="0.1.0", prog_name="keel")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["json", "table", "tsv", "human"]),
    default=None,
    help="Output format (default: auto-detect from context)",
)
@click.option("--dry-run", is_flag=True, help="Preview without side effects")
@click.option("--verbose", is_flag=True, help="Verbose output")
@click.pass_context
def cli(ctx: click.Context, fmt: str | None, dry_run: bool, verbose: bool) -> None:
    """Keel — AI-native strategy development CLI."""
    ctx.ensure_object(dict)
    ctx.obj["format"] = fmt or default_format()
    ctx.obj["dry_run"] = dry_run
    ctx.obj["verbose"] = verbose


def _get_format(ctx: click.Context) -> str:
    """Get output format from Click context."""
    return ctx.obj.get("format", "json")


# ── Register command groups ──────────────────────────────────────────────

from keel.cli.commands.components import components  # noqa: E402
from keel.cli.commands.strategy import strategy  # noqa: E402
from keel.cli.commands.universe import universe  # noqa: E402

cli.add_command(components)
cli.add_command(strategy)
cli.add_command(universe)

# Phase 2 stubs — registered but raise "not yet implemented"
from keel.cli.commands.auth import auth  # noqa: E402
from keel.cli.commands.backtest import backtest  # noqa: E402
from keel.cli.commands.live import live  # noqa: E402
from keel.cli.commands.market_data import market_data  # noqa: E402
from keel.cli.commands.mcp_cmd import mcp  # noqa: E402

cli.add_command(auth)
cli.add_command(backtest)
cli.add_command(live)
cli.add_command(market_data, name="market-data")
cli.add_command(mcp)

from keel.cli.commands.sharing import sharing  # noqa: E402
from keel.cli.commands.audit import audit  # noqa: E402

cli.add_command(sharing)
cli.add_command(audit)

from keel.cli.commands.skills import skills  # noqa: E402

cli.add_command(skills)
