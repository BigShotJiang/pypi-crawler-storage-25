"""MCP server command — start the Keel MCP server."""

from __future__ import annotations

import click


@click.group()
def mcp() -> None:
    """MCP server for IDE integration."""


@mcp.command()
@click.option("--transport", type=click.Choice(["stdio", "http"]), default="stdio")
@click.option("--port", type=int, default=3100)
def serve(transport: str, port: int) -> None:
    """Start the MCP server.

    Use stdio transport for Claude Code and Cursor.
    Use http transport for remote agents.
    """
    from keel.mcp.server import create_server

    server = create_server()
    if transport == "stdio":
        server.run(transport="stdio")
    else:
        server.run(transport="streamable-http", host="0.0.0.0", port=port)
