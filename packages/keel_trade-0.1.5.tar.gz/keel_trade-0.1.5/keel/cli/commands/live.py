"""Live trading commands — 12 remote commands via keel-api."""

from __future__ import annotations

import click

from keel.cli.main import _get_format
from keel.errors import KeelError
from keel.output import emit, emit_error


def _client():
    from keel.client import KeelClient

    return KeelClient()


@click.group()
def live() -> None:
    """Live trading operations (requires API key)."""


@live.command()
@click.argument("strategy_id")
@click.option("--confirm", is_flag=True, help="Skip confirmation prompt")
@click.option("--dry-run", is_flag=True, help="Preview without deploying")
@click.pass_context
def deploy(ctx: click.Context, strategy_id: str, confirm: bool, dry_run: bool) -> None:
    """Deploy a strategy for live trading."""
    if dry_run:
        emit({"dry_run": True, "strategy_id": strategy_id, "action": "deploy"}, _get_format(ctx))
        return
    if not confirm:
        from keel.cli.agent_mode import is_agent_mode

        if not is_agent_mode():
            click.confirm(f"Deploy strategy {strategy_id} to live trading?", abort=True)
    try:
        client = _client()
        result = client.post("/v1/live", json={"strategy_id": strategy_id})
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command("list")
@click.pass_context
def list_live(ctx: click.Context) -> None:
    """List active live deployments."""
    try:
        result = _client().get("/v1/live")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def show(ctx: click.Context, deployment_id: str) -> None:
    """Show deployment details."""
    try:
        result = _client().get(f"/v1/live/{deployment_id}")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def pause(ctx: click.Context, deployment_id: str) -> None:
    """Pause a live deployment."""
    try:
        result = _client().post(f"/v1/live/{deployment_id}/pause")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def resume(ctx: click.Context, deployment_id: str) -> None:
    """Resume a paused deployment."""
    try:
        result = _client().post(f"/v1/live/{deployment_id}/resume")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def stop(ctx: click.Context, deployment_id: str) -> None:
    """Stop a live deployment."""
    try:
        result = _client().delete(f"/v1/live/{deployment_id}")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def positions(ctx: click.Context, deployment_id: str) -> None:
    """View current positions."""
    try:
        result = _client().get(f"/v1/live/{deployment_id}/positions")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def equity(ctx: click.Context, deployment_id: str) -> None:
    """View equity curve."""
    try:
        result = _client().get(f"/v1/live/{deployment_id}/equity")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def pnl(ctx: click.Context, deployment_id: str) -> None:
    """View daily P&L."""
    try:
        result = _client().get(f"/v1/live/{deployment_id}/daily-pnl")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def stats(ctx: click.Context, deployment_id: str) -> None:
    """View deployment statistics."""
    try:
        result = _client().get(f"/v1/live/{deployment_id}/stats")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.argument("deployment_id")
@click.pass_context
def weights(ctx: click.Context, deployment_id: str) -> None:
    """View current portfolio weights."""
    try:
        result = _client().get(f"/v1/live/{deployment_id}/weights")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@live.command()
@click.pass_context
def portfolio(ctx: click.Context) -> None:
    """View aggregate portfolio summary."""
    try:
        result = _client().get("/v1/live/portfolio/summary")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
