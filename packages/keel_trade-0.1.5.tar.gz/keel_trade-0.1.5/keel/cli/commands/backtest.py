"""Backtest commands — 4 remote commands via keel-api."""

from __future__ import annotations

import click

from keel.cli.main import _get_format
from keel.errors import KeelError
from keel.output import emit, emit_error


def _client():
    from keel.client import KeelClient

    return KeelClient()


@click.group()
def backtest() -> None:
    """Run and inspect backtests (requires API key)."""


@backtest.command()
@click.argument("strategy_id")
@click.option("--start-date", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--end-date", required=True, help="End date (YYYY-MM-DD)")
@click.pass_context
def run(ctx: click.Context, strategy_id: str, start_date: str, end_date: str) -> None:
    """Start a backtest for a strategy."""
    try:
        client = _client()
        result = client.post(
            "/v1/backtests",
            json={"strategy_id": strategy_id, "start_date": start_date, "end_date": end_date},
        )
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@backtest.command()
@click.argument("backtest_id")
@click.pass_context
def status(ctx: click.Context, backtest_id: str) -> None:
    """Get backtest status and results."""
    try:
        client = _client()
        result = client.get(f"/v1/backtests/{backtest_id}")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@backtest.command()
@click.argument("backtest_id")
@click.pass_context
def results(ctx: click.Context, backtest_id: str) -> None:
    """Get detailed backtest results."""
    try:
        client = _client()
        result = client.get(f"/v1/backtests/{backtest_id}/results")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@backtest.command("list")
@click.option("--strategy-id", help="Filter by strategy ID")
@click.option("--limit", type=int, default=10, help="Max results")
@click.pass_context
def list_backtests(ctx: click.Context, strategy_id: str | None, limit: int) -> None:
    """List recent backtests."""
    try:
        client = _client()
        params: dict = {"limit": limit}
        if strategy_id:
            params["strategy_id"] = strategy_id
        result = client.get("/v1/backtests", **params)
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
