"""Strategy commands — local validation/analysis + remote compile/CRUD."""

from __future__ import annotations

import sys

import click

from keel.cli.main import _get_format
from keel.output import emit, emit_error


def _read_source(file_arg: str) -> str:
    """Read strategy source from file, stdin, or auto-detected workspace.

    Resolution order:
    1. Explicit file path (not '-') → read file
    2. Stdin ('-') with piped input → read stdin
    3. Auto-detect workspace strategy → read working copy
    """
    if file_arg != "-":
        from pathlib import Path

        p = Path(file_arg)
        if not p.exists():
            raise click.BadParameter(f"File not found: {file_arg}")
        return p.read_text()

    if not sys.stdin.isatty():
        content = sys.stdin.read()
        if content.strip():
            return content
        # Empty stdin (e.g., CliRunner with no input) — fall through to workspace

    # Auto-detect workspace
    from keel.workspace import find_workspace_strategy, read_local_source

    ws = find_workspace_strategy()
    if ws:
        return read_local_source(ws.strategy_id)

    raise click.UsageError(
        "No input provided. Either:\n"
        "  - Pass a file: keel strategy validate strategy.py\n"
        "  - Pipe stdin:  cat strategy.py | keel strategy validate -\n"
        "  - Checkout:    keel strategy checkout <id>  (then omit file arg)"
    )


def _read_source_with_lock(file_arg: str) -> tuple[str, dict | None]:
    """Read source and auto-generate component lock."""
    source = _read_source(file_arg)
    try:
        from keel.tools.local import strategy_lock_generate

        lock = strategy_lock_generate(source=source).get("component_lock")
    except Exception:
        lock = None
    return source, lock


@click.group()
def strategy() -> None:
    """Create, validate, and analyze strategies."""


@strategy.command()
@click.argument("name")
@click.option("--template", default="basic", help="Template: basic, momentum, multi_factor, carry")
@click.option("--dir", "strategy_dir", default=None, help="Output directory")
@click.pass_context
def new(ctx: click.Context, name: str, template: str, strategy_dir: str | None) -> None:
    """Create a new strategy from a template."""
    from keel.tools.local import strategy_new_inline

    try:
        result = strategy_new_inline(name=name, template=template, strategy_dir=strategy_dir)
        emit(result, _get_format(ctx))
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command()
@click.argument("file", default="-")
@click.pass_context
def validate(ctx: click.Context, file: str) -> None:
    """Validate a strategy source file."""
    from keel.tools.local import strategy_validate

    try:
        source, lock = _read_source_with_lock(file)
        result = strategy_validate(source=source, component_lock=lock)
        emit(result, _get_format(ctx))
        if not result.get("valid", False):
            ctx.exit(7)
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("compile")
@click.argument("file", default="-")
@click.pass_context
def compile_cmd(ctx: click.Context, file: str) -> None:
    """Compile a strategy to executable artifacts (remote)."""
    from keel.errors import KeelError
    from keel.tools.remote import strategy_compile

    try:
        source, lock = _read_source_with_lock(file)
        result = strategy_compile(source=source, component_lock=lock)
        emit(result, _get_format(ctx))
        if result.get("compiled") is False:
            ctx.exit(7)
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command()
@click.argument("file", default="-")
@click.pass_context
def explain(ctx: click.Context, file: str) -> None:
    """Explain a strategy's structure and type flow."""
    from keel.tools.local import strategy_explain

    try:
        source, lock = _read_source_with_lock(file)
        result = strategy_explain(source=source, component_lock=lock)
        emit(result, _get_format(ctx))
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command()
@click.argument("file_a")
@click.argument("file_b")
@click.pass_context
def diff(ctx: click.Context, file_a: str, file_b: str) -> None:
    """Compute structural diff between two strategies."""
    from keel.tools.local import strategy_diff

    try:
        source_a = _read_source(file_a)
        source_b = _read_source(file_b)
        result = strategy_diff(source_a=source_a, source_b=source_b)
        emit(result, _get_format(ctx))
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command()
@click.argument("file", default="-")
@click.pass_context
def stage(ctx: click.Context, file: str) -> None:
    """Assess pipeline completeness toward backtest readiness."""
    from keel.tools.local import pipeline_stage

    try:
        source = _read_source(file)
        result = pipeline_stage(source=source)
        emit(result, _get_format(ctx))
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command()
@click.option("--query", help="Search query")
@click.option("--complexity", type=click.Choice(["simple", "medium", "complex"]))
@click.option("--name", help="Get specific example by name")
@click.pass_context
def examples(ctx: click.Context, query: str | None, complexity: str | None, name: str | None) -> None:
    """Browse or search curated example strategies."""
    from keel.tools.local import strategy_examples

    kwargs: dict = {}
    if query:
        kwargs["query"] = query
    if complexity:
        kwargs["complexity"] = complexity
    if name:
        kwargs["name"] = name
    result = strategy_examples(**kwargs)
    emit(result, _get_format(ctx))


@strategy.command()
@click.argument("query")
@click.pass_context
def patterns(ctx: click.Context, query: str) -> None:
    """Query composition patterns by strategy goal."""
    from keel.tools.local import composition_patterns

    result = composition_patterns(query=query)
    emit(result, _get_format(ctx))


@strategy.command("lock-status")
@click.argument("file", default="-")
@click.pass_context
def lock_status(ctx: click.Context, file: str) -> None:
    """Check component version drift."""
    from keel.tools.local import strategy_lock_status

    try:
        source, lock = _read_source_with_lock(file)
        result = strategy_lock_status(source=source, component_lock=lock)
        emit(result, _get_format(ctx))
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("lock-upgrade")
@click.argument("file", default="-")
@click.option("--components", multiple=True, help="Specific components to upgrade")
@click.pass_context
def lock_upgrade(ctx: click.Context, file: str, components: tuple[str, ...]) -> None:
    """Upgrade component versions in strategy lock."""
    from keel.tools.local import strategy_lock_upgrade

    try:
        source, lock = _read_source_with_lock(file)
        kwargs: dict = {"source": source}
        if lock:
            kwargs["component_lock"] = lock
        if components:
            kwargs["components"] = list(components)
        result = strategy_lock_upgrade(**kwargs)
        emit(result, _get_format(ctx))
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# WORKSPACE COMMANDS (checkout/push/pull/status)
# ═══════════════════════════════════════════════════════════════════════════════


@strategy.command()
@click.argument("strategy_id")
@click.pass_context
def checkout(ctx: click.Context, strategy_id: str) -> None:
    """Check out a platform strategy for local editing.

    Creates a local working copy at ~/.keel/workspace/<id>/strategy.py.
    Subsequent validate/explain/stage commands auto-detect this file.
    """
    from keel.errors import KeelError
    from keel.workspace import checkout as ws_checkout

    try:
        result = ws_checkout(strategy_id)
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("push")
@click.option("--strategy", "strategy_id", default=None, help="Strategy ID (auto-detected if omitted)")
@click.option("--message", "-m", default=None, help="Commit message")
@click.option("--force", is_flag=True, help="Skip conflict detection")
@click.pass_context
def push_cmd(ctx: click.Context, strategy_id: str | None, message: str | None, force: bool) -> None:
    """Push local changes to the platform.

    Saves local edits back to the platform, creating a new version
    if the source compiled successfully. Uses optimistic concurrency
    to detect conflicts with editor changes.
    """
    from keel.errors import KeelError
    from keel.workspace import push as ws_push

    try:
        result = ws_push(strategy_id=strategy_id, message=message, force=force)
        emit(result, _get_format(ctx))
        if result.get("status") == "no_changes":
            ctx.exit(0)
    except KeelError as e:
        if e.exit_code == 5:  # Conflict
            emit_error({
                "error": "conflict",
                "message": "Remote has changed since checkout. Run 'keel strategy pull' first, or use --force.",
                "details": str(e),
            }, _get_format(ctx))
        else:
            emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("pull")
@click.option("--strategy", "strategy_id", default=None, help="Strategy ID (auto-detected if omitted)")
@click.option("--force", is_flag=True, help="Overwrite local changes")
@click.pass_context
def pull_cmd(ctx: click.Context, strategy_id: str | None, force: bool) -> None:
    """Pull latest source from the platform.

    Updates the local working copy with the latest version from the
    platform. Detects conflicts if both local and remote have changed.
    """
    from keel.errors import KeelError
    from keel.workspace import pull as ws_pull, pull_force

    try:
        if force and strategy_id:
            result = pull_force(strategy_id)
        elif force:
            from keel.workspace import find_workspace_strategy

            ws = find_workspace_strategy()
            if ws is None:
                raise click.UsageError("No workspace strategy found. Specify --strategy.")
            result = pull_force(ws.strategy_id)
        else:
            result = ws_pull(strategy_id=strategy_id)
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("status")
@click.option("--strategy", "strategy_id", default=None, help="Strategy ID (auto-detected if omitted)")
@click.pass_context
def status_cmd(ctx: click.Context, strategy_id: str | None) -> None:
    """Show local vs remote sync state.

    Compares the local working copy against the platform version
    and reports: current, ahead (local changes), behind (remote changes),
    or conflict (both changed).
    """
    from keel.workspace import status as ws_status

    try:
        result = ws_status(strategy_id=strategy_id)
        emit(result, _get_format(ctx))
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("workspaces")
@click.pass_context
def workspaces_cmd(ctx: click.Context) -> None:
    """List all checked-out strategies."""
    from keel.workspace import list_workspaces

    workspaces = list_workspaces()
    if not workspaces:
        emit({"workspaces": [], "count": 0}, _get_format(ctx))
        return
    result = {
        "workspaces": [
            {
                "strategy_id": ws.strategy_id,
                "name": ws.name,
                "source_hash": ws.source_hash[:12],
                "checked_out_at": ws.checked_out_at,
            }
            for ws in workspaces
        ],
        "count": len(workspaces),
    }
    emit(result, _get_format(ctx))


@strategy.command("discard")
@click.option("--strategy", "strategy_id", default=None, help="Strategy ID (auto-detected if omitted)")
@click.pass_context
def discard_cmd(ctx: click.Context, strategy_id: str | None) -> None:
    """Remove a local workspace (does not affect the platform strategy)."""
    from keel.workspace import discard as ws_discard

    try:
        result = ws_discard(strategy_id=strategy_id)
        emit(result, _get_format(ctx))
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


# ═══════════════════════════════════════════════════════════════════════════════
# REMOTE COMMANDS (require API key)
# ═══════════════════════════════════════════════════════════════════════════════


def _client():
    from keel.client import KeelClient

    return KeelClient()


@strategy.command()
@click.argument("file", default="-")
@click.option("--no-checkout", is_flag=True, help="Don't auto-checkout after creation")
@click.pass_context
def create(ctx: click.Context, file: str, no_checkout: bool) -> None:
    """Create a strategy on the platform and check it out locally.

    After creation, the strategy is automatically checked out to
    ~/.keel/workspace/ for local editing. Use --no-checkout to skip.
    """
    from keel.errors import KeelError

    try:
        source, lock = _read_source_with_lock(file)
        body: dict = {"source": source}
        if lock:
            body["component_lock"] = lock
        result = _client().post("/v1/strategies", json=body)

        # Auto-checkout
        strategy_id = result.get("id")
        if strategy_id and not no_checkout:
            try:
                from keel.workspace import checkout as ws_checkout

                ws_result = ws_checkout(strategy_id)
                result["workspace"] = ws_result.get("workspace")
                result["workspace_file"] = ws_result.get("file")
            except Exception:
                pass  # Checkout failure shouldn't fail the create

        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command("list")
@click.option("--search", help="Search filter")
@click.option("--status", "status_filter", help="Status filter")
@click.option("--limit", type=int, default=20, help="Max results")
@click.pass_context
def list_strategies(ctx: click.Context, search: str | None, status_filter: str | None, limit: int) -> None:
    """List strategies on the platform (remote)."""
    from keel.errors import KeelError

    try:
        params: dict = {"limit": limit}
        if search:
            params["search"] = search
        if status_filter:
            params["status"] = status_filter
        result = _client().get("/v1/strategies", **params)
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@strategy.command()
@click.argument("strategy_id")
@click.pass_context
def show(ctx: click.Context, strategy_id: str) -> None:
    """Show strategy details (remote)."""
    from keel.errors import KeelError

    try:
        result = _client().get(f"/v1/strategies/{strategy_id}", include="graph")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@strategy.command("update")
@click.argument("strategy_id")
@click.argument("file", default="-")
@click.pass_context
def update_remote(ctx: click.Context, strategy_id: str, file: str) -> None:
    """Update a strategy on the platform (remote)."""
    from keel.errors import KeelError

    try:
        source, lock = _read_source_with_lock(file)
        body: dict = {"source": source}
        if lock:
            body["component_lock"] = lock
        result = _client().patch(f"/v1/strategies/{strategy_id}", json=body)
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except click.BadParameter:
        raise
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@strategy.command()
@click.argument("strategy_id")
@click.pass_context
def versions(ctx: click.Context, strategy_id: str) -> None:
    """List strategy versions (remote)."""
    from keel.errors import KeelError

    try:
        result = _client().get(f"/v1/strategies/{strategy_id}/versions")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@strategy.command()
@click.argument("strategy_id")
@click.argument("ref", default="latest")
@click.pass_context
def source(ctx: click.Context, strategy_id: str, ref: str) -> None:
    """Get strategy source at a version (remote)."""
    from keel.errors import KeelError

    try:
        result = _client().get(f"/v1/strategies/{strategy_id}/versions/{ref}/source")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@strategy.command()
@click.argument("strategy_id")
@click.pass_context
def archive(ctx: click.Context, strategy_id: str) -> None:
    """Archive a strategy (remote)."""
    from keel.errors import KeelError

    try:
        result = _client().post(f"/v1/strategies/{strategy_id}/archive")
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
