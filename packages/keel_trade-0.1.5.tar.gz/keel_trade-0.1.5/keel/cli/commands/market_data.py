"""Market data commands — remote via keel-api."""

from __future__ import annotations

import click

from keel.cli.main import _get_format
from keel.errors import KeelError
from keel.output import emit, emit_error


@click.group()
def market_data() -> None:
    """Fetch market data (requires API key)."""


@market_data.command()
@click.option("--symbols", multiple=True, required=True, help="Symbol(s) to fetch")
@click.option("--start", required=True, help="Start date (YYYY-MM-DD)")
@click.option("--end", required=True, help="End date (YYYY-MM-DD)")
@click.option("--timeframe", default="1d", help="Bar timeframe (default: 1d)")
@click.pass_context
def prices(ctx: click.Context, symbols: tuple[str, ...], start: str, end: str, timeframe: str) -> None:
    """Fetch price data for symbols."""
    try:
        from keel.client import KeelClient

        client = KeelClient()
        result = client.get(
            "/v1/market-data/prices",
            symbols=",".join(symbols),
            start=start,
            end=end,
            timeframe=timeframe,
        )
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
