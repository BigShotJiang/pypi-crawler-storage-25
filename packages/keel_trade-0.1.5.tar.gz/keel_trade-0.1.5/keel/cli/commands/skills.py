"""Skills command — structured progressive discovery for AI agents.

Implements the CLI Skills Protocol: agents call `keel skills` for a compact
overview (~200 tokens), then `keel skills <name>` for full detail on a
specific capability. This replaces parsing --help text.
"""

from __future__ import annotations

import click

from keel.cli.main import _get_format
from keel.output import emit


# Level 0: compact overview (< 300 tokens total)
_SKILLS = [
    {
        "id": "discover",
        "summary": "Search 160+ pipeline components by keyword, category, type, or natural language",
        "commands": ["components search", "components detail", "components after", "components before"],
        "common": True,
        "auth": False,
    },
    {
        "id": "create",
        "summary": "Create strategies from templates, compose pipelines, validate structure",
        "commands": ["strategy new", "strategy validate", "strategy stage", "strategy explain"],
        "common": True,
        "auth": False,
    },
    {
        "id": "workspace",
        "summary": "Check out platform strategies for local editing, push/pull changes, handle conflicts",
        "commands": ["strategy checkout", "strategy push", "strategy pull", "strategy status"],
        "common": True,
        "auth": True,
    },
    {
        "id": "universe",
        "summary": "Configure which assets a strategy trades — mode, symbols, groups, exclusions",
        "commands": ["universe set", "universe get", "universe add-group", "universe modify-group"],
        "common": True,
        "auth": False,
    },
    {
        "id": "backtest",
        "summary": "Run backtests, monitor progress, retrieve and compare results",
        "commands": ["backtest run", "backtest status", "backtest results", "backtest list"],
        "common": True,
        "auth": True,
    },
    {
        "id": "deploy",
        "summary": "Deploy strategies for live trading, monitor positions, equity, P&L",
        "commands": ["live deploy", "live list", "live positions", "live stop"],
        "common": False,
        "auth": True,
    },
    {
        "id": "reference",
        "summary": "DSL reference docs, composition patterns, strategy examples",
        "commands": ["components reference", "strategy patterns", "strategy examples"],
        "common": False,
        "auth": False,
    },
    {
        "id": "share",
        "summary": "Create shareable links, fork shared strategies, view audit log",
        "commands": ["sharing create-link", "sharing fork", "audit list"],
        "common": False,
        "auth": True,
    },
]

# Level 1: detailed per-skill
_SKILL_DETAILS = {
    "discover": {
        "id": "discover",
        "description": "Search and explore the component registry. Components are the building blocks of trading pipelines.",
        "workflow": [
            "keel components search 'momentum'  — keyword search, returns top 10",
            "keel components search --category indicator  — filter by category",
            "keel components detail ROC  — full spec with parameters, types, description",
            "keel components after ROC  — what can follow ROC (type-compatible successors)",
            "keel components before ForecastScaler  — what can precede it",
            "keel components list  — all 160+ components",
        ],
        "output": "JSON array of {name, category, description, input_type, output_type}",
        "tips": "Use 'after' and 'before' to find type-compatible neighbors when composing pipelines.",
    },
    "create": {
        "id": "create",
        "description": "Build strategies from scratch or templates. Validate locally before uploading.",
        "workflow": [
            "keel strategy new my_strat --template momentum  — create from template",
            "keel strategy validate  — 9-pass validation (types, phases, params, slots)",
            "keel strategy stage  — check if pipeline reaches WeightSeries (backtest-ready)",
            "keel strategy explain  — structural walkthrough with type flow",
            "keel strategy create my_strat.py  — upload to platform + auto-checkout",
        ],
        "output": "validate returns {valid, errors[], warnings[], type_flow[]}. stage returns {stage, backtest_ready, final_output_type}.",
        "tips": "Always validate before creating. stage must show backtest_ready: true before backtesting.",
    },
    "workspace": {
        "id": "workspace",
        "description": "Checkout/push/pull model for editing platform strategies locally. Like lightweight git for strategies.",
        "workflow": [
            "keel strategy checkout <strategy_id>  — pull to ~/.keel/workspace/<id>/strategy.py",
            "keel strategy validate  — auto-detects workspace, no file arg needed",
            "keel universe set --mode top_volume --top-n 30  — edits workspace file in place",
            "keel strategy push -m 'description'  — push to platform, creates version",
            "keel strategy pull  — pull if web editor changed it",
            "keel strategy status  — shows: current / ahead / behind / conflict",
            "keel strategy workspaces  — list all checked-out strategies",
            "keel strategy discard  — remove local workspace",
        ],
        "output": "checkout returns {strategy_id, workspace, file}. push returns {status, source_hash, sequence}. status returns {state, local_modified, remote_modified}.",
        "tips": "Push uses optimistic concurrency. If push fails with conflict (exit 5), pull first then push again.",
    },
    "universe": {
        "id": "universe",
        "description": "Control which assets a strategy trades. Supports manual lists, category filters, and volume-ranked selection.",
        "workflow": [
            "keel universe get  — read current universe config from workspace",
            "keel universe set --mode top_volume --top-n 30  — set universe criteria",
            "keel universe set --mode manual --symbols BTC --symbols ETH  — explicit list",
            "keel universe add-group my_group --symbols BTC --symbols ETH  — named group",
            "keel universe modify-group my_group --add SOL --remove ETH  — edit group",
            "keel universe remove-group my_group  — remove group",
        ],
        "output": "Returns {source, universe: {mode, market, symbols, top_n, groups}}. Source is the updated DSL.",
        "tips": "Universe commands write back to the workspace file automatically. No separate save needed.",
    },
    "backtest": {
        "id": "backtest",
        "description": "Run backtests on the platform and retrieve performance metrics.",
        "workflow": [
            "keel strategy push -m 'ready for backtest'  — push changes first",
            "keel backtest run <strategy_id> --start-date 2024-01-01 --end-date 2025-01-01",
            "keel backtest status <backtest_id>  — poll until completed",
            "keel backtest results <backtest_id>  — detailed metrics",
            "keel backtest list --strategy-id <id>  — compare across runs",
        ],
        "output": "run returns {backtest_id}. results returns {sharpe, max_drawdown, annual_return, ...}.",
        "tips": "Change ONE thing between backtests. Push creates a version so you can always compare.",
    },
    "deploy": {
        "id": "deploy",
        "description": "Deploy strategies for live trading on Hyperliquid.",
        "workflow": [
            "keel live deploy <strategy_id>  — deploy for live trading",
            "keel live list  — all deployments",
            "keel live show <deployment_id>  — deployment details",
            "keel live positions <deployment_id>  — current positions",
            "keel live equity <deployment_id>  — equity curve",
            "keel live pnl <deployment_id>  — daily P&L",
            "keel live pause <deployment_id>  — pause trading",
            "keel live resume <deployment_id>  — resume trading",
            "keel live stop <deployment_id>  — stop and close positions",
        ],
        "output": "deploy returns {deployment_id, status}. positions returns [{symbol, size, entry_price, unrealized_pnl}].",
        "tips": "Always backtest thoroughly before deploying. Use pause/resume for temporary halts.",
    },
    "reference": {
        "id": "reference",
        "description": "DSL documentation, composition patterns, and strategy examples.",
        "workflow": [
            "keel components reference  — list all topics (phases, types, slots, composition, normalization, best_practices)",
            "keel components reference types  — type flow system docs",
            "keel strategy patterns 'momentum sizing'  — search composition patterns",
            "keel strategy examples --complexity simple  — browse by complexity",
        ],
        "output": "reference returns {topics, descriptions} or {topic, content}. patterns returns {patterns[], query, match_count}.",
        "tips": "Read 'phases' and 'types' first to understand the pipeline model.",
    },
    "share": {
        "id": "share",
        "description": "Share strategies with other users and view platform audit log.",
        "workflow": [
            "keel sharing create-link <strategy_id>  — create shareable link",
            "keel sharing fork <share_id>  — fork a shared strategy into your workspace",
            "keel audit list  — recent platform actions",
            "keel audit list --agent-id <id>  — filter by agent",
        ],
        "output": "create-link returns {share_id, url}. fork returns {id, name, status}.",
        "tips": "Forked strategies are independent copies — changes don't affect the original.",
    },
}


@click.command("skills")
@click.argument("skill_name", required=False)
@click.pass_context
def skills(ctx: click.Context, skill_name: str | None) -> None:
    """Structured capability discovery for AI agents.

    Without arguments: returns compact overview of all capabilities (~200 tokens).
    With a skill name: returns detailed workflow, commands, and output shapes.

    \b
    Examples:
        keel skills              # Overview of all capabilities
        keel skills create       # Full detail on strategy creation
        keel skills backtest     # Full detail on backtesting
    """
    if skill_name is None:
        # Level 0: compact overview
        emit(_SKILLS, _get_format(ctx))
    else:
        detail = _SKILL_DETAILS.get(skill_name)
        if detail is None:
            available = sorted(_SKILL_DETAILS.keys())
            emit(
                {"error": "unknown_skill", "message": f"Unknown skill '{skill_name}'", "available": available},
                _get_format(ctx),
            )
            ctx.exit(2)
        else:
            emit(detail, _get_format(ctx))
