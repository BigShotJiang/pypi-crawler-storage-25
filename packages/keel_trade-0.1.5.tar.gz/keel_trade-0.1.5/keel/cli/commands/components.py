"""Component discovery commands — all local, no API key needed."""

from __future__ import annotations

import click

from keel.cli.main import _get_format
from keel.output import emit, emit_error


@click.group()
def components() -> None:
    """Discover and inspect pipeline components."""


@components.command()
@click.argument("query", required=False)
@click.option("--keyword", help="Case-insensitive keyword filter")
@click.option("--category", help="Component category filter")
@click.option("--sub-category", help="Sub-category filter")
@click.option("--input-type", help="Required input type")
@click.option("--output-type", help="Required output type")
@click.option("--top-k", type=int, default=10, help="Max results")
@click.pass_context
def search(
    ctx: click.Context,
    query: str | None,
    keyword: str | None,
    category: str | None,
    sub_category: str | None,
    input_type: str | None,
    output_type: str | None,
    top_k: int,
) -> None:
    """Search components by keyword, category, or natural language query."""
    from keel.tools.local import strategy_components_search

    kwargs: dict = {"top_k": top_k}
    if query:
        kwargs["query"] = query
    if keyword:
        kwargs["keyword"] = keyword
    if category:
        kwargs["category"] = category
    if sub_category:
        kwargs["sub_category"] = sub_category
    if input_type:
        kwargs["input_type"] = input_type
    if output_type:
        kwargs["output_type"] = output_type

    try:
        results = strategy_components_search(**kwargs)
        emit(results, _get_format(ctx), columns=["name", "category", "description"])
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(1)


@components.command()
@click.argument("name")
@click.pass_context
def detail(ctx: click.Context, name: str) -> None:
    """Get full specification for a component."""
    from keel.tools.local import strategy_component_detail

    try:
        result = strategy_component_detail(name)
        emit(result, _get_format(ctx))
    except KeyError:
        emit_error({"error": "not_found", "message": f"Component '{name}' not found"}, _get_format(ctx))
        ctx.exit(3)


@components.command()
@click.argument("name")
@click.pass_context
def after(ctx: click.Context, name: str) -> None:
    """Find components that can follow a given component."""
    from keel.tools.local import strategy_components_after

    try:
        results = strategy_components_after(name)
        emit(results, _get_format(ctx), columns=["name", "category", "description"])
    except KeyError:
        emit_error({"error": "not_found", "message": f"Component '{name}' not found"}, _get_format(ctx))
        ctx.exit(3)


@components.command()
@click.argument("name")
@click.pass_context
def before(ctx: click.Context, name: str) -> None:
    """Find components that can precede a given component."""
    from keel.tools.local import strategy_components_before

    try:
        results = strategy_components_before(name)
        emit(results, _get_format(ctx), columns=["name", "category", "description"])
    except KeyError:
        emit_error({"error": "not_found", "message": f"Component '{name}' not found"}, _get_format(ctx))
        ctx.exit(3)


@components.command("list")
@click.option("--category", help="Filter by category")
@click.pass_context
def list_components(ctx: click.Context, category: str | None) -> None:
    """List all registered components."""
    from keel.tools.local import strategy_components_dump

    results = strategy_components_dump()
    if category:
        cat_lower = category.lower()
        results = [r for r in results if r.get("category", "").lower() == cat_lower]
    emit(results, _get_format(ctx), columns=["name", "category", "input_type", "output_type"])


@components.command()
@click.argument("topic", required=False)
@click.pass_context
def reference(ctx: click.Context, topic: str | None) -> None:
    """Load DSL reference documentation."""
    from keel.tools.local import dsl_reference

    kwargs: dict = {}
    if topic:
        kwargs["topic"] = topic
    result = dsl_reference(**kwargs)
    emit(result, _get_format(ctx))
