"""Auth commands — login, logout, whoami, status."""

from __future__ import annotations

import click

from keel.cli.agent_mode import is_agent_mode
from keel.cli.main import _get_format
from keel.errors import KeelError
from keel.output import emit, emit_error


@click.group()
def auth() -> None:
    """Authenticate with the Keel platform."""


@auth.command()
@click.option("--key", help="API key (reads from stdin in agent mode)")
@click.pass_context
def login(ctx: click.Context, key: str | None) -> None:
    """Log in with an API key."""
    from keel.auth import store_api_key

    if not key:
        if is_agent_mode():
            import sys

            key = sys.stdin.readline().strip()
        else:
            key = click.prompt("API key", hide_input=True)
    if not key:
        emit_error({"error": "usage_error", "message": "No API key provided"}, _get_format(ctx))
        ctx.exit(2)
        return
    try:
        info = store_api_key(key)
        emit({"authenticated": True, **info}, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
    except Exception as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(4)


@auth.command()
@click.pass_context
def logout(ctx: click.Context) -> None:
    """Clear stored credentials."""
    from keel.auth import clear_credentials

    clear_credentials()
    emit({"logged_out": True}, _get_format(ctx))


@auth.command()
@click.pass_context
def whoami(ctx: click.Context) -> None:
    """Show current identity, org, and plan."""
    from keel.auth import get_identity

    try:
        info = get_identity()
        emit(info, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@auth.command()
@click.pass_context
def status(ctx: click.Context) -> None:
    """Show entitlement balances and active deployments."""
    from keel.auth import get_status

    try:
        info = get_status()
        emit(info, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
