"""Audit commands — view action history (remote)."""
from __future__ import annotations
import click
from keel.cli.main import _get_format
from keel.output import emit, emit_error


def _client():
    from keel.client import KeelClient
    return KeelClient()


@click.group()
def audit() -> None:
    """View audit log of platform actions."""


@audit.command("list")
@click.option("--limit", type=int, default=20, help="Max results")
@click.option("--agent-id", help="Filter by agent ID")
@click.pass_context
def list_events(ctx: click.Context, limit: int, agent_id: str | None) -> None:
    """List recent audit events (remote)."""
    from keel.errors import KeelError
    try:
        params: dict = {"limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        result = _client().get("/v1/audit", **params)
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
