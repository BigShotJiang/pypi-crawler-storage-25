"""Sharing commands — create shareable links and fork strategies (remote)."""
from __future__ import annotations
import click
from keel.cli.main import _get_format
from keel.output import emit, emit_error


def _client():
    from keel.client import KeelClient
    return KeelClient()


@click.group()
def sharing() -> None:
    """Share strategies and fork shared strategies."""


@sharing.command("create-link")
@click.argument("strategy_id")
@click.option("--permission", default="view", type=click.Choice(["view", "fork"]),
              help="Permission level for the share link")
@click.pass_context
def create_link(ctx: click.Context, strategy_id: str, permission: str) -> None:
    """Create a shareable link for a strategy (remote)."""
    from keel.errors import KeelError
    try:
        result = _client().post(
            f"/v1/strategies/{strategy_id}/share-links",
            json={"permission": permission}
        )
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)


@sharing.command()
@click.argument("share_id")
@click.pass_context
def fork(ctx: click.Context, share_id: str) -> None:
    """Fork a shared strategy into your workspace (remote)."""
    from keel.errors import KeelError
    try:
        result = _client().post(
            "/v1/strategies/fork-with-edits",
            json={"share_link_id": share_id}
        )
        emit(result, _get_format(ctx))
    except KeelError as e:
        emit_error(e, _get_format(ctx))
        ctx.exit(e.exit_code)
