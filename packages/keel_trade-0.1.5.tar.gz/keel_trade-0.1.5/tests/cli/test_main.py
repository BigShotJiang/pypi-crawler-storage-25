"""Tests for keel CLI framework."""

import json
import os
from unittest.mock import patch

from click.testing import CliRunner

from keel.cli.main import cli

runner = CliRunner()


# ── help ─────────────────────────────────────────────────────────────────────


def test_help():
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "components" in result.output
    assert "strategy" in result.output
    assert "universe" in result.output
    assert "auth" in result.output
    assert "backtest" in result.output


def test_help_shows_all_groups():
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "market-data" in result.output
    assert "mcp" in result.output
    assert "live" in result.output


def test_help_shows_options():
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "--format" in result.output
    assert "--dry-run" in result.output
    assert "--verbose" in result.output
    assert "--version" in result.output


# ── version ──────────────────────────────────────────────────────────────────


def test_version():
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


# ── subcommand help ──────────────────────────────────────────────────────────


def test_components_help():
    result = runner.invoke(cli, ["components", "--help"])
    assert result.exit_code == 0
    assert "search" in result.output
    assert "detail" in result.output
    assert "after" in result.output
    assert "before" in result.output
    assert "list" in result.output
    assert "reference" in result.output


def test_strategy_help():
    result = runner.invoke(cli, ["strategy", "--help"])
    assert result.exit_code == 0
    assert "validate" in result.output
    assert "compile" in result.output
    assert "explain" in result.output
    assert "diff" in result.output
    assert "stage" in result.output
    assert "examples" in result.output
    assert "patterns" in result.output
    assert "lock-status" in result.output
    assert "lock-upgrade" in result.output
    assert "new" in result.output


def test_universe_help():
    result = runner.invoke(cli, ["universe", "--help"])
    assert result.exit_code == 0
    assert "get" in result.output
    assert "set" in result.output
    assert "add-group" in result.output
    assert "modify-group" in result.output
    assert "remove-group" in result.output


def test_auth_help():
    result = runner.invoke(cli, ["auth", "--help"])
    assert result.exit_code == 0
    assert "login" in result.output
    assert "logout" in result.output


# ── format option ────────────────────────────────────────────────────────────


def test_format_json_sets_format():
    result = runner.invoke(cli, ["--format", "json", "components", "list"])
    assert result.exit_code == 0
    # Should be valid JSON output
    json.loads(result.output)


def test_format_table_sets_format():
    result = runner.invoke(cli, ["--format", "table", "components", "list"])
    assert result.exit_code == 0
    assert "NAME" in result.output


def test_format_tsv_sets_format():
    result = runner.invoke(cli, ["--format", "tsv", "components", "list"])
    assert result.exit_code == 0
    assert "\t" in result.output


def test_format_human_sets_format():
    result = runner.invoke(cli, ["--format", "human", "components", "list"])
    assert result.exit_code == 0
    # Human for lists falls back to table
    assert "NAME" in result.output


def test_invalid_format_rejected():
    result = runner.invoke(cli, ["--format", "xml", "components", "list"])
    assert result.exit_code != 0


# ── agent mode auto-detection ────────────────────────────────────────────────


def test_agent_mode_defaults_to_json():
    """When CLAUDE_CODE is set, default format should be json."""
    result = runner.invoke(
        cli, ["components", "list"],
        env={"CLAUDE_CODE": "1"},
    )
    assert result.exit_code == 0
    # Should produce JSON output since agent mode defaults to json
    json.loads(result.output)


def test_no_agent_mode_defaults_to_human():
    """When not in agent mode and at a TTY, default should be human."""
    # CliRunner doesn't use a real TTY so agent_mode returns True (not a TTY).
    # We mock is_agent_mode to simulate the non-agent path.
    with patch("keel.cli.main.default_format", return_value="human"):
        result = runner.invoke(cli, ["components", "list"])
        assert result.exit_code == 0
        # Human format for lists shows table headers
        assert "NAME" in result.output


# ── format override beats agent mode ─────────────────────────────────────────


def test_explicit_format_overrides_agent():
    """Explicit --format should override agent mode default."""
    result = runner.invoke(
        cli, ["--format", "table", "components", "list"],
        env={"CLAUDE_CODE": "1"},
    )
    assert result.exit_code == 0
    assert "NAME" in result.output


# ── invalid subcommand ───────────────────────────────────────────────────────


def test_unknown_subcommand():
    result = runner.invoke(cli, ["nonexistent"])
    assert result.exit_code != 0


def test_unknown_sub_subcommand():
    result = runner.invoke(cli, ["components", "nonexistent"])
    assert result.exit_code != 0
