"""Tests for workspace CLI commands — checkout, push, pull, status."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from keel.cli.main import cli
from keel.workspace import META_FILE, STRATEGY_FILE, WorkspaceMeta, _compute_hash

runner = CliRunner()

VALID_STRATEGY = '''Globals(target_timeframe="1d")
Universe(mode="top_volume", top_n=30, market="perp")
Execution(rebalance="every_bar")
Pipeline([
    PriceDataLoader(timeframe="15min"),
    TargetTimeframeResampler(),
    ROC(period=8),
    ForecastScaler(avg_abs_target=10.0),
    ForecastWeightNormalizer(),
])'''


def _create_workspace(root: Path, strategy_id: str, source: str, name: str = "test") -> Path:
    ws_dir = root / strategy_id
    ws_dir.mkdir(parents=True)
    (ws_dir / STRATEGY_FILE).write_text(source)
    meta = WorkspaceMeta(
        strategy_id=strategy_id,
        name=name,
        source_hash=_compute_hash(source),
        checked_out_at="2026-04-02T00:00:00Z",
    )
    meta.save(ws_dir)
    return ws_dir


# ── workspaces command ───────────────────────────────────────────────────


def test_workspaces_empty():
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(cli, ["--format", "json", "strategy", "workspaces"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["count"] == 0


def test_workspaces_lists_checkouts():
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        _create_workspace(ws_root, "strat_1", VALID_STRATEGY, "My Strategy")
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(cli, ["--format", "json", "strategy", "workspaces"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["count"] == 1
            assert data["workspaces"][0]["strategy_id"] == "strat_1"
            assert data["workspaces"][0]["name"] == "My Strategy"


# ── status command ───────────────────────────────────────────────────────


def test_status_unmodified():
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        _create_workspace(ws_root, "strat_1", VALID_STRATEGY)
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(
                cli, ["--format", "json", "strategy", "status", "--strategy", "strat_1"]
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["local_modified"] is False


def test_status_modified():
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        ws_dir = _create_workspace(ws_root, "strat_1", VALID_STRATEGY)
        (ws_dir / STRATEGY_FILE).write_text(VALID_STRATEGY.replace("period=8", "period=16"))
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(
                cli, ["--format", "json", "strategy", "status", "--strategy", "strat_1"]
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["local_modified"] is True


def test_status_auto_detect():
    """Status auto-detects single workspace."""
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        _create_workspace(ws_root, "strat_1", VALID_STRATEGY)
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(cli, ["--format", "json", "strategy", "status"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["strategy_id"] == "strat_1"


# ── discard command ──────────────────────────────────────────────────────


def test_discard():
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        _create_workspace(ws_root, "strat_1", VALID_STRATEGY)
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(
                cli, ["--format", "json", "strategy", "discard", "--strategy", "strat_1"]
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["status"] == "discarded"
            assert not (ws_root / "strat_1").exists()


# ── validate with workspace auto-detect ──────────────────────────────────


def test_validate_auto_detects_workspace():
    """validate without file arg uses workspace strategy."""
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        _create_workspace(ws_root, "strat_1", VALID_STRATEGY)
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(cli, ["--format", "json", "strategy", "validate"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["valid"] is True


def test_validate_still_works_with_file():
    """validate with explicit file still works."""
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(VALID_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["valid"] is True


# ── universe set writes back to workspace ────────────────────────────────


def test_universe_set_writes_back_to_workspace():
    """Universe set should update the workspace file in place."""
    with runner.isolated_filesystem() as td:
        ws_root = Path(td) / "workspace"
        ws_dir = _create_workspace(ws_root, "strat_1", VALID_STRATEGY)
        with patch("keel.workspace.WORKSPACE_ROOT", ws_root):
            result = runner.invoke(
                cli,
                [
                    "--format", "json", "universe", "set",
                    str(ws_dir / STRATEGY_FILE),
                    "--mode", "manual", "--symbols", "BTC", "--symbols", "ETH",
                ],
            )
            assert result.exit_code == 0

            # Verify the workspace file was updated
            updated = (ws_dir / STRATEGY_FILE).read_text()
            assert "manual" in updated
            assert "BTC" in updated
