"""Tests for keel components CLI commands."""

import json

from click.testing import CliRunner

from keel.cli.main import cli

runner = CliRunner()


# ── search ───────────────────────────────────────────────────────────────────


def test_search_keyword():
    result = runner.invoke(cli, ["--format", "json", "components", "search", "--keyword", "ROC"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert isinstance(data, list)
    assert len(data) > 0


def test_search_keyword_returns_matching_components():
    result = runner.invoke(cli, ["--format", "json", "components", "search", "--keyword", "Price"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    names = [c["name"] for c in data]
    assert any("Price" in n for n in names)


def test_search_keyword_case_insensitive():
    """Keyword search should be case-insensitive (matches description/name substring)."""
    result = runner.invoke(cli, ["--format", "json", "components", "search", "--keyword", "forecast"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) > 0


def test_search_query_positional():
    result = runner.invoke(cli, ["--format", "json", "components", "search", "momentum"])
    # May return empty list if sentence-transformers not installed, but should not error
    assert result.exit_code == 0


def test_search_with_category_filter():
    result = runner.invoke(
        cli, ["--format", "json", "components", "search", "--category", "indicator"]
    )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert all(c["category"] == "indicator" for c in data)


def test_search_with_top_k():
    result = runner.invoke(
        cli, ["--format", "json", "components", "search", "--keyword", "a", "--top-k", "3"]
    )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) <= 3


def test_search_no_results():
    result = runner.invoke(
        cli, ["--format", "json", "components", "search", "--keyword", "ZZZZNONEXISTENT999"]
    )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) == 0


def test_search_table_format():
    result = runner.invoke(cli, ["--format", "table", "components", "search", "--keyword", "ROC"])
    assert result.exit_code == 0
    assert "NAME" in result.output


def test_search_tsv_format():
    result = runner.invoke(cli, ["--format", "tsv", "components", "search", "--keyword", "ROC"])
    assert result.exit_code == 0
    assert "name\t" in result.output


# ── detail ───────────────────────────────────────────────────────────────────


def test_detail_known():
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "ROC"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["name"] == "ROC"
    assert "parameters" in data
    assert "category" in data


def test_detail_known_has_types():
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "ROC"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "input_type" in data
    assert "output_type" in data


def test_detail_known_has_description():
    """Component detail includes description (example_usage requires introspection, not in SDK)."""
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "ROC"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "description" in data
    assert len(data["description"]) > 0


def test_detail_unknown():
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "NONEXISTENT_XYZ"])
    assert result.exit_code == 3


def test_detail_unknown_emits_error():
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "NONEXISTENT_XYZ"])
    # Error should be on stderr
    assert result.exit_code == 3


def test_detail_pricedata_loader():
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "PriceDataLoader"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["name"] == "PriceDataLoader"
    assert data["category"] == "data_loader"


def test_detail_forecast_scaler():
    result = runner.invoke(cli, ["--format", "json", "components", "detail", "ForecastScaler"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["name"] == "ForecastScaler"


# ── after ────────────────────────────────────────────────────────────────────


def test_after():
    result = runner.invoke(cli, ["--format", "json", "components", "after", "PriceDataLoader"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert isinstance(data, list)
    assert len(data) > 0


def test_after_returns_valid_components():
    result = runner.invoke(cli, ["--format", "json", "components", "after", "PriceDataLoader"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    # Each should have a name
    for comp in data:
        assert "name" in comp


def test_after_unknown_exits_3():
    result = runner.invoke(cli, ["--format", "json", "components", "after", "NONEXISTENT_XYZ"])
    assert result.exit_code == 3


# ── before ───────────────────────────────────────────────────────────────────


def test_before():
    result = runner.invoke(cli, ["--format", "json", "components", "before", "ForecastScaler"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert isinstance(data, list)


def test_before_has_results():
    result = runner.invoke(cli, ["--format", "json", "components", "before", "ForecastScaler"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) > 0


def test_before_unknown_exits_3():
    result = runner.invoke(cli, ["--format", "json", "components", "before", "NONEXISTENT_XYZ"])
    assert result.exit_code == 3


# ── list ─────────────────────────────────────────────────────────────────────


def test_list_all():
    result = runner.invoke(cli, ["--format", "json", "components", "list"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) > 10


def test_list_returns_all_components():
    result = runner.invoke(cli, ["--format", "json", "components", "list"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    names = [c["name"] for c in data]
    assert "ROC" in names
    assert "PriceDataLoader" in names
    assert "ForecastScaler" in names


def test_list_category_filter():
    result = runner.invoke(cli, ["--format", "json", "components", "list", "--category", "indicator"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert all(c["category"] == "indicator" for c in data)
    assert len(data) > 0


def test_list_category_filter_data_loader():
    result = runner.invoke(
        cli, ["--format", "json", "components", "list", "--category", "data_loader"]
    )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert all(c["category"] == "data_loader" for c in data)


def test_list_category_filter_case_insensitive():
    result = runner.invoke(
        cli, ["--format", "json", "components", "list", "--category", "Indicator"]
    )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert all(c["category"] == "indicator" for c in data)


def test_list_category_no_match():
    result = runner.invoke(
        cli, ["--format", "json", "components", "list", "--category", "nonexistent_category"]
    )
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data) == 0


def test_list_has_name_and_category():
    result = runner.invoke(cli, ["--format", "json", "components", "list"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    for comp in data[:5]:
        assert "name" in comp
        assert "category" in comp


# ── reference ────────────────────────────────────────────────────────────────


def test_reference_toc():
    result = runner.invoke(cli, ["--format", "json", "components", "reference"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "topics" in data


def test_reference_toc_has_topics_list():
    result = runner.invoke(cli, ["--format", "json", "components", "reference"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert isinstance(data["topics"], list)
    assert len(data["topics"]) > 0


def test_reference_topic():
    result = runner.invoke(cli, ["--format", "json", "components", "reference", "phases"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "content" in data
    assert data["topic"] == "phases"


def test_reference_topic_has_content():
    result = runner.invoke(cli, ["--format", "json", "components", "reference", "phases"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert len(data["content"]) > 10
