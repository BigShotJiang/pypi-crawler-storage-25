"""Tests for keel strategy CLI commands."""

import json

import pytest
from click.testing import CliRunner

from keel.cli.main import cli

runner = CliRunner()

BASIC_STRATEGY = '''Globals(target_timeframe="1d")

Universe(mode="top_volume", top_n=30, market="perp", resolved=["BTC", "ETH"], resolved_at="2026-01-01")

Pipeline([
    PriceDataLoader(timeframe="15min"),
    TargetTimeframeResampler(),
    ROC(period=8),
    ForecastScaler(avg_abs_target=10.0),
    ForecastCapper(limit=20.0),
    ForecastWeightNormalizer(target_leverage=1.0),
], name="test")'''

CHANGED_STRATEGY = BASIC_STRATEGY.replace("period=8", "period=16")

INVALID_STRATEGY = "this is not valid strategy source"

INCOMPLETE_STRATEGY = '''Globals(target_timeframe="1d")

Universe(mode="top_volume", top_n=30, market="perp", resolved=["BTC", "ETH"], resolved_at="2026-01-01")

Pipeline([
    PriceDataLoader(timeframe="15min"),
    TargetTimeframeResampler(),
    ROC(period=8),
], name="partial")'''


# ── new ──────────────────────────────────────────────────────────────────────


def test_new():
    with runner.isolated_filesystem() as td:
        result = runner.invoke(cli, ["--format", "json", "strategy", "new", "test_new_strat", "--dir", td])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "created"


def test_new_has_path():
    with runner.isolated_filesystem() as td:
        result = runner.invoke(cli, ["--format", "json", "strategy", "new", "path_strat", "--dir", td])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "path" in data


def test_new_has_template_and_name():
    with runner.isolated_filesystem() as td:
        result = runner.invoke(cli, ["--format", "json", "strategy", "new", "content_strat", "--dir", td])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "template" in data
        assert "name" in data
        assert data["name"] == "content_strat"


def test_new_with_custom_dir():
    with runner.isolated_filesystem() as td:
        result = runner.invoke(
            cli, ["--format", "json", "strategy", "new", "dir_strat", "--dir", td]
        )
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["status"] == "created"
        assert td in data["path"]


def test_new_duplicate_fails():
    with runner.isolated_filesystem() as td:
        # Create once
        result1 = runner.invoke(
            cli, ["--format", "json", "strategy", "new", "dup_strat", "--dir", td]
        )
        assert result1.exit_code == 0
        # Create again
        result2 = runner.invoke(
            cli, ["--format", "json", "strategy", "new", "dup_strat", "--dir", td]
        )
        assert result2.exit_code == 0  # The command itself doesn't exit non-zero
        data = json.loads(result2.output)
        assert data["status"] == "exists"
        assert "already exists" in data.get("error", "")


# ── validate ─────────────────────────────────────────────────────────────────


def test_validate_valid():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["valid"] is True


def test_validate_valid_has_type_flow():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "type_flow" in data
        assert isinstance(data["type_flow"], list)


def test_validate_valid_has_component_lock():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "component_lock" in data


def test_validate_valid_has_globals():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "globals" in data
        assert data["globals"]["target_timeframe"] == "1d"


def test_validate_valid_has_universe():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "universe" in data
        assert data["universe"]["mode"] == "top_volume"


def test_validate_invalid():
    with runner.isolated_filesystem():
        with open("bad.py", "w") as f:
            f.write(INVALID_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "bad.py"])
        # Parse error may be returned as error or as valid=false
        assert result.exit_code != 0 or "false" in result.output.lower()


def test_validate_missing_file():
    result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "nonexistent.py"])
    assert result.exit_code != 0


def test_validate_no_issues_for_valid():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "validate", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["valid"] is True
        assert len(data["issues"]) == 0


# ── compile (remote — requires API key) ─────────────────────────────────────


@pytest.mark.skipif(True, reason="compile is a remote command requiring KEEL_API_KEY")
def test_compile():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "compile", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "fingerprint" in data


@pytest.mark.skipif(True, reason="compile is a remote command requiring KEEL_API_KEY")
def test_compile_has_strategy_name():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "compile", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "strategy_name" in data


@pytest.mark.skipif(True, reason="compile is a remote command requiring KEEL_API_KEY")
def test_compile_has_steps():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "compile", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "steps" in data
        assert len(data["steps"]) > 0


@pytest.mark.skipif(True, reason="compile is a remote command requiring KEEL_API_KEY")
def test_compile_has_component_lock():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "compile", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "component_lock" in data


@pytest.mark.skipif(True, reason="compile is a remote command requiring KEEL_API_KEY")
def test_compile_has_output_type():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "compile", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["output_type"] == "WeightSeries"


def test_compile_missing_file():
    result = runner.invoke(cli, ["--format", "json", "strategy", "compile", "nonexistent.py"])
    assert result.exit_code != 0


# ── explain ──────────────────────────────────────────────────────────────────


def test_explain():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "explain", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["valid"] is True
        assert len(data["steps"]) > 0


def test_explain_has_strategy_name():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "explain", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "strategy_name" in data


def test_explain_has_type_flow():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "explain", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "type_flow" in data


def test_explain_has_summary():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "explain", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "summary" in data


def test_explain_missing_file():
    result = runner.invoke(cli, ["--format", "json", "strategy", "explain", "nonexistent.py"])
    assert result.exit_code != 0


# ── diff ─────────────────────────────────────────────────────────────────────


def test_diff():
    with runner.isolated_filesystem():
        with open("a.py", "w") as f:
            f.write(BASIC_STRATEGY)
        with open("b.py", "w") as f:
            f.write(CHANGED_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "diff", "a.py", "b.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "changed" in data


def test_diff_detects_change():
    with runner.isolated_filesystem():
        with open("a.py", "w") as f:
            f.write(BASIC_STRATEGY)
        with open("b.py", "w") as f:
            f.write(CHANGED_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "diff", "a.py", "b.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data["changed"]) > 0


def test_diff_identical():
    with runner.isolated_filesystem():
        with open("a.py", "w") as f:
            f.write(BASIC_STRATEGY)
        with open("b.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "diff", "a.py", "b.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data.get("changed", [])) == 0
        assert len(data.get("added", [])) == 0
        assert len(data.get("removed", [])) == 0


def test_diff_has_summary():
    with runner.isolated_filesystem():
        with open("a.py", "w") as f:
            f.write(BASIC_STRATEGY)
        with open("b.py", "w") as f:
            f.write(CHANGED_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "diff", "a.py", "b.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "summary" in data


def test_diff_missing_file():
    with runner.isolated_filesystem():
        with open("a.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "diff", "a.py", "missing.py"])
        assert result.exit_code != 0


# ── stage ────────────────────────────────────────────────────────────────────


def test_stage():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "stage", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["backtest_ready"] is True


def test_stage_complete_strategy():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "stage", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["final_output_type"] == "WeightSeries"
        assert data["step_count"] > 0


def test_stage_incomplete_strategy():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(INCOMPLETE_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "stage", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["backtest_ready"] is False


def test_stage_has_stage_name():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(INCOMPLETE_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "stage", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "stage" in data
        assert data["stage"] == "signal"


def test_stage_has_type_flow():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "stage", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "type_flow" in data
        assert isinstance(data["type_flow"], list)
        assert len(data["type_flow"]) > 0


def test_stage_has_step_count():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "stage", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "step_count" in data
        assert data["step_count"] > 0


# ── examples ─────────────────────────────────────────────────────────────────


def test_examples():
    result = runner.invoke(cli, ["--format", "json", "strategy", "examples"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["count"] >= 1


def test_examples_has_list():
    result = runner.invoke(cli, ["--format", "json", "strategy", "examples"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "examples" in data
    assert isinstance(data["examples"], list)
    assert len(data["examples"]) > 0


def test_examples_query():
    result = runner.invoke(cli, ["--format", "json", "strategy", "examples", "--query", "momentum"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["showing"] > 0


def test_examples_each_has_name():
    result = runner.invoke(cli, ["--format", "json", "strategy", "examples"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    for ex in data["examples"]:
        assert "name" in ex
        assert "title" in ex


def test_examples_shows_capped():
    result = runner.invoke(cli, ["--format", "json", "strategy", "examples"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "showing" in data
    assert data["showing"] <= data["count"]


# ── patterns ─────────────────────────────────────────────────────────────────


def test_patterns():
    result = runner.invoke(cli, ["--format", "json", "strategy", "patterns", "momentum sizing"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "patterns" in data
    assert data["query"] == "momentum sizing"


def test_patterns_returns_results():
    result = runner.invoke(cli, ["--format", "json", "strategy", "patterns", "momentum"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["match_count"] >= 1


def test_patterns_each_has_name():
    result = runner.invoke(cli, ["--format", "json", "strategy", "patterns", "momentum"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    for p in data["patterns"]:
        assert "name" in p
        assert "title" in p


# ── lock-status ──────────────────────────────────────────────────────────────


def test_lock_status():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "lock-status", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "status" in data
        assert data["status"] in ("current", "drift")


def test_lock_status_has_drift_list():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "lock-status", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "drift" in data
        assert isinstance(data["drift"], list)


def test_lock_status_has_component_lock():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "lock-status", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "component_lock" in data
        assert len(data["component_lock"]) > 0


# ── lock-upgrade ─────────────────────────────────────────────────────────────


def test_lock_upgrade():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "lock-upgrade", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "component_lock" in data


def test_lock_upgrade_has_lock():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "lock-upgrade", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "component_lock" in data
        assert len(data["component_lock"]) > 0


def test_lock_upgrade_has_upgraded_flag():
    with runner.isolated_filesystem():
        with open("strat.py", "w") as f:
            f.write(BASIC_STRATEGY)
        result = runner.invoke(cli, ["--format", "json", "strategy", "lock-upgrade", "strat.py"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "upgraded" in data
