"""Tests for Phase 4 — skill content validation and AGENTS.md."""

from __future__ import annotations

from pathlib import Path

import pytest
import yaml

SKILLS_DIR = Path(__file__).parent.parent / "skills"
AGENTS_MD = Path(__file__).parent.parent / "AGENTS.md"

EXPECTED_SKILLS = [
    "strategy-creation",
    "strategy-backtest",
    "live-trading",
    "portfolio-analysis",
    "universe-selection",
    "component-discovery",
]


# ── SKILL.md files exist ──────────────────────────────────────────────────


class TestSkillFiles:
    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_file_exists(self, skill_name):
        skill_file = SKILLS_DIR / skill_name / "SKILL.md"
        assert skill_file.exists(), f"Missing {skill_file}"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_has_frontmatter(self, skill_name):
        content = (SKILLS_DIR / skill_name / "SKILL.md").read_text()
        assert content.startswith("---"), f"{skill_name} missing frontmatter"
        # Extract frontmatter
        parts = content.split("---", 2)
        assert len(parts) >= 3, f"{skill_name} malformed frontmatter"
        fm = yaml.safe_load(parts[1])
        assert "name" in fm, f"{skill_name} frontmatter missing 'name'"
        assert "description" in fm, f"{skill_name} frontmatter missing 'description'"
        assert "triggers" in fm, f"{skill_name} frontmatter missing 'triggers'"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_has_triggers(self, skill_name):
        content = (SKILLS_DIR / skill_name / "SKILL.md").read_text()
        parts = content.split("---", 2)
        fm = yaml.safe_load(parts[1])
        triggers = fm["triggers"]
        assert isinstance(triggers, list)
        assert len(triggers) >= 2, f"{skill_name} needs at least 2 triggers"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_has_workflow_section(self, skill_name):
        content = (SKILLS_DIR / skill_name / "SKILL.md").read_text()
        assert "## Workflow" in content or "## workflow" in content.lower(), \
            f"{skill_name} missing Workflow section"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_has_commands_section(self, skill_name):
        content = (SKILLS_DIR / skill_name / "SKILL.md").read_text()
        assert "## Commands" in content or "command" in content.lower(), \
            f"{skill_name} missing Commands section"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_under_200_lines(self, skill_name):
        content = (SKILLS_DIR / skill_name / "SKILL.md").read_text()
        lines = content.split("\n")
        assert len(lines) <= 200, f"{skill_name} is {len(lines)} lines (max 200)"

    @pytest.mark.parametrize("skill_name", EXPECTED_SKILLS)
    def test_skill_references_keel_commands(self, skill_name):
        content = (SKILLS_DIR / skill_name / "SKILL.md").read_text()
        assert "keel " in content, f"{skill_name} should reference keel CLI commands"


# ── AGENTS.md ─────────────────────────────────────────────────────────────


class TestAgentsMd:
    def test_agents_md_exists(self):
        assert AGENTS_MD.exists()

    def test_has_quick_start(self):
        content = AGENTS_MD.read_text()
        assert "Quick Start" in content

    def test_has_authentication(self):
        content = AGENTS_MD.read_text()
        assert "Authentication" in content or "KEEL_API_KEY" in content

    def test_has_available_tools(self):
        content = AGENTS_MD.read_text()
        assert "Available Tools" in content or "Local" in content

    def test_has_exit_codes(self):
        content = AGENTS_MD.read_text()
        assert "Exit Code" in content or "exit_code" in content

    def test_has_mcp_config(self):
        content = AGENTS_MD.read_text()
        assert "mcp" in content.lower()
