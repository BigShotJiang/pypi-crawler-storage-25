"""Tests for keel.client — API client with retries and error translation."""

import pytest
import httpx
import respx

from keel.client import KeelClient
from keel.config import KeelConfig
from keel.errors import AuthError, KeelError, NotFoundError


@pytest.fixture
def config():
    return KeelConfig(api_key="sk_test_123", api_url="https://api.test.io")


@pytest.fixture
def client(config):
    c = KeelClient(config=config)
    yield c
    c.close()


class TestAuth:
    def test_requires_api_key(self):
        client = KeelClient(config=KeelConfig(api_key=None))
        with pytest.raises(AuthError, match="Not authenticated"):
            client.get("/v1/me")

    @respx.mock
    def test_sends_auth_header(self, client):
        route = respx.get("https://api.test.io/v1/me").mock(
            return_value=httpx.Response(200, json={"user": "test"})
        )
        client.get("/v1/me")
        assert route.calls.last.request.headers["authorization"] == "Bearer sk_test_123"


class TestHTTPMethods:
    @respx.mock
    def test_get(self, client):
        respx.get("https://api.test.io/v1/strategies").mock(
            return_value=httpx.Response(200, json={"strategies": []})
        )
        result = client.get("/v1/strategies")
        assert result == {"strategies": []}

    @respx.mock
    def test_get_with_params(self, client):
        route = respx.get("https://api.test.io/v1/strategies").mock(
            return_value=httpx.Response(200, json=[])
        )
        client.get("/v1/strategies", limit=10, search="test")
        req = route.calls.last.request
        assert "limit=10" in str(req.url)

    @respx.mock
    def test_post(self, client):
        respx.post("https://api.test.io/v1/backtests").mock(
            return_value=httpx.Response(200, json={"backtest_id": "bt_123"})
        )
        result = client.post("/v1/backtests", json={"strategy_id": "str_1"})
        assert result["backtest_id"] == "bt_123"

    @respx.mock
    def test_patch(self, client):
        respx.patch("https://api.test.io/v1/strategies/str_1").mock(
            return_value=httpx.Response(200, json={"updated": True})
        )
        result = client.patch("/v1/strategies/str_1", json={"source": "..."})
        assert result["updated"] is True

    @respx.mock
    def test_delete(self, client):
        respx.delete("https://api.test.io/v1/live/dep_1").mock(
            return_value=httpx.Response(200, json={"stopped": True})
        )
        result = client.delete("/v1/live/dep_1")
        assert result["stopped"] is True


class TestErrorTranslation:
    @respx.mock
    def test_404_raises_not_found(self, client):
        respx.get("https://api.test.io/v1/strategies/bad").mock(
            return_value=httpx.Response(404, text="Not found")
        )
        with pytest.raises(NotFoundError):
            client.get("/v1/strategies/bad")

    @respx.mock
    def test_401_raises_auth_error(self, client):
        respx.get("https://api.test.io/v1/me").mock(
            return_value=httpx.Response(401, text="Unauthorized")
        )
        with pytest.raises(AuthError):
            client.get("/v1/me")


class TestContextManager:
    @respx.mock
    def test_context_manager(self, config):
        respx.get("https://api.test.io/v1/me").mock(
            return_value=httpx.Response(200, json={"user": "test"})
        )
        with KeelClient(config=config) as client:
            result = client.get("/v1/me")
            assert result["user"] == "test"
