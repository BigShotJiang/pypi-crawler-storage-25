"""Tests for the workspace module — local checkout/push/pull/status."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from keel.workspace import (
    META_FILE,
    STRATEGY_FILE,
    WorkspaceMeta,
    _compute_hash,
    discard,
    find_workspace_strategy,
    get_workspace,
    get_workspace_dir,
    list_workspaces,
    read_local_source,
    write_local_source,
)


@pytest.fixture
def workspace_root(tmp_path):
    """Override WORKSPACE_ROOT for tests."""
    with patch("keel.workspace.WORKSPACE_ROOT", tmp_path):
        yield tmp_path


def _create_workspace(root: Path, strategy_id: str, source: str, name: str = "test") -> Path:
    """Helper to create a workspace directory with metadata."""
    ws_dir = root / strategy_id
    ws_dir.mkdir(parents=True)
    (ws_dir / STRATEGY_FILE).write_text(source)

    meta = WorkspaceMeta(
        strategy_id=strategy_id,
        name=name,
        source_hash=_compute_hash(source),
        checked_out_at="2026-04-02T00:00:00Z",
    )
    meta.save(ws_dir)
    return ws_dir


class TestWorkspaceMeta:
    def test_save_and_load(self, workspace_root):
        ws_dir = workspace_root / "test_strategy"
        ws_dir.mkdir()

        meta = WorkspaceMeta(
            strategy_id="test_strategy",
            name="My Strategy",
            source_hash="abc123",
            checked_out_at="2026-04-02T00:00:00Z",
            org_id="org_1",
        )
        meta.save(ws_dir)

        loaded = WorkspaceMeta.load(ws_dir)
        assert loaded.strategy_id == "test_strategy"
        assert loaded.name == "My Strategy"
        assert loaded.source_hash == "abc123"
        assert loaded.org_id == "org_1"


class TestListWorkspaces:
    def test_empty(self, workspace_root):
        assert list_workspaces() == []

    def test_one_workspace(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "Pipeline([])")
        result = list_workspaces()
        assert len(result) == 1
        assert result[0].strategy_id == "strat_1"

    def test_multiple_workspaces(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "Pipeline([])")
        _create_workspace(workspace_root, "strat_2", "Pipeline([ROC()])")
        result = list_workspaces()
        assert len(result) == 2


class TestGetWorkspace:
    def test_exists(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "Pipeline([])")
        meta = get_workspace("strat_1")
        assert meta is not None
        assert meta.strategy_id == "strat_1"

    def test_not_exists(self, workspace_root):
        assert get_workspace("nonexistent") is None


class TestFindWorkspace:
    def test_single_checkout(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "Pipeline([])")
        ws = find_workspace_strategy()
        assert ws is not None
        assert ws.strategy_id == "strat_1"

    def test_no_checkouts(self, workspace_root):
        assert find_workspace_strategy() is None

    def test_multiple_checkouts_returns_none(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "Pipeline([])")
        _create_workspace(workspace_root, "strat_2", "Pipeline([])")
        assert find_workspace_strategy() is None


class TestReadWriteSource:
    def test_read_source(self, workspace_root):
        source = "Pipeline([ROC(period=8)])"
        _create_workspace(workspace_root, "strat_1", source)
        assert read_local_source("strat_1") == source

    def test_write_source(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "old")
        write_local_source("strat_1", "new")
        assert read_local_source("strat_1") == "new"

    def test_read_nonexistent(self, workspace_root):
        with pytest.raises(FileNotFoundError):
            read_local_source("nonexistent")


class TestComputeHash:
    def test_deterministic(self):
        assert _compute_hash("hello") == _compute_hash("hello")

    def test_different_source(self):
        assert _compute_hash("a") != _compute_hash("b")


class TestStatus:
    def test_current(self, workspace_root):
        source = "Pipeline([])"
        _create_workspace(workspace_root, "strat_1", source)
        from keel.workspace import status

        # No API key → remote check skipped, shows local state only
        result = status("strat_1")
        assert result["strategy_id"] == "strat_1"
        assert result["local_modified"] is False

    def test_local_modified(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "old_source")
        write_local_source("strat_1", "new_source")
        from keel.workspace import status

        result = status("strat_1")
        assert result["local_modified"] is True


class TestDiscard:
    def test_discard(self, workspace_root):
        _create_workspace(workspace_root, "strat_1", "Pipeline([])")
        result = discard("strat_1")
        assert result["status"] == "discarded"
        assert not (workspace_root / "strat_1").exists()

    def test_discard_nonexistent(self, workspace_root):
        with pytest.raises(ValueError):
            discard("nonexistent")
