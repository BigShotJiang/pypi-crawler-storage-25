"""Tests for keel.errors."""

import pytest

from keel.errors import (
    AuthError,
    ConflictError,
    EntitlementError,
    KeelError,
    NotFoundError,
    UsageError,
    ValidationError,
    translate_http_error,
)


# ── KeelError.to_dict() ─────────────────────────────────────────────────────


def test_keel_error_to_dict():
    e = KeelError("test message", suggestion="try this", docs_url="https://docs.example.com")
    d = e.to_dict()
    assert d["error"] == "error"
    assert d["message"] == "test message"
    assert d["exit_code"] == 1
    assert d["suggestion"] == "try this"
    assert d["docs_url"] == "https://docs.example.com"


def test_to_dict_without_optional_fields():
    e = KeelError("plain")
    d = e.to_dict()
    assert "suggestion" not in d
    assert "docs_url" not in d
    assert d["error"] == "error"
    assert d["message"] == "plain"
    assert d["exit_code"] == 1


def test_to_dict_with_only_suggestion():
    e = KeelError("msg", suggestion="hint")
    d = e.to_dict()
    assert d["suggestion"] == "hint"
    assert "docs_url" not in d


def test_to_dict_with_only_docs_url():
    e = KeelError("msg", docs_url="https://docs.example.com/foo")
    d = e.to_dict()
    assert "suggestion" not in d
    assert d["docs_url"] == "https://docs.example.com/foo"


def test_keel_error_is_exception():
    e = KeelError("test")
    assert isinstance(e, Exception)
    assert str(e) == "test"


def test_keel_error_custom_error_code():
    e = KeelError("msg", error_code="custom_code")
    assert e.error_code == "custom_code"
    assert e.to_dict()["error"] == "custom_code"


def test_keel_error_custom_exit_code():
    e = KeelError("msg", exit_code=99)
    assert e.exit_code == 99
    assert e.to_dict()["exit_code"] == 99


def test_keel_error_custom_both_codes():
    e = KeelError("msg", error_code="custom", exit_code=42)
    d = e.to_dict()
    assert d["error"] == "custom"
    assert d["exit_code"] == 42


# ── Subclass exit codes and error codes ──────────────────────────────────────


def test_subclass_exit_codes():
    assert NotFoundError("x").exit_code == 3
    assert AuthError("x").exit_code == 4
    assert ConflictError("x").exit_code == 5
    assert EntitlementError("x").exit_code == 6
    assert ValidationError("x").exit_code == 7
    assert UsageError("x").exit_code == 2


def test_subclass_error_codes():
    assert NotFoundError("x").error_code == "not_found"
    assert AuthError("x").error_code == "auth_failed"
    assert ConflictError("x").error_code == "conflict"
    assert EntitlementError("x").error_code == "insufficient_entitlements"
    assert ValidationError("x").error_code == "validation_failed"
    assert UsageError("x").error_code == "usage_error"


def test_subclass_to_dict_includes_subclass_fields():
    e = NotFoundError("widget not found", suggestion="Check the name")
    d = e.to_dict()
    assert d["error"] == "not_found"
    assert d["exit_code"] == 3
    assert d["message"] == "widget not found"
    assert d["suggestion"] == "Check the name"


def test_subclass_inherits_exception():
    for cls in (NotFoundError, AuthError, ConflictError, EntitlementError, ValidationError, UsageError):
        e = cls("test")
        assert isinstance(e, KeelError)
        assert isinstance(e, Exception)


def test_subclass_str():
    e = ValidationError("bad input")
    assert str(e) == "bad input"


# ── translate_http_error() ───────────────────────────────────────────────────


def test_translate_http_401():
    e = translate_http_error(401, "Unauthorized")
    assert isinstance(e, AuthError)
    assert e.exit_code == 4
    assert "keel auth login" in e.suggestion
    assert e.docs_url == "https://app.usekeel.io/settings?tab=api-keys"


def test_translate_http_403():
    e = translate_http_error(403, "Forbidden")
    assert isinstance(e, EntitlementError)
    assert e.exit_code == 6
    assert e.suggestion == "Check 'keel auth status'"


def test_translate_http_404():
    e = translate_http_error(404, "Not found")
    assert isinstance(e, NotFoundError)
    assert e.exit_code == 3
    assert "Not found" in str(e)


def test_translate_http_404_empty_body():
    e = translate_http_error(404, "")
    assert isinstance(e, NotFoundError)
    assert "Resource not found" in str(e)


def test_translate_http_409():
    e = translate_http_error(409, "Conflict")
    assert isinstance(e, ConflictError)
    assert e.exit_code == 5


def test_translate_http_409_empty_body():
    e = translate_http_error(409, "")
    assert isinstance(e, ConflictError)
    assert e.suggestion is not None  # Should suggest pull


def test_translate_http_422():
    e = translate_http_error(422, "Invalid field")
    assert isinstance(e, ValidationError)
    assert e.exit_code == 7
    assert "Invalid field" in str(e)


def test_translate_http_422_empty_body():
    e = translate_http_error(422, "")
    assert isinstance(e, ValidationError)
    assert "Validation failed" in str(e)


def test_translate_http_500():
    e = translate_http_error(500, "Server error")
    assert isinstance(e, KeelError)
    assert e.exit_code == 1
    assert e.retryable is True


def test_translate_http_502():
    e = translate_http_error(502, "Bad gateway")
    assert isinstance(e, KeelError)
    assert e.retryable is True


def test_translate_http_429():
    e = translate_http_error(429, "Rate limited")
    assert isinstance(e, KeelError)
    assert e.retryable is True
    assert e.suggestion is not None


# ── Edge cases ───────────────────────────────────────────────────────────────


def test_empty_message():
    e = KeelError("")
    assert str(e) == ""
    d = e.to_dict()
    assert d["message"] == ""


def test_raise_and_catch_keel_error():
    with pytest.raises(KeelError) as exc_info:
        raise KeelError("boom")
    assert str(exc_info.value) == "boom"


def test_raise_and_catch_subclass_as_keel_error():
    with pytest.raises(KeelError):
        raise NotFoundError("missing")


def test_raise_and_catch_subclass_directly():
    with pytest.raises(NotFoundError):
        raise NotFoundError("missing")
