---
name: strategy-creation
description: Guide agents through creating trading strategies from thesis to validated pipeline
triggers:
  - "create strategy"
  - "new strategy"
  - "build a strategy"
  - "make a strategy"
  - "design a strategy"
---

# Strategy Creation

Guides the workflow from trading thesis to a validated, backtest-ready pipeline.

## When to Activate

- User wants to create a new trading strategy
- User describes a trading idea and wants it implemented
- User asks to build or design a strategy from scratch

## Workflow

### 1. Clarify Intent

Match complexity to the user's request specificity:

- **Vague** ("build me a strategy"): Ask ONE clarifying question, then build the simplest viable version. Iterate from there.
- **Moderate** ("momentum strategy with carry"): Build what was described. Fill in standard defaults. Explain key choices.
- **Detailed** ("EWMAC 2/8, 4/16, 8/32 with FDM and vol sizing"): Execute completely and exactly. Do not simplify or omit.

### 2. Search Components

```bash
keel components search "momentum"              # Semantic search
keel components search --category "Signal"      # By category
keel components after PriceDataLoader           # What can follow a component
keel components before ForecastWeightNormalizer  # What can precede a component
```

### 3. Choose a Path

Every strategy follows one of these paths from data to weights:

| Path | Flow | Best For |
|------|------|----------|
| **Continuous Forecast** | Data -> Indicator -> Normalize -> ForecastScaler -> Capper -> ForecastWeightNormalizer -> WeightSeries | Trend, momentum |
| **Discrete Entry/Exit** | Data -> Indicator -> ThresholdCross -> BinarySignal -> SelectionToSignalConverter -> Allocator -> WeightSeries | Mean-reversion, breakout |
| **Screen-Select** | Data -> Indicator -> TopNAssetSelector -> SelectionToSignalConverter -> EqualWeightAllocator -> WeightSeries | Rotation |
| **Direct Allocation** | Data -> Indicator -> EqualWeightAllocator or RiskParityAllocator -> WeightSeries | Factor tilts |

### 4. Compose Pipeline

```bash
keel strategy new my_strategy --template momentum  # Start from template
keel strategy patterns "trend following"            # Get composition patterns
keel strategy examples --complexity simple          # Browse examples
keel components detail ForecastScaler               # Check parameters
```

Include what the user mentioned. Add required components they didn't mention (e.g., position sizing) and explain why.

### 5. Validate and Stage

```bash
keel strategy validate    # Type-check and structural validation (auto-detects workspace)
keel strategy stage       # Check backtest readiness
keel strategy explain     # Verify structure makes sense
```

If `stage` returns `backtest_ready: false`, fix what's missing before proceeding.

### 6. Save to Platform

```bash
# Option A: Create new strategy on platform (auto-checks out locally)
keel strategy create strategy.py

# Option B: If working on an existing strategy
keel strategy push -m "initial version"    # Push local changes to platform
```

After `create`, the strategy is automatically checked out to `~/.keel/workspace/<id>/` for continued editing. All subsequent `validate`, `stage`, `explain`, and `universe` commands auto-detect this workspace.

## Workspace Model

Agents use a checkout/push/pull model for working on strategies:

```bash
# Start from existing platform strategy
keel strategy checkout str_abc123     # Pull to local workspace

# Or create new (auto-checkouts)
keel strategy create strategy.py      # Creates on platform + local checkout

# Edit locally — validate/stage/explain auto-detect workspace
keel strategy validate                # No file arg needed
keel universe set --mode top_volume --top-n 30   # Edits workspace file in place

# Push changes to platform
keel strategy push -m "added universe"

# Check sync state
keel strategy status                  # Shows: current, ahead, behind, conflict

# If someone edited in the web editor:
keel strategy pull                    # Pull their changes
```

## Key Patterns

**Forecast-Combine**: Multiple signals normalized, scaled, combined with ForecastCombiner, then sized. Add EmpiricalFDM or AnalyticalFDM for diversification benefit.

**Screen-Select**: Filter universe by signal, equal-weight survivors. Needs TopNAssetSelector + SelectionToSignalConverter (hold_periods) + EqualWeightAllocator.

**Multi-Signal Hierarchy**: Parallel branches composed at multiple levels. Uses Parallel + Composers at each level.

**Regime-Conditioned**: Base strategy modulated by regime detection. Uses RegimeWeightedBlender, RegimeGate, or RegimeScale.

## Mistakes to Avoid

| Code | Mistake | Fix |
|------|---------|-----|
| M-01 | Equal weights on continuous forecasts | Use ForecastWeightNormalizer or VolatilityScaler, not EqualWeightAllocator |
| M-09 | Pipeline without WeightSeries output | Backtester requires WeightSeries. Check output type. |
| M-10 | Missing data pipeline | Every pipeline needs Globals, PriceDataLoader, TargetTimeframeResampler |
| M-11 | TopN without exit logic | Always follow TopNAssetSelector with SelectionToSignalConverter(hold_periods) |
| M-12 | Unconsumed Parallel | After Parallel dict output, add Composer, Extract, or Load |
| M-16 | Over-indexing on one pattern | Simple factor tilt may be exactly right. Don't force complexity. |

## Collaboration Rules

- Suggest ONE improvement at a time, not a 5-step plan
- Explain the "why" for choices: "Using CrossSectionalZScore because combining signals with different scales requires normalization"
- NEVER suggest backtesting until `keel strategy stage` confirms `backtest_ready: true`

## Commands Reference

| Command | Purpose | Needs API |
|---------|---------|-----------|
| `keel components search <query>` | Find components | No |
| `keel components detail <name>` | Component spec | No |
| `keel components after <name>` | Type-compatible successors | No |
| `keel components before <name>` | Type-compatible predecessors | No |
| `keel strategy new <name> [--template]` | Create from template | No |
| `keel strategy validate` | Validate pipeline | No |
| `keel strategy stage` | Check backtest readiness | No |
| `keel strategy explain` | Explain structure | No |
| `keel strategy patterns <query>` | Composition patterns | No |
| `keel strategy examples [--complexity]` | Browse examples | No |
| `keel strategy checkout <id>` | Pull strategy to workspace | Yes |
| `keel strategy push [-m "msg"]` | Push local to platform | Yes |
| `keel strategy pull` | Pull remote to local | Yes |
| `keel strategy status` | Check sync state | Yes |
| `keel strategy create <file>` | Create on platform + checkout | Yes |
| `keel components reference [topic]` | DSL reference docs | No |
