---
name: component-discovery
description: Guide agents through finding, exploring, and composing pipeline components
triggers:
  - "components"
  - "signals"
  - "indicators"
  - "what components"
  - "find component"
  - "search components"
  - "available signals"
---

# Component Discovery

Guides the workflow for finding pipeline components, understanding their interfaces, checking compatibility, and composing them into pipelines.

## When to Activate

- User asks what components are available
- User searches for a specific type of signal or indicator
- User wants to know what can follow or precede a component
- User needs help choosing between components

## Workflow

### 1. Search for Components

Multiple search strategies depending on what the user knows:

**Semantic search** (natural language):
```bash
keel components search "trend following indicator"
keel components search "risk management"
keel components search "combine multiple signals"
```

**Keyword filter** (exact match on name/description):
```bash
keel components search --keyword "EWMAC"
keel components search --keyword "volatility"
```

**Category filter**:
```bash
keel components search --category "Signal"
keel components search --category "Allocator"
keel components search --category "Normalizer"
```

**Type filter** (by input/output types):
```bash
keel components search --input-type "SignalSeries" --output-type "ForecastSeries"
keel components search --output-type "WeightSeries"
```

**List all**:
```bash
keel components list                    # Everything
keel components list --category Signal  # All signals
```

### 2. Explore Details

Once you find a component, get its full specification:

```bash
keel components detail ForecastScaler
```

This returns:
- Input/output types
- Parameters with defaults and valid ranges
- Description and usage notes
- Version info

### 3. Check Type Compatibility

The pipeline is type-checked. Components must connect through compatible types.

```bash
# What can come AFTER this component?
keel components after PriceDataLoader
# Returns components that accept PriceDataLoader's output type

# What can come BEFORE this component?
keel components before ForecastWeightNormalizer
# Returns components whose output matches ForecastWeightNormalizer's input
```

Use these to build valid chains: start from your data source and chain `after` queries, or start from your target output (WeightSeries) and chain `before` queries.

### 4. Reference Documentation

For deeper understanding of the DSL and composition rules:

```bash
keel components reference              # List available topics
keel components reference "type_system" # Specific topic
keel components reference "composition" # How to compose components
```

### 5. Composition Patterns

When you know your goal but not the exact components:

```bash
keel strategy patterns "momentum with vol scaling"
keel strategy patterns "mean reversion"
keel strategy patterns "multi-signal combination"
keel strategy examples --complexity simple
keel strategy examples --query "carry"
```

## Component Categories

| Category | Purpose | Examples |
|----------|---------|----------|
| Data | Load and transform market data | PriceDataLoader, TargetTimeframeResampler |
| Signal | Generate trading signals from data | EWMAC, CarrySignal, MeanReversion |
| Normalizer | Scale signals for combination | CrossSectionalZScore, ForecastScaler |
| Combiner | Merge multiple signals | ForecastCombiner, Parallel |
| Selector | Filter or rank assets | TopNAssetSelector, VolumeUniverseReducer |
| Allocator | Convert signals to portfolio weights | ForecastWeightNormalizer, EqualWeightAllocator |
| Risk | Position sizing and risk management | VolatilityScaler, ForecastCapper |
| Regime | Market regime detection | RegimeWeightedBlender, RegimeGate |
| Utility | Pipeline control flow | Globals, StoreValue, SlotStore, SlotLoad |

## Type Flow Basics

Components connect through typed interfaces. The main types in order of pipeline progression:

```
OHLCV -> SignalSeries -> ForecastSeries -> WeightSeries
```

Some components transform within a type (e.g., CrossSectionalZScore: SignalSeries -> SignalSeries). Others transition between types (e.g., ForecastScaler: SignalSeries -> ForecastSeries).

The backtester requires the final output to be **WeightSeries**.

## Mistakes to Avoid

- **M-03**: Do not use CrossSectionalZScore on binary {-1,0,1} signals. Binary signals follow entry/exit path, not continuous forecast path.
- **M-18**: If any branch drops assets (VolumeUniverseReducer), ALL other Parallel branches must use AssetAligner to match shapes.

## Commands Reference

| Command | Purpose |
|---------|---------|
| `keel components search [query]` | Semantic or filtered search |
| `keel components detail <name>` | Full component specification |
| `keel components after <name>` | Type-compatible successors |
| `keel components before <name>` | Type-compatible predecessors |
| `keel components list [--category]` | List all components |
| `keel components reference [topic]` | DSL reference documentation |
| `keel strategy patterns <query>` | Composition pattern search |
| `keel strategy examples [--query] [--complexity]` | Browse example strategies |
