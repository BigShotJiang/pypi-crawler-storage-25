---
name: portfolio-analysis
description: Guide agents through analyzing portfolio performance across live deployments
triggers:
  - "portfolio"
  - "P&L"
  - "positions"
  - "performance"
  - "how am I doing"
  - "portfolio summary"
---

# Portfolio Analysis

Guides the workflow for analyzing performance across live deployments, identifying risk, and making portfolio-level recommendations.

## When to Activate

- User asks about overall portfolio performance
- User wants to see P&L, positions, or equity data
- User asks about risk exposure or concentration
- User wants cross-deployment comparison

## Workflow

### 1. Portfolio Overview

Start with the aggregate view, then drill into specifics:

```bash
# Aggregate view across all deployments
keel live portfolio

# List all active deployments
keel live list
```

### 2. Per-Deployment Metrics

For each active deployment, gather key data:

```bash
# Performance stats (Sharpe, return, drawdown)
keel live stats dep_abc123

# Current positions and sizes
keel live positions dep_abc123

# Current weight allocations
keel live weights dep_abc123

# Equity curve
keel live equity dep_abc123

# Daily P&L
keel live pnl dep_abc123
```

### 3. Analyze

Synthesize the data across deployments:

**Performance comparison**: Compare Sharpe ratios, returns, and drawdowns across deployments. Identify best and worst performers.

**Concentration risk**: Check if multiple strategies hold large positions in the same assets. Aggregate positions across deployments to find net exposure.

**Correlation risk**: Strategies that perform similarly in backtests may be correlated. If multiple strategies are trending down simultaneously, portfolio diversification is lower than expected.

**Drawdown analysis**: Compare current drawdown to historical max drawdown from backtests. A deployment exceeding its backtest max drawdown is a warning sign.

### 4. Recommend

Based on analysis, provide actionable recommendations:

| Finding | Recommendation |
|---------|---------------|
| One deployment dominates P&L | Consider rebalancing capital allocation |
| Multiple strategies long same asset | Reduce overlap or add constraints |
| Deployment exceeding backtest drawdown | Pause and investigate (see live-trading skill) |
| Low portfolio Sharpe despite good individual Sharpes | Strategies may be correlated; add uncorrelated strategy types |
| Consistent positive P&L across all | Stable; consider scaling up with new strategies |

## Key Metrics Reference

### Strategy-Level Metrics

| Metric | Source | Interpretation |
|--------|--------|---------------|
| Sharpe Ratio | `keel live stats` | Risk-adjusted return; >1.5 is good |
| Max Drawdown | `keel live stats` | Worst peak-to-trough; compare to backtest |
| Daily P&L | `keel live pnl` | Revenue trajectory and consistency |
| Win Rate | `keel live stats` | Percentage of profitable periods |
| Current Positions | `keel live positions` | Active exposure by asset |
| Portfolio Weights | `keel live weights` | Target allocation vs actual |

### Portfolio-Level Checks

| Check | How | Why |
|-------|-----|-----|
| Net exposure per asset | Sum positions across all deployments | Detect hidden concentration |
| Strategy correlation | Compare daily P&L patterns | True diversification check |
| Capital utilization | Sum weights across deployments | Ensure not over/under-allocated |
| Deployment health | Status of each deployment | Catch paused or erroring strategies |

## Common Questions

**"How is my portfolio doing?"**
Run `keel live portfolio` for the aggregate summary, then `keel live stats` for each deployment.

**"Which strategy is performing best?"**
Compare Sharpe ratios and returns from `keel live stats` across deployments.

**"Am I too concentrated?"**
Check `keel live positions` for each deployment. Sum exposure by asset across all.

**"Should I stop any strategies?"**
Compare current drawdown to backtest max drawdown. If exceeding 1.5x, investigate. If exceeding 2x, consider stopping.

## Commands Reference

| Command | Purpose |
|---------|---------|
| `keel live portfolio` | Aggregate portfolio summary |
| `keel live list` | All active deployments |
| `keel live stats <dep_id>` | Per-deployment performance |
| `keel live positions <dep_id>` | Current positions |
| `keel live weights <dep_id>` | Portfolio weights |
| `keel live equity <dep_id>` | Equity curve |
| `keel live pnl <dep_id>` | Daily P&L |
| `keel live show <dep_id>` | Deployment details |
| `keel backtest results <bt_id>` | Historical backtest for comparison |
