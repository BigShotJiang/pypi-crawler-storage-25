---
name: universe-selection
description: Guide agents through configuring which instruments a strategy trades
triggers:
  - "universe"
  - "instruments"
  - "assets"
  - "which coins"
  - "what to trade"
  - "add symbol"
  - "remove symbol"
---

# Universe Selection

Guides the workflow for configuring which instruments a strategy trades, including mode selection, group management, and verification.

## When to Activate

- User wants to choose which assets/instruments a strategy trades
- User asks about adding or removing symbols
- User wants to organize instruments into groups
- User asks about universe modes or categories

## Universe Modes

Every strategy has a universe configuration that determines its tradeable instruments.

| Mode | Description | Use When |
|------|-------------|----------|
| `manual` | Explicit list of symbols | You know exactly which assets to trade |
| `category` | Filter by category tags | Trading a sector (e.g., "defi", "layer1") |
| `top_volume` | Top N by trading volume | Want the most liquid assets dynamically |

## Workflow

### 1. Check Current Universe

```bash
keel universe get strategy.py
```

### 2. Choose and Set Mode

**Manual mode** (explicit symbols):
```bash
keel universe set strategy.py --mode manual \
  --symbols BTC --symbols ETH --symbols SOL --symbols DOGE
```

**Category mode** (by sector):
```bash
# List available categories first
keel universe categories

# Set category-based universe
keel universe set strategy.py --mode category \
  --categories defi --categories layer1
```

**Top volume mode** (dynamic by liquidity):
```bash
keel universe set strategy.py --mode top_volume --top-n 30
```

### 3. Exclusions and Inclusions

All modes support overrides:

```bash
# Exclude specific symbols (e.g., volatile meme coins)
keel universe set strategy.py --mode top_volume --top-n 30 \
  --exclusions DOGE --exclusions SHIB

# Force-include specific symbols regardless of mode
keel universe set strategy.py --mode category --categories defi \
  --inclusions BTC --inclusions ETH
```

### 4. Verify Resolution

See exactly which symbols the universe resolves to:

```bash
keel universe resolve --mode top_volume --top-n 30
# Returns the concrete list of symbols
```

## Group Management

Groups organize instruments within a strategy for multi-group pipelines (e.g., different signals for different asset classes).

### Add a Group

```bash
keel universe add-group strategy.py majors \
  --symbols BTC --symbols ETH --symbols SOL
```

### Modify a Group

```bash
# Add symbols to existing group
keel universe modify-group strategy.py majors --add AVAX --add SUI

# Remove symbols from existing group
keel universe modify-group strategy.py majors --remove SOL
```

### Remove a Group

```bash
keel universe remove-group strategy.py altcoins
```

### Multi-Group Strategy Pattern

Groups are useful when different parts of a pipeline treat different assets differently:

1. Create groups reflecting your strategy's logic (e.g., "majors", "alts", "stables")
2. Pipeline branches can reference groups for asset-specific signal generation
3. Each group can have its own parameters while sharing the same pipeline structure

## Available Instruments

To see what instruments are available to trade:

```bash
keel universe instruments              # All perpetual instruments
keel universe instruments --market perp  # Explicitly specify market
keel universe categories                # Available category tags
```

## Common Patterns

**Start narrow, expand later**: Begin with 5-10 well-known assets. Validate the strategy works, then expand the universe.

**Use exclusions for risk**: Exclude assets with unusual mechanics (new listings, low liquidity, scheduled delistings).

**Top volume for breadth**: `top_volume` with `--top-n 30` gives a good balance of breadth and liquidity. Add exclusions for problematic assets.

**Category for thematic**: Use categories when the strategy thesis is sector-specific (e.g., "DeFi momentum" should use `--categories defi`).

## Commands Reference

| Command | Purpose | Auth |
|---------|---------|------|
| `keel universe get <file>` | Read current universe config | Local |
| `keel universe set <file> --mode ...` | Set universe criteria | Local |
| `keel universe add-group <file> <name>` | Add instrument group | Local |
| `keel universe modify-group <file> <name>` | Modify group membership | Local |
| `keel universe remove-group <file> <name>` | Remove a group | Local |
| `keel universe resolve --mode ...` | Resolve to concrete symbols | Remote |
| `keel universe categories` | List available categories | Remote |
| `keel universe instruments [--market]` | List available instruments | Remote |
