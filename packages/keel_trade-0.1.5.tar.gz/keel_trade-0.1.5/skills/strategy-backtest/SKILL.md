---
name: strategy-backtest
description: Guide agents through backtesting strategies and interpreting results
triggers:
  - "backtest"
  - "test strategy"
  - "run backtest"
  - "backtest results"
  - "how did it perform"
---

# Strategy Backtest

Guides the workflow from pre-backtest validation through submission, monitoring, result interpretation, and iteration.

## When to Activate

- User wants to backtest a strategy
- User asks about backtest results or performance
- User wants to iterate on strategy based on backtest output

## Workflow

### 1. Pre-Backtest Checklist

Before submitting a backtest, verify three things in order:

```bash
# If working on a checked-out strategy, no file args needed:
keel strategy validate       # Catches type errors, missing params, structural issues
keel strategy stage          # Confirms pipeline ends with WeightSeries
keel strategy explain        # Sanity check the pipeline flow

# Or with explicit file:
keel strategy validate strategy.py
```

**Do not submit a backtest if stage shows `backtest_ready: false`.** Fix the pipeline first. Common reasons:
- Pipeline ends at SignalSeries or ForecastSeries instead of WeightSeries (M-09)
- Missing data pipeline components (M-10)
- Unconsumed Parallel block output (M-12)

### 2. Ensure Strategy is on Platform

The strategy must exist on the platform before backtesting:

```bash
# If not yet on platform:
keel strategy create strategy.py    # Creates + auto-checkouts, returns strategy_id

# If already checked out with local changes:
keel strategy push -m "ready for backtest"   # Pushes changes to platform
```

### 3. Submit Backtest

```bash
keel backtest run str_abc123 --start-date 2024-01-01 --end-date 2025-01-01
# Returns backtest_id (e.g., bt_xyz789)
```

### 4. Monitor Progress

```bash
keel backtest status bt_xyz789
# States: queued -> running -> completed | failed
```

Poll status periodically. When status is `completed`, fetch results.

### 5. Get Results

```bash
keel backtest results bt_xyz789     # Detailed performance metrics
keel backtest list --strategy-id str_abc123  # Compare across runs
```

## Interpreting Results

### Key Metrics

| Metric | Good | Concerning | What It Means |
|--------|------|------------|---------------|
| **Sharpe Ratio** | > 1.5 | < 0.5 | Risk-adjusted return. Higher = better return per unit risk. |
| **Max Drawdown** | < 20% | > 40% | Largest peak-to-trough decline. Affects real-world tolerance. |
| **Annual Return** | > 30% | < 10% | Total annualized return. Context-dependent on strategy type. |
| **Win Rate** | > 50% | < 35% | Percentage of profitable periods. Low is fine if winners are large. |
| **Calmar Ratio** | > 1.0 | < 0.3 | Return / max drawdown. Measures return per unit of worst pain. |

### Red Flags

- **Sharpe > 5**: Likely overfitting or look-ahead bias. Validate pipeline logic.
- **Flat equity curve with sudden jumps**: Strategy may only work in specific regimes.
- **Drawdown > 50%**: Unacceptable for live trading without risk management changes.
- **Very high turnover**: Excessive trading costs will erode live returns.

## Iteration Loop

The core iteration flow — edit locally, push, backtest, review, repeat:

```bash
# 1. Make changes to the checked-out strategy
#    (edit universe, swap components, tune parameters)
keel universe set --mode top_volume --top-n 20
# ... or edit the workspace file directly

# 2. Validate changes locally (fast, no network)
keel strategy validate
keel strategy stage

# 3. Push to platform (creates a version)
keel strategy push -m "reduced universe to top 20"

# 4. Run new backtest
keel backtest run str_abc123 --start-date 2024-01-01 --end-date 2025-01-01

# 5. Compare results
keel backtest list --strategy-id str_abc123
```

**Always change ONE thing at a time and re-backtest.** Do not make multiple changes simultaneously.

### What to Change Based on Results

| Problem | Action |
|---------|--------|
| Low Sharpe | Add diversification (more signals, ForecastCombiner with FDM) |
| High drawdown | Add vol scaling, reduce position sizes, add regime conditioning |
| Low return | Check if signals are too conservative, increase forecast scalar |
| High turnover | Increase hold_periods, add turnover penalty, smooth signals |
| Overfitting suspicion | Simplify: fewer signals, remove optimization, wider parameters |

## Handling Editor Collaboration

If the user edits the strategy in the web editor between backtests:

```bash
keel strategy status         # Check: "behind" means remote changed
keel strategy pull           # Pull their changes
keel strategy validate       # Validate the merged state
keel strategy push -m "..."  # Push and continue iterating
```

If both agent and editor changed the strategy:
```bash
keel strategy status         # Shows "conflict"
keel strategy pull --force   # Overwrite local with remote (their changes win)
# OR
keel strategy push --force   # Overwrite remote with local (agent's changes win)
```

## Commands Reference

| Command | Purpose | Needs API |
|---------|---------|-----------|
| `keel strategy validate` | Pre-backtest validation | No |
| `keel strategy stage` | Confirm backtest readiness | No |
| `keel strategy explain` | Verify pipeline structure | No |
| `keel strategy checkout <id>` | Pull strategy to workspace | Yes |
| `keel strategy push [-m "msg"]` | Push changes to platform | Yes |
| `keel strategy pull` | Pull remote changes | Yes |
| `keel strategy status` | Check sync state | Yes |
| `keel strategy create <file>` | Upload + auto-checkout | Yes |
| `keel backtest run <id> --start-date --end-date` | Submit backtest | Yes |
| `keel backtest status <bt_id>` | Check progress | Yes |
| `keel backtest results <bt_id>` | Get detailed results | Yes |
| `keel backtest list [--strategy-id]` | List/compare backtests | Yes |
| `keel strategy diff <a> <b>` | Compare strategy versions | No |
