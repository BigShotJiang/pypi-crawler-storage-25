---
name: live-trading
description: Guide agents through deploying, monitoring, and managing live trading strategies
triggers:
  - "deploy"
  - "go live"
  - "live trading"
  - "start trading"
  - "deploy strategy"
---

# Live Trading

Guides the workflow from pre-deployment verification through deployment, ongoing monitoring, and emergency actions.

## When to Activate

- User wants to deploy a strategy for live trading
- User asks about live deployment status or management
- User needs to pause, resume, or stop a live deployment
- User asks about emergency procedures for live strategies

## Workflow

### 1. Pre-Deploy Requirements

Before deploying, verify ALL of these:

```bash
# 1. Strategy must be validated and staged
keel strategy validate strategy.py
keel strategy stage strategy.py       # Must be backtest_ready: true

# 2. Strategy must exist on the platform
keel strategy show str_abc123

# 3. Strategy should have at least one successful backtest
keel backtest list --strategy-id str_abc123
# Look for status: completed with acceptable metrics

# 4. Check component versions are current
keel strategy lock-status strategy.py
# If drift detected:
keel strategy lock-upgrade strategy.py
```

**Do not deploy without a passing backtest.** Live trading uses real capital.

### 2. Preview Deployment

Always preview before committing:

```bash
keel live deploy str_abc123 --dry-run
# Shows what would happen without executing
```

### 3. Deploy

```bash
keel live deploy str_abc123 --confirm
# Returns deployment_id (e.g., dep_abc123)
```

In interactive mode (non-agent), the CLI prompts for confirmation. In agent mode, use `--confirm` to acknowledge.

### 4. Verify Deployment

```bash
keel live show dep_abc123      # Deployment details and status
keel live list                  # All active deployments
```

## Monitoring

### Regular Health Check

Run these commands periodically to assess deployment health:

```bash
# Core metrics
keel live stats dep_abc123       # Sharpe, return, drawdown, win rate
keel live equity dep_abc123      # Equity curve data
keel live pnl dep_abc123         # Daily P&L breakdown

# Current state
keel live positions dep_abc123   # Open positions and sizes
keel live weights dep_abc123     # Current portfolio weights

# Cross-deployment view
keel live portfolio              # Aggregate portfolio summary
```

### What to Monitor

| Metric | Check Frequency | Action Trigger |
|--------|----------------|----------------|
| Positions | Hourly | Unexpected concentration in one asset |
| Daily P&L | Daily | 3+ consecutive losing days |
| Drawdown | Daily | Exceeds 1.5x backtest max drawdown |
| Weights | Daily | Weights diverge significantly from expected |
| Stats | Weekly | Sharpe dropping below 0.5 |

## Emergency Actions

### Pause (Temporary Hold)

Stops new trades but keeps existing positions. Use when investigating issues.

```bash
keel live pause dep_abc123
# Verify:
keel live show dep_abc123     # Status should be "paused"
```

### Resume

Resumes trading after a pause:

```bash
keel live resume dep_abc123
```

### Stop (Full Shutdown)

Stops trading and closes all positions. Use for:
- Strategy significantly underperforming backtest
- Market conditions outside strategy's design parameters
- Critical bugs discovered in pipeline logic

```bash
keel live stop dep_abc123
# This is permanent — requires fresh deploy to restart
```

### When to Act

| Situation | Action |
|-----------|--------|
| Unexpected large position | **Pause** immediately, investigate weights |
| Drawdown > 2x backtest max | **Stop** the deployment |
| Single bad day within norms | Monitor, do not intervene |
| Strategy logic bug found | **Stop**, fix, re-backtest, redeploy |
| Market flash crash | **Pause**, wait for stability, then assess |
| Gradual performance decay | Monitor weekly, consider updating strategy |

## Commands Reference

| Command | Purpose |
|---------|---------|
| `keel live deploy <id> [--dry-run] [--confirm]` | Deploy strategy |
| `keel live list` | List active deployments |
| `keel live show <dep_id>` | Deployment details |
| `keel live pause <dep_id>` | Pause trading |
| `keel live resume <dep_id>` | Resume trading |
| `keel live stop <dep_id>` | Stop and close positions |
| `keel live positions <dep_id>` | Current positions |
| `keel live equity <dep_id>` | Equity curve |
| `keel live pnl <dep_id>` | Daily P&L |
| `keel live stats <dep_id>` | Performance statistics |
| `keel live weights <dep_id>` | Portfolio weights |
| `keel live portfolio` | Aggregate portfolio summary |
