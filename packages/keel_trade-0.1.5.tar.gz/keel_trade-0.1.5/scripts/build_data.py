#!/usr/bin/env python3
"""Pre-build script — generates static artifacts for the Keel SDK.

Run from the monorepo root with PYTHONPATH=libs:
    PYTHONPATH=libs python projects/agent-sdk/keel-sdk/scripts/build_data.py

Generates:
    keel/data/registry.json      — full component metadata
    keel/data/type_graph.json    — output→input type compatibility graph
    keel/data/tool_schemas.json  — MCP tool schemas
    keel/data/examples.json      — strategy examples
    keel/data/templates.json     — strategy templates
    keel/data/knowledge/         — system knowledge markdown files
    keel/data/patterns/          — composition pattern markdown files
    keel/data/reference/         — DSL reference markdown files

Also copies the DSL subset into the SDK package:
    pipeline_engine/dsl/         — parser, validator, emitter, differ, errors, templates, spec
    pipeline_engine/validation_shared.py
    pipeline_engine/base/registry.py
    pipeline_engine/base/step.py (subset)
    pipeline_engine/constants.py
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

# Resolve paths
SCRIPT_DIR = Path(__file__).parent
SDK_ROOT = SCRIPT_DIR.parent
KEEL_DATA_DIR = SDK_ROOT / "keel" / "data"
SDK_PE_DIR = SDK_ROOT / "pipeline_engine"

# Monorepo paths
MONO_ROOT = SDK_ROOT.parent.parent.parent  # projects/agent-sdk/keel-sdk -> Keel/
LIBS_DIR = MONO_ROOT / "libs"
PE_DIR = LIBS_DIR / "pipeline_engine"
REFERENCE_DIR = PE_DIR / "reference"
SYSTEM_DIR = REFERENCE_DIR / "system"
PATTERNS_DIR = REFERENCE_DIR / "patterns"


def ensure_imports():
    """Ensure monorepo libs are importable."""
    libs_str = str(LIBS_DIR)
    if libs_str not in sys.path:
        sys.path.insert(0, libs_str)


def build_registry_json() -> dict:
    """Build registry.json from live component registry."""
    from pipeline_engine.registry_loader import ensure_registry_loaded
    from pipeline_engine.base.registry import COMPONENT_REGISTRY, MISSING, get_all_versions, get_latest
    from pipeline_engine.validation_shared import (
        PHASE_INDEX,
        TYPE_TRANSITIONS,
        type_name,
    )

    ensure_registry_loaded()

    # Serialize type transitions
    type_transitions = {}
    for input_type, by_category in TYPE_TRANSITIONS.items():
        type_transitions[input_type] = {}
        for category, output_types in by_category.items():
            cat_name = category.value if hasattr(category, "value") else str(category)
            type_transitions[input_type][cat_name] = output_types

    # Serialize phase index
    phase_index = {}
    for category, idx in PHASE_INDEX.items():
        cat_name = category.value if hasattr(category, "value") else str(category)
        phase_index[cat_name] = idx

    # Serialize components
    components = []
    for name in sorted(COMPONENT_REGISTRY.keys()):
        sig = get_latest(name)
        if sig is None:
            continue

        params = []
        for pinfo in sig.parameters.values():
            constraints = pinfo.constraints or {}
            params.append({
                "name": pinfo.name,
                "type": (
                    pinfo.type_.__name__
                    if hasattr(pinfo.type_, "__name__")
                    else str(pinfo.type_)
                ),
                "default": pinfo.default if pinfo.default is not MISSING else None,
                "required": pinfo.required,
                "description": pinfo.description,
                "suggestions": pinfo.suggestions,
                "optimizable": pinfo.optimizable,
                "constraints": constraints,
                "min": constraints.get("min"),
                "max": constraints.get("max"),
                "options": constraints.get("options", pinfo.suggestions),
                "tier": pinfo.tier.value,
                "slot_reference": pinfo.slot_reference,
                "expected_slot_type": (
                    type_name(pinfo.expected_slot_type)
                    if pinfo.expected_slot_type
                    else None
                ),
            })

        implicit_reads = [k for k in sig.slot_reads if k not in sig.parameters]
        param_constraints = [
            {"params": c["params"], "rule": c.get("rule") or c.get("type", "")}
            for c in getattr(sig, "param_constraints", [])
        ]

        # Build per-version specs
        all_versions = get_all_versions(sig.name)
        versions_dict = {}
        changelog = {}
        for ver_num in sorted(all_versions.keys()):
            ver_sig = all_versions[ver_num]
            ver_params = []
            for vpinfo in ver_sig.parameters.values():
                vconstraints = vpinfo.constraints or {}
                ver_params.append({
                    "name": vpinfo.name,
                    "type": (
                        vpinfo.type_.__name__
                        if hasattr(vpinfo.type_, "__name__")
                        else str(vpinfo.type_)
                    ),
                    "default": vpinfo.default if vpinfo.default is not MISSING else None,
                    "required": vpinfo.required,
                    "description": vpinfo.description,
                    "tier": vpinfo.tier.value,
                    "slot_reference": vpinfo.slot_reference,
                })
            entry_text = ver_sig.changelog.get(ver_num, f"v{ver_num}")
            changelog[str(ver_num)] = entry_text
            versions_dict[str(ver_num)] = {
                "parameters": ver_params,
                "input_type": type_name(ver_sig.input_type),
                "output_type": type_name(ver_sig.output_type),
                "declaration_refs": ver_sig.declaration_refs or None,
                "optional_declaration_refs": ver_sig.optional_declaration_refs or None,
                "changelog_entry": entry_text,
            }

        components.append({
            "name": sig.name,
            "category": sig.category.value,
            "sub_category": sig.sub_category,
            "description": sig.description,
            "usage_hint": sig.usage_hint,
            "input_type": type_name(sig.input_type),
            "output_type": type_name(sig.output_type),
            "deterministic": sig.deterministic,
            "parameters": params,
            "implicit_slot_reads": implicit_reads,
            "param_constraints": param_constraints,
            "declaration_refs": sig.declaration_refs or None,
            "optional_declaration_refs": sig.optional_declaration_refs or None,
            "latest": sig.version,
            "version": sig.version,
            "status": sig.status,
            "changelog": changelog,
            "versions": versions_dict,
        })

    return {
        "type_transitions": type_transitions,
        "phase_index": phase_index,
        "components": components,
    }


def build_type_graph(registry_data: dict) -> dict:
    """Build type_graph.json for after/before queries."""
    output_to_names: dict[str, list[str]] = {}
    input_to_names: dict[str, list[str]] = {}

    for comp in registry_data["components"]:
        name = comp["name"]
        out_type = comp["output_type"]
        in_type = comp["input_type"]

        output_to_names.setdefault(out_type, []).append(name)
        input_to_names.setdefault(in_type, []).append(name)

    return {
        "output_type_to_names": output_to_names,
        "input_type_to_names": input_to_names,
    }


def build_tool_schemas() -> list[dict]:
    """Build tool_schemas.json from MCP schema definitions."""
    from pipeline_engine.mcp.schemas import get_tool_schemas

    return get_tool_schemas(format="mcp")


def build_examples() -> list[dict]:
    """Build examples.json from strategy_examples tool."""
    from pipeline_engine.registry_loader import ensure_registry_loaded
    from pipeline_engine.mcp.tools import strategy_examples

    ensure_registry_loaded()
    return strategy_examples()


def build_templates() -> dict:
    """Build templates.json from DSL template definitions."""
    from pipeline_engine.dsl.templates import TEMPLATES

    return {k: v for k, v in TEMPLATES.items()}


def copy_knowledge():
    """Copy system knowledge markdown files."""
    dest = KEEL_DATA_DIR / "knowledge"
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)

    for md_file in sorted(SYSTEM_DIR.glob("*.md")):
        shutil.copy2(md_file, dest / md_file.name)

    print(f"  Copied {len(list(dest.glob('*.md')))} knowledge files")


def copy_patterns():
    """Copy composition pattern markdown files."""
    dest = KEEL_DATA_DIR / "patterns"
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)

    for md_file in sorted(PATTERNS_DIR.glob("*.md")):
        shutil.copy2(md_file, dest / md_file.name)

    print(f"  Copied {len(list(dest.glob('*.md')))} pattern files")


def copy_reference():
    """Copy DSL reference markdown files."""
    dest = KEEL_DATA_DIR / "reference"
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)

    for md_file in sorted(REFERENCE_DIR.glob("*.md")):
        shutil.copy2(md_file, dest / md_file.name)

    print(f"  Copied {len(list(dest.glob('*.md')))} reference files")


def copy_dsl_subset():
    """Copy the DSL subset of pipeline_engine into the SDK package."""
    # Clean previous copy
    if SDK_PE_DIR.exists():
        shutil.rmtree(SDK_PE_DIR)

    # Create directory structure
    (SDK_PE_DIR / "dsl").mkdir(parents=True)
    (SDK_PE_DIR / "base").mkdir(parents=True)

    # Copy DSL files (excluding resolver.py, explainer.py, fixtures/)
    dsl_dir = PE_DIR / "dsl"
    dsl_include = [
        "__init__.py",
        "spec.py",
        "parser.py",
        "validator.py",
        "emitter.py",
        "differ.py",
        "errors.py",
        "templates.py",
    ]
    for fname in dsl_include:
        src = dsl_dir / fname
        if src.exists():
            shutil.copy2(src, SDK_PE_DIR / "dsl" / fname)

    # Copy base files — SDK-safe modules copied directly (no stripping needed)
    _write_base_init()
    shutil.copy2(PE_DIR / "base" / "categories.py", SDK_PE_DIR / "base" / "categories.py")
    shutil.copy2(PE_DIR / "base" / "registry_types.py", SDK_PE_DIR / "base" / "registry_types.py")

    # Write shims so existing imports (base.registry, base.step) keep working
    _write_registry_shim()
    _write_step_shim()

    # Copy top-level files
    shutil.copy2(PE_DIR / "constants.py", SDK_PE_DIR / "constants.py")
    shutil.copy2(PE_DIR / "validation_shared.py", SDK_PE_DIR / "validation_shared.py")

    # Create __init__.py for pipeline_engine package
    _write_pe_init()

    # Patch imports that reference excluded modules
    _patch_imports()

    print(f"  Copied DSL subset ({len(list(SDK_PE_DIR.rglob('*.py')))} Python files)")


def _write_registry_shim():
    """Write a thin registry.py that re-exports from registry_types.py."""
    content = '''\
"""Component registry — SDK shim re-exporting from registry_types.py."""

from pipeline_engine.base.registry_types import *  # noqa: F401,F403
from pipeline_engine.base.registry_types import (  # noqa: F811 — explicit re-exports
    _build_effective_registry,
    _resolve_param_type,
    _resolve_type_name,
)
'''
    (SDK_PE_DIR / "base" / "registry.py").write_text(content)


def _write_step_shim():
    """Write a thin step.py that re-exports from categories.py."""
    content = '''\
"""Step categories — SDK shim re-exporting from categories.py."""

from pipeline_engine.base.categories import *  # noqa: F401,F403
'''
    (SDK_PE_DIR / "base" / "step.py").write_text(content)


def _write_pe_init():
    """Write a minimal __init__.py for the SDK's pipeline_engine package."""
    content = '''\
"""Pipeline engine — DSL subset for the Keel SDK.

Contains only the language tooling (parser, validator, emitter, differ)
and registry infrastructure. No runtime execution, no component implementations.
"""

from pipeline_engine.dsl import parse_strategy, validate_strategy
from pipeline_engine.dsl.emitter import spec_to_dsl, spec_to_graph
from pipeline_engine.dsl.differ import diff_strategies

__all__ = [
    "parse_strategy",
    "validate_strategy",
    "spec_to_dsl",
    "spec_to_graph",
    "diff_strategies",
]
'''
    (SDK_PE_DIR / "__init__.py").write_text(content)


def _write_base_init():
    """Write a slim base/__init__.py for the SDK (no runtime classes)."""
    content = '''\
"""Base component system — SDK subset.

Only exports StepCategory and registry types needed by the validator.
Runtime base classes (DataSource, SignalTransform, etc.) are excluded.
"""

from .categories import StepCategory
from .registry_types import (
    COMPONENT_REGISTRY,
    ComponentSignature,
    RegistryParamInfo,
    load_registry_from_json,
)

__all__ = [
    "StepCategory",
    "ComponentSignature",
    "RegistryParamInfo",
    "COMPONENT_REGISTRY",
    "load_registry_from_json",
]
'''
    (SDK_PE_DIR / "base" / "__init__.py").write_text(content)


def _patch_imports():
    """Patch copied files to remove imports of excluded modules."""
    # validation_shared.py: remove import of pipeline_engine.types for ANNOTATED_SEMANTIC_NAMES
    # The SDK version needs a static version of this
    vs_path = SDK_PE_DIR / "validation_shared.py"
    content = vs_path.read_text()

    # Replace the dynamic _init_annotated_semantic_names with a static version
    old_init = """def _init_annotated_semantic_names() -> None:
    \"\"\"Auto-discover Annotated types from pipeline_engine.types.\"\"\"
    from pipeline_engine import types as t

    for name in dir(t):
        if name.startswith("_"):
            continue
        obj = getattr(t, name)
        if get_origin(obj) is Annotated:
            ANNOTATED_SEMANTIC_NAMES[id(obj)] = name


_init_annotated_semantic_names()"""

    new_init = """def _init_annotated_semantic_names() -> None:
    \"\"\"Auto-discover Annotated types from pipeline_engine.types.\"\"\"
    try:
        from pipeline_engine import types as t

        for name in dir(t):
            if name.startswith("_"):
                continue
            obj = getattr(t, name)
            if get_origin(obj) is Annotated:
                ANNOTATED_SEMANTIC_NAMES[id(obj)] = name
    except ImportError:
        # SDK mode: no types module available.
        # ANNOTATED_SEMANTIC_NAMES stays empty — the validator uses
        # string-based type names from registry.json instead.
        pass


_init_annotated_semantic_names()"""

    if old_init in content:
        content = content.replace(old_init, new_init)
        vs_path.write_text(content)
        print("  Patched validation_shared.py for SDK compatibility")

    # dsl/validator.py: patch imports for SDK compatibility
    val_path = SDK_PE_DIR / "dsl" / "validator.py"
    if val_path.exists():
        val_content = val_path.read_text()
        # Make ensure_registry_loaded optional
        val_content = val_content.replace(
            "from pipeline_engine.registry_loader import ensure_registry_loaded\n\n    ensure_registry_loaded()\n",
            "try:\n        from pipeline_engine.registry_loader import ensure_registry_loaded\n        ensure_registry_loaded()\n    except ImportError:\n        pass  # SDK mode: registry loaded from JSON before calling validator\n",
        )
        # Make base.lock import optional
        val_content = val_content.replace(
            "from pipeline_engine.base.lock import generate_lock\n",
            "try:\n        from pipeline_engine.base.lock import generate_lock\n    except ImportError:\n        generate_lock = None  # SDK mode: lock generated by keel.tools.local\n",
        )
        # Protect the generate_lock call
        val_content = val_content.replace(
            "            lock = generate_lock(strategy)\n",
            "            lock = generate_lock(strategy) if generate_lock else None\n",
        )
        val_path.write_text(val_content)
        print("  Patched dsl/validator.py for SDK compatibility")

    # dsl/__init__.py: check if it imports excluded modules
    dsl_init = SDK_PE_DIR / "dsl" / "__init__.py"
    if dsl_init.exists():
        content = dsl_init.read_text()
        # Remove imports of resolver and explainer
        lines = content.split("\n")
        filtered = []
        for line in lines:
            if "resolver" in line.lower() and "import" in line.lower():
                continue
            if "explainer" in line.lower() and "import" in line.lower():
                continue
            if "resolve_strategy" in line:
                continue
            if "explain_strategy" in line:
                continue
            filtered.append(line)
        new_content = "\n".join(filtered)
        if new_content != content:
            dsl_init.write_text(new_content)
            print("  Patched dsl/__init__.py to remove resolver/explainer imports")


def write_json(path: Path, data):
    """Write JSON data to file with pretty printing."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    print(f"  Wrote {path.name} ({path.stat().st_size:,} bytes)")


def main():
    ensure_imports()

    print("Building Keel SDK data artifacts...")
    print()

    # Ensure data directory exists
    KEEL_DATA_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Registry
    print("1. Building registry.json...")
    registry_data = build_registry_json()
    write_json(KEEL_DATA_DIR / "registry.json", registry_data)

    # 2. Type graph
    print("2. Building type_graph.json...")
    type_graph = build_type_graph(registry_data)
    write_json(KEEL_DATA_DIR / "type_graph.json", type_graph)

    # 3. Tool schemas
    print("3. Building tool_schemas.json...")
    schemas = build_tool_schemas()
    write_json(KEEL_DATA_DIR / "tool_schemas.json", schemas)

    # 4. Examples
    print("4. Building examples.json...")
    examples = build_examples()
    write_json(KEEL_DATA_DIR / "examples.json", examples)

    # 5. Templates
    print("5. Building templates.json...")
    templates = build_templates()
    write_json(KEEL_DATA_DIR / "templates.json", templates)

    # 6. Knowledge files
    print("6. Copying knowledge files...")
    copy_knowledge()

    # 7. Pattern files
    print("7. Copying pattern files...")
    copy_patterns()

    # 8. Reference files
    print("8. Copying reference files...")
    copy_reference()

    # 9. DSL subset
    print("9. Copying DSL subset...")
    copy_dsl_subset()

    # 10. Create data package __init__.py if needed
    init_path = KEEL_DATA_DIR / "__init__.py"
    if not init_path.exists():
        init_path.write_text('"""Bundled data artifacts for the Keel SDK."""\n')

    print()
    print("Build complete!")
    print(f"  Components: {len(registry_data['components'])}")
    print(f"  Tool schemas: {len(schemas)}")
    print(f"  Templates: {len(templates)}")


if __name__ == "__main__":
    main()
