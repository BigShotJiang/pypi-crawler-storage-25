"""Shared constants for the pipeline engine.

Provides sentinel values used across multiple modules to avoid identity
divergence from independently created sentinels.
"""

# Sentinel for "no default provided" / "required parameter".
# Distinct from None so we can tell "required param" from "default is None".
MISSING = object()


__all__ = ["MISSING"]
