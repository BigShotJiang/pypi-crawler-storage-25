import json
import os

class UnitreeExperiences:
    def __init__(self, json_path=None):
        if json_path is None:
            json_path = os.path.join(os.path.dirname(__file__), "all_pickup_experiences.json")
        self.experiences = []
        if os.path.exists(json_path):
            with open(json_path, 'r') as f:
                self.experiences = json.load(f)
            print(f"? 加载 {len(self.experiences)} 个宇树经验")

    def query(self, task):
        if "pickup" in task or "捡" in task:
            if self.experiences:
                return {
                    "found": True,
                    "sample_count": len(self.experiences),
                    "avg_frames": sum(e['frames'] for e in self.experiences) / len(self.experiences),
                    "avg_change": sum(e['avg_change'] for e in self.experiences) / len(self.experiences)
                }
        return {"found": False}