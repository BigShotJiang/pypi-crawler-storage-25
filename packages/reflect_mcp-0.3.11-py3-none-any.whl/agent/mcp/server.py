"""Reflect management MCP server.

Exposes reflect's management surface as MCP tools so any top-level Claude
session can drive reflect operations without CLI knowledge.

Entity-action pattern: 7 tools, ~20 actions total. Well within agent tool
budget limits.

Tools:
  track        — list, status, send, logs, interrupt
  track_admin  — create, enable, disable
  project      — list, link, unlink
  wake         — status, history, start, stop
  inbox        — list, peek, timeline
  doctor       — (no action; runs all checks)
  cost         — summary (flat or by-track, optional since filter)

Usage:
  uv run reflect-manage          # starts stdio MCP server
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from agent.cli.ops.track import (
    list_tracks,
    get_track_state,
    send_to_track,
    interrupt_track,
    create_track,
    enable_track,
    disable_track,
    get_track_logs,
)
from agent.cli.ops.project import list_projects, link_project, unlink_project
from agent.cli.ops.inbox import list_inbox, peek_inbox, inbox_timeline
from agent.cli.ops.wake import list_running_wakes, get_wake_history, start_wake, stop_wake
from agent.cli.ops.doctor import run_checks, run_doctor_structured
from agent.cli.ops.cost import get_cost_summary

# ── Server instance ─────────────────────────────────────────────────────────

server = Server("reflect")


# ── Tool definitions ─────────────────────────────────────────────────────────


TOOLS: list[Tool] = [
    Tool(
        name="track",
        description=(
            "Inspect or message a reflection track. "
            "action=list: list all tracks and their state. "
            "action=status: get state for a specific track (requires track). "
            "action=send: drop a message into a track's inbox (requires track + message). "
            "Messages queued via 'send' are read on the track's next wake. "
            "action=logs: read the dispatcher tick log for a track from /tmp/reflect-tick-{name}.log (requires track). "
            "action=interrupt: inject a message into a track (requires track + message). "
            "State-aware: running→socket delivery; idle→inbox-drop + immediate wake fired; "
            "wedged→inbox-drop, wake NOT fired; disabled→inbox-drop, wake NOT fired. "
            "Response includes: delivered ('socket'|'inbox'), track_state, wake_fired (bool), wake_pid."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "status", "send", "logs", "interrupt"]},
                "track": {"type": "string", "description": "Track name (required for status, send, logs)"},
                "message": {"type": "string", "description": "Message text (required for send or interrupt)"},
            },
        },
    ),
    Tool(
        name="track_admin",
        description=(
            "Manage track lifecycle. "
            "action=create: create a new track (requires track; optional template=blank|security-audit). "
            "action=enable: enable a disabled track (requires track). "
            "action=disable: disable a running/idle track (requires track). "
            "Destructive ops are split here for permission granularity."
        ),
        inputSchema={
            "type": "object",
            "required": ["action", "track"],
            "properties": {
                "action": {"type": "string", "enum": ["create", "enable", "disable"]},
                "track": {"type": "string", "description": "Track name"},
                "template": {
                    "type": "string",
                    "enum": ["blank", "security-audit"],
                    "description": "Track template (create only, default=blank)",
                },
            },
        },
    ),
    Tool(
        name="project",
        description=(
            "Manage linked projects for multi-project orchestration. "
            "action=list: list all linked projects. "
            "action=link: link a project directory (requires path). "
            "action=unlink: unlink a project by name (requires name)."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "link", "unlink"]},
                "path": {"type": "string", "description": "Absolute path to project dir (link only)"},
                "name": {"type": "string", "description": "Project name (unlink only)"},
            },
        },
    ),
    Tool(
        name="wake",
        description=(
            "Inspect or start wake activity. "
            "action=status: list currently running wakes across all tracks. "
            "action=history: recent wake history (optional: track filter, limit). "
            "action=start: fire a wake for a track (requires track; returns {ok, pid, message}). "
            "action=stop: request graceful stop of a running wake (requires track; touches stop.requested flag)."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["status", "history", "start", "stop"]},
                "track": {"type": "string", "description": "Track name (required for start, stop; filter for history)"},
                "limit": {"type": "integer", "description": "Max rows to return (history only, default=20)"},
            },
        },
    ),
    Tool(
        name="cost",
        description=(
            "Show spend summary across wakes. "
            "Returns aggregate total, wake count, and average api_equivalent_usd. "
            "Optional by_track=true to break down per track. "
            "Optional since=ISO timestamp or unix float to restrict to wakes after that time."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "by_track": {"type": "boolean", "description": "Group results by track (default false)"},
                "since": {"type": "string", "description": "ISO timestamp or unix float; filter to wakes started after this time"},
            },
        },
    ),
    Tool(
        name="inbox",
        description=(
            "Inspect track inboxes. "
            "action=list: list unread messages (optional: track filter). "
            "action=peek: read contents of a specific inbox file (requires track + filename). "
            "action=timeline: unified time-ordered view of pending + consumed + agent surfaces for a track (requires track). "
            "  Optional: pending_only=true to omit consumed, limit=N (default 50), since=ISO timestamp."
        ),
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {"type": "string", "enum": ["list", "peek", "timeline"]},
                "track": {"type": "string", "description": "Track name (filter for list; required for peek and timeline)"},
                "filename": {"type": "string", "description": "Filename to read (peek only)"},
                "pending_only": {"type": "boolean", "description": "timeline only: omit consumed messages (default false)"},
                "limit": {"type": "integer", "description": "timeline only: max entries to return (default 50)"},
                "since": {"type": "string", "description": "timeline only: ISO timestamp; only include entries at or after this time"},
            },
        },
    ),
    Tool(
        name="doctor",
        description=(
            "Run health checks against the reflect runtime. "
            "Returns a list of check results with status=PASS|WARN|ERROR and a message. "
            "No parameters required."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
    Tool(
        name="reflect_doctor",
        description=(
            "Run health checks and return a structured JSON payload (FR19/DR20). "
            "Returns: {status, contract_version, per_track_health[], wedge_file_path, suggested_actions[]}. "
            "status is 'clean' | 'warnings' | 'wedged'. "
            "per_track_health is a list of {track, status, violations}. "
            "No parameters required."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
        },
    ),
]


# ── Tool handlers ─────────────────────────────────────────────────────────────


def _text(data: Any) -> list[TextContent]:
    """Serialize data to a single TextContent JSON block."""
    return [TextContent(type="text", text=json.dumps(data, indent=2))]


@server.list_tools()
async def list_tools() -> list[Tool]:
    return TOOLS


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    action = arguments.get("action", "")

    # ── track ────────────────────────────────────────────────────────
    if name == "track":
        if action == "list":
            names = list_tracks()
            rows = []
            for n in names:
                s = get_track_state(n)
                if "error" not in s:
                    rows.append({
                        "name": s["name"],
                        "state": s["state"],
                        "last_wake": s["last_wake_fmt"],
                        "unread_count": s["unread_count"],
                    })
            return _text(rows)

        elif action == "status":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for status"})
            return _text(get_track_state(track))

        elif action == "send":
            track = arguments.get("track")
            message = arguments.get("message")
            if not track or not message:
                return _text({"error": "track and message required for send"})
            return _text(send_to_track(track, message))

        elif action == "logs":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for logs"})
            return _text(get_track_logs(track))

        elif action == "interrupt":
            track = arguments.get("track")
            message = arguments.get("message")
            if not track or not message:
                return _text({"error": "track and message required for interrupt"})
            return _text(interrupt_track(track, message))

        return _text({"error": f"unknown action: {action}"})

    # ── track_admin ──────────────────────────────────────────────────
    elif name == "track_admin":
        track = arguments.get("track")
        if not track:
            return _text({"error": "track required"})

        if action == "create":
            template = arguments.get("template", "blank")
            return _text(create_track(track, template=template))

        elif action == "enable":
            return _text(enable_track(track))

        elif action == "disable":
            return _text(disable_track(track))

        elif action == "interrupt":
            # DEPRECATED: interrupt moved to track tool. Forwarding for one release cycle.
            message = arguments.get("message")
            if not message:
                return _text({"error": "message required for interrupt"})
            result = interrupt_track(track, message)
            if isinstance(result, dict):
                result["_deprecated"] = "track_admin(action='interrupt') is deprecated; use track(action='interrupt') instead"
            return _text(result)

        return _text({"error": f"unknown action: {action}"})

    # ── project ──────────────────────────────────────────────────────
    elif name == "project":
        if action == "list":
            return _text(list_projects())

        elif action == "link":
            path = arguments.get("path")
            if not path:
                return _text({"error": "path required for link"})
            return _text(link_project(path))

        elif action == "unlink":
            proj_name = arguments.get("name")
            if not proj_name:
                return _text({"error": "name required for unlink"})
            return _text(unlink_project(proj_name))

        return _text({"error": f"unknown action: {action}"})

    # ── wake ─────────────────────────────────────────────────────────
    elif name == "wake":
        if action == "status":
            return _text(list_running_wakes())

        elif action == "history":
            track = arguments.get("track")
            limit = int(arguments.get("limit", 20))
            return _text(get_wake_history(track=track, limit=limit))

        elif action == "start":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for start"})
            return _text(start_wake(track))

        elif action == "stop":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for stop"})
            return _text(stop_wake(track))

        return _text({"error": f"unknown action: {action}"})

    # ── inbox ────────────────────────────────────────────────────────
    elif name == "inbox":
        if action == "list":
            track = arguments.get("track")
            return _text(list_inbox(track=track))

        elif action == "peek":
            track = arguments.get("track")
            filename = arguments.get("filename")
            if not track or not filename:
                return _text({"error": "track and filename required for peek"})
            return _text(peek_inbox(track, filename))

        elif action == "timeline":
            track = arguments.get("track")
            if not track:
                return _text({"error": "track required for timeline"})
            pending_only = bool(arguments.get("pending_only", False))
            limit = int(arguments.get("limit", 50))
            since = arguments.get("since")
            return _text(inbox_timeline(track=track, pending_only=pending_only, limit=limit, since=since))

        return _text({"error": f"unknown action: {action}"})

    # ── doctor ───────────────────────────────────────────────────────
    elif name == "doctor":
        return _text(run_checks())

    # ── reflect_doctor (structured payload, FR19/DR20) ───────────────
    elif name == "reflect_doctor":
        return _text(run_doctor_structured())

    # ── cost ─────────────────────────────────────────────────────────
    elif name == "cost":
        by_track = bool(arguments.get("by_track", False))
        since = arguments.get("since")
        try:
            return _text(get_cost_summary(by_track=by_track, since=since))
        except ValueError as exc:
            return _text({"error": str(exc)})

    return _text({"error": f"unknown tool: {name}"})


# ── Entry point ───────────────────────────────────────────────────────────────


def main() -> None:
    """Run the reflect management MCP server over stdio."""
    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            init_options = server.create_initialization_options()
            await server.run(read_stream, write_stream, init_options)

    asyncio.run(_run())


if __name__ == "__main__":
    main()
