"""Dashboard subcommand — launches the live multi-track TUI."""
from __future__ import annotations
from pathlib import Path
from .track import TRACKS_DIR


def cmd_dashboard(args) -> None:
    from .tui.dashboard_app import DashboardApp
    app = DashboardApp(tracks_dir=TRACKS_DIR)
    result = app.run()
    # If the app returned a track name, the user pressed 'i' — open inbox TUI
    if result:
        from .tui.inbox_app import InboxApp
        track_dir = TRACKS_DIR / result
        inbox_dir = track_dir / "inbox" / "from-originator"
        if inbox_dir.exists():
            inbox_app = InboxApp(track=result, inbox_dir=inbox_dir)
            inbox_app.run()
