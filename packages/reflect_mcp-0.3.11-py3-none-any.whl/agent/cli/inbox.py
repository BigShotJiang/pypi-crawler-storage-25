"""Inbox subcommands for the reflect CLI."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from .output import OutputMode, print_list
from .ops.track import TRACKS_DIR, list_tracks as _track_names


def _inbox_files_for_track(name: str) -> list[dict]:
    track_dir = TRACKS_DIR / name
    inbox_dir = track_dir / "inbox" / "from-originator"
    consumed_dir = inbox_dir / ".consumed"

    if not inbox_dir.exists():
        return []

    consumed_names: set[str] = set()
    if consumed_dir.exists():
        consumed_names = set(p.name for p in consumed_dir.glob("*.md"))

    files = []
    for p in sorted(inbox_dir.glob("*.md"), reverse=True):
        if p.name in consumed_names:
            continue
        try:
            mtime = p.stat().st_mtime
            mtime_str = datetime.fromtimestamp(mtime, tz=timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
        except OSError:
            mtime_str = "-"
        files.append({
            "track": name,
            "filename": p.name,
            "mtime": mtime_str,
        })
    return files


def _render_timeline_human(entries: list[dict]) -> None:
    """Print a time-ordered interleaved inbox view to stdout."""
    if not entries:
        print("No messages found.")
        return

    # Compute column widths
    ts_w = max(len(e["timestamp"]) for e in entries)
    ts_w = max(ts_w, len("timestamp"))
    dir_w = 9   # "←user" / "→agent" padded
    status_w = 8  # "consumed" is longest

    header = (
        f"{'timestamp':<{ts_w}}  {'dir':<{dir_w}}  {'status':<{status_w}}  title"
    )
    print(header)
    print("-" * min(len(header) + 40, 120))

    for e in entries:
        ts = e["timestamp"]
        direction = e["direction"]
        status = e["status"]
        title = e["title"]
        # Truncate title to avoid very long lines
        if len(title) > 60:
            title = title[:57] + "..."
        print(f"{ts:<{ts_w}}  {direction:<{dir_w}}  {status:<{status_w}}  {title}")


def cmd_inbox(args) -> None:
    mode = OutputMode(args.output)
    track_filter = getattr(args, "track", None)
    interleave = getattr(args, "interleave", False)
    pending_only = getattr(args, "pending_only", False)
    limit = getattr(args, "limit", 50)
    since = getattr(args, "since", None)

    # ── interleaved timeline mode ────────────────────────────────────────────
    if interleave:
        if not track_filter:
            print("inbox -i requires a track name, e.g.: reflect inbox main -i", file=sys.stderr)
            sys.exit(1)
        from .ops.inbox import inbox_timeline
        result = inbox_timeline(
            track=track_filter,
            pending_only=pending_only,
            limit=limit,
            since=since,
        )
        if isinstance(result, dict) and "error" in result:
            print(result["error"], file=sys.stderr)
            sys.exit(1)
        if mode == OutputMode.JSON:
            print(json.dumps(result, indent=2))
        else:
            _render_timeline_human(result)
        return

    # ── standard pending-only list mode ─────────────────────────────────────
    if track_filter:
        track_dir = TRACKS_DIR / track_filter
        if not track_dir.exists():
            print(f"Track '{track_filter}' not found.", file=sys.stderr)
            sys.exit(1)
        names = [track_filter]
    else:
        names = _track_names()

    all_files: list[dict] = []
    for name in names:
        all_files.extend(_inbox_files_for_track(name))

    if not all_files:
        if mode == OutputMode.HUMAN:
            print("No unread inbox messages found.")
        else:
            print(json.dumps([], indent=2))
        return

    print_list(all_files, mode)
