"""Wake subcommands for the reflect CLI."""
from __future__ import annotations

import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from .output import OutputMode, print_list, print_table
from .ops.track import (
    TRACKS_DIR,
    PROJECT_ROOT,
    _is_pid_alive,
    _read_lock_pid,
    list_tracks as _track_names,
)

WAKES_TSV = PROJECT_ROOT / "agent" / "runtime" / "wakes.tsv"


def _running_wakes() -> list[dict]:
    results = []
    for name in _track_names():
        track_dir = TRACKS_DIR / name
        lock_path = track_dir / "wake.lock"
        if not lock_path.exists():
            continue
        pid = _read_lock_pid(lock_path)
        if pid is None:
            continue
        if not _is_pid_alive(pid):
            continue

        # Calculate runtime
        runtime_secs = None
        lws_path = track_dir / "last-wake-start.timestamp"
        try:
            start_ts = int(lws_path.read_text().strip())
            runtime_secs = int(time.time()) - start_ts
        except (OSError, ValueError):
            pass

        results.append({
            "track": name,
            "pid": pid,
            "runtime": runtime_secs,
            "state": "running",
        })
    return results


def cmd_wake_list(args) -> None:
    mode = OutputMode(args.output)
    wakes = _running_wakes()

    if not wakes:
        if mode == OutputMode.HUMAN:
            print("No wakes currently running.")
        else:
            import json
            print(json.dumps([], indent=2))
        return

    rows = [
        [w["track"], w["pid"], f"{w['runtime']}s" if w["runtime"] is not None else "-", w["state"]]
        for w in wakes
    ]
    print_table(["track", "pid", "runtime", "state"], rows, mode)


def cmd_wake_start(args) -> None:
    name = args.track
    force = getattr(args, "force", False)
    track_dir = TRACKS_DIR / name

    if not track_dir.exists():
        print(f"Track '{name}' not found.", file=sys.stderr)
        sys.exit(1)

    lock_path = track_dir / "wake.lock"

    if lock_path.exists():
        pid = _read_lock_pid(lock_path)
        alive = pid is not None and _is_pid_alive(pid)

        if alive and not force:
            print(
                f"Wake already running for '{name}' (pid {pid}). "
                "Use --force to override.",
                file=sys.stderr,
            )
            sys.exit(1)

        if alive and force:
            print(f"Stopping existing wake (pid {pid})...")
            stop_file = track_dir / "stop.requested"
            stop_file.touch()

            # Wait up to 30s for the process to exit
            deadline = time.time() + 30
            while time.time() < deadline:
                if not _is_pid_alive(pid):
                    break
                time.sleep(1)
            else:
                print(f"Process {pid} did not exit after 30s, sending SIGKILL...")
                try:
                    import signal
                    os.kill(pid, signal.SIGKILL)
                except (OSError, ProcessLookupError):
                    pass

            # Clean up lock and stop file
            try:
                lock_path.unlink()
            except OSError:
                pass
            try:
                stop_file.unlink()
            except OSError:
                pass

    # Fire the wake
    env = os.environ.copy()
    env["REFLECT_TRACK"] = name
    os.execvpe("uv", ["uv", "run", "reflect-wake"], env)


def cmd_wake_stop(args) -> None:
    name = args.track
    track_dir = TRACKS_DIR / name

    if not track_dir.exists():
        print(f"Track '{name}' not found.", file=sys.stderr)
        sys.exit(1)

    stop_file = track_dir / "stop.requested"
    stop_file.touch()
    print(f"Stop requested for '{name}'. The wake will wind down gracefully.")


def _parse_wakes_tsv() -> list[dict]:
    if not WAKES_TSV.exists():
        return []
    rows = []
    try:
        lines = WAKES_TSV.read_text().splitlines()
        if not lines:
            return []
        headers = lines[0].split("\t")
        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.split("\t")
            row = dict(zip(headers, parts))
            # Normalize legacy cost_usd column → api_equivalent_usd
            if "cost_usd" in row and "api_equivalent_usd" not in row:
                row["api_equivalent_usd"] = row.pop("cost_usd")
            rows.append(row)
    except OSError:
        pass
    return rows


def _get_wake_track(wake_id: str) -> Optional[str]:
    """Try to read track.name from wake directory."""
    wake_dir = PROJECT_ROOT / "agent" / "runtime" / "wakes" / wake_id
    track_name_file = wake_dir / "track.name"
    try:
        return track_name_file.read_text().strip()
    except OSError:
        return None


def cmd_wake_history(args) -> None:
    mode = OutputMode(args.output)
    track_filter = getattr(args, "track", None)
    limit = getattr(args, "limit", 20)

    rows = _parse_wakes_tsv()

    if track_filter:
        # Filter by track if track.name file exists; else show all (no info to filter by)
        filtered = []
        for row in rows:
            wake_track = _get_wake_track(row.get("wake_id", ""))
            if wake_track is None or wake_track == track_filter:
                filtered.append(row)
        rows = filtered

    rows = rows[-limit:]

    if not rows:
        if mode == OutputMode.HUMAN:
            print("No wake history found.")
        else:
            import json
            print(json.dumps([], indent=2))
        return

    headers = ["wake_id", "started_at", "ended_at", "slept_clean", "num_turns", "api_equivalent_usd", "early_break_reason"]

    if mode == OutputMode.HUMAN:
        table_rows = []
        for row in rows:
            started = row.get("started_at", "")
            ended = row.get("ended_at", "")
            # Format timestamps if numeric
            try:
                started = datetime.fromtimestamp(int(started), tz=timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
            except (ValueError, OSError):
                pass
            try:
                ended = datetime.fromtimestamp(int(ended), tz=timezone.utc).strftime("%Y-%m-%dT%H:%MZ")
            except (ValueError, OSError):
                pass

            # Duration
            duration = "-"
            try:
                s = int(row.get("started_at", ""))
                e = int(row.get("ended_at", ""))
                duration = f"{e - s}s"
            except (ValueError, TypeError):
                pass

            table_rows.append([
                row.get("wake_id", ""),
                started,
                duration,
                row.get("slept_clean", ""),
                row.get("num_turns", ""),
                row.get("api_equivalent_usd") or row.get("cost_usd", ""),
                row.get("early_break_reason", "")[:40],
            ])
        print_table(
            ["wake_id", "started_at", "duration", "clean", "turns", "api_equiv_usd", "reason"],
            table_rows,
            mode,
        )
    else:
        import json
        out = [{h: row.get(h, "") for h in headers} for row in rows]
        print(json.dumps(out, indent=2))
