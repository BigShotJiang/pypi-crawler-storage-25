"""Pure wake operations — no CLI formatting, no sys.exit, no stdout.

All functions return structured dicts. Callers (CLI, MCP) format as needed.
"""
from __future__ import annotations

import json as _json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone as _tz
from pathlib import Path
from typing import Optional

from agent.cli.ops.root import resolve_project_root
PROJECT_ROOT = resolve_project_root()
TRACKS_DIR = PROJECT_ROOT / "agent" / "runtime" / "tracks"
WAKES_TSV = PROJECT_ROOT / "agent" / "runtime" / "wakes.tsv"
WAKES_DIR = PROJECT_ROOT / "agent" / "runtime" / "wakes"


def _is_pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_lock_pid(lock_path: Path) -> Optional[int]:
    try:
        content = lock_path.read_text().strip()
        for line in content.splitlines():
            line = line.strip()
            if line.isdigit():
                return int(line)
    except (OSError, ValueError):
        pass
    return None


def _track_names(tracks_dir: Optional[Path] = None) -> list[str]:
    td = tracks_dir or TRACKS_DIR
    if not td.exists():
        return []
    return sorted(d.name for d in td.iterdir() if d.is_dir() and not d.name.startswith("."))


def list_running_wakes(tracks_dir: Optional[Path] = None) -> list[dict]:
    """Return list of currently running wakes.

    Each dict: {track, pid, runtime_secs, state}
    """
    td = tracks_dir or TRACKS_DIR
    results = []
    for name in _track_names(td):
        track_dir = td / name
        lock_path = track_dir / "wake.lock"
        if not lock_path.exists():
            continue
        pid = _read_lock_pid(lock_path)
        if pid is None:
            continue
        if not _is_pid_alive(pid):
            continue

        runtime_secs: Optional[int] = None
        lws_path = track_dir / "last-wake-start.timestamp"
        try:
            start_ts = int(lws_path.read_text().strip())
            runtime_secs = int(time.time()) - start_ts
        except (OSError, ValueError):
            pass

        results.append({
            "track": name,
            "pid": pid,
            "runtime_secs": runtime_secs,
            "state": "running",
        })
    return results


def get_wake_history(track: Optional[str] = None, limit: int = 20) -> list[dict]:
    """Return recent wake history rows from wakes.tsv.

    Each dict contains fields from TSV headers. Filtered by track name if provided.
    """
    if not WAKES_TSV.exists():
        return []

    rows = []
    try:
        lines = WAKES_TSV.read_text().splitlines()
        if not lines:
            return []
        headers = lines[0].split("\t")
        for line in lines[1:]:
            if not line.strip():
                continue
            parts = line.split("\t")
            row = dict(zip(headers, parts))
            rows.append(row)
    except OSError:
        return []

    if track:
        filtered = []
        for row in rows:
            wake_id = row.get("wake_id", "")
            wake_dir = PROJECT_ROOT / "agent" / "runtime" / "wakes" / wake_id
            track_name_file = wake_dir / "track.name"
            try:
                wake_track = track_name_file.read_text().strip()
            except OSError:
                wake_track = None
            if wake_track is None or wake_track == track:
                filtered.append(row)
        rows = filtered

    return rows[-limit:]


def start_wake(track: str) -> dict:
    """Spawn a wake for *track* as a background subprocess.

    Returns: {ok: bool, pid: int | None, message: str}

    Unlike the CLI's cmd_wake_start (which uses os.execvpe to replace the
    current process), this spawns a detached child so the MCP caller can
    receive a response immediately.
    """
    track_dir = TRACKS_DIR / track
    if not track_dir.exists():
        return {"ok": False, "pid": None, "message": f"track '{track}' not found"}

    lock_path = track_dir / "wake.lock"
    if lock_path.exists():
        pid = _read_lock_pid(lock_path)
        if pid is not None and _is_pid_alive(pid):
            return {
                "ok": False,
                "pid": pid,
                "message": f"wake already running for '{track}' (pid {pid})",
            }

    env = os.environ.copy()
    env["REFLECT_TRACK"] = track

    # Log file: captures startup errors that were previously swallowed by DEVNULL.
    # Truncated on each spawn so the file always reflects the most-recent attempt.
    log_path = Path(f"/tmp/reflect-wake-{track}.log")

    try:
        log_fh = log_path.open("w")
        proc = subprocess.Popen(
            [sys.executable, "-m", "agent.runtime.wake"],
            env=env,
            cwd=str(PROJECT_ROOT),
            start_new_session=True,   # detach from MCP server's session
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
        )
        log_fh.close()
        return {"ok": True, "pid": proc.pid, "message": f"wake started for '{track}' (pid {proc.pid}), log: {log_path}"}
    except Exception as exc:
        return {"ok": False, "pid": None, "message": f"failed to start wake: {exc}"}


def stop_wake(track: str) -> dict:
    """Request graceful stop of a running wake for *track*.

    Touches ``stop.requested`` in the track directory. The running wake checks
    this file between tool calls and winds down cleanly on next opportunity.

    Returns: {ok: bool, message: str}
    """
    track_dir = TRACKS_DIR / track
    if not track_dir.exists():
        return {"ok": False, "message": f"track '{track}' not found"}

    stop_file = track_dir / "stop.requested"
    stop_file.touch()
    return {
        "ok": True,
        "message": f"Stop requested for '{track}'. Wake will wind down gracefully.",
    }


def latest_wake_for_track(track: str) -> Optional[dict]:
    """Return the most-recent wake (running or completed) for *track*.

    Returns a dict::

        {
            "wake_id":         str,
            "transcript_path": Path | None,
            "is_running":      bool,
            "num_turns":       int | None,   # None while running
            "cost_usd":        float | None, # None while running
        }

    Priority: a currently-running lock beats any wakes.tsv row.
    Returns None if no wake can be found for this track.

    Column layout for wakes.tsv data rows:
    * 9-col (current): wake_id, track, started_at, ended_at, slept_clean,
                        num_turns, cost_usd, early_break_reason, transcript_path
    * 8-col (legacy):  wake_id, started_at, ended_at, slept_clean, num_turns,
                        cost_usd, early_break_reason, transcript_path
                        (no track field — skipped)
    """
    track_dir = TRACKS_DIR / track
    lock_path = track_dir / "wake.lock"
    lws_path = track_dir / "last-wake-start.timestamp"

    # ── running wake ───────────────────────────────────────────────────────
    # Detection: last-wake-start.timestamp > last-wake.timestamp means the
    # wake started but hasn't written its end timestamp yet.  The lock file
    # holds an flock (no PID written), so we can't use _read_lock_pid here.
    lwe_path = track_dir / "last-wake.timestamp"
    if lws_path.exists():
        try:
            start_ts = int(lws_path.read_text().strip())
            try:
                end_ts = int(lwe_path.read_text().strip())
            except (OSError, ValueError):
                end_ts = 0  # no end timestamp → wake hasn't finished
            if start_ts > end_ts:
                wake_id = datetime.fromtimestamp(start_ts, tz=_tz.utc).strftime(
                    "%Y-%m-%dT%H-%M-%SZ"
                )
                # Per-track subfolders (current layout): WAKES_DIR/<track>/<id>/
                t_path = WAKES_DIR / track / wake_id / "transcript.jsonl"
                if not t_path.exists():
                    # Backward-compat: flat namespace (pre-fix wakes still in flight)
                    flat_path = WAKES_DIR / wake_id / "transcript.jsonl"
                    if flat_path.exists():
                        import sys as _sys
                        print(
                            f"[session] warn: falling back to flat wake path for {track}/{wake_id}",
                            file=_sys.stderr,
                        )
                        t_path = flat_path
                return {
                    "wake_id": wake_id,
                    "transcript_path": t_path if t_path.exists() else None,
                    "is_running": True,
                    "num_turns": None,
                    "cost_usd": None,
                }
        except (OSError, ValueError):
            pass  # fall through to wakes.tsv

    # ── last completed wake from wakes.tsv ─────────────────────────────────
    if not WAKES_TSV.exists():
        return None
    try:
        lines = WAKES_TSV.read_text().splitlines()
    except OSError:
        return None

    result: Optional[dict] = None
    for line in lines[1:]:  # skip header row
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 9:
            # 9-col layout (track field present)
            row_wake_id = parts[0]
            row_track = parts[1]
            num_turns_str = parts[5]
            cost_str = parts[6]
            transcript_rel = parts[8]
        elif len(parts) == 8:
            # 8-col legacy layout — no track info; skip
            continue
        else:
            continue

        if row_track != track:
            continue

        try:
            num_turns: Optional[int] = int(num_turns_str)
        except (ValueError, TypeError):
            num_turns = None
        try:
            cost_usd: Optional[float] = float(cost_str)
        except (ValueError, TypeError):
            cost_usd = None

        transcript_path = PROJECT_ROOT / transcript_rel if transcript_rel else None
        result = {
            "wake_id": row_wake_id,
            "transcript_path": transcript_path,
            "is_running": False,
            "num_turns": num_turns,
            "cost_usd": cost_usd,
        }

    return result


def parse_transcript_tail(
    transcript_path: Path,
    from_line: int = 0,
) -> tuple[list[str], int]:
    """Parse JSONL transcript events from *from_line* onwards.

    Returns ``(rendered_lines, new_from_line)`` where *new_from_line* is the
    total number of JSONL lines consumed so far (pass it back on the next call
    to resume where you left off).

    Only ``AssistantMessage`` events are rendered; ``UserMessage`` (tool
    results) and ``SystemMessage`` are skipped — they are too verbose for a
    tail view.

    Each content block becomes one or more display lines:
    * thinking block  → ``"🧠 <line1>"`` then ``"   <line2>"`` … (full content, multi-line)
    * text block      → the text as-is (may be multi-line)
    * tool-use block  → ``"  🔧 tool_name(<input preview>)"``
    """
    try:
        raw_bytes_lines = transcript_path.read_bytes().splitlines()
    except OSError:
        return [], from_line

    new_raw = raw_bytes_lines[from_line:]
    rendered: list[str] = []

    for raw_bytes in new_raw:
        raw = raw_bytes.strip()
        if not raw:
            continue
        try:
            event = _json.loads(raw)
        except (_json.JSONDecodeError, ValueError):
            continue

        if event.get("type") != "AssistantMessage":
            continue

        for block in event.get("data", {}).get("content", []):
            keys = set(block.keys())
            if "thinking" in keys and "text" not in keys and "name" not in keys:
                # Thinking block: {thinking, signature}
                # Render full content matching _print_event style: 🧠 on first line,
                # continuation indent on subsequent lines — no truncation.
                thinking = (block.get("thinking") or "").rstrip()
                lines = thinking.splitlines()
                if lines:
                    rendered.append(f"🧠 {lines[0]}")
                    for line in lines[1:]:
                        rendered.append(f"   {line}")
            elif "text" in keys and "name" not in keys:
                # Text block: {text}
                rendered.append(block["text"])
            elif "name" in keys and "input" in keys:
                # Tool-use block: {id, name, input}
                inp = str(block["input"])
                if len(inp) > 80:
                    inp = inp[:80] + "…"
                rendered.append(f"  🔧 {block['name']}({inp})")

    return rendered, from_line + len(new_raw)
