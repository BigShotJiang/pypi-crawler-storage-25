"""Help adapter (help://) - Meta-adapter for exploring reveal's capabilities."""

import sys
from pathlib import Path
from typing import Dict, List, Any, Optional
from .base import ResourceAdapter, register_adapter, register_renderer, _ADAPTER_REGISTRY
from ..rendering import render_help

_EXAMPLE_RECIPES: Dict[str, Dict[str, Any]] = {
    'security': {
        'type': 'query_recipes',
        'task': 'security',
        'description': 'Security analysis and vulnerability detection',
        'recipes': [
            {'goal': 'Find authentication functions', 'query': 'ast://src?name~=auth&type=function', 'description': 'Locate authentication-related code', 'output_type': 'ast_query'},
            {'goal': 'Check SSL certificate expiry', 'query': 'ssl://example.com --expiring-within=30', 'description': 'Find certificates expiring soon', 'output_type': 'ssl_certificate'},
            {'goal': 'Find SQL query construction', 'query': 'ast://src?name~=query&complexity>5', 'description': 'Locate complex database queries (SQL injection risk)', 'output_type': 'ast_query'},
        ]
    },
    'codebase': {
        'type': 'query_recipes',
        'task': 'codebase',
        'description': 'Codebase exploration and understanding',
        'recipes': [
            {'goal': 'Get project overview', 'query': 'reveal src/', 'description': 'Progressive disclosure: structure first', 'output_type': 'reveal_structure'},
            {'goal': 'Find entry points', 'query': 'ast://src?name=main*&type=function', 'description': 'Locate main() and main_* entry point functions', 'output_type': 'ast_query'},
            {'goal': 'List all classes', 'query': 'ast://src?type=class&sort=name', 'description': 'Enumerate class hierarchy for structural overview', 'output_type': 'ast_query'},
            {'goal': 'Find complex code', 'query': 'ast://src?complexity>15', 'description': 'Locate high-complexity functions', 'output_type': 'ast_query'},
        ]
    },
    'debugging': {
        'type': 'query_recipes',
        'task': 'debugging',
        'description': 'Debugging and error investigation',
        'recipes': [
            {'goal': 'Find error handlers', 'query': 'ast://src?name~=error&type=function', 'description': 'Locate error handling code', 'output_type': 'ast_query'},
            {'goal': 'Check recent changes', 'query': 'git://.?type=history', 'description': 'Review recent commit history', 'output_type': 'git_ref'},
            {'goal': 'Find large functions', 'query': 'ast://src?lines>100&type=function', 'description': 'Locate potentially problematic large functions', 'output_type': 'ast_query'},
        ]
    },
    'quality': {
        'type': 'query_recipes',
        'task': 'quality',
        'description': 'Code quality and hotspot analysis',
        'recipes': [
            {'goal': 'Find quality hotspots', 'query': 'stats://src?hotspots=true', 'description': 'Ranked list of files with quality issues', 'output_type': 'stats_summary'},
            {'goal': 'Check code complexity', 'query': 'ast://src?complexity>10', 'description': 'High complexity functions', 'output_type': 'ast_query'},
            {'goal': 'Find long functions lacking simplicity', 'query': 'ast://src?type=function&lines>50&sort=-lines', 'description': 'Large functions sorted by size — prime documentation/refactor targets', 'output_type': 'ast_query'},
        ]
    },
    'infrastructure': {
        'type': 'query_recipes',
        'task': 'infrastructure',
        'description': 'Server infrastructure inspection — nginx, SSL, domains',
        'recipes': [
            {'goal': 'Inspect nginx vhost', 'query': 'nginx://example.com', 'description': 'Ports, upstreams, auth, locations for a domain', 'output_type': 'nginx_vhost_summary'},
            {'goal': 'List all nginx vhosts', 'query': 'nginx://', 'description': 'Overview of all enabled nginx sites', 'output_type': 'nginx_sites_overview'},
            {'goal': 'Check nginx upstream health', 'query': 'nginx://example.com/upstream', 'description': 'TCP reachability of proxy_pass backends', 'output_type': 'nginx_vhost_upstream'},
            {'goal': 'Check SSL certificate', 'query': 'ssl://example.com --check', 'description': 'Certificate health, expiry, chain validity', 'output_type': 'ssl_certificate'},
            {'goal': 'Validate nginx SSL certs from config', 'query': 'ssl://nginx:///etc/nginx/conf.d/*.conf --check --local-certs', 'description': 'Check cert files referenced by nginx (no network)', 'output_type': 'ssl_certificate'},
            {'goal': 'Domain health check', 'query': 'domain://example.com --check', 'description': 'DNS propagation, SSL status, registration info', 'output_type': 'domain_health'},
        ]
    },
    'documentation': {
        'type': 'query_recipes',
        'task': 'documentation',
        'description': 'Documentation search and analysis — markdown, front matter',
        'recipes': [
            {'goal': 'Find docs by topic in body', 'query': "reveal 'markdown://docs/?body-contains=nginx'", 'description': 'Search doc body text (after frontmatter)', 'output_type': 'markdown_query'},
            {'goal': 'Find all guides', 'query': "reveal 'markdown://docs/?type=guide'", 'description': 'Filter by frontmatter field value', 'output_type': 'markdown_query'},
            {'goal': 'Find recent docs about deployment', 'query': "reveal 'markdown://docs/?body-contains=deploy&sort=-modified&limit=10'", 'description': 'Body search with recency sort', 'output_type': 'markdown_query'},
            {'goal': 'Validate internal links', 'query': 'reveal docs/README.md --links --link-type internal', 'description': 'Find broken internal links in a doc', 'output_type': 'markdown_query'},
            {'goal': 'Get document outline', 'query': 'reveal docs/README.md --outline', 'description': 'Hierarchical heading tree', 'output_type': 'markdown_query'},
        ]
    }
}


class HelpRenderer:
    """Renderer for help system results."""

    @staticmethod
    def render_structure(result: dict, format: str = 'text') -> None:
        """Render help topic list.

        Args:
            result: Structure dict from HelpAdapter.get_structure()
            format: Output format ('text', 'json', 'grep')
        """
        render_help(result, format, list_mode=True)

    @staticmethod
    def render_element(result: dict, format: str = 'text') -> None:
        """Render specific help topic.

        Args:
            result: Element dict from HelpAdapter.get_element()
            format: Output format ('text', 'json', 'grep')
        """
        render_help(result, format)

    @staticmethod
    def render_error(error: Exception) -> None:
        """Render user-friendly errors."""
        print(f"Error accessing help: {error}", file=sys.stderr)


@register_adapter('help')
@register_renderer(HelpRenderer)
class HelpAdapter(ResourceAdapter):
    """Adapter for exploring reveal's help system via help:// URIs.

    Examples:
        help://                    # List all help topics
        help://ast                 # Get ast:// adapter help
        help://ast/workflows       # Just the workflows section
        help://ast/try-now         # Just the try-now examples

        help://ast/anti-patterns   # Just the anti-patterns
        help://env                 # Get env:// adapter help
        help://python-guide        # Python adapter comprehensive guide
        help://markdown            # Markdown features guide
        help://tricks              # Cool tricks and hidden features
        help://adapters            # List all adapters with help
        help://quick               # Quick-reference cheat sheet (top 10 commands)
        help://agent               # Agent usage guide (AGENT_HELP.md)

    Agent Introspection (v0.46.0+):
        help://schemas/ssl         # Machine-readable schema for ssl:// adapter
        help://schemas/ast         # Machine-readable schema for ast:// adapter
        help://examples/security   # Query recipes for security analysis
        help://examples/codebase   # Query recipes for codebase exploration
    """

    ELEMENT_NAMESPACE_ADAPTER = True

    # Valid section names for help://adapter/section queries
    VALID_SECTIONS = {'workflows', 'try-now', 'anti-patterns'}

    # Static help files (markdown documentation in reveal/docs/)
    STATIC_HELP = {
        # Top-level docs (reveal/docs/)
        'quick-start': 'QUICK_START.md',
        'agent': 'AGENT_HELP.md',
        'anti-patterns': 'AGENT_HELP.md',  # Merged into AGENT_HELP.md
        # Adapter guides (reveal/docs/adapters/)
        'python': 'adapters/PYTHON_ADAPTER_GUIDE.md',
        'python-guide': 'adapters/PYTHON_ADAPTER_GUIDE.md',
        'reveal-guide': 'adapters/REVEAL_ADAPTER_GUIDE.md',
        'markdown': 'adapters/MARKDOWN_GUIDE.md',
        'html': 'adapters/HTML_GUIDE.md',
        # User guides (reveal/docs/guides/)
        'adapter-authoring': 'development/ADAPTER_AUTHORING_GUIDE.md',
        'tricks': 'guides/RECIPES.md',   # Merged into RECIPES.md (task-based workflows)
        'recipes': 'guides/RECIPES.md',
        'ux': 'guides/UX_GUIDE.md',
        'configuration': 'guides/CONFIGURATION_GUIDE.md',
        'config': 'guides/CONFIGURATION_GUIDE.md',
        'codebase-review': 'guides/RECIPES.md',  # CODEBASE_REVIEW.md archived; content merged into RECIPES.md
        'depends': 'adapters/DEPENDS_ADAPTER_GUIDE.md',
        'schemas': 'guides/SCHEMA_VALIDATION_HELP.md',
        'duplicates': 'guides/DUPLICATE_DETECTION_GUIDE.md',
        'duplicate-detection': 'guides/DUPLICATE_DETECTION_GUIDE.md',
        'dev': 'guides/SUBCOMMANDS_GUIDE.md',
        'review': 'guides/SUBCOMMANDS_GUIDE.md',
        'health': 'guides/SUBCOMMANDS_GUIDE.md',
        'pack': 'guides/SUBCOMMANDS_GUIDE.md',
        'schema': 'guides/SCHEMA_VALIDATION_HELP.md',
        'mcp': 'guides/MCP_SETUP.md',
        'mcp-setup': 'guides/MCP_SETUP.md',
        # Development docs (reveal/docs/development/)
        'help': 'development/HELP_SYSTEM_GUIDE.md',
        'output': 'development/OUTPUT_CONTRACT.md',
        'scaffolding': 'development/SCAFFOLDING_GUIDE.md',
    }

    @staticmethod
    def get_help() -> Dict[str, Any]:
        """Get help about the help system (meta!)."""
        return {
            'name': 'help',
            'description': (
                'Explore reveal help system - '
                'discover adapters, read guides'
            ),
            'syntax': 'help://[topic]',
            'examples': [
                {
                    'uri': 'help://',
                    'description': 'List all available help topics'
                },
                {
                    'uri': 'help://ast',
                    'description': 'Learn about ast:// adapter (query code as database)'
                },
                {
                    'uri': 'help://env',
                    'description': 'Learn about env:// adapter (environment variables)'
                },
                {
                    'uri': 'help://adapters',
                    'description': 'List all URI adapters with descriptions'
                },
                {
                    'uri': 'help://python-guide',
                    'description': (
                        'Python adapter comprehensive guide '
                        '(multi-shot examples, LLM integration)'
                    )
                },
                {
                    'uri': 'help://agent',
                    'description': 'Comprehensive agent reference (~12K tokens, task-pattern recipes)'
                },
                {
                    'uri': 'help://tricks',
                    'description': 'Cool tricks and hidden features guide'
                }
            ],
            'notes': [
                'Each adapter exposes its own help via get_help() method',
                'Static guides load from markdown files in reveal/docs/',
                (
                    'New adapters automatically appear in help:// '
                    'when they implement get_help()'
                ),
                (
                    'For agents: --agent-help dumps the full reference '
                    '(~12K tokens, task-pattern recipes)'
                )
            ],
            'see_also': [
                'reveal --agent-help - Comprehensive agent reference (~12K tokens)',
                'reveal --help - Raw flag and subcommand listing',
                'reveal --list-supported - Supported file types'
            ]
        }

    def __init__(self, topic: Optional[str] = None):
        """Initialize help adapter.

        Args:
            topic: Specific help topic to display (None = list all)
        """
        self.topic = topic
        # Merge auto-discovered guides with manual STATIC_HELP entries
        # STATIC_HELP takes precedence (allows aliases and special mappings)
        self.help_topics = self._discover_and_merge_guides()

    def _discover_and_merge_guides(self) -> Dict[str, str]:
        """Auto-discover guide files and merge with STATIC_HELP.

        Automatically discovers *_GUIDE.md files in reveal/docs/ and makes them
        accessible via help:// URIs. Manual STATIC_HELP entries take precedence,
        allowing for aliases and custom topic names.

        Returns:
            Dict mapping topic names to guide filenames
        """
        discovered = {}

        # Find reveal/docs directory
        docs_dir = Path(__file__).parent.parent / 'docs'

        if docs_dir.exists():
            # Auto-discover *_GUIDE.md files recursively (e.g., adapters/AST_ADAPTER_GUIDE.md)
            for guide in docs_dir.rglob('*_GUIDE.md'):
                # Convert filename to topic name
                # AST_ADAPTER_GUIDE.md -> ast-adapter
                # QUERY_SYNTAX_GUIDE.md -> query-syntax
                topic = guide.stem.lower().replace('_guide', '').replace('_', '-')
                # Store relative path from docs_dir (e.g., 'adapters/AST_ADAPTER_GUIDE.md')
                discovered[topic] = str(guide.relative_to(docs_dir))

            # Also check for *GUIDE.md pattern (without underscore before GUIDE)
            for guide in docs_dir.rglob('*GUIDE.md'):
                relative = str(guide.relative_to(docs_dir))
                if relative in discovered.values():
                    continue
                # HTMLGUIDE.md -> html (unlikely but handle it)
                topic = guide.stem.lower().replace('guide', '').replace('_', '-').strip('-')
                if topic:
                    discovered[topic] = relative

        # Merge: discovered guides + STATIC_HELP (STATIC_HELP takes precedence)
        # This allows STATIC_HELP to:
        #   - Define aliases (e.g., 'tricks' -> 'RECIPES.md')
        #   - Override auto-discovered names (e.g., 'python' -> 'PYTHON_ADAPTER_GUIDE.md')
        #   - Reference non-guide files (e.g., 'agent' -> 'AGENT_HELP.md')
        return {**discovered, **self.STATIC_HELP}

    def get_structure(self, **kwargs) -> Dict[str, Any]:
        """Get help structure (list of available topics)."""
        return {
            'contract_version': '1.0',
            'type': 'help',
            'source': 'help://',
            'source_type': 'runtime',
            'available_topics': self._list_topics(),
            'adapters': self._list_adapters(),
            'static_guides': list(self.help_topics.keys())
        }

    def get_element(self, element_name: str, **kwargs) -> Optional[Dict[str, Any]]:
        """Get help for a specific topic.

        Args:
            element_name: Topic name (adapter scheme, 'adapters', 'agent', etc.)
                   Can also be 'adapter/section' for section extraction
                   Or 'schemas/adapter' for machine-readable schemas
                   Or 'examples/task' for canonical query recipes

        Returns:
            Help content dict or None if not found
        """
        topic = element_name  # Alias for readability
        # Check for schemas route: help://schemas/ssl
        # Bare 'schemas/' lists available adapters
        if topic == 'schemas' or topic == 'schemas/':
            adapters = sorted(k for k in _ADAPTER_REGISTRY.keys() if k not in self._INTERNAL_ADAPTERS)
            return {
                'type': 'adapter_schema',
                'adapter': '',
                'available_adapters': adapters,
                'usage': 'reveal help://schemas/<adapter>',
                'examples': [
                    'reveal help://schemas/ast',
                    'reveal help://schemas/ssl',
                    'reveal help://schemas/git',
                ],
            }
        if topic.startswith('schemas/'):
            adapter_name = topic.split('/', 1)[1]
            return self._get_adapter_schema(adapter_name)

        # Check for examples route: help://examples/security
        # Bare 'examples' and 'examples/' show the task list (same as passing empty task)
        if topic == 'examples' or topic == 'examples/':
            return self._get_example_recipes('')
        if topic.startswith('examples/'):
            task_name = topic.split('/', 1)[1]
            return self._get_example_recipes(task_name)

        # Check for section extraction: help://ast/workflows
        if '/' in topic:
            adapter_name, section = topic.split('/', 1)
            return self._get_adapter_section(adapter_name, section)

        # Quick-start orientation cheat sheet
        if topic == 'quick':
            return self._get_quick_help()

        # Adapter ecosystem relationships map
        if topic == 'relationships':
            return self._get_adapter_relationships()

        # Check if it's a static guide (includes auto-discovered + manual)
        if topic in self.help_topics:
            return self._load_static_help(topic)

        # Check if it's 'adapters' (list all)
        if topic == 'adapters':
            return self._get_all_adapter_help()

        # Check if it's an adapter scheme
        if topic in _ADAPTER_REGISTRY:
            return self._get_adapter_help(topic)

        # Check if it's a known file-based analyzer (not a URI adapter)
        # Return focused inline help rather than failing with "not found"
        file_analyzer_help = self._get_file_analyzer_help(topic)
        if file_analyzer_help is not None:
            return file_analyzer_help

        return None

    def _validate_section_name(
        self, adapter_name: str, section: str
    ) -> Optional[Dict[str, Any]]:
        """Validate section name is valid.

        Returns:
            Error dict if invalid, None if valid
        """
        if section not in self.VALID_SECTIONS:
            valid_sections = ', '.join(sorted(self.VALID_SECTIONS))
            return {
                'type': 'help_section',
                'adapter': adapter_name,
                'section': section,
                'error': 'Invalid section',
                'message': (
                    f"Unknown section '{section}'. "
                    f"Valid sections: {valid_sections}"
                )
            }
        return None

    def _validate_adapter_exists(
        self, adapter_name: str, section: str
    ) -> Optional[Dict[str, Any]]:
        """Validate adapter exists in registry.

        Returns:
            Error dict if not found, None if exists
        """
        if adapter_name not in _ADAPTER_REGISTRY:
            return {
                'type': 'help_section',
                'adapter': adapter_name,
                'section': section,
                'error': 'Unknown adapter',
                'message': f"No adapter named '{adapter_name}'"
            }
        return None

    def _extract_section_content(
        self, adapter_name: str, section: str, help_data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Extract specific section from adapter help.

        Returns:
            Section content dict or error dict
        """
        # Map section names to help dict keys
        section_key_map = {
            'workflows': 'workflows',
            'try-now': 'try_now',
            'anti-patterns': 'anti_patterns',
        }

        key = section_key_map.get(section)
        content = help_data.get(key) if key else None

        if not content:
            return {
                'type': 'help_section',
                'adapter': adapter_name,
                'section': section,
                'error': 'Section not found',
                'message': (
                    f"Adapter '{adapter_name}' does not have "
                    f"a '{section}' section"
                )
            }

        return {
            'type': 'help_section',
            'adapter': adapter_name,
            'section': section,
            'content': content
        }

    def _get_adapter_section(
        self, adapter_name: str, section: str
    ) -> Optional[Dict[str, Any]]:
        """Get a specific section from an adapter's help.

        Args:
            adapter_name: Adapter scheme name (e.g., 'ast')
            section: Section name (e.g., 'workflows', 'try-now')

        Returns:
            Dict with section content or error
        """
        # Validate section name
        error = self._validate_section_name(adapter_name, section)
        if error:
            return error

        # Validate adapter exists
        error = self._validate_adapter_exists(adapter_name, section)
        if error:
            return error

        # Get full adapter help
        help_data = self._get_adapter_help(adapter_name)
        if not help_data or 'error' in help_data:
            return help_data

        # Extract and return section content
        return self._extract_section_content(adapter_name, section, help_data)

    def _list_topics(self) -> List[str]:
        """List all available help topics."""
        topics: List[str] = []

        # Add adapter schemes
        topics.extend(_ADAPTER_REGISTRY.keys())

        # Add meta topics
        topics.append('adapters')

        # Add static guides (auto-discovered + manual)
        topics.extend(self.help_topics.keys())

        return sorted(topics)

    def _get_adapter_description(self, adapter_class: type[Any]) -> str:
        """Get description from adapter's help method.

        Args:
            adapter_class: Adapter class

        Returns:
            Description string or empty string if unavailable
        """
        try:
            help_data = adapter_class.get_help()
            if help_data:
                return str(help_data.get('description', ''))
        except Exception:
            # If get_help() fails, return empty
            pass
        return ''

    def _list_adapters(self) -> List[Dict[str, Any]]:
        """List all registered adapters with basic info."""
        adapters = []
        for scheme, adapter_class in _ADAPTER_REGISTRY.items():
            if scheme in self._INTERNAL_ADAPTERS:
                continue
            has_help = (
                hasattr(adapter_class, 'get_help') and
                callable(getattr(adapter_class, 'get_help'))
            )

            info = {
                'scheme': scheme,
                'class': adapter_class.__name__,
                'has_help': has_help
            }

            # Add description if available
            if has_help:
                info['description'] = self._get_adapter_description(adapter_class)

            adapters.append(info)

        return sorted(adapters, key=lambda x: x['scheme'])

    def _get_file_analyzer_help(self, topic: str) -> Optional[Dict[str, Any]]:
        """Return inline help for file-based analyzers (not URI adapters).

        These are not in _ADAPTER_REGISTRY but users sometimes try `reveal help://nginx`
        thinking it's a URI scheme. Return focused usage help rather than "not found".
        """
        FILE_ANALYZERS: Dict[str, Dict[str, Any]] = {
            'nginx': {
                'name': 'nginx',
                'type': 'file_analyzer',
                'description': 'nginx is a file-based analyzer — pass a config file path directly',
                'note': (
                    'nginx is a file-based analyzer — pass config file paths directly. '
                    'The nginx:// URI scheme is not yet implemented.'
                ),
                'examples': [
                    {'uri': 'reveal /etc/nginx/nginx.conf', 'description': 'See all server blocks'},
                    {'uri': 'reveal /etc/nginx/nginx.conf --check', 'description': 'Run N001-N007 rules'},
                    {'uri': 'reveal /etc/nginx/conf.d/example.com.conf --check', 'description': 'Check a single vhost'},
                ],
                'cli_flags': [
                    '--check                      # Run N001-N007 nginx quality rules',
                    '--diagnose                   # Audit nginx error log for ACME/SSL failures',
                    '--check-acl                  # Verify nginx ACL configuration',
                    '--validate-nginx-acme        # Validate ACME challenge paths',
                    '--check-conflicts            # Detect conflicting server_name directives',
                    '--log-path PATH              # Override error log path for --diagnose',
                    '--dns-verified               # Skip DNS check (use when DNS is verified)',
                    '--extract domains|certs|...  # Extract specific elements (domains, certs, paths)',
                ],
                'see_also': [
                    'reveal help://ssl - SSL certificate inspection',
                    'reveal help://cpanel - cPanel user environment adapter',
                ],
            },
        }
        return FILE_ANALYZERS.get(topic)

    def _get_adapter_help(self, scheme: str) -> Optional[Dict[str, Any]]:
        """Get help for a specific adapter.

        Args:
            scheme: Adapter scheme name

        Returns:
            Help dict or None if adapter has no help
        """
        adapter_class: Optional[type[Any]] = _ADAPTER_REGISTRY.get(scheme)
        if not adapter_class:
            return None

        if not hasattr(adapter_class, 'get_help'):
            return {
                'scheme': scheme,
                'error': 'No help available',
                'message': (
                    f'{adapter_class.__name__} does not provide '
                    f'help documentation'
                )
            }

        try:
            help_data = adapter_class.get_help()
            if help_data:
                help_data['scheme'] = scheme  # Ensure scheme is included
            return help_data  # type: ignore[no-any-return]
        except Exception as e:
            return {
                'scheme': scheme,
                'error': 'Help generation failed',
                'message': str(e)
            }

    def _get_quick_help(self) -> Dict[str, Any]:
        """Return a concise orientation cheat-sheet (help://quick)."""
        return {
            'type': 'help_quick',
            'title': 'Reveal — Quick Reference',
            'commands': [
                {
                    'cmd': 'reveal <file.py>',
                    'description': 'Outline a Python/JS/Go/etc. file — functions, classes, imports',
                },
                {
                    'cmd': 'reveal <dir/>',
                    'description': 'Directory tree with file sizes and types',
                },
                {
                    'cmd': 'reveal ssl://DOMAIN --check',
                    'description': 'TLS cert health check — expiry, chain, algo (exit 1/2 on issues)',
                },
                {
                    'cmd': 'reveal domain://DOMAIN',
                    'description': 'DNS + WHOIS + HTTP redirect + email DNS in one pass',
                },
                {
                    'cmd': 'reveal nginx://DOMAIN',
                    'description': 'nginx vhost summary — SSL, ports, upstreams, ACL',
                },
                {
                    'cmd': 'reveal cpanel://USER/ssl --only-failures',
                    'description': 'Disk cert status for all domains on a cPanel user (failures only)',
                },
                {
                    'cmd': 'reveal <file.py> --check',
                    'description': 'Static quality rules — complexity, unused imports, long functions',
                },
                {
                    'cmd': 'reveal <file.py> --pattern',
                    'description': 'Pattern detection rules — security, anti-patterns, code smells',
                },
                {
                    'cmd': 'find src/ -name "*.py" | reveal --stdin --check',
                    'description': 'Batch check all Python files via stdin pipeline',
                },
                {
                    'cmd': 'reveal help://adapters',
                    'description': 'List all 23 adapters with syntax and examples',
                },
            ],
            'decision_tree': [
                {'want': 'understand code structure (functions, classes, complexity)',
                 'use': 'ast://', 'example': "reveal ast://src/?complexity>10"},
                {'want': 'know who calls what / find dead code',
                 'use': 'calls://', 'example': "reveal 'calls://src/?target=my_fn'"},
                {'want': 'check import health / circular deps',
                 'use': 'imports://', 'example': "reveal imports://src/"},
                {'want': 'compare files or git revisions',
                 'use': 'diff://', 'example': "reveal diff://git://main/.:git://HEAD/."},
                {'want': 'SSL/TLS certificate status',
                 'use': 'ssl://', 'example': "reveal ssl://example.com --check"},
                {'want': 'full server audit (SSL + ACL + nginx)',
                 'use': 'cpanel://', 'example': "reveal cpanel://USER/full-audit"},
                {'want': 'nginx vhost config and health',
                 'use': 'nginx://', 'example': "reveal nginx://example.com"},
                {'want': 'domain DNS / WHOIS / email health',
                 'use': 'domain://', 'example': "reveal domain://example.com"},
                {'want': 'inspect a SQLite or MySQL database',
                 'use': 'sqlite:// / mysql://', 'example': "reveal sqlite:///path/to/app.db"},
                {'want': 'explore Claude session history',
                 'use': 'claude://', 'example': "reveal claude://session/<id>/workflow"},
            ],
            'next_steps': [
                'reveal help://adapters          # full adapter list',
                'reveal help://ast               # Python/JS/Go AST queries',
                'reveal help://ssl               # TLS cert adapter guide',
                'reveal help://examples/security # security query recipes',
                'reveal help://agent             # AI agent usage guide',
            ],
        }

    def _get_adapter_relationships(self) -> Dict[str, Any]:
        """Return the adapter ecosystem map (help://relationships)."""
        return {
            'type': 'help_relationships',
            'title': 'Reveal Adapter Ecosystem',
            'clusters': [
                {
                    'name': 'Code Analysis',
                    'adapters': ['ast', 'calls', 'diff', 'stats', 'imports', 'depends', 'git'],
                    'pairs': [
                        ('ast', 'calls', 'structure feeds call-graph queries'),
                        ('ast', 'diff', 'compare element complexity across versions'),
                        ('ast', 'stats', 'same code, different lens: quality metrics'),
                        ('ast', 'imports', 'structure + dependency graph'),
                        ('calls', 'diff', 'impact analysis: who calls what changed'),
                        ('imports', 'depends', 'forward imports + reverse dependency graph'),
                        ('stats', 'git', 'quality score over commit history'),
                        ('git', 'diff', 'git history drives structural diff views'),
                    ],
                },
                {
                    'name': 'Infrastructure',
                    'adapters': ['nginx', 'ssl', 'letsencrypt', 'domain', 'cpanel', 'autossl'],
                    'pairs': [
                        ('nginx', 'ssl', 'validate certs referenced in nginx configs'),
                        ('nginx', 'domain', 'DNS health for domains in nginx configs'),
                        ('ssl', 'domain', 'cert chain + DNS/WHOIS in one pass'),
                        ('ssl', 'letsencrypt', 'on-disk cert details for Let\'s Encrypt live certs'),
                        ('cpanel', 'ssl', 'per-user cert inventory and health'),
                        ('cpanel', 'autossl', 'AutoSSL run logs for cPanel users'),
                        ('cpanel', 'nginx', 'nginx vhost config for this cPanel user'),
                        ('letsencrypt', 'nginx', 'cross-reference certbot certs with nginx vhosts'),
                    ],
                },
                {
                    'name': 'Data & Config',
                    'adapters': ['sqlite', 'mysql', 'json', 'env', 'xlsx'],
                    'pairs': [
                        ('sqlite', 'mysql', 'same query API, two database backends'),
                        ('json', 'sqlite', 'inspect app state: exported JSON or live DB'),
                        ('env', 'python', 'runtime environment + live module introspection'),
                        ('xlsx', 'sqlite', 'tabular data inspection across formats'),
                        ('xlsx', 'json', 'structured data: Excel vs JSON'),
                    ],
                },
                {
                    'name': 'Sessions & Docs',
                    'adapters': ['claude', 'git', 'markdown'],
                    'pairs': [
                        ('claude', 'git', 'cross-reference session work with code changes'),
                        ('claude', 'markdown', 'session docs and knowledge base'),
                        ('markdown', 'git', 'doc history and authorship'),
                    ],
                },
                {
                    'name': 'Self-Describing',
                    'adapters': ['help', 'reveal', 'python', 'ast'],
                    'pairs': [
                        ('help', 'reveal', 'help:// documents it; reveal:// introspects it'),
                        ('reveal', 'ast', 'reveal uses ast:// to analyze itself'),
                        ('python', 'ast', 'runtime introspection vs static analysis'),
                    ],
                },
            ],
            'power_pairs': [
                {
                    'adapters': ['ast', 'calls'],
                    'description': 'Core code understanding: structure + relationships',
                    'example': "reveal src/auth.py  &&  reveal 'calls://src/?target=validate_token'",
                },
                {
                    'adapters': ['diff', 'stats'],
                    'description': 'PR review: what changed + quality impact',
                    'example': "reveal pack src/ --since main --content  &&  reveal 'ast://src/?complexity>10'",
                },
                {
                    'adapters': ['nginx', 'ssl'],
                    'description': 'Infrastructure audit: config + cert validation',
                    'example': "reveal nginx://example.com  &&  reveal ssl://example.com --check",
                },
                {
                    'adapters': ['sqlite', 'mysql'],
                    'description': 'Portable DB inspection: same syntax, two backends',
                    'example': "reveal sqlite:///dev.db/users  →  reveal mysql://prod/users",
                },
                {
                    'adapters': ['claude', 'git'],
                    'description': 'Session archaeology: history + code changes',
                    'example': "reveal 'claude://sessions/?search=auth'  &&  reveal 'git://src/?message~=auth'",
                },
            ],
        }

    # Internal/scaffold adapters excluded from public listings
    _INTERNAL_ADAPTERS = {'demo', 'test'}

    def _get_all_adapter_help(self) -> Dict[str, Any]:
        """Get help for all adapters."""
        public_schemes = [s for s in _ADAPTER_REGISTRY.keys() if s not in self._INTERNAL_ADAPTERS]
        all_help: Dict[str, Any] = {
            'type': 'adapter_summary',
            'count': len(public_schemes),
            'adapters': {}
        }

        for scheme in public_schemes:
            help_data = self._get_adapter_help(scheme)
            if help_data and 'error' not in help_data:
                example = ''
                if help_data.get('examples'):
                    example = help_data.get('examples', [{}])[0].get('uri', '')

                all_help['adapters'][scheme] = {
                    'description': help_data.get('description', ''),
                    'syntax': help_data.get('syntax', ''),
                    'example': example
                }

        return all_help

    def _load_static_help(self, topic: str) -> Optional[Dict[str, Any]]:
        """Load help from static markdown file.

        Args:
            topic: Topic name ('agent', 'quick-start', 'tricks', etc.)

        Returns:
            Help content dict or None if file not found
        """
        filename = self.help_topics.get(topic)
        if not filename:
            return None

        # Help files are in reveal/docs/ directory
        help_path = Path(__file__).parent.parent / 'docs' / filename

        try:
            with open(help_path, 'r', encoding='utf-8') as f:
                content = f.read()

            return {
                'type': 'static_guide',
                'topic': topic,
                'file': filename,
                'content': content
            }
        except FileNotFoundError:
            return {
                'type': 'static_guide',
                'topic': topic,
                'error': 'File not found',
                'message': f'Could not find {filename}'
            }
        except Exception as e:
            return {
                'type': 'static_guide',
                'topic': topic,
                'error': 'Load failed',
                'message': str(e)
            }

    def _get_adapter_schema(self, adapter_name: str) -> Optional[Dict[str, Any]]:
        """Get machine-readable schema for an adapter.

        Args:
            adapter_name: Adapter scheme name (e.g., 'ssl', 'ast')

        Returns:
            Schema dict or error dict if adapter not found or has no schema
        """
        adapter_class: Optional[type[Any]] = _ADAPTER_REGISTRY.get(adapter_name)
        if not adapter_class:
            available = sorted(_ADAPTER_REGISTRY.keys())
            return {
                'type': 'adapter_schema',
                'adapter': adapter_name,
                'error': 'Unknown adapter',
                'message': f"No adapter named '{adapter_name}'. Available: {', '.join(available)}",
                'available_adapters': available,
            }

        if not hasattr(adapter_class, 'get_schema'):
            return {
                'type': 'adapter_schema',
                'adapter': adapter_name,
                'error': 'No schema available',
                'message': (
                    f'{adapter_class.__name__} does not provide '
                    f'machine-readable schema'
                )
            }

        try:
            schema_data = adapter_class.get_schema()
            if not schema_data:
                # Adapter has get_schema() but returns None (e.g., help:// meta-adapter)
                return {
                    'type': 'adapter_schema',
                    'adapter': adapter_name,
                    'error': 'No schema available',
                    'message': (
                        f'{adapter_class.__name__} does not provide a machine-readable schema. '
                        f'This is expected for meta-adapters like help://'
                    )
                }
            schema_data['adapter'] = adapter_name  # Ensure adapter is included
            schema_data['type'] = 'adapter_schema'
            return schema_data  # type: ignore[no-any-return]
        except Exception as e:
            return {
                'type': 'adapter_schema',
                'adapter': adapter_name,
                'error': 'Schema generation failed',
                'message': str(e)
            }

    def _get_example_recipes(self, task_name: str) -> Optional[Dict[str, Any]]:
        """Get canonical query recipes for a specific task."""
        if task_name not in _EXAMPLE_RECIPES:
            available = ', '.join(sorted(_EXAMPLE_RECIPES.keys()))
            error_msg = f"Specify a task. Available: {available}" if not task_name else f"Unknown task '{task_name}'. Available: {available}"
            return {
                'type': 'query_recipes',
                'task': task_name,
                'error': 'Unknown task' if task_name else 'No task specified',
                'message': error_msg,
                'available_tasks': list(_EXAMPLE_RECIPES.keys())
            }
        return _EXAMPLE_RECIPES[task_name]
