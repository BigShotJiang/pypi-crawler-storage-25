import pytest
import respx
import httpx

BASE_URL = "http://test-agent-bundle"


@pytest.fixture
def mock_transport():
    with respx.MockRouter(base_url=BASE_URL, assert_all_called=False) as router:
        yield router


@pytest.fixture
def sync_client(mock_transport):
    from ff_sdk import RemoteAgentBundleClient
    client = RemoteAgentBundleClient(base_url=BASE_URL, api_key="test-key")
    yield client
    client.close()


@pytest.fixture
async def async_client(mock_transport):
    from ff_sdk import AsyncRemoteAgentBundleClient
    client = AsyncRemoteAgentBundleClient(base_url=BASE_URL, api_key="test-key")
    yield client
    await client.close()
