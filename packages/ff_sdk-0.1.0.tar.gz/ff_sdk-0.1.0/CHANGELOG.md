# Changelog

## 0.1.0 (2024-01-01)

- Initial release: Python client SDK for FireFoundry Agent Bundle services
- `RemoteAgentBundleClient` (sync) and `AsyncRemoteAgentBundleClient` (async)
- Entity method invocation with JSON, binary, and multipart blob support
- Iterator/streaming support via `IteratorProxy` and `AsyncIteratorProxy`
- `EntityProxy` for ergonomic `__getattr__`-based method dispatch
- Bot invocation helpers (`run_bot`, `start_bot`)
- Custom API endpoint routing (`call_api_endpoint`)
- Correlation ID propagation via `contextvars`
