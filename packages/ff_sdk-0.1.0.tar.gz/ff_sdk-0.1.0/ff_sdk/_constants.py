CORRELATION_ID_HEADER = "X-FireFoundry-Correlation-ID"
SOURCE_APP_ID_HEADER = "X-FireFoundry-Source-App-ID"
MOCK_CACHE_HEADER = "X-FireFoundry-Mock-Cache"
