from __future__ import annotations

import base64
import logging
from typing import Any, Literal, overload

import httpx

from ._constants import CORRELATION_ID_HEADER, MOCK_CACHE_HEADER, SOURCE_APP_ID_HEADER
from ._context import get_mock_cache, get_or_generate_correlation_id, get_source_app_id
from ._errors import FFError
from ._iterator import AsyncIteratorProxy

logger = logging.getLogger("ff_sdk")

_DEFAULT_TIMEOUT = 200.0


class AsyncRemoteAgentBundleClient:
    """Async HTTP client for invoking methods on a remote Agent Bundle service."""

    def __init__(
        self,
        base_url: str,
        api_key: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT,
        is_external: bool = False,
    ) -> None:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if api_key:
            prefix = "" if is_external else "Bearer "
            headers["Authorization"] = f"{prefix}{api_key}"

        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            headers=headers,
        )

    async def __aenter__(self) -> "AsyncRemoteAgentBundleClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self._client.aclose()

    async def close(self) -> None:
        await self._client.aclose()

    def _correlation_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {
            CORRELATION_ID_HEADER: get_or_generate_correlation_id(),
        }
        source_app_id = get_source_app_id()
        if source_app_id:
            headers[SOURCE_APP_ID_HEADER] = source_app_id
        mock_cache = get_mock_cache()
        if mock_cache:
            headers[MOCK_CACHE_HEADER] = mock_cache
        return headers

    def _decode_result(self, data: dict[str, Any]) -> Any:
        if data.get("result_type") == "Buffer":
            return base64.b64decode(data["result"])
        return data.get("result")

    async def _post_json(self, path: str, body: Any) -> dict[str, Any]:
        try:
            response = await self._client.post(
                path, json=body, headers=self._correlation_headers()
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

    # ------------------------------------------------------------------ #
    # Entity invocation
    # ------------------------------------------------------------------ #

    async def invoke_entity_method(
        self, entity_id: str, method_name: str, *args: Any
    ) -> Any:
        data = await self._post_json(
            "/invoke", {"entity_id": entity_id, "method_name": method_name, "args": list(args)}
        )
        if not data.get("success"):
            raise FFError(data.get("error") or "Remote invocation failed")
        return self._decode_result(data)

    async def invoke_entity_method_with_blobs(
        self,
        entity_id: str,
        method_name: str,
        args: list[Any],
        files: list[bytes],
    ) -> Any:
        try:
            multipart: list[Any] = [
                ("payload", (None, _json_bytes({"entity_id": entity_id, "method_name": method_name, "args": args}), "application/json")),
            ]
            for i, file_bytes in enumerate(files):
                multipart.append((f"file{i}", (f"file{i}", file_bytes, "application/octet-stream")))

            response = await self._client.post(
                "/invoke/multipart",
                files=multipart,  # type: ignore[arg-type]
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

        if not data.get("success"):
            raise FFError(data.get("error") or "Remote multipart invocation failed")
        return self._decode_result(data)

    async def invoke_entity_method_binary(
        self, entity_id: str, method_name: str, *args: Any
    ) -> bytes:
        try:
            response = await self._client.post(
                "/invoke/binary",
                json={"entity_id": entity_id, "method_name": method_name, "args": list(args)},
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            return response.content
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

    async def invoke_entity_method_binary_with_blobs(
        self,
        entity_id: str,
        method_name: str,
        args: list[Any],
        files: list[bytes],
    ) -> bytes:
        try:
            multipart: list[Any] = [
                ("payload", (None, _json_bytes({"entity_id": entity_id, "method_name": method_name, "args": args}), "application/json")),
            ]
            for i, file_bytes in enumerate(files):
                multipart.append((f"file{i}", (f"file{i}", file_bytes, "application/octet-stream")))

            response = await self._client.post(
                "/invoke/binary/multipart",
                files=multipart,  # type: ignore[arg-type]
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            return response.content
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

    @overload
    async def invoke(
        self,
        entity_id: str,
        method_name: str,
        *,
        args: list[Any] | None = ...,
        files: list[bytes] | None = ...,
        response_type: Literal["binary"],
    ) -> bytes: ...

    @overload
    async def invoke(
        self,
        entity_id: str,
        method_name: str,
        *,
        args: list[Any] | None = ...,
        files: list[bytes] | None = ...,
        response_type: Literal["iterator"],
    ) -> AsyncIteratorProxy[Any]: ...

    @overload
    async def invoke(
        self,
        entity_id: str,
        method_name: str,
        *,
        args: list[Any] | None = ...,
        files: list[bytes] | None = ...,
        response_type: Literal["result"] | None = ...,
    ) -> Any: ...

    async def invoke(
        self,
        entity_id: str,
        method_name: str,
        *,
        args: list[Any] | None = None,
        files: list[bytes] | None = None,
        response_type: Literal["result", "binary", "iterator"] | None = None,
    ) -> Any:
        _args = args or []
        has_blobs = bool(files)
        _type = response_type or "result"

        if has_blobs and not _args:
            raise FFError("args required when using files")

        if _type == "binary":
            if has_blobs:
                return await self.invoke_entity_method_binary_with_blobs(entity_id, method_name, _args, files)  # type: ignore[arg-type]
            return await self.invoke_entity_method_binary(entity_id, method_name, *_args)

        if _type == "iterator":
            if has_blobs:
                return await self.start_iterator_with_blobs(entity_id, method_name, _args, files)  # type: ignore[arg-type]
            return await self.start_iterator(entity_id, method_name, *_args)

        if has_blobs:
            return await self.invoke_entity_method_with_blobs(entity_id, method_name, _args, files)  # type: ignore[arg-type]
        return await self.invoke_entity_method(entity_id, method_name, *_args)

    # ------------------------------------------------------------------ #
    # Iterator / streaming
    # ------------------------------------------------------------------ #

    async def start_iterator(
        self, entity_id: str, method_name: str = "start", *args: Any
    ) -> AsyncIteratorProxy[Any]:
        data = await self._post_json(
            "/iterator/start",
            {"entity_id": entity_id, "method_name": method_name, "args": list(args)},
        )
        if not data.get("success"):
            raise FFError(data.get("error") or "Failed to start iterator")
        return AsyncIteratorProxy(data["iterator_id"], self)

    async def start_iterator_with_blobs(
        self,
        entity_id: str,
        method_name: str = "start",
        args: list[Any] | None = None,
        files: list[bytes] | None = None,
    ) -> AsyncIteratorProxy[Any]:
        try:
            multipart: list[Any] = [
                ("payload", (None, _json_bytes({"entity_id": entity_id, "method_name": method_name, "args": args or []}), "application/json")),
            ]
            for i, file_bytes in enumerate(files or []):
                multipart.append((f"file{i}", (f"file{i}", file_bytes, "application/octet-stream")))

            response = await self._client.post(
                "/iterator/start/multipart",
                files=multipart,  # type: ignore[arg-type]
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            data = response.json()
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

        if not data.get("success"):
            raise FFError(data.get("error") or "Failed to start iterator with blobs")
        return AsyncIteratorProxy(data["iterator_id"], self)

    async def next_iterator(self, iterator_id: str) -> dict[str, Any]:
        try:
            response = await self._client.post(
                f"/iterators/{iterator_id}/next",
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

    async def cleanup_iterator(self, iterator_id: str) -> bool:
        try:
            response = await self._client.delete(
                f"/iterators/{iterator_id}",
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            return response.json().get("success", True)
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

    # ------------------------------------------------------------------ #
    # Bot invocation
    # ------------------------------------------------------------------ #

    async def run_bot(self, bot_name: str, request: Any) -> Any:
        data = await self._post_json(f"/bot/{bot_name}/run", request)
        if not data.get("success"):
            raise FFError(data.get("error") or "Bot run failed")
        return self._decode_result(data)

    async def start_bot(self, bot_name: str, request: Any) -> AsyncIteratorProxy[Any]:
        data = await self._post_json(f"/bot/{bot_name}/start", request)
        if not data.get("success"):
            raise FFError(data.get("error") or "Bot start failed")
        return AsyncIteratorProxy(data["iterator_id"], self)

    # ------------------------------------------------------------------ #
    # Custom API endpoints
    # ------------------------------------------------------------------ #

    async def call_api_endpoint(
        self,
        route: str,
        *,
        params: dict[str, Any] | None = None,
        body: Any = None,
        method: Literal["GET", "POST", "PUT", "PATCH", "DELETE"] = "GET",
    ) -> Any:
        try:
            response = await self._client.request(
                method,
                f"/api/{route}",
                params=params,
                json=body,
                headers=self._correlation_headers(),
            )
            response.raise_for_status()
            data = response.json()
            return data.get("result", data)
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc

    # ------------------------------------------------------------------ #
    # Health / info
    # ------------------------------------------------------------------ #

    async def health_check(self) -> bool:
        try:
            response = await self._client.get("/health")
            response.raise_for_status()
            return response.json().get("healthy") is True
        except Exception:
            return False

    async def is_ready(self) -> bool:
        try:
            response = await self._client.get("/ready")
            response.raise_for_status()
            return response.json().get("ready") is True
        except Exception:
            return False

    async def get_info(self) -> dict[str, Any]:
        try:
            response = await self._client.get("/info")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPError as exc:
            raise FFError(str(exc)) from exc


def _json_bytes(obj: Any) -> bytes:
    import json
    return json.dumps(obj).encode()
