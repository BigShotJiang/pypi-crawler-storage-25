from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Generic, Iterator, Protocol, TypeVar

from ._errors import FFError

T = TypeVar("T")
logger = logging.getLogger("ff_sdk")


class IteratorClientProtocol(Protocol):
    def next_iterator(self, iterator_id: str) -> dict[str, Any]: ...
    def cleanup_iterator(self, iterator_id: str) -> bool: ...


class AsyncIteratorClientProtocol(Protocol):
    async def next_iterator(self, iterator_id: str) -> dict[str, Any]: ...
    async def cleanup_iterator(self, iterator_id: str) -> bool: ...


class AsyncIteratorProxy(Generic[T]):
    """Async-iterator facade over a server-managed iterator session."""

    def __init__(self, iterator_id: str, client: AsyncIteratorClientProtocol) -> None:
        self._iterator_id = iterator_id
        self._client = client
        self._is_done = False
        self._is_cleaned_up = False

    def __aiter__(self) -> AsyncIterator[T]:
        return self  # type: ignore[return-value]

    async def __anext__(self) -> T:
        if self._is_done:
            raise StopAsyncIteration
        if self._is_cleaned_up:
            raise FFError("Iterator has been cleaned up")

        try:
            logger.debug("[AsyncIteratorProxy] next %s", self._iterator_id)
            result = await self._client.next_iterator(self._iterator_id)

            if result.get("done"):
                self._is_done = True
                self._is_cleaned_up = True
                raise StopAsyncIteration

            return result.get("value")  # type: ignore[return-value]
        except (StopAsyncIteration, FFError):
            raise
        except Exception as exc:
            self._is_done = True
            self._is_cleaned_up = True
            raise FFError(exc) from exc

    async def cleanup(self) -> bool:
        if self._is_cleaned_up:
            return False
        try:
            logger.debug("[AsyncIteratorProxy] cleanup %s", self._iterator_id)
            result = await self._client.cleanup_iterator(self._iterator_id)
            self._is_cleaned_up = True
            self._is_done = True
            return result
        except Exception as exc:
            logger.warning("[AsyncIteratorProxy] cleanup failed %s: %s", self._iterator_id, exc)
            self._is_cleaned_up = True
            self._is_done = True
            return False

    @property
    def iterator_id(self) -> str:
        return self._iterator_id

    @property
    def is_done(self) -> bool:
        return self._is_done

    @property
    def is_cleaned_up(self) -> bool:
        return self._is_cleaned_up


class IteratorProxy(Generic[T]):
    """Sync iterator facade over a server-managed iterator session."""

    def __init__(self, iterator_id: str, client: IteratorClientProtocol) -> None:
        self._iterator_id = iterator_id
        self._client = client
        self._is_done = False
        self._is_cleaned_up = False

    def __iter__(self) -> Iterator[T]:
        return self  # type: ignore[return-value]

    def __next__(self) -> T:
        if self._is_done:
            raise StopIteration
        if self._is_cleaned_up:
            raise FFError("Iterator has been cleaned up")

        try:
            logger.debug("[IteratorProxy] next %s", self._iterator_id)
            result = self._client.next_iterator(self._iterator_id)

            if result.get("done"):
                self._is_done = True
                self._is_cleaned_up = True
                raise StopIteration

            return result.get("value")  # type: ignore[return-value]
        except (StopIteration, FFError):
            raise
        except Exception as exc:
            self._is_done = True
            self._is_cleaned_up = True
            raise FFError(exc) from exc

    def cleanup(self) -> bool:
        if self._is_cleaned_up:
            return False
        try:
            logger.debug("[IteratorProxy] cleanup %s", self._iterator_id)
            result = self._client.cleanup_iterator(self._iterator_id)
            self._is_cleaned_up = True
            self._is_done = True
            return result
        except Exception as exc:
            logger.warning("[IteratorProxy] cleanup failed %s: %s", self._iterator_id, exc)
            self._is_cleaned_up = True
            self._is_done = True
            return False

    @property
    def iterator_id(self) -> str:
        return self._iterator_id

    @property
    def is_done(self) -> bool:
        return self._is_done

    @property
    def is_cleaned_up(self) -> bool:
        return self._is_cleaned_up
