class FFError(Exception):
    def __init__(self, message: str | Exception, cause: BaseException | None = None) -> None:
        if isinstance(message, Exception):
            cause = message
            message = str(message)
        super().__init__(message)
        self.__cause__ = cause
