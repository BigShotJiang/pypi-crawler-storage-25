from __future__ import annotations

from typing import Any, Callable


_PROXY_SKIP = frozenset({"then", "catch", "finally", "toJSON", "__class__", "__repr__", "__str__"})


class EntityProxy:
    """
    Maps attribute access to remote entity method calls.

    Example::

        proxy = EntityProxy(entity_id="uuid", client=client)
        result = proxy.generate_report({"format": "pdf"})
        # equivalent to: client.invoke_entity_method("uuid", "generate_report", {"format": "pdf"})
    """

    def __init__(self, entity_id: str, client: Any) -> None:
        object.__setattr__(self, "_entity_id", entity_id)
        object.__setattr__(self, "_client", client)

    def __getattr__(self, method_name: str) -> Callable[..., Any]:
        if method_name in _PROXY_SKIP:
            raise AttributeError(method_name)

        entity_id = object.__getattribute__(self, "_entity_id")
        client = object.__getattribute__(self, "_client")

        def dispatch(*args: Any) -> Any:
            return client.invoke_entity_method(entity_id, method_name, *args)

        return dispatch


class AsyncEntityProxy:
    """Async variant — each attribute returns a coroutine callable."""

    def __init__(self, entity_id: str, client: Any) -> None:
        object.__setattr__(self, "_entity_id", entity_id)
        object.__setattr__(self, "_client", client)

    def __getattr__(self, method_name: str) -> Callable[..., Any]:
        if method_name in _PROXY_SKIP:
            raise AttributeError(method_name)

        entity_id = object.__getattribute__(self, "_entity_id")
        client = object.__getattribute__(self, "_client")

        async def dispatch(*args: Any) -> Any:
            return await client.invoke_entity_method(entity_id, method_name, *args)

        return dispatch
