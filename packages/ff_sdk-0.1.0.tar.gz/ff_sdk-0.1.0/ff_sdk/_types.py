from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable


@dataclass
class BlobPlaceholder:
    """Marks a position in an args list where a binary file will be substituted."""
    blob: int

    def to_dict(self) -> dict[str, int]:
        return {"$blob": self.blob}


@runtime_checkable
class AgentBundleClientProtocol(Protocol):
    def invoke_entity_method(self, entity_id: str, method_name: str, *args: Any) -> Any: ...
