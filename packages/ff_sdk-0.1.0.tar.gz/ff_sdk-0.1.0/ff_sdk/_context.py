from __future__ import annotations

import uuid
from contextvars import ContextVar

_correlation_id_var: ContextVar[str | None] = ContextVar("ff_correlation_id", default=None)
_source_app_id_var: ContextVar[str | None] = ContextVar("ff_source_app_id", default=None)
_mock_cache_var: ContextVar[str | None] = ContextVar("ff_mock_cache", default=None)


def get_or_generate_correlation_id() -> str:
    existing = _correlation_id_var.get()
    if existing:
        return existing
    return str(uuid.uuid4())


def get_source_app_id() -> str | None:
    return _source_app_id_var.get()


def get_mock_cache() -> str | None:
    return _mock_cache_var.get()


def set_correlation_id(value: str) -> None:
    _correlation_id_var.set(value)


def set_source_app_id(value: str) -> None:
    _source_app_id_var.set(value)


def set_mock_cache(value: str) -> None:
    _mock_cache_var.set(value)
