from typing import Optional

from .mysql import MySQLDatabase
from .postgres import PostgreSQLDatabase
from athena.config import Config


def _normalize_section(section: Optional[str]) -> str:
    if section is None or section == "":
        return "business/default"
    if section.startswith("business/"):
        return section
    if "/" not in section:
        return "business/" + section
    return section


async def get_database(section: Optional[str] = None):
    config = Config("athena-db.conf")
    normalized = _normalize_section(section)
    db_cfg = config.get_value(normalized)
    if db_cfg is None:
        raise ValueError(f"Database section not found: {normalized}")

    vendor = db_cfg.get("vendor", "").lower()
    host = db_cfg.get("hosts", ["localhost"])[0]
    port = db_cfg.get("port", 5432 if vendor == "postgresql" else 3306)
    user = db_cfg.get("username")
    password = db_cfg.get("password")
    database = db_cfg.get("database")

    if vendor in ["mysql", "mariadb"]:
        db = MySQLDatabase(
            host=host,
            port=port,
            user=user,
            password=password,
            db=database,
            autocommit=True
        )
    elif vendor == "postgresql":
        db = PostgreSQLDatabase(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database
        )
    else:
        raise ValueError(f"Unsupported async DB vendor: {vendor!r} (section={normalized})")

    await db.connect()
    return db
