import pytest
import os
import sys
from io import StringIO
from unittest.mock import patch

# 実行時にパスを追加して、スクリプト直接実行でも動作するようにする
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_main_no_output_messages(tmp_path, capsys):
    """Unixスタイル準拠：開始・終了メッセージが出力されないことを確認"""
    from pdf_size_splitter import main
    
    # Given: テスト用のPDFと出力ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    output_dir = str(tmp_path)
    max_size = 10000
    
    # When: main関数を実行（コマンドライン引数をモック）
    with patch('sys.argv', ['pdf_size_splitter.py', input_pdf, str(max_size), '-o', output_dir]):
        main()
    
    # Then: 標準出力に開始・終了メッセージが出力されていないこと
    captured = capsys.readouterr()
    assert "分割処理を開始します" not in captured.out
    assert "分割が完了しました" not in captured.out
