# Changelog

All notable changes to the `zil-ai` package will be documented in this file.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project uses [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.4] — 2026-05-05

### Added

- **`zil eval` command group** — refactored from a single command into four subcommands: `run`, `add`, `record`, and `generate`.
- **`zil eval add`** — interactively create eval cases by chatting with the agent; cases are saved to YAML and auto-registered in the suite.
- **`zil eval record`** — record a full chat session with the agent and convert selected turns into eval cases, with auto-detected keywords.
- **`zil eval generate`** — use the judge LLM to synthesize eval cases from agent identity files (persona, instructions, guardrails). Supports `--count`, `--category`, and `--no-review`.
- **Per-metric thresholds** — `metric_thresholds` in `evals/config.yaml` lets you set custom pass thresholds per DeepEval metric.
- **Execution controls** — `execution.concurrency`, `execution.retries`, and `execution.timeout` in `evals/config.yaml` for parallel eval runs and retry logic.
- **Eval case writer** (`zil.sdk.eval.writer`) — programmatic API for appending cases to group files and auto-registering groups in suite YAML.
- **Eval case generator** (`zil.sdk.eval.generator`) — LLM-powered case synthesis with support for Gemini, OpenAI, and Anthropic judge providers.
- **Lazy judge model resolution** — the DeepEval adapter now defers judge model initialization until LLM metrics are actually needed, avoiding import errors for deterministic-only evals.
- 14 new tests for writer, config enhancements, generator parsing, and keyword extraction (46 eval tests total).

### Changed

- **`zil eval` is now a command group** — use `zil eval run` instead of `zil eval` to run suites (no backward compatibility needed; the command was unused).
- **DeepEval adapter** stores `_config` for lazy judge model creation; accepts `_metric_thresholds` from engine config.
- Eval runner uses `ThreadPoolExecutor` for concurrent case evaluation with configurable retries and timeout.
- Eval docs page expanded with full documentation for all subcommands and new config fields.
- CLI reference docs updated to reflect the eval command group structure.

## [0.1.3] — 2026-05-05

### Added

- **OpenTelemetry tracing integration** — `zil run --trace` exports spans to any OTLP-compatible backend (Jaeger, Cloud Trace, Datadog, etc.); `zil run --trace-console` prints spans to stderr for local development.
- **`setup_telemetry()` and `setup_console_telemetry()`** — new SDK functions for programmatic tracing control, exported from `zil.sdk`.
- **`enable_telemetry` parameter** on `zil.create_agent()` — automatically configures OTel tracing from `observability/config.yaml` (default: `True`).
- **Observability config loading** — `ProjectContext` now reads `observability/config.yaml` when referenced in the manifest.
- **`agent.txt`** — agent-friendly documentation at `getzil.dev/agent.txt` and `getzil.dev/docs/agent.txt`.
- `opentelemetry-exporter-otlp-proto-http>=1.20.0` added to `[adk]` optional extra.
- 10 new tests for telemetry setup and observability config loading.

### Changed

- **Observability config template** — uses standard `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` env var (replaces `OTEL_COLLECTOR_URL`), adds `resource_attributes` section.
- **`.env.example` template** — references `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` (commented out by default).
- **`--trace-console` runs in-process** — uses ADK's `run_cli` directly so the `ConsoleSpanExporter` is active during agent execution.
- Observability docs page fully rewritten with dev/prod guide, SDK integration, and CLI flags.
- CLI reference docs updated with `--trace` and `--trace-console` flags for `zil run` and `zil web`.

## [0.1.2] — 2026-05-04

### Added

- **`zil run` command** — runs the agent interactively by wrapping `adk run` with automatic module detection from `manifest.yaml`.
- **`zil web` command** — starts the ADK web UI for testing, wrapping `adk web` with configurable port.
- **Gemini (AI Studio) provider** — new default LLM provider using `GOOGLE_API_KEY`, with link to API key generation in `.env.example`.
- Gemini embedding adapter support (`text-embedding-004`).

### Changed

- **Project scaffold restructured** — `agent.py` now lives inside a Python package directory (`{module_name}/agent.py` with `__init__.py`) for ADK compatibility.
- **Default LLM provider** changed from `anthropic` to `gemini` for easier onboarding.
- `.env.example` moved into the agent module directory (ADK loads `.env` from there).
- Vertex AI `llm.yaml` template now includes `GOOGLE_CLOUD_PROJECT` and `GOOGLE_CLOUD_LOCATION` env var references.
- Dockerfile `CMD` updated to use `python -m {module_name}.agent`.
- README template updated with new project layout and `zil run`/`zil web` commands.

### Fixed

- **Agent naming error** — kebab-case manifest names (e.g., `qbo-bookkeeper`) are now automatically converted to snake_case (`qbo_bookkeeper`) for ADK's `LlmAgent`, fixing `pydantic ValidationError`.
- **`adk run` directory error** — agent code now lives in a proper Python package, fixing `Directory does not exist` errors.

## [0.1.1] — 2026-05-02

### Added

- **SDK layer** (`zil.create_agent()`) — reads `manifest.yaml`, identity files, and adapter config, then wires them into an ADK `LlmAgent` automatically.
- **Auto-install dependencies** — `zil init` now creates a `.venv` and installs `requirements.txt` after scaffolding.
- **Model resolution** — maps adapter config (Anthropic, OpenAI, Vertex) to ADK-compatible model strings via LiteLLM prefix convention.
- **Identity composition** — persona, instructions, and guardrails are merged into a single structured instruction for the LLM.
- 20 new SDK tests (`tests/test_sdk.py`).
- `[adk]` optional dependency extra in `pyproject.toml`.

### Changed

- `agent.py` template now uses `zil.create_agent(tools=[])` instead of a stub.
- `requirements.txt` template includes `zil-ai[adk]` instead of commented-out ADK.
- Sdist excludes `artifacts/`, `docs/`, `website/`, `.windsurf/` (85 MB → 17 KB).

### Fixed

- Lint cleanup across `commands/`, `templates/`, `schema/` (ruff UP037, E501, E402, F821).

## [0.1.0] — 2026-04-30

### Added

- Initial release.
- CLI with four commands: `zil init`, `zil validate`, `zil pack` (stub), `zil inspect` (stub).
- `zil init` scaffolds 18 files: manifest, identity, adapters, evals, observability, Dockerfile, CI pipeline, README.
- `zil validate` checks manifest schema + file structure.
- JSON Schema for Zil v1 manifest (`spec/v1/manifest.schema.json`).
- 15 CLI tests.

[0.1.4]: https://github.com/fluentdata-co/zil/compare/v0.1.3...v0.1.4
[0.1.3]: https://github.com/fluentdata-co/zil/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/fluentdata-co/zil/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/fluentdata-co/zil/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/fluentdata-co/zil/releases/tag/v0.1.0
