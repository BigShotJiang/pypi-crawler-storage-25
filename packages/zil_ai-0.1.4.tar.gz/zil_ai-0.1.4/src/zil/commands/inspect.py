"""zil inspect — inspect a .zil archive."""

from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command()
@click.argument("archive", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option(
    "--show",
    default=None,
    help="Print a specific component (e.g. manifest, identity, evals).",
)
@click.option("--json", "output_json", is_flag=True, help="Machine-readable JSON output.")
def inspect(archive: Path, show: str | None, output_json: bool) -> None:
    """Inspect a .zil archive without extracting it.

    Displays the manifest summary, signature status, SBOM overview,
    and component listing.
    """
    if not archive.name.endswith(".zil"):
        console.print(f"[red]Error:[/red] Expected a .zil archive, got '{archive.name}'")
        raise SystemExit(1)

    # TODO: implement archive reading
    console.print(f"[bold]Zil Package:[/bold] {archive.stem}")
    console.print("  [dim]Implementation pending — Phase 5[/dim]")
