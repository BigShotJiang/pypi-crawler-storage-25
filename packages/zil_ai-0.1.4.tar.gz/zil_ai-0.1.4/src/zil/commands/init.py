"""zil init — scaffold a new agent project."""

import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console

console = Console()


FRAMEWORKS = ["adk", "a2a-supervisor"]
LANGUAGES = ["python", "typescript"]
LLM_PROVIDERS = ["gemini", "anthropic", "openai", "vertex"]
EVAL_FRAMEWORKS = ["deepeval"]
DEPLOY_TARGETS = ["cloud-run", "bedrock", "foundry", "k8s"]


@click.command()
@click.argument("name")
@click.option(
    "--framework",
    type=click.Choice(FRAMEWORKS, case_sensitive=False),
    default=None,
    help="Agent framework (default: adk).",
)
@click.option(
    "--language",
    type=click.Choice(LANGUAGES, case_sensitive=False),
    default=None,
    help="Implementation language (default: python).",
)
@click.option(
    "--llm",
    "llm_provider",
    type=click.Choice(LLM_PROVIDERS, case_sensitive=False),
    default=None,
    help="LLM provider (default: anthropic).",
)
@click.option(
    "--target",
    "deploy_target",
    type=click.Choice(DEPLOY_TARGETS, case_sensitive=False),
    default=None,
    help="Deployment target (default: cloud-run).",
)
@click.option(
    "--eval-framework",
    type=click.Choice(EVAL_FRAMEWORKS, case_sensitive=False),
    default=None,
    help="Eval framework (default: deepeval).",
)
@click.option("--no-evals", is_flag=True, help="Skip eval suite scaffolding.")
@click.option("--no-otel", is_flag=True, help="Skip OpenTelemetry instrumentation.")
@click.option(
    "--non-interactive",
    is_flag=True,
    help="Use defaults for all prompts.",
)
def init(
    name: str,
    framework: str | None,
    language: str | None,
    llm_provider: str | None,
    eval_framework: str | None,
    deploy_target: str | None,
    no_evals: bool,
    no_otel: bool,
    non_interactive: bool,
) -> None:
    """Scaffold a new Zil agent project.

    Creates a working agent project with manifest, identity, adapters,
    eval suite, and deployment config.
    """
    project_dir = Path.cwd() / name

    if project_dir.exists():
        console.print(f"[red]Error:[/red] Directory '{name}' already exists.")
        raise SystemExit(1)

    # Resolve options — prompt interactively or use defaults
    framework = framework or _resolve("Framework", FRAMEWORKS, "adk", non_interactive)
    language = language or _resolve("Language", LANGUAGES, "python", non_interactive)
    llm_provider = llm_provider or _resolve(
        "LLM provider", LLM_PROVIDERS, "gemini", non_interactive
    )
    deploy_target = deploy_target or _resolve(
        "Deploy target", DEPLOY_TARGETS, "cloud-run", non_interactive
    )

    include_evals = not no_evals
    include_otel = not no_otel

    if include_evals:
        eval_framework = eval_framework or _resolve(
            "Eval framework", EVAL_FRAMEWORKS, "deepeval", non_interactive
        )
    else:
        eval_framework = eval_framework or "deepeval"

    config = InitConfig(
        name=name,
        framework=framework,
        language=language,
        llm_provider=llm_provider,
        eval_framework=eval_framework,
        deploy_target=deploy_target,
        include_evals=include_evals,
        include_otel=include_otel,
    )

    console.print()
    _scaffold(project_dir, config)
    console.print()

    _install_deps(project_dir, non_interactive)

    console.print()
    console.print("[green]Done![/green] Your agent is ready.")
    console.print(f"\n  cd {name}")
    console.print("  source .venv/bin/activate")
    console.print("  zil validate")
    console.print()


def _resolve(label: str, choices: list[str], default: str, non_interactive: bool) -> str:
    """Prompt the user or return the default."""
    if non_interactive:
        return default
    choice_str = " / ".join(
        f"[bold]{c}[/bold]" if c == default else c for c in choices
    )
    result = console.input(f"  ? {label} ({choice_str}): ").strip().lower()
    return result if result in choices else default


class InitConfig:
    """Holds resolved configuration for project scaffolding."""

    def __init__(
        self,
        name: str,
        framework: str,
        language: str,
        llm_provider: str,
        eval_framework: str,
        deploy_target: str,
        include_evals: bool,
        include_otel: bool,
    ) -> None:
        self.name = name
        self.framework = framework
        self.language = language
        self.llm_provider = llm_provider
        self.eval_framework = eval_framework
        self.deploy_target = deploy_target
        self.include_evals = include_evals
        self.include_otel = include_otel

    @property
    def module_name(self) -> str:
        """Agent name as a valid Python identifier (for ADK module dir)."""
        return self.name.replace("-", "_")


def _scaffold(project_dir: Path, config: InitConfig) -> None:
    """Create the project directory tree and write all template files."""
    from zil.templates import render_project

    render_project(project_dir, config)


def _install_deps(project_dir: Path, non_interactive: bool) -> None:
    """Create a venv and install requirements.txt."""
    requirements = project_dir / "requirements.txt"
    if not requirements.is_file():
        return

    if not non_interactive:
        answer = console.input(
            "  ? Install dependencies now? ([bold]yes[/bold] / no): "
        ).strip().lower()
        if answer in ("no", "n"):
            console.print("  Skipped. Run [bold]pip install -r requirements.txt[/bold] later.")
            return

    venv_dir = project_dir / ".venv"
    console.print("  Creating virtual environment...")
    subprocess.run(
        [sys.executable, "-m", "venv", str(venv_dir)],
        check=True,
        capture_output=True,
    )

    pip = venv_dir / "bin" / "pip"
    if not pip.exists():
        pip = venv_dir / "Scripts" / "pip.exe"  # Windows

    console.print("  Installing dependencies...")
    result = subprocess.run(
        [str(pip), "install", "-r", str(requirements), "--quiet"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        console.print("  [green]✓[/green] Dependencies installed.")
    else:
        console.print("  [yellow]⚠[/yellow] Dependency install failed. Run manually:")
        console.print(f"    cd {project_dir.name} && pip install -r requirements.txt")
        if result.stderr:
            console.print(f"    {result.stderr.strip()[:200]}")

