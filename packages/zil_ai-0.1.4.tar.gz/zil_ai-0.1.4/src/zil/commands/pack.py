"""zil pack — build a .zil archive."""

from pathlib import Path

import click
from rich.console import Console

console = Console()


@click.command()
@click.option(
    "--project-dir",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    default=".",
    help="Project directory to package (default: current directory).",
)
@click.option(
    "--output-dir",
    type=click.Path(file_okay=False, path_type=Path),
    default=None,
    help="Output directory for the .zil archive (default: dist/).",
)
@click.option("--skip-evals", is_flag=True, help="Skip eval suite (warns loudly).")
@click.option("--no-sign", is_flag=True, help="Skip cosign signing.")
def pack(
    project_dir: Path,
    output_dir: Path | None,
    skip_evals: bool,
    no_sign: bool,
) -> None:
    """Build a .zil archive from a Zil agent project.

    Validates the project, runs the eval suite, generates an SBOM,
    creates a signed tar.gz archive, and writes it to dist/.
    """
    if skip_evals:
        console.print("[bold yellow]⚠ --skip-evals: eval suite will NOT run. "
                       "Do not ship this archive to production.[/bold yellow]")

    console.print("→ Validating project...", end="  ")
    # TODO: call validate_project and bail on errors
    console.print("[green]✓[/green]")

    if not skip_evals:
        console.print("→ Running pre-flight evals...", end="  ")
        try:
            from zil.sdk.eval.runner import run_eval_suite

            result = run_eval_suite(project_dir)
            if result.passed:
                score_pct = f"{result.score * 100:.1f}%"
                console.print(f"[green]✓ {score_pct}[/green]")
            else:
                score_pct = f"{result.score * 100:.1f}%"
                threshold_pct = f"{result.threshold * 100:.1f}%"
                console.print(
                    f"[red]✗ {score_pct} (threshold: {threshold_pct})[/red]"
                )
                console.print(
                    "[red]Error:[/red] Eval suite failed. "
                    "Fix eval failures before packaging."
                )
                raise SystemExit(1)
        except FileNotFoundError:
            console.print("[yellow]⚠ no eval suite found, skipping[/yellow]")
        except ImportError as e:
            console.print(f"[yellow]⚠ {e}[/yellow]")

    console.print("→ Resolving dependencies...", end="  ")
    # TODO: dependency resolution
    console.print("[green]✓[/green]")

    console.print("→ Generating SBOM (CycloneDX)...", end="  ")
    # TODO: SBOM generation
    console.print("[green]✓[/green]")

    console.print("→ Building archive...", end="  ")
    # TODO: tar.gz creation
    console.print("[green]✓[/green]")

    if not no_sign:
        console.print("→ Signing with cosign...", end="  ")
        # TODO: cosign signing
        console.print("[green]✓[/green]")

    # TODO: compute real values
    out = output_dir or (project_dir / "dist")
    console.print(f"\n→ Wrote: {out}/<name>-<version>.zil")
