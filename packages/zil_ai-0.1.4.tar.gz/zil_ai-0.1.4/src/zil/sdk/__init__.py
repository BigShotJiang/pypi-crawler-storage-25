"""Zil SDK — read manifest + identity files and create a wired agent."""

from zil.sdk.agent import create_agent
from zil.sdk.telemetry import setup_console_telemetry, setup_telemetry

__all__ = ["create_agent", "setup_telemetry", "setup_console_telemetry"]
