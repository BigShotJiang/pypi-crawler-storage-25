"""Schema loading and project validation."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import jsonschema
import yaml

SCHEMA_PATH = Path(__file__).parent.parent / "spec" / "v1" / "manifest.schema.json"


@dataclass
class CheckResult:
    status: str  # "pass" | "fail" | "warn"
    message: str

    def to_dict(self) -> dict:
        return {"status": self.status, "message": self.message}


@dataclass
class ValidationResult:
    checks: list[CheckResult] = field(default_factory=list)

    @property
    def exit_code(self) -> int:
        statuses = {c.status for c in self.checks}
        if "fail" in statuses:
            return 1
        if "warn" in statuses:
            return 2
        return 0

    @property
    def error_count(self) -> int:
        return sum(1 for c in self.checks if c.status == "fail")

    @property
    def warning_count(self) -> int:
        return sum(1 for c in self.checks if c.status == "warn")

    def to_dict(self) -> dict:
        return {
            "valid": self.exit_code == 0,
            "exit_code": self.exit_code,
            "errors": self.error_count,
            "warnings": self.warning_count,
            "checks": [c.to_dict() for c in self.checks],
        }


def load_schema() -> dict:
    """Load the Zil manifest JSON Schema."""
    with open(SCHEMA_PATH) as f:
        return json.load(f)


def validate_project(project_dir: Path) -> ValidationResult:
    """Validate a Zil project directory against the manifest schema."""
    result = ValidationResult()

    manifest_path = project_dir / "manifest.yaml"
    if not manifest_path.exists():
        result.checks.append(CheckResult("fail", "manifest.yaml — not found"))
        return result

    # Parse manifest
    try:
        with open(manifest_path) as f:
            manifest = yaml.safe_load(f)
    except yaml.YAMLError as e:
        result.checks.append(CheckResult("fail", f"manifest.yaml — invalid YAML: {e}"))
        return result

    # Schema validation
    try:
        schema = load_schema()
        jsonschema.validate(instance=manifest, schema=schema)
        result.checks.append(CheckResult("pass", "manifest.yaml — schema valid"))
    except jsonschema.ValidationError as e:
        result.checks.append(CheckResult("fail", f"manifest.yaml — {e.message}"))
    except FileNotFoundError:
        result.checks.append(CheckResult("fail", "manifest.schema.json — schema file not found"))
        return result

    # File reference checks
    _check_identity(project_dir, manifest, result)
    _check_adapters(project_dir, manifest, result)
    _check_evals(project_dir, manifest, result)
    _check_observability(project_dir, manifest, result)

    return result


def _check_identity(project_dir: Path, manifest: dict, result: ValidationResult) -> None:
    """Check identity directory files exist."""
    spec = manifest.get("spec", {})
    identity_ref = spec.get("identity")
    if not identity_ref:
        return

    identity_dir = project_dir / "identity"
    required_files = ["persona.md", "instructions.md", "guardrails.yaml"]
    for fname in required_files:
        fpath = identity_dir / fname
        if fpath.exists():
            result.checks.append(CheckResult("pass", f"identity/{fname} — present"))
        else:
            result.checks.append(CheckResult("fail", f"identity/{fname} — missing"))


def _check_adapters(project_dir: Path, manifest: dict, result: ValidationResult) -> None:
    """Check adapter files referenced in the manifest exist."""
    spec = manifest.get("spec", {})
    runtime = spec.get("runtime", {})

    for adapter_key in ["llm", "embedding"]:
        adapter = runtime.get(adapter_key, {})
        adapter_path = adapter.get("adapter")
        if adapter_path:
            full_path = project_dir / adapter_path
            if full_path.exists():
                result.checks.append(CheckResult("pass", f"{adapter_path} — present"))
            else:
                result.checks.append(CheckResult("fail", f"{adapter_path} — missing"))


def _check_evals(project_dir: Path, manifest: dict, result: ValidationResult) -> None:
    """Check eval suite files exist."""
    spec = manifest.get("spec", {})
    evals_ref = spec.get("evals")
    if not evals_ref:
        result.checks.append(CheckResult("warn", "evals — not referenced in manifest"))
        return

    evals_path = project_dir / "evals" / "baseline.yaml"
    if evals_path.exists():
        result.checks.append(CheckResult("pass", "evals/baseline.yaml — present"))
    else:
        result.checks.append(CheckResult("fail", "evals/baseline.yaml — missing"))


def _check_observability(project_dir: Path, manifest: dict, result: ValidationResult) -> None:
    """Check observability config exists and has recommended attributes."""
    spec = manifest.get("spec", {})
    obs_ref = spec.get("observability")
    if not obs_ref:
        result.checks.append(CheckResult("warn", "observability — not referenced in manifest"))
        return

    obs_path = project_dir / "observability" / "config.yaml"
    if obs_path.exists():
        result.checks.append(CheckResult("pass", "observability/config.yaml — present"))
        # Check for recommended attributes
        try:
            with open(obs_path) as f:
                obs_config = yaml.safe_load(f)
            required_attrs = obs_config.get("observability", {}).get("required_attributes", [])
            if "cost.usd" not in required_attrs:
                result.checks.append(
                    CheckResult(
                        "warn",
                        "observability/config.yaml — missing recommended attribute: cost.usd",
                    )
                )
        except Exception:
            pass
    else:
        result.checks.append(CheckResult("fail", "observability/config.yaml — missing"))
