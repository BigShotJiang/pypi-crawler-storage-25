from datetime import datetime
from decimal import Decimal

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, Numeric, String, Text, func
from sqlalchemy.dialects.postgresql import ENUM
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from infrastructure_connector.utils.enums import (
    AlertCode,
    AnalysisType,
    ArtifactType,
    AssetClass,
    AssetSubclass,
    Countries,
    Direction,
    GrowthTrend,
    InflationTrend,
    LeadingStatus,
    Level,
    LiquidityProfile,
    Market,
    MonetaryPolicy,
    ObjectiveStatus,
    OperationStatus,
    OperationType,
    OpportunityStatus,
    Period,
    RiskAppetite,
    Signal,
    StrategyType,
    TimeHorizon,
    TimeUnitEnum,
    TypicalFrequency,
    ValueType,
    VolatilityProfile,
)


class Base(DeclarativeBase):
    """Base class for all ORM models."""

    pass


class AlembicVersion(Base):
    __tablename__ = "alembic_version"

    version_num: Mapped[str] = mapped_column(String(32), primary_key=True, nullable=False)


class SchemaVersion(Base):
    __tablename__ = "schema_version"
    version: Mapped[str] = mapped_column(primary_key=True)
    applied_at: Mapped[datetime] = mapped_column(server_default=func.now())


class Users(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    password_hash: Mapped[str] = mapped_column(String)
    role: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    alerts = relationship("Alerts", back_populates="user")
    portfolios = relationship("Portfolios", back_populates="user")
    strategies = relationship("Strategies", back_populates="creator")


class Alerts(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    type: Mapped[AlertCode] = mapped_column(
        ENUM(AlertCode, name="alert_code", create_type=True)
    )  # MODIFIÉ
    user = relationship("Users", back_populates="alerts")
    assets_alerts = relationship(
        "AssetsAlerts", back_populates="alert", cascade="all, delete-orphan"
    )
    publication_alerts = relationship(
        "PublicationAlerts", back_populates="alert", cascade="all, delete-orphan"
    )


class Assets(Base):
    __tablename__ = "assets"

    asset_class: Mapped[AssetClass] = mapped_column(
        ENUM(AssetClass, name="asset_class", create_type=True)
    )  # MODIFIÉ
    asset_subclass: Mapped[AssetSubclass] = mapped_column(
        ENUM(AssetSubclass, name="asset_subclass", create_type=True)
    )  # MODIFIÉ
    liquidity_profile: Mapped[LiquidityProfile] = mapped_column(
        ENUM(LiquidityProfile, name="liquidity_profile", create_type=True)
    )  # MODIFIÉ
    volatility_profile: Mapped[VolatilityProfile] = mapped_column(
        ENUM(VolatilityProfile, name="volatility_profile", create_type=True)
    )  # MODIFIÉ
    market: Mapped[Market] = mapped_column(ENUM(Market, name="market", create_type=True))  # MODIFIÉ
    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    symbol: Mapped[str] = mapped_column(String, unique=True)
    name: Mapped[str] = mapped_column(String)
    currency: Mapped[str] = mapped_column(String)
    base_currency: Mapped[str] = mapped_column(String)
    quote_currency: Mapped[str] = mapped_column(String)
    lot_unit: Mapped[Decimal] = mapped_column(Numeric)
    price_tick: Mapped[Decimal] = mapped_column(Numeric)
    quantity_step: Mapped[Decimal] = mapped_column(Numeric)
    trading_hours: Mapped[str] = mapped_column(String)
    assets_alerts = relationship("AssetsAlerts", back_populates="asset")
    operations = relationship("Operations", back_populates="asset")
    opportunities = relationship("Opportunities", back_populates="asset")
    asset_specific_exposures = relationship("AssetSpecificExposures", back_populates="asset")
    price_history = relationship("PriceHistory", back_populates="asset")
    analysis_kpis = relationship("AnalysisKpis", back_populates="asset")


class AssetsAlerts(Base):
    __tablename__ = "assets_alerts"

    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id"), primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), primary_key=True, nullable=False)
    asset_price: Mapped[Decimal] = mapped_column(Numeric)

    alert = relationship("Alerts", back_populates="assets_alerts")
    asset = relationship("Assets", back_populates="assets_alerts")


class EconomicCalendar(Base):
    __tablename__ = "economic_calendar"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    fundamental_indicator_id: Mapped[int] = mapped_column(
        ForeignKey("fundamental_indicators.id"), nullable=False
    )
    previous_value: Mapped[Decimal] = mapped_column(Numeric)
    forecast_value: Mapped[Decimal] = mapped_column(Numeric)
    actual_value: Mapped[Decimal] = mapped_column(Numeric)
    event_name: Mapped[str] = mapped_column(String)
    country: Mapped[str] = mapped_column(String)
    impact_level: Mapped[str] = mapped_column(String)
    event_date: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    fundamental_indicator = relationship("FundamentalIndicators", back_populates="economic_events")
    publication_alerts = relationship("PublicationAlerts", back_populates="publication")
    indicator_scores = relationship("IndicatorScores", back_populates="publication")


class PublicationAlerts(Base):
    __tablename__ = "publication_alerts"

    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id"), primary_key=True, nullable=False)
    publication_id: Mapped[int] = mapped_column(
        ForeignKey("economic_calendar.id"), primary_key=True, nullable=False
    )
    estimated_date: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    alert = relationship("Alerts", back_populates="publication_alerts")
    publication = relationship("EconomicCalendar", back_populates="publication_alerts")


class Portfolios(Base):
    __tablename__ = "portfolios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    base_currency: Mapped[str] = mapped_column(String)
    initial_capital: Mapped[Decimal] = mapped_column(Numeric)
    current_capital: Mapped[Decimal] = mapped_column(Numeric)
    risk_profile: Mapped[str] = mapped_column(String)
    benchmark: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    user = relationship("Users", back_populates="portfolios")
    operations = relationship("Operations", back_populates="portfolio")
    objectives = relationship("Objectives", back_populates="portfolio")
    performance_returns = relationship("PerformanceReturns", back_populates="portfolio")
    performance_risk = relationship("PerformanceRisk", back_populates="portfolio")
    execution_stats = relationship("ExecutionStats", back_populates="portfolio")
    behavioral_stats = relationship("BehavioralStats", back_populates="portfolio")
    portfolio_history = relationship("PortfolioHistory", back_populates="portfolio")


class Operations(Base):
    __tablename__ = "operations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    strategy_id: Mapped[int] = mapped_column(ForeignKey("strategies.id"))
    opportunity_id: Mapped[int] = mapped_column(ForeignKey("opportunities.id"))
    direction: Mapped[Direction] = mapped_column(
        ENUM(Direction, name="direction", create_type=True)
    )  # MODIFIÉ
    operation_type: Mapped[OperationType] = mapped_column(
        ENUM(OperationType, name="operation_type", create_type=True)
    )  # MODIFIÉ
    time_horizon: Mapped[TimeHorizon] = mapped_column(
        ENUM(TimeHorizon, name="time_horizon", create_type=True)
    )  # MODIFIÉ
    status: Mapped[OperationStatus] = mapped_column(
        ENUM(OperationStatus, name="operation_status", create_type=True)
    )  # MODIFIÉ
    quantity: Mapped[Decimal] = mapped_column(Numeric)
    price: Mapped[Decimal] = mapped_column(Numeric)
    notional: Mapped[Decimal] = mapped_column(Numeric)
    stop_loss: Mapped[Decimal] = mapped_column(Numeric)
    take_profit: Mapped[Decimal] = mapped_column(Numeric)
    fees: Mapped[Decimal] = mapped_column(Numeric)
    slippage: Mapped[Decimal] = mapped_column(Numeric)
    executed_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="operations")
    asset = relationship("Assets", back_populates="operations")
    strategy = relationship("Strategies", back_populates="operations")
    opportunity = relationship("Opportunities", back_populates="operations")
    operation_history = relationship(
        "OperationHistory", back_populates="operation", cascade="all, delete-orphan"
    )


class Opportunities(Base):
    __tablename__ = "opportunities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    strategy_id: Mapped[int] = mapped_column(ForeignKey("strategies.id"), nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    direction: Mapped[Direction] = mapped_column(
        ENUM(Direction, name="direction", create_type=True)
    )  # MODIFIÉ
    status: Mapped[OpportunityStatus] = mapped_column(
        ENUM(OpportunityStatus, name="opportunity_status", create_type=True)
    )  # MODIFIÉ
    confidence_score: Mapped[Decimal] = mapped_column(Numeric)
    entry_price: Mapped[Decimal] = mapped_column(Numeric)
    stop_loss: Mapped[Decimal] = mapped_column(Numeric)
    take_profit: Mapped[Decimal] = mapped_column(Numeric)
    expected_return: Mapped[Decimal] = mapped_column(Numeric)
    risk_reward_ratio: Mapped[Decimal] = mapped_column(Numeric)
    valid_from: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    valid_until: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    detected_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    closed_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    asset = relationship("Assets", back_populates="opportunities")
    strategy = relationship("Strategies", back_populates="opportunities")
    analysis = relationship("GeneratedAnalyses", back_populates="opportunities")
    operations = relationship("Operations", back_populates="opportunity")
    opportunity_history = relationship(
        "OpportunityHistory", back_populates="opportunity", cascade="all, delete-orphan"
    )


class Strategies(Base):
    __tablename__ = "strategies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    asset_class: Mapped[AssetClass] = mapped_column(
        ENUM(AssetClass, name="asset_class", create_type=True)
    )  # MODIFIÉ
    strategy_type: Mapped[StrategyType] = mapped_column(
        ENUM(StrategyType, name="strategy_type", create_type=True)
    )  # MODIFIÉ
    creator_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    max_position_size: Mapped[Decimal] = mapped_column(Numeric)
    expected_return: Mapped[Decimal] = mapped_column(Numeric)
    risk_estimate: Mapped[Decimal] = mapped_column(Numeric)
    leverage: Mapped[Decimal] = mapped_column(Numeric)

    creator = relationship("Users", back_populates="strategies")
    operations = relationship("Operations", back_populates="strategy")
    opportunities = relationship("Opportunities", back_populates="strategy")
    strategy_objectives = relationship("StrategyObjectives", back_populates="strategy")
    strategy_history = relationship(
        "StrategyHistory", back_populates="strategy", cascade="all, delete-orphan"
    )


class Objectives(Base):
    __tablename__ = "objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    type: Mapped[str] = mapped_column(String)
    target_return: Mapped[Decimal] = mapped_column(Numeric)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    asset_class: Mapped[AssetClass] = mapped_column(
        ENUM(AssetClass, name="asset_class", create_type=True)
    )  # MODIFIÉ
    time_horizon: Mapped[TimeHorizon] = mapped_column(
        ENUM(TimeHorizon, name="time_horizon", create_type=True)
    )  # MODIFIÉ
    status: Mapped[ObjectiveStatus] = mapped_column(
        ENUM(ObjectiveStatus, name="objective_status", create_type=True)
    )  # MODIFIÉ
    exposure: Mapped[Decimal] = mapped_column(Numeric)
    priority: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="objectives")
    strategy_objectives = relationship("StrategyObjectives", back_populates="objective")
    objective_history = relationship(
        "ObjectiveHistory", back_populates="objective", cascade="all, delete-orphan"
    )


class StrategyObjectives(Base):
    __tablename__ = "strategy_objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(ForeignKey("strategies.id"), nullable=False)
    objective_id: Mapped[int] = mapped_column(ForeignKey("objectives.id"), nullable=False)
    correlation_ratio: Mapped[Decimal] = mapped_column(Numeric)

    strategy = relationship("Strategies", back_populates="strategy_objectives")
    objective = relationship("Objectives", back_populates="strategy_objectives")


class MacroRegimes(Base):
    __tablename__ = "macro_regimes"

    growth_trend: Mapped[GrowthTrend] = mapped_column(
        ENUM(GrowthTrend, name="growth_trend", create_type=True)
    )  # MODIFIÉ
    inflation_trend: Mapped[InflationTrend] = mapped_column(
        ENUM(InflationTrend, name="inflation_trend", create_type=True)
    )  # MODIFIÉ
    monetary_policy: Mapped[MonetaryPolicy] = mapped_column(
        ENUM(MonetaryPolicy, name="monetary_policy", create_type=True)
    )  # MODIFIÉ
    risk_appetite: Mapped[RiskAppetite] = mapped_column(
        ENUM(RiskAppetite, name="risk_appetite", create_type=True)
    )  # MODIFIÉ
    expected_volatility: Mapped[Level] = mapped_column(
        ENUM(Level, name="level", create_type=True)
    )  # MODIFIÉ
    liquidity_level: Mapped[Level] = mapped_column(
        ENUM(Level, name="level", create_type=True)
    )  # MODIFIÉ

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    description: Mapped[str] = mapped_column(Text)
    confidence_score: Mapped[Decimal] = mapped_column(Numeric)
    valid_from: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    valid_to: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    generated_analyses = relationship("GeneratedAnalyses", back_populates="macro_regime")
    macro_asset_class_exposures = relationship(
        "MacroAssetClassExposures", back_populates="macro_regime"
    )
    asset_specific_exposures = relationship("AssetSpecificExposures", back_populates="macro_regime")
    indicator_scores = relationship("IndicatorScores", back_populates="macro_regime")
    indicator_scores_rules = relationship("IndicatorScoresRules", back_populates="macro_regime")


class Agents(Base):
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    type: Mapped[str] = mapped_column(String)

    generated_analyses = relationship("GeneratedAnalyses", back_populates="agent")
    agents_sources = relationship("AgentsSources", back_populates="agent")


class NewsSources(Base):
    __tablename__ = "news_sources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    category: Mapped[str] = mapped_column(String)
    country_code: Mapped[Countries] = mapped_column(
        ENUM(Countries, name="countries", create_type=True)
    )  # MODIFIÉ
    analysis_news_sources = relationship("AnalysisNewsSources", back_populates="source")
    agents_sources = relationship("AgentsSources", back_populates="news_source")


class GeneratedAnalyses(Base):
    __tablename__ = "generated_analyses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), nullable=False)
    analysis_type: Mapped[AnalysisType] = mapped_column(
        ENUM(AnalysisType, name="analysis_type", create_type=True)
    )  # MODIFIÉ
    time_horizon: Mapped[TimeHorizon] = mapped_column(
        ENUM(TimeHorizon, name="time_horizon", create_type=True)
    )  # MODIFIÉ
    global_score: Mapped[Decimal] = mapped_column(Numeric)
    confidence_level: Mapped[Decimal] = mapped_column(Numeric)
    bias: Mapped[str] = mapped_column(String(7))
    valid_from: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    valid_until: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    macro_regime = relationship("MacroRegimes", back_populates="generated_analyses")
    agent = relationship("Agents", back_populates="generated_analyses")
    analysis_news_sources = relationship("AnalysisNewsSources", back_populates="analysis")
    analysis_artifacts = relationship("AnalysisArtifacts", back_populates="analysis")
    analysis_indicators = relationship("AnalysisIndicators", back_populates="analysis")
    opportunities = relationship("Opportunities", back_populates="analysis")
    analysis_history = relationship(
        "AnalysisHistory", back_populates="analysis", cascade="all, delete-orphan"
    )


class AnalysisKpis(Base):
    __tablename__ = "analysis_kpis"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    time_unit: Mapped[TimeUnitEnum] = mapped_column(
        ENUM(TimeUnitEnum, name="time_unit", create_type=True)
    )
    nb_periods: Mapped[int] = mapped_column(Numeric)
    start_price: Mapped[float] = mapped_column(Numeric)
    end_price: Mapped[float] = mapped_column(Numeric)
    rel_change_pct: Mapped[float] = mapped_column(Numeric)  # en %
    abs_change_pips: Mapped[float] = mapped_column(Numeric)  # en pips

    # Volatility Regime
    simple_vol_pct: Mapped[float] = mapped_column(Numeric)  # en %
    atr_pips: Mapped[float] = mapped_column(Numeric)
    atr_pct: Mapped[float] = mapped_column(Numeric)  # ATR en % du prix

    # True Range Dynamics
    mean_tr_pips: Mapped[float] = mapped_column(Numeric)
    median_tr_pips: Mapped[float] = mapped_column(Numeric)
    std_tr_pips: Mapped[float] = mapped_column(Numeric)
    tr_cv: Mapped[float] = mapped_column(Numeric)  # coefficient de variation std/mean
    expansion_pct: Mapped[float] = mapped_column(Numeric)  # % de TR > 2*ATR
    max_tr_pct: Mapped[float] = mapped_column(Numeric)  # max TR / mean TR
    range_high: Mapped[float] = mapped_column(Numeric)
    range_low: Mapped[float] = mapped_column(Numeric)

    asset = relationship("Assets", back_populates="analysis_kpis")


class AnalysisNewsSources(Base):
    __tablename__ = "analysis_news_sources"

    analysis_id: Mapped[int] = mapped_column(
        ForeignKey("generated_analyses.id"), primary_key=True, nullable=False
    )
    source_id: Mapped[int] = mapped_column(
        ForeignKey("news_sources.id"), primary_key=True, nullable=False
    )

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_news_sources")
    source = relationship("NewsSources", back_populates="analysis_news_sources")


class AnalysisArtifacts(Base):
    __tablename__ = "analysis_artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    artifact_type: Mapped[ArtifactType] = mapped_column(
        ENUM(ArtifactType, name="artifact_type", create_type=True)
    )  # MODIFIÉ
    uri: Mapped[str] = mapped_column(String)
    checksum: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_artifacts")


class FundamentalIndicators(Base):
    __tablename__ = "fundamental_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[str] = mapped_column(String)
    code: Mapped[str] = mapped_column(String, unique=True)
    description: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String)
    sub_category: Mapped[str] = mapped_column(String)
    unit: Mapped[str] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    value_type: Mapped[ValueType] = mapped_column(
        ENUM(ValueType, name="value_type", create_type=True)
    )  # MODIFIÉ
    directionality: Mapped[Direction] = mapped_column(
        ENUM(Direction, name="direction", create_type=True)
    )  # MODIFIÉ
    typical_frequency: Mapped[TypicalFrequency] = mapped_column(
        ENUM(TypicalFrequency, name="typical_frequency", create_type=True)
    )  # MODIFIÉ
    leading_status: Mapped[LeadingStatus] = mapped_column(
        ENUM(LeadingStatus, name="leading_status", create_type=True)
    )  # MODIFIÉ

    economic_events = relationship("EconomicCalendar", back_populates="fundamental_indicator")
    analysis_indicators = relationship("AnalysisIndicators", back_populates="indicator")
    indicator_scores = relationship("IndicatorScores", back_populates="indicator")
    indicator_scores_rules = relationship("IndicatorScoresRules", back_populates="indicator")


class AnalysisIndicators(Base):
    __tablename__ = "analysis_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    indicator_id: Mapped[int] = mapped_column(
        ForeignKey("fundamental_indicators.id"), nullable=False
    )
    raw_value: Mapped[Decimal] = mapped_column(Numeric)
    normalized_value: Mapped[Decimal] = mapped_column(Numeric)
    score: Mapped[Decimal] = mapped_column(Numeric)
    weight: Mapped[Decimal] = mapped_column(Numeric)
    signal: Mapped[Signal] = mapped_column(ENUM(Signal, name="signal", create_type=True))  # MODIFIÉ
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_indicators")
    indicator = relationship("FundamentalIndicators", back_populates="analysis_indicators")


class AgentsSources(Base):
    __tablename__ = "agents_sources"

    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), primary_key=True, nullable=False)
    news_source_id: Mapped[int] = mapped_column(
        ForeignKey("news_sources.id"), primary_key=True, nullable=False
    )
    reliability_score: Mapped[Decimal] = mapped_column(Numeric)

    agent = relationship("Agents", back_populates="agents_sources")
    news_source = relationship("NewsSources", back_populates="agents_sources")


class IndicatorScores(Base):
    __tablename__ = "indicator_scores"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(
        ForeignKey("fundamental_indicators.id"), nullable=False
    )
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    publication_id: Mapped[int] = mapped_column(ForeignKey("economic_calendar.id"), nullable=False)
    country_code: Mapped[str] = mapped_column(String)
    score_naive: Mapped[int] = mapped_column(Integer)
    score_weighted: Mapped[Decimal] = mapped_column(Numeric)
    signal_direction: Mapped[Direction] = mapped_column(
        ENUM(Direction, name="direction", create_type=True)
    )  # MODIFIÉ
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    indicator = relationship("FundamentalIndicators", back_populates="indicator_scores")
    macro_regime = relationship("MacroRegimes", back_populates="indicator_scores")
    publication = relationship("EconomicCalendar", back_populates="indicator_scores")


class IndicatorScoresRules(Base):
    __tablename__ = "indicator_scores_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(
        ForeignKey("fundamental_indicators.id"), nullable=False
    )
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    score_naive: Mapped[int] = mapped_column(Integer)
    threshold_low: Mapped[Decimal] = mapped_column(Numeric)
    threshold_high: Mapped[Decimal] = mapped_column(Numeric)
    weight: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    indicator = relationship("FundamentalIndicators", back_populates="indicator_scores_rules")
    macro_regime = relationship("MacroRegimes", back_populates="indicator_scores_rules")


class MacroAssetClassExposures(Base):
    __tablename__ = "macro_asset_class_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    asset_class: Mapped[AssetClass] = mapped_column(
        ENUM(AssetClass, name="asset_class", create_type=True)
    )  # MODIFIÉ
    default_exposure: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    macro_regime = relationship("MacroRegimes", back_populates="macro_asset_class_exposures")


class AssetSpecificExposures(Base):
    __tablename__ = "asset_specific_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    exposure: Mapped[Decimal] = mapped_column(Numeric)
    override: Mapped[bool] = mapped_column(Boolean)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    macro_regime = relationship("MacroRegimes", back_populates="asset_specific_exposures")
    asset = relationship("Assets", back_populates="asset_specific_exposures")


class PerformanceReturns(Base):
    __tablename__ = "performance_returns"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    period: Mapped[Period] = mapped_column(ENUM(Period, name="period", create_type=True))  # MODIFIÉ
    total_return: Mapped[Decimal] = mapped_column(Numeric)
    win_rate: Mapped[Decimal] = mapped_column(Numeric)
    avg_win: Mapped[Decimal] = mapped_column(Numeric)
    avg_loss: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="performance_returns")


class PerformanceRisk(Base):
    __tablename__ = "performance_risk"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    volatility: Mapped[Decimal] = mapped_column(Numeric)
    max_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    avg_drawdown: Mapped[Decimal] = mapped_column(Numeric)
    drawdown_duration: Mapped[int] = mapped_column(Integer)
    sharpe_ratio: Mapped[Decimal] = mapped_column(Numeric)
    sortino_ratio: Mapped[Decimal] = mapped_column(Numeric)
    calmar_ratio: Mapped[Decimal] = mapped_column(Numeric)
    tail_risk: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="performance_risk")


class ExecutionStats(Base):
    __tablename__ = "execution_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    avg_slippage: Mapped[Decimal] = mapped_column(Numeric)
    avg_fees: Mapped[Decimal] = mapped_column(Numeric)
    slippage_ratio: Mapped[Decimal] = mapped_column(Numeric)
    fill_rate: Mapped[Decimal] = mapped_column(Numeric)
    avg_time_to_execution: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="execution_stats")


class BehavioralStats(Base):
    __tablename__ = "behavioral_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    trade_frequency: Mapped[Decimal] = mapped_column(Numeric)
    overtrading_score: Mapped[Decimal] = mapped_column(Numeric)
    avg_holding_time: Mapped[Decimal] = mapped_column(Numeric)
    deviation_from_expected_horizon: Mapped[Decimal] = mapped_column(Numeric)
    revenge_trading_score: Mapped[Decimal] = mapped_column(Numeric)
    consistency_score: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="behavioral_stats")


class PriceHistory(Base):
    __tablename__ = "price_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"))
    high: Mapped[Decimal] = mapped_column(Numeric)
    low: Mapped[Decimal] = mapped_column(Numeric)
    open: Mapped[Decimal] = mapped_column(Numeric)
    close: Mapped[Decimal] = mapped_column(Numeric)
    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )
    time_unit: Mapped[TimeUnitEnum] = mapped_column(
        ENUM(TimeUnitEnum, name="time_unit", create_type=True)
    )

    asset = relationship("Assets", back_populates="price_history")


class StrategyHistory(Base):
    __tablename__ = "strategy_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(ForeignKey("strategies.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    strategy = relationship("Strategies", back_populates="strategy_history")


class OperationHistory(Base):
    __tablename__ = "operation_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    operation_id: Mapped[int] = mapped_column(ForeignKey("operations.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    operation = relationship("Operations", back_populates="operation_history")


class ObjectiveHistory(Base):
    __tablename__ = "objective_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    objective_id: Mapped[int] = mapped_column(ForeignKey("objectives.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    objective = relationship("Objectives", back_populates="objective_history")


class PortfolioHistory(Base):
    __tablename__ = "portfolio_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    portfolio = relationship("Portfolios", back_populates="portfolio_history")


class AnalysisHistory(Base):
    __tablename__ = "analysis_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_history")


class OpportunityHistory(Base):
    __tablename__ = "opportunity_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    opportunity_id: Mapped[int] = mapped_column(ForeignKey("opportunities.id"))
    snapshot: Mapped[dict] = mapped_column(JSON)
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime,
        server_default=func.now(),
        nullable=False,
    )

    opportunity = relationship("Opportunities", back_populates="opportunity_history")
