from typing import Optional
from sqlalchemy.orm import Session
from infrastructure_connector.models.models import SchemaVersion
from infrastructure_connector.version import __schema_version__

# TODO Implements upgrade version's function according to updates

def initialize_schema_version(session: Session) -> None:
    latest = (
        session.query(SchemaVersion)
        .order_by(SchemaVersion.applied_at.desc())
        .first()
    )

    if latest is None or latest.version != __schema_version__:
        print("Initializing SchemaVersion in DB...")
        session.add(SchemaVersion(version=__schema_version__))
        session.commit()
        print("SchemaVersion added:", __schema_version__)
    else:
        print("Latest SchemaVersion found in DB:", latest.version)

def verify_schema_compatibility(session: Session) -> None:
    existing: Optional[SchemaVersion] = (
        session.query(SchemaVersion)
        .order_by(SchemaVersion.applied_at.desc())
        .first()
    )

    if existing is None:
        raise RuntimeError("Schema version table is not initialized.")

    if existing.version != __schema_version__:
        raise RuntimeError(
            f"Database schema version ({existing.version}) "
            f"does not match package version ({__schema_version__})"
        )