
def clean_dict(obj):
    """Extrait __dict__ propre sans SQLAlchemy internals"""
    if not hasattr(obj, '__dict__'):
        return obj
    return {k: v for k, v in obj.__dict__.items()
            if k != '_sa_instance_state'}
