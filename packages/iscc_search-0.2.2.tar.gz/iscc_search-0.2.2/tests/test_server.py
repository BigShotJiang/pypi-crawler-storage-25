"""Test FastAPI server for ISCC-Search API."""

from unittest.mock import patch, MagicMock
import pytest
from fastapi.testclient import TestClient
from iscc_search import __version__
from iscc_search.options import search_opts
from iscc_search.server import app, custom_docs, init_sentry, root


@pytest.fixture
def client():
    # type: () -> TestClient
    """
    Create TestClient with proper resource cleanup.

    Uses context manager to ensure the lifespan shutdown event is triggered
    and resources are properly cleaned up after tests. Configures app to use
    memory:// index backend.

    :return: FastAPI TestClient instance
    """
    import iscc_search.options

    # Save original URI and set to memory://
    original_uri = iscc_search.options.search_opts.index_uri
    iscc_search.options.search_opts.index_uri = "memory://"

    try:
        with TestClient(app) as client:
            yield client
    finally:
        # Restore original URI
        iscc_search.options.search_opts.index_uri = original_uri


def test_app_instance():
    """Test FastAPI app instance is properly configured."""
    assert app.title == "ISCC-Search API"
    assert app.version == __version__
    assert app.docs_url is None
    assert app.redoc_url is None
    assert app.openapi_url is None
    assert "A Scalable Nearest Neighbor Search" in app.description


def test_root_endpoint(client):
    """Test root endpoint returns API information."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["title"] == "ISCC-Search API"
    assert data["version"] == __version__
    assert data["docs"] == "/docs"
    assert "description" in data


def test_docs_endpoint(client):
    """Test custom docs endpoint returns HTML with Stoplight Elements UI."""
    response = client.get("/docs")
    assert response.status_code == 200
    assert response.headers["content-type"] == "text/html; charset=utf-8"

    html_content = response.text
    assert "<!doctype html>" in html_content.lower()
    assert "ISCC-Search API - Documentation" in html_content
    assert "/openapi/openapi.json" in html_content
    assert "@stoplight/elements" in html_content
    assert "elements-api" in html_content


def test_custom_docs_function():
    """Test custom_docs function directly."""
    result = custom_docs()
    html_content = result.body.decode("utf-8")
    assert "<!doctype html>" in html_content.lower()
    assert "ISCC-Search API - Documentation" in html_content
    assert "/openapi/openapi.json" in html_content
    assert "hideExport" in html_content
    assert "logo" in html_content


def test_root_function():
    """Test root function directly."""
    result = root()
    assert isinstance(result, dict)
    assert result["title"] == "ISCC-Search API"
    assert result["version"] == __version__
    assert result["docs"] == "/docs"


def test_openapi_static_files(client):
    """Test that OpenAPI static files are accessible."""
    response = client.get("/openapi/openapi.yaml")
    assert response.status_code == 200


def test_healthz_endpoint(client):
    """Liveness probe always returns 200 with status ok."""
    response = client.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_readyz_endpoint_ready(client):
    """Readiness probe returns 200 when the index is initialized and list_indexes works."""
    response = client.get("/readyz")
    assert response.status_code == 200
    assert response.json() == {"status": "ready"}


def test_readyz_endpoint_index_not_initialized(client):
    """Readiness probe returns 503 when app.state.index is missing."""
    original_index = app.state.index
    try:
        del app.state.index
        response = client.get("/readyz")
        assert response.status_code == 503
        body = response.json()
        assert body["status"] == "not_ready"
        assert body["reason"] == "index_not_initialized"
    finally:
        app.state.index = original_index


def test_init_sentry_skips_when_dsn_unset(monkeypatch):
    """init_sentry() is a no-op when ISCC_SEARCH_SENTRY_DSN is not configured."""
    monkeypatch.setattr(search_opts, "sentry_dsn", None)
    assert init_sentry() is False


def test_init_sentry_initializes_when_dsn_set(monkeypatch):
    """init_sentry() calls sentry_sdk.init with the configured DSN and sample rate."""
    import sentry_sdk

    calls = []

    def fake_init(**kwargs):
        calls.append(kwargs)

    monkeypatch.setattr(sentry_sdk, "init", fake_init)
    monkeypatch.setattr(search_opts, "sentry_dsn", "https://public@sentry.example.com/1")
    monkeypatch.setattr(search_opts, "sentry_traces_sample_rate", 0.1)

    assert init_sentry() is True
    assert len(calls) == 1
    assert calls[0]["dsn"] == "https://public@sentry.example.com/1"
    assert calls[0]["traces_sample_rate"] == 0.1
    assert calls[0]["integrations"]  # at least one integration


def test_readyz_endpoint_list_indexes_fails(client):
    """Readiness probe returns 503 when list_indexes raises."""
    original_list_indexes = app.state.index.list_indexes

    def failing_list_indexes():
        raise RuntimeError("simulated backend failure")

    app.state.index.list_indexes = failing_list_indexes
    try:
        response = client.get("/readyz")
        assert response.status_code == 503
        body = response.json()
        assert body["status"] == "not_ready"
        assert body["reason"] == "list_indexes_failed"
    finally:
        app.state.index.list_indexes = original_list_indexes


def test_main_entry_point():
    """Test main entry point starts uvicorn server."""
    from iscc_search.server.__main__ import main

    with patch("iscc_search.server.__main__.uvicorn.run") as mock_run:
        main()
        mock_run.assert_called_once_with(
            "iscc_search.server:app",
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info",
        )


def test_main_module_execution():
    """Test module execution via python -m."""
    import subprocess
    import sys

    # Run the module with mocked uvicorn to verify __name__ == '__main__' block executes
    # We use python -m to properly trigger the __main__ block for coverage
    code = """
from unittest.mock import patch, MagicMock

# Mock uvicorn.run before the module executes
import sys
mock_run = MagicMock()
sys.modules['uvicorn'] = MagicMock(run=mock_run)

# Now execute the __main__ module which will call uvicorn.run
if __name__ == '__main__':
    import iscc_search.server.__main__
"""
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True,
        timeout=5,
        text=True,
    )
    # Check that the subprocess completed successfully
    assert result.returncode == 0, f"Module execution failed: {result.stderr}"


def test_lifespan_shutdown():
    """Test that lifespan context manager properly closes index on shutdown."""
    from iscc_search.indexes.memory import MemoryIndex
    import iscc_search.options

    # Save and override URI to use memory://
    original_uri = iscc_search.options.search_opts.index_uri
    iscc_search.options.search_opts.index_uri = "memory://"

    try:
        # Use TestClient context manager to trigger lifespan events
        with TestClient(app) as client:
            # Verify the lifespan startup created an index
            assert hasattr(client.app.state, "index")
            index = client.app.state.index
            assert isinstance(index, MemoryIndex)

            # Patch close() on the real index to track calls
            # Lifespan captures the index reference directly, so we must
            # patch the actual instance (not swap app.state.index)
            index.close = MagicMock()

        # Verify close was called during lifespan shutdown
        index.close.assert_called_once()
    finally:
        # Restore original URI
        iscc_search.options.search_opts.index_uri = original_uri


def test_cors_headers_default(client):
    """Test CORS headers are present in response with default settings."""
    # CORS headers only appear when Origin header is present
    response = client.get("/", headers={"Origin": "https://example.com"})
    assert response.status_code == 200
    # Default should allow all origins
    assert "access-control-allow-origin" in response.headers
    assert response.headers["access-control-allow-origin"] == "*"


def test_cors_preflight_request(client):
    """Test CORS preflight OPTIONS request."""
    response = client.options(
        "/",
        headers={
            "Origin": "https://example.com",
            "Access-Control-Request-Method": "GET",
            "Access-Control-Request-Headers": "content-type",
        },
    )
    assert response.status_code == 200
    assert "access-control-allow-origin" in response.headers
    assert "access-control-allow-methods" in response.headers
    assert "access-control-allow-headers" in response.headers


def test_cors_with_custom_origins():
    """Test CORS with custom allowed origins."""
    import iscc_search.options

    # Save original values
    original_uri = iscc_search.options.search_opts.index_uri
    original_cors = iscc_search.options.search_opts.cors_origins

    try:
        # Override settings
        iscc_search.options.search_opts.index_uri = "memory://"
        iscc_search.options.search_opts.cors_origins = "https://example.com,https://app.example.com"

        # Need to reimport to pick up new settings
        from importlib import reload
        import iscc_search.server

        reload(iscc_search.server)

        with TestClient(iscc_search.server.app) as client:
            response = client.get(
                "/",
                headers={"Origin": "https://example.com"},
            )
            assert response.status_code == 200
            assert "access-control-allow-origin" in response.headers
            # When not using wildcard, FastAPI reflects the origin
            assert response.headers["access-control-allow-origin"] in [
                "https://example.com",
                "https://app.example.com",
            ]
    finally:
        # Restore original values
        iscc_search.options.search_opts.index_uri = original_uri
        iscc_search.options.search_opts.cors_origins = original_cors
        # Reload module to restore original state
        import iscc_search.server

        reload(iscc_search.server)
