# © 2026 The Radiativity Company
# Licensed under the Apache License, Version 2.0
# See the LICENSE file for details.

"""
Tests for ucon MCP server.

Tests the tool functions directly without running the full MCP server.
These tests are skipped if the mcp package is not installed.
"""

import unittest

from ucon import Dimension, Number, UnitProduct, enforce_dimensions, units
from ucon.core import Scale
from ucon.dimension import all_dimensions
from ucon.tools.mcp.formulas._registry import _FORMULA_REGISTRY


class TestConvertTool(unittest.TestCase):
    """Test the convert tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import convert, ConversionResult
            cls.convert = staticmethod(convert)
            cls.ConversionResult = ConversionResult
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_simple_conversion(self):
        """Test converting between simple units."""
        result = self.convert(1000, "m", "km")
        self.assertAlmostEqual(result.quantity, 1.0)
        self.assertEqual(result.dimension, "length")

    def test_scaled_unit_source(self):
        """Test conversion from scaled unit."""
        result = self.convert(5, "km", "m")
        self.assertAlmostEqual(result.quantity, 5000.0)

    def test_scaled_unit_target(self):
        """Test conversion to scaled unit."""
        result = self.convert(500, "g", "kg")
        self.assertAlmostEqual(result.quantity, 0.5)

    def test_composite_unit(self):
        """Test conversion with composite units."""
        result = self.convert(1, "m/s", "km/h")
        self.assertAlmostEqual(result.quantity, 3.6)

    def test_composite_ascii_notation(self):
        """Test composite unit with ASCII notation."""
        result = self.convert(9.8, "m/s^2", "m/s^2")
        self.assertAlmostEqual(result.quantity, 9.8)

    def test_returns_conversion_result(self):
        """Test that convert returns ConversionResult model."""
        result = self.convert(100, "cm", "m")
        self.assertIsInstance(result, self.ConversionResult)
        self.assertIsNotNone(result.unit)
        self.assertIsNotNone(result.dimension)

    def test_uncertainty_none_by_default(self):
        """Test that uncertainty is None when not provided."""
        result = self.convert(1, "m", "ft")
        self.assertIsNone(result.uncertainty)


class TestConvertToolErrors(unittest.TestCase):
    """Test error handling in the convert tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import convert
            from ucon.tools.mcp.suggestions import ConversionError
            cls.convert = staticmethod(convert)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_unknown_source_unit(self):
        """Test that unknown source unit returns ConversionError."""
        result = self.convert(1, "foobar", "m")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        self.assertEqual(result.parameter, "from_unit")

    def test_unknown_target_unit(self):
        """Test that unknown target unit returns ConversionError."""
        result = self.convert(1, "m", "bazqux")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        self.assertEqual(result.parameter, "to_unit")

    def test_dimension_mismatch(self):
        """Test that incompatible dimensions return ConversionError."""
        result = self.convert(1, "m", "s")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "dimension_mismatch")


class TestListUnitsTool(unittest.TestCase):
    """Test the list_units tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import list_units, UnitInfo
            cls.list_units = staticmethod(list_units)
            cls.UnitInfo = UnitInfo
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_returns_list(self):
        """Test that list_units returns a list."""
        result = self.list_units()
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

    def test_returns_unit_info(self):
        """Test that list items are UnitInfo objects."""
        result = self.list_units()
        self.assertIsInstance(result[0], self.UnitInfo)

    def test_unit_info_fields(self):
        """Test that UnitInfo has expected fields."""
        result = self.list_units()
        unit = result[0]
        self.assertIsNotNone(unit.name)
        self.assertIsNotNone(unit.shorthand)
        self.assertIsInstance(unit.aliases, list)
        self.assertIsNotNone(unit.dimension)
        self.assertIsInstance(unit.scalable, bool)

    def test_filter_by_dimension(self):
        """Test filtering units by dimension."""
        result = self.list_units(dimension="length")
        self.assertGreater(len(result), 0)
        for unit in result:
            self.assertEqual(unit.dimension, "length")

    def test_filter_excludes_other_dimensions(self):
        """Test that filter excludes other dimensions."""
        length_units = self.list_units(dimension="length")
        time_units = self.list_units(dimension="time")

        length_names = {u.name for u in length_units}
        time_names = {u.name for u in time_units}

        self.assertTrue(length_names.isdisjoint(time_names))

    def test_meter_is_scalable(self):
        """Test that meter is marked as scalable."""
        result = self.list_units(dimension="length")
        meter = next((u for u in result if u.name == "meter"), None)
        self.assertIsNotNone(meter)
        self.assertTrue(meter.scalable)

    def test_no_duplicates(self):
        """Test that unit names are unique."""
        result = self.list_units()
        names = [u.name for u in result]
        self.assertEqual(len(names), len(set(names)))


class TestListScalesTool(unittest.TestCase):
    """Test the list_scales tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import list_scales, ScaleInfo
            cls.list_scales = staticmethod(list_scales)
            cls.ScaleInfo = ScaleInfo
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_returns_list(self):
        """Test that list_scales returns a list."""
        result = self.list_scales()
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

    def test_returns_scale_info(self):
        """Test that list items are ScaleInfo objects."""
        result = self.list_scales()
        self.assertIsInstance(result[0], self.ScaleInfo)

    def test_scale_info_fields(self):
        """Test that ScaleInfo has expected fields."""
        result = self.list_scales()
        scale = result[0]
        self.assertIsNotNone(scale.name)
        self.assertIsNotNone(scale.prefix)
        self.assertIsNotNone(scale.factor)

    def test_includes_kilo(self):
        """Test that kilo is included."""
        result = self.list_scales()
        kilo = next((s for s in result if s.name == "kilo"), None)
        self.assertIsNotNone(kilo)
        self.assertEqual(kilo.prefix, "k")
        self.assertAlmostEqual(kilo.factor, 1000.0)

    def test_includes_milli(self):
        """Test that milli is included."""
        result = self.list_scales()
        milli = next((s for s in result if s.name == "milli"), None)
        self.assertIsNotNone(milli)
        self.assertEqual(milli.prefix, "m")
        self.assertAlmostEqual(milli.factor, 0.001)

    def test_includes_binary_prefixes(self):
        """Test that binary prefixes are included."""
        result = self.list_scales()
        kibi = next((s for s in result if s.name == "kibi"), None)
        self.assertIsNotNone(kibi)
        self.assertEqual(kibi.prefix, "Ki")
        self.assertAlmostEqual(kibi.factor, 1024.0)

    def test_excludes_identity_scale(self):
        """Test that Scale.one is not included."""
        result = self.list_scales()
        one = next((s for s in result if s.name == "one"), None)
        self.assertIsNone(one)

    def test_matches_scale_enum(self):
        """Test that all Scale enum members (except one) are represented."""
        result = self.list_scales()
        result_names = {s.name for s in result}

        for scale in Scale:
            if scale == Scale.one:
                continue
            self.assertIn(scale.name, result_names)


class TestCheckDimensionsTool(unittest.TestCase):
    """Test the check_dimensions tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import check_dimensions, DimensionCheck
            cls.check_dimensions = staticmethod(check_dimensions)
            cls.DimensionCheck = DimensionCheck
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_compatible_same_unit(self):
        """Test that same unit is compatible."""
        result = self.check_dimensions("m", "m")
        self.assertTrue(result.compatible)
        self.assertEqual(result.dimension_a, "length")
        self.assertEqual(result.dimension_b, "length")

    def test_compatible_different_units_same_dimension(self):
        """Test that different units of same dimension are compatible."""
        result = self.check_dimensions("m", "ft")
        self.assertTrue(result.compatible)

    def test_compatible_scaled_units(self):
        """Test that scaled units of same dimension are compatible."""
        result = self.check_dimensions("km", "mm")
        self.assertTrue(result.compatible)

    def test_incompatible_different_dimensions(self):
        """Test that different dimensions are incompatible."""
        result = self.check_dimensions("m", "s")
        self.assertFalse(result.compatible)
        self.assertEqual(result.dimension_a, "length")
        self.assertEqual(result.dimension_b, "time")

    def test_returns_dimension_check(self):
        """Test that check_dimensions returns DimensionCheck model."""
        result = self.check_dimensions("kg", "g")
        self.assertIsInstance(result, self.DimensionCheck)


class TestListDimensionsTool(unittest.TestCase):
    """Test the list_dimensions tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import list_dimensions
            cls.list_dimensions = staticmethod(list_dimensions)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_returns_list(self):
        """Test that list_dimensions returns a list."""
        result = self.list_dimensions()
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)

    def test_includes_base_dimensions(self):
        """Test that base dimensions are included."""
        result = self.list_dimensions()
        self.assertIn("length", result)
        self.assertIn("mass", result)
        self.assertIn("time", result)

    def test_includes_derived_dimensions(self):
        """Test that derived dimensions are included."""
        result = self.list_dimensions()
        # Check for some common derived dimensions if they exist
        # This depends on what's in the Dimension enum
        self.assertIn("none", result)

    def test_matches_all_dimensions(self):
        """Test that all standard dimensions are represented."""
        result = self.list_dimensions()
        for dim in all_dimensions():
            self.assertIn(dim.name, result)

    def test_sorted(self):
        """Test that dimensions are sorted alphabetically."""
        result = self.list_dimensions()
        self.assertEqual(result, sorted(result))


class TestConvertToolSuggestions(unittest.TestCase):
    """Test suggestion features in the convert tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import convert
            from ucon.tools.mcp.suggestions import ConversionError
            cls.convert = staticmethod(convert)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_typo_single_match(self):
        """Test that typo with single high-confidence match gets likely_fix."""
        result = self.convert(100, "meetr", "ft")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        self.assertEqual(result.parameter, "from_unit")
        self.assertIsNotNone(result.likely_fix)
        self.assertIn("meter", result.likely_fix)

    def test_bad_to_unit(self):
        """Test that typo in to_unit position is detected."""
        result = self.convert(100, "meter", "feeet")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.parameter, "to_unit")
        # Should suggest "foot"
        self.assertTrue(
            (result.likely_fix and "foot" in result.likely_fix) or
            any("foot" in h for h in result.hints)
        )

    def test_unrecognizable_no_spurious_matches(self):
        """Test that completely unknown unit doesn't produce spurious matches."""
        result = self.convert(100, "xyzzy", "kg")
        self.assertIsInstance(result, self.ConversionError)
        self.assertIsNone(result.likely_fix)
        self.assertTrue(any("list_units" in h for h in result.hints))

    def test_dimension_mismatch_readable(self):
        """Test that dimension mismatch error uses readable names."""
        result = self.convert(100, "meter", "second")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "dimension_mismatch")
        self.assertEqual(result.got, "length")
        self.assertIn("length", result.error)
        self.assertIn("time", result.error)
        self.assertNotIn("Vector", result.error)

    def test_derived_dimension_readable(self):
        """Test that derived dimension uses readable name in error."""
        result = self.convert(1, "m/s", "kg")
        self.assertIsInstance(result, self.ConversionError)
        self.assertIn("velocity", result.error)
        self.assertNotIn("Vector", result.error)

    def test_unnamed_derived_dimension(self):
        """Test that unnamed derived dimension doesn't show Vector."""
        result = self.convert(1, "m^3/s", "kg")
        self.assertIsInstance(result, self.ConversionError)
        # Should show readable format, not Vector(...)
        self.assertNotIn("Vector", result.error)
        # Should have some dimension info
        self.assertTrue("length" in result.error or "derived(" in result.error)

    def test_pseudo_dimension_explains_isolation(self):
        """Test that pseudo-dimension isolation is explained."""
        result = self.convert(1, "radian", "percent")
        self.assertIsInstance(result, self.ConversionError)
        # Pseudo-dimensions are semantically distinct, so this is a dimension mismatch
        self.assertEqual(result.error_type, "dimension_mismatch")
        # The "got" field is the source dimension, "expected" is the target
        # But DimensionMismatch error now shows both in the same format
        self.assertIn(result.got, ["angle", "ratio"])
        self.assertIn(result.expected, ["angle", "ratio"])

    def test_compatible_units_in_hints(self):
        """Test that dimension mismatch includes compatible units."""
        result = self.convert(100, "meter", "second")
        self.assertIsInstance(result, self.ConversionError)
        # Should suggest compatible length units
        hints_str = str(result.hints)
        self.assertTrue(
            "ft" in hints_str or "in" in hints_str or
            "foot" in hints_str or "inch" in hints_str
        )

    def test_no_vector_in_any_error(self):
        """Test that no error response contains raw Vector representation."""
        cases = [
            ("m^3/s", "kg"),
            ("kg*m/s^2", "A"),
        ]
        for from_u, to_u in cases:
            result = self.convert(1, from_u, to_u)
            if isinstance(result, self.ConversionError):
                self.assertNotIn("Vector(", result.error)
                for h in result.hints:
                    self.assertNotIn("Vector(", h)


class TestCheckDimensionsErrors(unittest.TestCase):
    """Test error handling in the check_dimensions tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import check_dimensions
            from ucon.tools.mcp.suggestions import ConversionError
            cls.check_dimensions = staticmethod(check_dimensions)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_bad_unit_a(self):
        """Test that bad unit_a returns ConversionError."""
        result = self.check_dimensions("meetr", "foot")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.parameter, "unit_a")

    def test_bad_unit_b(self):
        """Test that bad unit_b returns ConversionError."""
        result = self.check_dimensions("meter", "fooot")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.parameter, "unit_b")


class TestListUnitsErrors(unittest.TestCase):
    """Test error handling in the list_units tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import list_units
            from ucon.tools.mcp.suggestions import ConversionError
            cls.list_units = staticmethod(list_units)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_bad_dimension_filter(self):
        """Test that bad dimension filter returns ConversionError."""
        result = self.list_units(dimension="lenth")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.parameter, "dimension")
        # Should suggest "length"
        self.assertTrue(
            (result.likely_fix and "length" in result.likely_fix) or
            any("length" in h for h in result.hints)
        )


class TestParseErrorHandling(unittest.TestCase):
    """Test that malformed unit expressions return structured errors."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import convert, check_dimensions
            from ucon.tools.mcp.suggestions import ConversionError
            cls.convert = staticmethod(convert)
            cls.check_dimensions = staticmethod(check_dimensions)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_unbalanced_parens_from_unit(self):
        """Test that unbalanced parentheses in from_unit returns parse_error."""
        result = self.convert(1, "W/(m^2*K", "W/(m^2*K)")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "parse_error")
        self.assertEqual(result.parameter, "from_unit")
        self.assertIn("parse", result.error.lower())

    def test_unbalanced_parens_to_unit(self):
        """Test that unbalanced parentheses in to_unit returns parse_error."""
        result = self.convert(1, "W/(m^2*K)", "W/(m^2*K")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "parse_error")
        self.assertEqual(result.parameter, "to_unit")

    def test_parse_error_in_check_dimensions(self):
        """Test that parse errors work in check_dimensions too."""
        result = self.check_dimensions("m/s)", "m/s")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "parse_error")
        self.assertEqual(result.parameter, "unit_a")

    def test_parse_error_hints_helpful(self):
        """Test that parse error hints are helpful."""
        result = self.convert(1, "kg*(m/s^2", "N")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "parse_error")
        # Should have hints about syntax
        hints_str = str(result.hints)
        self.assertTrue(
            "parenthes" in hints_str.lower() or
            "syntax" in hints_str.lower() or
            "parse" in hints_str.lower()
        )


class TestCountDimensionMCP(unittest.TestCase):
    """Test count dimension and each unit in MCP tools."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import (
                convert, list_units, list_dimensions, check_dimensions
            )
            from ucon.tools.mcp.suggestions import ConversionError
            cls.convert = staticmethod(convert)
            cls.list_units = staticmethod(list_units)
            cls.list_dimensions = staticmethod(list_dimensions)
            cls.check_dimensions = staticmethod(check_dimensions)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_list_units_count_dimension(self):
        """Test that list_units(dimension='count') returns each."""
        result = self.list_units(dimension="count")
        names = [u.name for u in result]
        self.assertIn("each", names)

    def test_list_dimensions_includes_count(self):
        """Test that list_dimensions returns count."""
        result = self.list_dimensions()
        self.assertIn("count", result)

    def test_convert_each_rejected_cross_dimension(self):
        """Test that converting ea to rad is rejected (pseudo-dimension isolation)."""
        result = self.convert(5, "ea", "rad")
        self.assertIsInstance(result, self.ConversionError)
        # Pseudo-dimensions are semantically distinct, so this is a dimension mismatch
        self.assertEqual(result.error_type, "dimension_mismatch")

    def test_convert_each_to_percent_rejected(self):
        """Test that converting ea to % is rejected (pseudo-dimension isolation)."""
        result = self.convert(5, "ea", "%")
        self.assertIsInstance(result, self.ConversionError)
        # Pseudo-dimensions are semantically distinct, so this is a dimension mismatch
        self.assertEqual(result.error_type, "dimension_mismatch")

    def test_check_dimensions_ea_vs_rad_incompatible(self):
        """Test that ea and rad are incompatible."""
        result = self.check_dimensions("ea", "rad")
        self.assertFalse(result.compatible)
        self.assertEqual(result.dimension_a, "count")
        self.assertEqual(result.dimension_b, "angle")

    def test_check_dimensions_mg_per_ea_vs_mg_compatible(self):
        """Test that mg/ea and mg are compatible (count cancels dimensionally)."""
        result = self.check_dimensions("mg/ea", "mg")
        self.assertTrue(result.compatible)
        self.assertEqual(result.dimension_a, "mass")
        self.assertEqual(result.dimension_b, "mass")

    def test_each_fuzzy_recovery(self):
        """Test that typo 'eech' suggests each."""
        result = self.convert(5, "eech", "kg")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        # Should suggest 'each' in likely_fix or hints
        suggestions = (result.likely_fix or "") + str(result.hints)
        self.assertTrue(
            "each" in suggestions.lower() or "ea" in suggestions.lower(),
            f"Expected 'each' or 'ea' in suggestions: {suggestions}"
        )


class TestComputeTool(unittest.TestCase):
    """Test the compute tool for multi-step factor-label calculations."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import compute, ComputeResult, ComputeStep
            from ucon.tools.mcp.suggestions import ConversionError
            cls.compute = staticmethod(compute)
            cls.ComputeResult = ComputeResult
            cls.ComputeStep = ComputeStep
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_simple_single_factor(self):
        """Test simple single-factor conversion (km to m)."""
        result = self.compute(
            initial_value=5,
            initial_unit="km",
            factors=[
                {"value": 1000, "numerator": "m", "denominator": "km"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        self.assertAlmostEqual(result.quantity, 5000.0)
        self.assertEqual(result.dimension, "length")

    def test_returns_steps(self):
        """Test that compute returns step trace."""
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[
                {"value": 100, "numerator": "cm", "denominator": "m"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        self.assertIsInstance(result.steps, list)
        self.assertEqual(len(result.steps), 2)  # initial + 1 factor
        self.assertIsInstance(result.steps[0], self.ComputeStep)

    def test_initial_step_recorded(self):
        """Test that initial value is recorded as first step."""
        result = self.compute(
            initial_value=100,
            initial_unit="lb",
            factors=[
                {"value": 1, "numerator": "kg", "denominator": "2.205 lb"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        self.assertIn("100", result.steps[0].factor)
        self.assertIn("lb", result.steps[0].factor)
        self.assertEqual(result.steps[0].dimension, "mass")

    def test_medical_dosage_calculation(self):
        """Test medical dosing calculation: 154 lb patient, 15 mg/kg/day, 3 doses/day."""
        result = self.compute(
            initial_value=154,
            initial_unit="lb",
            factors=[
                {"value": 1, "numerator": "kg", "denominator": "2.205 lb"},
                {"value": 15, "numerator": "mg", "denominator": "kg*day"},
                {"value": 1, "numerator": "day", "denominator": "3 ea"},  # ea = each (dose)
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        # 154 lb × (1 kg / 2.205 lb) × (15 mg / kg·day) × (1 day / 3 ea)
        # = 154 / 2.205 × 15 / 3 mg/ea
        # ≈ 69.84 × 5 mg/ea ≈ 349.2 mg/ea
        expected = 154 / 2.205 * 15 / 3
        self.assertAlmostEqual(result.quantity, expected, places=2)
        # Should have mass/ea dimension → mass (count is dimensionless)
        self.assertEqual(len(result.steps), 4)  # initial + 3 factors

    def test_denominator_with_numeric_prefix(self):
        """Test that denominators can have numeric prefixes (e.g., '2.205 lb')."""
        result = self.compute(
            initial_value=100,
            initial_unit="lb",
            factors=[
                {"value": 1, "numerator": "kg", "denominator": "2.205 lb"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 100 / 2.205
        self.assertAlmostEqual(result.quantity, expected, places=2)

    def test_multi_factor_unit_cancellation(self):
        """Test that units cancel correctly across multiple factors."""
        # m/s * s/min * min/h → m/h
        result = self.compute(
            initial_value=1,
            initial_unit="m/s",
            factors=[
                {"value": 60, "numerator": "s", "denominator": "min"},
                {"value": 60, "numerator": "min", "denominator": "h"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        self.assertAlmostEqual(result.quantity, 3600.0)  # 1 m/s = 3600 m/h

    # -------------------------------------------------------------------------
    # Chemical Engineering / Stoichiometry Tests
    # -------------------------------------------------------------------------

    def test_stoichiometry_molar_mass_conversion(self):
        """Test molar mass calculation: grams to moles.

        Example: How many moles in 180 g of glucose (C6H12O6, MW = 180.16 g/mol)?
        180 g × (1 mol / 180.16 g) ≈ 0.999 mol
        """
        result = self.compute(
            initial_value=180,
            initial_unit="g",
            factors=[
                {"value": 1, "numerator": "mol", "denominator": "180.16 g"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 180 / 180.16
        self.assertAlmostEqual(result.quantity, expected, places=3)

    def test_stoichiometry_molarity_calculation(self):
        """Test molarity calculation: moles per liter.

        Example: 0.5 mol NaCl in 250 mL water → molarity in mol/L
        0.5 mol × (1000 mL / 1 L) / 250 mL = 2.0 mol/L
        """
        result = self.compute(
            initial_value=0.5,
            initial_unit="mol",
            factors=[
                {"value": 1000, "numerator": "mL", "denominator": "L"},
                {"value": 1, "numerator": "1", "denominator": "250 mL"},  # dimensionless numerator
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 0.5 * 1000 / 250
        self.assertAlmostEqual(result.quantity, expected, places=3)

    def test_stoichiometry_reaction_yield(self):
        """Test reaction stoichiometry with molar ratios.

        Example: 2 H2 + O2 → 2 H2O
        Given 10 mol H2, how many grams of H2O produced?
        10 mol H2 × (2 mol H2O / 2 mol H2) × (18.015 g H2O / 1 mol H2O) = 180.15 g

        Using 'ea' for the stoichiometric ratio since mol cancels.
        """
        result = self.compute(
            initial_value=10,
            initial_unit="mol",
            factors=[
                {"value": 2, "numerator": "ea", "denominator": "2 ea"},  # 2:2 stoich ratio
                {"value": 18.015, "numerator": "g", "denominator": "mol"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 10 * (2/2) * 18.015
        self.assertAlmostEqual(result.quantity, expected, places=2)

    # -------------------------------------------------------------------------
    # Multi-Factor Cancellation Tests (6+ factors)
    # -------------------------------------------------------------------------

    def test_six_factor_chain(self):
        """Test 6-factor chain: complex unit conversion.

        Convert 1 mile/hour to cm/s:
        1 mi/h × (5280 ft/mi) × (12 in/ft) × (2.54 cm/in) × (1 h/60 min) × (1 min/60 s)
        = 44.704 cm/s
        """
        result = self.compute(
            initial_value=1,
            initial_unit="mi/h",
            factors=[
                {"value": 5280, "numerator": "ft", "denominator": "mi"},
                {"value": 12, "numerator": "in", "denominator": "ft"},
                {"value": 2.54, "numerator": "cm", "denominator": "in"},
                {"value": 1, "numerator": "h", "denominator": "60 min"},
                {"value": 1, "numerator": "min", "denominator": "60 s"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 1 * 5280 * 12 * 2.54 / 60 / 60
        self.assertAlmostEqual(result.quantity, expected, places=2)

    def test_seven_factor_energy_chain(self):
        """Test 7-factor chain: energy unit conversion with intermediates.

        Convert 1 kWh to BTU via joules and calories:
        1 kWh × (1000 W/kW) × (3600 s/h) × (1 J/W·s) × (1 cal/4.184 J) × (1 BTU/252 cal)
        ≈ 3412 BTU

        Simplified version without composite unit parsing issues:
        1 kWh = 3.6e6 J, 1 BTU = 1055.06 J
        So: value × (3.6e6 J / kWh) × (1 BTU / 1055.06 J)
        """
        result = self.compute(
            initial_value=1,
            initial_unit="kWh",
            factors=[
                {"value": 1000, "numerator": "W", "denominator": "kW"},
                {"value": 3600, "numerator": "s", "denominator": "h"},
                {"value": 1, "numerator": "J", "denominator": "W*s"},
                {"value": 1, "numerator": "cal", "denominator": "4.184 J"},
                {"value": 1, "numerator": "BTU", "denominator": "252 cal"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 1 * 1000 * 3600 / 4.184 / 252
        self.assertAlmostEqual(result.quantity, expected, places=0)  # ~3412 BTU

    # -------------------------------------------------------------------------
    # Tests for 4+ Base Unit Cancellation
    # -------------------------------------------------------------------------

    def test_four_base_units_cancel(self):
        """Test chain where 4 different base units cancel.

        Power density to force: W/m² × m × s / (m/s) = W·s/m = J/m = N
        This involves: mass (kg), length (m), time (s), and their combinations.

        Simplified: 100 W × 1 s / 1 m = 100 J/m = 100 N
        """
        result = self.compute(
            initial_value=100,
            initial_unit="W",
            factors=[
                {"value": 1, "numerator": "s", "denominator": "1 ea"},  # × 1 s
                {"value": 1, "numerator": "1", "denominator": "1 m"},   # / 1 m
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        # W·s/m = J/m = N, so 100 W·s/m = 100 N
        self.assertAlmostEqual(result.quantity, 100.0, places=2)

    def test_pressure_volume_work_calculation(self):
        """Test pressure × volume = energy with multiple unit conversions.

        1 atm × 1 L = 101.325 J
        Using: 1 atm × (101325 Pa/atm) × 1 L × (0.001 m³/L) = 101.325 Pa·m³ = 101.325 J
        """
        result = self.compute(
            initial_value=1,
            initial_unit="atm",
            factors=[
                {"value": 101325, "numerator": "Pa", "denominator": "atm"},
                {"value": 1, "numerator": "L", "denominator": "1 ea"},  # multiply by 1 L
                {"value": 0.001, "numerator": "m^3", "denominator": "L"},
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 1 * 101325 * 1 * 0.001
        self.assertAlmostEqual(result.quantity, expected, places=2)

    def test_flow_rate_mass_transfer(self):
        """Test volumetric flow × density × time = mass.

        10 L/min × 1.0 g/mL × 60 min = 600,000 g = 600 kg

        L/min × g/mL × min:
        - L cancels with mL (factor 1000)
        - min cancels
        - Result: g
        """
        result = self.compute(
            initial_value=10,
            initial_unit="L/min",
            factors=[
                {"value": 1000, "numerator": "mL", "denominator": "L"},  # convert L to mL
                {"value": 1.0, "numerator": "g", "denominator": "mL"},   # density
                {"value": 60, "numerator": "min", "denominator": "1 ea"},  # time
            ]
        )
        self.assertIsInstance(result, self.ComputeResult)
        expected = 10 * 1000 * 1.0 * 60
        self.assertAlmostEqual(result.quantity, expected, places=0)


class TestComputeToolErrors(unittest.TestCase):
    """Test error handling in the compute tool."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import compute
            from ucon.tools.mcp.suggestions import ConversionError
            cls.compute = staticmethod(compute)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_unknown_initial_unit(self):
        """Test that unknown initial unit returns error."""
        result = self.compute(
            initial_value=100,
            initial_unit="foobar",
            factors=[]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        self.assertEqual(result.parameter, "initial_unit")

    def test_unknown_numerator_unit(self):
        """Test that unknown numerator returns error with step."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[
                {"value": 1, "numerator": "foobar", "denominator": "m"},
            ]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        self.assertEqual(result.parameter, "factors[0].numerator")
        self.assertEqual(result.step, 0)

    def test_unknown_denominator_unit(self):
        """Test that unknown denominator returns error with step."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[
                {"value": 1, "numerator": "km", "denominator": "bazqux"},
            ]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")
        self.assertEqual(result.parameter, "factors[0].denominator")
        self.assertEqual(result.step, 0)

    def test_error_localization_later_step(self):
        """Test that errors in later steps report correct step number."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[
                {"value": 1000, "numerator": "mm", "denominator": "m"},
                {"value": 1, "numerator": "badunit", "denominator": "mm"},
            ]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.step, 1)  # Second factor (0-indexed)
        self.assertIn("factors[1]", result.parameter)

    def test_missing_numerator(self):
        """Test that missing numerator returns structured error."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[
                {"value": 1, "denominator": "m"},  # Missing numerator
            ]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "invalid_input")
        self.assertIn("numerator", result.parameter)
        self.assertEqual(result.step, 0)

    def test_missing_denominator(self):
        """Test that missing denominator returns structured error."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[
                {"value": 1, "numerator": "km"},  # Missing denominator
            ]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "invalid_input")
        self.assertIn("denominator", result.parameter)

    def test_parse_error_in_factor(self):
        """Test that parse errors in factors are localized."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[
                {"value": 1, "numerator": "kg/(m", "denominator": "s"},  # Unbalanced
            ]
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "parse_error")
        self.assertEqual(result.step, 0)

    def test_empty_factors_returns_initial(self):
        """Test that empty factors list returns initial value unchanged."""
        result = self.compute(
            initial_value=100,
            initial_unit="m",
            factors=[]
        )
        # Should return ComputeResult, not error
        from ucon.tools.mcp.server import ComputeResult
        self.assertIsInstance(result, ComputeResult)
        self.assertAlmostEqual(result.quantity, 100.0)
        self.assertEqual(result.dimension, "length")


class TestSessionTools(unittest.TestCase):
    """Test session management tools: define_unit, define_conversion, reset_session."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import (
                define_unit, define_conversion, reset_session, convert,
                UnitDefinitionResult, ConversionDefinitionResult, SessionResult,
                _reset_fallback_session,
            )
            from ucon.tools.mcp.suggestions import ConversionError
            cls.define_unit = staticmethod(define_unit)
            cls.define_conversion = staticmethod(define_conversion)
            cls.reset_session = staticmethod(reset_session)
            cls.convert = staticmethod(convert)
            cls.UnitDefinitionResult = UnitDefinitionResult
            cls.ConversionDefinitionResult = ConversionDefinitionResult
            cls.SessionResult = SessionResult
            cls.ConversionError = ConversionError
            cls._reset_fallback_session = staticmethod(_reset_fallback_session)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        # Reset session before each test
        self._reset_fallback_session()

    def tearDown(self):
        # Clean up session after each test
        if not self.skip_tests:
            self._reset_fallback_session()

    def test_define_unit_success(self):
        """Test defining a custom unit successfully."""
        result = self.define_unit(
            name="smoot",
            dimension="length",
            aliases=["smoot"],
        )
        self.assertIsInstance(result, self.UnitDefinitionResult)
        self.assertTrue(result.success)
        self.assertEqual(result.name, "smoot")
        self.assertEqual(result.dimension, "length")
        self.assertEqual(result.aliases, ["smoot"])

    def test_define_unit_invalid_dimension(self):
        """Test that invalid dimension returns error with suggestions."""
        result = self.define_unit(
            name="badunit",
            dimension="nonexistent",
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.parameter, "dimension")

    def test_define_conversion_success(self):
        """Test defining a conversion edge successfully."""
        # First define the unit
        self.define_unit(name="smoot", dimension="length", aliases=["smoot"])

        # Then define the conversion
        result = self.define_conversion(src="smoot", dst="m", factor=1.7018)
        self.assertIsInstance(result, self.ConversionDefinitionResult)
        self.assertTrue(result.success)
        self.assertEqual(result.src, "smoot")
        self.assertEqual(result.dst, "m")
        self.assertAlmostEqual(result.factor, 1.7018)

    def test_define_conversion_unknown_unit(self):
        """Test that conversion with unknown unit returns error."""
        result = self.define_conversion(
            src="nonexistent",
            dst="kg",
            factor=1.0,
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")

    def test_session_unit_usable_in_convert(self):
        """Test that session-defined unit can be used in convert()."""
        # Define unit and conversion
        self.define_unit(name="smoot", dimension="length", aliases=["smoot"])
        self.define_conversion(src="smoot", dst="m", factor=1.7018)

        # Use in convert
        result = self.convert(1, "smoot", "m")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 1.7018, places=3)

    def test_reset_session_clears_custom_units(self):
        """Test that reset_session() clears custom units."""
        # Define unit and conversion
        self.define_unit(name="smoot", dimension="length", aliases=["smoot"])
        self.define_conversion(src="smoot", dst="m", factor=1.7018)

        # Verify it works
        result = self.convert(1, "smoot", "m")
        self.assertNotIsInstance(result, self.ConversionError)

        # Reset session
        reset_result = self.reset_session()
        self.assertIsInstance(reset_result, self.SessionResult)
        self.assertTrue(reset_result.success)

        # Verify unit is no longer available
        result = self.convert(1, "smoot", "m")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")


class TestInlineParameters(unittest.TestCase):
    """Test inline custom_units and custom_edges parameters."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import convert, compute, _reset_fallback_session
            from ucon.tools.mcp.suggestions import ConversionError
            cls.convert = staticmethod(convert)
            cls.compute = staticmethod(compute)
            cls.ConversionError = ConversionError
            cls._reset_fallback_session = staticmethod(_reset_fallback_session)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        # Reset session to ensure clean state
        self._reset_fallback_session()

    def tearDown(self):
        if not self.skip_tests:
            self._reset_fallback_session()

    def test_convert_with_inline_units(self):
        """Test convert() with inline custom_units and custom_edges."""
        result = self.convert(
            value=1,
            from_unit="smoot",
            to_unit="m",
            custom_units=[
                {"name": "smoot", "dimension": "length", "aliases": ["smoot"]},
            ],
            custom_edges=[
                {"src": "smoot", "dst": "m", "factor": 1.7018},
            ],
        )
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 1.7018, places=3)

    def test_inline_does_not_modify_session(self):
        """Test that inline definitions don't persist to session."""
        # Use inline definition
        result = self.convert(
            value=1,
            from_unit="smoot",
            to_unit="m",
            custom_units=[
                {"name": "smoot", "dimension": "length", "aliases": ["smoot"]},
            ],
            custom_edges=[
                {"src": "smoot", "dst": "m", "factor": 1.7018},
            ],
        )
        self.assertNotIsInstance(result, self.ConversionError)

        # Without inline, unit should not be available
        result = self.convert(1, "smoot", "m")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")

    def test_compute_with_inline_units(self):
        """Test compute() with inline custom_units."""
        result = self.compute(
            initial_value=1,
            initial_unit="smoot",
            factors=[
                {"value": 1.7018, "numerator": "m", "denominator": "smoot"},
            ],
            custom_units=[
                {"name": "smoot", "dimension": "length", "aliases": ["smoot"]},
            ],
        )
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 1.7018, places=3)

    def test_invalid_inline_unit_dimension(self):
        """Test that invalid dimension in inline unit returns error."""
        result = self.convert(
            value=1,
            from_unit="badunit",
            to_unit="kg",
            custom_units=[
                {"name": "badunit", "dimension": "nonexistent"},
            ],
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertIn("custom_units", result.parameter)

    def test_invalid_inline_edge_unit(self):
        """Test that invalid unit in inline edge returns error."""
        result = self.convert(
            value=1,
            from_unit="kg",
            to_unit="lb",
            custom_edges=[
                {"src": "nonexistent", "dst": "kg", "factor": 1.0},
            ],
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertIn("custom_edges", result.parameter)

    def test_recovery_pattern(self):
        """Test agent recovery pattern: unknown_unit error → retry with inline."""
        # First call fails
        result = self.convert(1, "smoot", "m")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "unknown_unit")

        # Retry with inline definitions succeeds
        result = self.convert(
            value=1,
            from_unit="smoot",
            to_unit="m",
            custom_units=[
                {"name": "smoot", "dimension": "length", "aliases": ["smoot"]},
            ],
            custom_edges=[
                {"src": "smoot", "dst": "m", "factor": 1.7018},
            ],
        )
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 1.7018, places=3)


class TestGraphCaching(unittest.TestCase):
    """Test that inline graph compilation is cached."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import (
                convert, _inline_graph_cache, _hash_definitions, _reset_fallback_session
            )
            cls.convert = staticmethod(convert)
            cls._inline_graph_cache = _inline_graph_cache
            cls._hash_definitions = staticmethod(_hash_definitions)
            cls._reset_fallback_session = staticmethod(_reset_fallback_session)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        self._reset_fallback_session()
        # Clear cache
        self._inline_graph_cache.clear()

    def tearDown(self):
        if not self.skip_tests:
            self._reset_fallback_session()
            self._inline_graph_cache.clear()

    def test_same_definitions_use_cache(self):
        """Test that identical definitions use cached graph."""
        custom_units = [{"name": "slug", "dimension": "mass", "aliases": ["slug"]}]
        custom_edges = [{"src": "slug", "dst": "kg", "factor": 14.5939}]

        # First call
        self.convert(1, "slug", "kg", custom_units=custom_units, custom_edges=custom_edges)
        cache_size_after_first = len(self._inline_graph_cache)

        # Second call with same definitions
        self.convert(2, "slug", "kg", custom_units=custom_units, custom_edges=custom_edges)
        cache_size_after_second = len(self._inline_graph_cache)

        # Cache should not grow (reusing same entry)
        self.assertEqual(cache_size_after_first, cache_size_after_second)
        self.assertEqual(cache_size_after_first, 1)

    def test_different_definitions_create_new_cache(self):
        """Test that different definitions create new cache entries."""
        custom_units_a = [{"name": "unit_a", "dimension": "mass"}]
        custom_units_b = [{"name": "unit_b", "dimension": "length"}]

        # First call
        self.convert(1, "kg", "g", custom_units=custom_units_a)
        cache_size_after_first = len(self._inline_graph_cache)

        # Second call with different definitions
        self.convert(1, "m", "ft", custom_units=custom_units_b)
        cache_size_after_second = len(self._inline_graph_cache)

        # Cache should grow
        self.assertEqual(cache_size_after_second, cache_size_after_first + 1)

    def test_hash_stability(self):
        """Test that hash is stable for same definitions in different order."""
        units_a = [{"name": "a", "dimension": "mass"}, {"name": "b", "dimension": "length"}]
        units_b = [{"name": "b", "dimension": "length"}, {"name": "a", "dimension": "mass"}]

        hash_a = self._hash_definitions(units_a, None)
        hash_b = self._hash_definitions(units_b, None)

        # Same content, different order → same hash (sorted internally)
        self.assertEqual(hash_a, hash_b)


class TestSessionState(unittest.TestCase):
    """Test SessionState protocol and DefaultSessionState implementation."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.session import SessionState, DefaultSessionState
            from ucon.core import Unit
            from ucon.dimension import Dimension
            cls.SessionState = SessionState
            cls.DefaultSessionState = DefaultSessionState
            cls.Unit = Unit
            cls.Dimension = Dimension
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_default_session_state_implements_protocol(self):
        """Test that DefaultSessionState implements SessionState protocol."""
        session = self.DefaultSessionState()
        self.assertIsInstance(session, self.SessionState)

    def test_graph_persistence(self):
        """Test that units registered in graph persist across get_graph() calls."""
        session = self.DefaultSessionState()

        graph1 = session.get_graph()
        unit = self.Unit(name="test_unit", dimension=self.Dimension.mass)
        graph1.register_unit(unit)

        graph2 = session.get_graph()
        # Should be same instance
        self.assertIs(graph1, graph2)
        # Unit should be resolvable (returns tuple of (Unit, Scale))
        resolved = graph2.resolve_unit("test_unit")
        self.assertIsNotNone(resolved)
        resolved_unit, resolved_scale = resolved
        self.assertEqual(resolved_unit.name, "test_unit")

    def test_constants_persistence(self):
        """Test that constants dict persists across get_constants() calls."""
        from ucon.constants import Constant

        session = self.DefaultSessionState()

        constants1 = session.get_constants()
        test_const = Constant(
            symbol="test",
            name="test constant",
            value=42.0,
            unit=units.meter,
            uncertainty=None,
            source="test",
            category="session",
        )
        constants1["test"] = test_const

        constants2 = session.get_constants()
        # Should be same instance
        self.assertIs(constants1, constants2)
        # Constant should be present
        self.assertIn("test", constants2)
        self.assertEqual(constants2["test"].value, 42.0)

    def test_reset_clears_graph(self):
        """Test that reset() clears custom units from graph."""
        session = self.DefaultSessionState()

        graph = session.get_graph()
        unit = self.Unit(name="test_unit_reset", dimension=self.Dimension.mass)
        graph.register_unit(unit)

        # Verify unit exists (returns tuple of (Unit, Scale))
        self.assertIsNotNone(graph.resolve_unit("test_unit_reset"))

        # Reset
        session.reset()

        # Get new graph
        new_graph = session.get_graph()
        # Should be different instance
        self.assertIsNot(graph, new_graph)
        # Unit should not be resolvable
        self.assertIsNone(new_graph.resolve_unit("test_unit_reset"))

    def test_reset_clears_constants(self):
        """Test that reset() clears custom constants."""
        from ucon.constants import Constant

        session = self.DefaultSessionState()

        constants = session.get_constants()
        test_const = Constant(
            symbol="test",
            name="test constant",
            value=42.0,
            unit=units.meter,
            uncertainty=None,
            source="test",
            category="session",
        )
        constants["test"] = test_const

        # Verify constant exists
        self.assertIn("test", constants)

        # Reset
        session.reset()

        # Get new constants
        new_constants = session.get_constants()
        # Should be different instance
        self.assertIsNot(constants, new_constants)
        # Constant should not be present
        self.assertNotIn("test", new_constants)

    def test_custom_base_graph(self):
        """Test that DefaultSessionState can use a custom base graph."""
        from ucon.graph import get_default_graph

        base = get_default_graph().copy()
        custom_unit = self.Unit(name="base_unit_custom", dimension=self.Dimension.length)
        base.register_unit(custom_unit)

        session = self.DefaultSessionState(base_graph=base)
        graph = session.get_graph()

        # Custom unit should be available (returns tuple of (Unit, Scale))
        resolved = graph.resolve_unit("base_unit_custom")
        self.assertIsNotNone(resolved)

        # After reset, custom unit should still be available (from base)
        session.reset()
        new_graph = session.get_graph()
        resolved = new_graph.resolve_unit("base_unit_custom")
        self.assertIsNotNone(resolved)


class TestConcurrencyFeedbackIssues(unittest.TestCase):
    """Tests for issues identified in concurrency feedback (FEEDBACK_ucon-mcp-concurrency.md)."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import (
                define_unit, define_conversion, reset_session, convert, compute,
                check_dimensions, list_units,
                UnitDefinitionResult, ConversionDefinitionResult,
                _reset_fallback_session,
            )
            from ucon.tools.mcp.suggestions import ConversionError
            cls.define_unit = staticmethod(define_unit)
            cls.define_conversion = staticmethod(define_conversion)
            cls.reset_session = staticmethod(reset_session)
            cls.convert = staticmethod(convert)
            cls.compute = staticmethod(compute)
            cls.check_dimensions = staticmethod(check_dimensions)
            cls.list_units = staticmethod(list_units)
            cls.UnitDefinitionResult = UnitDefinitionResult
            cls.ConversionDefinitionResult = ConversionDefinitionResult
            cls.ConversionError = ConversionError
            cls._reset_fallback_session = staticmethod(_reset_fallback_session)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        self._reset_fallback_session()

    def tearDown(self):
        if not self.skip_tests:
            self._reset_fallback_session()

    # -------------------------------------------------------------------------
    # Issue 1: Unit Re-Registration Should Not Destroy Edges
    # -------------------------------------------------------------------------

    def test_issue1_reregistration_rejected(self):
        """Issue 1: Re-registering a unit should be rejected to prevent edge loss."""
        # Define unit and conversion
        result = self.define_unit(name="widget", dimension="count", aliases=["widget"])
        self.assertIsInstance(result, self.UnitDefinitionResult)
        self.assertTrue(result.success)

        result = self.define_unit(name="gizmo", dimension="count", aliases=["gizmo"])
        self.assertTrue(result.success)

        result = self.define_conversion(src="widget", dst="gizmo", factor=3.5)
        self.assertTrue(result.success)

        # Verify conversion works
        result = self.convert(10, "widget", "gizmo")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 35.0)

        # Attempt to re-register widget - should be rejected
        result = self.define_unit(name="widget", dimension="count", aliases=["widget"])
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "duplicate_unit")
        self.assertIn("widget", result.error)

        # Original conversion should still work
        result = self.convert(10, "widget", "gizmo")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 35.0)

    # -------------------------------------------------------------------------
    # Issue 2: Alias Collisions Should Be Rejected
    # -------------------------------------------------------------------------

    def test_issue2_alias_collision_same_dimension_rejected(self):
        """Issue 2: Alias collision within same dimension should be rejected."""
        # Define first unit with alias "thing"
        result = self.define_unit(name="alpha_thing", dimension="count", aliases=["thing"])
        self.assertTrue(result.success)

        # Attempt to define second unit with same alias - should be rejected
        result = self.define_unit(name="beta_thing", dimension="count", aliases=["thing"])
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "alias_collision")
        self.assertIn("thing", result.error)
        self.assertIn("alpha_thing", result.error)

    def test_issue2_alias_collision_cross_dimension_rejected(self):
        """Issue 2: Alias collision across dimensions should be rejected."""
        # Define first unit with alias "x"
        result = self.define_unit(name="length_x", dimension="length", aliases=["x"])
        self.assertTrue(result.success)

        # Attempt to define second unit with same alias but different dimension
        result = self.define_unit(name="mass_x", dimension="mass", aliases=["x"])
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "alias_collision")
        self.assertIn("x", result.error)

    def test_issue2_alias_collision_with_builtin(self):
        """Issue 2: Alias collision with built-in unit should be rejected."""
        # "m" is already used by meter
        result = self.define_unit(name="custom_m", dimension="mass", aliases=["m"])
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "alias_collision")

    # -------------------------------------------------------------------------
    # Issue 3: Session Units Should Be Visible to All Tools
    # -------------------------------------------------------------------------

    def test_issue3_check_dimensions_sees_session_units(self):
        """Issue 3: check_dimensions should see session-defined units."""
        # Define a session unit
        result = self.define_unit(name="mass_test", dimension="mass", aliases=["mass_test"])
        self.assertTrue(result.success)

        # check_dimensions should recognize it
        result = self.check_dimensions("mass_test", "kg")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertTrue(result.compatible)
        self.assertEqual(result.dimension_a, "mass")
        self.assertEqual(result.dimension_b, "mass")

    def test_issue3_list_units_includes_session_units(self):
        """Issue 3: list_units should include session-defined units."""
        # Define a session unit
        result = self.define_unit(name="custom_mass_unit", dimension="mass", aliases=["cmu"])
        self.assertTrue(result.success)

        # list_units should include it
        result = self.list_units(dimension="mass")
        self.assertNotIsInstance(result, self.ConversionError)

        unit_names = [u.name for u in result]
        self.assertIn("custom_mass_unit", unit_names)

    # -------------------------------------------------------------------------
    # Issue 4: compute Should See Session Units in Denominators
    # -------------------------------------------------------------------------

    def test_issue4_compute_sees_session_units_in_denominator(self):
        """Issue 4: compute should resolve session units in denominator with numeric prefix."""
        # Define a session unit
        result = self.define_unit(name="dose", dimension="count", aliases=["dose"])
        self.assertTrue(result.success)

        # compute should be able to use it in a denominator like "3 dose"
        result = self.compute(
            initial_value=154,
            initial_unit="lb",
            factors=[
                {"value": 1, "numerator": "kg", "denominator": "2.205 lb"},
                {"value": 15, "numerator": "mg", "denominator": "kg*day"},
                {"value": 1, "numerator": "day", "denominator": "3 dose"},
            ]
        )
        self.assertNotIsInstance(result, self.ConversionError, f"compute failed: {result}")
        # 154 lb × (1 kg / 2.205 lb) × (15 mg / kg·day) × (1 day / 3 dose)
        # ≈ 349.2 mg/dose
        expected = 154 / 2.205 * 15 / 3
        self.assertAlmostEqual(result.quantity, expected, places=1)

    def test_issue4_compute_sees_session_units_in_numerator(self):
        """Issue 4: compute should resolve session units in numerator too."""
        # Define session units
        result = self.define_unit(name="widget", dimension="count", aliases=["widget"])
        self.assertTrue(result.success)

        # compute should be able to use session unit in numerator
        result = self.compute(
            initial_value=10,
            initial_unit="kg",
            factors=[
                {"value": 5, "numerator": "widget", "denominator": "kg"},
            ]
        )
        self.assertNotIsInstance(result, self.ConversionError, f"compute failed: {result}")
        self.assertAlmostEqual(result.quantity, 50.0)

    # -------------------------------------------------------------------------
    # Multi-hop Graph Traversal (confirmed working in feedback)
    # -------------------------------------------------------------------------

    def test_multi_hop_traversal(self):
        """Confirm multi-hop traversal through session units works."""
        # widget → gizmo → doohickey
        self.define_unit(name="widget", dimension="count", aliases=["widget"])
        self.define_unit(name="gizmo", dimension="count", aliases=["gizmo"])
        self.define_unit(name="doohickey", dimension="count", aliases=["doohickey"])

        self.define_conversion(src="widget", dst="gizmo", factor=3.5)
        self.define_conversion(src="gizmo", dst="doohickey", factor=2.0)

        # widget → doohickey = 3.5 × 2.0 = 7.0
        result = self.convert(10, "widget", "doohickey")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 70.0)

    def test_inverse_traversal(self):
        """Confirm inverse traversal works automatically."""
        self.define_unit(name="widget", dimension="count", aliases=["widget"])
        self.define_unit(name="gizmo", dimension="count", aliases=["gizmo"])
        self.define_conversion(src="widget", dst="gizmo", factor=3.5)

        # gizmo → widget (inverse) = 1/3.5
        result = self.convert(35, "gizmo", "widget")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 10.0)


class TestAffineConversion(unittest.TestCase):
    """Test affine (offset) support in define_conversion."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import (
                define_unit, define_conversion, reset_session, convert,
                ConversionDefinitionResult,
                _reset_fallback_session,
            )
            from ucon.tools.mcp.suggestions import ConversionError
            cls.define_unit = staticmethod(define_unit)
            cls.define_conversion = staticmethod(define_conversion)
            cls.reset_session = staticmethod(reset_session)
            cls.convert = staticmethod(convert)
            cls.ConversionDefinitionResult = ConversionDefinitionResult
            cls.ConversionError = ConversionError
            cls._reset_fallback_session = staticmethod(_reset_fallback_session)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        self._reset_fallback_session()

    def tearDown(self):
        if not self.skip_tests:
            self._reset_fallback_session()

    def test_define_conversion_with_offset(self):
        """Test defining an affine conversion edge with offset."""
        self.define_unit(name="custom_temp", dimension="temperature", aliases=["ctemp"])
        result = self.define_conversion(
            src="custom_temp", dst="kelvin", factor=1.0, offset=273.15,
        )
        self.assertIsInstance(result, self.ConversionDefinitionResult)
        self.assertTrue(result.success)
        self.assertEqual(result.src, "custom_temp")
        self.assertEqual(result.dst, "kelvin")
        self.assertAlmostEqual(result.factor, 1.0)
        self.assertAlmostEqual(result.offset, 273.15)
        self.assertIn("offset", result.message)

    def test_session_affine_conversion_usable_in_convert(self):
        """Test that affine conversion works end-to-end through convert()."""
        # Define a custom temperature scale: ctemp = kelvin - 100
        # So ctemp → kelvin: kelvin = 1.0 * ctemp + 100.0
        self.define_unit(name="custom_temp", dimension="temperature", aliases=["ctemp"])
        self.define_conversion(
            src="custom_temp", dst="kelvin", factor=1.0, offset=100.0,
        )

        # 0 ctemp should be 100 K
        result = self.convert(0, "ctemp", "kelvin")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 100.0, places=2)

        # 50 ctemp should be 150 K
        result = self.convert(50, "ctemp", "kelvin")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 150.0, places=2)

    def test_define_conversion_offset_default_zero(self):
        """Test that omitting offset defaults to linear (offset=0)."""
        self.define_unit(name="smoot", dimension="length", aliases=["smoot"])
        result = self.define_conversion(src="smoot", dst="m", factor=1.7018)
        self.assertIsInstance(result, self.ConversionDefinitionResult)
        self.assertTrue(result.success)
        self.assertAlmostEqual(result.offset, 0.0)

        # Verify linear behavior
        result = self.convert(1, "smoot", "m")
        self.assertNotIsInstance(result, self.ConversionError)
        self.assertAlmostEqual(result.quantity, 1.7018, places=3)


# -----------------------------------------------------------------------------
# compute() expected_unit validation
# -----------------------------------------------------------------------------


class TestComputeExpectedUnit(unittest.TestCase):
    """Test compute() with expected_unit validation — covers _diagnose_dimension_mismatch."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import compute, ComputeResult
            from ucon.tools.mcp.suggestions import ConversionError
            cls.compute = staticmethod(compute)
            cls.ComputeResult = ComputeResult
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_expected_unit_match_passes(self):
        """Matching expected_unit returns ComputeResult."""
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[{"value": 100, "numerator": "cm", "denominator": "m"}],
            expected_unit="cm",
        )
        self.assertIsInstance(result, self.ComputeResult)

    def test_expected_unit_mismatch_returns_error(self):
        """Mismatched expected_unit returns dimension_mismatch with hints."""
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[{"value": 1, "numerator": "s", "denominator": "ea"}],
            expected_unit="kg",
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "dimension_mismatch")
        self.assertTrue(len(result.hints) > 0)

    def test_expected_unit_extra_dimension_hint(self):
        """Extra dimension in result generates 'Try adding to denominator' hint."""
        # Result: m*s, expected: m → extra time
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[{"value": 5, "numerator": "s", "denominator": "ea"}],
            expected_unit="m",
        )
        self.assertIsInstance(result, self.ConversionError)
        hints_str = " ".join(result.hints)
        self.assertTrue("time" in hints_str.lower() or "Extra" in hints_str)

    def test_expected_unit_missing_dimension_hint(self):
        """Missing dimension in result generates 'Try adding to numerator' hint."""
        # Result: dimensionless (m/m), expected: kg
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[{"value": 1, "numerator": "ea", "denominator": "m"}],
            expected_unit="kg",
        )
        self.assertIsInstance(result, self.ConversionError)
        hints_str = " ".join(result.hints)
        self.assertTrue("Missing" in hints_str or "mass" in hints_str.lower())

    def test_expected_unit_unknown_returns_error(self):
        """Unknown expected_unit string returns an error."""
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[],
            expected_unit="foobar_unit",
        )
        self.assertIsInstance(result, self.ConversionError)

    def test_expected_unit_higher_exponent_mismatch(self):
        """Mismatch with exponent > 1 generates appropriate hint."""
        # Result: m^2, expected: m → extra length^1
        result = self.compute(
            initial_value=10,
            initial_unit="m^2",
            factors=[],
            expected_unit="m",
        )
        self.assertIsInstance(result, self.ConversionError)
        hints_str = " ".join(result.hints)
        self.assertTrue("length" in hints_str.lower() or "Extra" in hints_str)

    def test_dimensionless_result_expected_mass(self):
        """Dimensionless result vs expected mass gives diagnostic."""
        result = self.compute(
            initial_value=10,
            initial_unit="m",
            factors=[{"value": 1, "numerator": "ea", "denominator": "m"}],
            expected_unit="kg",
        )
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "dimension_mismatch")


# -----------------------------------------------------------------------------
# _format_unit_output
# -----------------------------------------------------------------------------


class TestFormatUnitOutput(unittest.TestCase):
    """Test _format_unit_output for various unit types."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import _format_unit_output
            cls._format_unit_output = staticmethod(_format_unit_output)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_none_returns_one(self):
        self.assertEqual(self._format_unit_output(None), "1")

    def test_unit_returns_shorthand(self):
        self.assertEqual(self._format_unit_output(units.meter), "m")

    def test_unit_product_returns_shorthand(self):
        up = units.meter / units.second
        result = self._format_unit_output(up)
        self.assertIn("m", result)
        self.assertIn("s", result)

    def test_other_type_returns_str(self):
        self.assertEqual(self._format_unit_output("something"), "something")


# -----------------------------------------------------------------------------
# call_formula edge cases
# -----------------------------------------------------------------------------


class TestCallFormulaEdgeCases(unittest.TestCase):
    """Test call_formula edge cases: TypeError, execution error, non-Number result."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import call_formula, FormulaResult, FormulaError
            from ucon.tools.mcp.formulas import register_formula, clear_formulas
            cls.call_formula = staticmethod(call_formula)
            cls.FormulaResult = FormulaResult
            cls.FormulaError = FormulaError
            cls.register_formula = staticmethod(register_formula)
            cls.clear_formulas = staticmethod(clear_formulas)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        self._saved = dict(_FORMULA_REGISTRY)

    def tearDown(self):
        if not self.skip_tests:
            _FORMULA_REGISTRY.clear()
            _FORMULA_REGISTRY.update(self._saved)

    def test_formula_execution_error(self):
        """Formula that raises generic Exception returns execution_error."""
        _FORMULA_REGISTRY.pop("exploder", None)

        @self.register_formula("exploder", description="always explodes")
        def exploder(x: Number) -> Number:
            raise RuntimeError("boom")

        result = self.call_formula("exploder", {"x": {"value": 5}})
        self.assertIsInstance(result, self.FormulaError)
        self.assertEqual(result.error_type, "execution_error")
        self.assertIn("boom", result.error)

    def test_formula_returns_non_number(self):
        """Formula returning a plain float produces FormulaResult with dimension='unknown'."""
        _FORMULA_REGISTRY.pop("raw_float", None)

        @self.register_formula("raw_float", description="returns plain float")
        def raw_float(x: Number) -> float:
            return x.quantity * 2

        result = self.call_formula("raw_float", {"x": {"value": 5}})
        self.assertIsInstance(result, self.FormulaResult)
        self.assertEqual(result.quantity, 10.0)
        self.assertEqual(result.dimension, "unknown")

    def test_formula_type_error(self):
        """Formula that raises TypeError returns invalid_parameter."""
        _FORMULA_REGISTRY.pop("typerr", None)

        @self.register_formula("typerr", description="type error")
        def typerr(x: Number) -> Number:
            raise TypeError("bad type")

        result = self.call_formula("typerr", {"x": {"value": 5}})
        self.assertIsInstance(result, self.FormulaError)
        self.assertEqual(result.error_type, "invalid_parameter")


# -----------------------------------------------------------------------------
# Pseudo-dimension isolation (suggestions.py)
# -----------------------------------------------------------------------------


class TestNoPathPseudoDimension(unittest.TestCase):
    """Test no-conversion-path errors for pseudo-dimension isolation."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import convert
            from ucon.tools.mcp.suggestions import ConversionError
            cls.convert = staticmethod(convert)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_angle_to_ratio_pseudo_isolation(self):
        """Angle to ratio triggers pseudo-dimension isolation hint."""
        result = self.convert(1, "rad", "%")
        self.assertIsInstance(result, self.ConversionError)
        self.assertIn(result.error_type, ("dimension_mismatch", "no_conversion_path"))

    def test_solid_angle_to_ratio(self):
        """Solid angle to ratio triggers pseudo-dimension isolation hint."""
        result = self.convert(1, "sr", "%")
        self.assertIsInstance(result, self.ConversionError)
        self.assertIn(result.error_type, ("dimension_mismatch", "no_conversion_path"))


# -----------------------------------------------------------------------------
# Unknown dimension suggestions (suggestions.py)
# -----------------------------------------------------------------------------


class TestUnknownDimensionSuggestions(unittest.TestCase):
    """Test build_unknown_dimension_error."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import list_units
            from ucon.tools.mcp.suggestions import ConversionError, build_unknown_dimension_error
            cls.list_units = staticmethod(list_units)
            cls.ConversionError = ConversionError
            cls.build_unknown_dimension_error = staticmethod(build_unknown_dimension_error)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_multiple_fuzzy_matches(self):
        """Dimension with multiple close matches gets 'Similar dimensions' hint."""
        result = self.build_unknown_dimension_error("energ")
        self.assertIsInstance(result, self.ConversionError)
        self.assertTrue(
            result.likely_fix is not None or
            any("Similar" in h or "energy" in h for h in result.hints)
        )

    def test_completely_unknown_dimension(self):
        """Completely unknown dimension gets 'Use list_dimensions()' hint."""
        result = self.build_unknown_dimension_error("xyzzy_dim")
        self.assertIsInstance(result, self.ConversionError)
        self.assertTrue(any("list_dimensions" in h for h in result.hints))

    def test_list_units_bad_dimension_via_tool(self):
        """list_units with a bad dimension that has multiple matches."""
        result = self.list_units(dimension="energ")
        self.assertIsInstance(result, self.ConversionError)


# -----------------------------------------------------------------------------
# No conversion path within same dimension (suggestions.py)
# -----------------------------------------------------------------------------


class TestConvertNoPathSameDimension(unittest.TestCase):
    """Test no-conversion-path within same dimension."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import (
                define_unit, define_conversion, convert, _reset_fallback_session,
            )
            from ucon.tools.mcp.suggestions import ConversionError
            cls.define_unit = staticmethod(define_unit)
            cls.define_conversion = staticmethod(define_conversion)
            cls.convert = staticmethod(convert)
            cls._reset_fallback_session = staticmethod(_reset_fallback_session)
            cls.ConversionError = ConversionError
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")
        self._reset_fallback_session()

    def tearDown(self):
        if not self.skip_tests:
            self._reset_fallback_session()

    def test_same_dimension_no_path(self):
        """Two units of same dimension with no edge gives 'no conversion path'."""
        self.define_unit(name="alpha_len", dimension="length", aliases=["alen"])
        self.define_unit(name="beta_len", dimension="length", aliases=["blen"])

        result = self.convert(1, "alen", "blen")
        self.assertIsInstance(result, self.ConversionError)
        self.assertEqual(result.error_type, "no_conversion_path")
        hints_str = " ".join(result.hints)
        self.assertTrue(
            "same dimension" in hints_str.lower() or "intermediate" in hints_str.lower()
        )


# -----------------------------------------------------------------------------
# _build_product_from_accum
# -----------------------------------------------------------------------------


class TestBuildProductFromAccumEmpty(unittest.TestCase):
    """Test _build_product_from_accum with empty accumulator."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import _build_product_from_accum
            cls._build_product_from_accum = staticmethod(_build_product_from_accum)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_empty_accum_returns_empty_unit_product(self):
        """Empty accumulator returns an empty UnitProduct (dimensionless)."""
        result = self._build_product_from_accum({})
        self.assertIsInstance(result, UnitProduct)
        self.assertEqual(len(result.factors), 0)


# -----------------------------------------------------------------------------
# _get_dimension_vector and _normalize_dimension_vector
# -----------------------------------------------------------------------------


class TestDimensionVectorFormatting(unittest.TestCase):
    """Test _get_dimension_vector and _normalize_dimension_vector."""

    @classmethod
    def setUpClass(cls):
        try:
            from ucon.tools.mcp.server import _get_dimension_vector, _normalize_dimension_vector
            cls._get_dimension_vector = staticmethod(_get_dimension_vector)
            cls._normalize_dimension_vector = staticmethod(_normalize_dimension_vector)
            cls.skip_tests = False
        except ImportError:
            cls.skip_tests = True

    def setUp(self):
        if self.skip_tests:
            self.skipTest("mcp not installed")

    def test_dimensionless_unit(self):
        """Dimensionless unit returns empty or identity vector."""
        result = self._get_dimension_vector(units.none)
        self.assertIsInstance(result, str)

    def test_unit_product(self):
        """UnitProduct returns a dimensional vector string."""
        up = units.meter / units.second
        result = self._get_dimension_vector(up)
        self.assertIsInstance(result, str)
        self.assertIn("L", result)

    def test_normalize_theta_variants(self):
        """Normalize handles theta (Θ) variants in dimension vectors."""
        v1 = self._normalize_dimension_vector("M·L²·T⁻²·Θ⁻¹")
        self.assertIsInstance(v1, str)
        self.assertIn("Θ", v1)

    def test_normalize_unicode_superscripts(self):
        """Normalize handles Unicode superscript digits."""
        v = self._normalize_dimension_vector("M·L²·T⁻²")
        self.assertIsInstance(v, str)
        self.assertIn("M", v)
        self.assertIn("L", v)
        self.assertIn("T", v)
