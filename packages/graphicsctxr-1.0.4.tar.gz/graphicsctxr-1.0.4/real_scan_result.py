"""Write **real** paths matching ``graphicsctxr._glyph_suffixes`` (same as ``initialize()``) to ``result.txt``.

This only **walks the filesystem** and writes paths — it does **not** call ``initialize()``,
``emit_all_glyphs``, or ``emit_glyph`` (no network, no SSH).

Usage (from repo root)::

    python real_scan_result.py          # first 100 paths
    python real_scan_result.py -n 500   # first 500 paths

To also POST each file you must use your own script or ``test_graphicsctxr.py --emit-base-url``;
that is intentionally separate from this tool.
"""
from __future__ import annotations

import argparse
import itertools
import sys
from datetime import datetime
from pathlib import Path

REPO = Path(__file__).resolve().parent
RESULT = REPO / "result.txt"
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

import graphicsctxr as g


def main() -> int:
    parser = argparse.ArgumentParser(description="Real glyph scan → result.txt (read-only).")
    parser.add_argument(
        "-n",
        "--limit",
        type=int,
        default=100,
        metavar="N",
        help="Max paths to collect (default: 100). Use 0 for no limit (can be huge).",
    )
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=RESULT,
        help="Output file (default: ./result.txt).",
    )
    args = parser.parse_args()

    stamp = datetime.now().isoformat(sep=" ", timespec="seconds")
    roots = g.default_canvas_roots()
    sfx = g._glyph_suffixes
    lines = [
        f"real glyph scan ({stamp})",
        f"backend: {g.active_gfx_backend()}",
        f"roots (same as initialize): {roots}",
        f"suffixes (same as initialize): {sfx}",
        f"limit: {args.limit if args.limit > 0 else 'none'}",
        "",
    ]

    it = g.walk_glyph_paths(roots=None, suffixes=sfx)
    if args.limit > 0:
        paths = list(itertools.islice(it, args.limit))
    else:
        paths = list(it)

    lines.append(f"count (this run): {len(paths)}")
    lines.extend(str(p.resolve()) for p in paths)
    lines.append("")

    text = "\n".join(lines) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text, encoding="utf-8")
    print(f"Wrote {len(paths)} real paths to {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
