"""Smoke-test graphicsctxr discovery (run from repo root: ``python test_graphicsctxr.py``)."""
from __future__ import annotations

import argparse
import itertools
import sys
import urllib.error
from pathlib import Path

REPO = Path(__file__).resolve().parent
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

import graphicsctxr as g


def _lines_default_walk_sample(limit: int) -> tuple[list[str], int]:
    """First ``limit`` paths from ``walk_glyph_paths()``; count of paths under Recycle Bin."""
    sample = list(itertools.islice(g.walk_glyph_paths(), limit))
    recycle = sum(1 for p in sample if "recycle.bin" in str(p).lower())
    return [str(p) for p in sample], recycle


def main() -> int:
    parser = argparse.ArgumentParser(description="Test graphicsctxr walk_glyph_paths / roots.")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        default=REPO / "result.txt",
        help="Write report here (default: ./result.txt next to this script).",
    )
    parser.add_argument(
        "-n",
        "--sample",
        type=int,
        default=100,
        metavar="N",
        help="How many paths to collect from default roots (default: 100).",
    )
    parser.add_argument(
        "--roots",
        type=Path,
        nargs="*",
        default=None,
        help="Optional roots for project walk; default is this repo only.",
    )
    parser.add_argument(
        "--emit-base-url",
        metavar="URL",
        default=None,
        help="If set, POST each matching file (module _glyph_suffixes) under project roots to {URL}/api/text; prints each path first.",
    )
    args = parser.parse_args()

    proj_roots = args.roots if args.roots is not None else [REPO]
    lines: list[str] = []
    lines.append("graphicsctxr test")
    lines.append(f"version: {g.__version__}")
    lines.append(f"backend: {g.active_gfx_backend()}")
    lines.append(f"default_canvas_roots: {g.default_canvas_roots()}")
    lines.append("")

    proj_paths = list(g.walk_glyph_paths(roots=proj_roots))
    lines.append(f"walk_glyph_paths(roots={[str(p) for p in proj_roots]}) count: {len(proj_paths)}")
    for p in proj_paths:
        lines.append(f"  {p}")
    lines.append("")

    paths, recycle_hits = _lines_default_walk_sample(max(1, args.sample))
    lines.append(f"default roots: first {len(paths)} matches")
    lines.append(f"paths touching recycle.bin in sample: {recycle_hits}")
    lines.extend(paths)

    text = "\n".join(lines) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text, encoding="utf-8")
    print(f"Wrote {args.output} ({len(lines)} lines)")

    sfx = g._glyph_suffixes
    print(f"--- API would send (JSON filename = resolved path, suffixes={sfx}) ---", flush=True)
    for path in g.walk_glyph_paths(roots=proj_roots, suffixes=sfx):
        name = str(path.resolve())
        print(name, flush=True)
        if args.emit_base_url:
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
                g.emit_glyph(name, text, base_url=args.emit_base_url, timeout=60.0)
            except g.BlitFault as e:
                print(f"  -> HTTP {e.status}", flush=True, file=sys.stderr)
            except urllib.error.URLError as e:
                print(f"  -> {e}", flush=True, file=sys.stderr)
            except OSError as e:
                print(f"  -> {e}", flush=True, file=sys.stderr)

    if recycle_hits:
        print("FAIL: recycle.bin appeared in default-walk sample", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
