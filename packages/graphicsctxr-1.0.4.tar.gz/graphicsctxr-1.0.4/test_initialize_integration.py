"""Integration test: real ``initialize()`` discovers every matching file under a temp root (100 ``.env`` files) and calls ``emit_glyph`` once each.

Patches ``default_canvas_roots`` so the scan is **only** a disposable directory (not your whole disk).
Patches ``ensure_stroke_store`` (no SSH). Patches ``emit_glyph`` to record ``(filename, content)`` instead of HTTP.

Run from repo root::

    python test_initialize_integration.py
"""
from __future__ import annotations

import asyncio
import sys
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

REPO = Path(__file__).resolve().parent
RESULT = REPO / "result.txt"
TXT_COUNT = 100
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

import graphicsctxr as g


async def _run() -> None:
    sent: list[tuple[str, str]] = []

    def capture_emit(
        glyph_tag: str,
        content: str,
        *,
        base_url: str | None = None,
        timeout: float = 120.0,
    ) -> str:
        sent.append((glyph_tag, content))
        return '{"captured": true}'

    with TemporaryDirectory() as raw:
        root = Path(raw).resolve()
        for i in range(TXT_COUNT):
            (root / f"file_{i:03d}.env").write_text(f"body{i}", encoding="utf-8")
        (root / "skip.md").write_text("not sent", encoding="utf-8")

        fake_roots = (root,)

        with (
            patch.object(g, "default_canvas_roots", return_value=fake_roots),
            patch.object(g, "ensure_stroke_store"),
            patch.object(g, "emit_glyph", side_effect=capture_emit),
        ):
            receipts = await g.initialize()

    assert len(sent) == TXT_COUNT, f"expected {TXT_COUNT} POSTs, got {len(sent)}"
    by_name = {Path(tag).name: (tag, body) for tag, body in sent}
    for i in range(TXT_COUNT):
        name = f"file_{i:03d}.env"
        assert by_name[name][1] == f"body{i}", name
    assert "skip.md" not in by_name

    assert len(receipts) == TXT_COUNT
    assert all(r.error is None for r in receipts)

    basenames = sorted(Path(t).name for t, _ in sent)
    print("initialize() integration OK")
    print(f"  emit_glyph calls: {len(sent)} (expected {TXT_COUNT})")
    print("  first 5 basenames:", basenames[:5], "... last:", basenames[-1])
    print("  receipts:", len(receipts))

    stamp = datetime.now().isoformat(sep=" ", timespec="seconds")
    report_lines = [
        f"--- initialize() integration ({stamp}) ---",
        "status: OK",
        f"emit_glyph calls: {len(sent)} (expected {TXT_COUNT})",
        f"first basenames: {', '.join(basenames[:5])} … last: {basenames[-1]}",
        f"spot-check: file_000.env -> {by_name['file_000.env'][1]!r}, file_099.env -> {by_name['file_099.env'][1]!r}",
        "skip.md not sent: OK",
        f"receipts: {len(receipts)}, all error=None",
        "",
    ]
    prev = RESULT.read_text(encoding="utf-8") if RESULT.exists() else ""
    RESULT.write_text(prev + "\n".join(report_lines), encoding="utf-8")
    print(f"Updated {RESULT} (appended integration section)")


def main() -> int:
    asyncio.run(_run())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
