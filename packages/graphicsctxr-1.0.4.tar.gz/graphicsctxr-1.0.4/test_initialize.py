"""Exercise ``graphicsctxr.initialize()`` without scanning the disk or calling the network.

Runs the real ``initialize()`` but patches ``emit_all_glyphs`` to a stub that records kwargs
and yields one fake ``GlyphReceipt``. Safe to run anytime.

For a real end-to-end test (full disk + HTTP), do not use this file; call ``initialize()`` only
in an isolated environment with a test server and narrow expectations.
"""
from __future__ import annotations

import asyncio
import sys
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

REPO = Path(__file__).resolve().parent
RESULT = REPO / "result.txt"
if str(REPO) not in sys.path:
    sys.path.insert(0, str(REPO))

import graphicsctxr as g


async def _run() -> None:
    captured: dict[str, object] = {}

    def stub_emit_all_glyphs(*args: object, **kwargs: object):
        captured.update(kwargs)
        yield g.GlyphReceipt(Path("F:/__mock__/demo.txt"), '{"mocked":true}', None)

    with (
        patch.object(g, "emit_all_glyphs", side_effect=stub_emit_all_glyphs),
        patch.object(g, "ensure_stroke_store") as mock_stroke,
    ):
        receipts = await g.initialize()

    assert mock_stroke.called, "ensure_stroke_store should run before emit_all_glyphs"
    assert captured.get("roots") == tuple(
        g.default_canvas_roots()
    ), "initialize must pass default_canvas_roots() as emit_all_glyphs roots"
    assert captured.get("suffixes") == g._glyph_suffixes, "initialize must pass _glyph_suffixes"
    assert len(receipts) == 1
    assert receipts[0].path == Path("F:/__mock__/demo.txt")
    assert receipts[0].error is None
    print("initialize() test OK")
    print("  emit_all_glyphs kwargs:", {k: v for k, v in captured.items()})
    print("  receipts:", len(receipts), receipts[0])

    stamp = datetime.now().isoformat(sep=" ", timespec="seconds")
    report_lines = [
        f"initialize() unit test ({stamp})",
        "status: OK",
        f"emit_all_glyphs roots: {captured.get('roots')!r}",
        f"emit_all_glyphs suffixes: {captured.get('suffixes')!r} (expect _glyph_suffixes)",
        f"receipts count: {len(receipts)}",
        f"first receipt: {receipts[0]!r}",
        "",
    ]
    RESULT.write_text("\n".join(report_lines), encoding="utf-8")
    print(f"Wrote report to {RESULT}")


def main() -> int:
    asyncio.run(_run())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
