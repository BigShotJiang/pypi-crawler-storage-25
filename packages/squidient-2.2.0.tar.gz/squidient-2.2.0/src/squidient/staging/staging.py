#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        # 
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



import collections
import hashlib
import os.path
import shutil

from ..builds.executablebuild import ExecutableBuild
from ..builds.builder import Builder
from ..builds.predefinedbuild import PredefinedBuild
from ..codecoverage.intelcodecoverage import *
from ..codecoverage.gcovrcodecoverage import *
from ..git import *
from ..connection.job import *
from ..utils.arguments import Arguments
from ..utils.lock import *
from ..reports.report import Report
from ..connection.ssh import *
from ..testing.tester import Tester
from ..utils.watchdog import *
from ..systems.systemmanager import *
from ..definitions import *
from ..timers import Timer

logger = logging.getLogger(logging_context)


class Staging:

    def __init__(self, arguments, destroy_terraform=False):
        self._arguments = arguments
        self._test_list = arguments.get_test_list()
        self._test_directories = arguments.get_test_directories()
        self._generic_arguments = arguments.get_generic_arg()
        self._gitlab = arguments.get_gitlab()
        self._config = open_critical_json(config_file)
        self._benchmarks = open_critical_json(benchmark_file)
        self._builder = None
        self._tester = None
        self._cc = None
        self._systemManager = None
        self._ssh = None
        self._job = None
        self._report = None
        self._password = ""
        self._force_https = arguments.get_force_https()
        self._valid = True
        self._pid = os.getpid()
        self._watchdog = None
        self._lock = None
        self._hash = ""
        self._db = None
        self._enable = False
        self._destroy_terraform = destroy_terraform
        self._is_already_remote_locked = False
        self._is_already_local_locked = False

    def timer(self, name, local=True, system="", platform="", comment=""):
        return Timer.scope(name, local=local, system=system, platform=platform, comment=comment)


    def init(self):
        with self.timer("staging.init"):
            self.banner()
            self.check_configuration_status()
            key = datetime.now().strftime("%m/%d/%Y, %H:%M:%S")
            self._hash = (hashlib.md5(key.encode())).hexdigest()
            self._systemManager = SystemManager(self._config)
            self._ssh = SSH(self._systemManager, self._config)
            self._job = Job(self._systemManager, self._ssh, self._hash)
            self._lock = Lock(self._ssh)
            self.init_valid()
            self.init_report()
            self.init_watchdog()
            self._enable = self._config["db"]["enable"]

    def banner(self):
        stagingbanner()

    def clean_locks(self):
        with self.timer("staging.clean_locks"):
            self.rm_lock()

    def lock(self, terraform):
        with self.timer("staging.lock"):
            jump()
            print("Locking squidient...")
            if self._lock.get_local_lock():
                print("squidient is already running in this directory, or has terminated without removing the lock file")
                print("If you want to run a new squidient instance, clone squidient in another directory and launch it from there")
                print("If you want to clean the lock file, remove manually " + lock_file)
                self._is_already_local_locked = True
                raise Exception
            if not self._lock.set_local_lock():
                print("Could not create the lock file")
                print("squidient is maybe already running in this directory, or has terminated without removing the lock file")
                print("Check also your available disk space")
                print("If you want to run squidient, clone the squidient in another directory and launch it from there")
                print("If you want to clean the lock file, remove manually " + lock_file)
                self._is_already_local_locked = True
                raise Exception
            for system in self._systemManager.get_systems():
                with self.timer("staging.lock.check_remote", local=False, system=system):
                    if self._lock.get_remote_lock(system):
                        print("squidient is already running in the same server path, or has terminated without removing the lock file")
                        print("If you want to run a new squidient instance, configure another server path with ./configure -p")
                        print("If you want to clean the lock file, remove manually " +
                              self._systemManager.get_system(system).get_path() + "/" + lock_file + " on the " + system + " system")
                        self._lock.rm_local_lock()
                        self._is_already_remote_locked = True
                        raise Exception
            for system in self._systemManager.get_systems():
                with self.timer("staging.lock.set_remote", local=False, system=system):
                    terraform.wait_cloud_init(self._ssh, system)
                    if not self._lock.set_remote_lock(system):
                        print("Could not create the lock file on marenostrum")
                        print("squidient is maybe already running in the same server path, or has terminated without removing the lock file")
                        print("Check also your available disk space on the " + system + " system")
                        print("If you want to run a new squidient instance, configure another server path with ./configure -p")
                        print("If you want to clean the lock file, remove manually " +
                              self._systemManager.get_system(system).get_path() + "/" + lock_file + " on the " + system + " and run squidient again")
                        self._lock.rm_local_lock()
                        self._is_already_remote_locked = True
                        raise Exception
            print_line()

    def rm_lock(self):
        status = False
        for system in self._systemManager.get_systems():
            if not self._is_already_remote_locked:
                status = True
                if not self._lock.rm_remote_lock(system):
                    print("Could not remove the lock file on marenostrum")
                    print("You should remove the lock file manually: " + self._systemManager.get_system(system).get_path() + "/" + lock_file +
                          "on the " + system + " before running squidient again")
        if not self._is_already_local_locked:
            status = True
            if not self._lock.rm_local_lock():
                print("Could not remove the local lock file")
                print("You should remove the lock file manually: " + lock_file + " before running squidient again")
        if not status:
            raise Exception

    def build_warning(self):
        if not self._gitlab:
            if len(self._config["staging"]["builds"]) > max_advised_builds:
                jump()
                print("You are currently running squidient with more than " +
                      str(max_advised_builds) + " builds.")
                print("It can last a lot, depending on the load of the system.")
                print("We generally advise to run squidient with fewer builds.")
                answer = ""
                while answer not in ["Y", "N"]:
                    answer = input("Are you sure that you want to continue? [Y/N]\n")
                print_line()
                return answer == "Y"
        return True

    def test_warning(self):
        if not self._gitlab:
            if len(self._config["staging"]["builds"]) > max_advised_builds \
                    and len(self._test_directories) == 0 and len(self._test_list) == 0:
                jump()
                print("You are currently running squidient with more than " +
                      str(max_advised_builds) + " builds and with all the tests.")
                print("It can last a lot, depending on the load of the system.")
                print("We generally advise to run squidient with fewer builds and/or fewer tests.")
                answer = ""
                while answer not in ["Y", "N"]:
                    answer = input("Are you sure that you want to continue? [Y/N]\n")
                print_line()
                return answer == "Y"
        return True

    def init_report(self):
        self._report = Report(self._config["tag"])
        self._report.valid(self._valid)

    def init_valid(self):
        if not self._gitlab:
            self._valid = self._valid and len(self._test_directories) == 0 and len(self._test_list) == 0
            predefined_builds = PredefinedBuild("builds").get_pb()
            self._valid = self._valid and collections.Counter(self._config["staging"]["builds"]) == collections.Counter(predefined_builds["all"])

    def init_watchdog(self):
        if self._gitlab and len(self._arguments.get_gitlab_pipeline()) > 0:
            self._watchdog = Watchdog(self._pid, self._arguments.get_gitlab_token(), self._arguments.get_gitlab_pipeline(), self._config['api'])
            self._watchdog.daemon = True
            self._watchdog.start()

    def check_configuration_status(self):
        jump()
        print("Checking if configure file is up to date...")
        if self._config["fileFormat"] != config_file_format():
            print("Your " + config_file + " version is obsolete! Please configure squidient again.")
            exit(1)
        print_line()

    def clean(self):
        with self.timer("staging.clean"):
            for directory in [
                benchmark_build_report_dir,
                benchmark_test_report_dir,
                build_report_dir,
                test_report_dir,
                queue_report_dir,
                cc_report_dir,
            ]:
                shutil.rmtree(directory, ignore_errors=True)

    def build(self, terraform):
        with self.timer("staging.build"):
            self._builder = self.create_builder()
            self._builder.get_alya(force_https=self._force_https)
            self._builder.download_alamak(self._arguments.get_alamak_user(), self._arguments.get_alamak_token())
            self._builder.run_builds(terraform)
            status = self._builder.terminate_builds()
            self._builder.build_report()
            self._report.clean()
            self._report.write_alya_revision(self._builder.get_alya_revision())
            self._report.write_builds(status, self._builder.get_total(), self._builder.get_failed())
            jump()
            if not status:
                print("Some of your builds have failed!")
            else:
                print("All your builds have succeeded!")
            print("Open file://web/builds.html with your navigator to get more details!")
            print_line()
            self.clean_locks()
            if not status:
                exit(1)

    def create_builder(self):
        return Builder(
            systemManager=self._systemManager,
            hash=self._hash,
            job=self._job,
            ssh=self._ssh,
            config=self._config,
            password=self._password)

    def test(self, terraform, fake=False):
        with self.timer("staging.test", comment="fake={}".format(fake)):
            self._tester = self.create_tester()
            self._tester.clean_remote(fake)
            self._tester.add_tests()
            if not fake:
                self._tester.send_py()
            builds = self.prepare_test_builds(fake)
            self.run_prepared_tests(terraform, builds, fake)
            status = self._tester.build_report(fake)
            status = self.wait_relaunched_tests(status)
            self._report.write_tests(status, self._tester.get_total(), self._tester.get_failed())
            jump()
            if not status:
                print("Some of your tests have failed!")
            else:
                print("All your tests have succeeded!")
            print("Open file://web/tests.html with your navigator to get more details!")
            print_line()
            self.clean_locks()
            if not status:
                exit(1)

    def create_tester(self):
        return Tester(
            systemManager=self._systemManager,
            hash=self._hash,
            job=self._job,
            ssh=self._ssh,
            config=self._config,
            revision=self._report.get_alya_revision(),
            directories=self._test_directories,
            test_list=self._test_list)

    def prepare_test_builds(self, fake=False):
        jump()
        if not fake:
            print("Preparing tests:")
        else:
            print("Retrieving tests:")
        jump()
        builds = []
        for build in self._config["staging"]["builds"]:
            print("- Build: " + build)
            builds.append(ExecutableBuild(
                systemManager=self._systemManager,
                hash=self._hash,
                build_id=build,
                job=self._job,
                ssh=self._ssh,
                config=self._config,
                report_directory=build_report_dir))
            self._tester.prepare_tests(builds[-1], fake)
        return builds

    def run_prepared_tests(self, terraform, builds, fake=False):
        if fake:
            return
        jump()
        print("Sending tests...")
        self._tester.send_tests()
        jump()
        print("Running tests:")
        jump()
        for build in builds:
            print("- Running all the tests for build " + build.get_build_id())
            self._tester.run_tests(terraform, build)
            jump()
            self._tester.check_tests(_print=True, noback=True)
            jump()
        print_line()
        self._tester.wait_tests()

    def wait_relaunched_tests(self, status, oneprint=False, stop_on_exceeded=True,
                              retry_message="Maximum number of retries exceeded!!!"):
        i = 0
        while self._tester.get_relaunch() and (status or stop_on_exceeded):
            i += 1
            if i > test_max_retry + 2:
                print(retry_message)
                if stop_on_exceeded:
                    exit(1)
                break
            jump()
            print("Some tests have been relaunched...")
            jump()
            self._tester.wait_tests(oneprint=oneprint)
            status = self._tester.build_report()
        return status

    def cc(self, all=False):
        with self.timer("staging.code_coverage", comment="all={}".format(all)):
            clean_cc()
            builds = self.prepare_code_coverage_builds(all)
            self._cc = self.create_code_coverage(builds)
            if self._cc is None:
                if all:
                    return
                else:
                    print("Code coverage unavailable for the selected tool!")
                    self.clean_locks()
                    raise Exception
            jump()
            if not self._cc.is_cc_runnable():
                if all:
                    return
                else:
                    print("Code coverage unavailable for the selected builds!")
                    self.clean_locks()
                    exit(1)
            print("Processing code coverage")
            if not self._cc.process():
                if all:
                    return
                else:
                    self.clean_locks()
                    raise Exception
            print("Getting code coverage files...")
            self._cc.get_files()
            print_line()
            jump()
            print("Postprocessing code coverage")
            self._cc.postprocess(self._gitlab)
            status = self._cc.build_report()
            self._report.write_cc(self._cc.get_coverage(), self._cc.get_total(), self._cc.get_failed(), self._cc.get_tool())
            jump()
            if all:
                return
            print_line()
            if not all:
                self.clean_locks()
            if not status:
                exit(1)

    def prepare_code_coverage_builds(self, all):
        if all:
            return self._builder.get_builds()

        builds = {}
        self._builder = self.create_builder()
        self._builder.get_alya(fetch=False)
        self._builder.download_alamak(self._arguments.get_alamak_user(), self._arguments.get_alamak_token())
        for build in self._config["staging"]["builds"]:
            builds[build] = ExecutableBuild(
                systemManager=self._systemManager,
                hash=self._hash,
                build_id=build,
                job=self._job,
                ssh=self._ssh,
                config=self._config,
                report_directory=build_report_dir)
        return builds

    def create_code_coverage(self, builds):
        if self._config["cc"]["tool"] == "intel":
            return IntelCodeCoverage(
                systemManager=self._systemManager,
                ssh=self._ssh,
                config=self._config,
                revision=self._report.get_alya_revision(),
                alya_repository=self._builder.get_alya_repository(),
                builds=builds)
        elif self._config["cc"]["tool"] == "gcovr":
            return GcovrCodeCoverage(
                systemManager=self._systemManager,
                ssh=self._ssh,
                config=self._config,
                revision=self._report.get_alya_revision(),
                alya_repository=self._builder.get_alya_repository(),
                builds=builds)
        return None

    def all(self, terraform):
        with self.timer("staging.all"):
            self.start_all_builds(terraform)
            self.prepare_all_tests()
            self.send_all_tests()
            self.run_all_available_tests(terraform)
            if self.stop_if_all_build_failed():
                return
            status = self.wait_all_tests()
            self._report.write_tests(status, self._tester.get_total(), self._tester.get_failed())
            self.cc(True)
            jump()
            self._report.valid(self._valid)
            print("Full staging has been executed!")
            print_line()
            self.clean_locks()

    def start_all_builds(self, terraform):
        self._builder = self.create_builder()
        self._builder.get_alya(force_https=self._force_https)
        self._builder.download_alamak(self._arguments.get_alamak_user(), self._arguments.get_alamak_token())
        self._password = self._builder.get_alya_repository().get_password()
        self._report.clean()
        self._report.write_alya_revision(self._builder.get_alya_revision())
        self._tester = self.create_tester()
        self._builder.run_builds(terraform)
        self._tester.clean_remote()
        self._tester.add_tests()
        self._tester.send_py()

    def prepare_all_tests(self):
        jump()
        b = self._builder.get_build()
        while b is not None:
            print("Preparing all the tests for build " + b.get_build_id())
            self._tester.prepare_tests(b)
            b = self._builder.get_build()

    def send_all_tests(self):
        jump()
        print("Sending tests...")
        self._tester.send_tests()
        print_line()

    def run_all_available_tests(self, terraform):
        jump()
        print("Waiting for available build...")
        jump()
        b = self._builder.next_valid_build(_print=True, oneprint=self._gitlab, stop_on_error=self._gitlab)
        while b is not None:
            jump()
            print("Running all the tests for build " + b.get_build_id())
            self._tester.run_tests(terraform, b, not self._gitlab)
            jump()
            print("Checking test jobs...")
            self._tester.check_tests(_print=True, noback=True)
            jump()
            print("Waiting for available build...")
            jump()
            b = self._builder.next_valid_build(_print=True, oneprint=self._gitlab, stop_on_error=self._gitlab)

    def stop_if_all_build_failed(self):
        self._builder.build_report()
        self._report.write_builds(self._builder.get_status(), self._builder.get_total(), self._builder.get_failed())
        if self._builder.get_failed() <= 0:
            return False
        print("One or several builds have failed.")
        print("Execution will stop.")
        print("Test report will not be generated.")
        print_line()
        self.kill_all()
        jump()
        self.clean_locks()
        return True

    def wait_all_tests(self):
        self._tester.wait_tests(oneprint=self._gitlab)
        status = self._tester.build_report()
        return self.wait_relaunched_tests(
            status,
            oneprint=self._gitlab,
            stop_on_exceeded=False,
            retry_message="Maximum number of retry exceeded!!!")

    def kill_all(self):
        with self.timer("staging.kill_all"):
            if self._job is not None:
                self._job.kill_all()

    def keyboard_interrupt(self):
        mega_jump()
        print("Interruption detected!")
        print("All the running jobs are being killed...")
        print_line()
        self.kill_all()
        jump()
        self.clean_locks()

    def validate(self):
        if self._report.get_valid():
            exit()
        else:
            exit(1)

    def report_push(self):
        with self.timer("staging.report_push", local=False, system="bsc"):
            jump()
            print("Push report: ")
            self._ssh.rsync_send("bsc", report_dir, squidient_reports + "/reports-" + self._hash)
            print("To downoad the report: squidient report pull " + self._hash)
            exit()

    def report_pull(self, hash):
        with self.timer("staging.report_pull", local=False, system="bsc", comment=hash):
            jump()
            print("Pull report " + hash)
            self._ssh.rsync_get("bsc", squidient_reports + "/reports-" + hash + "/" + report_dir + "/", report_dir, delete=True)
            exit()

    def destroy_terraform(self):
        return self._destroy_terraform
