#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the        # 
#  GNU General Public License for more details.                         #
#                                                                       #
#  You should have received a copy of the GNU General Public License    #
#  along with squidient. If not, see <https://www.gnu.org/licenses/>.   #
#                                                                       #
#########################################################################



from .codecoverage import *
import os

logger = logging.getLogger(logging_context)


def _read_lines(path):
    with open(path, "r", encoding="utf-8") as html_file:
        return html_file.readlines()


def _quoted_field(line, field):
    fields = line.split('"')
    if len(fields) > field - 1:
        return fields[field - 1]
    return ""


def _html_table_values(path, include_title=True):
    values = []
    for line in _read_lines(path):
        if "TD ALIGN" not in line:
            continue
        if not include_title and "title" in line:
            continue
        values.append(line.split(">", 1)[1].split("<", 1)[0].replace(" ", "").strip())
    return values


def _source_rows(path):
    rows = []
    for line in _read_lines(path):
        if "title" not in line or ".f90" not in line:
            continue
        fields = line.split(">")
        rows.append(
            {
                "file": fields[2].replace("</a", "").strip() if len(fields) > 2 else "",
                "path": _quoted_field(line, 6),
                "url": _quoted_field(line, 4),
            }
        )
    return rows


def _git_blame_revisions(blame_output):
    revisions = []
    for line in blame_output.splitlines():
        parts = line.split(" ", 1)
        if parts and parts[0]:
            revisions.append(parts[0])
    return revisions


def _find_html_anchor_line(lines, anchor):
    needle = 'name="' + anchor + '"'
    for index, line in enumerate(lines):
        if needle in line:
            return index
    return None


def _is_uncovered_html_line(line):
    return (
        "background-color: #ffff99" in line
        or "background-color: #ffcccc" in line
        or "background-color: #fafad2" in line
    )


def _highlight_html_line(path, index, color):
    lines = _read_lines(path)
    ending = "\n" if lines[index].endswith("\n") else ""
    content = lines[index].rstrip("\n")
    lines[index] = '<font color="' + color + '"><strong>' + content + "</strong></font>" + ending
    with open(path, "w", encoding="utf-8") as html_file:
        html_file.writelines(lines)


class IntelCodeCoverage(CodeCoverage):

    def __init__(self, systemManager, ssh, config, revision, alya_repository, builds):
        super().__init__(systemManager, ssh, config, revision, alya_repository, builds)

    def process(self):
        with self.platform_timer("code_coverage.process", comment=self._tool):
            print("\tMerging code coverage files...")
            if not self.merge():
                jump()
                print("\tMerging has failed!")
                print_line()
                return False
            print("\tGenerating code coverage html files...")
            if not self.codecov():
                jump()
                print("\tCode coverage has failed!")
                print_line()
                return False
            return True

    def merge(self):
        with self.platform_timer("code_coverage.intel.merge"):
            spi = ""
            dpis = "-a"
            self._module_cmd = "module purge && "
            for module in self._modules:
                self._module_cmd += "module load " + module + " && "
            for b in self._builds:
                if self._builds[b].get_system() == self._system and self._builds[b].get_platform() == self._platform:
                    if self._builds[b].get_code_coverage():
                        if self._builds[b].check_build_status():
                            cc_path = remote_cc_dir + "/" + self._builds[b].get_build_id()
                            dpis += " " + self._builds[b].get_build_id() + "/pgopti.dpi"
                            if spi == "":
                                spi = self._builds[b].get_build_id() + "/pgopti.spi"
                            with self.platform_timer("code_coverage.intel.merge.build", comment=b):
                                self._ssh.ssh(system=self._system, platform=self._platform, cmd=self._module_cmd + "profmerge",
                                              server_path=True, path=cc_path)
            self._spi = spi
            if spi == "":
                return False
            return self._ssh.ssh(system=self._system, platform=self._platform, cmd=self._module_cmd + "profmerge " + dpis,
                                 server_path=True, path=remote_cc_dir)

    def codecov(self):
        with self.platform_timer("code_coverage.intel.codecov"):
            return self._ssh.ssh(system=self._system, platform=self._platform,
                                 cmd=self._module_cmd + "codecov -srcroot " + self.alya_path() + " -spi " + self._spi,
                                 server_path=True, path=remote_cc_dir)

    def get_files(self):
        with self.platform_timer("code_coverage.download", comment=self._tool):
            os.makedirs(cc_report_dir, exist_ok=True)
            if not self._ssh.rsync_get(system=self._system, platform=self._platform,
                                       remote=remote_cc_dir + "/CODE_COVERAGE.HTML", local=cc_report_dir, delete=True,
                                       server_path=True, critical=True):
                raise Exception
            if not self._ssh.rsync_get(system=self._system, platform=self._platform, remote=remote_cc_dir + "/CodeCoverage",
                                       local=cc_report_dir, delete=True, server_path=True, critical=True):
                raise Exception

    def postprocess(self, _print):
        with self.timer("code_coverage.postprocess", comment=self._tool):
            print("\tSetting up input file list...")
            self.set_html_files()
            print("\tBuilding code coverage summary...")
            self.summary()
            self.details(True, _print=_print)
            self.details(False, _print=_print)

    def set_html_files(self):
        files = []
        for line in _read_lines(cc_report_dir + "/CODE_COVERAGE.HTML"):
            if "HTML" in line:
                files.append(_quoted_field(line, 2))
        self._summary = cc_report_dir + "/" + files[0]
        self._covered = cc_report_dir + "/" + files[1]
        self._uncovered = cc_report_dir + "/" + files[2]

    def summary(self):
        with self.timer("code_coverage.intel.summary"):
            data = _html_table_values(self._summary)
            d = []
            i = 0
            for type in "files", "functions", "blocks":
                c = {}
                c["type"] = type
                c["total"] = int(data[0 + i].replace(",", ""))
                c["covered"] = int(data[1 + i].replace(",", ""))
                c["uncovered"] = int(data[2 + i].replace(",", ""))
                c["coverage"] = float(data[3 + i])
                if type == "blocks":
                    self._codecoverage = c["coverage"]
                i += 4
                d.append(c)
            self._report["summary"] = d

    def details(self, covered, _print=True):
        with self.timer("code_coverage.intel.details", comment="covered={}".format(covered)):
            if covered:
                print("Building code coverage details (covered files)...")
                input = self._covered
            else:
                print("Building code coverage details (uncovered files)...")
                input = self._uncovered

            rows = _source_rows(input)
            data = _html_table_values(input, include_title=False)
            self._total = len(rows)
            for i in range(0, self._total):
                f = {}
                if rows[i]["file"] == "":
                    continue
                f["name"] = rows[i]["file"]
                if _print:
                    print("File: " + f["name"])
                path = rows[i]["path"].split("alya/", 1)[1]
                f["path"] = path
                realPath = self.alya_realpath(path)
                f["realPath"] = realPath
                f["url"] = rows[i]["url"]
                r = [0, 0, 0]
                f["modified"] = self.is_modified(realPath)
                r = self.lines(f["name"], realPath, rows[i]["url"])
                f["covered"] = covered
                if covered:
                    f["functions"] = int(data[0 + (i * 6)].replace(",", ""))
                    f["coveredFunctions"] = int(data[1 + (i * 6)].replace(",", ""))
                    f["functionCoverage"] = float(data[2 + (i * 6)])
                    f["blocks"] = int(data[3 + (i * 6)].replace(",", ""))
                    f["coveredBlocks"] = int(data[4 + (i * 6)].replace(",", ""))
                    f["blockCoverage"] = float(data[5 + (i * 6)])
                    f["newLines"] = r[0]
                    f["coveredNewLines"] = r[1]
                    f["uncoveredNewLines"] = r[2]
                else:
                    f["functions"] = int(data[0 + (i * 2)].replace(",", ""))
                    f["coveredFunctions"] = 0
                    f["functionCoverage"] = 0
                    f["blocks"] = int(data[1 + (i * 2)].replace(",", ""))
                    f["coveredBlocks"] = 0
                    f["blockCoverage"] = 0
                    f["newLines"] = r[0]
                    f["coveredNewLines"] = r[1]
                    f["uncoveredNewLines"] = r[2]
                self._report["files"].append(f)

    def lines(self, file, path, url):
        return self.lines_git(file, path, url)

    def alya_realpath(self, path):
        self.cd_push_alya()
        realpath = os.path.realpath(path)
        self.cd_pop_alya()
        return realpath

    def is_modified(self, path):
        self.cd_push_alya()
        modified = not command("git diff --exit-code " + self._cc_revision + " -- " + path).success
        self.cd_pop_alya()
        return modified

    def lines_git(self, file, path, url):
        with self.timer("code_coverage.intel.highlight_lines", comment=file):
            uncovered_new_lines = 0
            covered_new_lines = 0
            try:
                self.cd_push_alya()
                logger.debug("IN ALYA")
                revisions_master = set(
                    _git_blame_revisions(command("git blame " + self._cc_revision + " -- " + path).stdout)
                )
                logger.debug("BLAME OK")
                logger.debug("SPLIT OK")
                lines = _git_blame_revisions(command("git blame " + path).stdout)
                url2 = cc_report_dir + "/CodeCoverage/" + url.replace(".HTML", "_SRC.HTML")
                i = 1
                self.cd_pop_alya()
                for line in lines:
                    if line not in revisions_master:
                        color = "green"
                        html_lines = _read_lines(url2)
                        index = _find_html_anchor_line(html_lines, "l" + str(i))
                        if index is None:
                            i += 1
                            continue
                        html_line = html_lines[index]
                        runend = "call runend" in html_line
                        uncovered = _is_uncovered_html_line(html_line)
                        if uncovered:
                            uncovered_new_lines += 1
                            color = "red"
                            if runend:
                                color = "blue"
                            self._status = False
                        else:
                            covered_new_lines += 1
                        _highlight_html_line(url2, index, color)
                    i += 1
            except:
                logger.warning("Code coverage: file " + file + " line highlighting failed")
            r = [covered_new_lines + uncovered_new_lines, covered_new_lines, uncovered_new_lines]
            if uncovered_new_lines > 0:
                self._failed += 1
            return r

    def cd_push_alya(self):
        os.chdir(self._current_path + "/" + alya_dir)
        logger.debug(os.getcwd())

    def cd_pop_alya(self):
        os.chdir(self._current_path)
