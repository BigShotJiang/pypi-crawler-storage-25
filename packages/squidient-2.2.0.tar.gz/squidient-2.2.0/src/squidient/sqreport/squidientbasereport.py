#########################################################################
#                                                                       #
#  This file is part of squidient.                                      #
#                                                                       #
#  squidient is free software: you can redistribute it and/or modify    #
#  it under the terms of the GNU General Public License as published by #
#  the Free Software Foundation, either version 3 of the License, or    #
#  (at your option) any later version.                                  #
#                                                                       #
#  squidient is distributed in the hope that it will be useful,         #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of       #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.                 #
#                                                                       #
#########################################################################

from ..compare.compare import *


class SquidientBaseReport:

    # _____________________________________
    def __init__(self, case):

        self._case = case
        self._file = case + ".json"

        self._json = None
        self._test = {}

        self._status = True
        self._error = "OK"

        self._cwd = os.getcwd()
        self._base_dir = os.path.join("base", "1p")

    # _____________________________________
    def open_json(self):

        self._json = open_json(self._file)

    # _____________________________________
    def init_test(self):
        """
        Implemented in subclasses.
        """
        raise NotImplementedError

    # _____________________________________
    def save_json(self):

        save_json(self._test, "report.json")

    # _____________________________________
    def present_file(self, file_path):

        return os.path.isfile(file_path)

    # _____________________________________
    def compare(self, base, test, method, tolerance, rows=None, cols=None):

        c = Compare(base, test, method, tolerance, rows, cols)

        return c.compare()

    # _____________________________________
    def update_error(self, status, error):

        if status:
            return

        previous_error = self._error
        self._status = False

        if previous_error == "OK":
            self._error = error
            return

        if previous_error == error:
            return

        if "tolerance" in previous_error:
            self._error = error
            return

        if "tolerance" in error:
            return

        self._error = "mixed"

    # _____________________________________
    def _get_rows_cols_tolerance(self, file_cfg):

        rows = file_cfg.get("rows")
        cols = file_cfg.get("cols")
        tolerance = file_cfg.get("tolerance", 0)

        return rows, cols, tolerance

    # _____________________________________
    def _get_paths(self, file_cfg):

        relative_path = file_cfg["file"]
        base_path = os.path.join(self._base_dir, relative_path)
        test_path = relative_path

        return base_path, test_path

    # _____________________________________
    def _empty_file_test(self, file_cfg):

        return {
            "file": file_cfg["file"],
            "status": True,
            "error": "OK",
            "maxAbs": 0,
            "maxRel": 0,
            "maxError": None,
            "differences": 0,
            "total": 0,
            "method": file_cfg["method"],
            "tolerance": file_cfg.get("tolerance", 0),
        }

    # _____________________________________
    def _apply_compare_result(self, test, result):

        test["maxAbs"] = result["maxAbs"]
        test["maxRel"] = result["maxRel"]
        test["maxError"] = result["maxError"]
        test["differences"] = result["differences"]
        test["total"] = result["total"]
        test["status"] = result["status"]
        test["error"] = result["error"]
        test["tolerance"] = result["tolerance"]

        return test

    # _____________________________________
    def _validate_one_file(self, file_cfg):

        test = self._empty_file_test(file_cfg)
        rows, cols, tolerance = self._get_rows_cols_tolerance(file_cfg)
        base_path, test_path = self._get_paths(file_cfg)

        if not self.present_file(base_path):
            test["status"] = False
            test["error"] = "missing base"
            return test

        if not self.present_file(test_path):
            test["status"] = False
            test["error"] = "missing test file"
            return test

        try:
            result = self.compare(
                base_path,
                test_path,
                test["method"],
                tolerance,
                rows,
                cols,
            )
        except Exception as e:
            test["status"] = False
            test["error"] = "comparison"
            print(e)
            return test

        return self._apply_compare_result(test, result)

    # _____________________________________
    def validate_files(self):

        for file_cfg in self._json.get("comparisons", []):

            test = self._validate_one_file(file_cfg)

            self.update_error(test["status"], test["error"])

            self._test["files"].append(test)

        self._test["status"] = self._status
        self._test["error"] = self._error

    # _____________________________________
    def find_file_config(self, test_file):

        for file_cfg in self._json.get("comparisons", []):
            if file_cfg.get("file") == test_file:
                return file_cfg

        return None