import csv
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


timer_directory = "timers"


class Timer:
    _output_file = None
    _stack = threading.local()
    _fieldnames = [
        "id",
        "parent",
        "type",
        "local",
        "system",
        "platform",
        "start",
        "end",
        "duration",
        "status",
        "comment",
    ]

    def __init__(self, type, parent=None, local=True, system="", platform="", comment=""):
        self._id = uuid.uuid4().hex
        self._type = type
        self._parent = parent
        self._local = local
        self._system = system or ""
        self._platform = platform or ""
        self._comment = comment or ""
        self._start = None
        self._end = None
        self._start_time = None
        self._duration = None
        self._status = "running"
        self.output_file = self._ensure_output_file()

    @classmethod
    def _ensure_output_file(cls):
        timer_dir = Path(timer_directory)
        timer_dir.mkdir(parents=True, exist_ok=True)
        if cls._output_file is None:
            timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            cls._output_file = timer_dir / "{}.csv".format(timestamp)
            with cls._output_file.open("w", encoding="utf-8", newline="") as output:
                writer = csv.DictWriter(output, fieldnames=cls._fieldnames)
                writer.writeheader()
        return cls._output_file

    @classmethod
    def _active_stack(cls):
        if not hasattr(cls._stack, "timers"):
            cls._stack.timers = []
        return cls._stack.timers

    @classmethod
    def current(cls):
        stack = cls._active_stack()
        if stack:
            return stack[-1]
        return None

    @classmethod
    @contextmanager
    def scope(cls, type, local=True, system="", platform="", comment=""):
        parent = cls.current()
        timer = cls(
            type=type,
            parent=parent.get_id() if parent is not None else "",
            local=local,
            system=system,
            platform=platform,
            comment=comment,
        )
        timer.start()
        cls._active_stack().append(timer)
        try:
            yield timer
        except Exception:
            timer.stop(status="error")
            raise
        else:
            timer.stop(status="ok")
        finally:
            stack = cls._active_stack()
            if stack and stack[-1] is timer:
                stack.pop()
            elif timer in stack:
                stack.remove(timer)

    def get_id(self):
        return self._id

    def start(self):
        self._start = self._now()
        self._start_time = time.time()
        return self

    def stop(self, status="ok"):
        if self._end is not None:
            return
        self._end = self._now()
        self._duration = time.time() - self._start_time
        self._status = status
        self._write_row()

    def _write_row(self):
        with self.output_file.open("a", encoding="utf-8", newline="") as output:
            writer = csv.DictWriter(output, fieldnames=self._fieldnames)
            writer.writerow(
                {
                    "id": self._id,
                    "parent": self._parent,
                    "type": self._type,
                    "local": self._local,
                    "system": self._system,
                    "platform": self._platform,
                    "start": self._start,
                    "end": self._end,
                    "duration": "{:.6f}".format(self._duration),
                    "status": self._status,
                    "comment": self._comment,
                }
            )

    def write(self, text):
        with self.output_file.open("a", encoding="utf-8") as output:
            output.write(text + "\n")

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
