import json
import traceback
from pathlib import Path
from loguru import logger
# from dotenv import load_dotenv
# import os

PROJ_ROOT = Path(__file__).resolve().parents[1]
logger.info(f"PROJ_ROOT path is: {PROJ_ROOT}")

# load_dotenv()
# WORKDIR = os.getenv('WORKDIR')

# DATA_DIR = PROJ_ROOT / "data"
# RAW_DATA_DIR = DATA_DIR / "raw"
# INTERIM_DATA_DIR = DATA_DIR / "interim"
# PROCESSED_DATA_DIR = DATA_DIR / "processed"
# EXTERNAL_DATA_DIR = DATA_DIR / "external"

# MODELS_DIR = PROJ_ROOT / "models"

# REPORTS_DIR = PROJ_ROOT / "reports"
# FIGURES_DIR = REPORTS_DIR / "figures"

# If tqdm is installed, configure loguru with tqdm.write
# https://github.com/Delgan/loguru/issues/135
try:
    from tqdm import tqdm

    logger.remove(0)
    logger.add(lambda msg: tqdm.write(msg, end=""), colorize=True)
except ModuleNotFoundError:
    pass


def write_error_sentinel(
    metadata_filename: str,
    serial_number: str,
    dataset_uid: int,
    analysis_id: int,
    error: Exception,
) -> None:
    """Write an error sentinel JSON so the result handler can mark the job as failed.

    Called from a top-level try/except wrapper in each CLI entry point.
    The result handler checks metadata['status'] == 'failed' and records the error.
    """
    sentinel = {
        "serial_number": serial_number,
        "dataset_uid": dataset_uid,
        "pipeline_stage": "analysis",
        "analysis_id": analysis_id,
        "status": "failed",
        "error_message": str(error),
        "error_type": type(error).__name__,
        "traceback": traceback.format_exc(),
    }
    try:
        metadata_path = Path(metadata_filename)
        metadata_path.write_text(json.dumps(sentinel, indent=2))
        logger.error(f"Wrote error sentinel to {metadata_path.resolve()}: {error}")
    except Exception as write_err:
        logger.error(f"Failed to write error sentinel: {write_err}. Original error: {error}")
