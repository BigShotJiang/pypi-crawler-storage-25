"""Merge multiple prepared datasets of the same type into one combined dataset."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import typer
from scipy import sparse

app = typer.Typer()


def merge_datasets_impl(
    parquet_paths: list[str],
    row_paths: list[str],
    column_paths: list[str],
    metadata_paths: list[str],
    dataset_names: list[str],
    output_dir: str,
    serial_number: str,
    dataset_uid: int,
) -> dict:
    """
    Merge multiple prepared datasets into one.

    Each dataset has:
    - A sparse matrix parquet (COO format: row, col, data)
    - row_feature_names.tsv (mode, mass, index)
    - column_sample_names.tsv (sample, index)
    - metadata.csv (base_name, sample_id, ...)

    Output is a single merged set of files in output_dir.
    """
    out = Path(output_dir)

    # 1. Read all row features and build union feature index
    row_dfs = [pd.read_csv(p, sep='\t') for p in row_paths]
    all_features = pd.concat(row_dfs, ignore_index=True).drop_duplicates(
        subset=['mode', 'mass']
    ).reset_index(drop=True)
    all_features['index'] = range(len(all_features))
    n_features = len(all_features)

    # Map (mode, mass) -> new row index
    feature_key_to_idx = {}
    for _, row in all_features.iterrows():
        feature_key_to_idx[(row['mode'], row['mass'])] = row['index']

    # 2. Read all column samples and build merged column index
    col_dfs = [pd.read_csv(p, sep='\t') for p in column_paths]
    total_samples = sum(len(df) for df in col_dfs)
    merged_col = pd.concat(col_dfs, ignore_index=True)
    merged_col['index'] = range(total_samples)

    # 3. Read and remap sparse matrices
    merged_rows = []
    merged_cols = []
    merged_data = []
    col_offset = 0

    for i in range(len(parquet_paths)):
        df = pd.read_parquet(parquet_paths[i])
        src_row_df = row_dfs[i]

        # Build old_row_idx -> new_row_idx mapping for this dataset
        row_remap = {}
        for _, r in src_row_df.iterrows():
            old_idx = r['index']
            new_idx = feature_key_to_idx[(r['mode'], r['mass'])]
            row_remap[old_idx] = new_idx

        n_samples_i = len(col_dfs[i])

        for _, entry in df.iterrows():
            old_row = int(entry['row'])
            old_col = int(entry['col'])
            val = entry['data']
            if old_row in row_remap:
                merged_rows.append(row_remap[old_row])
                merged_cols.append(old_col + col_offset)
                merged_data.append(val)

        col_offset += n_samples_i

    # Build merged sparse matrix
    merged_sparse = sparse.coo_matrix(
        (merged_data, (merged_rows, merged_cols)),
        shape=(n_features, total_samples),
    )
    merged_parquet_df = pd.DataFrame({
        'row': merged_sparse.row,
        'col': merged_sparse.col,
        'data': merged_sparse.data,
    })

    # 4. Merge metadata with union join + dataset_id
    meta_dfs = []
    for i, mp in enumerate(metadata_paths):
        if not mp or not Path(mp).exists():
            # Generate a minimal metadata DataFrame from column_sample_names
            meta = pd.DataFrame({
                'sample_id': col_dfs[i]['sample'].tolist(),
            })
        else:
            meta = pd.read_csv(mp)
        meta['dataset_id'] = dataset_names[i]
        meta_dfs.append(meta)
    merged_meta = pd.concat(meta_dfs, ignore_index=True)

    # 5. Write outputs
    parquet_filename = f'{dataset_uid}_{serial_number}_merged_sparse_matrix.parquet'
    merged_parquet_df.to_parquet(out / parquet_filename)
    all_features.to_csv(out / 'row_feature_names.tsv', sep='\t', index=False)
    merged_col.to_csv(out / 'column_sample_names.tsv', sep='\t', index=False)
    merged_meta.to_csv(out / 'metadata.csv', index=False)

    result = {
        'serial_number': serial_number,
        'dataset_uid': dataset_uid,
        'sample_number': total_samples,
        'feature_number': n_features,
        'pipeline_stage': 'preparation',
        'result_type': 'sparse_matrix_file',
        'storage_path': str(out / parquet_filename),
        'file_size_bytes': (out / parquet_filename).stat().st_size,
        'row_count': len(merged_parquet_df),
        'column_names': merged_col['sample'].tolist(),
        'status': 'completed',
    }

    return result


@app.command()
def merge_datasets(
    parquet_paths: list[str] = typer.Option(..., help='Parquet file paths (repeat for each dataset)'),
    row_paths: list[str] = typer.Option(..., help='row_feature_names.tsv paths (repeat for each dataset)'),
    column_paths: list[str] = typer.Option(..., help='column_sample_names.tsv paths (repeat for each dataset)'),
    metadata_paths: list[str] = typer.Option(..., help='metadata.csv paths (repeat for each dataset)'),
    dataset_names: list[str] = typer.Option(..., help='Dataset names (repeat for each dataset)'),
    output_dir: str = typer.Option('.', help='Output directory'),
    serial_number: str = typer.Option(..., help='Project serial number'),
    dataset_uid: int = typer.Option(..., help='Merged dataset UID'),
):
    """Merge multiple prepared datasets into one combined dataset."""
    result = merge_datasets_impl(
        parquet_paths=parquet_paths,
        row_paths=row_paths,
        column_paths=column_paths,
        metadata_paths=metadata_paths,
        dataset_names=dataset_names,
        output_dir=output_dir,
        serial_number=serial_number,
        dataset_uid=dataset_uid,
    )

    # Print sentinel for metadata extraction
    sentinel = json.dumps(result)
    print(f'__PREPARATION_METADATA_START__{sentinel}__PREPARATION_METADATA_END__')


if __name__ == '__main__':
    app()
