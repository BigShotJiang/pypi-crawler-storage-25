import json
import os
from collections import Counter
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel

app = typer.Typer(add_completion=False)

DOWNSAMPLE_N = 1000
RANDOM_SEED = 42


class ClusteringExecutor:
    def __init__(
        self,
        matrix_data_path: str,
        embedding_path: str,
        metadata_path: str,
    ):
        # Load intensity matrix
        conn = duckdb.connect(database=':memory:')
        conn.read_parquet(matrix_data_path).create('matrix_data')
        df = conn.sql(
            'SELECT col, row, COALESCE(value, 0.0) AS value FROM matrix_data'
        ).to_df()
        conn.close()
        dense = df.pivot(index='col', columns='row', values='value').fillna(0.0)

        self.sample_names = dense.index.tolist()
        self.feature_names = dense.columns.tolist()
        self.X = dense.values.astype(np.float64)  # (n_obs, n_vars)

        # Load DR embedding (cell_name, component_1, component_2)
        emb_df = pd.read_parquet(embedding_path)
        self.emb_dict = {
            row['cell_name']: [float(row['component_1']), float(row['component_2'])]
            for _, row in emb_df.iterrows()
        }

        # Load metadata
        self.metadata_df = None
        if metadata_path and os.path.exists(metadata_path):
            self.metadata_df = pd.read_csv(metadata_path, index_col=0)

        # Populated by cluster_*
        self.cluster_labels_all: list = []  # parallel to sample_names, all cells

    # ------------------------------------------------------------------ #
    #  Clustering methods                                                  #
    # ------------------------------------------------------------------ #

    def cluster_leiden(self, n_pcs: int, n_neighbors: int, resolution: float) -> None:
        import scanpy as sc
        import anndata as ad

        n_comps = min(n_pcs, self.X.shape[0] - 1, self.X.shape[1] - 1)
        adata = ad.AnnData(X=self.X.astype(np.float64))
        sc.pp.pca(adata, n_comps=max(n_comps, 2))
        sc.pp.neighbors(adata, n_neighbors=n_neighbors, n_pcs=n_comps)
        sc.tl.leiden(adata, resolution=resolution)
        self.cluster_labels_all = adata.obs['leiden'].tolist()

    def cluster_louvain(self, n_pcs: int, n_neighbors: int, resolution: float) -> None:
        import igraph as ig
        import anndata as ad
        import scanpy as sc

        n_comps = min(n_pcs, self.X.shape[0] - 1, self.X.shape[1] - 1)
        adata = ad.AnnData(X=self.X.astype(np.float64))
        sc.pp.pca(adata, n_comps=max(n_comps, 2))
        sc.pp.neighbors(adata, n_neighbors=n_neighbors, n_pcs=n_comps)

        # Build igraph from the scanpy connectivities matrix
        cx = adata.obsp['connectivities'].tocoo()
        edges = list(zip(cx.row.tolist(), cx.col.tolist()))
        g = ig.Graph(n=self.X.shape[0], edges=edges, directed=False)
        g.simplify()

        # Louvain via igraph community_multilevel
        partition = g.community_multilevel(resolution=resolution)
        self.cluster_labels_all = [str(partition.membership[i]) for i in range(self.X.shape[0])]

    def cluster_kmeans(self, n_clusters: int) -> None:
        from sklearn.cluster import KMeans

        km = KMeans(n_clusters=n_clusters, random_state=RANDOM_SEED, n_init='auto')
        km.fit(self.X)
        self.cluster_labels_all = [str(c) for c in km.labels_.tolist()]

    # ------------------------------------------------------------------ #
    #  Output helpers                                                      #
    # ------------------------------------------------------------------ #

    def _downsample_indices(self) -> list:
        n = len(self.sample_names)
        if n <= DOWNSAMPLE_N:
            return list(range(n))
        rng = np.random.default_rng(RANDOM_SEED)
        return sorted(rng.choice(n, DOWNSAMPLE_N, replace=False).tolist())

    def _get_color_labels(self, column: str, names: list) -> list:
        if not column or self.metadata_df is None or column not in self.metadata_df.columns:
            return [None] * len(names)
        return [
            str(self.metadata_df.loc[name, column])
            if name in self.metadata_df.index else None
            for name in names
        ]

    def write_cluster_parquet(self, output_path: str) -> None:
        """Write cluster assignments for all cells (not downsampled)."""
        out_df = pd.DataFrame({
            'cell_name': self.sample_names,
            'cluster': self.cluster_labels_all,
        })
        pq.write_table(
            pa.Table.from_pandas(out_df, preserve_index=False),
            output_path,
        )
        logger.info(f'Wrote cluster labels parquet to {output_path}')

    def write_tsv_files(self, row_path: str, column_path: str) -> None:
        pd.Series(self.feature_names).to_csv(row_path, sep='\t', index=False, header=False)
        pd.Series(self.sample_names).to_csv(column_path, sep='\t', index=False, header=False)
        logger.info(f'Wrote row TSV to {row_path}, column TSV to {column_path}')

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        color_label: str,
        dr_method: str,
        clustering_method: str,
    ) -> None:
        indices = self._downsample_indices()
        sampled_names = [self.sample_names[i] for i in indices]
        sampled_cluster_labels = [str(self.cluster_labels_all[i]) for i in indices]
        sampled_embedding = [self.emb_dict.get(name, [0.0, 0.0]) for name in sampled_names]
        sampled_color_labels = self._get_color_labels(color_label, sampled_names)

        # Cluster sizes from ALL cells
        size_counter = Counter(str(lbl) for lbl in self.cluster_labels_all)
        cluster_sizes = {k: v for k, v in sorted(size_counter.items())}
        n_clusters_found = len(cluster_sizes)

        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'embedding': sampled_embedding,
            'cell_names': sampled_names,
            'cluster_labels': sampled_cluster_labels,
            'color_labels': sampled_color_labels,
            'cluster_sizes': cluster_sizes,
            'dr_method': dr_method,
            'clustering_method': clustering_method,
            'n_clusters_found': n_clusters_found,
            'status': 'completed',
        }
        metadata_file = Path('clustering_metadata.json')
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__CLUSTERING_METADATA_START__{json.dumps(sentinel)}'
            f'__CLUSTERING_METADATA_END__'
        )


@app.command()
def cluster(
    serial_number: str = '',
    dataset_uid: int = 0,
    # --- input paths (infrastructure, not parameters) ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    embedding_path: str = '',
    dr_method: str = '',
    # --- analysis ID (required for sentinel) ---
    analysis_id: int = typer.Option(..., help="Analysis ID (105 for SC clustering)"),
    # --- analysis parameters (match analysisParameterConfig.js parameterName in snake_case) ---
    clustering_method: str = 'Leiden',
    resolution: float = 1.0,
    n_clusters: int = 10,
    n_neighbors: int = 15,
    n_pcs: int = 50,
    color_label: str = '',
    # --- output paths ---
    output_parquet_path: str = 'cluster_labels.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
):
    """Cluster cells using Leiden, Louvain, or k-means on a single-cell metabolomics matrix."""
    try:
        executor = ClusteringExecutor(
            matrix_data_path=parquet_path,
            embedding_path=embedding_path,
            metadata_path=metadata_path,
        )

        if clustering_method == 'Leiden':
            executor.cluster_leiden(n_pcs=n_pcs, n_neighbors=n_neighbors, resolution=resolution)
        elif clustering_method == 'Louvain':
            executor.cluster_louvain(n_pcs=n_pcs, n_neighbors=n_neighbors, resolution=resolution)
        elif clustering_method == 'k-means':
            executor.cluster_kmeans(n_clusters=n_clusters)
        else:
            raise ValueError(f"Unknown clustering method: '{clustering_method}'")

        executor.write_cluster_parquet(output_parquet_path)
        executor.write_tsv_files(output_row_path, output_column_path)

        executor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet_path,
            row_path=output_row_path,
            column_path=output_column_path,
            color_label=color_label,
            dr_method=dr_method,
            clustering_method=clustering_method,
        )
        logger.success('Clustering complete.')
    except Exception as e:
        write_error_sentinel("clustering_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
