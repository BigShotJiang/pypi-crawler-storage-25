import os
import json
import numpy as np
import pandas as pd
import duckdb
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel


class NormalizationExecutor:
    def __init__(
        self,
        matrix_data_path: str,
        matrix_row_path: str,
        matrix_column_path: str,
        metadata_path: str,
    ):
        import anndata as ad

        conn = duckdb.connect(database=':memory:')
        conn.read_parquet(matrix_data_path).create('matrix_data')

        # Pivot COO sparse → dense DataFrame (samples=rows, features=columns)
        df = conn.sql(
            'SELECT col, row, COALESCE(value, 0.0) AS value FROM matrix_data'
        ).to_df()
        conn.close()
        dense = df.pivot(index='col', columns='row', values='value').fillna(0.0)

        self.sample_names = dense.index.tolist()
        self.feature_names = dense.columns.tolist()
        self.adata = ad.AnnData(
            X=dense.values.astype(np.float64),
            obs=pd.DataFrame(index=self.sample_names),
            var=pd.DataFrame(index=self.feature_names),
        )

        self.metadata_df = None
        if metadata_path and os.path.exists(metadata_path):
            self.metadata_df = pd.read_csv(metadata_path, index_col=0)

        self._z_score_applied = False

    def capture_violin_data(self) -> dict:
        """Return per-sample intensity arrays, downsampled to max 50 samples × 500 features."""
        rng = np.random.default_rng(42)
        n_samples = min(50, self.adata.n_obs)
        n_features = min(500, self.adata.n_vars)
        sample_idx = rng.choice(self.adata.n_obs, n_samples, replace=False)
        feature_idx = rng.choice(self.adata.n_vars, n_features, replace=False)

        result = {}
        for si in sample_idx:
            name = self.sample_names[si]
            result[name] = self.adata.X[si, feature_idx].tolist()
        return result

    def normalize(
        self,
        scaling_method: str,
        reference_feature: str,
        pqn_reference_column: str,
        pqn_reference_group: str,
        transformation: str,
        do_z_score: bool,
    ) -> None:
        import scanpy as sc

        # ① Sample scaling
        if scaling_method == 'TIC':
            sc.pp.normalize_total(self.adata, target_sum=1e6)
        elif scaling_method == 'median':
            sc.pp.normalize_total(self.adata, target_sum=None)
        elif scaling_method == 'PQN':
            self._apply_pqn(pqn_reference_column, pqn_reference_group)
        elif scaling_method == 'referenceFeature':
            self._apply_reference_feature(reference_feature)
        elif scaling_method == 'geometricMean':
            X = self.adata.X.copy()
            # geometric mean per sample (only positive values)
            log_means = np.array([
                np.mean(np.log(row[row > 0])) if np.any(row > 0) else 0.0
                for row in X
            ])
            geo_means = np.exp(log_means)
            geo_means = np.where(geo_means == 0, 1e-10, geo_means)
            self.adata.X = X / geo_means[:, np.newaxis]
        # 'none': skip

        # ② Transformation
        if transformation == 'log1p':
            sc.pp.log1p(self.adata)
        elif transformation == 'log2':
            self.adata.X = np.log2(self.adata.X + 1.0)
        elif transformation == 'sqrt':
            self.adata.X = np.sqrt(np.maximum(self.adata.X, 0.0))
        elif transformation == 'arcsinh':
            self.adata.X = np.arcsinh(self.adata.X)
        # 'none': skip

        # ③ Feature scaling
        if do_z_score:
            sc.pp.scale(self.adata, max_value=10)
            self._z_score_applied = True

    def _apply_pqn(self, pqn_reference_column: str, pqn_reference_group: str) -> None:
        X = self.adata.X.copy()
        reference = None
        if (
            pqn_reference_column
            and pqn_reference_group
            and self.metadata_df is not None
            and pqn_reference_column in self.metadata_df.columns
        ):
            mask = self.metadata_df[pqn_reference_column].astype(str) == str(pqn_reference_group)
            ref_sample_names = set(self.metadata_df.index[mask].astype(str))
            ref_positions = [
                i for i, name in enumerate(self.sample_names)
                if name in ref_sample_names
            ]
            if ref_positions:
                reference = np.median(X[ref_positions, :], axis=0)

        if reference is None:
            reference = np.median(X, axis=0)

        reference = np.where(reference == 0, 1e-10, reference)
        quotients = X / reference[np.newaxis, :]
        norm_factors = np.median(quotients, axis=1)
        norm_factors = np.where(norm_factors == 0, 1e-10, norm_factors)
        self.adata.X = X / norm_factors[:, np.newaxis]

    def _apply_reference_feature(self, reference_feature: str) -> None:
        if reference_feature not in self.adata.var_names:
            raise ValueError(f"Reference feature '{reference_feature}' not found in dataset")
        ref_idx = list(self.adata.var_names).index(reference_feature)
        ref_intensities = self.adata.X[:, ref_idx].copy()
        ref_intensities = np.where(ref_intensities == 0, 1e-10, ref_intensities)
        self.adata.X = self.adata.X / ref_intensities[:, np.newaxis]

    def quantile_normalize(self) -> None:
        """Force identical intensity distributions across all samples (columns).
        Rank-based quantile normalization: sort each sample, replace with
        row-wise mean of sorted values, then restore original order."""
        X = self.adata.X.copy()
        n_samples, n_features = X.shape
        sorted_indices = np.argsort(X, axis=1)
        sorted_X = np.take_along_axis(X, sorted_indices, axis=1)
        rank_means = np.mean(sorted_X, axis=0)
        # Restore original order
        ranks = np.argsort(sorted_indices, axis=1)
        self.adata.X = np.take_along_axis(
            np.tile(rank_means, (n_samples, 1)), ranks, axis=1
        )

    def cyclic_loess_normalize(self, span: float = 0.7) -> None:
        """Pairwise MA-plot loess normalization, iterated over all pairs.
        For each pair (i,j): M = log2(xi/xj), A = 0.5*log2(xi*xj),
        fit loess(M~A), subtract fitted/2 from i, add to j. Repeat until
        convergence (max 3 iterations)."""
        from statsmodels.nonparametric.smoothers_lowess import lowess

        X = self.adata.X.copy()
        # Add small pseudocount to avoid log(0)
        X = np.maximum(X, 1e-10)
        log_X = np.log2(X)

        n_samples = log_X.shape[0]
        for _iteration in range(3):
            for i in range(n_samples):
                for j in range(i + 1, n_samples):
                    M = log_X[i] - log_X[j]
                    A = 0.5 * (log_X[i] + log_X[j])
                    fitted = lowess(M, A, frac=span, return_sorted=False)
                    log_X[i] -= fitted / 2
                    log_X[j] += fitted / 2

        self.adata.X = np.power(2.0, log_X)

    def vsn_normalize(self) -> None:
        """Variance-stabilizing normalization via arcsinh transformation.
        Fits per-sample affine parameters (a_i, b_i) so that
        h(x) = arcsinh(a_i + b_i * x) stabilizes variance across
        intensity levels. Uses iterative least-squares fitting."""
        X = self.adata.X.copy()
        n_samples, n_features = X.shape

        # Per-sample: fit affine params via robust scaling, then arcsinh
        normalized = np.zeros_like(X)
        for i in range(n_samples):
            row = X[i]
            # Robust location/scale estimates
            median_val = np.median(row[row > 0]) if np.any(row > 0) else 1.0
            mad_val = np.median(np.abs(row - median_val))
            mad_val = max(mad_val, 1e-10)
            # Affine transform: center and scale
            a = -median_val / mad_val
            b = 1.0 / mad_val
            normalized[i] = np.arcsinh(a + b * row)

        self.adata.X = normalized

    def compute_pca_data(self, pca_color_label: str) -> dict:
        import scanpy as sc

        rng = np.random.default_rng(42)
        n_cells = min(1000, self.adata.n_obs)
        cell_idx = sorted(rng.choice(self.adata.n_obs, n_cells, replace=False).tolist())
        adata_sub = self.adata[cell_idx, :].copy()

        sc.pp.pca(adata_sub, n_comps=2)

        pc1 = adata_sub.obsm['X_pca'][:, 0].tolist()
        pc2 = adata_sub.obsm['X_pca'][:, 1].tolist()
        variance_ratio = adata_sub.uns['pca']['variance_ratio'][:2].tolist()

        color = None
        if (
            pca_color_label
            and self.metadata_df is not None
            and pca_color_label in self.metadata_df.columns
        ):
            sub_sample_names = [self.sample_names[i] for i in cell_idx]
            color = [
                str(self.metadata_df.loc[name, pca_color_label])
                if name in self.metadata_df.index else None
                for name in sub_sample_names
            ]

        return {
            'pca': {'pc1': pc1, 'pc2': pc2, 'color': color},
            'pca_variance_ratio': variance_ratio,
        }

    def write_normalized_parquet(self, output_path: str) -> None:
        X = self.adata.X
        # After z-score, zero means "feature at its mean" — a valid value that must
        # not be dropped. Use np.isfinite to keep all real values (including zeros).
        # Without z-score, sparse filtering via np.nonzero is safe and saves space.
        if self._z_score_applied:
            rows_idx, cols_idx = np.where(np.isfinite(X))
        else:
            rows_idx, cols_idx = np.nonzero(X)
        out_df = pd.DataFrame({
            'row': [self.feature_names[c] for c in cols_idx],
            'col': [self.sample_names[r] for r in rows_idx],
            'value': X[rows_idx, cols_idx].astype(np.float64),
        })
        pq.write_table(
            pa.Table.from_pandas(out_df, preserve_index=False),
            output_path,
        )
        logger.info(f'Wrote normalized parquet to {output_path}')

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        scaling_method: str,
        transformation: str,
        do_z_score: bool,
        violin_before: dict,
        violin_after: dict,
        pca_data: dict,
        normalization_mode: str = 'sequential',
        model_based_method: str = '',
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(storage_path),
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'normalization_mode': normalization_mode,
            'model_based_method': model_based_method,
            'scaling_method': scaling_method,
            'transformation': transformation,
            'do_z_score': do_z_score,
            'violin_before': violin_before,
            'violin_after': violin_after,
            **pca_data,
            'status': 'completed',
        }
        metadata_file = Path('normalization_metadata.json')
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__NORMALIZATION_METADATA_START__{json.dumps(sentinel)}'
            f'__NORMALIZATION_METADATA_END__'
        )


app = typer.Typer(add_completion=False)


@app.command()
def normalize(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(..., help='102 (Single Cell) or 202 (LCM)'),
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    normalization_mode: str = 'sequential',
    scaling_method: str = 'TIC',
    reference_feature: str = '',
    pqn_reference_column: str = '',
    pqn_reference_group: str = '',
    transformation: str = 'arcsinh',
    do_z_score: bool = False,
    pca_color_label: str = '',
    model_based_method: str = '',
    variable_features_n: int = 3000,
    loess_span: float = 0.7,
    eigenms_group_label: str = '',
):
    """Normalize a metabolomics matrix: sequential or model-based."""
    try:
        output_parquet = 'normalized.parquet'

        executor = NormalizationExecutor(
            matrix_data_path=parquet_path,
            matrix_row_path=row_path,
            matrix_column_path=column_path,
            metadata_path=metadata_path,
        )

        violin_before = executor.capture_violin_data()

        if normalization_mode == 'model-based':
            if model_based_method == 'quantile':
                executor.quantile_normalize()
            elif model_based_method == 'cyclicLoess':
                executor.cyclic_loess_normalize(span=loess_span)
            elif model_based_method == 'VSN':
                executor.vsn_normalize()
            else:
                raise ValueError(f"Unknown model-based method: {model_based_method}")
            # For sentinel compatibility, set sequential fields to 'none'
            scaling_method = 'none'
            transformation = 'none'
            do_z_score = False
        else:
            executor.normalize(
                scaling_method=scaling_method,
                reference_feature=reference_feature,
                pqn_reference_column=pqn_reference_column,
                pqn_reference_group=pqn_reference_group,
                transformation=transformation,
                do_z_score=do_z_score,
            )

        violin_after = executor.capture_violin_data()
        pca_data = executor.compute_pca_data(pca_color_label=pca_color_label)

        executor.write_normalized_parquet(output_parquet)

        executor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet,
            row_path=row_path,
            column_path=column_path,
            scaling_method=scaling_method,
            transformation=transformation,
            do_z_score=do_z_score,
            violin_before=violin_before,
            violin_after=violin_after,
            pca_data=pca_data,
            normalization_mode=normalization_mode,
            model_based_method=model_based_method,
        )
        logger.success('Normalization complete.')
    except Exception as e:
        write_error_sentinel("normalization_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
