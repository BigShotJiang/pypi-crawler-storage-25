from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DiscoveredRoute:
    framework: str  # "fastapi" | "django"
    method: str  # uppercase HTTP verb, or "*" when the source pattern doesn't constrain it (Django path())
    route: str  # pattern as written (e.g. "/items/{item_id}", "items/<int:pk>/")
    file: str  # path relative to scan root, forward slashes
    line: int
    function: str | None = None  # handler name when resolvable

    def as_dict(self) -> dict:
        return {
            "framework": self.framework,
            "method": self.method,
            "route": self.route,
            "file": self.file,
            "line": self.line,
            "function": self.function,
        }
