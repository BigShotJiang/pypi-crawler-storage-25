"""Static endpoint discovery.

Walks a project root for FastAPI/Django route definitions so the dashboard
can show every endpoint *before* any traffic flows. Discovery is best-effort
and regex-based — false positives are possible, missing edge cases (deep
APIRouter prefix stitching, dynamic url includes) are expected. Anything we
miss will still appear once traffic hits the middleware at runtime.
"""

from __future__ import annotations

from pathlib import Path

from ._models import DiscoveredRoute
from .django import scan_django
from .fastapi import scan_fastapi
from ._walker import iter_python_files

__all__ = ["DiscoveredRoute", "scan_project", "iter_python_files"]


def scan_project(root: Path) -> list[DiscoveredRoute]:
    """Scan `root` with every supported framework scanner and dedupe."""
    root = Path(root).resolve()
    found: list[DiscoveredRoute] = []
    found.extend(scan_fastapi(root))
    found.extend(scan_django(root))

    # Dedup by (framework, method, route, file) — first occurrence wins
    seen: set[tuple[str, str, str, str]] = set()
    out: list[DiscoveredRoute] = []
    for r in found:
        key = (r.framework, r.method, r.route, r.file)
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out
