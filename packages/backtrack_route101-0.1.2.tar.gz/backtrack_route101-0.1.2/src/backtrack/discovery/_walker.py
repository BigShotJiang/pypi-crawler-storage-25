from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

_SKIP_DIRS = {
    ".git", ".hg", ".svn", "node_modules", ".venv", "venv", "env",
    "__pycache__", "dist", "build", ".next", ".turbo", ".cache",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", "target", "vendor",
    "site-packages", ".tox", ".eggs",
}
_MAX_FILE_BYTES = 1_000_000  # files larger than this are almost certainly generated


def iter_python_files(root: Path) -> Iterator[Path]:
    """Yield .py files under `root`, skipping virtualenvs and other noise."""
    root = Path(root)
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")
        ]
        for fname in filenames:
            if not fname.endswith(".py"):
                continue
            path = Path(dirpath) / fname
            try:
                if path.stat().st_size > _MAX_FILE_BYTES:
                    continue
            except OSError:
                continue
            yield path


def rel(root: Path, path: Path) -> str:
    """Forward-slash relative path from root."""
    try:
        return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")
    except ValueError:
        return str(path).replace("\\", "/")
