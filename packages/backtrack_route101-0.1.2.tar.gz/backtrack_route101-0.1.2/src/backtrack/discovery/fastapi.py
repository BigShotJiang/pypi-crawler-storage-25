"""FastAPI route discovery.

Matches:
  @app.get("/path")               | @app.get('/path', response_model=...)
  @router.post("/path/{id}")      | @router.delete(...)
  @app.api_route("/path", methods=["GET","POST"])

Limitations (known and acceptable for v1):
  - We do NOT stitch APIRouter prefix chains (router = APIRouter(prefix="/api");
    app.include_router(router, prefix="/v2")). The decorator's literal path
    is reported. Runtime traffic will reveal the full path via the middleware,
    and the dashboard can correlate by tail-match.
  - Dynamic decorators (@some_factory()(...)) are missed.
  - Multi-line decorator arg lists work if the path string is on the first line.
"""

from __future__ import annotations

import re
from pathlib import Path

from ._models import DiscoveredRoute
from ._walker import iter_python_files, rel

_DECORATOR_RE = re.compile(
    r"""@\s*(?P<obj>[A-Za-z_][A-Za-z0-9_]*)\.(?P<verb>get|post|put|delete|patch|options|head|api_route)\s*\(\s*['"](?P<path>[^'"]+)['"]"""
)

# For api_route, capture methods=[...]
_API_ROUTE_METHODS_RE = re.compile(
    r"""methods\s*=\s*\[\s*((?:['"][A-Za-z]+['"]\s*,?\s*)+)\s*\]"""
)

_DEF_RE = re.compile(r"^\s*(?:async\s+)?def\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\(")


def scan_fastapi(root: Path) -> list[DiscoveredRoute]:
    out: list[DiscoveredRoute] = []
    root = Path(root)
    for path in iter_python_files(root):
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        # Cheap pre-filter: skip files that have no decorator-shaped tokens at all.
        if "@" not in text or "(" not in text:
            continue
        # Heuristic: a real FastAPI file imports from fastapi or defines an APIRouter.
        if "fastapi" not in text.lower() and "APIRouter" not in text:
            continue
        rel_file = rel(root, path)
        lines = text.splitlines()
        for i, line in enumerate(lines):
            m = _DECORATOR_RE.search(line)
            if not m:
                continue
            verb = m.group("verb").lower()
            route_path = m.group("path")
            func_name = _next_def_name(lines, i)

            if verb == "api_route":
                methods = _extract_api_route_methods(lines, i)
                if not methods:
                    methods = ["*"]
                for mth in methods:
                    out.append(
                        DiscoveredRoute(
                            framework="fastapi",
                            method=mth.upper(),
                            route=route_path,
                            file=rel_file,
                            line=i + 1,
                            function=func_name,
                        )
                    )
            else:
                out.append(
                    DiscoveredRoute(
                        framework="fastapi",
                        method=verb.upper(),
                        route=route_path,
                        file=rel_file,
                        line=i + 1,
                        function=func_name,
                    )
                )
    return out


def _next_def_name(lines: list[str], decorator_idx: int) -> str | None:
    """Find the `def name(...)` line that follows a decorator (skipping other decorators)."""
    for j in range(decorator_idx + 1, min(decorator_idx + 8, len(lines))):
        stripped = lines[j].lstrip()
        if stripped.startswith("@"):
            continue
        m = _DEF_RE.match(lines[j])
        if m:
            return m.group("name")
        if stripped and not stripped.startswith(("#", '"""', "'''")):
            return None
    return None


def _extract_api_route_methods(lines: list[str], start_idx: int) -> list[str]:
    """Pull the methods=[...] kwarg for @app.api_route, allowing it to span lines."""
    snippet = "\n".join(lines[start_idx : start_idx + 6])
    m = _API_ROUTE_METHODS_RE.search(snippet)
    if not m:
        return []
    inner = m.group(1)
    return [s.strip().strip("'\"") for s in inner.split(",") if s.strip()]
