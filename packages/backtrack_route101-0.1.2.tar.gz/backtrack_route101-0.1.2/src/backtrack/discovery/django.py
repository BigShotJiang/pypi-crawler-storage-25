"""Django URLconf discovery.

Matches:
  path("foo/", views.foo, name="foo")
  re_path(r"^foo/", views.foo)
  path("", include("app.urls"))

For include(), we look up the included module's `urls.py` relative to the
project root (best-effort: try `<root>/<module>/urls.py` with both dotted
and slashed lookups) and recurse, prefixing the parent's pattern. We don't
import anything — pure source reading. Dynamic `urlpatterns += ...` constructs
that compute patterns at runtime are missed.

Django patterns are method-agnostic at the URL layer; we record method="*".
"""

from __future__ import annotations

import re
from pathlib import Path

from ._models import DiscoveredRoute
from ._walker import iter_python_files, rel

# path("foo/", view, name="x")   or   re_path(r"^foo/", view)
_PATH_RE = re.compile(
    r"""\b(?P<kind>re_path|path)\s*\(\s*(?P<q>r?['"])(?P<pat>[^'"]*)(?P=q)\s*,\s*(?P<rest>[^)]*)"""
)

# Pull include("dotted.path") or include('relative.path')
_INCLUDE_RE = re.compile(r"""\binclude\s*\(\s*['"]([^'"]+)['"]""")

# Pull a view name from the second arg. We grab the whole dotted reference so we
# can strip a trailing ".as_view" (class-based views) and keep the class name.
_VIEW_NAME_RE = re.compile(
    r"""^\s*(?P<dotted>[A-Za-z_][A-Za-z0-9_\.]*)"""
)


def scan_django(root: Path) -> list[DiscoveredRoute]:
    out: list[DiscoveredRoute] = []
    root = Path(root)

    # Build a map of dotted-module -> Path(urls.py) so include() can resolve.
    urls_files = _index_urls_files(root)

    visited: set[Path] = set()
    for path in urls_files.values():
        out.extend(_scan_one(root, path, prefix="", urls_files=urls_files, visited=visited))

    # Also catch urls.py files that aren't reachable from the include() graph
    # (e.g. project-level entrypoint with no parent).
    for path in urls_files.values():
        if path in visited:
            continue
        out.extend(_scan_one(root, path, prefix="", urls_files=urls_files, visited=visited))

    return out


def _index_urls_files(root: Path) -> dict[str, Path]:
    """Map dotted module path → urls.py file, for include() resolution."""
    index: dict[str, Path] = {}
    for path in iter_python_files(root):
        if path.name != "urls.py":
            continue
        try:
            dotted = (
                str(path.relative_to(root.resolve()))
                .replace("\\", "/")
                .replace("/", ".")
            )
        except ValueError:
            continue
        # Strip ".urls.py" -> ".urls"
        if dotted.endswith(".urls.py"):
            dotted = dotted[: -len(".py")]
        index[dotted] = path
        # Also register the parent app name (e.g. "myapp.urls" -> "myapp.urls",
        # but include("myapp.urls") looks for the dotted match exactly).
    return index


def _scan_one(
    root: Path,
    file: Path,
    prefix: str,
    urls_files: dict[str, Path],
    visited: set[Path],
) -> list[DiscoveredRoute]:
    if file in visited:
        return []
    visited.add(file)
    try:
        text = file.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    if "urlpatterns" not in text and "path(" not in text and "re_path(" not in text:
        return []

    out: list[DiscoveredRoute] = []
    rel_file = rel(root, file)
    lines = text.splitlines()
    # Precompute (line, char) offsets so we can map a match position back to a line.
    line_starts = [0]
    for ln in lines:
        line_starts.append(line_starts[-1] + len(ln) + 1)

    for m in _PATH_RE.finditer(text):
        pat = m.group("pat")
        rest = m.group("rest")
        lineno = _pos_to_line(line_starts, m.start())

        # Is it an include()?
        inc = _INCLUDE_RE.search(rest)
        if inc:
            included = inc.group(1)
            joined_prefix = _join(prefix, pat)
            child = urls_files.get(included)
            if child is not None:
                out.extend(
                    _scan_one(root, child, joined_prefix, urls_files, visited)
                )
            else:
                # Record the unresolved include as a discovered "route" so users
                # see it exists, with method="INCLUDE" as a marker.
                out.append(
                    DiscoveredRoute(
                        framework="django",
                        method="INCLUDE",
                        route=joined_prefix + "[…]",
                        file=rel_file,
                        line=lineno,
                        function=f"include({included!r})",
                    )
                )
            continue

        view_name = _extract_view_name(rest)
        joined = _join(prefix, pat)
        out.append(
            DiscoveredRoute(
                framework="django",
                method="*",
                route=joined,
                file=rel_file,
                line=lineno,
                function=view_name,
            )
        )

    return out


def _join(prefix: str, suffix: str) -> str:
    if not prefix:
        return _ensure_leading_slash(suffix)
    p = prefix.rstrip("/")
    s = suffix.lstrip("/")
    if not s:
        return p + "/"
    return p + "/" + s


def _ensure_leading_slash(s: str) -> str:
    if s.startswith("^"):
        s = s[1:]
    return "/" + s.lstrip("/")


def _extract_view_name(rest: str) -> str | None:
    m = _VIEW_NAME_RE.match(rest)
    if not m:
        return None
    dotted = m.group("dotted")
    # Strip trailing .as_view for CBVs so we show the class, not the helper.
    if dotted.endswith(".as_view"):
        dotted = dotted[: -len(".as_view")]
    # Take the last segment of the dotted path (drop the module prefix).
    name = dotted.rsplit(".", 1)[-1]
    if name in {"include", "lambda", "None"}:
        return None
    return name


def _pos_to_line(line_starts: list[int], pos: int) -> int:
    """Binary-search the line number (1-based) for a character offset."""
    lo, hi = 0, len(line_starts) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if line_starts[mid] <= pos:
            lo = mid
        else:
            hi = mid - 1
    return lo + 1
