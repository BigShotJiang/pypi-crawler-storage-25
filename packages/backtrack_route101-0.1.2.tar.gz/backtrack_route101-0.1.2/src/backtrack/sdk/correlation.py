"""Correlation IDs for cross-service call chains.

How it works:
  1. The middleware reads `X-Request-ID`, `X-Correlation-ID`, and
     `X-Parent-Request-ID` from each incoming request (or generates a fresh
     request_id when absent). Correlation defaults to request_id at the root.
  2. The middleware stores those values in contextvars for the duration of
     the request, then records them on the Event sent to the collector.
  3. When your handler makes outgoing HTTP calls to another instrumented
     service, call `current_headers()` and merge the result into the outgoing
     headers — the next hop will see this hop as its parent, and stay on the
     same correlation chain.

Example:
    from backtrack.sdk.correlation import current_headers
    async with httpx.AsyncClient() as client:
        r = await client.get(other_url, headers=current_headers())

Headers (case-insensitive, the collector accepts these from either case):
    X-Request-ID          this hop's unique id
    X-Correlation-ID      chain id (root request_id)
    X-Parent-Request-ID   id of the hop that called us
"""

from __future__ import annotations

import contextvars
import uuid

# These hold the trace context for the *currently in-flight* request.
# Middlewares set them on entry and reset on exit.
_request_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "backtrack_request_id", default=None
)
_correlation_id_var: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "backtrack_correlation_id", default=None
)

HEADER_REQUEST_ID = "X-Request-ID"
HEADER_CORRELATION_ID = "X-Correlation-ID"
HEADER_PARENT_REQUEST_ID = "X-Parent-Request-ID"


def new_id() -> str:
    """A short, opaque trace id. 16 hex chars = 64 bits, plenty for local-only use."""
    return uuid.uuid4().hex[:16]


def get_request_id() -> str | None:
    return _request_id_var.get()


def get_correlation_id() -> str | None:
    return _correlation_id_var.get()


def current_headers() -> dict[str, str]:
    """Headers to attach to outgoing requests so the next hop joins this chain.

    Returns `{}` if there's no active request (e.g. called from a background
    task that isn't tied to an incoming request) — safe to splat unconditionally.
    """
    rid = _request_id_var.get()
    cid = _correlation_id_var.get()
    if not rid and not cid:
        return {}
    out: dict[str, str] = {}
    if cid:
        out[HEADER_CORRELATION_ID] = cid
    if rid:
        # The receiver will see us as their parent.
        out[HEADER_PARENT_REQUEST_ID] = rid
    return out


def set_context(request_id: str, correlation_id: str) -> tuple:
    """Set the contextvars for the lifetime of this request. Returns reset tokens."""
    t_req = _request_id_var.set(request_id)
    t_corr = _correlation_id_var.set(correlation_id)
    return (t_req, t_corr)


def reset_context(tokens: tuple) -> None:
    t_req, t_corr = tokens
    _request_id_var.reset(t_req)
    _correlation_id_var.reset(t_corr)


def resolve_incoming(
    incoming_request_id: str | None,
    incoming_correlation_id: str | None,
    incoming_parent_id: str | None,
) -> tuple[str, str, str | None]:
    """Apply our rules:
      - request_id: client-supplied or freshly generated
      - correlation_id: client-supplied; else falls back to request_id (root of chain)
      - parent_id: passed through as-is (None at the root)
    """
    request_id = (incoming_request_id or "").strip() or new_id()
    correlation_id = (incoming_correlation_id or "").strip() or request_id
    parent_id = (incoming_parent_id or "").strip() or None
    return request_id, correlation_id, parent_id
