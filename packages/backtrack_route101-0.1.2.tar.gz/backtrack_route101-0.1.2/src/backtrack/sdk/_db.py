"""Per-request ORM query capture.

The middleware sets up a contextvars buffer at the start of each request. Every
SQL execution (via the wrapped Django cursor or the SQLAlchemy event listener)
appends a (template_sql, params_repr, duration_ms) tuple to that buffer. At
request end the middleware drains the buffer into the Event:

    db_query_count, db_total_ms, db_slow (top-3 slowest with normalized SQL)

We normalize SQL by stripping quoted literals and IN-list bodies so identical
queries with different parameters collapse to the same template — N+1 patterns
become visible by their repeated-template count.
"""

from __future__ import annotations

import contextvars
import re
import time
from typing import Any

# Buffer is a list of dicts. We use list rather than deque so middlewares can
# slice trivially when computing the top-N slowest.
_buffer_var: contextvars.ContextVar[list[dict[str, Any]] | None] = contextvars.ContextVar(
    "backtrack_db_buffer", default=None
)

# Max items we keep per request — bounds memory if someone runs a wild loop.
_MAX_ITEMS = 500
# How long an SQL string we send up to the collector (per slow-query sample).
_SQL_TRUNCATE = 400


def start_buffer() -> tuple:
    """Initialize a fresh buffer for the current request. Returns the reset token."""
    return _buffer_var.set([])


def reset_buffer(token: tuple) -> None:
    _buffer_var.reset(token)


def record(sql: str, duration_ms: float) -> None:
    """Append a query record to the current request's buffer (no-op outside a request)."""
    buf = _buffer_var.get()
    if buf is None:
        return
    if len(buf) >= _MAX_ITEMS:
        return
    buf.append({"sql": _normalize_sql(sql), "ms": duration_ms})


def summarize() -> tuple[int, float, list[dict[str, Any]]] | None:
    """Read the current buffer. Returns (count, total_ms, top3_slowest) or None."""
    buf = _buffer_var.get()
    if buf is None:
        return None
    count = len(buf)
    total = sum(item["ms"] for item in buf)
    top3 = sorted(buf, key=lambda x: x["ms"], reverse=True)[:3]
    # Truncate SQL for transport
    top3 = [{"sql": item["sql"][:_SQL_TRUNCATE], "ms": round(item["ms"], 3)} for item in top3]
    return count, total, top3


# ----------------------------------------------------------- SQL normalization

# Strip 'string literals' and "double-quoted" strings, then collapse IN-lists
# and numeric literals. The result is a stable template for grouping.
_RE_STR = re.compile(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"")
_RE_IN_LIST = re.compile(r"\bIN\s*\([^)]*\)", re.IGNORECASE)
_RE_NUM = re.compile(r"\b\d+(?:\.\d+)?\b")
_RE_WS = re.compile(r"\s+")


def _normalize_sql(sql: str) -> str:
    s = _RE_STR.sub("?", sql)
    s = _RE_IN_LIST.sub("IN (?)", s)
    s = _RE_NUM.sub("?", s)
    s = _RE_WS.sub(" ", s).strip()
    return s


# ----------------------------------------------------------- Django hookup


def install_django() -> bool:
    """Wrap every Django connection's cursor.execute so timings flow into the buffer.

    Called by the Django middleware on first request. Idempotent (Django's
    execute_wrapper API is per-block, not global — we use a connection-level
    hook installed once that checks the contextvar for an active buffer).
    """
    try:
        from django.db import connections
    except Exception:  # noqa: BLE001
        return False

    # We install via connection_created signal so brand-new connections also
    # get the wrapper, plus we install on already-open connections here.
    try:
        from django.db.backends.signals import connection_created
    except Exception:  # noqa: BLE001
        connection_created = None  # type: ignore[assignment]

    def _wrapper(execute, sql, params, many, context):
        start = time.perf_counter()
        try:
            return execute(sql, params, many, context)
        finally:
            record(str(sql), (time.perf_counter() - start) * 1000.0)

    # Patch each existing connection to *always* run our wrapper. We do this
    # by adding the wrapper to connection.execute_wrappers — which Django
    # checks on every cursor execute.
    def _attach(conn: Any) -> None:
        wrappers = getattr(conn, "execute_wrappers", None)
        if wrappers is None:
            return
        if _wrapper in wrappers:
            return
        wrappers.append(_wrapper)

    for alias in connections:
        try:
            _attach(connections[alias])
        except Exception:  # noqa: BLE001
            pass

    if connection_created is not None:
        def _on_created(sender, connection, **kwargs):  # noqa: ANN001
            _attach(connection)

        connection_created.connect(_on_created, weak=False, dispatch_uid="backtrack_attach")

    return True


# ----------------------------------------------------------- SQLAlchemy hookup


def instrument_sqlalchemy(engine: Any) -> bool:
    """Wire SQLAlchemy `before/after_cursor_execute` events on `engine`.

    User-facing helper: call once at app startup.

        from sqlalchemy import create_engine
        from backtrack.sdk import instrument_sqlalchemy
        engine = create_engine(...)
        instrument_sqlalchemy(engine)
    """
    try:
        from sqlalchemy import event
    except Exception:  # noqa: BLE001
        return False

    @event.listens_for(engine, "before_cursor_execute")
    def _before(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001
        context._bt_start = time.perf_counter()

    @event.listens_for(engine, "after_cursor_execute")
    def _after(conn, cursor, statement, parameters, context, executemany):  # noqa: ANN001
        start = getattr(context, "_bt_start", None)
        if start is None:
            return
        record(str(statement), (time.perf_counter() - start) * 1000.0)

    return True
