"""Capture exception tracebacks and produce a stable fingerprint for grouping.

We don't try to be clever about which frames to keep — the full traceback is
captured (truncated to _MAX_TB_BYTES) so the dashboard can show real context.
The fingerprint is a blake2b of (filename + qualname + lineno) for every frame
in the traceback; identical bugs from the same code path collapse to one group
regardless of which request triggered them.
"""

from __future__ import annotations

import hashlib
import traceback
from types import TracebackType
from typing import Any

_MAX_TB_BYTES = 16_000  # collector stores TEXT, no point sending megabytes
_MAX_MSG_LEN = 500


def capture(exc: BaseException) -> dict[str, Any]:
    """Capture exception fields suitable for storage on an Event."""
    tb = exc.__traceback__
    tb_text = _format_traceback(exc, tb)
    return {
        "error_type": type(exc).__name__,
        "error_message": _truncate(str(exc), _MAX_MSG_LEN),
        "error_traceback": tb_text,
        "error_fingerprint": _fingerprint(tb),
    }


def _format_traceback(exc: BaseException, tb: TracebackType | None) -> str:
    text = "".join(traceback.format_exception(type(exc), exc, tb))
    if len(text) > _MAX_TB_BYTES:
        # Keep the head (where it came from) and the tail (where it landed).
        head = text[: _MAX_TB_BYTES // 2]
        tail = text[-_MAX_TB_BYTES // 2 :]
        return f"{head}\n... [traceback truncated] ...\n{tail}"
    return text


def _fingerprint(tb: TracebackType | None) -> str:
    h = hashlib.blake2b(digest_size=10)
    # Walk the traceback frames in order; hash filename + function + lineno.
    frame_tb = tb
    while frame_tb is not None:
        f = frame_tb.tb_frame
        co = f.f_code
        # Strip absolute paths so the fingerprint is portable across deploys.
        filename = _strip_path(co.co_filename)
        h.update(filename.encode("utf-8"))
        h.update(b"|")
        h.update(co.co_qualname.encode("utf-8") if hasattr(co, "co_qualname") else co.co_name.encode("utf-8"))
        h.update(b"|")
        h.update(str(frame_tb.tb_lineno).encode("utf-8"))
        h.update(b"\n")
        frame_tb = frame_tb.tb_next
    return h.hexdigest()


def _strip_path(filename: str) -> str:
    """Drop leading directories that vary between machines.

    Keeps everything after the last `site-packages/` or `src/` segment, so
    `~/proj/venv/lib/.../site-packages/django/views.py` becomes
    `django/views.py`.
    """
    for marker in ("site-packages", "src", "Lib"):
        idx = filename.rfind(marker + "/")
        if idx == -1:
            idx = filename.rfind(marker + "\\")
        if idx != -1:
            return filename[idx + len(marker) + 1 :].replace("\\", "/")
    return filename.replace("\\", "/")


def _truncate(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 1] + "…"
