"""FastAPI / Starlette ASGI middleware.

Usage:

    from fastapi import FastAPI
    from backtrack.sdk.fastapi import BacktrackMiddleware

    app = FastAPI()
    app.add_middleware(BacktrackMiddleware, service="my-api")

Captures per request:
  - method, route template, status, duration
  - exception type + truncated message + traceback + grouping fingerprint
  - W3C-ish trace context (request_id / correlation_id / parent_id)
  - ORM query count + total ms (if SQLAlchemy instrumented via instrument_sqlalchemy)
  - Outgoing HTTP aggregate (if httpx/requests instrumented via instrument_all)
"""

from __future__ import annotations

import time
from typing import Any

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from . import _db, _errors, _outgoing
from ._wire import DEFAULT_ENDPOINT, Event, Reporter, now
from .correlation import (
    HEADER_CORRELATION_ID,
    HEADER_PARENT_REQUEST_ID,
    HEADER_REQUEST_ID,
    reset_context,
    resolve_incoming,
    set_context,
)


class BacktrackMiddleware:
    def __init__(
        self,
        app: ASGIApp,
        service: str,
        endpoint: str = DEFAULT_ENDPOINT,
        instrument_outgoing: bool = True,
    ) -> None:
        self.app = app
        self.reporter = Reporter.get(service=service, endpoint=endpoint)
        if instrument_outgoing:
            _outgoing.instrument_all()

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        start = time.perf_counter()
        status_code = 500
        error_name: str | None = None
        captured_exc: BaseException | None = None
        method = scope.get("method", "")
        path = scope.get("path", "")

        # Trace context
        in_req = _scope_header(scope, HEADER_REQUEST_ID)
        in_corr = _scope_header(scope, HEADER_CORRELATION_ID)
        in_parent = _scope_header(scope, HEADER_PARENT_REQUEST_ID)
        request_id, correlation_id, parent_id = resolve_incoming(in_req, in_corr, in_parent)

        x_request_id_bytes = (HEADER_REQUEST_ID.lower().encode(), request_id.encode())

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code
            if message["type"] == "http.response.start":
                status_code = int(message.get("status", 500))
                headers = list(message.get("headers") or [])
                headers.append(x_request_id_bytes)
                message = {**message, "headers": headers}
            await send(message)

        tokens_ctx = set_context(request_id, correlation_id)
        db_token = _db.start_buffer()
        out_tokens = _outgoing.start_aggregate()
        self.reporter.inc_in_flight()
        try:
            await self.app(scope, receive, send_wrapper)
        except Exception as exc:  # noqa: BLE001 — capture then re-raise
            error_name = type(exc).__name__
            captured_exc = exc
            raise
        finally:
            reset_context(tokens_ctx)
            duration_ms = (time.perf_counter() - start) * 1000.0
            route_template = _route_template(scope) or path
            self.reporter.dec_in_flight()

            db_summary = _db.summarize()
            _db.reset_buffer(db_token)
            out_count, out_total_ms = _outgoing.aggregate_for_event()
            _outgoing.reset_aggregate(out_tokens)

            err_fields: dict[str, Any] = {}
            if captured_exc is not None:
                err_fields = _errors.capture(captured_exc)

            self.reporter.record(
                Event(
                    ts=now(),
                    method=method,
                    route=route_template,
                    path=path,
                    status=status_code,
                    duration_ms=duration_ms,
                    error=error_name,
                    request_id=request_id,
                    correlation_id=correlation_id,
                    parent_id=parent_id,
                    error_type=err_fields.get("error_type"),
                    error_message=err_fields.get("error_message"),
                    error_traceback=err_fields.get("error_traceback"),
                    error_fingerprint=err_fields.get("error_fingerprint"),
                    db_query_count=db_summary[0] if db_summary else None,
                    db_total_ms=db_summary[1] if db_summary else None,
                    db_slow=db_summary[2] if db_summary else None,
                    outgoing_count=out_count or None,
                    outgoing_total_ms=out_total_ms or None,
                )
            )


def _scope_header(scope: Scope, name: str) -> str | None:
    needle = name.lower().encode()
    for k, v in scope.get("headers") or []:
        if k == needle:
            try:
                return v.decode("latin-1")
            except Exception:  # noqa: BLE001
                return None
    return None


def _route_template(scope: Scope) -> str | None:
    route: Any = scope.get("route")
    if route is not None:
        path_format = getattr(route, "path_format", None)
        if path_format:
            return path_format
        path = getattr(route, "path", None)
        if path:
            return path
    return None
