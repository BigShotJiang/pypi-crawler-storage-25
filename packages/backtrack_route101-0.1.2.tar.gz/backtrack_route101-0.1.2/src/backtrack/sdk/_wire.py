"""Wire format + background reporter shared by every framework SDK.

The reporter buffers events in memory and flushes them to the collector on a
background thread every `flush_interval` seconds. Failures are dropped silently
so a down collector can never break the host application.
"""

from __future__ import annotations

import json
import os
import socket
import threading
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass, field
from typing import Any

DEFAULT_ENDPOINT = os.environ.get("BACKTRACK_ENDPOINT", "http://127.0.0.1:9876/ingest")
DEFAULT_FLUSH_INTERVAL = 1.0  # seconds
DEFAULT_BUFFER_CAP = 5_000  # drop oldest beyond this to bound memory
_HOSTNAME = socket.gethostname()


@dataclass
class Event:
    ts: float  # unix seconds (float)
    method: str
    route: str  # template if available, else raw path
    path: str  # raw path (for debugging)
    status: int
    duration_ms: float
    error: str | None = None  # exception class name, if any
    # Trace context (W3C-ish, simplified):
    #   request_id: this hop's id (always set by the middleware)
    #   correlation_id: chain id, shared across all hops of one logical trace
    #   parent_id: request_id of the caller hop, if any (None at the root)
    request_id: str | None = None
    correlation_id: str | None = None
    parent_id: str | None = None
    # Error grouping (set only when an exception bubbled out of the handler)
    error_type: str | None = None  # exception class name (same as .error, retained for clarity)
    error_message: str | None = None  # truncated str(exc)
    error_traceback: str | None = None  # full text traceback
    error_fingerprint: str | None = None  # stable hash for grouping
    # ORM
    db_query_count: int | None = None
    db_total_ms: float | None = None
    db_slow: list[dict[str, Any]] | None = None  # top-3 slowest [{sql, ms}]
    # Outgoing HTTP
    outgoing_count: int | None = None
    outgoing_total_ms: float | None = None


@dataclass
class OutgoingCall:
    ts: float
    method: str
    host: str
    path: str
    status: int  # 0 if the call errored out before getting a response
    duration_ms: float
    error: str | None = None  # exception class name if the call failed
    source_request_id: str | None = None  # the in-flight request that initiated this call
    correlation_id: str | None = None


@dataclass
class Envelope:
    service: str
    host: str
    pid: int
    events: list[Event] = field(default_factory=list)
    outgoing_calls: list[OutgoingCall] = field(default_factory=list)
    cpu_pct: float | None = None
    mem_mb: float | None = None
    in_flight: int = 0


class Reporter:
    """Buffers Events + outgoing calls and ships them to the collector in batches.

    One Reporter per process. Framework middlewares share the singleton via
    `Reporter.get(service=...)`.
    """

    _singleton: "Reporter | None" = None
    _lock = threading.Lock()

    def __init__(
        self,
        service: str,
        endpoint: str = DEFAULT_ENDPOINT,
        flush_interval: float = DEFAULT_FLUSH_INTERVAL,
        buffer_cap: int = DEFAULT_BUFFER_CAP,
    ) -> None:
        self.service = service
        self.endpoint = endpoint
        self.flush_interval = flush_interval
        self.buffer_cap = buffer_cap
        self._buf: list[Event] = []
        self._outgoing_buf: list[OutgoingCall] = []
        self._buf_lock = threading.Lock()
        self._in_flight = 0
        self._in_flight_lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name="backtrack-reporter", daemon=True)
        self._thread.start()
        # Lazy psutil import — keeps the SDK importable even if psutil is missing.
        try:
            import psutil

            self._proc = psutil.Process()
            # Prime the cpu_percent reading; first call always returns 0.0.
            self._proc.cpu_percent(interval=None)
        except Exception:  # noqa: BLE001
            self._proc = None

    @classmethod
    def get(cls, service: str, **kwargs: object) -> "Reporter":
        with cls._lock:
            if cls._singleton is None:
                cls._singleton = cls(service=service, **kwargs)  # type: ignore[arg-type]
            return cls._singleton

    def record(self, event: Event) -> None:
        with self._buf_lock:
            self._buf.append(event)
            if len(self._buf) > self.buffer_cap:
                self._buf = self._buf[-self.buffer_cap :]

    def record_outgoing(self, call: OutgoingCall) -> None:
        with self._buf_lock:
            self._outgoing_buf.append(call)
            if len(self._outgoing_buf) > self.buffer_cap:
                self._outgoing_buf = self._outgoing_buf[-self.buffer_cap :]

    def inc_in_flight(self) -> None:
        with self._in_flight_lock:
            self._in_flight += 1

    def dec_in_flight(self) -> None:
        with self._in_flight_lock:
            self._in_flight = max(0, self._in_flight - 1)

    def shutdown(self) -> None:
        self._stop.set()
        self._thread.join(timeout=2.0)
        self._flush_once()

    # -------------------------------------------------------------- internals

    def _loop(self) -> None:
        while not self._stop.wait(self.flush_interval):
            self._flush_once()

    def _flush_once(self) -> None:
        with self._buf_lock:
            events = self._buf
            outgoing = self._outgoing_buf
            self._buf = []
            self._outgoing_buf = []

        cpu_pct = None
        mem_mb = None
        if self._proc is not None:
            try:
                cpu_pct = self._proc.cpu_percent(interval=None)
                mem_mb = self._proc.memory_info().rss / (1024 * 1024)
            except Exception:  # noqa: BLE001
                pass

        payload = json.dumps(
            {
                "service": self.service,
                "host": _HOSTNAME,
                "pid": os.getpid(),
                "cpu_pct": cpu_pct,
                "mem_mb": mem_mb,
                "in_flight": self._in_flight,
                "events": [asdict(e) for e in events],
                "outgoing_calls": [asdict(c) for c in outgoing],
            }
        ).encode("utf-8")

        req = urllib.request.Request(
            self.endpoint,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=2.0):
                pass
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError):
            return


def now() -> float:
    return time.time()
