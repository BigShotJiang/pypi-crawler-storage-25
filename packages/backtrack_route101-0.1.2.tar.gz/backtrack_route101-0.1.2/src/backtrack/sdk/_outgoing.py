"""Instrument outgoing HTTP libraries (httpx + requests) at SDK boot.

For each outgoing call we record (host, path, method, status, duration, error)
on the Reporter — flushed separately from incoming events on its own table.

We also track per-request aggregate (count + total_ms) via contextvars so the
middleware can attach it to the in-flight Event before it's recorded.

httpx: use sync + async Client.send wrappers. Calling instrument_httpx()
       monkey-patches the methods on httpx.Client and httpx.AsyncClient.
requests: monkey-patch requests.Session.send.

Both are safe no-ops if the library isn't installed or already instrumented.
"""

from __future__ import annotations

import contextvars
import time
from typing import Any
from urllib.parse import urlparse

from ._wire import OutgoingCall, Reporter, now
from .correlation import get_correlation_id, get_request_id

# Per-request aggregate. Middleware reads these at request-end.
_count_var: contextvars.ContextVar[int] = contextvars.ContextVar("backtrack_out_count", default=0)
_total_ms_var: contextvars.ContextVar[float] = contextvars.ContextVar(
    "backtrack_out_total_ms", default=0.0
)

_INSTRUMENTED_HTTPX = False
_INSTRUMENTED_REQUESTS = False


def start_aggregate() -> tuple:
    """Reset per-request outgoing counters. Returns reset tokens."""
    t_count = _count_var.set(0)
    t_ms = _total_ms_var.set(0.0)
    return (t_count, t_ms)


def reset_aggregate(tokens: tuple) -> None:
    t_count, t_ms = tokens
    _count_var.reset(t_count)
    _total_ms_var.reset(t_ms)


def aggregate_for_event() -> tuple[int, float]:
    return _count_var.get(), _total_ms_var.get()


def _bump_aggregate(duration_ms: float) -> None:
    _count_var.set(_count_var.get() + 1)
    _total_ms_var.set(_total_ms_var.get() + duration_ms)


def _record_call(
    method: str, url: str, status: int, duration_ms: float, error: str | None
) -> None:
    """Forward to the Reporter and bump the per-request aggregate."""
    parsed = urlparse(url)
    host = parsed.netloc or url
    path = parsed.path or "/"
    reporter = Reporter._singleton  # may be None if SDK didn't initialize yet
    if reporter is not None:
        reporter.record_outgoing(
            OutgoingCall(
                ts=now(),
                method=method.upper(),
                host=host,
                path=path,
                status=status,
                duration_ms=duration_ms,
                error=error,
                source_request_id=get_request_id(),
                correlation_id=get_correlation_id(),
            )
        )
    _bump_aggregate(duration_ms)


# ------------------------------------------------------------------- httpx


def instrument_httpx() -> bool:
    """Wrap httpx.Client.send and httpx.AsyncClient.send. Idempotent."""
    global _INSTRUMENTED_HTTPX
    if _INSTRUMENTED_HTTPX:
        return True
    try:
        import httpx
    except Exception:  # noqa: BLE001
        return False

    orig_sync = httpx.Client.send
    orig_async = httpx.AsyncClient.send

    def sync_send(self, request, *args, **kwargs):  # type: ignore[no-untyped-def]
        start = time.perf_counter()
        status = 0
        err = None
        try:
            r = orig_sync(self, request, *args, **kwargs)
            status = r.status_code
            return r
        except Exception as exc:  # noqa: BLE001
            err = type(exc).__name__
            raise
        finally:
            _record_call(
                request.method,
                str(request.url),
                status,
                (time.perf_counter() - start) * 1000.0,
                err,
            )

    async def async_send(self, request, *args, **kwargs):  # type: ignore[no-untyped-def]
        start = time.perf_counter()
        status = 0
        err = None
        try:
            r = await orig_async(self, request, *args, **kwargs)
            status = r.status_code
            return r
        except Exception as exc:  # noqa: BLE001
            err = type(exc).__name__
            raise
        finally:
            _record_call(
                request.method,
                str(request.url),
                status,
                (time.perf_counter() - start) * 1000.0,
                err,
            )

    httpx.Client.send = sync_send  # type: ignore[method-assign]
    httpx.AsyncClient.send = async_send  # type: ignore[method-assign]
    _INSTRUMENTED_HTTPX = True
    return True


# ---------------------------------------------------------------- requests


def instrument_requests() -> bool:
    """Wrap requests.Session.send. Idempotent."""
    global _INSTRUMENTED_REQUESTS
    if _INSTRUMENTED_REQUESTS:
        return True
    try:
        import requests
    except Exception:  # noqa: BLE001
        return False

    orig = requests.Session.send

    def send(self, request, **kwargs):  # type: ignore[no-untyped-def]
        start = time.perf_counter()
        status = 0
        err = None
        try:
            r = orig(self, request, **kwargs)
            status = getattr(r, "status_code", 0)
            return r
        except Exception as exc:  # noqa: BLE001
            err = type(exc).__name__
            raise
        finally:
            _record_call(
                request.method or "GET",
                request.url,
                status,
                (time.perf_counter() - start) * 1000.0,
                err,
            )

    requests.Session.send = send  # type: ignore[method-assign]
    _INSTRUMENTED_REQUESTS = True
    return True


def instrument_all() -> dict[str, bool]:
    return {
        "httpx": instrument_httpx(),
        "requests": instrument_requests(),
    }
