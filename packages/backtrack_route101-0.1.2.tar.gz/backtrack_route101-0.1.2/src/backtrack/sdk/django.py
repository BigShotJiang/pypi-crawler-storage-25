"""Django middleware.

Settings:

    MIDDLEWARE = [
        "backtrack.sdk.django.BacktrackMiddleware",
        # ...
    ]
    BACKTRACK_SERVICE = "my-django-app"
    BACKTRACK_ENDPOINT = "http://127.0.0.1:9876/ingest"   # optional
    BACKTRACK_INSTRUMENT_OUTGOING = True                  # optional, default True

Captures per request: method, route template, status, duration, exception
traceback + grouping fingerprint, trace context, ORM query count + total ms
(Django connections are auto-wrapped on first request), outgoing HTTP aggregate.
"""

from __future__ import annotations

import time
from typing import Any, Callable

from . import _db, _errors, _outgoing
from ._wire import DEFAULT_ENDPOINT, Event, Reporter, now
from .correlation import (
    HEADER_CORRELATION_ID,
    HEADER_PARENT_REQUEST_ID,
    HEADER_REQUEST_ID,
    reset_context,
    resolve_incoming,
    set_context,
)


class BacktrackMiddleware:
    def __init__(self, get_response: Callable[[Any], Any]) -> None:
        from django.conf import settings

        self.get_response = get_response
        service = getattr(settings, "BACKTRACK_SERVICE", "django-app")
        endpoint = getattr(settings, "BACKTRACK_ENDPOINT", DEFAULT_ENDPOINT)
        self.reporter = Reporter.get(service=service, endpoint=endpoint)

        # Auto-instrument Django ORM + outgoing libs at construction time.
        _db.install_django()
        if getattr(settings, "BACKTRACK_INSTRUMENT_OUTGOING", True):
            _outgoing.instrument_all()

    def __call__(self, request: Any) -> Any:
        start = time.perf_counter()
        method = getattr(request, "method", "")
        path = getattr(request, "path", "")
        status = 500
        error_name: str | None = None
        captured_exc: BaseException | None = None

        in_req = _django_header(request, HEADER_REQUEST_ID)
        in_corr = _django_header(request, HEADER_CORRELATION_ID)
        in_parent = _django_header(request, HEADER_PARENT_REQUEST_ID)
        request_id, correlation_id, parent_id = resolve_incoming(in_req, in_corr, in_parent)

        tokens_ctx = set_context(request_id, correlation_id)
        db_token = _db.start_buffer()
        out_tokens = _outgoing.start_aggregate()
        self.reporter.inc_in_flight()
        response: Any = None
        try:
            response = self.get_response(request)
            status = int(getattr(response, "status_code", 500))
            try:
                response[HEADER_REQUEST_ID] = request_id
            except Exception:  # noqa: BLE001
                pass
            return response
        except Exception as exc:  # noqa: BLE001
            error_name = type(exc).__name__
            captured_exc = exc
            raise
        finally:
            reset_context(tokens_ctx)
            self.reporter.dec_in_flight()
            duration_ms = (time.perf_counter() - start) * 1000.0
            route = _resolve_route(request) or path

            db_summary = _db.summarize()
            _db.reset_buffer(db_token)
            out_count, out_total_ms = _outgoing.aggregate_for_event()
            _outgoing.reset_aggregate(out_tokens)

            err_fields: dict[str, Any] = {}
            if captured_exc is not None:
                err_fields = _errors.capture(captured_exc)

            self.reporter.record(
                Event(
                    ts=now(),
                    method=method,
                    route=route,
                    path=path,
                    status=status,
                    duration_ms=duration_ms,
                    error=error_name,
                    request_id=request_id,
                    correlation_id=correlation_id,
                    parent_id=parent_id,
                    error_type=err_fields.get("error_type"),
                    error_message=err_fields.get("error_message"),
                    error_traceback=err_fields.get("error_traceback"),
                    error_fingerprint=err_fields.get("error_fingerprint"),
                    db_query_count=db_summary[0] if db_summary else None,
                    db_total_ms=db_summary[1] if db_summary else None,
                    db_slow=db_summary[2] if db_summary else None,
                    outgoing_count=out_count or None,
                    outgoing_total_ms=out_total_ms or None,
                )
            )

    def process_exception(self, request: Any, exception: BaseException) -> None:
        return None


def _django_header(request: Any, name: str) -> str | None:
    headers = getattr(request, "headers", None)
    if headers is not None:
        try:
            return headers.get(name)
        except Exception:  # noqa: BLE001
            pass
    meta = getattr(request, "META", None)
    if isinstance(meta, dict):
        key = "HTTP_" + name.upper().replace("-", "_")
        return meta.get(key)
    return None


def _resolve_route(request: Any) -> str | None:
    try:
        from django.urls import resolve

        match = resolve(request.path)
        return getattr(match, "route", None) or match.url_name
    except Exception:  # noqa: BLE001
        return None
