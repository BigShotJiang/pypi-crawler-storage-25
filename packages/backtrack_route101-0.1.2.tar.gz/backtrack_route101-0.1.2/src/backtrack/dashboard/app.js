// backtrack dashboard — vanilla JS + Plotly.
// Polls the local collector every POLL_MS and re-renders.
// AI assist: API key lives in localStorage; analyze requests go directly
// from the browser to the chosen provider — never through the collector.

const POLL_MS = 2000;
const $ = (id) => document.getElementById(id);

const state = {
  service: "",
  windowSeconds: 300,
  view: "tree", // 'tree' | 'graph'
  lastDiscovered: { routes: [], scan_roots: [] },
  lastRuntimeRoutes: [],
  lastChains: [],
  lastDepsEdges: [],
  folderFilter: null, // e.g. "src/api"  → restrict routes table + analyze action
};

// ---------------------------------------------------------------- settings

const KEY_LS = "backtrack.aiKey";
const PROVIDER_LS = "backtrack.aiProvider";
const MODEL_LS = "backtrack.aiModel";

const DEFAULT_MODELS = {
  anthropic: "claude-sonnet-4-6",
  openai: "gpt-4o",
};

function loadSettings() {
  const provider = localStorage.getItem(PROVIDER_LS) || "anthropic";
  const model = localStorage.getItem(MODEL_LS) || DEFAULT_MODELS[provider];
  const key = localStorage.getItem(KEY_LS) || "";
  return { provider, model, key };
}

function saveSettings({ provider, model, key }) {
  localStorage.setItem(PROVIDER_LS, provider);
  localStorage.setItem(MODEL_LS, model);
  if (key) localStorage.setItem(KEY_LS, key);
}

function clearSettings() {
  localStorage.removeItem(KEY_LS);
  localStorage.removeItem(PROVIDER_LS);
  localStorage.removeItem(MODEL_LS);
}

// --------------------------------------------------------------- formatters

function fmtNum(n, digits = 1) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  if (n >= 1000) return (n / 1000).toFixed(digits) + "k";
  return n.toFixed(digits);
}
function fmtMs(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return n.toFixed(1) + " ms";
}
function fmtPct(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return (n * 100).toFixed(2) + "%";
}
function fmtMb(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return n.toFixed(0) + " MB";
}
function fmtTime(ts) {
  return new Date(ts * 1000).toLocaleTimeString();
}

// ---------------------------------------------------------------- fetching

async function get(path, params) {
  const url = new URL(path, window.location.origin);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== "" && v !== null && v !== undefined) url.searchParams.set(k, v);
    }
  }
  const r = await fetch(url);
  if (!r.ok) throw new Error(`${path} → ${r.status}`);
  return r.json();
}

// ---------------------------------------------------------------- rendering

let rpsChartInit = false;
let latencyChartInit = false;

function renderTiles(overview, services) {
  $("t-rps").textContent = fmtNum(overview.rps, 2);
  $("t-err").textContent = fmtPct(overview.error_rate);
  $("t-avg").textContent = fmtMs(overview.avg_duration_ms);
  $("t-max").textContent = fmtMs(overview.max_duration_ms);

  // Aggregate cpu/mem/in_flight across the selected service (or all).
  const matching = state.service
    ? services.filter((s) => s.service === state.service)
    : services;
  const inFlight = matching.reduce((a, b) => a + (b.in_flight || 0), 0);
  const cpuVals = matching.map((s) => s.cpu_pct).filter((v) => v !== null && v !== undefined);
  const memVals = matching.map((s) => s.mem_mb).filter((v) => v !== null && v !== undefined);
  const cpu = cpuVals.length ? cpuVals.reduce((a, b) => a + b, 0) / cpuVals.length : null;
  const mem = memVals.length ? memVals.reduce((a, b) => a + b, 0) : null;

  $("t-inflight").textContent = inFlight;
  $("t-cpu").textContent = cpu === null ? "—" : cpu.toFixed(1) + "%";
  $("t-mem").textContent = fmtMb(mem);
}

function renderRpsChart(timeseries) {
  const xs = timeseries.points.map((p) => new Date(p.ts * 1000));
  const rps = timeseries.points.map((p) => p.rps);
  const errRate = timeseries.points.map((p) => p.error_rate * 100);

  const data = [
    {
      x: xs,
      y: rps,
      name: "RPS",
      type: "scatter",
      mode: "lines",
      line: { color: "#58a6ff", width: 2 },
      yaxis: "y",
    },
    {
      x: xs,
      y: errRate,
      name: "error %",
      type: "scatter",
      mode: "lines",
      line: { color: "#f85149", width: 2, dash: "dot" },
      yaxis: "y2",
    },
  ];
  const layout = {
    margin: { l: 40, r: 50, t: 10, b: 30 },
    paper_bgcolor: "transparent",
    plot_bgcolor: "transparent",
    font: { color: "#8b95a5", size: 11 },
    showlegend: true,
    legend: { x: 0, y: 1.15, orientation: "h" },
    xaxis: { gridcolor: "#2a3342", color: "#8b95a5" },
    yaxis: { title: "RPS", gridcolor: "#2a3342", color: "#58a6ff", rangemode: "tozero" },
    yaxis2: {
      title: "err %",
      overlaying: "y",
      side: "right",
      gridcolor: "transparent",
      color: "#f85149",
      rangemode: "tozero",
    },
  };
  const config = { displayModeBar: false, responsive: true };
  if (!rpsChartInit) {
    Plotly.newPlot("chart-rps", data, layout, config);
    rpsChartInit = true;
  } else {
    Plotly.react("chart-rps", data, layout, config);
  }
}

function renderLatencyChart(timeseries) {
  const xs = timeseries.points.map((p) => new Date(p.ts * 1000));
  const avg = timeseries.points.map((p) => p.avg_ms);
  const data = [
    {
      x: xs,
      y: avg,
      name: "avg",
      type: "scatter",
      mode: "lines",
      fill: "tozeroy",
      line: { color: "#3fb950", width: 2 },
      fillcolor: "rgba(63,185,80,0.15)",
    },
  ];
  const layout = {
    margin: { l: 40, r: 20, t: 10, b: 30 },
    paper_bgcolor: "transparent",
    plot_bgcolor: "transparent",
    font: { color: "#8b95a5", size: 11 },
    showlegend: false,
    xaxis: { gridcolor: "#2a3342", color: "#8b95a5" },
    yaxis: { title: "ms", gridcolor: "#2a3342", color: "#8b95a5", rangemode: "tozero" },
  };
  const config = { displayModeBar: false, responsive: true };
  if (!latencyChartInit) {
    Plotly.newPlot("chart-latency", data, layout, config);
    latencyChartInit = true;
  } else {
    Plotly.react("chart-latency", data, layout, config);
  }
}

function renderRoutes(routes) {
  const tbody = document.querySelector("#routes-table tbody");
  tbody.innerHTML = "";
  if (routes.length === 0) {
    tbody.innerHTML = `<tr><td colspan="11" class="muted">no traffic in this window yet — start your app and hit some endpoints</td></tr>`;
    return;
  }
  for (const r of routes) {
    const tr = document.createElement("tr");
    const errCls = r.error_rate > 0 ? "err-status" : "";
    // N+1 hint: if avg query count is high, mark the DB cell red.
    const dbCls = (r.avg_db_queries || 0) >= 10 ? "err-status" : "";
    tr.innerHTML = `
      <td><span class="method-tag method-${r.method}">${r.method}</span></td>
      <td>${escape(r.route)}</td>
      <td class="num">${fmtNum(r.rps, 2)}</td>
      <td class="num ${errCls}">${fmtPct(r.error_rate)}</td>
      <td class="num">${fmtMs(r.avg_ms)}</td>
      <td class="num">${fmtMs(r.max_ms)}</td>
      <td class="num ${dbCls}">${r.avg_db_queries == null ? "—" : fmtNum(r.avg_db_queries, 1)}</td>
      <td class="num">${r.avg_db_ms == null ? "—" : fmtMs(r.avg_db_ms)}</td>
      <td class="num">${r.avg_outgoing == null ? "—" : fmtNum(r.avg_outgoing, 1)}</td>
      <td class="num">${r.total}</td>
      <td class="num"><button class="analyze-btn" data-method="${r.method}" data-route="${escape(r.route)}">analyze</button></td>
    `;
    tbody.appendChild(tr);
  }
  tbody.querySelectorAll(".analyze-btn").forEach((btn) => {
    btn.addEventListener("click", () =>
      openAnalyze(btn.dataset.method, btn.dataset.route),
    );
  });
}

function renderErrorGroups(groups) {
  const list = $("errors-list");
  const meta = $("errors-meta");
  list.innerHTML = "";
  if (!groups || groups.length === 0) {
    list.innerHTML = `<div class="muted" style="padding: 8px 0">no exceptions recorded — nice.</div>`;
    meta.textContent = "";
    return;
  }
  const totalCount = groups.reduce((a, b) => a + (b.count || 0), 0);
  meta.textContent = `${groups.length} group(s), ${totalCount} occurrence(s)`;
  for (const g of groups) {
    const card = document.createElement("div");
    card.className = "err-group";
    const routesLabel = (g.affected_routes || [])
      .map((r) => `${r.method} ${r.route} (${r.count})`)
      .join(", ");
    card.innerHTML = `
      <div class="err-group-header">
        <span class="err-count">${g.count}×</span>
        <span class="err-type">${escape(g.error_type || "Error")}</span>
        <span class="err-msg">${escape(g.error_message || "")}</span>
        <span class="err-last">last ${fmtTime(g.last_seen)}</span>
      </div>
      <div class="err-group-meta muted">routes: ${escape(routesLabel || "—")}</div>
      <pre class="err-traceback hidden">${escape(g.sample_traceback || "(no traceback)")}</pre>
    `;
    const header = card.querySelector(".err-group-header");
    const tb = card.querySelector(".err-traceback");
    header.addEventListener("click", () => tb.classList.toggle("hidden"));
    list.appendChild(card);
  }
}

function renderOutgoing(hosts) {
  const tbody = document.querySelector("#outgoing-table tbody");
  tbody.innerHTML = "";
  if (!hosts || hosts.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" class="muted">no outgoing HTTP calls recorded yet — instrument with <code>backtrack.sdk.instrument_all()</code> or via the middleware</td></tr>`;
    return;
  }
  for (const h of hosts) {
    const tr = document.createElement("tr");
    const errCls = h.error_rate > 0 ? "err-status" : "";
    tr.innerHTML = `
      <td>${escape(h.host)}</td>
      <td class="num">${h.calls}</td>
      <td class="num ${errCls}">${fmtPct(h.error_rate)}</td>
      <td class="num">${fmtMs(h.avg_ms)}</td>
      <td class="num">${fmtMs(h.max_ms)}</td>
      <td class="num">${fmtMs(h.total_ms)}</td>
    `;
    tbody.appendChild(tr);
  }
}

function escape(s) {
  return String(s).replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]),
  );
}

// ----------------------------------------------------------------- polling

let inFlightPoll = false;

async function poll() {
  if (inFlightPoll) return;
  inFlightPoll = true;
  try {
    const params = { service: state.service, w: state.windowSeconds };
    const [services, overview, timeseries, routes, discovered, chains, errGroups, outgoing, depsEdges] =
      await Promise.all([
        get("/api/services"),
        get("/api/overview", params),
        get("/api/timeseries", { ...params, bucket: bucketFor(state.windowSeconds) }),
        get("/api/routes", params),
        get("/api/discovered", { service: state.service }),
        get("/api/route_chains", params),
        get("/api/error_groups", params),
        get("/api/outgoing", params),
        get("/api/route_host_calls", params),
      ]);
    refreshServiceOptions(services.services, discovered.scan_roots);
    renderTiles(overview, services.services);
    renderRpsChart(timeseries);
    renderLatencyChart(timeseries);
    state.lastDiscovered = discovered;
    state.lastRuntimeRoutes = routes.routes;
    state.lastChains = chains.chains || [];
    state.lastDepsEdges = depsEdges.edges || [];
    renderRoutes(filteredRoutes(routes.routes));
    renderErrorGroups(errGroups.groups || []);
    renderOutgoing(outgoing.hosts || []);
    renderFolderFilterBar();
    renderProjectView();
  } catch (e) {
    console.error("poll failed", e);
  } finally {
    inFlightPoll = false;
  }
}

function bucketFor(window) {
  if (window <= 60) return 1;
  if (window <= 300) return 5;
  if (window <= 900) return 15;
  return 60;
}

function refreshServiceOptions(services, scanRoots) {
  const sel = $("service-select");
  const current = sel.value;
  const have = new Set(Array.from(sel.options).map((o) => o.value));
  // Services from both live heartbeats and from static scans.
  const names = new Set();
  for (const s of services) names.add(s.service);
  for (const r of scanRoots || []) names.add(r.service);
  for (const name of names) {
    if (!have.has(name)) {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      sel.appendChild(opt);
    }
  }
  if (current) sel.value = current;
}

// ----------------------------------------------------------- project view

function renderProjectView() {
  const discovered = state.lastDiscovered;
  const runtime = state.lastRuntimeRoutes;
  updateProjectMeta(discovered);
  if (state.view === "tree") {
    renderProjectTree(discovered, runtime);
  } else {
    renderProjectGraph(discovered, runtime);
  }
}

function updateProjectMeta(discovered) {
  const meta = $("project-meta");
  const scanRoots = discovered.scan_roots || [];
  if (state.service) {
    const sr = scanRoots.find((s) => s.service === state.service);
    meta.textContent = sr
      ? `${sr.routes} routes scanned from ${sr.scan_root}`
      : "no scan for this service yet";
  } else {
    const total = scanRoots.reduce((a, b) => a + (b.routes || 0), 0);
    meta.textContent = scanRoots.length
      ? `${total} routes across ${scanRoots.length} service(s)`
      : "";
  }
}

function renderProjectTree(discovered, runtimeRoutes) {
  const container = $("project-tree");
  const routes = discovered.routes || [];

  if (routes.length === 0) {
    container.innerHTML = `<div class="muted" style="padding: 8px 12px">
      No routes discovered. Pass <code>--scan PATH</code> to <code>backtrack start</code>,
      or type a path above and click scan.
    </div>`;
    return;
  }

  // Build a runtime-route lookup so we can show live RPS / err inline.
  // Key: METHOD + " " + routeTemplate. Wildcard methods ("*") fall back to any.
  const runtimeByExact = new Map();
  const runtimeByRoute = new Map();
  for (const r of runtimeRoutes) {
    runtimeByExact.set(`${r.method} ${r.route}`, r);
    if (!runtimeByRoute.has(r.route)) runtimeByRoute.set(r.route, []);
    runtimeByRoute.get(r.route).push(r);
  }

  // Build the folder tree: { dirs: {name: subtree}, files: {filename: [routes]} }
  const tree = { dirs: {}, files: {} };
  for (const r of routes) {
    const parts = (r.file || "").split("/").filter(Boolean);
    let node = tree;
    for (let i = 0; i < parts.length - 1; i++) {
      const seg = parts[i];
      node.dirs[seg] = node.dirs[seg] || { dirs: {}, files: {} };
      node = node.dirs[seg];
    }
    const fname = parts[parts.length - 1] || "(root)";
    node.files[fname] = node.files[fname] || [];
    node.files[fname].push(r);
  }

  container.innerHTML = "";
  container.appendChild(buildTreeNode(tree, "", runtimeByExact, runtimeByRoute));
}

function buildTreeNode(node, pathSoFar, runtimeByExact, runtimeByRoute) {
  const frag = document.createDocumentFragment();
  const dirNames = Object.keys(node.dirs).sort();
  const fileNames = Object.keys(node.files).sort();

  for (const dirName of dirNames) {
    const wrap = document.createElement("div");
    const head = document.createElement("div");
    head.className = "tree-dir";
    const fullPath = pathSoFar ? `${pathSoFar}/${dirName}` : dirName;
    const isFiltered = state.folderFilter === fullPath;
    head.innerHTML = `
      <span class="twirl">▼</span>
      <span>📁 ${escape(dirName)}/</span>
      <span class="tree-filter-link${isFiltered ? " active" : ""}" data-folder="${escape(fullPath)}">${isFiltered ? "filtering" : "filter"}</span>
    `;
    const children = document.createElement("div");
    children.className = "tree-children";
    children.appendChild(
      buildTreeNode(
        node.dirs[dirName],
        fullPath,
        runtimeByExact,
        runtimeByRoute,
      ),
    );
    head.addEventListener("click", (e) => {
      if (e.target && e.target.classList?.contains("tree-filter-link")) {
        const folder = e.target.dataset.folder;
        if (state.folderFilter === folder) clearFolderFilter();
        else setFolderFilter(folder);
        e.stopPropagation();
        return;
      }
      head.classList.toggle("collapsed");
      children.classList.toggle("hidden");
    });
    wrap.appendChild(head);
    wrap.appendChild(children);
    frag.appendChild(wrap);
  }

  for (const fileName of fileNames) {
    const fileWrap = document.createElement("div");
    const fileLine = document.createElement("div");
    fileLine.className = "tree-file";
    fileLine.innerHTML = `<span class="file-icon">📄</span><span>${escape(fileName)}</span>`;
    fileWrap.appendChild(fileLine);

    const routes = node.files[fileName];
    for (const r of routes) {
      const row = document.createElement("div");
      row.className = "tree-route";
      const liveExact = runtimeByExact.get(`${r.method} ${r.route}`);
      const liveAny = liveExact || (runtimeByRoute.get(r.route) || [])[0];
      if (!liveAny) row.classList.add("discovered-only");
      const stats = liveAny
        ? `<span class="route-stats">
            <span class="live">${fmtNum(liveAny.rps, 2)} rps</span>
            <span class="${liveAny.error_rate > 0 ? "err" : ""}">${fmtPct(liveAny.error_rate)}</span>
            <span>${fmtMs(liveAny.avg_ms)}</span>
          </span>`
        : `<span class="route-stats"><span>no traffic yet</span></span>`;
      row.innerHTML = `
        <span class="method-tag method-${escape(r.method)}">${escape(r.method)}</span>
        <span class="route-text">${escape(r.route)}</span>
        ${r.function ? `<span class="route-fn">${escape(r.function)}</span>` : ""}
        ${stats}
      `;
      if (liveAny) {
        row.addEventListener("click", () => openAnalyze(liveAny.method, liveAny.route));
      }
      fileWrap.appendChild(row);
    }
    frag.appendChild(fileWrap);
  }

  return frag;
}

// ------------------------------------------------------- folder filtering

function setFolderFilter(folder) {
  state.folderFilter = folder && folder.trim() ? folder.replace(/^\/+|\/+$/g, "") : null;
  // Immediate re-render off cached data — feels snappier than waiting for poll.
  renderRoutes(filteredRoutes(state.lastRuntimeRoutes));
  renderFolderFilterBar();
  renderProjectView();
}

function clearFolderFilter() {
  setFolderFilter(null);
}

function filteredRoutes(runtimeRoutes) {
  if (!state.folderFilter) return runtimeRoutes;
  const allowed = routesInFolder(state.folderFilter);
  if (!allowed.size) return [];
  return runtimeRoutes.filter((rt) => {
    // Allow either a method-exact match or a wildcard discovered method "*"
    if (allowed.has(`${rt.method} ${rt.route}`)) return true;
    if (allowed.has(`* ${rt.route}`)) return true;
    return false;
  });
}

function routesInFolder(folder) {
  const set = new Set();
  const folderNorm = (folder || "").replace(/^\/+|\/+$/g, "");
  const prefix = folderNorm + "/";
  for (const d of state.lastDiscovered.routes || []) {
    if (!d.file) continue;
    if (d.file === folderNorm || d.file.startsWith(prefix)) {
      set.add(`${d.method} ${d.route}`);
    }
  }
  return set;
}

function renderFolderFilterBar() {
  const bar = $("folder-filter-bar");
  if (!state.folderFilter) {
    bar.classList.add("hidden");
    return;
  }
  bar.classList.remove("hidden");
  $("folder-filter-name").textContent = state.folderFilter + "/";
  const allowed = routesInFolder(state.folderFilter);
  const matched = filteredRoutes(state.lastRuntimeRoutes);
  const totalReq = matched.reduce((a, b) => a + (b.total || 0), 0);
  $("folder-filter-stats").textContent =
    `${allowed.size} discovered route(s), ${matched.length} with live traffic, ${totalReq} requests in window`;
}

async function analyzeFolder() {
  if (!state.service) {
    alert("Pick a service first.");
    return;
  }
  if (!state.folderFilter) {
    alert("No folder selected.");
    return;
  }
  $("analyze-modal").classList.remove("hidden");
  $("analyze-title").textContent = `Analyze folder: ${state.folderFilter}/`;
  $("analyze-status").textContent = "loading folder snapshot…";
  $("analyze-snapshot").textContent = "";
  $("analyze-output").textContent = "";

  let snapshot;
  try {
    snapshot = await get("/api/folder/snapshot", {
      service: state.service,
      folder: state.folderFilter,
      w: 600,
    });
  } catch (e) {
    $("analyze-status").textContent = `failed to fetch folder snapshot: ${e.message}`;
    return;
  }
  $("analyze-snapshot").textContent = JSON.stringify(snapshot, null, 2);

  const settings = loadSettings();
  if (!settings.key) {
    $("analyze-status").textContent =
      "No API key configured. Click 'settings' (top-right) to add one.";
    return;
  }
  $("analyze-status").textContent = `calling ${settings.provider} (${settings.model})…`;
  try {
    const text = await callProvider(settings, buildFolderPrompt(snapshot));
    $("analyze-status").textContent = "done.";
    $("analyze-output").textContent = text;
  } catch (e) {
    $("analyze-status").textContent = `provider error: ${e.message}`;
  }
}

function buildFolderPrompt(snapshot) {
  return [
    "You are a senior backend SRE. The following is an aggregated snapshot of all API routes whose handlers live under a single folder in the codebase.",
    "",
    "Identify:",
    "1. Hot spots (highest RPS or worst error rate within this folder).",
    "2. Coupling smells visible from the metrics (e.g. one route dominating traffic, error rates concentrated in one file).",
    "3. Concrete refactors / robustness improvements scoped to this folder.",
    "4. Whether the folder's boundary looks right or whether some routes belong elsewhere.",
    "Be specific. Reference route names and numbers. Keep it under 350 words.",
    "",
    "Snapshot:",
    JSON.stringify(snapshot, null, 2),
  ].join("\n");
}

// --------------------------------------------------------- deps graph
//
// Bipartite view: routes on the left, external hosts on the right, edges
// weighted by outgoing call count and colored by error rate.
//
// This answers "what does this service depend on, and where do the problems
// concentrate?" — a question the routes table can't show on its own.
// Data source: GET /api/route_host_calls (a JOIN of outgoing_calls + events).

let cy = null;             // Cytoscape instance (lazy)
let lastGraphSig = "";     // signature of the rendered element set

const GRAPH_STYLES = [
  // Route nodes (left column)
  {
    selector: 'node[type = "route"]',
    style: {
      "background-color": "data(color)",
      "border-color": "#0d1117",
      "border-width": 2,
      shape: "round-rectangle",
      width: "data(width)",
      height: 28,
      label: "data(label)",
      color: "#e6edf3",
      "font-size": 11,
      "font-family": "ui-monospace, monospace",
      "text-valign": "center",
      "text-halign": "center",
      "text-max-width": 240,
      "text-wrap": "ellipsis",
      "text-outline-color": "#0d1117",
      "text-outline-width": 1,
      padding: "6px",
    },
  },
  // External host nodes (right column)
  {
    selector: 'node[type = "host"]',
    style: {
      "background-color": "#1c2330",
      "border-color": "data(border)",
      "border-width": 2,
      shape: "round-rectangle",
      width: "data(width)",
      height: 32,
      label: "data(label)",
      color: "#e6edf3",
      "font-size": 11,
      "font-family": "ui-monospace, monospace",
      "text-valign": "center",
      "text-halign": "center",
      "text-max-width": 220,
      "text-wrap": "ellipsis",
      padding: "8px",
    },
  },
  // Column headers (decorative)
  {
    selector: 'node[type = "header"]',
    style: {
      "background-opacity": 0,
      "border-opacity": 0,
      shape: "round-rectangle",
      label: "data(label)",
      color: "#8b95a5",
      "font-size": 11,
      "font-weight": 600,
      "text-transform": "uppercase",
      "text-valign": "center",
      "text-halign": "center",
      width: 200,
      height: 20,
    },
  },
  // Edges = (route → host) calls
  {
    selector: "edge[type = 'dep']",
    style: {
      width: "data(width)",
      "line-color": "data(color)",
      "line-opacity": 0.7,
      "curve-style": "bezier",
      "target-arrow-shape": "triangle",
      "target-arrow-color": "data(color)",
      "arrow-scale": 0.9,
      label: "data(label)",
      "font-size": 10,
      color: "#c8d0db",
      "text-background-color": "#0d1117",
      "text-background-opacity": 0.85,
      "text-background-padding": 2,
    },
  },
  // Active hover
  {
    selector: 'node:active',
    style: { "overlay-opacity": 0.15, "overlay-color": "#58a6ff" },
  },
];

const COL_LEFT_X = 120;     // x-position of the routes column
const COL_RIGHT_X = 720;    // x-position of the hosts column
const ROW_HEIGHT = 50;      // vertical spacing between rows in a column

function renderProjectGraph(/* discovered, runtimeRoutes — unused now */) {
  const container = $("project-graph");
  if (!window.cytoscape) {
    container.innerHTML = `<div class="graph-empty">Cytoscape failed to load (offline?).</div>`;
    return;
  }
  const edges = state.lastDepsEdges || [];
  if (edges.length === 0) {
    container.innerHTML = `<div class="graph-empty">
      No outgoing HTTP calls recorded for this service yet.<br/>
      The middleware auto-instruments <code>httpx</code> + <code>requests</code> — make a
      request that fans out to another service and refresh.
    </div>`;
    if (cy) {
      cy.destroy();
      cy = null;
      lastGraphSig = "";
    }
    return;
  }
  if (container.firstChild && container.firstChild.classList?.contains("graph-empty")) {
    container.innerHTML = "";
  }

  const elements = buildDepsElements(edges);
  const sig = elements
    .map((e) => (e.group === "edges" ? `e:${e.data.id}` : `n:${e.data.id}`))
    .sort()
    .join("|");

  if (!cy) {
    cy = cytoscape({
      container,
      elements,
      style: GRAPH_STYLES,
      layout: { name: "preset" },  // we set positions directly in buildDepsElements
      wheelSensitivity: 0.2,
      boxSelectionEnabled: false,
      selectionType: "single",
    });
    cy.on("tap", 'node[type = "route"]', (evt) => {
      const d = evt.target.data();
      if (d.method && d.route) openAnalyze(d.method, d.route);
    });
    lastGraphSig = sig;
    requestAnimationFrame(() => {
      cy.resize();
      cy.fit(undefined, 40);
    });
    return;
  }

  if (sig !== lastGraphSig) {
    cy.elements().remove();
    cy.add(elements);
    cy.layout({ name: "preset" }).run();
    cy.fit(undefined, 40);
    lastGraphSig = sig;
    return;
  }

  // Same structure — refresh per-element data (count, color, error rate) only.
  cy.batch(() => {
    for (const el of elements) {
      const n = cy.getElementById(el.data.id);
      if (!n.empty()) n.data(el.data);
    }
  });
}

function buildDepsElements(edges) {
  // Aggregate per-route and per-host totals (for node sizing).
  const routeTotals = new Map();   // "METHOD ROUTE" -> { calls, errors, avg_ms_sum, max_ms, label, method, route }
  const hostTotals = new Map();    // host -> { calls, errors, avg_ms_sum, max_ms }
  let maxEdgeCount = 1;

  for (const e of edges) {
    const rKey = `${e.method} ${e.route}`;
    const r = routeTotals.get(rKey) || {
      calls: 0,
      errors: 0,
      method: e.method,
      route: e.route,
      label: `${e.method} ${e.route}`,
    };
    r.calls += e.calls || 0;
    r.errors += e.errors || 0;
    routeTotals.set(rKey, r);

    const h = hostTotals.get(e.host) || { calls: 0, errors: 0 };
    h.calls += e.calls || 0;
    h.errors += e.errors || 0;
    hostTotals.set(e.host, h);

    if (e.calls > maxEdgeCount) maxEdgeCount = e.calls;
  }

  // Sort by traffic descending and assign positions.
  const routeList = [...routeTotals.entries()].sort((a, b) => b[1].calls - a[1].calls);
  const hostList = [...hostTotals.entries()].sort((a, b) => b[1].calls - a[1].calls);

  const elements = [];
  // Column headers
  const topY = 0;
  elements.push({
    group: "nodes",
    data: { id: "hdr-routes", type: "header", label: "routes" },
    position: { x: COL_LEFT_X, y: topY },
  });
  elements.push({
    group: "nodes",
    data: { id: "hdr-hosts", type: "header", label: "external hosts" },
    position: { x: COL_RIGHT_X, y: topY },
  });

  const routeY0 = topY + 40;
  const hostY0 = topY + 40;

  const routeIdMap = new Map();
  routeList.forEach(([key, r], idx) => {
    const id = `route:${key}`;
    routeIdMap.set(key, id);
    const errRate = r.calls > 0 ? r.errors / r.calls : 0;
    elements.push({
      group: "nodes",
      data: {
        id,
        type: "route",
        label: r.label,
        method: r.method,
        route: r.route,
        calls: r.calls,
        errors: r.errors,
        color: nodeColorForErrRate(errRate, true),
        width: routeWidthForLabel(r.label),
      },
      position: { x: COL_LEFT_X, y: routeY0 + idx * ROW_HEIGHT },
    });
  });

  const hostIdMap = new Map();
  hostList.forEach(([host, h], idx) => {
    const id = `host:${host}`;
    hostIdMap.set(host, id);
    const errRate = h.calls > 0 ? h.errors / h.calls : 0;
    elements.push({
      group: "nodes",
      data: {
        id,
        type: "host",
        label: host,
        calls: h.calls,
        errors: h.errors,
        border: errRate >= 0.05 ? "#f85149" : errRate > 0 ? "#d29922" : "#3fb950",
        width: hostWidthForLabel(host),
      },
      position: { x: COL_RIGHT_X, y: hostY0 + idx * ROW_HEIGHT },
    });
  });

  // Edges
  for (const e of edges) {
    const srcId = routeIdMap.get(`${e.method} ${e.route}`);
    const dstId = hostIdMap.get(e.host);
    if (!srcId || !dstId) continue;
    elements.push({
      group: "edges",
      data: {
        id: `dep:${srcId}->${dstId}`,
        source: srcId,
        target: dstId,
        type: "dep",
        count: e.calls,
        error_rate: e.error_rate,
        // Width scales 1.5 → 8 with relative traffic
        width: 1.5 + (e.calls / maxEdgeCount) * 6.5,
        color: e.error_rate >= 0.05
          ? "#f85149"
          : e.error_rate > 0
          ? "#d29922"
          : "#58a6ff",
        label: `${e.calls}× · ${Math.round(e.avg_ms)}ms`,
      },
    });
  }
  return elements;
}

function routeWidthForLabel(label) {
  // Approximate: 8 px per char in our mono font, plus 24 px padding, capped at 280.
  return Math.min(280, Math.max(120, label.length * 8 + 24));
}

function hostWidthForLabel(label) {
  return Math.min(260, Math.max(120, label.length * 8 + 24));
}

function nodeSizeForRps(rps) {
  if (!rps || rps <= 0) return 22;
  // log-scaled so a 100x traffic difference doesn't blow node sizes off-screen.
  return Math.min(72, 22 + Math.log10(1 + rps * 1000) * 12);
}

function nodeColorForErrRate(rate, hasRuntime) {
  if (!hasRuntime) return "#4a5260";
  if (rate >= 0.05) return "#f85149";
  if (rate > 0) return "#d29922";
  return "#3fb950";
}

// ----------------------------------------------------------- scan trigger

async function triggerScan() {
  const path = $("scan-path").value.trim();
  if (!path) {
    alert("enter a path to scan");
    return;
  }
  const service = state.service || prompt("service name for this scan:", "my-api");
  if (!service) return;
  const btn = $("scan-btn");
  btn.disabled = true;
  btn.textContent = "scanning…";
  try {
    const r = await fetch("/api/scan", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ service, path }),
    });
    if (!r.ok) {
      const t = await r.text();
      alert(`scan failed: ${r.status} ${t}`);
      return;
    }
    const j = await r.json();
    console.log("scan result", j);
    // Make sure the new service is selected so the tree shows up.
    if (!state.service) {
      state.service = service;
      const sel = $("service-select");
      if (!Array.from(sel.options).some((o) => o.value === service)) {
        const opt = document.createElement("option");
        opt.value = service;
        opt.textContent = service;
        sel.appendChild(opt);
      }
      sel.value = service;
    }
    await poll();
  } finally {
    btn.disabled = false;
    btn.textContent = "scan";
  }
}

// --------------------------------------------------------------- AI assist

async function openAnalyze(method, route) {
  $("analyze-modal").classList.remove("hidden");
  $("analyze-title").textContent = `Analyze: ${method} ${route}`;
  $("analyze-status").textContent = "loading snapshot…";
  $("analyze-snapshot").textContent = "";
  $("analyze-output").textContent = "";

  const service = state.service;
  if (!service) {
    $("analyze-status").textContent = "Pick a specific service first (top-left).";
    return;
  }

  let snapshot;
  try {
    snapshot = await get("/api/route/snapshot", { service, method, route, w: 600 });
  } catch (e) {
    $("analyze-status").textContent = `failed to fetch snapshot: ${e.message}`;
    return;
  }
  $("analyze-snapshot").textContent = JSON.stringify(snapshot, null, 2);

  const settings = loadSettings();
  if (!settings.key) {
    $("analyze-status").textContent =
      "No API key configured. Click 'settings' (top-right) to add one.";
    return;
  }

  $("analyze-status").textContent = `calling ${settings.provider} (${settings.model})…`;
  try {
    const text = await callProvider(settings, buildPrompt(snapshot));
    $("analyze-status").textContent = "done.";
    $("analyze-output").textContent = text;
  } catch (e) {
    $("analyze-status").textContent = `provider error: ${e.message}`;
  }
}

function buildPrompt(snapshot) {
  return [
    "You are a senior backend SRE. Analyze the following API route metrics from a backtrack snapshot.",
    "",
    "Tell the engineer:",
    "1. Likely root causes for any elevated error rate or latency.",
    "2. Concrete, prioritized mitigations they can apply now (caching, retries, timeouts, query patterns, batching, rate limiting, etc.).",
    "3. Robustness improvements they should make even if metrics look healthy.",
    "Be specific. Reference the numbers. Keep it under 300 words.",
    "",
    "Snapshot:",
    JSON.stringify(snapshot, null, 2),
  ].join("\n");
}

async function callProvider({ provider, model, key }, prompt) {
  if (provider === "anthropic") return callAnthropic(model, key, prompt);
  if (provider === "openai") return callOpenAI(model, key, prompt);
  throw new Error(`unknown provider: ${provider}`);
}

// --------------------- provider calls (model-agnostic) ---------------------
//
// The goal here is one code path per provider that works across the whole
// model family — old chat models, newer reasoning models, and anything in
// between — without the user having to pick a "right" model name.
//
// Anthropic: max_tokens is required and the field name has never changed.
//   The content array may contain {type:"text"|"thinking"|"tool_use"} blocks;
//   we keep just the text blocks. anthropic-version 2023-06-01 is the long-
//   term-stable major and is accepted by every current model.
//
// OpenAI: legacy chat models accept `max_tokens`; o1/o3/gpt-5 family REQUIRE
//   `max_completion_tokens`. We send the new name first; on the specific 400
//   error that complains about the param we retry with the legacy name. We
//   also avoid sending temperature/top_p so reasoning models that reject them
//   don't fail. Response content lives in choices[0].message.content for
//   chat-completions across all model families.

const PROVIDER_TOKEN_BUDGET = 4096; // headroom for reasoning models, ample for chat models

async function callAnthropic(model, key, prompt) {
  const body = {
    model,
    max_tokens: PROVIDER_TOKEN_BUDGET,
    messages: [{ role: "user", content: prompt }],
  };
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`${r.status} ${friendlyError(t)}`);
  }
  const j = await r.json();
  return extractAnthropicText(j);
}

function extractAnthropicText(j) {
  // content is an array of typed blocks. We keep only text blocks.
  if (Array.isArray(j?.content)) {
    const out = j.content
      .filter((b) => b && (b.type === "text" || typeof b.text === "string"))
      .map((b) => b.text)
      .filter(Boolean)
      .join("\n");
    if (out) return out;
  }
  // Defensive fallbacks for any future shape.
  if (typeof j?.content === "string") return j.content;
  if (typeof j?.completion === "string") return j.completion; // legacy text completions
  return "(empty response)";
}

async function callOpenAI(model, key, prompt) {
  const send = async (tokenField) => {
    const body = {
      model,
      messages: [{ role: "user", content: prompt }],
      [tokenField]: PROVIDER_TOKEN_BUDGET,
    };
    return fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${key}`,
      },
      body: JSON.stringify(body),
    });
  };

  // 1) Try the new field (required by o1/o3/gpt-5/reasoning models).
  let r = await send("max_completion_tokens");
  if (r.status === 400) {
    const text = await r.text();
    // 2) Older chat models (gpt-3.5/gpt-4 base) don't know the new field —
    //    retry with the legacy name.
    if (
      /max_completion_tokens/i.test(text) &&
      /unsupported|unrecognized|unknown|not.*support|invalid/i.test(text)
    ) {
      r = await send("max_tokens");
    } else {
      throw new Error(`${r.status} ${friendlyError(text)}`);
    }
  }
  if (!r.ok) {
    const t = await r.text();
    throw new Error(`${r.status} ${friendlyError(t)}`);
  }
  const j = await r.json();
  return extractOpenAIText(j);
}

function extractOpenAIText(j) {
  const choice = j?.choices?.[0];
  const msg = choice?.message;
  if (!msg) return "(empty response)";
  // Normal completions
  if (typeof msg.content === "string" && msg.content.trim()) return msg.content;
  // Some models return content as an array of {type:"text"|...} blocks
  if (Array.isArray(msg.content)) {
    const txt = msg.content
      .map((b) => (typeof b === "string" ? b : b?.text))
      .filter(Boolean)
      .join("\n");
    if (txt) return txt;
  }
  // Refusal field (some safety-trained models)
  if (typeof msg.refusal === "string" && msg.refusal.trim()) return `(refusal) ${msg.refusal}`;
  // Reasoning-only response with finish_reason="length" — content was eaten by reasoning.
  if (choice?.finish_reason === "length") {
    return "(model exhausted token budget on reasoning — try a smaller/non-reasoning model)";
  }
  return "(empty response)";
}

function friendlyError(text) {
  // Try to extract the human-readable message from a JSON error envelope.
  try {
    const j = JSON.parse(text);
    return j?.error?.message || j?.message || text.slice(0, 240);
  } catch {
    return text.slice(0, 240);
  }
}

// ----------------------------------------------------------------- wiring

function wireSettings() {
  const modal = $("settings-modal");
  $("settings-btn").addEventListener("click", () => {
    const s = loadSettings();
    $("ai-provider").value = s.provider;
    $("ai-model").value = s.model;
    $("ai-key").value = s.key;
    $("ai-model").placeholder = DEFAULT_MODELS[s.provider];
    modal.classList.remove("hidden");
  });
  $("ai-provider").addEventListener("change", (e) => {
    $("ai-model").placeholder = DEFAULT_MODELS[e.target.value];
    if (!$("ai-model").value) $("ai-model").value = DEFAULT_MODELS[e.target.value];
  });
  $("settings-save").addEventListener("click", () => {
    saveSettings({
      provider: $("ai-provider").value,
      model: $("ai-model").value || DEFAULT_MODELS[$("ai-provider").value],
      key: $("ai-key").value.trim(),
    });
    modal.classList.add("hidden");
  });
  $("settings-clear").addEventListener("click", () => {
    clearSettings();
    $("ai-key").value = "";
  });
  $("settings-close").addEventListener("click", () => modal.classList.add("hidden"));

  $("analyze-close").addEventListener("click", () =>
    $("analyze-modal").classList.add("hidden"),
  );
}

function wireFilters() {
  $("service-select").addEventListener("change", (e) => {
    state.service = e.target.value;
    // Folder filter is scoped to a service — drop it when switching.
    state.folderFilter = null;
    poll();
  });
  $("window-select").addEventListener("change", (e) => {
    state.windowSeconds = parseInt(e.target.value, 10);
    poll();
  });
  $("folder-clear-btn").addEventListener("click", () => clearFolderFilter());
  $("folder-analyze-btn").addEventListener("click", () => analyzeFolder());
}

function wireScan() {
  $("scan-btn").addEventListener("click", triggerScan);
  $("scan-path").addEventListener("keydown", (e) => {
    if (e.key === "Enter") triggerScan();
  });
}

function wireViewTabs() {
  const tabs = document.querySelectorAll(".view-tab");
  for (const tab of tabs) {
    tab.addEventListener("click", () => {
      const view = tab.dataset.view;
      if (view === state.view) return;
      state.view = view;
      tabs.forEach((t) => t.classList.toggle("active", t === tab));
      $("project-tree").classList.toggle("hidden", view !== "tree");
      $("project-graph-wrap").classList.toggle("hidden", view !== "graph");
      renderProjectView();
      // Cytoscape needs a resize+fit after un-hiding the canvas.
      if (view === "graph" && cy) {
        requestAnimationFrame(() => {
          cy.resize();
          cy.fit(undefined, 30);
        });
      }
    });
  }
  // The deps view uses a preset layout — no "relayout" makes sense, just fit.
  const fitBtn = $("graph-fit");
  if (fitBtn) {
    fitBtn.addEventListener("click", () => {
      if (cy) cy.fit(undefined, 40);
    });
  }
}

wireSettings();
wireFilters();
wireScan();
wireViewTabs();
poll();
setInterval(poll, POLL_MS);
