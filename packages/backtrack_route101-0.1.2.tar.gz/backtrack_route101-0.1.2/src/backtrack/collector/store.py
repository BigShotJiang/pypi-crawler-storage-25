"""SQLite-backed metric store.

Schema:
  events       — one row per request, retained for `event_retention_seconds`.
  service_state — last-known cpu/mem/in_flight per service+pid (heartbeat).

Rollups are computed on read instead of materialized — the volume in a
local-only tool is small enough that grouping + aggregating events on each
poll is cheap (tens of thousands of rows per minute, max).
"""

from __future__ import annotations

import json
import sqlite3
import threading
import time
from collections.abc import Iterable
from pathlib import Path
from typing import Any

DEFAULT_RETENTION_SECONDS = 60 * 60  # keep 1h of raw events

# Schema is split so we can run table DDL → ALTER TABLE migrations → index DDL.
# Indexes that reference columns added by migration would otherwise fail on
# old databases ("no such column: error_fingerprint", etc.).

_TABLE_DDL = [
    """
    CREATE TABLE IF NOT EXISTS events (
        ts REAL NOT NULL,
        service TEXT NOT NULL,
        method TEXT NOT NULL,
        route TEXT NOT NULL,
        path TEXT NOT NULL,
        status INTEGER NOT NULL,
        duration_ms REAL NOT NULL,
        error TEXT,
        request_id TEXT,
        correlation_id TEXT,
        parent_id TEXT,
        error_type TEXT,
        error_message TEXT,
        error_traceback TEXT,
        error_fingerprint TEXT,
        db_query_count INTEGER,
        db_total_ms REAL,
        db_slow TEXT,
        outgoing_count INTEGER,
        outgoing_total_ms REAL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS outgoing_calls (
        ts REAL NOT NULL,
        service TEXT NOT NULL,
        method TEXT NOT NULL,
        host TEXT NOT NULL,
        path TEXT NOT NULL,
        status INTEGER NOT NULL,
        duration_ms REAL NOT NULL,
        error TEXT,
        source_request_id TEXT,
        correlation_id TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS service_state (
        service TEXT NOT NULL,
        host TEXT NOT NULL,
        pid INTEGER NOT NULL,
        last_seen REAL NOT NULL,
        cpu_pct REAL,
        mem_mb REAL,
        in_flight INTEGER,
        PRIMARY KEY (service, host, pid)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS discovered_routes (
        service TEXT NOT NULL,
        framework TEXT NOT NULL,
        method TEXT NOT NULL,
        route TEXT NOT NULL,
        file TEXT NOT NULL,
        line INTEGER NOT NULL,
        function TEXT,
        scanned_at REAL NOT NULL,
        scan_root TEXT NOT NULL,
        PRIMARY KEY (service, framework, method, route, file)
    )
    """,
]

_INDEX_DDL = [
    "CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts)",
    "CREATE INDEX IF NOT EXISTS idx_events_service_ts ON events(service, ts)",
    "CREATE INDEX IF NOT EXISTS idx_events_route_ts ON events(service, route, ts)",
    "CREATE INDEX IF NOT EXISTS idx_events_corr ON events(correlation_id)",
    "CREATE INDEX IF NOT EXISTS idx_events_req ON events(request_id)",
    "CREATE INDEX IF NOT EXISTS idx_events_parent ON events(parent_id)",
    "CREATE INDEX IF NOT EXISTS idx_events_errfp ON events(service, error_fingerprint, ts)",
    "CREATE INDEX IF NOT EXISTS idx_out_ts ON outgoing_calls(ts)",
    "CREATE INDEX IF NOT EXISTS idx_out_service_ts ON outgoing_calls(service, ts)",
    "CREATE INDEX IF NOT EXISTS idx_out_source ON outgoing_calls(source_request_id)",
    "CREATE INDEX IF NOT EXISTS idx_out_corr ON outgoing_calls(correlation_id)",
    "CREATE INDEX IF NOT EXISTS idx_discovered_service ON discovered_routes(service)",
]


class Store:
    """Thread-safe SQLite wrapper. One process, many threads.

    SQLite handles concurrent readers fine; writers serialize via a single
    mutex held only for the duration of a write transaction.
    """

    def __init__(self, path: Path, retention_seconds: int = DEFAULT_RETENTION_SECONDS) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.retention_seconds = retention_seconds
        # SQLite's single Connection is NOT safe for concurrent use across
        # threads (sqlite3 module docs are explicit). FastAPI serves sync routes
        # from a worker pool, so /ingest writes and /api/* reads can race.
        #
        # Every public method that touches `self._conn` MUST acquire this lock
        # and hold it for the entire execute → fetchall window (cursors must be
        # materialized inside the lock). RLock so that nested `_query()` calls
        # from already-locked sites don't deadlock.
        self._db_lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        # Tables first (CREATE TABLE IF NOT EXISTS), then ALTER TABLE migrations
        # for older DBs, then indexes — order matters because some indexes
        # reference columns added by migration.
        for stmt in _TABLE_DDL:
            self._conn.execute(stmt)
        self._migrate()
        for stmt in _INDEX_DDL:
            self._conn.execute(stmt)
        self._last_gc = 0.0

    # ------------------------------------------------------------ db helpers

    def _query(self, sql: str, params: tuple | list = ()) -> list:
        """Run a SELECT under the lock and return fully-materialized rows.

        Holding the lock for the whole `execute → fetchall` ensures we never
        consume a cursor that a concurrent write transaction has invalidated.
        Use this for every read path. RLock makes nested calls safe.
        """
        with self._db_lock:
            cur = self._conn.execute(sql, tuple(params))
            return cur.fetchall()

    def _query_one(self, sql: str, params: tuple | list = ()) -> Any:
        with self._db_lock:
            cur = self._conn.execute(sql, tuple(params))
            return cur.fetchone()

    # -------------------------------------------------------------- internals

    def _migrate(self) -> None:
        """Add columns introduced after the initial schema. Idempotent."""
        with self._db_lock:
            cur = self._conn.execute("PRAGMA table_info(events)")
            existing = {row[1] for row in cur.fetchall()}
            for col, ddl in (
                ("request_id", "ALTER TABLE events ADD COLUMN request_id TEXT"),
                ("correlation_id", "ALTER TABLE events ADD COLUMN correlation_id TEXT"),
                ("parent_id", "ALTER TABLE events ADD COLUMN parent_id TEXT"),
                ("error_type", "ALTER TABLE events ADD COLUMN error_type TEXT"),
                ("error_message", "ALTER TABLE events ADD COLUMN error_message TEXT"),
                ("error_traceback", "ALTER TABLE events ADD COLUMN error_traceback TEXT"),
                ("error_fingerprint", "ALTER TABLE events ADD COLUMN error_fingerprint TEXT"),
                ("db_query_count", "ALTER TABLE events ADD COLUMN db_query_count INTEGER"),
                ("db_total_ms", "ALTER TABLE events ADD COLUMN db_total_ms REAL"),
                ("db_slow", "ALTER TABLE events ADD COLUMN db_slow TEXT"),
                ("outgoing_count", "ALTER TABLE events ADD COLUMN outgoing_count INTEGER"),
                ("outgoing_total_ms", "ALTER TABLE events ADD COLUMN outgoing_total_ms REAL"),
            ):
                if col not in existing:
                    self._conn.execute(ddl)

    def close(self) -> None:
        with self._db_lock:
            self._conn.close()

    # ------------------------------------------------------------------ writes

    def ingest(self, envelope: dict[str, Any]) -> int:
        """Insert events + outgoing + upsert service_state. Returns events written."""
        events: list[dict[str, Any]] = envelope.get("events") or []
        outgoing: list[dict[str, Any]] = envelope.get("outgoing_calls") or []
        service = envelope.get("service") or "unknown"
        host = envelope.get("host") or ""
        pid = int(envelope.get("pid") or 0)
        cpu_pct = envelope.get("cpu_pct")
        mem_mb = envelope.get("mem_mb")
        in_flight = int(envelope.get("in_flight") or 0)
        now = time.time()

        rows = [
            (
                float(e.get("ts") or now),
                service,
                str(e.get("method") or ""),
                str(e.get("route") or e.get("path") or ""),
                str(e.get("path") or ""),
                int(e.get("status") or 0),
                float(e.get("duration_ms") or 0.0),
                e.get("error"),
                e.get("request_id"),
                e.get("correlation_id"),
                e.get("parent_id"),
                e.get("error_type"),
                e.get("error_message"),
                e.get("error_traceback"),
                e.get("error_fingerprint"),
                e.get("db_query_count"),
                e.get("db_total_ms"),
                json.dumps(e.get("db_slow")) if e.get("db_slow") else None,
                e.get("outgoing_count"),
                e.get("outgoing_total_ms"),
            )
            for e in events
        ]
        out_rows = [
            (
                float(o.get("ts") or now),
                service,
                str(o.get("method") or ""),
                str(o.get("host") or ""),
                str(o.get("path") or ""),
                int(o.get("status") or 0),
                float(o.get("duration_ms") or 0.0),
                o.get("error"),
                o.get("source_request_id"),
                o.get("correlation_id"),
            )
            for o in outgoing
        ]

        with self._db_lock:
            if rows:
                self._conn.executemany(
                    "INSERT INTO events("
                    "ts, service, method, route, path, status, duration_ms, error, "
                    "request_id, correlation_id, parent_id, "
                    "error_type, error_message, error_traceback, error_fingerprint, "
                    "db_query_count, db_total_ms, db_slow, "
                    "outgoing_count, outgoing_total_ms"
                    ") VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    rows,
                )
            if out_rows:
                self._conn.executemany(
                    "INSERT INTO outgoing_calls("
                    "ts, service, method, host, path, status, duration_ms, error, "
                    "source_request_id, correlation_id"
                    ") VALUES (?,?,?,?,?,?,?,?,?,?)",
                    out_rows,
                )
            self._conn.execute(
                """
                INSERT INTO service_state(service, host, pid, last_seen, cpu_pct, mem_mb, in_flight)
                VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(service, host, pid) DO UPDATE SET
                    last_seen=excluded.last_seen,
                    cpu_pct=excluded.cpu_pct,
                    mem_mb=excluded.mem_mb,
                    in_flight=excluded.in_flight
                """,
                (service, host, pid, now, cpu_pct, mem_mb, in_flight),
            )

        # Opportunistic GC at most once per minute.
        if now - self._last_gc > 60:
            self._gc(now)
            self._last_gc = now
        return len(rows)

    def _gc(self, now: float) -> None:
        cutoff = now - self.retention_seconds
        with self._db_lock:
            self._conn.execute("DELETE FROM events WHERE ts < ?", (cutoff,))
            self._conn.execute("DELETE FROM outgoing_calls WHERE ts < ?", (cutoff,))

    # ------------------------------------------------------------------ reads

    def services(self) -> list[dict[str, Any]]:
        rows = self._query(
            """
            SELECT service,
                   MAX(last_seen) AS last_seen,
                   AVG(cpu_pct)   AS cpu_pct,
                   AVG(mem_mb)    AS mem_mb,
                   SUM(in_flight) AS in_flight
            FROM service_state
            GROUP BY service
            ORDER BY service
            """
        )
        return [
            {
                "service": r[0],
                "last_seen": r[1],
                "cpu_pct": r[2],
                "mem_mb": r[3],
                "in_flight": r[4] or 0,
            }
            for r in rows
        ]

    def overview(self, service: str | None, window_seconds: int = 300) -> dict[str, Any]:
        """Aggregate counts for a window. If service is None, all services combined."""
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [cutoff]
        where = "ts >= ?"
        if service:
            where += " AND service = ?"
            params.append(service)
        row = self._query_one(
            f"""
            SELECT COUNT(*),
                   SUM(CASE WHEN status >= 500 OR error IS NOT NULL THEN 1 ELSE 0 END),
                   AVG(duration_ms),
                   MAX(duration_ms)
            FROM events WHERE {where}
            """,
            params,
        )
        total, errors, avg_ms, max_ms = row
        total = total or 0
        errors = errors or 0
        return {
            "service": service,
            "window_seconds": window_seconds,
            "total_requests": total,
            "errors": errors,
            "error_rate": (errors / total) if total else 0.0,
            "rps": total / window_seconds if window_seconds else 0.0,
            "avg_duration_ms": avg_ms or 0.0,
            "max_duration_ms": max_ms or 0.0,
        }

    def rps_buckets(
        self, service: str | None, window_seconds: int = 300, bucket_seconds: int = 5
    ) -> list[dict[str, Any]]:
        """Time-series of RPS / error-rate bucketed at `bucket_seconds`."""
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [bucket_seconds, bucket_seconds, cutoff]
        where = "ts >= ?"
        if service:
            where += " AND service = ?"
            params.append(service)
        rows = self._query(
            f"""
            SELECT CAST(ts / ? AS INTEGER) * ? AS bucket,
                   COUNT(*) AS total,
                   SUM(CASE WHEN status >= 500 OR error IS NOT NULL THEN 1 ELSE 0 END) AS errors,
                   AVG(duration_ms) AS avg_ms
            FROM events WHERE {where}
            GROUP BY bucket
            ORDER BY bucket
            """,
            params,
        )
        out: list[dict[str, Any]] = []
        for bucket, total, errors, avg_ms in rows:
            out.append(
                {
                    "ts": float(bucket),
                    "rps": (total or 0) / bucket_seconds,
                    "error_rate": ((errors or 0) / total) if total else 0.0,
                    "avg_ms": avg_ms or 0.0,
                    "total": total or 0,
                }
            )
        return out

    def routes(self, service: str | None, window_seconds: int = 300) -> list[dict[str, Any]]:
        """Per-route summary: rps, error rate, avg/max latency, DB stats, outgoing stats."""
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [cutoff]
        where = "ts >= ?"
        if service:
            where += " AND service = ?"
            params.append(service)
        rows = self._query(
            f"""
            SELECT method, route,
                   COUNT(*) AS total,
                   SUM(CASE WHEN status >= 500 OR error IS NOT NULL THEN 1 ELSE 0 END) AS errors,
                   AVG(duration_ms) AS avg_ms,
                   MAX(duration_ms) AS max_ms,
                   AVG(db_query_count) AS avg_db_queries,
                   AVG(db_total_ms) AS avg_db_ms,
                   AVG(outgoing_count) AS avg_outgoing,
                   AVG(outgoing_total_ms) AS avg_outgoing_ms
            FROM events WHERE {where}
            GROUP BY method, route
            ORDER BY total DESC
            """,
            params,
        )
        out: list[dict[str, Any]] = []
        for row in rows:
            method, route, total, errors, avg_ms, max_ms, avg_q, avg_db_ms, avg_out, avg_out_ms = row
            out.append(
                {
                    "method": method,
                    "route": route,
                    "rps": (total or 0) / window_seconds if window_seconds else 0.0,
                    "total": total or 0,
                    "errors": errors or 0,
                    "error_rate": ((errors or 0) / total) if total else 0.0,
                    "avg_ms": avg_ms or 0.0,
                    "max_ms": max_ms or 0.0,
                    "avg_db_queries": avg_q,  # may be None when no requests carried DB data
                    "avg_db_ms": avg_db_ms,
                    "avg_outgoing": avg_out,
                    "avg_outgoing_ms": avg_out_ms,
                }
            )
        return out

    # ---------------------------------------------------- error grouping

    def error_groups(
        self, service: str | None, window_seconds: int = 600, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Aggregate by error_fingerprint so the dashboard can show grouped errors."""
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [cutoff]
        where = "ts >= ? AND error_fingerprint IS NOT NULL"
        if service:
            where += " AND service = ?"
            params.append(service)
        params.append(int(limit))
        rows = self._query(
            f"""
            SELECT error_fingerprint, error_type, error_message,
                   COUNT(*) AS count,
                   MIN(ts) AS first_seen,
                   MAX(ts) AS last_seen,
                   COUNT(DISTINCT route) AS routes_count,
                   MAX(error_traceback) AS sample_traceback
            FROM events
            WHERE {where}
            GROUP BY error_fingerprint
            ORDER BY last_seen DESC
            LIMIT ?
            """,
            params,
        )
        groups = [
            {
                "fingerprint": r[0],
                "error_type": r[1],
                "error_message": r[2],
                "count": r[3],
                "first_seen": r[4],
                "last_seen": r[5],
                "routes_count": r[6],
                "sample_traceback": r[7],
            }
            for r in rows
        ]
        # Attach the list of affected (method, route) for each group
        for g in groups:
            affected = self._query(
                """
                SELECT method, route, COUNT(*) AS n
                FROM events
                WHERE error_fingerprint = ? AND ts >= ?
                GROUP BY method, route
                ORDER BY n DESC LIMIT 10
                """,
                (g["fingerprint"], cutoff),
            )
            g["affected_routes"] = [
                {"method": r[0], "route": r[1], "count": r[2]} for r in affected
            ]
        return groups

    # --------------------------------------------------------- outgoing

    def outgoing_summary(
        self, service: str | None, window_seconds: int = 600, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Per-host outgoing call stats."""
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [cutoff]
        where = "ts >= ?"
        if service:
            where += " AND service = ?"
            params.append(service)
        params.append(int(limit))
        rows = self._query(
            f"""
            SELECT host,
                   COUNT(*) AS calls,
                   SUM(CASE WHEN status >= 400 OR error IS NOT NULL THEN 1 ELSE 0 END) AS errors,
                   AVG(duration_ms) AS avg_ms,
                   MAX(duration_ms) AS max_ms,
                   SUM(duration_ms) AS total_ms
            FROM outgoing_calls
            WHERE {where}
            GROUP BY host
            ORDER BY calls DESC
            LIMIT ?
            """,
            params,
        )
        return [
            {
                "host": r[0],
                "calls": r[1],
                "errors": r[2] or 0,
                "error_rate": ((r[2] or 0) / r[1]) if r[1] else 0.0,
                "avg_ms": r[3] or 0.0,
                "max_ms": r[4] or 0.0,
                "total_ms": r[5] or 0.0,
            }
            for r in rows
        ]

    def route_host_calls(
        self, service: str | None, window_seconds: int = 300, limit: int = 500
    ) -> list[dict[str, Any]]:
        """Bipartite edge data: (origin_route) → (host) call counts + error/latency.

        Powers the deps graph: for every (method, route, host) triple, returns
        how often that route called that host in the window, plus error / latency.
        Only edges where the originating request_id was captured by our middleware
        are included (we need the JOIN against `events`).
        """
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [cutoff]
        where = "o.ts >= ? AND o.source_request_id IS NOT NULL AND o.source_request_id != ''"
        if service:
            where += " AND o.service = ? AND e.service = ?"
            params.extend([service, service])
        params.append(int(limit))
        rows = self._query(
            f"""
            SELECT e.method, e.route, o.host,
                   COUNT(*) AS calls,
                   SUM(CASE WHEN o.status >= 400 OR (o.error IS NOT NULL AND o.error != '') THEN 1 ELSE 0 END) AS errors,
                   AVG(o.duration_ms) AS avg_ms,
                   MAX(o.duration_ms) AS max_ms,
                   SUM(o.duration_ms) AS total_ms
            FROM outgoing_calls o
            JOIN events e
              ON o.source_request_id = e.request_id
             AND o.service = e.service
            WHERE {where}
            GROUP BY e.method, e.route, o.host
            ORDER BY calls DESC
            LIMIT ?
            """,
            params,
        )
        return [
            {
                "method": r[0],
                "route": r[1],
                "host": r[2],
                "calls": r[3] or 0,
                "errors": r[4] or 0,
                "error_rate": ((r[4] or 0) / r[3]) if r[3] else 0.0,
                "avg_ms": r[5] or 0.0,
                "max_ms": r[6] or 0.0,
                "total_ms": r[7] or 0.0,
            }
            for r in rows
        ]

    def outgoing_for_route(
        self, service: str, method: str, route: str, window_seconds: int = 600, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Outgoing calls made by requests that matched a given (method, route)."""
        now = time.time()
        cutoff = now - window_seconds
        rows = self._query(
            """
            SELECT o.host,
                   COUNT(*) AS calls,
                   AVG(o.duration_ms) AS avg_ms,
                   MAX(o.duration_ms) AS max_ms,
                   SUM(CASE WHEN o.status >= 400 OR o.error IS NOT NULL THEN 1 ELSE 0 END) AS errors
            FROM outgoing_calls o
            JOIN events e ON o.source_request_id = e.request_id
            WHERE e.service = ? AND e.method = ? AND e.route = ?
              AND o.ts >= ?
            GROUP BY o.host
            ORDER BY calls DESC LIMIT ?
            """,
            (service, method, route, cutoff, int(limit)),
        )
        return [
            {
                "host": r[0],
                "calls": r[1],
                "avg_ms": r[2] or 0.0,
                "max_ms": r[3] or 0.0,
                "errors": r[4] or 0,
            }
            for r in rows
        ]

    def route_chains(
        self, service: str | None, window_seconds: int = 300, limit: int = 500
    ) -> list[dict[str, Any]]:
        """Aggregated parent→child route pairs derived from correlation IDs.

        A pair `(A, B)` with count N means: across the window, route A was the
        parent hop in N requests whose next hop landed on route B (both in the
        same correlation chain). Edges are intra-service (we only join when the
        same service ingested both hops).
        """
        now = time.time()
        cutoff = now - window_seconds
        params: list[Any] = [cutoff, cutoff]
        where_service = ""
        if service:
            where_service = " AND parent.service = ? AND child.service = ?"
            params.extend([service, service])
        params.append(int(limit))
        rows = self._query(
            f"""
            SELECT parent.method AS p_method,
                   parent.route  AS p_route,
                   child.method  AS c_method,
                   child.route   AS c_route,
                   COUNT(*)      AS n,
                   AVG(child.duration_ms) AS child_avg_ms,
                   SUM(CASE WHEN child.status >= 500 OR child.error IS NOT NULL THEN 1 ELSE 0 END) AS child_errors
            FROM events child
            JOIN events parent
              ON parent.request_id = child.parent_id
             AND parent.correlation_id = child.correlation_id
             AND parent.request_id IS NOT NULL
            WHERE child.ts >= ?
              AND parent.ts >= ?
              AND child.parent_id IS NOT NULL
              {where_service}
            GROUP BY parent.method, parent.route, child.method, child.route
            ORDER BY n DESC
            LIMIT ?
            """,
            params,
        )
        return [
            {
                "parent_method": r[0],
                "parent_route": r[1],
                "child_method": r[2],
                "child_route": r[3],
                "count": r[4],
                "child_avg_ms": r[5] or 0.0,
                "child_errors": r[6] or 0,
            }
            for r in rows
        ]

    def folder_snapshot(
        self,
        service: str,
        folder: str,
        window_seconds: int = 600,
    ) -> dict[str, Any]:
        """Aggregate stats for runtime routes whose handler is in a given folder.

        Folder resolution uses the discovered_routes table: pick every (method,
        route) discovered under the folder, then aggregate matching events.
        """
        now = time.time()
        cutoff = now - window_seconds
        folder_norm = (folder or "").strip().strip("/")
        like_prefix = (folder_norm + "/") if folder_norm else ""

        # Discovered routes that live inside the folder
        if folder_norm:
            disc_rows = self._query(
                """
                SELECT method, route, file, line, function FROM discovered_routes
                WHERE service = ? AND (file = ? OR file LIKE ?)
                ORDER BY file, line
                """,
                (service, folder_norm, like_prefix + "%"),
            )
        else:
            disc_rows = self._query(
                "SELECT method, route, file, line, function FROM discovered_routes "
                "WHERE service = ? ORDER BY file, line",
                (service,),
            )
        discovered = [
            {"method": r[0], "route": r[1], "file": r[2], "line": r[3], "function": r[4]}
            for r in disc_rows
        ]
        # Match-set (route -> set of methods) so wildcard "*" matches anything.
        route_methods: dict[str, set[str]] = {}
        for d in discovered:
            route_methods.setdefault(d["route"], set()).add(d["method"])

        # Pull runtime events that match any discovered (method, route) in this folder
        per_route: list[dict[str, Any]] = []
        total = 0
        errors = 0
        total_ms = 0.0
        for route, methods in route_methods.items():
            wildcard = "*" in methods
            placeholders = ",".join("?" * len(methods)) if methods and not wildcard else ""
            if wildcard:
                stat_rows = self._query(
                    """
                    SELECT method, COUNT(*),
                           SUM(CASE WHEN status >= 500 OR error IS NOT NULL THEN 1 ELSE 0 END),
                           AVG(duration_ms), MAX(duration_ms)
                    FROM events
                    WHERE service = ? AND route = ? AND ts >= ?
                    GROUP BY method
                    """,
                    (service, route, cutoff),
                )
            else:
                stat_rows = self._query(
                    f"""
                    SELECT method, COUNT(*),
                           SUM(CASE WHEN status >= 500 OR error IS NOT NULL THEN 1 ELSE 0 END),
                           AVG(duration_ms), MAX(duration_ms)
                    FROM events
                    WHERE service = ? AND route = ? AND ts >= ?
                      AND method IN ({placeholders})
                    GROUP BY method
                    """,
                    (service, route, cutoff, *methods),
                )
            for m, n, errs, avg_ms, max_ms in stat_rows:
                n = n or 0
                errs = errs or 0
                total += n
                errors += errs
                total_ms += (avg_ms or 0.0) * n
                per_route.append(
                    {
                        "method": m,
                        "route": route,
                        "total": n,
                        "errors": errs,
                        "error_rate": (errs / n) if n else 0.0,
                        "avg_ms": avg_ms or 0.0,
                        "max_ms": max_ms or 0.0,
                        "rps": n / window_seconds if window_seconds else 0.0,
                    }
                )

        per_route.sort(key=lambda r: r["total"], reverse=True)
        return {
            "service": service,
            "folder": folder_norm,
            "window_seconds": window_seconds,
            "discovered_routes": len(discovered),
            "total_requests": total,
            "errors": errors,
            "error_rate": (errors / total) if total else 0.0,
            "avg_duration_ms": (total_ms / total) if total else 0.0,
            "rps": total / window_seconds if window_seconds else 0.0,
            "routes": per_route,
            "files": sorted({d["file"] for d in discovered}),
        }

    def recent_errors(
        self, service: str | None, route: str | None, limit: int = 20
    ) -> list[dict[str, Any]]:
        params: list[Any] = []
        clauses = ["(status >= 500 OR error IS NOT NULL)"]
        if service:
            clauses.append("service = ?")
            params.append(service)
        if route:
            clauses.append("route = ?")
            params.append(route)
        where = " AND ".join(clauses)
        params.append(int(limit))
        rows = self._query(
            f"""
            SELECT ts, service, method, route, status, duration_ms, error
            FROM events WHERE {where}
            ORDER BY ts DESC LIMIT ?
            """,
            params,
        )
        return [
            {
                "ts": r[0],
                "service": r[1],
                "method": r[2],
                "route": r[3],
                "status": r[4],
                "duration_ms": r[5],
                "error": r[6],
            }
            for r in rows
        ]

    # -------------------------------------------------- discovery (static scan)

    def replace_discovered(
        self, service: str, scan_root: str, routes: list[dict[str, Any]]
    ) -> int:
        """Replace the discovered-route set for `service` atomically.

        Re-scanning the same project drops endpoints that disappeared from the
        source instead of leaving stale rows around.
        """
        now = time.time()
        rows = [
            (
                service,
                str(r.get("framework") or ""),
                str(r.get("method") or "*"),
                str(r.get("route") or ""),
                str(r.get("file") or ""),
                int(r.get("line") or 0),
                r.get("function"),
                now,
                scan_root,
            )
            for r in routes
        ]
        with self._db_lock:
            self._conn.execute("BEGIN")
            try:
                self._conn.execute(
                    "DELETE FROM discovered_routes WHERE service = ?", (service,)
                )
                if rows:
                    self._conn.executemany(
                        "INSERT INTO discovered_routes("
                        "service, framework, method, route, file, line, function, scanned_at, scan_root"
                        ") VALUES (?,?,?,?,?,?,?,?,?)",
                        rows,
                    )
                self._conn.execute("COMMIT")
            except Exception:
                self._conn.execute("ROLLBACK")
                raise
        return len(rows)

    def list_discovered(self, service: str | None) -> list[dict[str, Any]]:
        params: list[Any] = []
        where = ""
        if service:
            where = "WHERE service = ?"
            params.append(service)
        rows = self._query(
            f"""
            SELECT service, framework, method, route, file, line, function, scanned_at, scan_root
            FROM discovered_routes {where}
            ORDER BY service, file, line
            """,
            params,
        )
        return [
            {
                "service": r[0],
                "framework": r[1],
                "method": r[2],
                "route": r[3],
                "file": r[4],
                "line": r[5],
                "function": r[6],
                "scanned_at": r[7],
                "scan_root": r[8],
            }
            for r in rows
        ]

    def discovered_scan_roots(self) -> list[dict[str, Any]]:
        """For each service, return the most-recent scan_root + scanned_at."""
        rows = self._query(
            """
            SELECT service, MAX(scanned_at) AS scanned_at, scan_root, COUNT(*) AS routes
            FROM discovered_routes
            GROUP BY service
            ORDER BY service
            """
        )
        return [
            {"service": r[0], "scanned_at": r[1], "scan_root": r[2], "routes": r[3]}
            for r in rows
        ]

    def route_snapshot(
        self, service: str, method: str, route: str, window_seconds: int = 600
    ) -> dict[str, Any]:
        """Self-contained snapshot for AI assist: stats + errors + DB + outgoing."""
        now = time.time()
        cutoff = now - window_seconds
        row = self._query_one(
            """
            SELECT COUNT(*),
                   SUM(CASE WHEN status >= 500 OR error IS NOT NULL THEN 1 ELSE 0 END),
                   AVG(duration_ms),
                   MAX(duration_ms),
                   MIN(duration_ms),
                   AVG(db_query_count),
                   MAX(db_query_count),
                   AVG(db_total_ms),
                   MAX(db_total_ms),
                   AVG(outgoing_count),
                   AVG(outgoing_total_ms)
            FROM events
            WHERE service = ? AND method = ? AND route = ? AND ts >= ?
            """,
            (service, method, route, cutoff),
        )
        (
            total, errors, avg_ms, max_ms, min_ms,
            avg_q, max_q, avg_db_ms, max_db_ms,
            avg_out, avg_out_ms,
        ) = row
        total = total or 0
        errors = errors or 0

        # Pull a few sample errors with status codes.
        err_rows = self._query(
            """
            SELECT status, error, COUNT(*)
            FROM events
            WHERE service = ? AND method = ? AND route = ? AND ts >= ?
              AND (status >= 500 OR error IS NOT NULL)
            GROUP BY status, error
            ORDER BY COUNT(*) DESC LIMIT 10
            """,
            (service, method, route, cutoff),
        )
        error_breakdown = [
            {"status": r[0], "error": r[1], "count": r[2]} for r in err_rows
        ]

        # Pick the slowest-DB request as a sample for the AI to see actual SQL.
        slow_row = self._query_one(
            """
            SELECT db_slow, db_query_count, db_total_ms, duration_ms
            FROM events
            WHERE service = ? AND method = ? AND route = ? AND ts >= ?
              AND db_slow IS NOT NULL AND db_total_ms IS NOT NULL
            ORDER BY db_total_ms DESC LIMIT 1
            """,
            (service, method, route, cutoff),
        )
        worst_db = None
        if slow_row:
            try:
                worst_db = {
                    "queries": slow_row[1],
                    "db_total_ms": slow_row[2],
                    "request_total_ms": slow_row[3],
                    "slowest": json.loads(slow_row[0]) if slow_row[0] else [],
                }
            except json.JSONDecodeError:
                pass

        outgoing = self.outgoing_for_route(service, method, route, window_seconds)

        return {
            "service": service,
            "method": method,
            "route": route,
            "window_seconds": window_seconds,
            "total_requests": total,
            "errors": errors,
            "error_rate": (errors / total) if total else 0.0,
            "rps": total / window_seconds if window_seconds else 0.0,
            "avg_duration_ms": avg_ms or 0.0,
            "max_duration_ms": max_ms or 0.0,
            "min_duration_ms": min_ms or 0.0,
            "error_breakdown": error_breakdown,
            "db": {
                "avg_queries_per_request": avg_q,
                "max_queries_per_request": max_q,
                "avg_db_ms": avg_db_ms,
                "max_db_ms": max_db_ms,
                "worst_request": worst_db,
            },
            "outgoing": outgoing,
        }
