"""FastAPI app: ingest endpoint, query endpoints, dashboard static files.

Endpoints:
  POST /ingest                       — SDKs push envelopes here
  GET  /api/services                 — services seen recently
  GET  /api/overview?service=&w=300  — aggregate counts for a window
  GET  /api/timeseries?service=&w=300&bucket=5
  GET  /api/routes?service=&w=300
  GET  /api/route/snapshot?service=&method=&route=&w=600
       (snapshot intended for the browser to feed into the user's LLM key)
  GET  /                             — dashboard HTML
  GET  /static/*                     — dashboard assets
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from ..discovery import scan_project
from .store import Store


class ScanRequest(BaseModel):
    service: str
    path: str  # absolute or relative to the collector's CWD

DASHBOARD_DIR = Path(__file__).resolve().parent.parent / "dashboard"


def build_app(store: Store) -> FastAPI:
    app = FastAPI(title="backtrack collector", version="0.1.0")

    @app.post("/ingest")
    async def ingest(request: Request) -> dict[str, Any]:
        try:
            payload = await request.json()
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=f"invalid json: {exc}") from exc
        if not isinstance(payload, dict):
            raise HTTPException(status_code=400, detail="payload must be an object")
        written = store.ingest(payload)
        return {"ok": True, "events": written}

    @app.get("/api/services")
    def services() -> dict[str, Any]:
        return {"services": store.services()}

    @app.get("/api/overview")
    def overview(service: str | None = None, w: int = 300) -> dict[str, Any]:
        return store.overview(service=service, window_seconds=w)

    @app.get("/api/timeseries")
    def timeseries(service: str | None = None, w: int = 300, bucket: int = 5) -> dict[str, Any]:
        return {
            "service": service,
            "window_seconds": w,
            "bucket_seconds": bucket,
            "points": store.rps_buckets(service=service, window_seconds=w, bucket_seconds=bucket),
        }

    @app.get("/api/routes")
    def routes(service: str | None = None, w: int = 300) -> dict[str, Any]:
        return {"routes": store.routes(service=service, window_seconds=w)}

    @app.get("/api/recent_errors")
    def recent_errors(
        service: str | None = None, route: str | None = None, limit: int = 20
    ) -> dict[str, Any]:
        return {"errors": store.recent_errors(service=service, route=route, limit=limit)}

    @app.get("/api/route/snapshot")
    def route_snapshot(service: str, method: str, route: str, w: int = 600) -> dict[str, Any]:
        return store.route_snapshot(service=service, method=method, route=route, window_seconds=w)

    @app.get("/api/route_chains")
    def route_chains(service: str | None = None, w: int = 300, limit: int = 500) -> dict[str, Any]:
        return {
            "service": service,
            "window_seconds": w,
            "chains": store.route_chains(service=service, window_seconds=w, limit=limit),
        }

    @app.get("/api/folder/snapshot")
    def folder_snapshot(service: str, folder: str = "", w: int = 600) -> dict[str, Any]:
        return store.folder_snapshot(service=service, folder=folder, window_seconds=w)

    @app.get("/api/error_groups")
    def error_groups(service: str | None = None, w: int = 600, limit: int = 50) -> dict[str, Any]:
        return {
            "service": service,
            "window_seconds": w,
            "groups": store.error_groups(service=service, window_seconds=w, limit=limit),
        }

    @app.get("/api/outgoing")
    def outgoing(service: str | None = None, w: int = 600, limit: int = 50) -> dict[str, Any]:
        return {
            "service": service,
            "window_seconds": w,
            "hosts": store.outgoing_summary(service=service, window_seconds=w, limit=limit),
        }

    @app.get("/api/route_host_calls")
    def route_host_calls(
        service: str | None = None, w: int = 300, limit: int = 500
    ) -> dict[str, Any]:
        """Per (route, host) call counts for the bipartite dependency view."""
        return {
            "service": service,
            "window_seconds": w,
            "edges": store.route_host_calls(service=service, window_seconds=w, limit=limit),
        }

    # ---------------------------------------------------------- discovery

    @app.get("/api/discovered")
    def discovered(service: str | None = None) -> dict[str, Any]:
        return {
            "routes": store.list_discovered(service=service),
            "scan_roots": store.discovered_scan_roots(),
        }

    @app.post("/api/scan")
    def scan(req: ScanRequest) -> dict[str, Any]:
        root = Path(req.path).expanduser().resolve()
        if not root.exists():
            raise HTTPException(status_code=400, detail=f"path does not exist: {root}")
        if not root.is_dir():
            raise HTTPException(status_code=400, detail=f"not a directory: {root}")
        try:
            routes = scan_project(root)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=500, detail=f"scan failed: {exc}") from exc
        written = store.replace_discovered(
            service=req.service,
            scan_root=str(root),
            routes=[r.as_dict() for r in routes],
        )
        by_fw: dict[str, int] = {}
        for r in routes:
            by_fw[r.framework] = by_fw.get(r.framework, 0) + 1
        return {
            "service": req.service,
            "scan_root": str(root),
            "routes": written,
            "by_framework": by_fw,
        }

    # ------------------------------------------------------------- static UI

    if DASHBOARD_DIR.is_dir():
        app.mount(
            "/static",
            StaticFiles(directory=str(DASHBOARD_DIR), html=False),
            name="static",
        )

        @app.get("/")
        def index() -> FileResponse:
            return FileResponse(DASHBOARD_DIR / "index.html")
    else:

        @app.get("/")
        def index_missing() -> JSONResponse:
            return JSONResponse(
                {"error": "dashboard assets not found", "path": str(DASHBOARD_DIR)},
                status_code=500,
            )

    return app
