"""Local collector: SQLite store + FastAPI server + dashboard."""

from .server import build_app

__all__ = ["build_app"]
