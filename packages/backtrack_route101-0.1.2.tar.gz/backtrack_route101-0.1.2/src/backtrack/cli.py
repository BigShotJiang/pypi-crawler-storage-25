"""CLI: `backtrack start` boots the local collector + dashboard."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import click
import uvicorn

from .collector.server import build_app
from .collector.store import Store
from .discovery import scan_project


class _SuppressWinConnReset(logging.Filter):
    """Drop the benign 'forcibly closed by the remote host' tracebacks asyncio
    emits on Windows when a browser/client abruptly closes a kept-alive socket.

    The collector is fine — only the log spam goes away.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        if record.exc_info:
            exc = record.exc_info[1]
            if isinstance(exc, ConnectionResetError) and getattr(exc, "winerror", 0) == 10054:
                return False
        msg = record.getMessage()
        if "WinError 10054" in msg or "_ProactorBasePipeTransport._call_connection_lost" in msg:
            return False
        return True


def _quiet_windows_asyncio_noise() -> None:
    if sys.platform != "win32":
        return
    flt = _SuppressWinConnReset()
    for name in ("asyncio", "uvicorn.error"):
        logging.getLogger(name).addFilter(flt)


@click.group()
@click.version_option(package_name="backtrack")
def main() -> None:
    """backtrack — local API observability."""


@main.command()
@click.option("--host", default="127.0.0.1", show_default=True, help="Bind host. Stay on 127.0.0.1 unless you know what you're doing.")
@click.option("--port", default=9876, show_default=True, type=int)
@click.option(
    "--db",
    type=click.Path(path_type=Path),
    default=Path.home() / ".backtrack" / "backtrack.db",
    show_default=True,
    help="SQLite database path.",
)
@click.option("--retention", default=3600, type=int, show_default=True, help="Seconds of raw events to retain.")
@click.option(
    "--scan",
    "scans",
    multiple=True,
    type=click.Path(path_type=Path),
    help="Project root to scan at startup. Repeat for multi-project setups. "
    "Pair with --scan-service to label which service the scan belongs to.",
)
@click.option(
    "--scan-service",
    "scan_services",
    multiple=True,
    help="Service name for the corresponding --scan path (positional match).",
)
def start(
    host: str,
    port: int,
    db: Path,
    retention: int,
    scans: tuple[Path, ...],
    scan_services: tuple[str, ...],
) -> None:
    """Run the collector + dashboard."""
    store = Store(path=db, retention_seconds=retention)

    # Pair --scan paths with --scan-service names by index. Trailing scans
    # without an explicit service name fall back to the directory name.
    for i, scan_path in enumerate(scans):
        scan_path = scan_path.expanduser().resolve()
        if not scan_path.is_dir():
            click.echo(f"  skip scan: {scan_path} (not a directory)", err=True)
            continue
        service = scan_services[i] if i < len(scan_services) else scan_path.name
        routes = scan_project(scan_path)
        store.replace_discovered(
            service=service,
            scan_root=str(scan_path),
            routes=[r.as_dict() for r in routes],
        )
        click.echo(f"  scanned {scan_path} -> service={service}: {len(routes)} routes")

    app = build_app(store)

    click.echo(f"backtrack collector -> http://{host}:{port}")
    click.echo(f"           database -> {db}")
    click.echo(f"   point your SDKs -> http://{host}:{port}/ingest")

    _quiet_windows_asyncio_noise()
    config = uvicorn.Config(app, host=host, port=port, log_level="warning", access_log=False)
    server = uvicorn.Server(config)
    try:
        server.run()
    finally:
        store.close()


if __name__ == "__main__":
    main()
