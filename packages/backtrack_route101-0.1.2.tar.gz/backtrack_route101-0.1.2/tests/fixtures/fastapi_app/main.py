from fastapi import FastAPI
from pydantic import BaseModel

from .services import compute_total

app = FastAPI()


class Item(BaseModel):
    name: str
    price: float


@app.get("/items/{item_id}")
def get_item(item_id: int) -> Item:
    return Item(name="example", price=compute_total(item_id))


@app.post("/items")
def create_item(item: Item) -> dict:
    save_item(item)
    return {"ok": True}


def save_item(item: Item) -> None:
    pass
