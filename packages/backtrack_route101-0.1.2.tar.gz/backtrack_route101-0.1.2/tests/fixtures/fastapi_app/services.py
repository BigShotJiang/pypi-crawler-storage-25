def compute_total(n: int) -> float:
    base = _tax(n)
    return float(n) * base


def _tax(n: int) -> float:
    return 1.18 if n > 0 else 1.0
