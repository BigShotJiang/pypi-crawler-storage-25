from django.http import JsonResponse


def index(request):
    return JsonResponse({"hello": "world"})


class ItemView:
    def get(self, request, pk):
        return JsonResponse({"id": pk})


def health_check(request):
    return JsonResponse({"status": "ok"})
