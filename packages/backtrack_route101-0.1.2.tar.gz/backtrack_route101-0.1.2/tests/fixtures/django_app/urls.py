from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("items/<int:pk>/", views.ItemView.as_view(), name="item-detail"),
    path("health/", views.health_check, name="health"),
]
