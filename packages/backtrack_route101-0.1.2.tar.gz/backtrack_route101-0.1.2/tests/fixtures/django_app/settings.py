SECRET_KEY = "fixture"
DEBUG = True
INSTALLED_APPS = ["django.contrib.contenttypes", "django.contrib.auth"]
ROOT_URLCONF = "urls"
