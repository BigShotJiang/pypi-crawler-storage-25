"""Smoke test for ORM tracking, error grouping, and outgoing HTTP capture.

Boots the collector + a FastAPI app instrumented with the SDK and SQLAlchemy.
The app has four routes:
  GET /healthy       — fast, no DB, no calls (baseline)
  GET /db            — runs N+1-style SQL via SQLAlchemy
  GET /boom          — raises a ValueError (so we get a fingerprinted group)
  GET /external/{i}  — makes an outgoing httpx call to /healthy

After firing traffic we assert:
  - /api/routes shows non-null avg_db_queries on /db, avg_outgoing on /external
  - /api/error_groups returns at least one group for the ValueError, count >= 3,
    sample traceback non-empty
  - /api/outgoing lists the 127.0.0.1 host with the expected call count
"""

from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import httpx  # noqa: E402
import uvicorn  # noqa: E402
from fastapi import FastAPI  # noqa: E402
from sqlalchemy import Column, Integer, String, create_engine, select  # noqa: E402
from sqlalchemy.orm import Session, declarative_base  # noqa: E402

from backtrack.collector.server import build_app  # noqa: E402
from backtrack.collector.store import Store  # noqa: E402
from backtrack.sdk import instrument_sqlalchemy  # noqa: E402
from backtrack.sdk._wire import DEFAULT_FLUSH_INTERVAL, Reporter  # noqa: E402
from backtrack.sdk.fastapi import BacktrackMiddleware  # noqa: E402

COLLECTOR_PORT = 9884
APP_PORT = 9885
ENDPOINT = f"http://127.0.0.1:{COLLECTOR_PORT}/ingest"
Base = declarative_base()


class Widget(Base):
    __tablename__ = "widgets"
    id = Column(Integer, primary_key=True)
    name = Column(String)


def run_collector(stop: threading.Event, db: Path) -> None:
    store = Store(path=db, retention_seconds=600)
    app = build_app(store)
    config = uvicorn.Config(app, host="127.0.0.1", port=COLLECTOR_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    try:
        server.run()
    finally:
        store.close()


def make_app(engine) -> FastAPI:
    app = FastAPI()
    app.add_middleware(BacktrackMiddleware, service="features", endpoint=ENDPOINT)

    @app.get("/healthy")
    def healthy() -> dict:
        return {"ok": True}

    @app.get("/db")
    def db_view() -> dict:
        # Issue several queries — what an N+1 looks like in production.
        with Session(engine) as session:
            ids = [w.id for w in session.execute(select(Widget)).scalars().all()]
            names = []
            for wid in ids:
                w = session.get(Widget, wid)
                names.append(w.name)
        return {"count": len(names)}

    @app.get("/boom")
    def boom() -> dict:
        raise ValueError("kaboom from /boom")

    @app.get("/external/{i}")
    async def external(i: int) -> dict:
        async with httpx.AsyncClient() as c:
            r = await c.get(f"http://127.0.0.1:{APP_PORT}/healthy", timeout=2)
        return {"i": i, "inner": r.json()}

    return app


def run_app(stop: threading.Event, engine) -> None:
    app = make_app(engine)
    config = uvicorn.Config(app, host="127.0.0.1", port=APP_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    server.run()


def wait_for(url: str, attempts: int = 80) -> None:
    for _ in range(attempts):
        try:
            urllib.request.urlopen(url, timeout=0.5).read()
            return
        except Exception:
            time.sleep(0.1)
    raise RuntimeError(f"timed out waiting for {url}")


def get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=5) as r:
        return json.loads(r.read())


def hit(path: str) -> int:
    req = urllib.request.Request(f"http://127.0.0.1:{APP_PORT}{path}")
    try:
        with urllib.request.urlopen(req, timeout=4) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code


def main() -> int:
    stop = threading.Event()
    # ignore_cleanup_errors handles Windows file-lock during SQLAlchemy engine disposal.
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        db_path = Path(tmp) / "feat.db"
        engine = create_engine(f"sqlite:///{tmp}/widgets.db")
        Base.metadata.create_all(engine)
        with Session(engine) as session:
            session.add_all([Widget(id=i, name=f"w{i}") for i in range(1, 6)])
            session.commit()
        # Instrument BEFORE the app starts so the listener catches all queries.
        assert instrument_sqlalchemy(engine), "sqlalchemy not installed?"

        threads = [
            threading.Thread(target=run_collector, args=(stop, db_path), daemon=True),
            threading.Thread(target=run_app, args=(stop, engine), daemon=True),
        ]
        for t in threads:
            t.start()
        try:
            wait_for(f"http://127.0.0.1:{COLLECTOR_PORT}/api/services")
            wait_for(f"http://127.0.0.1:{APP_PORT}/healthy")

            # Generate traffic
            for _ in range(5):
                hit("/db")  # triggers ORM hooks
            for _ in range(4):
                hit("/boom")  # error grouping
            for i in range(6):
                hit(f"/external/{i}")  # outgoing httpx

            time.sleep(DEFAULT_FLUSH_INTERVAL + 2.0)

            routes = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/routes?service=features&w=600"
            )["routes"]
            err = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/error_groups?service=features&w=600"
            )["groups"]
            out = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/outgoing?service=features&w=600"
            )["hosts"]

            print("=== routes ===")
            for r in routes:
                print(
                    f"  {r['method']:5} {r['route']:30} "
                    f"db_q={r.get('avg_db_queries')!s:6} db_ms={r.get('avg_db_ms')!s:8} "
                    f"out={r.get('avg_outgoing')}"
                )
            print("\n=== error groups ===")
            print(json.dumps(err, indent=2))
            print("\n=== outgoing hosts ===")
            print(json.dumps(out, indent=2))

            # --- ORM assertions ---
            db_route = next((r for r in routes if r["route"] == "/db"), None)
            assert db_route, "expected /db in routes"
            assert (db_route["avg_db_queries"] or 0) >= 5, db_route
            assert (db_route["avg_db_ms"] or 0) > 0, db_route

            # --- Outgoing aggregate on the route + global outgoing list ---
            ext_route = next((r for r in routes if r["route"] == "/external/{i}"), None)
            assert ext_route, f"expected /external/{{i}} in routes: {[r['route'] for r in routes]}"
            assert (ext_route["avg_outgoing"] or 0) >= 1, ext_route
            assert any("127.0.0.1" in h["host"] for h in out), out
            host = next(h for h in out if "127.0.0.1" in h["host"])
            assert host["calls"] >= 6, host

            # --- Error grouping ---
            assert err, "expected at least one error group"
            grp = next((g for g in err if g["error_type"] == "ValueError"), None)
            assert grp, [g["error_type"] for g in err]
            assert grp["count"] >= 4, grp
            assert grp["fingerprint"], "expected non-empty fingerprint"
            assert "ValueError" in (grp["sample_traceback"] or ""), grp["sample_traceback"]
            routes_in_group = [r["route"] for r in grp.get("affected_routes", [])]
            assert "/boom" in routes_in_group, routes_in_group

            print("\nFEATURES SMOKE OK")
            return 0
        finally:
            stop.set()
            try:
                if Reporter._singleton is not None:
                    Reporter._singleton.shutdown()
            except Exception:
                pass
            for t in threads:
                t.join(timeout=3)
            try:
                engine.dispose()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
