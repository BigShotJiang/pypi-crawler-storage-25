"""End-to-end smoke test.

Boots the collector in a thread, runs a tiny FastAPI app instrumented with
BacktrackMiddleware in another thread, hits a few endpoints, and verifies the
collector's API reflects the traffic.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

# Make the project src/ importable when running outside an installed package.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import uvicorn  # noqa: E402
from fastapi import FastAPI, HTTPException  # noqa: E402

from backtrack.collector.server import build_app  # noqa: E402
from backtrack.collector.store import Store  # noqa: E402
from backtrack.sdk._wire import DEFAULT_FLUSH_INTERVAL, Reporter  # noqa: E402
from backtrack.sdk.fastapi import BacktrackMiddleware  # noqa: E402

COLLECTOR_PORT = 9876
APP_PORT = 9810
ENDPOINT = f"http://127.0.0.1:{COLLECTOR_PORT}/ingest"


def run_collector(stop: threading.Event, db_path: Path) -> None:
    store = Store(path=db_path, retention_seconds=600)
    app = build_app(store)
    config = uvicorn.Config(app, host="127.0.0.1", port=COLLECTOR_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    try:
        server.run()
    finally:
        store.close()


def make_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(BacktrackMiddleware, service="smoke-app", endpoint=ENDPOINT)

    @app.get("/users/{user_id}")
    def get_user(user_id: int) -> dict:
        return {"user_id": user_id, "name": f"user-{user_id}"}

    @app.get("/slow")
    def slow() -> dict:
        time.sleep(0.05)
        return {"ok": True}

    @app.get("/boom")
    def boom() -> dict:
        raise HTTPException(status_code=500, detail="kaboom")

    return app


def run_app(stop: threading.Event) -> None:
    config = uvicorn.Config(make_app(), host="127.0.0.1", port=APP_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    server.run()


def wait_for(url: str, attempts: int = 50) -> None:
    for _ in range(attempts):
        try:
            urllib.request.urlopen(url, timeout=0.5).read()
            return
        except Exception:
            time.sleep(0.1)
    raise RuntimeError(f"timed out waiting for {url}")


def get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=2) as r:
        return json.loads(r.read())


def hit(path: str) -> int:
    req = urllib.request.Request(f"http://127.0.0.1:{APP_PORT}{path}")
    try:
        with urllib.request.urlopen(req, timeout=2) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code


def main() -> int:
    stop = threading.Event()
    with tempfile.TemporaryDirectory() as tmp:
        db_path = Path(tmp) / "smoke.db"

        threads = [
            threading.Thread(target=run_collector, args=(stop, db_path), daemon=True),
            threading.Thread(target=run_app, args=(stop,), daemon=True),
        ]
        for t in threads:
            t.start()

        try:
            wait_for(f"http://127.0.0.1:{COLLECTOR_PORT}/api/services")
            wait_for(f"http://127.0.0.1:{APP_PORT}/users/1")

            # Generate traffic
            for i in range(20):
                hit(f"/users/{i}")
            for _ in range(5):
                hit("/slow")
            for _ in range(3):
                hit("/boom")

            # Wait for the SDK reporter to flush at least once.
            time.sleep(DEFAULT_FLUSH_INTERVAL + 1.5)

            services = get_json(f"http://127.0.0.1:{COLLECTOR_PORT}/api/services")["services"]
            overview = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/overview?service=smoke-app&w=600"
            )
            routes = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/routes?service=smoke-app&w=600"
            )["routes"]
            errors = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/recent_errors?service=smoke-app&limit=10"
            )["errors"]
            ts = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/timeseries?service=smoke-app&w=600&bucket=5"
            )["points"]

            print("=== services ===")
            print(json.dumps(services, indent=2, default=str))
            print("=== overview ===")
            print(json.dumps(overview, indent=2))
            print("=== routes ===")
            print(json.dumps(routes, indent=2))
            print(f"=== recent_errors ({len(errors)}) ===")
            print(json.dumps(errors[:3], indent=2))
            print(f"=== timeseries points: {len(ts)} ===")

            # Assertions
            assert services, "expected at least one service"
            assert any(s["service"] == "smoke-app" for s in services)
            assert overview["total_requests"] >= 28, overview
            assert overview["errors"] >= 3, overview
            route_set = {(r["method"], r["route"]) for r in routes}
            # Templates should be normalized: /users/{user_id}, not /users/1
            assert ("GET", "/users/{user_id}") in route_set, route_set
            assert ("GET", "/slow") in route_set, route_set
            assert ("GET", "/boom") in route_set, route_set
            assert any(e["status"] == 500 for e in errors), errors
            assert ts, "expected at least one timeseries bucket"

            # System metrics surfaced via heartbeat
            sm = next(s for s in services if s["service"] == "smoke-app")
            assert sm["cpu_pct"] is not None or sm["mem_mb"] is not None, sm

            print("\nSMOKE OK")
            return 0
        finally:
            stop.set()
            # Make sure the SDK reporter shuts down its background thread too.
            try:
                if Reporter._singleton is not None:
                    Reporter._singleton.shutdown()
            except Exception:
                pass
            for t in threads:
                t.join(timeout=3)


if __name__ == "__main__":
    raise SystemExit(main())
