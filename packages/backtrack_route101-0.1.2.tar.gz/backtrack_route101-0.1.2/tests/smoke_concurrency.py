"""Concurrency stress smoke — pins the SQLite-thread-safety bug shut.

Reproduces the failure mode from the user bug report: multiple writer threads
hammering `Store.ingest` while reader threads call every public read method.
On the pre-fix code (reads outside the lock) this prints hundreds of
`IndexError`, `TypeError`, or returns malformed tuples. On the fixed code it
prints `errors: 0`.

Run directly:
    python tests/smoke_concurrency.py
"""

from __future__ import annotations

import random
import sys
import tempfile
import threading
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from backtrack.collector.store import Store  # noqa: E402

WRITER_THREADS = 4
READER_THREADS = 6
ITERS_PER_THREAD = 400
SERVICES = ("svc-a", "svc-b", "svc-c")


def writer(store: Store, errors: list) -> None:
    for i in range(ITERS_PER_THREAD):
        try:
            service = random.choice(SERVICES)
            store.ingest(
                {
                    "service": service,
                    "host": "localhost",
                    "pid": random.randint(1, 5),
                    "cpu_pct": random.uniform(0, 100),
                    "mem_mb": random.uniform(50, 500),
                    "in_flight": i % 4,
                    "events": [
                        {
                            "ts": time.time(),
                            "method": "GET",
                            "route": f"/r/{i % 25}",
                            "path": f"/r/{i % 25}",
                            "status": 200 if i % 7 else 500,
                            "duration_ms": random.uniform(1, 50),
                            "request_id": f"rid-{service}-{i}",
                            "correlation_id": f"cid-{service}-{i // 5}",
                            "parent_id": f"rid-{service}-{i - 1}" if i % 3 == 0 else None,
                            "error": "BoomError" if i % 7 == 0 else None,
                            "error_type": "BoomError" if i % 7 == 0 else None,
                            "error_message": "kaboom" if i % 7 == 0 else None,
                            "error_traceback": "Traceback (most recent call last):\n  …" if i % 7 == 0 else None,
                            "error_fingerprint": "fp-1" if i % 7 == 0 else None,
                            "db_query_count": random.randint(0, 15),
                            "db_total_ms": random.uniform(0, 60),
                            "db_slow": [{"sql": "SELECT 1", "ms": 12.3}],
                            "outgoing_count": i % 3,
                            "outgoing_total_ms": random.uniform(0, 25),
                        }
                    ],
                    "outgoing_calls": [
                        {
                            "ts": time.time(),
                            "method": "GET",
                            "host": f"upstream-{i % 4}.local",
                            "path": "/x",
                            "status": 200,
                            "duration_ms": random.uniform(1, 30),
                            "error": None,
                            "source_request_id": f"rid-{service}-{i}",
                            "correlation_id": f"cid-{service}-{i // 5}",
                        }
                    ]
                    if i % 2 == 0
                    else [],
                }
            )
        except Exception as exc:  # noqa: BLE001
            errors.append(("writer", type(exc).__name__, str(exc)[:120]))


def reader(store: Store, errors: list) -> None:
    """Exercises every public read method that exists on Store."""
    for i in range(ITERS_PER_THREAD):
        svc = random.choice(SERVICES + (None,))
        try:
            store.services()
            store.overview(svc, 300)
            store.rps_buckets(svc, 300, 5)
            store.routes(svc, 300)
            store.error_groups(svc, 600, 50)
            store.outgoing_summary(svc, 600, 50)
            store.route_chains(svc, 300, 200)
            store.route_host_calls(svc, 300, 200)
            store.recent_errors(svc, None, 20)
            store.list_discovered(svc)
            store.discovered_scan_roots()
            if svc:
                store.route_snapshot(svc, "GET", f"/r/{i % 25}", 600)
                store.folder_snapshot(svc, "", 600)
                store.outgoing_for_route(svc, "GET", f"/r/{i % 25}", 600)
        except Exception as exc:  # noqa: BLE001
            errors.append(
                (
                    "reader",
                    type(exc).__name__,
                    "".join(traceback.format_exception_only(type(exc), exc))[:200],
                )
            )


def main() -> int:
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "concurrent.db"
        store = Store(db, retention_seconds=600)

        errors: list = []
        threads = (
            [threading.Thread(target=writer, args=(store, errors), daemon=True) for _ in range(WRITER_THREADS)]
            + [threading.Thread(target=reader, args=(store, errors), daemon=True) for _ in range(READER_THREADS)]
        )
        t0 = time.time()
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        elapsed = time.time() - t0

        total_ops = (WRITER_THREADS + READER_THREADS) * ITERS_PER_THREAD
        per_sec = total_ops / elapsed if elapsed else 0

        print(
            f"writers={WRITER_THREADS} readers={READER_THREADS} "
            f"iters/thread={ITERS_PER_THREAD} -> {total_ops} ops in {elapsed:.2f}s "
            f"({per_sec:.0f} ops/s)"
        )
        print(f"errors: {len(errors)}")
        for kind, exc, msg in errors[:5]:
            print(f"  {kind}: {exc}: {msg}")

        store.close()

        if errors:
            print("\nCONCURRENCY SMOKE FAILED — see errors above")
            return 1
        print("\nCONCURRENCY SMOKE OK")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
