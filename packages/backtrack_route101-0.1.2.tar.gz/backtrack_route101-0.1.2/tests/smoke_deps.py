"""End-to-end smoke for the bipartite deps view.

Boots collector + an instrumented FastAPI app with three routes that fan out
to two different external hosts. Verifies /api/route_host_calls returns the
expected (route, host, count) edges and the dashboard's app.js carries the
new renderer.
"""

from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import httpx  # noqa: E402
import uvicorn  # noqa: E402
from fastapi import FastAPI  # noqa: E402

from backtrack.collector.server import build_app  # noqa: E402
from backtrack.collector.store import Store  # noqa: E402
from backtrack.sdk._wire import DEFAULT_FLUSH_INTERVAL, Reporter  # noqa: E402
from backtrack.sdk.fastapi import BacktrackMiddleware  # noqa: E402

COLLECTOR_PORT = 9886
APP_PORT = 9887
ENDPOINT = f"http://127.0.0.1:{COLLECTOR_PORT}/ingest"


def run_collector(stop: threading.Event, db: Path) -> None:
    store = Store(path=db, retention_seconds=600)
    app = build_app(store)
    config = uvicorn.Config(app, host="127.0.0.1", port=COLLECTOR_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    try:
        server.run()
    finally:
        store.close()


def make_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(BacktrackMiddleware, service="deps", endpoint=ENDPOINT)

    @app.get("/health")
    def health() -> dict:
        return {"ok": True}

    @app.get("/echo")
    def echo() -> dict:
        return {"echo": True}

    @app.get("/orders/{order_id}")
    async def order(order_id: int) -> dict:
        # One outbound call to "downstream-a"
        async with httpx.AsyncClient() as c:
            await c.get(f"http://127.0.0.1:{APP_PORT}/echo", timeout=2)
        return {"order_id": order_id}

    @app.get("/checkout/{order_id}")
    async def checkout(order_id: int) -> dict:
        # Two outbound calls, mimicking a multi-host endpoint
        async with httpx.AsyncClient() as c:
            await c.get(f"http://127.0.0.1:{APP_PORT}/echo", timeout=2)
            await c.get(f"http://127.0.0.1:{APP_PORT}/health", timeout=2)
        return {"order_id": order_id, "ok": True}

    return app


def run_app(stop: threading.Event) -> None:
    config = uvicorn.Config(make_app(), host="127.0.0.1", port=APP_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    server.run()


def wait_for(url: str, attempts: int = 80) -> None:
    for _ in range(attempts):
        try:
            urllib.request.urlopen(url, timeout=0.5).read()
            return
        except Exception:
            time.sleep(0.1)
    raise RuntimeError(f"timed out waiting for {url}")


def get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=5) as r:
        return json.loads(r.read())


def main() -> int:
    stop = threading.Event()
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "deps.db"
        threads = [
            threading.Thread(target=run_collector, args=(stop, db), daemon=True),
            threading.Thread(target=run_app, args=(stop,), daemon=True),
        ]
        for t in threads:
            t.start()
        try:
            wait_for(f"http://127.0.0.1:{COLLECTOR_PORT}/api/services")
            wait_for(f"http://127.0.0.1:{APP_PORT}/health")

            with httpx.Client() as c:
                for i in range(4):
                    r = c.get(f"http://127.0.0.1:{APP_PORT}/orders/{i}", timeout=3)
                    assert r.status_code == 200, r.text
                for i in range(3):
                    r = c.get(f"http://127.0.0.1:{APP_PORT}/checkout/{i}", timeout=3)
                    assert r.status_code == 200, r.text

            time.sleep(DEFAULT_FLUSH_INTERVAL + 2.0)

            edges = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/route_host_calls?service=deps&w=600"
            )["edges"]
            print("=== deps edges ===")
            print(json.dumps(edges, indent=2))

            # Build a lookup keyed by (route, host)
            byKey = {(e["route"], e["host"]): e for e in edges}
            host = f"127.0.0.1:{APP_PORT}"

            # /orders/{id} fans out 1× to /echo
            ord_edge = byKey.get(("/orders/{order_id}", host))
            assert ord_edge, f"missing /orders edge; got keys {list(byKey)}"
            assert ord_edge["calls"] >= 4, ord_edge

            # /checkout/{id} fans out 2× per request → 6 calls for 3 hits
            chk_edge = byKey.get(("/checkout/{order_id}", host))
            assert chk_edge, f"missing /checkout edge; got keys {list(byKey)}"
            assert chk_edge["calls"] >= 6, chk_edge

            # Verify the dashboard JS carries the deps renderer.
            app_js = urllib.request.urlopen(
                f"http://127.0.0.1:{COLLECTOR_PORT}/static/app.js", timeout=3
            ).read().decode("utf-8", errors="replace")
            for needle in (
                "buildDepsElements",
                "route_host_calls",
                "lastDepsEdges",
                'type = "host"',
                'type = "route"',
            ):
                assert needle in app_js, f"served app.js missing {needle!r}"

            print("\nDEPS SMOKE OK")
            return 0
        finally:
            stop.set()
            try:
                if Reporter._singleton is not None:
                    Reporter._singleton.shutdown()
            except Exception:
                pass
            for t in threads:
                t.join(timeout=3)


if __name__ == "__main__":
    raise SystemExit(main())
