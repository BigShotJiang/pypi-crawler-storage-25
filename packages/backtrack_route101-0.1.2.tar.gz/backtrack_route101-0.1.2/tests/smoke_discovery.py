"""Smoke test for the discovery feature.

Boots the collector, POSTs /api/scan against the two fixture apps, then
verifies /api/discovered returns the expected route shapes for the dashboard
tree to consume.
"""

from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import uvicorn  # noqa: E402

from backtrack.collector.server import build_app  # noqa: E402
from backtrack.collector.store import Store  # noqa: E402

COLLECTOR_PORT = 9879


def run_collector(stop: threading.Event, db: Path) -> None:
    store = Store(path=db, retention_seconds=600)
    app = build_app(store)
    config = uvicorn.Config(app, host="127.0.0.1", port=COLLECTOR_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    try:
        server.run()
    finally:
        store.close()


def wait_for(url: str, attempts: int = 50) -> None:
    for _ in range(attempts):
        try:
            urllib.request.urlopen(url, timeout=0.5).read()
            return
        except Exception:
            time.sleep(0.1)
    raise RuntimeError(f"timed out waiting for {url}")


def post_json(url: str, body: dict) -> dict:
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read())


def get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=5) as r:
        return json.loads(r.read())


def main() -> int:
    stop = threading.Event()
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "discovery.db"
        t = threading.Thread(target=run_collector, args=(stop, db), daemon=True)
        t.start()
        try:
            wait_for(f"http://127.0.0.1:{COLLECTOR_PORT}/api/services")
            fastapi_root = (ROOT / "tests" / "fixtures" / "fastapi_app").resolve()
            django_root = (ROOT / "tests" / "fixtures" / "django_app").resolve()

            r1 = post_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/scan",
                {"service": "fapi", "path": str(fastapi_root)},
            )
            r2 = post_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/scan",
                {"service": "djapp", "path": str(django_root)},
            )
            print("scan fapi  :", r1)
            print("scan djapp :", r2)

            assert r1["routes"] >= 2, r1
            assert r2["routes"] >= 3, r2
            assert r1["by_framework"].get("fastapi", 0) >= 2
            assert r2["by_framework"].get("django", 0) >= 3

            fapi = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/discovered?service=fapi"
            )
            djapp = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/discovered?service=djapp"
            )
            print("\n=== fapi discovered ===")
            print(json.dumps(fapi, indent=2))
            print("\n=== djapp discovered ===")
            print(json.dumps(djapp, indent=2))

            # FastAPI assertions
            fapi_keys = {(r["method"], r["route"]) for r in fapi["routes"]}
            assert ("GET", "/items/{item_id}") in fapi_keys, fapi_keys
            assert ("POST", "/items") in fapi_keys, fapi_keys
            fns = {r["function"] for r in fapi["routes"]}
            assert "get_item" in fns and "create_item" in fns, fns

            # Django assertions
            dj_keys = {(r["method"], r["route"]) for r in djapp["routes"]}
            assert any(r == "/items/<int:pk>/" for (_, r) in dj_keys), dj_keys
            assert any(r == "/health/" for (_, r) in dj_keys), dj_keys
            dj_fns = {r["function"] for r in djapp["routes"]}
            assert "ItemView" in dj_fns or "as_view" in dj_fns, dj_fns

            # Re-scan replaces (delete + insert)
            r1b = post_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/scan",
                {"service": "fapi", "path": str(fastapi_root)},
            )
            assert r1b["routes"] == r1["routes"], (r1b, r1)
            fapi2 = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/discovered?service=fapi"
            )
            assert len(fapi2["routes"]) == len(fapi["routes"])

            # Scan-roots metadata used by the dashboard header
            all_disc = get_json(f"http://127.0.0.1:{COLLECTOR_PORT}/api/discovered")
            services_with_scans = {s["service"] for s in all_disc["scan_roots"]}
            assert services_with_scans == {"fapi", "djapp"}, services_with_scans

            print("\nDISCOVERY SMOKE OK")
            return 0
        finally:
            stop.set()
            t.join(timeout=3)


if __name__ == "__main__":
    raise SystemExit(main())
