"""Two-hop correlation smoke test.

Boots:
  - the collector
  - "service-b" instrumented FastAPI on port 9821 with a /b/{id} route
  - "service-a" instrumented FastAPI on port 9820 with a /a/{id} route that
    httpx-calls service-b, propagating headers via current_headers()

Then:
  - fires N requests against /a/{id}
  - waits for flushes
  - asserts /api/route_chains returns the (a -> b) intra-service pair for
    service-a (via the parent_id linkage) ... but the chain crosses services,
    so we only get an INTRA-service edge when both hops happen in the *same*
    service. We test the cross-service case by hitting /a/{id} which calls
    /a/echo internally inside the same service-a process.
"""

from __future__ import annotations

import json
import sys
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import httpx  # noqa: E402
import uvicorn  # noqa: E402
from fastapi import FastAPI, Request  # noqa: E402

from backtrack.collector.server import build_app  # noqa: E402
from backtrack.collector.store import Store  # noqa: E402
from backtrack.sdk._wire import DEFAULT_FLUSH_INTERVAL, Reporter  # noqa: E402
from backtrack.sdk.correlation import current_headers, get_request_id  # noqa: E402
from backtrack.sdk.fastapi import BacktrackMiddleware  # noqa: E402

COLLECTOR_PORT = 9883
APP_PORT = 9820  # service-a
ENDPOINT = f"http://127.0.0.1:{COLLECTOR_PORT}/ingest"


def run_collector(stop: threading.Event, db: Path) -> None:
    store = Store(path=db, retention_seconds=600)
    app = build_app(store)
    config = uvicorn.Config(app, host="127.0.0.1", port=COLLECTOR_PORT, log_level="error")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    try:
        server.run()
    finally:
        store.close()


def make_app_a() -> FastAPI:
    app = FastAPI()
    app.add_middleware(BacktrackMiddleware, service="service-a", endpoint=ENDPOINT)

    @app.get("/health")
    def health() -> dict:
        return {"ok": True}

    @app.get("/orders/{order_id}")
    async def get_order(order_id: int) -> dict:
        # Outer hop: call /downstream/echo with propagated headers.
        my_rid = get_request_id()
        headers = current_headers()
        async with httpx.AsyncClient() as client:
            r = await client.get(
                f"http://127.0.0.1:{APP_PORT}/downstream/echo", headers=headers, timeout=2
            )
        return {"order_id": order_id, "my_request_id": my_rid, "echo": r.json()}

    @app.get("/downstream/echo")
    def echo(request: Request) -> dict:
        return {
            "received_request_id": get_request_id(),
            "x_correlation": request.headers.get("x-correlation-id"),
            "x_parent": request.headers.get("x-parent-request-id"),
        }

    return app


def run_app(stop: threading.Event) -> None:
    config = uvicorn.Config(make_app_a(), host="127.0.0.1", port=APP_PORT, log_level="warning")
    server = uvicorn.Server(config)

    def watcher() -> None:
        stop.wait()
        server.should_exit = True

    threading.Thread(target=watcher, daemon=True).start()
    server.run()


def wait_for(url: str, attempts: int = 60) -> None:
    for _ in range(attempts):
        try:
            urllib.request.urlopen(url, timeout=0.5).read()
            return
        except Exception:
            time.sleep(0.1)
    raise RuntimeError(f"timed out waiting for {url}")


def get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=5) as r:
        return json.loads(r.read())


def post_json(url: str, body: dict) -> dict:
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read())


def main() -> int:
    stop = threading.Event()
    with tempfile.TemporaryDirectory() as tmp:
        db = Path(tmp) / "corr.db"
        threads = [
            threading.Thread(target=run_collector, args=(stop, db), daemon=True),
            threading.Thread(target=run_app, args=(stop,), daemon=True),
        ]
        for t in threads:
            t.start()
        try:
            wait_for(f"http://127.0.0.1:{COLLECTOR_PORT}/api/services")
            wait_for(f"http://127.0.0.1:{APP_PORT}/health")

            # Fire requests against /orders/{id}; each one triggers an internal call to /downstream/echo
            for i in range(10):
                with httpx.Client() as c:
                    r = c.get(f"http://127.0.0.1:{APP_PORT}/orders/{i}", timeout=4)
                    assert r.status_code == 200, r.text
                    body = r.json()
                    # Verify the inner hop saw the outer hop as parent
                    assert body["echo"]["x_parent"] == body["my_request_id"], body
                    assert body["echo"]["x_correlation"], body

            # Wait for flush
            time.sleep(DEFAULT_FLUSH_INTERVAL + 1.5)

            chains = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/route_chains?service=service-a&w=600"
            )["chains"]
            print("=== chains (service-a) ===")
            print(json.dumps(chains, indent=2))

            keys = {(c["parent_method"], c["parent_route"], c["child_method"], c["child_route"]) for c in chains}
            assert ("GET", "/orders/{order_id}", "GET", "/downstream/echo") in keys, keys
            edge = next(c for c in chains if c["child_route"] == "/downstream/echo")
            assert edge["count"] >= 10, edge

            # Discovery + folder snapshot
            # Synthesize a tiny "discovered" set so the folder filter has a basis.
            post_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/scan",
                {"service": "service-a", "path": str(ROOT / "tests" / "fixtures" / "fastapi_app")},
            )
            snap = get_json(
                f"http://127.0.0.1:{COLLECTOR_PORT}/api/folder/snapshot?service=service-a&folder=&w=600"
            )
            print("\n=== folder snapshot (root) ===")
            print(json.dumps(snap, indent=2))
            assert snap["discovered_routes"] >= 2, snap

            print("\nCORRELATION SMOKE OK")
            return 0
        finally:
            stop.set()
            try:
                if Reporter._singleton is not None:
                    Reporter._singleton.shutdown()
            except Exception:
                pass
            for t in threads:
                t.join(timeout=3)


if __name__ == "__main__":
    raise SystemExit(main())
