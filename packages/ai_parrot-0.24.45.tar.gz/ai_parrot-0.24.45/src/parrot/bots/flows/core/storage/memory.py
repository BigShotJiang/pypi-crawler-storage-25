"""Flow Primitives — ExecutionMemory.

Copied from ``parrot.bots.flow.storage.memory`` into the shared core
storage location.  Relative imports updated for the new package depth.

Updated (TASK-976): ``AgentResult`` → ``NodeResult`` from ``flows.core.result``.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..result import NodeResult
from .mixin import VectorStoreMixin


@dataclass
class ExecutionMemory(VectorStoreMixin):
    """In-memory storage for execution history.

    Optionally indexes results into a FAISS vector store (via
    ``VectorStoreMixin``) when an ``embedding_model`` is provided.

    Args:
        original_query: The initial prompt/task string for this execution.
        embedding_model: Optional embedding model for FAISS indexing.
        dimension: Embedding dimension (default 384).
        index_type: FAISS index type (``"Flat"``, ``"FlatIP"``, or ``"HNSW"``).
    """

    original_query: Optional[str] = None
    results: Dict[str, NodeResult] = field(default_factory=dict)
    execution_graph: Dict[str, List[str]] = field(default_factory=dict)
    execution_order: List[str] = field(default_factory=list)

    def __init__(
        self,
        original_query: str = "",
        embedding_model=None,
        dimension: int = 384,
        index_type: str = "Flat",
    ):
        self.original_query = original_query
        self.results = {}
        self.execution_graph = {}
        self.execution_order = []
        VectorStoreMixin.__init__(
            self,
            embedding_model=embedding_model,
            dimension=dimension,
            index_type=index_type,
        )

    def add_result(self, result: NodeResult, vectorize: bool = True) -> None:
        """Add a result and update execution graph.

        Args:
            result: The ``NodeResult`` (or legacy ``AgentResult``) to store.
            vectorize: If ``True`` and an embedding model is configured,
                schedule async FAISS indexing.
        """
        key = getattr(result, "node_id", None) or result.agent_id
        self.results[key] = result
        if result.parent_execution_id:
            if result.parent_execution_id not in self.execution_graph:
                self.execution_graph[result.parent_execution_id] = []
            self.execution_graph[result.parent_execution_id].append(result.execution_id)

        if vectorize and self.embedding_model:
            # create_task requires a running event loop; guard so sync callers
            # (e.g. test setup, __init__) don't raise RuntimeError.
            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._vectorize_result_async(result))
            except RuntimeError:
                pass  # No running loop; vectorization skipped in sync context

    def get_results_by_agent(self, agent_id: str) -> Optional[NodeResult]:
        """Retrieve result from a specific agent/node.

        Args:
            agent_id: Agent/node identifier.

        Returns:
            ``NodeResult`` or ``None`` if not found.
        """
        return self.results.get(agent_id)

    def get_reexecuted_results(self) -> List[NodeResult]:
        """Return only results from re-executions triggered by ``ask()``.

        Returns:
            List of ``NodeResult`` instances with a non-None
            ``parent_execution_id``.
        """
        return [r for r in self.results.values() if r.parent_execution_id is not None]

    def get_context_for_agent(self, agent_id: str) -> Any:
        """Return the context available to an agent at execution time.

        Args:
            agent_id: Agent identifier.

        Returns:
            Initial query for the first agent, previous agent's result when
            available, or ``original_query`` if either look-up fails.
        """
        try:
            idx = self.execution_order.index(agent_id)
        except ValueError:
            # agent_id not recorded in execution_order yet; fall back gracefully.
            return self.original_query
        if idx == 0:
            return self.original_query
        prev_agent_id = self.execution_order[idx - 1]
        prev_result = self.results.get(prev_agent_id)
        return prev_result.result if prev_result is not None else self.original_query

    def clear(self, keep_query: bool = False) -> None:
        """Clear execution memory.

        Args:
            keep_query: If ``True``, preserves ``original_query``.
        """
        self.results.clear()
        self.execution_graph.clear()
        self.execution_order.clear()
        self._clear_vectors()

        if not keep_query:
            self.original_query = ""

    def get_snapshot(self) -> Dict[str, Any]:
        """Return a serialisable snapshot of the current memory state.

        Returns:
            Dictionary with all memory state information.
        """
        return {
            "original_query": self.original_query,
            "results": {
                node_id: {
                    "result": str(result.result),
                    "task": result.task,
                    "metadata": result.metadata,
                    "timestamp": result.timestamp.isoformat(),
                    "parent_execution_id": result.parent_execution_id,
                    "execution_time": result.execution_time,
                }
                for node_id, result in self.results.items()
            },
            "execution_order": self.execution_order.copy(),
            "execution_graph": {k: v.copy() for k, v in self.execution_graph.items()},
            "total_executions": len(self.results),
            "reexecutions": len(self.get_reexecuted_results()),
        }
