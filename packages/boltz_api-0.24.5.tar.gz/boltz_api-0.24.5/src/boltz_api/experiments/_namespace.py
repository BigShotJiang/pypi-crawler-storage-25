from __future__ import annotations

from os import PathLike
from typing import TypeVar
from pathlib import Path
from collections.abc import Iterable
from typing_extensions import Literal, TypedDict

from ._state import load_metadata
from ._types import SmallMoleculeTarget
from ._engine import (
    ExperimentEngine,
    PipelineDefinition,
    PredictionDefinition,
    unsupported_stop,
)
from .._client import Boltz
from ._progress import build_progress_sink
from ._normalize import (
    ProteinDesignTargetInput,
    ProteinLibraryScreenTargetInput,
    ProteinDesignBinderSpecificationInput,
    normalize_prediction_request,
    normalize_protein_design_request,
    normalize_small_molecule_design_request,
    normalize_protein_library_screen_request,
    normalize_small_molecule_library_screen_request,
)
from ..pagination import SyncCursorPage
from ._addressing import resolve_create_run_dir, resolve_existing_run_dir
from ._fingerprint import fingerprint_payload
from ..types.protein import (
    design_start_params as protein_design_start_params,
    design_stop_response as protein_design_stop_response,
    design_start_response as protein_design_start_response,
    design_retrieve_response as protein_design_retrieve_response,
    library_screen_start_params as protein_library_screen_start_params,
    design_list_results_response as protein_design_list_results_response,
    library_screen_stop_response as protein_library_screen_stop_response,
    library_screen_start_response as protein_library_screen_start_response,
    library_screen_retrieve_response as protein_library_screen_retrieve_response,
    library_screen_list_results_response as protein_library_screen_list_results_response,
)
from ..types.predictions import (
    structure_and_binding_start_params,
    structure_and_binding_start_response,
    structure_and_binding_retrieve_response,
)
from ..types.small_molecule import (
    design_start_params as small_molecule_design_start_params,
    design_stop_response as small_molecule_design_stop_response,
    design_start_response as small_molecule_design_start_response,
    design_retrieve_response as small_molecule_design_retrieve_response,
    library_screen_start_params as small_molecule_library_screen_start_params,
    design_list_results_response as small_molecule_design_list_results_response,
    library_screen_stop_response as small_molecule_library_screen_stop_response,
    library_screen_start_response as small_molecule_library_screen_start_response,
    library_screen_retrieve_response as small_molecule_library_screen_retrieve_response,
    library_screen_list_results_response as small_molecule_library_screen_list_results_response,
)


class _WorkspaceKwargs(TypedDict, total=False):
    workspace_id: str


class _WorkspaceAfterKwargs(TypedDict, total=False):
    workspace_id: str
    after_id: str


class _SmallMoleculeDesignStartKwargs(TypedDict, total=False):
    chemical_space: Literal["enamine_real"]
    molecule_filters: small_molecule_design_start_params.MoleculeFilters
    workspace_id: str


class _SmallMoleculeLibraryScreenStartKwargs(TypedDict, total=False):
    molecule_filters: small_molecule_library_screen_start_params.MoleculeFilters
    workspace_id: str


_PipelinePayloadT = TypeVar("_PipelinePayloadT")


class ExperimentsNamespace:
    def __init__(self, client: Boltz) -> None:
        self._client = client

        self._prediction_definition: PredictionDefinition[
            structure_and_binding_start_params.StructureAndBindingStartParams
        ] = PredictionDefinition(
            run_type="prediction",
            start_call=self._prediction_start_call,
            retrieve_call=self._prediction_retrieve_call,
        )
        self._protein_design_definition: PipelineDefinition[protein_design_start_params.DesignStartParams] = (
            PipelineDefinition(
                run_type="protein_design",
                start_call=self._protein_design_start_call,
                retrieve_call=self._protein_design_retrieve_call,
                list_results_call=self._protein_design_list_results_call,
                stop_call=self._protein_design_stop_call,
            )
        )
        self._protein_library_screen_definition: PipelineDefinition[
            protein_library_screen_start_params.LibraryScreenStartParams
        ] = PipelineDefinition(
            run_type="protein_library_screen",
            start_call=self._protein_library_screen_start_call,
            retrieve_call=self._protein_library_screen_retrieve_call,
            list_results_call=self._protein_library_screen_list_results_call,
            stop_call=self._protein_library_screen_stop_call,
        )
        self._small_molecule_design_definition: PipelineDefinition[
            small_molecule_design_start_params.DesignStartParams
        ] = PipelineDefinition(
            run_type="small_molecule_design",
            start_call=self._small_molecule_design_start_call,
            retrieve_call=self._small_molecule_design_retrieve_call,
            list_results_call=self._small_molecule_design_list_results_call,
            stop_call=self._small_molecule_design_stop_call,
        )
        self._small_molecule_library_screen_definition: PipelineDefinition[
            small_molecule_library_screen_start_params.LibraryScreenStartParams
        ] = PipelineDefinition(
            run_type="small_molecule_library_screen",
            start_call=self._small_molecule_library_screen_start_call,
            retrieve_call=self._small_molecule_library_screen_retrieve_call,
            list_results_call=self._small_molecule_library_screen_list_results_call,
            stop_call=self._small_molecule_library_screen_stop_call,
        )

    def run_structure_and_binding(
        self,
        *,
        entities: Iterable[structure_and_binding_start_params.InputEntity],
        model: Literal["boltz-2.1"],
        binding: structure_and_binding_start_params.InputBinding | None = None,
        bonds: Iterable[structure_and_binding_start_params.InputBond] | None = None,
        constraints: Iterable[structure_and_binding_start_params.InputConstraint] | None = None,
        model_options: structure_and_binding_start_params.InputModelOptions | None = None,
        num_samples: int | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        return self.run_prediction(
            entities=entities,
            model=model,
            binding=binding,
            bonds=bonds,
            constraints=constraints,
            model_options=model_options,
            num_samples=num_samples,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )

    def start_structure_and_binding(
        self,
        *,
        entities: Iterable[structure_and_binding_start_params.InputEntity],
        model: Literal["boltz-2.1"],
        binding: structure_and_binding_start_params.InputBinding | None = None,
        bonds: Iterable[structure_and_binding_start_params.InputBond] | None = None,
        constraints: Iterable[structure_and_binding_start_params.InputConstraint] | None = None,
        model_options: structure_and_binding_start_params.InputModelOptions | None = None,
        num_samples: int | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        return self.start_prediction(
            entities=entities,
            model=model,
            binding=binding,
            bonds=bonds,
            constraints=constraints,
            model_options=model_options,
            num_samples=num_samples,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )

    def predict_structure_and_binding(
        self,
        *,
        entities: Iterable[structure_and_binding_start_params.InputEntity],
        model: Literal["boltz-2.1"],
        binding: structure_and_binding_start_params.InputBinding | None = None,
        bonds: Iterable[structure_and_binding_start_params.InputBond] | None = None,
        constraints: Iterable[structure_and_binding_start_params.InputConstraint] | None = None,
        model_options: structure_and_binding_start_params.InputModelOptions | None = None,
        num_samples: int | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        return self.run_structure_and_binding(
            entities=entities,
            model=model,
            binding=binding,
            bonds=bonds,
            constraints=constraints,
            model_options=model_options,
            num_samples=num_samples,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )

    def run_prediction(
        self,
        *,
        entities: Iterable[structure_and_binding_start_params.InputEntity],
        model: Literal["boltz-2.1"],
        binding: structure_and_binding_start_params.InputBinding | None = None,
        bonds: Iterable[structure_and_binding_start_params.InputBond] | None = None,
        constraints: Iterable[structure_and_binding_start_params.InputConstraint] | None = None,
        model_options: structure_and_binding_start_params.InputModelOptions | None = None,
        num_samples: int | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        run_dir = self.start_prediction(
            entities=entities,
            model=model,
            binding=binding,
            bonds=bonds,
            constraints=constraints,
            model_options=model_options,
            num_samples=num_samples,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )
        return self.wait_and_download(run_dir=run_dir, quiet=quiet, poll_interval_seconds=poll_interval_seconds)

    def start_prediction(
        self,
        *,
        entities: Iterable[structure_and_binding_start_params.InputEntity],
        model: Literal["boltz-2.1"],
        binding: structure_and_binding_start_params.InputBinding | None = None,
        bonds: Iterable[structure_and_binding_start_params.InputBond] | None = None,
        constraints: Iterable[structure_and_binding_start_params.InputConstraint] | None = None,
        model_options: structure_and_binding_start_params.InputModelOptions | None = None,
        num_samples: int | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        del poll_interval_seconds
        payload = normalize_prediction_request(
            entities=entities,
            model=model,
            binding=binding,
            bonds=bonds,
            constraints=constraints,
            model_options=model_options,
            num_samples=num_samples,
        )
        return self._start_prediction(
            payload=payload,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
        )

    def run_protein_design(
        self,
        *,
        binder_specification: ProteinDesignBinderSpecificationInput,
        num_proteins: int,
        target: ProteinDesignTargetInput,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        run_dir = self.start_protein_design(
            binder_specification=binder_specification,
            num_proteins=num_proteins,
            target=target,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )
        return self.wait_and_download(run_dir=run_dir, quiet=quiet, poll_interval_seconds=poll_interval_seconds)

    def start_protein_design(
        self,
        *,
        binder_specification: ProteinDesignBinderSpecificationInput,
        num_proteins: int,
        target: ProteinDesignTargetInput,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        del poll_interval_seconds
        payload = normalize_protein_design_request(
            binder_specification=binder_specification,
            num_proteins=num_proteins,
            target=target,
        )
        return self._start_pipeline(
            definition=self._protein_design_definition,
            payload=payload,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
        )

    def run_protein_library_screen(
        self,
        *,
        proteins: Iterable[protein_library_screen_start_params.Protein],
        target: ProteinLibraryScreenTargetInput,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        run_dir = self.start_protein_library_screen(
            proteins=proteins,
            target=target,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )
        return self.wait_and_download(run_dir=run_dir, quiet=quiet, poll_interval_seconds=poll_interval_seconds)

    def start_protein_library_screen(
        self,
        *,
        proteins: Iterable[protein_library_screen_start_params.Protein],
        target: ProteinLibraryScreenTargetInput,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        del poll_interval_seconds
        payload = normalize_protein_library_screen_request(
            proteins=proteins,
            target=target,
        )
        return self._start_pipeline(
            definition=self._protein_library_screen_definition,
            payload=payload,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
        )

    def run_small_molecule_design(
        self,
        *,
        num_molecules: int,
        target: SmallMoleculeTarget,
        chemical_space: Literal["enamine_real"] | None = None,
        molecule_filters: small_molecule_design_start_params.MoleculeFilters | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        run_dir = self.start_small_molecule_design(
            num_molecules=num_molecules,
            target=target,
            chemical_space=chemical_space,
            molecule_filters=molecule_filters,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )
        return self.wait_and_download(run_dir=run_dir, quiet=quiet, poll_interval_seconds=poll_interval_seconds)

    def start_small_molecule_design(
        self,
        *,
        num_molecules: int,
        target: SmallMoleculeTarget,
        chemical_space: Literal["enamine_real"] | None = None,
        molecule_filters: small_molecule_design_start_params.MoleculeFilters | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        del poll_interval_seconds
        payload = normalize_small_molecule_design_request(
            num_molecules=num_molecules,
            target=target,
            chemical_space=chemical_space,
            molecule_filters=molecule_filters,
        )
        return self._start_pipeline(
            definition=self._small_molecule_design_definition,
            payload=payload,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
        )

    def run_small_molecule_library_screen(
        self,
        *,
        molecules: Iterable[small_molecule_library_screen_start_params.Molecule],
        target: SmallMoleculeTarget,
        molecule_filters: small_molecule_library_screen_start_params.MoleculeFilters | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        run_dir = self.start_small_molecule_library_screen(
            molecules=molecules,
            target=target,
            molecule_filters=molecule_filters,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
            poll_interval_seconds=poll_interval_seconds,
        )
        return self.wait_and_download(run_dir=run_dir, quiet=quiet, poll_interval_seconds=poll_interval_seconds)

    def start_small_molecule_library_screen(
        self,
        *,
        molecules: Iterable[small_molecule_library_screen_start_params.Molecule],
        target: SmallMoleculeTarget,
        molecule_filters: small_molecule_library_screen_start_params.MoleculeFilters | None = None,
        root_dir: str | PathLike[str] = "boltz-experiments",
        name: str | None = None,
        workspace_id: str | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        del poll_interval_seconds
        payload = normalize_small_molecule_library_screen_request(
            molecules=molecules,
            target=target,
            molecule_filters=molecule_filters,
        )
        return self._start_pipeline(
            definition=self._small_molecule_library_screen_definition,
            payload=payload,
            root_dir=root_dir,
            name=name,
            workspace_id=workspace_id,
            quiet=quiet,
        )

    def wait_and_download(
        self,
        *,
        run_dir: str | PathLike[str] | None = None,
        name: str | None = None,
        root_dir: str | PathLike[str] | None = None,
        quiet: bool = False,
        poll_interval_seconds: float = 5.0,
    ) -> Path:
        resolved_run_dir = resolve_existing_run_dir(run_dir=run_dir, name=name, root_dir=root_dir)
        metadata = load_metadata(resolved_run_dir)
        engine = ExperimentEngine(client=self._client, sink=build_progress_sink(quiet=quiet))

        if metadata.run_type == "prediction":
            return engine.wait_for_prediction(
                definition=self._prediction_definition,
                run_dir=resolved_run_dir,
                poll_interval_seconds=poll_interval_seconds,
            )
        if metadata.run_type == "protein_design":
            return engine.wait_for_pipeline(
                definition=self._protein_design_definition,
                run_dir=resolved_run_dir,
                poll_interval_seconds=poll_interval_seconds,
            )
        if metadata.run_type == "protein_library_screen":
            return engine.wait_for_pipeline(
                definition=self._protein_library_screen_definition,
                run_dir=resolved_run_dir,
                poll_interval_seconds=poll_interval_seconds,
            )
        if metadata.run_type == "small_molecule_design":
            return engine.wait_for_pipeline(
                definition=self._small_molecule_design_definition,
                run_dir=resolved_run_dir,
                poll_interval_seconds=poll_interval_seconds,
            )
        return engine.wait_for_pipeline(
            definition=self._small_molecule_library_screen_definition,
            run_dir=resolved_run_dir,
            poll_interval_seconds=poll_interval_seconds,
        )

    def stop(
        self,
        *,
        run_dir: str | PathLike[str] | None = None,
        name: str | None = None,
        root_dir: str | PathLike[str] | None = None,
        quiet: bool = False,
    ) -> Path:
        resolved_run_dir = resolve_existing_run_dir(run_dir=run_dir, name=name, root_dir=root_dir)
        metadata = load_metadata(resolved_run_dir)
        engine = ExperimentEngine(client=self._client, sink=build_progress_sink(quiet=quiet))

        if metadata.run_type == "prediction":
            unsupported_stop(metadata.run_type)
        if metadata.run_type == "protein_design":
            return engine.stop_pipeline(definition=self._protein_design_definition, run_dir=resolved_run_dir)
        if metadata.run_type == "protein_library_screen":
            return engine.stop_pipeline(
                definition=self._protein_library_screen_definition,
                run_dir=resolved_run_dir,
            )
        if metadata.run_type == "small_molecule_design":
            return engine.stop_pipeline(
                definition=self._small_molecule_design_definition,
                run_dir=resolved_run_dir,
            )
        return engine.stop_pipeline(
            definition=self._small_molecule_library_screen_definition,
            run_dir=resolved_run_dir,
        )

    def _start_prediction(
        self,
        *,
        payload: structure_and_binding_start_params.StructureAndBindingStartParams,
        root_dir: str | PathLike[str],
        name: str | None,
        workspace_id: str | None,
        quiet: bool,
    ) -> Path:
        run_dir = resolve_create_run_dir(root_dir, name)
        engine = ExperimentEngine(client=self._client, sink=build_progress_sink(quiet=quiet))
        return engine.start_prediction(
            definition=self._prediction_definition,
            run_dir=run_dir,
            request_payload=payload,
            request_fingerprint=fingerprint_payload(payload),
            workspace_id=workspace_id,
        )

    def _start_pipeline(
        self,
        *,
        definition: PipelineDefinition[_PipelinePayloadT],
        payload: _PipelinePayloadT,
        root_dir: str | PathLike[str],
        name: str | None,
        workspace_id: str | None,
        quiet: bool,
    ) -> Path:
        run_dir = resolve_create_run_dir(root_dir, name)
        engine = ExperimentEngine(client=self._client, sink=build_progress_sink(quiet=quiet))
        return engine.start_pipeline(
            definition=definition,
            run_dir=run_dir,
            request_payload=payload,
            request_fingerprint=fingerprint_payload(payload),
            workspace_id=workspace_id,
        )

    @staticmethod
    def _prediction_start_call(
        client: Boltz,
        payload: structure_and_binding_start_params.StructureAndBindingStartParams,
        key: str,
        workspace_id: str | None,
    ) -> structure_and_binding_start_response.StructureAndBindingStartResponse:
        return client.predictions.structure_and_binding.start(
            input=payload["input"],
            model=payload["model"],
            idempotency_key=key,
            **_workspace_kwargs(workspace_id),
        )

    @staticmethod
    def _prediction_retrieve_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
    ) -> structure_and_binding_retrieve_response.StructureAndBindingRetrieveResponse:
        return client.predictions.structure_and_binding.retrieve(run_id, **_workspace_kwargs(workspace_id))

    @staticmethod
    def _protein_design_start_call(
        client: Boltz,
        payload: protein_design_start_params.DesignStartParams,
        key: str,
        workspace_id: str | None,
    ) -> protein_design_start_response.DesignStartResponse:
        return client.protein.design.start(
            binder_specification=payload["binder_specification"],
            num_proteins=payload["num_proteins"],
            target=payload["target"],
            idempotency_key=key,
            **_workspace_kwargs(workspace_id),
        )

    @staticmethod
    def _protein_design_retrieve_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
    ) -> protein_design_retrieve_response.DesignRetrieveResponse:
        return client.protein.design.retrieve(run_id, **_workspace_kwargs(workspace_id))

    @staticmethod
    def _protein_design_list_results_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
        limit: int,
        after_id: str | None,
    ) -> SyncCursorPage[protein_design_list_results_response.DesignListResultsResponse]:
        return client.protein.design.list_results(
            run_id,
            limit=limit,
            **_workspace_after_kwargs(workspace_id, after_id),
        )

    @staticmethod
    def _protein_design_stop_call(
        client: Boltz,
        run_id: str,
    ) -> protein_design_stop_response.DesignStopResponse:
        return client.protein.design.stop(run_id)

    @staticmethod
    def _protein_library_screen_start_call(
        client: Boltz,
        payload: protein_library_screen_start_params.LibraryScreenStartParams,
        key: str,
        workspace_id: str | None,
    ) -> protein_library_screen_start_response.LibraryScreenStartResponse:
        return client.protein.library_screen.start(
            proteins=payload["proteins"],
            target=payload["target"],
            idempotency_key=key,
            **_workspace_kwargs(workspace_id),
        )

    @staticmethod
    def _protein_library_screen_retrieve_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
    ) -> protein_library_screen_retrieve_response.LibraryScreenRetrieveResponse:
        return client.protein.library_screen.retrieve(run_id, **_workspace_kwargs(workspace_id))

    @staticmethod
    def _protein_library_screen_list_results_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
        limit: int,
        after_id: str | None,
    ) -> SyncCursorPage[protein_library_screen_list_results_response.LibraryScreenListResultsResponse]:
        return client.protein.library_screen.list_results(
            run_id,
            limit=limit,
            **_workspace_after_kwargs(workspace_id, after_id),
        )

    @staticmethod
    def _protein_library_screen_stop_call(
        client: Boltz,
        run_id: str,
    ) -> protein_library_screen_stop_response.LibraryScreenStopResponse:
        return client.protein.library_screen.stop(run_id)

    @staticmethod
    def _small_molecule_design_start_call(
        client: Boltz,
        payload: small_molecule_design_start_params.DesignStartParams,
        key: str,
        workspace_id: str | None,
    ) -> small_molecule_design_start_response.DesignStartResponse:
        return client.small_molecule.design.start(
            num_molecules=payload["num_molecules"],
            target=payload["target"],
            idempotency_key=key,
            **_small_molecule_design_start_kwargs(payload, workspace_id),
        )

    @staticmethod
    def _small_molecule_design_retrieve_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
    ) -> small_molecule_design_retrieve_response.DesignRetrieveResponse:
        return client.small_molecule.design.retrieve(run_id, **_workspace_kwargs(workspace_id))

    @staticmethod
    def _small_molecule_design_list_results_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
        limit: int,
        after_id: str | None,
    ) -> SyncCursorPage[small_molecule_design_list_results_response.DesignListResultsResponse]:
        return client.small_molecule.design.list_results(
            run_id,
            limit=limit,
            **_workspace_after_kwargs(workspace_id, after_id),
        )

    @staticmethod
    def _small_molecule_design_stop_call(
        client: Boltz,
        run_id: str,
    ) -> small_molecule_design_stop_response.DesignStopResponse:
        return client.small_molecule.design.stop(run_id)

    @staticmethod
    def _small_molecule_library_screen_start_call(
        client: Boltz,
        payload: small_molecule_library_screen_start_params.LibraryScreenStartParams,
        key: str,
        workspace_id: str | None,
    ) -> small_molecule_library_screen_start_response.LibraryScreenStartResponse:
        return client.small_molecule.library_screen.start(
            molecules=payload["molecules"],
            target=payload["target"],
            idempotency_key=key,
            **_small_molecule_library_screen_start_kwargs(payload, workspace_id),
        )

    @staticmethod
    def _small_molecule_library_screen_retrieve_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
    ) -> small_molecule_library_screen_retrieve_response.LibraryScreenRetrieveResponse:
        return client.small_molecule.library_screen.retrieve(run_id, **_workspace_kwargs(workspace_id))

    @staticmethod
    def _small_molecule_library_screen_list_results_call(
        client: Boltz,
        run_id: str,
        workspace_id: str | None,
        limit: int,
        after_id: str | None,
    ) -> SyncCursorPage[small_molecule_library_screen_list_results_response.LibraryScreenListResultsResponse]:
        return client.small_molecule.library_screen.list_results(
            run_id,
            limit=limit,
            **_workspace_after_kwargs(workspace_id, after_id),
        )

    @staticmethod
    def _small_molecule_library_screen_stop_call(
        client: Boltz,
        run_id: str,
    ) -> small_molecule_library_screen_stop_response.LibraryScreenStopResponse:
        return client.small_molecule.library_screen.stop(run_id)


def _workspace_kwargs(workspace_id: str | None) -> _WorkspaceKwargs:
    kwargs: _WorkspaceKwargs = {}
    if workspace_id is not None:
        kwargs["workspace_id"] = workspace_id
    return kwargs


def _workspace_after_kwargs(workspace_id: str | None, after_id: str | None) -> _WorkspaceAfterKwargs:
    kwargs: _WorkspaceAfterKwargs = {}
    if workspace_id is not None:
        kwargs["workspace_id"] = workspace_id
    if after_id is not None:
        kwargs["after_id"] = after_id
    return kwargs


def _small_molecule_design_start_kwargs(
    payload: small_molecule_design_start_params.DesignStartParams,
    workspace_id: str | None,
) -> _SmallMoleculeDesignStartKwargs:
    kwargs: _SmallMoleculeDesignStartKwargs = {}
    if "chemical_space" in payload:
        kwargs["chemical_space"] = payload["chemical_space"]
    if "molecule_filters" in payload:
        kwargs["molecule_filters"] = payload["molecule_filters"]
    if workspace_id is not None:
        kwargs["workspace_id"] = workspace_id
    return kwargs


def _small_molecule_library_screen_start_kwargs(
    payload: small_molecule_library_screen_start_params.LibraryScreenStartParams,
    workspace_id: str | None,
) -> _SmallMoleculeLibraryScreenStartKwargs:
    kwargs: _SmallMoleculeLibraryScreenStartKwargs = {}
    if "molecule_filters" in payload:
        kwargs["molecule_filters"] = payload["molecule_filters"]
    if workspace_id is not None:
        kwargs["workspace_id"] = workspace_id
    return kwargs
