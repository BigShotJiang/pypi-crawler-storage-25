# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "boltz_api"
__version__ = "0.24.5"  # x-release-please-version
