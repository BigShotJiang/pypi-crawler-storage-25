# Changelog

## 0.24.5 (2026-05-09)

Full Changelog: [v0.24.4...v0.24.5](https://github.com/boltz-bio/boltz-api-python/compare/v0.24.4...v0.24.5)

### Bug Fixes

* **client:** add missing f-string prefix in file type error message ([84651cd](https://github.com/boltz-bio/boltz-api-python/commit/84651cd530acd5a2973677eed37d89aef81ed0e8))

## 0.24.4 (2026-05-02)

Full Changelog: [v0.24.3...v0.24.4](https://github.com/boltz-bio/boltz-api-python/compare/v0.24.3...v0.24.4)

### Bug Fixes

* stainless changes ([e912546](https://github.com/boltz-bio/boltz-api-python/commit/e912546e895517320663850f349db73f5d6701bc))

## 0.24.3 (2026-05-02)

Full Changelog: [v0.24.2...v0.24.3](https://github.com/boltz-bio/boltz-api-python/compare/v0.24.2...v0.24.3)

### Chores

* update SDK settings ([50e55f4](https://github.com/boltz-bio/boltz-api-python/commit/50e55f4f238396f9de8b684fd50049739a47f53c))
* update SDK settings ([9213c4b](https://github.com/boltz-bio/boltz-api-python/commit/9213c4b1749c8f81445b6be2678c04154a764c5a))

## 0.24.2 (2026-05-01)

Full Changelog: [v0.24.1...v0.24.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.24.1...v0.24.2)

### Bug Fixes

* **compute-api:** polish reference docs for CLI and auth ([5e47aa9](https://github.com/boltz-bio/boltz-compute-api-python/commit/5e47aa92d6fcab78f675d548400c70d12c8ffbfd))

## 0.24.1 (2026-05-01)

Full Changelog: [v0.24.0...v0.24.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.24.0...v0.24.1)

### Chores

* **internal:** reformat pyproject.toml ([91bde99](https://github.com/boltz-bio/boltz-compute-api-python/commit/91bde9908f0e4a2e527b5b1c446ae58e3b7c7eff))

## 0.24.0 (2026-04-30)

Full Changelog: [v0.23.1...v0.24.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.23.1...v0.24.0)

### Features

* **compute:** gate console backend by compute roles ([bbbe256](https://github.com/boltz-bio/boltz-compute-api-python/commit/bbbe2563195eba7bdabaa017c55198456e129e3d))

## 0.23.1 (2026-04-30)

Full Changelog: [v0.23.0...v0.23.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.23.0...v0.23.1)

### Bug Fixes

* **compute-api:** display requested estimate units ([d6fb954](https://github.com/boltz-bio/boltz-compute-api-python/commit/d6fb954d395aab6fd279f05ce83f51e63c767d38))
* **sdk:** serialize usage arrays as repeated params ([1cc8de2](https://github.com/boltz-bio/boltz-compute-api-python/commit/1cc8de27e415d51e4bc7bdfac5af1647dd0945c9))

## 0.23.0 (2026-04-29)

Full Changelog: [v0.22.1...v0.23.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.22.1...v0.23.0)

### Features

* **compute:** support curated binder specs ([a2cd2eb](https://github.com/boltz-bio/boltz-compute-api-python/commit/a2cd2eb627d324d23900b21d338cbf7b29d1e673))

## 0.22.1 (2026-04-28)

Full Changelog: [v0.22.0...v0.22.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.22.0...v0.22.1)

### Bug Fixes

* **experiments:** align result path tracking with CLI ([#63](https://github.com/boltz-bio/boltz-compute-api-python/issues/63)) ([debdf68](https://github.com/boltz-bio/boltz-compute-api-python/commit/debdf68751b067e471e14c4d3b960d84d03203ac))


### Refactors

* **client:** isolate experiments hook ([#61](https://github.com/boltz-bio/boltz-compute-api-python/issues/61)) ([1f3c212](https://github.com/boltz-bio/boltz-compute-api-python/commit/1f3c2127c88393858a700e2c358e82967fe85842))

## 0.22.0 (2026-04-28)

Full Changelog: [v0.21.1...v0.22.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.21.1...v0.22.0)

### Features

* **compute-api:** add CLI version metadata endpoint ([2d801d1](https://github.com/boltz-bio/boltz-compute-api-python/commit/2d801d1a6e2c1d85d311412642ab22aa5734a953))
* support setting headers via env ([ad443c8](https://github.com/boltz-bio/boltz-compute-api-python/commit/ad443c88661f3dbc55c6b03b9e21dbdb5f5d94de))


### Bug Fixes

* use correct field name format for multipart file arrays ([a9fb66b](https://github.com/boltz-bio/boltz-compute-api-python/commit/a9fb66bf2e2d3fdf07a35f96b5fd08b8762bffed))

## 0.21.1 (2026-04-27)

Full Changelog: [v0.21.0...v0.21.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.21.0...v0.21.1)

### Bug Fixes

* keep experiments import out of generated sort ([4179988](https://github.com/boltz-bio/boltz-compute-api-python/commit/41799881dbc882beb7b28b0d589175f8deaa6bfc))
* **stainless:** expose auth context as auth me ([b7ec7dd](https://github.com/boltz-bio/boltz-compute-api-python/commit/b7ec7ddd7874d1a09a3be69d3e4bf13744dbcd21))

## 0.21.0 (2026-04-27)

Full Changelog: [v0.20.2...v0.21.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.20.2...v0.21.0)

### Features

* **compute-api:** add auth context endpoint ([745f29e](https://github.com/boltz-bio/boltz-compute-api-python/commit/745f29e36fab4e5cb7b4635586a123474e5f2491))


### Bug Fixes

* **compute-api:** make design motifs optional ([f5cd32f](https://github.com/boltz-bio/boltz-compute-api-python/commit/f5cd32f30087d87cba946fbf34318509ebb7621b))

## 0.20.2 (2026-04-24)

Full Changelog: [v0.20.1...v0.20.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.20.1...v0.20.2)

### Bug Fixes

* **backend:** narrow hydrophobic set to "very hydrophobic" residues ([bb23f0d](https://github.com/boltz-bio/boltz-compute-api-python/commit/bb23f0d4f6d8d209a3c755ffddf86338523e2d69))

## 0.20.1 (2026-04-23)

Full Changelog: [v0.20.0...v0.20.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.20.0...v0.20.1)

### Chores

* **internal:** more robust bootstrap script ([88610d2](https://github.com/boltz-bio/boltz-compute-api-python/commit/88610d23c46ea32d329acc7421b5aa3874c59877))

## 0.20.0 (2026-04-23)

Full Changelog: [v0.19.2...v0.20.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.19.2...v0.20.0)

### Features

* [codex] Add Baseten ADME model and public prediction API ([ff901d3](https://github.com/boltz-bio/boltz-compute-api-python/commit/ff901d320f0b4e61d595ba0c7d41717e8dff355d))
* **compute-api:** prefix structure-binding ids with sab_pred ([d70cb14](https://github.com/boltz-bio/boltz-compute-api-python/commit/d70cb1490a5997f8ae1da19c7d69d6383cb7c171))


### Bug Fixes

* **compute-api:** hide ADME from small-molecule results ([d9286de](https://github.com/boltz-bio/boltz-compute-api-python/commit/d9286de34eb8962ead94f9d14f1562925309a406))

## 0.19.2 (2026-04-22)

Full Changelog: [v0.19.1...v0.19.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.19.1...v0.19.2)

### Bug Fixes

* **compute-api:** replace unsafe application schema ([4496ced](https://github.com/boltz-bio/boltz-compute-api-python/commit/4496ced42862308b20976ff92453a68044a5928e))

## 0.19.1 (2026-04-22)

Full Changelog: [v0.19.0...v0.19.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.19.0...v0.19.1)

### Bug Fixes

* **compute-api:** default omitted polymer modifications ([98cdd2c](https://github.com/boltz-bio/boltz-compute-api-python/commit/98cdd2cb0651eec53f1c2c1b9b6a8a5d246d9487))

## 0.19.0 (2026-04-21)

Full Changelog: [v0.18.1...v0.19.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.18.1...v0.19.0)

### ⚠ BREAKING CHANGES

* **compute-api:** rename pipeline route params to id

### Features

* **compute:** accept user OAuth bearer tokens ([12b3b86](https://github.com/boltz-bio/boltz-compute-api-python/commit/12b3b8620bdccabc0d74d69e868c75c0e40e5c68))


### Refactors

* **compute-api:** rename pipeline route params to id ([8e4ec8e](https://github.com/boltz-bio/boltz-compute-api-python/commit/8e4ec8e86866b03b7a9bf689c7c4243f68ec27b1))

## 0.18.1 (2026-04-21)

Full Changelog: [v0.18.0...v0.18.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.18.0...v0.18.1)

## 0.18.0 (2026-04-21)

Full Changelog: [v0.17.3...v0.18.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.17.3...v0.18.0)

### Features

* **billing:** attribute usage by product category ([db4eb86](https://github.com/boltz-bio/boltz-compute-api-python/commit/db4eb86d6dbdd8b25ba005b36495f7341840e956))


### Bug Fixes

* **compute-api:** support SM target bonds and constraints ([ee17fe1](https://github.com/boltz-bio/boltz-compute-api-python/commit/ee17fe18e5227a4fb161091e396eceb1e53e6412))

## 0.17.3 (2026-04-20)

Full Changelog: [v0.17.2...v0.17.3](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.17.2...v0.17.3)

### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([3c5865d](https://github.com/boltz-bio/boltz-compute-api-python/commit/3c5865de34b2c7e4f38fef134288a3e4e11dc116))


### Chores

* configure new SDK language ([162fe61](https://github.com/boltz-bio/boltz-compute-api-python/commit/162fe6187d44cc757507f6f47d35798cae8555c9))

## 0.17.2 (2026-04-13)

Full Changelog: [v0.17.1...v0.17.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.17.1...v0.17.2)

### Bug Fixes

* **compute-api:** tighten public schema names and bounds ([045d880](https://github.com/boltz-bio/boltz-compute-api-python/commit/045d880328424026a014b824c0c912e36b5fb7e7))

## 0.17.1 (2026-04-13)

Full Changelog: [v0.17.0...v0.17.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.17.0...v0.17.1)

### Bug Fixes

* **compute-api:** rename public binding contract terms ([5a6fc99](https://github.com/boltz-bio/boltz-compute-api-python/commit/5a6fc99d6211ef34fbd8bb4c31258e1fffeb8cd5))

## 0.17.0 (2026-04-12)

Full Changelog: [v0.16.1...v0.17.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.16.1...v0.17.0)

### Features

* [codex] Normalize pLDDT outputs ([33d5fc5](https://github.com/boltz-bio/boltz-compute-api-python/commit/33d5fc5fdf8e68db1ab61551b4c8b9182ab0d1b8))

## 0.16.1 (2026-04-12)

Full Changelog: [v0.16.0...v0.16.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.16.0...v0.16.1)

### Chores

* **stainless:** align SDK package and publish config ([624ada3](https://github.com/boltz-bio/boltz-compute-api-python/commit/624ada3277ae30c7052c30db22f316d58752ee90))

## 0.16.0 (2026-04-11)

Full Changelog: [v0.15.5...v0.16.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.15.5...v0.16.0)

### Features

* add scientist workflow experiments namespace ([#40](https://github.com/boltz-bio/boltz-compute-api-python/issues/40)) ([cd029ab](https://github.com/boltz-bio/boltz-compute-api-python/commit/cd029ab923edcb1329dd907f3577a4852b5201d7))


### Bug Fixes

* **auth:** preserve inactivity timeout behavior ([733ad86](https://github.com/boltz-bio/boltz-compute-api-python/commit/733ad868f0c10094c9685174845cc82ea23933f2))
* ensure file data are only sent as 1 parameter ([7c3c276](https://github.com/boltz-bio/boltz-compute-api-python/commit/7c3c27671d0f3504194137f4b5e9817b23f3c1ad))
* **validation:** keep Fastify 400s out of Datadog ([71b9bbb](https://github.com/boltz-bio/boltz-compute-api-python/commit/71b9bbbdf311451d308a610049c6c722524f202d))

## 0.15.5 (2026-04-08)

Full Changelog: [v0.15.4...v0.15.5](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.15.4...v0.15.5)

### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([3b5128e](https://github.com/boltz-bio/boltz-compute-api-python/commit/3b5128e5c1da064d98bce8d35d1a218a48b098f6))

## 0.15.4 (2026-04-06)

Full Changelog: [v0.15.3...v0.15.4](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.15.3...v0.15.4)

### Chores

* update SDK settings ([ca2fa88](https://github.com/boltz-bio/boltz-compute-api-python/commit/ca2fa8812636d61ce34a54c660318b352082b2e8))

## 0.15.3 (2026-04-06)

Full Changelog: [v0.15.2...v0.15.3](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.15.2...v0.15.3)

### Chores

* remove custom code ([e6076fc](https://github.com/boltz-bio/boltz-compute-api-python/commit/e6076fcce6632aff698ca6d851ac4f547f6e3a7a))

## 0.15.2 (2026-04-06)

Full Changelog: [v0.15.1...v0.15.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.15.1...v0.15.2)

### Bug Fixes

* **compute-api:** rename DesignedProteinEntity.sequence to .value ([1518e5c](https://github.com/boltz-bio/boltz-compute-api-python/commit/1518e5c7f63f320ba8a16cd8b816df8fa866194b))


### Chores

* remove custom code ([9895ddd](https://github.com/boltz-bio/boltz-compute-api-python/commit/9895ddd6253bcb3bdb6ae0583d9e968cc8a0aa1b))

## 0.15.1 (2026-03-30)

Full Changelog: [v0.15.0...v0.15.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.15.0...v0.15.1)

### Bug Fixes

* **compute-api:** build public output layer with correct metrics and multi-sample support ([1cb5ae9](https://github.com/boltz-bio/boltz-compute-api-python/commit/1cb5ae9372fd1d5ff61ce5c83f80f1e18235716e))

## 0.15.0 (2026-03-27)

Full Changelog: [v0.14.2...v0.15.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.14.2...v0.15.0)

### Features

* **internal:** implement indices array format for query and form serialization ([161c632](https://github.com/boltz-bio/boltz-compute-api-python/commit/161c6323d3f28eb9cbc87c8f05bafa7d13b20c71))

## 0.14.2 (2026-03-25)

Full Changelog: [v0.14.1...v0.14.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.14.1...v0.14.2)

### Chores

* **ci:** skip lint on metadata-only changes ([b7e0cc3](https://github.com/boltz-bio/boltz-compute-api-python/commit/b7e0cc31a22777da4d1b4b68970393ba7698c8ff))
* remove custom code ([feccef2](https://github.com/boltz-bio/boltz-compute-api-python/commit/feccef2d7c8aeba26f99a695e5aec20fc84e2c4e))
* update SDK settings ([3b2f110](https://github.com/boltz-bio/boltz-compute-api-python/commit/3b2f1104ec8e4c8de37b506c0c6f261558e969cb))
* update SDK settings ([b881fac](https://github.com/boltz-bio/boltz-compute-api-python/commit/b881facdf8d34f543ba92a85fc11d92438b38f65))
* update SDK settings ([08d114c](https://github.com/boltz-bio/boltz-compute-api-python/commit/08d114c915c0bc4bd4ec5123a7bc5bd291752996))

## 0.14.1 (2026-03-24)

Full Changelog: [v0.14.0...v0.14.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.14.0...v0.14.1)

### Refactors

* **common-backend:** split schema compiler into runtime validation + build-time OpenAPI ([d980e8c](https://github.com/boltz-bio/boltz-compute-api-python/commit/d980e8c40a500778c5d3de09a596db5893efec60))

## 0.14.0 (2026-03-24)

Full Changelog: [v0.13.1...v0.14.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.13.1...v0.14.0)

### Features

* **compute-api:** enforce registry-driven type safety across full pipeline lifecycle ([3d431a4](https://github.com/boltz-bio/boltz-compute-api-python/commit/3d431a46482a3a3247b3bb05cb92b78500074dda))

## 0.13.1 (2026-03-24)

Full Changelog: [v0.13.0...v0.13.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.13.0...v0.13.1)

### Chores

* **internal:** update gitignore ([45eb143](https://github.com/boltz-bio/boltz-compute-api-python/commit/45eb1436fa9b5a299ccf384f98fe5f683f7acc0f))

## 0.13.0 (2026-03-21)

Full Changelog: [v0.12.0...v0.13.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.12.0...v0.13.0)

### Features

* **compute-api:** upload CIF blobs to S3, harden delete-data and data-retention ([fefd98a](https://github.com/boltz-bio/boltz-compute-api-python/commit/fefd98a9fe90a79806837188ae6aafe39bd94a76))

## 0.12.0 (2026-03-21)

Full Changelog: [v0.11.0...v0.12.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.11.0...v0.12.0)

### Features

* **compute-api:** add prediction stub routes and share schema compiler ([bb56e56](https://github.com/boltz-bio/boltz-compute-api-python/commit/bb56e566cdd532e6e0ce8f32dd90c5a1e6b3adf1))
* **compute-api:** admin API, internal provisioning & auth enforcement ([1fbf75b](https://github.com/boltz-bio/boltz-compute-api-python/commit/1fbf75b4659973229292da5ef7baafdb72c4842a))
* **compute-api:** refine workspace model + wire workspace_id into compute schemas ([2baeba6](https://github.com/boltz-bio/boltz-compute-api-python/commit/2baeba64eb78200c6045f784f18f5de64cb890f7))
* **compute-api:** separate input/response schemas and refine API types ([bc2e3f8](https://github.com/boltz-bio/boltz-compute-api-python/commit/bc2e3f8142f973688ce0d2b7b5946c2b90975dc0))


### Bug Fixes

* **compute-api:** update Stainless config for health check and admin API ([d0ccc8f](https://github.com/boltz-bio/boltz-compute-api-python/commit/d0ccc8f08e99f6476b3de4ecdb64b95d18b7465a))


### Chores

* **compute-api:** add Stainless pagination config and OpenAPI examples ([19fe01a](https://github.com/boltz-bio/boltz-compute-api-python/commit/19fe01a868605f1bb585478168e93e018826b3bd))
* **compute-api:** configure Stainless SDK/docs and unify error schema ([a66b30a](https://github.com/boltz-bio/boltz-compute-api-python/commit/a66b30aa83d9f24c5291c05fecd004edd735c13f))
* **compute-api:** improve Stainless SDK naming, ordering, and docs ([e32730c](https://github.com/boltz-bio/boltz-compute-api-python/commit/e32730c2fcbf125f1bf378083e54ef2897826a7d))
* format all `api.md` files ([60b8ae5](https://github.com/boltz-bio/boltz-compute-api-python/commit/60b8ae5610254f72e61be4785508a734f70c5cba))
* **internal:** fix lint error on Python 3.14 ([6506bb2](https://github.com/boltz-bio/boltz-compute-api-python/commit/6506bb2749cff7e309d5a6110cc9c3d47684438f))
* update SDK settings ([1941f7c](https://github.com/boltz-bio/boltz-compute-api-python/commit/1941f7c17ec69bbd4f84baff0a9b0b4fa507bcb9))
* update SDK settings ([83f6091](https://github.com/boltz-bio/boltz-compute-api-python/commit/83f60913210cc981dc9e6b7645b6cbc7a4eadc78))


### Refactors

* **compute-api:** restructure API types to 2-file-per-workflow pattern ([8d6ebe0](https://github.com/boltz-bio/boltz-compute-api-python/commit/8d6ebe0a11434fd9265db7f1fb66d2e4656dcbeb))

## 0.11.0 (2026-03-21)

Full Changelog: [v0.10.2...v0.11.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.10.2...v0.11.0)

### Features

* **compute-api:** billing entitlement, per-prediction billing, and estimate-cost improvements ([7a0eea2](https://github.com/boltz-bio/boltz-compute-api-python/commit/7a0eea21bf63ea34e52d5cb47cfa62a3668710aa))

## 0.10.2 (2026-03-20)

Full Changelog: [v0.10.1...v0.10.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.10.1...v0.10.2)

### Bug Fixes

* sanitize endpoint path params ([96a2da5](https://github.com/boltz-bio/boltz-compute-api-python/commit/96a2da5e1839bca936acbfce0e10cf3939871ae8))

## 0.10.1 (2026-03-19)

Full Changelog: [v0.10.0...v0.10.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.10.0...v0.10.1)

### Bug Fixes

* **compute-api:** align screen progress semantics ([481a07b](https://github.com/boltz-bio/boltz-compute-api-python/commit/481a07bbfefecf50f9067402a8193c7f5eb54e4e))

## 0.10.0 (2026-03-19)

Full Changelog: [v0.9.1...v0.10.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.9.1...v0.10.0)

### Features

* **compute-api:** implement small molecule screen pipeline ([f597233](https://github.com/boltz-bio/boltz-compute-api-python/commit/f597233b35577cf9b4d4b79b4eb4caa6955256bc))

## 0.9.1 (2026-03-17)

Full Changelog: [v0.9.0...v0.9.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.9.0...v0.9.1)

### Bug Fixes

* **deps:** bump minimum typing-extensions version ([599f291](https://github.com/boltz-bio/boltz-compute-api-python/commit/599f291d4d638c9bbae074aba35bd979b31719df))
* **pydantic:** do not pass `by_alias` unless set ([d62c52b](https://github.com/boltz-bio/boltz-compute-api-python/commit/d62c52b9ee526d8bb987023b71ac8ffe1c425462))


### Chores

* **internal:** tweak CI branches ([9d14f0a](https://github.com/boltz-bio/boltz-compute-api-python/commit/9d14f0a0e4c1fb48810281cad8e95aacb826b061))

## 0.9.0 (2026-03-14)

Full Changelog: [v0.8.8...v0.9.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.8...v0.9.0)

### Features

* **compute-api:** add data retention sweep and enforce canonical S3 paths ([5ee41fd](https://github.com/boltz-bio/boltz-compute-api-python/commit/5ee41fd30151092e11aac8bc1d23e8c76a0c0b5d))

## 0.8.8 (2026-03-08)

Full Changelog: [v0.8.7...v0.8.8](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.7...v0.8.8)

### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([5a40f5a](https://github.com/boltz-bio/boltz-compute-api-python/commit/5a40f5a0b299b6c5a81b306076c6c01fbbe0807c))

## 0.8.7 (2026-03-05)

Full Changelog: [v0.8.6...v0.8.7](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.6...v0.8.7)

### Bug Fixes

* **compute-api:** rename model boltz-2 to boltz-2.1, update versions ([2ce7ccd](https://github.com/boltz-bio/boltz-compute-api-python/commit/2ce7ccd61d5a05166ef56ccb59fc2567ff4afc03))

## 0.8.6 (2026-03-04)

Full Changelog: [v0.8.5...v0.8.6](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.5...v0.8.6)

### Chores

* update SDK settings ([bcbe97d](https://github.com/boltz-bio/boltz-compute-api-python/commit/bcbe97dde59f55efccd2fb9db78a8ac8be79ee40))

## 0.8.5 (2026-03-04)

Full Changelog: [v0.8.4...v0.8.5](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.4...v0.8.5)

### Chores

* **internal:** refactor authentication internals ([b0e2781](https://github.com/boltz-bio/boltz-compute-api-python/commit/b0e27813da54fc203fed4ea5198fa84b2177e723))

## 0.8.4 (2026-03-04)

Full Changelog: [v0.8.3...v0.8.4](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.3...v0.8.4)

### Chores

* enable PyPI publishing for Python SDK ([4a0876a](https://github.com/boltz-bio/boltz-compute-api-python/commit/4a0876ac44571984c67b7462980c974c61d7289b))

## 0.8.3 (2026-03-04)

Full Changelog: [v0.8.2...v0.8.3](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.2...v0.8.3)

### Chores

* rename SDK packages from boltz-compute-api to boltz-compute ([737e90f](https://github.com/boltz-bio/boltz-compute-api-python/commit/737e90fa3030fba407bddde9c93d5c2a4c92d3b4))
* update Stainless production URL to api.boltz.bio ([34c8263](https://github.com/boltz-bio/boltz-compute-api-python/commit/34c8263868fcc38f992a60d9001427b964b9e447))

## 0.8.2 (2026-03-04)

Full Changelog: [v0.8.1...v0.8.2](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.1...v0.8.2)

### Chores

* update SDK settings ([6a1ac8e](https://github.com/boltz-bio/boltz-compute-api-python/commit/6a1ac8e2e239906e0059aaad65336559d9c1dc99))

## 0.8.1 (2026-03-04)

Full Changelog: [v0.8.0...v0.8.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.8.0...v0.8.1)

### Chores

* update SDK settings ([4761a9e](https://github.com/boltz-bio/boltz-compute-api-python/commit/4761a9eca35b1343a5b60ea83940b3edd46e39ad))

## 0.8.0 (2026-02-28)

Full Changelog: [v0.7.0...v0.8.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.7.0...v0.8.0)

### Features

* **compute-api:** improve prediction response shape ([da937d1](https://github.com/boltz-bio/boltz-compute-api-python/commit/da937d12dbcf145a764191aa9116593fa9bccde0))

## 0.7.0 (2026-02-27)

Full Changelog: [v0.6.1...v0.7.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.6.1...v0.7.0)

### Features

* **compute-api:** add usage API and estimate-cost endpoints ([22778f3](https://github.com/boltz-bio/boltz-compute-api-python/commit/22778f36a795c678e21aca12c762b3c9a19811ee))
* **compute-api:** extract prediction & pipeline payloads into separate tables ([bdf3fbe](https://github.com/boltz-bio/boltz-compute-api-python/commit/bdf3fbe2d471cd9e5098596dc563df9d6868a5f2))


### Chores

* **ci:** bump uv version ([3a6b4b8](https://github.com/boltz-bio/boltz-compute-api-python/commit/3a6b4b8f963e04aaffc34b0ddc2184793eb592fd))
* **internal:** make `test_proxy_environment_variables` more resilient to env ([cd0e306](https://github.com/boltz-bio/boltz-compute-api-python/commit/cd0e306539007e7f9fbfb5982aaf1531a849e2cb))

## 0.6.1 (2026-02-24)

Full Changelog: [v0.6.0...v0.6.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.6.0...v0.6.1)

### Chores

* **internal:** add request options to SSE classes ([9264b0b](https://github.com/boltz-bio/boltz-compute-api-python/commit/9264b0bd935d987b576ab4d69fc69d28bb5c3b20))
* **internal:** make `test_proxy_environment_variables` more resilient ([3e6ebe0](https://github.com/boltz-bio/boltz-compute-api-python/commit/3e6ebe054a4ffac81af7f951d1d2ebbe4f917a71))

## 0.6.0 (2026-02-23)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.5.0...v0.6.0)

### Features

* **compute-api:** improve OpenAPI specs for SDK generation ([d3bb19e](https://github.com/boltz-bio/boltz-compute-api-python/commit/d3bb19e0906e0ccdfe2ab86bb7144999afcc8a73))
* **compute-api:** schema improvements — model renames, index optimization, cascade rules ([c071ca1](https://github.com/boltz-bio/boltz-compute-api-python/commit/c071ca16e04853f9329ecb8d0f6cb3dad9733aa2))

## 0.5.0 (2026-02-20)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.4.0...v0.5.0)

### Features

* **compute-api:** ECR repository, CI/CD pipeline, and app code ([785c856](https://github.com/boltz-bio/boltz-compute-api-python/commit/785c856cbcdccf309d7bc5af3bff9617db4c59b0))
* **compute-api:** permission system, ApiError class, HMAC-SHA256 keys ([9c681de](https://github.com/boltz-bio/boltz-compute-api-python/commit/9c681de9b1ce305b47b463f0943394fc9a72b9bd))
* **compute-api:** rename key type compute→workspace, visible default workspace ([d10c12a](https://github.com/boltz-bio/boltz-compute-api-python/commit/d10c12afe1492124cb4a39e15c0482f128fc0783))
* **compute-api:** test mode with Stripe-style livemode pattern ([42f9141](https://github.com/boltz-bio/boltz-compute-api-python/commit/42f914124acd79c0cb967db8731f4fc414786094))


### Chores

* **internal:** remove mock server code ([4ce146d](https://github.com/boltz-bio/boltz-compute-api-python/commit/4ce146d61264d563735d5ebda631b3cf0b7e33ff))
* remove custom code ([0690903](https://github.com/boltz-bio/boltz-compute-api-python/commit/0690903967f7d59cdbd3c6801687fa71bc8ec02d))
* update mock server docs ([b9a4c80](https://github.com/boltz-bio/boltz-compute-api-python/commit/b9a4c800c038503fd151376f9edd0191196b30be))


### Refactors

* **compute-api:** auth + DB→API transform layer with repository pattern ([6848185](https://github.com/boltz-bio/boltz-compute-api-python/commit/6848185eb08736349247d640624c2bb89bfa8836))

## 0.4.0 (2026-02-13)

Full Changelog: [v0.3.0...v0.4.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.3.0...v0.4.0)

### Features

* **compute-api:** refine workspace model + wire workspace_id into compute schemas ([2baeba6](https://github.com/boltz-bio/boltz-compute-api-python/commit/2baeba64eb78200c6045f784f18f5de64cb890f7))


### Chores

* **compute-api:** improve Stainless SDK naming, ordering, and docs ([e32730c](https://github.com/boltz-bio/boltz-compute-api-python/commit/e32730c2fcbf125f1bf378083e54ef2897826a7d))
* format all `api.md` files ([60b8ae5](https://github.com/boltz-bio/boltz-compute-api-python/commit/60b8ae5610254f72e61be4785508a734f70c5cba))


### Refactors

* **compute-api:** restructure API types to 2-file-per-workflow pattern ([8d6ebe0](https://github.com/boltz-bio/boltz-compute-api-python/commit/8d6ebe0a11434fd9265db7f1fb66d2e4656dcbeb))

## 0.3.0 (2026-02-12)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.2.1...v0.3.0)

### Features

* **compute-api:** separate input/response schemas and refine API types ([bc2e3f8](https://github.com/boltz-bio/boltz-compute-api-python/commit/bc2e3f8142f973688ce0d2b7b5946c2b90975dc0))

## 0.2.1 (2026-02-12)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.2.0...v0.2.1)

### Bug Fixes

* **compute-api:** update Stainless config for health check and admin API ([d0ccc8f](https://github.com/boltz-bio/boltz-compute-api-python/commit/d0ccc8f08e99f6476b3de4ecdb64b95d18b7465a))


### Chores

* **internal:** fix lint error on Python 3.14 ([6506bb2](https://github.com/boltz-bio/boltz-compute-api-python/commit/6506bb2749cff7e309d5a6110cc9c3d47684438f))

## 0.2.0 (2026-02-12)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.1.0...v0.2.0)

### Features

* **compute-api:** admin API, internal provisioning & auth enforcement ([1fbf75b](https://github.com/boltz-bio/boltz-compute-api-python/commit/1fbf75b4659973229292da5ef7baafdb72c4842a))


### Chores

* **compute-api:** add Stainless pagination config and OpenAPI examples ([19fe01a](https://github.com/boltz-bio/boltz-compute-api-python/commit/19fe01a868605f1bb585478168e93e018826b3bd))

## 0.1.0 (2026-02-11)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/boltz-bio/boltz-compute-api-python/compare/v0.0.1...v0.1.0)

### Features

* **compute-api:** add prediction stub routes and share schema compiler ([bb56e56](https://github.com/boltz-bio/boltz-compute-api-python/commit/bb56e566cdd532e6e0ce8f32dd90c5a1e6b3adf1))


### Chores

* **compute-api:** configure Stainless SDK/docs and unify error schema ([a66b30a](https://github.com/boltz-bio/boltz-compute-api-python/commit/a66b30aa83d9f24c5291c05fecd004edd735c13f))
* update SDK settings ([1941f7c](https://github.com/boltz-bio/boltz-compute-api-python/commit/1941f7c17ec69bbd4f84baff0a9b0b4fa507bcb9))
* update SDK settings ([83f6091](https://github.com/boltz-bio/boltz-compute-api-python/commit/83f60913210cc981dc9e6b7645b6cbc7a4eadc78))
