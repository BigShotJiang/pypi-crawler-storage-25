print("You can get help by visiting filereaderpy.great-site.net")

path = ""
text = ""

def read():
    with open(path, "r") as fr:
        fr.read()

def write():
    with open(path, "w") as fw:
        fw.write(text)