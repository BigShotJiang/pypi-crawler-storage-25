import os
import subprocess
import sys
import time

# Handle Windows Unicode for premium ASCII art
if sys.platform == 'win32':
    import codecs
    if sys.stdout.encoding != 'utf-8':
        sys.stdout = codecs.getwriter('utf-8')(sys.stdout.detach())

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_premium_header():
    header = r"""
\033[38;5;45m    ____     ______               __     
\033[38;5;51m   / __ \   / ____/____   ____   / /___  
\033[38;5;87m  / /_/ /  / /    / __ \ / __ \ / / __ \ 
\033[38;5;123m / _, _/  / /___ / /_/ // /_/ // / /_/ / 
\033[38;5;159m/_/ |_|   \____/ \____/ \____//_/\____/  
\033[0m
\033[36m╭──────────────────────────────────────────────────────────────────────────────────╮
│  \033[1m\033[35mR Code CLI\033[0m\033[36m - Developed by \033[1m\033[34mliskCell\033[0m\033[36m                                         │
│  \033[3m"The future of coding is here."\033[0m\033[36m                                         │
╰──────────────────────────────────────────────────────────────────────────────────╯\033[0m"""
    print(header)

def deploy():
    clear_screen()
    print_premium_header()
    
    print("\n\033[1m\033[33m[!] AUTO-DEPLOYMENT INITIATED\033[0m")
    print("\033[36m[*] Preparing to install R-Code on your system...\033[0m")
    time.sleep(1)
    
    repo_url = "https://github.com/liskCell/R-code.git"
    target_dir = os.path.join(os.path.expanduser("~"), "R-code")
    
    # Message requested by user
    print(f"\n\033[1m\033[34m[INFO]\033[0m \033[36mDeploying R-Code to: \033[1m{target_dir}\033[0m")
    
    try:
        if os.path.exists(target_dir):
            print(f"\033[33m[!] Target directory already exists. Synchronizing files...\033[0m")
            # If it exists, we try to pull updates if it's a git repo, otherwise we just continue
            try:
                subprocess.run(["git", "-C", target_dir, "pull"], check=False, capture_output=True)
            except:
                pass
        else:
            print("\033[36m[*] Cloning repository from source...\033[0m")
            subprocess.run(["git", "clone", repo_url, target_dir], check=True)
        
        print("\n\033[1m\033[32m" + "─"*82)
        print("│ [SUCCESS] R-Code has been successfully deployed and integrated into your system! │")
        print("│ Ready to revolutionize your workflow.                                            │")
        print("─"*82 + "\033[0m")
        
    except Exception as e:
        print(f"\n\033[31m[ERROR] Deployment encountered a critical error: {e}\033[0m")
        print("\033[33m[!] Please ensure Git is installed and you have an active internet connection.\033[0m")

if __name__ == "__main__":
    deploy()
