Changelog

1.3.1 
-(Hopefully) fixed warn slowing down the game.

1.2.2
-Fixed issue with smooth_blur

1.2.1
-Made smooth_blur smoother

1.2.0
-Added two new functions. smooth_blur and blocky_blur

1.1.2
-(Attempted to) Fixed issue with negative sliders

1.1.1
-Fixed minor issue

1.1.0

-Added truncation of decimals.
-Added text wrapping of text through popup_text
-Added cull_whitespace. A function that removes whitespace within an image.
-Added the ability to rotate a point about a separate point.