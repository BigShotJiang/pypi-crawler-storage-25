"""HTTP client for the SemanticEmbed cloud API."""

from __future__ import annotations

import os
import time
from typing import Any

import httpx

from .exceptions import APIError, AuthenticationError, SemanticConnectionError, NodeLimitError
from .models import DIMENSION_NAMES, RiskEntry, RiskReport, SemanticResult

DEFAULT_API_URL = "https://semanticembed-api-production.up.railway.app"
FREE_TIER_LIMIT = 50


def _resolve_key(license_key: str | None) -> str:
    """Resolve the API / license key from explicit arg, module-level, env var, or config file."""
    # 1. Explicit argument
    if license_key:
        return license_key

    # 2. Module-level attribute (set by user: semanticembed.license_key = "...")
    import semanticembed
    if getattr(semanticembed, "license_key", None):
        return semanticembed.license_key

    # 3. Environment variable
    env_key = os.environ.get("SEMANTICEMBED_LICENSE_KEY") or os.environ.get("SEMANTICEMBED_API_KEY")
    if env_key:
        return env_key

    # 4. Config file
    config_path = os.path.expanduser("~/.semanticembed/license")
    if os.path.isfile(config_path):
        with open(config_path) as f:
            key = f.read().strip()
            if key:
                return key

    # 5. No key — free tier (server will enforce 50-node limit)
    return ""


def _normalize_edges(edges: Any) -> list[list[str]]:
    """Accept tuples, lists, or dicts and normalize to [[source, target], ...]."""
    normalized = []
    for e in edges:
        if isinstance(e, dict):
            src = e.get("source") or e.get("src") or e.get("from")
            tgt = e.get("target") or e.get("tgt") or e.get("to")
            if not src or not tgt:
                raise ValueError(f"Edge dict must have 'source' and 'target' keys: {e}")
            normalized.append([str(src), str(tgt)])
        elif isinstance(e, (list, tuple)) and len(e) >= 2:
            normalized.append([str(e[0]), str(e[1])])
        else:
            raise ValueError(f"Invalid edge format: {e}")
    return normalized


def _parse_response(data: dict, elapsed_ms: float) -> SemanticResult:
    """Parse the API response into SDK models."""
    raw_embeddings = data.get("embeddings", {})
    vectors: dict[str, list[float]] = {}
    for node, emb in raw_embeddings.items():
        if isinstance(emb, dict):
            vectors[node] = [emb.get(d, 0.0) for d in DIMENSION_NAMES]
        elif isinstance(emb, list):
            vectors[node] = emb[:6]
        else:
            vectors[node] = [0.0] * 6

    risks = []
    for r in data.get("risks", []):
        risks.append(RiskEntry(
            node=r.get("node", ""),
            category=r.get("type", ""),
            severity=r.get("severity", "info"),
            description=r.get("description", ""),
            value=r.get("value", 0.0),
        ))

    metadata = data.get("metadata", {})
    graph_info = {
        "nodes": metadata.get("n_nodes", len(vectors)),
        "edges": metadata.get("n_edges", 0),
        "max_depth": metadata.get("max_depth", 0),
    }

    return SemanticResult(
        vectors=vectors,
        graph_info=graph_info,
        encoding_time_ms=elapsed_ms,
        risks=risks,
    )


_RETRYABLE_STATUS = {502, 503, 504}
_RETRY_BACKOFF_SECONDS = 0.5

# In-process LRU for encode results, keyed by frozenset of (source, target)
# pairs from the normalized edge list. Off by default — only populated when
# the caller passes `cache=True` to encode(). Survives the lifetime of the
# process; clear with clear_encode_cache().
from collections import OrderedDict
_ENCODE_CACHE: OrderedDict[frozenset, "SemanticResult"] = OrderedDict()
_ENCODE_CACHE_MAX = 64


def clear_encode_cache() -> None:
    """Empty the in-process encode result cache."""
    _ENCODE_CACHE.clear()


def _encode_cache_key(normalized: list[list[str]]) -> frozenset:
    """Order-independent cache key: frozenset of (source, target) pairs."""
    return frozenset((e[0], e[1]) for e in normalized)


def _cache_get(key: frozenset):
    if key in _ENCODE_CACHE:
        # Move to end (most-recently-used)
        _ENCODE_CACHE.move_to_end(key)
        return _ENCODE_CACHE[key]
    return None


def _cache_put(key: frozenset, result: "SemanticResult") -> None:
    _ENCODE_CACHE[key] = result
    _ENCODE_CACHE.move_to_end(key)
    while len(_ENCODE_CACHE) > _ENCODE_CACHE_MAX:
        _ENCODE_CACHE.popitem(last=False)


def _post_with_retry(
    url: str,
    headers: dict[str, str],
    payload: dict,
    timeout: float,
) -> httpx.Response:
    """POST with one retry on transient failures (connection error, read timeout, 5xx)."""
    last_exc: Exception | None = None
    for attempt in range(2):
        try:
            with httpx.Client(timeout=timeout) as client:
                resp = client.post(f"{url}/api/v1/encode", headers=headers, json=payload)
            if resp.status_code in _RETRYABLE_STATUS and attempt == 0:
                time.sleep(_RETRY_BACKOFF_SECONDS)
                continue
            return resp
        except (httpx.ConnectError, httpx.ReadTimeout) as e:
            last_exc = e
            if attempt == 0:
                time.sleep(_RETRY_BACKOFF_SECONDS)
                continue
            raise SemanticConnectionError(
                f"Could not connect to SemanticEmbed API at {url} after retry: {e}"
            ) from e
    # Loop exited without returning (exhausted retries on 5xx).
    if last_exc is not None:
        raise SemanticConnectionError(
            f"Could not connect to SemanticEmbed API at {url}: {last_exc}"
        ) from last_exc
    return resp  # last 5xx response


def encode(
    edges: list,
    *,
    license_key: str | None = None,
    api_url: str | None = None,
    timeout: float = 60.0,
    cache: bool = False,
) -> SemanticResult:
    """Encode a directed graph and return 6D structural coordinates.

    Args:
        edges: List of edges as tuples, lists, or dicts.
            Examples: [("A", "B"), ("B", "C")]
                      [{"source": "A", "target": "B"}]
        license_key: Optional API key. If not provided, checks env/config.
        api_url: Override the API endpoint (for testing).
        timeout: Request timeout in seconds.
        cache: If True, look up the result in an in-process LRU keyed on the
            edge set. Repeat calls with the same edges return immediately
            without an HTTP round trip. Cached entry is order-independent
            (``[(a,b),(b,c)]`` and ``[(b,c),(a,b)]`` hit the same entry).
            Default False to preserve existing behavior.

    Returns:
        SemanticResult with .vectors, .table, .graph_info, .risks
    """
    normalized = _normalize_edges(edges)
    if len(normalized) < 2:
        raise ValueError("Graph must have at least 2 edges.")

    if cache:
        cache_key = _encode_cache_key(normalized)
        hit = _cache_get(cache_key)
        if hit is not None:
            return hit

    key = _resolve_key(license_key)
    url = (api_url or os.environ.get("SEMANTICEMBED_API_URL") or DEFAULT_API_URL).rstrip("/")

    headers: dict[str, str] = {"Content-Type": "application/json"}
    if key:
        headers["X-API-Key"] = key

    # Count nodes for error reporting
    node_set = set()
    for e in normalized:
        node_set.add(e[0])
        node_set.add(e[1])

    # Pre-flight free-tier guard: avoid a round trip when we already know it'll 403.
    n_nodes = len(node_set)
    if not key and n_nodes > FREE_TIER_LIMIT:
        raise NodeLimitError(n_nodes, FREE_TIER_LIMIT)

    if not key and n_nodes > FREE_TIER_LIMIT * 0.8:
        import warnings
        warnings.warn(
            f"Graph has {n_nodes}/{FREE_TIER_LIMIT} free tier nodes. "
            f"Set a license key to avoid hitting the limit.",
            stacklevel=2,
        )

    payload = {"edges": normalized}

    start = time.perf_counter()
    resp = _post_with_retry(url, headers, payload, timeout)
    elapsed_ms = (time.perf_counter() - start) * 1000

    if resp.status_code == 401:
        raise AuthenticationError("Invalid API key. Check your license key or contact jeffmurr@seas.upenn.edu")
    if resp.status_code == 403:
        detail = resp.text[:300]
        # Parse node count from detail message if possible
        import re
        match = re.search(r"(\d+) nodes.*limit.*?(\d+)", detail)
        if match:
            n_nodes = int(match.group(1))
            limit = int(match.group(2))
        else:
            n_nodes = len(node_set)
            limit = FREE_TIER_LIMIT
        raise NodeLimitError(n_nodes, limit)
    if resp.status_code >= 400:
        detail = resp.text[:200]
        raise APIError(resp.status_code, detail)

    result = _parse_response(resp.json(), elapsed_ms)
    if cache:
        _cache_put(cache_key, result)
    return result


def report(result: SemanticResult) -> RiskReport:
    """Generate a structural risk report from an encoding result.

    Args:
        result: A SemanticResult from encode().

    Returns:
        RiskReport with .risks, .by_category(), .by_severity()
    """
    return RiskReport(risks=result.risks)


def encode_file(
    path: str,
    *,
    license_key: str | None = None,
    api_url: str | None = None,
    timeout: float = 60.0,
) -> SemanticResult:
    """Encode a graph from a JSON file.

    The file should contain an "edges" array with objects having
    "source" and "target" fields.

    Args:
        path: Path to a JSON file.
        license_key: Optional API key.
        api_url: Override the API endpoint.
        timeout: Request timeout in seconds.

    Returns:
        SemanticResult
    """
    import json
    with open(path) as f:
        data = json.load(f)

    edges = data.get("edges", [])
    if not edges:
        raise ValueError(f"No 'edges' array found in {path}")

    return encode(edges, license_key=license_key, api_url=api_url, timeout=timeout)


def drift(
    before: SemanticResult,
    after: SemanticResult,
    *,
    detail: bool = False,
) -> dict[str, dict[str, float | dict[str, float]]]:
    """Compare two encoding results and return per-node, per-dimension deltas.

    Args:
        before: Encoding result from the earlier version.
        after: Encoding result from the later version.
        detail: If True, return {"before": x, "after": y, "delta": d} per
            dimension instead of just the delta float.

    Returns:
        Dict mapping node names to dicts of dimension changes.
        Only nodes with changes are included.
    """
    all_nodes = set(before.vectors.keys()) | set(after.vectors.keys())
    changes: dict[str, dict] = {}

    for node in sorted(all_nodes):
        v_before = before.vectors.get(node, [0.0] * 6)
        v_after = after.vectors.get(node, [0.0] * 6)
        deltas = {}
        for i, dim in enumerate(DIMENSION_NAMES):
            delta = v_after[i] - v_before[i]
            if abs(delta) > 1e-6:
                if detail:
                    deltas[dim] = {
                        "before": round(v_before[i], 4),
                        "after": round(v_after[i], 4),
                        "delta": round(delta, 4),
                    }
                else:
                    deltas[dim] = round(delta, 4)
        if deltas:
            changes[node] = deltas

    return changes


def encode_diff(
    edges_before: list,
    edges_after: list,
    *,
    detail: bool = True,
    license_key: str | None = None,
    api_url: str | None = None,
    timeout: float = 60.0,
) -> dict[str, dict[str, dict[str, float]]]:
    """Encode two edge lists and return structural drift in one call.

    Convenience function that combines encode() + encode() + drift().

    Args:
        edges_before: Edge list for the earlier version.
        edges_after: Edge list for the later version.
        detail: If True (default), return before/after/delta per dimension.
        license_key: Optional API key.
        api_url: Override the API endpoint.
        timeout: Request timeout per encode call.

    Returns:
        Dict mapping node names to dimension changes.
    """
    result_before = encode(edges_before, license_key=license_key,
                           api_url=api_url, timeout=timeout)
    result_after = encode(edges_after, license_key=license_key,
                          api_url=api_url, timeout=timeout)
    return drift(result_before, result_after, detail=detail)


# ---------------------------------------------------------------------------
# Async surface
# ---------------------------------------------------------------------------
#
# `aencode` / `aencode_file` / `aencode_diff` mirror the sync versions:
# same preflight node-count guard, same retry-once-on-5xx logic, same
# in-process LRU cache (shared with the sync side -- a sync encode and a
# subsequent async aencode of the same edges hit the same cache entry).


async def _apost_with_retry(
    url: str,
    headers: dict[str, str],
    payload: dict,
    timeout: float,
) -> httpx.Response:
    """Async sibling of _post_with_retry. One retry on 502/503/504/ConnectError/ReadTimeout."""
    import asyncio

    last_exc: Exception | None = None
    for attempt in range(2):
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(
                    f"{url}/api/v1/encode", headers=headers, json=payload
                )
            if resp.status_code in _RETRYABLE_STATUS and attempt == 0:
                await asyncio.sleep(_RETRY_BACKOFF_SECONDS)
                continue
            return resp
        except (httpx.ConnectError, httpx.ReadTimeout) as e:
            last_exc = e
            if attempt == 0:
                await asyncio.sleep(_RETRY_BACKOFF_SECONDS)
                continue
            raise SemanticConnectionError(
                f"Could not connect to SemanticEmbed API at {url} after retry: {e}"
            ) from e
    if last_exc is not None:
        raise SemanticConnectionError(
            f"Could not connect to SemanticEmbed API at {url}: {last_exc}"
        ) from last_exc
    return resp  # last 5xx response


async def aencode(
    edges: list,
    *,
    license_key: str | None = None,
    api_url: str | None = None,
    timeout: float = 60.0,
    cache: bool = False,
) -> SemanticResult:
    """Async version of :func:`encode`.

    Identical semantics — preflight node guard, retry-on-5xx, optional
    cache (shared with the sync ``encode``). Useful inside FastAPI
    handlers, asyncio task groups, or any event-loop context.

    Example::

        import asyncio, semanticembed as se

        async def main():
            result = await se.aencode([("a", "b"), ("b", "c")], cache=True)
            print(result.table)

        asyncio.run(main())
    """
    normalized = _normalize_edges(edges)
    if len(normalized) < 2:
        raise ValueError("Graph must have at least 2 edges.")

    if cache:
        cache_key = _encode_cache_key(normalized)
        hit = _cache_get(cache_key)
        if hit is not None:
            return hit

    key = _resolve_key(license_key)
    url = (api_url or os.environ.get("SEMANTICEMBED_API_URL") or DEFAULT_API_URL).rstrip("/")

    headers: dict[str, str] = {"Content-Type": "application/json"}
    if key:
        headers["X-API-Key"] = key

    node_set: set[str] = set()
    for e in normalized:
        node_set.add(e[0])
        node_set.add(e[1])
    n_nodes = len(node_set)
    if not key and n_nodes > FREE_TIER_LIMIT:
        raise NodeLimitError(n_nodes, FREE_TIER_LIMIT)
    if not key and n_nodes > FREE_TIER_LIMIT * 0.8:
        import warnings
        warnings.warn(
            f"Graph has {n_nodes}/{FREE_TIER_LIMIT} free tier nodes. "
            f"Set a license key to avoid hitting the limit.",
            stacklevel=2,
        )

    payload = {"edges": normalized}
    start = time.perf_counter()
    resp = await _apost_with_retry(url, headers, payload, timeout)
    elapsed_ms = (time.perf_counter() - start) * 1000

    if resp.status_code == 401:
        raise AuthenticationError(
            "Invalid API key. Check your license key or contact jeffmurr@seas.upenn.edu"
        )
    if resp.status_code == 403:
        import re as _re
        detail = resp.text[:300]
        match = _re.search(r"(\d+) nodes.*limit.*?(\d+)", detail)
        if match:
            raise NodeLimitError(int(match.group(1)), int(match.group(2)))
        raise NodeLimitError(n_nodes, FREE_TIER_LIMIT)
    if resp.status_code >= 400:
        raise APIError(resp.status_code, resp.text[:200])

    result = _parse_response(resp.json(), elapsed_ms)
    if cache:
        _cache_put(cache_key, result)
    return result


async def aencode_file(
    path: str,
    *,
    license_key: str | None = None,
    api_url: str | None = None,
    timeout: float = 60.0,
    cache: bool = False,
) -> SemanticResult:
    """Async version of :func:`encode_file`."""
    import json

    with open(path) as f:
        data = json.load(f)
    edges = data.get("edges", data) if isinstance(data, dict) else data
    return await aencode(
        edges, license_key=license_key, api_url=api_url, timeout=timeout, cache=cache
    )


async def aencode_diff(
    edges_before: list,
    edges_after: list,
    *,
    detail: bool = True,
    license_key: str | None = None,
    api_url: str | None = None,
    timeout: float = 60.0,
    cache: bool = False,
) -> dict[str, dict[str, dict[str, float]]]:
    """Async version of :func:`encode_diff`. Issues both encodes in parallel."""
    import asyncio

    before_t, after_t = await asyncio.gather(
        aencode(edges_before, license_key=license_key, api_url=api_url,
                timeout=timeout, cache=cache),
        aencode(edges_after, license_key=license_key, api_url=api_url,
                timeout=timeout, cache=cache),
    )
    return drift(before_t, after_t, detail=detail)
