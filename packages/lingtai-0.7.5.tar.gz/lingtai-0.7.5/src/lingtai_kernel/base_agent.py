"""
BaseAgent — generic agent kernel with intrinsic tools and capability dispatch.

Anatomy leaf: docs/plans/drafts/2026-04-30-anatomy-tree/leaves/core/agent-state-machine/

Key concepts:
    - **5-state lifecycle**: ACTIVE, IDLE, STUCK, ASLEEP, SUSPENDED.
    - **Persistent LLM session**: each agent keeps its chat session across messages.
    - **2-layer tool dispatch**: intrinsics (built-in) + capability handlers.
    - **Opaque context**: the host app can pass any context object — the agent
      stores it but never introspects it.
    - **4 optional services**: LLM, FileIO, Mail, Logging —
      missing service auto-disables the intrinsics it backs.
"""

from __future__ import annotations

import json
import queue
import threading
import time
from pathlib import Path
from typing import Any, Callable

from .config import AgentConfig
from .state import AgentState
from .workdir import WorkingDir
from .message import Message, _make_message, MSG_REQUEST, MSG_USER_INPUT, MSG_TC_WAKE
from .intrinsics import ALL_INTRINSICS
from .prompt import SystemPromptManager
from .llm import (
    FunctionSchema,
    LLMService,
    ToolCall,
)
from .i18n import t as _t
from .logging import get_logger
from .loop_guard import LoopGuard
from .prompt import build_system_prompt, build_system_prompt_batches
from .meta_block import build_meta, render_meta
from .time_veil import now_iso, scrub_time_fields
from .session import SessionManager
from .tc_inbox import TCInbox
from .tool_executor import ToolExecutor
from .token_ledger import append_token_entry, count_main_api_calls, sum_token_ledger
from .types import UnknownToolError

logger = get_logger()


# ---------------------------------------------------------------------------
# Identity prompt section (curated prose)
# ---------------------------------------------------------------------------


def _format_stamina(seconds: float) -> str:
    """Render stamina capacity as a human-friendly duration string."""
    if seconds <= 0:
        return "no fixed limit"
    hours = seconds / 3600
    if hours >= 1:
        return f"{hours:.1f}h" if hours != int(hours) else f"{int(hours)}h"
    minutes = seconds / 60
    return f"{int(minutes)}min"


def _build_identity_section(manifest_data: dict, mailbox_name: str | None = None) -> str:
    """Render the agent's identity as curated prose for the system prompt.

    Stable across turns (no transient runtime state) so it sits in the
    cacheable prefix without invalidating cache. The `state` field is
    explicitly omitted upstream — it changes every turn.

    Returns a markdown paragraph. Empty/missing fields are silently
    omitted so the prose stays clean for minimal manifests.
    """
    name = manifest_data.get("agent_name") or "(unnamed)"
    nickname = manifest_data.get("nickname") or ""
    agent_id = manifest_data.get("agent_id") or ""
    address = manifest_data.get("address") or ""
    created = manifest_data.get("created_at") or ""
    started = manifest_data.get("started_at") or ""
    admin = manifest_data.get("admin") or {}
    stamina = manifest_data.get("stamina") or 0
    soul_delay = manifest_data.get("soul_delay")
    molt_count = manifest_data.get("molt_count", 0)

    lines: list[str] = []

    # Lead — name, nickname, id, address.
    lead = f"You are **{name}**"
    if nickname:
        lead += f" — \"{nickname}\""
    if agent_id:
        lead += f" (id `{agent_id}`)"
    lead += "."
    lines.append(lead)
    if address:
        lines.append(f"Your address is `{address}`.")

    # Origins — birth, awakening, molts.
    origins: list[str] = []
    if created:
        origins.append(f"born {created}")
    if started:
        origins.append(f"woken {started} for this session")
    if origins:
        lines.append("You were " + ", ".join(origins) + ".")
    if molt_count > 0:
        lines.append(
            f"You have undergone {molt_count} molt"
            f"{'s' if molt_count != 1 else ''} since birth."
        )

    # Admin role.
    if admin:
        flags = [k for k, v in admin.items() if v]
        if flags:
            if "nirvana" in flags:
                lines.append(
                    "You hold both **karma** and **nirvana** privileges — "
                    "you can manage and destroy other agents in this network."
                )
            elif "karma" in flags:
                lines.append(
                    "You hold **karma** privilege — "
                    "you can lull / suspend / cpr / clear other agents."
                )
            else:
                lines.append(f"You hold admin flags: {', '.join(flags)}.")

    # Resources.
    if stamina:
        lines.append(
            f"Each session lasts up to {_format_stamina(stamina)} "
            "of work before rest. Your `stamina_left_seconds` "
            "appears on every tool result."
        )
    if soul_delay is not None:
        lines.append(f"Your soul flow fires {soul_delay}s after you go idle.")
    if mailbox_name:
        lines.append(f"You receive messages via {mailbox_name}.")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# BaseAgent
# ---------------------------------------------------------------------------


class BaseAgent:
    """Generic research agent with intrinsic tools and MCP tool dispatch.

    Services (all optional):
        - ``service`` (LLMService): The brain — thinking, generating text.
        - ``file_io`` (FileIOService): File access — backs read/edit/write/glob/grep.
        - ``mail_service`` (MailService): Message transport — backs mail intrinsic.

    Missing service = intrinsics backed by it are auto-disabled.

    Subclasses customize behavior via:
        - ``_pre_request(msg)`` — transform message before LLM send
        - ``_post_request(msg, result)`` — side effects after LLM responds
        - ``_handle_message(msg)`` — message routing (must call super for processing)
        - ``_get_guard_limits()`` — per-agent loop guard limits
        - ``_PARALLEL_SAFE_TOOLS`` — set of tool names safe for concurrent execution
    """

    agent_type: str = ""

    # Tools safe for concurrent execution
    _PARALLEL_SAFE_TOOLS: set[str] = set()

    # Inbox polling interval (seconds)
    _inbox_timeout: float = 1.0

    def __init__(
        self,
        service: LLMService,
        *,
        agent_name: str | None = None,
        working_dir: str | Path,
        file_io: Any | None = None,
        mail_service: Any | None = None,
        config: AgentConfig | None = None,
        context: Any = None,
        admin: dict | None = None,
        streaming: bool = False,
        covenant: str = "",
        principle: str = "",
        procedures: str = "",
        brief: str = "",
        pad: str = "",
        comment: str = "",
    ):
        self.agent_name = agent_name  # true name (真名) — immutable once set
        self.nickname: str | None = None  # mutable alias (别名)
        self.service = service
        self._config = config or AgentConfig()
        self._context = context
        self._admin = admin or {}
        self._cancel_event = threading.Event()
        self._state = AgentState.IDLE
        self._started_at: str = ""
        self._last_usage = None  # UsageMetadata from last LLM call, for ledger
        self._created_at: str = ""
        self._uptime_anchor: float | None = None  # set in start(), None means not started

        # Working directory (caller-owned path)
        self._workdir = WorkingDir(working_dir)
        self._working_dir = self._workdir.path

        # LoggingService: always JSONL in working dir
        from .services.logging import JSONLLoggingService
        log_dir = self._working_dir / "logs"
        log_dir.mkdir(exist_ok=True)
        self._log_service = JSONLLoggingService(
            log_dir / "events.jsonl",
            ensure_ascii=self._config.ensure_ascii,
        )

        # Acquire working directory lock (10s grace for prior process cleanup)
        self._workdir.acquire_lock(timeout=10)

        # --- Wire services ---
        # FileIOService: optional, provided by Agent or host
        self._file_io = file_io

        # MailService: None means mail intrinsic disabled
        self._mail_service = mail_service

        # Covenant, principle, procedures, brief, and pad file paths
        system_dir = self._working_dir / "system"
        pad_file = system_dir / "pad.md"
        covenant_file = system_dir / "covenant.md"
        principle_file = system_dir / "principle.md"
        procedures_file = system_dir / "procedures.md"
        brief_file = system_dir / "brief.md"

        system_dir.mkdir(exist_ok=True)

        # Covenant: constructor value wins, then fall back to file on disk
        if covenant:
            covenant_file.write_text(covenant)
        elif covenant_file.is_file():
            covenant = covenant_file.read_text()

        # Principle: constructor value wins, then fall back to file on disk
        # (mirrors covenant — ensures principle survives molts even when
        # init.json omits it, and seeds the mirror on first construction).
        if principle:
            principle_file.write_text(principle)
        elif principle_file.is_file():
            principle = principle_file.read_text()

        # Procedures: same pattern as covenant/principle
        if procedures:
            procedures_file.write_text(procedures)
        elif procedures_file.is_file():
            procedures = procedures_file.read_text()

        # Brief: externally-maintained context (written by secretary agent).
        # init.json value only seeds the file if it doesn't exist yet;
        # once the secretary writes brief.md, the disk version always wins.
        if brief and not brief_file.is_file():
            brief_file.write_text(brief)
        elif brief_file.is_file():
            brief = brief_file.read_text()

        # Pad: constructor value seeds the file if it doesn't exist
        if pad and not pad_file.is_file():
            pad_file.write_text(pad)

        # Auto-load pad from file into prompt manager
        loaded_pad = ""
        if pad_file.is_file():
            loaded_pad = pad_file.read_text()

        # System prompt manager
        self._prompt_manager = SystemPromptManager()
        if principle:
            self._prompt_manager.write_section("principle", principle, protected=True)
        if covenant:
            self._prompt_manager.write_section("covenant", covenant, protected=True)
        if procedures:
            self._prompt_manager.write_section("procedures", procedures, protected=True)
        if brief:
            self._prompt_manager.write_section("brief", brief, protected=True)
        # Load existing rules from system/rules.md (survives molts, refreshes, and resumes)
        rules_md = system_dir / "rules.md"
        if rules_md.is_file():
            try:
                rules_content = rules_md.read_text().strip()
                if rules_content:
                    self._prompt_manager.write_section("rules", rules_content, protected=True)
            except OSError:
                pass
        if loaded_pad.strip():
            self._prompt_manager.write_section("pad", loaded_pad)
        if comment:
            self._prompt_manager.write_section("comment", comment)

        # Soul delay — needed before manifest build
        self._soul_delay = max(1.0, self._config.soul_delay)

        # Agent ID, created_at, and molt_count — persistent state restored
        # from the existing manifest on disk if present (resume path), or
        # freshly initialized otherwise. All three must be set BEFORE the
        # manifest write below, because _build_manifest() reads them and
        # write_manifest() will overwrite the old file.
        from datetime import datetime, timezone
        import secrets
        existing = self._workdir.read_full_manifest()
        self._agent_id: str = existing.get("agent_id", "")
        self._created_at: str = existing.get("created_at", "")
        self._molt_count: int = existing.get("molt_count", 0)
        if not self._agent_id or not self._created_at:
            now = datetime.now(timezone.utc)
            if not self._agent_id:
                self._agent_id = now.strftime("%Y%m%d-%H%M%S-") + secrets.token_hex(2)
            if not self._created_at:
                self._created_at = now.strftime("%Y-%m-%dT%H:%M:%SZ")

        # Write manifest — identity + construction recipe (no runtime state)
        self._started_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        manifest_data = self._build_manifest()
        self._workdir.write_manifest(manifest_data)

        # Auto-inject identity into system prompt from manifest, rendered as
        # curated prose. Transient runtime fields (`state`) are excluded so
        # the section sits in the cacheable prefix without breaking cache
        # every turn. The full manifest including `state` stays on disk
        # (.agent.json) and in .status.json for the TUI.
        self._prompt_manager.write_section(
            "identity",
            _build_identity_section(
                manifest_data,
                mailbox_name=getattr(self, "_mailbox_name", None),
            ),
            protected=True,
        )

        self._nap_wake = threading.Event()  # signalled to wake nap early
        self._nap_wake_reason = ""  # why the nap was woken

        # Mailbox identity — capabilities override these to change notification text.
        # _mailbox_name: human label ("email box", "gmail box")
        # _mailbox_tool: tool name for check/read instructions ("email", "gmail")
        # email.boot() overrides these to "email box"/"email" during construction;
        # MCP-provided mailbox listeners (gmail, telegram, etc) override further.
        self._mailbox_name = "email box"
        self._mailbox_tool = "email"

        # Non-intrinsic tool handlers (capabilities, MCP, add_tool)
        self._tool_handlers: dict[str, Callable[[dict], dict]] = {}
        self._tool_schemas: list[FunctionSchema] = []


        # --- Wire intrinsic tools ---
        self._intrinsics: dict[str, Callable[[dict], dict]] = {}
        self._wire_intrinsics()

        # Inbox — text-channel notifications (mail, daemon, user input)
        self.inbox: queue.Queue[Message] = queue.Queue()

        # Involuntary tool-call inbox — synthetic (call, result) pairs spliced
        # into the wire chat at safe boundaries. Soul flow is the first user.
        self._tc_inbox: TCInbox = TCInbox()

        # Tracks the most recent in-history call_id for each "single-slot"
        # source. When a tc_inbox item with replace_in_history=True drains,
        # the prior pair (if any) is removed from ChatInterface.entries
        # before the new one is appended. Cleared on molt (the wire chat is
        # rebuilt; nothing tracked survives).
        self._appendix_ids_by_source: dict[str, str] = {}

        # Map from external ref_id (e.g. mail_id) to the notif_id of a
        # currently-pending system_notification pair. Populated by
        # _enqueue_system_notification when source="email"; consumed by
        # email._read post-action hook (auto-dismiss). Voluntary
        # system(action="dismiss") in intrinsics/system.py also reverse-
        # looks up via this dict to keep it in sync. Cleared on molt.
        self._pending_mail_notifications: dict[str, str] = {}

        # Lifecycle
        self._shutdown = threading.Event()
        self._asleep = threading.Event()   # set when entering ASLEEP; cleared on wake
        self._thread: threading.Thread | None = None
        self._idle = threading.Event()
        self._idle.set()
        self._state = AgentState.IDLE
        self._sealed = False

        # Soul — inner voice
        # soul_delay initialized earlier (before manifest build).
        # Inquiry: on-demand one-shot, independent of flow.
        self._soul_prompt = ""       # non-empty during inquiry
        self._soul_oneshot = False    # True during pending inquiry
        self._soul_timer: threading.Timer | None = None
        self._insight_turn_counter: int = 0

        # Heartbeat — always-on health monitor
        self._heartbeat: float = 0.0
        self._heartbeat_thread: threading.Thread | None = None
        self._aed_start: float | None = None

        # Snapshot — periodic git commits (Time Machine)
        self._last_snapshot: float = 0.0
        self._last_gc: float = 0.0

        # Auto-fallback state: True after we've tried swapping to default_preset
        # during an AED exhaustion. One-shot per process — the next AED exhaustion
        # proceeds to ASLEEP normally.
        self._preset_fallback_attempted = False

        # Session manager — LLM session, token tracking, compaction
        self._session = SessionManager(
            llm_service=service,
            config=self._config,
            agent_name=agent_name,
            streaming=streaming,
            build_system_prompt_fn=self._build_system_prompt,
            build_tool_schemas_fn=self._build_tool_schemas,
            logger_fn=self._log,
            build_system_batches_fn=self._build_system_prompt_batches,
        )

        # Boot the psyche intrinsic — load lingtai+pad into prompt, register
        # post-molt reload. Must run AFTER _session is set up because pad/lingtai
        # load triggers _flush_system_prompt which reads _session.
        from .intrinsics import psyche as _psyche
        _psyche.boot(self)

        # Boot the email intrinsic — instantiate EmailManager, set mailbox
        # fields, start the scheduler thread.
        from .intrinsics import email as _email
        _email.boot(self)

    # ------------------------------------------------------------------
    # Intrinsic wiring
    # ------------------------------------------------------------------

    def _wire_intrinsics(self) -> None:
        """Wire kernel intrinsic tool handlers."""
        for name, info in ALL_INTRINSICS.items():
            handle_fn = info["module"].handle
            self._intrinsics[name] = lambda args, fn=handle_fn: fn(self, args)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def is_idle(self) -> bool:
        return self._idle.is_set()

    @property
    def state(self) -> AgentState:
        return self._state

    @property
    def agent_id(self) -> str:
        """Permanent birth certificate — never changes across restarts or moves."""
        return self._agent_id

    @property
    def working_dir(self) -> Path:
        """The agent's working directory."""
        return self._workdir.path

    @property
    def _chat(self) -> Any:
        """Proxy to SessionManager's chat session.

        Many parts of the codebase (intrinsics, capabilities, psyche)
        read ``self._chat`` directly — this property keeps them working.
        """
        return self._session.chat

    @_chat.setter
    def _chat(self, value: Any) -> None:
        self._session.chat = value

    @property
    def _streaming(self) -> bool:
        """Proxy to SessionManager's streaming flag."""
        return self._session.streaming

    @property
    def _token_decomp_dirty(self) -> bool:
        """Proxy to SessionManager's token decomp dirty flag."""
        return self._session.token_decomp_dirty

    @_token_decomp_dirty.setter
    def _token_decomp_dirty(self, value: bool) -> None:
        self._session.token_decomp_dirty = value

    @property
    def _interaction_id(self) -> str | None:
        """Proxy to SessionManager's interaction ID."""
        return self._session.interaction_id

    @_interaction_id.setter
    def _interaction_id(self, value: str | None) -> None:
        self._session.interaction_id = value

    @property
    def _intermediate_text_streamed(self) -> bool:
        """Proxy to SessionManager's intermediate text streamed flag."""
        return self._session.intermediate_text_streamed

    @_intermediate_text_streamed.setter
    def _intermediate_text_streamed(self, value: bool) -> None:
        self._session.intermediate_text_streamed = value

    # ------------------------------------------------------------------
    # Naming
    # ------------------------------------------------------------------

    def set_name(self, name: str) -> None:
        """Set the agent's true name (真名). Immutable once set."""
        if not name:
            raise ValueError("Agent name cannot be empty.")
        if self.agent_name is not None:
            raise RuntimeError(
                f"True name already set ({self.agent_name!r}). "
                f"True names are immutable. Use set_nickname() instead."
            )
        self.agent_name = name
        self._update_identity()

    def set_nickname(self, nickname: str) -> None:
        """Set or change the agent's nickname (别名). Mutable."""
        self.nickname = nickname or None
        self._update_identity()

    def _update_identity(self) -> None:
        """Write manifest and update identity section in system prompt.

        The system-prompt section excludes runtime-transient fields (`state`)
        to preserve prompt-cache stability. The disk manifest keeps them.
        """
        manifest_data = self._build_manifest()
        self._workdir.write_manifest(manifest_data)
        self._prompt_manager.write_section(
            "identity",
            _build_identity_section(
                manifest_data,
                mailbox_name=getattr(self, "_mailbox_name", None),
            ),
            protected=True,
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the agent's main loop thread."""
        self._sealed = True
        if self._thread and self._thread.is_alive():
            return
        self._shutdown.clear()

        # Initialize git repo in working directory (only if snapshots enabled)
        if self._config.snapshot_interval is not None:
            self._workdir.init_git()

        # Capture startup time for uptime tracking
        from datetime import datetime, timezone
        self._started_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        self._uptime_anchor = time.monotonic()

        # Export assembled system prompt to system/system.md
        self._flush_system_prompt()

        # Restore chat session and token state from filesystem if available
        chat_history_file = self._working_dir / "history" / "chat_history.jsonl"
        if chat_history_file.is_file():
            try:
                messages = [
                    json.loads(line)
                    for line in chat_history_file.read_text().splitlines()
                    if line.strip()
                ]
                self.restore_chat({"messages": messages})
                self._log("session_restored")
                # If a soul.flow appendix pair survived from the previous
                # process, re-track its id so the next consultation fire
                # removes it before appending its replacement.
                self._rehydrate_appendix_tracking()
            except Exception as e:
                logger.warning(f"[{self.agent_name}] Failed to restore chat history: {e}")
        # Restore token state from ledger (lifetime accumulator)
        try:
            ledger_path = self._working_dir / "logs" / "token_ledger.jsonl"
            totals = sum_token_ledger(ledger_path)
            self.restore_token_state(totals)
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Failed to restore token state from ledger: {e}")

        # Start MailService listener if configured
        if self._mail_service is not None:
            try:
                self._mail_service.listen(on_message=lambda payload: self._on_mail_received(payload))
            except RuntimeError:
                pass  # Already listening — that's fine

        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name=f"agent-{self.agent_name or self._working_dir.name}",
        )
        self._thread.start()
        self._start_heartbeat()
        # Soul cadence runs perpetually from boot — independent of state.
        self._start_soul_timer()

    def _reset_uptime(self) -> None:
        """Reset the uptime anchor for stamina tracking (used on wake from asleep)."""
        self._uptime_anchor = time.monotonic()

    def stop(self, timeout: float = 5.0) -> None:
        """Signal shutdown and wait for the agent thread to exit."""
        self._log("agent_stop")
        self._stop_heartbeat()
        self._cancel_soul_timer()
        self._shutdown.set()
        if self._thread:
            self._thread.join(timeout=timeout)
        self._session.close()

        # Stop MailService if configured
        if self._mail_service is not None:
            try:
                self._mail_service.stop()
            except Exception:
                pass

        # Close LoggingService if configured
        if self._log_service is not None:
            try:
                self._log_service.close()
            except Exception:
                pass

        # Pad is disk-authoritative — psyche._pad_edit writes it on every edit.
        # No need to flush from prompt manager state at stop().

        # Persist final state and release lock
        self._workdir.write_manifest(self._build_manifest())
        self._workdir.release_lock()

    def _on_mail_received(self, payload: dict) -> None:
        """Callback for MailService — route incoming mail to inbox.

        This method is never replaced — it is the stable entry point for all
        incoming mail. Lifecycle control (interrupt, sleep, lull, cpr, nirvana)
        is handled by the system intrinsic via signal files, not mail.
        """
        self._on_normal_mail(payload)

    def _on_normal_mail(self, payload: dict) -> None:
        """Handle a normal mail — notify agent via inbox.

        The message is already persisted to mailbox/inbox/ by MailService.
        This method signals arrival and sends a uniform push notification.
        Capabilities configure ``_mailbox_name`` and ``_mailbox_tool``
        to change the notification text (e.g. "email box" / "email").
        """
        from .intrinsics.email import _new_mailbox_id

        email_id = payload.get("_mailbox_id") or _new_mailbox_id()
        address = payload.get("from", "unknown")
        identity = payload.get("identity")
        name = address
        if identity and identity.get("agent_name"):
            name = identity["agent_name"]
        subject = payload.get("subject", "(no subject)")
        message = payload.get("message", "")
        sent_at = payload.get("sent_at") or payload.get("time") or ""

        self._wake_nap("mail_arrived")

        if len(message) > 500:
            preview = message[:500].replace("\n", " ") + f"... ({len(message) - 500} more chars)"
        else:
            preview = message.replace("\n", " ")
        notification = _t(
            self._config.language, "system.new_mail",
            box=self._mailbox_name, address=address, name=name, subject=subject,
            sent_at=sent_at, preview=preview, tool=self._mailbox_tool,
        )

        self._log("mail_received", address=address, name=name, subject=subject, message=message)
        # Route the arrival as a synthetic system(action="notification") pair
        # via tc_inbox. Replaces the older MSG_REQUEST text-channel delivery.
        # email_id is the stable mail_id used for action-coupled dismissal in
        # intrinsics/email._read.
        self._enqueue_system_notification(
            source="email",
            ref_id=email_id,
            body=notification,
        )

    # ------------------------------------------------------------------
    # Public addon API
    # ------------------------------------------------------------------

    @property
    def working_dir(self) -> Path:
        """The agent's working directory (read-only)."""
        return self._working_dir

    def wake(self, reason: str) -> None:
        """Wake the agent from nap. Call when external input arrives."""
        self._wake_nap(reason)

    def log(self, event_type: str, **fields) -> None:
        """Write a structured event to the agent's event log."""
        self._log(event_type, **fields)

    def _enqueue_system_notification(
        self, *, source: str, ref_id: str, body: str
    ) -> str:
        """Synthesize a ``system(action="notification")`` tool-call pair and
        enqueue it on ``tc_inbox`` for splicing at the next safe boundary.

        Drains via ``_drain_tc_inbox`` (busy path) or ``_handle_tc_wake``
        (idle path). Each notification is its own pair (no coalescing),
        append-only (``replace_in_history=False``); dismissal is voluntary
        (agent calls ``system(action="dismiss", ids=[...])``) or action-
        coupled (``email.read`` auto-dismisses for ``source="email"``).

        Args:
            source: "email", "email.bounce", "daemon", "mcp.<name>", etc.
                Opaque to the kernel except for the "email" auto-dismiss
                hook in ``intrinsics.email._read``.
            ref_id: External reference (mail_id for email arrival, the
                bounced message id for bounce, etc.).
            body: The localized prose that becomes the ``ToolResultBlock``
                content (what the LLM reads).

        Returns:
            The ``notif_id`` (stable, agent-facing handle) — callers that
            need to record a ref_id-to-notif_id mapping use this.
        """
        import secrets
        from datetime import datetime, timezone
        from .llm.interface import ToolCallBlock, ToolResultBlock
        from .tc_inbox import InvoluntaryToolCall
        from .message import _make_message, MSG_TC_WAKE

        notif_id = f"notif_{int(time.time()*1000):x}_{secrets.token_hex(3)}"
        call_id = f"sn_{int(time.time()*1000):x}_{secrets.token_hex(2)}"
        received_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        call = ToolCallBlock(
            id=call_id,
            name="system",
            args={
                "action": "notification",
                "notif_id": notif_id,
                "source": source,
                "ref_id": ref_id,
                "received_at": received_at,
            },
        )
        result = ToolResultBlock(id=call_id, name="system", content=body)
        item = InvoluntaryToolCall(
            call=call,
            result=result,
            source=f"system.notification:{notif_id}",
            enqueued_at=time.time(),
            coalesce=False,
            replace_in_history=False,
        )
        self._tc_inbox.enqueue(item)

        # Track for action-coupled auto-dismiss (email source only).
        if source == "email":
            self._pending_mail_notifications[ref_id] = notif_id

        self._log(
            "system_notification_enqueued",
            notif_id=notif_id,
            call_id=call_id,
            source=source,
            ref_id=ref_id,
        )
        self._wake_nap("system_notification_enqueued")
        try:
            wake_msg = _make_message(MSG_TC_WAKE, "system", "")
            self.inbox.put(wake_msg)
        except Exception as e:
            self._log(
                "tc_wake_post_error",
                source=source,
                ref_id=ref_id,
                error=str(e)[:200],
            )

        return notif_id

    def notify(self, sender: str, text: str) -> None:
        """Put a system notification into the agent's inbox.

        This is the primary way addons inform the agent about external events.
        The message appears in the agent's conversation as a system message.
        """
        msg = _make_message(MSG_REQUEST, sender, text)
        self.inbox.put(msg)

    def _set_state(self, new_state: AgentState, reason: str = "") -> None:
        """Transition to a new state.

        State no longer drives the soul cadence timer — the timer runs
        perpetually on a wall clock (started at boot, cancelled at
        shutdown / sleep). Only the idle event flag is updated here.
        """
        old = self._state
        if old == new_state:
            return
        self._state = new_state
        if new_state == AgentState.ACTIVE:
            self._idle.clear()
        else:
            self._idle.set()
        self._log("agent_state", old=old.value, new=new_state.value, reason=reason)
        self._workdir.write_manifest(self._build_manifest())

    def _start_soul_timer(self) -> None:
        """Start the soul cadence timer.

        Runs perpetually — fires every ``_soul_delay`` seconds regardless of
        agent state, reschedules itself in the timer callback. Stops only on
        shutdown or when explicitly cancelled (e.g. when entering ASLEEP).

        The cadence model means soul flow surfaces on a wall clock, not when
        the agent goes idle. Busy agents still get reflection; rest is no
        longer a precondition for the inner voice.
        """
        if self._shutdown.is_set():
            return
        self._cancel_soul_timer()
        self._soul_timer = threading.Timer(self._soul_delay, self._soul_whisper)
        self._soul_timer.daemon = True
        self._soul_timer.name = f"soul-{self.agent_name or self._working_dir.name}"
        self._soul_timer.start()

    def _cancel_soul_timer(self) -> None:
        """Cancel any pending soul timer."""
        if self._soul_timer is not None:
            self._soul_timer.cancel()
            self._soul_timer = None

    def _wake_nap(self, reason: str) -> None:
        """Signal the nap to wake up with a given reason."""
        self._nap_wake_reason = reason
        self._nap_wake.set()

    def _soul_whisper(self) -> None:
        """Cadence timer callback. Fires past-self consultation on the
        soul_delay wall clock, then reschedules itself.

        The consultation runs inline on this timer thread (already a
        daemon) — _run_consultation_fire spawns its own M parallel
        worker threads internally and joins them with a barrier, so this
        method blocks until they finish. Reschedule happens in the
        finally clause so the cadence keeps running even on errors.

        The work itself is delegated to _run_consultation_fire which
        builds the synthetic (call, result) pair and enqueues it on
        tc_inbox with replace_in_history=True. Splicing into the wire
        chat happens at the next safe boundary in _drain_tc_inbox.

        This replaced the legacy diary+mirror-session whisper. That old
        machinery (soul_flow, _ensure_soul_session, _trim_soul_session,
        _collect_new_diary, _save_soul_session, reset_soul_session,
        enqueue_flow_voice) was deleted from intrinsics/soul.py during
        the consultation tear-down.
        """
        self._soul_timer = None
        try:
            if self._state in (AgentState.ASLEEP, AgentState.SUSPENDED):
                self._log("soul_whisper_skipped", reason=self._state.value)
            else:
                self._run_consultation_fire()
        except Exception as e:
            self._log("soul_whisper_error", error=str(e))
        finally:
            # Perpetual cadence — reschedule unless shutting down
            self._start_soul_timer()

    def _drain_tc_inbox(self) -> None:
        """Splice queued involuntary tool-call pairs into the wire chat.

        Called at safe boundaries — top of ``_handle_request``, before the
        next ``send()`` composes its payload. The wire chat is in a clean
        state at that point: previous turn fully landed, next turn not yet
        constructed.

        Skips silently if the chat has unanswered tool_calls. Items remain
        queued for the next safe boundary; the cadence keeps firing regardless.

        Lazily creates the chat session if it's None (post-refresh, or a
        brand-new agent that hasn't processed its first request). Without
        this, the busy path would livelock alongside ``_handle_tc_wake``
        in the post-refresh asleep cycle.
        """
        if self._chat is None:
            try:
                self._session.ensure_session()
            except Exception:
                # Session creation failed; let the next safe boundary retry.
                return
        iface = self._chat.interface
        if iface.has_pending_tool_calls():
            return
        items = self._tc_inbox.drain()
        if not items:
            return
        for item in items:
            if getattr(item, "replace_in_history", False):
                # Single-slot semantics: remove any prior pair of the same
                # source from chat history before appending the new one.
                prior_id = self._appendix_ids_by_source.get(item.source)
                if prior_id is not None:
                    iface.remove_pair_by_call_id(prior_id)
                self._appendix_ids_by_source.pop(item.source, None)
            iface.add_assistant_message(content=[item.call])
            iface.add_tool_results([item.result])
            if getattr(item, "replace_in_history", False):
                self._appendix_ids_by_source[item.source] = item.call.id
        self._save_chat_history()
        self._log(
            "tc_inbox_drain",
            count=len(items),
            sources=[i.source for i in items],
        )

    def _persist_soul_entry(self, result: dict, mode: str = "flow", source: str = "agent") -> None:
        """Append a soul entry to the appropriate log file.

        NOTE: This is the inquiry-path persistence helper. Flow entries
        use the new schema written by ``_append_soul_flow_record`` instead.
        ``mode`` defaults to ``"flow"`` for backward compatibility but
        production callers should pass ``mode="inquiry"`` explicitly.
        """
        from datetime import datetime, timezone
        filename = f"soul_{mode}.jsonl"
        soul_file = self._working_dir / "logs" / filename
        soul_file.parent.mkdir(exist_ok=True)
        entry = json.dumps({
            "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "mode": mode,
            "source": source,
            "prompt": result["prompt"],
            "thinking": result["thinking"],
            "voice": result["voice"],
        }, ensure_ascii=False)
        with open(soul_file, "a") as f:
            f.write(entry + "\n")

    def _append_soul_flow_record(self, record: dict) -> None:
        """Append one record to logs/soul_flow.jsonl.

        Records carry a ``kind`` field — currently ``"fire"`` (one per
        consultation attempt, with the diary cue and source list) or
        ``"voice"`` (one per surviving voice, with the voice text and
        thinking blocks). Both link via ``fire_id`` so a single fire's
        full trace can be reconstructed by grepping that id.

        Schema is owned by the kernel; consumers (TUI panels, future
        analytics) should branch on ``kind`` and ``schema_version``.
        Best-effort — IO errors are swallowed by the caller.
        """
        soul_file = self._working_dir / "logs" / "soul_flow.jsonl"
        soul_file.parent.mkdir(exist_ok=True)
        with open(soul_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def _run_inquiry(self, question: str, source: str = "agent") -> None:
        """Run soul.inquiry and log result as insight event."""
        try:
            from .intrinsics.soul import soul_inquiry
            result = soul_inquiry(self, question)
            if result:
                self._log("insight", text=result["voice"], question=question, source=source)
                self._persist_soul_entry(result, mode="inquiry", source=source)
            else:
                self._log("insight", text="(silence)", question=question, source=source)
        except Exception as e:
            self._log("insight_error", error=str(e)[:200], question=question)

    # ------------------------------------------------------------------
    # Past-self consultation — soul flow as appendix tool-call pair
    # ------------------------------------------------------------------

    def _post_llm_call(self) -> None:
        """Post-call hook — runs after every successful main-chat LLM
        response. Owns turn-driven cadence work that should tick once
        per LLM call, independent of the wall-clock soul timer.

        Currently delegates to ``_maybe_fire_consultation`` (turn-count
        cadence for past-self consultation). Errors are logged and
        swallowed; this hook must never break the main loop.
        """
        try:
            self._maybe_fire_consultation()
        except Exception as e:
            self._log("post_llm_call_error", error=str(e)[:200])

    def _maybe_fire_consultation(self) -> None:
        """If the main-chat LLM call count hits the consultation cadence,
        kick off a fire in a daemon thread. Non-blocking.

        Cadence is set by ``config.consultation_interval`` (main-chat LLM
        calls between fires). 0 disables the turn-count trigger; the
        wall-clock timer (``_soul_delay``) keeps running independently.

        Counts ``source="main"`` entries in ``logs/token_ledger.jsonl`` —
        the canonical receipt for main-chat LLM round-trips. Fires when
        ``count > 0 and count % interval == 0``. Reading the ledger
        avoids the parallel-counter drift that came from involuntary
        tool-call splices (mail, MCP notifications, soul-flow's own
        appendix landing) ticking a shared "post-LLM-call" counter — the
        ledger is tagged at write time, so consultation/inquiry fan-out
        calls (``source="soul"``) structurally cannot pollute the count.

        Both cadences enqueue onto ``tc_inbox`` with ``coalesce=True``
        keyed by ``source="soul.flow"``, so rapid double-fires collapse
        to one queued pair (latest wins). The expensive M=1+K LLM fan-out
        still runs per fire — coalescing only deduplicates the visible
        artifact in chat history.
        """
        interval = int(getattr(self._config, "consultation_interval", 0))
        if interval <= 0:
            return
        ledger_path = self._working_dir / "logs" / "token_ledger.jsonl"
        count = count_main_api_calls(ledger_path)
        if count == 0 or count % interval != 0:
            return
        thread = threading.Thread(
            target=self._run_consultation_fire,
            daemon=True,
            name=f"consult-{self.agent_name or self._working_dir.name}",
        )
        thread.start()

    def _run_consultation_fire(self) -> None:
        """Run one consultation batch and persist the result.

        Side effects:
          - logs/events.jsonl: ``consultation_fire`` / ``consultation_fire_empty``
            / ``consultation_fire_error`` summary events keyed by ``fire_id``.
          - logs/soul_flow.jsonl (schema_version=2): one ``fire`` record
            per attempt — even on empty/error — carrying the diary cue,
            source list, and outcome. Plus one ``voice`` record per
            surviving voice with the voice text and thinking blocks. All
            linked by ``fire_id``.
          - logs/token_ledger.jsonl: per-LLM-call entries tagged
            ``source: "soul"`` (written by ``_write_soul_tokens`` inside
            ``_run_consultation``).
          - logs/chat_history.jsonl: rewritten when the drain splices the
            synthetic pair into the wire chat (handled in ``_drain_tc_inbox``).
          - tc_inbox: one item enqueued (only if voices_received > 0),
            coalesced by ``source="soul.flow"``. The synthetic pair's
            call_id matches the ``fire_id`` so consumers can cross-ref
            soul_flow.jsonl and chat_history.jsonl on the same id.

        Best-effort: any failure (LLM, persist, splice) is logged to
        events.jsonl and swallowed; consultation does not block the agent
        loop. The cadence keeps firing on its own perpetual schedule.
        """
        from datetime import datetime, timezone
        import secrets

        fire_id = f"fire_{int(time.time())}_{secrets.token_hex(2)}"
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        try:
            from .intrinsics.soul import (
                _kind_for_source,
                _render_current_diary,
                _run_consultation_batch,
                build_consultation_pair,
            )
            from .tc_inbox import InvoluntaryToolCall

            diary = _render_current_diary(self)
            voices = _run_consultation_batch(self)

            sources = [v.get("source", "unknown") for v in voices]
            outcome = "ok" if voices else "empty"

            # Fire record — written before voice records so a partial
            # crash still leaves a "we tried" trace on disk.
            try:
                self._append_soul_flow_record({
                    "kind": "fire",
                    "schema_version": 2,
                    "ts": ts,
                    "fire_id": fire_id,
                    "tc_id": fire_id,                 # synthetic pair reuses fire_id
                    "diary": diary,
                    "sources": sources,
                    "outcome": outcome,
                })
            except Exception as e:
                self._log("soul_flow_persist_error", phase="fire",
                          fire_id=fire_id, error=str(e)[:200])

            # Per-voice records.
            for v in voices:
                try:
                    src = v.get("source", "unknown")
                    self._append_soul_flow_record({
                        "kind": "voice",
                        "schema_version": 2,
                        "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                        "fire_id": fire_id,
                        "source": src,
                        "consultation_kind": _kind_for_source(src),
                        "voice": v.get("voice", ""),
                        "thinking": v.get("thinking", []),
                    })
                except Exception as e:
                    self._log(
                        "soul_flow_persist_error",
                        phase="voice",
                        fire_id=fire_id,
                        source=v.get("source", "unknown"),
                        error=str(e)[:200],
                    )

            if not voices:
                self._log("consultation_fire_empty", fire_id=fire_id)
                return

            call, result = build_consultation_pair(self, voices, tc_id=fire_id)
            self._tc_inbox.enqueue(InvoluntaryToolCall(
                call=call,
                result=result,
                source="soul.flow",
                enqueued_at=time.time(),
                coalesce=True,
                replace_in_history=True,
            ))
            # Inline voice text so the TUI can render the fire from a single
            # event without cross-referencing soul_flow.jsonl. Strip thinking
            # blocks (those live in soul_flow.jsonl for retrospective inspection)
            # and keep just (source, voice) — same shape the synthetic chat
            # appendix carries.
            voices_inline = [
                {"source": v.get("source", "unknown"), "voice": v.get("voice", "")}
                for v in voices
                if v.get("voice")
            ]
            self._log(
                "consultation_fire",
                fire_id=fire_id,
                count=len(voices),
                sources=sources,
                voices=voices_inline,
            )

            # Wake the run loop so it picks the queued pair out of tc_inbox
            # and drives it through _session.send([result]). Without this,
            # an idle agent blocks on inbox.get() and the pair only lands
            # when external mail happens to arrive. The MSG_TC_WAKE
            # message is a sentinel — _handle_tc_wake reads tc_inbox for
            # the actual payload, the message itself carries no content.
            try:
                wake_msg = _make_message(MSG_TC_WAKE, "system", "")
                self.inbox.put(wake_msg)
                self._wake_nap("soul_flow_fired")
            except Exception as e:
                self._log("tc_wake_post_error",
                          fire_id=fire_id, error=str(e)[:200])
        except Exception as e:
            self._log("consultation_fire_error",
                      fire_id=fire_id, error=str(e)[:200])
            # Try to leave a fire record marking the error so the log
            # doesn't go silent on hard failures.
            try:
                self._append_soul_flow_record({
                    "kind": "fire",
                    "schema_version": 2,
                    "ts": ts,
                    "fire_id": fire_id,
                    "tc_id": fire_id,
                    "diary": "",
                    "sources": [],
                    "outcome": "error",
                    "error": str(e)[:500],
                })
            except Exception:
                pass

    def _rehydrate_appendix_tracking(self) -> None:
        """Scan rehydrated chat history for an existing soul.flow synthetic
        pair and re-track its call_id, so the next consultation fire
        knows what to remove. Idempotent.

        Searches for the strict shape produced by build_consultation_pair:
        an assistant entry with exactly one ToolCallBlock(name="soul",
        args={"action": "flow"}) followed by a user entry with the matching
        ToolResultBlock. Tracks only the first match found; any duplicates
        beyond it are left alone (inert in history)."""
        if self._chat is None:
            return
        try:
            iface = self._chat.interface
        except Exception:
            return
        from .llm.interface import ToolCallBlock, ToolResultBlock
        entries = iface.entries
        for i in range(len(entries) - 1):
            a = entries[i]
            u = entries[i + 1]
            if a.role != "assistant" or u.role != "user":
                continue
            if len(a.content) != 1 or len(u.content) != 1:
                continue
            cblock = a.content[0]
            rblock = u.content[0]
            if not isinstance(cblock, ToolCallBlock):
                continue
            if not isinstance(rblock, ToolResultBlock):
                continue
            if cblock.name != "soul":
                continue
            if not isinstance(cblock.args, dict):
                continue
            if cblock.args.get("action") != "flow":
                continue
            if cblock.id != rblock.id:
                continue
            self._appendix_ids_by_source["soul.flow"] = cblock.id
            return

    # ------------------------------------------------------------------
    # Heartbeat — always-on health monitor (involuntary)
    # ------------------------------------------------------------------

    def _start_heartbeat(self) -> None:
        """Start the heartbeat daemon thread."""
        if self._heartbeat_thread is not None:
            return
        self._heartbeat_thread = threading.Thread(
            target=self._heartbeat_loop,
            daemon=True,
            name=f"heartbeat-{self.agent_name or self._working_dir.name}",
        )
        self._heartbeat_thread.start()
        self._log("heartbeat_start")

    def _stop_heartbeat(self) -> None:
        """Stop the heartbeat (called only by stop/shutdown)."""
        thread = self._heartbeat_thread
        self._heartbeat_thread = None  # signals the loop to exit
        if thread is not None:
            thread.join(timeout=5.0)
        hb_file = self._working_dir / ".agent.heartbeat"
        try:
            hb_file.unlink(missing_ok=True)
        except OSError:
            pass
        self._log("heartbeat_stop", heartbeat=self._heartbeat)

    def _heartbeat_loop(self) -> None:
        """Beat every 1 second. AED if agent is STUCK."""
        while self._heartbeat_thread is not None and not self._shutdown.is_set():
            # time.time() (wall clock), not time.monotonic().  This is
            # deliberate: heartbeat is written to a file and read by
            # handshake.is_alive() in a DIFFERENT process.  monotonic()
            # anchors are per-process and meaningless across PIDs — only
            # wall-clock timestamps survive the IPC boundary.  NTP jumps
            # are acceptable given the 2.0s liveness threshold.
            self._heartbeat = time.time()

            # Write heartbeat file in ALL living states (everything except SUSPENDED)
            try:
                hb_file = self._working_dir / ".agent.heartbeat"
                hb_file.write_text(str(self._heartbeat), encoding="utf-8")
            except OSError:
                pass

            # --- signal file detection ---
            interrupt_file = self._working_dir / ".interrupt"
            if interrupt_file.is_file():
                try:
                    interrupt_file.unlink()
                except OSError:
                    pass
                self._cancel_event.set()
                self._log("interrupt_received", source="signal_file")

            # .refresh = self-initiated restart (handshake: rename to .refresh.taken)
            refresh_file = self._working_dir / ".refresh"
            if refresh_file.is_file():
                taken_file = self._working_dir / ".refresh.taken"
                try:
                    refresh_file.rename(taken_file)
                except OSError:
                    pass
                self._cancel_event.set()
                self._set_state(AgentState.SUSPENDED, reason="refresh")
                self._shutdown.set()
                self._log("refresh_taken", source="signal_file")

            # .suspend = SUSPENDED (full process death, external only)
            suspend_file = self._working_dir / ".suspend"
            if suspend_file.is_file():
                try:
                    suspend_file.unlink()
                except OSError:
                    pass
                self._cancel_event.set()
                self._set_state(AgentState.SUSPENDED, reason="suspend signal")
                self._shutdown.set()
                self._log("suspend_received", source="signal_file")

            # .sleep = ASLEEP (sleep, listeners stay alive)
            sleep_file = self._working_dir / ".sleep"
            if sleep_file.is_file():
                try:
                    sleep_file.unlink()
                except OSError:
                    pass
                self._cancel_event.set()
                self._set_state(AgentState.ASLEEP, reason="sleep signal")
                self._asleep.set()
                self._log("sleep_received", source="signal_file")

            # .prompt = inject text input as [system] message
            prompt_file = self._working_dir / ".prompt"
            if prompt_file.is_file():
                try:
                    content = prompt_file.read_text().strip()
                except OSError:
                    content = ""
                try:
                    prompt_file.unlink()
                except OSError:
                    pass
                if content:
                    self.send(content, sender="system")
                    self._log("prompt_received", source="signal_file")

            # .clear = force a full molt (context wipe + recovery summary).
            # File content (optional) is a human-readable "source" tag used in
            # the summary message; empty file defaults to "admin".
            clear_file = self._working_dir / ".clear"
            if clear_file.is_file():
                try:
                    source = clear_file.read_text().strip() or "admin"
                except OSError:
                    source = "admin"
                try:
                    clear_file.unlink()
                except OSError:
                    pass
                try:
                    from .intrinsics import psyche as _psyche
                    _psyche.context_forget(self, source=source)
                    self._log("clear_received", source=source)
                except Exception as clear_err:
                    logger.error(
                        f"[{self.agent_name}] .clear signal failed: {clear_err}",
                    )

            # .inquiry = soul inquiry (from TUI /btw or auto-insight)
            # Format: first line = source, rest = question.
            # If no newline, entire content is question with source "human".
            # Flow: .inquiry → .inquiry.taken (processing) → deleted (done)
            inquiry_file = self._working_dir / ".inquiry"
            taken_file = self._working_dir / ".inquiry.taken"
            if inquiry_file.is_file() and not taken_file.is_file():
                try:
                    inquiry_file.rename(taken_file)
                except OSError:
                    pass
                else:
                    try:
                        content = taken_file.read_text().strip()
                    except OSError:
                        content = ""
                    if content:
                        lines = content.split("\n", 1)
                        if len(lines) == 2 and lines[0] in ("human", "insight", "agent"):
                            source, question = lines[0], lines[1].strip()
                        else:
                            source, question = "human", content.strip()
                        if question:
                            def _inquiry_done(q: str, s: str, tf: Path) -> None:
                                self._run_inquiry(q, source=s)
                                try:
                                    tf.unlink()
                                except OSError:
                                    pass
                            threading.Thread(
                                target=_inquiry_done,
                                args=(question, source, taken_file),
                                daemon=True,
                            ).start()
                        else:
                            try:
                                taken_file.unlink()
                            except OSError:
                                pass
                    else:
                        try:
                            taken_file.unlink()
                        except OSError:
                            pass

            # .rules = network rules signal (consumed → persisted to system/rules.md)
            self._check_rules_file()

            # Stamina enforcement — asleep when stamina expires
            if self._uptime_anchor is not None and self._state not in (AgentState.ASLEEP, AgentState.SUSPENDED):
                elapsed = time.monotonic() - self._uptime_anchor
                if elapsed >= self._config.stamina:
                    self._log("stamina_expired", elapsed=round(elapsed, 1), stamina=self._config.stamina)
                    self._cancel_event.set()
                    self._set_state(AgentState.ASLEEP, reason="stamina expired")
                    self._asleep.set()

            if self._state == AgentState.STUCK:
                now = time.monotonic()
                if self._aed_start is None:
                    self._aed_start = now
                if now - self._aed_start > self._config.aed_timeout:
                    self._log("aed_timeout", seconds=now - self._aed_start)
                    self._set_state(AgentState.ASLEEP, reason="AED timeout")
                    self._save_chat_history()
                    self._asleep.set()
            else:
                self._aed_start = None

            # Periodic snapshot (Time Machine) — off by default
            if self._config.snapshot_interval is not None:
                now_mono = time.monotonic()
                if now_mono - self._last_snapshot >= self._config.snapshot_interval:
                    self._workdir.snapshot()
                    self._last_snapshot = now_mono

                # Periodic GC — every 24 hours
                if now_mono - self._last_gc >= 86400:
                    self._workdir.gc()
                    self._last_gc = now_mono

            time.sleep(1.0)

    def _log(self, event_type: str, **fields) -> None:
        """Write a structured event to the logging service, if configured."""
        if self._log_service:
            self._log_service.log({
                "type": event_type,
                "address": self._working_dir.name,
                "agent_name": self.agent_name,
                "ts": time.time(),
                **fields,
            })

    # ------------------------------------------------------------------
    # Main loop (final — do not override)
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        """Wait for messages, process them. Agent persists between messages."""
        while True:
            while not self._shutdown.is_set():
                # --- Asleep: soul off, wait for inbox message ---
                if self._asleep.is_set():
                    self._cancel_soul_timer()
                    self._log("sleep")

                    # Block until a message arrives or shutdown
                    msg = None
                    while not self._shutdown.is_set():
                        try:
                            msg = self.inbox.get(timeout=1.0)
                            break
                        except queue.Empty:
                            continue

                    if msg is None:
                        break  # shutdown was set — exit inner loop

                    # Wake up
                    self._asleep.clear()
                    self._cancel_event.clear()  # clear stale sleep/stamina signal
                    self._set_state(AgentState.ACTIVE, reason=f"woke from asleep: {msg.type}")
                    self._log("wake", trigger=msg.type)
                    self._reset_uptime()
                    msg = self._concat_queued_messages(msg)
                    # Fall through to handle the message below
                else:
                    try:
                        msg = self.inbox.get(timeout=self._inbox_timeout)
                    except queue.Empty:
                        continue
                    msg = self._concat_queued_messages(msg)
                    self._set_state(AgentState.ACTIVE, reason=f"received {msg.type}")

                sleep_state = AgentState.IDLE
                aed_attempts = 0
                while True:
                    try:
                        self._handle_message(msg)
                        break  # success (chat saved after each session.send inside)
                    except Exception as e:
                        err_desc = str(e) or repr(e)
                        aed_attempts += 1

                        # Close any dangling tool_calls with synthetic error
                        # tool_results, preserving the assistant turn and the
                        # error context (err_desc). Without this, a subsequent
                        # add_user_message — e.g. the AED revive below —
                        # would violate the chat-completions positional
                        # invariant and strict providers (DeepSeek, OpenAI)
                        # would 400 on the next request.
                        if self._session.chat is not None:
                            self._session.chat.interface.close_pending_tool_calls(
                                reason=err_desc or "aed_recovery"
                            )

                        # NB: the `== max_aed_attempts` branch below either auto-falls-back
                        # to the default preset (returning early) or breaks to ASLEEP, so
                        # `aed_attempts > max_aed_attempts` is unreachable.

                        self._set_state(AgentState.STUCK, reason=f"AED attempt {aed_attempts}: {err_desc}")
                        self._log("aed_attempt", attempt=aed_attempts, error=err_desc)
                        logger.warning(
                            f"[{self.agent_name}] AED attempt {aed_attempts}/{self._config.max_aed_attempts}: {err_desc}",
                        )

                        # On the final allowed retry, give up and put the agent to
                        # sleep rather than force-molting. The forced molt was too
                        # aggressive — it wiped context every time a transient API
                        # error (rate limit, 400, timeout) ran out of retries,
                        # destroying durable state to recover from what is usually
                        # an external/protocol issue. Sleep lets the next inbox
                        # message (or explicit /cpr) drive recovery with context
                        # intact.
                        if aed_attempts == self._config.max_aed_attempts:
                            # Auto-fallback: if we're on a non-default preset, try swapping to
                            # default before going ASLEEP. One-shot per process — guarded by
                            # _preset_fallback_attempted so a default-preset failure proceeds normally.
                            if not self._preset_fallback_attempted and self._can_fallback_preset():
                                self._preset_fallback_attempted = True
                                self._log("preset_auto_fallback",
                                          reason=err_desc,
                                          failed_attempts=aed_attempts)
                                try:
                                    self._activate_default_preset()
                                except Exception as e:
                                    self._log("preset_auto_fallback_failed", error=str(e))
                                    # fall through to ASLEEP
                                else:
                                    # Successfully swapped — trigger refresh and let the relaunch take over
                                    self._perform_refresh()
                                    return

                            self._log("aed_exhausted", attempts=aed_attempts, error=err_desc)
                            sleep_state = AgentState.ASLEEP
                            self._asleep.set()
                            break

                        # Rebuild session with current config, preserving history
                        if self._session.chat is not None:
                            self._session._rebuild_session(self._session.chat.interface)

                        # Inject recovery message
                        ts = now_iso(self)
                        aed_msg = _t(self._config.language, "system.stuck_revive", ts=ts, tool_calls=err_desc)
                        msg = _make_message(MSG_REQUEST, "system", aed_msg)

                if not self._asleep.is_set():
                    self._set_state(sleep_state)
                self._save_chat_history()

                # Auto-insight: fire after N turns
                if self._config.insights_interval > 0:
                    self._insight_turn_counter += 1
                    if self._insight_turn_counter >= self._config.insights_interval:
                        self._insight_turn_counter = 0
                        from .i18n import t as _ti
                        self._run_inquiry(
                            _ti(self._config.language, "insight.auto_question"),
                            source="auto",
                        )

            break

    def _perform_refresh(self) -> None:
        """Refresh = .refresh handshake + deferred relaunch.

        Handshake protocol:
        1. Touch ``.refresh`` — request a refresh
        2. Heartbeat loop sees ``.refresh`` → renames to ``.refresh.taken``
           → shuts down cleanly (like suspend, but logged as refresh)
        3. Deferred watcher polls for ``.refresh.taken`` (handshake ack),
           then waits for lock file to disappear, then relaunches
        4. New process sees ``.refresh.taken`` → deletes it → sends
           "refresh successful" system message
        """
        import subprocess, sys
        self._log("refresh_start")
        self._save_chat_history()
        cmd = self._build_launch_cmd()
        if cmd is None:
            self._log("refresh_no_launch_cmd")
            return

        working_dir = self._working_dir
        (working_dir / ".refresh").touch()

        # Deferred relaunch: wait for .refresh.taken (heartbeat ack'd),
        # then wait for lock file to disappear (old process died), then
        # start new process. Gives up after 60s total.
        taken_path = str(working_dir / ".refresh.taken")
        lock_path = str(working_dir / ".agent.lock")
        events_path = str(working_dir / "logs" / "events.jsonl")
        agent_name = self.agent_name
        address = self._working_dir.name
        relaunch_script = (
            "import time, subprocess, os, sys, json\n"
            f"taken = {taken_path!r}\n"
            f"lock = {lock_path!r}\n"
            f"events = {events_path!r}\n"
            f"name = {agent_name!r}\n"
            f"addr = {address!r}\n"
            "def log(typ, **kw):\n"
            "    entry = {'type': typ, 'address': addr, 'agent_name': name, 'ts': time.time(), **kw}\n"
            "    try:\n"
            "        with open(events, 'a') as f:\n"
            "            f.write(json.dumps(entry) + '\\n')\n"
            "    except OSError:\n"
            "        pass\n"
            "deadline = time.time() + 60\n"
            # Phase 1: wait for heartbeat to ack (.refresh.taken)
            "log('refresh_watcher_start')\n"
            "while not os.path.exists(taken) and time.time() < deadline:\n"
            "    time.sleep(0.5)\n"
            "if not os.path.exists(taken):\n"
            "    log('refresh_watcher_timeout', phase='ack')\n"
            "    sys.exit(1)\n"
            "log('refresh_watcher_ack')\n"
            # Phase 2: wait for lock file to disappear (process exited)
            "while os.path.exists(lock) and time.time() < deadline:\n"
            "    time.sleep(0.5)\n"
            "if os.path.exists(lock):\n"
            "    log('refresh_watcher_timeout', phase='lock')\n"
            "    sys.exit(1)\n"
            "time.sleep(0.5)\n"  # settle time
            "log('refresh_watcher_relaunch')\n"
            f"subprocess.Popen({cmd!r},\n"
            "    stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,\n"
            "    stderr=subprocess.DEVNULL, start_new_session=True)\n"
        )
        subprocess.Popen(
            [sys.executable, "-c", relaunch_script],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        self._log("refresh_deferred_relaunch", cmd=cmd[0])

    def _activate_preset(self, name: str) -> None:
        """Swap to a named preset — override in subclasses that support presets.

        BaseAgent raises NotImplementedError; Agent (lingtai.agent) overrides
        this with the real implementation.
        """
        raise NotImplementedError(
            f"_activate_preset not supported on {type(self).__name__}"
        )

    def _can_fallback_preset(self) -> bool:
        """True if init.json has manifest.preset and active != default.

        Returns False if the umbrella is missing, fields are missing, or
        active already equals default (already on the fallback target).
        """
        import json
        try:
            data = json.loads((self._working_dir / "init.json").read_text(encoding="utf-8"))
            preset = data.get("manifest", {}).get("preset") or {}
            if not isinstance(preset, dict):
                return False
            active = preset.get("active")
            default = preset.get("default")
            return bool(active and default and active != default)
        except Exception:
            return False

    def _activate_default_preset(self) -> None:
        """Override hook — Agent subclass implements via _activate_preset(default).
        BaseAgent stub raises NotImplementedError."""
        raise NotImplementedError(
            "_activate_default_preset must be implemented by Agent subclass"
        )

    def _build_launch_cmd(self) -> list[str] | None:
        """Return the command to relaunch this agent. Override in subclasses."""
        return None

    def _concat_queued_messages(self, msg: Message) -> Message:
        """Drain any additional queued messages and concatenate into one.

        If nothing else is queued, returns the original message unchanged.
        Otherwise, joins all message contents with blank lines and returns
        a new merged message. Non-string content is converted via str().
        """
        extra: list[Message] = []
        while True:
            try:
                queued = self.inbox.get_nowait()
            except queue.Empty:
                break
            extra.append(queued)

        if not extra:
            return msg

        all_msgs = [msg] + extra
        parts = [m.content if isinstance(m.content, str) else str(m.content)
                 for m in all_msgs]
        merged_content = "\n\n".join(parts)
        merged = _make_message(MSG_REQUEST, msg.sender, merged_content)
        self._log("messages_concatenated", count=len(all_msgs))
        return merged

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    def _handle_message(self, msg: Message) -> None:
        """Route message by type. Subclasses may override for routing."""
        if msg.type in (MSG_REQUEST, MSG_USER_INPUT):
            self._handle_request(msg)
        elif msg.type == MSG_TC_WAKE:
            self._handle_tc_wake(msg)
        else:
            logger.warning(f"[{self.agent_name}] Unknown message type: {msg.type}")

    def _handle_request(self, msg: Message) -> None:
        """Send request to LLM, process response with tool calls."""
        # Splice any queued involuntary tool-call pairs (soul flow, etc.)
        # into the wire chat before composing this turn's payload. Safe
        # boundary — the previous turn has fully landed.
        self._drain_tc_inbox()

        max_calls, dup_free, dup_hard = self._get_guard_limits()
        guard = LoopGuard(
            max_total_calls=max_calls,
            dup_free_passes=dup_free,
            dup_hard_block=dup_hard,
        )
        self._executor = ToolExecutor(
            dispatch_fn=self._dispatch_tool,
            make_tool_result_fn=lambda name, result, **kw: self.service.make_tool_result(
                name, result, provider=self._config.provider, **kw
            ),
            guard=guard,
            known_tools=set(self._intrinsics) | set(self._tool_handlers),
            parallel_safe_tools=self._PARALLEL_SAFE_TOOLS,
            logger_fn=self._log,
            meta_fn=lambda: build_meta(self),
        )
        content = self._pre_request(msg)
        meta = build_meta(self)

        # Molt pressure — warn agent when context is getting full
        # Needs the psyche intrinsic to self-molt (always present after collapse)
        has_molt = "psyche" in self._intrinsics
        pressure = self._session.get_context_pressure()

        # Hard ceiling — unconditional force-wipe regardless of warning count.
        # The warning ladder can let an agent sit at elevated pressure for
        # several turns; if it keeps climbing, we need a guaranteed backstop
        # before the LLM call itself starts failing from oversized payloads.
        if pressure >= self._config.molt_hard_ceiling and has_molt:
            lang = self._config.language
            self._log("auto_forget", reason="hard ceiling", pressure=pressure, ceiling=self._config.molt_hard_ceiling)
            from .intrinsics import psyche as _psyche
            _psyche.context_forget(self)
            self._session._compaction_warnings = 0
            content = f"{_t(lang, 'system.molt_wiped')}\n\n{content}"
        elif pressure >= self._config.molt_pressure and has_molt:
            max_warnings = self._config.molt_warnings
            self._session._compaction_warnings += 1
            warnings = self._session._compaction_warnings
            remaining = max(0, max_warnings - warnings)
            lang = self._config.language
            if warnings > max_warnings:
                # Auto-forget — agent ignored all warnings
                self._log("auto_forget", reason=f"ignored {max_warnings} molt warnings", pressure=pressure)
                from .intrinsics import psyche as _psyche
                _psyche.context_forget(self)
                self._session._compaction_warnings = 0
                content = f"{_t(lang, 'system.molt_wiped')}\n\n{content}"
            else:
                # Warning ladder: level 1, 2, 3 based on accumulated warnings.
                # Clamp to level 3 in case molt_warnings is configured >3.
                # The molt procedure is in the system prompt (## procedures),
                # so warnings only need urgency framing.
                level = min(warnings, 3)
                level_prompt = _t(
                    lang,
                    f"system.molt_warning_level{level}",
                    pressure=f"{pressure:.0%}",
                    remaining=remaining,
                )
                if level >= 2:
                    level_prompt = level_prompt + "\n\n" + _t(lang, "system.molt_procedure")
                # User's custom molt_prompt (if set) wins over the default ladder
                molt_prompt = self._config.molt_prompt or level_prompt
                status = f"[context: {pressure:.0%} | {remaining}/{max_warnings}]"
                content = f"{molt_prompt}\n{status}\n\n{content}"

        prefix = render_meta(self, meta)
        if prefix:
            content = f"{prefix}\n\n{content}"
        self._log("text_input", text=content)
        response = self._session.send(content)
        self._last_usage = response.usage
        self._post_llm_call()
        self._save_chat_history()
        result = self._process_response(response)
        self._post_request(msg, result)

    def _handle_tc_wake(self, msg: Message) -> None:
        """Process queued involuntary tool-call pairs by driving them
        through the LLM as if the tools just returned — no fake user prompt.

        Triggered by ``MSG_TC_WAKE``, posted to inbox by producers that
        enqueue items on ``tc_inbox`` (soul flow, system notifications).
        Without this wake, an idle agent would block on ``inbox.get()``
        indefinitely and queued pairs would only land when an external
        message happened to arrive.

        Wire-level mechanics per item:

          1. If ``replace_in_history`` is set (soul flow uses this), remove
             any prior pair of the same source from the wire chat first.
          2. Append the synthetic assistant tool_call to the interface
             directly via ``add_assistant_message``.
          3. Call ``_session.send([result])`` — the adapter appends the
             tool_result AND fires an LLM call. From the model's POV: it
             "made a tool call, the tool returned, now react." It produces
             its next assistant turn naturally — text, more tool calls,
             whatever — without any fabricated user prompt.
          4. Process the response through the standard executor loop.

        Idempotent on a busy agent: ``_drain_tc_inbox`` runs at the top of
        every ``_handle_request``, so a soul pair that arrived mid-turn
        already got spliced silently into the interface and the user-message
        turn's LLM call saw it as context. By the time the wake handler
        runs, ``tc_inbox`` is empty and we no-op. Net cost: one LLM turn
        per *visible* fire — never extra.
        """
        items = self._tc_inbox.drain()
        if not items:
            self._log("tc_wake_noop", reason="tc_inbox_empty")
            return
        if self._chat is None:
            # Chat session not yet created. This happens after refresh (which
            # tears down _session.chat) or on a brand-new agent that hasn't
            # processed its first request. Lazily create the session here so
            # we can splice; otherwise we livelock — every soul-flow tick
            # posts MSG_TC_WAKE which lands here, bails with "chat_not_ready",
            # and re-enqueues forever (each tick adds a fresh pair to the
            # queue but nothing ever drains them). ensure_session is
            # idempotent and safe to call from the run-loop thread.
            try:
                self._session.ensure_session()
            except Exception as e:
                # Session creation failed (e.g. LLM service down). Re-enqueue
                # so a future safe boundary can retry, log the cause for
                # operator triage, and bail this attempt.
                for item in items:
                    self._tc_inbox.enqueue(item)
                self._log(
                    "tc_wake_noop",
                    reason="ensure_session_failed",
                    error=str(e)[:300],
                )
                return
        iface = self._chat.interface
        if iface.has_pending_tool_calls():
            # Mid-pair on the wire — can't splice safely. Re-enqueue and bail.
            for item in items:
                self._tc_inbox.enqueue(item)
            self._log("tc_wake_noop", reason="pending_tool_calls")
            return

        try:
            self._executor = ToolExecutor(
                dispatch_fn=self._dispatch_tool,
                make_tool_result_fn=lambda name, result, **kw: self.service.make_tool_result(
                    name, result, provider=self._config.provider, **kw
                ),
                guard=LoopGuard(
                    max_total_calls=self._config.max_turns,
                    dup_free_passes=2,
                    dup_hard_block=8,
                ),
                known_tools=set(self._intrinsics) | set(self._tool_handlers),
                parallel_safe_tools=self._PARALLEL_SAFE_TOOLS,
                logger_fn=self._log,
                meta_fn=lambda: build_meta(self),
            )
            for idx, item in enumerate(items):
                # Per-item splice (assistant tool_call → save → send →
                # process response) is wrapped in a single try so that ANY
                # failure between adding the synthetic tool_call to the
                # interface and finishing _process_response triggers orphan
                # healing. Without this, a timeout in _process_response (which
                # itself drives more LLM calls and tool dispatches) escaped
                # to the outer except and left the wire with an unanswered
                # tool_call, bricking the agent until AED could rebuild —
                # observed in lingtai-dev/mimo-v2.5 on 2026-05-02 when a
                # 300s LLM timeout happened mid-_process_response.
                try:
                    if getattr(item, "replace_in_history", False):
                        prior_id = self._appendix_ids_by_source.get(item.source)
                        if prior_id is not None:
                            iface.remove_pair_by_call_id(prior_id)
                        self._appendix_ids_by_source.pop(item.source, None)
                    iface.add_assistant_message(content=[item.call])
                    if getattr(item, "replace_in_history", False):
                        self._appendix_ids_by_source[item.source] = item.call.id
                    self._save_chat_history()

                    self._log("tc_wake_dispatch", source=item.source, call_id=item.call.id)
                    response = self._session.send([item.result])
                    self._last_usage = response.usage
                    # Tag the ledger entry source="tc_wake" — an involuntary
                    # tool-call splice (mail/MCP notification/soul-flow
                    # appendix) is not a main-chat turn, so consultation
                    # cadence (which counts source="main" ledger entries)
                    # must not see it. Deliberately NOT calling
                    # _post_llm_call() either: that hook is reserved for
                    # genuine main-chat round-trips. Tokens still land in
                    # the ledger — they're real spend — just under a
                    # different source tag.
                    self._save_chat_history(ledger_source="tc_wake")
                    self._process_response(response, ledger_source="tc_wake")
                except Exception as splice_err:
                    # Synthesize placeholder tool_results for any orphaned
                    # tool_calls left on the wire by the partial splice
                    # (same pattern AED uses). Persist, re-enqueue unprocessed
                    # remaining items so a future safe boundary can retry,
                    # and re-raise so AED sees this as a real error rather
                    # than the outer except swallowing it.
                    if iface.has_pending_tool_calls():
                        iface.close_pending_tool_calls(
                            reason=f"tc_wake splice failed: {str(splice_err)[:200]}",
                        )
                        self._save_chat_history()
                    self._log(
                        "tc_wake_send_error",
                        source=item.source,
                        call_id=item.call.id,
                        error=str(splice_err)[:300],
                    )
                    for remaining in items[idx + 1:]:
                        self._tc_inbox.enqueue(remaining)
                    raise
        except Exception as e:
            # Heal any pending orphan one more time before surfacing to AED.
            # The inner except above already heals the failing item, but a
            # later iteration or a non-splice failure (executor build, etc.)
            # may leave history dirty.
            if self._chat is not None and self._chat.interface.has_pending_tool_calls():
                self._chat.interface.close_pending_tool_calls(
                    reason=f"tc_wake outer-error heal: {str(e)[:200]}",
                )
                self._save_chat_history()
            self._log("tc_wake_error", error=str(e)[:300])
            raise

    def _get_guard_limits(self) -> tuple[int, int, int]:
        """Return (max_total_calls, dup_free_passes, dup_hard_block).

        Uses config.max_turns as the basis.
        """
        max_turns = self._config.max_turns
        return (max_turns, 2, 8)

    # ------------------------------------------------------------------
    # Response processing
    # ------------------------------------------------------------------

    def _process_response(self, response: LLMResponse, *, ledger_source: str = "main") -> dict:
        """Handle tool calls and collect text output.

        Returns a result dict: {"text": ..., "failed": ..., "errors": [...]}.

        ``ledger_source`` propagates to ``_save_chat_history`` for any
        tool-loop continuation LLM round-trips so cadence-counting
        treats them the same as the call that triggered this loop.
        Default ``"main"``; set to ``"tc_wake"`` when this method is
        invoked from an involuntary splice path.
        """
        # Clear any stale cancel event from a previous silence.
        self._cancel_event.clear()
        guard = self._executor.guard
        collected_text_parts: list[str] = []
        collected_errors: list[str] = []

        while True:
            if response.text:
                collected_text_parts.append(response.text)
                self._log("diary", text=response.text)
                if response.tool_calls:
                    self._intermediate_text_streamed = False

            if response.thoughts:
                for thought in response.thoughts:
                    self._log("thinking", text=thought)

            if not response.tool_calls:
                break

            if self._cancel_event.is_set():
                self._cancel_event.clear()
                return {"text": "", "failed": False, "errors": []}

            stop_reason = guard.check_limit(len(response.tool_calls))
            if stop_reason:
                break

            invalid_reason = guard.check_invalid_tool_limit()
            if invalid_reason:
                break

            # Delegate to ToolExecutor
            tool_results, intercepted, intercept_text = self._executor.execute(
                response.tool_calls,
                on_result_hook=self._on_tool_result_hook,
                cancel_event=self._cancel_event,
                collected_errors=collected_errors,
            )

            if intercepted:
                if tool_results and self._chat:
                    self._chat.commit_tool_results(tool_results)
                return {
                    "text": intercept_text,
                    "failed": False,
                    "errors": [],
                }

            guard.record_calls(len(response.tool_calls))

            # Break on repeated identical errors
            if (
                len(collected_errors) >= 2
                and collected_errors[-1] == collected_errors[-2]
            ):
                logger.warning(
                    "[%s] Same error repeated, breaking early: %s",
                    self.agent_name,
                    collected_errors[-1],
                )
                break

            response = self._session.send(tool_results)
            self._last_usage = response.usage
            if ledger_source == "main":
                self._post_llm_call()
            self._save_chat_history(ledger_source=ledger_source)

        final_text = "\n".join(collected_text_parts)
        has_errors = bool(collected_errors)
        no_useful_output = not final_text.strip()
        return {
            "text": final_text,
            "failed": has_errors and no_useful_output,
            "errors": collected_errors,
        }

    # ------------------------------------------------------------------
    # Tool dispatch — 2-layer
    # ------------------------------------------------------------------

    def _dispatch_tool(self, tc: ToolCall) -> dict:
        """Dispatch a tool call to the appropriate handler.

        Layer 1: intrinsics (built-in tools)
        Layer 2: MCP handlers (domain tools)

        Raises UnknownToolError if the tool name is not found.
        """
        if tc.name in self._intrinsics:
            # Inject the wire tool_use_id so intrinsics that need to locate
            # their own ToolCallBlock in the live interface (notably
            # psyche._context_molt) can find it. Intrinsics that don't care
            # simply ignore the field.
            args = dict(tc.args or {})
            args["_tc_id"] = tc.id
            return self._intrinsics[tc.name](args)
        elif tc.name in self._tool_handlers:
            return self._tool_handlers[tc.name](tc.args or {})
        else:
            raise UnknownToolError(tc.name)

    # ------------------------------------------------------------------
    # LLM communication
    # ------------------------------------------------------------------

    def _refresh_tool_inventory_section(self) -> None:
        """Rebuild the 'tools' section from current intrinsic + schema descriptions."""
        lang = self._config.language
        lines = []
        for name in self._intrinsics:
            info = ALL_INTRINSICS.get(name)
            if info:
                lines.append(f"### {name}\n{info['module'].get_description(lang)}")
        for s in self._tool_schemas:
            if s.description:
                lines.append(f"### {s.name}\n{s.description}")
        if lines:
            self._prompt_manager.write_section(
                "tools", "\n\n".join(lines), protected=True
            )

    def _build_system_prompt(self) -> str:
        """Build the system prompt from base + sections + tool inventory."""
        self._refresh_tool_inventory_section()
        return build_system_prompt(prompt_manager=self._prompt_manager, language=self._config.language)

    def _build_system_prompt_batches(self) -> list[str]:
        """Build the system prompt as mutation-frequency batches.

        Returns the same content as _build_system_prompt but as a list of
        segments so adapters that support per-block caching can place
        cache breakpoints at batch boundaries.
        """
        self._refresh_tool_inventory_section()
        return build_system_prompt_batches(
            prompt_manager=self._prompt_manager, language=self._config.language
        )

    def _build_tool_schemas(self) -> list[FunctionSchema]:
        """Build the complete tool schema list for the LLM.

        Every tool gets a 'reasoning' parameter injected — the agent must
        explain why it's calling this tool. Reasoning is logged as part of
        the agent's diary and stripped before the handler runs.
        """
        reasoning_prop = {
            "reasoning": {
                "type": "string",
                "description": _t(self._config.language, "tool.reasoning_description"),
            },
        }

        schemas = []

        # Intrinsic schemas
        lang = self._config.language
        for name in self._intrinsics:
            info = ALL_INTRINSICS.get(name)
            if info:
                params = dict(info["module"].get_schema(lang))
                props = dict(params.get("properties", {}))
                props.update(reasoning_prop)
                params["properties"] = props
                schemas.append(
                    FunctionSchema(
                        name=name,
                        description=info["module"].get_description(lang),
                        parameters=params,
                    )
                )

        # Capability + MCP schemas — inject reasoning into each
        for s in self._tool_schemas:
            params = dict(s.parameters)
            props = dict(params.get("properties", {}))
            props.update(reasoning_prop)
            params["properties"] = props
            schemas.append(
                FunctionSchema(
                    name=s.name,
                    description=s.description,
                    parameters=params,
                )
            )

        return schemas

    def get_token_usage(self) -> dict:
        """Return token usage summary (delegates to SessionManager)."""
        if not hasattr(self, "_session"):
            return {
                "input_tokens": 0, "output_tokens": 0,
                "thinking_tokens": 0, "cached_tokens": 0,
                "total_tokens": 0, "api_calls": 0,
                "ctx_system_tokens": 0, "ctx_tools_tokens": 0,
                "ctx_history_tokens": 0, "ctx_total_tokens": 0,
            }
        return self._session.get_token_usage()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def _build_manifest(self) -> dict:
        """Build the manifest dict for .agent.json.

        Subclasses override to add fields (e.g. capabilities).
        Contains everything the agent knows about itself.
        address is always the current working_dir (hot-refreshed on every write).
        Must not depend on _session or _chat — called during __init__.
        """
        data = {
            "agent_id": self._agent_id,
            "agent_name": self.agent_name,
            "nickname": self.nickname,
            "address": self._working_dir.name,
            "created_at": self._created_at,
            "started_at": self._started_at,
            "admin": self._admin,
            "language": self._config.language,
            "stamina": self._config.stamina,
            "state": self._state.value,
            "soul_delay": self._soul_delay,
            "molt_count": self._molt_count,
        }
        if self._mail_service is not None and self._mail_service.address:
            data["address"] = self._mail_service.address
        return data

    def mail(self, address: str, message: str, subject: str = "") -> dict:
        """Send a message to another agent (public API). Requires MailService.

        Routes through the email intrinsic (renamed from mail in 0.7.5).
        """
        return self._intrinsics["email"]({"action": "send", "address": address, "message": message, "subject": subject})

    def has_capability(self, name: str) -> bool:
        """Check if a capability is registered. Subclasses override."""
        return False

    def add_tool(
        self,
        name: str,
        *,
        schema: dict | None = None,
        handler: Callable[[dict], dict] | None = None,
        description: str = "",
        system_prompt: str = "",
    ) -> None:
        """Register a dynamic tool."""
        if self._sealed:
            raise RuntimeError("Cannot modify tools after start()")
        if handler is not None:
            self._tool_handlers[name] = handler
        if schema is not None:
            # Remove any existing schema with same name
            self._tool_schemas = [s for s in self._tool_schemas if s.name != name]
            self._tool_schemas.append(
                FunctionSchema(
                    name=name,
                    description=description,
                    parameters=schema,
                    system_prompt=system_prompt,
                )
            )
        # Update the live session's tools if one exists
        if self._chat is not None:
            self._chat.update_tools(self._build_tool_schemas())
        self._token_decomp_dirty = True

    def remove_tool(self, name: str) -> None:
        """Unregister a dynamic tool."""
        if self._sealed:
            raise RuntimeError("Cannot modify tools after start()")
        self._tool_handlers.pop(name, None)
        self._tool_schemas = [s for s in self._tool_schemas if s.name != name]
        if self._chat is not None:
            self._chat.update_tools(self._build_tool_schemas())
        self._token_decomp_dirty = True

    def override_intrinsic(self, name: str) -> Callable[[dict], dict]:
        """Remove an intrinsic and return its handler for delegation.

        Called by capabilities that upgrade an intrinsic (e.g. email → mail).
        Must be called before start() (tool surface sealed).

        Returns the original handler so the capability can delegate to it.
        """
        if self._sealed:
            raise RuntimeError("Cannot modify tools after start()")
        handler = self._intrinsics.pop(name)  # raises KeyError if missing
        self._token_decomp_dirty = True
        return handler

    def _check_rules_file(self) -> None:
        """Consume .rules signal file, diff against system/rules.md, update if changed."""
        rules_file = self._working_dir / ".rules"
        if not rules_file.is_file():
            return
        try:
            content = rules_file.read_text().strip()
        except OSError:
            return
        # Always consume the signal file
        try:
            rules_file.unlink()
        except OSError:
            return
        if not content:
            return
        # Diff against canonical system/rules.md
        canonical = self._working_dir / "system" / "rules.md"
        existing = ""
        if canonical.is_file():
            try:
                existing = canonical.read_text().strip()
            except OSError:
                pass
        if content == existing:
            return
        # Content changed — persist and refresh
        try:
            canonical.parent.mkdir(parents=True, exist_ok=True)
            canonical.write_text(content)
        except OSError:
            self._log("rules_write_error", source="signal")
            return
        self._prompt_manager.write_section("rules", content, protected=True)
        self._flush_system_prompt()
        self._log("rules_loaded", source="signal")

    def _flush_system_prompt(self) -> None:
        """Rebuild system prompt, persist to system/system.md, update live session."""
        prompt = self._build_system_prompt()
        system_md = self._working_dir / "system" / "system.md"
        system_md.parent.mkdir(exist_ok=True)
        system_md.write_text(prompt)
        if self._chat is not None:
            self._chat.update_system_prompt(prompt)

    def update_system_prompt(
        self, section: str, content: str, *, protected: bool = False
    ) -> None:
        """Update a named section of the system prompt.

        Args:
            section: Section name.
            content: Section content.
            protected: If True, the LLM cannot overwrite this section.
        """
        self._prompt_manager.write_section(section, content, protected=protected)
        self._token_decomp_dirty = True
        self._flush_system_prompt()

    def _cpr_agent(self, address: str) -> "BaseAgent | None":
        """Resuscitate a suspended agent at *address*.

        Returns the resuscitated agent, or None if not supported.
        Override in subclasses (e.g. lingtai's Agent) to provide
        full reconstruction from persisted working dir state.
        """
        return None

    def send(
        self,
        content: str | dict,
        sender: str = "user",
    ) -> None:
        """Send a message to the agent (fire-and-forget).

        Args:
            content: Message content.
            sender: Message sender.
        """
        msg = _make_message(MSG_REQUEST, sender, content)
        self.inbox.put(msg)
        self._wake_nap("message_received")

    # ------------------------------------------------------------------
    # Session persistence (delegates to SessionManager)
    # ------------------------------------------------------------------

    def get_chat_state(self) -> dict:
        """Serialize current chat session for persistence."""
        return self._session.get_chat_state()

    def restore_chat(self, state: dict) -> None:
        """Restore or create a chat session from saved state."""
        self._session.restore_chat(state)

    def restore_token_state(self, state: dict) -> None:
        """Restore cumulative token counters from a saved session."""
        self._session.restore_token_state(state)

    def _save_chat_history(self, *, ledger_source: str = "main") -> None:
        """Write chat history and token usage to disk (no git commit).

        Called after every completed interaction for crash resilience.
        Git commits are handled by the periodic snapshot system.

        ``ledger_source`` tags any token-ledger entry written for the
        most recent LLM round-trip. Default ``"main"`` covers the bulk
        of callers (real user/system text turns, ``_process_response``'s
        tool-loop continuations). Set to ``"tc_wake"`` from involuntary
        splice paths so consultation cadence — which counts ``"main"``
        ledger entries — does not double-count splices as main turns.
        """
        history_dir = self._working_dir / "history"
        history_dir.mkdir(exist_ok=True)
        try:
            state = self.get_chat_state()
            if state and state.get("messages"):
                lines = [json.dumps(entry, ensure_ascii=False) for entry in state["messages"]]
                (history_dir / "chat_history.jsonl").write_text("\n".join(lines) + "\n")
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Failed to save chat history: {e}")
        # Update .agent.json with current state
        try:
            self._workdir.write_manifest(self._build_manifest())
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Failed to update manifest: {e}")
        # Write .status.json — live runtime snapshot consumed by TUI/portal
        try:
            (self._working_dir / ".status.json").write_text(
                json.dumps(self.status(), ensure_ascii=False, indent=2)
            )
        except Exception as e:
            logger.warning(f"[{self.agent_name}] Failed to write .status.json: {e}")
        # Append per-call token usage to ledger (capture-and-null to avoid race
        # with heartbeat thread calling _save_chat_history on AED timeout)
        usage, self._last_usage = self._last_usage, None
        if usage is not None:
            try:
                ledger_path = self._working_dir / "logs" / "token_ledger.jsonl"
                model = getattr(self._session, "_model", None) or getattr(self.service, "model", None)
                endpoint = getattr(self.service, "_base_url", None)
                append_token_entry(
                    ledger_path,
                    input=usage.input_tokens,
                    output=usage.output_tokens,
                    thinking=usage.thinking_tokens,
                    cached=usage.cached_tokens,
                    model=model,
                    endpoint=endpoint,
                    extra={"source": ledger_source},
                )
            except Exception as e:
                logger.warning(f"[{self.agent_name}] Failed to append token ledger: {e}")

    # ------------------------------------------------------------------
    # Status / introspection
    # ------------------------------------------------------------------

    def status(self) -> dict:
        """Return live runtime status — written to .status.json on each turn for TUI/portal.

        Contains identity, runtime metrics, and token/context usage.
        Must only be called after _session exists (not during __init__).
        """
        from datetime import datetime, timezone

        mail_addr = None
        if self._mail_service is not None and self._mail_service.address:
            mail_addr = self._mail_service.address

        uptime = time.monotonic() - self._uptime_anchor if self._uptime_anchor is not None else 0.0
        stamina_left = max(0.0, self._config.stamina - uptime) if self._uptime_anchor is not None else None

        usage = self.get_token_usage()

        window_size = None
        usage_pct = None
        if self._chat is not None:
            try:
                # Use configured context_limit if set, otherwise model default
                window_size = self._config.context_limit or self._chat.context_window()
                ctx_total = usage["ctx_total_tokens"]
                usage_pct = round(ctx_total / window_size * 100, 1) if window_size else 0.0
            except Exception:
                pass

        return {
            "identity": {
                "address": str(self._working_dir),
                "agent_name": self.agent_name,
                "mail_address": mail_addr,
            },
            "runtime": scrub_time_fields(
                self,
                {
                    "current_time": now_iso(self),
                    "started_at": self._started_at,
                    "uptime_seconds": round(uptime, 1),
                    "stamina": self._config.stamina,
                    "stamina_left": round(stamina_left, 1) if stamina_left is not None else None,
                    "state": self._state.value,
                },
                keys=("current_time", "started_at", "uptime_seconds", "stamina", "stamina_left"),
            ),
            "tokens": {
                "input_tokens": usage["input_tokens"],
                "output_tokens": usage["output_tokens"],
                "thinking_tokens": usage["thinking_tokens"],
                "cached_tokens": usage["cached_tokens"],
                "total_tokens": usage["total_tokens"],
                "api_calls": usage["api_calls"],
                "estimated": self._session._token_fallback_warned,
                "context": {
                    "system_tokens": usage["ctx_system_tokens"],
                    "tools_tokens": usage["ctx_tools_tokens"],
                    "history_tokens": usage["ctx_history_tokens"],
                    "total_tokens": usage["ctx_total_tokens"],
                    "window_size": window_size,
                    "usage_pct": usage_pct,
                    # Meta-line decomposition (matches build_meta's buckets)
                    "fixed_tokens": usage["ctx_system_tokens"] + usage["ctx_tools_tokens"],
                    "growing_tokens": usage["ctx_history_tokens"],
                },
            },
        }

    # ------------------------------------------------------------------
    # Hooks (overridable by subclasses)
    # ------------------------------------------------------------------

    def _pre_request(self, msg: Message) -> str:
        """Transform message content before sending to LLM.

        Returns the content string to send.
        """
        return msg.content if isinstance(msg.content, str) else json.dumps(msg.content)

    def _post_request(self, msg: Message, result: dict) -> None:
        """Called after _process_response.

        Override in subclasses for post-processing.
        """

    def _on_tool_result_hook(
        self, tool_name: str, tool_args: dict, result: dict
    ) -> str | None:
        """Hook called after each tool execution.

        If this returns a non-None string, the current request processing
        returns immediately with that string as the result text.
        """
        return None

