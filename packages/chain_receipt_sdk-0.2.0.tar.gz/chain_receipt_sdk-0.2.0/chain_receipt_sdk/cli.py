"""chain-receipt CLI — verify, replay, chain, publish, status.

Five subcommands, all designed to be cited verbatim in the paper:

    chain-receipt verify <hash>
    chain-receipt replay <hash> --n 10
    chain-receipt chain --since <ts>
    chain-receipt publish <hash>
    chain-receipt status

The verifier endpoint at chain-determinism.org is not yet deployed.
``verify`` and ``publish`` therefore validate locally and print a clear
notice that the public endpoint is not yet live. They never block on a
network call.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from chain_receipt_core import (
    Receipt,
    receipt_hash,
    verify_chain,
    verify_receipt,
)

from chain_receipt_sdk import __version__
from chain_receipt_sdk.chain import LocalChain
from chain_receipt_sdk.replay import replay_receipt
from chain_receipt_sdk.verifier import (
    EndpointNotDeployedError,
    ReceiptVerifier,
)


# ============================================================================
# Helpers
# ============================================================================


def _normalize_hash(s: str) -> str:
    s = s.strip()
    return s if s.startswith("sha256:") else "sha256:" + s


def _load_local(target: str) -> Optional[Receipt]:
    return LocalChain().find_by_hash(_normalize_hash(target))


# ============================================================================
# Subcommand handlers
# ============================================================================


def cmd_status(args: argparse.Namespace) -> int:
    chain = LocalChain()
    n = chain.count()
    head = chain.head()
    print(f"chain-receipt-sdk {__version__}")
    print(f"local chain: {chain.path}")
    print(f"  count: {n}")
    if head is not None:
        print(f"  head:")
        print(f"    receipt_id:       {head.receipt_id}")
        print(f"    sequence_number:  {head.chain.sequence_number}")
        print(f"    receipt_hash:     {receipt_hash(head)}")
        print(f"    created_at:       {head.created_at}")
    else:
        print("  head: <empty>")
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    target = _normalize_hash(args.hash)
    r = _load_local(target)
    if r is None:
        print(f"  Receipt {target} not found in local chain", file=sys.stderr)
        print(f"  Hint: ~/.chain-receipt/chain.jsonl has no matching entry.")
        return 2

    res = verify_receipt(r, require_signature=args.require_signature)
    print(f"hash:       {target}")
    print(f"signature:  {'ok' if res.ok else 'FAILED'}")
    if not res.ok:
        for e in res.errors:
            print(f"  - {e}")

    # Also try a chain-link check against the predecessor in the local chain
    receipts = LocalChain().read_all()
    by_hash = {receipt_hash(x): (i, x) for i, x in enumerate(receipts)}
    if target in by_hash:
        idx, _ = by_hash[target]
        if idx > 0:
            prev = receipts[idx - 1]
            link = verify_receipt(
                r, prev_receipt=prev, require_signature=args.require_signature
            )
            print(f"chain link: {'ok' if link.ok else 'FAILED'}")
            if not link.ok:
                for e in link.errors:
                    print(f"  - {e}")

    # Remote
    print()
    try:
        ReceiptVerifier().verify_remote(r)
        print("remote:     ok")
    except EndpointNotDeployedError as e:
        print(f"remote:     not yet deployed")
        print(f"  {e}")
    return 0 if res.ok else 1


def cmd_replay(args: argparse.Namespace) -> int:
    target = _normalize_hash(args.hash)
    r = _load_local(target)
    if r is None:
        print(f"  Receipt {target} not found in local chain", file=sys.stderr)
        return 2

    res = replay_receipt(r, n=args.n)
    payload = {
        "receipt_hash": res.receipt_hash,
        "n_replays": res.n_replays,
        "divergence_rate": res.divergence_rate,
        "wilson_ci_lo": res.wilson_ci_lo,
        "wilson_ci_hi": res.wilson_ci_hi,
        "final_answer_consistent": res.final_answer_consistent,
        "tool_seq_identical": res.tool_seq_identical,
        "tool_args_identical": res.tool_args_identical,
        "method": res.method,
        "note": res.note,
    }
    print(json.dumps(payload, indent=2, default=str))
    return 0


def cmd_chain(args: argparse.Namespace) -> int:
    chain = LocalChain()
    receipts = chain.since(args.since) if args.since else chain.read_all()
    if args.json:
        print(
            json.dumps(
                [
                    {
                        "receipt_id": r.receipt_id,
                        "sequence_number": r.chain.sequence_number,
                        "receipt_hash": receipt_hash(r),
                        "created_at": r.created_at,
                        "vendor": r.interaction.vendor,
                        "model": r.interaction.model,
                    }
                    for r in receipts
                ],
                indent=2,
            )
        )
    else:
        for r in receipts:
            print(
                f"  seq={r.chain.sequence_number:>4d}  "
                f"{receipt_hash(r)}  "
                f"{r.created_at}  "
                f"{r.interaction.vendor}/{r.interaction.model}"
            )
        print(f"\n  total: {len(receipts)}")
    return 0


def cmd_publish(args: argparse.Namespace) -> int:
    target = _normalize_hash(args.hash)
    r = _load_local(target)
    if r is None:
        print(f"  Receipt {target} not found in local chain", file=sys.stderr)
        return 2
    print(f"hash: {target}")
    try:
        ReceiptVerifier().publish(r)
        print("publish:    ok")
        return 0
    except EndpointNotDeployedError as e:
        print(f"publish:    endpoint not yet deployed")
        print(f"  {e}")
        # Still validate locally so the user knows the Receipt is well-formed.
        res = verify_receipt(r, require_signature=False)
        print(f"local:      {'ok' if res.ok else 'FAILED'}")
        return 0  # Not an error — the local Receipt is fine, the endpoint just isn't live.


# ============================================================================
# Driver
# ============================================================================


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="chain-receipt",
        description="Emit, verify, replay, and chain Receipts (v1.0.0).",
    )
    p.add_argument("--version", action="version", version=f"chain-receipt-sdk {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("status", help="show local chain head + count")
    s.set_defaults(func=cmd_status)

    s = sub.add_parser("verify", help="validate signature + chain link of a Receipt")
    s.add_argument("hash", help="receipt_hash, with or without sha256: prefix")
    s.add_argument(
        "--no-require-signature",
        dest="require_signature",
        action="store_false",
        default=True,
        help="accept unsigned Receipts (default: signature required)",
    )
    s.set_defaults(func=cmd_verify)

    s = sub.add_parser("replay", help="re-run captured prompt N times, report divergence")
    s.add_argument("hash", help="receipt_hash")
    s.add_argument("--n", type=int, default=10, help="number of replays (default: 10)")
    s.set_defaults(func=cmd_replay)

    s = sub.add_parser("chain", help="list Receipts since <timestamp>")
    s.add_argument("--since", type=str, default=None,
                   help="RFC 3339 / ISO 8601 timestamp (e.g. 2026-04-25T00:00:00Z)")
    s.add_argument("--json", action="store_true", help="emit JSON instead of text")
    s.set_defaults(func=cmd_chain)

    s = sub.add_parser("publish", help="push a Receipt to chain-determinism.org/r/<hash>")
    s.add_argument("hash", help="receipt_hash")
    s.set_defaults(func=cmd_publish)

    return p


def main(argv: Optional[list] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
