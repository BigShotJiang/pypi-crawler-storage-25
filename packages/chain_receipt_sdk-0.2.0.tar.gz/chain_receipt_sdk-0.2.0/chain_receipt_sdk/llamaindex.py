"""LlamaIndex callback handler that emits one Receipt per LLM call.

Lazy-imports ``llama_index.core`` so that ``chain_receipt_sdk`` is usable
without it. If LlamaIndex is installed, ``ReceiptCallback`` subclasses
``llama_index.core.callbacks.base_handler.BaseCallbackHandler``; otherwise
it's a duck-typed plain class that raises a clear error when instantiated.

Usage:

    from llama_index.core import Settings
    from llama_index.core.callbacks import CallbackManager
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="my-llamaindex-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    Settings.callback_manager = CallbackManager([cb])

    # ... your normal LlamaIndex pipeline ...

    for r in cb.receipts:
        print(r.receipt_id, r.interaction.tool_calls_hash)

The callback emits one Receipt at the end of each ``CBEventType.LLM``
event. Tool calls (``CBEventType.FUNCTION_CALL``) are accumulated between
LLM events and rolled into the next emitted Receipt's
``tool_calls_hash``.

For non-LangChain / non-LlamaIndex agent loops, use the framework-
agnostic ``ReceiptCallback.emit(...)`` method (inherited from the
shared base class) to construct Receipts directly.
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from chain_receipt_core import (
    ClientInfo,
    Interaction,
    Receipt,
    Stability,
    compute_text_hash,
    compute_tool_calls_hash,
    generate_keypair,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from chain_receipt_sdk.builder import ReceiptBuilder
from chain_receipt_sdk.chain import LocalChain


# Try to subclass the LlamaIndex base handler when llama-index-core is
# available. Two import paths are checked because LlamaIndex has moved
# the base-handler module across minor versions (the public alias has
# also shifted between `from llama_index.core.callbacks import BaseCallbackHandler`
# and `from llama_index.core.callbacks.base_handler import BaseCallbackHandler`).
try:
    from llama_index.core.callbacks.base_handler import (  # type: ignore
        BaseCallbackHandler as _LIBaseHandler,
    )
    from llama_index.core.callbacks.schema import (  # type: ignore
        CBEventType as _LICBEventType,
        EventPayload as _LIEventPayload,
    )
    _LI_AVAILABLE = True
except Exception:  # pragma: no cover - exercised only when LI missing
    _LIBaseHandler = object  # type: ignore
    _LICBEventType = None  # type: ignore
    _LIEventPayload = None  # type: ignore
    _LI_AVAILABLE = False


class ReceiptCallback(_LIBaseHandler):  # type: ignore[misc]
    """Emit one Receipt per LLM event observed via LlamaIndex callbacks.

    Mirrors the public surface of ``chain_receipt_sdk.callback.ReceiptCallback``
    (the LangChain handler). Both classes accept the same constructor
    kwargs and expose the same ``.receipts``, ``.emit(...)`` and chain-
    management surface; choose whichever module matches your framework.
    """

    SDK_NAME = "chain-receipt-sdk"
    SDK_VERSION = "0.1.0"

    def __init__(
        self,
        *,
        client_name: str,
        vendor: str,
        model: str,
        temperature: float = 0.0,
        platform: str = "python",
        private_key: Optional[Ed25519PrivateKey] = None,
        verifier_url: Optional[str] = None,
        chain_seed: Optional[bytes] = None,
        persist: bool = False,
        local_chain: Optional[LocalChain] = None,
        capture_payload: bool = False,
        event_starts_to_ignore: Optional[List[Any]] = None,
        event_ends_to_ignore: Optional[List[Any]] = None,
    ):
        if not _LI_AVAILABLE:
            raise ImportError(
                "chain_receipt_sdk.llamaindex.ReceiptCallback requires "
                "llama-index-core. Install via `pip install "
                "chain-receipt-sdk[llamaindex]` or "
                "`pip install llama-index-core>=0.13`."
            )
        # LlamaIndex's BaseCallbackHandler.__init__ requires the two
        # ignore-lists as positional/keyword args. Default to empty lists
        # so we observe every event by default.
        super().__init__(
            event_starts_to_ignore=event_starts_to_ignore or [],
            event_ends_to_ignore=event_ends_to_ignore or [],
        )

        if private_key is None:
            sk, pub_b64 = generate_keypair()
        else:
            sk = private_key
            from cryptography.hazmat.primitives import serialization
            import base64
            pub_bytes = sk.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            pub_b64 = base64.urlsafe_b64encode(pub_bytes).rstrip(b"=").decode("ascii")

        self._client = ClientInfo(
            name=client_name,
            version=self.SDK_VERSION,
            platform=platform,
            emitter_pubkey=f"ed25519:{pub_b64}",
        )
        self._builder = ReceiptBuilder(
            client=self._client,
            private_key=sk,
            verifier_url=verifier_url,
            chain_seed=chain_seed if chain_seed is not None else pub_b64.encode(),
            persist=persist,
            local_chain=local_chain,
        )
        self.vendor = vendor
        self.model = model
        self.temperature = float(temperature)
        self.capture_payload = capture_payload

        self._receipts: List[Receipt] = []
        # Pending per-event state. LlamaIndex dispatches events by event_id
        # so a single handler instance could see overlapping events from
        # concurrent traces. We key pending state by event_id for safety;
        # a simple dict suffices because LlamaIndex serializes within a
        # given trace.
        self._pending: Dict[str, Dict[str, Any]] = {}
        self._pending_tool_calls: List[dict] = []

    # ------------------------------------------------------------------
    # Public surface (mirrors chain_receipt_sdk.callback.ReceiptCallback)
    # ------------------------------------------------------------------

    @property
    def receipts(self) -> List[Receipt]:
        return list(self._receipts)

    def emit(
        self,
        *,
        prompt: str,
        response: str,
        system_prompt: str = "",
        tool_calls: Optional[List[dict]] = None,
        latency_ms: Optional[int] = None,
        stability: Optional[Stability] = None,
    ) -> Receipt:
        """Manual emit path — use directly when no LlamaIndex event fires.

        Identical observable behaviour to a fully captured callback
        sequence; useful for non-LlamaIndex code paths within a
        LlamaIndex-using application.
        """
        tool_calls = tool_calls or []
        payload = None
        if self.capture_payload:
            payload = {
                "prompt": prompt,
                "system_prompt": system_prompt,
                "response": response,
                "tool_calls": list(tool_calls),
            }
        inter = Interaction(
            vendor=self.vendor,
            model=self.model,
            temperature=self.temperature,
            system_prompt_hash=compute_text_hash(system_prompt or ""),
            prompt_hash=compute_text_hash(prompt or ""),
            response_hash=compute_text_hash(response or ""),
            tool_calls_hash=compute_tool_calls_hash(tool_calls),
            n_tool_calls=len(tool_calls),
            latency_ms=latency_ms,
        )
        r = self._builder.build(
            interaction=inter,
            stability=stability,
            optional_payload=payload,
        )
        self._receipts.append(r)
        return r

    # ------------------------------------------------------------------
    # LlamaIndex BaseCallbackHandler hooks
    # ------------------------------------------------------------------

    def start_trace(self, trace_id: Optional[str] = None) -> None:  # type: ignore[override]
        # Reset tool-call accumulator at the start of a trace so calls
        # from a prior trace don't leak into the first LLM event.
        self._pending_tool_calls = []

    def end_trace(
        self,
        trace_id: Optional[str] = None,
        trace_map: Optional[Dict[str, List[str]]] = None,
    ) -> None:  # type: ignore[override]
        # No-op; Receipts are emitted on per-LLM-event end, not
        # per-trace end. A trace may include multiple LLM events.
        pass

    def on_event_start(
        self,
        event_type: Any,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:  # type: ignore[override]
        payload = payload or {}
        if event_type == _LICBEventType.LLM:
            prompt_text, system_text = self._extract_prompt(payload)
            self._pending[event_id] = {
                "t_start": time.time(),
                "prompt": prompt_text,
                "system_prompt": system_text,
            }
        elif event_type == _LICBEventType.FUNCTION_CALL:
            self._record_function_call(payload)
        return event_id

    def on_event_end(
        self,
        event_type: Any,
        payload: Optional[Dict[str, Any]] = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:  # type: ignore[override]
        if event_type != _LICBEventType.LLM:
            return
        pending = self._pending.pop(event_id, None)
        if pending is None:
            # Unknown event_id (out-of-order or duplicate end) — record
            # what we can but don't crash. The Receipt is still emitted
            # so the divergence surface remains complete.
            pending = {"t_start": None, "prompt": "", "system_prompt": ""}

        response_text = self._extract_response(payload or {})
        latency_ms = (
            int((time.time() - pending["t_start"]) * 1000)
            if pending["t_start"] is not None
            else None
        )
        self.emit(
            prompt=pending["prompt"] or "",
            response=response_text or "",
            system_prompt=pending["system_prompt"] or "",
            tool_calls=self._pending_tool_calls,
            latency_ms=latency_ms,
        )
        # Reset tool-call accumulator for the next LLM event in the trace.
        self._pending_tool_calls = []

    # ------------------------------------------------------------------
    # Payload extraction helpers (private)
    # ------------------------------------------------------------------

    def _extract_prompt(self, payload: Dict[str, Any]) -> tuple[str, str]:
        """Pull prompt + system text out of a CBEventType.LLM start payload.

        LlamaIndex emits LLM events with either ``EventPayload.PROMPT``
        (completion-style; a single formatted string) or
        ``EventPayload.MESSAGES`` (chat-style; a list of ChatMessage).
        Both shapes are handled.
        """
        prompt = ""
        system = ""

        # Completion-style: PROMPT key holds the formatted prompt string.
        if _LIEventPayload.PROMPT in payload:
            raw = payload[_LIEventPayload.PROMPT]
            prompt = str(raw) if raw is not None else ""

        # Chat-style: MESSAGES key holds a list of ChatMessage; split
        # system messages from user / assistant messages so they land
        # in the right Interaction field. This mirrors the LangChain
        # callback's on_chat_model_start behaviour.
        if _LIEventPayload.MESSAGES in payload:
            sys_chunks: List[str] = []
            flat: List[str] = []
            for m in payload[_LIEventPayload.MESSAGES] or []:
                role = getattr(m, "role", None)
                # LlamaIndex ChatMessage.role is a MessageRole enum;
                # convert to string for matching.
                role_str = getattr(role, "value", None) or str(role or "")
                content = getattr(m, "content", None)
                if content is None:
                    content = str(m)
                if role_str == "system":
                    sys_chunks.append(str(content))
                else:
                    flat.append(str(content))
            system = "\n".join(sys_chunks)
            if not prompt:
                prompt = "\n".join(flat)

        # SYSTEM_PROMPT key (some LlamaIndex paths emit it separately).
        if _LIEventPayload.SYSTEM_PROMPT in payload and not system:
            raw_sys = payload[_LIEventPayload.SYSTEM_PROMPT]
            system = str(raw_sys) if raw_sys is not None else ""

        return prompt, system

    def _extract_response(self, payload: Dict[str, Any]) -> str:
        """Pull response text out of a CBEventType.LLM end payload.

        LlamaIndex emits the response under either ``EventPayload.RESPONSE``
        (chat-style ChatResponse) or ``EventPayload.COMPLETION``
        (completion-style CompletionResponse). Both have a ``.text``
        attribute or a ``.message.content`` attribute depending on shape.
        """
        # Chat-style: RESPONSE key holds a ChatResponse with .message.content
        if _LIEventPayload.RESPONSE in payload:
            resp = payload[_LIEventPayload.RESPONSE]
            # Try ChatResponse.message.content first
            msg = getattr(resp, "message", None)
            if msg is not None:
                content = getattr(msg, "content", None)
                if content is not None:
                    return str(content)
            # Fall back to .text or str
            text = getattr(resp, "text", None)
            if text is not None:
                return str(text)
            return str(resp)

        # Completion-style: COMPLETION key holds a CompletionResponse with .text
        if _LIEventPayload.COMPLETION in payload:
            resp = payload[_LIEventPayload.COMPLETION]
            text = getattr(resp, "text", None)
            if text is not None:
                return str(text)
            return str(resp)

        return ""

    def _record_function_call(self, payload: Dict[str, Any]) -> None:
        """Append a tool-call entry to the pending list when LlamaIndex
        emits a CBEventType.FUNCTION_CALL start event."""
        # LlamaIndex stashes the call under EventPayload.FUNCTION_CALL
        # and the tool metadata under EventPayload.TOOL.
        call = payload.get(_LIEventPayload.FUNCTION_CALL)
        tool = payload.get(_LIEventPayload.TOOL)

        name = "tool"
        if tool is not None:
            # ToolMetadata has .name; or be lenient and stringify.
            name = getattr(tool, "name", None) or str(tool)
        elif call is not None and isinstance(call, dict):
            name = call.get("name", "tool")

        # Arguments shape varies; try a few common locations.
        args: Dict[str, Any] = {}
        if isinstance(call, dict):
            args = call.get("arguments") or call.get("args") or call
            if not isinstance(args, dict):
                args = {"_raw": str(args)}
        elif call is not None:
            # Object with attributes — best-effort serialization.
            args_attr = getattr(call, "arguments", None) or getattr(call, "args", None)
            if isinstance(args_attr, dict):
                args = args_attr
            elif args_attr is not None:
                args = {"_raw": str(args_attr)}

        self._pending_tool_calls.append({"name": str(name), "args": args})


__all__ = ["ReceiptCallback"]
