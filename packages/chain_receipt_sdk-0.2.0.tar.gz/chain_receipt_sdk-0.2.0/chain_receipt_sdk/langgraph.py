"""LangGraph adapter — Chain-Receipts from compiled state graphs.

LangGraph is built on LangChain's callback infrastructure, so the
existing ``chain_receipt_sdk.callback.ReceiptCallback`` already works
when attached to a compiled graph via
``compiled.invoke(config={"callbacks": [cb]})``. This module exists
for two reasons:

  1. Discoverability — devs searching for ``chain_receipt_sdk.langgraph``
     find an obvious entry point with LangGraph-specific docs and
     examples, rather than having to discover that the LangChain
     callback propagates.
  2. Convenience — ``attach_receipts(compiled_graph, callback)`` returns
     a thin wrapper that pre-attaches the callback to every
     ``.invoke()`` / ``.stream()`` call, so users don't have to thread
     ``config={"callbacks": [cb]}`` through every call site.

Audit (2026-05-12, ``/tmp/cv-audit/langgraph_audit.py``): three cases
verified — basic node invocation, three-node chain with full
verify_chain integrity, and conditional routing where only the
chosen branch emits Receipts. All passed without any LangGraph-
specific adapter code; the LangChain callback handles it.

Install: ``pip install chain-receipt-sdk[langgraph]`` (which pulls in
``langgraph>=0.2`` and ``langchain-core>=0.3``).
"""
from __future__ import annotations

from typing import Any, Optional

# Re-export so `from chain_receipt_sdk.langgraph import ReceiptCallback`
# Just Works for discoverability.
from chain_receipt_sdk.callback import ReceiptCallback


try:
    # Probe for langgraph presence so we can give a clear error in
    # attach_receipts() if the user calls it without langgraph installed.
    import langgraph  # type: ignore  # noqa: F401
    _LG_AVAILABLE = True
except Exception:  # pragma: no cover - exercised only when langgraph missing
    _LG_AVAILABLE = False


class _ReceiptAttachedGraph:
    """Wrapper that pre-attaches a callback to every graph invocation.

    Exposes the same ``invoke`` / ``ainvoke`` / ``stream`` / ``astream``
    surface as a compiled LangGraph; merges the ReceiptCallback into
    any ``config`` the caller passes.
    """

    def __init__(self, compiled_graph: Any, callback: ReceiptCallback) -> None:
        self._graph = compiled_graph
        self._callback = callback

    @property
    def callback(self) -> ReceiptCallback:
        """The attached ReceiptCallback. Use ``.receipts`` to list emitted Receipts."""
        return self._callback

    def _merge_config(self, config: Optional[dict]) -> dict:
        merged: dict = dict(config or {})
        existing = list(merged.get("callbacks") or [])
        if self._callback not in existing:
            existing.append(self._callback)
        merged["callbacks"] = existing
        return merged

    def invoke(self, input: Any, config: Optional[dict] = None, **kwargs: Any) -> Any:
        return self._graph.invoke(input, config=self._merge_config(config), **kwargs)

    async def ainvoke(self, input: Any, config: Optional[dict] = None, **kwargs: Any) -> Any:
        return await self._graph.ainvoke(input, config=self._merge_config(config), **kwargs)

    def stream(self, input: Any, config: Optional[dict] = None, **kwargs: Any):
        return self._graph.stream(input, config=self._merge_config(config), **kwargs)

    def astream(self, input: Any, config: Optional[dict] = None, **kwargs: Any):
        return self._graph.astream(input, config=self._merge_config(config), **kwargs)

    def __getattr__(self, name: str) -> Any:
        # Forward any attribute we haven't explicitly wrapped to the
        # underlying graph (get_graph(), update_state(), etc.).
        return getattr(self._graph, name)


def attach_receipts(compiled_graph: Any, callback: ReceiptCallback) -> _ReceiptAttachedGraph:
    """Wrap a compiled LangGraph so every invocation auto-attaches the callback.

    Usage::

        from langgraph.graph import StateGraph, START, END
        from chain_receipt_sdk.langgraph import ReceiptCallback, attach_receipts

        # Build your graph as usual
        graph = StateGraph(MyState)
        graph.add_node("llm", my_llm_node)
        graph.add_edge(START, "llm")
        graph.add_edge("llm", END)
        compiled = graph.compile()

        # Attach receipts
        cb = ReceiptCallback(
            client_name="my-langgraph-agent",
            vendor="anthropic",
            model="claude-sonnet-4-5",
        )
        wrapped = attach_receipts(compiled, cb)

        # Now every invocation auto-emits Receipts
        result = wrapped.invoke({"question": "hi"})

        for r in wrapped.callback.receipts:
            print(r.receipt_id, r.chain.sequence_number)

    If you prefer to thread the callback yourself (e.g., conditionally,
    or with extra callbacks), skip this wrapper and pass
    ``config={"callbacks": [cb]}`` to your existing ``compiled.invoke()``
    calls directly — that path is equally supported.
    """
    if not _LG_AVAILABLE:
        raise ImportError(
            "chain_receipt_sdk.langgraph.attach_receipts requires langgraph. "
            "Install via `pip install chain-receipt-sdk[langgraph]` or "
            "`pip install langgraph>=0.2`."
        )
    if not isinstance(callback, ReceiptCallback):
        raise TypeError(
            f"callback must be a chain_receipt_sdk ReceiptCallback "
            f"instance; got {type(callback).__name__}"
        )
    return _ReceiptAttachedGraph(compiled_graph, callback)


__all__ = ["ReceiptCallback", "attach_receipts"]
