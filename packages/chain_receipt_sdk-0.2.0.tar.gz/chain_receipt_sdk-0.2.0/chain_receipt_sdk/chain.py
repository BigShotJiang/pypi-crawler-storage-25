"""LocalChain — read/write Receipts at ~/.chain-receipt/chain.jsonl.

Each line is a JSON-serialized Receipt. Files are append-only on the
emit path; readers tolerate truncated last lines.

Storage location is overridable via the `CHAIN_RECEIPT_DIR` env var so
tests can use a tmp_path fixture without touching the user's HOME.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator, List, Optional

from chain_receipt_core import Receipt, receipt_hash


def _default_dir() -> Path:
    override = os.environ.get("CHAIN_RECEIPT_DIR")
    if override:
        return Path(override)
    return Path.home() / ".chain-receipt"


def _parse_iso(ts: str) -> datetime:
    """Parse RFC 3339 / ISO 8601 timestamp; tolerate trailing Z."""
    s = ts.rstrip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


class LocalChain:
    """Append-only JSONL chain at ~/.chain-receipt/chain.jsonl.

    Use as a context manager for atomic batch appends, or call
    ``append`` / ``read_all`` directly.
    """

    def __init__(self, *, path: Optional[Path] = None):
        self.dir = (path.parent if path else _default_dir())
        self.path = path or (self.dir / "chain.jsonl")
        self.dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def append(self, receipt: Receipt) -> str:
        """Append a Receipt and return its receipt_hash."""
        h = receipt_hash(receipt)
        with self.path.open("a") as f:
            f.write(receipt.model_dump_json() + "\n")
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        return h

    def append_many(self, receipts: Iterable[Receipt]) -> List[str]:
        return [self.append(r) for r in receipts]

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read_all(self) -> List[Receipt]:
        return list(self.iter_all())

    def iter_all(self) -> Iterator[Receipt]:
        if not self.path.exists():
            return
        with self.path.open() as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except json.JSONDecodeError:
                    # Tolerate a truncated final line (mid-write crash)
                    continue
                yield Receipt.model_validate(payload)

    def find_by_hash(self, target: str) -> Optional[Receipt]:
        """Return the Receipt with the given receipt_hash, or None."""
        if not target.startswith("sha256:"):
            target = "sha256:" + target.lstrip("sha256:")
        for r in self.iter_all():
            if receipt_hash(r) == target:
                return r
        return None

    def since(self, ts: str) -> List[Receipt]:
        """Return Receipts whose ``created_at`` is >= the given timestamp."""
        cutoff = _parse_iso(ts)
        out: List[Receipt] = []
        for r in self.iter_all():
            try:
                created = _parse_iso(r.created_at)
            except (ValueError, TypeError):
                continue
            if created >= cutoff:
                out.append(r)
        return out

    def head(self) -> Optional[Receipt]:
        """Return the most recently appended Receipt, or None if empty."""
        last: Optional[Receipt] = None
        for r in self.iter_all():
            last = r
        return last

    def count(self) -> int:
        if not self.path.exists():
            return 0
        with self.path.open() as f:
            return sum(1 for line in f if line.strip())


__all__ = ["LocalChain"]
