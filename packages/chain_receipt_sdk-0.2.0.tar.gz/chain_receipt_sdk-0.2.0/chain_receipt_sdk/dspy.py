"""DSPy adapter — Chain-Receipts from LM calls in compiled DSPy programs.

DSPy (>=3.0) exposes a ``BaseCallback`` interface at
``dspy.utils.callback``. Register an instance via
``dspy.settings.configure(callbacks=[cb])`` and DSPy fires
``on_lm_start`` / ``on_lm_end`` / ``on_tool_start`` / ``on_tool_end``
around every LM call and tool invocation across your DSPy program
(Predict, ChainOfThought, ReAct, Refine, BootstrapFewShot, etc.).

This module ships ``ReceiptCallback`` which subclasses ``BaseCallback``
and emits one Receipt per LM call, accumulating tool calls between
LM events into the next emitted Receipt's ``tool_calls_hash``.

Usage::

    import dspy
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="my-dspy-program",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    dspy.settings.configure(
        lm=dspy.LM("anthropic/claude-sonnet-4-5"),
        callbacks=[cb],
    )

    # ... build + run your DSPy program ...

    for r in cb.receipts:
        print(r.receipt_id, r.chain.sequence_number)

Install: ``pip install chain-receipt-sdk[dspy]`` (or pin ``dspy>=3``).
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from chain_receipt_core import (
    ClientInfo,
    Receipt,
    Stability,
    generate_keypair,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from chain_receipt_sdk.builder import ReceiptBuilder
from chain_receipt_sdk.chain import LocalChain


try:
    from dspy.utils.callback import BaseCallback as _DSPyBaseCallback  # type: ignore
    _DSPY_AVAILABLE = True
except Exception:  # pragma: no cover
    _DSPyBaseCallback = object  # type: ignore
    _DSPY_AVAILABLE = False


class ReceiptCallback(_DSPyBaseCallback):  # type: ignore[misc]
    """DSPy callback that emits one Chain-Receipt per LM call.

    Mirrors the public surface of the LangChain / LlamaIndex /
    Pydantic AI adapters in this SDK. Tool calls observed via
    ``on_tool_start`` accumulate between LM events and are folded into
    the next Receipt's ``tool_calls_hash``.
    """

    SDK_NAME = "chain-receipt-sdk"
    SDK_VERSION = "0.1.0"

    def __init__(
        self,
        *,
        client_name: str,
        vendor: str,
        model: str,
        temperature: float = 0.0,
        platform: str = "python",
        private_key: Optional[Ed25519PrivateKey] = None,
        verifier_url: Optional[str] = None,
        chain_seed: Optional[bytes] = None,
        persist: bool = False,
        local_chain: Optional[LocalChain] = None,
        capture_payload: bool = False,
    ):
        if not _DSPY_AVAILABLE:
            raise ImportError(
                "chain_receipt_sdk.dspy.ReceiptCallback requires dspy. "
                "Install via `pip install chain-receipt-sdk[dspy]` or "
                "`pip install dspy>=3`."
            )

        if private_key is None:
            sk, pub_b64 = generate_keypair()
        else:
            sk = private_key
            from cryptography.hazmat.primitives import serialization
            import base64
            pub_bytes = sk.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            pub_b64 = base64.urlsafe_b64encode(pub_bytes).rstrip(b"=").decode("ascii")

        self._client = ClientInfo(
            name=client_name,
            version=self.SDK_VERSION,
            platform=platform,
            emitter_pubkey=f"ed25519:{pub_b64}",
        )
        self._builder = ReceiptBuilder(
            client=self._client,
            private_key=sk,
            verifier_url=verifier_url,
            chain_seed=chain_seed if chain_seed is not None else pub_b64.encode(),
            persist=persist,
            local_chain=local_chain,
        )
        self.vendor = vendor
        self.model = model
        self.temperature = float(temperature)
        self.capture_payload = capture_payload

        self._receipts: List[Receipt] = []
        # Per-call_id pending state — DSPy callbacks are call-id-scoped so
        # nested or parallel calls don't trample each other.
        self._pending: Dict[str, Dict[str, Any]] = {}
        # Tool calls accumulated between LM events; rolled into the next
        # emitted Receipt and reset.
        self._pending_tool_calls: List[dict] = []

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------

    @property
    def receipts(self) -> List[Receipt]:
        return list(self._receipts)

    def emit(
        self,
        *,
        prompt: str,
        response: str,
        system_prompt: str = "",
        tool_calls: Optional[List[dict]] = None,
        latency_ms: Optional[int] = None,
        stability: Optional[Stability] = None,
    ) -> Receipt:
        """Framework-agnostic emit path. Mirrors other adapters in this SDK."""
        from chain_receipt_core import (
            Interaction,
            compute_text_hash,
            compute_tool_calls_hash,
        )

        tool_calls = tool_calls or []
        payload = None
        if self.capture_payload:
            payload = {
                "prompt": prompt,
                "system_prompt": system_prompt,
                "response": response,
                "tool_calls": list(tool_calls),
            }
        inter = Interaction(
            vendor=self.vendor,
            model=self.model,
            temperature=self.temperature,
            system_prompt_hash=compute_text_hash(system_prompt or ""),
            prompt_hash=compute_text_hash(prompt or ""),
            response_hash=compute_text_hash(response or ""),
            tool_calls_hash=compute_tool_calls_hash(tool_calls),
            n_tool_calls=len(tool_calls),
            latency_ms=latency_ms,
        )
        r = self._builder.build(
            interaction=inter,
            stability=stability,
            optional_payload=payload,
        )
        self._receipts.append(r)
        return r

    # ------------------------------------------------------------------
    # DSPy BaseCallback hooks
    # ------------------------------------------------------------------

    def on_lm_start(
        self,
        call_id: str,
        instance: Any,
        inputs: Dict[str, Any],
    ) -> None:  # type: ignore[override]
        prompt_text, system_text = self._extract_prompt(inputs)
        self._pending[call_id] = {
            "t_start": time.time(),
            "prompt": prompt_text,
            "system_prompt": system_text,
        }

    def on_lm_end(
        self,
        call_id: str,
        outputs: Optional[Any],
        exception: Optional[Exception] = None,
    ) -> None:  # type: ignore[override]
        pending = self._pending.pop(call_id, None)
        if pending is None:
            pending = {"t_start": None, "prompt": "", "system_prompt": ""}

        response_text = self._extract_response(outputs)
        latency_ms = (
            int((time.time() - pending["t_start"]) * 1000)
            if pending["t_start"] is not None
            else None
        )
        self.emit(
            prompt=pending["prompt"] or "",
            response=response_text or "",
            system_prompt=pending["system_prompt"] or "",
            tool_calls=self._pending_tool_calls,
            latency_ms=latency_ms,
        )
        self._pending_tool_calls = []

    def on_tool_start(
        self,
        call_id: str,
        instance: Any,
        inputs: Dict[str, Any],
    ) -> None:  # type: ignore[override]
        name = getattr(instance, "name", None) or type(instance).__name__
        self._pending_tool_calls.append({
            "name": str(name),
            "args": dict(inputs or {}),
        })

    def on_tool_end(
        self,
        call_id: str,
        outputs: Optional[Any],
        exception: Optional[Exception] = None,
    ) -> None:  # type: ignore[override]
        # Tool result not captured in the Receipt today (Receipt schema
        # records tool CALLS only). The result is the LM's next-prompt
        # input which will hash into the next LM event's prompt_hash.
        pass

    # ------------------------------------------------------------------
    # Payload extraction helpers (private)
    # ------------------------------------------------------------------

    def _extract_prompt(self, inputs: Dict[str, Any]) -> tuple[str, str]:
        """Pull prompt + system text out of a DSPy on_lm_start inputs.

        DSPy passes either ``inputs['messages']`` (chat-style, list of
        ``{'role': ..., 'content': ...}`` dicts) or ``inputs['prompt']``
        (completion-style string). Both shapes are handled.
        """
        prompt = ""
        system = ""

        messages = inputs.get("messages") or []
        if messages:
            sys_chunks: List[str] = []
            flat: List[str] = []
            for m in messages:
                if isinstance(m, dict):
                    role = m.get("role", "user")
                    content = m.get("content", "")
                else:
                    role = getattr(m, "role", "user")
                    content = getattr(m, "content", str(m))
                if role == "system":
                    sys_chunks.append(str(content))
                else:
                    flat.append(str(content))
            system = "\n".join(sys_chunks)
            prompt = "\n".join(flat)
        else:
            raw_prompt = inputs.get("prompt")
            if raw_prompt is not None:
                prompt = str(raw_prompt)

        return prompt, system

    def _extract_response(self, outputs: Any) -> str:
        """Pull response text out of a DSPy on_lm_end outputs.

        DSPy normalizes LM responses to either:
          - a list[str] of completions (the typical shape)
          - a single string in some adapter paths
          - None on exception (caller passes exception= alongside)
        We concatenate list items with no separator to give a single
        canonical response string for hashing.
        """
        if outputs is None:
            return ""
        if isinstance(outputs, list):
            return "".join(str(item) for item in outputs)
        if isinstance(outputs, str):
            return outputs
        return str(outputs)


__all__ = ["ReceiptCallback"]
