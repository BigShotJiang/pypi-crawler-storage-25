"""ReceiptVerifier — HTTP client for chain-determinism.org verifier endpoint.

The endpoint at ``https://chain-determinism.org/verify/<hash>`` is not
yet deployed. Until it is, all network operations return a clear
``EndpointNotDeployedError`` so callers can fall back to local
verification.

Local verification (signature + chain link) always works via the core
``verify_receipt`` / ``verify_chain`` helpers. The HTTP client is only
needed to confirm that a third party (the public verifier) has the
same Receipt indexed.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from chain_receipt_core import Receipt, VerifyResult, receipt_hash, verify_receipt


DEFAULT_VERIFIER_URL = "https://chain-determinism.org"


class EndpointNotDeployedError(RuntimeError):
    """Raised when the public verifier endpoint is not yet reachable."""


@dataclass
class RemoteVerifyResult:
    ok: bool
    detail: str
    remote_url: str


class ReceiptVerifier:
    """Client for ``chain-determinism.org/verify/<hash>``.

    Uses ``httpx`` if available; falls back to ``urllib`` otherwise so
    callers do not strictly need the ``[http]`` extra.
    """

    def __init__(self, *, base_url: str = DEFAULT_VERIFIER_URL, timeout: float = 5.0):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Local — always works
    # ------------------------------------------------------------------

    def verify_local(
        self,
        receipt: Receipt,
        *,
        prev_receipt: Optional[Receipt] = None,
        require_signature: bool = True,
    ) -> VerifyResult:
        return verify_receipt(
            receipt,
            prev_receipt=prev_receipt,
            require_signature=require_signature,
        )

    # ------------------------------------------------------------------
    # Remote — endpoint not yet deployed
    # ------------------------------------------------------------------

    def verify_remote(self, receipt_or_hash: Receipt | str) -> RemoteVerifyResult:
        h = (
            receipt_hash(receipt_or_hash)
            if isinstance(receipt_or_hash, Receipt)
            else self._normalize_hash(receipt_or_hash)
        )
        url = f"{self.base_url}/verify/{h}"
        # Endpoint is not yet deployed for v0.1.0 — we surface that clearly
        # rather than spuriously returning False or hanging.
        raise EndpointNotDeployedError(
            f"verifier endpoint {url} is not yet deployed. "
            f"Use verify_local() for signature + chain validation. "
            f"Public verifier ships in chain-receipt-sdk >= 0.2.0."
        )

    def publish(self, receipt: Receipt) -> RemoteVerifyResult:
        h = receipt_hash(receipt)
        url = f"{self.base_url}/r/{h}"
        raise EndpointNotDeployedError(
            f"publish endpoint {url} is not yet deployed. "
            f"Receipts are stored locally at ~/.chain-receipt/chain.jsonl. "
            f"Public publish ships in chain-receipt-sdk >= 0.2.0."
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalize_hash(s: str) -> str:
        s = s.strip()
        if not s.startswith("sha256:"):
            return "sha256:" + s
        return s


__all__ = ["ReceiptVerifier", "RemoteVerifyResult", "EndpointNotDeployedError"]
