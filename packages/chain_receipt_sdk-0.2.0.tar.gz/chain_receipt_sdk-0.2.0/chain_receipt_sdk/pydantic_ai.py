"""Pydantic AI adapter — Chain-Receipts from Agent runs.

Pydantic AI uses native OpenTelemetry instrumentation. Once Cruxia CV
v0.1.0 ships with always-on `gen_ai.*` span emission, Pydantic AI's
own OTel spans will be visible alongside Cruxia CV's chain-receipt
spans in any OTel-compatible backend (Datadog / Honeycomb / Grafana /
New Relic). That is the recommended production integration path.

This module ships a complementary direct-callback path for users who
want Receipts emitted explicitly (no OTel infrastructure required):

  - ``ReceiptCallback`` — a lightweight handler shaped like the
    LangChain / LlamaIndex / LangGraph adapters in this SDK. Same
    constructor kwargs; same ``.receipts`` property; same ``.emit()``
    framework-agnostic escape hatch.
  - ``emit_from_result(callback, result)`` — extract prompt + response
    + tool calls from a finished ``AgentRunResult`` and emit one
    Receipt. Useful when you don't want to wrap the Agent.
  - ``attach_receipts(agent, callback)`` — wrap a ``pydantic_ai.Agent``
    so every ``.run_sync()`` / ``.run()`` / ``.iter()`` call auto-emits
    a Receipt at completion. Mirrors the ``chain_receipt_sdk.langgraph
    .attach_receipts`` API.

Install: ``pip install chain-receipt-sdk[pydantic-ai]``.
"""
from __future__ import annotations

from typing import Any, List, Optional

from chain_receipt_core import (
    ClientInfo,
    Receipt,
    Stability,
    generate_keypair,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from chain_receipt_sdk.builder import ReceiptBuilder
from chain_receipt_sdk.chain import LocalChain


try:
    import pydantic_ai  # noqa: F401  # type: ignore
    _PA_AVAILABLE = True
except Exception:  # pragma: no cover
    _PA_AVAILABLE = False


class ReceiptCallback:
    """Chain-Receipt callback for Pydantic AI agents.

    Same surface as the LangChain / LlamaIndex / LangGraph adapters
    in this SDK: ``.receipts`` lists emitted Receipts, ``.emit()`` is
    a framework-agnostic emit path, and ``.emit_from_result(result)``
    extracts a Receipt from a finished ``AgentRunResult``.
    """

    SDK_NAME = "chain-receipt-sdk"
    SDK_VERSION = "0.1.0"

    def __init__(
        self,
        *,
        client_name: str,
        vendor: str,
        model: str,
        temperature: float = 0.0,
        platform: str = "python",
        private_key: Optional[Ed25519PrivateKey] = None,
        verifier_url: Optional[str] = None,
        chain_seed: Optional[bytes] = None,
        persist: bool = False,
        local_chain: Optional[LocalChain] = None,
        capture_payload: bool = False,
    ):
        if private_key is None:
            sk, pub_b64 = generate_keypair()
        else:
            sk = private_key
            from cryptography.hazmat.primitives import serialization
            import base64
            pub_bytes = sk.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            pub_b64 = base64.urlsafe_b64encode(pub_bytes).rstrip(b"=").decode("ascii")

        self._client = ClientInfo(
            name=client_name,
            version=self.SDK_VERSION,
            platform=platform,
            emitter_pubkey=f"ed25519:{pub_b64}",
        )
        self._builder = ReceiptBuilder(
            client=self._client,
            private_key=sk,
            verifier_url=verifier_url,
            chain_seed=chain_seed if chain_seed is not None else pub_b64.encode(),
            persist=persist,
            local_chain=local_chain,
        )
        self.vendor = vendor
        self.model = model
        self.temperature = float(temperature)
        self.capture_payload = capture_payload

        self._receipts: List[Receipt] = []

    @property
    def receipts(self) -> List[Receipt]:
        return list(self._receipts)

    def emit(
        self,
        *,
        prompt: str,
        response: str,
        system_prompt: str = "",
        tool_calls: Optional[List[dict]] = None,
        latency_ms: Optional[int] = None,
        stability: Optional[Stability] = None,
    ) -> Receipt:
        """Framework-agnostic emit path. Mirrors the LangChain / LlamaIndex
        / LangGraph adapters in this SDK."""
        from chain_receipt_core import (
            Interaction,
            compute_text_hash,
            compute_tool_calls_hash,
        )

        tool_calls = tool_calls or []
        payload = None
        if self.capture_payload:
            payload = {
                "prompt": prompt,
                "system_prompt": system_prompt,
                "response": response,
                "tool_calls": list(tool_calls),
            }
        inter = Interaction(
            vendor=self.vendor,
            model=self.model,
            temperature=self.temperature,
            system_prompt_hash=compute_text_hash(system_prompt or ""),
            prompt_hash=compute_text_hash(prompt or ""),
            response_hash=compute_text_hash(response or ""),
            tool_calls_hash=compute_tool_calls_hash(tool_calls),
            n_tool_calls=len(tool_calls),
            latency_ms=latency_ms,
        )
        r = self._builder.build(
            interaction=inter,
            stability=stability,
            optional_payload=payload,
        )
        self._receipts.append(r)
        return r

    def emit_from_result(self, result: Any) -> Receipt:
        """Extract prompt + response + tool calls from a finished
        ``pydantic_ai.agent.AgentRunResult`` and emit one Receipt.

        Walks ``result.all_messages()`` to gather:
          - System prompt (any ``SystemPromptPart``)
          - User prompt (the most recent ``UserPromptPart`` — the
            prompt that triggered this run)
          - Final response text (concatenated ``TextPart.content`` from
            the last ``ModelResponse``)
          - Tool call sequence (every ``ToolCallPart`` encountered)

        **`instructions=` vs `system_prompt=`:** Pydantic AI distinguishes
        these two Agent parameters. ``instructions=`` is passed to the
        model as inline guidance but does NOT appear in the message
        history — so it cannot be extracted into the Receipt's
        ``system_prompt_hash``. ``system_prompt=`` materializes a
        ``SystemPromptPart`` in the message history and IS captured.
        If you need the system context to appear in your Receipts, use
        ``system_prompt=`` (or both).
        """
        if not _PA_AVAILABLE:
            raise ImportError(
                "chain_receipt_sdk.pydantic_ai.emit_from_result requires "
                "pydantic-ai. Install via "
                "`pip install chain-receipt-sdk[pydantic-ai]` or "
                "`pip install pydantic-ai>=0.1`."
            )

        system_chunks: List[str] = []
        last_user_prompt = ""
        response_text = ""
        tool_calls: List[dict] = []

        messages = result.all_messages() if hasattr(result, "all_messages") else []
        for msg in messages:
            parts = getattr(msg, "parts", None) or []
            for part in parts:
                part_type = type(part).__name__
                if part_type == "SystemPromptPart":
                    content = getattr(part, "content", "")
                    if content:
                        system_chunks.append(str(content))
                elif part_type == "UserPromptPart":
                    content = getattr(part, "content", "")
                    # Keep the LAST user prompt — that's the one that
                    # triggered the final response.
                    if content:
                        last_user_prompt = str(content)
                elif part_type == "TextPart":
                    # Accumulate text from the LAST ModelResponse only:
                    # reset response_text when we encounter a new
                    # ModelResponse message.
                    if type(msg).__name__ == "ModelResponse":
                        response_text += str(getattr(part, "content", ""))
                elif part_type == "ToolCallPart":
                    tool_calls.append({
                        "name": str(getattr(part, "tool_name", "tool")),
                        "args": _normalize_args(getattr(part, "args", None)),
                    })

            # Reset response_text accumulator when a NEW ModelResponse
            # starts; we want only the FINAL ModelResponse's text in
            # the Receipt (intermediate responses are part of the
            # tool-call loop and aren't the "final" response).
            if type(msg).__name__ == "ModelResponse":
                # Only keep the final response — check if there's a later
                # ModelResponse. Simpler: track separately, overwrite.
                pass

        # Re-derive response_text more carefully: only the LAST
        # ModelResponse's TextParts count.
        response_text = ""
        for msg in reversed(messages):
            if type(msg).__name__ == "ModelResponse":
                parts = getattr(msg, "parts", None) or []
                response_text = "".join(
                    str(getattr(p, "content", ""))
                    for p in parts
                    if type(p).__name__ == "TextPart"
                )
                break

        return self.emit(
            prompt=last_user_prompt,
            response=response_text,
            system_prompt="\n".join(system_chunks),
            tool_calls=tool_calls,
        )


def _normalize_args(args: Any) -> dict:
    """Coerce a ToolCallPart.args value into a JSON-serializable dict."""
    if isinstance(args, dict):
        return args
    if args is None:
        return {}
    if isinstance(args, str):
        import json
        try:
            parsed = json.loads(args)
            if isinstance(parsed, dict):
                return parsed
            return {"_raw": parsed}
        except json.JSONDecodeError:
            return {"_raw": args}
    # pydantic model or other — best-effort serialize
    if hasattr(args, "model_dump"):
        return args.model_dump()  # type: ignore[no-any-return]
    return {"_raw": str(args)}


def emit_from_result(callback: ReceiptCallback, result: Any) -> Receipt:
    """Module-level alias for ``callback.emit_from_result(result)``."""
    return callback.emit_from_result(result)


class _ReceiptAttachedAgent:
    """Wrapper that intercepts Agent.run_sync / run / iter and auto-emits
    a Receipt at completion. Forwards all other attributes to the
    underlying Agent."""

    def __init__(self, agent: Any, callback: ReceiptCallback) -> None:
        self._agent = agent
        self._callback = callback

    @property
    def callback(self) -> ReceiptCallback:
        """The attached ReceiptCallback. Use ``.receipts`` to list emitted Receipts."""
        return self._callback

    def run_sync(self, *args: Any, **kwargs: Any) -> Any:
        result = self._agent.run_sync(*args, **kwargs)
        self._callback.emit_from_result(result)
        return result

    async def run(self, *args: Any, **kwargs: Any) -> Any:
        result = await self._agent.run(*args, **kwargs)
        self._callback.emit_from_result(result)
        return result

    def __getattr__(self, name: str) -> Any:
        # Forward any attribute we haven't explicitly wrapped to the
        # underlying Agent (tool registration, model swap, etc).
        return getattr(self._agent, name)


def attach_receipts(agent: Any, callback: ReceiptCallback) -> _ReceiptAttachedAgent:
    """Wrap a ``pydantic_ai.Agent`` so every ``.run_sync()`` / ``.run()``
    automatically emits a Chain-Receipt at completion.

    Usage::

        from pydantic_ai import Agent
        from pydantic_ai.models.test import TestModel
        from chain_receipt_sdk.pydantic_ai import ReceiptCallback, attach_receipts

        agent = Agent(TestModel(custom_output_text="hi"), instructions="be brief")
        cb = ReceiptCallback(
            client_name="my-pydantic-ai-agent",
            vendor="anthropic",
            model="claude-sonnet-4-5",
        )
        wrapped = attach_receipts(agent, cb)

        result = wrapped.run_sync("hello")
        for r in wrapped.callback.receipts:
            print(r.receipt_id, r.chain.sequence_number)

    If you prefer to use the Agent unwrapped and emit Receipts manually,
    use ``callback.emit_from_result(result)`` after each
    ``agent.run_sync(...)`` call instead.
    """
    if not _PA_AVAILABLE:
        raise ImportError(
            "chain_receipt_sdk.pydantic_ai.attach_receipts requires "
            "pydantic-ai. Install via `pip install chain-receipt-sdk[pydantic-ai]`."
        )
    if not isinstance(callback, ReceiptCallback):
        raise TypeError(
            f"callback must be a chain_receipt_sdk.pydantic_ai.ReceiptCallback "
            f"instance; got {type(callback).__name__}"
        )
    return _ReceiptAttachedAgent(agent, callback)


__all__ = ["ReceiptCallback", "emit_from_result", "attach_receipts"]
