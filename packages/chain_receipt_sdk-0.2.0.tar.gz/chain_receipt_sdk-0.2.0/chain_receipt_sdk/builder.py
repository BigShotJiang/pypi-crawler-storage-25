"""SDK-side ReceiptBuilder helper.

The core ReceiptBuilder lives in `chain_receipt_core.builder.ReceiptBuilder`.
This module is an explicit re-export so callers can write
`from chain_receipt_sdk.builder import ReceiptBuilder` without learning
the core package layout. It also adds an opt-in `persist=True` mode that
appends each emitted Receipt to a `LocalChain`.
"""
from __future__ import annotations

from typing import Any, Optional

from chain_receipt_core import (
    Interaction,
    Receipt,
    Stability,
)
from chain_receipt_core import ReceiptBuilder as CoreReceiptBuilder

from chain_receipt_sdk.chain import LocalChain


class ReceiptBuilder(CoreReceiptBuilder):
    """Drop-in replacement for the core builder with optional local persistence.

    Set ``persist=True`` to append every emitted Receipt to a LocalChain
    (defaults to ``~/.chain-receipt/chain.jsonl`` or whatever
    ``CHAIN_RECEIPT_DIR`` points at). Pass an explicit ``local_chain`` to
    inject a custom storage location (useful for tests).
    """

    def __init__(
        self,
        *,
        persist: bool = False,
        local_chain: Optional[LocalChain] = None,
        **kwargs: Any,
    ):
        super().__init__(**kwargs)
        self._persist = persist
        self._local_chain: Optional[LocalChain] = (
            local_chain if local_chain is not None
            else (LocalChain() if persist else None)
        )

    def build(
        self,
        *,
        interaction: Interaction,
        stability: Optional[Stability] = None,
        optional_payload: Optional[dict[str, Any]] = None,
        receipt_id: Optional[str] = None,
        created_at: Optional[str] = None,
    ) -> Receipt:
        r = super().build(
            interaction=interaction,
            stability=stability,
            optional_payload=optional_payload,
            receipt_id=receipt_id,
            created_at=created_at,
        )
        if self._persist and self._local_chain is not None:
            self._local_chain.append(r)
        return r


__all__ = ["ReceiptBuilder"]
