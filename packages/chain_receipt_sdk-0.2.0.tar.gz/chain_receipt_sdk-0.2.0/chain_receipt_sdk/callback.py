"""LangChain callback handler that emits one Receipt per LLM call.

Lazy-imports ``langchain_core`` so that ``chain_receipt_sdk`` is usable
without it. If LangChain is installed, ``ReceiptCallback`` subclasses
``BaseCallbackHandler``; otherwise it's a duck-typed plain class.

Usage:

    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="my-langchain-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    chain.invoke("...", config={"callbacks": [cb]})

    for r in cb.receipts:
        print(r.receipt_id, r.interaction.tool_calls_hash)

The callback emits a Receipt at ``on_llm_end`` (or ``on_chain_end`` if
no LLM was directly called). Tool calls are accumulated from
``on_tool_start`` / ``on_tool_end`` between LLM events.
"""
from __future__ import annotations

import time
from typing import Any, List, Optional

from chain_receipt_core import (
    ClientInfo,
    Interaction,
    Receipt,
    Stability,
    compute_text_hash,
    compute_tool_calls_hash,
    generate_keypair,
)
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from chain_receipt_sdk.builder import ReceiptBuilder
from chain_receipt_sdk.chain import LocalChain


# Try to subclass BaseCallbackHandler when langchain-core is available.
try:
    from langchain_core.callbacks import BaseCallbackHandler  # type: ignore
    _LC_AVAILABLE = True
except Exception:  # pragma: no cover - exercised only when LC missing
    BaseCallbackHandler = object  # type: ignore
    _LC_AVAILABLE = False


class ReceiptCallback(BaseCallbackHandler):  # type: ignore[misc]
    """Emit one Receipt per LLM call observed via LangChain callbacks."""

    SDK_NAME = "chain-receipt-sdk"
    SDK_VERSION = "0.1.0"

    def __init__(
        self,
        *,
        client_name: str,
        vendor: str,
        model: str,
        temperature: float = 0.0,
        platform: str = "python",
        private_key: Optional[Ed25519PrivateKey] = None,
        verifier_url: Optional[str] = None,
        chain_seed: Optional[bytes] = None,
        persist: bool = False,
        local_chain: Optional[LocalChain] = None,
        capture_payload: bool = False,
    ):
        if private_key is None:
            sk, pub_b64 = generate_keypair()
        else:
            sk = private_key
            from cryptography.hazmat.primitives import serialization
            import base64
            pub_bytes = sk.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
            pub_b64 = base64.urlsafe_b64encode(pub_bytes).rstrip(b"=").decode("ascii")

        self._client = ClientInfo(
            name=client_name,
            version=self.SDK_VERSION,
            platform=platform,
            emitter_pubkey=f"ed25519:{pub_b64}",
        )
        self._builder = ReceiptBuilder(
            client=self._client,
            private_key=sk,
            verifier_url=verifier_url,
            chain_seed=chain_seed if chain_seed is not None else pub_b64.encode(),
            persist=persist,
            local_chain=local_chain,
        )
        self.vendor = vendor
        self.model = model
        self.temperature = float(temperature)
        self.capture_payload = capture_payload

        self._receipts: List[Receipt] = []
        self._pending_prompt: Optional[str] = None
        self._pending_system_prompt: Optional[str] = None
        self._pending_tool_calls: List[dict] = []
        self._t_start: Optional[float] = None

    # ------------------------------------------------------------------
    # Public surface
    # ------------------------------------------------------------------

    @property
    def receipts(self) -> List[Receipt]:
        return list(self._receipts)

    def emit(
        self,
        *,
        prompt: str,
        response: str,
        system_prompt: str = "",
        tool_calls: Optional[List[dict]] = None,
        latency_ms: Optional[int] = None,
        stability: Optional[Stability] = None,
    ) -> Receipt:
        """Manual emit path — use directly when no LangChain hook fires.

        Identical observable behaviour to a fully captured callback
        sequence; useful for non-LangChain agent loops.
        """
        tool_calls = tool_calls or []
        payload = None
        if self.capture_payload:
            payload = {
                "prompt": prompt,
                "system_prompt": system_prompt,
                "response": response,
                "tool_calls": list(tool_calls),
            }
        inter = Interaction(
            vendor=self.vendor,
            model=self.model,
            temperature=self.temperature,
            system_prompt_hash=compute_text_hash(system_prompt or ""),
            prompt_hash=compute_text_hash(prompt or ""),
            response_hash=compute_text_hash(response or ""),
            tool_calls_hash=compute_tool_calls_hash(tool_calls),
            n_tool_calls=len(tool_calls),
            latency_ms=latency_ms,
        )
        r = self._builder.build(
            interaction=inter,
            stability=stability,
            optional_payload=payload,
        )
        self._receipts.append(r)
        return r

    # ------------------------------------------------------------------
    # LangChain BaseCallbackHandler hooks
    # ------------------------------------------------------------------

    def on_llm_start(  # type: ignore[override]
        self,
        serialized: dict,
        prompts: List[str],
        **kwargs: Any,
    ) -> None:
        self._t_start = time.time()
        self._pending_prompt = prompts[0] if prompts else ""
        self._pending_tool_calls = []

    def on_chat_model_start(  # type: ignore[override]
        self,
        serialized: dict,
        messages: List[List[Any]],
        **kwargs: Any,
    ) -> None:
        self._t_start = time.time()
        flat = []
        sys_chunks = []
        for batch in messages:
            for m in batch:
                role = getattr(m, "type", None) or getattr(m, "role", "user")
                content = getattr(m, "content", str(m))
                if role in ("system", "SystemMessage"):
                    sys_chunks.append(str(content))
                else:
                    flat.append(str(content))
        self._pending_system_prompt = "\n".join(sys_chunks)
        self._pending_prompt = "\n".join(flat)
        self._pending_tool_calls = []

    def on_tool_start(  # type: ignore[override]
        self,
        serialized: dict,
        input_str: str,
        **kwargs: Any,
    ) -> None:
        name = (serialized or {}).get("name", "tool")
        try:
            import json as _json
            args = _json.loads(input_str) if input_str else {}
            if not isinstance(args, dict):
                args = {"_raw": args}
        except Exception:
            args = {"_raw": input_str}
        self._pending_tool_calls.append({"name": name, "args": args})

    def on_llm_end(self, response: Any, **kwargs: Any) -> None:  # type: ignore[override]
        # LangChain LLMResult has `.generations: List[List[Generation]]`
        text = ""
        try:
            gens = getattr(response, "generations", None) or []
            if gens and gens[0]:
                g0 = gens[0][0]
                text = getattr(g0, "text", "") or str(g0)
        except Exception:
            text = str(response)
        latency_ms = (
            int((time.time() - self._t_start) * 1000)
            if self._t_start is not None else None
        )
        self.emit(
            prompt=self._pending_prompt or "",
            response=text,
            system_prompt=self._pending_system_prompt or "",
            tool_calls=self._pending_tool_calls,
            latency_ms=latency_ms,
        )
        self._pending_prompt = None
        self._pending_system_prompt = None
        self._pending_tool_calls = []
        self._t_start = None


__all__ = ["ReceiptCallback"]
