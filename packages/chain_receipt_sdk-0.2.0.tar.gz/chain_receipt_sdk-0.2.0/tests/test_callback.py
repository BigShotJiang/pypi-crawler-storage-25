"""Smoke tests for ReceiptCallback.

Tests the callback in two modes:
  1. Manual emit (no LangChain dependency)
  2. LangChain BaseCallbackHandler hooks (only if langchain-core installed)
"""
from __future__ import annotations

import pytest

from chain_receipt_core import (
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)


# ----------------------------------------------------------------------------
# Manual emit path (always available)
# ----------------------------------------------------------------------------


def test_callback_manual_emit():
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
    )
    r = cb.emit(prompt="hello", response="hi", system_prompt="be brief")
    assert r.interaction.vendor == "anthropic"
    assert r.interaction.model == "claude-sonnet-4-5"
    assert r.interaction.prompt_hash == compute_text_hash("hello")
    assert r.interaction.response_hash == compute_text_hash("hi")
    assert r.interaction.system_prompt_hash == compute_text_hash("be brief")
    assert r.interaction.n_tool_calls == 0
    assert r.signature is not None
    assert len(cb.receipts) == 1


def test_callback_chain_links():
    """Sequential emits MUST chain: prev_receipt_hash == receipt_hash(prev)."""
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="openai",
        model="gpt-4.1",
    )
    r0 = cb.emit(prompt="q1", response="a1")
    r1 = cb.emit(prompt="q2", response="a2")
    r2 = cb.emit(prompt="q3", response="a3")

    assert r0.chain.sequence_number == 0
    assert r1.chain.sequence_number == 1
    assert r2.chain.sequence_number == 2

    assert r1.chain.prev_receipt_hash == receipt_hash(r0)
    assert r2.chain.prev_receipt_hash == receipt_hash(r1)
    assert r0.chain.chain_root_hash == r1.chain.chain_root_hash == r2.chain.chain_root_hash

    res = verify_chain([r0, r1, r2])
    assert res.ok, res.errors


def test_callback_with_tool_calls():
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    seq = [
        {"name": "lookup", "args": {"q": "x"}},
        {"name": "final_answer", "args": {"answer": "42"}},
    ]
    r = cb.emit(prompt="?", response="42", tool_calls=seq)
    assert r.interaction.n_tool_calls == 2
    assert r.interaction.tool_calls_hash == compute_tool_calls_hash(seq)


def test_callback_persist_to_local_chain(tmp_path, monkeypatch):
    """persist=True must write to ~/.chain-receipt/chain.jsonl."""
    monkeypatch.setenv("CHAIN_RECEIPT_DIR", str(tmp_path / "chain"))

    from chain_receipt_sdk.callback import ReceiptCallback
    from chain_receipt_sdk.chain import LocalChain

    chain = LocalChain()
    cb = ReceiptCallback(
        client_name="test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        persist=True,
        local_chain=chain,
    )
    cb.emit(prompt="q1", response="a1")
    cb.emit(prompt="q2", response="a2")

    persisted = chain.read_all()
    assert len(persisted) == 2
    assert persisted[1].chain.sequence_number == 1


def test_callback_capture_payload():
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="test-agent",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        capture_payload=True,
    )
    r = cb.emit(prompt="hello", response="world", system_prompt="sys")
    assert r.optional_payload is not None
    assert r.optional_payload["prompt"] == "hello"
    assert r.optional_payload["response"] == "world"
    assert r.optional_payload["system_prompt"] == "sys"


# ----------------------------------------------------------------------------
# LangChain hook path — real invocation via FakeListLLM / FakeListChatModel
# (skipped if langchain-core missing).
#
# Audit history (2026-05-12): the prior version of this test exercised the
# hooks manually via `cb.on_llm_start(...)` + `cb.on_llm_end(...)` because
# `RunnableLambda` (the README's then-quickstart) does not fire LLM
# callbacks. The audit at /tmp/cv-audit/langchain_audit.py confirmed the
# hooks DO fire correctly under a real LangChain LLM/ChatModel/LCEL
# chain invocation; this test replaces the manual-hook smoke with the
# real-invocation path so we catch any future regression where the
# callback fails to attach to genuine LangChain runnables.
# ----------------------------------------------------------------------------


lc = pytest.importorskip("langchain_core")


def test_callback_real_completion_llm():
    """Real LangChain completion LLM (FakeListLLM) fires on_llm_start +
    on_llm_end. ReceiptCallback should emit exactly one Receipt per
    `.invoke()` with prompt_hash hashing the user's raw prompt string.
    """
    from langchain_core.language_models.fake import FakeListLLM
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="lc-completion-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    llm = FakeListLLM(responses=["the answer is 42"])
    out = llm.invoke("what is 6 times 7?", config={"callbacks": [cb]})

    assert out == "the answer is 42"
    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.prompt_hash == compute_text_hash("what is 6 times 7?")
    assert r.interaction.response_hash == compute_text_hash("the answer is 42")
    assert r.signature is not None


def test_callback_real_chat_model():
    """Real LangChain chat model (FakeListChatModel) fires
    on_chat_model_start + on_llm_end. SystemMessage and HumanMessage
    should split into system_prompt_hash + prompt_hash respectively.
    """
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from langchain_core.messages import HumanMessage, SystemMessage
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="lc-chat-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    llm = FakeListChatModel(responses=["12345"])
    msgs = [
        SystemMessage(content="you are a calculator"),
        HumanMessage(content="2 plus 3"),
    ]
    llm.invoke(msgs, config={"callbacks": [cb]})

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.system_prompt_hash == compute_text_hash("you are a calculator")
    assert r.interaction.response_hash == compute_text_hash("12345")


def test_callback_real_lcel_chain():
    """LCEL chain (prompt | llm | parser) with 3 sequential .invoke()s
    should emit 3 chained Receipts (seq 0, 1, 2) that pass verify_chain.
    """
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.output_parsers import StrOutputParser
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="lc-lcel-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    llm = FakeListChatModel(responses=["resp 1", "resp 2", "resp 3"])
    prompt = ChatPromptTemplate.from_messages(
        [("system", "be terse"), ("human", "Q: {q}")]
    )
    chain = prompt | llm | StrOutputParser()
    chain.invoke({"q": "first"}, config={"callbacks": [cb]})
    chain.invoke({"q": "second"}, config={"callbacks": [cb]})
    chain.invoke({"q": "third"}, config={"callbacks": [cb]})

    assert len(cb.receipts) == 3
    rs = cb.receipts
    assert rs[0].chain.sequence_number == 0
    assert rs[1].chain.sequence_number == 1
    assert rs[2].chain.sequence_number == 2
    assert rs[1].chain.prev_receipt_hash == receipt_hash(rs[0])
    assert rs[2].chain.prev_receipt_hash == receipt_hash(rs[1])
    res = verify_chain(rs)
    assert res.ok, res.errors


def test_callback_real_invocation_with_payload_capture():
    """capture_payload=True under a real FakeListLLM invocation should
    populate optional_payload with prompt + response keys."""
    from langchain_core.language_models.fake import FakeListLLM
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="lc-payload-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        capture_payload=True,
    )
    llm = FakeListLLM(responses=["captured response"])
    llm.invoke("captured prompt", config={"callbacks": [cb]})

    assert len(cb.receipts) == 1
    payload = cb.receipts[0].optional_payload
    assert payload is not None
    assert payload["prompt"] == "captured prompt"
    assert payload["response"] == "captured response"


def test_callback_hooks_direct_simulation():
    """Direct hook simulation — preserved from earlier test to cover the
    case where a non-LangChain caller wants to drive the hooks manually
    (e.g., wrapping a vendor SDK call that doesn't go through LangChain).
    Exercises on_tool_start between LLM start/end events.
    """
    from chain_receipt_sdk.callback import ReceiptCallback

    cb = ReceiptCallback(
        client_name="manual-hook-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    cb.on_llm_start(
        serialized={"name": "FakeLLM"},
        prompts=["hello world"],
    )
    cb.on_tool_start(serialized={"name": "calc"}, input_str='{"x": 1}')

    class _Gen:
        text = "the answer is 42"

    class _LLMResult:
        generations = [[_Gen()]]

    cb.on_llm_end(_LLMResult())

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.n_tool_calls == 1
    assert r.interaction.prompt_hash == compute_text_hash("hello world")
