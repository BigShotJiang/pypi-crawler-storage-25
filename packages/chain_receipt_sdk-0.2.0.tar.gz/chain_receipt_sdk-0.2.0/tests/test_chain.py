"""LocalChain smoke tests."""
from __future__ import annotations

from chain_receipt_core import (
    Interaction,
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)
from chain_receipt_sdk.builder import ReceiptBuilder
from chain_receipt_sdk.chain import LocalChain


def _build_n(client_info, sk, n: int):
    chain = LocalChain()
    b = ReceiptBuilder(
        client=client_info,
        private_key=sk,
        chain_seed=b"test",
        persist=True,
        local_chain=chain,
    )
    receipts = []
    for i in range(n):
        inter = Interaction(
            vendor="anthropic",
            model="claude-sonnet-4-5",
            temperature=0.0,
            system_prompt_hash=compute_text_hash(""),
            prompt_hash=compute_text_hash(f"q{i}"),
            response_hash=compute_text_hash(f"a{i}"),
            tool_calls_hash=compute_tool_calls_hash([]),
            n_tool_calls=0,
            latency_ms=10,
        )
        receipts.append(b.build(interaction=inter))
    return receipts, chain


def test_local_chain_round_trip(client_info, keypair):
    sk, _pub = keypair
    receipts, chain = _build_n(client_info, sk, n=3)

    persisted = chain.read_all()
    assert len(persisted) == 3
    assert verify_chain(persisted).ok

    # Hashes round-trip
    for orig, loaded in zip(receipts, persisted):
        assert receipt_hash(orig) == receipt_hash(loaded)


def test_local_chain_find_by_hash(client_info, keypair):
    sk, _pub = keypair
    receipts, chain = _build_n(client_info, sk, n=3)
    target = receipt_hash(receipts[1])
    found = chain.find_by_hash(target)
    assert found is not None
    assert receipt_hash(found) == target


def test_local_chain_find_missing(client_info, keypair):
    sk, _pub = keypair
    _, chain = _build_n(client_info, sk, n=2)
    missing = "sha256:" + "0" * 64
    assert chain.find_by_hash(missing) is None


def test_local_chain_count_and_head(client_info, keypair):
    sk, _pub = keypair
    receipts, chain = _build_n(client_info, sk, n=3)
    assert chain.count() == 3
    head = chain.head()
    assert head is not None
    assert receipt_hash(head) == receipt_hash(receipts[-1])


def test_local_chain_empty(client_info, keypair):
    chain = LocalChain()
    assert chain.count() == 0
    assert chain.head() is None
    assert chain.read_all() == []
    assert chain.find_by_hash("sha256:" + "0" * 64) is None


def test_local_chain_tolerates_truncated_line(tmp_path, monkeypatch, client_info, keypair):
    monkeypatch.setenv("CHAIN_RECEIPT_DIR", str(tmp_path / "chain"))
    sk, _pub = keypair
    receipts, chain = _build_n(client_info, sk, n=2)
    # Append a truncated line — simulates a mid-write crash.
    with chain.path.open("a") as f:
        f.write('{"receipt_version":"1.0.0",')
    persisted = chain.read_all()
    assert len(persisted) == 2  # truncated line dropped
