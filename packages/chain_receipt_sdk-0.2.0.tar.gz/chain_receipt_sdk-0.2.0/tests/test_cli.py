"""CLI subcommand smoke tests."""
from __future__ import annotations

import io
import json
import os
import sys
from contextlib import redirect_stdout, redirect_stderr

import pytest

from chain_receipt_core import (
    Interaction,
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
)
from chain_receipt_sdk.builder import ReceiptBuilder
from chain_receipt_sdk.chain import LocalChain
from chain_receipt_sdk.cli import build_parser, main


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------


def _emit_n(client_info, sk, n: int, *, persist: bool, with_payload: bool = False):
    chain = LocalChain()
    b = ReceiptBuilder(
        client=client_info,
        private_key=sk,
        verifier_url="https://chain-determinism.org",
        chain_seed=b"cli-test",
        persist=persist,
        local_chain=chain,
    )
    receipts = []
    for i in range(n):
        inter = Interaction(
            vendor="anthropic",
            model="claude-sonnet-4-5",
            temperature=0.0,
            system_prompt_hash=compute_text_hash("sys"),
            prompt_hash=compute_text_hash(f"q{i}"),
            response_hash=compute_text_hash(f"a{i}"),
            tool_calls_hash=compute_tool_calls_hash([]),
            n_tool_calls=0,
            latency_ms=10,
        )
        payload = {"prompt": f"q{i}", "system_prompt": "sys"} if with_payload else None
        receipts.append(b.build(interaction=inter, optional_payload=payload))
    return receipts


def _run_cli(argv):
    buf = io.StringIO()
    err = io.StringIO()
    with redirect_stdout(buf), redirect_stderr(err):
        rc = main(argv)
    return rc, buf.getvalue(), err.getvalue()


# ----------------------------------------------------------------------------
# parser smoke
# ----------------------------------------------------------------------------


def test_parser_subcommands():
    p = build_parser()
    for cmd in ("status", "verify", "replay", "chain", "publish"):
        # Each subcommand should parse without raising
        if cmd == "status":
            ns = p.parse_args(["status"])
        elif cmd == "verify":
            ns = p.parse_args(["verify", "deadbeef"])
        elif cmd == "replay":
            ns = p.parse_args(["replay", "deadbeef", "--n", "3"])
        elif cmd == "chain":
            ns = p.parse_args(["chain", "--since", "2026-01-01T00:00:00Z"])
        elif cmd == "publish":
            ns = p.parse_args(["publish", "deadbeef"])
        assert ns.cmd == cmd


# ----------------------------------------------------------------------------
# status
# ----------------------------------------------------------------------------


def test_cli_status_empty():
    rc, out, err = _run_cli(["status"])
    assert rc == 0
    assert "chain-receipt-sdk" in out
    assert "<empty>" in out


def test_cli_status_with_receipts(client_info, keypair):
    sk, _pub = keypair
    _emit_n(client_info, sk, n=3, persist=True)
    rc, out, _err = _run_cli(["status"])
    assert rc == 0
    assert "count: 3" in out
    assert "sequence_number:  2" in out


# ----------------------------------------------------------------------------
# verify
# ----------------------------------------------------------------------------


def test_cli_verify_missing():
    rc, _out, err = _run_cli(["verify", "sha256:0000000000000000000000000000000000000000000000000000000000000000"])
    assert rc == 2
    assert "not found" in err


def test_cli_verify_signed_ok(client_info, keypair):
    sk, _pub = keypair
    rs = _emit_n(client_info, sk, n=2, persist=True)
    target = receipt_hash(rs[0])
    rc, out, _err = _run_cli(["verify", target])
    assert rc == 0
    assert "signature:  ok" in out
    # Endpoint not yet deployed — this is the expected behavior for v0.1.0.
    assert "not yet deployed" in out


def test_cli_verify_chain_link(client_info, keypair):
    sk, _pub = keypair
    rs = _emit_n(client_info, sk, n=3, persist=True)
    target = receipt_hash(rs[1])  # middle Receipt — has both prev and next
    rc, out, _err = _run_cli(["verify", target])
    assert rc == 0
    assert "chain link: ok" in out


# ----------------------------------------------------------------------------
# replay
# ----------------------------------------------------------------------------


def test_cli_replay_skipped_no_payload(client_info, keypair):
    sk, _pub = keypair
    rs = _emit_n(client_info, sk, n=1, persist=True, with_payload=False)
    target = receipt_hash(rs[0])
    rc, out, _err = _run_cli(["replay", target, "--n", "5"])
    assert rc == 0
    payload = json.loads(out)
    assert payload["method"] == "replay-skipped"
    assert payload["divergence_rate"] is None


def test_cli_replay_skipped_no_runner(client_info, keypair):
    sk, _pub = keypair
    rs = _emit_n(client_info, sk, n=1, persist=True, with_payload=True)
    target = receipt_hash(rs[0])
    rc, out, _err = _run_cli(["replay", target, "--n", "5"])
    assert rc == 0
    payload = json.loads(out)
    assert payload["method"] == "replay-skipped"
    assert "no runner" in payload["note"]


# ----------------------------------------------------------------------------
# chain
# ----------------------------------------------------------------------------


def test_cli_chain_text(client_info, keypair):
    sk, _pub = keypair
    _emit_n(client_info, sk, n=3, persist=True)
    rc, out, _err = _run_cli(["chain"])
    assert rc == 0
    assert "total: 3" in out


def test_cli_chain_json(client_info, keypair):
    sk, _pub = keypair
    _emit_n(client_info, sk, n=2, persist=True)
    rc, out, _err = _run_cli(["chain", "--json"])
    assert rc == 0
    rows = json.loads(out)
    assert len(rows) == 2
    assert rows[0]["sequence_number"] == 0


def test_cli_chain_since(client_info, keypair):
    sk, _pub = keypair
    _emit_n(client_info, sk, n=2, persist=True)
    # All Receipts are stamped "now" — a 1970 cutoff returns everything.
    rc, out, _err = _run_cli(["chain", "--since", "1970-01-01T00:00:00Z"])
    assert rc == 0
    assert "total: 2" in out
    # A future cutoff returns nothing.
    rc, out, _err = _run_cli(["chain", "--since", "2099-01-01T00:00:00Z"])
    assert rc == 0
    assert "total: 0" in out


# ----------------------------------------------------------------------------
# publish
# ----------------------------------------------------------------------------


def test_cli_publish_endpoint_not_deployed(client_info, keypair):
    sk, _pub = keypair
    rs = _emit_n(client_info, sk, n=1, persist=True)
    target = receipt_hash(rs[0])
    rc, out, _err = _run_cli(["publish", target])
    # Endpoint not deployed is NOT an error — it's an honest status report.
    assert rc == 0
    assert "not yet deployed" in out
    assert "local:      ok" in out


def test_cli_publish_missing():
    rc, _out, err = _run_cli(
        ["publish", "sha256:0000000000000000000000000000000000000000000000000000000000000000"]
    )
    assert rc == 2
    assert "not found" in err
