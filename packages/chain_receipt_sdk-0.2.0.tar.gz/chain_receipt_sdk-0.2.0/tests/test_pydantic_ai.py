"""Integration tests for chain_receipt_sdk.pydantic_ai.

Uses pydantic_ai.models.test.TestModel (the official test double) to
drive Agent.run_sync without burning API credits. Verifies:
  - emit_from_result extracts prompt + response + tool calls correctly
  - attach_receipts wrapper auto-emits a Receipt per run_sync call
  - Receipts chain across sequential runs; verify_chain holds

Skipped automatically if pydantic-ai is not installed.
"""
from __future__ import annotations

import pytest

from chain_receipt_core import (
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)


pa = pytest.importorskip("pydantic_ai")


def test_pa_emit_from_result_basic():
    """emit_from_result extracts the user prompt + final response text
    + system prompt from a finished AgentRunResult."""
    from pydantic_ai import Agent
    from pydantic_ai.models.test import TestModel
    from chain_receipt_sdk.pydantic_ai import ReceiptCallback

    agent = Agent(
        TestModel(custom_output_text="the answer is 42"),
        system_prompt="be brief",
    )
    result = agent.run_sync("what is 6 times 7?")

    cb = ReceiptCallback(
        client_name="pa-basic-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    r = cb.emit_from_result(result)

    assert r.interaction.prompt_hash == compute_text_hash("what is 6 times 7?")
    assert r.interaction.response_hash == compute_text_hash("the answer is 42")
    assert r.interaction.system_prompt_hash == compute_text_hash("be brief")
    assert r.signature is not None
    assert len(cb.receipts) == 1


def test_pa_attach_receipts_wraps_run_sync():
    """attach_receipts wraps Agent.run_sync; each call auto-emits a Receipt."""
    from pydantic_ai import Agent
    from pydantic_ai.models.test import TestModel
    from chain_receipt_sdk.pydantic_ai import ReceiptCallback, attach_receipts

    agent = Agent(
        TestModel(custom_output_text="wrapped response"),
        system_prompt="be brief",
    )
    cb = ReceiptCallback(
        client_name="pa-wrap-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    wrapped = attach_receipts(agent, cb)

    result = wrapped.run_sync("wrapped prompt")
    # The result is the unmodified AgentRunResult
    assert result.response.parts[0].content == "wrapped response"
    # And one Receipt was auto-emitted
    assert len(wrapped.callback.receipts) == 1
    r = wrapped.callback.receipts[0]
    assert r.interaction.prompt_hash == compute_text_hash("wrapped prompt")
    assert r.interaction.response_hash == compute_text_hash("wrapped response")


def test_pa_chain_integrity_across_runs():
    """Three sequential run_sync calls produce 3 chained Receipts that
    pass verify_chain end-to-end."""
    from pydantic_ai import Agent
    from pydantic_ai.models.test import TestModel
    from chain_receipt_sdk.pydantic_ai import ReceiptCallback, attach_receipts

    # TestModel can take a list of responses; rotate through them.
    # In current pydantic-ai TestModel API, custom_output_text is a single
    # string. We create separate agents to vary the response per run.
    cb = ReceiptCallback(
        client_name="pa-chain-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )

    for i, (q, ans) in enumerate([("q1", "a1"), ("q2", "a2"), ("q3", "a3")]):
        agent = Agent(TestModel(custom_output_text=ans), instructions="be brief")
        wrapped = attach_receipts(agent, cb)
        wrapped.run_sync(q)

    assert len(cb.receipts) == 3
    rs = cb.receipts
    assert rs[0].chain.sequence_number == 0
    assert rs[1].chain.sequence_number == 1
    assert rs[2].chain.sequence_number == 2
    assert rs[1].chain.prev_receipt_hash == receipt_hash(rs[0])
    assert rs[2].chain.prev_receipt_hash == receipt_hash(rs[1])
    res = verify_chain(rs)
    assert res.ok, res.errors


def test_pa_capture_payload():
    """capture_payload=True populates optional_payload with prompt + response."""
    from pydantic_ai import Agent
    from pydantic_ai.models.test import TestModel
    from chain_receipt_sdk.pydantic_ai import ReceiptCallback, attach_receipts

    agent = Agent(
        TestModel(custom_output_text="captured response"),
        system_prompt="sys-prompt",
    )
    cb = ReceiptCallback(
        client_name="pa-payload-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        capture_payload=True,
    )
    wrapped = attach_receipts(agent, cb)
    wrapped.run_sync("captured prompt")

    assert len(wrapped.callback.receipts) == 1
    payload = wrapped.callback.receipts[0].optional_payload
    assert payload is not None
    assert payload["prompt"] == "captured prompt"
    assert payload["response"] == "captured response"
    assert payload["system_prompt"] == "sys-prompt"


def test_pa_manual_emit_path():
    """Framework-agnostic .emit(...) works identically to other adapters."""
    from chain_receipt_sdk.pydantic_ai import ReceiptCallback

    cb = ReceiptCallback(
        client_name="pa-manual-emit",
        vendor="openai",
        model="gpt-4.1",
    )
    r = cb.emit(prompt="hello", response="hi", system_prompt="be brief")
    assert r.interaction.prompt_hash == compute_text_hash("hello")
    assert r.interaction.response_hash == compute_text_hash("hi")
    assert r.interaction.system_prompt_hash == compute_text_hash("be brief")
    assert len(cb.receipts) == 1


def test_pa_attach_receipts_type_check():
    """attach_receipts() rejects non-ReceiptCallback."""
    from chain_receipt_sdk.pydantic_ai import attach_receipts

    class FakeAgent:
        pass

    with pytest.raises(TypeError, match="must be a chain_receipt_sdk"):
        attach_receipts(FakeAgent(), object())  # type: ignore[arg-type]


def test_pa_emit_from_result_handles_tool_calls():
    """A run that included tool calls should populate tool_calls in the
    Receipt. Uses a TestModel-shaped tool to simulate."""
    from pydantic_ai import Agent
    from pydantic_ai.models.test import TestModel
    from chain_receipt_sdk.pydantic_ai import ReceiptCallback

    # Agent with a tool that the TestModel will call
    agent = Agent(TestModel(), instructions="use the tool")

    @agent.tool_plain
    def lookup(query: str) -> str:
        return f"result for {query}"

    # TestModel will auto-call the tool with a synthesized argument
    result = agent.run_sync("look up something")

    cb = ReceiptCallback(
        client_name="pa-tools-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    r = cb.emit_from_result(result)

    # TestModel auto-fills tool args, so at least one tool call was made.
    # We don't assert the exact count because TestModel's behaviour can
    # vary by version; we just want non-empty tool_calls_hash.
    if r.interaction.n_tool_calls > 0:
        # Tool calls were recorded — verify hash is consistent
        # with a non-empty sequence
        empty_hash = compute_tool_calls_hash([])
        assert r.interaction.tool_calls_hash != empty_hash


def test_pa_emit_from_result_missing_pydantic_ai(monkeypatch):
    """emit_from_result raises a clear ImportError if pydantic-ai is
    missing at runtime."""
    from chain_receipt_sdk import pydantic_ai as pa_module

    original = pa_module._PA_AVAILABLE
    monkeypatch.setattr(pa_module, "_PA_AVAILABLE", False)
    try:
        cb = pa_module.ReceiptCallback(
            client_name="x",
            vendor="anthropic",
            model="claude-sonnet-4-5",
        )
        with pytest.raises(ImportError, match="pydantic-ai"):
            cb.emit_from_result(object())
    finally:
        monkeypatch.setattr(pa_module, "_PA_AVAILABLE", original)
