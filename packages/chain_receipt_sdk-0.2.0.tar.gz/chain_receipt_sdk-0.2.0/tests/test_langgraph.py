"""Integration tests for chain_receipt_sdk.langgraph.

Verifies that:
  1. The existing LangChain ReceiptCallback propagates through LangGraph
     compilations when attached at compiled.invoke(config=...)
  2. The attach_receipts() helper correctly merges the callback into
     every invocation without requiring callers to thread config
  3. Multi-node graphs produce chained Receipts (one per LLM call)
  4. Conditional routing only emits Receipts for the chosen branch

Skipped automatically if langgraph is not installed.
"""
from __future__ import annotations

from typing import TypedDict

import pytest

from chain_receipt_core import compute_text_hash, receipt_hash, verify_chain


lg = pytest.importorskip("langgraph")


# Module-level TypedDicts so langgraph's get_type_hints() can resolve them
class _BasicState(TypedDict):
    question: str
    answer: str


class _ChainState(TypedDict):
    step: int
    last_response: str


class _RoutingState(TypedDict):
    choice: str
    result: str


def test_lg_callback_via_invoke_config():
    """Callbacks attached at compiled.invoke(config={'callbacks': [cb]})
    propagate to LLM calls inside nodes."""
    from langgraph.graph import StateGraph, START, END
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from chain_receipt_sdk.callback import ReceiptCallback

    llm = FakeListChatModel(responses=["the answer is 42"])

    def llm_node(state: _BasicState) -> dict:
        return {"answer": llm.invoke(state["question"]).content}

    graph = StateGraph(_BasicState)
    graph.add_node("llm", llm_node)
    graph.add_edge(START, "llm")
    graph.add_edge("llm", END)
    compiled = graph.compile()

    cb = ReceiptCallback(
        client_name="lg-invoke-config",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )

    result = compiled.invoke(
        {"question": "what is 6 times 7?"},
        config={"callbacks": [cb]},
    )

    assert result["answer"] == "the answer is 42"
    assert len(cb.receipts) == 1
    assert cb.receipts[0].interaction.prompt_hash == compute_text_hash("what is 6 times 7?")
    assert cb.receipts[0].interaction.response_hash == compute_text_hash("the answer is 42")


def test_lg_attach_receipts_helper():
    """The attach_receipts() helper wraps a compiled graph so every
    .invoke() automatically attaches the receipt callback."""
    from langgraph.graph import StateGraph, START, END
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from chain_receipt_sdk.langgraph import ReceiptCallback, attach_receipts

    llm = FakeListChatModel(responses=["wrapped response"])

    def llm_node(state: _BasicState) -> dict:
        return {"answer": llm.invoke(state["question"]).content}

    graph = StateGraph(_BasicState)
    graph.add_node("llm", llm_node)
    graph.add_edge(START, "llm")
    graph.add_edge("llm", END)
    compiled = graph.compile()

    cb = ReceiptCallback(
        client_name="lg-attach-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    wrapped = attach_receipts(compiled, cb)

    # No config={"callbacks": ...} passed by the caller — wrapper attaches it.
    result = wrapped.invoke({"question": "wrapped invocation"})

    assert result["answer"] == "wrapped response"
    assert len(wrapped.callback.receipts) == 1
    assert wrapped.callback.receipts[0].interaction.prompt_hash == compute_text_hash(
        "wrapped invocation"
    )


def test_lg_attach_receipts_merges_with_user_callbacks():
    """attach_receipts() must merge our callback into existing user
    callbacks rather than replacing them. Pass an extra callback at
    invoke time; both should fire."""
    from langgraph.graph import StateGraph, START, END
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from chain_receipt_sdk.langgraph import ReceiptCallback, attach_receipts

    class CountingCallback(BaseCallbackHandler):
        def __init__(self):
            self.n_starts = 0

        def on_chat_model_start(self, *args, **kwargs):
            self.n_starts += 1

    llm = FakeListChatModel(responses=["resp"])

    def llm_node(state: _BasicState) -> dict:
        return {"answer": llm.invoke(state["question"]).content}

    graph = StateGraph(_BasicState)
    graph.add_node("llm", llm_node)
    graph.add_edge(START, "llm")
    graph.add_edge("llm", END)
    compiled = graph.compile()

    cb = ReceiptCallback(
        client_name="lg-merge-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    extra_cb = CountingCallback()
    wrapped = attach_receipts(compiled, cb)

    wrapped.invoke({"question": "test"}, config={"callbacks": [extra_cb]})

    assert len(wrapped.callback.receipts) == 1, "ReceiptCallback should still fire"
    assert extra_cb.n_starts == 1, "user-supplied callback should also fire"


def test_lg_multi_node_chain():
    """Three-node graph: each LLM call produces one Receipt; receipts
    chain and verify_chain holds end-to-end."""
    from langgraph.graph import StateGraph, START, END
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from chain_receipt_sdk.langgraph import ReceiptCallback, attach_receipts

    llm = FakeListChatModel(responses=["r1", "r2", "r3"])

    def make_node(name):
        def _node(state: _ChainState) -> dict:
            resp = llm.invoke(f"node {name} step {state['step']}")
            return {
                "step": state["step"] + 1,
                "last_response": resp.content,
            }
        return _node

    graph = StateGraph(_ChainState)
    graph.add_node("a", make_node("a"))
    graph.add_node("b", make_node("b"))
    graph.add_node("c", make_node("c"))
    graph.add_edge(START, "a")
    graph.add_edge("a", "b")
    graph.add_edge("b", "c")
    graph.add_edge("c", END)
    compiled = graph.compile()

    cb = ReceiptCallback(
        client_name="lg-multi-node",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    wrapped = attach_receipts(compiled, cb)

    result = wrapped.invoke({"step": 0, "last_response": ""})
    assert result["step"] == 3
    assert len(wrapped.callback.receipts) == 3

    rs = wrapped.callback.receipts
    assert rs[0].chain.sequence_number == 0
    assert rs[1].chain.sequence_number == 1
    assert rs[2].chain.sequence_number == 2
    assert rs[1].chain.prev_receipt_hash == receipt_hash(rs[0])
    assert rs[2].chain.prev_receipt_hash == receipt_hash(rs[1])
    res = verify_chain(rs)
    assert res.ok, res.errors


def test_lg_conditional_routing():
    """Conditional routing: only the chosen branch emits a Receipt."""
    from langgraph.graph import StateGraph, START, END
    from langchain_core.language_models.fake_chat_models import FakeListChatModel
    from chain_receipt_sdk.langgraph import ReceiptCallback, attach_receipts

    llm_a = FakeListChatModel(responses=["from A"])
    llm_b = FakeListChatModel(responses=["from B"])

    def node_a(state: _RoutingState) -> dict:
        return {"result": llm_a.invoke("A path").content}

    def node_b(state: _RoutingState) -> dict:
        return {"result": llm_b.invoke("B path").content}

    def router(state: _RoutingState) -> str:
        return "node_a" if state["choice"] == "A" else "node_b"

    graph = StateGraph(_RoutingState)
    graph.add_node("node_a", node_a)
    graph.add_node("node_b", node_b)
    graph.add_conditional_edges(START, router, {"node_a": "node_a", "node_b": "node_b"})
    graph.add_edge("node_a", END)
    graph.add_edge("node_b", END)
    compiled = graph.compile()

    cb = ReceiptCallback(
        client_name="lg-routing",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    wrapped = attach_receipts(compiled, cb)

    result = wrapped.invoke({"choice": "A", "result": ""})
    assert result["result"] == "from A"
    assert len(wrapped.callback.receipts) == 1


def test_lg_attach_receipts_type_check():
    """attach_receipts() should reject non-ReceiptCallback callable."""
    from chain_receipt_sdk.langgraph import attach_receipts

    class FakeGraph:
        pass

    with pytest.raises(TypeError, match="must be a chain_receipt_sdk ReceiptCallback"):
        attach_receipts(FakeGraph(), object())  # type: ignore[arg-type]


def test_lg_attach_receipts_missing_langgraph(monkeypatch):
    """If langgraph isn't installed, attach_receipts() raises ImportError
    with a clear install hint."""
    from chain_receipt_sdk import langgraph as lg_module
    from chain_receipt_sdk.callback import ReceiptCallback

    original = lg_module._LG_AVAILABLE
    monkeypatch.setattr(lg_module, "_LG_AVAILABLE", False)
    try:
        cb = ReceiptCallback(
            client_name="x",
            vendor="anthropic",
            model="claude-sonnet-4-5",
        )
        with pytest.raises(ImportError, match="langgraph"):
            lg_module.attach_receipts(object(), cb)
    finally:
        monkeypatch.setattr(lg_module, "_LG_AVAILABLE", original)
