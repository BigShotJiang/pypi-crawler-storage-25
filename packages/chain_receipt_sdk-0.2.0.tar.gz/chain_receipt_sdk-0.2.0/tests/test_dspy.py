"""Integration tests for chain_receipt_sdk.dspy.

Uses dspy.utils.dummies.DummyLM (DSPy's official test double) to drive
the BaseCallback hooks without burning API credits.

Skipped automatically if dspy is not installed.
"""
from __future__ import annotations

import pytest

from chain_receipt_core import (
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)


dspy = pytest.importorskip("dspy")


# Each test configures its own DSPy settings via dspy.context() to
# avoid mutating global state across tests.


def _make_predict_program():
    """Build a simple QA Predict program used by multiple tests."""
    class QA(dspy.Signature):
        """answer in one phrase"""
        question = dspy.InputField()
        answer = dspy.OutputField()
    return dspy.Predict(QA)


def test_dspy_callback_basic_emit():
    """A single LM call via Predict should produce one Receipt with
    response_hash derived from the LM's output."""
    from dspy.utils.dummies import DummyLM
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-basic",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    lm = DummyLM([{"answer": "42"}])
    program = _make_predict_program()

    with dspy.context(lm=lm, callbacks=[cb]):
        result = program(question="what is 6*7?")

    assert result.answer == "42"
    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    # The user-message contains the field marker + question; we don't
    # assert the exact prompt_hash (DSPy templates it) but it must be
    # non-empty.
    assert r.interaction.prompt_hash != compute_text_hash("")
    # System prompt comes from the Signature docstring + structure block
    assert r.interaction.system_prompt_hash != compute_text_hash("")
    # Response contains the field-marker-formatted answer
    assert "42" in str(r.interaction.response_hash) or r.interaction.response_hash != compute_text_hash("")
    assert r.signature is not None


def test_dspy_callback_chain_integrity():
    """Three sequential Predict calls produce 3 chained Receipts that
    pass verify_chain end-to-end."""
    from dspy.utils.dummies import DummyLM
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-chain",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    lm = DummyLM([{"answer": "42"}, {"answer": "12"}, {"answer": "7"}])
    program = _make_predict_program()

    with dspy.context(lm=lm, callbacks=[cb]):
        for q in ["what is 6*7?", "what is 4*3?", "what is 14/2?"]:
            program(question=q)

    assert len(cb.receipts) == 3
    rs = cb.receipts
    assert rs[0].chain.sequence_number == 0
    assert rs[1].chain.sequence_number == 1
    assert rs[2].chain.sequence_number == 2
    assert rs[1].chain.prev_receipt_hash == receipt_hash(rs[0])
    assert rs[2].chain.prev_receipt_hash == receipt_hash(rs[1])
    res = verify_chain(rs)
    assert res.ok, res.errors


def test_dspy_callback_capture_payload():
    """capture_payload=True populates optional_payload with prompt + response."""
    from dspy.utils.dummies import DummyLM
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-payload",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        capture_payload=True,
    )
    lm = DummyLM([{"answer": "captured"}])
    program = _make_predict_program()

    with dspy.context(lm=lm, callbacks=[cb]):
        program(question="captured prompt")

    assert len(cb.receipts) == 1
    payload = cb.receipts[0].optional_payload
    assert payload is not None
    # The DSPy-templated prompt contains the user question; sanity-check
    # that the actual question text appears somewhere in the captured payload
    assert "captured prompt" in payload["prompt"]
    assert "captured" in payload["response"]


def test_dspy_callback_manual_emit():
    """The framework-agnostic .emit(...) path works without any DSPy call."""
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-manual",
        vendor="openai",
        model="gpt-4.1",
    )
    r = cb.emit(prompt="hello", response="hi", system_prompt="be brief")
    assert r.interaction.prompt_hash == compute_text_hash("hello")
    assert r.interaction.response_hash == compute_text_hash("hi")
    assert r.interaction.system_prompt_hash == compute_text_hash("be brief")
    assert len(cb.receipts) == 1


def test_dspy_callback_tool_call_accumulation():
    """on_tool_start events between two on_lm events should accumulate
    into the SECOND emitted Receipt and reset for the next."""
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-tools",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )

    class _Tool:
        name = "calc"

    # Simulate the DSPy event sequence directly (DummyLM doesn't emit
    # tool events; tool events come from DSPy ReAct / function-calling
    # paths which require a real LM).
    cb.on_lm_start("call-1", None, {"messages": [{"role": "user", "content": "p1"}]})
    cb.on_lm_end("call-1", ["r1"])

    cb.on_tool_start("tool-1", _Tool(), {"x": 1, "y": 2})
    cb.on_tool_end("tool-1", {"result": 3})

    cb.on_lm_start("call-2", None, {"messages": [{"role": "user", "content": "p2"}]})
    cb.on_lm_end("call-2", ["r2"])

    assert len(cb.receipts) == 2
    r0, r1 = cb.receipts
    assert r0.interaction.n_tool_calls == 0
    assert r1.interaction.n_tool_calls == 1
    expected = [{"name": "calc", "args": {"x": 1, "y": 2}}]
    assert r1.interaction.tool_calls_hash == compute_tool_calls_hash(expected)


def test_dspy_callback_handles_dict_messages():
    """The adapter handles both dict-shaped messages (DSPy's typical
    shape) and object-shaped messages with .role/.content attributes."""
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-msg-shape",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    cb.on_lm_start(
        "call-1",
        None,
        {
            "messages": [
                {"role": "system", "content": "you are a calc"},
                {"role": "user", "content": "2+3?"},
            ],
        },
    )
    cb.on_lm_end("call-1", ["5"])

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.system_prompt_hash == compute_text_hash("you are a calc")
    assert r.interaction.prompt_hash == compute_text_hash("2+3?")
    assert r.interaction.response_hash == compute_text_hash("5")


def test_dspy_callback_handles_completion_style_prompt():
    """When DSPy passes inputs={'prompt': '...'} (completion-style),
    the adapter extracts the prompt and emits a Receipt."""
    from chain_receipt_sdk.dspy import ReceiptCallback

    cb = ReceiptCallback(
        client_name="dspy-completion",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    cb.on_lm_start("call-1", None, {"prompt": "raw completion prompt", "messages": None})
    cb.on_lm_end("call-1", ["raw completion response"])

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.prompt_hash == compute_text_hash("raw completion prompt")
    assert r.interaction.response_hash == compute_text_hash("raw completion response")


def test_dspy_callback_missing_dspy(monkeypatch):
    """If dspy is missing at runtime, instantiating ReceiptCallback
    raises a clear ImportError with the install hint."""
    from chain_receipt_sdk import dspy as dspy_module

    original = dspy_module._DSPY_AVAILABLE
    monkeypatch.setattr(dspy_module, "_DSPY_AVAILABLE", False)
    try:
        with pytest.raises(ImportError, match="dspy"):
            dspy_module.ReceiptCallback(
                client_name="x",
                vendor="anthropic",
                model="claude-sonnet-4-5",
            )
    finally:
        monkeypatch.setattr(dspy_module, "_DSPY_AVAILABLE", original)
