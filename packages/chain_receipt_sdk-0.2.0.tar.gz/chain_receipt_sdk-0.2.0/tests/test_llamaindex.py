"""Integration tests for chain_receipt_sdk.llamaindex.ReceiptCallback.

Drives the LlamaIndex callback through a real CallbackManager dispatch
(without needing a live LLM API call). Mirrors the structure of
test_callback.py's real-invocation tests for the LangChain callback.

Skipped automatically if llama-index-core is not installed.
"""
from __future__ import annotations

import pytest

from chain_receipt_core import (
    compute_text_hash,
    compute_tool_calls_hash,
    receipt_hash,
    verify_chain,
)


li_core = pytest.importorskip("llama_index.core")


def test_li_callback_completion_style():
    """CBEventType.LLM with EventPayload.PROMPT + EventPayload.COMPLETION
    on end. Mirrors what a non-chat LlamaIndex LLM emits."""
    from llama_index.core.callbacks import CallbackManager, CBEventType, EventPayload
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="li-completion-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        temperature=0.0,
    )
    cm = CallbackManager([cb])

    class FakeCompletion:
        text = "the answer is 42"

    with cm.event(
        CBEventType.LLM,
        payload={EventPayload.PROMPT: "what is 6 times 7?"},
    ) as event:
        event.on_end(payload={EventPayload.COMPLETION: FakeCompletion()})

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.prompt_hash == compute_text_hash("what is 6 times 7?")
    assert r.interaction.response_hash == compute_text_hash("the answer is 42")
    assert r.signature is not None


def test_li_callback_chat_style():
    """CBEventType.LLM with EventPayload.MESSAGES (chat-style) and
    EventPayload.RESPONSE (ChatResponse-shaped) on end. System +
    user messages should split into separate hashes."""
    from llama_index.core.callbacks import CallbackManager, CBEventType, EventPayload
    from llama_index.core.base.llms.types import ChatMessage, MessageRole
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="li-chat-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    cm = CallbackManager([cb])

    messages = [
        ChatMessage(role=MessageRole.SYSTEM, content="you are a calculator"),
        ChatMessage(role=MessageRole.USER, content="2 plus 3"),
    ]

    class FakeAIMsg:
        content = "12345"

    class FakeChatResponse:
        message = FakeAIMsg()

    with cm.event(
        CBEventType.LLM,
        payload={EventPayload.MESSAGES: messages},
    ) as event:
        event.on_end(payload={EventPayload.RESPONSE: FakeChatResponse()})

    assert len(cb.receipts) == 1
    r = cb.receipts[0]
    assert r.interaction.system_prompt_hash == compute_text_hash("you are a calculator")
    assert r.interaction.prompt_hash == compute_text_hash("2 plus 3")
    assert r.interaction.response_hash == compute_text_hash("12345")


def test_li_callback_function_call_accumulation():
    """CBEventType.FUNCTION_CALL events between two CBEventType.LLM
    events should accumulate into the SECOND LLM event's tool_calls_hash
    and reset for the next round."""
    from llama_index.core.callbacks import CallbackManager, CBEventType, EventPayload
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="li-toolcalls-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    cm = CallbackManager([cb])

    class FakeC:
        def __init__(self, t):
            self.text = t

    # First LLM event — no tools accumulated yet
    with cm.event(
        CBEventType.LLM,
        payload={EventPayload.PROMPT: "round 1"},
    ) as event:
        event.on_end(payload={EventPayload.COMPLETION: FakeC("r1")})

    # Two function calls between LLM events
    with cm.event(
        CBEventType.FUNCTION_CALL,
        payload={EventPayload.FUNCTION_CALL: {"name": "calc", "arguments": {"x": 1, "y": 2}}},
    ):
        pass
    with cm.event(
        CBEventType.FUNCTION_CALL,
        payload={EventPayload.FUNCTION_CALL: {"name": "lookup", "arguments": {"q": "x"}}},
    ):
        pass

    # Second LLM event — picks up both function calls
    with cm.event(
        CBEventType.LLM,
        payload={EventPayload.PROMPT: "round 2"},
    ) as event:
        event.on_end(payload={EventPayload.COMPLETION: FakeC("r2")})

    assert len(cb.receipts) == 2
    r0, r1 = cb.receipts
    assert r0.interaction.n_tool_calls == 0
    assert r1.interaction.n_tool_calls == 2

    expected_seq = [
        {"name": "calc", "args": {"x": 1, "y": 2}},
        {"name": "lookup", "args": {"q": "x"}},
    ]
    assert r1.interaction.tool_calls_hash == compute_tool_calls_hash(expected_seq)


def test_li_callback_chain_integrity():
    """Three sequential LLM events produce a 3-link chain that
    verify_chain accepts end-to-end."""
    from llama_index.core.callbacks import CallbackManager, CBEventType, EventPayload
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="li-chain-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
    )
    cm = CallbackManager([cb])

    class FakeC:
        def __init__(self, t):
            self.text = t

    for p, r in [("p1", "r1"), ("p2", "r2"), ("p3", "r3")]:
        with cm.event(
            CBEventType.LLM,
            payload={EventPayload.PROMPT: p},
        ) as event:
            event.on_end(payload={EventPayload.COMPLETION: FakeC(r)})

    assert len(cb.receipts) == 3
    rs = cb.receipts
    assert rs[0].chain.sequence_number == 0
    assert rs[1].chain.sequence_number == 1
    assert rs[2].chain.sequence_number == 2
    assert rs[1].chain.prev_receipt_hash == receipt_hash(rs[0])
    assert rs[2].chain.prev_receipt_hash == receipt_hash(rs[1])
    res = verify_chain(rs)
    assert res.ok, res.errors


def test_li_callback_capture_payload():
    """capture_payload=True under a real LlamaIndex dispatch populates
    optional_payload with prompt + response keys."""
    from llama_index.core.callbacks import CallbackManager, CBEventType, EventPayload
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="li-payload-test",
        vendor="anthropic",
        model="claude-sonnet-4-5",
        capture_payload=True,
    )
    cm = CallbackManager([cb])

    class FakeC:
        text = "captured response"

    with cm.event(
        CBEventType.LLM,
        payload={EventPayload.PROMPT: "captured prompt"},
    ) as event:
        event.on_end(payload={EventPayload.COMPLETION: FakeC()})

    assert len(cb.receipts) == 1
    payload = cb.receipts[0].optional_payload
    assert payload is not None
    assert payload["prompt"] == "captured prompt"
    assert payload["response"] == "captured response"


def test_li_callback_manual_emit_path():
    """The framework-agnostic .emit(...) path mirrors the LangChain
    callback — same behaviour, useful for non-LlamaIndex code paths
    within a LlamaIndex-using application."""
    from chain_receipt_sdk.llamaindex import ReceiptCallback

    cb = ReceiptCallback(
        client_name="li-manual-emit-test",
        vendor="openai",
        model="gpt-4.1",
    )
    r = cb.emit(prompt="hello", response="hi", system_prompt="be brief")
    assert r.interaction.prompt_hash == compute_text_hash("hello")
    assert r.interaction.response_hash == compute_text_hash("hi")
    assert r.interaction.system_prompt_hash == compute_text_hash("be brief")
    assert len(cb.receipts) == 1


def test_li_callback_import_without_llamaindex(monkeypatch):
    """If llama-index-core is missing at runtime, instantiating
    ReceiptCallback should raise a clear ImportError directing the user
    to the optional-dep install path. Verifies the lazy-import guard."""
    # Monkey-patch the _LI_AVAILABLE flag to simulate missing dep
    from chain_receipt_sdk import llamaindex as li_module

    original = li_module._LI_AVAILABLE
    monkeypatch.setattr(li_module, "_LI_AVAILABLE", False)
    try:
        with pytest.raises(ImportError, match="llama-index-core"):
            li_module.ReceiptCallback(
                client_name="x",
                vendor="anthropic",
                model="claude-sonnet-4-5",
            )
    finally:
        monkeypatch.setattr(li_module, "_LI_AVAILABLE", original)
