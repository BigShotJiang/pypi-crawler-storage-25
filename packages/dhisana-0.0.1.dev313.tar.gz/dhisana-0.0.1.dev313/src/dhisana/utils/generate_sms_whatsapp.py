import re
from datetime import datetime, timezone
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict

from dhisana.schemas.sales import (
    CampaignContext,
    ChannelType,
    ContentGenerationContext,
    ConversationContext,
    Lead,
    MessageGenerationInstructions,
    MessageItem,
    SenderInfo,
)
from dhisana.utils.generate_email import _sanitize_lead_for_prompt
from dhisana.utils.generate_structured_output_internal import (
    get_structured_output_internal,
    get_structured_output_with_assistant_and_vector_store,
)

DEFAULT_SMS_GEN_MODEL = "gpt-5.5-1"

SMS_CHAR_LIMIT = 160
WHATSAPP_CHAR_LIMIT = 1000

# Standard opt-out suffix appended to every generated message.
OPT_OUT_SUFFIX_SMS = "\nReply STOP to opt out."
OPT_OUT_SUFFIX_WHATSAPP = "\nReply STOP to opt out."


class SMSWhatsAppCopy(BaseModel):
    body: str

    model_config = ConfigDict(extra="forbid")


def _effective_char_limit(channel_type: ChannelType) -> int:
    if channel_type == ChannelType.WHATSAPP:
        return WHATSAPP_CHAR_LIMIT
    return SMS_CHAR_LIMIT


def _opt_out_suffix(channel_type: ChannelType) -> str:
    if channel_type == ChannelType.WHATSAPP:
        return OPT_OUT_SUFFIX_WHATSAPP
    return OPT_OUT_SUFFIX_SMS


# Matches explicit opt-out instructions like "Reply STOP", "Text STOP to …",
# "opt out", or "unsubscribe" — requires an action verb before "stop" so
# normal prose like "stop wasting time" does not suppress the footer.
_OPT_OUT_RE = re.compile(
    r"(?:reply|text|send|message|say)\s+stop\b"
    r"|\bopt[\s\-]?out\b"
    r"|\bunsubscribe\b",
    re.IGNORECASE,
)


def _ensure_opt_out(body: str, channel_type: ChannelType) -> str:
    suffix = _opt_out_suffix(channel_type)
    if _OPT_OUT_RE.search(body):
        return body
    return body.rstrip() + suffix


def _cleanup_context(
    ctx: ContentGenerationContext,
) -> ContentGenerationContext:
    clone = ctx.model_copy(deep=True)
    if clone.external_known_data:
        clone.external_known_data.external_openai_vector_store_id = None
    return clone


async def generate_sms_whatsapp_copy(
    message_context: ContentGenerationContext,
    message_instructions: MessageGenerationInstructions,
    variation_text: str,
    channel_type: ChannelType,
    tool_config: Optional[List[Dict]] = None,
) -> dict:
    cleaned = _cleanup_context(message_context)

    user_instructions = (
        message_instructions.instructions_to_generate_message or ""
    ).strip()
    selected_instructions = user_instructions if user_instructions else variation_text

    lead_data = cleaned.lead_info or Lead()
    sender_data = cleaned.sender_info or SenderInfo()
    campaign_data = cleaned.campaign_context or CampaignContext()
    conversation_data = (
        cleaned.current_conversation_context or ConversationContext()
    )

    char_limit = _effective_char_limit(channel_type)
    opt_out_suffix = _opt_out_suffix(channel_type)
    usable_chars = char_limit - len(opt_out_suffix)
    channel_label = "WhatsApp" if channel_type == ChannelType.WHATSAPP else "SMS"

    prompt = f"""You are an AI sales copywriter. Your task is to write exactly one personalized outbound business {channel_label} text message on behalf of the sender to the lead described below.

This is a legitimate B2B sales outreach message. The sender has opted in to sending these messages through our platform.

## Channel Rules — {channel_label}

1. The message body (excluding the compliance footer) MUST be {usable_chars} characters or fewer.
2. Plain text only — no HTML, no markdown, no emojis unless the instructions ask for them.
3. No subject line — output only a "body" field.
4. Be concise and conversational. Lead with value, not a greeting. Avoid filler.
5. Do NOT include any opt-out / STOP language — the system appends it automatically.
6. Do NOT include phone numbers, email addresses, or links unless the writing instructions explicitly request a specific provided URL.
7. Ground every claim in the provided context. When information is missing, omit it — never guess or fabricate.
8. Do not use em dashes.
9. The "body" field must contain ONLY the message text. Never append JSON, metadata, or structured data to the body.

## Lead

Name: {lead_data.first_name or ''} {lead_data.last_name or ''}
Organization: {lead_data.organization_name or ''}
Title: {lead_data.job_title or ''}

## Sender (closed set — use ONLY these facts)

- Full Name: {sender_data.sender_full_name or ''}
- First Name: {sender_data.sender_first_name or ''}
- Last Name: {sender_data.sender_last_name or ''}
- Bio: {sender_data.sender_bio or ''}

## Campaign

- Product: {campaign_data.product_name or ''}
- Value Proposition: {campaign_data.value_prop or ''}
- Call to Action: {campaign_data.call_to_action or ''}
- Pain Points: {campaign_data.pain_points or []}
- Proof Points: {campaign_data.proof_points or []}

## Writing Instructions

{selected_instructions}

## Conversation History

{conversation_data.current_email_thread or ''}
{conversation_data.current_linkedin_thread or ''}

## Output Format

Return JSON with a single field: "body" (string, plain text, max {usable_chars} chars).

## Additional Lead Context (reference only)

{_sanitize_lead_for_prompt(lead_data)}
"""

    vector_store_id = (
        message_context.external_known_data.external_openai_vector_store_id
        if message_context.external_known_data
        else None
    )
    use_cache = (
        message_context.message_instructions.use_cache
        if message_context.message_instructions
        else True
    )

    if vector_store_id:
        response, status = (
            await get_structured_output_with_assistant_and_vector_store(
                prompt=prompt,
                response_format=SMSWhatsAppCopy,
                vector_store_id=vector_store_id,
                model=DEFAULT_SMS_GEN_MODEL,
                effort="medium",
                tool_config=tool_config,
                use_cache=use_cache,
            )
        )
    else:
        response, status = await get_structured_output_internal(
            prompt=prompt,
            response_format=SMSWhatsAppCopy,
            model=DEFAULT_SMS_GEN_MODEL,
            effort="medium",
            tool_config=tool_config,
            use_cache=use_cache,
        )

    if status != "SUCCESS":
        # Include the refusal/error detail if the model returned text
        detail = ""
        if isinstance(response, str) and response:
            detail = f" Model response: {response[:200]}"
        raise Exception(
            f"Error: Could not generate {channel_label} message.{detail}"
        )

    body = (response.body or "").strip()
    # Truncate if model exceeded the limit
    if len(body) > usable_chars:
        body = body[:usable_chars].rsplit(" ", 1)[0]
    body = _ensure_opt_out(body, channel_type)

    response_item = MessageItem(
        message_id="",
        thread_id="",
        sender_name=sender_data.sender_full_name or "",
        sender_email=sender_data.sender_email or "",
        receiver_name=(message_context.lead_info.full_name or "") if message_context.lead_info else "",
        receiver_email=(message_context.lead_info.email or "") if message_context.lead_info else "",
        iso_datetime=datetime.now(timezone.utc).isoformat(),
        subject="",
        body=body,
        html_body=None,
    )
    return response_item.model_dump()


FRAMEWORK_VARIATIONS_SMS = [
    "Write a brief, personalized outreach message. Lead with a relevant insight about the prospect's company.",
    "Write a short value-first message — mention one pain point and how the product helps.",
    "Write a concise, curiosity-driven message with a clear call to action.",
]


async def generate_sms_whatsapp_message(
    generation_context: ContentGenerationContext,
    number_of_variations: int = 3,
    tool_config: Optional[List[Dict]] = None,
) -> List[dict]:
    channel_type = generation_context.target_channel_type or ChannelType.SMS
    message_instructions = generation_context.message_instructions
    user_instructions_exist = bool(
        (message_instructions.instructions_to_generate_message or "").strip()
    )

    variations: List[dict] = []
    for i in range(number_of_variations):
        if user_instructions_exist:
            variation_text = (
                message_instructions.instructions_to_generate_message or ""
            )
        else:
            variation_text = FRAMEWORK_VARIATIONS_SMS[
                i % len(FRAMEWORK_VARIATIONS_SMS)
            ]

        copy = await generate_sms_whatsapp_copy(
            message_context=generation_context,
            message_instructions=message_instructions,
            variation_text=variation_text,
            channel_type=channel_type,
            tool_config=tool_config,
        )
        variations.append(copy)

    return variations
