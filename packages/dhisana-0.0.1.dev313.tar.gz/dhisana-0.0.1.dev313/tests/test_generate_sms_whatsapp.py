import asyncio
import unittest
from unittest.mock import AsyncMock, patch

from dhisana.schemas.sales import (
    CampaignContext,
    ChannelType,
    ContentGenerationContext,
    ConversationContext,
    Lead,
    MessageGenerationInstructions,
    SenderInfo,
)
from dhisana.utils.generate_sms_whatsapp import (
    OPT_OUT_SUFFIX_SMS,
    OPT_OUT_SUFFIX_WHATSAPP,
    SMS_CHAR_LIMIT,
    SMSWhatsAppCopy,
    WHATSAPP_CHAR_LIMIT,
    _effective_char_limit,
    _ensure_opt_out,
    generate_sms_whatsapp_copy,
    generate_sms_whatsapp_message,
)


def _build_context(channel: ChannelType = ChannelType.SMS) -> ContentGenerationContext:
    lead = Lead(
        full_name="Jane Smith",
        first_name="Jane",
        last_name="Smith",
        email="jane@acmecorp.com",
        job_title="VP of Engineering",
        organization_name="Acme Corp",
        phone="404-555-1234",
    )
    sender = SenderInfo(
        sender_full_name="John Doe",
        sender_first_name="John",
        sender_last_name="Doe",
        sender_email="john@dhisana.ai",
        sender_bio="Co-founder at Dhisana",
    )
    campaign = CampaignContext(
        product_name="Dhisana AI",
        value_prop="AI-powered sales outreach",
        call_to_action="Book a demo",
    )
    instructions = MessageGenerationInstructions(
        instructions_to_generate_message="Write a brief intro message.",
        use_cache=False,
        allow_html=False,
    )
    return ContentGenerationContext(
        lead_info=lead,
        sender_info=sender,
        campaign_context=campaign,
        current_conversation_context=ConversationContext(),
        target_channel_type=channel,
        message_instructions=instructions,
    )


class TestCharLimits(unittest.TestCase):
    def test_sms_limit(self):
        self.assertEqual(_effective_char_limit(ChannelType.SMS), SMS_CHAR_LIMIT)

    def test_whatsapp_limit(self):
        self.assertEqual(_effective_char_limit(ChannelType.WHATSAPP), WHATSAPP_CHAR_LIMIT)


class TestOptOut(unittest.TestCase):
    def test_appends_opt_out_to_sms(self):
        result = _ensure_opt_out("Hi there!", ChannelType.SMS)
        self.assertTrue(result.endswith(OPT_OUT_SUFFIX_SMS))

    def test_appends_opt_out_to_whatsapp(self):
        result = _ensure_opt_out("Hi there!", ChannelType.WHATSAPP)
        self.assertTrue(result.endswith(OPT_OUT_SUFFIX_WHATSAPP))

    def test_skips_when_reply_stop_present(self):
        msg = "Reply STOP to unsubscribe."
        result = _ensure_opt_out(msg, ChannelType.SMS)
        self.assertEqual(result, msg)

    def test_skips_when_text_stop_present(self):
        msg = "Text STOP to cancel."
        result = _ensure_opt_out(msg, ChannelType.SMS)
        self.assertEqual(result, msg)

    def test_skips_when_opt_out_present(self):
        msg = "You may opt out at any time."
        result = _ensure_opt_out(msg, ChannelType.SMS)
        self.assertEqual(result, msg)

    def test_skips_when_opt_hyphen_out_present(self):
        msg = "Text opt-out to stop receiving messages."
        result = _ensure_opt_out(msg, ChannelType.SMS)
        self.assertEqual(result, msg)

    def test_skips_when_unsubscribe_present(self):
        msg = "Reply unsubscribe to stop."
        result = _ensure_opt_out(msg, ChannelType.WHATSAPP)
        self.assertEqual(result, msg)

    def test_does_not_skip_for_stop_in_normal_prose(self):
        msg = "Stop wasting hours on manual outreach."
        result = _ensure_opt_out(msg, ChannelType.SMS)
        self.assertTrue(result.endswith(OPT_OUT_SUFFIX_SMS))

    def test_does_not_skip_for_stop_mid_sentence(self):
        msg = "Let us help you stop losing deals."
        result = _ensure_opt_out(msg, ChannelType.WHATSAPP)
        self.assertTrue(result.endswith(OPT_OUT_SUFFIX_WHATSAPP))


class TestGenerateSMSWhatsAppCopy(unittest.TestCase):
    def test_sms_generation_single_copy(self):
        ctx = _build_context(ChannelType.SMS)
        mock_response = SMSWhatsAppCopy(body="Hey Jane, quick question about Acme's outreach.")

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(mock_response, "SUCCESS"),
        ):
            result = asyncio.get_event_loop().run_until_complete(
                generate_sms_whatsapp_copy(
                    message_context=ctx,
                    message_instructions=ctx.message_instructions,
                    variation_text="Write a brief message.",
                    channel_type=ChannelType.SMS,
                )
            )
        self.assertIn("body", result)
        self.assertEqual(result["subject"], "")
        self.assertIn("STOP", result["body"])

    def test_whatsapp_generation_single_copy(self):
        ctx = _build_context(ChannelType.WHATSAPP)
        mock_response = SMSWhatsAppCopy(body="Hi Jane, Dhisana AI can help Acme automate outreach.")

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(mock_response, "SUCCESS"),
        ):
            result = asyncio.get_event_loop().run_until_complete(
                generate_sms_whatsapp_copy(
                    message_context=ctx,
                    message_instructions=ctx.message_instructions,
                    variation_text="Write a brief message.",
                    channel_type=ChannelType.WHATSAPP,
                )
            )
        self.assertIn("body", result)
        self.assertIn("STOP", result["body"])

    def test_truncation_when_body_exceeds_limit(self):
        ctx = _build_context(ChannelType.SMS)
        long_body = "A" * 200
        mock_response = SMSWhatsAppCopy(body=long_body)

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(mock_response, "SUCCESS"),
        ):
            result = asyncio.get_event_loop().run_until_complete(
                generate_sms_whatsapp_copy(
                    message_context=ctx,
                    message_instructions=ctx.message_instructions,
                    variation_text="Write a brief message.",
                    channel_type=ChannelType.SMS,
                )
            )
        self.assertLessEqual(len(result["body"]), SMS_CHAR_LIMIT)

    def test_raises_on_llm_failure(self):
        ctx = _build_context(ChannelType.SMS)

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(None, "ERROR"),
        ):
            with self.assertRaises(Exception) as exc_ctx:
                asyncio.get_event_loop().run_until_complete(
                    generate_sms_whatsapp_copy(
                        message_context=ctx,
                        message_instructions=ctx.message_instructions,
                        variation_text="Write a brief message.",
                        channel_type=ChannelType.SMS,
                    )
                )
            self.assertIn("SMS", str(exc_ctx.exception))

    def test_no_html_in_body(self):
        ctx = _build_context(ChannelType.SMS)
        mock_response = SMSWhatsAppCopy(body="Hi Jane")

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(mock_response, "SUCCESS"),
        ):
            result = asyncio.get_event_loop().run_until_complete(
                generate_sms_whatsapp_copy(
                    message_context=ctx,
                    message_instructions=ctx.message_instructions,
                    variation_text="Test",
                    channel_type=ChannelType.SMS,
                )
            )
        self.assertIsNone(result.get("html_body"))


class TestGenerateSMSWhatsAppMessage(unittest.TestCase):
    def test_generates_requested_number_of_variations(self):
        ctx = _build_context(ChannelType.SMS)
        mock_response = SMSWhatsAppCopy(body="Hey Jane, quick q about Acme.")

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(mock_response, "SUCCESS"),
        ):
            results = asyncio.get_event_loop().run_until_complete(
                generate_sms_whatsapp_message(ctx, number_of_variations=2)
            )
        self.assertEqual(len(results), 2)
        for r in results:
            self.assertIn("body", r)

    def test_uses_framework_variations_when_no_user_instructions(self):
        ctx = _build_context(ChannelType.WHATSAPP)
        ctx.message_instructions.instructions_to_generate_message = None
        mock_response = SMSWhatsAppCopy(body="Hi Jane, value-first msg.")

        with patch(
            "dhisana.utils.generate_sms_whatsapp.get_structured_output_internal",
            new_callable=AsyncMock,
            return_value=(mock_response, "SUCCESS"),
        ) as mock_llm:
            asyncio.get_event_loop().run_until_complete(
                generate_sms_whatsapp_message(ctx, number_of_variations=3)
            )
        self.assertEqual(mock_llm.call_count, 3)


class TestChannelTypeEnum(unittest.TestCase):
    def test_sms_in_channel_type(self):
        self.assertEqual(ChannelType.SMS.value, "sms")

    def test_whatsapp_in_channel_type(self):
        self.assertEqual(ChannelType.WHATSAPP.value, "whatsapp")


if __name__ == "__main__":
    unittest.main()
