"""Tests for Apollo lookup/enrich – non-JSON response handling.

Reproduces DHISANA-STAGE-14H: JSONDecodeError when Apollo returns an empty
or non-JSON body on error status codes.
"""

import json

import pytest
from unittest.mock import AsyncMock, MagicMock, patch


def _mock_aiohttp_session(method, response_status, response_body):
    """Build a mock aiohttp.ClientSession whose *method* returns *response_body*."""
    mock_response = MagicMock()
    mock_response.status = response_status
    mock_response.text = AsyncMock(return_value=response_body)
    mock_response.request_info = MagicMock()
    mock_response.history = ()
    mock_response.headers = {}

    mock_cm = MagicMock()
    mock_cm.__aenter__ = AsyncMock(return_value=mock_response)
    mock_cm.__aexit__ = AsyncMock(return_value=None)

    mock_session = MagicMock()
    setattr(mock_session, method, MagicMock(return_value=mock_cm))

    mock_session_cm = MagicMock()
    mock_session_cm.__aenter__ = AsyncMock(return_value=mock_session)
    mock_session_cm.__aexit__ = AsyncMock(return_value=None)

    return mock_session_cm


# ---------------------------------------------------------------------------
# lookup_person_in_apollo_by_name
# ---------------------------------------------------------------------------

class TestLookupPersonByName:

    @pytest.mark.asyncio
    @patch("src.dhisana.utils.apollo_tools.get_apollo_access_token", return_value=("fake-key", False))
    async def test_empty_body_error_status(self, _mock_token):
        """Non-200 with empty body should return error dict, not raise."""
        from src.dhisana.utils.apollo_tools import lookup_person_in_apollo_by_name

        with patch("aiohttp.ClientSession", return_value=_mock_aiohttp_session("post", 502, "")):
            result = await lookup_person_in_apollo_by_name("Jane Doe")

        assert "error" in result
        assert "JSONDecodeError" not in str(result["error"])

    @pytest.mark.asyncio
    @patch("src.dhisana.utils.apollo_tools.get_apollo_access_token", return_value=("fake-key", False))
    async def test_html_body_error_status(self, _mock_token):
        """Non-200 with HTML body should return the HTML text as error."""
        from src.dhisana.utils.apollo_tools import lookup_person_in_apollo_by_name

        html = "<html><body>Service Unavailable</body></html>"
        with patch("aiohttp.ClientSession", return_value=_mock_aiohttp_session("post", 503, html)):
            result = await lookup_person_in_apollo_by_name("Jane Doe")

        assert "error" in result
        assert "Service Unavailable" in str(result["error"])

    @pytest.mark.asyncio
    @patch("src.dhisana.utils.apollo_tools.get_apollo_access_token", return_value=("fake-key", False))
    async def test_json_error_body(self, _mock_token):
        """Non-200 with valid JSON body should return parsed JSON as error."""
        from src.dhisana.utils.apollo_tools import lookup_person_in_apollo_by_name

        body = json.dumps({"message": "Unauthorized"})
        with patch("aiohttp.ClientSession", return_value=_mock_aiohttp_session("post", 401, body)):
            result = await lookup_person_in_apollo_by_name("Jane Doe")

        assert result["error"] == {"message": "Unauthorized"}

    @pytest.mark.asyncio
    @patch("src.dhisana.utils.apollo_tools.get_apollo_access_token", return_value=("fake-key", False))
    async def test_success(self, _mock_token):
        """200 response returns parsed JSON body."""
        from src.dhisana.utils.apollo_tools import lookup_person_in_apollo_by_name

        body = json.dumps({"people": [{"name": "Jane Doe"}]})
        with patch("aiohttp.ClientSession", return_value=_mock_aiohttp_session("post", 200, body)):
            result = await lookup_person_in_apollo_by_name("Jane Doe")

        assert result == {"people": [{"name": "Jane Doe"}]}

    @pytest.mark.asyncio
    async def test_empty_name(self):
        """Empty full_name should return error without making API call."""
        from src.dhisana.utils.apollo_tools import lookup_person_in_apollo_by_name

        result = await lookup_person_in_apollo_by_name("")
        assert "error" in result


# ---------------------------------------------------------------------------
# enrich_person_info_from_apollo
# ---------------------------------------------------------------------------

class TestEnrichPersonInfo:

    @pytest.mark.asyncio
    @patch("src.dhisana.utils.apollo_tools.get_apollo_access_token", return_value=("fake-key", False))
    async def test_empty_body_error_status(self, _mock_token):
        from src.dhisana.utils.apollo_tools import enrich_person_info_from_apollo

        with patch("aiohttp.ClientSession", return_value=_mock_aiohttp_session("post", 500, "")):
            result = await enrich_person_info_from_apollo(
                email="test@example.com",
            )

        assert "error" in result
        assert "JSONDecodeError" not in str(result["error"])


# ---------------------------------------------------------------------------
# enrich_organization_info_from_apollo
# ---------------------------------------------------------------------------

class TestEnrichOrgInfo:

    @pytest.mark.asyncio
    @patch("src.dhisana.utils.apollo_tools.get_apollo_access_token", return_value=("fake-key", False))
    async def test_empty_body_error_status(self, _mock_token):
        from src.dhisana.utils.apollo_tools import enrich_organization_info_from_apollo

        with patch("aiohttp.ClientSession", return_value=_mock_aiohttp_session("get", 502, "")):
            result = await enrich_organization_info_from_apollo(
                organization_domain="example.com",
            )

        assert "error" in result
        assert "JSONDecodeError" not in str(result["error"])
