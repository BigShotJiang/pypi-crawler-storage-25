"""Tests for SendEmailContext multi-recipient support (to/cc/bcc).

Validates that each provider function correctly handles the new
to_recipients, cc_recipients, and bcc_recipients fields on SendEmailContext.
"""

import base64
import email
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from dhisana.schemas.common import (
    BodyFormat,
    EmailRecipient,
    SendEmailContext,
)

# Provider imports may fail when the full test suite poisons sys.modules
# (the stale build/ directory creates a competing dhisana namespace).
# Use importorskip so these tests are skipped rather than erroring.
google_oauth_tools = pytest.importorskip("dhisana.utils.google_oauth_tools")
send_email_using_google_oauth_async = google_oauth_tools.send_email_using_google_oauth_async

microsoft365_tools = pytest.importorskip("dhisana.utils.microsoft365_tools")
send_email_using_microsoft_graph_async = microsoft365_tools.send_email_using_microsoft_graph_async

smtp_email_tools = pytest.importorskip("dhisana.utils.smtp_email_tools")
send_email_via_smtp_async = smtp_email_tools.send_email_via_smtp_async


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def basic_context():
    """SendEmailContext with a single primary recipient."""
    return SendEmailContext(
        recipient="primary@example.com",
        subject="Test Subject",
        body="Hello world",
        sender_name="Sender",
        sender_email="sender@example.com",
        labels=None,
        body_format=BodyFormat.TEXT,
    )


@pytest.fixture
def multi_recipient_context():
    """SendEmailContext with to/cc/bcc recipients."""
    return SendEmailContext(
        recipient="primary@example.com",
        subject="Multi Recipient Test",
        body="Hello everyone",
        sender_name="Sender",
        sender_email="sender@example.com",
        labels=None,
        body_format=BodyFormat.TEXT,
        to_recipients=[
            EmailRecipient(email="extra-to@example.com", name="Extra To"),
        ],
        cc_recipients=[
            EmailRecipient(email="cc1@example.com", name="CC One"),
            EmailRecipient(email="cc2@example.com", name="CC Two"),
        ],
        bcc_recipients=[
            EmailRecipient(email="bcc@example.com", name="BCC One"),
        ],
    )


# ---------------------------------------------------------------------------
# Schema tests
# ---------------------------------------------------------------------------

class TestSendEmailContextSchema:
    """Model-level tests for the new fields."""

    def test_new_fields_default_to_none(self, basic_context):
        assert basic_context.to_recipients is None
        assert basic_context.cc_recipients is None
        assert basic_context.bcc_recipients is None

    def test_accepts_email_recipient_objects(self, multi_recipient_context):
        assert len(multi_recipient_context.to_recipients) == 1
        assert multi_recipient_context.to_recipients[0].email == "extra-to@example.com"
        assert len(multi_recipient_context.cc_recipients) == 2
        assert len(multi_recipient_context.bcc_recipients) == 1

    def test_backward_compatible_serialization(self, basic_context):
        """Existing code that doesn't set the new fields should still serialize fine."""
        data = basic_context.model_dump()
        assert data["recipient"] == "primary@example.com"
        assert data["to_recipients"] is None
        assert data["cc_recipients"] is None
        assert data["bcc_recipients"] is None


# ---------------------------------------------------------------------------
# Google OAuth (Gmail API) tests
# ---------------------------------------------------------------------------

class TestGoogleOAuthRecipients:
    """Verify Gmail MIME message includes to/cc/bcc headers."""

    @pytest.mark.asyncio
    async def test_gmail_message_includes_cc_bcc(self, multi_recipient_context):
        captured_raw = {}

        with patch(
            "dhisana.utils.google_oauth_tools.get_google_access_token",
            return_value="fake-token",
        ), patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.raise_for_status = MagicMock()
            mock_resp.json.return_value = {"id": "gmail-msg-123"}

            mock_client = AsyncMock()

            async def fake_post(url, **kwargs):
                captured_raw.update(kwargs.get("json", {}))
                return mock_resp

            mock_client.post = fake_post
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await send_email_using_google_oauth_async(
                multi_recipient_context,
                tool_config=[{"name": "google", "configuration": []}],
            )

        assert result == "gmail-msg-123"

        # Decode the raw MIME message
        raw_b64 = captured_raw.get("raw", "")
        mime_bytes = base64.urlsafe_b64decode(raw_b64)
        parsed = email.message_from_bytes(mime_bytes)

        # To header should include primary + extra-to
        to_header = parsed["to"]
        assert "primary@example.com" in to_header
        assert "extra-to@example.com" in to_header

        # CC header
        cc_header = parsed.get("cc", "")
        assert "cc1@example.com" in cc_header
        assert "cc2@example.com" in cc_header

        # BCC header (Gmail strips it before delivery, but it should be in the raw payload)
        bcc_header = parsed.get("bcc", "")
        assert "bcc@example.com" in bcc_header

    @pytest.mark.asyncio
    async def test_gmail_no_extra_headers_when_none(self, basic_context):
        """When no extra recipients, only To header should be present."""
        captured_raw = {}

        with patch(
            "dhisana.utils.google_oauth_tools.get_google_access_token",
            return_value="fake-token",
        ), patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.raise_for_status = MagicMock()
            mock_resp.json.return_value = {"id": "gmail-msg-456"}

            mock_client = AsyncMock()

            async def fake_post(url, **kwargs):
                captured_raw.update(kwargs.get("json", {}))
                return mock_resp

            mock_client.post = fake_post
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await send_email_using_google_oauth_async(
                basic_context,
                tool_config=[{"name": "google", "configuration": []}],
            )

        raw_b64 = captured_raw.get("raw", "")
        mime_bytes = base64.urlsafe_b64decode(raw_b64)
        parsed = email.message_from_bytes(mime_bytes)

        assert parsed["to"] == "primary@example.com"
        assert parsed.get("cc") is None
        assert parsed.get("bcc") is None


# ---------------------------------------------------------------------------
# Microsoft 365 tests
# ---------------------------------------------------------------------------

class TestMicrosoft365Recipients:
    """Verify Graph API payload includes cc/bcc/to recipients."""

    @pytest.mark.asyncio
    async def test_graph_payload_includes_cc_bcc(self, multi_recipient_context):
        captured_payload = {}

        with patch(
            "dhisana.utils.microsoft365_tools.get_microsoft365_access_token",
            return_value="fake-token",
        ), patch(
            "dhisana.utils.microsoft365_tools._base_resource",
            return_value="/users/sender@example.com",
        ), patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp_send = MagicMock()
            mock_resp_send.status_code = 202
            mock_resp_send.raise_for_status = MagicMock()

            mock_resp_list = MagicMock()
            mock_resp_list.status_code = 200
            mock_resp_list.raise_for_status = MagicMock()
            mock_resp_list.json.return_value = {"value": []}

            mock_client = AsyncMock()

            async def fake_post(url, **kwargs):
                captured_payload.update(kwargs.get("json", {}))
                return mock_resp_send

            mock_client.post = fake_post
            mock_client.get = AsyncMock(return_value=mock_resp_list)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await send_email_using_microsoft_graph_async(
                multi_recipient_context,
                tool_config=[{"name": "microsoft365", "configuration": []}],
            )

        msg = captured_payload.get("message", {})

        # toRecipients should include primary + extra-to
        to_addrs = [r["emailAddress"]["address"] for r in msg.get("toRecipients", [])]
        assert "primary@example.com" in to_addrs
        assert "extra-to@example.com" in to_addrs

        # ccRecipients
        cc_addrs = [r["emailAddress"]["address"] for r in msg.get("ccRecipients", [])]
        assert "cc1@example.com" in cc_addrs
        assert "cc2@example.com" in cc_addrs

        # bccRecipients
        bcc_addrs = [r["emailAddress"]["address"] for r in msg.get("bccRecipients", [])]
        assert "bcc@example.com" in bcc_addrs

    @pytest.mark.asyncio
    async def test_graph_no_extra_fields_when_none(self, basic_context):
        """When no extra recipients, payload should only have toRecipients."""
        captured_payload = {}

        with patch(
            "dhisana.utils.microsoft365_tools.get_microsoft365_access_token",
            return_value="fake-token",
        ), patch(
            "dhisana.utils.microsoft365_tools._base_resource",
            return_value="/users/sender@example.com",
        ), patch("httpx.AsyncClient") as mock_client_cls:
            mock_resp = MagicMock()
            mock_resp.status_code = 202
            mock_resp.raise_for_status = MagicMock()

            mock_resp_list = MagicMock()
            mock_resp_list.status_code = 200
            mock_resp_list.raise_for_status = MagicMock()
            mock_resp_list.json.return_value = {"value": []}

            mock_client = AsyncMock()

            async def fake_post(url, **kwargs):
                captured_payload.update(kwargs.get("json", {}))
                return mock_resp

            mock_client.post = fake_post
            mock_client.get = AsyncMock(return_value=mock_resp_list)
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            await send_email_using_microsoft_graph_async(
                basic_context,
                tool_config=[{"name": "microsoft365", "configuration": []}],
            )

        msg = captured_payload.get("message", {})
        assert len(msg["toRecipients"]) == 1
        assert "ccRecipients" not in msg
        assert "bccRecipients" not in msg


# ---------------------------------------------------------------------------
# SMTP tests
# ---------------------------------------------------------------------------

class TestSMTPRecipients:
    """Verify SMTP adds Cc header and includes all envelope recipients."""

    @pytest.mark.asyncio
    async def test_smtp_envelope_includes_all_recipients(self, multi_recipient_context):
        captured_kwargs = {}
        captured_recipients = []

        async def fake_send(msg, *, recipients=None, **kwargs):
            captured_kwargs.update(kwargs)
            if recipients:
                captured_recipients.extend(recipients)
            # Parse the MIME message to verify headers
            parsed = email.message_from_string(msg.as_string())
            captured_kwargs["_parsed_to"] = parsed["To"]
            captured_kwargs["_parsed_cc"] = parsed.get("Cc", "")
            # BCC should NOT be in headers
            captured_kwargs["_parsed_bcc"] = parsed.get("Bcc")

        with patch("dhisana.utils.smtp_email_tools.aiosmtplib.send", side_effect=fake_send):
            result = await send_email_via_smtp_async(
                multi_recipient_context,
                smtp_server="smtp.example.com",
                smtp_port=587,
                username="user",
                password="pass",
            )

        assert result  # Should return a message ID

        # Envelope recipients include all addresses
        assert "primary@example.com" in captured_recipients
        assert "extra-to@example.com" in captured_recipients
        assert "cc1@example.com" in captured_recipients
        assert "cc2@example.com" in captured_recipients
        assert "bcc@example.com" in captured_recipients

        # Cc header present
        assert "cc1@example.com" in captured_kwargs["_parsed_cc"]
        assert "cc2@example.com" in captured_kwargs["_parsed_cc"]

        # BCC should NOT appear in headers
        assert captured_kwargs["_parsed_bcc"] is None

    @pytest.mark.asyncio
    async def test_smtp_basic_send_unchanged(self, basic_context):
        """Without extra recipients, SMTP sends to single recipient as before."""
        captured_recipients = []

        async def fake_send(msg, *, recipients=None, **kwargs):
            if recipients:
                captured_recipients.extend(recipients)

        with patch("dhisana.utils.smtp_email_tools.aiosmtplib.send", side_effect=fake_send):
            await send_email_via_smtp_async(
                basic_context,
                smtp_server="smtp.example.com",
                smtp_port=587,
                username="user",
                password="pass",
            )

        assert captured_recipients == ["primary@example.com"]

    @pytest.mark.asyncio
    async def test_smtp_headers_cc_bcc_included_in_envelope(self):
        """Cc/Bcc set via ctx.headers must also appear in envelope recipients."""
        ctx = SendEmailContext(
            recipient="primary@example.com",
            subject="Header CC Test",
            body="body",
            sender_name="Sender",
            sender_email="sender@example.com",
            labels=None,
            body_format=BodyFormat.TEXT,
            headers={
                "Cc": "header-cc@example.com",
                "Bcc": "header-bcc@example.com",
            },
        )

        captured_recipients = []

        async def fake_send(msg, *, recipients=None, **kwargs):
            if recipients:
                captured_recipients.extend(recipients)

        with patch("dhisana.utils.smtp_email_tools.aiosmtplib.send", side_effect=fake_send):
            await send_email_via_smtp_async(
                ctx,
                smtp_server="smtp.example.com",
                smtp_port=587,
                username="user",
                password="pass",
            )

        assert "primary@example.com" in captured_recipients
        assert "header-cc@example.com" in captured_recipients
        assert "header-bcc@example.com" in captured_recipients
