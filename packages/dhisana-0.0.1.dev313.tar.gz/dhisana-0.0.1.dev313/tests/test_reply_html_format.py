"""Tests for HTML reply body formatting across SMTP and M365 providers.

Validates that reply_body_format=HTML is honoured so that follow-up
emails in a campaign are sent as HTML rather than plain text.
"""

import asyncio
import base64
import email as email_lib
import json
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from dhisana.schemas.common import BodyFormat, ReplyEmailContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_response(status_code: int, json_body: Any = None) -> httpx.Response:
    resp = httpx.Response(
        status_code=status_code,
        request=httpx.Request("GET", "https://example.com"),
        content=json.dumps(json_body or {}).encode(),
    )
    return resp


HTML_BODY = "<p>Hello <strong>World</strong></p>"
PLAIN_BODY = "Hello World"


# ---------------------------------------------------------------------------
# SMTP reply tests
# ---------------------------------------------------------------------------

class TestSmtpReplyHtmlFormat:
    """reply_to_email_via_smtp_async must build a multipart/alternative MIME
    message when reply_body_format is HTML."""

    @pytest.fixture
    def smtp_ctx_html(self):
        return ReplyEmailContext(
            message_id="<orig@example.com>",
            reply_body=HTML_BODY,
            sender_email="sender@example.com",
            sender_name="Sender",
            fallback_recipient="recipient@example.com",
            reply_body_format=BodyFormat.HTML,
        )

    @pytest.fixture
    def smtp_ctx_text(self):
        return ReplyEmailContext(
            message_id="<orig@example.com>",
            reply_body=PLAIN_BODY,
            sender_email="sender@example.com",
            sender_name="Sender",
            fallback_recipient="recipient@example.com",
            reply_body_format=BodyFormat.TEXT,
        )

    @pytest.mark.asyncio
    async def test_html_reply_produces_multipart(self, smtp_ctx_html):
        """When reply_body_format=HTML, the MIME should be multipart/alternative
        with both plain and HTML parts."""
        from dhisana.utils.smtp_email_tools import reply_to_email_via_smtp_async

        raw_original = self._build_raw_original()

        with patch("dhisana.utils.smtp_email_tools.asyncio") as mock_asyncio, \
             patch("dhisana.utils.smtp_email_tools.aiosmtplib") as mock_aiosmtp:

            mock_asyncio.to_thread = AsyncMock(return_value=raw_original)
            mock_aiosmtp.send = AsyncMock(return_value=None)

            result = await reply_to_email_via_smtp_async(
                smtp_ctx_html,
                smtp_server="smtp.example.com",
                smtp_port=587,
                imap_server="imap.example.com",
                imap_port=993,
                username="user",
                password="pass",
            )

            # Verify aiosmtplib.send was called
            mock_aiosmtp.send.assert_awaited_once()
            sent_msg = mock_aiosmtp.send.call_args[0][0]

            # The message should be multipart/alternative
            assert sent_msg.get_content_type() == "multipart/alternative"
            parts = sent_msg.get_payload()
            assert len(parts) == 2

            plain_part = parts[0]
            html_part = parts[1]
            assert plain_part.get_content_type() == "text/plain"
            assert html_part.get_content_type() == "text/html"
            assert HTML_BODY in html_part.get_payload(decode=True).decode()

    @pytest.mark.asyncio
    async def test_text_reply_produces_plain(self, smtp_ctx_text):
        """When reply_body_format=TEXT, the MIME should be text/plain."""
        from dhisana.utils.smtp_email_tools import reply_to_email_via_smtp_async

        raw_original = self._build_raw_original()

        with patch("dhisana.utils.smtp_email_tools.asyncio") as mock_asyncio, \
             patch("dhisana.utils.smtp_email_tools.aiosmtplib") as mock_aiosmtp:

            mock_asyncio.to_thread = AsyncMock(return_value=raw_original)
            mock_aiosmtp.send = AsyncMock(return_value=None)

            result = await reply_to_email_via_smtp_async(
                smtp_ctx_text,
                smtp_server="smtp.example.com",
                smtp_port=587,
                imap_server="imap.example.com",
                imap_port=993,
                username="user",
                password="pass",
            )

            mock_aiosmtp.send.assert_awaited_once()
            sent_msg = mock_aiosmtp.send.call_args[0][0]

            assert sent_msg.get_content_type() == "text/plain"

    def _build_raw_original(self) -> bytes:
        """Build a minimal raw email message for IMAP fetch simulation."""
        msg = MIMEText("Original body", "plain", "utf-8")
        msg["From"] = "recipient@example.com"
        msg["To"] = "sender@example.com"
        msg["Subject"] = "Test"
        msg["Message-ID"] = "<orig@example.com>"
        return msg.as_bytes()


# ---------------------------------------------------------------------------
# Microsoft 365 reply tests
# ---------------------------------------------------------------------------

class TestM365ReplyHtmlFormat:
    """reply_to_email_m365_async must create an empty-comment draft, then PATCH
    the body with HTML content when reply_body_format is HTML."""

    def _m365_original_message(self) -> Dict[str, Any]:
        return {
            "id": "msg_123",
            "subject": "Test Subject",
            "conversationId": "conv_abc",
            "from": {
                "emailAddress": {
                    "address": "recipient@example.com",
                    "name": "Recipient",
                }
            },
            "toRecipients": [
                {"emailAddress": {"address": "sender@example.com", "name": "Sender"}}
            ],
            "ccRecipients": [],
        }

    def _build_mock_client(self, original_msg: Dict[str, Any]):
        mock_client = AsyncMock()
        mock_client.get = AsyncMock(
            return_value=_make_response(200, original_msg)
        )
        mock_client.post = AsyncMock(
            return_value=_make_response(201, {"id": "reply_draft_id", "categories": []})
        )
        mock_client.patch = AsyncMock(
            return_value=_make_response(200, {})
        )
        return mock_client

    @pytest.mark.asyncio
    async def test_html_reply_uses_comment_then_patch(self):
        """HTML reply should create draft with empty comment (to preserve the
        quoted thread) and then PATCH the body with the HTML content."""
        from dhisana.utils.microsoft365_tools import reply_to_email_m365_async

        ctx = ReplyEmailContext(
            message_id="msg_123",
            reply_body=HTML_BODY,
            sender_email="sender@example.com",
            sender_name="Sender",
            reply_body_format=BodyFormat.HTML,
        )
        original = self._m365_original_message()
        mock_client = self._build_mock_client(original)

        mock_cm = AsyncMock()
        mock_cm.__aenter__ = AsyncMock(return_value=mock_client)
        mock_cm.__aexit__ = AsyncMock(return_value=False)

        with patch("dhisana.utils.microsoft365_tools.get_microsoft365_access_token", return_value="fake_token"), \
             patch("dhisana.utils.microsoft365_tools.httpx.AsyncClient", return_value=mock_cm):

            result = await reply_to_email_m365_async(ctx, tool_config=[{"name": "microsoft365"}])

        # 1) The createReply POST should use an empty comment to let Graph
        #    generate the quoted thread in the draft.
        post_calls = mock_client.post.call_args_list
        create_reply_call = [c for c in post_calls if "createReply" in str(c)]
        assert len(create_reply_call) >= 1

        payload = create_reply_call[0].kwargs.get("json") or create_reply_call[0][1].get("json")
        assert payload == {"comment": ""}, "HTML reply should create draft with empty comment"

        # 2) A PATCH call should set the HTML body on the draft.
        patch_calls = mock_client.patch.call_args_list
        body_patch = [c for c in patch_calls if "body" in json.dumps(c.kwargs.get("json", {}))]
        assert len(body_patch) >= 1, "Expected a PATCH to set the HTML body on the draft"
        patch_json = body_patch[0].kwargs.get("json")
        assert patch_json["body"]["contentType"] == "html"
        assert HTML_BODY in patch_json["body"]["content"]

    @pytest.mark.asyncio
    async def test_text_reply_uses_comment(self):
        """Plain text reply should continue to use the comment field."""
        from dhisana.utils.microsoft365_tools import reply_to_email_m365_async

        ctx = ReplyEmailContext(
            message_id="msg_123",
            reply_body=PLAIN_BODY,
            sender_email="sender@example.com",
            sender_name="Sender",
            reply_body_format=BodyFormat.TEXT,
        )
        original = self._m365_original_message()
        mock_client = self._build_mock_client(original)

        mock_cm = AsyncMock()
        mock_cm.__aenter__ = AsyncMock(return_value=mock_client)
        mock_cm.__aexit__ = AsyncMock(return_value=False)

        with patch("dhisana.utils.microsoft365_tools.get_microsoft365_access_token", return_value="fake_token"), \
             patch("dhisana.utils.microsoft365_tools.httpx.AsyncClient", return_value=mock_cm):

            result = await reply_to_email_m365_async(ctx, tool_config=[{"name": "microsoft365"}])

        post_calls = mock_client.post.call_args_list
        create_reply_call = [c for c in post_calls if "createReply" in str(c)]
        assert len(create_reply_call) >= 1

        payload = create_reply_call[0].kwargs.get("json") or create_reply_call[0][1].get("json")
        assert "comment" in payload
        assert "message" not in payload
