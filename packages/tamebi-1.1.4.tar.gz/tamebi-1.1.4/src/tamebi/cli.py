from __future__ import annotations

from typing import Optional

import typer

from tamebi import __version__
from tamebi.display.report import TAMEBI_ACCENT, console

app = typer.Typer(
    name="tamebi",
    help="Tamebi — detect hardware and estimate LLM model inference capability.",
    no_args_is_help=True,
    add_completion=False,
)


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"[bold {TAMEBI_ACCENT}]tamebi[/]  [dim]v{__version__}[/dim]")
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-v",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    """Tamebi CLI — LLM infrastructure toolkit."""


@app.command()
def check(
    json_output: bool = typer.Option(
        False, "--json", "-j", help="Output results as JSON instead of rich tables."
    ),
    context_length: int = typer.Option(
        4096,
        "--context-length",
        "-c",
        help="Context length in tokens for KV cache estimation. Use 0 to use each model's native max context window.",
    ),
    batch_size: int = typer.Option(
        1,
        "--batch-size",
        "-b",
        help="Number of concurrent requests (batch size). Each gets its own KV cache.",
    ),
    online: bool = typer.Option(
        False,
        "--online",
        help="Also query HuggingFace Hub for additional model suggestions.",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", help="Show detailed detection info."
    ),
) -> None:
    """Detect hardware and estimate which LLM models can run on this machine."""
    from tamebi.display.report import render_json, render_report, render_runnable_models
    from tamebi.hardware.detector import detect_hardware
    from tamebi.models.catalog import get_catalog
    from tamebi.models.estimator import estimate_all

    with console.status(
        "[dim]Scanning hardware...[/dim]",
        spinner="dots",
        spinner_style=TAMEBI_ACCENT,
    ):
        hw = detect_hardware()

    if verbose and not json_output:
        console.print(f"[dim]OS: {hw.os}[/dim]")
        console.print(f"[dim]Compute device: {hw.compute_device}[/dim]")
        if hw.gpus:
            for g in hw.gpus:
                console.print(f"[dim]GPU vendor: {g.vendor}, model: {g.model}[/dim]")

    with console.status(
        "[dim]Loading model catalog...[/dim]",
        spinner="dots",
        spinner_style=TAMEBI_ACCENT,
    ):
        models = get_catalog()
        ctx = context_length if context_length > 0 else None
        estimates = estimate_all(hw, models, ctx_len=ctx, batch_size=batch_size)

    if json_output:
        render_json(hw, estimates, context_length, batch_size)
    else:
        render_report(hw, estimates, context_length, batch_size)

    # Optional HuggingFace lookup
    if online and not json_output:
        from tamebi.models.huggingface import search_huggingface

        max_params = hw.available_memory_gb / 0.5  # rough: INT4 = 0.5 bytes/param
        with console.status(
            "[dim]Querying HuggingFace Hub...[/dim]",
            spinner="dots",
            spinner_style=TAMEBI_ACCENT,
        ):
            hf_models = search_huggingface(max_params_b=max_params, limit=5)
        if hf_models:
            console.print()
            console.rule(f"[bold {TAMEBI_ACCENT}]HuggingFace Suggestions[/]", style=TAMEBI_ACCENT)
            for m in hf_models:
                console.print(
                    f"  [dim]·[/dim]  {m['id']}  "
                    f"[dim]({m['params_b']:.1f}B  ·  {m['downloads']:,} downloads)[/dim]"
                )
        else:
            console.print("[dim]No additional models found on HuggingFace.[/dim]")


@app.command()
def models(
    context_length: int = typer.Option(
        4096,
        "--context-length",
        "-c",
        help="Context length for KV cache estimation. Use 0 for each model's native max.",
    ),
    batch_size: int = typer.Option(
        1, "--batch-size", "-b", help="Batch size for KV cache estimation."
    ),
) -> None:
    """Show the full model compatibility matrix across all precisions."""
    from tamebi.display.report import render_compatibility_matrix
    from tamebi.hardware.detector import detect_hardware
    from tamebi.models.catalog import get_catalog
    from tamebi.models.estimator import estimate_all

    with console.status(
        "[dim]Scanning hardware...[/dim]",
        spinner="dots",
        spinner_style=TAMEBI_ACCENT,
    ):
        hw = detect_hardware()

    with console.status(
        "[dim]Loading model catalog...[/dim]",
        spinner="dots",
        spinner_style=TAMEBI_ACCENT,
    ):
        models_list = get_catalog()
        ctx = context_length if context_length > 0 else None
        estimates = estimate_all(hw, models_list, ctx_len=ctx, batch_size=batch_size)

    console.print()
    from tamebi import __version__
    from rich import box
    from rich.align import Align
    from rich.panel import Panel
    from tamebi.display.report import TAMEBI_ACCENT as _A
    ctx_label = "each model's max" if context_length == 0 else f"{context_length:,} tokens"
    console.print(
        Panel(
            Align.center(
                f"[bold {_A}]tamebi models[/]  [dim]v{__version__}[/dim]\n"
                f"[dim]context {ctx_label}  ·  batch {batch_size}[/dim]"
            ),
            box=box.ROUNDED,
            border_style=_A,
            padding=(1, 4),
        )
    )
    render_compatibility_matrix(estimates)
    console.print()


@app.command()
def update() -> None:
    """Force-refresh the local model catalog cache from the remote source."""
    from tamebi.models.updater import fetch_remote_catalog, save_catalog_cache

    try:
        with console.status(
            "[dim]Fetching latest catalog...[/dim]",
            spinner="dots",
            spinner_style=TAMEBI_ACCENT,
        ):
            data = fetch_remote_catalog()
        save_catalog_cache(data)
        console.print(f"[bold green]✔[/bold green]  Cached {len(data)} models.")
    except Exception as exc:
        console.print(f"[bold red]✘[/bold red]  Update failed: {exc}")
        raise typer.Exit(code=1)
