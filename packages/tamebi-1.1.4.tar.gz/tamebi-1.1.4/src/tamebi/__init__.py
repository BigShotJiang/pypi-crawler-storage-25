"""Tamebi — LLM hardware detection and model inference estimation CLI."""

__version__ = "1.1.4"
