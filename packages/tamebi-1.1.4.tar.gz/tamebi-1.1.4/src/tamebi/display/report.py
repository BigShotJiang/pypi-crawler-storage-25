from __future__ import annotations

import json
import shutil

from rich import box
from rich.align import Align
from rich.console import Console
from rich.padding import Padding
from rich.panel import Panel
from rich.table import Table

from tamebi import __version__
from tamebi.hardware.detector import HardwareProfile
from tamebi.models.estimator import FitRating, ModelEstimate

# ---------------------------------------------------------------------------
# Brand palette
# ---------------------------------------------------------------------------
TAMEBI_ACCENT = "#D96C4F"

# Auto-detect terminal width; fall back to 220 for non-TTY contexts.
_terminal_width = shutil.get_terminal_size(fallback=(220, 50)).columns
console = Console(width=_terminal_width)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt_date(date_str: str) -> str:
    """Format 'YYYY-MM' -> 'Mon YYYY'."""
    if not date_str:
        return "—"
    try:
        from datetime import datetime
        return datetime.strptime(date_str, "%Y-%m").strftime("%b %Y")
    except ValueError:
        return date_str


_FIT_ICONS = {
    FitRating.RUNS:   "[bold green]✔  Runs[/]",
    FitRating.TIGHT:  "[bold yellow]▲  Tight[/]",
    FitRating.NO_FIT: "[bold red]✘  No fit[/]",
}

_FIT_ICON_ONLY = {
    FitRating.RUNS:   "[bold green]✔[/]",
    FitRating.TIGHT:  "[bold yellow]▲[/]",
    FitRating.NO_FIT: "[bold red]✘[/]",
}


def _section(title: str) -> None:
    console.print()
    console.rule(f"[bold {TAMEBI_ACCENT}]{title}[/]", style=TAMEBI_ACCENT)


# ---------------------------------------------------------------------------
# Sections
# ---------------------------------------------------------------------------

def render_hardware_summary(hw: HardwareProfile) -> None:
    """Print Section 1: Hardware Summary."""
    _section("Hardware")

    table = Table(
        show_header=True,
        header_style=f"bold {TAMEBI_ACCENT}",
        border_style=TAMEBI_ACCENT,
        box=box.ROUNDED,
        padding=(0, 1),
    )
    table.add_column("Component", style="bold", min_width=24)
    table.add_column("Details")

    # CPU
    table.add_row("CPU", hw.cpu.model)
    table.add_row("Architecture", hw.cpu.arch)
    freq = f"  @  {hw.cpu.freq_mhz:.0f} MHz" if hw.cpu.freq_mhz else ""
    table.add_row("Cores / Threads", f"{hw.cpu.cores} cores / {hw.cpu.threads} threads{freq}")

    # RAM
    table.add_section()
    table.add_row(
        "RAM",
        f"{hw.memory.total_gb:.1f} GB total  /  {hw.memory.available_gb:.1f} GB available",
    )

    # GPU(s)
    table.add_section()
    if hw.gpus:
        for i, gpu in enumerate(hw.gpus):
            prefix = f"GPU {i}" if len(hw.gpus) > 1 else "GPU"
            parts = [f"{gpu.model}  —  {gpu.vram_total_gb:.1f} GB VRAM  ({gpu.vram_free_gb:.1f} GB free)"]
            if gpu.cuda_version:
                parts.append(f"CUDA {gpu.cuda_version}")
            if gpu.compute_capability:
                parts.append(f"CC {gpu.compute_capability}")
            table.add_row(prefix, "  |  ".join(parts))
    else:
        table.add_row("GPU", "[dim]None detected — CPU-only[/dim]")

    # System
    table.add_section()
    table.add_row("Disk", f"{hw.disk.free_gb:.1f} GB free  /  {hw.disk.total_gb:.1f} GB total")
    table.add_row("OS", hw.os)

    # Inference budget
    table.add_section()
    mem_type = "VRAM" if hw.is_gpu_available else "RAM"
    table.add_row(
        "Available for inference",
        f"[bold {TAMEBI_ACCENT}]{hw.available_memory_gb:.1f} GB[/]  [dim]({mem_type})[/dim]",
    )

    console.print(Padding(table, (1, 0, 0, 0)))


def render_compatibility_matrix(estimates: list[ModelEstimate]) -> None:
    """Print Section 2: Model Compatibility Matrix."""
    _section("Compatibility Matrix")

    # Group by model
    models_seen: dict[str, dict[str, ModelEstimate]] = {}
    for est in estimates:
        if est.model.name not in models_seen:
            models_seen[est.model.name] = {}
        models_seen[est.model.name][est.precision.label] = est

    # Collect all precisions in order
    precisions = []
    for est in estimates:
        if est.precision.label not in precisions:
            precisions.append(est.precision.label)

    table = Table(
        show_header=True,
        header_style=f"bold {TAMEBI_ACCENT}",
        border_style=TAMEBI_ACCENT,
        box=box.ROUNDED,
        padding=(0, 1),
    )
    table.add_column("Model", style="bold", min_width=22, no_wrap=True)
    table.add_column("Released", justify="center", no_wrap=True)
    table.add_column("Params", justify="right", no_wrap=True)
    table.add_column("Max Ctx", justify="right", no_wrap=True)
    table.add_column("Est. Ctx", justify="right", no_wrap=True)
    for prec in precisions:
        table.add_column(prec, justify="center", min_width=16, no_wrap=True)

    sorted_models = sorted(
        models_seen.items(),
        key=lambda item: next(iter(item[1].values())).model.release_date or "0000-00",
        reverse=True,
    )

    for model_name, prec_map in sorted_models:
        first_est = next(iter(prec_map.values()))
        max_ctx = first_est.model.default_ctx_len
        est_ctx = first_est.context_length
        max_ctx_str = f"{max_ctx // 1024}K" if max_ctx >= 1024 else str(max_ctx)
        est_ctx_str = f"{est_ctx // 1024}K" if est_ctx >= 1024 else str(est_ctx)
        row = [
            model_name,
            _fmt_date(first_est.model.release_date),
            f"{first_est.model.params_b:.1f}B",
            max_ctx_str,
            est_ctx_str,
        ]
        for prec in precisions:
            est = prec_map.get(prec)
            if est:
                cell = f"{_FIT_ICONS[est.fit_rating]}\n[dim]{est.total_gb:.1f} GB[/dim]"
                row.append(cell)
            else:
                row.append("[dim]—[/dim]")
        table.add_row(*row)

    console.print(Padding(table, (1, 0, 0, 0)))


def render_runnable_models(estimates: list[ModelEstimate]) -> None:
    """Print runnable models with performance data."""
    _section("Runnable Models")

    runnable = [e for e in estimates if e.fit_rating != FitRating.NO_FIT]
    runnable.sort(key=lambda e: (e.model.release_date or "0000-00"), reverse=True)

    if not runnable:
        console.print(
            Padding(
                Panel(
                    "[bold red]✘[/]  No models fit on this hardware at any precision.\n"
                    "[dim]Consider a machine with more VRAM / RAM, or try smaller models.[/dim]",
                    border_style="red",
                    box=box.ROUNDED,
                    padding=(1, 2),
                ),
                (1, 0, 0, 0),
            )
        )
        return

    table = Table(
        show_header=True,
        header_style=f"bold {TAMEBI_ACCENT}",
        border_style=TAMEBI_ACCENT,
        box=box.ROUNDED,
        padding=(0, 1),
    )
    table.add_column("Model", style="bold", min_width=22, no_wrap=True)
    table.add_column("Released", justify="center", no_wrap=True)
    table.add_column("Precision", justify="center", no_wrap=True)
    table.add_column("VRAM / RAM", justify="right", no_wrap=True)
    table.add_column("Weights", justify="right", no_wrap=True)
    table.add_column("KV Cache", justify="right", no_wrap=True)
    table.add_column("Tok / sec", justify="right", no_wrap=True)
    table.add_column("TTFT (s)", justify="right", no_wrap=True)
    table.add_column("Fit", justify="center", no_wrap=True)

    for est in runnable:
        table.add_row(
            est.model.name,
            _fmt_date(est.model.release_date),
            est.precision.label,
            f"{est.total_gb:.1f} GB",
            f"{est.weights_gb:.1f} GB",
            f"{est.kv_cache_gb:.1f} GB",
            est.tokens_per_sec,
            est.ttft_sec,
            _FIT_ICON_ONLY[est.fit_rating],
        )

    console.print(Padding(table, (1, 0, 0, 0)))


def render_recommendations(estimates: list[ModelEstimate]) -> None:
    """Print Section 4: Top recommendations."""
    runnable = [e for e in estimates if e.fit_rating == FitRating.RUNS]
    if not runnable:
        runnable = [e for e in estimates if e.fit_rating == FitRating.TIGHT]

    if not runnable:
        return

    prec_rank = {"INT4": 0, "INT8": 1, "FP16": 2, "FP32": 3}
    runnable.sort(
        key=lambda e: (e.model.release_date or "0000-00", e.model.params_b),
        reverse=True,
    )

    seen: set[str] = set()
    top: list[ModelEstimate] = []
    for est in runnable:
        if est.model.name not in seen:
            seen.add(est.model.name)
            top.append(est)
        if len(top) >= 3:
            break

    _section("Top Recommendations")

    table = Table(
        show_header=True,
        header_style=f"bold {TAMEBI_ACCENT}",
        border_style=TAMEBI_ACCENT,
        box=box.ROUNDED,
        padding=(0, 1),
        show_lines=True,
    )
    table.add_column("#", justify="center", style=f"bold {TAMEBI_ACCENT}", width=3)
    table.add_column("Model", style="bold", no_wrap=True)
    table.add_column("Precision", justify="center", no_wrap=True)
    table.add_column("Memory", justify="right", no_wrap=True)
    table.add_column("Speed", justify="right", no_wrap=True)
    table.add_column("Run with Ollama", style="dim", no_wrap=True)

    for i, est in enumerate(top, 1):
        prec_tag = est.precision.label.lower()
        model_tag = est.model.name.lower().replace(" ", "-")
        table.add_row(
            str(i),
            est.model.name,
            est.precision.label,
            f"{est.total_gb:.1f} GB",
            f"~{est.tokens_per_sec} tok/s",
            f"ollama run {model_tag}:{prec_tag}",
        )

    console.print(Padding(table, (1, 0, 0, 0)))


def render_report(
    hw: HardwareProfile,
    estimates: list[ModelEstimate],
    ctx_len: int,
    batch_size: int,
) -> None:
    """Render the full Rich report (all 4 sections)."""
    ctx_label = "each model's max" if ctx_len == 0 else f"{ctx_len:,} tokens"

    console.print()
    console.print(
        Panel(
            Align.center(
                f"[bold {TAMEBI_ACCENT}]tamebi[/]  [dim]v{__version__}[/dim]\n"
                f"[dim]context {ctx_label}  ·  batch {batch_size}[/dim]"
            ),
            box=box.ROUNDED,
            border_style=TAMEBI_ACCENT,
            padding=(1, 4),
        )
    )

    render_hardware_summary(hw)
    render_recommendations(estimates)
    render_runnable_models(estimates)
    console.print()


def render_json(
    hw: HardwareProfile,
    estimates: list[ModelEstimate],
    ctx_len: int,
    batch_size: int,
) -> None:
    """Render the full report as JSON to stdout."""
    output = {
        "hardware": hw.to_dict(),
        "settings": {
            "context_length": ctx_len,
            "batch_size": batch_size,
        },
        "estimates": [e.to_dict() for e in estimates],
    }
    print(json.dumps(output, indent=2))
