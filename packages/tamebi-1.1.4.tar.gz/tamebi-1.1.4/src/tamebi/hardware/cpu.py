from __future__ import annotations

from dataclasses import dataclass

import cpuinfo
import psutil


@dataclass
class CpuInfo:
    model: str
    cores: int
    threads: int
    freq_mhz: float | None
    arch: str

    def to_dict(self) -> dict:
        return {
            "model": self.model,
            "cores": self.cores,
            "threads": self.threads,
            "freq_mhz": self.freq_mhz,
            "arch": self.arch,
        }


def detect_cpu() -> CpuInfo:
    info = cpuinfo.get_cpu_info()
    freq = psutil.cpu_freq()
    return CpuInfo(
        model=info.get("brand_raw", "Unknown CPU"),
        cores=psutil.cpu_count(logical=False) or 1,
        threads=psutil.cpu_count(logical=True) or 1,
        freq_mhz=round(freq.current, 1) if freq else None,
        arch=info.get("arch_string_raw", "unknown"),
    )
