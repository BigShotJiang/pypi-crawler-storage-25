from __future__ import annotations

import platform
from dataclasses import dataclass, field

from tamebi.hardware.cpu import CpuInfo, detect_cpu
from tamebi.hardware.disk import DiskInfo, detect_disk
from tamebi.hardware.gpu import GpuInfo, detect_gpus
from tamebi.hardware.memory import MemoryInfo, detect_memory


@dataclass
class HardwareProfile:
    cpu: CpuInfo
    memory: MemoryInfo
    gpus: list[GpuInfo]
    disk: DiskInfo
    os: str
    is_gpu_available: bool = field(init=False)
    compute_device: str = field(init=False)

    def __post_init__(self) -> None:
        self.is_gpu_available = len(self.gpus) > 0
        if self.gpus:
            self.compute_device = self.gpus[0].vendor
        else:
            self.compute_device = "cpu"

    @property
    def total_vram_gb(self) -> float:
        return sum(g.vram_total_gb for g in self.gpus)

    @property
    def free_vram_gb(self) -> float:
        return sum(g.vram_free_gb for g in self.gpus)

    @property
    def available_memory_gb(self) -> float:
        """Memory available for model loading — VRAM if GPU present, else RAM."""
        if self.is_gpu_available:
            return self.free_vram_gb
        return self.memory.available_gb

    @property
    def is_nvidia(self) -> bool:
        return any(g.vendor == "nvidia" for g in self.gpus)

    def to_dict(self) -> dict:
        return {
            "cpu": self.cpu.to_dict(),
            "memory": self.memory.to_dict(),
            "gpus": [g.to_dict() for g in self.gpus],
            "disk": self.disk.to_dict(),
            "os": self.os,
            "compute_device": self.compute_device,
            "total_vram_gb": round(self.total_vram_gb, 2) if self.gpus else None,
            "available_memory_gb": round(self.available_memory_gb, 2),
        }


def detect_hardware() -> HardwareProfile:
    """Run all hardware detectors and return a unified profile."""
    return HardwareProfile(
        cpu=detect_cpu(),
        memory=detect_memory(),
        gpus=detect_gpus(),
        disk=detect_disk(),
        os=f"{platform.system()} {platform.release()}",
    )
