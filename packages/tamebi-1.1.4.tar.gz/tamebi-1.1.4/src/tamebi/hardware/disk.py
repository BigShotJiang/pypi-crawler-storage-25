from __future__ import annotations

from dataclasses import dataclass
import platform

import psutil


@dataclass
class DiskInfo:
    free_gb: float
    total_gb: float

    def to_dict(self) -> dict:
        return {
            "free_gb": round(self.free_gb, 2),
            "total_gb": round(self.total_gb, 2),
        }


def detect_disk() -> DiskInfo:
    # Use home directory root as the reference path for model storage
    if platform.system() == "Windows":
        path = "C:\\"
    else:
        path = "/"
    usage = psutil.disk_usage(path)
    return DiskInfo(
        free_gb=usage.free / (1024**3),
        total_gb=usage.total / (1024**3),
    )
