from __future__ import annotations

import json
import platform
import subprocess
from dataclasses import dataclass, field


@dataclass
class GpuInfo:
    vendor: str  # "nvidia", "amd", "apple", "none"
    model: str
    vram_total_gb: float
    vram_free_gb: float
    cuda_version: str | None = None
    compute_capability: str | None = None

    def to_dict(self) -> dict:
        d: dict = {
            "vendor": self.vendor,
            "model": self.model,
            "vram_total_gb": round(self.vram_total_gb, 2),
            "vram_free_gb": round(self.vram_free_gb, 2),
        }
        if self.cuda_version:
            d["cuda_version"] = self.cuda_version
        if self.compute_capability:
            d["compute_capability"] = self.compute_capability
        return d


def detect_nvidia_gpus() -> list[GpuInfo]:
    """Detect NVIDIA GPUs using nvidia-ml-py (pynvml)."""
    try:
        from pynvml import (
            nvmlDeviceGetCount,
            nvmlDeviceGetCudaComputeCapability,
            nvmlDeviceGetHandleByIndex,
            nvmlDeviceGetMemoryInfo,
            nvmlDeviceGetName,
            nvmlInit,
            nvmlShutdown,
            nvmlSystemGetCudaDriverVersion_v2,
        )
    except ImportError:
        return []

    try:
        nvmlInit()
    except Exception:
        return []

    gpus: list[GpuInfo] = []
    try:
        count = nvmlDeviceGetCount()
        cuda_driver = nvmlSystemGetCudaDriverVersion_v2()
        cuda_ver = f"{cuda_driver // 1000}.{(cuda_driver % 1000) // 10}"

        for i in range(count):
            handle = nvmlDeviceGetHandleByIndex(i)
            name = nvmlDeviceGetName(handle)
            if isinstance(name, bytes):
                name = name.decode("utf-8")
            mem = nvmlDeviceGetMemoryInfo(handle)
            try:
                cc = nvmlDeviceGetCudaComputeCapability(handle)
                cc_str = f"{cc[0]}.{cc[1]}"
            except Exception:
                cc_str = None

            gpus.append(
                GpuInfo(
                    vendor="nvidia",
                    model=name,
                    vram_total_gb=mem.total / (1024**3),
                    vram_free_gb=mem.free / (1024**3),
                    cuda_version=cuda_ver,
                    compute_capability=cc_str,
                )
            )
    except Exception:
        pass
    finally:
        try:
            nvmlShutdown()
        except Exception:
            pass

    return gpus


def detect_amd_gpus() -> list[GpuInfo]:
    """Detect AMD GPUs using rocm-smi."""
    try:
        result = subprocess.run(
            ["rocm-smi", "--showmeminfo", "vram", "--json"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        data = json.loads(result.stdout)
    except (FileNotFoundError, subprocess.TimeoutExpired, json.JSONDecodeError):
        return []

    gpus: list[GpuInfo] = []
    for card_key, card_data in data.items():
        if not card_key.startswith("card"):
            continue
        try:
            total = int(card_data.get("VRAM Total Memory (B)", 0))
            used = int(card_data.get("VRAM Total Used Memory (B)", 0))
            # Get GPU model name
            name_result = subprocess.run(
                ["rocm-smi", "--showproductname", "--json"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            model_name = "AMD GPU"
            if name_result.returncode == 0:
                name_data = json.loads(name_result.stdout)
                card_info = name_data.get(card_key, {})
                model_name = card_info.get("Card Series", "AMD GPU")

            gpus.append(
                GpuInfo(
                    vendor="amd",
                    model=model_name,
                    vram_total_gb=total / (1024**3),
                    vram_free_gb=(total - used) / (1024**3),
                )
            )
        except (ValueError, KeyError):
            continue

    return gpus


def detect_apple_silicon() -> GpuInfo | None:
    """Detect Apple Silicon chip and unified memory."""
    if platform.system() != "Darwin":
        return None

    try:
        result = subprocess.run(
            ["system_profiler", "SPHardwareDataType"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None

    chip_name = None
    memory_gb = 0.0

    for line in result.stdout.splitlines():
        line = line.strip()
        if "Chip" in line and ":" in line:
            chip_name = line.split(":", 1)[1].strip()
        elif "Memory" in line and ":" in line:
            mem_str = line.split(":", 1)[1].strip()
            # Parse "16 GB" or "32 GB"
            parts = mem_str.split()
            if parts:
                try:
                    memory_gb = float(parts[0])
                except ValueError:
                    pass

    if not chip_name or "Apple" not in chip_name:
        return None

    # Apple Silicon uses unified memory — GPU shares all system RAM.
    # Estimate ~75% available for ML workloads (OS and apps use the rest).
    return GpuInfo(
        vendor="apple",
        model=chip_name,
        vram_total_gb=memory_gb,
        vram_free_gb=memory_gb * 0.75,
    )


def detect_gpus() -> list[GpuInfo]:
    """Detect all available GPUs across vendors. Returns empty list if CPU-only."""
    # Try NVIDIA first (most common for ML)
    gpus = detect_nvidia_gpus()
    if gpus:
        return gpus

    # Try AMD
    gpus = detect_amd_gpus()
    if gpus:
        return gpus

    # Try Apple Silicon
    apple = detect_apple_silicon()
    if apple:
        return [apple]

    return []
