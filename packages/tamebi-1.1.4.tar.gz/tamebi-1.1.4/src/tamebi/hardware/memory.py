from __future__ import annotations

from dataclasses import dataclass

import psutil


@dataclass
class MemoryInfo:
    total_gb: float
    available_gb: float

    def to_dict(self) -> dict:
        return {
            "total_gb": round(self.total_gb, 2),
            "available_gb": round(self.available_gb, 2),
        }


def detect_memory() -> MemoryInfo:
    vm = psutil.virtual_memory()
    return MemoryInfo(
        total_gb=vm.total / (1024**3),
        available_gb=vm.available / (1024**3),
    )
