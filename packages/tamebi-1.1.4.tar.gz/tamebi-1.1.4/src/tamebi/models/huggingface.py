from __future__ import annotations

from tamebi.models.catalog import ModelSpec


def search_huggingface(max_params_b: float, limit: int = 10) -> list[dict]:
    """Search HuggingFace Hub for models that fit within a parameter budget.

    Requires `huggingface-hub` to be installed (pip install tamebi[hf]).
    Returns a list of dicts with model info.
    """
    try:
        from huggingface_hub import HfApi
    except ImportError:
        return []

    api = HfApi()
    results: list[dict] = []

    try:
        models = api.list_models(
            sort="downloads",
            direction=-1,
            limit=limit * 3,  # fetch extra, we'll filter
            filter="text-generation",
        )

        for model in models:
            # Try to infer param count from model name or tags
            param_count = _infer_params_from_name(model.id)
            if param_count is not None and param_count <= max_params_b:
                results.append({
                    "id": model.id,
                    "downloads": model.downloads,
                    "params_b": param_count,
                })
                if len(results) >= limit:
                    break
    except Exception:
        return []

    return results


def fetch_model_spec(repo_id: str) -> dict | None:
    """Download config.json from HuggingFace and extract architecture params.

    Requires ``huggingface-hub`` (pip install tamebi[hf]).
    Returns a dict with keys: num_hidden_layers, num_attention_heads,
    num_key_value_heads, head_dim, max_position_embeddings.
    Returns None on any failure.
    """
    try:
        import json as _json

        from huggingface_hub import hf_hub_download

        # Only config.json is fetched and parsed with json.load — no code execution
        path = hf_hub_download(repo_id=repo_id, filename="config.json")  # nosec B615
        with open(path, encoding="utf-8") as fh:
            config = _json.load(fh)
    except Exception:
        return None

    try:
        num_q_heads = config.get("num_attention_heads")
        hidden_size = config.get("hidden_size")
        return {
            "num_hidden_layers": config.get("num_hidden_layers"),
            "num_attention_heads": num_q_heads,
            "num_key_value_heads": config.get("num_key_value_heads") or num_q_heads,
            "head_dim": config.get("head_dim") or (
                hidden_size // num_q_heads if hidden_size and num_q_heads else None
            ),
            "max_position_embeddings": config.get("max_position_embeddings"),
        }
    except Exception:
        return None


def _infer_params_from_name(model_id: str) -> float | None:
    """Try to extract parameter count from model name (e.g., 'meta-llama/Llama-3.1-8B' -> 8.0)."""
    import re

    name = model_id.lower()
    # Match patterns like "8b", "70b", "3.8b", "7b"
    match = re.search(r"(\d+\.?\d*)\s*b(?:illion)?", name)
    if match:
        try:
            return float(match.group(1))
        except ValueError:
            pass
    return None
