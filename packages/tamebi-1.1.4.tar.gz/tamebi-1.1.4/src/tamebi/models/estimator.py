from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from tamebi.hardware.detector import HardwareProfile
from tamebi.models.catalog import ModelSpec


class Precision(Enum):
    FP32 = ("FP32", 4.0)
    FP16 = ("FP16", 2.0)
    INT8 = ("INT8", 1.0)
    INT4 = ("INT4", 0.5)

    def __init__(self, label: str, bytes_per_param: float) -> None:
        self.label = label
        self.bytes_per_param = bytes_per_param


class FitRating(Enum):
    RUNS = "runs"       # Fits comfortably (<80% of available memory)
    TIGHT = "tight"     # Fits but tight (80-100%)
    NO_FIT = "no_fit"   # Won't fit (>100%)


@dataclass
class ModelEstimate:
    model: ModelSpec
    precision: Precision
    weights_gb: float
    kv_cache_gb: float
    overhead_gb: float
    total_gb: float
    fit_rating: FitRating
    available_memory_gb: float
    tokens_per_sec: str  # range string, e.g. "30-50"
    ttft_sec: str        # range string, e.g. "0.5-1.0"
    context_length: int  # effective context length used for this estimate

    def to_dict(self) -> dict:
        return {
            "model": self.model.name,
            "precision": self.precision.label,
            "weights_gb": round(self.weights_gb, 2),
            "kv_cache_gb": round(self.kv_cache_gb, 2),
            "overhead_gb": round(self.overhead_gb, 2),
            "total_gb": round(self.total_gb, 2),
            "fit_rating": self.fit_rating.value,
            "available_memory_gb": round(self.available_memory_gb, 2),
            "tokens_per_sec": self.tokens_per_sec,
            "time_to_first_token_sec": self.ttft_sec,
            "context_length": self.context_length,
            "max_context_length": self.model.default_ctx_len,
        }


# Throughput lookup: (hardware_class, model_size_bucket, precision) -> (min_tok_s, max_tok_s)
# hardware_class: "high_gpu", "mid_gpu", "apple", "cpu"
# model_size_bucket: "small" (<10B), "medium" (10-40B), "large" (40-100B), "xl" (>100B)
_THROUGHPUT_TABLE: dict[tuple[str, str, str], tuple[float, float]] = {
    # High-end GPU (4090/A100/H100)
    ("high_gpu", "small", "FP32"): (30, 50),
    ("high_gpu", "small", "FP16"): (80, 120),
    ("high_gpu", "small", "INT8"): (100, 160),
    ("high_gpu", "small", "INT4"): (120, 200),
    ("high_gpu", "medium", "FP32"): (10, 20),
    ("high_gpu", "medium", "FP16"): (30, 50),
    ("high_gpu", "medium", "INT8"): (50, 80),
    ("high_gpu", "medium", "INT4"): (60, 100),
    ("high_gpu", "large", "FP32"): (3, 8),
    ("high_gpu", "large", "FP16"): (10, 25),
    ("high_gpu", "large", "INT8"): (20, 40),
    ("high_gpu", "large", "INT4"): (30, 50),
    ("high_gpu", "xl", "FP32"): (1, 3),
    ("high_gpu", "xl", "FP16"): (3, 8),
    ("high_gpu", "xl", "INT8"): (5, 10),
    ("high_gpu", "xl", "INT4"): (8, 15),
    # Mid-range GPU (3060/4060/3070)
    ("mid_gpu", "small", "FP32"): (8, 15),
    ("mid_gpu", "small", "FP16"): (25, 45),
    ("mid_gpu", "small", "INT8"): (40, 70),
    ("mid_gpu", "small", "INT4"): (50, 90),
    ("mid_gpu", "medium", "FP32"): (3, 8),
    ("mid_gpu", "medium", "FP16"): (10, 20),
    ("mid_gpu", "medium", "INT8"): (15, 25),
    ("mid_gpu", "medium", "INT4"): (20, 35),
    ("mid_gpu", "large", "FP32"): (1, 3),
    ("mid_gpu", "large", "FP16"): (3, 8),
    ("mid_gpu", "large", "INT8"): (8, 15),
    ("mid_gpu", "large", "INT4"): (5, 12),
    ("mid_gpu", "xl", "INT8"): (1, 3),
    ("mid_gpu", "xl", "INT4"): (2, 5),
    # Apple Silicon
    ("apple", "small", "FP32"): (5, 10),
    ("apple", "small", "FP16"): (15, 30),
    ("apple", "small", "INT8"): (20, 40),
    ("apple", "small", "INT4"): (25, 50),
    ("apple", "medium", "FP32"): (3, 6),
    ("apple", "medium", "FP16"): (8, 15),
    ("apple", "medium", "INT8"): (8, 15),
    ("apple", "medium", "INT4"): (10, 20),
    ("apple", "large", "FP32"): (1, 3),
    ("apple", "large", "FP16"): (3, 8),
    ("apple", "large", "INT8"): (5, 12),
    ("apple", "large", "INT4"): (3, 8),
    ("apple", "xl", "FP16"): (0.5, 2),
    ("apple", "xl", "INT8"): (1, 3),
    ("apple", "xl", "INT4"): (2, 5),
    # CPU only
    ("cpu", "small", "FP32"): (0.5, 2),
    ("cpu", "small", "FP16"): (1, 3),
    ("cpu", "small", "INT8"): (2, 5),
    ("cpu", "small", "INT4"): (3, 8),
    ("cpu", "medium", "FP32"): (0.2, 1),
    ("cpu", "medium", "FP16"): (0.5, 2),
    ("cpu", "medium", "INT8"): (0.5, 2),
    ("cpu", "medium", "INT4"): (1, 3),
    ("cpu", "large", "FP32"): (0.05, 0.2),
    ("cpu", "large", "FP16"): (0.1, 0.5),
    ("cpu", "large", "INT8"): (0.2, 1),
    ("cpu", "large", "INT4"): (0.5, 2),
    ("cpu", "xl", "INT8"): (0.05, 0.2),
    ("cpu", "xl", "INT4"): (0.1, 0.5),
}

# TTFT lookup (seconds): same keys
_TTFT_TABLE: dict[tuple[str, str, str], tuple[float, float]] = {
    # High-end GPU
    ("high_gpu", "small", "FP32"): (0.3, 0.8),
    ("high_gpu", "small", "FP16"): (0.1, 0.3),
    ("high_gpu", "small", "INT8"): (0.1, 0.2),
    ("high_gpu", "small", "INT4"): (0.08, 0.2),
    ("high_gpu", "medium", "FP32"): (0.8, 2.0),
    ("high_gpu", "medium", "FP16"): (0.3, 0.8),
    ("high_gpu", "medium", "INT8"): (0.2, 0.5),
    ("high_gpu", "medium", "INT4"): (0.15, 0.4),
    ("high_gpu", "large", "FP32"): (1.5, 4.0),
    ("high_gpu", "large", "FP16"): (0.5, 1.5),
    ("high_gpu", "large", "INT8"): (0.4, 1.0),
    ("high_gpu", "large", "INT4"): (0.3, 0.8),
    ("high_gpu", "xl", "FP32"): (5.0, 15.0),
    ("high_gpu", "xl", "FP16"): (2.0, 5.0),
    ("high_gpu", "xl", "INT8"): (1.5, 4.0),
    ("high_gpu", "xl", "INT4"): (1.0, 3.0),
    # Mid-range GPU
    ("mid_gpu", "small", "FP32"): (0.8, 2.0),
    ("mid_gpu", "small", "FP16"): (0.3, 0.8),
    ("mid_gpu", "small", "INT8"): (0.2, 0.5),
    ("mid_gpu", "small", "INT4"): (0.15, 0.4),
    ("mid_gpu", "medium", "FP32"): (1.5, 4.0),
    ("mid_gpu", "medium", "FP16"): (0.5, 1.5),
    ("mid_gpu", "medium", "INT8"): (0.5, 1.5),
    ("mid_gpu", "medium", "INT4"): (0.4, 1.0),
    ("mid_gpu", "large", "FP32"): (3.0, 8.0),
    ("mid_gpu", "large", "FP16"): (1.5, 4.0),
    ("mid_gpu", "large", "INT8"): (0.8, 2.0),
    ("mid_gpu", "large", "INT4"): (1.0, 3.0),
    ("mid_gpu", "xl", "INT8"): (4.0, 10.0),
    ("mid_gpu", "xl", "INT4"): (3.0, 8.0),
    # Apple Silicon
    ("apple", "small", "FP32"): (0.8, 2.0),
    ("apple", "small", "FP16"): (0.3, 0.8),
    ("apple", "small", "INT8"): (0.2, 0.6),
    ("apple", "small", "INT4"): (0.2, 0.5),
    ("apple", "medium", "FP32"): (1.5, 4.0),
    ("apple", "medium", "FP16"): (0.5, 1.5),
    ("apple", "medium", "INT8"): (0.8, 2.0),
    ("apple", "medium", "INT4"): (0.5, 1.5),
    ("apple", "large", "FP32"): (3.0, 8.0),
    ("apple", "large", "FP16"): (1.5, 4.0),
    ("apple", "large", "INT8"): (1.0, 3.0),
    ("apple", "large", "INT4"): (2.0, 5.0),
    ("apple", "xl", "FP16"): (5.0, 15.0),
    ("apple", "xl", "INT8"): (4.0, 10.0),
    ("apple", "xl", "INT4"): (3.0, 8.0),
    # CPU only
    ("cpu", "small", "FP32"): (5, 30),
    ("cpu", "small", "FP16"): (3, 15),
    ("cpu", "small", "INT8"): (2, 10),
    ("cpu", "small", "INT4"): (1, 8),
    ("cpu", "medium", "FP32"): (10, 40),
    ("cpu", "medium", "FP16"): (5, 20),
    ("cpu", "medium", "INT8"): (8, 30),
    ("cpu", "medium", "INT4"): (5, 20),
    ("cpu", "large", "FP32"): (30, 120),
    ("cpu", "large", "FP16"): (20, 80),
    ("cpu", "large", "INT8"): (15, 60),
    ("cpu", "large", "INT4"): (10, 40),
    ("cpu", "xl", "INT8"): (60, 240),
    ("cpu", "xl", "INT4"): (30, 120),
}


def _model_size_bucket(params_b: float) -> str:
    if params_b < 10:
        return "small"
    elif params_b < 40:
        return "medium"
    elif params_b < 100:
        return "large"
    return "xl"


def _hardware_class(hw: HardwareProfile) -> str:
    if not hw.is_gpu_available:
        return "cpu"
    vendor = hw.gpus[0].vendor
    if vendor == "apple":
        return "apple"
    # Classify by VRAM: >=20GB = high-end, <20GB = mid
    max_vram = max(g.vram_total_gb for g in hw.gpus)
    if max_vram >= 20:
        return "high_gpu"
    return "mid_gpu"


def estimate_model_weights_gb(params_b: float, precision: Precision) -> float:
    return params_b * precision.bytes_per_param


def estimate_kv_cache_gb(
    model: ModelSpec,
    precision: Precision,
    ctx_len: int,
    batch_size: int,
) -> float:
    # GQA-aware: uses num_kv_heads, not num_q_heads
    bytes_total = (
        2
        * model.layers
        * model.num_kv_heads
        * model.head_dim
        * ctx_len
        * precision.bytes_per_param
        * batch_size
    )
    return bytes_total / (1024**3)


def estimate_model(
    model: ModelSpec,
    precision: Precision,
    hw: HardwareProfile,
    ctx_len: int | None = None,
    batch_size: int = 1,
) -> ModelEstimate:
    if ctx_len is None or ctx_len == 0:
        effective_ctx_len = model.default_ctx_len
    else:
        effective_ctx_len = min(ctx_len, model.default_ctx_len)

    weights_gb = estimate_model_weights_gb(model.params_b, precision)
    kv_cache_gb = estimate_kv_cache_gb(model, precision, effective_ctx_len, batch_size)

    # CUDA runtime overhead: ~500MB for NVIDIA, 0 otherwise
    cuda_overhead = 0.5 if hw.is_nvidia else 0.0
    # Activations + fragmentation: 15% of weights
    activation_overhead = weights_gb * 0.15
    overhead_gb = activation_overhead + cuda_overhead

    total_gb = weights_gb + kv_cache_gb + overhead_gb

    available = hw.available_memory_gb
    usage_ratio = total_gb / available if available > 0 else float("inf")

    if usage_ratio <= 0.80:
        fit = FitRating.RUNS
    elif usage_ratio <= 1.0:
        fit = FitRating.TIGHT
    else:
        fit = FitRating.NO_FIT

    # Performance lookup
    hw_class = _hardware_class(hw)
    size_bucket = _model_size_bucket(model.params_b)
    key = (hw_class, size_bucket, precision.label)

    throughput = _THROUGHPUT_TABLE.get(key)
    ttft = _TTFT_TABLE.get(key)

    tok_str = f"{throughput[0]:.0f}-{throughput[1]:.0f}" if throughput else "N/A"
    ttft_str = f"{ttft[0]:.1f}-{ttft[1]:.1f}" if ttft else "N/A"

    return ModelEstimate(
        model=model,
        precision=precision,
        weights_gb=weights_gb,
        kv_cache_gb=kv_cache_gb,
        overhead_gb=overhead_gb,
        total_gb=total_gb,
        fit_rating=fit,
        available_memory_gb=available,
        tokens_per_sec=tok_str,
        ttft_sec=ttft_str,
        context_length=effective_ctx_len,
    )


def estimate_all(
    hw: HardwareProfile,
    models: list[ModelSpec],
    precisions: list[Precision] | None = None,
    ctx_len: int | None = None,
    batch_size: int = 1,
) -> list[ModelEstimate]:
    """Estimate all model × precision combinations for the given hardware."""
    if precisions is None:
        precisions = [Precision.FP16, Precision.INT8, Precision.INT4]

    results: list[ModelEstimate] = []
    for model in models:
        for prec in precisions:
            est = estimate_model(model, prec, hw, ctx_len, batch_size)
            # Drop estimates with negligible weights (broken model metadata)
            if est.weights_gb < 0.1:
                continue
            results.append(est)
    return results
