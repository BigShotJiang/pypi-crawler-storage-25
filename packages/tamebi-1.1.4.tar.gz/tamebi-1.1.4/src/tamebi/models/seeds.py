"""Auto-discovery configuration for major-lab open-weight models.

build_catalog.py queries HuggingFace for the latest MODELS_PER_ORG models
from each org in TRACKED_ORGS automatically — no manual model list needed.
Add a new org here to start tracking it; new models appear on the next run.
"""

from __future__ import annotations

# Orgs to discover models from. Order determines display priority on ties.
TRACKED_ORGS: list[str] = [
    "meta-llama",
    "mistralai",
    "google",
    "Qwen",
    "deepseek-ai",
    "zai-org",
    "MiniMaxAI",
    "moonshotai",
    "LiquidAI",
    "allenai",
]

# How many models to fetch per org (sorted by created_at, newest first)
MODELS_PER_ORG: int = 15
