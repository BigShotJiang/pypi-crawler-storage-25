from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ModelSpec:
    name: str
    family: str
    params_b: float  # billions of parameters
    layers: int
    num_q_heads: int
    num_kv_heads: int
    head_dim: int
    default_ctx_len: int
    release_date: str = ""  # "YYYY-MM", empty string for unknown

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "family": self.family,
            "params_b": self.params_b,
            "layers": self.layers,
            "num_q_heads": self.num_q_heads,
            "num_kv_heads": self.num_kv_heads,
            "head_dim": self.head_dim,
            "default_ctx_len": self.default_ctx_len,
            "release_date": self.release_date,
        }


# Built-in catalog — offline fallback, always present.
# num_kv_heads reflects GQA where applicable.
MODEL_CATALOG: list[ModelSpec] = [
    # Llama 3.1 family
    ModelSpec("Llama 3.1 8B",   "llama", 8.0,   32,  32,  8,  128, 131072, "2024-07"),
    ModelSpec("Llama 3.1 70B",  "llama", 70.0,  80,  64,  8,  128, 131072, "2024-07"),
    ModelSpec("Llama 3.1 405B", "llama", 405.0, 126, 128, 8,  128, 131072, "2024-07"),
    # Mistral
    ModelSpec("Mistral 7B v0.3", "mistral", 7.3, 32, 32, 8, 128, 32768, "2024-05"),
    # Mixtral (MoE — params_b is total, but only ~12.9B active per token)
    ModelSpec("Mixtral 8x7B", "mixtral", 46.7, 32, 32, 8, 128, 32768, "2023-12"),
    # Qwen 2.5 & 3.6 family
    ModelSpec("Qwen 2.5 7B",  "qwen", 7.6,  28, 28, 4, 128, 131072, "2024-09"),
    ModelSpec("Qwen 2.5 72B", "qwen", 72.7, 80, 64, 8, 128, 131072, "2024-09"),
    ModelSpec("Qwen3.6 35B A38", "qwen", 35.952, 40, 16, 2, 256, 262144, "2026-04"),
    # Phi-3 family
    ModelSpec("Phi-3 Mini 3.8B",   "phi", 3.8,  32, 32, 32,  96, 128000, "2024-04"),
    ModelSpec("Phi-3 Medium 14B",  "phi", 14.0, 40, 40, 10, 128, 128000, "2024-04"),
    # Gemma 2 family
    ModelSpec("Gemma 2 9B",  "gemma", 9.2,  42, 16, 8,  256, 8192, "2024-06"),
    ModelSpec("Gemma 2 27B", "gemma", 27.2, 46, 32, 16, 128, 8192, "2024-06"),
    # DeepSeek
    ModelSpec("DeepSeek-V2 Lite 16B", "deepseek", 15.7,  27,  16,  2, 128, 163840, "2024-05"),
    ModelSpec("DeepSeek-V2 236B",     "deepseek", 236.0, 60, 128,  2, 128, 163840, "2024-05"),
]


def get_catalog() -> list[ModelSpec]:
    """Return the full model catalog, merging remote cache over built-in entries.

    Silently refreshes the local cache from GitHub if it is stale (>7 days).
    Falls back to the built-in MODEL_CATALOG when offline or the cache is empty.
    """
    from tamebi.models import updater

    updater.refresh_cache_if_stale(silent=True)
    cached = updater.load_catalog_cache()

    if not cached:
        return list(MODEL_CATALOG)

    # Start from built-in entries, then let remote entries override by name.
    merged: dict[str, ModelSpec] = {m.name: m for m in MODEL_CATALOG}
    for entry in cached:
        try:
            spec = ModelSpec(
                name=entry["name"],
                family=entry["family"],
                params_b=float(entry["params_b"]),
                layers=int(entry["layers"]),
                num_q_heads=int(entry.get("num_q_heads", entry.get("num q heads"))),
                num_kv_heads=int(entry.get("num_kv_heads", entry.get("num kv heads"))),
                head_dim=int(entry["head_dim"]),
                default_ctx_len=int(entry["default_ctx_len"]),
                release_date=entry.get("release_date", ""),
            )
            # Skip entries with clearly broken metadata (e.g. failed param extraction)
            if spec.params_b < 0.01 or spec.layers < 1 or spec.head_dim < 1:
                continue
            merged[spec.name] = spec
        except (KeyError, TypeError, ValueError):
            continue

    return list(merged.values())
