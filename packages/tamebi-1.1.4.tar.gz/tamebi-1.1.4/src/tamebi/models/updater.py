"""Runtime cache manager for the remote model catalog.

Fetches catalog.json from GitHub raw CDN if the local cache is missing or
older than STALE_AFTER_DAYS.  All network failures are silent by default so
tamebi always works offline.
"""

from __future__ import annotations

import json
import urllib.request
from datetime import datetime
from pathlib import Path

REMOTE_CATALOG_URL = (
    "https://cdn.jsdelivr.net/gh/tamebi-ai/clicatalog@main/catalog.json"
)
CACHE_PATH = Path.home() / ".tamebi" / "catalog.json"
STALE_AFTER_DAYS = 7
_TIMEOUT_SECONDS = 5


def is_cache_stale() -> bool:
    """Return True if the cache is missing or older than STALE_AFTER_DAYS."""
    if not CACHE_PATH.exists():
        return True
    age_seconds = datetime.now().timestamp() - CACHE_PATH.stat().st_mtime
    return age_seconds > STALE_AFTER_DAYS * 86400


def refresh_cache_if_stale(silent: bool = True) -> bool:
    """Fetch catalog.json from remote if the local cache is stale or missing.

    Returns True if the cache was refreshed, False if it was already fresh or
    the fetch failed.  Set silent=False to let exceptions propagate.
    """
    if not is_cache_stale():
        return False
    try:
        # URL is a hardcoded HTTPS constant, not user-supplied
        with urllib.request.urlopen(REMOTE_CATALOG_URL, timeout=_TIMEOUT_SECONDS) as resp:  # nosec B310
            data = json.loads(resp.read().decode("utf-8"))
        save_catalog_cache(data)
        return True
    except Exception:
        if not silent:
            raise
        return False


def load_catalog_cache() -> list[dict] | None:
    """Load catalog entries from the local cache file.

    Returns None if the cache doesn't exist or is unreadable.
    """
    if not CACHE_PATH.exists():
        return None
    try:
        return json.loads(CACHE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return None


def fetch_remote_catalog() -> list[dict]:
    """Force-fetch catalog.json from the remote URL.

    Raises on any network or parse failure (use this for the explicit
    ``tamebi update`` command, not background refresh).
    """
    # URL is a hardcoded HTTPS constant, not user-supplied
    with urllib.request.urlopen(REMOTE_CATALOG_URL, timeout=_TIMEOUT_SECONDS) as resp:  # nosec B310
        return json.loads(resp.read().decode("utf-8"))


def save_catalog_cache(data: list[dict]) -> None:
    """Write data to the local cache file, creating parent dirs as needed."""
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    CACHE_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
