"""Allow running tamebi as a module: python -m tamebi"""

from tamebi.cli import app

app()
