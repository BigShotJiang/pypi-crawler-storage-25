from tamebi.models.catalog import MODEL_CATALOG, ModelSpec, get_catalog


def test_catalog_not_empty():
    catalog = get_catalog()
    assert len(catalog) > 0


def test_catalog_returns_copies():
    """get_catalog should return a copy, not the original list."""
    c1 = get_catalog()
    c2 = get_catalog()
    assert c1 is not c2
    assert c1 == c2


def test_all_models_have_valid_fields():
    for model in MODEL_CATALOG:
        assert model.params_b > 0
        assert model.layers > 0
        assert model.num_q_heads > 0
        assert model.num_kv_heads > 0
        assert model.num_kv_heads <= model.num_q_heads, (
            f"{model.name}: num_kv_heads ({model.num_kv_heads}) > num_q_heads ({model.num_q_heads})"
        )
        assert model.head_dim > 0
        assert model.default_ctx_len > 0
        assert len(model.name) > 0
        assert len(model.family) > 0


def test_model_spec_to_dict():
    spec = ModelSpec("Test", "test", 7.0, 32, 32, 8, 128, 4096)
    d = spec.to_dict()
    assert d["name"] == "Test"
    assert d["params_b"] == 7.0
    assert d["num_kv_heads"] == 8
