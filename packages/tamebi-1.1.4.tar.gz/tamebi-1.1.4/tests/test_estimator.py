import pytest

from tamebi.hardware.cpu import CpuInfo
from tamebi.hardware.detector import HardwareProfile
from tamebi.hardware.disk import DiskInfo
from tamebi.hardware.gpu import GpuInfo
from tamebi.hardware.memory import MemoryInfo
from tamebi.models.catalog import ModelSpec
from tamebi.models.estimator import (
    FitRating,
    Precision,
    estimate_all,
    estimate_kv_cache_gb,
    estimate_model,
    estimate_model_weights_gb,
)


def _make_hw(
    vram_total: float = 24.0,
    vram_free: float = 22.0,
    ram_total: float = 64.0,
    ram_available: float = 48.0,
    vendor: str = "nvidia",
) -> HardwareProfile:
    gpus = []
    if vendor != "none":
        gpus = [
            GpuInfo(
                vendor=vendor,
                model="Test GPU",
                vram_total_gb=vram_total,
                vram_free_gb=vram_free,
            )
        ]
    return HardwareProfile(
        cpu=CpuInfo("Test CPU", 8, 16, 3500.0, "x86_64"),
        memory=MemoryInfo(ram_total, ram_available),
        gpus=gpus,
        disk=DiskInfo(500.0, 1000.0),
        os="Test OS",
    )


LLAMA_8B = ModelSpec("Llama 3.1 8B", "llama", 8.0, 32, 32, 8, 128, 131072)


class TestWeightsEstimation:
    def test_fp16(self):
        gb = estimate_model_weights_gb(8.0, Precision.FP16)
        assert gb == pytest.approx(16.0)

    def test_int4(self):
        gb = estimate_model_weights_gb(8.0, Precision.INT4)
        assert gb == pytest.approx(4.0)

    def test_fp32(self):
        gb = estimate_model_weights_gb(8.0, Precision.FP32)
        assert gb == pytest.approx(32.0)

    def test_int8(self):
        gb = estimate_model_weights_gb(8.0, Precision.INT8)
        assert gb == pytest.approx(8.0)


class TestKVCacheEstimation:
    def test_basic_kv_cache(self):
        # Llama 8B: 32 layers, 8 KV heads, 128 head_dim, 4096 ctx, FP16 (2 bytes), batch=1
        # = 2 * 32 * 8 * 128 * 4096 * 2 * 1 = 536,870,912 bytes = 0.5 GB
        kv = estimate_kv_cache_gb(LLAMA_8B, Precision.FP16, 4096, batch_size=1)
        assert kv == pytest.approx(0.5, abs=0.05)

    def test_kv_cache_scales_with_batch(self):
        kv_1 = estimate_kv_cache_gb(LLAMA_8B, Precision.FP16, 4096, batch_size=1)
        kv_4 = estimate_kv_cache_gb(LLAMA_8B, Precision.FP16, 4096, batch_size=4)
        assert kv_4 == pytest.approx(kv_1 * 4)

    def test_kv_cache_scales_with_context(self):
        kv_4k = estimate_kv_cache_gb(LLAMA_8B, Precision.FP16, 4096, batch_size=1)
        kv_8k = estimate_kv_cache_gb(LLAMA_8B, Precision.FP16, 8192, batch_size=1)
        assert kv_8k == pytest.approx(kv_4k * 2)

    def test_int4_halves_kv(self):
        kv_fp16 = estimate_kv_cache_gb(LLAMA_8B, Precision.FP16, 4096, batch_size=1)
        kv_int4 = estimate_kv_cache_gb(LLAMA_8B, Precision.INT4, 4096, batch_size=1)
        assert kv_int4 == pytest.approx(kv_fp16 / 4)


class TestModelEstimation:
    def test_fits_on_24gb_gpu(self):
        hw = _make_hw(vram_total=24.0, vram_free=22.0)
        est = estimate_model(LLAMA_8B, Precision.INT4, hw, ctx_len=4096)
        assert est.fit_rating == FitRating.RUNS
        assert est.total_gb < 22.0

    def test_does_not_fit_fp32_on_24gb(self):
        hw = _make_hw(vram_total=24.0, vram_free=22.0)
        big_model = ModelSpec("Llama 70B", "llama", 70.0, 80, 64, 8, 128, 131072)
        est = estimate_model(big_model, Precision.FP32, hw, ctx_len=4096)
        assert est.fit_rating == FitRating.NO_FIT

    def test_cuda_overhead_nvidia(self):
        hw_nvidia = _make_hw(vendor="nvidia")
        est = estimate_model(LLAMA_8B, Precision.INT4, hw_nvidia, ctx_len=4096)
        # CUDA overhead = 0.5 GB
        assert est.overhead_gb > 0.5

    def test_no_cuda_overhead_cpu(self):
        hw_cpu = _make_hw(vendor="none")
        est = estimate_model(LLAMA_8B, Precision.INT4, hw_cpu, ctx_len=4096)
        # No CUDA overhead, only 15% activation overhead
        expected_activation = est.weights_gb * 0.15
        assert est.overhead_gb == pytest.approx(expected_activation)

    def test_cpu_uses_ram(self):
        hw = _make_hw(vendor="none", ram_available=32.0)
        est = estimate_model(LLAMA_8B, Precision.INT4, hw, ctx_len=4096)
        assert est.available_memory_gb == pytest.approx(32.0)


class TestEstimateAll:
    def test_returns_all_combinations(self):
        hw = _make_hw()
        models = [LLAMA_8B]
        precisions = [Precision.FP16, Precision.INT8, Precision.INT4]
        results = estimate_all(hw, models, precisions, ctx_len=4096)
        assert len(results) == 3

    def test_default_precisions(self):
        hw = _make_hw()
        results = estimate_all(hw, [LLAMA_8B], ctx_len=4096)
        assert len(results) == 3  # FP16, INT8, INT4

    def test_to_dict(self):
        hw = _make_hw()
        est = estimate_model(LLAMA_8B, Precision.INT4, hw, ctx_len=4096)
        d = est.to_dict()
        assert "model" in d
        assert "precision" in d
        assert "total_gb" in d
        assert "fit_rating" in d
        assert "tokens_per_sec" in d
