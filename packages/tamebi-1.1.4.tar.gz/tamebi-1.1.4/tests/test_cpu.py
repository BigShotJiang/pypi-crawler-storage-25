from tamebi.hardware.cpu import CpuInfo, detect_cpu


def test_detect_cpu_returns_cpu_info():
    info = detect_cpu()
    assert isinstance(info, CpuInfo)
    assert info.cores >= 1
    assert info.threads >= 1
    assert len(info.model) > 0
    assert len(info.arch) > 0


def test_cpu_info_to_dict():
    info = CpuInfo(model="Test CPU", cores=8, threads=16, freq_mhz=3500.0, arch="x86_64")
    d = info.to_dict()
    assert d["model"] == "Test CPU"
    assert d["cores"] == 8
    assert d["threads"] == 16
    assert d["freq_mhz"] == 3500.0
    assert d["arch"] == "x86_64"
