from tamebi.hardware.gpu import GpuInfo, detect_gpus


def test_detect_gpus_returns_list():
    gpus = detect_gpus()
    assert isinstance(gpus, list)
    # May be empty on CI or CPU-only machines — that's fine
    for g in gpus:
        assert isinstance(g, GpuInfo)
        assert g.vendor in ("nvidia", "amd", "apple")
        assert g.vram_total_gb > 0


def test_gpu_info_to_dict():
    gpu = GpuInfo(
        vendor="nvidia",
        model="RTX 4090",
        vram_total_gb=24.0,
        vram_free_gb=22.5,
        cuda_version="12.4",
        compute_capability="8.9",
    )
    d = gpu.to_dict()
    assert d["vendor"] == "nvidia"
    assert d["model"] == "RTX 4090"
    assert d["vram_total_gb"] == 24.0
    assert d["cuda_version"] == "12.4"
    assert d["compute_capability"] == "8.9"


def test_gpu_info_to_dict_no_cuda():
    gpu = GpuInfo(vendor="amd", model="RX 7900", vram_total_gb=24.0, vram_free_gb=20.0)
    d = gpu.to_dict()
    assert "cuda_version" not in d
    assert "compute_capability" not in d
