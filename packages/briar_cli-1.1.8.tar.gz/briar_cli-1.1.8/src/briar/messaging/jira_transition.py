"""Jira ticket-transition writer.

Transitions a Jira ticket to a target status. The status name comes
either from ``extras["status"]`` at send time or from the binding's
``config: {status: "Done"}`` default.

`body` is recorded as an optional resolution comment (Jira's
transitions can carry a comment field)."""

from __future__ import annotations

import logging
from typing import Any, Dict, List

from briar.decorators import swallow_errors
from briar.env_vars import CredEnv
from briar.messaging._writer import MessageWriter, SendResult


log = logging.getLogger(__name__)


class JiraTransitionWriter(MessageWriter):
    kind = "jira-transition"

    def __init__(self, *, company: str = "", config: Dict[str, Any] = None) -> None:
        self._company = company
        self._config = config or {}
        self._default_status = str(self._config.get("status", ""))
        self._url = CredEnv.JIRA_URL.read(company=company) if company else ""
        self._email = CredEnv.JIRA_EMAIL.read(company=company) if company else ""
        self._token = CredEnv.JIRA_TOKEN.read(company=company) if company else ""
        self._client = None

    def _jira(self):
        if self._client is None:
            from atlassian import Jira

            self._client = Jira(url=self._url, username=self._email, password=self._token, cloud=True)
        return self._client

    def is_available(self) -> bool:
        return bool(self._url and self._email and self._token)

    @swallow_errors(default=SendResult(ok=False, detail="exception"), message="jira-transition send")
    def send(self, *, target: str, body: str, **extras: Any) -> SendResult:
        if not self.is_available():
            return SendResult(ok=False, detail="jira creds missing")
        if not target:
            return SendResult(ok=False, detail="jira-transition requires target=<TICKET-KEY>")
        status = extras.get("status") or self._default_status
        if not status:
            return SendResult(ok=False, detail="jira-transition requires extras.status or binding config.status")
        # The library exposes `set_issue_status` which wraps the
        # /transitions endpoint + the transition-id resolution.
        # `body` is appended as a comment via `comment=` when supplied.
        result = self._jira().set_issue_status(target, status, comment=body or None)
        if result is None:
            return SendResult(ok=True, ref=f"{target}→{status}")
        # Atlassian's response shape varies — treat any non-None as ok.
        return SendResult(ok=True, ref=str(result)[:200])

    @classmethod
    def required_env_vars(cls, company: str = "") -> List[str]:
        if not company:
            return []
        return [
            CredEnv.JIRA_URL.for_company(company),
            CredEnv.JIRA_EMAIL.for_company(company),
            CredEnv.JIRA_TOKEN.for_company(company),
        ]
