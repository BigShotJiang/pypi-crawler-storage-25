"""Local-file knowledge store — one markdown file per blob.

Default layout: ``./knowledge/<category>/<rest-of-name>.md``. A blob
named ``knowledge:acme`` becomes ``./knowledge/knowledge/acme.md``;
a name without a colon goes to ``./knowledge/<name>.md``."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from briar.storage.base import KnowledgeRef, KnowledgeStore, StoreBinding


log = logging.getLogger(__name__)

_DEFAULT_ROOT = Path("./knowledge")


class StoreFile(KnowledgeStore):
    name = "file"

    def __init__(self, root: Path) -> None:
        self._root = root
        self._root.mkdir(parents=True, exist_ok=True)
        log.debug("file-store init: root=%s", self._root)

    @classmethod
    def from_binding(cls, binding: StoreBinding, *, default_root: Optional[Path] = None) -> "StoreFile":
        root = Path(binding.root) if binding.root else (default_root or _DEFAULT_ROOT)
        return cls(root)

    def _path_for(self, blob_name: str) -> Path:
        """Three name shapes are supported:
        - `<category>:<rest>`      → `<root>/<category>/<rest>.md`
        - `<bare>`                 → `<root>/<bare>.md`
        - path-like (`/` or `.md`) → use the path verbatim."""
        if "/" in blob_name or blob_name.endswith(".md"):
            path = Path(blob_name)
            if not path.suffix:
                path = path.with_suffix(".md")
            return path
        category, sep, rest = blob_name.partition(":")
        if not sep:
            return self._root / f"{blob_name}.md"
        return self._root / category / f"{rest}.md"

    def _name_for(self, path: Path) -> str:
        try:
            rel = path.relative_to(self._root)
        except ValueError:
            return str(path)
        parts = rel.with_suffix("").parts
        if len(parts) == 1:
            return parts[0]
        category, *rest = parts
        return f"{category}:{'/'.join(rest)}"

    def put(self, blob_name: str, content: str, category: str = "") -> KnowledgeRef:
        path = self._path_for(blob_name)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            path.write_text(content)
        except OSError:
            log.exception("file-store put failed: blob=%s path=%s", blob_name, path)
            raise
        log.debug("file-store put: blob=%s path=%s bytes=%d", blob_name, path, len(content))
        return KnowledgeRef(
            name=blob_name,
            category=category or KnowledgeRef.category_of(blob_name),
            byte_count=len(content),
            updated_at="",
            extra={"path": str(path)},
        )

    def get(self, blob_name: str) -> str:
        path = self._path_for(blob_name)
        if not path.exists():
            log.debug("file-store get miss: blob=%s path=%s", blob_name, path)
            return ""
        log.debug("file-store get: blob=%s path=%s", blob_name, path)
        return path.read_text()

    def list(self, prefix: str = "") -> List[KnowledgeRef]:
        out: List[KnowledgeRef] = []
        for path in sorted(self._root.rglob("*.md")):
            blob_name = self._name_for(path)
            if prefix and not blob_name.startswith(prefix):
                continue
            stat = path.stat()
            out.append(
                KnowledgeRef(
                    name=blob_name,
                    category=KnowledgeRef.category_of(blob_name),
                    byte_count=stat.st_size,
                    updated_at=str(stat.st_mtime),
                    extra={"path": str(path)},
                )
            )
        return out

    def delete(self, blob_name: str) -> bool:
        path = self._path_for(blob_name)
        if not path.exists():
            return False
        path.unlink()
        parent = path.parent
        if parent != self._root and not any(parent.iterdir()):
            parent.rmdir()
        return True
