"""License key validation + 14-day trial.

Design goals:
  - Offline. No phone-home. Works in air-gapped factories.
  - Tamper-evident. HMAC over a JSON payload + a secret baked into the
    Pro build at release time.
  - Friendly degradation. If no key is provided, fall back to the trial.
    If the trial has expired, return an invalid LicenseStatus with a
    clear upgrade message — Core's QuantizeStep / serve command translate
    that into a ProFeatureRequired with a trial+pricing link.

Key format:
    darml_pro_<base64url_payload>_<hex_first_16_of_sig>

Payload (JSON, base64url-encoded, no padding):
    {"e": "email@host", "p": "pro|trial", "x": <unix_ts_expiry>}

Signing secret:
    Read from env var DARML_LICENSE_SIGNING_SECRET. The release build
    script bakes the production secret in via PyInstaller --add-data
    or similar; for development we accept the env var directly.

Trial file:
    ~/.darml/trial — JSON with {"started": <iso8601>, "machine": <hostname>}.
    First run of Pro creates it. Trial expires 14 days after `started`.
    Removing the file resets the trial — that's intentional. We're not
    shipping DRM; we're selling convenience.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import platform
import socket
import time
from datetime import datetime, timezone
from pathlib import Path

from darml.plugins import LicenseStatus

TRIAL_FILE = Path.home() / ".darml" / "trial"
TRIAL_DAYS = 14
KEY_PREFIX = "darml_pro_"

# Demo/dev secret — the production build process injects a different one
# at release time. Safe to commit; fake keys made with this won't match
# real releases.
_DEV_SECRET = b"darml-dev-do-not-ship-this-secret"


def _signing_secret() -> bytes:
    raw = os.getenv("DARML_LICENSE_SIGNING_SECRET")
    if raw:
        return raw.encode()
    return _DEV_SECRET


# ---------------------------------------------------------------- key codec


def _b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def encode_key(email: str, plan: str, expires_unix: int) -> str:
    """Mint a new license key. Internal — use _genkey.py for production."""
    payload = json.dumps({"e": email, "p": plan, "x": expires_unix}, separators=(",", ":"))
    payload_b = payload.encode()
    payload_b64 = _b64url_encode(payload_b)
    sig = hmac.new(_signing_secret(), payload_b, hashlib.sha256).hexdigest()[:16]
    return f"{KEY_PREFIX}{payload_b64}_{sig}"


def decode_and_verify(key: str) -> tuple[str, str, int] | None:
    """Return (email, plan, expires_unix) on success; None otherwise."""
    if not key.startswith(KEY_PREFIX):
        return None
    body = key[len(KEY_PREFIX):]
    if "_" not in body:
        return None
    payload_b64, sig = body.rsplit("_", 1)
    if len(sig) != 16:
        return None
    try:
        payload_b = _b64url_decode(payload_b64)
        expected = hmac.new(_signing_secret(), payload_b, hashlib.sha256).hexdigest()[:16]
    except Exception:
        return None
    if not hmac.compare_digest(expected, sig):
        return None
    try:
        data = json.loads(payload_b.decode())
        return str(data["e"]), str(data["p"]), int(data["x"])
    except Exception:
        return None


# ---------------------------------------------------------------- trial state


def _read_trial() -> dict | None:
    if not TRIAL_FILE.exists():
        return None
    try:
        return json.loads(TRIAL_FILE.read_text())
    except Exception:
        return None


def _start_trial() -> dict:
    TRIAL_FILE.parent.mkdir(parents=True, exist_ok=True)
    record = {
        "started": datetime.now(timezone.utc).isoformat(),
        "machine": f"{platform.system()}-{socket.gethostname()}",
    }
    TRIAL_FILE.write_text(json.dumps(record))
    return record


def _trial_status() -> LicenseStatus:
    record = _read_trial() or _start_trial()
    try:
        started = datetime.fromisoformat(record["started"])
    except Exception:
        # Corrupt file — treat as fresh trial.
        record = _start_trial()
        started = datetime.fromisoformat(record["started"])

    now = datetime.now(timezone.utc)
    elapsed_days = (now - started).total_seconds() / 86400
    remaining = TRIAL_DAYS - elapsed_days

    if remaining > 0:
        return LicenseStatus(
            valid=True,
            plan="trial",
            expires_at=record["started"],
            message=(
                f"Darml Pro trial: {remaining:.1f} days remaining. "
                f"Trial file: {TRIAL_FILE}"
            ),
        )
    return LicenseStatus(
        valid=False,
        plan="expired",
        expires_at=record["started"],
        message=(
            "Darml Pro 14-day trial has ended.\n"
            "  → Buy a license:  https://darml.dev/pricing\n"
            "  → Or unset DARML_LICENSE_KEY and use Darml Core (free, MIT)."
        ),
    )


# ---------------------------------------------------------------- public API


def validate_license() -> LicenseStatus:
    """Called by darml.plugins.hooks.license_validator on every is_pro check.

    Order of resolution:
      1. DARML_LICENSE_KEY env var → HMAC verify + expiry check
      2. Otherwise → trial state at ~/.darml/trial
    """
    raw = os.getenv("DARML_LICENSE_KEY", "").strip()
    if raw:
        decoded = decode_and_verify(raw)
        if decoded is None:
            return LicenseStatus(
                valid=False, plan="invalid",
                message=(
                    "DARML_LICENSE_KEY is set but does not verify. "
                    "Check for copy-paste truncation or contact "
                    "support@darml.dev."
                ),
            )
        email, plan, expires = decoded
        now = int(time.time())
        if expires < now:
            return LicenseStatus(
                valid=False, plan="expired", customer=email,
                expires_at=datetime.fromtimestamp(expires, tz=timezone.utc).isoformat(),
                message=(
                    f"Darml Pro license for {email} expired on "
                    f"{datetime.fromtimestamp(expires, tz=timezone.utc).date()}. "
                    "Renew at https://darml.dev/pricing."
                ),
            )
        return LicenseStatus(
            valid=True, plan=plan, customer=email,
            expires_at=datetime.fromtimestamp(expires, tz=timezone.utc).isoformat(),
            message=f"Darml Pro: licensed to {email} ({plan}).",
        )

    return _trial_status()
