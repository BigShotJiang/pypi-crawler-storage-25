"""Darml Pro — proprietary plugin pack for Darml Core.

Importing this module registers Pro adapters into `darml.plugins.hooks`.
That's the only side effect: Core then picks up quantizers, the ONNX→TFLite
converter, the build cache, and the FastAPI server through the registry.
"""

from __future__ import annotations

import logging
from pathlib import Path

from darml.config import get_settings
from darml.plugins import LicenseStatus, hooks

__version__ = "0.1.0"
log = logging.getLogger("darml_pro")


def _register_quantizers() -> None:
    from darml_pro.adapters.quantizers.onnx_quantizer import OnnxQuantizer
    from darml_pro.adapters.quantizers.tflite_quantizer import TFLiteQuantizer

    onnx_q = OnnxQuantizer()
    tflite_q = TFLiteQuantizer()
    hooks.quantizers[onnx_q.format] = onnx_q
    hooks.quantizers[tflite_q.format] = tflite_q


def _register_converters() -> None:
    from darml_pro.adapters.converters.onnx_to_tflite import ONNXToTFLiteConverter

    conv = ONNXToTFLiteConverter()
    hooks.converters[(conv.source_format, conv.target_format)] = conv


def _register_cache() -> None:
    from darml_pro.adapters.cache.filesystem_cache import FileSystemBuildCache

    settings = get_settings()
    if settings.cache_enabled:
        hooks.build_cache = FileSystemBuildCache(Path(settings.cache_dir))


def _register_server() -> None:
    """Lazy: don't import FastAPI until something actually calls server_factory."""

    def factory(container):  # type: ignore[no-untyped-def]
        from darml_pro.api.server import build_app
        return build_app(container)

    hooks.server_factory = factory


def _register_license() -> None:
    """Validate the Darml Pro license. Trial-aware.

    The actual HMAC validator + trial machinery live in darml_pro/license.py.
    Falls back to a permissive trial if that file isn't present yet
    (early-development convenience).
    """
    try:
        from darml_pro.license import validate_license  # type: ignore
        hooks.license_validator = validate_license
    except ImportError:
        hooks.license_validator = lambda: LicenseStatus(
            valid=True, plan="trial",
            message="Darml Pro: trial mode (no license validator wired yet)",
        )


def _bootstrap() -> None:
    try:
        _register_quantizers()
    except Exception as e:
        log.warning("darml_pro: quantizer registration failed: %s", e)
    try:
        _register_converters()
    except Exception as e:
        log.warning("darml_pro: converter registration failed: %s", e)
    try:
        _register_cache()
    except Exception as e:
        log.warning("darml_pro: cache registration failed: %s", e)
    try:
        _register_server()
    except Exception as e:
        log.warning("darml_pro: server registration failed: %s", e)
    _register_license()


_bootstrap()
