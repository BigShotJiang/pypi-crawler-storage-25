"""Internal — Darml Pro license key generator.

Operator-only. Never shipped to customers; only invoked by:
  - the Stripe webhook handler when a checkout completes
  - manual support flows (granting comp keys, support replacements)

Usage:
    DARML_LICENSE_SIGNING_SECRET=<prod-secret> python -m darml_pro._genkey \\
        --email customer@example.com --plan pro --years 1

The signing secret MUST come from your password manager / secrets vault,
NEVER from this repo. Without the prod secret set, this script generates
keys signed with the dev secret — they will not validate on real Pro
installs.
"""

from __future__ import annotations

import argparse
import sys
import time

from darml_pro.license import _signing_secret, encode_key, _DEV_SECRET


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Generate a Darml Pro license key.")
    p.add_argument("--email", required=True, help="Customer email")
    p.add_argument(
        "--plan", default="pro", choices=["pro", "trial", "team", "business"],
        help="Plan tier embedded in the key.",
    )
    p.add_argument(
        "--years", type=float, default=1.0,
        help="License validity in years from now (fractional allowed).",
    )
    args = p.parse_args(argv)

    if _signing_secret() == _DEV_SECRET:
        print(
            "WARNING: DARML_LICENSE_SIGNING_SECRET not set — using dev secret.\n"
            "  Keys generated with the dev secret will NOT validate on production.\n"
            "  Set DARML_LICENSE_SIGNING_SECRET from your secrets vault before "
            "minting customer keys.",
            file=sys.stderr,
        )

    expires = int(time.time() + args.years * 365 * 86400)
    key = encode_key(args.email, args.plan, expires)
    print(key)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
