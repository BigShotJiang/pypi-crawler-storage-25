"""ONNX → TFLite via onnx2tf, optionally with INT8 PTQ.

When ``quantize=True``, we ask onnx2tf to emit a full INT8 model using
its built-in PTQ pipeline. onnx2tf maps the ONNX graph straight to
native TFLite quantized ops (FULLY_CONNECTED int8, CONV_2D int8, etc.) —
no Flex/Select-TF ops, so the result loads on stock tflite-micro.

Calibration data
----------------
onnx2tf needs representative samples to compute activation scales. We
synthesize ``n_calibration_samples`` random N(0, 1) tensors matching the
model input shape. This is a "good enough" default for small dense and
conv-light models. Real-world Conv-heavy models will benefit from real
calibration data; that's a follow-up enhancement.
"""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import numpy as np

from darml.application.ports.converter import ConverterPort
from darml.domain.enums import ModelFormat
from darml.domain.exceptions import ConversionFailed


class ONNXToTFLiteConverter(ConverterPort):
    def __init__(self, n_calibration_samples: int = 64, random_seed: int = 0):
        self._n_samples = n_calibration_samples
        self._seed = random_seed

    @property
    def source_format(self) -> ModelFormat:
        return ModelFormat.ONNX

    @property
    def target_format(self) -> ModelFormat:
        return ModelFormat.TFLITE

    def convert(
        self,
        input_path: Path,
        output_path: Path,
        quantize: bool = False,
        calibration_data_path: Path | None = None,
    ) -> Path:
        try:
            import onnx2tf  # type: ignore
        except ImportError as e:
            raise ConversionFailed(
                f"ONNX→TFLite conversion import failed: {e}. "
                "Install ONNX→TFLite deps with: "
                "pip install tensorflow tf-keras onnx2tf onnx-graphsurgeon onnxsim sng4onnx"
            ) from e

        out_dir = output_path.parent / f"{output_path.stem}_onnx2tf"
        out_dir.mkdir(parents=True, exist_ok=True)

        kwargs: dict = {
            "input_onnx_file_path": str(input_path),
            "output_folder_path": str(out_dir),
            "non_verbose": True,
        }
        calib_npy: Path | None = None
        owns_calib: bool = False  # True if WE created the temp file (and must delete it)
        if quantize:
            if calibration_data_path is not None and calibration_data_path.exists():
                calib_npy = calibration_data_path
                owns_calib = False  # user-supplied; don't delete
            else:
                calib_npy = self._make_calibration(input_path)
                owns_calib = True
            input_name = self._first_input_name(input_path)
            # onnx2tf int8 PTQ: produces *_full_integer_quant.tflite alongside
            # the float .tflite. Calibration tuple is [op_name, npy_path, mode].
            # onnx2tf expects [input_name, numpy_path, mean, std] — mean and
            # std normalize the calibration tensors before the quantizer
            # measures activation ranges. Our random samples are already
            # N(0, 1), so identity normalization (mean=0, std=1).
            kwargs.update(
                output_integer_quantized_tflite=True,
                quant_type="per-tensor",
                custom_input_op_name_np_data_path=[
                    [input_name, str(calib_npy), [0.0], [1.0]]
                ],
            )

        try:
            onnx2tf.convert(**kwargs)
        except Exception as e:
            raise ConversionFailed(f"onnx2tf failed: {e}") from e
        finally:
            if owns_calib and calib_npy is not None and calib_npy.exists():
                calib_npy.unlink()

        chosen = self._pick_output(out_dir, prefer_int8=quantize)
        if chosen is None:
            raise ConversionFailed("onnx2tf produced no .tflite output.")
        shutil.copy2(chosen, output_path)
        return output_path

    # ────────────────────────────────────────────── helpers

    def _first_input_name(self, onnx_path: Path) -> str:
        import onnx
        model = onnx.load(str(onnx_path), load_external_data=False)
        return model.graph.input[0].name

    def _input_shape(self, onnx_path: Path) -> tuple[int, ...]:
        import onnx
        model = onnx.load(str(onnx_path), load_external_data=False)
        dims = [
            d.dim_value if d.dim_value > 0 else 1
            for d in model.graph.input[0].type.tensor_type.shape.dim
        ]
        return tuple(dims)

    def _make_calibration(self, onnx_path: Path) -> Path:
        """Synthesize a calibration .npy stack of N samples shaped for the model.

        onnx2tf in 'raw' mode wants a single ndarray with the FIRST dim
        being the number of samples. We replace the model's batch dim
        (typically 1) with self._n_samples and fill with N(0, 1).
        """
        shape = self._input_shape(onnx_path)
        rng = np.random.default_rng(self._seed)
        if shape:
            stack_shape = (self._n_samples, *shape[1:])
        else:
            stack_shape = (self._n_samples,)
        samples = rng.standard_normal(stack_shape).astype(np.float32)
        path = Path(tempfile.mkstemp(suffix=".npy")[1])
        np.save(path, samples)
        return path

    @staticmethod
    def _pick_output(out_dir: Path, prefer_int8: bool) -> Path | None:
        """onnx2tf emits multiple .tflite files when quantization is on
        (e.g. <model>_float32.tflite, <model>_full_integer_quant.tflite,
        <model>_integer_quant.tflite). Pick the right one for the request."""
        all_tflite = sorted(out_dir.glob("*.tflite"))
        if not all_tflite:
            return None
        if prefer_int8:
            # Prefer full integer (int8 in/out + int8 weights) for tflite-micro.
            for stem_marker in ("full_integer_quant", "integer_quant", "int8"):
                hits = [p for p in all_tflite if stem_marker in p.name]
                if hits:
                    return hits[0]
        floaty = [p for p in all_tflite
                  if all(m not in p.name for m in ("int8", "quant"))]
        return (floaty or all_tflite)[0]
