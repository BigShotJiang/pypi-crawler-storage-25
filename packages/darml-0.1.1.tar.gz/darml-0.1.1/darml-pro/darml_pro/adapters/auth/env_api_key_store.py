"""Env-driven API key store — good enough for self-hosted single-tenant.

Format of DARML_API_KEYS:
    "<secret>:<tier>[:<label>],<secret>:<tier>[:<label>],..."

Examples:
    DARML_API_KEYS="sk_test_freeperson:free:alice,sk_live_team:pro:acme"

For multi-tenant production, swap this for a SQLite/Postgres-backed
APIKeyStorePort implementation — the use cases never see the difference.
"""

from __future__ import annotations

from darml.application.ports.api_key_store import APIKeyStorePort
from darml.domain.api_key import APIKey, Tier


class EnvAPIKeyStore(APIKeyStorePort):
    def __init__(self, raw: str | None):
        self._by_key: dict[str, APIKey] = {}
        if not raw:
            return
        for entry in (e.strip() for e in raw.split(",") if e.strip()):
            parts = entry.split(":", 2)
            secret = parts[0].strip()
            tier_str = parts[1].strip().lower() if len(parts) >= 2 else "free"
            label = parts[2].strip() if len(parts) >= 3 else ""
            try:
                tier = Tier(tier_str)
            except ValueError:
                tier = Tier.FREE
            if secret:
                self._by_key[secret] = APIKey(key=secret, tier=tier, label=label)

    def find(self, key: str) -> APIKey | None:
        return self._by_key.get(key)
