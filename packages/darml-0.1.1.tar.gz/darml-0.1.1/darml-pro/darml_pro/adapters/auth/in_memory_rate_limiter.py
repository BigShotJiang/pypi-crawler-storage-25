"""In-memory daily rate limiter — single-process, single-host.

For multi-instance deployments (e.g. cloud build farm) replace with a
Redis-backed limiter; the port stays identical.
"""

from __future__ import annotations

import threading
from datetime import datetime, timezone

from darml.application.ports.rate_limiter import RateLimiterPort
from darml.domain.api_key import APIKey


class InMemoryDailyRateLimiter(RateLimiterPort):
    def __init__(self):
        self._lock = threading.Lock()
        self._counters: dict[tuple[str, str], int] = {}  # (key, utc_day) → count

    def consume(self, api_key: APIKey) -> tuple[bool, int]:
        if api_key.is_unlimited:
            return True, -1
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        with self._lock:
            slot = (api_key.key, today)
            used = self._counters.get(slot, 0)
            if used >= api_key.daily_quota:
                return False, 0
            self._counters[slot] = used + 1
            return True, api_key.daily_quota - (used + 1)
