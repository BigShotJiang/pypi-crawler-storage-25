"""Filesystem-backed build cache.

Layout under `cache_dir`:
    <cache_key>/
        artifact.zip       # the user-downloadable bundle
        firmware           # firmware path's basename, when present
        library            # library zip's basename, when present
        build_log.txt
        metadata.json      # status, warnings, target, timestamps

A hit copies these into the new build's workspace and patches paths on the
returned BuildResult so the rest of the pipeline (download endpoint, CLI
output) sees them as if produced fresh.
"""

from __future__ import annotations

import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from darml.application.ports.build_cache import BuildCachePort
from darml.domain.enums import BuildStatus
from darml.domain.models import BuildRequest, BuildResult

_BUF = 1 << 20  # 1 MiB


class FileSystemBuildCache(BuildCachePort):
    def __init__(self, cache_dir: Path):
        self._root = Path(cache_dir)
        self._root.mkdir(parents=True, exist_ok=True)

    def key_for(self, request: BuildRequest) -> str:
        h = hashlib.sha256()
        # Content-addressed: hash the model bytes themselves.
        with request.model_path.open("rb") as f:
            while True:
                chunk = f.read(_BUF)
                if not chunk:
                    break
                h.update(chunk)
        # Mix in every option that influences the rendered output.
        for piece in (
            request.target_id,
            "q1" if request.quantize else "q0",
            request.output_kind.value,
            request.report_mode.value,
            request.report_url or "",
            str(request.inference_interval_ms),
            request.wifi_ssid or "",
            request.wifi_password or "",
        ):
            h.update(b"\x00")
            h.update(piece.encode())
        return h.hexdigest()

    def _entry(self, key: str) -> Path:
        return self._root / key

    def get(self, key: str, into_workspace: Path, build_id: str) -> BuildResult | None:
        entry = self._entry(key)
        meta_path = entry / "metadata.json"
        if not meta_path.exists():
            return None
        try:
            meta = json.loads(meta_path.read_text())
        except Exception:
            return None

        into_workspace.mkdir(parents=True, exist_ok=True)
        artifact_zip = entry / "artifact.zip"
        new_artifact: Path | None = None
        if artifact_zip.exists():
            new_artifact = into_workspace / f"{build_id}.zip"
            shutil.copy2(artifact_zip, new_artifact)

        new_firmware: Path | None = None
        if meta.get("firmware_name"):
            src = entry / meta["firmware_name"]
            if src.exists():
                new_firmware = into_workspace / meta["firmware_name"]
                shutil.copy2(src, new_firmware)

        new_library: Path | None = None
        if meta.get("library_name"):
            src = entry / meta["library_name"]
            if src.exists():
                new_library = into_workspace / meta["library_name"]
                shutil.copy2(src, new_library)

        log_path = entry / "build_log.txt"
        log = log_path.read_text() if log_path.exists() else ""

        warnings = list(meta.get("warnings") or [])
        warnings.append(f"served from cache (key={key[:12]})")

        now = datetime.now(timezone.utc)
        return BuildResult(
            build_id=build_id,
            target_id=meta["target_id"],
            status=BuildStatus.COMPLETED,
            warnings=warnings,
            build_log=log,
            firmware_path=new_firmware,
            library_path=new_library,
            artifact_zip_path=new_artifact,
            created_at=now,
            completed_at=now,
        )

    def put(self, key: str, result: BuildResult) -> None:
        if result.status != BuildStatus.COMPLETED:
            return
        entry = self._entry(key)
        entry.mkdir(parents=True, exist_ok=True)

        firmware_name = None
        if result.firmware_path and result.firmware_path.exists():
            firmware_name = result.firmware_path.name
            shutil.copy2(result.firmware_path, entry / firmware_name)

        library_name = None
        if result.library_path and result.library_path.exists():
            library_name = result.library_path.name
            shutil.copy2(result.library_path, entry / library_name)

        if result.artifact_zip_path and result.artifact_zip_path.exists():
            shutil.copy2(result.artifact_zip_path, entry / "artifact.zip")

        if result.build_log:
            (entry / "build_log.txt").write_text(result.build_log)

        meta = {
            "target_id": result.target_id,
            "warnings": list(result.warnings),
            "firmware_name": firmware_name,
            "library_name": library_name,
            "cached_at": datetime.now(timezone.utc).isoformat(),
        }
        (entry / "metadata.json").write_text(json.dumps(meta, indent=2))
