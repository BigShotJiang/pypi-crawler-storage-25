"""Static INT8 quantization for ONNX models, MCU-deployable.

Uses `onnxruntime.quantization.quantize_static` with QDQ format
(QuantizeLinear/DequantizeLinear nodes wrapping each op). This is the
only ONNX quantization variant that onnx2tf can compile to native TFLite
ops. The previous `quantize_dynamic` approach produced QLinear* ops that
fall back to Flex (Select-TF) ops, which `tflite-micro` on ESP32/STM32
cannot run.

Calibration data
----------------
Static quantization needs a few representative input samples to compute
activation scales. We support two sources:

  - `calibration_data` argument: a path to a .npy / .npz with
    pre-recorded inputs. Recommended for production.

  - default: random N(0, 1) tensors matching the model's input shape.
    Cheap and keeps the user-facing API trivial; accuracy on small
    dense networks is usually within 1–3% of FP32. For Conv-heavy
    models with real-world input distributions far from N(0, 1),
    consider supplying real calibration data.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

from darml.application.ports.quantizer import QuantizerPort
from darml.domain.enums import ModelFormat
from darml.domain.exceptions import QuantizationFailed
from darml.domain.models import QuantizeResult


class OnnxQuantizer(QuantizerPort):
    def __init__(
        self,
        n_calibration_samples: int = 64,
        calibration_data: Path | None = None,
        random_seed: int = 0,
    ):
        self._n_samples = n_calibration_samples
        self._calibration_data = calibration_data
        self._seed = random_seed

    @property
    def format(self) -> ModelFormat:
        return ModelFormat.ONNX

    def quantize(self, input_path: Path, output_path: Path) -> QuantizeResult:
        try:
            import onnx  # type: ignore
            from onnxruntime.quantization import (  # type: ignore
                CalibrationDataReader,
                QuantFormat,
                QuantType,
                quantize_static,
            )
            from onnxruntime.quantization.shape_inference import quant_pre_process  # type: ignore
        except ImportError as e:
            raise QuantizationFailed(
                f"ONNX quantization import failed: {e}. "
                "Install ONNX deps with: pip install onnx onnxruntime sympy"
            ) from e

        # quantize_static requires shape inference to determine activation
        # tensor shapes for calibration. quant_pre_process runs symbolic
        # shape inference + constant folding. If it fails (rare; some
        # models have unusual ops), fall back to a plain copy and let
        # quantize_static do its best.
        prepped = output_path.with_suffix(".prepped.onnx")
        try:
            quant_pre_process(str(input_path), str(prepped), skip_symbolic_shape=False)
        except Exception:
            try:
                model = onnx.load(str(input_path), load_external_data=False)
                onnx.save(model, str(prepped))
            except Exception as e:
                raise QuantizationFailed(f"ONNX pre-processing failed: {e}") from e

        try:
            reader = self._build_calibration_reader(prepped, CalibrationDataReader)
            quantize_static(
                model_input=str(prepped),
                model_output=str(output_path),
                calibration_data_reader=reader,
                quant_format=QuantFormat.QDQ,
                activation_type=QuantType.QInt8,
                weight_type=QuantType.QInt8,
                per_channel=False,  # simpler graph; onnx2tf maps cleanly
            )
        except Exception as e:
            raise QuantizationFailed(f"ONNX static quantization failed: {e}") from e
        finally:
            prepped.unlink(missing_ok=True)

        return QuantizeResult(
            input_path=input_path,
            output_path=output_path,
            original_size_bytes=input_path.stat().st_size,
            quantized_size_bytes=output_path.stat().st_size,
        )

    # ────────────────────────────────────────────────────────── helpers

    def _build_calibration_reader(self, model_path: Path, reader_base):
        """Construct a CalibrationDataReader yielding inputs the quantizer feeds
        through the network to measure activation ranges.

        Single-input models only, for now. Multi-input support requires
        the user to provide the matched arrays via .npz keyed by input name.
        """
        import onnx

        model = onnx.load(str(model_path), load_external_data=False)
        if len(model.graph.input) != 1:
            raise QuantizationFailed(
                f"Static quantization currently supports single-input models; "
                f"this one has {len(model.graph.input)}. Provide a custom "
                f"calibration_data .npz keyed by input name."
            )
        input_meta = model.graph.input[0]
        input_name = input_meta.name
        shape = [
            d.dim_value if d.dim_value > 0 else 1
            for d in input_meta.type.tensor_type.shape.dim
        ]

        if self._calibration_data and self._calibration_data.exists():
            samples = self._load_user_calibration(self._calibration_data, input_name)
        else:
            rng = np.random.default_rng(self._seed)
            samples = [
                rng.standard_normal(shape).astype(np.float32)
                for _ in range(self._n_samples)
            ]

        class _Reader(reader_base):
            def __init__(self):
                super().__init__()
                self._iter = iter(samples)

            def get_next(self):
                try:
                    arr = next(self._iter)
                except StopIteration:
                    return None
                return {input_name: arr}

        return _Reader()

    @staticmethod
    def _load_user_calibration(path: Path, input_name: str) -> list[np.ndarray]:
        if path.suffix == ".npz":
            data = np.load(path)
            if input_name in data.files:
                arr = data[input_name]
                # Allow either a single array or a stack of N samples along axis 0
                return [arr] if arr.ndim == len(arr.shape) and arr.shape[0] == 1 else list(arr)
            return [data[k] for k in data.files]
        return [np.load(path)]
