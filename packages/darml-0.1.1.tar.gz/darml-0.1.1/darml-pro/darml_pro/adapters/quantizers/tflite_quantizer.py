from pathlib import Path

from darml.application.ports.quantizer import QuantizerPort
from darml.domain.enums import ModelFormat
from darml.domain.exceptions import QuantizationFailed
from darml.domain.models import QuantizeResult


class TFLiteQuantizer(QuantizerPort):
    """INT8 PTQ for TFLite models.

    Limitation: post-training quantization from a pre-exported .tflite file is
    not supported by the TFLite converter — the converter requires a Keras
    model, SavedModel, or concrete function as input. Closing this gap
    properly means accepting SavedModel uploads as a separate input format,
    not supported in v1.

    Recommended quantization path for v1: upload your model in ONNX format
    with `quantize=true` — `OnnxQuantizer` produces real INT8 output, which
    the ONNX→TFLite converter then turns into a quantized .tflite for the
    target.

    This class is registered for completeness so the QuantizerFactory has a
    clear story for `ModelFormat.TFLITE`. Not registered in the default
    container — see `darml/container.py`.
    """

    @property
    def format(self) -> ModelFormat:
        return ModelFormat.TFLITE

    def quantize(self, input_path: Path, output_path: Path) -> QuantizeResult:
        raise QuantizationFailed(
            "INT8 post-training quantization of a pre-exported .tflite file "
            "is not supported by the TFLite converter — it requires a Keras "
            "model, SavedModel, or concrete function as input. Two options:\n"
            "  1) Upload the model in ONNX format with quantize=true. The "
            "ONNX → quantized ONNX → TFLite path is fully supported and "
            "produces a quantized .tflite for the target.\n"
            "  2) Pre-quantize before upload: re-export from your training "
            "framework with `tf.lite.TFLiteConverter` and "
            "`optimizations=[tf.lite.Optimize.DEFAULT]`. The size_check "
            "step will detect the model is already INT8 and skip this stage."
        )
