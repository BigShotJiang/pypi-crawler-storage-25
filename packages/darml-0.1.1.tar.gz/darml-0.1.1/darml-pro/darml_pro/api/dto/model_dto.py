from pydantic import BaseModel

from darml.domain.models import ModelInfo, SizeCheckResult


class ModelInfoDTO(BaseModel):
    format: str
    file_size_bytes: int
    input_shape: list[int]
    output_shape: list[int]
    input_dtype: str
    output_dtype: str
    num_ops: int
    is_quantized: bool
    ops_list: list[str]

    @classmethod
    def from_domain(cls, m: ModelInfo) -> "ModelInfoDTO":
        return cls(
            format=m.format.value,
            file_size_bytes=m.file_size_bytes,
            input_shape=list(m.input_shape),
            output_shape=list(m.output_shape),
            input_dtype=m.input_dtype.value,
            output_dtype=m.output_dtype.value,
            num_ops=m.num_ops,
            is_quantized=m.is_quantized,
            ops_list=list(m.ops_list),
        )


class SizeCheckDTO(BaseModel):
    fits: bool
    model_ram_kb: float
    model_flash_kb: float
    target_ram_kb: float
    target_flash_kb: float
    warning: str | None = None

    @classmethod
    def from_domain(cls, s: SizeCheckResult) -> "SizeCheckDTO":
        return cls(
            fits=s.fits,
            model_ram_kb=s.model_ram_kb,
            model_flash_kb=s.model_flash_kb,
            target_ram_kb=s.target_ram_kb,
            target_flash_kb=s.target_flash_kb,
            warning=s.warning,
        )


class CheckResponseDTO(BaseModel):
    model: ModelInfoDTO
    size: SizeCheckDTO
