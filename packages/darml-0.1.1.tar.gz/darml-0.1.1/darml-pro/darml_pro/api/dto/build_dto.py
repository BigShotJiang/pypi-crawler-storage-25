from pydantic import BaseModel

from darml.domain.models import BuildResult


class BuildStartResponseDTO(BaseModel):
    build_id: str
    status: str


class BuildStatusDTO(BaseModel):
    build_id: str
    target: str
    status: str
    warnings: list[str]
    error: str | None = None
    artifact_available: bool
    build_time_seconds: float | None = None
    build_log: str | None = None

    @classmethod
    def from_domain(cls, b: BuildResult, include_log: bool = True) -> "BuildStatusDTO":
        # Cap log payload to avoid blowing up polling JSON (PIO logs can be
        # multi-MB). Tail is what users care about for debugging.
        log = None
        if include_log and b.build_log:
            tail_chars = 64 * 1024
            log = (
                b.build_log
                if len(b.build_log) <= tail_chars
                else "... [truncated, see GET /v1/build/{id}/log for full] ...\n"
                + b.build_log[-tail_chars:]
            )
        return cls(
            build_id=b.build_id,
            target=b.target_id,
            status=b.status.value,
            warnings=list(b.warnings),
            error=b.error,
            artifact_available=b.artifact_zip_path is not None
            and b.artifact_zip_path.exists(),
            build_time_seconds=b.build_time_seconds,
            build_log=log,
        )


class TargetDTO(BaseModel):
    id: str
    ram_kb: int
    psram_kb: int
    flash_kb: int
    runtime: str
    platformio_board: str | None = None
