from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from darml.domain.exceptions import (
    DarmlError,
    AuthRequired,
    BuildFailed,
    BuildNotFound,
    ConversionFailed,
    FlashFailed,
    ModelFormatUnsupported,
    ModelParseError,
    ModelTooLarge,
    ModelTooLargeUpload,
    QuantizationFailed,
    QuotaExceeded,
    TargetIncompatible,
    TargetUnknown,
    ToolchainMissing,
)

_STATUS_MAP: dict[type[DarmlError], int] = {
    ModelFormatUnsupported: 400,
    ModelParseError: 400,
    TargetUnknown: 404,
    TargetIncompatible: 400,
    ModelTooLarge: 413,
    ModelTooLargeUpload: 413,
    BuildNotFound: 404,
    BuildFailed: 500,
    ToolchainMissing: 503,
    QuantizationFailed: 500,
    ConversionFailed: 500,
    FlashFailed: 500,
    AuthRequired: 401,
    QuotaExceeded: 429,
}


def install(app: FastAPI) -> None:
    @app.exception_handler(DarmlError)
    async def _handle(request: Request, exc: DarmlError):  # noqa: ARG001
        status = _STATUS_MAP.get(type(exc), 400)
        return JSONResponse(
            status_code=status,
            content={"error": type(exc).__name__, "detail": str(exc)},
        )
