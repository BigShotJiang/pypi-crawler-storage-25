"""Shared upload helper — enforces DARML_MAX_MODEL_SIZE_MB.

Reads an UploadFile in 1 MiB chunks, aborting (and raising
`ModelTooLargeUpload`) the moment we cross the configured cap. We don't
trust the `Content-Length` header — clients can lie or stream without it
— so we cap the byte stream itself.
"""

from __future__ import annotations

import shutil
from pathlib import Path

from fastapi import UploadFile

from darml.config import Settings
from darml.domain.exceptions import ModelTooLargeUpload

_CHUNK = 1 << 20  # 1 MiB


async def save_capped(upload: UploadFile, dst: Path, settings: Settings) -> Path:
    """Stream `upload` into `dst`, capping at settings.max_model_size_mb."""
    cap_bytes = settings.max_model_size_mb * 1024 * 1024
    seen = 0
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open("wb") as out:
        while True:
            chunk = await upload.read(_CHUNK)
            if not chunk:
                break
            seen += len(chunk)
            if seen > cap_bytes:
                out.close()
                dst.unlink(missing_ok=True)
                raise ModelTooLargeUpload(
                    f"Uploaded model exceeds DARML_MAX_MODEL_SIZE_MB="
                    f"{settings.max_model_size_mb}. Reject at "
                    f"{seen} bytes."
                )
            out.write(chunk)
    return dst


async def save_capped_to_temp(upload: UploadFile, settings: Settings) -> Path:
    """Convenience wrapper for routes that just need a tmp file."""
    import tempfile

    suffix = Path(upload.filename or "model").suffix or ".bin"
    fd, path = tempfile.mkstemp(suffix=suffix)
    Path(path).unlink()  # we re-create via save_capped
    try:
        return await save_capped(upload, Path(path), settings)
    except Exception:
        Path(path).unlink(missing_ok=True)
        raise


def copy_capped_sync(src_file, dst: Path, settings: Settings) -> Path:
    """Synchronous variant for sites that already hold a file-like handle."""
    cap_bytes = settings.max_model_size_mb * 1024 * 1024
    seen = 0
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open("wb") as out:
        while True:
            chunk = src_file.read(_CHUNK)
            if not chunk:
                break
            seen += len(chunk)
            if seen > cap_bytes:
                out.close()
                dst.unlink(missing_ok=True)
                raise ModelTooLargeUpload(
                    f"Uploaded model exceeds DARML_MAX_MODEL_SIZE_MB="
                    f"{settings.max_model_size_mb}."
                )
            out.write(chunk)
    return dst


# Re-exported so routes can use a pre-bound shutil reference if needed.
__all__ = ["save_capped", "save_capped_to_temp", "copy_capped_sync", "shutil"]
