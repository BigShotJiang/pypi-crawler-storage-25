from fastapi import APIRouter, Depends

from darml.container import Container
from darml_pro.api.deps import get_container
from darml_pro.api.dto.build_dto import TargetDTO

router = APIRouter(prefix="/v1", tags=["targets"])


@router.get("/targets")
async def list_targets(container: Container = Depends(get_container)) -> dict:
    items = [
        TargetDTO(
            id=t.id,
            ram_kb=t.ram_kb,
            psram_kb=t.psram_kb,
            flash_kb=t.flash_kb,
            runtime=t.runtime.value,
            platformio_board=t.platformio_board,
        )
        for t in container.list_targets.execute()
    ]
    return {"targets": [i.model_dump() for i in items]}
