from pathlib import Path

from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter(tags=["dashboard"])

_DASHBOARD = Path(__file__).parent.parent / "dashboard.html"


@router.get("/", response_class=HTMLResponse)
async def dashboard() -> str:
    if _DASHBOARD.exists():
        return _DASHBOARD.read_text()
    return "<html><body><h1>Darml</h1><p>Dashboard not installed.</p></body></html>"
