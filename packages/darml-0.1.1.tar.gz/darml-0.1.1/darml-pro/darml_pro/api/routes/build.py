from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, PlainTextResponse

from darml.container import Container
from darml.domain.api_key import APIKey
from darml.domain.enums import OutputKind, ReportMode
from darml.domain.models import BuildRequest
from darml_pro.api.auth import consume_build_quota
from darml_pro.api.deps import get_container
from darml_pro.api.dto.build_dto import BuildStartResponseDTO, BuildStatusDTO
from darml_pro.api.upload import save_capped

router = APIRouter(prefix="/v1", tags=["build"])


@router.post("/build", response_model=BuildStartResponseDTO, status_code=202)
async def start_build(
    target: str = Form(...),
    quantize: bool = Form(False),
    output: str = Form("firmware"),
    report_mode: str = Form("serial"),
    report_url: str | None = Form(None),
    file: UploadFile = File(...),
    calibration_data: UploadFile | None = File(None),
    container: Container = Depends(get_container),
    api_key: APIKey = Depends(consume_build_quota),
) -> BuildStartResponseDTO:
    uploads_dir = Path(container.settings.data_dir) / "uploads"
    suffix = Path(file.filename or "model").suffix or ".bin"
    upload_path = uploads_dir / f"{uuid4().hex}{suffix}"
    await save_capped(file, upload_path, container.settings)

    calib_path: Path | None = None
    if calibration_data is not None and calibration_data.filename:
        calib_suffix = Path(calibration_data.filename).suffix or ".npy"
        calib_path = uploads_dir / f"{uuid4().hex}_calib{calib_suffix}"
        await save_capped(calibration_data, calib_path, container.settings)

    request = BuildRequest(
        model_path=upload_path,
        target_id=target,
        quantize=quantize,
        calibration_data_path=calib_path,
        output_kind=OutputKind(output),
        report_mode=ReportMode(report_mode),
        report_url=report_url,
    )
    result = await container.build_firmware.start(request)
    return BuildStartResponseDTO(build_id=result.build_id, status=result.status.value)


@router.get("/build/{build_id}", response_model=BuildStatusDTO)
async def get_build(
    build_id: str,
    container: Container = Depends(get_container),
) -> BuildStatusDTO:
    result = await container.get_build_status.execute(build_id)
    return BuildStatusDTO.from_domain(result)


@router.get("/build/{build_id}/download")
async def download_build(
    build_id: str,
    container: Container = Depends(get_container),
) -> FileResponse:
    result = await container.get_build_status.execute(build_id)
    if not result.artifact_zip_path or not result.artifact_zip_path.exists():
        raise HTTPException(status_code=404, detail="Artifact not yet available.")
    return FileResponse(
        path=str(result.artifact_zip_path),
        media_type="application/zip",
        filename=f"darml-{build_id}.zip",
    )


@router.get("/build/{build_id}/log", response_class=PlainTextResponse)
async def build_log(
    build_id: str,
    container: Container = Depends(get_container),
) -> str:
    """Return the full build log (untruncated) — for debugging large failures."""
    result = await container.get_build_status.execute(build_id)
    if not result.build_log:
        # Fall back to disk if the in-memory copy was dropped (e.g. server restart).
        log_path = container.storage.workspace(build_id) / "build_log.txt"
        if log_path.exists():
            return log_path.read_text()
        raise HTTPException(status_code=404, detail="No build log for this build.")
    return result.build_log
