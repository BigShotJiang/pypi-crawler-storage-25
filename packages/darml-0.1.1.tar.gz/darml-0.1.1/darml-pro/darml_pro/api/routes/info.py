from pathlib import Path

from fastapi import APIRouter, Depends, File, UploadFile

from darml.container import Container
from darml_pro.api.deps import get_container
from darml_pro.api.dto.model_dto import ModelInfoDTO
from darml_pro.api.upload import save_capped_to_temp

router = APIRouter(prefix="/v1", tags=["info"])


@router.post("/info", response_model=ModelInfoDTO)
async def info(
    file: UploadFile = File(...),
    container: Container = Depends(get_container),
) -> ModelInfoDTO:
    tmp_path = await save_capped_to_temp(file, container.settings)
    try:
        model_info = container.parse_model.execute(tmp_path)
        return ModelInfoDTO.from_domain(model_info)
    finally:
        Path(tmp_path).unlink(missing_ok=True)
