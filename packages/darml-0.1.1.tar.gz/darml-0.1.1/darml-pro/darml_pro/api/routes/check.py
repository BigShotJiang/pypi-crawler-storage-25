from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, UploadFile

from darml.container import Container
from darml_pro.api.deps import get_container
from darml_pro.api.dto.model_dto import CheckResponseDTO, ModelInfoDTO, SizeCheckDTO
from darml_pro.api.upload import save_capped_to_temp

router = APIRouter(prefix="/v1", tags=["check"])


@router.post("/check", response_model=CheckResponseDTO)
async def check(
    target: str = Form(...),
    file: UploadFile = File(...),
    container: Container = Depends(get_container),
) -> CheckResponseDTO:
    tmp_path = await save_capped_to_temp(file, container.settings)
    try:
        model_info = container.parse_model.execute(tmp_path)
        size = container.check_size.execute(model_info, target)
        return CheckResponseDTO(
            model=ModelInfoDTO.from_domain(model_info),
            size=SizeCheckDTO.from_domain(size),
        )
    finally:
        Path(tmp_path).unlink(missing_ok=True)
