"""Stripe billing routes — checkout + webhook.

Configuration (all env vars):
  STRIPE_SECRET_KEY          sk_live_… or sk_test_…
  STRIPE_WEBHOOK_SECRET      whsec_… (from `stripe listen` or dashboard)
  STRIPE_PRICE_PRO_CLOUD     price_… for €49/mo Pro Cloud subscription
  STRIPE_PRICE_PRO_SELFHOST  price_… for €399/yr Pro self-hosted license
  DARML_PUBLIC_BASE_URL       https://darml.dev (used in success/cancel URLs)

Endpoints:
  POST /v1/billing/checkout/{plan}    → 303 redirect to Stripe Checkout
                                        plan ∈ {pro-cloud, pro-selfhost}
  POST /v1/billing/webhook            → Stripe → us; verifies signature

The webhook currently logs the event type. Wire your provisioning flow
(e.g. mint a Pro API key on `checkout.session.completed`) inside
`_handle_event`.

Stripe products are NOT created automatically — create them once in your
dashboard (€49/mo recurring + €399/yr recurring for self-host) and copy
the price IDs into the env vars above.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse

from darml.container import Container
from darml_pro.api.deps import get_container

router = APIRouter(prefix="/v1/billing", tags=["billing"])
log = logging.getLogger("darml.billing")

_PLAN_TO_PRICE_FIELD = {
    "pro-cloud": "stripe_price_pro_cloud",
    "pro-selfhost": "stripe_price_pro_selfhost",
}


@router.post("/checkout/{plan}")
async def checkout(plan: str, container: Container = Depends(get_container)):
    settings = container.settings
    if not settings.stripe_secret_key:
        raise HTTPException(status_code=503, detail="Stripe is not configured on this server.")
    price_field = _PLAN_TO_PRICE_FIELD.get(plan)
    if price_field is None:
        raise HTTPException(status_code=404, detail=f"Unknown plan: {plan}")
    price_id = getattr(settings, price_field)
    if not price_id:
        raise HTTPException(status_code=503, detail=f"Plan {plan} not configured (missing price id).")

    try:
        import stripe  # type: ignore
    except ImportError as e:
        raise HTTPException(
            status_code=503,
            detail="stripe SDK not installed on the server. pip install stripe",
        ) from e

    stripe.api_key = settings.stripe_secret_key
    base = settings.public_base_url.rstrip("/")
    try:
        session = stripe.checkout.Session.create(
            mode="subscription",
            line_items=[{"price": price_id, "quantity": 1}],
            success_url=f"{base}/billing/success?session_id={{CHECKOUT_SESSION_ID}}",
            cancel_url=f"{base}/billing/cancel",
            allow_promotion_codes=True,
        )
    except Exception as e:
        log.exception("Stripe checkout failed")
        raise HTTPException(status_code=502, detail=f"Stripe error: {e}")

    return RedirectResponse(url=session.url, status_code=303)


@router.post("/webhook")
async def webhook(request: Request, container: Container = Depends(get_container)):
    settings = container.settings
    if not settings.stripe_webhook_secret:
        raise HTTPException(status_code=503, detail="Stripe webhook secret not configured.")
    try:
        import stripe  # type: ignore
    except ImportError as e:
        raise HTTPException(status_code=503, detail="stripe SDK not installed.") from e

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")
    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.stripe_webhook_secret,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=f"Invalid payload: {e}")
    except Exception as e:
        # Includes stripe.error.SignatureVerificationError
        raise HTTPException(status_code=400, detail=f"Invalid signature: {e}")

    _handle_event(event)
    return JSONResponse({"received": True})


def _handle_event(event: dict) -> None:
    """Dispatch Stripe events to provisioning logic.

    On `checkout.session.completed` we mint a license key signed with the
    server's DARML_LICENSE_SIGNING_SECRET and store it for delivery. The
    actual email delivery is left as an extension point — wire your
    transactional email provider (Postmark, Resend, SES) where indicated.

    On `customer.subscription.deleted` / `invoice.payment_failed` we log;
    revocation requires a separate signed-revocation-list mechanism not
    yet implemented (offline keys can't be revoked retroactively).
    """
    import time

    from darml_pro.license import encode_key

    event_type = event.get("type", "unknown")
    obj = event.get("data", {}).get("object", {}) or {}
    log.info("stripe event: %s id=%s", event_type, event.get("id"))

    if event_type == "checkout.session.completed":
        email = (
            obj.get("customer_details", {}).get("email")
            or obj.get("customer_email")
            or ""
        )
        if not email:
            log.error("checkout.session.completed missing email; cannot mint key")
            return

        # Plan & validity from the price id we put on the session.
        price_id = ""
        try:
            line_items = obj.get("line_items") or {}
            data = line_items.get("data") or []
            if data:
                price_id = data[0].get("price", {}).get("id", "")
        except Exception:
            pass

        years = 1.0  # subscription seats default to 1 year per renewal
        plan = "pro"
        expires = int(time.time() + years * 365 * 86400)
        key = encode_key(email, plan, expires)

        log.info("minted Darml Pro key for %s (expires unix=%d)", email, expires)
        _deliver_key(email, key, plan, expires)

    elif event_type in ("customer.subscription.deleted", "invoice.payment_failed"):
        cust = obj.get("customer", "?")
        log.warning(
            "stripe %s for customer=%s — manual follow-up may be needed "
            "(offline keys cannot be revoked retroactively without a CRL)",
            event_type, cust,
        )


def _deliver_key(email: str, key: str, plan: str, expires_unix: int) -> None:
    """Stub for delivering a freshly-minted key.

    Replace with your transactional email provider — e.g.:
        from postmarker.core import PostmarkClient
        PostmarkClient(server_token=...).emails.send(...)

    For now we log to stderr so support can copy-paste manually until
    email delivery is wired.
    """
    import sys
    print(
        f"[darml-pro] DELIVER → {email}: {key} (plan={plan} expires={expires_unix})",
        file=sys.stderr, flush=True,
    )
