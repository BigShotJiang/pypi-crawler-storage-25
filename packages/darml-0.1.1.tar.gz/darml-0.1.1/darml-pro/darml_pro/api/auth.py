"""FastAPI dependencies for API-key auth + per-key rate limiting.

Behavior:
  - DARML_AUTH_ENABLED=false (default) → all endpoints open, anonymous PRO.
  - DARML_AUTH_ENABLED=true → /v1/build requires X-API-Key header; metadata
    endpoints (/v1/info, /v1/check, /v1/targets) stay open.

The API-key store and rate limiter are Pro singletons constructed lazily
on first call. Core's Container deliberately does not know about them —
auth is a Pro-only concern, accessible only when the Pro server is
mounted.
"""

from __future__ import annotations

from functools import lru_cache

from fastapi import Header, Request

from darml.domain.api_key import APIKey, Tier
from darml.domain.exceptions import AuthRequired, QuotaExceeded
from darml_pro.adapters.auth.env_api_key_store import EnvAPIKeyStore
from darml_pro.adapters.auth.in_memory_rate_limiter import InMemoryDailyRateLimiter


_ANONYMOUS_PRO = APIKey(key="anon", tier=Tier.PRO, label="anonymous-local")


@lru_cache(maxsize=1)
def _api_key_store(api_keys_raw: str) -> EnvAPIKeyStore:
    return EnvAPIKeyStore(api_keys_raw)


@lru_cache(maxsize=1)
def _rate_limiter() -> InMemoryDailyRateLimiter:
    # Process-local; for multi-instance Fly/Railway swap to a Redis-backed
    # implementation of RateLimiterPort and replace this factory.
    return InMemoryDailyRateLimiter()


def require_api_key(
    request: Request,
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
) -> APIKey:
    container = request.app.state.container
    settings = container.settings
    if not settings.auth_enabled:
        return _ANONYMOUS_PRO
    if not x_api_key:
        raise AuthRequired("Missing X-API-Key header.")
    found = _api_key_store(settings.api_keys_raw).find(x_api_key)
    if found is None:
        raise AuthRequired("Unknown API key.")
    return found


def consume_build_quota(
    request: Request,
    x_api_key: str | None = Header(default=None, alias="X-API-Key"),
) -> APIKey:
    """Like require_api_key, but ALSO debits one build from today's quota."""
    api_key = require_api_key(request, x_api_key)
    allowed, remaining = _rate_limiter().consume(api_key)
    if not allowed:
        raise QuotaExceeded(
            f"Daily build quota exhausted (free tier = {api_key.daily_quota}/day). "
            "Upgrade to Pro for unlimited builds: see /v1/billing/checkout/pro-cloud."
        )
    return api_key
