import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from darml import __version__
from darml.container import get_container
from darml_pro.api import errors
from darml_pro.api.routes import billing, build, check, dashboard, health, info, targets

log = logging.getLogger("darml.server")


def _init_sentry(dsn: str) -> None:
    if not dsn:
        return
    try:
        import sentry_sdk  # type: ignore
        from sentry_sdk.integrations.asgi import SentryAsgiMiddleware  # noqa: F401
    except ImportError:
        log.warning("SENTRY_DSN set but sentry-sdk not installed; skipping init.")
        return
    sentry_sdk.init(
        dsn=dsn,
        traces_sample_rate=0.1,
        send_default_pii=False,
    )
    log.info("Sentry initialized for error reporting.")


def build_app(container=None) -> FastAPI:
    """Construct the FastAPI app. Called by darml.plugins.server_factory."""
    if container is None:
        container = get_container()
    _init_sentry(container.settings.sentry_dsn)

    app = FastAPI(
        title="Darml",
        description="Model-to-firmware compiler for edge AI.",
        version=__version__,
    )
    app.state.container = container

    # CORS — origins come from DARML_CORS_ORIGINS (comma-separated). Defaults
    # to "*" so the bundled dashboard works when served from a different
    # origin (e.g. docs site, custom front-end).
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(container.settings.cors_origins),
        allow_credentials=False,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(health.router)
    app.include_router(targets.router)
    app.include_router(info.router)
    app.include_router(check.router)
    app.include_router(build.router)
    app.include_router(billing.router)
    app.include_router(dashboard.router)

    errors.install(app)
    return app


# Backwards-compat alias for any tooling that still references create_app/app.
create_app = build_app
app = None  # set lazily by darml.__main__ / darml.plugins.server_factory
