"""License key codec, trial state, and the validate_license dispatcher."""

from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path

import pytest

from darml_pro import license as lic


def test_encode_then_decode_roundtrip():
    key = lic.encode_key("alice@example.com", "pro", int(time.time() + 3600))
    decoded = lic.decode_and_verify(key)
    assert decoded is not None
    email, plan, expires = decoded
    assert email == "alice@example.com"
    assert plan == "pro"
    assert expires > int(time.time())


def test_decode_rejects_wrong_prefix():
    assert lic.decode_and_verify("not_a_darml_key_at_all") is None


def test_decode_rejects_tampered_signature():
    key = lic.encode_key("alice@example.com", "pro", int(time.time() + 3600))
    # Flip the last hex char of the signature.
    sig_flipped = key[:-1] + ("0" if key[-1] != "0" else "1")
    assert lic.decode_and_verify(sig_flipped) is None


def test_decode_rejects_tampered_payload():
    key = lic.encode_key("alice@example.com", "pro", int(time.time() + 3600))
    # Replace one char in the base64 payload.
    body = key[len(lic.KEY_PREFIX):]
    payload, sig = body.rsplit("_", 1)
    if payload[0] == "X":
        payload = "Y" + payload[1:]
    else:
        payload = "X" + payload[1:]
    tampered = lic.KEY_PREFIX + payload + "_" + sig
    assert lic.decode_and_verify(tampered) is None


def test_validate_license_with_valid_key(monkeypatch):
    key = lic.encode_key("bob@example.com", "pro", int(time.time() + 3600))
    monkeypatch.setenv("DARML_LICENSE_KEY", key)
    s = lic.validate_license()
    assert s.valid and s.plan == "pro" and s.customer == "bob@example.com"


def test_validate_license_with_expired_key(monkeypatch):
    expired = lic.encode_key("bob@example.com", "pro", int(time.time() - 3600))
    monkeypatch.setenv("DARML_LICENSE_KEY", expired)
    s = lic.validate_license()
    assert not s.valid and s.plan == "expired" and s.customer == "bob@example.com"


def test_validate_license_with_invalid_key(monkeypatch):
    monkeypatch.setenv("DARML_LICENSE_KEY", "darml_pro_garbage_xxxxxxxxxxxxxxxx")
    s = lic.validate_license()
    assert not s.valid and s.plan == "invalid"


def test_trial_starts_fresh_when_no_key_and_no_file(monkeypatch, tmp_path):
    monkeypatch.delenv("DARML_LICENSE_KEY", raising=False)
    monkeypatch.setattr(lic, "TRIAL_FILE", tmp_path / "trial")
    s = lic.validate_license()
    assert s.valid and s.plan == "trial"
    assert (tmp_path / "trial").exists()


def test_trial_expired_after_14_days(monkeypatch, tmp_path):
    monkeypatch.delenv("DARML_LICENSE_KEY", raising=False)
    trial_path = tmp_path / "trial"
    trial_path.parent.mkdir(parents=True, exist_ok=True)
    # Started 30 days ago.
    long_ago = datetime.now(timezone.utc).replace(microsecond=0)
    long_ago = datetime.fromtimestamp(long_ago.timestamp() - 30 * 86400, tz=timezone.utc)
    trial_path.write_text(
        json.dumps({"started": long_ago.isoformat(), "machine": "test"})
    )
    monkeypatch.setattr(lic, "TRIAL_FILE", trial_path)
    s = lic.validate_license()
    assert not s.valid and s.plan == "expired"
    assert "trial has ended" in s.message
