import pytest

from darml.domain.enums import ModelFormat
from darml.domain.exceptions import QuantizationFailed
from darml_pro.adapters.quantizers.onnx_quantizer import OnnxQuantizer
from darml_pro.adapters.quantizers.tflite_quantizer import TFLiteQuantizer


def test_onnx_quantizer_has_correct_format():
    assert OnnxQuantizer().format == ModelFormat.ONNX


def test_tflite_quantizer_has_correct_format():
    assert TFLiteQuantizer().format == ModelFormat.TFLITE


def test_tflite_quantizer_raises_clear_error_pointing_to_onnx_path(tmp_path):
    q = TFLiteQuantizer()
    with pytest.raises(QuantizationFailed) as exc:
        q.quantize(tmp_path / "in.tflite", tmp_path / "out.tflite")
    assert "ONNX" in str(exc.value)
