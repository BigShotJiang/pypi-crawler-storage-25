"""API key parsing + per-key daily rate limiting."""

from __future__ import annotations

from darml.domain.api_key import Tier
from darml_pro.adapters.auth.env_api_key_store import EnvAPIKeyStore
from darml_pro.adapters.auth.in_memory_rate_limiter import InMemoryDailyRateLimiter


def test_env_store_parses_keys():
    store = EnvAPIKeyStore("k_free:free:alice,k_pro:pro:acme,k_bad:WUT,k_min:free")
    free = store.find("k_free")
    assert free is not None and free.tier == Tier.FREE and free.label == "alice"
    pro = store.find("k_pro")
    assert pro is not None and pro.tier == Tier.PRO and pro.is_unlimited
    # Unknown tier defaults to FREE.
    bad = store.find("k_bad")
    assert bad is not None and bad.tier == Tier.FREE
    # Two-field entry (no label) still works.
    minimal = store.find("k_min")
    assert minimal is not None and minimal.tier == Tier.FREE


def test_env_store_returns_none_for_unknown():
    assert EnvAPIKeyStore("k_real:pro").find("k_other") is None


def test_env_store_handles_empty_config():
    assert EnvAPIKeyStore("").find("anything") is None
    assert EnvAPIKeyStore(None).find("anything") is None


def test_rate_limiter_pro_is_unlimited():
    limiter = InMemoryDailyRateLimiter()
    pro = EnvAPIKeyStore("k_pro:pro").find("k_pro")
    for _ in range(20):
        allowed, remaining = limiter.consume(pro)
        assert allowed and remaining == -1


def test_rate_limiter_free_caps_at_quota():
    limiter = InMemoryDailyRateLimiter()
    free = EnvAPIKeyStore("k_free:free").find("k_free")
    # Default quota = 5
    for i in range(5):
        allowed, remaining = limiter.consume(free)
        assert allowed
        assert remaining == 5 - (i + 1)
    allowed, remaining = limiter.consume(free)
    assert not allowed and remaining == 0
