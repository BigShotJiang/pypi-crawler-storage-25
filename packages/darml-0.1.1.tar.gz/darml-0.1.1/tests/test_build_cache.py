"""FilesystemBuildCache: key derivation + roundtrip."""

from __future__ import annotations

from pathlib import Path

from darml.domain.enums import BuildStatus, OutputKind, ReportMode
from darml.domain.models import BuildRequest, BuildResult
from darml_pro.adapters.cache.filesystem_cache import FileSystemBuildCache


def _request(model_path: Path, **overrides) -> BuildRequest:
    return BuildRequest(
        model_path=model_path,
        target_id=overrides.get("target_id", "esp32-s3"),
        quantize=overrides.get("quantize", False),
        output_kind=overrides.get("output_kind", OutputKind.FIRMWARE),
        report_mode=overrides.get("report_mode", ReportMode.SERIAL),
    )


def test_cache_key_stable_for_identical_request(tmp_path):
    model = tmp_path / "model.tflite"
    model.write_bytes(b"abc123" * 100)

    cache = FileSystemBuildCache(tmp_path / "cache")
    k1 = cache.key_for(_request(model))
    k2 = cache.key_for(_request(model))
    assert k1 == k2 and len(k1) == 64


def test_cache_key_changes_with_target(tmp_path):
    model = tmp_path / "model.tflite"
    model.write_bytes(b"abc123" * 100)
    cache = FileSystemBuildCache(tmp_path / "cache")
    assert cache.key_for(_request(model, target_id="esp32-s3")) != cache.key_for(
        _request(model, target_id="stm32f4")
    )


def test_cache_key_changes_with_model_bytes(tmp_path):
    cache = FileSystemBuildCache(tmp_path / "cache")
    a = tmp_path / "a.tflite"
    a.write_bytes(b"AAAA" * 50)
    b = tmp_path / "b.tflite"
    b.write_bytes(b"BBBB" * 50)
    assert cache.key_for(_request(a)) != cache.key_for(_request(b))


def test_cache_get_miss_returns_none(tmp_path):
    cache = FileSystemBuildCache(tmp_path / "cache")
    assert cache.get("does-not-exist", tmp_path / "ws", "build-1") is None


def test_cache_put_then_get_roundtrips_artifacts(tmp_path):
    cache = FileSystemBuildCache(tmp_path / "cache")
    workspace_a = tmp_path / "ws_a"
    workspace_a.mkdir()
    fw = workspace_a / "firmware.bin"
    fw.write_bytes(b"\xde\xad\xbe\xef" * 1000)
    artifact = workspace_a / "build.zip"
    artifact.write_bytes(b"PKZIP-fake-bytes")

    result = BuildResult(
        build_id="orig",
        target_id="esp32-s3",
        status=BuildStatus.COMPLETED,
        firmware_path=fw,
        artifact_zip_path=artifact,
        build_log="cc1plus ok",
    )
    cache.put("k1", result)

    workspace_b = tmp_path / "ws_b"
    cached = cache.get("k1", workspace_b, "new-build")
    assert cached is not None
    assert cached.status == BuildStatus.COMPLETED
    assert cached.firmware_path is not None and cached.firmware_path.exists()
    assert cached.firmware_path.read_bytes() == fw.read_bytes()
    assert cached.artifact_zip_path is not None and cached.artifact_zip_path.exists()
    assert any("served from cache" in w for w in cached.warnings)


def test_cache_does_not_store_failed_builds(tmp_path):
    cache = FileSystemBuildCache(tmp_path / "cache")
    failed = BuildResult.new("esp32-s3")
    failed.status = BuildStatus.FAILED
    failed.error = "compile failed"
    cache.put("k_failed", failed)
    # No metadata.json was written → get() returns None
    assert cache.get("k_failed", tmp_path / "ws", "b1") is None
