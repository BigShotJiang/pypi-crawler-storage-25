"""Tests for the new input-validation and quota paths."""

from __future__ import annotations

import pytest

from darml.domain.exceptions import (
    ModelParseError,
    QuantizationFailed,
)
from darml.infrastructure.parsers.sklearn_parser import SklearnParser
from darml.infrastructure.parsers.tflite_parser import TFLiteParser
from darml_pro.adapters.quantizers.tflite_quantizer import TFLiteQuantizer


def test_tflite_parser_rejects_non_flatbuffer(tmp_path):
    junk = tmp_path / "fake.tflite"
    junk.write_bytes(b"\x89PNG\r\n\x1a\nrandom-jpeg-bytes-renamed-to-tflite")
    parser = TFLiteParser()
    with pytest.raises(ModelParseError) as exc:
        parser.parse(junk)
    assert "TFL3" in str(exc.value)


def test_tflite_parser_rejects_short_file(tmp_path):
    short = tmp_path / "tiny.tflite"
    short.write_bytes(b"\x00\x00\x00")
    parser = TFLiteParser()
    with pytest.raises(ModelParseError) as exc:
        parser.parse(short)
    assert "too small" in str(exc.value).lower()


def test_sklearn_parser_rejects_non_pickle(tmp_path):
    junk = tmp_path / "fake.pkl"
    junk.write_bytes(b"#!/usr/bin/env python\nprint('not a pickle')\n")
    parser = SklearnParser()
    with pytest.raises(ModelParseError) as exc:
        parser.parse(junk)
    assert "pickle" in str(exc.value).lower()


def test_tflite_quantizer_error_message_points_to_onnx(tmp_path):
    q = TFLiteQuantizer()
    with pytest.raises(QuantizationFailed) as exc:
        q.quantize(tmp_path / "in.tflite", tmp_path / "out.tflite")
    msg = str(exc.value)
    assert "ONNX" in msg
    assert "quantize=true" in msg.lower() or "quantize=true" in msg
