"""Tests for DARML_MAX_MODEL_SIZE_MB upload cap."""

from __future__ import annotations

import asyncio
import io
from dataclasses import replace

import pytest

from darml.config import Settings
from darml.domain.exceptions import ModelTooLargeUpload
from darml_pro.api.upload import save_capped


class FakeUpload:
    """Minimal stand-in for FastAPI's UploadFile for tests."""

    def __init__(self, payload: bytes, filename: str = "model.tflite"):
        self.filename = filename
        self._stream = io.BytesIO(payload)

    async def read(self, n: int = -1) -> bytes:
        return self._stream.read(n)


def _settings(mb: int) -> Settings:
    return Settings(max_model_size_mb=mb)


def test_save_capped_rejects_oversized_upload(tmp_path):
    settings = _settings(1)  # 1 MB cap
    payload = b"\x00" * (2 * 1024 * 1024)  # 2 MB
    upload = FakeUpload(payload)
    with pytest.raises(ModelTooLargeUpload) as exc:
        asyncio.run(save_capped(upload, tmp_path / "out.bin", settings))
    assert "DARML_MAX_MODEL_SIZE_MB" in str(exc.value)


def test_save_capped_accepts_under_cap(tmp_path):
    settings = _settings(2)
    payload = b"x" * (1024 * 1024)  # 1 MB, under 2 MB cap
    upload = FakeUpload(payload)
    out = asyncio.run(save_capped(upload, tmp_path / "ok.bin", settings))
    assert out.exists() and out.stat().st_size == len(payload)


def test_save_capped_cleans_up_on_rejection(tmp_path):
    settings = _settings(1)
    payload = b"\x00" * (2 * 1024 * 1024)
    upload = FakeUpload(payload)
    out_path = tmp_path / "should_be_gone.bin"
    with pytest.raises(ModelTooLargeUpload):
        asyncio.run(save_capped(upload, out_path, settings))
    assert not out_path.exists(), "rejected upload must not leave a partial file"
