from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Resource:
    """Unified cloud resource representation."""

    id: str
    provider: str
    kind: str
    resource: Optional[str] = None
    name: Optional[str] = None
    region: Optional[str] = None
    zone: Optional[str] = None
    account_id: Optional[str] = None
    resource_group: Optional[str] = None
    network_id: Optional[str] = None
    subnetwork_id: Optional[str] = None
    security_group_ids: List[str] = field(default_factory=list)
    attached_to: Optional[str] = None
    iam_role: Optional[str] = None
    status: Optional[str] = None
    tags: Dict[str, str] = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Return a plain dict for serialization or logging."""
        return {
            "id": self.id,
            "provider": self.provider,
            "kind": self.kind,
            "resource": self.resource,
            "name": self.name,
            "region": self.region,
            "zone": self.zone,
            "account_id": self.account_id,
            "resource_group": self.resource_group,
            "network_id": self.network_id,
            "subnetwork_id": self.subnetwork_id,
            "security_group_ids": self.security_group_ids,
            "attached_to": self.attached_to,
            "iam_role": self.iam_role,
            "status": self.status,
            "tags": self.tags,
            "raw": self.raw,
        }
