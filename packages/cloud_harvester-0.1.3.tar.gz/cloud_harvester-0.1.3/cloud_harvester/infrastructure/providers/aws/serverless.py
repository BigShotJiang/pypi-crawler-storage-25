from __future__ import annotations

from typing import List, Optional

from botocore.exceptions import ClientError

from cloud_harvester.domain.enums import AwsResource, Provider, ResourceKind
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers.aws.auth import get_boto3_session
from cloud_harvester.infrastructure.providers.aws.utils import extract_network_info


def collect_lambda_functions(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect AWS Lambda functions."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("lambda")
    paginator = client.get_paginator("list_functions")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for fn in page.get("Functions", []):
            arn = fn["FunctionArn"]
            tags = _get_lambda_tags(client, arn)
            status = fn.get("State") or fn.get("LastUpdateStatus")
            network_id, subnetwork_id = extract_network_info(fn)
            vpc_config = fn.get("VpcConfig") or {}
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.COMPUTE.value,
                    resource=AwsResource.LAMBDA.value,
                    name=fn.get("FunctionName"),
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    security_group_ids=vpc_config.get("SecurityGroupIds") or [],
                    iam_role=fn.get("Role"),
                    status=status,
                    tags=tags,
                    raw=fn,
                )
            )
    return resources


def collect_sqs_queues(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect SQS queues."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("sqs")
    paginator = client.get_paginator("list_queues")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for url in page.get("QueueUrls", []):
            try:
                attrs = client.get_queue_attributes(
                    QueueUrl=url, AttributeNames=["QueueArn"]
                )["Attributes"]
            except ClientError:
                attrs = {}
            arn = attrs.get("QueueArn", url)
            name = url.split("/")[-1]
            try:
                tags = client.list_queue_tags(QueueUrl=url).get("Tags", {}) or {}
            except ClientError:
                tags = {}
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.COMPUTE.value,
                    resource=AwsResource.SQS.value,
                    name=name,
                    region=client.meta.region_name,
                    network_id=None,
                    subnetwork_id=None,
                    status=None,
                    tags=tags,
                    raw={"url": url, **attrs},
                )
            )
    return resources


def collect_sns_topics(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect SNS topics."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("sns")
    paginator = client.get_paginator("list_topics")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for topic in page.get("Topics", []):
            arn = topic.get("TopicArn")
            name = arn.split(":")[-1] if arn else None
            try:
                attrs = client.get_topic_attributes(TopicArn=arn).get("Attributes", {})
            except ClientError:
                attrs = {}
            try:
                tags = {
                    t["Key"]: t["Value"]
                    for t in client.list_tags_for_resource(ResourceArn=arn).get(
                        "Tags", []
                    )
                    if t.get("Key")
                }
            except ClientError:
                tags = {}
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.COMPUTE.value,
                    resource=AwsResource.SNS.value,
                    name=name,
                    region=client.meta.region_name,
                    network_id=None,
                    subnetwork_id=None,
                    status=None,
                    tags=tags,
                    raw=attrs,
                )
            )
    return resources


def collect_eventbridge_buses(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect EventBridge event buses."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("events")

    resources: List[Resource] = []
    kwargs: dict = {}
    while True:
        response = client.list_event_buses(**kwargs)
        for bus in response.get("EventBuses", []):
            arn = bus.get("Arn")
            try:
                tags = {
                    t["Key"]: t["Value"]
                    for t in client.list_tags_for_resource(ResourceARN=arn).get(
                        "Tags", []
                    )
                    if t.get("Key")
                }
            except ClientError:
                tags = {}
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.COMPUTE.value,
                    resource=AwsResource.EVENTBRIDGE_BUS.value,
                    name=bus.get("Name"),
                    region=client.meta.region_name,
                    network_id=None,
                    subnetwork_id=None,
                    status=None,
                    tags=tags,
                    raw=bus,
                )
            )
        next_token = response.get("NextToken")
        if not next_token:
            break
        kwargs["NextToken"] = next_token
    return resources


def collect_eventbridge_rules(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect EventBridge rules across all event buses."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("events")
    rules_paginator = client.get_paginator("list_rules")

    bus_names: List[str] = []
    kwargs: dict = {}
    while True:
        response = client.list_event_buses(**kwargs)
        for bus in response.get("EventBuses", []):
            if bus.get("Name"):
                bus_names.append(bus["Name"])
        next_token = response.get("NextToken")
        if not next_token:
            break
        kwargs["NextToken"] = next_token

    resources: List[Resource] = []
    for bus_name in bus_names:
        for rules_page in rules_paginator.paginate(EventBusName=bus_name):
            for rule in rules_page.get("Rules", []):
                arn = rule.get("Arn")
                try:
                    tags = {
                        t["Key"]: t["Value"]
                        for t in client.list_tags_for_resource(ResourceARN=arn).get(
                            "Tags", []
                        )
                        if t.get("Key")
                    }
                except ClientError:
                    tags = {}
                resources.append(
                    Resource(
                        id=arn,
                        provider=Provider.AWS.value,
                        kind=ResourceKind.COMPUTE.value,
                        resource=AwsResource.EVENTBRIDGE_RULE.value,
                        name=rule.get("Name"),
                        region=client.meta.region_name,
                        network_id=None,
                        subnetwork_id=None,
                        status=rule.get("State"),
                        tags=tags,
                        raw=rule,
                    )
                )
    return resources


def collect_kinesis_streams(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect Kinesis Data Streams."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("kinesis")
    paginator = client.get_paginator("list_streams")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for stream_name in page.get("StreamNames", []):
            try:
                summary = client.describe_stream_summary(StreamName=stream_name)[
                    "StreamDescriptionSummary"
                ]
                arn = summary.get("StreamARN", stream_name)
            except ClientError:
                summary = {}
                arn = stream_name
            try:
                tags = {
                    t["Key"]: t["Value"]
                    for t in client.list_tags_for_stream(StreamName=stream_name).get(
                        "Tags", []
                    )
                    if t.get("Key")
                }
            except ClientError:
                tags = {}
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.COMPUTE.value,
                    resource=AwsResource.KINESIS.value,
                    name=stream_name,
                    region=client.meta.region_name,
                    network_id=None,
                    subnetwork_id=None,
                    status=summary.get("StreamStatus"),
                    tags=tags,
                    raw=summary,
                )
            )
    return resources


def _get_lambda_tags(client, arn: str) -> dict:
    try:
        response = client.list_tags(Resource=arn)
        return response.get("Tags", {}) or {}
    except ClientError:
        return {}
