from __future__ import annotations

from typing import List, Optional

from botocore.exceptions import ClientError

from cloud_harvester.domain.enums import AwsResource, Provider, ResourceKind
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers.aws.auth import get_boto3_session
from cloud_harvester.infrastructure.providers.aws.utils import extract_network_info


def collect_vpc(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect AWS VPCs and normalize them to the Resource model."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("ec2")
    paginator = client.get_paginator("describe_vpcs")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for vpc in page.get("Vpcs", []):
            tags = (
                {t["Key"]: t["Value"] for t in vpc.get("Tags", [])}
                if vpc.get("Tags")
                else {}
            )
            network_id, subnetwork_id = extract_network_info(vpc)
            resources.append(
                Resource(
                    id=vpc["VpcId"],
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.VPC.value,
                    name=tags.get("Name", vpc.get("VpcId")),
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    status=vpc.get("State"),
                    tags=tags,
                    raw=vpc,
                )
            )
    return resources


def collect_elbv2_load_balancers(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect Application/Network/Gateway Load Balancers."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("elbv2")
    paginator = client.get_paginator("describe_load_balancers")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for lb in page.get("LoadBalancers", []):
            tags = _elbv2_tags(client, lb.get("LoadBalancerArn"))
            lb_state = (lb.get("State") or {}).get("Code")
            network_id, subnetwork_id = extract_network_info(lb)
            resources.append(
                Resource(
                    id=lb.get("LoadBalancerArn", lb.get("DNSName")),
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.ELB.value,
                    name=lb.get("LoadBalancerName"),
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    security_group_ids=lb.get("SecurityGroups") or [],
                    status=lb_state,
                    tags=tags,
                    raw=lb,
                )
            )
    return resources


def collect_classic_elb_load_balancers(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect Classic Load Balancers."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("elb")
    paginator = client.get_paginator("describe_load_balancers")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for lb in page.get("LoadBalancerDescriptions", []):
            name = lb.get("LoadBalancerName")
            tags = _classic_elb_tags(client, name)
            network_id, subnetwork_id = extract_network_info(lb)
            resources.append(
                Resource(
                    id=name,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.CLASSIC_ELB.value,
                    name=name,
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    status=None,
                    tags=tags,
                    raw=lb,
                )
            )
    return resources


def collect_api_gateway_rest_apis(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect API Gateway REST APIs."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("apigateway")
    paginator = client.get_paginator("get_rest_apis")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for api in page.get("items", []):
            arn = f"arn:aws:apigateway:{client.meta.region_name}::/restapis/{api['id']}"
            tags = _api_gateway_tags(client, arn)
            status = "disabled" if api.get("disableExecuteApiEndpoint") else "available"
            network_id, subnetwork_id = extract_network_info(api)
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.API_GATEWAY_REST.value,
                    name=api.get("name"),
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    status=status,
                    tags=tags,
                    raw=api,
                )
            )
    return resources


def collect_api_gateway_http_apis(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect API Gateway HTTP/WebSocket APIs."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("apigatewayv2")
    paginator = client.get_paginator("get_apis")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for api in page.get("Items", []):
            arn = f"arn:aws:apigateway:{client.meta.region_name}::/apis/{api['ApiId']}"
            tags = _api_gateway_v2_tags(client, arn)
            network_id, subnetwork_id = extract_network_info(api)
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.API_GATEWAY_HTTP.value,
                    name=api.get("Name"),
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    status=api.get("ProtocolType"),
                    tags=tags,
                    raw=api,
                )
            )
    return resources


def collect_route53_hosted_zones(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect Route 53 hosted zones."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("route53")
    paginator = client.get_paginator("list_hosted_zones")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for zone in page.get("HostedZones", []):
            zone_id = zone.get("Id", "").split("/")[-1]
            tags = _route53_tags(client, zone_id)
            visibility = (
                "private" if zone.get("Config", {}).get("PrivateZone") else "public"
            )
            network_id, subnetwork_id = extract_network_info(zone)
            resources.append(
                Resource(
                    id=zone.get("Id"),
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.ROUTE53.value,
                    name=zone.get("Name"),
                    region="global",
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    status=visibility,
                    tags=tags,
                    raw=zone,
                )
            )
    return resources


def collect_cloudfront_distributions(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect CloudFront distributions."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("cloudfront")
    paginator = client.get_paginator("list_distributions")

    resources: List[Resource] = []
    for page in paginator.paginate():
        distribution_list = page.get("DistributionList", {})
        for distribution in distribution_list.get("Items", []):
            arn = distribution.get("ARN")
            tags = _cloudfront_tags(client, arn)
            network_id, subnetwork_id = extract_network_info(distribution)
            resources.append(
                Resource(
                    id=arn,
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.CLOUDFRONT.value,
                    name=distribution.get("Id"),
                    region="global",
                    network_id=network_id,
                    subnetwork_id=subnetwork_id,
                    status=distribution.get("Status"),
                    tags=tags,
                    raw=distribution,
                )
            )
    return resources


def _elbv2_tags(client, arn: Optional[str]) -> dict:
    if not arn:
        return {}
    try:
        response = client.describe_tags(ResourceArns=[arn])
        tag_descriptions = response.get("TagDescriptions", [])
        if not tag_descriptions:
            return {}
        tags = tag_descriptions[0].get("Tags", [])
        return {t.get("Key"): t.get("Value") for t in tags if t.get("Key")}
    except ClientError:
        return {}


def _classic_elb_tags(client, name: Optional[str]) -> dict:
    if not name:
        return {}
    try:
        response = client.describe_tags(LoadBalancerNames=[name])
        descriptions = response.get("TagDescriptions", [])
        if not descriptions:
            return {}
        tags = descriptions[0].get("Tags", [])
        return {t.get("Key"): t.get("Value") for t in tags if t.get("Key")}
    except ClientError:
        return {}


def _api_gateway_tags(client, arn: str) -> dict:
    try:
        response = client.get_tags(resourceArn=arn)
        return response.get("tags", {}) or {}
    except ClientError:
        return {}


def _api_gateway_v2_tags(client, arn: str) -> dict:
    try:
        response = client.get_tags(ResourceArn=arn)
        return response.get("Tags", {}) or {}
    except ClientError:
        return {}


def _route53_tags(client, zone_id: str) -> dict:
    if not zone_id:
        return {}
    try:
        response = client.list_tags_for_resource(
            ResourceType="hostedzone", ResourceId=zone_id
        )
        tag_set = response.get("ResourceTagSet", {})
        return {
            t.get("Key"): t.get("Value")
            for t in tag_set.get("Tags", [])
            if t.get("Key")
        }
    except ClientError:
        return {}


def collect_internet_gateways(
    session=None, region: Optional[str] = None
) -> List[Resource]:
    """Collect Internet Gateways."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("ec2")
    paginator = client.get_paginator("describe_internet_gateways")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for igw in page.get("InternetGateways", []):
            tags = (
                {t["Key"]: t["Value"] for t in igw.get("Tags", []) if t.get("Key")}
                if igw.get("Tags")
                else {}
            )
            attachments = igw.get("Attachments", [])
            network_id = attachments[0].get("VpcId") if attachments else None
            status = attachments[0].get("State") if attachments else "detached"
            resources.append(
                Resource(
                    id=igw["InternetGatewayId"],
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.INTERNET_GATEWAY.value,
                    name=tags.get("Name", igw.get("InternetGatewayId")),
                    region=client.meta.region_name,
                    network_id=network_id,
                    subnetwork_id=None,
                    status=status,
                    tags=tags,
                    raw=igw,
                )
            )
    return resources


def collect_route_tables(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect Route Tables."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("ec2")
    paginator = client.get_paginator("describe_route_tables")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for rt in page.get("RouteTables", []):
            tags = (
                {t["Key"]: t["Value"] for t in rt.get("Tags", []) if t.get("Key")}
                if rt.get("Tags")
                else {}
            )
            associations = rt.get("Associations", [])
            subnet_id = next(
                (a.get("SubnetId") for a in associations if a.get("SubnetId")), None
            )
            is_main = any(a.get("Main") for a in associations)
            resources.append(
                Resource(
                    id=rt["RouteTableId"],
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.ROUTE_TABLE.value,
                    name=tags.get("Name", rt.get("RouteTableId")),
                    region=client.meta.region_name,
                    network_id=rt.get("VpcId"),
                    subnetwork_id=subnet_id,
                    status="main" if is_main else "custom",
                    tags=tags,
                    raw=rt,
                )
            )
    return resources


def collect_elastic_ips(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect Elastic IPs."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("ec2")
    response = client.describe_addresses()

    resources: List[Resource] = []
    for eip in response.get("Addresses", []):
        tags = (
            {t["Key"]: t["Value"] for t in eip.get("Tags", []) if t.get("Key")}
            if eip.get("Tags")
            else {}
        )
        resources.append(
            Resource(
                id=eip.get("AllocationId", eip.get("PublicIp")),
                provider=Provider.AWS.value,
                kind=ResourceKind.NETWORK.value,
                resource=AwsResource.ELASTIC_IP.value,
                name=tags.get("Name", eip.get("PublicIp")),
                region=client.meta.region_name,
                network_id=None,
                subnetwork_id=None,
                attached_to=eip.get("InstanceId"),
                status="associated" if eip.get("AssociationId") else "unassociated",
                tags=tags,
                raw=eip,
            )
        )
    return resources


def collect_subnets(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect AWS Subnets."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("ec2")
    paginator = client.get_paginator("describe_subnets")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for subnet in page.get("Subnets", []):
            tags = (
                {t["Key"]: t["Value"] for t in subnet.get("Tags", []) if t.get("Key")}
                if subnet.get("Tags")
                else {}
            )
            resources.append(
                Resource(
                    id=subnet["SubnetId"],
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.SUBNET.value,
                    name=tags.get("Name", subnet.get("SubnetId")),
                    region=client.meta.region_name,
                    zone=subnet.get("AvailabilityZone"),
                    network_id=subnet.get("VpcId"),
                    subnetwork_id=subnet.get("SubnetId"),
                    status=subnet.get("State"),
                    tags=tags,
                    raw=subnet,
                )
            )
    return resources


def collect_nat_gateways(session=None, region: Optional[str] = None) -> List[Resource]:
    """Collect AWS NAT Gateways."""

    boto_session = get_boto3_session(session=session, region=region)
    client = boto_session.client("ec2")
    paginator = client.get_paginator("describe_nat_gateways")

    resources: List[Resource] = []
    for page in paginator.paginate():
        for nat in page.get("NatGateways", []):
            tags = (
                {t["Key"]: t["Value"] for t in nat.get("Tags", []) if t.get("Key")}
                if nat.get("Tags")
                else {}
            )
            resources.append(
                Resource(
                    id=nat["NatGatewayId"],
                    provider=Provider.AWS.value,
                    kind=ResourceKind.NETWORK.value,
                    resource=AwsResource.NAT_GATEWAY.value,
                    name=tags.get("Name", nat.get("NatGatewayId")),
                    region=client.meta.region_name,
                    network_id=nat.get("VpcId"),
                    subnetwork_id=nat.get("SubnetId"),
                    status=nat.get("State"),
                    tags=tags,
                    raw=nat,
                )
            )
    return resources


def _cloudfront_tags(client, arn: Optional[str]) -> dict:
    if not arn:
        return {}
    try:
        response = client.list_tags_for_resource(Resource=arn)
        items = response.get("Tags", {}).get("Items", [])
        return {t.get("Key"): t.get("Value") for t in items if t.get("Key")}
    except ClientError:
        return {}
