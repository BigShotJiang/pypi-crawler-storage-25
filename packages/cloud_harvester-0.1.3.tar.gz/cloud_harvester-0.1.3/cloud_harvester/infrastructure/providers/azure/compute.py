from __future__ import annotations

from typing import List, Optional

from cloud_harvester.domain.enums import AzureResource, Provider, ResourceKind
from cloud_harvester.domain.models import Resource
from cloud_harvester.infrastructure.providers.azure.clients import get_compute_client
from cloud_harvester.infrastructure.providers.azure.resource_graph import (
    collect_from_resource_graph,
)
from cloud_harvester.infrastructure.providers.azure.utils import (
    extract_network_info,
    resource_group_from_id,
)


def collect_vm(
    credential=None,
    subscription_id: Optional[str] = None,
    compute_client=None,
) -> List[Resource]:
    """Collect Azure VMs and map them to the unified Resource model."""

    compute_client = compute_client or get_compute_client(
        credential=credential, subscription_id=subscription_id
    )
    vms = compute_client.virtual_machines.list_all()

    resources: List[Resource] = []
    for vm in vms:
        status = None
        try:
            rg_name = _resource_group_from_id(vm.id)
            instance_view = compute_client.virtual_machines.instance_view(
                rg_name, vm.name
            )
            statuses = instance_view.statuses or []
            status_codes = [s.code for s in statuses if s.code]
            status = next(
                (code.split("/")[-1] for code in status_codes if "PowerState" in code),
                None,
            )
        except Exception:  # pragma: no cover - best effort status
            status = None

        tags = vm.tags or {}
        raw = vm.as_dict() if hasattr(vm, "as_dict") else vm.__dict__
        network_id, subnetwork_id = extract_network_info(raw)
        zones = getattr(vm, "zones", None) or []
        resources.append(
            Resource(
                id=vm.id,
                provider=Provider.AZURE.value,
                kind=ResourceKind.COMPUTE.value,
                resource=AzureResource.VM.value,
                name=vm.name,
                region=vm.location,
                zone=str(zones[0]) if zones else None,
                resource_group=resource_group_from_id(vm.id),
                network_id=network_id,
                subnetwork_id=subnetwork_id,
                status=status,
                tags=tags,
                raw=raw,
            )
        )
    return resources


def collect_functions(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.web/sites"],
        azure_resource=AzureResource.FUNCTIONS,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
        extra_filter="| where tolower(kind) contains 'functionapp'",
    )


def collect_container_instances(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.containerinstance/containergroups"],
        azure_resource=AzureResource.CONTAINER_INSTANCE,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_container_apps(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.app/containerapps"],
        azure_resource=AzureResource.CONTAINER_APP,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_aks_clusters(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.containerservice/managedclusters"],
        azure_resource=AzureResource.AKS,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_vmss(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.compute/virtualmachinescalesets"],
        azure_resource=AzureResource.VMSS,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_app_service_plans(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.web/serverfarms"],
        azure_resource=AzureResource.APP_SERVICE_PLAN,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_managed_identities(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.managedidentity/userassignedidentities"],
        azure_resource=AzureResource.MANAGED_IDENTITY,
        resource_kind=ResourceKind.SECURITY,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_app_services(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.web/sites"],
        azure_resource=AzureResource.APP_SERVICE,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
        extra_filter="| where tolower(kind) !contains 'functionapp'",
    )


def collect_container_registries(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.containerregistry/registries"],
        azure_resource=AzureResource.CONTAINER_REGISTRY,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_logic_apps(
    credential=None, subscription_id: Optional[str] = None
) -> List[Resource]:
    return collect_from_resource_graph(
        resource_types=["microsoft.logic/workflows"],
        azure_resource=AzureResource.LOGIC_APP,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def _resource_group_from_id(resource_id: str) -> str:
    parts = resource_id.split("/")
    for idx, part in enumerate(parts):
        if part.lower() == "resourcegroups" and idx + 1 < len(parts):
            return parts[idx + 1]
    raise ValueError(f"Unable to parse resource group from id: {resource_id}")
