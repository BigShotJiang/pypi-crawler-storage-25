from __future__ import annotations

from typing import List, Optional

from cloud_harvester.domain.enums import AzureResource, ResourceKind
from cloud_harvester.infrastructure.providers.azure.resource_graph import (
    collect_from_resource_graph,
)


def collect_service_bus_namespaces(
    credential=None, subscription_id: Optional[str] = None
) -> List:
    return collect_from_resource_graph(
        resource_types=["microsoft.servicebus/namespaces"],
        azure_resource=AzureResource.SERVICE_BUS,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )


def collect_event_hub_namespaces(
    credential=None, subscription_id: Optional[str] = None
) -> List:
    return collect_from_resource_graph(
        resource_types=["microsoft.eventhub/namespaces"],
        azure_resource=AzureResource.EVENT_HUB,
        resource_kind=ResourceKind.COMPUTE,
        credential=credential,
        subscription_id=subscription_id,
    )
