from .main import EmailManager
