from .main import LicenseManager
