"""Build :class:`~pystator.orchestrator.Orchestrator` for synchronous API requests.

Mirrors worker wiring: load action/guard catalog from app config, bind registries
to a machine built via ``parse_machine`` + ``build_machine``, and use a
request-scoped :class:`~pystator.stores.sqlalchemy_session.SessionStateStore`.

String guard names in YAML that are not in the loaded catalog are registered as
pass-through (always true), matching :func:`build_machine_from_config`.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from pystator._types import TransitionResult
from pystator.actions import ActionRegistry, ExecutionResult, _ActionExecutor
from pystator.api.services.fsm_service import _collect_guard_names
from pystator.errors import ConfigurationError
from pystator.guards import GuardRegistry
from pystator.machine import StateMachine
from pystator.machine_builder import build_machine
from pystator.machine_parser import parse_machine
from pystator.orchestrator import Orchestrator
from pystator.registry import load_registry_from_app_config
from pystator.stores.sqlalchemy_session import SessionStateStore


def database_url_from_session(session: Session) -> str | None:
    """SQLAlchemy engine URL string for registry catalog loading, or None."""
    bind = session.get_bind()
    if bind is None:
        return None
    return bind.url.render_as_string(hide_password=False)


class AccumulatingActionExecutor(_ActionExecutor):
    """Records each :meth:`execute` / :meth:`async_execute` batch for API responses."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.execution_batches: list[ExecutionResult] = []

    def execute(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        er = super().execute(transition_result, context)
        self.execution_batches.append(er)
        return er

    async def async_execute(
        self,
        transition_result: TransitionResult,
        context: dict[str, Any],
    ) -> ExecutionResult:
        er = await super().async_execute(transition_result, context)
        self.execution_batches.append(er)
        return er


def _merge_pass_through_guards(
    machine_config: dict[str, Any], guards: GuardRegistry
) -> None:
    for name in _collect_guard_names(machine_config):
        if not guards.has(name):
            guards.register(name, lambda ctx: True)


def build_state_machine_for_api(
    machine_config: dict[str, Any],
    *,
    guards: GuardRegistry,
    actions: ActionRegistry,
) -> StateMachine:
    """Parse config and bind registries (same fallback path as ``build_machine_from_config``)."""
    _merge_pass_through_guards(machine_config, guards)
    try:
        definition = parse_machine(machine_config, validate=False)
        return build_machine(definition, guards=guards, actions=actions)
    except (ConfigurationError, ValueError):
        machine = StateMachine.from_dict(machine_config)
        machine.bind_guards(guards)
        machine.bind_actions(actions)
        return machine


def build_api_orchestrator(
    session: Session,
    machine_config: dict[str, Any],
) -> tuple[Orchestrator, AccumulatingActionExecutor, SessionStateStore]:
    """Create store, registries, machine, and orchestrator for one API request."""
    actions = ActionRegistry()
    guards = GuardRegistry()
    db_url = database_url_from_session(session)
    load_registry_from_app_config(actions, guards, database_url=db_url, log_name="api")

    machine = build_state_machine_for_api(
        machine_config, guards=guards, actions=actions
    )
    store = SessionStateStore(session)
    executor = AccumulatingActionExecutor(
        actions or machine.action_registry,
        log_execution=True,
    )
    orchestrator = Orchestrator(
        machine=machine,
        state_store=store,
        guards=guards,
        actions=actions,
        executor=executor,
    )
    return orchestrator, executor, store
