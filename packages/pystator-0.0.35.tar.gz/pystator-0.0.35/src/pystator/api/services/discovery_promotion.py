"""Promote an inferred discovery candidate into a persisted FSM machine row."""

from __future__ import annotations

import copy
from typing import Any

from fastapi import HTTPException, status
from sqlalchemy.orm import Session

from pystator.api.models.responses import MachineResponse
from pystator.api.routes.v1.machines import _model_to_response
from pystator.api.services.discovery_service import DiscoveryService
from pystator.api.services.fsm_service import FSMService
from pystator.db.models import MachineModel
from pystator.errors import ConfigurationError
from pystator.machine_parser import parse_machine


def promote_discovery_candidate(
    db: Session,
    discovery: DiscoveryService,
    fsm: FSMService,
    machine_name: str,
    candidate_version: str,
    *,
    target_machine_name: str | None = None,
) -> MachineResponse:
    """Validate candidate config and upsert :class:`MachineModel`.

    Args:
        db: Database session.
        discovery: Discovery service facade.
        fsm: FSM validation service.
        machine_name: Candidate's stored machine_name (URL path).
        candidate_version: Candidate's version string.
        target_machine_name: Optional override for the published
            catalog machine name. When ``None`` the candidate is
            published under its own ``machine_name`` (current behavior).
            When set, the candidate is published under *target_machine_name*
            instead, which may create a new catalog entry or a new
            version of an existing one.

    Returns:
        :class:`MachineResponse` for the upserted catalog row.
    """
    candidate = discovery.get_candidate_version(machine_name, candidate_version)
    if candidate is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No candidate {machine_name!r} version {candidate_version!r}",
        )
    if candidate.machine_name != machine_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Candidate machine_name does not match path",
        )

    effective_name = (target_machine_name or machine_name).strip()
    if not effective_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="target_machine_name must be non-empty when provided",
        )

    config: dict[str, Any] = copy.deepcopy(candidate.config)
    meta = config.setdefault("meta", {})
    meta["machine_name"] = effective_name
    meta["version"] = candidate.version

    valid, errors, _ = fsm.validate(config)
    if not valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "Invalid FSM config from candidate", "errors": errors},
        )

    try:
        definition = parse_machine(config, validate=False)
    except (ConfigurationError, ValueError) as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    existing = (
        db.query(MachineModel)
        .filter(
            MachineModel.name == definition.name,
            MachineModel.version == definition.version,
        )
        .first()
    )
    if existing:
        existing.description = definition.description or None
        existing.strict_mode = str(definition.strict_mode).lower()
        existing.config_json = config
        db.commit()
        db.refresh(existing)
        discovery.update_candidate_status(
            machine_name=machine_name, version=candidate_version, status="promoted"
        )
        return _model_to_response(existing)

    row = MachineModel(
        name=definition.name,
        version=definition.version,
        description=definition.description or None,
        strict_mode=str(definition.strict_mode).lower(),
        config_json=config,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    discovery.update_candidate_status(
        machine_name=machine_name, version=candidate_version, status="promoted"
    )
    return _model_to_response(row)
