"""Shared Pydantic filter model for Discovery Instance endpoints.

Lives in its own module so it can be imported from both ``requests.py``
and ``responses.py`` without creating a circular import.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from pystator.discovery.models import DiscoveryDraftFilter


class DiscoveryDraftFilterModel(BaseModel):
    """API shape of a discovery draft filter.

    Mirrors :class:`pystator.discovery.models.DiscoveryDraftFilter`.
    All fields are optional; ``None`` on a dimension means "do not
    filter". Combined semantics: AND across non-null dimensions,
    OR within each list.
    """

    channels: list[str] | None = Field(
        None,
        description=(
            "Observation channel tags (the ``machine_name`` column on "
            "``discovery_observations``) to include. ``None`` means all."
        ),
    )
    entity_ids: list[str] | None = Field(
        None, description="Entity identifiers to include."
    )
    sources: list[str] | None = Field(
        None, description="``source`` field values to include."
    )
    observed_after: datetime | None = Field(
        None, description="Include events with ``observed_at >= value``."
    )
    observed_before: datetime | None = Field(
        None, description="Include events with ``observed_at <= value``."
    )
    metadata_match: dict[str, Any] | None = Field(
        None,
        description=(
            "Key/value pairs that must all match the observation's metadata exactly."
        ),
    )


def filter_model_to_dataclass(
    model: DiscoveryDraftFilterModel | None,
) -> DiscoveryDraftFilter | None:
    """Convert a wire model into the internal frozen dataclass."""
    if model is None:
        return None
    metadata_match: tuple[tuple[str, Any], ...] | None = None
    if model.metadata_match:
        metadata_match = tuple((str(k), v) for k, v in model.metadata_match.items())
    dc = DiscoveryDraftFilter(
        channels=tuple(model.channels) if model.channels is not None else None,
        entity_ids=tuple(model.entity_ids) if model.entity_ids is not None else None,
        sources=tuple(model.sources) if model.sources is not None else None,
        observed_after=model.observed_after,
        observed_before=model.observed_before,
        metadata_match=metadata_match,
    )
    return None if dc.is_empty() else dc


def filter_dataclass_to_model(
    dc: DiscoveryDraftFilter | None,
) -> DiscoveryDraftFilterModel | None:
    """Convert the internal dataclass into a wire model (or ``None``)."""
    if dc is None or dc.is_empty():
        return None
    metadata_match: dict[str, Any] | None = None
    if dc.metadata_match is not None:
        metadata_match = dict(dc.metadata_match)
    return DiscoveryDraftFilterModel(
        channels=list(dc.channels) if dc.channels is not None else None,
        entity_ids=list(dc.entity_ids) if dc.entity_ids is not None else None,
        sources=list(dc.sources) if dc.sources is not None else None,
        observed_after=dc.observed_after,
        observed_before=dc.observed_before,
        metadata_match=metadata_match,
    )
