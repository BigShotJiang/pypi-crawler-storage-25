"""API v1 routes."""

from __future__ import annotations

from pystator.api.routes.v1 import (
    auth,
    discovery,
    docs,
    entities,
    entities_bulk,
    events,
    machines,
    observability,
    process,
    settings,
    templates,
    workspace_annotations,
    workspace_layouts,
    workspace_transition_annotations,
)

__all__ = [
    "auth",
    "workspace_annotations",
    "workspace_layouts",
    "discovery",
    "docs",
    "entities",
    "entities_bulk",
    "events",
    "machines",
    "observability",
    "process",
    "settings",
    "templates",
]
