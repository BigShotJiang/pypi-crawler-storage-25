"""CRUD API for persisted action/guard registry catalog (metadata + entry points).

Mutations require Admin. List/get are available to any authenticated user.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from pystator.api.dependencies.auth import get_current_user, require_admin
from pystator.api.dependencies.database import get_db_session
from pystator.db.models.registry_catalog import RegistryCatalogModel
from pystator.errors import ConfigurationError
from pystator.registry.resolve import resolve_entry_point
from pystator.registry.types import CatalogEntry, CatalogKind
from pystator.registry.yaml_manifest import (
    catalog_entries_to_yaml_text,
    parse_manifest_yaml_text,
)

router = APIRouter(prefix="/registry/catalog")

Kind = Literal["action", "guard"]


class RegistryCatalogCreateRequest(BaseModel):
    """Create a catalog row."""

    kind: Kind = Field(..., description="action or guard")
    name: str = Field(..., min_length=1, max_length=255)
    entry_point: str = Field(
        ...,
        min_length=1,
        max_length=1024,
        description="module:callable (e.g. mypkg.actions:notify)",
    )
    description: str | None = None
    params_schema: dict[str, Any] | None = None
    enabled: bool = True
    version_label: str | None = Field(None, max_length=64)


class RegistryCatalogUpdateRequest(BaseModel):
    """Patch a catalog row."""

    name: str | None = Field(None, max_length=255)
    entry_point: str | None = Field(None, max_length=1024)
    description: str | None = None
    params_schema: dict[str, Any] | None = None
    enabled: bool | None = None
    version_label: str | None = Field(None, max_length=64)


class RegistryCatalogResponse(BaseModel):
    """One catalog row."""

    id: str
    kind: Kind
    name: str
    entry_point: str
    description: str | None = None
    params_schema: dict[str, Any] | None = None
    enabled: bool
    version_label: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class RegistryCatalogListResponse(BaseModel):
    """List response."""

    items: list[RegistryCatalogResponse]
    total: int


class ResolveEntryPointResponse(BaseModel):
    """Whether an entry point resolves to a callable in this deployment."""

    entry_point: str
    ok: bool
    error: str | None = None


class RegistryCatalogValidateResponse(BaseModel):
    """Result of validating registry YAML."""

    ok: bool
    entry_count: int
    errors: list[str] = Field(default_factory=list)


class RegistryCatalogImportResponse(BaseModel):
    """Result of importing registry YAML into the database."""

    created: int
    updated: int
    errors: list[str] = Field(default_factory=list)


def _row_to_response(row: RegistryCatalogModel) -> RegistryCatalogResponse:
    return RegistryCatalogResponse(
        id=str(row.id),
        kind=row.kind if row.kind in ("action", "guard") else "action",
        name=row.name,
        entry_point=row.entry_point,
        description=row.description,
        params_schema=row.params_schema
        if isinstance(row.params_schema, dict)
        else None,
        enabled=bool(row.enabled),
        version_label=row.version_label,
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def _validate_entry_point(ep: str) -> None:
    try:
        resolve_entry_point(ep)
    except (TypeError, ValueError) as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid entry_point: {e}",
        ) from e


@router.get("/resolve", response_model=ResolveEntryPointResponse)
def resolve_entry_point_probe(
    entry_point: Annotated[str, Query(min_length=1, max_length=1024)],
    _current_user: Annotated[dict, Depends(get_current_user)],
) -> ResolveEntryPointResponse:
    """Check whether ``entry_point`` resolves to a callable in this process."""
    try:
        resolve_entry_point(entry_point)
    except (TypeError, ValueError) as e:
        return ResolveEntryPointResponse(
            entry_point=entry_point, ok=False, error=str(e)
        )
    return ResolveEntryPointResponse(entry_point=entry_point, ok=True, error=None)


def _model_to_catalog_entry(row: RegistryCatalogModel) -> CatalogEntry:
    kind: CatalogKind = row.kind if row.kind in ("action", "guard") else "action"
    return CatalogEntry(
        kind=kind,
        name=row.name,
        entry_point=row.entry_point,
        description=row.description,
        params_schema=row.params_schema
        if isinstance(row.params_schema, dict)
        else None,
        enabled=bool(row.enabled),
        version_label=row.version_label,
        source="database",
    )


@router.post(
    "/validate",
    response_model=RegistryCatalogValidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Validate registry YAML",
)
async def validate_registry_yaml(
    request: Request,
    _current_user: Annotated[dict, Depends(get_current_user)],
) -> RegistryCatalogValidateResponse:
    """Parse registry YAML and verify each ``entry_point`` resolves (no DB writes)."""
    text = (await request.body()).decode("utf-8")
    errors: list[str] = []
    try:
        entries = parse_manifest_yaml_text(text, source="<validate>")
    except ConfigurationError as e:
        return RegistryCatalogValidateResponse(ok=False, entry_count=0, errors=[str(e)])
    for e in entries:
        try:
            resolve_entry_point(e.entry_point)
        except (TypeError, ValueError) as ex:
            errors.append(f"{e.kind} {e.name!r}: {ex}")
    return RegistryCatalogValidateResponse(
        ok=len(errors) == 0,
        entry_count=len(entries),
        errors=errors,
    )


@router.get(
    "/export",
    summary="Export registry catalog as YAML",
    response_class=PlainTextResponse,
)
def export_registry_catalog(
    session: Annotated[Session, Depends(get_db_session)],
    _current_user: Annotated[dict, Depends(get_current_user)],
) -> PlainTextResponse:
    """Return the full database catalog as ``registry.yaml``-compatible YAML."""
    rows = (
        session.query(RegistryCatalogModel)
        .order_by(RegistryCatalogModel.kind, RegistryCatalogModel.name)
        .all()
    )
    entries = [_model_to_catalog_entry(r) for r in rows]
    yaml_text = catalog_entries_to_yaml_text(entries)
    return PlainTextResponse(
        content=yaml_text,
        media_type="application/x-yaml",
        headers={"Content-Disposition": 'attachment; filename="registry.yaml"'},
    )


@router.post(
    "/import",
    response_model=RegistryCatalogImportResponse,
    status_code=status.HTTP_200_OK,
    summary="Import registry YAML into database",
)
async def import_registry_catalog(
    request: Request,
    session: Annotated[Session, Depends(get_db_session)],
    _admin: Annotated[dict, Depends(require_admin)],
    replace: Annotated[
        bool, Query(description="If true, delete all rows then import")
    ] = False,
) -> RegistryCatalogImportResponse:
    """Upsert catalog rows from YAML (same interchange format as export / file manifest)."""
    text = (await request.body()).decode("utf-8")
    errors: list[str] = []
    try:
        entries = parse_manifest_yaml_text(text, source="<import>")
    except ConfigurationError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        ) from e

    for e in entries:
        try:
            resolve_entry_point(e.entry_point)
        except (TypeError, ValueError) as ex:
            errors.append(f"{e.kind} {e.name!r}: {ex}")
    if errors:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "Invalid entry_point(s)", "errors": errors},
        )

    created = 0
    updated = 0
    if replace:
        session.query(RegistryCatalogModel).delete()
        session.commit()

    for e in entries:
        existing = (
            session.query(RegistryCatalogModel)
            .filter(
                RegistryCatalogModel.kind == e.kind,
                RegistryCatalogModel.name == e.name,
            )
            .first()
        )
        if existing is None:
            session.add(
                RegistryCatalogModel(
                    kind=e.kind,
                    name=e.name,
                    entry_point=e.entry_point,
                    description=e.description,
                    params_schema=e.params_schema,
                    enabled=e.enabled,
                    version_label=e.version_label,
                )
            )
            created += 1
        else:
            existing.entry_point = e.entry_point
            existing.description = e.description
            existing.params_schema = e.params_schema
            existing.enabled = e.enabled
            existing.version_label = e.version_label
            existing.updated_at = datetime.now(UTC)
            updated += 1
    session.commit()
    return RegistryCatalogImportResponse(created=created, updated=updated, errors=[])


@router.get("", response_model=RegistryCatalogListResponse)
def list_registry_catalog(
    session: Annotated[Session, Depends(get_db_session)],
    _current_user: Annotated[dict, Depends(get_current_user)],
    kind: Kind | None = None,
) -> RegistryCatalogListResponse:
    """List catalog rows (optional filter by kind)."""
    q = session.query(RegistryCatalogModel).order_by(
        RegistryCatalogModel.kind,
        RegistryCatalogModel.name,
    )
    if kind is not None:
        q = q.filter(RegistryCatalogModel.kind == kind)
    rows = q.all()
    return RegistryCatalogListResponse(
        items=[_row_to_response(r) for r in rows],
        total=len(rows),
    )


@router.post(
    "",
    response_model=RegistryCatalogResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_registry_catalog(
    body: RegistryCatalogCreateRequest,
    session: Annotated[Session, Depends(get_db_session)],
    _admin: Annotated[dict, Depends(require_admin)],
) -> RegistryCatalogResponse:
    """Create a catalog row (Admin)."""
    _validate_entry_point(body.entry_point)
    existing = (
        session.query(RegistryCatalogModel)
        .filter(
            RegistryCatalogModel.kind == body.kind,
            RegistryCatalogModel.name == body.name,
        )
        .first()
    )
    if existing is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Catalog entry already exists for kind={body.kind!r} name={body.name!r}",
        )
    row = RegistryCatalogModel(
        kind=body.kind,
        name=body.name,
        entry_point=body.entry_point,
        description=body.description,
        params_schema=body.params_schema,
        enabled=body.enabled,
        version_label=body.version_label,
    )
    session.add(row)
    session.commit()
    session.refresh(row)
    return _row_to_response(row)


@router.get("/{catalog_id}", response_model=RegistryCatalogResponse)
def get_registry_catalog(
    catalog_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    _current_user: Annotated[dict, Depends(get_current_user)],
) -> RegistryCatalogResponse:
    """Get one catalog row by id."""
    try:
        cid = uuid.UUID(catalog_id)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid catalog id",
        ) from e
    row = (
        session.query(RegistryCatalogModel)
        .filter(RegistryCatalogModel.id == cid)
        .first()
    )
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Catalog entry {catalog_id} not found",
        )
    return _row_to_response(row)


@router.patch("/{catalog_id}", response_model=RegistryCatalogResponse)
def update_registry_catalog(
    catalog_id: str,
    body: RegistryCatalogUpdateRequest,
    session: Annotated[Session, Depends(get_db_session)],
    _admin: Annotated[dict, Depends(require_admin)],
) -> RegistryCatalogResponse:
    """Update a catalog row (Admin)."""
    try:
        cid = uuid.UUID(catalog_id)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid catalog id",
        ) from e
    row = (
        session.query(RegistryCatalogModel)
        .filter(RegistryCatalogModel.id == cid)
        .first()
    )
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Catalog entry {catalog_id} not found",
        )
    if body.name is not None:
        row.name = body.name
    if body.entry_point is not None:
        _validate_entry_point(body.entry_point)
        row.entry_point = body.entry_point
    if body.description is not None:
        row.description = body.description
    # Allow PATCH {"params_schema": null} to clear; omit key to leave unchanged.
    if "params_schema" in body.model_fields_set:
        row.params_schema = body.params_schema
    if body.enabled is not None:
        row.enabled = body.enabled
    if body.version_label is not None:
        row.version_label = body.version_label
    row.updated_at = datetime.now(UTC)
    session.commit()
    session.refresh(row)
    return _row_to_response(row)


@router.delete("/{catalog_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_registry_catalog(
    catalog_id: str,
    session: Annotated[Session, Depends(get_db_session)],
    _admin: Annotated[dict, Depends(require_admin)],
) -> None:
    """Delete a catalog row (Admin)."""
    try:
        cid = uuid.UUID(catalog_id)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid catalog id",
        ) from e
    row = (
        session.query(RegistryCatalogModel)
        .filter(RegistryCatalogModel.id == cid)
        .first()
    )
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Catalog entry {catalog_id} not found",
        )
    session.delete(row)
    session.commit()
