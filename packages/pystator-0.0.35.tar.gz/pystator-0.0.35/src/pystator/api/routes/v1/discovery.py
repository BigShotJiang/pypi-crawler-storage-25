"""Routes for inferred FSM discovery (shadow mode)."""

from __future__ import annotations

from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Body, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session, get_fsm_service
from pystator.api.models.requests import (
    DiscoveryBuildCandidateRequest,
    DiscoveryDraftCreateRequest,
    DiscoveryDraftPatchRequest,
    DiscoveryObserveRequest,
    DiscoveryPreviewRequest,
    DiscoveryPromoteRequest,
    DiscoverySaveCandidateRequest,
)
from pystator.api.models.responses import (
    DiscoveryBuiltCandidateResponse,
    DiscoveryBuiltCandidateSummaryItem,
    DiscoveryDraftResponse,
    DiscoveryEntityDeleteResponse,
    DiscoveryEntityListResponse,
    DiscoveryFleetListResponse,
    DiscoveryFleetMachineItem,
    DiscoveryInstancesListResponse,
    DiscoveryMachineDraftsResponse,
    DiscoveryObserveResponse,
    DiscoveryPreviewResponse,
    DiscoveryShadowDiffResponse,
    MachineResponse,
)
from pystator.api.services.discovery_promotion import promote_discovery_candidate
from pystator.api.services.discovery_service import DiscoveryService
from pystator.api.services.fsm_service import FSMService
from pystator.db.models import MachineModel

router = APIRouter(prefix="/discovery")

_SORT_FIELDS = frozenset(
    {
        "machine_name",
        "last_observation_at",
        "observation_count",
        "candidate_count",
        "drift_rate_recent",
        "shadow_diff_count_recent",
    }
)


@router.get(
    "/machines",
    response_model=DiscoveryFleetListResponse,
    status_code=status.HTTP_200_OK,
    summary="List machines with discovery activity (fleet index)",
    description=(
        "Aggregates per machine from discovery_observations, discovery_edges, "
        "discovery_built_candidates, discovery_drafts, and discovery_shadow_diffs. Shadow metrics use "
        "the latest 200 shadow diffs per machine (recorded_at DESC)."
    ),
)
async def list_discovery_fleet(
    query: str | None = Query(
        default=None,
        description="Case-insensitive substring filter on machine_name",
    ),
    sort: str = Query(
        default="machine_name",
        description=f"Sort field; one of: {', '.join(sorted(_SORT_FIELDS))}",
    ),
    order: str = Query(
        default="asc",
        description="Sort direction: asc or desc",
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryFleetListResponse:
    sort_key = sort if sort in _SORT_FIELDS else "machine_name"
    order_norm = order.strip().lower()
    if order_norm not in ("asc", "desc"):
        order_norm = "asc"
    service = DiscoveryService()
    payload = service.list_fleet_summaries(
        query=query,
        sort=sort_key,
        order=order_norm,
        limit=limit,
        offset=offset,
    )
    return DiscoveryFleetListResponse(
        items=[DiscoveryFleetMachineItem.model_validate(x) for x in payload["items"]],
        total=payload["total"],
        limit=payload["limit"],
        offset=payload["offset"],
    )


@router.get(
    "/instances",
    response_model=DiscoveryInstancesListResponse,
    status_code=status.HTTP_200_OK,
    summary="List Discovery Instances (drafts across all channels)",
    description=(
        "Cross-channel list of all discovery drafts. Each row is a "
        "Discovery Instance: a named, filter-configured consumer of the "
        "shared observation stream. The ``home_channel`` field is the "
        "draft's ``machine_name`` and is used as the default target when "
        "publishing a build."
    ),
)
async def list_discovery_instances(
    query: str | None = Query(
        default=None,
        description="Case-insensitive substring match on title or home_channel",
    ),
    limit: int = Query(default=50, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> DiscoveryInstancesListResponse:
    service = DiscoveryService()
    payload = service.list_all_instances(limit=limit, offset=offset, query=query)
    return DiscoveryInstancesListResponse.model_validate(payload)


@router.post(
    "/observations",
    response_model=DiscoveryObserveResponse,
    status_code=status.HTTP_200_OK,
    summary="Record observed state",
)
async def record_observation(
    request: DiscoveryObserveRequest,
) -> DiscoveryObserveResponse:
    observed_at = None
    if request.observed_at:
        try:
            observed_at = datetime.fromisoformat(request.observed_at)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid observed_at: {request.observed_at}",
            ) from exc
    service = DiscoveryService()
    accepted = service.record_observation(
        machine_name=request.machine_name,
        entity_id=request.entity_id,
        state=request.state,
        observed_at=observed_at,
        source=request.source,
        source_event_id=request.source_event_id,
        ingest_seq=request.ingest_seq,
        metadata=request.metadata,
    )
    return DiscoveryObserveResponse(accepted=accepted)


@router.post(
    "/candidates/build",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Build inferred candidate machine",
)
async def build_candidate(
    request: DiscoveryBuildCandidateRequest,
) -> DiscoveryBuiltCandidateResponse:
    service = DiscoveryService()
    edge_selection = [
        (item.get("source_state", ""), item.get("destination_state", ""))
        for item in request.edge_selection
    ]
    try:
        payload = service.build_candidate(
            request.machine_name,
            version=request.version,
            mode=request.mode,
            entity_ids=request.entity_ids,
            edge_selection=edge_selection,
            min_edge_count=request.min_edge_count,
            min_confidence=request.min_confidence,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.post(
    "/candidates/preview",
    response_model=DiscoveryPreviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Preview inferred edges for discovery scope",
)
async def preview_candidate(
    request: DiscoveryPreviewRequest,
) -> DiscoveryPreviewResponse:
    service = DiscoveryService()
    payload = service.preview_candidate_inputs(
        request.machine_name,
        mode=request.mode,
        entity_ids=request.entity_ids,
        min_edge_count=request.min_edge_count,
        min_confidence=request.min_confidence,
    )
    return DiscoveryPreviewResponse.model_validate(payload)


@router.get(
    "/machines/{machine_name}/entities",
    response_model=DiscoveryEntityListResponse,
    status_code=status.HTTP_200_OK,
    summary="List distinct entity IDs for a discovery machine",
)
async def list_machine_entities(machine_name: str) -> DiscoveryEntityListResponse:
    service = DiscoveryService()
    return DiscoveryEntityListResponse(
        machine_name=machine_name,
        entity_ids=service.list_entity_ids(machine_name),
    )


@router.delete(
    "/machines/{machine_name}/entities/{entity_id}/observations",
    response_model=DiscoveryEntityDeleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Delete all observations for one entity in a discovery machine",
)
async def delete_machine_entity_observations(
    machine_name: str, entity_id: str
) -> DiscoveryEntityDeleteResponse:
    service = DiscoveryService()
    deleted_count = service.delete_entity_observations(machine_name, entity_id)
    return DiscoveryEntityDeleteResponse(
        machine_name=machine_name,
        entity_id=entity_id,
        deleted_count=int(deleted_count),
    )


@router.post(
    "/machines/{machine_name}/drafts",
    response_model=DiscoveryDraftResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create discovery draft (mutable scope before build)",
)
async def create_discovery_draft(
    machine_name: str,
    request: DiscoveryDraftCreateRequest = DiscoveryDraftCreateRequest(),
) -> DiscoveryDraftResponse:
    service = DiscoveryService()
    try:
        payload = service.create_draft(
            machine_name, title=request.title, filter_model=request.filter
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryDraftResponse.model_validate(payload)


@router.patch(
    "/machines/{machine_name}/drafts/{draft_id}",
    response_model=DiscoveryDraftResponse,
    status_code=status.HTTP_200_OK,
    summary="Update discovery draft",
)
async def patch_discovery_draft(
    machine_name: str,
    draft_id: str,
    request: DiscoveryDraftPatchRequest,
) -> DiscoveryDraftResponse:
    service = DiscoveryService()
    patch = request.model_dump(exclude_unset=True)
    try:
        payload = service.patch_draft(machine_name, draft_id, patch)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryDraftResponse.model_validate(payload)


@router.delete(
    "/machines/{machine_name}/drafts/{draft_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete discovery draft",
)
async def delete_discovery_draft(machine_name: str, draft_id: str) -> None:
    service = DiscoveryService()
    if not service.delete_draft(machine_name, draft_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="draft not found",
        )


@router.post(
    "/machines/{machine_name}/drafts/{draft_id}/preview",
    response_model=DiscoveryPreviewResponse,
    status_code=status.HTTP_200_OK,
    summary="Preview inferred edges using draft scope",
)
async def preview_discovery_draft(
    machine_name: str,
    draft_id: str,
) -> DiscoveryPreviewResponse:
    service = DiscoveryService()
    try:
        payload = service.preview_draft(machine_name, draft_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryPreviewResponse.model_validate(payload)


@router.post(
    "/machines/{machine_name}/drafts/{draft_id}/build",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Build candidate from draft scope",
)
async def build_discovery_draft(
    machine_name: str,
    draft_id: str,
) -> DiscoveryBuiltCandidateResponse:
    service = DiscoveryService()
    try:
        payload = service.build_draft(machine_name, draft_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.get(
    "/candidates/{machine_name}/latest",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get latest inferred candidate machine",
)
async def get_latest_candidate(
    machine_name: str,
) -> DiscoveryBuiltCandidateResponse:
    service = DiscoveryService()
    payload = service.get_latest_candidate(machine_name)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No candidate found for machine: {machine_name}",
        )
    if "edges" not in payload:
        payload["edges"] = []
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.get(
    "/candidates/{machine_name}",
    response_model=DiscoveryMachineDraftsResponse,
    status_code=status.HTTP_200_OK,
    summary="List drafts and built candidate versions",
)
async def list_discovery_for_machine(
    machine_name: str, db: Session = Depends(get_db_session)
) -> DiscoveryMachineDraftsResponse:
    service = DiscoveryService()
    rows = service.list_candidate_summaries(machine_name)
    draft_rows = service.list_drafts_dicts(machine_name)
    promoted_versions = {
        str(v)
        for (v,) in db.query(MachineModel.version)
        .filter(MachineModel.name == machine_name)
        .all()
    }
    rows = [r for r in rows if str(r.get("version")) not in promoted_versions]
    return DiscoveryMachineDraftsResponse(
        machine_name=machine_name,
        drafts=[DiscoveryDraftResponse.model_validate(w) for w in draft_rows],
        built_candidates=[
            DiscoveryBuiltCandidateSummaryItem(
                machine_name=r["machine_name"],
                version=r["version"],
                candidate_sequence=int(r.get("candidate_sequence") or 0),
                status=r["status"],
                created_at=r["created_at"],
                metadata=r["metadata"],
                observation_count_at_build=int(
                    r.get("observation_count_at_build") or 0
                ),
                shadow_diff_count_recent=int(r.get("shadow_diff_count_recent") or 0),
                drift_rate_recent=float(r.get("drift_rate_recent") or 0.0),
                build_mode=(
                    str(r.get("build_mode"))
                    if r.get("build_mode") is not None
                    else None
                ),
            )
            for r in rows
        ],
    )


@router.get(
    "/candidates/{machine_name}/{candidate_version}",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get inferred candidate by version",
)
async def get_candidate_by_version(
    machine_name: str, candidate_version: str
) -> DiscoveryBuiltCandidateResponse:
    service = DiscoveryService()
    payload = service.get_candidate_detail(machine_name, candidate_version)
    if payload is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(f"No candidate {machine_name!r} version {candidate_version!r}"),
        )
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.post(
    "/candidates/{machine_name}/{candidate_version}/promote",
    response_model=MachineResponse,
    status_code=status.HTTP_200_OK,
    summary="Promote candidate to stored FSM machine",
    description=(
        "Validate candidate config and upsert a row in the machines table "
        "for the same name and version as in the candidate meta."
    ),
)
async def promote_candidate(
    machine_name: str,
    candidate_version: str,
    request: DiscoveryPromoteRequest | None = Body(default=None),
    db: Session = Depends(get_db_session),
    fsm: Annotated[FSMService, Depends(get_fsm_service)] = None,
) -> MachineResponse:
    svc = fsm if fsm is not None else FSMService()
    discovery = DiscoveryService()
    target = request.target_machine_name if request is not None else None
    return promote_discovery_candidate(
        db,
        discovery,
        svc,
        machine_name,
        candidate_version,
        target_machine_name=target,
    )


@router.post(
    "/candidates/save",
    response_model=DiscoveryBuiltCandidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Save edited candidate configuration",
)
async def save_candidate(
    request: DiscoverySaveCandidateRequest,
    fsm: Annotated[FSMService, Depends(get_fsm_service)] = None,
) -> DiscoveryBuiltCandidateResponse:
    svc = fsm if fsm is not None else FSMService()
    valid, errors, _ = svc.validate(request.config)
    if not valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": "Invalid FSM config", "errors": errors},
        )
    discovery = DiscoveryService()
    payload = discovery.save_candidate_config(
        source_machine_name=request.source_machine_name,
        target_machine_name=request.target_machine_name,
        target_version=request.target_version,
        config=request.config,
        metadata=request.metadata,
    )
    return DiscoveryBuiltCandidateResponse.model_validate(payload)


@router.get(
    "/shadow/{machine_name}",
    response_model=list[DiscoveryShadowDiffResponse],
    status_code=status.HTTP_200_OK,
    summary="List shadow-mode diffs",
)
async def list_shadow_diffs(
    machine_name: str,
    limit: int = Query(default=100, ge=1, le=500),
) -> list[DiscoveryShadowDiffResponse]:
    service = DiscoveryService()
    rows = service.list_shadow_diffs(machine_name, limit=limit)
    return [DiscoveryShadowDiffResponse.model_validate(item) for item in rows]
