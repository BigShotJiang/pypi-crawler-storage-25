"""Route handlers for FSM config validation, CRUD, and info."""

from __future__ import annotations

import logging
import uuid
from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    Request,
    status,
)
from sqlalchemy.orm import Session

from pystator.api.dependencies import get_db_session, get_fsm_service
from pystator.api.models.requests import (
    MachineCreateRequest,
    MachineUpdateRequest,
    ValidateRequest,
)
from pystator.api.models.responses import (
    MachineInfo,
    MachineListItem,
    MachineListResponse,
    MachineResponse,
    ValidateResponse,
)
from pystator.api.services.fsm_service import FSMService
from pystator.db.models import (
    EntityStateModel,
    MachineModel,
    WorkspaceAnnotationModel,
    WorkspaceLayoutModel,
    WorkspaceTransitionAnnotationModel,
)
from pystator.errors import ConfigurationError
from pystator.events import ChangeBus, ChangeEvent
from pystator.machine_parser import MachineDefinition, parse_machine

logger = logging.getLogger(__name__)


def _migrate_workspace_data(
    db: Session,
    machine_name: str,
    old_version: str,
    new_version: str,
) -> None:
    """Copy notes and layouts from old version to new version.

    Called when a machine's version changes so that workspace
    data (annotations, transition annotations, layouts) is
    carried forward automatically.

    Args:
        db: Database session.
        machine_name: The machine name.
        old_version: Version being replaced.
        new_version: New version to copy data into.
    """
    if old_version == new_version:
        return

    # Copy state annotations
    old_annotations = (
        db.query(WorkspaceAnnotationModel)
        .filter(
            WorkspaceAnnotationModel.machine_name == machine_name,
            WorkspaceAnnotationModel.machine_version == old_version,
        )
        .all()
    )
    for ann in old_annotations:
        existing = (
            db.query(WorkspaceAnnotationModel)
            .filter(
                WorkspaceAnnotationModel.machine_name == machine_name,
                WorkspaceAnnotationModel.machine_version == new_version,
                WorkspaceAnnotationModel.state_name == ann.state_name,
            )
            .first()
        )
        if not existing:
            db.add(
                WorkspaceAnnotationModel(
                    machine_name=machine_name,
                    machine_version=new_version,
                    state_name=ann.state_name,
                    body_markdown=ann.body_markdown,
                )
            )

    # Copy transition annotations
    old_trans = (
        db.query(WorkspaceTransitionAnnotationModel)
        .filter(
            WorkspaceTransitionAnnotationModel.machine_name == machine_name,
            WorkspaceTransitionAnnotationModel.machine_version == old_version,
        )
        .all()
    )
    for ta in old_trans:
        existing = (
            db.query(WorkspaceTransitionAnnotationModel)
            .filter(
                WorkspaceTransitionAnnotationModel.machine_name == machine_name,
                WorkspaceTransitionAnnotationModel.machine_version == new_version,
                WorkspaceTransitionAnnotationModel.transition_key == ta.transition_key,
            )
            .first()
        )
        if not existing:
            db.add(
                WorkspaceTransitionAnnotationModel(
                    machine_name=machine_name,
                    machine_version=new_version,
                    transition_key=ta.transition_key,
                    body_markdown=ta.body_markdown,
                )
            )

    # Copy layouts
    old_layouts = (
        db.query(WorkspaceLayoutModel)
        .filter(
            WorkspaceLayoutModel.machine_name == machine_name,
            WorkspaceLayoutModel.machine_version == old_version,
        )
        .all()
    )
    for layout in old_layouts:
        existing = (
            db.query(WorkspaceLayoutModel)
            .filter(
                WorkspaceLayoutModel.machine_name == machine_name,
                WorkspaceLayoutModel.machine_version == new_version,
                WorkspaceLayoutModel.state_name == layout.state_name,
            )
            .first()
        )
        if not existing:
            db.add(
                WorkspaceLayoutModel(
                    machine_name=machine_name,
                    machine_version=new_version,
                    state_name=layout.state_name,
                    position_x=layout.position_x,
                    position_y=layout.position_y,
                )
            )


router = APIRouter()


def _parse_and_validate(config: dict) -> MachineDefinition:
    """Parse + validate config via machine_parser (single canonical path).

    Raises:
        HTTPException 400: If config is structurally invalid.
        HTTPException 422: If meta fields (machine_name) fail validation.
    """
    try:
        return parse_machine(config, validate=True)
    except ConfigurationError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "message": "Invalid FSM config",
                "errors": exc.context.get("errors", [str(exc)])
                if exc.context
                else [str(exc)],
            },
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc


def _model_to_response(m: MachineModel) -> MachineResponse:
    """Build MachineResponse from MachineModel."""
    strict = m.strict_mode
    if isinstance(strict, str):
        strict = strict.lower() in ("true", "1", "yes")
    return MachineResponse(
        id=str(m.id),
        name=m.name,
        version=m.version,
        description=m.description,
        strict_mode=bool(strict),
        config=m.config_json,
        revision=m.revision or 1,
        created_at=m.created_at,
        updated_at=m.updated_at,
    )


def _get_change_bus(request) -> ChangeBus | None:
    """Retrieve ChangeBus from app state, if available."""
    return getattr(request.app.state, "change_bus", None)


@router.post(
    "/machines/validate",
    response_model=ValidateResponse,
    status_code=status.HTTP_200_OK,
    summary="Validate FSM config",
    description="Validate FSM configuration. Returns errors or machine info.",
    responses={
        200: {"description": "Validation result"},
        422: {"description": "Request validation error"},
    },
)
async def validate_config(
    request: ValidateRequest,
    service: Annotated[FSMService, Depends(get_fsm_service)],
) -> ValidateResponse:
    """Validate FSM configuration via machine_parser + FSMService.

    If valid, returns machine_name, version, state_names, trigger_names, terminal_states.
    If invalid, returns list of error messages.
    """
    valid, errors, info = service.validate(request.config)
    if valid and info:
        return ValidateResponse(
            valid=True,
            errors=[],
            info=MachineInfo(**info),
        )
    return ValidateResponse(valid=False, errors=errors, info=None)


@router.get(
    "/machines",
    response_model=MachineListResponse,
    status_code=status.HTTP_200_OK,
    summary="List FSM machines",
    description="List all FSM machines stored in the database",
)
async def list_machines(
    db: Session = Depends(get_db_session),
    name: str | None = Query(default=None, description="Filter by machine name"),
    version: str | None = Query(default=None, description="Filter by version"),
) -> MachineListResponse:
    """List machines from the database, optionally filtered by name and version."""
    query = db.query(MachineModel)
    if name:
        query = query.filter(MachineModel.name == name)
    if version:
        query = query.filter(MachineModel.version == version)
    rows = query.order_by(MachineModel.name, MachineModel.version).all()
    items = [
        MachineListItem(
            id=str(r.id),
            name=r.name,
            version=r.version,
            namespace=(r.config_json or {}).get("meta", {}).get("namespace"),
            description=r.description,
            created_at=r.created_at,
            updated_at=r.updated_at,
        )
        for r in rows
    ]
    return MachineListResponse(machines=items, count=len(items))


@router.get(
    "/machines/{machine_id}",
    response_model=MachineResponse,
    status_code=status.HTTP_200_OK,
    summary="Get FSM machine",
    description="Get a single FSM machine by ID (returns full config).",
)
async def get_machine(
    machine_id: str,
    db: Session = Depends(get_db_session),
) -> MachineResponse:
    """Get machine by ID."""
    try:
        uid = uuid.UUID(machine_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid machine ID: {machine_id}",
        )
    row = db.query(MachineModel).filter(MachineModel.id == uid).first()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Machine not found: {machine_id}",
        )
    return _model_to_response(row)


@router.post(
    "/machines",
    response_model=MachineResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create FSM machine",
    description="Validate and store an FSM machine in the database.",
)
async def create_machine(
    http_request: Request,
    request: MachineCreateRequest,
    db: Session = Depends(get_db_session),
    service: Annotated[FSMService, Depends(get_fsm_service)] = None,
) -> MachineResponse:
    """Parse config via machine_parser and save to database."""
    definition = _parse_and_validate(request.config)

    existing = (
        db.query(MachineModel)
        .filter(
            MachineModel.name == definition.name,
            MachineModel.version == definition.version,
        )
        .first()
    )
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Machine '{definition.name}' version "
                f"'{definition.version}' already exists"
            ),
        )
    # Find the latest existing version to carry forward workspace data
    latest_existing = (
        db.query(MachineModel)
        .filter(MachineModel.name == definition.name)
        .order_by(MachineModel.version.desc())
        .first()
    )

    row = MachineModel(
        name=definition.name,
        version=definition.version,
        description=definition.description or None,
        strict_mode=str(definition.strict_mode).lower(),
        config_json=definition.config,
        revision=1,
    )
    db.add(row)

    # Carry forward notes and layouts from previous version
    if latest_existing:
        _migrate_workspace_data(
            db,
            definition.name,
            latest_existing.version,
            definition.version,
        )

    db.commit()
    db.refresh(row)

    bus = _get_change_bus(http_request)
    if bus:
        bus.publish(
            ChangeEvent(
                topic="machine",
                action="created",
                resource_id=str(row.id),
                revision=row.revision or 1,
            )
        )
    return _model_to_response(row)


@router.put(
    "/machines/{machine_id}",
    response_model=MachineResponse,
    status_code=status.HTTP_200_OK,
    summary="Update FSM machine",
    description="Validate and update an FSM machine in the database.",
)
async def update_machine(
    http_request: Request,
    machine_id: str,
    request: MachineUpdateRequest,
    db: Session = Depends(get_db_session),
    service: Annotated[FSMService, Depends(get_fsm_service)] = None,
) -> MachineResponse:
    """Parse config and update machine in database."""
    definition = _parse_and_validate(request.config)

    try:
        uid = uuid.UUID(machine_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid machine ID: {machine_id}",
        )
    row = db.query(MachineModel).filter(MachineModel.id == uid).first()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Machine not found: {machine_id}",
        )

    # Optimistic concurrency check
    if (
        request.expected_revision is not None
        and (row.revision or 1) != request.expected_revision
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Revision mismatch: expected "
                f"{request.expected_revision}, "
                f"current is {row.revision or 1}"
            ),
        )

    # Check for name+version conflict with *other* machines
    conflict = (
        db.query(MachineModel)
        .filter(
            MachineModel.name == definition.name,
            MachineModel.version == definition.version,
            MachineModel.id != uid,
        )
        .first()
    )
    if conflict:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Machine '{definition.name}' version "
                f"'{definition.version}' already exists "
                "as a different machine"
            ),
        )

    old_version = row.version
    row.name = definition.name
    row.version = definition.version
    row.description = definition.description or None
    row.strict_mode = str(definition.strict_mode).lower()
    row.config_json = definition.config
    row.revision = (row.revision or 1) + 1

    # Carry forward notes and layouts when version changes
    if old_version != definition.version:
        _migrate_workspace_data(
            db,
            definition.name,
            old_version,
            definition.version,
        )

    db.commit()
    db.refresh(row)

    bus = _get_change_bus(http_request)
    if bus:
        bus.publish(
            ChangeEvent(
                topic="machine",
                action="updated",
                resource_id=str(row.id),
                revision=row.revision or 1,
            )
        )
    return _model_to_response(row)


@router.delete(
    "/machines/{machine_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete FSM machine",
    description="Delete an FSM machine from the database.",
)
async def delete_machine(
    http_request: Request,
    machine_id: str,
    db: Session = Depends(get_db_session),
) -> None:
    """Delete machine by ID."""
    try:
        uid = uuid.UUID(machine_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid machine ID: {machine_id}",
        )
    row = db.query(MachineModel).filter(MachineModel.id == uid).first()
    if not row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Machine not found: {machine_id}",
        )
    resource_id = str(row.id)
    db.delete(row)
    db.commit()

    bus = _get_change_bus(http_request)
    if bus:
        bus.publish(
            ChangeEvent(
                topic="machine",
                action="deleted",
                resource_id=resource_id,
            )
        )


@router.post(
    "/machines/{machine_id}/compatibility",
    summary="Check entity compatibility with a machine version",
    description="Check if entities using this machine can safely migrate to a target version.",
    responses={
        200: {"description": "Compatibility check results"},
        404: {"description": "Machine not found"},
    },
)
async def check_machine_compatibility(
    machine_id: str,
    target_version: str = Query(..., description="Target version to check against"),
    db: Session = Depends(get_db_session),
) -> dict:
    """Check if entities can migrate to a different machine version."""
    try:
        uid = uuid.UUID(machine_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid machine ID: {machine_id}",
        )

    # Load source machine
    source_row = db.query(MachineModel).filter(MachineModel.id == uid).first()
    if not source_row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Machine not found: {machine_id}",
        )

    # Load target machine by name + version
    target_row = (
        db.query(MachineModel)
        .filter(
            MachineModel.name == source_row.name,
            MachineModel.version == target_version,
        )
        .first()
    )
    if not target_row:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Machine '{source_row.name}' version '{target_version}' not found"
            ),
        )

    # Parse target machine to get its state set
    target_def = _parse_and_validate(target_row.config_json)
    target_states = {s["name"] for s in target_def.states}

    # Find entities using this machine and check compatibility
    entities = (
        db.query(EntityStateModel)
        .filter(
            EntityStateModel.machine_name == source_row.name,
            EntityStateModel.status == "active",
        )
        .limit(500)
        .all()
    )

    issues: list[dict] = []
    for ent in entities:
        if ent.current_state not in target_states:
            issues.append(
                {
                    "entity_id": ent.entity_id,
                    "current_state": ent.current_state,
                    "issue": (
                        f"State '{ent.current_state}' does not exist in "
                        f"target version '{target_version}'"
                    ),
                }
            )

    return {
        "compatible": len(issues) == 0,
        "source_version": source_row.version,
        "target_version": target_version,
        "entities_checked": len(entities),
        "issues": issues,
    }
