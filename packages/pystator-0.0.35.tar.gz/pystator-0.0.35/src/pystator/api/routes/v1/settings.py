"""
Route handlers for settings and configuration testing.

Mirrors PyCharter's api/routes/v1/settings.py: database config, test-database, and DLQ
(test-dlq, dlq-stats, worker-dlq-config).
"""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from pystator import __version__ as pystator_version
from pystator.api.dependencies.auth import require_admin
from pystator.api.dependencies.database import get_db_session
from pystator.api.models.requests import (
    DatabaseTestRequest,
    DiscoveryDatabaseTestRequest,
    DlqStatsRequest,
    DlqTestRequest,
    ServerConfigPatchRequest,
)
from pystator.api.models.responses import (
    DatabaseConfigResponse,
    DatabaseTestResponse,
    DiscoveryConfigResponse,
    DiscoveryDatabaseTestResponse,
    DlqStatsResponse,
    DlqTestResponse,
    WorkerDlqConfigResponse,
)
from pystator.api.services.dlq_testing import get_dlq_stats, verify_dlq_connection
from pystator.api.services.server_config_editor import (
    apply_server_config_patch,
    get_server_config_bundle,
)
from pystator.config import (
    get_allow_inline_code_actions,
    get_allow_inline_code_actions_source,
    get_allow_inline_code_imports,
    get_allow_inline_code_imports_source,
    get_api_url,
    get_database_url,
    get_discovery_backend,
    get_discovery_database_url,
    get_discovery_drift_alert_threshold,
    get_discovery_drift_min_sample,
    get_discovery_drift_severe_threshold,
    get_discovery_low_sample_threshold,
    get_discovery_min_confidence,
    get_discovery_min_edge_count,
    get_ui_app_name,
    get_ui_theme,
    is_discovery_shadow_enabled,
)
from pystator.config.auth import get_auth_service_url, is_auth_disabled
from pystator.db.models import MachineModel
from pystator.discovery.stores import create_discovery_store
from pystator.worker.config import WorkerConfig

# Public router: no auth (so UI can load theme before login)
public_router = APIRouter()


@public_router.get(
    "/settings/app-config",
    status_code=status.HTTP_200_OK,
    summary="Get app config (theme, app name, version) for UI",
    description="Returns UI theme (light, dark, system), app name, and release version. No auth required.",
)
async def get_app_config() -> dict[str, str | bool]:
    return {
        "theme": get_ui_theme(),
        "app_name": get_ui_app_name(),
        "version": pystator_version or "",
        "allow_inline_code_actions": get_allow_inline_code_actions(),
        "allow_inline_code_actions_source": get_allow_inline_code_actions_source(),
        "allow_inline_code_imports": get_allow_inline_code_imports(),
        "allow_inline_code_imports_source": get_allow_inline_code_imports_source(),
    }


def _database_driver_kind(url: str | None) -> str:
    if not url or not url.strip():
        return "sqlite_default"
    u = url.strip().lower()
    if u.startswith("sqlite"):
        return "sqlite"
    if u.startswith(("postgresql", "postgres")):
        return "postgresql"
    if u.startswith("mysql"):
        return "mysql"
    return "other"


def _auth_mode_summary() -> str:
    if is_auth_disabled():
        return "open_no_login"
    if get_auth_service_url():
        return "external_oidc"
    return "builtin_jwt"


@public_router.get(
    "/settings/runtime-overview",
    status_code=status.HTTP_200_OK,
    summary="Server runtime configuration (masked, no secrets)",
    description=(
        "Effective values from environment and pystator.cfg for operators. "
        "No authentication required. URLs are masked; hierarchy is env overrides file."
    ),
)
async def get_runtime_overview() -> dict[str, Any]:
    raw_db = get_database_url()
    raw_disc = get_discovery_database_url()
    wc = WorkerConfig()
    worker_dlq = _worker_dlq_runtime_fields(wc)
    disc_display = _mask_database_url(raw_disc)
    db_display = _mask_database_url(raw_db)
    return {
        "version": pystator_version or "",
        "app_name": get_ui_app_name(),
        "ui_theme": get_ui_theme(),
        "api_url": get_api_url(),
        "auth_disabled": is_auth_disabled(),
        "auth_mode": _auth_mode_summary(),
        "allow_inline_code_actions": get_allow_inline_code_actions(),
        "allow_inline_code_actions_source": get_allow_inline_code_actions_source(),
        "allow_inline_code_imports": get_allow_inline_code_imports(),
        "allow_inline_code_imports_source": get_allow_inline_code_imports_source(),
        "database": {
            "configured_url_masked": db_display,
            "driver_kind": _database_driver_kind(raw_db),
        },
        "discovery": {
            "backend": get_discovery_backend(),
            "database_url_masked": disc_display,
            "shadow_enabled": is_discovery_shadow_enabled(),
            "min_edge_count": get_discovery_min_edge_count(),
            "min_confidence": get_discovery_min_confidence(),
            "drift_alert_threshold": get_discovery_drift_alert_threshold(),
            "drift_severe_threshold": get_discovery_drift_severe_threshold(),
            "drift_min_sample": get_discovery_drift_min_sample(),
            "low_sample_threshold": get_discovery_low_sample_threshold(),
        },
        "worker": {
            "poll_interval_ms": wc.poll_interval_ms,
            "concurrency": wc.concurrency,
            "machine_source": wc.machine_source,
            **worker_dlq,
        },
    }


router = APIRouter()


@router.get(
    "/settings/server-config",
    status_code=status.HTTP_200_OK,
    summary="Server config table (admin): edit metadata and file values",
    description=(
        "Returns rows for the settings UI: effective values, cfg file column, env lock flags. "
        "Requires Admin (or auth disabled). Contains raw URLs/passwords from pystator.cfg when set."
    ),
)
async def get_server_config(
    _admin: Annotated[dict, Depends(require_admin)],
) -> dict[str, Any]:
    return get_server_config_bundle()


@router.patch(
    "/settings/server-config",
    status_code=status.HTTP_200_OK,
    summary="Update pystator.cfg (admin)",
    description=(
        "Writes allowed PYSTATOR_* keys into pystator.cfg. Environment variables still override "
        "at runtime; restart may be required for some options. Requires Admin."
    ),
)
async def patch_server_config(
    body: ServerConfigPatchRequest,
    _admin: Annotated[dict, Depends(require_admin)],
) -> dict[str, Any]:
    try:
        path, keys = apply_server_config_patch(body.values)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    return {
        "written_path": str(path),
        "keys_written": keys,
        "detail": f"Updated {len(keys)} key(s) in {path}",
    }


def _build_connection_string(
    connection_string: str | None = None,
    host: str | None = None,
    port: int | None = None,
    database: str | None = None,
    username: str | None = None,
    password: str | None = None,
) -> str:
    """Build database connection string from components."""
    if connection_string:
        return connection_string
    if not all([host, database]):
        raise ValueError(
            "Either connection_string or (host and database) must be provided"
        )
    if port is None:
        port = 5432
    if username and password:
        return f"postgresql://{username}:{password}@{host}:{port}/{database}"
    if username:
        return f"postgresql://{username}@{host}:{port}/{database}"
    return f"postgresql://{host}:{port}/{database}"


@router.get(
    "/settings/database-config",
    response_model=DatabaseConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get current database configuration",
    description="Get information about the currently configured database connection",
)
async def get_database_config(
    db: Session = Depends(get_db_session),
) -> DatabaseConfigResponse:
    """
    Get current database configuration and connection info.
    Shows which database is actually being used (SQLite vs PostgreSQL).
    """
    configured_url = get_database_url()
    actual_url = (
        str(db.get_bind().url)
        if hasattr(db, "get_bind") and db.get_bind()
        else "unknown"
    )
    if actual_url.startswith("sqlite"):
        database_type = "SQLite"
        is_default = configured_url is None
    elif actual_url.startswith(("postgresql", "postgres")):
        database_type = "PostgreSQL"
        is_default = False
    else:
        database_type = "Unknown"
        is_default = False
    try:
        machine_count = db.query(MachineModel).count()
    except Exception:
        machine_count = -1
    if is_default:
        message = (
            "No database URL configured. Using default SQLite. "
            "To use PostgreSQL, set PYSTATOR_DATABASE_URL."
        )
        display_url = None
    else:
        display_url = configured_url
        if configured_url and "@" in configured_url:
            parts = configured_url.split("@", 1)
            if ":" in parts[0] and "://" in parts[0]:
                user_pass = parts[0].split("://", 1)[1]
                if ":" in user_pass:
                    user, _ = user_pass.split(":", 1)
                    display_url = (
                        parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
                    )
        message = f"Using {database_type} database"
    return DatabaseConfigResponse(
        configured_url=display_url,
        actual_url=actual_url.split("@")[-1] if "@" in actual_url else actual_url,
        database_type=database_type,
        is_default=is_default,
        machine_count=machine_count,
        message=message,
    )


@router.post(
    "/settings/test-database",
    response_model=DatabaseTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test database connection",
    description="Test a database connection using provided credentials",
)
async def test_database(request: DatabaseTestRequest) -> DatabaseTestResponse:
    """Test database connection."""
    try:
        connection_string = _build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
        engine = create_engine(connection_string, pool_pre_ping=True)
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return DatabaseTestResponse(
            success=True, message="Database connection successful"
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except SQLAlchemyError as e:
        return DatabaseTestResponse(
            success=False, message=f"Database connection failed: {str(e)}"
        )
    except Exception as e:
        return DatabaseTestResponse(
            success=False, message=f"Unexpected error: {str(e)}"
        )


@router.get(
    "/settings/discovery-config",
    response_model=DiscoveryConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get discovery configuration",
)
async def get_discovery_config() -> DiscoveryConfigResponse:
    raw_url = get_discovery_database_url()
    display_url = raw_url
    if raw_url and "@" in raw_url:
        parts = raw_url.split("@", 1)
        if ":" in parts[0] and "://" in parts[0]:
            user_pass = parts[0].split("://", 1)[1]
            if ":" in user_pass:
                user, _ = user_pass.split(":", 1)
                display_url = (
                    parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
                )
    return DiscoveryConfigResponse(
        backend=get_discovery_backend(),
        database_url=display_url,
        shadow_enabled=is_discovery_shadow_enabled(),
        min_edge_count=get_discovery_min_edge_count(),
        min_confidence=get_discovery_min_confidence(),
        drift_alert_threshold=get_discovery_drift_alert_threshold(),
        drift_severe_threshold=get_discovery_drift_severe_threshold(),
        drift_min_sample=get_discovery_drift_min_sample(),
        low_sample_threshold=get_discovery_low_sample_threshold(),
    )


@router.post(
    "/settings/test-discovery-database",
    response_model=DiscoveryDatabaseTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test discovery backend connection",
)
async def test_discovery_database(
    request: DiscoveryDatabaseTestRequest,
) -> DiscoveryDatabaseTestResponse:
    try:
        store = create_discovery_store(
            request.backend,
            connection_string=request.connection_string,
            options={"database_name": "pystator"},
        )
        connect = getattr(store, "connect", None)
        disconnect = getattr(store, "disconnect", None)
        if callable(connect):
            connect()
        if callable(disconnect):
            disconnect()
        return DiscoveryDatabaseTestResponse(
            success=True, message="Discovery backend connection successful"
        )
    except Exception as e:
        return DiscoveryDatabaseTestResponse(
            success=False, message=f"Discovery backend connection failed: {str(e)}"
        )


def _mask_database_url(url: str | None) -> str | None:
    if not url or "@" not in url:
        return url
    parts = url.split("@", 1)
    if ":" in parts[0] and "://" in parts[0]:
        user_pass = parts[0].split("://", 1)[1]
        if ":" in user_pass:
            user, _ = user_pass.split(":", 1)
            return parts[0].split("://", 1)[0] + "://" + user + ":****@" + parts[1]
    return url


def _worker_dlq_runtime_fields(wc: WorkerConfig) -> dict[str, Any]:
    """Runtime overview / worker-dlq-config: same semantics as :meth:`Worker.start` DLQ."""
    if not wc.dlq_enabled:
        return {
            "dlq_enabled": False,
            "dlq_persistence": "disabled",
            "dlq_table_name": wc.dlq_table_name,
            "dlq_database_url_masked": None,
        }
    return {
        "dlq_enabled": True,
        "dlq_persistence": "database",
        "dlq_table_name": wc.dlq_table_name,
        "dlq_database_url_masked": _mask_database_url(wc.resolve_dlq_database_url()),
    }


@router.get(
    "/settings/worker-dlq-config",
    response_model=WorkerDlqConfigResponse,
    status_code=status.HTTP_200_OK,
    summary="Get worker DLQ configuration (masked)",
)
async def get_worker_dlq_config() -> WorkerDlqConfigResponse:
    wc = WorkerConfig()
    fields = _worker_dlq_runtime_fields(wc)
    return WorkerDlqConfigResponse(
        dlq_enabled=fields["dlq_enabled"],
        dlq_database_url=fields["dlq_database_url_masked"],
        dlq_table_name=fields["dlq_table_name"],
        persistence=fields["dlq_persistence"],
    )


@router.post(
    "/settings/test-dlq",
    response_model=DlqTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test DLQ connection",
    description="Test DLQ database connectivity and verify the table exists",
)
async def test_dlq(request: DlqTestRequest) -> DlqTestResponse:
    try:
        conn_str = _build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    if not request.table_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="table_name is required",
        )
    ok, message = verify_dlq_connection(conn_str, request.table_name)
    return DlqTestResponse(success=ok, message=message)


@router.post(
    "/settings/dlq-stats",
    response_model=DlqStatsResponse,
    status_code=status.HTTP_200_OK,
    summary="Get DLQ statistics",
)
async def post_dlq_stats(request: DlqStatsRequest) -> DlqStatsResponse:
    try:
        conn_str = _build_connection_string(
            connection_string=request.connection_string,
            host=request.host,
            port=request.port,
            database=request.database,
            username=request.username,
            password=request.password,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    if not request.table_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="table_name is required",
        )
    try:
        stats = get_dlq_stats(conn_str, request.table_name)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    except SQLAlchemyError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Database error: {exc}",
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Unexpected error: {exc}",
        ) from exc
    return DlqStatsResponse(
        total_messages=stats.total_messages,
        by_reason=stats.by_reason,
        by_stage=stats.by_stage,
        by_status=stats.by_status,
    )
