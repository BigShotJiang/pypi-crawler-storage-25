# PyStator API

REST API for PyStator: **stateless** transition computation, **stored machines**, **entity lifecycle** (with database), auth, settings, and templates.

## Install

```bash
pip install pystator[api]
```

PostgreSQL URLs are supported when you install `pystator[api]` (includes the driver). Copy `pystator.cfg.example` to `pystator.cfg` and set `PYSTATOR_DATABASE_URL` (or use env) so machines, entities, and history persist.

Initialize the database:

```bash
pystator db upgrade
# optional: pystator db seed
```

## Run

```bash
pystator api
# or
uvicorn pystator.api.main:app --host 0.0.0.0 --port 8004 --reload
```

- Swagger: `http://localhost:8004/docs`
- ReDoc: `http://localhost:8004/redoc`

## Route groups (v1)

All JSON APIs are under `/api/v1/…` unless noted.

| Tag | Purpose |
|-----|--------|
| **Auth** | Login, JWT, current user (`/api/v1/auth/...`) |
| **Process** | `POST /validate` — validate FSM config; `POST /process` — **stateless** one-shot transition (full `config` + `current_state` + `trigger` + optional `context`). Returns `actions_to_execute` / exit / enter specs; **does not** run actions or touch the DB. |
| **Machines** | CRUD stored machine definitions (requires DB) |
| **Entities** | Per-entity routes: create, **`POST .../events`** (orchestrator: persist + **run actions** + `action_results`), **`POST .../dry-run`**, snapshot/history/metrics, **`POST .../apply-data`** (enqueue triggerless update for **worker**). |
| **Entities (bulk)** | `POST /api/v1/entities/bulk/create`, `POST /api/v1/entities/bulk/events` — batch create or same trigger across many entities (must be registered **before** the per-entity router). |
| **Settings** | Database test, DLQ stats/test, discovery DB config, optional admin **server-config** (read/patch `pystator.cfg`), runtime fields (e.g. inline code feature flags). |
| **Observability** | KPIs, worker-event listing, related feeds |
| **Templates** | Starter FSM templates for UI |

**Health:** `GET /health` (no auth).

## Design notes

- **`/process`** is **stateless**: each request may include the full FSM `config`. Guards named in YAML are treated as **pass-through** unless you run custom middleware—safe for validation and diagramming. It does **not** execute transition actions for you; the client persists state and runs side effects if needed.
- **`POST .../entities/{id}/events`** uses the **orchestrator** (same sandwich as `pystator worker`): stored context is merged with the request payload, and configured transition actions run on the server. The HTTP request waits until processing finishes; for long work prefer the worker or a client-driven `/process` loop.
- **Entity routes** use the **SQLAlchemy** state store and match the worker/API database schema.
- **Auth** is optional: when JWT secrets/users are configured, routes use Bearer tokens; otherwise behavior follows `pystator.cfg` / env.

## See also

- [REST API guide](../../../docs/api/rest-api.md) (MkDocs)
- [Tutorial: API and UI](../../../docs/tutorials/api-and-ui.md)
- [Configuration](../../../docs/guides/configuration.md)
- [Worker](../../../docs/guides/worker.md) — queued processing with `submit_event` + `pystator worker`
