"""Default local development ports (aligned with workspace PORTS.md)."""

from __future__ import annotations

UI_PORT = 3004
API_PORT = 8004
DOCS_PORT = 5004
