"""Read/write ``pystator.cfg`` for the admin server-config API.

Security: only **allow-listed** keys (see ``server_config_editor.PATCHABLE``) are writable,
and routes require **Admin**. Environment variables still override at runtime.

Uses :class:`configparser.ConfigParser` with ``interpolation=None`` so URLs and JSON values
may contain ``%`` without errors.
"""

from __future__ import annotations

import os
import tempfile
from configparser import ConfigParser
from pathlib import Path
from typing import Any

from pystator.config.paths import find_config_file, find_config_file_user_scoped

_CONFIG_NAME = "pystator.cfg"
FEATURES_SECTION = "features"
# Sections also written to the user-scoped cfg path when it differs from the main file
# (must match ``pystator.config.features`` resolution).
MIRROR_TO_USER_SCOPED_SECTIONS: frozenset[str] = frozenset({FEATURES_SECTION})
MAX_OPTION_VALUE_CHARS = 65_536


def resolve_config_path_for_write() -> Path:
    """Path to read/update: existing ``find_config_file`` result or ``~/.pystator/pystator.cfg``."""
    existing = find_config_file(_CONFIG_NAME)
    if existing:
        return Path(existing)
    home_dir = Path.home() / ".pystator"
    home_dir.mkdir(parents=True, exist_ok=True)
    return home_dir / _CONFIG_NAME


def resolve_features_cfg_path_for_write() -> Path:
    """Path where ``[features]`` is written so :mod:`pystator.config.features` can read it.

    Uses :func:`~pystator.config.paths.find_config_file_user_scoped` (cwd, home, parents);
    if none exists, ``~/.pystator/pystator.cfg`` (created on write).
    """
    existing = find_config_file_user_scoped(_CONFIG_NAME)
    if existing:
        return Path(existing)
    home_dir = Path.home() / ".pystator"
    home_dir.mkdir(parents=True, exist_ok=True)
    return home_dir / _CONFIG_NAME


def config_file_path_display() -> str | None:
    """Resolved path if a config file already exists (for UI)."""
    p = find_config_file(_CONFIG_NAME)
    return str(p) if p else None


def env_overrides(env_key: str) -> bool:
    """True when the process environment sets this variable (non-empty)."""
    raw = os.getenv(env_key)
    return raw is not None and str(raw).strip() != ""


def _config_parser() -> ConfigParser:
    return ConfigParser(interpolation=None)


def assert_option_value_length(value: str, *, key: str) -> None:
    if len(value) > MAX_OPTION_VALUE_CHARS:
        raise ValueError(
            f"{key}: value exceeds maximum length ({MAX_OPTION_VALUE_CHARS} characters)"
        )


def read_cfg_option(section: str, option_key: str) -> str | None:
    """Raw string from the file used for that section (features → user-scoped path)."""
    path = (
        resolve_features_cfg_path_for_write()
        if section == FEATURES_SECTION
        else resolve_config_path_for_write()
    )
    if not path.exists():
        return None
    cfg = _config_parser()
    try:
        cfg.read(path, encoding="utf-8")
    except OSError:
        return None
    if not cfg.has_section(section):
        return None
    if not cfg.has_option(section, option_key):
        return None
    val = cfg.get(section, option_key, fallback="")
    return val.strip() if val and val.strip() else val


def merge_and_write(
    section_updates: dict[str, dict[str, str]],
    *,
    target_path: Path | None = None,
) -> Path:
    """Merge ``{section: {OPTION_KEY: value_str}}`` into the config file and save atomically.

    Creates the file (and ``~/.pystator``) if needed. Option names use env-style
    identifiers (e.g. ``PYSTATOR_UI_THEME``); ConfigParser stores them case-insensitively.

    ``target_path`` defaults to :func:`resolve_config_path_for_write`.
    """
    path = target_path or resolve_config_path_for_write()
    cfg = _config_parser()
    if path.exists():
        try:
            cfg.read(path, encoding="utf-8")
        except OSError:
            pass

    for section, options in section_updates.items():
        if not cfg.has_section(section):
            cfg.add_section(section)
        for opt_key, val in options.items():
            assert_option_value_length(val, key=opt_key)
            cfg.set(section, opt_key, val)

    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        suffix=".tmp",
        prefix="pystator.cfg.",
        dir=path.parent,
        text=True,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            cfg.write(fh)
        os.replace(tmp_name, path)
    except Exception:
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise
    return path


def normalize_bool_for_cfg(value: Any) -> str:
    if isinstance(value, bool):
        return "1" if value else "0"
    s = str(value).strip().lower()
    if s in {"1", "true", "yes", "on"}:
        return "1"
    if s in {"0", "false", "no", "off"}:
        return "0"
    raise ValueError(f"expected boolean-like value, got {value!r}")


def normalize_int_for_cfg(value: Any, *, min_val: int | None = None) -> str:
    try:
        n = int(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"expected integer, got {value!r}") from e
    if min_val is not None and n < min_val:
        raise ValueError(f"value must be >= {min_val}")
    return str(n)


def normalize_float_for_cfg(
    value: Any, *, min_val: float = 0.0, max_val: float = 1.0
) -> str:
    try:
        x = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"expected number, got {value!r}") from e
    x = max(min_val, min(max_val, x))
    return str(x)
