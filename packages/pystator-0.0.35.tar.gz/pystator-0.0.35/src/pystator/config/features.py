"""Feature flags: env ``PYSTATOR_*`` overrides ``pystator.cfg`` (same pattern as database, auth, discovery)."""

from __future__ import annotations

import os
from configparser import ConfigParser
from typing import Literal

from pystator.config.paths import find_config_file_user_scoped

_ENV_KEY_INLINE = "PYSTATOR_ALLOW_INLINE_CODE_ACTIONS"
_ENV_KEY_IMPORTS = "PYSTATOR_ALLOW_INLINE_CODE_IMPORTS"
_TRUTHY = frozenset({"1", "true", "yes", "on"})
_FALSEY = frozenset({"0", "false", "no", "off"})
_FEATURES_SECTION = "features"

_Source = Literal["environment", "config_file", "default"]


def _parse_flag_value(raw: str) -> bool:
    s = raw.strip().lower()
    if s in _FALSEY:
        return False
    if s in _TRUTHY:
        return True
    return False


def _from_config_file(env_key: str) -> str | None:
    cfg_path = find_config_file_user_scoped("pystator.cfg")
    if not cfg_path:
        return None
    try:
        cfg = ConfigParser(interpolation=None)
        cfg.read(cfg_path)
        if cfg.has_section(_FEATURES_SECTION):
            v = cfg.get(_FEATURES_SECTION, env_key, fallback=None)
            if v is not None and str(v).strip():
                return str(v).strip()
    except Exception:
        pass
    return None


def _resolve_feature_flag(env_key: str) -> tuple[bool, _Source]:
    """Resolve a boolean from env, then ``[features]`` in user-scoped ``pystator.cfg``, else False."""
    raw = os.getenv(env_key)
    if raw is not None and raw.strip() != "":
        return _parse_flag_value(raw), "environment"
    cfg_val = _from_config_file(env_key)
    if cfg_val is not None:
        return _parse_flag_value(cfg_val), "config_file"
    return False, "default"


def get_allow_inline_code_actions_source() -> _Source:
    """Where ``PYSTATOR_ALLOW_INLINE_CODE_ACTIONS`` was resolved from (for diagnostics / UI)."""
    return _resolve_feature_flag(_ENV_KEY_INLINE)[1]


def get_allow_inline_code_actions() -> bool:
    """Whether inline ``code:`` FSM actions may run.

    Order: environment variable wins, then ``pystator.cfg`` (see
    :func:`pystator.config.paths.find_config_file_user_scoped` — cwd, ``~/.pystator/``,
    parents of cwd; not the package install path), section ``[features]`` key
    ``PYSTATOR_ALLOW_INLINE_CODE_ACTIONS``, then ``False``.
    """
    return _resolve_feature_flag(_ENV_KEY_INLINE)[0]


def get_allow_inline_code_imports_source() -> _Source:
    """Where ``PYSTATOR_ALLOW_INLINE_CODE_IMPORTS`` was resolved from."""
    return _resolve_feature_flag(_ENV_KEY_IMPORTS)[1]


def get_allow_inline_code_imports() -> bool:
    """Whether ``code:`` actions may use allowlisted imports and restricted builtins.

    Subordinate to :func:`get_allow_inline_code_actions`: if base inline code is off,
    :func:`pystator.code_action.execute_code_action` does not run user code at all.

    Same resolution order as ``PYSTATOR_ALLOW_INLINE_CODE_ACTIONS``: env, then
    ``[features]`` key ``PYSTATOR_ALLOW_INLINE_CODE_IMPORTS``, default ``False``.
    """
    return _resolve_feature_flag(_ENV_KEY_IMPORTS)[0]
