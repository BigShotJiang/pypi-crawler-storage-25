"""Registry catalog settings: database load flag (no file path — parity with FSM machines).

Environment variables override ``pystator.cfg`` ``[registry]`` (same pattern as
:mod:`pystator.config.features`).

There is **no** registry file env var (unlike ``PYSTATOR_WORKER_MACHINE_DIR`` when
``MACHINE_SOURCE=yaml`` for loading ``*.yaml`` machines from a directory). The action/guard catalog lives in
``registry_catalog`` and is loaded at worker startup; use API/UI import or DB
seeds to populate it. YAML is interchange only (export/import), like FSM configs.
"""

from __future__ import annotations

import os
from configparser import ConfigParser
from typing import Literal

from pystator.config.paths import find_config_file

_ENV_LOAD_DB = "PYSTATOR_REGISTRY_LOAD_DATABASE"
_SECTION = "registry"
_TRUTHY = frozenset({"1", "true", "yes", "on"})
_FALSEY = frozenset({"0", "false", "no", "off"})

_Source = Literal["environment", "config_file", "default"]


def _parse_bool(raw: str) -> bool:
    s = raw.strip().lower()
    if s in _FALSEY:
        return False
    if s in _TRUTHY:
        return True
    return False


def _from_config_file(key: str) -> str | None:
    cfg_path = find_config_file("pystator.cfg")
    if not cfg_path:
        return None
    try:
        cfg = ConfigParser()
        cfg.read(cfg_path)
        if cfg.has_section(_SECTION):
            v = cfg.get(_SECTION, key, fallback=None)
            if v is not None and str(v).strip():
                return str(v).strip()
    except Exception:
        pass
    return None


def _resolve_load_database() -> tuple[bool, _Source]:
    raw = os.getenv(_ENV_LOAD_DB)
    if raw is not None and raw.strip() != "":
        return _parse_bool(raw), "environment"
    cfg_val = _from_config_file(_ENV_LOAD_DB)
    if cfg_val is not None:
        return _parse_bool(cfg_val), "config_file"
    return True, "default"


def get_registry_load_database() -> bool:
    """Whether to load catalog rows from the database when a URL is available.

    Default ``True`` (opt out with ``0`` / ``false``). If the
    ``registry_catalog`` table is missing, the loader logs and skips.
    """
    return _resolve_load_database()[0]


def get_registry_load_database_source() -> _Source:
    """Where :func:`get_registry_load_database` was resolved from."""
    return _resolve_load_database()[1]
