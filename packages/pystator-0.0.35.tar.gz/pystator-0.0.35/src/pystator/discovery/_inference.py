"""Stateless inference algorithms for the discovery engine."""

from __future__ import annotations

import logging
import re
from collections import defaultdict
from datetime import datetime
from typing import Any

from pystator.discovery.models import InferredEdge, ObservedStateEvent

logger = logging.getLogger(__name__)


def edges_to_dict(edges: list[InferredEdge]) -> list[dict[str, Any]]:
    """Serialize a list of inferred edges to plain dicts.

    Args:
        edges: Inferred edges to convert.

    Returns:
        List of dicts with edge fields suitable for JSON serialization.
    """
    return [
        {
            "source_state": e.source_state,
            "destination_state": e.destination_state,
            "count": e.count,
            "unique_entities": e.unique_entities,
            "unique_sources": e.unique_sources,
            "confidence": e.confidence,
            "last_seen_at": e.last_seen_at.isoformat() if e.last_seen_at else None,
        }
        for e in edges
    ]


def infer_edges(observations: list[ObservedStateEvent]) -> list[InferredEdge]:
    """Infer weighted transition edges from observed state sequences.

    Groups observations by entity, orders them chronologically, and counts
    consecutive state pairs to produce weighted edges with confidence scores.

    Args:
        observations: Flat list of observed state events across entities.

    Returns:
        Sorted list of inferred edges with counts, unique entities/sources,
        confidence, and last-seen timestamps.
    """
    by_entity: dict[str, list[ObservedStateEvent]] = defaultdict(list)
    for ev in observations:
        by_entity[ev.entity_id].append(ev)

    edge_counts: dict[tuple[str, str], int] = defaultdict(int)
    edge_entities: dict[tuple[str, str], set[str]] = defaultdict(set)
    edge_sources: dict[tuple[str, str], set[str]] = defaultdict(set)
    edge_last_seen: dict[tuple[str, str], datetime] = {}

    for entity_events in by_entity.values():
        ordered = sorted(
            entity_events,
            key=lambda x: (x.observed_at, x.ingest_seq, x.ingested_at),
        )
        for idx in range(len(ordered) - 1):
            src = ordered[idx]
            dst = ordered[idx + 1]
            key = (src.state, dst.state)
            edge_counts[key] += 1
            edge_entities[key].add(src.entity_id)
            edge_sources[key].add(src.source)
            edge_last_seen[key] = max(
                edge_last_seen.get(key, src.observed_at), dst.observed_at
            )

    outgoing_totals: dict[str, int] = defaultdict(int)
    for (src, _), count in edge_counts.items():
        outgoing_totals[src] += count

    edges: list[InferredEdge] = []
    for (src, dst), count in edge_counts.items():
        total = outgoing_totals[src]
        confidence = (count / total) if total > 0 else 0.0
        edges.append(
            InferredEdge(
                source_state=src,
                destination_state=dst,
                count=count,
                unique_entities=len(edge_entities[(src, dst)]),
                unique_sources=len(edge_sources[(src, dst)]),
                confidence=confidence,
                last_seen_at=edge_last_seen.get((src, dst)),
            )
        )
    edges.sort(key=lambda e: (e.source_state, e.destination_state))
    return edges


def build_machine_config(
    machine_name: str, edges: list[InferredEdge]
) -> dict[str, Any]:
    """Build a state-machine config dict from inferred edges.

    Normalizes state names to lowercase snake_case, deduplicates states,
    and produces a config dict compatible with ``StateMachine.from_dict``.

    Args:
        machine_name: Name for the generated machine.
        edges: Inferred edges to include as transitions.

    Returns:
        Config dict with ``meta``, ``states``, and ``transitions`` keys.
    """

    def normalize(name: str) -> str:
        return re.sub(r"[^a-z0-9_]+", "_", name.strip().lower()).strip("_")

    states = set()
    transitions: list[dict[str, Any]] = []
    for edge in edges:
        src = normalize(edge.source_state)
        dst = normalize(edge.destination_state)
        if not src or not dst:
            continue
        states.add(src)
        states.add(dst)
        trigger = f"to_{dst}"
        transitions.append(
            {
                "trigger": trigger,
                "source": src,
                "dest": dst,
                "meta": {
                    "inferred": True,
                    "count": edge.count,
                    "confidence": edge.confidence,
                },
            }
        )
    sorted_states = sorted(states)
    initial_state = sorted_states[0] if sorted_states else "unknown"
    state_defs = [
        {
            "name": name,
            "type": "initial" if name == initial_state else "stable",
        }
        for name in sorted_states
    ]
    return {
        "meta": {
            "machine_name": machine_name,
            "version": "0.1.0",
            "source": "pystator.discovery",
        },
        "states": state_defs,
        "transitions": transitions,
    }


def next_version(latest_version: str | None) -> str:
    """Compute the next patch version string.

    Args:
        latest_version: The current latest version (e.g. ``"0.1.2"``),
            or ``None`` if no prior version exists.

    Returns:
        The next version string with the patch component incremented,
        or ``"0.1.0"`` when there is no prior version or the format
        is invalid.
    """
    if latest_version is None:
        return "0.1.0"
    parts = latest_version.split(".")
    if len(parts) != 3 or not all(part.isdigit() for part in parts):
        return "0.1.0"
    major, minor, patch = (int(p) for p in parts)
    return f"{major}.{minor}.{patch + 1}"
