"""Discovery subsystem for inferred state machines."""

from __future__ import annotations

from pystator.discovery._visualization import candidate_to_dot, candidate_to_mermaid
from pystator.discovery.classification import (
    ClassificationResult,
    ClassificationRuleSet,
    DataIngester,
    IngestionResult,
    StateClassifier,
)
from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    InferredEdge,
    ObservedStateEvent,
    ShadowDiff,
)
from pystator.discovery.protocols import (
    BuiltDiscoveryCandidateStore,
    DraftStore,
    ObservationStore,
    ShadowResultStore,
)
from pystator.discovery.service import InferenceEngine, InferenceThresholds
from pystator.discovery.stores import (
    InMemoryDiscoveryStore,
    MongoDBDiscoveryStore,
    PostgresDiscoveryStore,
    RedisDiscoveryStore,
    SQLiteDiscoveryStore,
    create_discovery_store,
)

__all__ = [
    "ObservedStateEvent",
    "InferredEdge",
    "BuiltDiscoveryCandidate",
    "DiscoveryDraft",
    "DiscoveryDraftFilter",
    "ShadowDiff",
    "ObservationStore",
    "BuiltDiscoveryCandidateStore",
    "ShadowResultStore",
    "DraftStore",
    "InferenceEngine",
    "InferenceThresholds",
    "create_discovery_store",
    "InMemoryDiscoveryStore",
    "SQLiteDiscoveryStore",
    "PostgresDiscoveryStore",
    "MongoDBDiscoveryStore",
    "RedisDiscoveryStore",
    "StateClassifier",
    "DataIngester",
    "ClassificationResult",
    "ClassificationRuleSet",
    "IngestionResult",
    "candidate_to_dot",
    "candidate_to_mermaid",
]
