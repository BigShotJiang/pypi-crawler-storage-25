"""Visual export utilities for discovery candidates."""

from __future__ import annotations

from typing import Any

from pystator.discovery.models import BuiltDiscoveryCandidate


def candidate_to_mermaid(candidate: BuiltDiscoveryCandidate, **kwargs: Any) -> str:
    """Generate a Mermaid stateDiagram-v2 from a built discovery candidate.

    Builds a temporary StateMachine from the candidate config and
    delegates to :func:`pystator.visualization.to_mermaid`.

    Args:
        candidate: The built discovery candidate to visualize.
        **kwargs: Passed through to ``to_mermaid()`` (title, show_guards, direction, etc.).

    Returns:
        Mermaid diagram markup string.
    """
    from pystator.machine import StateMachine
    from pystator.visualization import to_mermaid

    machine = StateMachine.from_dict(candidate.config)
    return to_mermaid(machine, **kwargs)


def candidate_to_dot(candidate: BuiltDiscoveryCandidate, **kwargs: Any) -> str:
    """Generate a Graphviz DOT diagram from a built discovery candidate.

    Args:
        candidate: The built discovery candidate to visualize.
        **kwargs: Passed through to ``to_dot()``.

    Returns:
        DOT format string.
    """
    from pystator.machine import StateMachine
    from pystator.visualization import to_dot

    machine = StateMachine.from_dict(candidate.config)
    return to_dot(machine, **kwargs)
