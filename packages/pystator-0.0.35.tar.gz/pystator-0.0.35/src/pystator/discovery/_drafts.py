"""Draft management for discovery inference workflows."""

from __future__ import annotations

import uuid
from dataclasses import replace
from datetime import UTC, datetime
from typing import Any, Literal

from pystator.discovery.models import DiscoveryDraft, DiscoveryDraftFilter
from pystator.discovery.protocols import DraftStore


class DraftManager:
    """Manages discovery draft lifecycle: create, update, preview, build.

    Encapsulates all draft CRUD and the preview/build workflows that
    delegate back to the parent ``InferenceEngine`` for inference and
    candidate building.

    Args:
        draft_store: Persistence backend for drafts.
        default_min_edge_count: Default minimum edge count from thresholds.
        default_min_confidence: Default minimum confidence from thresholds.
        engine: The parent ``InferenceEngine`` used for preview and build
            operations.
    """

    def __init__(
        self,
        draft_store: DraftStore,
        thresholds: Any,
        engine: Any,
    ) -> None:
        self._drafts = draft_store
        self._thresholds = thresholds
        self._engine = engine

    def create_draft(
        self,
        machine_name: str,
        title: str | None = None,
        *,
        filter: DiscoveryDraftFilter | None = None,
    ) -> DiscoveryDraft:
        """Create a new discovery draft with default settings.

        Args:
            machine_name: Home channel for this draft. Used as the
                default target when publishing and as the legacy scope
                selector when *filter* is ``None``.
            title: Optional human-readable title.
            filter: Optional filter expressing which observations this
                draft reads from the shared event stream. When set,
                ``selected_entity_ids`` is ignored by preview/build.

        Returns:
            The persisted draft with a generated UUID.
        """
        now = datetime.now(UTC)
        thr = self._thresholds
        draft = DiscoveryDraft(
            id=str(uuid.uuid4()),
            machine_name=machine_name,
            title=title,
            selected_entity_ids=(),
            mode="inference",
            min_edge_count=thr.min_edge_count,
            min_confidence=thr.min_confidence,
            manual_edge_selection=(),
            created_at=now,
            updated_at=now,
            last_built_version=None,
            filter=filter,
        )
        return self._drafts.save_draft(draft)

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """List every draft across all channels, newest updated first."""
        return self._drafts.list_all_drafts()

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        """Retrieve a draft by ID.

        Args:
            draft_id: Unique draft identifier.

        Returns:
            The draft, or ``None`` if not found.
        """
        return self._drafts.get_draft(draft_id)

    def list_drafts(self, machine_name: str) -> list[DiscoveryDraft]:
        """List all drafts for a given machine.

        Args:
            machine_name: Machine to list drafts for.

        Returns:
            List of drafts (may be empty).
        """
        return self._drafts.list_drafts(machine_name)

    def delete_draft(self, draft_id: str) -> bool:
        """Delete a draft by ID.

        Args:
            draft_id: Unique draft identifier.

        Returns:
            True if the draft was deleted, False if not found.
        """
        return self._drafts.delete_draft(draft_id)

    def update_draft(
        self,
        draft_id: str,
        *,
        title: str | None = None,
        selected_entity_ids: list[str] | None = None,
        mode: Literal["inference", "manual"] | None = None,
        min_edge_count: int | None = None,
        min_confidence: float | None = None,
        manual_edge_selection: list[tuple[str, str]] | None = None,
        filter: DiscoveryDraftFilter | None = None,
        clear_filter: bool = False,
    ) -> DiscoveryDraft:
        """Partially update a draft's settings.

        Pass ``None`` (or omit the argument) to leave a field unchanged.
        Title clearing (setting back to ``None`` after being set) is
        handled at the patch-layer via key-presence semantics rather
        than through this engine-level method.

        Filter semantics:
            - ``filter=None`` and ``clear_filter=False`` → leave
              the draft's filter unchanged.
            - ``filter=<value>`` → set the filter to *value*.
            - ``clear_filter=True`` → clear the filter (set to ``None``).
              Takes precedence over any explicit ``filter`` argument.

        Args:
            draft_id: Unique draft identifier.
            title: New title (``None`` = leave unchanged).
            selected_entity_ids: Entity IDs to scope legacy inference to.
            mode: ``"inference"`` or ``"manual"``.
            min_edge_count: Minimum edge count threshold.
            min_confidence: Minimum confidence threshold.
            manual_edge_selection: Explicit edge pairs for manual mode.
            filter: New filter value (``None`` = leave unchanged).
            clear_filter: When ``True``, clear the filter.

        Returns:
            The updated draft.

        Raises:
            ValueError: If the draft is not found.
        """
        draft = self._drafts.get_draft(draft_id)
        if draft is None:
            raise ValueError(f"draft not found: {draft_id}")
        updates: dict[str, Any] = {"updated_at": datetime.now(UTC)}
        if title is not None:
            updates["title"] = title
        if selected_entity_ids is not None:
            updates["selected_entity_ids"] = tuple(selected_entity_ids)
        if mode is not None:
            updates["mode"] = mode
        if min_edge_count is not None:
            updates["min_edge_count"] = max(1, int(min_edge_count))
        if min_confidence is not None:
            mc = float(min_confidence)
            updates["min_confidence"] = min(1.0, max(0.0, mc))
        if manual_edge_selection is not None:
            updates["manual_edge_selection"] = tuple(
                (str(a), str(b)) for a, b in manual_edge_selection
            )
        if clear_filter:
            updates["filter"] = None
        elif filter is not None:
            updates["filter"] = filter
        new_draft = replace(draft, **updates)
        return self._drafts.save_draft(new_draft)

    def preview_draft(self, draft_id: str) -> dict[str, Any]:
        """Preview inferred edges for a draft's scope without building.

        When the draft has a ``filter`` set, observations are pulled
        across channels via
        :meth:`InferenceEngine.preview_filter`. Otherwise the legacy
        ``(machine_name, selected_entity_ids)`` path is used.

        Args:
            draft_id: Unique draft identifier.

        Returns:
            Preview dict (see :meth:`InferenceEngine.preview_filter`).

        Raises:
            ValueError: If the draft is not found.
        """
        draft = self._drafts.get_draft(draft_id)
        if draft is None:
            raise ValueError(f"draft not found: {draft_id}")
        if draft.filter is not None:
            return self._engine.preview_filter(
                draft.filter,
                mode=draft.mode,
                min_edge_count=draft.min_edge_count,
                min_confidence=draft.min_confidence,
            )
        entity_scope = list(draft.selected_entity_ids) or None
        return self._engine.preview_inference(
            draft.machine_name,
            mode=draft.mode,
            entity_ids=entity_scope,
            min_edge_count=draft.min_edge_count,
            min_confidence=draft.min_confidence,
        )

    def build_from_draft(
        self,
        draft_id: str,
        *,
        target_machine_name: str | None = None,
    ) -> Any:
        """Build a candidate machine from the draft's scope and settings.

        Args:
            draft_id: Unique draft identifier.
            target_machine_name: Override for the published candidate's
                catalog name. When omitted, the draft's ``machine_name``
                (home channel) is used.

        Returns:
            The built ``BuiltDiscoveryCandidate``.

        Raises:
            ValueError: If the draft is not found or is in manual mode
                without edge selections.
        """
        draft = self._drafts.get_draft(draft_id)
        if draft is None:
            raise ValueError(f"draft not found: {draft_id}")
        edge_sel: list[tuple[str, str]] | None = None
        if draft.mode == "manual":
            edge_sel = list(draft.manual_edge_selection)
            if not edge_sel:
                raise ValueError(
                    "manual mode requires manual_edge_selection on the draft"
                )
        entity_scope = (
            None
            if draft.filter is not None
            else (list(draft.selected_entity_ids) or None)
        )
        cand = self._engine.build_candidate(
            draft.machine_name,
            mode=draft.mode,
            entity_ids=entity_scope,
            edge_selection=edge_sel,
            min_edge_count=draft.min_edge_count,
            min_confidence=draft.min_confidence,
            draft_id=draft.id,
            filter=draft.filter,
            target_machine_name=target_machine_name,
        )
        updated = replace(
            draft,
            last_built_version=cand.version,
            updated_at=datetime.now(UTC),
        )
        self._drafts.save_draft(updated)
        return cand
