"""Idempotent DDL for SQL-backed discovery stores (SQLite and PostgreSQL)."""

from __future__ import annotations

from sqlalchemy import inspect, text
from sqlalchemy.engine import Engine

# Single source of truth: tables first, then indexes. Used by discovery stores
# and by db init/upgrade provisioning.
DISCOVERY_DDL_STATEMENTS: tuple[str, ...] = (
    """
    CREATE TABLE IF NOT EXISTS discovery_observations (
      machine_name TEXT NOT NULL,
      entity_id TEXT NOT NULL,
      state TEXT NOT NULL,
      observed_at TEXT NOT NULL,
      source TEXT NOT NULL,
      source_event_id TEXT,
      metadata_json TEXT NOT NULL,
      ingested_at TEXT NOT NULL,
      ingest_seq INTEGER NOT NULL DEFAULT 0,
      UNIQUE(machine_name, entity_id, state, observed_at, source, source_event_id)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS discovery_edges (
      machine_name TEXT NOT NULL,
      source_state TEXT NOT NULL,
      destination_state TEXT NOT NULL,
      count INTEGER NOT NULL,
      unique_entities INTEGER NOT NULL,
      unique_sources INTEGER NOT NULL,
      confidence REAL NOT NULL,
      last_seen_at TEXT,
      UNIQUE(machine_name, source_state, destination_state)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS discovery_built_candidates (
      machine_name TEXT NOT NULL,
      version TEXT NOT NULL,
      status TEXT NOT NULL,
      config_json TEXT NOT NULL,
      metadata_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      candidate_sequence INTEGER NOT NULL,
      UNIQUE(machine_name, version),
      UNIQUE(machine_name, candidate_sequence)
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS discovery_shadow_diffs (
      machine_name TEXT NOT NULL,
      source_state TEXT NOT NULL,
      trigger TEXT NOT NULL,
      active_success INTEGER NOT NULL,
      active_target_state TEXT,
      candidate_success INTEGER NOT NULL,
      candidate_target_state TEXT,
      differs INTEGER NOT NULL,
      reason TEXT,
      metadata_json TEXT NOT NULL,
      recorded_at TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS discovery_drafts (
      id TEXT PRIMARY KEY,
      machine_name TEXT NOT NULL,
      title TEXT,
      selected_entity_ids_json TEXT NOT NULL DEFAULT '[]',
      mode TEXT NOT NULL DEFAULT 'inference',
      min_edge_count INTEGER NOT NULL DEFAULT 2,
      min_confidence REAL NOT NULL DEFAULT 0.5,
      manual_edge_selection_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_built_version TEXT,
      filter_json TEXT NOT NULL DEFAULT '{}'
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_discovery_obs_machine_observed
    ON discovery_observations(machine_name, observed_at)
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_discovery_edges_machine
    ON discovery_edges(machine_name)
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_discovery_built_candidates_machine_created
    ON discovery_built_candidates(machine_name, created_at)
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_discovery_shadow_machine_recorded
    ON discovery_shadow_diffs(machine_name, recorded_at)
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_discovery_drafts_machine_updated
    ON discovery_drafts(machine_name, updated_at)
    """,
)


def migrate_legacy_discovery_names(engine: Engine) -> None:
    """Rename pre-2026 discovery tables if present (idempotent)."""
    insp = inspect(engine)
    tables = set(insp.get_table_names())
    with engine.begin() as conn:
        if (
            "discovery_candidates" in tables
            and "discovery_built_candidates" not in tables
        ):
            conn.execute(
                text(
                    "ALTER TABLE discovery_candidates RENAME TO discovery_built_candidates"
                )
            )
            tables.discard("discovery_candidates")
            tables.add("discovery_built_candidates")
        if "discovery_workspaces" in tables and "discovery_drafts" not in tables:
            conn.execute(
                text("ALTER TABLE discovery_workspaces RENAME TO discovery_drafts")
            )


def ensure_candidate_sequence_column(engine: Engine) -> None:
    """Add candidate_sequence to legacy discovery_built_candidates and backfill (idempotent)."""
    insp = inspect(engine)
    if "discovery_built_candidates" not in insp.get_table_names():
        return
    cols = {c["name"] for c in insp.get_columns("discovery_built_candidates")}
    if "candidate_sequence" in cols:
        return

    dialect = engine.dialect.name
    with engine.begin() as conn:
        conn.execute(
            text(
                "ALTER TABLE discovery_built_candidates ADD COLUMN candidate_sequence INTEGER"
            )
        )
        if dialect == "sqlite":
            conn.execute(
                text(
                    """
                    UPDATE discovery_built_candidates AS t
                    SET candidate_sequence = (
                      SELECT COUNT(*)
                      FROM discovery_built_candidates AS o
                      WHERE o.machine_name = t.machine_name
                        AND (
                          o.created_at < t.created_at
                          OR (o.created_at = t.created_at AND o.version < t.version)
                        )
                    ) + 1
                    """
                )
            )
        else:
            conn.execute(
                text(
                    """
                    UPDATE discovery_built_candidates AS t
                    SET candidate_sequence = sub.seq
                    FROM (
                      SELECT machine_name, version,
                             ROW_NUMBER() OVER (
                               PARTITION BY machine_name
                               ORDER BY created_at ASC, version ASC
                             ) AS seq
                      FROM discovery_built_candidates
                    ) AS sub
                    WHERE t.machine_name = sub.machine_name AND t.version = sub.version
                    """
                )
            )
        conn.execute(
            text(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "ux_discovery_built_candidates_machine_sequence "
                "ON discovery_built_candidates(machine_name, candidate_sequence)"
            )
        )


def ensure_draft_filter_column(engine: Engine) -> None:
    """Add filter_json to legacy discovery_drafts (idempotent)."""
    insp = inspect(engine)
    if "discovery_drafts" not in insp.get_table_names():
        return
    cols = {c["name"] for c in insp.get_columns("discovery_drafts")}
    if "filter_json" in cols:
        return
    with engine.begin() as conn:
        conn.execute(
            text(
                "ALTER TABLE discovery_drafts "
                "ADD COLUMN filter_json TEXT NOT NULL DEFAULT '{}'"
            )
        )


def apply_discovery_schema(engine: Engine) -> None:
    """Create discovery tables and indexes if missing (idempotent)."""
    migrate_legacy_discovery_names(engine)
    with engine.begin() as conn:
        for stmt in DISCOVERY_DDL_STATEMENTS:
            conn.execute(text(stmt))
    ensure_candidate_sequence_column(engine)
    ensure_draft_filter_column(engine)
