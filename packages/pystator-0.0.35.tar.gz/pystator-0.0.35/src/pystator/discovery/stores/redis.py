"""Redis discovery store."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from pystator.discovery.models import (
    BuiltDiscoveryCandidate,
    DiscoveryDraft,
    DiscoveryDraftFilter,
    ObservedStateEvent,
    ShadowDiff,
)

try:
    import redis as _redis_lib  # type: ignore[import-not-found,import-untyped]

    REDIS_AVAILABLE = True
except ImportError:
    REDIS_AVAILABLE = False
    _redis_lib = None  # type: ignore[assignment]


def _redis_built_from_item(item: dict) -> BuiltDiscoveryCandidate:
    return BuiltDiscoveryCandidate(
        machine_name=item["machine_name"],
        version=item["version"],
        status=item["status"],
        config=dict(item["config"]),
        metadata=dict(item.get("metadata") or {}),
        created_at=datetime.fromisoformat(item["created_at"]),
        candidate_sequence=int(item.get("candidate_sequence") or 0),
    )


class RedisDiscoveryStore:
    def __init__(
        self, connection_string: str, key_prefix: str = "pystator:discovery"
    ) -> None:
        if not REDIS_AVAILABLE:
            raise ImportError(
                "redis is required for RedisDiscoveryStore. Install with: pip install redis"
            )
        self.connection_string = connection_string
        self.key_prefix = key_prefix
        self._client: Any = None

    def connect(self) -> None:
        self._client = _redis_lib.from_url(
            self.connection_string, decode_responses=True
        )
        self._client.ping()

    def disconnect(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def _require_client(self):
        if self._client is None:
            raise RuntimeError("Not connected. Call connect() first.")
        return self._client

    def _key(self, *parts: str) -> str:
        return f"{self.key_prefix}:{':'.join(parts)}"

    def _json(self, value: Any) -> str:
        return json.dumps(value, default=str)

    def add_observation(self, event: ObservedStateEvent) -> bool:
        client = self._require_client()
        machine_name = event.machine_name
        dedupe_key = self._key(
            "obs",
            machine_name,
            event.entity_id,
            event.state,
            event.observed_at.isoformat(),
            event.source,
            event.source_event_id or "",
        )
        if not client.set(dedupe_key, "1", nx=True):
            return False
        payload = self._json(
            {
                "entity_id": event.entity_id,
                "state": event.state,
                "observed_at": event.observed_at.isoformat(),
                "source": event.source,
                "source_event_id": event.source_event_id,
                "metadata": event.metadata,
                "ingested_at": event.ingested_at.isoformat(),
                "ingest_seq": event.ingest_seq,
            }
        )
        client.rpush(self._key("obslist", machine_name), payload)
        return True

    def list_observations(
        self, machine_name: str, entity_id: str | None = None
    ) -> list[ObservedStateEvent]:
        client = self._require_client()
        rows = client.lrange(self._key("obslist", machine_name), 0, -1)
        out: list[ObservedStateEvent] = []
        for row in rows:
            doc = json.loads(row)
            if entity_id and doc["entity_id"] != entity_id:
                continue
            out.append(
                ObservedStateEvent(
                    entity_id=doc["entity_id"],
                    machine_name=machine_name,
                    state=doc["state"],
                    observed_at=datetime.fromisoformat(doc["observed_at"]),
                    source=doc["source"],
                    source_event_id=doc.get("source_event_id"),
                    metadata=dict(doc.get("metadata") or {}),
                    ingested_at=datetime.fromisoformat(doc["ingested_at"]),
                    ingest_seq=int(doc.get("ingest_seq") or 0),
                )
            )
        out.sort(
            key=lambda e: (e.entity_id, e.observed_at, e.ingest_seq, e.ingested_at)
        )
        return out

    def list_entity_ids(self, machine_name: str) -> list[str]:
        return sorted(
            {
                ev.entity_id
                for ev in self.list_observations(machine_name)
                if ev.entity_id
            }
        )

    def delete_observations_for_entity(self, machine_name: str, entity_id: str) -> int:
        client = self._require_client()
        key = self._key("obslist", machine_name)
        rows = client.lrange(key, 0, -1)
        if not rows:
            return 0
        kept: list[str] = []
        deleted = 0
        for row in rows:
            try:
                doc = json.loads(row)
            except Exception:
                kept.append(row)
                continue
            if str(doc.get("entity_id") or "") == entity_id:
                deleted += 1
            else:
                kept.append(row)
        if deleted <= 0:
            return 0
        pipe = client.pipeline()
        pipe.delete(key)
        if kept:
            pipe.rpush(key, *kept)
        pipe.execute()
        return deleted

    def resolve_observations(
        self, filter: DiscoveryDraftFilter, *, limit: int = 50_000
    ) -> tuple[list[ObservedStateEvent], bool]:
        """Filter-based resolution is not supported on the Redis backend.

        Use the SQLite / PostgreSQL backend or the in-memory store for
        instance-centric discovery workflows.
        """
        raise NotImplementedError(
            "Filter-based resolve_observations requires the SQL or in-memory backend."
        )

    def list_all_channels(self) -> list[str]:
        raise NotImplementedError(
            "list_all_channels requires the SQL or in-memory backend."
        )

    def list_all_sources(self) -> list[str]:
        raise NotImplementedError(
            "list_all_sources requires the SQL or in-memory backend."
        )

    def _max_candidate_sequence(self, client: Any, machine_name: str) -> int:
        versions = client.zrevrange(self._key("candidate_index", machine_name), 0, -1)
        m = 0
        for v in versions:
            raw = client.get(self._key("candidate", machine_name, v))
            if raw:
                doc = json.loads(raw)
                m = max(m, int(doc.get("candidate_sequence") or 0))
        return m

    def save_built_candidate(
        self, candidate: BuiltDiscoveryCandidate
    ) -> BuiltDiscoveryCandidate:
        client = self._require_client()
        mn = candidate.machine_name
        ver = candidate.version
        key = self._key("candidate", mn, ver)
        existing_raw = client.get(key)
        if existing_raw:
            seq = int(json.loads(existing_raw).get("candidate_sequence") or 0)
        else:
            seq = self._max_candidate_sequence(client, mn) + 1
        client.set(
            key,
            self._json(
                {
                    "machine_name": mn,
                    "version": ver,
                    "status": candidate.status,
                    "config": candidate.config,
                    "metadata": candidate.metadata,
                    "created_at": candidate.created_at.isoformat(),
                    "candidate_sequence": seq,
                }
            ),
        )
        client.zadd(
            self._key("candidate_index", mn),
            {ver: candidate.created_at.timestamp()},
        )
        out = self.get_built_candidate(mn, ver)
        assert out is not None
        return out

    def get_built_candidate(
        self, machine_name: str, version: str
    ) -> BuiltDiscoveryCandidate | None:
        client = self._require_client()
        raw = client.get(self._key("candidate", machine_name, version))
        if not raw:
            return None
        item = json.loads(raw)
        return _redis_built_from_item(item)

    def get_latest_built_candidate(
        self, machine_name: str
    ) -> BuiltDiscoveryCandidate | None:
        client = self._require_client()
        versions = client.zrevrange(self._key("candidate_index", machine_name), 0, 0)
        if not versions:
            return None
        return self.get_built_candidate(machine_name, versions[0])

    def list_built_candidates(self, machine_name: str) -> list[BuiltDiscoveryCandidate]:
        client = self._require_client()
        versions = client.zrevrange(self._key("candidate_index", machine_name), 0, -1)
        out: list[BuiltDiscoveryCandidate] = []
        for version in versions:
            item = self.get_built_candidate(machine_name, version)
            if item is not None:
                out.append(item)
        return out

    def record_shadow_diff(self, diff: ShadowDiff) -> None:
        client = self._require_client()
        payload = self._json(
            {
                "machine_name": diff.machine_name,
                "source_state": diff.source_state,
                "trigger": diff.trigger,
                "active_success": diff.active_success,
                "active_target_state": diff.active_target_state,
                "candidate_success": diff.candidate_success,
                "candidate_target_state": diff.candidate_target_state,
                "differs": diff.differs,
                "reason": diff.reason,
                "recorded_at": diff.recorded_at.isoformat(),
                "metadata": diff.metadata,
            }
        )
        client.lpush(self._key("shadow", diff.machine_name), payload)

    def list_shadow_diffs(
        self, machine_name: str, limit: int = 100
    ) -> list[ShadowDiff]:
        client = self._require_client()
        rows = client.lrange(self._key("shadow", machine_name), 0, max(0, limit) - 1)
        out: list[ShadowDiff] = []
        for row in rows:
            item = json.loads(row)
            out.append(
                ShadowDiff(
                    machine_name=item["machine_name"],
                    source_state=item["source_state"],
                    trigger=item["trigger"],
                    active_success=bool(item["active_success"]),
                    active_target_state=item.get("active_target_state"),
                    candidate_success=bool(item["candidate_success"]),
                    candidate_target_state=item.get("candidate_target_state"),
                    differs=bool(item["differs"]),
                    reason=item.get("reason"),
                    recorded_at=datetime.fromisoformat(item["recorded_at"]),
                    metadata=dict(item.get("metadata") or {}),
                )
            )
        return out

    def _draft_from_doc(self, item: dict[str, Any]) -> DiscoveryDraft:
        manual = item.get("manual_edge_selection") or []
        pairs: list[tuple[str, str]] = []
        for x in manual:
            if isinstance(x, dict):
                s, d = x.get("source_state"), x.get("destination_state")
                if isinstance(s, str) and isinstance(d, str):
                    pairs.append((s, d))
        return DiscoveryDraft(
            id=item["id"],
            machine_name=item["machine_name"],
            title=item.get("title"),
            selected_entity_ids=tuple(
                str(x) for x in (item.get("selected_entity_ids") or [])
            ),
            mode=str(item.get("mode") or "inference"),
            min_edge_count=int(item.get("min_edge_count") or 2),
            min_confidence=float(item.get("min_confidence") or 0.5),
            manual_edge_selection=tuple(pairs),
            created_at=datetime.fromisoformat(item["created_at"]),
            updated_at=datetime.fromisoformat(item["updated_at"]),
            last_built_version=item.get("last_built_version"),
        )

    def save_draft(self, draft: DiscoveryDraft) -> DiscoveryDraft:
        client = self._require_client()
        doc = {
            "id": draft.id,
            "machine_name": draft.machine_name,
            "title": draft.title,
            "selected_entity_ids": list(draft.selected_entity_ids),
            "mode": draft.mode,
            "min_edge_count": draft.min_edge_count,
            "min_confidence": draft.min_confidence,
            "manual_edge_selection": [
                {"source_state": a, "destination_state": b}
                for (a, b) in draft.manual_edge_selection
            ],
            "created_at": draft.created_at.isoformat(),
            "updated_at": draft.updated_at.isoformat(),
            "last_built_version": draft.last_built_version,
        }
        payload = self._json(doc)
        client.set(self._key("draft", draft.id), payload)
        client.zadd(
            self._key("draft_index", draft.machine_name),
            {draft.id: draft.updated_at.timestamp()},
        )
        legacy = self._key("workspace", draft.id)
        if client.exists(legacy):
            client.delete(legacy)
            client.zrem(self._key("workspace_index", draft.machine_name), draft.id)
        return draft

    def get_draft(self, draft_id: str) -> DiscoveryDraft | None:
        client = self._require_client()
        nk = self._key("draft", draft_id)
        ok = self._key("workspace", draft_id)
        raw = client.get(nk)
        if not raw and client.exists(ok):
            raw = client.get(ok)
            if raw:
                client.rename(ok, nk)
                doc = json.loads(raw)
                mn = doc["machine_name"]
                ts = datetime.fromisoformat(doc["updated_at"]).timestamp()
                client.zrem(self._key("workspace_index", mn), draft_id)
                client.zadd(self._key("draft_index", mn), {draft_id: ts})
        if not raw:
            return None
        return self._draft_from_doc(json.loads(raw))

    def list_drafts(self, machine_name: str) -> list[DiscoveryDraft]:
        client = self._require_client()
        seen: set[str] = set()
        ids: list[str] = []
        for idx_key in (
            self._key("draft_index", machine_name),
            self._key("workspace_index", machine_name),
        ):
            for wid in client.zrevrange(idx_key, 0, -1):
                if wid not in seen:
                    seen.add(wid)
                    ids.append(wid)
        out: list[DiscoveryDraft] = []
        for wid in ids:
            d = self.get_draft(wid)
            if d is not None:
                out.append(d)
        return out

    def list_all_drafts(self) -> list[DiscoveryDraft]:
        """Return every draft across all channels, newest updated first.

        Note: scanning the Redis draft namespace is O(N); Redis is not
        the recommended backend for cross-channel instance listings.
        """
        client = self._require_client()
        pattern = self._key("draft", "*")
        drafts: list[DiscoveryDraft] = []
        for key in client.scan_iter(match=pattern):
            raw = client.get(key)
            if not raw:
                continue
            try:
                drafts.append(self._draft_from_doc(json.loads(raw)))
            except (json.JSONDecodeError, KeyError, ValueError):
                continue
        drafts.sort(key=lambda d: d.updated_at, reverse=True)
        return drafts

    def delete_draft(self, draft_id: str) -> bool:
        client = self._require_client()
        d = self.get_draft(draft_id)
        if d is None:
            raw = client.get(self._key("workspace", draft_id))
            if not raw:
                return False
            doc = json.loads(raw)
            mn = doc["machine_name"]
            client.delete(self._key("workspace", draft_id))
            client.zrem(self._key("workspace_index", mn), draft_id)
            return True
        client.delete(self._key("draft", draft_id))
        client.delete(self._key("workspace", draft_id))
        client.zrem(self._key("draft_index", d.machine_name), draft_id)
        client.zrem(self._key("workspace_index", d.machine_name), draft_id)
        return True
