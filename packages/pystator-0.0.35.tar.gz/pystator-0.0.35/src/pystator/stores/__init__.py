"""Pluggable state store adapters for PyStator.

State stores handle persistence of entity FSM state.  Implement the
``StateStore`` (sync) or ``AsyncStateStore`` (async) protocol for your
backend, or extend ``StateStoreClient`` for the shared connect/disconnect
lifecycle.

Available implementations:

- ``InMemoryStateStore``   -- in-memory store for testing / development
- ``SQLiteStateStore``     -- SQLite (requires ``sqlalchemy``)
- ``PostgresStateStore``   -- PostgreSQL (requires ``sqlalchemy``, ``psycopg2``)
- ``MongoDBStateStore``    -- MongoDB (requires ``pymongo``)
- ``RedisStateStore``      -- Redis (requires ``redis``)
- ``SessionStateStore``    -- existing SQLAlchemy session (API request scope; flush-only)
"""

from __future__ import annotations

from pystator.stores.base import (
    AsyncStateStore,
    AuditStore,
    BatchStateStore,
    EventStore,
    InMemoryStateStore,
    QueryableStateStore,
    StateStore,
    StateStoreClient,
    VersionedStateStore,
    batch_fallback,
)

# Import implementations with optional-dependency guards
# (mirrors pycharter's metadata_store/__init__.py pattern)

try:
    from pystator.stores.sqlite import SQLiteStateStore
except ImportError:
    SQLiteStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.postgres import PostgresStateStore
except ImportError:
    PostgresStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.mongodb import MongoDBStateStore
except ImportError:
    MongoDBStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.redis import RedisStateStore
except ImportError:
    RedisStateStore = None  # type: ignore[assignment,misc]

from pystator.stores.sqlalchemy_session import SessionStateStore

__all__ = [
    "AsyncStateStore",
    "AuditStore",
    "BatchStateStore",
    "EventStore",
    "InMemoryStateStore",
    "MongoDBStateStore",
    "PostgresStateStore",
    "QueryableStateStore",
    "RedisStateStore",
    "SessionStateStore",
    "SQLiteStateStore",
    "StateStore",
    "StateStoreClient",
    "VersionedStateStore",
    "batch_fallback",
]
