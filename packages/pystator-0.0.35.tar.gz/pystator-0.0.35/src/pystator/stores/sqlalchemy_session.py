"""Request-scoped SQLAlchemy :class:`~sqlalchemy.orm.Session` state store.

For FastAPI (or any caller that owns transaction boundaries): ``set_state`` /
``set_context`` call :meth:`~sqlalchemy.orm.Session.flush` only — no
:meth:`~sqlalchemy.orm.Session.commit`. The caller commits once at the end of
the request.

This mirrors the row-update logic of :class:`_SQLAlchemyStateStoreBase` in
``_sqlalchemy_base.py`` without coupling to ``StateStoreClient`` connect/disconnect.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from sqlalchemy.orm import Session

from pystator.db.models.entity_state import EntityStateModel


def _utc_now() -> datetime:
    return datetime.now(UTC)


class SessionStateStore:
    """Sync ``StateStore`` + ``set_context`` using an existing ORM session."""

    def __init__(self, session: Session) -> None:
        self._session = session

    def get_state(self, entity_id: str) -> str | None:
        row = (
            self._session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        return row.current_state if row else None

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        meta = metadata or {}
        row = (
            self._session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        if row is None:
            row = EntityStateModel(
                entity_id=entity_id,
                current_state=state,
                is_terminal=meta.get("is_terminal"),
                workflow_status=meta.get("workflow_status"),
                machine_name=meta.get("machine_name"),
                machine_version=meta.get("machine_version"),
                context_json=meta.get("context"),
            )
            self._session.add(row)
        else:
            row.current_state = state
            row.is_terminal = meta.get("is_terminal", row.is_terminal)
            if "workflow_status" in meta:
                row.workflow_status = meta.get("workflow_status")
            row.updated_at = _utc_now()
            row.version = (row.version or 1) + 1
            if "machine_name" in meta:
                row.machine_name = meta["machine_name"]
            if "machine_version" in meta:
                row.machine_version = meta["machine_version"]
            if "context" in meta:
                row.context_json = meta["context"]
        self._session.flush()

    def get_context(self, entity_id: str) -> dict[str, Any]:
        row = (
            self._session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        if row is None or row.context_json is None:
            return {}
        return dict(row.context_json)

    def set_context(self, entity_id: str, context: dict[str, Any]) -> None:
        row = (
            self._session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == entity_id)
            .first()
        )
        if row is None:
            raise ValueError(f"Entity not found: {entity_id!r}")
        row.context_json = context
        row.updated_at = _utc_now()
        self._session.flush()
