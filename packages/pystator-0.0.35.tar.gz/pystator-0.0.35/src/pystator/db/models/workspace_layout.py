"""Workspace diagram layout positions (stored separately from FSM config).

Positions are visual/presentation data and do not belong in the FSM
protocol config.  This mirrors the WorkspaceAnnotationModel pattern.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import Column, DateTime, Float, String, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


class WorkspaceLayoutModel(Base):
    """Per-state diagram position for the workspace editor.

    Positions are visual/presentation data and are stored
    separately from the FSM config (which is a pure protocol).
    This follows the same pattern as WorkspaceAnnotationModel.
    """

    __tablename__ = "workspace_layouts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    machine_name = Column(String(255), nullable=False, index=True)
    machine_version = Column(String(50), nullable=False, index=True)
    state_name = Column(String(255), nullable=False, index=True)

    position_x = Column(Float, nullable=False, default=0.0)
    position_y = Column(Float, nullable=False, default=0.0)

    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)
    created_by = Column(String(255), nullable=True)
    updated_by = Column(String(255), nullable=True)

    __table_args__ = (
        UniqueConstraint(
            "machine_name",
            "machine_version",
            "state_name",
            name="uq_workspace_layouts_machine_version_state",
        ),
        {"schema": "pystator"},
    )
