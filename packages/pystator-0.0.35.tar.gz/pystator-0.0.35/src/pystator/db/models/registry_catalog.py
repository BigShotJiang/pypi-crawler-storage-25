"""
SQLAlchemy model for persisted action/guard registry catalog (metadata + entry points).

Implementation code is not stored here — only ``module:callable`` strings resolved at runtime.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Index,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import UUID

from pystator.db.base import Base


def _utc_now() -> datetime:
    return datetime.now(UTC)


class RegistryCatalogModel(Base):
    """One row per named action or guard in the distributed catalog."""

    __tablename__ = "registry_catalog"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)

    kind = Column(String(20), nullable=False)  # "action" | "guard"
    name = Column(String(255), nullable=False)
    entry_point = Column(String(1024), nullable=False)
    description = Column(Text, nullable=True)
    params_schema = Column(JSON, nullable=True)
    enabled = Column(Boolean, nullable=False, default=True)
    version_label = Column(String(64), nullable=True)

    created_at = Column(DateTime(timezone=True), default=_utc_now)
    updated_at = Column(DateTime(timezone=True), default=_utc_now, onupdate=_utc_now)

    __table_args__ = (
        UniqueConstraint("kind", "name", name="uq_registry_catalog_kind_name"),
        Index("ix_registry_catalog_kind_enabled", "kind", "enabled"),
        {"schema": "pystator"},
    )
