"""Persisted action/guard registry catalog (metadata + entry points).

Revision ID: 20260413120000
Revises: 20260412120000
Create Date: 2026-04-13
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision: str = "20260413120000"
down_revision: str | None = "20260412120000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.create_table(
        "registry_catalog",
        sa.Column("id", UUID(as_uuid=True), nullable=False),
        sa.Column("kind", sa.String(20), nullable=False),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("entry_point", sa.String(1024), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("params_schema", sa.JSON(), nullable=True),
        sa.Column("enabled", sa.Boolean(), nullable=False, server_default=sa.text("1")),
        sa.Column("version_label", sa.String(64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("kind", "name", name="uq_registry_catalog_kind_name"),
        schema=schema_name,
    )
    op.create_index(
        "ix_registry_catalog_kind_enabled",
        "registry_catalog",
        ["kind", "enabled"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_registry_catalog_kind_enabled",
        table_name="registry_catalog",
        schema=schema_name,
    )
    op.drop_table("registry_catalog", schema=schema_name)
