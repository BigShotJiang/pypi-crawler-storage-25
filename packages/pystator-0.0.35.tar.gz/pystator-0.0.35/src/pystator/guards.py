"""Guard registry and evaluation for PyStator FSM.

Guards are pure functions that determine whether a transition should
be allowed. They receive a context dict and return a boolean.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import threading
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from pystator._types import GuardSpec, Transition
from pystator.errors import GuardExecutionError, GuardNotFoundError, GuardRejectedError

logger = logging.getLogger(__name__)

# Key used to inject guard parameters into context
GUARD_PARAMS_KEY = "_guard_params"


from pystator.shared.import_utils import import_dotted as _import_dotted

# ---------------------------------------------------------------------------
# Protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class GuardFunc(Protocol):
    """Synchronous guard function protocol."""

    def __call__(self, context: dict[str, Any]) -> bool: ...


@runtime_checkable
class AsyncGuardFunc(Protocol):
    """Asynchronous guard function protocol."""

    def __call__(self, context: dict[str, Any]) -> Awaitable[bool]: ...


AnyGuardFunc = (
    GuardFunc | AsyncGuardFunc | Callable[[dict[str, Any]], bool | Awaitable[bool]]
)


# ---------------------------------------------------------------------------
# GuardResult
# ---------------------------------------------------------------------------


@dataclass
class GuardResult:
    """Result of guard evaluation.

    Attributes:
        passed: Whether all guards passed.
        guard_name: Name of the last evaluated guard (if failed).
        message: Explanation of the result.
        evaluated_guards: List of (guard_name, passed) tuples.
    """

    passed: bool
    guard_name: str | None = None
    message: str = ""
    evaluated_guards: list[tuple[str, bool]] = field(default_factory=list)

    def __bool__(self) -> bool:
        """Return True if the guard passed."""
        return self.passed

    @classmethod
    def success(cls, evaluated: list[tuple[str, bool]] | None = None) -> GuardResult:
        """Create a passing guard result.

        Args:
            evaluated: Optional list of (guard_name, passed) tuples.

        Returns:
            GuardResult with ``passed=True``.
        """
        return cls(passed=True, evaluated_guards=evaluated or [])

    @classmethod
    def failure(
        cls,
        guard_name: str,
        message: str = "",
        evaluated: list[tuple[str, bool]] | None = None,
    ) -> GuardResult:
        """Create a failing guard result with reason.

        Args:
            guard_name: Name of the guard that failed.
            message: Human-readable failure reason.
            evaluated: Optional list of (guard_name, passed) tuples.

        Returns:
            GuardResult with ``passed=False``.
        """
        return cls(
            passed=False,
            guard_name=guard_name,
            message=message or f"Guard '{guard_name}' rejected transition",
            evaluated_guards=evaluated or [],
        )


# ---------------------------------------------------------------------------
# Inline expression evaluation (delegates to shared _expr module)
# ---------------------------------------------------------------------------


def _eval_expression(expr: str, context: dict[str, Any]) -> bool:
    """Evaluate a boolean expression with context as namespace."""
    from pystator._expr import evaluate_bool_expr

    return evaluate_bool_expr(expr, context)


# ---------------------------------------------------------------------------
# GuardRegistry
# ---------------------------------------------------------------------------


class GuardRegistry:
    """Registry and evaluator for guard functions (sync and async).

    Handles both registration of guard callables and evaluation of
    guard specs on transitions (named, expression, check, composite).

    Example:
        >>> registry = GuardRegistry()
        >>> registry.register("is_valid", lambda ctx: ctx.get("valid", False))
        >>> registry.evaluate("is_valid", {"valid": True})
        True
    """

    def __init__(self, *, strict: bool = True) -> None:
        self._guards: dict[str, AnyGuardFunc] = {}
        self._async_guards: set[str] = set()
        self._accepts_kwargs: set[str] = set()
        self._lock = threading.Lock()
        self.strict = strict

    def register(self, name: str, func: AnyGuardFunc) -> None:
        """Register a guard function. Thread-safe.

        Re-registration replaces the existing guard (allows overriding builtins).
        If the function accepts keyword arguments beyond ``ctx``, parameters
        from the guard spec are passed as ``**kwargs`` instead of injected
        into the context dict.
        """
        if not name:
            raise ValueError("Guard name cannot be empty")
        with self._lock:
            self._guards[name] = func
            if asyncio.iscoroutinefunction(func) or (
                callable(func)
                and asyncio.iscoroutinefunction(getattr(func, "__call__", None))  # noqa: B004
            ):
                self._async_guards.add(name)
            else:
                self._async_guards.discard(name)
            # Introspect: does the function accept extra keyword args?
            try:
                sig = inspect.signature(func)
                has_extra = any(
                    p.kind
                    in (inspect.Parameter.KEYWORD_ONLY, inspect.Parameter.VAR_KEYWORD)
                    for p in sig.parameters.values()
                )
                if has_extra:
                    self._accepts_kwargs.add(name)
                else:
                    self._accepts_kwargs.discard(name)
            except (ValueError, TypeError):
                self._accepts_kwargs.discard(name)

    def unregister(self, name: str) -> None:
        """Unregister a guard function. Thread-safe."""
        with self._lock:
            if name not in self._guards:
                raise GuardNotFoundError(f"Guard '{name}' not found", guard_name=name)
            del self._guards[name]
            self._async_guards.discard(name)

    def get(self, name: str) -> AnyGuardFunc:
        """Look up a registered guard callable by name.

        Args:
            name: The registered guard name.

        Returns:
            The guard callable.

        Raises:
            GuardNotFoundError: If no guard is registered under *name*.
        """
        if name not in self._guards:
            raise GuardNotFoundError(f"Guard '{name}' not found", guard_name=name)
        return self._guards[name]

    def has(self, name: str) -> bool:
        """Check whether a guard is registered."""
        return name in self._guards

    def is_async(self, name: str) -> bool:
        """Return True if the named guard is an async function."""
        return name in self._async_guards

    def evaluate(self, name: str, context: dict[str, Any]) -> bool:
        """Evaluate a single guard synchronously."""
        return self.get(name)(context)  # type: ignore[return-value]

    def evaluate_all(
        self,
        guards: tuple[str, ...] | list[str],
        context: dict[str, Any],
        fail_fast: bool = True,
    ) -> GuardResult:
        """Evaluate multiple guards. Returns GuardResult."""
        if not guards:
            return GuardResult.success()
        evaluated: list[tuple[str, bool]] = []
        for name in guards:
            result = self.evaluate(name, context)
            evaluated.append((name, result))
            if not result and fail_fast:
                return GuardResult.failure(name, evaluated=evaluated)
        for name, passed in evaluated:
            if not passed:
                return GuardResult.failure(name, evaluated=evaluated)
        return GuardResult.success(evaluated)

    async def async_evaluate(self, name: str, context: dict[str, Any]) -> bool:
        """Evaluate a single guard asynchronously.

        Falls back to synchronous execution if the guard is not async.

        Args:
            name: Registered guard name.
            context: Context dict passed to the guard callable.

        Returns:
            True if the guard passed, False otherwise.
        """
        func = self.get(name)
        if self.is_async(name):
            return await func(context)  # type: ignore[misc]
        return func(context)  # type: ignore[return-value]

    async def async_evaluate_all(
        self,
        guards: tuple[GuardSpec, ...] | tuple[str, ...] | list[str],
        context: dict[str, Any],
        fail_fast: bool = True,
    ) -> GuardResult:
        """Evaluate multiple guards asynchronously.

        Args:
            guards: Guard specs or names to evaluate.
            context: Context dict passed to each guard.
            fail_fast: If True, stop on first failing guard.

        Returns:
            GuardResult summarising all evaluations.
        """
        if not guards:
            return GuardResult.success()
        evaluated: list[tuple[str, bool]] = []
        for guard in guards:
            name = guard.name if isinstance(guard, GuardSpec) else guard
            if name is None:
                continue
            eval_ctx = context
            if isinstance(guard, GuardSpec) and guard.has_params:
                eval_ctx = {**context, GUARD_PARAMS_KEY: guard.params}
            result = await self.async_evaluate(name, eval_ctx)
            evaluated.append((name, result))
            if not result and fail_fast:
                return GuardResult.failure(name, evaluated=evaluated)
        for name, passed in evaluated:
            if not passed:
                return GuardResult.failure(name, evaluated=evaluated)
        return GuardResult.success(evaluated)

    def list_guards(self) -> list[str]:
        """Return all registered guard names."""
        return list(self._guards.keys())

    def clear(self) -> None:
        """Remove all registered guards."""
        self._guards.clear()
        self._async_guards.clear()

    def __len__(self) -> int:
        """Return the number of registered guards."""
        return len(self._guards)

    def __contains__(self, name: str) -> bool:
        """Check whether a guard name is registered."""
        return name in self._guards

    # -- Transition-level evaluation (merged from GuardEvaluator) -----

    def can_transition(
        self,
        transition: Transition,
        context: dict[str, Any],
    ) -> GuardResult:
        """Check if a transition is allowed based on its guards.

        Args:
            transition: The transition whose guards to evaluate.
            context: Context dict passed to each guard.

        Returns:
            GuardResult indicating pass/fail with evaluation details.
        """
        if not transition.guards:
            return GuardResult.success()
        return self._evaluate_guards(transition.guards, context)

    async def async_can_transition(
        self,
        transition: Transition,
        context: dict[str, Any],
    ) -> GuardResult:
        """Async version of :meth:`can_transition`.

        Falls back to sync evaluation for non-async guards.
        """
        if not transition.guards:
            return GuardResult.success()
        # For async path, delegate to async_evaluate_all with GuardSpec objects
        return await self.async_evaluate_all(transition.guards, context, fail_fast=True)

    def evaluate_and_raise(
        self,
        transition: Transition,
        current_state: str,
        context: dict[str, Any],
    ) -> None:
        """Evaluate guards and raise GuardRejectedError if blocked."""
        result = self.can_transition(transition, context)
        if not result.passed:
            raise GuardRejectedError(
                message=result.message,
                current_state=current_state,
                trigger=transition.trigger,
                guard_name=result.guard_name or "unknown",
                guard_result=result.evaluated_guards,
            )

    def get_required_guards(
        self,
        transitions: list[Transition] | tuple[Transition, ...],
    ) -> set[str]:
        """Return named guard names required by the given transitions.

        Recurses into composite guards (allOf, anyOf, not).
        Excludes inline expression guards.
        """
        names: set[str] = set()
        for trans in transitions:
            for guard in trans.guards:
                _collect_guard_names(guard, names)
        return names

    # -- Internal evaluation helpers ------------------------------------------

    def _evaluate_guards(
        self,
        guards: tuple[GuardSpec, ...],
        context: dict[str, Any],
    ) -> GuardResult:
        """Evaluate a tuple of guard specs (fail-fast)."""
        evaluated: list[tuple[str, bool]] = []
        for guard in guards:
            guard_id, result = self._evaluate_single_guard(guard, context, evaluated)
            if not result:
                return GuardResult.failure(str(guard_id), evaluated=evaluated)
        return GuardResult.success(evaluated)

    def _evaluate_single_guard(
        self,
        guard: GuardSpec,
        context: dict[str, Any],
        evaluated: list[tuple[str, bool]],
    ) -> tuple[str, bool]:
        """Evaluate a single guard spec, recursing into composites."""
        try:
            if guard.is_all_of:
                return self._evaluate_all_of(guard, context, evaluated)
            if guard.is_any_of:
                return self._evaluate_any_of(guard, context, evaluated)
            if guard.is_negate:
                return self._evaluate_negate(guard, context, evaluated)
            return self._evaluate_leaf_guard(guard, context, evaluated)
        except (GuardNotFoundError, GuardExecutionError):
            raise
        except (OSError, ConnectionError, TimeoutError) as exc:
            guard_id = str(guard.expr or guard.name or "composite")
            logger.error("Guard '%s' raised transient error: %s", guard_id, exc)
            raise GuardExecutionError(
                f"Guard '{guard_id}' failed with transient error",
                guard_name=guard_id,
                original_error=exc,
            ) from exc
        except Exception as exc:
            guard_id = str(guard.expr or guard.name or "composite")
            logger.warning("Guard '%s' raised unexpected error: %s", guard_id, exc)
            evaluated.append((guard_id, False))
            return guard_id, False

    def _evaluate_leaf_guard(
        self,
        guard: GuardSpec,
        context: dict[str, Any],
        evaluated: list[tuple[str, bool]],
    ) -> tuple[str, bool]:
        """Evaluate a non-composite guard (name, expr, or check)."""
        guard_id = guard.expr if guard.is_expression else guard.name
        if guard.is_check:
            from pystator.checks import evaluate_check

            check = guard.check  # type: ignore[union-attr]
            guard_id = f"check:{check.field} {check.op}"
            result = evaluate_check(check, context)
            evaluated.append((guard_id, result))
        elif guard.is_expression:
            result = _eval_expression(guard.expr, context)  # type: ignore[arg-type]
            guard_id = f"expr:{guard.expr}"
            evaluated.append((guard_id, result))
        else:
            guard_name = guard.name  # type: ignore[assignment]
            guard_id = guard_name
            if not self.has(guard_name):
                # Auto-resolve dotted paths (e.g. "my_app.guards.is_valid")
                if "." in guard_name:
                    func = _import_dotted(guard_name)
                    if func is not None:
                        self.register(guard_name, func)
                    else:
                        if self.strict:
                            raise GuardNotFoundError(
                                f"Guard '{guard_name}' could not be imported",
                                guard_name=guard_name,
                            )
                        evaluated.append((guard_name, True))
                        return guard_name, True
                elif self.strict:
                    raise GuardNotFoundError(
                        f"Guard '{guard_name}' not registered",
                        guard_name=guard_name,
                    )
                else:
                    evaluated.append((guard_name, True))
                    return guard_name, True
            params = guard.params if guard.has_params else {}
            if params and guard_name in self._accepts_kwargs:
                # Pass params as explicit keyword arguments
                func = self.get(guard_name)
                result = func(context, **params)  # type: ignore[call-arg]
            elif params:
                # Legacy: inject params into context for old-style guards
                eval_ctx = {**context, GUARD_PARAMS_KEY: params}
                result = self.evaluate(guard_name, eval_ctx)
            else:
                result = self.evaluate(guard_name, context)
            evaluated.append((guard_name, result))
        return str(guard_id), result

    def _evaluate_all_of(
        self,
        guard: GuardSpec,
        context: dict[str, Any],
        evaluated: list[tuple[str, bool]],
    ) -> tuple[str, bool]:
        """Evaluate allOf: all children must pass."""
        for child in guard.all_of:
            _, passed = self._evaluate_single_guard(child, context, evaluated)
            if not passed:
                evaluated.append(("allOf", False))
                return "allOf", False
        evaluated.append(("allOf", True))
        return "allOf", True

    def _evaluate_any_of(
        self,
        guard: GuardSpec,
        context: dict[str, Any],
        evaluated: list[tuple[str, bool]],
    ) -> tuple[str, bool]:
        """Evaluate anyOf: at least one child must pass."""
        for child in guard.any_of:
            _, passed = self._evaluate_single_guard(child, context, evaluated)
            if passed:
                evaluated.append(("anyOf", True))
                return "anyOf", True
        evaluated.append(("anyOf", False))
        return "anyOf", False

    def _evaluate_negate(
        self,
        guard: GuardSpec,
        context: dict[str, Any],
        evaluated: list[tuple[str, bool]],
    ) -> tuple[str, bool]:
        """Evaluate not: child must fail."""
        child = guard.negate  # type: ignore[assignment]
        _, passed = self._evaluate_single_guard(child, context, evaluated)
        result = not passed
        evaluated.append(("not", result))
        return "not", result

    # -- Decorator -----------------------------------------------------------

    def decorator(
        self, name: str | None = None
    ) -> Callable[[AnyGuardFunc], AnyGuardFunc]:
        """Decorator to register a guard function.

        Example:
            >>> @registry.decorator()
            ... def is_valid(ctx: dict) -> bool:
            ...     return ctx.get("valid", False)
        """

        def inner(func: AnyGuardFunc) -> AnyGuardFunc:
            self.register(name or func.__name__, func)
            return func

        return inner


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _collect_guard_names(guard: GuardSpec, names: set[str]) -> None:
    """Recursively collect named guard names from a guard spec."""
    if guard.name is not None:
        names.add(guard.name)
    for child in guard.all_of:
        _collect_guard_names(child, names)
    for child in guard.any_of:
        _collect_guard_names(child, names)
    if guard.negate is not None:
        _collect_guard_names(guard.negate, names)


# ---------------------------------------------------------------------------
# Guard factories (Python-side convenience)
#
# These overlap with declarative checks (CheckSpec) which can do the same
# comparisons in YAML without any Python:
#
#   guards:
#     - check: { field: status, op: eq, value: ACTIVE }   # YAML-only
#
# Use declarative checks when the guard is a simple field comparison
# expressible in config. Use these factories when composing guards in
# Python code (e.g. all_of, negate) or when registered dynamically.
# ---------------------------------------------------------------------------


def equals(key: str, value: Any) -> Callable[[dict[str, Any]], bool]:
    """Guard factory: context[key] == value."""

    def guard(ctx: dict[str, Any]) -> bool:
        return ctx.get(key) == value

    return guard


def greater_than(key: str, value: Any) -> Callable[[dict[str, Any]], bool]:
    """Guard factory: context[key] > value."""

    def guard(ctx: dict[str, Any]) -> bool:
        v = ctx.get(key)
        if v is None:
            return False
        try:
            return v > value
        except TypeError:
            return False

    return guard


def in_list(key: str, values: list[Any]) -> Callable[[dict[str, Any]], bool]:
    """Guard factory: context[key] in values."""

    def guard(ctx: dict[str, Any]) -> bool:
        return ctx.get(key) in values

    return guard


def all_of(
    *guards: Callable[[dict[str, Any]], bool],
) -> Callable[[dict[str, Any]], bool]:
    """Compound guard: all must pass."""

    def guard(ctx: dict[str, Any]) -> bool:
        return all(g(ctx) for g in guards)

    return guard


def any_of(
    *guards: Callable[[dict[str, Any]], bool],
) -> Callable[[dict[str, Any]], bool]:
    """Compound guard: at least one must pass."""

    def guard(ctx: dict[str, Any]) -> bool:
        return any(g(ctx) for g in guards)

    return guard


def negate(
    guard_fn: Callable[[dict[str, Any]], bool],
) -> Callable[[dict[str, Any]], bool]:
    """Guard that negates the result of another guard."""

    def guard(ctx: dict[str, Any]) -> bool:
        return not guard_fn(ctx)

    return guard
