"""Execution namespace for inline ``code:`` actions when imports are enabled.

Provides restricted ``__builtins__``, allowlisted ``__import__``, and pre-bound
modules. Not a security sandbox — opt-in only via config (see ``config.features``).
"""

from __future__ import annotations

import builtins as _real_builtins
import types
from collections.abc import Sequence
from typing import Any

# Top-level package names permitted via ``import`` / ``from … import`` in user code.
_ALLOWLISTED_IMPORT_ROOTS: frozenset[str] = frozenset(
    {
        "json",
        "requests",
        "numpy",
        "math",
        "re",
        "datetime",
        "decimal",
        "copy",
        "itertools",
        "functools",
        "typing",
        "collections",
        "uuid",
        "enum",
        "operator",
        "statistics",
        "string",
    }
)

_SAFE_BUILTIN_NAMES: tuple[str, ...] = (
    "abs",
    "all",
    "any",
    "bin",
    "bool",
    "bytes",
    "bytearray",
    "callable",
    "chr",
    "classmethod",
    "complex",
    "dict",
    "divmod",
    "enumerate",
    "filter",
    "float",
    "format",
    "frozenset",
    "getattr",
    "hasattr",
    "hash",
    "hex",
    "int",
    "isinstance",
    "issubclass",
    "iter",
    "len",
    "list",
    "map",
    "max",
    "min",
    "next",
    "object",
    "oct",
    "ord",
    "pow",
    "property",
    "range",
    "repr",
    "reversed",
    "round",
    "set",
    "slice",
    "sorted",
    "staticmethod",
    "str",
    "sum",
    "tuple",
    "type",
    "zip",
    "None",
    "True",
    "False",
    "Ellipsis",
    "BaseException",
    "Exception",
    "ArithmeticError",
    "ZeroDivisionError",
    "ValueError",
    "TypeError",
    "KeyError",
    "IndexError",
    "AttributeError",
    "RuntimeError",
    "StopIteration",
    "NotImplementedError",
    "OSError",
    "IOError",
    "ImportError",
    "ModuleNotFoundError",
)

_builtin_import = _real_builtins.__import__


def _restricted_import(
    name: str,
    globals: dict[str, Any] | None = None,
    locals: dict[str, Any] | None = None,
    fromlist: Sequence[str] = (),
    level: int = 0,
) -> Any:
    if level != 0:
        raise ImportError(
            "relative imports are not allowed in inline code actions",
        )
    root = name.partition(".")[0]
    if root not in _ALLOWLISTED_IMPORT_ROOTS:
        raise ImportError(
            f"module {name!r} is not allowlisted for inline code actions",
        )
    return _builtin_import(name, globals, locals, fromlist, level)


def _restricted_builtins_dict() -> dict[str, Any]:
    out: dict[str, Any] = {}
    for n in _SAFE_BUILTIN_NAMES:
        if hasattr(_real_builtins, n):
            out[n] = getattr(_real_builtins, n)
    out["__import__"] = _restricted_import
    return out


def build_imports_enabled_namespace(context: dict[str, Any]) -> dict[str, Any]:
    """Namespace for ``exec`` when ``PYSTATOR_ALLOW_INLINE_CODE_IMPORTS`` is on."""
    ns: dict[str, Any] = {
        "ctx": context,
        "__builtins__": _restricted_builtins_dict(),
    }

    import json as _json

    ns["json"] = _json

    try:
        import requests as _requests

        ns["requests"] = _requests
    except ImportError:
        pass

    try:
        import numpy as _np

        ns["numpy"] = _np
        ns["np"] = _np
    except ImportError:
        pass

    try:
        import yaml as _yaml

        ns["yaml"] = types.SimpleNamespace(
            safe_load=_yaml.safe_load,
            safe_dump=_yaml.safe_dump,
        )
    except ImportError:
        pass

    return ns
