'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { useDiscoveryConfig } from '@/hooks'
import type { DiscoveryDatabaseTestRequest } from '@/lib/api'
import { cn } from '@/lib/utils'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface DiscoveryConfigCardProps {
  backend: 'memory' | 'sqlite' | 'postgresql' | 'mongodb' | 'redis'
  connectionString: string
  shadowEnabled: boolean
  minEdgeCount: string
  minConfidence: string
  driftAlertThreshold: string
  driftSevereThreshold: string
  driftMinSample: string
  lowSampleThreshold: string
  onBackendChange: (v: DiscoveryConfigCardProps['backend']) => void
  onConnectionStringChange: (v: string) => void
  onShadowEnabledChange: (v: boolean) => void
  onMinEdgeCountChange: (v: string) => void
  onMinConfidenceChange: (v: string) => void
  onDriftAlertThresholdChange: (v: string) => void
  onDriftSevereThresholdChange: (v: string) => void
  onDriftMinSampleChange: (v: string) => void
  onLowSampleThresholdChange: (v: string) => void
  compact?: boolean
}

export function DiscoveryConfigCard({
  backend,
  connectionString,
  shadowEnabled,
  minEdgeCount,
  minConfidence,
  driftAlertThreshold,
  driftSevereThreshold,
  driftMinSample,
  lowSampleThreshold,
  onBackendChange,
  onConnectionStringChange,
  onShadowEnabledChange,
  onMinEdgeCountChange,
  onMinConfidenceChange,
  onDriftAlertThresholdChange,
  onDriftSevereThresholdChange,
  onDriftMinSampleChange,
  onLowSampleThresholdChange,
  compact,
}: DiscoveryConfigCardProps) {
  const { config, testing, testResult, test } = useDiscoveryConfig()

  const handleTest = () => {
    const body: DiscoveryDatabaseTestRequest = {
      backend,
      connection_string: connectionString || undefined,
    }
    test(body)
  }

  return (
    <Card id="discovery" className="scroll-mt-28">
      <CardHeader className={cn(compact && 'space-y-1 p-4 pb-2')}>
        <CardTitle className={cn(compact && 'text-base')}>Discovery</CardTitle>
        <CardDescription className={cn(compact && 'text-xs leading-snug')}>
          Client defaults for discovery tools; server uses <code className="text-[11px]">[discovery]</code>{' '}
          keys (see overview). Test uses the values below.
        </CardDescription>
      </CardHeader>
      <CardContent className={cn('space-y-3', compact && 'p-4 pt-0')}>
        {config && (
          <div
            className={cn(
              'rounded-md bg-muted/50 text-muted-foreground',
              compact ? 'px-2 py-1.5 text-xs' : 'px-3 py-2 text-sm',
            )}
          >
            Server: {config.backend} · shadow {config.shadow_enabled ? 'on' : 'off'} · edges ≥
            {config.min_edge_count} · conf {config.min_confidence} · drift{' '}
            {(config.drift_alert_threshold * 100).toFixed(0)}%/
            {(config.drift_severe_threshold * 100).toFixed(0)}%
          </div>
        )}

        <div className={cn('space-y-2', compact && 'space-y-1')}>
          <Label htmlFor="discovery-backend" className={cn(compact && 'text-xs')}>
            Backend
          </Label>
          <select
            id="discovery-backend"
            className={cn(
              'w-full rounded-md border border-input bg-background px-2 text-sm',
              compact ? 'h-8' : 'h-10 px-3',
            )}
            value={backend}
            onChange={(e) => onBackendChange(e.target.value as DiscoveryConfigCardProps['backend'])}
          >
            <option value="memory">memory</option>
            <option value="sqlite">sqlite</option>
            <option value="postgresql">postgresql</option>
            <option value="mongodb">mongodb</option>
            <option value="redis">redis</option>
          </select>
        </div>

        <div className={cn('space-y-2', compact && 'space-y-1')}>
          <Label htmlFor="discovery-connection-string" className={cn(compact && 'text-xs')}>
            Connection string (non-memory)
          </Label>
          <Input
            id="discovery-connection-string"
            type="text"
            className={cn(compact && 'h-8 text-sm')}
            value={connectionString}
            onChange={(e) => onConnectionStringChange(e.target.value)}
            placeholder="sqlite:///pystator_discovery.db"
          />
        </div>

        <div
          className={cn(
            'grid gap-3',
            compact ? 'grid-cols-2 sm:grid-cols-3' : 'grid-cols-2 gap-4',
          )}
        >
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="discovery-min-edge-count" className={cn(compact && 'text-xs')}>
              Min edges
            </Label>
            <Input
              id="discovery-min-edge-count"
              type="number"
              min={1}
              className={cn(compact && 'h-8 text-sm')}
              value={minEdgeCount}
              onChange={(e) => onMinEdgeCountChange(e.target.value)}
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="discovery-min-confidence" className={cn(compact && 'text-xs')}>
              Min conf.
            </Label>
            <Input
              id="discovery-min-confidence"
              type="number"
              min={0}
              max={1}
              step={0.01}
              className={cn(compact && 'h-8 text-sm')}
              value={minConfidence}
              onChange={(e) => onMinConfidenceChange(e.target.value)}
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="discovery-drift-alert-threshold" className={cn(compact && 'text-xs')}>
              Drift alert
            </Label>
            <Input
              id="discovery-drift-alert-threshold"
              type="number"
              min={0}
              max={1}
              step={0.01}
              className={cn(compact && 'h-8 text-sm')}
              value={driftAlertThreshold}
              onChange={(e) => onDriftAlertThresholdChange(e.target.value)}
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="discovery-drift-severe-threshold" className={cn(compact && 'text-xs')}>
              Drift severe
            </Label>
            <Input
              id="discovery-drift-severe-threshold"
              type="number"
              min={0}
              max={1}
              step={0.01}
              className={cn(compact && 'h-8 text-sm')}
              value={driftSevereThreshold}
              onChange={(e) => onDriftSevereThresholdChange(e.target.value)}
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="discovery-drift-min-sample" className={cn(compact && 'text-xs')}>
              Drift min n
            </Label>
            <Input
              id="discovery-drift-min-sample"
              type="number"
              min={1}
              className={cn(compact && 'h-8 text-sm')}
              value={driftMinSample}
              onChange={(e) => onDriftMinSampleChange(e.target.value)}
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="discovery-low-sample-threshold" className={cn(compact && 'text-xs')}>
              Low-sample n
            </Label>
            <Input
              id="discovery-low-sample-threshold"
              type="number"
              min={1}
              className={cn(compact && 'h-8 text-sm')}
              value={lowSampleThreshold}
              onChange={(e) => onLowSampleThresholdChange(e.target.value)}
            />
          </div>
        </div>

        <div
          className={cn(
            'flex items-center justify-between rounded-md border',
            compact ? 'px-2 py-1.5' : 'px-3 py-2',
          )}
        >
          <div>
            <p className={cn('font-medium', compact ? 'text-xs' : 'text-sm')}>Shadow mode</p>
            <p className="text-xs text-muted-foreground leading-snug">
              Shadow-compare candidates without enforcing in runtime.
            </p>
          </div>
          <Switch checked={shadowEnabled} onCheckedChange={onShadowEnabledChange} />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size={compact ? 'sm' : 'default'}
            onClick={handleTest}
            disabled={testing}
          >
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test discovery backend'
            )}
          </Button>
          {testResult && (
            <span className={cn('inline-flex items-center gap-1', compact ? 'text-xs' : 'text-sm')}>
              {testResult.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {testResult.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
