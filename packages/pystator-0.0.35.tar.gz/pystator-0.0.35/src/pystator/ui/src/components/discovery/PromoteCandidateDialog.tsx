'use client'

import { useEffect, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Loader2 } from 'lucide-react'

type PublishMode = 'new' | 'existing'

interface PromoteCandidateDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** The candidate's stored machine_name (home channel). */
  machineName: string
  version: string | null
  loading: boolean
  /**
   * Confirm handler. When ``targetMachineName`` is ``null`` the caller
   * should promote under ``machineName`` (backcompat). When set, the
   * caller should promote with the override.
   */
  onConfirm: (targetMachineName: string | null) => void
  /** Existing catalog machine names for the "publish as new version" picker. */
  catalogNames?: string[]
  /** When true, show catalog baseline comparison (fleet / three-column flow). */
  showCatalogImpact?: boolean
  /** Short line describing catalog vs candidate delta; null means no catalog baseline. */
  impactSummary?: string | null
  /** e.g. "Machines catalog · v1.0.0" */
  impactBaselineLabel?: string | null
  impactLoading?: boolean
}

export function PromoteCandidateDialog({
  open,
  onOpenChange,
  machineName,
  version,
  loading,
  onConfirm,
  catalogNames = [],
  showCatalogImpact = false,
  impactSummary,
  impactBaselineLabel,
  impactLoading,
}: PromoteCandidateDialogProps) {
  const [mode, setMode] = useState<PublishMode>('new')
  const [newName, setNewName] = useState<string>('')
  const [existingName, setExistingName] = useState<string>('')

  useEffect(() => {
    if (open) {
      setMode('new')
      setNewName(machineName)
      setExistingName(catalogNames[0] ?? '')
    }
  }, [open, machineName, catalogNames])

  const chosenTarget =
    mode === 'new' ? newName.trim() : existingName.trim()
  const canConfirm = Boolean(version) && Boolean(chosenTarget) && !loading

  const handleConfirm = () => {
    if (!canConfirm) return
    // When the chosen target matches the candidate's stored name we send
    // ``null`` — which the backend treats as "use candidate.machine_name"
    // and which preserves back-compat for callers with no override.
    const target = chosenTarget === machineName ? null : chosenTarget
    onConfirm(target)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" showClose>
        <DialogHeader>
          <DialogTitle>Publish candidate</DialogTitle>
          <DialogDescription>
            Save the inferred config to the Machines catalog as version{' '}
            <span className="font-mono">{version || '—'}</span>. You can
            publish under the candidate's own name or as a new version of
            an existing catalog machine.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-2">
          <div className="space-y-2 rounded-md border border-border/60 p-3">
            <label className="flex items-start gap-2 text-sm">
              <input
                type="radio"
                name="promote-mode"
                value="new"
                checked={mode === 'new'}
                onChange={() => setMode('new')}
                className="mt-1"
              />
              <span className="flex-1">
                <span className="block font-medium">
                  Publish as new state machine
                </span>
                <span className="block text-xs text-muted-foreground">
                  Type a catalog name. A new machine is created, or a new
                  version of an existing one if the name matches.
                </span>
              </span>
            </label>
            {mode === 'new' ? (
              <div className="ml-6 space-y-1">
                <Label htmlFor="promote-new-name" className="text-xs">
                  Target catalog name
                </Label>
                <Input
                  id="promote-new-name"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder={machineName}
                />
              </div>
            ) : null}
          </div>

          <div className="space-y-2 rounded-md border border-border/60 p-3">
            <label className="flex items-start gap-2 text-sm">
              <input
                type="radio"
                name="promote-mode"
                value="existing"
                checked={mode === 'existing'}
                disabled={catalogNames.length === 0}
                onChange={() => setMode('existing')}
                className="mt-1"
              />
              <span className="flex-1">
                <span className="block font-medium">
                  Publish as new version of…
                </span>
                <span className="block text-xs text-muted-foreground">
                  {catalogNames.length === 0
                    ? 'No catalog machines available.'
                    : 'Pick an existing catalog machine to version.'}
                </span>
              </span>
            </label>
            {mode === 'existing' ? (
              <div className="ml-6 space-y-1">
                <Label htmlFor="promote-existing-name" className="text-xs">
                  Existing catalog machine
                </Label>
                <select
                  id="promote-existing-name"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
                  value={existingName}
                  onChange={(e) => setExistingName(e.target.value)}
                  disabled={catalogNames.length === 0}
                >
                  <option value="">Select…</option>
                  {catalogNames.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
          </div>
        </div>

        {showCatalogImpact && (
          <div className="rounded-md border border-border bg-muted/30 px-3 py-2 text-sm">
            <p className="text-xs font-medium text-muted-foreground">
              Impact vs catalog
            </p>
            {impactLoading ? (
              <p className="mt-1 text-muted-foreground">Loading baseline…</p>
            ) : impactSummary ? (
              <>
                {impactBaselineLabel ? (
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {impactBaselineLabel}
                  </p>
                ) : null}
                <p className="mt-1 text-foreground">{impactSummary}</p>
              </>
            ) : (
              <p className="mt-1 text-muted-foreground">
                No matching machine in the catalog — promotion will create
                or replace the catalog entry for this name.
              </p>
            )}
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button type="button" onClick={handleConfirm} disabled={!canConfirm}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Publishing…
              </>
            ) : (
              'Publish'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
