'use client'

import dynamic from 'next/dynamic'
import { Label } from '@/components/ui/label'
import { useMonacoTheme } from '@/hooks/useMonacoTheme'
import type { editor } from 'monaco-editor'

const MonacoEditor = dynamic(
  async () => (await import('@monaco-editor/react')).default,
  {
    ssr: false,
    loading: () => (
      <div
        className="flex min-h-[280px] items-center justify-center rounded-md border border-input bg-muted/40 text-xs text-muted-foreground"
        aria-hidden
      >
        Loading editor…
      </div>
    ),
  },
)

export interface FsmCodeActionEditorProps {
  value: string
  onChange: (source: string) => void
  /** Optional stable id for accessibility (e.g. action row index). */
  editorId?: string
}

const MONACO_OPTIONS: editor.IStandaloneEditorConstructionOptions = {
  minimap: { enabled: false },
  fontSize: 13,
  lineHeight: 20,
  scrollBeyondLastLine: false,
  wordWrap: 'on',
  tabSize: 4,
  insertSpaces: true,
  lineNumbers: 'on',
  glyphMargin: false,
  folding: true,
  automaticLayout: true,
  padding: { top: 8, bottom: 8 },
  scrollbar: { verticalScrollbarSize: 8, horizontalScrollbarSize: 8 },
  renderLineHighlight: 'line',
  overviewRulerLanes: 0,
  hideCursorInOverviewRuler: true,
}

/**
 * Python source editor for FSM `code:` actions — Monaco for highlighting, line numbers, and indentation.
 */
export function FsmCodeActionEditor({ value, onChange, editorId }: FsmCodeActionEditorProps) {
  const theme = useMonacoTheme()

  return (
    <div className="space-y-1.5">
      <div className="flex flex-col gap-0.5">
        <Label className="text-xs font-medium text-foreground">Python</Label>
        <p className="text-[11px] leading-snug text-muted-foreground">
          Runs on the server with a mutable <code className="rounded bg-muted px-0.5">ctx</code> dict
          (same as transition context). Write top-level statements; avoid pasting indented blocks from
          inside another function unless you dedent them.
        </p>
      </div>
      <div
        id={editorId}
        className="overflow-hidden rounded-md border border-input bg-background"
        style={{ minHeight: 280 }}
      >
        <MonacoEditor
          height="280px"
          language="python"
          theme={theme}
          value={value}
          onChange={(v) => onChange(v ?? '')}
          options={MONACO_OPTIONS}
        />
      </div>
    </div>
  )
}
