'use client'

import { useMemo, useState } from 'react'
import { Group, Panel, Separator } from 'react-resizable-panels'
import { Button } from '@/components/ui/button'
import { Plus } from 'lucide-react'
import { PromoteCandidateDialog } from '@/components/discovery/PromoteCandidateDialog'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { useDiscoveryConfig } from '@/hooks/useDiscoveryConfig'
import { DiscoveryStatusBanner } from '@/components/discovery/DiscoveryStatusBanner'
import { DiscoveryBackendSummaryCard } from '@/components/discovery/DiscoveryBackendSummaryCard'
import { DiscoveryMachineSelectorCard } from '@/components/discovery/DiscoveryMachineSelectorCard'
import { DiscoveryObservationCard } from '@/components/discovery/DiscoveryObservationCard'
import { DiscoveryCandidatesTable } from '@/components/discovery/DiscoveryCandidatesTable'
import { DiscoveryRecipeWorkspacePanel } from '@/components/discovery/DiscoveryRecipeWorkspacePanel'
import {
  DiscoveryShadowDiffCard,
  DiscoveryShadowDiffTable,
  type DiscoveryShadowFilter,
} from '@/components/discovery/DiscoveryShadowDiffCard'
import { DiscoveryDiffSummaryCard } from '@/components/discovery/DiscoveryDiffSummaryCard'
import { DiscoveryRightPanelBottomToolbar } from '@/components/discovery/DiscoveryRightPanelBottomToolbar'
import { FsmFlowDiagram } from '@/components/fsm-flow'
import { useDiscoveryBaselineMachine } from '@/hooks/useDiscoveryBaselineMachine'
import {
  DISCOVERY_EMPTY_PREVIEW_CONFIG,
  coerceDiscoveryDetailConfig,
  inferredEdgesToPreviewFsmConfig,
} from '@/lib/discoveryDiagramConfig'
import type { FSMConfig } from '@/lib/types/fsm'

export interface DiscoveryWorkspaceProps {
  /** Shared workspace state (e.g. from the Discovery page with fleet panel). */
  workspace: UseDiscoveryWorkspaceResult
  /** `threeColumn`: machine + builtCandidates live in left/middle columns; baseline uses catalog row id. */
  mode?: 'standalone' | 'threeColumn'
  /** Focused catalog machine id for baseline diff (threeColumn). */
  baselineCatalogMachineId?: string | null
  /** After successful single or batch observation (refresh fleet list, etc.). */
  onAfterObservation?: () => void
}

export function DiscoveryWorkspace({
  workspace: d,
  mode = 'standalone',
  baselineCatalogMachineId = null,
  onAfterObservation,
}: DiscoveryWorkspaceProps) {
  const { config: discoveryConfig } = useDiscoveryConfig()
  const baseline = useDiscoveryBaselineMachine(
    d.machineName,
    mode === 'threeColumn' ? { catalogMachineId: baselineCatalogMachineId } : undefined
  )
  const [entityId, setEntityId] = useState('demo-entity-1')
  const [stateObs, setStateObs] = useState('observed_state')
  const [promoteOpen, setPromoteOpen] = useState(false)
  const [promoteTarget, setPromoteTarget] = useState<string | null>(null)

  const candidateConfig =
    d.detail?.config ? ({ ...d.detail.config } as unknown as FSMConfig) : null

  const hasMachine = d.machineName.trim().length > 0
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)
  const canRunScope =
    editingWorkspace && d.selectedEntityIds.length > 0
  const canBuild =
    canRunScope &&
    (d.mode === 'inference' ||
      (d.mode === 'manual' && d.selectedEdgeKeys.length > 0))

  const inspector = (
    <div className="min-h-0 space-y-4 overflow-y-auto p-3 sm:p-4">
      <DiscoveryDiffSummaryCard
        baselineConfig={baseline.baselineConfig}
        baselineVersion={baseline.baselineVersion}
        candidateConfig={candidateConfig}
      />

      <DiscoveryShadowDiffCard
        machineName={d.machineName}
        loadingShadow={d.loadingShadow}
        shadowDiffs={d.shadowDiffs}
        onRefresh={() => void d.loadShadow()}
      />
    </div>
  )

  const [observationOpen, setObservationOpen] = useState(true)
  const [shadowFilter, setShadowFilter] = useState<DiscoveryShadowFilter>('differs')

  const threeColumnDiagramConfig = useMemo(() => {
    const name = d.machineName.trim()
    if (d.selectedVersion && d.loadingDetail) {
      return DISCOVERY_EMPTY_PREVIEW_CONFIG
    }
    if (d.selectedVersion && d.detail?.config) {
      return coerceDiscoveryDetailConfig(d.detail.config as Record<string, unknown>, name)
    }
    const edges =
      d.previewSelectedEdges.length > 0 ? d.previewSelectedEdges : d.previewEdges
    if (edges.length > 0) {
      return inferredEdgesToPreviewFsmConfig(edges, name)
    }
    return DISCOVERY_EMPTY_PREVIEW_CONFIG
  }, [
    d.machineName,
    d.selectedVersion,
    d.loadingDetail,
    d.detail,
    d.previewEdges,
    d.previewSelectedEdges,
  ])

  if (mode === 'threeColumn') {
    return (
      <div className="flex h-full min-h-0 flex-col">
        <div className="shrink-0">
          <DiscoveryStatusBanner error={d.error} promoted={d.promoted} />
        </div>

        <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
          {!hasMachine ? (
            <div className="flex min-h-0 flex-1 items-center justify-center p-6 text-center text-sm text-muted-foreground">
              Pin a discovery machine from the left column to use Preview, Build, and the diagram.
            </div>
          ) : (
            <>
              <Group
                id="discovery-right-vertical"
                orientation="vertical"
                className="flex min-h-0 flex-1 flex-col"
              >
                <Panel defaultSize="58" minSize="22" className="min-h-0 flex flex-col">
                  <div className="relative flex min-h-[200px] min-w-0 flex-1 flex-col p-2">
                    <FsmFlowDiagram
                      config={threeColumnDiagramConfig}
                      minHeight="100%"
                      className="min-h-0 flex-1"
                      editable={false}
                      showGuards
                      showActions={false}
                      opsMetrics={{ enabled: false, metricsByState: {} }}
                    />
                  </div>
                </Panel>
                <Separator className="h-1.5 shrink-0 bg-border !cursor-ns-resize" />
                <Panel defaultSize="42" minSize="18" className="flex min-h-0 flex-col">
                  <DiscoveryRightPanelBottomToolbar
                    d={d}
                    observationOpen={observationOpen}
                    onToggleObservation={() => setObservationOpen((o) => !o)}
                    shadowFilter={shadowFilter}
                    onShadowFilterChange={setShadowFilter}
                    canRunScope={canRunScope}
                    canBuild={canBuild}
                  />
                  <div className="min-h-0 flex-1 space-y-4 overflow-y-auto p-3">
                    {observationOpen ? (
                      <DiscoveryObservationCard
                        machineName={d.machineName}
                        entityId={entityId}
                        observedState={stateObs}
                        observing={d.observing}
                        onEntityIdChange={setEntityId}
                        onObservedStateChange={setStateObs}
                        onObserve={async () => {
                          const ok = await d.observe(entityId, stateObs)
                          if (ok) onAfterObservation?.()
                        }}
                        onBulkRecord={async (text) => {
                          const ok = await d.observeBulkFromText(text)
                          if (ok) onAfterObservation?.()
                        }}
                      />
                    ) : null}

                    <DiscoveryRecipeWorkspacePanel
                      workspace={d}
                      layout="threeColumn"
                      recipeToolbar="formOnly"
                    />

                    <DiscoveryDiffSummaryCard
                      baselineConfig={baseline.baselineConfig}
                      baselineVersion={baseline.baselineVersion}
                      candidateConfig={candidateConfig}
                    />

                    <div className="space-y-2">
                      <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                        Shadow diff log
                      </p>
                      <DiscoveryShadowDiffTable shadowDiffs={d.shadowDiffs} filter={shadowFilter} />
                    </div>
                  </div>
                </Panel>
              </Group>
            </>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-col gap-0">
      <div className="shrink-0 space-y-3 pb-3">
        <DiscoveryStatusBanner error={d.error} promoted={d.promoted} />

        <DiscoveryBackendSummaryCard config={discoveryConfig} />

        <DiscoveryMachineSelectorCard
          machineName={d.machineName}
          recentMachineNames={d.recentMachineNames}
          loadingList={d.loadingList}
          building={d.building}
          onMachineNameChange={d.setMachineName}
          onSelectRecent={d.selectMachineName}
          onClearError={d.clearError}
          onLoadCandidates={() => void d.loadCandidates()}
        />

        <DiscoveryObservationCard
          machineName={d.machineName}
          entityId={entityId}
          observedState={stateObs}
          observing={d.observing}
          onEntityIdChange={setEntityId}
          onObservedStateChange={setStateObs}
          onObserve={async () => {
            const ok = await d.observe(entityId, stateObs)
            if (ok) onAfterObservation?.()
          }}
          onBulkRecord={async (text) => {
            const ok = await d.observeBulkFromText(text)
            if (ok) onAfterObservation?.()
          }}
        />
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-0 border-t border-border lg:grid-cols-[minmax(260px,340px)_1fr]">
        <div className="flex min-h-0 min-w-0 flex-col border-border lg:border-r">
          <div className="min-h-0 flex-1">
            <DiscoveryCandidatesTable
              embedded
              drafts={d.drafts}
              activeDraftId={d.activeDraftId}
              onSelectDraft={d.selectDraft}
              onDeleteDraft={(id) => void d.deleteDraft(id)}
              builtCandidates={d.builtCandidates}
              selectedVersion={d.selectedVersion}
              loadingList={d.loadingList}
              promoting={d.promoting}
              driftAlertThreshold={discoveryConfig?.drift_alert_threshold}
              driftSevereThreshold={discoveryConfig?.drift_severe_threshold}
              driftMinSample={discoveryConfig?.drift_min_sample}
              lowSampleThreshold={discoveryConfig?.low_sample_threshold}
              onSelectVersion={d.selectVersion}
              onPromoteRequest={(version) => {
                setPromoteTarget(version)
                setPromoteOpen(true)
              }}
            />
          </div>
        </div>

        <div className="flex min-h-0 min-w-0 flex-col overflow-hidden border-border lg:border-l">
          {hasMachine ? (
            <div className="flex h-12 min-h-12 shrink-0 flex-wrap items-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-0">
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="h-8"
                disabled={d.loadingList}
                onClick={() => void d.createDraft()}
              >
                <Plus className="mr-1.5 h-3.5 w-3.5" />
                New draft
              </Button>
            </div>
          ) : null}
          <div className="shrink-0 overflow-y-auto border-b border-border px-3 py-3 lg:max-h-[min(380px,40vh)]">
            <DiscoveryRecipeWorkspacePanel workspace={d} layout="standalone" />
          </div>
          <div className="min-h-0 flex-1 overflow-hidden">{inspector}</div>
        </div>
      </div>

      <PromoteCandidateDialog
        open={promoteOpen}
        onOpenChange={(open) => {
          setPromoteOpen(open)
          if (!open) setPromoteTarget(null)
        }}
        machineName={d.machineName.trim()}
        version={promoteTarget}
        loading={d.promoting}
        onConfirm={async () => {
          if (!promoteTarget) return
          try {
            await d.promote(promoteTarget)
            setPromoteOpen(false)
            setPromoteTarget(null)
          } catch {
            /* error surfaced in workspace */
          }
        }}
      />
    </div>
  )
}
