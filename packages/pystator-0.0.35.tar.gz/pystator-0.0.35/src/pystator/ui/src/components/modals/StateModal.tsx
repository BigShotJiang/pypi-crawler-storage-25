'use client'

import { useState, useEffect, useRef } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import type { FSMState } from '@/lib/types/fsm'
import { StateInspectorForm } from '@/components/workspace/inspector/StateInspectorForm'

export interface StateModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  state: FSMState
  existingStateNames: string[]
  onSave: (state: FSMState) => void
  title?: string
  description?: string
  machineStateVariableKeys?: string[]
  allStates: FSMState[]
}

const STATE_MODAL_FORM_ID = 'workspace-state-modal-form'

export function StateModal({
  open,
  onOpenChange,
  state,
  existingStateNames,
  onSave,
  title = 'State',
  description = 'Add or edit state name, type, hierarchy, and optional hooks.',
  machineStateVariableKeys,
  allStates,
}: StateModalProps) {
  const [canSave, setCanSave] = useState(false)
  const [formSession, setFormSession] = useState(0)
  const wasOpen = useRef(false)
  useEffect(() => {
    if (open && !wasOpen.current) {
      setFormSession((s) => s + 1)
    }
    wasOpen.current = open
  }, [open])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" showClose>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        {open ? (
          <StateInspectorForm
            state={state}
            resetKey={formSession}
            existingStateNames={existingStateNames}
            allStates={allStates}
            machineStateVariableKeys={machineStateVariableKeys}
            onSubmit={(next) => {
              onSave(next)
              onOpenChange(false)
            }}
            showFooter={false}
            formId={STATE_MODAL_FORM_ID}
            onCanSaveChange={setCanSave}
          />
        ) : null}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button type="submit" form={STATE_MODAL_FORM_ID} disabled={!canSave}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
