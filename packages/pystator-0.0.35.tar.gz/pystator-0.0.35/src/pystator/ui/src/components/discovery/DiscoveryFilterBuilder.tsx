'use client'

import { useCallback } from 'react'
import { Label } from '@/components/ui/label'
import type { DiscoveryDraftFilterInput } from '@/lib/api'

const TEXTAREA_CLASS =
  'flex min-h-[64px] w-full rounded-md border border-input bg-background px-2 py-1.5 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring'

/**
 * Controlled editor for a ``DiscoveryDraftFilterInput``.
 *
 * Keeps the parent dialog (create vs. edit) simple: the parent owns
 * the draft filter state and the "set vs clear" decision; this
 * component is a pure view that renders the textarea-based editors
 * for each dimension and bubbles changes up via ``onChange``.
 */
export interface DiscoveryFilterBuilderProps {
  value: DiscoveryDraftFilterInput
  onChange: (next: DiscoveryDraftFilterInput) => void
}

function parseList(raw: string): string[] | null {
  const parts = raw
    .split(/[\n,]+/)
    .map((s) => s.trim())
    .filter(Boolean)
  return parts.length > 0 ? parts : null
}

function listToText(list: string[] | null | undefined): string {
  return (list ?? []).join('\n')
}

function parseDateTime(raw: string): string | null {
  const trimmed = raw.trim()
  if (!trimmed) return null
  const d = new Date(trimmed)
  if (Number.isNaN(d.getTime())) return null
  return d.toISOString()
}

export function DiscoveryFilterBuilder({
  value,
  onChange,
}: DiscoveryFilterBuilderProps) {
  const setChannels = useCallback(
    (raw: string) => onChange({ ...value, channels: parseList(raw) }),
    [onChange, value]
  )
  const setEntityIds = useCallback(
    (raw: string) => onChange({ ...value, entity_ids: parseList(raw) }),
    [onChange, value]
  )
  const setSources = useCallback(
    (raw: string) => onChange({ ...value, sources: parseList(raw) }),
    [onChange, value]
  )
  const setObservedAfter = useCallback(
    (raw: string) => onChange({ ...value, observed_after: parseDateTime(raw) }),
    [onChange, value]
  )
  const setObservedBefore = useCallback(
    (raw: string) =>
      onChange({ ...value, observed_before: parseDateTime(raw) }),
    [onChange, value]
  )

  return (
    <div className="grid gap-3">
      <div className="space-y-1">
        <Label htmlFor="dfb-channels" className="text-xs">
          Channels (one per line or comma-separated)
        </Label>
        <textarea
          id="dfb-channels"
          rows={2}
          className={TEXTAREA_CLASS}
          placeholder="orders&#10;inventory"
          value={listToText(value.channels)}
          onChange={(e) => setChannels(e.target.value)}
        />
        <p className="text-[11px] text-muted-foreground">
          Producer ``machine_name`` tags. Leave empty to read all channels.
        </p>
      </div>

      <div className="space-y-1">
        <Label htmlFor="dfb-entity-ids" className="text-xs">
          Entity IDs
        </Label>
        <textarea
          id="dfb-entity-ids"
          rows={2}
          className={TEXTAREA_CLASS}
          placeholder="order-123&#10;order-456"
          value={listToText(value.entity_ids)}
          onChange={(e) => setEntityIds(e.target.value)}
        />
      </div>

      <div className="space-y-1">
        <Label htmlFor="dfb-sources" className="text-xs">
          Sources
        </Label>
        <textarea
          id="dfb-sources"
          rows={2}
          className={TEXTAREA_CLASS}
          placeholder="svc&#10;worker"
          value={listToText(value.sources)}
          onChange={(e) => setSources(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div className="space-y-1">
          <Label htmlFor="dfb-after" className="text-xs">
            Observed after
          </Label>
          <input
            id="dfb-after"
            type="datetime-local"
            className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={
              value.observed_after
                ? new Date(value.observed_after).toISOString().slice(0, 16)
                : ''
            }
            onChange={(e) => setObservedAfter(e.target.value)}
          />
        </div>
        <div className="space-y-1">
          <Label htmlFor="dfb-before" className="text-xs">
            Observed before
          </Label>
          <input
            id="dfb-before"
            type="datetime-local"
            className="flex h-9 w-full rounded-md border border-input bg-background px-2 text-sm"
            value={
              value.observed_before
                ? new Date(value.observed_before).toISOString().slice(0, 16)
                : ''
            }
            onChange={(e) => setObservedBefore(e.target.value)}
          />
        </div>
      </div>
    </div>
  )
}

/** True when the filter has at least one dimension set. */
export function filterHasAnyDimension(f: DiscoveryDraftFilterInput): boolean {
  return Boolean(
    (f.channels && f.channels.length > 0) ||
      (f.entity_ids && f.entity_ids.length > 0) ||
      (f.sources && f.sources.length > 0) ||
      f.observed_after ||
      f.observed_before ||
      (f.metadata_match && Object.keys(f.metadata_match).length > 0)
  )
}

export const EMPTY_FILTER: DiscoveryDraftFilterInput = {
  channels: null,
  entity_ids: null,
  sources: null,
  observed_after: null,
  observed_before: null,
  metadata_match: null,
}
