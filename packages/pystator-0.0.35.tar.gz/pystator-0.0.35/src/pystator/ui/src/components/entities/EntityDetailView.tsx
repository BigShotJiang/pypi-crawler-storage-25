'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import FsmFlowDiagram from '@/components/fsm-flow/FsmFlowDiagram'
import SendEventForm from '@/components/entities/SendEventForm'
import TransitionHistory from '@/components/entities/TransitionHistory'
import ReplayPanel from '@/components/entities/ReplayPanel'
import GuardActionTester from '@/components/entities/GuardActionTester'
import EntityLabelEditor from '@/components/entities/EntityLabelEditor'
import AvailableTriggers from '@/components/entities/AvailableTriggers'
import EntityTimeline from '@/components/entities/EntityTimeline'
import EntityMetricsPanel from '@/components/entities/EntityMetricsPanel'
import ContextPanel from '@/components/entities/ContextPanel'
import {
  getEntityState,
  getEntityHistory,
  deleteEntity,
  archiveEntity,
  restoreEntity,
  purgeEntity,
  getEntitySnapshot,
  listWorkspaceAnnotations,
  upsertWorkspaceAnnotation,
  deleteWorkspaceAnnotation,
} from '@/lib/api'
import type { EntityState, TransitionHistoryEntry } from '@/lib/api'
import { diagramHighlightFromHistoryEntry } from '@/lib/entityDiagramHighlight'
import { useMachineConfigByName } from '@/hooks/useMachineConfigByName'
import { useStateOpsMetrics } from '@/hooks/useStateOpsMetrics'
import { getTriggersFromState } from '@/lib/fsmConfigUtils'
import {
  ArrowLeft, Trash2, RefreshCw, Download, Archive,
  RotateCcw, AlertTriangle, MoreVertical,
} from 'lucide-react'

export interface EntityDetailViewProps {
  entityId: string
  onBack: () => void
}

type TabKey = 'history' | 'timeline' | 'metrics' | 'replay' | 'developer'

const TAB_LABELS: { key: TabKey; label: string }[] = [
  { key: 'history', label: 'History' },
  { key: 'timeline', label: 'Timeline' },
  { key: 'metrics', label: 'Metrics' },
  { key: 'replay', label: 'Replay' },
  { key: 'developer', label: 'Developer' },
]

export default function EntityDetailView({ entityId, onBack }: EntityDetailViewProps) {
  const [entity, setEntity] = useState<EntityState | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const [lastTransition, setLastTransition] = useState<TransitionHistoryEntry | null>(null)
  /** History row chosen for diagram edge highlight (takes precedence over {@link lastTransition}). */
  const [historyDiagramSelection, setHistoryDiagramSelection] =
    useState<TransitionHistoryEntry | null>(null)
  const [activeTab, setActiveTab] = useState<TabKey>('history')
  const [showActions, setShowActions] = useState(false)

  const { config: machineConfig, loading: configLoading, error: configError } =
    useMachineConfigByName(entity?.machine_name ?? null)

  const opsMachineName = (machineConfig?.meta?.machine_name ?? '').trim()
  const { metricsByState: opsMetricsByState } = useStateOpsMetrics({
    enabled: opsMachineName.length > 0,
    machineName: opsMachineName,
    windowHours: 24,
    pollMs: 15_000,
  })

  // Workspace annotations (state notes)
  const machineNameForNotes = machineConfig?.meta?.machine_name ?? ''
  const machineVersionForNotes = machineConfig?.meta?.version ?? ''
  const notesEnabled =
    machineNameForNotes.trim().length > 0 && machineVersionForNotes.trim().length > 0
  const [notesByState, setNotesByState] = useState<Record<string, string>>({})
  const [noteSaving, setNoteSaving] = useState(false)
  const [noteDeleting, setNoteDeleting] = useState(false)
  const [openNoteStateName, setOpenNoteStateName] = useState<string>('')

  useEffect(() => {
    if (!notesEnabled) { setNotesByState({}); return }
    listWorkspaceAnnotations({
      machine_name: machineNameForNotes,
      machine_version: machineVersionForNotes,
    })
      .then((items) => {
        const next: Record<string, string> = {}
        const arr = Array.isArray(items) ? items : (items as { items?: unknown[] }).items ?? []
        for (const a of arr as Array<{ state_name?: string; body_markdown?: string }>) {
          if (a.state_name && a.body_markdown) next[a.state_name] = a.body_markdown
        }
        setNotesByState(next)
      })
      .catch(() => {})
  }, [notesEnabled, machineNameForNotes, machineVersionForNotes])

  const openNoteForState = useCallback(
    (stateName: string) => { if (notesEnabled) setOpenNoteStateName(stateName) },
    [notesEnabled],
  )
  const handleSaveNote = useCallback(
    async (body: string) => {
      if (!notesEnabled || !openNoteStateName) return
      setNoteSaving(true)
      try {
        await upsertWorkspaceAnnotation({
          machine_name: machineNameForNotes, machine_version: machineVersionForNotes,
          state_name: openNoteStateName, body_markdown: body,
        })
        setNotesByState((prev) => ({ ...prev, [openNoteStateName]: body }))
      } finally { setNoteSaving(false) }
    },
    [notesEnabled, openNoteStateName, machineNameForNotes, machineVersionForNotes],
  )
  const handleDeleteNote = useCallback(async () => {
    if (!notesEnabled || !openNoteStateName) return
    setNoteDeleting(true)
    try {
      await deleteWorkspaceAnnotation({
        machine_name: machineNameForNotes, machine_version: machineVersionForNotes,
        state_name: openNoteStateName,
      })
      setNotesByState((prev) => { const n = { ...prev }; delete n[openNoteStateName]; return n })
      setOpenNoteStateName('')
    } finally { setNoteDeleting(false) }
  }, [notesEnabled, openNoteStateName, machineNameForNotes, machineVersionForNotes])

  const statesWithNotes = useMemo(
    () => new Set(Object.keys(notesByState).filter((k) => (notesByState[k] ?? '').trim().length > 0)),
    [notesByState],
  )

  // Data fetching
  const fetchEntity = useCallback(async () => {
    setLoading(true); setError(null)
    try { setEntity(await getEntityState(entityId)) }
    catch (e) { setError(e instanceof Error ? e : new Error(String(e))) }
    finally { setLoading(false) }
  }, [entityId])

  useEffect(() => { fetchEntity() }, [fetchEntity])

  useEffect(() => {
    if (!entityId || !entity) return
    getEntityHistory(entityId, 1, 0)
      .then((entries) => setLastTransition(entries[0] ?? null))
      .catch(() => setLastTransition(null))
  }, [entityId, entity, refreshKey])

  useEffect(() => {
    setHistoryDiagramSelection(null)
  }, [entityId, refreshKey])

  const diagramHighlightTransition = useMemo(() => {
    if (historyDiagramSelection) {
      return diagramHighlightFromHistoryEntry(historyDiagramSelection)
    }
    return diagramHighlightFromHistoryEntry(lastTransition)
  }, [historyDiagramSelection, lastTransition])

  const handleEventSuccess = () => { fetchEntity(); setRefreshKey((k) => k + 1) }

  // Entity actions
  const handleDelete = async () => {
    if (!window.confirm(`Delete entity "${entityId}"?`)) return
    try { await deleteEntity(entityId); onBack() }
    catch (e) { setError(e instanceof Error ? e : new Error(String(e))) }
  }
  const handleArchive = async () => {
    try { await archiveEntity(entityId); await fetchEntity() }
    catch (e) { setError(e instanceof Error ? e : new Error(String(e))) }
  }
  const handleRestore = async () => {
    try { await restoreEntity(entityId); await fetchEntity() }
    catch (e) { setError(e instanceof Error ? e : new Error(String(e))) }
  }
  const handlePurge = async () => {
    if (!window.confirm(`Permanently purge "${entityId}"? Cannot be undone.`)) return
    try { await purgeEntity(entityId); onBack() }
    catch (e) { setError(e instanceof Error ? e : new Error(String(e))) }
  }
  const handleExportSnapshot = async () => {
    try {
      const snap = await getEntitySnapshot(entityId)
      const blob = new Blob([JSON.stringify(snap, null, 2)], { type: 'application/json' })
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob)
      a.download = `entity-${entityId}-snapshot.json`; document.body.appendChild(a)
      a.click(); document.body.removeChild(a); URL.revokeObjectURL(a.href)
    } catch (e) { setError(e instanceof Error ? e : new Error(String(e))) }
  }

  if (loading && !entity) {
    return <PageContainer><div className="flex justify-center py-20"><LoadingSpinner /></div></PageContainer>
  }

  // Status badge colors
  const stateColor = entity?.is_terminal
    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
    : 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
  const workflowColor =
    entity?.workflow_status === 'complete' ? 'text-emerald-600' :
    entity?.workflow_status === 'failed' ? 'text-red-600' : 'text-muted-foreground'

  return (
    <PageContainer>
      {error && <ErrorDisplay error={error} className="mb-4" />}

      {entity && (
        <>
          {/* ─── Dense Header Bar ─── */}
          <div className="flex items-center justify-between border-b pb-3 mb-4 flex-wrap gap-2">
            <div className="flex items-center gap-3 min-w-0">
              <Button variant="ghost" size="icon" onClick={onBack} className="h-8 w-8 shrink-0">
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <span className="font-mono text-sm font-medium truncate max-w-[200px]" title={entityId}>
                {entityId}
              </span>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${stateColor}`}>
                {entity.current_state}
              </span>
              {entity.machine_name && (
                <span className="text-xs text-muted-foreground hidden sm:inline">
                  {entity.machine_name}
                  {(entity as unknown as Record<string, unknown>).machine_version ? ` v${(entity as unknown as Record<string, unknown>).machine_version}` : ''}
                </span>
              )}
              <span className={`text-xs ${workflowColor} hidden md:inline`}>
                {entity.workflow_status ?? 'active'}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <Button variant="ghost" size="sm" onClick={fetchEntity} className="h-8 gap-1 text-xs">
                <RefreshCw className="h-3.5 w-3.5" /> Refresh
              </Button>
              <Button variant="ghost" size="sm" onClick={handleExportSnapshot} className="h-8 gap-1 text-xs">
                <Download className="h-3.5 w-3.5" />
              </Button>
              {/* More actions dropdown */}
              <div className="relative">
                <Button
                  variant="ghost" size="sm" className="h-8 w-8 p-0"
                  onClick={() => setShowActions(!showActions)}
                >
                  <MoreVertical className="h-4 w-4" />
                </Button>
                {showActions && (
                  <div className="absolute right-0 top-full mt-1 z-50 bg-popover border rounded-md shadow-md py-1 min-w-[140px]">
                    {entity.status === 'active' && (
                      <button
                        className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent flex items-center gap-2"
                        onClick={() => { setShowActions(false); handleArchive() }}
                      >
                        <Archive className="h-3.5 w-3.5" /> Archive
                      </button>
                    )}
                    {(entity.status === 'archived' || entity.status === 'deleted') && (
                      <button
                        className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent flex items-center gap-2"
                        onClick={() => { setShowActions(false); handleRestore() }}
                      >
                        <RotateCcw className="h-3.5 w-3.5" /> Restore
                      </button>
                    )}
                    <button
                      className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent text-destructive flex items-center gap-2"
                      onClick={() => { setShowActions(false); handleDelete() }}
                    >
                      <Trash2 className="h-3.5 w-3.5" /> Delete
                    </button>
                    {entity.status === 'deleted' && (
                      <button
                        className="w-full text-left px-3 py-1.5 text-xs hover:bg-accent text-destructive flex items-center gap-2"
                        onClick={() => { setShowActions(false); handlePurge() }}
                      >
                        <AlertTriangle className="h-3.5 w-3.5" /> Purge
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Labels inline */}
          <EntityLabelEditor
            entityId={entityId}
            labels={entity.labels ?? {}}
            onLabelsChanged={fetchEntity}
          />

          {/* ─── Two-Column Top Section ─── */}
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 mt-4">
            {/* Left: FSM Diagram (3/5) — stretch to fill grid row */}
            <div className="lg:col-span-3 rounded-lg border bg-card min-h-[420px]">
              {configLoading && !machineConfig && (
                <div className="flex items-center justify-center h-full" style={{ minHeight: 320 }}>
                  <LoadingSpinner />
                </div>
              )}
              {configError && !machineConfig && (
                <div className="flex items-center justify-center h-full p-6">
                  <p className="text-sm text-muted-foreground">
                    Machine &quot;{entity.machine_name}&quot; not found. Diagram unavailable.
                  </p>
                </div>
              )}
              {machineConfig && (
                <FsmFlowDiagram
                  config={machineConfig}
                  minHeight="100%"
                  showGuards
                  showActions={false}
                  highlightState={entity.current_state}
                  highlightTransition={diagramHighlightTransition}
                  annotations={{
                    enabled: notesEnabled, statesWithNotes,
                    openStateName: openNoteStateName,
                    getBody: (s: string) => notesByState[s] ?? '',
                    saving: noteSaving, deleting: noteDeleting,
                    machineName: machineNameForNotes, machineVersion: machineVersionForNotes,
                    onOpen: openNoteForState, onClose: () => setOpenNoteStateName(''),
                    onSave: (_s: string, body: string) => { void handleSaveNote(body) },
                    onDelete: (_s: string) => { void handleDeleteNote() },
                  }}
                  opsMetrics={{
                    enabled: opsMachineName.length > 0,
                    metricsByState: opsMetricsByState,
                  }}
                />
              )}
            </div>

            {/* Right: Interaction Panel (2/5) */}
            <div className="lg:col-span-2 space-y-3">
              <div id="send-event-form">
                <SendEventForm
                  entityId={entityId}
                  defaultMachineName={entity.machine_name}
                  availableTriggers={
                    machineConfig && entity.current_state
                      ? getTriggersFromState(machineConfig, entity.current_state)
                      : undefined
                  }
                  stateVariables={machineConfig?.state_variables ?? []}
                  onSuccess={handleEventSuccess}
                />
              </div>

              {entity.machine_name && (
                <div className="rounded-lg border p-3">
                  <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide block mb-2">
                    Available Triggers
                  </span>
                  <AvailableTriggers
                    entityId={entityId}
                    currentState={entity.current_state}
                    onTriggerSelect={() => {
                      document.getElementById('send-event-form')?.scrollIntoView({ behavior: 'smooth' })
                    }}
                  />
                </div>
              )}

              <ContextPanel context={entity.context ?? {}} />
            </div>
          </div>

          {/* ─── Tabbed Lower Section ─── */}
          <div className="mt-6">
            {/* Tab bar */}
            <div className="flex border-b">
              {TAB_LABELS.map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => setActiveTab(key)}
                  className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === key
                      ? 'border-primary text-primary'
                      : 'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground/30'
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="mt-4">
              {activeTab === 'history' && (
                <TransitionHistory
                  entityId={entityId}
                  refreshKey={refreshKey}
                  selectedEntryId={historyDiagramSelection?.id ?? null}
                  onSelectEntry={(entry) => {
                    setHistoryDiagramSelection((prev) =>
                      prev?.id === entry.id ? null : entry
                    )
                  }}
                />
              )}
              {activeTab === 'timeline' && (
                <EntityTimeline entityId={entityId} />
              )}
              {activeTab === 'metrics' && (
                <EntityMetricsPanel entityId={entityId} refreshToken={refreshKey} />
              )}
              {activeTab === 'replay' && (
                <ReplayPanel entityId={entityId} />
              )}
              {activeTab === 'developer' && (
                <GuardActionTester entityId={entityId} />
              )}
            </div>
          </div>
        </>
      )}
    </PageContainer>
  )
}
