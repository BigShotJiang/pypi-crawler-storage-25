'use client'

import { ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import type { SidebarDisplayMode } from './ResizableWorkspaceLayout'

export interface SidebarHeaderWithToggleProps {
  /** When true, only the expand chevron is shown (centered). */
  isCollapsed: boolean
  /** Sidebar display mode for responsive header content. */
  displayMode?: SidebarDisplayMode
  /** Called when user clicks the toggle (collapse or expand). */
  onToggle: () => void
  /** Content shown on the left when expanded (e.g. title or tabs). Omitted when collapsed. */
  children?: React.ReactNode
  /** Optional class name for the header container. */
  className?: string
}

/**
 * Left sidebar header: muted bar with optional leading content and collapse/expand control.
 * Matches pycharter unified-editor LeftPanel + ResizableWorkspaceLayout header pattern.
 */
export function SidebarHeaderWithToggle({
  isCollapsed,
  displayMode = isCollapsed ? 'collapsed' : 'expanded',
  onToggle,
  children,
  className,
}: SidebarHeaderWithToggleProps) {
  const showChildren = displayMode !== 'collapsed'
  return (
    <div
      className={cn(
        'flex shrink-0 items-center gap-2 border-b border-border/50 bg-muted/30 px-3 py-2.5',
        isCollapsed ? 'justify-center' : 'justify-between',
        className
      )}
    >
      {showChildren && children}
      <button
        type="button"
        onClick={onToggle}
        className="shrink-0 rounded-md p-1.5 transition-all duration-200 hover:bg-muted hover:scale-105 active:scale-95"
        aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {isCollapsed ? (
          <ChevronRight className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronLeft className="h-4 w-4 text-muted-foreground" />
        )}
      </button>
    </div>
  )
}
