'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { normalizeName, validateName } from '@/lib/utils'
import {
  inspectorInputComponentClass,
  inspectorLabelClass,
} from '@/components/workspace/inspector/inspectorPanelStyles'

export interface TransitionTriggerPopoverProps {
  open: boolean
  position: { x: number; y: number }
  sourceState: string
  destState: string
  onConfirm: (trigger: string) => void
  onCancel: () => void
}

/**
 * Small fixed-position prompt shown after connecting two states (pycharter-style
 * immediate connection UI). User enters a trigger name; the transition is
 * created on confirm without opening the side inspector.
 */
export function TransitionTriggerPopover({
  open,
  position,
  sourceState,
  destState,
  onConfirm,
  onCancel,
}: TransitionTriggerPopoverProps) {
  const rootRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const [raw, setRaw] = useState('')
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) {
      setRaw('')
      setError(null)
      return
    }
    const id = requestAnimationFrame(() => {
      inputRef.current?.focus()
      inputRef.current?.select()
    })
    return () => cancelAnimationFrame(id)
  }, [open])

  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation()
        onCancel()
      }
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onCancel])

  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        onCancel()
      }
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [open, onCancel])

  const submit = useCallback(() => {
    const trimmed = raw.trim()
    if (!trimmed) {
      setError('Enter a trigger name for this transition.')
      return
    }
    const normalized = normalizeName(trimmed)
    if (!normalized) {
      setError('Trigger produces no valid characters')
      return
    }
    try {
      validateName(normalized)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Invalid trigger')
      return
    }
    setError(null)
    onConfirm(normalized)
  }, [raw, onConfirm])

  if (!open) return null

  return (
    <div
      ref={rootRef}
      role="dialog"
      aria-label="New transition trigger"
      className="fixed z-[60] w-64 rounded-lg border border-border bg-background/95 p-3 shadow-lg backdrop-blur-sm text-xs"
      style={{ left: position.x, top: position.y }}
      onKeyDown={(e) => {
        if (e.key === 'Enter') {
          e.preventDefault()
          e.stopPropagation()
          submit()
        }
      }}
    >
      <p className="mb-2 text-[11px] text-muted-foreground leading-snug">
        <span className="font-mono text-foreground">{sourceState}</span>
        {' → '}
        <span className="font-mono text-foreground">{destState}</span>
      </p>
      <div className="space-y-1.5">
        <Label htmlFor="transition-trigger-popover-input" className={inspectorLabelClass}>
          Trigger name
        </Label>
        <Input
          ref={inputRef}
          id="transition-trigger-popover-input"
          className={inspectorInputComponentClass}
          placeholder="e.g. submit"
          value={raw}
          onChange={(e) => {
            setRaw(e.target.value)
            setError(null)
          }}
          autoComplete="off"
        />
        {error ? <p className="text-[11px] text-destructive">{error}</p> : null}
        <p className="text-[11px] text-muted-foreground">Press Enter to create the transition.</p>
      </div>
      <div className="mt-3 flex justify-end gap-2">
        <Button type="button" variant="outline" size="sm" className="h-8 text-xs" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="button" size="sm" className="h-8 text-xs" onClick={submit}>
          Continue
        </Button>
      </div>
    </div>
  )
}
