"use client"

import { useState, useCallback } from "react"
import yaml from "js-yaml"
import { useBuilderStore } from "@/stores/builder"
import { useToastStore } from "@/stores/toast"
import { Button } from "@/components/ui/button"
import FsmFlowDiagram from "@/components/fsm-flow/FsmFlowDiagram"
import { createMachine, updateMachine, validateConfig } from "@/lib/api"

type PreviewFormat = "json" | "yaml"

/**
 * Right-hand preview panel for the Builder page.
 *
 * Shows a toolbar (Save / Validate / Download YAML), the FSM diagram,
 * and a collapsible raw-config viewer with JSON/YAML toggle.
 */
export function BuilderPreview() {
  const generatedConfig = useBuilderStore((s) => s.generatedConfig)
  const machineName = useBuilderStore((s) => s.machineName)
  const loadedMachineId = useBuilderStore((s) => s.loadedMachineId)
  const toast = useToastStore((s) => s.toast)

  const [saving, setSaving] = useState(false)
  const [validating, setValidating] = useState(false)
  const [configOpen, setConfigOpen] = useState(false)
  const [format, setFormat] = useState<PreviewFormat>("json")

  // ── Save ──────────────────────────────────────────────────
  const handleSave = useCallback(async () => {
    if (!generatedConfig) return
    setSaving(true)
    try {
      if (loadedMachineId) {
        await updateMachine(loadedMachineId, generatedConfig)
        toast("success", "Machine updated successfully")
      } else {
        await createMachine(generatedConfig)
        toast("success", "Machine created successfully")
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Save failed"
      toast("error", msg)
    } finally {
      setSaving(false)
    }
  }, [generatedConfig, loadedMachineId, toast])

  // ── Validate ──────────────────────────────────────────────
  const handleValidate = useCallback(async () => {
    if (!generatedConfig) return
    setValidating(true)
    try {
      const result = await validateConfig(generatedConfig)
      if (result.valid) {
        toast("success", "Configuration is valid")
      } else {
        const errorCount = result.errors?.length ?? 0
        toast("error", `Validation failed with ${errorCount} error(s)`)
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Validation request failed"
      toast("error", msg)
    } finally {
      setValidating(false)
    }
  }, [generatedConfig, toast])

  // ── Download YAML ─────────────────────────────────────────
  const handleDownload = useCallback(() => {
    if (!generatedConfig) return
    const yamlStr = yaml.dump(generatedConfig, { indent: 2 })
    const blob = new Blob([yamlStr], { type: "application/x-yaml" })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement("a")
    anchor.href = url
    anchor.download = `${machineName || "machine"}.yaml`
    anchor.click()
    URL.revokeObjectURL(url)
  }, [generatedConfig, machineName])

  // ── Config text ───────────────────────────────────────────
  const configText =
    generatedConfig == null
      ? ""
      : format === "json"
        ? JSON.stringify(generatedConfig, null, 2)
        : yaml.dump(generatedConfig, { indent: 2 })

  const hasStates =
    generatedConfig != null &&
    Array.isArray(generatedConfig.states) &&
    generatedConfig.states.some((s) => s.name?.trim())

  return (
    <div className="flex flex-col h-full gap-3">
      {/* ── Toolbar ─────────────────────────────────────── */}
      <div className="flex items-center gap-2 shrink-0">
        <Button size="sm" disabled={!generatedConfig || saving} onClick={handleSave}>
          {saving ? "Saving..." : loadedMachineId ? "Update" : "Save"}
        </Button>
        <Button
          variant="outline"
          size="sm"
          disabled={!generatedConfig || validating}
          onClick={handleValidate}
        >
          {validating ? "Validating..." : "Validate"}
        </Button>
        <Button
          variant="outline"
          size="sm"
          disabled={!generatedConfig}
          onClick={handleDownload}
        >
          Download YAML
        </Button>
      </div>

      {/* ── FSM Diagram ─────────────────────────────────── */}
      <div className="flex-1 min-h-[240px] rounded-md border border-border/50 overflow-hidden">
        {hasStates && generatedConfig ? (
          <FsmFlowDiagram
            config={{
              ...generatedConfig,
              states: generatedConfig.states?.filter((s) => s.name?.trim()) ?? [],
              transitions: generatedConfig.transitions?.filter(
                (t) =>
                  (typeof t.source === 'string' ? t.source.trim() : true) &&
                  t.dest?.trim(),
              ) ?? [],
            }}
            minHeight={240}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
            Add states and rules to see the FSM diagram
          </div>
        )}
      </div>

      {/* ── Collapsible config preview ──────────────────── */}
      <div className="shrink-0 rounded-md border border-border/50">
        <button
          className="flex w-full items-center justify-between px-3 py-2 text-xs font-medium text-muted-foreground hover:bg-muted/40 transition-colors"
          onClick={() => setConfigOpen((prev) => !prev)}
        >
          <span>Generated Config</span>
          <span>{configOpen ? "Hide" : "Show"}</span>
        </button>

        {configOpen && (
          <div className="border-t border-border/40">
            <div className="flex items-center gap-1 px-3 py-1.5 border-b border-border/30">
              <button
                className={`px-2 py-0.5 text-xs rounded ${format === "json" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/40"}`}
                onClick={() => setFormat("json")}
              >
                JSON
              </button>
              <button
                className={`px-2 py-0.5 text-xs rounded ${format === "yaml" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted/40"}`}
                onClick={() => setFormat("yaml")}
              >
                YAML
              </button>
            </div>
            <pre className="max-h-[300px] overflow-auto p-3 text-xs font-mono whitespace-pre-wrap break-words">
              {configText || "No config generated yet"}
            </pre>
          </div>
        )}
      </div>
    </div>
  )
}
