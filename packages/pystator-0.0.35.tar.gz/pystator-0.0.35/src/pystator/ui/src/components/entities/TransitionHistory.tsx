'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { getEntityHistory, getHistoryStats } from '@/lib/api'
import type { TransitionHistoryEntry, HistoryStatsResponse } from '@/lib/api'
import LoadingSpinner from '@/components/LoadingSpinner'
import { ChevronLeft, ChevronRight, CheckCircle2, XCircle } from 'lucide-react'

const PAGE_SIZE = 20

interface TransitionHistoryProps {
  entityId: string
  refreshKey: number
  /** When set, the row with this history `id` is shown as selected (diagram highlight in parent). */
  selectedEntryId?: string | null
  /** Toggle: clicking the active row again clears selection in the parent. */
  onSelectEntry?: (entry: TransitionHistoryEntry) => void
}

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString()
  } catch {
    return iso
  }
}

function HistoryStats({ entityId, refreshKey }: { entityId: string; refreshKey: number }) {
  const [stats, setStats] = useState<HistoryStatsResponse | null>(null)

  useEffect(() => {
    getHistoryStats(entityId)
      .then(setStats)
      .catch(() => setStats(null))
  }, [entityId, refreshKey])

  if (!stats) return null

  return (
    <div className="flex items-center gap-4 text-sm mb-4 px-1">
      <span className="text-muted-foreground">
        Total: <span className="font-medium text-foreground">{stats.total_transitions}</span>
      </span>
      <span className="text-muted-foreground">
        Success:{' '}
        <span className="font-medium text-emerald-600 dark:text-emerald-400">
          {stats.success_count}
        </span>
      </span>
      <span className="text-muted-foreground">
        Failures:{' '}
        <span className="font-medium text-destructive">
          {stats.failure_count}
        </span>
      </span>
    </div>
  )
}

export default function TransitionHistory({
  entityId,
  refreshKey,
  selectedEntryId = null,
  onSelectEntry,
}: TransitionHistoryProps) {
  const [entries, setEntries] = useState<TransitionHistoryEntry[]>([])
  const [offset, setOffset] = useState(0)
  const [loading, setLoading] = useState(true)
  const [hasMore, setHasMore] = useState(false)

  const fetchHistory = useCallback(async (currentOffset: number) => {
    setLoading(true)
    try {
      const data = await getEntityHistory(entityId, PAGE_SIZE + 1, currentOffset)
      if (data.length > PAGE_SIZE) {
        setHasMore(true)
        setEntries(data.slice(0, PAGE_SIZE))
      } else {
        setHasMore(false)
        setEntries(data)
      }
    } catch {
      // silent -- main page already handles connection errors
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    setOffset(0)
    fetchHistory(0)
  }, [fetchHistory, refreshKey])

  useEffect(() => {
    fetchHistory(offset)
  }, [fetchHistory, offset])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Transition History</CardTitle>
      </CardHeader>
      <CardContent>
        <HistoryStats entityId={entityId} refreshKey={refreshKey} />

        {loading && entries.length === 0 ? (
          <div className="flex justify-center py-6">
            <LoadingSpinner size="sm" />
          </div>
        ) : entries.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">
            No transitions recorded yet.
          </p>
        ) : (
          <>
            <div className="overflow-x-auto rounded-lg border">
              <table className="min-w-full divide-y divide-border">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Time</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Trigger</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Transition</th>
                    <th className="px-3 py-2 text-center text-xs font-medium text-muted-foreground uppercase">Status</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase hidden lg:table-cell">Actions / Error</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border bg-background">
                  {entries.map((entry) => {
                    const isSelected = selectedEntryId != null && entry.id === selectedEntryId
                    return (
                    <tr
                      key={entry.id}
                      tabIndex={onSelectEntry ? 0 : undefined}
                      onClick={onSelectEntry ? () => onSelectEntry(entry) : undefined}
                      onKeyDown={
                        onSelectEntry
                          ? (e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault()
                                onSelectEntry(entry)
                              }
                            }
                          : undefined
                      }
                      className={
                        onSelectEntry
                          ? `cursor-pointer transition-colors ${
                              isSelected ? 'bg-primary/10 ring-1 ring-inset ring-primary/25' : 'hover:bg-muted/30'
                            }`
                          : 'hover:bg-muted/30 transition-colors'
                      }
                      aria-selected={onSelectEntry ? isSelected : undefined}
                    >
                      <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">
                        {formatTime(entry.created_at)}
                      </td>
                      <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                        {entry.trigger}
                      </td>
                      <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                        {entry.source_state}
                        <span className="mx-1 text-muted-foreground">&rarr;</span>
                        {entry.target_state ?? '\u2014'}
                      </td>
                      <td className="px-3 py-2 text-center">
                        {entry.success ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 inline-block" />
                        ) : (
                          <XCircle className="h-4 w-4 text-destructive inline-block" />
                        )}
                      </td>
                      <td className="px-3 py-2 text-xs text-muted-foreground hidden lg:table-cell max-w-[200px] truncate">
                        {entry.error_message
                          ? <span className="text-destructive">{entry.error_message}</span>
                          : entry.actions_executed?.join(', ') || '\u2014'}
                      </td>
                    </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
            {/* Pagination */}
            <div className="flex items-center justify-end gap-2 mt-3">
              <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => setOffset((o) => Math.max(0, o - PAGE_SIZE))}>
                <ChevronLeft className="h-4 w-4 mr-1" /> Prev
              </Button>
              <Button variant="outline" size="sm" disabled={!hasMore} onClick={() => setOffset((o) => o + PAGE_SIZE)}>
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
