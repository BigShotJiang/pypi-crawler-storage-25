'use client'

import { ChevronLeft, ChevronRight, Plus, Trash2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import type { TriplePanelLayoutApi } from '@/components/layout/ResizableTriplePanelLayout'
import type { UseDiscoveryInstancesResult } from '@/hooks/useDiscoveryInstances'

function instanceInitial(label: string): string {
  const t = label.trim()
  if (!t) return '?'
  return t.charAt(0).toUpperCase()
}

function formatRelative(iso: string): string {
  const t = Date.parse(iso)
  if (Number.isNaN(t)) return ''
  const deltaSec = Math.floor((Date.now() - t) / 1000)
  if (deltaSec < 60) return 'just now'
  if (deltaSec < 3600) return `${Math.floor(deltaSec / 60)}m ago`
  if (deltaSec < 86_400) return `${Math.floor(deltaSec / 3600)}h ago`
  return `${Math.floor(deltaSec / 86_400)}d ago`
}

export interface DiscoveryInstancesPanelProps {
  api: TriplePanelLayoutApi
  instancesHook: UseDiscoveryInstancesResult
  focusedInstanceId: string | null
  onFocusInstance: (id: string, homeChannel: string) => void
  onOpenCreateDialog: () => void
}

/**
 * Left-rail panel for the /discovery page.
 *
 * Shows one list of Discovery Instances (persistent, filter-configured
 * consumers of the shared observation stream). Clicking a row focuses
 * the instance; the middle column loads its builds and the right
 * workspace loads the current filter preview.
 */
export function DiscoveryInstancesPanel({
  api,
  instancesHook,
  focusedInstanceId,
  onFocusInstance,
  onOpenCreateDialog,
}: DiscoveryInstancesPanelProps) {
  const isCollapsed = api.isPanelCollapsed
  const isCompact = api.panelDisplayMode === 'compact'
  const showLabels = !isCollapsed && !isCompact
  const { instances, loading, error, removeInstance } = instancesHook

  if (isCollapsed) {
    return (
      <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
        <div className="flex h-12 min-h-12 shrink-0 items-center justify-center gap-2 border-b border-border/50 bg-muted/30 px-4 py-0">
          <button
            type="button"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
            aria-label="Expand panel"
            onClick={() => api.onExpandRequested()}
          >
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
        <div className="flex shrink-0 justify-center border-b border-border/50 px-1 py-2">
          <Button
            type="button"
            variant="outline"
            size="icon"
            className="h-8 w-8 shrink-0"
            title="New discovery instance"
            aria-label="New discovery instance"
            onClick={onOpenCreateDialog}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex min-h-0 flex-1 flex-col items-center gap-2 overflow-y-auto px-1 py-2">
          {instances.map((inst) => {
            const active = inst.id === focusedInstanceId
            const label = inst.title?.trim() || inst.home_channel
            return (
              <Button
                key={inst.id}
                type="button"
                variant={active ? 'default' : 'outline'}
                size="icon"
                className="h-8 w-8 shrink-0 rounded-full text-xs font-semibold"
                title={`${label} · ${inst.home_channel}`}
                aria-label={`Focus instance ${label}`}
                aria-pressed={active}
                onClick={() => onFocusInstance(inst.id, inst.home_channel)}
              >
                {instanceInitial(label)}
              </Button>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className="flex h-full min-h-0 flex-col border-r border-border/50 bg-muted/20">
      <div className="flex h-12 min-h-12 shrink-0 items-center justify-between gap-2 border-b border-border/50 bg-muted/30 px-4 py-0">
        {showLabels ? (
          <span className="truncate px-1 text-xs font-semibold uppercase leading-none tracking-wide text-muted-foreground">
            Instances
          </span>
        ) : null}
        <div className="flex items-center gap-1">
          <button
            type="button"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
            title="New discovery instance"
            aria-label="New discovery instance"
            onClick={onOpenCreateDialog}
          >
            <Plus className="h-4 w-4 text-muted-foreground" />
          </button>
          <button
            type="button"
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md transition-colors hover:bg-muted"
            aria-label="Collapse panel"
            onClick={() => api.onCollapseRequested()}
          >
            <ChevronLeft className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
      </div>

      {error ? (
        <div className="shrink-0 border-b border-border/50 px-3 py-2">
          <p className="text-xs text-destructive" role="alert">
            {error}
          </p>
        </div>
      ) : null}

      <div className="min-h-0 flex-1 overflow-y-auto p-2">
        {loading && instances.length === 0 ? (
          <p className="px-2 py-4 text-center text-sm text-muted-foreground">
            Loading instances…
          </p>
        ) : instances.length === 0 ? (
          <p className="px-2 py-4 text-center text-sm text-muted-foreground">
            No discovery instances yet. Click <Plus className="inline h-3 w-3" />{' '}
            to create one.
          </p>
        ) : (
          <ul className="space-y-1">
            {instances.map((inst) => {
              const active = inst.id === focusedInstanceId
              const label = inst.title?.trim() || 'Untitled instance'
              return (
                <li key={inst.id}>
                  <div
                    className={cn(
                      'flex items-start gap-1 rounded-md border px-2 py-2 text-left text-sm transition-colors',
                      active
                        ? 'border-primary bg-primary/10'
                        : 'border-border/60 bg-background hover:bg-muted/50'
                    )}
                  >
                    <button
                      type="button"
                      className="min-w-0 flex-1 text-left"
                      onClick={() => onFocusInstance(inst.id, inst.home_channel)}
                    >
                      <div className="truncate font-medium">{label}</div>
                      <div className="truncate text-xs text-muted-foreground">
                        channel: <span className="font-mono">{inst.home_channel}</span>
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-1 text-[11px] text-muted-foreground">
                        <span className="rounded bg-muted px-1.5 py-0.5">
                          {inst.filter_summary}
                        </span>
                        <span>·</span>
                        <span>
                          {inst.built_count} {inst.built_count === 1 ? 'build' : 'builds'}
                        </span>
                        <span>·</span>
                        <span>{formatRelative(inst.updated_at)}</span>
                      </div>
                    </button>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
                      aria-label={`Delete instance ${label}`}
                      title="Delete instance"
                      onClick={() =>
                        void removeInstance({
                          id: inst.id,
                          homeChannel: inst.home_channel,
                        })
                      }
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </div>
  )
}
