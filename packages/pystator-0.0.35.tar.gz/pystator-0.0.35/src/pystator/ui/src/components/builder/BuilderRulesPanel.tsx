"use client"

import { useBuilderStore } from "@/stores/builder"
import { Button } from "@/components/ui/button"
import { RuleCard } from "./RuleCard"

/**
 * Lists all builder rules and provides controls to add new ones.
 * Each rule is rendered as a visual RuleCard that reads like English.
 */
export function BuilderRulesPanel() {
  const rules = useBuilderStore((s) => s.rules)
  const states = useBuilderStore((s) => s.states)
  const variables = useBuilderStore((s) => s.variables)

  const addRule = useBuilderStore((s) => s.addRule)
  const updateRule = useBuilderStore((s) => s.updateRule)
  const removeRule = useBuilderStore((s) => s.removeRule)
  const addCondition = useBuilderStore((s) => s.addCondition)
  const updateCondition = useBuilderStore((s) => s.updateCondition)
  const removeCondition = useBuilderStore((s) => s.removeCondition)
  const addAction = useBuilderStore((s) => s.addAction)
  const updateAction = useBuilderStore((s) => s.updateAction)
  const removeAction = useBuilderStore((s) => s.removeAction)

  const stateNames = states.map((s) => s.name)
  const variableKeys = variables.map((v) => v.key)

  if (rules.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 py-12 text-center">
        <p className="text-sm text-muted-foreground">
          No rules yet. Rules define how your state machine transitions between
          states based on conditions and actions.
        </p>
        <Button onClick={addRule}>Add your first rule</Button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {rules.map((rule) => (
        <RuleCard
          key={rule.id}
          rule={rule}
          stateNames={stateNames}
          variableKeys={variableKeys}
          onUpdate={(patch) => updateRule(rule.id, patch)}
          onRemove={() => removeRule(rule.id)}
          onAddCondition={() => addCondition(rule.id)}
          onUpdateCondition={(condId, patch) =>
            updateCondition(rule.id, condId, patch)
          }
          onRemoveCondition={(condId) => removeCondition(rule.id, condId)}
          onAddAction={() => addAction(rule.id)}
          onUpdateAction={(actId, patch) =>
            updateAction(rule.id, actId, patch)
          }
          onRemoveAction={(actId) => removeAction(rule.id, actId)}
        />
      ))}

      <div className="flex justify-center pt-2">
        <Button variant="outline" onClick={addRule}>
          + Add Rule
        </Button>
      </div>
    </div>
  )
}
