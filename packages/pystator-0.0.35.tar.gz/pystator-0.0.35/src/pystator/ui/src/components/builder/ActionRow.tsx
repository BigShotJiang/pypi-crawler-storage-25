"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import type { BuilderAction } from "@/stores/builder"
import { ACTION_TYPE_LABELS } from "@/lib/builder/constants"

interface ActionRowProps {
  action: BuilderAction
  variableKeys: string[]
  onChange: (patch: Partial<BuilderAction>) => void
  onRemove: () => void
}

const ACTION_TYPE_KEYS = Object.keys(ACTION_TYPE_LABELS) as BuilderAction["type"][]

/** Types where only a field selector is needed (no value). */
const FIELD_ONLY_TYPES = new Set(["timestamp", "increment", "decrement", "clear"])

function ActionFields({
  action,
  variableKeys,
  onChange,
}: {
  action: BuilderAction
  variableKeys: string[]
  onChange: (patch: Partial<BuilderAction>) => void
}) {
  switch (action.type) {
    case "set":
      return (
        <>
          <Input
            className="h-9 w-28"
            placeholder="field"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
          <span className="text-xs text-muted-foreground">=</span>
          <Input
            className="h-9 w-28"
            placeholder="value"
            value={action.value ?? ""}
            onChange={(e) => onChange({ value: e.target.value })}
          />
        </>
      )

    case "append":
      return (
        <>
          <Input
            className="h-9 w-28"
            placeholder="field"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
          <Input
            className="h-9 w-28"
            placeholder="value"
            value={action.value ?? ""}
            onChange={(e) => onChange({ value: e.target.value })}
          />
        </>
      )

    case "compute":
      return (
        <>
          <Input
            className="h-9 w-28"
            placeholder="result key"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
          <span className="text-xs text-muted-foreground">=</span>
          <Input
            className="h-9 flex-1 min-w-[120px]"
            placeholder="expression"
            value={action.value ?? ""}
            onChange={(e) => onChange({ value: e.target.value })}
          />
        </>
      )

    case "named":
      return (
        <Input
          className="h-9 w-40"
          placeholder="action name"
          value={action.value ?? ""}
          onChange={(e) => onChange({ value: e.target.value })}
        />
      )

    case "http":
      return (
        <textarea
          className="h-16 flex-1 min-w-[160px] rounded-md border border-input bg-background px-2 py-1 text-xs font-mono resize-y"
          placeholder='{"url": "...", "method": "POST"}'
          value={action.value ?? ""}
          onChange={(e) => onChange({ value: e.target.value })}
        />
      )

    default:
      if (FIELD_ONLY_TYPES.has(action.type)) {
        return (
          <Input
            className="h-9 w-36"
            placeholder="field"
            value={action.field ?? ""}
            onChange={(e) => onChange({ field: e.target.value })}
          />
        )
      }
      return null
  }
}

export function ActionRow({ action, variableKeys, onChange, onRemove }: ActionRowProps) {
  return (
    <div className="flex items-start gap-2 flex-wrap">
      {/* Action type selector */}
      <select
        className="h-9 rounded-md border border-input bg-background px-2 text-sm min-w-[140px]"
        value={action.type}
        onChange={(e) =>
          onChange({ type: e.target.value as BuilderAction["type"], field: "", value: "" })
        }
      >
        {ACTION_TYPE_KEYS.map((key) => (
          <option key={key} value={key}>
            {ACTION_TYPE_LABELS[key]}
          </option>
        ))}
      </select>

      <ActionFields action={action} variableKeys={variableKeys} onChange={onChange} />

      {/* Remove button */}
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={onRemove}
        aria-label="Remove action"
      >
        <span aria-hidden="true">&times;</span>
      </Button>
    </div>
  )
}
