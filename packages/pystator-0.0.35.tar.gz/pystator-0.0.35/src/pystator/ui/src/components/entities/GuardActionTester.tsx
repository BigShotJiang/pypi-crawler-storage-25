'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { dryRunTransition, ApiError } from '@/lib/api'
import type { DryRunResponse } from '@/lib/api'
import { Shield, Play, CheckCircle2, XCircle } from 'lucide-react'

interface GuardActionTesterProps {
  entityId: string
}

interface GuardResult {
  passed: boolean
  error?: string
}

/** Simple client-side evaluation for guard expressions (e.g. `expr:qty > 0`). */
function evaluateGuardLocally(expression: string, context: Record<string, unknown>): GuardResult {
  let expr = expression.trim()
  if (expr.startsWith('expr:')) {
    expr = expr.slice(5).trim()
  }
  if (!expr) {
    return { passed: false, error: 'Empty expression' }
  }
  try {
    const keys = Object.keys(context)
    const values = Object.values(context)
    const fn = new Function(...keys, `return Boolean(${expr})`)
    const result = fn(...values)
    return { passed: Boolean(result) }
  } catch (e) {
    return { passed: false, error: e instanceof Error ? e.message : String(e) }
  }
}

export default function GuardActionTester({ entityId }: GuardActionTesterProps) {
  // Guard test state
  const [guardExpr, setGuardExpr] = useState('')
  const [guardContext, setGuardContext] = useState('{}')
  const [guardResult, setGuardResult] = useState<GuardResult | null>(null)
  const [guardError, setGuardError] = useState<string | null>(null)

  // Dry-run state
  const [trigger, setTrigger] = useState('')
  const [dryContext, setDryContext] = useState('{}')
  const [dryResult, setDryResult] = useState<DryRunResponse | null>(null)
  const [dryError, setDryError] = useState<string | null>(null)
  const [dryLoading, setDryLoading] = useState(false)

  const handleEvaluateGuard = () => {
    setGuardResult(null)
    setGuardError(null)
    let parsed: Record<string, unknown>
    try {
      parsed = JSON.parse(guardContext)
    } catch {
      setGuardError('Invalid JSON in context')
      return
    }
    const result = evaluateGuardLocally(guardExpr, parsed)
    if (result.error) {
      setGuardError(result.error)
    }
    setGuardResult(result)
  }

  const handleDryRun = async () => {
    if (!trigger.trim()) return
    setDryResult(null)
    setDryError(null)
    setDryLoading(true)
    let parsed: Record<string, unknown>
    try {
      parsed = JSON.parse(dryContext)
    } catch {
      setDryError('Invalid JSON in context')
      setDryLoading(false)
      return
    }
    try {
      const result = await dryRunTransition(entityId, {
        trigger: trigger.trim(),
        context: parsed,
      })
      setDryResult(result)
    } catch (e) {
      setDryError(e instanceof ApiError ? e.message : e instanceof Error ? e.message : String(e))
    } finally {
      setDryLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      {/* Guard test */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-1.5">
            <Shield className="h-4 w-4" />
            Test Guard
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1">
            <Label className="text-xs">Guard expression</Label>
            <input
              type="text"
              placeholder="e.g. expr:qty > 0"
              className="w-full rounded-md border border-input bg-background px-3 py-1.5 text-sm font-mono"
              value={guardExpr}
              onChange={(e) => setGuardExpr(e.target.value)}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Context JSON</Label>
            <textarea
              rows={2}
              className="w-full rounded-md border border-input bg-background px-3 py-1.5 text-sm font-mono"
              value={guardContext}
              onChange={(e) => setGuardContext(e.target.value)}
            />
          </div>
          <Button size="sm" onClick={handleEvaluateGuard} disabled={!guardExpr.trim()}>
            Evaluate
          </Button>

          {guardResult && (
            <div
              className={`flex items-center gap-2 rounded border px-3 py-2 text-sm ${
                guardResult.passed
                  ? 'border-emerald-300 bg-emerald-50 dark:border-emerald-700 dark:bg-emerald-950/30'
                  : 'border-destructive/50 bg-destructive/10'
              }`}
            >
              {guardResult.passed ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <XCircle className="h-4 w-4 text-destructive" />
              )}
              {guardResult.passed ? 'Guard passed' : 'Guard failed'}
            </div>
          )}
          {guardError && (
            <p className="text-xs text-destructive">{guardError}</p>
          )}
        </CardContent>
      </Card>

      {/* Dry-run transition */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-1.5">
            <Play className="h-4 w-4" />
            Test Transition (Dry Run)
          </CardTitle>
          <p className="text-xs text-muted-foreground leading-snug">
            Preview only: dry-run does not persist state or run transition actions. Use Send
            Event on the entity page to run the real transition (including side effects).
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="space-y-1">
            <Label className="text-xs">Trigger</Label>
            <input
              type="text"
              placeholder="e.g. submit"
              className="w-full rounded-md border border-input bg-background px-3 py-1.5 text-sm"
              value={trigger}
              onChange={(e) => setTrigger(e.target.value)}
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Context JSON</Label>
            <textarea
              rows={2}
              className="w-full rounded-md border border-input bg-background px-3 py-1.5 text-sm font-mono"
              value={dryContext}
              onChange={(e) => setDryContext(e.target.value)}
            />
          </div>
          <Button size="sm" onClick={handleDryRun} disabled={dryLoading || !trigger.trim()}>
            {dryLoading ? 'Running...' : 'Run'}
          </Button>

          {dryResult && (
            <div
              className={`rounded border p-3 text-sm ${
                dryResult.would_succeed
                  ? 'border-emerald-300 bg-emerald-50 dark:border-emerald-700 dark:bg-emerald-950/30'
                  : 'border-destructive/50 bg-destructive/10'
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                {dryResult.would_succeed ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <XCircle className="h-4 w-4 text-destructive" />
                )}
                <span className="font-medium">
                  {dryResult.would_succeed ? 'Would succeed' : 'Would fail'}
                </span>
              </div>
              <dl className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-xs mt-2">
                <dt className="text-muted-foreground">Source</dt>
                <dd className="font-mono">{dryResult.source_state}</dd>
                <dt className="text-muted-foreground">Target</dt>
                <dd className="font-mono">{dryResult.target_state ?? '--'}</dd>
                {dryResult.actions_that_would_execute.length > 0 && (
                  <>
                    <dt className="text-muted-foreground">Actions</dt>
                    <dd className="font-mono">
                      {dryResult.actions_that_would_execute.join(', ')}
                    </dd>
                  </>
                )}
              </dl>
              {dryResult.error_detail && (
                <p className="text-xs text-destructive mt-1">{dryResult.error_detail}</p>
              )}
            </div>
          )}
          {dryError && !dryResult && (
            <p className="text-xs text-destructive">{dryError}</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
