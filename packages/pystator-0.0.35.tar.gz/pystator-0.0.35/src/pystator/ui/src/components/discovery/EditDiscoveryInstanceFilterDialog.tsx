'use client'

import { useCallback, useEffect, useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import type { DiscoveryDraftFilterInput } from '@/lib/api'
import {
  DiscoveryFilterBuilder,
  EMPTY_FILTER,
  filterHasAnyDimension,
} from './DiscoveryFilterBuilder'

export interface EditDiscoveryInstanceFilterDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  initialFilter: DiscoveryDraftFilterInput | null
  onSave: (filter: DiscoveryDraftFilterInput | null) => Promise<void>
  instanceTitle: string
}

/**
 * Dialog for retrospectively editing a Discovery Instance's filter.
 *
 * Saving an empty filter clears the filter on the draft (the backend
 * treats this as "read all events"). Reuses the shared
 * :mod:`DiscoveryFilterBuilder` with the create dialog.
 */
export function EditDiscoveryInstanceFilterDialog({
  open,
  onOpenChange,
  initialFilter,
  onSave,
  instanceTitle,
}: EditDiscoveryInstanceFilterDialogProps) {
  const [filter, setFilter] = useState<DiscoveryDraftFilterInput>(EMPTY_FILTER)
  const [submitting, setSubmitting] = useState<boolean>(false)

  useEffect(() => {
    if (open) {
      setFilter(initialFilter ?? EMPTY_FILTER)
      setSubmitting(false)
    }
  }, [open, initialFilter])

  const handleSave = useCallback(async () => {
    setSubmitting(true)
    try {
      await onSave(filterHasAnyDimension(filter) ? filter : null)
      onOpenChange(false)
    } finally {
      setSubmitting(false)
    }
  }, [filter, onOpenChange, onSave])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit filter · {instanceTitle}</DialogTitle>
          <DialogDescription>
            Retrospectively change which observations this instance
            reads. An empty filter reads all events across all
            channels.
          </DialogDescription>
        </DialogHeader>

        <div className="py-2">
          <DiscoveryFilterBuilder value={filter} onChange={setFilter} />
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="button"
            disabled={submitting}
            onClick={() => void handleSave()}
          >
            Save filter
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
