"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import type { BuilderCondition } from "@/stores/builder"
import {
  CHECK_OP_LABELS,
  CHECK_OP_KEYS,
  UNARY_OPS,
} from "@/lib/builder/constants"

interface ConditionRowProps {
  condition: BuilderCondition
  variableKeys: string[]
  onChange: (patch: Partial<BuilderCondition>) => void
  onRemove: () => void
  isFirst: boolean
  logic: "all" | "any"
}

export function ConditionRow({
  condition,
  variableKeys,
  onChange,
  onRemove,
  isFirst,
  logic,
}: ConditionRowProps) {
  const label = isFirst ? "IF" : logic === "all" ? "AND" : "OR"
  const isUnary = UNARY_OPS.has(condition.operator)

  return (
    <div className="flex items-center gap-2">
      <span className="w-10 shrink-0 text-xs font-semibold text-muted-foreground uppercase">
        {label}
      </span>

      {/* Field selector */}
      <select
        className="h-9 rounded-md border border-input bg-background px-2 text-sm min-w-[120px]"
        value={condition.field}
        onChange={(e) => onChange({ field: e.target.value })}
      >
        <option value="">Select field...</option>
        {variableKeys.map((key) => (
          <option key={key} value={key}>
            {key}
          </option>
        ))}
      </select>

      {/* Operator selector */}
      <select
        className="h-9 rounded-md border border-input bg-background px-2 text-sm min-w-[140px]"
        value={condition.operator}
        onChange={(e) => onChange({ operator: e.target.value })}
      >
        {CHECK_OP_KEYS.map((op) => (
          <option key={op} value={op}>
            {CHECK_OP_LABELS[op]}
          </option>
        ))}
      </select>

      {/* Value input (hidden for unary operators) */}
      {!isUnary && (
        <Input
          className="h-9 w-28"
          placeholder="value"
          value={condition.value}
          onChange={(e) => onChange({ value: e.target.value })}
        />
      )}

      {/* Remove button */}
      <Button
        variant="ghost"
        size="icon"
        className="h-8 w-8 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={onRemove}
        aria-label="Remove condition"
      >
        <span aria-hidden="true">&times;</span>
      </Button>
    </div>
  )
}
