'use client'

import { useBuilderStore, type BuilderStep } from '@/stores/builder'
import { cn } from '@/lib/utils'

const TABS: { step: BuilderStep; label: string }[] = [
  { step: 'variables', label: '1. Variables' },
  { step: 'states', label: '2. States' },
  { step: 'rules', label: '3. Rules' },
]

export function BuilderStepTabs() {
  const activeStep = useBuilderStore((s) => s.activeStep)
  const ruleCount = useBuilderStore((s) => s.rules.length)
  const setActiveStep = useBuilderStore((s) => s.setActiveStep)

  return (
    <div className="flex shrink-0 gap-1 border-b border-border/50 px-3 py-2">
      {TABS.map(({ step, label }) => (
        <button
          key={step}
          type="button"
          onClick={() => setActiveStep(step)}
          className={cn(
            'relative rounded-full px-3 py-1 text-xs font-medium transition-colors',
            activeStep === step
              ? 'bg-primary text-primary-foreground'
              : 'text-muted-foreground hover:bg-muted hover:text-foreground',
          )}
        >
          {label}
          {step === 'rules' && ruleCount > 0 && (
            <span className="ml-1.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-primary/20 px-1 text-[10px] font-semibold text-primary">
              {ruleCount}
            </span>
          )}
        </button>
      ))}
    </div>
  )
}
