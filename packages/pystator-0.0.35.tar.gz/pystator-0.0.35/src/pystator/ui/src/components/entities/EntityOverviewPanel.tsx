'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { BarChart3, ChevronDown, ChevronUp } from 'lucide-react'

/** Workflow totals scoped by machine/state/terminal filters (all lifecycle rows). */
export interface EntityWorkflowOverview {
  inProgress: number
  complete: number
  failed: number
}

interface EntityOverviewPanelProps {
  total: number
  workflow: EntityWorkflowOverview | null
  /** When true, the collapsible overview starts open. */
  defaultExpanded?: boolean
}

function fmt(n: number | null): string {
  if (n === null) return '—'
  return n.toLocaleString()
}

export default function EntityOverviewPanel({
  total,
  workflow,
  defaultExpanded = false,
}: EntityOverviewPanelProps) {
  const [expanded, setExpanded] = useState(defaultExpanded)

  const inProgress = workflow?.inProgress ?? null
  const complete = workflow?.complete ?? null
  const failed = workflow?.failed ?? null

  return (
    <Card>
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center justify-between px-4 py-3 text-sm font-medium hover:bg-muted/30 transition-colors rounded-t-lg"
      >
        <span className="flex items-center gap-2">
          <BarChart3 className="h-4 w-4 text-muted-foreground" />
          Overview
          <span className="text-muted-foreground font-normal">({total.toLocaleString()} total)</span>
        </span>
        {expanded ? (
          <ChevronUp className="h-4 w-4 text-muted-foreground" />
        ) : (
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        )}
      </button>

      {expanded && (
        <CardContent className="pt-0 pb-4 space-y-4">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Workflow (FSM)</p>
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-sky-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">In progress</span>
              </div>
              <p className="text-lg font-semibold text-sky-600 dark:text-sky-400">{fmt(inProgress)}</p>
            </div>
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-emerald-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Complete</span>
              </div>
              <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">{fmt(complete)}</p>
            </div>
            <div className="rounded-lg border p-3 text-center">
              <div className="flex items-center justify-center gap-1.5 mb-1">
                <span className="h-2 w-2 rounded-full bg-red-500" />
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Failed</span>
              </div>
              <p className="text-lg font-semibold text-red-600 dark:text-red-400">{fmt(failed)}</p>
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  )
}
