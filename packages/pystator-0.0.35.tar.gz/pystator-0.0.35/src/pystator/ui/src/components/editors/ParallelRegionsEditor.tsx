'use client'

import { useCallback, useMemo } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { FSMRegion, FSMState } from '@/lib/types/fsm'
import { childStatesForParent, PARALLEL_STATES_DOC_PATH } from '@/lib/fsm/regionUtils'
import { Plus, Trash2 } from 'lucide-react'

export interface ParallelRegionsEditorProps {
  /** Normalized name of the parallel state being edited (used to filter child states). */
  parallelStateName: string
  regions: FSMRegion[]
  onChange: (regions: FSMRegion[]) => void
  allStates: FSMState[]
}

function emptyRow(): FSMRegion {
  return { name: '', initial: '' }
}

export default function ParallelRegionsEditor({
  parallelStateName,
  regions,
  onChange,
  allStates,
}: ParallelRegionsEditorProps) {
  const childStates = useMemo(
    () => childStatesForParent(parallelStateName, allStates),
    [parallelStateName, allStates]
  )

  const allStateNamesSorted = useMemo(() => {
    return [...allStates.map((s) => s.name)].sort((a, b) => a.localeCompare(b))
  }, [allStates])

  const updateRow = useCallback(
    (index: number, patch: Partial<FSMRegion>) => {
      const next = regions.map((r, i) => (i === index ? { ...r, ...patch } : r))
      onChange(next)
    },
    [regions, onChange]
  )

  const removeRow = useCallback(
    (index: number) => {
      const next = regions.filter((_, i) => i !== index)
      onChange(next.length > 0 ? next : [emptyRow()])
    },
    [regions, onChange]
  )

  const addRow = useCallback(() => {
    onChange([...regions, emptyRow()])
  }, [regions, onChange])

  const initialOptions =
    childStates.length > 0
      ? childStates.map((s) => s.name)
      : allStateNamesSorted

  return (
    <div className="space-y-3">
      <div className="space-y-1">
        <p className="text-sm font-medium">Parallel State Regions ⊞</p>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Each region is an orthogonal sub-machine. Region names must be unique across the whole machine.
          Transitions inside a parallel parent often set <span className="font-mono">region</span> to scope
          which sub-machine handles the event.
        </p>
        <p className="text-xs text-muted-foreground font-mono break-all">{PARALLEL_STATES_DOC_PATH}</p>
      </div>

      {childStates.length === 0 && parallelStateName ? (
        <p className="text-xs text-amber-700 dark:text-amber-300/90">
          No child states list this parallel state as Parent yet. Initial dropdown lists all states; set each
          child state&apos;s Parent to <span className="font-mono">{parallelStateName}</span> and add them to{' '}
          <span className="font-mono">regions[].states</span> in YAML or keep using the diagram hierarchy as you
          prefer.
        </p>
      ) : null}

      <div className="space-y-3">
        {regions.map((row, index) => (
          <div
            key={index}
            className="rounded-md border border-border/80 bg-muted/20 px-3 py-2 space-y-2"
          >
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <Label className="text-xs">Region name</Label>
                <Input
                  className="h-9"
                  placeholder="e.g. trading"
                  value={row.name}
                  onChange={(e) => updateRow(index, { name: e.target.value })}
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Initial state</Label>
                <select
                  className="flex h-9 w-full rounded-md border border-input bg-background px-2 py-1 text-sm"
                  value={row.initial}
                  onChange={(e) => updateRow(index, { initial: e.target.value })}
                  disabled={initialOptions.length === 0}
                >
                  <option value="">{initialOptions.length === 0 ? 'Add states first' : 'Select…'}</option>
                  {initialOptions.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Description (optional)</Label>
              <Input
                className="h-9"
                placeholder="Short note for this region"
                value={row.description ?? ''}
                onChange={(e) =>
                  updateRow(index, {
                    description: e.target.value || undefined,
                  })
                }
              />
            </div>
            <div className="flex justify-end">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 text-destructive hover:text-destructive"
                onClick={() => removeRow(index)}
                aria-label="Remove region"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      <Button type="button" variant="outline" size="sm" className="h-8" onClick={addRow}>
        <Plus className="h-4 w-4 mr-1" />
        Add region
      </Button>
    </div>
  )
}
