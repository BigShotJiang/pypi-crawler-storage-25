'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useDatabaseConfig } from '@/hooks'
import type { DatabaseTestRequest } from '@/lib/api'
import { cn } from '@/lib/utils'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface DatabaseConfigCardProps {
  connectionString: string
  host: string
  port: string
  database: string
  username: string
  password: string
  onConnectionStringChange: (v: string) => void
  onHostChange: (v: string) => void
  onPortChange: (v: string) => void
  onDatabaseChange: (v: string) => void
  onUsernameChange: (v: string) => void
  onPasswordChange: (v: string) => void
  compact?: boolean
}

export function DatabaseConfigCard({
  connectionString,
  host,
  port,
  database,
  username,
  password,
  onConnectionStringChange,
  onHostChange,
  onPortChange,
  onDatabaseChange,
  onUsernameChange,
  onPasswordChange,
  compact,
}: DatabaseConfigCardProps) {
  const { config: dbConfig, testing, testResult, test } = useDatabaseConfig()

  const handleTest = () => {
    const body: DatabaseTestRequest = {
      connection_string: connectionString || undefined,
      host: host || undefined,
      port: port ? parseInt(port, 10) : undefined,
      database: database || undefined,
      username: username || undefined,
      password: password || undefined,
    }
    test(body)
  }

  return (
    <Card id="database" className="scroll-mt-28">
      <CardHeader className={cn(compact && 'space-y-1 p-4 pb-2')}>
        <CardTitle className={cn(compact && 'text-base')}>Database (test & tools)</CardTitle>
        <CardDescription className={cn(compact && 'text-xs leading-snug')}>
          Credentials here are only for <strong>Test connection</strong> from this browser. The live API
          uses <code className="text-[11px]">PYSTATOR_DATABASE_URL</code> on the server (see overview
          above).
        </CardDescription>
      </CardHeader>
      <CardContent className={cn('space-y-3', compact && 'p-4 pt-0')}>
        {dbConfig && (
          <div
            className={cn(
              'rounded-md bg-muted/50 px-2 py-1.5 text-muted-foreground',
              compact ? 'text-xs' : 'text-sm px-3 py-2',
            )}
          >
            {dbConfig.message}
            {dbConfig.machine_count >= 0 && (
              <span className="ml-2">Machines: {dbConfig.machine_count}</span>
            )}
          </div>
        )}
        <div className={cn('space-y-2', compact && 'space-y-1')}>
          <Label htmlFor="db-connection-string" className={cn(compact && 'text-xs')}>
            Connection string
          </Label>
          <Input
            id="db-connection-string"
            type="text"
            className={cn(compact && 'h-8 text-sm')}
            value={connectionString}
            onChange={(e) => onConnectionStringChange(e.target.value)}
            placeholder="postgresql://user:password@host:5432/pystator or sqlite:///pystator.db"
          />
        </div>
        <div className={cn('grid grid-cols-2 gap-3', compact && 'gap-2')}>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="db-host" className={cn(compact && 'text-xs')}>
              Host
            </Label>
            <Input
              id="db-host"
              type="text"
              className={cn(compact && 'h-8 text-sm')}
              value={host}
              onChange={(e) => onHostChange(e.target.value)}
              placeholder="localhost"
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="db-port" className={cn(compact && 'text-xs')}>
              Port
            </Label>
            <Input
              id="db-port"
              type="number"
              className={cn(compact && 'h-8 text-sm')}
              value={port}
              onChange={(e) => onPortChange(e.target.value)}
              placeholder="5432"
            />
          </div>
        </div>
        <div className={cn('space-y-2', compact && 'space-y-1')}>
          <Label htmlFor="db-name" className={cn(compact && 'text-xs')}>
            Database
          </Label>
          <Input
            id="db-name"
            type="text"
            className={cn(compact && 'h-8 text-sm')}
            value={database}
            onChange={(e) => onDatabaseChange(e.target.value)}
            placeholder="pystator"
          />
        </div>
        <div className={cn('grid grid-cols-2 gap-3', compact && 'gap-2')}>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="db-username" className={cn(compact && 'text-xs')}>
              Username
            </Label>
            <Input
              id="db-username"
              type="text"
              className={cn(compact && 'h-8 text-sm')}
              value={username}
              onChange={(e) => onUsernameChange(e.target.value)}
              placeholder="user"
            />
          </div>
          <div className={cn('space-y-2', compact && 'space-y-1')}>
            <Label htmlFor="db-password" className={cn(compact && 'text-xs')}>
              Password
            </Label>
            <Input
              id="db-password"
              type="password"
              className={cn(compact && 'h-8 text-sm')}
              value={password}
              onChange={(e) => onPasswordChange(e.target.value)}
              placeholder="••••••••"
            />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size={compact ? 'sm' : 'default'}
            onClick={handleTest}
            disabled={testing}
          >
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test connection'
            )}
          </Button>
          {testResult && (
            <span className={cn('inline-flex items-center gap-1', compact ? 'text-xs' : 'text-sm')}>
              {testResult.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {testResult.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
