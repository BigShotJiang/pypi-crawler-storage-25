'use client'

import { useState, useCallback } from 'react'
import { PlusCircle, FolderOpen, Search, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useBuilderStore } from '@/stores/builder'
import { listMachines, getMachine } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'

export function BuilderStartScreen() {
  const reset = useBuilderStore((s) => s.reset)
  const setActiveStep = useBuilderStore((s) => s.setActiveStep)
  const loadFromConfig = useBuilderStore((s) => s.loadFromConfig)

  const [browsing, setBrowsing] = useState(false)
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [search, setSearch] = useState('')

  const handleCreateNew = useCallback(() => {
    reset()
    setActiveStep('variables')
  }, [reset, setActiveStep])

  const handleBrowse = useCallback(async () => {
    setBrowsing(true)
    setLoading(true)
    setError(null)
    try {
      const resp = await listMachines()
      setMachines(resp.machines)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load machines')
    } finally {
      setLoading(false)
    }
  }, [])

  const handleSelect = useCallback(
    async (machine: MachineListItem) => {
      setLoading(true)
      setError(null)
      try {
        const resp = await getMachine(machine.id)
        loadFromConfig(resp.config, resp.id)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load machine')
      } finally {
        setLoading(false)
      }
    },
    [loadFromConfig],
  )

  const filtered = machines.filter(
    (m) =>
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      (m.description ?? '').toLowerCase().includes(search.toLowerCase()),
  )

  if (browsing) {
    return (
      <div className="flex flex-col gap-3">
        <Button
          variant="ghost"
          size="sm"
          className="self-start -ml-2 text-xs text-muted-foreground"
          onClick={() => setBrowsing(false)}
        >
          &larr; Back
        </Button>

        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search machines..."
            className="h-8 pl-8 text-sm"
          />
        </div>

        {loading && (
          <div className="flex items-center justify-center py-6">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        )}

        {error && (
          <p className="text-sm text-destructive">{error}</p>
        )}

        {!loading && filtered.length === 0 && (
          <p className="py-4 text-center text-sm text-muted-foreground">
            No machines found.
          </p>
        )}

        <div className="flex flex-col gap-1">
          {filtered.map((m) => (
            <button
              key={m.id}
              type="button"
              onClick={() => handleSelect(m)}
              className="flex flex-col gap-0.5 rounded-md border border-border/50 px-3 py-2 text-left transition-colors hover:bg-muted/50"
            >
              <span className="text-sm font-medium text-foreground truncate">
                {m.name}
              </span>
              <span className="text-xs text-muted-foreground truncate">
                v{m.version}
                {m.description ? ` \u2014 ${m.description}` : ''}
              </span>
            </button>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col items-center gap-4 pt-8">
      <p className="text-sm text-muted-foreground text-center">
        Build a state machine step by step.
      </p>

      <div className="flex w-full flex-col gap-3">
        <Button
          variant="outline"
          className="h-auto w-full flex-col items-center gap-2 py-6"
          onClick={handleCreateNew}
        >
          <PlusCircle className="h-8 w-8 text-primary" />
          <span className="text-sm font-medium">Create New Machine</span>
        </Button>

        <Button
          variant="outline"
          className="h-auto w-full flex-col items-center gap-2 py-6"
          onClick={handleBrowse}
        >
          <FolderOpen className="h-8 w-8 text-muted-foreground" />
          <span className="text-sm font-medium">Load Existing Machine</span>
        </Button>
      </div>
    </div>
  )
}
