"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import type {
  BuilderRule,
  BuilderCondition,
  BuilderAction,
} from "@/stores/builder"
import { ConditionRow } from "./ConditionRow"
import { ActionRow } from "./ActionRow"

// ---------------------------------------------------------------------------
// Props
// ---------------------------------------------------------------------------

interface RuleCardProps {
  rule: BuilderRule
  stateNames: string[]
  variableKeys: string[]
  onUpdate: (patch: Partial<BuilderRule>) => void
  onRemove: () => void
  onAddCondition: () => void
  onUpdateCondition: (condId: string, patch: Partial<BuilderCondition>) => void
  onRemoveCondition: (condId: string) => void
  onAddAction: () => void
  onUpdateAction: (actId: string, patch: Partial<BuilderAction>) => void
  onRemoveAction: (actId: string) => void
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------

export function RuleCard({
  rule,
  stateNames,
  variableKeys,
  onUpdate,
  onRemove,
  onAddCondition,
  onUpdateCondition,
  onRemoveCondition,
  onAddAction,
  onUpdateAction,
  onRemoveAction,
}: RuleCardProps) {
  return (
    <Card className="border border-border/60">
      <CardContent className="space-y-4 pt-5">
        {/* ── Source state ────────────────────────────────── */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
            When in state:
          </span>
          <select
            className="h-9 rounded-md border border-input bg-background px-2 text-sm min-w-[140px]"
            value={rule.sourceState}
            onChange={(e) => onUpdate({ sourceState: e.target.value })}
          >
            <option value="">Select state...</option>
            {stateNames.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        {/* ── Conditions ─────────────────────────────────── */}
        <div className="space-y-2 pl-4 border-l-2 border-muted">
          {rule.conditions.map((cond, idx) => (
            <ConditionRow
              key={cond.id}
              condition={cond}
              variableKeys={variableKeys}
              onChange={(patch) => onUpdateCondition(cond.id, patch)}
              onRemove={() => onRemoveCondition(cond.id)}
              isFirst={idx === 0}
              logic={rule.conditionLogic}
            />
          ))}

          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="text-xs"
              onClick={onAddCondition}
            >
              + Add condition
            </Button>

            {rule.conditions.length > 1 && (
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-muted-foreground">Logic:</span>
                <select
                  className="h-8 rounded-md border border-input bg-background px-2 text-xs"
                  value={rule.conditionLogic}
                  onChange={(e) =>
                    onUpdate({
                      conditionLogic: e.target.value as "all" | "any",
                    })
                  }
                >
                  <option value="all">All must match</option>
                  <option value="any">Any can match</option>
                </select>
              </div>
            )}
          </div>
        </div>

        {/* ── Target state ───────────────────────────────── */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
            Then move to:
          </span>
          <select
            className="h-9 rounded-md border border-input bg-background px-2 text-sm min-w-[140px]"
            value={rule.targetState}
            onChange={(e) => onUpdate({ targetState: e.target.value })}
          >
            <option value="">Select state...</option>
            {stateNames.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        {/* ── Actions ────────────────────────────────────── */}
        <div className="space-y-2 pl-4 border-l-2 border-muted">
          <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            And:
          </span>

          {rule.actions.map((act) => (
            <ActionRow
              key={act.id}
              action={act}
              variableKeys={variableKeys}
              onChange={(patch) => onUpdateAction(act.id, patch)}
              onRemove={() => onRemoveAction(act.id)}
            />
          ))}

          <Button
            variant="ghost"
            size="sm"
            className="text-xs"
            onClick={onAddAction}
          >
            + Add action
          </Button>
        </div>

        {/* ── Trigger name + Delete ──────────────────────── */}
        <div className="flex items-center justify-between pt-2 border-t border-border/40">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Trigger:</span>
            <Input
              className="h-8 w-48 text-xs font-mono"
              placeholder="auto_generated"
              value={rule.trigger}
              onChange={(e) => onUpdate({ trigger: e.target.value })}
            />
          </div>

          <Button
            variant="ghost"
            size="sm"
            className="text-xs text-destructive hover:text-destructive"
            onClick={onRemove}
          >
            Delete rule
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
