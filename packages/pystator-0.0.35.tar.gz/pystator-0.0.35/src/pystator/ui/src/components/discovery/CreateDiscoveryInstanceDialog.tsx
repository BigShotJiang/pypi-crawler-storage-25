'use client'

import { useCallback, useEffect, useState } from 'react'
import { Plus } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type {
  DiscoveryDraftFilterInput,
  DiscoveryInstanceSummary,
} from '@/lib/api'
import {
  DiscoveryFilterBuilder,
  EMPTY_FILTER,
  filterHasAnyDimension,
} from './DiscoveryFilterBuilder'

export interface CreateDiscoveryInstanceDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onCreate: (args: {
    homeChannel: string
    title: string
    filter: DiscoveryDraftFilterInput | null
  }) => Promise<DiscoveryInstanceSummary | null>
}

/**
 * Dialog for creating a new Discovery Instance.
 *
 * Required fields: title and home channel (the ``machine_name`` the
 * instance defaults to for publishing). The filter section is
 * optional and collapsed by default — an empty filter means "read
 * all events across all channels".
 */
export function CreateDiscoveryInstanceDialog({
  open,
  onOpenChange,
  onCreate,
}: CreateDiscoveryInstanceDialogProps) {
  const [title, setTitle] = useState<string>('')
  const [homeChannel, setHomeChannel] = useState<string>('')
  const [filter, setFilter] = useState<DiscoveryDraftFilterInput>(EMPTY_FILTER)
  const [showFilter, setShowFilter] = useState<boolean>(false)
  const [submitting, setSubmitting] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)

  // Reset form whenever the dialog closes.
  useEffect(() => {
    if (!open) {
      setTitle('')
      setHomeChannel('')
      setFilter(EMPTY_FILTER)
      setShowFilter(false)
      setError(null)
      setSubmitting(false)
    }
  }, [open])

  const canSubmit =
    !submitting && title.trim().length > 0 && homeChannel.trim().length > 0

  const handleSubmit = useCallback(async () => {
    if (!canSubmit) return
    setSubmitting(true)
    setError(null)
    try {
      const created = await onCreate({
        homeChannel: homeChannel.trim(),
        title: title.trim(),
        filter: filterHasAnyDimension(filter) ? filter : null,
      })
      if (created) {
        onOpenChange(false)
      } else {
        setError('Failed to create instance')
      }
    } finally {
      setSubmitting(false)
    }
  }, [canSubmit, filter, homeChannel, onCreate, onOpenChange, title])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>New discovery instance</DialogTitle>
          <DialogDescription>
            An instance is a named, filter-configured consumer of the
            shared observation stream. Multiple instances can read the
            same raw events with different filters.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-2">
          <div className="space-y-1">
            <Label htmlFor="cdi-title" className="text-xs">
              Instance name
            </Label>
            <Input
              id="cdi-title"
              placeholder="Happy path orders"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              autoFocus
            />
          </div>

          <div className="space-y-1">
            <Label htmlFor="cdi-home-channel" className="text-xs">
              Home channel
            </Label>
            <Input
              id="cdi-home-channel"
              placeholder="orders"
              value={homeChannel}
              onChange={(e) => setHomeChannel(e.target.value)}
            />
            <p className="text-[11px] text-muted-foreground">
              The ``machine_name`` tag this instance defaults to when
              publishing. Free-form — it does not need to exist yet.
            </p>
          </div>

          <div className="border-t pt-3">
            <button
              type="button"
              className="flex w-full items-center justify-between text-left text-xs font-semibold uppercase tracking-wide text-muted-foreground hover:text-foreground"
              onClick={() => setShowFilter((v) => !v)}
            >
              <span>Advanced scope (filter)</span>
              <span>{showFilter ? 'Hide' : 'Show'}</span>
            </button>
            {showFilter ? (
              <div className="mt-2">
                <DiscoveryFilterBuilder value={filter} onChange={setFilter} />
              </div>
            ) : (
              <p className="mt-1 text-[11px] text-muted-foreground">
                Leave hidden to read all events across all channels.
              </p>
            )}
          </div>

          {error ? (
            <p className="text-xs text-destructive" role="alert">
              {error}
            </p>
          ) : null}
        </div>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="button"
            disabled={!canSubmit}
            onClick={() => void handleSubmit()}
          >
            <Plus className="mr-1.5 h-3.5 w-3.5" />
            Create instance
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
