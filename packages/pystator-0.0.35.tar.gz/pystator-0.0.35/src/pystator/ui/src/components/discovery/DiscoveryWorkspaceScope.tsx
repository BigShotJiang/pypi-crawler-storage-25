'use client'

import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { Bot, Trash2, Wrench } from 'lucide-react'
import { useState } from 'react'

/** Entity ID checkboxes; render directly below the recipe bottom-panel toolbar. */
export function DiscoveryEntityScopeList({ d }: { d: UseDiscoveryWorkspaceResult }) {
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  if (!editingWorkspace) return null
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">Entity scope</p>
      <div className="max-h-64 overflow-auto rounded border">
        {d.entityIds.length === 0 ? (
          <p className="p-3 text-xs text-muted-foreground">No observed entity IDs yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10 bg-muted/80 backdrop-blur">
              <tr className="border-b text-left">
                <th className="w-16 p-2 font-medium">Use</th>
                <th className="p-2 font-medium">Entity ID</th>
                <th className="w-24 p-2 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {d.entityIds.map((id) => {
                const checked = d.selectedEntityIds.includes(id)
                const deleting = deletingId === id
                return (
                  <tr key={id} className="border-b">
                    <td className="p-2 align-middle">
                      <input
                        type="checkbox"
                        checked={checked}
                        disabled={Boolean(d.selectedVersion) || deleting}
                        onChange={(e) => {
                          if (e.target.checked) {
                            d.setSelectedEntityIds([...d.selectedEntityIds, id])
                          } else {
                            d.setSelectedEntityIds(d.selectedEntityIds.filter((x) => x !== id))
                          }
                        }}
                      />
                    </td>
                    <td className="p-2 align-middle font-mono text-xs">{id}</td>
                    <td className="p-2 align-middle">
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        className="h-7 text-destructive hover:text-destructive"
                        disabled={deleting}
                        title={`Delete all observations for ${id}`}
                        onClick={() => {
                          const ok = window.confirm(
                            `Delete all discovery observations for entity ID '${id}' on machine '${d.machineName}'?`
                          )
                          if (!ok) return
                          setDeletingId(id)
                          void d
                            .deleteObservationEntity(id)
                            .finally(() => setDeletingId((curr) => (curr === id ? null : curr)))
                        }}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

export function DiscoveryWorkspaceScopeFields({ d }: { d: UseDiscoveryWorkspaceResult }) {
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)

  return (
    <>
      {d.selectedVersion ? (
        <p className="mt-2 text-xs text-muted-foreground">
          Built version selected — pick a draft workspace in the list to change scope, Preview, or Build.
        </p>
      ) : null}
      {editingWorkspace && d.mode === 'inference' && (
        <div className="mt-2 grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label htmlFor="disc-min-edge-count" className="text-xs">
              Min edge count
            </Label>
            <Input
              id="disc-min-edge-count"
              type="number"
              min={1}
              value={d.minEdgeCount}
              onChange={(e) => d.setMinEdgeCount(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="disc-min-confidence" className="text-xs">
              Min confidence
            </Label>
            <Input
              id="disc-min-confidence"
              type="number"
              min={0}
              max={1}
              step={0.01}
              value={d.minConfidence}
              onChange={(e) => d.setMinConfidence(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
        </div>
      )}
      {d.previewObservationCount > 0 && (
        <p className="mt-2 text-xs text-muted-foreground">
          Preview observations: {d.previewObservationCount}
        </p>
      )}
    </>
  )
}

export function DiscoveryWorkspaceModeTabs({
  d,
  compact = false,
}: {
  d: UseDiscoveryWorkspaceResult
  compact?: boolean
}) {
  return (
    <div
      className="flex rounded-lg border border-border/70 bg-background/50 p-0.5"
      role="tablist"
      aria-label="Discovery mode"
    >
      <button
        type="button"
        role="tab"
        aria-label="Inference mode"
        title="Inference"
        aria-selected={d.mode === 'inference'}
        disabled={Boolean(d.selectedVersion)}
        onClick={() => d.setMode('inference')}
        className={cn(
          'inline-flex shrink-0 items-center rounded-md text-xs font-medium transition-colors',
          compact ? 'h-7 gap-1.5 justify-center px-2.5' : 'h-8 gap-1.5 px-2.5',
          d.mode === 'inference'
            ? 'bg-primary text-primary-foreground'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <Bot className="h-3.5 w-3.5 shrink-0" />
        <span>Inference</span>
      </button>
      <button
        type="button"
        role="tab"
        aria-label="Manual mode"
        title="Manual"
        aria-selected={d.mode === 'manual'}
        disabled={Boolean(d.selectedVersion)}
        onClick={() => d.setMode('manual')}
        className={cn(
          'inline-flex shrink-0 items-center rounded-md text-xs font-medium transition-colors',
          compact ? 'h-7 gap-1.5 justify-center px-2.5' : 'h-8 gap-1.5 px-2.5',
          d.mode === 'manual'
            ? 'bg-primary text-primary-foreground'
            : 'text-muted-foreground hover:text-foreground'
        )}
      >
        <Wrench className="h-3.5 w-3.5 shrink-0" />
        <span>Manual</span>
      </button>
    </div>
  )
}

export function DiscoveryManualEdgeChecklist({ d }: { d: UseDiscoveryWorkspaceResult }) {
  const editingWorkspace = Boolean(d.activeDraftId && !d.selectedVersion)
  if (!editingWorkspace || d.mode !== 'manual' || d.previewEdges.length === 0) return null
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">Select edges</p>
      <div className="max-h-64 overflow-auto rounded border">
        <table className="w-full text-sm">
          <thead className="sticky top-0 z-10 bg-muted/80 backdrop-blur">
            <tr className="border-b text-left">
              <th className="w-16 p-2 font-medium">Use</th>
              <th className="p-2 font-medium">Transition</th>
              <th className="w-28 p-2 font-medium">Count</th>
              <th className="w-28 p-2 font-medium">Confidence</th>
            </tr>
          </thead>
          <tbody>
            {d.previewEdges.map((e, idx) => {
              const key = `${e.source_state}|||${e.destination_state}`
              const checked = d.selectedEdgeKeys.includes(key)
              return (
                <tr key={`${key}-${idx}`} className="border-b">
                  <td className="p-2 align-middle">
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(ev) => {
                        if (ev.target.checked) {
                          d.setSelectedEdgeKeys([...d.selectedEdgeKeys, key])
                        } else {
                          d.setSelectedEdgeKeys(d.selectedEdgeKeys.filter((x) => x !== key))
                        }
                      }}
                    />
                  </td>
                  <td className="p-2 align-middle font-mono text-xs">
                    {e.source_state} -&gt; {e.destination_state}
                  </td>
                  <td className="p-2 align-middle text-xs">{e.count}</td>
                  <td className="p-2 align-middle text-xs">{e.confidence.toFixed(2)}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
