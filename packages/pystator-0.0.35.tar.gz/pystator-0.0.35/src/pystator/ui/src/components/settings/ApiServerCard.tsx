'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useApiHealth } from '@/hooks'
import { useAppConfigStore, selectAppName } from '@/stores/app-config'
import { cn } from '@/lib/utils'
import { Loader2, CheckCircle2, XCircle } from 'lucide-react'

interface ApiServerCardProps {
  url: string
  onUrlChange: (url: string) => void
  /** Tighter spacing and typography for the settings hub. */
  compact?: boolean
}

export function ApiServerCard({ url, onUrlChange, compact }: ApiServerCardProps) {
  const appName = useAppConfigStore(selectAppName)
  const { testing, result, test } = useApiHealth()

  return (
    <Card id="connection" className="scroll-mt-28">
      <CardHeader className={cn(compact && 'space-y-1 p-4 pb-2')}>
        <CardTitle className={cn(compact && 'text-base')}>API server</CardTitle>
        <CardDescription className={cn(compact && 'text-xs leading-snug')}>
          {`Browser → API base URL (stored locally). Server default: PYSTATOR_API_URL / [api]. ${appName}`}
        </CardDescription>
      </CardHeader>
      <CardContent className={cn('space-y-3', compact && 'p-4 pt-0')}>
        <div className={cn('space-y-2', compact && 'space-y-1')}>
          <Label htmlFor="api-url" className={cn(compact && 'text-xs')}>
            API URL
          </Label>
          <Input
            id="api-url"
            type="text"
            className={cn(compact && 'h-8 text-sm')}
            value={url}
            onChange={(e) => onUrlChange(e.target.value)}
            placeholder="http://localhost:8004"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size={compact ? 'sm' : 'default'}
            onClick={() => test(url)}
            disabled={testing}
          >
            {testing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              'Test connection'
            )}
          </Button>
          {result && (
            <span className={cn('inline-flex items-center gap-1', compact ? 'text-xs' : 'text-sm')}>
              {result.success ? (
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              ) : (
                <XCircle className="h-4 w-4 text-red-600" />
              )}
              {result.message}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
