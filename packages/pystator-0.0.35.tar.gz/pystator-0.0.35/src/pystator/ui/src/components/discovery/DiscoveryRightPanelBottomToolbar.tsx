'use client'

import { Button } from '@/components/ui/button'
import {
  DiscoveryShadowDiffToolbar,
  type DiscoveryShadowFilter,
} from '@/components/discovery/DiscoveryShadowDiffCard'
import { DiscoveryFetchObservationEntitiesButton } from '@/components/discovery/DiscoveryRecipeWorkspacePanel'
import { DiscoveryWorkspaceModeTabs } from '@/components/discovery/DiscoveryWorkspaceScope'
import type { UseDiscoveryWorkspaceResult } from '@/hooks/useDiscoveryWorkspace'
import { ChevronDown, ChevronUp, Eye, Loader2, Plus, Wrench } from 'lucide-react'

export function DiscoveryRightPanelBottomToolbar({
  d,
  observationOpen,
  onToggleObservation,
  shadowFilter,
  onShadowFilterChange,
  canRunScope,
  canBuild,
}: {
  d: UseDiscoveryWorkspaceResult
  observationOpen: boolean
  onToggleObservation: () => void
  shadowFilter: DiscoveryShadowFilter
  onShadowFilterChange: (f: DiscoveryShadowFilter) => void
  canRunScope: boolean
  canBuild: boolean
}) {
  return (
    <div className="flex flex-wrap items-center gap-x-2 gap-y-2 border-b border-border/50 bg-muted/20 px-3 py-2">
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="h-8"
        onClick={onToggleObservation}
        title={observationOpen ? 'Hide observation form' : 'Show observation form'}
      >
        <Plus className="mr-1 h-3.5 w-3.5 opacity-80" />
        Observation
        {observationOpen ? (
          <ChevronUp className="ml-1 h-3.5 w-3.5 opacity-70" />
        ) : (
          <ChevronDown className="ml-1 h-3.5 w-3.5 opacity-70" />
        )}
      </Button>
      <DiscoveryFetchObservationEntitiesButton d={d} compact />
      <span className="select-none text-muted-foreground/50" aria-hidden>
        |
      </span>
      <DiscoveryWorkspaceModeTabs d={d} compact />
      <span className="select-none text-muted-foreground/50" aria-hidden>
        |
      </span>
      <DiscoveryShadowDiffToolbar
        machineName={d.machineName}
        loadingShadow={d.loadingShadow}
        filter={shadowFilter}
        onFilterChange={onShadowFilterChange}
        onRefresh={() => void d.loadShadow()}
        filterId="discovery-right-shadow-filter"
      />
      <div className="ml-auto flex items-center gap-2">
        <Button
          type="button"
          size="sm"
          variant="outline"
          className="h-8"
          disabled={!canRunScope || d.previewLoading}
          onClick={() => void d.preview()}
        >
          {d.previewLoading ? (
            <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
          ) : (
            <Eye className="mr-1.5 h-3.5 w-3.5" />
          )}
          Preview
        </Button>
        <Button
          type="button"
          size="sm"
          className="h-8"
          disabled={!canBuild || d.building}
          onClick={() => void d.build()}
        >
          {d.building ? (
            <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
          ) : (
            <Wrench className="mr-1.5 h-3.5 w-3.5" />
          )}
          Build candidate
        </Button>
      </div>
    </div>
  )
}
