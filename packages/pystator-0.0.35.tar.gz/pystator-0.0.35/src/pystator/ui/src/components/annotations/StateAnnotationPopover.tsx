'use client'

import { Button } from '@/components/ui/button'
import { X } from 'lucide-react'

export function StateAnnotationPopover({
  machineName,
  machineVersion,
  stateName,
  heading = 'State note',
  body,
  initialBody,
  saving,
  deleting,
  onBodyChange,
  onSave,
  onDelete,
  onClose,
}: {
  machineName: string
  machineVersion: string
  stateName: string
  /** Popover title (e.g. "Transition note" on edge labels). */
  heading?: string
  body: string
  initialBody: string
  saving: boolean
  deleting: boolean
  onBodyChange: (body: string) => void
  onSave: () => void
  onDelete: () => void
  onClose: () => void
}) {
  const canDelete = (initialBody ?? '').trim().length > 0

  return (
    <div className="w-[420px] max-w-[calc(100vw-48px)] rounded-lg border bg-background shadow-lg">
      <div className="flex items-start justify-between gap-3 border-b px-4 py-3">
        <div className="min-w-0">
          <div className="text-sm font-semibold">{heading}</div>
          <div className="mt-1 font-mono text-[10px] text-muted-foreground truncate">
            {machineName}@{machineVersion} • {stateName}
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
          aria-label="Close"
          title="Close"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="space-y-2 p-4">
        <div className="text-xs font-medium text-muted-foreground">Note (basic markdown)</div>
        <textarea
          value={body}
          onChange={(e) => onBodyChange(e.target.value)}
          rows={12}
          className="w-full resize-y rounded-md border bg-background px-3 py-2 text-sm"
          placeholder="- Preconditions\n- Failure modes\n- Ops checks"
        />
      </div>

      <div className="flex flex-col-reverse gap-2 border-t px-4 py-3 sm:flex-row sm:justify-end">
        {canDelete ? (
          <Button type="button" variant="destructive" onClick={onDelete} disabled={deleting || saving}>
            {deleting ? 'Deleting…' : 'Delete note'}
          </Button>
        ) : null}
        <Button type="button" onClick={onSave} disabled={saving || deleting}>
          {saving ? 'Saving…' : 'Save'}
        </Button>
      </div>
    </div>
  )
}
