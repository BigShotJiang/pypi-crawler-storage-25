'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { processEntityEvent, ApiError } from '@/lib/api'
import type { ProcessEntityEventResponse } from '@/lib/api'
import type { FSMStateVariable } from '@/lib/types/fsm'
import { Send, CheckCircle2, XCircle } from 'lucide-react'

interface SendEventFormProps {
  entityId: string
  defaultMachineName?: string | null
  /** When set, trigger is shown as a dropdown of allowed triggers for the current state */
  availableTriggers?: string[]
  /** When set, a "Fill from state variables" button pre-fills context JSON with keys and defaults */
  stateVariables?: FSMStateVariable[]
  onSuccess: () => void
}

export default function SendEventForm({ entityId, defaultMachineName, availableTriggers, stateVariables = [], onSuccess }: SendEventFormProps) {
  const [trigger, setTrigger] = useState(availableTriggers?.[0] ?? '')

  useEffect(() => {
    if (availableTriggers && availableTriggers.length > 0) {
      setTrigger((prev) => (availableTriggers.includes(prev) ? prev : availableTriggers[0]))
    } else {
      setTrigger('')
    }
  }, [availableTriggers])
  const [contextJson, setContextJson] = useState('{}')
  const [sending, setSending] = useState(false)
  const [result, setResult] = useState<ProcessEntityEventResponse | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!trigger.trim()) return

    setSending(true)
    setResult(null)
    setError(null)

    let parsedContext: Record<string, unknown> = {}
    try {
      parsedContext = JSON.parse(contextJson)
    } catch {
      setError('Invalid JSON in context field')
      setSending(false)
      return
    }

    try {
      const res = await processEntityEvent(entityId, {
        trigger: trigger.trim(),
        machine_name: defaultMachineName || undefined,
        context: parsedContext,
      })
      setResult(res)
      if (res.success) {
        setTrigger('')
        onSuccess()
      }
    } catch (err) {
      setError(err instanceof ApiError ? err.message : err instanceof Error ? err.message : String(err))
    } finally {
      setSending(false)
    }
  }

  const fillFromStateVariables = () => {
    const obj: Record<string, unknown> = {}
    for (const sv of stateVariables) {
      obj[sv.key] = sv.default !== undefined && sv.default !== null ? sv.default : null
    }
    setContextJson(JSON.stringify(obj, null, 2))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Send Event</CardTitle>
        <p className="text-xs text-muted-foreground leading-snug">
          Runs the transition on the server: state and context are saved and configured actions
          execute. The request waits until processing finishes (use the worker or a client-driven
          flow if you need async or long-running work).
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="trigger" className="text-sm">Trigger *</Label>
            {availableTriggers && availableTriggers.length > 0 ? (
              <select
                id="trigger"
                required
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={trigger}
                onChange={(e) => setTrigger(e.target.value)}
              >
                <option value="">Select trigger</option>
                {availableTriggers.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            ) : (
              <input
                id="trigger"
                type="text"
                required
                placeholder="e.g. submit, approve, cancel"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={trigger}
                onChange={(e) => setTrigger(e.target.value)}
              />
            )}
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <Label htmlFor="context_json" className="text-sm">Context (JSON)</Label>
              {stateVariables.length > 0 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="text-xs text-muted-foreground"
                  onClick={fillFromStateVariables}
                  title="Pre-fill with keys and defaults from state variables"
                >
                  Fill from state variables
                </Button>
              )}
            </div>
            <textarea
              id="context_json"
              rows={3}
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm font-mono"
              value={contextJson}
              onChange={(e) => setContextJson(e.target.value)}
            />
          </div>
          <Button type="submit" disabled={sending || !trigger.trim()} className="gap-1.5">
            <Send className={`h-4 w-4 ${sending ? 'animate-pulse' : ''}`} />
            {sending ? 'Running transition…' : 'Run transition'}
          </Button>
        </form>

        {/* Result display */}
        {result && (
          <div className={`mt-4 rounded-lg border p-4 ${result.success ? 'border-emerald-300 bg-emerald-50 dark:border-emerald-700 dark:bg-emerald-950/30' : 'border-destructive/50 bg-destructive/10'}`}>
            <div className="flex items-center gap-2 mb-2">
              {result.success ? (
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <XCircle className="h-4 w-4 text-destructive" />
              )}
              <span className="text-sm font-medium">
                {result.success ? 'Transition successful' : 'Transition failed'}
              </span>
            </div>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-sm">
              <dt className="text-muted-foreground">Trigger</dt>
              <dd className="font-mono">{result.trigger}</dd>
              <dt className="text-muted-foreground">Source</dt>
              <dd className="font-mono">{result.source_state}</dd>
              <dt className="text-muted-foreground">Target</dt>
              <dd className="font-mono">{result.target_state ?? '—'}</dd>
              {result.actions.length > 0 && (
                <>
                  <dt className="text-muted-foreground">Planned actions</dt>
                  <dd className="font-mono">{result.actions.join(', ')}</dd>
                </>
              )}
              {result.action_results && result.action_results.length > 0 && (
                <>
                  <dt className="text-muted-foreground col-span-2 mt-1">Action results</dt>
                  <dd className="col-span-2 text-xs font-mono space-y-0.5">
                    {result.action_results.map((ar, i) => (
                      <div key={`${ar.name}-${i}`}>
                        {ar.name}: {ar.success ? 'ok' : 'failed'}
                        {ar.error ? ` — ${ar.error}` : ''}
                      </div>
                    ))}
                  </dd>
                </>
              )}
              {result.error && (
                <>
                  <dt className="text-muted-foreground">Error</dt>
                  <dd className="text-destructive">{result.error}</dd>
                </>
              )}
            </dl>
          </div>
        )}

        {error && !result && (
          <div className="mt-4 rounded-lg border border-destructive/50 bg-destructive/10 p-3">
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
