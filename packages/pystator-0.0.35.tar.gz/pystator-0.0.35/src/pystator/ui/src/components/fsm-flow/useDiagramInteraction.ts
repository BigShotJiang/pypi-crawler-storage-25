import { useCallback, useEffect, useRef, useMemo } from 'react'
import {
  useReactFlow,
  getConnectedEdges,
  type Connection,
  type Node,
  type Edge,
} from '@xyflow/react'
import type { NodeData, EdgeLabelData } from '@/lib/fsmToReactFlow'
import type { FSMConfig } from '@/lib/types/fsm'
import { getPaletteDragPayload, type PaletteDragPayload } from '@/components/workspace/paletteDnd'
import { useFsmDiagramFocus } from './FsmDiagramFocusContext'
import { useToastStore } from '@/stores/toast'

export type FsmDiagramSelection =
  | { kind: 'none' }
  | { kind: 'state'; stateName: string }
  | {
      kind: 'transition'
      primaryIndex: number
      groupedIndices?: number[]
    }

interface UseDiagramInteractionOptions {
  config: FSMConfig
  editable: boolean
  nodes: Node<NodeData>[]
  setNodes: React.Dispatch<React.SetStateAction<Node<NodeData>[]>>
  setEdges: React.Dispatch<React.SetStateAction<Edge<EdgeLabelData>[]>>
  onPaneDoubleClick?: (position: { x: number; y: number }) => void
  onNodeDoubleClick?: (stateName: string) => void
  onEdgeDoubleClick?: (transitionIndex: number, groupedIndices?: number[]) => void
  onConnect?: (sourceName: string, destName: string, initialTrigger?: string) => void
  /**
   * When this returns true, `onConnect` is not called (caller shows UI, e.g. trigger popover).
   */
  onConnectIntercept?: (ctx: {
    sourceName: string
    destName: string
    sourceNode: Node<NodeData>
    targetNode: Node<NodeData>
  }) => boolean
  onNodesDelete?: (stateNames: string[]) => void
  onEdgesDelete?: (transitionIndices: number[]) => void
  onPaletteDrop?: (payload: PaletteDragPayload, flowPosition: { x: number; y: number } | null) => void
  onDiagramSelectionChange?: (selection: FsmDiagramSelection) => void
  diagramSelectRequest?: { nodeId: string; token: number } | null
  onDiagramSelectRequestHandled?: () => void
  clearDiagramSelectionNonce: number
}

export function useDiagramInteraction({
  config,
  editable,
  nodes,
  setNodes,
  setEdges,
  onPaneDoubleClick,
  onNodeDoubleClick,
  onEdgeDoubleClick,
  onConnect,
  onConnectIntercept,
  onNodesDelete,
  onEdgesDelete,
  onPaletteDrop,
  onDiagramSelectionChange,
  diagramSelectRequest,
  onDiagramSelectRequestHandled,
  clearDiagramSelectionNonce,
}: UseDiagramInteractionOptions) {
  const { clearFocus, requestFocusNode, requestFocusEdgeLabel } = useFsmDiagramFocus()
  const reactFlow = useReactFlow<Node<NodeData>, Edge<EdgeLabelData>>()
  const toastError = useToastStore((s) => s.error)

  const initialStateNames = useMemo(
    () => new Set((config.states ?? []).filter((s) => s.type === 'initial').map((s) => s.name)),
    [config.states],
  )

  const lastSelectTokenRef = useRef<number | null>(null)
  const lastClearNonceRef = useRef(0)

  // Programmatic select
  useEffect(() => {
    const req = diagramSelectRequest
    if (!req) return
    if (lastSelectTokenRef.current === req.token) return
    if (!nodes.some((n) => n.id === req.nodeId)) return
    setNodes((nds) => nds.map((n) => ({ ...n, selected: n.id === req.nodeId })))
    setEdges((eds) => eds.map((e) => ({ ...e, selected: false })))
    lastSelectTokenRef.current = req.token
    onDiagramSelectRequestHandled?.()
  }, [diagramSelectRequest, nodes, setNodes, setEdges, onDiagramSelectRequestHandled])

  // Programmatic clear
  useEffect(() => {
    if (!clearDiagramSelectionNonce || clearDiagramSelectionNonce === lastClearNonceRef.current) {
      return
    }
    lastClearNonceRef.current = clearDiagramSelectionNonce
    setNodes((nds) => nds.map((n) => ({ ...n, selected: false })))
    setEdges((eds) => eds.map((e) => ({ ...e, selected: false })))
  }, [clearDiagramSelectionNonce, setNodes, setEdges])

  /**
   * Keeps the diagram inspector in sync with canvas selection (single node or edge).
   * Parent should only open the panel from double-click / palette; this handler updates
   * content when the panel is already open.
   */
  const handleSelectionChange = useCallback(
    ({
      nodes: selectedNodes,
      edges: selectedEdges,
    }: {
      nodes: Node<NodeData>[]
      edges: Edge<EdgeLabelData>[]
    }) => {
      if (!onDiagramSelectionChange) return
      const nc = selectedNodes.length
      const ec = selectedEdges.length
      if (nc === 0 && ec === 0) {
        onDiagramSelectionChange({ kind: 'none' })
        return
      }
      if (nc === 1 && ec === 0) {
        const node = selectedNodes[0]!
        const data = node.data as NodeData
        const stateName = data.stateName ?? node.id
        onDiagramSelectionChange({ kind: 'state', stateName })
        return
      }
      if (nc === 0 && ec === 1) {
        const edge = selectedEdges[0]!
        const data = (edge.data ?? {}) as EdgeLabelData
        if (data.isSynthetic) {
          onDiagramSelectionChange({ kind: 'none' })
          return
        }
        const grouped = data.groupedTransitions
        if (grouped && grouped.length > 0) {
          const indices = grouped.map((g) => g.transitionIndex)
          onDiagramSelectionChange({
            kind: 'transition',
            primaryIndex: indices[0]!,
            groupedIndices: indices,
          })
          return
        }
        if (data.transitionIndex != null) {
          onDiagramSelectionChange({
            kind: 'transition',
            primaryIndex: data.transitionIndex,
          })
          return
        }
        onDiagramSelectionChange({ kind: 'none' })
        return
      }
      onDiagramSelectionChange({ kind: 'none' })
    },
    [onDiagramSelectionChange],
  )

  const handlePaneDoubleClick = useCallback(
    (event: React.MouseEvent) => {
      if (!editable || !onPaneDoubleClick) return
      const target = event.target as HTMLElement
      if (
        target.closest('.react-flow__node') ||
        target.closest('.react-flow__edge') ||
        target.closest('.react-flow__edgelabel-renderer')
      )
        return
      const position = reactFlow.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })
      onPaneDoubleClick(position)
    },
    [editable, onPaneDoubleClick, reactFlow],
  )

  const handleNodeDoubleClick = useCallback(
    (_event: React.MouseEvent, node: Node<NodeData>) => {
      if (!editable) return
      const data = node.data as NodeData
      const stateName = data.stateName ?? node.id
      setNodes((nds) => nds.map((n) => ({ ...n, selected: n.id === node.id })))
      setEdges((eds) => eds.map((e) => ({ ...e, selected: false })))
      if (onNodeDoubleClick) onNodeDoubleClick(stateName)
    },
    [editable, onNodeDoubleClick, setNodes, setEdges],
  )

  const handleNodeClick = useCallback(
    (_event: React.MouseEvent, node: Node<NodeData>) => {
      requestFocusNode(node.id)
    },
    [requestFocusNode],
  )

  const handleEdgeDoubleClick = useCallback(
    (_event: React.MouseEvent, edge: Edge<EdgeLabelData>) => {
      if (!editable) return
      const data = (edge.data ?? {}) as EdgeLabelData
      if (data.isSynthetic) return
      setEdges((eds) => eds.map((e) => ({ ...e, selected: e.id === edge.id })))
      setNodes((nds) => nds.map((n) => ({ ...n, selected: false })))
      if (!onEdgeDoubleClick) return
      const grouped = data.groupedTransitions
      const groupedIndices =
        grouped && grouped.length >= 2
          ? [...grouped].map((r) => r.transitionIndex).sort((a, b) => a - b)
          : undefined
      const primaryIndex =
        data.transitionIndex ??
        (grouped && grouped.length > 0
          ? [...grouped].sort((a, b) => a.transitionIndex - b.transitionIndex)[0]!.transitionIndex
          : undefined)
      if (primaryIndex != null) {
        onEdgeDoubleClick(primaryIndex, groupedIndices)
      }
    },
    [editable, onEdgeDoubleClick, setNodes, setEdges],
  )

  const handleEdgeClick = useCallback(
    (_event: React.MouseEvent, edge: Edge<EdgeLabelData>) => {
      requestFocusEdgeLabel(edge.id, { sourceId: edge.source, targetId: edge.target })
    },
    [requestFocusEdgeLabel],
  )

  const handleConnect = useCallback(
    (connection: Connection) => {
      if (!editable || (!onConnect && !onConnectIntercept)) return
      if (!connection.source || !connection.target) return
      const sourceNode = nodes.find((n) => n.id === connection.source)
      const targetNode = nodes.find((n) => n.id === connection.target)
      if (!sourceNode || !targetNode) return
      const sourceData = sourceNode.data as NodeData
      const targetData = targetNode.data as NodeData
      const sourceName = sourceData.stateName ?? sourceNode.id
      const destName = targetData.stateName ?? targetNode.id
      if (
        onConnectIntercept?.({
          sourceName,
          destName,
          sourceNode,
          targetNode,
        })
      ) {
        return
      }
      onConnect?.(sourceName, destName)
    },
    [editable, onConnect, onConnectIntercept, nodes],
  )

  const handleBeforeDelete = useCallback(
    async ({
      nodes: toDelete,
      edges: edgesToDelete,
    }: {
      nodes: Node<NodeData>[]
      edges: Edge<EdgeLabelData>[]
    }) => {
      if (toDelete.length === 0) return true

      const blocked = toDelete.filter((n) => {
        const name = (n.data as NodeData).stateName ?? n.id
        return initialStateNames.has(name)
      })
      const allowedNodes = toDelete.filter((n) => {
        const name = (n.data as NodeData).stateName ?? n.id
        return !initialStateNames.has(name)
      })

      if (blocked.length > 0) {
        const names = blocked.map((n) => (n.data as NodeData).stateName ?? n.id)
        if (allowedNodes.length === 0) {
          toastError(`Cannot delete initial state: ${names.join(', ')}`)
          return false
        }
        toastError(
          `Initial state(s) cannot be deleted (${names.join(', ')}). Other selected states will be removed.`,
        )
      }

      if (blocked.length > 0) {
        const allowedEdges = getConnectedEdges(allowedNodes, edgesToDelete)
        return { nodes: allowedNodes, edges: allowedEdges }
      }

      return true
    },
    [initialStateNames, toastError],
  )

  const handleNodesDeleteCb = useCallback(
    (deletedNodes: Node<NodeData>[]) => {
      if (!editable || !onNodesDelete) return
      const stateNames = deletedNodes.map((n) => (n.data as NodeData).stateName ?? n.id)
      if (stateNames.length > 0) onNodesDelete(stateNames)
    },
    [editable, onNodesDelete],
  )

  const handleEdgesDeleteCb = useCallback(
    (deletedEdges: Edge<EdgeLabelData>[]) => {
      if (!editable || !onEdgesDelete) return
      const indices = deletedEdges
        .map((e) => ((e.data ?? {}) as EdgeLabelData).transitionIndex)
        .filter((idx): idx is number => idx != null)
      if (indices.length > 0) onEdgesDelete(indices)
    },
    [editable, onEdgesDelete],
  )

  const handlePaletteDragOver = useCallback(
    (event: React.DragEvent) => {
      if (!editable || !onPaletteDrop) return
      event.preventDefault()
      event.dataTransfer.dropEffect = 'move'
    },
    [editable, onPaletteDrop],
  )

  const handlePaletteDrop = useCallback(
    (event: React.DragEvent) => {
      if (!editable || !onPaletteDrop) return
      event.preventDefault()
      const payload = getPaletteDragPayload(event)
      if (!payload) return
      const flowPosition = reactFlow.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })
      onPaletteDrop(payload, flowPosition)
    },
    [editable, onPaletteDrop, reactFlow],
  )

  return {
    clearFocus,
    handleSelectionChange,
    handlePaneDoubleClick,
    handleNodeDoubleClick,
    handleNodeClick,
    handleEdgeDoubleClick,
    handleEdgeClick,
    handleConnect,
    handleBeforeDelete,
    handleNodesDeleteCb,
    handleEdgesDeleteCb,
    handlePaletteDragOver,
    handlePaletteDrop,
  }
}
