'use client'

import { useState, useEffect, useRef } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import type { FSMState, FSMTransition } from '@/lib/types/fsm'
import { TransitionInspectorForm } from '@/components/workspace/inspector/TransitionInspectorForm'

export interface TransitionModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  transition: FSMTransition
  stateNames: string[]
  regionNames?: string[]
  configStates?: FSMState[]
  onSave: (transition: FSMTransition) => void
  title?: string
  description?: string
}

const TRANSITION_MODAL_FORM_ID = 'workspace-transition-modal-form'

export function TransitionModal({
  open,
  onOpenChange,
  transition,
  stateNames,
  regionNames = [],
  configStates,
  onSave,
  title = 'Transition',
  description = 'Trigger, source state(s), destination; guards, actions, delay, and region optional.',
}: TransitionModalProps) {
  const [canSave, setCanSave] = useState(false)
  const [formSession, setFormSession] = useState(0)
  const wasOpen = useRef(false)
  useEffect(() => {
    if (open && !wasOpen.current) {
      setFormSession((s) => s + 1)
    }
    wasOpen.current = open
  }, [open])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto" showClose>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        {open ? (
          <TransitionInspectorForm
            transition={transition}
            resetKey={formSession}
            stateNames={stateNames}
            regionNames={regionNames}
            configStates={configStates}
            onSubmit={(next) => {
              onSave(next)
              onOpenChange(false)
            }}
            showFooter={false}
            formId={TRANSITION_MODAL_FORM_ID}
            onCanSaveChange={setCanSave}
          />
        ) : null}
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button type="submit" form={TRANSITION_MODAL_FORM_ID} disabled={!canSave}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
