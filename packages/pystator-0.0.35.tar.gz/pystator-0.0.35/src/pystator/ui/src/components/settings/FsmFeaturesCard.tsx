'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import {
  useAppConfigStore,
  selectAllowInlineCodeActions,
  selectAllowInlineCodeActionsSource,
} from '@/stores/app-config'

export type InlineCodeEditorPref = 'auto' | 'always' | 'never'

function sourceLabel(source: string): string {
  switch (source) {
    case 'environment':
      return 'environment variable'
    case 'config_file':
      return 'pystator.cfg'
    default:
      return 'default'
  }
}

interface FsmFeaturesCardProps {
  inlineCodeActionsEditor: InlineCodeEditorPref
  onInlineCodeActionsEditorChange: (v: InlineCodeEditorPref) => void
  compact?: boolean
}

export function FsmFeaturesCard({
  inlineCodeActionsEditor,
  onInlineCodeActionsEditorChange,
  compact,
}: FsmFeaturesCardProps) {
  const serverAllows = useAppConfigStore(selectAllowInlineCodeActions)
  const resolvedSource = useAppConfigStore(selectAllowInlineCodeActionsSource)

  return (
    <Card id="features" className="scroll-mt-28">
      <CardHeader className={cn(compact && 'space-y-1 p-4 pb-2')}>
        <CardTitle className={cn(compact && 'text-base')}>FSM features</CardTitle>
        <CardDescription className={cn(compact && 'text-xs leading-snug')}>
          Inline <code className="text-[11px]">code:</code> policy:{' '}
          <code className="text-[11px]">PYSTATOR_ALLOW_INLINE_CODE_ACTIONS</code> overrides{' '}
          <code className="text-[11px]">[features]</code>.
        </CardDescription>
      </CardHeader>
      <CardContent className={cn('space-y-3', compact && 'p-4 pt-0')}>
        <div
          className={cn(
            'rounded-md bg-muted/50 text-muted-foreground',
            compact ? 'px-2 py-1.5 text-xs' : 'px-3 py-2 text-sm',
          )}
        >
          Server: inline code {serverAllows ? 'on' : 'off'} ({sourceLabel(resolvedSource)}).
        </div>
        <div className={cn('space-y-2', compact && 'space-y-1')}>
          <Label htmlFor="inline-code-editor-pref" className={cn(compact && 'text-xs')}>
            Editor: show &quot;Code&quot; kind
          </Label>
          <select
            id="inline-code-editor-pref"
            className={cn(
              'w-full max-w-md rounded-md border border-input bg-background px-2 text-sm',
              compact ? 'h-8' : 'h-9',
            )}
            value={inlineCodeActionsEditor}
            onChange={(e) =>
              onInlineCodeActionsEditorChange(e.target.value as InlineCodeEditorPref)
            }
          >
            <option value="auto">Auto — show when the server allows execution</option>
            <option value="always">Always — show even if the server will reject execution</option>
            <option value="never">Never — hide (existing code actions still editable)</option>
          </select>
          <p className="text-xs text-muted-foreground">
            Stored in this browser only. Execution is always governed by the API server configuration.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
