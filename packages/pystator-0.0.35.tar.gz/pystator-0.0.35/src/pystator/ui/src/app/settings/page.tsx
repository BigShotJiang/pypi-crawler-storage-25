'use client'

import { useState } from 'react'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { getSettings, saveSettings, type AppSettings } from '@/lib/settings'
import {
  ApiServerCard,
  DatabaseConfigCard,
  DiscoveryConfigCard,
  DlqConfigCard,
  FsmFeaturesCard,
  ServerRuntimeOverview,
  type InlineCodeEditorPref,
} from '@/components/settings'
import { Loader2 } from 'lucide-react'
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config'

const SECTIONS = [
  { id: 'overview', label: 'Server overview' },
  { id: 'connection', label: 'API' },
  { id: 'database', label: 'Database' },
  { id: 'discovery', label: 'Discovery' },
  { id: 'dlq', label: 'DLQ' },
  { id: 'features', label: 'FSM features' },
] as const

export default function SettingsPage() {
  const appName = useAppConfigStore(selectAppName)
  const version = useAppConfigStore(selectVersion)
  const [settings, setSettings] = useState<AppSettings>(getSettings())
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const handleSave = () => {
    setSaving(true)
    setMessage(null)
    try {
      saveSettings(settings)
      setMessage({
        type: 'success',
        text: 'Saved to this browser. The API URL is used for the next request; other values are hints for tests and tools.',
      })
    } catch (e) {
      setMessage({ type: 'error', text: String(e) })
    } finally {
      setSaving(false)
    }
  }

  return (
    <PageContainer padding="sm">
      <div className="sticky top-0 z-30 -mt-2 mb-4 space-y-2 border-b border-border/60 bg-background/95 pb-3 pt-1 backdrop-blur-md">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">Settings</h1>
            <p className="text-xs text-muted-foreground sm:text-sm">
              {appName}
              {version ? ` · ${version}` : ''} · Admins can edit server{' '}
              <code className="rounded bg-muted px-0.5 text-[11px]">pystator.cfg</code> from the overview
              table; other forms below use{' '}
              <code className="rounded bg-muted px-0.5 text-[11px]">localStorage</code> in this browser.
            </p>
          </div>
          <div className="flex shrink-0 flex-wrap items-center gap-2">
            <Button type="button" variant="outline" size="sm" onClick={() => window.location.reload()}>
              Reload
            </Button>
            <Button type="button" size="sm" onClick={handleSave} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving…
                </>
              ) : (
                'Save browser settings'
              )}
            </Button>
          </div>
        </div>
        <nav className="flex flex-wrap gap-1" aria-label="Settings sections">
          {SECTIONS.map(({ id, label }) => (
            <a
              key={id}
              href={`#${id}`}
              className="rounded-md border border-border/60 bg-muted/30 px-2 py-0.5 text-xs font-medium text-muted-foreground transition-colors hover:border-border hover:bg-muted hover:text-foreground"
            >
              {label}
            </a>
          ))}
        </nav>
      </div>

      {message && (
        <Alert
          className={`mb-3 ${message.type === 'success' ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}
        >
          <AlertDescription
            className={message.type === 'success' ? 'text-green-900 text-sm' : 'text-red-900 text-sm'}
          >
            {message.text}
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-3">
        <ServerRuntimeOverview compact />

        <div className="grid gap-3 xl:grid-cols-2 xl:items-start">
          <div className="space-y-3 min-w-0">
            <ApiServerCard
              compact
              url={settings.apiServer.url}
              onUrlChange={(url) => setSettings((s) => ({ ...s, apiServer: { ...s.apiServer, url } }))}
            />
            <DatabaseConfigCard
              compact
              connectionString={settings.database.connectionString ?? ''}
              host={settings.database.host ?? ''}
              port={settings.database.port != null ? String(settings.database.port) : ''}
              database={settings.database.database ?? ''}
              username={settings.database.username ?? ''}
              password={settings.database.password ?? ''}
              onConnectionStringChange={(v) =>
                setSettings((s) => ({ ...s, database: { ...s.database, connectionString: v || undefined } }))
              }
              onHostChange={(v) =>
                setSettings((s) => ({ ...s, database: { ...s.database, host: v || undefined } }))
              }
              onPortChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  database: { ...s.database, port: v ? parseInt(v, 10) : undefined },
                }))
              }
              onDatabaseChange={(v) =>
                setSettings((s) => ({ ...s, database: { ...s.database, database: v || undefined } }))
              }
              onUsernameChange={(v) =>
                setSettings((s) => ({ ...s, database: { ...s.database, username: v || undefined } }))
              }
              onPasswordChange={(v) =>
                setSettings((s) => ({ ...s, database: { ...s.database, password: v || undefined } }))
              }
            />
            <FsmFeaturesCard
              compact
              inlineCodeActionsEditor={
                (settings.features?.inlineCodeActionsEditor ?? 'auto') as InlineCodeEditorPref
              }
              onInlineCodeActionsEditorChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  features: { ...s.features, inlineCodeActionsEditor: v },
                }))
              }
            />
          </div>

          <div className="space-y-3 min-w-0">
            <DiscoveryConfigCard
              compact
              backend={settings.discovery.backend}
              connectionString={settings.discovery.connectionString ?? ''}
              shadowEnabled={settings.discovery.shadowEnabled}
              minEdgeCount={String(settings.discovery.minEdgeCount)}
              minConfidence={String(settings.discovery.minConfidence)}
              driftAlertThreshold={String(settings.discovery.driftAlertThreshold)}
              driftSevereThreshold={String(settings.discovery.driftSevereThreshold)}
              driftMinSample={String(settings.discovery.driftMinSample)}
              lowSampleThreshold={String(settings.discovery.lowSampleThreshold)}
              onBackendChange={(v) =>
                setSettings((s) => ({ ...s, discovery: { ...s.discovery, backend: v } }))
              }
              onConnectionStringChange={(v) =>
                setSettings((s) => ({ ...s, discovery: { ...s.discovery, connectionString: v || undefined } }))
              }
              onShadowEnabledChange={(v) =>
                setSettings((s) => ({ ...s, discovery: { ...s.discovery, shadowEnabled: v } }))
              }
              onMinEdgeCountChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  discovery: { ...s.discovery, minEdgeCount: v ? parseInt(v, 10) : 2 },
                }))
              }
              onMinConfidenceChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  discovery: { ...s.discovery, minConfidence: v ? parseFloat(v) : 0.5 },
                }))
              }
              onDriftAlertThresholdChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  discovery: {
                    ...s.discovery,
                    driftAlertThreshold: v ? Math.min(1, Math.max(0, parseFloat(v))) : 0.15,
                  },
                }))
              }
              onDriftSevereThresholdChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  discovery: {
                    ...s.discovery,
                    driftSevereThreshold: v ? Math.min(1, Math.max(0, parseFloat(v))) : 0.4,
                  },
                }))
              }
              onDriftMinSampleChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  discovery: { ...s.discovery, driftMinSample: v ? Math.max(1, parseInt(v, 10)) : 3 },
                }))
              }
              onLowSampleThresholdChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  discovery: {
                    ...s.discovery,
                    lowSampleThreshold: v ? Math.max(1, parseInt(v, 10)) : 10,
                  },
                }))
              }
            />
            <DlqConfigCard
              compact
              enabled={settings.dlq.enabled}
              connectionString={settings.dlq.connectionString ?? ''}
              host={settings.dlq.host ?? ''}
              port={settings.dlq.port != null ? String(settings.dlq.port) : ''}
              database={settings.dlq.database ?? ''}
              username={settings.dlq.username ?? ''}
              password={settings.dlq.password ?? ''}
              tableName={settings.dlq.tableName ?? 'dead_letter_queue'}
              onEnabledChange={(v) => setSettings((s) => ({ ...s, dlq: { ...s.dlq, enabled: v } }))}
              onConnectionStringChange={(v) =>
                setSettings((s) => ({ ...s, dlq: { ...s.dlq, connectionString: v || undefined } }))
              }
              onHostChange={(v) => setSettings((s) => ({ ...s, dlq: { ...s.dlq, host: v || undefined } }))}
              onPortChange={(v) =>
                setSettings((s) => ({
                  ...s,
                  dlq: { ...s.dlq, port: v ? parseInt(v, 10) : undefined },
                }))
              }
              onDatabaseChange={(v) =>
                setSettings((s) => ({ ...s, dlq: { ...s.dlq, database: v || undefined } }))
              }
              onUsernameChange={(v) =>
                setSettings((s) => ({ ...s, dlq: { ...s.dlq, username: v || undefined } }))
              }
              onPasswordChange={(v) =>
                setSettings((s) => ({ ...s, dlq: { ...s.dlq, password: v || undefined } }))
              }
              onTableNameChange={(v) =>
                setSettings((s) => ({ ...s, dlq: { ...s.dlq, tableName: v || undefined } }))
              }
            />
          </div>
        </div>
      </div>
    </PageContainer>
  )
}
