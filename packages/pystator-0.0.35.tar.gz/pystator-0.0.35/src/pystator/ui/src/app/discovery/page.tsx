'use client'

import { useCallback, useEffect, useState } from 'react'
import { ResizableTriplePanelLayout } from '@/components/layout'
import { CreateDiscoveryInstanceDialog } from '@/components/discovery/CreateDiscoveryInstanceDialog'
import { DiscoveryCandidatesColumn } from '@/components/discovery/DiscoveryCandidatesColumn'
import { DiscoveryInstancesPanel } from '@/components/discovery/DiscoveryInstancesPanel'
import { DiscoveryWorkspace } from '@/components/discovery/DiscoveryWorkspace'
import { useDiscoveryInstances } from '@/hooks/useDiscoveryInstances'
import { useDiscoveryWorkspace } from '@/hooks/useDiscoveryWorkspace'

const DISCOVERY_FOCUSED_INSTANCE_KEY = 'pystator_discovery_focused_instance_id'

export default function DiscoveryPage() {
  const workspace = useDiscoveryWorkspace()
  const instancesHook = useDiscoveryInstances()
  const [focusedInstanceId, setFocusedInstanceId] = useState<string | null>(null)
  const [createOpen, setCreateOpen] = useState<boolean>(false)

  const handleFocusInstance = useCallback(
    (id: string, homeChannel: string) => {
      setFocusedInstanceId(id)
      void workspace.focusInstance(id, homeChannel)
    },
    [workspace]
  )

  const handleAfterObservation = useCallback(() => {
    void workspace.refreshAvailableMachines()
    void instancesHook.refresh()
  }, [workspace, instancesHook])

  const handleCreate = useCallback(
    async (args: {
      homeChannel: string
      title: string
      filter: Parameters<typeof instancesHook.create>[0]['filter']
    }) => {
      const created = await instancesHook.create(args)
      if (created) {
        setFocusedInstanceId(created.id)
        void workspace.focusInstance(created.id, created.home_channel)
      }
      return created
    },
    [instancesHook, workspace]
  )

  // Restore the last focused instance from localStorage on mount.
  useEffect(() => {
    if (typeof window === 'undefined') return
    const saved = window.localStorage.getItem(DISCOVERY_FOCUSED_INSTANCE_KEY)
    if (saved && saved.trim()) {
      setFocusedInstanceId(saved.trim())
    }
  }, [])

  // Persist the focused instance id.
  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!focusedInstanceId) {
      window.localStorage.removeItem(DISCOVERY_FOCUSED_INSTANCE_KEY)
      return
    }
    window.localStorage.setItem(DISCOVERY_FOCUSED_INSTANCE_KEY, focusedInstanceId)
  }, [focusedInstanceId])

  // Drop focus if the instance disappears (e.g. deleted from another tab).
  useEffect(() => {
    if (!focusedInstanceId) return
    if (instancesHook.loading) return
    const exists = instancesHook.instances.some((i) => i.id === focusedInstanceId)
    if (!exists) {
      setFocusedInstanceId(null)
      workspace.selectDraft(null)
      workspace.selectVersion(null)
      workspace.setMachineName('')
    }
  }, [focusedInstanceId, instancesHook.instances, instancesHook.loading, workspace])

  // When the focused instance id is restored from localStorage, hydrate
  // the workspace once the instances list has loaded.
  useEffect(() => {
    if (!focusedInstanceId) return
    if (workspace.machineName) return
    const inst = instancesHook.instances.find((i) => i.id === focusedInstanceId)
    if (!inst) return
    void workspace.focusInstance(inst.id, inst.home_channel)
  }, [focusedInstanceId, instancesHook.instances, workspace])

  return (
    <>
      <CreateDiscoveryInstanceDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        onCreate={handleCreate}
      />
      <ResizableTriplePanelLayout
        groupId="discovery-triple"
        left={(api) => (
          <DiscoveryInstancesPanel
            api={api}
            instancesHook={instancesHook}
            focusedInstanceId={focusedInstanceId}
            onFocusInstance={handleFocusInstance}
            onOpenCreateDialog={() => setCreateOpen(true)}
          />
        )}
        middle={(api) => (
          <DiscoveryCandidatesColumn api={api} workspace={workspace} />
        )}
        right={
          <DiscoveryWorkspace
            mode="threeColumn"
            workspace={workspace}
            onAfterObservation={handleAfterObservation}
          />
        }
      />
    </>
  )
}
