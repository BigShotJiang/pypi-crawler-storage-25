'use client'

import { ResizableWorkspaceLayout } from '@/components/layout'
import { BuilderSidebar } from '@/components/builder'
import { BuilderPreview } from '@/components/builder'

export default function BuilderPage() {
  return (
    <ResizableWorkspaceLayout
      groupId="builder-layout"
      renderSidebar={(api) => <BuilderSidebar {...api} />}
    >
      <BuilderPreview />
    </ResizableWorkspaceLayout>
  )
}
