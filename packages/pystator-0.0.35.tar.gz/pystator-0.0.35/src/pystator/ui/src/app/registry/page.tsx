'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  createRegistryCatalog,
  deleteRegistryCatalog,
  exportRegistryCatalogYaml,
  importRegistryCatalogYaml,
  listRegistryCatalog,
  resolveRegistryEntryPoint,
  updateRegistryCatalog,
  validateRegistryCatalogYaml,
  type RegistryCatalogItem,
  type RegistryKind,
} from '@/lib/api'
import LoadingSpinner from '@/components/LoadingSpinner'
import { useAuthStore, selectIsAdmin } from '@/stores/auth'
import {
  CheckCircle2,
  Download,
  Pencil,
  Plus,
  Trash2,
  Upload,
  X,
  XCircle,
  Zap,
} from 'lucide-react'
import { cn } from '@/lib/utils'

type KindFilter = 'all' | RegistryKind

interface FormState {
  kind: RegistryKind
  name: string
  entry_point: string
  description: string
  params_schema_json: string
  enabled: boolean
  version_label: string
}

const EMPTY_FORM: FormState = {
  kind: 'action',
  name: '',
  entry_point: '',
  description: '',
  params_schema_json: '',
  enabled: true,
  version_label: '',
}

function itemToForm(row: RegistryCatalogItem): FormState {
  return {
    kind: row.kind,
    name: row.name,
    entry_point: row.entry_point,
    description: row.description ?? '',
    params_schema_json:
      row.params_schema != null ? JSON.stringify(row.params_schema, null, 2) : '',
    enabled: row.enabled,
    version_label: row.version_label ?? '',
  }
}

export default function RegistryPage() {
  const isAdmin = useAuthStore(selectIsAdmin)
  const [items, setItems] = useState<RegistryCatalogItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [kindFilter, setKindFilter] = useState<KindFilter>('all')

  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState<FormState>(EMPTY_FORM)
  const [saving, setSaving] = useState(false)
  const [formError, setFormError] = useState<string | null>(null)

  const [resolveBusy, setResolveBusy] = useState<string | null>(null)
  const [resolveResult, setResolveResult] = useState<
    Record<string, { ok: boolean; error: string | null }>
  >({})

  const [artifactBusy, setArtifactBusy] = useState(false)
  const importMergeRef = useRef<HTMLInputElement>(null)
  const importReplaceRef = useRef<HTMLInputElement>(null)

  const fetchList = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const kind = kindFilter === 'all' ? undefined : kindFilter
      const res = await listRegistryCatalog(kind)
      setItems(res.items)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load registry catalog')
    } finally {
      setLoading(false)
    }
  }, [kindFilter])

  useEffect(() => {
    fetchList()
  }, [fetchList])

  const openCreate = () => {
    setEditingId(null)
    setForm(EMPTY_FORM)
    setFormError(null)
    setShowForm(true)
  }

  const openEdit = (row: RegistryCatalogItem) => {
    setEditingId(row.id)
    setForm(itemToForm(row))
    setFormError(null)
    setShowForm(true)
  }

  const closeForm = () => {
    setShowForm(false)
    setEditingId(null)
    setForm(EMPTY_FORM)
    setFormError(null)
  }

  const parseParamsSchema = (): Record<string, unknown> | null | undefined => {
    const raw = form.params_schema_json.trim()
    if (!raw) return null
    try {
      const v = JSON.parse(raw) as unknown
      if (v === null || typeof v !== 'object' || Array.isArray(v)) {
        setFormError('params_schema must be a JSON object')
        return undefined
      }
      return v as Record<string, unknown>
    } catch {
      setFormError('params_schema must be valid JSON')
      return undefined
    }
  }

  const handleSave = async () => {
    if (!form.name.trim()) {
      setFormError('Name is required')
      return
    }
    if (!form.entry_point.trim()) {
      setFormError('Entry point is required')
      return
    }
    const params_schema = parseParamsSchema()
    if (params_schema === undefined) return

    setSaving(true)
    setFormError(null)
    try {
      if (editingId) {
        await updateRegistryCatalog(editingId, {
          name: form.name.trim(),
          entry_point: form.entry_point.trim(),
          description: form.description.trim() || null,
          enabled: form.enabled,
          version_label: form.version_label.trim() || null,
          params_schema: params_schema,
        })
      } else {
        await createRegistryCatalog({
          kind: form.kind,
          name: form.name.trim(),
          entry_point: form.entry_point.trim(),
          description: form.description.trim() || null,
          params_schema: params_schema ?? null,
          enabled: form.enabled,
          version_label: form.version_label.trim() || null,
        })
      }
      closeForm()
      await fetchList()
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this catalog entry? Workers must be restarted to pick up changes.')) {
      return
    }
    try {
      await deleteRegistryCatalog(id)
      await fetchList()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete')
    }
  }

  const handleResolve = async (row: RegistryCatalogItem) => {
    setResolveBusy(row.id)
    try {
      const r = await resolveRegistryEntryPoint(row.entry_point)
      setResolveResult((prev) => ({
        ...prev,
        [row.id]: { ok: r.ok, error: r.error },
      }))
    } catch (e) {
      setResolveResult((prev) => ({
        ...prev,
        [row.id]: {
          ok: false,
          error: e instanceof Error ? e.message : 'Resolve failed',
        },
      }))
    } finally {
      setResolveBusy(null)
    }
  }

  const filteredCount = items.length

  const handleExportYaml = async () => {
    setArtifactBusy(true)
    setError(null)
    try {
      const yamlText = await exportRegistryCatalogYaml()
      const blob = new Blob([yamlText], { type: 'application/x-yaml' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'registry.yaml'
      a.click()
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export failed')
    } finally {
      setArtifactBusy(false)
    }
  }

  const runImportFile = async (file: File, replace: boolean) => {
    const text = await file.text()
    const v = await validateRegistryCatalogYaml(text)
    if (!v.ok) {
      setError(v.errors.length ? v.errors.join('\n') : 'Validation failed')
      return
    }
    setArtifactBusy(true)
    setError(null)
    try {
      await importRegistryCatalogYaml(text, { replace })
      await fetchList()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Import failed')
    } finally {
      setArtifactBusy(false)
    }
  }

  return (
    <PageContainer padding="sm">
      <div className="sticky top-0 z-30 -mt-2 mb-4 space-y-3 border-b border-border/60 bg-background/95 pb-3 pt-1 backdrop-blur-md">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <h1 className="text-xl font-semibold tracking-tight sm:text-2xl">Registry</h1>
            <p className="text-xs text-muted-foreground sm:text-sm">
              Named actions and guards (entry points). Like FSM machines, the catalog lives in the
              database only—there is no separate registry file path on workers. Use export/import here
              for YAML interchange (templates, backups, CI). Restart workers after changes.
            </p>
          </div>
          {isAdmin && !showForm && (
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={importMergeRef}
                type="file"
                accept=".yaml,.yml,application/x-yaml,text/yaml,text/plain"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0]
                  e.target.value = ''
                  if (!f) return
                  await runImportFile(f, false)
                }}
              />
              <input
                ref={importReplaceRef}
                type="file"
                accept=".yaml,.yml,application/x-yaml,text/yaml,text/plain"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0]
                  e.target.value = ''
                  if (!f) return
                  if (
                    !window.confirm(
                      'Replace the entire catalog with this file? All existing rows will be removed first.'
                    )
                  ) {
                    return
                  }
                  await runImportFile(f, true)
                }}
              />
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={artifactBusy}
                onClick={handleExportYaml}
              >
                <Download className="mr-1.5 h-4 w-4" />
                Export YAML
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={artifactBusy}
                onClick={() => importMergeRef.current?.click()}
              >
                <Upload className="mr-1.5 h-4 w-4" />
                Import (merge)
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={artifactBusy}
                onClick={() => importReplaceRef.current?.click()}
              >
                <Upload className="mr-1.5 h-4 w-4" />
                Import (replace)
              </Button>
              <Button type="button" size="sm" onClick={openCreate}>
                <Plus className="mr-1.5 h-4 w-4" />
                Add entry
              </Button>
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-2" role="tablist" aria-label="Filter by kind">
          {(
            [
              ['all', 'All'],
              ['action', 'Actions'],
              ['guard', 'Guards'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={kindFilter === id}
              className={cn(
                'rounded-md px-3 py-1.5 text-xs font-medium transition-colors sm:text-sm',
                kindFilter === id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:text-foreground'
              )}
              onClick={() => setKindFilter(id)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="mb-4 rounded-md border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {error}
        </div>
      )}

      {!isAdmin && (
        <p className="mb-4 text-sm text-muted-foreground">
          You can browse entries. Creating, editing, and deleting requires an Admin account.
        </p>
      )}

      {showForm && isAdmin && (
        <Card className="mb-6">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-base font-semibold">
              {editingId ? 'Edit catalog entry' : 'New catalog entry'}
            </CardTitle>
            <Button type="button" size="sm" variant="ghost" onClick={closeForm}>
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {formError && (
              <div className="rounded-md border border-destructive/50 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {formError}
              </div>
            )}
            {!editingId && (
              <div className="space-y-1.5">
                <Label htmlFor="reg-kind">Kind</Label>
                <select
                  id="reg-kind"
                  className="flex h-9 w-full max-w-xs rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                  value={form.kind}
                  onChange={(e) =>
                    setForm((p) => ({ ...p, kind: e.target.value as RegistryKind }))
                  }
                >
                  <option value="action">action</option>
                  <option value="guard">guard</option>
                </select>
              </div>
            )}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="reg-name">Name</Label>
                <Input
                  id="reg-name"
                  placeholder="notify_ops"
                  value={form.name}
                  onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="reg-ver">Version label (optional)</Label>
                <Input
                  id="reg-ver"
                  placeholder="2026.04"
                  value={form.version_label}
                  onChange={(e) => setForm((p) => ({ ...p, version_label: e.target.value }))}
                />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reg-ep">Entry point</Label>
              <Input
                id="reg-ep"
                placeholder="mypackage.actions:notify_ops"
                value={form.entry_point}
                onChange={(e) => setForm((p) => ({ ...p, entry_point: e.target.value }))}
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground">
                Python import path: <code className="rounded bg-muted px-0.5">module:callable</code>{' '}
                (must exist in the API/worker deployment).
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reg-desc">Description</Label>
              <Input
                id="reg-desc"
                placeholder="Short description for operators"
                value={form.description}
                onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reg-schema">Params schema (JSON object, optional)</Label>
              {editingId ? (
                <p className="text-xs text-muted-foreground">
                  Clear the field and save to remove a stored schema.
                </p>
              ) : null}
              <textarea
                id="reg-schema"
                className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 font-mono text-xs shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                placeholder='{"type":"object","properties":{...}}'
                value={form.params_schema_json}
                onChange={(e) => setForm((p) => ({ ...p, params_schema_json: e.target.value }))}
              />
            </div>
            <div className="flex items-center gap-2">
              <Switch
                id="reg-en"
                checked={form.enabled}
                onCheckedChange={(v) => setForm((p) => ({ ...p, enabled: v }))}
              />
              <Label htmlFor="reg-en">Enabled</Label>
            </div>
            <div className="flex gap-2">
              <Button type="button" onClick={handleSave} disabled={saving}>
                {saving ? 'Saving…' : editingId ? 'Save changes' : 'Create'}
              </Button>
              <Button type="button" variant="outline" onClick={closeForm}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {loading ? (
        <div className="flex justify-center py-12">
          <LoadingSpinner />
        </div>
      ) : (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              Catalog
              <span className="ml-2 text-sm font-normal text-muted-foreground">
                ({filteredCount} {filteredCount === 1 ? 'entry' : 'entries'})
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0 sm:p-6">
            {items.length === 0 ? (
              <p className="px-4 py-8 text-center text-sm text-muted-foreground sm:px-6">
                No catalog entries. Admins can add rows, import YAML (e.g.{' '}
                <code className="rounded bg-muted px-1 text-xs">
                  pystator/data/seed/registry_catalog.yaml
                </code>
                ), run <code className="rounded bg-muted px-1 text-xs">pystator db seed</code>, or use
                migrations.
              </p>
            ) : (
              <table className="w-full min-w-[720px] border-collapse text-sm">
                <thead>
                  <tr className="border-b text-left text-muted-foreground">
                    <th className="px-3 py-2 font-medium sm:px-4">Kind</th>
                    <th className="px-3 py-2 font-medium sm:px-4">Name</th>
                    <th className="px-3 py-2 font-medium sm:px-4">Entry point</th>
                    <th className="px-3 py-2 font-medium sm:px-4">Enabled</th>
                    <th className="hidden px-3 py-2 font-medium md:table-cell sm:px-4">
                      Description
                    </th>
                    <th className="px-3 py-2 text-right font-medium sm:px-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((row) => (
                    <tr key={row.id} className="border-b border-border/60 hover:bg-muted/40">
                      <td className="px-3 py-2.5 sm:px-4">
                        <span
                          className={cn(
                            'rounded px-1.5 py-0.5 text-xs font-medium',
                            row.kind === 'action'
                              ? 'bg-primary/15 text-primary'
                              : 'bg-secondary text-secondary-foreground'
                          )}
                        >
                          {row.kind}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 font-medium sm:px-4">{row.name}</td>
                      <td className="max-w-[240px] truncate px-3 py-2.5 font-mono text-xs sm:max-w-xs sm:px-4">
                        {row.entry_point}
                      </td>
                      <td className="px-3 py-2.5 sm:px-4">{row.enabled ? 'Yes' : 'No'}</td>
                      <td className="hidden max-w-xs truncate px-3 py-2.5 text-muted-foreground md:table-cell sm:px-4">
                        {row.description ?? '—'}
                      </td>
                      <td className="px-3 py-2.5 text-right sm:px-4">
                        <div className="flex flex-wrap justify-end gap-1">
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            title="Check entry point in this server"
                            disabled={resolveBusy === row.id}
                            onClick={() => handleResolve(row)}
                          >
                            <Zap className="h-3.5 w-3.5" />
                          </Button>
                          {resolveResult[row.id] && (
                            <span
                              className="inline-flex items-center"
                              title={resolveResult[row.id]!.error ?? ''}
                            >
                              {resolveResult[row.id]!.ok ? (
                                <CheckCircle2 className="h-4 w-4 text-green-600" />
                              ) : (
                                <XCircle className="h-4 w-4 text-destructive" />
                              )}
                            </span>
                          )}
                          {isAdmin && (
                            <>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2"
                                onClick={() => openEdit(row)}
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                type="button"
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2 text-destructive hover:text-destructive"
                                onClick={() => handleDelete(row.id)}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </CardContent>
        </Card>
      )}
    </PageContainer>
  )
}
