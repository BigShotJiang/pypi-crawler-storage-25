"""Inline Python action (config ``code:``) — gated by env / ``pystator.cfg`` (see ``config.features``).

When disabled, set ``PYSTATOR_ALLOW_INLINE_CODE_ACTIONS`` or ``[features]`` in ``pystator.cfg``.
With the base flag on only: ``exec`` uses ``ctx`` and empty ``__builtins__``.
With ``PYSTATOR_ALLOW_INLINE_CODE_IMPORTS`` also on: restricted builtins, allowlisted
``import``, and pre-bound ``json`` / ``requests`` / ``numpy`` / safe ``yaml`` (see
:mod:`pystator.code_action_namespace`).
"""

from __future__ import annotations

import textwrap
from typing import Any

from pystator.actions import ActionResult
from pystator.config.features import (
    get_allow_inline_code_actions,
    get_allow_inline_code_imports,
)


def execute_code_action(
    params: dict[str, Any], context: dict[str, Any]
) -> ActionResult:
    """Execute ``code`` action: ``exec`` source with mutable ``ctx`` (same dict as context)."""
    if not get_allow_inline_code_actions():
        return ActionResult.fail(
            "_code",
            RuntimeError(
                "Inline code actions are disabled. Enable via environment variable "
                "PYSTATOR_ALLOW_INLINE_CODE_ACTIONS or pystator.cfg section [features]."
            ),
        )
    source = params.get("source")
    if not isinstance(source, str) or not source.strip():
        return ActionResult.fail(
            "_code", ValueError("code action requires non-empty source string")
        )
    # Pasted snippets are often uniformly indented (e.g. copied from inside a def).
    # Dedent so module-level statements are valid; blank lines do not affect margin.
    source = textwrap.dedent(source)

    if get_allow_inline_code_imports():
        from pystator.code_action_namespace import build_imports_enabled_namespace

        ns = build_imports_enabled_namespace(context)
    else:
        ns = {"ctx": context, "__builtins__": {}}
    try:
        exec(compile(source, "<fsm_code_action>", "exec"), ns, ns)
    except Exception as e:
        return ActionResult.fail("_code", e)
    return ActionResult.ok("_code", None)
