"""Dynamic import utilities for dotted-path resolution.

Used by the guard and action registries to auto-import functions
specified as dotted module paths in YAML config (e.g.
``my_app.guards.is_valid``).
"""

from __future__ import annotations

import importlib
import logging
from typing import Any

logger = logging.getLogger(__name__)


def import_dotted(dotted_path: str) -> Any | None:
    """Import a callable from a dotted module path.

    Splits ``"my_app.guards.is_valid"`` into module ``my_app.guards``
    and attribute ``is_valid``, then dynamically imports and returns it.

    Args:
        dotted_path: Fully qualified ``module.attribute`` path.

    Returns:
        The callable if found, or ``None`` on import/attribute failure.
    """
    parts = dotted_path.rsplit(".", 1)
    if len(parts) != 2:
        return None
    module_path, attr_name = parts
    try:
        module = importlib.import_module(module_path)
        return getattr(module, attr_name, None)
    except (ImportError, AttributeError):
        logger.debug("Could not import '%s'", dotted_path)
        return None
