"""Resolve ``module:attr`` or ``module:nested.attr`` entry-point strings."""

from __future__ import annotations

import importlib
from typing import Any


def resolve_entry_point(spec: str) -> Any:
    """Import and return a callable from an entry-point string.

    Format: ``dotted.module.path:callable`` or ``pkg.mod:Class.method`` —
    the part after the **last** ``:`` is split on ``.`` for nested attributes.

    Raises:
        ValueError: invalid spec or module not found.
        TypeError: resolved object is not callable.
    """
    s = spec.strip()
    if ":" not in s:
        raise ValueError(
            f"Invalid entry point {spec!r}: expected 'module:attr' or 'module:nested.attr'"
        )
    mod_name, attr_path = s.rsplit(":", 1)
    mod_name = mod_name.strip()
    attr_path = attr_path.strip()
    if not mod_name or not attr_path:
        raise ValueError(f"Invalid entry point {spec!r}: empty module or attribute")

    try:
        mod = importlib.import_module(mod_name)
    except ModuleNotFoundError as e:
        raise ValueError(
            f"Cannot import module {mod_name!r} for entry point {spec!r}"
        ) from e
    obj: Any = mod
    for part in attr_path.split("."):
        obj = getattr(obj, part)

    if not callable(obj):
        raise TypeError(
            f"Entry point {spec!r} does not resolve to a callable (got {type(obj).__name__})"
        )
    return obj
