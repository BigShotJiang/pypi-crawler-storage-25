"""Parse and serialize registry catalog YAML (import/export, tests, ``load_manifest_path`` for files).

Runtime workers load **only** from the database; this module does not read config paths.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from pystator.errors import ConfigurationError
from pystator.registry.types import CatalogEntry, CatalogKind


def _parse_block(
    kind: CatalogKind,
    items: Any,
    *,
    source: str,
) -> list[CatalogEntry]:
    if items is None:
        return []
    if not isinstance(items, list):
        raise ConfigurationError(
            f"Registry manifest '{kind}s' must be a list",
            path=source,
        )
    out: list[CatalogEntry] = []
    for i, raw in enumerate(items):
        if not isinstance(raw, dict):
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {i} must be a mapping",
                path=source,
            )
        name = raw.get("name")
        ep = raw.get("entry_point")
        if not isinstance(name, str) or not name.strip():
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {i} needs non-empty string 'name'",
                path=source,
            )
        if not isinstance(ep, str) or not ep.strip():
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {i!r} needs non-empty string 'entry_point'",
                path=source,
            )
        desc = raw.get("description")
        if desc is not None and not isinstance(desc, str):
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {name!r}: 'description' must be a string",
                path=source,
            )
        params_schema = raw.get("params_schema")
        if params_schema is not None and not isinstance(params_schema, dict):
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {name!r}: 'params_schema' must be an object",
                path=source,
            )
        enabled = raw.get("enabled", True)
        if not isinstance(enabled, bool):
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {name!r}: 'enabled' must be a boolean",
                path=source,
            )
        ver = raw.get("version_label")
        if ver is not None and not isinstance(ver, str):
            raise ConfigurationError(
                f"Registry manifest '{kind}s' item {name!r}: 'version_label' must be a string",
                path=source,
            )
        out.append(
            CatalogEntry(
                kind=kind,
                name=name.strip(),
                entry_point=ep.strip(),
                description=desc.strip()
                if isinstance(desc, str) and desc.strip()
                else None,
                params_schema=params_schema,
                enabled=enabled,
                version_label=ver.strip()
                if isinstance(ver, str) and ver.strip()
                else None,
                source="manifest",
            )
        )
    return out


def parse_manifest_yaml_text(
    text: str, *, source: str = "<string>"
) -> list[CatalogEntry]:
    """Parse registry YAML from a string (same schema as :func:`load_manifest_path`)."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise ConfigurationError(
            f"Invalid YAML in registry manifest: {e}",
            path=source,
        ) from e

    if data is None:
        return []
    if not isinstance(data, dict):
        raise ConfigurationError(
            "Registry manifest must be a mapping at the top level",
            path=source,
        )

    actions = _parse_block("action", data.get("actions"), source=source)
    guards = _parse_block("guard", data.get("guards"), source=source)
    return actions + guards


def load_manifest_path(path: str | Path) -> list[CatalogEntry]:
    """Parse a YAML manifest file into catalog entries.

    Expected top-level keys (optional): ``actions``, ``guards`` — each a list of
    objects with ``name``, ``entry_point``, and optional ``description``,
    ``params_schema``, ``enabled``, ``version_label``.
    """
    p = Path(path)
    if not p.is_file():
        raise ConfigurationError(
            f"Registry manifest not found: {p}",
            path=str(p),
        )
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as e:
        raise ConfigurationError(
            f"Cannot read registry manifest: {e}",
            path=str(p),
        ) from e

    return parse_manifest_yaml_text(text, source=str(p.resolve()))


def catalog_entries_to_yaml_text(entries: list[CatalogEntry]) -> str:
    """Serialize catalog entries to registry YAML (``actions`` / ``guards`` lists)."""
    actions: list[dict[str, Any]] = []
    guards: list[dict[str, Any]] = []
    for e in sorted(entries, key=lambda x: (x.kind, x.name)):
        block = guards if e.kind == "guard" else actions
        row: dict[str, Any] = {
            "name": e.name,
            "entry_point": e.entry_point,
        }
        if e.description:
            row["description"] = e.description
        if e.params_schema is not None:
            row["params_schema"] = e.params_schema
        if not e.enabled:
            row["enabled"] = False
        if e.version_label:
            row["version_label"] = e.version_label
        block.append(row)
    doc: dict[str, Any] = {}
    if actions:
        doc["actions"] = actions
    if guards:
        doc["guards"] = guards
    if not doc:
        return "# Empty registry catalog\n"
    return yaml.safe_dump(
        doc,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
    )
