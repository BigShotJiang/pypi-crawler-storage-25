"""Distributed registry: load named actions/guards from the database (YAML via import/export only)."""

from __future__ import annotations

from pystator.registry.loader import (
    apply_catalog_entries,
    load_catalog_from_database,
    load_registry_from_app_config,
    load_registry_into_registries,
)
from pystator.registry.resolve import resolve_entry_point
from pystator.registry.types import CatalogEntry, CatalogKind
from pystator.registry.yaml_manifest import (
    catalog_entries_to_yaml_text,
    load_manifest_path,
    parse_manifest_yaml_text,
)

__all__ = [
    "CatalogEntry",
    "CatalogKind",
    "apply_catalog_entries",
    "catalog_entries_to_yaml_text",
    "load_catalog_from_database",
    "load_manifest_path",
    "load_registry_from_app_config",
    "load_registry_into_registries",
    "parse_manifest_yaml_text",
    "resolve_entry_point",
]
