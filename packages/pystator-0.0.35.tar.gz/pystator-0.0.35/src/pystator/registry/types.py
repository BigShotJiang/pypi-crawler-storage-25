"""Typed catalog entries for persisted action/guard registry."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

CatalogKind = Literal["action", "guard"]


@dataclass(frozen=True, slots=True)
class CatalogEntry:
    """One row of the registry catalog (file or database)."""

    kind: CatalogKind
    name: str
    entry_point: str
    description: str | None = None
    params_schema: dict[str, Any] | None = None
    enabled: bool = True
    version_label: str | None = None
    source: Literal["database", "manifest"] = "manifest"
