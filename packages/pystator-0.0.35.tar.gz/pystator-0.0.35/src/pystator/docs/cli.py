"""CLI for documentation: ``pystator docs serve`` and ``pystator docs build``.

Delegates to MkDocs. Docs root is the repo checkout (walk-up from the package)
when present so ``mkdocs serve`` watches live ``docs/``; ``_bundled_docs`` is
only used as a fallback (e.g. wheel install). Override with ``DOCS_ROOT`` or run
from the directory that contains ``mkdocs.yml``.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from pystator.config.ports import DOCS_PORT


def _get_docs_root() -> Path | None:
    """Return the directory containing mkdocs.yml, or None if not found.

    Search order:
        1. ``DOCS_ROOT`` environment variable (explicit override).
        2. Current working directory (repo checkout convenience).
        3. Walk up parent directories from the installed module — **before**
           bundled docs so local ``docs/`` edits reload during development
           (bundled under ``_bundled_docs/`` is a stale snapshot until rebuild).
        4. Bundled docs inside the package (wheel installs / fallback).
    """
    # 1. Environment variable override
    env_root = os.environ.get("DOCS_ROOT")
    if env_root:
        p = Path(env_root).resolve()
        if (p / "mkdocs.yml").exists():
            return p
        return None

    # 2. Current working directory
    cwd = Path.cwd()
    if (cwd / "mkdocs.yml").exists():
        return cwd

    # 3. Walk up from package → repo root (editable / dev; live MkDocs watch)
    try:
        import pystator

        start = Path(pystator.__file__).resolve().parent
    except (ImportError, AttributeError):
        start = None

    if start is not None:
        current = start
        for _ in range(10):
            if (current / "mkdocs.yml").exists():
                return current
            parent = current.parent
            if parent == current:
                break
            current = parent

    # 4. Bundled snapshot (e.g. plain pip install without a checkout)
    try:
        import pystator

        pkg_dir = Path(pystator.__file__).resolve().parent
        bundled = pkg_dir / "_bundled_docs"
        if (bundled / "mkdocs.yml").exists():
            return bundled
    except (ImportError, AttributeError):
        pass

    return None


DEFAULT_DOCS_PORT = DOCS_PORT


def cmd_docs_serve(host: str = "127.0.0.1", port: int = DOCS_PORT) -> int:
    """Run ``mkdocs serve`` for local preview."""
    root = _get_docs_root()
    if not root:
        print(
            "❌ mkdocs.yml not found. Run from the project root (where mkdocs.yml lives), "
            "or set DOCS_ROOT to that directory.",
            file=sys.stderr,
        )
        return 1

    print(f"📚 MkDocs project directory: {root}", file=sys.stderr)
    if root.name == "_bundled_docs" or "_bundled_docs" in root.parts:
        print(
            "⚠️  Serving from packaged _bundled_docs (snapshot). File changes in your "
            "checkout may NOT reload until you run from the repo root, reinstall editable "
            '(`pip install -e ".[dev]"`), or set DOCS_ROOT to the directory that contains mkdocs.yml.',
            file=sys.stderr,
        )

    try:
        subprocess.run(
            [sys.executable, "-m", "mkdocs", "serve", "-a", f"{host}:{port}"],
            cwd=str(root),
            check=True,
        )
    except FileNotFoundError:
        print(
            "❌ MkDocs not found. Install with: pip install pystator[api]",
            file=sys.stderr,
        )
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode

    return 0


def cmd_docs_build() -> int:
    """Run ``mkdocs build`` to produce the static site."""
    root = _get_docs_root()
    if not root:
        print(
            "❌ mkdocs.yml not found. Run from the project root (where mkdocs.yml lives), "
            "or set DOCS_ROOT to that directory.",
            file=sys.stderr,
        )
        return 1

    try:
        subprocess.run(
            [sys.executable, "-m", "mkdocs", "build"],
            cwd=str(root),
            check=True,
        )
    except FileNotFoundError:
        print(
            "❌ MkDocs not found. Install with: pip install pystator[api]",
            file=sys.stderr,
        )
        return 1
    except subprocess.CalledProcessError as e:
        return e.returncode

    return 0
