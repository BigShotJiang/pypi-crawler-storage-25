#!/bin/bash
################################################################################
# Setup script for PyStator development environment
#
# Creates venv, installs dev dependencies, optional API/UI deps,
# and pre-commit hooks. Run from the repo root:
#   ./scripts/setup.sh
#   bash /path/to/pystator/scripts/setup.sh
################################################################################

set -euo pipefail  # Exit on error, undefined vars, pipe failures

# Avoid pyenv rehash hanging 60s if triggered (e.g. by python3 -m venv)
export PYENV_REHASH_TIMEOUT=0

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

info() { echo -e "${BLUE}ℹ${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }
warning() { echo -e "${YELLOW}⚠${NC} $1"; }
error() { echo -e "${RED}✗${NC} $1" >&2; }

# Check if Python 3 is available
if ! command -v python3 &> /dev/null; then
    error "Python 3 is not installed. Please install Python 3.10 or higher."
    exit 1
fi

# Check Python version (requires 3.10+)
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)
if ! [[ "$PYTHON_MAJOR" =~ ^[0-9]+$ ]] || ! [[ "$PYTHON_MINOR" =~ ^[0-9]+$ ]]; then
    error "Could not parse Python version. Found: $PYTHON_VERSION"
    exit 1
fi
if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    error "Python 3.11 or higher is required. Found: $PYTHON_VERSION"
    exit 1
fi

info "Python version: $PYTHON_VERSION"
echo ""

# Recreate venv if the repo was moved: bin/activate embeds the old absolute path (PATH won't include this venv).
WANT_VENV="$(cd "$REPO_ROOT" && pwd -P)/venv"
if [ -f venv/bin/activate ]; then
    GOT_VENV=$(grep -m1 'export VIRTUAL_ENV=/' venv/bin/activate | sed 's/.*export VIRTUAL_ENV=//; s/\r//' || true)
    if [ -n "${GOT_VENV:-}" ] && [ "$GOT_VENV" != "$WANT_VENV" ]; then
        info "Removing virtual environment (was created at $GOT_VENV; expected $WANT_VENV)..."
        rm -rf venv
    fi
fi

# Create virtual environment (or recreate if broken)
if [ ! -d "venv" ] || [ ! -f "venv/bin/python" ]; then
    if [ -d "venv" ]; then
        info "Removing broken or incomplete virtual environment..."
        rm -rf venv
    fi
    info "Creating virtual environment..."
    python3 -m venv venv
    success "Virtual environment created"
else
    success "Virtual environment already exists"
fi

# Use venv interpreter explicitly — avoids pyenv rehash and never uses the wrong pip on PATH
VENV_PY="$REPO_ROOT/venv/bin/python"
if [ ! -x "$VENV_PY" ]; then
    error "venv interpreter missing or not executable: $VENV_PY"
    exit 1
fi
info "Using virtualenv: $VENV_PY"

info "Upgrading pip, setuptools, and wheel..."
"$VENV_PY" -m pip install --upgrade pip setuptools wheel --quiet

# Install package in development mode
info "Installing PyStator in development mode..."
if "$VENV_PY" -m pip install -e ".[dev]" --quiet; then
    success "PyStator installed with dev dependencies"
else
    error "Failed to install PyStator. Check the error messages above."
    exit 1
fi

# Pre-commit hooks (same as pycharter: run on commit so CI stays green)
if "$VENV_PY" -c "import pre_commit" 2>/dev/null; then
    info "Installing pre-commit hooks..."
    "$VENV_PY" -m pre_commit install
    "$VENV_PY" -m pre_commit install --hook-type pre-push
    success "Pre-commit hooks installed."
else
    warning "pre-commit not installed in venv. Add it to [dev] extras and re-run setup."
fi

# Install API dependencies if API exists (src layout)
if [ -d "src/pystator/api" ]; then
    info "Installing API dependencies (required for API server)..."
    if "$VENV_PY" -m pip install -e ".[api]" --quiet; then
        success "API dependencies installed"
    else
        warning "Failed to install API dependencies. API server may not work."
    fi
fi

# Install UI dependencies if UI exists (src layout)
if [ -d "src/pystator/ui" ]; then
    info "Installing UI dependencies (required for UI server)..."
    if "$VENV_PY" -m pip install -e ".[ui]" --quiet; then
        success "UI dependencies installed"
    else
        warning "Failed to install UI dependencies. UI server may not work."
    fi
fi

# Install UI npm dependencies (Next.js app)
if [ -f "src/pystator/ui/package.json" ]; then
    if command -v npm &> /dev/null; then
        info "Installing UI npm dependencies..."
        # Public registry avoids E401 when ~/.npmrc points at a private registry with stale auth.
        if (cd "src/pystator/ui" && npm install --silent --registry https://registry.npmjs.org/); then
            success "UI npm dependencies installed"
        else
            warning "Failed to install UI npm dependencies."
        fi
    else
        warning "npm not found. UI npm dependencies were not installed."
    fi
fi

echo ""
success "Setup complete!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📋 Quick Start"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "To activate the environment:"
echo "  source venv/bin/activate"
echo ""
echo "To start development servers:"
echo "  pystator api       # Start API server (http://localhost:8004)"
echo "  pystator ui dev   # Start UI dev server (http://localhost:3004)"
echo "  pystator docs serve # MkDocs (http://127.0.0.1:5004)"
echo "  pystator ui serve # Serve built UI (run 'pystator ui build' first)"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧪 Testing"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Run tests:"
echo "  pytest"
echo ""
echo "Run tests with coverage:"
echo "  pytest --cov=pystator"
echo ""
echo "Run Ruff or all pre-commit hooks:"
echo "  python -m pre_commit run --all-files"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "💡 Development Tips"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "• Package is installed in editable mode (-e), so code changes are"
echo "  reflected immediately (restart server to see changes)"
echo ""
echo "• To build the UI for production:"
echo "  pystator ui build   # Requires Node.js and npm in src/pystator/ui"
echo ""
