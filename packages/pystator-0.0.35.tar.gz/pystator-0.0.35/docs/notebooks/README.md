# Example notebooks

PyStator's hands-on material is primarily **Python scripts plus YAML FSM definitions** in the repository [`examples/`](https://github.com/optophi/pystator/tree/main/examples) tree, documented on the [Examples & Notebooks](../examples-and-notebooks.md) overview page.

**Marimo** demos (`.py` notebooks) live in the flat [`notebooks/`](https://github.com/optophi/pystator/tree/main/notebooks) directory in the repo; see [`notebooks/README.md`](https://github.com/optophi/pystator/blob/main/notebooks/README.md). They are not bundled as static pages in this documentation site. For narrative walkthroughs, use the [Tutorials](../tutorials/index.md) (for example [Order workflow](../tutorials/order-workflow.md) and [API and UI](../tutorials/api-and-ui.md)).
