# Contributing to PyStator

Thank you for your interest in contributing. This page is the **documentation hub** for contributors; the canonical dev guide with branch flow, Ruff/mypy, UI, and commit conventions lives in the repository root.

## Quick links

| Resource | Description |
|----------|-------------|
| **[CONTRIBUTING.md](https://github.com/optophi/pystator/blob/main/CONTRIBUTING.md)** (repo root) | Dev setup, tests, lint, UI, Conventional Commits, release branches |
| **[Publishing to PyPI](contributing/publishing.md)** | Tags, Trusted Publishing, `publish.yml` |
| **[Release workflow](contributing/release-workflow.md)** | Day-of-release checklist and verification |
| **[Code of Conduct](https://github.com/optophi/pystator/blob/main/CODE_OF_CONDUCT.md)** | Community standards |
| **[Security](https://github.com/optophi/pystator/blob/main/SECURITY.md)** | Responsible disclosure |

## Development setup (summary)

```bash
git clone https://github.com/optophi/pystator.git
cd pystator
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e ".[dev]"
pytest
```

Use **Ruff** for format/lint and **mypy** on `src/pystator` as described in **CONTRIBUTING.md**. Prefer **`python -m pre_commit install`** (and pre-push) so CI stays green.

## Documentation

This site is built with **MkDocs** and **mkdocstrings**. From the repo root, with **`[dev]`** installed:

```bash
pystator docs serve
# or: mkdocs serve -a 127.0.0.1:5004
```

See **CONTRIBUTING.md** for details on bundled docs and **`DOCS_ROOT`**.

## Maintainer guides

- [Publishing to PyPI](contributing/publishing.md)
- [Release workflow](contributing/release-workflow.md)
