# Reference

Reference documentation for PyStator.

| Document | Description |
|----------|-------------|
| [CLI (`pystator` commands)](cli.md) | `api`, `ui`, `db`, `machines`, `discovery`, `schema`, `worker`, `docs` — flags, defaults, and extra requirements. |
| [FSM configuration (YAML/JSON)](fsm-config.md) | Full schema for state machine definitions: `meta`, `states`, `transitions`, `error_policy`, and validation rules. |

For the Python API, see the [API reference overview](../api/index.md) (mkdocstrings) and the [condensed API list](../api.md). For design and architecture, see [Architecture](../guides/architecture.md).
