# Command-line interface

The `pystator` package installs a single entry point: **`pystator`** (`[project.scripts]` in `pyproject.toml`). Run `pystator --help` or `pystator <command> --help` for the latest flags.

## Requirements by command

| Command | Typical install |
|---------|-----------------|
| `api`, `db`, `machines`, `worker`, most `docs` | `pip install pystator[api]` (or `[worker]` / `[all]` as needed) |
| `ui` | `pip install pystator[ui]` (often with `[api]`) |
| `schema` | Needs **Pydantic** (declared in `[api]`). Core-only `pip install pystator` prints a hint to install `[api]`. |
| `discovery` | Discovery modules (same extras as API/DB in practice) |

Core-only installs support FSM usage from Python; HTTP, DB, and some CLIs need extras.

---

## `pystator api`

Start the FastAPI server (default host `0.0.0.0`, port from `pystator.config.ports`, typically **8004**).

```bash
pystator api
pystator api --port 8004 --reload
pystator api --no-reload
```

OpenAPI: **`http://<host>:<port>/docs`**.

---

## `pystator ui`

Next.js UI: serve the production build, run the dev server, or build static assets.

```bash
pystator ui serve [--api-url URL] [--host 127.0.0.1] [--port 3004]
pystator ui dev  [--api-url URL] [--port 3004]
pystator ui build
```

Requires a built UI for `serve` (see project README: `npm run build` under `src/pystator/ui`).

---

## `pystator db`

Database lifecycle: Alembic migrations against **`PYSTATOR_DATABASE_URL`** or the URL passed on the command line.

```text
pystator db init [database_url]
pystator db upgrade [database_url] [--revision head]
pystator db downgrade [database_url] [--revision -1]
pystator db current [database_url]
pystator db history [database_url]
pystator db stamp [database_url] [--revision head]
pystator db seed [seed_dir] [database_url]
pystator db truncate [database_url] [--force]
```

See [Configuration](../guides/configuration.md) and [Worker](../guides/worker.md) for URL and env conventions.

---

## `pystator machines`

Manage stored machine definitions (database-backed).

```text
pystator machines list
pystator machines get ...
pystator machines create ...
pystator machines delete ...
pystator machines seed ...
```

Use `pystator machines --help` for arguments (IDs, YAML paths, etc.).

---

## `pystator discovery`

Discovery inference CLI: observations → candidate FSMs.

```text
pystator discovery observe ...
pystator discovery preview ...
pystator discovery build ...
pystator discovery export ...
pystator discovery list ...
```

See [Discovery (inferred FSM)](../guides/discovery-inference.md).

---

## `pystator schema`

Print the **JSON Schema** for the Pydantic `MachineConfig` model (FSM YAML/JSON shape). Optional `-o` / `--output` to write a file.

```bash
pystator schema
pystator schema -o machine-config.schema.json
```

Requires **`pystator[api]`** (Pydantic).

---

## `pystator worker`

Run the background worker: polls **`worker_events`**, claims work, runs the orchestrator.

```bash
pystator worker
pystator worker --app mypackage.worker:create_worker
pystator worker --concurrency 10 --poll-interval 500
```

Requires **`pystator[worker]`** and a configured database. See [Worker](../guides/worker.md).

---

## `pystator docs`

Local MkDocs site (Material + mkdocstrings).

```bash
pystator docs serve [--host 127.0.0.1] [--port 5004]
pystator docs build    # output: site/
```

Requires **`pystator[docs]`**, **`pystator[api]`**, or **`pystator[dev]`** (docs dependencies are pulled in via those extras).

---

## Environment and ports

- Default ports are centralized in **`pystator.config.ports`** (API, UI, docs); override with flags or env where supported.
- Database URL: **`PYSTATOR_DATABASE_URL`** or **`pystator.cfg`** — see [Installation](../getting-started/installation.md) and [Configuration](../guides/configuration.md).
