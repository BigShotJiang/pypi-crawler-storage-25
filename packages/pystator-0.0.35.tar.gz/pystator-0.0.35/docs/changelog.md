# Changelog

Release history for PyStator is maintained in the repository **`CHANGELOG.md`**, generated from [Conventional Commits](https://www.conventionalcommits.org/) via the release pipeline.

**[View full changelog on GitHub](https://github.com/optophi/pystator/blob/main/CHANGELOG.md)**

For installable versions, see [PyPI — pystator](https://pypi.org/project/pystator/#history).
