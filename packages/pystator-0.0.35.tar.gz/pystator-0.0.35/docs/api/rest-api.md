# REST API

The PyStator REST API is documented and tryable in two places:

- **Swagger UI** — When the API is running, open `/docs` (e.g. `http://localhost:8004/docs`) for interactive request/response documentation and "Try it out" for every endpoint.
- **In-app API Playground** — From the PyStator UI, open the **API Playground** (Documentation) page to call endpoints with a minimal request body editor.

Both use the same OpenAPI schema; Swagger is the single source of truth for endpoint paths, methods, request bodies, and responses.

## Running the API

Start the API server:

```bash
pystator api
```

Or with uvicorn:

```bash
uvicorn pystator.api.main:app --host 0.0.0.0 --port 8004
```

Then open [http://localhost:8004/docs](http://localhost:8004/docs) for the full REST API reference.

## Stateless transition (`POST /api/v1/process`)

Send the full FSM **`config`**, **`current_state`**, **`trigger`**, and optional **`context`**. The server builds a machine with **pass-through guards** (named guards in YAML always pass unless you add custom middleware). It returns **HTTP 200** with `success`, `source_state`, `target_state`, structured `error` when the transition fails, and:

- **`actions_to_execute`** — transition actions (names + params, e.g. `code:` / `http:` specs)
- **`on_exit_actions`**, **`on_enter_actions`** — state lifecycle actions

The server **does not** execute those actions, **does not** persist entity rows, and **does not** run inline **`code:`** Python. That matches `StateMachine.process(...)` in the library: compute only. Use this for diagramming, validation flows, or when **your** app runs `ActionExecutor` after persisting state.

**Python equivalent:** `FSMService().process(...)` in `pystator.api.services.fsm_service` (same dict shape as the JSON body).

## Entity lifecycle

- **Create (initial state only):** `POST /api/v1/entities/{entity_id}/create` with JSON body `{ "machine_name": "...", "machine_version": "..." (optional), "context": {} (optional) }`. Persists the entity at the machine’s initial state and writes a history row with trigger `__entity_created__`. Returns **409** if `entity_id` already exists.
- **Process an event:** `POST /api/v1/entities/{entity_id}/events` with a `trigger` (and optional `context`, `machine_name`, `machine_version`) — runs the **orchestrator**: loads state and persisted context from the database, evaluates guards, persists the new state, **executes transition actions** (`code:`, `http:`, registry actions), writes updated context, and appends a history row. The response is returned when processing completes (synchronous HTTP). Optional **`action_results`** lists per-action outcomes (`name`, `success`, `status`, `error`). **Not** the same as `POST /process`, which is stateless compute-only and does not run actions or touch entity rows. Archived or deleted entities return **409** via `EntityNotActiveError`.
- **Dry-run:** `POST /api/v1/entities/{entity_id}/dry-run` — evaluates whether a trigger would succeed from the entity’s current state **without** persisting state, running actions, or writing history. Response includes `would_succeed`, `target_state` when applicable, and **`actions_that_would_execute`** (names only).
- **Enqueue apply-data (worker):** `POST /api/v1/entities/{entity_id}/apply-data` — enqueues a **triggerless** context merge for **`pystator worker`** (`submit_apply_data`); returns an **`event_id`**. Does not run the orchestrator inline. (There is no generic HTTP “enqueue this trigger” endpoint; use **`submit_event`** from Python or insert into **`worker_events`** for queued **named** triggers.)

## Bulk entities

Under **`/api/v1/entities/bulk`** (registered before per-entity routes so `bulk` is not captured as `entity_id`):

- **`POST .../entities/bulk/create`** — create many entities at initial state in one request; per-item errors in the response body.
- **`POST .../entities/bulk/events`** — run the same **trigger** against many **`entity_ids`**; each row uses the full orchestrator path (including action execution); per-entity results in the response.

## Settings and runtime

**`/api/v1/settings/...`** exposes database tests, DLQ checks, discovery DB config, optional **admin** **server-config** read/patch (`pystator.cfg`), and runtime overview fields useful for operators (e.g. **`allow_inline_code_actions`** / **`allow_inline_code_actions_source`** for **`code:`** actions). See OpenAPI **`/docs`** for the full list; many routes require auth when JWT is configured.

## Worker vs HTTP

For **fire-and-forget server-side** processing of **named triggers** (worker runs actions), use **`pystator.worker.submit_event`** / **`submit_event_sync`** and run **`pystator worker`** against the same database as **`PYSTATOR_DATABASE_URL`**. See [Worker](../guides/worker.md).
