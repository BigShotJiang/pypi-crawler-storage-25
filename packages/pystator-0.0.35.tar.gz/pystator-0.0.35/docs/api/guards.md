# Guards

Register and evaluate guards used in transitions.

::: pystator.guards.GuardRegistry

::: pystator.guards.GuardResult

Transition-level evaluation (`can_transition`, `async_can_transition`, …) lives on **`GuardRegistry`** (formerly a separate ``GuardEvaluator``).

Built-in guard helpers:

::: pystator.guards.equals
::: pystator.guards.greater_than
::: pystator.guards.in_list
::: pystator.guards.all_of
::: pystator.guards.any_of
::: pystator.guards.negate
