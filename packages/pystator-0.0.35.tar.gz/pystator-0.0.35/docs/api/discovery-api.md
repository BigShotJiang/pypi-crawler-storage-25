# Discovery (Python API)

**Discovery** covers inferred FSM candidates, observation ingestion, shadow diffs, and pluggable stores. Conceptual guide: [Discovery (inferred FSM)](../guides/discovery-inference.md) and [Classification](../guides/classification.md).

Below are the main **service and store** entrypoints; protocols and data models are available in the `pystator.discovery` package.

## Engine and thresholds

::: pystator.discovery.service.InferenceEngine

::: pystator.discovery.service.InferenceThresholds

## Store factory

::: pystator.discovery.stores.create_discovery_store

## Classification

::: pystator.discovery.classification.StateClassifier

::: pystator.discovery.classification.DataIngester

## Key models (selected)

::: pystator.discovery.models.ObservedStateEvent

::: pystator.discovery.models.BuiltDiscoveryCandidate

::: pystator.discovery.models.InferredEdge

## Imports

```python
from pystator.discovery import (
    InferenceEngine,
    InferenceThresholds,
    create_discovery_store,
    StateClassifier,
    DataIngester,
    ObservedStateEvent,
    BuiltDiscoveryCandidate,
)
```

Additional exports (`DiscoveryDraft`, `ShadowDiff`, `PostgresDiscoveryStore`, `ClassificationResult`, …) are listed in `pystator.discovery.__all__`.
