# Declarative checks, effects, and tooling

PyStator supports **config-only** guard checks and context mutations (no Python functions), plus **built-in** guard/action packs, **sinks** for observability, and **lint** for static review.

## Declarative checks (`check:`)

Use structured checks in transition **guards** instead of named Python guards. Evaluated by `pystator.checks.evaluate_check`.

Supported operators on a **context field**:

| Operator | Meaning |
|----------|--------|
| `eq`, `neq` | Equality / inequality |
| `gt`, `gte`, `lt`, `lte` | Numeric / comparable ordering |
| `in`, `not_in` | Membership in a list |
| `is_set`, `is_null` | Field present / absent |

Example in YAML (illustrative):

```yaml
transitions:
  - trigger: submit
    source: draft
    dest: submitted
    guards:
      - check:
          field: amount
          op: gt
          value: 0
```

Combine with named guards as needed. See the [FSM config reference](../reference/fsm-config.md) for the full `CheckSpec` shape.

## Declarative effects (`set`, `timestamp`, …)

**Effects** mutate **context** during transitions (action-side counterpart to checks). Applied via `pystator.effects.apply_effect`:

| Effect | Role |
|--------|------|
| `set` | `ctx.update(...)` from params |
| `timestamp` | Set a field to current UTC ISO time |
| `increment` / `decrement` | Numeric field |
| `append` | Append to a list field |
| `clear` | Remove a key from context |

In YAML these often appear as `on_enter` / transition entries using the declarative action form (e.g. `{ set: { phase: running } }` or `{ timestamp: started_at }`). See [Context and sinks](context.md) and the FSM reference for your schema version.

## Inline guard expressions (`expr`)

For arithmetic / boolean expressions over context, use **`expr: "fill_qty >= order_qty"`** in YAML. Requires:

```bash
pip install pystator[api]
```

(`simpleeval` evaluates expressions; keep configs trusted.)

## Inline code actions (`code:`)

FSM YAML may include a **`code:`** action with a **`source`** string executed via `exec` when the worker (or any path using `ActionExecutor`) runs actions. Two independent flags in **`pystator.cfg` `[features]`** or environment (env wins), same resolution as other feature keys:

| Flag | Effect |
|------|--------|
| **`PYSTATOR_ALLOW_INLINE_CODE_ACTIONS`** | If off, `code:` never runs. If on, execution is allowed. |
| **`PYSTATOR_ALLOW_INLINE_CODE_IMPORTS`** | If off (default), only **`ctx`** is available and **`__builtins__`** is empty. If **on** (and the base flag is on), a **restricted** builtin set, **allowlisted** `import` roots (`json`, `requests`, `numpy`, `math`, `re`, `datetime`, …), and pre-bound **`json`** / **`requests`** / **`numpy`** / **`np`** (if installed) are provided; **`yaml`** is exposed as **`yaml.safe_load`** / **`yaml.safe_dump`** only (no unsafe `yaml.load`). |

This is **not** a security sandbox: enabling imports allows network I/O (`requests`) and heavy libraries in the **same process** as the worker. Use only with **trusted** machine configs. Optional packages (`requests`, `numpy`, `pyyaml`) must be installed in that environment.

**Indentation:** Before execution, the server applies **`textwrap.dedent()`** to the `source` string so uniformly indented snippets (e.g. pasted from inside a function) are valid at module scope. Mixed indentation (some lines flush-left and later lines indented without a surrounding `def`/`if`/…) can still raise **`IndentationError`**; keep top-level statements aligned or wrap nested logic in a small function and call it from the top level.

## Builtins

Python implementations live in **`pystator.builtins`** (`_BUILTIN_GUARDS` / `_BUILTIN_ACTIONS`). Call **`register_builtins()`** or **`builtin_registries()`** to attach them by name (`always`, `never`, `key_present`, `noop`, `log`, `trace`, …). Metadata for docs and tooling is available from **`pystator.catalog.get_builtin_catalog()`**.

**`publish`** and **`emit_metric`** are not plain module attributes: `register_builtins()` wires them via **`pystator.sinks`** (`configure_event_sink` / `configure_metric_sink`).

For the **distributed catalog**, **`registry.yaml` is interchange only** (like pasting or importing FSM YAML): there is **no** env var that points a worker at a registry file on disk (unlike optional **`PYSTATOR_WORKER_MACHINE_DIR`** for YAML-only machines). The **`registry_catalog` table** is what workers load at startup. Populate it via API **`GET` / `POST /api/v1/registry/catalog/export`** and **`import`**, the Registry UI, migrations, or seeds. The repository includes **`pystator/data/seed/registry_catalog.yaml`** listing built-ins with `pystator.builtins:…` paths; run **`pystator db seed`** or import that file via the API or Registry UI.

## Sinks (events and metrics)

`pystator.sinks` defines **event** and **metric** sinks (e.g. `LoggingEventSink`, `LoggingMetricSink`, `configure_event_sink`, `create_publish_action`) so actions can emit structured telemetry without ad-hoc `print` calls.

## Lint

Static analysis over FSM config:

```python
from pystator.lint import lint, LintWarning

warnings: list[LintWarning] = lint(config_dict)
```

See [Linting](linting.md) for severity levels and CI usage.

## Programmatic machine building

For code-first construction, use **`StateMachineBuilder`** (`from pystator import StateMachineBuilder`) to add states and transitions fluently before calling `.build()`.

---

**See also:** [Concepts](concepts.md) · [Package structure](package-structure.md) · [FSM config reference](../reference/fsm-config.md)
