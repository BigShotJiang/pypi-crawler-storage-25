# Tutorial: REST API and Web UI

Run the PyStator API server and (optionally) the web UI to validate configs, run process, and manage machines.

## Overview

You will:

1. Install the API extra and start the server.
2. Call the health and validate endpoints.
3. Call the process endpoint to compute a transition.
4. (Optional) Build and serve the UI, and use it to point at the API.

## Prerequisites

- Python 3.11+
- `pip install pystator[api]`

For the UI: Node.js and npm, and a built UI (see Step 4).

## Step 1: Start the API server

```bash
pystator api
```

Or with uvicorn:

```bash
uvicorn pystator.api.main:app --reload --port 8004
```

Default URL: **http://localhost:8004** (same default port as `pystator api`). OpenAPI docs: **http://localhost:8004/docs**.

## Step 2: Health and validate

**Health:**

```bash
curl http://localhost:8004/health
```

Expect something like: `{"status":"healthy","version":"0.0.1"}`.

**Validate a config:**

```bash
curl -X POST http://localhost:8004/api/v1/validate \
  -H "Content-Type: application/json" \
  -d '{
    "config": {
      "meta": {"version": "1.0.0", "machine_name": "test", "strict_mode": true},
      "states": [
        {"name": "A", "type": "initial"},
        {"name": "B", "type": "stable"},
        {"name": "C", "type": "terminal"}
      ],
      "transitions": [
        {"trigger": "go", "source": "A", "dest": "B"},
        {"trigger": "done", "source": "B", "dest": "C"}
      ]
    }
  }'
```

A valid config returns 200 and validation result; invalid returns 422 with error details.

## Step 3: Process an event (stateless)

**`POST /api/v1/process`** computes the next state for one trigger. The JSON body includes the full **`config`**, **`current_state`**, **`trigger`**, and optional **`context`**.

```bash
curl -X POST http://localhost:8004/api/v1/process \
  -H "Content-Type: application/json" \
  -d '{
    "config": {
      "meta": {"version": "1.0.0", "machine_name": "test", "strict_mode": true},
      "states": [
        {"name": "A", "type": "initial"},
        {"name": "B", "type": "stable"},
        {"name": "C", "type": "terminal"}
      ],
      "transitions": [
        {"trigger": "go", "source": "A", "dest": "B"},
        {"trigger": "done", "source": "B", "dest": "C"}
      ]
    },
    "current_state": "A",
    "trigger": "go",
    "context": {}
  }'
```

The response includes `success`, `source_state`, `target_state`, **`actions_to_execute`**, **`on_exit_actions`**, **`on_enter_actions`**, and structured **`error`** when the transition fails. The API **does not** run those actions (no `code:` execution, no HTTP actions, no registry calls). That is intentional: same semantics as `StateMachine.process()` in Python.

**Entity event (server runs actions):** To persist state in the database and **execute** transition actions (including declarative **`code:`** when enabled in config), use **`POST /api/v1/entities/{entity_id}/events`** with a **`trigger`** and optional **`context`**. The HTTP request blocks until processing finishes; the response may include **`action_results`**.

If auth is enabled, include `Authorization: Bearer <token>` (obtain token via `POST /api/v1/auth/login`).

## Step 4: (Optional) Web UI

The UI is a Next.js app that can be built and served separately, or served by a small Python server that proxies to the API.

**From source (development):**

```bash
cd src/pystator/ui
npm install
npm run build
# From project root:
pystator ui serve
```

Then open the URL shown (e.g. http://127.0.0.1:3004). In Settings you can set the API base URL (default: http://localhost:8004). Use the UI to:

- **Workspace** — Edit FSM config (structured sidebar + optional raw YAML/JSON), diagram view, palette, and **Test** panel. The Test panel calls **`POST /api/v1/process`** against the in-browser config: it does **not** run inline **`code:`** actions (only lists what would run). Transition **`code:`** snippets are edited with a **Monaco** (Python) editor for better editing UX; raw config text still uses a plain textarea.
- Validate FSM configs (standalone and from workspace)
- **Entities** — Drive **`POST /api/v1/entities/.../events`** so the server runs guards, persistence, and actions
- (If the API has machine storage) List and manage stored machines, timelines, dry-run, bulk operations — see OpenAPI **`/docs`**

**Auth:** If the API has auth enabled, the UI will show a login page and use Bearer tokens for requests. When the API is unreachable, an “API server not connected” banner appears; you can still navigate and adjust Settings.

## What you learned

- The API exposes `/health`, `/api/v1/validate`, and **`/api/v1/process`** for quick validation and **stateless** transition computation (no server-side action execution).
- **`/api/v1/entities/{id}/events`** is the path that **runs** actions and persists entity state (when the API is backed by a database).
- Optional auth: login via `/api/v1/auth/login`, then send Bearer token on protected routes.
- The UI talks to the API using the base URL you configure; workspace **Test** uses **`/process`**; **Entities** uses the entity event API.

## Next steps

- [REST API](../api/rest-api.md) — Process vs entities, dry-run, bulk, worker
- [Configuration](../guides/configuration.md) — Auth and database for the API
- [Concepts](../guides/concepts.md) — States, transitions, guards, actions
- [Declarative features](../guides/declarative-features.md) — `code:`, `check:`, effects
- [Order workflow tutorial](order-workflow.md) — Build the FSM in code first
