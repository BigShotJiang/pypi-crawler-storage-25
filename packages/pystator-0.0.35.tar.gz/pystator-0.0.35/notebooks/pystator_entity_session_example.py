import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator: EntitySession Example (Guards and Actions)

    This notebook uses **EntitySession**: state lives **in memory** in one Python object. We define a minimal FSM with **guards** and **actions**, create a stateful session with `machine.create()`, and drive it with `session.send()`. Actions are run explicitly via `ActionExecutor` after each transition. Everything is self-contained; no external config files.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Define the FSM config

    We use a simple order-like flow: **pending** → **confirmed** → **shipped**. The transition `pending` → `confirmed` requires guard `can_confirm` and runs action `notify` on success. **state_variables** declare the context contract (optional; enables documentation and optional validation via `meta.validate_context`).
    """)
    return


@app.cell
def _():
    FSM_CONFIG = {
        "meta": {
            "machine_name": "order_demo",
            "version": "1.0.0",
            "strict_mode": True,
        },
        "state_variables": [
            {"key": "order_id", "type": "string", "required": True},
            {"key": "valid", "type": "boolean", "default": False},
        ],
        "states": [
            {"name": "pending", "type": "initial"},
            {"name": "confirmed", "type": "stable"},
            {"name": "shipped", "type": "terminal"},
        ],
        "transitions": [
            {
                "trigger": "confirm",
                "source": "pending",
                "dest": "confirmed",
                "guards": ["can_confirm"],
                "actions": ["notify"],
            },
            {
                "trigger": "ship",
                "source": "confirmed",
                "dest": "shipped",
                "actions": ["notify"],
            },
        ],
    }

    print("Config defined.")
    return (FSM_CONFIG,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. Load the machine and register guard + action

    - **Guard** `can_confirm`: transition is allowed only when context has `valid=True`.
    - **Action** `notify`: appends a message to a list so we can see it ran (in a real app this might send email or update a DB).
    """)
    return


@app.cell
def _(FSM_CONFIG):
    from pystator import ActionExecutor, StateMachine

    # Side-effect log (instead of sending email / DB)
    notifications = []

    machine = StateMachine.from_dict(FSM_CONFIG)

    @machine.guard("can_confirm")
    def can_confirm(ctx):
        """Only allow confirm when context has valid=True."""
        return ctx.get("valid", False) is True

    @machine.action("notify")
    def notify(ctx):
        """Side effect": append a message (e.g. could send email)."""
        msg = f"State changed to {ctx.get('new_status', '?')} for order {ctx.get('order_id', 'unknown')}"
        notifications.append(msg)
        print(f"  [action] {msg}")

    print("Machine loaded; guard and action registered.")
    return ActionExecutor, machine, notifications


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Use EntitySession and run the flow

    We create a stateful **EntitySession** for one order, send events, and run **actions** explicitly (PyStator returns which actions to run; you execute them with `ActionExecutor` so you can persist state first in a real app).
    """)
    return


@app.cell
def _(ActionExecutor, machine, notifications):
    notifications.clear()

    order = machine.create(context={"order_id": "order-42", "valid": False})
    executor = ActionExecutor(machine.action_registry, log_execution=False)

    print("Initial state:", order.current_state)
    print()

    # Try confirm without valid=True -> guard blocks
    result = order.send("confirm")
    print("send(confirm) without valid=True:", result.success)  # False
    print("State still:", order.current_state)
    print()

    # Confirm with valid=True -> guard passes
    result = order.send("confirm", valid=True)
    print("send(confirm, valid=True):", result.success)  # True
    if result.success and result.all_action_specs:
        executor.execute(result, {**order.context, "new_status": result.target_state})
    print("State now:", order.current_state)
    print()

    # Ship
    result = order.send("ship")
    print("send(ship):", result.success)
    if result.success and result.all_action_specs:
        executor.execute(result, {**order.context, "new_status": result.target_state})
    print("State now:", order.current_state)
    print("is_final:", order.is_final)
    print()
    print("Notifications recorded:", notifications)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. Summary

    - **FSM config** (dict) defines states and transitions; **guards** and **actions** are referenced by name.
    - **Guards** are evaluated when you send an event; they allow or block the transition (here, `can_confirm` requires `valid=True` in context).
    - **Actions** are returned in the transition result; you run them with `ActionExecutor.execute(result, context)` after persisting state if needed.
    - **EntitySession** holds state in memory; use `machine.create(context=...)` and `order.send(trigger, **payload)`. For store-backed, ID-based state, see **pystator_orchestrator_example.py**.
    """)
    return


if __name__ == "__main__":
    app.run()
