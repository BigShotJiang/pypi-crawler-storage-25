import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator Discovery Demo

    **Discovery** lets you infer a state machine from observed data.
    Instead of hand-writing states and transitions, you feed real
    event data and PyStator figures out the structure for you.

    **What this notebook covers:**

    1. Record observations (entity moved to state X at time T)
    2. Preview inferred edges (consecutive state pairs → weighted transitions)
    3. Build a candidate FSM the one-shot way
    4. Build a candidate the **draft workflow** way (iterative, scoped, preferred)
    5. Export as a Mermaid diagram
    6. Use the discovered machine to process real events
    7. **Shadow compare** the candidate against an existing active machine
    8. **Fleet summary** — cross-machine aggregates
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Create mock order data

    Imagine an e-commerce system where orders flow through states.
    We'll generate observations for 20 orders with realistic patterns.
    """)
    return


@app.cell
def _():
    import random
    from datetime import UTC, datetime, timedelta

    random.seed(42)

    # Possible order flows (weighted by likelihood)
    FLOWS = [
        ["created", "confirmed", "shipped", "delivered"],  # happy path (60%)
        ["created", "confirmed", "shipped", "returned"],  # return (15%)
        ["created", "cancelled"],  # early cancel (15%)
        ["created", "confirmed", "cancelled"],  # late cancel (10%)
    ]
    WEIGHTS = [60, 15, 15, 10]

    def generate_order_events(num_orders: int = 10):
        """Generate mock order lifecycle events."""
        events = []
        base_time = datetime(2026, 1, 1, tzinfo=UTC)

        for i in range(num_orders):
            order_id = f"order-{i + 1:03d}"
            flow = random.choices(FLOWS, weights=WEIGHTS, k=1)[0]
            t = base_time + timedelta(hours=i * 2)

            for state in flow:
                events.append(
                    {
                        "order_id": order_id,
                        "state": state,
                        "timestamp": t.isoformat(),
                        "source": "mock",
                    }
                )
                t += timedelta(minutes=random.randint(10, 120))

        return events

    mock_events = generate_order_events(20)
    print(f"Generated {len(mock_events)} events for 20 orders")
    mock_events[:5]

    dt = datetime  # export alias: downstream cell can't use param name `datetime`
    return dt, mock_events


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. Create the discovery engine

    One line: `InferenceEngine.from_app_config()` resolves the backend
    and URL the same way the API server, CLI, and worker do (env vars,
    `pystator.cfg`, or the default `sqlite:///pystator.db`) so the
    notebook, CLI, and UI all see the same data automatically.

    Thresholds are set to minimum values here so every inferred edge
    shows up in the demo — tune up `min_edge_count` / `min_confidence`
    for real data.
    """)
    return


@app.cell
def _():
    from pystator.discovery import (
        InferenceEngine,
        InferenceThresholds,
        ObservedStateEvent,
    )

    engine = InferenceEngine.from_app_config(
        thresholds=InferenceThresholds(min_edge_count=1, min_confidence=0.0),
    )
    return ObservedStateEvent, engine


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Ingest the mock data

    Convert raw dicts into `ObservedStateEvent` objects and
    batch-record them into the engine with `record_observations()`.
    """)
    return


@app.cell
def _(ObservedStateEvent, dt, engine, mock_events):
    observations = [
        ObservedStateEvent(
            entity_id=evt["order_id"],
            machine_name="order_lifecycle",
            state=evt["state"],
            observed_at=dt.fromisoformat(evt["timestamp"]),
            source=evt["source"],
        )
        for evt in mock_events
    ]

    accepted = engine.record_observations("order_lifecycle", observations)
    entity_ids = engine._observations.list_entity_ids("order_lifecycle")  # noqa: SLF001
    print(f"Accepted {accepted} / {len(observations)} observations")
    print(f"Distinct entities: {len(entity_ids)}")
    return (entity_ids,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. Preview inferred edges

    `preview_inference()` returns both the raw edges and the filtered
    `selected_edges` (those passing the current thresholds), along
    with the set of entities seen.
    """)
    return


@app.cell
def _(engine, mo):
    preview = engine.preview_inference("order_lifecycle")

    rows = [
        {
            "From": edge.source_state,
            "To": edge.destination_state,
            "Count": edge.count,
            "Entities": edge.unique_entities,
            "Confidence": f"{edge.confidence:.0%}",
        }
        for edge in preview["edges"]
    ]

    mo.vstack(
        [
            mo.md(
                f"**Observations:** {preview['observation_count']}  "
                f"**Entities:** {len(preview['entity_ids_used'])}  "
                f"**Edges:** {len(preview['edges'])}  "
                f"**Selected:** {len(preview['selected_edges'])}"
            ),
            mo.ui.table(rows, label="Inferred Edges"),
        ]
    )
    return (preview,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 5. Build a candidate (one-shot)

    `build_candidate()` compiles the inferred edges into a valid FSM
    config with normalized state names and auto-generated triggers,
    then persists it.
    """)
    return


@app.cell
def _(engine, preview):
    _ = preview
    candidate = engine.build_candidate("order_lifecycle")

    print(f"Candidate version:  {candidate.version}")
    print(f"Candidate sequence: {candidate.candidate_sequence}")
    print(f"Status:             {candidate.status}")
    print(f"States:             {[s['name'] for s in candidate.config['states']]}")
    print(f"Transitions:        {len(candidate.config['transitions'])}")
    print(f"Edges in metadata:  {candidate.metadata['edge_count']}")
    return (candidate,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 6. Build a candidate via the **draft workflow** (preferred)

    For interactive exploration, the draft workflow lets you:

    - Scope to a subset of entities (`selected_entity_ids`)
    - Tune thresholds per-draft
    - Preview before committing
    - Build when ready — the draft is updated with the built version

    This is the workflow the UI uses and is the recommended way to
    go from raw observations to a production-ready candidate.
    """)
    return


@app.cell
def _(engine, entity_ids):
    # 1. Create a draft scoped to the happy-path orders only.
    happy_path_entities = entity_ids[:10]
    draft = engine.create_draft("order_lifecycle", title="Happy path subset")

    # 2. Update the draft with our scope + thresholds.
    draft = engine.update_draft(
        draft.id,
        selected_entity_ids=happy_path_entities,
        mode="inference",
        min_edge_count=1,
        min_confidence=0.0,
    )

    # 3. Preview without committing — iterate freely.
    draft_preview = engine.preview_draft(draft.id)
    print(f"Draft id:            {draft.id}")
    print(f"Scoped entities:     {len(draft_preview['entity_ids_used'])}")
    print(f"Scoped observations: {draft_preview['observation_count']}")
    print(f"Inferred edges:      {len(draft_preview['edges'])}")

    # 4. Build the candidate from the draft when ready.
    draft_candidate = engine.build_from_draft(draft.id)
    print(f"\nBuilt from draft:    {draft_candidate.version}")
    print(f"Candidate sequence:  {draft_candidate.candidate_sequence}")
    print(
        f"Linked draft_id:     {draft_candidate.metadata.get('draft_id') == draft.id}"
    )
    return (draft_candidate,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 7. Export as a Mermaid diagram

    `export_candidate_diagram()` accepts `format="mermaid"` or `"dot"`.
    """)
    return


@app.cell
def _(candidate, engine, mo):
    _ = candidate  # depend on build
    diagram = engine.export_candidate_diagram("order_lifecycle", format="mermaid")
    mo.mermaid(diagram)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 8. Use the discovered machine

    The candidate config is a standard PyStator config dict.
    Load it with `StateMachine.from_dict()` and process transitions.
    """)
    return


@app.cell
def _(candidate):
    from pystator import StateMachine

    machine = StateMachine.from_dict(candidate.config)

    # Triggers are auto-generated as `to_<destination>`.
    for src, trigger in [
        ("created", "to_confirmed"),
        ("confirmed", "to_shipped"),
        ("shipped", "to_delivered"),
    ]:
        result = machine.process(src, trigger, {})
        ok = "OK" if result.success else "FAIL"
        print(f"[{ok}] {src} + {trigger} → {result.target_state}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 9. Shadow compare vs. an active machine

    `run_shadow_compare()` runs the same `(state, trigger)` through both
    an existing active machine and the latest candidate, then records a
    `ShadowDiff` whenever they disagree. This is how you safely validate
    a discovered machine against one already in production.
    """)
    return


@app.cell
def _(candidate, engine):
    _ = candidate  # depend on build

    # Simulate an "active" machine that ONLY allows created → confirmed → shipped
    # (missing the delivered/returned/cancelled branches).
    active_config = {
        "meta": {"machine_name": "order_lifecycle", "version": "legacy-1.0"},
        "states": [
            {"name": "created", "type": "initial"},
            {"name": "confirmed", "type": "stable"},
            {"name": "shipped", "type": "terminal"},
        ],
        "transitions": [
            {"trigger": "to_confirmed", "source": "created", "dest": "confirmed"},
            {"trigger": "to_shipped", "source": "confirmed", "dest": "shipped"},
        ],
    }

    shadow_scenarios = [
        ("created", "to_confirmed"),  # both agree
        ("shipped", "to_delivered"),  # active rejects, candidate accepts
        ("confirmed", "to_cancelled"),  # active rejects, candidate accepts
    ]
    for src, trig in shadow_scenarios:
        engine.run_shadow_compare(
            machine_name="order_lifecycle",
            active_config=active_config,
            source_state=src,
            trigger=trig,
        )

    diffs = engine.list_shadow_diffs("order_lifecycle", limit=10)
    print(f"Recorded {len(diffs)} shadow diffs.\n")
    for d in diffs:
        verdict = "DIFFERS" if d.differs else "agrees "
        print(
            f"[{verdict}] {d.source_state} + {d.trigger}:"
            f" active→{d.active_target_state} vs candidate→{d.candidate_target_state}"
            f"  reason={d.reason or '—'}"
        )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 10. Fleet summary

    The store's `list_fleet_summaries()` gives a cross-machine overview:
    observation counts, candidate counts, and drift rate from shadow diffs.
    The Discovery UI uses the same data to render its fleet index page.
    """)
    return


@app.cell
def _(engine, mo):
    store = engine._observations  # noqa: SLF001 — single combined store
    summaries = (
        store.list_fleet_summaries() if hasattr(store, "list_fleet_summaries") else []
    )

    summary_rows = [
        {
            "Machine": r["machine_name"],
            "Observations": r["observation_count"],
            "Candidates": r["candidate_count"],
            "Latest version": r.get("latest_candidate_version") or "—",
            "Shadow diffs (recent)": r["shadow_diff_count_recent"],
            "Drift rate": f"{r['drift_rate_recent']:.0%}",
        }
        for r in summaries
    ]
    mo.ui.table(summary_rows, label="Fleet summary")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 11. Query stored candidates

    Once persisted, candidates are queryable through the engine.
    """)
    return


@app.cell
def _(draft_candidate, engine):
    _ = draft_candidate  # depend on both builds
    latest = engine.get_latest_built_candidate("order_lifecycle")
    all_candidates = engine.list_built_candidates("order_lifecycle")

    print(f"Latest candidate:  {latest.version} (seq={latest.candidate_sequence})")
    print(f"All candidates:    {len(all_candidates)}")
    for c in all_candidates:
        tag = " ← latest" if c.version == latest.version else ""
        print(f"  • {c.version} (seq={c.candidate_sequence}) {c.status}{tag}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---

    ## View in the UI

    `from_app_config()` points at the same SQLite file (`./pystator.db`
    by default) that the API server, CLI, and worker use, so everything
    this notebook wrote is already visible to the rest of the stack:

    1. **API:** `pystator api` — serves the same database, no env needed.
    2. **UI:** `pystator ui dev` — Discovery page lists `order_lifecycle`
       in the fleet index with the counts shown above.
    3. **CLI:** `pystator discovery list order_lifecycle` — same data, same
       backend.

    **Summary:** 20 mock orders → discovered state machine (one-shot and
    draft workflows) → mermaid diagram → replayable in `StateMachine` →
    shadow-compared against a legacy machine → fleet summary. Everything
    is persisted through the canonical `from_app_config()` factory so the
    notebook, CLI, API, and UI all share state automatically.
    """)
    return


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
