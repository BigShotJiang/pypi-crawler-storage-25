# PyStator notebooks

Interactive demos are **[Marimo](https://marimo.io/)** notebooks (plain Python) in this **flat** `notebooks/` directory—no subfolders.

```bash
pip install -e ".[dev]"
marimo edit notebooks/pystator_simple_demo.py
```

## Catalog

| Topic | File |
|-------|------|
| Minimal FSM intro | `pystator_simple_demo.py` |
| Mock context | `pystator_mock_context_demo.py` |
| Entity session | `pystator_entity_session_example.py` |
| Orchestrator + SQLite | `pystator_orchestrator_example.py` |
| Worker YAML demo | `pystator_worker_example.py` |
| When / routing | `pystator_when_routing_demo.py` |
| Triggerless apply-data | `pystator_triggerless_apply_data_example.py` |
| Auto transitions | `pystator_auto_transitions_example.py` |
| Worker load test | `pystator_worker_load_test.py` |
| AIDX bulk v1.2.0 | `aidx_flight_lifecycle_bulk_entities.py` |
| AIDX bulk v1.0.0 | `aidx_flight_lifecycle_v1_0_0_bulk_entities.py` |

Supporting YAML for some demos: `mock_when_state_variables.yaml`, `notebook_worker_demo.yaml`.

## Editing

Edit the `.py` files directly, or use Marimo's editor (`marimo edit …`). If `marimo convert` puts `from __future__ import annotations` inside a cell, ruff will flag **F404** — move that import to the **first line** of the file (before `import marimo`) and delete it from the cell.
