import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator: Auto (Eventless) Transitions Example

    This notebook demonstrates **auto transitions**: transitions that fire **on state entry** when their guards pass, without you sending a trigger. After a normal transition lands in a state, the engine evaluates all auto transitions from that state; the first whose guards pass is taken (and can chain further).

    **No continuous process needed** — everything runs inside the same `send()` or `process_event()` call. No worker or daemon required.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Define the FSM config

    Flow: **start** → (trigger `submit`) → **checking** → then **automatically** to **approved** or **rejected** based on context (e.g. `score`). The transitions from `checking` have **`auto: true`** and no trigger; they are evaluated as soon as we enter `checking`.
    """)
    return


@app.cell
def _():
    FSM_CONFIG = {
        "meta": {
            "machine_name": "auto_transition_demo",
            "version": "1.0.0",
            "strict_mode": False,
        },
        "states": [
            {"name": "start", "type": "initial"},
            {"name": "checking", "type": "stable"},
            {"name": "approved", "type": "stable"},
            {"name": "rejected", "type": "terminal"},
        ],
        "transitions": [
            {"trigger": "submit", "source": "start", "dest": "checking"},
            {
                "source": "checking",
                "dest": "approved",
                "auto": True,
                "guards": ["is_approved"],
            },
            {
                "source": "checking",
                "dest": "rejected",
                "auto": True,
                "guards": ["is_rejected"],
            },
        ],
    }

    print("Config defined.")
    return (FSM_CONFIG,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. Load the machine and register guards

    Guards **is_approved** and **is_rejected** read `score` from context. Auto transitions are evaluated in config order; the first guard that passes wins.
    """)
    return


@app.cell
def _(FSM_CONFIG):
    from pystator import StateMachine

    machine = StateMachine.from_dict(FSM_CONFIG)

    @machine.guard("is_approved")
    def is_approved(ctx):
        return ctx.get("score", 0) >= 80

    @machine.guard("is_rejected")
    def is_rejected(ctx):
        return ctx.get("score", 0) < 80

    print("Machine loaded; guards registered.")
    return (machine,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Run the flow: one `send()` does the whole path

    We send **submit** with a **score** in context. The machine moves to `checking`, then the engine immediately evaluates auto transitions: with **score=90** the guard **is_approved** passes, so we end in **approved** — all in one call. With **score=50**, **is_rejected** passes and we end in **rejected**.
    """)
    return


@app.cell
def _(machine):
    session_high = machine.create(context={"score": 90})
    print("Before send:", session_high.current_state)  # start

    result = session_high.send("submit")
    print("After send('submit') with score=90:", session_high.current_state)  # approved
    print("Success:", result.success)
    print()

    session_low = machine.create(context={"score": 50})
    result2 = session_low.send("submit")
    print("After send('submit') with score=50:", session_low.current_state)  # rejected
    print("Success:", result2.success)
    print()
    print("No second send() needed — auto transitions ran inside the same call.")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. Summary

    - **Auto transitions** use **`auto: true`** in the config and have **no trigger**. They are evaluated **when the machine enters** their source state.
    - The first auto transition whose **guards** pass is taken; the engine can **chain** multiple auto steps (until no more fire or a terminal state is reached).
    - All of this runs **synchronously** inside `send()` or `process_event()`. You do **not** need pystator running as a continuous service for auto transitions to work.
    - Compare with **pystator_entity_session_example.py** (explicit triggers only) and **pystator_orchestrator_example.py** (store-backed state).
    """)
    return


if __name__ == "__main__":
    app.run()
