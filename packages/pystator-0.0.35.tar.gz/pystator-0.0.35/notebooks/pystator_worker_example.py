from __future__ import annotations

import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator Worker Example — Three-Layer Machine Management

    This notebook demonstrates the **three-layer** pattern for managing FSM machines in PyStator:

    | Layer | Module | Role |
    |-------|--------|------|
    | **Parse** | `pystator.machine_parser` | Read YAML/JSON into a `MachineDefinition` |
    | **Store** | `pystator.machine_store` | Persist definitions via `SQLAlchemyMachineStore` |
    | **Run** | `pystator.worker` / `pystator.api.services` | Create entities, submit events, process transitions |

    We parse `notebook_worker_demo.yaml` (in this `notebooks/` directory), store it in the database,
    create an entity, and submit a worker event — all through the public API of each layer.

    **Database:** unless `PYSTATOR_DATABASE_URL` is set, SQLite uses **`pystator.db` at the PyStator repo root** (next to `src/` and `notebooks/`), not a cwd-relative file under `notebooks/`.
    """)
    return


@app.cell
def _():
    import os
    import uuid
    from pathlib import Path

    import pystator
    from pystator.db.cli import cmd_upgrade
    from pystator.db.config import get_db_url

    def _notebooks_asset(filename: str) -> Path:
        cwd = Path.cwd()
        for base in (
            cwd,
            cwd / "notebooks",
            Path(pystator.__file__).resolve().parent.parent.parent / "notebooks",
        ):
            p = base / filename
            if p.is_file():
                return p
        raise FileNotFoundError(filename)

    MACHINE_YAML = _notebooks_asset("notebook_worker_demo.yaml")

    # Repo-root pystator.db (…/pystator/pystator.db), not cwd-relative notebooks/pystator.db.
    _pkg_init = Path(pystator.__file__).resolve()
    PYSTATOR_PROJECT_ROOT = (
        _pkg_init.parent.parent.parent
    )  # src/pystator -> src -> repo root
    ROOT_DB = (PYSTATOR_PROJECT_ROOT / "pystator.db").resolve()

    if os.environ.get("PYSTATOR_DATABASE_URL"):
        DATABASE_URL = get_db_url(os.environ.get("PYSTATOR_DATABASE_URL"))
    else:
        DATABASE_URL = f"sqlite:///{ROOT_DB}"

    os.environ["PYSTATOR_DATABASE_URL"] = DATABASE_URL

    MACHINE_NAME = "notebook_worker_demo"
    ENTITY_ID = f"nb-worker-{uuid.uuid4().hex[:10]}"

    rc = cmd_upgrade(DATABASE_URL)
    assert rc == 0, f"db upgrade failed with exit code {rc}"

    print("PYSTATOR_PROJECT_ROOT:", PYSTATOR_PROJECT_ROOT)
    print("DATABASE_URL:", DATABASE_URL)
    print("MACHINE_YAML:", MACHINE_YAML)
    print("ENTITY_ID:  ", ENTITY_ID)
    return DATABASE_URL, ENTITY_ID, MACHINE_NAME, MACHINE_YAML


@app.cell
def _(MACHINE_YAML):
    from pystator.machine_parser import parse_machine_file

    definition = parse_machine_file(MACHINE_YAML)

    print("name:       ", definition.name)
    print("version:    ", definition.version)
    print("states:     ", [s["name"] for s in definition.states])
    print(
        "transitions:",
        [(t["trigger"], t["source"], t["dest"]) for t in definition.transitions],
    )
    return (definition,)


@app.cell
def _(DATABASE_URL, definition):
    from pystator.machine_store import SQLAlchemyMachineStore

    store = SQLAlchemyMachineStore(DATABASE_URL)
    store.connect()

    machine_id = store.save(definition)
    print("Saved machine, id:", machine_id)
    return (store,)


@app.cell
def _(store):
    machines = store.list()
    for m in machines:
        print(
            f"  {m.name} v{m.version}  ({len(m.states)} states, {len(m.transitions)} transitions)"
        )

    store.disconnect()
    return


@app.cell
async def _(DATABASE_URL, ENTITY_ID, MACHINE_NAME):
    from pystator.api.services.entity_service import (
        create_entity_at_initial,
        load_machine_config,
    )
    from pystator.db.base import get_session
    from pystator.worker import submit_event

    _session = get_session(DATABASE_URL)
    try:
        _cfg = load_machine_config(_session, MACHINE_NAME)
        create_entity_at_initial(
            _session,
            entity_id=ENTITY_ID,
            machine_name=MACHINE_NAME,
            machine_config=_cfg,
        )
        _session.commit()
        print("Created entity", ENTITY_ID, "at initial state")
    finally:
        _session.close()
    event_id = await submit_event(MACHINE_NAME, ENTITY_ID, "go", db_url=DATABASE_URL)
    print("Submitted worker event:", event_id)
    return (
        create_entity_at_initial,
        get_session,
        load_machine_config,
        submit_event,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Run the worker

    In a separate terminal, start the worker with the **same** database URL:

    ```bash
    PYSTATOR_DATABASE_URL="<paste DATABASE_URL from cell above>" pystator worker
    ```

    The worker loads machine definitions from the database by default and processes
    the queued event. Stop it with **Ctrl+C** when done, then run the next cell.
    """)
    return


@app.cell
def _(DATABASE_URL, ENTITY_ID, get_session):
    from pystator.db.models import EntityStateModel

    _session = get_session(DATABASE_URL)
    try:
        row = (
            _session.query(EntityStateModel)
            .filter(EntityStateModel.entity_id == ENTITY_ID)
            .first()
        )
        if row is None:
            print("No entity row found — did you run the cells above?")
        else:
            print("entity_id:    ", row.entity_id)
            print("machine_name: ", row.machine_name)
            print("current_state:", row.current_state)
    finally:
        _session.close()
    return


@app.cell
def _(
    DATABASE_URL,
    MACHINE_NAME,
    create_entity_at_initial,
    get_session,
    load_machine_config,
):
    _session = get_session(DATABASE_URL)
    try:
        _cfg = load_machine_config(_session, MACHINE_NAME)
        create_entity_at_initial(
            _session,
            entity_id="entity-1",
            machine_name=MACHINE_NAME,
            machine_config=_cfg,
        )
        _session.commit()
    finally:
        _session.close()
    return


@app.cell
async def _(DATABASE_URL, MACHINE_NAME, submit_event):
    event_id_1 = await submit_event(MACHINE_NAME, "entity-1", "go", db_url=DATABASE_URL)
    return (event_id_1,)


@app.cell
def _(event_id_1):
    return (event_id_1,)


if __name__ == "__main__":
    app.run()
