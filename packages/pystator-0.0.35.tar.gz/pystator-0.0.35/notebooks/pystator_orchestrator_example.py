import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator: Orchestrator Example (Guards and Actions)

    This notebook uses the **Orchestrator**: state lives in a **StateStore** (here, **SQLite**) and entities are identified by **entity_id**. We call `orchestrator.process_event(entity_id, trigger, context)`; the orchestrator loads state, runs the transition, persists the new state, and **runs actions automatically**. Same FSM as the EntitySession example; compare with **pystator_entity_session_example.py**.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Define the FSM config

    Same order-like flow: **pending** → **confirmed** → **shipped**, with guard `can_confirm` and action `notify`. **state_variables** declare the context contract (optional; enables documentation and optional validation via `meta.validate_context`).
    """)
    return


@app.cell
def _():
    FSM_CONFIG = {
        "meta": {
            "machine_name": "order_demo",
            "version": "1.0.0",
            "strict_mode": True,
        },
        "state_variables": [
            {"key": "order_id", "type": "string", "required": True},
            {"key": "valid", "type": "boolean", "default": False},
        ],
        "states": [
            {"name": "pending", "type": "initial"},
            {"name": "confirmed", "type": "stable"},
            {"name": "shipped", "type": "terminal"},
        ],
        "transitions": [
            {
                "trigger": "confirm",
                "source": "pending",
                "dest": "confirmed",
                "guards": ["can_confirm"],
                "actions": ["notify"],
            },
            {
                "trigger": "ship",
                "source": "confirmed",
                "dest": "shipped",
                "actions": ["notify"],
            },
        ],
    }

    print("Config defined.")
    return (FSM_CONFIG,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. Load machine, register guard and action, create store and Orchestrator

    We use **SQLiteStateStore** with a SQLite file (`pystator_orchestrator_demo.db` in the current directory). Tables are created automatically with `connect(auto_initialize=True)`. The Orchestrator runs the full loop: load state from store → process event → persist new state → **execute actions**.
    """)
    return


@app.cell
def _(FSM_CONFIG):
    from pystator import Orchestrator, StateMachine
    from pystator.stores import SQLiteStateStore

    notifications = []

    machine = StateMachine.from_dict(FSM_CONFIG)

    @machine.guard("can_confirm")
    def can_confirm(ctx):
        return ctx.get("valid", False) is True

    @machine.action("notify")
    def notify(ctx):
        msg = f"State changed to {ctx.get('new_status', '?')} for order {ctx.get('order_id', 'unknown')}"
        notifications.append(msg)
        print(f"  [action] {msg}")

    # SQLite store: file created in current directory; tables created automatically
    store = SQLiteStateStore("sqlite:///pystator_orchestrator_demo.db")
    store.connect(auto_initialize=True)
    orchestrator = Orchestrator(machine, store, use_initial_state_when_missing=True)

    print("Machine, SQLite store, and Orchestrator ready.")
    return machine, notifications, orchestrator, store


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Process events by entity_id

    We call `orchestrator.process_event(entity_id, trigger, context)`. For a new entity the store has no state, so the orchestrator uses the machine's initial state. **Actions run automatically** after a successful transition; no need to call ActionExecutor.
    """)
    return


@app.cell
def _(machine, notifications, orchestrator, store):
    ENTITY_ID = "order-42"
    notifications.clear()

    # New entity: no state in store yet -> orchestrator uses initial state
    current = store.get_state(ENTITY_ID)
    print(
        "State in store (new entity):", current
    )  # None until first successful transition
    print()

    # Try confirm without valid=True -> guard blocks
    result = orchestrator.process_event(
        ENTITY_ID, "confirm", context={"order_id": ENTITY_ID, "valid": False}
    )
    print("process_event(confirm, valid=False):", result.success)  # False
    print(
        "State in store:", store.get_state(ENTITY_ID)
    )  # None (no transition succeeded yet)
    print()

    # Confirm with valid=True -> guard passes; state persisted; action runs
    result = orchestrator.process_event(
        ENTITY_ID, "confirm", context={"order_id": ENTITY_ID, "valid": True}
    )
    print("process_event(confirm, valid=True):", result.success)  # True
    print("State in store:", store.get_state(ENTITY_ID))  # confirmed
    print()

    # Ship
    result = orchestrator.process_event(
        ENTITY_ID, "ship", context={"order_id": ENTITY_ID}
    )
    print("process_event(ship):", result.success)
    print("State in store:", store.get_state(ENTITY_ID))  # shipped
    print("Terminal?", store.get_state(ENTITY_ID) in machine.terminal_states)
    print()
    print("Notifications recorded:", notifications)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. Summary

    - **Orchestrator** uses a **StateStore** (here, SQLite); state is keyed by **entity_id**. No in-memory session object.
    - Call **process_event(entity_id, trigger, context)**; the orchestrator loads state (or uses initial for new entities), runs the transition, persists the new state, and **executes actions**.
    - Use when you need durable, ID-based state shared across requests or processes (e.g. API + Worker). For in-memory, one-object-per-entity flow, see **pystator_entity_session_example.py**.
    - The demo creates `pystator_orchestrator_demo.db` in the current directory; you can delete it when done, or call `store.disconnect()` to close the connection.
    """)
    return


if __name__ == "__main__":
    app.run()
