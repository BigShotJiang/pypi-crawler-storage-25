import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # AIDX flight lifecycle **v1.0.0** — bulk entities (REST API)

    Same demo as the **v1.2.0** notebook, but targets machine **`aidx_flight_lifecycle` `1.0.0`** (`aidx_flight_lifecycle_v1_0_0.yaml`): **no** `state_variables` and **no** transition guards, so events work with **empty context**.

    **Pairing:** use [`aidx_flight_lifecycle_bulk_entities.py`](aidx_flight_lifecycle_bulk_entities.py) for **v1.2.0** (latest), which requires feed-shaped **context** on each event.

    **Before you run:** API is up; `pystator db seed` has loaded **`aidx_flight_lifecycle_v1_0_0.yaml`**.

    **Environment (optional):** `PYSTATOR_API_URL`, `PYSTATOR_API_TOKEN`, `AIDX_DEMO_PREFIX`.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Helpers — HTTP + bulk API

    Standard library only (`urllib`, `json`).
    """)
    return


@app.cell
def _():
    import json
    import os
    import time
    import urllib.error
    import urllib.parse
    import urllib.request

    API_BASE = os.environ.get("PYSTATOR_API_URL", "http://127.0.0.1:8004").rstrip("/")
    MACHINE = "aidx_flight_lifecycle"
    VERSION = "1.0.0"
    TOKEN = os.environ.get("PYSTATOR_API_TOKEN", "").strip()
    RUN_PREFIX = os.environ.get("AIDX_DEMO_PREFIX", f"aidx-{int(time.time())}")

    def _headers() -> dict[str, str]:
        h = {"Accept": "application/json"}
        if TOKEN:
            h["Authorization"] = f"Bearer {TOKEN}"
        return h

    def api_json(method: str, path: str, body: dict | None = None) -> dict:
        url = f"{API_BASE}/api/v1{path}"
        payload = json.dumps(body).encode() if body is not None else None
        headers = _headers()
        if body is not None:
            headers["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=payload, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            raise RuntimeError(
                f"HTTP {e.code} {path}: {e.read().decode(errors='replace')}"
            ) from None

    def bulk_create(items: list[dict]) -> dict:
        return api_json("POST", "/entities/bulk/create", {"items": items})

    def bulk_fire(
        entity_ids: list[str], trigger: str, context: dict | None = None
    ) -> dict:
        return api_json(
            "POST",
            "/entities/bulk/events",
            {"entity_ids": entity_ids, "trigger": trigger, "context": context or {}},
        )

    def get_state(entity_id: str) -> dict:
        q = urllib.parse.quote(entity_id, safe="")
        return api_json("GET", f"/entities/{q}/state")

    def assert_bulk_ok(step: str, result: dict) -> None:
        if result.get("failed"):
            bad = [r for r in result["results"] if not r["success"]]
            raise RuntimeError(f"{step}: {bad[:3]}")

    print(f"API: {API_BASE}  |  machine {MACHINE}@{VERSION}  |  run id: {RUN_PREFIX}")
    return (
        MACHINE,
        RUN_PREFIX,
        VERSION,
        assert_bulk_ok,
        bulk_create,
        bulk_fire,
        get_state,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## One run — create, then transitions

    v1.0.0 has no guards: **`context` stays empty** for every bulk event.
    """)
    return


@app.cell
def _(
    MACHINE,
    RUN_PREFIX,
    VERSION,
    assert_bulk_ok,
    bulk_create,
    bulk_fire,
    get_state,
):
    from collections import Counter

    n, half = 100, 50
    ids = [f"{RUN_PREFIX}-fl-{i:03d}" for i in range(n)]
    to_complete = ids[:half]
    to_cancel = ids[half:]

    created = bulk_create(
        [
            {
                "entity_id": eid,
                "machine_name": MACHINE,
                "machine_version": VERSION,
                "context": {"i": i, "leg_id": eid},
            }
            for i, eid in enumerate(ids)
        ]
    )
    assert_bulk_ok("create", created)
    print(f"Created {created['succeeded']} entities.")

    steps = [
        "initiate",
        "start_boarding",
        "final_boarding_call",
        "close_gate",
        "ready_for_start",
        "off_block",
        "takeoff",
        "begin_approach",
        "land",
        "arrive_on_block",
        "close_flight",
        "complete",
    ]
    for t in steps:
        r = bulk_fire(to_complete, t)
        assert_bulk_ok(t, r)
    print(f"Full lifecycle: {len(to_complete)} entities → completed.")

    a, b, c = to_cancel[:17], to_cancel[17:34], to_cancel[34:]
    assert_bulk_ok("cancel A", bulk_fire(a, "cancel"))
    assert_bulk_ok("initiate B", bulk_fire(b, "initiate"))
    assert_bulk_ok("cancel B", bulk_fire(b, "cancel"))
    assert_bulk_ok("initiate C", bulk_fire(c, "initiate"))
    assert_bulk_ok("boarding C", bulk_fire(c, "start_boarding"))
    assert_bulk_ok("cancel C", bulk_fire(c, "cancel"))
    print(f"Cancel paths: {len(to_cancel)} entities → canceled.")

    done = [get_state(eid) for eid in to_complete]
    rest = [get_state(eid) for eid in to_cancel]
    assert all(s["current_state"] == "completed" for s in done)
    assert all(s["current_state"] == "canceled" for s in rest)

    print()
    print("Summary")
    print("  Completed:", sum(1 for s in done if s["current_state"] == "completed"))
    print("  Canceled: ", dict(Counter(s["current_state"] for s in rest)))
    print("Done (v1.0.0).")
    return


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
