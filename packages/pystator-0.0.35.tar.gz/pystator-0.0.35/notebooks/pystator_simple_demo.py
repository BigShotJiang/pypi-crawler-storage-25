import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator Simple Demo

    A short demonstration of **PyStator**: configuration-driven finite state machines.

    - Define states and transitions in YAML or a dict
    - Call `machine.process(current_state, trigger, context)` for pure transition logic
    - Optionally add **guards** (conditions) and **actions** (side effects)

    Install: `pip install pystator` (or `pip install -e .[dev]` from repo root for Marimo).
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. Load a state machine
    """)
    return


@app.cell
def _():
    from pystator import StateMachine

    # From an inline config (no file needed)
    config = {
        "meta": {"machine_name": "order", "version": "1.0.0", "strict_mode": True},
        "states": [
            {"name": "PENDING", "type": "initial"},
            {"name": "OPEN", "type": "stable"},
            {"name": "FILLED", "type": "terminal"},
        ],
        "transitions": [
            {"trigger": "exchange_ack", "source": "PENDING", "dest": "OPEN"},
            {"trigger": "fill", "source": "OPEN", "dest": "FILLED"},
        ],
    }

    machine = StateMachine.from_dict(config)
    print(f"Machine: {machine.name} v{machine.version}")
    print(f"States: {machine.state_names}")
    print(f"Initial: {machine.get_initial_state().name}")
    return StateMachine, machine


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. Process events (stateless)
    """)
    return


@app.cell
def _(machine):
    # Pure computation: (current_state, trigger, context) -> result
    _result = machine.process("PENDING", "exchange_ack", {})
    print(f"Success: {_result.success}")
    print(f"Transition: {_result.source_state} -> {_result.target_state}")
    result2 = machine.process(_result.target_state, "fill", {})
    print(f"Then: {result2.source_state} -> {result2.target_state}")
    # Next event from the new state
    print(f"Terminal: {result2.target_state in machine.terminal_states}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Optional: guards and actions
    """)
    return


@app.cell
def _(StateMachine):
    from pystator import ActionExecutor, ActionRegistry, GuardRegistry

    config_with_guard = {
        "meta": {"machine_name": "order", "version": "1.0.0", "strict_mode": True},
        "states": [
            {"name": "PENDING", "type": "initial"},
            {"name": "OPEN", "type": "stable"},
            {"name": "FILLED", "type": "terminal"},
        ],
        "transitions": [
            {"trigger": "exchange_ack", "source": "PENDING", "dest": "OPEN"},
            {
                "trigger": "fill",
                "source": "OPEN",
                "dest": "FILLED",
                "guards": ["is_full_fill"],
                "actions": ["log_fill"],
            },
        ],
    }
    machine2 = StateMachine.from_dict(config_with_guard)
    guards = GuardRegistry()
    guards.register(
        "is_full_fill", lambda ctx: ctx.get("fill_qty", 0) >= ctx.get("order_qty", 1)
    )
    machine2.bind_guards(guards)
    actions = ActionRegistry()
    actions.register(
        "log_fill", lambda ctx: print(f"  Action: filled qty={ctx.get('fill_qty')}")
    )
    executor = ActionExecutor(actions)
    ctx = {"order_qty": 100, "fill_qty": 100}
    _result = machine2.process("OPEN", "fill", ctx)
    print(f"Transition: {_result.source_state} -> {_result.target_state}")
    if _result.all_actions:
        executor.execute(_result, ctx)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. Load from YAML file
    """)
    return


@app.cell
def _():
    # If you have a YAML file (e.g. examples/order_fsm.yaml):
    # machine = StateMachine.from_yaml("examples/order_fsm.yaml")
    # result = machine.process("PENDING_NEW", "exchange_ack", {})

    print("Use StateMachine.from_yaml('path/to/fsm.yaml') when you have a file.")
    print("See examples/ in the repo for full order_fsm.yaml with guards and actions.")
    return


if __name__ == "__main__":
    app.run()
