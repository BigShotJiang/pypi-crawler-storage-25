from __future__ import annotations

import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # When-route auto-routing demo

    This notebook demonstrates **when-route auto-routing** -- a feature where the engine automatically transitions an entity based on destination states' `when` clauses, **without an explicit trigger**.

    The machine config sets `classification.auto_route: true`, and each target state declares `when:` conditions. Transitions declare valid paths but carry **no guards** -- the destination's `when` clauses act as implicit guards.

    The notebook shows three APIs:

    1. **`StateClassifier.classify()`** -- evaluates `when` in state order (classification only, no side effects).
    2. **`session.apply_data(risk_score=85)`** -- updates context and auto-routes to the matching state. No trigger needed.
    3. **`session.send("finalize", ...)`** -- traditional trigger-driven transition (explicit guards still work alongside when-routes).

    No database, worker, or `simpleeval`. Uses `mock_when_state_variables.yaml` in this `notebooks/` directory.
    """)
    return


@app.cell
def _():
    from pathlib import Path

    import pystator
    from pystator import StateMachine
    from pystator.discovery.classification import StateClassifier

    def _notebooks_asset(filename: str) -> Path:
        cwd = Path.cwd()
        for base in (
            cwd,
            cwd / "notebooks",
            Path(pystator.__file__).resolve().parent.parent.parent / "notebooks",
        ):
            p = base / filename
            if p.is_file():
                return p
        raise FileNotFoundError(filename)

    MACHINE_YAML = _notebooks_asset("mock_when_state_variables.yaml")

    machine = StateMachine.from_yaml(MACHINE_YAML)
    classifier = StateClassifier.from_machine(machine)
    print("Loaded:", machine.name, machine.version)
    print("Classifier default (no match):", classifier.rule_set.default_state)
    return classifier, machine


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1 — Classifier: which state does each mock record satisfy?

    States with `when:` are tested **in YAML order**; the first state where **all** `when` items pass wins. `intaking` has no `when`, so it is not considered here.
    """)
    return


@app.cell
def _(classifier):
    MOCK_RECORDS = [
        {"label": "high", "payload": {"risk_score": 88}},
        {"label": "mid", "payload": {"risk_score": 55}},
        {"label": "low", "payload": {"risk_score": 12}},
        {"label": "edge_70", "payload": {"risk_score": 70}},
        {"label": "edge_40", "payload": {"risk_score": 40}},
        {"label": "no_score", "payload": {}},
    ]
    print(f"{'label':<12} {'classified_state':<18} matched")
    print("-" * 42)
    for _row in MOCK_RECORDS:
        result = classifier.classify(_row["payload"])
        print(f"{_row['label']:<12} {result.state:<18} {result.matched!s}")
    return (MOCK_RECORDS,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2 — When-route: `apply_data()` from `intaking`

    Each row calls `apply_data(**payload)`. The engine evaluates destination states' `when` clauses against the merged context and auto-routes to the matching state. No trigger needed.
    """)
    return


@app.cell
def _(MOCK_RECORDS, machine):
    print(f"{'label':<12} {'after apply_data':<20} {'routed'}")
    print("-" * 44)
    for _row in MOCK_RECORDS:
        if _row["label"] == "no_score":
            continue  # no when clause matches with missing fields
        label = _row["label"]
        session = machine.create(entity_id=f"demo-{label}")
        results = session.apply_data(**_row["payload"])
        routed = bool(results)
        print(f"{label:<12} {session.current_state:<20} {routed}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3 — `finalize` from `review_required` using `reviewer_ok`
    """)
    return


@app.cell
def _(machine):
    def run_finalize(*, reviewer_ok: bool) -> None:
        session = machine.create(entity_id=f"demo-fin-{reviewer_ok}")
        session.apply_data(risk_score=50)  # auto-routes intaking -> review_required
        assert session.current_state == "review_required"
        session.send("finalize", reviewer_ok=reviewer_ok)  # explicit trigger
        print(f"reviewer_ok={reviewer_ok!s:5} -> {session.current_state!r}")

    run_finalize(reviewer_ok=True)
    run_finalize(reviewer_ok=False)
    return


if __name__ == "__main__":
    app.run()
