import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator: Triggerless Data-Driven Transitions (when-route)

    This notebook demonstrates **triggerless** state transitions driven only by **data (context/state variables)**.

    Instead of calling `process_event(entity_id, trigger, context)`, we call:

    - `orchestrator.apply_data(entity_id, data)`

    That method:
    - loads the current state + persisted context from the store
    - merges in `data`
    - evaluates the **post-transition chain** (**auto-transitions + when-routes**)
    - persists any resulting state changes

    ## Important note about the worker
    The current `pystator worker` processes queued `worker_events` by calling `orchestrator.process_event(...)` (trigger-based). It **does not** currently enqueue/handle an `apply_data`-style event, so this notebook demonstrates triggerless routing via direct `Orchestrator.apply_data` calls.
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 1. FSM config: states + when clauses

    Key idea: **when-route** is opt-in.

    - Enable it with `meta.classification.auto_route: true`
    - Put `when: [...]` checks on **destination** states.

    In this demo, we route based on a single field: `status`.
    """)
    return


@app.cell
def _():
    FSM_CONFIG = {
        "meta": {
            "machine_name": "triggerless_order_demo",
            "version": "1.0.0",
            "strict_mode": True,
            "classification": {"auto_route": True},
        },
        "state_variables": [
            {"key": "order_id", "type": "string", "required": True},
            {"key": "status", "type": "string", "required": False},
        ],
        "states": [
            {"name": "pending", "type": "initial"},
            {
                "name": "confirmed",
                "type": "stable",
                "when": [{"field": "status", "op": "eq", "value": "confirmed"}],
            },
            {
                "name": "shipped",
                "type": "terminal",
                "when": [{"field": "status", "op": "eq", "value": "shipped"}],
            },
        ],
        "transitions": [
            # These triggers are never invoked directly in this notebook.
            # When-route evaluation will "choose" among these transitions based on the
            # destination states' `when` clauses.
            {"trigger": "_route", "source": "pending", "dest": "confirmed"},
            {"trigger": "_route", "source": "confirmed", "dest": "shipped"},
        ],
    }

    print("Config defined:", FSM_CONFIG["meta"]["machine_name"])
    return (FSM_CONFIG,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. Create a machine + SQLite store + Orchestrator

    We use a SQLite-backed store so the current state and context are durable and can be shared across processes.

    This notebook creates a local SQLite DB file in the current directory.
    """)
    return


@app.cell
def _(FSM_CONFIG):
    from pystator import Orchestrator, StateMachine
    from pystator.stores import SQLiteStateStore

    machine = StateMachine.from_dict(FSM_CONFIG)

    store = SQLiteStateStore("sqlite:///pystator_triggerless_apply_data_demo.db")
    store.connect(auto_initialize=True)

    orchestrator = Orchestrator(
        machine=machine,
        state_store=store,
        use_initial_state_when_missing=True,
    )

    print("Ready:", machine.name, "@", machine.version)
    print("DB:", store.connection_string)
    return (
        Orchestrator,
        SQLiteStateStore,
        StateMachine,
        machine,
        orchestrator,
        store,
    )


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 3. Triggerless progression: only send data

    We never call `process_event(..., trigger=...)`.

    We only call `orchestrator.apply_data(entity_id, data)` and watch the FSM advance when the `when` conditions become true.
    """)
    return


@app.cell
def _(machine, orchestrator, store):
    def show(entity_id: str, label: str) -> None:
        print(f"\n--- {label} ---")
        print("state:", store.get_state(entity_id))
        try:
            ctx = store.get_context(entity_id)
        except Exception:
            ctx = {}
        print("context:", ctx)

    def show_results(results):
        if not _results:
            print("(no transitions fired)")
            return
        for r in _results:
            print(
                "fired:",
                {
                    "source": r.source_state,
                    "target": r.target_state,
                    "trigger": r.trigger,
                    "success": r.success,
                },
            )

    ENTITY_ID = "order-100"
    show(ENTITY_ID, "initial (new entity)")
    _results = orchestrator.apply_data(
        ENTITY_ID, {"order_id": ENTITY_ID, "status": "pending"}
    )
    show_results(_results)
    show(ENTITY_ID, "after status=pending")
    _results = orchestrator.apply_data(ENTITY_ID, {"status": "confirmed"})
    show_results(_results)
    show(ENTITY_ID, "after status=confirmed")
    _results = orchestrator.apply_data(ENTITY_ID, {"status": "shipped"})
    show_results(_results)
    show(ENTITY_ID, "after status=shipped")
    # 3a) Send data that does NOT satisfy any destination state's `when`.
    #     Expected: no transition.
    # 3b) Update only the status. Expected: pending -> confirmed
    # 3c) Update status again. Expected: confirmed -> shipped
    print("\nterminal?", store.get_state(ENTITY_ID) in machine.terminal_states)
    return (show_results,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 4. Edge case: ambiguous `when` matches

    If multiple destination states' `when` clauses match at the same time, the engine must pick *one*. In practice you should design `when` checks to be **mutually exclusive** (or use priorities).

    Below we create a tiny machine where *two* possible destinations both match `flag=True`.
    """)
    return


@app.cell
def _(Orchestrator, SQLiteStateStore, StateMachine, show_results):
    AMBIG_CONFIG = {
        "meta": {
            "machine_name": "triggerless_ambiguous_demo",
            "version": "1.0.0",
            "strict_mode": True,
            "classification": {"auto_route": True},
        },
        "states": [
            {"name": "start", "type": "initial"},
            {
                "name": "path_a",
                "type": "stable",
                "when": [{"field": "flag", "op": "eq", "value": True}],
            },
            {
                "name": "path_b",
                "type": "stable",
                "when": [{"field": "flag", "op": "eq", "value": True}],
            },
        ],
        "transitions": [
            {"trigger": "_route", "source": "start", "dest": "path_a"},
            {"trigger": "_route", "source": "start", "dest": "path_b"},
        ],
    }
    amb_machine = StateMachine.from_dict(AMBIG_CONFIG)
    amb_store = SQLiteStateStore(
        "sqlite:///pystator_triggerless_apply_data_ambiguous_demo.db"
    )
    amb_store.connect(auto_initialize=True)
    amb_orch = Orchestrator(amb_machine, amb_store, use_initial_state_when_missing=True)
    entity_id = "amb-1"
    print("before:", amb_store.get_state(entity_id))
    _results = amb_orch.apply_data(entity_id, {"flag": True})
    show_results(_results)
    print("after:", amb_store.get_state(entity_id))
    print(
        "\nTip: make when-clauses mutually exclusive, or use transition priority to disambiguate."
    )  # Two candidates from the same source. Both destinations match.  # Which one fires depends on ordering/priority rules.
    return (amb_store,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 5. Worker note

    If you already have a `pystator worker` running, it will happily process **trigger-based** events (`submit_event(..., trigger=...)`).

    However, the worker currently executes this call shape:

    - `orchestrator.process_event(entity_id, event=trigger, context=payload)`

    It does **not** have an event type that maps to:

    - `orchestrator.apply_data(entity_id, data)`

    So to drive triggerless transitions *through the worker*, you’d need to extend the worker event model/processor to support a “data update” event kind (or a dedicated trigger that only runs auto+when-route evaluation).

    For now, `Orchestrator.apply_data` is the canonical path for “I can only send data”.

    ## Cleanup
    If you want to remove DB files created by this notebook:
    - `pystator_triggerless_apply_data_demo.db`
    - `pystator_triggerless_apply_data_ambiguous_demo.db`

    And you can close connections by calling:
    - `store.disconnect()`
    - `amb_store.disconnect()`
    """)
    return


@app.cell
def _(amb_store, store):
    store.disconnect()
    amb_store.disconnect()
    print("Disconnected.")
    return


if __name__ == "__main__":
    app.run()
