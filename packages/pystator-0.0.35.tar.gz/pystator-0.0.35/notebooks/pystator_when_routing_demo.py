import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyStator: Data-Driven When-Route Transitions

    This notebook demonstrates **triggerless, data-driven state transitions** using pystator's **when-routing** feature.

    **Core idea:** Instead of sending explicit trigger events, you push *data* (state variable values) into the state machine. The engine evaluates declarative `when` clauses on destination states and automatically routes the entity to the correct state.

    ### What you'll see

    1. **Basic when-routing** — numeric range checks drive state transitions
    2. **Composable logic** — `all_of`, `any_of`, and `negate` combinators
    3. **EntitySession API** — in-memory `apply_data()` with no trigger
    4. **Orchestrator API** — persistent `apply_data()` with SQLite storage
    5. **Chaining** — when-routes that fire in sequence
    6. **Priorities** — controlling which route wins when multiple match
    7. **Mixing triggers + data** — combining explicit events with when-routes

    ### Supported check operators

    `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `in`, `not_in`, `is_set`, `is_null`, `contains`, `starts_with`, `ends_with`, `matches`
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 1. Basic When-Routing: Loan Application

    A loan application is routed based on `credit_score`:

    | Score range | Destination |
    |---|---|
    | >= 750 | `auto_approved` |
    | 600–749 | `manual_review` |
    | < 600 | `auto_declined` |
    """)
    return


@app.cell
def _():
    from pystator import StateMachine

    LOAN_CONFIG = {
        "meta": {
            "machine_name": "loan_application",
            "version": "1.0.0",
            "classification": {"auto_route": True},  # <-- enables when-routing
        },
        "state_variables": [
            {
                "key": "credit_score",
                "type": "number",
                "description": "Applicant credit score (300-850)",
            },
            {"key": "income", "type": "number", "description": "Annual income in USD"},
        ],
        "states": [
            {"name": "submitted", "type": "initial"},
            {
                "name": "auto_approved",
                "type": "terminal",
                "when": [{"field": "credit_score", "op": "gte", "value": 750}],
            },
            {
                "name": "manual_review",
                "type": "stable",
                "when": [
                    {
                        "all_of": [
                            {"field": "credit_score", "op": "gte", "value": 600},
                            {"field": "credit_score", "op": "lt", "value": 750},
                        ]
                    }
                ],
            },
            {
                "name": "auto_declined",
                "type": "terminal",
                "when": [{"field": "credit_score", "op": "lt", "value": 600}],
            },
        ],
        "transitions": [
            # These define the valid paths. The engine picks the right one
            # based on which destination's `when` clause matches.
            {"trigger": "_route", "source": "submitted", "dest": "auto_approved"},
            {"trigger": "_route", "source": "submitted", "dest": "manual_review"},
            {"trigger": "_route", "source": "submitted", "dest": "auto_declined"},
        ],
    }

    loan_machine = StateMachine.from_dict(LOAN_CONFIG)
    print(f"Machine: {loan_machine.name} v{loan_machine.version}")
    print(f"States: {loan_machine.state_names}")
    print(f"State variables: {loan_machine.get_state_variables()}")
    return StateMachine, loan_machine


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## 2. EntitySession: In-Memory `apply_data()`

    The simplest way to use when-routing. No database, no orchestrator — just push data and watch the state change.
    """)
    return


@app.cell
def _(loan_machine):
    # High credit score -> auto_approved
    app1 = loan_machine.create(entity_id="loan-001")
    print(f"Before: state={app1.current_state}")
    _results = app1.apply_data(credit_score=800)
    print(f"After:  state={app1.current_state}")
    print(f"Transition: {_results[0].source_state} -> {_results[0].target_state}")
    print()
    return


@app.cell
def _(loan_machine):
    # Mid-range score -> manual_review
    app2 = loan_machine.create(entity_id="loan-002")
    _results = app2.apply_data(credit_score=680)
    print(f"loan-002: {app2.current_state}  (credit_score=680)")
    app3 = loan_machine.create(entity_id="loan-003")
    # Low score -> auto_declined
    _results = app3.apply_data(credit_score=520)
    print(f"loan-003: {app3.current_state}  (credit_score=520)")
    return


@app.cell
def _(loan_machine):
    # No matching data -> no transition
    app4 = loan_machine.create(entity_id="loan-004")
    _results = app4.apply_data(income=75000)  # income is not checked by any when clause
    print(
        f"loan-004: state={app4.current_state}  (no credit_score provided, no transition)"
    )
    print(f"Transitions fired: {len(_results)}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 3. Composable Logic: `all_of`, `any_of`, `negate`

    When clauses support boolean composition for complex routing rules.
    """)
    return


@app.cell
def _(StateMachine):
    TRIAGE_CONFIG = {
        "meta": {
            "machine_name": "support_triage",
            "version": "1.0.0",
            "classification": {"auto_route": True},
        },
        "states": [
            {"name": "new_ticket", "type": "initial"},
            {
                "name": "escalated",
                "type": "stable",
                "description": "VIP customer OR severity is critical",
                "when": [
                    {
                        "any_of": [
                            {"field": "is_vip", "op": "eq", "value": True},
                            {"field": "severity", "op": "eq", "value": "critical"},
                        ]
                    }
                ],
            },
            {
                "name": "standard_queue",
                "type": "stable",
                "description": "Not VIP AND severity is not critical",
                "when": [
                    {
                        "all_of": [
                            {"negate": {"field": "is_vip", "op": "eq", "value": True}},
                            {
                                "negate": {
                                    "field": "severity",
                                    "op": "eq",
                                    "value": "critical",
                                }
                            },
                        ]
                    }
                ],
            },
        ],
        "transitions": [
            {"trigger": "_route", "source": "new_ticket", "dest": "escalated"},
            {"trigger": "_route", "source": "new_ticket", "dest": "standard_queue"},
        ],
    }

    triage = StateMachine.from_dict(TRIAGE_CONFIG)

    # VIP customer -> escalated
    t1 = triage.create(entity_id="ticket-1")
    t1.apply_data(is_vip=True, severity="low")
    print(f"ticket-1 (VIP, low severity): {t1.current_state}")

    # Critical severity -> escalated (even non-VIP)
    t2 = triage.create(entity_id="ticket-2")
    t2.apply_data(is_vip=False, severity="critical")
    print(f"ticket-2 (non-VIP, critical):  {t2.current_state}")

    # Normal customer, normal severity -> standard_queue
    t3 = triage.create(entity_id="ticket-3")
    t3.apply_data(is_vip=False, severity="medium")
    print(f"ticket-3 (non-VIP, medium):    {t3.current_state}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 4. Orchestrator: Persistent `apply_data()`

    For production use, the Orchestrator loads state from a store, merges data, evaluates when-routes, and persists the result — all in one call.
    """)
    return


@app.cell
def _(loan_machine):
    from pystator import InMemoryStateStore, Orchestrator

    store = InMemoryStateStore()
    orch = Orchestrator(
        machine=loan_machine, state_store=store, use_initial_state_when_missing=True
    )
    _results = orch.apply_data("orch-loan-1", {"credit_score": 710})
    print(f"State: {store.get_state('orch-loan-1')}")
    print(f"Context: {store.get_context('orch-loan-1')}")
    # Entity doesn't exist yet. Orchestrator auto-creates at initial state.
    print(f"Transition: {_results[0].source_state} -> {_results[0].target_state}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 5. Chaining: Multi-Step Auto-Routing

    When-routes can chain: a single `apply_data()` call can fire **multiple transitions in sequence** if each destination's when-clause matches and leads to another routable state.

    Here, a document flows: `draft` -> `reviewed` -> `published` in one data push.
    """)
    return


@app.cell
def _(StateMachine):
    CHAIN_CONFIG = {
        "meta": {
            "machine_name": "doc_pipeline",
            "version": "1.0.0",
            "classification": {"auto_route": True},
        },
        "states": [
            {"name": "draft", "type": "initial"},
            {
                "name": "reviewed",
                "type": "stable",
                "when": [{"field": "review_complete", "op": "eq", "value": True}],
            },
            {
                "name": "published",
                "type": "terminal",
                "when": [
                    {
                        "all_of": [
                            {"field": "review_complete", "op": "eq", "value": True},
                            {"field": "approved", "op": "eq", "value": True},
                        ]
                    }
                ],
            },
        ],
        "transitions": [
            {"trigger": "_route", "source": "draft", "dest": "reviewed"},
            {"trigger": "_route", "source": "reviewed", "dest": "published"},
        ],
    }
    doc_machine = StateMachine.from_dict(CHAIN_CONFIG)
    doc = doc_machine.create(entity_id="doc-1")
    _results = doc.apply_data(review_complete=True, approved=True)
    print(f"Final state: {doc.current_state}")
    print(f"Transitions fired: {len(_results)}")
    for r in _results:
        # Send both fields at once -> chains through reviewed -> published
        print(f"  {r.source_state} -> {r.target_state}")
    return (doc_machine,)


@app.cell
def _(doc_machine):
    # Partial data -> stops at reviewed (approved not yet True)
    doc2 = doc_machine.create(entity_id="doc-2")
    _results = doc2.apply_data(review_complete=True)
    print(f"doc-2 after review_complete=True: {doc2.current_state}")
    _results = doc2.apply_data(approved=True)
    # Now approve -> chains to published
    print(f"doc-2 after approved=True:        {doc2.current_state}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 6. Priorities: Controlling Ambiguous Matches

    If multiple destinations' `when` clauses match simultaneously, use the `priority` field on transitions to control which one wins. **Lower priority number = fires first** (default is 0, so -1 beats 0).
    """)
    return


@app.cell
def _(StateMachine):
    PRIORITY_CONFIG = {
        "meta": {
            "machine_name": "priority_demo",
            "version": "1.0.0",
            "classification": {"auto_route": True},
        },
        "states": [
            {"name": "intake", "type": "initial"},
            {
                "name": "fast_track",
                "type": "stable",
                "when": [{"field": "eligible", "op": "eq", "value": True}],
            },
            {
                "name": "normal_track",
                "type": "stable",
                "when": [{"field": "eligible", "op": "eq", "value": True}],
            },
        ],
        "transitions": [
            # Both destinations match eligible=True.
            # Lower priority number fires first: -1 beats 0.
            {
                "trigger": "_route",
                "source": "intake",
                "dest": "fast_track",
                "priority": -1,
            },
            {
                "trigger": "_route",
                "source": "intake",
                "dest": "normal_track",
                "priority": 0,
            },
        ],
    }

    pri_machine = StateMachine.from_dict(PRIORITY_CONFIG)
    entity = pri_machine.create(entity_id="pri-1")
    entity.apply_data(eligible=True)

    print(f"Both match eligible=True, but priority -1 wins: {entity.current_state}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 7. Mixing Triggers + Data-Driven Routing

    When-routing doesn't have to replace triggers entirely. You can use explicit triggers for some transitions and `apply_data()` for others in the same machine.

    Example: An explicit `submit` trigger moves from `draft` to `scoring`, then data-driven routing takes over.
    """)
    return


@app.cell
def _(StateMachine):
    MIXED_CONFIG = {
        "meta": {
            "machine_name": "mixed_demo",
            "version": "1.0.0",
            "classification": {"auto_route": True},
        },
        "states": [
            {"name": "draft", "type": "initial"},
            {"name": "scoring", "type": "stable"},
            {
                "name": "accepted",
                "type": "terminal",
                "when": [{"field": "score", "op": "gte", "value": 70}],
            },
            {
                "name": "rejected",
                "type": "terminal",
                "when": [{"field": "score", "op": "lt", "value": 70}],
            },
        ],
        "transitions": [
            # Explicit trigger: draft -> scoring
            {"trigger": "submit", "source": "draft", "dest": "scoring"},
            # Data-driven: scoring -> accepted/rejected
            {"trigger": "_route", "source": "scoring", "dest": "accepted"},
            {"trigger": "_route", "source": "scoring", "dest": "rejected"},
        ],
    }

    mixed = StateMachine.from_dict(MIXED_CONFIG)
    session = mixed.create(entity_id="mixed-1")

    # Step 1: explicit trigger
    session.send("submit")
    print(f"After submit trigger: {session.current_state}")

    # Step 2: data-driven routing (no trigger needed)
    session.apply_data(score=85)
    print(f"After score=85 data:  {session.current_state}")
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## 8. Available Check Operators

    Quick reference of all operators you can use in `when` clauses.
    """)
    return


@app.cell
def _():
    from pystator._types import CheckSpec
    from pystator.checks import evaluate_check

    examples = [
        (
            "eq",
            {"field": "status", "op": "eq", "value": "active"},
            {"status": "active"},
        ),
        (
            "neq",
            {"field": "status", "op": "neq", "value": "inactive"},
            {"status": "active"},
        ),
        ("gt", {"field": "age", "op": "gt", "value": 18}, {"age": 25}),
        ("gte", {"field": "score", "op": "gte", "value": 70}, {"score": 70}),
        ("lt", {"field": "risk", "op": "lt", "value": 0.5}, {"risk": 0.3}),
        ("lte", {"field": "count", "op": "lte", "value": 10}, {"count": 10}),
        (
            "in",
            {"field": "tier", "op": "in", "value": ["gold", "plat"]},
            {"tier": "gold"},
        ),
        (
            "not_in",
            {"field": "tier", "op": "not_in", "value": ["free"]},
            {"tier": "gold"},
        ),
        (
            "is_set",
            {"field": "email", "op": "is_set", "value": True},
            {"email": "a@b.com"},
        ),
        ("is_null", {"field": "phone", "op": "is_null", "value": True}, {}),
        (
            "contains",
            {"field": "tags", "op": "contains", "value": "urgent"},
            {"tags": ["urgent", "new"]},
        ),
        (
            "starts_with",
            {"field": "code", "op": "starts_with", "value": "PRE"},
            {"code": "PRE-001"},
        ),
        (
            "ends_with",
            {"field": "file", "op": "ends_with", "value": ".csv"},
            {"file": "data.csv"},
        ),
        (
            "matches",
            {"field": "id", "op": "matches", "value": "^[A-Z]{3}-\\d+$"},
            {"id": "ABC-123"},
        ),
    ]

    print(f"{'Operator':<12} {'Result':<8} Check")
    print("-" * 60)
    for op_name, spec_dict, ctx in examples:
        spec = CheckSpec(**spec_dict)
        result = evaluate_check(spec, ctx)
        print(
            f"{op_name:<12} {str(result):<8} {spec_dict['field']} {spec_dict['op']} {spec_dict.get('value', '')}"
        )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ---
    ## Summary

    | API | Use case |
    |---|---|
    | `session.apply_data(**kwargs)` | In-memory, no persistence |
    | `orchestrator.apply_data(entity_id, data)` | Persistent (loads from store, saves after routing) |
    | `session.send(trigger, **payload)` | Explicit trigger-based transition |

    **Key points:**
    - Enable with `classification.auto_route: true` in machine meta
    - `when` clauses go on **destination states**, not transitions
    - Design `when` clauses to be **mutually exclusive** (or use `priority` to disambiguate)
    - When-routes **chain** automatically (a single `apply_data` can fire multiple transitions)
    - Triggers and data-driven routing **coexist** in the same machine
    - Full async support via `await session.aapply_data()` and `await orchestrator.async_apply_data()`
    """)
    return


if __name__ == "__main__":
    app.run()
