from __future__ import annotations

import marimo

__generated_with = "0.23.0"
app = marimo.App()


@app.cell
def _():
    import marimo as mo

    return (mo,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # Worker load test: many entities

    Run the code cell **while `pystator worker` is running** and using the **same SQLite file** as this notebook.

    **Critical — one database file:** The worker resolves its URL from `PYSTATOR_DATABASE_URL` (env) or `pystator.cfg` `[database]`. If that path differs from the notebook’s `DATABASE_URL`, the notebook will enqueue rows the worker never sees (common symptom: **0/N** entities reach `end`). After changing `pystator.cfg`, **restart the worker**. At startup (INFO logs) it prints: `Worker event queue database: sqlite:///…` — that line must match the notebook’s printed `DATABASE_URL`.

    **Orphaned `claimed` rows:** If a process claims an event and dies before completing it, that entity is blocked until the claim lease expires (default **300s**, `PYSTATOR_WORKER_CLAIM_LEASE_TIMEOUT_S`). For local SQLite you can lower that in `pystator.cfg` while debugging.

    The notebook:

    1. Migrates the DB (`cmd_upgrade`), saves the demo machine from YAML (`parse_machine_file` + `SQLAlchemyMachineStore`).
    2. Creates **`N`** entities at the machine’s initial state (`create_entity_at_initial`).
    3. **Enqueues** `go` events on `worker_events` (`DatabaseEventSource`), so the **worker process** runs the orchestrator — not the notebook kernel.
    4. Polls `entity_states` until all entities reach **`end`** or a timeout (on failure it prints `worker_events` status counts from the notebook DB).

    The code cell uses **`await`** for enqueue (Marimo runs async cells on an event loop).

    **Discovery:** `PYSTATOR_DISCOVERY_DATABASE_URL` is set to the same URL as the main DB.
    """)
    return


@app.cell
async def _():
    import os
    import time
    import uuid
    from pathlib import Path

    from sqlalchemy import text

    import pystator
    from pystator.db.config import get_db_url

    def _notebooks_asset(filename: str) -> Path:
        cwd = Path.cwd()
        for base in (
            cwd,
            cwd / "notebooks",
            Path(pystator.__file__).resolve().parent.parent.parent / "notebooks",
        ):
            p = base / filename
            if p.is_file():
                return p
        raise FileNotFoundError(filename)

    MACHINE_YAML = _notebooks_asset("notebook_worker_demo.yaml")

    _pkg_init = Path(pystator.__file__).resolve()
    PYSTATOR_PROJECT_ROOT = _pkg_init.parent.parent.parent
    ROOT_DB = (PYSTATOR_PROJECT_ROOT / "pystator.db").resolve()

    if os.environ.get("PYSTATOR_DATABASE_URL"):
        DATABASE_URL = get_db_url(os.environ.get("PYSTATOR_DATABASE_URL"))
    else:
        DATABASE_URL = f"sqlite:///{ROOT_DB}"

    os.environ["PYSTATOR_DATABASE_URL"] = DATABASE_URL
    os.environ["PYSTATOR_DISCOVERY_DATABASE_URL"] = DATABASE_URL

    from configparser import ConfigParser

    from pystator.config.paths import find_config_file

    _cfg_path = find_config_file("pystator.cfg")
    _cfg_db = None
    if _cfg_path:
        _cp = ConfigParser()
        _cp.read(_cfg_path)
        if _cp.has_section("database"):
            # ConfigParser lowercases option names (PYSTATOR_DATABASE_URL → pystator_database_url).
            _cfg_db = (
                _cp.get("database", "pystator_database_url", fallback="") or ""
            ).strip() or None

    print("Notebook DATABASE_URL:", DATABASE_URL)
    if _cfg_path:
        print(
            "pystator.cfg database URL (on disk):", _cfg_db or "(not set in [database])"
        )
    if _cfg_db and _cfg_db.rstrip("/") != DATABASE_URL.rstrip("/"):
        print(
            "WARNING: pystator.cfg [database] URL differs from this notebook’s DATABASE_URL.\n"
            "  A worker started without PYSTATOR_DATABASE_URL in its shell uses cfg → a different SQLite file.\n"
            "  Align paths in pystator.cfg, or export the same PYSTATOR_DATABASE_URL in the worker’s shell, then restart the worker."
        )

    N = 100  # change as needed
    MACHINE_NAME = "notebook_worker_demo"
    POLL_INTERVAL_S = 0.2
    TIMEOUT_S = 120.0

    from pystator.db.cli import cmd_upgrade

    assert cmd_upgrade(DATABASE_URL) == 0, "db upgrade failed"

    from pystator.machine_parser import parse_machine_file
    from pystator.machine_store import SQLAlchemyMachineStore

    definition = parse_machine_file(MACHINE_YAML)
    _store = SQLAlchemyMachineStore(DATABASE_URL)
    _store.connect()
    try:
        _store.save(definition)
    finally:
        _store.disconnect()
    print("Machine saved:", definition.name, definition.version)

    from pystator.api.services.entity_service import (
        create_entity_at_initial,
        load_machine_config,
    )
    from pystator.db.base import get_session
    from pystator.db.models import EntityStateModel
    from pystator.worker.event_sources.database import DatabaseEventSource
    from pystator.worker.models import WorkerEvent

    run_id = uuid.uuid4().hex[:8]
    ids = [f"load-{run_id}-{i:04d}" for i in range(N)]

    s = get_session(DATABASE_URL)
    try:
        cfg = load_machine_config(s, MACHINE_NAME)
        for eid in ids:
            create_entity_at_initial(
                s, entity_id=eid, machine_name=MACHINE_NAME, machine_config=cfg
            )
        s.commit()
    finally:
        s.close()

    async def enqueue_go_events() -> None:
        source = DatabaseEventSource(DATABASE_URL)
        try:
            for eid in ids:
                await source.submit(
                    WorkerEvent(
                        machine_name=MACHINE_NAME,
                        entity_id=eid,
                        trigger="go",
                    )
                )
        finally:
            await source.close()

    # Marimo async cells run on an existing loop; asyncio.run() would nest a loop.
    await enqueue_go_events()
    print(f"Enqueued {N} worker events (trigger=go). Waiting for worker to drain…")

    deadline = time.monotonic() + TIMEOUT_S
    ended = 0
    while time.monotonic() < deadline:
        s = get_session(DATABASE_URL)
        try:
            ended = (
                s.query(EntityStateModel)
                .filter(EntityStateModel.entity_id.in_(ids))
                .filter(EntityStateModel.status == "active")
                .filter(EntityStateModel.current_state == "end")
                .count()
            )
        finally:
            s.close()
        if ended == N:
            break
        time.sleep(POLL_INTERVAL_S)
    else:
        try:
            from pystator.db.base import get_engine

            with get_engine(DATABASE_URL).connect() as conn:
                qcounts = list(
                    conn.execute(
                        text(
                            "SELECT status, COUNT(*) FROM worker_events GROUP BY status"
                        )
                    ).all()
                )
        except Exception as exc:
            qcounts = [("query_failed", str(exc))]
        raise TimeoutError(
            f"Only {ended}/{N} entities reached 'end' after {TIMEOUT_S}s.\n"
            f"worker_events counts on this DATABASE_URL: {qcounts}\n"
            "Check worker stderr for: Worker event queue database: … (must match). "
            "Restart `pystator worker` after editing pystator.cfg. "
            "Rows stuck in status=claimed block that entity until claim lease expires."
        )

    print("DATABASE_URL:", DATABASE_URL)
    print(f"Entities: {N}, reached 'end': {ended} (processed by worker)")
    return


if __name__ == "__main__":
    app.run()
