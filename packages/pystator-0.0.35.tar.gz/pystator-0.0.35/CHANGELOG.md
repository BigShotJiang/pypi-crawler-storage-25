# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.0.35] - 2026-04-10

### Added

- Update package
- Update package
- Update package
- Update package
- Update package
- Update notebooks/aidx_flight_lifecycle_bulk_entities.ipynb,src/pystator/data/seed/aidx_flight_lifecycle.yaml
- Update package

### Documentation

- Update documentation
- Update documentation
- Update documentation
- Update documentation
- Update documentation
- Update src/pystator/_bundled_docs/docs/api/rest-api.md

## [0.0.34] - 2026-04-08

### Added

- Update package

### Documentation

- Update src/pystator/_bundled_docs/docs/guides/declarative-features.md
- Update src/pystator/_bundled_docs/docs/guides/declarative-features.md,src/pystator/_bundled_docs/docs/reference/fsm-config.md
- Update documentation
- Update src/pystator/_bundled_docs/docs/reference/fsm-config.md

## [0.0.33] - 2026-04-04

### Documentation

- Update documentation
- Update mkdocs.optophi.yml,src/pystator/_bundled_docs/docs/api/guards.md,src/pystator/_bundled_docs/docs/guides/package-structure.md
- Update documentation

## [0.0.32] - 2026-04-03

### Added

- Update package
- Update package
- Update package

### Documentation

- Update documentation

## [0.0.31] - 2026-04-02

### Added

- Update package
- Update package

## [0.0.30] - 2026-04-02

### Added

- Update src/pystator/data/seed/enhancements_examples.yaml
- Update package
- Update src/pystator/ui/src/components/annotations/StateAnnotationDialog.tsx,src/pystator/ui/src/components/fsm-flow/EdgeWithLabel.tsx
- Update package
- Update src/pystator/ui/src/components/editors/ActionEditor.tsx
- Update package
- Update src/pystator/ui/src/stores/machine-browse.ts
- Update package

### Documentation

- Update src/pystator/_bundled_docs/docs/guides/worker.md

## [0.0.29] - 2026-03-31

### Documentation

- Update docs/guides/configuration.md,src/pystator/ui/dev.py,src/pystator/ui/server.py

## [0.0.28] - 2026-03-30

### Documentation

- Update CONTRIBUTING.md

## [0.0.3] - 2026-02-13

