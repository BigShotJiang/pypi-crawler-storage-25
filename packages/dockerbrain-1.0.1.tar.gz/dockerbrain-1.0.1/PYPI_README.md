# Project Info

[![pipeline](https://github.com/iamPulakesh/DockerBrain/actions/workflows/dockerbrain.yml/badge.svg)](https://github.com/iamPulakesh/DockerBrain/actions/workflows/dockerbrain.yml) [![github project](https://img.shields.io/badge/github-project-blue.svg?logo=github)](https://github.com/iamPulakesh/DockerBrain)

## Core components of DockerBrain

This package contains the command-line based program that allows you to monitor your Docker containers in real time, detect resource issues, and use LLMs to generate actionable optimizations for running containers and Dockerfiles right from your terminal.

## Installation

Complete DockerBrain's setup by installing the package via pip. To install this package, run:

```bash
$ pip install dockerbrain
```

## Contact

For bug reports or feature requests, please open an issue on [GitHub](https://github.com/iamPulakesh/DockerBrain/issues)
