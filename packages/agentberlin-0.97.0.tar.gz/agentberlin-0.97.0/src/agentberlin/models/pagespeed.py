"""Pydantic models for Google PageSpeed Insights responses."""

from typing import List, Optional

from pydantic import BaseModel, Field


class PageSpeedCoreWebVitals(BaseModel):
    """Lighthouse *lab* metrics extracted from a PageSpeed Insights run.

    All fields are optional — None when Lighthouse did not measure the metric
    (partial audit, skipped category).
    """

    largest_contentful_paint_ms: Optional[float] = Field(
        default=None, description="LCP in milliseconds (lab)"
    )
    first_contentful_paint_ms: Optional[float] = Field(
        default=None, description="FCP in milliseconds (lab)"
    )
    cumulative_layout_shift: Optional[float] = Field(
        default=None, description="CLS (unitless, lab)"
    )
    total_blocking_time_ms: Optional[float] = Field(
        default=None, description="TBT in milliseconds (lab)"
    )
    speed_index_ms: Optional[float] = Field(
        default=None, description="Speed Index in milliseconds (lab)"
    )
    time_to_interactive_ms: Optional[float] = Field(
        default=None, description="TTI in milliseconds (lab)"
    )
    server_response_time_ms: Optional[float] = Field(
        default=None, description="Server response time in milliseconds (lab)"
    )


class PageSpeedCruxMetric(BaseModel):
    """A single CrUX (real-user) metric — p75 value + category classification."""

    percentile: float = Field(description="75th-percentile value from real users")
    category: str = Field(description='Google classification: "FAST" | "AVERAGE" | "SLOW"')


class PageSpeedCruxMetrics(BaseModel):
    """Real-user metrics from Chrome User Experience Report (CrUX)."""

    overall_category: Optional[str] = Field(
        default=None,
        description='Aggregate classification across all metrics: "FAST" | "AVERAGE" | "SLOW"',
    )
    largest_contentful_paint_ms: Optional[PageSpeedCruxMetric] = None
    first_contentful_paint_ms: Optional[PageSpeedCruxMetric] = None
    cumulative_layout_shift: Optional[PageSpeedCruxMetric] = None
    interaction_to_next_paint_ms: Optional[PageSpeedCruxMetric] = None
    time_to_first_byte_ms: Optional[PageSpeedCruxMetric] = None


class PageSpeedFieldData(BaseModel):
    """CrUX field data snapshots.

    Returned only when Chrome has enough real-user samples. Low-traffic sites
    will have ``field_data = None`` on the parent response.
    """

    url_metrics: Optional[PageSpeedCruxMetrics] = Field(
        default=None, description="CrUX data for the specific URL"
    )
    origin_metrics: Optional[PageSpeedCruxMetrics] = Field(
        default=None, description="CrUX data aggregated across the origin (all paths)"
    )


class PageSpeedMetricSavings(BaseModel):
    """Estimated savings (in ms) if an opportunity is applied."""

    lcp: float = Field(default=0.0, description="Milliseconds of LCP improvement")
    fcp: float = Field(default=0.0, description="Milliseconds of FCP improvement")


class PageSpeedOffender(BaseModel):
    """A single resource/URL contributing to an opportunity's cost."""

    url: Optional[str] = None
    wasted_bytes: float = Field(default=0.0)
    wasted_ms: float = Field(default=0.0)
    total_bytes: float = Field(default=0.0)


class PageSpeedOpportunity(BaseModel):
    """An actionable Lighthouse audit with estimated LCP/FCP savings."""

    id: str
    title: str
    description: Optional[str] = None
    score: Optional[float] = None
    display_value: Optional[str] = None
    estimated_savings_ms: PageSpeedMetricSavings = Field(
        default_factory=PageSpeedMetricSavings
    )
    offenders: List[PageSpeedOffender] = Field(
        default_factory=list,
        description="Top offending URLs, capped at 10, sorted by wasted bytes desc",
    )


class PageSpeedDiagnostic(BaseModel):
    """A Lighthouse audit flagging an issue without a precise savings number."""

    id: str
    title: str
    description: Optional[str] = None
    score: Optional[float] = None
    display_value: Optional[str] = None
    numeric_value: Optional[float] = None
    numeric_unit: Optional[str] = None


class PageSpeedThirdParty(BaseModel):
    """Per-entity rollup of third-party resource costs."""

    entity: str = Field(description="Third-party entity name, e.g. 'Google Tag Manager'")
    transfer_size_bytes: float
    main_thread_time_ms: float


class PageSpeedAnalyzeResponse(BaseModel):
    """Response from ``client.pagespeed.analyze``.

    High-level summary at the top (``performance_score``, ``core_web_vitals``,
    ``field_data``) with drill-down lists for ``opportunities``, ``diagnostics``,
    and ``third_parties``.
    """

    url: str
    strategy: str  # "mobile" or "desktop"
    analysis_utc_timestamp: Optional[str] = None
    lighthouse_version: Optional[str] = None
    performance_score: Optional[float] = Field(
        default=None,
        description="Overall Lighthouse performance score (0.0–1.0, lab-based)",
    )
    core_web_vitals: PageSpeedCoreWebVitals = Field(
        default_factory=PageSpeedCoreWebVitals,
        description="Lighthouse lab metrics",
    )
    field_data: Optional[PageSpeedFieldData] = Field(
        default=None,
        description="Chrome User Experience Report (CrUX) real-user data. None when site lacks traffic for CrUX coverage.",
    )
    opportunities: List[PageSpeedOpportunity] = Field(
        default_factory=list,
        description="Actionable fixes sorted by estimated LCP savings descending",
    )
    diagnostics: List[PageSpeedDiagnostic] = Field(
        default_factory=list,
        description="Health-check issues without precise savings estimates",
    )
    third_parties: List[PageSpeedThirdParty] = Field(
        default_factory=list,
        description="Per-entity rollup of third-party resource costs",
    )
