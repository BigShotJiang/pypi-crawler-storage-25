"""Pydantic models for Google Search API responses."""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class GoogleSearchSitelink(BaseModel):
    """Sub-link listed under an organic result (inline or expanded)."""

    title: str
    link: str
    snippet: Optional[str] = None


class GoogleSearchResult(BaseModel):
    """Single search result from Google Search."""

    title: str
    url: str
    snippet: str
    displayed_link: Optional[str] = None
    date: Optional[str] = None
    thumbnail: Optional[str] = None
    sitelinks: List[GoogleSearchSitelink] = Field(default_factory=list)


class GoogleSearchMetadata(BaseModel):
    """Metadata about the Google search."""

    id: Optional[str] = None
    status: Optional[str] = None
    total_time_taken: Optional[float] = None


class GoogleSearchAnswerBox(BaseModel):
    """Featured snippet / direct answer shown above organic results."""

    type: Optional[str] = None
    title: Optional[str] = None
    answer: Optional[str] = None
    snippet: Optional[str] = None
    link: Optional[str] = None
    displayed_link: Optional[str] = None
    list: List[str] = Field(default_factory=list)


class GoogleSearchRelatedQuestion(BaseModel):
    """Single entry in the 'People Also Ask' box."""

    question: str
    snippet: Optional[str] = None
    title: Optional[str] = None
    link: Optional[str] = None
    displayed_link: Optional[str] = None


class GoogleSearchKnowledgeGraph(BaseModel):
    """Knowledge panel entity card."""

    title: Optional[str] = None
    type: Optional[str] = None
    description: Optional[str] = None
    source: Optional[str] = None
    website: Optional[str] = None
    image: Optional[str] = None
    attributes: Dict[str, str] = Field(default_factory=dict)


class GoogleSearchLocalResult(BaseModel):
    """Single place in the local pack (3-pack) shown on a web SERP."""

    title: str
    rating: Optional[float] = None
    reviews: Optional[int] = None
    type: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    hours: Optional[str] = None
    website: Optional[str] = None
    place_id: Optional[str] = None
    thumbnail: Optional[str] = None


class GoogleSearchInlineImage(BaseModel):
    """Image tile in the inline images carousel on a web SERP."""

    source: Optional[str] = None
    title: Optional[str] = None
    link: Optional[str] = None
    thumbnail: Optional[str] = None
    original: Optional[str] = None


class GoogleSearchInlineVideo(BaseModel):
    """Video tile in the inline videos carousel on a web SERP."""

    title: str
    link: str
    source: Optional[str] = None
    date: Optional[str] = None
    channel: Optional[str] = None
    duration: Optional[str] = None
    thumbnail: Optional[str] = None


class GoogleSearchTopStory(BaseModel):
    """News tile in the Top Stories carousel on a web SERP."""

    title: str
    link: str
    source: Optional[str] = None
    date: Optional[str] = None
    thumbnail: Optional[str] = None


class GoogleSearchAIOverview(BaseModel):
    """Inline AI Overview block shown on some Google web SERPs."""

    text: Optional[str] = None
    sources: List[GoogleSearchResult] = Field(default_factory=list)


class GoogleSearchRelatedSearch(BaseModel):
    """Single 'Related searches' suggestion."""

    query: str
    link: Optional[str] = None


class GoogleSearchWebResponse(BaseModel):
    """Response for Google web search (organic results + SERP features).

    Non-organic surfaces (answer_box, related_questions, knowledge_graph,
    local_results, inline_images/videos, top_stories, ai_overview,
    related_searches) are populated only when Google actually returned them
    for the query; absent otherwise.
    """

    query: str
    results: List[GoogleSearchResult] = Field(default_factory=list)
    total: int
    answer_box: Optional[GoogleSearchAnswerBox] = None
    related_questions: List[GoogleSearchRelatedQuestion] = Field(default_factory=list)
    knowledge_graph: Optional[GoogleSearchKnowledgeGraph] = None
    local_results: List[GoogleSearchLocalResult] = Field(default_factory=list)
    inline_images: List[GoogleSearchInlineImage] = Field(default_factory=list)
    inline_videos: List[GoogleSearchInlineVideo] = Field(default_factory=list)
    top_stories: List[GoogleSearchTopStory] = Field(default_factory=list)
    ai_overview: Optional[GoogleSearchAIOverview] = None
    related_searches: List[GoogleSearchRelatedSearch] = Field(default_factory=list)
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchNewsResult(BaseModel):
    """Single news result from Google News search."""

    title: str
    url: str
    snippet: str
    source: Optional[str] = None
    date: Optional[str] = None
    thumbnail: Optional[str] = None


class GoogleSearchNewsResponse(BaseModel):
    """Response for Google News search."""

    query: str
    results: List[GoogleSearchNewsResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchImageResult(BaseModel):
    """Single image result from Google Images search."""

    title: str
    url: str
    original: Optional[str] = None
    thumbnail: Optional[str] = None
    source: Optional[str] = None
    width: Optional[int] = None
    height: Optional[int] = None


class GoogleSearchImagesResponse(BaseModel):
    """Response for Google Images search."""

    query: str
    results: List[GoogleSearchImageResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchVideoResult(BaseModel):
    """Single video result from Google Videos search."""

    title: str
    url: str
    snippet: Optional[str] = None
    displayed_link: Optional[str] = None
    thumbnail: Optional[str] = None
    duration: Optional[str] = None
    platform: Optional[str] = None


class GoogleSearchVideosResponse(BaseModel):
    """Response for Google Videos search."""

    query: str
    results: List[GoogleSearchVideoResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchShoppingResult(BaseModel):
    """Single shopping result from Google Shopping search."""

    title: str
    url: str
    price: Optional[str] = None
    source: Optional[str] = None
    thumbnail: Optional[str] = None
    rating: Optional[float] = None
    reviews: Optional[int] = None


class GoogleSearchShoppingResponse(BaseModel):
    """Response for Google Shopping search."""

    query: str
    results: List[GoogleSearchShoppingResult] = Field(default_factory=list)
    total: int
    search_metadata: Optional[GoogleSearchMetadata] = None


class GoogleSearchAIModeResponse(BaseModel):
    """Response for Google AI Mode search."""

    query: str
    answer: str
    sources: List[GoogleSearchResult] = Field(default_factory=list)
    search_metadata: Optional[GoogleSearchMetadata] = None
