"""Command-line interface for Agent Berlin SDK.

This module provides CLI commands for managing workflows, uploading outputs,
and executing workflow scripts.
"""

import json
import os
import sys
from pathlib import Path
from typing import Any, Optional

import click
import requests

from . import __version__
from .config import DEFAULT_BASE_URL
from .session import configure_session as _configure_session
from .session import load_session_config


@click.group()
@click.version_option(version=__version__, prog_name="agentberlin")
def main() -> None:
    """Agent Berlin CLI - Manage workflows."""
    pass


@main.command()
@click.option("--token", "-t", required=True, help="Authentication token from get_auth_token MCP tool")
@click.option("--domain", "-d", required=True, help="Project domain (e.g., example.com)")
@click.option("--config-path", help="Custom config file path")
def configure(token: str, domain: str, config_path: Optional[str]) -> None:
    """Configure session credentials for Agent Berlin."""
    _configure_session(token, domain, config_path)
    click.echo(f"Session configured for domain: {domain}")


def _resolve_project_domain(project_domain: Optional[str]) -> str:
    """Resolve project_domain from CLI arg or session config."""
    if project_domain:
        return project_domain
    config = load_session_config()
    resolved = config.get("project_domain")
    if not resolved:
        raise click.ClickException(
            "No project domain found. Use --project-domain or configure session first."
        )
    return resolved


@main.group("brand-files")
def brand_files_group() -> None:
    """List and download brand context files (keywords, prompts, brand tone, etc.)."""
    pass


@brand_files_group.command("list")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--json", "as_json", is_flag=True, help="Output raw JSON instead of a table")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_files_list(
    project_domain: Optional[str],
    token: Optional[str],
    as_json: bool,
    base_url: str,
) -> None:
    """List all brand files attached to the project."""
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/list",
            headers=headers,
            json={"project_domain": project_domain},
            timeout=30,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    _handle_api_error(resp, "Brand file list")
    files = resp.json().get("files", [])

    if as_json:
        click.echo(json.dumps(files, indent=2))
        return

    if not files:
        click.echo("No brand files found.")
        return

    id_w = max(len("ID"), max(len(f["id"]) for f in files))
    name_w = max(len("FILENAME"), max(len(f["filename"]) for f in files))
    click.echo(f"{'ID':<{id_w}}  {'FILENAME':<{name_w}}  {'SIZE':>10}  DESCRIPTION")
    for f in files:
        size_kb = f.get("size_bytes", 0) / 1024
        size_str = f"{size_kb:.1f} KB"
        desc = f.get("description", "") or ""
        click.echo(f"{f['id']:<{id_w}}  {f['filename']:<{name_w}}  {size_str:>10}  {desc}")


@brand_files_group.command("download")
@click.argument("file_id")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Output file path. Defaults to the original filename in the current directory.",
)
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def brand_files_download(
    file_id: str,
    project_domain: Optional[str],
    token: Optional[str],
    output: Optional[str],
    base_url: str,
) -> None:
    """Download a brand file's contents by its ID.

    FILE_ID is the file identifier shown by `agentberlin brand-files list`.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    try:
        resp = requests.post(
            f"{base_url}/brand/files/content",
            headers=headers,
            json={"project_domain": project_domain, "file_id": file_id},
            timeout=120,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Brand file '{file_id}' not found.")
    _handle_api_error(resp, "Brand file download")

    if output:
        out_path = Path(output)
    else:
        # Extract filename from Content-Disposition, fall back to file_id.
        disposition = resp.headers.get("Content-Disposition", "")
        filename = file_id
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        out_path = Path.cwd() / filename

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(resp.content)
    click.echo(f"Downloaded: {out_path} ({len(resp.content)} bytes)")


WORKFLOW_GROUP_HELP = """Manage workflows (create, update, publish).

\b
Commands:
  create    Create a new workflow from a natural-language spec
  update    Update metadata of an existing workflow (name, description, details, schedule)
  publish   Push a built file (e.g. main.py) onto the latest version of a workflow

`create` and `update` read from the same manifest file. Editing `details` on an
existing workflow (via `update`) bumps the workflow version and flags it for
rebuild by the builder. `publish` is intended for the workflow_builder agent
running in a sandbox; it does not use the manifest format.

MANIFEST FILE FORMAT
====================

The manifest is a JSON file that defines your workflow metadata:

\b
{
  "name": "My Workflow",
  "description": "Optional description",
  "id": "wfl_abc123xyz",
  "details": "Natural-language spec describing what the workflow does",
  "schedule": {"type": "cron", "cron_expression": "...", "timezone": "UTC"}
}

REQUIRED FIELDS
===============
  name  - Workflow name (always required)
  id    - Required by `update`; absent for `create`

OPTIONAL FIELDS
===============
  description - Workflow description
  details     - Natural-language spec describing what the workflow should do.
                The builder turns this into an executable spec on the server.
  schedule    - {type: "cron"|"one_time"|"manual", cron_expression?, timezone?}

DETAILS
=======
`details` is the most important field. Be thorough: cover data sources,
analysis logic, outputs, and any thresholds or decision criteria. The builder
uses this to generate the executable workflow spec.

SCHEDULE
========
`schedule.type` may be "cron", "one_time", or "manual". Schedules are stored
disabled and start running only after the workflow reaches the "ready" phase.

EXAMPLE
=======

\b
# plan.json
{
  "name": "Weekly Keyword Rank Tracking",
  "description": "Track target keyword positions weekly",
  "details": "Read target keywords from the keywords resource. Every Monday query GSC for rank data for the past 7 days. Flag any keyword that dropped more than 3 positions WoW. Write a summary CSV and email it to the SEO lead.",
  "schedule": { "type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC" }
}

\b
agentberlin workflow create --manifest plan.json
# Later revise details or schedule:
agentberlin workflow update --manifest plan.json
"""


def _handle_api_error(resp: requests.Response, context: str = "API request") -> None:
    """Handle API error responses with appropriate messages."""
    if resp.status_code == 401:
        raise click.ClickException("Authentication failed. Check your token.")
    if resp.status_code == 400:
        error_data = resp.json()
        # Check for validation errors (syntax/type check failures)
        if "validation_errors" in error_data:
            click.echo("Script validation failed:", err=True)
            for err in error_data["validation_errors"]:
                click.echo(f"  - {err}", err=True)
            raise click.ClickException("Fix the errors above and try again")
        error_msg = error_data.get("error", "Bad request")
        raise click.ClickException(f"{context} failed: {error_msg}")
    try:
        resp.raise_for_status()
    except requests.HTTPError as e:
        raise click.ClickException(f"{context} failed: {e}")


def _resolve_token(token: Optional[str]) -> str:
    """Resolve API token from CLI arg, env, or session config."""
    if token:
        return token
    config = load_session_config()
    resolved = config.get("token")
    if not resolved:
        raise click.ClickException("No API token found. Set AGENTBERLIN_TOKEN or configure session first.")
    return resolved


def _load_manifest(manifest: str) -> tuple[dict[str, Any], Path, Path]:
    """Load a manifest JSON file. Returns (data, path, parent_dir)."""
    manifest_path = Path(manifest)
    try:
        data = json.loads(manifest_path.read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"Invalid manifest JSON: {e}")
    if not isinstance(data, dict):
        raise click.ClickException("Manifest must be a JSON object")
    if not data.get("name"):
        raise click.ClickException("manifest must include 'name' field")
    return data, manifest_path, manifest_path.parent


def _build_metadata_payload(manifest_data: dict[str, Any]) -> dict[str, Any]:
    """Extract metadata fields (name, description, details, schedule) from a manifest.

    Only includes keys that are present and non-empty. Used as the body for both
    POST /workflows and PATCH /workflows/:id.
    """
    payload: dict[str, Any] = {"name": manifest_data["name"]}
    description = manifest_data.get("description")
    if description:
        payload["description"] = description
    details = manifest_data.get("details")
    if details:
        payload["details"] = details
    schedule = manifest_data.get("schedule")
    if schedule:
        payload["schedule"] = schedule
    return payload


def _post_create_workflow(base_url: str, headers: dict[str, str], payload: dict[str, Any]) -> str:
    """Call POST /workflows. Returns the new workflow_id."""
    try:
        resp = requests.post(f"{base_url}/workflows", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    _handle_api_error(resp, "Workflow creation")
    return resp.json()["workflow_id"]


def _patch_workflow(
    base_url: str, headers: dict[str, str], workflow_id: str, payload: dict[str, Any]
) -> dict[str, Any]:
    """Call PATCH /workflows/:id. Returns the response JSON."""
    try:
        resp = requests.patch(f"{base_url}/workflows/{workflow_id}", headers=headers, json=payload, timeout=60)
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(f"Workflow '{workflow_id}' not found.")
    _handle_api_error(resp, "Workflow update")
    return resp.json()


def _post_publish_workflow_version(
    base_url: str,
    headers: dict[str, str],
    workflow_id: str,
    files_map: dict[str, str],
    cost_estimate: Optional[dict[str, Any]],
) -> dict[str, Any]:
    """Call POST /workflows/:id/versions/current/files. Returns the response JSON."""
    body: dict[str, Any] = {"files": files_map}
    if cost_estimate is not None:
        body["cost_estimate"] = cost_estimate
    try:
        resp = requests.post(
            f"{base_url}/workflows/{workflow_id}/versions/current/files",
            headers=headers,
            json=body,
            timeout=60,
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")
    if resp.status_code == 404:
        raise click.ClickException(
            f"Workflow '{workflow_id}' not found, or no version exists yet."
        )
    _handle_api_error(resp, "Workflow publish")
    return resp.json()


def _write_id_to_manifest(manifest_path: Path, manifest_data: dict[str, Any], workflow_id: str) -> None:
    """Persist the workflow_id back to the manifest file."""
    manifest_data["id"] = workflow_id
    manifest_path.write_text(json.dumps(manifest_data, indent=2))


@main.group("workflow")
def workflow_group() -> None:
    """Manage workflows (create, update, publish)."""
    pass


workflow_group.help = WORKFLOW_GROUP_HELP


_WORKFLOW_CREATE_HELP = """Create a new workflow from a manifest file.

The manifest must NOT include an 'id' field (the id is written back after creation).
Required: 'name'. Optional: 'description', 'details', 'schedule'.

On success, the new 'id' is written back to the manifest file for future
`agentberlin workflow update` calls.

See `agentberlin workflow --help` for the full manifest format reference.
"""


@workflow_group.command("create", help=_WORKFLOW_CREATE_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_create(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, manifest_path, _ = _load_manifest(manifest)

    if manifest_data.get("id"):
        raise click.ClickException(
            "manifest already has an 'id'. Use `agentberlin workflow update` instead."
        )

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    metadata_payload = _build_metadata_payload(manifest_data)
    workflow_id = _post_create_workflow(base_url, headers, metadata_payload)
    _write_id_to_manifest(manifest_path, manifest_data, workflow_id)
    click.echo(f"Created workflow: {manifest_data['name']} ({workflow_id})")


_WORKFLOW_UPDATE_HELP = """Update an existing workflow.

Requires the manifest to have an 'id' field. Sends any of the following fields
present in the manifest: 'name', 'description', 'details', 'schedule'.

When 'details' changes, the backend bumps the workflow version and flags the
workflow for rebuild by the builder.
"""


@workflow_group.command("update", help=_WORKFLOW_UPDATE_HELP)
@click.option(
    "--manifest",
    "-m",
    type=click.Path(exists=True),
    required=True,
    help="Path to manifest JSON file",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_update(manifest: str, token: Optional[str], base_url: str) -> None:
    token = _resolve_token(token)
    manifest_data, _, _ = _load_manifest(manifest)

    workflow_id = manifest_data.get("id")
    if not workflow_id:
        raise click.ClickException(
            "manifest must include 'id'. Use `agentberlin workflow create` for new workflows."
        )

    payload = _build_metadata_payload(manifest_data)
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _patch_workflow(base_url, headers, workflow_id, payload)
    click.echo(f"Workflow updated: {result.get('name', manifest_data['name'])} ({workflow_id})")
    phase = result.get("phase")
    if phase:
        click.echo(f"Phase: {phase}")


_WORKFLOW_PUBLISH_HELP = """Publish built workflow files to the latest version.

Pass either --file (single file) or --dir (every regular file in the directory).
Sends the contents to the latest workflow_versions row of the workflow identified
by --workflow-id (or the WORKFLOW_ID env var, set automatically inside the
workflow_builder sandbox).

The server stores files under their basename. Status is not changed by this
call — the agent's terminal-status hook flips the version from `building` to
`ready` when the agent reports done.

When --dir is used, dotfiles, __pycache__, and *.pyc are skipped.

--cost-estimate-file is required and points to a JSON file carrying the
per-resource SDK call estimate (must be a JSON object containing an
`estimates` array). Its parsed contents are sent in the request body as
`cost_estimate`; if the file lives inside --dir, its basename is dropped
from the files map so it isn't double-shipped.
"""


def _load_cost_estimate(path: str) -> dict[str, Any]:
    """Read & parse the cost-estimate JSON file. Validates the top-level shape.

    The contract (see workflow_builder agent prompt): a JSON object with an
    `estimates` array. Server-side parsing is strict-typed, so failing fast
    here gives the agent a clear error before the network round-trip.
    """
    try:
        parsed = json.loads(Path(path).read_text())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--cost-estimate-file is not valid JSON: {e}")
    if not isinstance(parsed, dict):
        raise click.ClickException("--cost-estimate-file must be a JSON object")
    if not isinstance(parsed.get("estimates"), list):
        raise click.ClickException(
            "--cost-estimate-file must contain an 'estimates' array"
        )
    return parsed


def _collect_dir_files(dir_path: Path) -> dict[str, str]:
    """Read every regular file in dir_path (non-recursive) into a basename→content map.

    Skips dotfiles, __pycache__ entries, and *.pyc — these would never be
    intentional build artefacts and trip up server-side validation.
    """
    files_map: dict[str, str] = {}
    for entry in sorted(dir_path.iterdir()):
        if not entry.is_file():
            continue
        if entry.name.startswith(".") or entry.name == "__pycache__" or entry.suffix == ".pyc":
            continue
        try:
            files_map[entry.name] = entry.read_text()
        except OSError as e:
            raise click.ClickException(f"Failed to read {entry}: {e}")
    if not files_map:
        raise click.ClickException(f"No publishable files found in {dir_path}.")
    return files_map


@workflow_group.command("publish", help=_WORKFLOW_PUBLISH_HELP)
@click.option(
    "--file",
    "-f",
    "file_path",
    type=click.Path(exists=True, dir_okay=False),
    help="Path to a single file to publish (e.g. main.py).",
)
@click.option(
    "--dir",
    "-d",
    "dir_path",
    type=click.Path(exists=True, file_okay=False),
    help="Directory whose regular files (non-recursive) should be published together.",
)
@click.option(
    "--cost-estimate-file",
    "cost_estimate_path",
    type=click.Path(exists=True, dir_okay=False),
    required=True,
    help=(
        "Path to a JSON file with the workflow's per-resource SDK cost estimate. "
        "Sent in the request body as cost_estimate; excluded from the files map "
        "when --dir is used."
    ),
)
@click.option(
    "--workflow-id",
    envvar="WORKFLOW_ID",
    help="Workflow id. Defaults to the WORKFLOW_ID env var set inside the sandbox.",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_publish(
    file_path: Optional[str],
    dir_path: Optional[str],
    cost_estimate_path: str,
    workflow_id: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    if bool(file_path) == bool(dir_path):
        raise click.ClickException("Pass exactly one of --file or --dir.")
    if not workflow_id:
        raise click.ClickException(
            "workflow id is required. Pass --workflow-id or set WORKFLOW_ID."
        )
    token = _resolve_token(token)

    cost_estimate = _load_cost_estimate(cost_estimate_path)

    if file_path:
        path = Path(file_path)
        try:
            content = path.read_text()
        except OSError as e:
            raise click.ClickException(f"Failed to read {file_path}: {e}")
        files_map = {path.name: content}
        label = path.name
    else:
        assert dir_path is not None  # for type checker; click guarantees one of the two
        files_map = _collect_dir_files(Path(dir_path))
        # The cost estimate is published via its own column, not as a file —
        # drop it from the files map if it happened to live in --dir.
        files_map.pop(Path(cost_estimate_path).name, None)
        if not files_map:
            raise click.ClickException(f"No publishable files found in {dir_path}.")
        label = f"{len(files_map)} files from {dir_path}"

    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    result = _post_publish_workflow_version(
        base_url, headers, workflow_id, files_map, cost_estimate
    )
    version = result.get("version")
    if version is not None:
        click.echo(f"Published {label} to workflow {workflow_id} (version {version})")
    else:
        click.echo(f"Published {label} to workflow {workflow_id}")


_WORKFLOW_RUN_HELP = """Execute a workflow's main.py and upload its artifacts.

\b
Runs `python <main>` (default: ./main.py) as a subprocess, tees stdout
and stderr live to this process's stdout/stderr (so CloudWatch / journald
see output as it happens) while buffering them, and after the script
exits uploads stdout, stderr, and any output.json the script produced
to the backend. The backend stores them in S3 under the brand-domain
prefix and records artifacts_uploaded_at on the workflow_runs row.

\b
Auth: AGENTBERLIN_TOKEN must be a sandbox token. The processor injects
it before exec'ing this command — the token's task_runner_id and
workflow_id claims tell the backend which run row to attach the
artifacts to. There is no --workflow-id or --run-id flag.

\b
Exit code: passes through the script's exit code unchanged. Upload
errors are logged to stderr but do not mask the script's return value.
"""


def _stream_tee(
    src: Any, sink: Any, buf: bytearray, lock: Any
) -> None:
    """Read bytes from src line-by-line, append to buf, and mirror to sink.

    Runs in a daemon thread per stream so the parent can wait on the
    process while output flows live. Bytes (not str) keep encoding
    clean for non-UTF-8 script output.
    """
    while True:
        chunk = src.readline()
        if not chunk:
            return
        with lock:
            buf.extend(chunk)
        try:
            sink.write(chunk)
            sink.flush()
        except (OSError, ValueError):
            # Parent's stdout/stderr was closed — keep buffering.
            pass


@workflow_group.command("run", help=_WORKFLOW_RUN_HELP)
@click.option(
    "--main",
    "main_path",
    type=click.Path(exists=True),
    default="main.py",
    show_default=True,
    help="Path to the workflow's main.py.",
)
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="Sandbox token (injected by the processor).")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def workflow_run(main_path: str, token: Optional[str], base_url: str) -> None:
    import subprocess
    import threading

    token = _resolve_token(token)
    main_resolved = Path(main_path).resolve()
    cwd = main_resolved.parent

    stdout_buf = bytearray()
    stderr_buf = bytearray()
    stdout_lock = threading.Lock()
    stderr_lock = threading.Lock()

    # `-u` forces the child's stdout/stderr to be unbuffered. Without it,
    # CPython block-buffers writes to a pipe and we'd see nothing live —
    # output would only appear when the buffer filled or the process
    # exited. PYTHONUNBUFFERED is set as a belt-and-braces in case the
    # script re-execs or spawns its own python helpers.
    child_env = os.environ.copy()
    child_env["PYTHONUNBUFFERED"] = "1"
    proc = subprocess.Popen(
        [sys.executable, "-u", str(main_resolved)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=str(cwd),
        env=child_env,
    )

    stdout_thread = threading.Thread(
        target=_stream_tee,
        args=(proc.stdout, sys.stdout.buffer, stdout_buf, stdout_lock),
        daemon=True,
    )
    stderr_thread = threading.Thread(
        target=_stream_tee,
        args=(proc.stderr, sys.stderr.buffer, stderr_buf, stderr_lock),
        daemon=True,
    )
    stdout_thread.start()
    stderr_thread.start()

    return_code = proc.wait()
    stdout_thread.join()
    stderr_thread.join()

    output_path = cwd / "output.json"
    output_bytes: Optional[bytes] = None
    if output_path.is_file():
        try:
            output_bytes = output_path.read_bytes()
        except OSError as e:
            click.echo(f"warning: failed to read output.json: {e}", err=True)

    files = {
        "stdout": ("stdout.log", bytes(stdout_buf), "text/plain"),
        "stderr": ("stderr.log", bytes(stderr_buf), "text/plain"),
    }
    if output_bytes is not None:
        files["output"] = ("output.json", output_bytes, "application/json")

    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = requests.post(
            f"{base_url}/workflow-runs/artifacts",
            headers=headers,
            files=files,
            data={"exit_code": str(return_code)},
            timeout=60,
        )
    except requests.RequestException as e:
        click.echo(f"warning: artifact upload failed (network): {e}", err=True)
        sys.exit(return_code)

    if resp.status_code != 200:
        # Don't raise — surface the error but preserve the script's exit
        # code. The processor's separate terminal-status PATCH carries
        # the DB-side error reporting.
        try:
            err_msg = resp.json().get("error", resp.text)
        except ValueError:
            err_msg = resp.text
        click.echo(
            f"warning: artifact upload failed (HTTP {resp.status_code}): {err_msg}",
            err=True,
        )

    sys.exit(return_code)


REPORT_GROUP_HELP = """Manage reports (create, update, publish).

\b
A report is an HTML viewer paired with a JSON spec. Agents read the spec to
know what shape of data to produce; `report publish` uploads that data as
the live data.json the HTML reads.

\b
Commands:
  create    Register a new report and upload its HTML + spec
  update    Update html, spec, title, or description on an existing report
  publish   Upload a new data.json conforming to the spec
"""


@main.group("report", help=REPORT_GROUP_HELP)
def report_group() -> None:
    pass


def _load_json_file(path: str, field_name: str, require_object: bool) -> None:
    """Validate a path is a readable JSON file (and optionally a top-level object).

    Raises click.ClickException with a friendly message on failure. Does not
    return the parsed JSON — callers upload the raw bytes, this is only a
    fail-fast check before hitting the network.
    """
    p = Path(path)
    if p.suffix.lower() != ".json":
        raise click.ClickException(f"--{field_name} must be a .json file")
    try:
        parsed = json.loads(p.read_bytes())
    except json.JSONDecodeError as e:
        raise click.ClickException(f"--{field_name} is not valid JSON: {e}")
    if require_object and not isinstance(parsed, dict):
        raise click.ClickException(f"--{field_name} must be a JSON object at the top level")


def _check_html_file(path: str, field_name: str) -> None:
    if Path(path).suffix.lower() != ".html":
        raise click.ClickException(f"--{field_name} must be a .html file")


@report_group.command("create")
@click.option("--slug", required=True, help="URL-safe identifier, e.g. 'audit'. Lowercase alphanumeric + hyphens, max 64 chars.")
@click.option("--details", required=True, help="Data-shape brief for the report_builder agent. Describe each workflow's output shape and any visual instructions.")
@click.option("--title", help="Display title for the report.")
@click.option("--description", help="Optional description.")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_create(
    slug: str,
    details: str,
    title: Optional[str],
    description: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Create a new report row and enqueue a report_builder run to author its HTML + spec.

    The --details brief is the builder's only context — describe each
    workflow's data shape (fields, types, cardinality) and any user-supplied
    visual instructions. The HTML and spec.json files are produced by the
    builder, not passed here.
    """
    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    form: dict[str, str] = {
        "slug": slug,
        "project_domain": project_domain,
        "details": details,
    }
    if title:
        form["title"] = title
    if description:
        form["description"] = description

    headers = {"Authorization": f"Bearer {token}"}
    try:
        resp = requests.post(
            f"{base_url}/reports", headers=headers, data=form, timeout=120
        )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 409:
        error_msg = resp.json().get("error", "Report already exists")
        raise click.ClickException(error_msg)
    _handle_api_error(resp, "Report create")

    result = resp.json()
    click.echo(f"Report build enqueued: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL (live after the builder publishes): {result['url']}")


@report_group.command("update")
@click.option("--slug", required=True, help="Slug of the existing report to update.")
@click.option("--details", default=None, help="New brief for the report_builder. Re-enqueues a build. Mutually exclusive with --html/--spec.")
@click.option("--html", "html_path", type=click.Path(exists=True), help="Builder publish path: new HTML viewer. Direct write to S3.")
@click.option("--spec", "spec_path", type=click.Path(exists=True), help="Builder publish path: new JSON spec. Direct write to S3.")
@click.option("--title", default=None, help="New title (optional).")
@click.option("--description", default=None, help="New description (optional).")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_update(
    slug: str,
    details: Optional[str],
    html_path: Optional[str],
    spec_path: Optional[str],
    title: Optional[str],
    description: Optional[str],
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Update an existing report.

    Three modes (chosen by which flags you pass):

    \b
    - --details "..."           re-enqueue a report_builder run with a fresh brief.
    - --html ... --spec ...     builder direct write of new layout artefacts to S3.
    - --title ... [--description ...]  metadata only.

    --details is mutually exclusive with --html/--spec.
    """
    if (
        details is None
        and html_path is None
        and spec_path is None
        and title is None
        and description is None
    ):
        raise click.ClickException(
            "provide at least one of --details, --html, --spec, --title, --description"
        )
    if details is not None and (html_path is not None or spec_path is not None):
        raise click.ClickException(
            "--details cannot be combined with --html or --spec"
        )

    if html_path is not None:
        _check_html_file(html_path, "html")
    if spec_path is not None:
        _load_json_file(spec_path, "spec", require_object=True)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    form: dict[str, str] = {"project_domain": project_domain}
    if title is not None:
        form["title"] = title
    if description is not None:
        form["description"] = description
    if details is not None:
        form["details"] = details

    headers = {"Authorization": f"Bearer {token}"}
    html_f = open(html_path, "rb") if html_path else None
    spec_f = open(spec_path, "rb") if spec_path else None
    try:
        files: dict[str, tuple[str, Any, str]] = {}
        if html_f is not None and html_path is not None:
            files["file"] = (Path(html_path).name, html_f, "text/html")
        if spec_f is not None and spec_path is not None:
            files["spec"] = (Path(spec_path).name, spec_f, "application/json")
        try:
            resp = requests.patch(
                f"{base_url}/reports/{slug}",
                headers=headers,
                files=files if files else None,
                data=form,
                timeout=120,
            )
        except requests.RequestException as e:
            raise click.ClickException(f"Failed to connect to API: {e}")
    finally:
        if html_f is not None:
            html_f.close()
        if spec_f is not None:
            spec_f.close()

    if resp.status_code == 404:
        raise click.ClickException(f"Report '{slug}' not found. Use `agentberlin report create` first.")
    _handle_api_error(resp, "Report update")

    result = resp.json()
    if details is not None:
        click.echo(f"Report build enqueued: {slug} ({result.get('report_id', '')})")
    else:
        click.echo(f"Report updated: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


@report_group.command("publish")
@click.option("--slug", required=True, help="Slug of the report to publish data for.")
@click.option("--data", "data_path", type=click.Path(exists=True), required=True, help="Path to the JSON data file conforming to the spec.")
@click.option("--project-domain", envvar="PROJECT_DOMAIN", help="Project domain (reads from PROJECT_DOMAIN env or config if not set)")
@click.option("--token", envvar="AGENTBERLIN_TOKEN", help="API token")
@click.option("--base-url", default=DEFAULT_BASE_URL, hidden=True)
def report_publish(
    slug: str,
    data_path: str,
    project_domain: Optional[str],
    token: Optional[str],
    base_url: str,
) -> None:
    """Publish a new data.json for an existing report."""
    _load_json_file(data_path, "data", require_object=False)

    token = _resolve_token(token)
    project_domain = _resolve_project_domain(project_domain)

    headers = {"Authorization": f"Bearer {token}"}
    try:
        with open(data_path, "rb") as data_f:
            files = {"file": (Path(data_path).name, data_f, "application/json")}
            resp = requests.post(
                f"{base_url}/reports/{slug}/publish",
                headers=headers,
                files=files,
                data={"project_domain": project_domain},
                timeout=120,
            )
    except requests.RequestException as e:
        raise click.ClickException(f"Failed to connect to API: {e}")

    if resp.status_code == 404:
        raise click.ClickException(f"Report '{slug}' not found. Use `agentberlin report create` first.")
    _handle_api_error(resp, "Report publish")

    result = resp.json()
    click.echo(f"Report data published: {slug} ({result.get('report_id', '')})")
    if result.get("url"):
        click.echo(f"URL: {result['url']}")


if __name__ == "__main__":
    main()
