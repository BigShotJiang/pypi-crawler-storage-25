"""PageSpeed Insights resource for Agent Berlin SDK."""

from typing import Optional

from .._http import HTTPClient
from ..models.pagespeed import PageSpeedAnalyzeResponse


class PageSpeedResource:
    """Resource for Google PageSpeed Insights analysis.

    Runs a Lighthouse audit for the given URL and returns performance score
    and Core Web Vitals (LCP, FCP, CLS, TBT, Speed Index, TTI, server response
    time).

    PSI is synchronous on Google's side — each analysis takes 10–30 seconds
    typically, longer for heavy sites. A 90-second timeout is applied on the
    backend. If the target site is too slow for Lighthouse to finish, the
    analysis returns a timeout error; it is not retried (a retry is a fresh
    Lighthouse run and burns another quota unit with the same outcome likely).

    Example:
        result = client.pagespeed.analyze(
            url="https://example.com",
            strategy="mobile",
        )
        print(f"Performance score: {result.performance_score}")
        print(f"LCP: {result.core_web_vitals.largest_contentful_paint_ms}ms")
    """

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def analyze(
        self,
        url: str,
        *,
        strategy: str = "mobile",
        locale: Optional[str] = None,
    ) -> PageSpeedAnalyzeResponse:
        """Run a Lighthouse audit on the given URL.

        Args:
            url: The page to analyze. Must start with http:// or https://.
            strategy: Form factor — "mobile" (default) or "desktop".
            locale: BCP 47 locale, e.g. "en-US". Defaults to "en-US".

        Returns:
            PageSpeedAnalyzeResponse with performance score and core web vitals.
        """
        payload: dict[str, object] = {"url": url, "strategy": strategy}
        if locale is not None:
            payload["locale"] = locale

        data = self._http.post("/pagespeed/analyze", json=payload)
        return PageSpeedAnalyzeResponse.model_validate(data)
