"""Tests for the `agentberlin report` CLI subcommand group.

HTTP calls are stubbed via the `responses` library so tests don't hit a real
backend. File uploads are validated client-side before the request is made.
"""

import json
from pathlib import Path

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write(path: Path, text: str) -> Path:
    path.write_text(text)
    return path


def _html(tmp_path: Path, name: str = "viewer.html") -> Path:
    return _write(tmp_path / name, "<html><body>viewer</body></html>")


def _spec(tmp_path: Path, name: str = "spec.json") -> Path:
    return _write(tmp_path / name, json.dumps({"version": 1, "fields": []}))


def _data(tmp_path: Path, name: str = "data.json") -> Path:
    return _write(tmp_path / name, json.dumps({"score": 42}))


# ---------------------------------------------------------------------------
# report create — operator first-time. --details is required; HTML/spec are
# produced by the report_builder, not passed here.
# ---------------------------------------------------------------------------


class TestReportCreate:
    @responses.activate
    def test_happy_path_enqueues_build_with_details(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={"success": True, "report_id": "rpt_abc", "url": "https://cdn/example.com/reports/audit/index.html"},
            status=202,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "create",
                "--slug", "audit",
                "--details", "Workflow X produces { rows: [...] }; render as a table.",
                "--title", "Audit",
                "--description", "Weekly",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "rpt_abc" in result.output
        assert "enqueued" in result.output.lower()
        body = responses.calls[0].request.body
        # Form-urlencoded since no files are attached.
        assert "details=" in body
        assert "Audit" in body

    def test_requires_details(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "create",
                "--slug", "audit",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "details" in result.output.lower()

    @responses.activate
    def test_surfaces_409_duplicate(self, tmp_path: Path) -> None:
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports",
            json={"error": "Report with slug 'audit' already exists. Use `agentberlin report update` instead."},
            status=409,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "create",
                "--slug", "audit",
                "--details", "x",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "already exists" in result.output


# ---------------------------------------------------------------------------
# report update — operator subsequent (--details), builder publish
# (--html/--spec), or metadata only (--title/--description).
# ---------------------------------------------------------------------------


class TestReportUpdate:
    def test_requires_at_least_one_field(self, tmp_path: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "update",
                "--slug", "audit",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "at least one" in result.output.lower()

    def test_rejects_details_with_html_or_spec(self, tmp_path: Path) -> None:
        html = _html(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "update",
                "--slug", "audit",
                "--details", "x",
                "--html", str(html),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "details" in result.output.lower()
        assert "html" in result.output.lower() or "spec" in result.output.lower()

    @responses.activate
    def test_details_only_enqueues_build(self, tmp_path: Path) -> None:
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={"success": True, "report_id": "rpt_abc", "url": "https://cdn/example.com/reports/audit/index.html"},
            status=202,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "update",
                "--slug", "audit",
                "--details", "Workflow Y now produces a score field; surface it as a dial.",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "enqueued" in result.output.lower()
        body = responses.calls[0].request.body
        assert "details=" in body

    @responses.activate
    def test_metadata_only_update(self, tmp_path: Path) -> None:
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={"success": True, "report_id": "rpt_abc", "url": "https://cdn/example.com/reports/audit/index.html"},
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "update",
                "--slug", "audit",
                "--title", "New title",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code == 0, result.output
        body = responses.calls[0].request.body
        # Metadata-only PATCH sends no files, so requests uses urlencoded form
        # (str body) rather than multipart (bytes body).
        assert "New+title" in body or "New title" in body

    @responses.activate
    def test_spec_only_update(self, tmp_path: Path) -> None:
        spec = _spec(tmp_path)
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/audit",
            json={"success": True, "report_id": "rpt_abc", "url": "https://cdn/example.com/reports/audit/index.html"},
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "update",
                "--slug", "audit",
                "--spec", str(spec),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code == 0, result.output
        body = responses.calls[0].request.body
        assert b'name="spec"' in body
        assert b'name="file"' not in body

    @responses.activate
    def test_surfaces_404(self, tmp_path: Path) -> None:
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/reports/missing",
            json={"error": "not found"},
            status=404,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "update",
                "--slug", "missing",
                "--title", "x",
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower()


# ---------------------------------------------------------------------------
# report publish — unchanged
# ---------------------------------------------------------------------------


class TestReportPublish:
    @responses.activate
    def test_happy_path(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/audit/publish",
            json={"success": True, "report_id": "rpt_abc", "url": "https://cdn/example.com/reports/audit/data.json"},
            status=200,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish",
                "--slug", "audit",
                "--data", str(data),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code == 0, result.output
        assert "data.json" in result.output

    def test_rejects_non_json_data(self, tmp_path: Path) -> None:
        bad = _write(tmp_path / "data.csv", "a,b\n1,2\n")
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish",
                "--slug", "audit",
                "--data", str(bad),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert ".json" in result.output

    def test_rejects_invalid_json_data(self, tmp_path: Path) -> None:
        bad = _write(tmp_path / "data.json", "{not json")
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish",
                "--slug", "audit",
                "--data", str(bad),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "valid JSON" in result.output or "not valid JSON" in result.output

    @responses.activate
    def test_surfaces_404(self, tmp_path: Path) -> None:
        data = _data(tmp_path)
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/reports/missing/publish",
            json={"error": "not found"},
            status=404,
        )
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "report", "publish",
                "--slug", "missing",
                "--data", str(data),
                "--project-domain", "example.com",
                "--token", "t",
            ],
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower()
