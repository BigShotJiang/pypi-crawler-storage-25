"""Tests for the `agentberlin workflow` CLI subcommand group.

Covers manifest-shape validation and URL routing. HTTP calls are stubbed via
the `responses` library so tests don't hit a real backend.
"""

import json
from pathlib import Path
from typing import Any

import responses
from click.testing import CliRunner

from agentberlin.cli import main
from agentberlin.config import DEFAULT_BASE_URL


def _write_manifest(tmp_path: Path, data: dict[str, Any], name: str = "manifest.json") -> Path:
    path = tmp_path / name
    path.write_text(json.dumps(data))
    return path


def _read_manifest(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


# ---------------------------------------------------------------------------
# workflow create
# ---------------------------------------------------------------------------


class TestWorkflowCreate:
    @responses.activate
    def test_plan_only_create_writes_id_back(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "name": "Weekly Rank Tracking",
                "details": "Query GSC weekly and flag drops.",
                "schedule": {"type": "cron", "cron_expression": "0 9 * * 1", "timezone": "UTC"},
            },
        )
        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows",
            json={"success": True, "workflow_id": "wfl_123", "name": "Weekly Rank Tracking", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_123" in result.output
        assert _read_manifest(manifest)["id"] == "wfl_123"

        body = json.loads(responses.calls[0].request.body)
        assert body["details"] == "Query GSC weekly and flag drops."
        assert body["schedule"]["type"] == "cron"

    def test_rejects_manifest_with_id(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path, {"name": "Existing", "id": "wfl_abc", "details": "irrelevant"}
        )
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "already has an 'id'" in result.output

    def test_rejects_manifest_without_name(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "create", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "name" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow update
# ---------------------------------------------------------------------------


class TestWorkflowUpdate:
    @responses.activate
    def test_update_patches_metadata(self, tmp_path: Path) -> None:
        manifest = _write_manifest(
            tmp_path,
            {
                "id": "wfl_abc",
                "name": "Edited Name",
                "description": "new desc",
                "details": "revised spec",
            },
        )
        responses.add(
            responses.PATCH,
            f"{DEFAULT_BASE_URL}/workflows/wfl_abc",
            json={"success": True, "workflow_id": "wfl_abc", "name": "Edited Name", "phase": "pre_planning"},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "update", "-m", str(manifest), "--token", "t"])

        assert result.exit_code == 0, result.output
        assert "wfl_abc" in result.output
        body = json.loads(responses.calls[0].request.body)
        assert body["name"] == "Edited Name"
        assert body["description"] == "new desc"
        assert body["details"] == "revised spec"

    def test_rejects_manifest_without_id(self, tmp_path: Path) -> None:
        manifest = _write_manifest(tmp_path, {"name": "X", "details": "..."})
        runner = CliRunner()
        result = runner.invoke(main, ["workflow", "update", "-m", str(manifest), "--token", "t"])
        assert result.exit_code != 0
        assert "id" in result.output.lower()


# ---------------------------------------------------------------------------
# workflow publish
# ---------------------------------------------------------------------------


def _write_estimate(tmp_path: Path, name: str = "api_estimate.json") -> Path:
    """Drop a minimal-but-valid cost-estimate JSON into tmp_path."""
    p = tmp_path / name
    p.write_text('{"estimates": []}')
    return p


class TestWorkflowPublish:
    @responses.activate
    def test_publish_dir_routes_estimate_into_body_and_filters_droppings(
        self, tmp_path: Path
    ) -> None:
        # --dir bundles main.py + output_schema.json into the files map,
        # routes api_estimate.json into the cost_estimate body field, and
        # filters dotfiles / __pycache__ / *.pyc droppings.
        (tmp_path / "main.py").write_text("print('hi')\n")
        (tmp_path / "output_schema.json").write_text('{"type":"object"}')
        estimate = {
            "estimates": [
                {
                    "resource": "gsc",
                    "method": "query",
                    "calls_per_run": {"min": 1, "max": 30, "typical": 5},
                    "basis": "one query per page",
                }
            ]
        }
        (tmp_path / "api_estimate.json").write_text(json.dumps(estimate))
        (tmp_path / ".DS_Store").write_text("ignored")
        (tmp_path / "main.pyc").write_bytes(b"\x00\x00")
        (tmp_path / "__pycache__").mkdir()

        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows/wfl_xyz/versions/current/files",
            json={"success": True, "version": 3},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(tmp_path / "api_estimate.json"),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        assert "version 3" in result.output

        body = json.loads(responses.calls[0].request.body)
        assert set(body["files"].keys()) == {"main.py", "output_schema.json"}
        assert body["files"]["main.py"] == "print('hi')\n"
        assert body["cost_estimate"] == estimate

    def test_publish_rejects_passing_both_file_and_dir(self, tmp_path: Path) -> None:
        # The two flags are mutually exclusive; passing both is a user error
        # that should fail before any HTTP call is made.
        (tmp_path / "main.py").write_text("print('hi')\n")
        estimate = _write_estimate(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--file",
                str(tmp_path / "main.py"),
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(estimate),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "exactly one" in result.output.lower()

    def test_publish_requires_one_of_file_or_dir(self, tmp_path: Path) -> None:
        estimate = _write_estimate(tmp_path)
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--cost-estimate-file",
                str(estimate),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "exactly one" in result.output.lower()

    def test_publish_requires_cost_estimate_file(self, tmp_path: Path) -> None:
        # The flag is mandatory: omitting it fails before any HTTP call.
        (tmp_path / "main.py").write_text("print('hi')\n")
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(tmp_path),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "cost-estimate-file" in result.output.lower()

    def test_publish_dir_errors_when_empty(self, tmp_path: Path) -> None:
        # An empty publish would silently no-op and leave the version row
        # empty; surface it as an error instead.
        outside = tmp_path.parent / "estimate.json"
        outside.write_text('{"estimates": []}')
        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(outside),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "no publishable files" in result.output.lower()

    @responses.activate
    def test_publish_cost_estimate_file_outside_dir_excluded_from_files(
        self, tmp_path: Path
    ) -> None:
        # The cost-estimate file may live outside --dir entirely; the body
        # should still carry it, the dir's files are unaffected.
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "main.py").write_text("print('hi')\n")
        estimate_path = tmp_path / "api_estimate.json"
        estimate_path.write_text('{"estimates": []}')

        responses.add(
            responses.POST,
            f"{DEFAULT_BASE_URL}/workflows/wfl_xyz/versions/current/files",
            json={"success": True, "version": 1},
            status=200,
        )

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(src_dir),
                "--cost-estimate-file",
                str(estimate_path),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )

        assert result.exit_code == 0, result.output
        body = json.loads(responses.calls[0].request.body)
        assert set(body["files"].keys()) == {"main.py"}
        assert body["cost_estimate"] == {"estimates": []}

    def test_publish_rejects_invalid_cost_estimate_json(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text("print('hi')\n")
        bad = tmp_path / "api_estimate.json"
        bad.write_text("not json at all")

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(bad),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "not valid json" in result.output.lower()

    def test_publish_rejects_cost_estimate_without_estimates_array(
        self, tmp_path: Path
    ) -> None:
        (tmp_path / "main.py").write_text("print('hi')\n")
        bad = tmp_path / "api_estimate.json"
        bad.write_text('{"foo": "bar"}')

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(bad),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "estimates" in result.output.lower()

    def test_publish_dir_with_only_cost_estimate_file_errors(self, tmp_path: Path) -> None:
        # If the dir only contains the cost-estimate file and we pop it, there
        # are no files left to publish — surface the empty-dir error.
        estimate_path = tmp_path / "api_estimate.json"
        estimate_path.write_text('{"estimates": []}')

        runner = CliRunner()
        result = runner.invoke(
            main,
            [
                "workflow",
                "publish",
                "--dir",
                str(tmp_path),
                "--cost-estimate-file",
                str(estimate_path),
                "--workflow-id",
                "wfl_xyz",
                "--token",
                "t",
            ],
        )
        assert result.exit_code != 0
        assert "no publishable files" in result.output.lower()
