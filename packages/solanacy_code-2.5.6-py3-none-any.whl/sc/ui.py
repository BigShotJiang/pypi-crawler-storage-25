"""SC Terminal UI — Apple-style, minimal, clean."""
from __future__ import annotations
import sys, time, re, os
from typing import Optional
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from rich.table import Table
from rich.prompt import Prompt, Confirm
from rich import box
from rich.markup import escape

console = Console(highlight=False, markup=True)
err_console = Console(stderr=True, highlight=False)

PRIMARY  = "#7B68EE"
SUCCESS  = "#50FA7B"
WARNING  = "#FFB86C"
ERROR_C  = "#FF5555"
MUTED    = "#6272A4"
ACCENT   = "#8BE9FD"
TOOL_C   = "#BD93F9"
AGENT_C  = "#FF79C6"

BANNER = """
  ███████  ██████  ██       █████  ███   ██   ██████  ██    ██
  ██      ██    ██ ██      ██   ██ ████  ██ ██    ██  ██  ██
  ███████ ██    ██ ██      ███████ ██ ██ ██ ██    ██   ████
       ██ ██    ██ ██      ██   ██ ██  ████ ██    ██    ██
  ███████  ██████  ███████ ██   ██ ██   ███  ██████     ██

   ██████  ██████  ██████  ████████
  ██      ██    ██ ██   ██ ██
  ██      ██    ██ ██   ██ ██████
  ██      ██    ██ ██   ██ ██
   ██████  ██████  ██████  ████████

         v2.5.5  ·  by Saumik Paul
"""

def show_banner(provider: str, model: str):
    console.print(f"[bold {PRIMARY}]{BANNER}[/]")
    console.print(
        f"  [{MUTED}]provider:[/] [bold {ACCENT}]{provider}[/] "
        f"[{MUTED}]/[/] [bold {PRIMARY}]{model}[/]"
        f"  [{MUTED}]type /help[/]\n"
    )

def show_thinking():
    import threading, itertools, time
    frames = ["|", "/", "-", "\\"]
    stop = threading.Event()
    def _spin():
        for f in itertools.cycle(frames):
            if stop.is_set():
                break
            console.print(Text(f"  {f} thinking...", style=f"dim {MUTED}"), end="\r")
            time.sleep(0.1)
        console.print(" " * 30, end="\r")
    t = threading.Thread(target=_spin, daemon=True)
    t.start()
    show_thinking._stop = stop
    show_thinking._thread = t

def stop_thinking():
    s = getattr(show_thinking, "_stop", None)
    if s:
        s.set()

def clear_line():
    console.print(" " * 70, end="\r")

def show_response_start(): pass

def stream_response(chunk: str):
    console.print(chunk, end="", markup=False, highlight=False)

def show_response_end(text: str = ""):
    console.print()

def show_full_response(text: str):
    if "```" in text:
        parts = re.split(r"(```\w*\n.*?```)", text, flags=re.DOTALL)
        for part in parts:
            if part.startswith("```"):
                lang_m = re.match(r"```(\w+)\n", part)
                lang = lang_m.group(1) if lang_m else "text"
                code = re.sub(r"```\w*\n?", "", part).strip()
                try:
                    console.print(Syntax(code, lang, theme="dracula",
                                         line_numbers=False, padding=(0,1)))
                except Exception:
                    console.print(code)
            else:
                if part.strip():
                    console.print(part.rstrip(), markup=False, highlight=False)
    else:
        console.print(text.rstrip(), markup=False, highlight=False)
    console.print()

def show_tool_running(name: str, description: str):
    console.print(f"  [{MUTED}]  -> {escape(name)}: {escape(description[:60])}[/]", end="\r")

def show_tool_result(name: str, result: str):
    clear_line()
    if not result or not result.strip():
        console.print(f"  [{SUCCESS}]v[/] [{MUTED}]{escape(name)} done[/]")
        return
    if result.startswith("❌") or "Error" in result[:30] or "error" in result[:30]:
        first_line = result.strip().splitlines()[0]
        console.print(f"  [{ERROR_C}]x {escape(first_line[:100])}[/]")
        return
    if result.startswith("✅"):
        console.print(f"  [{SUCCESS}]{escape(result[:120])}[/]")
        return
    lines = result.strip().splitlines()
    total = len(lines)
    preview = lines[:3]
    out = "  ".join(escape(l) for l in preview if l.strip())
    if out:
        console.print(f"  [{MUTED}]{escape(name)}:[/] {out[:120]}")
    if total > 3:
        console.print(f"  [{MUTED}]  ... {total} lines[/]")

def show_tool_denied(name: str):
    console.print(f"  [dim]  ⛔ {name} denied[/]")

def ask_tool_permission(name: str, description: str, force: bool = False) -> bool:
    from .tools import get_permission, PermissionMode
    perm = get_permission(name)
    color = ERROR_C if perm == PermissionMode.DANGEROUS else WARNING
    console.print()
    if force:
        return Confirm.ask(
            f"  [{color}]Allow [bold]{name}[/bold]?[/]\n"
            f"  [{MUTED}]{escape(description[:80])}[/]\n  ",
            default=False)
    else:
        return Confirm.ask(
            f"  [{color}]Allow [bold]{name}[/bold]?[/]  [{MUTED}]{escape(description[:60])}[/]  ",
            default=True)

def show_success(msg: str): console.print(f"  [{SUCCESS}]v[/] {escape(msg)}")
def show_error(msg: str): console.print(f"  [{ERROR_C}]x[/] {escape(msg)}")
def show_warning(msg: str): console.print(f"  [{WARNING}]![/] {escape(msg)}")
def show_info(msg: str): console.print(f"  [{MUTED}]{escape(msg)}[/]")
def show_cost(cost: float, tokens: int):
    if cost > 0:
        console.print(f"  [{MUTED}]  cost: ${cost:.5f}  {tokens:,} tokens[/]")

def show_status(provider, model, auto_approve, msgs, agents_mode=False, think_mode=False):
    table = Table(box=box.SIMPLE, show_header=False, padding=(0,2))
    table.add_column(style=MUTED)
    table.add_column(style="white")
    table.add_row("Provider", f"[{ACCENT}]{provider}[/]")
    table.add_row("Model", f"[{PRIMARY}]{model}[/]")
    table.add_row("Messages", str(msgs))
    table.add_row("Auto-approve", "ON" if auto_approve else "OFF")
    table.add_row("Think mode", "ON" if think_mode else "OFF")
    table.add_row("Agents mode", "ON" if agents_mode else "OFF")
    console.print(table)

def show_help():
    console.print(f"\n  [{ACCENT}]Solanacy Code v2.5[/] — AI coding agent\n")
    cmds = [
        ("/model", "Switch provider/model"),
        ("/config", "Manage API keys"),
        ("/status", "Show current status"),
        ("/models", "Show all models + availability"),
        ("/clear", "Clear conversation"),
        ("/compact", "Compress context manually"),
        ("/auto", "Toggle auto-approve tools"),
        ("/think", "Toggle think mode"),
        ("/agents", "Toggle multi-agent mode"),
        ("/agent X", "Force next msg to agent"),
        ("/hybrid", "Toggle hybrid mode"),
        ("/memory", "Show long-term memory"),
        ("/remember X", "Add to memory"),
        ("/forget X", "Delete from memory"),
        ("/memstats", "Memory size + status"),
        ("/todo", "Show TODO list"),
        ("/add X", "Add TODO"),
        ("/done X", "Complete TODO"),
        ("/cost", "Show cost stats"),
        ("/budget X", "Set daily budget"),
        ("/index", "Index codebase"),
        ("/search X", "Search codebase"),
        ("/git", "Git status"),
        ("/diff", "Git diff"),
        ("/commit X", "Git commit"),
        ("/save", "Save session"),
        ("/load", "Load session"),
        ("/sessions", "List sessions"),
        ("/snapshot", "Save checkpoint"),
        ("/restore", "Restore checkpoint"),
        ("/share", "Export session"),
        ("/plugins", "List plugins"),
        ("/benchmark", "Benchmark all models"),
        ("/init", "Create SC.md"),
        ("/exit", "Quit"),
    ]
    for cmd, desc in cmds:
        console.print(f"  [{ACCENT}]{cmd:<18}[/] [{MUTED}]{desc}[/]")
    console.print()

def show_tools():
    from .tools import TOOL_SPECS, TOOL_PERMISSIONS, PermissionMode
    console.print(f"\n  [{ACCENT}]Available Tools[/]\n")
    for t in TOOL_SPECS:
        perm = TOOL_PERMISSIONS.get(t["name"], PermissionMode.SAFE)
        color = {
            PermissionMode.SAFE: SUCCESS,
            PermissionMode.MODERATE: WARNING,
            PermissionMode.DANGEROUS: ERROR_C,
        }[perm]
        console.print(f"  [{color}]{t['name']:<22}[/] [{MUTED}]{t.get('description','')[:50]}[/]")
    console.print()

def show_models(cfg: dict):
    from .router import router, PROVIDERS
    rows = router.get_status_table(cfg)
    table = Table(box=box.SIMPLE, show_header=True, padding=(0,2))
    table.add_column("Provider", style=ACCENT)
    table.add_column("Model", style=PRIMARY)
    table.add_column("Status", style=MUTED)
    for r in rows:
        status_color = {
            "available": SUCCESS,
            "no_key": MUTED,
            "rate_limited": WARNING,
            "failed": ERROR_C,
        }.get(r["status"], MUTED)
        table.add_row(
            r["provider"],
            r["model"],
            f"[{status_color}]{r['status']}[/]"
        )
    console.print(table)

def show_keys(cfg: dict):
    from .router import PROVIDERS
    console.print(f"\n  [{ACCENT}]API Keys[/]\n")
    for pid in PROVIDERS:
        keys = cfg.get("keys", {}).get(pid, [])
        if keys:
            masked = keys[0][:8] + "..." + keys[0][-4:]
            console.print(f"  [{SUCCESS}]v[/] [{ACCENT}]{pid:<12}[/] [{MUTED}]{masked}[/]")
        else:
            console.print(f"  [{MUTED}]  {pid:<12} not set[/]")
    console.print()

def configure_api_keys(cfg: dict) -> dict:
    from .router import PROVIDERS
    console.print(f"\n  [{ACCENT}]Configure API Keys[/]")
    console.print(f"  [{MUTED}]Press Enter to skip a provider[/]\n")
    for pid, pinfo in PROVIDERS.items():
        existing = cfg.get("keys", {}).get(pid, [])
        hint = f" (current: ...{existing[0][-4:]})" if existing else ""
        key = Prompt.ask(
            f"  [{ACCENT}]{pinfo['name']}[/] [{MUTED}]{hint}[/]",
            default="", password=True
        )
        if key.strip():
            cfg.setdefault("keys", {}).setdefault(pid, [])
            if key not in cfg["keys"][pid]:
                cfg["keys"][pid].insert(0, key)
    return cfg

def pick_provider_and_model(current_provider: str, current_model: str, cfg: dict):
    from .router import PROVIDERS
    providers = list(PROVIDERS.keys())
    console.print(f"\n  [{ACCENT}]Select Provider[/]\n")
    for i, pid in enumerate(providers, 1):
        marker = ">" if pid == current_provider else " "
        has_key = bool(cfg.get("keys", {}).get(pid))
        key_status = f"[{SUCCESS}]key set[/]" if has_key else f"[{MUTED}]no key[/]"
        console.print(f"  {marker} [{ACCENT}]{i}.[/] {pid:<12} {key_status}")
    console.print()
    choice = Prompt.ask("  Provider number", default="1")
    try:
        provider = providers[int(choice) - 1]
    except Exception:
        provider = current_provider

    pinfo = PROVIDERS[provider]
    models = pinfo["models"]
    console.print(f"\n  [{ACCENT}]Select Model ({provider})[/]\n")
    for i, m in enumerate(models, 1):
        marker = ">" if m == current_model else " "
        console.print(f"  {marker} [{PRIMARY}]{i}.[/] {m}")
    console.print()
    mchoice = Prompt.ask("  Model number", default="1")
    try:
        model = models[int(mchoice) - 1]
    except Exception:
        model = pinfo["default"]

    return provider, model

def prompt_input(cwd: str, cfg: dict = None) -> str:
    import subprocess
    branch = ""
    try:
        b = subprocess.check_output(
            ["git", "branch", "--show-current"],
            cwd=cwd, stderr=subprocess.DEVNULL
        ).decode().strip()
        if b:
            branch = f" ({b})"
    except Exception:
        pass
    # Status bar
    if cfg:
        from .cost import get_session_stats
        stats = get_session_stats()
        provider = cfg.get("provider", "")
        model = cfg.get("model", "").split("-")[0]
        cost = f"${stats['cost']:.4f}" if stats["cost"] > 0 else ""
        msgs = stats.get("total_tokens", 0)
        cost_str = f"  [{MUTED}]{cost}[/]" if cost else ""
        sep = "─" * 40
        console.print(
            f"  [{MUTED}]{sep}[/]\n"
            f"  [{ACCENT}]{provider}[/][{MUTED}]/{model}[/]"
            f"  [{MUTED}]tokens:{msgs:,}[/]{cost_str}"
        )
    try:
        from prompt_toolkit import prompt as pt_prompt
        from prompt_toolkit.styles import Style
        style = Style.from_dict({"prompt": "#8BE9FD bold"})
        short_cwd = cwd.replace(str(__import__("pathlib").Path.home()), "~")
        result = pt_prompt(f"  {short_cwd}{branch} > ", style=style)
        return result
    except Exception:
        short = cwd.replace(os.path.expanduser("~"), "~")
        return Prompt.ask(f"  [{MUTED}]{short}{branch}[/] [{ACCENT}]>[/]")


def show_diff_preview(path: str, original: str, modified: str) -> bool:
    """Show diff and ask user to apply or skip."""
    import difflib
    diff = list(difflib.unified_diff(
        original.splitlines(keepends=True),
        modified.splitlines(keepends=True),
        fromfile=f"  {path} (before)",
        tofile=f"  {path} (after)",
        lineterm=""
    ))
    if not diff:
        console.print(f"  [{MUTED}]No changes.[/]")
        return False
    console.print(f"\n  [{ACCENT}]Changes to {escape(path)}:[/]\n")
    for line in diff[:40]:
        if line.startswith("+++") or line.startswith("---"):
            console.print(f"  [{MUTED}]{escape(line)}[/]")
        elif line.startswith("+"):
            console.print(f"  [{SUCCESS}]{escape(line)}[/]")
        elif line.startswith("-"):
            console.print(f"  [{ERROR_C}]{escape(line)}[/]")
        elif line.startswith("@@"):
            console.print(f"  [{ACCENT}]{escape(line)}[/]")
        else:
            console.print(f"  [{MUTED}]{escape(line)}[/]")
    if len(diff) > 40:
        console.print(f"  [{MUTED}]  ... {len(diff)-40} more lines[/]")
    console.print()
    return Confirm.ask(f"  [{WARNING}]Apply changes?[/]", default=True)

def show_agent_start(agent: str, task_id: str, prompt: str):
    console.print(f"\n  [{AGENT_C}]agent {agent}[/] [{MUTED}]starting: {escape(prompt[:60])}[/]")

def show_agent_done(agent: str, task_id: str):
    console.print(f"  [{SUCCESS}]v[/] [{AGENT_C}]{agent}[/] [{MUTED}]done[/]")

def show_agent_error(agent: str, task_id: str, error: str):
    console.print(f"  [{ERROR_C}]x[/] [{AGENT_C}]{agent}[/] [{ERROR_C}]{escape(error[:80])}[/]")

def show_orchestration_plan(tasks: list):
    console.print(f"\n  [{ACCENT}]Orchestration Plan[/]\n")
    for t in tasks:
        deps = ", ".join(t.get("depends_on", [])) or "none"
        console.print(
            f"  [{PRIMARY}]{t['id']}[/] [{AGENT_C}]{t['agent']}[/] "
            f"[{MUTED}]deps:{deps}[/]"
        )
        console.print(f"    [{MUTED}]{t['prompt'][:70]}[/]")
    console.print()
