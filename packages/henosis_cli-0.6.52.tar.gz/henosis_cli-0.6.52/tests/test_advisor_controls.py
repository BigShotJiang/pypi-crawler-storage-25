from types import SimpleNamespace

from app.controls import L1, available_tools_for
from app.routers import chat as chat_router
from app.tools.file_tools import FileToolPolicy


def _names(tools):
    return {t.get("name") for t in tools if isinstance(t, dict)}


def test_advisor_tool_available_even_when_file_tools_disabled():
    names = _names(
        available_tools_for(
            L1,
            tools_enabled=False,
            browser_tools_enabled=False,
            advisor_enabled=True,
        )
    )
    assert "advisor" in names
    assert "read_file" not in names
    assert "browser_session" not in names


def test_advisor_tool_available_at_level_three_even_when_file_tools_disabled():
    names = _names(
        available_tools_for(
            3,
            tools_enabled=False,
            browser_tools_enabled=False,
            advisor_enabled=True,
        )
    )
    assert "advisor" in names


def test_execute_server_only_tool_result_runs_advisor_and_updates_usage(monkeypatch, tmp_path):
    captured = {}

    def fake_build_prompt(**kwargs):
        captured.update(kwargs)
        return "advisor transcript"

    def fake_invoke(config, transcript):
        assert transcript == "advisor transcript"
        return SimpleNamespace(
            ok=True,
            text="advisor says hi",
            advisor_model=config.advisor_model,
            reasoning_effort=config.reasoning_effort,
            usage={"input_tokens": 11, "output_tokens": 7, "total_tokens": 18},
            cost_usd=0.123,
        )

    monkeypatch.setattr(chat_router, "build_advisor_prompt", fake_build_prompt)
    monkeypatch.setattr(chat_router, "invoke_advisor", fake_invoke)

    advisor_state = chat_router._new_advisor_state()
    config = SimpleNamespace(enabled=True, advisor_model="gpt-5.5", reasoning_effort="xhigh", max_uses=2)
    policy = FileToolPolicy(scope="workspace", workspace_base=tmp_path)

    result = chat_router._execute_server_only_tool_result(
        name="advisor",
        args_payload={},
        file_policy=policy,
        advisor_config=config,
        advisor_state=advisor_state,
        system_prompt="system prompt",
        conversation_items=[{"role": "user", "content": "hello"}],
        model_name="claude-sonnet-4-6",
        provider_name="anthropic",
        tools_enabled=True,
        control_level=2,
    )

    assert result["ok"] is True
    assert result["data"]["text"] == "advisor says hi"
    assert advisor_state["calls"] == 1
    assert advisor_state["usage"] == {"input_tokens": 11, "output_tokens": 7, "total_tokens": 18}
    assert advisor_state["cost_usd"] == 0.123
    assert captured["provider_name"] == "anthropic"
    assert captured["model_name"] == "claude-sonnet-4-6"


def test_execute_server_only_tool_result_enforces_advisor_max_uses(tmp_path):
    advisor_state = {"calls": 1, "usage": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}, "cost_usd": 0.0}
    config = SimpleNamespace(enabled=True, advisor_model="gpt-5.5", reasoning_effort="xhigh", max_uses=1)
    policy = FileToolPolicy(scope="workspace", workspace_base=tmp_path)

    result = chat_router._execute_server_only_tool_result(
        name="advisor",
        args_payload={},
        file_policy=policy,
        advisor_config=config,
        advisor_state=advisor_state,
        system_prompt="",
        conversation_items=[],
        model_name="gpt-5.4",
        provider_name="openai",
        tools_enabled=True,
        control_level=3,
    )

    assert result["ok"] is False
    assert result["error_code"] == "advisor_max_uses_reached"
    assert advisor_state["calls"] == 1
