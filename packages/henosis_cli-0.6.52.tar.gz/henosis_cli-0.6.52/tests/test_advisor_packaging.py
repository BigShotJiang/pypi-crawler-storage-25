import asyncio
import builtins
import importlib
import sys
import uuid
from pathlib import Path
from types import SimpleNamespace


def _new_local_tmp() -> Path:
    base = Path.cwd() / ".pytest_local_tmp"
    base.mkdir(parents=True, exist_ok=True)
    p = base / f"advisor-packaging-{uuid.uuid4().hex[:10]}"
    p.mkdir(parents=True, exist_ok=False)
    return p


def _reload_cli_with_missing_backend_advisor(monkeypatch):
    original_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "app.services.advisor":
            raise ImportError("simulated missing backend advisor module")
        if name == "app.services" and fromlist and "advisor" in fromlist:
            raise ImportError("simulated missing backend advisor module")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", guarded_import)
    sys.modules.pop("cli", None)
    return importlib.import_module("cli")


def _make_cli(cli_mod, tmp_path: Path):
    cli = cli_mod.ChatCLI(
        server="http://127.0.0.1:8000/api",
        model=None,
        system_prompt=None,
        timeout=5.0,
        map_prefix=False,
        log_enabled=False,
        save_to_threads=False,
        server_usage_commit=False,
        verbose=False,
    )
    cli.codex_auth_file = tmp_path / "henosis_cli_codex_auth.json"
    cli.codex_shared_auth_file = tmp_path / "codex_shared_auth" / "auth.json"
    cli._clear_codex_auth_state_on_disk(clear_shared=False)
    return cli


def test_cli_uses_packaged_advisor_helpers_when_backend_module_is_missing(monkeypatch):
    cli_mod = _reload_cli_with_missing_backend_advisor(monkeypatch)

    assert cli_mod.HAS_LOCAL_ADVISOR is True
    assert cli_mod.local_build_advisor_prompt.__module__ == "henosis_cli_tools.advisor"
    assert cli_mod.local_invoke_advisor.__module__ == "henosis_cli_tools.advisor"
    assert cli_mod.local_resolve_advisor_config.__module__ == "henosis_cli_tools.advisor"


def test_codex_local_advisor_byok_does_not_require_backend_settings(monkeypatch):
    cli_mod = importlib.import_module("cli")
    tmp_path = _new_local_tmp()
    cli = _make_cli(cli_mod, tmp_path)

    captured = {}

    def fake_invoke(cfg, transcript, *, api_key=None):
        captured["advisor_model"] = cfg.advisor_model
        captured["reasoning_effort"] = cfg.reasoning_effort
        captured["transcript"] = transcript
        captured["api_key"] = api_key
        return SimpleNamespace(
            ok=True,
            text="advisor from byok",
            advisor_model=cfg.advisor_model,
            reasoning_effort=cfg.reasoning_effort,
            usage={"input_tokens": 7, "output_tokens": 3, "total_tokens": 10},
            cost_usd=0.01,
        )

    class _Hub:
        def get_provider_key(self, provider):
            return "sk-test-openai" if provider == "openai" else None

    original_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "app.settings":
            raise ImportError("simulated missing backend settings module")
        if name == "app" and fromlist and "settings" in fromlist:
            raise ImportError("simulated missing backend settings module")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(cli_mod, "local_invoke_advisor", fake_invoke)
    monkeypatch.setattr(builtins, "__import__", guarded_import)

    cli.access_hub = _Hub()
    cfg = SimpleNamespace(advisor_model="gpt-5.5", reasoning_effort="xhigh")

    result = asyncio.run(cli._invoke_advisor_via_byok(cfg, "advisor transcript"))

    assert result["ok"] is True
    assert captured == {
        "advisor_model": "gpt-5.5",
        "reasoning_effort": "xhigh",
        "transcript": "advisor transcript",
        "api_key": "sk-test-openai",
    }
    assert result["data"]["auth_mode"] == cli_mod.AUTH_MODE_BYOK
