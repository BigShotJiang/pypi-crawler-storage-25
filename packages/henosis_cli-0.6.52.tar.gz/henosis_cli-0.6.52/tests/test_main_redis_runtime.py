import asyncio

import app.main as main_mod


class _FakeRedis:
    pass


async def _no_redis():
    return None


async def _has_redis():
    return _FakeRedis()


def test_redis_not_required_for_plain_local_runtime(monkeypatch):
    monkeypatch.setattr(main_mod.settings, "REQUIRE_REDIS", False, raising=False)
    monkeypatch.setattr(main_mod.settings, "DEPLOY_COLOR", None, raising=False)
    monkeypatch.setattr(main_mod.settings, "ENVIRONMENT", "development", raising=False)
    monkeypatch.setattr(main_mod, "get_redis", _no_redis)

    asyncio.run(main_mod._ensure_runtime_redis_ready())


def test_redis_required_for_blue_green_runtime(monkeypatch):
    monkeypatch.setattr(main_mod.settings, "REQUIRE_REDIS", False, raising=False)
    monkeypatch.setattr(main_mod.settings, "DEPLOY_COLOR", "green", raising=False)
    monkeypatch.setattr(main_mod.settings, "ENVIRONMENT", "development", raising=False)
    monkeypatch.setattr(main_mod, "get_redis", _no_redis)

    try:
        asyncio.run(main_mod._ensure_runtime_redis_ready())
    except RuntimeError as exc:
        assert "Redis is required" in str(exc)
    else:
        raise AssertionError("Expected RuntimeError when Redis is missing for a deploy color runtime")


def test_redis_required_flag_honored(monkeypatch):
    monkeypatch.setattr(main_mod.settings, "REQUIRE_REDIS", True, raising=False)
    monkeypatch.setattr(main_mod.settings, "DEPLOY_COLOR", None, raising=False)
    monkeypatch.setattr(main_mod.settings, "ENVIRONMENT", "development", raising=False)
    monkeypatch.setattr(main_mod, "get_redis", _no_redis)

    try:
        asyncio.run(main_mod._ensure_runtime_redis_ready())
    except RuntimeError as exc:
        assert "Redis is required" in str(exc)
    else:
        raise AssertionError("Expected RuntimeError when REQUIRE_REDIS is enabled and Redis is missing")


def test_redis_ready_passes_when_available(monkeypatch):
    monkeypatch.setattr(main_mod.settings, "REQUIRE_REDIS", True, raising=False)
    monkeypatch.setattr(main_mod.settings, "DEPLOY_COLOR", "green", raising=False)
    monkeypatch.setattr(main_mod.settings, "ENVIRONMENT", "production", raising=False)
    monkeypatch.setattr(main_mod, "get_redis", _has_redis)

    asyncio.run(main_mod._ensure_runtime_redis_ready())
