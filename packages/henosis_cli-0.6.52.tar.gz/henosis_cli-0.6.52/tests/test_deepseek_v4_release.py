from app.routers import chat as chat_router
from app.routers import chat_adapter
from app.routers import media as media_router


def test_deepseek_v4_reasoning_request_defaults_to_thinking_high():
    payload = chat_router._deepseek_reasoning_request_fields(None)
    assert payload == {
        "thinking": {"type": "enabled"},
        "reasoning_effort": "high",
    }


def test_deepseek_v4_reasoning_request_maps_compatibility_levels():
    assert chat_router._deepseek_reasoning_request_fields("low") == {
        "thinking": {"type": "enabled"},
        "reasoning_effort": "high",
    }
    assert chat_router._deepseek_reasoning_request_fields("medium") == {
        "thinking": {"type": "enabled"},
        "reasoning_effort": "high",
    }
    assert chat_router._deepseek_reasoning_request_fields("high") == {
        "thinking": {"type": "enabled"},
        "reasoning_effort": "high",
    }
    assert chat_router._deepseek_reasoning_request_fields("xhigh") == {
        "thinking": {"type": "enabled"},
        "reasoning_effort": "max",
    }


def test_deepseek_v4_reasoning_request_supports_non_thinking_mode():
    payload = chat_router._deepseek_reasoning_request_fields("none")
    assert payload == {"thinking": {"type": "disabled"}}



def test_deepseek_v4_model_aliases_are_supported():
    assert chat_adapter._deepseek_ui_to_api_slug("deepseek-v4-pro") == "deepseek-v4-pro"
    assert chat_adapter._deepseek_ui_to_api_slug("deepseek-v4-flash") == "deepseek-v4-flash"



def test_deepseek_v4_model_capabilities_are_exposed():
    payload = media_router.model_capabilities()
    providers = payload.get("providers") or []
    deepseek = next(p for p in providers if p.get("name") == "deepseek")
    model_ids = {m.get("id") for m in (deepseek.get("models") or [])}
    assert "deepseek-v4-pro" in model_ids
    assert "deepseek-v4-flash" in model_ids
    assert "deepseek-chat" not in model_ids
