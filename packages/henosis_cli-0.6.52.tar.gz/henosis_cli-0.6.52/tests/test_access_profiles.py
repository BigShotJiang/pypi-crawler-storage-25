from henosis_cli_tools.access_profiles import (
    AccessProfile,
    ExecutionAdapter,
    ModelCapabilityInfo,
    ProfileCapabilities,
    ProfileReadinessStatus,
)
from henosis_cli_tools.access_hub import AccessHub


class _FakeAdapter:
    profile_id = "sub:github_copilot"

    def list_available_models(self):
        return [ModelCapabilityInfo(model_id="claude-sonnet-4", provider_family="anthropic")]

    def supports_model(self, model_id: str) -> bool:
        return model_id == "claude-sonnet-4"

    def get_model_capabilities(self, model_id: str):
        if not self.supports_model(model_id):
            return None
        return ModelCapabilityInfo(model_id=model_id, provider_family="anthropic", supports_tools=True)

    def get_readiness_status(self):
        return ProfileReadinessStatus(
            state="ready",
            ready=True,
            installed=True,
            authenticated=True,
            subscription_usable=True,
            model_available=True,
        )

    def execute_turn(self, *, model_id: str, prompt: str, cwd=None):
        return {"ok": True, "text": f"ran:{model_id}:{prompt}", "usage": {}, "model": model_id}


def test_access_profile_contract_shapes_are_instantiable():
    profile = AccessProfile(
        profile_id="oauth:codex",
        kind="oauth",
        display_name="Codex OAuth",
        provider_families_supported=["openai"],
        billing_source="oauth_codex",
        execution_backend="local_http",
        capabilities=ProfileCapabilities(
            supports_streaming=True,
            supports_tool_calling=True,
            supports_context_handoff=True,
        ),
    )

    assert profile.profile_id == "oauth:codex"
    assert profile.capabilities.supports_streaming is True
    assert profile.billing_source == "oauth_codex"


def test_execution_adapter_protocol_supports_phase_zero_contract():
    adapter = _FakeAdapter()

    assert isinstance(adapter, ExecutionAdapter)
    assert adapter.supports_model("claude-sonnet-4") is True
    assert adapter.supports_model("gpt-5.4") is False
    assert adapter.get_model_capabilities("claude-sonnet-4").supports_tools is True
    assert adapter.get_readiness_status().ready is True


def test_codex_adapter_supports_gpt_55_codex_local_model():
    from henosis_cli_tools.access_adapters.codex import CodexOAuthAdapter

    adapter = CodexOAuthAdapter()

    assert adapter.supports_model("gpt-5.5") is True
    models = {m.model_id: m for m in adapter.list_available_models()}
    assert "gpt-5.5" in models
    assert models["gpt-5.5"].max_context_tokens == 400000
    assert adapter.get_model_capabilities("gpt-5.5").max_context_tokens == 400000


def test_access_hub_registers_subscription_adapter_scaffolds(tmp_path):
    hub = AccessHub(routes_path=tmp_path / "routes.json", keys_path=tmp_path / "keys.json")

    known_profiles = {profile.profile_id: profile for profile in hub.list_known_profiles()}

    assert "sub:github_copilot" in known_profiles
    assert "sub:droid" in known_profiles
    assert known_profiles["sub:github_copilot"].billing_source == "sub_github_copilot"
    assert known_profiles["sub:droid"].capabilities.supports_jsonrpc is True

    gh_status = hub.get_profile_readiness("sub:github_copilot")
    droid_status = hub.get_profile_readiness("sub:droid")

    # Readiness depends on developer-machine PATH/env.  The scaffold contract is
    # that the adapters return a concrete readiness status without crashing.
    assert gh_status.state in {"not_installed", "misconfigured", "ready", "unknown"}
    assert droid_status.state in {"not_installed", "misconfigured", "ready", "unknown"}


def test_access_hub_available_auth_modes_for_model_prefers_supported_subscription_profiles(tmp_path, monkeypatch):
    monkeypatch.setenv("HENOSIS_ENABLE_EXPERIMENTAL_SUB_ROUTES", "1")
    hub = AccessHub(routes_path=tmp_path / "routes.json", keys_path=tmp_path / "keys.json")

    gh = hub.get_execution_adapter("sub:github_copilot")
    droid = hub.get_execution_adapter("sub:droid")
    monkeypatch.setattr(gh, "supports_model", lambda model_id: model_id in {"gpt-5.4", "claude-sonnet-4-6"})
    monkeypatch.setattr(droid, "supports_model", lambda model_id: model_id in {"claude-sonnet-4-6", "deepseek-chat-3.2"})

    assert "github_copilot_sub" in hub.available_auth_modes_for_model("gpt-5.4")
    assert "github_copilot_sub" in hub.available_auth_modes_for_model("claude-sonnet-4-6")
    assert "droid_sub" in hub.available_auth_modes_for_model("claude-sonnet-4-6")


def test_access_hub_hides_subscription_auth_modes_by_default(tmp_path):
    hub = AccessHub(routes_path=tmp_path / "routes.json", keys_path=tmp_path / "keys.json")

    assert "github_copilot_sub" not in hub.available_auth_modes_for_model("gpt-5.4")
    assert "github_copilot_sub" not in hub.available_auth_modes_for_model("claude-sonnet-4-6")
    assert "droid_sub" not in hub.available_auth_modes_for_model("claude-sonnet-4-6")
