"""
henosis_cli_tools
-----------------
Reusable, policy-aware local machine tools extracted from the server.

Exports:
- FileToolPolicy: sandbox/scope configuration
- resolve_path: path resolution and sandbox enforcement
- read_text_auto: BOM/encoding-aware text reader
- read_file, write_file, append_file, list_dir
- run_command: safe command execution with allowlist and timeout
- spawn_command, process_list, process_status, process_output, wait_process, terminate_process
- spawn_terminal, terminal_list, terminal_snapshot, terminal_input, terminal_resize, terminal_close
- apply_patch: simplified multi-file patch applier

These functions are framework-agnostic and can be used by both the
FastAPI server and the standalone CLI.

Also exports:
- SettingsUI: dependency-free interactive settings UI used by henosis-cli.
"""

from .tool_impl import (
    FileToolPolicy,
    resolve_path,
    read_text_auto,
    read_file,
    write_file,
    append_file,
    list_dir,
    run_command,
    run_shell,
    spawn_command,
    process_list,
    process_status,
    process_output,
    wait_process,
    terminate_process,
    spawn_terminal,
    terminal_list,
    terminal_snapshot,
    terminal_input,
    terminal_resize,
    terminal_close,
    apply_patch,
    string_replace,
)
from .browser_impl import (
    BROWSER_TOOL_NAMES,
    BrowserPolicyError,
    browser_tool_requires_approval,
    execute_browser_tool,
    is_browser_tool,
)
from .advisor import (
    AdvisorConfig,
    AdvisorEffort,
    AdvisorInvocationResult,
    build_advisor_prompt,
    invoke_advisor,
    resolve_advisor_config,
)
from .settings_ui import SettingsUI
from .access_profiles import (
    AccessProfile,
    ExecutionAdapter,
    ModelCapabilityInfo,
    ProfileCapabilities,
    ProfileReadinessStatus,
)


_OPTIONAL_ACCESS_EXPORTS = []

try:
    from .access_hub import AccessHub
    from .access_hub import (
        AUTH_MODE_DROID_SUB,
        AUTH_MODE_GITHUB_SUB,
        PROFILE_ID_BACKEND,
        PROFILE_ID_CODEX,
        byok_profile_id_for_provider,
        default_access_profile_for_mode,
        default_profile_id_for_mode,
    )

    _OPTIONAL_ACCESS_EXPORTS.extend(
        [
            "AccessHub",
            "AUTH_MODE_DROID_SUB",
            "AUTH_MODE_GITHUB_SUB",
            "PROFILE_ID_BACKEND",
            "PROFILE_ID_CODEX",
            "byok_profile_id_for_provider",
            "default_access_profile_for_mode",
            "default_profile_id_for_mode",
        ]
    )
except Exception:
    # Access-routing helpers are optional for core CLI startup. Keeping these
    # imports non-fatal prevents the entrypoint wrapper from crashing when a
    # wheel is missing an optional subpackage.
    pass

try:
    from .access_adapters import (
        BackendHenosisAdapter,
        CodexOAuthAdapter,
        DroidAdapter,
        GitHubCopilotAdapter,
    )

    _OPTIONAL_ACCESS_EXPORTS.extend(
        [
            "BackendHenosisAdapter",
            "CodexOAuthAdapter",
            "DroidAdapter",
            "GitHubCopilotAdapter",
        ]
    )
except Exception:
    pass

__all__ = [
    "FileToolPolicy",
    "resolve_path",
    "read_text_auto",
    "read_file",
    "write_file",
    "append_file",
    "list_dir",
    "run_command",
    "run_shell",
    "spawn_command",
    "process_list",
    "process_status",
    "process_output",
    "wait_process",
    "terminate_process",
    "spawn_terminal",
    "terminal_list",
    "terminal_snapshot",
    "terminal_input",
    "terminal_resize",
    "terminal_close",
    "apply_patch",
    "string_replace",
    "BROWSER_TOOL_NAMES",
    "BrowserPolicyError",
    "browser_tool_requires_approval",
    "execute_browser_tool",
    "is_browser_tool",
    "AdvisorConfig",
    "AdvisorEffort",
    "AdvisorInvocationResult",
    "build_advisor_prompt",
    "invoke_advisor",
    "resolve_advisor_config",
    "SettingsUI",
    "AccessProfile",
    "ExecutionAdapter",
    "ModelCapabilityInfo",
    "ProfileCapabilities",
    "ProfileReadinessStatus",
] + _OPTIONAL_ACCESS_EXPORTS
