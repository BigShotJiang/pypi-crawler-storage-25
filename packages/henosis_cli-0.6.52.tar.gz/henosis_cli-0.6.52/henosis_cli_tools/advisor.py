from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Literal, Optional


AdvisorEffort = Literal["low", "medium", "high", "xhigh"]

_DEFAULT_ADVISOR_MODEL = "gpt-5.5"
_DEFAULT_REASONING_EFFORT: AdvisorEffort = "xhigh"
_DEFAULT_AUTH_MODE = "auto"
_DEFAULT_MAX_USES = 2
_DEFAULT_TIMEOUT_SEC = 120
_DEFAULT_SUMMARY_VERBOSITY = "concise"
_DEFAULT_MAX_PROMPT_TOKENS = 200000


def _classify_advisor_error_code(error: Any) -> str:
    try:
        text = str(error or "").strip().lower()
    except Exception:
        text = ""
    if not text:
        return "advisor_error"
    if (
        "model_not_found" in text
        or "does not exist" in text
        or "unknown model" in text
        or "unsupported model" in text
        or "not a valid model" in text
    ):
        return "advisor_model_unavailable"
    if "api key" in text and ("missing" in text or "not set" in text):
        return "missing_openai_api_key"
    return "advisor_error"


@dataclass
class AdvisorConfig:
    enabled: bool
    advisor_model: str
    reasoning_effort: AdvisorEffort
    auth_mode: str
    max_uses: int
    timeout_sec: int


@dataclass
class AdvisorInvocationResult:
    ok: bool
    text: str
    advisor_model: str
    reasoning_effort: AdvisorEffort
    usage: Dict[str, Any]
    cost_usd: float
    error: Optional[str] = None
    error_code: Optional[str] = None


def _setting_value(runtime_settings: Any, key: str, default: Any) -> Any:
    try:
        value = getattr(runtime_settings, key)
    except Exception:
        value = default
    return default if value is None else value


def resolve_advisor_config(body: Any, runtime_settings: Any = None) -> AdvisorConfig:
    enabled_default = bool(_setting_value(runtime_settings, "ENABLE_ADVISOR_DEFAULT", True))
    enabled = (
        bool(getattr(body, "enable_advisor", None))
        if getattr(body, "enable_advisor", None) is not None
        else enabled_default
    )

    advisor_model = str(
        getattr(body, "advisor_model", None)
        or _setting_value(runtime_settings, "ADVISOR_DEFAULT_MODEL", _DEFAULT_ADVISOR_MODEL)
        or _DEFAULT_ADVISOR_MODEL
    ).strip() or _DEFAULT_ADVISOR_MODEL

    effort_raw = str(
        getattr(body, "advisor_reasoning_effort", None)
        or _setting_value(runtime_settings, "ADVISOR_DEFAULT_REASONING_EFFORT", _DEFAULT_REASONING_EFFORT)
        or _DEFAULT_REASONING_EFFORT
    ).strip().lower()
    reasoning_effort: AdvisorEffort = effort_raw if effort_raw in {"low", "medium", "high", "xhigh"} else _DEFAULT_REASONING_EFFORT

    try:
        max_uses = int(
            getattr(body, "advisor_max_uses", None)
            if getattr(body, "advisor_max_uses", None) is not None
            else _setting_value(runtime_settings, "ADVISOR_MAX_USES_DEFAULT", _DEFAULT_MAX_USES)
        )
    except Exception:
        max_uses = _DEFAULT_MAX_USES
    if max_uses < 0:
        max_uses = 0

    try:
        timeout_sec = int(_setting_value(runtime_settings, "ADVISOR_TIMEOUT_SEC", _DEFAULT_TIMEOUT_SEC) or _DEFAULT_TIMEOUT_SEC)
    except Exception:
        timeout_sec = _DEFAULT_TIMEOUT_SEC
    if timeout_sec <= 0:
        timeout_sec = _DEFAULT_TIMEOUT_SEC

    auth_mode = str(
        getattr(body, "advisor_auth_mode", None)
        or _setting_value(runtime_settings, "ADVISOR_DEFAULT_AUTH_MODE", _DEFAULT_AUTH_MODE)
        or _DEFAULT_AUTH_MODE
    ).strip().lower()
    if auth_mode == "codex":
        auth_mode = "codex_oauth"
    if auth_mode not in {"auto", "codex_oauth", "backend", "byok"}:
        auth_mode = _DEFAULT_AUTH_MODE

    return AdvisorConfig(
        enabled=enabled,
        advisor_model=advisor_model,
        reasoning_effort=reasoning_effort,
        auth_mode=auth_mode,
        max_uses=max_uses,
        timeout_sec=timeout_sec,
    )


def _clip_text(text: str, max_chars: int) -> str:
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    keep = max(0, max_chars - len("\n...[truncated]"))
    return text[:keep].rstrip() + "\n...[truncated]"


def _flatten_lines(values: Iterable[str]) -> str:
    out: List[str] = []
    for item in values:
        if not isinstance(item, str):
            continue
        s = item.strip()
        if not s:
            continue
        out.append(s)
    return "\n".join(out)


def build_advisor_prompt(
    *,
    system_prompt: str,
    conversation_items: Any,
    tool_constraints_text: str = "",
    model_name: Optional[str] = None,
    provider_name: Optional[str] = None,
    summary_verbosity: Optional[str] = None,
    max_prompt_tokens: Optional[int] = None,
) -> str:
    try:
        prompt_cap = int(max_prompt_tokens or _DEFAULT_MAX_PROMPT_TOKENS)
    except Exception:
        prompt_cap = _DEFAULT_MAX_PROMPT_TOKENS
    max_chars = max(2000, int(prompt_cap * 4))

    transcript_text = ""
    try:
        transcript_text = json.dumps(conversation_items or [], ensure_ascii=False, indent=2, default=str)
    except Exception:
        transcript_text = str(conversation_items or "")
    transcript_text = _clip_text(transcript_text, max_chars=max_chars)

    verbosity = str(summary_verbosity or _DEFAULT_SUMMARY_VERBOSITY).strip().lower()
    if verbosity not in {"concise", "medium", "detailed"}:
        verbosity = _DEFAULT_SUMMARY_VERBOSITY

    sections = [
        "You are a strategic coding/task advisor.",
        "Give practical next-step guidance to the executor model.",
        f"Preferred verbosity: {verbosity}.",
        "Prefer enumerated steps when useful.",
        "Do not restate the full transcript unless necessary.",
    ]
    meta_lines = _flatten_lines(
        [
            f"Executor model: {model_name}" if model_name else "",
            f"Executor provider: {provider_name}" if provider_name else "",
        ]
    )
    if meta_lines:
        sections.append("\n## Metadata\n" + meta_lines)
    if system_prompt:
        sections.append("\n## System prompt\n" + _clip_text(system_prompt, max_chars=max(1000, max_chars // 6)))
    if tool_constraints_text:
        sections.append("\n## Tool constraints\n" + _clip_text(tool_constraints_text, max_chars=max(1000, max_chars // 8)))
    sections.append("\n## Normalized transcript\n" + transcript_text)
    sections.append(
        "\n## Task\n"
        "Return concise, actionable advice for what the executor model should do next. "
        "Call out key risks, missing information, and a suggested next sequence of actions."
    )
    return "\n".join(sections).strip()


def _advisor_cost_usd(model: str, input_tokens: int, output_tokens: int) -> float:
    model_l = str(model or "").strip().lower()
    if model_l.startswith("gpt-5.5"):
        in_rate = 5.0
        out_rate = 30.0
    else:
        in_rate = 2.75
        out_rate = 15.25
    return ((max(0, int(input_tokens)) / 1_000_000.0) * in_rate) + ((max(0, int(output_tokens)) / 1_000_000.0) * out_rate)


def invoke_advisor(
    config: AdvisorConfig,
    transcript: str,
    *,
    api_key: Optional[str] = None,
) -> AdvisorInvocationResult:
    if not config.enabled:
        return AdvisorInvocationResult(
            ok=False,
            text="",
            advisor_model=config.advisor_model,
            reasoning_effort=config.reasoning_effort,
            usage={},
            cost_usd=0.0,
            error="advisor is disabled",
            error_code="advisor_disabled",
        )
    if not (isinstance(api_key, str) and api_key.strip()):
        return AdvisorInvocationResult(
            ok=False,
            text="",
            advisor_model=config.advisor_model,
            reasoning_effort=config.reasoning_effort,
            usage={},
            cost_usd=0.0,
            error="OPENAI_API_KEY is not set",
            error_code="missing_openai_api_key",
        )

    try:
        from openai import OpenAI
    except Exception as e:
        return AdvisorInvocationResult(
            ok=False,
            text="",
            advisor_model=config.advisor_model,
            reasoning_effort=config.reasoning_effort,
            usage={},
            cost_usd=0.0,
            error=f"openai package is not installed: {e}",
            error_code="advisor_unavailable",
        )

    client = OpenAI(api_key=api_key.strip(), timeout=float(config.timeout_sec))
    try:
        req: Dict[str, Any] = {
            "model": config.advisor_model,
            "input": [
                {
                    "role": "user",
                    "content": transcript,
                }
            ],
        }
        if config.reasoning_effort in {"low", "medium", "high", "xhigh"}:
            req["reasoning"] = {"effort": config.reasoning_effort}
        resp = client.responses.create(**req)
        text = str(getattr(resp, "output_text", "") or "")
        usage_obj = getattr(resp, "usage", None)
        usage: Dict[str, Any] = {}
        if usage_obj is not None:
            try:
                input_tokens = int(getattr(usage_obj, "input_tokens", 0) or 0)
            except Exception:
                input_tokens = 0
            try:
                output_tokens = int(getattr(usage_obj, "output_tokens", 0) or 0)
            except Exception:
                output_tokens = 0
            usage = {
                "input_tokens": int(input_tokens),
                "output_tokens": int(output_tokens),
                "total_tokens": int(getattr(usage_obj, "total_tokens", (input_tokens + output_tokens)) or (input_tokens + output_tokens)),
            }
        else:
            input_tokens = 0
            output_tokens = 0
        return AdvisorInvocationResult(
            ok=True,
            text=text,
            advisor_model=config.advisor_model,
            reasoning_effort=config.reasoning_effort,
            usage=usage,
            cost_usd=_advisor_cost_usd(config.advisor_model, input_tokens, output_tokens),
        )
    except Exception as e:
        return AdvisorInvocationResult(
            ok=False,
            text="",
            advisor_model=config.advisor_model,
            reasoning_effort=config.reasoning_effort,
            usage={},
            cost_usd=0.0,
            error=str(e),
            error_code=_classify_advisor_error_code(e),
        )
