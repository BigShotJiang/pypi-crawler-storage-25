from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import List, Optional

from ..access_profiles import ModelCapabilityInfo, ProfileReadinessStatus
from ._subprocess_bridge import _parse_execution_output, _prepare_command, _run_command, _split_models_csv


class DroidAdapter:
    profile_id = "sub:droid"
    billing_source = "sub_droid"
    _fallback_models = [
        "gpt-5.4",
        "claude-sonnet-4-6",
        "gemini-3.1-pro-preview",
        "deepseek-chat-3.2",
        "kimi-k2.6",
        "glm-5.1",
    ]

    def _droid_binary(self) -> Optional[str]:
        try:
            return shutil.which("droid")
        except Exception:
            return None

    def _factory_settings_path(self) -> Path:
        try:
            return Path.home() / ".factory" / "settings.json"
        except Exception:
            return Path(".factory") / "settings.json"

    def _exec_template(self) -> Optional[str]:
        raw = os.getenv("HENOSIS_DROID_EXEC", "").strip()
        if raw:
            return raw
        binary = self._droid_binary()
        if binary:
            return f'{binary} exec --model {{model}}'
        return None

    def _discover_models_from_env(self) -> List[str]:
        return _split_models_csv(os.getenv("HENOSIS_DROID_MODELS", ""))

    def _discover_models_from_settings(self) -> List[str]:
        settings_path = self._factory_settings_path()
        if not settings_path.exists():
            return []
        try:
            raw = json.loads(settings_path.read_text(encoding="utf-8"))
        except Exception:
            return []
        models: List[str] = []
        seen = set()
        custom_models = raw.get("customModels") if isinstance(raw, dict) else None
        if isinstance(custom_models, list):
            for item in custom_models:
                if not isinstance(item, dict):
                    continue
                for key in ("id", "model", "name"):
                    mid = str(item.get(key) or "").strip()
                    if mid and mid not in seen:
                        seen.add(mid)
                        models.append(mid)
                        break
        return models

    def list_available_models(self) -> List[ModelCapabilityInfo]:
        models = self._discover_models_from_env()
        if not models:
            models = self._discover_models_from_settings()
        if not models:
            models = list(self._fallback_models)
        infos: List[ModelCapabilityInfo] = []
        for model_id in models:
            mid = str(model_id or "").strip()
            if not mid:
                continue
            provider = "openai"
            if mid.startswith("claude-"):
                provider = "anthropic"
            elif mid.startswith("gemini-"):
                provider = "gemini"
            elif mid.startswith("deepseek-"):
                provider = "deepseek"
            elif mid.startswith("kimi-"):
                provider = "kimi"
            elif mid.startswith("glm-"):
                provider = "glm"
            infos.append(
                ModelCapabilityInfo(
                    model_id=mid,
                    provider_family=provider,
                    supports_tools=True,
                    supports_streaming=False,
                )
            )
        return infos

    def supports_model(self, model_id: str) -> bool:
        try:
            target = str(model_id or "").strip()
        except Exception:
            return False
        return any(m.model_id == target for m in self.list_available_models())

    def get_model_capabilities(self, model_id: str) -> Optional[ModelCapabilityInfo]:
        for item in self.list_available_models():
            if item.model_id == model_id:
                return item
        return None

    def get_readiness_status(self) -> ProfileReadinessStatus:
        binary = self._droid_binary()
        settings_path = self._factory_settings_path()
        exec_template = self._exec_template()
        if not binary and not exec_template:
            return ProfileReadinessStatus(
                state="not_installed",
                ready=False,
                installed=False,
                authenticated=None,
                subscription_usable=None,
                model_available=None,
                detail="Droid CLI was not found on PATH.",
                metadata={"binary": None, "settings_path": str(settings_path)},
            )
        if not exec_template:
            return ProfileReadinessStatus(
                state="misconfigured",
                ready=False,
                installed=bool(binary),
                authenticated=None,
                subscription_usable=None,
                model_available=None,
                detail="Droid CLI is installed, but no execution template is configured.",
                metadata={"binary": binary, "settings_path": str(settings_path), "discovery": "runtime-first"},
            )
        return ProfileReadinessStatus(
            state="ready",
            ready=True,
            installed=True,
            authenticated=None,
            subscription_usable=None,
            model_available=None,
            detail="Droid subprocess bridge is configured.",
            metadata={"binary": binary, "settings_path": str(settings_path), "exec_template": exec_template, "discovery": "runtime-first"},
        )

    def execute_turn(self, *, model_id: str, prompt: str, cwd: Optional[str] = None):
        template = self._exec_template()
        if not template:
            return {
                "ok": False,
                "error": "Droid execution is not configured.",
                "model": model_id,
                "usage": {},
                "text": "",
                "billing_source": self.billing_source,
            }
        command = _prepare_command(template, model_id=model_id, cwd=cwd)
        raw = _run_command(command, prompt=prompt, cwd=cwd, timeout_sec=120.0)
        return _parse_execution_output(raw, model_id=model_id, billing_source=self.billing_source)
