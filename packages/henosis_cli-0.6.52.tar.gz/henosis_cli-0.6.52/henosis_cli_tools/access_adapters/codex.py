from __future__ import annotations

from typing import List, Optional

from ..access_profiles import ModelCapabilityInfo, ProfileReadinessStatus


class CodexOAuthAdapter:
    profile_id = "oauth:codex"

    def list_available_models(self) -> List[ModelCapabilityInfo]:
        return [
            ModelCapabilityInfo(
                model_id="gpt-5.5",
                provider_family="openai",
                max_context_tokens=400_000,
                supports_tools=True,
                supports_streaming=True,
            ),
            ModelCapabilityInfo(
                model_id="gpt-5.3-codex",
                provider_family="openai",
                max_context_tokens=400_000,
                supports_tools=True,
                supports_streaming=True,
            ),
            ModelCapabilityInfo(
                model_id="gpt-5-codex",
                provider_family="openai",
                max_context_tokens=400_000,
                supports_tools=True,
                supports_streaming=True,
            ),
            ModelCapabilityInfo(
                model_id="codex-mini-latest",
                provider_family="openai",
                max_context_tokens=200_000,
                supports_tools=True,
                supports_streaming=True,
            ),
        ]

    def supports_model(self, model_id: str) -> bool:
        try:
            mid = str(model_id or "").strip().lower()
        except Exception:
            return False
        return mid in {"gpt-5.5", "gpt-5.3-codex", "gpt-5-codex", "codex-mini-latest"}

    def get_model_capabilities(self, model_id: str) -> Optional[ModelCapabilityInfo]:
        if not self.supports_model(model_id):
            return None
        max_context_tokens = 400_000
        if str(model_id or "").strip().lower() == "codex-mini-latest":
            max_context_tokens = 200_000
        return ModelCapabilityInfo(
            model_id=str(model_id).strip(),
            provider_family="openai",
            max_context_tokens=max_context_tokens,
            supports_tools=True,
            supports_streaming=True,
            supports_reasoning=True,
        )

    def get_readiness_status(self) -> ProfileReadinessStatus:
        return ProfileReadinessStatus(
            state="unknown",
            ready=False,
            installed=True,
            authenticated=None,
            subscription_usable=None,
            model_available=None,
            detail="Codex readiness depends on local OAuth state managed by the CLI.",
        )

    def execute_turn(self, *, model_id: str, prompt: str, cwd: Optional[str] = None):
        return {
            "ok": False,
            "error": "oauth:codex execution is handled by the dedicated local Codex streaming path, not the generic adapter bridge.",
            "model": model_id,
            "usage": {},
            "text": "",
            "billing_source": "oauth_codex",
        }
