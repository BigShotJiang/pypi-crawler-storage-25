BASE="0.1.0"
SUFFIX=".25143203280rc0"
version="%s%s" % (BASE, SUFFIX)
