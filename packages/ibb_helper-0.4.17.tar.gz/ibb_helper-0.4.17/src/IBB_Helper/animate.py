import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
import matplotlib.animation
from sympy import latex, Matrix
from IPython.display import HTML, display as ipy_display

def animate(exprs, var, 
            # --- Animation Parameter ---
            param=None,
            # --- Labels & Text ---
            labels=None, title="Animation", xlabel="x", ylabel="y",
            # --- Styling ---
            line_styles=None, colors=None, linewidth=1, scaling=None, fontsize=None,
            # --- Limits ---
            xlim=None, ylim=None, 
            # --- Animation Config ---
            animation_time=5000, frames=100, show=True,
            # --- Figure Size ---
            width=800, height=600):

    """
    Animates 2D curves from symbolic expressions or numeric datasets using Matplotlib.

    Parameters:
        exprs          : Expression, tuple, or list of expressions (symbolic, parametric, or numeric data)
        var            : Symbol or tuple defining variable/range, or array mode ('array', x_values)
        
        # --- Labels ---
        labels         : Curve labels (strings or SymPy expressions, LaTeX supported) (default=None)
        title          : Plot title (default="Animation")
        xlabel         : X-axis label (default="x")
        ylabel         : Y-axis label (default="y")
        
        # --- Styling ---
        line_styles    : Line styles for each curve (default=None -> solid)
        colors         : Colors for each curve (default=None -> Matplotlib cycle)
        linewidth      : Line width(s) as int or list (default=2)
        
        # --- Limits ---
        xlim           : X-axis limits as (min, max) (default=None -> auto)
        ylim           : Y-axis limits as (min, max) (default=None -> auto)
        
        # --- Animation Config ---
        animation_time : Total animation duration in milliseconds (default=5000)
        frames         : Number of animation frames (default=100)
        show           : Whether to display the animation (default=True)

    Returns:
        matplotlib.animation.FuncAnimation
            The animation object
    """

    # Configuration
    plt.rcParams["animation.html"] = "jshtml"
    plt.rcParams['figure.dpi'] = 300
    plt.rcParams['animation.embed_limit'] = 50.0
    plt.ioff()

    # Label Formatting
    def _smart_label(lbl):
        """Converts strings or SymPy objects to LaTeX formatted strings."""
        if lbl is None:
            return None
        if isinstance(lbl, str):
            if any(c in lbl for c in ['_', '^', '\\', '(', ')']):
                return f"${lbl}$"
            return lbl
        return f"${latex(lbl)}$"

    def _strip_math_delimiters(s):
        if isinstance(s, str) and s.startswith("$") and s.endswith("$"):
            return s[1:-1]
        return s

    def _parse_symbol_range(defn, name="var"):
        if defn is None:
            return None

        if isinstance(defn, tuple):
            if len(defn) == 2 and isinstance(defn[1], (tuple, list)) and len(defn[1]) == 2:
                sym = defn[0]
                vmin, vmax = defn[1]
                return sym, float(vmin), float(vmax)

            if len(defn) == 3:
                sym, vmin, vmax = defn
                return sym, float(vmin), float(vmax)

        raise ValueError(f"{name} must be of the form (symbol, min, max) or (symbol, (min, max))")

    # Data Preparation
    def _prepare_data(raw_exprs, variable_def):
        """
        Parses inputs (Symbolic/Numeric) and generates consistent (x, y) arrays.
        """
        # Normalize inputs to lists
        if not isinstance(raw_exprs, list):
            expr_list = [raw_exprs]
        else:
            expr_list = raw_exprs

        # Determine symbol and range
        is_sympy_mode = True
        
        if isinstance(variable_def, tuple):
            if variable_def[0] == 'array':
                is_sympy_mode = False
                x_vals_sample = variable_def[1]
                x_sym = None
            else:
                x_sym, x_min, x_max = _parse_symbol_range(variable_def, "var")
                x_range = (x_min, x_max)
                x_vals_sample = np.linspace(float(x_range[0]), float(x_range[1]), frames)
        else:
            x_sym = variable_def
            x_range = (-1, 1)
            x_vals_sample = np.linspace(float(x_range[0]), float(x_range[1]), frames)

        prepared_data = []
        symbolic_exprs = []

        for expr in expr_list:
            if isinstance(expr, Matrix):
                expr = np.array(expr).astype(np.float64).flatten()
            
            if isinstance(expr, (tuple, list)) and len(expr) == 2:
                x_comp, y_comp = expr
                
                if isinstance(x_comp, sp.Basic) or isinstance(y_comp, sp.Basic):
                    if is_sympy_mode:
                        symbolic_exprs.append((x_comp, y_comp))
                        prepared_data.append(None)
                    else:
                        x_data, y_data = x_comp, y_comp
                        prepared_data.append((
                            np.asarray(x_data, dtype=float).flatten(),
                            np.asarray(y_data, dtype=float).flatten()
                        ))
                        symbolic_exprs.append(None)
                else:
                    x_data, y_data = x_comp, y_comp
                    
                    is_x_array = hasattr(x_data, '__len__')
                    is_y_array = hasattr(y_data, '__len__')

                    if is_x_array and not is_y_array:
                        y_data = np.full_like(x_data, y_data)
                    elif not is_x_array and is_y_array:
                        x_data = np.full_like(y_data, x_data)

                    prepared_data.append((
                        np.asarray(x_data, dtype=float).flatten(),
                        np.asarray(y_data, dtype=float).flatten()
                    ))
                    symbolic_exprs.append(None)

            else:
                expr = sp.sympify(expr)
                if is_sympy_mode:
                    symbolic_exprs.append(expr)
                    prepared_data.append(None)
                else:
                    y_vals = np.array(expr).flatten()
                    prepared_data.append((
                        np.asarray(x_vals_sample, dtype=float).flatten(),
                        np.asarray(y_vals, dtype=float).flatten()
                    ))
                    symbolic_exprs.append(None)
                
        return prepared_data, symbolic_exprs, is_sympy_mode, x_sym, x_vals_sample

    # Animation Logic
    def _create_animation_object(plot_data, symbolic_exprs, is_sympy_mode, x_sym, x_vals_sample):
        n_plots = len(plot_data)
        
        if isinstance(linewidth, (int, float)):
            lw_list = [linewidth] * n_plots
        else:
            lw_list = linewidth
            
        nonlocal xlim, ylim

        def _eval_symbolic(expr, x_array, p_val=None):
            if isinstance(expr, tuple) and len(expr) == 2:
                x_expr, y_expr = expr
                if param is not None:
                    p_sym, _, _ = _parse_symbol_range(param, "param")
                    f_x = sp.lambdify(x_sym, sp.sympify(x_expr).subs(p_sym, p_val), modules='numpy')
                    f_y = sp.lambdify(x_sym, sp.sympify(y_expr).subs(p_sym, p_val), modules='numpy')
                else:
                    f_x = sp.lambdify(x_sym, x_expr, modules='numpy')
                    f_y = sp.lambdify(x_sym, y_expr, modules='numpy')
                x_data = f_x(x_array)
                y_data = f_y(x_array)
                if np.isscalar(x_data):
                    x_data = np.full_like(x_array, x_data)
                if np.isscalar(y_data):
                    y_data = np.full_like(x_array, y_data)
                return np.asarray(x_data, dtype=float).flatten(), np.asarray(y_data, dtype=float).flatten()

            expr = sp.sympify(expr)
            if param is not None:
                p_sym, _, _ = _parse_symbol_range(param, "param")
                expr = expr.subs(p_sym, p_val)

            if is_sympy_mode and x_sym is not None and expr.has(x_sym):
                f = sp.lambdify(x_sym, expr, modules='numpy')
                y_vals = f(x_array)
                if np.isscalar(y_vals):
                    y_vals = np.full_like(x_array, y_vals)
            else:
                try:
                    y_vals = np.full_like(x_array, float(expr))
                except Exception:
                    y_vals = np.full_like(x_array, np.nan)

            return np.asarray(x_array, dtype=float).flatten(), np.asarray(y_vals, dtype=float).flatten()

        # Build sample data for limits
        if param is not None:
            _, p_min, p_max = _parse_symbol_range(param, "param")
            p_samples = np.linspace(float(p_min), float(p_max), min(frames, 25))
        else:
            p_samples = [None]

        sampled_curves = []
        for i in range(n_plots):
            if symbolic_exprs[i] is not None:
                for p_val in p_samples:
                    sampled_curves.append(_eval_symbolic(symbolic_exprs[i], x_vals_sample, p_val))
            else:
                sampled_curves.append(plot_data[i])

        if xlim is None:
            all_x = np.concatenate([d[0] for d in sampled_curves if d is not None and len(d[0]) > 0])
            x_min, x_max = np.nanmin(all_x), np.nanmax(all_x)
            dx = x_max - x_min if x_max != x_min else 1.0
            xlim = (x_min - 0.05 * dx, x_max + 0.05 * dx)
            
        if ylim is None:
            all_y = np.concatenate([d[1] for d in sampled_curves if d is not None and len(d[1]) > 0])
            finite_y = all_y[np.isfinite(all_y)]
            if len(finite_y) == 0:
                y_min, y_max = -1.0, 1.0
            else:
                y_min, y_max = np.nanmin(finite_y), np.nanmax(finite_y)
            dy = y_max - y_min if y_max != y_min else 1.0
            ylim = (y_min - 0.1 * dy, y_max + 0.1 * dy)

        # 2. Setup Figure
        current_dpi = plt.rcParams.get('figure.dpi', 100)
        fig_w_inches = width / current_dpi
        fig_h_inches = height / current_dpi
        
        fig, ax = plt.subplots(figsize=(fig_w_inches, fig_h_inches))
        
        # Dynamic Font Scaling
        if fontsize is None:
            # Scale relative to a standard 8x6 inch physical figure
            font_scale = min(fig_w_inches / 8.0, fig_h_inches / 6.0)
            
            title_fs = max(4, 16 * font_scale)
            label_fs = max(4, 14 * font_scale)
            tick_fs  = max(4, 12 * font_scale)
            legend_fs = max(4, 12 * font_scale)
        else:
            # If explicitly set, scale it down proportionally
            font_scale = min(fig_w_inches / 8.0, fig_h_inches / 6.0)
            
            title_fs = max(4, (fontsize + 2) * font_scale)
            label_fs = max(4, fontsize * font_scale)
            tick_fs  = max(4, (fontsize - 2) * font_scale)
            legend_fs = max(4, fontsize * font_scale)
        
        # Apply Static Configuration ONCE
        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        ax.set_title(_smart_label(title), fontsize=title_fs)
        ax.set_xlabel(_smart_label(xlabel), fontsize=label_fs)
        ax.set_ylabel(_smart_label(ylabel), fontsize=label_fs)
        ax.tick_params(axis='both', which='major', labelsize=tick_fs)
        ax.grid(True, alpha=0.3)
        
        if scaling:
            if isinstance(scaling, str):
                scaling_key = scaling.lower()
            else:
                scaling_key = 'equal'

            if scaling_key in ('equal', 'constrained', 'box', 'datalim'):
                x_span = xlim[1] - xlim[0]
                y_span = ylim[1] - ylim[0]
                if x_span > 0 and y_span > 0 and x_span != y_span:
                    if x_span < y_span:
                        pad = (y_span - x_span) / 2.0
                        xlim = (xlim[0] - pad, xlim[1] + pad)
                        ax.set_xlim(xlim)
                    else:
                        pad = (x_span - y_span) / 2.0
                        ylim = (ylim[0] - pad, ylim[1] + pad)
                        ax.set_ylim(ylim)

                adjustable = 'box' if scaling_key in ('equal', 'constrained') else scaling_key
                ax.set_aspect('equal', adjustable=adjustable)

        lines = []
        for i in range(n_plots):
            style = line_styles[i] if line_styles and i < len(line_styles) else 'solid'
            color = colors[i] if colors and i < len(colors) else None
            raw_lbl = labels[i] if labels and i < len(labels) else None
            lbl = _smart_label(raw_lbl)
            lw = lw_list[i] if i < len(lw_list) else 2
            
            line, = ax.plot([], [], label=lbl, linestyle=style, color=color, linewidth=lw)
            lines.append(line)

        if labels: 
            # Apply dynamic font size to legend
            ax.legend(fontsize=legend_fs)

        if param is not None:
            p_sym, p_min, p_max = _parse_symbol_range(param, "param")
            p_vals = np.linspace(float(p_min), float(p_max), frames)
        else:
            p_vals = None

        # 3. Update Function
        def _update_frame(frame):
            if param is None:
                idx = int(frame + 1)
                
                for i in range(n_plots):
                    if symbolic_exprs[i] is not None:
                        x_data, y_data = _eval_symbolic(symbolic_exprs[i], x_vals_sample)
                    else:
                        x_data, y_data = plot_data[i]

                    curr_x = x_data[:min(idx, len(x_data))]
                    curr_y = y_data[:min(idx, len(y_data))]
                    lines[i].set_data(curr_x, curr_y)
            else:
                p_curr = p_vals[frame]

                for i in range(n_plots):
                    if symbolic_exprs[i] is not None:
                        x_data, y_data = _eval_symbolic(symbolic_exprs[i], x_vals_sample, p_curr)
                    else:
                        x_data, y_data = plot_data[i]
                    lines[i].set_data(x_data, y_data)

                if title:
                    title_ltx = _strip_math_delimiters(_smart_label(title))
                    ax.set_title(
                        rf"${title_ltx}\;\left({sp.latex(p_sym)}={p_curr:.4g}\right)$",
                        fontsize=title_fs
                    )
                else:
                    ax.set_title(rf"${sp.latex(p_sym)}={p_curr:.4g}$", fontsize=title_fs)

            return lines

        # 4. Create Animation
        interval = animation_time / frames
        anim = matplotlib.animation.FuncAnimation(
            fig, _update_frame, frames=frames, interval=interval, repeat=True, blit=True
        )
        
        return fig, anim

    # Main Execution
    fig, anim_obj = _create_animation_object(*_prepare_data(exprs, var))
    
    if show:
        ipy_display(HTML(anim_obj.to_jshtml()))
    else:
        plt.close(fig)
        
    return anim_obj