"""Private morphology backend adapters."""
