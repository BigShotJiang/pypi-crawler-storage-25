# 01 - 时间轴骨架（Stage 2: 语义判断）

> 把视频切成语义时间窗口（Explain / Operate / Verify），以 **Transcript 语义理解**为主信号。
> 核心思路：**一次 LLM 调用对全部 transcript 分段做意图分类，ActivityProfile 作为可选佐证。**

## 依赖

- **必需**：Transcript（来自 Stage 1，Whisper 或平台字幕）
- **可选**：ActivityProfile（来自 01a-motion-vectors，作为佐证信号）
- **可选**：YouTube 章节、弹幕密度等平台元数据

## 主流程

```pseudocode
function build_timeline(transcript, profile, meta, cfg, work_dir) -> [RepeatStep]:

  // ======== Step 1: Transcript 分段 ========
  // 将 transcript segments 按语义边界分组为 topic blocks
  topic_blocks = segment_into_topics(transcript, meta.chapters)

  // ======== Step 2: 语义判断（单次 LLM 调用）========
  // 对全部 topic blocks 做意图分类
  // ⚡ 决策点：LLM 空输出 / 无效 JSON / 异常 → DecisionRequired(llm_stage_retry_or_abort)
  classifications = semantic_judgment(topic_blocks, cfg, work_dir)

  // ======== Step 3: 多操作块拆分 ========
  // operate 块含 > 2 个 transcript_operations 时，拆成一对一子块
  topic_blocks, classifications = split_multi_action_blocks(topic_blocks, classifications)

  // ======== Step 4: 窗口组装 ========
  windows = blocks_to_windows(transcript.segments, topic_blocks, classifications)

  // ======== Step 5: RepeatStep 组装 ========
  steps = assemble_repeat_steps(windows)

  // ======== Step 6: transcript_operations → step.operations ========
  populate_transcript_operations(steps)

  return steps
```

> **注意**：活动检测（ActivityProfile）已移至 Pipeline Stage 1c 执行，不在 build_timeline 内部。
> build_timeline 接收 profile 参数但主要用于内部佐证，不驱动窗口分类。

## Step 1: Transcript 分段

将连续的 transcript segments 分组为语义主题块。

```pseudocode
function segment_into_topics(transcript, chapters?) -> [TopicBlock]:
  // 分段信号（优先级从高到低）：
  //   1. Chapter 边界（硬边界，不可跨越）
  //   2. 静音间隙 > 2 秒（讲师在切换主题）
  //   3. 连续语音合并为同一 block

  blocks = []
  current_segments = []

  for seg in transcript.segments:
    // 检查是否跨越 chapter 边界
    if chapters and crosses_chapter_boundary(current_segments, seg, chapters):
      if current_segments:
        blocks.append(TopicBlock{segments: current_segments})
      current_segments = [seg]
      continue

    // 检查是否有静音间隙
    if current_segments and seg.start - current_segments[-1].end > 2.0:
      blocks.append(TopicBlock{segments: current_segments})
      current_segments = [seg]
      continue

    current_segments.append(seg)

  if current_segments:
    blocks.append(TopicBlock{segments: current_segments})

  return blocks
```

```pseudocode
TopicBlock {
  segments: [Segment]
  start: float          // = segments[0].start
  end: float            // = segments[-1].end
  text: string          // = join(seg.text for seg in segments)
}
```

## Step 2: 语义判断

单次 LLM 调用，对全部 topic blocks 做意图分类。这是整条 pipeline 的核心枢纽。

```pseudocode
function semantic_judgment(blocks, meta) -> [Classification]:
  // 构建 prompt
  prompt = build_judgment_prompt(blocks, meta)

  // 单次 LLM 调用（纯文本，无图像，快速且低成本）
  response = llm_call(prompt)

  // 解析返回
  return parse_classifications(response, len(blocks))
```

```pseudocode
// Classification 是 LLM 返回的 JSON 对象（per block），不是 Python typed class
Classification {  // → dict
  intent: string                       // "EXPLAIN" | "OPERATE" | "VERIFY" | "TRANSITION"
  confidence: float                    // 0~1（LLM 自评，仅参考）
  needs_visual_evidence: bool          // 是否需要看画面才能重建内容
  operation_cue: string | null         // 操作概述线索（如"安装依赖"、"创建文件"）
  knowledge_topic: string | null       // 知识点主题（EXPLAIN 时填写）
  transcript_operations: [dict]        // 旁白明确说出的语义操作（OPERATE 时填写）
                                       //   规则：只提取有明确"动词+宾语"的操作，不推断
                                       //   EXPLAIN / VERIFY / TRANSITION 时为空数组 []
}
```

**transcript_operations 是 transcript-only 路径的产出**。即使 `needs_visual_evidence=false`，旁白说了"去 GitHub 搜索"就应该有一个 `ui_action/navigate` 操作。`needs_visual_evidence=false` 的含义是"不需要看画面也能重建操作"，不是"没有操作"。

视觉路径（`needs_visual_evidence=true`）下，vision 分析结果会**补充 visual_hint 字段**或**提升 source 为 `transcript+vision`**，但不会推翻旁白已确认的操作意图。

### 语义判断 Prompt 设计

```
你是一个教程视频分析专家。以下是一段教程视频的 transcript，已按主题分段。

视频标题：{meta.title}
章节信息：{meta.chapters or "无"}

请对每个分段判断讲师的**意图**：

- EXPLAIN：讲师在传达信息（解释概念、介绍背景、对比方案、阐述观点、展示参考资料）
- OPERATE：讲师在执行操作（写代码、点击 UI、输入命令、拖拽、配置设置）
- VERIFY：讲师在验证结果（运行程序查看输出、刷新页面检查效果、对比预期结果）
- TRANSITION：过渡语（问好、引导词、预告下一段内容）

对每个分段还需判断：
- needs_visual_evidence：仅当 transcript 文字不足以重建操作细节时为 true
  - true 的例子："然后我们这样做"（指代不明，需要看画面）
  - true 的例子：讲师在操作但没有说话（静默操作）
  - false 的例子："我们 pip install fastapi"（文字已包含完整命令）
  - false 的例子："设计系统的核心是..."（纯讲解，不需要画面）
- operation_cue：如果 intent=OPERATE，简要描述操作内容
- knowledge_topic：如果 intent=EXPLAIN，简要描述知识点主题

分段列表：
{json_blocks}

请返回 JSON 数组，每项对应一个分段：
[{"intent": "EXPLAIN|OPERATE|VERIFY|TRANSITION",
  "confidence": 0.0~1.0,
  "needs_visual_evidence": bool,
  "operation_cue": "..." | null,
  "knowledge_topic": "..." | null}]
```

### 关键分类原则

1. **讲解中的画面切换不是操作**：讲师边讲解边滚动网页、切换标签页展示参考资料——这是 EXPLAIN，不是 OPERATE。判断依据是意图，不是画面变化。

2. **"边做边说"是 OPERATE**：讲师一边操作一边解释自己在做什么——这是 OPERATE（explain 部分由 transcript 自然包含）。

3. **VERIFY 必须跟随 OPERATE**：如果前面没有 OPERATE，就不可能有 VERIFY。讲师说"可以看到效果了"但前面只有 EXPLAIN → 这不是 VERIFY。

4. **needs_visual_evidence 决定成本**：标为 true 的窗口会触发帧提取 + vision LLM 调用。标为 false 的窗口零额外成本。宁可少标（漏掉一些细节）也不要多标（浪费 API 调用）。

## Step 3: 窗口组装

```pseudocode
// 实现：pipeline._blocks_to_windows(transcript_segments, topic_blocks, classifications)
function blocks_to_windows(segments, blocks, classifications) -> [Window]:
  windows = []

  for block, cls in zip(blocks, classifications):
    if cls["intent"] == "TRANSITION":
      continue  // 过渡语不产生独立窗口

    window = Window{
      start: block.start,
      end: block.end,
      type: cls["intent"],     // EXPLAIN / OPERATE / VERIFY
      transcript_segments: block.segments,
      needs_visual_evidence: cls["needs_visual_evidence"],
      knowledge_points: [cls["knowledge_topic"]] if cls["knowledge_topic"] else []
    }
    windows.append(window)

  // 合并相邻同类型窗口
  windows = merge_adjacent_same_type(windows)

  return windows
```

> **ActivityProfile 佐证叠加（计划中）**：ActivityProfile 传入 `_build_timeline()` 备用，
> 目前未实现 burst 叠加到 Window 的逻辑。计划：EXPLAIN 窗口内出现强 burst（`> threshold * 2`）
> 时，将 `needs_visual_evidence` 升级为 `true`。

## Step 4: RepeatStep 组装

以 EXPLAIN 为锚点组装 RepeatStep。每个步骤必有语义理解（explain），可选操作（operate）和验证（verify）。

```pseudocode
// 实现：pipeline._assemble_steps(windows)
function assemble_repeat_steps(windows) -> [RepeatStep]:
  steps = []
  i = 0

  while i < len(windows):
    window = windows[i]

    if window.type == EXPLAIN:
      step = RepeatStep{index: len(steps), explain: window}

      // 看后面是否紧跟 OPERATE
      if i + 1 < len(windows) and windows[i + 1].type == OPERATE:
        step.operate = windows[i + 1]
        i += 1

        // OPERATE 后面是否紧跟 VERIFY
        if i + 1 < len(windows) and windows[i + 1].type == VERIFY:
          step.verify = windows[i + 1]
          i += 1

      step.time_range = {
        start: step.explain.start,
        end: (step.verify or step.operate or step.explain).end
      }
      steps.append(step)

    elif window.type == OPERATE:
      // 没有前置 EXPLAIN 的操作（直接动手）
      // 仍然创建 explain 窗口，内容来自 operate 的 transcript
      step = RepeatStep{
        index: len(steps),
        explain: Window{
          start: window.start,
          end: window.end,
          type: EXPLAIN,
          transcript_segments: window.transcript_segments,
          needs_visual_evidence: false
        },
        operate: window
      }

      // 看后面是否紧跟 VERIFY
      if i + 1 < len(windows) and windows[i + 1].type == VERIFY:
        step.verify = windows[i + 1]
        i += 1

      step.time_range = {
        start: step.explain.start,
        end: (step.verify or step.operate).end
      }
      steps.append(step)

    elif window.type == VERIFY:
      // 孤立的 VERIFY（前面没有 OPERATE）→ 作为 EXPLAIN 处理
      step = RepeatStep{
        index: len(steps),
        explain: Window{...window, type: EXPLAIN},
        time_range: {start: window.start, end: window.end}
      }
      steps.append(step)

    i += 1

  // 重新编号
  for idx, step in enumerate(steps):
    step.index = idx

  return steps
```

## Chapter 作为硬边界

```pseudocode
function refine_with_chapters(windows, chapters) -> [Window]:
  // Chapter 边界是"硬边界"，不允许窗口跨越
  for chapter in chapters:
    boundary = chapter.start
    for i, window in enumerate(windows):
      if window.start < boundary < window.end:
        left = Window{...window, end: boundary}
        right = Window{...window, start: boundary}
        windows = windows[:i] + [left, right] + windows[i+1:]
        break
  return windows
```

## 关键设计决策

1. **EXPLAIN 为锚点**：每个 RepeatStep 以语义理解为基础。没有操作的步骤（纯讲解）是正常的、一等的步骤，不是边缘情况。

2. **单次 LLM 调用做全局分类**：一次纯文本 LLM 调用（~5-10 秒）替代逐帧 vision 调用（每帧 ~60 秒）。全局上下文让分类更准确。

3. **Activity 佐证但不驱动**：MV burst 用于确认和修正语义分类，不用于定义窗口类型。没有 ActivityProfile 时语义层仍可独立工作。

4. **needs_visual_evidence 门控成本**：只有标记为 true 的窗口才会触发帧提取和 vision 分析。典型教程中 50-70% 的窗口不需要视觉证据。

5. **VERIFY 始终依赖 OPERATE**：孤立的 VERIFY 不合语义（没有操作何来验证），降级为 EXPLAIN。

6. **Chapter 作为硬边界**：讲师自己定义的结构比自动检测更可靠。

## 多操作块拆分

当 LLM 返回的 `transcript_operations` 列表包含超过 2 个操作时，将该 operate 块拆分为多个子块，
每个子块对应一个操作。segment 按比例分配，knowledge_topics 轮询分配。

```pseudocode
// 实现：pipeline._split_multi_action_blocks(topic_blocks, classifications)
// _MAX_OPS_PER_BLOCK = 2
MAX_OPS_PER_BLOCK = 2

function split_multi_action_blocks(blocks, classifications):
  for block, cls in zip(blocks, classifications):
    ops = cls["transcript_operations"]
    if cls["intent"] != "OPERATE" or len(ops) <= MAX_OPS_PER_BLOCK:
      keep as-is
    else:
      // 按操作数量等比拆分 segments
      // 每个子块拿一个 operation + 一个 knowledge_topic（如有）
      // 重新编号 index
```

## Transcript Operations 填充

Stage 2 产出的 `transcript_operations` 附在 Window.operations 上。
在 RepeatStep 组装后，将 operate window 上的 operations 复制到 step.operations，
供 Stage 4 和 semantic.json 使用。如果 Stage 3 vision 分析产出了 vision_ops，则覆盖 transcript ops。

## Open Questions

- **超长视频（60+ min）**：全 transcript 可能超出 LLM context window，需分块策略（按 chapter 分块 + 重叠）。
