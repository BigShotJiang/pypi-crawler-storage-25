# 05 - learn 主流程编排

> `wv learn` 的完整执行流程。5 个阶段，以 **语义判断**（Stage 2）为核心枢纽。
> 每个阶段产出中间文件，支持断点续做和单阶段重跑。
>
> Pipeline 本身不做分支决策（不 prompt、不自动降级）。遇到需要人工干预的分支时，
> 抛出 `DecisionRequired` 异常，由 CLI 层根据 `--decision-mode` 处理（详见 06-cli.md）。
> 所有人类可读日志通过 `RunReporter.human()` 输出到 stderr，
> 可选的结构化 JSONL 事件通过 `RunReporter.emit()` 输出到 stdout。

## 工作目录结构

```
.withvideo/
  <video_name>/
    source.mp4                 # Stage 0 产出
    source.info.json           # Stage 0 产出（yt-dlp 元数据）
    subtitles/                 # Stage 0 产出
    audio.wav                  # Stage 1 产出
    transcript.json            # Stage 1 产出（统一格式 Transcript）
    activity.json              # Stage 2 产出（ActivityProfile，可选）
    semantic_judgment.json     # Stage 2 产出（分段意图分类结果，含 transcript_operations）
    timeline.json              # Stage 2 产出（[RepeatStep] 序列，含 SemanticOperation）
    keyframes/                 # Stage 3 产出（仅 needs_visual_evidence 的窗口有帧）
    analysis.json              # Stage 3 产出（视觉分析结果，vision 补充 visual_hint）
    guide.md                   # Stage 4 产出（人类可读 Repeat Guide）
    semantic.json              # Stage 4 产出（机器可读语义操作契约，wv act 的数据源）
```

## 阶段总览

```
Stage 0: Content Acquisition       获取视频 + 元数据
Stage 1: Transcript Understanding  转录 → 统一 Transcript
Stage 2: Semantic Judgment         语义分类 + 时间轴构建（核心枢纽）
Stage 3: Selective Tool Invocation 按需帧提取 + 按需 vision 分析
Stage 4: Guide Synthesis           LLM 合成 + Markdown 渲染
```

## 主流程

CLI 持有 try/except 决策循环（见 06-cli.md），每次迭代调用 `Pipeline.run()`。
Pipeline 内部通过 `RunReporter` 发射事件，通过 `raise DecisionRequired(...)` 请求外部决策。

```pseudocode
function Pipeline.run(input_str) -> Path:

  // ============ Stage 0: 获取视频 ============
  // 详见 00a-source-acquisition.md
  reporter.stage_started("acquire", ...)          // → JSONL stage_started + task_started("acquire")
  reporter.task_started("acquire.fetch", ...)
  media, video_name, meta = acquirer.acquire(input_str, staging_dir)
  // staging → work_dir 迁移
  reporter.task_completed("acquire.fetch", "{platform}  字幕: {subtitle_quality}")
  reporter.artifact_written("acquire", "source.info.json", ...)
  reporter.stage_completed("acquire", ..., {platform, subtitle_quality, work_dir})
  //   → task_completed("acquire") + JSONL stage_completed


  // ============ Stage 1: Transcript Understanding ============
  reporter.stage_started("transcript", ...)

  // ⚡ 决策点：remote 模式下无可用平台字幕
  if is_remote(media) and not has_remote_transcript(meta):
    raise DecisionRequired(
      kind="remote_to_download",
      options=["download", "abort"], default="download",
      stage="transcript")

  // AdaptiveTranscriptProvider 内部也可能 raise：
  //   ⚡ 决策点：auto 模式下平台字幕不可靠 → platform_subtitles_to_whisper
  //   ⚡ 决策点：platform-subs 文件缺失    → platform_subtitles_to_whisper
  reporter.task_started("transcript.transcribe", "transcribe ({cfg.transcript})")
  transcript = cached(transcribe)(provider, video_path, meta, work_dir)
  reporter.task_completed("transcript.transcribe", "{N} 段 ({source})")
  reporter.stage_completed("transcript", ..., {segments, source})

  // Stage 1b: transcript-first 插件检测
  plugin.select_from_transcript(transcript)

  // Stage 1c: 活动检测（可选佐证）
  reporter.stage_started("activity", ...)
  reporter.task_started("activity.detect", "detect activity")
  if is_remote(media):
    profile = empty_profile()
    reporter.task_completed("activity.detect", "跳过 (remote media)")
  else:
    profile = cached(detect_activity)(detector, video_path)
    reporter.task_completed("activity.detect", "{N} 个爆发")
  reporter.stage_completed("activity", ..., {bursts})


  // ============ Stage 2: Semantic Judgment ============
  reporter.stage_started("semantic", ...)

  // 2a. Transcript 分段 → Topic Blocks
  // 2b. 语义判断（单次 LLM 调用，纯文本，无图像）
  //     ⚡ 决策点：LLM 空输出 / 无效 JSON / 异常 → llm_stage_retry_or_abort
  // 2c. 多操作块拆分（> 2 ops/block → 一对一子块）
  // 2d. 窗口组装 + RepeatStep 序列
  // 2e. transcript_operations 填充到 step
  reporter.task_started("semantic.llm", "semantic judgment")
  steps = cached(build_timeline)(transcript, profile, meta, cfg, work_dir)
  reporter.task_completed("semantic.llm")
  reporter.stage_completed("semantic", ..., {repeat_steps, explain/operate/verify/vision counts})


  // ============ Stage 3: Selective Tool Invocation ============
  if vision_enabled and visual_windows > 0 and "vision" not in skip:
    reporter.stage_started("vision", ...)

    // 3a. 帧提取（仅 needs_visual_evidence 的 OPERATE 窗口）
    reporter.task_started("vision.extract", "extract keyframes", total=visual_n)
    for ei, step in enumerate(visual_steps):
      step.operate.keyframes = extract_frames(step.operate, media, keyframes_dir)
      reporter.task_progress("vision.extract", ei+1, message="{N} frames")
    reporter.task_completed("vision.extract", "{total} 张关键帧")

    // 3b. 可选的 vision-based 插件检测
    if not plugin.transcript_selected:
      plugin.select(sample_frames)

    // 3c. Vision 分析（帧 → frame_analyses → operations）
    reporter.task_started("vision.analyze", "analyze frames", total=len(analyze_steps))
    for ai, step in enumerate(analyze_steps):
      with reporter.task("vision.analyze.step-{ai+1}", "step {ai+1}/{N}", total=n_frames):
        analyze_window(step.operate, vision_backend, plugin)
        vision_ops = plugin.extract_operations(step.operate.frame_analyses)
        if vision_ops:
          step.operations = vision_ops   // vision 覆盖 transcript ops
      reporter.task_progress("vision.analyze", ai+1)
    reporter.task_completed("vision.analyze", "{analyzed} 帧")

    reporter.stage_completed("vision", ..., {frames_analyzed, frames_extracted})


  // ============ Stage 4: Guide Synthesis ============
  reporter.stage_started("guide", ...)

  // 单次 LLM 调用合成标题和知识点
  //   ⚡ 决策点：LLM 空输出 / 异常 → llm_stage_retry_or_abort
  reporter.task_started("guide.synthesize", "synthesize guide")
  guide = generate_guide(steps, plugin, meta, cfg, work_dir)
  reporter.task_completed("guide.synthesize")

  with reporter.task("guide.render", "render outputs"):
    // 产出 1：人类可读 guide.md
    renderer.render(guide) → work_dir/guide.md

    // 产出 2：机器可读 semantic.json（wv act 的数据源）
    render_semantic_json(guide) → work_dir/semantic.json

  reporter.artifact_written("guide", "guide.md", "guide_markdown")
  reporter.artifact_written("guide", "semantic.json", "semantic_json")
  reporter.stage_completed("guide", ..., {steps, operations, knowledge_points})
  return guide_path
```

## Stage 间的数据流

```
Stage 0 ──→ SourceMeta (video_path, subtitles, chapters, danmaku, ...)
              │
Stage 1 ──→ Transcript (segments with timestamps)
              │
Stage 2 ──→ semantic_judgment.json (per-block intent + needs_visual_evidence)
         ──→ activity.json (optional, ActivityProfile as evidence)
         ──→ timeline.json ([RepeatStep] with explain required, operate/verify optional)
              │
Stage 3 ──→ keyframes/ (only for needs_visual_evidence windows)
         ──→ analysis.json (frame analyses + operations, only for vision-analyzed windows)
              │
Stage 4 ──→ guide.md (human-readable Repeat Guide)
         ──→ semantic.json (machine-readable SemanticOperation contract for wv act)
```

## 关键设计点

### Stage 2 是枢纽

Stage 2（语义判断）是整条 pipeline 的核心：
- **输入**：纯文本（Transcript + 平台元数据），可选 ActivityProfile
- **处理**：单次 LLM 调用对全部 transcript 分段做意图分类
- **产出**：分类结果 + `needs_visual_evidence` 标记 + RepeatStep 序列
- **成本**：~5-10 秒，纯文本调用，无图像

这一步决定了 Stage 3 的工作量。标记为 `needs_visual_evidence: false` 的窗口在 Stage 3 中被完全跳过。

### Stage 3 是条件执行

Stage 3 不是全量执行。它只处理 Stage 2 标记为需要视觉证据的窗口：
- 典型教程：50-70% 的窗口是纯讲解，Stage 3 跳过
- 纯讲解视频：Stage 3 可能完全为空
- `--vision none` 模式：Stage 3 跳过所有 vision 调用，只保留 transcript 理解

### 决策点（DecisionRequired）

Pipeline 不做隐式降级。遇到以下分支时，抛出 `DecisionRequired` 异常给 CLI 层决策：

| 触发位置 | kind | 条件 | options |
|---------|------|------|---------|
| Stage 1 (pipeline) | `remote_to_download` | remote 模式 + 无可用平台字幕 | `[download, abort]` |
| Stage 1 (AdaptiveTranscriptProvider) | `platform_subtitles_to_whisper` | auto 模式 + 字幕不可靠/缺失 | `[mlx-whisper, abort]` |
| Stage 2 (_semantic_judgment) | `llm_stage_retry_or_abort` | LLM 空输出 / 无效 JSON / 异常 | `[retry, abort]` |
| Stage 4 (_generate_guide) | `llm_stage_retry_or_abort` | LLM 空输出 / 异常 | `[retry, abort]` |

CLI 收到后根据 `--decision-mode` 处理（prompt / fail / auto），
选择非 abort 选项后修改 config 并重新执行整条 pipeline（cache 保护已完成的阶段不重复计算）。

## 错误处理与恢复

每个 Stage 产出独立的中间文件。中断后重新运行时：
- joblib/json 缓存保护已完成的 Stage 不重复计算
- `--force` 强制重跑所有 Stage（等效 `--cache none`）
- `--skip <stage>` 跳过指定 Stage（如 `--skip vision` 跳过 Stage 3）
- DecisionRequired 决策重试时，整条 pipeline 重新执行，但 cache 命中的阶段直接跳过

## 日志输出示例

### stderr（人类可读，TTY 下始终可见）

```
# 示例: B 站教程视频（download 模式）
[wv] ▶ acquire
[wv]   ▶ fetch (https://www.bilibili.com/video/BV1StX3B7E9X/)
[wv]   ✓ fetch — bilibili  字幕: unreliable (12.3s)
[wv]   章节: 5 个（平台提供）
[wv] ✓ acquire (15.1s)
[wv] ▶ transcript
[wv]   ▶ transcribe (auto)
[wv] 需要决策: Platform subtitles are unavailable or unreliable; Whisper fallback requires confirmation.
[wv] 是否改用 Whisper 在本地媒体上继续转录？ [Y/n]:
[wv]   ✓ transcribe — 60 段 (whisper) (8.2s)
[wv]   插件 (transcript): code
[wv] ✓ transcript (8.5s)
[wv] ▶ activity
[wv]   ▶ detect activity
[wv]   ✓ detect activity — 5 个爆发 (3.1s)
[wv] ✓ activity (3.2s)
[wv] ▶ semantic
[wv]   ▶ semantic judgment
[wv]   ✓ semantic judgment (5.1s)
[wv]   RepeatSteps: 12  (EXPLAIN:9 OPERATE:4 VERIFY:2)
[wv]   需要 vision 分析: 3 个 operate 窗口
[wv] ✓ semantic (5.3s)
[wv] ▶ vision
[wv]   ▶ extract keyframes [0/3]
[wv]     extract keyframes [1/3] — 4 frames
[wv]     extract keyframes [2/3] — 4 frames
[wv]     extract keyframes [3/3] — 4 frames
[wv]   ✓ extract keyframes — 12 张关键帧 (3.2s)
[wv]   ▶ analyze frames [0/3]
[wv]     ▶ step 1/3 [0/4]
[wv]     ✓ step 1/3 (4.1s)
[wv]     ▶ step 2/3 [0/4]
[wv]     ✓ step 2/3 (3.8s)
[wv]     ▶ step 3/3 [0/4]
[wv]     ✓ step 3/3 (4.3s)
[wv]   ✓ analyze frames — 12 帧 (12.4s)
[wv] ✓ vision (15.9s)
[wv] ▶ guide
[wv]   ▶ synthesize guide
[wv]   ✓ synthesize guide (4.2s)
[wv]   ▶ render outputs
[wv]   ✓ render outputs (0.1s)
[wv] ✓ guide (4.5s)

✅ Repeat Guide 已生成: .withvideo/xxx/guide.md
✅ semantic.json 已生成: .withvideo/xxx/semantic.json
   步骤: 12  操作: 8  知识点: 14
```

### stdout（JSONL 事件流，pipe 或 --event-stream jsonl 时输出）

```jsonl
{"type":"run_started","timestamp":"...","run_id":"abc123","stage":null,"message":"Run started","context":{"input":"https://...","media_access":"download","transcript":"auto","vision":"claude"}}
{"type":"stage_started","timestamp":"...","run_id":"abc123","stage":"acquire","message":"Acquire source media","context":{"input":"https://..."}}
{"type":"stage_completed","timestamp":"...","run_id":"abc123","stage":"acquire","message":"...","context":{"platform":"bilibili","subtitle_quality":"unreliable","work_dir":".withvideo/xxx"}}
{"type":"decision_required","timestamp":"...","run_id":"abc123","stage":"transcript","message":"...","context":{"kind":"platform_subtitles_to_whisper","reason_code":"platform_subtitles_unreliable","options":["mlx-whisper","abort"],"default_option":"mlx-whisper",...}}
{"type":"decision_selected","timestamp":"...","run_id":"abc123","stage":"transcript","message":"Decision selected: mlx-whisper","context":{"kind":"platform_subtitles_to_whisper","selected":"mlx-whisper",...}}
...
{"type":"artifact_written","timestamp":"...","run_id":"abc123","stage":"guide","message":"Artifact written: semantic_json","context":{"path":".withvideo/xxx/semantic.json","artifact_type":"semantic_json"}}
{"type":"run_completed","timestamp":"...","run_id":"abc123","stage":null,"message":"Run completed","context":{"output_path":".withvideo/xxx/guide.md"}}
```
