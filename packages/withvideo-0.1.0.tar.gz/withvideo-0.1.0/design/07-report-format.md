# 07 - Repeat Guide 格式规范

> Repeat Guide（`guide.md`）是 `wv learn` 的人类可读输出。
> `wv act` 读的是同目录下的 `semantic.json`，而非 `guide.md`。
> **`guide.md` 是 human-facing 的**：旁白引用 + 知识点 + 操作摘要 + 预期结果。
> **`semantic.json` 是 machine-facing 的**：SemanticOperation 序列 + VerificationExpectation，是 act 的权威数据来源。

## 完整示例

```markdown
---
source: "building-rest-api-fastapi.mp4"
title: "用 FastAPI 构建 REST API 完整教程"
duration: "28:34"
plugin: "code"
generated: "2026-04-03"
format: repeat-guide-v1
---

# 用 FastAPI 构建 REST API 完整教程

## 概述

这个教程从零开始演示了如何用 Python 的 FastAPI 框架构建一个完整的 REST API。
涵盖了项目初始化、路由定义、Pydantic 数据模型、数据库集成（SQLAlchemy）、
以及部署到生产环境。

## 前置条件

- Python 3.9+
- Terminal / 命令行工具
- VS Code（推荐）
- Docker（部署章节需要）

## 知识点索引

- [0:00] Python 虚拟环境隔离项目依赖
- [2:15] FastAPI 路由基础（GET/POST/PUT/DELETE）
- [3:12] FastAPI 自动生成 OpenAPI 文档
- [5:30] Pydantic 数据验证模型
- [10:00] SQLAlchemy ORM 集成
- [18:45] 中间件与错误处理
- [24:00] Docker 部署

---

## Step 1: 项目初始化
_[0:00 - 1:30]_

### 💡 概念

> Let's start by creating a new directory for our project and setting up a virtual environment.
> I always recommend using a virtual environment to keep your dependencies isolated.

- Python 虚拟环境隔离项目依赖，避免全局包冲突
- `python -m venv` 是 Python 内置的虚拟环境工具

### 🔧 操作

1. 打开 Terminal
2. 创建项目目录 `fastapi-demo`
3. 创建 Python 虚拟环境
4. 激活虚拟环境

```bash
mkdir fastapi-demo && cd fastapi-demo
python -m venv venv
source venv/bin/activate
```

<!-- withvideo:operations
[
  {"step": 0, "type": "shell", "description": "创建项目目录", "payload": {"command": "mkdir fastapi-demo && cd fastapi-demo"}},
  {"step": 0, "type": "shell", "description": "创建虚拟环境", "payload": {"command": "python -m venv venv"}},
  {"step": 0, "type": "shell", "description": "激活虚拟环境", "payload": {"command": "source venv/bin/activate"}}
]
-->

## Step 2: 编辑器配置
_[1:30 - 2:15]_

### 🔧 操作 `[silent]`

_（此段无旁白——操作从画面变化推断）_

1. 从终端运行 `code .` 打开 VS Code
2. 安装 Python 扩展
3. 选择 Python 解释器为 `./venv/bin/python`

<!-- withvideo:operations
[
  {"step": 1, "type": "shell", "description": "打开 VS Code", "payload": {"command": "code ."}},
  {"step": 1, "type": "ui_click", "description": "安装 Python 扩展", "payload": {"app": "vscode", "action": "install_extension", "id": "ms-python.python"}},
  {"step": 1, "type": "ui_click", "description": "选择 Python 解释器", "payload": {"app": "vscode", "action": "command_palette", "command": "Python: Select Interpreter", "value": "./venv/bin/python"}}
]
-->

### ✅ 预期结果

VS Code 底部状态栏应显示 `Python 3.x.x ('venv': venv)` 字样，表示已使用虚拟环境中的 Python 解释器。

## Step 3: 安装依赖并创建入口文件
_[2:15 - 5:30]_

### 💡 概念

> Now let's install FastAPI and uvicorn. Uvicorn is an ASGI server that will run our application.

- FastAPI 是基于 ASGI 的现代 Python Web 框架
- Uvicorn 是 ASGI 服务器，用于运行 FastAPI 应用
- `uvicorn main:app --reload` 中的 `--reload` 开启热重载，适合开发

### 🔧 操作

1. 安装 FastAPI 和 Uvicorn
2. 创建 `main.py` 文件
3. 编写最基本的 FastAPI 应用
4. 启动开发服务器

```bash
pip install fastapi uvicorn
```

```python
# main.py
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Hello World"}
```

```bash
uvicorn main:app --reload
```

<!-- withvideo:operations
[
  {"step": 2, "type": "shell", "description": "安装依赖", "payload": {"command": "pip install fastapi uvicorn"}},
  {"step": 2, "type": "code_edit", "description": "创建 main.py", "payload": {"file": "main.py", "language": "python", "content": "from fastapi import FastAPI\n\napp = FastAPI()\n\n@app.get(\"/\")\ndef read_root():\n    return {\"message\": \"Hello World\"}"}},
  {"step": 2, "type": "shell", "description": "启动开发服务器", "payload": {"command": "uvicorn main:app --reload"}}
]
-->

### ✅ 预期结果

终端显示 `Uvicorn running on http://127.0.0.1:8000`。浏览器打开 `localhost:8000` 看到 `{"message": "Hello World"}`。

## Step 4: FastAPI 自动文档
_[5:30 - 6:00]_

### 💡 概念

> One of the great things about FastAPI is that it automatically generates API documentation.
> If you go to localhost:8000/docs, you'll see the Swagger UI.

- FastAPI 自动生成 OpenAPI 规范（Swagger）文档
- `/docs` 路径提供 Swagger UI（可交互测试 API）
- `/redoc` 路径提供 ReDoc 文档（更适合阅读）
- 文档从代码中的类型注解和 docstring 自动生成

_（此步骤为纯讲解，无需操作）_
```

## 格式规范

### YAML Frontmatter

| 字段 | 类型 | 说明 |
|------|------|------|
| `source` | string | 原视频文件路径或 URL |
| `title` | string | 教程标题 |
| `duration` | string | 视频时长 "MM:SS" |
| `plugin` | string | 使用的领域插件名 |
| `generated` | string | 生成日期 ISO 格式 |
| `format` | string | 固定值 `repeat-guide-v1` |

### Step 标题格式

```
## Step N: 动作导向的标题
_[MM:SS - MM:SS]_
```

### 子节格式

每个 Step 最多三个子节，按 Explain → Operate → Verify 顺序：

| 子节 | 格式 | 何时出现 |
|------|------|---------|
| `### 💡 概念` | 引用块（旁白）+ 知识点列表 | **始终存在**（每个 step 必有 EXPLAIN） |
| `### 🔧 操作` / `### 🔧 操作 [silent]` | 编号列表 + 代码块 + JSON 注释 | 有 OPERATE 窗口时（可选） |
| `### ✅ 预期结果` | 描述文本 | 有 VERIFY 窗口时（可选，依赖 OPERATE） |

纯讲解 Step（只有 EXPLAIN，没有 OPERATE）标注 `_（此步骤为纯讲解，无需操作）_`。这是常见的正常步骤类型，不是边缘情况。

### 操作摘要注释块（guide.md 中的辅助信息）

`guide.md` 中的操作区包含一个 HTML 注释块，以 SemanticOperation 格式序列化：

```html
<!-- withvideo:operations
[
  {
    "type": "ui_action",
    "capability": "ui_action",
    "action": "navigate",
    "target": "GitHub 搜索框",
    "app_context": "GitHub",
    "intent": "搜索官方设计资产",
    "source": "transcript",
    "description": "在 GitHub 上搜索 Google Design Guide"
  }
]
-->
```

**注意：这只是 guide.md 的辅助信息，供人类参考和调试用。`wv act` 不解析此注释块，它读取 `semantic.json`。**

### SemanticOperation 字段汇总（guide.md 和 semantic.json 共享）

| capability | action 值 | text_content | visual_hint |
|-----------|----------|-------------|------------|
| `ui_action` | `navigate`, `open`, `select`, `download`, `dismiss`, `confirm` | — | vision 补充时有 |
| `text_input` | `search_text`, `enter_text`, `run_command`, `write_code` | 必填 | — |
