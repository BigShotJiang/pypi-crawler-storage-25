# 02 - 视觉理解（Stage 3 工具）

> **按需调用**的视觉分析工具。仅对语义层标记 `needs_visual_evidence: true` 的窗口做帧提取和图像理解。
> 核心策略不变：**智能帧选取**（基于 burst 结构）和 **空间注意力提示**（基于 MV 热力图）。

## 触发条件

Vision 分析**不是一个必经阶段**，而是 Stage 3（选择性工具调用）的一部分。触发条件：

1. 窗口被语义层标记为 `needs_visual_evidence: true`（Stage 2 决定）
2. `--vision` 不是 `none`
3. 未超过 `--max-frames` 限制

典型教程中 50-70% 的窗口是纯讲解，不触发 vision。只有 transcript 不足以重建操作细节的窗口才需要看画面。

## 依赖

- `01-timeline.md`：Window（含 `needs_visual_evidence` 标记）
- `01a-motion-vectors.md`：ActivityBurst（pattern, heatmap）— 可选，用于帧选取和空间提示
- `03-domain-plugin.md`：DomainPlugin（frame_prompt）

## 帧对比较仍然是核心策略

| 方法 | 优点 | 缺点 |
|------|------|------|
| 单帧 OCR | 简单 | 准确率不够；无法知道"做了什么" |
| 单帧描述 | 能描述画面 | 两帧描述再做文本 diff，信息丢失大 |
| **帧对比较** | LLM 直接聚焦"变化"；自然回答"做了什么" | 每次发 2 张图，token 稍多 |

当 vision 被触发时，仍使用帧对比较策略。改进点在于：**哪些帧要比较**（智能选取）和 **比较时看哪里**（空间提示）。

## 智能帧选取

仅对 `needs_visual_evidence: true` 的窗口执行。

```pseudocode
function smart_frame_extraction(window, video_path) -> [Frame]:
  // 帧选取策略取决于是否有 ActivityBurst 数据

  if window.activity_burst:
    // 有 burst 数据 → 基于 burst 结构选取
    return burst_based_extraction(window.activity_burst, video_path)
  else:
    // 无 burst 数据（MV 未运行或无匹配 burst）→ 均匀采样
    return uniform_extraction(window.start, window.end, video_path)


function burst_based_extraction(burst, video_path) -> [Frame]:
  frames = []

  // 三帧骨架：操作前 / 峰值 / 操作后
  pre_time = max(0, burst.start - 0.5)
  frames.append(extract_frame_at(video_path, pre_time, reason="pre_burst"))
  frames.append(extract_frame_at(video_path, burst.peak_time, reason="peak"))
  post_time = min(video_duration, burst.end + 0.5)
  frames.append(extract_frame_at(video_path, post_time, reason="post_burst"))

  // 长 burst 补充中间帧
  min_duration = pattern_min_duration(burst.pattern)
  if burst.duration > min_duration:
    interval = pattern_interval(burst.pattern)
    for t in range(burst.start + interval, burst.end, interval):
      frames.append(extract_frame_at(video_path, t, reason="intermediate"))

  return deduplicate_frames(frames, threshold=5)  // pHash hamming distance


function uniform_extraction(start, end, video_path, max_frames=4) -> [Frame]:
  // 窗口内均匀采样
  duration = end - start
  interval = duration / (max_frames + 1)
  frames = []
  for i in range(1, max_frames + 1):
    t = start + interval * i
    frames.append(extract_frame_at(video_path, t, reason="uniform"))
  return deduplicate_frames(frames)
```

## 可插拔后端接口

```pseudocode
interface VisionBackend:
  function analyze_frame_pair(
    prev_frame: Frame | null,
    curr_frame: Frame,
    context: string,          // 来自 transcript 的上下文
    domain_prompt: string,    // 来自 plugin 的专用 prompt
    spatial_hint: string,     // 来自 MV 热力图的空间提示（可选）
    pattern_hint: string      // 来自 burst 的操作模式提示（可选）
  ) -> FrameAnalysis
```

## 可用后端

| 后端 | 选项值 | 说明 |
|------|--------|------|
| **cli**（默认） | `--vision cli` | 调用本地 CLI（如 `claude -p`）交互式分析，用 `WV_LLM_COMMAND` / `--llm-command` 配置 |
| claude | `--vision claude` | 通过 Anthropic API 直接调用 Claude（需 `ANTHROPIC_API_KEY`） |
| ollama | `--vision ollama:<model>` | 本地 Ollama 模型，如 `ollama:llava` |
| none | `--vision none` | 完全跳过 Stage 3，产出纯 transcript 理解的 guide |

## 批量分析策略

```pseudocode
// 实现：pipeline._analyze_window(window, vision_backend, plugin)
// 当前为顺序处理（非并发），帧对依次送入 VisionBackend
function analyze_window_frames(window, vision_backend, plugin):
  frames = window.keyframes
  if not frames:
    return

  context = join(s.text for s in window.transcript_segments)

  spatial_hint = ""
  pattern_hint = ""
  if window.activity_burst:
    if window.activity_burst.heatmap:
      spatial_hint = describe_hot_zones(window.activity_burst.heatmap)
    pattern_hint = window.activity_burst.pattern or ""

  // 顺序处理帧对（prev, curr）
  for i in range(len(frames)):
    prev = frames[i-1] if i > 0 else null
    curr = frames[i]
    analysis = vision_backend.analyze_frame_pair(
      prev, curr, context,
      plugin.frame_prompt(),
      spatial_hint,
      pattern_hint
    )
    window.frame_analyses.append(analysis)
```

## 成本估算

语义门控 + 智能帧选取的综合节省：

| 视频时长 | 旧架构帧数 | 新架构帧数 | 预估节省 |
|---------|-----------|-----------|---------|
| 5 分钟 | 10-30 帧 | 3-10 帧 | ~60% |
| 30 分钟 | 50-150 帧 | 15-50 帧 | ~65% |
| 2 小时 | 200-500 帧 | 60-175 帧 | ~65% |

节省来自两层门控：
1. **语义层过滤**：50-70% 的窗口是纯讲解，跳过 vision（最大节省）
2. **智能帧选取**：被选中的窗口内，基于 burst 结构精确选帧，pHash 去重

`--vision none` 模式完全跳过 Stage 3，产出纯 transcript 理解的 guide。

## 关键设计决策

1. **Vision 是工具，不是阶段**：语义层的 `needs_visual_evidence` 标记是唯一触发条件。没有标记 → 不提帧 → 不调 API → 零成本。

2. **三帧骨架 + 按需补充**：每个 burst 最少 3 帧（前/峰/后），长 burst 按模式密度补充。

3. **无 burst 时均匀采样**：如果 MV 未运行或无匹配 burst，在标记窗口的时间范围内均匀采样最多 4 帧。

4. **空间提示不裁图**：MV 热力图转为文字提示，让 LLM 自己关注变化区域，保留全局上下文。

5. **pHash 去重**：汉明距离 < 5 视为近似帧，过滤重复。
