# 00 - 核心数据结构

## 设计哲学

`learn` 的核心能力是**语义理解**：先读懂讲师在说什么，再按需调用工具（视觉分析、运动检测）补充无法从文本获得的信息。

每个教程步骤的基本单元是 **Explain**（讲师在传达什么）。部分步骤包含操作（Operate），部分操作之后有验证（Verify）。三者的关系：

```
RepeatStep = Explain (必需) + Operate (可选) + Verify (可选，依赖 Operate)
```

数据结构围绕这个层次设计：Transcript 是一等公民，Vision 和 Motion 是按需调用的工具产出。

---

## 媒体句柄（Stage 0 产出）

Pipeline 通过 `MediaHandle` 统一处理本地和远程媒体。
远程模式下不下载视频，依赖平台字幕和远程帧提取；
当远程模式无法完成任务时，Pipeline 抛出 `DecisionRequired` 请求 CLI 切换到下载模式。

```pseudocode
MediaHandle = LocalMediaHandle | RemoteMediaHandle

LocalMediaHandle {
  path: Path                     // 本地视频文件路径
}

RemoteMediaHandle {
  video_url: string              // 视频 URL
  headers: {string: string}      // 请求头（认证等）
  duration: float                // 秒
  platform: Platform
}
```

## 视频来源元数据（Stage 0 产出）

```pseudocode
SubtitleTrack {
  lang: string                   // "en" | "zh" | "ai-zh" | ...
  fmt: string                    // "srt" | "vtt" | "srv3" | ...
  path: Path | null              // 已下载到本地的路径
  is_generated: bool             // 是否为自动生成字幕
  has_word_timestamps: bool      // 是否有逐词时间戳
  source: string                 // "sidecar"（默认）等来源标记
}

SourceMeta {
  // 输入
  input: string                  // 用户给的 URL 或文件路径
  platform: enum {
    YOUTUBE, BILIBILI, VIMEO,
    TWITTER, LOCAL_FILE
  }

  // yt-dlp 提取的标准字段
  local_video_path: Path | null  // 下载后的本地路径；remote 模式下为 null
  title: string
  description: string            // 视频简介（教程常含资源链接、代码仓库）
  duration: float                // 秒
  uploader: string               // 频道名 / UP主名
  upload_date: string            // ISO 日期

  // 字幕（SubtitleTrack 列表）
  subtitles: [SubtitleTrack]     // 人工上传的字幕
  auto_captions: [SubtitleTrack] // 平台自动生成的字幕（YouTube ASR 等）
  subtitle_quality: enum {
    WORD_LEVEL,                  // YouTube srv3/vtt：逐词时间戳 → 可完全替代 Whisper
    SENTENCE_LEVEL,              // 普通 SRT/VTT：句级时间戳 → 可替代 Whisper，但无逐词
    UNRELIABLE,                  // B 站 AI 字幕：有 bug，仅做参考
    NONE                         // 无字幕 → 必须 Whisper
  }

  // 章节 / 时间线
  chapters: [Chapter] | []
  sponsor_segments: [SponsorSegment] | []

  // 平台特有数据
  danmaku: [DanmakuItem] | []   // B 站弹幕
  heatmap: [{start, end, value}] | []  // YouTube 参与度热力图
  parts: [VideoPart] | []       // B 站多 P 视频

  // 属性访问器
  video_path → local_video_path  // 兼容别名
}
```

## 转录（统一格式）

```pseudocode
Transcript {
  source: enum {
    WHISPER,                     // 本地 Whisper 转录
    PLATFORM_MANUAL,             // 平台人工字幕
    PLATFORM_AUTO,               // 平台自动字幕（YouTube ASR 等）
    PLATFORM_UNRELIABLE          // 质量不可靠（B 站 AI 字幕），仅做参考
  }
  language: string               // "zh" | "en" | "ja" | ...
  segments: [Segment]
  has_word_timestamps: bool
}
```

## 语音转录段

```pseudocode
Segment {
  start: float           // 秒
  end: float
  text: string
  words: [{word, start, end}]
  no_speech_prob: float   // 0~1，用于判断是否静默
}
```

## 运动矢量帧（可选工具产出，来自 01a-motion-vectors）

以下三个结构由运动矢量工具产出。语义层将其作为佐证信号消费，不是必需输入。

```pseudocode
MVFrame {
  pts: float              // 在视频中的秒数
  frame_index: int
  vectors: [{src_x, src_y, dst_x, dst_y, motion_x, motion_y}]
}
```

## 活动爆发（可选工具产出）

```pseudocode
ActivityBurst {
  start: float
  end: float
  peak_time: float
  peak_score: float
  duration: float                // end - start
  pattern: enum {
    TYPING,                      // 编辑器区域持续小幅变化
    SCROLLING,                   // 大面积方向一致
    TAB_SWITCH,                  // 全屏短暂爆发
    VIEWPORT_MANIPULATION,       // Blender/3D 视口旋转
    CLICK_MENU,                  // 局部短脉冲
    DRAG,                        // 持续方向性运动
    UNKNOWN
  }
  heatmap: grid[16][9]           // 空间活动度分布（归一化 0~1）
}
```

## 活动度剖面（可选工具产出）

```pseudocode
ActivityProfile {
  per_second: [{time: float, score: float}]
  threshold: float
  bursts: [ActivityBurst]
  encoding_type: string          // "INTER" | "ALL_INTRA"
}
```

## 关键帧（按需提取，来自 02-vision）

仅当语义层判断窗口需要视觉证据时才提取。

```pseudocode
Frame {
  index: int
  timestamp: float               // 在视频中的秒数
  path: string                   // 帧图片文件路径
  extraction_reason: string      // "pre_burst" | "peak" | "post_burst" | "intermediate" | "uniform"
}
```

## 帧视觉分析结果（按需产出，来自 02-vision）

```pseudocode
FrameAnalysis {
  frame: Frame
  description: string                  // 画面整体描述
  app_visible: string                  // 当前可见的应用
  content_snapshot: string             // 屏幕上的文字内容
  changes_from_previous: string        // 和上一帧相比变化了什么
  operations_detected: [Operation]     // 从视觉推断的语义操作（可为空）
}
```

## 语义操作（learn 层输出）

`Operation` 是 `wv learn` 对操作的语义表示。它描述**做什么**（意图 + 目标），而非**怎么做**（像素坐标、具体点击位置）。这是 learn 和 act 之间的稳定契约。

```pseudocode
Operation {
  // 核心字段
  capability: string      // "ui_action" | "text_input"
  action: string          // 见下方 per-capability 动词集
  target: string          // 自然语言描述的操作目标（如 "GitHub 搜索框"、"VS Code 终端"）
  intent: string          // 操作目的（用户视角，如 "搜索官方设计资产"）
  app_context: string     // 所在应用 / 环境（如 "GitHub"、"VS Code"、"Terminal"、"Figma"）
  source: string          // "transcript" | "vision" | "transcript+vision"

  // 可选字段
  text_content: string    // text_input 时：要输入/运行的确切文字
  visual_hint: string     // vision 补充时：帮助 act 定位目标的视觉描述
  description: string     // 人类可读摘要

  // 兼容字段（遗留，prefer capability+action）
  type: string
  payload: {any}
}
```

**`ui_action` 允许的 action 值：**
`navigate` | `open` | `select` | `download` | `dismiss` | `confirm`

> scroll 不是 learn 级别的操作（它是 act 的执行细节），除非教程明确教"滚动到 X"。

**`text_input` 允许的 action 值：**
`search_text` | `enter_text` | `run_command` | `write_code`

**示例：**

```json
{"capability": "text_input", "action": "run_command", "target": "Terminal", "app_context": "Terminal", "text_content": "pip install fastapi", "intent": "安装 FastAPI 框架", "source": "transcript"}
{"capability": "ui_action", "action": "navigate", "target": "GitHub 搜索框", "app_context": "GitHub", "intent": "搜索 Google Design Guide 素材", "source": "transcript"}
{"capability": "ui_action", "action": "select", "target": "Python 解释器选择器", "app_context": "VS Code", "intent": "选择虚拟环境中的 Python", "source": "transcript+vision", "visual_hint": "底部状态栏 Python 版本标签"}
{"capability": "text_input", "action": "write_code", "target": "VS Code 编辑器", "app_context": "VS Code", "text_content": "from fastapi import FastAPI\n\napp = FastAPI()", "intent": "创建 FastAPI 应用入口", "source": "transcript"}
```

## 语义时间窗口

Window 是时间轴上的语义单元。类型由 Stage 2 的语义判断层决定，不由运动矢量决定。

```pseudocode
Window {
  start: float
  end: float
  type: enum {
    EXPLAIN,     // 讲师在传达信息：解释概念、介绍背景、对比方案、阐述观点
                 // 判定依据：语义层从 transcript 中识别出教学意图
                 // 处理：文本摘要 + 知识点提取
                 // 这是每个 RepeatStep 的基础，始终存在

    OPERATE,     // 讲师在执行操作：写代码、操作 UI、配置设置
                 // 判定依据：语义层从 transcript 中识别出操作意图
                 // 处理：根据 needs_visual_evidence 决定是否调用 vision 工具
                 // 产出：可复现的 operation 序列

    VERIFY       // 讲师在验证结果：运行代码、预览渲染、检查输出
                 // 判定依据：语义层识别出结果验证意图，且前序有 OPERATE
                 // 处理：提取预期结果描述
                 // 产出：expected_outcome
  }

  // 内容
  transcript_segments: [Segment]        // 这个窗口内的语音（始终存在）
  activity_burst: ActivityBurst | null  // 关联的运动爆发（可选，工具产出）
  keyframes: [Frame]                    // 关键帧（仅 needs_visual_evidence 时有）
  frame_analyses: [FrameAnalysis]       // 视觉分析结果（仅 needs_visual_evidence 时有）

  // 语义层标记（Stage 2 填写）
  needs_visual_evidence: bool           // 是否需要看画面才能重建内容（Stage 2 决定）
  intent: string                        // 原始意图分类 (explain/operate/verify/transition)
  knowledge_topic: string               // 该窗口的知识主题
  operation_cue: string                 // 操作概述线索（OPERATE 时有）

  // 产出
  summary: string
  operations: [Operation]               // 仅 OPERATE 窗口有
  expected_outcome: string              // 仅 VERIFY 窗口有
  knowledge_points: [string]            // EXPLAIN 和 OPERATE 都可能有
}
```

## Repeat 步骤（learn 的最终产出单元）

每个 RepeatStep 以 Explain 为锚点。Operate 和 Verify 是可选的语义补充。

```pseudocode
RepeatStep {
  index: int                           // 第几步
  title: string                        // LLM 生成的步骤标题
  time_range: {start, end}             // 在原视频中的时间范围

  explain: Window                      // 语义理解（必需——每个步骤必有讲师在传达的内容）
  operate: Window | null               // 操作重建（可选——语义层判断此步骤包含操作时才有）
  verify: Window | null                // 结果验证（可选——仅当 operate 存在且语义层检测到验证时有）

  // 给 wv act 用的结构化数据
  operations: [Operation]              // 从 operate 窗口汇总；
                                       //   transcript 路径：Stage 2 语义判断直接产出
                                       //   vision 路径：Stage 3 视觉分析补充/覆盖
  expected_outcome: string             // 从 verify 窗口提取的预期状态（自然语言）
  prerequisites: [string]              // 前置条件
}
```

## Repeat Guide（learn 的最终产出）

`wv learn` 产出两个文件，职责不同：

| 文件 | 用途 | 消费方 |
|------|------|--------|
| `guide.md` | 人类可读的复现指南 | 学习者、搜索索引 |
| `semantic.json` | 机器可读的语义操作契约 | `wv act`、自动化工具 |

**`guide.md` 是 human-facing 的**：结构化 Markdown，包含旁白引用、知识点、操作概述。`wv act` **不解析** `guide.md`。

**`semantic.json` 是 machine-facing 的**：它是 act 的权威数据来源。

```pseudocode
RepeatGuide {
  metadata: {
    source: string              // 视频文件路径或 URL
    title: string               // 视频标题
    duration: string            // "28:34"
    plugin: string              // "code" | "blender" | "figma" | "general"
    generated_at: string        // ISO 日期
  }
  overview: string              // LLM 生成的整体概述
  prerequisites: [string]       // 开始前需要准备什么
  steps: [RepeatStep]           // 按时间顺序的步骤序列
  knowledge_index: [{           // 知识点索引
    timestamp: float,
    topic: string,
    step_index: int
  }]
}
```

### semantic.json 格式

```json
{
  "metadata": {
    "source": "...",
    "title": "...",
    "generated_at": "2026-04-03"
  },
  "steps": [
    {
      "index": 0,
      "title": "从 GitHub 下载设计资产",
      "time_range": [0.0, 45.2],
      "operations": [
        {
          "capability": "ui_action",
          "action": "navigate",
          "target": "GitHub 搜索框",
          "app_context": "GitHub",
          "intent": "搜索 Google Design Guide 素材",
          "source": "transcript",
          "description": "在 GitHub 上搜索 Google Design Guide"
        }
      ],
      "expected_outcome": "GitHub 搜索结果页显示 Google Design Guide 仓库"
    }
  ]
}
```

## act_with_video 层数据结构

这些结构由 `act_with_video` 项目独立定义，learn 层不依赖它们。

```pseudocode
// act 消费 Operation，产出 ExecutionStep
ExecutionStep {
  operation: Operation            // 来自 semantic.json 的原始语义操作
  actions: [ComputerAction]       // 翻译后的原子动作序列
  ui_adapted: bool                // 是否发生了 UI 适配（布局变化等）
  adaptation_note: string         // 适配说明
  outcome_verified: bool | null   // 验证结果（如果有）
}

// ComputerAction 是 vendor-facing 的原子动作（对齐 Claude computer use schema）
ComputerAction {
  action: enum { screenshot, left_click, type, key, scroll, left_click_drag }
  coordinate: [int, int] | null
  text: string                    // for type
  key: string                     // for key (e.g. "Return", "ctrl+c")
  scroll_direction: enum { up, down, left, right }
  scroll_amount: int
}

// ActPlan 是一次 act 执行的完整计划
ActPlan {
  source: string                  // semantic.json 路径
  steps: [ExecutionStep]
  expectations: [VerificationExpectation]
}
```
