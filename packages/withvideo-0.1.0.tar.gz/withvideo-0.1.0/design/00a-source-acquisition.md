# 00a - 视频获取与平台适配（Stage 0）

> 输入一个 URL 或文件路径，输出标准化的 SourceMeta + 本地视频文件。
> 不同平台给的东西不一样，这一层负责抹平差异。

## 平台能力矩阵

```
                     YouTube    B站       Vimeo    Twitter   本地文件
字幕质量              逐词级     不可靠     看UP主    无        无
章节                  有         无         有        无        可能有
弹幕                  无         ✓          无        无        无
观众热力图            ✓          无         无        无        无
需要登录              否         1080p+要   私密要    有时      否
多 P / 分集           播放列表   ✓ 分P      无        无        无
SponsorBlock          ✓          无         无        无        无
视频简介含代码/链接   常见       常见       少见      推文      无
```

## 主流程

```pseudocode
function resolve_input(input: string, options) -> (video_path, video_name, SourceMeta):

  if is_url(input):
    return download_from_url(input, options)
  elif is_file(input):
    return resolve_local_file(input, options)
  else:
    error("无法识别的输入: " + input)
```

## URL 下载

```pseudocode
function download_from_url(url, options) -> (video_path, video_name, SourceMeta):

  // 检测平台
  platform = detect_platform(url)
  // youtube.com / youtu.be → YOUTUBE
  // bilibili.com / b23.tv  → BILIBILI
  // vimeo.com              → VIMEO
  // twitter.com / x.com    → TWITTER
  // ...

  // ---- yt-dlp 下载 ----
  // 核心原则：下载够用的质量，不追求最高
  // 教程视频需要：能看清屏幕上的代码/UI + 清晰的音频
  yt_dlp_args = [
    url,
    "--output", work_dir + "/source.%(ext)s",
    "--write-info-json",                         // 保存元数据
    "--merge-output-format", "mp4",              // 统一输出 mp4
  ]

  // 字幕策略（按平台）
  subtitle_args = get_subtitle_args(platform)
  yt_dlp_args.extend(subtitle_args)

  // 画质策略
  format_args = get_format_args(platform)
  yt_dlp_args.extend(format_args)

  // 平台特有处理
  platform_args = get_platform_args(platform, options)
  yt_dlp_args.extend(platform_args)

  // 执行下载
  run_yt_dlp(yt_dlp_args)

  // 解析 info.json
  info = load_json(work_dir + "/source.info.json")
  meta = build_source_meta(info, platform, work_dir)

  video_path = work_dir + "/source.mp4"
  video_name = sanitize_filename(info.title or extract_id(url))

  return (video_path, video_name, meta)
```

## 字幕策略

```pseudocode
function get_subtitle_args(platform) -> [string]:
  args = []

  if platform == YOUTUBE:
    // YouTube 字幕极其丰富：优先下载原始语言 + 自动生成
    args = [
      "--write-subs",                  // 人工字幕
      "--write-auto-subs",             // 自动字幕
      "--sub-langs", "all",            // 所有语言（后面按需筛选）
      "--sub-format", "vtt",           // vtt 带时间戳，srv3 逐词但需要特殊解析
      "--convert-subs", "srt",         // 同时转为 srt 备用
    ]

  elif platform == BILIBILI:
    // B 站字幕有 bug，下载了也不一定能用
    // 但还是试一下，后面做质量检查
    args = [
      "--write-subs",
      "--sub-langs", "all",
    ]

  elif platform in (VIMEO, UDEMY, COURSERA):
    args = [
      "--write-subs",
      "--sub-langs", "all",
    ]

  // Twitter 没有字幕系统，不请求

  return args
```

## 画质策略

```pseudocode
function get_format_args(platform) -> [string]:
  // 原则：够看清代码就行，不要 4K（浪费带宽和处理时间）
  // 目标：720p~1080p，优选 H.264（MV 提取兼容性最好）

  if platform == YOUTUBE:
    // YouTube DASH 格式丰富，选 H.264 的 720p/1080p
    // 优先 H.264 因为 MV 提取最稳定（VP9/AV1 的 MV 结构不同）
    return [
      "--format", "bestvideo[height<=1080][vcodec^=avc1]+bestaudio/best[height<=1080]",
    ]

  elif platform == BILIBILI:
    // B 站 1080p 需要登录
    // 先试 1080p，如果没登录会自动降到能下的最高画质
    return [
      "--format", "bestvideo[height<=1080]+bestaudio/best",
    ]

  elif platform == TWITTER:
    // Twitter 视频通常就 720p，直接 best
    return ["--format", "best"]

  else:
    return [
      "--format", "bestvideo[height<=1080]+bestaudio/best[height<=1080]",
    ]
```

## 平台特有处理

```pseudocode
function get_platform_args(platform, options) -> [string]:
  args = []

  if platform == YOUTUBE:
    // SponsorBlock：标记广告/片头片尾（不跳过，只标记）
    args.extend(["--sponsorblock-mark", "all"])
    // 章节：提取到 info.json 的 chapters 字段
    // （yt-dlp 默认就会提取，不需要额外参数）

  elif platform == BILIBILI:
    // 认证（如果有 cookies）
    if options.cookies:
      args.extend(["--cookies", options.cookies])
    elif options.cookies_from_browser:
      args.extend(["--cookies-from-browser", options.cookies_from_browser])

    // 弹幕：用 yt-dlp-danmaku 插件（如果安装了）
    // 弹幕以 XML 形式保存，后续解析
    // 注意：这是 yt-dlp 插件，不是命令行参数
    // 如果没装插件，我们自己用 API 抓弹幕

    // 多 P 视频
    if is_multi_part(url):
      // 默认只下载指定 P，如果用户没指定就下载全部
      if not options.part:
        args.extend(["--yes-playlist"])  // 下载所有 P

  return args
```

## B 站弹幕获取

```pseudocode
function fetch_danmaku(cid: string) -> [{time, text, color, type}]:
  // B 站弹幕 API：https://comment.bilibili.com/{cid}.xml
  // 返回 XML，解析后得到带时间戳的弹幕列表

  xml = http_get("https://comment.bilibili.com/" + cid + ".xml")
  danmaku = []
  for d in parse_xml(xml, "d"):
    attrs = d.attr("p").split(",")
    // p 属性格式: 时间,模式,字号,颜色,发送时间,弹幕池,用户hash,弹幕ID
    danmaku.append({
      time: float(attrs[0]),       // 视频时间（秒）
      type: int(attrs[1]),         // 1=滚动 4=底部 5=顶部
      color: int(attrs[3]),
      text: d.text()
    })

  // 按时间排序
  return sort_by(danmaku, key=lambda d: d.time)
```

## 构建 SourceMeta

```pseudocode
function build_source_meta(info: map, platform, work_dir) -> SourceMeta:
  meta = SourceMeta{
    input: info.webpage_url or info.original_url,
    platform: platform,
    video_path: work_dir + "/source.mp4",
    title: info.title,
    description: info.description,
    duration: info.duration,
    uploader: info.uploader or info.channel,
    upload_date: info.upload_date,
  }

  // ---- 字幕质量判定 ----
  if platform == YOUTUBE:
    if info.automatic_captions:
      meta.auto_captions = normalize_subs(info.automatic_captions, work_dir)
      meta.subtitle_quality = WORD_LEVEL  // YouTube auto-subs 有逐词时间戳
    if info.subtitles:
      meta.subtitles = normalize_subs(info.subtitles, work_dir)
      meta.subtitle_quality = WORD_LEVEL  // 人工的至少是 SENTENCE_LEVEL

  elif platform == BILIBILI:
    if info.subtitles:
      meta.subtitles = normalize_subs(info.subtitles, work_dir)
      meta.subtitle_quality = UNRELIABLE  // B 站字幕提取不稳定
    else:
      meta.subtitle_quality = NONE

  else:
    if info.subtitles:
      meta.subtitles = normalize_subs(info.subtitles, work_dir)
      meta.subtitle_quality = SENTENCE_LEVEL
    else:
      meta.subtitle_quality = NONE

  // ---- 章节 ----
  if info.chapters:
    meta.chapters = [{
      start: c.start_time,
      end: c.end_time,
      title: c.title
    } for c in info.chapters]

  // ---- SponsorBlock ----
  if info.sponsorblock_chapters:
    meta.sponsor_segments = [{
      start: s.start_time,
      end: s.end_time,
      category: s.category
    } for s in info.sponsorblock_chapters]

  // ---- B 站弹幕 ----
  if platform == BILIBILI:
    cid = extract_cid(info)
    if cid:
      meta.danmaku = fetch_danmaku(cid)

  // ---- YouTube 热力图 ----
  if platform == YOUTUBE and info.heatmap:
    meta.heatmap = info.heatmap

  // ---- B 站多 P ----
  if platform == BILIBILI and info.pages:
    meta.parts = [{
      index: p.page,
      title: p.part,
      cid: str(p.cid),
      duration: p.duration
    } for p in info.pages]

  return meta
```

## 本地文件处理

```pseudocode
function resolve_local_file(file_path, options) -> (video_path, video_name, SourceMeta):

  if not exists(file_path):
    error("文件不存在: " + file_path)

  video_name = stem(basename(file_path))

  // 检查是否有配套的 info.json（yt-dlp 之前下载过）
  info_json_path = file_path.replace(ext(file_path), ".info.json")
  if exists(info_json_path):
    info = load_json(info_json_path)
    platform = detect_platform(info.webpage_url) if info.webpage_url else LOCAL_FILE
    meta = build_source_meta(info, platform, dirname(file_path))
  else:
    meta = SourceMeta{
      input: file_path,
      platform: LOCAL_FILE,
      video_path: file_path,
      title: video_name,
      description: "",
      duration: ffprobe_duration(file_path),
      subtitle_quality: NONE,
    }

  // 检查编码（H.264 最适合 MV 提取）
  codec = ffprobe_codec(file_path)
  if codec not in ("h264", "h265", "hevc"):
    log("⚠️ 视频编码为 " + codec + "，MV 提取可能不可用，将自动回退到 SSIM")

  return (file_path, video_name, meta)
```

## 转录决策逻辑

Stage 0 完成后，Stage 1（Transcript Understanding）由 `AdaptiveTranscriptProvider` 根据 SourceMeta 选择转录策略。
**Pipeline 不做隐式降级**——当需要切换策略时，抛出 `DecisionRequired` 给 CLI 层（详见 06-cli.md）。

```pseudocode
class AdaptiveTranscriptProvider:

  function transcribe(video_path, meta, work_dir) -> Transcript:

    // ---- auto 模式下检查平台字幕可用性 ----
    if cfg.transcript == "auto" and video_path != null:
      if not has_usable_platform_subs(meta)
         or meta.subtitle_quality not in (WORD_LEVEL, SENTENCE_LEVEL):
        // ⚡ 决策点：需要 CLI 确认是否切换到 Whisper
        raise DecisionRequired(
          kind="platform_subtitles_to_whisper",
          options=["mlx-whisper", "abort"],
          default="mlx-whisper")

    // ---- 选择 provider ----
    provider_name = select_provider_name(meta, video_path)
    //   明确指定 → 直接用
    //   auto + 有高质量平台字幕 → platform-subs
    //   auto + 其他 → mlx-whisper

    // ---- 执行转录 ----
    // 如果 platform-subs 文件缺失（FileNotFoundError），
    // 同样 raise DecisionRequired(platform_subtitles_to_whisper)
    return provider.transcribe(video_path, meta, work_dir)
```

**决策策略：**

| subtitle_quality | auto 行为 |
|-----------------|----------|
| WORD_LEVEL | 直接使用平台字幕 |
| SENTENCE_LEVEL | 直接使用平台字幕 |
| UNRELIABLE | raise DecisionRequired → CLI 确认后切 Whisper |
| NONE | raise DecisionRequired → CLI 确认后切 Whisper |

## 弹幕的价值（B 站独有信号）

弹幕是**带时间戳的观众实时反应**，对教程分析极有价值：

```pseudocode
// 弹幕密度分析：观众在哪些时间段最活跃
function analyze_danmaku_density(danmaku, window_size=10) -> [{time, density}]:
  // 滑动窗口统计弹幕密度
  // 高密度区域 = 观众觉得重要/困惑/精彩的地方

// 弹幕内容分析：提取有价值的信息
function analyze_danmaku_content(danmaku) -> DanmakuInsights:
  // 常见模式：
  //   "看不懂" / "这里没听清" → 标记为难点
  //   "学到了" / "原来如此"   → 标记为知识点
  //   "这步少了xxx"           → 教程可能漏了步骤
  //   代码/命令相关弹幕        → 可能是勘误或补充
```

弹幕密度可以作为 Stage 2 语义判断的辅助信号——高密度区域可能是重要操作或难点，帮助语义层更准确地识别关键步骤。
