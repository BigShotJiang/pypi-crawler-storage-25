# 01a - 运动矢量分析（可选佐证工具）

> 从 H.264/H.265 码流中直接提取运动矢量（Motion Vectors），**无需解码像素**。
> 产出：每秒活动度评分、活动爆发区间、空间热力图、操作模式分类。
>
> 在 semantic-first 架构中，这是**语义层的可选佐证信号**。语义层从 transcript 做主分类，
> ActivityProfile 用于确认和修正分类结果，以及为后续 vision 分析提供空间提示。
> 没有 ActivityProfile 时，语义层仍可独立工作。

## 定位

MV 分析运行一次（~1-2 秒），产出 `ActivityProfile`。语义层消费此 profile 的方式：
- burst 与 OPERATE 窗口对齐 → 高置信度
- burst 出现在 EXPLAIN 窗口 → 可能需要重新分类或补充视觉证据
- heatmap 和 pattern → 传递给 vision 后端作为空间/模式提示

## 为什么用运动矢量？

| 方案 | 速度 | 精度 | 适用场景 |
|------|------|------|---------|
| ffmpeg scene detect | 中（需解码像素） | 低（只检测"画面大变"） | 电影/综艺剪辑 |
| SSIM/pHash 帧对比 | 慢（需解码 + 逐帧对比） | 中 | 通用 |
| **H.264 运动矢量** | 极快（直接读码流） | 高（微小变化也能捕获） | **屏幕录制教程** |
| 光流法 (RAFT) | 极慢（需 GPU） | 极高 | 学术/动作分析 |

屏幕录制的 MV 特征非常典型：
- **打字**：编辑器区域持续小幅 MV
- **滚动**：大面积方向一致的 MV
- **切 Tab/窗口**：全屏爆发性 MV
- **菜单点击**：局部短暂 MV 脉冲
- **Blender 视口旋转**：中等面积、持续方向变化
- **鼠标拖拽**：沿拖拽方向的局部持续 MV
- **静止/摄像头说话**：几乎无 MV

## MV 提取

```pseudocode
function extract_motion_vectors(video_path) -> [MVFrame]:
  container = pyav.open(video_path)
  stream = container.streams.video[0]
  stream.codec_context.export_side_data = true  // 关键：启用 MV 导出

  mv_frames = []
  for packet in container.demux(stream):
    for frame in packet.decode():
      mvs = frame.side_data.get('MOTION_VECTORS', [])
      mv_frames.append(MVFrame{
        pts: float(frame.pts * stream.time_base),
        frame_index: len(mv_frames),
        vectors: [{
          src_x: mv.src_x, src_y: mv.src_y,
          dst_x: mv.dst_x, dst_y: mv.dst_y,
          motion_x: mv.motion_x, motion_y: mv.motion_y
        } for mv in mvs]
      })

  return mv_frames
```

## 编码类型检测 + 回退

```pseudocode
function check_encoding_type(mv_frames) -> string:
  // All-Intra 编码（macOS QuickTime 屏幕录制等）没有 P/B 帧，没有 MV
  if len(mv_frames) == 0:
    return "ALL_INTRA"
  total_mv_count = sum(len(mvf.vectors) for mvf in mv_frames)
  avg_mv_per_frame = total_mv_count / len(mv_frames)
  if avg_mv_per_frame < 5:
    return "ALL_INTRA"
  return "INTER"


function ssim_fallback_profile(video_path, sample_fps=2) -> ActivityProfile:
  // MV 不可用时，回退到像素域对比
  frames = ffmpeg_sample_frames(video_path, fps=sample_fps)
  per_second = []
  for i in range(1, len(frames)):
    ssim = compute_ssim(frames[i-1], frames[i])
    score = (1.0 - ssim) * 1000
    per_second.append({time: frames[i].timestamp, score: score})

  noise_floor = percentile(scores, 25)
  threshold = max(noise_floor * 3, percentile(scores, 60))

  return ActivityProfile{per_second, threshold, encoding_type: "ALL_INTRA"}
```

## 活动度评分

```pseudocode
function compute_activity_profile(mv_frames) -> ActivityProfile:
  // Step 1: 每帧活动度 = 所有 MV magnitude 之和
  per_frame = []
  for mvf in mv_frames:
    magnitude_sum = sum(sqrt(mv.motion_x² + mv.motion_y²) for mv in mvf.vectors)
    per_frame.append({time: mvf.pts, score: magnitude_sum})

  // Step 2: 按 1 秒窗口聚合（用中位数，天然忽略 I 帧的零值）
  duration = per_frame[-1].time
  per_second = []
  for t in range(0, ceil(duration)):
    scores_in_window = [pf.score for pf in per_frame if t <= pf.time < t+1]
    if scores_in_window:
      per_second.append({time: t, score: median(scores_in_window)})
    else:
      per_second.append({time: t, score: 0})

  // Step 3: 自适应阈值
  all_scores = [ps.score for ps in per_second]
  noise_floor = percentile(all_scores, 25)
  threshold = max(noise_floor * 3, percentile(all_scores, 60))

  return ActivityProfile{per_second, threshold, encoding_type: "INTER"}
```

## 活动爆发检测

```pseudocode
function detect_bursts(profile) -> [ActivityBurst]:
  // Step 1: 连续超过阈值的区间
  runs = find_continuous_runs(profile.per_second, profile.threshold)

  // Step 2: 合并过近的 burst（间隔 < 0.5s）
  bursts = merge_nearby(runs, gap=0.5)

  // Step 3: 丰富元数据（peak_time, peak_score, duration）
  for burst in bursts:
    enrich_burst_metadata(burst, profile.per_second)

  // Step 4: 过滤太短的 burst（< 0.3s）
  bursts = [b for b in bursts if b.duration >= 0.3]

  return bursts
```

## 空间热力图

```pseudocode
function compute_spatial_heatmap(mv_frames, burst, video_width, video_height) -> grid[16][9]:
  // 把 burst 时间范围内的所有 MV 映射到 16x9 网格
  cell_w = video_width / 16
  cell_h = video_height / 9
  grid = zeros(16, 9)

  relevant_frames = [mvf for mvf in mv_frames if burst.start <= mvf.pts < burst.end]
  for mvf in relevant_frames:
    for mv in mvf.vectors:
      col = clamp(floor(mv.dst_x / cell_w), 0, 15)
      row = clamp(floor(mv.dst_y / cell_h), 0, 8)
      grid[col][row] += sqrt(mv.motion_x² + mv.motion_y²)

  // 归一化到 0~1
  max_val = max(grid.flatten())
  if max_val > 0:
    grid = grid / max_val
  return grid


function describe_hot_zones(heatmap) -> string:
  // 热力图转文字描述，用于 vision 后端的空间提示
  zones = {
    "左上": heatmap[0:8][0:4],
    "右上": heatmap[8:16][0:4],
    "左下": heatmap[0:8][6:9],
    "右下": heatmap[8:16][6:9],
    "顶部": heatmap[0:16][0:2],
    "底部": heatmap[0:16][7:9]
  }
  hot = [name for name, zone in zones if mean(zone) > 0.3]
  if not hot:
    return "变化均匀分布在整个屏幕"
  return "变化集中在：" + "、".join(hot)
```

## 模式分类

```pseudocode
function classify_pattern(burst, mv_frames, video_width, video_height) -> string:
  // 基于 4 个特征分类：覆盖率、方向一致性、焦点集中度、持续时间
  heatmap = compute_spatial_heatmap(mv_frames, burst, video_width, video_height)
  burst.heatmap = heatmap

  coverage = active_cell_ratio(heatmap, threshold=0.1)
  direction_consistency = circular_variance(extract_angles(burst, mv_frames))
  focus_ratio = top_20_percent_ratio(heatmap)
  duration = burst.duration

  if coverage > 0.7 and duration < 1.0:       return "TAB_SWITCH"
  if direction_consistency < 0.3 and coverage > 0.4: return "SCROLLING"
  if focus_ratio > 0.7 and duration > 2.0:    return "TYPING"
  if focus_ratio > 0.6 and duration < 1.0:    return "CLICK_MENU"
  if direction_consistency < 0.5 and 0.2 < coverage < 0.6 and duration > 1.5: return "DRAG"
  if 0.2 < coverage < 0.6 and duration > 2.0: return "VIEWPORT_MANIPULATION"
  return "UNKNOWN"
```

## Facecam / 持续活动区域检测

```pseudocode
function detect_persistent_regions(mv_frames, video_width, video_height) -> [Region]:
  // 活跃占比 > 80% 的 cell → 持续活动区域（facecam、动态水印等）
  // 从 MV 中排除这些区域的贡献，重新计算 activity profile

function recompute_without_regions(mv_frames, persistent_regions) -> ActivityProfile:
  filtered_frames = [filter_vectors(mvf, persistent_regions) for mvf in mv_frames]
  return compute_activity_profile(filtered_frames)
```

## 关键设计决策

1. **PyAV 而非 ffprobe/ffmpeg**：直接返回结构化数据，~15MB 依赖，速度最快。

2. **中位数聚合**：I 帧（intra-coded）没有 MV，score=0。中位数天然忽略这些零值。

3. **自适应阈值**：`max(3x noise_floor, 60th percentile)` 自动适应不同录屏工具和分辨率。

4. **16x9 网格**：与屏幕比例对齐，足够区分 UI 区域。

5. **模式分类用规则而非 ML**：4 个特征、7 个类别、领域知识明确。可解释、可调试、零训练成本。

6. **Facecam 用持续性检测**：不引入额外 CV 模型。"一直在动的区域"是通用定义。
