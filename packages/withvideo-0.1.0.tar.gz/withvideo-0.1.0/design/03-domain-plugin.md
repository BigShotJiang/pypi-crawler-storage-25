# 03 - 领域插件（Stage 3 组件）

> 不同教程类型需要不同的"理解策略"和"操作提取逻辑"。
> 设计为插件协议，按需加载。

## 插件协议

```pseudocode
// 对应 withvideo/protocols/plugin.py — DomainPlugin Protocol
interface DomainPlugin:
  name: string
  description: string

  // Vision-based 检测（置信度评分，仅接受帧列表，不接受 vision backend）
  function detect(frames: [Frame]) -> float

  // 领域专属的帧分析 prompt（注入到 VisionBackend 的请求中）
  function frame_prompt() -> string

  // 从 FrameAnalysis 中提取结构化操作
  function extract_operations(analysis: FrameAnalysis) -> [Operation]

  // 格式化为人看的描述（报告用）
  function format_for_report(ops: [Operation]) -> string
```

> `select_from_transcript()` 和 `select()` **不在** `DomainPlugin` 协议中，是 `AutoDetectPlugin`
> 的具体方法，由 Pipeline 通过 `hasattr` 判断后调用。

## 自动检测机制（AutoDetectPlugin 包装器）

`AutoDetectPlugin` 包装所有具体插件，实现两阶段检测。
Pipeline 在 Stage 1b 通过 `hasattr` 检查调用 `select_from_transcript()`，
Stage 3 提取关键帧后通过 `hasattr` 检查调用 `select(frames)`。

```pseudocode
// 对应 withvideo/impl/plugins/auto.py — AutoDetectPlugin
class AutoDetectPlugin:
  plugins = [CodePlugin, BlenderPlugin, FigmaPlugin, GeneralPlugin]
  selected: DomainPlugin = GeneralPlugin()
  _transcript_selected: bool = false

  // Phase 1: Transcript-based（Stage 1b，快速、零成本）
  function select_from_transcript(transcript):
    // 在 transcript 文本中搜索各插件的关键词
    // 命中数最高且 >= 阈值的插件被选中
    // 选中后标记 _transcript_selected = true

  // Phase 2: Vision-based（Stage 3，仅当 transcript 未选中时）
  function select(frames: [Frame]):
    if _transcript_selected:
      return  // transcript 已确定，跳过
    // 用前几帧的 detect() 评分选择最佳插件

  // 代理方法（满足 DomainPlugin 协议）
  function detect(frames) -> delegate to selected
  function frame_prompt() -> delegate to selected
  function extract_operations(analysis) -> delegate to selected
  function format_for_report(ops) -> delegate to selected
```

---

## code 插件

```pseudocode
class CodePlugin implements DomainPlugin:
  name = "code"
  description = "代码教程（IDE、终端、浏览器开发工具）"

  function detect_from_transcript(transcript):
    // 在 transcript 文本中搜索代码相关关键词
    text = join(seg.text for seg in transcript.segments).lower()
    keywords = [
      "npm", "pip", "yarn", "cargo", "go get",           // 包管理器
      "import", "require", "from", "include",              // 导入语句
      "function", "class", "def ", "const ", "let ", "var ",  // 声明关键字
      ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs",  // 文件扩展名
      "vscode", "vs code", "terminal", "命令行",           // 工具名
      "git ", "docker", "kubectl",                         // DevOps 工具
      "localhost", "127.0.0.1", "端口",                    // 开发服务器
      "报错", "error", "bug", "debug",                     // 调试
    ]
    hits = sum(1 for kw in keywords if kw in text)
    return min(hits / 5.0, 1.0)  // 5 个关键词命中 → 满分

  function detect(frames: [Frame]) -> float:
    // 通过关键帧特征（文件名、UI 元素）评分
    // 具体实现依赖 frame.path 的图像分析或简单启发式
    return score  // 0~1

  function frame_prompt():
    return """
    你在分析一个代码教程的屏幕录像。请特别关注：
    1. 当前打开的是什么应用（VS Code? Terminal? Browser? 其他 IDE?）
    2. 如果是编辑器：打开的文件名、可见的代码内容、语言/文件类型
    3. 如果是终端：输入的命令、命令的输出结果、工作目录
    4. 与上一帧相比：新增/修改/删除了什么代码
    5. 任何错误信息、警告、或运行结果
    6. 浏览器中的 URL 和页面内容（如果可见）

    输出 JSON 格式：
    {
      "description": "...",
      "app_visible": "vscode | terminal | browser | other",
      "content_snapshot": "可见的代码/命令",
      "changes_from_previous": "...",
      "operations_detected": [
        {"type": "shell", "description": "...", "payload": {"command": "..."}},
        {"type": "code_edit", "description": "...", "payload": {"file": "...", "language": "...", "content": "..."}}
      ]
    }
    """

  function extract_operations(analysis):
    return analysis.operations_detected

  function format_for_report(ops):
    lines = []
    for op in ops:
      if op.type == "shell":
        lines.append("```bash\n" + op.payload.command + "\n```")
      elif op.type == "code_edit":
        lang = op.payload.language or ""
        lines.append("```" + lang + "\n" + op.payload.content + "\n```")
      else:
        lines.append("- " + op.description)
    return join(lines, "\n")

```

---

## blender 插件（骨架）

```pseudocode
class BlenderPlugin implements DomainPlugin:
  name = "blender"
  description = "Blender 3D 教程"

  function detect_from_transcript(transcript):
    text = join(seg.text for seg in transcript.segments).lower()
    keywords = [
      "blender", "mesh", "vertex", "edge", "face",
      "modifier", "subdivision", "bevel", "extrude",
      "viewport", "render", "material", "shader", "node",
      "uv", "texture", "sculpt", "armature", "bone",
      "keyframe", "animation", "timeline",
    ]
    hits = sum(1 for kw in keywords if kw in text)
    return min(hits / 4.0, 1.0)

  function detect(frames: [Frame]) -> float:
    return score  // 0~1，基于帧特征评估

  function frame_prompt():
    return """
    你在分析一个 Blender 教程的屏幕录像。请特别关注：
    1. 编辑模式（Object / Edit / Sculpt / ...）
    2. 选中的对象名称、活跃的工具
    3. Properties 面板中的数值（Transform, Modifier 参数, Material 设置）
    4. 节点编辑器（如果可见）：节点类型、连接关系、参数值
    5. 左下角的操作提示（最近一次操作及参数）
    6. 弹出菜单、搜索框内容

    输出 JSON 格式 {...}
    """

  function extract_operations(analysis):
    // 提取 blender_action 类型的 Operation
    ...

```

---

## figma 插件（骨架）

```pseudocode
class FigmaPlugin implements DomainPlugin:
  name = "figma"
  description = "Figma 设计教程"

  function detect_from_transcript(transcript):
    text = join(seg.text for seg in transcript.segments).lower()
    keywords = [
      "figma", "frame", "auto layout", "component", "variant",
      "prototype", "design system", "style", "fill", "stroke",
      "layer", "group", "boolean", "mask", "plugin",
    ]
    hits = sum(1 for kw in keywords if kw in text)
    return min(hits / 4.0, 1.0)

  function frame_prompt():
    return """
    你在分析一个 Figma 教程。请特别关注：
    1. 选中的图层/组件名称
    2. Design 面板的属性值（尺寸、颜色、字体、间距）
    3. 使用的工具（选择、矩形、文字、钢笔...）
    4. Auto Layout 设置、组件/变体操作

    输出 JSON 格式 {...}
    """
```

---

## general 插件（兜底）

```pseudocode
class GeneralPlugin implements DomainPlugin:
  name = "general"
  description = "通用教程（无特定领域优化）"

  function detect_from_transcript(transcript):
    return 0.1  // 永远是最低优先级

  function detect(frames: [Frame]) -> float:
    return 0.1  // 永远是最低优先级

  function frame_prompt():
    return """
    分析这个教程截图，描述：
    1. 画面中显示的应用/网站
    2. 可见的文字内容
    3. 与上一帧相比的变化
    4. 作者执行了什么操作
    """

  function extract_operations(analysis):
    return [Operation{
      type: "ui_action",
      description: analysis.description,
      payload: {raw_description: analysis.changes_from_previous}
    }]
```
