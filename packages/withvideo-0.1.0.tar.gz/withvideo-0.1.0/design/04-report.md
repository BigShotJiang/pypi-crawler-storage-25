# 04 - Repeat Guide 生成（Stage 4）

> 把语义理解 + 可选的视觉分析结果合成为 **Repeat Guide**。
> 报告不是"总结"，而是"怎么重复这个教程"。
> **Transcript 理解是主数据源，vision 产出是补充。**

## 依赖

- `01-timeline.md`：[RepeatStep]（每步必有 explain，可选 operate/verify）
- `03-domain-plugin.md`：DomainPlugin（extract_operations, format_for_report）
- `02-vision.md`：FrameAnalysis（仅 needs_visual_evidence 窗口有）

## 生成流程

```pseudocode
function generate_repeat_guide(steps: [RepeatStep], plugin: DomainPlugin, metadata) -> RepeatGuide:

  // ---- Step 1: 提取操作（仅有 vision 分析的 OPERATE 窗口）----
  for step in steps:
    if step.operate and step.operate.frame_analyses:
      for analysis in step.operate.frame_analyses:
        step.operations.extend(plugin.extract_operations(analysis))

  // ---- Step 2: LLM 高层次综合 ----
  // ⚡ 决策点：LLM 空输出 / 异常 → DecisionRequired(llm_stage_retry_or_abort)
  // Transcript 理解为主数据源，operations 为补充
  step_summaries = [{
    index: step.index,
    time_range: format_time_range(step.time_range),

    // 主数据：transcript 理解（每个 step 都有）
    explain_text: join(s.text for s in step.explain.transcript_segments),
    knowledge_topic: step.explain.knowledge_points,

    // 补充数据：操作（仅有 vision 分析的 step 有）
    has_operate: step.operate != null,
    operations: [o.description for o in step.operations],
    visual_changes: [a.changes_from_previous for a in (step.operate.frame_analyses or [])] if step.operate else [],

    // 补充数据：验证
    has_verify: step.verify != null,
    verify_text: join(s.text for s in step.verify.transcript_segments) if step.verify else ""
  } for step in steps]

  synthesis = llm_call(
    system: """你是一个教程分析专家。根据以下视频分析结果，生成一份 "How to Repeat" 指南。

    每个步骤的 explain_text 是讲师的原始旁白，这是最权威的信息来源。
    部分步骤有额外的 operations（从画面视觉分析提取），作为补充。
    没有 operations 的步骤不代表内容缺失——讲师的解说本身就是完整的内容。

    请：
    1. 写一段整体概述（3-5 句话）
    2. 列出前置条件
    3. 给每个步骤起一个标题（反映讲师在传达什么，不只是在做什么）
    4. 为每个步骤提取知识点
    5. 为有 VERIFY 的步骤描述预期结果
    """,
    user: json_dumps(step_summaries)
  )

  // ---- Step 3: 组装 RepeatGuide ----
  guide = RepeatGuide{
    metadata: metadata,
    overview: synthesis.overview,
    prerequisites: synthesis.prerequisites,
    steps: steps,
    knowledge_index: []
  }

  // 回填 LLM 生成的内容
  for i, step in enumerate(guide.steps):
    step.title = synthesis.step_titles[i]

    // explain 知识点（每个 step 都有）
    step.explain.knowledge_points = synthesis.knowledge_points[i]
    for kp in step.explain.knowledge_points:
      guide.knowledge_index.append({
        timestamp: step.explain.start,
        topic: kp,
        step_index: i
      })

    // verify 预期结果
    if step.verify:
      step.verify.summary = synthesis.verify_descriptions[i]
      step.expected_outcome = synthesis.verify_descriptions[i]

  return guide
```

## 渲染为 Markdown

详见 `07-report-format.md`。关键点：

- EXPLAIN 子节（`### 💡 概念`）始终在前，是每个 step 的主体
- OPERATE 子节（`### 🔧 操作`）可选，有 operations 时才出现
- VERIFY 子节（`### ✅ 预期结果`）可选，依赖 OPERATE
- 纯讲解 Step（只有 EXPLAIN）是正常形态，标注 `_（此步骤为纯讲解，无需操作）_`

## Repeat Guide 的消费方

| 消费方 | 读什么文件 | 怎么用 |
|--------|-----------|--------|
| 人（学习者） | `guide.md` | 按步骤学习和复现 |
| `wv act` | `semantic.json` | 读取 SemanticOperation 序列，翻译为 ComputerAction |
| `wv act --verify` | `semantic.json` 中的 expectations | 执行后按 VerificationExpectation 自动验证 |
| 搜索/索引 | `guide.md` YAML frontmatter、知识点索引 | 检索和分类 |

**重要：`wv act` 读 `semantic.json`，不解析 `guide.md` 注释块。** `guide.md` 是给人看的，`semantic.json` 是机器契约。

## Stage 4 产出两个文件

```
generate_repeat_guide(steps) → RepeatGuide
  ├── render_markdown(guide) → guide.md     (human-readable)
  └── render_semantic_json(guide) → semantic.json  (machine-readable, wv act 数据源)
```

`semantic.json` 的顶层结构见 `00-data-structures.md`。
