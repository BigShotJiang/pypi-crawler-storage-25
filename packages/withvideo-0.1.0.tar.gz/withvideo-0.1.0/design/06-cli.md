# 06 - CLI 入口设计

> 命令行工具 `wv`，四个子命令：`learn`、`act`、`schema`、`preflight`。
> 设计目标：对人类友好（TTY prompt 流程），同时对 AI agent 友好（双向 JSONL 协议、defaults 自动模式、preflight 预检）。

## 外部命令解析约束

所有通过 `subprocess` 调用的外部二进制（ffmpeg、ffprobe、yt-dlp、claude、codex、cursor 等），
**禁止使用裸命令名**，必须通过 `config._find_binary(name)` 解析为绝对路径。

原因：Claude Code / Cursor / Codex 等桌面 IDE 启动的子进程 PATH 受限，
不含 `/opt/homebrew/bin`、`~/.local/bin` 等常见安装路径。裸名调用会导致 `FileNotFoundError`。

`_find_binary` 查找顺序：
1. `shutil.which(name)` — 标准 PATH 查找
2. `~/.local/bin/{name}` — 用户本地安装（claude / codex CLI 默认位置）
3. `/opt/homebrew/bin/{name}` — Homebrew (Apple Silicon)
4. `/usr/local/bin/{name}` — Homebrew (Intel) / 手动安装

## 命令结构

```
wv
├── learn <video>      看视频，产出 Repeat Guide
├── act <guide>        读 Repeat Guide，真实执行操作
├── schema             输出 JSON schema（事件、决策、选项自描述）
└── preflight <video>  预检环境 + 探测视频源，输出 JSON 报告（不运行 pipeline）
```

## wv learn

```pseudocode
command "wv learn":

  // 必选参数
  argument INPUT:
    description: "视频文件路径或 URL（YouTube/B站/Vimeo/...）"
    required: true

  // 输出控制
  option --output, -o:
    description: "输出目录（默认 .withvideo/<video_name>/）"
    type: path

  // 插件选择
  option --plugin, -p:
    description: "教程类型插件"
    choices: [auto, code, blender, figma, general]
    default: "auto"

  // 视觉后端
  option --vision:
    description: "视觉分析后端。none = 纯 transcript 理解，不做帧提取和 vision 调用"
    choices: [cli, claude, "ollama:<model>", none]
    default: "cli"
    // cli: 调用本地 CLI（由 --llm-command 或 WV_LLM_COMMAND 环境变量配置）
    // claude: 通过 Anthropic API 直接调用（需 ANTHROPIC_API_KEY）
    // ollama:<model>: 本地 Ollama，如 ollama:llava
    // none: 完全跳过视觉分析

  // 转录
  option --transcript:
    description: "转录策略"
    choices: [auto, mlx-whisper, platform-subs]
    default: "auto"

  // 活动检测
  option --activity:
    description: "活动检测后端"
    choices: [auto, mv, ssim]
    default: "auto"

  // 媒体获取
  option --media-access:
    description: "视频获取方式。remote = 不下载视频，依赖平台字幕和远程帧提取"
    choices: [download, remote]
    default: "download"

  // 调参
  option --max-frames:
    description: "最大分析帧数（控制 vision API 成本）"
    type: int
    default: 200

  option --whisper-model:
    description: "Whisper 模型"
    default: "mlx-community/whisper-large-v3-turbo"

  option --llm-command:
    description: "语义/guide LLM 调用命令模板。用 {prompt} 占位，或以 - 结尾表示从 stdin 读取"
    type: string
    // 自动检测顺序：WV_LLM_COMMAND 环境变量 → codex CLI → claude CLI → 报错（不再静默回退到不存在的命令）

  option --llm-timeout:
    description: "语义/guide LLM 调用超时（秒）"
    type: int

  // 平台认证（B 站 1080p+ 需要）
  option --cookies:
    description: "cookies 文件路径（Netscape 格式）"
    type: path

  option --cookies-from-browser:
    description: "从浏览器提取 cookies，可带 profile"
    examples: [chrome, "chrome:Default", "firefox:Profile 1"]

  // 跳过/恢复
  option --skip:
    description: "跳过指定阶段"
    choices: [transcript, semantic, vision, guide]
    multiple: true

  option --force:
    description: "强制重新运行所有阶段（忽略已有中间文件）"
    type: bool
    default: false

  // 缓存
  option --cache:
    description: "Stage 缓存后端"
    choices: [joblib, json, none]
    default: "joblib"

  // 事件流与决策
  option --event-stream:
    description: "结构化事件输出模式"
    choices: [off, auto, jsonl]
    default: "auto"
    // auto: stdout 是 TTY 时不输出 JSONL；stdout 被 pipe 时输出 JSONL
    // jsonl: 始终在 stdout 输出 JSONL 事件
    // off: 不输出结构化事件

  option --decision-mode:
    description: "决策点处理方式"
    choices: [auto, prompt, fail, agent, defaults]
    default: "auto"
    // auto:     TTY 下弹 prompt；非 TTY 下 emit run_failed → exit(1)
    // prompt:   强制 prompt（stdin 非交互时报错退出）
    // fail:     遇到决策点立即 emit run_failed → exit(1)，不 prompt
    // agent:    通过 stdin 读取 JSON 决策响应（双向 JSONL 协议，见下文）
    // defaults: 自动选择每个决策点的 default_option，无需 TTY 或 agent 协议
    //           适合 Claude Code、Codex、CI 等非交互环境

  // 通用
  option --verbose, -v:
    description: "详细日志"
    type: bool
    default: false
```

## wv preflight

```pseudocode
command "wv preflight":

  // 必选参数
  argument INPUT:
    description: "视频文件路径或 URL"
    required: true

  // 认证（同 wv learn）
  option --cookies:
    description: "cookies 文件路径"
    type: path

  option --cookies-from-browser:
    description: "从浏览器提取 cookies"
    examples: [chrome, "chrome:Default"]
```

输出到 **stdout** 的 JSON 报告（不运行 pipeline，仅探测）：

```json
{
  "environment": {
    "ffmpeg": "/opt/homebrew/bin/ffmpeg",
    "ffprobe": "/opt/homebrew/bin/ffprobe",
    "llm_command": "claude -p {prompt}",
    "llm_command_source": "claude CLI (auto-detect)",
    "llm_available": true,
    "whisper_available": true,
    "issues": []
  },
  "source": {
    "platform": "bilibili",
    "title": "Figma Vibe Design 教程",
    "duration": 251,
    "remote_capable": true,
    "subtitle_available": true,
    "subtitle_quality": "sentence_level",
    "danmaku_available": true,
    "cookies_found": true,
    "parts": 1,
    "existing_output": null
  },
  "recommended": {
    "media_access": "remote",
    "transcript": "auto",
    "vision": "cli",
    "decision_mode": "defaults",
    "rationale": [
      "B站视频支持远端获取，无需下载",
      "平台字幕可用（sentence_level）",
      "检测到 claude CLI"
    ]
  },
  "command": "wv learn 'https://...' --media-access remote --decision-mode defaults"
}
```

**issues 枚举（environment.issues）：**

| issue | 含义 |
|-------|------|
| `ffmpeg_not_found` | ffmpeg 不在 PATH，无法处理视频 |
| `ffprobe_not_found` | ffprobe 不在 PATH，无法探测视频元数据 |
| `llm_not_configured` | 未找到 LLM 命令（需设置 WV_LLM_COMMAND 或安装 codex/claude） |
| `whisper_unavailable` | mlx-whisper 包未安装（--transcript mlx-whisper 不可用） |
| `cookies_required` | 平台需要认证，但未提供 cookies（如 B 站 1080p） |

## wv act

```pseudocode
command "wv act":

  argument SEMANTIC_PATH:
    description: "semantic.json 路径（wv learn 产出），或对应目录下的 guide.md（会自动查找同目录的 semantic.json）"
    required: true

  option --step:
    description: "只执行特定步骤，如 '3' 或 '2-5'"
    type: string

  option --dry-run:
    description: "只打印要执行的操作，不实际执行"
    type: bool
    default: false

  option --confirm:
    description: "每步操作前确认"
    type: bool
    default: true

  option --executor:
    description: "执行后端"
    choices: [claude-computer-use]
    default: "claude-computer-use"
```

**`wv act` 读 `semantic.json`，不解析 `guide.md`。** `semantic.json` 包含完整的 `Operation` 序列，是 act 的权威数据来源。

## wv schema

```bash
wv schema
```

输出一个 JSON 对象，描述 wv 的完整能力：所有事件类型及字段、所有决策类型及选项、exit code 含义、主要 CLI 选项。
Agent 在调用 `wv learn` 前应先调用 `wv schema` 获得这份自描述。

```json
{
  "version": "0.1.0",
  "commands": { "learn": {...}, "act": {...}, "schema": {...}, "preflight": {...} },
  "events": {
    "run_started":      {"fields": ["type","timestamp","run_id","stage","message","context"]},
    "stage_started":    {"fields": [...]},
    "task_started":     {"fields": [..., "task_id","parent_task_id","depth"]},
    "task_progress":    {"fields": [..., "task_id","parent_task_id","depth"]},
    "task_completed":   {"fields": [..., "task_id","parent_task_id","depth"]},
    "task_failed":      {"fields": [..., "task_id","parent_task_id","depth"]},
    "plugin_selected":  {"fields": [...], "context_fields": ["plugin","method"]},
    "artifact_written": {"fields": [...], "context_fields": ["path","artifact_type"]},
    "decision_required":{"fields": [...], "context_fields": ["kind","reason_code","options","default_option"]},
    "decision_selected":{"fields": [...], "context_fields": ["kind","selected"]},
    "run_completed":    {"fields": [...], "context_fields": ["output_path","artifacts","stats"]},
    "run_failed":       {"fields": [...], "context_fields": ["error_code","recoverable","suggestion"]}
  },
  "decisions": {
    "remote_to_download":            {"stage":"transcript","options":["download","abort"],"default":"download"},
    "platform_subtitles_to_whisper": {"stage":"transcript","options":["mlx-whisper","abort"],"default":"mlx-whisper"},
    "llm_stage_retry_or_abort":      {"stage":"semantic|guide","options":["retry","abort"],"default":"retry"}
  },
  "exit_codes": {"0":"Success","1":"General error","2":"Agent protocol error","3":"Explicit abort"}
}
```

## 输出路由

所有人类可读日志输出到 **stderr**，结构化 JSONL 事件输出到 **stdout**。
Pipeline 内部的 `print()` 通过 `redirect_stdout(sys.stderr)` 统一路由。

```
stdout  →  JSONL 事件（当 event_stream 生效时）
           agent 模式下同时用于接收来自 stdin 的决策响应
stderr  →  [wv] 进度日志、决策 prompt、错误信息
```

## 事件流

`--event-stream auto|jsonl` 时，stdout 输出 JSONL 事件，每行一个 JSON 对象：

```json
{"type":"run_started","timestamp":"...","run_id":"abc","stage":null,"message":"Run started","context":{"input":"...","media_access":"download","transcript":"auto","vision":"cli"}}
{"type":"stage_started","timestamp":"...","run_id":"abc","stage":"acquire","message":"...","context":{...}}
{"type":"plugin_selected","timestamp":"...","run_id":"abc","stage":"transcript","message":"Plugin selected: code","context":{"plugin":"code","method":"transcript"}}
{"type":"artifact_written","timestamp":"...","run_id":"abc","stage":"acquire","message":"...","context":{"path":"...","artifact_type":"source_info"}}
{"type":"stage_completed","timestamp":"...","run_id":"abc","stage":"acquire","message":"...","context":{"platform":"bilibili",...}}
{"type":"decision_required","timestamp":"...","run_id":"abc","stage":"transcript","message":"...","context":{"kind":"platform_subtitles_to_whisper","reason_code":"platform_subtitles_unreliable","options":["mlx-whisper","abort"],"default_option":"mlx-whisper"}}
{"type":"decision_selected","timestamp":"...","run_id":"abc","stage":"transcript","message":"Decision selected: mlx-whisper","context":{"kind":"platform_subtitles_to_whisper","selected":"mlx-whisper",...}}
{"type":"run_completed","timestamp":"...","run_id":"abc","stage":null,"message":"Run completed","context":{"output_path":"...","artifacts":{"guide_md":"...","semantic_json":"..."},"stats":{"steps":12,"operations":8,"knowledge_points":14,"frames_analyzed":12}}}
{"type":"run_failed","timestamp":"...","run_id":"abc","stage":"semantic","message":"...","context":{"error_code":"llm_error","recoverable":true,"suggestion":"Retry with --llm-timeout 120"}}
```

**事件类型：**

| type | 含义 | stage |
|------|------|-------|
| `run_started` | Pipeline 开始 | — |
| `stage_started` | 阶段开始（同时触发 `task_started`） | acquire / transcript / activity / semantic / vision / guide |
| `stage_completed` | 阶段完成（同时触发 `task_completed`） | 同上 |
| `task_started` | 任务节点开始（可嵌套） | 所在阶段 |
| `task_progress` | 任务中间进度 | 所在阶段 |
| `task_completed` | 任务节点完成 | 所在阶段 |
| `task_failed` | 任务节点失败（不一定致命） | 所在阶段 |
| `plugin_selected` | 插件选定（transcript 或 vision 方式） | transcript / vision |
| `artifact_written` | 产出文件写入 | 所在阶段 |
| `decision_required` | 需要外部决策 | 触发阶段 |
| `decision_selected` | 决策已选择 | 触发阶段 |
| `run_completed` | Pipeline 完成 | — |
| `run_failed` | Pipeline 失败 | 失败阶段（可选） |

**task 事件额外字段：**

| 字段 | 含义 |
|------|------|
| `task_id` | 点分层级 ID，如 `"vision.analyze.step-3"` |
| `parent_task_id` | 父任务 ID（顶层任务无此字段） |
| `depth` | 嵌套深度：0 = stage，1 = 子任务，2 = 子子任务 |

`task_completed` 的 `context` 额外含 `elapsed_s`（任务耗时秒数）。`stage_started/stage_completed` 仍按旧格式发射，不含 task 字段（向后兼容）。

**task_id 命名约定：** `<stage>.<subtask>[.<sub-subtask>]`，例如：
- `acquire.fetch`
- `transcript.transcribe`
- `vision.extract`、`vision.analyze`、`vision.analyze.step-3`
- `guide.synthesize`、`guide.render`

**`run_completed` context 字段：**

| 字段 | 含义 |
|------|------|
| `output_path` | guide.md 路径（主产出） |
| `artifacts.guide_md` | guide.md 绝对路径 |
| `artifacts.semantic_json` | semantic.json 绝对路径 |
| `stats.steps` | RepeatStep 总数 |
| `stats.operations` | Operation 总数 |
| `stats.knowledge_points` | 知识点总数 |
| `stats.frames_analyzed` | 视觉分析帧数（0 = 纯 transcript 模式） |

**`run_failed` context 字段：**

| 字段 | 含义 |
|------|------|
| `error_code` | 见下方 error_code 枚举 |
| `recoverable` | bool：是否可通过修改参数重试 |
| `suggestion` | 建议动作（如 "Retry with --llm-timeout 120"） |

**error_code 枚举：**

| error_code | 含义 | recoverable |
|---|---|---|
| `decision_aborted` | 用户/agent 选了 abort | false |
| `decision_mode_fail` | `--decision-mode fail` 触发 | true |
| `decision_mode_no_tty` | auto/prompt 模式下无 TTY | true（改用 --decision-mode defaults 或 agent） |
| `agent_stdin_timeout` | agent 模式 stdin 超时（30s） | true |
| `agent_stdin_invalid_json` | agent 模式 stdin JSON 无效 | true |
| `agent_decision_kind_mismatch` | agent 响应 kind 不匹配 decision | true |
| `agent_decision_invalid_option` | agent 响应 selected 不在 options 中 | true |
| `llm_not_configured` | 未配置 LLM 命令 | true（设置 WV_LLM_COMMAND 或 --llm-command） |
| `llm_error` | LLM 调用失败或返回无效输出 | true |
| `unexpected` | 未分类异常 | false |

**stderr 进度树示例：**

```
[wv] ▶ acquire
[wv]   ▶ fetch (https://bilibili.com/video/BV...)
[wv]   ✓ fetch — bilibili  字幕: reliable (12.3s)
[wv] ✓ acquire (15.1s)
[wv] ▶ transcript
[wv]   ▶ transcribe (mlx-whisper)
[wv]   ✓ transcribe — 60 段 (whisper) (8.2s)
[wv] ✓ transcript (8.5s)
[wv] ▶ vision
[wv]   ▶ extract keyframes [0/3]
[wv]     extract keyframes [1/3] — 4 frames
[wv]     extract keyframes [2/3] — 4 frames
[wv]     extract keyframes [3/3] — 4 frames
[wv]   ✓ extract keyframes — 12 张关键帧 (3.2s)
[wv]   ▶ analyze frames [0/3]
[wv]     ▶ step 1/3 [0/4]
[wv]     ✓ step 1/3 (4.1s)
[wv]   ✓ analyze frames — 12 帧 (12.0s)
[wv] ✓ vision (15.5s)
```

## 决策流

Pipeline 内部遇到需要人工干预的分支时，抛出 `DecisionRequired` 异常。
CLI 捕获后根据 `--decision-mode` 处理：

```
Pipeline.run()
  └─ raise DecisionRequired(kind, options, default_option, ...)
       │
CLI catch
  ├─ emit decision_required 事件（所有模式）
  ├─ decision_mode == "defaults"（新增）
  │     → 自动选 decision.default_option
  │     → stderr: "[wv] 自动选择默认值: {kind} → {selected}"
  │     → emit decision_selected → _apply_decision → 重新执行 pipeline
  ├─ decision_mode == "fail"
  │     → emit run_failed(error_code="decision_mode_fail") → exit(1)
  ├─ decision_mode == "prompt" / "auto"
  │     → stdin 非交互 → stderr: 建议使用 --decision-mode defaults
  │     →               → emit run_failed(error_code="decision_mode_no_tty") → exit(1)
  │     → stdin 交互   → click.confirm(err=True)
  │          → 用户选 abort → emit run_failed(error_code="decision_aborted") → exit(3)
  │          → 用户选其他  → emit decision_selected → _apply_decision → 重新执行 pipeline
  └─ decision_mode == "agent"（见下节）
       → 从 stdin 读取 JSON 响应
       → 协议错误 → emit run_failed(error_code="agent_*") → exit(2)
       → selected == "abort" → emit run_failed(error_code="decision_aborted") → exit(3)
       → selected 有效 → emit decision_selected → _apply_decision → 重新执行 pipeline
```

**v1 决策点：**

| kind | 触发条件 | options | 默认 |
|------|---------|---------|------|
| `remote_to_download` | remote 模式下无平台字幕可用 | `[download, abort]` | download |
| `platform_subtitles_to_whisper` | 平台字幕不可用或质量不可靠 | `[mlx-whisper, abort]` | mlx-whisper |
| `llm_stage_retry_or_abort` | 语义/guide LLM 调用失败或返回无效 JSON | `[retry, abort]` | retry |

## Agent 决策协议

`--decision-mode agent` 启用双向 JSONL 协议，专为 AI agent 编排设计。

### 协议流

```
wv stdout  →  {"type":"decision_required","context":{"kind":"...","options":[...],...}}
wv stdin   ←  {"kind":"platform_subtitles_to_whisper","selected":"mlx-whisper"}
wv stdout  →  {"type":"decision_selected","context":{"kind":"...","selected":"mlx-whisper",...}}
wv stdout  →  (pipeline 继续执行...)
```

### stdin 响应格式

```json
{"kind": "<decision_kind>", "selected": "<option>"}
```

| 字段 | 说明 |
|------|------|
| `kind` | 必须完全匹配 `decision_required` 事件中的 `context.kind` |
| `selected` | 必须是 `context.options` 数组中的一个值 |

### 错误处理

| 情况 | error_code | exit |
|------|-----------|------|
| stdin EOF 或 30s 内无数据 | `agent_stdin_timeout` | 2 |
| 读取的行不是合法 JSON | `agent_stdin_invalid_json` | 2 |
| `kind` 不匹配当前 decision | `agent_decision_kind_mismatch` | 2 |
| `selected` 不在 `options` 中 | `agent_decision_invalid_option` | 2 |
| `selected == "abort"` | `decision_aborted` | 3 |

### 注意事项

- Agent 必须同时开启 `--event-stream jsonl`，否则 stdout 无事件输出
- stdin 响应必须是单行 JSON（`\n` 结尾），不能跨行
- 决策响应只需响应当前 `decision_required` 事件，不需要响应其他事件
- `wv` 每次只有一个悬挂决策（串行），agent 无需维护决策队列

## Exit Codes

| Exit code | 含义 | 触发场景 |
|-----------|------|---------|
| 0 | 成功 | `run_completed` |
| 1 | 一般错误 | 未捕获异常、`--decision-mode fail`、非 TTY auto/prompt 模式 |
| 2 | Agent 协议错误 | stdin 超时/解析失败/kind 不匹配/option 无效（仅 agent 模式） |
| 3 | 显式 abort | 用户或 agent 选择了 `abort` |

## Agent 集成架构

```
┌─────────────────────────────────────────────────────────────┐
│                     Agent Layer                              │
│  Claude Code (Plugin) │ Codex (AGENTS.md) │ 任意 MCP 客户端  │
└────────┬────────────────────┬──────────────────┬────────────┘
         │                    │                  │
    ┌────▼────┐          ┌───▼───┐         ┌───▼───┐
    │ Plugin  │          │AGENTS │         │  MCP  │
    │ Skill + │          │  .md  │         │Server │
    │ MCP     │          │       │         │       │
    └────┬────┘          └───┬───┘         └───┬───┘
         │                   │                 │
         ▼                   ▼                 ▼
┌─────────────────────────────────────────────────────────────┐
│                     wv CLI（通用基座）                       │
│  wv preflight │ wv learn │ wv act │ wv schema               │
│  --decision-mode defaults │ --event-stream jsonl             │
└─────────────────────────────────────────────────────────────┘
```

三条接入路径：

| 接入方式 | 适用 agent | 配置文件 |
|---------|-----------|---------|
| **Claude Code Plugin** | Claude Code | `withvideo-plugin/` 目录（Skill + MCP + bin） |
| **通用 CLI 指南** | Codex、OpenClaw、自定义 agent | `AGENTS.md` |
| **MCP Server** | 任意 MCP 客户端 | `withvideo-plugin/.mcp.json` |

### Claude Code Plugin 结构

```
withvideo-plugin/
├── .claude-plugin/
│   └── plugin.json                  # 插件清单
├── skills/
│   └── learn-from-video/
│       └── SKILL.md                 # 编排 wv 工作流的 Skill
├── .mcp.json                        # 注册 MCP Server（wv_preflight, wv_learn, wv_schema）
└── bin/
    └── wv-env                       # 环境包装脚本（确保 PATH 含 /opt/homebrew/bin）
```

Skill 工作流（`skills/learn-from-video/SKILL.md`）：

```
1. wv preflight <url>     → 探测环境 + 视频源，向用户展示状态和推荐策略
2. 等用户确认策略
3. wv learn <url> [推荐参数] --decision-mode defaults
4. 读取 guide.md，向用户报告关键结果
```

### MCP Server 工具

`wv mcp`（由 `python -m withvideo.mcp_server` 启动）暴露三个工具：

| 工具 | 说明 |
|-----|------|
| `wv_preflight(source, cookies_from_browser?)` | 探测环境 + 视频源，返回推荐策略 |
| `wv_learn(source, media_access?, vision?, ...)` | 运行完整 pipeline，返回结果和事件日志 |
| `wv_schema()` | 返回 wv 的自描述 schema |

## 使用示例

```bash
# ── 预检 ──────────────────────────────────────────────────────
# 探测 B 站视频（检查环境 + 字幕可用性 + 推荐参数）
wv preflight https://www.bilibili.com/video/BV1xxxxx

# ── 基本用法 ──────────────────────────────────────────────────
# YouTube 视频（自动下载 + 利用平台字幕/章节）
wv learn https://www.youtube.com/watch?v=xxxxx

# B 站视频（远端模式，无需下载）
wv learn https://www.bilibili.com/video/BV1xxxxx --media-access remote

# B 站视频（用浏览器 cookies 获取 1080p）
wv learn https://www.bilibili.com/video/BV1xxxxx --cookies-from-browser chrome

# 本地文件
wv learn tutorial.mp4

# ── 非交互 / Agent 环境 ───────────────────────────────────────
# defaults 模式：自动选择所有决策点的默认值（适合 Claude Code、Codex、CI）
wv learn tutorial.mp4 --decision-mode defaults

# 同上，同时强制 JSONL 事件输出
wv learn tutorial.mp4 --decision-mode defaults --event-stream jsonl

# Agent 模式（双向 JSONL）：agent 从 stdout 读事件，向 stdin 写决策
wv learn tutorial.mp4 --decision-mode agent --event-stream jsonl 2>/dev/null

# 简单 agent 测试（预先管道决策响应）
echo '{"kind":"platform_subtitles_to_whisper","selected":"mlx-whisper"}' | \
  wv learn tutorial.mp4 --decision-mode agent --event-stream jsonl 2>/dev/null

# ── 成本控制 ─────────────────────────────────────────────────
# 纯 transcript 模式（不做 vision 分析，最快最省）
wv learn tutorial.mp4 --vision none

# 用本地模型（不花钱）
wv learn tutorial.mp4 --vision ollama:llava

# 限制 vision 帧数（省钱试水）
wv learn long-tutorial.mp4 --max-frames 50

# ── 调试/恢复 ────────────────────────────────────────────────
# 只重新生成 guide（跳过其他阶段，利用缓存）
wv learn tutorial.mp4 --skip transcript --skip semantic --skip vision

# 强制重跑所有阶段
wv learn tutorial.mp4 --force

# ── 执行操作 ─────────────────────────────────────────────────
wv act .withvideo/tutorial/semantic.json --dry-run
wv act .withvideo/tutorial/semantic.json --step 3
wv act .withvideo/tutorial/guide.md --dry-run  # 自动找同目录 semantic.json

# ── 自描述 ───────────────────────────────────────────────────
wv schema
wv schema | jq '.decisions'
wv schema | jq '.exit_codes'

# ── 检查 exit code ────────────────────────────────────────────
wv learn tutorial.mp4 --decision-mode fail; echo "exit: $?"   # → exit: 1
```
