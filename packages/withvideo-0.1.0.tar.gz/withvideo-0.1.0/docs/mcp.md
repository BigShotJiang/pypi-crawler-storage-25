# WithVideo MCP Server

`WithVideo` 通过 **MCP**（Model Context Protocol）把 `wv` 的能力暴露给任何兼容 MCP 的 Agent/IDE——Claude Desktop、Claude Code、Cursor、Cline、Continue 等。

## 安装

```bash
# 任选一种 whisper backend
pip install "withvideo[mcp,faster-whisper,youtube,bilibili]"   # 跨平台
pip install "withvideo[mcp,whisper,youtube,bilibili]"          # Apple Silicon
```

启动 MCP server：

```bash
python -m withvideo.mcp_server
```

（MCP clients 通常会自己 spawn 这个子进程，你不用手动跑。）

## 暴露的 Tools

| Tool | 作用 |
|------|------|
| `wv_schema()` | 返回 wv 的自描述 API（decisions / events / exit codes） |
| `wv_preflight(source)` | 探测环境 + 视频源，返回建议策略 |
| `wv_status(work_dir)` | 查询一次已有 learn run 的状态 |
| `wv_learn(source, ...)` | 跑完整 learn 流水线（视频→`guide.md`+`semantic.json`）|
| `wv_act(semantic_path, ...)` | 按 `semantic.json` 执行 Tier 0/1 操作（Shell / FileWrite / URLOpen / ClaudeCode） |

## 接入各家 MCP Client

所有 client 的接入方式基本一致：在 MCP 配置 JSON 里加一个 server 条目。

### Claude Desktop

配置文件位置：

- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "withvideo": {
      "command": "python",
      "args": ["-m", "withvideo.mcp_server"],
      "env": {
        "PATH": "/opt/homebrew/bin:/usr/local/bin:${PATH}",
        "WV_LLM_COMMAND": "claude -p {prompt}"
      }
    }
  }
}
```

改完重启 Claude Desktop。在对话里说"帮我分析这个 YouTube 视频 https://..."，Claude 会自己调 `wv_preflight` + `wv_learn`。

### Claude Code

Claude Code 支持项目级的 `.mcp.json`（放在项目根目录）：

```json
{
  "mcpServers": {
    "withvideo": {
      "command": "python",
      "args": ["-m", "withvideo.mcp_server"],
      "env": {
        "PATH": "/opt/homebrew/bin:/usr/local/bin:${PATH}"
      }
    }
  }
}
```

或者直接用 WithVideo 提供的 Plugin（见 [`withvideo-plugin/`](../withvideo-plugin/)），它自带 MCP 配置 + Skill：

```bash
claude --plugin-dir ./withvideo-plugin
```

### Cursor

`~/.cursor/mcp.json` 或项目 `.cursor/mcp.json`：

```json
{
  "mcpServers": {
    "withvideo": {
      "command": "python",
      "args": ["-m", "withvideo.mcp_server"],
      "env": { "PATH": "/opt/homebrew/bin:${PATH}" }
    }
  }
}
```

重启 Cursor 后，AI 面板会出现 `withvideo` 下的 5 个 tools。

### Cline (VSCode)

打开 Cline 设置 → MCP Servers → Edit JSON：

```json
{
  "mcpServers": {
    "withvideo": {
      "command": "python",
      "args": ["-m", "withvideo.mcp_server"]
    }
  }
}
```

### Continue

`~/.continue/config.yaml` 加 `mcpServers` 段：

```yaml
mcpServers:
  - name: withvideo
    command: python
    args:
      - -m
      - withvideo.mcp_server
```

## 环境变量

| 变量 | 用途 |
|------|------|
| `WV_LLM_COMMAND` | 覆盖默认 LLM 命令（如 `claude -p {prompt}` / `codex exec -`） |
| `ANTHROPIC_API_KEY` | `--vision claude` 必须 |
| `PATH` | 要确保包含 `ffmpeg` 所在目录（macOS 通常是 `/opt/homebrew/bin`） |

## 工作流示例

### 学完一个教程视频 + 自动执行

```
User: 帮我分析 https://www.bilibili.com/video/BV1EowjzKE5x/ 并执行里面的操作
AI: [调用 wv_preflight] → 确认策略 → [调用 wv_learn]
    产出 .withvideo/xxx/guide.md + semantic.json
    → [调用 wv_act with dry_run=True] 预览路由决策
    → 向用户确认后 → [调用 wv_act with no_confirm=True] 真实执行
```

### 只跑 learn 不 act

对只想看懂视频、不需要自动执行的场景，调 `wv_learn` 就够了，完全跳过 `wv_act`。

## 常见问题

| 现象 | 解决 |
|------|------|
| `mcp package not installed` | 装 `pip install "withvideo[mcp]"` |
| `ffmpeg not found` | MCP env 里补 `"PATH": "/opt/homebrew/bin:${PATH}"` |
| `llm_not_configured` | 设 `WV_LLM_COMMAND` 或装 Claude/Codex CLI |
| 长视频 `wv_learn` 超时 | 传 `llm_timeout=900`（秒）或加 `skip=["vision"]` |
| `wv_act` 报危险命令被拒 | 传 `allow_dangerous=True`（慎用），或先 `dry_run=True` 看是哪一步 |

## 参考

- 完整 CLI schema：`wv schema`
- 事件流 JSONL 协议：见仓库 [AGENTS.md](../AGENTS.md)
- Plugin 源码：[`withvideo-plugin/`](../withvideo-plugin/)
