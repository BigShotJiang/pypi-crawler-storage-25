"""act_with_video CLI — execute semantic operations from a wv learn guide."""

from __future__ import annotations

import sys
from pathlib import Path

from .models import ActConfig
from .reporter import ActReporter
from .router import OperationRouter
from .runner import ActRunner


def _cmd_run(
    guide_path: Path,
    *,
    step: str | None = None,
    dry_run: bool = False,
    confirm: bool = True,
    executor: str = "auto",
    allow_dangerous: bool = False,
) -> None:
    if not guide_path.exists():
        print(f"[act] Error: guide not found: {guide_path}", file=sys.stderr)
        sys.exit(1)

    cfg = ActConfig(
        browser_enabled=(executor in ("auto", "browser")),
        computer_use_enabled=(executor in ("auto", "computer-use")),
        allow_dangerous=allow_dangerous,
    )

    router = OperationRouter(cfg)
    reporter = ActReporter()
    runner = ActRunner(router, reporter, cfg)

    runner.run(
        guide_path,
        step_filter=step,
        dry_run=dry_run,
        confirm=confirm,
    )


def main() -> None:
    """Standalone CLI entry point (python -m act_with_video)."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="wv-act",
        description="Execute semantic operations from a wv learn guide.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="Execute a guide")
    run_parser.add_argument("guide", type=Path, help="Path to guide.md or semantic.json")
    run_parser.add_argument("--step", default=None, help="Steps to execute (e.g. '3', '1-5', '1,3,5')")
    run_parser.add_argument("--dry-run", action="store_true", help="Preview without executing")
    run_parser.add_argument("--confirm", action="store_true", default=True, dest="confirm")
    run_parser.add_argument("--no-confirm", action="store_false", dest="confirm")
    run_parser.add_argument(
        "--executor",
        choices=["auto", "direct-only", "browser", "computer-use"],
        default="auto",
    )
    run_parser.add_argument(
        "--allow-dangerous",
        action="store_true",
        default=False,
        dest="allow_dangerous",
        help="Allow shell commands matching dangerous patterns (rm -rf, sudo, curl|sh, ...)",
    )

    args = parser.parse_args()

    if args.command == "run":
        _cmd_run(
            args.guide,
            step=args.step,
            dry_run=args.dry_run,
            confirm=args.confirm,
            executor=args.executor,
            allow_dangerous=args.allow_dangerous,
        )


if __name__ == "__main__":
    main()
