"""act_with_video data models.

Consumes SemanticOperation objects from wv learn's semantic.json and translates
them into execution results via a multi-tier executor architecture.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Semantic input (mirrors withvideo.models.Operation)
# ---------------------------------------------------------------------------

@dataclass
class SemanticOperation:
    """A human-level operation extracted by wv learn from transcript/vision.

    This is the stable contract between learn and act. It describes *what* to
    do (intent + target), not *how* to do it at the pixel level.
    """
    capability: str = "ui_action"   # "ui_action" | "text_input"
    action: str = ""                # per-capability verb (see below)
    target: str = ""                # natural-language description of the target element
    intent: str = ""                # why this operation matters (user-facing goal)
    app_context: str = ""           # application / environment name
    source: str = ""                # "transcript" | "vision" | "transcript+vision"
    confidence: float = 1.0
    text_content: str = ""          # for text_input: exact text to type / run
    visual_hint: str = ""           # vision-derived description to help locate target
    description: str = ""           # human-readable summary
    payload: dict[str, Any] = field(default_factory=dict)  # extra structured data (file, language, etc.)

    # ui_action.action values: navigate, open, select, download, dismiss, confirm
    # text_input.action values: search_text, enter_text, run_command, write_code,
    #                           input_prompt, send_prompt


@dataclass
class VerificationExpectation:
    """Expected outcome after a set of operations — produced by wv learn, checked by act."""
    kind: str = "visual"            # "visual" | "text_present" | "url_match" | "state_change"
    expected: str = ""              # description of the expected state
    context: str = ""               # what step/operation this validates
    source: str = ""                # "transcript" | "vision"


# ---------------------------------------------------------------------------
# Execution results (multi-tier)
# ---------------------------------------------------------------------------

@dataclass
class ExecutionResult:
    """One operation's execution outcome."""
    operation: SemanticOperation
    executor_type: str              # "shell" | "claude_code" | "file_write" | "url_open" | "computer_use"
    success: bool = False
    output: str = ""                # stdout/stderr, AI response, etc.
    error: str = ""
    skipped: bool = False           # True if user chose to skip
    skip_reason: str = ""
    elapsed_s: float = 0.0


@dataclass
class VerificationResult:
    """Result of checking expectations after execution."""
    passed: bool
    expectation: VerificationExpectation
    actual: str = ""                # what was actually observed
    detail: str = ""                # explanation of pass/fail


@dataclass
class ActReport:
    """Full execution report for one guide."""
    source: str
    results: list[ExecutionResult] = field(default_factory=list)
    total_ops: int = 0
    executed: int = 0
    succeeded: int = 0
    failed: int = 0
    skipped: int = 0


@dataclass
class ActConfig:
    """Configuration for the act runner."""
    browser_enabled: bool = False
    computer_use_enabled: bool = False
    stop_on_failure: bool = False
    claude_timeout: int = 300
    allow_dangerous: bool = False        # bypass shell safety guard
    file_write_subdir: str | None = "wv_act_output"  # sandbox dir for file_write


# ---------------------------------------------------------------------------
# Legacy execution layer (retained for Tier 3 computer use)
# ---------------------------------------------------------------------------

@dataclass
class ComputerAction:
    """A vendor-facing atomic action (aligned with Claude computer use schema)."""
    action: str                     # "screenshot" | "left_click" | "type" | "key" | "scroll" | "left_click_drag"
    coordinate: tuple[int, int] | None = None
    text: str = ""
    key: str = ""
    scroll_direction: str = ""      # "up" | "down" | "left" | "right"
    scroll_amount: int = 3
    start_coordinate: tuple[int, int] | None = None  # for left_click_drag


@dataclass
class ExecutionStep:
    """One unit of execution: a SemanticOperation translated into ComputerActions.

    Retained for Tier 3 (computer use) internal use.
    """
    operation: SemanticOperation
    actions: list[ComputerAction] = field(default_factory=list)
    ui_adapted: bool = False
    adaptation_note: str = ""
    outcome_verified: bool | None = None


@dataclass
class ActPlan:
    """Full execution plan for one guide / semantic.json."""
    source: str                     # path to semantic.json
    steps: list[ExecutionStep] = field(default_factory=list)
    expectations: list[VerificationExpectation] = field(default_factory=list)
