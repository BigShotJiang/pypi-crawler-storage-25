"""Act runner — main execution loop that consumes semantic.json."""

from __future__ import annotations

import sys
from pathlib import Path

from .guide_reader import read_guide
from .models import ActConfig, ActReport, ExecutionResult, SemanticOperation
from .reporter import ActReporter
from .router import OperationRouter


class ActRunner:
    """Execute all operations from a guide via the multi-tier router."""

    def __init__(
        self,
        router: OperationRouter,
        reporter: ActReporter,
        cfg: ActConfig | None = None,
    ) -> None:
        self.router = router
        self.reporter = reporter
        self.cfg = cfg or ActConfig()

    def run(
        self,
        guide_path: Path,
        *,
        step_filter: str | None = None,
        dry_run: bool = False,
        confirm: bool = True,
    ) -> ActReport:
        ops, expectations = read_guide(guide_path)

        if step_filter:
            ops = _filter_ops(ops, step_filter)

        report = ActReport(source=str(guide_path), total_ops=len(ops))
        self.reporter.act_started(str(guide_path), len(ops))
        cwd = Path.cwd()

        for i, op in enumerate(ops):
            executor = self.router.route(op)
            self.reporter.operation_preview(op, executor.executor_type)

            # Confirm before execution (unless dry-run or --no-confirm)
            if confirm and not dry_run:
                proceed = _confirm_tty(i, op, executor.executor_type)
                if not proceed:
                    result = ExecutionResult(
                        op, executor.executor_type,
                        skipped=True, skip_reason="user_skipped",
                    )
                    report.results.append(result)
                    report.skipped += 1
                    self.reporter.operation_skipped(result)
                    continue

            # Execute
            result = executor.execute(op, cwd=cwd, dry_run=dry_run)
            report.results.append(result)
            report.executed += 1

            if result.success:
                report.succeeded += 1
            else:
                report.failed += 1
                if self.cfg.stop_on_failure:
                    break

            self.reporter.operation_completed(result)

        self.reporter.act_completed(report)
        return report


def _filter_ops(
    ops: list[SemanticOperation], spec: str,
) -> list[SemanticOperation]:
    """Parse step filter like '3', '3-5', '1,3,5' and return matching ops (1-based)."""
    indices: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            lo, hi = part.split("-", 1)
            indices.update(range(int(lo), int(hi) + 1))
        else:
            indices.add(int(part))
    # Convert 1-based to 0-based
    return [op for i, op in enumerate(ops) if (i + 1) in indices]


def _confirm_tty(index: int, op: SemanticOperation, executor_type: str) -> bool:
    """Prompt user for Y/n confirmation on stderr/stdin."""
    if not sys.stdin.isatty():
        return True  # non-interactive → proceed

    desc = op.description or f"{op.capability}/{op.action}"
    prompt = f"  Execute [{index + 1}] ({executor_type}) {desc}? [Y/n/q] "
    try:
        answer = input(prompt).strip().lower()
    except (EOFError, KeyboardInterrupt):
        return False

    if answer in ("q", "quit"):
        raise KeyboardInterrupt
    return answer in ("", "y", "yes")
