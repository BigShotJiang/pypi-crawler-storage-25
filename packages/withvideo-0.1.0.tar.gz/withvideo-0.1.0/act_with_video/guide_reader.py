"""Parse wv learn's output (guide.md or semantic.json) into SemanticOperation objects."""

from __future__ import annotations

import json
import re
from pathlib import Path

from .models import SemanticOperation, VerificationExpectation


def read_guide(path: Path) -> tuple[list[SemanticOperation], list[VerificationExpectation]]:
    """Read a guide.md or semantic.json and return operations + expectations.

    If a ``.md`` is given and ``semantic.json`` exists in the same directory,
    that takes precedence (it is the machine-facing authority).
    """
    if path.suffix == ".json":
        return _read_semantic_json(path)

    # Auto-discover semantic.json next to guide.md
    semantic_sibling = path.parent / "semantic.json"
    if semantic_sibling.exists():
        return _read_semantic_json(semantic_sibling)

    # Fallback: parse guide.md comment blocks
    return _read_guide_md(path)


def _read_semantic_json(path: Path) -> tuple[list[SemanticOperation], list[VerificationExpectation]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    ops: list[SemanticOperation] = []
    expectations: list[VerificationExpectation] = []

    for step in data.get("steps") or []:
        for op_dict in step.get("operations") or []:
            ops.append(_dict_to_op(op_dict))
        for exp_dict in step.get("expectations") or []:
            expectations.append(VerificationExpectation(
                kind=exp_dict.get("kind") or "visual",
                expected=exp_dict.get("expected") or "",
                context=exp_dict.get("context") or "",
                source=exp_dict.get("source") or "",
            ))

    return ops, expectations


def _read_guide_md(path: Path) -> tuple[list[SemanticOperation], list[VerificationExpectation]]:
    """Extract operations from <!-- withvideo:operations ... --> comment blocks."""
    text = path.read_text(encoding="utf-8")
    ops: list[SemanticOperation] = []

    pattern = re.compile(
        r"<!--\s*withvideo:operations\s*(\[.*?\])\s*-->",
        re.DOTALL,
    )
    for m in pattern.finditer(text):
        try:
            items = json.loads(m.group(1))
        except json.JSONDecodeError:
            continue
        for item in items:
            if isinstance(item, dict) and item.get("description"):
                ops.append(_dict_to_op(item))

    return ops, []


def _dict_to_op(d: dict) -> SemanticOperation:
    payload = d.get("payload") or {}
    return SemanticOperation(
        capability=d.get("capability") or d.get("type") or "ui_action",
        action=d.get("action") or "",
        target=d.get("target") or "",
        intent=d.get("intent") or "",
        app_context=d.get("app_context") or "",
        source=d.get("source") or "",
        confidence=float(d.get("confidence") or 1.0),
        text_content=d.get("text_content") or payload.get("command") or "",
        visual_hint=d.get("visual_hint") or "",
        description=d.get("description") or "",
        payload=payload,
    )
