"""act_with_video — executes semantic operations from wv learn guides."""
