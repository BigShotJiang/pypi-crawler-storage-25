"""Executor protocol — all execution backends implement this interface."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from ..models import ExecutionResult, SemanticOperation


class ExecutorBackend(Protocol):
    """Execute a single SemanticOperation."""

    @property
    def executor_type(self) -> str:
        """Identifier for this executor type (e.g., 'shell', 'claude_code')."""
        ...

    def execute(
        self,
        op: SemanticOperation,
        *,
        cwd: Path,
        dry_run: bool = False,
    ) -> ExecutionResult:
        """Execute the operation and return result.

        Args:
            op: The operation to execute.
            cwd: Working directory for execution.
            dry_run: If True, describe what would happen without doing it.
        """
        ...
