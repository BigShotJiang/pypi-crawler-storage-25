"""Shell executor — runs commands via subprocess (Tier 0)."""

from __future__ import annotations

import re
import subprocess
import time
from pathlib import Path

from ..models import ExecutionResult, SemanticOperation


# Patterns we refuse to run silently. These match dangerous shell idioms;
# even with --no-confirm, hitting one of these requires explicit allow_dangerous=True.
_DANGER_PATTERNS = (
    re.compile(r"\brm\s+(-[a-zA-Z]*r[a-zA-Z]*f|-[a-zA-Z]*f[a-zA-Z]*r)\b"),  # rm -rf, rm -fr
    re.compile(r"\bsudo\b"),
    re.compile(r"\bmkfs\b"),
    re.compile(r"\bdd\s+if=.*\s+of=/dev/"),
    re.compile(r":\(\)\s*\{.*\}\s*;\s*:"),                                   # fork bomb
    re.compile(r"\bchmod\s+-R\s+0?777\b"),
    re.compile(r"(curl|wget)\s+[^\|;]+\s*\|\s*(sh|bash|zsh)\b"),             # curl|sh
    re.compile(r"^\s*>\s*/dev/sd[a-z]"),
)


def is_dangerous_command(cmd: str) -> str | None:
    """Return a human-readable reason if *cmd* matches a dangerous pattern, else None."""
    for pat in _DANGER_PATTERNS:
        m = pat.search(cmd)
        if m:
            return f"matches dangerous pattern: {m.group(0)!r}"
    return None


class ShellExecutor:
    """Execute shell commands directly via subprocess.

    Refuses to run obviously dangerous commands (rm -rf, sudo, curl|sh, ...)
    unless ``allow_dangerous=True`` is passed at construction.
    """

    executor_type = "shell"

    def __init__(self, *, allow_dangerous: bool = False, timeout: int = 120) -> None:
        self._allow_dangerous = allow_dangerous
        self._timeout = timeout

    def execute(
        self,
        op: SemanticOperation,
        *,
        cwd: Path,
        dry_run: bool = False,
    ) -> ExecutionResult:
        cmd = op.text_content
        if not cmd:
            return ExecutionResult(
                op, self.executor_type, error="No command text"
            )

        danger = is_dangerous_command(cmd)
        if danger and not self._allow_dangerous:
            return ExecutionResult(
                op, self.executor_type,
                error=f"Refused: command {danger}. Re-run interactively or pass --allow-dangerous.",
            )

        if dry_run:
            preview = f"[dry-run] $ {cmd}"
            if danger:
                preview = f"[dry-run] (DANGEROUS, would refuse) $ {cmd}"
            return ExecutionResult(
                op, self.executor_type, success=True,
                output=preview,
            )

        t0 = time.monotonic()
        try:
            result = subprocess.run(
                cmd, shell=True, cwd=cwd,
                capture_output=True, text=True, timeout=self._timeout,
            )
            return ExecutionResult(
                op, self.executor_type,
                success=(result.returncode == 0),
                output=result.stdout,
                error=result.stderr,
                elapsed_s=time.monotonic() - t0,
            )
        except subprocess.TimeoutExpired:
            return ExecutionResult(
                op, self.executor_type,
                error=f"Command timed out ({self._timeout}s)",
                elapsed_s=time.monotonic() - t0,
            )
        except Exception as exc:
            return ExecutionResult(
                op, self.executor_type,
                error=str(exc),
                elapsed_s=time.monotonic() - t0,
            )
