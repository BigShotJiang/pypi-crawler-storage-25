"""Claude computer use executor.

Translates SemanticOperation → ComputerAction using Claude's computer use API.
This is the primary P0 executor for ui_action capability.
"""

from __future__ import annotations

from ..models import ComputerAction, ExecutionStep, SemanticOperation

# ---------------------------------------------------------------------------
# Action mapping
# ---------------------------------------------------------------------------

# Canonical ui_action verbs (from design/00-data-structures.md)
UI_ACTIONS = frozenset({"navigate", "open", "select", "download", "dismiss", "confirm"})

# Canonical text_input verbs
TEXT_ACTIONS = frozenset({"search_text", "enter_text", "run_command", "write_code"})

# text_input actions that submit with Return after typing
_SUBMIT_ACTIONS = frozenset({"run_command", "search_text"})


class ClaudeComputerUseExecutor:
    """Uses Claude's computer use tools to execute SemanticOperations.

    Planning phase: screenshot → vision call to locate target → build ComputerActions.
    Execution phase: dispatch each ComputerAction to the computer use API.
    """

    def plan(self, operation: SemanticOperation) -> ExecutionStep:
        step = ExecutionStep(operation=operation)

        if operation.capability == "ui_action":
            step = self._plan_ui_action(operation, step)
        elif operation.capability == "text_input":
            step = self._plan_text_input(operation, step)

        return step

    def _plan_ui_action(self, op: SemanticOperation, step: ExecutionStep) -> ExecutionStep:
        # Always take a screenshot first to locate the target
        step.actions.append(ComputerAction(action="screenshot"))
        # Placeholder: actual vision call to locate target goes here
        # After locating: step.actions.append(ComputerAction(action="left_click", coordinate=(...)))
        step.adaptation_note = (
            f"Need screenshot analysis to locate: {op.target or op.description}"
        )
        return step

    def _plan_text_input(self, op: SemanticOperation, step: ExecutionStep) -> ExecutionStep:
        if op.text_content:
            step.actions.append(ComputerAction(action="type", text=op.text_content))
            if op.action in _SUBMIT_ACTIONS:
                step.actions.append(ComputerAction(action="key", key="Return"))
        return step

    def execute(self, step: ExecutionStep) -> ExecutionStep:
        """Execute planned actions. Stub — real implementation calls computer use API."""
        raise NotImplementedError(
            "ClaudeComputerUseExecutor.execute() requires computer use API integration"
        )
