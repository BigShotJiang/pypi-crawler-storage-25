"""Executor adapters — translate SemanticOperation → ComputerAction lists."""
