"""Claude Code CLI executor — delegates to `claude` CLI (Tier 1)."""

from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path

from ..models import ActConfig, ExecutionResult, SemanticOperation


def _find_claude_binary() -> str:
    """Locate the claude CLI binary."""
    found = shutil.which("claude")
    if found:
        return found
    for directory in (
        Path.home() / ".local" / "bin",
        Path("/opt/homebrew/bin"),
        Path("/usr/local/bin"),
    ):
        candidate = directory / "claude"
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return "claude"


class ClaudeCodeExecutor:
    """Execute operations by delegating to the Claude Code CLI."""

    executor_type = "claude_code"

    def __init__(self, cfg: ActConfig | None = None) -> None:
        self._claude_bin = _find_claude_binary()
        self._timeout = (cfg.claude_timeout if cfg else None) or 300

    def execute(
        self,
        op: SemanticOperation,
        *,
        cwd: Path,
        dry_run: bool = False,
    ) -> ExecutionResult:
        prompt = self._build_prompt(op)
        if not prompt:
            return ExecutionResult(
                op, self.executor_type, error="No prompt text"
            )

        if dry_run:
            preview = prompt[:100].replace("\n", " ")
            return ExecutionResult(
                op, self.executor_type, success=True,
                output=f"[dry-run] claude -p '{preview}...'",
            )

        t0 = time.monotonic()
        try:
            result = subprocess.run(
                [self._claude_bin, "--dangerously-skip-permissions", "-p", prompt],
                cwd=cwd,
                capture_output=True,
                text=True,
                stdin=subprocess.DEVNULL,
                timeout=self._timeout,
            )
            return ExecutionResult(
                op, self.executor_type,
                success=(result.returncode == 0),
                output=result.stdout,
                error=result.stderr,
                elapsed_s=time.monotonic() - t0,
            )
        except subprocess.TimeoutExpired:
            return ExecutionResult(
                op, self.executor_type,
                error=f"Claude CLI timed out ({self._timeout}s)",
                elapsed_s=time.monotonic() - t0,
            )
        except FileNotFoundError:
            return ExecutionResult(
                op, self.executor_type,
                error=f"Claude CLI not found at {self._claude_bin}",
                elapsed_s=time.monotonic() - t0,
            )

    def _build_prompt(self, op: SemanticOperation) -> str:
        parts: list[str] = []
        if op.intent:
            parts.append(f"目标：{op.intent}")
        if op.text_content:
            parts.append(op.text_content)
        elif op.description:
            parts.append(op.description)
        return "\n".join(parts)
