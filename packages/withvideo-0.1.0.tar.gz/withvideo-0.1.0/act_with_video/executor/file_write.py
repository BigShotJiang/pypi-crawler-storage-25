"""File write executor — writes content to files (Tier 0).

Refuses absolute paths and any path that escapes the working directory.
Default ``output_subdir`` ("wv_act_output") keeps writes contained beneath cwd.
"""

from __future__ import annotations

import os
import time
from pathlib import Path

from ..models import ExecutionResult, SemanticOperation


def _resolve_safe(filename: str, cwd: Path, output_subdir: str | None) -> Path:
    """Resolve *filename* against *cwd*, refusing escapes.

    - absolute paths or ``~`` expansions are rejected
    - any ``..`` traversal that lands outside cwd is rejected
    - relative paths land under ``cwd / output_subdir`` (when set), else cwd
    """
    raw = filename.strip()
    if not raw:
        raise ValueError("empty filename")

    # Reject obviously unsafe forms before any resolution.
    if os.path.isabs(raw) or raw.startswith("~"):
        raise ValueError(f"absolute / home paths are not allowed: {raw!r}")

    base = cwd / output_subdir if output_subdir else cwd
    candidate = (base / raw).resolve()
    base_resolved = base.resolve()

    # Path.is_relative_to is 3.9+; we target 3.11+.
    try:
        candidate.relative_to(base_resolved)
    except ValueError as exc:
        raise ValueError(
            f"path escapes working directory: {raw!r} → {candidate}"
        ) from exc

    return candidate


class FileWriteExecutor:
    """Write text content directly to a file under the working directory."""

    executor_type = "file_write"

    def __init__(self, *, output_subdir: str | None = "wv_act_output") -> None:
        # output_subdir=None means write directly into cwd (still sandboxed).
        self._output_subdir = output_subdir

    def execute(
        self,
        op: SemanticOperation,
        *,
        cwd: Path,
        dry_run: bool = False,
    ) -> ExecutionResult:
        filename = op.payload.get("file") or op.target or "output.txt"
        content = op.text_content or ""

        try:
            path = _resolve_safe(filename, cwd, self._output_subdir)
        except ValueError as exc:
            return ExecutionResult(
                op, self.executor_type,
                error=f"Refused: {exc}",
            )

        if dry_run:
            return ExecutionResult(
                op, self.executor_type, success=True,
                output=f"[dry-run] Write {len(content)} chars to {path}",
            )

        t0 = time.monotonic()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return ExecutionResult(
                op, self.executor_type, success=True,
                output=f"Written {len(content)} chars to {path}",
                elapsed_s=time.monotonic() - t0,
            )
        except Exception as exc:
            return ExecutionResult(
                op, self.executor_type,
                error=str(exc),
                elapsed_s=time.monotonic() - t0,
            )
