"""URL open executor — opens URLs in the default browser (Tier 0)."""

from __future__ import annotations

import platform
import subprocess
import time
from pathlib import Path

from ..models import ExecutionResult, SemanticOperation


class URLOpenExecutor:
    """Open a URL in the system's default browser."""

    executor_type = "url_open"

    def execute(
        self,
        op: SemanticOperation,
        *,
        cwd: Path,
        dry_run: bool = False,
    ) -> ExecutionResult:
        url = op.target or op.text_content or ""
        if not url:
            return ExecutionResult(
                op, self.executor_type, error="No URL provided"
            )

        if dry_run:
            return ExecutionResult(
                op, self.executor_type, success=True,
                output=f"[dry-run] open {url}",
            )

        t0 = time.monotonic()
        try:
            cmd = "open" if platform.system() == "Darwin" else "xdg-open"
            subprocess.run([cmd, url], check=True, timeout=10)
            return ExecutionResult(
                op, self.executor_type, success=True,
                output=f"Opened {url}",
                elapsed_s=time.monotonic() - t0,
            )
        except Exception as exc:
            return ExecutionResult(
                op, self.executor_type,
                error=str(exc),
                elapsed_s=time.monotonic() - t0,
            )
