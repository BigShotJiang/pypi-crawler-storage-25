"""Capability adapters — P0: ui_action, P1: text_input."""
