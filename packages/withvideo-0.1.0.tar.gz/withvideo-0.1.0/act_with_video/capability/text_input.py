"""P1 capability: text_input — type text or run commands.

Translates a SemanticOperation with capability="text_input" into ComputerActions.
Unlike ui_action, text_input rarely needs vision for location — if the active
window is correct, we just type.

Action set:
- search_text: type into a search field (may need click first)
- enter_text: type into the focused element
- run_command: type a command + press Return
- write_code: type code content into the editor (multi-line aware)
"""

from __future__ import annotations

from ..models import ComputerAction, ExecutionStep, SemanticOperation

TEXT_ACTIONS = frozenset({"search_text", "enter_text", "run_command", "write_code"})


def plan_text_input(op: SemanticOperation) -> ExecutionStep:
    """Plan a text_input operation."""
    if op.capability != "text_input":
        raise ValueError(f"Expected text_input capability, got {op.capability!r}")

    step = ExecutionStep(operation=op)

    if not op.text_content:
        step.adaptation_note = "No text_content provided — cannot execute text_input"
        return step

    # For search_text: may need a screenshot to locate the search field first
    if op.action == "search_text" and op.target:
        step.actions.append(ComputerAction(action="screenshot"))

    step.actions.append(ComputerAction(action="type", text=op.text_content))

    # run_command always submits with Return
    if op.action == "run_command":
        step.actions.append(ComputerAction(action="key", key="Return"))

    return step
