"""P0 capability: ui_action — locate and interact with UI elements.

Translates a SemanticOperation with capability="ui_action" into a sequence of
ComputerActions. The core challenge is UI location: the tutorial may have been
recorded at a different time (different layout, theme, version).

Strategy:
1. Take a screenshot of the current screen.
2. Pass screenshot + target description + visual_hint to a vision model.
3. Vision model returns coordinates or reports element not found.
4. If found: emit left_click at coordinates.
5. If not found: mark step.ui_adapted = True, try alternative locators.
"""

from __future__ import annotations

from ..models import ComputerAction, ExecutionStep, SemanticOperation

# Fixed action set for ui_action capability
UI_ACTIONS = frozenset({"navigate", "open", "select", "download", "dismiss", "confirm"})


def plan_ui_action(op: SemanticOperation) -> ExecutionStep:
    """Plan a ui_action operation (without executing)."""
    if op.capability != "ui_action":
        raise ValueError(f"Expected ui_action capability, got {op.capability!r}")

    step = ExecutionStep(operation=op)
    # Step 1: screenshot to observe current UI state
    step.actions.append(ComputerAction(action="screenshot"))
    # Steps 2-4 happen at execution time when we have the screenshot result
    return step


def execute_ui_action(step: ExecutionStep, coordinates: tuple[int, int] | None) -> ExecutionStep:
    """Complete execution after vision has located the target.

    Args:
        step: The planned step (from plan_ui_action).
        coordinates: Pixel coordinates returned by vision, or None if not found.
    """
    op = step.operation

    if coordinates is None:
        step.ui_adapted = True
        step.adaptation_note = f"Target not found: {op.target!r}. Manual intervention required."
        return step

    # Remove placeholder screenshot (already taken during planning)
    click_actions = [a for a in step.actions if a.action != "screenshot"]
    click_actions.append(ComputerAction(action="left_click", coordinate=coordinates))
    step.actions = click_actions
    return step
