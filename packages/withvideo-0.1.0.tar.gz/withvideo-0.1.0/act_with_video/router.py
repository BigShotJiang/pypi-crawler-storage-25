"""Operation router — routes SemanticOperation to the most efficient executor."""

from __future__ import annotations

from .executor.base import ExecutorBackend
from .executor.claude_code import ClaudeCodeExecutor
from .executor.file_write import FileWriteExecutor
from .executor.shell import ShellExecutor
from .executor.url_open import URLOpenExecutor
from .models import ActConfig, SemanticOperation


class OperationRouter:
    """Routes each SemanticOperation to the cheapest capable executor.

    Tier 0: Direct execution (shell, file_write, url_open) — free, instant.
    Tier 1: Claude Code CLI — LLM-backed, reliable for text/code tasks.
    Tier 2: Browser automation (Playwright) — future.
    Tier 3: Computer use API — expensive, last resort — future.
    """

    def __init__(self, cfg: ActConfig | None = None) -> None:
        cfg = cfg or ActConfig()
        self.shell = ShellExecutor(allow_dangerous=cfg.allow_dangerous)
        self.claude_code = ClaudeCodeExecutor(cfg)
        self.file_write = FileWriteExecutor(output_subdir=cfg.file_write_subdir)
        self.url_open = URLOpenExecutor()
        # Tier 2/3 executors loaded lazily when available
        self._fallback: ExecutorBackend = self.claude_code

    def route(self, op: SemanticOperation) -> ExecutorBackend:
        """Pick the most efficient executor for *op*."""
        cap, act = op.capability, op.action
        app = (op.app_context or "").lower()

        # --- Tier 0: Direct execution (free, instant) ---
        if cap == "text_input" and act == "run_command" and op.text_content:
            return self.shell

        if cap == "text_input" and act == "write_code" and op.text_content:
            if op.payload.get("file"):
                return self.file_write
            return self.claude_code

        if cap == "ui_action" and act == "navigate" and _is_url(op.target):
            return self.url_open

        # --- Tier 1: Claude Code CLI (LLM, reliable) ---
        if cap == "text_input" and act in (
            "input_prompt", "send_prompt", "enter_text", "search_text",
        ):
            if _app_is_claude(app):
                return self.claude_code

        # text_input with content but no specific routing → Claude Code
        if cap == "text_input" and op.text_content:
            return self.claude_code

        # --- Tier 2/3: future ---
        # browser / computer_use executors will be added here

        return self._fallback


def _app_is_claude(app: str) -> bool:
    return any(k in app for k in ("claude", "智能体", "agent", "ai"))


def _app_is_browser(app: str) -> bool:
    return any(k in app for k in ("browser", "chrome", "firefox", "safari", "浏览器"))


def _is_url(text: str) -> bool:
    return bool(text) and text.startswith(("http://", "https://", "www."))
