"""Act reporter — JSONL event stream + human-readable console output."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from .models import ActReport, ExecutionResult, SemanticOperation


class ActReporter:
    """Emits structured events and human-readable progress to stderr."""

    def __init__(self, *, jsonl_path: Path | None = None, quiet: bool = False) -> None:
        self._jsonl_path = jsonl_path
        self._quiet = quiet
        self._jsonl_fh = None
        if jsonl_path:
            jsonl_path.parent.mkdir(parents=True, exist_ok=True)
            self._jsonl_fh = open(jsonl_path, "w", encoding="utf-8")

    # -- events ---------------------------------------------------------------

    def act_started(self, source: str, total_ops: int) -> None:
        self._emit({"type": "act_started", "source": source, "total_ops": total_ops})
        self._print(f"[act] Starting: {source}  ({total_ops} operations)")

    def operation_preview(self, op: SemanticOperation, executor_type: str) -> None:
        self._emit({
            "type": "operation_preview",
            "capability": op.capability,
            "action": op.action,
            "executor": executor_type,
            "description": op.description,
        })
        tier_label = _tier_label(executor_type)
        desc = op.description or f"{op.capability}/{op.action}"
        self._print(f"  [{tier_label}] {desc}")
        if op.text_content:
            preview = op.text_content[:120].replace("\n", "\\n")
            self._print(f"         → {preview}")

    def operation_completed(self, result: ExecutionResult) -> None:
        status = "✓" if result.success else "✗"
        self._emit({
            "type": "operation_completed",
            "executor": result.executor_type,
            "success": result.success,
            "elapsed_s": round(result.elapsed_s, 2),
        })
        elapsed = f" ({result.elapsed_s:.1f}s)" if result.elapsed_s > 0.1 else ""
        if result.success:
            self._print(f"         {status} done{elapsed}")
        else:
            self._print(f"         {status} failed{elapsed}: {result.error[:200]}")

    def operation_skipped(self, result: ExecutionResult) -> None:
        self._emit({
            "type": "operation_skipped",
            "reason": result.skip_reason,
        })
        self._print(f"         ⊘ skipped: {result.skip_reason}")

    def act_completed(self, report: ActReport) -> None:
        self._emit({
            "type": "act_completed",
            "executed": report.executed,
            "succeeded": report.succeeded,
            "failed": report.failed,
            "skipped": report.skipped,
        })
        self._print(
            f"\n[act] Done: {report.executed} executed, "
            f"{report.succeeded} succeeded, {report.failed} failed, "
            f"{report.skipped} skipped"
        )
        if self._jsonl_fh:
            self._jsonl_fh.close()

    # -- internals ------------------------------------------------------------

    def _emit(self, event: dict) -> None:
        if self._jsonl_fh:
            self._jsonl_fh.write(json.dumps(event, ensure_ascii=False) + "\n")
            self._jsonl_fh.flush()

    def _print(self, msg: str) -> None:
        if not self._quiet:
            print(msg, file=sys.stderr)


def _tier_label(executor_type: str) -> str:
    return {
        "shell": "T0:shell",
        "file_write": "T0:file",
        "url_open": "T0:url",
        "claude_code": "T1:claude",
        "browser": "T2:browser",
        "computer_use": "T3:cu",
    }.get(executor_type, executor_type)
