---
name: video-frame-analysis
description: >
  H.264 motion vector video analysis domain knowledge for WithVideo.
  Understand burst patterns, spatial heatmaps, and frame extraction strategies
  for tutorial video analysis. Use when working on wv learn pipeline,
  keyframe extraction, or visual content capture.
---

# Video Frame Analysis -- H.264 MV Domain Knowledge

## H.264 Motion Vectors

Video encoders record motion vectors (MV) in P/B frames, describing macroblock
displacement from reference frame to current frame. WithVideo extracts these via
PyAV, computes per-frame activity scores (sum of MV magnitudes), aggregates into
1-second ActivityProfile, then detects contiguous high-activity intervals (ActivityBurst).

When all-intra encoded (no MV), falls back to SSIM pixel-diff detection.

## BurstPattern Semantics

The MV detector classifies each burst using three features:
- **spatial_coverage**: fraction of 16x9 grid cells with active MVs (0-1)
- **direction_consistency**: MV direction uniformity via circular variance (0=consistent, 1=random)
- **duration**: burst duration in seconds

| Pattern | Conditions | Meaning | Frame Strategy |
|---------|-----------|---------|----------------|
| TAB_SWITCH | coverage>0.7, duration<1s | Full-screen rapid change (tab switch, page flip, content reveal) | Capture peak frame (content after switch) |
| SCROLLING | dir_consistency<0.3, coverage>0.4 | Directional scroll (code, document, web) | Capture pre+post frames to stitch full content |
| TYPING | coverage<0.3, duration>2s | Localized sustained change (code editing, text input) | Capture final result (wait for typing to finish) |
| CLICK_MENU | coverage<0.3, duration<1s | Localized brief change (menu, button) | Usually skip (low value) |
| VIEWPORT_MANIPULATION | 0.2<coverage<0.6, duration>2s | Medium-range sustained (3D viewport rotation, canvas pan) | Capture before/after comparison |
| DRAG | dir_consistency<0.5, 0.2<coverage<0.6, duration>1.5s | Drag operation | Capture start/end positions |

## Spatial Heatmap

16x9 grid normalized to [0,1], representing MV magnitude concentration per cell.
Hot zones described as: top-left, top-right, bottom-left, bottom-right, top, bottom.

Typical patterns:
- **Code editor**: activity concentrated left/center (editing area)
- **Terminal**: activity concentrated bottom
- **Browser**: activity distributed broadly
- **Slide/presentation**: full coverage during transitions

## Content Capture Strategies

### Text Content (code, docs, config)
- **Goal**: Extract visible text (content_snapshot)
- **Code tutorial**: Instructor may write wrong code first, then fix it.
  The LLM should use transcript semantics to identify the FINAL correct version.
- **Scrolling display**: Content doesn't fit one screen.
  Capture pre+post scroll frames to reconstruct full content.
- **Fast page flipping**: Showing multiple files quickly.
  Each TAB_SWITCH peak frame has value -- capture all of them.

### Operation Content (UI interactions, 3D operations)
- **Goal**: Record specific operations (what was clicked, where dragged)
- **Blender/Figma**: Record tool selection, parameter settings
- **Browser**: Record navigation paths, form inputs
- **Desktop apps**: Record menu paths, dialog options

## Pipeline Data Flow

```
Stage 1c: H.264 MV -> ActivityProfile (bursts with pattern + heatmap)
    |
_attach_bursts_to_windows: burst matched to Window by temporal overlap
    |
Stage 2: Semantic LLM receives transcript + screen_activity (burst summary)
    -> Decides needs_visual_evidence for OPERATE and EXPLAIN windows
    |
Stage 3: Keyframe extraction
    -> OPERATE windows: _smart_frame_extraction (burst-guided)
    -> EXPLAIN windows (needs_visual=true): content-flash extraction
    -> Vision LLM analyzes all needs_visual windows -> content_snapshot + operations
```

## Key Code Locations

- MV extraction: `withvideo/impl/activity/mv.py` -- `MVDetector.detect()`
- Pattern classification: `mv.py:_classify_pattern()` -- coverage/direction/duration rules
- Spatial heatmap: `mv.py:_compute_spatial_heatmap()` + `describe_hot_zones()`
- Burst-to-window: `withvideo/pipeline.py:_attach_bursts_to_windows()`
- Burst summary for LLM: `pipeline.py:_summarize_bursts_for_block()`
- Semantic judgment: `pipeline.py:_semantic_judgment()` -- LLM classification with burst data
- Frame extraction: `pipeline.py:_extract_window_frames()` -> `_smart_frame_extraction()`
- Vision analysis: `pipeline.py:_analyze_window()` -- vision LLM extracts content_snapshot

## Diagnostic Guide

| Symptom | Likely Cause | Check |
|---------|-------------|-------|
| EXPLAIN window content not captured | LLM didn't set needs_visual_evidence=true | Read `llm/semantic_output.raw.txt` |
| All frames are "uniform" sampling | window.activity_burst is None | Check `_attach_bursts_to_windows` ran |
| Vision analysis skipped entirely | visual_n + explain_visual_n both 0 | Check Stage 3 entry condition |
| All bursts classified UNKNOWN | MV extraction failed, fell back to SSIM | Check video encoding format |
| Wrong frames captured (noise, not content) | Burst peak misaligned with content | Check burst timing vs actual content timestamps |
| content_flash_frames missing from JSON | EXPLAIN has no keyframes | Check explain_visual list in Stage 3 |

## Smart Frame Extraction Rules

When `window.activity_burst` is set, `_smart_frame_extraction` uses:
- Always: pre_burst (0.5s before), peak, post_burst (0.5s after)
- Additional intermediate frames only when `burst.duration > _PATTERN_MIN_DUR[pattern]`
- TAB_SWITCH min_dur=99s (intentionally high -- sub-second switch needs only peak)
- TYPING min_dur=3s, interval=2s (capture during sustained editing)
- SCROLLING min_dur=4s, interval=5s (capture scroll progression)

When `window.activity_burst` is None, falls back to uniform sampling (3 frames evenly spaced).

## Frame Quality: Hybrid Remote Upgrade

B站 default downloads are very low bitrate (~112 kbps for a 90s video). Text in code editors,
Markdown files, and terminals is unreadable at this quality. The pipeline uses a **hybrid mode**:

1. **Stage 1c**: Activity detection runs on the local (low-quality) download — SSIM/MV work fine
2. **Stage 2**: Semantic judgment uses transcript — no frames needed
3. **Stage 3**: Before frame extraction, `_try_remote_upgrade()` attempts to get a Bilibili
   remote stream URL via bilibili-api for higher-quality frames

### Upgrade path
- `_try_remote_upgrade()` in pipeline.py checks: is media LocalMediaHandle + platform BILIBILI?
- If yes: uses `get_remote_stream_url()` from `bilibili.py` to get stream URL + headers
- Creates a `RemoteMediaHandle` used only for frame extraction (ffmpeg seeks directly)
- Falls back to local file with degradation warning if remote fails

### When remote upgrade fails
- No bilibili-api installed → suggests `pip install bilibili-api-python`
- No cookies / auth failure → suggests `--cookies-from-browser chrome`
- API rate limit / network error → falls back silently with warning

### Diagnostic

| Symptom | Likely Cause | Check |
|---------|-------------|-------|
| Frames too blurry to read text | Remote upgrade failed, using local low-bitrate | Look for "远程高清取帧不可用" in output |
| "bilibili-api 未安装" warning | Missing dependency | `pip install bilibili-api-python` |
| content_snapshot mostly layout, no text details | Vision LLM can't read low-res frames | Ensure remote upgrade succeeds |
