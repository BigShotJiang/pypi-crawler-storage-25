# yt-dlp下载 #视频采集

调用 yt-dlp 完成视频文件下载、字幕提取和元数据收集，支持多平台统一接口。

---

## 格式选择策略

```
优先：720p–1080p H.264（对运动向量提取最友好）
避免：AV1/VP9（All-Intra 编码，运动向量不可用）
最大分辨率：1080p（更高分辨率无额外收益）
```

---

## 各平台下载内容

| 平台 | 下载内容 |
|------|---------|
| YouTube | 视频 + 所有字幕轨 + 章节 + SponsorBlock |
| Bilibili | 视频 + 字幕（若有）+ 弹幕（via API）|
| Vimeo | 视频 + 字幕 + 章节 |
| Twitter | 视频（无字幕）|
| Local | 直接使用，ffprobe 探测元数据 |

---

## 输出文件

```
.withvideo/<title>/
  source.mp4          # 视频文件
  source.info.json    # yt-dlp 元数据（完整 JSON）
  subtitles/          # 字幕文件（.vtt / .srt）
```

---

## 关联

- [[平台适配]] — 平台识别决定 yt-dlp 参数
- [[元数据规范化]] — source.info.json → SourceMeta
- [[字幕质量分类]] — 字幕文件质量评估

*业务域标签：#视频采集*
