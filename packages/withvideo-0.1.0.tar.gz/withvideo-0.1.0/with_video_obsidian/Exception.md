---
title: Exception
roadmap: [[mvp-roadmap]]
---

# Exception Log — WithVideo MVP Roadmap

配套 `mvp-roadmap.canvas` 的阻塞/异常登记。每条红色节点必须在此登记。

---

## EX-01:P0.5 Tier 0/1 执行器是否纳入 MVP [RESOLVED]

- **节点 ID**:`22c2370a30e9d0e9`
- **节点文本**:P0.5 Tier 0/1 执行器端到端
- **状态**:**resolved**(红→灰,进入正常推进队列)
- **登记时间**:2026-04-15(草稿生成)
- **解除时间**:2026-04-15(用户拍板)

### 决策结果

选 **A 选项**:MVP **纳入** Tier 0/1 可执行。

- ShellExecutor:跑通 `wv act` 执行 shell 类步骤
- ClaudeCodeExecutor:跑通 Claude Code 子任务型步骤
- Tier 2/3(AppleScript / 视觉级)**继续 out of scope**
- B 通道的 plugin skill 文档里要展示 `wv act` 能真实执行

### 影响(已落地到 canvas)

- `22c2370a30e9d0e9`(P0.5):红→灰,body 重写为"端到端跑通 Tier 0/1"
- `2b02add28eceb951`(P0.4):body 改为"Tier 0/1 标 MVP 可用,Tier 2/3 标 roadmap"
- `bf4c1bc051011113`(B.1):body 加入"learn + act 均可从 plugin 调用"
- `533ed217742d7016`(B.3):body 加入"MCP tools 暴露 learn + act"
- `41a99d7daf952cf9`(B.4):body 加入"示例展示 learn + act 真实调用"

### 后续

Curator 在 KP-04 writeback 阶段,需要把该决策同步写回:

- `with_video_obsidian/执行自动化/` 业务域 README(Tier 0/1 = locked fact:MVP 可用)
- `with_video_obsidian/插件系统/` 业务域 README(plugin 暴露 act)

---
