# Markdown渲染 #指南生成

`MarkdownRenderer` 将 `RepeatGuide` 对象渲染为 Obsidian 兼容的 Markdown 文件，包含 YAML frontmatter 和中文章节结构。

---

## 渲染器接口

```python
class MarkdownRenderer:
    def render(self, guide: RepeatGuide) -> str:
        """向后兼容：所有代码内联"""

    def render_with_code_files(self, guide: RepeatGuide) -> tuple[str, list[CodeFile]]:
        """返回 (md字符串, 外置代码文件列表)"""
```

---

## 章节结构

| 章节 | 对应 RepeatStep 字段 |
|------|-------------------|
| `### 💡 概念` | `explain` 窗口的 transcript + knowledge_points |
| `### 🔧 操作` | `operate` 窗口的 operations（编号列表 + 代码块）|
| `### ✅ 预期结果` | `verify` 窗口的 expected_outcome |

---

## 操作渲染规则

```python
is_run   = capability=="text_input" and action=="run_command"   → ```bash
is_write = capability=="text_input" and action=="write_code"    → ```{lang}
is_prompt= capability=="text_input" and action not in above     → ```prompt
```

每个步骤末尾附带机器可读注释块（始终完整，不受代码外置影响）：
```
<!-- withvideo:operations
[{...operation JSON...}]
-->
```

---

## 代码入口

Markdown主渲染 `MarkdownRenderer._render_body` @withvideo/impl/renderers/markdown.py#L89-L127
业务域：#指南生成、[[Markdown渲染]]、[[RepeatGuide]]、[[guide.md]]

步骤渲染 `_render_step` @withvideo/impl/renderers/markdown.py#L130-L157
业务域：#指南生成、[[Markdown渲染]]、[[RepeatStep]]

操作渲染 `_render_operate` @withvideo/impl/renderers/markdown.py#L174-L240
业务域：#指南生成、[[Markdown渲染]]、[[Operation]]、[[代码块渲染]]

---

## 关联

- [[代码外置]] — `render_with_code_files()` 触发代码外置逻辑
- [[语义JSON输出]] — 并行产出 semantic.json
- [[指南合成]] — 渲染器的调用方

*业务域标签：#指南生成*
