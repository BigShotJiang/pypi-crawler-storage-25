# 语义JSON输出 #指南生成

将 `RepeatGuide` 序列化为 `semantic.json`，这是 `wv act` 的数据源，也是 learn ↔ act 的**稳定契约**。

---

## 格式

```json
{
  "metadata": {
    "source": "https://youtube.com/...",
    "title": "视频标题",
    "generated_at": "2026-04-05T12:00:00Z"
  },
  "steps": [
    {
      "index": 0,
      "title": "步骤标题",
      "time_range": [0.0, 90.5],
      "operations": [
        {
          "capability": "text_input",
          "action": "input_prompt",
          "target": "Claude Code 对话框",
          "intent": "生成风格指南",
          "app_context": "Claude Code",
          "text_content": "帮我生成详细的风格指南...",
          "source": "transcript"
        }
      ],
      "expected_outcome": "Claude 生成包含配色方案的风格指南文档"
    }
  ]
}
```

---

## 稳定性保证

`semantic.json` 的 `Operation` 结构是 learn 输出与 act 消费的稳定接口，字段变更需要同时更新：
- `withvideo/models.py` → `Operation`
- `act_with_video/models.py` → `SemanticOperation`
- `act_with_video/guide_reader.py` → `_dict_to_op()`

---

## 代码入口

语义JSON渲染 `_render_semantic_json` @withvideo/pipeline.py#L1724-L1780
业务域：#指南生成、[[语义JSON输出]]、[[semantic.json]]、[[learn-act契约]]

---

## 关联

- [[执行自动化]] — wv act 的数据输入
- [[执行自动化/操作路由]] — 路由器消费 Operation 字段
- [[Markdown渲染]] — 并行产出 guide.md

*业务域标签：#指南生成*
