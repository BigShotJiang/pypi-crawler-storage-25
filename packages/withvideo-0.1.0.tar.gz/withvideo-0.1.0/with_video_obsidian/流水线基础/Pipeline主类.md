# Pipeline主类 #流水线基础

`Pipeline` 类编排 5 个阶段的顺序执行，管理缓存、事件报告、DecisionRequired 异常和产出物写入。

---

## 类定义

```python
# withvideo/pipeline.py L158
class Pipeline:
    def __init__(self, cfg: WVConfig, reporter: RunReporter | None = None): ...

    def run(self, source: str | Path) -> Path:
        """主入口：source → 输出目录路径"""
```

---

## 执行阶段

```python
# pipeline.py 内部结构（简化）
def run(self, source):
    work_dir = self._setup_work_dir(source)          # 工作目录
    media, meta = self._stage_acquire(source)         # Stage 0
    transcript = self._stage_transcript(media, meta)  # Stage 1a
    plugin = self._stage_plugin_detect(transcript, meta)  # Stage 1b
    activity = self._stage_activity(media)            # Stage 1c
    steps = self._stage_semantic(transcript, activity, meta)  # Stage 2
    steps = self._stage_vision(steps, media, plugin)  # Stage 3
    self._stage_synthesis(steps, plugin, meta, work_dir)  # Stage 4
    return work_dir
```

---

## 缓存机制

- `joblib` 缓存：存储可调用结果（Whisper、LLM 调用、帧提取）
- `json` 缓存：存储中间 JSON 文件（transcript.json、semantic_judgment.json 等）
- `--force` → 清空缓存，重跑全部阶段
- `--skip <stage>` → 跳过指定阶段（使用缓存结果）

---

## Stage 3 辅助函数

Stage 3（视觉分析）新增的 burst→窗口联动函数：

burst 关联窗口 `_attach_bursts_to_windows` @withvideo/pipeline.py#L703-L728
业务域：#流水线基础、[[Pipeline主类]]、[[5阶段流水线]]、[[ActivityBurst]]

- 按时间重叠将 ActivityBurst 关联到 EXPLAIN/OPERATE/VERIFY 窗口
- 多 burst 重叠时合并为合成 burst，确保连续滚动等活动全覆盖

视觉强制触发 `_force_visual_for_significant_bursts` @withvideo/pipeline.py#L734-L746
业务域：#流水线基础、[[Pipeline主类]]、[[视觉分析]]、[[BurstPattern]]

- SCROLLING 或 TAB_SWITCH 且 duration ≥ 2s → 强制 `needs_visual_evidence = true`
- 运行于 Stage 2 语义判断之后、Stage 3 关键帧提取之前

---

## 代码入口

Pipeline主类 `Pipeline` @withvideo/pipeline.py#L158-L340
业务域：#流水线基础、[[Pipeline主类]]、[[5阶段流水线]]、[[缓存与恢复]]

---

## 关联

- [[事件流]] — RunReporter 在此使用
- [[决策机制]] — DecisionRequired 从此抛出，由 CLI 层捕获
- [[数据模型]] — 所有阶段数据类型定义
- [[视觉分析]] — Stage 3 burst 联动机制

*业务域标签：#流水线基础*
