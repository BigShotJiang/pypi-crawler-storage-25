# CLI命令 #流水线基础

`wv` 四个命令的完整参数参考。

---

## wv learn

```bash
wv learn <video_url_or_path> [OPTIONS]

Options:
  -o, --output PATH           输出目录（默认 .withvideo/<title>/）
  -p, --plugin                领域插件 (auto|code|blender|figma|general)，默认 auto
  --vision                    视觉后端 (cli|claude|ollama:<model>|none)，默认 cli
  --transcript                字幕策略 (auto|mlx-whisper|platform-subs)，默认 auto
  --activity                  活动检测后端 (auto|mv|ssim)，默认 auto
  --media-access              媒体访问模式 (download|remote)
  --max-frames INT            视觉 API 帧预算
  --decision-mode             决策模式 (auto|prompt|fail|defaults|agent)
  --event-stream              事件流输出 (off|auto|jsonl)
  --force                     强制重跑所有阶段
  --skip STAGE                跳过指定阶段
  --cache                     缓存后端 (joblib|json|none)
```

CLI learn命令 `learn` @withvideo/cli.py#L265-L336
业务域：#流水线基础、[[CLI命令]]、[[wv-learn]]、[[视频学习]]

---

## wv act

```bash
wv act <guide_path> [OPTIONS]

Options:
  --step TEXT                 步骤过滤 ("3" | "2-5" | "1,3,5")
  --dry-run                   预览路由决策，不实际执行
  --confirm / --no-confirm    每步执行前确认（默认 --confirm）
  --executor CHOICE           执行后端 (auto|direct-only|browser|computer-use)
```

CLI act命令 `act` @withvideo/cli.py#L376-L390
业务域：#流水线基础、#执行自动化、[[CLI命令]]、[[wv-act]]

---

## wv preflight

```bash
wv preflight <video_url> [OPTIONS]

Options:
  --cookies PATH              cookies 文件路径
  --cookies-from-browser TEXT 从浏览器提取 cookies
```

输出 JSON 报告：
```json
{
  "environment": {"ffmpeg": true, "llm": "claude", "issues": []},
  "source": {"platform": "youtube", "subtitle_quality": "word_level"},
  "recommended": {"media_access": "remote", "vision": "cli"},
  "command": "wv learn https://... --vision cli"
}
```

CLI preflight命令 `preflight` @withvideo/cli.py#L352-L375
业务域：#流水线基础、[[CLI命令]]、[[预检]]、[[环境检查]]

---

## wv schema

```bash
wv schema
```

输出机器可读的接口描述 JSON，包含：
- `commands`：所有命令参数及类型
- `events`：JSONL 事件类型及字段
- `decisions`：决策类型、选项、默认值
- `exit_codes`：退出码含义

供 AI Agent、Claude Code 插件、MCP Server 集成使用。

CLI schema命令 `schema` @withvideo/cli.py#L337-L351
业务域：#流水线基础、[[CLI命令]]、[[Agent集成]]、[[MCP]]

---

## 关联

- [[事件流]] — `--event-stream` 控制 JSONL 输出
- [[决策机制]] — `--decision-mode` 影响决策处理方式
- [[执行自动化/执行循环]] — `wv act` 内部调用 ActRunner

*业务域标签：#流水线基础*
