# LLM分类调用 #语义判断

Stage 2 核心：**一次 LLM 调用**对所有 topic blocks 分类，返回结构化 JSON 序列。

---

## 调用逻辑

```
输入：所有 topic blocks（文本 + 时间戳 + 可选 ActivityBurst）
输出：每个 block 的 {intent, needs_visual_evidence, transcript_operations, ...}
```

- 纯文本 prompt，无图片 → 成本低，速度快（~5s）
- ActivityProfile 中的 burst 信息作为辅助证据注入 prompt
- 使用本地 CLI（claude/codex）或 API，由 `--vision` 参数控制

---

## 错误处理与重试

| 错误类型 | 处理方式 |
|---------|---------|
| JSON 解析失败 | `_repair_json()` 修复字面量换行符，再次解析 |
| LLM 调用失败 | `DecisionRequired(llm_stage_retry_or_abort)` |
| 置信度 < 0.5 | 降级为 `_fallback_classify()`（基于 ActivityBurst 启发式） |

---

## _repair_json 修复器

LLM 有时在 JSON 字符串值内输出未转义的字面量换行符，导致解析失败。

修复器 `_repair_json` @withvideo/pipeline.py#L58-L82
业务域：#语义判断、[[JSON修复]]、[[LLM输出解析]]

---

## 降级分类

`_fallback_classify` @withvideo/pipeline.py#L1102-L1122
业务域：#语义判断、[[降级策略]]、[[ActivityBurst]]

当 LLM 不可用时，纯基于 ActivityBurst 启发式分配 EXPLAIN/OPERATE。

---

## 关联

- [[主题分段]] — 分类的输入来自 topic blocks
- [[时间窗口组装]] — 分类结果转化为 Window
- [[活动检测]] — ActivityBurst 作为辅助证据

*业务域标签：#语义判断*
