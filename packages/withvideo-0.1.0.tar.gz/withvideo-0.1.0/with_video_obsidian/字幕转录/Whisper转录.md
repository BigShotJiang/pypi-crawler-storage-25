# Whisper转录 #字幕转录

使用本地 mlx-whisper 模型将音频转录为文字，用于平台字幕质量不足（UNRELIABLE/NONE）的情况。

---

## 触发条件

| 情况 | 策略 |
|------|------|
| 平台字幕 WORD/SENTENCE 级 | 跳过 Whisper，直接使用 |
| 平台字幕 UNRELIABLE/NONE | 触发 `DecisionRequired` → 默认使用 Whisper |
| `--transcript mlx-whisper` | 强制使用 Whisper |

---

## 实现细节

- 模型：`mlx-community` whisper（Apple Silicon 优化）
- 输入：`audio.wav`（从视频提取）
- 输出：带词级时间戳的 `Transcript`
- 延迟：约 8s（M2 上转录 10min 视频）

---

## 输出格式

```python
Transcript(
    source=TranscriptSource.WHISPER,
    language="zh",
    segments=[Segment(start, end, text, words=[Word(...)])],
    has_word_timestamps=True,
)
```

---

## 关联

- [[平台字幕优先级]] — 优先级更高，Whisper 为后备
- [[字幕质量分类]] — 质量判断触发此路径

*业务域标签：#字幕转录*
