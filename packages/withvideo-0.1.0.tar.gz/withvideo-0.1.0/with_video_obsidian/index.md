---
title: WithVideo 项目总览
tags:
  - 项目总览
aliases:
  - WithVideo
---

# WithVideo 项目总览

WithVideo 是一个**语义优先**的教程视频理解系统，将教学视频转化为可复现的 Repeat Guide，支持人工跟学和 AI 自动执行。

---

## 核心理念

> **语言理解优先，视觉分析可选。**
> 字幕/语音转录是主要信号；运动向量与视觉分析是辅助确认，不是主驱动。

---

## 五阶段流水线

```
Stage 0: 视频采集    → SourceMeta + 视频文件
Stage 1: 字幕转录    → Transcript（统一格式）
Stage 2: 语义判断    → [RepeatStep]（核心枢纽，一次 LLM 调用）
Stage 3: 视觉分析    → [FrameAnalysis]（仅在 needs_visual_evidence 时运行）
Stage 4: 指南生成    → guide.md + semantic.json
```

---

## 业务域

| 业务域 | 说明 | 负责阶段 |
|--------|------|---------|
| [[视频采集]] | 平台适配、yt-dlp 下载、元数据规范化 | Stage 0 |
| [[字幕转录]] | Whisper、平台字幕、活动检测 | Stage 1 |
| [[语义判断]] | 主题分段、LLM 分类、窗口/步骤组装 | Stage 2 |
| [[视觉分析]] | 关键帧提取、视觉后端、帧分析 | Stage 3 |
| [[指南生成]] | guide.md 渲染、代码外置、semantic.json | Stage 4 |
| [[执行自动化]] | 操作路由、多层执行器、执行循环 | wv act |
| [[流水线基础]] | Pipeline 主类、数据模型、CLI、事件流 | 全局 |
| [[插件系统]] | 领域插件检测（code/blender/figma/general） | Stage 1b/3 |

---

## 产出物

| 文件 | 用途 |
|------|------|
| `guide.md` | 人类可读的 Repeat Guide（含 YAML frontmatter） |
| `semantic.json` | 机器可读的操作序列（`wv act` 的数据源） |

---

## CLI 入口

```bash
wv learn <url_or_path>   # 视频 → 指南
wv act   <guide_path>    # 指南 → 自动执行
wv preflight <url>       # 环境 + 源兼容性检查
wv schema                # 输出机器可读的接口描述
```

---

## 工作目录结构

```
.withvideo/<视频名>/
  source.mp4            # Stage 0
  source.info.json
  audio.wav             # Stage 1
  transcript.json
  activity.json         # Stage 1c（可选）
  semantic_judgment.json # Stage 2 中间产物
  timeline.json
  keyframes/            # Stage 3（可选）
  analysis.json
  guide.md              # ★ 人类可读输出
  semantic.json         # ★ 机器可读契约
  code/                 # 外置代码文件（长代码块）
```

---

*最后更新：2026-04-05*
