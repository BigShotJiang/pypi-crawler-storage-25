# Examples

真实跑出来的 `wv learn` 产物，供新用户快速看到输出长什么样。

## `vibe-coding-user/`

- **源视频**: [Bilibili · 爆款案例｜如何找到你的第一个 vibe coding 用户](https://www.bilibili.com/video/BV1EowjzKE5x/)
- **时长**: 17:12
- **产物**:
  - [`guide.md`](vibe-coding-user/guide.md) — 42 KB 人类可读指南
  - [`semantic.json`](vibe-coding-user/semantic.json) — 28 KB 机器可读契约

重跑这个例子：

```bash
wv learn https://www.bilibili.com/video/BV1EowjzKE5x/ \
  -o demo/vibe-coding-user \
  --vision none \
  --llm-timeout 600
```
