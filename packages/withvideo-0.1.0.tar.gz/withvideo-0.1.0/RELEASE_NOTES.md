# Release Notes

## 0.1.0

这是 `WithVideo` 第一版能真正端到端跑通的可用版本。

### 新增能力

- 新增 `wv learn` 主链路，支持把教程视频转换成：
  - `guide.md`
  - `semantic.json`
- 新增 `wv act` 执行链路，能够读取 `guide.md` / `semantic.json` 并真实执行 Tier 0/1 操作（Shell / FileWrite / URLOpen / ClaudeCode）
- 支持双输入模式：
  - 本地原始视频文件
  - 网络 URL
- URL 侧新增站点分流：
  - `BilibiliAcquirer`
  - `YouTubeAcquirer`
  - `GenericUrlAcquirer`
- 本地视频现在会自动吸收 sidecar：
  - `.info.json`
  - `.srt`
  - `.vtt`

### 字幕与转录

- `--transcript auto` 改为在拿到真实 `SourceMeta` 之后再决定 provider
- Bilibili 支持：
  - 平台字幕识别
  - 登录态 cookies 缓存
  - 浏览器授权失败后自动降级到匿名下载 + Whisper
- YouTube 支持：
  - 优先下载原始语言字幕，而不是默认拉取所有字幕语言
  - `youtube-transcript-api` 作为 `yt-dlp` 字幕缺失时的 fallback
- `platform-subs` 现在会根据 track 本身判断：
  - manual / auto
  - 是否真的有 word timestamps

### 运行稳定性

- 长视频活动检测现在会按时长自动降采样
- `SSIMDetector` 在 `ffmpeg` 抽帧超时时会优雅降级，不再直接打断整条流程
- LLM 阶段新增 `llm_command` 和 `llm_timeout`
  - 可接 `codex`
  - 可接 `claude`
  - 为后续 `openclaw` 预留统一入口

### 已验证场景

- 本地原始视频 + sidecar 路径可跑通
- Bilibili：
  - 匿名下载路径可跑通
  - 登录态字幕路径可跑通
  - 浏览器 cookies 读取被拒绝时可自动降级
- YouTube：
  - `https://www.youtube.com/watch?v=xZaSPw14Cfo`
  - 已验证从 URL 输入进入完整 `wv learn` 链路，并生成最终产物

### 输出产物

一次成功运行后，输出目录通常会包含：

- `guide.md`
- `semantic.json`
- `source.mp4`
- `source.info.json`
- 平台字幕 sidecar
- `keyframes/`

### 当前边界

- `wv act` 已支持 Tier 0/1 真实执行；Tier 2/3（Browser / ComputerUse）仍在 roadmap
- `--vision none` 仍是当前最稳的配置
- 长视频在 LLM 阶段可能仍然较慢，建议显式设置 `--llm-timeout`

### 推荐命令

```bash
uv run --python 3.11 --with youtube-transcript-api --with mlx-whisper python -m withvideo.cli learn \
  "https://www.youtube.com/watch?v=xZaSPw14Cfo" \
  -o .withvideo/demo-youtube \
  --vision none \
  --llm-timeout 600 \
  -v
```
