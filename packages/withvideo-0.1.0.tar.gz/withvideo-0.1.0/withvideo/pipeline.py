"""Main learn pipeline — orchestrates all stages (semantic-first architecture)."""

from __future__ import annotations

import json
import re
import shlex
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from .config import WVConfig, _find_binary
from .impl.acquirers.common import has_usable_tracks
from .models import (
    ActivityBurst, ActivityProfile, BurstPattern, Frame, FrameAnalysis,
    GuideMetadata, KnowledgeEntry, Operation, RepeatGuide,
    LocalMediaHandle, MediaHandle, RemoteMediaHandle, RepeatStep,
    Segment, SourceMeta, Transcript, Window, WindowType,
)
from .protocols import (
    ActivityDetector, DomainPlugin, ReportRenderer,
    SourceAcquirer, StageCache, TranscriptProvider, VisionBackend,
)
from .runtime import DecisionRequired, RunReporter, get_current_reporter, use_reporter


def _extract_json_block(text: str, open_ch: str = "{", close_ch: str = "}") -> str:
    """Extract the outermost JSON object/array from text using bracket matching."""
    start = text.find(open_ch)
    if start == -1:
        return text
    depth = 0
    in_string = False
    escape = False
    for i in range(start, len(text)):
        c = text[i]
        if escape:
            escape = False
            continue
        if c == "\\":
            escape = True
            continue
        if c == '"' and not escape:
            in_string = not in_string
            continue
        if in_string:
            continue
        if c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return text[start:i+1]
    return text[start:]  # fallback


def _repair_json(text: str) -> str:
    """Fix common LLM JSON generation issues: literal newlines/tabs inside strings."""
    result = []
    in_string = False
    escape_next = False
    for ch in text:
        if escape_next:
            result.append(ch)
            escape_next = False
        elif ch == "\\":
            result.append(ch)
            escape_next = True
        elif ch == '"':
            result.append(ch)
            in_string = not in_string
        elif in_string and ch == "\n":
            result.append("\\n")
        elif in_string and ch == "\r":
            result.append("\\r")
        elif in_string and ch == "\t":
            result.append("\\t")
        else:
            result.append(ch)
    return "".join(result)


def _fmt_time(s: float) -> str:
    m, sec = divmod(int(s), 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m}:{sec:02d}"


def _fmt_duration(s: float) -> str:
    return _fmt_time(s)


def _relocate_meta_paths(meta: SourceMeta, from_dir: Path, to_dir: Path) -> None:
    def relocate(path: Path | None) -> Path | None:
        if path is None:
            return None
        try:
            relative = path.relative_to(from_dir)
        except ValueError:
            return path
        return to_dir / relative

    meta.local_video_path = relocate(meta.local_video_path) or meta.local_video_path
    for track in [*meta.subtitles, *meta.auto_captions]:
        track.path = relocate(track.path)


def _relocate_media_handle(media: MediaHandle, from_dir: Path, to_dir: Path) -> MediaHandle:
    if isinstance(media, RemoteMediaHandle):
        return media

    try:
        relative = media.path.relative_to(from_dir)
    except ValueError:
        return media
    return LocalMediaHandle(path=to_dir / relative)


def _materialize_staging_dir(staging: Path, work_dir: Path) -> None:
    if not staging.exists():
        return
    if not work_dir.exists():
        staging.rename(work_dir)
        return
    shutil.copytree(staging, work_dir, dirs_exist_ok=True)
    shutil.rmtree(staging)


def _is_remote_media(media: MediaHandle) -> bool:
    return isinstance(media, RemoteMediaHandle)


def _local_video_path(media: MediaHandle) -> Path | None:
    if isinstance(media, LocalMediaHandle):
        return media.path
    return None


def _warn_if_low_resolution(media: MediaHandle, reporter: RunReporter) -> None:
    """Warn when a downloaded video is below 720p — frame extraction may be too blurry to read text."""
    if not isinstance(media, LocalMediaHandle):
        return
    try:
        result = subprocess.run(
            [
                _find_binary("ffprobe") or "ffprobe",
                "-v", "quiet",
                "-select_streams", "v:0",
                "-show_entries", "stream=height",
                "-of", "csv=p=0",
                str(media.path),
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        height = int(result.stdout.strip().split("\n")[0])
        if height < 720:
            reporter.human(
                f"[wv] ⚠ 视频分辨率 {height}p < 720p，截帧画质可能不足以识别文字内容\n"
                f"[wv]   建议: 使用 --cookies-from-browser chrome 并重新运行以获取高清版本"
            )
        else:
            reporter.human(f"[wv]   视频分辨率: {height}p ✓")
    except Exception:
        pass  # ffprobe unavailable or file not yet present — skip silently


def _reporter() -> RunReporter:
    return get_current_reporter()


def _emit_artifact_if_exists(stage: str, path: Path, artifact_type: str, context: dict | None = None) -> None:
    if path.exists():
        _reporter().artifact_written(
            stage=stage,
            path=str(path),
            artifact_type=artifact_type,
            context=context,
        )


# ---------------------------------------------------------------------------
# Pipeline class
# ---------------------------------------------------------------------------

class Pipeline:
    def __init__(
        self,
        acquirer: SourceAcquirer,
        transcript_provider: TranscriptProvider,
        activity_detector: ActivityDetector,
        vision: VisionBackend,
        plugin: DomainPlugin,
        cache: StageCache,
        renderer: ReportRenderer,
        cfg: WVConfig,
        reporter: RunReporter | None = None,
    ):
        self.acquirer = acquirer
        self.transcript_provider = transcript_provider
        self.activity_detector = activity_detector
        self.vision = vision
        self.plugin = plugin
        self.cache = cache
        self.renderer = renderer
        self.cfg = cfg
        self.reporter = reporter or _reporter()

    def run(self, input_str: str) -> Path:
        reporter_ctx = use_reporter(self.reporter)
        reporter_ctx.__enter__()
        cfg = self.cfg
        try:
            # ----------------------------------------------------------------
            # Stage 0: acquire video
            # ----------------------------------------------------------------
            self.reporter.stage_started("acquire", "Acquire source media", context={"input": input_str})
            base_out = cfg.output or Path(".withvideo")
            base_out.mkdir(parents=True, exist_ok=True)

            self.reporter.task_started("acquire.fetch", f"fetch ({input_str[:60]})")
            media, video_name, meta = self.acquirer.acquire(
                input_str,
                base_out / "_staging",
                {},
            )
            staging = base_out / "_staging"
            work_dir = base_out / video_name
            if staging.exists():
                _materialize_staging_dir(staging, work_dir)
            elif not work_dir.exists():
                work_dir.mkdir(parents=True, exist_ok=True)
            (work_dir / "keyframes").mkdir(exist_ok=True)

            media = _relocate_media_handle(media, staging, work_dir)
            _relocate_meta_paths(meta, staging, work_dir)
            # Enable progress file for external polling (e.g. Claude Code)
            self.reporter._progress_file = work_dir / ".wv_progress.json"
            self.reporter.task_completed(
                "acquire.fetch",
                f"{meta.platform.value}  字幕: {meta.subtitle_quality.value}",
            )
            if meta.chapters:
                self.reporter.human(f"[wv]   章节: {len(meta.chapters)} 个（平台提供）")
            _warn_if_low_resolution(media, self.reporter)
            _emit_artifact_if_exists("acquire", work_dir / "source.info.json", "source_info")
            for track in [*meta.subtitles, *meta.auto_captions]:
                if track.path is not None:
                    _emit_artifact_if_exists(
                        "acquire",
                        track.path,
                        "subtitle_track",
                        {"lang": track.lang, "format": track.fmt, "generated": track.is_generated},
                    )
            self.reporter.stage_completed(
                "acquire",
                "Acquire source media completed",
                context={
                    "platform": meta.platform.value,
                    "subtitle_quality": meta.subtitle_quality.value,
                    "work_dir": str(work_dir),
                },
            )
            # Post-acquire time estimate (now that we know duration and mode)
            if meta.duration:
                dur_min = int(meta.duration // 60)
                dur_sec = int(meta.duration % 60)
                dur_str = f"{dur_min}:{dur_sec:02d}"
                mode_str = "远程" if cfg.media_access == "remote" else "本地"
                vision_str = "含 vision" if cfg.vision != "none" else "纯 transcript"
                # rough estimate: semantic ~60s + vision ~25s/window + guide ~30s
                # We don't know visual_n yet, so use duration as a proxy (longer videos → more steps)
                estimated_s = 60 + min(max(int(meta.duration / 30), 3), 15) * 25 + 30
                est_min = max(1, estimated_s // 60)
                self.reporter.human(
                    f"[wv] 预计还需 ~{est_min}-{est_min + 2} 分钟"
                    f"  ({dur_str} 视频 · {mode_str} · {vision_str})"
                )

            # ----------------------------------------------------------------
            # Stage 1: transcription
            # ----------------------------------------------------------------
            self.reporter.stage_started(
                "transcript",
                "Transcription started",
                context={"skip": "transcript" in cfg.skip},
            )
            if _is_remote_media(media) and not _has_remote_transcript(meta):
                raise DecisionRequired(
                    kind="remote_to_download",
                    reason_code="platform_subtitles_unavailable",
                    message="Remote media access requires platform subtitles; remote-mode Whisper is unsupported.",
                    options=["download", "abort"],
                    default_option="download",
                    stage="transcript",
                    context={
                        "platform": meta.platform.value,
                        "subtitle_quality": meta.subtitle_quality.value,
                        "media_access": cfg.media_access,
                    },
                )
            cached_transcribe = self.cache.cached(_transcribe)
            self.reporter.task_started("transcript.transcribe", f"transcribe ({cfg.transcript})")
            transcript = cached_transcribe(
                self.transcript_provider, _local_video_path(media), meta, work_dir
            )
            self.reporter.task_completed(
                "transcript.transcribe",
                f"{len(transcript.segments)} 段 ({transcript.source.value})",
            )
            self.reporter.stage_completed(
                "transcript",
                "Transcription completed",
                context={"segments": len(transcript.segments), "source": transcript.source.value},
            )

            # Stage 1b: transcript-first plugin detection
            if hasattr(self.plugin, "select_from_transcript"):
                self.plugin.select_from_transcript(transcript)
                self.reporter.human(f"[wv]   插件 (transcript): {self.plugin.selected_name}")
                self.reporter.emit(
                    "plugin_selected",
                    stage="transcript",
                    message=f"Plugin selected: {self.plugin.selected_name}",
                    context={"plugin": self.plugin.selected_name, "method": "transcript"},
                )
            elif hasattr(self.plugin, "name"):
                self.reporter.human(f"[wv]   插件: {self.plugin.name}")
                self.reporter.emit(
                    "plugin_selected",
                    stage="transcript",
                    message=f"Plugin selected: {self.plugin.name}",
                    context={"plugin": self.plugin.name, "method": "transcript"},
                )

            # Stage 1c: activity detection (optional evidence tool)
            self.reporter.stage_started("activity", "Activity analysis started")
            if _is_remote_media(media):
                profile = ActivityProfile(
                    per_second=[],
                    threshold=0.0,
                    bursts=[],
                    encoding_type="REMOTE_SKIPPED",
                )
                self.reporter.task_started("activity.detect", "detect activity")
                self.reporter.task_completed("activity.detect", "跳过 (remote media)")
                self.reporter.stage_completed(
                    "activity",
                    "Activity analysis skipped",
                    context={"skipped": True, "reason": "remote_media_access"},
                )
            else:
                cached_detect = self.cache.cached(_detect_activity)
                local_video_path = _local_video_path(media)
                if local_video_path is None:
                    raise RuntimeError("Local activity detection requires a local video path.")
                self.reporter.task_started("activity.detect", "detect activity")
                profile = cached_detect(self.activity_detector, local_video_path)
                self.reporter.task_completed(
                    "activity.detect",
                    f"{len(profile.bursts)} 个爆发",
                )
                self.reporter.stage_completed(
                    "activity",
                    "Activity analysis completed",
                    context={"bursts": len(profile.bursts)},
                )

            # ----------------------------------------------------------------
            # Stage 2: semantic judgment — one LLM call classifies everything
            # ----------------------------------------------------------------
            self.reporter.stage_started(
                "semantic",
                "Semantic analysis started",
                context={"skip": "semantic" in cfg.skip},
            )
            cached_timeline = self.cache.cached(_build_timeline)
            self.reporter.task_started("semantic.llm", "semantic judgment")
            steps = cached_timeline(transcript, profile, meta, cfg, work_dir)
            self.reporter.task_completed("semantic.llm")
            explain_n = sum(1 for s in steps if s.explain)
            operate_n = sum(1 for s in steps if s.operate)
            verify_n = sum(1 for s in steps if s.verify)
            visual_n = sum(1 for s in steps if s.operate and s.operate.needs_visual_evidence)
            self.reporter.human(f"[wv]   RepeatSteps: {len(steps)}  (EXPLAIN:{explain_n} OPERATE:{operate_n} VERIFY:{verify_n})")
            self.reporter.human(f"[wv]   需要 vision 分析: {visual_n} 个 operate 窗口")
            if cfg.vision != "none" and visual_n > 0:
                vision_eta = visual_n * 25 + 30  # ~25s/window + 30s guide
                self.reporter.human(f"[wv]   vision + guide 预计还需 ~{vision_eta // 60 + 1} 分钟")
            self.reporter.stage_completed(
                "semantic",
                "Semantic analysis completed",
                context={
                    "repeat_steps": len(steps),
                    "explain_count": explain_n,
                    "operate_count": operate_n,
                    "verify_count": verify_n,
                    "vision_windows": visual_n,
                },
            )

            # Attach activity bursts to windows (connects Stage 1c → Stage 3)
            _attach_bursts_to_windows(steps, profile)
            # Heuristic override: significant SCROLLING/TAB_SWITCH forces visual evidence
            _force_visual_for_significant_bursts(steps)
            # Heuristic: infer content_focus from transcript keywords + SCROLLING
            _infer_content_focus(steps)
            explain_visual_n = sum(1 for s in steps if s.explain and s.explain.needs_visual_evidence)
            if explain_visual_n > 0:
                self.reporter.human(f"[wv]   需要 content-flash 分析: {explain_visual_n} 个 explain 窗口")

            # ----------------------------------------------------------------
            # Stage 3: selective tool invocation (vision, only where needed)
            # ----------------------------------------------------------------
            vision_enabled = cfg.vision != "none"
            if vision_enabled and (visual_n > 0 or explain_visual_n > 0) and "vision" not in cfg.skip:
                self.reporter.stage_started("vision", "Vision analysis started")

                # Extract keyframes only for needs_visual_evidence windows
                keyframes_dir = work_dir / "keyframes"
                # Clean stale keyframes on --force
                if cfg.cache == "none" and keyframes_dir.exists():
                    for old_frame in keyframes_dir.glob("*.png"):
                        old_frame.unlink()

                video_duration = _probe_duration(media)
                total_frames = 0
                visual_steps = [s for s in steps if s.operate and s.operate.needs_visual_evidence]
                self.reporter.task_started("vision.extract", "extract keyframes", total=len(visual_steps))
                for ei, step in enumerate(visual_steps):
                    if total_frames >= cfg.max_frames:
                        break
                    frames = _extract_window_frames(
                        step.operate, media, keyframes_dir, video_duration
                    )
                    step.operate.keyframes = frames
                    total_frames += len(frames)
                    self.reporter.task_progress("vision.extract", ei + 1, message=f"{len(frames)} frames")
                self.reporter.task_completed("vision.extract", f"{total_frames} 张关键帧")

                # Content-flash: extract keyframes from EXPLAIN windows needing visual evidence
                explain_visual = [s for s in steps if s.explain and s.explain.needs_visual_evidence and not s.explain.keyframes]
                if explain_visual:
                    cf_total = 0
                    self.reporter.task_started("vision.cf_extract", "content-flash keyframes", total=len(explain_visual))
                    for ci, step in enumerate(explain_visual):
                        if total_frames + cf_total >= cfg.max_frames:
                            break
                        frames = _extract_window_frames(step.explain, media, keyframes_dir, video_duration)
                        step.explain.keyframes = frames
                        cf_total += len(frames)
                        self.reporter.task_progress("vision.cf_extract", ci + 1, message=f"{len(frames)} frames")
                    self.reporter.task_completed("vision.cf_extract", f"{cf_total} 张 content-flash 帧")
                    total_frames += cf_total

                # Fallback vision-based plugin detection (AFTER keyframe extraction)
                if hasattr(self.plugin, "select") and not getattr(self.plugin, "_transcript_selected", False):
                    sample_frames_list: list[Frame] = []
                    for s in steps[:3]:
                        if s.operate and s.operate.keyframes:
                            sample_frames_list.extend(s.operate.keyframes[:2])
                        elif s.explain and s.explain.keyframes:
                            sample_frames_list.extend(s.explain.keyframes[:2])
                    if sample_frames_list:
                        self.plugin.select(sample_frames_list)
                        self.reporter.human(f"[wv]   插件 (vision): {self.plugin.selected_name}")
                        self.reporter.emit(
                            "plugin_selected",
                            stage="vision",
                            message=f"Plugin selected: {self.plugin.selected_name}",
                            context={"plugin": self.plugin.selected_name, "method": "vision"},
                        )

                # Vision analysis (OPERATE + EXPLAIN windows with visual evidence)
                analyzed = 0

                # Build unified list of (step, window) pairs for analysis
                _analyze_pairs: list[tuple[RepeatStep, Window]] = []
                for s in steps:
                    if s.operate and s.operate.needs_visual_evidence and s.operate.keyframes:
                        _analyze_pairs.append((s, s.operate))
                    if s.explain and s.explain.needs_visual_evidence and s.explain.keyframes:
                        _analyze_pairs.append((s, s.explain))

                self.reporter.task_started("vision.analyze", "analyze frames", total=len(_analyze_pairs))
                hit_limit = False
                for ai, (step, window) in enumerate(_analyze_pairs):
                    if analyzed >= cfg.max_frames:
                        hit_limit = True
                        break
                    n = len(window.keyframes)
                    label = "explain" if window.type == WindowType.EXPLAIN else "operate"
                    with self.reporter.task(f"vision.analyze.{label}-{ai+1}", f"{label} {ai+1}/{len(_analyze_pairs)}", total=n):
                        _analyze_window(window, self.vision, self.plugin)
                        vision_ops: list[Operation] = []
                        for fa in window.frame_analyses:
                            vision_ops.extend(self.plugin.extract_operations(fa))
                        if vision_ops:
                            # Preserve transcript text_content when vision ops lack it
                            transcript_texts = [
                                op.text_content for op in step.operations
                                if op.text_content and op.source == "transcript"
                            ]
                            text_idx = 0
                            for v_op in vision_ops:
                                if not v_op.text_content and text_idx < len(transcript_texts):
                                    v_op.text_content = transcript_texts[text_idx]
                                    text_idx += 1
                                if not v_op.source:
                                    v_op.source = "vision"
                            step.operations = vision_ops
                            window.operations = vision_ops
                        # else: keep transcript operations already set by _populate_transcript_operations
                    analyzed += n
                    self.reporter.task_progress("vision.analyze", ai + 1)
                limit_note = f" (达到限制 {cfg.max_frames})" if hit_limit else ""
                self.reporter.task_completed("vision.analyze", f"{analyzed} 帧{limit_note}")
                self.reporter.stage_completed(
                    "vision",
                    "Vision analysis completed",
                    context={"frames_analyzed": analyzed, "frames_extracted": total_frames},
                )
            else:
                self.reporter.stage_completed(
                    "vision",
                    "Vision analysis skipped",
                    context={"skipped": True},
                )

            # ----------------------------------------------------------------
            # Stage 4: generate Repeat Guide
            # ----------------------------------------------------------------
            if "guide" not in cfg.skip:
                self.reporter.stage_started("guide", "Guide synthesis started")
                self.reporter.task_started("guide.synthesize", "synthesize guide")
                max_guide_retries = 2
                guide = None
                for attempt in range(max_guide_retries + 1):
                    try:
                        guide = _generate_guide(steps, self.plugin, meta, cfg, work_dir)
                        break
                    except DecisionRequired as decision:
                        if decision.kind == "llm_stage_retry_or_abort" and attempt < max_guide_retries:
                            self.reporter.human(f"[wv]   guide 重试 ({attempt + 1}/{max_guide_retries})...")
                            self.reporter.decision_required(decision)
                            self.reporter.decision_selected(decision, "retry")
                            continue
                        raise
                if guide is None:
                    raise RuntimeError("Guide synthesis failed after retries")
                self.reporter.task_completed("guide.synthesize")

                with self.reporter.task("guide.render", "render outputs"):
                    # Human-readable guide.md (with code files externalized)
                    out_path = work_dir / f"guide{self.renderer.extension()}"
                    if hasattr(self.renderer, "render_with_code_files"):
                        md_text, code_files = self.renderer.render_with_code_files(guide)
                        for cf in code_files:
                            fp = work_dir / cf.rel_path
                            fp.parent.mkdir(parents=True, exist_ok=True)
                            fp.write_text(cf.content, encoding="utf-8")
                        out_path.write_text(md_text, encoding="utf-8")
                    else:
                        out_path.write_text(self.renderer.render(guide), encoding="utf-8")

                    # Machine-readable semantic.json (authority for wv act)
                    semantic_path = work_dir / "semantic.json"
                    semantic_path.write_text(
                        _render_semantic_json(guide), encoding="utf-8"
                    )
                _emit_artifact_if_exists("guide", out_path, "guide_markdown")
                _emit_artifact_if_exists("guide", semantic_path, "semantic_json")

                total_ops = sum(len(s.operations) for s in guide.steps)
                self.reporter.human(f"\n✅ Repeat Guide 已生成: {out_path}")
                self.reporter.human(f"✅ semantic.json 已生成: {semantic_path}")
                self.reporter.human(f"   步骤: {len(guide.steps)}  操作: {total_ops}  知识点: {len(guide.knowledge_index)}")
                self.reporter.stage_completed(
                    "guide",
                    "Guide synthesis completed",
                    context={
                        "steps": len(guide.steps),
                        "operations": total_ops,
                        "knowledge_points": len(guide.knowledge_index),
                    },
                )
                return out_path
            else:
                self.reporter.human("[wv] Stage 4: 跳过 (--skip guide)")
                self.reporter.stage_completed(
                    "guide",
                    "Guide synthesis skipped",
                    context={"skipped": True},
                )
                return work_dir
        finally:
            reporter_ctx.__exit__(None, None, None)


# ---------------------------------------------------------------------------
# Stage functions (top-level so joblib can pickle them)
# ---------------------------------------------------------------------------

def _transcribe(
    provider: TranscriptProvider,
    video_path: Path | None,
    meta: SourceMeta,
    work_dir: Path,
) -> Transcript:
    return provider.transcribe(video_path, meta, work_dir)


def _detect_activity(detector: ActivityDetector, video_path: Path) -> ActivityProfile:
    return detector.detect(video_path)


def _has_remote_transcript(meta: SourceMeta) -> bool:
    return has_usable_tracks(meta.subtitles) or has_usable_tracks(meta.auto_captions)


def _build_timeline(
    transcript: Transcript,
    profile: ActivityProfile,
    meta: SourceMeta,
    cfg: WVConfig,
    work_dir: Path,
) -> list[RepeatStep]:
    """Stage 2: semantic judgment → RepeatSteps."""
    topic_blocks = _segment_into_topics(transcript, meta)
    classified = _semantic_judgment(topic_blocks, profile, cfg, work_dir)
    topic_blocks, classified = _split_multi_action_blocks(topic_blocks, classified)
    windows = _blocks_to_windows(transcript.segments, topic_blocks, classified)
    steps = _assemble_steps(windows)
    _populate_transcript_operations(steps)
    return steps


# ---------------------------------------------------------------------------
# Transcript operation helpers
# ---------------------------------------------------------------------------

_MAX_OPS_PER_BLOCK = 2   # operate blocks with more ops get split


def _split_multi_action_blocks(
    topic_blocks: list[dict],
    classifications: list[dict],
) -> tuple[list[dict], list[dict]]:
    """Split operate blocks that have > _MAX_OPS_PER_BLOCK transcript_operations."""
    new_blocks: list[dict] = []
    new_cls: list[dict] = []

    for block, cls in zip(topic_blocks, classifications):
        ops = cls.get("transcript_operations") or []
        if cls.get("intent") != "operate" or len(ops) <= _MAX_OPS_PER_BLOCK:
            new_blocks.append(block)
            new_cls.append(cls)
            continue

        # Split segments proportionally across operations
        segments = block["segments"]
        n_ops = len(ops)
        chunk = max(1, len(segments) // n_ops)

        # Distribute knowledge_topics across sub-blocks (one each, round-robin)
        all_kts = cls.get("knowledge_topics") or []

        for oi, op in enumerate(ops):
            start_idx = oi * chunk
            end_idx = start_idx + chunk if oi < n_ops - 1 else len(segments)
            sub_segs = segments[start_idx:end_idx]
            # Avoid empty segment slices — give at least one unique segment
            if not sub_segs:
                # Use last segment but only for the last sub-block
                if oi == n_ops - 1:
                    sub_segs = segments[-1:]
                else:
                    continue  # skip empty sub-blocks
            sub_block = _make_block(0, sub_segs)
            # Each sub-block gets at most one knowledge topic (distributed, not duplicated)
            sub_kts = [all_kts[oi]] if oi < len(all_kts) else []
            sub_cls = {
                **cls,
                "transcript_operations": [op],
                "operation_cue": op.get("description") or cls.get("operation_cue") or "",
                "knowledge_topics": sub_kts,
            }
            new_blocks.append(sub_block)
            new_cls.append(sub_cls)

    # Re-index
    for i, b in enumerate(new_blocks):
        b["index"] = i
    for i, c in enumerate(new_cls):
        c["index"] = i

    return new_blocks, new_cls


def _populate_transcript_operations(steps: list[RepeatStep]) -> None:
    """Copy transcript operations from operate/explain windows to step when vision hasn't filled it."""
    for step in steps:
        if step.operate and step.operate.operations and not step.operations:
            step.operations = list(step.operate.operations)
        # Also surface text_content operations from explain window (code shown during lecture)
        if step.explain and step.explain.operations and not step.operations:
            step.operations = list(step.explain.operations)


def _merge_bursts(bursts: list[ActivityBurst]) -> ActivityBurst:
    """Merge multiple bursts into a synthetic composite burst."""
    peak_burst = max(bursts, key=lambda b: b.peak_score)
    merged_start = min(b.start for b in bursts)
    merged_end = max(b.end for b in bursts)
    # Merge heatmaps (element-wise max)
    merged_heatmap: list[list[float]] = []
    if any(b.heatmap for b in bursts):
        merged_heatmap = [[0.0] * 9 for _ in range(16)]
        for b in bursts:
            if b.heatmap:
                for c in range(min(16, len(b.heatmap))):
                    for r in range(min(9, len(b.heatmap[c]))):
                        merged_heatmap[c][r] = max(merged_heatmap[c][r], b.heatmap[c][r])
    return ActivityBurst(
        start=merged_start,
        end=merged_end,
        peak_time=peak_burst.peak_time,
        peak_score=peak_burst.peak_score,
        duration=merged_end - merged_start,
        pattern=peak_burst.pattern,
        heatmap=merged_heatmap,
    )


def _attach_bursts_to_windows(steps: list[RepeatStep], profile: ActivityProfile) -> None:
    """Match activity bursts to windows by temporal overlap.

    Collects ALL overlapping bursts per window and merges them into a single
    synthetic burst.  This ensures scrolling / multi-burst sequences are fully
    covered by _smart_frame_extraction.
    """
    if not profile.bursts:
        return
    for step in steps:
        for window in (step.explain, step.operate, step.verify):
            if window is None or window.activity_burst is not None:
                continue
            overlapping: list[ActivityBurst] = []
            for burst in profile.bursts:
                overlap_start = max(window.start, burst.start)
                overlap_end = min(window.end, burst.end)
                if overlap_end > overlap_start:
                    overlapping.append(burst)
            if not overlapping:
                continue
            if len(overlapping) == 1:
                window.activity_burst = overlapping[0]
            else:
                window.activity_burst = _merge_bursts(overlapping)


_VISUAL_FORCE_PATTERNS = {BurstPattern.SCROLLING, BurstPattern.TAB_SWITCH}
_VISUAL_FORCE_MIN_DURATION = 2.0  # seconds


def _force_visual_for_significant_bursts(steps: list[RepeatStep]) -> None:
    """Override needs_visual_evidence for windows with significant scrolling/tab-switch activity."""
    for step in steps:
        for window in (step.explain, step.operate):
            if window is None or window.needs_visual_evidence:
                continue
            burst = window.activity_burst
            if (
                burst is not None
                and burst.pattern in _VISUAL_FORCE_PATTERNS
                and burst.duration >= _VISUAL_FORCE_MIN_DURATION
            ):
                window.needs_visual_evidence = True


_CONTENT_DISPLAY_PATTERNS = [
    re.compile(r"(?:写|打开|看|展示|显示|浏览|翻).{0,4}(?:Markdown|MD|文档|文件|配置|readme|代码|prompt|模板)", re.IGNORECASE),
    re.compile(r"(?:这个|这份|这篇|这是).{0,4}(?:文件|文档|内容|配置|页面|模板)"),
    re.compile(r"(?:用横线分隔|分页|分段|每一页|每页)"),
]


def _infer_content_focus(steps: list[RepeatStep]) -> None:
    """Heuristic: set content_focus for SCROLLING windows where transcript mentions content display."""
    for step in steps:
        for window in (step.explain, step.operate):
            if window is None or window.content_focus:
                continue
            burst = window.activity_burst
            if burst is None or burst.pattern != BurstPattern.SCROLLING:
                continue
            text = " ".join(s.text for s in window.transcript_segments)
            for pat in _CONTENT_DISPLAY_PATTERNS:
                if pat.search(text):
                    window.content_focus = "讲师正在展示的文件/文档内容"
                    break


def _summarize_bursts_for_block(block: dict, profile: ActivityProfile) -> list[dict]:
    """Summarize activity bursts overlapping a topic block for LLM consumption."""
    from .impl.activity.mv import describe_hot_zones

    result = []
    for burst in profile.bursts:
        if block["start"] < burst.end and block["end"] > burst.start:
            entry = {
                "time": f"{burst.start:.1f}-{burst.end:.1f}",
                "pattern": burst.pattern.value,
                "peak_score": round(burst.peak_score, 2),
                "duration_s": round(burst.duration, 2),
            }
            if burst.heatmap:
                entry["hot_zones"] = describe_hot_zones(burst.heatmap)
            result.append(entry)
    return result


# ---------------------------------------------------------------------------
# Topic segmentation
# ---------------------------------------------------------------------------

_SILENCE_GAP = 1.2    # seconds of silence → block boundary (Chinese speech has short pauses)
_MAX_BLOCK_CHARS = 400
_MAX_BLOCK_SECS = 25.0
_MIN_BLOCKS_PER_MINUTE = 2.5  # guarantee minimum granularity


def _segment_into_topics(transcript: Transcript, meta: SourceMeta) -> list[dict]:
    """Split transcript into coherent topic blocks by silence gaps and chapter boundaries."""
    segs = [s for s in transcript.segments if s.text.strip()]
    if not segs:
        return []

    chapter_boundaries = {ch.start for ch in meta.chapters} if meta.chapters else set()

    blocks = _split_by_gaps(segs, chapter_boundaries, _SILENCE_GAP, _MAX_BLOCK_SECS, _MAX_BLOCK_CHARS)

    # Adaptive: if too few blocks for the video duration, re-split with tighter thresholds
    video_dur = segs[-1].end - segs[0].start
    min_blocks = max(3, int(video_dur / 60.0 * _MIN_BLOCKS_PER_MINUTE))
    if len(blocks) < min_blocks:
        # Try progressively tighter gap thresholds
        for gap in (0.8, 0.5, 0.3):
            max_secs = max(10.0, video_dur / min_blocks)
            max_chars = max(150, _MAX_BLOCK_CHARS // 2)
            blocks = _split_by_gaps(segs, chapter_boundaries, gap, max_secs, max_chars)
            if len(blocks) >= min_blocks:
                break

    # Last resort: if still too few, force split large blocks by segment count
    if len(blocks) < min_blocks:
        blocks = _force_split_large_blocks(blocks, min_blocks)

    return blocks


def _split_by_gaps(
    segs: list[Segment],
    chapter_boundaries: set[float],
    silence_gap: float,
    max_block_secs: float,
    max_block_chars: int,
) -> list[dict]:
    """Core splitting logic with configurable thresholds."""
    blocks: list[dict] = []
    current_segs: list[Segment] = [segs[0]]

    for seg in segs[1:]:
        prev = current_segs[-1]
        gap = seg.start - prev.end
        at_chapter = any(prev.end <= b <= seg.start for b in chapter_boundaries)
        block_text = " ".join(s.text for s in current_segs)
        too_long = (seg.end - current_segs[0].start > max_block_secs or
                    len(block_text) > max_block_chars)

        if gap > silence_gap or at_chapter or too_long:
            blocks.append(_make_block(len(blocks), current_segs))
            current_segs = [seg]
        else:
            current_segs.append(seg)

    if current_segs:
        blocks.append(_make_block(len(blocks), current_segs))

    return blocks


def _force_split_large_blocks(blocks: list[dict], target_count: int) -> list[dict]:
    """Split largest blocks by segment count until we hit target_count."""
    result = list(blocks)
    while len(result) < target_count:
        # Find the largest block (by segment count)
        largest_idx = max(range(len(result)), key=lambda i: len(result[i]["segments"]))
        block = result[largest_idx]
        block_segs = block["segments"]
        if len(block_segs) < 2:
            break  # can't split further
        mid = len(block_segs) // 2
        left = _make_block(0, block_segs[:mid])
        right = _make_block(0, block_segs[mid:])
        result[largest_idx:largest_idx+1] = [left, right]

    # Re-index
    for i, b in enumerate(result):
        b["index"] = i
    return result


def _make_block(index: int, segs: list[Segment]) -> dict:
    return {
        "index": index,
        "start": segs[0].start,
        "end": segs[-1].end,
        "text": " ".join(s.text.strip() for s in segs),
        "segments": segs,
    }


# ---------------------------------------------------------------------------
# Semantic judgment (Stage 2 core)
# ---------------------------------------------------------------------------

_SEMANTIC_PROMPT_TMPL = """\
你是教程视频分析专家。以下是一段教程视频的文字记录，已按主题块分割。
请对每个主题块分类，判断讲师在做什么。

主题块数据：
{blocks_json}

请返回 JSON 数组，每个元素对应一个主题块（按 index 顺序）：
[
  {{
    "index": 0,
    "intent": "explain|operate|verify|transition",
    "confidence": 0.85,
    "needs_visual_evidence": false,
    "knowledge_topics": ["知识点1", "知识点2"],
    "operation_cue": "可选，describe 具体操作（operate 时填写）",
    "content_focus": "可选，讲师展示的需要 vision 重点读取的内容",
    "transcript_operations": [
      {{
        "capability": "ui_action",
        "action": "navigate",
        "target": "GitHub",
        "intent": "搜索官方设计资产",
        "app_context": "Browser",
        "description": "在 GitHub 上搜索 Google Design Guide"
      }},
      {{
        "capability": "text_input",
        "action": "run_command",
        "target": "终端",
        "intent": "安装依赖",
        "app_context": "Terminal",
        "description": "运行 pip install 安装 uvicorn",
        "text_content": "pip install uvicorn"
      }}
    ]
  }}
]

分类规则：
- explain: 讲师在解释概念、介绍背景、展示原理。即使画面有变化（如滚动浏览代码），重点是讲解，不是操作。
- operate: 讲师在执行具体操作——写代码、运行命令、配置设置、创建文件。判断标准：旁白里有明确的"动词+宾语"（如"安装 uvicorn"、"创建 main.py"、"运行这个命令"）。
- verify: 讲师在检查结果——打开浏览器验证、查看输出结果、确认配置生效。
- transition: 纯过渡片段（片头、片尾、赞助商广告、无实质内容）。

knowledge_topics 规则：
- 列出这个主题块里讲师传达的所有知识点，不限数量
- 每个知识点用一句话概括，侧重"观众应该学到什么"
- explain 块通常有 1-3 个知识点
- operate 块也可以有知识点（讲师边做边解释的情况）
- transition 块通常为空数组 []

needs_visual_evidence 规则：
- operate 块：旁白无法完整重建操作细节时为 true（如"点这里"但没说具体位置）
- explain 块：当 screen_activity 显示有内容展示（TAB_SWITCH/SCROLLING）且旁白提到代码/文件/配置/界面内容但未给出完整文本时，设为 true
- verify / transition：必须为 false

content_focus 规则：
- 当旁白提到正在展示/浏览某个文件/文档/网页/配置的具体内容，且 screen_activity 显示 SCROLLING 或 TAB_SWITCH 时填写。
- 值描述 vision 应重点读取什么（如 "Markdown 文件的完整文本"、"终端输出的完整日志"、"配置文件的键值对"、"网页上的步骤说明"）。
- 仅在展示的内容本身是观众需要的关键信息时填写。如果旁白已经覆盖了要点，不需要填写。
- verify / transition 为空字符串 ""。

transcript_operations 规则：
- 只从旁白原文中提取有明确"动词+宾语"的操作，不要推断或编造
- capability: "ui_action"（界面操作）| "text_input"（输入文字/命令）
- ui_action 的 action 值: "navigate" | "open" | "select" | "download" | "dismiss" | "confirm"
- text_input 的 action 值: "search_text" | "enter_text" | "input_prompt" | "send_prompt" | "run_command" | "write_code"
- target: 操作对象的具体描述（如 "GitHub 搜索框"、"VS Code 终端"）
- intent: 这个操作的目的（用户视角）
- app_context: 操作所在应用 / 环境（如 "GitHub"、"VS Code"、"Terminal"、"Figma"、"Browser"）
- description: 人类可读的操作描述
- text_content: 当旁白里有**具体的命令文本、代码片段、配置值、prompt 内容、文件名**时，从旁白原文中逐字提取，保持原始格式。旁白只提到操作但没给出具体文本时（如"运行那个命令"），留空字符串 ""。不要编造或推断旁白中没有的内容。
- explain 块：如果讲师在讲解中朗读或展示了具体代码、命令、配置值、prompt 模板，用 text_input 操作记录到 transcript_operations 中（text_content 要填完整内容）。纯概念讲解则保持空数组 []。
- transition 的 transcript_operations 必须为空数组 []
- 即使 needs_visual_evidence=true，也填写旁白能确认的部分

只输出 JSON 数组，不要其他内容。"""

_SEMANTIC_FILE_PROMPT_TMPL = """\
你是教程视频分析专家。
请读取本地文件 `{input_path}` 中的 JSON 数据，并对其中 `topic_blocks` 的每个主题块分类。

返回 JSON 数组，每个元素对应一个主题块（按 index 顺序）：
[
  {{
    "index": 0,
    "intent": "explain|operate|verify|transition",
    "confidence": 0.85,
    "needs_visual_evidence": false,
    "knowledge_topics": ["知识点1", "知识点2"],
    "operation_cue": "可选，describe 具体操作（operate 时填写）",
    "content_focus": "可选，讲师展示的需要 vision 重点读取的内容",
    "transcript_operations": [
      {{
        "capability": "ui_action",
        "action": "navigate",
        "target": "GitHub",
        "intent": "搜索官方设计资产",
        "app_context": "Browser",
        "description": "在 GitHub 上搜索 Google Design Guide"
      }},
      {{
        "capability": "text_input",
        "action": "run_command",
        "target": "终端",
        "intent": "安装依赖",
        "app_context": "Terminal",
        "description": "运行 pip install 安装 uvicorn",
        "text_content": "pip install uvicorn"
      }}
    ]
  }}
]

screen_activity 字段说明：
每个主题块可能包含 screen_activity 数组，描述该时间段内检测到的屏幕活动（来自 H.264 运动向量分析）：
- pattern: 活动类型
  - TAB_SWITCH: 画面整体快速切换（<1秒），通常是切换标签、展示新内容、翻页
  - SCROLLING: 方向性滚动（代码滚动、文档翻页、网页浏览）
  - TYPING: 局部持续变化（代码编辑、文字输入）
  - CLICK_MENU: 局部短暂变化（菜单点击、按钮操作）
  - VIEWPORT_MANIPULATION: 中等范围持续变化（3D视口旋转、画布拖拽）
  - DRAG: 中等范围拖拽操作
- hot_zones: 变化集中的屏幕区域
- peak_score: 活动强度（越高变化越剧烈）
- duration_s: 活动持续时间
结合 screen_activity 和旁白内容综合判断。

分类规则：
- explain: 讲师在解释概念、介绍背景、展示原理。即使画面有变化（如滚动浏览代码），重点是讲解，不是操作。
- operate: 讲师在执行具体操作——写代码、运行命令、配置设置、创建文件。判断标准：旁白里有明确的"动词+宾语"。
- verify: 讲师在检查结果——打开浏览器验证、查看输出结果、确认配置生效。
- transition: 纯过渡片段（片头、片尾、赞助商广告、无实质内容）。

knowledge_topics 规则：
- 列出这个主题块里讲师传达的所有知识点，不限数量。
- transition 块通常为空数组 []。

needs_visual_evidence 规则：
- operate 块：旁白无法完整重建操作细节时为 true（如"点这里"但没说具体位置）。
- explain 块：当 screen_activity 显示有内容展示（TAB_SWITCH/SCROLLING）且旁白提到代码/文件/配置/界面内容但未给出完整文本时，设为 true。场景：讲师快速翻过代码、滚动展示文档、切换标签展示结果。
- verify / transition：必须为 false。

content_focus 规则：
- 当旁白提到正在展示/浏览某个文件/文档/网页/配置的具体内容，且 screen_activity 显示 SCROLLING 或 TAB_SWITCH 时填写。
- 值描述 vision 应重点读取什么（如 "Markdown 文件的完整文本"、"终端输出的完整日志"、"配置文件的键值对"、"网页上的步骤说明"）。
- 仅在展示的内容本身是观众需要的关键信息时填写。如果旁白已经覆盖了要点，不需要填写。
- verify / transition 为空字符串 ""。

transcript_operations 规则：
- 只从旁白原文中提取有明确"动词+宾语"的操作，不要推断或编造。
- text_content: 旁白中有具体命令、代码、配置值、prompt 内容时，逐字提取。没给出具体文本时留空 ""。
- explain 块：讲师朗读/展示了具体代码、命令、配置值、prompt 模板时，用 text_input 记录（text_content 填完整内容）。纯概念讲解保持空数组 []。
- transition 的 transcript_operations 必须为空数组 []。

只输出 JSON 数组，不要其他内容。"""


def _resolve_llm_command(prompt: str, cfg: WVConfig) -> list[str]:
    parts = shlex.split(cfg.llm_command)
    if not parts:
        raise RuntimeError(
            "未配置 LLM 命令。请安装 codex 或 claude CLI，"
            "或设置 WV_LLM_COMMAND 环境变量，"
            "或传入 --llm-command 参数。"
        )
    resolved: list[str] = []
    placeholder_seen = False
    for part in parts:
        if "{prompt}" in part:
            placeholder_seen = True
            replaced = part.replace("{prompt}", prompt)
            if replaced:
                resolved.append(replaced)
            continue
        resolved.append(part)
    if not placeholder_seen and "-" not in resolved:
        resolved.append(prompt)
    return resolved


def _resolve_llm_input(prompt: str, cfg: WVConfig) -> str | None:
    parts = shlex.split(cfg.llm_command)
    if any("{prompt}" in part for part in parts):
        return None
    if any(part == "-" for part in parts):
        return prompt
    return None


def _llm_artifact_dir(work_dir: Path) -> Path:
    path = work_dir / "llm"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _write_llm_stage_artifacts(
    *,
    stage: str,
    work_dir: Path,
    payload: dict,
    prompt: str,
) -> tuple[Path, Path, Path]:
    llm_dir = _llm_artifact_dir(work_dir)
    input_path = llm_dir / f"{stage}_input.json"
    prompt_path = llm_dir / f"{stage}_prompt.txt"
    raw_output_path = llm_dir / f"{stage}_output.raw.txt"
    input_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    prompt_path.write_text(prompt, encoding="utf-8")
    _emit_artifact_if_exists(stage, input_path, f"{stage}_input")
    _emit_artifact_if_exists(stage, prompt_path, f"{stage}_prompt")
    return input_path, prompt_path, raw_output_path


def _run_llm_command(
    prompt: str,
    cfg: WVConfig,
    timeout: int,
    *,
    raw_output_path: Path | None = None,
) -> str:
    stdin_input = _resolve_llm_input(prompt, cfg)
    result = subprocess.run(
        _resolve_llm_command(prompt, cfg),
        capture_output=True,
        text=True,
        input=stdin_input,
        stdin=subprocess.DEVNULL if stdin_input is None else None,
        timeout=timeout,
        check=False,
    )
    if result.returncode != 0:
        error = (result.stderr or result.stdout).strip() or f"exit status {result.returncode}"
        if raw_output_path is not None:
            raw_output_path.write_text((result.stdout or "").strip(), encoding="utf-8")
            _emit_artifact_if_exists(raw_output_path.stem.split("_")[0], raw_output_path, raw_output_path.stem)
        raise RuntimeError(f"LLM command failed: {error}")
    final_text = result.stdout.strip()
    if raw_output_path is not None:
        raw_output_path.write_text(final_text, encoding="utf-8")
        _emit_artifact_if_exists(raw_output_path.stem.split("_")[0], raw_output_path, raw_output_path.stem)
    return final_text


def _report_llm_failure(
    *,
    stage_label: str,
    error: str,
    input_path: Path,
    prompt_path: Path,
    raw_output_path: Path,
) -> None:
    _reporter().human(f"[wv]   {stage_label}失败: {error}")
    _reporter().human(f"[wv]   输入: {input_path}")
    _reporter().human(f"[wv]   Prompt: {prompt_path}")
    _reporter().human(f"[wv]   原始输出: {raw_output_path}")


def _raise_llm_retry_decision(
    *,
    stage: str,
    stage_label: str,
    error: str,
    input_path: Path,
    prompt_path: Path,
    raw_output_path: Path,
) -> None:
    _report_llm_failure(
        stage_label=stage_label,
        error=error,
        input_path=input_path,
        prompt_path=prompt_path,
        raw_output_path=raw_output_path,
    )
    raise DecisionRequired(
        kind="llm_stage_retry_or_abort",
        reason_code="llm_stage_failed",
        message=f"{stage_label}失败：{error}",
        options=["retry", "abort"],
        default_option="retry",
        stage=stage,
        context={
            "input_path": str(input_path),
            "prompt_path": str(prompt_path),
            "raw_output_path": str(raw_output_path),
        },
    )


def _semantic_judgment(
    topic_blocks: list[dict], profile: ActivityProfile, cfg: WVConfig, work_dir: Path,
) -> list[dict]:
    """One LLM call to classify all topic blocks."""
    if not topic_blocks:
        return []

    blocks_for_llm = []
    for b in topic_blocks:
        entry = {
            "index": b["index"],
            "start": round(b["start"], 1),
            "end": round(b["end"], 1),
            "text": b["text"],
        }
        burst_info = _summarize_bursts_for_block(b, profile)
        if burst_info:
            entry["screen_activity"] = burst_info
        blocks_for_llm.append(entry)

    payload = {"topic_blocks": blocks_for_llm}
    llm_dir = _llm_artifact_dir(work_dir)
    prompt = _SEMANTIC_FILE_PROMPT_TMPL.format(
        input_path=(llm_dir / "semantic_input.json").resolve()
    )
    input_path, prompt_path, raw_output_path = _write_llm_stage_artifacts(
        stage="semantic",
        work_dir=work_dir,
        payload=payload,
        prompt=prompt,
    )

    try:
        raw = _run_llm_command(
            prompt,
            cfg,
            timeout=cfg.llm_timeout,
            raw_output_path=raw_output_path,
        )
        if not raw:
            _raise_llm_retry_decision(
                stage="semantic",
                stage_label="语义判断",
                error="LLM 返回空输出",
                input_path=input_path,
                prompt_path=prompt_path,
                raw_output_path=raw_output_path,
            )

        # Strip markdown fence if present
        m = re.search(r"```(?:json)?\s*(\[.+\])\s*```", raw, re.DOTALL)
        if m:
            raw = m.group(1)
        else:
            raw = _extract_json_block(raw, "[", "]")

        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            try:
                data = json.loads(_repair_json(raw))
            except json.JSONDecodeError as e:
                _raise_llm_retry_decision(
                    stage="semantic",
                    stage_label="语义判断",
                    error=str(e),
                    input_path=input_path,
                    prompt_path=prompt_path,
                    raw_output_path=raw_output_path,
                )
        if not isinstance(data, list):
            _raise_llm_retry_decision(
                stage="semantic",
                stage_label="语义判断",
                error="LLM 输出不是 JSON 数组",
                input_path=input_path,
                prompt_path=prompt_path,
                raw_output_path=raw_output_path,
            )

        # Index by block index for safe alignment
        result_map = {item["index"]: item for item in data if isinstance(item, dict)}
        return [result_map.get(b["index"], {}) for b in topic_blocks]

    except DecisionRequired:
        raise
    except Exception as e:
        _raise_llm_retry_decision(
            stage="semantic",
            stage_label="语义判断",
            error=str(e),
            input_path=input_path,
            prompt_path=prompt_path,
            raw_output_path=raw_output_path,
        )


def _fallback_classify(topic_blocks: list[dict], profile: ActivityProfile) -> list[dict]:
    """Fallback when semantic LLM fails: use activity bursts to infer operate windows."""
    burst_ranges = [(b.start, b.end) for b in profile.bursts]
    result = []
    for block in topic_blocks:
        has_burst = any(
            block["start"] < be and block["end"] > bs
            for bs, be in burst_ranges
        )
        result.append({
            "index": block["index"],
            "intent": "operate" if has_burst else "explain",
            "confidence": 0.5,
            "needs_visual_evidence": has_burst,
            "knowledge_topic": "",
            "operation_cue": "",
        })
    return result


# ---------------------------------------------------------------------------
# Window assembly from classified blocks
# ---------------------------------------------------------------------------

_INTENT_TO_WINDOW_TYPE = {
    "explain": WindowType.EXPLAIN,
    "operate": WindowType.OPERATE,
    "verify": WindowType.VERIFY,
    "transition": WindowType.EXPLAIN,  # treat transitions as explain (skip in rendering)
}


def _blocks_to_windows(
    all_segments: list[Segment],
    topic_blocks: list[dict],
    classifications: list[dict],
) -> list[Window]:
    windows: list[Window] = []
    for block, cls in zip(topic_blocks, classifications):
        intent = (cls.get("intent") or "explain").lower()
        wtype = _INTENT_TO_WINDOW_TYPE.get(intent, WindowType.EXPLAIN)

        # Skip pure transition blocks (very short, no real content)
        if intent == "transition" and (block["end"] - block["start"]) < 5.0:
            continue

        # knowledge_topics: accept both array (new) and single string (legacy)
        raw_kts = cls.get("knowledge_topics") or cls.get("knowledge_topic") or []
        if isinstance(raw_kts, str):
            raw_kts = [raw_kts] if raw_kts else []

        w = Window(
            start=block["start"],
            end=block["end"],
            type=wtype,
            transcript_segments=block["segments"],
            needs_visual_evidence=bool(cls.get("needs_visual_evidence")) and wtype in (WindowType.OPERATE, WindowType.EXPLAIN),
            intent=intent,
            knowledge_topic=raw_kts[0] if raw_kts else "",
            knowledge_points=raw_kts,
            operation_cue=cls.get("operation_cue") or "",
            content_focus=cls.get("content_focus") or "",
        )

        # Parse transcript_operations → Operation objects (operate + explain windows)
        if wtype in (WindowType.OPERATE, WindowType.EXPLAIN):
            raw_ops = cls.get("transcript_operations") or []
            for op in raw_ops:
                if not isinstance(op, dict) or not op.get("description"):
                    continue
                w.operations.append(Operation(
                    capability=op.get("capability") or "ui_action",
                    action=op.get("action") or "",
                    target=op.get("target") or "",
                    intent=op.get("intent") or "",
                    app_context=op.get("app_context") or "",
                    source="transcript",
                    text_content=op.get("text_content") or "",
                    visual_hint=op.get("visual_hint") or "",
                    description=op["description"],
                    type=op.get("capability") or "ui_action",
                    payload={"source": "transcript"},
                ))

        windows.append(w)
    return windows


# ---------------------------------------------------------------------------
# RepeatStep assembly (anchored on EXPLAIN)
# ---------------------------------------------------------------------------

def _assemble_steps(windows: list[Window]) -> list[RepeatStep]:
    steps: list[RepeatStep] = []
    i = 0
    while i < len(windows):
        w = windows[i]

        if w.type == WindowType.EXPLAIN:
            step = RepeatStep(
                index=len(steps),
                explain=w,
                time_range=(w.start, w.end),
            )
            i += 1

            # Consume following OPERATE
            if i < len(windows) and windows[i].type == WindowType.OPERATE:
                step.operate = windows[i]
                step.time_range = (step.explain.start, windows[i].end)
                i += 1

                # Consume following VERIFY
                if i < len(windows) and windows[i].type == WindowType.VERIFY:
                    step.verify = windows[i]
                    step.time_range = (step.explain.start, windows[i].end)
                    i += 1

            steps.append(step)

        elif w.type == WindowType.OPERATE:
            # Orphan OPERATE (no preceding explain) — synthesise explain from its transcript
            synthetic_explain = Window(
                start=w.start,
                end=w.end,
                type=WindowType.EXPLAIN,
                transcript_segments=w.transcript_segments,
                knowledge_topic=w.operation_cue,
            )
            step = RepeatStep(
                index=len(steps),
                explain=synthetic_explain,
                operate=w,
                time_range=(w.start, w.end),
            )
            i += 1

            # Consume following VERIFY
            if i < len(windows) and windows[i].type == WindowType.VERIFY:
                step.verify = windows[i]
                step.time_range = (step.explain.start, windows[i].end)
                i += 1

            steps.append(step)

        elif w.type == WindowType.VERIFY:
            # Orphan VERIFY (no preceding operate) — downgrade to explain
            w.type = WindowType.EXPLAIN
            step = RepeatStep(
                index=len(steps),
                explain=w,
                time_range=(w.start, w.end),
            )
            steps.append(step)
            i += 1

        else:
            i += 1

    return steps


# ---------------------------------------------------------------------------
# Frame extraction helpers
# ---------------------------------------------------------------------------

def _extract_window_frames(
    window: Window,
    media: MediaHandle,
    keyframes_dir: Path,
    video_duration: float,
) -> list[Frame]:
    """Extract keyframes for a window. Uses burst data if available, else uniform sampling."""
    if window.activity_burst:
        return _smart_frame_extraction(
            window.activity_burst, media, keyframes_dir, video_duration
        )
    else:
        return _uniform_frame_extraction(
            window.start, window.end, media, keyframes_dir, video_duration
        )


_PATTERN_MIN_DUR = {
    "TYPING": 3.0, "SCROLLING": 4.0, "VIEWPORT_MANIPULATION": 5.0,
    "TAB_SWITCH": 99.0, "CLICK_MENU": 99.0, "DRAG": 3.0, "UNKNOWN": 4.0,
}
_PATTERN_INTERVAL = {
    "TYPING": 2.0, "SCROLLING": 3.0, "VIEWPORT_MANIPULATION": 4.0,
    "DRAG": 2.0, "UNKNOWN": 3.0,
}


def _smart_frame_extraction(
    burst,
    media: MediaHandle,
    keyframes_dir: Path,
    video_duration: float,
) -> list[Frame]:
    pattern = burst.pattern.value
    timestamps: list[tuple[float, str]] = [
        (max(0.0, burst.start - 0.5), "pre_burst"),
        (burst.peak_time, "peak"),
        (min(video_duration, burst.end + 0.5), "post_burst"),
    ]
    min_dur = _PATTERN_MIN_DUR.get(pattern, 4.0)
    interval = _PATTERN_INTERVAL.get(pattern, 3.0)
    if burst.duration > min_dur:
        t = burst.start + interval
        while t < burst.end:
            timestamps.append((t, "intermediate"))
            t += interval

    frames: list[Frame] = []
    for ts, reason in timestamps:
        path = keyframes_dir / f"frame_{ts:.3f}_{reason}.png"
        if not path.exists():
            _extract_frame(media, ts, path)
        if path.exists():
            frames.append(Frame(index=len(frames), timestamp=ts, path=path, extraction_reason=reason))

    return _deduplicate_frames(frames)


def _uniform_frame_extraction(
    start: float,
    end: float,
    media: MediaHandle,
    keyframes_dir: Path,
    video_duration: float,
    target_frames: int = 3,
) -> list[Frame]:
    """Uniform sampling within [start, end] when no burst data is available."""
    duration = end - start
    if duration <= 0:
        return []
    n = min(target_frames, max(1, int(duration / 5)))
    step = duration / (n + 1)
    timestamps = [(start + step * (i + 1), "uniform") for i in range(n)]

    frames: list[Frame] = []
    for ts, reason in timestamps:
        ts = min(ts, video_duration - 0.1)
        path = keyframes_dir / f"frame_{ts:.3f}_{reason}.png"
        if not path.exists():
            _extract_frame(media, ts, path)
        if path.exists():
            frames.append(Frame(index=len(frames), timestamp=ts, path=path, extraction_reason=reason))

    return _deduplicate_frames(frames)


def _format_http_headers(headers: dict[str, str]) -> str:
    lines = []
    for name, value in headers.items():
        if not value or name.lower() == "user-agent":
            continue
        lines.append(f"{name}: {value}\r\n")
    return "".join(lines)


def _ffmpeg_input_args(media: MediaHandle) -> list[str]:
    if isinstance(media, LocalMediaHandle):
        return ["-i", str(media.path)]

    args: list[str] = []
    user_agent = media.headers.get("User-Agent") or media.headers.get("user-agent")
    if user_agent:
        args.extend(["-user_agent", user_agent])

    header_blob = _format_http_headers(media.headers)
    if header_blob:
        args.extend(["-headers", header_blob])

    args.extend(["-i", media.video_url])
    return args


def _ffprobe_input_args(media: MediaHandle) -> list[str]:
    if isinstance(media, LocalMediaHandle):
        return [str(media.path)]

    args: list[str] = []
    user_agent = media.headers.get("User-Agent") or media.headers.get("user-agent")
    if user_agent:
        args.extend(["-user_agent", user_agent])

    header_blob = _format_http_headers(media.headers)
    if header_blob:
        args.extend(["-headers", header_blob])

    args.append(media.video_url)
    return args


def _extract_frame(media: MediaHandle, timestamp: float, out_path: Path) -> None:
    command = [
        _find_binary("ffmpeg") or "ffmpeg",
        "-y",
        "-ss",
        str(timestamp),
        *_ffmpeg_input_args(media),
        "-frames:v",
        "1",
        "-q:v",
        "2",
        str(out_path),
    ]
    if isinstance(media, RemoteMediaHandle):
        try:
            subprocess.run(
                command,
                capture_output=True,
                timeout=30,
                check=True,
            )
        except subprocess.CalledProcessError as exc:
            raise RuntimeError(
                f"Remote frame extraction failed for {media.video_url}: {exc.stderr.decode(errors='ignore') if exc.stderr else exc}"
            ) from exc
        return

    subprocess.run(
        command,
        capture_output=True,
        timeout=30,
    )


def _deduplicate_frames(frames: list[Frame]) -> list[Frame]:
    try:
        import imagehash
        from PIL import Image
    except ImportError:
        return frames

    result: list[Frame] = []
    hashes = []
    for frame in frames:
        try:
            h = imagehash.phash(Image.open(frame.path))
            if all(abs(h - ph) > 5 for ph in hashes):
                result.append(frame)
                hashes.append(h)
        except Exception:
            result.append(frame)
    return result


def _probe_duration(media: MediaHandle) -> float:
    import json as _json
    if isinstance(media, RemoteMediaHandle) and media.duration:
        return media.duration

    command = [
        _find_binary("ffprobe") or "ffprobe",
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_format",
        *_ffprobe_input_args(media),
    ]
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=30)
        return float(_json.loads(result.stdout)["format"].get("duration", 0))
    except Exception:
        if isinstance(media, RemoteMediaHandle):
            raise RuntimeError(f"Failed to probe remote media duration: {media.video_url}")
        return 3600.0


# ---------------------------------------------------------------------------
# Vision analysis
# ---------------------------------------------------------------------------

def _analyze_window(
    window: Window,
    vision: VisionBackend,
    plugin: DomainPlugin,
) -> None:
    frames = window.keyframes
    if not frames:
        return

    context = " ".join(s.text for s in window.transcript_segments).strip()
    domain_prompt = plugin.frame_prompt()

    # Inject content significance hint when semantic stage identified content display
    if window.content_focus:
        domain_prompt += (
            f"\n\n🎯 内容重点提示：讲师正在展示关键内容。"
            f"请优先逐字读取并完整记录 {window.content_focus}。"
            f"不要只描述布局或 UI 结构，要抄录实际的文字内容。"
            f"content_snapshot 和 code_snapshot 都应包含尽可能完整的原文文本。"
        )

    try:
        from .impl.activity.mv import describe_hot_zones
        spatial_hint = describe_hot_zones(window.activity_burst.heatmap) if window.activity_burst and window.activity_burst.heatmap else ""
    except Exception:
        spatial_hint = ""
    pattern_hint = window.activity_burst.pattern.value if window.activity_burst else ""

    analyses: list[FrameAnalysis] = []
    for i, frame in enumerate(frames):
        prev = frames[i - 1] if i > 0 else None
        fa = vision.analyze_frame_pair(
            prev=prev,
            curr=frame,
            context=context,
            domain_prompt=domain_prompt,
            spatial_hint=spatial_hint,
            pattern_hint=pattern_hint,
        )
        analyses.append(fa)

    window.frame_analyses = analyses


# ---------------------------------------------------------------------------
# Guide generation (Stage 4)
# ---------------------------------------------------------------------------

_GUIDE_SYNTHESIS_PROMPT = """\
你是教程分析专家。根据以下教程视频的步骤序列，生成一份 "How to Repeat" 指南的摘要。

视频标题: {title}

步骤数据（JSON）：
{steps_json}

每个步骤的 explain_text 是讲师的原始旁白，这是最权威的信息来源。
operations 字段来自视觉分析（可能为空），作为补充。
explain_only 为 true 的步骤是正常步骤，不是缺失内容。

请返回 JSON：
{{
  "overview": "3-5 句话的整体概述",
  "prerequisites": ["前置条件1", "前置条件2"],
  "step_titles": ["步骤0的标题", "步骤1的标题", ...],
  "knowledge_points": [["步骤0知识点a", "步骤0知识点b"], ["步骤1知识点"], ...]
}}

标题要求：反映讲师在传达什么（理解层面），不只是"做了什么"。
只输出 JSON，不要其他内容。"""

_GUIDE_FILE_PROMPT_TMPL = """\
你是教程分析专家。
请读取本地文件 `{input_path}` 中的 JSON 数据，并生成一份 "How to Repeat" 指南摘要。

请返回 JSON：
{{
  "overview": "3-5 句话的整体概述",
  "prerequisites": ["前置条件1", "前置条件2"],
  "step_titles": ["步骤0的标题", "步骤1的标题", ...],
  "knowledge_points": [["步骤0知识点a", "步骤0知识点b"], ["步骤1知识点"], ...]
}}

要求：
- `explain_text` 是最权威的信息来源。
- `operations` 是视觉分析补充，可能为空。
- `explain_only=true` 依然是正常步骤。
- 标题要反映讲师传达的理解内容，不只是"做了什么"。

只输出 JSON，不要其他内容。"""

_GUIDE_INLINE_PROMPT_TMPL = """\
你是教程分析专家。请根据以下 JSON 数据，生成一份 "How to Repeat" 指南摘要。

数据：
{payload_json}

请返回 JSON：
{{
  "overview": "3-5 句话的整体概述",
  "prerequisites": ["前置条件1", "前置条件2"],
  "step_titles": ["步骤0的标题", "步骤1的标题", ...],
  "knowledge_points": [["步骤0知识点a", "步骤0知识点b"], ["步骤1知识点"], ...]
}}

要求：
- `explain_text` 是最权威的信息来源。
- `operations` 是视觉分析补充，可能为空。
- `explain_only=true` 依然是正常步骤。
- 标题要反映讲师传达的理解内容，不只是"做了什么"。

只输出 JSON，不要其他内容。"""


def _generate_guide(
    steps: list[RepeatStep],
    plugin: DomainPlugin,
    meta: SourceMeta,
    cfg: WVConfig,
    work_dir: Path,
) -> RepeatGuide:
    """Stage 4: LLM synthesis via configurable subprocess command."""
    step_summaries = []
    for step in steps:
        explain_text = " ".join(s.text for s in step.explain.transcript_segments).strip()
        operate_text = " ".join(
            s.text for s in (step.operate.transcript_segments if step.operate else [])
        ).strip()
        ops_data = []
        for op in step.operations[:8]:
            d: dict[str, str] = {"description": op.description}
            if op.text_content:
                d["text_content"] = op.text_content
            if op.capability:
                d["capability"] = op.capability
            if op.action:
                d["action"] = op.action
            ops_data.append(d)
        step_summaries.append({
            "index": step.index,
            "time": _fmt_time(step.time_range[0]),
            "explain_text": explain_text,
            "explain_only": step.operate is None,
            "operate_text": operate_text if operate_text else None,
            "operations": ops_data if ops_data else None,
        })

    payload = {
        "title": meta.title,
        "steps": step_summaries,
    }
    llm_dir = _llm_artifact_dir(work_dir)
    prompt = _GUIDE_FILE_PROMPT_TMPL.format(
        input_path=(llm_dir / "guide_input.json").resolve(),
    )
    input_path, prompt_path, raw_output_path = _write_llm_stage_artifacts(
        stage="guide",
        work_dir=work_dir,
        payload=payload,
        prompt=prompt,
    )

    synthesis: dict = {}
    try:
        raw = _run_llm_command(
            prompt,
            cfg,
            timeout=cfg.llm_timeout,
            raw_output_path=raw_output_path,
        )
        if raw:
            # Strip markdown fence if present
            m = re.search(r"```(?:json)?\s*(\{.+\})\s*```", raw, re.DOTALL)
            if m:
                raw = m.group(1)
            else:
                # Find the outermost { ... } by brace matching
                raw = _extract_json_block(raw, "{", "}")
            try:
                synthesis = json.loads(raw)
            except json.JSONDecodeError:
                synthesis = json.loads(_repair_json(raw))
            if not isinstance(synthesis, dict):
                raise ValueError("Guide synthesis did not return a JSON object.")
        else:
            _raise_llm_retry_decision(
                stage="guide",
                stage_label="Guide synthesis",
                error="LLM 返回空输出",
                input_path=input_path,
                prompt_path=prompt_path,
                raw_output_path=raw_output_path,
            )
    except DecisionRequired:
        raise
    except Exception as e:
        _raise_llm_retry_decision(
            stage="guide",
            stage_label="Guide synthesis",
            error=str(e),
            input_path=input_path,
            prompt_path=prompt_path,
            raw_output_path=raw_output_path,
        )

    titles = synthesis.get("step_titles") or []
    kp_list = synthesis.get("knowledge_points") or []
    knowledge_index: list[KnowledgeEntry] = []

    for i, step in enumerate(steps):
        step.title = titles[i] if i < len(titles) and titles[i] else f"Step {i + 1}"

        # Merge knowledge points: Stage 2 (block-level, with timestamps) is primary,
        # Stage 4 (synthesis) supplements with any new points
        stage2_kps = list(step.explain.knowledge_points)  # already set in _blocks_to_windows
        stage4_kps = kp_list[i] if i < len(kp_list) else []
        # Deduplicate: add stage4 points that aren't already covered
        existing_lower = {kp.lower() for kp in stage2_kps}
        for kp in stage4_kps:
            if kp.lower() not in existing_lower:
                stage2_kps.append(kp)
                existing_lower.add(kp.lower())
        step.explain.knowledge_points = stage2_kps

        # Build knowledge index with per-segment timestamps
        explain_segs = step.explain.transcript_segments
        for ki, kp in enumerate(stage2_kps):
            if explain_segs:
                seg_idx = min(ki * len(explain_segs) // max(len(stage2_kps), 1), len(explain_segs) - 1)
                ts = explain_segs[seg_idx].start
            else:
                ts = step.explain.start
            knowledge_index.append(KnowledgeEntry(
                timestamp=ts, topic=kp, step_index=i
            ))

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    plugin_name = getattr(plugin, "selected_name", None) or getattr(plugin, "name", "general")

    metadata = GuideMetadata(
        source=meta.input,
        title=meta.title or "Tutorial",
        duration=_fmt_duration(meta.duration),
        plugin=plugin_name,
        generated_at=now,
    )

    return RepeatGuide(
        metadata=metadata,
        overview=synthesis.get("overview") or "",
        prerequisites=synthesis.get("prerequisites") or [],
        steps=steps,
        knowledge_index=knowledge_index,
    )


def _render_semantic_json(guide: RepeatGuide) -> str:
    """Produce the machine-readable semantic.json — authority for wv act."""
    steps_out = []
    for step in guide.steps:
        ops_out = []
        for op in step.operations:
            d = {
                "capability": op.capability or "ui_action",
                "action": op.action,
                "target": op.target,
                "intent": op.intent,
                "app_context": op.app_context,
                "source": op.source,
                "description": op.description,
            }
            if op.text_content:
                d["text_content"] = op.text_content
            if op.visual_hint:
                d["visual_hint"] = op.visual_hint
            ops_out.append(d)

        expectations_out = []
        if step.verify:
            verify_text = " ".join(
                s.text for s in step.verify.transcript_segments if s.text.strip()
            ).strip()
            if step.expected_outcome or verify_text:
                expectations_out.append({
                    "kind": "visual",
                    "expected": step.expected_outcome or verify_text,
                    "context": step.title or f"Step {step.index + 1}",
                    "source": "transcript",
                })

        step_entry = {
            "index": step.index,
            "title": step.title,
            "time_range": list(step.time_range),
            "explain_text": " ".join(
                s.text for s in step.explain.transcript_segments
            ).strip()[:500],
            "operations": ops_out,
            "expectations": expectations_out,
        }
        if step.explain and step.explain.keyframes:
            step_entry["content_flash_frames"] = [
                {"timestamp": round(f.timestamp, 3), "path": f.path.name, "reason": f.extraction_reason}
                for f in step.explain.keyframes
            ]
        if step.explain and step.explain.frame_analyses:
            snapshots = [
                fa.content_snapshot for fa in step.explain.frame_analyses
                if fa.content_snapshot and fa.content_snapshot.strip()
            ]
            if snapshots:
                step_entry["content_snapshot"] = "\n---\n".join(snapshots)
        steps_out.append(step_entry)

    return json.dumps({
        "metadata": {
            "source": guide.metadata.source,
            "title": guide.metadata.title,
            "duration": guide.metadata.duration,
            "plugin": guide.metadata.plugin,
            "generated_at": guide.metadata.generated_at,
        },
        "steps": steps_out,
    }, ensure_ascii=False, indent=2)
