"""wv CLI — entry point."""

from __future__ import annotations

from contextlib import redirect_stdout
from dataclasses import replace
from pathlib import Path
import sys

import click

from .config import WVConfig, load_config
from .registry import (
    build_acquirer, build_activity_detector, build_cache,
    build_plugin, build_renderer, build_transcript_provider, build_vision_backend,
)
from .pipeline import Pipeline
from .runtime import AgentDecisionError, DecisionRequired, RunReporter, read_agent_decision, use_reporter


@click.group()
def main():
    """WithVideo — learn from tutorial videos and reproduce operations."""


def _stdout_is_tty() -> bool:
    return sys.stdout.isatty()


def _stdin_is_tty() -> bool:
    return sys.stdin.isatty()


def _should_emit_jsonl(cfg: WVConfig) -> bool:
    if cfg.event_stream == "jsonl":
        return True
    if cfg.event_stream == "off":
        return False
    return not _stdout_is_tty()


def _can_prompt_for_decision() -> bool:
    return _stdin_is_tty() and _stdout_is_tty()


def _build_reporter(cfg: WVConfig) -> RunReporter:
    return RunReporter(emit_jsonl=_should_emit_jsonl(cfg))


def _build_pipeline(cfg: WVConfig, reporter: RunReporter | None = None) -> Pipeline:
    acquirer = build_acquirer(cfg)
    transcript_prov = build_transcript_provider(cfg)
    detector = build_activity_detector(cfg)
    vision_be = build_vision_backend(cfg)
    plugin_inst = build_plugin(cfg)
    renderer = build_renderer(cfg)

    work_base = cfg.output or Path(".withvideo")
    cache_inst = build_cache(cfg, work_base)

    return Pipeline(
        acquirer=acquirer,
        transcript_provider=transcript_prov,
        activity_detector=detector,
        vision=vision_be,
        plugin=plugin_inst,
        cache=cache_inst,
        renderer=renderer,
        cfg=cfg,
        reporter=reporter,
    )


def _run_learn_once(input_str: str, cfg: WVConfig, reporter: RunReporter | None = None) -> Path:
    reporter = reporter or _build_reporter(cfg)
    with use_reporter(reporter), redirect_stdout(sys.stderr):
        return _build_pipeline(cfg, reporter).run(input_str)


def _apply_decision(cfg: WVConfig, decision: DecisionRequired, selected: str) -> WVConfig:
    if decision.kind == "remote_to_download" and selected == "download":
        return replace(cfg, media_access="download")
    if decision.kind == "platform_subtitles_to_whisper" and selected in {"mlx-whisper", "faster-whisper"}:
        return replace(cfg, transcript=selected)
    if decision.kind == "llm_stage_retry_or_abort" and selected == "retry":
        return cfg
    return cfg


def _prompt_for_decision(decision: DecisionRequired) -> str:
    default_yes = decision.default_option != "abort"
    if decision.kind == "remote_to_download":
        confirmed = click.confirm(
            "[wv] 是否改用下载到本地后继续处理？",
            default=default_yes,
            err=True,
        )
        return "download" if confirmed else "abort"
    if decision.kind == "platform_subtitles_to_whisper":
        confirmed = click.confirm(
            "[wv] 是否改用 Whisper 在本地媒体上继续转录？",
            default=default_yes,
            err=True,
        )
        return decision.default_option if confirmed else "abort"
    if decision.kind == "llm_stage_retry_or_abort":
        confirmed = click.confirm(
            "[wv] LLM 阶段失败，是否重试？",
            default=default_yes,
            err=True,
        )
        return "retry" if confirmed else "abort"
    raise RuntimeError(f"Unsupported CLI decision kind: {decision.kind}")


def _format_exception_message(exc: Exception) -> str:
    message = str(exc).strip()
    if message:
        return message
    return exc.__class__.__name__


def _resolve_decision(
    *,
    cfg: WVConfig,
    reporter: RunReporter,
    decision: DecisionRequired,
) -> str:
    reporter.decision_required(decision)

    if cfg.decision_mode == "defaults":
        selected = decision.default_option
        reporter.human(f"[wv] 自动选择默认值: {decision.kind} → {selected}")
        reporter.decision_selected(decision, selected)
        if selected == "abort":
            reporter.run_failed(
                "Run aborted (default_option was abort)",
                stage=decision.stage,
                context={
                    "error_code": "decision_aborted",
                    "recoverable": False,
                    "kind": decision.kind,
                    "selected": selected,
                    **decision.context,
                },
            )
            raise click.exceptions.Exit(3)
        return selected

    if cfg.decision_mode == "agent":
        try:
            selected = read_agent_decision(decision)
        except AgentDecisionError as exc:
            reporter.run_failed(
                exc.message,
                stage=decision.stage,
                context={
                    "error_code": exc.error_code,
                    "recoverable": True,
                    "kind": decision.kind,
                    "options": decision.options,
                    **decision.context,
                },
            )
            raise click.exceptions.Exit(2) from exc
        reporter.decision_selected(decision, selected)
        if selected == "abort":
            reporter.run_failed(
                "Run aborted by agent decision",
                stage=decision.stage,
                context={
                    "error_code": "decision_aborted",
                    "recoverable": False,
                    "kind": decision.kind,
                    "selected": selected,
                    **decision.context,
                },
            )
            raise click.exceptions.Exit(3)
        return selected

    if cfg.decision_mode == "fail":
        reporter.run_failed(
            decision.message,
            stage=decision.stage,
            context={
                "error_code": "decision_mode_fail",
                "recoverable": True,
                "suggestion": "Re-run with --decision-mode agent or --decision-mode prompt",
                "kind": decision.kind,
                "reason_code": decision.reason_code,
                "options": decision.options,
                "default_option": decision.default_option,
                **decision.context,
            },
        )
        raise click.exceptions.Exit(1)

    can_prompt = _can_prompt_for_decision()
    if not can_prompt:
        reporter.human(
            "[wv] 当前不是交互终端，无法执行需要确认的决策。"
            " 建议使用 --decision-mode defaults 自动选择默认值。"
        )
        reporter.run_failed(
            decision.message,
            stage=decision.stage,
            context={
                "error_code": "decision_mode_no_tty",
                "recoverable": True,
                "suggestion": "Re-run with --decision-mode defaults to auto-accept, or --decision-mode agent for bidirectional protocol",
                "kind": decision.kind,
                "reason_code": decision.reason_code,
                "options": decision.options,
                "default_option": decision.default_option,
                **decision.context,
            },
        )
        raise click.exceptions.Exit(1)

    reporter.human(f"[wv] 需要决策: {decision.message}")
    selected = _prompt_for_decision(decision)
    reporter.decision_selected(decision, selected)
    if selected == "abort":
        reporter.run_failed(
            "Run aborted by user decision",
            stage=decision.stage,
            context={
                "error_code": "decision_aborted",
                "recoverable": False,
                "kind": decision.kind,
                "selected": selected,
                **decision.context,
            },
        )
        raise click.exceptions.Exit(3)
    return selected


@main.command()
@click.argument("input")
@click.option("-o", "--output", type=click.Path(), default=None, help="Output directory (default: .withvideo/)")
@click.option("-p", "--plugin", default="auto", type=click.Choice(["auto","code","blender","figma","general"]), show_default=True)
@click.option("--vision", default="cli", show_default=True, help="Vision backend: cli | claude | ollama:<model> | none")
@click.option("--transcript", default="auto", type=click.Choice(["auto","mlx-whisper","faster-whisper","platform-subs"]), show_default=True)
@click.option("--activity", default="auto", type=click.Choice(["auto","mv","ssim"]), show_default=True)
@click.option("--cache", default="joblib", type=click.Choice(["joblib","json","none"]), show_default=True)
@click.option("--media-access", default="download", type=click.Choice(["download", "remote"]), show_default=True)
@click.option("--event-stream", default="auto", type=click.Choice(["off", "auto", "jsonl"]), show_default=True)
@click.option("--decision-mode", default="auto", type=click.Choice(["auto", "prompt", "fail", "agent", "defaults"]), show_default=True)
@click.option("--whisper-model", default=None, help="Whisper model path or HF repo")
@click.option("--llm-command", default=None, help="Command template for semantic/guide LLM calls. Use {prompt} to place the prompt explicitly.")
@click.option("--llm-timeout", default=None, type=int, help="Timeout in seconds for semantic/guide LLM calls.")
@click.option("--max-frames", default=200, show_default=True, help="Max frames to analyse (controls API cost)")
@click.option("--cookies", default=None, type=click.Path(), help="Netscape cookies file")
@click.option(
    "--cookies-from-browser",
    default=None,
    help="Extract cookies from browser, optionally with profile: chrome | chrome:Default | firefox:Profile 1",
)
@click.option("--skip", multiple=True, type=click.Choice(["transcript", "semantic", "vision", "guide"]),
              help="Skip a pipeline stage (can be repeated)")
@click.option("--force", is_flag=True, default=False, help="Re-run all stages (ignore cache)")
@click.option("-v", "--verbose", is_flag=True, default=False)
def learn(
    input, output, plugin, vision, transcript, activity, cache, media_access, event_stream, decision_mode,
    whisper_model, llm_command, llm_timeout, max_frames, cookies, cookies_from_browser, skip, force, verbose,
):
    """Analyse a tutorial video and produce a Repeat Guide.

    INPUT can be a URL (YouTube, Bilibili, ...) or a local video file path.
    """
    overrides = {
        "plugin": plugin,
        "vision": vision,
        "transcript": transcript,
        "activity": activity,
        "cache": "none" if force else cache,
        "media_access": media_access,
        "event_stream": event_stream,
        "decision_mode": decision_mode,
        "max_frames": max_frames,
        "cookies": cookies,
        "cookies_from_browser": cookies_from_browser,
        "llm_command": llm_command,
        "llm_timeout": llm_timeout,
        "skip": list(skip),
        "force": force,
        "verbose": verbose,
    }
    if whisper_model:
        overrides["whisper_model"] = whisper_model
    if output:
        overrides["output"] = Path(output)

    cfg = load_config(overrides=overrides)
    reporter = _build_reporter(cfg)
    reporter.run_started(
        input_value=input,
        context={
            "media_access": cfg.media_access,
            "transcript": cfg.transcript,
            "vision": cfg.vision,
        },
    )
    reporter.pipeline_started()
    current_cfg = cfg
    while True:
        try:
            out_path = _run_learn_once(input, current_cfg, reporter)
            semantic_path = out_path.parent / "semantic.json"
            reporter.run_completed(
                output_path=str(out_path),
                context={
                    "artifacts": {
                        "guide_md": str(out_path),
                        "semantic_json": str(semantic_path) if semantic_path.exists() else None,
                    },
                },
            )
            return
        except DecisionRequired as decision:
            selected = _resolve_decision(cfg=current_cfg, reporter=reporter, decision=decision)
            current_cfg = _apply_decision(current_cfg, decision, selected)
            continue
        except click.exceptions.Exit:
            raise
        except Exception as exc:
            reporter.run_failed(
                _format_exception_message(exc),
                context={"error_code": "unexpected", "recoverable": False},
            )
            raise


@main.command()
def schema():
    """Output JSON schema describing wv's events, decisions, and options."""
    import json as _json
    from .schema import get_schema
    click.echo(_json.dumps(get_schema(), indent=2, ensure_ascii=False))


@main.command()
@click.argument("source")
@click.option("--cookies", default=None, type=click.Path(), help="Netscape cookies file")
@click.option(
    "--cookies-from-browser",
    default=None,
    help="Extract cookies from browser profile: chrome | chrome:Default | firefox:Profile 1",
)
def preflight(source, cookies, cookies_from_browser):
    """Probe environment and video source without running the pipeline.

    SOURCE can be a URL (YouTube, Bilibili, ...) or a local video file path.
    Outputs a JSON report with environment status, source info, and recommended flags.
    """
    import json as _json
    from .config import load_config
    from .preflight import run_preflight
    cfg = load_config(overrides={
        "cookies": cookies,
        "cookies_from_browser": cookies_from_browser,
    })
    result = run_preflight(source, cfg)
    click.echo(_json.dumps(result, indent=2, ensure_ascii=False))


@main.command()
@click.argument("guide_path", type=click.Path(exists=True))
@click.option("--step", default=None, help="Steps to execute (e.g. '3', '1-5', '1,3,5')")
@click.option("--dry-run", is_flag=True, default=False, help="Preview operations without executing")
@click.option("--confirm/--no-confirm", default=True, help="Confirm each operation before executing")
@click.option("--executor", type=click.Choice(["auto", "direct-only", "browser", "computer-use"]),
              default="auto", help="Executor backend selection")
@click.option("--allow-dangerous", is_flag=True, default=False,
              help="Allow shell commands matching dangerous patterns (rm -rf, sudo, curl|sh, ...)")
def act(guide_path, step, dry_run, confirm, executor, allow_dangerous):
    """Execute operations from a Repeat Guide or semantic.json."""
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from act_with_video.cli import _cmd_run
    _cmd_run(
        Path(guide_path),
        step=step,
        dry_run=dry_run,
        confirm=confirm,
        executor=executor,
        allow_dangerous=allow_dangerous,
    )


if __name__ == "__main__":
    main()
