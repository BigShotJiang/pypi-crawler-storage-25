"""wv MCP Server — exposes wv tools to any MCP-compatible agent.

Tools:
  wv_schema()           → wv self-describing API
  wv_preflight(source)  → environment + source probe, returns recommendations
  wv_status(work_dir)   → check the state of a prior learn run
  wv_learn(source, ...) → run full pipeline, returns results + event log
  wv_act(semantic, ...) → execute Tier 0/1 operations from a semantic.json

Usage:
  python -m withvideo.mcp_server

Or via .mcp.json:
  {
    "mcpServers": {
      "withvideo": {
        "command": "python",
        "args": ["-m", "withvideo.mcp_server"],
        "env": {"PATH": "/opt/homebrew/bin:${PATH}"}
      }
    }
  }
"""

from __future__ import annotations

import asyncio
import json
import subprocess
import sys
from typing import Any

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    raise ImportError(
        "mcp package not installed. Install with: pip install 'withvideo[mcp]'"
    )


mcp = FastMCP("withvideo")


# ---------------------------------------------------------------------------
# Tool: wv_schema
# ---------------------------------------------------------------------------

@mcp.tool()
def wv_schema() -> dict[str, Any]:
    """Return the self-describing JSON schema of wv's capabilities.

    Call this first to discover events, decisions, options, and exit codes.
    """
    from .schema import get_schema
    return get_schema()


# ---------------------------------------------------------------------------
# Tool: wv_preflight
# ---------------------------------------------------------------------------

@mcp.tool()
def wv_preflight(
    source: str,
    cookies_from_browser: str | None = None,
) -> dict[str, Any]:
    """Probe environment and video source without running the pipeline.

    Returns environment status, source metadata, recommended wv learn flags,
    and a ready-to-run command string. Fast (seconds, not minutes).

    Args:
        source: Video URL (YouTube, Bilibili, ...) or local file path.
        cookies_from_browser: Browser to extract cookies from, e.g. "chrome" or
            "chrome:Default". Required for Bilibili 1080p+.
    """
    from .config import load_config
    from .preflight import run_preflight
    cfg = load_config(overrides={
        "cookies_from_browser": cookies_from_browser,
    })
    return run_preflight(source, cfg)


# ---------------------------------------------------------------------------
# Tool: wv_status
# ---------------------------------------------------------------------------

@mcp.tool()
def wv_status(work_dir: str) -> dict[str, Any]:
    """Check the real-time progress of a running wv learn pipeline.

    Poll this every few seconds after launching wv_learn to get live progress.
    Returns progress percentage, current stage, ETA, and per-stage status.

    Args:
        work_dir: Path to the .withvideo/{video_name}/ directory.
                  If unknown, pass ".withvideo" to scan for the most recent run.
    """
    from pathlib import Path as _Path

    p = _Path(work_dir)
    if p.name == ".withvideo" and p.is_dir():
        candidates = sorted(
            p.glob("*/.wv_progress.json"),
            key=lambda f: f.stat().st_mtime,
            reverse=True,
        )
        if not candidates:
            return {"status": "no_active_run"}
        progress_path = candidates[0]
    else:
        progress_path = p / ".wv_progress.json"

    if not progress_path.exists():
        return {"status": "no_progress_file", "path": str(progress_path)}

    try:
        return json.loads(progress_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return {"status": "read_error", "error": str(exc)}


# ---------------------------------------------------------------------------
# Tool: wv_learn
# ---------------------------------------------------------------------------

@mcp.tool()
def wv_learn(
    source: str,
    media_access: str = "download",
    vision: str = "cli",
    transcript: str = "auto",
    plugin: str = "auto",
    max_frames: int = 200,
    cookies_from_browser: str | None = None,
    skip: list[str] | None = None,
    force: bool = False,
    llm_command: str | None = None,
    llm_timeout: int | None = None,
) -> dict[str, Any]:
    """Run the full wv learn pipeline on a tutorial video.

    Returns structured results including output paths, stats, auto-resolved
    decisions, and a condensed event log.

    Args:
        source: Video URL (YouTube, Bilibili, ...) or local file path.
        media_access: "download" (default) or "remote" (Bilibili only, no download).
        vision: Vision backend — "cli" (default), "claude", "ollama:<model>", or "none".
        transcript: Transcript strategy — "auto" (default), "mlx-whisper", "platform-subs".
        plugin: Domain plugin — "auto" (default), "code", "blender", "figma", "general".
        max_frames: Max frames to analyze (controls API cost). Default 200.
        cookies_from_browser: Extract cookies from browser, e.g. "chrome".
        skip: Stages to skip — any of ["transcript", "semantic", "vision", "guide"].
        force: Re-run all stages (ignore cache). Default False.
        llm_command: Override LLM command template. Use {prompt} placeholder.
        llm_timeout: LLM call timeout in seconds.
    """
    cmd = _build_learn_cmd(
        source=source,
        media_access=media_access,
        vision=vision,
        transcript=transcript,
        plugin=plugin,
        max_frames=max_frames,
        cookies_from_browser=cookies_from_browser,
        skip=skip or [],
        force=force,
        llm_command=llm_command,
        llm_timeout=llm_timeout,
    )
    return _run_pipeline(cmd)


# ---------------------------------------------------------------------------
# Tool: wv_act
# ---------------------------------------------------------------------------

@mcp.tool()
def wv_act(
    semantic_path: str,
    dry_run: bool = False,
    no_confirm: bool = False,
    step: str | None = None,
    allow_dangerous: bool = False,
) -> dict[str, Any]:
    """Execute a semantic.json via wv act — real Tier 0/1 executors.

    Tier 0 (Shell / FileWrite / URLOpen) and Tier 1 (ClaudeCode) are supported.
    Tier 2/3 (Browser / ComputerUse) are roadmap.

    Args:
        semantic_path: Path to a semantic.json produced by wv learn.
        dry_run: Preview routing decisions without executing. Default False.
        no_confirm: Skip per-step interactive confirmation. Default False.
        step: Step filter like "3" or "2-5". None = run all.
        allow_dangerous: Permit dangerous shell patterns (rm -rf / sudo / ...).
            Default False — unsafe commands are refused.
    """
    cmd = [sys.executable, "-m", "withvideo.cli", "act", semantic_path]
    if dry_run:
        cmd.append("--dry-run")
    if no_confirm:
        cmd.append("--no-confirm")
    if step:
        cmd += ["--step", step]
    if allow_dangerous:
        cmd.append("--allow-dangerous")

    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, encoding="utf-8", timeout=3600,
        )
    except subprocess.TimeoutExpired:
        return {"success": False, "exit_code": -1, "stdout": "", "stderr": "timeout after 3600s"}
    except Exception as exc:
        return {"success": False, "exit_code": -1, "stdout": "", "stderr": f"spawn failed: {exc}"}

    return {
        "success": proc.returncode == 0,
        "exit_code": proc.returncode,
        "stdout": proc.stdout[-4000:],
        "stderr": proc.stderr[-4000:],
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_learn_cmd(
    source: str,
    media_access: str,
    vision: str,
    transcript: str,
    plugin: str,
    max_frames: int,
    cookies_from_browser: str | None,
    skip: list[str],
    force: bool,
    llm_command: str | None,
    llm_timeout: int | None,
) -> list[str]:
    cmd = [
        sys.executable, "-m", "withvideo.cli", "learn",
        source,
        "--decision-mode", "defaults",
        "--event-stream", "jsonl",
        "--media-access", media_access,
        "--vision", vision,
        "--transcript", transcript,
        "--plugin", plugin,
        "--max-frames", str(max_frames),
    ]
    if cookies_from_browser:
        cmd += ["--cookies-from-browser", cookies_from_browser]
    for stage in skip:
        cmd += ["--skip", stage]
    if force:
        cmd += ["--force"]
    if llm_command:
        cmd += ["--llm-command", llm_command]
    if llm_timeout is not None:
        cmd += ["--llm-timeout", str(llm_timeout)]
    return cmd


def _run_pipeline(cmd: list[str]) -> dict[str, Any]:
    """Spawn wv learn, collect JSONL events, return structured result."""
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
        )
    except Exception as exc:
        return {
            "success": False,
            "exit_code": -1,
            "output_path": None,
            "artifacts": {},
            "stats": {},
            "decisions_made": [],
            "event_log": [],
            "error": {"error_code": "spawn_failed", "message": str(exc), "recoverable": False, "suggestion": None},
        }

    events: list[dict] = []
    stdout_lines: list[str] = []

    # Read stdout synchronously (events are line-buffered JSONL)
    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip("\n")
        if not line:
            continue
        stdout_lines.append(line)
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass

    proc.wait()
    return _assemble_result(proc.returncode, events)


def _assemble_result(returncode: int, events: list[dict]) -> dict[str, Any]:
    success = returncode == 0
    output_path: str | None = None
    artifacts: dict = {}
    stats: dict = {}
    error: dict | None = None
    decisions_made: list[dict] = []

    # Condensed event log: stage completions, decisions, artifacts, run end
    key_types = {"stage_completed", "decision_selected", "artifact_written",
                 "run_completed", "run_failed", "plugin_selected"}
    event_log: list[dict] = []

    for ev in events:
        t = ev.get("type", "")
        ctx = ev.get("context") or {}

        if t in key_types:
            event_log.append({
                "type": t,
                "stage": ev.get("stage"),
                "message": ev.get("message", ""),
                "elapsed_s": ctx.get("elapsed_s"),
            })

        if t == "run_completed":
            output_path = ctx.get("output_path")
            artifacts = ctx.get("artifacts") or {}
            stats = {
                k: ctx.get(k)
                for k in ("stats.steps", "stats.operations",
                           "stats.knowledge_points", "stats.frames_analyzed")
                if ctx.get(k) is not None
            }
            # Also check nested stats key
            if ctx.get("stats"):
                stats = ctx["stats"]

        elif t == "run_failed":
            error = {
                "error_code": ctx.get("error_code", "unknown"),
                "message": ev.get("message", ""),
                "recoverable": ctx.get("recoverable", False),
                "suggestion": ctx.get("suggestion"),
            }

        elif t == "decision_selected":
            decisions_made.append({
                "kind": ctx.get("kind"),
                "selected": ctx.get("selected"),
                "stage": ev.get("stage"),
            })

    return {
        "success": success,
        "exit_code": returncode,
        "output_path": output_path,
        "artifacts": artifacts,
        "stats": stats,
        "decisions_made": decisions_made,
        "event_log": event_log,
        "error": error,
    }


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()
