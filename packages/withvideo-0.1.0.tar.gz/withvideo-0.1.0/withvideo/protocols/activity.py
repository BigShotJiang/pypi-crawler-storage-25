from __future__ import annotations
from pathlib import Path
from typing import Protocol, runtime_checkable
from ..models import ActivityProfile


@runtime_checkable
class ActivityDetector(Protocol):
    """Detects when screen activity (operations) happen in a video."""

    def detect(self, video_path: Path) -> ActivityProfile:
        """Analyse the video and return an activity profile with burst segments."""
        ...

    def can_handle(self, video_path: Path) -> bool:
        """Return True if this detector is suitable for the video (e.g. has motion vectors)."""
        ...
