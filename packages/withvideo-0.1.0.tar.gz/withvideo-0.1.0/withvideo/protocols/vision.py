from __future__ import annotations
from pathlib import Path
from typing import Protocol, runtime_checkable
from ..models import Frame, FrameAnalysis


@runtime_checkable
class VisionBackend(Protocol):
    """Analyses a pair of frames and extracts operations."""

    def analyze_frame_pair(
        self,
        prev: Frame | None,
        curr: Frame,
        context: str,
        domain_prompt: str,
        spatial_hint: str = "",
        pattern_hint: str = "",
    ) -> FrameAnalysis:
        """
        Args:
            prev: previous frame (None for the first frame in a burst)
            curr: current frame to analyse
            context: transcript text around this time window
            domain_prompt: plugin-specific instructions
            spatial_hint: human-readable description of active screen regions (from MV heatmap)
            pattern_hint: detected burst pattern (e.g. "TYPING", "TAB_SWITCH")
        """
        ...
