from __future__ import annotations
from typing import Protocol, runtime_checkable
from ..models import Frame, FrameAnalysis, Operation


@runtime_checkable
class DomainPlugin(Protocol):
    """Domain-specific logic: detection, prompting, and operation extraction."""

    name: str
    description: str

    def detect(self, frames: list[Frame]) -> float:
        """Return confidence score 0–1 that this plugin matches the video domain."""
        ...

    def frame_prompt(self) -> str:
        """Return domain-specific instructions to inject into the vision prompt."""
        ...

    def extract_operations(self, analysis: FrameAnalysis) -> list[Operation]:
        """Parse structured operations from a frame analysis result."""
        ...

    def format_for_report(self, ops: list[Operation]) -> str:
        """Human-readable operation descriptions for the report."""
        ...
