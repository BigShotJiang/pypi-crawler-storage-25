from __future__ import annotations
from typing import Any, Callable, Protocol, TypeVar, runtime_checkable

F = TypeVar("F", bound=Callable)


@runtime_checkable
class StageCache(Protocol):
    """Transparent function-result cache for pipeline stages."""

    def cached(self, fn: F) -> F:
        """
        Return a cached version of fn.
        Cache key is derived from fn's name + arguments.
        If the result is already cached and inputs haven't changed, return cached value.
        """
        ...

    def invalidate(self) -> None:
        """Clear all cached results (equivalent to --force)."""
        ...
