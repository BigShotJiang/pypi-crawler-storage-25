from __future__ import annotations
from pathlib import Path
from typing import Protocol, runtime_checkable
from ..models import MediaHandle, SourceMeta


@runtime_checkable
class SourceAcquirer(Protocol):
    """Resolves an input (URL or file path) into a media handle + metadata."""

    def acquire(
        self,
        input_str: str,
        work_dir: Path,
        opts: dict,
    ) -> tuple[MediaHandle, str, SourceMeta]:
        """
        Returns:
            media: local path or remote media descriptor
            video_name: sanitised name used as working directory stem
            meta: normalised platform metadata
        """
        ...
