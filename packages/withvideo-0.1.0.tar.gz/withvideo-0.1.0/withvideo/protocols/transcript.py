from __future__ import annotations
from pathlib import Path
from typing import Protocol, runtime_checkable
from ..models import SourceMeta, Transcript


@runtime_checkable
class TranscriptProvider(Protocol):
    """Produces a unified Transcript from a video (audio extraction, Whisper, or platform subs)."""

    def transcribe(
        self,
        video_path: Path | None,
        meta: SourceMeta,
        work_dir: Path,
    ) -> Transcript:
        ...

    def can_handle(self, meta: SourceMeta) -> bool:
        """Return True if this provider can handle the given source."""
        ...
