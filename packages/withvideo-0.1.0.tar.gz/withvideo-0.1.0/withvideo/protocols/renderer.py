from __future__ import annotations
from typing import Protocol, runtime_checkable
from ..models import RepeatGuide


@runtime_checkable
class ReportRenderer(Protocol):
    """Renders a RepeatGuide into a specific output format."""

    def render(self, guide: RepeatGuide) -> str:
        """Return the rendered content as a string."""
        ...

    def extension(self) -> str:
        """File extension for the output (e.g. '.md', '.json')."""
        ...
