"""wv schema — self-describing JSON output for agent consumption."""

from __future__ import annotations


_COMMON_FIELDS = ["type", "timestamp", "run_id", "stage", "message", "context"]
_TASK_FIELDS = _COMMON_FIELDS + ["task_id", "parent_task_id", "depth"]


def get_schema() -> dict:
    return {
        "version": "0.1.0",
        "description": (
            "wv (WithVideo) analyses tutorial videos and produces Repeat Guides. "
            "Run `wv learn <video>` to produce a guide, `wv act <guide>` to execute it."
        ),
        "commands": {
            "learn": {
                "description": "Analyse a tutorial video and produce a Repeat Guide",
                "args": {"INPUT": "Video URL or local file path"},
                "key_options": {
                    "--plugin":        "auto | code | blender | figma | general",
                    "--vision":        "cli | claude | ollama:<model> | none",
                    "--transcript":    "auto | mlx-whisper | platform-subs",
                    "--media-access":  "download | remote",
                    "--event-stream":  "off | auto | jsonl",
                    "--decision-mode": "auto | prompt | fail | agent | defaults",
                    "--max-frames":    "int (default 200)",
                    "--skip":          "transcript | semantic | vision | guide (repeatable)",
                    "--force":         "re-run all stages",
                    "--llm-command":   "LLM command template, use {prompt} placeholder",
                    "--llm-timeout":   "LLM timeout in seconds",
                },
            },
            "act": {
                "description": "Execute operations from a Repeat Guide or semantic.json",
                "args": {"SEMANTIC_PATH": "semantic.json or guide.md path"},
                "key_options": {
                    "--step":    "Execute only step N (0-indexed)",
                    "--dry-run": "Preview operations without executing",
                    "--confirm": "Confirm each operation (default true)",
                },
            },
            "schema": {
                "description": "Output this JSON schema",
            },
            "preflight": {
                "description": "Probe environment and video source without running the pipeline",
                "args": {"SOURCE": "Video URL or local file path"},
                "key_options": {
                    "--cookies":              "Netscape cookies file path",
                    "--cookies-from-browser": "Extract from browser: chrome | chrome:Default",
                },
            },
        },
        "events": {
            "run_started": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["input", "media_access", "transcript", "vision"],
                "description": "Emitted at the very start of wv learn",
            },
            "stage_started": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["input"],
                "description": "A pipeline stage has begun",
            },
            "stage_completed": {
                "fields": _COMMON_FIELDS,
                "context_fields": [],
                "description": "A pipeline stage has completed (also fires task_completed)",
            },
            "task_started": {
                "fields": _TASK_FIELDS,
                "context_fields": ["total"],
                "description": "A named sub-task has started; depth=0 means stage-level",
            },
            "task_progress": {
                "fields": _TASK_FIELDS,
                "context_fields": ["current", "total"],
                "description": "Progress update for a running task",
            },
            "task_completed": {
                "fields": _TASK_FIELDS,
                "context_fields": ["elapsed_s"],
                "description": "A task completed successfully",
            },
            "task_failed": {
                "fields": _TASK_FIELDS,
                "context_fields": ["elapsed_s"],
                "description": "A task failed (may not be fatal to the pipeline)",
            },
            "plugin_selected": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["plugin", "method"],
                "description": "Domain plugin was selected; method is 'transcript' or 'vision'",
            },
            "artifact_written": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["path", "artifact_type"],
                "description": "An output file was written",
            },
            "decision_required": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["kind", "reason_code", "options", "default_option"],
                "description": (
                    "Pipeline needs a decision. In agent mode, write a JSON response "
                    "to stdin: {\"kind\": \"<kind>\", \"selected\": \"<option>\"}"
                ),
            },
            "decision_selected": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["kind", "selected"],
                "description": "A decision was made; pipeline will continue",
            },
            "run_completed": {
                "fields": _COMMON_FIELDS,
                "context_fields": [
                    "output_path",
                    "artifacts.guide_md",
                    "artifacts.semantic_json",
                    "stats.steps",
                    "stats.operations",
                    "stats.knowledge_points",
                    "stats.frames_analyzed",
                ],
                "description": "Pipeline completed successfully",
            },
            "run_failed": {
                "fields": _COMMON_FIELDS,
                "context_fields": ["error_code", "recoverable", "suggestion"],
                "description": "Pipeline failed",
            },
        },
        "decisions": {
            "remote_to_download": {
                "stage": "transcript",
                "options": ["download", "abort"],
                "default": "download",
                "description": "Remote mode with no platform subtitles available; switch to download?",
            },
            "platform_subtitles_to_whisper": {
                "stage": "transcript",
                "options": ["mlx-whisper", "abort"],
                "default": "mlx-whisper",
                "description": "Platform subtitles unavailable or unreliable; switch to Whisper?",
            },
            "llm_stage_retry_or_abort": {
                "stage": "semantic | guide",
                "options": ["retry", "abort"],
                "default": "retry",
                "description": "LLM call failed or returned invalid output; retry?",
            },
        },
        "agent_decision_protocol": {
            "description": (
                "When --decision-mode agent is active, wv emits a decision_required event "
                "on stdout, then blocks reading one JSON line from stdin. "
                "Write exactly one JSON object followed by a newline."
            ),
            "stdin_format": {"kind": "<must match decision_required.context.kind>",
                             "selected": "<must be in decision_required.context.options>"},
            "error_codes": {
                "agent_stdin_timeout":          "No response within 30s",
                "agent_stdin_invalid_json":     "Response is not valid JSON",
                "agent_decision_kind_mismatch": "Response kind does not match pending decision",
                "agent_decision_invalid_option":"Response selected is not in options",
            },
        },
        "exit_codes": {
            "0": "Success — run_completed emitted",
            "1": "General error — unexpected exception, decision-mode fail, non-TTY auto/prompt, or llm_not_configured",
            "2": "Agent protocol error — stdin timeout, invalid JSON, kind mismatch, or bad option",
            "3": "Explicit abort — user or agent selected 'abort'",
        },
    }
