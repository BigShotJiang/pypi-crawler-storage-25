"""Configuration dataclass and loader.

Priority (high → low):
  1. CLI flags
  2. Project-level .withvideo/config.toml
  3. Defaults defined here
"""

from __future__ import annotations

import os
import shutil
import tomllib
from dataclasses import dataclass, field
from pathlib import Path


def _find_binary(name: str) -> str | None:
    """Locate a CLI binary, with fallback to well-known install paths."""
    found = shutil.which(name)
    if found:
        return found
    for directory in (Path.home() / ".local" / "bin", Path("/opt/homebrew/bin"), Path("/usr/local/bin")):
        candidate = directory / name
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return None


def _default_llm_command() -> str:
    env_override = os.environ.get("WITHVIDEO_LLM_COMMAND") or os.environ.get("WV_LLM_COMMAND")
    if env_override:
        return env_override
    codex = _find_binary("codex")
    if codex:
        return codex + " exec -"
    claude = _find_binary("claude")
    if claude:
        return claude + " -p {prompt}"
    cursor = _find_binary("cursor")
    if cursor:
        return cursor + " agent chat {prompt}"
    return ""  # No LLM found; pipeline will raise a clear error when LLM is needed


@dataclass
class WVConfig:
    # --- component selection ---
    acquirer: str = "auto"             # "auto" | "yt-dlp" | "local"
    transcript: str = "auto"           # "auto" | "mlx-whisper" | "faster-whisper" | "platform-subs"
    whisper_model: str = "mlx-community/whisper-large-v3-turbo"
    # faster-whisper specific knobs (ignored by other backends)
    whisper_device: str = "auto"       # "auto" | "cuda" | "cpu" (faster-whisper only)
    llm_command: str = field(default_factory=_default_llm_command)
    llm_timeout: int = 600
    activity: str = "auto"             # "auto" | "mv" | "ssim"
    vision: str = "cli"                # "cli" | "claude" | "ollama:<model>" | "none"
    vision_model: str = "claude-sonnet-4-6"
    plugin: str = "auto"               # "auto" | "code" | "blender" | "figma" | "general"
    cache: str = "joblib"              # "joblib" | "json" | "none"
    renderer: str = "markdown"         # "markdown"
    media_access: str = "download"     # "download" | "remote"
    event_stream: str = "auto"         # "off" | "auto" | "jsonl"
    decision_mode: str = "auto"        # "auto" | "prompt" | "fail" | "agent" | "defaults"

    # --- tuning ---
    max_frames: int = 200
    cookies: str | None = None
    cookies_from_browser: str | None = None

    # --- paths / control ---
    output: Path | None = None
    skip: list[str] = field(default_factory=list)   # stages to skip: transcript/semantic/vision/guide
    force: bool = False
    verbose: bool = False


def load_config(
    project_dir: Path | None = None,
    overrides: dict | None = None,
) -> WVConfig:
    """
    Build a WVConfig by merging:
      1. defaults
      2. .withvideo/config.toml (if found in project_dir)
      3. CLI overrides dict
    """
    cfg = WVConfig()

    # Load project-level config.toml
    if project_dir is not None:
        toml_path = project_dir / ".withvideo" / "config.toml"
        if toml_path.exists():
            with toml_path.open("rb") as f:
                data = tomllib.load(f)
            _apply_dict(cfg, data)

    # Apply CLI overrides (only non-None values)
    if overrides:
        _apply_dict(cfg, {k: v for k, v in overrides.items() if v is not None})

    return cfg


def _apply_dict(cfg: WVConfig, data: dict) -> None:
    for key, value in data.items():
        if hasattr(cfg, key) and value is not None:
            object.__setattr__(cfg, key, value)
