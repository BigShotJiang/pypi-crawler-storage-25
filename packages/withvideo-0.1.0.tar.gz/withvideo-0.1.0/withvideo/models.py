"""Core data models for withvideo."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class Platform(str, Enum):
    YOUTUBE = "youtube"
    BILIBILI = "bilibili"
    VIMEO = "vimeo"
    TWITTER = "twitter"
    LOCAL_FILE = "local"


class SubtitleQuality(str, Enum):
    WORD_LEVEL = "word_level"       # YouTube srv3/vtt — can replace Whisper
    SENTENCE_LEVEL = "sentence_level"  # Normal SRT/VTT
    UNRELIABLE = "unreliable"       # Bilibili AI subs — use Whisper instead
    NONE = "none"                   # No subtitles — must use Whisper


class TranscriptSource(str, Enum):
    WHISPER = "whisper"
    PLATFORM_MANUAL = "platform_manual"
    PLATFORM_AUTO = "platform_auto"
    PLATFORM_UNRELIABLE = "platform_unreliable"


class BurstPattern(str, Enum):
    TYPING = "TYPING"
    SCROLLING = "SCROLLING"
    TAB_SWITCH = "TAB_SWITCH"
    VIEWPORT_MANIPULATION = "VIEWPORT_MANIPULATION"
    CLICK_MENU = "CLICK_MENU"
    DRAG = "DRAG"
    UNKNOWN = "UNKNOWN"


class WindowType(str, Enum):
    EXPLAIN = "explain"    # Lecturer explaining concepts
    OPERATE = "operate"    # Lecturer performing operations
    VERIFY = "verify"      # Lecturer checking results


# ---------------------------------------------------------------------------
# Source / platform metadata
# ---------------------------------------------------------------------------

@dataclass
class SubtitleTrack:
    lang: str
    fmt: str          # "srt", "vtt", "srv3"
    path: Path | None = None
    is_generated: bool = False
    has_word_timestamps: bool = False
    source: str = "sidecar"


@dataclass
class Chapter:
    start: float
    end: float
    title: str


@dataclass
class SponsorSegment:
    start: float
    end: float
    category: str     # "sponsor", "intro", "outro", ...


@dataclass
class DanmakuItem:
    time: float       # video timestamp (seconds)
    text: str
    color: int = 0xFFFFFF
    type: int = 1     # 1=scroll, 4=bottom, 5=top


@dataclass
class VideoPart:
    index: int
    title: str
    cid: str
    duration: float


@dataclass(frozen=True)
class LocalMediaHandle:
    path: Path


@dataclass(frozen=True)
class RemoteMediaHandle:
    video_url: str
    headers: dict[str, str] = field(default_factory=dict)
    duration: float = 0.0
    platform: Platform = Platform.LOCAL_FILE


MediaHandle = LocalMediaHandle | RemoteMediaHandle


@dataclass
class SourceMeta:
    input: str                          # original URL or file path
    platform: Platform
    local_video_path: Path | None = None
    title: str = ""
    description: str = ""
    duration: float = 0.0
    uploader: str = ""
    upload_date: str = ""

    subtitles: list[SubtitleTrack] = field(default_factory=list)
    auto_captions: list[SubtitleTrack] = field(default_factory=list)
    subtitle_quality: SubtitleQuality = SubtitleQuality.NONE

    chapters: list[Chapter] = field(default_factory=list)
    sponsor_segments: list[SponsorSegment] = field(default_factory=list)
    danmaku: list[DanmakuItem] = field(default_factory=list)
    heatmap: list[dict] = field(default_factory=list)   # YouTube engagement [{start,end,value}]
    parts: list[VideoPart] = field(default_factory=list)  # Bilibili multi-part

    @property
    def video_path(self) -> Path | None:
        return self.local_video_path

    @video_path.setter
    def video_path(self, value: Path | None) -> None:
        self.local_video_path = value


# ---------------------------------------------------------------------------
# Transcript
# ---------------------------------------------------------------------------

@dataclass
class Word:
    word: str
    start: float
    end: float


@dataclass
class Segment:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)
    no_speech_prob: float = 0.0


@dataclass
class Transcript:
    source: TranscriptSource
    language: str
    segments: list[Segment]
    has_word_timestamps: bool = False


# ---------------------------------------------------------------------------
# Motion vector analysis
# ---------------------------------------------------------------------------

@dataclass
class MVVector:
    src_x: int
    src_y: int
    dst_x: int
    dst_y: int
    motion_x: int
    motion_y: int


@dataclass
class MVFrame:
    pts: float         # seconds
    frame_index: int
    vectors: list[MVVector]


@dataclass
class ActivitySample:
    time: float
    score: float


@dataclass
class ActivityBurst:
    start: float
    end: float
    peak_time: float
    peak_score: float
    duration: float
    pattern: BurstPattern = BurstPattern.UNKNOWN
    heatmap: list[list[float]] = field(default_factory=list)   # 16×9 grid, 0–1


@dataclass
class ActivityProfile:
    per_second: list[ActivitySample]
    threshold: float
    bursts: list[ActivityBurst]
    encoding_type: str = "INTER"   # "INTER" | "ALL_INTRA"


# ---------------------------------------------------------------------------
# Frames and vision analysis
# ---------------------------------------------------------------------------

@dataclass
class Frame:
    index: int
    timestamp: float
    path: Path
    extraction_reason: str = ""   # "pre_burst" | "peak" | "post_burst" | "intermediate"


@dataclass
class Operation:
    # Semantic fields (learn layer outputs these)
    capability: str = "ui_action"   # "ui_action" | "text_input"
    action: str = ""                # "click" | "navigate" | "type" | "run" | "open" | "select" | "scroll" | "drag"
    target: str = ""                # interaction target description (e.g., "GitHub search bar")
    intent: str = ""                # why this operation is performed
    app_context: str = ""           # "GitHub" | "VS Code" | "Terminal" | "Figma" | "Browser" | ...
    source: str = ""                # "transcript" | "vision" | "transcript+vision"
    text_content: str = ""          # for text_input: exact text to type
    visual_hint: str = ""           # visual description to help act layer locate the target

    # Human-readable and backward compat
    description: str = ""
    type: str = ""                  # legacy — prefer capability+action
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass
class FrameAnalysis:
    frame: Frame
    description: str = ""
    app_visible: str = ""
    code_state: str = ""               # writing|scrolling|showing_result|showing_error|no_code
    code_snapshot: str = ""            # verbatim code/text visible on screen
    content_snapshot: str = ""
    changes_from_previous: str = ""
    operations_detected: list[Operation] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Semantic windows and repeat steps
# ---------------------------------------------------------------------------

@dataclass
class Window:
    start: float
    end: float
    type: WindowType

    transcript_segments: list[Segment] = field(default_factory=list)
    activity_burst: ActivityBurst | None = None
    keyframes: list[Frame] = field(default_factory=list)
    frame_analyses: list[FrameAnalysis] = field(default_factory=list)

    # Semantic classification metadata
    needs_visual_evidence: bool = False   # gate for Stage 3 vision analysis
    intent: str = ""                      # raw intent from semantic judgment
    knowledge_topic: str = ""             # key topic for this window
    operation_cue: str = ""               # operation hint (for OPERATE windows)
    content_focus: str = ""               # what vision should prioritize reading

    summary: str = ""
    operations: list[Operation] = field(default_factory=list)
    expected_outcome: str = ""
    knowledge_points: list[str] = field(default_factory=list)


@dataclass
class RepeatStep:
    index: int
    explain: Window              # REQUIRED — every step is anchored on an explain window
    title: str = ""
    time_range: tuple[float, float] = (0.0, 0.0)

    operate: Window | None = None
    verify: Window | None = None

    operations: list[Operation] = field(default_factory=list)
    expected_outcome: str = ""
    prerequisites: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Final output
# ---------------------------------------------------------------------------

@dataclass
class KnowledgeEntry:
    timestamp: float
    topic: str
    step_index: int


@dataclass
class GuideMetadata:
    source: str
    title: str
    duration: str      # "MM:SS"
    plugin: str
    generated_at: str  # ISO date


@dataclass
class RepeatGuide:
    metadata: GuideMetadata
    overview: str
    prerequisites: list[str]
    steps: list[RepeatStep]
    knowledge_index: list[KnowledgeEntry]
