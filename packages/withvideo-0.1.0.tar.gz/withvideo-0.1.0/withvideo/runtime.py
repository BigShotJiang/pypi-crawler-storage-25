"""Run-time decision and event reporting helpers."""

from __future__ import annotations

import json
import select
import sys
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator, TextIO


@dataclass
class AgentDecisionError(Exception):
    """Raised when --decision-mode agent encounters a protocol error."""
    error_code: str   # agent_stdin_timeout | agent_stdin_invalid_json |
                      # agent_decision_kind_mismatch | agent_decision_invalid_option
    message: str

    def __str__(self) -> str:
        return self.message


def read_agent_decision(
    decision: "DecisionRequired",
    stdin: TextIO | None = None,
    timeout: float = 30.0,
) -> str:
    """Read a JSON decision response from stdin.

    Returns the selected option string.
    Raises AgentDecisionError on timeout, parse failure, or validation failure.
    """
    stdin = stdin or sys.stdin
    # Use select() on POSIX to implement timeout, but only when stdin has a
    # real file descriptor (not an in-memory StringIO used in tests).
    _has_real_fd = False
    try:
        stdin.fileno()
        _has_real_fd = True
    except Exception:
        pass

    if _has_real_fd and hasattr(select, "select"):
        readable, _, _ = select.select([stdin], [], [], timeout)
        if not readable:
            raise AgentDecisionError(
                error_code="agent_stdin_timeout",
                message=f"Agent did not respond within {timeout:.0f}s",
            )

    line = stdin.readline()
    if not line:
        raise AgentDecisionError(
            error_code="agent_stdin_timeout",
            message="Agent stdin reached EOF without a decision response",
        )

    try:
        payload = json.loads(line)
    except json.JSONDecodeError as exc:
        raise AgentDecisionError(
            error_code="agent_stdin_invalid_json",
            message=f"Agent decision response is not valid JSON: {exc}",
        ) from exc

    if not isinstance(payload, dict):
        raise AgentDecisionError(
            error_code="agent_stdin_invalid_json",
            message="Agent decision response must be a JSON object",
        )

    response_kind = payload.get("kind")
    if response_kind != decision.kind:
        raise AgentDecisionError(
            error_code="agent_decision_kind_mismatch",
            message=(
                f"Agent response kind '{response_kind}' does not match "
                f"pending decision kind '{decision.kind}'"
            ),
        )

    selected = payload.get("selected")
    if selected not in decision.options:
        raise AgentDecisionError(
            error_code="agent_decision_invalid_option",
            message=(
                f"Agent selected '{selected}' which is not in options "
                f"{decision.options}"
            ),
        )

    return selected


@dataclass
class DecisionRequired(Exception):
    kind: str
    reason_code: str
    message: str
    options: list[str]
    default_option: str
    stage: str | None = None
    context: dict[str, Any] = field(default_factory=dict)

    def __str__(self) -> str:
        return self.message


@dataclass
class TaskNode:
    task_id: str             # dot-separated: "acquire", "vision.analyze.step-3"
    label: str               # human-readable: "download", "analyze step 3"
    parent_id: str | None    # None = top-level
    depth: int               # 0=stage, 1=subtask, 2=sub-subtask
    started_at: float        # time.monotonic()
    total: int | None = None
    current: int = 0


class RunReporter:
    STAGE_WEIGHTS: dict[str, float] = {
        "acquire": 0.05,
        "transcript": 0.05,
        "semantic": 0.30,
        "vision": 0.50,
        "guide": 0.10,
    }

    def __init__(
        self,
        *,
        run_id: str | None = None,
        emit_jsonl: bool = False,
        stdout: TextIO | None = None,
        stderr: TextIO | None = None,
        human_enabled: bool = True,
    ):
        self.run_id = run_id or uuid.uuid4().hex
        self.emit_jsonl = emit_jsonl
        self.stdout = stdout or sys.stdout
        self.stderr = stderr or sys.stderr
        self.human_enabled = human_enabled
        self._task_stack: list[TaskNode] = []
        self._pipeline_started_at: float = 0.0
        self._completed_stages: list[str] = []
        self._progress_file: Path | None = None
        self._stage_status: dict[str, dict[str, Any]] = {}

    def pipeline_started(self) -> None:
        self._pipeline_started_at = time.monotonic()
        self._completed_stages = []

    def _emit_pipeline_progress(self, completed_stage: str) -> None:
        if completed_stage not in self._completed_stages:
            self._completed_stages.append(completed_stage)
        done_weight = sum(self.STAGE_WEIGHTS.get(s, 0) for s in self._completed_stages)
        elapsed = time.monotonic() - self._pipeline_started_at if self._pipeline_started_at else 0.0

        if done_weight > 0 and done_weight < 1.0 and elapsed > 0:
            estimated_total = elapsed / done_weight
            remaining = estimated_total - elapsed
            if remaining > 60:
                remaining_str = f"{remaining / 60:.0f}m"
            else:
                remaining_str = f"{remaining:.0f}s"
            eta_part = f" | 预计还需 ~{remaining_str}"
        elif done_weight >= 1.0:
            eta_part = f" | 总耗时 {elapsed:.0f}s"
        else:
            eta_part = ""

        bar_len = 20
        filled = int(bar_len * min(done_weight, 1.0))
        bar = "\u2501" * filled + "\u2591" * (bar_len - filled)
        pct = int(done_weight * 100)

        self.human(f"[wv] {bar} {pct}% | {completed_stage} \u2713 {elapsed:.0f}s{eta_part}")

    # ------------------------------------------------------------------
    # Progress file — real-time status for external polling
    # ------------------------------------------------------------------

    def _current_stage_name(self) -> str | None:
        """Return the stage currently in-progress (top-level task_id)."""
        for node in reversed(self._task_stack):
            if node.depth == 0:
                return node.task_id
        return None

    def _write_progress(self) -> None:
        """Write current pipeline state to a JSON file (atomic rename)."""
        if not self._progress_file:
            return
        elapsed = time.monotonic() - self._pipeline_started_at if self._pipeline_started_at else 0.0
        done_weight = sum(self.STAGE_WEIGHTS.get(s, 0) for s in self._completed_stages)

        if 0 < done_weight < 1.0 and elapsed > 0:
            eta_s: float | None = (elapsed / done_weight) - elapsed
        else:
            eta_s = None

        payload: dict[str, Any] = {
            "run_id": self.run_id,
            "elapsed_s": round(elapsed, 1),
            "progress": round(done_weight, 3),
            "eta_s": round(eta_s) if eta_s is not None else None,
            "current_stage": self._current_stage_name(),
            "stages": self._stage_status,
            "done": done_weight >= 1.0,
        }
        try:
            tmp = self._progress_file.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False) + "\n")
            tmp.rename(self._progress_file)
        except OSError:
            pass  # best-effort; don't crash pipeline for progress file issues

    def human(self, message: str) -> None:
        if not self.human_enabled:
            return
        print(message, file=self.stderr, flush=True)

    def emit(
        self,
        event_type: str,
        *,
        stage: str | None = None,
        message: str = "",
        context: dict[str, Any] | None = None,
        task_id: str | None = None,
        parent_task_id: str | None = None,
        depth: int | None = None,
    ) -> None:
        if not self.emit_jsonl:
            return
        payload: dict[str, Any] = {
            "type": event_type,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "run_id": self.run_id,
            "stage": stage,
            "message": message,
            "context": context or {},
        }
        if task_id is not None:
            payload["task_id"] = task_id
        if parent_task_id is not None:
            payload["parent_task_id"] = parent_task_id
        if depth is not None:
            payload["depth"] = depth
        self.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
        self.stdout.flush()

    # ------------------------------------------------------------------
    # Task tree API
    # ------------------------------------------------------------------

    def task_started(
        self,
        task_id: str,
        label: str,
        *,
        parent_id: str | None = None,
        total: int | None = None,
        context: dict[str, Any] | None = None,
    ) -> TaskNode:
        if parent_id is None and self._task_stack:
            parent_id = self._task_stack[-1].task_id
        depth = 0
        if parent_id is not None:
            parent = self._find_task(parent_id)
            depth = (parent.depth + 1) if parent else 1

        node = TaskNode(
            task_id=task_id,
            label=label,
            parent_id=parent_id,
            depth=depth,
            started_at=time.monotonic(),
            total=total,
        )
        self._task_stack.append(node)

        indent = "  " * depth
        progress = f" [0/{total}]" if total is not None else ""
        self.human(f"[wv] {indent}\u25b6 {label}{progress}")

        stage = task_id.split(".")[0]
        self.emit(
            "task_started",
            stage=stage,
            message=label,
            context={**(context or {}), **({"total": total} if total is not None else {})},
            task_id=task_id,
            parent_task_id=parent_id,
            depth=depth,
        )
        return node

    def task_progress(
        self,
        task_id: str,
        current: int,
        *,
        message: str = "",
        context: dict[str, Any] | None = None,
    ) -> None:
        node = self._find_task(task_id)
        if node is None:
            return
        node.current = current
        indent = "  " * node.depth
        progress = f" [{current}/{node.total}]" if node.total is not None else f" [{current}]"
        detail = f" \u2014 {message}" if message else ""
        eta = ""
        if node.total and node.current > 0:
            elapsed = time.monotonic() - node.started_at
            remaining = (node.total - node.current) * (elapsed / node.current)
            if remaining > 5:
                eta = f" | ETA ~{remaining:.0f}s"
        self.human(f"[wv] {indent}  {node.label}{progress}{detail}{eta}")

        stage = task_id.split(".")[0]
        self.emit(
            "task_progress",
            stage=stage,
            message=message,
            context={**(context or {}), "current": current, **({"total": node.total} if node.total is not None else {})},
            task_id=task_id,
            parent_task_id=node.parent_id,
            depth=node.depth,
        )
        # Update stage status with sub-task progress for progress file
        if stage in self._stage_status and node.total is not None:
            self._stage_status[stage]["current"] = current
            self._stage_status[stage]["total"] = node.total
            self._write_progress()

    def task_completed(
        self,
        task_id: str,
        message: str = "",
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        node = self._pop_task(task_id)
        if node is None:
            return
        elapsed = time.monotonic() - node.started_at
        indent = "  " * node.depth
        elapsed_str = f" ({elapsed:.1f}s)" if elapsed >= 0.1 else ""
        detail = f" \u2014 {message}" if message else ""
        self.human(f"[wv] {indent}\u2713 {node.label}{detail}{elapsed_str}")

        stage = task_id.split(".")[0]
        self.emit(
            "task_completed",
            stage=stage,
            message=message,
            context={**(context or {}), "elapsed_s": round(elapsed, 2)},
            task_id=task_id,
            parent_task_id=node.parent_id,
            depth=node.depth,
        )

    def task_failed(
        self,
        task_id: str,
        message: str = "",
        *,
        context: dict[str, Any] | None = None,
    ) -> None:
        node = self._pop_task(task_id)
        if node is None:
            return
        elapsed = time.monotonic() - node.started_at
        indent = "  " * node.depth
        elapsed_str = f" ({elapsed:.1f}s)" if elapsed >= 0.1 else ""
        detail = f" \u2014 {message}" if message else ""
        self.human(f"[wv] {indent}\u2717 {node.label}{detail}{elapsed_str}")

        stage = task_id.split(".")[0]
        self.emit(
            "task_failed",
            stage=stage,
            message=message,
            context={**(context or {}), "elapsed_s": round(elapsed, 2)},
            task_id=task_id,
            parent_task_id=node.parent_id,
            depth=node.depth,
        )

    @contextmanager
    def task(
        self,
        task_id: str,
        label: str,
        *,
        total: int | None = None,
        context: dict[str, Any] | None = None,
    ) -> Iterator[TaskNode]:
        node = self.task_started(task_id, label, total=total, context=context)
        try:
            yield node
        except Exception as exc:
            self.task_failed(task_id, str(exc) if str(exc) else type(exc).__name__)
            raise
        else:
            self.task_completed(task_id)

    def _find_task(self, task_id: str) -> TaskNode | None:
        for node in reversed(self._task_stack):
            if node.task_id == task_id:
                return node
        return None

    def _pop_task(self, task_id: str) -> TaskNode | None:
        for i in range(len(self._task_stack) - 1, -1, -1):
            if self._task_stack[i].task_id == task_id:
                return self._task_stack.pop(i)
        return None

    # ------------------------------------------------------------------
    # Stage-level events (bridge to task tree + legacy events)
    # ------------------------------------------------------------------

    def run_started(self, *, input_value: str, context: dict[str, Any] | None = None) -> None:
        self.emit("run_started", message="Run started", context={"input": input_value, **(context or {})})

    def run_completed(self, *, output_path: str, context: dict[str, Any] | None = None) -> None:
        self.emit("run_completed", message="Run completed",
                  context={"output_path": output_path, **(context or {})})
        self._write_progress()

    def run_failed(self, message: str, *, stage: str | None = None, context: dict[str, Any] | None = None) -> None:
        self.emit("run_failed", stage=stage, message=message, context=context)
        if stage and stage in self._stage_status:
            self._stage_status[stage]["status"] = "failed"
        self._write_progress()

    def stage_started(self, stage: str, message: str, *, context: dict[str, Any] | None = None) -> None:
        self.emit("stage_started", stage=stage, message=message, context=context)
        self.task_started(stage, stage, context=context)
        self._stage_status[stage] = {"status": "in_progress"}
        self._write_progress()

    def stage_completed(self, stage: str, message: str, *, context: dict[str, Any] | None = None) -> None:
        self.task_completed(stage, message, context=context)
        self.emit("stage_completed", stage=stage, message=message, context=context)
        elapsed = time.monotonic() - self._pipeline_started_at if self._pipeline_started_at else 0.0
        self._stage_status[stage] = {"status": "completed", "elapsed_s": round(elapsed, 1)}
        if self._pipeline_started_at:
            self._emit_pipeline_progress(stage)
        self._write_progress()

    def artifact_written(
        self,
        *,
        stage: str,
        path: str,
        artifact_type: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        self.emit(
            "artifact_written",
            stage=stage,
            message=f"Artifact written: {artifact_type}",
            context={"path": path, "artifact_type": artifact_type, **(context or {})},
        )

    def decision_required(self, decision: DecisionRequired) -> None:
        self.emit(
            "decision_required",
            stage=decision.stage,
            message=decision.message,
            context={
                "kind": decision.kind,
                "reason_code": decision.reason_code,
                "options": decision.options,
                "default_option": decision.default_option,
                **decision.context,
            },
        )

    def decision_selected(self, decision: DecisionRequired, selected: str) -> None:
        self.emit(
            "decision_selected",
            stage=decision.stage,
            message=f"Decision selected: {selected}",
            context={
                "kind": decision.kind,
                "reason_code": decision.reason_code,
                "selected": selected,
                "options": decision.options,
                "default_option": decision.default_option,
                **decision.context,
            },
        )


_CURRENT_REPORTER: RunReporter = RunReporter(emit_jsonl=False)


def get_current_reporter() -> RunReporter:
    return _CURRENT_REPORTER


@contextmanager
def use_reporter(reporter: RunReporter) -> Iterator[None]:
    global _CURRENT_REPORTER
    previous = _CURRENT_REPORTER
    _CURRENT_REPORTER = reporter
    try:
        yield
    finally:
        _CURRENT_REPORTER = previous
