"""wv preflight — lightweight environment and source probe.

Runs in seconds, does NOT start the pipeline.
Returns a JSON-serialisable dict with three top-level keys:
  environment  — local tool availability
  source       — video source metadata
  recommended  — suggested wv learn flags
  command      — ready-to-run wv learn command string
"""

from __future__ import annotations

import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Any

from .config import WVConfig, _default_llm_command, _find_binary
from .impl.acquirers.common import detect_platform, is_url_input
from .models import Platform


# ---------------------------------------------------------------------------
# Environment checks
# ---------------------------------------------------------------------------

def _check_environment(cfg: WVConfig) -> dict[str, Any]:
    issues: list[str] = []

    ffmpeg = _find_binary("ffmpeg")
    ffprobe = _find_binary("ffprobe")
    if not ffmpeg:
        issues.append("ffmpeg_not_found")
    if not ffprobe:
        issues.append("ffprobe_not_found")

    llm_cmd = cfg.llm_command or _default_llm_command()
    llm_available = False
    llm_source = "not configured"
    if llm_cmd:
        binary = shlex.split(llm_cmd)[0]
        if shutil.which(binary) or _find_binary(binary):
            llm_available = True
            if "codex" in binary:
                llm_source = "codex CLI (auto-detect)"
            elif "claude" in binary:
                llm_source = "claude CLI (auto-detect)"
            elif "cursor" in binary:
                llm_source = "cursor CLI (auto-detect)"
            else:
                llm_source = f"{binary} (configured)"
        else:
            issues.append("llm_not_configured")
    else:
        issues.append("llm_not_configured")

    whisper_available = False
    try:
        import mlx_whisper  # noqa: F401
        whisper_available = True
    except ImportError:
        pass
    try:
        import faster_whisper  # noqa: F401
        whisper_available = True
    except ImportError:
        pass

    return {
        "ffmpeg": ffmpeg,
        "ffprobe": ffprobe,
        "llm_command": llm_cmd or None,
        "llm_command_source": llm_source,
        "llm_available": llm_available,
        "whisper_available": whisper_available,
        "issues": issues,
    }


# ---------------------------------------------------------------------------
# Source probe
# ---------------------------------------------------------------------------

def _probe_bilibili(source: str, cfg: WVConfig) -> dict[str, Any]:
    """Probe a Bilibili URL using bilibili_api (fast, no download)."""
    import asyncio
    import re

    try:
        from bilibili_api import video as bv_video, Credential  # type: ignore
    except ImportError:
        return {
            "platform": "bilibili",
            "title": None,
            "duration": None,
            "remote_capable": True,
            "subtitle_available": None,
            "subtitle_quality": None,
            "danmaku_available": None,
            "cookies_found": False,
            "parts": None,
            "probe_error": "bilibili_api not installed",
        }

    bvid_match = re.search(r"(BV[0-9A-Za-z]+)", source)
    if not bvid_match:
        return {"platform": "bilibili", "probe_error": "could not extract BV id"}

    bvid = bvid_match.group(1)

    # Try to load cookies
    from .impl.acquirers.auth import load_site_cookies
    cookies_found = False
    credential = None
    cookiefile: Path | None = None
    if cfg.cookies:
        cookiefile = Path(cfg.cookies)
    if cookiefile and cookiefile.exists():
        cookies = load_site_cookies(cookiefile, "bilibili.com")
        if cookies:
            cookies_found = True
            credential = Credential(
                sessdata=cookies.get("SESSDATA"),
                bili_jct=cookies.get("bili_jct"),
                buvid3=cookies.get("buvid3"),
            )

    async def _fetch() -> dict:
        v = bv_video.Video(bvid=bvid, credential=credential)
        try:
            info = await v.get_info()
        except Exception as exc:
            return {"error": str(exc)}
        pages = info.get("pages") or []
        subtitle_available = bool(info.get("subtitle", {}).get("list"))
        danmaku_available = bool(info.get("cid") or (pages and pages[0].get("cid")))
        return {
            "title": info.get("title"),
            "duration": info.get("duration"),
            "parts": len(pages) if pages else 1,
            "subtitle_available": subtitle_available,
            "danmaku_available": danmaku_available,
        }

    try:
        data = asyncio.run(_fetch())
    except Exception as exc:
        data = {"error": str(exc)}

    if "error" in data:
        return {
            "platform": "bilibili",
            "remote_capable": True,
            "cookies_found": cookies_found,
            "probe_error": data["error"],
        }

    return {
        "platform": "bilibili",
        "title": data.get("title"),
        "duration": data.get("duration"),
        "remote_capable": True,
        "subtitle_available": data.get("subtitle_available"),
        "subtitle_quality": "sentence_level" if data.get("subtitle_available") else None,
        "danmaku_available": data.get("danmaku_available"),
        "cookies_found": cookies_found,
        "parts": data.get("parts", 1),
    }


def _probe_youtube(source: str) -> dict[str, Any]:
    """Probe a YouTube URL with yt-dlp --dump-json (no download)."""
    ytdlp = _find_binary("yt-dlp")
    if not ytdlp:
        return {
            "platform": "youtube",
            "probe_error": "yt-dlp not found",
        }
    try:
        result = subprocess.run(
            [ytdlp, "--dump-json", "--no-playlist", source],
            capture_output=True, text=True, timeout=30, check=False,
        )
        if result.returncode != 0:
            return {"platform": "youtube", "probe_error": result.stderr.strip()[:200]}
        import json
        info = json.loads(result.stdout)
        has_auto_subs = bool(info.get("automatic_captions"))
        has_subs = bool(info.get("subtitles"))
        return {
            "platform": "youtube",
            "title": info.get("title"),
            "duration": info.get("duration"),
            "remote_capable": False,
            "subtitle_available": has_auto_subs or has_subs,
            "subtitle_quality": "word_level" if (has_auto_subs or has_subs) else None,
            "danmaku_available": False,
            "cookies_found": False,
            "parts": None,
        }
    except Exception as exc:
        return {"platform": "youtube", "probe_error": str(exc)}


def _probe_local(source: str) -> dict[str, Any]:
    path = Path(source)
    if not path.exists():
        return {"platform": "local", "probe_error": f"file not found: {source}"}

    duration: float | None = None
    ffprobe = _find_binary("ffprobe")
    if ffprobe:
        try:
            result = subprocess.run(
                [ffprobe, "-v", "quiet", "-print_format", "json",
                 "-show_format", str(path)],
                capture_output=True, text=True, timeout=10, check=False,
            )
            if result.returncode == 0:
                import json
                fmt = json.loads(result.stdout).get("format", {})
                duration = float(fmt.get("duration") or 0) or None
        except Exception:
            pass

    # Check for existing .withvideo/ output
    work_dir = Path(".withvideo") / path.stem
    existing_output = str(work_dir / "guide.md") if (work_dir / "guide.md").exists() else None

    return {
        "platform": "local",
        "title": path.stem,
        "duration": duration,
        "remote_capable": False,
        "subtitle_available": False,
        "subtitle_quality": None,
        "danmaku_available": False,
        "cookies_found": False,
        "parts": None,
        "existing_output": existing_output,
    }


def _probe_source(source: str, cfg: WVConfig) -> dict[str, Any]:
    if is_url_input(source):
        platform = detect_platform(source)
        if platform == Platform.BILIBILI:
            info = _probe_bilibili(source, cfg)
        elif platform == Platform.YOUTUBE:
            info = _probe_youtube(source)
        else:
            info = {
                "platform": platform.value.lower(),
                "remote_capable": False,
                "subtitle_available": None,
            }
    else:
        info = _probe_local(source)

    # Check for existing .withvideo/ output for URL-based sources
    if is_url_input(source) and "existing_output" not in info:
        info["existing_output"] = None

    return info


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------

def _build_recommendations(env: dict, source: dict, source_str: str, cfg: WVConfig) -> dict[str, Any]:
    rationale: list[str] = []
    issues: list[str] = env.get("issues", [])

    media_access = "download"
    if source.get("remote_capable"):
        if source.get("subtitle_available"):
            media_access = "remote"
            rationale.append(f"{source.get('platform', '').capitalize()} 视频支持远端获取，无需下载")
            rationale.append(f"平台字幕可用（{source.get('subtitle_quality', 'unknown')}）")
        else:
            rationale.append(f"平台无可用字幕，建议下载后用 Whisper 转录")

    transcript = "auto"
    if media_access == "remote" and source.get("subtitle_available"):
        rationale.append("使用平台字幕，无需本地转录")
    elif not env.get("whisper_available"):
        rationale.append("未安装 faster-whisper / mlx-whisper，字幕获取依赖平台字幕")

    vision = "cli"
    if "llm_not_configured" in issues:
        vision = "none"
        rationale.append("未找到 LLM 命令，vision 已禁用（需设置 WV_LLM_COMMAND）")
    elif env.get("llm_available"):
        rationale.append(f"检测到 {env.get('llm_command_source', 'LLM')}")

    decision_mode = "defaults"

    # cookies hint
    if source.get("platform") == "bilibili" and not source.get("cookies_found"):
        rationale.append("提示：B站 1080p+ 需要 cookies（--cookies-from-browser chrome）")

    return {
        "media_access": media_access,
        "transcript": transcript,
        "vision": vision,
        "decision_mode": decision_mode,
        "rationale": rationale,
    }


def _build_command(source: str, rec: dict) -> str:
    parts = ["wv", "learn", shlex.quote(source)]
    if rec["media_access"] != "download":
        parts += ["--media-access", rec["media_access"]]
    if rec["vision"] != "cli":
        parts += ["--vision", rec["vision"]]
    if rec["transcript"] != "auto":
        parts += ["--transcript", rec["transcript"]]
    parts += ["--decision-mode", rec["decision_mode"]]
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_preflight(source: str, cfg: WVConfig) -> dict[str, Any]:
    """Run environment + source probe and return a JSON-serialisable report."""
    env = _check_environment(cfg)
    src = _probe_source(source, cfg)
    rec = _build_recommendations(env, src, source, cfg)
    return {
        "environment": env,
        "source": src,
        "recommended": rec,
        "command": _build_command(source, rec),
    }
