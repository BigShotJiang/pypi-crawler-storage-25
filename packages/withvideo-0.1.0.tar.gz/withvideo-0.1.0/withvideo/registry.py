"""Component registry: maps config string names to implementation classes."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from .config import WVConfig

if TYPE_CHECKING:
    from .protocols import (
        ActivityDetector, DomainPlugin, ReportRenderer,
        SourceAcquirer, StageCache, TranscriptProvider, VisionBackend,
    )

# Lazy imports keep startup fast — only load what's needed
def _acquirers():
    from .impl.acquirers.generic_url import GenericUrlAcquirer
    from .impl.acquirers.local_file import LocalFileAcquirer
    from .impl.acquirers.router import AutoInputAcquirer
    return {"auto": AutoInputAcquirer, "yt-dlp": GenericUrlAcquirer, "local": LocalFileAcquirer}

def _transcript_providers():
    from .impl.transcripts.adaptive import AdaptiveTranscriptProvider
    from .impl.transcripts.faster_whisper import FasterWhisperProvider
    from .impl.transcripts.mlx_whisper import MlxWhisperProvider
    from .impl.transcripts.platform_subs import PlatformSubsProvider
    return {
        "auto": AdaptiveTranscriptProvider,
        "mlx-whisper": MlxWhisperProvider,
        "faster-whisper": FasterWhisperProvider,
        "platform-subs": PlatformSubsProvider,
    }

def _activity_detectors():
    from .impl.activity.mv import MVDetector
    from .impl.activity.ssim import SSIMDetector
    return {"mv": MVDetector, "ssim": SSIMDetector}

def _vision_backends():
    from .impl.vision.cli import CliVisionBackend
    from .impl.vision.claude import ClaudeBackend
    from .impl.vision.none import NoVisionBackend
    backends = {"cli": CliVisionBackend, "claude": ClaudeBackend, "none": NoVisionBackend}
    try:
        from .impl.vision.ollama import OllamaBackend
        backends["ollama"] = OllamaBackend
    except ImportError:
        pass
    return backends

def _domain_plugins():
    from .impl.plugins.code import CodePlugin
    from .impl.plugins.general import GeneralPlugin
    from .impl.plugins.auto import AutoDetectPlugin
    plugins = {
        "code": CodePlugin,
        "general": GeneralPlugin,
        "auto": AutoDetectPlugin,
    }
    # Stub plugins (registered but not fully implemented)
    try:
        from .impl.plugins.blender import BlenderPlugin
        plugins["blender"] = BlenderPlugin
    except ImportError:
        pass
    try:
        from .impl.plugins.figma import FigmaPlugin
        plugins["figma"] = FigmaPlugin
    except ImportError:
        pass
    return plugins

def _stage_caches():
    from .impl.caches.joblib_cache import JoblibCache
    from .impl.caches.json_cache import JsonCache
    from .impl.caches.no_cache import NoCache
    return {"joblib": JoblibCache, "json": JsonCache, "none": NoCache}

def _renderers():
    from .impl.renderers.markdown import MarkdownRenderer
    return {"markdown": MarkdownRenderer}


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def build_acquirer(cfg: WVConfig) -> "SourceAcquirer":
    return _acquirers()[cfg.acquirer](cfg)


def build_transcript_provider(cfg: WVConfig, meta=None) -> "TranscriptProvider":
    return _transcript_providers()[cfg.transcript](cfg)


def build_activity_detector(cfg: WVConfig, video_path: Path | None = None) -> "ActivityDetector":
    if cfg.activity == "auto":
        # Try MV first; SSIMDetector is the fallback (handled inside MVDetector)
        return _activity_detectors()["mv"](cfg)
    return _activity_detectors()[cfg.activity](cfg)


def build_vision_backend(cfg: WVConfig) -> "VisionBackend":
    key = cfg.vision
    if key.startswith("ollama:"):
        model = key.split(":", 1)[1]
        from .impl.vision.ollama import OllamaBackend
        return OllamaBackend(model, cfg)
    return _vision_backends()[key](cfg)


def build_plugin(cfg: WVConfig) -> "DomainPlugin":
    return _domain_plugins()[cfg.plugin](cfg)


def build_cache(cfg: WVConfig, work_dir: Path) -> "StageCache":
    if cfg.force:
        from .impl.caches.no_cache import NoCache
        return NoCache()
    return _stage_caches()[cfg.cache](work_dir)


def build_renderer(cfg: WVConfig) -> "ReportRenderer":
    return _renderers()[cfg.renderer]()
