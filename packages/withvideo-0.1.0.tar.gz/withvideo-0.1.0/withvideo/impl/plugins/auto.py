"""AutoDetectPlugin — wraps all plugins and delegates to the best match."""

from __future__ import annotations

from ...config import WVConfig
from ...models import Frame, FrameAnalysis, Operation, Transcript
from .code import CodePlugin
from .general import GeneralPlugin


_TRANSCRIPT_CONFIDENCE_THRESHOLD = 0.5


class AutoDetectPlugin:
    name = "auto"
    description = "Auto-detects the domain plugin based on video content."

    def __init__(self, cfg: WVConfig | None = None):
        self._candidates = [CodePlugin(cfg), GeneralPlugin(cfg)]
        self._selected: object = self._candidates[-1]  # default to general
        self._transcript_selected = False

    def select_from_transcript(self, transcript: Transcript) -> None:
        """Phase 1: transcript keyword scoring (free, no frames needed)."""
        best_score = -1.0
        best = self._candidates[-1]
        for plugin in self._candidates:
            if hasattr(plugin, "detect_from_transcript"):
                score = plugin.detect_from_transcript(transcript)
                if score > best_score:
                    best_score = score
                    best = plugin
        if best_score >= _TRANSCRIPT_CONFIDENCE_THRESHOLD:
            self._selected = best
            self._transcript_selected = True

    def select(self, frames: list[Frame]) -> None:
        """Phase 2: vision-based detection (fallback if transcript was inconclusive)."""
        if self._transcript_selected:
            return  # already decided from transcript
        best_score = -1.0
        best = self._candidates[-1]
        for plugin in self._candidates:
            score = plugin.detect(frames)
            if score > best_score:
                best_score = score
                best = plugin
        if best_score >= 0.3:
            self._selected = best

    @property
    def selected_name(self) -> str:
        return self._selected.name  # type: ignore

    def detect_from_transcript(self, transcript: Transcript) -> float:
        return max(
            p.detect_from_transcript(transcript) for p in self._candidates
            if hasattr(p, "detect_from_transcript")
        )

    def detect(self, frames: list[Frame]) -> float:
        return max(p.detect(frames) for p in self._candidates)

    def frame_prompt(self) -> str:
        return self._selected.frame_prompt()  # type: ignore

    def extract_operations(self, analysis: FrameAnalysis) -> list[Operation]:
        return self._selected.extract_operations(analysis)  # type: ignore

    def format_for_report(self, ops: list[Operation]) -> str:
        return self._selected.format_for_report(ops)  # type: ignore
