"""Code/terminal/browser tutorial plugin."""

from __future__ import annotations

from ...config import WVConfig
from ...models import Frame, FrameAnalysis, Operation, Transcript


_DETECT_KEYWORDS = [
    "vscode", "vs code", "code.exe",
    "terminal", "iterm", "bash", "zsh", "powershell", "cmd",
    "jupyter", "notebook",
    "chrome devtools", "firefox devtools", "browser",
    "vim", "nvim", "emacs", "nano",
    "pycharm", "intellij", "webstorm", "cursor",
    # package managers / import patterns
    "npm", "pip", "yarn", "cargo", "go get", "brew install",
    "import ", "require(", "from ", "include ",
    # language identifiers
    ".py", ".js", ".ts", ".jsx", ".tsx", ".go", ".rs", ".java",
    # DevOps
    "git ", "docker", "kubectl", "terraform",
    # dev server
    "localhost", "127.0.0.1", "port ",
    # debug
    "error:", "traceback", "exception", "debug",
    # generic code terms
    "function ", "class ", "def ", "const ", "let ", "var ",
]


class CodePlugin:
    name = "code"
    description = "Code editors, terminals, and browser DevTools."

    def __init__(self, cfg: WVConfig | None = None):
        pass

    def detect_from_transcript(self, transcript: Transcript) -> float:
        """Transcript-first plugin detection. Returns confidence 0.0–1.0."""
        text = " ".join(s.text for s in transcript.segments).lower()
        hits = sum(1 for kw in _DETECT_KEYWORDS if kw in text)
        return min(hits / 5.0, 1.0)  # 5+ keyword hits → full confidence

    def detect(self, frames: list[Frame]) -> float:
        if not frames:
            return 0.0
        # Sample first few frames; look for IDE/terminal indicators via quick OCR-like check
        # (actual detection happens during vision analysis — this is just a rough first pass)
        return 0.5  # medium default confidence; AutoDetectPlugin will call vision to refine

    def frame_prompt(self) -> str:
        return (
            "This appears to be a coding tutorial. Focus on:\n"
            "1. The IDE or editor being used (VS Code, PyCharm, terminal, etc.)\n"
            "2. File names visible in tabs, title bar, or file explorer\n"
            "3. Code being written or edited — extract exact code snippets\n"
            "4. Terminal commands being typed or their output\n"
            "5. Browser URLs if visible\n"
            "6. Any error messages\n\n"
            "Output JSON:\n"
            "{\n"
            '  "description": "...",\n'
            '  "app_visible": "VS Code / Terminal / ...",\n'
            '  "content_snapshot": "visible code or terminal text",\n'
            '  "changes_from_previous": "what changed",\n'
            '  "operations_detected": [\n'
            '    {"type": "shell", "description": "...", "payload": {"command": "..."}},\n'
            '    {"type": "code_edit", "description": "...", "payload": {"file": "...", "language": "...", "content": "..."}}\n'
            "  ]\n"
            "}"
        )

    def extract_operations(self, analysis: FrameAnalysis) -> list[Operation]:
        ops = []
        for op in analysis.operations_detected:
            if isinstance(op, Operation):
                if not op.source:
                    op.source = "vision"
                ops.append(op)
                continue
            raw = op if isinstance(op, dict) else {}
            op_type = raw.get("type") or "ui_action"
            # Map legacy types to canonical capability+action
            if op_type == "shell":
                capability, action = "text_input", "run_command"
            elif op_type == "code_edit":
                capability, action = "text_input", "write_code"
            else:
                capability = raw.get("capability") or "ui_action"
                action = raw.get("action") or ""
            text = (raw.get("payload", {}).get("command")
                    or raw.get("payload", {}).get("content") or "")
            # Fallback: use code_snapshot for code operations without explicit payload
            if not text and op_type in ("shell", "code_edit") and analysis.code_snapshot:
                text = analysis.code_snapshot
            ops.append(Operation(
                capability=capability,
                action=action,
                app_context=raw.get("app_context") or analysis.app_visible or "",
                source="vision",
                text_content=text,
                description=raw.get("description") or "",
                type=op_type,
                payload=raw.get("payload") or {},
            ))
        return ops

    def format_for_report(self, ops: list[Operation]) -> list[str]:
        lines = []
        for op in ops:
            if op.type == "shell":
                cmd = op.payload.get("command") or ""
                lines.append(f"```bash\n{cmd}\n```")
            elif op.type == "code_edit":
                lang = op.payload.get("language") or ""
                content = op.payload.get("content") or op.payload.get("diff") or ""
                lines.append(f"```{lang}\n{content}\n```")
            else:
                lines.append(f"- {op.description}")
        return "\n".join(lines)
