"""General-purpose fallback plugin."""

from __future__ import annotations

from ...config import WVConfig
from ...models import Frame, FrameAnalysis, Operation, Transcript


class GeneralPlugin:
    name = "general"
    description = "Generic fallback for unrecognised tutorial domains."

    def __init__(self, cfg: WVConfig | None = None):
        pass

    def detect_from_transcript(self, transcript: Transcript) -> float:
        return 0.1  # lowest priority — always fallback

    def detect(self, frames: list[Frame]) -> float:
        return 0.1  # lowest priority

    def frame_prompt(self) -> str:
        return (
            "Analyse the screen carefully. Describe:\n"
            "1. What application or tool is visible\n"
            "2. What action appears to have been taken (click, type, drag, etc.)\n"
            "3. Any visible text, menus, or UI elements that changed\n"
            "Output JSON with keys: description, app_visible, content_snapshot, "
            "changes_from_previous, operations_detected"
        )

    def extract_operations(self, analysis: FrameAnalysis) -> list[Operation]:
        ops = []
        for op in analysis.operations_detected:
            if isinstance(op, Operation):
                if not op.source:
                    op.source = "vision"
                ops.append(op)
                continue
            if isinstance(op, dict):
                ops.append(Operation(
                    capability="ui_action",
                    action=op.get("action") or "",
                    app_context=op.get("app_context") or analysis.app_visible or "",
                    source="vision",
                    description=op.get("description") or "",
                    type=op.get("type") or "ui_action",
                    payload=op.get("payload") or {},
                ))
        return ops

    def format_for_report(self, ops: list[Operation]) -> str:
        return "\n".join(f"- {op.description}" for op in ops)
