"""Generic CLI vision backend — uses the configured CLI command to analyze frames."""

from __future__ import annotations

import shlex
import subprocess

from ...config import WVConfig
from ...models import Frame, FrameAnalysis
from .claude import _build_prompt, _parse_response


def _resolve_cli_command(prompt: str, cfg: WVConfig) -> list[str]:
    parts = shlex.split(cfg.llm_command)
    if not parts:
        raise ValueError("llm_command is empty")
    resolved: list[str] = []
    placeholder_seen = False
    for part in parts:
        if "{prompt}" in part:
            placeholder_seen = True
            replaced = part.replace("{prompt}", prompt)
            if replaced:
                resolved.append(replaced)
            continue
        resolved.append(part)
    if not placeholder_seen and "-" not in resolved:
        resolved.append(prompt)
    return resolved


def _resolve_cli_input(prompt: str, cfg: WVConfig) -> str | None:
    parts = shlex.split(cfg.llm_command)
    if any("{prompt}" in part for part in parts):
        return None
    if any(part == "-" for part in parts):
        return prompt
    return None


class CliVisionBackend:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def analyze_frame_pair(
        self,
        prev: Frame | None,
        curr: Frame,
        context: str = "",
        domain_prompt: str = "",
        spatial_hint: str = "",
        pattern_hint: str = "",
    ) -> FrameAnalysis:
        prompt = _build_prompt(prev, curr, context, domain_prompt, spatial_hint, pattern_hint)
        stdin_input = _resolve_cli_input(prompt, self._cfg)
        result = subprocess.run(
            _resolve_cli_command(prompt, self._cfg),
            capture_output=True,
            text=True,
            input=stdin_input,
            stdin=subprocess.DEVNULL if stdin_input is None else None,
            timeout=120,
            check=False,
        )
        raw = result.stdout.strip()
        if not raw and result.stderr:
            raw = result.stderr.strip()
        if result.returncode != 0:
            raise RuntimeError(raw or f"vision cli failed with exit status {result.returncode}")
        return _parse_response(curr, raw)
