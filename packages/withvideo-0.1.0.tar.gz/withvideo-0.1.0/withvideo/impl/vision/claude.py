"""Claude vision backend — uses the `claude` CLI subprocess (Claude Code auth)."""

from __future__ import annotations

import json
import re
import subprocess
import textwrap
from pathlib import Path

from ...config import WVConfig, _find_binary
from ...models import Frame, FrameAnalysis, Operation


class ClaudeBackend:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def analyze_frame_pair(
        self,
        prev: Frame | None,
        curr: Frame,
        context: str = "",
        domain_prompt: str = "",
        spatial_hint: str = "",
        pattern_hint: str = "",
    ) -> FrameAnalysis:
        frames_dir = curr.path.parent
        prompt = _build_prompt(prev, curr, context, domain_prompt, spatial_hint, pattern_hint)

        claude_bin = _find_binary("claude") or "claude"
        result = subprocess.run(
            [
                claude_bin,
                "--dangerously-skip-permissions",
                "--add-dir", str(frames_dir),
                "-p", prompt,
            ],
            capture_output=True,
            text=True,
            stdin=subprocess.DEVNULL,
            timeout=120,
        )
        raw = result.stdout.strip()
        if not raw and result.stderr:
            # Surface error text so pipeline can log it
            raw = result.stderr.strip()

        return _parse_response(curr, raw)


def _build_prompt(
    prev: Frame | None,
    curr: Frame,
    context: str,
    domain_prompt: str,
    spatial_hint: str,
    pattern_hint: str,
) -> str:
    lines: list[str] = []

    lines.append(
        "你是一个教程视频分析专家。分析以下屏幕截图，描述画面内容。\n"
        "如果提供了两张截图，请重点描述两者之间的变化——即讲师做了什么操作。"
    )
    if domain_prompt:
        lines.append(domain_prompt)

    if spatial_hint:
        lines.append(f"⚡ 运动矢量检测到的变化区域：{spatial_hint}\n请重点关注这些区域的内容变化。")

    if pattern_hint:
        lines.append(f"📊 检测到的操作模式：{pattern_hint}\n这有助于判断操作类型。")

    if context.strip():
        lines.append(f"这段时间的旁白：{context}")
    else:
        lines.append("⚠️ 这段时间没有旁白（静默操作），请仔细观察画面变化。")

    if prev and prev.path.exists():
        lines.append(f"请先阅读上一帧截图文件：{prev.path}\n（这是 t={prev.timestamp:.1f}s 的帧，{prev.extraction_reason}）")

    if curr.path.exists():
        lines.append(f"请阅读当前帧截图文件：{curr.path}\n（这是 t={curr.timestamp:.1f}s 的帧，{curr.extraction_reason}）")

    lines.append(textwrap.dedent("""\
        请用以下 JSON 格式输出分析结果（只输出 JSON，不要其他文字）：
        {
          "description": "画面整体描述",
          "app_visible": "当前可见的应用",
          "code_state": "writing|scrolling|showing_result|showing_error|no_code",
          "code_snapshot": "屏幕上可见的代码/命令/文本内容（逐字抄录，保持格式和缩进）",
          "content_snapshot": "屏幕上可见的关键文字内容（文档文本、配置内容、网页正文等），尽可能逐字抄录",
          "changes_from_previous": "与上一帧相比的变化",
          "operations_detected": [
            {"type": "shell", "description": "运行命令", "payload": {"command": "npm install next"}},
            {"type": "code_edit", "description": "编辑文件", "payload": {"content": "代码内容", "language": "python", "file": "main.py"}},
            {"type": "ui_click", "description": "点击按钮", "payload": {"target": "Run"}}
          ]
        }

        code_state 判断规则：
        - "writing": 代码正在被输入或 AI 正在生成（光标移动、新行出现）
        - "showing_result": 展示运行结果、最终代码、生成产物
        - "showing_error": 讲师明确说这是错误的/需要修改的代码
        - "scrolling": 上下滚动浏览已有代码，无新增
        - "no_code": 画面无代码相关内容

        code_snapshot 规则：
        - 逐字抄录屏幕上可见的代码/命令文本，保持原始格式和缩进
        - scrolling 时也要抄录可见部分
        - no_code 时为空字符串

        operations_detected payload 规则：
        - shell 操作: payload 必须含 {"command": "完整命令文本"}
        - code_edit 操作: payload 必须含 {"content": "代码内容", "language": "语言"}，可选 "file"
        - 屏幕上有代码但不属于任何操作时，创建 type="code_edit" 记录"""))

    return "\n\n".join(lines)


def _parse_response(frame: Frame, text: str) -> FrameAnalysis:
    text = text.strip()
    # Strip markdown code fence if present
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        text = m.group(1)
    else:
        m2 = re.search(r"\{.*\}", text, re.DOTALL)
        if m2:
            text = m2.group(0)

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return FrameAnalysis(frame=frame, description=text)

    raw_ops = data.get("operations_detected") or []
    ops = [
        Operation(
            type=o.get("type") or "ui_action",
            description=o.get("description") or "",
            payload=o.get("payload") or {},
        )
        for o in raw_ops
        if isinstance(o, dict)
    ]

    return FrameAnalysis(
        frame=frame,
        description=data.get("description") or "",
        app_visible=data.get("app_visible") or "",
        code_state=data.get("code_state") or "",
        code_snapshot=data.get("code_snapshot") or "",
        content_snapshot=data.get("content_snapshot") or "",
        changes_from_previous=data.get("changes_from_previous") or "",
        operations_detected=ops,
    )
