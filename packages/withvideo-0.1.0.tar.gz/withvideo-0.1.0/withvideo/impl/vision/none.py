"""No-op vision backend — skips visual analysis (useful for testing pipeline structure)."""

from __future__ import annotations

from ...models import Frame, FrameAnalysis


class NoVisionBackend:
    def __init__(self, cfg=None):
        pass
    def analyze_frame_pair(
        self,
        prev: Frame | None,
        curr: Frame,
        context: str = "",
        domain_prompt: str = "",
        spatial_hint: str = "",
        pattern_hint: str = "",
    ) -> FrameAnalysis:
        return FrameAnalysis(
            frame=curr,
            description="(vision analysis skipped)",
            changes_from_previous="(skipped)",
        )
