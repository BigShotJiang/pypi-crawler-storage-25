"""Ollama local vision backend (stub — requires `pip install ollama`)."""

from __future__ import annotations

from ...config import WVConfig
from ...models import Frame, FrameAnalysis


class OllamaBackend:
    def __init__(self, model: str = "llava", cfg: WVConfig | None = None):
        self._model = model
        self._cfg = cfg

    def analyze_frame_pair(
        self,
        prev: Frame | None,
        curr: Frame,
        context: str = "",
        domain_prompt: str = "",
        spatial_hint: str = "",
        pattern_hint: str = "",
    ) -> FrameAnalysis:
        try:
            import ollama
        except ImportError:
            raise ImportError("ollama package not installed. Run: pip install ollama")

        images = []
        if prev:
            images.append(str(prev.path))
        images.append(str(curr.path))

        prompt = domain_prompt + "\n"
        if spatial_hint:
            prompt += f"变化区域：{spatial_hint}\n"
        if pattern_hint:
            prompt += f"操作模式：{pattern_hint}\n"
        if context:
            prompt += f"旁白：{context}\n"
        else:
            prompt += "（无旁白，请观察画面变化）\n"
        prompt += (
            "\nOutput JSON with: description, app_visible, content_snapshot, "
            "changes_from_previous, operations_detected"
        )

        response = ollama.chat(
            model=self._model,
            messages=[{"role": "user", "content": prompt, "images": images}],
        )
        return _parse_response(curr, response.message.content)


def _parse_response(frame: Frame, text: str) -> FrameAnalysis:
    import json, re
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if m:
        try:
            data = json.loads(m.group(0))
            from ...models import Operation
            ops = [
                Operation(type=o.get("type","ui_action"), description=o.get("description",""), payload=o.get("payload",{}))
                for o in (data.get("operations_detected") or [])
            ]
            return FrameAnalysis(
                frame=frame,
                description=data.get("description",""),
                app_visible=data.get("app_visible",""),
                content_snapshot=data.get("content_snapshot",""),
                changes_from_previous=data.get("changes_from_previous",""),
                operations_detected=ops,
            )
        except Exception:
            pass
    return FrameAnalysis(frame=frame, description=text)
