"""Motion Vector based activity detector using PyAV."""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from ...config import WVConfig
from ...models import ActivityBurst, ActivityProfile, ActivitySample, BurstPattern


class MVDetector:
    """Extracts H.264/H.265 motion vectors via PyAV; falls back to SSIM if all-intra."""

    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def can_handle(self, video_path: Path) -> bool:
        return True  # Always tries; falls back internally if all-intra

    def detect(self, video_path: Path) -> ActivityProfile:
        import av  # lazy import

        mv_frames = _extract_mv_frames(video_path)

        if _is_all_intra(mv_frames):
            from .ssim import SSIMDetector
            return SSIMDetector(self._cfg).detect(video_path)

        width, height = _get_video_dimensions(video_path)
        profile = _compute_activity_profile(mv_frames)
        profile.bursts = _detect_bursts(profile)

        for burst in profile.bursts:
            burst.pattern = _classify_pattern(burst, mv_frames, width, height)
            burst.heatmap = _compute_spatial_heatmap(mv_frames, burst, width, height)

        return profile


# ---------------------------------------------------------------------------
# MV extraction
# ---------------------------------------------------------------------------

def _extract_mv_frames(video_path: Path) -> list[dict]:
    """Returns list of {pts, vectors: ndarray} dicts."""
    import av
    frames = []
    try:
        container = av.open(str(video_path))
        stream = container.streams.video[0]
        stream.codec_context.export_side_data = True

        for i, frame in enumerate(container.decode(stream)):
            pts = float(frame.pts * stream.time_base) if frame.pts is not None else i / 25.0
            mvs = frame.side_data.get("MOTION_VECTORS")
            vectors = mvs if mvs is not None else np.array([], dtype=[
                ("source", "i1"), ("w", "i2"), ("h", "i2"),
                ("src_x", "i2"), ("src_y", "i2"),
                ("dst_x", "i2"), ("dst_y", "i2"),
                ("motion_x", "i4"), ("motion_y", "i4"), ("flags", "u4"),
            ])
            frames.append({"pts": pts, "vectors": vectors})

        container.close()
    except Exception as e:
        # If PyAV fails entirely, return empty list → triggers SSIM fallback
        pass
    return frames


def _is_all_intra(mv_frames: list[dict]) -> bool:
    if not mv_frames:
        return True
    total = sum(len(f["vectors"]) for f in mv_frames)
    avg = total / len(mv_frames)
    return avg < 5


def _get_video_dimensions(video_path: Path) -> tuple[int, int]:
    import av
    try:
        container = av.open(str(video_path))
        stream = container.streams.video[0]
        w = stream.codec_context.width
        h = stream.codec_context.height
        container.close()
        return w or 1920, h or 1080
    except Exception:
        return 1920, 1080


# ---------------------------------------------------------------------------
# Activity profile
# ---------------------------------------------------------------------------

def _compute_activity_profile(mv_frames: list[dict]) -> ActivityProfile:
    if not mv_frames:
        return ActivityProfile(per_second=[], threshold=0.0, bursts=[])

    # Per-frame score = sum of MV magnitudes
    per_frame: list[tuple[float, float]] = []
    for f in mv_frames:
        vecs = f["vectors"]
        if len(vecs) > 0:
            mx = vecs["motion_x"].astype(float)
            my = vecs["motion_y"].astype(float)
            score = float(np.sum(np.sqrt(mx**2 + my**2)))
        else:
            score = 0.0
        per_frame.append((f["pts"], score))

    # Aggregate into 1-second buckets using median
    max_time = per_frame[-1][0] if per_frame else 0
    per_second: list[ActivitySample] = []
    for t in range(int(max_time) + 1):
        bucket = [s for ts, s in per_frame if t <= ts < t + 1]
        score = float(np.median(bucket)) if bucket else 0.0
        per_second.append(ActivitySample(time=float(t), score=score))

    scores = [s.score for s in per_second]
    if not scores:
        return ActivityProfile(per_second=per_second, threshold=0.0, bursts=[])

    noise_floor = float(np.percentile(scores, 25))
    threshold = max(noise_floor * 3, float(np.percentile(scores, 60)))

    return ActivityProfile(per_second=per_second, threshold=threshold, bursts=[])


# ---------------------------------------------------------------------------
# Burst detection
# ---------------------------------------------------------------------------

def _detect_bursts(profile: ActivityProfile) -> list[ActivityBurst]:
    samples = profile.per_second
    threshold = profile.threshold
    if not samples:
        return []

    # Find contiguous runs above threshold
    runs: list[tuple[float, float]] = []
    in_run = False
    run_start = 0.0
    for s in samples:
        if s.score > threshold:
            if not in_run:
                run_start = s.time
                in_run = True
        else:
            if in_run:
                runs.append((run_start, s.time))
                in_run = False
    if in_run:
        runs.append((run_start, samples[-1].time + 1))

    # Merge runs with gap < 0.5s
    merged: list[tuple[float, float]] = []
    for start, end in runs:
        if merged and start - merged[-1][1] < 0.5:
            merged[-1] = (merged[-1][0], end)
        else:
            merged.append((start, end))

    bursts: list[ActivityBurst] = []
    for start, end in merged:
        duration = end - start
        if duration < 0.3:
            continue

        window = [s for s in samples if start <= s.time < end]
        if not window:
            continue
        peak = max(window, key=lambda s: s.score)

        bursts.append(ActivityBurst(
            start=start,
            end=end,
            peak_time=peak.time,
            peak_score=peak.score,
            duration=duration,
        ))

    return bursts


# ---------------------------------------------------------------------------
# Pattern classification
# ---------------------------------------------------------------------------

def _classify_pattern(
    burst: ActivityBurst, mv_frames: list[dict], width: int, height: int
) -> BurstPattern:
    relevant = [f for f in mv_frames if burst.start <= f["pts"] < burst.end]
    if not relevant:
        return BurstPattern.UNKNOWN

    all_vecs = [v for f in relevant for v in f["vectors"]]
    if not all_vecs:
        return BurstPattern.UNKNOWN

    # Feature 1: spatial coverage (fraction of 16×9 grid cells active)
    cell_w = max(width / 16, 1)
    cell_h = max(height / 9, 1)
    active_cells: set[tuple[int, int]] = set()
    for v in all_vecs:
        col = min(int(v["dst_x"] / cell_w), 15)
        row = min(int(v["dst_y"] / cell_h), 8)
        active_cells.add((col, row))
    coverage = len(active_cells) / (16 * 9)

    # Feature 2: direction consistency (circular variance)
    angles = []
    for v in all_vecs:
        mx, my = float(v["motion_x"]), float(v["motion_y"])
        if mx != 0 or my != 0:
            angles.append(math.atan2(my, mx))

    if angles:
        mean_cos = sum(math.cos(a) for a in angles) / len(angles)
        mean_sin = sum(math.sin(a) for a in angles) / len(angles)
        R = math.sqrt(mean_cos**2 + mean_sin**2)
        dir_consistency = 1.0 - R  # 0=consistent, 1=random
    else:
        dir_consistency = 1.0

    duration = burst.duration

    # Rules (tuned for screen recordings)
    if coverage > 0.7 and duration < 1.0:
        return BurstPattern.TAB_SWITCH
    if dir_consistency < 0.3 and coverage > 0.4:
        return BurstPattern.SCROLLING
    if coverage < 0.3 and duration > 2.0:
        return BurstPattern.TYPING
    if coverage < 0.3 and duration < 1.0:
        return BurstPattern.CLICK_MENU
    if dir_consistency < 0.5 and 0.2 < coverage < 0.6 and duration > 1.5:
        return BurstPattern.DRAG
    if 0.2 < coverage < 0.6 and duration > 2.0:
        return BurstPattern.VIEWPORT_MANIPULATION

    return BurstPattern.UNKNOWN


# ---------------------------------------------------------------------------
# Spatial heatmap
# ---------------------------------------------------------------------------

def _compute_spatial_heatmap(
    mv_frames: list[dict], burst: ActivityBurst, width: int, height: int
) -> list[list[float]]:
    grid = [[0.0] * 9 for _ in range(16)]
    cell_w = max(width / 16, 1)
    cell_h = max(height / 9, 1)

    relevant = [f for f in mv_frames if burst.start <= f["pts"] < burst.end]
    for f in relevant:
        for v in f["vectors"]:
            col = min(int(v["dst_x"] / cell_w), 15)
            row = min(int(v["dst_y"] / cell_h), 8)
            mx, my = float(v["motion_x"]), float(v["motion_y"])
            grid[col][row] += math.sqrt(mx**2 + my**2)

    max_val = max((grid[c][r] for c in range(16) for r in range(9)), default=0.0)
    if max_val > 0:
        for c in range(16):
            for r in range(9):
                grid[c][r] /= max_val

    return grid


def describe_hot_zones(heatmap: list[list[float]]) -> str:
    """Convert 16×9 heatmap to a human-readable zone description for LLM prompts."""
    zones = {
        "左上": [(c, r) for c in range(8) for r in range(4)],
        "右上": [(c, r) for c in range(8, 16) for r in range(4)],
        "左下": [(c, r) for c in range(8) for r in range(6, 9)],
        "右下": [(c, r) for c in range(8, 16) for r in range(6, 9)],
        "顶部": [(c, r) for c in range(16) for r in range(2)],
        "底部": [(c, r) for c in range(16) for r in range(7, 9)],
    }
    hot = []
    for name, cells in zones.items():
        avg = sum(heatmap[c][r] for c, r in cells) / len(cells) if cells else 0
        if avg > 0.3:
            hot.append(name)
    if not hot:
        return "变化均匀分布在屏幕各处"
    return "变化集中在：" + "、".join(hot)
