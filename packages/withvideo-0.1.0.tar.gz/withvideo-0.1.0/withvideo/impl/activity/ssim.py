"""SSIM-based activity detector — fallback for all-intra encoded videos."""

from __future__ import annotations

import json
import subprocess
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

from ...config import WVConfig, _find_binary
from ...models import ActivityBurst, ActivityProfile, ActivitySample, BurstPattern


class SSIMDetector:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def can_handle(self, video_path: Path) -> bool:
        return True  # Always available as fallback

    def detect(self, video_path: Path) -> ActivityProfile:
        duration = _probe_duration(video_path)
        fps = _sampling_fps_for_duration(duration)
        frames = _sample_frames(video_path, fps)
        if len(frames) < 2:
            return ActivityProfile(per_second=[], threshold=0.0, bursts=[], encoding_type="ALL_INTRA")

        per_second: list[ActivitySample] = []
        for i in range(1, len(frames)):
            t, img = frames[i]
            _, prev_img = frames[i - 1]
            score = _pixel_diff_score(prev_img, img)
            per_second.append(ActivitySample(time=t, score=score))

        scores = [s.score for s in per_second]
        noise_floor = float(np.percentile(scores, 25)) if scores else 0
        threshold = max(noise_floor * 3, float(np.percentile(scores, 60))) if scores else 0

        profile = ActivityProfile(
            per_second=per_second,
            threshold=threshold,
            bursts=[],
            encoding_type="ALL_INTRA",
        )

        # Re-use burst detection from mv module
        from .mv import _detect_bursts
        profile.bursts = _detect_bursts(profile)
        # SSIM produces noisier, fragmented bursts — merge close ones before classifying
        profile.bursts = _merge_adjacent_ssim_bursts(profile.bursts)
        for burst in profile.bursts:
            burst.pattern = _classify_ssim_pattern(burst, frames)

        return profile


def _probe_duration(video_path: Path) -> float:
    try:
        result = subprocess.run(
            [
                _find_binary("ffprobe") or "ffprobe",
                "-v",
                "quiet",
                "-print_format",
                "json",
                "-show_format",
                str(video_path),
            ],
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        return float(json.loads(result.stdout)["format"].get("duration", 0.0))
    except Exception:
        return 0.0


def _sampling_fps_for_duration(duration: float) -> float:
    if duration >= 60 * 60:
        return 0.5
    if duration >= 15 * 60:
        return 1.0
    return 2.0


def _sampling_timeout_for_duration(duration: float) -> int:
    if duration <= 0:
        return 120
    return max(120, min(600, int(60 + duration * 0.2)))


def _sample_frames(video_path: Path, fps: float) -> list[tuple[float, Image.Image]]:
    """Use ffmpeg to extract frames at given fps into a temp dir."""
    frames = []
    timeout = _sampling_timeout_for_duration(_probe_duration(video_path))
    with tempfile.TemporaryDirectory() as tmp:
        out_pat = Path(tmp) / "frame_%05d.png"
        try:
            subprocess.run(
                [_find_binary("ffmpeg") or "ffmpeg", "-i", str(video_path), "-vf", f"fps={fps:g}",
                 "-q:v", "5", str(out_pat), "-y"],
                capture_output=True, timeout=timeout, check=False,
            )
        except subprocess.TimeoutExpired:
            return frames
        paths = sorted(Path(tmp).glob("frame_*.png"))
        for i, p in enumerate(paths):
            t = i / fps
            frames.append((t, Image.open(p).convert("RGB")))
    return frames


def _pixel_diff_score(a: Image.Image, b: Image.Image) -> float:
    a_arr = np.asarray(a.resize((160, 90))).astype(float)
    b_arr = np.asarray(b.resize((160, 90))).astype(float)
    diff = np.abs(a_arr - b_arr).mean()
    return float(diff)


def _merge_adjacent_ssim_bursts(
    bursts: list[ActivityBurst], max_gap: float = 2.0
) -> list[ActivityBurst]:
    """Merge SSIM bursts that are close together into longer composite bursts.

    SSIM detection produces fragmented bursts for continuous activity like
    scrolling.  Merging them before classification lets the classifier see
    the true duration and coverage of the activity.
    """
    if len(bursts) <= 1:
        return bursts
    sorted_bursts = sorted(bursts, key=lambda b: b.start)
    merged: list[ActivityBurst] = []
    group = [sorted_bursts[0]]
    for b in sorted_bursts[1:]:
        if b.start - group[-1].end <= max_gap:
            group.append(b)
        else:
            merged.append(_fuse_burst_group(group))
            group = [b]
    merged.append(_fuse_burst_group(group))
    return merged


def _fuse_burst_group(group: list[ActivityBurst]) -> ActivityBurst:
    """Fuse a group of adjacent bursts into one."""
    if len(group) == 1:
        return group[0]
    peak = max(group, key=lambda b: b.peak_score)
    return ActivityBurst(
        start=group[0].start,
        end=group[-1].end,
        peak_time=peak.peak_time,
        peak_score=peak.peak_score,
        duration=group[-1].end - group[0].start,
        pattern=BurstPattern.UNKNOWN,
        heatmap=[],
    )


def _classify_ssim_pattern(
    burst: ActivityBurst, frames: list[tuple[float, Image.Image]]
) -> BurstPattern:
    """Basic pattern classification from pixel-diff spatial analysis."""
    relevant = [(t, img) for t, img in frames if burst.start <= t <= burst.end]
    if len(relevant) < 2:
        return BurstPattern.UNKNOWN

    # Compute spatial coverage: fraction of 16x9 grid cells with significant change
    active_cells: set[tuple[int, int]] = set()
    for i in range(1, len(relevant)):
        prev_arr = np.asarray(relevant[i - 1][1].resize((160, 90))).astype(float)
        curr_arr = np.asarray(relevant[i][1].resize((160, 90))).astype(float)
        diff = np.abs(prev_arr - curr_arr).mean(axis=2)  # per-pixel mean across RGB
        cell_h, cell_w = 10, 10  # 90/9=10, 160/16=10
        for r in range(9):
            for c in range(16):
                cell = diff[r * cell_h : (r + 1) * cell_h, c * cell_w : (c + 1) * cell_w]
                if cell.mean() > 15.0:
                    active_cells.add((c, r))

    coverage = len(active_cells) / (16 * 9)
    duration = burst.duration

    if coverage > 0.7 and duration < 1.0:
        return BurstPattern.TAB_SWITCH
    if coverage > 0.4 and duration > 1.5:
        return BurstPattern.SCROLLING
    if coverage < 0.3 and duration > 2.0:
        return BurstPattern.TYPING
    if coverage < 0.3 and duration < 1.0:
        return BurstPattern.CLICK_MENU
    return BurstPattern.UNKNOWN
