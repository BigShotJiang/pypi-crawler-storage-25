"""Shared helpers for Stage 0 input and site acquisition."""

from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse

from ...models import (
    Chapter,
    Platform,
    SourceMeta,
    SponsorSegment,
    SubtitleQuality,
    SubtitleTrack,
    VideoPart,
)

VIDEO_EXTENSIONS = (".mp4", ".mkv", ".webm", ".mov")
SUBTITLE_EXTENSIONS = (".srt", ".vtt", ".webvtt")


def is_url_input(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme in {"http", "https"} and bool(parsed.netloc)


def detect_platform(value: str = "", extractor_key: str = "") -> Platform:
    extractor = extractor_key.lower()
    if "youtube" in extractor:
        return Platform.YOUTUBE
    if "bilibili" in extractor:
        return Platform.BILIBILI
    if "vimeo" in extractor:
        return Platform.VIMEO
    if "twitter" in extractor or "x" == extractor:
        return Platform.TWITTER

    host = (urlparse(value).hostname or "").lower()
    if "youtube.com" in host or "youtu.be" in host:
        return Platform.YOUTUBE
    if "bilibili.com" in host or "b23.tv" in host:
        return Platform.BILIBILI
    if "vimeo.com" in host:
        return Platform.VIMEO
    if "twitter.com" in host or "x.com" in host:
        return Platform.TWITTER
    return Platform.LOCAL_FILE


def sanitise(name: str) -> str:
    name = re.sub(r'[\\/*?:"<>|()\[\]{}\s]', "_", name)
    name = re.sub(r"_+", "_", name)
    return name[:60].strip("_") or "video"


def find_downloaded_video(work_dir: Path) -> Path:
    for ext in VIDEO_EXTENSIONS:
        candidate = work_dir / f"source{ext}"
        if candidate.exists():
            return candidate

    for candidate in sorted(work_dir.iterdir()):
        if candidate.suffix.lower() in VIDEO_EXTENSIONS:
            return candidate
    raise FileNotFoundError(f"No video file found in {work_dir}")


def build_source_meta(
    info: dict,
    platform: Platform,
    video_path: Path | None,
    work_dir: Path,
) -> SourceMeta:
    meta = SourceMeta(
        input=info.get("webpage_url") or info.get("original_url") or (str(video_path) if video_path else ""),
        platform=platform,
        local_video_path=video_path,
        title=info.get("title") or (video_path.stem if video_path else "video"),
        description=info.get("description") or "",
        duration=float(info.get("duration") or 0),
        uploader=info.get("uploader") or info.get("channel") or "",
        upload_date=info.get("upload_date") or "",
    )

    if info.get("chapters"):
        meta.chapters = [
            Chapter(
                start=float(chapter.get("start_time", 0)),
                end=float(chapter.get("end_time", 0)),
                title=chapter.get("title", ""),
            )
            for chapter in info["chapters"]
        ]

    if info.get("sponsorblock_chapters"):
        meta.sponsor_segments = [
            SponsorSegment(
                start=float(segment.get("start_time", 0)),
                end=float(segment.get("end_time", 0)),
                category=segment.get("category", ""),
            )
            for segment in info["sponsorblock_chapters"]
        ]

    meta.subtitles = collect_downloaded_subtitles(
        info.get("subtitles") or {},
        work_dir,
        is_generated=False,
        source="yt-dlp",
    )
    meta.auto_captions = collect_downloaded_subtitles(
        info.get("automatic_captions") or {},
        work_dir,
        is_generated=True,
        source="yt-dlp",
        default_word_timestamps=platform == Platform.YOUTUBE,
    )
    meta.subtitle_quality = classify_subtitle_quality(
        platform,
        subtitles=meta.subtitles,
        auto_captions=meta.auto_captions,
        duration=meta.duration,
    )

    if info.get("heatmap"):
        meta.heatmap = info["heatmap"]

    if info.get("pages"):
        meta.parts = [
            VideoPart(
                index=int(page.get("page", i + 1)),
                title=page.get("part") or page.get("title") or "",
                cid=str(page.get("cid") or ""),
                duration=float(page.get("duration") or 0),
            )
            for i, page in enumerate(info["pages"])
        ]

    return meta


def collect_downloaded_subtitles(
    subs_dict: dict,
    work_dir: Path,
    *,
    is_generated: bool = False,
    source: str = "sidecar",
    default_word_timestamps: bool = False,
) -> list[SubtitleTrack]:
    tracks: list[SubtitleTrack] = []
    subtitles_dir = work_dir / "subtitles"
    for lang, formats in subs_dict.items():
        for fmt_info in formats or []:
            ext = (fmt_info.get("ext") or "vtt").lower()
            path = subtitles_dir / f"{lang}.{ext}"
            tracks.append(
                SubtitleTrack(
                    lang=lang,
                    fmt=ext,
                    path=path if path.exists() else None,
                    is_generated=is_generated,
                    has_word_timestamps=default_word_timestamps and ext in {"vtt", "webvtt", "srv3"},
                    source=source,
                )
            )
            break
    return tracks


def scan_local_subtitle_sidecars(video_path: Path) -> list[SubtitleTrack]:
    tracks: list[SubtitleTrack] = []
    seen: set[tuple[str, str, str | None]] = set()
    prefix = f"{video_path.stem}."

    for candidate in sorted(video_path.parent.iterdir()):
        if candidate == video_path or candidate.suffix.lower() not in SUBTITLE_EXTENSIONS:
            continue
        if not candidate.name.startswith(prefix):
            continue
        lang = candidate.stem[len(prefix):] or "local"
        key = (lang, candidate.suffix.lower().lstrip("."), str(candidate))
        if key in seen:
            continue
        seen.add(key)
        tracks.append(
            SubtitleTrack(
                lang=lang,
                fmt=candidate.suffix.lower().lstrip("."),
                path=candidate,
                source="sidecar",
            )
        )

    subtitles_dir = video_path.parent / "subtitles"
    if subtitles_dir.exists():
        for candidate in sorted(subtitles_dir.iterdir()):
            if candidate.suffix.lower() not in SUBTITLE_EXTENSIONS:
                continue
            lang = candidate.stem or "local"
            key = (lang, candidate.suffix.lower().lstrip("."), str(candidate))
            if key in seen:
                continue
            seen.add(key)
            tracks.append(
                SubtitleTrack(
                    lang=lang,
                    fmt=candidate.suffix.lower().lstrip("."),
                    path=candidate,
                    source="sidecar",
                )
            )

    return tracks


def merge_local_sidecars(meta: SourceMeta, video_path: Path | None) -> SourceMeta:
    if video_path is None:
        return meta

    existing_paths = {
        str(track.path)
        for track in [*meta.subtitles, *meta.auto_captions]
        if track.path is not None
    }
    subtitle_index = {
        (track.lang, track.fmt): track
        for track in meta.subtitles
    }
    auto_caption_index = {
        (track.lang, track.fmt): track
        for track in meta.auto_captions
    }
    for track in scan_local_subtitle_sidecars(video_path):
        if track.path is not None and str(track.path) in existing_paths:
            continue
        existing = subtitle_index.get((track.lang, track.fmt))
        if existing is not None and existing.path is None:
            existing.path = track.path
            if track.path is not None:
                existing_paths.add(str(track.path))
            continue
        existing_auto = auto_caption_index.get((track.lang, track.fmt))
        if existing_auto is not None and existing_auto.path is None:
            existing_auto.path = track.path
            if track.path is not None:
                existing_paths.add(str(track.path))
            continue
        meta.subtitles.append(track)
        subtitle_index[(track.lang, track.fmt)] = track
        if track.path is not None:
            existing_paths.add(str(track.path))

    meta.subtitle_quality = classify_subtitle_quality(
        meta.platform,
        subtitles=meta.subtitles,
        auto_captions=meta.auto_captions,
        duration=meta.duration,
    )
    return meta


def has_usable_tracks(tracks: list[SubtitleTrack]) -> bool:
    return any(track.path and track.path.exists() for track in tracks)


def classify_subtitle_quality(
    platform: Platform,
    subtitles: list[SubtitleTrack],
    auto_captions: list[SubtitleTrack],
    duration: float = 0.0,
) -> SubtitleQuality:
    usable_manual = has_usable_tracks(subtitles)
    usable_auto = has_usable_tracks(auto_captions)

    if platform == Platform.YOUTUBE:
        if any(track.has_word_timestamps for track in auto_captions if track.path and track.path.exists()):
            return SubtitleQuality.WORD_LEVEL
        if usable_manual or usable_auto:
            return SubtitleQuality.SENTENCE_LEVEL
        return SubtitleQuality.NONE

    if platform == Platform.BILIBILI:
        best_track = _pick_best_bilibili_track(subtitles, auto_captions)
        if best_track is not None and _is_reliable_bilibili_subtitle(best_track, duration):
            return SubtitleQuality.SENTENCE_LEVEL
        if usable_manual or usable_auto:
            return SubtitleQuality.UNRELIABLE
        return SubtitleQuality.NONE

    if usable_manual or usable_auto:
        return SubtitleQuality.SENTENCE_LEVEL
    return SubtitleQuality.NONE


def _pick_best_bilibili_track(
    subtitles: list[SubtitleTrack],
    auto_captions: list[SubtitleTrack],
) -> SubtitleTrack | None:
    usable_tracks = [
        track
        for track in [*subtitles, *auto_captions]
        if track.path and track.path.exists()
    ]
    if not usable_tracks:
        return None
    return max(
        usable_tracks,
        key=lambda track: (
            1 if track.source == "yt-dlp" else 0,
            1 if not _looks_like_ai_subtitle(track) else 0,
            1 if track.fmt in {"srt", "vtt", "webvtt"} else 0,
        ),
    )


def _looks_like_ai_subtitle(track: SubtitleTrack) -> bool:
    lang = (track.lang or "").lower()
    path_name = (track.path.name.lower() if track.path else "")
    return track.is_generated or lang.startswith("ai-") or ".ai-" in path_name


def _is_reliable_bilibili_subtitle(track: SubtitleTrack, duration: float) -> bool:
    if track.path is None or not track.path.exists():
        return False

    segments = _parse_subtitle_segments(track.path, track.fmt)
    if not segments:
        return False

    text_lengths = [_visible_text_length(text) for _, _, text in segments]
    nonempty_lengths = [length for length in text_lengths if length > 0]
    if not nonempty_lengths:
        return False

    segment_count = len(nonempty_lengths)
    total_chars = sum(nonempty_lengths)
    avg_chars = total_chars / segment_count
    covered_duration = sum(max(end - start, 0.0) for start, end, _ in segments)

    max_gap = 0.0
    previous_end = 0.0
    for start, end, _ in sorted(segments, key=lambda item: item[0]):
        if start > previous_end:
            max_gap = max(max_gap, start - previous_end)
        previous_end = max(previous_end, end)
    if duration > 0:
        max_gap = max(max_gap, max(duration - previous_end, 0.0))

    if duration <= 0:
        return segment_count >= 3 and total_chars >= 24 and avg_chars >= 6

    coverage_ratio = covered_duration / duration if duration > 0 else 0.0
    gap_limit = max(8.0, duration * 0.2)
    min_coverage = 0.4 if not _looks_like_ai_subtitle(track) else 0.55

    if total_chars < 16 or avg_chars < 4:
        return False
    if max_gap > gap_limit:
        return False
    if coverage_ratio >= min_coverage and segment_count >= 3:
        return True
    return coverage_ratio >= 0.8 and segment_count >= 2 and total_chars >= 24


def _parse_subtitle_segments(path: Path, fmt: str) -> list[tuple[float, float, str]]:
    suffix = fmt.lower()
    if suffix in {"vtt", "webvtt"}:
        return _parse_vtt_segments(path)
    if suffix == "srt":
        return _parse_srt_segments(path)
    return []


_HTML_TAG = re.compile(r"<[^>]+>")
_SRT_TS = re.compile(
    r"(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})"
)
_VTT_TS = re.compile(
    r"(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})"
)


def _parse_srt_segments(path: Path) -> list[tuple[float, float, str]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks = re.split(r"\n\n+", text.strip())
    segments: list[tuple[float, float, str]] = []
    for block in blocks:
        lines = block.strip().splitlines()
        match = next((_SRT_TS.match(line) for line in lines if _SRT_TS.match(line)), None)
        if not match:
            continue
        start = _ts(*match.groups()[:4])
        end = _ts(*match.groups()[4:])
        text_lines = [line for line in lines if not _SRT_TS.match(line) and not line.strip().isdigit()]
        clean = _HTML_TAG.sub("", " ".join(text_lines)).strip()
        if clean:
            segments.append((start, end, clean))
    return segments


def _parse_vtt_segments(path: Path) -> list[tuple[float, float, str]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    segments: list[tuple[float, float, str]] = []
    index = 0
    while index < len(lines):
        match = _VTT_TS.match(lines[index])
        if not match:
            index += 1
            continue
        start = _ts(*match.groups()[:4])
        end = _ts(*match.groups()[4:])
        index += 1
        body_lines: list[str] = []
        while index < len(lines) and lines[index].strip():
            body_lines.append(lines[index])
            index += 1
        clean = _HTML_TAG.sub("", " ".join(body_lines)).strip()
        if clean:
            segments.append((start, end, clean))
    return segments


def _ts(h: str, m: str, s: str, ms: str) -> float:
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000


def _visible_text_length(text: str) -> int:
    return len(re.sub(r"\s+", "", text))
