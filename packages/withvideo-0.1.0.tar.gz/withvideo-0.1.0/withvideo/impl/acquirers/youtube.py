"""YouTube-specific acquisition and transcript fallback."""

from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from ...models import Platform, SourceMeta, SubtitleQuality, SubtitleTrack
from .common import build_source_meta, classify_subtitle_quality, has_usable_tracks
from .generic_url import BaseYtdlpAcquirer, _load_yt_dlp

try:
    from youtube_transcript_api import YouTubeTranscriptApi
except ImportError:  # pragma: no cover - exercised through runtime fallback behavior
    YouTubeTranscriptApi = None


_YOUTUBE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{11}$")


class YouTubeAcquirer(BaseYtdlpAcquirer):
    platform = Platform.YOUTUBE

    def _extract_info(
        self,
        input_str: str,
        platform: Platform,
        work_dir: Path,
        opts: dict,
    ) -> dict:
        yt_dlp = _load_yt_dlp()

        probe_opts = self._build_opts(platform, work_dir, {**opts, "skip_subtitles": True})
        probe_opts["skip_download"] = True
        with yt_dlp.YoutubeDL(probe_opts) as ydl:
            info = ydl.extract_info(input_str, download=False)
            if "entries" in info:
                info = info["entries"][0]

        local_opts = dict(opts)
        preferred_langs = _preferred_youtube_subtitle_langs(info)
        if preferred_langs:
            local_opts["subtitleslangs"] = preferred_langs

        with yt_dlp.YoutubeDL(self._build_opts(platform, work_dir, local_opts)) as ydl:
            info = ydl.extract_info(input_str, download=True)
            if "entries" in info:
                info = info["entries"][0]
            return info

    def _build_youtube_meta(self, info: dict, work_dir: Path, video_path: Path) -> SourceMeta:
        return build_source_meta(info, self.platform, video_path, work_dir)

    def _enrich_meta(
        self,
        input_str: str,
        info: dict,
        work_dir: Path,
        meta: SourceMeta,
    ) -> None:
        if has_usable_tracks(meta.subtitles) or has_usable_tracks(meta.auto_captions):
            return

        if YouTubeTranscriptApi is None:
            print(
                "[wv] YouTube 平台字幕兜底需要可选依赖 'youtube-transcript-api'。"
                " 可安装 `uv sync --extra youtube`。"
            )
            return

        video_id = _extract_youtube_video_id(meta.input, info)
        if not video_id:
            return

        try:
            transcript_list = YouTubeTranscriptApi().list(video_id)
            transcript = _pick_transcript(transcript_list)
        except ImportError:
            print(
                "[wv] YouTube 平台字幕兜底需要可选依赖 'youtube-transcript-api'。"
                " 可安装 `uv sync --extra youtube`。"
            )
            return
        except Exception:
            return

        if transcript is None:
            return

        track = _materialize_transcript_track(transcript, work_dir)
        if track is None:
            return

        if track.is_generated:
            meta.auto_captions.append(track)
        else:
            meta.subtitles.append(track)
        meta.subtitle_quality = classify_subtitle_quality(
            meta.platform,
            subtitles=meta.subtitles,
            auto_captions=meta.auto_captions,
            duration=meta.duration,
        )


def _extract_youtube_video_id(input_str: str, info: dict) -> str:
    for candidate in (info.get("id"), info.get("webpage_url"), info.get("original_url"), input_str):
        if not candidate:
            continue
        text = str(candidate)
        if _YOUTUBE_ID_RE.match(text):
            return text
        parsed = urlparse(text)
        host = (parsed.hostname or "").lower()
        if host.endswith("youtu.be"):
            video_id = parsed.path.strip("/").split("/")[0]
            if _YOUTUBE_ID_RE.match(video_id):
                return video_id
        if "youtube.com" in host:
            values = parse_qs(parsed.query).get("v", [])
            if values and _YOUTUBE_ID_RE.match(values[0]):
                return values[0]
            shorts = parsed.path.strip("/").split("/")
            if len(shorts) >= 2 and shorts[0] in {"shorts", "embed", "live"} and _YOUTUBE_ID_RE.match(shorts[1]):
                return shorts[1]
    return ""


def _pick_transcript(transcript_list) -> object | None:
    language_codes: list[str] = []
    try:
        for transcript in transcript_list:
            code = getattr(transcript, "language_code", None)
            if code and code not in language_codes:
                language_codes.append(code)
    except TypeError:
        pass
    if not language_codes:
        language_codes = ["en"]

    for method_name in ("find_manually_created_transcript", "find_generated_transcript"):
        method = getattr(transcript_list, method_name, None)
        if method is None:
            continue
        try:
            return method(language_codes)
        except Exception:
            continue
    return None


def _preferred_youtube_subtitle_langs(info: dict) -> list[str]:
    available = set((info.get("subtitles") or {}).keys()) | set((info.get("automatic_captions") or {}).keys())
    if not available:
        return []

    language = info.get("language")
    preferred: list[str] = []
    if language:
        for candidate in (f"{language}-orig", language):
            if candidate in available and candidate not in preferred:
                preferred.append(candidate)

    if preferred:
        return preferred

    orig_candidates = sorted(lang for lang in available if lang.endswith("-orig"))
    if orig_candidates:
        return orig_candidates[:1]

    return []


def _materialize_transcript_track(transcript, work_dir: Path) -> SubtitleTrack | None:
    try:
        fetched = transcript.fetch()
    except Exception:
        return None
    entries = list(fetched)
    if not entries:
        return None

    language_code = getattr(transcript, "language_code", None) or getattr(fetched, "language_code", None) or "en"
    language = getattr(transcript, "language", None) or getattr(fetched, "language", None) or language_code
    is_generated = bool(
        getattr(transcript, "is_generated", None)
        if getattr(transcript, "is_generated", None) is not None
        else getattr(fetched, "is_generated", False)
    )

    subtitles_dir = work_dir / "subtitles"
    subtitles_dir.mkdir(parents=True, exist_ok=True)
    subtitle_path = subtitles_dir / f"{language_code}.srt"
    subtitle_path.write_text(_render_srt(entries), encoding="utf-8")

    return SubtitleTrack(
        lang=language_code,
        fmt="srt",
        path=subtitle_path,
        is_generated=is_generated,
        has_word_timestamps=False,
        source="youtube-transcript-api",
    )


def _render_srt(entries: list[dict]) -> str:
    blocks: list[str] = []
    for index, item in enumerate(entries, start=1):
        start = float(_snippet_value(item, "start", 0.0))
        duration = float(_snippet_value(item, "duration", 0.0))
        end = start + max(duration, 0.0)
        text = str(_snippet_value(item, "text", "")).strip()
        if not text:
            continue
        blocks.append(
            "\n".join(
                [
                    str(index),
                    f"{_fmt_srt_time(start)} --> {_fmt_srt_time(end)}",
                    text,
                ]
            )
        )
    return "\n\n".join(blocks) + ("\n" if blocks else "")


def _snippet_value(item, name: str, default):
    if hasattr(item, name):
        return getattr(item, name)
    if isinstance(item, dict):
        return item.get(name, default)
    return default


def _fmt_srt_time(seconds: float) -> str:
    total_ms = max(0, int(round(seconds * 1000)))
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    secs, ms = divmod(rem, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{ms:03d}"
