"""Input dispatcher for local files and site-specific URL acquisition."""

from __future__ import annotations

from pathlib import Path

from ...config import WVConfig
from ...models import Platform
from .bilibili import BilibiliAcquirer
from .common import detect_platform, is_url_input
from .generic_url import GenericUrlAcquirer
from .local_file import LocalFileAcquirer
from .youtube import YouTubeAcquirer


class AutoInputAcquirer:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()
        self._local = LocalFileAcquirer(self._cfg)
        self._bilibili = BilibiliAcquirer(self._cfg)
        self._youtube = YouTubeAcquirer(self._cfg)
        self._generic = GenericUrlAcquirer(self._cfg)

    def acquire(self, input_str: str, work_dir: Path, opts: dict) -> tuple[object, str, object]:
        input_path = Path(input_str).expanduser()
        if input_path.exists() or (not is_url_input(input_str) and bool(input_path.suffix)):
            return self._local.acquire(input_str, work_dir, opts)

        if not is_url_input(input_str):
            raise FileNotFoundError(f"Input is neither an existing file nor a supported URL: {input_str}")

        platform = detect_platform(input_str)
        if self._cfg.media_access == "remote" and platform != Platform.BILIBILI:
            raise NotImplementedError(
                "Remote media access is currently only supported for Bilibili URLs."
            )
        if platform == Platform.BILIBILI:
            return self._bilibili.acquire(input_str, work_dir, opts)
        if platform == Platform.YOUTUBE:
            return self._youtube.acquire(input_str, work_dir, opts)
        return self._generic.acquire(input_str, work_dir, opts)
