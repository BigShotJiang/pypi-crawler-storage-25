"""Shared yt-dlp powered URL acquisition."""

from __future__ import annotations

from pathlib import Path

from ...config import WVConfig, _find_binary
from ...models import LocalMediaHandle, Platform, SourceMeta
from .common import build_source_meta, detect_platform, find_downloaded_video, merge_local_sidecars, sanitise


class BaseYtdlpAcquirer:
    platform: Platform | None = None

    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def acquire(
        self, input_str: str, work_dir: Path, opts: dict
    ) -> tuple[LocalMediaHandle, str, SourceMeta]:
        platform = self.platform or detect_platform(input_str)
        if self._cfg.media_access == "remote":
            raise NotImplementedError(_remote_media_download_disabled_message(platform))
        work_dir.mkdir(parents=True, exist_ok=True)
        (work_dir / "subtitles").mkdir(exist_ok=True)

        info = self._extract_info(input_str, platform, work_dir, opts)

        video_path = find_downloaded_video(work_dir)
        video_name = sanitise(info.get("title") or info.get("id") or "video")
        meta = build_source_meta(info, platform, video_path, work_dir)
        merge_local_sidecars(meta, video_path)
        self._enrich_meta(input_str, info, work_dir, meta)
        merge_local_sidecars(meta, video_path)
        return LocalMediaHandle(path=video_path), video_name, meta

    def _extract_info(
        self,
        input_str: str,
        platform: Platform,
        work_dir: Path,
        opts: dict,
    ) -> dict:
        yt_dlp = _load_yt_dlp()
        with yt_dlp.YoutubeDL(self._build_opts(platform, work_dir, opts)) as ydl:
            info = ydl.extract_info(input_str, download=True)
            if "entries" in info:
                info = info["entries"][0]
            return info

    def _build_opts(self, platform: Platform, work_dir: Path, opts: dict) -> dict:
        cfg = self._cfg
        ydl_opts: dict = {
            "outtmpl": str(work_dir / "source.%(ext)s"),
            "writeinfojson": True,
            "merge_output_format": "mp4",
            "quiet": not cfg.verbose,
            "no_warnings": not cfg.verbose,
            "writesubtitles": not opts.get("skip_subtitles", False),
            "writeautomaticsub": not opts.get("skip_subtitles", False),
            "subtitleslangs": opts.get("subtitleslangs", ["all"]),
            "subtitlesformat": "vtt/srt/best",
            "outtmpl_subtitles": str(work_dir / "subtitles" / "%(lang)s.%(ext)s"),
        }

        # Ensure yt-dlp can find ffmpeg in restricted PATH environments
        # (e.g. Claude Code desktop where PATH is /usr/bin:/bin only).
        ffmpeg_path = _find_binary("ffmpeg")
        if ffmpeg_path:
            ydl_opts["ffmpeg_location"] = str(Path(ffmpeg_path).parent)

        if platform == Platform.YOUTUBE:
            ydl_opts["format"] = (
                "bestvideo[height<=1080][vcodec^=avc1]+bestaudio"
                "/bestvideo[height<=1080]+bestaudio"
                "/best[height<=1080]"
            )
            ydl_opts["sponsorblock_mark"] = "all"
        elif platform == Platform.BILIBILI:
            # Bilibili serves DASH (video-only + audio-only), no combined streams.
            # Prefer 720p+ for frame extraction quality; fall back gracefully.
            ydl_opts["format"] = (
                "bestvideo[height>=720][height<=1080]+bestaudio"
                "/bestvideo[height>=720]+bestaudio"
                "/bestvideo[height<=1080]+bestaudio"
                "/bestvideo+bestaudio"
                "/best"
            )
        else:
            ydl_opts["format"] = "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best"

        if opts.get("cookiefile"):
            ydl_opts["cookiefile"] = opts["cookiefile"]
        elif cfg.cookies:
            ydl_opts["cookiefile"] = cfg.cookies
        elif cfg.cookies_from_browser and not opts.get("suppress_browser_cookies"):
            ydl_opts["cookiesfrombrowser"] = (cfg.cookies_from_browser,)

        return ydl_opts

    def _enrich_meta(
        self,
        input_str: str,
        info: dict,
        work_dir: Path,
        meta: SourceMeta,
    ) -> None:
        return None


class GenericUrlAcquirer(BaseYtdlpAcquirer):
    """Fallback URL acquirer for sites without a dedicated adapter."""


def _remote_media_download_disabled_message(platform: Platform) -> str:
    return (
        "Remote media access forbids downloading video files for URL inputs. "
        f"The current URL would fall back to a download-based acquirer (detected platform: {platform.value}). "
        "Use `--media-access download`, switch to a local video file, or use a platform with a true remote adapter."
    )


def _load_yt_dlp():
    import yt_dlp

    return yt_dlp
