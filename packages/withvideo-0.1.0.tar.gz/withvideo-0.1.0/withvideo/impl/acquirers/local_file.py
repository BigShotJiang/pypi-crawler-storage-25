"""Local file acquirer — wraps an existing video file."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

from ...config import WVConfig, _find_binary
from ...models import LocalMediaHandle, Platform, SourceMeta, SubtitleQuality
from .common import build_source_meta, detect_platform, merge_local_sidecars


def _sanitise(name: str) -> str:
    name = re.sub(r'[\\/*?:"<>|]', "_", name)
    return name[:80].strip(" ._") or "video"


class LocalFileAcquirer:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def acquire(
        self, input_str: str, work_dir: Path, opts: dict
    ) -> tuple[LocalMediaHandle, str, SourceMeta]:
        video_path = Path(input_str).expanduser().resolve()
        if not video_path.exists():
            raise FileNotFoundError(f"Video file not found: {video_path}")

        video_name = _sanitise(video_path.stem)

        # Check for companion info.json (from a prior yt-dlp download)
        info_json = video_path.with_suffix(".info.json")
        if info_json.exists():
            with info_json.open(encoding="utf-8") as f:
                info = json.load(f)
            platform = detect_platform(
                info.get("webpage_url") or info.get("original_url") or "",
                info.get("extractor_key") or "",
            )
            meta = build_source_meta(info, platform, video_path, video_path.parent)
            meta.input = str(video_path)
        else:
            info = {}
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.LOCAL_FILE,
                local_video_path=video_path,
                title=video_name,
                description="",
                duration=_probe_duration(video_path),
                uploader="",
                upload_date="",
                subtitle_quality=SubtitleQuality.NONE,
            )

        merge_local_sidecars(meta, video_path)
        if not meta.duration:
            meta.duration = _probe_duration(video_path)

        return LocalMediaHandle(path=video_path), video_name, meta


def _probe_duration(video_path: Path) -> float:
    try:
        result = subprocess.run(
            [
                _find_binary("ffprobe") or "ffprobe", "-v", "quiet", "-print_format", "json",
                "-show_format", str(video_path),
            ],
            capture_output=True, text=True, timeout=30,
        )
        data = json.loads(result.stdout)
        return float(data["format"].get("duration", 0))
    except Exception:
        return 0.0
