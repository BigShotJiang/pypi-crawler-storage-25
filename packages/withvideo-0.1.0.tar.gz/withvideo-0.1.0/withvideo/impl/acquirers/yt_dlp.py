"""Backward-compatible alias for the generic yt-dlp URL acquirer."""

from __future__ import annotations

from .generic_url import GenericUrlAcquirer as YtdlpAcquirer
