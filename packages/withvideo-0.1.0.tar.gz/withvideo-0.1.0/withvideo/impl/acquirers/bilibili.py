"""Bilibili-specific acquisition and enrichment."""

from __future__ import annotations

import asyncio
import json
import re
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from ...models import DanmakuItem, Platform, RemoteMediaHandle, SourceMeta, SubtitleQuality, SubtitleTrack
from .auth import BilibiliAuthManager, build_cookie_header, is_auth_failure, load_site_cookies
from .common import build_source_meta, classify_subtitle_quality, has_usable_tracks, sanitise
from .generic_url import BaseYtdlpAcquirer


_BVID_RE = re.compile(r"(BV[0-9A-Za-z]+)")
_BILIBILI_DOMAIN = "bilibili.com"
_DEFAULT_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/135.0.0.0 Safari/537.36"
)


class BilibiliAcquirer(BaseYtdlpAcquirer):
    platform = Platform.BILIBILI

    def acquire(
        self, input_str: str, work_dir: Path, opts: dict
    ) -> tuple[object, str, SourceMeta]:
        auth = BilibiliAuthManager(self._cfg, work_dir.parent)
        local_opts = dict(opts)
        # Bilibili subtitles and danmaku are fetched via _enrich_meta;
        # skip yt-dlp subtitle download to avoid 403 errors on danmaku URLs.
        local_opts["skip_subtitles"] = True
        cookiefile = auth.resolve_cookiefile()
        if cookiefile:
            local_opts["cookiefile"] = str(cookiefile)
            local_opts["suppress_browser_cookies"] = True

        try:
            if self._cfg.media_access == "remote":
                return self._acquire_remote(input_str, work_dir, local_opts)
            return super().acquire(input_str, work_dir, local_opts)
        except Exception as exc:
            if not cookiefile or not auth.can_refresh() or not is_auth_failure(exc):
                raise

            refreshed_cookiefile = auth.refresh_cookiefile()
            if not refreshed_cookiefile:
                raise

            local_opts["cookiefile"] = str(refreshed_cookiefile)
            local_opts["suppress_browser_cookies"] = True
            if self._cfg.media_access == "remote":
                return self._acquire_remote(input_str, work_dir, local_opts)
            return super().acquire(input_str, work_dir, local_opts)

    def _acquire_remote(
        self,
        input_str: str,
        work_dir: Path,
        opts: dict,
    ) -> tuple[RemoteMediaHandle, str, SourceMeta]:
        work_dir.mkdir(parents=True, exist_ok=True)
        (work_dir / "subtitles").mkdir(exist_ok=True)

        bvid = _extract_bvid(input_str, {})
        if not bvid:
            raise RuntimeError(f"Could not extract Bilibili BV id from URL: {input_str}")

        ass, video, Credential = _load_bilibili_api()
        cookiefile = Path(opts["cookiefile"]).expanduser() if opts.get("cookiefile") else None
        credential = _build_bilibili_credential(Credential, cookiefile)
        page_index = _extract_page_index(input_str)

        video_obj = video.Video(bvid=bvid, credential=credential)
        info = asyncio.run(video_obj.get_info())
        pages = asyncio.run(video_obj.get_pages())
        if pages:
            info["pages"] = pages

        cid = _pick_cid(info, page_index)
        download_data = asyncio.run(
            video_obj.get_download_url(page_index=page_index, cid=cid, html5=True)
        )
        stream_url = _pick_remote_stream_url(video, download_data)

        (work_dir / "source.info.json").write_text(
            json.dumps(info, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        meta = build_source_meta(info, self.platform, None, work_dir)
        meta.input = input_str
        meta.duration = _pick_duration(info, page_index) or meta.duration
        self._enrich_meta(
            input_str,
            info,
            work_dir,
            meta,
            page_index=page_index,
            cid=cid,
            credential=credential,
            video_obj=video_obj,
            cookiefile=cookiefile,
        )

        media = RemoteMediaHandle(
            video_url=stream_url,
            headers=_build_remote_headers(input_str, cookiefile),
            duration=meta.duration,
            platform=self.platform,
        )
        video_name = sanitise(info.get("title") or info.get("id") or bvid or "video")
        return media, video_name, meta

    def _enrich_meta(
        self,
        input_str: str,
        info: dict,
        work_dir: Path,
        meta: SourceMeta,
        *,
        page_index: int = 0,
        cid: int | None = None,
        credential=None,
        video_obj=None,
        cookiefile: Path | None = None,
    ) -> None:
        if not has_usable_tracks(meta.subtitles):
            track = _fetch_remote_bilibili_subtitle(
                input_str,
                info,
                work_dir,
                page_index=page_index,
                cid=cid,
                credential=credential,
                video_obj=video_obj,
                cookiefile=cookiefile,
            )
            if track is not None:
                meta.subtitles.append(track)
                meta.subtitle_quality = classify_subtitle_quality(
                    meta.platform,
                    subtitles=meta.subtitles,
                    auto_captions=meta.auto_captions,
                    duration=meta.duration,
                )

        if not meta.danmaku:
            cid = _extract_cid(info, meta)
            if cid:
                meta.danmaku = _fetch_danmaku(cid)


def _extract_cid(info: dict, meta: SourceMeta) -> str:
    if info.get("cid"):
        return str(info["cid"])
    for part in meta.parts:
        if part.cid:
            return part.cid
    return ""


def _extract_bvid(input_str: str, info: dict) -> str:
    for candidate in (info.get("id"), info.get("webpage_url"), input_str):
        if not candidate:
            continue
        match = _BVID_RE.search(str(candidate))
        if match:
            return match.group(1)
    return ""


def _extract_page_index(input_str: str) -> int:
    try:
        parsed = urlparse(input_str)
        raw = parse_qs(parsed.query).get("p", ["1"])[0]
        return max(0, int(raw) - 1)
    except Exception:
        return 0


def _pick_cid(info: dict, page_index: int) -> int:
    pages = info.get("pages") or []
    if not pages:
        cid = info.get("cid")
        if cid is None:
            raise RuntimeError("Could not resolve Bilibili cid for remote extraction.")
        return int(cid)
    if page_index >= len(pages):
        raise RuntimeError(f"Bilibili page index {page_index} is out of range.")
    cid = pages[page_index].get("cid")
    if cid is None:
        raise RuntimeError("Bilibili page metadata did not include a cid.")
    return int(cid)


def _pick_duration(info: dict, page_index: int) -> float:
    pages = info.get("pages") or []
    if pages and 0 <= page_index < len(pages):
        return float(pages[page_index].get("duration") or 0.0)
    return float(info.get("duration") or 0.0)


def _build_bilibili_credential(Credential, cookiefile: Path | None):
    cookies = load_site_cookies(cookiefile, _BILIBILI_DOMAIN)
    if not cookies:
        return None

    kwargs = {
        "sessdata": cookies.get("SESSDATA"),
        "bili_jct": cookies.get("bili_jct"),
        "buvid3": cookies.get("buvid3"),
        "buvid4": cookies.get("buvid4"),
        "dedeuserid": cookies.get("DedeUserID"),
        "ac_time_value": cookies.get("ac_time_value"),
    }
    kwargs = {key: value for key, value in kwargs.items() if value}
    return Credential(**kwargs) if kwargs else None


def _build_remote_headers(input_str: str, cookiefile: Path | None) -> dict[str, str]:
    headers = {
        "Referer": input_str,
        "User-Agent": _DEFAULT_UA,
    }
    cookie_header = build_cookie_header(cookiefile, _BILIBILI_DOMAIN)
    if cookie_header:
        headers["Cookie"] = cookie_header
    return headers


def _pick_remote_stream_url(video_module, download_data: dict) -> str:
    detector = getattr(video_module, "VideoDownloadURLDataDetecter", None)
    if detector is not None:
        try:
            for stream in detector(download_data).detect_best_streams():
                url = getattr(stream, "url", None)
                if url:
                    return url
        except Exception:
            pass

    for item in download_data.get("durl") or []:
        if item.get("url"):
            return item["url"]

    raise RuntimeError("Could not resolve a playable Bilibili HTML5 MP4 stream URL.")


def _fetch_remote_bilibili_subtitle(
    input_str: str,
    info: dict,
    work_dir: Path,
    *,
    page_index: int = 0,
    cid: int | None = None,
    credential=None,
    video_obj=None,
    cookiefile: Path | None = None,
) -> SubtitleTrack | None:
    try:
        ass, video, _ = _load_bilibili_api()
    except ImportError:
        return None

    bvid = _extract_bvid(input_str, info)
    if not bvid:
        return None

    if video_obj is None:
        video_obj = video.Video(bvid=bvid, credential=credential)

    try:
        if cid is None:
            cid = _pick_cid(info, page_index)
        subtitle_obj = asyncio.run(
            ass.request_subtitle(
                video_obj,
                page_index=page_index,
                cid=cid,
                credential=credential,
            )
        )
        srt_text = subtitle_obj.to_srt()
    except Exception:
        srt_text = _fetch_subtitle_via_url(
            video_obj,
            cid=cid,
            cookiefile=cookiefile,
            referer=input_str,
        )
        if not srt_text:
            return None

    if not srt_text.strip():
        return None

    subtitle_path = work_dir / "subtitles" / "bilibili-remote.srt"
    subtitle_path.write_text(srt_text, encoding="utf-8")
    return SubtitleTrack(lang="zh", fmt="srt", path=subtitle_path)


def _fetch_danmaku(cid: str) -> list[DanmakuItem]:
    url = f"https://comment.bilibili.com/{cid}.xml"
    try:
        with urllib.request.urlopen(url, timeout=10) as response:
            xml_text = response.read().decode("utf-8", errors="replace")
    except Exception:
        return []

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []

    items: list[DanmakuItem] = []
    for node in root.findall("d"):
        payload = (node.attrib.get("p") or "").split(",")
        if len(payload) < 4:
            continue
        try:
            items.append(
                DanmakuItem(
                    time=float(payload[0]),
                    type=int(payload[1]),
                    color=int(payload[3]),
                    text=(node.text or "").strip(),
                )
            )
        except ValueError:
            continue
    return items


def _load_bilibili_api():
    from bilibili_api import Credential, ass, video

    return ass, video, Credential


def _fetch_subtitle_via_url(
    video_obj,
    *,
    cid: int,
    cookiefile: Path | None,
    referer: str,
) -> str:
    try:
        subtitle_info = asyncio.run(video_obj.get_subtitle(cid=cid))
    except Exception:
        return ""

    subtitles = subtitle_info.get("subtitles") or []
    if not subtitles:
        return ""

    subtitle_url = subtitles[0].get("subtitle_url") or ""
    if not subtitle_url:
        return ""
    if subtitle_url.startswith("//"):
        subtitle_url = f"https:{subtitle_url}"

    headers = _build_remote_headers(referer, cookiefile)
    request = urllib.request.Request(subtitle_url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = response.read().decode("utf-8", errors="replace")
    except Exception:
        return ""

    try:
        data = json.loads(payload)
    except json.JSONDecodeError:
        return ""
    return _subtitle_json_to_srt(data)


def _subtitle_json_to_srt(data: dict) -> str:
    blocks: list[str] = []
    for index, item in enumerate(data.get("body") or [], start=1):
        start = float(item.get("from") or 0.0)
        end = float(item.get("to") or 0.0)
        text = str(item.get("content") or "").strip()
        if not text:
            continue
        blocks.append(
            "\n".join(
                [
                    str(index),
                    f"{_fmt_srt_time(start)} --> {_fmt_srt_time(end)}",
                    text,
                ]
            )
        )
    return "\n\n".join(blocks)


def _fmt_srt_time(value: float) -> str:
    total_ms = max(0, int(round(value * 1000)))
    hours, rem = divmod(total_ms, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1000)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{millis:03d}"
