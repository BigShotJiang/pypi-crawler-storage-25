"""Site-scoped auth helpers for browser and cookie-file based acquisition."""

from __future__ import annotations

import time
from dataclasses import dataclass
from http.cookiejar import Cookie, CookieJar
from pathlib import Path

from yt_dlp.cookies import YoutubeDLCookieJar, extract_cookies_from_browser

from ...config import WVConfig

_BILIBILI_DOMAIN = "bilibili.com"
_COOKIE_CACHE_TTL_DAYS = 3   # re-import browser cookies after this many days


def _cookie_cache_is_fresh(path: Path) -> bool:
    """Return True if the cookie cache file is present, non-empty, and within TTL."""
    try:
        stat = path.stat()
        age_days = (time.time() - stat.st_mtime) / 86400
        return stat.st_size > 0 and age_days < _COOKIE_CACHE_TTL_DAYS
    except OSError:
        return False


@dataclass(frozen=True)
class BrowserSpec:
    browser: str
    profile: str | None = None
    keyring: str | None = None
    container: str | None = None


def parse_browser_spec(value: str) -> BrowserSpec:
    browser_and_profile, has_container, container = value.partition("::")
    browser_and_keyring, has_profile, profile = browser_and_profile.partition(":")
    browser, has_keyring, keyring = browser_and_keyring.partition("+")
    return BrowserSpec(
        browser=browser,
        profile=profile if has_profile and profile else None,
        keyring=keyring if has_keyring and keyring else None,
        container=container if has_container and container else None,
    )


def _cookie_matches_domain(cookie: Cookie, site_domain: str) -> bool:
    cookie_domain = cookie.domain.lstrip(".").lower()
    site_domain = site_domain.lower()
    return cookie_domain == site_domain or cookie_domain.endswith(f".{site_domain}")


class BilibiliAuthManager:
    def __init__(self, cfg: WVConfig, cache_root: Path):
        self._cfg = cfg
        self._cache_root = cache_root
        self._browser_auth_blocked = False

    def resolve_cookiefile(self) -> Path | None:
        if self._cfg.cookies:
            return Path(self._cfg.cookies).expanduser()

        cache_path = self._cache_path()
        if cache_path.exists() and _cookie_cache_is_fresh(cache_path):
            return cache_path

        if not self._cfg.cookies_from_browser:
            return None

        try:
            return self._import_from_browser(show_notice=True)
        except Exception as exc:
            self._browser_auth_blocked = True
            print(f"[wv] 浏览器登录态授权未通过，继续走匿名下载并在后续使用 Whisper 兜底: {exc}")
            return None

    def refresh_cookiefile(self) -> Path | None:
        if self._cfg.cookies:
            return Path(self._cfg.cookies).expanduser()
        if not self._cfg.cookies_from_browser:
            return None
        try:
            return self._import_from_browser(show_notice=True)
        except Exception as exc:
            self._browser_auth_blocked = True
            print(f"[wv] 无法刷新浏览器登录态，继续走匿名下载并在后续使用 Whisper 兜底: {exc}")
            return None

    def can_refresh(self) -> bool:
        return (
            self._cfg.cookies is None
            and self._cfg.cookies_from_browser is not None
            and not self._browser_auth_blocked
        )

    def _import_from_browser(self, show_notice: bool) -> Path:
        if show_notice:
            print(
                "[wv] 需要读取浏览器中的 B 站登录态来访问登录后字幕。"
                " macOS 可能会弹出 Chrome/钥匙串授权，因为浏览器 cookies 是加密存储的。"
                " 读取后只会在本项目中缓存 bilibili.com 所需 cookies。"
            )

        spec = parse_browser_spec(self._cfg.cookies_from_browser or "")
        cookiejar = extract_cookies_from_browser(
            spec.browser,
            profile=spec.profile,
            keyring=spec.keyring,
            container=spec.container,
        )

        filtered = CookieJar()
        for cookie in cookiejar:
            if _cookie_matches_domain(cookie, _BILIBILI_DOMAIN):
                filtered.set_cookie(cookie)

        if not list(filtered):
            raise RuntimeError("Browser login state did not contain any bilibili.com cookies to cache.")

        cache_path = self._cache_path()
        cache_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            jar = YoutubeDLCookieJar(str(cache_path))
            for cookie in filtered:
                jar.set_cookie(cookie)
            jar.save(ignore_discard=True, ignore_expires=True)
        except Exception:
            cache_path.unlink(missing_ok=True)
            raise

        return cache_path

    def _cache_path(self) -> Path:
        return self._cache_root / ".auth" / "bilibili.cookies.txt"


def load_site_cookies(cookiefile: Path | None, site_domain: str) -> dict[str, str]:
    if cookiefile is None or not cookiefile.exists():
        return {}

    jar = YoutubeDLCookieJar(str(cookiefile))
    try:
        jar.load(ignore_discard=True, ignore_expires=True)
    except Exception:
        return {}

    cookies: dict[str, str] = {}
    for cookie in jar:
        if _cookie_matches_domain(cookie, site_domain):
            cookies[cookie.name] = cookie.value
    return cookies


def build_cookie_header(cookiefile: Path | None, site_domain: str) -> str | None:
    cookies = load_site_cookies(cookiefile, site_domain)
    if not cookies:
        return None
    return "; ".join(f"{name}={value}" for name, value in cookies.items())


def is_auth_failure(error: Exception) -> bool:
    text = str(error).lower()
    signals = (
        "cookie",
        "cookies",
        "login",
        "logged in",
        "sign in",
        "permission",
        "403",
        "access denied",
        "forbidden",
    )
    return any(signal in text for signal in signals)
