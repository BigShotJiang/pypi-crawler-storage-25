"""faster-whisper transcript provider — cross-platform CPU/CUDA backend.

Based on CTranslate2. Works on Linux/macOS/Windows with CPU by default.
Prefer this over mlx-whisper for non-Apple-Silicon environments.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

from ...config import WVConfig, _find_binary
from ...models import Segment, SourceMeta, Transcript, TranscriptSource, Word


class FasterWhisperProvider:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def can_handle(self, meta: SourceMeta) -> bool:
        return True  # Always usable when a local audio path is available.

    def transcribe(self, video_path: Path | None, meta: SourceMeta, work_dir: Path) -> Transcript:
        if video_path is None:
            raise RuntimeError(
                "Whisper transcription requires a local video file. "
                "Remote media mode currently requires platform subtitles."
            )
        audio_path = work_dir / "audio.wav"
        _extract_audio(video_path, audio_path)

        try:
            from faster_whisper import WhisperModel  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Whisper transcription requires optional dependency 'faster-whisper'. "
                "Install it with `pip install \"withvideo[faster-whisper]\"` or "
                "`uv sync --extra faster-whisper`."
            ) from exc

        model_name = self._cfg.whisper_model
        # The default whisper_model (`mlx-community/whisper-large-v3-turbo`) is an
        # MLX-specific repo. Fall back to a CPU-friendly default whenever the
        # configured value is an MLX repo and the user hasn't overridden it for
        # faster-whisper explicitly.
        if model_name.startswith("mlx-community/") or model_name.startswith("mlx-"):
            model_name = "small"

        device = self._cfg.whisper_device or "auto"
        compute_type = _compute_type_for_device(device)

        model = WhisperModel(model_name, device=device, compute_type=compute_type)
        segments_iter, info = model.transcribe(
            str(audio_path),
            word_timestamps=True,
        )

        segments = _parse_segments(segments_iter)
        lang = getattr(info, "language", None) or "unknown"

        return Transcript(
            source=TranscriptSource.WHISPER,
            language=lang,
            segments=segments,
            has_word_timestamps=True,
        )


def _extract_audio(video_path: Path, audio_path: Path) -> None:
    subprocess.run(
        [
            _find_binary("ffmpeg") or "ffmpeg", "-y", "-i", str(video_path),
            "-ar", "16000", "-ac", "1", "-f", "wav", str(audio_path),
        ],
        capture_output=True, check=True, timeout=300,
    )


def _compute_type_for_device(device: str) -> str:
    # faster-whisper/CTranslate2 exposes different mixed-precision paths on
    # CUDA vs CPU. Pick the most widely compatible default so users don't need
    # to tune this unless they want to.
    if device == "cuda":
        return "float16"
    if device == "cpu":
        return "int8"
    return "auto"


def _parse_segments(segments_iter) -> list[Segment]:
    """Convert faster-whisper segment objects (or dicts) to our Segment model."""
    segments: list[Segment] = []
    for seg in segments_iter:
        words_raw = _attr_or_key(seg, "words") or []
        words: list[Word] = []
        for w in words_raw:
            words.append(
                Word(
                    word=_attr_or_key(w, "word") or "",
                    start=float(_attr_or_key(w, "start") or 0),
                    end=float(_attr_or_key(w, "end") or 0),
                )
            )
        segments.append(
            Segment(
                start=float(_attr_or_key(seg, "start") or 0),
                end=float(_attr_or_key(seg, "end") or 0),
                text=(_attr_or_key(seg, "text") or "").strip(),
                words=words,
                no_speech_prob=float(_attr_or_key(seg, "no_speech_prob") or 0),
            )
        )
    return segments


def _attr_or_key(obj, name):
    """faster-whisper returns named tuples; support dicts for test ergonomics."""
    if isinstance(obj, dict):
        return obj.get(name)
    return getattr(obj, name, None)
