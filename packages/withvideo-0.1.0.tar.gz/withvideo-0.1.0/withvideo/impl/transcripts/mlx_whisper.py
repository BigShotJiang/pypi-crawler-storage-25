"""mlx-whisper transcript provider for Apple Silicon."""

from __future__ import annotations

import subprocess
from pathlib import Path

from ...config import WVConfig, _find_binary
from ...models import Segment, SourceMeta, Transcript, TranscriptSource, Word


class MlxWhisperProvider:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def can_handle(self, meta: SourceMeta) -> bool:
        return True  # Always available as primary or fallback

    def transcribe(self, video_path: Path | None, meta: SourceMeta, work_dir: Path) -> Transcript:
        if video_path is None:
            raise RuntimeError(
                "Whisper transcription requires a local video file. "
                "Remote media mode currently requires platform subtitles."
            )
        audio_path = work_dir / "audio.wav"
        _extract_audio(video_path, audio_path)

        try:
            import mlx_whisper  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Whisper transcription requires optional dependency 'mlx-whisper'. "
                "Install it with `uv sync --extra whisper` or `pip install mlx-whisper`."
            ) from exc

        result = mlx_whisper.transcribe(
            str(audio_path),
            path_or_hf_repo=self._cfg.whisper_model,
            word_timestamps=True,
        )

        segments = _parse_whisper_result(result)
        lang = result.get("language") or "unknown"

        return Transcript(
            source=TranscriptSource.WHISPER,
            language=lang,
            segments=segments,
            has_word_timestamps=True,
        )


def _extract_audio(video_path: Path, audio_path: Path) -> None:
    subprocess.run(
        [
            _find_binary("ffmpeg") or "ffmpeg", "-y", "-i", str(video_path),
            "-ar", "16000", "-ac", "1", "-f", "wav", str(audio_path),
        ],
        capture_output=True, check=True, timeout=300,
    )


def _parse_whisper_result(result: dict) -> list[Segment]:
    segments = []
    for seg in result.get("segments") or []:
        words = []
        for w in seg.get("words") or []:
            words.append(Word(
                word=w.get("word") or "",
                start=float(w.get("start") or 0),
                end=float(w.get("end") or 0),
            ))
        segments.append(Segment(
            start=float(seg.get("start") or 0),
            end=float(seg.get("end") or 0),
            text=(seg.get("text") or "").strip(),
            words=words,
            no_speech_prob=float(seg.get("no_speech_prob") or 0),
        ))
    return segments
