"""Runtime transcript provider selection based on acquired metadata."""

from __future__ import annotations

from pathlib import Path

from ...config import WVConfig
from ...models import SourceMeta, SubtitleQuality, Transcript
from ...runtime import DecisionRequired
from ..acquirers.common import has_usable_tracks
from .faster_whisper import FasterWhisperProvider
from .mlx_whisper import MlxWhisperProvider
from .platform_subs import PlatformSubsProvider


class AdaptiveTranscriptProvider:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def can_handle(self, meta: SourceMeta) -> bool:
        return True

    def transcribe(self, video_path: Path | None, meta: SourceMeta, work_dir: Path) -> Transcript:
        whisper_fallback = _default_whisper_backend()
        if self._cfg.transcript == "auto" and video_path is not None:
            if not _meta_has_usable_platform_subs(meta) or meta.subtitle_quality not in (
                SubtitleQuality.WORD_LEVEL,
                SubtitleQuality.SENTENCE_LEVEL,
            ):
                raise DecisionRequired(
                    kind="platform_subtitles_to_whisper",
                    reason_code="platform_subtitles_unavailable"
                    if not _meta_has_usable_platform_subs(meta)
                    else "platform_subtitles_unreliable",
                    message="Platform subtitles are unavailable or unreliable; Whisper fallback requires confirmation.",
                    options=[whisper_fallback, "abort"],
                    default_option=whisper_fallback,
                    stage="transcript",
                    context={
                        "subtitle_quality": meta.subtitle_quality.value,
                        "platform": meta.platform.value,
                    },
                )

        primary_name = self._select_provider_name(meta, video_path)
        primary = self._make_provider(primary_name)

        if primary_name == "platform-subs" and not _meta_has_usable_platform_subs(meta):
            if video_path is None:
                raise RuntimeError("Remote media access requires platform subtitles; Whisper fallback is unavailable.")
            raise DecisionRequired(
                kind="platform_subtitles_to_whisper",
                reason_code="platform_subtitles_unavailable",
                message="Platform subtitles are unavailable; Whisper fallback requires confirmation.",
                options=[whisper_fallback, "abort"],
                default_option=whisper_fallback,
                stage="transcript",
                context={
                    "subtitle_quality": meta.subtitle_quality.value,
                    "platform": meta.platform.value,
                },
            )

        try:
            return primary.transcribe(video_path, meta, work_dir)
        except FileNotFoundError as exc:
            if primary_name in {"mlx-whisper", "faster-whisper"}:
                raise
            if video_path is None:
                raise RuntimeError("Remote media access requires platform subtitles; Whisper fallback is unavailable.") from exc
            raise DecisionRequired(
                kind="platform_subtitles_to_whisper",
                reason_code="platform_subtitles_missing_sidecar",
                message=f"Platform subtitles are unavailable; Whisper fallback requires confirmation: {exc}",
                options=[whisper_fallback, "abort"],
                default_option=whisper_fallback,
                stage="transcript",
                context={
                    "subtitle_quality": meta.subtitle_quality.value,
                    "platform": meta.platform.value,
                },
            ) from exc

    def _select_provider_name(self, meta: SourceMeta, video_path: Path | None) -> str:
        choice = self._cfg.transcript
        if choice in {"mlx-whisper", "faster-whisper", "platform-subs"}:
            return choice
        if video_path is None and _meta_has_usable_platform_subs(meta):
            return "platform-subs"
        if (
            meta.subtitle_quality in (SubtitleQuality.WORD_LEVEL, SubtitleQuality.SENTENCE_LEVEL)
            and _meta_has_usable_platform_subs(meta)
        ):
            return "platform-subs"
        return _default_whisper_backend()

    def _make_provider(self, name: str):
        if name == "platform-subs":
            return PlatformSubsProvider(self._cfg)
        if name == "mlx-whisper":
            return MlxWhisperProvider(self._cfg)
        return FasterWhisperProvider(self._cfg)


def _default_whisper_backend() -> str:
    """Prefer cross-platform faster-whisper when available, falling back to mlx-whisper
    (Apple Silicon only) when faster-whisper is not installed."""
    try:
        import faster_whisper  # type: ignore # noqa: F401
        return "faster-whisper"
    except ImportError:
        pass
    try:
        import mlx_whisper  # type: ignore # noqa: F401
        return "mlx-whisper"
    except ImportError:
        # Neither backend installed — keep faster-whisper as the advertised default
        # so the error message points users at the cross-platform option.
        return "faster-whisper"


def _meta_has_usable_platform_subs(meta: SourceMeta) -> bool:
    return has_usable_tracks(meta.subtitles) or has_usable_tracks(meta.auto_captions)
