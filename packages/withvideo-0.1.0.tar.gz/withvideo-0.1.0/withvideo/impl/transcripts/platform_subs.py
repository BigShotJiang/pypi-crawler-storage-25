"""Platform subtitle provider — parses downloaded VTT/SRT files."""

from __future__ import annotations

import re
from pathlib import Path

from ...config import WVConfig
from ...models import Segment, SourceMeta, SubtitleQuality, Transcript, TranscriptSource, Word
from ..acquirers.common import scan_local_subtitle_sidecars


class PlatformSubsProvider:
    def __init__(self, cfg: WVConfig | None = None):
        self._cfg = cfg or WVConfig()

    def can_handle(self, meta: SourceMeta) -> bool:
        return meta.subtitle_quality in (
            SubtitleQuality.WORD_LEVEL, SubtitleQuality.SENTENCE_LEVEL
        )

    def transcribe(self, video_path: Path | None, meta: SourceMeta, work_dir: Path) -> Transcript:
        # Find best subtitle file
        track = _pick_best_track(meta, video_path)
        if track is None or not track.path or not track.path.exists():
            raise FileNotFoundError("No usable subtitle file found")

        if track.fmt in ("vtt", "webvtt"):
            segments = _parse_vtt(track.path)
        else:
            segments = _parse_srt(track.path)

        return Transcript(
            source=TranscriptSource.PLATFORM_AUTO
            if track.is_generated
            else TranscriptSource.PLATFORM_MANUAL,
            language=track.lang,
            segments=segments,
            has_word_timestamps=track.has_word_timestamps,
        )


def _pick_best_track(meta, video_path: Path | None):
    """Prefer manual subs; prefer the video's original language."""
    all_tracks = list(meta.subtitles) + list(meta.auto_captions)
    if not all_tracks and video_path is not None:
        all_tracks = scan_local_subtitle_sidecars(video_path)
    usable_tracks = [track for track in all_tracks if track.path and track.path.exists()]
    if not usable_tracks:
        return None

    def score(track):
        return (
            1 if track.source == "yt-dlp" else 0,
            1 if not track.is_generated else 0,
            1 if "-" not in track.lang else 0,
            1 if track.has_word_timestamps else 0,
        )

    return max(usable_tracks, key=score)


# ---------------------------------------------------------------------------
# VTT parser (handles YouTube's word-level timing)
# ---------------------------------------------------------------------------

_VTT_TS = re.compile(
    r"(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})"
)
_VTT_WORD_TAG = re.compile(r"<(\d{2}:\d{2}:\d{2}\.\d{3})><c>(.*?)</c>")
_HTML_TAG = re.compile(r"<[^>]+>")


def _ts(h, m, s, ms) -> float:
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000


def _parse_embedded_vtt_ts(value: str) -> float:
    match = re.match(r"(?:(\d{2}):)?(\d{2}):(\d{2})\.(\d{3})$", value)
    if not match:
        raise ValueError(f"Unsupported VTT timestamp: {value}")
    hours = match.group(1) or "00"
    minutes = match.group(2)
    seconds = match.group(3)
    millis = match.group(4)
    return _ts(hours, minutes, seconds, millis)


def _parse_vtt(path: Path) -> list[Segment]:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    segments: list[Segment] = []
    i = 0
    while i < len(lines):
        m = _VTT_TS.match(lines[i])
        if m:
            start = _ts(*m.groups()[:4])
            end = _ts(*m.groups()[4:])
            i += 1
            body_lines = []
            while i < len(lines) and lines[i].strip():
                body_lines.append(lines[i])
                i += 1
            raw = " ".join(body_lines)
            # Extract word-level timestamps if present (YouTube format)
            words: list[Word] = []
            for wm in _VTT_WORD_TAG.finditer(raw):
                wt = _parse_embedded_vtt_ts(wm.group(1))
                words.append(Word(word=wm.group(2), start=wt, end=wt))
            clean = _HTML_TAG.sub("", raw).strip()
            if clean:
                segments.append(Segment(start=start, end=end, text=clean, words=words))
        else:
            i += 1
    return segments


# ---------------------------------------------------------------------------
# SRT parser
# ---------------------------------------------------------------------------

_SRT_TS = re.compile(
    r"(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})"
)


def _parse_srt(path: Path) -> list[Segment]:
    text = path.read_text(encoding="utf-8", errors="replace")
    blocks = re.split(r"\n\n+", text.strip())
    segments = []
    for block in blocks:
        lines = block.strip().splitlines()
        m = None
        for line in lines:
            m = _SRT_TS.match(line)
            if m:
                break
        if not m:
            continue
        start = _ts(*m.groups()[:4])
        end = _ts(*m.groups()[4:])
        text_lines = [l for l in lines if not _SRT_TS.match(l) and not l.strip().isdigit()]
        clean = _HTML_TAG.sub("", " ".join(text_lines)).strip()
        if clean:
            segments.append(Segment(start=start, end=end, text=clean))
    return segments
