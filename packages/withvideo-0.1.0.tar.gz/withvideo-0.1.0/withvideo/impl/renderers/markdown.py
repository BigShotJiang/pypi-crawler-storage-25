"""Markdown renderer — produces the human+machine readable Repeat Guide."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime

from ...models import Operation, RepeatGuide, RepeatStep, Window, WindowType


# ---------------------------------------------------------------------------
# Code file externalization helpers
# ---------------------------------------------------------------------------

@dataclass
class CodeFile:
    rel_path: str   # e.g. "code/step_07_prompt.txt"
    content: str


_LANG_EXT: dict[str, str] = {
    "python": ".py", "py": ".py",
    "javascript": ".js", "js": ".js",
    "typescript": ".ts", "ts": ".ts",
    "bash": ".sh", "shell": ".sh", "sh": ".sh",
    "html": ".html", "css": ".css", "json": ".json",
    "yaml": ".yaml", "yml": ".yaml",
    "sql": ".sql", "go": ".go", "rust": ".rs",
    "java": ".java", "ruby": ".rb", "c": ".c", "cpp": ".cpp",
}

_CODE_LINE_THRESHOLD = 3  # lines > this → externalize


class _CodeCollector:
    """Accumulates code files to externalize, generating unique names."""

    def __init__(self) -> None:
        self.files: list[CodeFile] = []
        self._counters: dict[str, int] = {}

    def add(self, step_index: int, kind: str, ext: str, content: str) -> str:
        key = f"step_{step_index + 1:02d}_{kind}"
        count = self._counters.get(key, 0)
        self._counters[key] = count + 1
        suffix = f"_{count + 1}" if count > 0 else ""
        rel_path = f"code/{key}{suffix}{ext}"
        self.files.append(CodeFile(rel_path=rel_path, content=content))
        return rel_path


def _should_externalize(text: str, collector: _CodeCollector | None) -> bool:
    if collector is None or not text.strip():
        return False
    return text.strip().count("\n") + 1 > _CODE_LINE_THRESHOLD


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------

def _fmt_time(seconds: float) -> str:
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


# ---------------------------------------------------------------------------
# Renderer
# ---------------------------------------------------------------------------

class MarkdownRenderer:
    def extension(self) -> str:
        return ".md"

    def render(self, guide: RepeatGuide) -> str:
        """Backward-compatible: all code stays inline."""
        return self._render_body(guide, collector=None)

    def render_with_code_files(self, guide: RepeatGuide) -> tuple[str, list[CodeFile]]:
        """Returns (markdown_string, list_of_code_files_to_write)."""
        collector = _CodeCollector()
        md = self._render_body(guide, collector)
        return md, collector.files

    def _render_body(self, guide: RepeatGuide, collector: _CodeCollector | None) -> str:
        parts = []

        # YAML frontmatter
        parts.append("---")
        parts.append(f'source: "{guide.metadata.source}"')
        parts.append(f'title: "{guide.metadata.title}"')
        parts.append(f'duration: "{guide.metadata.duration}"')
        parts.append(f'plugin: "{guide.metadata.plugin}"')
        parts.append(f'generated: "{guide.metadata.generated_at}"')
        parts.append("format: repeat-guide-v1")
        parts.append("---\n")

        # Title + overview
        parts.append(f"# {guide.metadata.title}\n")
        if guide.overview:
            parts.append(f"## 概述\n\n{guide.overview}\n")

        # Prerequisites
        if guide.prerequisites:
            parts.append("## 前置条件\n")
            for p in guide.prerequisites:
                parts.append(f"- {p}")
            parts.append("")

        # Knowledge index
        if guide.knowledge_index:
            parts.append("## 知识点索引\n")
            for kp in guide.knowledge_index:
                parts.append(f"- [{_fmt_time(kp.timestamp)}] {kp.topic}")
            parts.append("")

        parts.append("---")

        # Steps
        for step in guide.steps:
            parts.append(_render_step(step, collector))

        return "\n".join(parts)


def _render_step(step: RepeatStep, collector: _CodeCollector | None = None) -> str:
    parts = []
    start, end = step.time_range
    time_str = f"[{_fmt_time(start)} - {_fmt_time(end)}]"
    title = step.title or f"Step {step.index + 1}"
    parts.append(f"\n## Step {step.index + 1}: {title}")
    parts.append(f"_{time_str}_\n")

    # EXPLAIN — always present
    parts.append(_render_explain(step.explain))

    # OPERATE — optional
    if step.operate:
        parts.append(_render_operate(step.operate, step.operations, step.index, collector))
    else:
        parts.append("_（此步骤为纯讲解，无需操作）_\n")

    # VERIFY — optional, depends on operate
    if step.verify:
        parts.append("### ✅ 预期结果\n")
        verify_text = " ".join(
            s.text for s in step.verify.transcript_segments if s.text.strip()
        ).strip()
        outcome = step.expected_outcome or verify_text
        if outcome:
            parts.append(outcome + "\n")

    return "\n".join(parts)


def _render_explain(window: Window) -> str:
    parts = ["### 💡 概念\n"]
    # Transcript
    for seg in window.transcript_segments:
        if seg.text.strip():
            parts.append(f"> {seg.text.strip()}")
    if window.knowledge_points:
        parts.append("")
        for kp in window.knowledge_points:
            parts.append(f"- {kp}")
    parts.append("")
    return "\n".join(parts)


def _render_operate(
    window: Window,
    operations: list[Operation],
    step_index: int = 0,
    collector: _CodeCollector | None = None,
) -> str:
    has_speech = any(s.text.strip() for s in window.transcript_segments)
    if has_speech:
        parts = ["### 🔧 操作\n"]
    else:
        parts = ["### 🔧 操作 `[silent]`\n", "_（此段无旁白——操作从画面变化推断）_\n"]

    if operations:
        # Numbered list with optional app context prefix
        for i, op in enumerate(operations, 1):
            label = f"**[{op.app_context}]** " if op.app_context else ""
            parts.append(f"{i}. {label}{op.description}")
        parts.append("")

        # Code blocks for text_input or legacy shell/code_edit
        for op in operations:
            is_run = op.capability == "text_input" and op.action == "run_command"
            is_write = op.capability == "text_input" and op.action == "write_code"
            is_prompt = (op.capability == "text_input"
                         and op.action not in ("run_command", "write_code")
                         and op.action != "")
            is_shell = op.type == "shell"
            is_code_edit = op.type == "code_edit"

            if (is_run or is_shell) and (op.text_content or op.payload.get("command")):
                cmd = op.text_content or op.payload.get("command") or ""
                if _should_externalize(cmd, collector):
                    rel = collector.add(step_index, "command", ".sh", cmd)
                    parts.append(f"→ [完整命令]({rel})\n")
                else:
                    parts.append(f"```bash\n{cmd}\n```\n")

            elif (is_write or is_code_edit) and (op.text_content or op.payload.get("content")):
                lang = op.payload.get("language") or ""
                content = op.text_content or op.payload.get("content") or op.payload.get("diff") or ""
                if content:
                    fname = op.payload.get("file") or ""
                    if _should_externalize(content, collector):
                        ext = _LANG_EXT.get(lang.lower(), ".txt") if lang else ".txt"
                        rel = collector.add(step_index, "code", ext, content)
                        parts.append(f"→ [完整代码]({rel})\n")
                    else:
                        comment = f"# {fname}\n" if fname else ""
                        parts.append(f"```{lang}\n{comment}{content}\n```\n")

            elif is_prompt and op.text_content:
                if _should_externalize(op.text_content, collector):
                    rel = collector.add(step_index, "prompt", ".txt", op.text_content)
                    parts.append(f"→ [完整 prompt]({rel})\n")
                else:
                    parts.append(f"```prompt\n{op.text_content}\n```\n")

        # Machine-readable JSON comment block (always contains full text_content)
        ops_json = [_op_to_dict(op) for op in operations]
        parts.append("<!-- withvideo:operations")
        parts.append(json.dumps(ops_json, ensure_ascii=False, indent=2))
        parts.append("-->")
    else:
        parts.append("_（未检测到具体操作）_")

    parts.append("")
    return "\n".join(parts)


def _op_to_dict(op: Operation) -> dict:
    d: dict = {"type": op.capability or op.type, "description": op.description}
    if op.capability:
        d["capability"] = op.capability
    if op.action:
        d["action"] = op.action
    if op.target:
        d["target"] = op.target
    if op.intent:
        d["intent"] = op.intent
    if op.app_context:
        d["app_context"] = op.app_context
    if op.source:
        d["source"] = op.source
    if op.text_content:
        d["text_content"] = op.text_content
    if op.visual_hint:
        d["visual_hint"] = op.visual_hint
    if op.payload:
        d["payload"] = op.payload
    return d
