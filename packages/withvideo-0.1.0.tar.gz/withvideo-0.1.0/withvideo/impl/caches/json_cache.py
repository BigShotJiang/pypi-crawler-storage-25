"""Simple JSON file-based cache — one file per stage."""

from __future__ import annotations

import hashlib
import json
import pickle
from pathlib import Path
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable)


class JsonCache:
    """
    Wraps functions with a file-based cache.
    Cache key = fn name + sha256 of pickled args.
    Stores values as JSON (falls back to pickle for non-JSON-serialisable types).
    """

    def __init__(self, work_dir: Path):
        self._dir = work_dir / ".cache_json"
        self._dir.mkdir(parents=True, exist_ok=True)

    def cached(self, fn: F) -> F:
        cache = self

        def wrapper(*args, **kwargs):
            key = _make_key(fn, args, kwargs)
            path = cache._dir / f"{fn.__name__}_{key}"
            pkl = path.with_suffix(".pkl")
            if pkl.exists():
                with pkl.open("rb") as f:
                    return pickle.load(f)
            result = fn(*args, **kwargs)
            with pkl.open("wb") as f:
                pickle.dump(result, f)
            return result

        wrapper.__name__ = fn.__name__
        return wrapper  # type: ignore

    def invalidate(self) -> None:
        import shutil
        shutil.rmtree(self._dir, ignore_errors=True)
        self._dir.mkdir(parents=True, exist_ok=True)


def _make_key(fn: Callable, args, kwargs) -> str:
    try:
        raw = pickle.dumps((fn.__name__, args, sorted(kwargs.items())))
    except Exception:
        raw = str((fn.__name__, args, kwargs)).encode()
    return hashlib.sha256(raw).hexdigest()[:16]
