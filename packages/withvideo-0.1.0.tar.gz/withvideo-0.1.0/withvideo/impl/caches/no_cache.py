"""No-op cache — always re-runs functions (equivalent to --force)."""

from __future__ import annotations

from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable)


class NoCache:
    def cached(self, fn: F) -> F:
        return fn  # pass-through, no caching

    def invalidate(self) -> None:
        pass
