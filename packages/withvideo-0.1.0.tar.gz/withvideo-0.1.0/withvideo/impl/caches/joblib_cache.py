"""Joblib-based stage cache — caches function results by arguments."""

from __future__ import annotations

from pathlib import Path
from typing import Callable, TypeVar

from joblib import Memory

F = TypeVar("F", bound=Callable)


class JoblibCache:
    def __init__(self, work_dir: Path):
        self._memory = Memory(location=str(work_dir / ".cache"), verbose=0)

    def cached(self, fn: F) -> F:
        return self._memory.cache(fn)

    def invalidate(self) -> None:
        self._memory.clear(warn=False)
