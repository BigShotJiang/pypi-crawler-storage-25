import tempfile
import unittest
from pathlib import Path

from withvideo.models import Platform, SourceMeta, SubtitleTrack
from withvideo.pipeline import _relocate_meta_paths


class PipelineMetaPathTests(unittest.TestCase):
    def test_relocates_staging_video_and_subtitle_paths(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            staging = base / "_staging"
            final_dir = base / "lesson"
            staging.mkdir()
            (staging / "source.mp4").write_bytes(b"")
            (staging / "source.ai-zh.srt").write_text(
                "1\n00:00:00,000 --> 00:00:01,000\n你好\n",
                encoding="utf-8",
            )
            meta = SourceMeta(
                input="https://example.com/video",
                platform=Platform.BILIBILI,
                local_video_path=staging / "source.mp4",
                subtitles=[SubtitleTrack(lang="ai-zh", fmt="srt", path=staging / "source.ai-zh.srt")],
            )

            _relocate_meta_paths(meta, staging, final_dir)

        self.assertEqual(meta.video_path, final_dir / "source.mp4")
        self.assertEqual(meta.subtitles[0].path, final_dir / "source.ai-zh.srt")


if __name__ == "__main__":
    unittest.main()
