import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.impl.vision.cli import CliVisionBackend
from withvideo.registry import build_vision_backend


class VisionCliBackendTests(unittest.TestCase):
    def test_default_config_uses_cli_vision_backend(self) -> None:
        backend = build_vision_backend(WVConfig())
        self.assertIsInstance(backend, CliVisionBackend)

    def test_cli_vision_backend_uses_dash_sentinel_stdin(self) -> None:
        backend = CliVisionBackend(WVConfig(llm_command="codex exec -"))
        frame = SimpleNamespace(
            path=Path("frame.png"),
            timestamp=1.0,
            extraction_reason="burst",
        )

        with patch("pathlib.Path.exists", return_value=True), patch(
            "withvideo.impl.vision.cli.subprocess.run"
        ) as mock_run:
            mock_run.return_value = SimpleNamespace(
                stdout='{"description":"ok","operations_detected":[]}',
                stderr="",
                returncode=0,
            )
            backend.analyze_frame_pair(None, frame, context="hello", domain_prompt="focus")

        cmd = mock_run.call_args.args[0]
        self.assertEqual(cmd, ["codex", "exec", "-"])
        self.assertIn("hello", mock_run.call_args.kwargs["input"])


if __name__ == "__main__":
    unittest.main()
