"""Tests for the cross-platform faster-whisper transcript backend."""

from __future__ import annotations

import sys
import tempfile
import types
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.impl.transcripts.adaptive import (
    AdaptiveTranscriptProvider,
    _default_whisper_backend,
)
from withvideo.impl.transcripts.faster_whisper import FasterWhisperProvider
from withvideo.models import (
    Platform,
    SourceMeta,
    SubtitleQuality,
    Transcript,
    TranscriptSource,
)
from withvideo.registry import build_transcript_provider
from withvideo.runtime import DecisionRequired


def _make_fake_faster_whisper_module(captured: dict, segments_iter):
    """Build a fake `faster_whisper` module so we never actually load a model."""

    class _Model:
        def __init__(self, model_name, device, compute_type, **kwargs):
            captured["model_name"] = model_name
            captured["device"] = device
            captured["compute_type"] = compute_type

        def transcribe(self, audio_path, **kwargs):
            captured["audio_path"] = audio_path
            captured["transcribe_kwargs"] = kwargs
            info = SimpleNamespace(language="en", duration=1.5)
            return segments_iter, info

    module = types.ModuleType("faster_whisper")
    module.WhisperModel = _Model
    return module


def _install_fake_module(testcase, module):
    original = sys.modules.get("faster_whisper")
    sys.modules["faster_whisper"] = module
    testcase.addCleanup(lambda: _restore_module(original))


def _restore_module(original):
    if original is None:
        sys.modules.pop("faster_whisper", None)
    else:
        sys.modules["faster_whisper"] = original


class FasterWhisperProviderTests(unittest.TestCase):
    def test_transcribe_parses_segments_with_word_timestamps(self):
        word = SimpleNamespace(word="hello", start=0.0, end=0.5)
        word2 = SimpleNamespace(word=" world", start=0.5, end=1.0)
        segment = SimpleNamespace(
            start=0.0,
            end=1.0,
            text="hello world",
            no_speech_prob=0.05,
            words=[word, word2],
        )
        captured: dict = {}
        fake_module = _make_fake_faster_whisper_module(captured, iter([segment]))
        _install_fake_module(self, fake_module)

        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "video.mp4"
            video_path.write_bytes(b"")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.LOCAL_FILE,
                local_video_path=video_path,
                subtitle_quality=SubtitleQuality.NONE,
            )

            cfg = WVConfig(transcript="faster-whisper", whisper_model="small", whisper_device="cpu")

            with patch(
                "withvideo.impl.transcripts.faster_whisper._extract_audio"
            ) as mock_extract:
                result = FasterWhisperProvider(cfg).transcribe(video_path, meta, work_dir)

        mock_extract.assert_called_once()
        self.assertIsInstance(result, Transcript)
        self.assertEqual(result.source, TranscriptSource.WHISPER)
        self.assertEqual(result.language, "en")
        self.assertTrue(result.has_word_timestamps)
        self.assertEqual(len(result.segments), 1)
        seg = result.segments[0]
        self.assertEqual(seg.text, "hello world")
        self.assertEqual(seg.start, 0.0)
        self.assertEqual(seg.end, 1.0)
        self.assertAlmostEqual(seg.no_speech_prob, 0.05)
        self.assertEqual(len(seg.words), 2)
        self.assertEqual(seg.words[0].word, "hello")
        self.assertAlmostEqual(seg.words[1].start, 0.5)

        # Ensure our cfg/whisper knobs flowed through
        self.assertEqual(captured["model_name"], "small")
        self.assertEqual(captured["device"], "cpu")
        self.assertEqual(captured["compute_type"], "int8")
        self.assertTrue(captured["transcribe_kwargs"].get("word_timestamps"))

    def test_falls_back_from_mlx_model_name_to_cpu_friendly_default(self):
        captured: dict = {}
        fake_module = _make_fake_faster_whisper_module(captured, iter([]))
        _install_fake_module(self, fake_module)

        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "video.mp4"
            video_path.write_bytes(b"")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.LOCAL_FILE,
                local_video_path=video_path,
                subtitle_quality=SubtitleQuality.NONE,
            )
            # Default cfg uses the MLX repo path which isn't valid for faster-whisper.
            cfg = WVConfig(transcript="faster-whisper")

            with patch("withvideo.impl.transcripts.faster_whisper._extract_audio"):
                FasterWhisperProvider(cfg).transcribe(video_path, meta, work_dir)

        self.assertEqual(captured["model_name"], "small")
        # Default device is "auto" → compute_type "auto"
        self.assertEqual(captured["device"], "auto")
        self.assertEqual(captured["compute_type"], "auto")

    def test_missing_faster_whisper_raises_helpful_import_error(self):
        # Remove any cached module and force the import to fail.
        original = sys.modules.pop("faster_whisper", None)
        self.addCleanup(lambda: _restore_module(original))

        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "video.mp4"
            video_path.write_bytes(b"")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.LOCAL_FILE,
                local_video_path=video_path,
                subtitle_quality=SubtitleQuality.NONE,
            )

            # Block the import so we hit the ImportError branch.
            real_import = __import__

            def _blocking_import(name, *args, **kwargs):
                if name == "faster_whisper" or name.startswith("faster_whisper."):
                    raise ImportError("blocked for test")
                return real_import(name, *args, **kwargs)

            with patch("withvideo.impl.transcripts.faster_whisper._extract_audio"):
                with patch("builtins.__import__", side_effect=_blocking_import):
                    with self.assertRaises(RuntimeError) as ctx:
                        FasterWhisperProvider(WVConfig(transcript="faster-whisper")).transcribe(
                            video_path, meta, work_dir
                        )

        self.assertIn("faster-whisper", str(ctx.exception))
        self.assertIn("withvideo[faster-whisper]", str(ctx.exception))


class AutoModeSelectsFasterWhisperTests(unittest.TestCase):
    def test_auto_selection_prefers_faster_whisper_when_installed(self):
        # Install a stub faster_whisper module so the import-probe succeeds.
        _install_fake_module(self, types.ModuleType("faster_whisper"))
        self.assertEqual(_default_whisper_backend(), "faster-whisper")

    def test_auto_selection_falls_back_to_mlx_when_faster_whisper_missing(self):
        original_fw = sys.modules.pop("faster_whisper", None)
        self.addCleanup(lambda: _restore_module(original_fw))

        # Make the faster_whisper import fail, but leave a stub mlx_whisper.
        original_mlx = sys.modules.get("mlx_whisper")
        sys.modules["mlx_whisper"] = types.ModuleType("mlx_whisper")

        def _cleanup_mlx():
            if original_mlx is None:
                sys.modules.pop("mlx_whisper", None)
            else:
                sys.modules["mlx_whisper"] = original_mlx

        self.addCleanup(_cleanup_mlx)

        real_import = __import__

        def _blocking_import(name, *args, **kwargs):
            if name == "faster_whisper" or name.startswith("faster_whisper."):
                raise ImportError("blocked")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_blocking_import):
            self.assertEqual(_default_whisper_backend(), "mlx-whisper")

    def test_auto_dispatch_without_platform_subs_raises_decision_with_faster_whisper_default(self):
        _install_fake_module(self, types.ModuleType("faster_whisper"))

        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "video.mp4"
            video_path.write_bytes(b"")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.BILIBILI,
                local_video_path=video_path,
                subtitle_quality=SubtitleQuality.NONE,
            )

            provider = AdaptiveTranscriptProvider(WVConfig(transcript="auto"))
            with self.assertRaises(DecisionRequired) as exc_info:
                provider.transcribe(video_path, meta, work_dir)

        self.assertEqual(exc_info.exception.default_option, "faster-whisper")
        self.assertIn("faster-whisper", exc_info.exception.options)


class RegistryIntegrationTests(unittest.TestCase):
    def test_registry_exposes_faster_whisper_name(self):
        cfg = WVConfig(transcript="faster-whisper")
        provider = build_transcript_provider(cfg)
        self.assertIsInstance(provider, FasterWhisperProvider)


if __name__ == "__main__":
    unittest.main()
