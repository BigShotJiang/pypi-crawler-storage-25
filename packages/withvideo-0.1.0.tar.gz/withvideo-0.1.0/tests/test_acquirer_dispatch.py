import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.impl.acquirers.generic_url import GenericUrlAcquirer
from withvideo.impl.acquirers.router import AutoInputAcquirer
from withvideo.models import Platform


class AutoInputAcquirerTests(unittest.TestCase):
    def test_routes_local_paths_to_local_video_acquirer(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            video_path = Path(tmp) / "sample.mp4"
            video_path.write_bytes(b"")

            acquirer = AutoInputAcquirer(WVConfig())
            with patch("withvideo.impl.acquirers.router.LocalFileAcquirer.acquire", return_value=("video", "name", "meta")) as mock_acquire:
                result = acquirer.acquire(str(video_path), Path(tmp) / "out", {})

        self.assertEqual(result, ("video", "name", "meta"))
        mock_acquire.assert_called_once()

    def test_routes_bilibili_urls_to_bilibili_acquirer(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            acquirer = AutoInputAcquirer(WVConfig())
            with patch("withvideo.impl.acquirers.router.BilibiliAcquirer.acquire", return_value=("video", "name", "meta")) as mock_acquire:
                result = acquirer.acquire("https://www.bilibili.com/video/BV1xx411c7mD", Path(tmp) / "out", {})

        self.assertEqual(result, ("video", "name", "meta"))
        mock_acquire.assert_called_once()

    def test_routes_other_urls_to_generic_url_acquirer(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            acquirer = AutoInputAcquirer(WVConfig())
            with patch("withvideo.impl.acquirers.router.GenericUrlAcquirer.acquire", return_value=("video", "name", "meta")) as mock_acquire:
                result = acquirer.acquire("https://example.com/tutorial.mp4", Path(tmp) / "out", {})

        self.assertEqual(result, ("video", "name", "meta"))
        mock_acquire.assert_called_once()

    def test_remote_mode_fast_fails_for_non_bilibili_urls_in_auto_router(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            acquirer = AutoInputAcquirer(WVConfig(media_access="remote"))

            with self.assertRaises(NotImplementedError) as ctx:
                acquirer.acquire("https://www.youtube.com/watch?v=dQw4w9WgXcQ", Path(tmp) / "out", {})

        self.assertIn("only supported for Bilibili URLs", str(ctx.exception))


class GenericUrlAcquirerRemoteGuardTests(unittest.TestCase):
    def test_direct_generic_acquirer_fast_fails_in_remote_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            acquirer = GenericUrlAcquirer(WVConfig(media_access="remote"))

            with self.assertRaises(NotImplementedError) as ctx:
                acquirer.acquire("https://example.com/tutorial.mp4", Path(tmp) / "out", {})

        self.assertIn("Remote media access", str(ctx.exception))
        self.assertIn(Platform.LOCAL_FILE.value, str(ctx.exception))
