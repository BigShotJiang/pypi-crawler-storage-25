from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
import io

import pytest

from withvideo.config import WVConfig
from withvideo.impl.acquirers.bilibili import BilibiliAcquirer
from withvideo.impl.caches.no_cache import NoCache
from withvideo.models import (
    ActivityProfile,
    LocalMediaHandle,
    Platform,
    RemoteMediaHandle,
    RepeatStep,
    Segment,
    SourceMeta,
    SubtitleQuality,
    SubtitleTrack,
    Transcript,
    TranscriptSource,
    Window,
    WindowType,
)
from withvideo.pipeline import Pipeline, _ffmpeg_input_args
from withvideo.runtime import DecisionRequired, RunReporter


class _DummyRenderer:
    def extension(self) -> str:
        return ".md"

    def render(self, guide) -> str:
        return ""


class _DummyPlugin:
    name = "dummy"

    def extract_operations(self, frame_analysis):
        return []


class _TranscriptProvider:
    def __init__(self, transcript: Transcript | None = None):
        self.transcript = transcript or Transcript(
            source=TranscriptSource.PLATFORM_MANUAL,
            language="zh",
            segments=[Segment(start=0, end=5, text="demo step")],
            has_word_timestamps=False,
        )

    def transcribe(self, video_path, meta, work_dir):
        return self.transcript

    def can_handle(self, meta) -> bool:
        return True


class _FailingActivityDetector:
    def detect(self, video_path):
        raise AssertionError("remote mode should skip activity detection")

    def can_handle(self, video_path) -> bool:
        return True


class _DummyVision:
    pass


def test_bilibili_remote_acquire_returns_remote_handle_without_video_download(tmp_path, monkeypatch):
    work_dir = tmp_path / "staging"

    class FakeCredential:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class FakeVideo:
        def __init__(self, bvid=None, aid=None, credential=None):
            self.bvid = bvid
            self.credential = credential

        async def get_info(self):
            return {
                "title": "Remote Demo",
                "webpage_url": "https://www.bilibili.com/video/BV1xx411c7mD",
                "duration": 42,
                "pages": [{"page": 1, "part": "P1", "cid": 123456, "duration": 42}],
            }

        async def get_pages(self):
            return [{"page": 1, "part": "P1", "cid": 123456, "duration": 42}]

        async def get_download_url(self, page_index=None, cid=None, html5=False):
            assert page_index == 0
            assert cid == 123456
            assert html5 is True
            return {"format": "mp4"}

    class FakeDetector:
        def __init__(self, data):
            self.data = data

        def detect_best_streams(self):
            return [SimpleNamespace(url="https://media.example/video.mp4")]

    class FakeSubtitle:
        def to_srt(self):
            return "1\n00:00:00,000 --> 00:00:02,000\nhello bilibili\n"

    async def fake_request_subtitle(obj, page_index=0, cid=None, lan_name=None, lan_code=None, credential=None):
        assert page_index == 0
        assert cid == 123456
        return FakeSubtitle()

    fake_ass = SimpleNamespace(request_subtitle=fake_request_subtitle)
    fake_video_module = SimpleNamespace(
        Video=FakeVideo,
        VideoDownloadURLDataDetecter=FakeDetector,
    )

    monkeypatch.setattr(
        "withvideo.impl.acquirers.bilibili._load_bilibili_api",
        lambda: (fake_ass, fake_video_module, FakeCredential),
    )

    acquirer = BilibiliAcquirer(WVConfig(media_access="remote"))
    media, video_name, meta = acquirer.acquire(
        "https://www.bilibili.com/video/BV1xx411c7mD",
        work_dir,
        {},
    )

    assert isinstance(media, RemoteMediaHandle)
    assert media.video_url == "https://media.example/video.mp4"
    assert media.headers["Referer"] == "https://www.bilibili.com/video/BV1xx411c7mD"
    assert video_name == "Remote_Demo"
    assert meta.local_video_path is None
    assert meta.subtitle_quality == SubtitleQuality.UNRELIABLE
    assert (work_dir / "source.info.json").exists()
    assert not (work_dir / "source.mp4").exists()
    assert meta.subtitles[0].path == work_dir / "subtitles" / "bilibili-remote.srt"
    assert meta.subtitles[0].path.exists()


def test_bilibili_remote_subtitle_falls_back_to_subtitle_url_when_ass_download_is_forbidden(tmp_path, monkeypatch):
    work_dir = tmp_path / "staging"

    class FakeCredential:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    class FakeVideo:
        def __init__(self, bvid=None, aid=None, credential=None):
            self.bvid = bvid
            self.credential = credential

        async def get_info(self):
            return {
                "title": "Remote Demo",
                "webpage_url": "https://www.bilibili.com/video/BV1xx411c7mD",
                "duration": 42,
                "pages": [{"page": 1, "part": "P1", "cid": 123456, "duration": 42}],
            }

        async def get_pages(self):
            return [{"page": 1, "part": "P1", "cid": 123456, "duration": 42}]

        async def get_download_url(self, page_index=None, cid=None, html5=False):
            return {"format": "mp4"}

        async def get_subtitle(self, cid=None):
            return {
                "subtitles": [
                    {
                        "subtitle_url": "//aisubtitle.example/subtitle.json",
                        "lan": "ai-zh",
                    }
                ]
            }

    class FakeDetector:
        def __init__(self, data):
            self.data = data

        def detect_best_streams(self):
            return [SimpleNamespace(url="https://media.example/video.mp4")]

    async def fake_request_subtitle(*args, **kwargs):
        raise RuntimeError("403 Forbidden")

    def fake_urlopen(req, timeout=10):
        payload = (
            '{"body":[{"from":0.0,"to":1.0,"content":"hello"},{"from":1.0,"to":2.0,"content":"world"}]}'
        ).encode("utf-8")
        return io.BytesIO(payload)

    fake_ass = SimpleNamespace(request_subtitle=fake_request_subtitle)
    fake_video_module = SimpleNamespace(
        Video=FakeVideo,
        VideoDownloadURLDataDetecter=FakeDetector,
    )

    monkeypatch.setattr(
        "withvideo.impl.acquirers.bilibili._load_bilibili_api",
        lambda: (fake_ass, fake_video_module, FakeCredential),
    )
    monkeypatch.setattr("urllib.request.urlopen", fake_urlopen)

    acquirer = BilibiliAcquirer(WVConfig(media_access="remote"))
    _, _, meta = acquirer.acquire(
        "https://www.bilibili.com/video/BV1xx411c7mD",
        work_dir,
        {},
    )

    assert meta.subtitles
    subtitle_text = meta.subtitles[0].path.read_text(encoding="utf-8")
    assert "hello" in subtitle_text
    assert "world" in subtitle_text


def test_pipeline_remote_mode_requires_platform_transcript(tmp_path):
    class _RemoteAcquirer:
        def acquire(self, input_str, work_dir, opts):
            meta = SourceMeta(
                input=input_str,
                platform=Platform.BILIBILI,
                local_video_path=None,
                title="No transcript",
                subtitle_quality=SubtitleQuality.NONE,
            )
            media = RemoteMediaHandle(
                video_url="https://media.example/video.mp4",
                headers={"Referer": input_str},
                duration=30.0,
                platform=Platform.BILIBILI,
            )
            return media, "no_transcript", meta

    pipeline = Pipeline(
        acquirer=_RemoteAcquirer(),
        transcript_provider=_TranscriptProvider(),
        activity_detector=_FailingActivityDetector(),
        vision=_DummyVision(),
        plugin=_DummyPlugin(),
        cache=NoCache(),
        renderer=_DummyRenderer(),
        cfg=WVConfig(output=tmp_path, media_access="remote", skip=["guide"]),
    )

    with pytest.raises(DecisionRequired) as exc_info:
        pipeline.run("https://www.bilibili.com/video/BV1xx411c7mD")

    decision = exc_info.value
    assert decision.kind == "remote_to_download"
    assert decision.reason_code == "platform_subtitles_unavailable"
    assert decision.stage == "transcript"
    assert decision.default_option == "download"


def test_pipeline_remote_mode_skips_activity_and_uses_uniform_sampling(tmp_path, monkeypatch):
    subtitle_path = tmp_path / "seed.srt"
    subtitle_path.write_text("1\n00:00:00,000 --> 00:00:02,000\nhello\n", encoding="utf-8")

    class _RemoteAcquirer:
        def acquire(self, input_str, work_dir, opts):
            meta = SourceMeta(
                input=input_str,
                platform=Platform.BILIBILI,
                local_video_path=None,
                title="Remote",
                duration=30.0,
                subtitles=[SubtitleTrack(lang="zh", fmt="srt", path=subtitle_path)],
                subtitle_quality=SubtitleQuality.SENTENCE_LEVEL,
            )
            media = RemoteMediaHandle(
                video_url="https://media.example/video.mp4",
                headers={"Referer": input_str},
                duration=30.0,
                platform=Platform.BILIBILI,
            )
            return media, "remote_demo", meta

    explain_seg = Segment(start=0, end=2, text="explain")
    operate_seg = Segment(start=2, end=12, text="operate")
    step = RepeatStep(
        index=0,
        explain=Window(start=0, end=2, type=WindowType.EXPLAIN, transcript_segments=[explain_seg]),
        operate=Window(
            start=2,
            end=12,
            type=WindowType.OPERATE,
            transcript_segments=[operate_seg],
            needs_visual_evidence=True,
        ),
    )

    recorded = []

    def fake_extract_frame(media, timestamp, out_path):
        recorded.append((media, timestamp, out_path))
        out_path.write_bytes(b"fake")

    monkeypatch.setattr(
        "withvideo.pipeline._build_timeline",
        lambda transcript, profile, meta, cfg, work_dir: [step],
    )
    monkeypatch.setattr("withvideo.pipeline._extract_frame", fake_extract_frame)
    monkeypatch.setattr("withvideo.pipeline._analyze_window", lambda window, vision, plugin: None)
    monkeypatch.setattr("withvideo.pipeline._probe_duration", lambda media: 30.0)

    pipeline = Pipeline(
        acquirer=_RemoteAcquirer(),
        transcript_provider=_TranscriptProvider(),
        activity_detector=_FailingActivityDetector(),
        vision=_DummyVision(),
        plugin=_DummyPlugin(),
        cache=NoCache(),
        renderer=_DummyRenderer(),
        cfg=WVConfig(output=tmp_path, media_access="remote", vision="claude", skip=["guide"]),
    )

    out_dir = pipeline.run("https://www.bilibili.com/video/BV1xx411c7mD")

    assert out_dir == tmp_path / "remote_demo"
    assert recorded
    assert all(isinstance(media, RemoteMediaHandle) for media, _, _ in recorded)
    assert all("_uniform" in path.name for _, _, path in recorded)


def test_pipeline_emits_stage_and_artifact_events(tmp_path, monkeypatch):
    subtitle_path = tmp_path / "seed.srt"
    subtitle_path.write_text("1\n00:00:00,000 --> 00:00:02,000\nhello\n", encoding="utf-8")
    stdout = io.StringIO()
    stderr = io.StringIO()

    class _RemoteAcquirer:
        def acquire(self, input_str, work_dir, opts):
            work_dir.mkdir(parents=True, exist_ok=True)
            (work_dir / "source.info.json").write_text("{}", encoding="utf-8")
            subtitles_dir = work_dir / "subtitles"
            subtitles_dir.mkdir(exist_ok=True)
            copied_sub = subtitles_dir / "demo.srt"
            copied_sub.write_text(subtitle_path.read_text(encoding="utf-8"), encoding="utf-8")
            meta = SourceMeta(
                input=input_str,
                platform=Platform.BILIBILI,
                local_video_path=None,
                title="Remote",
                duration=30.0,
                subtitles=[SubtitleTrack(lang="zh", fmt="srt", path=copied_sub)],
                subtitle_quality=SubtitleQuality.SENTENCE_LEVEL,
            )
            media = RemoteMediaHandle(
                video_url="https://media.example/video.mp4",
                headers={"Referer": input_str},
                duration=30.0,
                platform=Platform.BILIBILI,
            )
            return media, "remote_events", meta

    explain_seg = Segment(start=0, end=2, text="explain")
    step = RepeatStep(
        index=0,
        explain=Window(start=0, end=2, type=WindowType.EXPLAIN, transcript_segments=[explain_seg]),
        time_range=(0.0, 2.0),
    )

    monkeypatch.setattr(
        "withvideo.pipeline._build_timeline",
        lambda transcript, profile, meta, cfg, work_dir: [step],
    )

    pipeline = Pipeline(
        acquirer=_RemoteAcquirer(),
        transcript_provider=_TranscriptProvider(),
        activity_detector=_FailingActivityDetector(),
        vision=_DummyVision(),
        plugin=_DummyPlugin(),
        cache=NoCache(),
        renderer=_DummyRenderer(),
        cfg=WVConfig(output=tmp_path, media_access="remote", vision="none", skip=["guide"]),
        reporter=RunReporter(emit_jsonl=True, stdout=stdout, stderr=stderr, human_enabled=False),
    )

    out_dir = pipeline.run("https://www.bilibili.com/video/BV1xx411c7mD")

    assert out_dir == tmp_path / "remote_events"
    events = [json.loads(line) for line in stdout.getvalue().splitlines() if line.strip()]
    event_types = [event["type"] for event in events]
    assert "stage_started" in event_types
    assert "stage_completed" in event_types
    artifact_events = [event for event in events if event["type"] == "artifact_written"]
    artifact_types = {event["context"]["artifact_type"] for event in artifact_events}
    assert "source_info" in artifact_types
    assert "subtitle_track" in artifact_types
    stages = {(event["type"], event["stage"]) for event in events}
    assert ("stage_started", "acquire") in stages
    assert ("stage_completed", "transcript") in stages


def test_ffmpeg_input_args_include_remote_headers():
    media = RemoteMediaHandle(
        video_url="https://media.example/video.mp4",
        headers={
            "Referer": "https://www.bilibili.com/video/BV1xx411c7mD",
            "User-Agent": "WithVideoTest/1.0",
            "Cookie": "SESSDATA=abc",
        },
        duration=42.0,
        platform=Platform.BILIBILI,
    )

    args = _ffmpeg_input_args(media)

    assert args[-2:] == ["-i", "https://media.example/video.mp4"]
    assert "-user_agent" in args
    assert "WithVideoTest/1.0" in args
    headers_value = args[args.index("-headers") + 1]
    assert "Referer: https://www.bilibili.com/video/BV1xx411c7mD\r\n" in headers_value
    assert "Cookie: SESSDATA=abc\r\n" in headers_value


def test_pipeline_merges_staging_into_existing_work_dir(tmp_path):
    staging = tmp_path / "_staging"
    work_dir = tmp_path / "demo"
    staging.mkdir()
    work_dir.mkdir()
    (work_dir / "old.txt").write_text("old", encoding="utf-8")
    (staging / "source.info.json").write_text("{}", encoding="utf-8")

    from withvideo.pipeline import _materialize_staging_dir

    _materialize_staging_dir(staging, work_dir)

    assert not staging.exists()
    assert (work_dir / "old.txt").read_text(encoding="utf-8") == "old"
    assert (work_dir / "source.info.json").read_text(encoding="utf-8") == "{}"


def test_local_file_media_handle_stays_local(tmp_path):
    video_path = tmp_path / "local.mp4"
    video_path.write_bytes(b"not-a-real-video")

    from withvideo.impl.acquirers.local_file import LocalFileAcquirer

    media, video_name, meta = LocalFileAcquirer(WVConfig(media_access="remote")).acquire(
        str(video_path),
        tmp_path / "unused",
        {},
    )

    assert isinstance(media, LocalMediaHandle)
    assert media.path == video_path.resolve()
    assert meta.local_video_path == video_path.resolve()
    assert video_name == "local"
