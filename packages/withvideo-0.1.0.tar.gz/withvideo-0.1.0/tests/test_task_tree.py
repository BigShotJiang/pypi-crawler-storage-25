"""Unit tests for RunReporter task-tree event model."""

import io
import json

import pytest

from withvideo.runtime import RunReporter


def _make_reporter(emit_jsonl=True):
    stdout = io.StringIO()
    stderr = io.StringIO()
    return RunReporter(
        run_id="test-run",
        emit_jsonl=emit_jsonl,
        stdout=stdout,
        stderr=stderr,
    ), stdout, stderr


def _events(stdout):
    return [json.loads(line) for line in stdout.getvalue().splitlines() if line.strip()]


# ---------------------------------------------------------------------------
# task_started / task_completed
# ---------------------------------------------------------------------------

def test_task_started_emits_jsonl():
    r, stdout, _ = _make_reporter()
    r.task_started("acquire.fetch", "fetch video")
    events = _events(stdout)
    assert len(events) == 1
    e = events[0]
    assert e["type"] == "task_started"
    assert e["task_id"] == "acquire.fetch"
    assert e["stage"] == "acquire"
    assert e["depth"] == 0  # no parent in stack → depth 0
    assert e["message"] == "fetch video"


def test_task_completed_emits_jsonl_with_elapsed():
    r, stdout, _ = _make_reporter()
    r.task_started("acquire.fetch", "fetch video")
    r.task_completed("acquire.fetch", "done")
    events = _events(stdout)
    assert events[-1]["type"] == "task_completed"
    assert events[-1]["task_id"] == "acquire.fetch"
    assert "elapsed_s" in events[-1]["context"]


def test_task_completed_pops_stack():
    r, _, _ = _make_reporter()
    r.task_started("acquire.fetch", "fetch video")
    assert len(r._task_stack) == 1
    r.task_completed("acquire.fetch")
    assert len(r._task_stack) == 0


# ---------------------------------------------------------------------------
# Nested tasks — depth and parent_id
# ---------------------------------------------------------------------------

def test_nested_task_gets_correct_depth_and_parent():
    r, stdout, _ = _make_reporter()
    r.task_started("vision", "vision stage")
    r.task_started("vision.extract", "extract keyframes")
    events = _events(stdout)
    parent_event = events[0]
    child_event = events[1]
    assert parent_event["depth"] == 0
    assert child_event["depth"] == 1
    assert child_event["parent_task_id"] == "vision"
    assert "parent_task_id" not in parent_event


def test_deeply_nested_task():
    r, stdout, _ = _make_reporter()
    r.task_started("vision", "vision stage")
    r.task_started("vision.analyze", "analyze frames")
    r.task_started("vision.analyze.step-1", "step 1")
    events = _events(stdout)
    assert events[0]["depth"] == 0
    assert events[1]["depth"] == 1
    assert events[2]["depth"] == 2
    assert events[2]["parent_task_id"] == "vision.analyze"


def test_nested_completed_in_order():
    r, stdout, _ = _make_reporter()
    r.task_started("vision", "vision stage")
    r.task_started("vision.analyze", "analyze frames")
    r.task_completed("vision.analyze")
    r.task_completed("vision")
    assert len(r._task_stack) == 0
    events = _events(stdout)
    types = [e["type"] for e in events]
    assert types == ["task_started", "task_started", "task_completed", "task_completed"]


# ---------------------------------------------------------------------------
# task_progress
# ---------------------------------------------------------------------------

def test_task_progress_emits_jsonl():
    r, stdout, _ = _make_reporter()
    r.task_started("vision.extract", "extract", total=5)
    r.task_progress("vision.extract", 3, message="3 frames done")
    events = _events(stdout)
    prog = events[-1]
    assert prog["type"] == "task_progress"
    assert prog["task_id"] == "vision.extract"
    assert prog["context"]["current"] == 3
    assert prog["context"]["total"] == 5


def test_task_progress_updates_node_current():
    r, _, _ = _make_reporter()
    r.task_started("vision.extract", "extract", total=5)
    r.task_progress("vision.extract", 3)
    node = r._find_task("vision.extract")
    assert node.current == 3


# ---------------------------------------------------------------------------
# task() context manager
# ---------------------------------------------------------------------------

def test_task_context_manager_completes_on_success():
    r, stdout, _ = _make_reporter()
    with r.task("acquire.fetch", "fetch"):
        pass
    events = _events(stdout)
    types = [e["type"] for e in events]
    assert "task_started" in types
    assert "task_completed" in types
    assert "task_failed" not in types


def test_task_context_manager_fails_on_exception():
    r, stdout, _ = _make_reporter()
    with pytest.raises(ValueError):
        with r.task("acquire.fetch", "fetch"):
            raise ValueError("boom")
    events = _events(stdout)
    types = [e["type"] for e in events]
    assert "task_failed" in types
    assert "task_completed" not in types


def test_task_context_manager_pops_stack_on_exception():
    r, _, _ = _make_reporter()
    with pytest.raises(RuntimeError):
        with r.task("acquire.fetch", "fetch"):
            raise RuntimeError("oops")
    assert len(r._task_stack) == 0


def test_task_context_manager_nested():
    r, stdout, _ = _make_reporter()
    with r.task("vision", "vision stage"):
        with r.task("vision.analyze", "analyze"):
            pass
    events = _events(stdout)
    types = [e["type"] for e in events]
    assert types.count("task_started") == 2
    assert types.count("task_completed") == 2


# ---------------------------------------------------------------------------
# stage_started / stage_completed bridge
# ---------------------------------------------------------------------------

def test_stage_started_emits_both_legacy_and_task_events():
    r, stdout, _ = _make_reporter()
    r.stage_started("acquire", "Acquire started")
    events = _events(stdout)
    types = [e["type"] for e in events]
    assert "stage_started" in types
    assert "task_started" in types


def test_stage_completed_emits_both_legacy_and_task_events():
    r, stdout, _ = _make_reporter()
    r.stage_started("acquire", "Acquire started")
    r.stage_completed("acquire", "done")
    events = _events(stdout)
    types = [e["type"] for e in events]
    assert "stage_completed" in types
    assert "task_completed" in types


def test_stage_started_task_has_depth_zero():
    r, stdout, _ = _make_reporter()
    r.stage_started("acquire", "Acquire started")
    events = _events(stdout)
    task_event = next(e for e in events if e["type"] == "task_started")
    assert task_event["depth"] == 0


def test_subtask_inside_stage_has_depth_one():
    r, stdout, _ = _make_reporter()
    r.stage_started("acquire", "Acquire started")
    r.task_started("acquire.fetch", "fetch")
    events = _events(stdout)
    subtask_event = next(e for e in events if e.get("task_id") == "acquire.fetch")
    assert subtask_event["depth"] == 1
    assert subtask_event["parent_task_id"] == "acquire"


# ---------------------------------------------------------------------------
# Human-readable output
# ---------------------------------------------------------------------------

def test_task_started_prints_indented_arrow(capsys):
    r = RunReporter(run_id="x", emit_jsonl=False)
    r.task_started("vision", "vision stage")
    r.task_started("vision.analyze", "analyze frames")
    captured = capsys.readouterr()
    lines = captured.err.splitlines()
    assert any("▶ vision stage" in l and not l.startswith("[wv]   ") for l in lines)
    assert any("▶ analyze frames" in l and "  " in l for l in lines)


def test_task_completed_prints_checkmark(capsys):
    r = RunReporter(run_id="x", emit_jsonl=False)
    r.task_started("acquire.fetch", "fetch video")
    r.task_completed("acquire.fetch", "done")
    captured = capsys.readouterr()
    assert any("✓" in l and "fetch video" in l for l in captured.err.splitlines())


def test_task_failed_prints_cross(capsys):
    r = RunReporter(run_id="x", emit_jsonl=False)
    r.task_started("acquire.fetch", "fetch video")
    r.task_failed("acquire.fetch", "network error")
    captured = capsys.readouterr()
    assert any("✗" in l and "fetch video" in l for l in captured.err.splitlines())


def test_progress_shows_count(capsys):
    r = RunReporter(run_id="x", emit_jsonl=False)
    r.task_started("vision.extract", "extract keyframes", total=5)
    r.task_progress("vision.extract", 3, message="3 frames")
    captured = capsys.readouterr()
    assert any("[3/5]" in l for l in captured.err.splitlines())


# ---------------------------------------------------------------------------
# Old events unaffected
# ---------------------------------------------------------------------------

def test_run_started_no_task_fields():
    r, stdout, _ = _make_reporter()
    r.run_started(input_value="test.mp4")
    events = _events(stdout)
    assert events[0]["type"] == "run_started"
    assert "task_id" not in events[0]


def test_stage_completed_legacy_event_has_no_task_id():
    r, stdout, _ = _make_reporter()
    r.stage_started("acquire", "started")
    r.stage_completed("acquire", "done")
    events = _events(stdout)
    legacy = next(e for e in events if e["type"] == "stage_completed")
    assert "task_id" not in legacy
