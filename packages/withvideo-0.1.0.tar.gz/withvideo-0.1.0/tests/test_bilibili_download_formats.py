import unittest
from pathlib import Path

from withvideo.config import WVConfig
from withvideo.impl.acquirers.bilibili import BilibiliAcquirer
from withvideo.models import Platform


class BilibiliDownloadFormatTests(unittest.TestCase):
    def test_download_mode_prefers_720p_dash_streams_with_graceful_fallback(self) -> None:
        # Bilibili serves DASH-only (video-only + audio-only); there are no
        # combined single-file streams. Acquirer prefers 720p+ for frame
        # extraction quality, then falls back step by step.
        opts = BilibiliAcquirer(WVConfig())._build_opts(Platform.BILIBILI, Path("/tmp"), {})

        self.assertEqual(
            opts["format"],
            "bestvideo[height>=720][height<=1080]+bestaudio"
            "/bestvideo[height>=720]+bestaudio"
            "/bestvideo[height<=1080]+bestaudio"
            "/bestvideo+bestaudio"
            "/best",
        )


if __name__ == "__main__":
    unittest.main()
