import json
import tempfile
import unittest
import io
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.models import ActivityProfile, Platform, RepeatStep, Segment, SourceMeta, TranscriptSource, Window, WindowType
from withvideo.pipeline import _generate_guide, _run_llm_command, _semantic_judgment
from withvideo.runtime import DecisionRequired, RunReporter, use_reporter


class LlmCommandTests(unittest.TestCase):
    def test_semantic_judgment_uses_configured_non_codex_llm_command_placeholder(self) -> None:
        cfg = WVConfig(llm_command="openclaw run --prompt {prompt}", llm_timeout=321)
        topic_blocks = [{"index": 0, "start": 0.0, "end": 4.0, "text": "open settings"}]
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            with patch("withvideo.pipeline.subprocess.run") as mock_run:
                mock_run.return_value.stdout = '[{"index": 0, "intent": "explain"}]'
                mock_run.return_value.stderr = ""
                mock_run.return_value.returncode = 0

                result = _semantic_judgment(topic_blocks, ActivityProfile(per_second=[], threshold=0.0, bursts=[]), cfg, work_dir)

                self.assertEqual(result, [{"index": 0, "intent": "explain"}])
                cmd = mock_run.call_args.args[0]
                self.assertEqual(cmd[:3], ["openclaw", "run", "--prompt"])
                self.assertIn("semantic_input.json", cmd[3])
                self.assertNotIn("open settings", cmd[3])
                self.assertEqual(mock_run.call_args.kwargs["timeout"], 321)
                prompt_path = work_dir / "llm" / "semantic_prompt.txt"
                input_path = work_dir / "llm" / "semantic_input.json"
                raw_path = work_dir / "llm" / "semantic_output.raw.txt"
                self.assertTrue(prompt_path.exists())
                self.assertTrue(input_path.exists())
                self.assertTrue(raw_path.exists())
                payload = json.loads(input_path.read_text(encoding="utf-8"))
                self.assertEqual(payload["topic_blocks"][0]["text"], "open settings")

    def test_semantic_judgment_appends_prompt_when_placeholder_missing(self) -> None:
        cfg = WVConfig(llm_command="openclaw run")
        topic_blocks = [{"index": 0, "start": 0.0, "end": 4.0, "text": "open settings"}]
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            with patch("withvideo.pipeline.subprocess.run") as mock_run:
                mock_run.return_value.stdout = '[{"index": 0, "intent": "explain"}]'
                mock_run.return_value.stderr = ""
                mock_run.return_value.returncode = 0

                _semantic_judgment(topic_blocks, ActivityProfile(per_second=[], threshold=0.0, bursts=[]), cfg, work_dir)
                cmd = mock_run.call_args.args[0]
                self.assertEqual(cmd[:2], ["openclaw", "run"])
                self.assertIn("semantic_input.json", cmd[2])
                self.assertTrue((work_dir / "llm" / "semantic_prompt.txt").exists())

    def test_generate_guide_uses_configured_llm_command(self) -> None:
        cfg = WVConfig(llm_command="openclaw run --prompt {prompt}", llm_timeout=654)
        steps = [
            RepeatStep(
                index=0,
                explain=Window(
                    start=0.0,
                    end=3.0,
                    type=WindowType.EXPLAIN,
                    transcript_segments=[Segment(start=0.0, end=3.0, text="先打开设置页面")],
                ),
                time_range=(0.0, 3.0),
            )
        ]
        meta = SourceMeta(
            input="demo.mp4",
            platform=Platform.LOCAL_FILE,
            local_video_path=Path("demo.mp4"),
            title="Demo",
        )
        plugin = SimpleNamespace(name="general", selected_name="general")
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            with patch("withvideo.pipeline.subprocess.run") as mock_run:
                mock_run.return_value.stdout = (
                    '{"overview":"概览","prerequisites":["已安装"],'
                    '"step_titles":["打开设置"],"knowledge_points":[["知道入口"]]}'
                )
                mock_run.return_value.stderr = ""
                mock_run.return_value.returncode = 0

                guide = _generate_guide(steps, plugin, meta, cfg, work_dir)
                self.assertEqual(guide.overview, "概览")
                self.assertEqual(guide.steps[0].title, "打开设置")
                cmd = mock_run.call_args.args[0]
                self.assertEqual(cmd[:3], ["openclaw", "run", "--prompt"])
                self.assertIn("guide_input.json", cmd[3])
                self.assertNotIn("先打开设置页面", cmd[3])
                self.assertEqual(mock_run.call_args.kwargs["timeout"], 654)
                prompt_path = work_dir / "llm" / "guide_prompt.txt"
                input_path = work_dir / "llm" / "guide_input.json"
                raw_path = work_dir / "llm" / "guide_output.raw.txt"
                self.assertTrue(prompt_path.exists())
                self.assertTrue(input_path.exists())
                self.assertTrue(raw_path.exists())
                payload = json.loads(input_path.read_text(encoding="utf-8"))
                self.assertEqual(payload["title"], "Demo")
                self.assertEqual(payload["steps"][0]["explain_text"], "先打开设置页面")

    def test_run_llm_command_uses_stdin_when_command_contains_dash_sentinel(self) -> None:
        cfg = WVConfig(llm_command="codex exec -", llm_timeout=123)

        with patch("withvideo.pipeline.subprocess.run") as mock_run:
            mock_run.return_value = SimpleNamespace(stdout='[{"index": 0, "intent": "explain"}]', stderr="", returncode=0)
            result = _run_llm_command("classify this", cfg, timeout=cfg.llm_timeout)

        self.assertEqual(result, '[{"index": 0, "intent": "explain"}]')
        cmd = mock_run.call_args.args[0]
        self.assertEqual(cmd, ["codex", "exec", "-"])
        self.assertEqual(mock_run.call_args.kwargs["input"], "classify this")
        self.assertEqual(mock_run.call_args.kwargs["timeout"], 123)

    def test_run_llm_command_raises_on_non_zero_exit(self) -> None:
        cfg = WVConfig(llm_command="openclaw run -", llm_timeout=99)

        with tempfile.TemporaryDirectory() as tmp:
            raw_path = Path(tmp) / "semantic_output.raw.txt"
            with patch("withvideo.pipeline.subprocess.run") as mock_run:
                mock_run.return_value = SimpleNamespace(stdout="partial", stderr="boom", returncode=2)
                with self.assertRaises(RuntimeError) as exc_info:
                    _run_llm_command("hello", cfg, timeout=cfg.llm_timeout, raw_output_path=raw_path)
                self.assertEqual(raw_path.read_text(encoding="utf-8"), "partial")

        self.assertEqual(str(exc_info.exception), "LLM command failed: boom")

    def test_semantic_judgment_preserves_full_payload_and_reports_invalid_json_artifacts(self) -> None:
        cfg = WVConfig(llm_command="openclaw run --prompt {prompt}", llm_timeout=50)
        long_text = "A" * 900
        topic_blocks = [{"index": 0, "start": 0.0, "end": 4.0, "text": long_text}]
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            stdout = io.StringIO()
            stderr = io.StringIO()
            reporter = RunReporter(emit_jsonl=True, stdout=stdout, stderr=stderr)
            with patch("withvideo.pipeline.subprocess.run") as mock_run, use_reporter(reporter):
                mock_run.return_value.stdout = "not json"
                mock_run.return_value.stderr = ""
                mock_run.return_value.returncode = 0
                with self.assertRaises(DecisionRequired) as exc_info:
                    _semantic_judgment(topic_blocks, ActivityProfile(per_second=[], threshold=0.0, bursts=[]), cfg, work_dir)
                payload = json.loads((work_dir / "llm" / "semantic_input.json").read_text(encoding="utf-8"))
                self.assertEqual(payload["topic_blocks"][0]["text"], long_text)
                self.assertEqual(
                    (work_dir / "llm" / "semantic_output.raw.txt").read_text(encoding="utf-8"),
                    "not json",
                )
                self.assertEqual(exc_info.exception.kind, "llm_stage_retry_or_abort")
                self.assertEqual(exc_info.exception.stage, "semantic")
                self.assertIn("semantic_output.raw.txt", stderr.getvalue())
                events = [json.loads(line) for line in stdout.getvalue().splitlines() if line.strip()]
                artifact_types = {event["context"]["artifact_type"] for event in events if event["type"] == "artifact_written"}
                self.assertIn("semantic_input", artifact_types)
                self.assertIn("semantic_prompt", artifact_types)
                self.assertIn("semantic_output.raw", artifact_types)


if __name__ == "__main__":
    unittest.main()
