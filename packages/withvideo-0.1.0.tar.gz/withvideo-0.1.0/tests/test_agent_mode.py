"""Tests for --decision-mode agent: bidirectional JSONL protocol."""

import io
import json

import pytest

from withvideo.runtime import (
    AgentDecisionError,
    DecisionRequired,
    RunReporter,
    read_agent_decision,
)


def _decision(kind="platform_subtitles_to_whisper", options=None, stage="transcript"):
    return DecisionRequired(
        kind=kind,
        reason_code="platform_subtitles_unreliable",
        message="Platform subtitles are unreliable",
        options=options or ["mlx-whisper", "abort"],
        default_option="mlx-whisper",
        stage=stage,
    )


def _stdin(line: str) -> io.StringIO:
    return io.StringIO(line if line.endswith("\n") else line + "\n")


# ---------------------------------------------------------------------------
# read_agent_decision — happy path
# ---------------------------------------------------------------------------

def test_read_agent_decision_returns_selected():
    decision = _decision()
    stdin = _stdin('{"kind": "platform_subtitles_to_whisper", "selected": "mlx-whisper"}')
    result = read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert result == "mlx-whisper"


def test_read_agent_decision_abort_is_valid_option():
    decision = _decision()
    stdin = _stdin('{"kind": "platform_subtitles_to_whisper", "selected": "abort"}')
    result = read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert result == "abort"


def test_read_agent_decision_different_kind():
    decision = _decision(kind="remote_to_download", options=["download", "abort"])
    stdin = _stdin('{"kind": "remote_to_download", "selected": "download"}')
    result = read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert result == "download"


# ---------------------------------------------------------------------------
# read_agent_decision — EOF / empty stdin → timeout
# ---------------------------------------------------------------------------

def test_read_agent_decision_eof_raises_timeout():
    decision = _decision()
    stdin = io.StringIO("")  # EOF immediately
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_stdin_timeout"


# ---------------------------------------------------------------------------
# read_agent_decision — invalid JSON
# ---------------------------------------------------------------------------

def test_read_agent_decision_invalid_json():
    decision = _decision()
    stdin = _stdin("not-json")
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_stdin_invalid_json"


def test_read_agent_decision_json_array_not_object():
    decision = _decision()
    stdin = _stdin('["mlx-whisper"]')
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_stdin_invalid_json"


# ---------------------------------------------------------------------------
# read_agent_decision — kind mismatch
# ---------------------------------------------------------------------------

def test_read_agent_decision_kind_mismatch():
    decision = _decision(kind="platform_subtitles_to_whisper")
    stdin = _stdin('{"kind": "remote_to_download", "selected": "download"}')
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_decision_kind_mismatch"


def test_read_agent_decision_missing_kind():
    decision = _decision()
    stdin = _stdin('{"selected": "mlx-whisper"}')
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_decision_kind_mismatch"


# ---------------------------------------------------------------------------
# read_agent_decision — invalid option
# ---------------------------------------------------------------------------

def test_read_agent_decision_invalid_option():
    decision = _decision()
    stdin = _stdin('{"kind": "platform_subtitles_to_whisper", "selected": "skip"}')
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_decision_invalid_option"


def test_read_agent_decision_missing_selected():
    decision = _decision()
    stdin = _stdin('{"kind": "platform_subtitles_to_whisper"}')
    with pytest.raises(AgentDecisionError) as exc_info:
        read_agent_decision(decision, stdin=stdin, timeout=1.0)
    assert exc_info.value.error_code == "agent_decision_invalid_option"


# ---------------------------------------------------------------------------
# AgentDecisionError str
# ---------------------------------------------------------------------------

def test_agent_decision_error_str():
    err = AgentDecisionError(error_code="agent_stdin_timeout", message="timed out")
    assert str(err) == "timed out"


# ---------------------------------------------------------------------------
# run_completed context enrichment
# ---------------------------------------------------------------------------

def _make_reporter():
    stdout = io.StringIO()
    stderr = io.StringIO()
    return (
        RunReporter(run_id="r1", emit_jsonl=True, stdout=stdout, stderr=stderr),
        stdout,
    )


def _events(stdout):
    return [json.loads(line) for line in stdout.getvalue().splitlines() if line.strip()]


def test_run_completed_includes_artifacts():
    reporter, stdout = _make_reporter()
    reporter.run_completed(
        output_path="/tmp/guide.md",
        context={"artifacts": {"guide_md": "/tmp/guide.md", "semantic_json": "/tmp/semantic.json"}},
    )
    events = _events(stdout)
    assert len(events) == 1
    ev = events[0]
    assert ev["type"] == "run_completed"
    assert ev["context"]["output_path"] == "/tmp/guide.md"
    assert ev["context"]["artifacts"]["guide_md"] == "/tmp/guide.md"
    assert ev["context"]["artifacts"]["semantic_json"] == "/tmp/semantic.json"


def test_run_completed_no_context():
    """Backward compat: context is optional."""
    reporter, stdout = _make_reporter()
    reporter.run_completed(output_path="/tmp/guide.md")
    events = _events(stdout)
    assert events[0]["context"]["output_path"] == "/tmp/guide.md"


# ---------------------------------------------------------------------------
# run_failed error_code
# ---------------------------------------------------------------------------

def test_run_failed_with_error_code():
    reporter, stdout = _make_reporter()
    reporter.run_failed(
        "something went wrong",
        context={"error_code": "unexpected", "recoverable": False},
    )
    events = _events(stdout)
    assert events[0]["context"]["error_code"] == "unexpected"
    assert events[0]["context"]["recoverable"] is False
