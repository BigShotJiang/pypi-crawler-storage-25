import tempfile
import unittest
from http.cookiejar import Cookie, CookieJar
from pathlib import Path
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.impl.acquirers.bilibili import BilibiliAcquirer
from withvideo.impl.acquirers.auth import (
    BilibiliAuthManager,
    BrowserSpec,
    _cookie_matches_domain,
    parse_browser_spec,
)


def _cookie(domain: str, name: str = "SESSDATA", value: str = "token") -> Cookie:
    return Cookie(
        version=0,
        name=name,
        value=value,
        port=None,
        port_specified=False,
        domain=domain,
        domain_specified=True,
        domain_initial_dot=domain.startswith("."),
        path="/",
        path_specified=True,
        secure=True,
        expires=None,
        discard=True,
        comment=None,
        comment_url=None,
        rest={},
        rfc2109=False,
    )


class BrowserSpecTests(unittest.TestCase):
    def test_parse_browser_spec_supports_profile(self) -> None:
        spec = parse_browser_spec("chrome:Default")
        self.assertEqual(
            spec,
            BrowserSpec(browser="chrome", profile="Default", keyring=None, container=None),
        )

    def test_parse_browser_spec_supports_keyring_profile_and_container(self) -> None:
        spec = parse_browser_spec("firefox+basictext:Profile 1::work")
        self.assertEqual(
            spec,
            BrowserSpec(browser="firefox", profile="Profile 1", keyring="basictext", container="work"),
        )

    def test_cookie_matches_domain_uses_site_scope(self) -> None:
        self.assertTrue(_cookie_matches_domain(_cookie(".bilibili.com"), "bilibili.com"))
        self.assertTrue(_cookie_matches_domain(_cookie("api.bilibili.com"), "bilibili.com"))
        self.assertFalse(_cookie_matches_domain(_cookie(".example.com"), "bilibili.com"))


class BilibiliAuthManagerTests(unittest.TestCase):
    def test_first_browser_import_creates_site_scoped_cache_and_prints_notice(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cache_root = Path(tmp)
            config = WVConfig(cookies_from_browser="chrome:Default")
            manager = BilibiliAuthManager(config, cache_root)
            cookiejar = CookieJar()
            cookiejar.set_cookie(_cookie(".bilibili.com"))
            cookiejar.set_cookie(_cookie(".example.com", name="other"))

            with patch("withvideo.impl.acquirers.auth.extract_cookies_from_browser", return_value=cookiejar) as mock_extract, \
                 patch("builtins.print") as mock_print:
                cookiefile = manager.resolve_cookiefile()
                self.assertIsNotNone(cookiefile)
                self.assertTrue(cookiefile.exists())
                contents = cookiefile.read_text(encoding="utf-8")
                self.assertIn("bilibili.com", contents)
                self.assertNotIn("example.com", contents)
                mock_extract.assert_called_once()
                mock_print.assert_called()

    def test_second_run_reuses_cache_without_browser_access(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cache_root = Path(tmp)
            config = WVConfig(cookies_from_browser="chrome")
            manager = BilibiliAuthManager(config, cache_root)
            cookiejar = CookieJar()
            cookiejar.set_cookie(_cookie(".bilibili.com"))

            with patch("withvideo.impl.acquirers.auth.extract_cookies_from_browser", return_value=cookiejar):
                first_cookiefile = manager.resolve_cookiefile()

            with patch("withvideo.impl.acquirers.auth.extract_cookies_from_browser") as mock_extract, \
                 patch("builtins.print") as mock_print:
                second_cookiefile = manager.resolve_cookiefile()

        self.assertEqual(first_cookiefile, second_cookiefile)
        mock_extract.assert_not_called()
        mock_print.assert_not_called()

    def test_manual_cookie_file_overrides_browser_import(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cache_root = Path(tmp)
            manual_cookiefile = cache_root / "manual.cookies.txt"
            manual_cookiefile.write_text("# Netscape HTTP Cookie File\n", encoding="utf-8")
            config = WVConfig(cookies=str(manual_cookiefile), cookies_from_browser="chrome")
            manager = BilibiliAuthManager(config, cache_root)

            with patch("withvideo.impl.acquirers.auth.extract_cookies_from_browser") as mock_extract:
                cookiefile = manager.resolve_cookiefile()

        self.assertEqual(cookiefile, manual_cookiefile)
        mock_extract.assert_not_called()

    def test_refresh_rebuilds_cache_after_failure(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cache_root = Path(tmp)
            config = WVConfig(cookies_from_browser="chrome")
            manager = BilibiliAuthManager(config, cache_root)

            first = CookieJar()
            first.set_cookie(_cookie(".bilibili.com", value="old"))
            second = CookieJar()
            second.set_cookie(_cookie(".bilibili.com", value="new"))

            with patch("withvideo.impl.acquirers.auth.extract_cookies_from_browser", side_effect=[first, second]):
                initial_cookiefile = manager.resolve_cookiefile()
                self.assertIn("old", initial_cookiefile.read_text(encoding="utf-8"))
                refreshed_cookiefile = manager.refresh_cookiefile()
                self.assertEqual(initial_cookiefile, refreshed_cookiefile)
                self.assertIn("new", refreshed_cookiefile.read_text(encoding="utf-8"))

    def test_browser_permission_denied_falls_back_to_anonymous_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            cache_root = Path(tmp)
            config = WVConfig(cookies_from_browser="chrome:Default")
            manager = BilibiliAuthManager(config, cache_root)

            with patch(
                "withvideo.impl.acquirers.auth.extract_cookies_from_browser",
                side_effect=RuntimeError("Keychain permission denied"),
            ), patch("builtins.print") as mock_print:
                cookiefile = manager.resolve_cookiefile()

        self.assertIsNone(cookiefile)
        self.assertFalse(manager.can_refresh())
        mock_print.assert_called()


class BilibiliAcquirerAuthTests(unittest.TestCase):
    def test_auth_failure_triggers_one_cookie_refresh_and_retry(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            staging = Path(tmp) / "_staging"
            acquirer = BilibiliAcquirer(WVConfig(cookies_from_browser="chrome"))

            with patch.object(BilibiliAuthManager, "resolve_cookiefile", return_value=Path("/tmp/old.cookies.txt")) as mock_resolve, \
                 patch.object(BilibiliAuthManager, "refresh_cookiefile", return_value=Path("/tmp/new.cookies.txt")) as mock_refresh, \
                 patch.object(BilibiliAuthManager, "can_refresh", return_value=True), \
                 patch("withvideo.impl.acquirers.generic_url.BaseYtdlpAcquirer.acquire", side_effect=[RuntimeError("login required"), ("video", "name", "meta")]) as mock_acquire:
                result = acquirer.acquire("https://www.bilibili.com/video/BV1xx411c7mD", staging, {})

        self.assertEqual(result, ("video", "name", "meta"))
        mock_resolve.assert_called_once()
        mock_refresh.assert_called_once()
        self.assertEqual(mock_acquire.call_count, 2)

    def test_browser_auth_denied_continues_without_retrying_auth(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            staging = Path(tmp) / "_staging"
            acquirer = BilibiliAcquirer(WVConfig(cookies_from_browser="chrome"))

            with patch.object(BilibiliAuthManager, "resolve_cookiefile", return_value=None) as mock_resolve, \
                 patch.object(BilibiliAuthManager, "can_refresh", return_value=False) as mock_can_refresh, \
                 patch.object(BilibiliAuthManager, "refresh_cookiefile") as mock_refresh, \
                 patch("withvideo.impl.acquirers.generic_url.BaseYtdlpAcquirer.acquire", return_value=("video", "name", "meta")) as mock_acquire:
                result = acquirer.acquire("https://www.bilibili.com/video/BV1xx411c7mD", staging, {})

        self.assertEqual(result, ("video", "name", "meta"))
        mock_resolve.assert_called_once()
        mock_can_refresh.assert_not_called()
        mock_refresh.assert_not_called()
        mock_acquire.assert_called_once()
