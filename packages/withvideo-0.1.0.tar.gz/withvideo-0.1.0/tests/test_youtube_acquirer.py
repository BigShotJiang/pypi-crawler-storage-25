import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.impl.acquirers.youtube import YouTubeAcquirer, _preferred_youtube_subtitle_langs
from withvideo.impl.acquirers.common import merge_local_sidecars
from withvideo.models import Platform, SourceMeta, SubtitleQuality


class _FakeFetchedTranscript(list):
    def __init__(self, items, *, language="English", language_code="en", is_generated=False):
        super().__init__(items)
        self.language = language
        self.language_code = language_code
        self.is_generated = is_generated


class _FakeTranscript:
    def __init__(self, *, language="English", language_code="en", is_generated=False):
        self.language = language
        self.language_code = language_code
        self.is_generated = is_generated

    def fetch(self):
        return _FakeFetchedTranscript(
            [
                {"text": "hello", "start": 0.0, "duration": 1.5},
                {"text": "world", "start": 1.5, "duration": 1.0},
            ],
            language=self.language,
            language_code=self.language_code,
            is_generated=self.is_generated,
        )


class _FakeFetchedSnippet:
    def __init__(self, text, start, duration):
        self.text = text
        self.start = start
        self.duration = duration


class _FakeTranscriptList:
    def __init__(self, manual=None, generated=None):
        self._manual = manual
        self._generated = generated

    def find_manually_created_transcript(self, languages):
        if self._manual is None:
            raise RuntimeError("no manual")
        return self._manual

    def find_generated_transcript(self, languages):
        if self._generated is None:
            raise RuntimeError("no generated")
        return self._generated


class _FakeTranscriptApi:
    def __init__(self, transcript_list):
        self._transcript_list = transcript_list

    def list(self, video_id):
        return self._transcript_list


class YouTubeAcquirerTests(unittest.TestCase):
    def test_prefers_original_youtube_caption_language_over_all_languages(self) -> None:
        info = {
            "language": "en",
            "subtitles": {},
            "automatic_captions": {
                "ab": [{}],
                "en-orig": [{}],
                "en": [{}],
                "fr": [{}],
            },
        }

        langs = _preferred_youtube_subtitle_langs(info)

        self.assertEqual(langs, ["en-orig", "en"])

    def test_fallback_materializes_manual_transcript_as_sentence_level(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            meta = SourceMeta(
                input="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                platform=Platform.YOUTUBE,
                local_video_path=work_dir / "source.mp4",
            )
            info = {"webpage_url": meta.input}
            fake_api = _FakeTranscriptApi(_FakeTranscriptList(manual=_FakeTranscript()))

            with patch("withvideo.impl.acquirers.youtube.YouTubeTranscriptApi", return_value=fake_api, create=True):
                YouTubeAcquirer(WVConfig())._enrich_meta(meta.input, info, work_dir, meta)

            self.assertTrue(meta.subtitles[0].path and meta.subtitles[0].path.exists())
            self.assertIn("hello", meta.subtitles[0].path.read_text(encoding="utf-8"))

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.SENTENCE_LEVEL)
        self.assertEqual(len(meta.subtitles), 1)
        self.assertEqual(meta.subtitles[0].lang, "en")
        self.assertFalse(meta.subtitles[0].is_generated)

    def test_fallback_materializes_generated_transcript_as_auto_caption(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            meta = SourceMeta(
                input="https://youtu.be/dQw4w9WgXcQ",
                platform=Platform.YOUTUBE,
                local_video_path=work_dir / "source.mp4",
            )
            info = {"original_url": meta.input}
            fake_api = _FakeTranscriptApi(
                _FakeTranscriptList(generated=_FakeTranscript(language_code="en", is_generated=True))
            )

            with patch("withvideo.impl.acquirers.youtube.YouTubeTranscriptApi", return_value=fake_api, create=True):
                YouTubeAcquirer(WVConfig())._enrich_meta(meta.input, info, work_dir, meta)

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.SENTENCE_LEVEL)
        self.assertFalse(meta.subtitles)
        self.assertEqual(len(meta.auto_captions), 1)
        self.assertTrue(meta.auto_captions[0].is_generated)
        self.assertFalse(meta.auto_captions[0].has_word_timestamps)

    def test_missing_optional_dependency_keeps_youtube_acquisition_degradable(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            meta = SourceMeta(
                input="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                platform=Platform.YOUTUBE,
                local_video_path=work_dir / "source.mp4",
            )
            info = {"webpage_url": meta.input}

            with patch("withvideo.impl.acquirers.youtube.YouTubeTranscriptApi", side_effect=ImportError, create=True), \
                 patch("builtins.print") as mock_print:
                YouTubeAcquirer(WVConfig())._enrich_meta(meta.input, info, work_dir, meta)

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.NONE)
        mock_print.assert_called()

    def test_existing_yt_dlp_subtitles_win_over_transcript_api_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            existing = work_dir / "source.en.vtt"
            existing.write_text("WEBVTT\n\n00:00:00.000 --> 00:00:01.000\nhello\n", encoding="utf-8")
            meta = SourceMeta(
                input="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                platform=Platform.YOUTUBE,
                local_video_path=work_dir / "source.mp4",
                auto_captions=[],
                subtitles=[],
            )
            info = {
                "webpage_url": meta.input,
                "automatic_captions": {"en": [{"ext": "vtt"}]},
            }
            fake_api = _FakeTranscriptApi(_FakeTranscriptList(manual=_FakeTranscript()))

            with patch("withvideo.impl.acquirers.youtube.YouTubeTranscriptApi", return_value=fake_api, create=True):
                acquirer = YouTubeAcquirer(WVConfig())
                rebuilt = acquirer._build_youtube_meta(info, work_dir, meta.video_path)
                merge_local_sidecars(rebuilt, meta.video_path)
                acquirer._enrich_meta(meta.input, info, work_dir, rebuilt)

        self.assertEqual(rebuilt.subtitle_quality, SubtitleQuality.WORD_LEVEL)
        self.assertEqual(len(rebuilt.auto_captions), 1)
        self.assertFalse(any(track.path and track.path.name.startswith("youtube-transcript") for track in rebuilt.subtitles + rebuilt.auto_captions))

    def test_materializes_transcript_api_snippet_objects(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)

            class _ObjTranscript:
                language_code = "en"
                language = "English"
                is_generated = True

                def fetch(self):
                    return [
                        _FakeFetchedSnippet("hello", 0.0, 1.2),
                        _FakeFetchedSnippet("world", 1.2, 0.8),
                    ]

            with patch("withvideo.impl.acquirers.youtube.YouTubeTranscriptApi", return_value=_FakeTranscriptApi(_FakeTranscriptList(generated=_ObjTranscript())), create=True):
                meta = SourceMeta(
                    input="https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                    platform=Platform.YOUTUBE,
                    local_video_path=work_dir / "source.mp4",
                )
                YouTubeAcquirer(WVConfig())._enrich_meta(meta.input, {"webpage_url": meta.input}, work_dir, meta)

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.SENTENCE_LEVEL)
        self.assertEqual(len(meta.auto_captions), 1)


if __name__ == "__main__":
    unittest.main()
