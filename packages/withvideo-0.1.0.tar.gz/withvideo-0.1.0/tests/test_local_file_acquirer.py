import json
import tempfile
import unittest
from pathlib import Path

from withvideo.config import WVConfig
from withvideo.impl.acquirers.local_file import LocalFileAcquirer
from withvideo.models import Platform, SubtitleQuality


class LocalFileAcquirerTests(unittest.TestCase):
    def test_local_raw_video_without_sidecars_returns_none_subtitles(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            video_path = Path(tmp) / "lesson.mp4"
            video_path.write_bytes(b"")

            _, video_name, meta = LocalFileAcquirer(WVConfig()).acquire(str(video_path), Path(tmp) / "out", {})

        self.assertEqual(video_name, "lesson")
        self.assertEqual(meta.platform, Platform.LOCAL_FILE)
        self.assertEqual(meta.subtitle_quality, SubtitleQuality.NONE)
        self.assertEqual(meta.input, str(video_path.resolve()))

    def test_local_video_absorbs_info_json_and_subtitle_sidecars(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            video_path = Path(tmp) / "lesson.mp4"
            video_path.write_bytes(b"")
            (Path(tmp) / "lesson.srt").write_text(
                "1\n00:00:00,000 --> 00:00:01,000\nhello\n",
                encoding="utf-8",
            )
            (Path(tmp) / "lesson.info.json").write_text(
                json.dumps(
                    {
                        "webpage_url": "https://www.youtube.com/watch?v=demo",
                        "title": "Demo Lesson",
                    }
                ),
                encoding="utf-8",
            )

            _, _, meta = LocalFileAcquirer(WVConfig()).acquire(str(video_path), Path(tmp) / "out", {})

        self.assertEqual(meta.platform, Platform.YOUTUBE)
        self.assertEqual(meta.title, "Demo Lesson")
        self.assertEqual(meta.subtitle_quality, SubtitleQuality.SENTENCE_LEVEL)
        self.assertTrue(meta.subtitles)
        self.assertEqual(meta.subtitles[0].path, (Path(tmp) / "lesson.srt").resolve())
        self.assertEqual(meta.input, str(video_path.resolve()))
