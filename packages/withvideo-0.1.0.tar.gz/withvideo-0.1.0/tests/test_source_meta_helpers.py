import tempfile
import unittest
from pathlib import Path

from withvideo.impl.acquirers.common import build_source_meta, merge_local_sidecars
from withvideo.models import Platform, SubtitleQuality


class SourceMetaHelperTests(unittest.TestCase):
    def test_bilibili_missing_subtitle_artifacts_stays_none(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")

            meta = build_source_meta(
                {
                    "title": "Bilibili Demo",
                    "subtitles": {"zh": [{"ext": "srt"}]},
                    "pages": [{"page": 1, "part": "P1", "cid": 123, "duration": 10}],
                },
                Platform.BILIBILI,
                video_path,
                work_dir,
            )

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.NONE)
        self.assertEqual(len(meta.parts), 1)
        self.assertEqual(meta.parts[0].cid, "123")

    def test_bilibili_root_sidecar_subtitle_becomes_unreliable(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "source.ai-zh.srt"
            subtitle_path.write_text("1\n00:00:00,000 --> 00:00:01,000\n你好\n", encoding="utf-8")

            meta = build_source_meta(
                {
                    "title": "Bilibili Demo",
                    "subtitles": {"ai-zh": [{"ext": "srt"}]},
                },
                Platform.BILIBILI,
                video_path,
                work_dir,
            )
            merge_local_sidecars(meta, video_path)

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.UNRELIABLE)
        self.assertTrue(meta.subtitles)
        self.assertEqual(meta.subtitles[0].path, subtitle_path)

    def test_bilibili_high_coverage_sidecar_subtitle_becomes_sentence_level(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "source.ai-zh.srt"
            subtitle_path.write_text(
                "\n\n".join(
                    [
                        "1\n00:00:00,000 --> 00:00:06,000\n大家好今天我们来看这个例子",
                        "2\n00:00:06,100 --> 00:00:12,000\n接下来先打开设置面板确认参数",
                        "3\n00:00:12,100 --> 00:00:18,000\n然后点击保存按钮观察页面变化",
                    ]
                ),
                encoding="utf-8",
            )

            meta = build_source_meta(
                {
                    "title": "Bilibili Demo",
                    "duration": 18,
                    "subtitles": {"ai-zh": [{"ext": "srt"}]},
                },
                Platform.BILIBILI,
                video_path,
                work_dir,
            )
            merge_local_sidecars(meta, video_path)

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.SENTENCE_LEVEL)

    def test_bilibili_sparse_sidecar_subtitle_stays_unreliable(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "source.ai-zh.srt"
            subtitle_path.write_text(
                "1\n00:00:00,000 --> 00:00:01,000\n你好\n",
                encoding="utf-8",
            )

            meta = build_source_meta(
                {
                    "title": "Bilibili Demo",
                    "duration": 30,
                    "subtitles": {"ai-zh": [{"ext": "srt"}]},
                },
                Platform.BILIBILI,
                video_path,
                work_dir,
            )
            merge_local_sidecars(meta, video_path)

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.UNRELIABLE)

    def test_youtube_auto_caption_vtt_stays_word_level(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitles_dir = work_dir / "subtitles"
            subtitles_dir.mkdir()
            (subtitles_dir / "en.vtt").write_text(
                "WEBVTT\n\n00:00:00.000 --> 00:00:01.000\n<00:00:00.000><c>hello</c>\n",
                encoding="utf-8",
            )

            meta = build_source_meta(
                {
                    "title": "YouTube Demo",
                    "automatic_captions": {"en": [{"ext": "vtt"}]},
                },
                Platform.YOUTUBE,
                video_path,
                work_dir,
            )

        self.assertEqual(meta.subtitle_quality, SubtitleQuality.WORD_LEVEL)
        self.assertEqual(len(meta.auto_captions), 1)
        self.assertTrue(meta.auto_captions[0].is_generated)
        self.assertTrue(meta.auto_captions[0].has_word_timestamps)
