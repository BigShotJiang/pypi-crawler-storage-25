import json
from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from withvideo.cli import main
from withvideo.runtime import DecisionRequired


def _remote_to_download_decision() -> DecisionRequired:
    return DecisionRequired(
        kind="remote_to_download",
        reason_code="platform_subtitles_unavailable",
        message="Remote media access requires platform subtitles; remote-mode Whisper is unsupported.",
        options=["download", "abort"],
        default_option="download",
        stage="transcript",
        context={"platform": "bilibili", "subtitle_quality": "none"},
    )


def _llm_retry_decision() -> DecisionRequired:
    return DecisionRequired(
        kind="llm_stage_retry_or_abort",
        reason_code="llm_stage_failed",
        message="语义判断失败：LLM 返回空输出",
        options=["retry", "abort"],
        default_option="retry",
        stage="semantic",
        context={"raw_output_path": ".withvideo/demo/llm/semantic_output.raw.txt"},
    )


def test_learn_tty_prompt_can_retry_remote_failure_with_download(tmp_path):
    runner = CliRunner()
    success_path = tmp_path / "guide.md"

    with patch(
        "withvideo.cli._run_learn_once",
        side_effect=[_remote_to_download_decision(), success_path],
    ) as mock_run, patch("withvideo.cli._stdout_is_tty", return_value=True), patch(
        "withvideo.cli._stdin_is_tty", return_value=True
    ), patch("withvideo.cli.click.confirm", return_value=True) as mock_confirm:
        result = runner.invoke(
            main,
            [
                "learn",
                "https://www.bilibili.com/video/BV1dD9wBeESP/",
                "--media-access",
                "remote",
                "--event-stream",
                "off",
                "-o",
                str(tmp_path),
            ],
        )

    assert result.exit_code == 0
    assert mock_confirm.called
    assert mock_run.call_count == 2
    first_cfg = mock_run.call_args_list[0].args[1]
    second_cfg = mock_run.call_args_list[1].args[1]
    assert first_cfg.media_access == "remote"
    assert second_cfg.media_access == "download"


def test_learn_tty_prompt_can_retry_llm_stage_without_mutating_config(tmp_path):
    runner = CliRunner()
    success_path = tmp_path / "guide.md"

    with patch(
        "withvideo.cli._run_learn_once",
        side_effect=[_llm_retry_decision(), success_path],
    ) as mock_run, patch("withvideo.cli._stdout_is_tty", return_value=True), patch(
        "withvideo.cli._stdin_is_tty", return_value=True
    ), patch("withvideo.cli.click.confirm", return_value=True) as mock_confirm:
        result = runner.invoke(
            main,
            [
                "learn",
                "demo.mp4",
                "--event-stream",
                "off",
                "-o",
                str(tmp_path),
            ],
        )

    assert result.exit_code == 0
    assert mock_confirm.called
    assert mock_run.call_count == 2
    first_cfg = mock_run.call_args_list[0].args[1]
    second_cfg = mock_run.call_args_list[1].args[1]
    assert first_cfg.llm_command == second_cfg.llm_command
    assert first_cfg.media_access == second_cfg.media_access


def test_learn_non_tty_emits_decision_required_jsonl_and_exits(tmp_path):
    runner = CliRunner()
    with patch(
        "withvideo.cli._run_learn_once",
        side_effect=_remote_to_download_decision(),
    ):
        result = runner.invoke(
            main,
            [
                "learn",
                "https://www.bilibili.com/video/BV1dD9wBeESP/",
                "--media-access",
                "remote",
                "-o",
                str(tmp_path),
            ],
        )

    assert result.exit_code == 1
    events = [json.loads(line) for line in result.output.splitlines() if line.startswith("{")]
    event_types = [event["type"] for event in events]
    assert "run_started" in event_types
    assert "decision_required" in event_types
    assert "run_failed" in event_types
    decision_event = next(event for event in events if event["type"] == "decision_required")
    assert decision_event["stage"] == "transcript"
    assert decision_event["context"]["kind"] == "remote_to_download"
    assert decision_event["context"]["reason_code"] == "platform_subtitles_unavailable"


def test_learn_decision_mode_fail_never_prompts(tmp_path):
    runner = CliRunner()
    with patch(
        "withvideo.cli._run_learn_once",
        side_effect=_remote_to_download_decision(),
    ), patch("withvideo.cli._stdout_is_tty", return_value=True), patch(
        "withvideo.cli._stdin_is_tty", return_value=True
    ), patch("withvideo.cli.click.confirm") as mock_confirm:
        result = runner.invoke(
            main,
            [
                "learn",
                "https://www.bilibili.com/video/BV1dD9wBeESP/",
                "--media-access",
                "remote",
                "--event-stream",
                "off",
                "--decision-mode",
                "fail",
                "-o",
                str(tmp_path),
            ],
        )

    assert result.exit_code == 1
    assert not mock_confirm.called


def test_learn_event_stream_jsonl_emits_events_even_on_tty(tmp_path):
    runner = CliRunner()
    success_path = tmp_path / "guide.md"

    with patch("withvideo.cli._run_learn_once", return_value=success_path), patch(
        "withvideo.cli._stdout_is_tty", return_value=True
    ), patch("withvideo.cli._stdin_is_tty", return_value=True):
        result = runner.invoke(
            main,
            [
                "learn",
                "demo.mp4",
                "--event-stream",
                "jsonl",
                "-o",
                str(tmp_path),
            ],
        )

    assert result.exit_code == 0
    events = [json.loads(line) for line in result.output.splitlines() if line.startswith("{")]
    event_types = [event["type"] for event in events]
    assert "run_started" in event_types
    assert "run_completed" in event_types
