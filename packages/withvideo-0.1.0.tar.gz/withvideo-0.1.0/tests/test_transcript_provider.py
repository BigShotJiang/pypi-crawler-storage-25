import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from withvideo.config import WVConfig
from withvideo.impl.transcripts.adaptive import AdaptiveTranscriptProvider
from withvideo.impl.transcripts.platform_subs import PlatformSubsProvider
from withvideo.models import Platform, SourceMeta, SubtitleQuality, SubtitleTrack, Transcript, TranscriptSource
from withvideo.runtime import DecisionRequired


class AdaptiveTranscriptProviderTests(unittest.TestCase):
    def test_auto_prefers_platform_subtitles_when_usable(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            subtitle_path = work_dir / "track.srt"
            subtitle_path.write_text("1\n00:00:00,000 --> 00:00:01,000\nhello\n", encoding="utf-8")
            video_path = work_dir / "video.mp4"
            video_path.write_bytes(b"")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.LOCAL_FILE,
                local_video_path=video_path,
                subtitles=[SubtitleTrack(lang="en", fmt="srt", path=subtitle_path)],
                subtitle_quality=SubtitleQuality.SENTENCE_LEVEL,
            )
            expected = Transcript(source=TranscriptSource.PLATFORM_MANUAL, language="en", segments=[])

            provider = AdaptiveTranscriptProvider(WVConfig(transcript="auto"))
            with patch("withvideo.impl.transcripts.platform_subs.PlatformSubsProvider.transcribe", return_value=expected) as mock_platform, \
                 patch("withvideo.impl.transcripts.mlx_whisper.MlxWhisperProvider.transcribe") as mock_whisper:
                result = provider.transcribe(video_path, meta, work_dir)

        self.assertIs(result, expected)
        mock_platform.assert_called_once()
        mock_whisper.assert_not_called()

    def test_auto_requests_whisper_decision_when_platform_subtitles_are_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "video.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "track.srt"
            subtitle_path.write_text("1\n00:00:00,000 --> 00:00:01,000\nhello\n", encoding="utf-8")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.BILIBILI,
                local_video_path=video_path,
                subtitles=[SubtitleTrack(lang="zh", fmt="srt", path=subtitle_path)],
                subtitle_quality=SubtitleQuality.SENTENCE_LEVEL,
            )
            provider = AdaptiveTranscriptProvider(WVConfig(transcript="auto"))
            with patch("withvideo.impl.transcripts.platform_subs.PlatformSubsProvider.transcribe", side_effect=FileNotFoundError("missing")) as mock_platform, \
                 patch("withvideo.impl.transcripts.mlx_whisper.MlxWhisperProvider.transcribe") as mock_whisper:
                with self.assertRaises(DecisionRequired) as exc_info:
                    provider.transcribe(video_path, meta, work_dir)

        self.assertEqual(exc_info.exception.kind, "platform_subtitles_to_whisper")
        self.assertEqual(exc_info.exception.reason_code, "platform_subtitles_missing_sidecar")
        mock_platform.assert_called_once()
        mock_whisper.assert_not_called()


class PlatformSubsProviderTests(unittest.TestCase):
    def test_explicit_platform_subs_can_fallback_to_local_sidecar_scan(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "source.ai-zh.srt"
            subtitle_path.write_text("1\n00:00:00,000 --> 00:00:01,000\n你好\n", encoding="utf-8")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.BILIBILI,
                local_video_path=video_path,
                subtitle_quality=SubtitleQuality.UNRELIABLE,
            )

            transcript = PlatformSubsProvider(WVConfig(transcript="platform-subs")).transcribe(
                video_path, meta, work_dir
            )

        self.assertEqual(transcript.language, "ai-zh")
        self.assertEqual(len(transcript.segments), 1)
        self.assertEqual(transcript.segments[0].text, "你好")

    def test_generated_srt_track_reports_platform_auto_without_word_timestamps(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "subtitles" / "en.srt"
            subtitle_path.parent.mkdir()
            subtitle_path.write_text("1\n00:00:00,000 --> 00:00:01,000\nhello\n", encoding="utf-8")
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.YOUTUBE,
                local_video_path=video_path,
                auto_captions=[
                    SubtitleTrack(
                        lang="en",
                        fmt="srt",
                        path=subtitle_path,
                    )
                ],
                subtitle_quality=SubtitleQuality.SENTENCE_LEVEL,
            )
            meta.auto_captions[0].is_generated = True
            meta.auto_captions[0].has_word_timestamps = False

            transcript = PlatformSubsProvider(WVConfig(transcript="platform-subs")).transcribe(
                video_path, meta, work_dir
            )

        self.assertEqual(transcript.source, TranscriptSource.PLATFORM_AUTO)
        self.assertFalse(transcript.has_word_timestamps)

    def test_generated_vtt_track_preserves_word_timestamps(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            work_dir = Path(tmp)
            video_path = work_dir / "source.mp4"
            video_path.write_bytes(b"")
            subtitle_path = work_dir / "source.en-orig.vtt"
            subtitle_path.write_text(
                "\n".join(
                    [
                        "WEBVTT",
                        "",
                        "00:00:00.000 --> 00:00:01.500",
                        "<00:00:00.000><c>hello</c> <00:00:00.500><c>world</c>",
                        "",
                    ]
                ),
                encoding="utf-8",
            )
            meta = SourceMeta(
                input=str(video_path),
                platform=Platform.YOUTUBE,
                local_video_path=video_path,
                auto_captions=[
                    SubtitleTrack(
                        lang="en-orig",
                        fmt="vtt",
                        path=subtitle_path,
                        is_generated=True,
                        has_word_timestamps=True,
                        source="yt-dlp",
                    )
                ],
                subtitle_quality=SubtitleQuality.WORD_LEVEL,
            )

            transcript = PlatformSubsProvider(WVConfig(transcript="platform-subs")).transcribe(
                video_path, meta, work_dir
            )

        self.assertEqual(transcript.source, TranscriptSource.PLATFORM_AUTO)
        self.assertTrue(transcript.has_word_timestamps)
        self.assertEqual(len(transcript.segments), 1)
        self.assertEqual(transcript.segments[0].text, "hello world")
        self.assertEqual(len(transcript.segments[0].words), 2)
        self.assertEqual(transcript.segments[0].words[0].word, "hello")
        self.assertAlmostEqual(transcript.segments[0].words[1].start, 0.5)
