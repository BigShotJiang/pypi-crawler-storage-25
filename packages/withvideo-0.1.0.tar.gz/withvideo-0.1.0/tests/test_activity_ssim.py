import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from withvideo.impl.activity.ssim import SSIMDetector, _sampling_fps_for_duration


class SSIMDetectorTests(unittest.TestCase):
    def test_long_videos_reduce_sampling_fps(self) -> None:
        self.assertEqual(_sampling_fps_for_duration(5 * 60), 2.0)
        self.assertEqual(_sampling_fps_for_duration(1190.454), 1.0)
        self.assertEqual(_sampling_fps_for_duration(35 * 60), 1.0)
        self.assertEqual(_sampling_fps_for_duration(75 * 60), 0.5)

    def test_timeout_during_frame_sampling_degrades_to_empty_profile(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            video_path = Path(tmp) / "video.mp4"
            video_path.write_bytes(b"")

            with patch(
                "withvideo.impl.activity.ssim._probe_duration",
                return_value=35 * 60,
            ), patch(
                "withvideo.impl.activity.ssim.subprocess.run",
                side_effect=subprocess.TimeoutExpired(["ffmpeg"], timeout=360),
            ):
                profile = SSIMDetector().detect(video_path)

        self.assertEqual(profile.per_second, [])
        self.assertEqual(profile.bursts, [])
        self.assertEqual(profile.threshold, 0.0)
        self.assertEqual(profile.encoding_type, "ALL_INTRA")


if __name__ == "__main__":
    unittest.main()
