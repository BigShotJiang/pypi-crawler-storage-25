---
name: learn-from-video
description: >
  Analyze tutorial videos (YouTube, Bilibili, local files) and produce
  actionable Repeat Guides with step-by-step operations and knowledge points.
  Optionally execute those operations via `wv act` (Tier 0/1: Shell / FileWrite /
  URLOpen / ClaudeCode). Use when the user provides a video URL or file and
  wants to learn from it, extract steps, or reproduce operations shown in the video.
allowed-tools: Bash(wv *) Bash(PATH=* wv *) Read
---

# Learn from Video Workflow

When the user provides a video URL or local file to analyze:

## Step 1: Preflight Check

Run `wv preflight "<source>"` to probe the environment and video source.
Present a brief summary to the user:
- Environment: ffmpeg available? LLM command detected?
- Video: platform, duration, subtitle availability
- Recommended strategy with rationale
- Ready-to-run command

If issues are found (e.g., `ffmpeg_not_found`, `llm_not_configured`), explain
how to fix them before proceeding.

```bash
wv preflight "$ARGUMENTS"
```

## Step 2: Confirm Strategy

Show the user the recommended `wv learn` command from the preflight output.
Explain what each flag means in plain language. Ask the user to confirm or adjust.

Common adjustments:
- Want to skip vision (faster/cheaper)? Add `--vision none`
- Need B站 1080p? Add `--cookies-from-browser chrome`
- Want to re-run from scratch? Add `--force`

## Step 3: Execute Pipeline

Run `wv learn` with the confirmed parameters. Always include
`--decision-mode defaults` to avoid TTY blocking in non-interactive mode.

If ffmpeg is not in PATH, prepend `PATH=/opt/homebrew/bin:$PATH`:
```bash
PATH=/opt/homebrew/bin:$PATH wv learn "$ARGUMENTS" --decision-mode defaults
```

## Step 4: Report Results

Read the generated guide.md and present key findings:
- Total steps, operations, and knowledge points (from run_completed stats)
- Brief summary of the first 2-3 steps
- Full path to guide.md and semantic.json

Then ask the user whether they want to **execute** the learned operations via
`wv act`. Default is *no* — only proceed if the user explicitly confirms.

## Step 5: Optional Act (Tier 0/1 real execution)

When the user asks to execute what the video taught:

### 5.1 Dry run first — always

```bash
wv act <work_dir>/semantic.json --dry-run
```

Show the routing table: which step goes to Shell / FileWrite / URLOpen /
ClaudeCode, which steps require `--allow-dangerous`, and which steps map to
Tier 2/3 (Browser / ComputerUse — not implemented, will be skipped).

### 5.2 Walk the user through risky steps

If any step contains shell patterns like `rm -rf`, `sudo`, `curl | sh`, or
writes outside a project-local subdirectory, call them out explicitly and ask
for confirmation before moving on. Never auto-accept `--allow-dangerous`.

### 5.3 Execute with guardrails

Preferred invocation (interactive confirmation on each step):

```bash
wv act <work_dir>/semantic.json
```

For fully unattended runs, after the user has reviewed the dry-run output:

```bash
wv act <work_dir>/semantic.json --no-confirm
```

To run a subset:

```bash
wv act <work_dir>/semantic.json --step 2-5
```

### 5.4 Report execution

After `wv act` returns, summarize:
- Steps executed vs skipped (Tier 2/3 unimplemented)
- Any failed step (exit code non-zero) — include stderr tail
- Files written, URLs opened, ClaudeCode sessions launched

## Troubleshooting

| Problem | Fix |
|---------|-----|
| `llm_not_configured` | Set `export WV_LLM_COMMAND="claude -p {prompt}"` |
| `ffmpeg_not_found` | Use `PATH=/opt/homebrew/bin:$PATH wv learn ...` |
| B站 subtitle unreliable | Add `--transcript mlx-whisper` (requires local video) |
| B站 1080p missing | Add `--cookies-from-browser chrome` |
| Want faster run | Add `--vision none` to skip frame analysis |
| Resume interrupted run | Re-run same command; cache skips completed stages |
| `wv act` blocks on dangerous command | Inspect the pattern; pass `--allow-dangerous` only if the user reviewed and approved |
| `wv act` step needs Browser / ComputerUse | Tier 2/3 not implemented — skip or do that step manually |
