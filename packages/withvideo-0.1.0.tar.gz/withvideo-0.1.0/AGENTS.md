# WithVideo (wv) — Agent Integration Guide

`wv` analyzes tutorial videos (YouTube, Bilibili, local files) and produces
actionable Repeat Guides with step-by-step operations and knowledge points.

## Quick Start

```bash
# 1. Discover capabilities
wv schema

# 2. Probe environment + video source (fast, no download)
wv preflight <url-or-file>

# 3. Run the pipeline
wv learn <url-or-file> --decision-mode defaults
```

## Recommended Workflow

```
wv preflight <source>     → check environment + probe video
                            → get recommended flags + ready-to-run command
wv learn <source> [flags] → run pipeline, produce guide.md + semantic.json
```

Always use `--decision-mode defaults` in non-interactive environments to
auto-accept all decision points (subtitle fallback, LLM retry, etc.).

## Integration Methods

### 1. Subprocess (any agent that can run shell commands)

```bash
# Fire-and-forget: auto-accept all decisions, output JSONL events
wv learn <source> --decision-mode defaults --event-stream jsonl 2>/dev/null

# Bidirectional: agent reads decision_required events, writes decisions to stdin
wv learn <source> --decision-mode agent --event-stream jsonl 2>/dev/null
```

**Bidirectional protocol:**
```
wv stdout → {"type":"decision_required","context":{"kind":"...","options":[...],"default_option":"..."}}
wv stdin  ← {"kind":"<same-kind>","selected":"<option>"}
wv stdout → {"type":"decision_selected","context":{"kind":"...","selected":"..."}}
```

### 2. MCP Server (MCP-compatible clients)

```bash
python -m withvideo.mcp_server
```

Exposes three tools: `wv_preflight`, `wv_learn`, `wv_schema`.

Configure via `.mcp.json`:
```json
{
  "mcpServers": {
    "withvideo": {
      "command": "python",
      "args": ["-m", "withvideo.mcp_server"],
      "env": { "PATH": "/opt/homebrew/bin:${PATH}" }
    }
  }
}
```

### 3. Claude Code Plugin

Load the bundled plugin for Skills + MCP integration:
```bash
claude --plugin-dir ./withvideo-plugin
```

Then use `/withvideo:learn-from-video <url>` or simply provide a video URL
— the Skill automatically runs preflight, confirms strategy, and executes.

## Key Options

| Option | Values | Notes |
|--------|--------|-------|
| `--decision-mode` | `defaults` / `agent` / `auto` | Use `defaults` for non-interactive |
| `--media-access` | `download` / `remote` | `remote` = no download (Bilibili only) |
| `--vision` | `cli` / `claude` / `none` | `none` = skip frame analysis (faster) |
| `--transcript` | `auto` / `mlx-whisper` / `platform-subs` | |
| `--event-stream` | `jsonl` / `auto` | `jsonl` = always emit structured events |
| `--llm-command` | command template | Use `{prompt}` placeholder or `-` for stdin |
| `--cookies-from-browser` | `chrome` / `firefox` | Bilibili 1080p+ |

## Environment Variables

| Variable | Purpose |
|----------|---------|
| `WV_LLM_COMMAND` | Override LLM command (e.g. `claude -p {prompt}`) |
| `ANTHROPIC_API_KEY` | Required for `--vision claude` |

## Events (JSONL, stdout)

All events share fields: `type`, `timestamp`, `run_id`, `stage`, `message`, `context`.

| type | When |
|------|------|
| `run_started` | Pipeline begins |
| `stage_started/completed` | Each stage (acquire/transcript/semantic/vision/guide) |
| `decision_required` | Pipeline needs a decision |
| `decision_selected` | Decision was made (auto or interactive) |
| `artifact_written` | Output file created |
| `run_completed` | Success — `context.output_path`, `context.stats` |
| `run_failed` | Failure — `context.error_code`, `context.recoverable`, `context.suggestion` |

See full schema: `wv schema`

## Decision Points

| kind | Trigger | Default |
|------|---------|---------|
| `remote_to_download` | Remote mode + no subtitles | `download` |
| `platform_subtitles_to_whisper` | Subtitles unreliable/missing | `mlx-whisper` |
| `llm_stage_retry_or_abort` | LLM call failed | `retry` |

## Exit Codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | General error (see `run_failed.context.error_code`) |
| 2 | Agent protocol error (stdin timeout / invalid JSON / kind mismatch) |
| 3 | Explicit abort (user or agent selected "abort") |

## Common Recipes

```bash
# B站视频 — 远端模式，无需下载
wv learn https://www.bilibili.com/video/BV... --media-access remote --decision-mode defaults

# B站 1080p (需要登录)
wv learn https://... --cookies-from-browser chrome --decision-mode defaults

# YouTube — 快速模式 (跳过视觉分析)
wv learn https://www.youtube.com/watch?v=... --vision none --decision-mode defaults

# 本地文件
wv learn tutorial.mp4 --decision-mode defaults

# 重新运行（强制清除缓存）
wv learn <source> --force --decision-mode defaults

# 只重新生成 guide（利用缓存）
wv learn <source> --skip transcript --skip semantic --skip vision --decision-mode defaults
```
