from __future__ import annotations

from typing import TYPE_CHECKING, Any

from lfx.components._importing import import_mod

if TYPE_CHECKING:
    from .astradb_chatmemory import AstraDBChatMemory
    from .astradb_cql import AstraDBCQLToolComponent
    from .astradb_data_api import AstraDBDataAPIComponent
    from .astradb_graph import AstraDBGraphVectorStoreComponent
    from .astradb_tool import AstraDBToolComponent
    from .astradb_vectorize import AstraVectorizeComponent
    from .astradb_vectorstore import AstraDBVectorStoreComponent
    from .dotenv import Dotenv
    from .getenvvar import GetEnvVar
    from .graph_rag import GraphRAGComponent

_dynamic_imports = {
    "AstraDBCQLToolComponent": "astradb_cql",
    "AstraDBChatMemory": "astradb_chatmemory",
    "AstraDBDataAPIComponent": "astradb_data_api",
    "AstraDBGraphVectorStoreComponent": "astradb_graph",
    "AstraDBToolComponent": "astradb_tool",
    "AstraDBVectorStoreComponent": "astradb_vectorstore",
    "AstraVectorizeComponent": "astradb_vectorize",
    "Dotenv": "dotenv",
    "GetEnvVar": "getenvvar",
    "GraphRAGComponent": "graph_rag",
}

__all__ = [
    "AstraDBCQLToolComponent",
    "AstraDBChatMemory",
    "AstraDBDataAPIComponent",
    "AstraDBGraphVectorStoreComponent",
    "AstraDBToolComponent",
    "AstraDBVectorStoreComponent",
    "AstraVectorizeComponent",
    "Dotenv",
    "GetEnvVar",
    "GraphRAGComponent",
]


def __getattr__(attr_name: str) -> Any:
    """Lazily import datastax components on attribute access."""
    if attr_name not in _dynamic_imports:
        msg = f"module '{__name__}' has no attribute '{attr_name}'"
        raise AttributeError(msg)
    try:
        result = import_mod(attr_name, _dynamic_imports[attr_name], __spec__.parent)
    except (ModuleNotFoundError, ImportError, AttributeError) as e:
        msg = f"Could not import '{attr_name}' from '{__name__}': {e}"
        raise AttributeError(msg) from e
    globals()[attr_name] = result
    return result


def __dir__() -> list[str]:
    return list(__all__)
