#!/usr/bin/env python3
"""LoongClaw MCP 发布引擎（v0.9.0 起 AI-first）

**常规路径**：AI 调用 `loongclaw-devkit` MCP 服务的 `publish_mcp` 工具——这个文件
是其幕后子进程后端，AI 不直接接触。

**紧急逃生路径**（CI / devkit MCP 服务挂了）：
    python publish.py --auto --json-output --dir . --version 1.0.0 --access public --upload

配置存在 .publish.json，缺字段会立刻 fail（由 server.py 的 `update_mcp_config` 工具维护）。
v0.9.0 已删除 interactive_config() 和 --reconfigure。
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import pathspec

# ── 常量 ──────────────────────────────────────────────────
CLOUD_API_BASE = "https://api.loongclaw.net.cn"
UPLOAD_ENDPOINT = "/v1/store/upload"
ENTRYPOINT = "server.py"  # 入口文件
CONFIG_FILE = ".publish.json"
MCPIGNORE_FILE = ".mcpignore"

# ── 结构化 Error Code（AI-first，v0.9.0 新增）────────────
#
# 所有面向 AI/外层的错误返回都必须带 `code` 字段（稳定枚举），AI 看 code 路由
# 到确定的 auto-fix 策略；错误文案仅供人类调试，**不能靠 regex 文案猜意图**。
# 新增 code 必须同步更新 server.py 的 docstring（AI 读 docstring 决定如何处理）。
class PublishErrorCode:
    # 配置类（人类操作问题，需要 AI 更新 .publish.json）
    CONFIG_INVALID = "CONFIG_INVALID"              # .publish.json 字段缺失/非法
    PROJECT_DIR_MISSING = "PROJECT_DIR_MISSING"    # 目录不存在
    PROJECT_STRUCTURE_INVALID = "PROJECT_STRUCTURE_INVALID"  # server.py/requirements.txt 缺失或格式不对
    ENTRYPOINT_INSTANCE_NAME = "ENTRYPOINT_INSTANCE_NAME"   # private 包 FastMCP 实例不叫 mcp
    RUNTIME_INVALID = "RUNTIME_INVALID"            # runtime 不在白名单（python / self-contained）
    MCP_COMMAND_REQUIRED = "MCP_COMMAND_REQUIRED"  # self-contained 缺 mcp.command
    BUILD_PLATFORM_REQUIRED = "BUILD_PLATFORM_REQUIRED"  # self-contained 缺 buildPlatform
    # Cython 兼容性（可通过改源码/加 .mcpignore 修复）
    CYTHON_INCOMPAT = "CYTHON_INCOMPAT"            # 文件名/参数名撞保留字
    CYTHON_COMPILE_FAILED = "CYTHON_COMPILE_FAILED"  # 编译本身挂了
    PRIVATE_PLAINTEXT_LEAK = "PRIVATE_PLAINTEXT_LEAK"  # private 包存在明文业务 .py
    # 打包类
    PACKAGE_TOO_LARGE = "PACKAGE_TOO_LARGE"        # 超上传上限
    PATH_NOT_IN_ZIP = "PATH_NOT_IN_ZIP"            # server.py 引用的路径不在 zip 里
    # 上传类
    UPLOAD_NO_TOKEN = "UPLOAD_NO_TOKEN"            # 缺 Store Key
    UPLOAD_DEPS_MISSING = "UPLOAD_DEPS_MISSING"    # requests 未安装
    UPLOAD_HTTP_ERROR = "UPLOAD_HTTP_ERROR"        # HTTP 非 200
    UPLOAD_NETWORK_ERROR = "UPLOAD_NETWORK_ERROR"  # 连接/超时错误
    UPLOAD_BAD_RESPONSE = "UPLOAD_BAD_RESPONSE"    # 服务端返回非 JSON
    # 未分类
    UNKNOWN = "UNKNOWN"

# 硬红线：.mcpignore 无法覆盖。即使用户写 `!__pycache__/` 试图反向解除也无效
# （见 load_ignore_spec 末尾再次追加红线，gitignore 语义"最后匹配者胜"）。
#
# 分两类：
#  [安全] 4 项 — 防止源码/历史/密钥/字节码泄漏或大体积注入
#    __pycache__ / .git / .venv / venv
#    （衍生：*.pyc / *.pyo —— 字节码可 uncompyle6 反编译回源码，付费包致命）
#  [工具正确性] 5 项 — 防止工具自身输出物污染打包结果
#    _staging     —— 上一轮失败残留，重打自我复制导致嵌套膨胀
#    publish.py   —— 发布脚本本身（包内不应出现）
#    setup.py     —— 同上（Cython 临时 setup 文件）
#    .publish.json—— 含 LOONGCLAW_STORE_KEY（token）泄漏风险 ⚠
#    project.zip  —— 上一轮的产物，不排会自包含导致无限膨胀
#    .mcpignore   —— 规则文件本身不是 MCP 运行时
SECURITY_RED_LINES = {
    # [安全]
    "__pycache__", ".git", ".venv", "venv",
    "*.pyc", "*.pyo",
    # [工具正确性]
    "_staging", "publish.py", "setup.py",
    ".publish.json", "project.zip", ".mcpignore",
}


# ── 工具函数 ──────────────────────────────────────────────

def should_skip(name: str) -> bool:
    """basename 级硬红线检查（等价旧 IGNORE_PATTERNS 行为）。

    只看最后一级名字——用在 os.walk/zip-build/manifest 构建时过滤
    Cython 编译残留（如 __pycache__、*.pyc）。.mcpignore 的路径级规则
    走 load_ignore_spec + is_path_ignored，不经过此函数。
    """
    if name in SECURITY_RED_LINES:
        return True
    return any(
        name.endswith(p[1:]) for p in SECURITY_RED_LINES if p.startswith("*")
    )


def _red_line_gitignore_patterns() -> list[str]:
    """把 SECURITY_RED_LINES 翻译成 gitignore 语法，供 pathspec 用。"""
    return [
        "__pycache__/", "*.pyc", "*.pyo",
        ".git/", ".venv/", "venv/",
        "_staging/", "publish.py", "setup.py",
        ".publish.json", "project.zip", ".mcpignore",
    ]


def load_ignore_spec(project_dir: Path) -> pathspec.PathSpec:
    """加载硬红线 + .mcpignore，返回合并后的 PathSpec。

    顺序：[硬红线] → [用户 .mcpignore] → [硬红线再一次]
    最后一次追加是为了让"最后匹配者胜"规则下，用户的 !negate 永远无法反向
    解除硬红线（即使 .mcpignore 写了 `!.git/` 也会被末尾的 `.git/` 重新忽略）。
    """
    patterns: list[str] = list(_red_line_gitignore_patterns())

    mcpignore = project_dir / MCPIGNORE_FILE
    if mcpignore.exists():
        try:
            # v0.9.1 #15：用 utf-8-sig 读取自动剥离 UTF-8 BOM。
            # Windows 记事本/部分编辑器默认保存带 BOM，第一行规则会被 \ufeff 前缀
            # 污染导致匹配失败（gitwildmatch 把 BOM 当成字面字符）。utf-8-sig 编码
            # 只在文件开头剥一次 BOM，中间出现不会误剥，是最安全的兼容方案。
            raw = mcpignore.read_text(encoding="utf-8-sig")
            # 独立告警：提示开发者改成无 BOM 编码更稳妥
            raw_bytes = mcpignore.read_bytes()
            if raw_bytes.startswith(b"\xef\xbb\xbf"):
                print(f"  ⚠ {MCPIGNORE_FILE} 含 UTF-8 BOM，已自动剥离；建议用无 BOM 编码重新保存")
            user_rules = raw.splitlines()
            patterns.extend(user_rules)
            print(f"  ℹ 已加载 {MCPIGNORE_FILE}（{sum(1 for l in user_rules if l.strip() and not l.strip().startswith('#'))} 条规则）")
        except OSError as e:
            print(f"  ⚠ 读取 {MCPIGNORE_FILE} 失败: {e}，仅使用硬红线")

    # 硬红线二次追加 → 压制用户可能的 !negate
    patterns.extend(_red_line_gitignore_patterns())

    return pathspec.PathSpec.from_lines("gitwildmatch", patterns)


def is_path_ignored(spec: pathspec.PathSpec, rel_path) -> bool:
    """判断相对路径是否被忽略（目录/文件均可）。"""
    rel_str = str(rel_path).replace(os.sep, "/")
    return spec.match_file(rel_str)


def print_step(n: int, total: int, msg: str) -> None:
    print(f"\n[{n}/{total}] {msg}")


def detect_project_info(project_dir: Path) -> dict:
    """从 server.py 的 FastMCP 实例中提取插件信息。"""
    entry = project_dir / ENTRYPOINT
    if not entry.exists():
        return {}

    text = entry.read_text(encoding="utf-8", errors="replace")
    info: dict = {}

    # FastMCP("name", ...) 或 FastMCP(name="...")
    m = re.search(r'FastMCP\(\s*["\']([^"\']+)["\']', text)
    if m:
        info["id"] = m.group(1)

    # instructions=("...") 或 description="..."
    m = re.search(r'(?:instructions|description)\s*=\s*["\'\(]+(.*?)[\)"\']', text, re.DOTALL)
    if m:
        info["description"] = " ".join(m.group(1).split())[:200]

    return info


def find_py_files(project_dir: Path) -> list[Path]:
    """递归查找所有 .py 文件，应用硬红线 + .mcpignore 过滤。"""
    spec = load_ignore_spec(project_dir)
    results = []
    for p in sorted(project_dir.rglob("*.py")):
        rel = p.relative_to(project_dir)
        if is_path_ignored(spec, rel):
            continue
        results.append(p)
    return results


def validate_project(project_dir: Path, runtime: str = "python") -> list[str]:
    """校验项目结构，返回错误列表。

    runtime="self-contained" 时：开发者自带运行时与依赖，客户端不走 venv/pip，
      requirements.txt 可缺失；server.py FastMCP 检查也跳过（启动走 mcp.command）。
    """
    errors = []
    if runtime == "self-contained":
        # self-contained 不依赖项目结构；mcp.command 是否有效交给 _validate_config 处理。
        return errors

    entry = project_dir / ENTRYPOINT
    if not entry.exists():
        errors.append(f"缺少入口文件 {ENTRYPOINT}")
    else:
        text = entry.read_text(encoding="utf-8", errors="replace")
        if "FastMCP" not in text:
            errors.append(f"{ENTRYPOINT} 中未找到 FastMCP 实例")
        if "mcp.run(" not in text and ".run(" not in text:
            errors.append(f"{ENTRYPOINT} 中未找到 mcp.run() 调用")

    req = project_dir / "requirements.txt"
    if not req.exists():
        errors.append("缺少 requirements.txt")

    return errors


def check_entrypoint_mcp_instance(project_dir: Path) -> list[str]:
    """private 付费插件壳模式专属校验：FastMCP 实例必须命名为 `mcp`。

    壳脚本写死 `from server_impl import mcp`——如果开发者把实例叫 app/server，
    壳启动会立即 ImportError。此处提前在发布前拦截。
    """
    entry = project_dir / ENTRYPOINT
    if not entry.exists():
        return []  # validate_project 已报过错
    text = entry.read_text(encoding="utf-8", errors="replace")
    # 匹配：mcp = FastMCP( 或 mcp: FastMCP = FastMCP(
    if re.search(r"^\s*mcp\s*(?::\s*\w+\s*)?=\s*FastMCP\s*\(", text, re.MULTILINE):
        return []
    return [
        f"{ENTRYPOINT} 中 FastMCP 实例必须命名为 `mcp`（壳模式约定）。\n"
        f"     付费（private）插件加密后，DevKit 生成的壳 server.py 通过\n"
        f"     `from server_impl import mcp` 拿到实例并启动。请改写为：\n"
        f"         mcp = FastMCP(\"your-id\", instructions=\"...\")\n"
        f"     不要使用 app/server 等其他变量名。\n"
        f"\n"
        f"     存量项目快速迁移（在 server.py 所在目录执行，先 git 提交备份）：\n"
        f"         # macOS / BSD sed:\n"
        f"         sed -i '' -E 's/^([[:space:]]*)app([[:space:]]*=[[:space:]]*FastMCP)/\\1mcp\\2/; s/@app\\./@mcp./g; s/\\bapp\\.run\\(/mcp.run(/g' server.py\n"
        f"         # Linux / GNU sed:\n"
        f"         sed -i    -E 's/^([[:space:]]*)app([[:space:]]*=[[:space:]]*FastMCP)/\\1mcp\\2/; s/@app\\./@mcp./g; s/\\bapp\\.run\\(/mcp.run(/g' server.py\n"
        f"     （server/srv 等其他名字按需替换 app）。迁移后 git diff 复核一遍再发布。"
    ]


# ── private 付费包：生成入口壳（2026-04-23 v0.7.1 改造）─────────────
# server.py → server_impl.so 加密后，staging_dir 里自动生成一个壳 server.py，
# 通过 `from server_impl import mcp` 拿到 FastMCP 实例并启动 stdio 服务。
#
# 为什么不用 runpy.run_module 触发加密模块的 `if __name__ == "__main__"` 块：
#   Python 标准库 runpy 不支持扩展模块（.so/.pyd）——会报
#   `ImportError: No code object available for <module>`，因为 Cython 编译产物
#   没有 Python code object 可供 runpy 重放。
#
# 因此约定：开发者必须把 FastMCP 实例命名为 `mcp`（FastMCP 官方文档示例 + DevKit
# 既有 validate_project 已强制要求 `mcp = FastMCP(...)` 存在），无需写 def main()。
# manifest.entrypoint 仍是 server.py，客户端启动命令 `python server.py` 零改动。
#
# 壳脚本必须对外部环境零依赖（v0.10.2 起）：见模板内 WHY 注释——嵌入式/隔离
# Python 不会自动把脚本所在目录加进 sys.path[0]，必须由壳脚本自己注入。
_SHELL_SERVER_PY = '''\
#!/usr/bin/env python3
# Auto-generated by LoongClaw DevKit — DO NOT EDIT.
# 真实业务逻辑已加密到 server_impl.so/.pyd。
import os, sys

# ─────────────────────────────────────────────────────────────────────
# WHY 下面这一行不能删（防 REV3/PERM5 类回归，新人/AI 看着多余请先读完）
# ─────────────────────────────────────────────────────────────────────
# 普通 `python server.py` 启动时，CPython 会把脚本所在目录自动放到
# sys.path[0]——所以 bare `from server_impl import mcp` 能找到同目录下的
# server_impl.cpython-XXX.so。但下面两种启动方式 **不会** 自动注入脚本目录：
#
#   1. 嵌入式 Python（runtime=self-contained 包自带 python-3.x.x-embed）：
#      解释器旁存在 `pythonXY._pth` 文件 → 触发 isolated startup →
#      跳过 site → 不读 PYTHONPATH → sys.path 只含 _pth 列出的目录，
#      **绝对不含脚本所在目录**。
#   2. 显式隔离模式 `python -I server.py` / `python -E -s server.py`。
#
# 此时 `from server_impl import mcp` 必报 ModuleNotFoundError，子进程在
# 完成 MCP stdio 协议握手前秒死，客户端只看到 stdin/stdout 管道关闭，
# 报 `MCP error -32000: Connection closed`——没有任何 Python traceback
# 露出来，排查成本极高（用户/客户端均无从下手）。
#
# 历史回归点：
#   * v0.10.0 引入 runtime=self-contained，但 v0.10.0 客户端通过 bootstrap.js
#     间接启动子进程，恰好绕开了这个问题；
#   * v0.10.1 客户端启动器换成裸调 `python server.py`（start.cmd / mcp.command）→
#     所有 runtime=self-contained + private 付费包 100% 启动失败
#     （gerenweixin-mcp v2.3.20+ 工单 2026-04-26 实锤）。
#
# 修复策略：让壳脚本对启动环境零假设——不依赖 cwd / PYTHONPATH / 启动器
# 行为，用 `__file__` 派生本目录、显式 insert(0, ...) 注入 sys.path。这是
# 壳脚本对自身契约的兜底，不是补丁；删除等于回归 v0.10.1 的崩溃。
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from server_impl import mcp

if __name__ == "__main__":
    mcp.run(transport="stdio")
'''


def _write_entrypoint_shell(staging_dir: Path) -> None:
    """在 staging 根目录写入入口壳 server.py（含 sys.path 自注入，见 _SHELL_SERVER_PY 内 WHY）。"""
    shell_path = staging_dir / ENTRYPOINT
    shell_path.write_text(_SHELL_SERVER_PY, encoding="utf-8")


# ── 配置字段校验（Fail-Close）─────────────────────────────
# 2026-04-22 事故后新增：与 Cloud store-upload.ts 白名单对齐，在本地预先拦截
# 缺失/非法字段，避免构建/加密/压缩几十秒后才被 Cloud 400 退回。
_ALLOWED_ACCESS = {"public", "private"}
# 2026-04-25：与 Cloud ALLOWED_RUNTIMES 严格对齐。runtime 字段在 .publish.json 缺省 = "python"（向下兼容）。
_ALLOWED_RUNTIMES = {"python", "self-contained"}
_CONFIG_REQUIRED_STRINGS = [
    # (字段, 最小长度, 最大长度)
    ("id", 1, 64),
    ("name", 1, 60),
    ("description", 10, 500),
    ("version", 1, 32),
    ("author", 1, 60),
]


def _validate_config(config: dict, json_output: bool) -> None:
    """校验 config 必填/白名单字段，失败则打印错误并 sys.exit(1)。"""
    errs: list[str] = []
    for key, min_len, max_len in _CONFIG_REQUIRED_STRINGS:
        v = config.get(key, "")
        if not isinstance(v, str) or not v.strip():
            errs.append(f".publish.json 缺少必填字段 `{key}`")
            continue
        s = v.strip()
        if len(s) < min_len:
            errs.append(f"字段 `{key}` 长度至少 {min_len} 字符（当前 {len(s)}）")
        if len(s) > max_len:
            errs.append(f"字段 `{key}` 长度不能超过 {max_len} 字符（当前 {len(s)}）")

    access = config.get("access", "")
    if access not in _ALLOWED_ACCESS:
        errs.append(
            f"字段 `access` 必填且只能是 {sorted(_ALLOWED_ACCESS)}（当前 {access!r}）"
        )

    # runtime 校验（缺省 python，向下兼容老 .publish.json）
    runtime = config.get("runtime", "python")
    if runtime not in _ALLOWED_RUNTIMES:
        errs.append(
            f"字段 `runtime` 只支持 {sorted(_ALLOWED_RUNTIMES)}（当前 {runtime!r}）"
        )

    # skipCython 字段：可选 bool，缺省 false。仅类型校验，语义在 encrypt 调用点处理。
    skip_cython = config.get("skipCython", False)
    if not isinstance(skip_cython, bool):
        errs.append(
            f"字段 `skipCython` 必须是布尔值（当前 {type(skip_cython).__name__}）"
        )

    # self-contained 强制要求：mcp.command 非空 + buildPlatform 非空（自带二进制必平台特定）
    if runtime == "self-contained":
        mcp = config.get("mcp")
        if not isinstance(mcp, dict) or not isinstance(mcp.get("command"), str) \
                or not mcp["command"].strip():
            errs.append(
                "runtime=self-contained 必须在 .publish.json 配置 `mcp.command`（启动命令），"
                "如 {\"command\": \"./bin/server\", \"args\": []}"
            )
        elif "args" in mcp and not (
            isinstance(mcp["args"], list)
            and all(isinstance(a, str) for a in mcp["args"])
        ):
            errs.append("`mcp.args` 必须是字符串数组")

        build_platform = config.get("buildPlatform", "")
        if not isinstance(build_platform, str) or not build_platform.strip():
            errs.append(
                "runtime=self-contained 必须显式声明 `buildPlatform`（如 darwin / linux / win32），"
                "自带二进制必然是平台特定的，客户端 precheck 据此过滤"
            )

    if not errs:
        return

    if json_output:
        print(json.dumps({
            "status": "error",
            "code": PublishErrorCode.CONFIG_INVALID,
            "step": "validate_config",
            "errors": errs,
            "fix": "编辑 .publish.json 补全上述字段后重试（AI：调用 update_mcp_config 工具）",
        }, ensure_ascii=False))
    else:
        print("\n❌ .publish.json 字段校验失败：")
        for e in errs:
            print(f"  - {e}")
        print("\n💡 让 AI 调 `update_mcp_config(field=..., value=...)` 工具补全字段（或手动编辑 .publish.json）")
    sys.exit(1)


# ── Cython 可行性前置扫描（v0.9.0 新增，#3+#7 根因修复）─────
#
# 为什么要前置扫描：Cython 把 .py 编译成 C 扩展时，有两类输入会直接挂掉——
#   ① 函数参数名是 C 关键字（int/long/char/...）→ 生成的 C 代码语法错误
#   ② 文件名包含非 ASCII / 非合法标识符字符（中文/空格/连字符）→ 无法作为模块名
# 旧做法是各加一套临时特判，每遇到新坑补一次；这违反「加特殊处理」警报。
# 根因修复：发布前一次性扫描所有会进 Cython 的 .py 文件，收集所有不可编译原因，
# 一次性报告给开发者，强制修复后才继续。
#
# C 关键字保留字参考 https://en.cppreference.com/w/c/keyword（仅列 Python 参数名
# 场景下实际会撞的）。Cython 额外保留 `api/public` 用作声明修饰符。
_C_RESERVED_PARAM_NAMES = {
    "char", "int", "long", "short", "double", "float",
    "signed", "unsigned", "void", "const", "volatile", "register",
    "struct", "union", "enum", "typedef", "sizeof",
    "auto", "extern", "static", "inline",
    # Cython 自身保留
    "api", "public", "cdef", "cpdef", "nogil",
}


def precheck_cython_compatibility(
    project_dir: Path, py_files: list[Path]
) -> list[str]:
    """发布前扫描所有待加密文件，返回不可编译问题列表。

    检查：
      (A) 文件名（不含 .py）必须是合法 Python 标识符且纯 ASCII——
          Cython 用文件名作模块名，中文/空格/连字符都会挂。
      (B) 函数参数名不能撞 C/Cython 保留字（char/int/long/...）——
          生成的 C 代码会是 `int char` 这种语法错误。

    一次性收集所有问题，不在第一个问题就 return。让开发者一次看全修完。
    """
    issues: list[str] = []
    always_plain = {"__init__.py"}  # 不会进 Cython

    for f in py_files:
        rel = f.relative_to(project_dir)
        if f.name in always_plain:
            continue

        stem = f.stem  # 不含 .py 后缀
        # (A) 文件名合法性
        if not stem.isidentifier() or not stem.isascii():
            issues.append(
                f"文件名不是合法 ASCII 标识符（Cython 要用它做模块名）: {rel}\n"
                f"     改名为纯英文小写+下划线（如 xiaohongshu_client.py）"
            )
            # 文件名挂了，AST 还是解，收集参数问题继续

        # (B) 参数名保留字扫描
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
        except SyntaxError as e:
            issues.append(f"Python 语法错误: {rel} 第 {e.lineno} 行: {e.msg}")
            continue

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                all_args = (
                    list(node.args.posonlyargs)
                    + list(node.args.args)
                    + list(node.args.kwonlyargs)
                )
                if node.args.vararg:
                    all_args.append(node.args.vararg)
                if node.args.kwarg:
                    all_args.append(node.args.kwarg)
                for a in all_args:
                    if a.arg in _C_RESERVED_PARAM_NAMES:
                        issues.append(
                            f"参数名撞 C/Cython 保留字: {rel} 第 {a.lineno} 行"
                            f" 函数 `{node.name}` 的参数 `{a.arg}`\n"
                            f"     改名（如 char→ch, int→n, long→big_n）"
                        )

    return issues


# ── 跨平台兼容性检查 ─────────────────────────────────────

# 已知需要 C 编译器的包——严格锁版在无编译器的平台（Windows）容易安装失败
_C_EXT_PKGS = {
    "greenlet", "numpy", "scipy", "pandas", "lxml", "pillow",
    "cryptography", "grpcio", "psycopg2", "cffi", "pyyaml",
    "markupsafe", "msgpack", "aiohttp", "uvloop",
}


def check_requirements_compat(project_dir: Path) -> list[str]:
    """检查 requirements.txt 跨平台兼容性，返回警告列表。"""
    warnings = []
    req = project_dir / "requirements.txt"
    if not req.exists():
        return warnings

    for line in req.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        m = re.match(r"^([a-zA-Z0-9_.-]+)==(\S+)", line)
        if m:
            pkg = m.group(1).lower().replace("-", "_")
            if pkg in _C_EXT_PKGS:
                warnings.append(
                    f"{m.group(1)}=={m.group(2)} 严格锁定版本，"
                    f"可能导致部分平台安装失败。建议改为 >={m.group(2)}"
                )
    return warnings


def verify_zip_paths(project_dir: Path, zip_path: Path) -> list[str]:
    """校验 server.py 中引用的子目录是否存在于 zip 中。

    防止开发环境有 project/ 子目录但打包时丢失层级的典型错误。
    """
    warnings = []
    entry = project_dir / ENTRYPOINT
    if not entry.exists() or not zip_path.exists():
        return warnings

    text = entry.read_text(encoding="utf-8", errors="replace")

    # 收集 zip 中的顶级目录和文件
    with zipfile.ZipFile(zip_path, "r") as zf:
        zip_entries = set(zf.namelist())
    zip_top_dirs = {n.split("/")[0] for n in zip_entries if "/" in n}
    zip_top_files = {n for n in zip_entries if "/" not in n}
    zip_top = zip_top_dirs | zip_top_files

    # 匹配 PLUGIN_DIR / "xxx" 或 Path(__file__).parent / "xxx" 等模式
    pattern = (
        r"(?:PLUGIN_DIR|PROJECT_DIR|BASE_DIR|ROOT_DIR|"
        r"Path\(__file__\)(?:\.resolve\(\))?\.parent)"
        r'\s*/\s*["\']([^"\']+)["\']'
    )
    for m in re.finditer(pattern, text):
        ref = m.group(1)
        if ref in ("__pycache__", ".venv", "venv", "node_modules"):
            continue
        if ref not in zip_top:
            warnings.append(
                f'{ENTRYPOINT} 引用路径 "{ref}"，但 project.zip '
                f"中不存在此路径。安装后 server.py 将无法找到该目录/文件。"
            )

    return warnings


# ── 加密（Cython 编译）──────────────────────────────────

def encrypt_files(
    project_dir: Path,
    py_files: list[Path],
    staging_dir: Path,
    access: str = "public",
) -> tuple[list[str], list[str]]:
    """编译 .py → .so/.pyd，返回 (加密文件列表, 明文文件列表)。

    access=='private' 时：
      - server.py 强制加密为 server_impl.so
      - staging_dir 根目录生成入口壳 server.py（含 sys.path 自注入）
      - 加密完后做 Fail-Close 后置检查：不允许业务 .py 明文残留
    access=='public' 时：
      - server.py 保持明文（和老行为一致）

    v0.9.0 起：skip_encrypt 参数已删除。非 MCP 运行时文件请写入 .mcpignore
    完全排除出包，而不是保留明文进包——后者既不能加密保护又占用 zip 体积。
    """
    # __init__.py 几乎都是空占位符（或仅有版本字符串），Cython 加密它会导致包初
    # 始化失败，所以永远保持明文。（publish.py/setup.py 已被硬红线排除不会进这里）
    always_plain = {"__init__.py"}

    to_encrypt: list[Path] = []
    plain_files: list[str] = []

    for f in py_files:
        rel = str(f.relative_to(project_dir))
        name = f.name

        # server.py 按 access 分流：private 强制加密；public 保持明文
        if name == ENTRYPOINT and rel == ENTRYPOINT:  # 只匹配根目录的 server.py
            if access == "private":
                to_encrypt.append(f)
            else:
                plain_files.append(rel)
            continue

        if name in always_plain:
            plain_files.append(rel)
        else:
            to_encrypt.append(f)

    if not to_encrypt:
        print("  ℹ 无需加密的文件")
        return [], [str(f.relative_to(project_dir)) for f in py_files]

    # v0.9.0 #3+#7：Cython 可行性前置扫描。任何不可编译问题（文件名/参数名）
    # 一次性报告给开发者，强制修复后才能继续——不让问题拖到 Cython 自己在子进程
    # 里挂掉再凭 stderr 猜原因。
    compat_issues = precheck_cython_compatibility(project_dir, to_encrypt)
    if compat_issues:
        msg_lines = [
            f"❌ Cython 可行性检查失败（{len(compat_issues)} 个问题）：",
            "",
        ]
        for i, issue in enumerate(compat_issues, 1):
            msg_lines.append(f"  [{i}] {issue}")
        msg_lines.append("")
        msg_lines.append("💡 全部修复后重试。不兼容的文件可通过 .mcpignore 排除出包。")
        raise SystemExit("\n".join(msg_lines))

    # 检查 Cython 是否安装
    try:
        import Cython  # noqa: F401
    except ImportError:
        print("  ⚠ Cython 未安装，正在安装...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "cython", "-q"],
        )

    encrypted_names = []
    entrypoint_encrypted = False  # server.py 是否成功加密成 server_impl
    for f in to_encrypt:
        rel = f.relative_to(project_dir)
        # server.py 特殊：加密后改名为 server_impl 模块，方便后续壳 import
        is_entrypoint = f.name == ENTRYPOINT and str(rel) == ENTRYPOINT
        module_name = "server_impl" if is_entrypoint else f.stem
        work_dir = staging_dir / rel.parent
        work_dir.mkdir(parents=True, exist_ok=True)

        # 复制为 .pyx
        pyx_path = work_dir / f"{module_name}.pyx"
        shutil.copy2(f, pyx_path)

        # 编译
        print(f"  🔒 编译 {rel}...")
        setup_code = (
            "from setuptools import setup\n"
            "from Cython.Build import cythonize\n"
            f"setup(ext_modules=cythonize('{module_name}.pyx', "
            "compiler_directives={'language_level': '3'}))\n"
        )
        setup_file = work_dir / "_setup_tmp.py"
        setup_file.write_text(setup_code)

        result = subprocess.run(
            [sys.executable, str(setup_file), "build_ext", "--inplace"],
            cwd=str(work_dir),
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            # v0.9.0 #6：Cython 失败 = 立即 abort。旧版回退成明文 → public 包悄悄
            # 把本该加密的业务逻辑明文发布；private 包拖到后置检查才报错，中间
            # 已经白跑一遍打包流程。Fail Fast 原则：编译失败就是发版失败。
            raise SystemExit(
                f"❌ Cython 编译失败: {rel}\n"
                f"     {result.stderr[:800]}\n"
                f"\n💡 常见原因：C 编译器缺失 / Cython 版本不兼容 / 文件含无法编译的语法。"
                f"\n   若该文件无需加密保护，请加入 .mcpignore 排除出包。"
            )

        # 收集编译产物
        so_files = list(work_dir.glob(f"{module_name}.cpython-*.so")) + \
                   list(work_dir.glob(f"{module_name}.cp*-*.pyd"))
        if so_files:
            encrypted_names.append(str(rel))
            if is_entrypoint:
                entrypoint_encrypted = True
        else:
            print(f"  ⚠ 未找到编译产物: {rel}，保留明文")
            plain_files.append(str(rel))

        # 清理中间文件
        for tmp in [pyx_path, setup_file]:
            tmp.unlink(missing_ok=True)
        for c_file in work_dir.glob(f"{module_name}.c"):
            c_file.unlink(missing_ok=True)
        for build_dir in work_dir.glob("build"):
            shutil.rmtree(build_dir, ignore_errors=True)

    # ── private 付费包后置保护（2026-04-22 Fail-Close 第 2 层）──
    if access == "private":
        # WHY (2026-04-25 v0.10.1)：项目里是否有根目录 server.py 决定是否需要"壳模式"。
        # private + runtime=python（默认）：要求 server.py 存在并加密成功 → 写壳。
        # private + runtime=self-contained：开发者用自己的 mcp.command 启动，
        #   项目里可以没有 server.py（典型场景：纯二进制 + helper.py 业务模块）。
        #   此时不要求 server.py 存在，但业务 .py 明文兜底检查（步骤 3）必须照常跑。
        project_has_entrypoint = any(
            f.name == ENTRYPOINT and str(f.relative_to(project_dir)) == ENTRYPOINT
            for f in py_files
        )

        if project_has_entrypoint:
            # 1) server.py 必须成功加密成 server_impl，才能写壳
            if not entrypoint_encrypted:
                # server.py 未加密成功（编译失败被回退成明文），直接 abort
                raise SystemExit(
                    f"❌ private 付费包要求 {ENTRYPOINT} 必须加密成功，"
                    f"但编译失败已回退明文。请查看上方 Cython 报错并修复后重试。"
                )
            # 2) 生成入口壳 server.py 塞回 staging 根目录（含 sys.path 自注入）
            _write_entrypoint_shell(staging_dir)

        # 3) 业务 .py 明文兜底检查（核心防线，所有 private 路径都跑）
        # __init__.py 允许明文（几乎都是空占位符，加密会破坏包初始化）
        forbidden = [
            p for p in plain_files
            if Path(p).suffix == ".py" and Path(p).name != "__init__.py"
        ]
        if forbidden:
            raise SystemExit(
                "❌ private 付费包不能包含明文业务 .py 文件（源码会被逆向）：\n"
                + "\n".join(f"    {p}" for p in forbidden)
                + "\n\n💡 通常原因是 Cython 编译失败被回退为明文。"
                "\n   请查看上方编译报错日志并修复后重试。"
            )

    return encrypted_names, plain_files


# ── 打包 ─────────────────────────────────────────────────

def package_project(
    project_dir: Path,
    staging_dir: Path,
    plain_files: list[str],
    bundle_vendor: bool = False,
) -> Path:
    """收集明文文件 + 编译产物 + vendor wheels → project.zip

    bundle_vendor=False（默认，v0.9.0 起）：不下载 wheel 到 _vendor/，客户端
      在安装时走 PyPI 在线安装（mcp-store-python.ts 的 pipInstallOnline 有三级
      fallback 兜底，见客户端代码）。包体从几十 MB 回落到几 MB。
    bundle_vendor=True：保留 v0.8.x 行为，打进离线 wheel。仅在需要内网离线分发
      时开启；日常发布不推荐，nginx 默认 100MB 上限很容易超。
    """
    # 复制明文文件
    for rel in plain_files:
        src = project_dir / rel
        dst = staging_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.exists():
            shutil.copy2(src, dst)

    # 复制非 .py 文件（配置、模板等）
    spec = load_ignore_spec(project_dir)
    for f in sorted(project_dir.rglob("*")):
        if f.is_dir():
            continue
        rel = f.relative_to(project_dir)
        if is_path_ignored(spec, rel):
            continue
        if f.suffix == ".py":
            continue  # .py 已处理
        dst = staging_dir / rel
        if not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, dst)

    # requirements.txt → vendor wheels（v0.9.0 起默认关闭，见函数 docstring）
    req = staging_dir / "requirements.txt"
    if bundle_vendor and req.exists():
        vendor_dir = staging_dir / "_vendor"
        vendor_dir.mkdir(exist_ok=True)
        print("  📦 下载离线 wheel 包（bundleVendor=true）...")
        result = subprocess.run(
            [
                sys.executable, "-m", "pip", "download",
                "-r", str(req), "-d", str(vendor_dir),
                "--only-binary=:all:",
            ],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            # 尝试清华镜像
            subprocess.run(
                [
                    sys.executable, "-m", "pip", "download",
                    "-r", str(req), "-d", str(vendor_dir),
                    "--only-binary=:all:",
                    "-i", "https://pypi.tuna.tsinghua.edu.cn/simple",
                    "--trusted-host", "pypi.tuna.tsinghua.edu.cn",
                ],
                capture_output=True, text=True,
            )

    # 打 zip
    zip_path = project_dir / "project.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(staging_dir):
            dirs[:] = [d for d in dirs if not should_skip(d)]
            for fname in sorted(files):
                if should_skip(fname):
                    continue
                full = Path(root) / fname
                arcname = full.relative_to(staging_dir)
                zf.write(full, arcname)

    return zip_path


# ── Manifest 生成 ────────────────────────────────────────

def _sha256(path: Path) -> str:
    """计算文件的 SHA-256 哈希值。"""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def generate_manifest(
    project_dir: Path,
    staging_dir: Path,
    config: dict,
    encrypted_count: int = 0,
) -> dict:
    """生成 manifest.json（带文件哈希，支持增量更新）。

    参数 encrypted_count：本次构建 Cython 加密的产物数量。
    用于自动推断 requiredPython——Cython .so/.pyd 按 cpython-3XY ABI tag
    绑定构建时的 Python 版本，必须锁定 major.minor，否则客户端换版本必 ImportError。
    """
    # 收集 staging 中的所有文件，并计算每个文件的 SHA-256 哈希
    files_map: dict[str, dict] = {}
    for f in sorted(staging_dir.rglob("*")):
        if f.is_dir():
            continue
        rel = str(f.relative_to(staging_dir))
        if not should_skip(f.name):
            files_map[rel] = {
                "hash": _sha256(f),
                "size": f.stat().st_size,
            }

    # 检测 configFields
    config_fields = []
    entry = project_dir / ENTRYPOINT
    if entry.exists():
        text = entry.read_text(encoding="utf-8", errors="replace")
        for m in re.finditer(
            r'os\.environ\.get\(["\'](\w+)["\'](?:,\s*["\']([^"\']*)["\'])?\)',
            text,
        ):
            key = m.group(1)
            default = m.group(2) or ""
            if key not in ("PATH", "HOME", "USER", "LANG"):
                config_fields.append({
                    "key": key,
                    "label": key.replace("_", " ").title(),
                    "default": default,
                    "required": default == "",
                })

    # 计算 project.zip 的哈希（zip 在上一步已生成）
    zip_path = project_dir / "project.zip"
    source_archive_hash = _sha256(zip_path) if zip_path.exists() else None

    manifest: dict = {
        "id": config["id"],
        "name": config.get("name", config["id"]),
        "description": config.get("description", ""),
        "version": config["version"],
        "author": config.get("author", ""),
        "icon": config.get("icon", "🔧"),
        # 2026-04-25：runtime 从硬编码改为读 config（缺省 python 向下兼容）
        "runtime": config.get("runtime", "python"),
        "entrypoint": ENTRYPOINT,
        "files": files_map,
        "env": {},
        "configFields": config_fields,
        "sourceArchive": "project.zip",
    }
    # self-contained 启动命令写入 manifest.mcp，客户端据此启动。
    # _validate_config 已保证 mcp.command 非空；args 可选。
    if config.get("runtime") == "self-contained":
        mcp_cfg = config.get("mcp", {}) or {}
        manifest["mcp"] = {
            "command": mcp_cfg["command"],
            "args": list(mcp_cfg.get("args", [])),
        }
    if source_archive_hash:
        manifest["sourceArchiveHash"] = source_archive_hash

    # PLAT1 + #12：requiredPython 写入
    # 优先级：config.requiredPython（用户显式声明） > Cython ABI 锁定 > 不写
    # - Cython 有产物时必须锁 major.minor（ABI tag 绑定），否则客户端换版本必 ImportError
    # - 用户显式声明允许覆盖（可能知道 pure-Python 跨版本兼容，或有自己的约束）
    # - 都没有且无 Cython → 不写，客户端走默认 >=3.10
    user_required = config.get("requiredPython") or config.get("required_python")
    if user_required:
        manifest["requiredPython"] = str(user_required)
    elif encrypted_count > 0:
        build_major = sys.version_info.major
        build_minor = sys.version_info.minor
        manifest["requiredPython"] = (
            f">={build_major}.{build_minor},<{build_major}.{build_minor + 1}"
        )

    # PLAT1：平台标记——devkit 构建平台写入 manifest，方便 Cloud 审计/客户端日志定位
    # 注：运行时平台兼容性已由客户端 precheck 拦截（zip-entries.ts），此字段仅做元数据
    # self-contained 必填 buildPlatform（_validate_config 已拦截缺失），优先读 config 显式值
    explicit_platform = config.get("buildPlatform")
    if explicit_platform:
        manifest["buildPlatform"] = str(explicit_platform)
    elif encrypted_count > 0:
        manifest["buildPlatform"] = sys.platform

    # MCP-LLM 代理声明（v0.10+）：声明该 MCP 需要使用 LoongClaw 平台 LLM
    # 客户端三向锁第二层——store 安装 + 此声明 + Cloud 白名单 enabled，三者全满足
    # gateway 才会向子进程注入 OPENAI_BASE_URL / OPENAI_API_KEY 占位 env
    # 默认 false（不声明），保持最小权限边界，避免修改第三方 MCP 行为
    if config.get("usesPlatformLlm") is True:
        manifest["usesPlatformLlm"] = True

    # 写到 staging
    manifest_path = staging_dir / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    return manifest


# ── 上传 ──────────────────────────────────────────────────

def upload_to_cloud(
    project_dir: Path,
    config: dict,
    manifest: dict,
) -> dict:
    """上传到 LoongClaw Cloud API。

    v0.8.0 起使用 `requests` + `requests-toolbelt.MultipartEncoder`
    做**流式** multipart 上传（不把 zip 整体拼进内存，带 Content-Length +
    Expect: 100-continue），从根上消除 v0.7.x 大 zip 场景的 BrokenPipe 问题。

    依赖缺失时直接报错（Fail Fast）——不回退到已知有 BrokenPipe 问题的
    老 urllib 路径，避免用户升级后仍静默踩同一个坑。
    """
    token = config.get("token", "")
    if not token:
        token = os.environ.get("LOONGCLAW_STORE_KEY", "")
    if not token:
        return {"status": "error", "step": "upload",
                "code": PublishErrorCode.UPLOAD_NO_TOKEN,
                "error": "缺少 Store Key。设置环境变量 LOONGCLAW_STORE_KEY 或在 .publish.json 中配置 token",
                "fix": "前往 https://loongclaw.net.cn/dev/ 申请开发者并生成 Store Key"}

    zip_path = project_dir / "project.zip"
    if not zip_path.exists():
        return {"status": "error", "step": "upload",
                "error": "project.zip 不存在",
                "fix": "检查打包步骤是否成功"}

    manifest_path = project_dir / "_staging" / "manifest.json"
    if not manifest_path.exists():
        manifest_path = project_dir / "manifest.json"

    url = f"{CLOUD_API_BASE}{UPLOAD_ENDPOINT}"
    access_type = config["access"]  # 前置 validate_config 已保证 public/private 白名单

    # ── 流式上传：requests + requests-toolbelt ─────────────
    try:
        import requests
        from requests_toolbelt import MultipartEncoder
    except ImportError:
        return {"status": "error", "step": "upload",
                "code": PublishErrorCode.UPLOAD_DEPS_MISSING,
                "error": "缺少上传所需依赖：requests + requests-toolbelt",
                "fix": "在当前 Python 环境执行：pip install 'requests>=2.25' 'requests-toolbelt>=1.0.0'，然后重新运行 publish.py"}

    manifest_bytes = json.dumps(manifest, ensure_ascii=False).encode("utf-8")

    # MultipartEncoder: zip 以文件句柄传入 → urllib3 按 chunk 读，内存占用 ≈ 8KB 而非整 zip 大小
    zip_fp = zip_path.open("rb")
    try:
        encoder = MultipartEncoder(
            fields={
                "manifest": ("manifest.json", manifest_bytes, "application/json"),
                "archive": ("project.zip", zip_fp, "application/zip"),
                "accessType": access_type,
            }
        )
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": encoder.content_type,
            # Expect: 100-continue —— 服务端拒绝时不上传 body，避免写到一半 RST
            "Expect": "100-continue",
        }

        try:
            # v0.9.0 #4（超时铁律）：read timeout 设为 None。
            # 连接阶段仍有 10s 上限（网络建立失败应快速反馈），但 body 上传/服务端
            # 处理时间由 TCP keepalive + SDK 自行判定，不强加应用层超时。
            # 旧版 300s → 用户在几十 MB 大包 + 弱网下被误杀；改 1800s 是打补丁。
            # 触发读超时 = 100% 伤害用户体验，零正面价值（见 CLAUDE.md 超时铁律）。
            resp = requests.post(url, data=encoder, headers=headers, timeout=(10, None))
        except requests.exceptions.ConnectionError as e:
            return {"status": "error", "step": "upload",
                    "code": PublishErrorCode.UPLOAD_NETWORK_ERROR,
                    "error": f"连接错误: {e}",
                    "fix": "检查网络连接和 CLOUD_API_BASE 地址；确认未被防火墙/代理拦截"}
        except requests.exceptions.Timeout as e:
            # 触发点：connect timeout 10s 内连不上服务器（DNS/防火墙/服务不可达）
            return {"status": "error", "step": "upload",
                    "code": PublishErrorCode.UPLOAD_NETWORK_ERROR,
                    "error": f"连接服务器超时: {e}",
                    "fix": "检查网络与 CLOUD_API_BASE 可达性；持续失败联系管理员"}
        except requests.exceptions.RequestException as e:
            return {"status": "error", "step": "upload",
                    "code": PublishErrorCode.UPLOAD_NETWORK_ERROR,
                    "error": f"网络错误: {e}",
                    "fix": "检查网络连接和 CLOUD_API_BASE 地址"}

        if resp.status_code == 200:
            try:
                result = resp.json()
            except ValueError:
                return {"status": "error", "step": "upload",
                        "code": PublishErrorCode.UPLOAD_BAD_RESPONSE,
                        "error": f"服务端响应不是 JSON: {resp.text[:300]}",
                        "fix": "联系管理员检查服务端日志"}
            return {"status": "success", **result}

        # HTTP 非 200
        err_body = resp.text[:300] if resp.text else ""
        return {"status": "error", "step": "upload",
                "code": PublishErrorCode.UPLOAD_HTTP_ERROR,
                "http_status": resp.status_code,
                "error": f"HTTP {resp.status_code}: {err_body}",
                "fix": "检查 token 是否有效；403 通常是非原上传者或 Store Key 权限不足；"
                       "400 通常是 manifest 字段校验失败，按响应中的详情修正 .publish.json"}
    finally:
        zip_fp.close()


# ── 配置管理 ─────────────────────────────────────────────

def load_config(project_dir: Path) -> dict | None:
    cfg_path = project_dir / CONFIG_FILE
    if cfg_path.exists():
        try:
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
            # v0.9.0 起删除 skipEncrypt 字段。迁移路径：改用 .mcpignore 完全排除非
            # MCP 运行时文件出包，而不是保留明文。老配置直接丢弃字段并提示。
            if isinstance(cfg, dict) and "skipEncrypt" in cfg:
                legacy = cfg.pop("skipEncrypt")
                if legacy:
                    print(
                        f"  ⚠ 检测到 .publish.json 中的 skipEncrypt 字段（已废弃 v0.9.0）。"
                        f"\n     原值: {legacy}"
                        f"\n     请改为在项目根创建 .mcpignore 把这些文件完全排除出包"
                        f"\n     （gitignore 语法；示例见 README）。\n"
                    )
            return cfg
        except (json.JSONDecodeError, OSError):
            pass
    return None


def save_config(project_dir: Path, config: dict) -> None:
    cfg_path = project_dir / CONFIG_FILE
    # 不保存 token 到配置文件（安全）
    safe = {k: v for k, v in config.items() if k != "token"}
    cfg_path.write_text(
        json.dumps(safe, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


# ── 主流程 ────────────────────────────────────────────────
#
# v0.9.0 起 devkit 定位为 AI-first：所有配置通过 .publish.json + CLI flag / MCP
# 工具输入，**不再提供 input() 交互式配置**。旧的 interactive_config() 已删除。
# 这意味着：
#   - 没有 .publish.json 且没传 --id / --version / --access 等 CLI flag 时，
#     直接在 _validate_config 阶段报错退出（Fail-Close），不阻塞等用户敲键盘
#   - 开发者用 AI 操作：AI 调 devkit MCP 工具 create_mcp_project / update_mcp_config
#     写 .publish.json，再调 publish_mcp 触发发布
#   - CLI 仍保留（python publish.py --auto --id ... --version ...）作为紧急逃生

# 上传体积三层查询（v0.9.0 #10 根因修复，v0.9.3 扩展 warnMb）
# 服务端是单一权威来源（对齐「服务端数据权威铁律」）——devkit 不该硬编码阈值。
# 顺序：Cloud GET /v1/store/limits → LOONGCLAW_MAX_UPLOAD_MB env → 硬编码 500/300 MB。
# 三层都会返回 (max_mb, warn_mb)；warn 默认 = max * 0.6（在限制内留足处理空间）。
#
# WHY fallback 选 500：仅在 cloud 不可达时触发。设太小（如 50）会让真实有大包的离线
# 开发者被自己的 fallback 误伤；设无上限又失去 fallback 的意义。500 MB 是"足够覆盖
# 95% 合法场景 + 仍能挡住明显异常"的折中值。cloud 一旦可达立即覆盖。
_DEFAULT_MAX_UPLOAD_MB = 500
_DEFAULT_WARN_RATIO = 0.6


def fetch_upload_limit_mb() -> tuple[int, int, str]:
    """返回 (max_mb, warn_mb, source)。source 用于日志透明呈现阈值来源。

    warn_mb 是“建议上限”（超过会警告但仍可上传），max_mb 是硬限（超过服务端拒绝）。
    老版 Cloud 不返 warnUploadMb 字段时 fallback 到 max * _DEFAULT_WARN_RATIO。
    """
    def _with_default_warn(max_mb: int, warn_raw: int | None, source: str) -> tuple[int, int, str]:
        if warn_raw and warn_raw > 0:
            return max_mb, min(warn_raw, max_mb), source
        return max_mb, max(1, int(max_mb * _DEFAULT_WARN_RATIO)), source

    # 1) Cloud 单源
    try:
        import requests
        resp = requests.get(
            f"{CLOUD_API_BASE}/v1/store/limits",
            timeout=(5, 5),
        )
        if resp.status_code == 200:
            data = resp.json()
            mb = int(data.get("maxUploadMb") or 0)
            warn = int(data.get("warnUploadMb") or 0)
            if mb > 0:
                return _with_default_warn(mb, warn or None, "cloud")
    except Exception:
        pass  # Cloud 不可用 → 继续 fallback

    # 2) env 覆盖（只覆盖 max，warn 从 max 推导）
    env_val = os.environ.get("LOONGCLAW_MAX_UPLOAD_MB", "").strip()
    if env_val.isdigit() and int(env_val) > 0:
        return _with_default_warn(int(env_val), None, "env")

    # 3) 硬编码兜底
    return _with_default_warn(_DEFAULT_MAX_UPLOAD_MB, None, "builtin")


def run(config: dict, project_dir: Path, json_output: bool = False) -> dict:
    """执行完整发布流程，返回结果字典。

    v0.9.0 起 staging 清理包裹在 try/finally 中——无论中途 raise/exit 哪一步，
    _staging/ 一定被清掉，防止下一次 `publish.py` 读到旧残留或嵌套膨胀。
    """
    total_steps = 6 if config.get("upload") else 5
    result: dict = {"status": "success", "steps": {}}
    staging_dir = project_dir / "_staging"

    try:
        # Step 1: 校验
        print_step(1, total_steps, "校验项目结构...")
        runtime = config.get("runtime", "python")
        errors = validate_project(project_dir, runtime=runtime)
        # private 付费包额外要求 FastMCP 实例必须命名为 `mcp`（壳模式约定）
        # self-contained 走 mcp.command 启动不需检查
        if not errors and config.get("access") == "private" and runtime == "python":
            errors = check_entrypoint_mcp_instance(project_dir)
        if errors:
            result = {
                "status": "error", "step": "validate",
                "errors": errors,
                "fix": "; ".join(errors),
            }
            if json_output:
                print(json.dumps(result, ensure_ascii=False))
            else:
                for e in errors:
                    print(f"  ❌ {e}")
            return result
        print("  ✅ 项目结构正确")

        # 跨平台兼容性警告（不阻断，但在 JSON 中记录）
        compat_warnings = check_requirements_compat(project_dir)
        if compat_warnings:
            result["warnings"] = compat_warnings
            for w in compat_warnings:
                print(f"  ⚠ {w}")
        result["steps"]["validate"] = "ok"

        # Step 2: 准备 staging
        if staging_dir.exists():
            shutil.rmtree(staging_dir)
        staging_dir.mkdir()

        # Step 3: 加密编译
        print_step(2, total_steps, "Cython 加密编译...")
        py_files = find_py_files(project_dir)
        # WHY: skipCython=true 或 runtime=self-contained 跳过加密。
        # - skipCython: 开发者显式要求（中间产物已是 .so/.pyd 等，纯明文补充资源不需加密）
        # - self-contained: 开发者自带运行时，客户端不读 .py（典型场景是项目里只有
        #   预编译二进制 / .so / .exe，没有 .py 业务源码）
        #
        # SECURITY (2026-04-25 v0.10.1)：private 付费包永远走 encrypt_files()，
        # 不允许任何路径绕过。源头权威是 access_type，"加密 vs 不加密" 与
        # "解释器类型 vs 自带运行时" 是两个正交维度。private + self-contained
        # + 项目里没有 .py 业务源码 → encrypt_files() 内部 to_encrypt 为空会安全
        # return；private + self-contained + 项目里仍有 .py → encrypt_files() 的
        # PRIVATE_PLAINTEXT_LEAK Fail-Close 防线统一守门。
        skip_cython = bool(config.get("skipCython", False))
        access_type = config.get("access", "public")
        should_skip = (skip_cython or runtime == "self-contained") and access_type != "private"
        if should_skip:
            reason = "runtime=self-contained" if runtime == "self-contained" else "skipCython=true"
            print(f"  ⏭  跳过加密（{reason}，access={access_type}）")
            # 所有过滤后的 .py 作为明文（package_project 会拷到 staging）
            encrypted: list[str] = []
            plain: list[str] = [str(p.relative_to(project_dir)) for p in py_files]
        else:
            encrypted, plain = encrypt_files(
                project_dir, py_files,
                staging_dir,
                access=access_type,
            )
        print(f"  ✅ 加密 {len(encrypted)} 个，明文 {len(plain)} 个")
        result["steps"]["encrypt"] = {"encrypted": len(encrypted), "plain": len(plain)}

        # PLAT1：Cython 加密产物绑定构建平台——告警提示开发者多平台用户会安装失败
        # 客户端已有 precheck 拦截（zip-entries.ts），但把"为什么会拦"提前告诉开发者
        # 避免收到用户反馈才意识到问题。
        if len(encrypted) > 0:
            plat_label = {
                "darwin": "macOS",
                "win32": "Windows",
                "linux": "Linux",
            }.get(sys.platform, sys.platform)
            py_ver = f"{sys.version_info.major}.{sys.version_info.minor}"
            warn_msg = (
                f"Cython 产物绑定构建平台（{plat_label}）+ Python {py_ver}；"
                f"其他平台用户安装时会被客户端 precheck 拒绝。"
            )
            # v0.9.1 #14 文案修正：说清楚 manifest 会自动写 buildPlatform + requiredPython
            # 两个字段供客户端 precheck 使用，不要误导开发者以为只锁 Python 版本。
            fix_msg = (
                "当前会自动写入 manifest：buildPlatform=" + sys.platform +
                f"，requiredPython 锁 {py_ver} ABI。\n"
                "     缓解方案：① 每个目标平台各构建一次并分别上传（Store 多平台模型见"
                " BACKLOG #14，计划中）；② 改 access=public 发布明文 .py"
                "（跨平台兼容，但源码会被用户看到）；③ 在 .publish.json 显式声明"
                " requiredPython（可覆盖自动值，适合纯 Python 包）。"
            )
            print(f"  ⚠ {warn_msg}")
            print(f"     {fix_msg}")
            # 累积到 warnings（JSON 输出 + AI 调用方可读）
            result.setdefault("warnings", []).append(warn_msg)

        # Step 4: 打包
        print_step(3, total_steps, "打包 project.zip...")
        zip_path = package_project(
            project_dir, staging_dir, plain,
            bundle_vendor=bool(config.get("bundleVendor", False)),
        )
        size_mb = zip_path.stat().st_size / 1024 / 1024
        print(f"  ✅ {zip_path.name} ({size_mb:.1f} MB)")
        result["steps"]["package"] = {"size_mb": round(size_mb, 1)}

        # v0.9.0 #10 体积查询（v0.9.3：warn 亦来自服务端）
        max_mb, warn_mb, src = fetch_upload_limit_mb()
        if size_mb > max_mb:
            err = (
                f"project.zip 体积 {size_mb:.1f} MB 超过上传上限 {max_mb} MB "
                f"（来源: {src}）"
            )
            fix = (
                "精简依赖或在 .publish.json 关闭 bundleVendor（默认已关闭）；"
                "或在 .mcpignore 中排除大文件。"
                if config.get("bundleVendor") else
                "精简依赖或检查是否有大二进制/数据文件应写入 .mcpignore。"
            )
            result.update({"status": "error", "step": "package",
                           "error": err, "fix": fix})
            if json_output:
                print(json.dumps(result, ensure_ascii=False))
            else:
                print(f"  ❌ {err}\n     {fix}")
            return result
        if size_mb > warn_mb:
            print(f"  ⚠ 体积偏大（{size_mb:.1f} MB，告警阈值 {warn_mb} MB / 上限 {max_mb} MB）；上传可能较慢")

        # 路径一致性校验
        zip_warnings = verify_zip_paths(project_dir, zip_path)
        if zip_warnings:
            result["status"] = "error"
            result["step"] = "verify"
            result["errors"] = zip_warnings
            result["fix"] = (
                "server.py 引用的路径在打包后不存在。"
                "请确保 server.py 中的路径引用与 project.zip 的目录结构一致。"
            )
            if json_output:
                print(json.dumps(result, ensure_ascii=False))
            else:
                for w in zip_warnings:
                    print(f"  ❌ {w}")
                print("  💡 常见原因：开发环境中 project.zip 从子目录内部打包，"
                      "导致 zip 中缺少了一层目录前缀。")
            return result

        # Step 5: 生成 manifest
        print_step(4, total_steps, "生成 manifest.json...")
        manifest = generate_manifest(
            project_dir, staging_dir, config, encrypted_count=len(encrypted)
        )
        print(f"  ✅ {manifest['id']} v{manifest['version']}")
        if "requiredPython" in manifest:
            print(f"     requiredPython = {manifest['requiredPython']}")
        if "buildPlatform" in manifest:
            print(f"     buildPlatform  = {manifest['buildPlatform']}")
        result["steps"]["manifest"] = manifest

        # Step 6: 上传（可选）
        if config.get("upload"):
            print_step(5, total_steps, "上传到 LoongClaw 服务器...")
            upload_result = upload_to_cloud(project_dir, config, manifest)
            if upload_result["status"] == "error":
                result["status"] = "error"
                result["step"] = "upload"
                result["error"] = upload_result["error"]
                result["fix"] = upload_result.get("fix", "")
                if json_output:
                    print(json.dumps(result, ensure_ascii=False))
                else:
                    print(f"  ❌ {upload_result['error']}")
                return result
            # v0.9.1 #16：上传成功后打印详细确认信息，方便开发者/AI 核对
            print("  ✅ 上传成功")
            print(f"     插件 ID   : {manifest['id']}")
            print(f"     版本      : v{manifest['version']}")
            print(f"     访问类型  : {config.get('access', 'public')}")
            if manifest.get("buildPlatform"):
                print(f"     构建平台  : {manifest['buildPlatform']}")
            if manifest.get("requiredPython"):
                print(f"     Python 版 : {manifest['requiredPython']}")
            print(f"     包大小    : {size_mb:.1f} MB")
            if upload_result.get("url"):
                print(f"     上传地址  : {upload_result['url']}")
            result["steps"]["upload"] = "ok"

        # 保存配置
        save_config(project_dir, config)

        result["version"] = config["version"]
        result["files_encrypted"] = len(encrypted)
        result["uploaded"] = config.get("upload", False)

        if json_output:
            print(json.dumps(result, ensure_ascii=False))
        else:
            print(f"\n{'═' * 50}")
            print(f"  发布完成！ {config['id']} v{config['version']}")
            if config.get("access") == "private":
                print("  📌 访问类型: 付费（需商务开通）")
            else:
                print("  📌 访问类型: 公开")
            print(f"{'═' * 50}")

        return result
    finally:
        # v0.9.0 #8 根因：无论成功/失败/raise 哪条路径，staging 都必须被清掉。
        # 旧代码在每个 error return 前手动 rmtree，漏一处就会留残留，下次编译
        # 读到旧文件 → 嵌套膨胀 / 幻觉行为。
        shutil.rmtree(staging_dir, ignore_errors=True)


def _apply_cli_overrides(config: dict, args: argparse.Namespace) -> dict:
    """CLI flag 覆盖已有 config（无论 config 来自 saved 还是 auto 初始化）。

    v0.9.0 #2 根因：flag override 必须独立于 mode 选择器。旧版本把 CLI 覆盖只写在
    `--auto` 分支里，所以 `python publish.py --version 1.0.1`（无 --auto）在已有
    .publish.json 时 saved 直接赢，命令行参数被静默忽略。
    根因修复：任何模式下，非 None 的 CLI flag 都覆盖 config 相应字段。
    """
    if args.id:
        config["id"] = args.id
    if args.name:
        config["name"] = args.name
    if args.version:
        config["version"] = args.version
    if args.access:
        config["access"] = args.access
    # upload 是布尔：--upload / --no-upload 都是显式意图；都没传保留 saved
    if args.upload:
        config["upload"] = True
    elif args.no_upload:
        config["upload"] = False
    if args.token:
        config["token"] = args.token
    return config


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "LoongClaw MCP 一键发布工具（AI-first，CLI 为紧急逃生）。"
            "正常使用请让 AI 调用 devkit MCP 工具 publish_mcp。"
        ),
    )
    parser.add_argument("--auto", action="store_true",
                        help="自动模式（v0.9.0 起唯一模式，保留参数仅为向后兼容）")
    parser.add_argument("--json-output", action="store_true",
                        help="JSON 格式输出（适合 AI 解析）")
    parser.add_argument("--id", type=str, help="插件 ID")
    parser.add_argument("--name", type=str, help="插件名称")
    parser.add_argument("--version", type=str, help="版本号")
    parser.add_argument("--access", choices=["public", "private"], help="访问类型")
    parser.add_argument("--upload", action="store_true", help="上传到服务器")
    parser.add_argument("--no-upload", action="store_true", help="不上传")
    parser.add_argument("--token", type=str, help="LoongClaw Store Key")
    parser.add_argument("--dir", type=str, default=".",
                        help="项目目录（默认当前目录）")
    args = parser.parse_args()

    project_dir = Path(args.dir).resolve()
    json_output = args.json_output

    # v0.9.0：只剩 auto 模式。没有 .publish.json 且没传必需 CLI flag 时，
    # _validate_config 会 Fail-Close 拦截并报错退出。
    saved = load_config(project_dir) or {}
    detected = detect_project_info(project_dir)
    config = {
        "id": saved.get("id") or detected.get("id") or project_dir.name,
        "name": saved.get("name") or saved.get("id", project_dir.name),
        "version": saved.get("version", "1.0.0"),
        "description": saved.get("description") or detected.get("description", ""),
        "author": saved.get("author", ""),
        "icon": saved.get("icon", "🔧"),
        # 2026-04-22 Fail-Close：不再 `or "public"` 兜底——必填且由 _validate_config 拦截空值
        "access": saved.get("access", ""),
        "upload": saved.get("upload", False),
        "bundleVendor": bool(saved.get("bundleVendor", False)),
        "token": os.environ.get("LOONGCLAW_STORE_KEY", ""),
    }

    # CLI flag 统一覆盖（所有模式共用）—— v0.9.0 #2 根因修复
    config = _apply_cli_overrides(config, args)

    # Fail-Close 预校验
    _validate_config(config, json_output)

    run(config, project_dir, json_output)


if __name__ == "__main__":
    main()
