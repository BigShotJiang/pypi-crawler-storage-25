# HemoSim

Reinforcement learning Gymnasium environments for hemostasis and anticoagulation management.

## Installation

```bash
pip install hemosim
```

## Environments

| Environment | Description | Observation | Action |
|---|---|---|---|
| `hemosim/WarfarinDosing-v0` | 90-day warfarin titration | Box(8) | Box(1) |
| `hemosim/HeparinInfusion-v0` | 5-day heparin infusion | Box(6) | Box(2) |
| `hemosim/DOACManagement-v0` | 365-day DOAC selection | Box(8) | MultiDiscrete(3,3) |
| `hemosim/DICManagement-v0` | 7-day DIC management | Box(8) | MultiDiscrete(4,4,3,3) |

## Quick Start

```python
import gymnasium as gym
import hemosim

env = gym.make("hemosim/WarfarinDosing-v0")
obs, info = env.reset(seed=42)

for _ in range(90):
    action = env.action_space.sample()
    obs, reward, terminated, truncated, info = env.step(action)
    if terminated or truncated:
        break

env.close()
```

## License

MIT License. Copyright (c) 2026 Hass Dhia, Smart Technology Investments Research Institute.
