"""Warfarin population PK/PD model.

Based on the Hamberg et al. (2007) population pharmacokinetic/pharmacodynamic model
for S- and R-warfarin with CYP2C9 and VKORC1 genotype effects.

State variables:
    0: S_warfarin_central      - S-warfarin in central compartment (mg/L)
    1: S_warfarin_peripheral   - S-warfarin in peripheral compartment (mg/L)
    2: R_warfarin_central      - R-warfarin in central compartment (mg/L)
    3: R_warfarin_peripheral   - R-warfarin in peripheral compartment (mg/L)
    4: vitamin_K_cycle         - Vitamin K cycle activity (fraction, 0-1)
    5: INR_delay_1             - Transit compartment 1 for INR delay
    6: INR_delay_2             - Transit compartment 2 for INR delay
    7: INR                     - Observed INR

Reference:
    Hamberg AK, Dahl ML, Barber TM, et al. A PK-PD model for predicting
    the impact of age, CYP2C9, and VKORC1 genotype on individualization
    of warfarin therapy. Clin Pharmacol Ther. 2007;81(4):529-538.
"""

from __future__ import annotations

import numpy as np


# CYP2C9 genotype effects on S-warfarin clearance (relative to *1/*1)
# From Hamberg et al. (2007) Table 3
CYP2C9_CL_FACTOR = {
    "*1/*1": 1.00,
    "*1/*2": 0.78,
    "*1/*3": 0.56,
    "*2/*2": 0.60,
    "*2/*3": 0.44,
    "*3/*3": 0.31,
}

# VKORC1 -1639G>A genotype effects on warfarin sensitivity (EC50 multiplier)
# From Hamberg et al. (2007) - lower EC50 means more sensitive
VKORC1_EC50_FACTOR = {
    "GG": 1.00,
    "GA": 0.65,
    "AA": 0.45,
}


class WarfarinPKPD:
    """Two-compartment PK model for S/R-warfarin with PD INR response.

    Implements the Hamberg et al. (2007) population PK/PD model with:
    - Separate S- and R-warfarin two-compartment pharmacokinetics
    - CYP2C9 genotype effect on S-warfarin clearance
    - VKORC1 genotype effect on warfarin sensitivity (EC50)
    - Age effect on clearance
    - Inhibitory Emax model with transit compartment delay for INR
    """

    N_STATES = 8

    def __init__(
        self,
        cyp2c9: str = "*1/*1",
        vkorc1: str = "GG",
        age: float = 60.0,
        weight: float = 75.0,
    ) -> None:
        if cyp2c9 not in CYP2C9_CL_FACTOR:
            raise ValueError(f"Invalid CYP2C9 genotype: {cyp2c9}")
        if vkorc1 not in VKORC1_EC50_FACTOR:
            raise ValueError(f"Invalid VKORC1 genotype: {vkorc1}")

        self.cyp2c9 = cyp2c9
        self.vkorc1 = vkorc1
        self.age = age
        self.weight = weight

        # S-warfarin PK parameters (Hamberg 2007)
        self.s_cl_base = 0.15  # L/h - base clearance
        self.s_vc = 10.0       # L   - central volume
        self.s_vp = 8.0        # L   - peripheral volume
        self.s_q = 0.5         # L/h - intercompartmental clearance
        self.s_ka = 1.5        # 1/h - absorption rate constant

        # R-warfarin PK parameters
        self.r_cl_base = 0.065  # L/h - base clearance (R is slower)
        self.r_vc = 10.0        # L
        self.r_vp = 8.0         # L
        self.r_q = 0.5          # L/h
        self.r_ka = 1.5         # 1/h

        # Genotype and covariate adjustments
        self.cyp2c9_factor = CYP2C9_CL_FACTOR[cyp2c9]
        self.vkorc1_factor = VKORC1_EC50_FACTOR[vkorc1]

        # Age effect on clearance: CL * (age/60)^(-0.3) from Hamberg 2007
        self.age_factor = (age / 60.0) ** (-0.3)

        # Adjusted clearances
        self.s_cl = self.s_cl_base * self.cyp2c9_factor * self.age_factor
        self.r_cl = self.r_cl_base * self.age_factor

        # PD parameters - inhibitory Emax model
        self.emax = 1.0        # maximum inhibition fraction
        self.ec50 = 1.5        # mg/L - adjusted by VKORC1
        self.ec50_adjusted = self.ec50 * self.vkorc1_factor
        self.hill = 1.3        # Hill coefficient
        self.baseline_inr = 1.0

        # Transit compartment rate for INR delay (~36-72h delay)
        self.k_transit = 0.04  # 1/h (~25h mean transit time per compartment)

        # State vector
        self.state = np.zeros(self.N_STATES)
        self.state[4] = 1.0  # vitamin K cycle fully active
        self.state[7] = self.baseline_inr  # baseline INR

    def step(self, dose_mg: float, dt_hours: float = 24.0) -> np.ndarray:
        """Advance the model by one time step with an oral warfarin dose.

        Args:
            dose_mg: Oral warfarin dose in mg (racemic mixture, 50/50 S/R).
            dt_hours: Time step in hours (default 24h for daily dosing).

        Returns:
            Updated state vector.
        """
        # Warfarin is a racemic mixture: ~50% S-warfarin, ~50% R-warfarin
        s_dose = dose_mg * 0.5
        r_dose = dose_mg * 0.5

        # Add dose at start of step (oral absorption at beginning of period)
        self.state[0] += s_dose  # mg added to central
        self.state[2] += r_dose

        # Substep with Euler integration (small steps for stability)
        n_substeps = max(int(dt_hours / 0.5), 1)
        h = dt_hours / n_substeps

        for _ in range(n_substeps):
            s_central = max(self.state[0], 0.0)
            s_periph = max(self.state[1], 0.0)
            r_central = max(self.state[2], 0.0)
            r_periph = max(self.state[3], 0.0)
            vk_cycle = np.clip(self.state[4], 0.0, 1.0)
            delay1 = self.state[5]
            delay2 = self.state[6]
            inr = max(self.state[7], 0.5)

            # S-warfarin concentrations
            s_conc_central = s_central / self.s_vc
            s_conc_periph = s_periph / self.s_vp

            # R-warfarin concentrations
            r_conc_central = r_central / self.r_vc
            r_conc_periph = r_periph / self.r_vp

            # S-warfarin PK
            ds_central = (
                - self.s_cl * s_conc_central
                - self.s_q * (s_conc_central - s_conc_periph)
            )
            ds_periph = self.s_q * (s_conc_central - s_conc_periph)

            # R-warfarin PK
            dr_central = (
                - self.r_cl * r_conc_central
                - self.r_q * (r_conc_central - r_conc_periph)
            )
            dr_periph = self.r_q * (r_conc_central - r_conc_periph)

            # PD: Warfarin inhibits vitamin K cycle
            # Combined S+R effect (S-warfarin is ~3-5x more potent)
            effective_conc = s_conc_central * 3.0 + r_conc_central
            inhibition = (
                self.emax * effective_conc ** self.hill
                / (self.ec50_adjusted ** self.hill + effective_conc ** self.hill)
            )

            # Vitamin K cycle: inhibited by warfarin, recovers naturally
            dvk = 0.04 * (1.0 - vk_cycle) - 0.04 * inhibition * vk_cycle

            # INR response through transit compartments (delayed response)
            # INR increases as vitamin K cycle is suppressed
            target_inr = self.baseline_inr / max(vk_cycle, 0.01)
            target_inr = np.clip(target_inr, 0.8, 12.0)

            d_delay1 = self.k_transit * (target_inr - delay1)
            d_delay2 = self.k_transit * (delay1 - delay2)
            d_inr = self.k_transit * (delay2 - inr)

            # Update state
            self.state[0] = max(s_central + ds_central * h, 0.0)
            self.state[1] = max(s_periph + ds_periph * h, 0.0)
            self.state[2] = max(r_central + dr_central * h, 0.0)
            self.state[3] = max(r_periph + dr_periph * h, 0.0)
            self.state[4] = np.clip(vk_cycle + dvk * h, 0.01, 1.0)
            self.state[5] = delay1 + d_delay1 * h
            self.state[6] = delay2 + d_delay2 * h
            self.state[7] = max(inr + d_inr * h, 0.5)

        return self.state.copy()

    def get_inr(self) -> float:
        """Return current INR value."""
        return float(max(self.state[7], 0.5))

    def get_concentration(self) -> dict[str, float]:
        """Return current S/R warfarin plasma concentrations in mg/L."""
        return {
            "s_warfarin": max(self.state[0] / self.s_vc, 0.0),
            "r_warfarin": max(self.state[2] / self.r_vc, 0.0),
        }

    def reset(self) -> np.ndarray:
        """Reset model to initial (drug-free) state."""
        self.state = np.zeros(self.N_STATES)
        self.state[4] = 1.0  # vitamin K cycle active
        self.state[7] = self.baseline_inr
        return self.state.copy()
