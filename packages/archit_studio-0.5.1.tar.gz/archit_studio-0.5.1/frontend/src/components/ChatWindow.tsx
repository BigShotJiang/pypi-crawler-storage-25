import { useEffect, useRef } from 'react'
import { AnyMessage } from '../types'
import { Message } from './Message'

interface Props {
  messages: AnyMessage[]
  isThinking: boolean
  onApprovePhase: () => void
}

export function ChatWindow({ messages, isThinking, onApprovePhase }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isThinking])

  return (
    <div className="chat-window">
      {messages.map(msg => (
        <Message key={msg.id} message={msg} onApprovePhase={onApprovePhase} />
      ))}

      {isThinking && (
        <div className="message message--thinking">
          <div className="message__author">Architecture Team</div>
          <div className="message__bubble">
            <span className="thinking-dots">
              <span />
              <span />
              <span />
            </span>
            <span className="thinking-label">Consulting the design team…</span>
          </div>
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  )
}
