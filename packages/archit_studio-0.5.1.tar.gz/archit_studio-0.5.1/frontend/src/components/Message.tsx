import { useEffect, useRef, useState } from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { AnyMessage, ChatMessage, PhaseGateMessage, SvgMessage } from '../types'

function isSvg(msg: AnyMessage): msg is SvgMessage {
  return (msg as SvgMessage).type === 'svg'
}

function isPhaseGate(msg: AnyMessage): msg is PhaseGateMessage {
  return (msg as PhaseGateMessage).type === 'phase_complete'
}

interface Props {
  message: AnyMessage
  onApprovePhase: () => void
}

export function Message({ message, onApprovePhase }: Props) {
  if (isPhaseGate(message)) {
    return <PhaseGateCard msg={message} onApprove={onApprovePhase} />
  }
  if (isSvg(message)) {
    return <SvgCard msg={message} />
  }
  return <ChatBubble msg={message as ChatMessage} />
}

function ChatBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === 'user'
  const isSystem = msg.role === 'system'
  const isBim = msg.role === 'bim'

  const containerClass = [
    'message',
    isUser ? 'message--user' : '',
    isSystem ? 'message--system' : '',
    isBim ? 'message--bim' : '',
  ].filter(Boolean).join(' ')

  return (
    <div className={containerClass}>
      {!isUser && (
        <div className="message__author">{msg.author}</div>
      )}
      <div className="message__bubble">
        <ReactMarkdown remarkPlugins={[remarkGfm]}>
          {msg.content}
        </ReactMarkdown>
      </div>
    </div>
  )
}

const PHASE_STEPS = ['site', 'floorplan', 'interiors', 'finalise']
const PHASE_LABELS: Record<string, string> = {
  site:      'Site & Brief',
  floorplan: 'Floor Plan',
  interiors: 'Furniture & Finishes',
  finalise:  'Validation & Export',
}

function PhaseGateCard({ msg, onApprove }: { msg: PhaseGateMessage; onApprove: () => void }) {
  const currentIdx = PHASE_STEPS.indexOf(msg.phase)

  return (
    <div className="message message--phase-gate">
      <div className="phase-gate">
        {/* Progress pip row */}
        <div className="phase-gate__steps">
          {PHASE_STEPS.map((step, i) => (
            <div key={step} className="phase-gate__step-item">
              <div
                className={[
                  'phase-gate__pip',
                  i < currentIdx  ? 'phase-gate__pip--done'    : '',
                  i === currentIdx ? 'phase-gate__pip--current' : '',
                ].filter(Boolean).join(' ')}
              />
              <span className="phase-gate__step-label">{PHASE_LABELS[step]}</span>
              {i < PHASE_STEPS.length - 1 && <div className="phase-gate__connector" />}
            </div>
          ))}
        </div>

        <div className="phase-gate__body">
          <span className="phase-gate__check">&#10003;</span>
          <div>
            <div className="phase-gate__done-label">{msg.phaseLabel} complete</div>
            <div className="phase-gate__next-label">Next: {msg.nextPhaseLabel}</div>
          </div>
        </div>

        <div className="phase-gate__actions">
          <button className="btn btn--primary phase-gate__continue" onClick={onApprove}>
            Continue to {msg.nextPhaseLabel} &rarr;
          </button>
          <span className="phase-gate__hint">or type feedback below to revise this phase</span>
        </div>
      </div>
    </div>
  )
}

/** All possible SVG layer groups in render order, with display labels. */
const LAYER_DEFS: { id: string; label: string }[] = [
  { id: 'rooms',         label: 'Rooms' },
  { id: 'slabs',         label: 'Slabs' },
  { id: 'ramps',         label: 'Ramps' },
  { id: 'staircases',    label: 'Staircases' },
  { id: 'walls',         label: 'Walls' },
  { id: 'openings',      label: 'Openings' },
  { id: 'beams',         label: 'Beams' },
  { id: 'columns',       label: 'Columns' },
  { id: 'furniture',     label: 'Furniture' },
  { id: 'dimensions',    label: 'Dimensions' },
  { id: 'section-marks', label: 'Sections' },
  { id: 'annotations',   label: 'Annotations' },
]

function SvgCard({ msg }: { msg: SvgMessage }) {
  const svgContainerRef = useRef<HTMLDivElement>(null)
  const [availableLayers, setAvailableLayers] = useState<string[]>([])
  const [visibleLayers, setVisibleLayers] = useState<Set<string>>(
    new Set(LAYER_DEFS.map(l => l.id))
  )

  // Discover which layer groups actually exist in this SVG
  useEffect(() => {
    const container = svgContainerRef.current
    if (!container) return
    const found = LAYER_DEFS
      .filter(l => container.querySelector(`#${l.id}`) !== null)
      .map(l => l.id)
    setAvailableLayers(found)
    // Reset visibility to all-on whenever a new SVG arrives
    setVisibleLayers(new Set(LAYER_DEFS.map(l => l.id)))
  }, [msg.svg])

  // Apply visibility to SVG <g> elements whenever state changes
  useEffect(() => {
    const container = svgContainerRef.current
    if (!container) return
    for (const { id } of LAYER_DEFS) {
      const el = container.querySelector<SVGGElement>(`#${id}`)
      if (el) {
        el.style.display = visibleLayers.has(id) ? '' : 'none'
      }
    }
  }, [visibleLayers, availableLayers])

  function toggleLayer(id: string) {
    setVisibleLayers(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function toggleAll() {
    if (visibleLayers.size === availableLayers.length) {
      setVisibleLayers(new Set())
    } else {
      setVisibleLayers(new Set(LAYER_DEFS.map(l => l.id)))
    }
  }

  const allOn = visibleLayers.size === availableLayers.length

  function downloadSvg() {
    const container = svgContainerRef.current
    const svgEl = container?.querySelector('svg')
    if (!svgEl) return
    const blob = new Blob([svgEl.outerHTML], { type: 'image/svg+xml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${msg.levelName.replace(/\s+/g, '_')}.svg`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="message message--svg">
      <div className="message__author">BIM Coordinator</div>
      <div className="message__bubble">
        <div className="svg-card__header">
          <div className="svg-card__header-left">
            <strong>{msg.levelName}</strong>
            {' — '}
            {msg.roomCount} room{msg.roomCount !== 1 ? 's' : ''},&nbsp;
            {msg.area.toFixed(1)} m² net area
          </div>
          <button className="download-btn download-btn--svg" onClick={downloadSvg} title="Download SVG">
            ↓ SVG
          </button>
        </div>

        {availableLayers.length > 0 && (
          <div className="layer-toolbar">
            <button
              className={`layer-btn layer-btn--all ${allOn ? 'layer-btn--on' : 'layer-btn--off'}`}
              onClick={toggleAll}
              title={allOn ? 'Hide all layers' : 'Show all layers'}
            >
              {allOn ? 'All' : 'None'}
            </button>
            <div className="layer-toolbar__divider" />
            {availableLayers.map(id => {
              const def = LAYER_DEFS.find(l => l.id === id)!
              const on = visibleLayers.has(id)
              return (
                <button
                  key={id}
                  className={`layer-btn ${on ? 'layer-btn--on' : 'layer-btn--off'}`}
                  onClick={() => toggleLayer(id)}
                  title={on ? `Hide ${def.label}` : `Show ${def.label}`}
                >
                  {def.label}
                </button>
              )
            })}
          </div>
        )}

        <div
          className="svg-card__preview"
          ref={svgContainerRef}
          dangerouslySetInnerHTML={{ __html: msg.svg }}
        />
      </div>
    </div>
  )
}
