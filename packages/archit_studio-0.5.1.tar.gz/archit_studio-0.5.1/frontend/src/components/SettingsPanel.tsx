import { useState, useEffect } from 'react'
import { Model } from '../types'

interface Props {
  currentModel: string
  onClose: () => void
  onModelChange: (modelId: string) => Promise<unknown>
}

export function SettingsPanel({ currentModel, onClose, onModelChange }: Props) {
  const [models, setModels] = useState<Model[]>([])
  const [selected, setSelected] = useState(currentModel)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetch('/api/models')
      .then(r => r.json())
      .then(setModels)
      .catch(console.error)
  }, [])

  async function handleSave() {
    if (selected === currentModel) { onClose(); return }
    setSaving(true)
    await onModelChange(selected)
    setSaving(false)
    onClose()
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal__header">
          <h2>Settings</h2>
          <button className="modal__close" onClick={onClose}>✕</button>
        </div>

        <div className="modal__body">
          <label className="setting-label">Active LLM model</label>
          <div className="model-list">
            {models.map(m => (
              <label key={m.id} className={`model-option ${selected === m.id ? 'model-option--active' : ''}`}>
                <input
                  type="radio"
                  name="model"
                  value={m.id}
                  checked={selected === m.id}
                  onChange={() => setSelected(m.id)}
                />
                <span>{m.label}</span>
              </label>
            ))}
          </div>
        </div>

        <div className="modal__footer">
          <button className="btn btn--secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn--primary" onClick={handleSave} disabled={saving}>
            {saving ? 'Saving…' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  )
}
