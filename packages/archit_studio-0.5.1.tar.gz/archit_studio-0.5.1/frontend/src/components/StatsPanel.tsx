import { StatsData } from '../types'

interface Props {
  stats: StatsData
  sessionId: string | null
}

export function StatsPanel({ stats, sessionId }: Props) {
  const programEntries = Object.entries(stats.areaByProgram).sort((a, b) => b[1] - a[1])

  return (
    <aside className="stats-panel">
      <h3 className="stats-panel__title">Building Summary</h3>

      <div className="stats-panel__project">{stats.projectName}</div>

      <div className="stats-grid">
        <div className="stat">
          <div className="stat__value">{stats.totalLevels}</div>
          <div className="stat__label">Levels</div>
        </div>
        <div className="stat">
          <div className="stat__value">{stats.totalRooms}</div>
          <div className="stat__label">Rooms</div>
        </div>
        <div className="stat">
          <div className="stat__value">{stats.grossFloorArea} m²</div>
          <div className="stat__label">Gross area</div>
        </div>
      </div>

      {programEntries.length > 0 && (
        <div className="stats-program">
          <div className="stats-program__title">Programme</div>
          {programEntries.map(([k, v]) => (
            <div key={k} className="program-row">
              <span className="program-row__name">{k}</span>
              <span className="program-row__area">{v} m²</span>
            </div>
          ))}
        </div>
      )}

      <div className="stats-panel__model">
        Model: <code>{stats.model}</code>
      </div>

      {sessionId && (
        <div className="stats-panel__downloads">
          <a
            className="download-btn"
            href={`/api/download/${sessionId}/building.json`}
            download={`${stats.projectName || 'building'}.json`}
          >
            ↓ Building JSON
          </a>
        </div>
      )}
    </aside>
  )
}
