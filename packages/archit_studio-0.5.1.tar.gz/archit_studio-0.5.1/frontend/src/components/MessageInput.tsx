import { useState, useRef, KeyboardEvent, ChangeEvent } from 'react'

interface Props {
  onSend: (content: string) => void
  onUpload: (file: File) => Promise<void>
  onOpenSettings: () => void
  disabled: boolean
}

export function MessageInput({ onSend, onUpload, onOpenSettings, disabled }: Props) {
  const [text, setText] = useState('')
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      submit()
    }
  }

  function submit() {
    const trimmed = text.trim()
    if (!trimmed || disabled) return
    onSend(trimmed)
    setText('')
  }

  async function handleFileChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    try {
      await onUpload(file)
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  return (
    <div className="input-bar">
      <button
        className="icon-btn"
        title="Settings"
        onClick={onOpenSettings}
      >
        ⚙
      </button>

      <button
        className="icon-btn"
        title="Upload building file (.json / .geojson)"
        onClick={() => fileRef.current?.click()}
        disabled={uploading}
      >
        {uploading ? '⏳' : '📎'}
      </button>

      <input
        ref={fileRef}
        type="file"
        accept=".json,.geojson"
        style={{ display: 'none' }}
        onChange={handleFileChange}
      />

      <textarea
        className="input-bar__textarea"
        value={text}
        onChange={e => setText(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Describe the building you want to design… (Enter to send, Shift+Enter for newline)"
        rows={1}
        disabled={disabled}
      />

      <button
        className="icon-btn icon-btn--send"
        title="Send"
        onClick={submit}
        disabled={disabled || !text.trim()}
      >
        ➤
      </button>
    </div>
  )
}
