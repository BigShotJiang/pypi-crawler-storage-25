import { STARTERS } from '../types'

interface Props {
  onSelect: (message: string) => void
}

export function StarterButtons({ onSelect }: Props) {
  return (
    <div className="starters">
      <p className="starters__hint">Quick starters:</p>
      <div className="starters__grid">
        {STARTERS.map(s => (
          <button
            key={s.label}
            className="starter-btn"
            onClick={() => onSelect(s.message)}
          >
            <span className="starter-btn__icon">{s.icon}</span>
            <span className="starter-btn__label">{s.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
