import { useState, useEffect, useRef, useCallback } from 'react'
import { AnyMessage, ChatMessage, SvgMessage, PhaseGateMessage, StatsData, ServerEvent } from '../types'

function uid(): string {
  return Math.random().toString(36).slice(2) + Date.now().toString(36)
}

interface UseSessionReturn {
  sessionId: string | null
  messages: AnyMessage[]
  stats: StatsData | null
  isThinking: boolean
  isConnected: boolean
  sendMessage: (content: string) => void
  approvePhase: () => void
  uploadFile: (file: File) => Promise<void>
  updateModel: (modelId: string) => Promise<{ message: string } | null>
}

export function useSession(): UseSessionReturn {
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [messages, setMessages] = useState<AnyMessage[]>([])
  const [stats, setStats] = useState<StatsData | null>(null)
  const [isThinking, setIsThinking] = useState(false)
  const [isConnected, setIsConnected] = useState(false)

  const wsRef = useRef<WebSocket | null>(null)

  // Push a chat message into state
  const pushMessage = useCallback((msg: AnyMessage) => {
    setMessages(prev => [...prev, msg])
  }, [])

  // Initialise session + WebSocket
  useEffect(() => {
    let ws: WebSocket | null = null
    let cancelled = false

    async function init() {
      const res = await fetch('/api/session', { method: 'POST' })
      const data = await res.json()
      if (cancelled) return

      const sid: string = data.session_id
      setSessionId(sid)

      // Welcome message
      pushMessage({
        id: uid(),
        role: 'assistant',
        author: 'Project Manager',
        content: data.welcome,
        timestamp: new Date(),
      })

      // Open WebSocket
      const proto = window.location.protocol === 'https:' ? 'wss' : 'ws'
      const wsUrl = `${proto}://${window.location.host}/ws/${sid}`
      ws = new WebSocket(wsUrl)
      wsRef.current = ws

      ws.addEventListener('open', () => setIsConnected(true))
      ws.addEventListener('close', () => setIsConnected(false))

      ws.addEventListener('message', (ev: MessageEvent) => {
        const event: ServerEvent = JSON.parse(ev.data)

        if (event.type === 'thinking') {
          setIsThinking(true)
          return
        }

        setIsThinking(false)

        if (event.type === 'message') {
          const role: ChatMessage['role'] =
            event.author === 'System' ? 'system'
            : event.author === 'BIM Coordinator' ? 'bim'
            : 'assistant'
          pushMessage({
            id: uid(),
            role,
            author: event.author,
            content: event.content,
            timestamp: new Date(),
          })
        } else if (event.type === 'svg') {
          const svgMsg: SvgMessage = {
            id: uid(),
            type: 'svg',
            levelIndex: event.level_index,
            levelName: event.level_name,
            roomCount: event.room_count,
            area: event.area,
            svg: event.svg,
            timestamp: new Date(),
          }
          pushMessage(svgMsg)
        } else if (event.type === 'svg_error') {
          pushMessage({
            id: uid(),
            role: 'system',
            author: 'System',
            content: `Floor plan export failed for Level ${event.level_index}: ${event.error}`,
            timestamp: new Date(),
          })
        } else if (event.type === 'stats') {
          setStats({
            projectName: event.project_name,
            totalLevels: event.total_levels,
            totalRooms: event.total_rooms,
            grossFloorArea: event.gross_floor_area,
            areaByProgram: event.area_by_program,
            model: event.model,
          })
        } else if (event.type === 'error') {
          pushMessage({
            id: uid(),
            role: 'system',
            author: 'System',
            content: event.message,
            timestamp: new Date(),
          })
        } else if (event.type === 'phase_complete') {
          const gateMsg: PhaseGateMessage = {
            id: uid(),
            type: 'phase_complete',
            phase: event.phase,
            phaseLabel: event.phase_label,
            nextPhase: event.next_phase,
            nextPhaseLabel: event.next_phase_label,
            timestamp: new Date(),
          }
          pushMessage(gateMsg)
        }
      })
    }

    init().catch(console.error)

    return () => {
      cancelled = true
      ws?.close()
    }
  }, [pushMessage])

  const sendMessage = useCallback((content: string) => {
    const ws = wsRef.current
    if (!ws || ws.readyState !== WebSocket.OPEN) return

    pushMessage({
      id: uid(),
      role: 'user',
      author: 'You',
      content,
      timestamp: new Date(),
    })

    ws.send(JSON.stringify({ type: 'message', content }))
  }, [pushMessage])

  const approvePhase = useCallback(() => {
    const ws = wsRef.current
    if (!ws || ws.readyState !== WebSocket.OPEN) return
    ws.send(JSON.stringify({ type: 'phase_approve' }))
  }, [])

  const uploadFile = useCallback(async (file: File) => {
    if (!sessionId) return
    const form = new FormData()
    form.append('file', file)
    const res = await fetch(`/api/upload/${sessionId}`, { method: 'POST', body: form })
    const data = await res.json()

    const role: ChatMessage['role'] = data.author === 'BIM Coordinator' ? 'bim' : 'system'
    pushMessage({
      id: uid(),
      role,
      author: data.author ?? 'System',
      content: data.message,
      timestamp: new Date(),
    })
  }, [sessionId, pushMessage])

  const updateModel = useCallback(async (modelId: string) => {
    if (!sessionId) return null
    const res = await fetch(`/api/settings/${sessionId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId }),
    })
    const data = await res.json()
    if (data.ok) {
      pushMessage({
        id: uid(),
        role: 'system',
        author: 'System',
        content: data.message,
        timestamp: new Date(),
      })
    }
    return data
  }, [sessionId, pushMessage])

  return { sessionId, messages, stats, isThinking, isConnected, sendMessage, approvePhase, uploadFile, updateModel }
}
