import { useState } from 'react'
import { useSession } from './hooks/useSession'
import { ChatWindow } from './components/ChatWindow'
import { MessageInput } from './components/MessageInput'
import { StarterButtons } from './components/StarterButtons'
import { SettingsPanel } from './components/SettingsPanel'
import { StatsPanel } from './components/StatsPanel'

export default function App() {
  const { sessionId, messages, stats, isThinking, isConnected, sendMessage, approvePhase, uploadFile, updateModel } =
    useSession()
  const [showSettings, setShowSettings] = useState(false)

  // Only show starters when the only message is the welcome
  const showStarters = messages.length <= 1

  const currentModel = stats?.model ?? 'gpt-4o-mini'

  return (
    <div className="layout">
      {/* Header */}
      <header className="header">
        <div className="header__brand">
          <span className="header__logo">▣</span>
          <span className="header__title">Archit Studio</span>
        </div>
        <div className="header__status">
          <span className={`status-dot ${isConnected ? 'status-dot--on' : 'status-dot--off'}`} />
          <span className="header__model">{currentModel}</span>
        </div>
      </header>

      {/* Main area */}
      <div className="main">
        <div className="chat-area">
          {/* Messages */}
          <ChatWindow messages={messages} isThinking={isThinking} onApprovePhase={approvePhase} />

          {/* Quick starters */}
          {showStarters && !isThinking && (
            <StarterButtons onSelect={sendMessage} />
          )}

          {/* Input */}
          <MessageInput
            onSend={sendMessage}
            onUpload={uploadFile}
            onOpenSettings={() => setShowSettings(true)}
            disabled={!sessionId || isThinking}
          />
        </div>

        {/* Stats sidebar */}
        {stats && <StatsPanel stats={stats} sessionId={sessionId} />}
      </div>

      {/* Settings modal */}
      {showSettings && (
        <SettingsPanel
          currentModel={currentModel}
          onClose={() => setShowSettings(false)}
          onModelChange={updateModel}
        />
      )}
    </div>
  )
}
