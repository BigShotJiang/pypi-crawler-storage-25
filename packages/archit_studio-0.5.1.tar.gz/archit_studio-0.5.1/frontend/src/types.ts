export type MessageRole = 'user' | 'assistant' | 'system' | 'bim'

export interface ChatMessage {
  id: string
  role: MessageRole
  author: string
  content: string
  timestamp: Date
}

export interface SvgMessage {
  id: string
  type: 'svg'
  levelIndex: number
  levelName: string
  roomCount: number
  area: number
  svg: string
  timestamp: Date
}

export interface PhaseGateMessage {
  id: string
  type: 'phase_complete'
  phase: string
  phaseLabel: string
  nextPhase: string
  nextPhaseLabel: string
  timestamp: Date
}

export interface StatsData {
  projectName: string
  totalLevels: number
  totalRooms: number
  grossFloorArea: number
  areaByProgram: Record<string, number>
  model: string
}

export type AnyMessage = ChatMessage | SvgMessage | PhaseGateMessage

export interface Model {
  id: string
  label: string
}

export type ServerEvent =
  | { type: 'thinking'; status: string }
  | { type: 'message'; author: string; content: string }
  | { type: 'svg'; level_index: number; level_name: string; room_count: number; area: number; svg: string }
  | { type: 'svg_error'; level_index: number; error: string }
  | { type: 'stats'; project_name: string; total_levels: number; total_rooms: number; gross_floor_area: number; area_by_program: Record<string, number>; model: string }
  | { type: 'error'; message: string }
  | { type: 'phase_complete'; phase: string; phase_label: string; next_phase: string; next_phase_label: string }

export interface StarterPrompt {
  label: string
  message: string
  icon: string
}

export const STARTERS: StarterPrompt[] = [
  {
    label: 'Design a 3-bedroom house',
    message: 'I need a 3-bedroom, 2-bathroom single-storey house. The total area should be around 120m². Please start designing the floor plan.',
    icon: '🏠',
  },
  {
    label: 'Start an office layout',
    message: 'Design an open-plan office layout for 20 people with a small meeting room, reception area, and two private offices. Target 200m².',
    icon: '🏢',
  },
  {
    label: 'Check compliance',
    message: 'Please run a full compliance and accessibility check on the current design.',
    icon: '✅',
  },
  {
    label: 'Export floorplans',
    message: 'Please export the current design as SVG floorplans and save the session.',
    icon: '📐',
  },
]
