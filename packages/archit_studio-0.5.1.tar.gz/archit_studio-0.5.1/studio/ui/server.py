"""
studio.ui.server — FastAPI backend replacing the Chainlit UI.

Endpoints:
  POST /api/session                 — create session, returns session_id + welcome message
  WS   /ws/{session_id}            — real-time bidirectional chat
  POST /api/upload/{session_id}    — upload building JSON or GeoJSON
  PUT  /api/settings/{session_id}  — update active LLM model
  GET  /api/models                 — list supported models

  Serves the React SPA from frontend/dist/ when built.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from pathlib import Path

log = logging.getLogger(__name__)

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from studio.agents.runner import run_phase as _run_phase_agents
from studio.config import SUPPORTED_MODELS, MODEL_LABELS, DEFAULT_MODEL, settings, get_data_dir
from studio.state.session import (
    SessionState, set_session, get_session,
    DesignPhase, PHASE_LABELS, next_design_phase,
)

app = FastAPI(title="Archit Studio API", version="0.4.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------------------------------------------------------------------
# Session creation
# ---------------------------------------------------------------------------

@app.post("/api/session")
async def create_session():
    """Create a new design session. Returns session_id and the welcome message."""
    session_id = str(uuid.uuid4())
    state = SessionState(session_id=session_id)
    set_session(session_id, state)
    return {
        "session_id": session_id,
        "welcome": _welcome_message(),
    }


# ---------------------------------------------------------------------------
# WebSocket — real-time chat
# ---------------------------------------------------------------------------

@app.websocket("/ws/{session_id}")
async def websocket_endpoint(websocket: WebSocket, session_id: str):
    await websocket.accept()

    state = get_session(session_id)
    if state is None:
        await websocket.send_json({"type": "error", "message": "Session not found. Please reload."})
        await websocket.close()
        return

    try:
        while True:
            data = await websocket.receive_json()
            msg_type = data.get("type")

            # ── Phase approval (user clicked "Continue →") ─────────────────
            if msg_type == "phase_approve":
                if not state.awaiting_approval:
                    continue
                state.awaiting_approval = False
                next_ph = next_design_phase(state.phase)
                if next_ph is None:
                    continue
                state.phase = next_ph
                await _run_phase(websocket, state, session_id, state.original_request)
                continue

            if msg_type != "message":
                continue

            user_message = data.get("content", "").strip()
            if not user_message:
                continue

            if state.awaiting_approval:
                # User typed feedback instead of approving → redo current phase
                state.awaiting_approval = False
                await _run_phase(websocket, state, session_id, user_message)
            else:
                # Fresh request — reset to the first phase
                state.original_request = user_message
                state.phase = DesignPhase.SITE
                await _run_phase(websocket, state, session_id, user_message)

    except WebSocketDisconnect:
        pass


async def _run_phase(
    websocket: WebSocket,
    state: SessionState,
    session_id: str,
    user_message: str,
) -> None:
    """Run the crew for state.phase, then emit SVG/stats and optionally a phase gate."""
    phase = state.phase
    label = PHASE_LABELS[phase]

    await websocket.send_json({"type": "thinking", "status": f"Working on {label}…"})

    async def _forward_text(author: str, text: str) -> None:
        """Send each agent's output to the UI as it completes."""
        await websocket.send_json({"type": "message", "author": author, "content": text})

    try:
        await _run_phase_agents(phase, session_id, user_message, on_text=_forward_text)
    except Exception as exc:
        log.error("Phase %s error for session %s: %s", phase, session_id, exc, exc_info=True)
        await websocket.send_json({
            "type": "message",
            "author": "Project Manager",
            "content": (
                f"I encountered an error during **{label}**: {exc}\n\n"
                "Please try rephrasing, or check that your API key is set in .env."
            ),
        })

    # Auto-export SVG for any level with content
    for level in state.building.levels:
        if level.rooms or level.walls:
            svg_event = await _build_svg_event(session_id, state, level.index)
            if svg_event:
                await websocket.send_json(svg_event)

    # Building stats
    stats_event = _build_stats_event(state)
    if stats_event:
        await websocket.send_json(stats_event)

    # Phase gate — ask for confirmation before the next phase
    next_ph = next_design_phase(phase)
    if next_ph is not None:
        state.awaiting_approval = True
        await websocket.send_json({
            "type": "phase_complete",
            "phase": phase.value,
            "phase_label": label,
            "next_phase": next_ph.value,
            "next_phase_label": PHASE_LABELS[next_ph],
        })


# ---------------------------------------------------------------------------
# SVG helper
# ---------------------------------------------------------------------------

async def _build_svg_event(session_id: str, state, level_index: int) -> dict | None:
    try:
        from archit_app.io.svg import level_to_svg

        level = state.building.get_level(level_index)
        if level is None or not (level.rooms or level.walls):
            return None

        # Generate SVG in-memory — no disk I/O, no permission issues
        svg_content = await asyncio.to_thread(level_to_svg, level)

        return {
            "type": "svg",
            "level_index": level_index,
            "level_name": level.name or f"Level {level_index}",
            "room_count": len(level.rooms),
            "area": round(sum(r.area for r in level.rooms), 1),
            "svg": svg_content,
        }
    except Exception as exc:
        log.error("SVG export failed for session %s level %d: %s", session_id, level_index, exc, exc_info=True)
        return {
            "type": "svg_error",
            "level_index": level_index,
            "error": str(exc),
        }


# ---------------------------------------------------------------------------
# Stats helper
# ---------------------------------------------------------------------------

def _build_stats_event(state) -> dict | None:
    try:
        if not state.building.levels:
            return None
        stats = state.building.stats()
        return {
            "type": "stats",
            "project_name": state.building.metadata.name or "Untitled",
            "total_levels": stats.total_levels,
            "total_rooms": stats.total_rooms,
            "gross_floor_area": round(stats.gross_floor_area_m2),
            "area_by_program": {k: round(v) for k, v in (stats.area_by_program or {}).items()},
            "model": state.model,
        }
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Downloads
# ---------------------------------------------------------------------------

@app.get("/api/download/{session_id}/building.json")
async def download_building_json(session_id: str):
    """Return the full building model as a downloadable JSON file."""
    from fastapi.responses import Response
    from archit_app.io import building_to_json

    state = get_session(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail="Session not found")

    name = state.building.metadata.name or "building"
    safe_name = "".join(c if c.isalnum() or c in "-_ " else "_" for c in name).strip()
    filename = f"{safe_name}.json"

    json_str = await asyncio.to_thread(building_to_json, state.building)
    return Response(
        content=json_str,
        media_type="application/json",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


# ---------------------------------------------------------------------------
# File upload
# ---------------------------------------------------------------------------

@app.post("/api/upload/{session_id}")
async def upload_file(session_id: str, file: UploadFile = File(...)):
    """Accept a .json building file or .geojson land parcel and import it."""
    state = get_session(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail="Session not found")

    content = await file.read()
    filename = file.filename or ""
    suffix = Path(filename).suffix.lower()

    if suffix == ".json":
        return await _import_building_json(content, filename, state)
    elif suffix == ".geojson":
        return await _import_geojson(content, filename, state)
    else:
        return JSONResponse({
            "ok": False,
            "message": f"File '{filename}' uploaded but not imported — only .json and .geojson are supported.",
            "author": "System",
        })


async def _import_building_json(content: bytes, filename: str, state) -> JSONResponse:
    try:
        from archit_app.io import building_from_json

        json_str = content.decode("utf-8")
        try:
            wrapper = json.loads(json_str)
            if "building" in wrapper:
                json_str = json.dumps(wrapper["building"])
        except Exception:
            pass

        building = building_from_json(json_str)
        state.update(building)
        return JSONResponse({
            "ok": True,
            "author": "BIM Coordinator",
            "message": (
                f"Building project **'{building.metadata.name or filename}'** loaded. "
                f"{len(building.levels)} level(s), {building.stats().total_rooms} room(s)."
            ),
        })
    except Exception as exc:
        return JSONResponse({"ok": False, "author": "System", "message": f"Failed to import '{filename}': {exc}"})


async def _import_geojson(content: bytes, filename: str, state) -> JSONResponse:
    try:
        from archit_app.io.geojson import level_from_geojson_str

        geojson_str = content.decode("utf-8")
        level = level_from_geojson_str(geojson_str)
        new_building = state.building.add_level(level)
        state.update(new_building)
        return JSONResponse({
            "ok": True,
            "author": "BIM Coordinator",
            "message": f"GeoJSON **'{filename}'** imported as Level {level.index}.",
        })
    except Exception as exc:
        return JSONResponse({"ok": False, "author": "System", "message": f"Failed to import '{filename}': {exc}"})


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

class ModelUpdate(BaseModel):
    model: str


@app.put("/api/settings/{session_id}")
async def update_settings(session_id: str, body: ModelUpdate):
    """Change the active LLM model for a session."""
    state = get_session(session_id)
    if state is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if body.model not in SUPPORTED_MODELS:
        raise HTTPException(status_code=400, detail=f"Unsupported model: {body.model}")

    state.model = body.model
    os.environ["STUDIO_MODEL"] = body.model
    return {
        "ok": True,
        "message": f"Model updated to **{MODEL_LABELS.get(body.model, body.model)}**.",
        "model": body.model,
    }


# ---------------------------------------------------------------------------
# Models list
# ---------------------------------------------------------------------------

@app.get("/api/models")
async def list_models():
    """Return all supported models with their human-readable labels."""
    return [{"id": k, "label": MODEL_LABELS.get(k, k)} for k in SUPPORTED_MODELS]


# ---------------------------------------------------------------------------
# React SPA — serve built frontend
# ---------------------------------------------------------------------------

_FRONTEND_DIST = Path(__file__).parent.parent.parent / "frontend" / "dist"

if _FRONTEND_DIST.exists():
    _assets_dir = _FRONTEND_DIST / "assets"
    if _assets_dir.exists():
        app.mount("/assets", StaticFiles(directory=str(_assets_dir)), name="assets")

    @app.get("/{full_path:path}")
    async def serve_spa(full_path: str):
        # Serve any file that actually exists in dist/ (favicon, icons, etc.)
        candidate = _FRONTEND_DIST / full_path
        if candidate.exists() and candidate.is_file():
            return FileResponse(str(candidate))
        # Everything else → SPA entry point
        return FileResponse(str(_FRONTEND_DIST / "index.html"))


# ---------------------------------------------------------------------------
# Welcome message (mirrors original Chainlit copy)
# ---------------------------------------------------------------------------

def _welcome_message() -> str:
    model_id = settings.get("model", DEFAULT_MODEL)
    label = MODEL_LABELS.get(model_id, model_id)
    return (
        "# Welcome to Archit Studio\n\n"
        "I'm your **Project Manager** — your primary point of contact for this design session. "
        "I coordinate a specialist team:\n\n"
        "- **Architect** — spatial layout, rooms, walls, openings\n"
        "- **Structural Engineer** — columns, beams, slabs, circulation\n"
        "- **Compliance Analyst** — zoning, egress, accessibility, daylighting\n"
        "- **Interior Designer** — furniture, materials, finishes\n"
        "- **Space Programmer** — area targets, adjacency requirements\n"
        "- **BIM Coordinator** — model integrity, exports, session management\n\n"
        "**To get started:**\n"
        "- Describe the building you want to design (type, size, number of floors, key spaces)\n"
        "- Upload an existing `.json` building file to continue a previous project\n"
        "- Use the quick starters below for common scenarios\n\n"
        f"*Active model: {label}*"
    )
