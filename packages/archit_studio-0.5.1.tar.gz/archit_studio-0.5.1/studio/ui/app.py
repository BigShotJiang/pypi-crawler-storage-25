"""
studio.ui.app — Entry point for the Archit Studio server.

Run with:
    archit-studio          (CLI script)
    uvicorn studio.ui.server:app --port 8000 --reload  (development)
"""

from __future__ import annotations


def main():
    """Entry point: start the FastAPI/uvicorn server."""
    import uvicorn
    import logging
    logging.basicConfig(level=logging.DEBUG)
    uvicorn.run(
        "studio.ui.server:app",
        host="0.0.0.0",
        port=8000,
        reload=False,
        log_level="debug",
    )


if __name__ == "__main__":
    main()
