"""archit-studio — AI-powered architecture design studio."""

__version__ = "0.4.0"
