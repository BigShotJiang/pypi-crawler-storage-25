"""
studio.state.session — per-session building state.

Each Chainlit browser session gets its own SessionState that holds:
  - the live Building (immutable, from archit-app)
  - a History stack for undo/redo
  - the active model override (settable at runtime from the UI)
  - helpers for JSON persistence to data/sessions/<session_id>.json

The global registry ``_SESSIONS`` maps session_id → SessionState so that
all CrewAI tools in the same session share the same building without passing
it through function arguments.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from archit_app import Building, BuildingMetadata
from archit_app.history import History
from archit_app.io import building_to_json, building_from_json

from studio.config import get_data_dir, max_history, get_default_model


# ---------------------------------------------------------------------------
# Design phases
# ---------------------------------------------------------------------------

class DesignPhase(str, Enum):
    SITE      = "site"
    FLOORPLAN = "floorplan"
    INTERIORS = "interiors"
    FINALISE  = "finalise"


PHASE_LABELS: dict[DesignPhase, str] = {
    DesignPhase.SITE:      "Site & Brief",
    DesignPhase.FLOORPLAN: "Floor Plan",
    DesignPhase.INTERIORS: "Furniture & Finishes",
    DesignPhase.FINALISE:  "Validation & Export",
}

_PHASE_ORDER = [
    DesignPhase.SITE,
    DesignPhase.FLOORPLAN,
    DesignPhase.INTERIORS,
    DesignPhase.FINALISE,
]


def next_design_phase(phase: DesignPhase) -> DesignPhase | None:
    """Return the phase that follows *phase*, or None if it is the last."""
    try:
        idx = _PHASE_ORDER.index(phase)
        return _PHASE_ORDER[idx + 1] if idx + 1 < len(_PHASE_ORDER) else None
    except ValueError:
        return None

# ---------------------------------------------------------------------------
# In-memory registry  (session_id → SessionState)
# ---------------------------------------------------------------------------

_SESSIONS: dict[str, "SessionState"] = {}


def get_session(session_id: str) -> "SessionState | None":
    return _SESSIONS.get(session_id)


def set_session(session_id: str, state: "SessionState") -> None:
    _SESSIONS[session_id] = state


def delete_session(session_id: str) -> None:
    _SESSIONS.pop(session_id, None)


# ---------------------------------------------------------------------------
# SessionState
# ---------------------------------------------------------------------------


class SessionState:
    """Mutable wrapper around an immutable Building + History.

    All CrewAI tools receive the session_id and call ``get_session()`` to
    access this object.  Tools call ``update()`` to push new Building states
    (which automatically pushes to the History stack).
    """

    def __init__(
        self,
        session_id: str,
        *,
        building: Building | None = None,
        model: str | None = None,
    ) -> None:
        self.session_id = session_id
        self.model: str = model or get_default_model()
        self.created_at: datetime = datetime.now(timezone.utc)
        self.last_modified: datetime = self.created_at

        initial = building or Building(
            metadata=BuildingMetadata(name="New Project")
        )
        self._history: History = History.start(initial, max_snapshots=max_history())

        # Phase-gating workflow
        self.phase: DesignPhase = DesignPhase.SITE
        self.awaiting_approval: bool = False
        self.original_request: str = ""   # Saved so later phases get the full brief

    # ------------------------------------------------------------------
    # Building access
    # ------------------------------------------------------------------

    @property
    def building(self) -> Building:
        return self._history.current

    def update(self, new_building: Building, *, label: str = "") -> None:
        """Push a new building state onto the history stack."""
        self._history = self._history.push(new_building)
        self.last_modified = datetime.now(timezone.utc)

    def undo(self) -> Building:
        """Undo the last change.  Returns the restored building.

        Raises ``HistoryError`` if there is nothing to undo.
        """
        _, self._history = self._history.undo()
        self.last_modified = datetime.now(timezone.utc)
        return self.building

    def redo(self) -> Building:
        """Redo a previously undone change.  Returns the new building.

        Raises ``HistoryError`` if there is nothing to redo.
        """
        _, self._history = self._history.redo()
        self.last_modified = datetime.now(timezone.utc)
        return self.building

    @property
    def can_undo(self) -> bool:
        return self._history.can_undo

    @property
    def can_redo(self) -> bool:
        return self._history.can_redo

    @property
    def history_depth(self) -> int:
        return len(self._history.snapshots)

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self) -> Path:
        """Persist the current building to data/sessions/<session_id>.json."""
        data_dir = get_data_dir()
        path = data_dir / f"{self.session_id}.json"
        json_str = building_to_json(self.building)
        # Wrap with session metadata
        wrapper = {
            "session_id": self.session_id,
            "model": self.model,
            "created_at": self.created_at.isoformat(),
            "last_modified": self.last_modified.isoformat(),
            "building": json.loads(json_str),
        }
        path.write_text(json.dumps(wrapper, indent=2), encoding="utf-8")
        return path

    @classmethod
    def load(cls, session_id: str) -> "SessionState":
        """Load a previously saved session from disk.

        Raises FileNotFoundError if the session file does not exist.
        """
        data_dir = get_data_dir()
        path = data_dir / f"{session_id}.json"
        if not path.exists():
            raise FileNotFoundError(f"No saved session found: {path}")

        try:
            wrapper = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ValueError(f"Session file is not valid JSON: {path}") from exc

        if "building" not in wrapper:
            raise ValueError(f"Session file is missing 'building' key: {path}")

        building = building_from_json(json.dumps(wrapper["building"]))
        state = cls(session_id=session_id, building=building, model=wrapper.get("model"))
        if created_at := wrapper.get("created_at"):
            state.created_at = datetime.fromisoformat(created_at)
        if last_modified := wrapper.get("last_modified"):
            state.last_modified = datetime.fromisoformat(last_modified)
        return state

    @classmethod
    def list_saved(cls) -> list[dict[str, Any]]:
        """Return a list of saved session summaries from the data directory."""
        data_dir = get_data_dir()
        sessions = []
        for path in sorted(data_dir.glob("*.json")):
            try:
                wrapper = json.loads(path.read_text(encoding="utf-8"))
                sessions.append({
                    "session_id": wrapper.get("session_id", path.stem),
                    "model": wrapper.get("model", ""),
                    "created_at": wrapper.get("created_at", ""),
                    "last_modified": wrapper.get("last_modified", ""),
                    "building_name": wrapper.get("building", {}).get("metadata", {}).get("name", ""),
                })
            except Exception:
                continue
        return sessions

    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"SessionState(id={self.session_id!r}, "
            f"model={self.model!r}, "
            f"building={self.building!r})"
        )
