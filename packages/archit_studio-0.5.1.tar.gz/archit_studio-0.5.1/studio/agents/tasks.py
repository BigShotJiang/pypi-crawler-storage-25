"""
Task factory — generates CrewAI Task objects dynamically from user requests.

CrewAI hierarchical process does not require pre-defined tasks; the manager
(PM) decomposes the user request at runtime. However, we define structured
task templates here for common design workflows that the PM can reference.
"""

from __future__ import annotations

from crewai import Task


def make_design_task(
    user_request: str,
    session_id: str,
    agent,
    context_tasks: list[Task] | None = None,
) -> Task:
    """Create a generic design task from a user request string."""
    return Task(
        description=(
            f"SESSION ID: {session_id}\n\n"
            f"User request:\n{user_request}\n\n"
            "══════════════════════════════════════════════════════\n"
            "MANDATORY EXECUTION RULES — READ BEFORE DOING ANYTHING\n"
            "══════════════════════════════════════════════════════\n"
            f"1. Pass session_id=\"{session_id}\" to EVERY single tool call, without exception.\n"
            "2. You MUST actually call the building tools. Do NOT describe a design in text only.\n"
            "3. Delegate to specialists who will call the tools — they must also use this session_id.\n\n"
            "REQUIRED WORKFLOW FOR NEW DESIGNS:\n"
            f"  a) get_building_context(session_id=\"{session_id}\") — check current state\n"
            f"  b) Delegate to Architect: call add_level(session_id=\"{session_id}\", ...) "
            "for each floor, then add_room(...) for each space\n"
            f"  c) Delegate to BIM Coordinator: call export_level_svg(session_id=\"{session_id}\", "
            "level_index=...) for each level, then save_session(...)\n"
            f"  d) Call get_building_context(session_id=\"{session_id}\") again to confirm the "
            "state was saved\n\n"
            "ROOM SIZING MINIMUMS: bedroom ≥ 9m², master bedroom ≥ 14m², bathroom ≥ 4m², "
            "kitchen ≥ 8m², living ≥ 18m², corridor width ≥ 1.2m.\n"
            "══════════════════════════════════════════════════════"
        ),
        expected_output=(
            "A professional summary that MUST include: "
            "(1) list of levels created (index, elevation, name), "
            "(2) list of rooms added (name, program, area in m²), "
            "(3) confirmation that export_level_svg and save_session were called, "
            "(4) final building stats from get_building_context (total levels, rooms, gross area), "
            "(5) key design rationale and recommended next steps."
        ),
        agent=agent,
        context=context_tasks or [],
    )


def make_programme_task(
    spaces: list[dict],
    session_id: str,
    agent,
) -> Task:
    """Task for verifying design compliance with a space programme."""
    spaces_str = "\n".join(
        f"  - {s.get('name','?')}: {s.get('program','?')}, target {s.get('area_m2','?')}m²"
        for s in spaces
    )
    return Task(
        description=(
            f"Session ID: {session_id}\n\n"
            f"Verify that the current building design satisfies the following space programme:\n"
            f"{spaces_str}\n\n"
            "Run get_building_detailed_context and run_area_report. For each programme item:\n"
            "- Check if the space exists (by name or program type)\n"
            "- Check if its area meets the target\n"
            "- Check adjacency requirements if specified\n"
            "Report on compliance, missing spaces, under/over-sized rooms."
        ),
        expected_output=(
            "Programme compliance report: list each required space with actual vs. target area, "
            "pass/fail status, and a list of required modifications."
        ),
        agent=agent,
    )


def make_compliance_task(session_id: str, agent) -> Task:
    """Task for running a full compliance check."""
    return Task(
        description=(
            f"Session ID: {session_id}\n\n"
            "Run a comprehensive compliance check on the current building design:\n"
            "1. run_compliance_check — zoning, FAR, height, setbacks\n"
            "2. run_accessibility_check on each level\n"
            "3. run_egress_report on each level\n"
            "4. run_daylight_report on each level\n"
            "Summarise all findings, flag non-compliances, and propose specific remediation."
        ),
        expected_output=(
            "Full compliance report with overall pass/fail, itemised findings for each check "
            "category, and specific design changes required to achieve compliance."
        ),
        agent=agent,
    )


def make_export_task(session_id: str, agent, level_indices: list[int] | None = None) -> Task:
    """Task for exporting the building to SVG and saving the session."""
    levels_str = str(level_indices) if level_indices else "all levels"
    return Task(
        description=(
            f"Session ID: {session_id}\n\n"
            f"Produce deliverables for the current design milestone:\n"
            f"1. validate_building — ensure model integrity\n"
            f"2. export_level_svg for {levels_str}\n"
            f"3. export_building_json — full project JSON\n"
            f"4. save_session — persist the session\n"
            "Report the paths of all exported files."
        ),
        expected_output=(
            "List of exported file paths with a brief description of each deliverable, "
            "plus any validation warnings that should be addressed."
        ),
        agent=agent,
    )
