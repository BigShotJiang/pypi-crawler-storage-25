"""
Tool schemas (OpenAI function-calling format) and callable registry for the
custom agent runner.

TOOL_REGISTRY maps tool-name → raw Python callable (bypassing CrewAI).
ALL_SCHEMAS maps tool-name → OpenAI-format tool dict.

Grouped tool lists let each agent phase receive only the tools it needs.
"""

from __future__ import annotations

from typing import Callable


# ---------------------------------------------------------------------------
# Unwrap CrewAI-decorated tools to their raw callables
# ---------------------------------------------------------------------------

def _fn(crewai_tool) -> Callable:
    """Return the underlying Python function from a CrewAI @tool object."""
    return getattr(crewai_tool, "func", crewai_tool)


def _make_grid_wrapper(raw_fn: Callable) -> Callable:
    """Wrap set_structural_grid to accept plain lists and auto-generate labels."""
    import json as _json

    def _wrapper(
        session_id: str,
        x_spacing=None,
        y_spacing=None,
        x_labels=None,
        y_labels=None,
    ) -> str:
        def _to_list(v, default):
            if v is None:
                return default
            if isinstance(v, list):
                return v
            return _json.loads(v)

        xs = _to_list(x_spacing, [0, 5, 10])
        ys = _to_list(y_spacing, [0, 5, 10])
        xl = _to_list(x_labels, None)
        yl = _to_list(y_labels, None)

        # Auto-generate labels that always match the position count
        if xl is None or len(xl) != len(xs):
            xl = [chr(65 + i) for i in range(len(xs))]   # A, B, C, …
        if yl is None or len(yl) != len(ys):
            yl = [str(i + 1) for i in range(len(ys))]    # 1, 2, 3, …

        return raw_fn(
            session_id=session_id,
            x_spacing=_json.dumps(xs),
            y_spacing=_json.dumps(ys),
            x_labels=_json.dumps(xl),
            y_labels=_json.dumps(yl),
        )

    return _wrapper


def _make_annotation_wrapper(raw_fn: Callable) -> Callable:
    """Wrap add_text_annotation to accept an 'anchor' dict in place of x/y."""
    def _wrapper(session_id: str, level_index: int, text: str,
                 x: float = None, y: float = None,
                 anchor=None, font_size: float = 0.3, rotation_deg: float = 0.0) -> str:
        # Model sometimes passes anchor={"x": ..., "y": ...} instead of x/y directly
        if anchor is not None and isinstance(anchor, dict):
            x = float(anchor.get("x", x or 0))
            y = float(anchor.get("y", y or 0))
        return raw_fn(session_id=session_id, level_index=level_index, text=text,
                      x=x or 0.0, y=y or 0.0,
                      font_size=font_size, rotation_deg=rotation_deg)
    return _wrapper


def _make_egress_wrapper(raw_fn: Callable) -> Callable:
    """Wrap run_egress_report to drop spurious kwargs (e.g. exit_ids) the model sometimes passes."""
    def _wrapper(session_id: str, level_index: int = 0, **_ignored) -> str:
        return raw_fn(session_id=session_id, level_index=level_index)
    return _wrapper


def _make_slab_wrapper(raw_fn: Callable) -> Callable:
    """Wrap add_slab to fix slab_type mismatches (e.g. 'basement_floor' on level 0)."""
    def _wrapper(session_id: str, level_index: int, boundary_points: str,
                 thickness_m: float = 0.2, slab_type: str = "floor") -> str:
        # Normalise: 'basement_floor' only makes sense for level_index < 0
        if slab_type == "basement_floor" and level_index >= 0:
            slab_type = "floor"
        return raw_fn(session_id=session_id, level_index=level_index,
                      boundary_points=boundary_points,
                      thickness_m=thickness_m, slab_type=slab_type)
    return _wrapper


def _import_registry() -> dict[str, Callable]:
    from studio.agents.tools import building_tools as bt
    from studio.agents.tools import structural_tools as st
    from studio.agents.tools import analysis_tools as at
    from studio.agents.tools import interior_tools as it
    from studio.agents.tools import io_tools as iot

    return {
        # ── Context ──────────────────────────────────────────────────────────
        "get_building_context":           _fn(bt.get_building_context),
        "get_building_detailed_context":  _fn(bt.get_building_detailed_context),
        # ── Building elements ─────────────────────────────────────────────────
        "add_level":                      _fn(bt.add_level),
        "add_room":                       _fn(bt.add_room),
        "add_rooms_batch":                _fn(bt.add_rooms_batch),
        "add_wall":                       _fn(bt.add_wall),
        "add_walls_batch":                _fn(bt.add_walls_batch),
        "add_opening_to_wall":            _fn(bt.add_opening_to_wall),
        "add_staircase":                  _fn(bt.add_staircase),
        "remove_element":                 _fn(bt.remove_element),
        "update_building_metadata":       _fn(bt.update_building_metadata),
        "undo_last_change":               _fn(bt.undo_last_change),
        "redo_last_change":               _fn(bt.redo_last_change),
        # ── Element transforms ────────────────────────────────────────────────
        "copy_element_to":                _fn(bt.copy_element_to),
        "mirror_element_tool":            _fn(bt.mirror_element_tool),
        "array_element_tool":             _fn(bt.array_element_tool),
        # ── Structural ────────────────────────────────────────────────────────
        "add_column":                     _fn(st.add_column),
        "add_beam":                       _fn(st.add_beam),
        "add_slab":                       _make_slab_wrapper(_fn(st.add_slab)),
        "add_ramp":                       _fn(st.add_ramp),
        "add_elevator":                   _fn(st.add_elevator),
        "set_structural_grid":            _make_grid_wrapper(_fn(st.set_structural_grid)),
        # ── Analysis ──────────────────────────────────────────────────────────
        "set_land":                       _fn(at.set_land),
        "run_compliance_check":           _fn(at.run_compliance_check),
        "run_area_report":                _fn(at.run_area_report),
        "run_egress_report":              _fn(at.run_egress_report),
        "run_accessibility_check":        _fn(at.run_accessibility_check),
        "run_daylight_report":            _fn(at.run_daylight_report),
        "run_visibility_check":           _fn(at.run_visibility_check),
        "run_adjacency_analysis":         _fn(at.run_adjacency_analysis),
        "get_walls_for_room":             _fn(at.get_walls_for_room),
        # ── Interior ──────────────────────────────────────────────────────────
        "add_furniture":                  _fn(it.add_furniture),
        "add_text_annotation":            _make_annotation_wrapper(_fn(it.add_text_annotation)),
        "set_room_material":              _fn(it.set_room_material),
        # ── I/O ───────────────────────────────────────────────────────────────
        "export_level_svg":               _fn(iot.export_level_svg),
        "export_building_json":           _fn(iot.export_building_json),
        "export_building_pdf":            _fn(iot.export_building_pdf),
        "export_level_geojson":           _fn(iot.export_level_geojson),
        "validate_building":              _fn(iot.validate_building),
        "save_session":                   _fn(iot.save_session),
    }


# Lazy singleton — populated on first access to avoid import-time side effects
_registry: dict[str, Callable] | None = None


def get_registry() -> dict[str, Callable]:
    global _registry
    if _registry is None:
        _registry = _import_registry()
    return _registry


# ---------------------------------------------------------------------------
# Schema helpers
# ---------------------------------------------------------------------------

def _schema(
    name: str,
    description: str,
    properties: dict,
    required: list[str],
) -> dict:
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
                "required": required,
            },
        },
    }


_SID   = {"type": "string", "description": "Active session identifier."}
_LEVEL = {"type": "integer", "description": "Floor level index (0=ground, negative=basement, positive=upper)."}


# ---------------------------------------------------------------------------
# All tool schemas
# ---------------------------------------------------------------------------

_SCHEMAS_LIST: list[dict] = [
    # ── Context ────────────────────────────────────────────────────────────
    _schema("get_building_context",
        "Return a compact summary of the current building state. "
        "Call this first before any design decisions.",
        {"session_id": _SID}, ["session_id"]),

    _schema("get_building_detailed_context",
        "Return detailed spatial data: per-room centroids, bounding boxes "
        "(x_min, y_min, x_max, y_max), and full wall geometry including "
        "start/end points and facing direction (N/S/E/W). "
        "Pass level_index to scope to one floor and reduce token usage. "
        "Pass include_furniture=false or include_columns=false to further narrow.",
        {"session_id": _SID,
         "level_index":       {"type": "integer",
                               "description": "Scope to this floor only (omit for all floors)."},
         "include_walls":     {"type": "boolean",
                               "description": "Include wall geometry (default true)."},
         "include_furniture": {"type": "boolean",
                               "description": "Include furniture entries (default true)."},
         "include_columns":   {"type": "boolean",
                               "description": "Include column entries (default true)."}},
        ["session_id"]),

    # ── Levels ─────────────────────────────────────────────────────────────
    _schema("add_level",
        "Add a new floor level before adding any rooms or walls to it.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "elevation_m":    {"type": "number", "description": "Height above site datum in metres."},
         "floor_height_m": {"type": "number", "description": "Floor-to-ceiling height in metres (2.7–4.0)."},
         "name":           {"type": "string",  "description": "Human label e.g. 'Ground Floor'."}},
        ["session_id", "level_index", "elevation_m", "floor_height_m"]),

    # ── Rooms ──────────────────────────────────────────────────────────────
    _schema("add_rooms_batch",
        "Add multiple rooms to a level in a single call — preferred over "
        "calling add_room N times. Use for entire floor plan layouts to reduce "
        "round-trips. rooms_json is a JSON array of room objects.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "rooms_json": {"type": "string", "description":
             'JSON array of room objects. Each: {"name":"...", "program":"...", '
             '"boundary_points":[[x,y],...]}. Min 3 points per room. '
             'Example: [{"name":"Living","program":"living","boundary_points":[[0,0],[5,0],[5,4],[0,4]]}]'}},
        ["session_id", "level_index", "rooms_json"]),

    _schema("add_room",
        "Add a room polygon to a level. boundary_points is a JSON array of "
        "[x, y] pairs in metres. Rooms must TILE together — shared edges, no gaps.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "name":             {"type": "string", "description": "Room name e.g. 'Master Bedroom'."},
         "program":          {"type": "string", "description":
             "Space type: bedroom, living, kitchen, bathroom, corridor, dining, "
             "study, garage, utility, storage, lobby, terrace, office."},
         "boundary_points":  {"type": "string", "description":
             'JSON array of [x,y] pairs. Min 3. Example: "[[0,0],[4,0],[4,5],[0,5]]"'}},
        ["session_id", "level_index", "name", "program", "boundary_points"]),

    # ── Walls ──────────────────────────────────────────────────────────────
    _schema("add_walls_batch",
        "Add multiple walls to a level in a single call — preferred over "
        "calling add_wall N times. Use for full perimeter placement. "
        "walls_json is a JSON array of wall objects.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "walls_json": {"type": "string", "description":
             'JSON array of wall objects. Each: {"x1":n,"y1":n,"x2":n,"y2":n, '
             '"wall_type":"exterior","thickness_m":0.2,"height_m":3.0}. '
             'Example: [{"x1":0,"y1":0,"x2":10,"y2":0,"wall_type":"exterior"}]'}},
        ["session_id", "level_index", "walls_json"]),

    _schema("add_wall",
        "Add a straight wall between two points.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "x1": {"type": "number"}, "y1": {"type": "number"},
         "x2": {"type": "number"}, "y2": {"type": "number"},
         "thickness_m": {"type": "number", "description": "Wall thickness in metres (default 0.2)."},
         "height_m":    {"type": "number", "description": "Wall height in metres (default 3.0)."},
         "wall_type":   {"type": "string",  "enum": ["exterior", "interior", "partition", "curtain", "retaining"]}},
        ["session_id", "level_index", "x1", "y1", "x2", "y2"]),

    # ── Openings ───────────────────────────────────────────────────────────
    _schema("add_opening_to_wall",
        "Add a door or window to an existing wall.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "wall_id":              {"type": "string", "description": "UUID of the wall from get_building_detailed_context."},
         "kind":                 {"type": "string", "enum": ["door", "window", "sliding_door", "garage_door", "skylight"]},
         "width_m":              {"type": "number", "description": "Opening width (doors 0.8–1.2, windows 0.6–2.4)."},
         "height_m":             {"type": "number", "description": "Opening height (doors 2.0–2.4, windows 0.6–1.8)."},
         "sill_height_m":        {"type": "number", "description": "Height from floor to opening bottom (0 for doors)."},
         "position_along_wall":  {"type": "number", "description": "Fractional position along wall length (0.0–1.0)."}},
        ["session_id", "level_index", "wall_id"]),

    # ── Staircase ──────────────────────────────────────────────────────────
    _schema("add_staircase",
        "Add a staircase connecting floor levels.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "x": {"type": "number"}, "y": {"type": "number"},
         "width_m":            {"type": "number", "description": "Stair width (min 1.0, recommended 1.2+)."},
         "length_m":           {"type": "number", "description": "Stair run length in metres."},
         "staircase_type":     {"type": "string", "enum": ["straight", "l_shaped", "spiral"]},
         "bottom_level_index": {"type": "integer"},
         "top_level_index":    {"type": "integer"}},
        ["session_id", "level_index", "x", "y"]),

    # ── Remove / Undo ──────────────────────────────────────────────────────
    _schema("remove_element",
        "Remove any element (room, wall, column, etc.) by its UUID.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "element_id": {"type": "string", "description": "UUID of the element to remove."}},
        ["session_id", "level_index", "element_id"]),

    _schema("update_building_metadata",
        "Set the project name, number, architect, client, and date.",
        {"session_id": _SID,
         "name": {"type": "string"}, "project_number": {"type": "string"},
         "architect": {"type": "string"}, "client": {"type": "string"}, "date": {"type": "string"}},
        ["session_id"]),

    _schema("undo_last_change", "Undo the most recent change to the building.",
        {"session_id": _SID}, ["session_id"]),

    _schema("redo_last_change", "Redo a previously undone change.",
        {"session_id": _SID}, ["session_id"]),

    # ── Element transforms ─────────────────────────────────────────────────
    _schema("copy_element_to",
        "Copy any element (room, wall, column, furniture, etc.) to a new position "
        "offset by (dx_m, dy_m) meters. The original is preserved. Use to duplicate "
        "furniture, repeat structural bays, or copy rooms.",
        {"session_id": _SID, "level_index": _LEVEL,
         "element_id": {"type": "string", "description": "UUID of the element to copy."},
         "dx_m": {"type": "number", "description": "X displacement in meters."},
         "dy_m": {"type": "number", "description": "Y displacement in meters."}},
        ["session_id", "level_index", "element_id"]),

    _schema("mirror_element_tool",
        "Create a mirrored copy of an element across a vertical (axis_x) or "
        "horizontal (axis_y) axis. Provide exactly one of axis_x or axis_y. "
        "The original is preserved. Use for symmetric layouts and wing mirroring.",
        {"session_id": _SID, "level_index": _LEVEL,
         "element_id": {"type": "string", "description": "UUID of the element to mirror."},
         "axis_x": {"type": "number", "description": "X-coordinate of vertical mirror axis (x = axis_x)."},
         "axis_y": {"type": "number", "description": "Y-coordinate of horizontal mirror axis (y = axis_y)."}},
        ["session_id", "level_index", "element_id"]),

    _schema("array_element_tool",
        "Create a linear array of copies of an element with a repeating step offset. "
        "count=4 with dx_m=3 creates 3 new copies at +3m, +6m, +9m from the source. "
        "Use for column grids, furniture rows, or repeating structural bays.",
        {"session_id": _SID, "level_index": _LEVEL,
         "element_id": {"type": "string", "description": "UUID of the element to array."},
         "count":  {"type": "integer", "description": "Total copies to create (min 2)."},
         "dx_m":   {"type": "number",  "description": "X step per copy in meters."},
         "dy_m":   {"type": "number",  "description": "Y step per copy in meters."}},
        ["session_id", "level_index", "element_id", "count"]),

    # ── Structural ─────────────────────────────────────────────────────────
    _schema("add_column",
        "Add a structural column.",
        {"session_id": _SID, "level_index": _LEVEL,
         "x": {"type": "number"}, "y": {"type": "number"},
         "width_m": {"type": "number"}, "depth_m": {"type": "number"}, "height_m": {"type": "number"},
         "shape": {"type": "string", "enum": ["rectangular", "circular"]}},
        ["session_id", "level_index", "x", "y"]),

    _schema("add_beam",
        "Add a structural beam between two points.",
        {"session_id": _SID, "level_index": _LEVEL,
         "x1": {"type": "number"}, "y1": {"type": "number"},
         "x2": {"type": "number"}, "y2": {"type": "number"},
         "width_m": {"type": "number"}, "depth_m": {"type": "number"},
         "section": {"type": "string", "enum": ["rectangular", "i_beam", "t_beam", "circular"]}},
        ["session_id", "level_index", "x1", "y1", "x2", "y2"]),

    _schema("add_slab",
        "Add a structural floor or roof slab.",
        {"session_id": _SID, "level_index": _LEVEL,
         "boundary_points": {"type": "string", "description": "JSON array of [x,y] pairs."},
         "thickness_m": {"type": "number"},
         "slab_type": {"type": "string", "enum": ["floor", "roof", "basement_floor", "podium"]}},
        ["session_id", "level_index", "boundary_points"]),

    _schema("add_ramp",
        "Add an accessible or service ramp.",
        {"session_id": _SID, "level_index": _LEVEL,
         "x": {"type": "number"}, "y": {"type": "number"},
         "width_m": {"type": "number"}, "length_m": {"type": "number"},
         "slope_angle_deg": {"type": "number"},
         "ramp_type": {"type": "string", "enum": ["accessible", "service", "parking"]}},
        ["session_id", "level_index", "x", "y"]),

    _schema("add_elevator",
        "Add a building elevator serving multiple levels.",
        {"session_id": _SID,
         "x": {"type": "number"}, "y": {"type": "number"},
         "cab_width_m": {"type": "number"}, "cab_depth_m": {"type": "number"},
         "served_level_indices": {"type": "string", "description": "JSON array of level indices e.g. '[0,1,2]'."}},
        ["session_id", "x", "y"]),

    _schema("set_structural_grid",
        "Define the building's structural column grid. "
        "Labels are optional — they are auto-generated if omitted.",
        {"session_id": _SID,
         "x_spacing": {"type": "array", "items": {"type": "number"},
                       "description": "X-axis grid positions in metres e.g. [0, 5, 10]."},
         "y_spacing": {"type": "array", "items": {"type": "number"},
                       "description": "Y-axis grid positions in metres e.g. [0, 5, 10]."},
         "x_labels":  {"type": "array", "items": {"type": "string"},
                       "description": "Optional X-axis labels e.g. [\"A\",\"B\",\"C\"]. Auto-generated if omitted."},
         "y_labels":  {"type": "array", "items": {"type": "string"},
                       "description": "Optional Y-axis labels e.g. [\"1\",\"2\",\"3\"]. Auto-generated if omitted."}},
        ["session_id", "x_spacing", "y_spacing"]),

    # ── Analysis ───────────────────────────────────────────────────────────
    _schema("set_land",
        "Define the site boundary and zoning parameters.",
        {"session_id": _SID,
         "boundary_points":    {"type": "string", "description": "JSON array of [x,y] pairs (leave empty if unknown)."},
         "address":            {"type": "string"},
         "zone_code":          {"type": "string"},
         "max_height_m":       {"type": "number"},
         "max_far":            {"type": "number"},
         "max_lot_coverage":   {"type": "number"},
         "setback_front_m":    {"type": "number"}, "setback_back_m":  {"type": "number"},
         "setback_left_m":     {"type": "number"}, "setback_right_m": {"type": "number"}},
        ["session_id"]),

    _schema("run_compliance_check",
        "Check zoning compliance: FAR, lot coverage, height, setbacks.",
        {"session_id": _SID}, ["session_id"]),

    _schema("run_area_report",
        "Generate space program area report: net/gross areas by program type.",
        {"session_id": _SID,
         "level_index": {"type": "integer", "description": "Specific level, or omit for all levels."}},
        ["session_id"]),

    _schema("run_egress_report",
        "Analyse egress paths and emergency exit compliance.",
        {"session_id": _SID, "level_index": _LEVEL},
        ["session_id", "level_index"]),

    _schema("run_accessibility_check",
        "Check accessibility: door widths, corridor widths, ramps, turning radius.",
        {"session_id": _SID, "level_index": _LEVEL},
        ["session_id", "level_index"]),

    _schema("run_daylight_report",
        "Analyse natural daylighting for each room: window-to-floor ratio, solar "
        "orientation (N/S/E/W facade), and which rooms are under-daylit (<10% WFR). "
        "Use to verify bedroom and living room light requirements.",
        {"session_id": _SID,
         "level_index":    _LEVEL,
         "north_angle_deg": {"type": "number",
                             "description": "Degrees clockwise from +Y to geographic north. "
                                            "Uses land.north_angle if land is set."}},
        ["session_id", "level_index"]),

    _schema("run_visibility_check",
        "Compute the visibility polygon (isovist) from a point on a level. "
        "Returns the visible area in m² and which room the viewpoint is inside. "
        "Use to verify sightlines, check privacy between spaces, or assess "
        "open-plan visibility.",
        {"session_id": _SID,
         "level_index":  _LEVEL,
         "viewpoint_x":  {"type": "number", "description": "Observer X coordinate in meters."},
         "viewpoint_y":  {"type": "number", "description": "Observer Y coordinate in meters."},
         "max_range_m":  {"type": "number", "description": "Maximum sightline distance in meters (default 30)."},
         "resolution":   {"type": "integer", "description": "Ray count — 180 is fast and sufficient."}},
        ["session_id", "level_index", "viewpoint_x", "viewpoint_y"]),

    _schema("run_adjacency_analysis",
        "Determine which rooms are adjacent (share a wall/boundary).",
        {"session_id": _SID, "level_index": _LEVEL},
        ["session_id", "level_index"]),

    _schema("get_walls_for_room",
        "Return all walls that border a specific room, including their start/end "
        "points and facing direction. Use this before add_opening_to_wall to find "
        "the correct wall_id without manual coordinate lookup.",
        {"session_id": _SID,
         "level_index": _LEVEL,
         "room_id":     {"type": "string", "description": "UUID of the room from get_building_detailed_context."},
         "tolerance_m": {"type": "number",  "description": "Proximity threshold in metres (default 0.35)."}},
        ["session_id", "level_index", "room_id"]),

    # ── Interior ───────────────────────────────────────────────────────────
    _schema("add_furniture",
        "Place a furniture item. Position (x, y) is the CENTRE of the item in metres. "
        "The piece MUST be inside the room bounding box. "
        "Keep ≥150 mm from walls and ≥750 mm between pieces.",
        {"session_id": _SID, "level_index": _LEVEL,
         "furniture_type": {"type": "string", "description":
             "One of: sofa, armchair, dining_table, desk, double_bed, single_bed, "
             "bunk_bed, wardrobe, bookshelf, tv_unit, coffee_table, kitchen_island, "
             "toilet, sink, bathtub, shower, washing_machine, refrigerator"},
         "x":            {"type": "number", "description": "Centre x in metres."},
         "y":            {"type": "number", "description": "Centre y in metres."},
         "rotation_deg": {"type": "number", "description": "Clockwise rotation in degrees."},
         "width_m":      {"type": "number"}, "depth_m": {"type": "number"},
         "name":         {"type": "string"}},
        ["session_id", "level_index", "furniture_type", "x", "y"]),

    _schema("add_text_annotation",
        "Add a text label to the floor plan.",
        {"session_id": _SID, "level_index": _LEVEL,
         "text": {"type": "string"}, "x": {"type": "number"}, "y": {"type": "number"},
         "font_size": {"type": "number"}, "rotation_deg": {"type": "number"}},
        ["session_id", "level_index", "text", "x", "y"]),

    _schema("set_room_material",
        "Assign a material finish to a room.",
        {"session_id": _SID, "level_index": _LEVEL,
         "room_id":           {"type": "string", "description": "UUID of the room from get_building_detailed_context."},
         "material_name":     {"type": "string", "description": "e.g. 'Oak Parquet', 'Ceramic Tile', 'Polished Concrete'."},
         "material_category": {"type": "string", "enum": ["finish", "structure", "insulation", "cladding", "glazing"]},
         "color_hex":         {"type": "string", "description": "Hex colour e.g. '#D4A96A'."}},
        ["session_id", "level_index", "room_id", "material_name"]),

    # ── I/O ────────────────────────────────────────────────────────────────
    _schema("export_level_svg",
        "Export a floor level as an SVG drawing file.",
        {"session_id": _SID, "level_index": _LEVEL},
        ["session_id", "level_index"]),

    _schema("export_building_json",
        "Export the full building as a JSON file.",
        {"session_id": _SID}, ["session_id"]),

    _schema("export_building_pdf",
        "Export all floor levels as a multi-page PDF presentation drawing. "
        "Produces vector-quality output for client review and printing. "
        "Requires pip install archit-app[pdf].",
        {"session_id": _SID,
         "paper_size":  {"type": "string", "enum": ["A4", "A3", "A2"],
                         "description": "Page size (default A3)."},
         "level_index": {"type": "integer",
                         "description": "Export a single floor, or omit for all floors."}},
        ["session_id"]),

    _schema("export_level_geojson",
        "Export a floor level as a GeoJSON FeatureCollection for GIS tools. "
        "Rooms, walls, columns, and openings become GeoJSON features with "
        "element type and program as properties.",
        {"session_id": _SID, "level_index": _LEVEL},
        ["session_id", "level_index"]),

    _schema("validate_building",
        "Validate the building model for errors and inconsistencies.",
        {"session_id": _SID}, ["session_id"]),

    _schema("save_session",
        "Persist the session to disk.",
        {"session_id": _SID}, ["session_id"]),
]

ALL_SCHEMAS: dict[str, dict] = {s["function"]["name"]: s for s in _SCHEMAS_LIST}


def schemas_for(tool_names: list[str]) -> list[dict]:
    """Return the tool schema dicts for the given tool names."""
    return [ALL_SCHEMAS[n] for n in tool_names if n in ALL_SCHEMAS]


# ---------------------------------------------------------------------------
# Canonical tool sets per agent role
# ---------------------------------------------------------------------------

CONTEXT_TOOLS = ["get_building_context", "get_building_detailed_context"]

ARCHITECT_TOOLS = CONTEXT_TOOLS + [
    "add_level",
    "add_room", "add_rooms_batch",       # prefer batch for full layouts
    "add_wall", "add_walls_batch",       # prefer batch for perimeters
    "add_opening_to_wall", "get_walls_for_room",  # find wall → add opening
    "add_staircase", "remove_element", "update_building_metadata",
    "undo_last_change", "redo_last_change",
    # Parametric layout — duplicate, mirror, and array any element
    "copy_element_to", "mirror_element_tool", "array_element_tool",
]

STRUCTURAL_TOOLS = CONTEXT_TOOLS + [
    "add_column", "add_beam", "add_slab", "add_ramp", "add_elevator",
    "set_structural_grid", "remove_element",
    # Repeat structural bays or mirror column grids
    "copy_element_to", "mirror_element_tool", "array_element_tool",
]

COMPLIANCE_TOOLS = CONTEXT_TOOLS + [
    "set_land", "run_compliance_check", "run_egress_report",
    "run_accessibility_check", "run_area_report", "run_adjacency_analysis",
    # Performance analysis
    "run_daylight_report", "run_visibility_check",
    # Spatial query — find walls of a room to verify window placement
    "get_walls_for_room",
]

INTERIOR_TOOLS = CONTEXT_TOOLS + [
    "add_furniture", "add_text_annotation", "set_room_material",
    "remove_element",
    # Duplicate and array furniture arrangements
    "copy_element_to", "array_element_tool",
]

SPACE_TOOLS = CONTEXT_TOOLS + [
    "run_area_report", "run_adjacency_analysis",
]

BIM_TOOLS = CONTEXT_TOOLS + [
    "validate_building", "export_level_svg", "export_building_json",
    "export_building_pdf", "export_level_geojson",
    "save_session",
]
