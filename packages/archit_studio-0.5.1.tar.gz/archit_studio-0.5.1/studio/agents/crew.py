"""
Crew assembly — builds the 6-specialist sequential CrewAI crew.

Process.sequential + planning=True:
  CrewAI's planning LLM analyses the full user request before any agent runs,
  decomposes it into a step-by-step plan, and injects that plan as context into
  every task description.  Specialists then execute in order; each can read the
  previous agent's output via context chaining.

  This avoids the hierarchical-delegation bug in CrewAI ≤ 1.14.x that causes
  "tool_calls must be followed by tool messages" 400 errors from OpenAI.

Tool assignment per agent:
  - All agents: get_building_context, get_building_detailed_context
  - Architect:           building CRUD tools + undo/redo
  - Structural Engineer: structural element tools
  - Compliance Analyst:  analysis tools
  - Interior Designer:   interior tools
  - Space Programmer:    area/adjacency analysis
  - BIM Coordinator:     io tools + validate + undo/redo
"""

from __future__ import annotations

import logging

from crewai import Agent, Crew, LLM, Process, Task

from studio.config import get_model_for_agent, is_verbose
from studio.agents.definitions import AGENT_DEFS
from studio.state.session import DesignPhase

# ── Tools ──────────────────────────────────────────────────────────────────
from studio.agents.tools.building_tools import (
    get_building_context, get_building_detailed_context,
    add_level, add_room, remove_element, add_wall, add_opening_to_wall,
    add_staircase, update_building_metadata, undo_last_change, redo_last_change,
)
from studio.agents.tools.structural_tools import (
    add_column, add_beam, add_slab, add_elevator, set_structural_grid, add_ramp,
)
from studio.agents.tools.analysis_tools import (
    run_compliance_check, run_area_report, run_egress_report,
    run_accessibility_check, run_daylight_report, run_adjacency_analysis, set_land,
)
from studio.agents.tools.interior_tools import (
    add_furniture, add_text_annotation, set_room_material,
)
from studio.agents.tools.io_tools import (
    export_level_svg, export_building_json, validate_building,
    save_session, load_session_tool, list_saved_sessions,
)

log = logging.getLogger(__name__)

# Read-only tools shared by all agents
_SHARED_TOOLS = [get_building_context, get_building_detailed_context]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _llm(agent_name: str) -> LLM:
    """Build a CrewAI LLM object for a named agent."""
    return LLM(model=get_model_for_agent(agent_name))


def _session_goal_prefix(session_id: str) -> str:
    if not session_id:
        return ""
    return (
        f"ACTIVE SESSION ID: {session_id}\n"
        f'You MUST pass session_id="{session_id}" to every tool call you make. '
        "This is the only way changes persist in the building model.\n\n"
    )


def _make_agent(name: str, extra_tools: list, session_id: str = "") -> Agent:
    d = AGENT_DEFS[name]
    goal = _session_goal_prefix(session_id) + d["goal"]
    return Agent(
        role=d["role"],
        goal=goal,
        backstory=d["backstory"],
        tools=_SHARED_TOOLS + extra_tools,
        llm=_llm(name),
        verbose=is_verbose(),
        allow_delegation=False,  # Sequential crew — no delegation
        max_iter=10,
        max_retry_limit=2,
    )


def build_crew(session_id: str = "") -> "ArchitectureCrew":
    """Instantiate and return the full architecture crew."""
    return ArchitectureCrew(session_id=session_id)


# ---------------------------------------------------------------------------
# Phase-specific task factories
# ---------------------------------------------------------------------------

def _make_site_tasks(
    user_message: str,
    session_id: str,
    architect: Agent,
    compliance_analyst: Agent,
) -> list[Task]:
    sid = session_id
    header = f"SESSION ID: {sid}\n\n" if sid else ""
    tool_rule = f'MANDATORY: pass session_id="{sid}" to every tool call.\n\n' if sid else ""
    req = f"User brief:\n{user_message}\n\n"

    site_setup = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Site & Brief — your ONLY job this phase.\n\n"
            "1. Call get_building_context to see current state.\n"
            "2. Use update_building_metadata to set project name, address, and building type "
            "based on the user brief.\n"
            "3. Create the initial level(s) with add_level (name only — no rooms or walls yet).\n\n"
            "Do NOT add rooms, walls, columns, furniture, or any spatial elements. "
            "That happens in a later phase."
        ),
        expected_output=(
            "Confirmation that project metadata is set and levels are initialised, "
            "with a brief restatement of the design brief."
        ),
        agent=architect,
    )

    site_constraints = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Site & Brief — your ONLY job this phase.\n\n"
            "1. If the user has provided site dimensions, call set_land to record the "
            "land boundary.\n"
            "2. Call run_compliance_check to identify zoning constraints "
            "(FAR limit, max height, setbacks).\n"
            "Summarise the site constraints that will guide the design.\n\n"
            "Do NOT add rooms, walls, or furniture."
        ),
        expected_output=(
            "Site boundary set (or noted as TBD), and a list of key zoning/regulatory "
            "constraints that the design must respect."
        ),
        agent=compliance_analyst,
        context=[site_setup],
    )

    return [site_setup, site_constraints]


def _make_floorplan_tasks(
    user_message: str,
    session_id: str,
    architect: Agent,
    structural_engineer: Agent,
    compliance_analyst: Agent,
) -> list[Task]:
    sid = session_id
    header = f"SESSION ID: {sid}\n\n" if sid else ""
    tool_rule = f'MANDATORY: pass session_id="{sid}" to every tool call.\n\n' if sid else ""
    req = f"User brief:\n{user_message}\n\n"

    arch_task = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Floor Plan — design the complete spatial layout.\n\n"
            "1. Call get_building_context to review what is already set (site, levels).\n\n"
            "2. DETERMINE THE BUILDING FOOTPRINT first — before placing any room:\n"
            "   a. Count the required rooms and sum their target areas.\n"
            "   b. Add 20 %% for walls, partitions, and circulation corridors.\n"
            "   c. Choose a compact footprint: aspect ratio between 1:1 and 1:2.\n"
            "   d. Example — 2-bed house (7 spaces, ~90 m² net): footprint ≈ 10 m × 11 m.\n\n"
            "3. ROOM SIZING — obey BOTH the minimum AND maximum:\n"
            "   - Bedroom:        9–16 m²  (e.g. 3.5 × 3.5 m or 4 × 3.5 m)\n"
            "   - Master bedroom: 14–20 m² (e.g. 4 × 4 m)\n"
            "   - Bathroom/WC:    4–7 m²   (e.g. 2.5 × 2.5 m or 2 × 3 m)\n"
            "   - Kitchen:        8–15 m²  (e.g. 3 × 3.5 m)\n"
            "   - Living room:    18–30 m² (e.g. 5 × 5 m or 6 × 4 m)\n"
            "   - Dining:         10–20 m² (e.g. 3.5 × 4 m)\n"
            "   - Corridor/hall:  1.2–1.5 m wide, length as needed\n"
            "   - Total net area must match the program (e.g. 2-bed house → 80–120 m²).\n\n"
            "4. TILING RULE — rooms MUST share edges; no gaps, no overlaps:\n"
            "   - Choose one corner as origin (0, 0).\n"
            "   - Place each room so its boundary_points exactly meet adjacent rooms.\n"
            "   - Example compact 2-bed layout (all in metres from origin):\n"
            "       Entry hall  (1.5 × 3.0):  [[0,0],[1.5,0],[1.5,3],[0,3]]\n"
            "       Living      (5.0 × 4.5):  [[1.5,0],[6.5,0],[6.5,4.5],[1.5,4.5]]\n"
            "       Kitchen     (3.5 × 4.5):  [[6.5,0],[10,0],[10,4.5],[6.5,4.5]]\n"
            "       Corridor    (1.5 × 4.5):  [[0,3],[1.5,3],[1.5,7.5],[0,7.5]]\n"
            "       Bedroom 1   (4.0 × 3.5):  [[1.5,4.5],[5.5,4.5],[5.5,8],[1.5,8]]\n"
            "       Bedroom 2   (3.5 × 3.5):  [[5.5,4.5],[9,4.5],[9,8],[5.5,8]]\n"
            "       Bathroom    (2.5 × 2.5):  [[9,4.5],[11.5,4.5],[11.5,7],[9,7]]\n"
            "   Adjust sizes to match the actual brief, but keep the tiling principle.\n\n"
            "5. ZONES — follow this spatial logic:\n"
            "   - PUBLIC zone  (entry, living, kitchen/dining) at the front (low y).\n"
            "   - PRIVATE zone (bedrooms, bathrooms) at the back (high y).\n"
            "   - A corridor or hallway separates the two zones.\n"
            "   - Bathrooms adjoin the bedrooms they serve.\n\n"
            "6. After all rooms are placed:\n"
            "   a. Add EXTERIOR walls tracing the full building perimeter.\n"
            "   b. Add INTERIOR partition walls along shared room boundaries.\n"
            "   c. Add doors (0.9 m wide) to every room; add windows to exterior walls.\n"
            "   d. Add staircases for multi-storey buildings.\n\n"
            "Do NOT add furniture or structural elements — those come later."
        ),
        expected_output=(
            "List of all rooms created (name, program, area m², boundary vertices), "
            "total net area, walls placed, and openings added."
        ),
        agent=architect,
    )

    struct_task = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Floor Plan — add structural elements.\n\n"
            "1. Review the architectural layout via get_building_context.\n"
            "2. Set the structural grid with set_structural_grid.\n"
            "3. Add columns and beams coordinated with the layout.\n"
            "4. Add floor/ceiling slabs for each level.\n"
            "5. Add ramps or elevators if required.\n\n"
            "Do NOT add furniture."
        ),
        expected_output=(
            "Structural grid, columns, beams, and slabs added; ramps/elevators if applicable."
        ),
        agent=structural_engineer,
        context=[arch_task],
    )

    compliance_task = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Floor Plan — compliance verification.\n\n"
            "1. run_compliance_check — zoning, FAR, height, setbacks.\n"
            "2. run_egress_report for each level.\n"
            "3. run_accessibility_check for each level.\n"
            "Flag any issues and propose the minimum changes needed to comply."
        ),
        expected_output=(
            "Compliance report: pass/fail per check, itemised findings, remediation steps."
        ),
        agent=compliance_analyst,
        context=[arch_task, struct_task],
    )

    return [arch_task, struct_task, compliance_task]


def _make_interiors_tasks(
    user_message: str,
    session_id: str,
    interior_designer: Agent,
) -> list[Task]:
    sid = session_id
    header = f"SESSION ID: {sid}\n\n" if sid else ""
    tool_rule = f'MANDATORY: pass session_id="{sid}" to every tool call.\n\n' if sid else ""
    req = f"User brief:\n{user_message}\n\n"

    interiors_task = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Furniture & Finishes — the floor plan is finalised; do not add or remove rooms/walls.\n\n"
            "1. Call get_building_detailed_context to get every room's centroid and bounding box.\n\n"
            "2. DERIVE ROOM BOUNDS — for each room you receive centroid (cx, cy) and bbox "
            "(x_min, y_min, x_max, y_max). Use these to calculate furniture positions.\n\n"
            "3. PLACEMENT RULES — all furniture MUST be inside the room boundary:\n"
            "   - Keep every piece ≥ 150 mm from the nearest wall face.\n"
            "   - Keep ≥ 750 mm clear circulation aisle between all pieces.\n"
            "   - Never place furniture outside the room's bounding box.\n\n"
            "4. PER-ROOM RECIPES — follow these exactly:\n\n"
            "   BEDROOM (bed against the wall opposite or perpendicular to the door):\n"
            "     - Bed centred left-right, headboard 150 mm from back wall.\n"
            "       x = cx,  y = y_max - 0.15 - bed_depth/2\n"
            "     - Wardrobe (depth 0.6 m) along a side wall, 150 mm from wall.\n"
            "       x = x_min + 0.15 + 0.9,  y = cx_y (midpoint of wardrobe)\n"
            "     - Bedside tables (0.5 × 0.5 m) flanking the bed.\n\n"
            "   LIVING ROOM:\n"
            "     - Sofa against the wall furthest from the entry, facing inward.\n"
            "       x = cx,  y = y_max - 0.15 - 0.45  (sofa depth 0.9 m)\n"
            "     - Coffee table 0.4 m in front of the sofa.\n"
            "     - TV unit against the opposite (entry-side) wall.\n"
            "       x = cx,  y = y_min + 0.15 + 0.225\n"
            "     - Armchair(s) to one side, maintaining 750 mm aisle to sofa.\n\n"
            "   KITCHEN:\n"
            "     - Counter runs along the longest wall (depth 0.6 m from wall face).\n"
            "       Place first counter: x = x_min + 0.15 + 1.2,  y = y_min + 0.15 + 0.3\n"
            "     - Second counter on perpendicular wall if room ≥ 8 m².\n"
            "     - Island centred (only if clear aisle ≥ 1.2 m on all sides).\n"
            "     - Ensure ≥ 1.2 m between parallel counter runs.\n\n"
            "   BATHROOM:\n"
            "     - Toilet (0.38 × 0.65 m) against the side wall, 150 mm from wall.\n"
            "       x = x_min + 0.15 + 0.19,  y = y_max - 0.15 - 0.325\n"
            "     - Sink (0.6 × 0.45 m) next to toilet, 750 mm clearance in front.\n"
            "       x = x_min + 0.15 + 0.3,   y = y_min + 0.15 + 0.225  (if space allows)\n"
            "     - Bathtub or shower against the back wall.\n"
            "       x = cx,  y = y_max - 0.15 - bathtub_depth/2\n\n"
            "   DINING ROOM / DINING AREA:\n"
            "     - Dining table centred: x = cx,  y = cy\n"
            "     - Dining chairs evenly spaced around the table (≥ 600 mm from table edge to wall).\n\n"
            "   OFFICE / STUDY:\n"
            "     - Desk against the wall with the best daylight (or facing the window wall).\n"
            "     - Bookshelf along a side wall.\n\n"
            "5. After furniture, assign materials to rooms with set_room_material, "
            "and add text annotations for key design-intent notes.\n\n"
            "Do NOT modify rooms, walls, or structural elements."
        ),
        expected_output=(
            "For each room: furniture type, position (x, y), and that it is inside the room bounds. "
            "Materials assigned and annotations added."
        ),
        agent=interior_designer,
    )

    return [interiors_task]


def _make_finalise_tasks(
    user_message: str,
    session_id: str,
    space_programmer: Agent,
    bim_coordinator: Agent,
) -> list[Task]:
    sid = session_id
    header = f"SESSION ID: {sid}\n\n" if sid else ""
    tool_rule = f'MANDATORY: pass session_id="{sid}" to every tool call.\n\n' if sid else ""
    req = f"User brief:\n{user_message}\n\n"

    space_task = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Validation & Export — analyse the completed design.\n\n"
            "1. run_area_report to check rooms against programme targets.\n"
            "2. run_adjacency_analysis to verify spatial relationships.\n"
            "Summarise pass/fail per space and highlight any issues."
        ),
        expected_output=(
            "Area and adjacency compliance report, pass/fail per space, any unresolved issues."
        ),
        agent=space_programmer,
    )

    bim_task = Task(
        description=(
            f"{header}{req}{tool_rule}"
            "PHASE: Validation & Export — finalise and export the project.\n\n"
            f"1. validate_building(session_id=\"{sid}\").\n"
            "2. export_level_svg for every level with rooms or walls.\n"
            "3. export_building_json.\n"
            f"4. save_session(session_id=\"{sid}\").\n\n"
            "Do not make any design changes."
        ),
        expected_output=(
            "Validation result, SVG and JSON export paths, session save confirmation."
        ),
        agent=bim_coordinator,
        context=[space_task],
    )

    return [space_task, bim_task]


# ---------------------------------------------------------------------------
# Task factory
# ---------------------------------------------------------------------------

def _make_tasks(
    user_message: str,
    session_id: str,
    architect: Agent,
    structural_engineer: Agent,
    compliance_analyst: Agent,
    interior_designer: Agent,
    space_programmer: Agent,
    bim_coordinator: Agent,
) -> list[Task]:
    """
    Build a sequential task list — one task per specialist.

    Tasks are chained via *context* so each agent can read what the previous
    agents did.  The planning LLM (invoked by planning=True on the Crew) will
    prepend a coherent plan to every task description before execution.
    """
    sid = session_id
    header = f"SESSION ID: {sid}\n\n" if sid else ""
    tool_rule = (
        f'MANDATORY: pass session_id="{sid}" to every tool call.\n\n'
        if sid else ""
    )
    request_line = f"User request:\n{user_message}\n\n"

    # ── Task 1: Architect ─────────────────────────────────────────────────
    architect_task = Task(
        description=(
            f"{header}{request_line}{tool_rule}"
            "Your role: Senior Architect — Spatial Design.\n\n"
            "If this request involves spatial layout, levels, rooms, walls, openings, "
            "or staircases:\n"
            f"  1. Call get_building_context(session_id=\"{sid}\") to see current state.\n"
            "  2. FOOTPRINT FIRST: determine total building area = sum of room targets + 20%% "
            "for walls/circulation. Pick a compact rectangle (aspect ratio 1:1 to 1:2).\n"
            "  3. TILE rooms within that footprint — every room boundary must share edges "
            "with neighbours. No gaps, no overlaps. Start at origin (0,0).\n"
            "  4. SIZING — obey BOTH min and max:\n"
            "     Bedroom 9–16 m², master 14–20 m², bathroom 4–7 m², "
            "kitchen 8–15 m², living 18–30 m², corridor 1.2–1.5 m wide.\n"
            "  5. ZONES: public (living, kitchen) at front (low y), "
            "private (beds, baths) at back (high y), corridor between.\n"
            "  6. Add exterior walls tracing the perimeter, interior walls along shared "
            "room boundaries, doors (0.9 m) to every room, windows on exterior walls.\n\n"
            "If spatial design is NOT relevant to this request, respond with exactly: "
            "'No architectural changes required.'"
        ),
        expected_output=(
            "A concise list of levels and rooms created or modified "
            "(name, program type, area in m²), "
            "or 'No architectural changes required.' if not applicable."
        ),
        agent=architect,
    )

    # ── Task 2: Structural Engineer ────────────────────────────────────────
    structural_task = Task(
        description=(
            f"{header}{request_line}{tool_rule}"
            "Your role: Structural Engineer.\n\n"
            "Review the architectural output from the previous step.  "
            "If structural elements (columns, beams, slabs, ramps, or elevators) are needed:\n"
            "  1. Set the structural grid if it has not been defined.\n"
            "  2. Add columns, beams, and slabs that are coordinated with the architectural layout.\n"
            "  3. Add ramps or elevators if circulation requires them.\n\n"
            "If structural design is NOT relevant, respond with: "
            "'No structural changes required.'"
        ),
        expected_output=(
            "Summary of structural elements added and grid configuration, "
            "or 'No structural changes required.' if not applicable."
        ),
        agent=structural_engineer,
        context=[architect_task],
    )

    # ── Task 3: Compliance Analyst ─────────────────────────────────────────
    compliance_task = Task(
        description=(
            f"{header}{request_line}{tool_rule}"
            "Your role: Compliance & Regulatory Analyst.\n\n"
            "If compliance verification is relevant to this request:\n"
            "  1. run_compliance_check — zoning, FAR, height, setbacks.\n"
            "  2. run_egress_report for each level.\n"
            "  3. run_accessibility_check for each level.\n"
            "  4. run_daylight_report if daylighting is relevant.\n"
            "Flag any non-compliances and propose the minimum changes needed.\n\n"
            "If compliance is NOT relevant, respond with: "
            "'No compliance checks required.'"
        ),
        expected_output=(
            "Compliance report: overall pass/fail, itemised findings per check, "
            "and specific remediation steps; "
            "or 'No compliance checks required.' if not applicable."
        ),
        agent=compliance_analyst,
        context=[architect_task, structural_task],
    )

    # ── Task 4: Interior Designer ──────────────────────────────────────────
    interior_task = Task(
        description=(
            f"{header}{request_line}{tool_rule}"
            "Your role: Interior Designer.\n\n"
            "If furnishing, materials, or annotations are relevant to this request:\n"
            "  1. Add appropriate furniture to each room based on its program type.\n"
            "  2. Assign coherent materials that reinforce the design concept.\n"
            "  3. Add text annotations to communicate design intent.\n"
            "Ensure furniture layouts maintain ≥ 750 mm clearance around pieces.\n\n"
            "If interior design is NOT relevant, respond with: "
            "'No interior design changes required.'"
        ),
        expected_output=(
            "List of furniture placed and materials assigned per room, "
            "or 'No interior design changes required.' if not applicable."
        ),
        agent=interior_designer,
        context=[architect_task],
    )

    # ── Task 5: Space Programmer ───────────────────────────────────────────
    space_task = Task(
        description=(
            f"{header}{request_line}{tool_rule}"
            "Your role: Space Programmer & Brief Analyst.\n\n"
            "If area or adjacency verification is relevant to this request:\n"
            "  1. run_area_report to check each room against programme targets.\n"
            "  2. run_adjacency_analysis to verify spatial relationships.\n"
            "Identify missing spaces, under/over-sized rooms, or incorrect adjacencies.\n\n"
            "If space programming is NOT relevant, respond with: "
            "'No space programming required.'"
        ),
        expected_output=(
            "Area and adjacency compliance report with pass/fail per space, "
            "or 'No space programming required.' if not applicable."
        ),
        agent=space_programmer,
        context=[architect_task, interior_task],
    )

    # ── Task 6: BIM Coordinator ────────────────────────────────────────────
    bim_task = Task(
        description=(
            f"{header}{request_line}{tool_rule}"
            "Your role: BIM Coordinator & Project Data Manager.\n\n"
            "After all design changes are complete:\n"
            f"  1. validate_building(session_id=\"{sid}\") — ensure model integrity.\n"
            "  2. export_level_svg for every level that has rooms or walls.\n"
            "  3. export_building_json — full project data export.\n"
            f"  4. save_session(session_id=\"{sid}\") — persist the session.\n\n"
            "If no design changes were made and the building has no content, "
            "you may skip steps 2–4 but always validate and save if content exists.\n"
            "If there is truly nothing to do, respond with: "
            "'No BIM coordination required.'"
        ),
        expected_output=(
            "Validation result, list of exported SVG files and JSON file path, "
            "and session save confirmation; "
            "or 'No BIM coordination required.' if the building is empty."
        ),
        agent=bim_coordinator,
        context=[architect_task, structural_task, interior_task, space_task],
    )

    return [
        architect_task,
        structural_task,
        compliance_task,
        interior_task,
        space_task,
        bim_task,
    ]


# ---------------------------------------------------------------------------
# Crew class
# ---------------------------------------------------------------------------

class ArchitectureCrew:
    """
    Sequential 6-specialist architecture crew.

    Usage:
        crew = ArchitectureCrew(session_id="abc123")
        result = await crew.arun(session_id="abc123", user_message="Design a 3-bed house")
    """

    def __init__(self, session_id: str = "") -> None:
        self._session_id = session_id

        self.architect = _make_agent("architect", [
            add_level, add_room, remove_element, add_wall,
            add_opening_to_wall, add_staircase, update_building_metadata,
            undo_last_change, redo_last_change,
        ], session_id=session_id)

        self.structural_engineer = _make_agent("structural_engineer", [
            add_column, add_beam, add_slab, add_elevator,
            set_structural_grid, add_ramp,
        ], session_id=session_id)

        self.compliance_analyst = _make_agent("compliance_analyst", [
            run_compliance_check, run_egress_report,
            run_accessibility_check, run_daylight_report, set_land,
        ], session_id=session_id)

        self.interior_designer = _make_agent("interior_designer", [
            add_furniture, add_text_annotation, set_room_material,
        ], session_id=session_id)

        self.space_programmer = _make_agent("space_programmer", [
            run_area_report, run_adjacency_analysis,
        ], session_id=session_id)

        self.bim_coordinator = _make_agent("bim_coordinator", [
            export_level_svg, export_building_json, validate_building,
            save_session, load_session_tool, list_saved_sessions,
            undo_last_change, redo_last_change,
        ], session_id=session_id)

        self._specialists = [
            self.architect,
            self.structural_engineer,
            self.compliance_analyst,
            self.interior_designer,
            self.space_programmer,
            self.bim_coordinator,
        ]

    def _build_crew(self, user_message: str) -> tuple[Crew, list[Task]]:
        tasks = _make_tasks(
            user_message=user_message,
            session_id=self._session_id,
            architect=self.architect,
            structural_engineer=self.structural_engineer,
            compliance_analyst=self.compliance_analyst,
            interior_designer=self.interior_designer,
            space_programmer=self.space_programmer,
            bim_coordinator=self.bim_coordinator,
        )
        crew = Crew(
            agents=self._specialists,
            tasks=tasks,
            process=Process.sequential,
            planning=True,
            planning_llm=_llm("project_manager"),
            verbose=is_verbose(),
            memory=False,
        )
        return crew, tasks

    def run(self, session_id: str, user_message: str) -> str:
        """Synchronous entry point."""
        crew, _ = self._build_crew(user_message)
        result = crew.kickoff()
        return str(result) if result else "I was unable to process that request."

    async def arun(self, session_id: str, user_message: str) -> str:
        """Async entry point — uses CrewAI's native async kickoff."""
        crew, _ = self._build_crew(user_message)
        result = await crew.akickoff()
        return str(result) if result else "I was unable to process that request."

    async def arun_phase(self, phase: DesignPhase, session_id: str, user_message: str) -> str:
        """Run only the agents and tasks relevant to *phase*."""
        if phase == DesignPhase.SITE:
            tasks = _make_site_tasks(user_message, session_id, self.architect, self.compliance_analyst)
            agents = [self.architect, self.compliance_analyst]
        elif phase == DesignPhase.FLOORPLAN:
            tasks = _make_floorplan_tasks(
                user_message, session_id,
                self.architect, self.structural_engineer, self.compliance_analyst,
            )
            agents = [self.architect, self.structural_engineer, self.compliance_analyst]
        elif phase == DesignPhase.INTERIORS:
            tasks = _make_interiors_tasks(user_message, session_id, self.interior_designer)
            agents = [self.interior_designer]
        elif phase == DesignPhase.FINALISE:
            tasks = _make_finalise_tasks(
                user_message, session_id, self.space_programmer, self.bim_coordinator,
            )
            agents = [self.space_programmer, self.bim_coordinator]
        else:
            return "Unknown phase."

        crew = Crew(
            agents=agents,
            tasks=tasks,
            process=Process.sequential,
            planning=True,
            planning_llm=_llm("project_manager"),
            verbose=is_verbose(),
            memory=False,
        )
        result = await crew.akickoff()
        return str(result) if result else "Phase complete."
