"""
Custom lightweight agent runner — replaces CrewAI for phase execution.

Architecture
------------
Each agent is a simple tool-use loop backed by either openai.AsyncOpenAI
(for GPT models) or anthropic.AsyncAnthropic (for Claude models):
  1. Build messages: system prompt + optional prior-agent context + task
  2. Call LLM
  3. If tool calls → execute them in a thread pool → append results → go to 2
  4. If stop → send text to UI via on_text callback → done
  5. Pass accumulated text as context to the next agent in the phase

Provider routing
----------------
SUPPORTED_MODELS in config.py maps model keys to resolved IDs:
  - OpenAI models:    "gpt-4o"   → "gpt-4o"
  - Anthropic models: "claude-*" → "anthropic/claude-*"

A resolved ID that starts with "anthropic/" is routed to AsyncAnthropic;
the "anthropic/" prefix is stripped before the API call since Anthropic's
SDK takes the bare model name (e.g. "claude-3-5-haiku-20241022").

OpenAI and Anthropic use different wire formats for tools and messages;
each has its own internal _run_agent_* function that handles the specifics.

Phases run their agents sequentially; SVG / stats / phase-gate events are
handled by server.py after run_phase() returns.
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Awaitable, Callable

from anthropic import AsyncAnthropic
from openai import AsyncOpenAI

_oai_client = AsyncOpenAI()
_ant_client = AsyncAnthropic()

from studio.agents.definitions import AGENT_DEFS
from studio.agents.tool_catalog import ALL_SCHEMAS, get_registry, schemas_for
from studio.config import get_model_for_agent
from studio.state.session import DesignPhase, PHASE_LABELS

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Provider helpers
# ---------------------------------------------------------------------------

_ANTHROPIC_PREFIX = "anthropic/"


def _is_anthropic(model: str) -> bool:
    """True if the resolved model ID targets the Anthropic API."""
    return model.startswith(_ANTHROPIC_PREFIX)


def _bare_model(model: str) -> str:
    """Strip the routing prefix; Anthropic SDK takes the bare model name."""
    return model.removeprefix(_ANTHROPIC_PREFIX)


def _to_anthropic_tools(oai_tools: list[dict]) -> list[dict]:
    """
    Convert OpenAI-format tool schemas to Anthropic format.

    OpenAI:   {"type": "function", "function": {"name": ..., "description": ..., "parameters": {...}}}
    Anthropic: {"name": ..., "description": ..., "input_schema": {...}}
    """
    result = []
    for t in oai_tools:
        fn = t.get("function", t)  # handle both wrapped and bare dicts
        result.append({
            "name":         fn["name"],
            "description":  fn.get("description", ""),
            "input_schema": fn.get("parameters", {"type": "object", "properties": {}}),
        })
    return result

# Safety cap: max tool-call rounds per agent invocation
_MAX_ROUNDS = 40


# ---------------------------------------------------------------------------
# Agent spec
# ---------------------------------------------------------------------------

@dataclass
class AgentSpec:
    """Lightweight description of one agent in a phase."""
    key: str             # key in AGENT_DEFS  e.g. "architect"
    tool_names: list[str]
    display_name: str = ""  # shown in UI; defaults to AGENT_DEFS role

    def system_prompt(self) -> str:
        d = AGENT_DEFS[self.key]
        return (
            f"You are a {d['role']}.\n\n"
            f"**Goal:** {d['goal']}\n\n"
            f"**Background:** {d['backstory']}\n\n"
            "Use your tools to make changes to the building model. "
            "Always call get_building_context first to see the current state. "
            "Return a concise professional summary of what you did and why."
        )

    def ui_name(self) -> str:
        return self.display_name or AGENT_DEFS[self.key]["role"]


# ---------------------------------------------------------------------------
# Core agent loop
# ---------------------------------------------------------------------------

async def run_agent(
    spec: AgentSpec,
    task: str,
    *,
    context: str = "",
    session_id: str = "",
    on_text: Callable[[str, str], Awaitable[None]] | None = None,
) -> str:
    """
    Run a single agent to completion.

    Routes to _run_agent_openai or _run_agent_anthropic based on the
    resolved model ID returned by get_model_for_agent.

    Parameters
    ----------
    spec        : AgentSpec describing this agent
    task        : the task description string
    context     : output from previous agents in this phase (passed as context)
    session_id  : active session (injected into tool calls if missing)
    on_text     : async callback(author, text) called after each LLM response

    Returns
    -------
    Full text output produced by this agent.
    """
    model = get_model_for_agent(spec.key)
    if _is_anthropic(model):
        return await _run_agent_anthropic(spec, task, model=model, context=context,
                                          session_id=session_id, on_text=on_text)
    return await _run_agent_openai(spec, task, model=model, context=context,
                                   session_id=session_id, on_text=on_text)


# ---------------------------------------------------------------------------
# OpenAI provider loop
# ---------------------------------------------------------------------------

async def _run_agent_openai(
    spec: AgentSpec,
    task: str,
    *,
    model: str,
    context: str = "",
    session_id: str = "",
    on_text: Callable[[str, str], Awaitable[None]] | None = None,
) -> str:
    tools = schemas_for(spec.tool_names)
    registry = get_registry()

    messages: list[dict] = [{"role": "system", "content": spec.system_prompt()}]
    if context:
        messages += [
            {"role": "user",      "content": f"Context from previous work this phase:\n\n{context}"},
            {"role": "assistant", "content": "Understood. I have reviewed the prior work."},
        ]
    messages.append({"role": "user", "content": task})

    accumulated: list[str] = []

    for _ in range(_MAX_ROUNDS):
        call_kwargs: dict = {"model": model, "messages": messages, "max_tokens": 8192}
        if tools:
            call_kwargs["tools"] = tools
            call_kwargs["tool_choice"] = "auto"

        response = await _oai_client.chat.completions.create(**call_kwargs)
        choice = response.choices[0]
        msg = choice.message
        text: str = msg.content or ""
        is_final = choice.finish_reason == "stop" or not msg.tool_calls

        if is_final:
            if text:
                accumulated.append(text)
                if on_text:
                    await on_text(spec.ui_name(), text)
            break

        messages.append({
            "role": "assistant",
            "content": msg.content,
            "tool_calls": [
                {"id": tc.id, "type": "function",
                 "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                for tc in msg.tool_calls
            ],
        })

        tool_result_messages: list[dict] = []
        for tc in msg.tool_calls:
            result = await _call_tool(tc.function.name, tc.function.arguments, session_id, registry)
            tool_result_messages.append(
                {"role": "tool", "tool_call_id": tc.id, "content": result}
            )
        messages.extend(tool_result_messages)

    else:
        log.warning("Agent %s hit max rounds (%d)", spec.key, _MAX_ROUNDS)

    return "\n\n".join(accumulated)


# ---------------------------------------------------------------------------
# Anthropic provider loop
# ---------------------------------------------------------------------------

async def _run_agent_anthropic(
    spec: AgentSpec,
    task: str,
    *,
    model: str,
    context: str = "",
    session_id: str = "",
    on_text: Callable[[str, str], Awaitable[None]] | None = None,
) -> str:
    """
    Anthropic wire format differs from OpenAI in three important ways:
      1. System prompt is a top-level kwarg, not a message role.
      2. Tool schemas use {name, description, input_schema} instead of
         {type, function: {name, description, parameters}}.
      3. Tool results go back in a "user" turn as content blocks of
         type "tool_result", not as role="tool" messages.
    """
    oai_tools = schemas_for(spec.tool_names)
    ant_tools = _to_anthropic_tools(oai_tools)
    registry = get_registry()
    bare_model = _bare_model(model)

    # Build initial messages (no system role — passed separately)
    messages: list[dict] = []
    if context:
        messages += [
            {"role": "user",      "content": f"Context from previous work this phase:\n\n{context}"},
            {"role": "assistant", "content": "Understood. I have reviewed the prior work."},
        ]
    messages.append({"role": "user", "content": task})

    accumulated: list[str] = []

    for _ in range(_MAX_ROUNDS):
        call_kwargs: dict = {
            "model":      bare_model,
            "system":     spec.system_prompt(),
            "messages":   messages,
            "max_tokens": 8192,
        }
        if ant_tools:
            call_kwargs["tools"] = ant_tools

        response = await _ant_client.messages.create(**call_kwargs)

        # Extract text blocks and tool-use blocks from the response
        text_parts: list[str] = []
        tool_uses: list = []
        for block in response.content:
            if block.type == "text":
                text_parts.append(block.text)
            elif block.type == "tool_use":
                tool_uses.append(block)

        text = "\n".join(text_parts).strip()
        is_final = response.stop_reason == "end_turn" or not tool_uses

        if is_final:
            if text:
                accumulated.append(text)
                if on_text:
                    await on_text(spec.ui_name(), text)
            break

        # Append the assistant turn (content is the raw response content list)
        messages.append({"role": "assistant", "content": response.content})

        # Execute tools and return results in a single user turn
        tool_result_blocks: list[dict] = []
        for tu in tool_uses:
            result = await _call_tool(tu.name, json.dumps(tu.input), session_id, registry)
            tool_result_blocks.append({
                "type":        "tool_result",
                "tool_use_id": tu.id,
                "content":     result,
            })
        messages.append({"role": "user", "content": tool_result_blocks})

    else:
        log.warning("Agent %s hit max rounds (%d)", spec.key, _MAX_ROUNDS)

    return "\n\n".join(accumulated)


# ---------------------------------------------------------------------------
# Shared tool execution helper
# ---------------------------------------------------------------------------

async def _call_tool(fn_name: str, arguments: str, session_id: str, registry: dict) -> str:
    """Parse arguments, inject session_id if missing, execute the tool."""
    try:
        kwargs = json.loads(arguments)
        if session_id and "session_id" not in kwargs:
            schema = ALL_SCHEMAS.get(fn_name, {})
            props = schema.get("function", {}).get("parameters", {}).get("properties", {})
            if "session_id" in props:
                kwargs["session_id"] = session_id

        fn = registry.get(fn_name)
        if fn is None:
            return json.dumps({"status": "error", "message": f"Unknown tool: {fn_name}"})
        return await asyncio.to_thread(fn, **kwargs)

    except Exception as exc:
        log.warning("Tool %s raised: %s", fn_name, exc, exc_info=True)
        return json.dumps({"status": "error", "message": str(exc)})


# ---------------------------------------------------------------------------
# Phase definitions
# ---------------------------------------------------------------------------

def _header(session_id: str, user_message: str) -> str:
    sid_line = f"SESSION ID: {session_id}\n\n" if session_id else ""
    tool_rule = (
        f'MANDATORY: pass session_id="{session_id}" to every tool call.\n\n'
        if session_id else ""
    )
    return f"{sid_line}User brief:\n{user_message}\n\n{tool_rule}"


def _site_agents_and_tasks(
    session_id: str,
    user_message: str,
) -> list[tuple[AgentSpec, str]]:
    from studio.agents.tool_catalog import ARCHITECT_TOOLS, COMPLIANCE_TOOLS

    h = _header(session_id, user_message)
    architect = AgentSpec("architect", ARCHITECT_TOOLS)
    compliance = AgentSpec("compliance_analyst", COMPLIANCE_TOOLS)

    return [
        (architect, (
            f"{h}"
            "PHASE: Site & Brief — your ONLY job this phase.\n\n"
            "1. Call get_building_context to see current state.\n"
            "2. Use update_building_metadata to set project name, address, and building type.\n"
            "3. Create the initial level(s) with add_level (name only — no rooms or walls yet).\n\n"
            "Do NOT add rooms, walls, columns, furniture, or any spatial elements."
        )),
        (compliance, (
            f"{h}"
            "PHASE: Site & Brief — your ONLY job this phase.\n\n"
            "1. If the user provided site dimensions, call set_land to record the boundary.\n"
            "2. Call run_compliance_check to identify zoning constraints.\n"
            "Summarise the key constraints that will guide the design.\n\n"
            "Do NOT add rooms, walls, or furniture."
        )),
    ]


def _floorplan_agents_and_tasks(
    session_id: str,
    user_message: str,
) -> list[tuple[AgentSpec, str]]:
    from studio.agents.tool_catalog import ARCHITECT_TOOLS, STRUCTURAL_TOOLS, COMPLIANCE_TOOLS

    h = _header(session_id, user_message)
    architect   = AgentSpec("architect",           ARCHITECT_TOOLS)
    structural  = AgentSpec("structural_engineer", STRUCTURAL_TOOLS)
    compliance  = AgentSpec("compliance_analyst",  COMPLIANCE_TOOLS)

    return [
        (architect, (
            f"{h}"
            "PHASE: Floor Plan — design the complete spatial layout.\n\n"
            "1. Call get_building_context to review what is already set (site, levels).\n\n"
            "2. DETERMINE THE BUILDING FOOTPRINT first — before placing any room:\n"
            "   a. Count the required rooms and sum their target areas.\n"
            "   b. Add 20% for walls, partitions, and circulation corridors.\n"
            "   c. Choose a compact footprint: aspect ratio between 1:1 and 1:2.\n"
            "   d. Example — 2-bed house (7 spaces, ~90 m² net): footprint ≈ 10 m × 11 m.\n\n"
            "3. ROOM SIZING — obey BOTH the minimum AND maximum:\n"
            "   - Bedroom:        9–16 m²  (e.g. 3.5 × 3.5 m or 4 × 3.5 m)\n"
            "   - Master bedroom: 14–20 m² (e.g. 4 × 4 m)\n"
            "   - Bathroom/WC:    4–7 m²   (e.g. 2.5 × 2.5 m or 2 × 3 m)\n"
            "   - Kitchen:        8–15 m²  (e.g. 3 × 3.5 m)\n"
            "   - Living room:    18–30 m² (e.g. 5 × 5 m or 6 × 4 m)\n"
            "   - Dining:         10–20 m² (e.g. 3.5 × 4 m)\n"
            "   - Corridor/hall:  1.2–1.5 m wide, length as needed\n"
            "   - Total net area must match the program (e.g. 2-bed house → 80–120 m²).\n\n"
            "4. TILING RULE — rooms MUST share edges; no gaps, no overlaps:\n"
            "   - Choose one corner as origin (0, 0).\n"
            "   - Place each room so its boundary_points exactly meet adjacent rooms.\n"
            "   - Example compact 2-bed layout (all in metres from origin):\n"
            "       Entry hall  (1.5 × 3.0):  [[0,0],[1.5,0],[1.5,3],[0,3]]\n"
            "       Living      (5.0 × 4.5):  [[1.5,0],[6.5,0],[6.5,4.5],[1.5,4.5]]\n"
            "       Kitchen     (3.5 × 4.5):  [[6.5,0],[10,0],[10,4.5],[6.5,4.5]]\n"
            "       Corridor    (1.5 × 4.5):  [[0,3],[1.5,3],[1.5,7.5],[0,7.5]]\n"
            "       Bedroom 1   (4.0 × 3.5):  [[1.5,4.5],[5.5,4.5],[5.5,8],[1.5,8]]\n"
            "       Bedroom 2   (3.5 × 3.5):  [[5.5,4.5],[9,4.5],[9,8],[5.5,8]]\n"
            "       Bathroom    (2.5 × 2.5):  [[9,4.5],[11.5,4.5],[11.5,7],[9,7]]\n"
            "   Adjust sizes to match the actual brief, but keep the tiling principle.\n\n"
            "5. ZONES — follow this spatial logic:\n"
            "   - PUBLIC zone  (entry, living, kitchen/dining) at the front (low y).\n"
            "   - PRIVATE zone (bedrooms, bathrooms) at the back (high y).\n"
            "   - A corridor or hallway separates the two zones.\n"
            "   - Bathrooms adjoin the bedrooms they serve.\n\n"
            "6. After all rooms are placed:\n"
            "   a. Add EXTERIOR walls tracing the full building perimeter.\n"
            "   b. Add INTERIOR partition walls along shared room boundaries.\n"
            "   c. Add doors (0.9 m wide) to every room; add windows to exterior walls.\n"
            "   d. Add staircases for multi-storey buildings.\n\n"
            "Do NOT add furniture or structural elements — those come later."
        )),
        (structural, (
            f"{h}"
            "PHASE: Floor Plan — add structural elements.\n\n"
            "1. Call get_building_context to review the architectural layout.\n"
            "2. DECISION — choose the right approach for this building type:\n\n"
            "   SIMPLE RESIDENTIAL (single storey, all spans ≤ 8 m, timber frame):\n"
            "   - Do NOT add a structural grid, columns, or beams.\n"
            "   - Add one roof slab covering the full building footprint.\n"
            "   - Add ramps only if explicitly requested.\n\n"
            "   COMPLEX / MULTI-STOREY (RC frame, spans > 8 m, or multi-level):\n"
            "   - Set the structural grid with set_structural_grid, passing x_spacing\n"
            "     and y_spacing as arrays of numbers e.g. [0, 5, 10] that match the\n"
            "     room layout. x_labels and y_labels are optional — omit them.\n"
            "   - Add columns at grid intersections within the building footprint only.\n"
            "   - Add beams between column pairs.\n"
            "   - Add floor slabs per level.\n"
            "   - Add elevators or ramps if the brief requires them.\n\n"
            "Do NOT add furniture."
        )),
        (compliance, (
            f"{h}"
            "PHASE: Floor Plan — compliance verification.\n\n"
            "1. run_compliance_check — zoning, FAR, height, setbacks.\n"
            "2. run_egress_report for each level.\n"
            "3. run_accessibility_check for each level.\n"
            "Flag any issues and propose the minimum changes needed to comply."
        )),
    ]


def _interiors_agents_and_tasks(
    session_id: str,
    user_message: str,
) -> list[tuple[AgentSpec, str]]:
    from studio.agents.tool_catalog import INTERIOR_TOOLS

    h = _header(session_id, user_message)
    interior = AgentSpec("interior_designer", INTERIOR_TOOLS)

    return [
        (interior, (
            f"{h}"
            "PHASE: Furniture & Finishes — the floor plan is finalised; do not add or remove rooms/walls.\n\n"
            "1. Call get_building_detailed_context to get every room's centroid and bounding box.\n\n"
            "2. DERIVE ROOM BOUNDS — for each room you receive centroid (cx, cy) and bbox "
            "(x_min, y_min, x_max, y_max). Use these to calculate furniture positions.\n\n"
            "3. PLACEMENT RULES — all furniture MUST be inside the room boundary:\n"
            "   - Keep every piece ≥ 150 mm from the nearest wall face.\n"
            "   - Keep ≥ 750 mm clear circulation aisle between all pieces.\n"
            "   - Never place furniture outside the room's bounding box.\n\n"
            "4. PER-ROOM RECIPES — follow these exactly:\n\n"
            "   BEDROOM (bed against the wall opposite or perpendicular to the door):\n"
            "     - Bed centred left-right, headboard 150 mm from back wall.\n"
            "       x = cx,  y = y_max - 0.15 - bed_depth/2\n"
            "     - Wardrobe (depth 0.6 m) along a side wall, 150 mm from wall.\n"
            "       x = x_min + 0.15 + 0.9,  y = cy\n"
            "     - Bedside tables (0.5 × 0.5 m) flanking the bed.\n\n"
            "   LIVING ROOM:\n"
            "     - Sofa against the wall furthest from the entry, facing inward.\n"
            "       x = cx,  y = y_max - 0.15 - 0.45\n"
            "     - Coffee table 0.4 m in front of the sofa.\n"
            "     - TV unit against the opposite wall: x = cx, y = y_min + 0.15 + 0.225\n"
            "     - Armchair(s) to one side with 750 mm aisle to sofa.\n\n"
            "   KITCHEN:\n"
            "     - Counter runs along the longest wall (depth 0.6 m from wall face).\n"
            "       x = cx,  y = y_min + 0.15 + 0.3\n"
            "     - Second counter on perpendicular wall if room ≥ 8 m².\n"
            "     - Island centred only if clear aisle ≥ 1.2 m on all sides.\n\n"
            "   BATHROOM:\n"
            "     - Toilet (0.38 × 0.65 m) against the side wall, 150 mm from wall.\n"
            "       x = x_min + 0.15 + 0.19,  y = y_max - 0.15 - 0.325\n"
            "     - Sink next to toilet; bathtub/shower against the back wall.\n\n"
            "   DINING:\n"
            "     - Dining table centred: x = cx, y = cy\n"
            "     - Chairs evenly spaced around it (≥ 600 mm from table edge to wall).\n\n"
            "5. After furniture, assign materials to rooms with set_room_material "
            "and add text annotations for key design-intent notes.\n\n"
            "Do NOT modify rooms, walls, or structural elements."
        )),
    ]


def _finalise_agents_and_tasks(
    session_id: str,
    user_message: str,
) -> list[tuple[AgentSpec, str]]:
    from studio.agents.tool_catalog import SPACE_TOOLS, BIM_TOOLS

    h = _header(session_id, user_message)
    space = AgentSpec("space_programmer",  SPACE_TOOLS)
    bim   = AgentSpec("bim_coordinator",   BIM_TOOLS)

    return [
        (space, (
            f"{h}"
            "PHASE: Validation & Export — analyse the completed design.\n\n"
            "1. run_area_report to check rooms against programme targets.\n"
            "2. run_adjacency_analysis to verify spatial relationships.\n"
            "Summarise pass/fail per space and highlight any issues."
        )),
        (bim, (
            f"{h}"
            "PHASE: Validation & Export — finalise and export the project.\n\n"
            f"1. validate_building(session_id=\"{session_id}\").\n"
            "2. export_level_svg for every level with rooms or walls.\n"
            "3. export_building_json.\n"
            f"4. save_session(session_id=\"{session_id}\").\n\n"
            "Do not make any design changes."
        )),
    ]


_PHASE_FACTORIES = {
    DesignPhase.SITE:      _site_agents_and_tasks,
    DesignPhase.FLOORPLAN: _floorplan_agents_and_tasks,
    DesignPhase.INTERIORS: _interiors_agents_and_tasks,
    DesignPhase.FINALISE:  _finalise_agents_and_tasks,
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def run_phase(
    phase: DesignPhase,
    session_id: str,
    user_message: str,
    on_text: Callable[[str, str], Awaitable[None]] | None = None,
) -> str:
    """
    Run all agents for the given design phase sequentially.

    Each agent's output is forwarded to `on_text(author, text)` as it
    completes and is also passed as context to the next agent.

    Returns the combined output of all agents.
    """
    factory = _PHASE_FACTORIES.get(phase)
    if factory is None:
        raise ValueError(f"Unknown phase: {phase}")

    agent_tasks = factory(session_id, user_message)
    label = PHASE_LABELS[phase]
    log.info("Phase %s — running %d agent(s)", label, len(agent_tasks))

    context = ""
    all_outputs: list[str] = []

    for spec, task in agent_tasks:
        log.debug("Running agent: %s", spec.ui_name())
        output = await run_agent(
            spec,
            task,
            context=context,
            session_id=session_id,
            on_text=on_text,
        )
        if output:
            all_outputs.append(f"**{spec.ui_name()}:**\n\n{output}")
            context = output  # pass this agent's output to the next

    return "\n\n---\n\n".join(all_outputs)
