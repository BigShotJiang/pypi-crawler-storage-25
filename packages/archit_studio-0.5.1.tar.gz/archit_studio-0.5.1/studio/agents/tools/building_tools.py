"""
Building design tools — rooms, walls, openings, levels, staircases.

All tools follow the same contract:
  - Accept ``session_id`` plus element-specific params.
  - Read the current Building from the session, apply the change (returning a new
    immutable Building), push to session history, and return a JSON string with
    status + compact building summary.
  - Never mutate archit-app objects in-place; always use the immutable API.
"""

import json
from typing import Optional

from crewai.tools import tool

from archit_app import (
    Building, BuildingMetadata, Level, Room, Wall, Opening, Staircase,
    Polygon2D, Point2D, WORLD, OpeningKind, StaircaseType,
)
from archit_app.elements.beam import Beam
from archit_app.elements.column import Column
from archit_app.elements.furniture import Furniture
from archit_app.elements.ramp import Ramp
from archit_app.elements.slab import Slab
from archit_app.elements.annotation import TextAnnotation

from studio.agents.tools._base import _get_state, _ok, _err, _building_summary


# ---------------------------------------------------------------------------
# Internal helper — dispatch a transformed copy back to the right collection
# ---------------------------------------------------------------------------

def _add_element_to_level(level: Level, element) -> Level:
    """Add *element* to the appropriate collection on *level* based on its type."""
    if isinstance(element, Room):
        return level.add_room(element)
    elif isinstance(element, Wall):
        return level.add_wall(element)
    elif isinstance(element, Column):
        return level.add_column(element)
    elif isinstance(element, Furniture):
        return level.add_furniture(element)
    elif isinstance(element, Beam):
        return level.add_beam(element)
    elif isinstance(element, Slab):
        return level.add_slab(element)
    elif isinstance(element, Ramp):
        return level.add_ramp(element)
    elif isinstance(element, Staircase):
        return level.add_staircase(element)
    elif isinstance(element, TextAnnotation):
        return level.add_text_annotation(element)
    else:
        raise ValueError(f"Unsupported element type for copy/transform: {type(element).__name__}")


# ---------------------------------------------------------------------------
# Read-only context tools (used by all agents)
# ---------------------------------------------------------------------------

@tool("get_building_context")
def get_building_context(session_id: str) -> str:
    """Return a compact summary of the current building state.

    Use this first before making any design decisions to understand the current
    state: number of levels, rooms, areas, and element counts.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with building summary statistics.
    """
    try:
        state = _get_state(session_id)
        return _ok(state.building.to_agent_context())
    except Exception as e:
        return _err(str(e))


@tool("get_building_detailed_context")
def get_building_detailed_context(
    session_id: str,
    level_index: Optional[int] = None,
    include_walls: bool = True,
    include_furniture: bool = True,
    include_columns: bool = True,
) -> str:
    """Return a detailed spatial summary of the current building state.

    Includes per-room centroids, bounding boxes, full wall geometry (start/end
    points, facing direction), column info, and land/site data if available.
    Use this when you need precise spatial information for design decisions.

    Tip: pass level_index to scope the response to one floor and reduce token
    usage. Pass include_furniture=False or include_columns=False to further
    narrow the response when those element types are not needed.

    Args:
        session_id: The active session identifier.
        level_index: If provided, return detailed data only for this floor.
        include_walls: Set False to omit wall geometry (saves tokens).
        include_furniture: Set False to omit furniture entries.
        include_columns: Set False to omit column entries.

    Returns:
        JSON with detailed per-level, per-room, per-element spatial data
        including wall start/end coordinates and facing directions.
    """
    try:
        state = _get_state(session_id)
        return _ok(state.building.to_detailed_agent_context(
            level_index=level_index,
            include_walls=include_walls,
            include_furniture=include_furniture,
            include_columns=include_columns,
        ))
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Level management
# ---------------------------------------------------------------------------

@tool("add_level")
def add_level(
    session_id: str,
    level_index: int,
    elevation_m: float,
    floor_height_m: float,
    name: str = "",
) -> str:
    """Add a new floor level to the building.

    Use this to create the building's floor structure before adding rooms and walls.
    Level index 0 = ground floor; negative = basement; positive = upper floors.

    Args:
        session_id: The active session identifier.
        level_index: Floor number (0=ground, -1=basement, 1=first upper floor, etc.).
        elevation_m: Height of this floor's slab above site datum in meters.
        floor_height_m: Floor-to-ceiling height in meters (typically 2.7–4.0m).
        name: Human-readable label e.g. "Ground Floor", "Level 2".

    Returns:
        JSON with status and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = Level(
            index=level_index,
            elevation=elevation_m,
            floor_height=floor_height_m,
            name=name,
        )
        new_building = state.building.add_level(level)
        state.update(new_building)
        return _ok({
            "message": f"Level {level_index} ('{name or f'Level {level_index}'}') added at elevation {elevation_m}m.",
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Room management
# ---------------------------------------------------------------------------

@tool("add_room")
def add_room(
    session_id: str,
    level_index: int,
    name: str,
    program: str,
    boundary_points: str,
) -> str:
    """Add a room to a building level.

    Rooms define the primary spatial units of the floorplan. Each room has an
    outer boundary polygon and a program type (bedroom, living, kitchen, etc.).

    Args:
        session_id: The active session identifier.
        level_index: Which floor to add the room to (must already exist).
        name: Human-readable room name e.g. "Master Bedroom".
        program: Space program type: "bedroom", "living", "kitchen", "bathroom",
                 "corridor", "office", "lobby", "utility", "storage", "staircase",
                 "dining", "study", "garage", "terrace", or any custom string.
        boundary_points: JSON array of [x, y] pairs defining the room polygon in
                         meters (WORLD coordinates, Y-up). Must be at least 3 points.
                         Example: "[[0,0],[4,0],[4,5],[0,5]]"

    Returns:
        JSON with status and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist. Create it first with add_level.")

        pts_raw = json.loads(boundary_points)
        if len(pts_raw) < 3:
            return _err("boundary_points must have at least 3 points.")

        exterior = tuple(Point2D(x=float(p[0]), y=float(p[1]), crs=WORLD) for p in pts_raw)
        polygon = Polygon2D(exterior=exterior, crs=WORLD)
        room = Room(
            boundary=polygon,
            name=name,
            program=program,
            level_index=level_index,
        )
        new_level = level.add_room(room)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"Room '{name}' ({program}, {room.area:.1f}m²) added to level {level_index}.",
            "room_id": str(room.id),
            "area_m2": round(room.area, 2),
            "building": _building_summary(state),
        })
    except json.JSONDecodeError:
        return _err("boundary_points must be a valid JSON array of [x, y] pairs.")
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Wall management
# ---------------------------------------------------------------------------

@tool("add_wall")
def add_wall(
    session_id: str,
    level_index: int,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    thickness_m: float = 0.2,
    height_m: float = 3.0,
    wall_type: str = "exterior",
) -> str:
    """Add a straight wall to a building level.

    Walls define the physical enclosure of spaces. They run from point (x1,y1)
    to (x2,y2) in WORLD coordinates (meters, Y-up).

    Args:
        session_id: The active session identifier.
        level_index: Which floor to add the wall to.
        x1, y1: Start point in meters.
        x2, y2: End point in meters.
        thickness_m: Wall thickness in meters (default 0.2m = 200mm).
        height_m: Wall height in meters (default 3.0m).
        wall_type: "exterior", "interior", "partition", "curtain", or "retaining".

    Returns:
        JSON with status, wall_id, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        from archit_app import WallType
        wtype_map = {
            "exterior": WallType.EXTERIOR,
            "interior": WallType.INTERIOR,
            "partition": WallType.PARTITION,
            "curtain": WallType.CURTAIN,
            "retaining": WallType.RETAINING,
        }
        wtype = wtype_map.get(wall_type.lower(), WallType.EXTERIOR)

        wall = Wall.straight(x1, y1, x2, y2, thickness=thickness_m, height=height_m, wall_type=wtype)
        new_level = level.add_wall(wall)
        new_building = state.building.add_level(new_level)
        state.update(new_building)

        length = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        return _ok({
            "message": f"{wall_type.capitalize()} wall ({length:.2f}m long, {thickness_m}m thick) added to level {level_index}.",
            "wall_id": str(wall.id),
            "length_m": round(length, 3),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Opening (door/window)
# ---------------------------------------------------------------------------

@tool("add_opening_to_wall")
def add_opening_to_wall(
    session_id: str,
    level_index: int,
    wall_id: str,
    kind: str = "door",
    width_m: float = 0.9,
    height_m: float = 2.1,
    sill_height_m: float = 0.0,
    position_along_wall: float = 0.5,
) -> str:
    """Add a door or window opening to an existing wall.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the wall.
        wall_id: UUID string of the target wall (from get_building_detailed_context).
        kind: "door", "window", "sliding_door", "garage_door", or "skylight".
        width_m: Opening width in meters (doors: 0.8–1.2, windows: 0.6–2.4).
        height_m: Opening height in meters (doors: 2.0–2.4, windows: 0.6–1.8).
        sill_height_m: Height of the bottom of the opening from floor (0 for doors).
        position_along_wall: Fractional position along the wall length (0.0–1.0).

    Returns:
        JSON with status and updated building summary.
    """
    try:
        import uuid
        from archit_app import OpeningKind

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        target_wall_id = uuid.UUID(wall_id)
        wall = next((w for w in level.walls if w.id == target_wall_id), None)
        if wall is None:
            return _err(f"Wall {wall_id} not found on level {level_index}.")

        kind_map = {
            "door": OpeningKind.DOOR,
            "window": OpeningKind.WINDOW,
            "sliding_door": OpeningKind.SLIDING_DOOR,
            "garage_door": OpeningKind.GARAGE_DOOR,
            "skylight": OpeningKind.SKYLIGHT,
        }
        ok_kind = kind_map.get(kind.lower(), OpeningKind.DOOR)

        opening = Opening(
            kind=ok_kind,
            width=width_m,
            height=height_m,
            sill_height=sill_height_m,
            position_along_wall=position_along_wall,
        )
        new_wall = wall.add_opening(opening)
        new_level = level.replace_element(target_wall_id, new_wall)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"{kind.capitalize()} ({width_m}m × {height_m}m) added to wall {wall_id[:8]}…",
            "opening_id": str(opening.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Staircase
# ---------------------------------------------------------------------------

@tool("add_staircase")
def add_staircase(
    session_id: str,
    level_index: int,
    x: float,
    y: float,
    width_m: float = 1.2,
    length_m: float = 3.0,
    staircase_type: str = "straight",
    bottom_level_index: Optional[int] = None,
    top_level_index: Optional[int] = None,
) -> str:
    """Add a staircase connecting two floor levels.

    Args:
        session_id: The active session identifier.
        level_index: Floor to place the staircase on (typically the lower level).
        x, y: Position of the staircase bottom-left corner in meters.
        width_m: Stair width in meters (minimum 1.0m, recommended 1.2m+).
        length_m: Stair run length in meters.
        staircase_type: "straight", "l_shaped", or "spiral".
        bottom_level_index: Lower floor index this staircase connects to.
        top_level_index: Upper floor index this staircase connects to.

    Returns:
        JSON with status, staircase_id, and updated building summary.
    """
    try:
        from archit_app import StaircaseType, Point2D, WORLD

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        stype_map = {
            "straight": StaircaseType.STRAIGHT,
            "l_shaped": StaircaseType.L_SHAPED,
            "spiral": StaircaseType.SPIRAL,
        }
        stype = stype_map.get(staircase_type.lower(), StaircaseType.STRAIGHT)

        stair = Staircase(
            origin=Point2D(x=x, y=y, crs=WORLD),
            width=width_m,
            length=length_m,
            stair_type=stype,
            bottom_level_index=bottom_level_index,
            top_level_index=top_level_index,
        )
        new_level = level.add_staircase(stair)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"{staircase_type.capitalize()} staircase ({width_m}m wide) added to level {level_index}.",
            "staircase_id": str(stair.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Element removal
# ---------------------------------------------------------------------------

@tool("remove_element")
def remove_element(session_id: str, level_index: int, element_id: str) -> str:
    """Remove any element (room, wall, column, staircase, etc.) from a level.

    Use this to correct design mistakes or refine the layout.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the element.
        element_id: UUID string of the element to remove.

    Returns:
        JSON with status and updated building summary.
    """
    try:
        import uuid
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")
        eid = uuid.UUID(element_id)
        new_level = level.remove_element(eid)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"Element {element_id[:8]}… removed from level {level_index}.",
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Metadata
# ---------------------------------------------------------------------------

@tool("update_building_metadata")
def update_building_metadata(
    session_id: str,
    name: str = "",
    project_number: str = "",
    architect: str = "",
    client: str = "",
    date: str = "",
) -> str:
    """Update the building's metadata fields.

    Call this at the start of a project to set the building name and details,
    or whenever the user provides updated project information.

    Args:
        session_id: The active session identifier.
        name: Project/building name.
        project_number: Internal project reference number.
        architect: Lead architect name.
        client: Client name.
        date: Project date (ISO 8601: YYYY-MM-DD).

    Returns:
        JSON with status and updated building summary.
    """
    try:
        state = _get_state(session_id)
        kwargs = {k: v for k, v in {
            "name": name, "project_number": project_number,
            "architect": architect, "client": client, "date": date,
        }.items() if v}
        new_building = state.building.with_metadata(**kwargs)
        state.update(new_building)
        return _ok({
            "message": f"Building metadata updated: {kwargs}",
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# History
# ---------------------------------------------------------------------------

@tool("undo_last_change")
def undo_last_change(session_id: str) -> str:
    """Undo the most recent change to the building.

    Use this when the user asks to undo, revert, or go back.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with status and updated building summary.
    """
    try:
        state = _get_state(session_id)
        if not state.can_undo:
            return _err("Nothing to undo — already at the earliest state.")
        state.undo()
        return _ok({
            "message": "Undo successful.",
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("redo_last_change")
def redo_last_change(session_id: str) -> str:
    """Redo a previously undone change.

    Use this when the user asks to redo or restore a change.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with status and updated building summary.
    """
    try:
        state = _get_state(session_id)
        if not state.can_redo:
            return _err("Nothing to redo — already at the latest state.")
        state.redo()
        return _ok({
            "message": "Redo successful.",
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


# ---------------------------------------------------------------------------
# Element transform tools
# ---------------------------------------------------------------------------

@tool("copy_element_to")
def copy_element_to(
    session_id: str,
    level_index: int,
    element_id: str,
    dx_m: float = 0.0,
    dy_m: float = 0.0,
) -> str:
    """Copy an existing element to a new position offset by (dx_m, dy_m).

    Creates an identical copy of any element (room, wall, column, furniture,
    etc.) displaced by the given X and Y offsets in meters. The original
    element is preserved. Useful for duplicating furniture layouts, repeating
    structural bays, or copying rooms to adjacent positions.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the source element.
        element_id: UUID of the element to copy (from get_building_detailed_context).
        dx_m: Displacement in the +X direction in meters.
        dy_m: Displacement in the +Y direction in meters.

    Returns:
        JSON with status, the new element's UUID, and updated building summary.
    """
    try:
        import uuid as _uuid
        from archit_app.elements.transform_utils import copy_element

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        eid = _uuid.UUID(element_id)
        source = level.get_element_by_id(eid)
        if source is None:
            return _err(f"Element {element_id} not found on level {level_index}.")

        copied = copy_element(source, dx=dx_m, dy=dy_m)
        new_level = _add_element_to_level(level, copied)
        new_building = state.building.add_level(new_level)
        state.update(new_building, label=f"Copy {type(source).__name__} by ({dx_m},{dy_m})m")

        return _ok({
            "message": f"{type(source).__name__} copied {dx_m}m in X and {dy_m}m in Y.",
            "new_element_id": str(copied.id),
            "source_element_id": element_id,
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("mirror_element_tool")
def mirror_element_tool(
    session_id: str,
    level_index: int,
    element_id: str,
    axis_x: Optional[float] = None,
    axis_y: Optional[float] = None,
) -> str:
    """Create a mirrored copy of an element across a vertical or horizontal axis.

    Reflects the element across either a vertical line (x = axis_x) or a
    horizontal line (y = axis_y). Exactly one of axis_x or axis_y must be
    provided. The original element is preserved. Useful for symmetric layouts,
    mirroring apartment wings, or reflecting furniture arrangements.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the source element.
        element_id: UUID of the element to mirror.
        axis_x: X-coordinate of the vertical mirror axis (mirror across x = axis_x).
        axis_y: Y-coordinate of the horizontal mirror axis (mirror across y = axis_y).

    Returns:
        JSON with status, the new element's UUID, and updated building summary.
    """
    try:
        import uuid as _uuid
        from archit_app.elements.transform_utils import mirror_element

        if (axis_x is None) == (axis_y is None):
            return _err("Provide exactly one of axis_x or axis_y.")

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        eid = _uuid.UUID(element_id)
        source = level.get_element_by_id(eid)
        if source is None:
            return _err(f"Element {element_id} not found on level {level_index}.")

        mirrored = mirror_element(source, axis_x=axis_x, axis_y=axis_y)
        new_level = _add_element_to_level(level, mirrored)
        new_building = state.building.add_level(new_level)
        axis_desc = f"x={axis_x}" if axis_x is not None else f"y={axis_y}"
        state.update(new_building, label=f"Mirror {type(source).__name__} across {axis_desc}")

        return _ok({
            "message": f"{type(source).__name__} mirrored across {axis_desc}.",
            "new_element_id": str(mirrored.id),
            "source_element_id": element_id,
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("add_rooms_batch")
def add_rooms_batch(session_id: str, level_index: int, rooms_json: str) -> str:
    """Add multiple rooms to a level in a single operation.

    Equivalent to calling add_room N times but uses a single immutable update,
    reducing tool-call round-trips and LLM token usage for large floor plans.

    Args:
        session_id: The active session identifier.
        level_index: Floor to add rooms to (must already exist).
        rooms_json: JSON array of room objects, each with keys:
            - ``name`` (str): Room name e.g. "Living Room".
            - ``program`` (str): Space type e.g. "bedroom", "living", "kitchen".
            - ``boundary_points`` (list): Array of [x, y] pairs in meters.
            Example:
            [
              {"name":"Living","program":"living","boundary_points":[[0,0],[5,0],[5,4],[0,4]]},
              {"name":"Kitchen","program":"kitchen","boundary_points":[[5,0],[9,0],[9,4],[5,4]]}
            ]

    Returns:
        JSON with status, list of created room IDs, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist. Create it first with add_level.")

        rooms_data = json.loads(rooms_json)
        if not isinstance(rooms_data, list) or len(rooms_data) == 0:
            return _err("rooms_json must be a non-empty JSON array of room objects.")

        new_rooms: list[Room] = []
        for i, rd in enumerate(rooms_data):
            pts_raw = rd.get("boundary_points", [])
            if len(pts_raw) < 3:
                return _err(f"Room {i} '{rd.get('name', '')}': boundary_points needs at least 3 points.")
            exterior = tuple(Point2D(x=float(p[0]), y=float(p[1]), crs=WORLD) for p in pts_raw)
            polygon = Polygon2D(exterior=exterior, crs=WORLD)
            new_rooms.append(Room(
                boundary=polygon,
                name=rd.get("name", f"Room {i}"),
                program=rd.get("program", ""),
                level_index=level_index,
            ))

        new_level = level.add_rooms(new_rooms)
        new_building = state.building.add_level(new_level)
        state.update(new_building, label=f"Add {len(new_rooms)} rooms to level {level_index}")
        return _ok({
            "message": f"{len(new_rooms)} room(s) added to level {level_index}.",
            "room_ids": [str(r.id) for r in new_rooms],
            "rooms_added": [{"id": str(r.id), "name": r.name, "program": r.program, "area_m2": round(r.area, 2)} for r in new_rooms],
            "building": _building_summary(state),
        })
    except json.JSONDecodeError as e:
        return _err(f"rooms_json is not valid JSON: {e}")
    except Exception as e:
        return _err(str(e))


@tool("add_walls_batch")
def add_walls_batch(session_id: str, level_index: int, walls_json: str) -> str:
    """Add multiple walls to a level in a single operation.

    Equivalent to calling add_wall N times but uses a single immutable update,
    reducing tool-call round-trips for full-perimeter wall placement.

    Args:
        session_id: The active session identifier.
        level_index: Floor to add walls to (must already exist).
        walls_json: JSON array of wall objects, each with keys:
            - ``x1``, ``y1`` (float): Start point in meters.
            - ``x2``, ``y2`` (float): End point in meters.
            - ``thickness_m`` (float, optional): Wall thickness, default 0.2.
            - ``height_m`` (float, optional): Wall height, default 3.0.
            - ``wall_type`` (str, optional): "exterior"/"interior"/"partition", default "exterior".
            Example:
            [
              {"x1":0,"y1":0,"x2":10,"y2":0,"wall_type":"exterior"},
              {"x1":10,"y1":0,"x2":10,"y2":8,"wall_type":"exterior"}
            ]

    Returns:
        JSON with status, list of created wall IDs, and updated building summary.
    """
    try:
        from archit_app import WallType

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        walls_data = json.loads(walls_json)
        if not isinstance(walls_data, list) or len(walls_data) == 0:
            return _err("walls_json must be a non-empty JSON array of wall objects.")

        wtype_map = {
            "exterior": WallType.EXTERIOR, "interior": WallType.INTERIOR,
            "partition": WallType.PARTITION, "curtain": WallType.CURTAIN,
            "retaining": WallType.RETAINING,
        }

        new_walls: list[Wall] = []
        for i, wd in enumerate(walls_data):
            try:
                x1, y1, x2, y2 = float(wd["x1"]), float(wd["y1"]), float(wd["x2"]), float(wd["y2"])
            except KeyError as k:
                return _err(f"Wall {i} missing required key: {k}.")
            thickness = float(wd.get("thickness_m", 0.2))
            height = float(wd.get("height_m", 3.0))
            wtype = wtype_map.get(str(wd.get("wall_type", "exterior")).lower(), WallType.EXTERIOR)
            new_walls.append(Wall.straight(x1, y1, x2, y2, thickness=thickness, height=height, wall_type=wtype))

        new_level = level.add_walls(new_walls)
        new_building = state.building.add_level(new_level)
        state.update(new_building, label=f"Add {len(new_walls)} walls to level {level_index}")
        return _ok({
            "message": f"{len(new_walls)} wall(s) added to level {level_index}.",
            "wall_ids": [str(w.id) for w in new_walls],
            "building": _building_summary(state),
        })
    except json.JSONDecodeError as e:
        return _err(f"walls_json is not valid JSON: {e}")
    except Exception as e:
        return _err(str(e))


@tool("array_element_tool")
def array_element_tool(
    session_id: str,
    level_index: int,
    element_id: str,
    count: int = 2,
    dx_m: float = 0.0,
    dy_m: float = 0.0,
) -> str:
    """Create a linear array of copies of an element with a repeating offset.

    Produces *count* copies of the element where each copy is offset by
    (dx_m, dy_m) relative to the previous one. The first copy is at the
    original position (offset 0). Useful for repeating columns along a grid
    line, arraying furniture modules, or creating repetitive structural bays.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the source element.
        element_id: UUID of the element to array.
        count: Total number of elements to create (including the one at offset 0).
               Must be at least 2 to produce any new elements.
        dx_m: X-step between each copy in meters.
        dy_m: Y-step between each copy in meters.

    Returns:
        JSON with status, list of new element UUIDs, and updated building summary.
    """
    try:
        import uuid as _uuid
        from archit_app.elements.transform_utils import array_element

        if count < 2:
            return _err("count must be at least 2 to create new copies.")

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        eid = _uuid.UUID(element_id)
        source = level.get_element_by_id(eid)
        if source is None:
            return _err(f"Element {element_id} not found on level {level_index}.")

        # array_element returns `count` items starting at offset 0 — skip index 0
        # (the original) and only add the new copies (indices 1..count-1)
        all_copies = array_element(source, count=count, dx=dx_m, dy=dy_m)
        new_copies = all_copies[1:]  # exclude the copy at offset (0,0)

        new_level = level
        for copy in new_copies:
            new_level = _add_element_to_level(new_level, copy)

        new_building = state.building.add_level(new_level)
        state.update(
            new_building,
            label=f"Array {type(source).__name__} × {count} at ({dx_m},{dy_m})m",
        )

        return _ok({
            "message": (
                f"{len(new_copies)} copies of {type(source).__name__} created "
                f"with step ({dx_m}m, {dy_m}m)."
            ),
            "new_element_ids": [str(c.id) for c in new_copies],
            "source_element_id": element_id,
            "count_added": len(new_copies),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))
