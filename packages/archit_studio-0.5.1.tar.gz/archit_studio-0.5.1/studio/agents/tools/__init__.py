"""CrewAI tools for each specialist agent."""

from studio.agents.tools.building_tools import (
    get_building_context,
    get_building_detailed_context,
    add_level,
    add_room,
    remove_element,
    add_wall,
    add_opening_to_wall,
    add_staircase,
    update_building_metadata,
    undo_last_change,
    redo_last_change,
)
from studio.agents.tools.structural_tools import (
    add_column,
    add_beam,
    add_slab,
    add_elevator,
    set_structural_grid,
    add_ramp,
)
from studio.agents.tools.analysis_tools import (
    run_compliance_check,
    run_area_report,
    run_egress_report,
    run_accessibility_check,
    run_daylight_report,
    run_adjacency_analysis,
    set_land,
)
from studio.agents.tools.interior_tools import (
    add_furniture,
    add_text_annotation,
    set_room_material,
)
from studio.agents.tools.io_tools import (
    export_level_svg,
    export_building_json,
    validate_building,
    save_session,
    load_session_tool,
    list_saved_sessions,
)

__all__ = [
    # building
    "get_building_context",
    "get_building_detailed_context",
    "add_level",
    "add_room",
    "remove_element",
    "add_wall",
    "add_opening_to_wall",
    "add_staircase",
    "update_building_metadata",
    "undo_last_change",
    "redo_last_change",
    # structural
    "add_column",
    "add_beam",
    "add_slab",
    "add_elevator",
    "set_structural_grid",
    "add_ramp",
    # analysis
    "run_compliance_check",
    "run_area_report",
    "run_egress_report",
    "run_accessibility_check",
    "run_daylight_report",
    "run_adjacency_analysis",
    "set_land",
    # interior
    "add_furniture",
    "add_text_annotation",
    "set_room_material",
    # io
    "export_level_svg",
    "export_building_json",
    "validate_building",
    "save_session",
    "load_session_tool",
    "list_saved_sessions",
]
