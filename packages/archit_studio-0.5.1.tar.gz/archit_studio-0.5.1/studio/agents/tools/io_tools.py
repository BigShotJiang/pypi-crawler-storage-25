"""
I/O tools — SVG export, JSON export, session persistence, building validation.
"""

import json
from pathlib import Path
from typing import Optional

from crewai.tools import tool

from archit_app.io import building_to_json, save_level_svg, save_building_svgs

from studio.agents.tools._base import _get_state, _ok, _err, _building_summary
from studio.config import get_data_dir


@tool("export_level_svg")
def export_level_svg(session_id: str, level_index: int = 0) -> str:
    """Export a building level as an SVG floorplan drawing.

    The SVG file is saved to the session data directory and its path is
    returned so the UI can display it inline. Call this after significant
    design changes to let the user review the current layout visually.

    Args:
        session_id: The active session identifier.
        level_index: Which floor to render (default: 0 = ground floor).

    Returns:
        JSON with status and the absolute path to the saved SVG file.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        out_dir = get_data_dir() / session_id
        out_dir.mkdir(parents=True, exist_ok=True)
        svg_path = out_dir / f"level_{level_index}.svg"

        save_level_svg(level, str(svg_path))
        return _ok({
            "message": f"Level {level_index} exported as SVG.",
            "svg_path": str(svg_path),
            "level_index": level_index,
        })
    except Exception as e:
        return _err(str(e))


@tool("export_building_json")
def export_building_json(session_id: str) -> str:
    """Export the entire building as a canonical JSON file.

    The JSON is fully round-trippable — it can be reloaded via load_session_tool
    or imported into other archit-app tools. Use this to give the user a
    downloadable copy of their project.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with status and the absolute path to the saved JSON file.
    """
    try:
        state = _get_state(session_id)
        out_dir = get_data_dir() / session_id
        out_dir.mkdir(parents=True, exist_ok=True)
        json_path = out_dir / "building.json"

        json_str = building_to_json(state.building)
        json_path.write_text(json_str, encoding="utf-8")
        return _ok({
            "message": "Building exported as JSON.",
            "json_path": str(json_path),
        })
    except Exception as e:
        return _err(str(e))


@tool("validate_building")
def validate_building(session_id: str) -> str:
    """Run the built-in building validation checks.

    Detects common modelling errors: duplicate level indices, zero-area rooms,
    zero-length walls, broken staircase level links, and more.

    Use this before exporting or presenting a design to ensure it is
    internally consistent.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with validation report including errors and warnings.
    """
    try:
        state = _get_state(session_id)
        report = state.building.validate()
        issues = [
            {
                "severity": issue.severity,
                "element_id": str(issue.element_id) if issue.element_id else None,
                "message": issue.message,
            }
            for issue in report.issues
        ]
        errors = [i for i in issues if i["severity"] == "error"]
        warnings = [i for i in issues if i["severity"] == "warning"]
        return _ok({
            "has_errors": report.has_errors,
            "has_warnings": report.has_warnings,
            "error_count": len(errors),
            "warning_count": len(warnings),
            "errors": errors,
            "warnings": warnings,
            "summary": (
                "Building is valid — no issues found."
                if not report.issues
                else f"{len(errors)} error(s), {len(warnings)} warning(s) found."
            ),
        })
    except Exception as e:
        return _err(str(e))


@tool("save_session")
def save_session(session_id: str) -> str:
    """Save the current session to disk (data/sessions/<session_id>.json).

    This persists the current building state so it can be reloaded in a future
    conversation. Always save before the user ends a session.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with status and the path where the session was saved.
    """
    try:
        state = _get_state(session_id)
        path = state.save()
        return _ok({
            "message": f"Session saved to {path}.",
            "path": str(path),
        })
    except Exception as e:
        return _err(str(e))


@tool("load_session_tool")
def load_session_tool(session_id: str, target_session_id: str) -> str:
    """Load a previously saved session from disk into the current session.

    This replaces the current building with a saved one. Use with care —
    always confirm with the user before overwriting unsaved work.

    Args:
        session_id: The current active session identifier.
        target_session_id: The session_id of the saved session to load.

    Returns:
        JSON with status and loaded building summary.
    """
    try:
        from studio.state.session import SessionState, set_session, get_session

        loaded = SessionState.load(target_session_id)
        # Transplant the loaded building into the current session
        current = _get_state(session_id)
        current.update(loaded.building, label=f"Loaded from session {target_session_id}")
        return _ok({
            "message": f"Session '{target_session_id}' loaded successfully.",
            "building": _building_summary(current),
        })
    except FileNotFoundError:
        return _err(f"No saved session found with id '{target_session_id}'.")
    except Exception as e:
        return _err(str(e))


@tool("export_building_pdf")
def export_building_pdf(
    session_id: str,
    paper_size: str = "A3",
    level_index: Optional[int] = None,
) -> str:
    """Export the building as a multi-page PDF presentation drawing.

    Each floor level is rendered as one page. Produces vector-quality output
    suitable for client presentations, printing, and design reviews.
    Requires the 'pdf' optional dependency (pip install archit-app[pdf]).

    Args:
        session_id: The active session identifier.
        paper_size: Page size — "A4", "A3", or "A2" (default "A3").
        level_index: If provided, export only this floor. If None, export all floors.

    Returns:
        JSON with status and the absolute path to the saved PDF file.
    """
    try:
        from archit_app.io.pdf import save_level_pdf, save_building_pdf

        state = _get_state(session_id)
        out_dir = get_data_dir() / session_id
        out_dir.mkdir(parents=True, exist_ok=True)

        if level_index is not None:
            level = state.building.get_level(level_index)
            if level is None:
                return _err(f"Level {level_index} does not exist.")
            pdf_path = out_dir / f"level_{level_index}.pdf"
            save_level_pdf(level, str(pdf_path), paper_size=paper_size)
            message = f"Level {level_index} exported as PDF ({paper_size})."
        else:
            pdf_path = out_dir / "building.pdf"
            save_building_pdf(state.building, str(pdf_path), paper_size=paper_size)
            level_count = len(state.building.levels)
            message = f"All {level_count} floor(s) exported as multi-page PDF ({paper_size})."

        return _ok({
            "message": message,
            "pdf_path": str(pdf_path),
            "paper_size": paper_size,
        })
    except ImportError:
        return _err(
            "PDF export requires the 'pdf' extra: pip install archit-app[pdf]  (needs reportlab)"
        )
    except Exception as e:
        return _err(str(e))


@tool("export_level_geojson")
def export_level_geojson(session_id: str, level_index: int = 0) -> str:
    """Export a building level as a GeoJSON FeatureCollection.

    Rooms, walls, columns, and openings are exported as GeoJSON features with
    their element type, program, and ID as properties. Useful for loading
    floorplans into GIS tools (QGIS, Mapbox, Leaflet) and for spatial analysis
    workflows that operate on standard geographic data formats.

    Args:
        session_id: The active session identifier.
        level_index: Which floor to export (default: 0 = ground floor).

    Returns:
        JSON with status and the absolute path to the saved GeoJSON file.
    """
    try:
        from archit_app.io.geojson import level_to_geojson_str

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        out_dir = get_data_dir() / session_id
        out_dir.mkdir(parents=True, exist_ok=True)
        geojson_path = out_dir / f"level_{level_index}.geojson"

        geojson_str = level_to_geojson_str(level)
        geojson_path.write_text(geojson_str, encoding="utf-8")

        return _ok({
            "message": f"Level {level_index} exported as GeoJSON.",
            "geojson_path": str(geojson_path),
            "level_index": level_index,
        })
    except Exception as e:
        return _err(str(e))


@tool("list_saved_sessions")
def list_saved_sessions(session_id: str) -> str:
    """List all previously saved sessions available on disk.

    Use this to help the user find and load a previous project.

    Args:
        session_id: The active session identifier (used for auth context).

    Returns:
        JSON with a list of saved session summaries.
    """
    try:
        from studio.state.session import SessionState
        sessions = SessionState.list_saved()
        return _ok({
            "saved_sessions": sessions,
            "count": len(sessions),
        })
    except Exception as e:
        return _err(str(e))
