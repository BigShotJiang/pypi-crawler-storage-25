"""
Interior design tools — furniture placement, materials, and text annotations.
"""

from typing import Optional

from crewai.tools import tool

from archit_app import (
    Furniture, FurnitureCategory,
    TextAnnotation, Point2D, WORLD,
    Material, MaterialCategory,
)

from studio.agents.tools._base import _get_state, _ok, _err, _building_summary

# Map of user-friendly furniture type strings to factory methods on Furniture
_FURNITURE_FACTORIES = {
    "sofa":           "sofa",
    "armchair":       "armchair",
    "dining_table":   "dining_table",
    "desk":           "desk",
    "double_bed":     "double_bed",
    "single_bed":     "single_bed",
    "bunk_bed":       "bunk_bed",
    "wardrobe":       "wardrobe",
    "bookshelf":      "bookshelf",
    "tv_unit":        "tv_unit",
    "coffee_table":   "coffee_table",
    "kitchen_island": "kitchen_island",
    "toilet":         "toilet",
    "sink":           "sink",
    "bathtub":        "bathtub",
    "shower":         "shower",
    "washing_machine":"washing_machine",
    "refrigerator":   "refrigerator",
}


@tool("add_furniture")
def add_furniture(
    session_id: str,
    level_index: int,
    furniture_type: str,
    x: float,
    y: float,
    rotation_deg: float = 0.0,
    width_m: Optional[float] = None,
    depth_m: Optional[float] = None,
    name: str = "",
) -> str:
    """Place a furniture item on a building level.

    Furniture items have standard sizes by default but can be overridden.
    Position (x, y) is the centre of the item in WORLD coordinates.

    Available furniture types:
        sofa, armchair, dining_table, desk, double_bed, single_bed, bunk_bed,
        wardrobe, bookshelf, tv_unit, coffee_table, kitchen_island,
        toilet, sink, bathtub, shower, washing_machine, refrigerator

    Args:
        session_id: The active session identifier.
        level_index: Floor to place the furniture on.
        furniture_type: One of the available furniture type strings above.
        x, y: Centre position in meters.
        rotation_deg: Rotation angle in degrees (clockwise from Y-up).
        width_m: Override default width (optional).
        depth_m: Override default depth (optional).
        name: Custom label for this item (optional).

    Returns:
        JSON with status, furniture_id, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        factory_name = _FURNITURE_FACTORIES.get(furniture_type.lower())
        if factory_name is None:
            valid = ", ".join(sorted(_FURNITURE_FACTORIES.keys()))
            return _err(f"Unknown furniture type '{furniture_type}'. Valid types: {valid}")

        factory = getattr(Furniture, factory_name, None)
        if factory is None:
            return _err(f"Furniture factory '{factory_name}' not found in archit-app.")

        # Build kwargs — only pass overrides if provided
        kwargs: dict = {"x": x, "y": y, "rotation": rotation_deg}
        if width_m is not None:
            kwargs["width"] = width_m
        if depth_m is not None:
            kwargs["depth"] = depth_m
        if name:
            kwargs["name"] = name

        item = factory(**kwargs)
        new_level = level.add_furniture(item)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"{furniture_type.replace('_',' ').title()} placed at ({x:.1f},{y:.1f}) on level {level_index}.",
            "furniture_id": str(item.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("add_text_annotation")
def add_text_annotation(
    session_id: str,
    level_index: int,
    text: str,
    x: float,
    y: float,
    font_size: float = 0.3,
    rotation_deg: float = 0.0,
) -> str:
    """Add a text annotation label to a building level.

    Use annotations to label rooms, add notes, indicate dimensions verbally,
    or mark special areas on the floorplan.

    Args:
        session_id: The active session identifier.
        level_index: Floor to add the annotation to.
        text: The annotation text string.
        x, y: Anchor point of the text in meters.
        font_size: Approximate text height in meters (default 0.3m = 300mm).
        rotation_deg: Text rotation in degrees.

    Returns:
        JSON with status, annotation_id, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        annotation = TextAnnotation(
            anchor=Point2D(x=x, y=y, crs=WORLD),
            text=text,
            font_size=font_size,
            rotation=rotation_deg,
        )
        new_level = level.add_text_annotation(annotation)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"Annotation '{text}' added at ({x:.1f},{y:.1f}) on level {level_index}.",
            "annotation_id": str(annotation.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("set_room_material")
def set_room_material(
    session_id: str,
    level_index: int,
    room_id: str,
    material_name: str,
    material_category: str = "finish",
    color_hex: str = "#CCCCCC",
) -> str:
    """Assign a material to a room's boundary for rendering and specification.

    This tags the room with material information used in export and visualisation.
    Material category determines how it is rendered and scheduled.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the room.
        room_id: UUID string of the target room.
        material_name: Material name e.g. "Oak Parquet", "Polished Concrete", "Ceramic Tile".
        material_category: "finish", "structure", "insulation", "cladding", "glazing".
        color_hex: Hex colour string for rendering (e.g. "#D4A96A" for warm oak).

    Returns:
        JSON with status and updated building summary.
    """
    try:
        import uuid

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        rid = uuid.UUID(room_id)
        room = next((r for r in level.rooms if r.id == rid), None)
        if room is None:
            return _err(f"Room {room_id} not found on level {level_index}.")

        cat_map = {
            "finish": MaterialCategory.FINISH,
            "structure": MaterialCategory.STRUCTURE,
            "insulation": MaterialCategory.INSULATION,
            "cladding": MaterialCategory.CLADDING,
            "glazing": MaterialCategory.GLAZING,
        }
        cat = cat_map.get(material_category.lower(), MaterialCategory.FINISH)

        material = Material(name=material_name, category=cat, color=color_hex)
        new_room = room.model_copy(update={"material": material})
        new_level = level.replace_element(rid, new_room)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"Material '{material_name}' ({material_category}) assigned to room '{room.name or room_id[:8]}'.",
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))
