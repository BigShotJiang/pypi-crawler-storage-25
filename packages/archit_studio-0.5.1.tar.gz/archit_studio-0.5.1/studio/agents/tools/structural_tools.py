"""
Structural engineering tools — columns, beams, slabs, ramps, elevators, grid.
"""

from crewai.tools import tool

from archit_app import (
    Column, ColumnShape, Beam, BeamSection, Slab, SlabType,
    Ramp, RampType, Elevator, ElevatorDoor,
    StructuralGrid, GridAxis, Point2D, WORLD,
)

from studio.agents.tools._base import _get_state, _ok, _err, _building_summary


@tool("add_column")
def add_column(
    session_id: str,
    level_index: int,
    x: float,
    y: float,
    width_m: float = 0.3,
    depth_m: float = 0.3,
    height_m: float = 3.0,
    shape: str = "rectangular",
) -> str:
    """Add a structural column to a building level.

    Columns are primary vertical load-bearing elements. Place them at structural
    grid intersections or where loads need to be transferred.

    Args:
        session_id: The active session identifier.
        level_index: Floor to place the column on.
        x, y: Centre point of the column in meters.
        width_m: Column width (x-direction) in meters.
        depth_m: Column depth (y-direction) in meters.
        height_m: Column height in meters (typically equals floor height).
        shape: "rectangular" or "circular".

    Returns:
        JSON with status, column_id, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        shape_map = {"rectangular": ColumnShape.RECTANGULAR, "circular": ColumnShape.CIRCULAR}
        col_shape = shape_map.get(shape.lower(), ColumnShape.RECTANGULAR)

        col = Column(
            origin=Point2D(x=x, y=y, crs=WORLD),
            width=width_m,
            depth=depth_m,
            height=height_m,
            shape=col_shape,
        )
        new_level = level.add_column(col)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"{shape.capitalize()} column ({width_m}×{depth_m}m) added at ({x},{y}) on level {level_index}.",
            "column_id": str(col.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("add_beam")
def add_beam(
    session_id: str,
    level_index: int,
    x1: float,
    y1: float,
    x2: float,
    y2: float,
    width_m: float = 0.3,
    depth_m: float = 0.5,
    section: str = "rectangular",
) -> str:
    """Add a structural beam spanning between two points on a level.

    Beams are horizontal load-bearing elements that typically span between
    columns or walls. Position them at ceiling level (not floor level).

    Args:
        session_id: The active session identifier.
        level_index: Floor to place the beam on.
        x1, y1: Start point in meters.
        x2, y2: End point in meters.
        width_m: Beam width in meters (horizontal dimension).
        depth_m: Beam depth in meters (vertical dimension, i.e. beam height).
        section: "rectangular", "i_beam", "t_beam", or "circular".

    Returns:
        JSON with status, beam_id, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        section_map = {
            "rectangular": BeamSection.RECTANGULAR,
            "i_beam": BeamSection.I_BEAM,
            "t_beam": BeamSection.T_BEAM,
            "circular": BeamSection.CIRCULAR,
        }
        bs = section_map.get(section.lower(), BeamSection.RECTANGULAR)

        beam = Beam(
            start=Point2D(x=x1, y=y1, crs=WORLD),
            end=Point2D(x=x2, y=y2, crs=WORLD),
            width=width_m,
            depth=depth_m,
            section=bs,
        )
        new_level = level.add_beam(beam)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        length = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        return _ok({
            "message": f"{section.capitalize()} beam ({length:.2f}m span, {width_m}×{depth_m}m) added to level {level_index}.",
            "beam_id": str(beam.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("add_slab")
def add_slab(
    session_id: str,
    level_index: int,
    boundary_points: str,
    thickness_m: float = 0.2,
    slab_type: str = "floor",
) -> str:
    """Add a structural slab (floor or roof) to a building level.

    Slabs define horizontal floor/roof plates. They should typically cover the
    full floor plan bounded by walls.

    Args:
        session_id: The active session identifier.
        level_index: Floor to place the slab on.
        boundary_points: JSON array of [x, y] pairs defining the slab polygon.
        thickness_m: Slab thickness in meters (typical: 0.15–0.30m).
        slab_type: "floor", "roof", "basement_floor", or "podium".

    Returns:
        JSON with status, slab_id, and updated building summary.
    """
    try:
        import json
        from archit_app import Polygon2D

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        pts_raw = json.loads(boundary_points)
        exterior = tuple(Point2D(x=float(p[0]), y=float(p[1]), crs=WORLD) for p in pts_raw)
        polygon = Polygon2D(exterior=exterior, crs=WORLD)

        stype_map = {
            "floor": SlabType.FLOOR,
            "roof": SlabType.ROOF,
            "basement_floor": SlabType.BASEMENT_FLOOR,
            "podium": SlabType.PODIUM,
        }
        stype = stype_map.get(slab_type.lower(), SlabType.FLOOR)

        slab = Slab(boundary=polygon, thickness=thickness_m, slab_type=stype)
        new_level = level.add_slab(slab)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        return _ok({
            "message": f"{slab_type.capitalize()} slab ({thickness_m}m thick, {polygon.area:.1f}m²) added to level {level_index}.",
            "slab_id": str(slab.id),
            "area_m2": round(polygon.area, 2),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("add_ramp")
def add_ramp(
    session_id: str,
    level_index: int,
    x: float,
    y: float,
    width_m: float = 1.5,
    length_m: float = 5.0,
    slope_angle_deg: float = 5.0,
    ramp_type: str = "accessible",
) -> str:
    """Add a ramp to a building level.

    Accessible ramps must meet building code: max slope 1:20 (2.86°) for
    wheelchair access, or up to 1:12 (4.76°) with handrails.

    Args:
        session_id: The active session identifier.
        level_index: Floor to place the ramp on.
        x, y: Bottom-left origin of the ramp in meters.
        width_m: Ramp width in meters (minimum 1.5m for accessible).
        length_m: Ramp horizontal run in meters.
        slope_angle_deg: Slope angle in degrees (2.86° = 1:20 accessible, max 5° general).
        ramp_type: "accessible", "service", or "parking".

    Returns:
        JSON with status, ramp_id, and updated building summary.
    """
    try:
        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        rtype_map = {
            "accessible": RampType.ACCESSIBLE,
            "service": RampType.SERVICE,
            "parking": RampType.PARKING,
        }
        rtype = rtype_map.get(ramp_type.lower(), RampType.ACCESSIBLE)

        ramp = Ramp(
            origin=Point2D(x=x, y=y, crs=WORLD),
            width=width_m,
            length=length_m,
            slope_angle=slope_angle_deg,
            ramp_type=rtype,
        )
        new_level = level.add_ramp(ramp)
        new_building = state.building.add_level(new_level)
        state.update(new_building)
        rise = length_m * __import__("math").tan(__import__("math").radians(slope_angle_deg))
        return _ok({
            "message": f"{ramp_type.capitalize()} ramp ({width_m}m wide, {length_m}m run, {rise:.2f}m rise) added to level {level_index}.",
            "ramp_id": str(ramp.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("add_elevator")
def add_elevator(
    session_id: str,
    x: float,
    y: float,
    cab_width_m: float = 1.1,
    cab_depth_m: float = 1.4,
    served_level_indices: str = "[0, 1]",
) -> str:
    """Add an elevator serving multiple building levels.

    Elevators are building-level elements (not floor-specific). They appear on
    all served floors automatically.

    Args:
        session_id: The active session identifier.
        x, y: Position of the elevator shaft centre in meters.
        cab_width_m: Internal cab width in meters (min 1.1m for accessible).
        cab_depth_m: Internal cab depth in meters (min 1.4m for accessible).
        served_level_indices: JSON array of floor indices the elevator serves.
                              Example: "[0, 1, 2, 3]"

    Returns:
        JSON with status, elevator_id, and updated building summary.
    """
    try:
        import json
        state = _get_state(session_id)
        levels = json.loads(served_level_indices)

        elev = Elevator(
            origin=Point2D(x=x, y=y, crs=WORLD),
            cab_width=cab_width_m,
            cab_depth=cab_depth_m,
            served_levels=tuple(int(li) for li in levels),
        )
        new_building = state.building.add_elevator(elev)
        state.update(new_building)
        return _ok({
            "message": f"Elevator ({cab_width_m}×{cab_depth_m}m cab) serving levels {levels} added.",
            "elevator_id": str(elev.id),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("set_structural_grid")
def set_structural_grid(
    session_id: str,
    x_spacing: str = "[0, 5, 10]",
    y_spacing: str = "[0, 5, 10]",
    x_labels: str = '["A","B","C"]',
    y_labels: str = '["1","2","3"]',
) -> str:
    """Define the building's structural grid.

    A structural grid establishes regular column/beam spacing and aids in
    coordinating element placement. Set this early in the design process.

    Args:
        session_id: The active session identifier.
        x_spacing: JSON array of X-axis positions in meters. Example: "[0,5,10,15]"
        y_spacing: JSON array of Y-axis positions in meters. Example: "[0,4,8]"
        x_labels: JSON array of labels for X axes. Example: '["A","B","C","D"]'
        y_labels: JSON array of labels for Y axes. Example: '["1","2","3"]'

    Returns:
        JSON with status and updated building summary.
    """
    try:
        import json
        state = _get_state(session_id)

        xs = json.loads(x_spacing)
        ys = json.loads(y_spacing)
        xl = json.loads(x_labels)
        yl = json.loads(y_labels)

        x_axes = tuple(GridAxis(label=lbl, position=float(pos)) for lbl, pos in zip(xl, xs))
        y_axes = tuple(GridAxis(label=lbl, position=float(pos)) for lbl, pos in zip(yl, ys))
        grid = StructuralGrid(x_axes=x_axes, y_axes=y_axes)

        new_building = state.building.with_grid(grid)
        state.update(new_building)
        return _ok({
            "message": f"Structural grid set: {len(x_axes)} X-axes ({xl}), {len(y_axes)} Y-axes ({yl}).",
            "x_axes": xl,
            "y_axes": yl,
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))
