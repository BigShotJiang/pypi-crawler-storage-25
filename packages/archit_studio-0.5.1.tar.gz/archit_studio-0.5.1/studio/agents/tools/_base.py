"""Shared helpers for all tool modules."""

from __future__ import annotations

import json
from typing import Any

from studio.state.session import get_session, SessionState


def _get_state(session_id: str) -> SessionState:
    """Retrieve a session or raise a clear error."""
    state = get_session(session_id)
    if state is None:
        raise ValueError(
            f"No active session '{session_id}'. "
            "Start a new chat or load an existing session first."
        )
    return state


def _ok(payload: Any) -> str:
    """Serialise a success result to JSON string (what CrewAI tools must return)."""
    return json.dumps({"status": "ok", **payload} if isinstance(payload, dict) else {"status": "ok", "result": payload})


def _err(message: str) -> str:
    return json.dumps({"status": "error", "message": message})


def _building_summary(state: SessionState) -> dict:
    """Compact building summary appended to every successful tool response."""
    ctx = state.building.to_agent_context()
    return {
        "building_name": ctx.get("building_name", ""),
        "total_levels": ctx.get("total_levels", 0),
        "total_rooms": ctx.get("total_rooms", 0),
        "gross_floor_area_m2": ctx.get("gross_floor_area_m2", 0.0),
        "can_undo": state.can_undo,
        "can_redo": state.can_redo,
    }
