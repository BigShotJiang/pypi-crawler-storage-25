"""
Analysis tools — compliance, area program, egress, accessibility, daylighting,
room adjacency, and site/land configuration.
"""

import json
from typing import Optional

from crewai.tools import tool

from studio.agents.tools._base import _get_state, _ok, _err, _building_summary


@tool("set_land")
def set_land(
    session_id: str,
    boundary_points: str = "",
    address: str = "",
    north_angle_deg: float = 0.0,
    elevation_m: float = 0.0,
    zone_code: str = "",
    max_height_m: Optional[float] = None,
    max_far: Optional[float] = None,
    max_lot_coverage: Optional[float] = None,
    setback_front_m: float = 0.0,
    setback_back_m: float = 0.0,
    setback_left_m: float = 0.0,
    setback_right_m: float = 0.0,
) -> str:
    """Define or update the building's land parcel and zoning information.

    Set the site context before running any compliance checks. Zoning parameters
    are optional — provide only what is known.

    Args:
        session_id: The active session identifier.
        boundary_points: JSON array of [x, y] pairs defining the lot boundary in
                         meters (WORLD coordinates). Leave empty if boundary unknown.
        address: Street address of the parcel.
        north_angle_deg: Degrees clockwise from world +Y to geographic north (0 = Y is north).
        elevation_m: Mean site elevation above sea level in meters.
        zone_code: Zoning designation e.g. "R-2", "C-1", "MU".
        max_height_m: Maximum allowed building height in meters (None = unknown).
        max_far: Floor Area Ratio limit (None = unknown).
        max_lot_coverage: Max fraction of lot that may be covered (0–1, None = unknown).
        setback_front_m: Front setback in meters.
        setback_back_m: Back setback in meters.
        setback_left_m: Left setback in meters.
        setback_right_m: Right setback in meters.

    Returns:
        JSON with status and site context summary.
    """
    try:
        from archit_app import Land, Setbacks, ZoningInfo, Polygon2D, Point2D, WORLD

        state = _get_state(session_id)

        land_kwargs = {
            "north_angle": north_angle_deg,
            "address": address,
            "elevation_m": elevation_m,
        }

        if boundary_points:
            pts_raw = json.loads(boundary_points)
            exterior = tuple(Point2D(x=float(p[0]), y=float(p[1]), crs=WORLD) for p in pts_raw)
            polygon = Polygon2D(exterior=exterior, crs=WORLD)
            land = Land.from_polygon(polygon, **land_kwargs)
        else:
            land = Land.minimal(**land_kwargs)

        setbacks = Setbacks(
            front=setback_front_m, back=setback_back_m,
            left=setback_left_m, right=setback_right_m,
        )
        land = land.with_setbacks(setbacks)

        if zone_code or max_height_m or max_far or max_lot_coverage:
            zoning = ZoningInfo(
                zone_code=zone_code,
                max_height_m=max_height_m,
                max_far=max_far,
                max_lot_coverage=max_lot_coverage,
            )
            land = land.with_zoning(zoning)

        new_building = state.building.with_land(land)
        state.update(new_building)
        return _ok({
            "message": f"Land parcel set. Area: {land.area_m2:.1f}m² | Zone: {zone_code or 'unzoned'}",
            "land_context": land.to_agent_context(),
            "building": _building_summary(state),
        })
    except Exception as e:
        return _err(str(e))


@tool("run_compliance_check")
def run_compliance_check(session_id: str) -> str:
    """Run a full zoning and regulatory compliance check on the building.

    Checks FAR, lot coverage, building height, footprint within lot boundary,
    and footprint within setback envelope. Requires land/site to be set first.

    Args:
        session_id: The active session identifier.

    Returns:
        JSON with compliance report including pass/fail status for each check.
    """
    try:
        from archit_app.analysis.compliance import check_compliance

        state = _get_state(session_id)
        if state.building.land is None:
            return _err("No land/site set. Use set_land first to define the parcel and zoning.")

        report = check_compliance(state.building, state.building.land)
        checks = [
            {
                "name": c.name,
                "actual": c.actual,
                "limit": c.limit,
                "unit": c.unit,
                "compliant": c.compliant,
                "note": c.note,
            }
            for c in report.checks
        ]
        return _ok({
            "overall_compliant": report.compliant,
            "failed_checks": [c["name"] for c in checks if not c["compliant"]],
            "checks": checks,
            "summary": report.summary(),
        })
    except Exception as e:
        return _err(str(e))


@tool("run_area_report")
def run_area_report(session_id: str, level_index: Optional[int] = None) -> str:
    """Generate a space program area report for the building or a specific level.

    Reports net and gross areas per program type (bedroom, living, kitchen, etc.),
    helping to verify whether the design meets the client's area targets.

    Args:
        session_id: The active session identifier.
        level_index: If provided, report only for this floor. If None, report all floors.

    Returns:
        JSON with area breakdown by program type and totals.
    """
    try:
        from archit_app.analysis.area import area_report, area_by_program

        state = _get_state(session_id)
        building = state.building

        if level_index is not None:
            level = building.get_level(level_index)
            if level is None:
                return _err(f"Level {level_index} does not exist.")
            levels = [level]
        else:
            levels = list(building.levels)

        program_areas: dict[str, float] = {}
        total_net = 0.0
        total_gross = 0.0

        for lv in levels:
            for room in lv.rooms:
                prog = room.program or "unassigned"
                program_areas[prog] = round(program_areas.get(prog, 0.0) + room.area, 3)
                total_net += room.area
                total_gross += room.gross_area

        rooms_list = []
        for lv in levels:
            for r in lv.rooms:
                rooms_list.append({
                    "level": lv.index,
                    "name": r.name,
                    "program": r.program,
                    "net_area_m2": round(r.area, 2),
                    "gross_area_m2": round(r.gross_area, 2),
                })

        return _ok({
            "area_by_program_m2": {k: round(v, 2) for k, v in program_areas.items()},
            "total_net_area_m2": round(total_net, 2),
            "total_gross_area_m2": round(total_gross, 2),
            "room_count": len(rooms_list),
            "rooms": rooms_list,
        })
    except Exception as e:
        return _err(str(e))


@tool("run_egress_report")
def run_egress_report(session_id: str, level_index: int = 0) -> str:
    """Analyse egress paths and emergency exit compliance for a building level.

    Exits are auto-detected from rooms whose program is "lobby", "corridor",
    "staircase", "entry", etc. Results include per-room compliance status,
    egress distance, and actionable fix suggestions for non-compliant rooms.

    Args:
        session_id: The active session identifier.
        level_index: Floor to analyse (default: ground floor, index 0).

    Returns:
        JSON with overall_compliant flag, failed_rooms list, and full per-room
        breakdown including issue description and suggested_fix for each failure.
    """
    try:
        from archit_app.analysis.circulation import egress_report

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")
        if not level.rooms:
            return _ok({"level_index": level_index, "overall_compliant": True, "rooms": [], "message": "No rooms on this level."})

        report = egress_report(level)  # exit_ids auto-detected
        return _ok({"level_index": level_index, **report})
    except ImportError:
        return _err("Egress analysis requires the 'analysis' extra: pip install archit-app[analysis]")
    except Exception as e:
        return _err(str(e))


@tool("run_accessibility_check")
def run_accessibility_check(session_id: str, level_index: int = 0) -> str:
    """Check accessibility compliance (door widths, corridor widths, ramps, turning radius).

    Returns structured findings with element_id, severity, and detail for each
    check, so the architect agent can directly act on specific failures.

    Args:
        session_id: The active session identifier.
        level_index: Floor to check (default: ground floor).

    Returns:
        JSON with accessible flag, structured checks list (each with name, passed,
        severity, detail, element_id), and a failures list for quick scanning.
    """
    try:
        from archit_app.analysis.accessibility import check_accessibility

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        report = check_accessibility(level)
        checks_out = [
            {
                "name": c.name,
                "passed": c.passed,
                "severity": c.severity,
                "detail": c.detail,
                "element_id": str(c.element_id) if c.element_id else None,
            }
            for c in report.checks
        ]
        return _ok({
            "level_index": level_index,
            "accessible": report.passed_all,
            "checks": checks_out,
            "failures": [c for c in checks_out if not c["passed"]],
            "summary": report.summary(),
        })
    except Exception as e:
        return _err(str(e))


@tool("run_daylight_report")
def run_daylight_report(
    session_id: str,
    level_index: int = 0,
    north_angle_deg: float = 0.0,
) -> str:
    """Analyse natural daylighting for each room on a building level.

    Reports window-to-floor area ratios, solar orientation, compliance status,
    and actionable fix suggestions for rooms that fail the 10% WFR minimum.

    Args:
        session_id: The active session identifier.
        level_index: Floor to analyse.
        north_angle_deg: Degrees clockwise from world +Y to geographic north.
                         Uses land.north_angle if the building has a land set.

    Returns:
        JSON with per-room daylighting analysis including compliant flag,
        issue description, and suggested_fix for each non-compliant room.
    """
    try:
        from archit_app.analysis.daylighting import daylight_report

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        actual_north = (
            state.building.land.north_angle
            if state.building.land is not None
            else north_angle_deg
        )
        results = daylight_report(level, north_angle_deg=actual_north)
        rooms_out = [
            {
                "room_id": str(r.room_id),
                "room_name": r.room_name,
                "program": r.program,
                "floor_area_m2": r.floor_area_m2,
                "window_area_m2": r.window_area_m2,
                "window_to_floor_ratio": r.window_to_floor_ratio,
                "avg_solar_score": r.avg_solar_score,
                "compliant": r.compliant,
                "issue": r.issue,
                "suggested_fix": r.suggested_fix,
                "windows": [
                    {
                        "opening_id": str(w.opening_id),
                        "cardinal": w.cardinal,
                        "solar_score": w.solar_score,
                        "width_m": w.width_m,
                    }
                    for w in r.windows
                ],
            }
            for r in results
        ]
        overall = all(r["compliant"] for r in rooms_out)
        return _ok({
            "level_index": level_index,
            "north_angle_deg": actual_north,
            "overall_compliant": overall,
            "failed_rooms": [r for r in rooms_out if not r["compliant"]],
            "rooms": rooms_out,
        })
    except Exception as e:
        return _err(str(e))


@tool("run_visibility_check")
def run_visibility_check(
    session_id: str,
    level_index: int = 0,
    viewpoint_x: float = 0.0,
    viewpoint_y: float = 0.0,
    max_range_m: float = 30.0,
    resolution: int = 180,
) -> str:
    """Compute the visibility (isovist) from a point on a building level.

    Ray-casts from the viewpoint to find all areas visible from that position,
    accounting for walls as opaque obstacles. Useful for privacy analysis
    (can this seating area see into bedrooms?), sightline verification (does
    the entrance desk have line-of-sight to the lobby?), and open-plan
    space planning.

    Args:
        session_id: The active session identifier.
        level_index: Floor to analyse.
        viewpoint_x: X coordinate of the observer in meters.
        viewpoint_y: Y coordinate of the observer in meters.
        max_range_m: Maximum sightline distance in meters (default 30m).
        resolution: Number of rays to cast — higher = smoother but slower
                    (180 is fast and sufficient for design decisions).

    Returns:
        JSON with visible area in m², the room the viewpoint is in (if any),
        and a human-readable sightline summary.
    """
    try:
        from archit_app.analysis.visibility import compute_isovist
        from archit_app.geometry.point import Point2D
        from archit_app.geometry.crs import WORLD

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        viewpoint = Point2D(x=viewpoint_x, y=viewpoint_y, crs=WORLD)
        result = compute_isovist(viewpoint, level, resolution=resolution, max_range=max_range_m)

        if result is None:
            return _ok({
                "level_index": level_index,
                "viewpoint": {"x": viewpoint_x, "y": viewpoint_y},
                "visible_area_m2": 0.0,
                "room_id": None,
                "message": "No wall obstacles found — level may be empty.",
            })

        room_name = None
        if result.room_id is not None:
            room = next((r for r in level.rooms if r.id == result.room_id), None)
            room_name = room.name or room.program if room else None

        return _ok({
            "level_index": level_index,
            "viewpoint": {"x": viewpoint_x, "y": viewpoint_y},
            "visible_area_m2": result.area_m2,
            "max_range_m": max_range_m,
            "room_id": str(result.room_id) if result.room_id else None,
            "room_name": room_name,
            "message": (
                f"From ({viewpoint_x}, {viewpoint_y}) on level {level_index}, "
                f"{result.area_m2:.1f}m² is visible within {max_range_m}m."
                + (f" Viewpoint is inside '{room_name}'." if room_name else "")
            ),
        })
    except Exception as e:
        return _err(str(e))


@tool("run_adjacency_analysis")
def run_adjacency_analysis(session_id: str, level_index: int = 0) -> str:
    """Analyse room adjacency relationships on a building level.

    Determines which rooms share walls/boundaries (are adjacent), producing
    an adjacency graph useful for verifying spatial relationships meet the
    programme requirements (e.g., kitchen adjacent to dining, bedroom not
    adjacent to lobby).

    Args:
        session_id: The active session identifier.
        level_index: Floor to analyse.

    Returns:
        JSON with adjacency pairs and room relationship graph.
    """
    try:
        from archit_app.analysis.topology import build_adjacency_graph

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")
        if not level.rooms:
            return _ok({"level_index": level_index, "adjacency_pairs": [], "message": "No rooms on this level."})

        graph = build_adjacency_graph(level)

        adjacency_pairs = []
        room_lookup = {str(r.id): r.name or r.program for r in level.rooms}
        for edge in graph.edges():
            adjacency_pairs.append({
                "room_a_id": str(edge[0]),
                "room_a_name": room_lookup.get(str(edge[0]), str(edge[0])[:8]),
                "room_b_id": str(edge[1]),
                "room_b_name": room_lookup.get(str(edge[1]), str(edge[1])[:8]),
            })

        return _ok({
            "level_index": level_index,
            "room_count": len(level.rooms),
            "adjacency_pairs": adjacency_pairs,
            "total_adjacencies": len(adjacency_pairs),
        })
    except ImportError:
        return _err("Adjacency analysis requires the 'analysis' extra: pip install archit-app[analysis]")
    except Exception as e:
        return _err(str(e))


@tool("get_walls_for_room")
def get_walls_for_room(
    session_id: str,
    level_index: int,
    room_id: str,
    tolerance_m: float = 0.35,
) -> str:
    """Return all walls that form or closely border a specific room's boundary.

    Uses a spatial proximity query so the architect agent can quickly find the
    right wall IDs when adding openings (doors/windows) to a specific room,
    without manually searching coordinates.  Results include wall facing
    direction (N/S/E/W), start/end points, and opening count.

    Args:
        session_id: The active session identifier.
        level_index: Floor containing the room.
        room_id: UUID string of the target room (from get_building_detailed_context).
        tolerance_m: Proximity threshold in metres (default 0.35 m). Increase if
                     walls are not being detected due to thick wall offsets.

    Returns:
        JSON with a list of matching walls sorted exterior-first, each entry
        containing id, wall_type, facing, length_m, start, end, openings_count.
    """
    try:
        import uuid as _uuid

        state = _get_state(session_id)
        level = state.building.get_level(level_index)
        if level is None:
            return _err(f"Level {level_index} does not exist.")

        rid = _uuid.UUID(room_id)
        room = next((r for r in level.rooms if r.id == rid), None)
        if room is None:
            return _err(f"Room {room_id} not found on level {level_index}.")

        walls = level.walls_for_room(rid, tolerance_m=tolerance_m)

        walls_out = []
        for w in walls:
            sp = w.start_point
            ep = w.end_point
            entry = {
                "id": str(w.id),
                "wall_type": w.wall_type.value,
                "facing": w.facing_direction(),
                "length_m": round(w.length, 3),
                "openings_count": len(w.openings),
            }
            if sp:
                entry["start"] = {"x": sp[0], "y": sp[1]}
            if ep:
                entry["end"] = {"x": ep[0], "y": ep[1]}
            walls_out.append(entry)

        return _ok({
            "room_id": room_id,
            "room_name": room.name,
            "level_index": level_index,
            "wall_count": len(walls_out),
            "walls": walls_out,
        })
    except ImportError:
        return _err("walls_for_room requires Shapely: pip install shapely")
    except Exception as e:
        return _err(str(e))
