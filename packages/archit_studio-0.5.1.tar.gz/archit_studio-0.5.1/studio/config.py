"""
studio.config — application settings and model registry.

Settings are loaded from settings.toml (base), then .env / environment variables
(override).  Dynaconf handles the merge; all env vars must be prefixed STUDIO_.

Usage:
    from studio.config import settings, get_model_for_agent, SUPPORTED_MODELS
"""

from __future__ import annotations

from pathlib import Path

from dynaconf import Dynaconf

# ---------------------------------------------------------------------------
# Dynaconf instance
# ---------------------------------------------------------------------------

_settings_file = Path(__file__).parent.parent / "settings.toml"
_env_file = Path(__file__).parent.parent / ".env"

settings = Dynaconf(
    envvar_prefix="STUDIO",
    settings_files=[str(_settings_file)],
    load_dotenv=True,
    dotenv_path=str(_env_file) if _env_file.exists() else None,
)

# ---------------------------------------------------------------------------
# Supported model registry
# ---------------------------------------------------------------------------

DEFAULT_MODEL = "gpt-4o-mini"

# Resolved model IDs used by runner.py to route API calls.
# OpenAI models:    pass the model ID directly to AsyncOpenAI.
# Anthropic models: prefix with "anthropic/" — runner.py detects this prefix,
#                   strips it, and routes the call to AsyncAnthropic instead.
SUPPORTED_MODELS: dict[str, str] = {
    # GPT-4o family
    "gpt-4o-mini": "gpt-4o-mini",
    "gpt-4o":      "gpt-4o",
    # GPT-4.1 family
    "gpt-4.1-mini": "gpt-4.1-mini",
    "gpt-4.1":      "gpt-4.1",
    # GPT-5 family
    "gpt-5-mini": "gpt-5-mini",
    "gpt-5":      "gpt-5",
    # Reasoning models
    "o3-mini": "o3-mini",
    "o4-mini": "o4-mini",
    # Anthropic / Claude models
    "claude-3-5-haiku-20241022":  "anthropic/claude-3-5-haiku-20241022",
    "claude-3-5-sonnet-20241022": "anthropic/claude-3-5-sonnet-20241022",
    "claude-opus-4-5":            "anthropic/claude-opus-4-5",
}

# Human-readable labels shown in the UI settings panel
MODEL_LABELS: dict[str, str] = {
    "gpt-4o-mini":  "GPT-4o mini   (fast · recommended)",
    "gpt-4o":       "GPT-4o        (high quality)",
    "gpt-4.1-mini": "GPT-4.1 mini  (fast)",
    "gpt-4.1":      "GPT-4.1       (high quality)",
    "gpt-5-mini":   "GPT-5 mini    (next-gen · fast)",
    "gpt-5":        "GPT-5         (next-gen · flagship)",
    "o3-mini":      "o3-mini       (reasoning · fast)",
    "o4-mini":      "o4-mini       (reasoning · fast)",
    "claude-3-5-haiku-20241022":  "Claude 3.5 Haiku  (Anthropic · fast)",
    "claude-3-5-sonnet-20241022": "Claude 3.5 Sonnet (Anthropic · high quality)",
    "claude-opus-4-5":            "Claude Opus 4.5   (Anthropic · flagship)",
}


def get_model_for_agent(agent_name: str) -> str:
    """Return the OpenAI model ID for a named agent.

    Looks up [agents.<agent_name>.model] in settings, falls back to the
    top-level ``model`` setting, then falls back to DEFAULT_MODEL.
    """
    try:
        override = settings.get(f"agents.{agent_name}.model", "")
    except Exception:
        override = ""

    model_id = override or settings.get("model", DEFAULT_MODEL)
    return SUPPORTED_MODELS.get(model_id, model_id)


def get_default_model() -> str:
    """Return the OpenAI model ID for the default/global model."""
    model_id = settings.get("model", DEFAULT_MODEL)
    return SUPPORTED_MODELS.get(model_id, model_id)


def get_data_dir() -> Path:
    """Return the session data directory, creating it if necessary."""
    d = Path(settings.get("data_dir", "./data/sessions"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def is_verbose() -> bool:
    return bool(settings.get("verbose_agents", False))


def max_history() -> int:
    return int(settings.get("max_history", 50))
