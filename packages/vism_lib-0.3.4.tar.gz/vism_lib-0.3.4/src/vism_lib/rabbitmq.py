import asyncio
import json
import logging
from typing import Callable, Awaitable

import aio_pika
from aio_pika import Message
from aio_pika.abc import AbstractRobustConnection, AbstractIncomingMessage, AbstractRobustChannel
from aiormq import AMQPConnectionError

from vism_lib.config import RabbitMQConfig
from vism_lib.data.exchange import DataExchange, DataExchangeMessage, DataExchangeCSRMessage, DataExchangeCertMessage
from vism_lib.data.validation import DataValidationProtocol
from vism_lib.errors import RabbitMQError

type AsyncCallableExchange = Callable[[DataExchangeMessage], Awaitable]
type AsyncCallableExchangeCSR = Callable[[DataExchangeCSRMessage], Awaitable]
type AsyncCallableExchangeCert = Callable[[DataExchangeCertMessage], Awaitable]

shared_logger = logging.getLogger("vism_shared")

def rabbitmq_callback_decorator(original_function):
    def decorator(callback: AsyncCallableExchangeCSR | AsyncCallableExchangeCert):
        if not asyncio.iscoroutinefunction(callback):
            raise RabbitMQError(f"Invalid callback function: {callback.__name__}. Function is not async.")

        async def wrapper(message: AbstractIncomingMessage):
            message_body_dict = await original_function(message)

            exchange_message_class = callback.__annotations__.get('message', None)
            if not exchange_message_class:
                raise RabbitMQError(f"Invalid callback function: {callback.__name__}. Function does not have valid message arg annotation.")

            exchange_message = exchange_message_class(**message_body_dict)

            return await callback(exchange_message)

        return wrapper

    return decorator

class RabbitMQClient:

    def __init__(self, config: RabbitMQConfig):
        self.config = config

        self._connection: AbstractRobustConnection | None = None
        self._channel: AbstractRobustChannel | None = None

    async def connection(self) -> AbstractRobustConnection:
        if self._connection is None:
            self._connection = await self._new_connection()

        if self._connection.is_closed:
            await self._connection.reconnect()

        return self._connection

    async def channel(self) -> AbstractRobustChannel:
        connection = await self.connection()
        if self._channel is None:
            self._channel = await connection.channel(on_return_raises=True)

        if self._channel.is_closed:
            await self._channel.reopen()

        return self._channel

    async def close(self):
        if self._channel is not None and not self._channel.is_closed:
            await self._channel.close()

        if self._connection is not None and not self._connection.is_closed:
            await self._connection.close()

    async def _new_connection(self) -> AbstractRobustConnection:
        return await aio_pika.connect_robust(
            host=self.config.host,
            port=self.config.port,
            login=self.config.user,
            password=self.config.password,
            virtualhost=self.config.vhost,
            heartbeat=30,
        )

class RabbitMQExchange(DataExchange):

    def __init__(self, validation_module: DataValidationProtocol, *, config: RabbitMQConfig, rabbitmq_client: RabbitMQClient):
        shared_logger.debug("Initializing RabbitMQ module")

        self.config = config
        self.validation_module = validation_module
        self.rabbitmq_client = rabbitmq_client

    async def cleanup(self, full: bool = False):
        """Clean up RabbitMQ resources."""
        shared_logger.debug("Cleaning up RabbitMQ")
        if full:
            await self.rabbitmq_client.close()

    async def _send_message(self, message: DataExchangeMessage, exchange_name: str, message_type: str, routing_key: str = ""):
        shared_logger.info("Sending message to RabbitMQ exchange '%s'", exchange_name)

        data_json = message.to_json().encode("utf-8")
        message_signature = self.validation_module.sign(data_json)

        channel = await self.rabbitmq_client.channel()
        if not channel.is_initialized:
            await channel.initialize(timeout=30)

        exchange = await channel.get_exchange(exchange_name)
        rabbitmq_message: Message = Message(
            body=data_json,
            headers={
                "X-Vism-Message-Type": message_type,
                "X-Vism-Signature": message_signature.hex(),
                "Content-Type": "application/octet-stream",
            }
        )

        try:
            await exchange.publish(message=rabbitmq_message, routing_key=routing_key)
        except Exception as e:
            shared_logger.error(f"Failed to publish message: {e}")
            raise RuntimeError from e

    async def _consume(self, *, queue_name, retry_count: int = 0, callback: AsyncCallableExchangeCSR | AsyncCallableExchangeCert):
        shared_logger.info(f"Starting listening for messages from RabbitMQ queue '{queue_name}'")
        channel = await self.rabbitmq_client.channel()
        if not channel.is_initialized:
            await channel.initialize(timeout=30)

        await channel.set_qos(prefetch_count=1)
        queue = await channel.declare_queue(
            name=queue_name,
            passive=True,
            durable=True,
            robust=True,
        )

        try:
            decorated_callback = rabbitmq_callback_decorator(self._handle_message)(callback)
            await queue.consume(decorated_callback)
        except AMQPConnectionError:
            if retry_count >= self.config.max_retries:
                raise
            await asyncio.sleep(self.config.retry_delay_seconds)
            return await self._consume(queue_name=queue_name, retry_count=retry_count, callback=callback)

    async def send_message(self, message: DataExchangeMessage):
        if isinstance(message, DataExchangeCSRMessage):
            exchange = self.config.csr_exchange
            routing_key = self.config.csr_routing_key
            message_type = "csr"
        elif isinstance(message, DataExchangeCertMessage):
            exchange = self.config.cert_exchange
            routing_key = self.config.cert_routing_key
            message_type = "cert"
        else:
            raise RabbitMQError(f"Invalid message type: {type(message)}")

        await self._send_message(message, exchange, message_type, routing_key)

    async def receive_messages(self, message_class: type[DataExchangeMessage], callback: AsyncCallableExchange) -> None:
        if message_class == DataExchangeCSRMessage:
            await self._consume(queue_name=self.config.csr_queue, callback=callback)
        elif message_class == DataExchangeCertMessage:
            await self._consume(queue_name=self.config.cert_queue, callback=callback)

    async def _handle_message(self, message: AbstractIncomingMessage) -> dict:
        shared_logger.info("Received message from RabbitMQ.")
        async with message.process():
            message_type = message.headers.get("X-Vism-Message-Type", None)
            if message_type is None:
                raise RabbitMQError(f"No message type found in message headers: {message.headers}.")

            shared_logger.info("Processing message from RabbitMQ of type '%s'.", message_type)
            shared_logger.debug("Message body: %s | Signature: %s", message.body, message.headers['X-Vism-Signature'])

            signature = bytes.fromhex(message.headers['X-Vism-Signature'])
            if not self.validation_module.verify(message.body, signature):
                raise RabbitMQError('Invalid signature')

            return json.loads(message.body)
