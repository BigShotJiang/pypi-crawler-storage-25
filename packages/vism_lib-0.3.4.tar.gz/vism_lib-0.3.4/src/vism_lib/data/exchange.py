"""Data exchange module for inter-component communication."""

import json
from dataclasses import dataclass
from typing import Callable, Awaitable, Protocol
from vism_lib.data.validation import DataValidationProtocol

type AsyncCallableExchange = Callable[[DataExchangeMessage], Awaitable]
type AsyncCallableExchangeCSR = Callable[[DataExchangeCSRMessage], Awaitable]
type AsyncCallableExchangeCert = Callable[[DataExchangeCertMessage], Awaitable]


@dataclass
class DataExchangeMessage:
    """Base class for data exchange messages."""

    def to_json(self) -> str:
        """Convert message to JSON string."""
        raise NotImplementedError()


@dataclass
class DataExchangeCSRMessage(DataExchangeMessage):
    """Message containing Certificate Signing Request data."""

    csr_pem: str
    ca_name: str
    days: int
    module_args: dict
    order_id: str
    profile_name: str = None

    def to_json(self) -> str:
        """Convert CSR message to JSON string."""
        return json.dumps({
            "csr_pem": self.csr_pem,
            "ca_name": self.ca_name,
            "days": self.days,
            "module_args": self.module_args,
            "order_id": self.order_id,
        })


@dataclass
class DataExchangeCertMessage(DataExchangeMessage):
    """Message containing certificate chain data."""

    chain: str
    order_id: str
    ca_name: str
    days: int

    def to_json(self) -> str:
        """Convert certificate message to JSON string."""
        return json.dumps({
            "chain": self.chain,
            "order_id": self.order_id,
            "ca_name": self.ca_name,
            "days": self.days,
        })


class DataExchange(Protocol):
    """Abstract base class for data exchange implementations."""

    validation_module: DataValidationProtocol

    async def cleanup(self, full: bool = False) -> None:
        """Clean up resources used by the data exchange module."""
        ...

    async def send_message(self, message: DataExchangeMessage) -> None:
        """Send a data exchange message."""
        ...

    async def receive_messages(self, message_class: type[DataExchangeMessage], callback: AsyncCallableExchange) -> None:
        """Receive data exchange messages."""
