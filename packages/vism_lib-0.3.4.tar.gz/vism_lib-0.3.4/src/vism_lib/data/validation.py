"""Data validation and cryptography module interfaces."""
import hashlib
import hmac
from dataclasses import dataclass
from typing import Protocol

from yaml_dataclass import YamlConfigCached
from vism_lib.config import shared_logger
from vism_lib.errors import VismException


class DataError(VismException):
    """Exception raised for data validation/encryption errors."""


@dataclass
class DataModuleConfig:
    """Base configuration class for data modules."""


@dataclass
class DataConfig(YamlConfigCached):
    """Configuration class for data operations."""

class DataValidationProtocol(Protocol):
    """Protocol for data validation modules."""
    validation_key: str

    def sign(self, data: bytes) -> bytes:
        """Sign data using the module's validation key."""
        ...

    def verify(self, data: bytes, signature: bytes) -> bool:
        """Verify data signature using the module's validation key."""
        ...


class DataValidation:
    """Abstract base class for data validation and encryption modules."""

    def __init__(self, *, validation_key: str):
        shared_logger.debug("Initializing DataValidation module")
        self.validation_key = validation_key.encode("utf-8")

    def sign(self, data: bytes) -> bytes:
        """Sign data using the module's validation key."""
        return hmac.new(self.validation_key, data, hashlib.sha256).digest()

    def verify(self, data: bytes, signature: bytes) -> bool:
        """Verify data signature using the module's validation key."""
        data_signature = self.sign(data)
        return hmac.compare_digest(data_signature, signature)
