"""Base controller class for VISM components."""

import asyncio
from vism_lib.config import shared_logger, VismConfig
from vism_lib.logs import setup_logger

class Controller:
    """Base controller class for managing modules and configuration."""

    def __init__(self, config: VismConfig):
        self.config = config

        self.setup_logging()
        self.shutdown_event = asyncio.Event()

    def shutdown(self):
        shared_logger.info("Shutting down")
        self.shutdown_event.set()

    def setup_logging(self):
        """Set up logging configuration."""
        shared_logger.info("Setting up logging")
        setup_logger(self.config.logging)
