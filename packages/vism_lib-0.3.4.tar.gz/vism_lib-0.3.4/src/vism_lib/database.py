"""Shared database models and utilities for VISM components."""

import json
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Generator, Type
from uuid import UUID, uuid4
from sqlalchemy import Uuid, DateTime, Engine, event, LargeBinary, TypeDecorator, BigInteger
from sqlalchemy import ColumnExpressionArgument
from sqlalchemy.orm import (
    MappedAsDataclass,
    DeclarativeBase,
    Mapped,
    mapped_column,
    sessionmaker,
    Session
)
from vism_lib.config import shared_logger
from sqlalchemy.exc import OperationalError, StatementError
from sqlalchemy.orm.query import Query as _Query

from vism_lib.data.validation import DataValidationProtocol
from vism_lib.errors import VismDatabaseException


class TZDateTime(TypeDecorator):
    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is not None:
            if not value.tzinfo or value.tzinfo.utcoffset(value) is None:
                raise TypeError("tzinfo is required")
            value = value.astimezone(timezone.utc).replace(tzinfo=None)
        return value

    def process_result_value(self, value, dialect):
        if value is not None:
            value = value.replace(tzinfo=timezone.utc)
        return value

class Base(MappedAsDataclass, DeclarativeBase):
    """Base class for all database entities with common fields."""

    id: Mapped[UUID] = mapped_column(
        Uuid, primary_key=True, default_factory=uuid4, init=False
    )
    signature: Mapped[bytes] = mapped_column(
        LargeBinary, nullable=True, default=None, init=False
    )

    created_at: Mapped[datetime] = mapped_column(
        TZDateTime,
        default_factory=lambda: datetime.now(tz=timezone.utc),
        init=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        TZDateTime,
        default_factory=lambda: datetime.now(tz=timezone.utc),
        onupdate=lambda: datetime.now(tz=timezone.utc),
        init=False
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert entity to dictionary representation."""
        raise NotImplementedError()

class RetryingQuery(_Query):
    __max_retry_count__ = 3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def __iter__(self):
        attempts = 0
        while True:
            attempts += 1
            try:
                return super().__iter__()
            except OperationalError as ex:
                if "server closed the connection unexpectedly" not in str(ex):
                    raise
                if attempts <= self.__max_retry_count__:
                    continue
                else:
                    raise
            except StatementError as ex:
                if "reconnect until invalid transaction is rolled back" not in str(ex):
                    raise
                self.session.rollback()


class VismDatabase:
    """Database interface for VISM operations."""

    def __init__(self, engine: Engine, validation_module: DataValidationProtocol):
        shared_logger.debug("Initializing database")
        self.engine = engine
        self.validation_module = validation_module

        self.session_maker = sessionmaker(bind=self.engine, query_cls=RetryingQuery)

        self._create_tables()

    def clear_all_tables(self):
        shared_logger.critical("Clearing database of all tables.")
        with self._get_session() as session:
            for table in reversed(Base.metadata.sorted_tables):
                session.execute(table.delete())

            session.commit()

    def _validate_obj(self, obj: Base) -> bool:
        """Validate entity signature using validation module."""
        shared_logger.debug(f"Validating {obj.__class__.__name__} {obj.id} signature.")

        # just incase signing has failed for some reason
        if obj.signature is None:
            return True

        # backwards compatibility for old objects
        if b'+|+' not in obj.signature:
            return True

        obj_keys_signature, obj_data_signature = obj.signature.split(b'+|+')

        keys_signature = self.validation_module.sign(
            json.dumps([*obj.to_dict().keys()]).encode("utf-8")
        )

        # If the keys have changed validation is no longer possible
        if keys_signature != obj_keys_signature:
            return True

        data_signature = self.validation_module.sign(
            json.dumps(obj.to_dict()).encode("utf-8")
        )
        combined_signature = keys_signature + b"+|+" + data_signature

        return combined_signature == obj.signature

    def _sign_obj(self, obj: Base) -> bytes:
        """Sign entity data using validation module."""
        shared_logger.debug(f"Signing {obj.__class__.__name__} {obj.id}")

        keys_signature = self.validation_module.sign(
            json.dumps([*obj.to_dict().keys()]).encode("utf-8")
        )

        data_signature = self.validation_module.sign(
            json.dumps(obj.to_dict()).encode("utf-8")
        )

        combined_signature = keys_signature + b"+|+" + data_signature

        return combined_signature

    def get(
            self,
            obj_type: Type[Base],
            *criterion: ColumnExpressionArgument[bool],
            multiple: bool = False
    ):
        """
        Get entity or entities from database by criteria.

        Args:
            obj_type: Type of entity to retrieve
            *criterion: Filter criteria
            multiple: Whether to return multiple results

        Returns:
            Single entity, list of entities, or None
        """
        with self._get_session() as session:
            objs: list[Base] = session.query(obj_type).filter(*criterion).all()
            for obj in objs:
                if not self._validate_obj(obj):
                    raise VismDatabaseException("Object has invalid signature")
            if not multiple:
                if len(objs) == 0:
                    return None
                if len(objs) > 1:
                    raise VismDatabaseException("Multiple objects found.")
                return objs[0]
            return objs

    def save_to_db(self, obj: Base):
        """
        Save entity to database with signature.

        Args:
            obj: Entity to save

        Returns:
            Saved entity with updated signature
        """
        with self._get_session() as session:
            merged = session.merge(obj)
            session.flush()
            merged.signature = self._sign_obj(merged)
            merged = session.merge(merged)
            session.flush()
            shared_logger.debug(f"Saved {merged.__class__.__name__} {merged.id} to database")
            return merged

    def _create_tables(self):
        """Create all database tables."""
        Base.metadata.create_all(self.engine)

    @contextmanager
    def _get_session(self) -> Generator[Session, Any, None]:
        """Get database session with automatic commit/rollback."""
        session = self.session_maker(expire_on_commit=False)
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
