"""Shared configuration classes for VISM components."""

import logging
from dataclasses import field
from pydantic import field_validator
from pydantic.dataclasses import dataclass
from yaml_dataclass import YamlConfigCached

from vism_lib.logs import LoggingConfig

shared_logger = logging.getLogger("vism_shared")

@dataclass
class DatabaseConfig:
    """Database connection configuration."""

    data_validation_key: str
    host: str
    port: int
    database: str
    username: str
    password: str
    driver: str = "postgresql+psycopg2"

    @field_validator("host")
    @classmethod
    def host_must_be_valid(cls, v):
        if not v:
            raise ValueError("database host can not be empty.")

        return v

    @field_validator("port")
    @classmethod
    def port_must_be_valid(cls, v):
        """Validate that port is in valid range."""
        if v < 1 or v > 65535:
            raise ValueError("Port must be between 1 and 65535")
        return v

@dataclass
class Security:
    """Security configuration including validation and encryption."""

    data_validation_key: str
    chroot_base_dir: str = None

@dataclass
class S3Config:
    """Configuration for s3."""

    bucket: str
    endpoint: str
    access_key: str
    secret_key: str
    region: str = ""


@dataclass
class RabbitMQConfig:
    """Configuration for RabbitMQ."""

    leader_queue: str
    host: str
    user: str
    password: str
    vhost: str
    port: int

    csr_routing_key: str
    cert_routing_key: str
    csr_queue: str
    cert_queue: str
    csr_exchange: str
    cert_exchange: str

    max_retries: int = 5
    retry_delay_seconds: int = 1


@dataclass
class VismConfig(YamlConfigCached):
    """Base configuration class for VISM components."""

    rabbitmq: RabbitMQConfig = None
    security: Security = field(default_factory=Security)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    database: DatabaseConfig = None
    s3: S3Config = None
