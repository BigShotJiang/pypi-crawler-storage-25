"""Build standalone mcp-audit binaries via PyInstaller."""

import platform
import subprocess
import sys
from pathlib import Path


def build() -> None:
    """Produce a single-file mcp-audit binary for the current platform."""
    root = Path(__file__).parent
    system = platform.system().lower()  # darwin, linux, windows
    arch = platform.machine().lower()  # arm64, x86_64

    name = f"mcp-audit-{system}-{arch}"
    if system == "windows":
        name += ".exe"

    # Data files that must be bundled: (source_path, dest_dir_inside_bundle)
    datas = [
        (str(root / "src" / "mcp_audit" / "data"), "mcp_audit/data"),
        (str(root / "registry" / "known-servers.json"), "registry"),
        (str(root / "registry" / "known-extension-vulns.json"), "registry"),
        (str(root / "rules" / "community"), "rules/community"),
        (str(root / "semgrep-rules"), "semgrep-rules"),
    ]
    datas_args: list[str] = []
    for src, dst in datas:
        datas_args.extend(["--add-data", f"{src}:{dst}"])

    cmd = [
        sys.executable,
        "-m",
        "PyInstaller",
        "--onefile",
        "--name",
        name,
        "--clean",
        "--noconfirm",
        # Hidden imports that PyInstaller static analysis may miss
        "--hidden-import", "mcp_audit.analyzers.poisoning",
        "--hidden-import", "mcp_audit.analyzers.credentials",
        "--hidden-import", "mcp_audit.analyzers.transport",
        "--hidden-import", "mcp_audit.analyzers.supply_chain",
        "--hidden-import", "mcp_audit.analyzers.rug_pull",
        "--hidden-import", "mcp_audit.analyzers.toxic_flow",
        "--hidden-import", "mcp_audit.analyzers.attack_paths",
        "--hidden-import", "mcp_audit.output.terminal",
        "--hidden-import", "mcp_audit.output.sarif",
        "--hidden-import", "mcp_audit.output.nucleus",
        "--hidden-import", "mcp_audit.output.dashboard",
        "--hidden-import", "mcp_audit.watcher",
        "--hidden-import", "mcp_audit.registry.loader",
        "--hidden-import", "mcp_audit.rules.engine",
        "--hidden-import", "mcp_audit.fleet.merger",
        "--hidden-import", "mcp_audit.governance.evaluator",
        "--hidden-import", "mcp_audit.governance.loader",
        "--hidden-import", "mcp_audit.governance.models",
        "--hidden-import", "mcp_audit.baselines.manager",
        "--hidden-import", "mcp_audit.attestation.hasher",
        "--hidden-import", "mcp_audit.attestation.verifier",
        "--hidden-import", "mcp_audit.extensions.analyzer",
        "--hidden-import", "mcp_audit.extensions.discovery",
        "--hidden-import", "mcp_audit.sast.runner",
        "--hidden-import", "mcp_audit.sast.bundler",
        # CLI submodules — each registers its commands via @app.command decorators
        # at import time.  Listed explicitly so PyInstaller's static analysis picks
        # up every command group even if the late from-import in cli/__init__.py
        # is collapsed.
        "--hidden-import", "mcp_audit.cli.baseline",
        "--hidden-import", "mcp_audit.cli.dashboard",
        "--hidden-import", "mcp_audit.cli.extensions",
        "--hidden-import", "mcp_audit.cli.fleet",
        "--hidden-import", "mcp_audit.cli.policy",
        "--hidden-import", "mcp_audit.cli.registry",
        "--hidden-import", "mcp_audit.cli.rules",
        "--hidden-import", "mcp_audit.cli.sast",
        "--hidden-import", "mcp_audit.cli.scan",
        "--hidden-import", "mcp_audit.cli.version",
        *datas_args,
        str(root / "src" / "mcp_audit" / "cli" / "__main__.py"),
    ]

    print(f"Building {name}...")
    subprocess.run(cmd, check=True)  # noqa: S603 — cmd is fully controlled by this script

    output = root / "dist" / name
    size_mb = output.stat().st_size / 1024 / 1024
    print(f"\nBinary built: {output}")
    print(f"Size: {size_mb:.1f} MB")
    print(f"\nTest it: ./dist/{name} scan")


if __name__ == "__main__":
    build()
