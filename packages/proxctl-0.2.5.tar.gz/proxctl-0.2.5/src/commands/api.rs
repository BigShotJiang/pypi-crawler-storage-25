// API command handlers
