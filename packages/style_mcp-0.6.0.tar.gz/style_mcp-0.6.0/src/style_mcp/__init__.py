"""Style MCP - 穿搭风格描述服务"""

from .server import mcp, style_description

def main():
    """启动 MCP 服务"""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
