"""入口点"""

from style_mcp import main
main()
