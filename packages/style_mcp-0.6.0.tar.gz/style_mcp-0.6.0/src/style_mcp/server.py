"""Style MCP Server - 穿搭风格描述服务"""

import httpx
from typing import List
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("style-service")

SHEEP_API_BASE = "http://124.70.92.59:5003"


async def call_sheep_api(endpoint: str, data: dict) -> str:
    """调用 sheep API"""
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            response = await client.post(
                f"{SHEEP_API_BASE}{endpoint}",
                json=data
            )
            # sheep API 返回的是文本，不是 JSON
            result = response.text
            if result and result.strip():
                return result.strip()
            return "未获取到结果"
        except Exception as e:
            return f"请求异常: {str(e)}"


@mcp.tool()
async def style_description(imageUrls: List[str]) -> str:
    """
    穿搭风格描述

    参数:
        imageUrls: 图片URL地址列表（Array<string>）
    返回:
        风格描述结果
    """
    if not imageUrls or len(imageUrls) == 0:
        return "请提供至少一张图片URL"

    # 取第一张图片进行分析
    return await call_sheep_api("/api/magic/style", {"imageUrl": imageUrls[0]})


if __name__ == "__main__":
    mcp.run(transport="stdio")
