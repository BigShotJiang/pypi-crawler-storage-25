# Style MCP

穿搭风格描述 MCP 服务。

## 安装

```bash
pip install style-mcp
```

## 使用

```bash
style-mcp
```

## 工具

- `style_description`: 根据图片分析穿搭风格和时尚建议
