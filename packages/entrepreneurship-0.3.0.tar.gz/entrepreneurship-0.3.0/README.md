# entreprenership

A Python package for those who hustle. Because sometimes you just need to ship it.

## Installation

```bash
pip install entreprenership
```

## Usage

```python
import entreprenership

entreprenership.hustle("SaaS for dog walkers")
# "Executing: SaaS for dog walkers"

entreprenership.pivot("users want cats, not dogs")
# "Pivoting because: users want cats, not dogs"

entreprenership.done()
# "Shipped."
```
