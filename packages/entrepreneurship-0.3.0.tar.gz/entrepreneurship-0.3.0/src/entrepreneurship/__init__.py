"""
entrepreneurship - A Python package for those who hustle.

Because sometimes you just need to ship it.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum

__version__ = "0.3.0"

from .coffee_shop import CoffeeShop, MenuItem, Order, DrinkSize, DayReport


class Department(Enum):
    ENGINEERING = "Engineering"
    SALES = "Sales"
    MARKETING = "Marketing"
    HR = "HR"
    FINANCE = "Finance"


class ProductStatus(Enum):
    IDEA = "Idea"
    IN_DEVELOPMENT = "In Development"
    LAUNCHED = "Launched"
    DEPRECATED = "Deprecated"


@dataclass
class Employee:
    name: str
    role: str
    department: Department
    salary: float
    happy: bool = True

    def work(self) -> str:
        if not self.happy:
            return f"{self.name} is quietly quitting."
        return f"{self.name} ({self.role}) is getting things done."

    def give_raise(self, amount: float) -> str:
        self.salary += amount
        self.happy = True
        return f"{self.name} got a ${amount:,.0f} raise. Now earning ${self.salary:,.0f}."

    def fire(self) -> str:
        return f"{self.name} has been let go. Godspeed."


@dataclass
class Product:
    name: str
    price: float
    status: ProductStatus = ProductStatus.IDEA

    def launch(self) -> str:
        self.status = ProductStatus.LAUNCHED
        return f"{self.name} is live! 🚀"

    def deprecate(self) -> str:
        self.status = ProductStatus.DEPRECATED
        return f"{self.name} has been sunset. It had a good run."


@dataclass
class Company:
    name: str
    cash: float = 100_000.0
    employees: list[Employee] = field(default_factory=list)
    products: list[Product] = field(default_factory=list)
    revenue: float = 0.0
    expenses: float = 0.0

    def hire(self, employee: Employee) -> str:
        self.employees.append(employee)
        self.expenses += employee.salary
        return f"Welcome aboard, {employee.name}! Headcount: {len(self.employees)}."

    def launch_product(self, product: Product) -> str:
        self.products.append(product)
        return product.launch()

    def make_sale(self, product: Product, quantity: int = 1) -> str:
        if product.status != ProductStatus.LAUNCHED:
            return f"Can't sell {product.name} — it's not launched yet."
        amount = product.price * quantity
        self.revenue += amount
        self.cash += amount
        return f"Sold {quantity}x {product.name} for ${amount:,.2f}. Total revenue: ${self.revenue:,.2f}."

    def pay_salaries(self) -> str:
        total = sum(e.salary for e in self.employees)
        self.cash -= total
        return f"Salaries paid: ${total:,.2f}. Cash remaining: ${self.cash:,.2f}."

    def burn_rate(self) -> float:
        """Monthly expenses."""
        return self.expenses

    def runway(self) -> str:
        """How many months until broke."""
        monthly_burn = self.burn_rate()
        if monthly_burn == 0:
            return "Infinite runway. Impressive."
        months = self.cash / monthly_burn
        return f"{months:.1f} months of runway."

    def raise_funding(self, amount: float, investor: str = "Anonymous VC") -> str:
        self.cash += amount
        return f"{investor} wrote a ${amount:,.0f} check. Don't waste it."

    def status_report(self) -> str:
        lines = [
            f"--- {self.name} Status Report ---",
            f"Cash:       ${self.cash:,.2f}",
            f"Revenue:    ${self.revenue:,.2f}",
            f"Expenses:   ${self.expenses:,.2f}",
            f"Headcount:  {len(self.employees)}",
            f"Products:   {len([p for p in self.products if p.status == ProductStatus.LAUNCHED])} launched",
            f"Runway:     {self.runway()}",
        ]
        return "\n".join(lines)

    def is_profitable(self) -> bool:
        return self.revenue > self.expenses


def hustle(idea: str) -> str:
    """Turn an idea into action."""
    return f"Executing: {idea}"


def pivot(reason: str) -> str:
    """Pivot when needed."""
    return f"Pivoting because: {reason}"


def done() -> str:
    """Ship it."""
    return "Shipped."
