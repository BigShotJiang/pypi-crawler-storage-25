"""
Coffee shop simulation — a looping business.

customers arrive → orders taken → coffee made → served → money collected → repeat
"""

from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import random


class DrinkSize(Enum):
    SMALL = "Small"
    MEDIUM = "Medium"
    LARGE = "Large"


@dataclass
class MenuItem:
    name: str
    base_price: float
    cost_to_make: float  # ingredient cost

    def price(self, size: DrinkSize) -> float:
        multipliers = {DrinkSize.SMALL: 1.0, DrinkSize.MEDIUM: 1.3, DrinkSize.LARGE: 1.6}
        return round(self.base_price * multipliers[size], 2)


@dataclass
class Order:
    customer_name: str
    item: MenuItem
    size: DrinkSize

    @property
    def total(self) -> float:
        return self.item.price(self.size)

    @property
    def profit(self) -> float:
        return self.total - self.item.cost_to_make

    def __str__(self) -> str:
        return f"{self.customer_name}: {self.size.value} {self.item.name} (${self.total:.2f})"


@dataclass
class DayReport:
    day: int
    customers: int
    orders: list[Order]
    daily_revenue: float
    daily_costs: float
    cash: float

    @property
    def daily_profit(self) -> float:
        return self.daily_revenue - self.daily_costs

    def summary(self) -> str:
        lines = [
            f"Day {self.day}",
            f"  Customers : {self.customers}",
            f"  Revenue   : ${self.daily_revenue:.2f}",
            f"  Costs     : ${self.daily_costs:.2f}",
            f"  Profit    : ${self.daily_profit:.2f}",
            f"  Cash      : ${self.cash:.2f}",
        ]
        return "\n".join(lines)


class CoffeeShop:
    """
    A coffee shop that runs as a loop.

    Each call to `open_day()` simulates one business day:
    customers arrive → place orders → coffee is made → payment collected.

    Example:
        shop = CoffeeShop("Beans & Dreams")
        for report in shop.run(days=7):
            print(report.summary())
    """

    DEFAULT_MENU = [
        MenuItem("Espresso",   base_price=3.00, cost_to_make=0.50),
        MenuItem("Latte",      base_price=4.50, cost_to_make=1.20),
        MenuItem("Cappuccino", base_price=4.00, cost_to_make=1.00),
        MenuItem("Cold Brew",  base_price=5.00, cost_to_make=0.80),
        MenuItem("Matcha",     base_price=5.50, cost_to_make=1.50),
    ]

    CUSTOMER_NAMES = [
        "Alice", "Bob", "Carlos", "Diana", "Eve", "Frank",
        "Grace", "Hank", "Iris", "Jack", "Karen", "Leo",
    ]

    def __init__(
        self,
        name: str,
        cash: float = 10_000.0,
        daily_rent: float = 200.0,
        daily_staff_cost: float = 300.0,
        avg_customers_per_day: int = 40,
        menu: list[MenuItem] | None = None,
    ):
        self.name = name
        self.cash = cash
        self.daily_rent = daily_rent
        self.daily_staff_cost = daily_staff_cost
        self.avg_customers_per_day = avg_customers_per_day
        self.menu = menu or self.DEFAULT_MENU
        self.total_revenue = 0.0
        self.total_costs = 0.0
        self.day = 0
        self.history: list[DayReport] = []
        self._open = True

    def is_open(self) -> bool:
        return self._open and self.cash > 0

    def _generate_customers(self) -> int:
        # some days are busy, some are slow
        variance = int(self.avg_customers_per_day * 0.4)
        return max(0, random.randint(
            self.avg_customers_per_day - variance,
            self.avg_customers_per_day + variance,
        ))

    def _take_order(self) -> Order:
        name = random.choice(self.CUSTOMER_NAMES)
        item = random.choice(self.menu)
        size = random.choice(list(DrinkSize))
        return Order(customer_name=name, item=item, size=size)

    def open_day(self) -> DayReport:
        """Simulate one full business day."""
        self.day += 1
        num_customers = self._generate_customers()
        orders = [self._take_order() for _ in range(num_customers)]

        daily_revenue = sum(o.total for o in orders)
        fixed_costs = self.daily_rent + self.daily_staff_cost
        variable_costs = sum(o.item.cost_to_make for o in orders)
        daily_costs = fixed_costs + variable_costs

        self.cash += daily_revenue - daily_costs
        self.total_revenue += daily_revenue
        self.total_costs += daily_costs

        if self.cash <= 0:
            self._open = False

        report = DayReport(
            day=self.day,
            customers=num_customers,
            orders=orders,
            daily_revenue=daily_revenue,
            daily_costs=daily_costs,
            cash=self.cash,
        )
        self.history.append(report)
        return report

    def run(self, days: int) -> list[DayReport]:
        """Run the shop for N days and return all daily reports."""
        reports = []
        while self.is_open() and self.day < days:
            reports.append(self.open_day())
        return reports

    def close(self) -> str:
        self._open = False
        return f"{self.name} is closed."

    def final_report(self) -> str:
        profit = self.total_revenue - self.total_costs
        avg_daily = profit / self.day if self.day else 0
        status = "PROFITABLE" if profit > 0 else "IN THE RED"
        lines = [
            f"=== {self.name} — Final Report ({self.day} days) ===",
            f"Total Revenue  : ${self.total_revenue:,.2f}",
            f"Total Costs    : ${self.total_costs:,.2f}",
            f"Net Profit     : ${profit:,.2f}",
            f"Avg Daily P/L  : ${avg_daily:,.2f}",
            f"Cash on Hand   : ${self.cash:,.2f}",
            f"Status         : {status}",
        ]
        return "\n".join(lines)
