"""
Poll until Databricks workspace allows job runs, then trigger the test suite.
Retries every 2 minutes for up to 2 hours.
"""
from __future__ import annotations
import os, sys, time, base64
from pathlib import Path

env_file = Path.home() / ".config" / "burning-cost" / "databricks.env"
for line in env_file.read_text().splitlines():
    line = line.strip()
    if line and "=" in line:
        k, _, v = line.partition("=")
        os.environ.setdefault(k.strip(), v.strip())

from databricks.sdk import WorkspaceClient
from databricks.sdk.service import workspace as ws_svc
from databricks.sdk.errors.platform import NotFound

w = WorkspaceClient()
VALIDATE_JOB_ID = 896318314048217

print("Polling for workspace availability...")
max_attempts = 60
for attempt in range(max_attempts):
    try:
        run_response = w.jobs.run_now(job_id=VALIDATE_JOB_ID)
        run_id = run_response.run_id
        print(f"Run started: run_id={run_id}")
        break
    except NotFound as e:
        if "disabled temporarily" in str(e):
            print(f"  [{attempt+1}/{max_attempts}] Still disabled. Waiting 2 min...")
            time.sleep(120)
        else:
            raise
else:
    print("Workspace still disabled after max attempts. Giving up.")
    sys.exit(1)

# Poll
print("Polling run...")
poll_interval = 20
max_wait = 900
elapsed = 0
while elapsed < max_wait:
    status = w.jobs.get_run(run_id=run_id)
    state = status.state
    lc = state.life_cycle_state.value if state.life_cycle_state else "UNKNOWN"
    rs = state.result_state.value if state.result_state else ""
    print(f"  [{elapsed:3d}s] {lc} {rs}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        break
    time.sleep(poll_interval)
    elapsed += poll_interval

# Output
print("\n--- Run output ---")
try:
    output = w.jobs.get_run_output(run_id=run_id)
    if output.notebook_output and output.notebook_output.result:
        print(output.notebook_output.result)
    elif output.error:
        print("ERROR:", output.error)
        if output.error_trace:
            print(output.error_trace[-3000:])
    else:
        print("(no output captured)")
except Exception as exc:
    print(f"Could not fetch output: {exc}")

final = w.jobs.get_run(run_id=run_id).state
result = final.result_state.value if final.result_state else "UNKNOWN"
print(f"\nFinal result: {result}")
if result != "SUCCESS":
    sys.exit(1)
