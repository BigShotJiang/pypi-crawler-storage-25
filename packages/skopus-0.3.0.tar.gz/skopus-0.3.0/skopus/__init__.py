"""Skopus — persistent context for AI coding assistants.

Install it, run it, your agent remembers you.
"""

__version__ = "0.3.0"
