import logging
from pathlib import Path
from typing import List, Union

import pandas as pd

from emout.utils import InpFile, Units

from .backtrace.solver_wrapper import BacktraceWrapper
from .data.griddata_series import GridDataSeries
from .data.vector_data import VectorData2d, VectorData3d
from .io.directory import DirectoryInspector
from .io.grid import GridDataLoader
from .units import build_name2unit_mapping

from .data.particle_data_series import ParticlesSeries

logger = logging.getLogger(__name__)


class Emout:
    """
    EMSES 出力／.inp ファイルをまとめて扱う Facade クラス。
    """

    # name2unit マッピング (一度だけビルド)
    name2unit = build_name2unit_mapping(max_ndp=9)

    def __init__(
        self,
        directory: Union[Path, str] = "./",
        append_directories: Union[List[Union[Path, str]], None] = None,
        ad: Union[List[Union[Path, str]], None] = None,
        inpfilename: Union[Path, str] = "plasma.inp",
        input_path: Union[Path, str, None] = None,
        output_directory: Union[Path, str, None] = None,
    ):
        """Emout ファサードを初期化する。

        Parameters
        ----------
        directory : Union[Path, str], optional
            基準ディレクトリです。`input_path` / `output_directory` 未指定時は
            入力ファイル・出力ファイルの両方をこのディレクトリから探索します。
        append_directories : Union[List[Union[Path, str]], None], optional
            追加で参照するディレクトリまたはそのリストです。
        ad : Union[List[Union[Path, str]], None], optional
            `append_directories` の短縮エイリアスです。両方指定した場合は `append_directories` が優先されます。
        inpfilename : Union[Path, str], optional
            入力パラメータファイル名です。`input_path` が指定されている場合は無視されます。
        input_path : Union[Path, str, None], optional
            入力パラメータファイルへのフルパスです（例: ``/path/to/plasma.toml``）。
        output_directory : Union[Path, str, None], optional
            シミュレーション出力ファイルを格納したディレクトリです。
            未指定時は `directory` が使われます。
        """
        self._dir_inspector = DirectoryInspector(
            directory=directory,
            append_directories=append_directories or ad,
            inpfilename=inpfilename,
            input_path=input_path,
            output_directory=output_directory,
        )

        self._grid_loader = GridDataLoader(
            dir_inspector=self._dir_inspector,
            name2unit_map=Emout.name2unit,
        )

    @property
    def directory(self) -> Path:
        """メインディレクトリを返す。

        Returns
        -------
        Path
            EMSES 出力の基準ディレクトリです。
        """
        return self._dir_inspector.main_directory

    @property
    def append_directories(self) -> List[Path]:
        """追加チェーンディレクトリ一覧を返す。

        Returns
        -------
        List[Path]
            読み込み時に後段として連結されるディレクトリ一覧です。
        """
        return self._dir_inspector.append_directories

    @property
    def inp(self) -> Union[InpFile, None]:
        """読み込まれた `.inp` 情報を返す。

        Returns
        -------
        Union[InpFile, None]
            `.inp` の読み込み結果です。未読込時は `None`。
        """
        return self._dir_inspector.inp

    @property
    def toml(self):
        """TOML データを返す。

        ``plasma.toml`` が存在する場合のみ有効。
        ``data.toml.species[0].wp`` のように
        構造化 TOML へ直接アクセスできる。
        `group_id` を使う ``*_groups`` は読み込み時に各 entry へ展開され、
        `data.toml` からは group table が取り除かれる。

        Returns
        -------
        TomlData or None
            TOML 読み込み時は ``TomlData``、それ以外は ``None``。
        """
        return self._dir_inspector.toml

    @property
    def unit(self) -> Union[Units, None]:
        """単位変換情報を返す。

        Returns
        -------
        Union[Units, None]
            `UnitConversionKey` が取得できた場合は `Units`、未設定なら `None`。
        """
        return self._dir_inspector.unit

    def is_valid(self) -> bool:
        """シミュレーション出力が正常終了しているか判定する。

        Returns
        -------
        bool
            条件判定結果です。
        """
        return self._dir_inspector.is_valid()

    @property
    def icur(self) -> pd.DataFrame:
        """
        'icur' を DataFrame で返す
        """
        return self._dir_inspector.read_icur_as_dataframe()

    @property
    def pbody(self) -> pd.DataFrame:
        """
        'pbody' を DataFrame で返す
        """
        return self._dir_inspector.read_pbody_as_dataframe()

    def particle(self, species: int):
        """粒子時系列データを読み込む `ParticlesSeries` を返す。

        Parameters
        ----------
        species : int
            粒子種別番号（1 始まり）です。

        Returns
        -------
        object
            指定種別の粒子データ系列オブジェクトです。
        """
        x_unit = self.unit.length
        v_unit = self.unit.v

        vunits = {
            "x": x_unit,
            "y": x_unit,
            "z": x_unit,
            "vx": v_unit,
            "vy": v_unit,
            "vz": v_unit,
        }

        return ParticlesSeries(self.directory, species=species, vunits=vunits)

    def __getattr__(self, name: str) -> Union[GridDataSeries, VectorData2d, VectorData3d]:
        """
        - r[e/b][xyz] → relocated field の生成
        - (dname)(axis1)(axis2)(axis3) → VectorData3d
        - (dname)(axis1)(axis2) → VectorData2d
        - それ以外 → GridDataSeries
        """
        import re

        m = re.match(r"^p([1-9])", name)
        if m:
            return self.particle(species=int(m.group(1)))

        try:
            return self._grid_loader.load(name)
        except (KeyError, FileNotFoundError, OSError) as e:
            raise AttributeError(f"属性 '{name}' の読み込みに失敗しました: {e}")

    @property
    def boundaries(self):
        """MPIEMSES finbound 境界のコレクションを返す。

        ``data.inp`` の ``boundary_type = 'complex'`` 設定と
        ``boundary_types`` 配列をもとに、各 sub-boundary の
        :class:`emout.emout.boundaries.Boundary` インスタンスを生成して
        :class:`emout.emout.boundaries.BoundaryCollection` として返します。

        使用例::

            data = Emout("output_dir")

            # 個別境界のメッシュ (grid 単位)
            mesh = data.boundaries[0].mesh()

            # SI 単位で、解像度をオーバーライド
            mesh = data.boundaries[0].mesh(use_si=True, ntheta=96)

            # すべての境界をまとめた合成メッシュ
            composite = data.boundaries.mesh(use_si=True)

            # 境界ごとに個別の引数を渡す
            composite = data.boundaries.mesh(
                use_si=True,
                per={0: {"ntheta": 64}, 1: {"nradial": 12}},
            )

        Returns
        -------
        BoundaryCollection
            サポートされた finbound 境界の集合。
            `data.inp` が未読込または非 complex モードの場合は空集合を返します。
        """
        from .boundaries import BoundaryCollection

        return BoundaryCollection(
            self._dir_inspector.inp,
            self.unit,
            remote_open_kwargs=self._remote_open_kwargs,
        )

    @property
    def backtrace(self) -> BacktraceWrapper:
        """バックトレース計算用ラッパーを返す。

        Returns
        -------
        BacktraceWrapper
            現在のディレクトリ/入力条件に紐づいたバックトレース API です。
        """
        return BacktraceWrapper(
            directory=self._dir_inspector.main_directory,
            inp=self._dir_inspector.inp,
            unit=self.unit,
            remote_open_kwargs=self._remote_open_kwargs,
        )

    @property
    def _emout_dir(self) -> str:
        return str(self._dir_inspector.main_directory)

    @property
    def _remote_open_kwargs(self) -> dict:
        kwargs = {
            "directory": str(self._dir_inspector._input_directory),
            "append_directories": [str(path) for path in self._dir_inspector.append_directories],
            "inpfilename": self._dir_inspector.inpfilename,
            "output_directory": str(self._dir_inspector.main_directory),
        }
        if self._dir_inspector.input_path is not None:
            kwargs["input_path"] = str(self._dir_inspector.input_path)
        return kwargs
