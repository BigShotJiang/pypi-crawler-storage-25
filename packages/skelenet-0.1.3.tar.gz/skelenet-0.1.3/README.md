# BoneNet

Neural skeleton pose estimation — graph-transformer keypoint detection for any species.

## Install

```bash
pip install bonenet
```

## Quickstart

```python
import bonenet

# Load model (downloads once, cached locally)
model = bonenet.load("Haa-mad/chick-pose")

# Run on a file path
result = bonenet.predict(model, "image.jpg")

# Or run on a numpy array (e.g. from cv2)
result = bonenet.predict(model, frame[..., ::-1])  # cv2 is BGR — flip to RGB
```

## Output

```python
result = bonenet.predict(model, image)

result['keypoints']      # dict: {name: (x, y)} in original image pixels
result['confidence']     # list: per-keypoint confidence score
result['bbox']           # list: [cx, cy, w, h] normalized to [0, 1]
result['keypoint_names'] # list: ordered keypoint names
```

### Example output

```python
{
  'keypoints': {
    'beak':       (359.8, 155.2),
    'head':       (364.6, 174.2),
    'back':       (366.9, 156.3),
    'tail':       (360.6, 167.3),
    'left_wing':  (350.7, 161.6),
    'right_wing': (366.5, 147.7),
  },
  'confidence': [1.099, 1.278, 0.550, 1.006, 1.101, 0.848],
  'bbox': [0.505, 0.497, 0.236, 0.487],
  'keypoint_names': ['beak', 'head', 'back', 'tail', 'left_wing', 'right_wing']
}
```

## Integrating with a detection pipeline

```python
import bonenet

model = bonenet.load("Haa-mad/chick-pose")

for detection in detections:
    crop = get_crop(frame, detection['bbox'])  # your crop logic
    result = bonenet.predict(model, crop)

    detection['keypoints'] = {
        name: [x, y, result['confidence'][i]]
        for i, (name, (x, y)) in enumerate(result['keypoints'].items())
    }
```

## Available models

| Model | Species | Keypoints | HuggingFace |
|-------|---------|-----------|-------------|
| chick-pose | Chick | beak, head, back, tail, left_wing, right_wing | `Haa-mad/chick-pose` |

## Device

```python
model = bonenet.load("Haa-mad/chick-pose", device="cuda")  # GPU
model = bonenet.load("Haa-mad/chick-pose", device="cpu")   # CPU
```
