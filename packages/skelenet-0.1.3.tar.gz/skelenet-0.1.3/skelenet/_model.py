"""AnimalPoseModel — inference-only assembly."""

import torch
import torch.nn as nn
from typing import Dict, Optional

from ._backbone import Backbone
from ._graph import AnatomicalGraphTransformer
from ._heads import HeatmapHead, RegressionHead, GraphRefinementHead, UncertaintyHead, heatmap_to_coordinates
from ._detection import DetectionHead, SegmentationHead
from ._skeleton import Skeleton


class AnimalPoseModel(nn.Module):
    def __init__(self, config: dict, skeleton: Skeleton):
        super().__init__()
        self.skeleton = skeleton
        model_cfg = config['model']

        self.backbone = Backbone(model_cfg['backbone'])
        backbone_dims = self.backbone.get_output_dims()

        head_cfg = model_cfg['head']
        self.heatmap_head = HeatmapHead(
            in_channels=backbone_dims[-1],
            num_keypoints=skeleton.num_keypoints,
            num_deconv_layers=head_cfg['num_deconv_layers'],
            num_deconv_filters=head_cfg['num_deconv_filters'],
        )

        gt_cfg = dict(model_cfg['graph_transformer'])
        gt_cfg['hidden_dim'] = min(backbone_dims[-1], 256)
        self.graph_transformer = AnatomicalGraphTransformer(
            config=gt_cfg,
            skeleton=skeleton,
            backbone_dims=backbone_dims,
        )

        gt_hidden = gt_cfg['hidden_dim']
        self.regression_head = RegressionHead(hidden_dim=gt_hidden, num_keypoints=skeleton.num_keypoints)
        self.graph_refinement = GraphRefinementHead(hidden_dim=gt_hidden, num_keypoints=skeleton.num_keypoints, skeleton=skeleton)

        if head_cfg.get('uncertainty_head', True):
            self.uncertainty_head = UncertaintyHead(hidden_dim=gt_hidden, num_keypoints=skeleton.num_keypoints)
        else:
            self.uncertainty_head = None

        det_cfg = model_cfg.get('detection', {})
        if det_cfg.get('enabled', True):
            self.detection_head = DetectionHead(backbone_dims=backbone_dims, hidden_dim=det_cfg.get('hidden_dim', 256))
        else:
            self.detection_head = None

        seg_cfg = model_cfg.get('segmentation', {})
        if seg_cfg.get('enabled', True):
            self.segmentation_head = SegmentationHead(
                backbone_dims=backbone_dims,
                hidden_dim=seg_cfg.get('hidden_dim', 128),
                output_size=model_cfg['input_size'],
            )
        else:
            self.segmentation_head = None

        self.input_size = model_cfg['input_size']
        self.heatmap_size = head_cfg['heatmap_size']

    def forward(self, images: torch.Tensor, mode: str = 'pose') -> Dict[str, torch.Tensor]:
        if mode == 'detect':
            if self.detection_head is None:
                return {}
            return self.detection_head(self.backbone(images))

        multi_scale_features = self.backbone(images)
        heatmaps = self.heatmap_head(multi_scale_features[-1])
        heatmap_coords, heatmap_confidence = heatmap_to_coordinates(heatmaps)
        keypoint_features = self.graph_transformer(multi_scale_features)
        regression_offsets = self.regression_head(keypoint_features)
        regression_coords = heatmap_coords + regression_offsets
        final_coords = self.graph_refinement(keypoint_features, regression_coords)

        outputs = {
            'heatmaps': heatmaps,
            'heatmap_coords': heatmap_coords,
            'heatmap_confidence': heatmap_confidence,
            'regression_coords': regression_coords,
            'final_coords': final_coords,
            'keypoint_features': keypoint_features,
        }
        if self.uncertainty_head is not None:
            outputs['log_variance'] = self.uncertainty_head(keypoint_features)
        if self.segmentation_head is not None:
            outputs.update(self.segmentation_head(multi_scale_features))
        return outputs

    @torch.no_grad()
    def predict(self, images: torch.Tensor, use_internal_detection: bool = False) -> Dict[str, torch.Tensor]:
        """Run pose estimation on images.

        Args:
            images: (B, 3, H, W) normalised input tensor.
            use_internal_detection: If True, the model first runs its own detector
                to find the subject inside the image, then crops and re-runs pose.
                Set to False (default) when the caller already provides a tight crop
                (e.g. from an external detector like YOLO) — this avoids a lossy
                double-crop and gives better keypoint accuracy.
        """
        self.eval()
        B = images.shape[0]
        ih, iw = self.input_size

        if not use_internal_detection:
            pose_out = self.forward(images, mode='pose')
            coords = pose_out['final_coords']          # (B, K, 2) normalised [0,1]
            coords_px = coords.clone()
            coords_px[..., 0] = coords[..., 0] * iw
            coords_px[..., 1] = coords[..., 1] * ih
            conf = pose_out.get('heatmap_confidence',
                                torch.ones(coords.shape[:2], device=coords.device))
            if conf.dim() == 3:
                conf = conf[:, 0, :]
            dummy_bbox = torch.tensor([[0.5, 0.5, 1.0, 1.0]], device=images.device).expand(B, -1)
            return {
                'coordinates': coords_px,
                'confidence': conf,
                'bbox': dummy_bbox,
            }

        det_outputs = self.forward(images, mode='detect')

        all_coords_pixel, all_conf, all_bbox = [], [], []

        for b in range(B):
            if 'bbox' in det_outputs:
                cx, cy, bw, bh = det_outputs['bbox'][b].tolist()
                x1 = max(0.0, cx - bw / 2)
                y1 = max(0.0, cy - bh / 2)
                x2 = min(1.0, cx + bw / 2)
                y2 = min(1.0, cy + bh / 2)
            else:
                x1, y1, x2, y2 = 0.0, 0.0, 1.0, 1.0

            px1, py1 = int(x1 * iw), int(y1 * ih)
            px2, py2 = max(px1 + 1, int(x2 * iw)), max(py1 + 1, int(y2 * ih))
            crop = images[b:b+1, :, py1:py2, px1:px2]
            crop = nn.functional.interpolate(crop, size=(ih, iw), mode='bilinear', align_corners=False)

            pose_out = self.forward(crop, mode='pose')
            coords = pose_out['final_coords'][0]

            crop_w_px = px2 - px1
            crop_h_px = py2 - py1
            coords_px = coords.clone()
            coords_px[:, 0] = coords[:, 0] * crop_w_px + px1
            coords_px[:, 1] = coords[:, 1] * crop_h_px + py1

            conf = pose_out.get('heatmap_confidence', torch.ones(coords.shape[0], device=coords.device))
            if conf.dim() > 1:
                conf = conf[0]  # (1, K) -> (K,)
            all_coords_pixel.append(coords_px)
            all_conf.append(conf)
            all_bbox.append(
                det_outputs['bbox'][b] if 'bbox' in det_outputs
                else torch.tensor([0.5, 0.5, 1.0, 1.0], device=images.device)
            )

        return {
            'coordinates': torch.stack(all_coords_pixel),
            'confidence': torch.stack(all_conf),
            'bbox': torch.stack(all_bbox),
        }

    @classmethod
    def load(cls, checkpoint_path: str, device: str = 'cpu') -> 'AnimalPoseModel':
        """Load from checkpoint. Skips pretrained backbone download."""
        checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
        config = checkpoint['config']
        # Disable pretrained weight download — we load from checkpoint
        config['model']['backbone']['pretrained'] = False
        skeleton = Skeleton(config['skeleton'])
        model = cls(config, skeleton)
        model.load_state_dict(checkpoint['model_state_dict'])
        model = model.to(device)
        model.eval()
        return model
