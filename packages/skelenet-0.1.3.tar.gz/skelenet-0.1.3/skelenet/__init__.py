"""
Skelenet — neural skeleton pose estimation in 3 lines.

    import skelenet
    model = skelenet.load("Haa-mad/chick-pose")
    result = skelenet.predict(model, "image.jpg")
    # result['keypoints'] → {'beak': (x, y), 'head': (x, y), ...}
"""

from pathlib import Path
from typing import Union, Dict, Any, List, Optional

import torch
from PIL import Image
from torchvision import transforms

from ._model import AnimalPoseModel

_transform = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])


def load(hf_repo: str, filename: str = "best_model.pth", device: str = None) -> AnimalPoseModel:
    """Download (once) and load a BoneNet model from HuggingFace.

    Args:
        hf_repo: HuggingFace repo ID, e.g. "Haa-mad/chick-pose"
        filename: checkpoint filename in the repo (default: best_model.pth)
        device:   'cuda', 'cpu', or None (auto-detects GPU)

    Returns:
        Loaded AnimalPoseModel ready for inference.

    Example:
        model = skelenet.load("Haa-mad/chick-pose")
    """
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        raise ImportError("Run: pip install huggingface_hub")

    if device is None:
        device = 'cuda' if torch.cuda.is_available() else 'cpu'

    path = hf_hub_download(repo_id=hf_repo, filename=filename)
    return AnimalPoseModel.load(path, device=device)


def predict(
    model: AnimalPoseModel,
    image: Union[str, Path, 'Image.Image', 'np.ndarray'],
    device: str = None,
    use_internal_detection: bool = False,
) -> Dict[str, Any]:
    """Run pose estimation on a single image.

    Args:
        model:  Loaded model from skelenet.load().
        image:  PIL Image, file path, or numpy array (RGB or BGR uint8).
        device: Override device (defaults to model's device).
        use_internal_detection: If True, the model runs its own detector inside
            the image before estimating pose (two-stage pipeline). Useful when
            passing a full uncropped frame. If False (default), pose is estimated
            directly on the provided image — use this when the image is already a
            tight crop from an external detector (e.g. YOLO) for best accuracy.

    Returns:
        dict with:
          'keypoints'  — {name: (x, y)} pixel coords in original image space
          'confidence' — [float] per-keypoint confidence
          'bbox'       — [cx, cy, w, h] normalized to [0, 1]
          'keypoint_names' — ordered list of keypoint names
    """
    if isinstance(image, (str, Path)):
        image = Image.open(image).convert('RGB')
    elif not isinstance(image, Image.Image):
        import numpy as np
        image = Image.fromarray(np.asarray(image, dtype='uint8')).convert('RGB')

    orig_w, orig_h = image.size
    tensor = _transform(image).unsqueeze(0)  # (1, 3, 256, 256)

    if device is None:
        device = next(model.parameters()).device
    tensor = tensor.to(device)

    with torch.no_grad():
        result = model.predict(tensor, use_internal_detection=use_internal_detection)

    coords = result['coordinates'][0].cpu()  # (K, 2) in 256x256 space
    coords[:, 0] = coords[:, 0] * orig_w / 256
    coords[:, 1] = coords[:, 1] * orig_h / 256

    keypoint_names = model.skeleton.keypoints

    return {
        'keypoints': {
            name: (float(coords[i, 0]), float(coords[i, 1]))
            for i, name in enumerate(keypoint_names)
        },
        'confidence': result['confidence'][0].cpu().tolist(),
        'bbox': result['bbox'][0].cpu().tolist(),
        'keypoint_names': keypoint_names,
    }


def predict_batch(
    model: AnimalPoseModel,
    images: List[Union[str, Path, 'Image.Image', 'np.ndarray']],
    device: str = None,
    use_internal_detection: bool = False,
) -> List[Dict[str, Any]]:
    """Run pose estimation on a batch of images in a single GPU forward pass.

    Args:
        model:  Loaded model from skelenet.load().
        images: List of PIL Images, file paths, or numpy arrays (RGB or BGR uint8).
        device: Override device (defaults to model's device).
        use_internal_detection: Same as in predict(). Default False.

    Returns:
        List of dicts (one per image), each with the same structure as predict().

    Example:
        crops = [frame[y1:y2, x1:x2] for (y1, y2, x1, x2) in detections]
        results = skelenet.predict_batch(model, crops)
    """
    import numpy as np

    if device is None:
        device = next(model.parameters()).device

    orig_sizes = []
    tensors = []
    for image in images:
        if isinstance(image, (str, Path)):
            image = Image.open(image).convert('RGB')
        elif not isinstance(image, Image.Image):
            image = Image.fromarray(np.asarray(image, dtype='uint8')).convert('RGB')
        orig_sizes.append(image.size)  # (w, h)
        tensors.append(_transform(image))

    batch = torch.stack(tensors).to(device)  # (B, 3, 256, 256)

    with torch.no_grad():
        result = model.predict(batch, use_internal_detection=use_internal_detection)

    keypoint_names = model.skeleton.keypoints
    outputs = []
    for i, (orig_w, orig_h) in enumerate(orig_sizes):
        coords = result['coordinates'][i].cpu()
        coords[:, 0] = coords[:, 0] * orig_w / 256
        coords[:, 1] = coords[:, 1] * orig_h / 256
        outputs.append({
            'keypoints': {
                name: (float(coords[j, 0]), float(coords[j, 1]))
                for j, name in enumerate(keypoint_names)
            },
            'confidence': result['confidence'][i].cpu().tolist(),
            'bbox': result['bbox'][i].cpu().tolist(),
            'keypoint_names': keypoint_names,
        })
    return outputs


__all__ = ['load', 'predict', 'predict_batch', 'AnimalPoseModel']
