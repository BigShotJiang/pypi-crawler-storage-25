"""goose-chase-web test harness — pytest plugin and reporting."""
