"""goose-chase-web: Selector-free, self-healing web test automation."""

from goose_chase_web.agent import WebAgent

__version__ = "0.1.50"
__all__ = ["WebAgent"]
