"""Spatial package: matrix construction and spatial relationship resolution."""

from .matrix_builder import MatrixBuilder
from .matrix_resolver import MatrixResolver

__all__ = ["MatrixBuilder", "MatrixResolver"]
