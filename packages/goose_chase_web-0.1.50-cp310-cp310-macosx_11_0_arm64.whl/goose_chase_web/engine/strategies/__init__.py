"""Strategies package: DOM, spatial, and Florence resolution strategies."""

from .dom_strategy import DOMStrategy
from .spatial_strategy import SpatialStrategy

__all__ = ["DOMStrategy", "SpatialStrategy"]
