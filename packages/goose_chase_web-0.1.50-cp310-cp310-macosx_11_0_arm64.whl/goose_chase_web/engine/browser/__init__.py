"""Browser package: Playwright management, DOM parsing, and page actions."""

from .dom_parser import DOMParser
from .actions import Actions

__all__ = ["DOMParser", "Actions"]
