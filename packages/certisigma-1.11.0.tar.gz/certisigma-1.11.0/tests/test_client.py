"""Unit tests for CertiSigma Python SDK."""

import pytest
import httpx
import respx

from certisigma import (
    CertiSigmaClient,
    AsyncCertiSigmaClient,
    AuthenticationError,
    RateLimitError,
    QuotaExceededError,
)
from certisigma.exceptions import NotFoundError, ValidationError

BASE = "https://test.certisigma.ch/api"
KEY = "cs_live_test_key_000"
VALID_HASH = "a" * 64


class TestSyncClient:
    def _client(self):
        return CertiSigmaClient(api_key=KEY, base_url=BASE)

    @respx.mock
    def test_attest_success(self):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(200, json={
            "id": "att_1", "hash_hex": VALID_HASH, "timestamp": "2026-01-01T00:00:00Z",
            "status": "created", "signature": "sig123", "signing_key_id": "k1",
        }))
        with self._client() as c:
            r = c.attest(VALID_HASH, source="test")
        assert r.id == "att_1"
        assert r.status == "created"

    @respx.mock
    def test_verify_exists(self):
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": True, "hash_hex": VALID_HASH, "id": "att_1",
            "timestamp": "2026-01-01T00:00:00Z", "verified_at": "2026-01-02T00:00:00Z",
        }))
        with self._client() as c:
            r = c.verify(VALID_HASH)
        assert r.exists is True

    @respx.mock
    def test_auth_error(self):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(401, json={
            "detail": "Invalid API key",
        }))
        with pytest.raises(AuthenticationError):
            with self._client() as c:
                c.attest(VALID_HASH)

    @respx.mock
    def test_rate_limit(self):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(
            429, json={"detail": "Rate limit exceeded"}, headers={"Retry-After": "30"},
        ))
        with pytest.raises(RateLimitError) as exc_info:
            with self._client() as c:
                c.attest(VALID_HASH)
        assert exc_info.value.retry_after == 30

    @respx.mock
    def test_quota_exceeded(self):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(
            429, json={"detail": "Monthly quota exhausted"},
        ))
        with pytest.raises(QuotaExceededError):
            with self._client() as c:
                c.attest(VALID_HASH)

    def test_invalid_hash(self):
        with self._client() as c:
            with pytest.raises(ValueError, match="Invalid SHA-256"):
                c.attest("not_a_valid_hash")

    @respx.mock
    def test_batch_attest(self):
        respx.post(f"{BASE}/attest/batch").mock(return_value=httpx.Response(200, json={
            "batch_id": "b1", "count": 2, "created": 2, "existing": 0, "attestations": [],
        }))
        with self._client() as c:
            r = c.batch_attest([VALID_HASH, "b" * 64])
        assert r.count == 2

    @respx.mock
    def test_batch_attest_enriched_response(self):
        respx.post(f"{BASE}/attest/batch").mock(return_value=httpx.Response(200, json={
            "batch_id": "b1", "count": 1, "created": 1, "existing": 0,
            "attestations": [{
                "id": "att_100", "hash_hex": VALID_HASH,
                "timestamp": "2026-02-28T00:00:00+00:00", "status": "created",
                "signature": "MEUCIQDx...", "format_version": "2.0.0",
                "signing_key_id": "key-1", "claim_id": 42,
                "source": "my-app", "extra_data": {"p": "alpha"},
                "client_encrypted": False, "etag": 'W/"abc"',
            }],
        }))
        with self._client() as c:
            r = c.batch_attest([VALID_HASH])
        assert r.count == 1
        att = r.attestations[0]
        assert att["claim_id"] == 42
        assert att["source"] == "my-app"
        assert att["etag"] == 'W/"abc"'

    @respx.mock
    def test_health(self):
        respx.get(f"{BASE}/healthz").mock(return_value=httpx.Response(200, json={
            "status": "ok", "database": "connected",
        }))
        with self._client() as c:
            r = c.health()
        assert r["status"] == "ok"

    @respx.mock
    def test_update_metadata(self):
        respx.patch(f"{BASE}/attestation/att_N3k8Qw2zYp6Lm9Rt4Vc1Sa0B/metadata").mock(return_value=httpx.Response(200, json={
            "success": True, "claim_id": 10, "attestation_id": "att_N3k8Qw2zYp6Lm9Rt4Vc1Sa0B",
            "source": "new-src", "extra_data": {"k": "v"},
            "deleted": False, "audit_entries": 2,
        }))
        with self._client() as c:
            r = c.update_metadata("att_N3k8Qw2zYp6Lm9Rt4Vc1Sa0B", source="new-src", extra_data={"k": "v"})
        assert r.success is True
        assert r.claim_id == 10
        assert r.source == "new-src"
        assert r.extra_data == {"k": "v"}
        assert r.audit_entries == 2

    @respx.mock
    def test_delete_metadata(self):
        respx.patch(f"{BASE}/attestation/5/metadata").mock(return_value=httpx.Response(200, json={
            "success": True, "claim_id": 5, "attestation_id": "att_5",
            "source": None, "extra_data": None,
            "deleted": True, "audit_entries": 1,
        }))
        with self._client() as c:
            r = c.delete_metadata(5)
        assert r.success is True
        assert r.deleted is True

    @respx.mock
    def test_get_evidence(self):
        respx.get(f"{BASE}/attestation/att_99/evidence").mock(return_value=httpx.Response(200, json={
            "id": "att_99", "hash_hex": VALID_HASH, "level": "T1",
            "t0": {"signature": "sig"}, "t1": {"batchId": 1}, "t2": None,
        }))
        with self._client() as c:
            r = c.get_evidence("att_99")
        assert r.level == "T1"
        assert r.t0 == {"signature": "sig"}
        assert r.t2 is None

    @respx.mock
    def test_attest_file(self, tmp_path):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(200, json={
            "id": "att_file", "hash_hex": VALID_HASH, "timestamp": "2026-01-01T00:00:00Z",
            "status": "created",
        }))
        f = tmp_path / "test.txt"
        f.write_text("hello world")
        with self._client() as c:
            r = c.attest_file(str(f))
        assert r.id == "att_file"
        assert r.status == "created"

    @respx.mock
    def test_attest_string(self):
        import hashlib
        expected_hash = hashlib.sha256(b"SN-2026-001234").hexdigest()
        route = respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(200, json={
            "id": "att_str", "hash_hex": expected_hash, "timestamp": "2026-01-01T00:00:00Z",
            "status": "created",
        }))
        with self._client() as c:
            r = c.attest_string("SN-2026-001234", source="serial-registry")
        assert r.id == "att_str"
        req_body = route.calls[0].request.content
        import json
        payload = json.loads(req_body)
        assert payload["hash_hex"] == expected_hash
        assert payload["source"] == "serial-registry"

    @respx.mock
    def test_attest_string_no_auto_source(self):
        """source must NOT auto-populate from the string content."""
        route = respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(200, json={
            "id": "att_str2", "hash_hex": VALID_HASH, "timestamp": "2026-01-01T00:00:00Z",
            "status": "created",
        }))
        with self._client() as c:
            c.attest_string("SECRET-VALUE-123")
        import json
        payload = json.loads(route.calls[0].request.content)
        assert "source" not in payload

    @respx.mock
    def test_verify_string(self):
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": True, "hash_hex": VALID_HASH, "id": "att_1",
            "timestamp": "2026-01-01T00:00:00Z", "verified_at": "2026-01-02T00:00:00Z",
        }))
        with self._client() as c:
            r = c.verify_string("SN-2026-001234")
        assert r.exists is True

    @respx.mock
    def test_verify_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello world")
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": True, "hash_hex": VALID_HASH, "id": "att_1",
            "timestamp": "2026-01-01T00:00:00Z", "verified_at": "2026-01-02T00:00:00Z",
        }))
        with self._client() as c:
            r = c.verify_file(str(f))
        assert r.exists is True


@pytest.mark.asyncio
class TestAsyncClient:
    @respx.mock
    async def test_async_attest(self):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(200, json={
            "id": "att_2", "hash_hex": VALID_HASH, "timestamp": "2026-01-01T00:00:00Z",
            "status": "created",
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.attest(VALID_HASH)
        assert r.id == "att_2"

    @respx.mock
    async def test_async_verify(self):
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": False, "hash_hex": VALID_HASH, "verified_at": "2026-01-02T00:00:00Z",
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.verify(VALID_HASH)
        assert r.exists is False

    @respx.mock
    async def test_async_attest_string(self):
        respx.post(f"{BASE}/attest").mock(return_value=httpx.Response(200, json={
            "id": "att_async_str", "hash_hex": VALID_HASH, "timestamp": "2026-01-01T00:00:00Z",
            "status": "created",
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.attest_string("SN-ASYNC-001")
        assert r.id == "att_async_str"

    @respx.mock
    async def test_async_verify_string(self):
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": True, "hash_hex": VALID_HASH, "verified_at": "2026-01-02T00:00:00Z",
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.verify_string("SN-ASYNC-001")
        assert r.exists is True

    @respx.mock
    async def test_async_update_metadata(self):
        respx.patch(f"{BASE}/attestation/10/metadata").mock(return_value=httpx.Response(200, json={
            "success": True, "claim_id": 10, "attestation_id": "att_10",
            "source": "async-src", "extra_data": None,
            "deleted": False, "audit_entries": 1,
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.update_metadata(10, source="async-src")
        assert r.success is True
        assert r.source == "async-src"

    @respx.mock
    async def test_async_delete_metadata(self):
        respx.patch(f"{BASE}/attestation/10/metadata").mock(return_value=httpx.Response(200, json={
            "success": True, "claim_id": 10, "attestation_id": "att_10",
            "deleted": True, "audit_entries": 1,
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.delete_metadata(10)
        assert r.deleted is True

    @respx.mock
    async def test_async_get_evidence(self):
        respx.get(f"{BASE}/attestation/55/evidence").mock(return_value=httpx.Response(200, json={
            "id": "att_55", "hash_hex": VALID_HASH, "level": "T0",
            "t0": {"signature": "abc"}, "t1": None, "t2": None,
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.get_evidence(55)
        assert r.level == "T0"

    @respx.mock
    async def test_async_register_webhook(self):
        respx.post(f"{BASE}/webhook/register").mock(return_value=httpx.Response(200, json={
            "id": "wh_async",
            "url": "https://hook.example/h",
            "events": ["t2_complete"],
            "signing_secret": "b" * 64,
            "active": True,
            "created_at": "2026-03-21T00:00:00+00:00",
        }))
        async with AsyncCertiSigmaClient(api_key=KEY, base_url=BASE) as c:
            r = await c.register_webhook("https://hook.example/h", ["t2_complete"])
        assert r.id == "wh_async"
        assert len(r.signing_secret) == 64


class TestKeylessPublicEndpoints:
    """Verify that public endpoints work without an API key."""

    def _client(self):
        return CertiSigmaClient(base_url=BASE)

    @respx.mock
    def test_verify_without_key(self):
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": True, "hash_hex": VALID_HASH, "id": "att_1",
            "timestamp": "2026-01-01T00:00:00Z", "verified_at": "2026-01-02T00:00:00Z",
        }))
        with self._client() as c:
            r = c.verify(VALID_HASH)
        assert r.exists is True

    @respx.mock
    def test_batch_verify_without_key(self):
        respx.post(f"{BASE}/verify/batch").mock(return_value=httpx.Response(200, json={
            "count": 1, "found": 1, "not_found": 0, "results": [],
        }))
        with self._client() as c:
            r = c.batch_verify([VALID_HASH])
        assert r.count == 1

    @respx.mock
    def test_batch_verify_detailed(self):
        route = respx.post(f"{BASE}/verify/batch").mock(return_value=httpx.Response(200, json={
            "count": 1, "found": 1, "not_found": 0,
            "results": [{
                "hash_hex": VALID_HASH, "exists": True,
                "id": "att_100", "timestamp": "2026-02-28T00:00:00+00:00",
                "source": "my-app", "level": "T1",
                "format_version": "2.0.0",
                "t1_timestamp": "2026-02-28T01:00:00+00:00",
                "t1_provider": "DigiCert",
            }],
        }))
        with self._client() as c:
            r = c.batch_verify([VALID_HASH], detailed=True)
        assert r.count == 1
        assert r.results[0]["level"] == "T1"
        assert r.results[0]["source"] == "my-app"
        body = route.calls[0].request.content
        import json
        assert json.loads(body)["detailed"] is True

    @respx.mock
    def test_health_without_key(self):
        respx.get(f"{BASE}/healthz").mock(return_value=httpx.Response(200, json={
            "status": "ok", "database": "connected",
        }))
        with self._client() as c:
            r = c.health()
        assert r["status"] == "ok"

    @respx.mock
    def test_no_auth_header_when_keyless(self):
        route = respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": False, "hash_hex": VALID_HASH,
        }))
        with self._client() as c:
            c.verify(VALID_HASH)
        req = route.calls[0].request
        assert "authorization" not in {k.lower() for k in dict(req.headers).keys()}

    def test_attest_raises_without_key(self):
        with self._client() as c:
            with pytest.raises(AuthenticationError, match="api_key is required"):
                c.attest(VALID_HASH)

    def test_batch_attest_raises_without_key(self):
        with self._client() as c:
            with pytest.raises(AuthenticationError, match="api_key is required"):
                c.batch_attest([VALID_HASH])

    def test_attest_file_raises_without_key(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        with self._client() as c:
            with pytest.raises(AuthenticationError, match="api_key is required"):
                c.attest_file(str(f))

    def test_update_metadata_raises_without_key(self):
        with self._client() as c:
            with pytest.raises(AuthenticationError, match="api_key is required"):
                c.update_metadata(1, source="x")

    def test_delete_metadata_raises_without_key(self):
        with self._client() as c:
            with pytest.raises(AuthenticationError, match="api_key is required"):
                c.delete_metadata(1)

    def test_default_constructor_no_key(self):
        c = CertiSigmaClient(base_url=BASE)
        assert c._api_key is None
        c.close()


@pytest.mark.asyncio
class TestAsyncKeylessPublicEndpoints:
    @respx.mock
    async def test_async_verify_without_key(self):
        respx.post(f"{BASE}/verify").mock(return_value=httpx.Response(200, json={
            "exists": True, "hash_hex": VALID_HASH, "verified_at": "2026-01-02T00:00:00Z",
        }))
        async with AsyncCertiSigmaClient(base_url=BASE) as c:
            r = await c.verify(VALID_HASH)
        assert r.exists is True

    async def test_async_attest_raises_without_key(self):
        async with AsyncCertiSigmaClient(base_url=BASE) as c:
            with pytest.raises(AuthenticationError, match="api_key is required"):
                await c.attest(VALID_HASH)


class TestWebhooks:
    """Mocked HTTP tests for webhook management (SDK v1.9+)."""

    def _client(self):
        return CertiSigmaClient(api_key=KEY, base_url=BASE)

    @respx.mock
    def test_register_webhook_success(self):
        respx.post(f"{BASE}/webhook/register").mock(return_value=httpx.Response(200, json={
            "id": "wh_abc123",
            "url": "https://hook.example/h",
            "events": ["t1_complete"],
            "signing_secret": "a" * 64,
            "active": True,
            "created_at": "2026-03-21T00:00:00+00:00",
            "label": "census",
        }))
        with self._client() as c:
            r = c.register_webhook("https://hook.example/h", ["t1_complete"], label="census")
        assert r.id == "wh_abc123"
        assert r.signing_secret == "a" * 64
        assert r.label == "census"

    def test_register_webhook_invalid_events(self):
        with self._client() as c:
            with pytest.raises(ValueError, match="events must be"):
                c.register_webhook("https://hook.example/h", [])
            with pytest.raises(ValueError, match="events must be"):
                c.register_webhook("https://hook.example/h", ["unknown"])

    @respx.mock
    def test_list_webhooks(self):
        respx.get(f"{BASE}/webhooks").mock(return_value=httpx.Response(200, json={
            "webhooks": [{
                "id": "wh_1",
                "url": "https://x.io",
                "events": ["t2_complete"],
                "active": True,
                "label": None,
                "created_at": "2026-01-01T00:00:00Z",
                "last_triggered_at": None,
                "failure_count": 0,
            }],
            "count": 1,
        }))
        with self._client() as c:
            r = c.list_webhooks()
        assert r.count == 1
        assert r.webhooks[0].id == "wh_1"

    @respx.mock
    def test_delete_webhook(self):
        respx.delete(f"{BASE}/webhook/wh_x").mock(return_value=httpx.Response(200, json={
            "deleted": True, "id": "wh_x",
        }))
        with self._client() as c:
            r = c.delete_webhook("wh_x")
        assert r.deleted is True
        assert r.id == "wh_x"

    @respx.mock
    def test_list_webhook_deliveries(self):
        respx.get(f"{BASE}/webhook/wh_x/deliveries").mock(return_value=httpx.Response(200, json={
            "webhook_id": "wh_x",
            "deliveries": [{
                "id": 42,
                "event_type": "t1_complete",
                "status": "delivered",
                "response_code": 200,
                "attempts": 1,
                "created_at": "2026-01-01T00:00:00Z",
                "delivered_at": "2026-01-01T00:00:01Z",
            }],
            "count": 1,
        }))
        with self._client() as c:
            r = c.list_webhook_deliveries("wh_x")
        assert r.deliveries[0].id == 42
        assert r.deliveries[0].event_type == "t1_complete"

    @respx.mock
    def test_webhook_not_found(self):
        respx.delete(f"{BASE}/webhook/missing").mock(return_value=httpx.Response(
            404, json={"detail": "Webhook not found"},
        ))
        with pytest.raises(NotFoundError):
            with self._client() as c:
                c.delete_webhook("missing")

    @respx.mock
    def test_webhook_validation_error(self):
        respx.post(f"{BASE}/webhook/register").mock(return_value=httpx.Response(
            422, json={"detail": "Invalid"},
        ))
        with pytest.raises(ValidationError):
            with self._client() as c:
                c.register_webhook("https://x.io", ["t1_complete"])


class TestCryptoModule:
    """Tests for certisigma.crypto client-side encryption."""

    def test_generate_key(self):
        from certisigma.crypto import generate_key
        key = generate_key()
        assert len(key) == 64
        assert all(c in "0123456789abcdef" for c in key)

    def test_encrypt_decrypt_roundtrip(self):
        from certisigma.crypto import generate_key, encrypt_metadata, decrypt_metadata
        key = generate_key()
        data = {"secret": "value", "num": 42}
        envelope = encrypt_metadata(data, key)

        assert "ciphertext" in envelope
        assert "nonce" in envelope
        assert envelope["v"] == 1
        assert len(envelope["nonce"]) == 24

        decrypted = decrypt_metadata(envelope, key)
        assert decrypted == data

    def test_is_encrypted(self):
        from certisigma.crypto import generate_key, encrypt_metadata, is_encrypted
        key = generate_key()
        envelope = encrypt_metadata({"a": 1}, key)
        assert is_encrypted(envelope) is True
        assert is_encrypted({"a": 1}) is False
        assert is_encrypted(None) is False
        assert is_encrypted("string") is False

    def test_rotate_key(self):
        from certisigma.crypto import generate_key, encrypt_metadata, decrypt_metadata, rotate_key
        old_key = generate_key()
        new_key = generate_key()
        data = {"rotated": True}

        env1 = encrypt_metadata(data, old_key)
        env2 = rotate_key(env1, old_key, new_key)

        assert env1["ciphertext"] != env2["ciphertext"]
        decrypted = decrypt_metadata(env2, new_key)
        assert decrypted == data

    def test_invalid_key_length(self):
        from certisigma.crypto import encrypt_metadata
        with pytest.raises(ValueError, match="Invalid key"):
            encrypt_metadata({"a": 1}, "abcd")

    def test_invalid_envelope(self):
        from certisigma.crypto import generate_key, decrypt_metadata
        key = generate_key()
        with pytest.raises(ValueError, match="Invalid envelope"):
            decrypt_metadata({}, key)
        with pytest.raises((ValueError, TypeError)):
            decrypt_metadata(None, key)

    def test_wrong_key_fails(self):
        from certisigma.crypto import generate_key, encrypt_metadata, decrypt_metadata
        key1 = generate_key()
        key2 = generate_key()
        envelope = encrypt_metadata({"secret": 1}, key1)
        with pytest.raises(Exception):
            decrypt_metadata(envelope, key2)

    def test_verify_webhook_signature(self):
        import hmac
        import hashlib
        from certisigma.crypto import verify_webhook_signature

        body = b'{"attestation_id":"att_1","event":"t1_complete"}'
        secret = "whsec_test_secret"
        sig = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
        assert verify_webhook_signature(body, sig, secret) is True
        assert verify_webhook_signature(body, "sha256=" + "0" * 64, secret) is False
        assert verify_webhook_signature(b"tampered", sig, secret) is False
