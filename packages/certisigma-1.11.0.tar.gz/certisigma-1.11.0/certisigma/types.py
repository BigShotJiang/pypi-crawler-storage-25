"""CertiSigma SDK — Type definitions."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class AttestResult:
    id: str
    hash_hex: str
    timestamp: str
    status: str
    public_id: Optional[str] = None
    signature: Optional[str] = None
    signing_key_id: Optional[str] = None
    format_version: str = "1.0.0"
    claim_id: Optional[int] = None
    source: Optional[str] = None
    extra_data: Optional[dict] = None
    client_encrypted: bool = False
    etag: Optional[str] = None


@dataclass
class VerifyResult:
    exists: bool
    hash_hex: str
    id: Optional[str] = None
    public_id: Optional[str] = None
    timestamp: Optional[str] = None
    source: Optional[str] = None
    level: Optional[str] = None
    verified_at: Optional[str] = None


@dataclass
class BatchAttestResult:
    batch_id: str
    count: int
    created: int
    existing: int
    attestations: list[dict] = field(default_factory=list)


@dataclass
class BatchVerifyResult:
    count: int
    found: int
    not_found: int
    results: list[dict] = field(default_factory=list)


@dataclass
class MetadataPatchResult:
    success: bool
    claim_id: int
    attestation_id: str
    public_id: Optional[str] = None
    source: Optional[str] = None
    extra_data: Optional[dict] = None
    client_encrypted: bool = False
    deleted: bool = False
    audit_entries: int = 0


@dataclass
class EvidenceResult:
    hash_hex: str
    level: str
    t0: dict[str, object] = field(default_factory=dict)
    t1: Optional[dict] = None
    t2: Optional[dict] = None
    id: Optional[str] = None
    public_id: Optional[str] = None


@dataclass
class AttestationStatus:
    id: str
    hash_hex: str
    level: str
    t0_timestamp: str
    t1_timestamp: Optional[str] = None
    t2_timestamp: Optional[str] = None
    t2_bitcoin_block: Optional[int] = None
    signature_available: bool = False
    tsa_available: bool = False
    merkle_proof_available: bool = False


@dataclass
class MetadataResult:
    attestation_id: str
    public_id: Optional[str] = None
    source: Optional[str] = None
    extra_data: Optional[dict] = None
    client_encrypted: bool = False
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class ShareTokenResult:
    id: str
    share_token: str
    attestation_ids: list[str] = field(default_factory=list)
    scope: str = "read_metadata"
    recipient_label: Optional[str] = None
    max_uses: Optional[int] = None
    expires_at: str = ""
    created_at: str = ""


@dataclass
class ShareTokenInfo:
    id: str
    attestation_ids: list[str] = field(default_factory=list)
    scope: str = "read_metadata"
    recipient_label: Optional[str] = None
    max_uses: Optional[int] = None
    use_count: int = 0
    expires_at: str = ""
    revoked_at: Optional[str] = None
    created_at: str = ""
    active: bool = True


@dataclass
class Tag:
    key: str
    value: Optional[str] = None
    value_enc: Optional[str] = None
    value_nonce: Optional[str] = None
    client_encrypted: bool = False
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class TagResult:
    attestation_id: str
    tags_upserted: int = 0


@dataclass
class TagQueryResult:
    attestation_ids: list[str] = field(default_factory=list)
    next_cursor: Optional[str] = None
    count: int = 0


@dataclass
class DerivedListResult:
    id: str
    list_key: str
    item_count: int
    content_hash: str
    signature: str
    signing_key_id: str
    label: Optional[str] = None
    expires_at: Optional[str] = None
    created_at: str = ""
    warning: str = "Save list_key now — it will not be shown again"


@dataclass
class DerivedListInfo:
    id: str
    item_count: int
    label: Optional[str] = None
    expires_at: Optional[str] = None
    revoked_at: Optional[str] = None
    created_at: str = ""
    active: bool = True


@dataclass
class DerivedListDetail:
    id: str
    item_count: int
    content_hash: str
    signing_key_id: str
    label: Optional[str] = None
    tag_filter: Optional[dict] = None
    expires_at: Optional[str] = None
    revoked_at: Optional[str] = None
    created_at: str = ""
    active: bool = True
    match_count: int = 0


@dataclass
class MatchResult:
    list_id: str
    matched: int
    unmatched: int
    total: int
    matches: list[dict] = field(default_factory=list)


@dataclass
class DerivedListSignature:
    list_id: str
    signature: str
    signing_key_id: str
    content_hash: str
    item_count: int
    created_at: str = ""
    expires_at: Optional[str] = None


@dataclass
class AccessLogEntry:
    matched_count: int
    total_submitted: int
    ip_address: Optional[str] = None
    created_at: str = ""


@dataclass
class ScanMatch:
    hash_hex: str
    first_seen: str
    source: Optional[str] = None


@dataclass
class ScanResult:
    scan_id: str
    scanned_at: str
    total_scanned: int
    matched: int
    unmatched: int
    match_rate: float
    matches: list[ScanMatch] = field(default_factory=list)


@dataclass
class BulkStatsResult:
    org_id_hash: str
    total_claims: int
    unique_hashes: int
    first_claim: Optional[str] = None
    last_claim: Optional[str] = None
    claims_by_month: dict[str, int] = field(default_factory=dict)


@dataclass
class WebhookResult:
    id: str
    url: str
    events: list[str]
    signing_secret: str
    active: bool
    created_at: str
    label: Optional[str] = None


@dataclass
class WebhookInfo:
    id: str
    url: str
    events: list[str]
    active: bool
    label: Optional[str] = None
    created_at: Optional[str] = None
    last_triggered_at: Optional[str] = None
    failure_count: int = 0


@dataclass
class WebhookListResult:
    webhooks: list[WebhookInfo]
    count: int


@dataclass
class WebhookDeleteResult:
    deleted: bool
    id: str


@dataclass
class WebhookDelivery:
    id: int
    event_type: str
    status: str
    response_code: Optional[int] = None
    attempts: int = 0
    created_at: Optional[str] = None
    delivered_at: Optional[str] = None


@dataclass
class WebhookDeliveryListResult:
    webhook_id: str
    deliveries: list[WebhookDelivery]
    count: int
