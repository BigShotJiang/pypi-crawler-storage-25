"""CertiSigma Python SDK — Attestation & Verification client."""

from .client import CertiSigmaClient, AsyncCertiSigmaClient
from .crypto import verify_webhook_signature
from .exceptions import CertiSigmaError, AuthenticationError, RateLimitError, QuotaExceededError
from .hash import hash_file, hash_bytes, hash_string
from .evidence import get_blockchain_url, save_ots_proof
from .types import (
    WebhookResult,
    WebhookInfo,
    WebhookListResult,
    WebhookDeleteResult,
    WebhookDelivery,
    WebhookDeliveryListResult,
)

__version__ = "1.11.0"
__all__ = [
    "CertiSigmaClient",
    "AsyncCertiSigmaClient",
    "CertiSigmaError",
    "AuthenticationError",
    "RateLimitError",
    "QuotaExceededError",
    "hash_file",
    "hash_bytes",
    "hash_string",
    "get_blockchain_url",
    "save_ots_proof",
    "verify_webhook_signature",
    "WebhookResult",
    "WebhookInfo",
    "WebhookListResult",
    "WebhookDeleteResult",
    "WebhookDelivery",
    "WebhookDeliveryListResult",
]
