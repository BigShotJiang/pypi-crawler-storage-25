"""
Synrix Agent Runtime — Persistent Memory Kernel for AI Agents
"""

__version__ = "3.1.17"

from synrix_runtime.api.runtime import AgentRuntime

__all__ = ["AgentRuntime"]
