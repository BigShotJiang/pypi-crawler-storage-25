from .manager import lanmu
__version__ = "1.0.0"