import fastavro
import os
from fastavro import writer, reader

class ModelObserver():
    def __init__(self, avro_file_name) -> None:
        self.avro_file_name = avro_file_name

    def update(self, **kwargs):
        self.__create_avro_file(kwargs)

    def __create_avro_file(self, args):
        schema = args['schemaAvro']
        avro_file_name = self.avro_file_name
        data = args["data"]
        os.makedirs(os.path.dirname(avro_file_name), exist_ok=True)
        
        if os.path.isfile(avro_file_name):
            with open(avro_file_name, "rb") as f:
                existing_data = list(reader(f))
            data = existing_data + data

        with open(avro_file_name, "wb") as f_out:
            writer(f_out, schema, data, codec="deflate")
                
   

        

                     
        
        