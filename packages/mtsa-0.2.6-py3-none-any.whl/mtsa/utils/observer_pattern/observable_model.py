import numpy as np

class ObservableModel:
    def __init__(self):
        super().__init__()
        self.observers = []
        self.schema_locked = None

    def attach_observer(self, observer):
        self.observers.append(observer)

    def dettach_observer(self, observer):
        self.observers.remove(observer)
        
    def notify_observers(self, **kwargs):

        processed = {
            k: v.clone() if hasattr(v, "clone") else v
            for k, v in kwargs.items()
        }

        schemaAvro, data = self.__proxy_notify_observers(**processed)
        for observer in self.observers:
            observer.update(schemaAvro=schemaAvro, data=data)
        
    def __convert(self, value):
        import numpy as np

        if hasattr(value, "detach"):
            value = value.detach()

        if hasattr(value, "cpu"):
            value = value.cpu()

        if hasattr(value, "numpy"):
            value = value.numpy()

        if isinstance(value, np.ndarray):
            if value.size == 1:
                return value.item()
            return value.tolist()

        if isinstance(value, (list, dict, int, float, str, bool, type(None))):
            return value

        return str(value)
     
    def __infer_avro_type(self, value):

        if value is None:
            return ["null", "double"]

        if isinstance(value, bool):
            return "boolean"

        if isinstance(value, int):
            return "int"

        if isinstance(value, float):
            return "double"

        if isinstance(value, str):
            return "string"

        if isinstance(value, dict):
            return {"type": "map", "values": "double"}

        if isinstance(value, list):

            if len(value) == 0:
                return {"type": "array", "items": "double"}

            if isinstance(value[0], list):
                return {
                    "type": "array",
                    "items": {
                        "type": "array",
                        "items": "double"
                    }
                }

            return {"type": "array", "items": "double"}

        return "string"
    
    def __proxy_notify_observers(self, **kwargs):

        processed = {}
        
        for key, value in kwargs.items():
            value = self.__convert(value)
            processed[key] = value

        if self.schema_locked is None:
            fields = []
            for key, value in processed.items():
                fields.append({
                    "name": key,
                    "type": self.__infer_avro_type(value)
                })

            self.schema_locked = {
                "type": "record",
                "name": "Model",
                "fields": fields
            }

        return self.schema_locked, [processed]

