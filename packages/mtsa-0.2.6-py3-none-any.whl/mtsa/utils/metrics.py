from sklearn import metrics

def calculate_aucroc(y_hat, y_test):
    fpr, tpr, thresholds = metrics.roc_curve(y_test, y_hat)
    auc = metrics.auc(fpr, tpr)
    return auc, fpr, tpr

def calculate_confusion_matrix(y_hat, y_test):
    tn, fp, fn, tp = metrics.confusion_matrix(y_test, y_hat).ravel()
    return tn, fp, fn, tp
