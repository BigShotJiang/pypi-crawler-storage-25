import torch.nn as nn
import numpy as np
from tqdm import tqdm
import time

from functools import reduce

from sklearn import metrics
from sklearn.base import BaseEstimator, OutlierMixin
from sklearn.pipeline import Pipeline, FeatureUnion

from mtsa.features.mel import Array2Mfcc
from mtsa.models.hybridModels_components.ganf_core import GANFcore
from mtsa.utils.utils import Wav2Array
from mtsa.features.stats import FEATURES


"""
    GRAPH-AUGMENTED NORMALIZING FLOWS

    This class implements the model described in the paper:
        GRAPH-AUGMENTED NORMALIZING FLOWS FOR ANOMALY DETECTION OF MULTIPLE TIME SERIES

    Key concepts and techniques from the paper have been adapted and implemented here.
    Any deviations or modifications from the original methodology are noted in the implementation details.

    Reference:
    [1] X. Wu, Y. Park, S. Tirthapura, "GRAPH-AUGMENTED NORMALIZING FLOWS FOR ANOMALY DETECTION OF MULTIPLE TIME SERIES,"
    AAAI, vol. 36, no. 8, 2022.  DOI: 10.1609/aaai.v36i8.20829
"""


class GANF(nn.Module, BaseEstimator, OutlierMixin):
    def __init__(
        self,
        random_state=None,
        device=0,
        hidden_size=32,
        n_blocks=2,
        input_size=1,
        n_hidden=2,
        pre_processing_steps=[],
    ) -> None:
        super().__init__()
        self.random_state = random_state
        self.final_model = GANFcore(
            device=device,
            input_size=input_size,
            n_hidden=n_hidden,
            hidden_size=hidden_size,
            n_blocks=n_blocks,
        )
        self.pre_processing_steps = pre_processing_steps
        self.model = self._build_model()
        self.last_fit_time = 0
        
        self.device = device
        self.hidden_size = hidden_size
        self.input_size = input_size
        self.n_blocks = n_blocks
        self.n_hidden = n_hidden
        
        

    @property
    def name(self):
        return "GANF"

    def fit(
        self,
        X,
        y=None,
        batch_size=None,
        epochs=None,
        max_iteraction=None,
        learning_rate=None,
    ):

        mono = (
            not self.__has_step(self.model, "array2mfcc") and self.__is_mono_channel()
        )

        start = time.perf_counter()
        self.model.fit(
            X,
            y,
            final_model__batch_size=batch_size,
            final_model__epochs=epochs,
            final_model__max_iteraction=max_iteraction,
            final_model__learning_rate=learning_rate,
            final_model__isWaveData=self.__has_step(self.model, "wav2array"),
            final_model__mono=mono,
        )
        end = time.perf_counter()
        self.last_fit_time = end - start
        return self

    def transform(self, X, y=None):
        l = list()
        l.append(X)
        l.extend(self.model.steps[:-1])
        Xt = reduce(lambda x, y: y[1].transform(x), l)
        return Xt

    def predict(self, X):
        return self.score_samples(X)

    def score_samples(self, X):
        return np.array(list(map(self.model.score_samples, [[x] for x in X])))

    def score(self, X, Y):
        X = self.score_samples
        fpr, tpr, thresholds = metrics.roc_curve(Y, X)
        auc = metrics.auc(fpr, tpr)
        return auc

    def get_adjacent_matrix(self):
        return self.final_model.get_adjacent_matrix()

    def _build_model(self):
        model = Pipeline(steps=self.pre_processing_steps)
        model.steps.append(("final_model", self.final_model))

        return model

    def attach_observer(self, observer):
        if self.final_model is not None:
            self.final_model.attach_observer(observer)

    def set_adjacent_matrix(self, adjacent_matrix):
        if self.final_model is not None:
            self.final_model.set_adjacent_matrix(adjacent_matrix)

    def get_random_adjacent_matrix(self):
        return self.final_model.get_random_adjacent_matrix()

    def get_initial_adjacent_matrix(self):
        return self.final_model.get_initial_adjacent_matrix()

    def get_epoch_times(self):
        return self.final_model.get_epoch_times()

    def get_loss(self):
        return self.final_model.loss_best

    def __has_step(self, pipeline, step_name):
        return any(name == step_name for name, _ in pipeline.steps)

    def __is_mono_channel(self):
        for name, step in self.pipeline.steps:
            if name == "wav2array":
                return step.mono
        return False
