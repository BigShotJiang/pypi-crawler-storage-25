from functools import reduce

import numpy as np
import torch.nn as nn
from tqdm import tqdm
import time

from sklearn import metrics
from sklearn.base import BaseEstimator, OutlierMixin
from sklearn.pipeline import Pipeline, FeatureUnion

from mtsa.features.mel import Array2Mfcc
from mtsa.models.hybridModels_components.trcvae_core import TRCVAEcore
from mtsa.utils.utils import Wav2Array
from mtsa.features.stats import FEATURES


class TRCVAE(nn.Module, BaseEstimator, OutlierMixin):
    def __init__(
        self,
        device=0,
        CVAE_hidden_dims=[400, 128],
        CVAE_latent_dim=64,
        hidden_size=32,
        input_size=1,
        pre_processing_steps=[],
        lagrange_method="standard",
    ) -> None:
        super().__init__()
        # CVAE_hidden_dims[0] = hidden_size

        self.pre_processing_steps = pre_processing_steps

        self.final_model = TRCVAEcore(
            device=device,
            input_size=input_size,
            hidden_size=hidden_size,
            CVAE_hidden_dims=CVAE_hidden_dims,
            CVAE_latent_dim=CVAE_latent_dim,
            lagrange_method=lagrange_method,
        )

        self.model = self._build_model()
        
        self.CVAE_hidden_dims= CVAE_hidden_dims
        self.CVAE_latent_dim = CVAE_latent_dim
        self.hidden_size = hidden_size
        self.input_size = input_size
        self.device = device
        self.lagrange_method = lagrange_method

    @property
    def name(self):
        return "GACVAE"

    @property
    def adjacent_matrix(self):
        return self.final_model.adjacent_matrix

    @property
    def initial_adjacent_matrix(self):
        return self.final_model.initial_adjacent_matrix

    @adjacent_matrix.setter
    def adjacent_matrix(self, adjacent_matrix):
        if self.final_model is not None:
            self.final_model.adjacent_matrix = adjacent_matrix

    @property
    def epoch_times(self):
        return self.final_model.epoch_times

    @property
    def loss(self):
        return self.final_model.loss_best

    def fit(
        self,
        X,
        y=None,
        batch_size=None,
        epochs=None,
        max_iteraction=None,
        learning_rate=None,
    ):

        start = time.perf_counter()
        self.model.fit(
            X,
            y,
            final_model__batch_size=batch_size,
            final_model__epochs=epochs,
            final_model__max_iteraction=max_iteraction,
            final_model__learning_rate=learning_rate,
        )
        end = time.perf_counter()
        self.last_fit_time = end - start
        return self

    def transform(self, X, y=None):
        l = list()
        l.append(X)
        l.extend(self.model.steps[:-1])
        Xt = reduce(lambda x, y: y[1].transform(x), l)
        return Xt

    def predict(self, X):
        return self.score_samples(X)

    def score_samples(self, X):
        return np.array(list(map(self.model.score_samples, [[x] for x in X])))

    def score(self, X, Y):
        X = self.score_samples
        fpr, tpr, thresholds = metrics.roc_curve(Y, X)
        auc = metrics.auc(fpr, tpr)
        return auc

    def get_adjacent_matrix(self):
        return self.final_model.get_adjacent_matrix()

    def _build_model(self):
        model = Pipeline(steps=self.pre_processing_steps)
        model.steps.append(("final_model", self.final_model))

        return model

    def attach_observer(self, observer):
        if self.final_model is not None:
            self.final_model.attach_observer(observer)

