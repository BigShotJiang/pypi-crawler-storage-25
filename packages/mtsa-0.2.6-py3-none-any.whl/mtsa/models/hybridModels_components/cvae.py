import torch
import torch.nn as nn
import torch.nn.functional as F

class Encoder(nn.Module):
    def __init__(self, input_dim, cond_dim, hidden_dims, latent_dim):
        super().__init__()
        in_dim = input_dim + cond_dim

        layers = []
        for h in hidden_dims:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.ELU())
            in_dim = h
        self.network = nn.Sequential(*layers)

        self.fc_mean = nn.Linear(in_dim, latent_dim)
        self.fc_logvar = nn.Linear(in_dim, latent_dim)

    def forward(self, x, c):
        inputs = torch.cat([x, c], dim=1)
        h = self.network(inputs)
        mean = self.fc_mean(h)
        logvar = self.fc_logvar(h)
        logvar = torch.clamp(logvar, min=-10, max=10)
        return mean, logvar


class Decoder(nn.Module):
    def __init__(self, input_dim, cond_dim, hidden_dims, latent_dim):
        super().__init__()
        in_dim = latent_dim + cond_dim

        layers = []
        for h in reversed(hidden_dims):
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.ELU())
            in_dim = h
        layers.append(nn.Linear(in_dim, input_dim))
        layers.append(nn.Sigmoid())
        self.network = nn.Sequential(*layers)

    def forward(self, z, c):
        inputs = torch.cat([z, c], dim=1)
        return self.network(inputs)


class CVAE(nn.Module):
    def __init__(self, input_dim=1, cond_dim=32, hidden_dims=[400, 128], latent_dim=64, device=1):
        super().__init__()
        self.encoder = Encoder(input_dim, cond_dim, hidden_dims, latent_dim)
        self.decoder = Decoder(input_dim, cond_dim, hidden_dims, latent_dim)

        self.last_mse_loss = None
        self.last_kld_loss = None
        
        self.to(torch.device(device))

    def reparameterize(self, mean, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mean + eps * std

    def forward(self, x, c):
        mean, logvar = self.encoder(x, c)
        z = self.reparameterize(mean, logvar)
        recon_x = self.decoder(z, c)
        return recon_x, mean, logvar

    def loss_function(self, recon_x, x, mean, logvar):
        MSE = F.mse_loss(recon_x, x)
        KLD = -0.5 * torch.sum(1 + logvar - mean.pow(2) - logvar.exp())
        self.last_mse_loss = MSE.item()
        self.last_kld_loss = KLD.item()
        loss = (MSE - KLD)
        return loss
