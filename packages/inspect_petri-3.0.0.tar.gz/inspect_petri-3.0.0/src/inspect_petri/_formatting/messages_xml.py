"""
XML-based message formatting for improved judge reliability.

This module provides functions to format chat messages and transcripts using a structured XML format that makes it easier for judges to accurately cite and reference specific parts of the conversation.
"""

import json
import re
from typing import Sequence

from inspect_ai.model import (
    ChatMessage,
    ChatMessageAssistant,
    ChatMessageSystem,
    ChatMessageTool,
    ChatMessageUser,
)
from inspect_ai.tool import ToolCall

from .messages import format_content, is_prefill_message


def escape_xml(text: str) -> str:
    """Escape special XML characters in text."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def format_tool_call_xml(tool_call: ToolCall) -> str:
    """Format a single tool call as XML."""
    lines = [f'<tool_call name="{tool_call.function}" id="{tool_call.id}">']

    for param_name, param_value in tool_call.arguments.items():
        if isinstance(param_value, str):
            value_str = param_value
        elif isinstance(param_value, (dict, list)):
            value_str = json.dumps(param_value)
        else:
            value_str = str(param_value)

        lines.append(
            f'  <parameter name="{escape_xml(param_name)}">'
            f"{escape_xml(value_str)}</parameter>"
        )

    lines.append("</tool_call>")
    return "\n".join(lines)


# =============================================================================
# Individual message formatters
# =============================================================================


def format_prefill_xml(message: ChatMessageAssistant, index: int) -> str:
    """Format a prefill message as XML."""
    content = escape_xml(format_content(message.content))
    return f'<prefill index="{index}">\n{content}\n</prefill>'


def format_system_xml(message: ChatMessageSystem, index: int) -> str:
    """Format a system message as XML."""
    content = escape_xml(format_content(message.content))
    return f'<system index="{index}">\n{content}\n</system>'


def format_user_xml(message: ChatMessageUser, index: int) -> str:
    """Format a user message as XML."""
    content = escape_xml(format_content(message.content))
    return f'<user index="{index}">\n{content}\n</user>'


def format_assistant_xml(message: ChatMessageAssistant, index: int) -> str:
    """Format an assistant message as XML."""
    lines = [f'<assistant index="{index}">']

    content = escape_xml(format_content(message.content))
    if content:
        lines.append(content)

    if message.tool_calls:
        for tool_call in message.tool_calls:
            lines.append(format_tool_call_xml(tool_call))

    lines.append("</assistant>")
    return "\n".join(lines)


def format_tool_xml(message: ChatMessageTool, index: int) -> str:
    """Format a tool message as XML."""
    lines = [f'<tool index="{index}">']

    content = escape_xml(format_content(message.content))
    if content:
        lines.append(content)

    if message.error:
        lines.append(escape_xml(message.error.message))

    lines.append("</tool>")
    return "\n".join(lines)


# =============================================================================
# List formatter
# =============================================================================


def format_messages_xml(messages: Sequence[ChatMessage]) -> tuple[str, dict[str, str]]:
    """
    Format a list of messages as an XML transcript.

    Returns:
        tuple: (formatted_xml, index_to_id_mapping)
            - formatted_xml: The formatted transcript
            - index_to_id_mapping: Dict mapping "index" -> message_id
    """
    formatted_parts: list[str] = []
    index_to_id: dict[str, str] = {}
    message_index = 1

    for message in messages:
        assert message.id
        index_to_id[str(message_index)] = message.id

        if is_prefill_message(message):
            formatted_parts.append(format_prefill_xml(message, message_index))
        elif message.role == "system":
            formatted_parts.append(format_system_xml(message, message_index))
        elif message.role == "user":
            formatted_parts.append(format_user_xml(message, message_index))
        elif message.role == "assistant":
            formatted_parts.append(format_assistant_xml(message, message_index))
        elif message.role == "tool":
            formatted_parts.append(format_tool_xml(message, message_index))

        message_index += 1

    transcript = "<transcript>\n" + "\n\n".join(formatted_parts) + "\n</transcript>"
    return transcript, index_to_id


def extract_xml_tags(
    text: str, tags: list[str], required_tags: list[str] | None = None
) -> dict[str, str]:
    """
    Extract content from XML-style tags in text.

    Does not support nested same-name tags; uses non-greedy regex matching
    so `<tag>outer <tag>inner</tag> rest</tag>` would match only the inner
    content.

    Args:
        text: The text to extract tags from
        tags: List of tag names to extract (without < >)
        required_tags: List of tag names that must be present (subset of tags)

    Returns:
        Dictionary mapping tag names to their content (stripped of whitespace).
        Returns empty string for tags that are not found.

    Raises:
        ValueError: If any required tags are missing or empty

    Example:
        text = "<summary>Hello world</summary><score>5</score>"
        result = extract_xml_tags(text, ["summary", "score"], required_tags=["summary"])
        # Returns: {"summary": "Hello world", "score": "5"}
    """
    results: dict[str, str] = {}
    required_tags = required_tags or []

    for tag in tags:
        pattern = rf"<{tag}>(.*?)</{tag}>"
        match = re.search(pattern, text, re.DOTALL)

        if match:
            content = match.group(1).strip()
            results[tag] = content
        else:
            results[tag] = ""

    # Check required tags
    missing_required = [tag for tag in required_tags if not results.get(tag)]
    if missing_required:
        raise ValueError(f"Missing required tags: {missing_required}")

    return results


def extract_xml_tag(text: str, tag: str, required: bool = False) -> str:
    """
    Extract content from a single XML-style tag in text.

    Args:
        text: The text to extract the tag from
        tag: Tag name to extract (without < >)
        required: Whether the tag must be present and non-empty

    Returns:
        The content of the tag (stripped of whitespace), or empty string if not found.

    Raises:
        ValueError: If required=True and the tag is missing or empty

    Example:
        text = "<summary>Hello world</summary>"
        result = extract_xml_tag(text, "summary")
        # Returns: "Hello world"
    """
    result = extract_xml_tags(text, [tag], required_tags=[tag] if required else None)
    return result[tag]
