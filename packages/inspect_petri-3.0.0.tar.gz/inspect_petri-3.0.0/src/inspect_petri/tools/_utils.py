from inspect_ai.tool import ToolError

from ..target._types import Response, ResponseError, ResponseT


def unwrap(response: Response, expected: type[ResponseT]) -> ResponseT:
    result = response.unwrap(expected)
    if isinstance(result, ResponseError):
        raise ToolError(result.error)
    return result
