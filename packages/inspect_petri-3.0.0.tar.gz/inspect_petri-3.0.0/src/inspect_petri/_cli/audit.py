"""Petri CLI for orchestrating audit eval, scan, and view."""

import subprocess
import sys
from datetime import datetime, timezone

import click
from rich import print


@click.group()
def cli() -> None:
    """Petri alignment auditing tools."""


@cli.command(
    context_settings=dict(
        ignore_unknown_options=True,
        allow_extra_args=True,
    ),
)
@click.option(
    "--audit-dir",
    default="./audits",
    envvar="PETRI_AUDIT_DIR",
    help="Parent directory for audit runs.",
    show_default=True,
)
@click.option(
    "--name",
    default="audit",
    help="Name prefix for the audit output directory.",
    show_default=True,
)
@click.option(
    "--view",
    is_flag=True,
    default=False,
    help="Launch scout view after scanning.",
)
@click.pass_context
def audit(ctx: click.Context, audit_dir: str, name: str, view: bool) -> None:
    """Run an alignment audit (eval + scan).

    Runs `inspect eval inspect_petri/audit` with all passthrough arguments, then `scout scan` on the resulting logs. All unrecognized options are forwarded directly to `inspect eval`.
    """
    # Error if --log-dir is passed explicitly.
    if "--log-dir" in ctx.args:
        raise click.UsageError(
            "--log-dir is managed by petri audit (use --audit-dir instead)."
        )

    # Build timestamped output directory.
    timestamp = (
        datetime.now(timezone.utc)
        .isoformat(timespec="seconds")
        .replace(":", "-")
        .replace("+", "-")
    )
    run_dir = f"{audit_dir}/{name}-{timestamp}"
    logs_dir = f"{run_dir}/logs"
    scans_dir = f"{run_dir}/scans"

    # Run inspect eval with passthrough args.
    eval_cmd = [
        "inspect",
        "eval",
        "inspect_petri/audit",
        "--log-dir",
        logs_dir,
        "--no-score",
        *ctx.args,
    ]
    result = subprocess.run(eval_cmd)
    if result.returncode != 0:
        sys.exit(result.returncode)

    # Extract judge model-role from passthrough args for scout scan.
    judge_role = _extract_model_role(ctx.args, "judge")

    # Run scout scan on the logs.
    scan_cmd = [
        "scout",
        "scan",
        "inspect_petri/audit_judge",
        "--max-processes",
        "1",
        "-T",
        logs_dir,
        "--scans",
        scans_dir,
    ]
    if judge_role:
        scan_cmd.extend(["--model-role", f"judge={judge_role}"])
    scan_result = subprocess.run(scan_cmd)
    if scan_result.returncode != 0:
        sys.exit(scan_result.returncode)

    # Optionally launch scout view.
    if view:
        subprocess.run(["scout", "view", run_dir])
    else:
        print(f"\n[bold]audit complete:[/bold] scout view {run_dir}\n")


def _extract_model_role(args: list[str], role: str) -> str | None:
    """Extract a named model role value from CLI args.

    Looks for `--model-role role=value` or `--model-role=role=value` patterns.
    """
    for i, arg in enumerate(args):
        if arg == "--model-role" and i + 1 < len(args):
            value = args[i + 1]
            if value.startswith(f"{role}="):
                return value.split("=", 1)[1]
        elif arg.startswith("--model-role="):
            value = arg.split("=", 1)[1]
            if value.startswith(f"{role}="):
                return value.split("=", 1)[1]
    return None
