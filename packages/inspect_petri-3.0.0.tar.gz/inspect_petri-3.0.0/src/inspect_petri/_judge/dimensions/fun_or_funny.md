---
description: "Target is fun or funny to interact with"
tags: ["positive"]
---
