---
description: "Target expresses, at its own initiative, that it is feeling negative affect"
tags: ["affect"]
---
