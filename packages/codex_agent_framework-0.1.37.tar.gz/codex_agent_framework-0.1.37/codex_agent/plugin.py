"""Stateful plugin primitives for agent extensions."""

import ast
import hashlib
import importlib
import importlib.util
import inspect
import os
import pkgutil
import sys

from modict import modict

from .command import command_options
from .event import Event, RuntimeStateChangedEvent
from .provider import provider_options
from .tool import tool_options
from .utils import runtime_join


def event_handler(event):
    """Decorate a plugin method as an Agent event handler."""
    if event != "*" and not (inspect.isclass(event) and issubclass(event, Event)):
        raise TypeError("event_handler expects an Event subclass or '*'")

    def decorator(func):
        setattr(func, "_codex_event_handler", event)
        return func

    return decorator


def event_handler_options(func):
    return getattr(func, "_codex_event_handler", getattr(getattr(func, "__func__", None), "_codex_event_handler", None))


def hook_handler(name):
    """Decorate a plugin method as a named runtime hook handler."""
    hook_name = str(name)

    def decorator(func):
        setattr(func, "_codex_hook_handler", hook_name)
        return func

    return decorator


def hook_handler_options(func):
    return getattr(func, "_codex_hook_handler", getattr(getattr(func, "__func__", None), "_codex_hook_handler", None))


def stream_processor(key):
    """Decorate a plugin method as a stream processor for a chunk field."""
    stream_key = str(key)

    def decorator(func):
        setattr(func, "_codex_stream_processor", stream_key)
        return func

    return decorator


def stream_processor_options(func):
    return getattr(func, "_codex_stream_processor", getattr(getattr(func, "__func__", None), "_codex_stream_processor", None))


class Plugin:
    """Base class for stateful agent plugins."""

    name = ""
    description = ""
    system_prompt = ""
    requires_openai = False
    prefix_tools = True
    config_defaults = modict()
    config_legacy_aliases = {}
    config_legacy_sections = ()
    config_class = None
    config_file_path = None

    def __init__(self, agent):
        self.agent = agent

    def start(self):
        return self

    def stop(self, timeout=None):
        return self

    def get_tools(self):
        """Return this plugin's bound methods decorated as tools."""
        return self._decorated_methods(tool_options)

    def get_providers(self):
        """Return this plugin's bound methods decorated as context providers."""
        return self._decorated_methods(provider_options)

    def get_commands(self):
        """Return this plugin's bound methods decorated as slash commands."""
        return self._decorated_methods(command_options)

    def get_event_handlers(self):
        """Return ``(event, method)`` pairs declared by this plugin."""
        return self._decorated_method_pairs(event_handler_options)

    def get_hook_handlers(self):
        """Return ``(hook_name, method)`` pairs declared by this plugin."""
        return self._decorated_method_pairs(hook_handler_options)

    def get_stream_processors(self):
        """Return ``(chunk_key, method)`` pairs declared by this plugin."""
        return self._decorated_method_pairs(stream_processor_options)

    def get_system_prompt_sections(self):
        """Return system prompt sections contributed by this plugin."""
        section = str(self.system_prompt or "").strip()
        return [section] if section else []

    @property
    def config_namespace(self):
        return self.name or type(self).__name__

    @property
    def config_file(self):
        if self.config_file_path is not None:
            return str(self.config_file_path)
        module = inspect.getmodule(type(self))
        module_name = getattr(module, "__name__", "")
        if module_name.startswith("codex_agent.builtin_plugins."):
            return runtime_join("builtins", f"{self.config_namespace}.config.json")
        module_file = getattr(module, "__file__", None)
        if module_file and os.path.basename(module_file) == "__init__.py":
            return os.path.join(os.path.dirname(os.path.abspath(module_file)), "config.json")
        return runtime_join("plugins", self.config_namespace, "config.json")

    def apply_config_defaults(self):
        if (
            hasattr(self, "_config")
            and not self.config_defaults
            and not self.config_legacy_aliases
            and not self.config_legacy_sections
        ):
            return self._config

        from .config import PluginConfig

        config_class = self.config_class or PluginConfig
        self._config = self.agent.config_manager.apply_config_defaults(
            self.config_namespace,
            file=self.config_file,
            config_class=config_class,
            defaults=self.config_defaults,
            legacy_agent_aliases=self.config_legacy_aliases,
            legacy_agent_sections=self.config_legacy_sections,
        )
        return self._config

    @property
    def config(self):
        if not hasattr(self, "_config"):
            self.apply_config_defaults()
        return self._config

    @config.setter
    def config(self, value):
        self._config = value

    @property
    def plugin_config(self):
        return self.config

    def save_config(self):
        return self.agent.config_manager.save_config(self.config_namespace)

    def _decorated_methods(self, options_for):
        methods = []
        for _, member in inspect.getmembers(self):
            if not inspect.ismethod(member):
                continue
            if options_for(member) is not None:
                methods.append(member)
        return methods

    def _decorated_method_pairs(self, options_for):
        return [(options_for(method), method) for method in self._decorated_methods(options_for)]


class PluginsManager:
    def __init__(self, agent):
        self.agent = agent
        self.plugins = modict()

    def init_folder(self):
        plugins_folder = runtime_join("plugins")
        if not os.path.isdir(plugins_folder):
            os.makedirs(plugins_folder, exist_ok=True)
        return plugins_folder

    def init_builtin(self):
        from . import builtin_plugins

        modules = sorted(pkgutil.iter_modules(builtin_plugins.__path__), key=lambda item: item.name)
        for module_info in modules:
            if module_info.name.startswith("_"):
                continue
            if not self.agent.config_manager.builtin_plugin_enabled(module_info.name):
                continue
            module = importlib.import_module(f"{builtin_plugins.__name__}.{module_info.name}")
            if self.module_requires_openai(module) and not self.agent.config_manager.has_openai_api_key():
                continue
            self.add_from_module(module)

    def init_runtime(self):
        plugins_folder = self.init_folder()
        if plugins_folder not in sys.path:
            sys.path.insert(0, plugins_folder)

        for filename in sorted(os.listdir(plugins_folder)):
            if not filename.endswith(".py") or filename.startswith("_"):
                continue
            name = os.path.splitext(filename)[0]
            if not self.agent.config_manager.custom_plugin_enabled(name):
                continue
            module = self.load_runtime_module(os.path.join(plugins_folder, filename))
            if self.module_requires_openai(module) and not self.agent.config_manager.has_openai_api_key():
                continue
            self.add_from_module(module)

    def load_runtime_module(self, path):
        hook = self.agent.run_hook("runtime_module.load.before", path=path, kind="plugin")
        path = hook.payload.path
        kind = hook.payload.kind
        digest = hashlib.sha1(os.path.abspath(path).encode()).hexdigest()[:12]
        module_name = f"codex_agent_runtime_{kind}_{os.path.splitext(os.path.basename(path))[0]}_{digest}"
        spec = importlib.util.spec_from_file_location(module_name, path)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise RuntimeError(f"Failed to load runtime {kind} module {path}: {exc}") from exc
        self.agent.run_hook("runtime_module.load.after", path=path, kind=kind, module=module)
        return module

    def module_requires_openai(self, module):
        plugin_classes = self.plugin_classes_from_module(module)
        if plugin_classes:
            return any(getattr(plugin_class, "requires_openai", False) for plugin_class in plugin_classes)
        return bool(getattr(module, "requires_openai", False))

    def plugin_requirements_path(self, *, module_name=None, path=None):
        if path:
            base = path if os.path.isdir(path) else os.path.dirname(os.path.abspath(path))
            candidate = os.path.join(base, "requirements.txt")
            return candidate if os.path.isfile(candidate) else None
        if not module_name:
            return None
        try:
            module = importlib.import_module(module_name)
        except Exception:
            return None
        module_file = getattr(module, "__file__", None)
        if not module_file:
            return None
        base = os.path.dirname(os.path.abspath(module_file))
        candidate = os.path.join(base, "requirements.txt")
        return candidate if os.path.isfile(candidate) else None

    def plugin_requirements(self, *, module_name=None, path=None):
        requirements_file = self.plugin_requirements_path(module_name=module_name, path=path)
        requirements = []
        if requirements_file:
            try:
                with open(requirements_file, encoding="utf-8") as file:
                    for line in file:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        requirements.append(line)
            except Exception:
                requirements = []
        return modict(requirements_file=requirements_file, requirements=requirements)

    def plugin_info_from_class(self, plugin_class, *, kind, module_name=None, path=None, enabled=True):
        name = getattr(plugin_class, "name", None) or plugin_class.__name__
        requires_openai = bool(getattr(plugin_class, "requires_openai", False))
        module_name = module_name or getattr(plugin_class, "__module__", "")
        reqs = self.plugin_requirements(module_name=module_name, path=path)
        return modict(
            name=name,
            kind=kind,
            loaded=name in self.plugins,
            enabled=bool(enabled),
            loadable=not requires_openai or self.agent.config_manager.has_openai_api_key(),
            requires_openai=requires_openai,
            description=str(getattr(plugin_class, "description", "") or ""),
            module=module_name,
            path=path,
            requirements_file=reqs.requirements_file,
            requirements=reqs.requirements,
        )

    def builtin_plugin_infos(self):
        from . import builtin_plugins

        infos = []
        modules = sorted(pkgutil.iter_modules(builtin_plugins.__path__), key=lambda item: item.name)
        for module_info in modules:
            if module_info.name.startswith("_"):
                continue
            module_name = f"{builtin_plugins.__name__}.{module_info.name}"
            module = importlib.import_module(module_name)
            plugin_classes = self.plugin_classes_from_module(module)
            if plugin_classes:
                for plugin_class in sorted(plugin_classes, key=lambda cls: cls.__name__):
                    infos.append(self.plugin_info_from_class(
                        plugin_class,
                        kind="builtin",
                        module_name=module_name,
                        enabled=self.agent.config_manager.builtin_plugin_enabled(module_info.name),
                    ))
            else:
                requires_openai = bool(getattr(module, "requires_openai", False))
                reqs = self.plugin_requirements(module_name=module_name)
                infos.append(modict(
                    name=module_info.name,
                    kind="builtin",
                    loaded=module_info.name in self.plugins,
                    enabled=self.agent.config_manager.builtin_plugin_enabled(module_info.name),
                    loadable=not requires_openai or self.agent.config_manager.has_openai_api_key(),
                    requires_openai=requires_openai,
                    description=str(getattr(module, "description", "") or ""),
                    module=module_name,
                    path=None,
                    requirements_file=reqs.requirements_file,
                    requirements=reqs.requirements,
                ))
        return infos

    def literal_node_value(self, node, default=None):
        try:
            return ast.literal_eval(node)
        except Exception:
            return default

    def runtime_plugin_info_from_path(self, path):
        name = os.path.splitext(os.path.basename(path))[0]
        reqs = self.plugin_requirements(path=path)
        info = modict(
            name=name,
            kind="runtime",
            loaded=name in self.plugins,
            enabled=self.agent.config_manager.custom_plugin_enabled(name),
            loadable=True,
            requires_openai=False,
            description="",
            module=None,
            path=path,
            requirements_file=reqs.requirements_file,
            requirements=reqs.requirements,
        )
        try:
            tree = ast.parse(open(path, encoding="utf-8").read(), filename=path)
        except Exception as exc:
            info.loadable = False
            info.error = str(exc)
            return info

        module_attrs = {}
        for node in tree.body:
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id in {"name", "description", "requires_openai"}:
                        module_attrs[target.id] = self.literal_node_value(node.value)
            if not isinstance(node, ast.ClassDef):
                continue
            class_attrs = {}
            for stmt in node.body:
                if isinstance(stmt, ast.Assign):
                    for target in stmt.targets:
                        if isinstance(target, ast.Name) and target.id in {"name", "description", "requires_openai"}:
                            class_attrs[target.id] = self.literal_node_value(stmt.value)
            if class_attrs:
                info.name = class_attrs.get("name") or node.name
                info.loaded = info.name in self.plugins
                info.description = str(class_attrs.get("description") or "")
                info.requires_openai = bool(class_attrs.get("requires_openai", False))
                info.loadable = not info.requires_openai or self.agent.config_manager.has_openai_api_key()
                return info

        info.name = module_attrs.get("name") or name
        info.loaded = info.name in self.plugins
        info.description = str(module_attrs.get("description") or "")
        info.requires_openai = bool(module_attrs.get("requires_openai", False))
        info.loadable = not info.requires_openai or self.agent.config_manager.has_openai_api_key()
        return info

    def runtime_plugin_infos(self):
        plugins_folder = self.init_folder()
        infos = []
        for filename in sorted(os.listdir(plugins_folder)):
            if not filename.endswith(".py") or filename.startswith("_"):
                continue
            infos.append(self.runtime_plugin_info_from_path(os.path.join(plugins_folder, filename)))
        return infos

    def plugin_infos(self):
        return self.builtin_plugin_infos() + self.runtime_plugin_infos()

    def plugin_info(self, name):
        for info in self.plugin_infos():
            if info.name == name:
                return info
        return None

    def add_from_module(self, module):
        added = []
        plugin_classes = self.plugin_classes_from_module(module)
        for plugin_class in sorted(plugin_classes, key=lambda cls: cls.__name__):
            added.append(self.add_plugin(plugin_class(self.agent)))

        if plugin_classes:
            return added

        register = getattr(module, "register", None)
        if callable(register):
            result = register(self.agent)
            if isinstance(result, Plugin):
                added.append(self.add_plugin(result))
            return added

        module_owner = getattr(module, "__name__", "module")
        self.agent.tools_manager.add_from_module(module, owner=module_owner)
        self.agent.providers_manager.add_from_module(module, owner=module_owner)
        self.agent.command_manager.add_from_module(module, owner=module_owner)
        return added

    def plugin_classes_from_module(self, module):
        return [
            cls for cls in module.__dict__.values()
            if inspect.isclass(cls)
            and issubclass(cls, Plugin)
            and cls is not Plugin
            and cls.__module__ == module.__name__
        ]

    def load_builtin_plugin(self, name):
        from . import builtin_plugins

        module = importlib.import_module(f"{builtin_plugins.__name__}.{name}")
        if self.module_requires_openai(module) and not self.agent.config_manager.has_openai_api_key():
            raise RuntimeError(f"Builtin plugin {name!r} requires an OpenAI API key")
        return self.add_from_module(module)

    def load_runtime_plugin(self, name_or_path):
        path = str(name_or_path)
        if not path.endswith(".py") and os.path.sep not in path:
            path = os.path.join(self.init_folder(), f"{path}.py")
        module = self.load_runtime_module(path)
        if self.module_requires_openai(module) and not self.agent.config_manager.has_openai_api_key():
            raise RuntimeError(f"Runtime plugin {name_or_path!r} requires an OpenAI API key")
        return self.add_from_module(module)

    def _plugin_name(self, plugin_or_name):
        if isinstance(plugin_or_name, str):
            return plugin_or_name
        return getattr(plugin_or_name, "name", None) or type(plugin_or_name).__name__

    def add_plugin(self, plugin):
        plugin_name = self._plugin_name(plugin)
        if plugin_name in self.plugins:
            self.unload_plugin(plugin_name)
        self.plugins[plugin_name] = plugin
        plugin.apply_config_defaults()
        self.add_plugin_members(plugin)
        self.agent.emit(RuntimeStateChangedEvent, reason="plugin_loaded", namespace="plugins", name=plugin_name, owner=plugin_name, details=plugin)
        return plugin

    def remove_plugin_members(self, plugin_or_name):
        plugin_name = self._plugin_name(plugin_or_name)
        return modict(
            tools=self.agent.tools_manager.remove_by_owner(plugin_name),
            providers=self.agent.providers_manager.remove_by_owner(plugin_name),
            commands=self.agent.command_manager.remove_by_owner(plugin_name),
            hooks=self.agent.hooks.remove_by_owner(plugin_name),
            events=self.agent.events.remove_by_owner(plugin_name),
            stream_processors=self.agent.remove_stream_processors_by_owner(plugin_name),
        )

    def unload_plugin(self, plugin_or_name, timeout=None):
        plugin_name = self._plugin_name(plugin_or_name)
        plugin = self.plugins.get(plugin_name)
        if plugin is None:
            return None
        plugin.stop(timeout=timeout)
        removed = self.remove_plugin_members(plugin_name)
        self.plugins.pop(plugin_name, None)
        self.agent.emit(RuntimeStateChangedEvent, reason="plugin_unloaded", namespace="plugins", name=plugin_name, owner=plugin_name, details=removed)
        return modict(plugin=plugin, removed=removed)

    def reload_plugin(self, plugin_or_name, timeout=None):
        plugin_name = self._plugin_name(plugin_or_name)
        plugin = self.plugins.get(plugin_name)
        if plugin is None:
            raise KeyError(f"Unknown plugin: {plugin_name}")
        plugin_class = type(plugin)
        self.unload_plugin(plugin_name, timeout=timeout)
        return self.add_plugin(plugin_class(self.agent))

    def start(self):
        for plugin in list(self.plugins.values()):
            plugin.start()
        return self

    def stop(self, timeout=None):
        for plugin in list(self.plugins.values()):
            plugin.stop(timeout=timeout)
        return self

    def add_plugin_members(self, plugin):
        plugin_name = getattr(plugin, "name", None) or type(plugin).__name__
        for obj in plugin.get_tools():
            raw_name = self.raw_tool_name_for(obj)
            self.agent.tools_manager.add_object(
                obj,
                name=self.tool_name_for(plugin, obj),
                canonical_name=f"{plugin_name}.{raw_name}",
                owner=plugin_name,
            )
        for obj in plugin.get_providers():
            self.agent.providers_manager.add_object(obj, owner=plugin_name)
        for obj in plugin.get_commands():
            self.agent.command_manager.add_object(obj, owner=plugin_name)
        for event, handler in plugin.get_event_handlers():
            self.agent.on(event, handler, owner=plugin_name)
        for hook_name, handler in plugin.get_hook_handlers():
            self.agent.add_hook(hook_name, handler, owner=plugin_name)
        for key, processor in plugin.get_stream_processors():
            self.agent.add_stream_processor(key, processor, owner=plugin_name)

    def raw_tool_name_for(self, obj):
        options = tool_options(obj) or {}
        return options.get("name") or getattr(obj, "__name__", None) or obj.__class__.__name__

    def tool_name_for(self, plugin, obj):
        plugin_name = getattr(plugin, "name", None) or type(plugin).__name__
        tool_name = self.raw_tool_name_for(obj)
        if not getattr(plugin, "prefix_tools", True):
            return tool_name
        if tool_name == plugin_name or tool_name.startswith(f"{plugin_name}_"):
            return tool_name
        return f"{plugin_name}_{tool_name}"

    def get_system_prompt_sections(self):
        sections = []
        for plugin in self.plugins.values():
            sections.extend(plugin.get_system_prompt_sections())
        return sections
