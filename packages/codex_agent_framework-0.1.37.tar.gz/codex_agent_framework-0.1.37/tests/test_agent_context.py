import json
import os

from modict import modict

import codex_agent.utils as utils
from codex_agent import (
    Agent,
    AssistantStepEndEvent,
    CompactionCompletedEvent,
    CompactionMessage,
    CompactionRequestedEvent,
    MessageSubmittedEvent,
    ResponseContentDeltaEvent,
)
from codex_agent.sessions import AgentSession
from codex_agent.message import (
    AssistantMessage,
    DeveloperMessage,
    MessageChunk,
    ToolResultMessage,
    ToolResultWrapper,
    UserMessage,
)


def agent_result(agent, prompt):
    return agent(prompt).result


class FakeAI:
    def __init__(self, agent):
        self.agent = agent
        self.params = None

    def run(self, **params):
        self.params = params
        message = AssistantMessage(name="assistant")
        chunk = MessageChunk(content="hi")
        message.add_chunk(chunk)
        self.agent.emit(
            ResponseContentDeltaEvent,
            delta="hi",
            content="hi",
            chunk=chunk,
            message=message,
        )
        return message


class SequencedAI:
    def __init__(self, messages):
        self.messages = list(messages)
        self.params = []

    def run(self, **params):
        self.params.append(params)
        return self.messages.pop(0)


class FakeCompactionResult:
    id = "resp_123"
    output = [
        {"type": "message", "role": "user", "content": [{"type": "input_text", "text": "old"}]},
        {"type": "compaction_summary", "id": "cs_123", "encrypted_content": "opaque"},
    ]


class FakeCompactionClient:
    def __init__(self):
        self.history = None
        self.params = None

    @property
    def responses(self):
        return self

    def compact(self, **params):
        self.history = params.get("input")
        self.params = params
        return FakeCompactionResult()


class FailingCompactionClient(FakeCompactionClient):
    def compact(self, **params):
        self.history = params.get("input")
        self.params = params
        raise TimeoutError("compaction timed out")


def test_agent_session_compact_purges_compacted_prefix_before_remainder(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    user = DeveloperMessage(content="old session marker")
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    session = AgentSession(messages=[user, done, current])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert isinstance(message, CompactionMessage)
    assert session.messages == [message, current]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [message.id, current.id]
    assert "output_items" not in message
    assert message.summaries == [FakeCompactionResult.output[1]]
    assert message.compacted_message_count == 2
    assert client.history == [
        {
            "type": "message",
            "role": "developer",
            "content": [{"type": "input_text", "text": "old session marker"}],
        },
        {
            "type": "message",
            "role": "assistant",
            "content": [{"type": "output_text", "text": "done"}],
        },
    ]


def test_agent_session_compact_can_limit_compacted_turns(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    old_user = DeveloperMessage(content="old turn")
    old_done = AssistantMessage(content="old done")
    recent_user = DeveloperMessage(content="recent turn")
    recent_done = AssistantMessage(content="recent done")
    current = DeveloperMessage(content="current unfinished turn")
    session = AgentSession(messages=[old_user, old_done, recent_user, recent_done, current])
    client = FakeCompactionClient()

    plan = session.compaction_plan(max_compacted_turns=1)
    message = session.compact(client=client, max_compacted_turns=1)

    assert plan.completed_turn_count == 2
    assert plan.compacted_turn_count == 1
    assert plan.preserved_turn_count == 1
    assert isinstance(message, CompactionMessage)
    assert message.compacted_message_count == 2
    assert message.compacted_turn_count == 1
    assert message.preserved_turn_count == 1
    assert session.messages == [message, recent_user, recent_done, current]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [
        message.id,
        recent_user.id,
        recent_done.id,
        current.id,
    ]
    payload = json.dumps(client.history)
    assert "old turn" in payload
    assert "old done" in payload
    assert "recent turn" not in payload
    assert "recent done" not in payload


def test_agent_session_compact_zero_compacted_turns_is_noop(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    user = DeveloperMessage(content="old turn")
    done = AssistantMessage(content="old done")
    session = AgentSession(messages=[user, done])
    client = FakeCompactionClient()

    message = session.compact(client=client, max_compacted_turns=0)

    assert message is None
    assert client.history is None
    assert session.messages == [user, done]


def test_agent_session_compact_starts_at_latest_compaction(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    old_user = DeveloperMessage(content="very old")
    old_done = AssistantMessage(content="very old done")
    previous = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "old"}])
    new_user = DeveloperMessage(content="new")
    new_done = AssistantMessage(content="new done")
    session = AgentSession(messages=[old_user, old_done, previous, new_user, new_done])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert session.messages == [previous, message]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [previous.id, message.id]
    assert client.history[0] == {"type": "compaction_summary", "id": "old"}
    assert "very old" not in json.dumps(client.history)
    assert "new done" in json.dumps(client.history)


def test_agent_session_compact_includes_only_latest_compaction_anchor(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    older = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "older"}])
    latest = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "latest"}])
    new_user = DeveloperMessage(content="new facts")
    new_done = AssistantMessage(content="new facts done")
    session = AgentSession(messages=[older, latest, new_user, new_done])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert session.messages == [latest, message]
    assert [msg.id for msg in AgentSession.load(session.session_id).messages] == [latest.id, message.id]
    assert client.history[0] == {"type": "compaction_summary", "id": "latest"}
    assert {item.get("id") for item in client.history if item.get("type") == "compaction_summary"} == {"latest"}
    assert "new facts done" in json.dumps(client.history)


def test_agent_session_compact_skips_expired_context_messages(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible context")
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    session = AgentSession(messages=[expired, visible, done, current])
    client = FakeCompactionClient()

    message = session.compact(client=client)

    assert session.messages == [message, current]
    assert message.compacted_message_count == 2
    assert "visible context" in json.dumps(client.history)
    assert "expired hidden context" not in json.dumps(client.history)
    assert expired.id not in [msg.id for msg in AgentSession.load(session.session_id).messages]


def test_agent_session_compact_excludes_tool_result_wrappers_from_compaction_payload(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    assistant = AssistantMessage(content="running tool")
    assistant.tool_calls = [{
        "type": "function_call",
        "call_id": "call_big",
        "name": "big_output",
        "arguments": "{}",
    }]
    result = ToolResultMessage(
        name="big_output",
        call_id="call_big",
        content="success: call_id=call_big; full output in ToolResultWrapper id=wrap_big.",
    )
    wrapper = ToolResultWrapper(
        id="wrap_big",
        call_id="call_big",
        tool_name="big_output",
        content="\n".join(f"line {index} visible output" for index in range(200)) + "\nSECRET_TAIL",
    )
    done = AssistantMessage(content="done")
    session = AgentSession(messages=[assistant, result, wrapper, done])
    client = FakeCompactionClient()

    message = session.compact(client=client, max_input_tokens=80)
    payload = json.dumps(client.history)

    assert message.compacted_message_count == 3
    assert "SECRET_TAIL" not in payload
    assert "visible output" not in payload
    assert "running tool" in payload
    assert "full output in ToolResultWrapper id=wrap_big" in payload
    assert "done" in payload


def test_agent_compact_session_emits_volume_events(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    agent = Agent(session="new")
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible compactable context")
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    agent.session.messages = [expired, visible, done, current]
    agent.status_manager.cache_api_status(
        usage=modict(input_tokens=5000),
        quota={
            "rate_limit": {
                "primary_window": {"used_percent": 12},
                "secondary_window": {"used_percent": 34},
            },
        },
    )
    seen = []
    client = FakeCompactionClient()

    agent.on(CompactionRequestedEvent, lambda event: seen.append(event))
    agent.on(CompactionCompletedEvent, lambda event: seen.append(event))

    message = agent.compact_session(client=client)

    assert isinstance(message, CompactionMessage)
    assert [event.type for event in seen] == [
        "compaction_requested_event",
        "compaction_completed_event",
    ]
    assert seen[0].compacted_message_count == 2
    assert seen[0].context_message_count == 3
    assert seen[0].total_session_messages == 4
    assert seen[0].compacted_token_count > 0
    assert "expired hidden context" not in json.dumps(client.history)
    assert seen[1].message is message
    assert seen[1].status.source == "local_estimate"
    assert seen[1].status.context_current_tokens != 5000
    assert seen[1].compacted_message_count == 2
    assert seen[1].post_compaction_message_count == 2
    assert seen[1].total_session_messages == 2
    status = agent.get_status()
    assert status.source == "local_estimate"
    assert status.sent_session_messages == 2
    assert status.total_session_messages == 2
    assert status.context_current_tokens != 5000
    assert status.quota_5h_percent == 12
    assert status.quota_7d_percent == 34


def test_agent_compact_session_failure_is_non_mutating_and_emits_event(tmp_path, monkeypatch):
    monkeypatch.setattr(utils, "RUNTIME_DIR", str(tmp_path))
    from codex_agent import CompactionFailedEvent

    agent = Agent(session="new")
    visible = DeveloperMessage(content="visible compactable context")
    done = AssistantMessage(content="done")
    current = DeveloperMessage(content="current unfinished turn")
    agent.session.messages = [visible, done, current]
    agent.session.save()
    before_ids = [message.id for message in agent.session.messages]
    seen = []
    client = FailingCompactionClient()
    agent.on(CompactionFailedEvent, lambda event: seen.append(event))

    result = agent.compact_session(client=client)

    assert result.status == "failed"
    assert result.reason == "TimeoutError"
    assert "compaction timed out" in result.error
    assert [message.id for message in agent.session.messages] == before_ids
    assert [message.id for message in AgentSession.load(agent.current_session_id).messages] == before_ids
    assert client.history is not None
    assert [event.type for event in seen] == ["compaction_failed_event"]
    assert seen[0].reason == "TimeoutError"
    assert seen[0].compacted_message_count == 2


def test_agent_get_response_auto_compact_failure_continues_backend_call(monkeypatch):
    agent = Agent(session="new")
    agent.ai = FakeAI(agent)
    agent.session.messages.extend([
        DeveloperMessage(content="compact me"),
        AssistantMessage(content="done"),
    ])

    def compact(_session, **_params):
        raise TimeoutError("compaction timed out")

    agent.context_manager.should_auto_compact = lambda _messages: True
    monkeypatch.setattr(AgentSession, "compact", compact)

    message = agent.get_response()

    assert isinstance(message, AssistantMessage)
    assert agent.ai.params["messages"]
    assert not any(isinstance(message, CompactionMessage) for message in agent.session.messages)


def test_slash_compact_reports_compaction_failure(monkeypatch):
    agent = Agent(session="new")
    monkeypatch.setattr(agent, "compact_session", lambda **_kwargs: modict(status="failed", error="boom"))

    assert agent_result(agent, "/compact") == "Compaction failed: boom"


def test_agent_add_message_invalidates_context_status_cache():
    agent = Agent(session="new")
    first = agent.status_manager.context_status()

    agent.add_message(DeveloperMessage(content="new visible context"))
    agent.mainloop_manager.dump_pending()
    second = agent.status_manager.context_status()

    assert second.total_session_messages == first.total_session_messages + 1
    assert second.used_tokens != first.used_tokens


def test_agent_add_message_queues_pending_without_starting_turn():
    agent = Agent(session="new")
    agent.start()

    message = agent.add_message(UserMessage(content="queued only"))

    assert message in agent.mainloop_manager.pending
    assert not any(future.command == "turn" for future in agent.mainloop_manager.futures.values())
    agent.stop(timeout=1.0)


def test_agent_submit_message_queues_pending_and_autostarts_when_idle():
    agent = Agent(session="new")
    submitted = []
    agent.on(MessageSubmittedEvent, lambda event: submitted.append(event))

    def process_pending(resume=False):
        agent.mainloop_manager.dump_pending()
        return modict(type="turn_outcome", completed=True, reason="completed", result=True)

    agent.mainloop_manager.process = process_pending
    agent.start()

    result = agent.submit_message(UserMessage(content="queued while idle"))
    message = result.message
    future = next(future for future in agent.mainloop_manager.futures.values() if future.command == "turn")

    assert result.turn_id == future.id
    assert len(submitted) == 1
    assert submitted[0].message is message
    assert submitted[0].turn_id == future.id
    assert message in agent.mainloop_manager.pending or message in agent.session.messages
    turn = future.wait(timeout=1.0)
    assert turn.result is True
    assert message not in agent.mainloop_manager.pending
    assert agent.session.messages[-1].content == "queued while idle"
    agent.stop(timeout=1.0)


def test_agent_tool_result_messages_append_directly_without_pending():
    agent = Agent(session="new")
    result = ToolResultMessage(name="tool", call_id="call_1", content="ok")

    agent.add_message(result)

    assert result in agent.session.messages
    assert result not in agent.mainloop_manager.pending


def test_agent_get_context_starts_at_latest_compaction():
    agent = Agent(session="new")
    old = DeveloperMessage(content="old hidden context")
    previous = CompactionMessage(output_items=[{"type": "compaction_summary", "id": "cs_123"}])
    current = DeveloperMessage(content="current visible context")
    agent.session.messages = [old, previous, current]

    context = agent.context_manager.get_context()
    context_text = "\n".join(str(message.get("content", "")) for message in context)

    context_ids = [message.id for message in context]
    assert previous.id in context_ids
    assert current.id in context_ids
    assert old.id not in context_ids
    assert "old hidden context" not in context_text


def test_agent_local_context_estimate_does_not_count_encrypted_compaction_payload():
    agent = Agent(session="new")
    encrypted_content = "x" * 100_000
    agent.session.messages = [
        CompactionMessage(output_items=[{
            "type": "compaction_summary",
            "id": "cs_123",
            "encrypted_content": encrypted_content,
        }]),
        DeveloperMessage(content="small current context"),
    ]

    status = agent.status_manager.context_status()

    assert status.used_tokens < 10_000
    assert encrypted_content not in str(agent.context_manager.local_token_count_payload(
        agent.context_manager.response_input_token_payload(agent.session.context_messages(), response_tools=[])
    ))


def test_agent_get_context_filters_expired_messages():
    agent = Agent(session="new")
    expired = DeveloperMessage(content="expired hidden context", turns_left=0)
    visible = DeveloperMessage(content="visible context", turns_left=1)
    agent.session.messages = [expired, visible]

    context = agent.context_manager.get_context()
    context_text = "\n".join(str(message.get("content", "")) for message in context)

    context_ids = [message.id for message in context]
    assert visible.id in context_ids
    assert expired.id not in context_ids
    assert "expired hidden context" not in context_text


def test_agent_get_context_uses_openai_input_token_count_when_available(monkeypatch):
    agent = Agent(session="new")
    agent.session.messages = [DeveloperMessage(content="visible context")]
    calls = []

    def count_input_tokens(**payload):
        calls.append(payload)
        return 4321

    monkeypatch.setattr(agent.ai, "count_input_tokens", count_input_tokens)

    agent.context_manager.get_context()
    status = agent.get_status()

    assert calls
    assert calls[0]["model"] == agent.config.model
    assert "input" in calls[0]
    assert "tools" in calls[0]
    assert status.context_current_tokens == 4321
    assert status.source == "openai_input_tokens"


def test_agent_ages_context_messages_once_per_process_loop():
    agent = Agent(session="new", auto_proceed=True)
    expiring = DeveloperMessage(content="still visible", turns_left=2)
    agent.session.messages = [expiring]

    @agent.add_tool
    def echo(value):
        return value

    tool_call = AssistantMessage()
    tool_call.tool_calls = [{
        "type": "function_call",
        "call_id": "call_1",
        "name": "echo",
        "arguments": '{"value": "ok"}',
    }]
    final = AssistantMessage(content="done")
    agent.ai = SequencedAI([tool_call, final])

    outcome = agent.mainloop_manager.process()

    assert outcome.completed is True
    assert outcome.reason == "completed"
    assert expiring.turns_left == 1
