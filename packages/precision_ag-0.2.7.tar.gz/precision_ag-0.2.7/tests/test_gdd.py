"""
Unit tests for the gdd module (Growing Degree Days using NASA POWER API).

Temperature math reference (all hand-verified):
  °F = °C * 9/5 + 32
  GDD = max(0, (T_max_f + T_min_f) / 2 - t_base_f)
  Corn modified: T_max capped at 86°F, T_min floored at 50°F before averaging.
"""

import json
import pytest
from unittest.mock import patch, MagicMock
import urllib.error

from gdd import GDDComputer, GDDDataError


def _make_mock_urlopen(t_max_data: dict, t_min_data: dict):
    """Helper: build a mock urlopen that returns a NASA POWER-style response."""
    response_data = {
        "properties": {
            "parameter": {
                "T2M_MAX": t_max_data,
                "T2M_MIN": t_min_data,
            }
        }
    }
    mock_response = MagicMock()
    mock_response.read.return_value = json.dumps(response_data).encode("utf-8")
    mock_response.__enter__.return_value = mock_response
    mock_response.__exit__.return_value = False
    return mock_response


class TestGDDComputerInit:
    def test_init_stores_lat_lon(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        assert gdd.latitude == 41.5
        assert gdd.longitude == -93.5

    def test_power_url_constant(self):
        assert "power.larc.nasa.gov" in GDDComputer.POWER_URL
        assert "temporal/daily/point" in GDDComputer.POWER_URL


class TestGetSupportedCrops:
    def test_get_supported_crops(self):
        crops = GDDComputer.get_supported_crops()
        for expected in ["corn", "soybeans", "winter_wheat", "spring_wheat",
                         "cotton", "alfalfa", "sorghum", "sunflower", "rice"]:
            assert expected in crops
        # Values are floats
        for v in crops.values():
            assert isinstance(v, float)

    def test_get_supported_crops_returns_copy(self):
        crops1 = GDDComputer.get_supported_crops()
        crops1["corn"] = 999.0
        crops2 = GDDComputer.get_supported_crops()
        assert crops2["corn"] == 50.0  # original unchanged


class TestInvalidArgs:
    def test_both_crop_and_tbase_raises(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="not both"):
            gdd.compute_gdd_total("2023-05-01", "2023-09-30", crop="corn", t_base=50.0)

    def test_neither_crop_nor_tbase_raises(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="Must specify"):
            gdd.compute_gdd_total("2023-05-01", "2023-09-30")

    def test_unknown_crop_raises(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="Unknown crop"):
            gdd._resolve_crop_params("bananas", None, "F")

    def test_both_raises_for_get_gdd_series(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError):
            gdd.get_gdd_series("2023-05-01", "2023-09-30", crop="corn", t_base=50.0)

    def test_neither_raises_for_find_gdd_date(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError):
            gdd.find_gdd_date("2023-05-01", 1500)


class TestComputeGDDTotalCorn:
    """
    3-day corn scenario with modified formula (cap/floor).

    Day "20230501": T_max=35°C (95°F → capped 86°F), T_min=5°C (41°F → floored 50°F)
        avg=(86+50)/2=68, GDD=18.0
    Day "20230502": T_max=30°C (86°F, at cap), T_min=15°C (59°F, above floor)
        avg=(86+59)/2=72.5, GDD=22.5
    Day "20230503": T_max=20°C (68°F), T_min=10°C (50°F)
        avg=(68+50)/2=59, GDD=9.0
    Total = 49.5
    """

    @patch("urllib.request.urlopen")
    def test_compute_gdd_total_corn(self, mock_urlopen):
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230501": 35.0, "20230502": 30.0, "20230503": 20.0},
            t_min_data={"20230501": 5.0,  "20230502": 15.0, "20230503": 10.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        total = gdd.compute_gdd_total("2023-05-01", "2023-05-03", crop="corn")

        assert total == pytest.approx(49.5, rel=1e-6)


class TestComputeGDDTotalCustomTbase:
    """
    2-day scenario with custom °F base temperature (no crop modifier).

    t_base = 60°F
    Day "20230601": T_max=30°C (86°F), T_min=20°C (68°F)
        avg=(86+68)/2=77, GDD=17.0
    Day "20230602": T_max=25°C (77°F), T_min=15°C (59°F)
        avg=(77+59)/2=68, GDD=8.0
    Total = 25.0
    """

    @patch("urllib.request.urlopen")
    def test_compute_gdd_total_custom_tbase_f(self, mock_urlopen):
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230601": 30.0, "20230602": 25.0},
            t_min_data={"20230601": 20.0, "20230602": 15.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        total = gdd.compute_gdd_total("2023-06-01", "2023-06-02", t_base=60.0, units="F")

        assert total == pytest.approx(25.0, rel=1e-6)

    """
    2-day scenario with custom °C base temperature.

    t_base = 10°C = 50°F
    Day "20230501": T_max=25°C (77°F), T_min=15°C (59°F)
        avg=(77+59)/2=68, GDD=18.0
    Day "20230502": T_max=20°C (68°F), T_min=10°C (50°F)
        avg=(68+50)/2=59, GDD=9.0
    Total = 27.0
    """

    @patch("urllib.request.urlopen")
    def test_compute_gdd_total_custom_tbase_c(self, mock_urlopen):
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230501": 25.0, "20230502": 20.0},
            t_min_data={"20230501": 15.0, "20230502": 10.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        total = gdd.compute_gdd_total("2023-05-01", "2023-05-02", t_base=10.0, units="C")

        # 10°C → 50°F; expected total = 27.0
        assert total == pytest.approx(27.0, rel=1e-6)


class TestGetGDDSeries:
    @patch("urllib.request.urlopen")
    def test_get_gdd_series_returns_daily_dict(self, mock_urlopen):
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230501": 30.0, "20230502": 28.0, "20230503": 25.0},
            t_min_data={"20230501": 15.0, "20230502": 12.0, "20230503": 10.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        series = gdd.get_gdd_series("2023-05-01", "2023-05-03", crop="soybeans")

        # Keys must be ISO date strings
        assert set(series.keys()) == {"2023-05-01", "2023-05-02", "2023-05-03"}
        # Values must be floats >= 0
        for v in series.values():
            assert isinstance(v, float)
            assert v >= 0.0

    @patch("urllib.request.urlopen")
    def test_get_gdd_series_sorted_chronologically(self, mock_urlopen):
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230503": 25.0, "20230501": 30.0, "20230502": 28.0},
            t_min_data={"20230503": 10.0, "20230501": 15.0, "20230502": 12.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        series = gdd.get_gdd_series("2023-05-01", "2023-05-03", crop="soybeans")

        assert list(series.keys()) == sorted(series.keys())


class TestFindGDDDate:
    """
    Scenario: soybeans (t_base=50°F), 5 identical days.

    Each day: T_max=30°C (86°F), T_min=14°C (57.2°F)
        avg=(86+57.2)/2=71.6, GDD=21.6

    Cumulative: day1=21.6, day2=43.2, day3=64.8, ...
    target_gdd=40 → first reached on day2 ("2023-05-02")
    """

    def _five_day_mock(self):
        dates = ["20230501", "20230502", "20230503", "20230504", "20230505"]
        t_max = {d: 30.0 for d in dates}
        t_min = {d: 14.0 for d in dates}
        return _make_mock_urlopen(t_max, t_min)

    @patch("urllib.request.urlopen")
    def test_find_gdd_date_found(self, mock_urlopen):
        mock_urlopen.return_value = self._five_day_mock()

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        result = gdd.find_gdd_date("2023-05-01", target_gdd=40.0, crop="soybeans")

        assert result == "2023-05-02"

    @patch("urllib.request.urlopen")
    def test_find_gdd_date_not_found(self, mock_urlopen):
        mock_urlopen.return_value = self._five_day_mock()

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        result = gdd.find_gdd_date("2023-05-01", target_gdd=1000.0, crop="soybeans")

        assert result is None

    @patch("urllib.request.urlopen")
    def test_find_gdd_date_exact_target(self, mock_urlopen):
        """Target reached exactly on day 1 (using a whole-number target)."""
        mock_urlopen.return_value = self._five_day_mock()

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        # Each day ~21.6 GDD; target 21.0 is reached on day 1 (21.6 >= 21.0)
        result = gdd.find_gdd_date("2023-05-01", target_gdd=21.0, crop="soybeans")

        assert result == "2023-05-01"


class TestCornCapApplied:
    """
    Verify corn modified formula: T_max capped at 86°F, T_min floored at 50°F.

    T_max=40°C=104°F → capped to 86°F
    T_min=8°C=46.4°F → floored to 50°F
    avg=(86+50)/2=68, GDD=18.0

    Without corn (soybeans, same base):
    avg=(104+46.4)/2=75.2, GDD=25.2
    """

    @patch("urllib.request.urlopen")
    def test_corn_cap_applied(self, mock_urlopen):
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230701": 40.0},
            t_min_data={"20230701": 8.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        total_corn = gdd.compute_gdd_total("2023-07-01", "2023-07-01", crop="corn")

        assert total_corn == pytest.approx(18.0, rel=1e-6)

    @patch("urllib.request.urlopen")
    def test_corn_cap_differs_from_uncapped(self, mock_urlopen):
        """Same temps, corn vs soybeans (same base, no cap) → different results."""
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230701": 40.0},
            t_min_data={"20230701": 8.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        total_corn = gdd.compute_gdd_total("2023-07-01", "2023-07-01", crop="corn")

        # Reset mock for second call
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230701": 40.0},
            t_min_data={"20230701": 8.0},
        )
        total_soybeans = gdd.compute_gdd_total("2023-07-01", "2023-07-01", crop="soybeans")

        # Corn (capped): 18.0; Soybeans (uncapped): 25.2
        assert total_corn == pytest.approx(18.0, rel=1e-6)
        assert total_soybeans == pytest.approx(25.2, rel=1e-4)
        assert total_corn < total_soybeans


class TestMissingValuesFiltered:
    @patch("urllib.request.urlopen")
    def test_missing_values_filtered(self, mock_urlopen):
        """Days with -999 values must be excluded from the series."""
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230501": 30.0, "20230502": -999.0, "20230503": 25.0},
            t_min_data={"20230501": 15.0, "20230502": 10.0,   "20230503": 10.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        series = gdd.get_gdd_series("2023-05-01", "2023-05-03", crop="soybeans")

        assert "2023-05-01" in series
        assert "2023-05-02" not in series  # T_max was -999
        assert "2023-05-03" in series

    @patch("urllib.request.urlopen")
    def test_missing_tmin_filtered(self, mock_urlopen):
        """Days where T_min is -999 must also be excluded."""
        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230501": 30.0, "20230502": 28.0},
            t_min_data={"20230501": -999.0, "20230502": 12.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        series = gdd.get_gdd_series("2023-05-01", "2023-05-02", crop="soybeans")

        assert "2023-05-01" not in series
        assert "2023-05-02" in series


class TestAPIError:
    @patch("urllib.request.urlopen")
    def test_network_error_raises_gdd_data_error(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("Network error")

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(GDDDataError, match="NASA POWER API error"):
            gdd.compute_gdd_total("2023-05-01", "2023-09-30", crop="corn")

    @patch("urllib.request.urlopen")
    def test_http_error_raises_gdd_data_error(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.HTTPError(
            "url", 500, "Server Error", {}, None
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(GDDDataError):
            gdd.get_gdd_series("2023-05-01", "2023-09-30", crop="corn")

    @patch("urllib.request.urlopen")
    def test_json_error_raises_gdd_data_error(self, mock_urlopen):
        mock_response = MagicMock()
        mock_response.read.return_value = b"not valid json"
        mock_response.__enter__.return_value = mock_response
        mock_response.__exit__.return_value = False
        mock_urlopen.return_value = mock_response

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(GDDDataError, match="Invalid JSON"):
            gdd.compute_gdd_total("2023-05-01", "2023-09-30", crop="corn")


class TestDateInputFormats:
    @patch("urllib.request.urlopen")
    def test_accepts_datetime_date_objects(self, mock_urlopen):
        import datetime as dt

        mock_urlopen.return_value = _make_mock_urlopen(
            t_max_data={"20230501": 25.0},
            t_min_data={"20230501": 15.0},
        )

        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        series = gdd.get_gdd_series(
            dt.date(2023, 5, 1), dt.date(2023, 5, 1), crop="soybeans"
        )

        assert "2023-05-01" in series

    def test_invalid_date_string_raises(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="YYYY-MM-DD"):
            gdd._to_yyyymmdd("20230501")  # missing hyphens

    def test_to_yyyymmdd_iso_string(self):
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)
        assert gdd._to_yyyymmdd("2023-05-01") == "20230501"
