"""
Unit tests for the elevation_data module.
"""

import numpy as np
import pytest
from unittest.mock import patch, MagicMock
import json


class TestElevationComputer:
    """Tests for basic ElevationComputer initialization and config."""

    @patch("precision_ag.elevation_data.Client")
    def test_init_default_source(self, mock_client):
        """Test initialization with default auto source."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        assert ec.source == "auto"
        assert "planetarycomputer" in ec.catalog_url

    @patch("precision_ag.elevation_data.Client")
    def test_init_3dep_source(self, mock_client):
        """Test initialization with 3DEP source."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer(source="3dep-seamless")

        assert ec.source == "3dep-seamless"

    def test_init_invalid_source(self):
        """Test that unknown source raises ValueError."""
        from precision_ag.elevation_data import ElevationComputer

        with pytest.raises(ValueError, match="Unknown DEM source"):
            ElevationComputer(source="not-a-source")

    @patch("precision_ag.elevation_data.Client")
    def test_get_available_products(self, mock_client):
        """Test listing available terrain products."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        products = ec.get_available_products()

        assert "elevation" in products
        assert "slope" in products
        assert "aspect" in products
        assert "hillshade" in products
        assert "twi" in products
        assert "roughness" in products

    @patch("precision_ag.elevation_data.Client")
    def test_sources_dict(self, mock_client):
        """Test that SOURCES dict has expected keys."""
        from precision_ag.elevation_data import SOURCES

        assert "cop-dem-glo-30" in SOURCES
        assert "3dep-seamless" in SOURCES
        assert SOURCES["cop-dem-glo-30"]["coverage"] == "global"
        assert SOURCES["3dep-seamless"]["coverage"] == "us"


class TestAutoSourceResolution:
    """Tests for automatic source selection based on AOI location."""

    @patch("precision_ag.elevation_data.Client")
    def test_auto_resolves_to_3dep_for_us(self, mock_client, sample_aoi_geojson):
        """Auto source should resolve to 3DEP for a US AOI."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()  # default "auto"
        ec._resolve_source(sample_aoi_geojson)

        assert ec.source == "3dep-seamless"
        assert ec.source_info["coverage"] == "us"

    @patch("precision_ag.elevation_data.Client")
    def test_auto_resolves_to_copernicus_outside_us(self, mock_client):
        """Auto source should resolve to Copernicus for non-US AOI."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        europe_aoi = {
            "type": "Polygon",
            "coordinates": [
                [[10.0, 50.0], [11.0, 50.0], [11.0, 51.0], [10.0, 51.0], [10.0, 50.0]]
            ],
        }
        ec._resolve_source(europe_aoi)

        assert ec.source == "cop-dem-glo-30"
        assert ec.source_info["coverage"] == "global"

    @patch("precision_ag.elevation_data.Client")
    def test_explicit_source_not_overridden(self, mock_client, sample_aoi_geojson):
        """Explicit source should not be changed by _resolve_source."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer(source="cop-dem-glo-30")
        ec._resolve_source(sample_aoi_geojson)

        assert ec.source == "cop-dem-glo-30"

    @patch("precision_ag.elevation_data.Client")
    def test_is_in_conus_true(self, mock_client, sample_aoi_geojson):
        from precision_ag.elevation_data import ElevationComputer

        assert ElevationComputer._is_in_conus(sample_aoi_geojson) is True

    @patch("precision_ag.elevation_data.Client")
    def test_is_in_conus_false(self, mock_client):
        from precision_ag.elevation_data import ElevationComputer

        europe_aoi = {
            "type": "Polygon",
            "coordinates": [
                [[10.0, 50.0], [11.0, 50.0], [11.0, 51.0], [10.0, 51.0], [10.0, 50.0]]
            ],
        }
        assert ElevationComputer._is_in_conus(europe_aoi) is False


class TestAOILoading:
    """Tests for AOI loading (mirrors existing satellite_indices tests)."""

    @patch("precision_ag.elevation_data.Client")
    def test_load_aoi_bbox(self, mock_client, sample_aoi_bbox):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        geometry = ec.load_aoi(sample_aoi_bbox)

        assert geometry["type"] == "Polygon"
        assert len(geometry["coordinates"]) == 1
        assert len(geometry["coordinates"][0]) == 5

    @patch("precision_ag.elevation_data.Client")
    def test_load_aoi_polygon(self, mock_client, sample_aoi_polygon):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        geometry = ec.load_aoi(sample_aoi_polygon)

        assert geometry["type"] == "Polygon"
        assert len(geometry["coordinates"][0]) == 5  # auto-closed

    @patch("precision_ag.elevation_data.Client")
    def test_load_aoi_geojson(self, mock_client, sample_aoi_geojson):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        geometry = ec.load_aoi(sample_aoi_geojson)

        assert geometry["type"] == "Polygon"

    @patch("precision_ag.elevation_data.Client")
    def test_load_aoi_file(self, mock_client, sample_aoi_geojson, tmp_path):
        from precision_ag.elevation_data import ElevationComputer

        # Write a GeoJSON file
        geojson_file = tmp_path / "test_aoi.geojson"
        feature = {"type": "Feature", "geometry": sample_aoi_geojson, "properties": {}}
        geojson_file.write_text(json.dumps(feature))

        ec = ElevationComputer()
        geometry = ec.load_aoi(str(geojson_file))

        assert geometry["type"] == "Polygon"

    @patch("precision_ag.elevation_data.Client")
    def test_load_aoi_invalid(self, mock_client):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        with pytest.raises(ValueError):
            ec.load_aoi(12345)

    @patch("precision_ag.elevation_data.Client")
    def test_load_aoi_missing_file(self, mock_client):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        with pytest.raises(ValueError, match="AOI file not found"):
            ec.load_aoi("/nonexistent/path.geojson")


class TestTerrainComputation:
    """Tests for pure numpy/scipy terrain computations on synthetic DEM."""

    def test_slope_range(self, sample_dem_array):
        """Slope values should be in [0, 90] degrees."""
        from precision_ag.elevation_data import ElevationComputer

        slope = ElevationComputer._compute_slope(sample_dem_array, 30.0)

        assert slope.shape == sample_dem_array.shape
        assert np.all(slope >= 0)
        assert np.all(slope <= 90)

    def test_slope_flat_surface(self):
        """A perfectly flat surface should have zero slope."""
        from precision_ag.elevation_data import ElevationComputer

        flat = np.ones((50, 50), dtype=np.float32) * 100.0
        slope = ElevationComputer._compute_slope(flat, 30.0)

        np.testing.assert_allclose(slope, 0.0, atol=1e-6)

    def test_aspect_range(self, sample_dem_array):
        """Aspect values should be in [0, 360) degrees."""
        from precision_ag.elevation_data import ElevationComputer

        aspect = ElevationComputer._compute_aspect(sample_dem_array, 30.0)

        assert aspect.shape == sample_dem_array.shape
        assert np.all(aspect >= 0)
        assert np.all(aspect <= 360)

    def test_hillshade_range(self, sample_dem_array):
        """Hillshade values should be in [0, 255]."""
        from precision_ag.elevation_data import ElevationComputer

        hs = ElevationComputer._compute_hillshade(sample_dem_array, 30.0)

        assert hs.shape == sample_dem_array.shape
        assert np.all(hs >= 0)
        assert np.all(hs <= 255)

    def test_twi_no_nan_on_bowl(self, sample_dem_array):
        """TWI should have no NaN or inf on a bowl-shaped DEM."""
        from precision_ag.elevation_data import ElevationComputer

        twi = ElevationComputer._compute_twi(sample_dem_array, 30.0)

        assert twi.shape == sample_dem_array.shape
        assert not np.any(np.isnan(twi))
        assert not np.any(np.isinf(twi))

    def test_roughness_shape(self, sample_dem_array):
        """Roughness output should match input shape."""
        from precision_ag.elevation_data import ElevationComputer

        rough = ElevationComputer._compute_roughness(sample_dem_array)

        assert rough.shape == sample_dem_array.shape
        assert rough.dtype == np.float32

    def test_roughness_flat_is_zero(self):
        """Roughness of a flat surface should be ~0."""
        from precision_ag.elevation_data import ElevationComputer

        flat = np.ones((50, 50), dtype=np.float32) * 100.0
        rough = ElevationComputer._compute_roughness(flat)

        np.testing.assert_allclose(rough, 0.0, atol=1e-6)

    @patch("precision_ag.elevation_data.Client")
    def test_slope_reasonable_with_geographic_crs(
        self, mock_client, sample_dem_array, sample_dem_metadata_geographic, sample_aoi_bbox
    ):
        """Slope through compute_terrain_products with geographic CRS (NAD83)
        should produce realistic values, not ~90 degrees."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        with patch.object(
            ec, "fetch_dem", return_value=(sample_dem_array, sample_dem_metadata_geographic)
        ):
            results = ec.compute_terrain_products(
                sample_aoi_bbox, products=["slope"]
            )

        slope = results["slope"][0]
        # A gentle synthetic bowl should have slopes well below 45 degrees
        assert slope.mean() < 45, (
            f"Mean slope {slope.mean():.1f}° is unrealistically steep — "
            f"resolution_m likely not converted from degrees"
        )

    @patch("precision_ag.elevation_data.Client")
    def test_resolution_computed_for_geographic_crs(
        self, mock_client, sample_dem_array, sample_dem_metadata_geographic, sample_aoi_bbox
    ):
        """fetch_dem should convert degree pixel size to meters for geographic CRS."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer(source="cop-dem-glo-30")

        mock_search = MagicMock()
        mock_search.items.return_value = iter([MagicMock()])
        ec.catalog.search.return_value = mock_search

        with patch.object(
            ec, "_mosaic_tiles", return_value=(sample_dem_array, sample_dem_metadata_geographic)
        ):
            _, meta = ec.fetch_dem(sample_aoi_bbox)

        # Pixel size in degrees is ~0.0001; in meters should be ~8-12m at this latitude
        assert meta["resolution_m"] > 1, (
            f"resolution_m={meta['resolution_m']} looks like raw degrees, not meters"
        )
        assert meta["resolution_m"] < 200, (
            f"resolution_m={meta['resolution_m']} is unrealistically large"
        )


class TestCRSDetection:
    """Tests for _crs_is_geographic helper."""

    def test_wgs84_is_geographic(self):
        from precision_ag.elevation_data import ElevationComputer
        from rasterio.crs import CRS

        assert ElevationComputer._crs_is_geographic(CRS.from_epsg(4326)) is True

    def test_nad83_is_geographic(self):
        from precision_ag.elevation_data import ElevationComputer
        from rasterio.crs import CRS

        assert ElevationComputer._crs_is_geographic(CRS.from_epsg(4269)) is True

    def test_utm_is_not_geographic(self):
        from precision_ag.elevation_data import ElevationComputer
        from rasterio.crs import CRS

        assert ElevationComputer._crs_is_geographic(CRS.from_epsg(32614)) is False

    def test_string_fallback_4326(self):
        from precision_ag.elevation_data import ElevationComputer

        assert ElevationComputer._crs_is_geographic("EPSG:4326") is True

    def test_string_fallback_4269(self):
        from precision_ag.elevation_data import ElevationComputer

        assert ElevationComputer._crs_is_geographic("EPSG:4269") is True

    def test_string_fallback_projected(self):
        from precision_ag.elevation_data import ElevationComputer

        assert ElevationComputer._crs_is_geographic("EPSG:32614") is False


class TestFetchDEM:
    """Tests for STAC-based DEM fetching (mocked)."""

    @patch("precision_ag.elevation_data.Client")
    def test_fetch_dem_returns_tuple(self, mock_client, sample_aoi_bbox):
        """fetch_dem should return (ndarray, metadata_dict)."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        # Create a mock STAC item with a mock rasterio dataset
        mock_item = MagicMock()
        mock_item.assets = {
            "data": MagicMock(href="https://example.com/dem.tif")
        }

        # Mock the STAC search
        mock_search = MagicMock()
        mock_search.items.return_value = iter([mock_item])
        ec.catalog.search.return_value = mock_search

        # Mock planetary_computer.sign
        with patch("precision_ag.elevation_data.planetary_computer") as mock_pc:
            mock_pc.sign.return_value = mock_item

            # Mock rasterio.open
            with patch("precision_ag.elevation_data.rasterio") as mock_rio:
                mock_src = MagicMock()
                mock_src.crs = "EPSG:4326"
                mock_src.nodata = -9999
                mock_src.meta = {
                    "driver": "GTiff",
                    "dtype": "float32",
                    "width": 100,
                    "height": 100,
                    "count": 1,
                    "crs": "EPSG:4326",
                    "transform": MagicMock(__getitem__=lambda s, k: 0.0003 if k == 0 else 0),
                }

                # mask returns (array, transform)
                dem_data = np.random.rand(1, 50, 50).astype(np.float32) * 100
                mock_rio.mask.mask.return_value = (dem_data, MagicMock())
                mock_rio.open.return_value.__enter__ = MagicMock(
                    return_value=mock_src
                )
                mock_rio.open.return_value.__exit__ = MagicMock(
                    return_value=False
                )

                # Patch _mosaic_tiles to avoid complex rasterio mocking
                with patch.object(
                    ec,
                    "_mosaic_tiles",
                    return_value=(
                        dem_data[0],
                        {
                            "driver": "GTiff",
                            "dtype": "float32",
                            "width": 50,
                            "height": 50,
                            "count": 1,
                            "crs": "EPSG:4326",
                            "transform": MagicMock(
                                __getitem__=lambda s, k: 0.0003 if k == 0 else 0,
                                __abs__=lambda s: 0.0003,
                            ),
                            "nodata": np.nan,
                        },
                    ),
                ):
                    result = ec.fetch_dem(sample_aoi_bbox)

                    assert isinstance(result, tuple)
                    assert len(result) == 2
                    assert isinstance(result[0], np.ndarray)
                    assert isinstance(result[1], dict)

    @patch("precision_ag.elevation_data.Client")
    def test_fetch_dem_no_tiles_raises(self, mock_client, sample_aoi_bbox):
        """fetch_dem should raise ElevationDataError when no tiles found."""
        from precision_ag.elevation_data import ElevationComputer, ElevationDataError

        ec = ElevationComputer()

        mock_search = MagicMock()
        mock_search.items.return_value = iter([])
        ec.catalog.search.return_value = mock_search

        with pytest.raises(ElevationDataError, match="No DEM tiles found"):
            ec.fetch_dem(sample_aoi_bbox)

    @patch("precision_ag.elevation_data.Client")
    def test_compute_terrain_products_invalid_product(
        self, mock_client, sample_aoi_bbox
    ):
        """Requesting unknown product should raise ValueError."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        with pytest.raises(ValueError, match="Unknown terrain product"):
            ec.compute_terrain_products(
                sample_aoi_bbox, products=["nonexistent"]
            )

    @patch("precision_ag.elevation_data.Client")
    def test_compute_terrain_products_returns_dict(
        self, mock_client, sample_dem_array, sample_dem_metadata, sample_aoi_bbox
    ):
        """compute_terrain_products should return a dict of results."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        # Mock fetch_dem to return our synthetic data
        with patch.object(
            ec, "fetch_dem", return_value=(sample_dem_array, sample_dem_metadata)
        ):
            results = ec.compute_terrain_products(
                sample_aoi_bbox, products=["slope", "aspect"]
            )

            assert isinstance(results, dict)
            assert "slope" in results
            assert "aspect" in results
            assert results["slope"][0].shape == sample_dem_array.shape
            assert results["aspect"][0].shape == sample_dem_array.shape


class TestSamplePoints:
    """Tests for batch point sampling."""

    @patch("precision_ag.elevation_data.Client")
    def test_sample_points_returns_list_of_dicts(
        self, mock_client, sample_dem_array, sample_dem_metadata
    ):
        """sample_points should return one dict per input point."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        points = [(38.45, -96.55), (38.46, -96.54)]

        with patch.object(
            ec, "fetch_dem", return_value=(sample_dem_array, sample_dem_metadata)
        ):
            results = ec.sample_points(points, products=["elevation"])

        assert isinstance(results, list)
        assert len(results) == 2
        assert "lat" in results[0]
        assert "lon" in results[0]
        assert "elevation" in results[0]

    @patch("precision_ag.elevation_data.Client")
    def test_sample_points_preserves_coordinates(
        self, mock_client, sample_dem_array, sample_dem_metadata
    ):
        """Returned dicts should contain the original lat/lon."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        points = [(38.45, -96.55)]

        with patch.object(
            ec, "fetch_dem", return_value=(sample_dem_array, sample_dem_metadata)
        ):
            results = ec.sample_points(points, products=["elevation"])

        assert results[0]["lat"] == 38.45
        assert results[0]["lon"] == -96.55

    @patch("precision_ag.elevation_data.Client")
    def test_sample_points_multiple_products(
        self, mock_client, sample_dem_array, sample_dem_metadata
    ):
        """Should return values for all requested products."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        points = [(38.45, -96.55)]

        with patch.object(
            ec, "fetch_dem", return_value=(sample_dem_array, sample_dem_metadata)
        ):
            results = ec.sample_points(
                points, products=["elevation", "slope", "aspect"]
            )

        assert "elevation" in results[0]
        assert "slope" in results[0]
        assert "aspect" in results[0]

    @patch("precision_ag.elevation_data.Client")
    def test_sample_points_empty_raises(self, mock_client):
        """Empty points list should raise ValueError."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        with pytest.raises(ValueError, match="points list must not be empty"):
            ec.sample_points([])

    @patch("precision_ag.elevation_data.Client")
    def test_sample_points_invalid_product_raises(self, mock_client):
        """Unknown product should raise ValueError."""
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()

        with pytest.raises(ValueError, match="Unknown terrain product"):
            ec.sample_points([(38.45, -96.55)], products=["nonexistent"])


class TestComputeStatistics:
    """Tests for the statistics method."""

    @patch("precision_ag.elevation_data.Client")
    def test_statistics_keys(self, mock_client, sample_dem_array, sample_dem_metadata):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        results = {
            "elevation": (sample_dem_array, sample_dem_metadata),
        }

        stats = ec.compute_statistics(results)

        assert "elevation" in stats
        for key in ("mean", "median", "std", "min", "max", "valid_pixels", "total_pixels"):
            assert key in stats["elevation"]

    @patch("precision_ag.elevation_data.Client")
    def test_statistics_all_nan(self, mock_client):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer()
        nan_arr = np.full((10, 10), np.nan, dtype=np.float32)
        results = {"test": (nan_arr, {})}

        stats = ec.compute_statistics(results)
        assert stats["test"] == {"error": "No valid data"}


class TestCheckUSCoverage:
    """Tests for the _check_us_coverage warning."""

    @patch("precision_ag.elevation_data.Client")
    def test_warns_outside_conus(self, mock_client):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer(source="3dep-seamless")

        # AOI in Europe
        aoi = {
            "type": "Polygon",
            "coordinates": [
                [[10.0, 50.0], [11.0, 50.0], [11.0, 51.0], [10.0, 51.0], [10.0, 50.0]]
            ],
        }

        with pytest.warns(UserWarning, match="outside the continental US"):
            ec._check_us_coverage(aoi)

    @patch("precision_ag.elevation_data.Client")
    def test_no_warning_inside_conus(self, mock_client, sample_aoi_geojson):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer(source="3dep-seamless")

        # Kansas AOI (inside CONUS) — should not warn
        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("error")
            ec._check_us_coverage(sample_aoi_geojson)

    @patch("precision_ag.elevation_data.Client")
    def test_no_warning_for_copernicus(self, mock_client):
        from precision_ag.elevation_data import ElevationComputer

        ec = ElevationComputer(source="cop-dem-glo-30")

        # Should never warn for non-3DEP sources
        aoi = {
            "type": "Polygon",
            "coordinates": [
                [[10.0, 50.0], [11.0, 50.0], [11.0, 51.0], [10.0, 51.0], [10.0, 50.0]]
            ],
        }

        import warnings

        with warnings.catch_warnings():
            warnings.simplefilter("error")
            ec._check_us_coverage(aoi)


class TestConvenienceFunction:
    """Tests for the compute_elevation_for_aoi convenience function."""

    def test_importable(self):
        """Convenience function should be importable from the package."""
        from precision_ag.elevation_data import compute_elevation_for_aoi

        assert callable(compute_elevation_for_aoi)

    def test_importable_from_package(self):
        """Should be importable from top-level package."""
        from precision_ag import compute_elevation_for_aoi

        assert callable(compute_elevation_for_aoi)

    @patch("precision_ag.elevation_data.Client")
    def test_returns_elevation_tuple(
        self, mock_client, sample_dem_array, sample_dem_metadata, sample_aoi_bbox
    ):
        """compute_elevation_for_aoi should return (array, metadata) tuple."""
        from precision_ag.elevation_data import compute_elevation_for_aoi

        with patch(
            "precision_ag.elevation_data.ElevationComputer.fetch_dem",
            return_value=(sample_dem_array, sample_dem_metadata),
        ):
            result = compute_elevation_for_aoi(sample_aoi_bbox)

            assert isinstance(result, tuple)
            assert len(result) == 2
            assert isinstance(result[0], np.ndarray)
            assert isinstance(result[1], dict)


class TestConveniencePointFunction:
    """Tests for the compute_elevation_for_points convenience function."""

    def test_importable(self):
        """Convenience function should be importable from the package."""
        from precision_ag.elevation_data import compute_elevation_for_points

        assert callable(compute_elevation_for_points)

    def test_importable_from_package(self):
        """Should be importable from top-level package."""
        from precision_ag import compute_elevation_for_points

        assert callable(compute_elevation_for_points)

    @patch("precision_ag.elevation_data.Client")
    def test_returns_elevation_for_points(
        self, mock_client, sample_dem_array, sample_dem_metadata
    ):
        """compute_elevation_for_points should return list of dicts with elevation only."""
        from precision_ag.elevation_data import compute_elevation_for_points

        points = [(38.45, -96.55), (38.46, -96.54)]

        with patch(
            "precision_ag.elevation_data.ElevationComputer.fetch_dem",
            return_value=(sample_dem_array, sample_dem_metadata),
        ):
            result = compute_elevation_for_points(points)

            assert isinstance(result, list)
            assert len(result) == 2
            assert "lat" in result[0]
            assert "lon" in result[0]
            assert "elevation" in result[0]
            # Should only have elevation, not slope or other products
            assert "slope" not in result[0]


class TestErrorClass:
    """Test the custom exception class."""

    def test_elevation_data_error_importable(self):
        from precision_ag.elevation_data import ElevationDataError

        assert issubclass(ElevationDataError, Exception)

    def test_elevation_data_error_from_package(self):
        from precision_ag import ElevationDataError

        assert issubclass(ElevationDataError, Exception)

    def test_elevation_data_error_message(self):
        from precision_ag.elevation_data import ElevationDataError

        err = ElevationDataError("test error")
        assert str(err) == "test error"
