"""
Unit tests for satellite_indices module.
"""

import numpy as np
import pytest
from unittest.mock import patch
import json


class TestAgIndexComputer:
    """Tests for the AgIndexComputer class."""

    def test_import_main_class(self):
        """Test that AgIndexComputer can be imported."""
        from precision_ag.satellite_indices import AgIndexComputer

        assert AgIndexComputer is not None

    @patch("precision_ag.satellite_indices.Client")
    def test_init_default_catalog(self, mock_client):
        """Test initialization with default catalog."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer()

        assert computer.collection == "sentinel-2-l2a"
        assert "planetarycomputer" in computer.catalog_url

    @patch("precision_ag.satellite_indices.Client")
    def test_get_available_indices_sentinel2(self, mock_client):
        """Test getting available indices for Sentinel-2."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer(collection="sentinel-2-l2a")
        indices = computer.get_available_indices()

        # Sentinel-2 should have all indices including NDRE
        assert "ndvi" in indices
        assert "evi" in indices
        assert "savi" in indices
        assert "ndre" in indices
        assert "gndvi" in indices

    @patch("precision_ag.satellite_indices.Client")
    def test_get_available_indices_landsat(self, mock_client):
        """Test getting available indices for Landsat."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer(collection="landsat-c2-l2")
        indices = computer.get_available_indices()

        # Landsat should NOT have NDRE (no red edge band)
        assert "ndvi" in indices
        assert "ndre" not in indices


class TestAOILoading:
    """Tests for AOI loading functionality."""

    @patch("precision_ag.satellite_indices.Client")
    def test_load_aoi_bbox(self, mock_client, sample_aoi_bbox):
        """Test loading AOI from bounding box."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer()
        geometry = computer.load_aoi(sample_aoi_bbox)

        assert geometry["type"] == "Polygon"
        assert len(geometry["coordinates"]) == 1
        assert len(geometry["coordinates"][0]) == 5  # Closed polygon

    @patch("precision_ag.satellite_indices.Client")
    def test_load_aoi_polygon(self, mock_client, sample_aoi_polygon):
        """Test loading AOI from polygon coordinates."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer()
        geometry = computer.load_aoi(sample_aoi_polygon)

        assert geometry["type"] == "Polygon"
        # Should auto-close the polygon
        coords = geometry["coordinates"][0]
        assert coords[0] == coords[-1]

    @patch("precision_ag.satellite_indices.Client")
    def test_load_aoi_geojson_dict(self, mock_client, sample_aoi_geojson):
        """Test loading AOI from GeoJSON dict."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer()
        geometry = computer.load_aoi(sample_aoi_geojson)

        assert geometry == sample_aoi_geojson

    @patch("precision_ag.satellite_indices.Client")
    def test_load_aoi_from_file(self, mock_client, sample_aoi_geojson, tmp_path):
        """Test loading AOI from GeoJSON file."""
        from precision_ag.satellite_indices import AgIndexComputer

        # Write sample GeoJSON to file
        geojson_file = tmp_path / "aoi.geojson"
        with open(geojson_file, "w") as f:
            json.dump(sample_aoi_geojson, f)

        computer = AgIndexComputer()
        geometry = computer.load_aoi(str(geojson_file))

        assert geometry["type"] == "Polygon"

    @patch("precision_ag.satellite_indices.Client")
    def test_load_aoi_invalid_input(self, mock_client):
        """Test that invalid AOI input raises error."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer()

        with pytest.raises(ValueError):
            computer.load_aoi("invalid")

        with pytest.raises(ValueError):
            computer.load_aoi([1, 2])  # Too few coordinates


class TestIndexComputation:
    """Tests for vegetation index computation."""

    def test_compute_ndvi(self, sample_bands):
        """Test NDVI computation."""
        # Access the internal computation method
        nir = sample_bands["nir"]
        red = sample_bands["red"]

        # NDVI = (NIR - Red) / (NIR + Red)
        expected = (nir - red) / (nir + red)

        # Values should be in [-1, 1]
        assert np.all(expected >= -1)
        assert np.all(expected <= 1)

    def test_compute_evi(self, sample_bands):
        """Test EVI computation."""
        nir = sample_bands["nir"]
        red = sample_bands["red"]
        blue = sample_bands["blue"]

        # EVI = 2.5 * (NIR - Red) / (NIR + 6*Red - 7.5*Blue + 1)
        denominator = nir + 6 * red - 7.5 * blue + 1
        evi = np.where(denominator != 0, 2.5 * (nir - red) / denominator, np.nan)

        # Should produce valid results
        valid_evi = evi[~np.isnan(evi)]
        assert len(valid_evi) > 0

    def test_compute_savi(self, sample_bands):
        """Test SAVI computation."""
        nir = sample_bands["nir"]
        red = sample_bands["red"]
        L = 0.5

        # SAVI = ((NIR - Red) / (NIR + Red + L)) * (1 + L)
        denominator = nir + red + L
        savi = np.where(denominator != 0, ((nir - red) / denominator) * (1 + L), np.nan)

        valid_savi = savi[~np.isnan(savi)]
        assert len(valid_savi) > 0

    def test_compute_ndre(self, sample_bands):
        """Test NDRE computation."""
        nir = sample_bands["nir"]
        rededge = sample_bands["rededge"]

        # NDRE = (NIR - RedEdge) / (NIR + RedEdge)
        denominator = nir + rededge
        ndre = np.where(denominator != 0, (nir - rededge) / denominator, np.nan)

        valid_ndre = ndre[~np.isnan(ndre)]
        assert len(valid_ndre) > 0
        # Values should be in [-1, 1]
        assert np.all(valid_ndre >= -1)
        assert np.all(valid_ndre <= 1)

    def test_compute_gndvi(self, sample_bands):
        """Test GNDVI computation."""
        nir = sample_bands["nir"]
        green = sample_bands["green"]

        # GNDVI = (NIR - Green) / (NIR + Green)
        denominator = nir + green
        gndvi = np.where(denominator != 0, (nir - green) / denominator, np.nan)

        valid_gndvi = gndvi[~np.isnan(gndvi)]
        assert len(valid_gndvi) > 0


class TestStatistics:
    """Tests for statistics computation."""

    @patch("precision_ag.satellite_indices.Client")
    def test_compute_statistics(self, mock_client, sample_ndvi_array):
        """Test statistics computation on results."""
        from precision_ag.satellite_indices import AgIndexComputer

        computer = AgIndexComputer()

        # Create mock results
        metadata = {"dtype": "float32", "width": 100, "height": 100}
        results = {"ndvi": (sample_ndvi_array, metadata)}

        stats = computer.compute_statistics(results)

        assert "ndvi" in stats
        assert "mean" in stats["ndvi"]
        assert "std" in stats["ndvi"]
        assert "min" in stats["ndvi"]
        assert "max" in stats["ndvi"]
        assert "valid_pixels" in stats["ndvi"]

        # Check values are reasonable
        assert -1 <= stats["ndvi"]["mean"] <= 1
        assert stats["ndvi"]["valid_pixels"] > 0


class TestBackwardCompatibility:
    """Tests for backward compatibility functions."""

    def test_compute_ndvi_for_aoi_exists(self):
        """Test that compute_ndvi_for_aoi function exists."""
        from precision_ag.satellite_indices import compute_ndvi_for_aoi

        assert callable(compute_ndvi_for_aoi)

    def test_compute_vegetation_indices_for_aoi_exists(self):
        """Test that compute_vegetation_indices_for_aoi function exists."""
        from precision_ag.satellite_indices import compute_vegetation_indices_for_aoi

        assert callable(compute_vegetation_indices_for_aoi)

    def test_compute_agricultural_indices_for_aoi_exists(self):
        """Test that compute_agricultural_indices_for_aoi function exists."""
        from precision_ag.satellite_indices import compute_agricultural_indices_for_aoi

        assert callable(compute_agricultural_indices_for_aoi)


class TestCloudCoverFiltering:
    """Tests for cloud cover filtering functionality."""

    @patch("precision_ag.satellite_indices.Client")
    def test_calculate_aoi_cloud_cover_sentinel2(self, mock_client, sample_cloud_mask_scl):
        """Test cloud cover calculation for Sentinel-2."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="sentinel-2-l2a")

        # Mock the _load_band method to return our sample cloud mask
        with patch.object(computer, "_load_band", return_value=(sample_cloud_mask_scl, {}, None)):
            mock_item = MagicMock()
            mock_item.id = "test_scene"
            aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}

            cloud_percentage = computer.calculate_aoi_cloud_cover(mock_item, aoi_geometry)

            # Expected: 8% cloud cover (800 out of 10000 pixels)
            assert 7.5 <= cloud_percentage <= 8.5

    @patch("precision_ag.satellite_indices.Client")
    def test_calculate_aoi_cloud_cover_landsat(self, mock_client, sample_cloud_mask_qa):
        """Test cloud cover calculation for Landsat."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="landsat-c2-l2")

        # Mock the _load_band method to return our sample cloud mask
        with patch.object(computer, "_load_band", return_value=(sample_cloud_mask_qa, {}, None)):
            mock_item = MagicMock()
            mock_item.id = "test_scene"
            aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}

            cloud_percentage = computer.calculate_aoi_cloud_cover(mock_item, aoi_geometry)

            # Expected: 7.5% cloud cover (750 out of 10000 pixels)
            assert 7.0 <= cloud_percentage <= 8.0

    @patch("precision_ag.satellite_indices.Client")
    def test_calculate_aoi_cloud_cover_fallback(self, mock_client):
        """Test fallback to scene-level cloud cover on error."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="sentinel-2-l2a")

        # Mock _load_band to raise an exception
        with patch.object(computer, "_load_band", side_effect=ValueError("Band not found")):
            mock_item = MagicMock()
            mock_item.id = "test_scene"
            mock_item.properties = {"eo:cloud_cover": 15.5}
            aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}

            cloud_percentage = computer.calculate_aoi_cloud_cover(mock_item, aoi_geometry)

            # Should fallback to scene-level cloud cover
            assert cloud_percentage == 15.5

    @patch("precision_ag.satellite_indices.Client")
    def test_search_with_aoi_cloud_filter_enabled(self, mock_client, sample_cloud_mask_scl):
        """Test search with AOI cloud filtering enabled."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="sentinel-2-l2a")

        # Mock catalog search to return items
        mock_item1 = MagicMock()
        mock_item1.id = "scene1"
        mock_item1.properties = {"eo:cloud_cover": 10}

        mock_item2 = MagicMock()
        mock_item2.id = "scene2"
        mock_item2.properties = {"eo:cloud_cover": 5}

        mock_search = MagicMock()
        mock_search.items.return_value = [mock_item1, mock_item2]
        computer.catalog.search = MagicMock(return_value=mock_search)

        # Mock calculate_aoi_cloud_cover to return different values
        with patch.object(
            computer, "calculate_aoi_cloud_cover", side_effect=[15.0, 5.0]  # scene1 has 15%  # scene2 has 5%
        ):
            aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}
            items = computer.search_satellite_data(
                aoi_geometry,
                start_date="2024-06-01",
                end_date="2024-06-30",
                max_cloud_cover=10,
                aoi_cloud_filter=True,
            )

            # Only scene2 should pass (5% <= 10%)
            assert len(items) == 1
            assert items[0].id == "scene2"

    @patch("precision_ag.satellite_indices.Client")
    def test_search_without_aoi_cloud_filter(self, mock_client):
        """Test search with scene-level filtering only."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="sentinel-2-l2a")

        # Mock catalog search to return items
        mock_item1 = MagicMock()
        mock_item1.id = "scene1"
        mock_item1.properties = {"eo:cloud_cover": 8}

        mock_item2 = MagicMock()
        mock_item2.id = "scene2"
        mock_item2.properties = {"eo:cloud_cover": 5}

        mock_search = MagicMock()
        mock_search.items.return_value = [mock_item1, mock_item2]
        computer.catalog.search = MagicMock(return_value=mock_search)

        aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}
        items = computer.search_satellite_data(
            aoi_geometry,
            start_date="2024-06-01",
            end_date="2024-06-30",
            max_cloud_cover=10,
            aoi_cloud_filter=False,
        )

        # Both scenes should be returned (no AOI filtering)
        assert len(items) == 2

    @patch("precision_ag.satellite_indices.Client")
    def test_aoi_filter_doesnt_reject_good_scenes(self, mock_client):
        """Test that AOI filtering doesn't reject scenes with high scene-level but low AOI cloud cover."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="sentinel-2-l2a")

        # Mock a scene with HIGH scene-level cloud cover (50%)
        # but LOW AOI cloud cover (5%)
        mock_item = MagicMock()
        mock_item.id = "scene_with_clouds_elsewhere"
        mock_item.properties = {"eo:cloud_cover": 50}  # 50% scene-level

        mock_search = MagicMock()
        mock_search.items.return_value = [mock_item]
        computer.catalog.search = MagicMock(return_value=mock_search)

        # Mock AOI cloud cover to be low (5%)
        with patch.object(computer, "calculate_aoi_cloud_cover", return_value=5.0):
            aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}
            items = computer.search_satellite_data(
                aoi_geometry,
                start_date="2024-06-01",
                end_date="2024-06-30",
                max_cloud_cover=10,  # User wants < 10% over AOI
                aoi_cloud_filter=True,
            )

            # Scene should be KEPT because AOI has only 5% cloud cover
            # even though overall scene has 50%
            assert len(items) == 1
            assert items[0].id == "scene_with_clouds_elsewhere"

            # Verify that catalog.search was called with threshold of 100 (not 10)
            # to avoid rejecting this scene prematurely
            search_call = computer.catalog.search.call_args
            assert search_call[1]["query"]["eo:cloud_cover"]["lt"] == 100

    @patch("precision_ag.satellite_indices.Client")
    def test_cloud_cover_default_behavior(self, mock_client):
        """Test that AOI filtering is enabled by default when max_cloud_cover < 100."""
        from precision_ag.satellite_indices import AgIndexComputer
        from unittest.mock import MagicMock

        computer = AgIndexComputer(collection="sentinel-2-l2a")

        mock_search = MagicMock()
        mock_search.items.return_value = []
        computer.catalog.search = MagicMock(return_value=mock_search)

        aoi_geometry = {"type": "Polygon", "coordinates": [[[-96.6, 38.4]]]}

        # Test with max_cloud_cover < 100 (should enable AOI filtering)
        with patch.object(computer, "calculate_aoi_cloud_cover") as mock_calc:
            items = computer.search_satellite_data(
                aoi_geometry,
                start_date="2024-06-01",
                end_date="2024-06-30",
                max_cloud_cover=20,  # < 100
                aoi_cloud_filter=None,  # Use default behavior
            )
            # AOI filtering should be enabled, but no items to filter
            # Just verify no errors occurred

        # Test with max_cloud_cover = 100 (should NOT enable AOI filtering)
        with patch.object(computer, "calculate_aoi_cloud_cover") as mock_calc:
            items = computer.search_satellite_data(
                aoi_geometry,
                start_date="2024-06-01",
                end_date="2024-06-30",
                max_cloud_cover=100,  # = 100
                aoi_cloud_filter=None,  # Use default behavior
            )
            # calculate_aoi_cloud_cover should NOT be called
            mock_calc.assert_not_called()
