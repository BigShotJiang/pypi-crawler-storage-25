"""
Unit tests for weather_data module (NASA POWER Weather API integration).
"""

import json
import numpy as np
import pytest
from unittest.mock import patch, MagicMock
import urllib.error

from weather_data import NASAPowerWeather


class TestNASAPowerWeather:
    """Tests for the NASAPowerWeather class."""

    def test_import_class(self):
        """Test that NASAPowerWeather can be imported."""
        assert NASAPowerWeather is not None

    def test_init_default_params(self):
        """Test initialization with default growing season."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)

        assert weather.latitude == 41.5
        assert weather.longitude == -93.5
        assert weather.growing_season_start == 4
        assert weather.growing_season_end == 9

    def test_init_custom_growing_season(self):
        """Test initialization with custom growing season."""
        weather = NASAPowerWeather(
            latitude=35.0, longitude=-120.0, growing_season_months=(5, 10)
        )

        assert weather.growing_season_start == 5
        assert weather.growing_season_end == 10

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_success(self, mock_urlopen):
        """Test successful precipitation query."""
        # Mock API response
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {
                        "20200401": 10.5,
                        "20200402": 5.2,
                        "20200403": 0.0,
                        "20200404": 15.8,
                        "20200405": 3.1,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip is not None
        assert precip == pytest.approx(34.6, rel=0.01)  # Sum of valid values

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_filters_invalid(self, mock_urlopen):
        """Test that missing values (-999) are filtered out."""
        # Mock API response with some missing values
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {
                        "20200401": 10.5,
                        "20200402": -999,  # Missing value
                        "20200403": 5.2,
                        "20200404": None,  # Another form of missing
                        "20200405": 3.1,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip == pytest.approx(18.8, rel=0.01)  # Only valid values

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_empty_response(self, mock_urlopen):
        """Test handling of empty API response."""
        mock_response_data = {"properties": {"parameter": {}}}

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip is None

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_all_invalid(self, mock_urlopen):
        """Test handling when all values are invalid."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {
                        "20200401": -999,
                        "20200402": -999,
                        "20200403": -999,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip is None

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_network_error(self, mock_urlopen):
        """Test handling of network errors."""
        mock_urlopen.side_effect = urllib.error.URLError("Network error")

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip is None

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_http_error(self, mock_urlopen):
        """Test handling of HTTP errors."""
        mock_urlopen.side_effect = urllib.error.HTTPError(
            "url", 500, "Server Error", {}, None
        )

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip is None

    @patch("urllib.request.urlopen")
    def test_get_growing_season_precipitation_json_error(self, mock_urlopen):
        """Test handling of invalid JSON response."""
        mock_response = MagicMock()
        mock_response.read.return_value = b"not valid json"
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_growing_season_precipitation(2020)

        assert precip is None

    @patch("urllib.request.urlopen")
    def test_classify_years_three_terciles(self, mock_urlopen):
        """Test classification of years into dry/normal/wet terciles."""
        # Mock responses for different years with different precipitation
        def mock_side_effect(*args, **kwargs):
            url = args[0].full_url if hasattr(args[0], "full_url") else str(args[0])

            # Extract year from URL
            if "start=2019" in url:
                precip = 300.0  # Dry
            elif "start=2020" in url:
                precip = 500.0  # Normal
            elif "start=2021" in url:
                precip = 700.0  # Wet
            elif "start=2022" in url:
                precip = 400.0  # Normal
            elif "start=2023" in url:
                precip = 600.0  # Normal
            else:
                precip = 500.0

            response_data = {
                "properties": {
                    "parameter": {"PRECTOTCORR": {"20200401": precip}}
                }
            }

            mock_response = MagicMock()
            mock_response.read.return_value = json.dumps(response_data).encode("utf-8")
            mock_response.__enter__.return_value = mock_response
            return mock_response

        mock_urlopen.side_effect = mock_side_effect

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        classification = weather.classify_years([2019, 2020, 2021, 2022, 2023])

        assert len(classification["dry"]) >= 1
        assert len(classification["normal"]) >= 1
        assert len(classification["wet"]) >= 1
        assert 2019 in classification["dry"]  # 300mm is lowest
        assert 2021 in classification["wet"]  # 700mm is highest

    @patch("urllib.request.urlopen")
    def test_classify_years_fewer_than_three(self, mock_urlopen):
        """Test that years with < 3 data points are all classified as normal."""
        # Mock successful response
        mock_response_data = {
            "properties": {"parameter": {"PRECTOTCORR": {"20200401": 500.0}}}
        }
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        classification = weather.classify_years([2020, 2021])  # Only 2 years

        assert len(classification["normal"]) == 2
        assert len(classification["dry"]) == 0
        assert len(classification["wet"]) == 0

    def test_power_url_constant(self):
        """Test that the POWER_URL constant is set correctly."""
        assert "power.larc.nasa.gov" in NASAPowerWeather.POWER_URL
        assert "temporal/daily/point" in NASAPowerWeather.POWER_URL

    @patch("urllib.request.urlopen")
    def test_get_growing_season_temperature_mean(self, mock_urlopen):
        """Test successful temperature (mean) query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "T2M": {
                        "20200401": 15.5,
                        "20200402": 16.2,
                        "20200403": 14.8,
                        "20200404": 17.1,
                        "20200405": 15.9,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        temp = weather.get_growing_season_temperature(2020, stat="mean")

        assert temp is not None
        assert temp == pytest.approx(15.9, rel=0.01)  # Mean of values

    @patch("urllib.request.urlopen")
    def test_get_growing_season_temperature_max(self, mock_urlopen):
        """Test successful temperature (max) query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "T2M_MAX": {
                        "20200401": 20.5,
                        "20200402": 21.2,
                        "20200403": 19.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        temp = weather.get_growing_season_temperature(2020, stat="max")

        assert temp is not None
        assert temp == pytest.approx(20.5, rel=0.01)

    def test_get_growing_season_temperature_invalid_stat(self):
        """Test that invalid stat raises ValueError."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        
        with pytest.raises(ValueError, match="Invalid stat"):
            weather.get_growing_season_temperature(2020, stat="invalid")

    @patch("urllib.request.urlopen")
    def test_get_growing_season_solar_radiation(self, mock_urlopen):
        """Test successful solar radiation query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "ALLSKY_SFC_SW_DWN": {
                        "20200401": 18.5,
                        "20200402": 19.2,
                        "20200403": 17.8,
                        "20200404": 20.1,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        solar = weather.get_growing_season_solar_radiation(2020)

        assert solar is not None
        assert solar == pytest.approx(18.9, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_growing_season_humidity(self, mock_urlopen):
        """Test successful humidity query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "RH2M": {
                        "20200401": 65.5,
                        "20200402": 68.2,
                        "20200403": 62.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        humidity = weather.get_growing_season_humidity(2020)

        assert humidity is not None
        assert humidity == pytest.approx(65.5, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_growing_season_wind_speed(self, mock_urlopen):
        """Test successful wind speed query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "WS2M": {
                        "20200401": 3.5,
                        "20200402": 4.2,
                        "20200403": 2.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        wind = weather.get_growing_season_wind_speed(2020)

        assert wind is not None
        assert wind == pytest.approx(3.5, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_all_weather_parameters(self, mock_urlopen):
        """Test fetching all weather parameters at once."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {"20200401": 10.5, "20200402": 5.2},
                    "T2M": {"20200401": 15.5, "20200402": 16.2},
                    "T2M_MAX": {"20200401": 20.5, "20200402": 21.2},
                    "T2M_MIN": {"20200401": 10.5, "20200402": 11.2},
                    "ALLSKY_SFC_SW_DWN": {"20200401": 18.5, "20200402": 19.2},
                    "RH2M": {"20200401": 65.5, "20200402": 68.2},
                    "WS2M": {"20200401": 3.5, "20200402": 4.2},
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        all_params = weather.get_all_weather_parameters(2020)

        assert all_params is not None
        assert "precipitation" in all_params
        assert "temperature_mean" in all_params
        assert "temperature_max" in all_params
        assert "temperature_min" in all_params
        assert "solar_radiation" in all_params
        assert "humidity" in all_params
        assert "wind_speed" in all_params
        
        assert all_params["precipitation"] == pytest.approx(15.7, rel=0.01)
        assert all_params["temperature_mean"] == pytest.approx(15.85, rel=0.01)
        assert all_params["temperature_max"] == pytest.approx(20.85, rel=0.01)
        assert all_params["temperature_min"] == pytest.approx(10.85, rel=0.01)
        assert all_params["solar_radiation"] == pytest.approx(18.85, rel=0.01)
        assert all_params["humidity"] == pytest.approx(66.85, rel=0.01)
        assert all_params["wind_speed"] == pytest.approx(3.85, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_all_weather_parameters_handles_missing_values(self, mock_urlopen):
        """Test that all weather parameters handles missing values correctly."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {"20200401": 10.5, "20200402": -999},
                    "T2M": {"20200401": 15.5, "20200402": 16.2},
                    "T2M_MAX": {"20200401": -999, "20200402": 21.2},
                    "T2M_MIN": {"20200401": 10.5, "20200402": None},
                    "ALLSKY_SFC_SW_DWN": {"20200401": 18.5, "20200402": 19.2},
                    "RH2M": {"20200401": -999, "20200402": -999},
                    "WS2M": {"20200401": 3.5, "20200402": 4.2},
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        all_params = weather.get_all_weather_parameters(2020)

        assert all_params is not None
        assert all_params["precipitation"] == pytest.approx(10.5, rel=0.01)  # Only one valid
        assert all_params["temperature_max"] == pytest.approx(21.2, rel=0.01)  # Only one valid
        assert all_params["temperature_min"] == pytest.approx(10.5, rel=0.01)  # Only one valid
        assert all_params["humidity"] is None  # All invalid

    def test_validate_month_range_valid_single_month(self):
        """Test that valid single month passes validation."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        # Should not raise any exception
        weather._validate_month_range(6)

    def test_validate_month_range_valid_range(self):
        """Test that valid month range passes validation."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        # Should not raise any exception
        weather._validate_month_range(4, end_month=9)

    def test_validate_month_range_invalid_month_too_low(self):
        """Test that month < 1 raises ValueError."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="month must be between 1 and 12"):
            weather._validate_month_range(0)

    def test_validate_month_range_invalid_month_too_high(self):
        """Test that month > 12 raises ValueError."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="month must be between 1 and 12"):
            weather._validate_month_range(13)

    def test_validate_month_range_invalid_end_month_too_low(self):
        """Test that end_month < 1 raises ValueError."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="end_month must be between 1 and 12"):
            weather._validate_month_range(6, end_month=0)

    def test_validate_month_range_invalid_end_month_too_high(self):
        """Test that end_month > 12 raises ValueError."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="end_month must be between 1 and 12"):
            weather._validate_month_range(6, end_month=13)

    def test_validate_month_range_end_before_start(self):
        """Test that end_month < month raises ValueError."""
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        with pytest.raises(ValueError, match="end_month .* must be >= month"):
            weather._validate_month_range(9, end_month=4)

    @patch("urllib.request.urlopen")
    def test_get_monthly_precipitation_single_month(self, mock_urlopen):
        """Test monthly precipitation query for a single month."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {
                        "20230401": 10.5,
                        "20230402": 5.2,
                        "20230403": 8.3,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_monthly_precipitation(2023, 4)

        assert precip is not None
        assert precip == pytest.approx(24.0, rel=0.01)  # Sum of values

    @patch("urllib.request.urlopen")
    def test_get_monthly_precipitation_month_range(self, mock_urlopen):
        """Test monthly precipitation query for a month range."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {
                        "20230401": 10.5,
                        "20230501": 15.2,
                        "20230601": 20.3,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_monthly_precipitation(2023, 4, end_month=6)

        assert precip is not None
        assert precip == pytest.approx(46.0, rel=0.01)  # Sum of values

    @patch("urllib.request.urlopen")
    def test_get_monthly_temperature_single_month(self, mock_urlopen):
        """Test monthly temperature query for a single month."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "T2M": {
                        "20230701": 25.5,
                        "20230702": 26.2,
                        "20230703": 24.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        temp = weather.get_monthly_temperature(2023, 7, stat="mean")

        assert temp is not None
        assert temp == pytest.approx(25.5, rel=0.01)  # Mean of values

    @patch("urllib.request.urlopen")
    def test_get_monthly_temperature_month_range_max(self, mock_urlopen):
        """Test monthly max temperature query for a month range."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "T2M_MAX": {
                        "20230601": 30.5,
                        "20230701": 32.2,
                        "20230801": 31.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        temp = weather.get_monthly_temperature(2023, 6, end_month=8, stat="max")

        assert temp is not None
        assert temp == pytest.approx(31.5, rel=0.01)  # Mean of max values

    @patch("urllib.request.urlopen")
    def test_get_monthly_solar_radiation(self, mock_urlopen):
        """Test monthly solar radiation query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "ALLSKY_SFC_SW_DWN": {
                        "20230601": 22.5,
                        "20230602": 23.2,
                        "20230603": 21.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        solar = weather.get_monthly_solar_radiation(2023, 6)

        assert solar is not None
        assert solar == pytest.approx(22.5, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_monthly_humidity(self, mock_urlopen):
        """Test monthly humidity query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "RH2M": {
                        "20230801": 65.5,
                        "20230802": 68.2,
                        "20230803": 62.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        humidity = weather.get_monthly_humidity(2023, 8)

        assert humidity is not None
        assert humidity == pytest.approx(65.5, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_monthly_wind_speed(self, mock_urlopen):
        """Test monthly wind speed query."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "WS2M": {
                        "20230301": 4.5,
                        "20230302": 5.2,
                        "20230303": 3.8,
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        wind = weather.get_monthly_wind_speed(2023, 3)

        assert wind is not None
        assert wind == pytest.approx(4.5, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_monthly_weather_all_parameters(self, mock_urlopen):
        """Test getting all monthly weather parameters at once."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {"20230401": 10.5, "20230402": 5.2},
                    "T2M": {"20230401": 15.5, "20230402": 16.2},
                    "T2M_MAX": {"20230401": 20.5, "20230402": 21.2},
                    "T2M_MIN": {"20230401": 10.5, "20230402": 11.2},
                    "ALLSKY_SFC_SW_DWN": {"20230401": 18.5, "20230402": 19.2},
                    "RH2M": {"20230401": 65.5, "20230402": 68.2},
                    "WS2M": {"20230401": 3.5, "20230402": 4.2},
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        monthly_data = weather.get_monthly_weather(2023, 4)

        assert monthly_data is not None
        assert "precipitation" in monthly_data
        assert "temperature_mean" in monthly_data
        assert "temperature_max" in monthly_data
        assert "temperature_min" in monthly_data
        assert "solar_radiation" in monthly_data
        assert "humidity" in monthly_data
        assert "wind_speed" in monthly_data
        
        assert monthly_data["precipitation"] == pytest.approx(15.7, rel=0.01)
        assert monthly_data["temperature_mean"] == pytest.approx(15.85, rel=0.01)

    @patch("urllib.request.urlopen")
    def test_get_monthly_weather_month_range(self, mock_urlopen):
        """Test getting monthly weather for a month range."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {"20230401": 10.5, "20230501": 12.0, "20230601": 8.5},
                    "T2M": {"20230401": 15.5, "20230501": 18.0, "20230601": 22.0},
                    "T2M_MAX": {"20230401": 20.5, "20230501": 23.0, "20230601": 27.0},
                    "T2M_MIN": {"20230401": 10.5, "20230501": 13.0, "20230601": 17.0},
                    "ALLSKY_SFC_SW_DWN": {"20230401": 18.5, "20230501": 20.0, "20230601": 22.0},
                    "RH2M": {"20230401": 65.5, "20230501": 62.0, "20230601": 58.0},
                    "WS2M": {"20230401": 3.5, "20230501": 3.0, "20230601": 2.8},
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        spring_data = weather.get_monthly_weather(2023, 4, end_month=6)

        assert spring_data is not None
        assert spring_data["precipitation"] == pytest.approx(31.0, rel=0.01)  # Sum
        assert spring_data["temperature_mean"] == pytest.approx(18.5, rel=0.01)  # Mean

    @patch("urllib.request.urlopen")
    def test_get_monthly_weather_filtered_parameters(self, mock_urlopen):
        """Test getting only specific monthly weather parameters."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {"20230401": 10.5},
                    "T2M": {"20230401": 15.5},
                    "T2M_MAX": {"20230401": 20.5},
                    "T2M_MIN": {"20230401": 10.5},
                    "ALLSKY_SFC_SW_DWN": {"20230401": 18.5},
                    "RH2M": {"20230401": 65.5},
                    "WS2M": {"20230401": 3.5},
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        filtered_data = weather.get_monthly_weather(
            2023, 4, parameters=["precipitation", "temperature_mean"]
        )

        assert filtered_data is not None
        assert len(filtered_data) == 2
        assert "precipitation" in filtered_data
        assert "temperature_mean" in filtered_data
        assert "humidity" not in filtered_data
        assert "wind_speed" not in filtered_data

    @patch("urllib.request.urlopen")
    def test_get_monthly_precipitation_handles_missing_values(self, mock_urlopen):
        """Test that monthly precipitation correctly filters missing values."""
        mock_response_data = {
            "properties": {
                "parameter": {
                    "PRECTOTCORR": {
                        "20230401": 10.5,
                        "20230402": -999,  # Missing
                        "20230403": 5.2,
                        "20230404": None,  # Missing
                    }
                }
            }
        }

        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps(mock_response_data).encode("utf-8")
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        precip = weather.get_monthly_precipitation(2023, 4)

        assert precip is not None
        assert precip == pytest.approx(15.7, rel=0.01)  # Only valid values

    @patch("urllib.request.urlopen")
    def test_get_monthly_weather_network_error(self, mock_urlopen):
        """Test handling of network errors in monthly queries."""
        mock_urlopen.side_effect = urllib.error.URLError("Network error")

        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        result = weather.get_monthly_precipitation(2023, 4)

        assert result is None
