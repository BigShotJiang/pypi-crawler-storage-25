"""
Unit tests for crop_data module (USDA CropScape / Cropland Data Layer integration).
"""

import json
import pytest
from unittest.mock import patch, MagicMock
import urllib.error

from crop_data import CroplandCROS, CROP_CODES, CropScapeAPIError

# CropScape API uses two-step flow: (1) XML with returnURL, (2) JSON from returnURL
CROPSCAPE_XML_RESPONSE = """<?xml version="1.0"?>
<response>
  <returnURL>https://example.com/cropdata.json</returnURL>
</response>"""


def _make_cropscape_responses(json_rows):
    """Create urlopen mock that returns XML then JSON for CropScape two-step API."""
    call_count = [0]

    def side_effect(*args, **kwargs):
        call_count[0] += 1
        if call_count[0] % 2 == 1:
            # Odd calls: XML with returnURL
            mock = MagicMock()
            mock.read.return_value = CROPSCAPE_XML_RESPONSE.encode("utf-8")
            mock.__enter__ = MagicMock(return_value=mock)
            mock.__exit__ = MagicMock(return_value=False)
            return mock
        else:
            # Even calls: JSON from returnURL
            mock = MagicMock()
            mock.read.return_value = json.dumps({"rows": json_rows}).encode("utf-8")
            mock.__enter__ = MagicMock(return_value=mock)
            mock.__exit__ = MagicMock(return_value=False)
            return mock

    return side_effect


def _make_cropscape_responses_per_call(json_responses):
    """Create urlopen mock with explicit responses per (xml, json) pair.
    json_responses: list of row dicts for each year/call pair.
    """
    call_count = [0]

    def side_effect(*args, **kwargs):
        call_count[0] += 1
        if call_count[0] % 2 == 1:
            mock = MagicMock()
            mock.read.return_value = CROPSCAPE_XML_RESPONSE.encode("utf-8")
            mock.__enter__ = MagicMock(return_value=mock)
            mock.__exit__ = MagicMock(return_value=False)
            return mock
        else:
            idx = (call_count[0] // 2) - 1
            rows = json_responses[idx] if idx < len(json_responses) else []
            mock = MagicMock()
            mock.read.return_value = json.dumps({"rows": rows}).encode("utf-8")
            mock.__enter__ = MagicMock(return_value=mock)
            mock.__exit__ = MagicMock(return_value=False)
            return mock

    return side_effect


class TestCroplandCROS:
    """Tests for the CroplandCROS class."""

    def test_import_class(self):
        """Test that CroplandCROS can be imported."""
        assert CroplandCROS is not None

    def test_import_crop_codes(self):
        """Test that CROP_CODES dictionary can be imported."""
        assert CROP_CODES is not None
        assert isinstance(CROP_CODES, dict)
        assert "corn" in CROP_CODES
        assert CROP_CODES["corn"] == 1
        assert "soybeans" in CROP_CODES
        assert CROP_CODES["soybeans"] == 5

    def test_init_with_geojson(self):
        """Test initialization with a GeoJSON polygon."""
        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)

        assert cros.field_aoi_wgs84 == field_geojson
        assert cros._bbox_wgs84 is not None

    def test_compute_bbox_simple_polygon(self):
        """Test bounding box computation for a simple polygon."""
        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        bbox = CroplandCROS._compute_bbox(field_geojson)

        assert bbox == (-96.6, 38.4, -96.5, 38.5)

    def test_compute_bbox_irregular_polygon(self):
        """Test bounding box computation for an irregular polygon."""
        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [
                    [-96.6, 38.4],
                    [-96.5, 38.3],
                    [-96.4, 38.5],
                    [-96.7, 38.6],
                    [-96.6, 38.4],
                ]
            ],
        }

        bbox = CroplandCROS._compute_bbox(field_geojson)

        assert bbox[0] == -96.7  # min_lon
        assert bbox[1] == 38.3  # min_lat
        assert bbox[2] == -96.4  # max_lon
        assert bbox[3] == 38.6  # max_lat

    @patch("pyproj.Transformer")
    def test_bbox_to_albers(self, mock_transformer_class):
        """Test transformation from WGS84 to Albers Equal Area."""
        # Mock the transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [
            (100000, 200000),  # min_x, min_y
            (101000, 201000),  # max_x, max_y
        ]
        mock_transformer_class.from_crs.return_value = mock_transformer

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        albers_bbox = cros._bbox_to_albers()

        assert albers_bbox == (100000, 200000, 101000, 201000)
        mock_transformer_class.from_crs.assert_called_once_with(
            "EPSG:4326", "EPSG:5070", always_xy=True
        )

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_success(self, mock_urlopen, mock_transformer_class):
        """Test successful crop query."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock CropScape two-step API: XML then JSON with rows (value=code, acreage, category)
        mock_urlopen.side_effect = _make_cropscape_responses([
            {"value": 1, "acreage": 123.45, "category": "Corn"},
            {"value": 5, "acreage": 45.67, "category": "Soybeans"},
        ])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        crop_code = cros.get_dominant_crop(2020)

        assert crop_code == 1  # Corn has the most acreage

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_soybeans(self, mock_urlopen, mock_transformer_class):
        """Test crop query when soybeans is dominant."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock CropScape API with soybeans dominant
        mock_urlopen.side_effect = _make_cropscape_responses([
            {"value": 5, "acreage": 123.45, "category": "Soybeans"},
            {"value": 1, "acreage": 45.67, "category": "Corn"},
        ])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        crop_code = cros.get_dominant_crop(2020)

        assert crop_code == 5  # Soybeans

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_empty_response(self, mock_urlopen, mock_transformer_class):
        """Test handling of empty API response."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock empty rows in JSON response
        mock_urlopen.side_effect = _make_cropscape_responses([])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        crop_code = cros.get_dominant_crop(2020)

        assert crop_code is None

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_unknown_crops(self, mock_urlopen, mock_transformer_class):
        """Test handling when response contains only non-agricultural codes."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock response with codes outside valid range 1-254 (e.g. background, water)
        mock_urlopen.side_effect = _make_cropscape_responses([
            {"value": 0, "acreage": 123.45, "category": "Background"},
            {"value": 255, "acreage": 45.67, "category": "No Data"},
        ])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        crop_code = cros.get_dominant_crop(2020)

        assert crop_code is None

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_network_error(self, mock_urlopen, mock_transformer_class):
        """Test that network errors are raised so callers can retry."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        mock_urlopen.side_effect = urllib.error.URLError("Network error")

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        with pytest.raises(urllib.error.URLError):
            cros.get_dominant_crop(2020)

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_http_error(self, mock_urlopen, mock_transformer_class):
        """Test that HTTP errors are raised so callers can retry."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        mock_urlopen.side_effect = urllib.error.HTTPError(
            "url", 500, "Server Error", {}, None
        )

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        with pytest.raises(urllib.error.HTTPError):
            cros.get_dominant_crop(2020)

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_crop_years_filters_correctly(self, mock_urlopen, mock_transformer_class):
        """Test filtering years by crop type."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [
            (100000, 200000),
            (101000, 201000),
        ] * 3  # 3 years
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock different crops for different years (2019 corn, 2020 soybeans, 2021 corn)
        mock_urlopen.side_effect = _make_cropscape_responses_per_call([
            [{"value": 1, "acreage": 123.45, "category": "Corn"}],  # 2019
            [{"value": 5, "acreage": 123.45, "category": "Soybeans"}],  # 2020
            [{"value": 1, "acreage": 123.45, "category": "Corn"}],  # 2021
        ])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        corn_years = cros.get_crop_years([2019, 2020, 2021], target_crop_code=CROP_CODES["corn"])

        assert corn_years == [2019, 2021]  # Only corn years

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_crop_years_fallback_all_failures(self, mock_urlopen, mock_transformer_class):
        """Test that CropScapeAPIError is raised when API fails for all years."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)] * 3
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock API failures for all years
        mock_urlopen.side_effect = urllib.error.URLError("Network error")

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        with pytest.raises(CropScapeAPIError, match="unreachable for all"):
            cros.get_crop_years([2019, 2020, 2021], target_crop_code=CROP_CODES["corn"])

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_corn_years_convenience_method(self, mock_urlopen, mock_transformer_class):
        """Test the get_corn_years convenience method."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)] * 2
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock corn for both years (2 years = 4 urlopen calls: xml, json, xml, json)
        mock_urlopen.side_effect = _make_cropscape_responses_per_call([
            [{"value": 1, "acreage": 123.45, "category": "Corn"}],
            [{"value": 1, "acreage": 123.45, "category": "Corn"}],
        ])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        corn_years = cros.get_corn_years([2020, 2021])

        assert corn_years == [2020, 2021]

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_dominant_crop_handles_malformed_csv(
        self, mock_urlopen, mock_transformer_class
    ):
        """Test handling when one row has zero acreage (soybeans wins)."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)]
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Corn has 0 acreage (e.g. malformed/missing), soybeans has valid acreage
        mock_urlopen.side_effect = _make_cropscape_responses([
            {"value": 1, "acreage": 0.0, "category": "Corn"},
            {"value": 5, "acreage": 45.67, "category": "Soybeans"},
        ])

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        crop_code = cros.get_dominant_crop(2020)

        # Should return soybeans (the only valid entry; corn has acreage=None)
        assert crop_code == 5  # Soybeans

    def test_cropscape_url_constant(self):
        """Test that the CROPSCAPE_URL constant is set correctly."""
        assert "nassgeodata.gmu.edu" in CroplandCROS.CROPSCAPE_URL
        assert "CDLService" in CroplandCROS.CROPSCAPE_URL

    @patch("pyproj.Transformer")
    @patch("urllib.request.urlopen")
    def test_get_crop_years_partial_failures(self, mock_urlopen, mock_transformer_class):
        """Test behavior when API fails for some but not all years."""
        # Mock transformer
        mock_transformer = MagicMock()
        mock_transformer.transform.side_effect = [(100000, 200000), (101000, 201000)] * 3
        mock_transformer_class.from_crs.return_value = mock_transformer

        # Mock: 2019 succeeds with corn, 2020 and 2021 fail with URLError
        call_count = [0]

        def mock_side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] <= 2:
                # First year (2019): XML then JSON
                if call_count[0] == 1:
                    mock = MagicMock()
                    mock.read.return_value = CROPSCAPE_XML_RESPONSE.encode("utf-8")
                else:
                    mock = MagicMock()
                    mock.read.return_value = json.dumps({
                        "rows": [{"value": 1, "acreage": 123.45, "category": "Corn"}]
                    }).encode("utf-8")
                mock.__enter__ = MagicMock(return_value=mock)
                mock.__exit__ = MagicMock(return_value=False)
                return mock
            else:
                raise urllib.error.URLError("Network error")

        mock_urlopen.side_effect = mock_side_effect

        field_geojson = {
            "type": "Polygon",
            "coordinates": [
                [[-96.6, 38.4], [-96.5, 38.4], [-96.5, 38.5], [-96.6, 38.5], [-96.6, 38.4]]
            ],
        }

        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        corn_years = cros.get_crop_years([2019, 2020, 2021], target_crop_code=CROP_CODES["corn"])

        # Should return only the successful year (2019)
        assert corn_years == [2019]
