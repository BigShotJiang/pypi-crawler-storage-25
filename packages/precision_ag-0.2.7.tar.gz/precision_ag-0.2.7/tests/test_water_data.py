"""
Unit tests for water_data module (NHD + NWI water feature integration).
"""

import json
import pytest
from unittest.mock import patch, MagicMock
import urllib.error

from water_data import (
    NHDWaterBodies,
    NWIWetlands,
    WaterFeatures,
    WaterDataError,
    _compute_bbox,
    _query_arcgis,
    _esri_feature_to_geojson,
    _features_to_clipped_geometry,
)

# ---------------------------------------------------------------------------
# Test fixtures
# ---------------------------------------------------------------------------

SIMPLE_AOI = {
    "type": "Polygon",
    "coordinates": [
        [[-99.95, 43.88], [-99.92, 43.88], [-99.92, 43.90], [-99.95, 43.90], [-99.95, 43.88]]
    ],
}

# A water body polygon fully inside the AOI
WATER_POLYGON_GEOJSON = {
    "type": "Feature",
    "geometry": {
        "type": "Polygon",
        "coordinates": [
            [[-99.94, 43.885], [-99.93, 43.885], [-99.93, 43.895], [-99.94, 43.895], [-99.94, 43.885]]
        ],
    },
    "properties": {"FTYPE": 390, "GNIS_NAME": "Test Pond"},
}

# A water body polygon partially outside the AOI (should be clipped)
WATER_POLYGON_PARTIAL = {
    "type": "Feature",
    "geometry": {
        "type": "Polygon",
        "coordinates": [
            [[-99.96, 43.885], [-99.93, 43.885], [-99.93, 43.895], [-99.96, 43.895], [-99.96, 43.885]]
        ],
    },
    "properties": {"FTYPE": 390, "GNIS_NAME": "Partial Pond"},
}

# Esri JSON format feature (rings instead of coordinates)
ESRI_JSON_FEATURE = {
    "attributes": {"WETLAND_TYPE": "Freshwater Emergent Wetland", "ACRES": 2.5},
    "geometry": {
        "rings": [
            [[-99.94, 43.885], [-99.93, 43.885], [-99.93, 43.895], [-99.94, 43.895], [-99.94, 43.885]]
        ]
    },
}


def _mock_geojson_response(features, exceeded_limit=False):
    """Create a mock urlopen response returning GeoJSON features."""
    data = {"type": "FeatureCollection", "features": features}
    if exceeded_limit:
        data["exceededTransferLimit"] = True
    body = json.dumps(data).encode("utf-8")
    mock = MagicMock()
    mock.read.return_value = body
    mock.__enter__ = MagicMock(return_value=mock)
    mock.__exit__ = MagicMock(return_value=False)
    return mock


def _mock_esri_json_response(features, exceeded_limit=False):
    """Create a mock urlopen response returning Esri JSON features."""
    data = {"features": features}
    if exceeded_limit:
        data["exceededTransferLimit"] = True
    body = json.dumps(data).encode("utf-8")
    mock = MagicMock()
    mock.read.return_value = body
    mock.__enter__ = MagicMock(return_value=mock)
    mock.__exit__ = MagicMock(return_value=False)
    return mock


def _mock_error_response(error_msg="Failed"):
    """Create a mock urlopen response returning an ArcGIS error."""
    data = {"error": {"code": 400, "message": error_msg, "details": []}}
    body = json.dumps(data).encode("utf-8")
    mock = MagicMock()
    mock.read.return_value = body
    mock.__enter__ = MagicMock(return_value=mock)
    mock.__exit__ = MagicMock(return_value=False)
    return mock


def _mock_html_response():
    """Create a mock urlopen response returning HTML (service unavailable)."""
    body = b"<html><body>Service Unavailable</body></html>"
    mock = MagicMock()
    mock.read.return_value = body
    mock.__enter__ = MagicMock(return_value=mock)
    mock.__exit__ = MagicMock(return_value=False)
    return mock


# ---------------------------------------------------------------------------
# _compute_bbox tests
# ---------------------------------------------------------------------------


class TestComputeBbox:
    def test_simple_polygon(self):
        bbox = _compute_bbox(SIMPLE_AOI)
        assert bbox == (-99.95, 43.88, -99.92, 43.90)

    def test_multipolygon(self):
        mp = {
            "type": "MultiPolygon",
            "coordinates": [
                [[[-100.0, 43.0], [-99.0, 43.0], [-99.0, 44.0], [-100.0, 44.0], [-100.0, 43.0]]],
                [[[-98.0, 42.0], [-97.0, 42.0], [-97.0, 43.0], [-98.0, 43.0], [-98.0, 42.0]]],
            ],
        }
        bbox = _compute_bbox(mp)
        assert bbox[0] == -100.0  # min_lon
        assert bbox[1] == 42.0  # min_lat
        assert bbox[2] == -97.0  # max_lon
        assert bbox[3] == 44.0  # max_lat


# ---------------------------------------------------------------------------
# _esri_feature_to_geojson tests
# ---------------------------------------------------------------------------


class TestEsriFeatureToGeojson:
    def test_single_ring_polygon(self):
        result = _esri_feature_to_geojson(ESRI_JSON_FEATURE)
        assert result is not None
        assert result["type"] == "Feature"
        assert result["geometry"]["type"] == "Polygon"
        assert result["geometry"]["coordinates"] == ESRI_JSON_FEATURE["geometry"]["rings"]
        assert result["properties"]["WETLAND_TYPE"] == "Freshwater Emergent Wetland"

    def test_multi_ring_polygon(self):
        feature = {
            "attributes": {},
            "geometry": {
                "rings": [
                    [[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]],
                    [[2, 2], [8, 2], [8, 8], [2, 8], [2, 2]],
                ]
            },
        }
        result = _esri_feature_to_geojson(feature)
        assert result is not None
        assert len(result["geometry"]["coordinates"]) == 2

    def test_no_rings_returns_none(self):
        result = _esri_feature_to_geojson({"attributes": {}, "geometry": {}})
        assert result is None

    def test_no_geometry_returns_none(self):
        result = _esri_feature_to_geojson({"attributes": {}})
        assert result is None


# ---------------------------------------------------------------------------
# _query_arcgis tests
# ---------------------------------------------------------------------------


class TestQueryArcgis:
    @patch("water_data.urllib.request.urlopen")
    def test_geojson_format_returns_features(self, mock_urlopen):
        mock_urlopen.return_value = _mock_geojson_response([WATER_POLYGON_GEOJSON])
        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
            source_name="Test",
        )
        assert len(features) == 1
        assert features[0]["properties"]["GNIS_NAME"] == "Test Pond"

    @patch("water_data.urllib.request.urlopen")
    def test_esri_json_format_converts_features(self, mock_urlopen):
        mock_urlopen.return_value = _mock_esri_json_response([ESRI_JSON_FEATURE])
        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
            source_name="Test",
            output_format="json",
        )
        assert len(features) == 1
        assert features[0]["geometry"]["type"] == "Polygon"

    @patch("water_data.urllib.request.urlopen")
    def test_empty_response(self, mock_urlopen):
        mock_urlopen.return_value = _mock_geojson_response([])
        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
        )
        assert features == []

    @patch("water_data.urllib.request.urlopen")
    def test_api_error_returns_empty(self, mock_urlopen):
        mock_urlopen.return_value = _mock_error_response("Query failed")
        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
        )
        assert features == []

    @patch("water_data.urllib.request.urlopen")
    def test_html_response_returns_empty(self, mock_urlopen):
        mock_urlopen.return_value = _mock_html_response()
        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
        )
        assert features == []

    @patch("water_data.urllib.request.urlopen")
    def test_network_error_returns_empty(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
        )
        assert features == []

    @patch("water_data.urllib.request.urlopen")
    def test_pagination(self, mock_urlopen):
        """Test that pagination follows exceededTransferLimit."""
        page1 = _mock_geojson_response([WATER_POLYGON_GEOJSON], exceeded_limit=True)
        page2 = _mock_geojson_response([WATER_POLYGON_PARTIAL])
        mock_urlopen.side_effect = [page1, page2]

        features = _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
            max_records=1,
        )
        assert len(features) == 2
        # First call fetches page 1 (exceededTransferLimit=True),
        # second call fetches page 2 (no more pages)
        assert mock_urlopen.call_count >= 2

    @patch("water_data.urllib.request.urlopen")
    def test_uses_get_not_post(self, mock_urlopen):
        """Verify requests use GET (query string) not POST."""
        mock_urlopen.return_value = _mock_geojson_response([])
        _query_arcgis(
            url="https://example.com/query",
            bbox=(-99.95, 43.88, -99.92, 43.90),
        )
        req = mock_urlopen.call_args[0][0]
        assert "?" in req.full_url
        assert req.data is None


# ---------------------------------------------------------------------------
# _features_to_clipped_geometry tests
# ---------------------------------------------------------------------------


class TestFeaturesToClippedGeometry:
    def test_features_clipped_to_aoi(self):
        """Partially-outside feature should be clipped to AOI boundary."""
        result = _features_to_clipped_geometry([WATER_POLYGON_PARTIAL], SIMPLE_AOI)
        assert result is not None
        # Clipped geometry should be smaller than original
        from shapely.geometry import shape

        original = shape(WATER_POLYGON_PARTIAL["geometry"])
        assert result.area < original.area

    def test_feature_inside_aoi_unchanged(self):
        result = _features_to_clipped_geometry([WATER_POLYGON_GEOJSON], SIMPLE_AOI)
        assert result is not None
        from shapely.geometry import shape

        original = shape(WATER_POLYGON_GEOJSON["geometry"])
        assert abs(result.area - original.area) < 1e-10

    def test_empty_features_returns_none(self):
        result = _features_to_clipped_geometry([], SIMPLE_AOI)
        assert result is None

    def test_invalid_geometry_skipped(self):
        bad_feature = {"geometry": {"type": "Point", "coordinates": [0, 0]}}
        good_feature = WATER_POLYGON_GEOJSON
        result = _features_to_clipped_geometry([bad_feature, good_feature], SIMPLE_AOI)
        assert result is not None

    def test_feature_outside_aoi_returns_none(self):
        outside = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [[-80.0, 30.0], [-79.0, 30.0], [-79.0, 31.0], [-80.0, 31.0], [-80.0, 30.0]]
                ],
            },
            "properties": {},
        }
        result = _features_to_clipped_geometry([outside], SIMPLE_AOI)
        assert result is None


# ---------------------------------------------------------------------------
# NHDWaterBodies tests
# ---------------------------------------------------------------------------


class TestNHDWaterBodies:
    def test_url_points_to_waterbody_layer(self):
        assert "/MapServer/12/" in NHDWaterBodies.NHD_URL

    def test_ftype_codes(self):
        nhd = NHDWaterBodies()
        assert 390 in nhd.WATER_FTYPES  # Lake/Pond
        assert 436 in nhd.WATER_FTYPES  # Reservoir
        assert 466 in nhd.WATER_FTYPES  # Swamp/Marsh
        assert 361 in nhd.WATER_FTYPES  # Playa

    @patch("water_data.urllib.request.urlopen")
    def test_query_returns_geometry(self, mock_urlopen):
        mock_urlopen.return_value = _mock_geojson_response([WATER_POLYGON_GEOJSON])
        nhd = NHDWaterBodies()
        result = nhd.query(SIMPLE_AOI)
        assert result is not None
        assert not result.is_empty

    @patch("water_data.urllib.request.urlopen")
    def test_query_no_features_returns_none(self, mock_urlopen):
        mock_urlopen.return_value = _mock_geojson_response([])
        nhd = NHDWaterBodies()
        result = nhd.query(SIMPLE_AOI)
        assert result is None

    @patch("water_data.urllib.request.urlopen")
    def test_query_includes_ftype_filter(self, mock_urlopen):
        mock_urlopen.return_value = _mock_geojson_response([])
        nhd = NHDWaterBodies()
        nhd.query(SIMPLE_AOI)
        req = mock_urlopen.call_args[0][0]
        assert "FType" in req.full_url or "FTYPE" in req.full_url

    @patch("water_data.urllib.request.urlopen")
    def test_query_api_error_returns_none(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("timeout")
        nhd = NHDWaterBodies()
        result = nhd.query(SIMPLE_AOI)
        assert result is None


# ---------------------------------------------------------------------------
# NWIWetlands tests
# ---------------------------------------------------------------------------


class TestNWIWetlands:
    def test_url_points_to_wetlands_layer(self):
        assert "Wetlands" in NWIWetlands.NWI_URL

    @patch("water_data.urllib.request.urlopen")
    def test_query_converts_esri_json(self, mock_urlopen):
        """NWI uses f=json (Esri format), should convert to Shapely."""
        mock_urlopen.return_value = _mock_esri_json_response([ESRI_JSON_FEATURE])
        nwi = NWIWetlands()
        result = nwi.query(SIMPLE_AOI)
        assert result is not None
        assert not result.is_empty

    @patch("water_data.urllib.request.urlopen")
    def test_query_no_features_returns_none(self, mock_urlopen):
        mock_urlopen.return_value = _mock_esri_json_response([])
        nwi = NWIWetlands()
        result = nwi.query(SIMPLE_AOI)
        assert result is None

    @patch("water_data.urllib.request.urlopen")
    def test_query_service_error_returns_none(self, mock_urlopen):
        mock_urlopen.return_value = _mock_error_response("Error performing query")
        nwi = NWIWetlands()
        result = nwi.query(SIMPLE_AOI)
        assert result is None


# ---------------------------------------------------------------------------
# WaterFeatures (combined) tests
# ---------------------------------------------------------------------------


class TestWaterFeatures:
    @patch("water_data.urllib.request.urlopen")
    def test_unions_nhd_and_nwi(self, mock_urlopen):
        """When both sources return data, result should be their union."""
        nhd_feature = WATER_POLYGON_GEOJSON
        nwi_feature = ESRI_JSON_FEATURE

        # NHD call returns GeoJSON, NWI call returns Esri JSON
        nhd_resp = _mock_geojson_response([nhd_feature])
        nwi_resp = _mock_esri_json_response([nwi_feature])
        mock_urlopen.side_effect = [nhd_resp, nwi_resp]

        wf = WaterFeatures()
        result = wf.query(SIMPLE_AOI)
        assert result is not None
        assert not result.is_empty

    @patch("water_data.urllib.request.urlopen")
    def test_nhd_only_when_nwi_fails(self, mock_urlopen):
        nhd_resp = _mock_geojson_response([WATER_POLYGON_GEOJSON])
        nwi_resp = _mock_error_response("Service unavailable")
        mock_urlopen.side_effect = [nhd_resp, nwi_resp]

        wf = WaterFeatures()
        result = wf.query(SIMPLE_AOI)
        assert result is not None

    @patch("water_data.urllib.request.urlopen")
    def test_nwi_only_when_nhd_fails(self, mock_urlopen):
        nhd_resp = _mock_geojson_response([])
        nwi_resp = _mock_esri_json_response([ESRI_JSON_FEATURE])
        mock_urlopen.side_effect = [nhd_resp, nwi_resp]

        wf = WaterFeatures()
        result = wf.query(SIMPLE_AOI)
        assert result is not None

    @patch("water_data.urllib.request.urlopen")
    def test_both_empty_returns_none(self, mock_urlopen):
        nhd_resp = _mock_geojson_response([])
        nwi_resp = _mock_esri_json_response([])
        mock_urlopen.side_effect = [nhd_resp, nwi_resp]

        wf = WaterFeatures()
        result = wf.query(SIMPLE_AOI)
        assert result is None

    @patch("water_data.urllib.request.urlopen")
    def test_both_fail_returns_none(self, mock_urlopen):
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")

        wf = WaterFeatures()
        result = wf.query(SIMPLE_AOI)
        assert result is None
