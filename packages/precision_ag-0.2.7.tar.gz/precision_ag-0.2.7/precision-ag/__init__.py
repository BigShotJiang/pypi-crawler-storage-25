"""
Precision Agriculture Analysis Toolkit

A comprehensive toolkit for precision agriculture analysis using
satellite imagery and remote sensing data.

This package provides tools for:
- Computing agricultural indices (NDVI, EVI, SAVI, NDRE, GNDVI, BSI, SI, NDMI, NDWI, MNDWI)
- Analyzing crop health, soil conditions, and water resources
"""

__version__ = "0.1.0"

# Main module: satellite_indices.py
from .satellite_indices import (
    # Main classes and functions
    AgIndexComputer,
    compute_agricultural_indices_for_aoi,
    # Backward compatibility aliases
    NDVIComputer,
    compute_ndvi_for_aoi,
    VegetationIndexComputer,
    compute_vegetation_indices_for_aoi,
)

# Crop and weather data modules
from .crop_data import CroplandCROS, CropScapeAPIError
from .weather_data import NASAPowerWeather, NASAPowerAPIError

# Elevation data module
from .elevation_data import ElevationComputer, compute_elevation_for_aoi, compute_elevation_for_points, ElevationDataError

# GDD module
from .gdd import GDDComputer, GDDDataError

# Water data module
from .water_data import WaterFeatures, NHDWaterBodies, NWIWetlands, WaterDataError

__all__ = [
    "__version__",
    # Main API
    "AgIndexComputer",
    "compute_agricultural_indices_for_aoi",
    # Backward compatibility (NDVI-focused workflows)
    "NDVIComputer",
    "compute_ndvi_for_aoi",
    # Backward compatibility (vegetation indices)
    "VegetationIndexComputer",
    "compute_vegetation_indices_for_aoi",
    # Crop and weather data
    "CroplandCROS",
    "CropScapeAPIError",
    "NASAPowerWeather",
    "NASAPowerAPIError",
    # Elevation data
    "ElevationComputer",
    "compute_elevation_for_aoi",
    "compute_elevation_for_points",
    "ElevationDataError",
    # GDD
    "GDDComputer",
    "GDDDataError",
    # Water data
    "WaterFeatures",
    "NHDWaterBodies",
    "NWIWetlands",
    "WaterDataError",
]
