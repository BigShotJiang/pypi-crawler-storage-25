"""
USDA CropScape / Cropland Data Layer integration.

Queries the USDA NASS CropScape API (CroplandCROS) to determine which crop was
planted in a field for a given year. This supports filtering NDVI or other
indices to only years when a target crop (e.g., corn) was grown, which is
recommended for management zone creation and crop-specific analysis.

CropScape provides 30 m resolution crop-type maps for the continental US,
derived from satellite imagery and ground truth. The Cropland Data Layer (CDL)
is published annually and is typically available by February of the following year.

API reference: https://nassgeodata.gmu.edu/CropScape
Coordinate system: Bounding boxes must be in Albers Equal Area (EPSG:5070).

Common CDL crop codes (row crops):
    1 = Corn, 5 = Soybeans, 24 = Winter Wheat, 23 = Spring Wheat,
    26 = Dbl Crop WinWht/Soybeans, 28 = Oats, 36 = Alfalfa, 41 = Sugarbeets
"""

import logging
import socket
import urllib.request
import urllib.error
import json
import re
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# Common crop codes from the USDA NASS Cropland Data Layer
CROP_CODES: Dict[str, int] = {
    "corn": 1,
    "cotton": 2,
    "rice": 3,
    "sorghum": 4,
    "soybeans": 5,
    "sunflower": 6,
    "peanuts": 10,
    "tobacco": 11,
    "sweet_corn": 12,
    "pop_corn": 13,
    "spring_wheat": 23,
    "winter_wheat": 24,
    "durum_wheat": 22,
    "oats": 28,
    "barley": 21,
    "alfalfa": 36,
    "sugarbeets": 41,
    "dry_beans": 42,
    "potatoes": 43,
    "canola": 31,
    "dbl_crop_winwht_soybeans": 26,
}


class CroplandCROS:
    """
    Client for the USDA CropScape API to determine crop type within a field.

    Uses the GetCDLStat endpoint to retrieve crop acreage statistics for a
    bounding box and identifies the dominant crop. No full raster download is
    required; the client works with a field AOI in WGS84 (EPSG:4326).

    Example:
        cros = CroplandCROS(field_aoi_wgs84=field_geojson)
        corn_years = cros.get_corn_years([2019, 2020, 2021, 2022, 2023])
    """

    CROPSCAPE_URL = "https://nassgeodata.gmu.edu/axis2/services/CDLService"

    def __init__(self, field_aoi_wgs84: dict):
        """
        Initialize the client with a field area of interest.

        Args:
            field_aoi_wgs84: GeoJSON Polygon or MultiPolygon geometry in WGS84
                (EPSG:4326), with coordinates in [longitude, latitude] order.
        """
        self.field_aoi_wgs84 = field_aoi_wgs84
        self._bbox_wgs84 = self._compute_bbox(field_aoi_wgs84)

    @staticmethod
    def _compute_bbox(geojson: dict) -> tuple:
        """
        Extract a bounding box from GeoJSON geometry.

        Returns:
            Tuple (min_lon, min_lat, max_lon, max_lat) in WGS84.
        """
        coords = geojson["coordinates"]
        # Flatten nested coordinate arrays (handles Polygon and MultiPolygon)
        flat = []

        def _flatten(c):
            if isinstance(c[0], (int, float)):
                flat.append(c)
            else:
                for item in c:
                    _flatten(item)

        _flatten(coords)
        lons = [p[0] for p in flat]
        lats = [p[1] for p in flat]
        return (min(lons), min(lats), max(lons), max(lats))

    def _bbox_to_albers(self) -> tuple:
        """
        Transform the field bounding box from WGS84 to Albers Equal Area (EPSG:5070).

        Returns:
            Tuple (min_x, min_y, max_x, max_y) in EPSG:5070, in meters.
        """
        from pyproj import Transformer

        transformer = Transformer.from_crs(
            "EPSG:4326", "EPSG:5070", always_xy=True
        )
        min_lon, min_lat, max_lon, max_lat = self._bbox_wgs84
        min_x, min_y = transformer.transform(min_lon, min_lat)
        max_x, max_y = transformer.transform(max_lon, max_lat)
        return (min_x, min_y, max_x, max_y)

    def get_dominant_crop(self, year: int) -> Optional[int]:
        """
        Return the dominant CDL crop code within the field for the given year.

        Uses the GetCDLStat endpoint to fetch acreage by crop type and returns
        the crop code with the largest acreage.

        Args:
            year: CDL year to query (data available from 2008 onward).

        Returns:
            The dominant crop code, or None if the request fails or no crop
            could be determined.
        """
        try:
            min_x, min_y, max_x, max_y = self._bbox_to_albers()

            url = (
                f"{self.CROPSCAPE_URL}/GetCDLStat?"
                f"year={year}&"
                f"bbox={min_x},{min_y},{max_x},{max_y}&"
                f"format=json"
            )

            logger.info(f"Querying CropScape for year {year}: {url}")

            # Step 1: Get XML response with returnURL
            req = urllib.request.Request(url, headers={"Accept": "application/xml"})
            with urllib.request.urlopen(req, timeout=10) as response:
                xml_data = response.read().decode("utf-8")

            # Parse XML to extract returnURL
            root = ET.fromstring(xml_data)
            # Handle namespace
            ns = {'ns1': 'http://cropscape.csiss.gmu.edu/CDLService/'}
            return_url_elem = root.find('.//ns1:returnURL', ns) or root.find('.//returnURL')
            
            if return_url_elem is None or not return_url_elem.text:
                logger.warning(f"No returnURL found in CropScape response for year {year}")
                return None

            return_url = return_url_elem.text
            logger.debug(f"Fetching crop data from: {return_url}")

            # Step 2: Fetch the actual JSON data from returnURL
            req2 = urllib.request.Request(return_url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req2, timeout=10) as response:
                json_data = response.read().decode("utf-8")

            # Parse the JSON (which may have unquoted keys)
            # Use regex to extract rows array if standard JSON parsing fails
            try:
                result = json.loads(json_data)
            except json.JSONDecodeError:
                # Handle malformed JSON with unquoted keys using regex
                match = re.search(r'rows:\s*(\[.*?\])', json_data, re.DOTALL)
                if match:
                    rows_str = match.group(1)
                    # Fix unquoted keys
                    rows_str = re.sub(r'(\w+):', r'"\1":', rows_str)
                    result = {"rows": json.loads(rows_str)}
                else:
                    logger.warning(f"Could not parse CropScape JSON for year {year}")
                    return None

            # Extract crop statistics from rows
            rows = result.get("rows", [])
            if not rows:
                logger.warning(f"No crop data in CropScape response for year {year}")
                return None

            # Find dominant crop by acreage
            best_crop_code = None
            best_acreage = 0.0

            for row in rows:
                crop_code = row.get("value")
                acreage = row.get("acreage", 0.0)
                category = row.get("category", "")

                if crop_code is not None and acreage > best_acreage:
                    # Check if this is an agricultural crop (not developed, water, etc.)
                    # Crop codes 1-255 are valid, but codes > 60 are generally non-crop
                    if 1 <= crop_code <= 254:
                        best_acreage = acreage
                        best_crop_code = crop_code

            if best_crop_code is not None:
                logger.info(
                    f"Year {year}: dominant crop code = {best_crop_code} "
                    f"({best_acreage:.1f} acres)"
                )
            else:
                logger.warning(f"Year {year}: could not identify dominant crop")

            return best_crop_code

        except socket.timeout as e:
            logger.warning(f"CropScape timeout for year {year}: {e}")
            raise
        except (urllib.error.URLError, urllib.error.HTTPError) as e:
            logger.warning(f"CropScape API error for year {year}: {e}")
            raise
        except ET.ParseError as e:
            logger.warning(f"CropScape XML parse error for year {year}: {e}")
            return None
        except Exception as e:
            logger.warning(f"Unexpected error querying CropScape for year {year}: {e}")
            return None

    def get_crop_years(
        self, years: List[int], target_crop_code: int
    ) -> List[int]:
        """
        Return only the years in which the target crop was the dominant crop.

        Args:
            years: Years to evaluate.
            target_crop_code: CDL crop code to match (e.g., 1 for corn).

        Returns:
            Subset of years where the target crop was dominant.

        Raises:
            CropScapeAPIError: If the CropScape API was unreachable for every
                queried year.
        """
        matched_years = []
        api_failures = 0

        for year in years:
            try:
                dominant = self.get_dominant_crop(year)
            except (socket.timeout, urllib.error.URLError, urllib.error.HTTPError):
                api_failures += 1
                continue
            if dominant is None:
                api_failures += 1
                continue
            if dominant == target_crop_code:
                matched_years.append(year)
            else:
                logger.info(
                    f"Year {year}: crop code {dominant} != target {target_crop_code}, excluding"
                )

        if api_failures == len(years):
            raise CropScapeAPIError(
                f"CropScape API unreachable for all {len(years)} queried years"
            )

        logger.info(
            f"Crop filter: {len(matched_years)}/{len(years)} years match "
            f"crop code {target_crop_code} ({api_failures} API failures)"
        )
        return matched_years

    def get_corn_years(self, years: List[int]) -> List[int]:
        """
        Return only the years in which corn (CDL code 1) was the dominant crop.

        Args:
            years: Years to evaluate.

        Returns:
            Subset of years where corn was dominant.

        Raises:
            CropScapeAPIError: If the CropScape API was unreachable for every
                queried year.
        """
        return self.get_crop_years(years, target_crop_code=CROP_CODES["corn"])


class CropScapeAPIError(Exception):
    """Raised when the CropScape API cannot be reached for any of the queried years."""
    pass
