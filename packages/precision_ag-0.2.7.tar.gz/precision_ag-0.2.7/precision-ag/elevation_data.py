#!/usr/bin/env python3
"""
Digital Elevation Model retrieval and terrain analysis.

Fetches DEMs from STAC-accessible sources (Copernicus GLO-30, USGS 3DEP)
and computes terrain-derived products for precision agriculture workflows
such as drainage analysis, erosion risk, and zone-based field management.

Terrain products:
- Slope (degrees, Horn method)
- Aspect (degrees from north)
- Hillshade (simulated illumination)
- TWI (Topographic Wetness Index)
- Roughness (local elevation variability)

Usage:
    from precision_ag.elevation_data import ElevationComputer

    ec = ElevationComputer(source="cop-dem-glo-30")
    results = ec.compute_terrain_products(aoi, products=["slope", "aspect", "twi"])
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
import warnings

import numpy as np
import rasterio
import rasterio.io
from rasterio.crs import CRS
from rasterio.mask import mask
from rasterio.merge import merge
from rasterio.warp import transform_geom
import matplotlib.pyplot as plt
from pystac_client import Client
import planetary_computer
from shapely.geometry import shape, box
from scipy.ndimage import generic_filter


class ElevationDataError(Exception):
    """Exception raised for elevation data retrieval and processing errors."""

    pass


# DEM source configurations
SOURCES = {
    "cop-dem-glo-30": {
        "name": "Copernicus DEM GLO-30",
        "collection": "cop-dem-glo-30",
        "asset_key": "data",
        "resolution_m": 30,
        "coverage": "global",
        "description": "Copernicus 30m global DEM from ESA",
    },
    "3dep-seamless": {
        "name": "USGS 3DEP Seamless",
        "collection": "3dep-seamless",
        "asset_key": "data",
        "resolution_m": None,  # variable (1m–60m)
        "coverage": "us",
        "description": "USGS 3D Elevation Program, up to 1m resolution (US only)",
    },
}

# Terrain product definitions
TERRAIN_PRODUCTS = {
    "elevation": {
        "name": "Elevation",
        "unit": "meters",
        "description": "Raw DEM elevation values",
    },
    "slope": {
        "name": "Slope",
        "unit": "degrees",
        "range": (0, 90),
        "description": "Terrain slope via Horn method (np.gradient)",
    },
    "aspect": {
        "name": "Aspect",
        "unit": "degrees",
        "range": (0, 360),
        "description": "Downhill direction measured clockwise from north",
    },
    "hillshade": {
        "name": "Hillshade",
        "unit": "intensity",
        "range": (0, 255),
        "description": "Simulated illumination (default azimuth=315, altitude=45)",
    },
    "twi": {
        "name": "Topographic Wetness Index",
        "unit": "dimensionless",
        "description": "Simplified single-cell TWI: ln(cell_area / tan(slope))",
    },
    "roughness": {
        "name": "Roughness",
        "unit": "meters",
        "description": "Local elevation variability (3x3 neighborhood std dev)",
    },
}


class ElevationComputer:
    """
    Fetch digital elevation models and compute terrain-derived products.

    Supports Copernicus GLO-30 (30m, global) and USGS 3DEP (up to 1m, US-only),
    both accessed via Planetary Computer STAC.
    """

    PLANETARY_COMPUTER_CATALOG = (
        "https://planetarycomputer.microsoft.com/api/stac/v1"
    )

    # Approximate CONUS bounding box for 3DEP coverage check
    _CONUS_BOUNDS = (-125.0, 24.0, -66.0, 50.0)

    def __init__(self, source: str = "auto", catalog_url: str = None):
        """
        Initialize the ElevationComputer.

        Args:
            source: DEM source identifier. One of:
                - "auto" (default) — uses USGS 3DEP (~1m) for US locations,
                  Copernicus GLO-30 (30m) elsewhere.
                - "cop-dem-glo-30" — Copernicus 30m global DEM.
                - "3dep-seamless" — USGS 3DEP (up to 1m, US only).
            catalog_url: STAC catalog URL. Defaults to Planetary Computer.

        Raises:
            ValueError: If source is not recognized.
        """
        valid_sources = set(SOURCES.keys()) | {"auto"}
        if source not in valid_sources:
            available = ", ".join(sorted(valid_sources))
            raise ValueError(
                f"Unknown DEM source '{source}'. Available sources: {available}"
            )

        self.source = source
        self.source_info = SOURCES.get(source)  # None when "auto"
        self.catalog_url = catalog_url or self.PLANETARY_COMPUTER_CATALOG
        self.catalog = Client.open(self.catalog_url)

    def get_available_products(self) -> List[str]:
        """Return list of available terrain product names."""
        return list(TERRAIN_PRODUCTS.keys())

    def load_aoi(self, aoi_input: Union[str, Path, Dict, List]) -> Dict:
        """
        Load Area of Interest from various input formats.

        Args:
            aoi_input: Can be:
                - Path to GeoJSON file
                - GeoJSON dict
                - Bounding box as [min_lon, min_lat, max_lon, max_lat]
                - List of coordinate tuples [(lon1, lat1), (lon2, lat2), ...]

        Returns:
            GeoJSON geometry dict
        """
        if isinstance(aoi_input, (str, Path)):
            try:
                with open(aoi_input, "r") as f:
                    geojson = json.load(f)
            except FileNotFoundError as exc:
                raise ValueError(f"AOI file not found: {aoi_input}") from exc

            if geojson.get("type") == "Feature":
                return geojson["geometry"]
            elif geojson.get("type") == "FeatureCollection":
                return geojson["features"][0]["geometry"]
            else:
                return geojson

        elif isinstance(aoi_input, dict):
            return aoi_input

        elif isinstance(aoi_input, list):
            if len(aoi_input) == 4 and all(
                isinstance(x, (int, float)) for x in aoi_input
            ):
                min_lon, min_lat, max_lon, max_lat = aoi_input
                return {
                    "type": "Polygon",
                    "coordinates": [
                        [
                            [min_lon, min_lat],
                            [max_lon, min_lat],
                            [max_lon, max_lat],
                            [min_lon, max_lat],
                            [min_lon, min_lat],
                        ]
                    ],
                }
            elif len(aoi_input) >= 3 and all(
                isinstance(coord, (tuple, list)) and len(coord) >= 2
                for coord in aoi_input
            ):
                coords = [
                    [float(coord[0]), float(coord[1])] for coord in aoi_input
                ]
                if coords[0] != coords[-1]:
                    coords.append(coords[0])
                return {"type": "Polygon", "coordinates": [coords]}
            else:
                raise ValueError(
                    "List input must be either a bounding box "
                    "[min_lon, min_lat, max_lon, max_lat] or a list of "
                    "coordinate tuples [(lon1, lat1), (lon2, lat2), ...]"
                )
        else:
            raise ValueError(
                "AOI input must be a file path, GeoJSON dict, bounding box "
                "list, or list of coordinate tuples"
            )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _crs_is_geographic(crs) -> bool:
        """Check if a CRS uses geographic (degree) coordinates."""
        try:
            return CRS(crs).is_geographic
        except Exception:
            # Fallback for strings or mocks: check for known geographic CRS ids
            crs_str = str(crs).upper()
            return any(tag in crs_str for tag in ("4326", "4269", "GEOGCS"))

    @staticmethod
    def _is_in_conus(aoi_geometry: Dict) -> bool:
        """Check whether the AOI intersects the continental US."""
        aoi_shape = shape(aoi_geometry)
        conus_box = box(*ElevationComputer._CONUS_BOUNDS)
        return conus_box.intersects(aoi_shape)

    def _resolve_source(self, aoi_geometry: Dict) -> str:
        """Resolve 'auto' source to a concrete source based on AOI location.

        Returns the source key ("3dep-seamless" or "cop-dem-glo-30") and
        updates self.source / self.source_info accordingly.
        """
        if self.source != "auto":
            return self.source

        if self._is_in_conus(aoi_geometry):
            resolved = "3dep-seamless"
            print("AOI is in the US — using USGS 3DEP (up to 1m resolution)")
        else:
            resolved = "cop-dem-glo-30"
            print("AOI is outside the US — using Copernicus GLO-30 (30m)")

        self.source = resolved
        self.source_info = SOURCES[resolved]
        return resolved

    def _check_us_coverage(self, aoi_geometry: Dict) -> None:
        """Warn if AOI appears to be outside CONUS when using 3DEP."""
        if self.source != "3dep-seamless":
            return

        if not self._is_in_conus(aoi_geometry):
            warnings.warn(
                "The AOI appears to be outside the continental US. "
                "USGS 3DEP data may not be available for this region.",
                UserWarning,
            )

    def _load_dem_tile(
        self, item, aoi_geometry: Dict
    ) -> Tuple[np.ndarray, Dict]:
        """
        Load and clip a single DEM tile from a STAC item.

        Args:
            item: STAC item with a signed or signable DEM asset.
            aoi_geometry: GeoJSON geometry dict (WGS84).

        Returns:
            Tuple of (clipped_array, rasterio metadata dict).
        """
        # Sign the item for Planetary Computer access
        if "planetarycomputer" in self.catalog_url:
            item = planetary_computer.sign(item)

        asset_key = self.source_info["asset_key"]
        href = item.assets[asset_key].href

        with rasterio.open(href) as src:
            # Transform AOI into the raster's CRS
            aoi_transformed = transform_geom(
                "EPSG:4326", src.crs, aoi_geometry
            )

            clipped, clipped_transform = mask(
                src, [aoi_transformed], crop=True
            )
            clipped = clipped[0].astype(np.float32)

            # Normalize nodata to NaN
            nodata = src.nodata
            if nodata is not None:
                clipped[clipped == nodata] = np.nan

            meta = src.meta.copy()
            meta.update(
                {
                    "driver": "GTiff",
                    "height": clipped.shape[0],
                    "width": clipped.shape[1],
                    "transform": clipped_transform,
                    "count": 1,
                    "dtype": "float32",
                    "nodata": np.nan,
                }
            )

        return clipped, meta

    def _mosaic_tiles(
        self, items: List, aoi_geometry: Dict
    ) -> Tuple[np.ndarray, Dict]:
        """
        Load multiple DEM tiles and mosaic them into a single array.

        Each tile is clipped to the AOI first (windowed COG read) so only
        the needed pixels are downloaded, then the clipped pieces are merged.

        Args:
            items: List of STAC items covering the AOI.
            aoi_geometry: GeoJSON geometry dict (WGS84).

        Returns:
            Tuple of (mosaic_array, rasterio metadata dict).
        """
        if len(items) == 1:
            return self._load_dem_tile(items[0], aoi_geometry)

        # Clip each tile individually (fast windowed reads from COGs),
        # then merge the small clipped arrays.
        clipped_datasets = []
        ref_meta = None

        try:
            for item in items:
                try:
                    arr, meta = self._load_dem_tile(item, aoi_geometry)
                except Exception:
                    # Tile may not actually overlap after reprojection
                    continue

                if ref_meta is None:
                    ref_meta = meta

                # Write clipped tile to an in-memory dataset for merge()
                memfile = rasterio.io.MemoryFile()
                ds = memfile.open(**meta)
                ds.write(arr.astype("float32"), 1)
                clipped_datasets.append((memfile, ds))

            if not clipped_datasets:
                raise ElevationDataError(
                    "No DEM tiles overlapped the AOI after clipping."
                )

            if len(clipped_datasets) == 1:
                _, ds = clipped_datasets[0]
                data = ds.read(1).astype(np.float32)
                return data, ref_meta

            # Merge the clipped pieces
            datasets_for_merge = [ds for _, ds in clipped_datasets]
            mosaic, mosaic_transform = merge(datasets_for_merge)
            mosaic = mosaic[0].astype(np.float32)

            ref_meta.update(
                {
                    "height": mosaic.shape[0],
                    "width": mosaic.shape[1],
                    "transform": mosaic_transform,
                }
            )

            return mosaic, ref_meta

        finally:
            for memfile, ds in clipped_datasets:
                ds.close()
                memfile.close()

    # ------------------------------------------------------------------
    # Terrain computation (pure numpy / scipy)
    # ------------------------------------------------------------------

    @staticmethod
    def _compute_slope(dem: np.ndarray, cell_size: float) -> np.ndarray:
        """Compute slope in degrees using the Horn method via np.gradient."""
        dy, dx = np.gradient(dem, cell_size)
        slope_rad = np.arctan(np.sqrt(dx**2 + dy**2))
        return np.degrees(slope_rad)

    @staticmethod
    def _compute_aspect(dem: np.ndarray, cell_size: float) -> np.ndarray:
        """Compute aspect in degrees clockwise from north (0-360)."""
        dy, dx = np.gradient(dem, cell_size)
        # atan2(-dx, dy) gives angle from north, clockwise positive
        aspect_rad = np.arctan2(-dx, dy)
        aspect_deg = np.degrees(aspect_rad)
        # Convert from (-180, 180) to (0, 360)
        aspect_deg = np.where(aspect_deg < 0, aspect_deg + 360, aspect_deg)
        return aspect_deg

    @staticmethod
    def _compute_hillshade(
        dem: np.ndarray,
        cell_size: float,
        azimuth: float = 315.0,
        altitude: float = 45.0,
    ) -> np.ndarray:
        """Compute hillshade illumination (0-255)."""
        dy, dx = np.gradient(dem, cell_size)
        slope_rad = np.arctan(np.sqrt(dx**2 + dy**2))
        aspect_rad = np.arctan2(-dx, dy)

        az_rad = np.radians(azimuth)
        alt_rad = np.radians(altitude)

        hillshade = (
            np.sin(alt_rad) * np.cos(slope_rad)
            + np.cos(alt_rad) * np.sin(slope_rad) * np.cos(az_rad - aspect_rad)
        )
        # Scale to 0-255
        hillshade = np.clip(hillshade, 0, 1) * 255
        return hillshade.astype(np.float32)

    @staticmethod
    def _compute_twi(
        dem: np.ndarray, cell_size: float
    ) -> np.ndarray:
        """Compute simplified single-cell Topographic Wetness Index.

        TWI = ln(cell_area / tan(slope))
        Uses a minimum slope threshold to avoid division by zero.
        """
        dy, dx = np.gradient(dem, cell_size)
        slope_rad = np.arctan(np.sqrt(dx**2 + dy**2))
        # Clamp slope to a small minimum to avoid log(inf)
        tan_slope = np.tan(np.maximum(slope_rad, np.radians(0.1)))
        cell_area = cell_size * cell_size
        twi = np.log(cell_area / tan_slope)
        return twi

    @staticmethod
    def _compute_roughness(dem: np.ndarray) -> np.ndarray:
        """Compute roughness as 3x3 neighborhood standard deviation."""
        return generic_filter(dem, np.std, size=3).astype(np.float32)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fetch_dem(
        self,
        aoi: Union[str, Path, Dict, List],
        target_resolution_m: float = None,
        output_path: str = None,
    ) -> Tuple[np.ndarray, Dict]:
        """
        Fetch a DEM clipped to the given AOI.

        Args:
            aoi: Area of interest (file path, GeoJSON, bbox, or coord list).
            target_resolution_m: Desired resolution in meters (not yet used,
                reserved for future resampling support).
            output_path: Optional path to save the DEM as a GeoTIFF.

        Returns:
            Tuple of (dem_array, metadata_dict).

        Raises:
            ElevationDataError: If no DEM tiles are found for the AOI.
        """
        aoi_geometry = self.load_aoi(aoi)
        self._resolve_source(aoi_geometry)
        self._check_us_coverage(aoi_geometry)

        # Search for DEM tiles
        collection = self.source_info["collection"]
        search = self.catalog.search(
            collections=[collection],
            intersects=aoi_geometry,
        )
        items = list(search.items())

        if not items:
            raise ElevationDataError(
                f"No DEM tiles found for the given AOI in '{self.source}'. "
                f"Check that the AOI is within the source's coverage area."
            )

        print(f"Found {len(items)} DEM tile(s) from {self.source_info['name']}")

        # Load and mosaic
        dem, meta = self._mosaic_tiles(items, aoi_geometry)

        # Store resolution for terrain computations
        transform = meta["transform"]
        crs = meta.get("crs")
        pixel_size = abs(transform[0])

        if crs and self._crs_is_geographic(crs):
            # CRS is in degrees (WGS84, NAD83, etc.) — convert to meters
            mid_lat = aoi_geometry.get("coordinates", [[[0, 0]]])[0][0][1]
            meta["resolution_m"] = pixel_size * 111320 * np.cos(
                np.radians(mid_lat)
            )
        else:
            # CRS is projected (UTM, etc.) — pixel size is already in meters
            meta["resolution_m"] = pixel_size

        # Save if requested
        if output_path:
            output_path = Path(output_path)
            output_path.parent.mkdir(exist_ok=True, parents=True)
            save_meta = {k: v for k, v in meta.items() if k != "resolution_m"}
            with rasterio.open(output_path, "w", **save_meta) as dst:
                dst.write(dem.astype("float32"), 1)
            print(f"DEM saved to: {output_path}")

        return dem, meta

    def compute_terrain_products(
        self,
        aoi: Union[str, Path, Dict, List],
        products: List[str] = None,
        output_dir: str = None,
        visualize: bool = False,
        print_stats: bool = False,
    ) -> Dict[str, Tuple[np.ndarray, Dict]]:
        """
        Fetch DEM and compute terrain-derived products.

        Args:
            aoi: Area of interest.
            products: List of product names (default: ["slope", "aspect", "hillshade"]).
                Available: elevation, slope, aspect, hillshade, twi, roughness.
            output_dir: Optional directory to save each product as a GeoTIFF.
            visualize: Whether to display a visualization of the results.
            print_stats: Whether to print summary statistics for each product.

        Returns:
            Dict mapping product names to (array, metadata) tuples.

        Raises:
            ValueError: If an unknown product is requested.
            ElevationDataError: If DEM cannot be fetched.
        """
        if products is None:
            products = ["slope", "aspect", "hillshade"]

        # Validate requested products
        for p in products:
            if p not in TERRAIN_PRODUCTS:
                available = ", ".join(TERRAIN_PRODUCTS.keys())
                raise ValueError(
                    f"Unknown terrain product '{p}'. "
                    f"Available products: {available}"
                )

        # Fetch the DEM
        dem, meta = self.fetch_dem(aoi)
        cell_size = meta.get("resolution_m", 30.0)

        print(f"Computing terrain products (cell size ~{cell_size:.1f}m)...")

        results = {}

        for product in products:
            print(f"  Computing {product}...")

            if product == "elevation":
                arr = dem.copy()
            elif product == "slope":
                arr = self._compute_slope(dem, cell_size)
            elif product == "aspect":
                arr = self._compute_aspect(dem, cell_size)
            elif product == "hillshade":
                arr = self._compute_hillshade(dem, cell_size)
            elif product == "twi":
                arr = self._compute_twi(dem, cell_size)
            elif product == "roughness":
                arr = self._compute_roughness(dem)

            product_meta = meta.copy()
            product_meta["product"] = product
            product_meta["unit"] = TERRAIN_PRODUCTS[product]["unit"]

            results[product] = (arr, product_meta)

            # Save if output directory provided
            if output_dir:
                out_path = Path(output_dir)
                out_path.mkdir(exist_ok=True, parents=True)
                out_file = out_path / f"{product}_{self.source}.tif"
                save_meta = {
                    k: v
                    for k, v in meta.items()
                    if k not in ("resolution_m", "product", "unit")
                }
                with rasterio.open(out_file, "w", **save_meta) as dst:
                    dst.write(arr.astype("float32"), 1)
                print(f"    Saved to: {out_file}")

        print("All terrain products computed successfully!")

        if visualize:
            self.visualize_terrain(results)

        if print_stats:
            stats = self.compute_statistics(results)
            print("\nStatistics:")
            for name, s in stats.items():
                if "error" not in s:
                    print(f"  {name}: mean={s['mean']:.2f}, range=[{s['min']:.2f}, {s['max']:.2f}]")

        return results

    def sample_points(
        self,
        points: List[Tuple[float, float]],
        products: List[str] = None,
        buffer_deg: float = 0.001,
    ) -> List[Dict]:
        """
        Sample terrain products at a batch of lat/lon points efficiently.

        Fetches a single DEM covering all points, computes terrain products
        once, then samples each point from the rasters.

        Args:
            points: List of (lat, lon) tuples.
            products: Terrain products to sample (default: ["elevation", "slope"]).
            buffer_deg: Buffer in degrees added around the bounding box of all
                points to ensure edge points are fully covered. Default 0.001
                (~110m).

        Returns:
            List of dicts, one per point, each containing:
                - "lat", "lon": the input coordinates
                - one key per product with the sampled value (or NaN if
                  the point falls outside the raster).

        Raises:
            ValueError: If points list is empty or products are invalid.
            ElevationDataError: If DEM cannot be fetched.
        """
        if not points:
            raise ValueError("points list must not be empty")

        if products is None:
            products = ["elevation", "slope"]

        # Validate products
        for p in products:
            if p not in TERRAIN_PRODUCTS:
                available = ", ".join(TERRAIN_PRODUCTS.keys())
                raise ValueError(
                    f"Unknown terrain product '{p}'. "
                    f"Available products: {available}"
                )

        # Build a single bounding box covering all points + buffer
        lats = [p[0] for p in points]
        lons = [p[1] for p in points]
        bbox = [
            min(lons) - buffer_deg,
            min(lats) - buffer_deg,
            max(lons) + buffer_deg,
            max(lats) + buffer_deg,
        ]

        print(f"Sampling {len(points)} points...")

        # Fetch DEM and compute products over the combined extent
        terrain_results = self.compute_terrain_products(bbox, products=products)

        # Sample each point from the rasters
        # We need the transform to convert lat/lon -> pixel coordinates
        ref_meta = list(terrain_results.values())[0][1]
        transform = ref_meta["transform"]
        crs = ref_meta.get("crs")

        sampled = []
        for lat, lon in points:
            row = {}
            row["lat"] = lat
            row["lon"] = lon

            # Convert lon/lat to pixel coords in the raster
            if crs and not self._crs_is_geographic(crs):
                # Raster is in a projected CRS — transform the point
                from rasterio.warp import transform as warp_transform

                xs, ys = warp_transform(
                    "EPSG:4326", crs, [lon], [lat]
                )
                px_x, px_y = xs[0], ys[0]
            else:
                px_x, px_y = lon, lat

            # Inverse transform: geo coords -> pixel row/col
            col_idx, row_idx = ~transform * (px_x, px_y)
            col_idx = int(round(col_idx))
            row_idx = int(round(row_idx))

            for product_name, (arr, _) in terrain_results.items():
                if (
                    0 <= row_idx < arr.shape[0]
                    and 0 <= col_idx < arr.shape[1]
                ):
                    row[product_name] = float(arr[row_idx, col_idx])
                else:
                    row[product_name] = float("nan")

            sampled.append(row)

        print(f"Sampled {len(sampled)} points across {len(products)} products")
        return sampled

    def compute_statistics(
        self, results: Dict[str, Tuple[np.ndarray, Dict]]
    ) -> Dict[str, Dict]:
        """
        Compute summary statistics for terrain products.

        Args:
            results: Dictionary from compute_terrain_products().

        Returns:
            Dictionary mapping product names to statistics dicts.
        """
        stats = {}

        for name, (arr, _) in results.items():
            valid = arr[~np.isnan(arr)]

            if len(valid) > 0:
                stats[name] = {
                    "mean": float(valid.mean()),
                    "median": float(np.median(valid)),
                    "std": float(valid.std()),
                    "min": float(valid.min()),
                    "max": float(valid.max()),
                    "valid_pixels": len(valid),
                    "total_pixels": arr.size,
                }
            else:
                stats[name] = {"error": "No valid data"}

        return stats

    def visualize_terrain(
        self,
        results: Dict[str, Tuple[np.ndarray, Dict]],
        save_path: str = None,
        figsize: Tuple[int, int] = None,
    ):
        """
        Create a grid visualization of terrain products.

        Args:
            results: Dictionary from compute_terrain_products().
            save_path: Optional path to save the figure.
            figsize: Figure size (width, height). Auto-calculated if None.

        Returns:
            matplotlib Figure.
        """
        n = len(results)
        if n == 0:
            print("No products to visualize")
            return None

        # Layout
        if n <= 3:
            nrows, ncols = 1, n
        else:
            ncols = 3
            nrows = (n + ncols - 1) // ncols

        if figsize is None:
            figsize = (6 * ncols, 5 * nrows)

        fig, axes = plt.subplots(nrows, ncols, figsize=figsize)

        if n == 1:
            axes = [axes]
        elif nrows > 1:
            axes = axes.flatten()

        cmaps = {
            "elevation": "terrain",
            "slope": "YlOrRd",
            "aspect": "hsv",
            "hillshade": "gray",
            "twi": "Blues",
            "roughness": "magma",
        }

        for idx, (name, (arr, _meta)) in enumerate(results.items()):
            ax = axes[idx] if n > 1 else axes[0]
            cmap = cmaps.get(name, "viridis")

            valid = arr[~np.isnan(arr)]
            if len(valid) > 0:
                vmin, vmax = float(valid.min()), float(valid.max())
            else:
                vmin, vmax = 0, 1

            im = ax.imshow(arr, cmap=cmap, vmin=vmin, vmax=vmax)
            cbar = plt.colorbar(im, ax=ax, shrink=0.8)

            info = TERRAIN_PRODUCTS.get(name, {})
            unit = info.get("unit", "")
            cbar.set_label(unit, rotation=270, labelpad=15)
            ax.set_title(
                info.get("name", name),
                fontsize=11,
                fontweight="bold",
            )
            ax.set_xlabel("Column (pixels)")
            ax.set_ylabel("Row (pixels)")

            # Stats overlay
            if len(valid) > 0:
                stats_text = (
                    f"Mean: {valid.mean():.2f}\n"
                    f"Std: {valid.std():.2f}\n"
                    f"Range: [{valid.min():.2f}, {valid.max():.2f}]"
                )
                ax.text(
                    0.02,
                    0.98,
                    stats_text,
                    transform=ax.transAxes,
                    verticalalignment="top",
                    bbox=dict(
                        boxstyle="round", facecolor="white", alpha=0.8
                    ),
                    fontsize=8,
                )

        # Hide unused axes
        if nrows > 1:
            for idx in range(n, len(axes)):
                axes[idx].axis("off")

        fig.suptitle(
            f"Terrain Analysis — {self.source_info['name']}",
            fontsize=14,
            fontweight="bold",
            y=0.995,
        )
        plt.tight_layout()

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches="tight")
            print(f"Figure saved to: {save_path}")

        return fig


def compute_elevation_for_points(
    points: List[Tuple[float, float]],
    source: str = "auto",
    buffer_deg: float = 0.001,
) -> List[Dict]:
    """
    Convenience function to get elevation at a list of lat/lon points.

    Args:
        points: List of (lat, lon) tuples.
        source: DEM source. Defaults to "auto" which picks USGS 3DEP
            (~1m) for US locations and Copernicus GLO-30 (30m) elsewhere.
            Can also be "cop-dem-glo-30" or "3dep-seamless" explicitly.
        buffer_deg: Buffer in degrees around the bounding box of all
            points. Default 0.001 (~110m).

    Returns:
        List of dicts, one per point, each containing "lat", "lon",
        and "elevation" keys.
    """
    ec = ElevationComputer(source=source)
    return ec.sample_points(points, products=["elevation"], buffer_deg=buffer_deg)


def compute_elevation_for_aoi(
    aoi: Union[str, Path, Dict, List],
    source: str = "auto",
    output_path: str = None,
) -> Tuple[np.ndarray, Dict]:
    """
    Convenience function to fetch elevation data for an AOI.

    Args:
        aoi: Area of interest (file path, GeoJSON, bbox, or coord list).
        source: DEM source. Defaults to "auto" which picks USGS 3DEP
            (~1m) for US locations and Copernicus GLO-30 (30m) elsewhere.
            Can also be "cop-dem-glo-30" or "3dep-seamless" explicitly.
        output_path: Optional path to save the DEM as a GeoTIFF.

    Returns:
        Tuple of (elevation_array, metadata_dict).
    """
    ec = ElevationComputer(source=source)
    return ec.fetch_dem(aoi, output_path=output_path)
