"""
Federal water feature data integration (NHD + NWI).

Queries the USGS National Hydrography Dataset (NHD) and the US Fish & Wildlife
Service National Wetlands Inventory (NWI) via their public ArcGIS REST API
endpoints to retrieve known water bodies and wetlands that intersect a field.

These authoritative datasets complement satellite-derived water indices (MNDWI)
by providing mapped permanent and semi-permanent water features that may not
appear in a single satellite scene (e.g., tree-canopy-obscured ponds, features
missed during dry periods).

NHD reference: https://hydro.nationalmap.gov/arcgis/rest/services/nhd/MapServer
NWI reference: https://fwsprimary.wim.usgs.gov/server/rest/services/Wetlands/MapServer
"""

import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class WaterDataError(Exception):
    """Raised when water feature data cannot be retrieved."""

    pass


class NHDWaterBodies:
    """
    Query the USGS National Hydrography Dataset for water bodies.

    Retrieves lakes, ponds, reservoirs, swamps, and playas from the NHD
    waterbody layer that intersect a field's bounding box.

    Example:
        nhd = NHDWaterBodies()
        water_geom = nhd.query(field_aoi_geojson)
        if water_geom:
            print(f"Found {water_geom.area} sq degrees of water")
    """

    NHD_URL = (
        "https://hydro.nationalmap.gov/arcgis/rest/services/nhd/MapServer/12/query"
    )

    # FType codes for water-related features in the NHD Waterbody layer
    WATER_FTYPES = [390, 436, 466, 361]  # Lake/Pond, Reservoir, Swamp/Marsh, Playa

    def __init__(self, timeout: int = 30, max_records: int = 500):
        """
        Args:
            timeout: HTTP request timeout in seconds.
            max_records: Maximum records per page (ArcGIS default is 1000).
        """
        self.timeout = timeout
        self.max_records = max_records

    def query(self, aoi_geometry: dict):
        """
        Query NHD water bodies within the bounding box of the AOI.

        Args:
            aoi_geometry: GeoJSON geometry dict (Polygon or MultiPolygon)
                in WGS84 (EPSG:4326).

        Returns:
            Shapely geometry (Polygon or MultiPolygon) of water features
            clipped to the AOI, or None if no features found or on error.
        """
        bbox = _compute_bbox(aoi_geometry)
        ftype_list = ",".join(str(f) for f in self.WATER_FTYPES)

        features = _query_arcgis(
            url=self.NHD_URL,
            bbox=bbox,
            where=f"FType IN ({ftype_list})",
            timeout=self.timeout,
            max_records=self.max_records,
            source_name="NHD",
        )

        if not features:
            return None

        return _features_to_clipped_geometry(features, aoi_geometry)


class NWIWetlands:
    """
    Query the US Fish & Wildlife Service National Wetlands Inventory.

    Retrieves all wetland polygons that intersect a field's bounding box.

    Example:
        nwi = NWIWetlands()
        wetland_geom = nwi.query(field_aoi_geojson)
    """

    NWI_URL = (
        "https://fwsprimary.wim.usgs.gov/server/rest/services"
        "/Wetlands/MapServer/0/query"
    )

    def __init__(self, timeout: int = 30, max_records: int = 500):
        self.timeout = timeout
        self.max_records = max_records

    def query(self, aoi_geometry: dict):
        """
        Query NWI wetlands within the bounding box of the AOI.

        Args:
            aoi_geometry: GeoJSON geometry dict in WGS84.

        Returns:
            Shapely geometry of wetland features clipped to the AOI, or None.
        """
        bbox = _compute_bbox(aoi_geometry)

        features = _query_arcgis(
            url=self.NWI_URL,
            bbox=bbox,
            where="1=1",
            timeout=self.timeout,
            max_records=self.max_records,
            source_name="NWI",
            output_format="json",  # NWI server doesn't support GeoJSON
        )

        if not features:
            return None

        return _features_to_clipped_geometry(features, aoi_geometry)


class WaterFeatures:
    """
    Combined NHD + NWI water feature querying.

    Convenience class that queries both federal datasets and returns the
    union of all water features. Failures in either source are non-fatal;
    the other source's results are still returned.

    Example:
        wf = WaterFeatures()
        water = wf.query(field_aoi_geojson)
        if water:
            acres = abs(Geod(ellps='WGS84').geometry_area_perimeter(water)[0]) / 4046.86
            print(f"Total water: {acres:.2f} ac")
    """

    def __init__(self, timeout: int = 30, max_records: int = 500):
        self.nhd = NHDWaterBodies(timeout=timeout, max_records=max_records)
        self.nwi = NWIWetlands(timeout=timeout, max_records=max_records)

    def query(self, aoi_geometry: dict):
        """
        Query both NHD and NWI, return union of all features.

        Args:
            aoi_geometry: GeoJSON geometry dict in WGS84.

        Returns:
            Shapely geometry (union of NHD + NWI), or None if nothing found.
        """
        from shapely.ops import unary_union

        geometries = []

        nhd_geom = self.nhd.query(aoi_geometry)
        if nhd_geom is not None and not nhd_geom.is_empty:
            geometries.append(nhd_geom)
            logger.info("NHD: found water features")
        else:
            logger.info("NHD: no water features found")

        nwi_geom = self.nwi.query(aoi_geometry)
        if nwi_geom is not None and not nwi_geom.is_empty:
            geometries.append(nwi_geom)
            logger.info("NWI: found wetland features")
        else:
            logger.info("NWI: no wetland features found")

        if not geometries:
            return None

        merged = unary_union(geometries)
        if not merged.is_valid:
            merged = merged.buffer(0)
        return merged


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _compute_bbox(geojson: dict) -> Tuple[float, float, float, float]:
    """
    Extract a bounding box (min_lon, min_lat, max_lon, max_lat) from a
    GeoJSON geometry.
    """
    coords = geojson["coordinates"]
    flat = []

    def _flatten(c):
        if isinstance(c[0], (int, float)):
            flat.append(c)
        else:
            for item in c:
                _flatten(item)

    _flatten(coords)
    lons = [p[0] for p in flat]
    lats = [p[1] for p in flat]
    return (min(lons), min(lats), max(lons), max(lats))


def _query_arcgis(
    url: str,
    bbox: Tuple[float, float, float, float],
    where: str = "1=1",
    timeout: int = 30,
    max_records: int = 500,
    source_name: str = "ArcGIS",
    output_format: str = "geojson",
) -> List[dict]:
    """
    Query an ArcGIS REST feature service, handling pagination.

    Args:
        output_format: Response format — "geojson" (default) or "json" (Esri
            native format, for servers that don't support GeoJSON). When "json"
            is used, Esri ring geometries are converted to GeoJSON format.

    Returns a list of GeoJSON-formatted features, or an empty list on failure.
    """
    all_features = []
    offset = 0

    while True:
        params = {
            "where": where,
            "geometry": f"{bbox[0]},{bbox[1]},{bbox[2]},{bbox[3]}",
            "geometryType": "esriGeometryEnvelope",
            "spatialRel": "esriSpatialRelIntersects",
            "inSR": "4326",
            "outSR": "4326",
            "outFields": "*",
            "returnGeometry": "true",
            "f": output_format,
            "resultRecordCount": str(max_records),
            "resultOffset": str(offset),
        }

        query_string = urllib.parse.urlencode(params)
        full_url = f"{url}?{query_string}"

        try:
            req = urllib.request.Request(
                full_url,
                headers={"Accept": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8")
                if "<html" in raw[:500].lower():
                    logger.warning(
                        f"{source_name}: received HTML instead of JSON "
                        f"(service may be unavailable)"
                    )
                    break
                data = json.loads(raw)
        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
            logger.warning(f"{source_name} API error: {e}")
            break
        except Exception as e:
            logger.warning(f"{source_name} unexpected error: {e}")
            break

        if "error" in data:
            logger.warning(
                f"{source_name} query error: {data['error'].get('message', data['error'])}"
            )
            break

        features = data.get("features", [])
        if not features:
            break

        # Convert Esri JSON geometry to GeoJSON if needed
        if output_format == "json":
            features = [_esri_feature_to_geojson(f) for f in features]
            features = [f for f in features if f is not None]
            if not features:
                break

        all_features.extend(features)
        logger.debug(
            f"{source_name}: fetched {len(features)} features "
            f"(total: {len(all_features)}, offset: {offset})"
        )

        # Check for pagination
        if data.get("exceededTransferLimit") or len(features) >= max_records:
            offset += len(features)
        else:
            break

    if all_features:
        logger.info(f"{source_name}: {len(all_features)} feature(s) in bounding box")
    return all_features


def _esri_feature_to_geojson(feature: dict) -> Optional[dict]:
    """
    Convert an Esri JSON feature to GeoJSON format.

    Handles polygon geometries with ``rings`` arrays.
    """
    geom = feature.get("geometry", {})
    rings = geom.get("rings")
    if not rings:
        return None

    # Esri rings: first ring is exterior, subsequent rings are holes
    # (same convention as GeoJSON Polygon coordinates)
    if len(rings) == 1:
        geojson_geom = {"type": "Polygon", "coordinates": rings}
    else:
        # Multiple rings — could be multi-part or polygon with holes.
        # Esri uses clockwise = exterior, counter-clockwise = hole.
        # For simplicity, treat as a single polygon with holes.
        geojson_geom = {"type": "Polygon", "coordinates": rings}

    return {
        "type": "Feature",
        "geometry": geojson_geom,
        "properties": feature.get("attributes", {}),
    }


def _features_to_clipped_geometry(features: List[dict], aoi_geometry: dict):
    """
    Convert GeoJSON features to a single Shapely geometry clipped to the AOI.

    Returns None if no valid polygons remain after clipping.
    """
    from shapely.geometry import shape, Polygon, MultiPolygon
    from shapely.ops import unary_union

    aoi_shape = shape(aoi_geometry)

    polys = []
    for f in features:
        try:
            geom = shape(f["geometry"])
            if geom.is_valid and not geom.is_empty:
                polys.append(geom)
        except Exception:
            continue

    if not polys:
        return None

    merged = unary_union(polys)
    if not merged.is_valid:
        merged = merged.buffer(0)

    # Clip to AOI boundary
    clipped = merged.intersection(aoi_shape)
    if clipped.is_empty:
        return None
    if not clipped.is_valid:
        clipped = clipped.buffer(0)

    # Keep only polygon parts (discard points/lines from intersection artifacts)
    if isinstance(clipped, (Polygon, MultiPolygon)):
        return clipped

    from shapely.geometry import GeometryCollection

    if isinstance(clipped, GeometryCollection):
        poly_parts = [
            g for g in clipped.geoms if isinstance(g, (Polygon, MultiPolygon))
        ]
        if not poly_parts:
            return None
        if len(poly_parts) == 1:
            return poly_parts[0]
        return MultiPolygon(poly_parts)

    return None
