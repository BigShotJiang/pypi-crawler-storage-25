"""
NASA POWER Weather Data Integration

Queries the NASA POWER (Prediction Of Worldwide Energy Resources) API for
daily weather data to classify growing seasons by precipitation and provide
additional meteorological parameters. This enables filtering NDVI history to
exclude abnormally dry or wet years, and provides context for crop growth analysis.

NASA POWER provides global daily/monthly/annual meteorological parameters at
0.5-degree resolution, derived from satellite observations and reanalysis models.
The API is free and requires no API key.

API reference: https://power.larc.nasa.gov/docs/services/api/

Available weather parameters:
    - Precipitation (PRECTOTCORR): Bias-corrected daily precipitation
    - Solar Radiation (ALLSKY_SFC_SW_DWN): All-sky surface shortwave downward irradiance
    - Temperature (T2M, T2M_MAX, T2M_MIN): Temperature at 2 meters
    - Humidity (RH2M): Relative humidity at 2 meters
    - Wind Speed (WS2M): Wind speed at 2 meters

Weather classification approach:
    1. Fetch total growing season precipitation (default: April-September) for each year.
    2. Classify years using climatological baseline (30-year normals, 1991-2020):
       - Dry: < mean - 0.5 * std
       - Normal: mean ± 0.5 * std  
       - Wet: > mean + 0.5 * std
    
    This uses absolute standards based on long-term climate data, not relative
    percentiles, ensuring that classifications are meaningful even with small
    sample sizes.
"""

import logging
import urllib.request
import urllib.error
import json
from typing import Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed

import numpy as np

logger = logging.getLogger(__name__)


class NASAPowerWeather:
    """
    Query NASA POWER API for growing season weather data and classify years.

    Provides access to multiple meteorological parameters including precipitation,
    temperature, solar radiation, humidity, and wind speed. Supports both growing
    season queries and specific month/month range queries. Uses climatological
    baseline (30-year normals) to classify years by precipitation patterns.

    Example usage:
        weather = NASAPowerWeather(latitude=41.5, longitude=-93.5)
        
        # Classify years by precipitation against 30-year climate normals
        classification = weather.classify_years([2019, 2020, 2021, 2022, 2023])
        # classification = {"dry": [2021], "normal": [2019, 2022], "wet": [2020, 2023]}
        
        # Get growing season weather parameters
        precip_mm = weather.get_growing_season_precipitation(2023)
        temp_c = weather.get_growing_season_temperature(2023, stat="mean")
        solar_mj = weather.get_growing_season_solar_radiation(2023)
        humidity_pct = weather.get_growing_season_humidity(2023)
        wind_ms = weather.get_growing_season_wind_speed(2023)
        
        # Or get all parameters at once (more efficient)
        all_params = weather.get_all_weather_parameters(2023)
        
        # Get monthly weather data
        april_precip = weather.get_monthly_precipitation(2023, 4)
        july_temp = weather.get_monthly_temperature(2023, 7, stat="mean")
        
        # Query month ranges
        spring_weather = weather.get_monthly_weather(2023, 4, end_month=6)
        summer_precip = weather.get_monthly_precipitation(2023, 6, end_month=8)
    """

    POWER_URL = "https://power.larc.nasa.gov/api/temporal/daily/point"

    def __init__(
        self,
        latitude: float,
        longitude: float,
        growing_season_months: Tuple[int, int] = (4, 9),
    ):
        """
        Args:
            latitude: Field centroid latitude (WGS84).
            longitude: Field centroid longitude (WGS84).
            growing_season_months: Tuple of (start_month, end_month) inclusive.
                Default (4, 9) = April through September.
        """
        self.latitude = latitude
        self.longitude = longitude
        self.growing_season_start = growing_season_months[0]
        self.growing_season_end = growing_season_months[1]

    def _fetch_precipitation_concurrent(
        self, years: List[int], max_workers: int = 10
    ) -> Dict[int, float]:
        """
        Fetch precipitation for multiple years concurrently.

        Uses ThreadPoolExecutor to parallelize API calls, reducing total fetch
        time from ~0.5s per year to ~2-3s for 30 years.

        Args:
            years: List of years to fetch.
            max_workers: Maximum number of concurrent threads (default 10).

        Returns:
            Dict mapping year to precipitation (mm). Years with API failures
            are excluded from the result.
        """
        year_precip = {}

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all fetch tasks
            future_to_year = {
                executor.submit(self.get_growing_season_precipitation, year): year
                for year in years
            }

            # Collect results as they complete
            for future in as_completed(future_to_year):
                year = future_to_year[future]
                try:
                    precip = future.result()
                    if precip is not None:
                        year_precip[year] = precip
                except Exception as e:
                    logger.warning(f"Error fetching precipitation for year {year}: {e}")

        return year_precip

    def _get_weather_data(
        self, 
        year: int, 
        parameter: str,
        start_month: Optional[int] = None,
        end_month: Optional[int] = None
    ) -> Optional[Dict[str, float]]:
        """
        Generic method to query NASA POWER for any weather parameter.

        Args:
            year: Year to query.
            parameter: NASA POWER parameter name (e.g., "PRECTOTCORR", "T2M", "RH2M").
            start_month: Starting month (1-12). If None, uses growing_season_start.
            end_month: Ending month (1-12). If None, uses growing_season_end.

        Returns:
            Dictionary mapping date strings to parameter values, or None if API fails.
        """
        try:
            import calendar
            
            # Use provided months or fall back to growing season
            start_m = start_month if start_month is not None else self.growing_season_start
            end_m = end_month if end_month is not None else self.growing_season_end
            
            start_date = f"{year}{start_m:02d}01"
            # End on last day of the end month
            if end_m == 12:
                end_date = f"{year}1231"
            else:
                last_day = calendar.monthrange(year, end_m)[1]
                end_date = f"{year}{end_m:02d}{last_day:02d}"

            url = (
                f"{self.POWER_URL}?"
                f"parameters={parameter}&"
                f"community=AG&"
                f"longitude={self.longitude}&"
                f"latitude={self.latitude}&"
                f"start={start_date}&"
                f"end={end_date}&"
                f"format=JSON"
            )

            logger.info(f"Querying NASA POWER for {parameter} in year {year}")

            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))

            # Extract daily values
            param_data = (
                data.get("properties", {})
                .get("parameter", {})
                .get(parameter, {})
            )

            if not param_data:
                logger.warning(f"No {parameter} data in NASA POWER response for {year}")
                return None

            return param_data

        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
            logger.warning(f"NASA POWER API error for year {year}, parameter {parameter}: {e}")
            return None
        except Exception as e:
            logger.warning(f"Unexpected error querying NASA POWER for year {year}: {e}")
            return None

    def get_growing_season_precipitation(self, year: int) -> Optional[float]:
        """
        Query NASA POWER for total growing season precipitation (mm).

        Uses the PRECTOTCORR parameter (Precipitation Corrected) from the
        POWER daily API, which provides bias-corrected precipitation values.

        Args:
            year: Year to query.

        Returns:
            Total growing season precipitation in mm, or None if API fails.
        """
        precip_data = self._get_weather_data(year, "PRECTOTCORR")
        if precip_data is None:
            return None

        # Sum valid daily values (NASA POWER uses -999 for missing)
        total_precip = 0.0
        valid_days = 0
        for date_str, value in precip_data.items():
            if value is not None and value > -998:
                total_precip += value
                valid_days += 1

        if valid_days == 0:
            logger.warning(f"No valid precipitation days for year {year}")
            return None

        logger.info(
            f"Year {year}: {total_precip:.1f} mm precipitation "
            f"over {valid_days} days (growing season)"
        )
        return total_precip

    def get_growing_season_temperature(self, year: int, stat: str = "mean") -> Optional[float]:
        """
        Query NASA POWER for growing season temperature statistics (°C).

        Args:
            year: Year to query.
            stat: Temperature statistic to retrieve:
                - "mean": Average daily temperature (T2M)
                - "max": Average daily maximum temperature (T2M_MAX)
                - "min": Average daily minimum temperature (T2M_MIN)

        Returns:
            Average temperature for the growing season in °C, or None if API fails.
        """
        param_map = {
            "mean": "T2M",
            "max": "T2M_MAX",
            "min": "T2M_MIN"
        }
        
        if stat not in param_map:
            raise ValueError(f"Invalid stat '{stat}'. Must be one of: {list(param_map.keys())}")
        
        parameter = param_map[stat]
        temp_data = self._get_weather_data(year, parameter)
        if temp_data is None:
            return None

        # Calculate mean of daily values
        valid_temps = [v for v in temp_data.values() if v is not None and v > -998]
        if not valid_temps:
            logger.warning(f"No valid temperature days for year {year}")
            return None

        avg_temp = float(np.mean(valid_temps))
        logger.info(
            f"Year {year}: {avg_temp:.1f}°C average {stat} temperature "
            f"over {len(valid_temps)} days (growing season)"
        )
        return avg_temp

    def get_growing_season_solar_radiation(self, year: int) -> Optional[float]:
        """
        Query NASA POWER for growing season solar radiation (MJ/m²/day).

        Uses the ALLSKY_SFC_SW_DWN parameter (All Sky Surface Shortwave 
        Downward Irradiance), which represents total solar energy reaching 
        the surface.

        Args:
            year: Year to query.

        Returns:
            Average daily solar radiation for the growing season in MJ/m²/day, 
            or None if API fails.
        """
        solar_data = self._get_weather_data(year, "ALLSKY_SFC_SW_DWN")
        if solar_data is None:
            return None

        # Calculate mean of daily values
        valid_values = [v for v in solar_data.values() if v is not None and v > -998]
        if not valid_values:
            logger.warning(f"No valid solar radiation days for year {year}")
            return None

        avg_solar = float(np.mean(valid_values))
        logger.info(
            f"Year {year}: {avg_solar:.2f} MJ/m²/day average solar radiation "
            f"over {len(valid_values)} days (growing season)"
        )
        return avg_solar

    def get_growing_season_humidity(self, year: int) -> Optional[float]:
        """
        Query NASA POWER for growing season relative humidity (%).

        Uses the RH2M parameter (Relative Humidity at 2 Meters).

        Args:
            year: Year to query.

        Returns:
            Average relative humidity for the growing season in %, 
            or None if API fails.
        """
        humidity_data = self._get_weather_data(year, "RH2M")
        if humidity_data is None:
            return None

        # Calculate mean of daily values
        valid_values = [v for v in humidity_data.values() if v is not None and v > -998]
        if not valid_values:
            logger.warning(f"No valid humidity days for year {year}")
            return None

        avg_humidity = float(np.mean(valid_values))
        logger.info(
            f"Year {year}: {avg_humidity:.1f}% average relative humidity "
            f"over {len(valid_values)} days (growing season)"
        )
        return avg_humidity

    def get_growing_season_wind_speed(self, year: int) -> Optional[float]:
        """
        Query NASA POWER for growing season wind speed (m/s).

        Uses the WS2M parameter (Wind Speed at 2 Meters).

        Args:
            year: Year to query.

        Returns:
            Average wind speed for the growing season in m/s, 
            or None if API fails.
        """
        wind_data = self._get_weather_data(year, "WS2M")
        if wind_data is None:
            return None

        # Calculate mean of daily values
        valid_values = [v for v in wind_data.values() if v is not None and v > -998]
        if not valid_values:
            logger.warning(f"No valid wind speed days for year {year}")
            return None

        avg_wind = float(np.mean(valid_values))
        logger.info(
            f"Year {year}: {avg_wind:.2f} m/s average wind speed "
            f"over {len(valid_values)} days (growing season)"
        )
        return avg_wind

    def get_all_weather_parameters(self, year: int) -> Optional[Dict[str, float]]:
        """
        Query NASA POWER for all available weather parameters at once.

        This is more efficient than calling individual methods since it makes
        a single API call to fetch all parameters.

        Args:
            year: Year to query.

        Returns:
            Dictionary with all weather parameters:
                - precipitation: Total growing season precipitation (mm)
                - temperature_mean: Average daily temperature (°C)
                - temperature_max: Average daily maximum temperature (°C)
                - temperature_min: Average daily minimum temperature (°C)
                - solar_radiation: Average daily solar radiation (MJ/m²/day)
                - humidity: Average relative humidity (%)
                - wind_speed: Average wind speed (m/s)
            Returns None if API fails.
        """
        try:
            start_date = f"{year}{self.growing_season_start:02d}01"
            if self.growing_season_end == 12:
                end_date = f"{year}1231"
            else:
                import calendar
                last_day = calendar.monthrange(year, self.growing_season_end)[1]
                end_date = f"{year}{self.growing_season_end:02d}{last_day:02d}"

            # Request all parameters in a single API call
            parameters = "PRECTOTCORR,T2M,T2M_MAX,T2M_MIN,ALLSKY_SFC_SW_DWN,RH2M,WS2M"
            
            url = (
                f"{self.POWER_URL}?"
                f"parameters={parameters}&"
                f"community=AG&"
                f"longitude={self.longitude}&"
                f"latitude={self.latitude}&"
                f"start={start_date}&"
                f"end={end_date}&"
                f"format=JSON"
            )

            logger.info(f"Querying NASA POWER for all weather parameters in year {year}")

            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))

            # Extract all parameter data
            params = data.get("properties", {}).get("parameter", {})
            
            if not params:
                logger.warning(f"No weather data in NASA POWER response for {year}")
                return None

            # Calculate statistics for each parameter
            result = {}
            
            # Precipitation (sum)
            precip_data = params.get("PRECTOTCORR", {})
            valid_precip = [v for v in precip_data.values() if v is not None and v > -998]
            result["precipitation"] = float(np.sum(valid_precip)) if valid_precip else None
            
            # Temperature mean
            temp_data = params.get("T2M", {})
            valid_temp = [v for v in temp_data.values() if v is not None and v > -998]
            result["temperature_mean"] = float(np.mean(valid_temp)) if valid_temp else None
            
            # Temperature max
            temp_max_data = params.get("T2M_MAX", {})
            valid_temp_max = [v for v in temp_max_data.values() if v is not None and v > -998]
            result["temperature_max"] = float(np.mean(valid_temp_max)) if valid_temp_max else None
            
            # Temperature min
            temp_min_data = params.get("T2M_MIN", {})
            valid_temp_min = [v for v in temp_min_data.values() if v is not None and v > -998]
            result["temperature_min"] = float(np.mean(valid_temp_min)) if valid_temp_min else None
            
            # Solar radiation
            solar_data = params.get("ALLSKY_SFC_SW_DWN", {})
            valid_solar = [v for v in solar_data.values() if v is not None and v > -998]
            result["solar_radiation"] = float(np.mean(valid_solar)) if valid_solar else None
            
            # Humidity
            humidity_data = params.get("RH2M", {})
            valid_humidity = [v for v in humidity_data.values() if v is not None and v > -998]
            result["humidity"] = float(np.mean(valid_humidity)) if valid_humidity else None
            
            # Wind speed
            wind_data = params.get("WS2M", {})
            valid_wind = [v for v in wind_data.values() if v is not None and v > -998]
            result["wind_speed"] = float(np.mean(valid_wind)) if valid_wind else None

            logger.info(f"Year {year}: Retrieved all weather parameters successfully")
            return result

        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
            logger.warning(f"NASA POWER API error for year {year}: {e}")
            return None
        except Exception as e:
            logger.warning(f"Unexpected error querying NASA POWER for year {year}: {e}")
            return None

    def _validate_month_range(self, month: int, end_month: Optional[int] = None) -> None:
        """
        Validate month parameters.

        Args:
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional.

        Raises:
            ValueError: If month values are invalid.
        """
        if not (1 <= month <= 12):
            raise ValueError(f"month must be between 1 and 12, got {month}")
        
        if end_month is not None:
            if not (1 <= end_month <= 12):
                raise ValueError(f"end_month must be between 1 and 12, got {end_month}")
            if end_month < month:
                raise ValueError(
                    f"end_month ({end_month}) must be >= month ({month}). "
                    f"Cross-year ranges are not supported."
                )

    def get_monthly_precipitation(
        self, 
        year: int, 
        month: int, 
        end_month: Optional[int] = None
    ) -> Optional[float]:
        """
        Query NASA POWER for total precipitation for a specific month or month range.

        Args:
            year: Year to query.
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional. If provided, queries from 
                month to end_month (inclusive).

        Returns:
            Total precipitation in mm for the specified period, or None if API fails.

        Examples:
            # Get precipitation for April 2023
            precip = weather.get_monthly_precipitation(2023, 4)
            
            # Get precipitation for April-June 2023
            spring_precip = weather.get_monthly_precipitation(2023, 4, end_month=6)
        """
        self._validate_month_range(month, end_month)
        
        precip_data = self._get_weather_data(
            year, "PRECTOTCORR", start_month=month, end_month=end_month
        )
        if precip_data is None:
            return None

        # Sum valid daily values
        valid_precip = [v for v in precip_data.values() if v is not None and v > -998]
        if not valid_precip:
            logger.warning(f"No valid precipitation days for {year}/{month}")
            return None

        total_precip = float(np.sum(valid_precip))
        month_str = f"{month}" if end_month is None else f"{month}-{end_month}"
        logger.info(
            f"Year {year}, month(s) {month_str}: {total_precip:.1f} mm precipitation "
            f"over {len(valid_precip)} days"
        )
        return total_precip

    def get_monthly_temperature(
        self, 
        year: int, 
        month: int, 
        end_month: Optional[int] = None,
        stat: str = "mean"
    ) -> Optional[float]:
        """
        Query NASA POWER for temperature statistics for a specific month or month range.

        Args:
            year: Year to query.
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional. If provided, queries from 
                month to end_month (inclusive).
            stat: Temperature statistic to retrieve:
                - "mean": Average daily temperature (T2M)
                - "max": Average daily maximum temperature (T2M_MAX)
                - "min": Average daily minimum temperature (T2M_MIN)

        Returns:
            Average temperature for the specified period in °C, or None if API fails.

        Examples:
            # Get average temperature for July 2022
            temp = weather.get_monthly_temperature(2022, 7, stat="mean")
            
            # Get average max temperature for summer (June-August) 2023
            summer_max = weather.get_monthly_temperature(2023, 6, end_month=8, stat="max")
        """
        self._validate_month_range(month, end_month)
        
        param_map = {
            "mean": "T2M",
            "max": "T2M_MAX",
            "min": "T2M_MIN"
        }
        
        if stat not in param_map:
            raise ValueError(f"Invalid stat '{stat}'. Must be one of: {list(param_map.keys())}")
        
        parameter = param_map[stat]
        temp_data = self._get_weather_data(
            year, parameter, start_month=month, end_month=end_month
        )
        if temp_data is None:
            return None

        # Calculate mean of daily values
        valid_temps = [v for v in temp_data.values() if v is not None and v > -998]
        if not valid_temps:
            logger.warning(f"No valid temperature days for {year}/{month}")
            return None

        avg_temp = float(np.mean(valid_temps))
        month_str = f"{month}" if end_month is None else f"{month}-{end_month}"
        logger.info(
            f"Year {year}, month(s) {month_str}: {avg_temp:.1f}°C average {stat} temperature "
            f"over {len(valid_temps)} days"
        )
        return avg_temp

    def get_monthly_solar_radiation(
        self, 
        year: int, 
        month: int, 
        end_month: Optional[int] = None
    ) -> Optional[float]:
        """
        Query NASA POWER for solar radiation for a specific month or month range.

        Args:
            year: Year to query.
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional. If provided, queries from 
                month to end_month (inclusive).

        Returns:
            Average daily solar radiation for the specified period in MJ/m²/day, 
            or None if API fails.

        Examples:
            # Get solar radiation for June 2023
            solar = weather.get_monthly_solar_radiation(2023, 6)
            
            # Get average solar radiation for growing season (April-September)
            season_solar = weather.get_monthly_solar_radiation(2023, 4, end_month=9)
        """
        self._validate_month_range(month, end_month)
        
        solar_data = self._get_weather_data(
            year, "ALLSKY_SFC_SW_DWN", start_month=month, end_month=end_month
        )
        if solar_data is None:
            return None

        # Calculate mean of daily values
        valid_values = [v for v in solar_data.values() if v is not None and v > -998]
        if not valid_values:
            logger.warning(f"No valid solar radiation days for {year}/{month}")
            return None

        avg_solar = float(np.mean(valid_values))
        month_str = f"{month}" if end_month is None else f"{month}-{end_month}"
        logger.info(
            f"Year {year}, month(s) {month_str}: {avg_solar:.2f} MJ/m²/day average solar radiation "
            f"over {len(valid_values)} days"
        )
        return avg_solar

    def get_monthly_humidity(
        self, 
        year: int, 
        month: int, 
        end_month: Optional[int] = None
    ) -> Optional[float]:
        """
        Query NASA POWER for relative humidity for a specific month or month range.

        Args:
            year: Year to query.
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional. If provided, queries from 
                month to end_month (inclusive).

        Returns:
            Average relative humidity for the specified period in %, 
            or None if API fails.

        Examples:
            # Get humidity for August 2023
            humidity = weather.get_monthly_humidity(2023, 8)
            
            # Get average humidity for spring (March-May)
            spring_humidity = weather.get_monthly_humidity(2023, 3, end_month=5)
        """
        self._validate_month_range(month, end_month)
        
        humidity_data = self._get_weather_data(
            year, "RH2M", start_month=month, end_month=end_month
        )
        if humidity_data is None:
            return None

        # Calculate mean of daily values
        valid_values = [v for v in humidity_data.values() if v is not None and v > -998]
        if not valid_values:
            logger.warning(f"No valid humidity days for {year}/{month}")
            return None

        avg_humidity = float(np.mean(valid_values))
        month_str = f"{month}" if end_month is None else f"{month}-{end_month}"
        logger.info(
            f"Year {year}, month(s) {month_str}: {avg_humidity:.1f}% average relative humidity "
            f"over {len(valid_values)} days"
        )
        return avg_humidity

    def get_monthly_wind_speed(
        self, 
        year: int, 
        month: int, 
        end_month: Optional[int] = None
    ) -> Optional[float]:
        """
        Query NASA POWER for wind speed for a specific month or month range.

        Args:
            year: Year to query.
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional. If provided, queries from 
                month to end_month (inclusive).

        Returns:
            Average wind speed for the specified period in m/s, 
            or None if API fails.

        Examples:
            # Get wind speed for March 2023
            wind = weather.get_monthly_wind_speed(2023, 3)
            
            # Get average wind speed for winter (December-February)
            # Note: Use December of previous year for Dec-Feb range
            winter_wind = weather.get_monthly_wind_speed(2022, 12, end_month=12)
            jan_feb_wind = weather.get_monthly_wind_speed(2023, 1, end_month=2)
        """
        self._validate_month_range(month, end_month)
        
        wind_data = self._get_weather_data(
            year, "WS2M", start_month=month, end_month=end_month
        )
        if wind_data is None:
            return None

        # Calculate mean of daily values
        valid_values = [v for v in wind_data.values() if v is not None and v > -998]
        if not valid_values:
            logger.warning(f"No valid wind speed days for {year}/{month}")
            return None

        avg_wind = float(np.mean(valid_values))
        month_str = f"{month}" if end_month is None else f"{month}-{end_month}"
        logger.info(
            f"Year {year}, month(s) {month_str}: {avg_wind:.2f} m/s average wind speed "
            f"over {len(valid_values)} days"
        )
        return avg_wind

    def get_monthly_weather(
        self,
        year: int,
        month: int,
        end_month: Optional[int] = None,
        parameters: Optional[List[str]] = None
    ) -> Optional[Dict[str, float]]:
        """
        Query NASA POWER for all or specified weather parameters for a month or month range.

        This is more efficient than calling individual methods when you need multiple
        parameters, as it makes a single API call.

        Args:
            year: Year to query.
            month: Starting month (1-12).
            end_month: Ending month (1-12), optional. If provided, queries from 
                month to end_month (inclusive).
            parameters: List of parameter names to fetch. If None, fetches all available
                parameters. Valid values: ["precipitation", "temperature_mean", 
                "temperature_max", "temperature_min", "solar_radiation", "humidity", 
                "wind_speed"]

        Returns:
            Dictionary with requested weather parameters:
                - precipitation: Total precipitation (mm)
                - temperature_mean: Average daily temperature (°C)
                - temperature_max: Average daily maximum temperature (°C)
                - temperature_min: Average daily minimum temperature (°C)
                - solar_radiation: Average daily solar radiation (MJ/m²/day)
                - humidity: Average relative humidity (%)
                - wind_speed: Average wind speed (m/s)
            Returns None if API fails.

        Examples:
            # Get all weather data for April 2023
            april_weather = weather.get_monthly_weather(2023, 4)
            
            # Get precipitation and temperature for summer (June-August)
            summer_weather = weather.get_monthly_weather(
                2023, 6, end_month=8, 
                parameters=["precipitation", "temperature_mean"]
            )
        """
        self._validate_month_range(month, end_month)
        
        try:
            import calendar
            
            # Use provided months
            start_m = month
            end_m = end_month if end_month is not None else month
            
            start_date = f"{year}{start_m:02d}01"
            if end_m == 12:
                end_date = f"{year}1231"
            else:
                last_day = calendar.monthrange(year, end_m)[1]
                end_date = f"{year}{end_m:02d}{last_day:02d}"

            # Request all parameters in a single API call
            all_params = "PRECTOTCORR,T2M,T2M_MAX,T2M_MIN,ALLSKY_SFC_SW_DWN,RH2M,WS2M"
            
            url = (
                f"{self.POWER_URL}?"
                f"parameters={all_params}&"
                f"community=AG&"
                f"longitude={self.longitude}&"
                f"latitude={self.latitude}&"
                f"start={start_date}&"
                f"end={end_date}&"
                f"format=JSON"
            )

            month_str = f"{month}" if end_month is None else f"{month}-{end_month}"
            logger.info(f"Querying NASA POWER for all weather parameters for {year}/{month_str}")

            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))

            # Extract all parameter data
            params_data = data.get("properties", {}).get("parameter", {})
            
            if not params_data:
                logger.warning(f"No weather data in NASA POWER response for {year}/{month_str}")
                return None

            # Calculate statistics for each parameter
            result = {}
            
            # Precipitation (sum)
            precip_data = params_data.get("PRECTOTCORR", {})
            valid_precip = [v for v in precip_data.values() if v is not None and v > -998]
            result["precipitation"] = float(np.sum(valid_precip)) if valid_precip else None
            
            # Temperature mean
            temp_data = params_data.get("T2M", {})
            valid_temp = [v for v in temp_data.values() if v is not None and v > -998]
            result["temperature_mean"] = float(np.mean(valid_temp)) if valid_temp else None
            
            # Temperature max
            temp_max_data = params_data.get("T2M_MAX", {})
            valid_temp_max = [v for v in temp_max_data.values() if v is not None and v > -998]
            result["temperature_max"] = float(np.mean(valid_temp_max)) if valid_temp_max else None
            
            # Temperature min
            temp_min_data = params_data.get("T2M_MIN", {})
            valid_temp_min = [v for v in temp_min_data.values() if v is not None and v > -998]
            result["temperature_min"] = float(np.mean(valid_temp_min)) if valid_temp_min else None
            
            # Solar radiation
            solar_data = params_data.get("ALLSKY_SFC_SW_DWN", {})
            valid_solar = [v for v in solar_data.values() if v is not None and v > -998]
            result["solar_radiation"] = float(np.mean(valid_solar)) if valid_solar else None
            
            # Humidity
            humidity_data = params_data.get("RH2M", {})
            valid_humidity = [v for v in humidity_data.values() if v is not None and v > -998]
            result["humidity"] = float(np.mean(valid_humidity)) if valid_humidity else None
            
            # Wind speed
            wind_data = params_data.get("WS2M", {})
            valid_wind = [v for v in wind_data.values() if v is not None and v > -998]
            result["wind_speed"] = float(np.mean(valid_wind)) if valid_wind else None

            # Filter to requested parameters if specified
            if parameters is not None:
                result = {k: v for k, v in result.items() if k in parameters}

            logger.info(f"Year {year}, month(s) {month_str}: Retrieved weather parameters successfully")
            return result

        except (urllib.error.URLError, urllib.error.HTTPError, json.JSONDecodeError) as e:
            logger.warning(f"NASA POWER API error for {year}/{month}: {e}")
            return None
        except Exception as e:
            logger.warning(f"Unexpected error querying NASA POWER for {year}/{month}: {e}")
            return None

    def classify_years(
        self,
        years: List[int],
        baseline_period: Tuple[int, int] = (1991, 2020),
        use_climatology: bool = True,
    ) -> Dict[str, List[int]]:
        """
        Classify years as dry, normal, or wet based on precipitation.

        Two classification methods are available:

        1. **Climatology** (default, recommended): Compares against 30-year
           climate normals. Uses standard deviations from the long-term mean:
           - Dry: < baseline_mean - 0.5 * baseline_std
           - Normal: baseline_mean ± 0.5 * baseline_std
           - Wet: > baseline_mean + 0.5 * baseline_std

           This provides objective, scientifically-valid classifications that
           work with any sample size.

        2. **Relative percentiles**: Classifies years relative to each other
           using terciles (33rd/67th percentiles). Only use this if you have
           a large sample (10+ years) and want to compare years within your
           specific dataset rather than to historical norms.

        Args:
            years: List of years to classify.
            baseline_period: Tuple of (start_year, end_year) for climatological
                baseline. Default is (1991, 2020), the WMO standard climate
                normal period. Only used if use_climatology=True.
            use_climatology: If True, use climatological baseline (recommended).
                If False, use relative percentiles within the input years.

        Returns:
            Dict with keys "dry", "normal", "wet", each mapping to a list of years.
            Years where the API failed are excluded from classification.

        Raises:
            NASAPowerAPIError: If the API was unreachable for ALL queried years.
        """
        result = {"dry": [], "normal": [], "wet": []}

        # Fetch precipitation for requested years (in parallel)
        logger.info(f"Fetching precipitation data for {len(years)} years...")
        year_precip = self._fetch_precipitation_concurrent(years)

        if len(year_precip) == 0:
            raise NASAPowerAPIError(
                f"NASA POWER API unreachable for all {len(years)} queried years"
            )

        if use_climatology:
            # Fetch 30-year baseline for climatological comparison
            baseline_years = list(range(baseline_period[0], baseline_period[1] + 1))
            logger.info(
                f"Fetching {len(baseline_years)}-year climatological baseline "
                f"({baseline_period[0]}-{baseline_period[1]})..."
            )
            baseline_precip = self._fetch_precipitation_concurrent(baseline_years)

            if len(baseline_precip) < 20:
                logger.warning(
                    f"Only {len(baseline_precip)}/{len(baseline_years)} baseline years "
                    f"available. Falling back to relative percentiles."
                )
                use_climatology = False
            else:
                # Compute climatological statistics
                baseline_values = np.array(list(baseline_precip.values()))
                mean_precip = float(np.mean(baseline_values))
                std_precip = float(np.std(baseline_values))

                # Classification thresholds (±0.5 standard deviations)
                dry_threshold = mean_precip - 0.5 * std_precip
                wet_threshold = mean_precip + 0.5 * std_precip

                logger.info(
                    f"Climatological baseline: mean={mean_precip:.1f}mm, "
                    f"std={std_precip:.1f}mm, "
                    f"dry<{dry_threshold:.1f}mm, wet>{wet_threshold:.1f}mm"
                )

                # Classify years against baseline
                for year, precip in year_precip.items():
                    if precip < dry_threshold:
                        result["dry"].append(year)
                    elif precip > wet_threshold:
                        result["wet"].append(year)
                    else:
                        result["normal"].append(year)

        if not use_climatology:
            # Fall back to relative percentiles
            if len(year_precip) < 3:
                logger.warning(
                    f"Only {len(year_precip)} years with precipitation data. "
                    f"Classifying all as normal."
                )
                result["normal"] = list(year_precip.keys())
                return result

            # Compute tercile boundaries from input years only
            precip_values = np.array(list(year_precip.values()))
            p33 = float(np.percentile(precip_values, 33.33))
            p67 = float(np.percentile(precip_values, 66.67))

            logger.warning(
                f"Using relative percentiles (not recommended for small samples). "
                f"Tercile bounds: p33={p33:.1f}mm, p67={p67:.1f}mm"
            )

            for year, precip in year_precip.items():
                if precip < p33:
                    result["dry"].append(year)
                elif precip > p67:
                    result["wet"].append(year)
                else:
                    result["normal"].append(year)

        logger.info(
            f"Weather classification — "
            f"dry ({len(result['dry'])}): {sorted(result['dry'])}, "
            f"normal ({len(result['normal'])}): {sorted(result['normal'])}, "
            f"wet ({len(result['wet'])}): {sorted(result['wet'])}"
        )

        return result

class NASAPowerAPIError(Exception):
    """Raised when the NASA POWER API is unreachable for all queried years."""
    pass
