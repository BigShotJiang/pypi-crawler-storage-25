"""
Growing Degree Days (GDD) computation using NASA POWER API temperature data.

Growing Degree Days quantify heat accumulation above a crop-specific base
temperature. The standard formula is max(0, (T_max + T_min) / 2 - T_base),
computed in °F from NASA POWER Celsius data.

Corn uses a modified method with T_max capped at 86°F and T_min floored at
50°F before averaging.

NASA POWER API reference: https://power.larc.nasa.gov/docs/services/api/
"""

import datetime
import json
import logging
import urllib.error
import urllib.request
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)


class GDDDataError(Exception):
    """Raised when temperature data cannot be fetched from NASA POWER."""
    pass


class GDDComputer:
    """
    Compute Growing Degree Days (GDD) using NASA POWER daily temperature data.

    GDD quantify heat accumulation above a crop-specific base temperature.
    The standard formula is max(0, (T_max + T_min) / 2 - T_base), computed
    in °F. Corn uses a modified method: T_max capped at 86°F, T_min floored
    at 50°F before averaging.

    Example usage:
        gdd = GDDComputer(latitude=41.5, longitude=-93.5)

        # Total GDD for corn between two dates
        total = gdd.compute_gdd_total("2023-05-01", "2023-09-30", crop="corn")

        # Find when 1500 GDD were reached after planting
        date_reached = gdd.find_gdd_date("2023-05-01", target_gdd=1500, crop="corn")

        # Daily series for cotton
        series = gdd.get_gdd_series("2023-04-01", "2023-08-31", crop="cotton")

        # Custom base temperature in °C
        total_c = gdd.compute_gdd_total("2023-05-01", "2023-09-30", t_base=10.0, units="C")

        print(GDDComputer.get_supported_crops())
    """

    POWER_URL = "https://power.larc.nasa.gov/api/temporal/daily/point"

    CROP_BASE_TEMPS_F: Dict[str, float] = {
        "corn": 50.0,
        "soybeans": 50.0,
        "winter_wheat": 32.0,
        "spring_wheat": 32.0,
        "cotton": 60.0,
        "alfalfa": 41.0,
        "sorghum": 50.0,
        "sunflower": 44.0,
        "rice": 50.0,
    }
    CORN_TMAX_CAP_F = 86.0
    CORN_TMIN_FLOOR_F = 50.0

    def __init__(self, latitude: float, longitude: float):
        """
        Args:
            latitude: Field centroid latitude (WGS84).
            longitude: Field centroid longitude (WGS84).
        """
        self.latitude = latitude
        self.longitude = longitude

    @classmethod
    def get_supported_crops(cls) -> Dict[str, float]:
        """Return supported crop names mapped to their base temperatures in °F."""
        return dict(cls.CROP_BASE_TEMPS_F)

    def _to_yyyymmdd(self, date_input) -> str:
        """Convert a date to YYYYMMDD string for the NASA POWER API."""
        if isinstance(date_input, datetime.date):
            return date_input.strftime("%Y%m%d")
        if isinstance(date_input, str):
            parts = date_input.split("-")
            if len(parts) != 3:
                raise ValueError(
                    f"Invalid date string '{date_input}'. Expected 'YYYY-MM-DD'."
                )
            return f"{parts[0]}{parts[1]}{parts[2]}"
        raise ValueError(
            f"date_input must be a str or datetime.date, got {type(date_input).__name__}"
        )

    def _fetch_daily_temps(
        self, start_yyyymmdd: str, end_yyyymmdd: str
    ) -> Dict[str, Tuple[float, float]]:
        """
        Fetch daily T2M_MAX and T2M_MIN from NASA POWER for an arbitrary date range.

        Unlike the weather module, this makes a single call spanning any date
        range (not limited to one calendar year).

        Args:
            start_yyyymmdd: Start date in YYYYMMDD format.
            end_yyyymmdd: End date in YYYYMMDD format.

        Returns:
            Dict mapping "YYYY-MM-DD" date strings to (t_max_c, t_min_c) tuples.
            Days where either value is missing (-999) are excluded.

        Raises:
            GDDDataError: If the API call fails or returns unparseable data.
        """
        url = (
            f"{self.POWER_URL}?"
            f"parameters=T2M_MAX,T2M_MIN&"
            f"community=AG&"
            f"longitude={self.longitude}&"
            f"latitude={self.latitude}&"
            f"start={start_yyyymmdd}&"
            f"end={end_yyyymmdd}&"
            f"format=JSON"
        )

        try:
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, urllib.error.HTTPError) as e:
            raise GDDDataError(
                f"NASA POWER API error fetching temperature data: {e}"
            ) from e
        except json.JSONDecodeError as e:
            raise GDDDataError(
                f"Invalid JSON in NASA POWER response: {e}"
            ) from e

        params = data.get("properties", {}).get("parameter", {})
        t_max_data = params.get("T2M_MAX", {})
        t_min_data = params.get("T2M_MIN", {})

        result: Dict[str, Tuple[float, float]] = {}
        for date_key, t_max in t_max_data.items():
            t_min = t_min_data.get(date_key)
            if t_max is None or t_min is None:
                continue
            if float(t_max) <= -998 or float(t_min) <= -998:
                continue
            iso_date = f"{date_key[:4]}-{date_key[4:6]}-{date_key[6:]}"
            result[iso_date] = (float(t_max), float(t_min))

        return result

    def _compute_daily_gdd(
        self,
        t_max_c: float,
        t_min_c: float,
        t_base_f: float,
        use_modified_corn: bool = False,
    ) -> float:
        """
        Compute GDD for a single day.

        Converts NASA POWER Celsius values to °F, applies corn cap/floor if
        requested, then computes max(0, avg - t_base).

        Args:
            t_max_c: Maximum daily temperature in °C.
            t_min_c: Minimum daily temperature in °C.
            t_base_f: Base temperature in °F.
            use_modified_corn: If True, cap T_max at 86°F and floor T_min at 50°F.

        Returns:
            Daily GDD (always >= 0).
        """
        t_max_f = t_max_c * 9.0 / 5.0 + 32.0
        t_min_f = t_min_c * 9.0 / 5.0 + 32.0

        if use_modified_corn:
            t_max_f = min(t_max_f, self.CORN_TMAX_CAP_F)
            t_min_f = max(t_min_f, self.CORN_TMIN_FLOOR_F)

        avg_f = (t_max_f + t_min_f) / 2.0
        return max(0.0, avg_f - t_base_f)

    def _resolve_crop_params(
        self,
        crop: Optional[str],
        t_base: Optional[float],
        units: str,
    ) -> Tuple[float, bool]:
        """
        Resolve crop/t_base arguments to (t_base_f, use_modified_corn).

        Args:
            crop: Crop name (case-insensitive), or None.
            t_base: Base temperature, or None.
            units: "F" or "C" — unit of t_base (only used when t_base is given).

        Returns:
            Tuple of (base_temperature_in_fahrenheit, use_modified_corn_flag).

        Raises:
            ValueError: If both or neither of crop/t_base are provided, or the
                crop name is unrecognised.
        """
        if crop is not None and t_base is not None:
            raise ValueError("Specify either 'crop' or 't_base', not both.")
        if crop is None and t_base is None:
            raise ValueError("Must specify either 'crop' or 't_base'.")

        if crop is not None:
            crop_key = crop.lower()
            if crop_key not in self.CROP_BASE_TEMPS_F:
                raise ValueError(
                    f"Unknown crop '{crop}'. Supported crops: "
                    f"{sorted(self.CROP_BASE_TEMPS_F.keys())}"
                )
            return self.CROP_BASE_TEMPS_F[crop_key], (crop_key == "corn")

        # t_base given
        if units.upper() == "C":
            t_base_f = float(t_base) * 9.0 / 5.0 + 32.0
        else:
            t_base_f = float(t_base)
        return t_base_f, False

    def get_gdd_series(
        self,
        start_date,
        end_date,
        crop: Optional[str] = None,
        t_base: Optional[float] = None,
        units: str = "F",
    ) -> Dict[str, float]:
        """
        Compute daily GDD for every day between two dates.

        Args:
            start_date: Start date as "YYYY-MM-DD" string or datetime.date.
            end_date: End date as "YYYY-MM-DD" string or datetime.date.
            crop: Crop name (see get_supported_crops()). Mutually exclusive with t_base.
            t_base: Base temperature. Mutually exclusive with crop.
            units: "F" (default) or "C" — unit of t_base when t_base is provided.

        Returns:
            Dict mapping "YYYY-MM-DD" date strings to daily GDD values (float),
            sorted chronologically.

        Raises:
            ValueError: If crop/t_base arguments are invalid.
            GDDDataError: If temperature data cannot be fetched.
        """
        t_base_f, use_modified_corn = self._resolve_crop_params(crop, t_base, units)
        start_str = self._to_yyyymmdd(start_date)
        end_str = self._to_yyyymmdd(end_date)

        daily_temps = self._fetch_daily_temps(start_str, end_str)

        return {
            date_str: self._compute_daily_gdd(t_max_c, t_min_c, t_base_f, use_modified_corn)
            for date_str, (t_max_c, t_min_c) in sorted(daily_temps.items())
        }

    def compute_gdd_total(
        self,
        start_date,
        end_date,
        crop: Optional[str] = None,
        t_base: Optional[float] = None,
        units: str = "F",
    ) -> float:
        """
        Compute total accumulated GDD between two dates.

        Args:
            start_date: Start date as "YYYY-MM-DD" string or datetime.date.
            end_date: End date as "YYYY-MM-DD" string or datetime.date.
            crop: Crop name (see get_supported_crops()). Mutually exclusive with t_base.
            t_base: Base temperature. Mutually exclusive with crop.
            units: "F" (default) or "C" — unit of t_base when t_base is provided.

        Returns:
            Sum of all daily GDD values over the date range.

        Raises:
            ValueError: If crop/t_base arguments are invalid.
            GDDDataError: If temperature data cannot be fetched.
        """
        series = self.get_gdd_series(
            start_date, end_date, crop=crop, t_base=t_base, units=units
        )
        return sum(series.values())

    def find_gdd_date(
        self,
        start_date,
        target_gdd: float,
        crop: Optional[str] = None,
        t_base: Optional[float] = None,
        units: str = "F",
    ) -> Optional[str]:
        """
        Find the date when cumulative GDD first reaches a target.

        Searches up to 365 days from start_date.

        Args:
            start_date: Planting/start date as "YYYY-MM-DD" string or datetime.date.
            target_gdd: GDD accumulation target.
            crop: Crop name (see get_supported_crops()). Mutually exclusive with t_base.
            t_base: Base temperature. Mutually exclusive with crop.
            units: "F" (default) or "C" — unit of t_base when t_base is provided.

        Returns:
            "YYYY-MM-DD" date string of the first day cumulative GDD >= target_gdd,
            or None if the target is not reached within 365 days.

        Raises:
            ValueError: If crop/t_base arguments are invalid.
            GDDDataError: If temperature data cannot be fetched.
        """
        t_base_f, use_modified_corn = self._resolve_crop_params(crop, t_base, units)
        start_str = self._to_yyyymmdd(start_date)

        if isinstance(start_date, str):
            start_dt = datetime.date.fromisoformat(start_date)
        else:
            start_dt = start_date
        end_dt = start_dt + datetime.timedelta(days=365)
        end_str = end_dt.strftime("%Y%m%d")

        daily_temps = self._fetch_daily_temps(start_str, end_str)

        cumulative = 0.0
        for date_str in sorted(daily_temps.keys()):
            t_max_c, t_min_c = daily_temps[date_str]
            cumulative += self._compute_daily_gdd(
                t_max_c, t_min_c, t_base_f, use_modified_corn
            )
            if cumulative >= target_gdd:
                return date_str

        return None
