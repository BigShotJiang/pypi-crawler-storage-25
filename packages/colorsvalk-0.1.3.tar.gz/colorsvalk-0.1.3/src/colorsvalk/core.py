import os
import platform

class Painter:
    # ANSI escape codes
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'  # Reset

    @staticmethod
    def paint(text, color="green", bold=False):
        """Returns colored and optionally bold text."""
        color_code = getattr(Painter, color.upper(), Painter.END)
        style = Painter.BOLD if bold else ""
        return f"{style}{color_code}{text}{Painter.END}"

    @staticmethod
    def open_calc():
        """Opens the system calculator (Windows only)."""
        if platform.system() == "Windows":
            os.system("calc")
            return "Calculator opened!"
        else:
            return "This feature is currently only supported on Windows."