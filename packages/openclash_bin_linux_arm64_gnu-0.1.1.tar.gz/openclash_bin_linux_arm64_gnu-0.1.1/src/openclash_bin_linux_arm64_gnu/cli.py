""" openclash-bin-linux-arm64-gnu """


def main() -> None:
    print("  openclash-bin-linux-arm64-gnu  ")
