# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.7.0] - 2026-04-13

### Added

- Add automatic redirection to the newly created project when in REPL using `new` command
- Add template selection option `-t` to `sereto pdf target` and `sereto pdf finding-group`

### Changed

- **Breaking:** Change the render configuration in the settings to use Typst instead of LaTeX by default. This means that if you are using the default settings, you will need to prepare Typst templates for report, finding group, and statement-of-work rendering. The old LaTeX recipes are still present in the settings, so you can explicitly specify them if needed or change your settings.
- **Breaking:** Rewrote the Dockerfile so that it derives from pandoc/typst Docker image.
- Reworked the `sereto findings show` table to look like the other tables within `show` command.
- Escape path suggestions in REPL.

### Dependencies

- Update click requirement from ~=8.1.7 to ~=8.3.1
- Update jinja2 requirement from ~=3.1.4 to ~=3.1.6
- Update pathspec requirement from >=0.12.1 to ~=1.0.4
- Update prompt-toolkit requirement from ~=3.0.50 to ~=3.0.52
- Update pydantic-settings requirement from ~=2.13.0 to ~=2.13.1
- Update pypdf requirement from ~=6.8.0 to ~=6.10.0
- Update rapidfuzz requirement from ~=3.14.0 to ~=3.14.5
- Update sereto-repl requirement from ~=0.3.1 to ~=0.3.2
- Update textual requirement from ~=8.0.0 to ~=8.2.3
- Bump aiohttp from 3.13.3 to 3.13.4
- Bump cryptography from 46.0.5 to 46.0.7
- Bump pillow from 12.1.1 to 12.2.0
- Bump pygments from 2.19.2 to 2.20.0
- Bump requests from 2.32.5 to 2.33.0

## [0.6.0] - 2026-03-10

### Added

- **Group hints**: Add support for group hints in the sub-finding template frontmatter. This allows to simply specify which finding group a sub-finding belongs to, without having to specify it manually every time.

### Dependencies

- Update pypdf requirement from ~=6.7.0 to ~=6.8.0 to prevent "Annotation sizes differ" warning in the terminal when rendering the report.
- uv.lock: Bump pypdf from 6.7.1 to 6.8.0

## [0.5.8] - 2026-02-24

### Changed

- New release process, which is now automated via GitHub Actions. See [release documentation](docs/development/release.md) for details.

## [0.5.7] - 2026-02-23

### Added

- Select finding group from the TUI when adding a finding with `sereto findings add`.
- `sereto clean` now supports also deleting generated layout files (in `layouts/generated` directory) with the `--generated` flag.

### Changed

- Improve logging at various log levels, including in REPL (new command `log <LEVEL>` to change log level on the fly). Previous `debug` command is now `log debug`.
- Display default value in the TUI when adding a finding with `sereto findings add`.

### Dependencies

- Update pydantic-settings requirement from ~=2.12.0 to ~=2.13.0
- Update textual requirement from ~=7.5.0 to ~=8.0.0

## [0.5.6] - 2026-02-13

### Changes

- Consistently specify encoding (utf-8) when reading/writing files.
- Allow extras for FindingGroup (defined in `findings.toml`).

### Dependencies

- Update textual requirement from ~=7.4.0 to ~=7.5.0
- Bump cryptography from 46.0.2 to 46.0.5
- Update pypdf requirement from ~=6.6.0 to ~=6.7.0

### Security

- uv.lock: Bump pillow from 11.3.0 to 12.1.1

## [0.5.5] - 2026-01-28

Security release (update dependencies).

### Security

- uv.lock: Bump aiohttp from 3.13.0 to 3.13.3
- uv.lock: Bump urllib3 from 2.5.0 to 2.6.3
- uv.lock: Bump fonttools from 4.60.1 to 4.60.2
- uv.lock: Bump pypdf from 6.6.0 to 6.6.2

### Dependencies

- Update rich requirement from ~=14.2.0 to ~=14.3.1
- Update textual requirement from ~=7.3.0 to ~=7.4.0

## [0.5.4] - 2026-01-19

### Added

- Allow `cd` to a project's directory name with a fallback to searching for the project ID (for all versions).
- Add target for mobile category.

### Changed

- Complete refactoring of logging, which now supports log levels.

### Dependencies

- Add loguru as a logging library.
- Update textual requirement from ~=6.8.0 to ~=7.3.0
- Update humanize requirement from ~=4.14.0 to ~=4.15.0
- Update pypdf requirement from ~=6.4.0 to ~=6.6.0
- Update tomlkit requirement from ~=0.13.3 to ~=0.14.0

## [0.5.3] - 2025-12-10

### Changed

- Modified logic how locators are determined for finding groups and sub-findings.
- To access dynamically computed sub-finding locators, use the new method `FindingGroup.subfinding_locators`.

### Dependencies

- Update textual requirement from ~=6.7.0 to ~=6.8.0

## [0.5.2] - 2025-12-01

### Fixed

- Due dates calculation improvements:
  - Due date is not extended during retest
  - It is possible to add finding in retest and define `reported_on` variable, to correctly calculate the due date for this case

### Dependencies

- Update pypdf requirement from ~=6.2.0 to ~=6.4.0
- Update textual requirement from ~=6.5.0 to ~=6.7.0
- Update pydantic-settings requirement from ~=2.11.0 to ~=2.12.0
- Update keyring requirement from ~=25.6.0 to ~=25.7.0

## [0.5.1] - 2025-11-18

### Changed

- Improve logic for loading plugins, which allows us to have also tests for plugins.

### Dependencies

- Update pypdf requirement from ~=6.1.0 to ~=6.2.0

## [0.5.0] - 2025-11-08

Initial **Typst** support. You can specify Typst as your preferred intermediate format in the settings. The default intermediate format remains TeX. Keep in mind that you also need to prepare Typst templates.

Example of configuring Typst as an intermediate format in the settings for `report_recipes`:

```json
  "render": {
    "report_recipes": [
      {
        "name": "default-report",
        "tools": [
          "latexmk"
        ],
        "intermediate_format": "typ"
      }
    ],
    ...
  }
```

### Added

- Add support for Typst as an alternative intermediate format to LaTeX for report generation.

### Fixes

- Strip the frontmatter before processing Jinja2 templates.

## [0.4.2] - 2025-11-05

Bugfix release.

### Fixes

- Categories order is now preserved as defined in settings.
- Change focus on newly added item in `sereto findings add` TUI.

### Dependencies

- Update textual requirement from ~=6.3.0 to ~=6.5.0
- Update pydantic requirement from ~=2.12.0 to ~=2.12.4 to address bug with `serialize_as_any`

## [0.4.1] - 2025-10-20

### Added

- Add tests for `VersionConfig.{filter_targets,filter_dates,filter_people}`

### Fixes

- Ensure `.build/` directory exists even when there are no targets.
- Fix `VersionConfig.filter_targets`
- Do not create empty project directory when templates are empty.

### Dependencies

- Update rich requirement from ~=14.1.0 to ~=14.2.0
- Update textual requirement from ~=6.2.1 to ~=6.3.0
- Update humanize requirement from ~=4.13.0 to ~=4.14.0


## [0.4.0] - 2025-10-08

### Added

- Add method `Project.ensure_dir`.
- Allow generating all finding groups with `sereto pdf finding-group --all`.
- Docs: display version warning when not viewing the latest version of the documentation.

### Changed

- **Breaking:** Change minimum supported Python version to 3.12.

### Dependencies

- Update textual requirement from ~=6.1.0 to ~=6.2.1.
- Update pydantic requirement from ~=2.11.1 to ~=2.12.0.

## [0.3.8] - 2025-10-06

### Added

- Add `show_locator_types` attribute to `FindingGroup` to filter locators shown in the report.
- Add support for Python 3.14 to Tox configuration.
- Add more tests for `VersionConfig`.
- Add documentation versioning.

### Fixed

- Fix `VersionConfig.report_sent_date` property to correctly select the `report_sent` date when set, even when other dates have later timestamps.

### Changed

- Docs build improvements.
- Replace `tomli-w` with `tomlkit` for writing TOML files with style preservation.

### Dependencies

- Update pypdf requirement from ~=6.0.0 to ~=6.1.0
- Update cryptography requirement from ~=45.0.2 to ~=46.0.1
- Update pydantic-settings requirement from ~=2.10.0 to ~=2.11.0

## [0.3.7] - 2025-09-09

### Fixed

- Docker: fix build by installing Python packages into virtual environment.

## [0.3.6] - 2025-09-08

### Added

- Add operators to search within the template content in the `findings add` TUI search.

### Dependencies

- Update rich requirement from ~=14.0.0 to ~=14.1.0
- Update pypdf requirement from ~=5.8.0 to ~=6.0.0
- Update textual requirement from ~=4.0.0 to ~=6.1.0
- Update humanize requirement from ~=4.12.1 to ~=4.13.0
- Update rapidfuzz requirement from ~=3.13.0 to ~=3.14.0

## [0.3.5] - 2025-07-22

### Added

- Add support for loading plugin modules.

### Changed

- Improve the TUI search for finding templates.

### Fixed

- Fix issue in `sereto findings add`, when the finding already exists, and the user chooses to create copy. The finding group name now adds a suffix to the name, so that it does not conflict with the existing finding group.
- Improve completion in several cases by leveraging `StrEnum` instead of `(str, Enum)`.

### Dependencies

- Remove rapidfuzz dependency, as it is not used anymore.
- Update textual requirement from ~=3.5.0 to ~=3.6.0.
- Update pypdf requirement from ~=5.7.0 to ~=5.8.0
- Update textual requirement from ~=3.7.1 to ~=4.0.0

## [0.3.4] - 2025-07-09

### Fixed

- Docker: install `requirements.txt` from templates.
- Docker: use the same UID for the low-privileged user as the owner of the `/projects` directory

## [0.3.3] - 2025-07-08

### Added

- Add warning to `sereto findings add` TUI when the finding already exists, and an option to overwrite it.

### Changed

- Allow lists without preceeding newlines in Markdown.
- Pass `Config` (`config`) and `VersionConfig` (`c`) as Jinja2 variables when rendering sub-findings.

### Fixed

- Fix Docker volume permissions for mounted directories.

### Dependencies

- Update pypdf requirement from ~=5.6.0 to ~=5.7.0

## [0.3.2] - 2025-06-26

### Added

- Add `sereto oxipng` command to optimize PNG images in the report.

### Changed

- Rename output filenames for SoW and report (now they contain the project ID and version).
- Update usage docs about locators

### Fixed

- Properly handle var types (boolean/integer/string) in `sereto findings add` TUI.

### Dependencies

- Add tomli-w to the dependencies to support writing TOML files.
- Update pydantic-settings requirement from ~=2.9.1 to ~=2.10.0
- Update textual requirement from ~=3.4.0 to ~=3.5.0

## [0.3.1] - 2025-06-17

### Added

- Add "hostname" and "domain" locator types.

### Changed

- Documentation: update usage GIFs

### Fixed

- Fix `filter_locators` method, which incorrectly handled iterables on the input.
- Handle exceptions in the REPL `cd` command.

### Dependencies

- Update textual requirement from ~=3.3.0 to ~=3.4.0

## [0.3.0] - 2025-06-13

### Changed

- **Breaking:** Change format of locators from `str` to object with `type`, `value`, and `description` attributes.
- Update documentation.
- Add (this time for real) *graphics* pandoc filter to the default settings.
- Make plugin loading error message more informative.

### Dependencies

- Update textual requirement from ~=3.2.0 to ~=3.3.0
- Update pypdf requirement from ~=5.5.0 to ~=5.6.0

## [0.2.9] - 2025-06-01

### Added

- Introduce `clean` command to remove auxiliary files created during the PDF build.

### Fixed

- `VersionConfig.filter_targets` now correctly returns `list[Target]`, instead of `list[TargetModel]`
- Remove `locators` from the `Target` dataclass. This was included by mistake, as locators are already present in the `data` (`TargetModel`) attribute.

## [0.2.8] - 2025-05-30

### Added

- Add `VersionConfig.due_date_for(risk)` to calculate until when the finding with the given risk should be remediated.
- Add *graphics* pandoc filter to the default settings.
- Add optional `id` attribute for targets

### Changed

- Update documentation.

## [0.2.7] - 2025-05-26

### Security

- CI: Set job permissions

## [0.2.6] - 2025-05-23

### Added

- Add locators for findings and targets.
- Specify `default_people` in settings.
- Add option to `sereto pdf report` to specify report template.

### Dependencies

- Update pypdf requirement from ~=5.4.0 to ~=5.5.0
- Update cryptography requirement from ~=44.0.0 to ~=45.0.2

## [0.2.5] - 2025-04-21

### Fixed

- Do not duplicate the `\figure` environment for images (turn off implicit figure generation)

### Removed

- Remove need for `--shell-escape` when rendering the TeX documents

### Dependencies

- Update pydantic-settings requirement from ~=2.8.0 to ~=2.9.1
- Update rapidfuzz requirement from ~=3.12.1 to ~=3.13.0
- Update textual requirement from ~=3.0.0 to ~=3.1.0

## [0.2.4] - 2025-04-05

### Added

- Add method `Config.replace_version_config`
- Configure variables from the `findings add` TUI

### Changed

- Update error messages for Jinja2 missing variables

### Fixed

- Fix mismatch in the attached source archive name when embedding the archive vs. unpacking.

## [0.2.3] - 2025-04-02

### Changed

- Validate variables for sub-findings if the corresponding template can be found.
- Print error if variable is missing for Jinja2 (optional variables now need to stricly check with `is defined`)

## [0.2.2] - 2025-04-01

### Added

- Add `py.typed` file to the package to indicate that it supports type hints.

### Changed

- Allow constructing `SeretoDate` from string with a custom format string

### Fixed

- Check if there is any target before opening TUI to add findings
- Make `load_plugins` function print name of missing plugin module

### Dependencies

- Update pypdf requirement from ~=5.3.0 to ~=5.4.0
- Update textual requirement from ~=2.1.1 to ~=3.0.0
- Update rich requirement from ~=13.9.2 to ~=14.0.0
- Update pydantic requirement from ~=2.10.1 to ~=2.11.1

## [0.2.1] - 2025-03-10

### Changed

- Add fallback keyring backend (keyring-alt) to support Docker and WSL.
- Fork `click-repl` and build release from master.

## [0.2.0] - 2025-02-26

### Added

- TUI utility for fuzzy searching and adding findings to the report (`sereto findings add`).

### Changed
- **Major refactoring**: separated runtime classes from Pydantic models to better distinguish operational logic from data loading and validation.
- The entire target subtree is now version-specific; for retests, copy the subtree from the previous version.
- Migrated from findings.yaml to findings.toml.
- Updated how risk counts are represented.
- Used more explicit function arguments.
- Revised unique name generation.
- Improved `VersionConfig.filter_dates`.
- Fixed REPL UsageError (requires removing `click-repl` 0.3.0 if installed).

## [0.1.1] - 2025-02-02

### Changed

- Docs: `uv` as preferred package manager for installation.
- `sereto findings add`: Allow adding findings from other categories.

## [0.1.0] - 2024-12-22

### Added

- Introduce plugin system for adding new commands to the CLI.
- Add CLI commands: `sereto pdf target`, `sereto pdf finding-group` to render partial reports.
- `Render`: add methods for selecting recipe

### Changed

- **Breaking:** Implement new directory structure for the project.
- **Breaking:** Rename "informational" risk to "info".
- **Breaking:** Add `version_description` attribute to `VersionConfig`.
- **Breaking:** `ConvertRecipe` now has in addition to input_format also output_format.
- Command `sereto pdf report` no longer renders the partial reports.

### Fixed

- Fix target index in `delete_targets_config`
- Set correct indexes for partials (target, finding group)
- Fix path to template when reading metadata
- Fix the issue with internal links inside PDF being broken after running `embed_source_archive`

### Removed

- Remove `argon2-cffi` dependency. This was added to the `crytography` library in version 44.0.0.

## [0.0.17] - 2024-11-29

### Added

- Docs: Markdown building blocks (writing findings and their templates).
- Jinja2: add debug extension to generic env.
- REPL: Add `exit` command + `debug` command to toggle debug mode. Show debug mode indicator in the prompt.

### Changed

- **Breaking:** Modify the structure of `config.json`.
- Update REPL to use `click-repl`.
- Remove redundancy in Jinja2 rendering.
- Adjust variables passed when rendering Jinja templates.
- Use `prompt_toolkit` for user input.
- Make the default TeX rendering less verbose + fail early.
- Remove command output during rendering. We might still need to show the errors in the future.
- Display command execution time.
- `Config.filter_*` methods now contain parameter `invert`, which allows to invert the filtering logic.
- Avoid overriding TeX files if the content was not changed. This should speed up the rendering process as `latexmk` uses the file modification time to decide whether to recompile the document.

### Fixed

- Fix `Config.filter_*` methods to handle correctly None values.

## [0.0.16] - 2024-10-28

### Added

- Provide helper methods to `VersionConfig` for writing the templates - `filter_targets`, `filter_dates`, and `filter_people`
- Docs: start documenting available building blocks for writing the templates

### Changed

- Use NamedTuple to represent result of key derivation with Argon2
- Use Pydantic's Secret types when dealing with passwords. This prevents the data from being printed in the logs and tracebacks.
- Rename `BaseConfig` class to `VersionConfig`
- Implement `__str__` method for `Date` class
- Make sure the source archive always starts with the directory equal to the project ID, even if the user renamed the directory
- Handle more edge cases when extracting the source archive

### Fixed

- Fix `sereto ls` failing when there is a file in the report directory (too strict argument check in `Project.is_project_dir` function).
- Fix unpacking unencrypted source archive.

### Security

- Use filter [data](https://docs.python.org/3/library/tarfile.html#tarfile.data_filter) when extracting the source archive from tar. This takes care of the following:
    - Strip leading slashes (`/` and `os.sep`) from filenames.
    - Refuse to extract files with absolute paths (in case the name is absolute even after stripping slashes, e.g. `C:/foo` on Windows).
    - Refuse to extract files whose absolute path (after following symlinks) would end up outside the destination.
    - Clear high mode bits (setuid, setgid, sticky) and group/other write bits (`S_IWGRP` | `S_IWOTH`).
    - Refuse to extract links (hard or soft) that link to absolute paths, or ones that link outside the destination.
    - Refuse to extract device files (including pipes).
    - For regular files, including hard links:
        - Set the owner read and write permissions (`S_IRUSR` | `S_IWUSR`).
        - Remove the group & other executable permission (`S_IXGRP` | `S_IXOTH`) if the owner doesn’t have it (`S_IXUSR`).
    - For other files (directories), set `mode` to `None`, so that extraction methods skip applying permission bits.
    - Set user and group info (`uid`, `gid`, `uname`, `gname`) to `None`, so that extraction methods skip setting it.

## [0.0.15] - 2024-10-21

### Changed

- Use `TypeAdapter` instead of `RootModel` in config module.
- Type hints: start using Self
- README: rebranding IT Hub -> Digital Hub
- Improve error message for `Config` and `Settings` validation
- Prefer annotated types over `Field`
- Use more `DirectoryPath` and `FilePath` instead of plain `Path`
- Apply args validation for more function (`@validate_call`)
- Refactor: `Config.from_file` -> `Config.load_from`
- Refactor: `Settings.from_file` -> `Settings.load_from`
- Refactor: `FindingsConfig.from_yaml_file` -> `FindingsConfig.from_yaml`
- Refactor: fn `write_conifg` -> `Config.dump_json`
- Refactor class `Report` to `Project`, which now contains also `settings` and `path` attributes
- Refactor: `Project.load_runtime_vars` -> `Config.update_paths`
- Refactor: `Project.is_report_dir` -> `Project.is_project_dir`
- Refactor: fn `extract_source_archive` -> `retrieve_source_archive`
- Refactor: fn `untar_sources` -> `extract_source_archive`
- Move `config` module into `cli`, as it contains only CLI related functions
- Reflect changes in the documentation

### Removed

- Remove artefacts of `sereto.cli.console`
- Remove module `cleanup`
- Remove unused functions `get_all_projects`, `get_all_projects_dict`, and `is_settings_valid`

## [0.0.14] - 2024-10-18

### Changed

- Code refactoring and cleanup, mainly around source archive handling.
- Validate password retrieved from system keyring against `TypePassword` type.
- Clarify fn usage: `Report.get_path` -> `Report.get_path_from_cwd`.

### Fixed

- `sereto unpack` can now properly handle extracting encrypted or unencrypted archives.

## [0.0.13] - 2024-10-09

### Changed

- Improve REPL and use it as the default command for Docker image.
- Code cleanup: docstrings; move `Console` class to `sereto.cli.utils` module and `handle_exceptions` decorator to `sereto.exceptions`.
- Docs: enable privacy plugin.
- Docs: Set CSP and Referrer-Policy headers through the meta tag.

### Removed

- Remove support for Python 3.10.

## [0.0.12] - 2024-09-27

### Added

- Add a new command `sereto decrypt` to extract the project sources from `source.sereto` file.
- Add a new command `sereto unpack` to extract the project sources from a report's PDF file.

### Changed

- Keyring: change the location, as the username should not be empty.
- Bump version of keyring and pypdf

## [0.0.11] - 2024-09-20

### Added

- Encrypt the attached source archive

### Changed

- Docker: use version as tag, format default settings.json
- CI/CD: Fix invalid `${{ github.ref_name#v }}` syntax

## [0.0.10] - 2024-09-20

### Changed

- Implement REPL (Read-Eval-Print-Loop) for the CLI.
- Extract only relevant part of the changelog into GH release.
- Docs: Update installation instructions related to Docker and DockerHub.
- Adjust Dependabot to use `versioning-strategy: "increase"`.

## [0.0.9] - 2024-09-08

### Changed

- CI/CD: Try to fix Docker pipeline.
- CI/CD: Add checkout action to make the CHANGELOG.md file available.

## [0.0.8] - 2024-09-08

### Added

- CI/CD: Build and push Docker image to Docker Hub.

### Changed

- Include notes from CHANGELOG.md into GH release notes.

## [0.0.7] - 2024-09-07

### Added

- Tests: Add tests for the `sereto new` command.
- Docs: Add section about `sereto.cli.cli`, and `sereto.types` to references.

### Changed

- README: Add PyPI badge, fix link to the installation section in the documentation.
- Docs: Updated the *Usage* section, especially part "Create Report".
- Define annotated types in separate file.

### Fixed

- CI/CD: Add CNAME file to stop overwriting the custom domain in the GitHub Pages deployment.

## [0.0.6] - 2024-09-04

### Added

- Define a security policy in SECURITY.md file.
- Docs: Add security considerations to the documentation.

### Changed

- Docker: Update Dockerfile to use low privileged user for running the application.
- README: Getting started section, mainly pointing to the documentation.

## [0.0.5] - 2024-09-04

### Changed

- CI/CD: Don't upload the package to TestPyPI, pushing the same version again makes the pipeline fail.
- README: Use different image for dark / light mode. Hopefully this will not break the PyPI rendering.
- README: Add badge with a link to the documentation.
- Docs: Move development instructions from README to the documentation.

### Fixed

- Docs: Adjust link since original content from `report_structure.md` was moved to `project_files.md`.

## [0.0.4] - 2024-09-03

- Update image in README.md to absolute URL. This is necessary for the PyPI to render the image correctly.
- Add pipeline for building
- Update docs

## 0.0.2, [0.0.3] - 2024-09-02

We registered a dummy package to PyPI to test the publishing. Therefore a version increment was necessary.

## 0.0.1

Initial version


[unreleased]: https://github.com/s3r3t0/sereto/compare/v0.7.0...HEAD
[0.7.0]: https://github.com/s3r3t0/sereto/compare/v0.6.0...v0.7.0
[0.6.0]: https://github.com/s3r3t0/sereto/compare/v0.5.8...v0.6.0
[0.5.8]: https://github.com/s3r3t0/sereto/compare/v0.5.7...v0.5.8
[0.5.7]: https://github.com/s3r3t0/sereto/compare/v0.5.6...v0.5.7
[0.5.6]: https://github.com/s3r3t0/sereto/compare/v0.5.5...v0.5.6
[0.5.5]: https://github.com/s3r3t0/sereto/compare/v0.5.4...v0.5.5
[0.5.4]: https://github.com/s3r3t0/sereto/compare/v0.5.3...v0.5.4
[0.5.3]: https://github.com/s3r3t0/sereto/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/s3r3t0/sereto/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/s3r3t0/sereto/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/s3r3t0/sereto/compare/v0.4.2...v0.5.0
[0.4.2]: https://github.com/s3r3t0/sereto/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/s3r3t0/sereto/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/s3r3t0/sereto/compare/v0.3.8...v0.4.0
[0.3.8]: https://github.com/s3r3t0/sereto/compare/v0.3.7...v0.3.8
[0.3.7]: https://github.com/s3r3t0/sereto/compare/v0.3.6...v0.3.7
[0.3.6]: https://github.com/s3r3t0/sereto/compare/v0.3.5...v0.3.6
[0.3.5]: https://github.com/s3r3t0/sereto/compare/v0.3.4...v0.3.5
[0.3.4]: https://github.com/s3r3t0/sereto/compare/v0.3.3...v0.3.4
[0.3.3]: https://github.com/s3r3t0/sereto/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.com/s3r3t0/sereto/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/s3r3t0/sereto/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/s3r3t0/sereto/compare/v0.2.9...v0.3.0
[0.2.9]: https://github.com/s3r3t0/sereto/compare/v0.2.8...v0.2.9
[0.2.8]: https://github.com/s3r3t0/sereto/compare/v0.2.7...v0.2.8
[0.2.7]: https://github.com/s3r3t0/sereto/compare/v0.2.6...v0.2.7
[0.2.6]: https://github.com/s3r3t0/sereto/compare/v0.2.5...v0.2.6
[0.2.5]: https://github.com/s3r3t0/sereto/compare/v0.2.4...v0.2.5
[0.2.4]: https://github.com/s3r3t0/sereto/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/s3r3t0/sereto/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/s3r3t0/sereto/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/s3r3t0/sereto/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/s3r3t0/sereto/compare/v0.1.1...v0.2.0
[0.1.1]: https://github.com/s3r3t0/sereto/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/s3r3t0/sereto/compare/v0.0.17...v0.1.0
[0.0.17]: https://github.com/s3r3t0/sereto/compare/v0.0.16...v0.0.17
[0.0.16]: https://github.com/s3r3t0/sereto/compare/v0.0.15...v0.0.16
[0.0.15]: https://github.com/s3r3t0/sereto/compare/v0.0.14...v0.0.15
[0.0.14]: https://github.com/s3r3t0/sereto/compare/v0.0.13...v0.0.14
[0.0.13]: https://github.com/s3r3t0/sereto/compare/v0.0.12...v0.0.13
[0.0.12]: https://github.com/s3r3t0/sereto/compare/v0.0.11...v0.0.12
[0.0.11]: https://github.com/s3r3t0/sereto/compare/v0.0.10...v0.0.11
[0.0.10]: https://github.com/s3r3t0/sereto/compare/v0.0.9...v0.0.10
[0.0.9]: https://github.com/s3r3t0/sereto/compare/v0.0.8...v0.0.9
[0.0.8]: https://github.com/s3r3t0/sereto/compare/v0.0.7...v0.0.8
[0.0.7]: https://github.com/s3r3t0/sereto/compare/v0.0.6...v0.0.7
[0.0.6]: https://github.com/s3r3t0/sereto/compare/v0.0.5...v0.0.6
[0.0.5]: https://github.com/s3r3t0/sereto/compare/v0.0.4...v0.0.5
[0.0.4]: https://github.com/s3r3t0/sereto/compare/v0.0.3...v0.0.4
[0.0.3]: https://github.com/s3r3t0/sereto/releases/tag/v0.0.3
