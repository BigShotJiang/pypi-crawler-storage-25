# Skills — `titon-network-kronos-sdk` (Python)

Persona-grouped recipes the AI surfaces via slash commands. Each file is a
self-contained workflow that an AI can follow end-to-end without any other
context.

## Available skills

| Slash command | When to use it |
|---------------|----------------|
| [`/kronos-register-job`](./kronos-register-job.md) | User wants to schedule a recurring on-chain job. |
| [`/kronos-job-lifecycle`](./kronos-job-lifecycle.md) | User wants to update / pause / resume / withdraw / cancel an existing job. |
| [`/kronos-monitor-events`](./kronos-monitor-events.md) | User wants to build an indexer or alerting bot for Kronos events. |
| [`/kronos-debug-exit-code`](./kronos-debug-exit-code.md) | User pasted a failed-tx exit code or asked "what does Kronos error N mean?". |
| [`/kronos-owner-ops`](./kronos-owner-ops.md) | User is the protocol owner: update config / treasury, withdraw fees, propose / execute / cancel timelocked code upgrades, retry slashes. |

## How `errors.py:related_skill` lines up

`kronos_sdk.errors.explain_error(code)` returns an `ErrorExplanation` whose
``related_skill`` field points at one of the slash commands above. AI
assistants are expected to **load the matching skill file** when the error
fires — the skill walks through the fix.

## When to consult vs reference TS

These are Python-specific mirrors of `../typescript/skills/*.md`. Six TS
skills have no Python counterpart yet:

- `kronos-automaton-setup` — running an automaton (needs the Python forgeton-sdk).
- `kronos-deploy` — deploying a fresh contract (Python deploy script not yet ported; the TS one works against the same bytecode).
- `kronos-gas-sizing` — sizing `gas_limit` (Python ships `recommended_gas_limit` instead of a sandbox estimator).
- `kronos-integration-test` — pytoniq's TVM emulator is too weak for sandbox tests.
- `kronos-scaffold` — bootstrapping a new contract repo.
- `kronos-target-receiver` — writing the Tolk target your job calls.

For now those tasks: read the TS skill first, then translate. The cross-language
patterns are mechanical (snake_case + `await wallet.transfer(...)` + dataclass
construction).

## Adding a new skill

Mirror the TS frontmatter format:

```markdown
---
name: kronos-<topic>
description: One sentence — when to load this skill (used by AI as the routing key).
---

# Title

Body — recipe + pitfalls + related skills.
```

Then add a row to the table above and link it from `AGENTS.md`'s persona
table.
