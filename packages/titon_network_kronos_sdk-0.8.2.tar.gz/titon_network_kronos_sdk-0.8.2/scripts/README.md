# Scripts

Per-package codegen / packaging helpers. Both run from the kronos repo root
and rely on `<repo>/contracts/` + `<repo>/build/` being present.

| Script | What it does | When to re-run |
|--------|-------------|----------------|
| [`gen_opcodes.py`](./gen_opcodes.py) | Parses `contracts/messages.tolk` + `contracts/errors.tolk` and rewrites `src/kronos_sdk/opcodes.py` (the OP / ERR dicts + reverse maps). | Any time you change a struct opcode or `E_*` constant in the Tolk source. Mirrors the TS `scripts/gen-opcodes.ts`. |
| [`copy_artifacts.py`](./copy_artifacts.py) | Copies `<repo>/build/KronosRegistry.compiled.json` into `src/kronos_sdk/artifacts/` so the wheel ships with bundled bytecode. | Before `python -m build --wheel`, or after `pnpm build` regenerates the BoC. |

## Usage

```bash
# from the kronos/ repo root:
python sdks/python/scripts/gen_opcodes.py
python sdks/python/scripts/copy_artifacts.py
```

Both scripts are idempotent — running with no source changes prints
`(unchanged)` / `copied 1 artifact(s)` and modifies nothing relevant.

## Mirror with TS

When editing one, mirror the other:

| Tolk source change | Run |
|--------------------|-----|
| New struct opcode in `messages.tolk` | `pnpm run gen:opcodes` (TS) **and** `python sdks/python/scripts/gen_opcodes.py` (Python) |
| New error in `errors.tolk` | Same opcode regen + add prose row to both `sdks/typescript/src/errors.ts` and `sdks/python/src/kronos_sdk/errors.py` |
| Contract recompile (`pnpm build`) | `pnpm run build:sdk` (TS — has its own copy via `prepublishOnly`) **and** `python sdks/python/scripts/copy_artifacts.py` (Python) |

See [`../AGENTS.md`](../AGENTS.md) §"Mirror checklist when editing the TS SDK"
for the full per-change matrix.
