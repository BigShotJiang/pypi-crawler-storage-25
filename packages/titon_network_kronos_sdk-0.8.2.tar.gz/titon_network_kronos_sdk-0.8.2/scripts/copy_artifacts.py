#!/usr/bin/env python3
"""Copy compiled BoC artifacts from <repo>/build/ into src/kronos_sdk/artifacts/.

Mirror of ../../typescript/scripts/copy-artifacts.cjs. Run before packaging the
Python wheel so the bundled artifact matches the latest contract build.

Run: ``python sdks/python/scripts/copy_artifacts.py`` from the kronos repo root.
"""

import shutil
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[3]
BUILD_DIR = REPO_ROOT / "build"
OUT_DIR = REPO_ROOT / "sdks" / "python" / "src" / "kronos_sdk" / "artifacts"

ARTIFACTS = ["KronosRegistry.compiled.json"]

def main() -> int:
    if not BUILD_DIR.exists():
        print(
            f"[copy-artifacts] build/ not found at {BUILD_DIR}.\n"
            "Run `pnpm build` from the repo root first (compiles the Tolk contracts).",
            file=sys.stderr,
        )
        return 1

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    copied = 0
    for name in ARTIFACTS:
        src = BUILD_DIR / name
        dst = OUT_DIR / name
        if not src.exists():
            print(f"[copy-artifacts] missing {src}", file=sys.stderr)
            return 1
        shutil.copyfile(src, dst)
        copied += 1
        print(f"[copy-artifacts] {name}")

    print(f"[copy-artifacts] copied {copied} artifact(s) to {OUT_DIR}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
