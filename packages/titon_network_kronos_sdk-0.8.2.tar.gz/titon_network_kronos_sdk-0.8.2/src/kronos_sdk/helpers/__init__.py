"""Pure-math helpers — mirror on-chain formulas; zero network calls."""

from .assignment import (
    AssignmentInput,
    ResolveAssignedInput,
    assigned_automaton_index,
    resolve_assigned_automaton,
)
from .cost import (
    BPS_DENOMINATOR,
    ExecutionEconomics,
    ExecutionEconomicsInput,
    RecommendedRegisterValueInput,
    execution_economics,
    recommended_register_value,
)
from .gas import EstimateJobGasResult, recommended_gas_limit
from .windows import (
    ExecutableInput,
    JobWindowInput,
    JobWindowState,
    WindowStatus,
    is_due,
    is_executable,
    job_window_state,
    next_execution_at,
)

# Aliases for the kronos_sdk top-level re-export — short names that read well in
# user code without the helpers. prefix.
assigned_automaton = resolve_assigned_automaton
compute_window_state = job_window_state
estimate_register_value = recommended_register_value
execution_cost = execution_economics
job_funding_for = recommended_register_value

def next_due(*, last_executed_at: int, interval: int) -> int:
    """Return ``last_executed_at + interval`` — the canonical next-due timestamp."""

    return last_executed_at + interval

def window_state(input: JobWindowInput) -> JobWindowState:  # noqa: A002 — mirror TS surface
    """Alias for :func:`job_window_state` so SDK docs translate 1:1."""

    return job_window_state(input)

__all__ = [
    # assignment
    "AssignmentInput",
    "ResolveAssignedInput",
    "assigned_automaton_index",
    "resolve_assigned_automaton",
    # cost
    "BPS_DENOMINATOR",
    "ExecutionEconomics",
    "ExecutionEconomicsInput",
    "RecommendedRegisterValueInput",
    "execution_economics",
    "recommended_register_value",
    # windows
    "ExecutableInput",
    "JobWindowInput",
    "JobWindowState",
    "WindowStatus",
    "is_due",
    "is_executable",
    "job_window_state",
    "next_execution_at",
    # gas
    "EstimateJobGasResult",
    "recommended_gas_limit",
    # convenience aliases
    "assigned_automaton",
    "compute_window_state",
    "estimate_register_value",
    "execution_cost",
    "job_funding_for",
    "next_due",
    "window_state",
]
