"""Job economics — mirrors ``JobConfig.executionEconomics`` in
``contracts/kronos-registry.tolk``.

Off-chain calculators must match the on-chain formula bit-for-bit, otherwise
users get rejected RegisterJob / FundJob calls when their funding looks
adequate locally.

Formula::

    protocol_fee = reward * protocol_fee_bps // BPS_DENOMINATOR  (integer division)
    total_cost   = reward + gas_limit + protocol_fee

All values in nano-TON (Python ``int``).
"""

from dataclasses import dataclass

BPS_DENOMINATOR: int = 10_000

@dataclass(frozen=True)
class ExecutionEconomics:
    total_cost: int
    """Total deducted from job balance per Execute."""
    protocol_fee: int
    """Portion of total_cost that accrues to accumulatedFees."""
    automaton_reward: int
    """Portion paid to the automaton."""
    gas_limit: int
    """Portion forwarded as gas to the target."""

@dataclass(frozen=True)
class ExecutionEconomicsInput:
    reward: int  # nano-TON
    gas_limit: int  # nano-TON
    protocol_fee_bps: int  # 0-10000

@dataclass(frozen=True)
class RecommendedRegisterValueInput:
    reward: int
    gas_limit: int
    protocol_fee_bps: int
    min_gas_reserve: int
    """Registry's ``min_gas_reserve`` config — covers the RegisterJob message processing."""
    executions: int = 1
    """How many executions the funding should cover.

    Default ``1`` matches the TS SDK and the on-chain ``BelowMinForActive``
    floor, but a job funded for a single execution will deactivate after the
    first run. For real deployments pass an explicit value (the TS default of
    ``100`` in ``register_job_opts`` is a reasonable starting point)."""
    min_funding: int = 0
    """Floor enforced by the registry's minFunding config."""

def execution_economics(input: ExecutionEconomicsInput) -> ExecutionEconomics:  # noqa: A002
    """Calculate the per-execution economics of a job.

    Equivalent to on-chain ``JobConfig.executionEconomics`` — use to predict
    a job's burn rate or to validate funding off-chain.

    Example::

        e = execution_economics(ExecutionEconomicsInput(
            reward=int(0.05 * 10**9),
            gas_limit=int(0.02 * 10**9),
            protocol_fee_bps=500,  # 5%
        ))
        # e.total_cost      = 0.0725 TON
        # e.protocol_fee    = 0.0025 TON
        # e.automaton_reward = 0.05 TON
    """
    if input.protocol_fee_bps < 0 or input.protocol_fee_bps > BPS_DENOMINATOR:
        raise ValueError(
            f"protocol_fee_bps must be in [0, {BPS_DENOMINATOR}], got {input.protocol_fee_bps}"
        )
    protocol_fee = (input.reward * input.protocol_fee_bps) // BPS_DENOMINATOR
    total_cost = input.reward + input.gas_limit + protocol_fee
    return ExecutionEconomics(
        total_cost=total_cost,
        protocol_fee=protocol_fee,
        automaton_reward=input.reward,
        gas_limit=input.gas_limit,
    )

def recommended_register_value(input: RecommendedRegisterValueInput) -> int:  # noqa: A002
    """Recommended attached ``value`` for RegisterJob / FundJob.

    Sums ``max(executions × execution_cost, min_funding)`` (the job-balance
    credit) and ``min_gas_reserve`` (the message-processing buffer).

    Example::

        cfg = await client.jobs.config()
        value = recommended_register_value(RecommendedRegisterValueInput(
            reward=int(0.05 * 10**9),
            gas_limit=int(0.02 * 10**9),
            protocol_fee_bps=cfg.protocol_fee_bps,
            min_gas_reserve=cfg.min_gas_reserve,
            min_funding=cfg.min_funding,
            executions=100,  # fund for ~100 runs
        ))
    """
    if input.executions <= 0:
        raise ValueError(f"executions must be > 0, got {input.executions}")
    per_exec = execution_economics(
        ExecutionEconomicsInput(
            reward=input.reward,
            gas_limit=input.gas_limit,
            protocol_fee_bps=input.protocol_fee_bps,
        )
    ).total_cost
    required = per_exec * input.executions
    floor = input.min_funding
    job_balance = required if required > floor else floor
    return job_balance + input.min_gas_reserve
