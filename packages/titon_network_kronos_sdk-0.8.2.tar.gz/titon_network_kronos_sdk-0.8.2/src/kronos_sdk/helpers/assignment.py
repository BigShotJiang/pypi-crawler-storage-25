"""Off-chain mirror of the on-chain automaton-assignment formula.

The registry stores automatons in a dense map ``automatonAddresses: map<uint32,
address>`` indexed in ``[0, activeAutomatonCount)``; for each Execute, the
assigned slot is::

    index = (jobId + executionCount) % activeAutomatonCount

Canonical sources in ``contracts/kronos-registry.tolk``:

- ``resolveSlashTarget(...)`` — used at execute-time to pick the automaton.
- ``get fun assignedAutomaton(jobId, executionCount)`` — getter exposed for
  off-chain previews.

Off-chain we only need the index; resolving the address requires the live
mirror which an automaton daemon will have already fetched (or can pull via
``KronosRegistry.get_automaton_at(index)``).

For a one-shot end-to-end "who runs this next?" question, prefer the
high-level convenience method :meth:`KronosClient.assigned_automaton_for`
which combines the count, mirror, and index lookup in one call. This module
is for the cache-friendly path where you maintain the mirror locally via
``AutomatonMirrorUpdated`` events.
"""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from pytoniq_core import Address

@dataclass(frozen=True)
class AssignmentInput:
    job_id: int
    execution_count: int
    """Pre-execution count — i.e. ``job.execution_count`` BEFORE the upcoming run."""
    active_automaton_count: int

@dataclass(frozen=True)
class ResolveAssignedInput:
    job_id: int
    execution_count: int
    active_automaton_count: int
    automaton_addresses: Mapping[int, Address] | Sequence[Address]
    """The dense mirror snapshot — index → address."""

def assigned_automaton_index(input: AssignmentInput) -> int | None:  # noqa: A002
    """Compute the assigned-automaton INDEX for the next execution of a job.

    Returns ``None`` if the rotation is disabled (ForgeTON unset or zero active
    automatons) — callers should treat ``None`` as "fully permissionless,
    anyone can Execute".

    Mirrors ``resolveSlashTarget`` in ``contracts/kronos-registry.tolk``.

    Example::

        # jobId=7, after 3 executions, 4 active automatons → slot (7+3) % 4 = 2
        assigned_automaton_index(AssignmentInput(job_id=7, execution_count=3, active_automaton_count=4))
        # → 2
    """
    if input.active_automaton_count <= 0:
        return None
    return int((input.job_id + input.execution_count) % input.active_automaton_count)

def resolve_assigned_automaton(input: ResolveAssignedInput) -> Address | None:  # noqa: A002
    """Resolve the assigned automaton to a concrete address using a mirror snapshot.

    Returns ``None`` if the rotation is disabled or the slot is empty (latter
    shouldn't happen when the mirror is consistent with ``active_automaton_count``).
    """
    idx = assigned_automaton_index(
        AssignmentInput(
            job_id=input.job_id,
            execution_count=input.execution_count,
            active_automaton_count=input.active_automaton_count,
        )
    )
    if idx is None:
        return None
    mirror = input.automaton_addresses
    if isinstance(mirror, Mapping):
        return mirror.get(idx)
    if 0 <= idx < len(mirror):
        return mirror[idx]
    return None
