"""Gas-sizing helpers.

The TS SDK ships an ``estimateJobGas`` that runs the target on a ``@ton/sandbox``
blockchain and returns ``{gasUsed, recommended, success, exitCode}``.

The Python SDK ships **the buffered-multiplier half**: take a measured
``gas_used`` (typically obtained by running the target in a TVM emulator,
trace-getter dry run, or a captured production tx) and add a configurable
safety buffer. We don't ship a sandbox runner because pytoniq's emulator
surface is significantly weaker than ``@ton/sandbox`` and the user-facing
output of "you must pre-measure gas yourself" is more honest than a
half-working in-process estimator.

Under-sizing ``gas_limit`` is the #1 Kronos integration footgun: the automaton
gets paid for sending, the target OOGs, state never advances, and the user
sees "why isn't my job running?". Always layer a buffer on the measurement.
"""

from dataclasses import dataclass

@dataclass(frozen=True)
class EstimateJobGasResult:
    """Result of the buffered-multiplier helper."""

    gas_used: int
    """Caller-supplied measured gas (nano-TON)."""
    recommended: int
    """``gas_used * (100 + buffer_percent) // 100`` — what to pass as ``gas_limit``."""
    buffer_percent: int

def recommended_gas_limit(gas_used: int, *, buffer_percent: int = 20) -> EstimateJobGasResult:
    """Wrap a measured ``gas_used`` with a safety buffer (default 20%).

    Example::

        # Suppose you measured the target's TVM execution at 187,420 nanoTON.
        from kronos_sdk import recommended_gas_limit
        rec = recommended_gas_limit(187_420, buffer_percent=20)
        # rec.recommended → 224,904  (187_420 * 1.2)

        # Then plug into RegisterJob:
        builder = JobBuilder().target(addr).message(body).interval(3600).reward(...)\\
                              .gas_limit(rec.recommended)
    """
    if buffer_percent < 0:
        raise ValueError(f"buffer_percent must be >= 0, got {buffer_percent}")
    if gas_used < 0:
        raise ValueError(f"gas_used must be >= 0, got {gas_used}")
    recommended = (gas_used * (100 + buffer_percent)) // 100
    return EstimateJobGasResult(
        gas_used=gas_used,
        recommended=recommended,
        buffer_percent=buffer_percent,
    )
