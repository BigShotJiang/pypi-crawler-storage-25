"""Execution-window math — mirrors the window asserts inside ``handleExecute``
in ``contracts/kronos-registry.tolk`` and the ``isDue`` getter.

Important semantic note: the on-chain ``isDue`` ALSO checks that the job is
active and has enough balance to cover one execution. This module's :func:`is_due`
only checks WINDOW + EXPIRY — the time-based half. Use :func:`is_executable`
when you need a faithful preview of whether ``Execute`` will succeed.

A job's nextDue timestamp is ``last_executed_at + interval``. Around it we
define three windows:

- ``[next_due - window_before, next_due + primary_window_seconds]`` — primary
  Only the assigned automaton can Execute. Anyone else hits ``E_NOT_ASSIGNED``.
- ``(next_due + primary_window_seconds, next_due + window_after]`` — fallback
  Anyone can Execute. If the executor is NOT the assigned automaton, the
  registry slashes the assigned automaton for missing.
- anything outside ``[next_due - window_before, next_due + window_after]`` — closed
  Reverts ``E_TOO_EARLY`` (before) or ``E_TOO_LATE`` (after).

First execution is special: ``last_executed_at == 0`` means the job has never
been executed, so the rotation is skipped entirely (anyone can run, no slash
possible).
"""

import time
from dataclasses import dataclass
from typing import Literal

WindowStatus = Literal[
    "never-executed",
    "too-early",
    "primary",
    "fallback",
    "too-late",
    "expired",
]

@dataclass(frozen=True)
class JobWindowInput:
    last_executed_at: int
    """Last successful Execute timestamp; 0 if never executed."""
    interval: int
    window_before: int
    window_after: int
    primary_window_seconds: int
    """Registry config — the primary-window length; default 30 s."""
    expire_after: int = 0
    """0 means never expires."""
    now: int | None = None
    """Defaults to current unix time."""

@dataclass(frozen=True)
class JobWindowState:
    status: WindowStatus
    next_due: int
    """``last_executed_at + interval``; 0 if never executed (rotation off)."""
    window_opens_at: int
    """Earliest Execute timestamp (``next_due - window_before``)."""
    primary_ends_at: int
    """Boundary between primary and fallback (``next_due + primary_window_seconds``)."""
    window_closes_at: int
    """Latest Execute timestamp (``next_due + window_after``)."""
    seconds_to_next: int | None
    """Seconds until status changes; None if permanently 'never-executed' or 'expired'."""

@dataclass(frozen=True)
class ExecutableInput:
    last_executed_at: int
    interval: int
    window_before: int
    window_after: int
    primary_window_seconds: int
    balance: int
    """Current job balance (nano-TON)."""
    per_execution_cost: int
    """Per-execution cost — compute via :func:`execution_economics`."""
    is_active: bool
    """Pass ``False`` when the job is paused — Execute reverts with ``E_JOB_NOT_ACTIVE``."""
    expire_after: int = 0
    now: int | None = None

def _now_or(now: int | None) -> int:
    return int(time.time()) if now is None else now

def job_window_state(input: JobWindowInput) -> JobWindowState:  # noqa: A002
    """Full state inspection for UI / dashboards.

    Example::

        job = await client.jobs.get(job_id)
        cfg = await client.jobs.config()
        s = job_window_state(JobWindowInput(
            last_executed_at=job.last_executed_at,
            interval=job.interval,
            window_before=job.window_before,
            window_after=job.window_after,
            primary_window_seconds=cfg.primary_window_seconds,
            expire_after=job.expire_after,
        ))
        # s.status: 'never-executed' | 'too-early' | 'primary' | 'fallback' | 'too-late' | 'expired'
    """
    now = _now_or(input.now)

    if input.expire_after and input.expire_after != 0 and now >= input.expire_after:
        return JobWindowState(
            status="expired",
            next_due=0,
            window_opens_at=0,
            primary_ends_at=0,
            window_closes_at=0,
            seconds_to_next=None,
        )

    if input.last_executed_at == 0:
        return JobWindowState(
            status="never-executed",
            next_due=0,
            window_opens_at=0,
            primary_ends_at=0,
            window_closes_at=0,
            seconds_to_next=None,
        )

    next_due = input.last_executed_at + input.interval
    window_opens_at = next_due - input.window_before
    primary_ends_at = next_due + input.primary_window_seconds
    window_closes_at = next_due + input.window_after

    if now < window_opens_at:
        return JobWindowState(
            status="too-early",
            next_due=next_due,
            window_opens_at=window_opens_at,
            primary_ends_at=primary_ends_at,
            window_closes_at=window_closes_at,
            seconds_to_next=window_opens_at - now,
        )
    if now <= primary_ends_at:
        return JobWindowState(
            status="primary",
            next_due=next_due,
            window_opens_at=window_opens_at,
            primary_ends_at=primary_ends_at,
            window_closes_at=window_closes_at,
            seconds_to_next=primary_ends_at - now,
        )
    if now <= window_closes_at:
        return JobWindowState(
            status="fallback",
            next_due=next_due,
            window_opens_at=window_opens_at,
            primary_ends_at=primary_ends_at,
            window_closes_at=window_closes_at,
            seconds_to_next=window_closes_at - now,
        )
    return JobWindowState(
        status="too-late",
        next_due=next_due,
        window_opens_at=window_opens_at,
        primary_ends_at=primary_ends_at,
        window_closes_at=window_closes_at,
        seconds_to_next=None,
    )

def is_due(input: JobWindowInput) -> bool:  # noqa: A002
    """True iff the job's WINDOW is open right now (primary or fallback, or first run)."""
    s = job_window_state(input)
    return s.status in {"primary", "fallback", "never-executed"}

def is_executable(input: ExecutableInput) -> bool:  # noqa: A002
    """True iff ``Execute`` will succeed right now.

    Faithful to the on-chain ``isDue`` getter — checks active flag, expiry,
    balance, AND window. Use this in automaton daemons before sending an
    Execute message; use the cheaper :func:`is_due` when you only care about
    the time window.
    """
    if not input.is_active:
        return False
    if input.balance < input.per_execution_cost:
        return False
    return is_due(
        JobWindowInput(
            last_executed_at=input.last_executed_at,
            interval=input.interval,
            window_before=input.window_before,
            window_after=input.window_after,
            primary_window_seconds=input.primary_window_seconds,
            expire_after=input.expire_after,
            now=input.now,
        )
    )

def next_execution_at(input: JobWindowInput) -> int | None:  # noqa: A002
    """Earliest unix timestamp at which Execute will be accepted.

    Returns ``None`` if the job has never executed (rotation off — Execute is
    available immediately) or if the job is already expired or past-due.
    """
    s = job_window_state(input)
    if s.status in {"never-executed", "expired", "too-late"}:
        return None
    return s.window_opens_at
