"""Compiled-contract artifact loader."""

from .loader import CompiledArtifact, load_registry_code

__all__ = ["CompiledArtifact", "load_registry_code"]
