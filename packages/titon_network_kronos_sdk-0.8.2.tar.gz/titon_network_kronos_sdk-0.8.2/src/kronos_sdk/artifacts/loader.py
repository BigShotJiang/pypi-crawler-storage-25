"""Compiled-contract artifact loader.

At packaging time, ``scripts/copy_artifacts.py`` copies ``build/*.compiled.json``
into ``src/kronos_sdk/artifacts/``. This loader reads them and returns a
``Cell`` ready for ``KronosRegistry.create_from_config(...)``.

In-repo dev (before the wheel is built) also works — if the artifact is
missing inside the package, we fall back to the repo-root ``build/`` dir.
External consumers never see this fallback because ``build/`` doesn't exist
outside the source tree.
"""

import json
from dataclasses import dataclass
from pathlib import Path

from pytoniq_core import Cell

HERE = Path(__file__).resolve().parent

@dataclass(frozen=True)
class CompiledArtifact:
    """Parsed contents of a Blueprint ``*.compiled.json`` file."""

    hash: str  # cell-hash hex (matches contract code hash on-chain)
    hash_base64: str
    hex: str  # raw BoC hex; what Cell.from_boc(bytes.fromhex(hex))[0] consumes

def _find_artifact(basename: str) -> Path:
    # Prefer the bundled location (works inside an installed wheel).
    bundled = HERE / basename
    if bundled.exists():
        return bundled

    # Fall back to <repo>/build/ for in-tree dev: HERE is .../sdks/python/src/kronos_sdk/artifacts
    in_tree = HERE.parents[4] / "build" / basename
    if in_tree.exists():
        return in_tree

    raise FileNotFoundError(
        f"Kronos compiled artifact not found: {basename}. "
        f"Looked in:\n  {bundled}\n  {in_tree}\n"
        "If you're developing in-repo, run `pnpm build` from the project root first."
    )

def _load_compiled_cell(basename: str) -> Cell:
    path = _find_artifact(basename)
    parsed = json.loads(path.read_text(encoding="utf-8"))
    if not parsed.get("hex"):
        raise ValueError(f"Artifact {basename} missing 'hex' field")
    return Cell.one_from_boc(bytes.fromhex(parsed["hex"]))

def load_registry_code() -> Cell:
    """Load the compiled ``KronosRegistry`` code cell, ready for create_from_config.

    Example::

        from kronos_sdk import KronosRegistry, load_registry_code

        registry = KronosRegistry.create_from_config(
            {"owner": owner_addr, "treasury": treasury_addr},
            load_registry_code(),
        )
    """
    return _load_compiled_cell("KronosRegistry.compiled.json")
