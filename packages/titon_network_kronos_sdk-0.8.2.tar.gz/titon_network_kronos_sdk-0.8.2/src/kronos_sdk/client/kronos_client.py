"""High-level façade over the KronosRegistry contract.

The low-level wrapper (:class:`KronosRegistry`) is perfectly usable on its
own. The façade exists for ergonomics:

1. **Namespaced methods.** ``client.jobs.register(...)`` reads better than
   ``registry.send_register_job(...)``, and groups related operations.

2. **Cross-contract helpers.** ``client.assigned_automaton_for(job_id)``
   queries the registry's mirror in one call without the user manually
   fetching ``active_automaton_count`` first.

3. **Event decoding shortcut.** ``client.events.decode(body)`` is the same
   function as :func:`decode_event`, exposed on the client for
   discoverability.

Pool operations (stake an automaton, slash, inspect per-consumer drift)
live in the sibling forgeton-sdk Python package. Install it alongside this
package and construct a separate ``Forgeton`` handle when you need those
operations.
"""

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

from pytoniq import BaseWallet
from pytoniq_core import Address, Cell

from ..contracts.kronos_registry import JobData, KronosRegistry, RegistryConfigReply
from ..events.decoder import decode_event, decode_events
from ..events.definitions import KronosEvent
from ..helpers.assignment import (
    AssignmentInput,
    ResolveAssignedInput,
    assigned_automaton_index,
    resolve_assigned_automaton,
)
from ..helpers.cost import (
    ExecutionEconomics,
    ExecutionEconomicsInput,
    execution_economics,
)
from ..helpers.windows import JobWindowInput, JobWindowState, job_window_state

JobBalanceStatus = Literal["healthy", "low", "empty"]

@dataclass(frozen=True)
class JobBalanceHealth:
    job_id: int
    balance: int
    """Current job balance (nano-TON)."""
    per_execution_cost: int
    """Per-execution cost derived from the job's config + registry config."""
    runs_remaining: int
    """``balance // per_execution_cost`` — how many more Executes will succeed."""
    is_active: bool
    """Active flag mirrored from the job record."""
    status: JobBalanceStatus
    """``empty`` when balance == 0 or job inert; ``low`` when ``runs_remaining < low_threshold`` (default 10); ``healthy`` otherwise."""

@dataclass
class EnsureFundedOptions:
    min_runs: int = 10
    """Re-fund if ``runs_remaining`` < this."""
    top_up_runs: int = 200
    """On refill, attach funding for this many additional runs."""
    gas_reserve: int | None = None
    """Gas reserve to add on top. Defaults to the registry's ``min_gas_reserve``."""


@dataclass(frozen=True)
class EnsureFundedResult:
    """Outcome of :meth:`JobsFacade.ensure_funded`.

    Mirrors the TS ``{ sent, value, runsBefore }`` return shape, with
    ``sent=False`` when the job was already healthy and no top-up was sent.
    """

    sent: bool
    """``True`` when a FundJob message was dispatched, ``False`` otherwise."""
    value: int
    """Attached value of the FundJob send (nano-TON). ``0`` when ``sent=False``."""
    runs_before: int
    """``runs_remaining`` measured prior to the (possible) top-up."""

class KronosClient:
    """High-level client for the Kronos registry.

    Example::

        from pytoniq import LiteBalancer, WalletV4R2
        from kronos_sdk import KRONOS_TESTNET, KronosClient, KronosRegistry

        client = LiteBalancer.from_testnet_config(trust_level=2)
        await client.start_up()

        registry = KronosRegistry.create_from_address(KRONOS_TESTNET.registry, client=client)
        kronos = KronosClient(registry=registry)

        cfg = await kronos.jobs.config()
        job = await kronos.jobs.get(job_id)
        assigned = await kronos.assigned_automaton_for(job_id)
    """

    def __init__(self, registry: KronosRegistry) -> None:
        if registry.client is None:
            raise ValueError(
                "KronosClient requires a registry with a wired pytoniq client; "
                "construct via KronosRegistry.create_from_address(addr, client=client)."
            )
        self.registry = registry
        self.jobs = JobsFacade(self)
        self.mirror = MirrorFacade(self)
        self.events = EventsFacade()

    async def assigned_automaton_for(self, job_id: int) -> Address | None:
        """Resolve the address assigned to execute the next run of a job.

        Combines :meth:`KronosRegistry.get_active_automaton_count`, the job's
        current ``execution_count``, and a per-index
        :meth:`KronosRegistry.get_automaton_at` lookup.

        Returns ``None`` when no ForgeTON is configured, the active automaton
        count is 0, or the job has never executed (first run is permissionless
        on-chain; rotation engages from run #1 onward).

        For high-frequency callers, prefer caching ``active_automaton_count``
        and the mirror snapshot — the ``AutomatonMirrorUpdated`` event tells
        you when to invalidate. See :meth:`MirrorFacade.snapshot` +
        :meth:`MirrorFacade.assigned_for` for the cache-friendly path.
        """
        job = await self.registry.get_job(job_id)
        if job is None:
            return None
        if job.last_executed_at == 0:
            return None
        active = await self.registry.get_active_automaton_count()
        idx = assigned_automaton_index(
            AssignmentInput(
                job_id=job_id,
                execution_count=job.execution_count,
                active_automaton_count=active,
            )
        )
        if idx is None:
            return None
        return await self.registry.get_automaton_at(idx)

    async def window_for(self, job_id: int, *, now: int | None = None) -> JobWindowState | None:
        """Fetch + interpret a job's window state in one call."""
        job = await self.registry.get_job(job_id)
        if job is None:
            return None
        cfg = await self.registry.get_config()
        return job_window_state(
            JobWindowInput(
                last_executed_at=job.last_executed_at,
                interval=job.interval,
                window_before=job.window_before,
                window_after=job.window_after,
                primary_window_seconds=cfg.primary_window_seconds,
                expire_after=job.expire_after,
                now=now,
            )
        )

# ===== Facades =====

class JobsFacade:
    """Job-level reads + writes."""

    def __init__(self, c: KronosClient) -> None:
        self._c = c

    # --- writes ---

    async def register(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        target: Address,
        message: Cell,
        interval: int,
        reward: int,
        gas_limit: int,
        max_executions: int,
        window_before: int,
        window_after: int,
        expire_after: int,
    ) -> Any:
        """Register a job. Forwards to :meth:`KronosRegistry.send_register_job`."""
        return await self._c.registry.send_register_job(
            wallet,
            value=value,
            target=target,
            message=message,
            interval=interval,
            reward=reward,
            gas_limit=gas_limit,
            max_executions=max_executions,
            window_before=window_before,
            window_after=window_after,
            expire_after=expire_after,
        )

    async def execute(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_execute(wallet, value=value, job_id=job_id)

    async def fund(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_fund_job(wallet, value=value, job_id=job_id)

    async def cancel(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_cancel_job(wallet, value=value, job_id=job_id)

    async def pause(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_pause_job(wallet, value=value, job_id=job_id)

    async def resume(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_resume_job(wallet, value=value, job_id=job_id)

    async def withdraw(
        self, wallet: BaseWallet, *, value: int, job_id: int, amount: int
    ) -> Any:
        return await self._c.registry.send_withdraw_job(
            wallet, value=value, job_id=job_id, amount=amount
        )

    async def update(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        job_id: int,
        reward: int,
        interval: int,
        gas_limit: int,
    ) -> Any:
        return await self._c.registry.send_update_job(
            wallet, value=value, job_id=job_id, reward=reward, interval=interval, gas_limit=gas_limit
        )

    async def update_full(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        job_id: int,
        target: Address,
        message: Cell,
        interval: int,
        reward: int,
        gas_limit: int,
        max_executions: int,
        window_before: int,
        window_after: int,
        expire_after: int,
    ) -> Any:
        """Rewrite every mutable field of a job. Forwards to
        :meth:`KronosRegistry.send_update_job_full`. Owner-gated."""
        return await self._c.registry.send_update_job_full(
            wallet,
            value=value,
            job_id=job_id,
            target=target,
            message=message,
            interval=interval,
            reward=reward,
            gas_limit=gas_limit,
            max_executions=max_executions,
            window_before=window_before,
            window_after=window_after,
            expire_after=expire_after,
        )

    async def cleanup_expired(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_cleanup_expired_job(
            wallet, value=value, job_id=job_id
        )

    async def sweep_dust(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await self._c.registry.send_sweep_dust(wallet, value=value, job_id=job_id)

    async def perform_housekeeping(self, wallet: BaseWallet, *, value: int) -> Any:
        return await self._c.registry.send_perform_housekeeping(wallet, value=value)

    async def ensure_funded(
        self,
        wallet: BaseWallet,
        job_id: int,
        options: EnsureFundedOptions | None = None,
    ) -> EnsureFundedResult:
        """Fund the job only if its health is below ``min_runs``.

        No-op if already healthy — safe to call on a timer.
        """
        opts = options or EnsureFundedOptions()
        health = await self.balance_health(job_id)
        if health.runs_remaining >= opts.min_runs and health.status != "empty":
            return EnsureFundedResult(
                sent=False, value=0, runs_before=health.runs_remaining
            )
        cfg = await self._c.registry.get_config()
        gas_reserve = opts.gas_reserve if opts.gas_reserve is not None else cfg.min_gas_reserve
        top_up = health.per_execution_cost * opts.top_up_runs
        value = top_up + gas_reserve
        await self._c.registry.send_fund_job(wallet, value=value, job_id=job_id)
        return EnsureFundedResult(
            sent=True, value=value, runs_before=health.runs_remaining
        )

    # --- reads ---

    async def get(self, job_id: int) -> JobData | None:
        return await self._c.registry.get_job(job_id)

    async def exists(self, job_id: int) -> bool:
        return (await self._c.registry.get_job(job_id)) is not None

    async def is_due(self, job_id: int) -> bool:
        return await self._c.registry.get_is_due(job_id)

    async def next_due(self, job_id: int) -> int:
        return await self._c.registry.get_next_due(job_id)

    async def balance(self, job_id: int) -> int:
        return await self._c.registry.get_job_balance(job_id)

    async def balance_health(self, job_id: int, low_threshold: int = 10) -> JobBalanceHealth:
        """Health check: is this job about to die?

        Pulls the job + config, computes ``per_execution_cost``, and reports
        ``runs_remaining`` with a ``status`` classification.

        Example::

            h = await client.jobs.balance_health(job_id)
            if h.status == 'low':
                alert_ops(f"job {job_id} has {h.runs_remaining} runs left")
        """
        job = await self._c.registry.get_job(job_id)
        if job is None:
            return JobBalanceHealth(
                job_id=job_id,
                balance=0,
                per_execution_cost=0,
                runs_remaining=0,
                is_active=False,
                status="empty",
            )
        cfg = await self._c.registry.get_config()
        econ = execution_economics(
            ExecutionEconomicsInput(
                reward=job.reward, gas_limit=job.gas_limit, protocol_fee_bps=cfg.protocol_fee_bps
            )
        )
        balance = job.balance
        per_exec = econ.total_cost
        runs_remaining = 0 if per_exec == 0 else balance // per_exec
        status: JobBalanceStatus
        if balance == 0 or not job.is_active:
            status = "empty"
        elif runs_remaining < low_threshold:
            status = "low"
        else:
            status = "healthy"
        return JobBalanceHealth(
            job_id=job_id,
            balance=balance,
            per_execution_cost=per_exec,
            runs_remaining=int(runs_remaining),
            is_active=job.is_active,
            status=status,
        )

    async def economics(self, job_id: int) -> ExecutionEconomics | None:
        """Predict per-execution economics from a fetched job + config."""
        job = await self._c.registry.get_job(job_id)
        if job is None:
            return None
        cfg = await self._c.registry.get_config()
        return execution_economics(
            ExecutionEconomicsInput(
                reward=job.reward, gas_limit=job.gas_limit, protocol_fee_bps=cfg.protocol_fee_bps
            )
        )

    async def count(self) -> int:
        return await self._c.registry.get_job_count()

    async def config(self) -> RegistryConfigReply:
        return await self._c.registry.get_config()

class MirrorFacade:
    """Mirror-side view of the automaton set.

    Reads from the registry's dense automaton mirror (maintained via inbound
    AutomatonSync from ForgeTON). Pool-side writes (stake / unstake / slash)
    live in the sibling forgeton-sdk; construct a separate Forgeton handle
    when you need those.
    """

    def __init__(self, c: KronosClient) -> None:
        self._c = c

    async def active_count(self) -> int:
        return await self._c.registry.get_active_automaton_count()

    async def snapshot(self) -> list[Address]:
        """Snapshot the mirror — addresses indexed ``[0, active_automaton_count)``.

        Costs ``N+1`` getter calls. For long-running daemons, subscribe to
        ``AutomatonMirrorUpdated`` events and maintain the mirror
        incrementally instead of resnapshotting every cycle.
        """
        count = await self._c.registry.get_active_automaton_count()
        out: list[Address] = []
        for i in range(count):
            a = await self._c.registry.get_automaton_at(i)
            if a is not None:
                out.append(a)
        return out

    def assigned_for(
        self, job_id: int, execution_count: int, mirror: Sequence[Address]
    ) -> Address | None:
        """Resolve the assigned automaton using a pre-fetched mirror snapshot.

        Use this in automaton daemons that subscribe to
        ``AutomatonMirrorUpdated`` and keep the mirror locally — it avoids
        per-job round-trips.
        """
        return resolve_assigned_automaton(
            ResolveAssignedInput(
                job_id=job_id,
                execution_count=execution_count,
                active_automaton_count=len(mirror),
                automaton_addresses=mirror,
            )
        )

class EventsFacade:
    """Event-decoding shortcuts."""

    def decode(self, body: Cell) -> KronosEvent | None:
        """Decode a single event body cell. Returns ``None`` for unknown opcodes."""
        return decode_event(body)

    def decode_all(self, bodies: Sequence[Cell]) -> list[KronosEvent]:
        """Filter a batch of body cells through the decoder, dropping unknowns."""
        return decode_events(bodies)
