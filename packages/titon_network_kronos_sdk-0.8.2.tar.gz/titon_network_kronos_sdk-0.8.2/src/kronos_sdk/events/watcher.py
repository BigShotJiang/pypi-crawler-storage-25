"""JobWatcher — long-running subscription for a single job's events.

Polls the registry's transaction stream, filters external-out bodies to
events attributable to ``job_id``, and dispatches typed callbacks. Consumers
wire this into webhook shims, Slack alerts, custom dashboards without
building their own indexer.

Design constraints:

- Pluggable transaction source — so tests can drive the watcher with
  synthetic event streams and prod wires it to a LiteBalancer / indexer.
- Low-balance detection is derived, not a contract event. The watcher
  re-reads job balance on every ``JobExecuted`` and emits ``LowBalance``
  when a user-supplied threshold (in remaining runs) is crossed.
- :meth:`start` returns an awaitable stop coroutine; ``await stop()`` to
  tear down the loop.
- Events are typed via the existing :data:`KronosEvent` union — no
  reinvention of the event model.
"""

import asyncio
import logging
import math
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal, Protocol, Self, Union

from pytoniq_core import Cell

_log = logging.getLogger(__name__)

from .decoder import decode_event
from .definitions import (
    JobCancelledEvent,
    JobDustSweptEvent,
    JobExecutedEvent,
    JobExpiredEvent,
    JobFundedEvent,
    JobPausedEvent,
    JobResumedEvent,
    JobUpdatedEvent,
    JobWithdrawnEvent,
    KronosEvent,
)

if TYPE_CHECKING:
    from ..client import KronosClient

@dataclass(frozen=True)
class LowBalanceEvent:
    """Synthetic event — not on-chain. Emitted by :class:`JobWatcher` when a
    job's remaining-runs estimate dips below the configured threshold."""

    job_id: int
    balance: int
    """Remaining job balance (nano-TON)."""
    runs_remaining: int
    """Runs remaining at current execution_cost."""
    threshold: int
    """Threshold the watcher was configured with."""
    kind: Literal["LowBalance"] = "LowBalance"

JobWatcherEvent = Union[
    JobExecutedEvent,
    JobFundedEvent,
    JobWithdrawnEvent,
    JobExpiredEvent,
    JobCancelledEvent,
    JobPausedEvent,
    JobResumedEvent,
    JobUpdatedEvent,
    JobDustSweptEvent,
    LowBalanceEvent,
]

JobWatcherKind = str  # Literal[...] equivalent of TS JobWatcherEvent['kind']

JobWatcherCallback = Callable[[JobWatcherEvent], Awaitable[None] | None]

class EventSource(Protocol):
    """Pluggable transaction source.

    Implementations MUST return each external-out body cell exactly once
    (monotonic / cursor-based).
    """

    async def poll_bodies(self) -> list[Cell]:
        """Return every external-out body emitted by the registry since the
        last call. Return ``[]`` when nothing new."""
        ...

@dataclass
class JobWatcherOptions:
    source: EventSource
    poll_seconds: float = 5.0
    """Poll cadence in seconds. Default 5."""
    low_balance_threshold: int = 10
    """Emit ``LowBalance`` when ``runs_remaining`` drops below this. 0 disables."""

class JobWatcher:
    """Subscribe to a single job's events.

    Example::

        from kronos_sdk import JobWatcher, KronosClient
        from kronos_sdk.events import EventSource

        class MySource:
            async def poll_bodies(self):
                txs = await client.get_transactions(registry.address, count=20)
                return [
                    msg.body for tx in txs
                    for msg in tx.out_msgs
                    if msg.info.type == 'external-out'
                ]

        watcher = JobWatcher(client, job_id, JobWatcherOptions(source=MySource()))
        watcher.on('JobExecuted', lambda ev: print(f'run {ev.execution_count} by {ev.automaton}'))
        watcher.on('LowBalance', lambda ev: alert_ops(ev.job_id, ev.runs_remaining))

        stop = watcher.start()
        # ... later ...
        await stop()
    """

    def __init__(
        self,
        client: "KronosClient",
        job_id: int,
        options: JobWatcherOptions,
    ) -> None:
        self._client = client
        self._job_id = job_id
        self._opts = options
        self._handlers: dict[str, list[JobWatcherCallback]] = {}
        self._per_execution_cost: int | None = None
        self._running = False
        self._task: asyncio.Task[None] | None = None
        self._last_alert_runs: float = math.inf

    def on(self, kind: JobWatcherKind, cb: JobWatcherCallback) -> Self:
        """Register a callback. Multiple callbacks per kind are allowed."""
        self._handlers.setdefault(kind, []).append(cb)
        return self

    def start(self) -> Callable[[], Awaitable[None]]:
        """Begin polling. Returns an async stop function."""
        if self._running:
            raise RuntimeError("JobWatcher: already running")
        self._running = True
        self._task = asyncio.create_task(self._loop())

        async def stop() -> None:
            self._running = False
            if self._task is not None:
                self._task.cancel()
                try:
                    await self._task
                except asyncio.CancelledError:
                    pass
                self._task = None

        return stop

    async def tick(self) -> None:
        """Manually drive one poll cycle. Exposed so tests can avoid real timers."""
        bodies = await self._opts.source.poll_bodies()
        for body in bodies:
            ev = decode_event(body)
            if ev is None:
                continue
            if not self._matches_this_job(ev):
                continue
            await self._dispatch(ev)

    async def _loop(self) -> None:
        while self._running:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:
                # Surface poll errors via the structured logger so production
                # operators can capture them without subclassing. The logger's
                # name is ``kronos_sdk.events.watcher`` — wire pino-style
                # handlers in the host app to route accordingly.
                _log.exception("JobWatcher poll error")
            try:
                await asyncio.sleep(self._opts.poll_seconds)
            except asyncio.CancelledError:
                raise

    def _matches_this_job(self, ev: KronosEvent) -> bool:
        # Every job-lifecycle event carries a job_id field. Config / automaton /
        # fee events do not — we drop them silently.
        return getattr(ev, "job_id", None) == self._job_id

    async def _dispatch(self, ev: JobWatcherEvent) -> None:
        await self._invoke(ev)
        if isinstance(ev, (JobExecutedEvent, JobFundedEvent, JobWithdrawnEvent)):
            await self._check_low_balance()

    async def _invoke(self, ev: JobWatcherEvent) -> None:
        kind = getattr(ev, "kind", None)
        if not kind:
            return
        for cb in self._handlers.get(kind, []):
            result = cb(ev)
            if asyncio.iscoroutine(result):
                await result

    async def _check_low_balance(self) -> None:
        if self._opts.low_balance_threshold <= 0:
            return
        if self._per_execution_cost is None:
            econ = await self._client.jobs.economics(self._job_id)
            if econ is None:
                return
            self._per_execution_cost = econ.total_cost
        balance = await self._client.jobs.balance(self._job_id)
        if balance == 0:
            self._last_alert_runs = math.inf
            return
        if self._per_execution_cost == 0:
            return
        runs = balance // self._per_execution_cost
        if runs < self._opts.low_balance_threshold and runs < self._last_alert_runs:
            self._last_alert_runs = runs
            await self._invoke(
                LowBalanceEvent(
                    job_id=self._job_id,
                    balance=balance,
                    runs_remaining=int(runs),
                    threshold=self._opts.low_balance_threshold,
                )
            )
        elif runs >= self._opts.low_balance_threshold:
            self._last_alert_runs = math.inf
