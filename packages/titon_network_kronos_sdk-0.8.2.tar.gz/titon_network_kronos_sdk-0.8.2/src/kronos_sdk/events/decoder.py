"""Event decoder — parses the body cell of an external-log message into a typed
:class:`KronosEvent`.

The registry emits events via ``createExternalLogMessage`` with
``dest: addr_none``; the body is ``store_uint(opcode, 32) || fields...``.

Indexers / monitors call :func:`decode_event` on each external-out message
body and switch on ``event.kind``.

Wire layout per ``messages.tolk``: integer fields use the declared bit width,
``coins`` uses store_coins (varuint 16), ``address`` uses store_address,
``bool`` uses store_bit, ``uint256`` (cell hash) uses 256 bits.

ForgeTON (pool) events are decoded by the sibling forgeton-sdk's own
``decode_event``. An indexer watching both contracts typically chains: try
this module's ``decode_event`` first, then fall through to forgeton-sdk's
decoder.
"""

from collections.abc import Iterable
from typing import Callable

from pytoniq_core import Cell, Slice

from ..opcodes import OP
from .definitions import (
    AssignedAutomatonMissedEvent,
    AutomatonMirrorUpdatedEvent,
    CodeUpdatedEvent,
    ConfigUpdatedEvent,
    DecodedEvent,
    FeesWithdrawnEvent,
    ForgetonSetEvent,
    HousekeepingJobSetEvent,
    JobCancelledEvent,
    JobDustSweptEvent,
    JobExecutedEvent,
    JobExpiredEvent,
    JobFundedEvent,
    JobHousekeepingExecutedEvent,
    JobPausedEvent,
    JobRegisteredEvent,
    JobResumedEvent,
    JobUpdatedEvent,
    JobWithdrawnEvent,
    KronosEvent,
    PausedChangedEvent,
    SlashRetriedEvent,
    TreasuryUpdatedEvent,
    UpgradeCancelledEvent,
    UpgradeProposedEvent,
)

def decode_event(body: Cell) -> DecodedEvent:
    """Decode an event body cell.

    Returns ``None`` when the leading 32-bit opcode is not a recognised Kronos
    event — forgeton-sdk's decoder should be tried next for pool events.

    Example::

        ev = decode_event(external_out_body)
        if ev and ev.kind == 'JobExecuted':
            print(f"reward: {ev.reward}, fee: {ev.protocol_fee}")
    """
    s = body.begin_parse()
    if s.remaining_bits < 32:
        return None
    opcode = s.load_uint(32)
    decoder = _DECODERS.get(opcode)
    if decoder is None:
        return None
    return decoder(s, opcode)

def decode_events(bodies: Iterable[Cell]) -> list[KronosEvent]:
    """Convenience: decode many bodies and drop the unrecognised ones."""
    out: list[KronosEvent] = []
    for body in bodies:
        ev = decode_event(body)
        if ev is not None:
            out.append(ev)
    return out

# ===== Per-opcode decoders =====

def _job_registered(s: Slice, opcode: int) -> JobRegisteredEvent:
    return JobRegisteredEvent(
        kind="JobRegistered",
        opcode=opcode,
        job_id=s.load_uint(64),
        owner=s.load_address(),
        target=s.load_address(),
        reward=s.load_coins(),
        interval=s.load_uint(32),
        expire_after=s.load_uint(32),
    )

def _job_executed(s: Slice, opcode: int) -> JobExecutedEvent:
    return JobExecutedEvent(
        kind="JobExecuted",
        opcode=opcode,
        job_id=s.load_uint(64),
        automaton=s.load_address(),
        execution_count=s.load_uint(32),
        reward=s.load_coins(),
        protocol_fee=s.load_coins(),
        executed_at=s.load_uint(32),
    )

def _job_funded(s: Slice, opcode: int) -> JobFundedEvent:
    return JobFundedEvent(
        kind="JobFunded",
        opcode=opcode,
        job_id=s.load_uint(64),
        amount=s.load_coins(),
        new_balance=s.load_coins(),
    )

def _job_cancelled(s: Slice, opcode: int) -> JobCancelledEvent:
    return JobCancelledEvent(
        kind="JobCancelled",
        opcode=opcode,
        job_id=s.load_uint(64),
        refund=s.load_coins(),
    )

def _job_updated(s: Slice, opcode: int) -> JobUpdatedEvent:
    return JobUpdatedEvent(kind="JobUpdated", opcode=opcode, job_id=s.load_uint(64))

def _job_paused(s: Slice, opcode: int) -> JobPausedEvent:
    return JobPausedEvent(kind="JobPaused", opcode=opcode, job_id=s.load_uint(64))

def _job_resumed(s: Slice, opcode: int) -> JobResumedEvent:
    return JobResumedEvent(kind="JobResumed", opcode=opcode, job_id=s.load_uint(64))

def _job_withdrawn(s: Slice, opcode: int) -> JobWithdrawnEvent:
    return JobWithdrawnEvent(
        kind="JobWithdrawn",
        opcode=opcode,
        job_id=s.load_uint(64),
        amount=s.load_coins(),
        remaining_balance=s.load_coins(),
    )

def _job_expired(s: Slice, opcode: int) -> JobExpiredEvent:
    return JobExpiredEvent(
        kind="JobExpired",
        opcode=opcode,
        job_id=s.load_uint(64),
        refund=s.load_coins(),
    )

def _job_dust_swept(s: Slice, opcode: int) -> JobDustSweptEvent:
    return JobDustSweptEvent(
        kind="JobDustSwept",
        opcode=opcode,
        job_id=s.load_uint(64),
        amount=s.load_coins(),
    )

def _job_housekeeping_executed(s: Slice, opcode: int) -> JobHousekeepingExecutedEvent:
    return JobHousekeepingExecutedEvent(
        kind="JobHousekeepingExecuted",
        opcode=opcode,
        batch_start=s.load_uint(64),
        cleaned=s.load_uint(32),
        next_cursor=s.load_uint(64),
    )

def _forgeton_set(s: Slice, opcode: int) -> ForgetonSetEvent:
    return ForgetonSetEvent(kind="ForgetonSet", opcode=opcode, forgeton=s.load_address())

def _automaton_mirror_updated(s: Slice, opcode: int) -> AutomatonMirrorUpdatedEvent:
    return AutomatonMirrorUpdatedEvent(
        kind="AutomatonMirrorUpdated",
        opcode=opcode,
        automaton=s.load_address(),
        is_active=s.load_bool(),
        active_automaton_count=s.load_uint(32),
    )

def _assigned_automaton_missed(s: Slice, opcode: int) -> AssignedAutomatonMissedEvent:
    return AssignedAutomatonMissedEvent(
        kind="AssignedAutomatonMissed",
        opcode=opcode,
        job_id=s.load_uint(64),
        assigned=s.load_address(),
        executor=s.load_address(),
    )

def _config_updated(s: Slice, opcode: int) -> ConfigUpdatedEvent:
    return ConfigUpdatedEvent(
        kind="ConfigUpdated",
        opcode=opcode,
        min_reward=s.load_coins(),
        min_funding=s.load_coins(),
        min_interval=s.load_uint(32),
        max_interval=s.load_uint(32),
        protocol_fee_bps=s.load_uint(16),
        min_storage_reserve=s.load_coins(),
        min_gas_reserve=s.load_coins(),
        primary_window_seconds=s.load_uint(32),
        slash_gas_cost=s.load_coins(),
    )

def _treasury_updated(s: Slice, opcode: int) -> TreasuryUpdatedEvent:
    return TreasuryUpdatedEvent(kind="TreasuryUpdated", opcode=opcode, treasury=s.load_address())

def _housekeeping_job_set(s: Slice, opcode: int) -> HousekeepingJobSetEvent:
    return HousekeepingJobSetEvent(
        kind="HousekeepingJobSet", opcode=opcode, job_id=s.load_uint(64)
    )

def _fees_withdrawn(s: Slice, opcode: int) -> FeesWithdrawnEvent:
    return FeesWithdrawnEvent(
        kind="FeesWithdrawn",
        opcode=opcode,
        amount=s.load_coins(),
        remaining_accumulated=s.load_coins(),
    )

def _upgrade_proposed(s: Slice, opcode: int) -> UpgradeProposedEvent:
    return UpgradeProposedEvent(
        kind="UpgradeProposed",
        opcode=opcode,
        code_hash=s.load_uint(256),
        eta=s.load_uint(32),
    )

def _upgrade_cancelled(s: Slice, opcode: int) -> UpgradeCancelledEvent:
    return UpgradeCancelledEvent(
        kind="UpgradeCancelled", opcode=opcode, code_hash=s.load_uint(256)
    )

def _slash_retried(s: Slice, opcode: int) -> SlashRetriedEvent:
    return SlashRetriedEvent(
        kind="SlashRetried",
        opcode=opcode,
        automaton=s.load_address(),
        job_id=s.load_uint(64),
    )

def _paused_changed(s: Slice, opcode: int) -> PausedChangedEvent:
    return PausedChangedEvent(kind="PausedChanged", opcode=opcode, paused=s.load_bool())

def _code_updated(s: Slice, opcode: int) -> CodeUpdatedEvent:
    return CodeUpdatedEvent(
        kind="CodeUpdated",
        opcode=opcode,
        code_hash=s.load_uint(256),
        old_code_hash=s.load_uint(256),
        timestamp=s.load_uint(32),
    )

_DECODERS: dict[int, Callable[[Slice, int], KronosEvent]] = {
    OP["JobRegistered"]: _job_registered,
    OP["JobExecuted"]: _job_executed,
    OP["JobFunded"]: _job_funded,
    OP["JobCancelled"]: _job_cancelled,
    OP["JobUpdated"]: _job_updated,
    OP["JobPaused"]: _job_paused,
    OP["JobResumed"]: _job_resumed,
    OP["JobWithdrawn"]: _job_withdrawn,
    OP["JobExpired"]: _job_expired,
    OP["JobDustSwept"]: _job_dust_swept,
    OP["JobHousekeepingExecuted"]: _job_housekeeping_executed,
    OP["ForgetonSet"]: _forgeton_set,
    OP["AutomatonMirrorUpdated"]: _automaton_mirror_updated,
    OP["AssignedAutomatonMissed"]: _assigned_automaton_missed,
    OP["ConfigUpdated"]: _config_updated,
    OP["TreasuryUpdated"]: _treasury_updated,
    OP["HousekeepingJobSet"]: _housekeeping_job_set,
    OP["FeesWithdrawn"]: _fees_withdrawn,
    OP["UpgradeProposed"]: _upgrade_proposed,
    OP["UpgradeCancelled"]: _upgrade_cancelled,
    OP["SlashRetried"]: _slash_retried,
    OP["PausedChanged"]: _paused_changed,
    # Shared admin event
    OP["CodeUpdated"]: _code_updated,
}
