"""Typed event definitions — one dataclass per registry event struct in
``contracts/messages.tolk``.

The ``kind`` attribute is a string discriminant so users can switch on it
without remembering opcodes; ``opcode`` is preserved for indexers that key
off the raw uint.

Field names + widths mirror the Tolk struct exactly. Widths are documented
inline so a future maintainer can audit against ``messages.tolk`` without
loading the SDK source.

ForgeTON (pool) events live in the sibling forgeton-sdk — use its own
``decode_event`` / ``ForgetonEvent`` union for pool-side external bodies.
"""

from dataclasses import dataclass
from typing import Literal, Union

from pytoniq_core import Address

# String literal type for cheap discrimination at the use-site.
EventKind = Literal[
    "JobRegistered",
    "JobExecuted",
    "JobFunded",
    "JobCancelled",
    "JobUpdated",
    "JobPaused",
    "JobResumed",
    "JobWithdrawn",
    "JobExpired",
    "JobDustSwept",
    "JobHousekeepingExecuted",
    "ForgetonSet",
    "AutomatonMirrorUpdated",
    "AssignedAutomatonMissed",
    "ConfigUpdated",
    "TreasuryUpdated",
    "HousekeepingJobSet",
    "FeesWithdrawn",
    "UpgradeProposed",
    "UpgradeCancelled",
    "SlashRetried",
    "PausedChanged",
    "CodeUpdated",
]

@dataclass(frozen=True)
class BaseEvent:
    kind: EventKind
    opcode: int
    """32-bit opcode prefix."""

# ===== Registry events (0xA8 - 0xBF) =====

@dataclass(frozen=True)
class JobRegisteredEvent(BaseEvent):
    job_id: int  # uint64
    owner: Address
    target: Address
    reward: int  # coins
    interval: int  # uint32 (seconds)
    expire_after: int  # uint32 (unix; 0 = never)

@dataclass(frozen=True)
class JobExecutedEvent(BaseEvent):
    job_id: int
    automaton: Address
    execution_count: int  # uint32 (post-execution count)
    reward: int
    protocol_fee: int
    executed_at: int  # uint32 (unix)

@dataclass(frozen=True)
class JobFundedEvent(BaseEvent):
    job_id: int
    amount: int
    new_balance: int

@dataclass(frozen=True)
class JobCancelledEvent(BaseEvent):
    job_id: int
    refund: int

@dataclass(frozen=True)
class JobUpdatedEvent(BaseEvent):
    job_id: int

@dataclass(frozen=True)
class JobPausedEvent(BaseEvent):
    job_id: int

@dataclass(frozen=True)
class JobResumedEvent(BaseEvent):
    job_id: int

@dataclass(frozen=True)
class JobWithdrawnEvent(BaseEvent):
    job_id: int
    amount: int
    remaining_balance: int

@dataclass(frozen=True)
class JobExpiredEvent(BaseEvent):
    job_id: int
    refund: int

@dataclass(frozen=True)
class JobDustSweptEvent(BaseEvent):
    job_id: int
    amount: int

@dataclass(frozen=True)
class JobHousekeepingExecutedEvent(BaseEvent):
    batch_start: int  # uint64
    cleaned: int  # uint32
    next_cursor: int  # uint64

@dataclass(frozen=True)
class ForgetonSetEvent(BaseEvent):
    forgeton: Address

@dataclass(frozen=True)
class AutomatonMirrorUpdatedEvent(BaseEvent):
    automaton: Address
    is_active: bool
    active_automaton_count: int  # uint32

@dataclass(frozen=True)
class AssignedAutomatonMissedEvent(BaseEvent):
    job_id: int
    assigned: Address
    executor: Address

@dataclass(frozen=True)
class ConfigUpdatedEvent(BaseEvent):
    min_reward: int
    min_funding: int
    min_interval: int
    max_interval: int
    protocol_fee_bps: int
    min_storage_reserve: int
    min_gas_reserve: int
    primary_window_seconds: int
    slash_gas_cost: int

@dataclass(frozen=True)
class TreasuryUpdatedEvent(BaseEvent):
    treasury: Address

@dataclass(frozen=True)
class HousekeepingJobSetEvent(BaseEvent):
    job_id: int

@dataclass(frozen=True)
class FeesWithdrawnEvent(BaseEvent):
    amount: int
    remaining_accumulated: int

@dataclass(frozen=True)
class UpgradeProposedEvent(BaseEvent):
    code_hash: int  # uint256 (raw cell hash)
    eta: int  # uint32

@dataclass(frozen=True)
class UpgradeCancelledEvent(BaseEvent):
    code_hash: int

@dataclass(frozen=True)
class SlashRetriedEvent(BaseEvent):
    automaton: Address
    job_id: int

@dataclass(frozen=True)
class PausedChangedEvent(BaseEvent):
    paused: bool

# ===== Shared admin event (0xA7) =====

@dataclass(frozen=True)
class CodeUpdatedEvent(BaseEvent):
    code_hash: int  # uint256
    old_code_hash: int
    timestamp: int

# ===== Discriminated union =====

KronosEvent = Union[
    JobRegisteredEvent,
    JobExecutedEvent,
    JobFundedEvent,
    JobCancelledEvent,
    JobUpdatedEvent,
    JobPausedEvent,
    JobResumedEvent,
    JobWithdrawnEvent,
    JobExpiredEvent,
    JobDustSweptEvent,
    JobHousekeepingExecutedEvent,
    ForgetonSetEvent,
    AutomatonMirrorUpdatedEvent,
    AssignedAutomatonMissedEvent,
    ConfigUpdatedEvent,
    TreasuryUpdatedEvent,
    HousekeepingJobSetEvent,
    FeesWithdrawnEvent,
    UpgradeProposedEvent,
    UpgradeCancelledEvent,
    SlashRetriedEvent,
    PausedChangedEvent,
    CodeUpdatedEvent,
]

# Alias used in user-facing APIs / docs.
DecodedEvent = KronosEvent | None
