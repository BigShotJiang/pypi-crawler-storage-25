"""Human-readable explanations for every Kronos exit code.

Tolk asserts throw an integer exit code; the contracts use the constants from
``contracts/errors.tolk`` (re-exported as ``ERR`` in ``opcodes.py``). When an
integration sees ``exit_code == 132`` they want to know what that means without
grepping the contract source — that's what :func:`explain_error` does.

TVM also defines its own exit codes (2 stack underflow, 9 cell underflow,
13 out of gas, 32-37 actions phase failures, ...). We surface the common
ones too so users don't go hunting through TVM docs.

Pool (ForgeTON) error codes (160-199) are NOT in this table — install the
matching ``forgeton-sdk`` and use its ``explain_error`` for those. Codes in
that range returned from this :func:`explain_error` surface as
``origin == "forgeton"`` with a pointer to the pool SDK.
"""

from dataclasses import dataclass
from typing import Literal

from .opcodes import ERR

# ===== Public types =====

ErrorCode = int
ErrorOrigin = Literal["kronos", "forgeton", "tvm", "unknown"]

@dataclass(frozen=True)
class ErrorExplanation:
    """Structured description of an on-chain exit code."""

    code: ErrorCode
    origin: ErrorOrigin
    name: str
    """Symbolic name (e.g. 'NotJobOwner', 'InsufficientGas')."""
    message: str
    """One-line description suitable for surfacing in UI/logs."""
    hint: str | None = None
    """Optional remediation when the error has an obvious fix."""
    related_skill: str | None = None
    """Optional pointer to a Claude Code skill (e.g. '/kronos-register-job')."""

class KronosError(Exception):
    """Exception raised when SDK code wants to surface a structured exit code.

    The message is the formatted explanation; the structured form is on
    ``self.explanation`` so callers can dispatch on origin/name programmatically.
    """

    explanation: ErrorExplanation

    def __init__(self, explanation: ErrorExplanation) -> None:
        super().__init__(format_error_explanation(explanation))
        self.explanation = explanation

    @property
    def code(self) -> int:
        return self.explanation.code

    @property
    def origin(self) -> ErrorOrigin:
        return self.explanation.origin

# ===== Skill pointers =====

_SKILL_OWNER_OPS = "/kronos-owner-ops"
_SKILL_REGISTER = "/kronos-register-job"
_SKILL_LIFECYCLE = "/kronos-job-lifecycle"
_SKILL_DEPLOY = "/kronos-deploy"
_SKILL_AUTOMATON = "/kronos-automaton-setup"
_SKILL_GAS = "/kronos-gas-sizing"
_SKILL_RECEIVER = "/kronos-target-receiver"

# ===== Kronos error table =====
#
# Mirrors contracts/errors.tolk 1:1. Adding a new error code there requires
# adding a row here too — there's no automatic codegen for the prose because
# the prose is the value-add.

_KRONOS_MESSAGES: dict[int, tuple[str, str, str | None]] = {
    # Tuples are (name, message, hint or None) — relatedSkill comes from the map below.
    # ===== Shared / admin =====
    ERR["NotOwner"]: (
        "NotOwner",
        "Caller is not the contract owner.",
        "Send the message from the address recorded in storage.owner.",
    ),
    ERR["Paused"]: (
        "Paused",
        "Contract is paused — only owner-only / withdraw paths are accepted.",
        "Wait for the owner to call Unpause, or use the pause-skip operations (cancel/withdraw/cleanup).",
    ),
    ERR["InsufficientGas"]: (
        "InsufficientGas",
        "Attached value is below the contract minimum gas reserve.",
        "Send at least minGasReserve TON (0.05 TON by default) with the message.",
    ),
    ERR["ZeroAddress"]: (
        "ZeroAddress",
        "A required address argument was the zero address.",
        None,
    ),
    ERR["WouldBreachReserve"]: (
        "WouldBreachReserve",
        "Outgoing payment would push the contract balance below its storage reserve.",
        "Top up the contract or reduce the requested amount.",
    ),
    ERR["InvalidConfig"]: (
        "InvalidConfig",
        "UpdateConfig payload fails coherence checks (reserve/gas/slash-gas out of range).",
        "Diff the submission against the last ConfigUpdated event; re-send with all fields >0 and minStorageReserve >= MIN_RESERVE_FLOOR (0.05 TON).",
    ),
    ERR["ZeroAmount"]: (
        "ZeroAmount",
        "Withdrawal/funding amount must be > 0.",
        None,
    ),
    ERR["EmptyCodeCell"]: (
        "EmptyCodeCell",
        "Proposed upgrade code cell is empty.",
        "Pass a non-empty Cell built from the new contract bytecode.",
    ),
    ERR["FeeBpsOutOfRange"]: (
        "FeeBpsOutOfRange",
        "protocolFeeBps must be within [0, 10000].",
        None,
    ),
    ERR["NoPendingUpgrade"]: (
        "NoPendingUpgrade",
        "ExecuteCodeUpgrade / CancelCodeUpgrade with no proposal pending.",
        "Call ProposeCodeUpgrade first, wait the timelock, then execute.",
    ),
    ERR["UpgradeNotReady"]: (
        "UpgradeNotReady",
        "Pending upgrade ETA has not elapsed yet.",
        "Wait until block time >= the proposal eta (24 h minimum delay).",
    ),
    ERR["UpgradeEtaTooSoon"]: (
        "UpgradeEtaTooSoon",
        "Proposed upgrade eta is sooner than the minimum delay.",
        "Set eta >= now + 24 hours.",
    ),
    ERR["UpgradeAlreadyPending"]: (
        "UpgradeAlreadyPending",
        "A code upgrade is already pending — cancel it first.",
        None,
    ),
    ERR["BadSchemaVersion"]: (
        "BadSchemaVersion",
        "Storage schemaVersion does not match what this code expects.",
        "Likely a stale or wrong-version BoC. After a contract upgrade with storage shape changes, the new code rejects pre-migration storage that was not lazily migrated. Inspect the storageVersion() getter and confirm the code matches.",
    ),
    # ===== Registry: job lifecycle =====
    ERR["InsufficientFunding"]: (
        "InsufficientFunding",
        "RegisterJob/FundJob value is below minFunding (after gas reserve).",
        "Send value >= minFunding + minGasReserve.",
    ),
    ERR["IntervalBelowMin"]: (
        "IntervalBelowMin",
        "Job interval is below the configured minimum.",
        None,
    ),
    ERR["IntervalAboveMax"]: (
        "IntervalAboveMax",
        "Job interval is above the configured maximum.",
        None,
    ),
    ERR["RewardBelowMin"]: (
        "RewardBelowMin",
        "Job reward is below the configured minimum.",
        None,
    ),
    ERR["GasLimitNonpos"]: (
        "GasLimitNonpos",
        "Job gasLimit must be > 0.",
        None,
    ),
    ERR["ExpiryInPast"]: (
        "ExpiryInPast",
        "Job expireAfter is in the past.",
        None,
    ),
    ERR["JobNotFound"]: (
        "JobNotFound",
        "Referenced jobId does not exist.",
        None,
    ),
    ERR["JobPaused"]: (
        "JobPaused",
        "Operation requires an active job, but it was paused by the owner.",
        "Call ResumeJob from the job owner, or use a pause-skip receiver (cancel/withdraw).",
    ),
    ERR["JobAlreadyPaused"]: (
        "JobAlreadyPaused",
        "PauseJob called on an already-paused job.",
        None,
    ),
    ERR["JobAlreadyActive"]: (
        "JobAlreadyActive",
        "ResumeJob called on an already-active job.",
        None,
    ),
    ERR["JobExpired"]: (
        "JobExpired",
        "Job has reached its expireAfter timestamp.",
        "Call CleanupExpiredJob to refund the owner and free the slot.",
    ),
    ERR["InsufficientJobBalance"]: (
        "InsufficientJobBalance",
        "Job balance cannot cover one full execution (reward + gas + fee).",
        "Call FundJob to top it up.",
    ),
    ERR["NotJobOwner"]: (
        "NotJobOwner",
        "Operation requires the job owner.",
        None,
    ),
    ERR["AmountExceedsBalance"]: (
        "AmountExceedsBalance",
        "Withdraw/withdraw-fees amount exceeds the available balance.",
        None,
    ),
    ERR["BelowMinForActive"]: (
        "BelowMinForActive",
        "Partial withdrawal would leave the job below one execution cost.",
        "Either reduce the amount or pause/cancel the job to fully drain.",
    ),
    ERR["TooEarly"]: (
        "TooEarly",
        "Execute called before the job is due (now < nextDue - windowBefore).",
        None,
    ),
    ERR["TooLate"]: (
        "TooLate",
        "Execute called past the fallback window (now > nextDue + windowAfter).",
        None,
    ),
    ERR["NotAssigned"]: (
        "NotAssigned",
        "Caller is not the assigned automaton for this primary execution window.",
        "Either wait for the fallback window, or check assigned_automaton(job_id, execution_count).",
    ),
    ERR["HousekeepingProtected"]: (
        "HousekeepingProtected",
        "Direct cleanup/sweep targeted the pinned housekeeping job.",
        None,
    ),
    ERR["NoExpiry"]: (
        "NoExpiry",
        "CleanupExpiredJob called on a job with no expireAfter set.",
        None,
    ),
    ERR["NotYetExpired"]: (
        "NotYetExpired",
        "CleanupExpiredJob called before the job expired.",
        None,
    ),
    ERR["NothingToSweep"]: (
        "NothingToSweep",
        "SweepDust called on a job with zero balance.",
        None,
    ),
    ERR["BalanceAboveDust"]: (
        "BalanceAboveDust",
        "SweepDust called on a job whose balance still covers an execution.",
        None,
    ),
    ERR["MaxExecBelowCount"]: (
        "MaxExecBelowCount",
        "UpdateJobFull would lower maxExecutions below the current executionCount.",
        None,
    ),
    ERR["ForgetonNotSet"]: (
        "ForgetonNotSet",
        "Operation requires a configured ForgeTON — call SetForgeton first.",
        None,
    ),
    ERR["NotForgeton"]: (
        "NotForgeton",
        "AutomatonSync sender mismatch — only the configured ForgeTON may push syncs.",
        None,
    ),
    ERR["AmountExceedsAccumulated"]: (
        "AmountExceedsAccumulated",
        "WithdrawFees amount exceeds accumulatedFees.",
        None,
    ),
    ERR["WindowBeforeExceedsInterval"]: (
        "WindowBeforeExceedsInterval",
        "Job windowBefore cannot exceed interval — would underflow the due-time math.",
        "Pick windowBefore <= interval in the RegisterJob / UpdateJob / UpdateJobFull payload.",
    ),
    ERR["ForgetonAlreadySet"]: (
        "ForgetonAlreadySet",
        "SetForgeton is one-shot — the pool address is already pinned.",
        "Re-pointing requires a timelocked code upgrade; see DEPLOY.md §\"Code upgrade\".",
    ),
    ERR["AutomatonLeftMirror"]: (
        "AutomatonLeftMirror",
        "RetrySlash target is not in the registry mirror (already unstaked).",
        "Drift on that automaton is unclosable by replay — pool would reject E_NOT_REGISTERED. Accept the gap; the AssignedAutomatonMissed event indexed by Argus is the audit trail.",
    ),
    ERR["JobExhausted"]: (
        "JobExhausted",
        "Job reached maxExecutions and terminally deactivated.",
        "The job is done; cancel for refund or leave for housekeeping to clean up.",
    ),
    ERR["JobSwept"]: (
        "JobSwept",
        "Job was dust-swept — balance went to treasury and the entry is inert.",
        "Cancel to release the storage slot. RegisterJob anew if needed.",
    ),
    ERR["SlashGasCostTooLow"]: (
        "SlashGasCostTooLow",
        "UpdateConfig rejected: slashGasCost must be >= 0.01 TON (= ForgeTON's MIN_XC_GAS floor on handleSlash).",
        "Kronos's outbound Slash uses SEND_MODE_PAY_FEES_SEPARATELY so ForgeTON receives EXACTLY slashGasCost. Setting it below 0.01 would silently drop every slash at ForgeTON's compute phase (NoBounce + IGNORE_ERRORS swallows the failure on Kronos's side).",
    ),
    ERR["SlashGasCostTooHigh"]: (
        "SlashGasCostTooHigh",
        "UpdateConfig rejected: slashGasCost must be <= 1 TON.",
        "Anti-deplete cap: each Slash send drains slashGasCost from registry balance. Above 1 TON per slash is operationally absurd.",
    ),
    # ===== Address validation =====
    ERR["WrongWorkchain"]: (
        "WrongWorkchain",
        "Protocol-internal address is not on workchain 0.",
        "Forgeton and treasury must reside on workchain 0 (the registry's workchain). Re-supply with a wc=0 address. User-supplied job targets are NOT workchain-gated — pick whatever wc you need there.",
    ),
}

_TVM_MESSAGES: dict[int, tuple[str, str, str | None]] = {
    2: ("StackUnderflow", "TVM stack underflow (likely malformed message body).", None),
    3: ("StackOverflow", "TVM stack overflow.", None),
    4: ("IntegerOverflow", "Integer overflow during arithmetic.", None),
    5: ("IntegerOutOfRange", "Integer out of declared range.", None),
    7: ("TypeCheckError", "TVM type check failed.", None),
    8: ("CellOverflow", "Cell overflow — too many bits/refs.", None),
    9: ("CellUnderflow", "Cell underflow — slice ran out of data while parsing.", None),
    13: ("OutOfGas", "Out of gas during TVM execution.", "Increase the value attached to the message."),
    32: ("ActionListInvalid", "Action phase: invalid action list cell.", None),
    33: ("ActionListTooLong", "Action phase: action list too long.", None),
    34: ("ActionInvalid", "Action phase: invalid action format.", None),
    35: ("InvalidSrcAddress", "Action phase: invalid src address.", None),
    36: ("InvalidDstAddress", "Action phase: invalid dst address (likely workchain mismatch).", None),
    37: (
        "NotEnoughTon",
        "Action phase: not enough TON for an outgoing message.",
        "The contract tried to send more value than its balance allows — top it up.",
    ),
    38: ("NotEnoughExtra", "Action phase: not enough extra currency.", None),
    40: ("NotEnoughForOp", "Action phase: not enough TON to forward the action.", None),
    50: ("AccountSizeExceeded", "Account state size exceeded.", None),
    0xFFFF: (
        "UnknownOpcode",
        "Dispatcher rejected an unknown opcode.",
        "Make sure you're sending to the right contract and that the opcode is in your wrapper's OP table.",
    ),
}

_SKILL_MAP_KRONOS: dict[int, str] = {
    ERR["NotOwner"]: _SKILL_OWNER_OPS,
    ERR["Paused"]: _SKILL_OWNER_OPS,
    ERR["InvalidConfig"]: _SKILL_OWNER_OPS,
    ERR["EmptyCodeCell"]: _SKILL_OWNER_OPS,
    ERR["FeeBpsOutOfRange"]: _SKILL_OWNER_OPS,
    ERR["NoPendingUpgrade"]: _SKILL_OWNER_OPS,
    ERR["UpgradeNotReady"]: _SKILL_OWNER_OPS,
    ERR["UpgradeEtaTooSoon"]: _SKILL_OWNER_OPS,
    ERR["UpgradeAlreadyPending"]: _SKILL_OWNER_OPS,
    ERR["BadSchemaVersion"]: _SKILL_OWNER_OPS,
    ERR["AmountExceedsAccumulated"]: _SKILL_OWNER_OPS,
    ERR["ForgetonAlreadySet"]: _SKILL_OWNER_OPS,
    ERR["AutomatonLeftMirror"]: _SKILL_OWNER_OPS,
    ERR["InsufficientFunding"]: _SKILL_REGISTER,
    ERR["IntervalBelowMin"]: _SKILL_REGISTER,
    ERR["IntervalAboveMax"]: _SKILL_REGISTER,
    ERR["RewardBelowMin"]: _SKILL_REGISTER,
    ERR["GasLimitNonpos"]: _SKILL_REGISTER,
    ERR["ExpiryInPast"]: _SKILL_REGISTER,
    ERR["WindowBeforeExceedsInterval"]: _SKILL_REGISTER,
    ERR["JobNotFound"]: _SKILL_LIFECYCLE,
    ERR["JobPaused"]: _SKILL_LIFECYCLE,
    ERR["JobAlreadyPaused"]: _SKILL_LIFECYCLE,
    ERR["JobAlreadyActive"]: _SKILL_LIFECYCLE,
    ERR["JobExpired"]: _SKILL_LIFECYCLE,
    ERR["InsufficientJobBalance"]: _SKILL_LIFECYCLE,
    ERR["NotJobOwner"]: _SKILL_LIFECYCLE,
    ERR["AmountExceedsBalance"]: _SKILL_LIFECYCLE,
    ERR["BelowMinForActive"]: _SKILL_LIFECYCLE,
    ERR["MaxExecBelowCount"]: _SKILL_LIFECYCLE,
    ERR["JobExhausted"]: _SKILL_LIFECYCLE,
    ERR["JobSwept"]: _SKILL_LIFECYCLE,
    ERR["HousekeepingProtected"]: _SKILL_LIFECYCLE,
    ERR["NoExpiry"]: _SKILL_LIFECYCLE,
    ERR["NotYetExpired"]: _SKILL_LIFECYCLE,
    ERR["NothingToSweep"]: _SKILL_LIFECYCLE,
    ERR["BalanceAboveDust"]: _SKILL_LIFECYCLE,
    ERR["TooEarly"]: _SKILL_AUTOMATON,
    ERR["TooLate"]: _SKILL_AUTOMATON,
    ERR["NotAssigned"]: _SKILL_AUTOMATON,
    ERR["ForgetonNotSet"]: _SKILL_DEPLOY,
    ERR["NotForgeton"]: _SKILL_DEPLOY,
    ERR["WrongWorkchain"]: _SKILL_DEPLOY,
}

_SKILL_MAP_TVM: dict[int, str] = {
    13: _SKILL_GAS,  # OutOfGas
    36: _SKILL_RECEIVER,  # InvalidDstAddress
    37: _SKILL_RECEIVER,  # NotEnoughTon
    0xFFFF: _SKILL_RECEIVER,  # UnknownOpcode
}

def explain_error(code: ErrorCode) -> ErrorExplanation:
    """Return a structured explanation for an exit code.

    - Kronos codes (100+, non-160-199) are looked up in the contract error table.
    - Pool codes (160-199) return ``origin == "forgeton"`` — install the matching
      forgeton SDK and call its ``explain_error`` for the human-readable message.
    - TVM codes (2-40 + 0xFFFF) get generic descriptions.
    - Anything else returns ``origin == "unknown"``.

    Every result includes ``related_skill`` when a Claude Code skill covers the fix.

    Example::

        e = explain_error(132)
        # → ErrorExplanation(code=132, origin='kronos', name='NotJobOwner',
        #                    message='Operation requires the job owner.',
        #                    related_skill='/kronos-job-lifecycle')
    """
    kronos = _KRONOS_MESSAGES.get(code)
    if kronos is not None:
        name, message, hint = kronos
        return ErrorExplanation(
            code=code,
            origin="kronos",
            name=name,
            message=message,
            hint=hint,
            related_skill=_SKILL_MAP_KRONOS.get(code),
        )
    if 160 <= code <= 199:
        return ErrorExplanation(
            code=code,
            origin="forgeton",
            name="ForgetonRange",
            message=f"Exit code {code} is a pool-side error.",
            hint="Install the forgeton-sdk and call its explain_error(code) for the message.",
        )
    tvm = _TVM_MESSAGES.get(code)
    if tvm is not None:
        name, message, hint = tvm
        return ErrorExplanation(
            code=code,
            origin="tvm",
            name=name,
            message=message,
            hint=hint,
            related_skill=_SKILL_MAP_TVM.get(code),
        )
    return ErrorExplanation(
        code=code,
        origin="unknown",
        name="Unknown",
        message=f"Exit code {code} is not in the Kronos or TVM tables.",
    )

def format_error_explanation(e: ErrorExplanation) -> str:
    """One-line representation for logs and exception messages.

    Example::

        raise KronosError(explain_error(tx.exit_code))
        # message: "[NotJobOwner] (132) Operation requires the job owner.  See /kronos-job-lifecycle"
    """
    parts: list[str] = [f"[{e.name}] ({e.code}) {e.message}"]
    if e.hint:
        parts.append(f"→ {e.hint}")
    if e.related_skill:
        parts.append(f"See {e.related_skill}")
    return "  ".join(parts)
