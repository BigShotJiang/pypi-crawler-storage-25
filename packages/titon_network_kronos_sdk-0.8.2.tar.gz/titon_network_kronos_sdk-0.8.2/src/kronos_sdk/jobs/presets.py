"""Named window-shape presets for common recurrence profiles.

``window_before`` / ``window_after`` / ``primary_window_seconds`` are three
dials most new users don't know how to set. These presets collapse the choice
to:

- "tight"   — short interval, strict window (e.g. every minute)
- "default" — balanced (e.g. every hour) — same as ``DEFAULT_JOB_OPTS``
- "loose"   — long interval, generous window (e.g. daily, weekly)

``primary_window_seconds`` is a REGISTRY config (not per-job), so these only
cover the per-job dials. Spread into ``register_job_opts``::

    opts = register_job_opts(
        JobOptsInput(target=..., message=..., interval=60, reward=..., gas_limit=...,
                     **JOB_PRESETS["tight"]),
        cfg,
    )
"""

from typing import Final, Literal, TypedDict

class JobWindowPreset(TypedDict):
    window_before: int
    window_after: int

JobPresetName = Literal["tight", "default", "loose"]

JOB_PRESETS: Final[dict[JobPresetName, JobWindowPreset]] = {
    # For jobs with sub-minute-to-5-minute intervals. Tight windows — the
    # assigned automaton has a narrow primary slot; late/early arrivals
    # quickly fall into the fallback zone so someone else picks up.
    "tight": {"window_before": 5, "window_after": 60},
    # Balanced defaults — same as DEFAULT_JOB_OPTS. Good for hourly-to-daily
    # cadence. 30 s pre-fire tolerance, 10 min fallback.
    "default": {"window_before": 30, "window_after": 600},
    # For daily / weekly jobs where exact timing matters less. Wide windows
    # tolerate validator downtime and network congestion without slashing.
    "loose": {"window_before": 300, "window_after": 3_600},
}
