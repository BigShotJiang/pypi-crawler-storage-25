"""Job-building helpers — defaults, presets, preview, validation, fluent builder."""

from .builder import (
    DEFAULT_JOB_OPTS,
    DefaultJobOpts,
    JobBuilder,
    JobOptsInput,
    SendRegisterJobOpts,
    register_job_opts,
)
from .presets import JOB_PRESETS, JobPresetName, JobWindowPreset
from .preview import JobCostPreview, PreviewJobCostInput, preview_job_cost
from .validate import (
    MIN_REASONABLE_GAS_LIMIT,
    ValidationResult,
    validate_register_opts,
)

__all__ = [
    # builder
    "DEFAULT_JOB_OPTS",
    "DefaultJobOpts",
    "JobBuilder",
    "JobOptsInput",
    "SendRegisterJobOpts",
    "register_job_opts",
    # presets
    "JOB_PRESETS",
    "JobPresetName",
    "JobWindowPreset",
    # preview
    "JobCostPreview",
    "PreviewJobCostInput",
    "preview_job_cost",
    # validate
    "MIN_REASONABLE_GAS_LIMIT",
    "ValidationResult",
    "validate_register_opts",
]
