"""Pre-flight validation for ``RegisterJob`` inputs.

The contract's on-chain asserts ultimately enforce the rules, but a failed
``RegisterJob`` round-trip costs gas and surfaces as a generic exit code.
:func:`validate_register_opts` catches the common foot-guns off-chain with
actionable error messages before any message is sent.

Classification:

- **errors** — things the registry will reject. Raising here turns a confusing
  on-chain failure into a local one.
- **warnings** — things that probably mean a bug but are legal. Returned as a
  ``warnings`` list so the caller can log them without aborting. Common
  example: ``gas_limit`` below the floor where almost no target fits.

Wired into :func:`register_job_opts` by default when ``cfg`` is supplied.
Opt out with ``validate=False`` if you know what you're doing.
"""

import time
from dataclasses import dataclass, field

from ..contracts.kronos_registry import RegistryConfigReply
from ..helpers.cost import ExecutionEconomicsInput, execution_economics

# Minimum gas_limit before a warning fires. ~1000 TVM gas at testnet rates.
MIN_REASONABLE_GAS_LIMIT: int = 1_000_000  # 0.001 TON

@dataclass
class ValidationResult:
    warnings: list[str] = field(default_factory=list)

def validate_register_opts(
    *,
    interval: int,
    reward: int,
    gas_limit: int,
    max_executions: int | None = None,
    expire_after: int | None = None,
    cfg: RegistryConfigReply,
) -> ValidationResult:
    """Validate job-registration inputs against the registry config.

    Raises ``ValueError`` on configuration errors the contract would reject;
    returns warnings for likely-buggy-but-legal inputs.

    Example::

        from kronos_sdk import validate_register_opts
        cfg = await client.jobs.config()
        result = validate_register_opts(
            interval=opts.interval, reward=opts.reward, gas_limit=opts.gas_limit, cfg=cfg
        )
        for w in result.warnings:
            log.warning("[kronos] %s", w)
    """
    warnings: list[str] = []

    # --- errors ---
    if interval < cfg.min_interval or interval > cfg.max_interval:
        raise ValueError(
            f"register_job: interval {interval}s is outside [{cfg.min_interval}, {cfg.max_interval}] "
            "— contract would reject with E_INTERVAL_OUT_OF_RANGE."
        )
    if reward < cfg.min_reward:
        raise ValueError(
            f"register_job: reward {reward} < min_reward {cfg.min_reward} "
            "— contract would reject with E_REWARD_BELOW_MIN."
        )
    if gas_limit <= 0:
        raise ValueError(
            "register_job: gas_limit must be > 0 — contract would reject with E_ZERO_GAS_LIMIT."
        )
    if max_executions is not None and max_executions < 0:
        raise ValueError(f"register_job: max_executions must be >= 0, got {max_executions}")
    if expire_after is not None and expire_after != 0 and expire_after < int(time.time()):
        raise ValueError(
            f"register_job: expire_after {expire_after} is already in the past — "
            "the job would be expired at registration."
        )

    # --- warnings ---
    if gas_limit < MIN_REASONABLE_GAS_LIMIT:
        warnings.append(
            f"gas_limit {gas_limit} is below {MIN_REASONABLE_GAS_LIMIT} nano-TON — most targets "
            "OOG at this level. Measure with a sandbox + recommended_gas_limit() before shipping."
        )
    econ = execution_economics(
        ExecutionEconomicsInput(
            reward=reward, gas_limit=gas_limit, protocol_fee_bps=cfg.protocol_fee_bps
        )
    )
    if econ.total_cost > cfg.min_funding:
        # Not an error — min_funding is a floor, not a ceiling. But it's a
        # signal the caller may have picked unusually large values.
        warnings.append(
            f"per-execution cost ({econ.total_cost}) exceeds min_funding ({cfg.min_funding}) — "
            "confirm that reward + gas_limit are sized correctly."
        )

    return ValidationResult(warnings=warnings)
