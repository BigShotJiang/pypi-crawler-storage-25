"""Helpers for building a ``register_job`` invocation with sensible defaults
and optional auto-funding against a live registry config.

Mirrors ``sdks/typescript/src/jobs/JobBuilder.ts`` 1:1 — the function
:func:`register_job_opts` matches TS ``registerJobOpts``. As a bonus over
the TS surface, the :class:`JobBuilder` class wraps the same logic in a
Python-idiomatic fluent API.
"""

import warnings as _warnings
from dataclasses import dataclass
from typing import Callable, Self

from pytoniq_core import Address, Cell

from ..contracts.kronos_registry import RegistryConfigReply
from ..helpers.cost import RecommendedRegisterValueInput, recommended_register_value
from .presets import JobWindowPreset
from .validate import validate_register_opts

@dataclass(frozen=True)
class DefaultJobOpts:
    window_before: int = 30
    """30 s — automatons can pre-fire when slightly behind."""
    window_after: int = 600
    """10 min — accommodates network congestion."""
    max_executions: int = 0
    """0 = unlimited executions."""
    expire_after: int = 0
    """0 = never expires."""

DEFAULT_JOB_OPTS: DefaultJobOpts = DefaultJobOpts()

@dataclass
class JobOptsInput:
    """Required + optional fields for :func:`register_job_opts`."""

    target: Address
    message: Cell
    interval: int
    reward: int
    gas_limit: int
    max_executions: int | None = None
    window_before: int | None = None
    window_after: int | None = None
    expire_after: int | None = None
    funding: int | None = None
    """Message ``value`` to attach. Auto-computed when omitted if ``cfg`` is supplied."""
    validate: bool = True
    """Run :func:`validate_register_opts` before returning. Has no effect when ``cfg`` is None."""
    on_warning: Callable[[str], None] | None = None
    """Callback for non-fatal validation warnings. Defaults to ``warnings.warn``."""

@dataclass(frozen=True)
class SendRegisterJobOpts:
    """Resolved kwargs for :meth:`KronosRegistry.send_register_job`."""

    value: int
    target: Address
    message: Cell
    interval: int
    reward: int
    gas_limit: int
    max_executions: int
    window_before: int
    window_after: int
    expire_after: int

    def as_kwargs(self) -> dict:
        """Spread into ``await registry.send_register_job(wallet, **opts.as_kwargs())``."""
        return {
            "value": self.value,
            "target": self.target,
            "message": self.message,
            "interval": self.interval,
            "reward": self.reward,
            "gas_limit": self.gas_limit,
            "max_executions": self.max_executions,
            "window_before": self.window_before,
            "window_after": self.window_after,
            "expire_after": self.expire_after,
        }

def register_job_opts(
    input: JobOptsInput,  # noqa: A002
    cfg: RegistryConfigReply | None = None,
) -> SendRegisterJobOpts:
    """Build a :class:`SendRegisterJobOpts` from a partial input + defaults.

    Example::

        from kronos_sdk import register_job_opts, JobOptsInput
        from pytoniq_core import begin_cell

        cfg = await client.jobs.config()
        opts = register_job_opts(
            JobOptsInput(
                target=target,
                message=begin_cell().end_cell(),
                interval=3600,
                reward=int(0.05 * 10**9),
                gas_limit=int(0.02 * 10**9),
                max_executions=1000,
            ),
            cfg,
        )
        await registry.send_register_job(wallet, **opts.as_kwargs())

    Raises:
        RuntimeError: when ``input.funding`` is omitted and ``cfg`` is not supplied.
    """
    # Validate first so errors surface before funding math runs on invalid inputs.
    if cfg is not None and input.validate is not False:
        result = validate_register_opts(
            interval=input.interval,
            reward=input.reward,
            gas_limit=input.gas_limit,
            max_executions=input.max_executions,
            expire_after=input.expire_after,
            cfg=cfg,
        )
        if result.warnings:
            on_warning = input.on_warning or (
                lambda msg: _warnings.warn(f"[kronos] {msg}", stacklevel=2)
            )
            for w in result.warnings:
                on_warning(w)

    value = input.funding
    if value is None:
        if cfg is None:
            raise RuntimeError(
                "register_job_opts: funding not set and no registry config supplied"
            )
        value = recommended_register_value(
            RecommendedRegisterValueInput(
                reward=input.reward,
                gas_limit=input.gas_limit,
                protocol_fee_bps=cfg.protocol_fee_bps,
                min_gas_reserve=cfg.min_gas_reserve,
                min_funding=cfg.min_funding,
                executions=100,
            )
        )

    return SendRegisterJobOpts(
        value=value,
        target=input.target,
        message=input.message,
        interval=input.interval,
        reward=input.reward,
        gas_limit=input.gas_limit,
        max_executions=(
            input.max_executions
            if input.max_executions is not None
            else DEFAULT_JOB_OPTS.max_executions
        ),
        window_before=(
            input.window_before
            if input.window_before is not None
            else DEFAULT_JOB_OPTS.window_before
        ),
        window_after=(
            input.window_after
            if input.window_after is not None
            else DEFAULT_JOB_OPTS.window_after
        ),
        expire_after=(
            input.expire_after if input.expire_after is not None else DEFAULT_JOB_OPTS.expire_after
        ),
    )

class JobBuilder:
    """Fluent wrapper around :func:`register_job_opts`.

    Bonus over the TS surface — Python-idiomatic alternative to constructing
    a :class:`JobOptsInput` dataclass manually. Each ``with_*`` setter
    returns the builder so calls can be chained.

    Example::

        from kronos_sdk import JobBuilder
        from pytoniq_core import begin_cell

        cfg = await client.jobs.config()
        opts = (JobBuilder()
            .target(target_addr)
            .message(begin_cell().store_uint(my_op, 32).end_cell())
            .interval(3600)
            .reward(int(0.05 * 10**9))
            .gas_limit(int(0.02 * 10**9))
            .max_executions(1000)
            .build(cfg))
        await registry.send_register_job(wallet, **opts.as_kwargs())
    """

    def __init__(self) -> None:
        self._target: Address | None = None
        self._message: Cell | None = None
        self._interval: int | None = None
        self._reward: int | None = None
        self._gas_limit: int | None = None
        self._max_executions: int | None = None
        self._window_before: int | None = None
        self._window_after: int | None = None
        self._expire_after: int | None = None
        self._funding: int | None = None
        self._validate: bool = True
        self._on_warning: Callable[[str], None] | None = None

    def target(self, target: Address) -> Self:
        self._target = target
        return self

    def message(self, message: Cell) -> Self:
        self._message = message
        return self

    def interval(self, interval: int) -> Self:
        self._interval = interval
        return self

    def reward(self, reward: int) -> Self:
        self._reward = reward
        return self

    def gas_limit(self, gas_limit: int) -> Self:
        self._gas_limit = gas_limit
        return self

    def max_executions(self, max_executions: int) -> Self:
        self._max_executions = max_executions
        return self

    def window_before(self, window_before: int) -> Self:
        self._window_before = window_before
        return self

    def window_after(self, window_after: int) -> Self:
        self._window_after = window_after
        return self

    def expire_after(self, expire_after: int) -> Self:
        self._expire_after = expire_after
        return self

    def funding(self, funding: int) -> Self:
        self._funding = funding
        return self

    def validate(self, validate: bool) -> Self:  # noqa: A003
        self._validate = validate
        return self

    def on_warning(self, on_warning: Callable[[str], None]) -> Self:
        self._on_warning = on_warning
        return self

    def with_preset(self, preset: JobWindowPreset) -> Self:
        """Apply a preset from :data:`JOB_PRESETS`.

        Example::

            from kronos_sdk import JOB_PRESETS, JobBuilder
            JobBuilder().target(...).message(...).interval(60).reward(...).gas_limit(...) \\
                .with_preset(JOB_PRESETS["tight"]).build(cfg)
        """
        self._window_before = preset["window_before"]
        self._window_after = preset["window_after"]
        return self

    def build(self, cfg: RegistryConfigReply | None = None) -> SendRegisterJobOpts:
        """Resolve the builder into a :class:`SendRegisterJobOpts`.

        Same auto-funding + validation rules as :func:`register_job_opts`.
        """
        if self._target is None:
            raise ValueError("JobBuilder: .target(...) is required")
        if self._message is None:
            raise ValueError("JobBuilder: .message(...) is required")
        if self._interval is None:
            raise ValueError("JobBuilder: .interval(...) is required")
        if self._reward is None:
            raise ValueError("JobBuilder: .reward(...) is required")
        if self._gas_limit is None:
            raise ValueError("JobBuilder: .gas_limit(...) is required")

        return register_job_opts(
            JobOptsInput(
                target=self._target,
                message=self._message,
                interval=self._interval,
                reward=self._reward,
                gas_limit=self._gas_limit,
                max_executions=self._max_executions,
                window_before=self._window_before,
                window_after=self._window_after,
                expire_after=self._expire_after,
                funding=self._funding,
                validate=self._validate,
                on_warning=self._on_warning,
            ),
            cfg,
        )
