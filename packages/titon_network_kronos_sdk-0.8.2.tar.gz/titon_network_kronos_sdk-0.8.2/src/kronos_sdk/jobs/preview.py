"""Unified cost preview for ``RegisterJob`` — single call returning everything
a UI needs to show users before they sign.

:func:`execution_economics` + :func:`recommended_register_value` already
compute these numbers individually. :func:`preview_job_cost` is the ergonomic
wrapper that:

1. Returns a flat, labeled dataclass instead of two separate calls.
2. Adds ``burn_rate_per_day`` — the derived number users actually care about.
3. Surfaces the ``min_funding`` floor separately from the recommended value
   so UIs can distinguish "will be accepted" vs. "will last N runs".
"""

from dataclasses import dataclass

from ..contracts.kronos_registry import RegistryConfigReply
from ..helpers.cost import (
    ExecutionEconomicsInput,
    RecommendedRegisterValueInput,
    execution_economics,
    recommended_register_value,
)

@dataclass(frozen=True)
class PreviewJobCostInput:
    reward: int
    gas_limit: int
    interval: int
    """Seconds. Only used for ``burn_rate_per_day``; does not affect cost math."""
    executions: int = 100
    """How many executions the recommended funding should cover."""

@dataclass(frozen=True)
class JobCostPreview:
    per_execution_cost: int
    """Cost deducted from the job balance per ``Execute``."""
    min_funding: int
    """Registry-enforced minimum attached value (after gas reserve)."""
    recommended: int
    """Recommended attached value — ``max(executions*cost, min_funding) + min_gas_reserve``."""
    protocol_fee: int
    """Portion of per-execution cost that accrues to ``accumulated_fees``."""
    automaton_reward: int
    """Portion paid to the executing automaton."""
    gas_limit: int
    """Forwarded to the target (echoed for completeness)."""
    burn_rate_per_day: int
    """Derived: ``per_execution_cost * (86400 // interval)``."""
    runs_at_min_funding: int
    """How many runs ``min_funding`` covers at this cost (integer division)."""
    runs_at_recommended: int
    """How many runs ``recommended`` covers."""

def preview_job_cost(
    input: PreviewJobCostInput,  # noqa: A002
    cfg: RegistryConfigReply,
) -> JobCostPreview:
    """Everything a UI needs to show users the cost of a job before they sign
    ``RegisterJob``.

    Pulls ``min_funding`` / ``protocol_fee_bps`` / ``min_gas_reserve`` from
    the registry config passed in; compose with
    ``await client.jobs.config()``.

    Example::

        from kronos_sdk import preview_job_cost, PreviewJobCostInput

        cfg = await client.jobs.config()
        p = preview_job_cost(
            PreviewJobCostInput(
                reward=int(0.05 * 10**9),
                gas_limit=int(0.02 * 10**9),
                interval=3600,
                executions=200,
            ),
            cfg,
        )
        print(f"per run: {p.per_execution_cost}")
        print(f"per day: {p.burn_rate_per_day}")
        print(f"attach to RegisterJob: {p.recommended}")
    """
    if input.interval <= 0:
        raise ValueError(f"interval must be > 0, got {input.interval}")

    econ = execution_economics(
        ExecutionEconomicsInput(
            reward=input.reward,
            gas_limit=input.gas_limit,
            protocol_fee_bps=cfg.protocol_fee_bps,
        )
    )

    recommended = recommended_register_value(
        RecommendedRegisterValueInput(
            reward=input.reward,
            gas_limit=input.gas_limit,
            protocol_fee_bps=cfg.protocol_fee_bps,
            min_gas_reserve=cfg.min_gas_reserve,
            min_funding=cfg.min_funding,
            executions=input.executions,
        )
    )

    seconds_per_day = 86_400
    burn_rate_per_day = (econ.total_cost * seconds_per_day) // input.interval

    runs_at_min_funding = 0 if econ.total_cost == 0 else cfg.min_funding // econ.total_cost
    runs_at_recommended = (
        0 if econ.total_cost == 0 else (recommended - cfg.min_gas_reserve) // econ.total_cost
    )

    return JobCostPreview(
        per_execution_cost=econ.total_cost,
        min_funding=cfg.min_funding,
        recommended=recommended,
        protocol_fee=econ.protocol_fee,
        automaton_reward=econ.automaton_reward,
        gas_limit=input.gas_limit,
        burn_rate_per_day=burn_rate_per_day,
        runs_at_min_funding=int(runs_at_min_funding),
        runs_at_recommended=int(runs_at_recommended),
    )
