"""Hand-written wrapper for the Tolk KronosRegistry contract.

Encoding rules (canonical source: ``contracts/messages.tolk`` +
``contracts/registry-storage.tolk``):

- Message body: 32-bit opcode via ``store_uint(OP, 32)`` then each field in
  the declaration order from ``contracts/messages.tolk``.
- Integer field widths match the Tolk declaration (``uint8`` → 8 bits, etc).
- ``coins`` → ``store_coins``.
- ``address`` → ``store_address`` (``None`` serialises as ``addr_none``).
- ``bool`` → ``store_bit``.
- ``cell`` field → ``store_ref``.
- Tolk ``address?``: pytoniq's ``store_address(None)`` already emits the
  2-bit addr_none header, no separate presence bit.
- Tolk ``uintN?``: one presence bit then the integer. For null:
  ``store_bit(False)``.
- Tolk empty map: one presence bit ``store_bit(False)`` and no ref.

The class mirrors the TypeScript ``KronosRegistry`` 1:1 — same method names
(``send_register_job`` <-> ``sendRegisterJob``, ``get_job`` <-> ``getJob``)
so docs translate by transliteration.
"""

from dataclasses import dataclass
from typing import Any, Self, Union

from pytoniq import BaseWallet, LiteBalancer, LiteClient
from pytoniq_core import Address, Cell, Slice, StateInit, begin_cell

from ..opcodes import OP

# A pytoniq client capable of running TVM get-methods. Both LiteClient (single
# liteserver) and LiteBalancer (round-robin / fail-over over many) implement
# ``run_get_method`` with the same signature.
Provider = Union[LiteClient, LiteBalancer]

# ===== Init / config =====

@dataclass(frozen=True)
class RegistryInitConfig:
    """Init-data fields for a fresh KronosRegistry deploy."""

    owner: Address
    treasury: Address

@dataclass(frozen=True)
class RegistryDefaults:
    """Protocol defaults — mirrors ``REGISTRY_DEFAULTS`` in the TS SDK.

    Slash penalty per missed execution. Must be ≤ pool's
    ``consumer.maxSlashPerEvent`` for kronos (set at SetConsumer admission).
    1 TON is symbolic + painful — easy default to remember.
    """

    min_reward: int = 10_000_000  # 0.01 TON
    min_funding: int = 500_000_000  # 0.5 TON
    min_interval: int = 60
    max_interval: int = 86_400
    protocol_fee_bps: int = 500
    min_storage_reserve: int = 100_000_000  # 0.1 TON
    min_gas_reserve: int = 50_000_000  # 0.05 TON
    primary_window_seconds: int = 30
    slash_gas_cost: int = 20_000_000  # 0.02 TON
    slash_amount: int = 1_000_000_000  # 1.0 TON

REGISTRY_DEFAULTS = RegistryDefaults()

# Schema versions — must match constants in registry-storage.tolk and
# kronos-registry.tolk. Exported so off-chain reconcilers / indexers can
# verify the deployed contract matches the SDK version they're using.
REGISTRY_STORAGE_VERSION: int = 1  # v1 — clean launch baseline (counter-free)
REGISTRY_CONFIG_BLOB_VERSION: int = 1
JOB_CONFIG_VERSION: int = 1
JOB_RECORD_VERSION: int = 1

def _registry_config_blob_cell(treasury: Address) -> Cell:
    """Build the ``RegistryConfigBlob`` cell — ordering must match registry-storage.tolk.

    ``upgrade`` ref carries ``{pendingCode: None, pendingCodeEta: 0}`` at deploy.
    """
    empty_upgrade = (
        begin_cell()
        .store_bit(False)  # pendingCode: cell? → null
        .store_uint(0, 32)  # pendingCodeEta: uint32
        .end_cell()
    )
    return (
        begin_cell()
        .store_uint(REGISTRY_CONFIG_BLOB_VERSION, 8)
        .store_address(treasury)
        .store_coins(REGISTRY_DEFAULTS.min_reward)
        .store_coins(REGISTRY_DEFAULTS.min_funding)
        .store_uint(REGISTRY_DEFAULTS.min_interval, 32)
        .store_uint(REGISTRY_DEFAULTS.max_interval, 32)
        .store_uint(REGISTRY_DEFAULTS.protocol_fee_bps, 16)
        .store_coins(REGISTRY_DEFAULTS.min_storage_reserve)
        .store_coins(REGISTRY_DEFAULTS.min_gas_reserve)
        .store_uint(REGISTRY_DEFAULTS.primary_window_seconds, 32)
        .store_coins(REGISTRY_DEFAULTS.slash_gas_cost)
        .store_coins(REGISTRY_DEFAULTS.slash_amount)
        .store_ref(empty_upgrade)  # upgrade: Cell<UpgradeState>
        .end_cell()
    )

def _registry_config_to_cell(config: RegistryInitConfig) -> Cell:
    """Build the root ``RegistryStorage`` cell.

    Field order must exactly match ``RegistryStorage`` in registry-storage.tolk.
    Counter-free clean-launch baseline — observability is event-sourced via the
    Argus indexer.
    """
    return (
        begin_cell()
        .store_uint(REGISTRY_STORAGE_VERSION, 8)  # schemaVersion: uint8
        .store_address(config.owner)  # owner: address
        .store_bit(False)  # paused: bool
        .store_uint(0, 64)  # jobSeqno: uint64
        .store_uint(0, 64)  # nextCleanupId: uint64
        .store_coins(0)  # accumulatedFees: coins
        .store_bit(False)  # housekeepingJobId: uint64? → null
        .store_address(None)  # forgeton: address? → addr_none
        .store_uint(0, 32)  # activeAutomatonCount: uint32
        .store_ref(_registry_config_blob_cell(config.treasury))  # configRef
        .store_bit(False)  # automatonAddresses: empty map
        .store_bit(False)  # automatonIndex: empty map
        .store_bit(False)  # jobs: empty map
        .end_cell()
    )

# ===== Getter reply structs =====

@dataclass(frozen=True)
class JobData:
    schema_version: int
    target: Address
    interval: int
    reward: int
    gas_limit: int
    max_executions: int
    execution_count: int
    window_before: int
    window_after: int
    expire_after: int
    owner: Address
    balance: int
    last_executed_at: int
    is_active: bool

@dataclass(frozen=True)
class RegistryConfigReply:
    min_reward: int
    min_funding: int
    min_interval: int
    max_interval: int
    protocol_fee_bps: int
    min_storage_reserve: int
    min_gas_reserve: int
    primary_window_seconds: int
    slash_gas_cost: int
    slash_amount: int

@dataclass(frozen=True)
class PendingUpgrade:
    code_hash: int
    eta: int

# ===== Contract wrapper =====

class KronosRegistry:
    """Wrapper for the on-chain KronosRegistry contract.

    Two construction paths mirror the TS SDK:

    - :meth:`create_from_config` — for fresh deploys; returns an instance
      whose ``address`` is the predicted post-deploy address and whose
      ``state_init`` carries the code+data needed for the deploy message.
    - :meth:`create_from_address` — for already-deployed contracts.

    All ``send_*`` methods take a pytoniq wallet (anything implementing
    ``transfer(destination, amount, body)``); all ``get_*`` methods take a
    pytoniq client (``LiteClient`` or ``LiteBalancer``). For ergonomic
    re-use, both can be passed at construction time and omitted from each
    call:

    Example::

        from pytoniq import LiteBalancer, WalletV4R2

        client = LiteBalancer.from_testnet_config(trust_level=2)
        await client.start_up()
        registry = KronosRegistry.create_from_address(KRONOS_TESTNET.registry, client=client)
        cfg = await registry.get_config()
        wallet = WalletV4R2.from_mnemonic(client, mnemonic.split())
        await registry.send_register_job(wallet, value=int(1.05e9), target=..., ...)
    """

    def __init__(
        self,
        address: Address,
        *,
        client: Provider | None = None,
        state_init: StateInit | None = None,
    ) -> None:
        self.address = address
        self.client = client
        self.state_init = state_init

    @classmethod
    def create_from_config(
        cls,
        config: RegistryInitConfig,
        code: Cell,
        *,
        workchain: int = 0,
        client: Provider | None = None,
    ) -> Self:
        data = _registry_config_to_cell(config)
        state_init = StateInit(code=code, data=data)
        addr = Address((workchain, state_init.serialize().hash))
        return cls(addr, client=client, state_init=state_init)

    @classmethod
    def create_from_address(
        cls,
        address: Address | str,
        *,
        client: Provider | None = None,
    ) -> Self:
        addr = address if isinstance(address, Address) else Address(address)
        return cls(addr, client=client)

    # ---- Static body builders (pure; no I/O) ----
    #
    # Useful for callers that want to construct the message body separately
    # from sending — e.g. automaton daemons that batch via raw_transfer, or
    # offline tools that just need to display a tx body.

    @staticmethod
    def deploy_body() -> Cell:
        """Empty body cell — sender supplies state_init separately."""
        return begin_cell().end_cell()

    @staticmethod
    def register_job_body(
        *,
        target: Address,
        message: Cell,
        interval: int,
        reward: int,
        gas_limit: int,
        max_executions: int,
        window_before: int,
        window_after: int,
        expire_after: int,
    ) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["RegisterJob"], 32)
            .store_address(target)
            .store_ref(message)
            .store_uint(interval, 32)
            .store_coins(reward)
            .store_coins(gas_limit)
            .store_uint(max_executions, 32)
            .store_uint(window_before, 16)
            .store_uint(window_after, 16)
            .store_uint(expire_after, 32)
            .end_cell()
        )

    @staticmethod
    def execute_body(*, job_id: int) -> Cell:
        return begin_cell().store_uint(OP["Execute"], 32).store_uint(job_id, 64).end_cell()

    @staticmethod
    def fund_job_body(*, job_id: int) -> Cell:
        return begin_cell().store_uint(OP["FundJob"], 32).store_uint(job_id, 64).end_cell()

    @staticmethod
    def cancel_job_body(*, job_id: int) -> Cell:
        return begin_cell().store_uint(OP["CancelJob"], 32).store_uint(job_id, 64).end_cell()

    @staticmethod
    def update_job_body(
        *, job_id: int, reward: int, interval: int, gas_limit: int
    ) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["UpdateJob"], 32)
            .store_uint(job_id, 64)
            .store_coins(reward)
            .store_uint(interval, 32)
            .store_coins(gas_limit)
            .end_cell()
        )

    @staticmethod
    def pause_job_body(*, job_id: int) -> Cell:
        return begin_cell().store_uint(OP["PauseJob"], 32).store_uint(job_id, 64).end_cell()

    @staticmethod
    def resume_job_body(*, job_id: int) -> Cell:
        return begin_cell().store_uint(OP["ResumeJob"], 32).store_uint(job_id, 64).end_cell()

    @staticmethod
    def withdraw_job_body(*, job_id: int, amount: int) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["WithdrawJob"], 32)
            .store_uint(job_id, 64)
            .store_coins(amount)
            .end_cell()
        )

    @staticmethod
    def update_job_full_body(
        *,
        job_id: int,
        target: Address,
        message: Cell,
        interval: int,
        reward: int,
        gas_limit: int,
        max_executions: int,
        window_before: int,
        window_after: int,
        expire_after: int,
    ) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["UpdateJobFull"], 32)
            .store_uint(job_id, 64)
            .store_address(target)
            .store_ref(message)
            .store_uint(interval, 32)
            .store_coins(reward)
            .store_coins(gas_limit)
            .store_uint(max_executions, 32)
            .store_uint(window_before, 16)
            .store_uint(window_after, 16)
            .store_uint(expire_after, 32)
            .end_cell()
        )

    @staticmethod
    def cleanup_expired_job_body(*, job_id: int) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["CleanupExpiredJob"], 32)
            .store_uint(job_id, 64)
            .end_cell()
        )

    @staticmethod
    def sweep_dust_body(*, job_id: int) -> Cell:
        return begin_cell().store_uint(OP["SweepDust"], 32).store_uint(job_id, 64).end_cell()

    @staticmethod
    def perform_housekeeping_body() -> Cell:
        return begin_cell().store_uint(OP["PerformHousekeeping"], 32).end_cell()

    @staticmethod
    def set_forgeton_body(*, forgeton: Address) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["SetForgeton"], 32)
            .store_address(forgeton)
            .end_cell()
        )

    @staticmethod
    def automaton_sync_body(*, automaton: Address, is_active: bool) -> Cell:
        """Inbound AutomatonSync body. Production senders are pool-only."""
        return (
            begin_cell()
            .store_uint(OP["AutomatonSync"], 32)
            .store_address(automaton)
            .store_bit(is_active)
            .end_cell()
        )

    @staticmethod
    def set_housekeeping_job_body(*, job_id: int) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["SetHousekeepingJob"], 32)
            .store_uint(job_id, 64)
            .end_cell()
        )

    @staticmethod
    def pause_body() -> Cell:
        return begin_cell().store_uint(OP["Pause"], 32).end_cell()

    @staticmethod
    def unpause_body() -> Cell:
        return begin_cell().store_uint(OP["Unpause"], 32).end_cell()

    @staticmethod
    def update_config_body(
        *,
        min_reward: int,
        min_funding: int,
        min_interval: int,
        max_interval: int,
        protocol_fee_bps: int,
        min_storage_reserve: int,
        min_gas_reserve: int,
        primary_window_seconds: int,
        slash_gas_cost: int,
        slash_amount: int,
    ) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["UpdateConfig"], 32)
            .store_coins(min_reward)
            .store_coins(min_funding)
            .store_uint(min_interval, 32)
            .store_uint(max_interval, 32)
            .store_uint(protocol_fee_bps, 16)
            .store_coins(min_storage_reserve)
            .store_coins(min_gas_reserve)
            .store_uint(primary_window_seconds, 32)
            .store_coins(slash_gas_cost)
            .store_coins(slash_amount)
            .end_cell()
        )

    @staticmethod
    def update_treasury_body(*, treasury: Address) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["UpdateTreasury"], 32)
            .store_address(treasury)
            .end_cell()
        )

    @staticmethod
    def withdraw_fees_body(*, amount: int) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["WithdrawFees"], 32)
            .store_coins(amount)
            .end_cell()
        )

    @staticmethod
    def propose_code_upgrade_body(*, new_code: Cell, eta: int) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["ProposeCodeUpgrade"], 32)
            .store_ref(new_code)
            .store_uint(eta, 32)
            .end_cell()
        )

    @staticmethod
    def execute_code_upgrade_body() -> Cell:
        return begin_cell().store_uint(OP["ExecuteCodeUpgrade"], 32).end_cell()

    @staticmethod
    def cancel_code_upgrade_body() -> Cell:
        return begin_cell().store_uint(OP["CancelCodeUpgrade"], 32).end_cell()

    @staticmethod
    def retry_slash_body(*, automaton: Address, job_id: int) -> Cell:
        return (
            begin_cell()
            .store_uint(OP["RetrySlash"], 32)
            .store_address(automaton)
            .store_uint(job_id, 64)
            .end_cell()
        )

    # ---- send_* methods ----
    #
    # Each one builds the body via the static helpers above and forwards to
    # ``wallet.transfer(...)``. The wallet is anything that conforms to the
    # ``async transfer(destination, amount, body, state_init=None)`` shape —
    # WalletV4R2, WalletV5R1, etc. State-init is included only for deploys.

    async def send_deploy(
        self, wallet: BaseWallet, value: int
    ) -> Any:
        if self.state_init is None:
            raise RuntimeError(
                "send_deploy requires a state_init — construct via create_from_config(config, code)."
            )
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.deploy_body(),
            state_init=self.state_init,
        )

    async def send_register_job(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        target: Address,
        message: Cell,
        interval: int,
        reward: int,
        gas_limit: int,
        max_executions: int,
        window_before: int,
        window_after: int,
        expire_after: int,
    ) -> Any:
        body = self.register_job_body(
            target=target,
            message=message,
            interval=interval,
            reward=reward,
            gas_limit=gas_limit,
            max_executions=max_executions,
            window_before=window_before,
            window_after=window_after,
            expire_after=expire_after,
        )
        return await wallet.transfer(destination=self.address, amount=value, body=body)

    async def send_execute(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.execute_body(job_id=job_id),
        )

    async def send_fund_job(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.fund_job_body(job_id=job_id),
        )

    async def send_cancel_job(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.cancel_job_body(job_id=job_id),
        )

    async def send_update_job(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        job_id: int,
        reward: int,
        interval: int,
        gas_limit: int,
    ) -> Any:
        """Update a job's reward, interval, and gasLimit.

        ⚠️ **Full overwrite.** All three fields are written; there is no
        "update only reward" overload. To change one, fetch the current job
        and preserve the others. Owner-gated; reverts ``E_NOT_JOB_OWNER`` (132)
        for non-owners.
        """
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.update_job_body(
                job_id=job_id,
                reward=reward,
                interval=interval,
                gas_limit=gas_limit,
            ),
        )

    async def send_pause_job(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.pause_job_body(job_id=job_id),
        )

    async def send_resume_job(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.resume_job_body(job_id=job_id),
        )

    async def send_withdraw_job(
        self, wallet: BaseWallet, *, value: int, job_id: int, amount: int
    ) -> Any:
        """Withdraw ``amount`` from a job's balance without cancelling.

        ⚠️ **Active jobs reject withdrawals that leave the balance below one
        execution cost** (``E_BELOW_MIN_FOR_ACTIVE = 134``). To drain
        everything: pause first (then withdraw is unrestricted) or cancel
        (refunds all + deletes the entry). Owner-gated.
        """
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.withdraw_job_body(job_id=job_id, amount=amount),
        )

    async def send_update_job_full(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        job_id: int,
        target: Address,
        message: Cell,
        interval: int,
        reward: int,
        gas_limit: int,
        max_executions: int,
        window_before: int,
        window_after: int,
        expire_after: int,
    ) -> Any:
        """Rewrite every mutable field of a job.

        Preserves only ``execution_count`` and schema ``version``. Reverts
        ``E_MAX_EXEC_BELOW_COUNT`` (143) if ``max_executions <`` current
        ``execution_count``. Owner-gated.
        """
        body = self.update_job_full_body(
            job_id=job_id,
            target=target,
            message=message,
            interval=interval,
            reward=reward,
            gas_limit=gas_limit,
            max_executions=max_executions,
            window_before=window_before,
            window_after=window_after,
            expire_after=expire_after,
        )
        return await wallet.transfer(destination=self.address, amount=value, body=body)

    async def send_cleanup_expired_job(
        self, wallet: BaseWallet, *, value: int, job_id: int
    ) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.cleanup_expired_job_body(job_id=job_id),
        )

    async def send_sweep_dust(self, wallet: BaseWallet, *, value: int, job_id: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.sweep_dust_body(job_id=job_id),
        )

    async def send_perform_housekeeping(self, wallet: BaseWallet, *, value: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.perform_housekeeping_body(),
        )

    async def send_set_forgeton(
        self, wallet: BaseWallet, *, value: int, forgeton: Address
    ) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.set_forgeton_body(forgeton=forgeton),
        )

    async def send_automaton_sync(
        self, wallet: BaseWallet, *, value: int, automaton: Address, is_active: bool
    ) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.automaton_sync_body(automaton=automaton, is_active=is_active),
        )

    async def send_set_housekeeping_job(
        self, wallet: BaseWallet, *, value: int, job_id: int
    ) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.set_housekeeping_job_body(job_id=job_id),
        )

    async def send_pause(self, wallet: BaseWallet, *, value: int) -> Any:
        return await wallet.transfer(
            destination=self.address, amount=value, body=self.pause_body()
        )

    async def send_unpause(self, wallet: BaseWallet, *, value: int) -> Any:
        return await wallet.transfer(
            destination=self.address, amount=value, body=self.unpause_body()
        )

    async def send_update_config(
        self,
        wallet: BaseWallet,
        *,
        value: int,
        min_reward: int,
        min_funding: int,
        min_interval: int,
        max_interval: int,
        protocol_fee_bps: int,
        min_storage_reserve: int,
        min_gas_reserve: int,
        primary_window_seconds: int,
        slash_gas_cost: int,
        slash_amount: int,
    ) -> Any:
        body = self.update_config_body(
            min_reward=min_reward,
            min_funding=min_funding,
            min_interval=min_interval,
            max_interval=max_interval,
            protocol_fee_bps=protocol_fee_bps,
            min_storage_reserve=min_storage_reserve,
            min_gas_reserve=min_gas_reserve,
            primary_window_seconds=primary_window_seconds,
            slash_gas_cost=slash_gas_cost,
            slash_amount=slash_amount,
        )
        return await wallet.transfer(destination=self.address, amount=value, body=body)

    async def send_update_treasury(
        self, wallet: BaseWallet, *, value: int, treasury: Address
    ) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.update_treasury_body(treasury=treasury),
        )

    async def send_withdraw_fees(self, wallet: BaseWallet, *, value: int, amount: int) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.withdraw_fees_body(amount=amount),
        )

    async def send_propose_code_upgrade(
        self, wallet: BaseWallet, *, value: int, new_code: Cell, eta: int
    ) -> Any:
        """Step 1 of 3 in the timelocked code-upgrade flow.

        ⚠️ ``eta`` is an ABSOLUTE unix timestamp, not a delta. Compute as
        ``int(time.time()) + delay_seconds``.

        Min delay enforced on-chain: 24 hours. Reverts
        ``E_UPGRADE_ETA_TOO_SOON`` (117) if ``eta < now + 86400``. Reverts
        ``E_UPGRADE_ALREADY_PENDING`` (118) if a proposal is already in-flight.
        Owner-gated.
        """
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.propose_code_upgrade_body(new_code=new_code, eta=eta),
        )

    async def send_execute_code_upgrade(self, wallet: BaseWallet, *, value: int) -> Any:
        return await wallet.transfer(
            destination=self.address, amount=value, body=self.execute_code_upgrade_body()
        )

    async def send_cancel_code_upgrade(self, wallet: BaseWallet, *, value: int) -> Any:
        return await wallet.transfer(
            destination=self.address, amount=value, body=self.cancel_code_upgrade_body()
        )

    async def send_retry_slash(
        self, wallet: BaseWallet, *, value: int, automaton: Address, job_id: int
    ) -> Any:
        return await wallet.transfer(
            destination=self.address,
            amount=value,
            body=self.retry_slash_body(automaton=automaton, job_id=job_id),
        )

    # ---- Getters ----

    def _require_client(self) -> Provider:
        if self.client is None:
            raise RuntimeError(
                "KronosRegistry needs a pytoniq client (LiteClient or LiteBalancer); "
                "construct via create_from_address(addr, client=client)."
            )
        return self.client

    async def _run(self, method: str, stack: list[Any] | None = None) -> list[Any]:
        client = self._require_client()
        return await client.run_get_method(self.address, method, stack or [])

    async def get_job(self, job_id: int) -> JobData | None:
        """Read a job's full state. Returns ``None`` if the jobId is unknown.

        ``JobData?`` flattens onto the stack — Tolk pushes a single ``null`` for
        the absent case, the full 14 fields otherwise. Pytoniq surfaces the
        null case as a list whose first slot is ``None``; an unpack on that
        raises :class:`ValueError`, which we treat as "no such job".
        """
        result = await self._run("job", [job_id])
        try:
            (
                schema_version,
                target_slice,
                interval,
                reward,
                gas_limit,
                max_executions,
                execution_count,
                window_before,
                window_after,
                expire_after,
                owner_slice,
                balance,
                last_executed_at,
                is_active,
            ) = result
        except (ValueError, TypeError):
            return None
        return JobData(
            schema_version=int(schema_version),
            target=_load_address(target_slice),
            interval=int(interval),
            reward=int(reward),
            gas_limit=int(gas_limit),
            max_executions=int(max_executions),
            execution_count=int(execution_count),
            window_before=int(window_before),
            window_after=int(window_after),
            expire_after=int(expire_after),
            owner=_load_address(owner_slice),
            balance=int(balance),
            last_executed_at=int(last_executed_at),
            is_active=bool(is_active),
        )

    async def get_is_due(self, job_id: int) -> bool:
        result = await self._run("isDue", [job_id])
        return bool(result[0])

    async def get_job_balance(self, job_id: int) -> int:
        result = await self._run("jobBalance", [job_id])
        return int(result[0])

    async def get_next_due(self, job_id: int) -> int:
        result = await self._run("nextDue", [job_id])
        return int(result[0])

    async def get_job_count(self) -> int:
        result = await self._run("jobCount")
        return int(result[0])

    async def get_accumulated_fees(self) -> int:
        result = await self._run("accumulatedFees")
        return int(result[0])

    async def get_is_paused(self) -> bool:
        result = await self._run("isPaused")
        return bool(result[0])

    async def get_config(self) -> RegistryConfigReply:
        result = await self._run("config")
        return RegistryConfigReply(
            min_reward=int(result[0]),
            min_funding=int(result[1]),
            min_interval=int(result[2]),
            max_interval=int(result[3]),
            protocol_fee_bps=int(result[4]),
            min_storage_reserve=int(result[5]),
            min_gas_reserve=int(result[6]),
            primary_window_seconds=int(result[7]),
            slash_gas_cost=int(result[8]),
            slash_amount=int(result[9]),
        )

    async def get_next_cleanup_id(self) -> int:
        result = await self._run("nextCleanupId")
        return int(result[0])

    async def get_housekeeping_job_id(self) -> int | None:
        result = await self._run("housekeepingJobId")
        v = result[0]
        return None if v is None else int(v)

    async def get_forgeton(self) -> Address | None:
        result = await self._run("forgeton")
        return _load_address_opt(result[0])

    async def get_active_automaton_count(self) -> int:
        result = await self._run("activeAutomatonCount")
        return int(result[0])

    async def get_pending_upgrade(self) -> PendingUpgrade:
        """Returns ``(code_hash, eta)``. ``code_hash == 0`` when nothing is pending."""
        result = await self._run("pendingUpgrade")
        return PendingUpgrade(code_hash=int(result[0]), eta=int(result[1]))

    async def get_automaton_at(self, index: int) -> Address | None:
        result = await self._run("automatonAt", [index])
        return _load_address_opt(result[0])

    async def get_assigned_automaton(self, job_id: int, execution_count: int) -> Address | None:
        result = await self._run("assignedAutomaton", [job_id, execution_count])
        return _load_address_opt(result[0])

    async def get_owner(self) -> Address:
        result = await self._run("owner")
        return _load_address(result[0])

    async def get_treasury(self) -> Address:
        result = await self._run("treasury")
        return _load_address(result[0])

    async def get_storage_version(self) -> int:
        """Schema version of the deployed root storage.

        Compare against :data:`REGISTRY_STORAGE_VERSION` to confirm the contract
        matches this SDK's expected layout. Mismatch → either the contract is
        on a different code version, or the SDK is stale.
        """
        result = await self._run("storageVersion")
        return int(result[0])

# ===== Slice → address helpers =====
#
# Liteservers return addresses inside the get-method stack as ``Slice`` objects
# (the slice is positioned over the address bits). Sometimes pytoniq has
# already loaded one to an ``Address``; sometimes the field is null
# (``addr_none``) which surfaces as ``None``. Both helpers normalise to
# ``Address``; the strict variant raises on ``addr_none`` and is used for
# fields the contract guarantees non-null (owner, treasury, target).


def _load_address_opt(value: "Slice | Address | None") -> Address | None:
    """Coerce a stack entry into ``Address`` or ``None`` (addr_none / missing)."""
    if value is None:
        return None
    if isinstance(value, Address):
        return value
    return value.load_address()


def _load_address(value: "Slice | Address") -> Address:
    """Like :func:`_load_address_opt` but raises on a null/addr_none entry."""
    addr = _load_address_opt(value)
    if addr is None:
        raise ValueError("expected non-null address, got addr_none")
    return addr
