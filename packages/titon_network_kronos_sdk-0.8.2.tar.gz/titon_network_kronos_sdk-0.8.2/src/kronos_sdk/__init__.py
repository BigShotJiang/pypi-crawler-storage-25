"""titon-network-kronos-sdk — Python SDK for Kronos.

Three layers, pick what you need:

  1. **Low-level wrapper** — :class:`KronosRegistry`. Matches the on-chain ABI
     1:1; use directly when you need full control.

  2. **Helpers** — pure functions that mirror on-chain math (assignment formula,
     execution cost, window state). No network calls.

  3. **High-level** — :class:`KronosClient` (façade), :class:`JobBuilder`
     (fluent), :func:`decode_event` (typed event parsing). The path-of-least-
     resistance for most integrations.

Plus error introspection (:func:`explain_error`, :class:`KronosError`) and
bundled compiled contract code via :func:`load_registry_code`.

The shared-security staking pool (ForgeTON) lives in a sibling Python SDK
(forgeton-sdk) — install it alongside ``titon-network-kronos-sdk`` when you
need to interact with the pool directly.
"""

# Constants
from .opcodes import ERR, ERR_BY_VALUE, OP, OP_BY_VALUE

# Errors
from .errors import (
    ErrorCode,
    ErrorExplanation,
    ErrorOrigin,
    KronosError,
    explain_error,
    format_error_explanation,
)

# Contract wrapper
from .contracts import (
    JOB_CONFIG_VERSION,
    JOB_RECORD_VERSION,
    REGISTRY_CONFIG_BLOB_VERSION,
    REGISTRY_DEFAULTS,
    REGISTRY_STORAGE_VERSION,
    JobData,
    KronosRegistry,
    PendingUpgrade,
    RegistryConfigReply,
    RegistryDefaults,
    RegistryInitConfig,
)

# Helpers
from .helpers import (
    AssignmentInput,
    BPS_DENOMINATOR,
    EstimateJobGasResult,
    ExecutableInput,
    ExecutionEconomics,
    ExecutionEconomicsInput,
    JobWindowInput,
    JobWindowState,
    RecommendedRegisterValueInput,
    ResolveAssignedInput,
    WindowStatus,
    assigned_automaton,
    assigned_automaton_index,
    compute_window_state,
    estimate_register_value,
    execution_cost,
    execution_economics,
    is_due,
    is_executable,
    job_funding_for,
    job_window_state,
    next_due,
    next_execution_at,
    recommended_gas_limit,
    recommended_register_value,
    resolve_assigned_automaton,
    window_state,
)

# Events
from .events import (
    AssignedAutomatonMissedEvent,
    AutomatonMirrorUpdatedEvent,
    BaseEvent,
    CodeUpdatedEvent,
    ConfigUpdatedEvent,
    DecodedEvent,
    EventKind,
    EventSource,
    FeesWithdrawnEvent,
    ForgetonSetEvent,
    HousekeepingJobSetEvent,
    JobCancelledEvent,
    JobDustSweptEvent,
    JobExecutedEvent,
    JobExpiredEvent,
    JobFundedEvent,
    JobHousekeepingExecutedEvent,
    JobPausedEvent,
    JobRegisteredEvent,
    JobResumedEvent,
    JobUpdatedEvent,
    JobWatcher,
    JobWatcherEvent,
    JobWatcherKind,
    JobWatcherOptions,
    JobWithdrawnEvent,
    KronosEvent,
    LowBalanceEvent,
    PausedChangedEvent,
    SlashRetriedEvent,
    TreasuryUpdatedEvent,
    UpgradeCancelledEvent,
    UpgradeProposedEvent,
    decode_event,
    decode_events,
)

# Job building
from .jobs import (
    DEFAULT_JOB_OPTS,
    JOB_PRESETS,
    MIN_REASONABLE_GAS_LIMIT,
    DefaultJobOpts,
    JobBuilder,
    JobCostPreview,
    JobOptsInput,
    JobPresetName,
    JobWindowPreset,
    PreviewJobCostInput,
    SendRegisterJobOpts,
    ValidationResult,
    preview_job_cost,
    register_job_opts,
    validate_register_opts,
)

# High-level client
from .client import (
    EnsureFundedOptions,
    EnsureFundedResult,
    EventsFacade,
    JobBalanceHealth,
    JobBalanceStatus,
    JobsFacade,
    KronosClient,
    MirrorFacade,
)

# Compiled artifacts
from .artifacts import load_registry_code

# Live deployments
from .deployments import KRONOS_TESTNET, KronosDeployment

# Public surface, organised by layer:
#
#   Layer 1 — low-level on-chain ABI: `KronosRegistry`. Body builders +
#             `send_*` + `get_*` for every receiver / getter. Use when you
#             need full control or want to construct cells without sending.
#
#   Layer 2 — pure helpers (no I/O): mirror the on-chain math off-chain
#             (assignment, cost, gas, windows). Cheap to call from anywhere.
#
#   Layer 3 — high-level: `KronosClient` (with `.jobs`, `.mirror`, `.events`
#             facades), `JobBuilder` (fluent builder), `decode_event` /
#             `JobWatcher` (event consumption). Path of least resistance for
#             most integrations.
#
# Plus error introspection (`explain_error`, `KronosError`), bundled compiled
# contract code (`load_registry_code`), and the live-deployment constant
# (`KRONOS_TESTNET`).
__all__ = [
    # Constants
    "OP",
    "ERR",
    "OP_BY_VALUE",
    "ERR_BY_VALUE",
    # Errors
    "ErrorCode",
    "ErrorExplanation",
    "ErrorOrigin",
    "KronosError",
    "explain_error",
    "format_error_explanation",
    # Contracts
    "KronosRegistry",
    "RegistryInitConfig",
    "RegistryDefaults",
    "REGISTRY_DEFAULTS",
    "REGISTRY_STORAGE_VERSION",
    "REGISTRY_CONFIG_BLOB_VERSION",
    "JOB_CONFIG_VERSION",
    "JOB_RECORD_VERSION",
    "JobData",
    "PendingUpgrade",
    "RegistryConfigReply",
    # Helpers
    "AssignmentInput",
    "BPS_DENOMINATOR",
    "EstimateJobGasResult",
    "ExecutableInput",
    "ExecutionEconomics",
    "ExecutionEconomicsInput",
    "JobWindowInput",
    "JobWindowState",
    "RecommendedRegisterValueInput",
    "ResolveAssignedInput",
    "WindowStatus",
    "assigned_automaton",
    "assigned_automaton_index",
    "compute_window_state",
    "estimate_register_value",
    "execution_cost",
    "execution_economics",
    "is_due",
    "is_executable",
    "job_funding_for",
    "job_window_state",
    "next_due",
    "next_execution_at",
    "recommended_gas_limit",
    "recommended_register_value",
    "resolve_assigned_automaton",
    "window_state",
    # Events
    "AssignedAutomatonMissedEvent",
    "AutomatonMirrorUpdatedEvent",
    "BaseEvent",
    "CodeUpdatedEvent",
    "ConfigUpdatedEvent",
    "DecodedEvent",
    "EventKind",
    "EventSource",
    "FeesWithdrawnEvent",
    "ForgetonSetEvent",
    "HousekeepingJobSetEvent",
    "JobCancelledEvent",
    "JobDustSweptEvent",
    "JobExecutedEvent",
    "JobExpiredEvent",
    "JobFundedEvent",
    "JobHousekeepingExecutedEvent",
    "JobPausedEvent",
    "JobRegisteredEvent",
    "JobResumedEvent",
    "JobUpdatedEvent",
    "JobWatcher",
    "JobWatcherEvent",
    "JobWatcherKind",
    "JobWatcherOptions",
    "JobWithdrawnEvent",
    "KronosEvent",
    "LowBalanceEvent",
    "PausedChangedEvent",
    "SlashRetriedEvent",
    "TreasuryUpdatedEvent",
    "UpgradeCancelledEvent",
    "UpgradeProposedEvent",
    "decode_event",
    "decode_events",
    # Jobs
    "DEFAULT_JOB_OPTS",
    "JOB_PRESETS",
    "MIN_REASONABLE_GAS_LIMIT",
    "DefaultJobOpts",
    "JobBuilder",
    "JobCostPreview",
    "JobOptsInput",
    "JobPresetName",
    "JobWindowPreset",
    "PreviewJobCostInput",
    "SendRegisterJobOpts",
    "ValidationResult",
    "preview_job_cost",
    "register_job_opts",
    "validate_register_opts",
    # Client
    "EnsureFundedOptions",
    "EnsureFundedResult",
    "EventsFacade",
    "JobBalanceHealth",
    "JobBalanceStatus",
    "JobsFacade",
    "KronosClient",
    "MirrorFacade",
    # Artifacts
    "load_registry_code",
    # Deployments
    "KRONOS_TESTNET",
    "KronosDeployment",
]

__version__ = "0.8.2"
