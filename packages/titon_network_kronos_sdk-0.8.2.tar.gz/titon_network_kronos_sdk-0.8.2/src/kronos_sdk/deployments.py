"""Canonical addresses of live Kronos deployments per network.

These mirror deployments.{network}.json at the repo root — both files are
updated together when a fresh deploy lands. Use these instead of hardcoding
addresses in your application code.

Example::

    from kronos_sdk import KRONOS_TESTNET, KronosClient, KronosRegistry
    from pytoniq import LiteBalancer

    client = LiteBalancer.from_testnet_config(trust_level=2)
    await client.start_up()
    registry = KronosRegistry.create_from_address(
        KRONOS_TESTNET.registry, client=client
    )
    kronos = KronosClient(registry=registry)
"""

from dataclasses import dataclass

from pytoniq_core import Address

@dataclass(frozen=True)
class KronosDeployment:
    """Pinned addresses + housekeeping jobId for a single Kronos deployment."""

    registry: Address
    forgeton: Address
    housekeeping_job_id: int  # bigint in TS; native int in Python

KRONOS_TESTNET: KronosDeployment = KronosDeployment(
    registry=Address("0QD92bDtZ037uRNVr51jWCgz6_nhHdkQJv3S_0Um36WvrNNt"),
    forgeton=Address("0QD-9fxQ8k1f23xNFyWI-edoh-WnAIDMUrwvodnkSWYuz1rF"),
    # Sentinel: 0 means "no housekeeping job pinned yet". A real job_id lands
    # here once the registry owner runs `register_housekeeping_job` on the
    # post-deploy step. Indexers should treat 0 as "unknown / not pinned",
    # not as a literal jobId 0.
    housekeeping_job_id=0,
)

# KRONOS_MAINNET will be added when the mainnet deploy lands.
