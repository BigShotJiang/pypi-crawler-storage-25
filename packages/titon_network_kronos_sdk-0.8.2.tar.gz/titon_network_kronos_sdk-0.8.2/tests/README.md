# Tests as docs

The pytest suite doubles as runnable worked examples for every public API.
This index maps a question you might be answering to the test that pins the
behaviour.

## "How do I X?" → look here

| Question | File:test |
|----------|-----------|
| What's the canonical opcode for X? | `test_opcodes.py::test_op_pinned_constants` |
| What error code does Y throw? | `test_opcodes.py::test_err_pinned_constants` + `test_errors.py::test_kronos_codes_get_kronos_origin` |
| How do I read the testnet deployment? | `test_deployments.py::test_kronos_testnet_matches_json` |
| How do I encode + decode an event? | `test_events.py::test_round_trip_job_executed` (and all 24 in `test_events_full.py`) |
| How do I build a `RegisterJob` body? | `test_contracts.py::test_register_job_body_starts_with_opcode` + `test_bodies_full.py::test_register_job_body_round_trip` |
| How do I derive a deploy address? | `test_contracts.py::test_create_from_config_predicts_live_testnet_address` |
| How does `JobBuilder` chain? | `test_jobs.py::test_job_builder_chains_and_builds` |
| How does `register_job_opts` auto-fund? | `test_jobs.py::test_register_job_opts_auto_funds_when_cfg_supplied` |
| What does `validate_register_opts` reject? | `test_jobs.py::test_validate_rejects_*` + `test_misc_coverage.py::test_validate_rejects_*` |
| How do I compute per-execution cost? | `test_helpers.py::test_execution_economics_basic` |
| How does the assignment formula work? | `test_helpers.py::test_assignment_index_*` |
| How does the window state machine work? | `test_helpers.py::test_window_state_*` |
| How do I size `gas_limit` with a buffer? | `test_helpers.py::test_recommended_gas_limit_buffers_correctly` |
| How do I drive `JobWatcher` deterministically? | `test_watcher.py::test_dispatches_matching_job_events_to_callbacks` |
| How does `LowBalance` synthesis work? | `test_watcher.py::test_low_balance_synthesis_fires_when_below_threshold` + `test_low_balance_re_arms_after_recovery` |
| How do I unsubscribe `JobWatcher`? | `test_watcher.py::test_start_returns_stop_function_and_stops_cleanly` |
| What does `explain_error` return for each origin? | `test_errors.py::test_*_origin` |
| How do I wrap an exit code in `KronosError`? | `test_errors.py::test_kronos_error_exception_carries_explanation` |
| How does `resolve_assigned_automaton` accept Mapping vs Sequence? | `test_misc_coverage.py::test_resolve_assigned_with_*_mirror` |

## Files at a glance

| File | What it pins |
|------|-------------|
| `test_opcodes.py` | OP / ERR tables match `contracts/{messages,errors}.tolk` 1:1; reverse maps; pinned constants. |
| `test_errors.py` | `explain_error` dispatch by origin (kronos / forgeton / tvm / unknown); `format_error_explanation`; `KronosError`. |
| `test_deployments.py` | `KRONOS_TESTNET` matches `deployments.testnet.json`; addresses are wc=0; dataclass is frozen. |
| `test_helpers.py` | Pure-math helpers: assignment, cost/economics, window state, gas-buffer. |
| `test_jobs.py` | `JOB_PRESETS`, `validate_register_opts`, `register_job_opts` auto-funding, `JobBuilder` fluent path, `preview_job_cost`. |
| `test_events.py` | Event decoder smoke (a few canonical events). |
| `test_contracts.py` | `KronosRegistry.create_from_*` smoke; deploy-address derivation byte-identical to TS; representative body builders. |
| `test_events_full.py` | **Every** event opcode (23 events + 1 fixture-completeness check) round-trips encode → decode. Catches "added a new event without a decoder". |
| `test_bodies_full.py` | **Every** `*_body()` builder asserts opcode + field round-trip. Catches "added a new send method without a body builder". |
| `test_watcher.py` | `JobWatcher` async loop: dispatch, filter, multi-callback, async callback, low-balance synthesis + re-arm, start/stop, exception isolation. |
| `test_misc_coverage.py` | Helper aliases (`next_due`, `window_state`, …); `resolve_assigned_automaton` Mapping + Sequence + out-of-bounds; `validate_register_opts` edge raise paths. |
| `test_easy_wins.py` | `JobBuilder` fluent setter coverage; missing-required-field raises; `register_job_opts` default warning emission; artifact-loader error paths. |

## Running

```bash
# All tests
python -m pytest tests/ -q

# With coverage
python -m pytest tests/ --cov=kronos_sdk --cov-report=term-missing

# Just one file
python -m pytest tests/test_jobs.py -q

# A single test (great for "how does this work" exploration)
python -m pytest tests/test_watcher.py::test_low_balance_synthesis_fires_when_below_threshold -v
```

## Adding a new test

When you add a new feature, add a new test row to the table above and a
matching pytest function. The test serves double duty as the canonical
worked example for that behaviour — keep it simple, well-commented, and
fixture-driven.

The test files use these conventions:

- `_FIXTURES` lists in `test_events_full.py` / `test_bodies_full.py` make
  it cheap to add a new entry without re-typing the test scaffolding.
- The `cfg` fixture in `test_jobs.py` / `test_misc_coverage.py` /
  `test_easy_wins.py` synthesises a `RegistryConfigReply` from
  `REGISTRY_DEFAULTS` so tests don't need a network round-trip.
- `tests/conftest.py` puts `src/` on `sys.path` so tests work without
  installing the package.
