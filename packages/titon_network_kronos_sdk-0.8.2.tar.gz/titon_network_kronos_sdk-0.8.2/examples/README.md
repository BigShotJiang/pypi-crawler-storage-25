# Examples

Runnable scripts demonstrating the most common use cases of
`titon-network-kronos-sdk`.

| File | What it shows |
|------|---------------|
| [`01_register_job.py`](./01_register_job.py) | Connect to live testnet, build a `RegisterJob` payload via `JobBuilder`. Stops before sending — uncomment the wallet wiring at the bottom to fire it for real. |
| [`02_decode_events.py`](./02_decode_events.py) | Pure-Python event-decoder demo on synthetic bodies. Mirror this pattern in any indexer that subscribes to external-out messages. |

> **Missing automaton-register example?** The TS SDK ships
> `02-automaton-register.ts` that calls `forgeton-sdk` to stake. The
> Python forgeton SDK is a separate package — that example will land
> once the Python forgeton SDK is published. The TS example reads as
> Python without surprises in the meantime.

## No sandbox, on purpose

The TS examples use `@ton/sandbox` for an offline demo blockchain. Python's
TVM emulator surface (via `pytoniq`) is significantly weaker, so the
examples target the **live testnet** instead. The trade-off:

- **Pros:** examples run against the real audited contract; no hidden divergence between sandbox + production code paths.
- **Cons:** require network access; example 01 stops before sending so you don't accidentally spend funds.

## Need a fully-offline example?

`03_decode_events.py` is the offline reference — it builds and decodes
canonical event bodies entirely in-process, no network needed.
