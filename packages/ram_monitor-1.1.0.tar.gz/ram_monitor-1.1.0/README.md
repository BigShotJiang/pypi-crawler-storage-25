# RAM Monitor

A lightweight system tray application that monitors RAM usage in the background and sends desktop notifications when memory usage exceeds a configurable threshold.

## Features

- **System tray icon** - Runs silently in background with color-coded indicator
  - 🟢 Green: RAM < 80%
  - 🟠 Orange: RAM 80-90%
  - 🔴 Red: RAM ≥ 90%
- **Desktop notifications** - Alerts when RAM usage exceeds threshold (default: 90%)
- **Enable/Disable toggle** - Control monitoring from tray menu
- **Configurable threshold** - Adjust notification trigger level
- **Auto-start support** - Launch on system boot via desktop entry
- **Cross-platform** - Works on Linux, macOS, and Windows
- **Lightweight** - Minimal CPU and memory footprint

## Installation

### From PyPI (coming soon)
```bash
pip install ram-monitor
ram-monitor
```

### From wheel file
```bash
pip install ram_monitor-1.0.0-py3-none-any.whl
ram-monitor
```

## Requirements

- Python 3.8+
- psutil
- plyer

## Build from source

```bash
pip install build
python -m build
pip install dist/ram_monitor-1.0.0-py3-none-any.whl
```

## Usage

```bash
./run.sh
```

Or run in background directly:
```bash
nohup python3 ram_monitor.py &
```

The app runs in the system tray. Click tray icon to show window, or use "Quit" to exit.

## Auto-start on Linux (Ubuntu/GNOME)

```bash
cp ram-monitor.desktop ~/.config/autostart/
```

## Development

This project uses a `.gitignore` to exclude build artifacts:

```
*.whl
*.gz
__pycache__/
*.pyc
dist/
build/
*.egg-info/
```

Only commit source files to GitHub - users install from PyPI.

## License

MIT