#!/usr/bin/env python3
import os
import sys
import threading
import psutil
import time
from plyer import notification
from pystray import MenuItem as Item
import pystray
from PIL import Image, ImageDraw

class RamMonitorApp:
    def __init__(self):
        self.running = True
        self.enabled = True
        self.threshold = 90
        self.interval = 5
        self.notified = False
        self.tray_icon = None

    def create_icon(self, color='green'):
        image = Image.new('RGB', (64, 64), color='white')
        dc = ImageDraw.Draw(image)
        dc.ellipse([8, 8, 56, 56], fill=color)
        return image

    def create_menu(self):
        return (
            Item('Status: Enabled', None, enabled=False),
            Item('Disable', self.on_toggle),
            Item('Quit', self.on_quit),
        )

    def on_toggle(self, tray, item):
        self.enabled = not self.enabled
        self.notified = False
        label = 'Enable' if self.enabled else 'Disable'
        tray.menu = self.create_menu()

    def on_quit(self, tray, item):
        self.running = False
        tray.stop()

    def update_tray(self):
        if not self.tray_icon:
            return
        ram = psutil.virtual_memory().percent
        if ram >= self.threshold:
            color = '#e74c3c'
        elif ram >= self.threshold - 10:
            color = '#f39c12'
        else:
            color = '#2ecc71'
        self.tray_icon.icon = self.create_icon(color)
        self.tray_icon.title = f'RAM: {ram:.1f}%'

    def notify(self, ram):
        notification.notify(
            title='RAM Monitor',
            message=f'RAM usage is at {ram:.1f}%',
            app_name='RAM Monitor',
            timeout=10
        )

    def monitor_loop(self):
        while self.running:
            if self.enabled:
                ram = psutil.virtual_memory().percent
                if ram >= self.threshold and not self.notified:
                    self.notify(ram)
                    self.notified = True
                elif ram < self.threshold:
                    self.notified = False
            self.update_tray()
            time.sleep(self.interval)

    def run(self):
        self.tray_icon = pystray.Icon(
            'ram_monitor',
            self.create_icon('#2ecc71'),
            'RAM Monitor',
            self.create_menu()
        )
        self.tray_icon.run_detached()
        
        self.monitor_thread = threading.Thread(target=self.monitor_loop, daemon=True)
        self.monitor_thread.start()
        
        while self.running:
            time.sleep(1)
        self.tray_icon.stop()

def main():
    app = RamMonitorApp()
    app.run()

if __name__ == '__main__':
    main()
