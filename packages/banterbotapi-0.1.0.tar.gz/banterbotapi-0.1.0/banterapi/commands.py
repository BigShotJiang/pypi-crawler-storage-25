import inspect
import shlex

from .errors import MissingPermissions
from .permissions import has_perm, describe


class CommandError(Exception):
    pass


class CommandNotFound(CommandError):
    pass


class MissingArgument(CommandError):
    def __init__(self, name):
        self.name = name
        super().__init__(f"missing required argument: {name}")


class BadArgument(CommandError):
    def __init__(self, name, value, expected):
        self.name = name
        self.value = value
        self.expected = expected
        super().__init__(f"argument {name!r} expected {expected}, got {value!r}")


_BOOL_TRUE = {"true", "yes", "y", "1", "on", "enable"}
_BOOL_FALSE = {"false", "no", "n", "0", "off", "disable"}


def _convert(value, annotation, name):
    if annotation is inspect.Parameter.empty or annotation is str:
        return value
    if annotation is int:
        try:
            return int(value)
        except ValueError:
            raise BadArgument(name, value, "integer")
    if annotation is float:
        try:
            return float(value)
        except ValueError:
            raise BadArgument(name, value, "number")
    if annotation is bool:
        v = value.lower()
        if v in _BOOL_TRUE:
            return True
        if v in _BOOL_FALSE:
            return False
        raise BadArgument(name, value, "yes/no")
    return value


class Context:
    def __init__(self, bot, message, invoked_with, args_raw):
        self.bot = bot
        self.message = message
        self.invoked_with = invoked_with
        self.args_raw = args_raw
        self.author = message.author
        self.author_perms = message.author_perms
        self.channel = message.channel
        self.channel_id = message.channel_id
        self.guild_id = message.guild_id

    def has_permissions(self, required):
        return has_perm(self.author_perms, required)

    async def send(self, content="", embed=None):
        return await self.bot.send_message(self.channel_id, content=content, embed=embed)

    async def reply(self, content="", embed=None):
        return await self.message.reply(content=content, embed=embed)

    async def trigger_typing(self):
        await self.bot._http.trigger_typing(self.channel_id)


def has_permissions(*required):
    """Decorator: block command if invoker lacks any of the given perms.

    Usage:
        @bot.command(slash=True)
        @has_permissions(Permissions.KICK_MEMBERS)
        async def kick(ctx, target: str): ...
    """
    required_mask = 0
    for r in required:
        required_mask |= r
    def decorator(fn):
        existing = getattr(fn, "_required_perms", 0)
        fn._required_perms = existing | required_mask
        return fn
    return decorator


class Command:
    def __init__(self, func, name=None, aliases=None, help=None):
        self.callback = func
        self.name = name or func.__name__
        self.aliases = tuple(aliases or ())
        self.help = help or (func.__doc__ or "").strip()
        sig = inspect.signature(func)
        params = list(sig.parameters.values())
        if not params:
            raise ValueError(f"command {self.name!r} must accept a context argument")
        self.params = params[1:]

    def _parse(self, ctx, args_raw):
        try:
            tokens = shlex.split(args_raw) if args_raw else []
        except ValueError:
            tokens = args_raw.split() if args_raw else []

        positional = []
        kwargs = {}
        i = 0
        for p in self.params:
            if p.kind is inspect.Parameter.VAR_POSITIONAL:
                remaining = tokens[i:]
                positional.extend(_convert(t, p.annotation, p.name) for t in remaining)
                i = len(tokens)
                break
            if p.kind is inspect.Parameter.KEYWORD_ONLY:
                remaining = args_raw
                for _ in range(i):
                    remaining = remaining.split(maxsplit=1)[1] if " " in remaining else ""
                remaining = remaining.strip()
                if not remaining and p.default is inspect.Parameter.empty:
                    raise MissingArgument(p.name)
                kwargs[p.name] = remaining if remaining else p.default
                i = len(tokens)
                break
            if i >= len(tokens):
                if p.default is inspect.Parameter.empty:
                    raise MissingArgument(p.name)
                positional.append(p.default)
            else:
                positional.append(_convert(tokens[i], p.annotation, p.name))
                i += 1
        return positional, kwargs

    @property
    def required_perms(self):
        return getattr(self.callback, "_required_perms", 0)

    async def invoke(self, ctx):
        req = self.required_perms
        if req and not has_perm(ctx.author_perms, req):
            missing_bits = req & ~ctx.author_perms
            raise MissingPermissions(describe(missing_bits))
        positional, kwargs = self._parse(ctx, ctx.args_raw)
        result = self.callback(ctx, *positional, **kwargs)
        if inspect.isawaitable(result):
            await result


class CommandRegistry:
    def __init__(self):
        self._commands = {}

    def add(self, command):
        self._commands[command.name] = command
        for alias in command.aliases:
            self._commands[alias] = command

    def get(self, name):
        return self._commands.get(name)

    def all(self):
        seen = set()
        out = []
        for cmd in self._commands.values():
            if cmd.name in seen:
                continue
            seen.add(cmd.name)
            out.append(cmd)
        return out