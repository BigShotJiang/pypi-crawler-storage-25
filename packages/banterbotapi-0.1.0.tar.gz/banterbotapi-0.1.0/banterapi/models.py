import functools
from dataclasses import dataclass, field
from typing import List, Optional


def _requires_client(fn):
    @functools.wraps(fn)
    async def wrapper(self, *args, **kwargs):
        if self._client is None:
            raise RuntimeError(f"{type(self).__name__} detached from client")
        return await fn(self, *args, **kwargs)
    return wrapper


@dataclass
class User:
    id: str
    username: str
    display_name: str = ""
    avatar_id: str = ""
    bot: bool = False

    @classmethod
    def from_dict(cls, d):
        return cls(
            id=d.get("id", ""),
            username=d.get("username", ""),
            display_name=d.get("display_name", ""),
            avatar_id=d.get("avatar", "") or d.get("avatar_id", ""),
            bot=d.get("is_bot", False) or d.get("bot", False),
        )


@dataclass
class Role:
    id: str
    name: str
    color: str = ""
    position: int = 0
    permissions: int = 0

    @classmethod
    def from_dict(cls, d):
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            color=d.get("color", ""),
            position=d.get("position", 0),
            permissions=int(d.get("permissions", 0)),
        )


@dataclass
class Channel:
    id: str
    name: str
    guild_id: str = ""
    type: str = "text"
    description: str = ""

    _client: object = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d, client=None):
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            guild_id=d.get("guild_id", ""),
            type=d.get("type", "text"),
            description=d.get("description", ""),
            _client=client,
        )

    @_requires_client
    async def send(self, content="", embed=None, reply_to=""):
        return await self._client.send_message(self.id, content=content, embed=embed, reply_to=reply_to)

    @_requires_client
    async def trigger_typing(self):
        await self._client._http.trigger_typing(self.id)


@dataclass
class Member:
    user: User
    guild_id: str
    roles: List[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d, guild_id=""):
        return cls(
            user=User.from_dict(d),
            guild_id=guild_id or d.get("guild_id", ""),
            roles=d.get("roles", []) or [],
        )


@dataclass
class Guild:
    id: str
    name: str
    owner_id: str = ""
    icon: str = ""
    description: str = ""
    member_count: int = 0

    @classmethod
    def from_dict(cls, d):
        return cls(
            id=d.get("id", ""),
            name=d.get("name", ""),
            owner_id=d.get("owner_id", ""),
            icon=d.get("icon", ""),
            description=d.get("description", ""),
            member_count=d.get("member_count", 0),
        )


@dataclass
class Message:
    id: str
    channel_id: str
    user_id: str
    content: str
    author: Optional[User] = None
    guild_id: str = ""
    type: str = "message"
    reply_to: str = ""
    edited: bool = False
    created_at: str = ""
    author_perms: int = 0

    _client: object = field(default=None, repr=False, compare=False)

    @classmethod
    def from_dict(cls, d, client=None):
        return cls(
            id=d.get("id", ""),
            channel_id=d.get("channel_id", ""),
            user_id=d.get("user_id", ""),
            content=d.get("content", ""),
            author=User.from_dict(d) if d.get("username") else None,
            guild_id=d.get("guild_id", ""),
            type=d.get("type", "message"),
            reply_to=d.get("reply_to", ""),
            edited=d.get("edited", False),
            created_at=d.get("created_at", ""),
            author_perms=int(d.get("author_perms", 0)),
            _client=client,
        )

    @property
    def channel(self):
        if self._client is None:
            raise RuntimeError("Message detached from client")
        return Channel(id=self.channel_id, name="", guild_id=self.guild_id, _client=self._client)

    @_requires_client
    async def reply(self, content="", embed=None):
        return await self._client.send_message(self.channel_id, content=content, embed=embed, reply_to=self.id)

    @_requires_client
    async def edit(self, content):
        return await self._client._http.edit_message(self.id, content)

    @_requires_client
    async def delete(self):
        return await self._client._http.delete_message(self.id)

    @_requires_client
    async def add_reaction(self, emoji):
        return await self._client._http.add_reaction(self.channel_id, self.id, emoji)