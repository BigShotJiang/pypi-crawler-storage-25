import asyncio
import json

import websockets

from .errors import GatewayError, LoginFailure


OP_DISPATCH = 0
OP_HEARTBEAT = 1
OP_HELLO = 10
OP_HEARTBEAT_ACK = 11


def _headers_kwarg():
    try:
        from inspect import signature
        params = signature(websockets.connect).parameters
    except Exception:
        return "additional_headers"
    if "additional_headers" in params:
        return "additional_headers"
    if "extra_headers" in params:
        return "extra_headers"
    return "additional_headers"


class Gateway:
    def __init__(self, token, intents, ws_url, dispatcher):
        self.token = token
        self.intents = int(intents)
        self.ws_url = ws_url
        self.dispatcher = dispatcher
        self._ws = None
        self._closed = False
        self._heartbeat_task = None
        self._heartbeat_interval = None
        self._last_ack = True

    async def connect(self):
        url = f"{self.ws_url}?intents={self.intents}"
        kwargs = {
            _headers_kwarg(): {
                "Authorization": f"Bot {self.token}",
                "User-Agent": "BanterPy/0.1",
            },
            "ping_interval": 20,
            "ping_timeout": 20,
        }
        try:
            self._ws = await websockets.connect(url, **kwargs)
        except Exception as e:
            name = type(e).__name__
            if name in ("InvalidStatus", "InvalidStatusCode"):
                status = 0
                resp = getattr(e, "response", None)
                if resp is not None:
                    status = getattr(resp, "status_code", 0)
                if status == 0:
                    status = getattr(e, "status_code", 0)
                if status == 401:
                    raise LoginFailure("invalid bot token")
                raise GatewayError(f"connect failed: HTTP {status}")
            raise GatewayError(f"connect failed: {e}")

    async def _heartbeat_loop(self):
        try:
            while not self._closed:
                await asyncio.sleep(self._heartbeat_interval / 1000)
                if not self._last_ack:
                    try:
                        await self._ws.close(code=4000, reason="missed heartbeat ack")
                    except Exception:
                        pass
                    return
                self._last_ack = False
                try:
                    await self._ws.send(json.dumps({"op": OP_HEARTBEAT, "d": None}))
                except Exception:
                    return
        except asyncio.CancelledError:
            return

    async def run(self):
        if self._ws is None:
            raise GatewayError("not connected")
        try:
            async for raw in self._ws:
                if self._closed:
                    return
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                if isinstance(msg, dict) and "op" in msg:
                    op = msg.get("op")
                    if op == OP_HELLO:
                        d = msg.get("d") or {}
                        self._heartbeat_interval = int(d.get("heartbeat_interval", 41250))
                        self._last_ack = True
                        if self._heartbeat_task is None or self._heartbeat_task.done():
                            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                        continue
                    if op == OP_HEARTBEAT_ACK:
                        self._last_ack = True
                        continue
                    if op == OP_DISPATCH:
                        event_type = msg.get("t") or ""
                        payload = msg.get("d") or {}
                        await self.dispatcher(event_type, payload)
                        continue

                event_type = msg.get("type", "")
                payload = msg.get("payload", {})
                await self.dispatcher(event_type, payload)
        except websockets.exceptions.ConnectionClosed:
            return

    async def close(self):
        self._closed = True
        if self._heartbeat_task is not None and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
        if self._ws is None:
            return
        closed = False
        state = getattr(self._ws, "closed", None)
        if state is not None:
            closed = bool(state)
        if not closed:
            try:
                await self._ws.close()
            except Exception:
                pass