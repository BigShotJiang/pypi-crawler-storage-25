import asyncio
import inspect
import logging

from .commands import Command, CommandRegistry, Context, CommandError, CommandNotFound
from .gateway import Gateway
from .http import HTTPClient
from .intents import Intents
from .models import User, Guild, Channel, Member, Message
from .errors import GatewayError

log = logging.getLogger("banterapi")


class Bot:
    def __init__(self, intents=None, base_url="https://banterchat.org", ws_url=None, reconnect=True, command_prefix="!", application_id=""):
        self.intents = intents if intents is not None else Intents.default()
        self.base_url = base_url.rstrip("/")
        self.ws_url = ws_url or self.base_url.replace("http://", "ws://").replace("https://", "wss://") + "/api/bot/ws"
        self.reconnect = reconnect
        self.command_prefix = command_prefix
        self.application_id = application_id
        self.user = None
        self.guilds = {}
        self._http = None
        self._gateway = None
        self._handlers = {}
        self._commands = CommandRegistry()
        self._slash_commands = []
        self._loop = None

    def event(self, fn):
        name = fn.__name__
        if not name.startswith("on_"):
            raise ValueError("event handlers must be named on_<event>")
        self._handlers[name] = fn
        return fn

    def command(self, name=None, aliases=None, help=None, slash=False, description=""):
        def decorator(fn):
            cmd = Command(fn, name=name, aliases=aliases, help=help)
            self._commands.add(cmd)
            if slash:
                self._slash_commands.append({
                    "name": cmd.name,
                    "description": description or cmd.help or cmd.name,
                })
            return fn
        return decorator

    def slash_command(self, name=None, description=""):
        def decorator(fn):
            cmd = Command(fn, name=name, help=description)
            self._commands.add(cmd)
            self._slash_commands.append({
                "name": cmd.name,
                "description": description or cmd.help or cmd.name,
            })
            return fn
        return decorator

    async def sync_commands(self):
        if not self.application_id or not self._slash_commands:
            return 0
        result = await self._http.register_commands(self.application_id, self._slash_commands)
        return result.get("registered", len(self._slash_commands)) if result else 0

    @property
    def commands(self):
        return self._commands.all()

    async def process_commands(self, message):
        if self.user is not None and message.user_id == self.user.id:
            return
        content = message.content or ""
        if not content.startswith(self.command_prefix):
            return
        stripped = content[len(self.command_prefix):]
        if not stripped:
            return
        parts = stripped.split(maxsplit=1)
        name = parts[0]
        args_raw = parts[1] if len(parts) > 1 else ""
        cmd = self._commands.get(name)
        if cmd is None:
            return
        ctx = Context(self, message, name, args_raw)
        try:
            await cmd.invoke(ctx)
        except CommandError as e:
            await self._fire("on_command_error", ctx, e)
        except Exception as e:
            await self._fire("on_command_error", ctx, e)

    async def _dispatch(self, event_type, payload):
        if event_type == "ready":
            user_data = payload.get("user", {})
            self.user = User.from_dict(user_data)
            for g in payload.get("guilds", []) or []:
                guild = Guild.from_dict(g)
                self.guilds[guild.id] = guild
            app_id_from_ready = payload.get("application_id", "")
            if app_id_from_ready and not self.application_id:
                self.application_id = app_id_from_ready
            if self._slash_commands:
                try:
                    await self.sync_commands()
                except Exception as e:
                    log.warning("command sync failed: %s", e)
            await self._fire("on_ready")
            return

        if event_type in ("channel_message", "message_create"):
            msg = Message.from_dict(payload, client=self)
            await self._fire("on_message", msg)
            await self.process_commands(msg)
            return

        if event_type == "message_edit":
            await self._fire("on_message_edit", payload)
            return

        if event_type == "message_delete":
            await self._fire("on_message_delete", payload)
            return

        if event_type == "reaction_add":
            await self._fire("on_reaction_add", payload)
            return

        if event_type == "reaction_remove":
            await self._fire("on_reaction_remove", payload)
            return

        if event_type == "guild_member_add":
            await self._fire("on_member_join", payload)
            return

        if event_type == "guild_member_remove":
            await self._fire("on_member_remove", payload)
            return

        if event_type == "error":
            await self._fire("on_error", payload)
            return

        await self._fire("on_raw_event", event_type, payload)

    async def _fire(self, name, *args):
        handler = self._handlers.get(name)
        if handler is None:
            return
        try:
            result = handler(*args)
            if inspect.isawaitable(result):
                await result
        except Exception:
            log.exception("handler %s raised", name)

    async def send_message(self, channel_id, content="", embed=None, reply_to=""):
        d = await self._http.send_message(channel_id, content=content, embed=embed, reply_to=reply_to)
        return Message.from_dict(d, client=self) if d else None

    async def get_user(self, user_id):
        d = await self._http.get_user(user_id)
        return User.from_dict(d) if d else None

    async def get_guild(self, guild_id):
        d = await self._http.get_guild(guild_id)
        return Guild.from_dict(d) if d else None

    async def get_member(self, guild_id, user_id):
        d = await self._http.get_member(guild_id, user_id)
        return Member.from_dict(d, guild_id=guild_id) if d else None

    async def list_channels(self, guild_id):
        d = await self._http.list_channels(guild_id)
        return [Channel.from_dict(c, client=self) for c in (d or [])]

    async def _start(self, token):
        self._http = HTTPClient(token, base_url=self.base_url)
        self._gateway = Gateway(token, self.intents, self.ws_url, self._dispatch)
        try:
            while True:
                try:
                    await self._gateway.connect()
                    await self._gateway.run()
                except GatewayError as e:
                    log.warning("gateway error: %s", e)
                if not self.reconnect:
                    break
                log.info("reconnecting in 5s")
                await asyncio.sleep(5)
        finally:
            await self._gateway.close()
            await self._http.close()

    def run(self, token):
        try:
            asyncio.run(self._start(token))
        except KeyboardInterrupt:
            pass