import asyncio
from http import HTTPStatus

import aiohttp

from .errors import HTTPException, Forbidden, NotFound, RateLimited, LoginFailure


class HTTPClient:
    def __init__(self, token, base_url="https://banterchat.org"):
        self.token = token
        self.base_url = base_url.rstrip("/")
        self._session = None

    async def _ensure_session(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bot {self.token}",
                    "User-Agent": "BanterPy/0.1",
                }
            )

    async def close(self):
        if self._session and not self._session.closed:
            await self._session.close()

    async def request(self, method, path, json_body=None, params=None):
        await self._ensure_session()
        url = self.base_url + path
        for attempt in range(2):
            async with self._session.request(method, url, json=json_body, params=params) as resp:
                if resp.status == HTTPStatus.NO_CONTENT:
                    return None
                text = await resp.text()
                data = None
                if text:
                    try:
                        data = await resp.json(content_type=None)
                    except Exception:
                        data = {"message": text}
                if HTTPStatus.OK <= resp.status < HTTPStatus.MULTIPLE_CHOICES:
                    return data
                code = (data or {}).get("code", 0)
                message = (data or {}).get("message", text or "unknown error")
                if resp.status == HTTPStatus.TOO_MANY_REQUESTS:
                    retry_after = float(resp.headers.get("X-RateLimit-Reset-After", "1"))
                    if attempt == 0:
                        await asyncio.sleep(retry_after)
                        continue
                    raise RateLimited(resp.status, code, message, retry_after)
                if resp.status == HTTPStatus.UNAUTHORIZED:
                    raise LoginFailure(message)
                if resp.status == HTTPStatus.FORBIDDEN:
                    raise Forbidden(resp.status, code, message)
                if resp.status == HTTPStatus.NOT_FOUND:
                    raise NotFound(resp.status, code, message)
                raise HTTPException(resp.status, code, message)
        raise HTTPException(0, 0, "request failed")

    async def me(self):
        return await self.request("GET", "/api/me")

    async def get_user(self, user_id):
        return await self.request("GET", f"/api/users/{user_id}")

    async def get_guild(self, guild_id):
        return await self.request("GET", f"/api/guilds/{guild_id}")

    async def get_member(self, guild_id, user_id):
        return await self.request("GET", f"/api/guilds/{guild_id}/members/{user_id}")

    async def list_channels(self, guild_id):
        return await self.request("GET", f"/api/guilds/{guild_id}/channels")

    async def list_roles(self, guild_id):
        return await self.request("GET", f"/api/guilds/{guild_id}/roles")

    async def list_messages(self, channel_id, before="", limit=50):
        params = {"limit": limit}
        if before:
            params["before"] = before
        return await self.request("GET", f"/api/channels/{channel_id}/messages", params=params)

    async def send_message(self, channel_id, content="", embed=None, reply_to=""):
        body = {"content": content}
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        if reply_to:
            body["reply_to"] = reply_to
        return await self.request("POST", f"/api/channels/{channel_id}/messages", json_body=body)

    async def edit_message(self, message_id, content):
        return await self.request("PATCH", f"/api/messages/{message_id}", json_body={"content": content})

    async def delete_message(self, message_id):
        return await self.request("DELETE", f"/api/messages/{message_id}")

    async def trigger_typing(self, channel_id):
        return await self.request("POST", f"/api/channels/{channel_id}/typing")

    async def add_reaction(self, channel_id, message_id, emoji):
        return await self.request("PUT", f"/api/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me")

    async def remove_reaction(self, channel_id, message_id, emoji):
        return await self.request("DELETE", f"/api/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me")

    async def add_role(self, guild_id, user_id, role_id):
        return await self.request("PUT", f"/api/guilds/{guild_id}/members/{user_id}/roles/{role_id}")

    async def remove_role(self, guild_id, user_id, role_id):
        return await self.request("DELETE", f"/api/guilds/{guild_id}/members/{user_id}/roles/{role_id}")

    async def kick_member(self, guild_id, user_id):
        return await self.request("POST", f"/api/guilds/{guild_id}/members/{user_id}/kick")

    async def ban_member(self, guild_id, user_id, reason=""):
        return await self.request("POST", f"/api/guilds/{guild_id}/members/{user_id}/ban", json_body={"reason": reason})

    async def unban_member(self, guild_id, user_id):
        return await self.request("DELETE", f"/api/guilds/{guild_id}/members/{user_id}/ban")

    async def register_commands(self, app_id, commands):
        return await self.request("PUT", f"/api/applications/{app_id}/commands", json_body={"commands": commands})