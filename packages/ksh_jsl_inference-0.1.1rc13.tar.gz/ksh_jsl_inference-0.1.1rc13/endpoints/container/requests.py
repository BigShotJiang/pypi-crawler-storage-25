import dataclasses
from uuid import uuid4

from endpoints import Platform
from endpoints.core import ModelInfo
from endpoints.settings import DEFAULT_JOHNSNOWLABS_VERSION


@dataclasses.dataclass
class CommonParams:
    model: ModelInfo
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION
    no_license: bool = False
    store_model: bool = False
    language: str = "en"
    platform: Platform = Platform.SAGEMAKER


@dataclasses.dataclass(init=False)
class GenerateDockerFilesRequest(CommonParams):
    output_dir: str = f"/tmp/{uuid4()}"

    def __init__(self, **kwargs):
        names = set([f.name for f in dataclasses.fields(self)])
        for k, v in kwargs.items():
            if k in names:
                setattr(self, k, v)
