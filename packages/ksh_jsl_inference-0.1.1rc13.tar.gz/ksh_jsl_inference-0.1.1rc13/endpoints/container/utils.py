import os
import re
import subprocess
from typing import Optional

from endpoints.__about__ import __version__
from endpoints.core import ModelInfo, ModelRegistry
from endpoints.core.models import BaseInferenceModel
from endpoints.johnsnowlabs import find_license_from_jsl_home, is_license_valid
from endpoints.logging import logger
from endpoints.server.serve import get_requirements
from endpoints.settings import PACKAGE_NAME
from endpoints.utils import (
    copy_and_replace,
    generate_license_file,
)

from .requests import GenerateDockerFilesRequest

current_dir = os.path.dirname(__file__)


def _get_requirements_for_docker_image(req: GenerateDockerFilesRequest):
    """Helper function that generates requirements based on the platform and inference model."""

    requirements = [f"{PACKAGE_NAME}=={__version__}"]

    inference_obj = None
    if isinstance(req.model.inference_provider, BaseInferenceModel):
        inference_obj = req.model.inference_provider
    requirements.extend(
        get_requirements(req.platform, req.johnsnowlabs_version, inference_obj)
    )

    return requirements


def __generate_requirements_file(req):
    requirements = _get_requirements_for_docker_image(req)

    logger.debug(f"Generating requirements file in: {req.output_dir}")
    with open(f"{req.output_dir}/requirements.txt", "w+") as f:
        f.write("\n".join(requirements))


def _get_env_setup_command(req: GenerateDockerFilesRequest):

    setup_container_args = {
        "model_id": f"'{req.model.id}'",
        "language": f"'{req.language}'",
        "johnsnowlabs_version": f"'{req.johnsnowlabs_version}'",
        "store_license": not req.no_license,
        "store_model": req.store_model,
    }
    args_string = ",".join(
        [f"{key}={value}" for key, value in setup_container_args.items()]
    )
    container_serve_command = f"S({args_string})"
    setup_env_command = (
        "python3 -c "
        '"from endpoints.container import setup_container_env as S;'
        f'{container_serve_command}"'
    )
    return setup_env_command


def __get_entrypoint_command(model: ModelInfo):
    return (
        "import sys;"
        f"from endpoints import container as C;"
        f"C._init(sys.argv[1], model_id='{model.id}', language='{model.language}')"
    )


def _generate_docker_files_v1(req: GenerateDockerFilesRequest):

    __generate_requirements_file(req)

    generate_license_file(req.output_dir)
    setup_env_command = _get_env_setup_command(req)

    entrypoint_command = __get_entrypoint_command(req.model)

    copy_and_replace(
        f"{current_dir}/Dockerfile",
        f"{req.output_dir}/Dockerfile",
        {
            "{{STORE_LICENSE}}": str(not req.no_license),
            "{{STORE_MODEL}}": str(req.store_model),
            "{{LANGUAGE}}": req.language,
            "{{ENTRYPOINT}}": f'ENTRYPOINT ["python3", "-c", "{entrypoint_command}"]',
            "{{ENVIRONMENT_VARIABLES}}": f"ENV PLATFORM={req.platform.value}",
            "{{SETUP_ENVIRONMENT}}": setup_env_command,
        },
    )


def _generate_docker_files(req: GenerateDockerFilesRequest):
    """Common logic for generating Docker files across different recipes."""

    os.makedirs(req.output_dir, exist_ok=True)
    _generate_docker_files_v1(req)

    return req.output_dir


def generate_docker_files(model_id: str, language: str, **kwargs) -> str:
    """
    Generates Docker files to serve JSL model.
    :param str output_dir: The output directory to store the generated files. If not provided, a temporary directory is used.
    :param str model: The model to generate Docker files for (Required).
    :param str johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION
    :param bool no_license: Indicate whether to include license in the docker image. Default: False
    :param bool store_model: Indicate whether to include model in the docker image. Default: False
    :param str language: The language of the model. Default: 'en'
    :param BaseInferenceModel inference_model: The inference model to use.
    :param Platform platform: Platform to target. Default: Platform.SAGEMAKER
    :return: The path to the directory containing the generated docker files

    .. code-block:: python
        :caption: Example

            from endpoints.container import generate_docker_files

            generate_docker_files(
                model="clinical_deidentification",
                johnsnowlabs_version="5.5.0",
                store_license=True,
                store_model=True,
                language="en"
            )
    """
    model = ModelRegistry.find(model_id=model_id, language=language)

    logger.info(f"Generating Docker files for model: {model_id}")

    req = GenerateDockerFilesRequest(model=model, **kwargs)

    output_dir = _generate_docker_files(req)

    logger.info(f"Docker files generated in: {output_dir}")
    return output_dir


def build_docker_image(
    image_name: str,
    license_path: Optional[str],
    build_context_dir: str,
    no_cache: bool = False,
    image_tag: str = "latest",
    **kwargs,
):
    """Builds a Docker image using the specified build context directory"""
    if license_path and is_license_valid(license_path):
        license_to_use = license_path
    else:
        license_to_use = find_license_from_jsl_home()

    build_command = [
        "docker",
        "build",
        "--platform=linux/amd64",
        "--provenance=false",
    ]

    if no_cache:
        build_command.append("--no-cache")

    build_command.extend(
        [
            "--secret",
            f"id=license,src={license_to_use}",
            "-t",
            f"{image_name}:{image_tag}",
            build_context_dir,
        ]
    )

    logger.info(f"Executing Docker build command: {' '.join(build_command)}")

    subprocess.run(build_command, check=True)
    logger.info(f"Docker image '{image_name}:{image_tag}' built successfully!")


def is_valid_output_dir(directory: str) -> bool:
    """
    Validates if the specified directory contains the required Docker files.

    Args:
        directory (str): Path to the directory to validate.

    Returns:
        bool: True if the directory contains the required files, False otherwise.
    """
    if not directory or not os.path.isdir(directory):
        return False

    required_files = ["Dockerfile", "requirements.txt"]
    return all(os.path.isfile(os.path.join(directory, file)) for file in required_files)


def install_johnsnowlabs_from_docker_secret():
    from johnsnowlabs import nlp

    nlp.install(
        json_license_path="/run/secrets/license",
        browser_login=False,
        force_browser=False,
    )


def validate_docker_image_name(image_name: str) -> bool:
    """
    Validates a Docker image name according to Docker specifications.
    Rules:
    - 1-255 characters total
    - Can contain lowercase letters, digits, separated by slashes
    - Each component must start/end with alphanumeric
    - Allowed characters: a-z, 0-9, ._- (components), / (separator)
    """
    if len(image_name) < 1 or len(image_name) > 255:
        return False

    components = image_name.split("/")

    component_pattern = r"^[a-z0-9]+(?:[._-][a-z0-9]+)*$"
    for comp in components:
        if not re.match(component_pattern, comp):
            return False

    return True


def validate_image_tag(image_tag: str) -> bool:
    """
    Validates a Docker image tag according to Docker specifications.
    Rules:
    - 1-128 characters
    - Must start with alphanumeric
    - Allowed characters: A-Za-z0-9._-
    """
    pattern = r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$"
    return bool(re.match(pattern, image_tag))


def format_docker_image_name(image_name: str) -> str:
    """
    Formats a Docker image name to be specification-compliant.
    Converts to lowercase, replaces invalid characters with '-',
    and ensures valid component structure.
    """
    components = image_name.split("/")
    formatted_components = []

    for comp in components:
        formatted = re.sub(r"[^a-z0-9._-]", "-", comp.lower())

        formatted = re.sub(r"^[^a-z0-9]+", "", formatted)
        formatted = re.sub(r"[^a-z0-9]+$", "", formatted)

        if not formatted:
            formatted = "invalid"

        formatted_components.append(formatted)

    formatted_name = "/".join(formatted_components)

    if not validate_docker_image_name(formatted_name):
        raise ValueError(
            f"Invalid Docker image name after formatting: {formatted_name}"
        )

    return formatted_name


def format_image_tag(image_tag: str) -> str:
    """
    Formats a Docker image tag to be specification-compliant.
    Preserves case, replaces invalid characters with '.',
    and ensures valid structure.
    """
    formatted_tag = re.sub(r"[^A-Za-z0-9._-]", ".", image_tag)

    formatted_tag = re.sub(r"^[^A-Za-z0-9]+", "", formatted_tag)

    formatted_tag = formatted_tag[:128]

    formatted_tag = re.sub(r"[^A-Za-z0-9]+$", "", formatted_tag)

    if not formatted_tag:
        formatted_tag = "latest"

    if not validate_image_tag(formatted_tag):
        raise ValueError(f"Invalid Docker image tag after formatting: {formatted_tag}")

    return formatted_tag
