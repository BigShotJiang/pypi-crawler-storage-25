"""
Module for serving inference model to Docker Container
"""

from endpoints.core import ModelRegistry
from endpoints.server import serve
from endpoints.settings import TARGET_PLATFORM

from .setup import setup_container_env
from .utils import (
    build_docker_image,
    format_docker_image_name,
    format_image_tag,
    generate_docker_files,
    validate_docker_image_name,
    validate_image_tag,
)


# Default entrypoint for the Docker containers
def _init(command, model_id: str, language: str):
    # For Sagemaker, serve and train are the possible commands
    if command == "serve":
        model = ModelRegistry.find(model_id, language)
        serve(
            model=model,
            platform=TARGET_PLATFORM,
        )
    else:
        raise NotImplementedError("Command not implemented")


__all__ = [
    "build_docker_image",
    "generate_docker_files",
    "setup_container_env",
    "format_image_tag",
    "format_docker_image_name",
    "validate_docker_image_name",
    "validate_image_tag",
]
