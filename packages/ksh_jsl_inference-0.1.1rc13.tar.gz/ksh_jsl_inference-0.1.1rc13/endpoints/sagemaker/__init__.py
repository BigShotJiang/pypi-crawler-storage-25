import os
import uuid
from typing import Optional

from endpoints import Platform, container
from endpoints.container import build_docker_image as _build_docker_image
from endpoints.settings import HOME_DIR


def get_default_docker_file_location() -> str:
    return os.path.join(
        HOME_DIR, ".jsl_inference", Platform.SAGEMAKER, str(uuid.uuid4())
    )


def generate_docker_files(model_id: str, output_dir: Optional[str] = None, **kwargs):
    """Generates Docker files for the specified model for Sagemaker."""

    return container.generate_docker_files(
        model_id=model_id,
        platform=Platform.SAGEMAKER,
        store_model=False,
        output_dir=output_dir or get_default_docker_file_location(),
        **kwargs,
    )


def build_docker_image(model_id: str, **kwargs):
    docker_files_location = generate_docker_files(model_id, **kwargs)
    _build_docker_image(build_context_dir=docker_files_location, **kwargs)
