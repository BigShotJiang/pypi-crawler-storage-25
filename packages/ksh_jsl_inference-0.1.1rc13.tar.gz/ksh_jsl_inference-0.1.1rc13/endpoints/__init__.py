"""JSL Inference Module"""

from enum import Enum


class Recipe(str, Enum):
    HEALTHCARE_NLP = "healthcare_nlp"
    VISUAL_NLP = "visual_nlp"
    LLM = "llm"
    CHROMADB_RESOLVER = "chromadb_resolver"


class Platform(str, Enum):
    SAGEMAKER = "sagemaker"
    SNOWFLAKE = "snowflake"

    def get_python_requirements(self):
        if self == Platform.SNOWFLAKE:
            return ["snowflake-snowpark-python"]
        return []


class JslInferenceException(Exception):
    """Exception for JSL Inference errors"""

    pass
