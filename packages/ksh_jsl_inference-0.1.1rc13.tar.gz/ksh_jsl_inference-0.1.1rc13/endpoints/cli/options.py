import click


def common_options(f):
    """
    A decorator to add common CLI options for SageMaker commands, including:
    - Model argument (required).
    - John Snow Labs version.
    - Flags to store license and model in the Docker image.
    """
    f = click.argument("model_id")(f)
    f = click.option(
        "--johnsnowlabs-version",
        default="5.5.0",
        help="Version of the John Snow Labs library (default: 5.5.0)",
    )(f)
    f = click.option(
        "--language",
        default="en",
        help="Language of the model (default: en)",
    )(f)
    f = click.option(
        "--no-license",
        is_flag=True,
        default=False,
        show_default=True,
        help="Do not include the license file in the Docker image. Default: False",
    )(f)

    return f
