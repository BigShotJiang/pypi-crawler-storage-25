import uuid
from typing import Optional

import endpoints
from endpoints import Platform, container
from endpoints.container import utils
from endpoints.settings import HOME_DIR

from .components import *


def get_default_docker_file_location() -> str:
    return os.path.join(
        HOME_DIR, ".jsl_inference", Platform.SNOWFLAKE, str(uuid.uuid4())
    )


def generate_docker_files(model_id: str, output_dir: Optional[str] = None, **kwargs):
    """
    Generates Docker files for the specified model for Snowflake.
    """

    return container.generate_docker_files(
        model_id=model_id,
        platform=endpoints.Platform.SNOWFLAKE,
        store_model=True,
        output_dir=output_dir or get_default_docker_file_location(),
        **kwargs,
    )


def build_docker_image(model_id: str, **kwargs):
    image_name = kwargs.pop("image_name") or model_id
    docker_files_location = generate_docker_files(model_id, **kwargs)
    utils.build_docker_image(
        image_name=image_name, build_context_dir=docker_files_location, **kwargs
    )
