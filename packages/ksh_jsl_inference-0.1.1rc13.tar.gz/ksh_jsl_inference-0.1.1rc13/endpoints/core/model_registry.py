from dataclasses import dataclass
from typing import Dict, List, Optional

from endpoints import Recipe
from endpoints.core.exceptions import ModelRegistryException
from endpoints.core.models import BaseInferenceModel
from endpoints.johnsnowlabs.providers import (
    ChromaDbResolverInferenceProvider,
    DeidentificationInferenceProvider,
    MedNlpInferenceProvider,
)


@dataclass
class ModelInfo:
    id: str
    inference_provider: BaseInferenceModel
    language: str = "en"  # en, de, gr
    recipe: Recipe = Recipe.HEALTHCARE_NLP

    @staticmethod
    def generate_key(model_id: str, language: str) -> str:
        """Generate a key from model_id and language.

        Args:
            model_id: The model identifier
            language: The language code

        Returns:
            Base64-encoded key safe for S3 keys
        """
        import base64

        # Use base64 encoding to make it safe for S3 keys
        key_string = f"{model_id}##{language}"
        return base64.b64encode(key_string.encode("utf-8")).decode("ascii")

    @property
    def key(self) -> str:
        return self.generate_key(self.id, self.language)


class ModelRegistry:
    """Global registry for managing all available ModelInfo instances."""

    _key_to_models: Dict[str, ModelInfo] = {}
    _default_medical_nlp_provider = MedNlpInferenceProvider()

    @staticmethod
    def register(
        model_id: str,
        language: str = "en",
        inference_provider: Optional[BaseInferenceModel] = None,
        recipe: Recipe = Recipe.HEALTHCARE_NLP,
    ) -> None:
        """Register a new ModelInfo instance in the registry.

        Args:
            model_info: The ModelInfo instance to register
        """
        model_info = ModelInfo(
            id=model_id,
            language=language,
            inference_provider=inference_provider
            or ModelRegistry._default_medical_nlp_provider,
            recipe=recipe,
        )
        ModelRegistry._key_to_models[model_info.key] = model_info

    @staticmethod
    def get_by_key(key: str) -> ModelInfo:
        return ModelRegistry._key_to_models[key]

    @staticmethod
    def find(model_id: str, language: str = "en") -> ModelInfo:
        """Retrieve a ModelInfo by its ID.

        Args:
            model_id: The ID of the model to retrieve

        Returns:
            The ModelInfo instance if found, None otherwise
        """
        key = ModelInfo.generate_key(model_id, language)
        try:
            return ModelRegistry.get_by_key(key)
        except KeyError:
            raise ModelRegistryException(f"The requested model is not registered.")

    @staticmethod
    def get_by_recipe(recipe: Recipe) -> List[ModelInfo]:
        """Retrieve all ModelInfo instances for a specific recipe.

        Args:
            recipe: The recipe to filter by

        Returns:
            List of ModelInfo instances matching the recipe
        """
        return [
            model
            for model in ModelRegistry._key_to_models.values()
            if model.recipe == recipe
        ]

    @staticmethod
    def get_all() -> List[ModelInfo]:
        """Get all registered ModelInfo instances.

        Returns:
            List of all registered ModelInfo instances
        """
        return list(ModelRegistry._key_to_models.values())

    @staticmethod
    def count() -> int:
        """Get the number of registered models.

        Returns:
            The number of registered ModelInfo instances
        """
        return len(ModelRegistry._key_to_models)


BASE_MEDICAL_NLP_INFERENCE = MedNlpInferenceProvider()

HEALTHCARE_MODELS = []
for model in HEALTHCARE_MODELS:
    ModelRegistry.register(
        model_id=model,
        language="en",
    )


# Clinical Deidentification
ModelRegistry.register(
    model_id="clinical_deidentification_docwise_wip",
    language="en",
    inference_provider=DeidentificationInferenceProvider(),
)

# Chroma VDB Resolvers
ModelRegistry.register(
    model_id="rxnorm",
    language="en",
    inference_provider=ChromaDbResolverInferenceProvider(),
    recipe=Recipe.CHROMADB_RESOLVER,
)
