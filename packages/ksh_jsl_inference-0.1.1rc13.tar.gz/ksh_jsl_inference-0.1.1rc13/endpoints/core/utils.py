from endpoints import Recipe

from .model_registry import ModelInfo


def download_model(model: ModelInfo):
    """Downloads a model based on its info"""
    from endpoints.johnsnowlabs.utils import (
        download_chromadb_resolver_model,
        download_healthcare_model,
    )

    if model.recipe == Recipe.HEALTHCARE_NLP:
        return download_healthcare_model(model_ref=model.id, language=model.language)

    elif model.recipe == Recipe.CHROMADB_RESOLVER:
        return download_chromadb_resolver_model(concept=model.id)
    else:
        raise NotImplementedError("Only healthcare_nlp is supported at the moment")
