# endpoints


## Development

### Pre-requisites

- Python 3.8 or higher
- Docker
- A valid JSL License

### Setup
```bash
 pip install -r dev-requirements.txt
```

### CLI


To install the package locally, run the following command from the root of the repository:

```bash
 cd endpoints
 python3 -m pip install -e .
```

This will install the `jsl_inference` CLI command defined in `pyproject.toml`.

Alternatively, if you haven't defined the `jsl_inference` script in `pyproject.toml` or `setup.py`, you can run the CLI directly:

```bash
 python -m endpoints.cli
```

## Docs

Documentation is served using MkDocs. To view the documentation, run:

```bash
make docs
```
This will start a local development server and serve the documentation at `http://127.0.0.1:8000/`. The server will automatically reload when documentation files are modified.

### Testing

Tests are run via the Makefile which handles virtual environment setup and dependency installation automatically.

To run the tests, use one of the following commands:

```bash
# Run tests (installs dependencies automatically)
make test

# Run tests with verbose output
make test-verbose

# Run tests with coverage report
make test-coverage
```

Alternatively, if you prefer to manage dependencies manually:
```bash
pip install -e .[dev]
pytest
```

### Toolkit

To get some information on the available models and its details, use this helper command

<small>Please make sure to install dependencies before. See tools/requirements.txt </small>
```bash
 python tools/models_info.py
```
You can also refer the help for this toolkit

```bash
 python tools/models_info.py --help
```




## Databricks Development (Needs to fixed)

see `databricks_tests.py` 
1. Start up a Databricks Cluster producer. Once Started you must **manually enable it to Unity Catalog**
2. Submit publisher job
3. Once completed, need to go to provider UI and publish the model to either private or public exchange
4. Once published, **you must manually import the listing on consumer end form the UI and accept the Terms of usage**. Then model can be tested via consumer jobs

