"""S-SONDO inference and finetuning module.

Provides `get_ssondo()` to load a trained student model and return an
nn.Module ready for inference or downstream finetuning on raw audio.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from ssondo.preprocess import SliceAudio, LogMelSpectrogram
from ssondo.models.MobileNetV3.model import get_model as get_mobilenet
from ssondo.models.dymn.model import get_model as get_dymn
from ssondo.models.ERes2Net.model import ERes2Net
from ssondo.models.model_utils import (
    LinearClassifer,
    MLPClassifer,
    RNNClassifer,
    AttentionRNNClassifer,
    ModelWrapper,
)

HF_REPO_ID = "mohammedali2501/ssondo"

AVAILABLE_MODELS = {
    "matpac-mobilenetv3": {
        "filename": "matpac_mobilenetv3.ckpt",
        "description": "MobileNetV3 distilled from MATPAC++ (cosine similarity, 50 clusters)",
    },
    "matpac-dymn": {
        "filename": "matpac_dymn.ckpt",
        "description": "DyMN distilled from MATPAC++ (cosine similarity, 50 clusters)",
    },
    "matpac-eres2net": {
        "filename": "matpac_eres2net.ckpt",
        "description": "ERes2Net distilled from MATPAC++ (cosine similarity, 50 clusters)",
    },
    "m2d-mobilenetv3": {
        "filename": "m2d_mobilenetv3.ckpt",
        "description": "MobileNetV3 distilled from M2D (cosine similarity, 50 clusters)",
    },
    "m2d-dymn": {
        "filename": "m2d_dymn.ckpt",
        "description": "DyMN distilled from M2D (cosine similarity, 50 clusters)",
    },
    "m2d-eres2net": {
        "filename": "m2d_eres2net.ckpt",
        "description": "ERes2Net distilled from M2D (cosine similarity, 50 clusters)",
    },
}

PRETRAINED_HEADS = {
    "gtzan": {"filename": "heads/gtzan.pth", "n_classes": 10, "description": "Music genre (10 classes)"},
    "openmic": {"filename": "heads/openmic.pth", "n_classes": 20, "description": "Instrument recognition (20 classes)"},
    "nsynth": {"filename": "heads/nsynth.pth", "n_classes": 11, "description": "Instrument family (11 classes)"},
    "esc50": {"filename": "heads/esc50.pth", "n_classes": 50, "description": "Environmental sound (50 classes)"},
    "us8k": {"filename": "heads/us8k.pth", "n_classes": 10, "description": "Urban sound (10 classes)"},
    "magna-tag-a-tune": {"filename": "heads/magna-tag-a-tune.pth", "n_classes": 50, "description": "Music auto-tagging (50 tags)"},
    "fsd50k": {"filename": "heads/fsd50k.pth", "n_classes": 200, "description": "Sound events (200 classes)"},
}


def list_models() -> dict[str, str]:
    """List available pretrained S-SONDO models.

    Returns
    -------
    dict[str, str]
        Mapping of model name to description.

    Example
    -------
    >>> from ssondo import list_models
    >>> for name, desc in list_models().items():
    ...     print(f"{name}: {desc}")
    """
    return {name: info["description"] for name, info in AVAILABLE_MODELS.items()}


def list_heads() -> dict[str, str]:
    """List available pretrained classification heads.

    These are linear probes trained on the matpac-mobilenetv3 backbone
    across 7 standard audio benchmarks.

    Returns
    -------
    dict[str, str]
        Mapping of head name to description.

    Example
    -------
    >>> from ssondo import list_heads
    >>> for name, desc in list_heads().items():
    ...     print(f"{name}: {desc}")
    """
    return {name: info["description"] for name, info in PRETRAINED_HEADS.items()}


def _resolve_checkpoint(checkpoint: str, device: str = "cpu") -> dict:
    """Resolve a checkpoint path or model name to a loaded checkpoint dict."""
    import os

    if os.path.isfile(checkpoint):
        return torch.load(checkpoint, map_location=device, weights_only=False)

    if checkpoint in AVAILABLE_MODELS:
        from huggingface_hub import hf_hub_download

        local_path = hf_hub_download(
            repo_id=HF_REPO_ID,
            filename=AVAILABLE_MODELS[checkpoint]["filename"],
        )
        return torch.load(local_path, map_location=device, weights_only=False)

    raise ValueError(
        f"'{checkpoint}' is not a valid file path or model name. "
        f"Available models: {list(AVAILABLE_MODELS.keys())}"
    )


def _build_student_model(conf: dict) -> ModelWrapper:
    """Build the student model from a training config dict."""
    model_name = conf["student_model"]["model_name"]

    if "mn" in model_name and "dy" not in model_name:
        model = get_mobilenet(
            pretrained_name=None,
            width_mult=conf["student_model"]["width_mult"],
            reduced_tail=conf["student_model"]["reduced_tail"],
            dilated=conf["student_model"]["dilated"],
            strides=conf["student_model"]["strides"],
            relu_only=conf["student_model"]["relu_only"],
            input_dim_f=conf["student_model"]["input_dim_f"],
            input_dim_t=conf["student_model"]["input_dim_t"],
            se_dims=conf["student_model"]["se_dims"],
            se_agg=conf["student_model"]["se_agg"],
            se_r=conf["student_model"]["se_r"],
        )
    elif "dy" in model_name:
        model = get_dymn(
            pretrained_name=None,
            width_mult=conf["student_model"]["width_mult"],
            strides=conf["student_model"]["strides"],
            pretrain_final_temp=conf["student_model"].get("pretrain_final_temp", 1.0),
        )
    else:
        model = ERes2Net(
            m_channels=conf["student_model"]["m_channels"],
            feat_dim=conf["student_model"]["feat_dim"],
            num_blocks=conf["student_model"]["num_blocks"],
            pooling_func=conf["student_model"]["pooling_func"],
            add_layer=conf["student_model"]["add_layer"],
        )

    head_type = conf["classification_head"]["head_type"]

    if head_type == "mlp":
        try:
            hidden_features_size = model.last_channel
        except AttributeError:
            hidden_features_size = conf["classification_head"]["hidden_features_size"]
        class_head = MLPClassifer(
            emb_size=model.emb_size,
            n_classes=conf["classification_head"]["n_classes"],
            hidden_features_size=hidden_features_size,
            pooling=conf["classification_head"]["pooling"],
            activation_att=conf["classification_head"]["activation_att"],
            last_activation=conf["classification_head"]["last_activation"],
        )
    elif head_type in ["lstm", "gru", "rnn"]:
        class_head = RNNClassifer(
            rnn_type=head_type,
            emb_size=model.emb_size,
            hidden_size=conf["classification_head"]["hidden_size"],
            n_classes=conf["classification_head"]["n_classes"],
            num_layers=conf["classification_head"]["num_layers"],
            bidirectional=conf["classification_head"]["bidirectional"],
            n_last_elements=conf["classification_head"]["n_last_elements"],
            last_activation=conf["classification_head"]["last_activation"],
        )
    elif head_type in ["attention_lstm", "attention_gru", "attention_rnn"]:
        rnn_type = head_type.split("_")[1]
        class_head = AttentionRNNClassifer(
            rnn_type=rnn_type,
            emb_size=model.emb_size,
            hidden_size=conf["classification_head"]["hidden_size"],
            n_classes=conf["classification_head"]["n_classes"],
            num_layers=conf["classification_head"]["num_layers"],
            bidirectional=conf["classification_head"]["bidirectional"],
            n_last_elements=conf["classification_head"]["n_last_elements"],
            last_activation=conf["classification_head"]["last_activation"],
        )
    else:
        class_head = LinearClassifer(
            emb_size=model.emb_size,
            n_classes=conf["classification_head"]["n_classes"],
            pooling=conf["classification_head"]["pooling"],
            activation_att=conf["classification_head"]["activation_att"],
            last_activation=conf["classification_head"]["last_activation"],
        )

    return ModelWrapper(model=model, classification_head=class_head)


def _build_head(
    head: str,
    emb_dim: int,
    n_classes: int | None,
    hidden_sizes: list[int] | None,
    device: str = "cpu",
) -> nn.Module:
    """Build a classification head to attach on top of the backbone."""
    if head in PRETRAINED_HEADS:
        from huggingface_hub import hf_hub_download

        info = PRETRAINED_HEADS[head]
        local_path = hf_hub_download(
            repo_id=HF_REPO_ID, filename=info["filename"]
        )
        state = torch.load(local_path, map_location=device, weights_only=False)
        linear = nn.Linear(emb_dim, info["n_classes"])
        linear.load_state_dict({
            "weight": state["probe.linear_probe.weight"],
            "bias": state["probe.linear_probe.bias"],
        })
        return linear

    if head == "linear":
        return nn.Linear(emb_dim, n_classes)

    if head == "mlp":
        if hidden_sizes is None:
            hidden_sizes = [512]
        layers: list[nn.Module] = []
        in_dim = emb_dim
        for h in hidden_sizes:
            layers.extend([nn.Linear(in_dim, h), nn.ReLU()])
            in_dim = h
        layers.append(nn.Linear(in_dim, n_classes))
        return nn.Sequential(*layers)

    valid = ["linear", "mlp"] + list(PRETRAINED_HEADS.keys())
    raise ValueError(f"head must be one of {valid}, got '{head}'")


class SsondoWrapper(nn.Module):
    """End-to-end wrapper for S-SONDO student models.

    Supports inference, embedding extraction, and downstream finetuning
    with frozen backbone.
    """

    def __init__(self, student_model, slicer, logmel, return_logits=False, head=None):
        super().__init__()
        self.student_model = student_model
        self.slicer = slicer
        self.logmel = logmel
        self.return_logits = return_logits
        self.head = head

    @property
    def backbone(self) -> nn.Module:
        """The backbone feature extractor (e.g., MobileNetV3)."""
        return self.student_model.model

    @property
    def embedding_dim(self) -> int:
        """Dimensionality of the backbone embeddings."""
        return self.student_model.model.emb_size

    def preprocess(self, x: torch.Tensor) -> torch.Tensor:
        """Convert raw audio to log-mel spectrogram segments.

        Parameters
        ----------
        x : torch.Tensor
            Raw mono audio of shape ``(batch, n_samples)`` or ``(n_samples,)``.

        Returns
        -------
        torch.Tensor
            Log-mel spectrogram of shape ``(batch, n_segments, n_mels, time_frames)``.
        """
        if x.ndim == 1:
            x = x.unsqueeze(0)
        x = x.unsqueeze(1)
        x = self.slicer(x)
        x = self.logmel(x)
        return x

    def get_embeddings(self, x: torch.Tensor) -> torch.Tensor:
        """Extract embeddings from raw audio (no classification head).

        Runs the backbone only and mean-pools over segments to produce
        a single embedding vector per audio clip.

        Parameters
        ----------
        x : torch.Tensor
            Raw mono audio at the expected sample rate (typically 32 kHz).
            Shape: ``(batch, n_samples)`` or ``(n_samples,)``.

        Returns
        -------
        torch.Tensor
            Embeddings of shape ``(batch, embedding_dim)``.

        Example
        -------
        >>> model = get_ssondo("matpac-mobilenetv3")
        >>> emb = model.get_embeddings(audio)  # (batch, 960)
        """
        x = self.preprocess(x)
        # backbone returns (batch, n_segments, emb_dim)
        emb = self.student_model.model(x)
        # mean-pool over segments
        if emb.ndim == 3:
            emb = emb.mean(dim=1)
        return emb

    def freeze_backbone(self) -> None:
        """Freeze all backbone parameters (for linear probing / finetuning).

        After calling this, only newly added layers (e.g., a linear
        classifier) will be updated during training. The preprocessing
        layers are also frozen.

        Example
        -------
        >>> model = get_ssondo("matpac-mobilenetv3")
        >>> model.freeze_backbone()
        >>> # Only a new head's parameters will be trainable
        """
        for param in self.student_model.model.parameters():
            param.requires_grad = False
        for param in self.slicer.parameters():
            param.requires_grad = False
        for param in self.logmel.parameters():
            param.requires_grad = False

    def unfreeze_backbone(self) -> None:
        """Unfreeze all backbone parameters (for full finetuning)."""
        for param in self.student_model.model.parameters():
            param.requires_grad = True

    def forward(
        self, x: torch.Tensor
    ) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """Run inference on raw audio.

        Parameters
        ----------
        x : torch.Tensor
            Raw mono audio at the expected sample rate (typically 32 kHz).
            Shape: ``(batch, n_samples)`` or ``(n_samples,)``.

        Returns
        -------
        torch.Tensor or tuple[torch.Tensor, torch.Tensor]
            If a classification ``head`` was provided: logits of shape
            ``(batch, n_classes)``, or ``(logits, embeddings)`` when
            ``return_logits=True``.

            Otherwise: embeddings of shape ``(batch, n_segments, emb_size)``,
            or ``(embeddings, logits)`` when ``return_logits=True``.
        """
        if self.head is not None:
            emb = self.get_embeddings(x)
            logits = self.head(emb)
            if self.return_logits:
                return logits, emb
            return logits

        x = self.preprocess(x)
        logits, embeddings = self.student_model(x)
        if self.return_logits:
            return embeddings, logits
        return embeddings


def get_ssondo(
    checkpoint: str = "matpac-mobilenetv3",
    head: str | None = None,
    n_classes: int | None = None,
    hidden_sizes: list[int] | None = None,
    return_logits: bool = False,
    device: str = "cpu",
) -> SsondoWrapper:
    """Load a pretrained S-SONDO model ready for inference or finetuning.

    Parameters
    ----------
    checkpoint : str, optional
        Either a model name (e.g., ``"matpac-mobilenetv3"``) which
        auto-downloads from Hugging Face Hub, or a local path to a
        ``.ckpt`` file. Defaults to ``"matpac-mobilenetv3"``.
    head : str or None, optional
        Classification head to attach on top of the backbone.
        ``"linear"`` for a single ``nn.Linear`` layer, ``"mlp"`` for a
        multi-layer perceptron, or a pretrained head name (e.g.,
        ``"esc50"``, ``"gtzan"``) to load a ready-to-use classifier.
        Use ``list_heads()`` to see available pretrained heads.
        ``None`` (default) returns raw embeddings.
    n_classes : int or None, optional
        Number of output classes. Required when ``head`` is ``"linear"``
        or ``"mlp"``. Ignored for pretrained heads.
    hidden_sizes : list[int] or None, optional
        Hidden layer sizes for the MLP head (e.g., ``[512, 256]``).
        Only used when ``head="mlp"``. Defaults to ``[512]``.
    return_logits : bool, optional
        If True and no ``head``: forward returns ``(embeddings, logits)``.
        If True and ``head`` is set: forward returns ``(logits, embeddings)``.
    device : str, optional
        Device to load the model on (default: ``"cpu"``).

    Returns
    -------
    SsondoWrapper
        An ``nn.Module`` in eval mode.

    Examples
    --------
    Inference (default model):

    >>> model = get_ssondo()
    >>> embeddings = model(audio)

    Pretrained ESC-50 classifier:

    >>> model = get_ssondo(head="esc50")
    >>> logits = model(audio)  # (batch, 50)

    With a custom linear head:

    >>> model = get_ssondo(head="linear", n_classes=50)
    >>> model.freeze_backbone()
    >>> logits = model(audio)  # (batch, 50)

    With an MLP classification head:

    >>> model = get_ssondo(head="mlp", n_classes=50, hidden_sizes=[512, 256])
    >>> model.freeze_backbone()
    >>> logits = model(audio)  # (batch, 50)
    """
    if head in ("linear", "mlp") and n_classes is None:
        raise ValueError("n_classes is required when head is 'linear' or 'mlp'")

    ckpt = _resolve_checkpoint(checkpoint, device)
    conf = ckpt["training_config"]

    sr = conf["student_model"]["sr"]
    logmel_params = conf["preprocess"]["logmelspec"]
    slice_params = conf["preprocess"]["slice_audio"]

    slicer = SliceAudio(
        sr=sr,
        window_length=slice_params["win_len"],
        step_size=slice_params["step_size"],
    )
    logmel = LogMelSpectrogram(
        sample_rate=sr,
        win_length=logmel_params["win_len"],
        hop_length=logmel_params["hop_len"],
        n_mels=logmel_params["n_mels"],
        f_min=logmel_params["f_min"],
        f_max=logmel_params["f_max"],
    )

    student_model = _build_student_model(conf)

    state_dict = ckpt["state_dict"]
    prefix = "student_model."
    new_state_dict = {
        k[len(prefix) :]: v for k, v in state_dict.items() if k.startswith(prefix)
    }
    student_model.load_state_dict(new_state_dict, strict=True)

    classification_head = None
    if head is not None:
        emb_dim = student_model.model.emb_size
        classification_head = _build_head(head, emb_dim, n_classes, hidden_sizes, device)

    wrapper = SsondoWrapper(
        student_model=student_model,
        slicer=slicer,
        logmel=logmel,
        return_logits=return_logits,
        head=classification_head,
    )
    wrapper = wrapper.to(device)
    wrapper.eval()
    return wrapper
