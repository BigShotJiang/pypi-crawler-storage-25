"""Response and error data structures for the cv-pipeline package.

Defines the JSON-serializable dataclasses that represent inference results
and error responses. These structures implement the contract from the
CV Pipeline Specification (task_328), sections 4 and 6.

All consumers of the pipeline — FastAPI, CLI, Azure ML jobs — receive
these same structures.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Landmark:
    """A single detected root tip location.

    Args:
        id: Zero-based index of this landmark.
        x: X coordinate in input pixel space.
        y: Y coordinate in input pixel space.
        confidence: Confidence that this point is a true root tip, range [0, 1].
    """

    id: int
    x: int
    y: int
    confidence: float

    def to_dict(self) -> dict:
        """Convert to a plain dictionary for JSON serialization."""
        return {
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "confidence": self.confidence,
        }


@dataclass
class Metadata:
    """Optional metadata passed alongside the input image.

    Args:
        plate_id: Identifier for the Petri dish or plate.
        experiment_id: Identifier for the experiment this image belongs to.
        timestamp: ISO 8601 time the image was captured.
    """

    plate_id: str | None = None
    experiment_id: str | None = None
    timestamp: str | None = None

    def to_dict(self) -> dict:
        """Convert to a plain dictionary for JSON serialization."""
        return {
            "plate_id": self.plate_id,
            "experiment_id": self.experiment_id,
            "timestamp": self.timestamp,
        }


@dataclass
class InferenceResult:
    """Complete inference response for a single image.

    Args:
        pipeline_version: Semantic version of the cv-pipeline package.
        model_version: Name and version of the registered model used.
        timestamp: ISO 8601 UTC time the inference completed.
        image_filename: Filename of the input image (not the full path).
        image_width_px: Width of the input image in pixels.
        image_height_px: Height of the input image in pixels.
        metadata: Optional metadata passed through from the input.
        mask_b64: Base64-encoded PNG of the binary segmentation mask.
        mask_confidence: Mean confidence across root-classified pixels, range [0, 1].
        landmark_count: Number of root tips detected. Zero is a valid value.
        landmarks: List of detected root tip landmarks. Empty list if none detected.
    """

    pipeline_version: str
    model_version: str
    timestamp: str
    image_filename: str
    image_width_px: int
    image_height_px: int
    metadata: Metadata
    mask_b64: str
    mask_confidence: float
    landmark_count: int
    landmarks: list[Landmark] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to a plain dictionary for JSON serialization."""
        return {
            "pipeline_version": self.pipeline_version,
            "model_version": self.model_version,
            "timestamp": self.timestamp,
            "image_filename": self.image_filename,
            "image_width_px": self.image_width_px,
            "image_height_px": self.image_height_px,
            "metadata": self.metadata.to_dict(),
            "mask_b64": self.mask_b64,
            "mask_confidence": self.mask_confidence,
            "landmark_count": self.landmark_count,
            "landmarks": [lm.to_dict() for lm in self.landmarks],
        }


@dataclass
class ErrorResponse:
    """Error response returned when the pipeline rejects an input.

    Args:
        error_code: Machine-readable code identifying the error type.
        message: Human-readable explanation with specific values where available.
        pipeline_version: Package version at the time of the error.
        timestamp: ISO 8601 UTC time the error occurred.
    """

    error_code: str
    message: str
    pipeline_version: str
    timestamp: str

    def to_dict(self) -> dict:
        """Convert to a plain dictionary for JSON serialization."""
        return {
            "error_code": self.error_code,
            "message": self.message,
            "pipeline_version": self.pipeline_version,
            "timestamp": self.timestamp,
        }
