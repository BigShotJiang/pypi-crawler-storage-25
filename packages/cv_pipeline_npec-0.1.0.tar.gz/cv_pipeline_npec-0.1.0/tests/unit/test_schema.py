"""Unit tests for cv_pipeline.schema."""

from __future__ import annotations

import pytest
from cv_pipeline.schema import (
    ErrorResponse,
    InferenceResult,
    Landmark,
    Metadata,
)

# ---- Landmark --------------------------------------------------------


@pytest.mark.unit
class TestLandmark:
    """Tests for the Landmark dataclass."""

    def test_to_dict_contains_all_fields(self) -> None:
        """to_dict should return all four fields."""
        lm = Landmark(id=0, x=100, y=200, confidence=0.95)
        d = lm.to_dict()

        assert d == {
            "id": 0,
            "x": 100,
            "y": 200,
            "confidence": 0.95,
        }

    def test_multiple_landmarks_have_unique_ids(self) -> None:
        """Each landmark should have a distinct id."""
        landmarks = [
            Landmark(id=i, x=i * 10, y=i * 20, confidence=0.8) for i in range(5)
        ]
        ids = [lm.id for lm in landmarks]
        assert len(set(ids)) == 5


# ---- Metadata --------------------------------------------------------


@pytest.mark.unit
class TestMetadata:
    """Tests for the Metadata dataclass."""

    def test_defaults_are_none(self) -> None:
        """All fields should default to None."""
        m = Metadata()
        d = m.to_dict()

        assert d["plate_id"] is None
        assert d["experiment_id"] is None
        assert d["timestamp"] is None

    def test_to_dict_with_values(self) -> None:
        """Provided values should appear in the dict."""
        m = Metadata(
            plate_id="PL-001",
            experiment_id="EXP-42",
            timestamp="2026-04-17T12:00:00Z",
        )
        d = m.to_dict()

        assert d["plate_id"] == "PL-001"
        assert d["experiment_id"] == "EXP-42"
        assert d["timestamp"] == "2026-04-17T12:00:00Z"


# ---- InferenceResult -------------------------------------------------


@pytest.mark.unit
class TestInferenceResult:
    """Tests for the InferenceResult dataclass."""

    def test_to_dict_structure_matches_spec(self) -> None:
        """to_dict should contain all fields from the spec schema."""
        result = InferenceResult(
            pipeline_version="0.1.0",
            model_version="unet-v0",
            timestamp="2026-04-17T12:00:00Z",
            image_filename="plate_001.tif",
            image_width_px=2048,
            image_height_px=2048,
            metadata=Metadata(),
            mask_b64="dGVzdA==",
            mask_confidence=0.87,
            landmark_count=2,
            landmarks=[
                Landmark(id=0, x=100, y=200, confidence=0.9),
                Landmark(id=1, x=300, y=400, confidence=0.8),
            ],
        )
        d = result.to_dict()

        assert d["pipeline_version"] == "0.1.0"
        assert d["model_version"] == "unet-v0"
        assert d["image_filename"] == "plate_001.tif"
        assert d["image_width_px"] == 2048
        assert d["landmark_count"] == 2
        assert len(d["landmarks"]) == 2
        assert d["landmarks"][0]["x"] == 100

    def test_empty_landmarks_is_valid(self) -> None:
        """Zero landmarks is a valid result per the spec."""
        result = InferenceResult(
            pipeline_version="0.1.0",
            model_version="unet-v0",
            timestamp="2026-04-17T12:00:00Z",
            image_filename="empty.tif",
            image_width_px=512,
            image_height_px=512,
            metadata=Metadata(),
            mask_b64="",
            mask_confidence=0.0,
            landmark_count=0,
            landmarks=[],
        )
        d = result.to_dict()

        assert d["landmark_count"] == 0
        assert d["landmarks"] == []
        assert d["mask_confidence"] == 0.0

    def test_metadata_nested_in_dict(self) -> None:
        """Metadata should be serialized as a nested dict."""
        result = InferenceResult(
            pipeline_version="0.1.0",
            model_version="unet-v0",
            timestamp="2026-04-17T12:00:00Z",
            image_filename="plate.tif",
            image_width_px=1024,
            image_height_px=1024,
            metadata=Metadata(plate_id="PL-001"),
            mask_b64="",
            mask_confidence=0.5,
            landmark_count=0,
        )
        d = result.to_dict()

        assert isinstance(d["metadata"], dict)
        assert d["metadata"]["plate_id"] == "PL-001"


# ---- ErrorResponse ---------------------------------------------------


@pytest.mark.unit
class TestErrorResponse:
    """Tests for the ErrorResponse dataclass."""

    def test_to_dict_contains_all_fields(self) -> None:
        """to_dict should return all four error fields."""
        err = ErrorResponse(
            error_code="FILE_TOO_LARGE",
            message="File is 62.4 MB, exceeds 50 MB limit.",
            pipeline_version="0.1.0",
            timestamp="2026-04-17T12:00:00Z",
        )
        d = err.to_dict()

        assert d["error_code"] == "FILE_TOO_LARGE"
        assert "62.4" in d["message"]
        assert d["pipeline_version"] == "0.1.0"
