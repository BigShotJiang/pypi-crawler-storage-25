import sqlite3
import os
from pathlib import Path
from grove.tree import Node

DB_PATH = Path.home() / ".grove" / "grove.db"


def get_connection() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            parent_id INTEGER,
            name TEXT NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(id),
            FOREIGN KEY (parent_id) REFERENCES nodes(id)
        );

        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            node_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            position INTEGER NOT NULL,
            FOREIGN KEY (node_id) REFERENCES nodes(id)
        );
                       
        CREATE INDEX IF NOT EXISTS idx_messages_node_id ON messages(node_id);
        CREATE INDEX IF NOT EXISTS idx_nodes_session_id ON nodes(session_id);
    """)
    conn.commit()
    conn.close()


def list_sessions() -> list[dict]:
    conn = get_connection()
    rows = conn.execute(
        "SELECT name, created_at, updated_at FROM sessions ORDER BY updated_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def session_exists(name: str) -> bool:
    conn = get_connection()
    row = conn.execute("SELECT id FROM sessions WHERE name = ?", (name,)).fetchone()
    conn.close()
    return row is not None


def delete_session(name: str) -> bool:
    conn = get_connection()
    row = conn.execute("SELECT id FROM sessions WHERE name = ?", (name,)).fetchone()
    if not row:
        conn.close()
        return False
    session_id = row["id"]
    # delete messages, then nodes, then session
    conn.execute("""
        DELETE FROM messages WHERE node_id IN (
            SELECT id FROM nodes WHERE session_id = ?
        )
    """, (session_id,))
    conn.execute("DELETE FROM nodes WHERE session_id = ?", (session_id,))
    conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
    conn.commit()
    conn.close()
    return True


def save_session(name: str, root: Node):
    """Save or overwrite a full session tree."""
    conn = get_connection()

    # upsert session
    conn.execute("""
        INSERT INTO sessions (name, updated_at) VALUES (?, CURRENT_TIMESTAMP)
        ON CONFLICT(name) DO UPDATE SET updated_at = CURRENT_TIMESTAMP
    """, (name,))
    session_id = conn.execute("SELECT id FROM sessions WHERE name = ?", (name,)).fetchone()["id"]

    # clear existing nodes/messages for this session
    conn.execute("""
        DELETE FROM messages WHERE node_id IN (
            SELECT id FROM nodes WHERE session_id = ?
        )
    """, (session_id,))
    conn.execute("DELETE FROM nodes WHERE session_id = ?", (session_id,))

    # recursively save nodes
    _save_node(conn, session_id, root, parent_db_id=None)
    conn.commit()
    conn.close()


def _save_node(conn, session_id: int, node: Node, parent_db_id):
    cursor = conn.execute(
        "INSERT INTO nodes (session_id, parent_id, name) VALUES (?, ?, ?)",
        (session_id, parent_db_id, node.name)
    )
    node_db_id = cursor.lastrowid
    for i, msg in enumerate(node.messages):
        conn.execute(
            "INSERT INTO messages (node_id, role, content, position) VALUES (?, ?, ?, ?)",
            (node_db_id, msg["role"], msg["content"], i)
        )
    for child in node.children:
        _save_node(conn, session_id, child, node_db_id)


def load_session(name: str) -> Node | None:
    conn = get_connection()
    session_row = conn.execute("SELECT id FROM sessions WHERE name = ?", (name,)).fetchone()
    if not session_row:
        conn.close()
        return None
    session_id = session_row["id"]

    nodes_rows = conn.execute(
        "SELECT id, parent_id, name FROM nodes WHERE session_id = ? ORDER BY id",
        (session_id,)
    ).fetchall()

    if not nodes_rows:
        conn.close()
        return None

    # build a map of db_id -> Node
    node_map: dict[int, Node] = {}
    root = None

    for row in nodes_rows:
        messages = conn.execute(
            "SELECT role, content FROM messages WHERE node_id = ? ORDER BY position",
            (row["id"],)
        ).fetchall()
        node = Node(
            name=row["name"],
            messages=[{"role": m["role"], "content": m["content"]} for m in messages]
        )
        node_map[row["id"]] = node
        if row["parent_id"] is None:
            root = node

    # wire up parent/child relationships
    for row in nodes_rows:
        if row["parent_id"] is not None:
            parent = node_map[row["parent_id"]]
            child = node_map[row["id"]]
            child.parent = parent
            parent.children.append(child)

    conn.close()
    return root


def touch_session(name: str):
    """Update updated_at timestamp."""
    conn = get_connection()
    conn.execute("UPDATE sessions SET updated_at = CURRENT_TIMESTAMP WHERE name = ?", (name,))
    conn.commit()
    conn.close()
