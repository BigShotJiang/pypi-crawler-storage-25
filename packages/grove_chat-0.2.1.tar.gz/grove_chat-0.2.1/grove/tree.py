from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Node:
    """A single node in the conversation tree.
    
    Each node holds its own isolated message history.
    Children are branches forked from this node.
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = "main"
    messages: list[dict] = field(default_factory=list)
    parent: Optional["Node"] = field(default=None, repr=False)
    children: list["Node"] = field(default_factory=list)

    def fork(self, name: str) -> "Node":
        """Create a child branch, inheriting current message history."""
        child = Node(
            name=name,
            messages=list(self.messages),
            parent=self,
        )
        self.children.append(child)
        return child

    def depth(self) -> int:
        d = 0
        n = self
        while n.parent:
            d += 1
            n = n.parent
        return d

    def root(self) -> "Node":
        n = self
        while n.parent:
            n = n.parent
        return n
