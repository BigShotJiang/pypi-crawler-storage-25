from rich.console import Console
from rich.tree import Tree as RichTree
from rich.text import Text
from grove.tree import Node

console = Console()


def print_tree(root: Node, current: Node):
    """Print the full conversation tree, highlighting current node."""
    rich_tree = _build_rich_tree(root, current)
    console.print(rich_tree)


def _build_rich_tree(node: Node, current: Node, rich_node=None):
    label = _node_label(node, current)
    if rich_node is None:
        t = RichTree(label)
        for child in node.children:
            _build_rich_tree(child, current, t)
        return t
    else:
        branch = rich_node.add(label)
        for child in node.children:
            _build_rich_tree(child, current, branch)


def _node_label(node: Node, current: Node) -> Text:
    name = node.name
    msg_count = len([m for m in node.messages if m["role"] == "user"])
    if node is current:
        return Text(f"▶ {name} ({msg_count} msgs)", style="bold green")
    return Text(f"  {name} ({msg_count} msgs)", style="dim")


def print_status(current: Node):
    path = []
    n = current
    while n:
        path.append(n.name)
        n = n.parent
    breadcrumb = " > ".join(reversed(path))
    console.print(f"[dim]branch:[/dim] [bold cyan]{breadcrumb}[/bold cyan]")


def print_branches(current: Node):
    if not current.children:
        console.print("[dim]No branches from here.[/dim]")
        return
    console.print("[bold]Branches from here:[/bold]")
    for child in current.children:
        console.print(f"  [cyan]{child.name}[/cyan]")
