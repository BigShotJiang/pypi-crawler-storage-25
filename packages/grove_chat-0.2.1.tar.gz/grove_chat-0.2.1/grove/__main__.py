import sys
from rich.console import Console
from rich.prompt import Prompt
from grove.tree import Node
from grove.chat import stream_response, list_models
from grove.display import print_tree, print_status, print_branches
from grove.db import (
    init_db, list_sessions, session_exists, delete_session,
    save_session, load_session, touch_session
)

console = Console()

HELP = """
[bold]Grove commands:[/bold]
  /branch [name]      Fork a new branch from here
  /switch <name>      Switch into an existing branch
  /parent             Go up one level to parent branch
  /main               Jump straight to the main branch
  /branches           List branches from current node
  /tree               Show full conversation tree
  /merge              Summarize this branch into parent
  /discard            Discard this branch and return to parent
  /session list       List all saved sessions
  /session new <n>    Start a new named session
  /session load <n>   Load a past session
  /session delete <n> Delete a session
  /model              Switch model
  /help               Show this help
  /quit               Exit and save
"""


def pick_model() -> str:
    models = list_models()
    if not models:
        console.print("[red]No models found. Pull one with: ollama pull llama3[/red]")
        sys.exit(1)
    if len(models) == 1:
        console.print(f"[dim]Using model: {models[0]}[/dim]")
        return models[0]
    console.print("[bold]Available models:[/bold]")
    for i, m in enumerate(models):
        console.print(f"  [{i+1}] {m}")
    choice = Prompt.ask("Pick a model", default="1")
    try:
        return models[int(choice) - 1]
    except (ValueError, IndexError):
        return models[0]


def pick_session() -> tuple[str, Node]:
    """On startup, let user pick or create a session."""
    sessions = list_sessions()
    if not sessions:
        console.print("[dim]No saved sessions. Starting a new one.[/dim]")
        name = Prompt.ask("Session name", default="default")
        return name, Node(name="main")

    console.print("[bold]Saved sessions:[/bold]")
    for i, s in enumerate(sessions):
        console.print(f"  [{i+1}] {s['name']} [dim](last used {s['updated_at']})[/dim]")
    console.print(f"  [n] New session")

    choice = Prompt.ask("Pick a session", default="1")

    if choice.lower() == "n":
        name = Prompt.ask("Session name", default="default")
        return name, Node(name="main")

    try:
        session = sessions[int(choice) - 1]
        name = session["name"]
        root = load_session(name)
        if root:
            console.print(f"[green]Loaded session:[/green] [cyan]{name}[/cyan]")
            return name, root
    except (ValueError, IndexError):
        pass

    name = Prompt.ask("Session name", default="default")
    return name, Node(name="main")


def main():
    init_db()
    console.print("[bold green]🌿 Grove[/bold green] — branching conversations for local LLMs")
    console.print("[dim]Type /help for commands[/dim]\n")

    model = pick_model()
    session_name, root = pick_session()
    current = root

    while True:
        print_status(current)
        try:
            user_input = Prompt.ask("[bold]you[/bold]")
        except (KeyboardInterrupt, EOFError):
            save_session(session_name, root)
            console.print("\n[dim]Session saved. Bye.[/dim]")
            break

        if not user_input.strip():
            continue

        if user_input.startswith("/"):
            parts = user_input.split(maxsplit=2)
            cmd = parts[0].lower()
            arg = parts[1] if len(parts) > 1 else ""
            arg2 = parts[2] if len(parts) > 2 else ""

            if cmd == "/quit":
                save_session(session_name, root)
                console.print("[dim]Session saved. Bye.[/dim]")
                break

            elif cmd == "/help":
                console.print(HELP)

            elif cmd == "/tree":
                print_tree(current.root(), current)

            elif cmd == "/branches":
                print_branches(current)

            elif cmd == "/branch":
                name = arg.strip() or f"branch-{len(current.children)+1}"
                existing = next((c for c in current.children if c.name == name), None)
                if existing:
                    current = existing
                    console.print(f"[yellow]Already exists, switching to:[/yellow] [cyan]{name}[/cyan]")
                else:
                    current = current.fork(name)
                    console.print(f"[green]Branched into:[/green] [cyan]{name}[/cyan]")
                save_session(session_name, root)

            elif cmd == "/switch":
                name = arg.strip()
                if not name:
                    console.print("[red]Usage: /switch <branch-name>[/red]")
                else:
                    match = next((c for c in current.children if c.name == name), None)
                    if match:
                        current = match
                        console.print(f"[green]Switched to:[/green] [cyan]{name}[/cyan]")
                    else:
                        available = [c.name for c in current.children]
                        if available:
                            console.print(f"[red]No branch '{name}' here.[/red] Available: {', '.join(available)}")
                        else:
                            console.print("[red]No branches here yet. Use /branch to create one.[/red]")

            elif cmd == "/parent":
                if current.parent is None:
                    console.print("[dim]Already at root.[/dim]")
                else:
                    current = current.parent
                    console.print(f"[green]Returned to:[/green] [cyan]{current.name}[/cyan]")

            elif cmd == "/main":
                if current.parent is None:
                    console.print("[dim]Already at main.[/dim]")
                else:
                    current = current.root()
                    console.print(f"[green]Jumped to:[/green] [cyan]main[/cyan]")

            elif cmd == "/discard":
                if current.parent is None:
                    console.print("[dim]Can't discard root.[/dim]")
                else:
                    parent = current.parent
                    parent.children.remove(current)
                    current = parent
                    save_session(session_name, root)
                    console.print(f"[yellow]Branch discarded.[/yellow] Back to [cyan]{current.name}[/cyan]")

            elif cmd == "/merge":
                if current.parent is None:
                    console.print("[dim]Can't merge root.[/dim]")
                else:
                    console.print("[dim]Summarizing branch...[/dim]")
                    summary_prompt = (
                        "Summarize the key conclusions or insights from this conversation "
                        "in 2-3 sentences, as if briefing someone who wasn't there."
                    )
                    temp = Node(name="summary", messages=list(current.messages))
                    temp.messages.append({"role": "user", "content": summary_prompt})
                    summary = stream_response(temp, model)
                    if summary:
                        current.parent.messages.append({
                            "role": "user",
                            "content": f"[Merged from branch '{current.name}']: {summary}"
                        })
                        parent = current.parent
                        parent.children.remove(current)
                        current = parent
                        save_session(session_name, root)
                        console.print(f"[green]Merged into:[/green] [cyan]{current.name}[/cyan]")

            elif cmd == "/session":
                subcmd = arg.strip().lower()
                name = arg2.strip()

                if subcmd == "list":
                    sessions = list_sessions()
                    if not sessions:
                        console.print("[dim]No saved sessions.[/dim]")
                    else:
                        for s in sessions:
                            marker = "[green]▶[/green] " if s["name"] == session_name else "  "
                            console.print(f"{marker}[cyan]{s['name']}[/cyan] [dim]{s['updated_at']}[/dim]")

                elif subcmd == "new":
                    if not name:
                        name = Prompt.ask("Session name")
                    save_session(session_name, root)
                    session_name = name
                    root = Node(name="main")
                    current = root
                    console.print(f"[green]New session:[/green] [cyan]{name}[/cyan]")

                elif subcmd == "load":
                    if not name:
                        name = Prompt.ask("Session name")
                    loaded = load_session(name)
                    if loaded:
                        save_session(session_name, root)
                        session_name = name
                        root = loaded
                        current = root
                        touch_session(name)
                        console.print(f"[green]Loaded session:[/green] [cyan]{name}[/cyan]")
                    else:
                        console.print(f"[red]Session '{name}' not found.[/red]")

                elif subcmd == "delete":
                    if not name:
                        name = Prompt.ask("Session name")
                    if name == session_name:
                        console.print("[red]Can't delete the current session.[/red]")
                    elif delete_session(name):
                        console.print(f"[yellow]Deleted session:[/yellow] [cyan]{name}[/cyan]")
                    else:
                        console.print(f"[red]Session '{name}' not found.[/red]")

                else:
                    console.print("[red]Usage: /session list|new|load|delete[/red]")

            elif cmd == "/model":
                model = pick_model()
                console.print(f"[green]Switched to:[/green] {model}")

            else:
                console.print(f"[red]Unknown command:[/red] {cmd}. Type /help.")

            continue

        # --- normal chat ---
        current.messages.append({"role": "user", "content": user_input})
        reply = stream_response(current, model)
        if reply:
            current.messages.append({"role": "assistant", "content": reply})
            save_session(session_name, root)

def serve():
    try:
        import uvicorn
    except ImportError:
        print("uvicorn not installed. Run: pip install uvicorn")
        sys.exit(1)
    init_db()
    console.print("[bold green]🌿 Grove API[/bold green] starting on http://localhost:7337")
    console.print("[dim]Docs at http://localhost:7337/docs[/dim]")
    uvicorn.run("grove.server:app", host="0.0.0.0", port=7337, reload=False)


def ui():
    try:
        import uvicorn
    except ImportError:
        print("uvicorn not installed. Run: pip install uvicorn")
        sys.exit(1)
    import threading
    import webbrowser
    init_db()
    url = "http://localhost:7337"
    console.print(f"[bold green]🌿 Grove[/bold green] starting at {url}")
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    uvicorn.run("grove.server:app", host="0.0.0.0", port=7337, reload=False)

if __name__ == "__main__":
    main()

