import ollama
from rich.console import Console
from rich.spinner import Spinner
from rich.live import Live
from grove.tree import Node

console = Console()


def stream_response(node: Node, model: str) -> str:
    full = ""
    started = False

    try:
        stream = ollama.chat(model=model, messages=node.messages, stream=True)

        with Live(Spinner("dots", text="thinking..."), console=console, transient=True) as live:
            for chunk in stream:
                if not started:
                    started = True
                    live.stop()
                    print("\033[1;36mgrove\033[0m ", end="", flush=True)
                token = chunk.message.content
                full += token
                print(token, end="", flush=True)

        if full:
            print()

    except KeyboardInterrupt:
        print()
        console.print("[yellow]Generation cancelled.[/yellow]")

    except Exception as e:
        console.print(f"[red]Ollama error: {e}[/red]")
        console.print("[dim]Is Ollama running? Try: ollama serve[/dim]")

    return full


def list_models() -> list[str]:
    try:
        response = ollama.list()
        models = response.get("models", []) if isinstance(response, dict) else response.models
        result = []
        for m in models:
            if isinstance(m, dict):
                result.append(m["name"])
            else:
                result.append(m.model)
        return result
    except Exception:
        return []
