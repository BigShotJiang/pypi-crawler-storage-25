from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from pathlib import Path
import ollama

from grove.tree import Node
from grove.db import (
    init_db, list_sessions, save_session, load_session,
    delete_session, touch_session
)

app = FastAPI(title="Grove API", description="Branching conversations for local LLMs")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_static_dir = Path(__file__).parent / "static"


# --- request/response models ---

class ChatRequest(BaseModel):
    session: str
    node_path: list[str]  # e.g. ["main", "ml", "attention"]
    message: str
    model: str = "llama3.2:3b"

class BranchRequest(BaseModel):
    session: str
    node_path: list[str]
    branch_name: str

class NavigateRequest(BaseModel):
    session: str
    node_path: list[str]

class MergeRequest(BaseModel):
    session: str
    node_path: list[str]
    model: str = "llama3.2:3b"

class SessionRequest(BaseModel):
    name: str


# --- helpers ---

def resolve_node(root: Node, path: list[str]) -> Node:
    """Walk the tree following a path of names."""
    current = root
    for name in path[1:]:  # skip "main" which is root
        match = next((c for c in current.children if c.name == name), None)
        if not match:
            raise HTTPException(status_code=404, detail=f"Node '{name}' not found")
        current = match
    return current


def node_to_dict(node: Node, current_path: list[str] = None) -> dict:
    """Serialize a node and its children to a dict."""
    return {
        "name": node.name,
        "message_count": len([m for m in node.messages if m["role"] == "user"]),
        "children": [node_to_dict(c) for c in node.children]
    }


# --- session endpoints ---

@app.get("/sessions")
def get_sessions():
    return list_sessions()


@app.post("/sessions")
def create_session(req: SessionRequest):
    root = Node(name="main")
    save_session(req.name, root)
    return {"name": req.name, "status": "created"}


@app.delete("/sessions/{name}")
def remove_session(name: str):
    if not delete_session(name):
        raise HTTPException(status_code=404, detail=f"Session '{name}' not found")
    return {"name": name, "status": "deleted"}


# --- tree endpoints ---

@app.get("/sessions/{session}/tree")
def get_tree(session: str):
    root = load_session(session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{session}' not found")
    return node_to_dict(root)


@app.get("/sessions/{session}/messages")
def get_messages(session: str, node_path: str = "main"):
    root = load_session(session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{session}' not found")
    path = node_path.split(".")
    node = resolve_node(root, path)
    return {"node": node.name, "messages": node.messages}


# --- chat endpoint ---

@app.post("/chat")
def chat(req: ChatRequest):
    root = load_session(req.session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{req.session}' not found")

    node = resolve_node(root, req.node_path)
    node.messages.append({"role": "user", "content": req.message})

    full = ""
    try:
        stream = ollama.chat(model=req.model, messages=node.messages, stream=True)
        for chunk in stream:
            full += chunk.message.content
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    node.messages.append({"role": "assistant", "content": full})
    save_session(req.session, root)
    touch_session(req.session)

    return {"reply": full, "node": node.name}


@app.post("/chat/stream")
def chat_stream(req: ChatRequest):
    """Streaming version of chat — returns tokens as they arrive."""
    root = load_session(req.session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{req.session}' not found")

    node = resolve_node(root, req.node_path)
    node.messages.append({"role": "user", "content": req.message})

    def generate():
        full = ""
        try:
            stream = ollama.chat(model=req.model, messages=node.messages, stream=True)
            for chunk in stream:
                token = chunk.message.content
                full += token
                yield token
        except Exception as e:
            yield f"[error: {e}]"
        node.messages.append({"role": "assistant", "content": full})
        save_session(req.session, root)

    return StreamingResponse(generate(), media_type="text/plain")


# --- branch endpoints ---

@app.post("/branch")
def create_branch(req: BranchRequest):
    root = load_session(req.session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{req.session}' not found")

    node = resolve_node(root, req.node_path)
    existing = next((c for c in node.children if c.name == req.branch_name), None)
    if existing:
        return {"status": "exists", "branch": req.branch_name}

    node.fork(req.branch_name)
    save_session(req.session, root)
    return {"status": "created", "branch": req.branch_name}


@app.post("/merge")
def merge_branch(req: MergeRequest):
    root = load_session(req.session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{req.session}' not found")

    node = resolve_node(root, req.node_path)
    if node.parent is None:
        raise HTTPException(status_code=400, detail="Cannot merge root node")

    summary_prompt = (
        "Summarize the key conclusions or insights from this conversation "
        "in 2-3 sentences, as if briefing someone who wasn't there."
    )
    messages = list(node.messages) + [{"role": "user", "content": summary_prompt}]

    full = ""
    try:
        stream = ollama.chat(model=req.model, messages=messages, stream=True)
        for chunk in stream:
            full += chunk.message.content
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    node.parent.messages.append({
        "role": "user",
        "content": f"[Merged from branch '{node.name}']: {full}"
    })
    node.parent.children.remove(node)
    save_session(req.session, root)

    return {"summary": full, "merged_into": node.parent.name}


@app.delete("/branch")
def discard_branch(req: NavigateRequest):
    root = load_session(req.session)
    if not root:
        raise HTTPException(status_code=404, detail=f"Session '{req.session}' not found")

    node = resolve_node(root, req.node_path)
    if node.parent is None:
        raise HTTPException(status_code=400, detail="Cannot discard root node")

    node.parent.children.remove(node)
    save_session(req.session, root)
    return {"status": "discarded", "returned_to": node.parent.name}


# --- models endpoint ---

@app.get("/models")
def get_models():
    try:
        response = ollama.list()
        models = response.get("models", []) if isinstance(response, dict) else response.models
        return [m["name"] if isinstance(m, dict) else m.model for m in models]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if _static_dir.exists():
    app.mount("/assets", StaticFiles(directory=_static_dir / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa_fallback(full_path: str):
        return FileResponse(_static_dir / "index.html")
