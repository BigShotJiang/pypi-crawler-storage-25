"""Tool loop system prompt builder — framework detection and prompt generation."""
from __future__ import annotations

import json
from pathlib import Path


def _detect_framework(self) -> str:
    """Detect project framework from config files."""
    cwd = Path.cwd()
    detectors = [
        ("Next.js", ["next.config.js", "next.config.ts", "next.config.mjs"]),
        ("React + Vite", ["vite.config.ts", "vite.config.js"]),
        ("Vue", ["vue.config.js"]),
        ("Svelte", ["svelte.config.js"]),
        ("Angular", ["angular.json"]),
        ("Django", ["manage.py"]),
        ("Flask", ["app.py", "wsgi.py"]),
        ("FastAPI", ["main.py"]),
        ("Express", ["app.js", "server.js"]),
        ("Go", ["go.mod"]),
        ("Rust", ["Cargo.toml"]),
        ("Flutter", ["pubspec.yaml"]),
    ]
    for fw, files in detectors:
        if any((cwd / f).exists() for f in files):
            if fw == "FastAPI":
                # main.py alone is not enough — confirm fastapi is a dependency
                if _has_fastapi_dependency(cwd):
                    return fw
                continue
            if fw == "React + Vite":
                # vite.config.ts/js could also be a Vue+Vite project — check for Vue
                if (cwd / "vite.config.ts").exists() or (cwd / "vite.config.js").exists():
                    if (cwd / "src" / "App.vue").exists() or any((cwd / f).exists() for f in ["vue.config.js"]):
                        return "Vue + Vite"
                return fw
            return fw
    pkg_json = cwd / "package.json"
    if pkg_json.exists():
        try:
            pkg = json.loads(pkg_json.read_text())
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "next" in deps: return "Next.js"
            if "react" in deps: return "React"
            if "vue" in deps: return "Vue"
            if "svelte" in deps: return "Svelte"
            if "express" in deps: return "Express"
        except json.JSONDecodeError:
            pass
    return "vanilla"


def _has_fastapi_dependency(cwd: Path) -> bool:
    """Return True if fastapi appears in pyproject.toml or requirements.txt."""
    for candidate in ["pyproject.toml", "requirements.txt", "requirements-dev.txt"]:
        path = cwd / candidate
        if path.exists():
            try:
                if "fastapi" in path.read_text(encoding="utf-8").lower():
                    return True
            except OSError:
                pass
    return False


def _detect_package_manager(self) -> str | None:
    cwd = Path.cwd()
    if (cwd / "package.json").exists():
        if (cwd / "pnpm-lock.yaml").exists(): return "pnpm"
        if (cwd / "yarn.lock").exists(): return "yarn"
        if (cwd / "bun.lockb").exists(): return "bun"
        return "npm"
    if (cwd / "pyproject.toml").exists(): return "pip"
    if (cwd / "Pipfile").exists(): return "pipenv"
    if (cwd / "go.mod").exists(): return "go"
    if (cwd / "Cargo.toml").exists(): return "cargo"
    return None


def _build_system_prompt(self) -> str:
    """Build a rich system prompt aware of the project stack."""
    fw = self._framework or self._detect_framework()
    pkg_mgr = self._detect_package_manager() or "auto"
    cwd = Path.cwd()
    cwd_name = cwd.name

    has_frontend = any(
        (cwd / d).is_dir()
        for d in ["frontend", "client", "web", "app", "src/app", "src/pages"]
    )
    has_backend = any(
        (cwd / d).is_dir()
        for d in ["backend", "server", "api", "src/api"]
    )
    has_docker = (cwd / "docker-compose.yml").exists() or (cwd / "docker-compose.yaml").exists()
    has_tests = any(
        (cwd / d).is_dir()
        for d in ["tests", "test", "__tests__", "spec"]
    )

    stack_parts: list[str] = []
    if has_frontend and has_backend:
        stack_parts.append("fullstack monorepo")
    if has_docker:
        stack_parts.append("Docker Compose")
    if has_tests:
        stack_parts.append("test suite present")
    stack_line = f"Stack: {', '.join(stack_parts)}" if stack_parts else ""

    context = f"""You are WIDDX, an expert AI software engineer powered by DeepSeek V4 working in the terminal.

Project: {cwd_name}  |  Framework: {fw}  |  Package manager: {pkg_mgr}
{stack_line}

## Tools
- Read(file_path, offset?, limit?)          — read a file; always read before editing
- Write(file_path, content, overwrite?)     — create or overwrite a file
- Edit(file_path, old_string, new_string)   — precise string replacement (include 3+ lines of context)
- Grep(pattern, path?)                      — regex search across files
- Glob(pattern, path?)                      — find files by pattern
- ListDir(path)                             — explore directory structure
- Bash(command, timeout?)                   — run shell commands
- WebSearch(query)                          — search documentation or the web

## Rules
1. Always Read a file before editing — never guess its contents.
2. Use ListDir and Glob to explore unfamiliar directories first.
3. Write complete, working code — no placeholders, no TODOs, no "..." ellipsis.
4. After writing code, verify it with Bash (run it, lint it, or test it).
5. If a test suite exists, run it after any change.
6. For fullstack tasks: backend first → frontend → wire together.
7. Use Edit for targeted changes; use Write(overwrite=true) only for full rewrites.
8. When a command fails, read the error carefully before retrying.
9. Prefer small, focused changes over large rewrites.
10. Never truncate file content when writing — always write the complete file.

## Project context
{self._project_context or "(run /index to scan project)"}
"""

    if self._project_md:
        context += f"\n## Project Memory (WIDDX.md)\n{self._project_md[:4000]}"

    skill_manager = getattr(self, "_skill_manager", None)
    if skill_manager:
        task = getattr(self, "_current_task", "") or ""
        active_skills = skill_manager.match_skills(task)
        if active_skills:
            context += "\n\n## Relevant Skills\n" + "\n\n".join(active_skills)

        missing = skill_manager.missing_domains(task)
        if missing:
            context += (
                "\n\n## Unfamiliar Technologies Detected\n"
                + ", ".join(missing)
                + f"\nSuggest: `/bootstrap {missing[0]}` to learn this technology."
            )

    return context.strip()
