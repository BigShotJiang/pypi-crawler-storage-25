"""Arabic script detection and reshaping — fully automatic for all terminals.

Zero-config RTL rendering: detects terminal capabilities and applies
the correct Arabic rendering strategy with no user intervention.

Strategy:
- All terminals: arabic_reshaper for letter joining (contextual shaping)
- Terminals WITHOUT bidi (xterm.js: VS Code, Cursor, Hyper...): manual RTL
- Terminals WITH bidi (Windows Terminal, iTerm2, Kitty, Gnome...): native RTL
"""
from __future__ import annotations

import os
import sys

# ── Arabic Unicode ranges ──
_ARABIC_RANGES = [
    (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
    (0xFB50, 0xFDFF), (0xFE70, 0xFEFF),
]

# Characters that should NOT be reshaped (numbers, punctuation, emoji, etc.).
_NEUTRAL_RANGES = [
    (0x0030, 0x0039),   # 0-9
    (0x0020, 0x002F),   # space ! " # $ % & ' ( ) * + , - . /
    (0x003A, 0x0040),   # : ; < = > ? @
    (0x005B, 0x0060),   # [ \ ] ^ _ `
    (0x007B, 0x007E),   # { | } ~
]

# ── Fully automatic terminal bidi detection ──
# No user configuration needed.  The system inspects environment
# variables that each terminal sets uniquely and decides whether
# manual RTL reordering is required.

# Terminals built on xterm.js (NO native bidi)
_TERMINALS_WITHOUT_BIDI = {
    "vscode", "cursor", "windsurf",   # VS Code family
    "hyper", "tabby",                  # Electron-based
    "jetbrains",                       # IntelliJ family
}

# Terminals with confirmed native bidi (fast path, avoid extra checks)
_TERMINALS_WITH_BIDI = {
    "apple_terminal",                  # macOS Terminal.app
    "iterm2",                          # macOS iTerm2
    "kitty",                           # Linux/macOS
    "wezterm",                         # Cross-platform
    "ghostty",                         # Cross-platform
    "alacritty",                       # Cross-platform
    "gnome-terminal",                  # Linux
    "konsole",                         # Linux KDE
    "xfce4-terminal",                  # Linux XFCE
    "lxterminal",                      # Linux LXDE
    "terminator",                      # Linux
    "tilix",                           # Linux
    "foot",                            # Linux Wayland
    "warp",                            # macOS
}


def _terminal_supports_bidi() -> bool:
    """Auto-detect whether the current terminal supports native bidi.

    Inspects well-known environment variables set by each terminal
    emulator.  No user configuration required — this runs silently
    on every Arabic text render.

    Returns:
        True:  terminal handles RTL natively (skip manual bidi)
        False: terminal lacks bidi (apply python-bidi fallback)
    """
    # ── Known bidi-capable terminals (fast positive match) ──
    # Windows Terminal
    if os.environ.get("WT_SESSION"):
        return True
    # iTerm2 (macOS)
    if os.environ.get("ITERM_SESSION_ID"):
        return True
    # Kitty
    if os.environ.get("KITTY_WINDOW_ID"):
        return True
    # WezTerm
    if os.environ.get("WEZTERM_EXECUTABLE"):
        return True
    # Ghostty
    if os.environ.get("GHOSTTY_SOCKET"):
        return True
    # Alacritty (Linux/macOS/Windows)
    if os.environ.get("ALACRITTY_LOG") or os.environ.get("ALACRITTY_SOCKET"):
        return True
    # KDE Konsole — sets KONSOLE_VERSION or KONSOLE_DBUS_SERVICE
    if os.environ.get("KONSOLE_VERSION"):
        return True
    # Gnome Terminal, Tilix, XFCE Terminal — set VTE_VERSION
    if os.environ.get("VTE_VERSION"):
        return True
    # Apple Terminal.app
    if os.environ.get("TERM_PROGRAM") == "Apple_Terminal":
        return True
    # Warp terminal (macOS)
    if os.environ.get("TERM_PROGRAM") == "WarpTerminal":
        return True
    # Foot terminal (Wayland)
    if os.environ.get("TERM") == "foot" or os.environ.get("TERM") == "foot-direct":
        return True

    # ── Known terminals WITHOUT bidi ──
    term_prog = os.environ.get("TERM_PROGRAM", "").lower()
    if term_prog in _TERMINALS_WITHOUT_BIDI:
        return False

    # VS Code forks / derivatives set VSCODE_* or VSCODE_IPC_HOOK_CLI
    if any(k.startswith("VSCODE_") for k in os.environ):
        return False

    # JetBrains IDEs (IntelliJ, PyCharm, etc.) use xterm.js-based terminal
    if os.environ.get("TERMINAL_EMULATOR", "").lower() == "jetbrains":
        return False
    if os.environ.get("JEDITERM_SOURCE"):  # JetBrains Jediterm
        return False

    # ── Known bidi-capable (TERM_PROGRAM based) ──
    if term_prog in _TERMINALS_WITH_BIDI:
        return True

    # ── Platform-aware fallback ──
    # On Windows: if we can't identify the terminal, it's likely
    # the old conhost (cmd.exe / standalone PowerShell) which has
    # poor bidi.  Apply manual RTL to be safe.
    # On Linux/macOS: assume modern terminal with native bidi.
    if sys.platform == "win32":
        return False
    return True


def _cp_is_arabic(cp: int) -> bool:
    """Check if a Unicode code point falls within Arabic ranges."""
    return any(lo <= cp <= hi for lo, hi in _ARABIC_RANGES)


def has_arabic(text: str) -> bool:
    """Return True if the text contains any Arabic character."""
    if not text:
        return False
    return any(_cp_is_arabic(ord(ch)) for ch in text)


def _is_arabic(text: str) -> bool:
    """Detect if text contains significant Arabic content (≥15%)."""
    if not text:
        return False
    arabic_chars = sum(1 for ch in text if _cp_is_arabic(ord(ch)))
    return (arabic_chars / len(text)) >= 0.15


def reshape(text: str) -> str:
    """Prepare Arabic text for terminal display — fully automatic.

    Applies arabic_reshaper for letter joining on ALL terminals.
    Auto-detects whether the terminal supports native bidi and
    applies manual RTL reordering only when needed.
    """
    if not text or not has_arabic(text):
        return text

    try:
        import arabic_reshaper
    except ImportError:
        return text

    # Step 1: Letter joining — always needed for connected Arabic glyphs
    try:
        config = {
            "delete_harakat": False,
            "support_zwj": True,
            "support_arabic_diacritics": True,
        }
        reshaper = arabic_reshaper.ArabicReshaper(config)
        shaped = reshaper.reshape(text)
    except Exception:
        shaped = arabic_reshaper.reshape(text)

    # Step 2: RTL reordering — only on terminals WITHOUT native bidi
    if not _terminal_supports_bidi():
        try:
            from bidi.algorithm import get_display
            shaped = get_display(shaped)
        except ImportError:
            pass

    return str(shaped)


def _d(text: str) -> str:
    """Reshape if Arabic, otherwise return as-is. Convenience wrapper."""
    return reshape(text) if has_arabic(text) else text


def reshape_strict(text: str) -> str:
    """Same as reshape — delegates to reshape() directly.

    Kept for backward compatibility; previously applied aggressive
    bidi reordering which is no longer needed.
    """
    return reshape(text)
