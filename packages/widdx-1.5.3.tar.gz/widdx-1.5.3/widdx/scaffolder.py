"""Project scaffolder — interactive framework installation and project initialisation.

Flow:
  1. Detect framework from task description
  2. Ask user for version and configuration choices
  3. Install the framework (composer create-project, npm create, etc.)
  4. Set up .env with database credentials
  5. Initialise git repository
  6. Create .widdx/ project state directory in the target project
  7. Return a ScaffoldResult with project metadata
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


@dataclass
class ScaffoldQuestion:
    key: str
    label: str
    options: list[str]
    default: str | None = None


@dataclass
class FrameworkConfig:
    label: str
    install_cmd: str
    versions: list[str]
    questions: list[ScaffoldQuestion] = field(default_factory=list)
    post_install: list[str] = field(default_factory=list)
    required_tools: list[str] = field(default_factory=list)
    env_template: dict[str, str] = field(default_factory=dict)


@dataclass
class ScaffoldResult:
    framework: str
    version: str
    project_dir: str
    answers: dict[str, str] = field(default_factory=dict)
    installed: bool = False
    env_created: bool = False
    git_inited: bool = False
    widdx_dir_created: bool = False
    skipped: bool = False
    error: str = ""


# ---------------------------------------------------------------------------
# Framework definitions — extend this dict to add support for new frameworks
# ---------------------------------------------------------------------------

_FRAMEWORKS: dict[str, FrameworkConfig] = {
    "laravel": FrameworkConfig(
        label="Laravel",
        install_cmd="composer create-project laravel/laravel:{version} . --no-interaction",
        versions=["11.x", "10.x", "12.x"],
        required_tools=["php", "composer"],
        post_install=[
            "php artisan key:generate",
            "php artisan storage:link",
        ],
        env_template={
            "DB_CONNECTION": "mysql",
            "DB_HOST": "127.0.0.1",
            "DB_PORT": "3306",
            "DB_DATABASE": "{project_name}",
            "DB_USERNAME": "root",
            "DB_PASSWORD": "",
        },
        questions=[
            ScaffoldQuestion(key="database", label="Database",
                             options=["MySQL", "PostgreSQL", "SQLite", "MariaDB"],
                             default="MySQL"),
            ScaffoldQuestion(key="auth", label="Authentication",
                             options=["Laravel Breeze", "Laravel Jetstream", "Sanctum", "None"],
                             default="Laravel Breeze"),
            ScaffoldQuestion(key="stack", label="Frontend stack",
                             options=["Blade + Tailwind", "Livewire + Alpine", "Inertia + Vue", "Inertia + React", "API only"],
                             default="Blade + Tailwind"),
        ],
    ),
    "django": FrameworkConfig(
        label="Django",
        install_cmd="pip install django=={version} && django-admin startproject {project_name} .",
        versions=["5.1", "5.0", "4.2"],
        required_tools=["python"],
        post_install=[
            "python manage.py migrate",
        ],
        env_template={
            "DEBUG": "True",
            "SECRET_KEY": "",
            "DATABASE_URL": "sqlite:///db.sqlite3",
        },
        questions=[
            ScaffoldQuestion(key="database", label="Database",
                             options=["SQLite", "PostgreSQL", "MySQL"],
                             default="SQLite"),
        ],
    ),
    "react": FrameworkConfig(
        label="React",
        install_cmd="npm create vite@latest . -- --template react-ts",
        versions=["latest"],
        required_tools=["node", "npm"],
        post_install=[
            "npm install",
        ],
        questions=[
            ScaffoldQuestion(key="router", label="Routing",
                             options=["React Router", "TanStack Router", "None"],
                             default="React Router"),
            ScaffoldQuestion(key="styling", label="Styling",
                             options=["Tailwind CSS", "CSS Modules", "Styled Components", "Plain CSS"],
                             default="Tailwind CSS"),
        ],
    ),
    "nextjs": FrameworkConfig(
        label="Next.js",
        install_cmd="npm create next@latest . -- --typescript --app --no-turbopack",
        versions=["latest", "14.x", "13.x"],
        required_tools=["node", "npm"],
        post_install=[
            "npm install",
        ],
        questions=[
            ScaffoldQuestion(key="styling", label="Styling",
                             options=["Tailwind CSS", "CSS Modules", "Plain CSS"],
                             default="Tailwind CSS"),
        ],
    ),
    "fastapi": FrameworkConfig(
        label="FastAPI",
        install_cmd="pip install 'fastapi=={version}' uvicorn",
        versions=["0.115", "0.114", "0.110"],
        required_tools=["python"],
        env_template={
            "APP_ENV": "development",
            "DEBUG": "True",
        },
        questions=[
            ScaffoldQuestion(key="database", label="Database",
                             options=["SQLAlchemy + PostgreSQL", "SQLAlchemy + SQLite", "SQLModel + SQLite"],
                             default="SQLAlchemy + SQLite"),
        ],
    ),
}

# Domain patterns to detect framework from task keywords
_FRAMEWORK_PATTERNS: list[tuple[str, str]] = [
    ("laravel", r"laravel"),
    ("django",  r"django"),
    ("react",   r"\breact\b"),
    ("nextjs",  r"next\.?js?\b"),
    ("fastapi", r"fastapi"),
    ("vue",     r"\bvue\b"),
    ("flask",   r"\bflask\b"),
    ("spring",  r"\bspring\b"),
    ("rails",   r"\brails\b"),
    ("express", r"\bexpress\b"),
]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def detect_framework(task: str) -> tuple[str, FrameworkConfig] | None:
    """Detect the framework the user wants from their task description."""
    import re
    lowered = task.lower()
    for key, pattern in _FRAMEWORK_PATTERNS:
        if re.search(pattern, lowered):
            cfg = _FRAMEWORKS.get(key)
            if cfg:
                return key, cfg
    return None


def ask_questions(cfg: FrameworkConfig) -> dict[str, str]:
    """Ask the user interactive configuration questions."""
    from widdx import ui

    answers: dict[str, str] = {}

    version_str = _ask_version(cfg)
    answers["version"] = version_str

    for question in cfg.questions:
        result = ui.confirm_with_options(
            f"{question.label}: which option?",
            question.options,
            default=question.default,
        )
        selected = _resolve_option(result, question)
        answers[question.key] = selected

    return answers


def scaffold(
    task: str,
    project_dir: str | None = None,
    answers: dict[str, str] | None = None,
    router: object = None,
) -> ScaffoldResult:
    """Run the full scaffolding flow.

    Args:
        task: The user's task description.
        project_dir: Target directory (defaults to CWD).
        answers: Pre-supplied answers (skips interactive questions).

    Returns:
        ScaffoldResult describing what was done.
    """
    from widdx import ui

    detected = detect_framework(task)
    if detected is None and router is not None and getattr(router, 'is_ready', False):
        # Try LLM-based detection for unknown frameworks
        detected = _detect_via_llm(task, router)

    if detected is None:
        return ScaffoldResult(
            framework="unknown",
            version="",
            project_dir=project_dir or os.getcwd(),
            skipped=True,
        )

    key, cfg = detected
    target = Path(project_dir or os.getcwd()).resolve()
    c = ui.get_console()

    # ── 1. Ask interactive questions ───────────────────────────────
    c.print(f"\n  [brand]◆[/] [bold]Project scaffolding:[/] [text]{cfg.label}[/]")

    if answers is None:
        answers = ask_questions(cfg)

    version = answers.get("version", cfg.versions[0])
    # Validate version against allowed values (security: prevents shell injection)
    if version not in cfg.versions:
        version = cfg.versions[0]
    project_name = target.name

    # ── 2. Check required tools ────────────────────────────────────
    from .preflight import check_requirements, print_report
    preflight = check_requirements(cfg.required_tools)
    if not preflight.passed:
        print_report(preflight)
        return ScaffoldResult(
            framework=key, version=version,
            project_dir=str(target),
            error=f"Missing tools: {', '.join(preflight.missing)}",
            answers=answers,
        )

    # ── 3. Run installation command ────────────────────────────────
    import shlex
    safe_version = shlex.quote(version)
    safe_project = shlex.quote(project_name)
    install_cmd = cfg.install_cmd.format(
        version=safe_version,
        project_name=safe_project,
    )

    c.print(f"  [dim]Installing {cfg.label} {version}...[/]")

    try:
        proc = subprocess.run(
            install_cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=300,
            cwd=str(target),
        )
        if proc.returncode != 0:
            error_msg = (proc.stderr or proc.stdout or "").strip()[:500]
            logger.error("Scaffolding failed for %s: %s", key, error_msg)
            return ScaffoldResult(
                framework=key, version=version,
                project_dir=str(target),
                error=error_msg,
                answers=answers,
            )
    except subprocess.TimeoutExpired:
        return ScaffoldResult(
            framework=key, version=version,
            project_dir=str(target),
            error="Installation timed out after 300s",
            answers=answers,
        )
    except OSError as e:
        return ScaffoldResult(
            framework=key, version=version,
            project_dir=str(target),
            error=str(e),
            answers=answers,
        )

    c.print(f"  [success]✓[/] {cfg.label} {version} installed")

    # ── 4. Post-install commands ───────────────────────────────────
    for cmd in cfg.post_install:
        cmd_fmt = cmd.format(project_name=project_name)
        _silent_cmd(cmd_fmt, target)

    # ── 5. Set up .env ─────────────────────────────────────────────
    env_created = _setup_env(cfg, target, answers)

    # ── 6. Initialise git ──────────────────────────────────────────
    git_inited = _init_git(target, cfg.label, version)

    # ── 7. Create .widdx/ in the target project ────────────────────
    _create_widdx_dir(target, key, version, answers)

    # ── 8. Generate skill files for the framework ──────────────────
    _generate_skills(target, key, cfg, answers, router)

    # ── 9. Generate project hooks ─────────────────────────────────
    _generate_hooks(target, key, label=cfg.label)

    # ── 10. Generate MCP config ───────────────────────────────────
    _generate_mcp_config(target)

    c.print(f"  [success]✓[/] Project ready in [text]{target}[/]")
    if git_inited:
        c.print("  [success]✓[/] Git repository initialised")

    return ScaffoldResult(
        framework=key,
        version=version,
        project_dir=str(target),
        answers=answers,
        installed=True,
        env_created=env_created,
        git_inited=git_inited,
        widdx_dir_created=True,
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _ask_version(cfg: FrameworkConfig) -> str:
    """Prompt the user to pick a version via numbered list."""
    from widdx import ui
    from widdx.ui.professional import confirm_with_options
    return confirm_with_options(
        f"{cfg.label} version",
        cfg.versions,
        default=cfg.versions[0],
    )


def _resolve_option(answer: str, question: ScaffoldQuestion) -> str:
    """Resolve a single-character answer to the full option name."""
    if not answer:
        return question.default or question.options[0]
    for opt in question.options:
        if answer == opt[0].lower() or answer.lower() == opt.lower():
            return opt
    return question.default or question.options[0]


def _setup_env(cfg: FrameworkConfig, target: Path, answers: dict[str, str]) -> bool:
    """Create or update .env with template values."""
    if not cfg.env_template:
        return False

    env_path = target / ".env"
    if not env_path.exists():
        try:
            content = "\n".join(
                f"{k}={v.format(project_name=target.name)}"
                for k, v in cfg.env_template.items()
            )
            env_path.write_text(content + "\n", encoding="utf-8")
            return True
        except OSError:
            return False
    return False


def _init_git(target: Path, framework: str, version: str) -> bool:
    """Initialise a git repository if one does not already exist."""
    if (target / ".git").exists():
        return False
    try:
        subprocess.run(
            ["git", "init"],
            capture_output=True, text=True,
            timeout=30, cwd=str(target),
        )
        gitignore_path = target / ".gitignore"
        if not gitignore_path.exists():
            gitignore_path.write_text(
                "/vendor\n/node_modules\n/.env\n.DS_Store\n", encoding="utf-8"
            )
        subprocess.run(
            ["git", "add", "-A"],
            capture_output=True, text=True,
            timeout=30, cwd=str(target),
        )
        subprocess.run(
            ["git", "commit", "-m", f"Initial scaffold: {framework} {version}"],
            capture_output=True, text=True,
            timeout=30, cwd=str(target),
        )
        return True
    except (subprocess.TimeoutExpired, OSError):
        return False


def _detect_via_llm(task: str, router: object) -> tuple[str, FrameworkConfig] | None:
    from openai import OpenAI as _Unused  # noqa: F401
    """Detect framework using LLM when keyword matching fails."""
    try:
        system = (
            "You are a framework detection expert. Given a project description, "
            "identify the web framework or technology stack. "
            "Return JSON only: {\"framework\": \"laravel\"|\"django\"|\"react\"|etc, "
            "\"install_hint\": \"composer create-project...\" or \"npm create...\" or \"pip install...\", "
            "\"language\": \"php\"|\"python\"|\"javascript\"|\"go\"|\"rust\"|\"ruby\"}. "
            "If unknown, return {\"framework\": \"unknown\"}."
        )
        result = router.call_executor(system, task, max_tokens=256) if hasattr(router, "call_executor") else {"text": ""}
        text = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else ""
        if text:
            import json, re
            m = re.search(r"\{.*\}", text, re.DOTALL)
            if m:
                data = json.loads(m.group(0))
                fw = data.get("framework", "unknown")
                if fw and fw != "unknown":
                    install_hint = data.get("install_hint", "")
                    lang = data.get("language", "")
                    cfg = FrameworkConfig(
                        label=fw.capitalize(),
                        install_cmd=install_hint or "echo 'Manual install required'",
                        versions=["latest"],
                        required_tools=[lang] if lang else [],
                    )
                    return fw, cfg
    except Exception:
        pass
    return None


def _silent_cmd(cmd: str, cwd: Path) -> None:
    """Run a shell command silently, ignoring errors."""
    import contextlib
    with contextlib.suppress(subprocess.TimeoutExpired, OSError):
        subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=120, cwd=str(cwd))


def _generate_skills(target: Path, framework: str, cfg: FrameworkConfig | None, answers: dict[str, str], router: object = None) -> None:
    """Create skill markdown files in .widdx/skills/ for the detected framework.

    Checks existing skills first (builtin → user → project) and only
    generates a new one if none exists.
    """
    from widdx import ui
    c = ui.get_console()

    label = cfg.label if cfg else framework
    skill_filename = f"{framework}-best-practices.md"
    skill_name = f"{framework}-best-practices"

    # ── 1. Check if skill already exists ─────────────────────────────
    existing = _find_existing_skill(skill_name)
    if existing:
        c.print(f"  [success]✓[/] Skill: [text]{skill_name}[/] (already exists)")
        return

    # ── 2. Check SelfLearning memory for previously learned patterns ─
    learned = _check_self_learning(framework, router)
    if learned:
        try:
            skills_dir = target / ".widdx" / "skills"
            skills_dir.mkdir(parents=True, exist_ok=True)
            (skills_dir / skill_filename).write_text(learned, encoding="utf-8")
            c.print(f"  [success]✓[/] Skill: [text]{skill_name}[/] (from past experience)")
            return
        except OSError:
            pass

    # ── 3. Generate via LLM ──────────────────────────────────────────
    c.print(f"  [dim]Generating new skill: {label}...[/]")
    skills_dir = target / ".widdx" / "skills"
    try:
        skills_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return

    llm = router if (router is not None and hasattr(router, 'call_executor')) else None
    if llm is None:
        try:
            from widdx.router import AIRouter
            from widdx.config import load_config, DEFAULT_MEMORY_DB_PATH
            from widdx.memory import MemoryStore
            _config = load_config()
            _memory = MemoryStore(_config.get("memory", {}).get("db_path", DEFAULT_MEMORY_DB_PATH))
            llm = AIRouter(_config, _memory)
        except Exception:
            pass

    if llm is not None and getattr(llm, 'is_ready', False):
        try:
            system = (
                f"You are a {label} expert. Write a concise skill file for WIDDX CLI that "
                f"teaches an AI agent the best practices for {label} development. "
                "Include: project structure conventions, key commands, code quality rules, "
                "testing patterns, and common pitfalls to avoid. "
                f"The skill name is '{skill_name}'."
            )
            user_msg = (
                f"Write a comprehensive skill guide for {label} development. "
                f"Focus on practical, actionable advice for an AI coding agent."
            )
            result = llm.call_executor(system, user_msg, max_tokens=2048)
            content = result.get("text", "") if not (isinstance(result, dict) and "error" in result) else ""
            if content and len(content) > 100:
                (skills_dir / skill_filename).write_text(content, encoding="utf-8")
                c.print(f"  [success]✓[/] Skill: [text]{skill_name}[/] (generated)")
                return
        except Exception:
            pass

    # ── 4. Fallback: minimal guide ───────────────────────────────────
    fallback = (
        f"# {label if cfg else framework} Development Guide\n\n"
        f"## Project Structure\n"
        f"- Follow the standard {label if cfg else framework} project layout\n\n"
        f"## Code Quality\n"
        f"- Follow language-specific style guides\n"
        f"- Write tests for critical paths\n\n"
        f"## Commands\n"
        f"- Use the framework's built-in CLI tools\n"
        f"- Run tests frequently\n"
    )
    try:
        (skills_dir / skill_filename).write_text(fallback, encoding="utf-8")
        c.print(f"  [success]✓[/] Skill: [text]{skill_name}[/] (built-in fallback)")
    except OSError:
        pass


def _find_existing_skill(skill_name: str) -> bool:
    """Check if a skill already exists in any of the 3 search directories.

    Order: builtin → user → project (same as SkillManager).
    """
    from pathlib import Path

    search_dirs = [
        Path(__file__).resolve().parent.parent / "skills" / "builtin",
        Path("~/.widdx/skills").expanduser(),
        Path(".widdx/skills"),
    ]

    for directory in search_dirs:
        if not directory.exists() or not directory.is_dir():
            continue
        for md_file in directory.glob("*.md"):
            try:
                text = md_file.read_text(encoding="utf-8")
                if skill_name in text or md_file.stem == skill_name:
                    return True
            except OSError:
                continue
    return False


def _check_self_learning(framework: str, router: object = None) -> str | None:
    """Check if SelfLearning has learned patterns for this framework."""
    if router is None or not hasattr(router, 'memory'):
        return None
    try:
        memory = router.memory
        events = memory.recent_learning_events(limit=20)
        framework_lower = framework.lower()
        relevant = []
        for ev in events:
            task_text = (ev.get("task_text") or "").lower()
            if framework_lower in task_text:
                relevant.append(ev.get("result_summary", ""))

        if len(relevant) >= 3:
            return (
                f"---\nname: {framework}-best-practices\n"
                f"description: Learned from {len(relevant)} successful {framework} tasks\n"
                f"auto_invoke: true\n---\n\n"
                f"## Learned Patterns\n\n"
                + "\n".join(f"- {r[:200]}" for r in relevant[-5:])
            )
    except Exception:
        pass
    return None


def _generate_hooks(target: Path, framework: str, label: str = "") -> None:
    """Create project-specific hooks in .widdx/hooks.json.

    Hooks run automatically on lifecycle events:
    - PreToolUse (before each tool call — security check)
    - PostToolUse (after each tool call — lint fix)
    - TaskCompleted (after each task — session log)
    """
    hooks_file = target / ".widdx" / "hooks.json"
    if hooks_file.exists():
        return

    from widdx import ui
    hooks = {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Bash",
                    "type": "command",
                    "command": f"echo '[WIDDX] Tool: $WIDDX_TOOL'"
                }
            ],
            "PostToolUse": [
                {
                    "matcher": "Write|Edit",
                    "type": "command",
                    "command": f"echo '[WIDDX] File modified: $WIDDX_FILE_PATH'",
                    "async": True,
                }
            ],
            "TaskCompleted": [
                {
                    "type": "command",
                    "command": f"echo '[WIDDX] Task completed at %DATE% %TIME%' >> .widdx/task.log",
                    "async": True,
                }
            ],
        }
    }
    try:
        import json
        hooks_file.write_text(
            json.dumps(hooks, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        ui.get_console().print(f"  [success]✓[/] Hooks: [text].widdx/hooks.json[/]")
    except OSError:
        pass


def _generate_mcp_config(target: Path) -> None:
    """Create project-specific MCP config in .widdx/mcp.json.

    MCP servers provide additional tools to the AI:
    - project-info: read project structure
    - utility: helper tools
    - filesystem: file access (disabled — built-in tools handle this)
    """
    mcp_file = target / ".widdx" / "mcp.json"
    if mcp_file.exists():
        return

    from widdx import ui
    mcp_config = {
        "_comment": "MCP servers for this project. Enable by removing _disabled or setting to false.",
        "mcpServers": {
            "filesystem": {
                "command": "npx",
                "args": ["-y", "@anthropic/mcp-server-filesystem", "."],
                "_disabled": True,
                "_note": "Provides filesystem access tools",
            },
            "fetch": {
                "command": "npx",
                "args": ["-y", "@anthropic/mcp-server-fetch"],
                "_disabled": True,
                "_note": "Fetch and process web content",
            }
        }
    }
    try:
        import json
        mcp_file.write_text(
            json.dumps(mcp_config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        ui.get_console().print(f"  [success]✓[/] MCP: [text].widdx/mcp.json[/]")
    except OSError:
        pass


def _create_widdx_dir(target: Path, framework: str, version: str, answers: dict[str, str]) -> None:
    """Create the .widdx/ project state directory in the target project."""
    widdx_dir = target / ".widdx"
    skills_dir = widdx_dir / "skills"
    try:
        widdx_dir.mkdir(parents=True, exist_ok=True)
        skills_dir.mkdir(exist_ok=True)

        state = {
            "version": 1,
            "framework": framework,
            "framework_version": version,
            "answers": answers,
            "created_at": __import__("datetime").datetime.now().isoformat(),
        }
        (widdx_dir / "project.json").write_text(
            json.dumps(state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except OSError:
        pass


__all__ = [
    "detect_framework", "ask_questions", "scaffold",
    "ScaffoldResult", "FrameworkConfig", "ScaffoldQuestion",
]
