"""Tests for jsonrpc package."""
