from __future__ import annotations

import os
import webbrowser
from pathlib import Path

import typer
import uvicorn

cli = typer.Typer(add_completion=False, help="Portable file manager + editor.")


@cli.command()
def run(
    directory: Path = typer.Argument(
        Path.cwd(),
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
        help="Directory to serve (defaults to CWD).",
    ),
    host: str = typer.Option("127.0.0.1", help="Bind host."),
    port: int = typer.Option(8765, help="Bind port."),
    open_browser: bool = typer.Option(True, "--open/--no-open", help="Open the UI on start."),
    reload: bool = typer.Option(False, help="Enable autoreload (dev only)."),
) -> None:
    """Start the quick-file-server server and open the browser."""
    os.environ["QUICK_FILE_SERVER_ROOT"] = str(directory)
    url = f"http://{host}:{port}"
    typer.echo(f"quick-file-server serving {directory}  ->  {url}")
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    uvicorn.run(
        "quick_file_server.server:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )


def main() -> None:
    import sys
    # Strip a leading bare "run" so both `quick-file-server ...` and `quick-file-server run ...` work.
    if len(sys.argv) > 1 and sys.argv[1] == "run":
        del sys.argv[1]
    cli()


if __name__ == "__main__":
    main()
