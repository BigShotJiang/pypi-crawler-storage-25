from __future__ import annotations

import os
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

# Root directory the user invoked the tool from. Set via env so the CLI can
# inject it before the app is imported by uvicorn workers.
ROOT = Path(os.environ.get("QUICK_FILE_SERVER_ROOT", os.getcwd())).resolve()

# Static assets shipped inside the wheel: <package>/static/ (built frontend).
STATIC_DIR = Path(__file__).parent / "static"


def _safe_resolve(rel: str) -> Path:
    """Resolve a user-supplied path against ROOT, rejecting traversal."""
    candidate = (ROOT / rel).resolve() if rel else ROOT
    try:
        candidate.relative_to(ROOT)
    except ValueError:
        raise HTTPException(status_code=400, detail="Path escapes root directory")
    return candidate


class WriteBody(BaseModel):
    path: str
    content: str


def create_app() -> FastAPI:
    app = FastAPI(title="quick-file-server", version="0.1.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.get("/api/health")
    def health() -> dict[str, str]:
        return {"status": "ok", "root": str(ROOT)}

    @app.get("/api/list")
    def list_dir(path: Annotated[str, Query()] = "") -> dict:
        target = _safe_resolve(path)
        if not target.exists():
            raise HTTPException(404, "Not found")
        if not target.is_dir():
            raise HTTPException(400, "Not a directory")

        entries = []
        for child in sorted(target.iterdir(), key=lambda p: (p.is_file(), p.name.lower())):
            try:
                stat = child.stat()
            except OSError:
                continue
            entries.append({
                "name": child.name,
                "path": str(child.relative_to(ROOT)),
                "is_dir": child.is_dir(),
                "size": stat.st_size,
                "mtime": stat.st_mtime,
            })

        return {
            "path": str(target.relative_to(ROOT)) if target != ROOT else "",
            "entries": entries,
        }

    @app.get("/api/read")
    def read_file(path: Annotated[str, Query()]) -> dict:
        target = _safe_resolve(path)
        if not target.is_file():
            raise HTTPException(404, "File not found")
        if target.stat().st_size > 5 * 1024 * 1024:
            raise HTTPException(413, "File too large to edit (>5MB)")
        try:
            content = target.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            raise HTTPException(415, "Binary file — cannot edit as text")
        return {"path": path, "content": content}

    @app.get("/api/raw")
    def raw_file(path: Annotated[str, Query()]) -> FileResponse:
        target = _safe_resolve(path)
        if not target.is_file():
            raise HTTPException(404, "File not found")
        return FileResponse(target)

    @app.post("/api/write")
    def write_file(body: WriteBody) -> dict:
        target = _safe_resolve(body.path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body.content, encoding="utf-8")
        return {"path": body.path, "size": target.stat().st_size}

    @app.post("/api/upload")
    async def upload_file(
        path: Annotated[str, Query()] = "",
        file: UploadFile = File(...),
    ) -> dict:
        dest_dir = _safe_resolve(path)
        if not dest_dir.is_dir():
            raise HTTPException(400, "Destination is not a directory")
        if not file.filename:
            raise HTTPException(400, "Missing filename")
        dest = dest_dir / Path(file.filename).name
        with dest.open("wb") as fh:
            while chunk := await file.read(1024 * 1024):
                fh.write(chunk)
        return {"path": str(dest.relative_to(ROOT)), "size": dest.stat().st_size}

    @app.get("/api/zip")
    def zip_paths(paths: Annotated[list[str], Query()]) -> StreamingResponse:
        import io
        import zipfile

        if not paths:
            raise HTTPException(400, "No paths provided")

        resolved: list[tuple[Path, str]] = []
        for rel in paths:
            target = _safe_resolve(rel)
            if not target.exists():
                raise HTTPException(404, f"Not found: {rel}")
            base = target.parent
            resolved.append((target, str(base)))

        def iter_zip():
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
                for target, base in resolved:
                    base_path = Path(base)
                    if target.is_dir():
                        for sub in target.rglob("*"):
                            if sub.is_file():
                                arc = sub.relative_to(base_path)
                                zf.write(sub, arcname=str(arc))
                    else:
                        arc = target.relative_to(base_path)
                        zf.write(target, arcname=str(arc))
            buf.seek(0)
            while chunk := buf.read(1024 * 1024):
                yield chunk

        if len(resolved) == 1:
            fname = resolved[0][0].name + ".zip"
        else:
            fname = "files.zip"
        return StreamingResponse(
            iter_zip(),
            media_type="application/zip",
            headers={"Content-Disposition": f'attachment; filename="{fname}"'},
        )

    @app.delete("/api/delete")
    def delete_path(path: Annotated[str, Query()]) -> dict:
        target = _safe_resolve(path)
        if target == ROOT:
            raise HTTPException(400, "Cannot delete root")
        if target.is_dir():
            import shutil
            shutil.rmtree(target)
        else:
            target.unlink(missing_ok=True)
        return {"deleted": path}

    # Static / SPA serving — only mounted if the built bundle is present.
    if STATIC_DIR.is_dir():
        assets_dir = STATIC_DIR / "assets"
        if assets_dir.is_dir():
            app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

        index_file = STATIC_DIR / "index.html"

        @app.get("/{full_path:path}", include_in_schema=False)
        async def spa_catchall(full_path: str, request: Request):
            if full_path.startswith("api/"):
                return JSONResponse({"detail": "Not found"}, status_code=404)
            asset = STATIC_DIR / full_path
            if full_path and asset.is_file():
                return FileResponse(asset)
            if index_file.is_file():
                return FileResponse(index_file)
            return JSONResponse(
                {"detail": "Frontend bundle missing — rebuild the package."},
                status_code=500,
            )
    else:
        @app.get("/", include_in_schema=False)
        def _missing_bundle():
            return JSONResponse(
                {"detail": "Frontend not built. Run `pnpm build` in /frontend."},
                status_code=503,
            )

    return app


app = create_app()
