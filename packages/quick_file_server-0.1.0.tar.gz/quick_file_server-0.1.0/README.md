# file-tool

Portable single-command file manager + editor. FastAPI backend, React (Vite + Tailwind + Shadcn UI) frontend, shipped as one Python wheel.

## Usage

```bash
uvx file-tool              # serve the current directory
uvx file-tool /some/dir    # serve a specific directory
uvx file-tool --port 9000 --no-open
```

The browser opens to a file explorer; click files to edit, drag/click Upload to push files into the current directory.

## Build from source

```bash
# 1. Build the frontend bundle
cd frontend
pnpm install
pnpm build                 # writes frontend/dist/

# 2. Build the Python wheel (picks up frontend/dist via force-include)
cd ../backend
pip install hatch
hatch build                # writes dist/file_tool-*.whl

# 3. Publish
hatch publish              # or `twine upload dist/*`
```

The wheel ships `frontend/dist/` as `file_tool/static/`, so the installed package is self-contained — no internet or Node required at runtime.

## API

| Method | Path           | Purpose                          |
|--------|----------------|----------------------------------|
| GET    | `/api/list`    | List directory (`?path=sub/dir`) |
| GET    | `/api/read`    | Read text file                   |
| POST   | `/api/write`   | Save text file                   |
| POST   | `/api/upload`  | Multipart upload                 |
| DELETE | `/api/delete`  | Remove file or directory         |

All paths are sandboxed to the directory passed on the CLI.
