"""LaTeX generator for UDS specification documents."""

from __future__ import annotations

import io
import logging
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from udsxml2tex.rtm import RtmDocument

from jinja2 import Environment, FileSystemLoader, select_autoescape

from udsxml2tex.models import (
    DTC_SEVERITY_LEVELS,
    DTC_STATUS_BIT_DEFINITIONS,
    ISO14229_SERVICE_ORDER,
    NRC_CHECK_ORDER,
    STANDARD_NRCS,
    UDS_MESSAGE_FORMATS,
    UdsSpecification,
)
from udsxml2tex._style_presets import (
    HeaderConfig,
    StylePreset,
    _resolve_preset,
)
from udsxml2tex.boot_overlay import BootOverlay
from udsxml2tex._reprogramming import (
    has_reprogramming_data,
    render_reprogramming_section_html,
    render_reprogramming_section_md,
    render_reprogramming_section_rst,
    render_reprogramming_section_tex,
)

logger = logging.getLogger(__name__)

# Characters that need escaping in LaTeX
_LATEX_ESCAPE_MAP = {
    "&": r"\&",
    "%": r"\%",
    "$": r"\$",
    "#": r"\#",
    "_": r"\_",
    "{": r"\{",
    "}": r"\}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


def _latex_escape(text: str) -> str:
    """Escape special LaTeX characters in text."""
    if not text:
        return ""
    # Don't escape backslashes that are already LaTeX commands
    result = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "\\" and i + 1 < len(text) and text[i + 1].isalpha():
            # Likely a LaTeX command, don't escape
            result.append(ch)
        elif ch in _LATEX_ESCAPE_MAP:
            result.append(_LATEX_ESCAPE_MAP[ch])
        else:
            result.append(ch)
        i += 1
    return "".join(result)


def _strip_0x(text: str) -> str:
    """Strip '0x' or '0X' prefix from hex string for subscript-16 notation."""
    if isinstance(text, str) and text.lower().startswith("0x"):
        return text[2:]
    return str(text)


# ---------------------------------------------------------------------------
# Drive / Boot domain helpers
# ---------------------------------------------------------------------------
# Generic labels used in every output format. No vendor / OEM / brand names.
# The long labels are used in tex/html/md/rst/docx; the short labels are
# used in CSV (single column-friendly tokens).

DOMAIN_LABELS_LONG: dict[str, str] = {
    "drive": "App",
    "boot": "Boot",
    "both": "Both",
}

DOMAIN_LABELS_SHORT: dict[str, str] = {
    "drive": "D",
    "boot": "B",
    "both": "D/B",
}

# CSS class applied to HTML rows whose item.domain == "boot" so a stylesheet
# can highlight the row. The selector is defined in :data:`_HTML_CSS`.
BOOT_ROW_HTML_CLASS: str = "boot-only"


def _domain_label(domain: str, short: bool = False) -> str:
    """Return a human-readable label for a domain marker.

    ``domain`` is one of ``"drive"``, ``"boot"``, ``"both"`` (anything else
    falls back to ``"App"`` / ``"D"`` so a freshly-parsed spec without an
    overlay always renders as drive-only).
    """
    table = DOMAIN_LABELS_SHORT if short else DOMAIN_LABELS_LONG
    return table.get(domain, table["drive"])


def _should_show_domain(spec: "UdsSpecification") -> bool:
    """Return True when ``spec`` contains at least one non-drive item.

    Used by the ``"auto"`` mode to decide whether the Domain column adds
    information. A freshly parsed spec (no boot overlay applied) returns
    False so the column stays out of the way.
    """
    iterables = (
        getattr(spec, "sessions", []) or [],
        getattr(spec, "services", []) or [],
        getattr(spec, "dids", []) or [],
        getattr(spec, "routines", []) or [],
    )
    for items in iterables:
        for item in items:
            if getattr(item, "domain", "drive") != "drive":
                return True
    return False


def _resolve_show_domain(spec: "UdsSpecification", show_domain: str) -> bool:
    """Resolve a ``--show-domain`` flag value to a concrete bool.

    Accepts ``"auto"`` (default), ``"always"``, ``"never"`` and any value
    pytho-truthy enough to coerce. Unknown strings fall back to ``"auto"``.
    """
    mode = (show_domain or "auto").strip().lower()
    if mode == "always":
        return True
    if mode == "never":
        return False
    # ``auto`` and anything else: show only when any non-drive item exists.
    return _should_show_domain(spec)


class TexGenerator:
    """Generate LaTeX documents from UDS specification data."""

    def __init__(
        self,
        template_dir: Optional[str | Path] = None,
        *,
        style_preset: "Optional[str | StylePreset]" = None,
        header_config: Optional[HeaderConfig] = None,
    ) -> None:
        """Initialize the TeX generator.

        Args:
            template_dir: Directory containing Jinja2 templates.
                         Defaults to the built-in templates directory.
            style_preset: Optional style preset name or
                :class:`StylePreset` object. When supplied, the master
                template includes the preset's ``header.tex.j2`` and
                ``titlepage.tex.j2`` snippets.
            header_config: Optional :class:`HeaderConfig` carrying the
                content the preset templates render — company name,
                author, logo, etc. Defaults to
                :func:`empty_header_config` when ``None``.
        """
        if template_dir is None:
            template_dir = Path(__file__).parent / "templates"
        else:
            template_dir = Path(template_dir)

        self.template_dir = template_dir
        self.style_preset = _resolve_preset(style_preset)
        self.header_config = header_config
        self.env = Environment(
            loader=FileSystemLoader(str(template_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        # Register custom filters
        self.env.filters["latex_escape"] = _latex_escape
        self.env.filters["strip_0x"] = _strip_0x
        self.env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

    def generate(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.tex.j2",
        *,
        extra_vars: Optional[dict] = None,
        show_domain: str = "auto",
        overlay: Optional[BootOverlay] = None,
        lang: str = "en",
        rtm: Optional["RtmDocument"] = None,
    ) -> Path:
        """Generate a LaTeX document from the UDS specification.

        Args:
            spec:          The UDS specification data.
            output_path:   Path for the output .tex file.
            template_name: Name of the Jinja2 template to use.
            extra_vars:    Optional dict merged into the Jinja2 template context,
                           enabling project-specific variables in custom templates.
            show_domain:   ``"auto"`` (default) shows the Drive/Boot/Both
                           Domain column only when an overlay has marked at
                           least one item as non-drive. ``"always"`` forces the
                           column, ``"never"`` hides it.
            overlay:       Optional :class:`BootOverlay`. When supplied and it
                           carries reprogramming-relevant data, a
                           ``Bootloader / Reprogramming`` chapter is appended
                           just before ``\\end{document}``.
            lang:          Language code for bootloader-section translations.

        Returns:
            Path to the generated .tex file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        context = self._build_context(spec, show_domain=show_domain)
        context["overlay_repro_section"] = (
            render_reprogramming_section_tex(overlay, lang=lang)
            if has_reprogramming_data(overlay)
            else ""
        )
        context["rtm"] = rtm
        if extra_vars:
            context.update(extra_vars)

        template = self.env.get_template(template_name)
        rendered = template.render(**context)
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated LaTeX document: %s", output_path)

        for asset in ("tikz-uml.sty", "udsspec.cls"):
            src = self.template_dir / asset
            if src.exists():
                dst = output_path.parent / asset
                if not dst.exists():
                    shutil.copy2(src, dst)
                    logger.info("Copied %s to %s", asset, dst)

        return output_path

    def generate_string(
        self,
        spec: UdsSpecification,
        template_name: str = "uds_spec.tex.j2",
        *,
        show_domain: str = "auto",
        overlay: Optional[BootOverlay] = None,
        lang: str = "en",
    ) -> str:
        """Generate LaTeX content as a string.

        Args:
            spec: The UDS specification data.
            template_name: Name of the Jinja2 template to use.
            show_domain: ``"auto"`` | ``"always"`` | ``"never"`` — controls
                whether the Drive/Boot Domain column is emitted. See
                :meth:`generate` for details.
            overlay: Optional :class:`BootOverlay` to append a Bootloader
                section to the rendered string.
            lang: Language code for bootloader-section translations.

        Returns:
            Rendered LaTeX content.
        """
        context = self._build_context(spec, show_domain=show_domain)
        context["overlay_repro_section"] = (
            render_reprogramming_section_tex(overlay, lang=lang)
            if has_reprogramming_data(overlay)
            else ""
        )
        template = self.env.get_template(template_name)
        return template.render(**context)

    def _build_context(
        self,
        spec: UdsSpecification,
        *,
        show_domain: str = "auto",
    ) -> dict:
        """Build the shared Jinja2 template context from a UdsSpecification."""
        services = sorted(
            spec.services,
            key=lambda s: ISO14229_SERVICE_ORDER.get(s.service_id, 100),
        )
        dids = sorted(spec.dids, key=lambda d: d.did_id)
        routines = sorted(spec.routines, key=lambda r: r.routine_id)
        sessions = sorted(spec.sessions, key=lambda s: s.session_id)
        security_levels = sorted(spec.security_levels, key=lambda s: s.security_level)

        transport_config = spec.transport_config
        cantp_channels = transport_config.channels if transport_config else []

        session_names = sorted({n for s in services for n in s.supported_sessions})
        security_level_names = sorted(
            {n for s in services for n in s.required_security_levels}
        )

        show_domain_bool = _resolve_show_domain(spec, show_domain)

        return {
            "ecu_name": spec.ecu_name,
            "description": spec.description,
            "protocol_name": spec.protocol_name,
            "protocol_type": spec.protocol_type,
            "can_rx_id": spec.can_rx_id,
            "can_tx_id": spec.can_tx_id,
            "can_functional_id": spec.can_functional_id,
            "s3_server": spec.s3_server,
            "dsl_rx_buffer_size": spec.dsl_rx_buffer_size,
            "dsl_tx_buffer_size": spec.dsl_tx_buffer_size,
            "sessions": sessions,
            "security_levels": security_levels,
            "services": services,
            "dids": dids,
            "routines": routines,
            "dtcs": sorted(spec.dtcs, key=lambda d: d.dtc_id),
            "memory_ranges": spec.memory_ranges,
            "io_control_dids": sorted(spec.io_control_dids, key=lambda d: d.did_id),
            "periodic_dids": sorted(spec.periodic_dids, key=lambda d: d.did_id),
            "did_ranges": sorted(spec.did_ranges, key=lambda d: d.lower_did),
            "transport_config": transport_config,
            "cantp_channels": cantp_channels,
            "message_formats": UDS_MESSAGE_FORMATS,
            "nrc_check_order": NRC_CHECK_ORDER,
            "standard_nrcs": STANDARD_NRCS,
            "session_names": session_names,
            "security_level_names": security_level_names,
            "com_control": spec.com_control,
            "response_on_event": spec.response_on_event,
            "dtc_status_availability_mask": spec.dtc_status_availability_mask,
            "max_num_resp_pend": spec.max_num_resp_pend,
            "max_response_length": spec.max_response_length,
            "request_file_transfer": spec.request_file_transfer,
            "clear_dtc_notifications": spec.clear_dtc_notifications,
            "dynamic_dids": sorted(spec.dynamic_dids, key=lambda d: d.did_id),
            "connection_mode": spec.connection_mode,
            "connection_end_of_type": spec.connection_end_of_type,
            "cdtc_status_mask": spec.cdtc_status_mask,
            "clear_dtc_group": spec.clear_dtc_group,
            "module_main_function_period": spec.module_main_function_period,
            "enable_fim_trigger": spec.enable_fim_trigger,
            "protocol_priority": spec.protocol_priority,
            "protocol_trans_type": spec.protocol_trans_type,
            "protocol_preempt_timeout": spec.protocol_preempt_timeout,
            "periodic_slow_rate": spec.periodic_slow_rate,
            "periodic_medium_rate": spec.periodic_medium_rate,
            "periodic_fast_rate": spec.periodic_fast_rate,
            "diag_resp_on_second_declined_request": spec.diag_resp_on_second_declined_request,
            "dsd_rx_buffer_size": spec.dsd_rx_buffer_size,
            "dsl_buffers": spec.dsl_buffers,
            "memory_compression_method": spec.memory_compression_method,
            "memory_encrypting_method": spec.memory_encrypting_method,
            "dev_error_detect": spec.dev_error_detect,
            "version_info_api": spec.version_info_api,
            "task_time": spec.task_time,
            "respond_all_request": spec.respond_all_request,
            "protocol_rows": sorted(spec.protocol_rows, key=lambda r: r.priority),
            "authentication_config": spec.authentication_config,
            "access_timing_rows": spec.access_timing_rows,
            # DEM (Diagnostic Event Manager)
            "dem_general": spec.dem_general,
            "dem_operation_cycles": spec.dem_operation_cycles,
            "dem_event_parameters": sorted(
                spec.dem_event_parameters, key=lambda e: e.event_id
            ),
            "dem_indicators": spec.dem_indicators,
            "dem_enable_conditions": spec.dem_enable_conditions,
            "dem_storage_conditions": spec.dem_storage_conditions,
            "dem_event_memories": spec.dem_event_memories,
            "dem_dtcs": sorted(spec.dem_dtcs, key=lambda d: d.dtc_value),
            "dem_freeze_frame_classes": spec.dem_freeze_frame_classes,
            "dem_extended_data_classes": sorted(
                spec.dem_extended_data_classes, key=lambda e: e.record_number
            ),
            "dem_combined_dtcs": sorted(
                spec.dem_combined_dtcs, key=lambda d: d.combined_dtc_value
            ),
            # ISO 14229-1 constant tables for template rendering
            "dtc_status_bit_definitions": DTC_STATUS_BIT_DEFINITIONS,
            "dtc_severity_levels": DTC_SEVERITY_LEVELS,
            # Upload/Download max block length (ISO 14229-1 §13)
            "max_block_length": spec.max_block_length,
            # LinkControl (0x87) supported baud rates
            "link_control_baudrates": sorted(
                spec.link_control_baudrates, key=lambda b: b.baudrate_value
            ),
            # Named DTC groups (DcmDspGroupOfDTC)
            "dtc_groups": sorted(spec.dtc_groups, key=lambda g: g.group_value),
            # TikZ diagrams (non-standalone figures for inclusion)
            "session_state_diagram": _build_session_state_tikz(sessions, spec.s3_server),
            "nrc_flowcharts": {
                f"0x{svc.service_id:02X}": _build_nrc_flowchart_tikz(svc)
                for svc in services
            },
            # Drive / Boot domain column (resolved boolean + label helpers
            # for Jinja templates). Generic labels only — never brand names.
            "show_domain": show_domain_bool,
            "domain_label": _domain_label,
            "domain_labels_long": DOMAIN_LABELS_LONG,
            "domain_labels_short": DOMAIN_LABELS_SHORT,
            # Style preset / header config — both may be None when the
            # caller has not customised presentation. Templates branch
            # on `style_preset is defined and style_preset` / `header
            # is defined and header`. No brand-name defaults.
            "style_preset": self.style_preset,
            "header": self.header_config,
        }

    # ---- PDF compilation ------------------------------------------------

    def compile_pdf(
        self,
        tex_path: str | Path,
        *,
        clean: bool = True,
    ) -> Path:
        """Compile a .tex file to PDF using latexmk or pdflatex.

        Args:
            tex_path: Path to the .tex file.
            clean: Remove auxiliary files after compilation.

        Returns:
            Path to the generated PDF.

        Raises:
            FileNotFoundError: If no LaTeX compiler is found.
            RuntimeError: If compilation fails.
        """
        tex_path = Path(tex_path).resolve()
        if not tex_path.exists():
            raise FileNotFoundError(f"TeX file not found: {tex_path}")

        work_dir = tex_path.parent

        # Detect whether the source needs XeTeX (e.g. xeCJK for Japanese).
        # Templates emitted by udsxml2tex use xeCJK, so xelatex is required
        # whenever it is available; pdflatex is only a fallback for
        # ASCII-only sources.
        needs_xetex = False
        try:
            head = tex_path.read_text(
                encoding="utf-8", errors="ignore"
            )[:8192]
            needs_xetex = (
                "xeCJK" in head
                or "fontspec" in head
                or "\\XeTeXinputencoding" in head
            )
        except OSError:
            pass

        latexmk = shutil.which("latexmk")
        xelatex = shutil.which("xelatex")
        pdflatex = shutil.which("pdflatex")

        clean_cmd = None
        if latexmk and (xelatex or not needs_xetex):
            engine_flag = "-xelatex" if (needs_xetex and xelatex) else "-pdf"
            cmd = [
                latexmk,
                engine_flag,
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
            if clean:
                clean_cmd = [latexmk, "-c", str(tex_path.name)]
        elif needs_xetex and xelatex:
            cmd = [
                xelatex,
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
        elif pdflatex:
            cmd = [
                pdflatex,
                "-interaction=nonstopmode",
                "-halt-on-error",
                str(tex_path.name),
            ]
        else:
            raise FileNotFoundError(
                "No LaTeX compiler found. Install TeX Live or MiKTeX "
                "(latexmk, xelatex, or pdflatex must be on PATH)."
            )

        logger.info("Compiling PDF: %s", " ".join(cmd))
        runs = 1 if cmd[0] == latexmk else 2
        for i in range(runs):
            result = subprocess.run(
                cmd,
                cwd=str(work_dir),
                capture_output=True,
                text=True,
                timeout=300,
            )
            if result.returncode != 0:
                logger.error("LaTeX stdout:\n%s", result.stdout[-2000:])
                logger.error("LaTeX stderr:\n%s", result.stderr[-2000:])
                log_path = tex_path.with_suffix(".log")
                log_excerpt = ""
                if log_path.exists():
                    try:
                        log_text = log_path.read_text(
                            encoding="utf-8", errors="replace"
                        )
                        first_error = log_text.find("\n! ")
                        if first_error != -1:
                            log_excerpt = log_text[
                                first_error : first_error + 800
                            ]
                    except OSError:
                        pass
                detail = (
                    f"LaTeX compilation failed (exit {result.returncode}). "
                )
                if log_excerpt:
                    detail += (
                        f"First error from {log_path.name}: "
                        f"{log_excerpt.strip()}"
                    )
                else:
                    detail += f"Check {log_path.name} for details."
                raise RuntimeError(detail)

        pdf_path = tex_path.with_suffix(".pdf")
        if not pdf_path.exists():
            raise RuntimeError(f"Expected PDF not found: {pdf_path}")

        # Clean auxiliary files
        if clean and latexmk and clean_cmd:
            subprocess.run(clean_cmd, cwd=str(work_dir), capture_output=True)

        logger.info("PDF generated: %s", pdf_path)
        return pdf_path

    # ---- HTML generation ------------------------------------------------

    def generate_html(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        template_name: str = "uds_spec.html.j2",
        *,
        show_domain: str = "auto",
        overlay: Optional[BootOverlay] = None,
        lang: str = "en",
    ) -> Path:
        """Generate an HTML document from the UDS specification.

        Args:
            spec: The UDS specification data.
            output_path: Path for the output .html file.
            template_name: Name of the HTML Jinja2 template.
            show_domain: ``"auto"`` | ``"always"`` | ``"never"`` — controls
                whether the Drive/Boot Domain column is emitted. See
                :meth:`generate` for details.
            overlay:     Optional :class:`BootOverlay`. When supplied and it
                         carries reprogramming-relevant data, a Bootloader
                         section is appended before ``</body>``.
            lang:        Language code for bootloader-section translations.

        Returns:
            Path to the generated .html file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Create a separate Jinja2 environment with standard delimiters for HTML
        html_env = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        html_env.filters["strip_0x"] = _strip_0x

        def _html_hex(value: str) -> str:
            """Render hex value with subscript-16 notation in HTML."""
            v = _strip_0x(str(value))
            return f'<span class="hexval">{v}<sub>16</sub></span>'

        html_env.filters["hexval"] = _html_hex

        context = self._build_context(spec, show_domain=show_domain)
        context["overlay_repro_section"] = (
            render_reprogramming_section_html(overlay, lang=lang)
            if has_reprogramming_data(overlay)
            else ""
        )

        template = html_env.get_template(template_name)
        rendered = template.render(**context)
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated HTML document: %s", output_path)
        return output_path

    # ---- Structured multi-file LaTeX ZIP --------------------------------

    def generate_structured_tex_zip(
        self,
        spec: "UdsSpecification",
        output_path: "str | Path",
        cls_content: Optional[bytes] = None,
        *,
        show_domain: str = "auto",
        overlay: Optional[BootOverlay] = None,
        lang: str = "en",
        rtm: Optional["RtmDocument"] = None,
    ) -> Path:
        """Generate a structured multi-file LaTeX project and package it as a ZIP.

        The ZIP mirrors the layout of refs/uds-tex-spec with root.tex plus
        nested sections/, and optionally includes a custom .cls file.

        Args:
            spec: Parsed UDS specification.
            output_path: Destination path for the output ZIP file.
            cls_content: Raw bytes of an optional custom LaTeX class file to
                         include as ``custom.cls`` in the ZIP root.
            overlay: Optional :class:`BootOverlay`. When supplied with
                     reprogramming data, a bootloader section is included.
            lang: Language code for bootloader-section translations.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        structured_dir = Path(__file__).parent / "templates" / "structured_tex"

        # Build a Jinja2 environment pointing at structured_tex/
        from jinja2 import Environment, FileSystemLoader

        tex_env = Environment(
            loader=FileSystemLoader(str(structured_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )
        tex_env.filters["latex_escape"] = _latex_escape
        tex_env.filters["strip_0x"] = _strip_0x
        tex_env.filters["bitand"] = lambda value, mask: bool(int(value) & int(mask))

        context = self._build_context(spec, show_domain=show_domain)
        context["overlay_repro_section"] = (
            render_reprogramming_section_tex(overlay, lang=lang)
            if has_reprogramming_data(overlay)
            else ""
        )
        context["rtm"] = rtm

        # Gather all .j2 template files relative to structured_dir
        template_files = sorted(structured_dir.rglob("*.j2"))

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            for tmpl_path in template_files:
                rel = tmpl_path.relative_to(structured_dir)
                # Strip the .j2 extension to get the output filename
                out_rel = rel.with_suffix("")  # e.g. root.tex.j2 -> root.tex
                out_path = tmp / out_rel
                out_path.parent.mkdir(parents=True, exist_ok=True)

                template = tex_env.get_template(str(rel).replace("\\", "/"))
                rendered = template.render(**context)
                out_path.write_text(rendered, encoding="utf-8")
                logger.debug("Rendered structured template: %s", out_rel)

            # Copy tikz-uml.sty to zip root
            sty_src = Path(__file__).parent / "templates" / "tikz-uml.sty"
            if sty_src.exists():
                shutil.copy2(sty_src, tmp / "tikz-uml.sty")

            # Empty bibliography placeholder so biber doesn't fail when the
            # template's \addbibresource{reference.bib} fires.
            ref_bib = tmp / "reference.bib"
            if not ref_bib.exists():
                ref_bib.write_text(
                    "% Placeholder bibliography (auto-generated)\n",
                    encoding="utf-8",
                )

            # Optionally write custom .cls file
            if cls_content is not None:
                (tmp / "custom.cls").write_bytes(cls_content)

            # Build the ZIP
            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))

        logger.info("Generated structured LaTeX ZIP: %s", output_path)
        return output_path

    # ---- Multi-page HTML ZIP --------------------------------------------

    def generate_html_zip(
        self,
        spec: "UdsSpecification",
        output_path: "str | Path",
        *,
        show_domain: str = "auto",
    ) -> Path:
        """Generate a browsable multi-page HTML UDS specification and ZIP it.

        Creates index.html plus per-section HTML pages that can be opened
        locally in any browser.

        Args:
            spec: Parsed UDS specification.
            output_path: Destination path for the output ZIP file.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        ctx = self._build_context(spec, show_domain=show_domain)
        services = ctx.get("services", [])

        # Build per-service nav children
        svc_children = []
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            svc_children.append({
                "path": path,
                "title": f"§5.{i} {svc.short_name}",
                "children": [],
            })

        # Build per-service nav children (no section numbers — just service names)
        svc_children = []
        for svc in services:
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            svc_children.append({
                "path": path,
                "title": svc.short_name,
                "children": [],
            })

        # Navigation tree mirroring the structured LaTeX sections/ layout
        # (section numbers omitted from titles — they're just visual noise here)
        nav_tree = [
            {"path": "index.html", "title": "Overview", "children": []},
            {"path": "sections/0_intro/index.html", "title": "Introduction", "children": []},
            {"path": "sections/1_low_layer/index.html", "title": "Network Protocol Layers",
             "children": [
                 {"path": "sections/1_low_layer/2_datalink/index.html",  "title": "Data Link",  "children": []},
                 {"path": "sections/1_low_layer/3_network/index.html",   "title": "Network",    "children": []},
                 {"path": "sections/1_low_layer/4_transport/index.html", "title": "Transport",  "children": []},
                 {"path": "sections/1_low_layer/5_session/index.html",   "title": "Session",    "children": []},
             ]},
            {"path": "sections/2_high_layer/index.html", "title": "Application Layers",
             "children": svc_children},
            {"path": "sections/A_annex/index.html", "title": "Annex", "children": []},
        ]

        # Flat ordered page list: (path, title, renderer)
        pages: list[tuple[str, str, object]] = [
            ("index.html",                                          "Overview",                   _render_html_index),
            ("sections/0_intro/index.html",                        "Introduction",               _render_html_intro),
            ("sections/1_low_layer/index.html",                    "Network Protocol Layers",    _render_html_low_layer_index),
            ("sections/1_low_layer/2_datalink/index.html",         "Data Link Layer",  _render_html_low_datalink),
            ("sections/1_low_layer/3_network/index.html",          "Network Layer",    _render_html_low_network),
            ("sections/1_low_layer/4_transport/index.html",        "Transport Layer",  _render_html_low_transport),
            ("sections/1_low_layer/5_session/index.html",          "Session Layer",    _render_html_low_session),
            ("sections/2_high_layer/index.html",                   "Application Layers", _render_html_high_overview),
        ]
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            title = svc.short_name
            pages.append((path, title, lambda c, s=svc, idx=i: _render_html_service_page(c, s, idx)))
        pages.append(("sections/A_annex/index.html", "Annex", _render_html_annex))

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)

            # Bundled mermaid.min.js (offline-renderable diagrams).
            # Copy once into assets/ at the zip root; pages link to it via
            # a relative URL computed per-page.
            assets_dir = tmp / "assets"
            assets_dir.mkdir(parents=True, exist_ok=True)
            try:
                from importlib.resources import files as _ir_files
                mermaid_src = _ir_files("udsxml2tex").joinpath(
                    "templates", "assets", "mermaid.min.js"
                )
                (assets_dir / "mermaid.min.js").write_bytes(mermaid_src.read_bytes())
                _has_mermaid = True
            except Exception as exc:  # noqa: BLE001
                logger.warning("mermaid.min.js not bundled: %s", exc)
                _has_mermaid = False

            for page_path, title, renderer in pages:
                nav_html   = _build_nav_html(nav_tree, page_path)
                page_ctx   = {**ctx, "_current_path": page_path}
                body       = renderer(page_ctx)
                mermaid_rel = (
                    _relpath(page_path, "assets/mermaid.min.js")
                    if _has_mermaid else None
                )
                page_html  = _html_page(
                    title, nav_html, body, _HTML_CSS,
                    mermaid_rel_path=mermaid_rel,
                )
                out_file   = tmp / Path(page_path)
                out_file.parent.mkdir(parents=True, exist_ok=True)
                out_file.write_text(page_html, encoding="utf-8")

            with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for f in sorted(tmp.rglob("*")):
                    if f.is_file():
                        zf.write(f, f.relative_to(tmp))

        logger.info("Generated HTML ZIP: %s", output_path)
        return output_path

    # ---- JSON / YAML output ---------------------------------------------

    def generate_json(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Serialize the specification to JSON."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(spec.to_json(), encoding="utf-8")
        logger.info("Generated JSON document: %s", output_path)
        return output_path

    def generate_yaml(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Serialize the specification to YAML."""
        try:
            import yaml  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "PyYAML is required for YAML output. "
                "Install it with: pip install udsxml2tex[yaml]"
            )
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            yaml.dump(spec.to_dict(), allow_unicode=True, default_flow_style=False),
            encoding="utf-8",
        )
        logger.info("Generated YAML document: %s", output_path)
        return output_path

    # ---- Markdown output ------------------------------------------------

    def generate_markdown(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        *,
        overlay: Optional[BootOverlay] = None,
        lang: str = "en",
        show_domain: str = "auto",
    ) -> Path:
        """Generate a Markdown specification document.

        When ``overlay`` carries reprogramming-relevant data, a
        ``## Bootloader`` section is appended to the output.

        ``show_domain`` (``"auto"`` | ``"always"`` | ``"never"``) controls
        whether the Drive/Boot Domain column is emitted in the body tables.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        body = _render_markdown(
            spec,
            show_domain=_resolve_show_domain(spec, show_domain),
        )
        if has_reprogramming_data(overlay):
            section = render_reprogramming_section_md(overlay, lang=lang)
            if section:
                # ensure a blank-line separator before the appended section
                body = body.rstrip() + "\n\n" + section
        output_path.write_text(body, encoding="utf-8")
        logger.info("Generated Markdown document: %s", output_path)
        return output_path

    # ---- RST output -----------------------------------------------------

    def generate_rst(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        *,
        overlay: Optional[BootOverlay] = None,
        lang: str = "en",
        show_domain: str = "auto",
    ) -> Path:
        """Generate a reStructuredText specification document.

        When ``overlay`` carries reprogramming-relevant data, a Bootloader
        section is appended to the output.

        ``show_domain`` (``"auto"`` | ``"always"`` | ``"never"``) controls
        whether the Drive/Boot Domain column is emitted in the body tables.
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        body = _render_rst(
            spec,
            show_domain=_resolve_show_domain(spec, show_domain),
        )
        if has_reprogramming_data(overlay):
            section = render_reprogramming_section_rst(overlay, lang=lang)
            if section:
                body = body.rstrip() + "\n\n" + section
        output_path.write_text(body, encoding="utf-8")
        logger.info("Generated RST document: %s", output_path)
        return output_path

    # ---- Bootloader reprogramming -------------------------------------------

    def render_reprogramming(
        self,
        overlay: BootOverlay,
        fmt: str = "tex",
        *,
        lang: str = "en",
    ) -> str:
        """Return a rendered Bootloader reprogramming section.

        Args:
            overlay: A :class:`BootOverlay` carrying bootloader data.
            fmt:     ``"tex"`` | ``"html"`` | ``"md"`` | ``"rst"``.
            lang:    Language code (defaults to ``"en"``).

        Returns:
            The rendered fragment. Returns an empty string when the overlay
            has no reprogramming-relevant data.
        """
        fmt_low = (fmt or "tex").lower()
        if fmt_low in ("tex", "latex"):
            return render_reprogramming_section_tex(overlay, lang=lang)
        if fmt_low == "html":
            return render_reprogramming_section_html(overlay, lang=lang)
        if fmt_low in ("md", "markdown"):
            return render_reprogramming_section_md(overlay, lang=lang)
        if fmt_low == "rst":
            return render_reprogramming_section_rst(overlay, lang=lang)
        raise ValueError(
            f"unknown reprogramming format {fmt!r}; "
            f"expected one of 'tex', 'html', 'md', 'rst'"
        )

    def write_reprogramming(
        self,
        overlay: BootOverlay,
        output_path: str | Path,
        fmt: str = "tex",
        *,
        lang: str = "en",
    ) -> Path:
        """Render and write the Bootloader reprogramming section to disk.

        Args:
            overlay:     A :class:`BootOverlay` carrying bootloader data.
            output_path: Destination path.
            fmt:         ``"tex"`` | ``"html"`` | ``"md"`` | ``"rst"``.
            lang:        Language code (defaults to ``"en"``).

        Returns:
            The output path (created with parent directories as needed).
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        rendered = self.render_reprogramming(overlay, fmt, lang=lang)
        output_path.write_text(rendered, encoding="utf-8")
        logger.info("Generated reprogramming fragment (%s): %s", fmt, output_path)
        return output_path

    # ---- CSV output -----------------------------------------------------

    def generate_csv(
        self,
        spec: UdsSpecification,
        output_dir: str | Path,
        *,
        show_domain: str = "auto",
    ) -> list[Path]:
        """Generate CSV files (one per major category) in *output_dir*.

        Args:
            spec: Parsed UDS specification.
            output_dir: Destination directory (created if missing).
            show_domain: ``"auto"`` | ``"always"`` | ``"never"`` — when the
                Drive/Boot Domain column should be added. See
                :meth:`generate` for details.

        Returns:
            List of paths to the generated CSV files.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        return _render_csv(
            spec, output_dir,
            show_domain=_resolve_show_domain(spec, show_domain),
        )

    # ---- Session state-machine diagram ----------------------------------

    def generate_session_diagram(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
    ) -> Path:
        """Generate a standalone TikZ session-transition diagram (.tex)."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(_render_session_tikz(spec), encoding="utf-8")
        logger.info("Generated session diagram: %s", output_path)
        return output_path

    # ---- DOCX output ----------------------------------------------------

    def generate_docx(
        self,
        spec: UdsSpecification,
        path: "str | Path",
        *,
        show_domain: str = "auto",
    ) -> Path:
        """Generate a DOCX document from the UDS specification.

        Requires: pip install udsxml2tex[docx]

        ``show_domain`` (``"auto"`` | ``"always"`` | ``"never"``) controls
        whether the Drive/Boot Domain column is emitted.
        """
        try:
            from docx import Document  # type: ignore[import] # noqa: F401
            from docx.shared import Pt, RGBColor  # type: ignore[import] # noqa: F401
            from docx.enum.text import WD_ALIGN_PARAGRAPH  # type: ignore[import] # noqa: F401
        except ImportError as exc:
            raise ImportError(
                "python-docx is required for DOCX output. "
                "Install with: pip install udsxml2tex[docx]"
            ) from exc
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        _render_docx(
            spec, path,
            show_domain=_resolve_show_domain(spec, show_domain),
        )
        logger.info("Generated DOCX document: %s", path)
        return path

    # ---- UML sequence diagrams ------------------------------------------

    def generate_sequence_diagrams(
        self,
        spec: UdsSpecification,
        output_dir: "str | Path",
    ) -> "list[Path]":
        """Generate TikZ sequence diagram .tex files into *output_dir*.

        Creates:
          - security_access_sequence.tex
          - routine_control_sequence.tex
          - upload_download_sequence.tex

        Returns:
            List of Path objects for the generated files.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        written: list[Path] = []

        # 1. SecurityAccess flow
        sa_participants = ["Tester", "ECU"]
        sa_messages = [
            ("Tester", "ECU", "Request Seed (27 01)", ""),
            ("ECU", "Tester", "Seed Response (67 01 seed...)", ""),
            ("Tester", "ECU", "Send Key (27 02 key...)", ""),
            ("ECU", "Tester", "Positive Response (67 02)", ""),
            ("ECU", "Tester", "NRC: invalidKey (35)", "dashed"),
            ("ECU", "Tester", "NRC: exceededNumberOfAttempts (36)", "dashed"),
            ("ECU", "Tester", "NRC: requiredTimeDelayNotExpired (37)", "dashed"),
        ]
        sa_path = output_dir / "security_access_sequence.tex"
        sa_path.write_text(
            _render_sequence_tikz("SecurityAccess Flow", sa_participants, sa_messages),
            encoding="utf-8",
        )
        written.append(sa_path)

        # 2. RoutineControl flow
        rc_participants = ["Tester", "ECU"]
        rc_messages = [
            ("Tester", "ECU", "Start Routine (31 01 routineId...)", ""),
            ("ECU", "Tester", "Positive Response (71 01 routineId...)", ""),
            ("Tester", "ECU", "Request Routine Results (31 03 routineId...)", ""),
            ("ECU", "Tester", "Results (71 03 routineId... statusRecord)", ""),
        ]
        rc_path = output_dir / "routine_control_sequence.tex"
        rc_path.write_text(
            _render_sequence_tikz("RoutineControl Flow", rc_participants, rc_messages),
            encoding="utf-8",
        )
        written.append(rc_path)

        # 3. Upload/Download flow
        ud_participants = ["Tester", "ECU"]
        ud_messages = [
            ("Tester", "ECU", "Request Download (34)", ""),
            ("ECU", "Tester", "maxBlockLength Response (74)", ""),
            ("Tester", "ECU", "Transfer Data [1] (36 01 data...)", ""),
            ("ECU", "Tester", "Transfer Data Response (76 01)", ""),
            ("Tester", "ECU", "... [loop] Transfer Data [N] (36 N data...)", ""),
            ("ECU", "Tester", "Transfer Data Response [N] (76 N)", ""),
            ("Tester", "ECU", "Request Transfer Exit (37)", ""),
            ("ECU", "Tester", "Positive Response (77)", ""),
        ]
        ud_path = output_dir / "upload_download_sequence.tex"
        ud_path.write_text(
            _render_sequence_tikz("Upload/Download Flow", ud_participants, ud_messages),
            encoding="utf-8",
        )
        written.append(ud_path)

        logger.info("Generated %d sequence diagram(s) in %s", len(written), output_dir)
        return written

    # ---- Byte-level visualization (bytefield) ----------------------------

    def generate_byte_diagrams(
        self,
        spec: UdsSpecification,
        output_dir: "str | Path",
    ) -> Path:
        """Generate did_byte_fields.tex using LaTeX bytefield package.

        Only DIDs with at least one data element are included.

        Returns:
            Path to the generated did_byte_fields.tex file.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        lines: list[str] = [
            r"% DID byte-field diagrams — generated by udsxml2tex",
            r"% Requires the 'bytefield' LaTeX package.",
            r"",
        ]
        for did in sorted(spec.dids, key=lambda d: d.did_id):
            if not did.data_elements:
                continue
            lines.append(_render_bytefield_did(did))

        out_path = output_dir / "did_byte_fields.tex"
        out_path.write_text("\n".join(lines), encoding="utf-8")
        logger.info("Generated byte-field diagrams: %s", out_path)
        return out_path

    # ---- Unified generate_format() entry point --------------------------

    def generate_changelog_chapter(
        self,
        spec_old: UdsSpecification,
        spec_new: UdsSpecification,
        output_path: str | Path,
        *,
        fmt: str = "tex",
        old_label: str = "Previous",
        new_label: str = "Current",
        lang: str = "en",
        chapter: bool = True,
    ) -> Path:
        """Diff two specs and write a standalone change-history document.

        Args:
            spec_old: Baseline UDS specification.
            spec_new: New UDS specification to compare against baseline.
            output_path: Destination file path.
            fmt: ``"tex"`` (default), ``"html"``, or ``"md"``.
            old_label: Label for the baseline version (used in heading).
            new_label: Label for the new version (used in heading).
            lang: Language code for translated headings (``en`` | ``ja`` | ``de``).
            chapter: LaTeX only — emit ``\\chapter`` (True) or ``\\section`` (False).
        """
        from udsxml2tex.diff import SpecDiffer

        diff = SpecDiffer().diff(spec_old, spec_new)
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)

        fmt = fmt.lower()
        if fmt == "tex":
            content = diff.to_latex(
                chapter=chapter, old_label=old_label, new_label=new_label, lang=lang,
            )
            out = out.with_suffix(".tex")
        elif fmt == "html":
            section = diff.to_html_section(old_label=old_label, new_label=new_label, lang=lang)
            content = (
                "<!DOCTYPE html>\n<html><head><meta charset='UTF-8'>"
                "<title>Change History</title></head><body>\n"
                + section
                + "</body></html>\n"
            )
            out = out.with_suffix(".html")
        elif fmt == "md":
            content = diff.to_markdown()
            out = out.with_suffix(".md")
        else:
            raise ValueError(f"Unsupported changelog format: {fmt!r}. Use tex, html, or md.")

        out.write_text(content, encoding="utf-8")
        return out

    def generate_format(
        self,
        spec: UdsSpecification,
        fmt: str,
        output_path: str | Path,
        *,
        extra_vars: Optional[dict] = None,
        odx_supplement: Optional[object] = None,
        show_domain: str = "auto",
    ) -> Path:
        """Generate output in the requested format.

        Args:
            fmt: One of "tex", "html", "md", "rst", "csv", "yaml", "json",
                "docx", "odx", "pdx".
            extra_vars: Passed through to LaTeX / HTML generation.
            odx_supplement: Optional :class:`udsxml2tex.odx.OdxSupplement`
                providing data that cannot be derived from ARXML
                (vehicle info, flash layout, functional groups). Only
                consumed when ``fmt`` is ``"odx"`` or ``"pdx"``.
            show_domain: ``"auto"`` | ``"always"`` | ``"never"`` — controls
                whether the Drive/Boot Domain column is emitted. The
                column is silently ignored by JSON / YAML / ODX / PDX
                formats which serialise the underlying field directly.
        """
        fmt = fmt.lower()
        if fmt == "tex":
            return self.generate(
                spec, output_path,
                extra_vars=extra_vars, show_domain=show_domain,
            )
        if fmt == "html":
            return self.generate_html(spec, output_path, show_domain=show_domain)
        if fmt == "md":
            return self.generate_markdown(spec, output_path, show_domain=show_domain)
        if fmt == "rst":
            return self.generate_rst(spec, output_path, show_domain=show_domain)
        if fmt == "yaml":
            return self.generate_yaml(spec, output_path)
        if fmt == "json":
            return self.generate_json(spec, output_path)
        if fmt == "csv":
            csv_dir = Path(output_path)
            self.generate_csv(spec, csv_dir, show_domain=show_domain)
            return csv_dir
        if fmt == "docx":
            return self.generate_docx(
                spec, Path(output_path).with_suffix(".docx"),
                show_domain=show_domain,
            )
        if fmt == "odx":
            return self.generate_odx_dir(spec, output_path, supplement=odx_supplement)
        if fmt == "pdx":
            return self.generate_pdx(spec, output_path, supplement=odx_supplement)
        raise ValueError(
            f"Unknown output format: {fmt!r}. "
            "Choose from: tex, html, md, rst, csv, yaml, json, docx, odx, pdx"
        )

    # ------------------------------------------------------------------
    # ODX / PDX (ISO 22901-1) output
    # ------------------------------------------------------------------

    def generate_odx(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        *,
        supplement: Optional[object] = None,
    ) -> Path:
        """Write the primary ODX-D (Diagnostic Layer) file for ``spec``.

        Args:
            spec: Parsed UDS specification.
            output_path: Target ``.odx-d`` path; the suffix is appended
                automatically when missing.
            supplement: Optional :class:`udsxml2tex.odx.OdxSupplement`.

        Returns:
            The path of the file that was written.
        """
        from udsxml2tex.odx import map_spec_to_odx
        from udsxml2tex.odx.serializers.odx_d import write_odx_d

        out = Path(output_path)
        if out.suffix != ".odx-d":
            out = out.with_suffix(".odx-d")
        documents = map_spec_to_odx(spec, supplement)
        diag_doc = next(
            (d for d in documents.values() if d.category.name == "DIAG_LAYER"),
            None,
        )
        if diag_doc is None:
            raise RuntimeError(
                "Mapper produced no DIAG_LAYER document; spec may be empty"
            )
        out.parent.mkdir(parents=True, exist_ok=True)
        return write_odx_d(diag_doc, out)

    def generate_odx_dir(
        self,
        spec: UdsSpecification,
        output_dir: str | Path,
        *,
        supplement: Optional[object] = None,
    ) -> Path:
        """Write every ``.odx-*`` file produced by the mapper into ``output_dir``.

        Unlike :meth:`generate_pdx` this leaves the documents as loose
        files (no ZIP, no ``index.xml``). Useful for inspecting the
        intermediate output or feeding individual files to a third-party
        ODX validator.

        Returns:
            The path of the directory that received the files.
        """
        from udsxml2tex.odx import map_spec_to_odx
        from udsxml2tex.odx.pdx_packager import write_loose_odx  # Agent 6 provides this

        out_dir = Path(output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        documents = map_spec_to_odx(spec, supplement)
        write_loose_odx(documents, out_dir)
        return out_dir

    def generate_pdx(
        self,
        spec: UdsSpecification,
        output_path: str | Path,
        *,
        supplement: Optional[object] = None,
        validate: bool = False,
    ) -> Path:
        """Write a complete PDX (ISO 22901-1) archive for ``spec``.

        Args:
            spec: Parsed UDS specification.
            output_path: Target ``.pdx`` path; the suffix is appended
                automatically when missing.
            supplement: Optional :class:`udsxml2tex.odx.OdxSupplement`
                with vehicle info, flash data and functional groups.
            validate: When ``True`` and ASAM XSDs are present, validate
                each member against its schema before packing.

        Returns:
            The path of the PDX archive that was written.
        """
        # Local imports keep generator.py importable even when running
        # inside __init__.py before all submodules have settled.
        from udsxml2tex import __version__ as _udsxml2tex_version
        from udsxml2tex.odx import map_spec_to_odx
        from udsxml2tex.odx.pdx_packager import pack_pdx  # Agent 6 provides this

        out = Path(output_path)
        if out.suffix != ".pdx":
            out = out.with_suffix(".pdx")
        documents = map_spec_to_odx(spec, supplement)
        result = pack_pdx(
            documents,
            out,
            validate=validate,
            tool_version=f"udsxml2tex/{_udsxml2tex_version}",
        )
        return result.path


# ---------------------------------------------------------------------------
# Markdown renderer
# ---------------------------------------------------------------------------

def _md_escape(text: str) -> str:
    """Minimal Markdown escaping for pipe-table cells."""
    return str(text).replace("|", "\\|").replace("\n", " ")


def _render_markdown(spec: UdsSpecification, *, show_domain: bool = False) -> str:
    lines: list[str] = []
    w = lines.append

    def _boot_suffix(item) -> str:
        """Return ``" _(Boot)_"`` for boot-only rows so MD readers see a marker."""
        return " _(Boot)_" if getattr(item, "domain", "drive") == "boot" else ""

    w(f"# {spec.ecu_name} UDS Specification")
    w("")
    if spec.description:
        w(spec.description)
        w("")
    w(f"**Protocol:** {spec.protocol_name}")
    if spec.can_rx_id:
        w(f"**CAN RX ID:** `{spec.can_rx_id}`  **CAN TX ID:** `{spec.can_tx_id}`")
    w(f"**S3 Server Timeout:** {spec.s3_server} s")
    w("")

    # Sessions
    if spec.sessions:
        w("## Diagnostic Sessions")
        w("")
        if show_domain:
            w("| Session ID | Short Name | P2 (s) | P2* (s) | Domain |")
            w("|---|---|---|---|---|")
        else:
            w("| Session ID | Short Name | P2 (s) | P2* (s) |")
            w("|---|---|---|---|")
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            name = _md_escape(s.short_name) + _boot_suffix(s)
            if show_domain:
                dom = _domain_label(getattr(s, "domain", "drive"))
                w(f"| `{s.session_id_hex}` | {name} | {s.p2_server_max} | {s.p2_star_server_max} | {dom} |")
            else:
                w(f"| `{s.session_id_hex}` | {name} | {s.p2_server_max} | {s.p2_star_server_max} |")
        w("")

    # Security levels
    if spec.security_levels:
        w("## Security Levels")
        w("")
        w("| Level | Short Name | Seed (B) | Key (B) | Max Attempts |")
        w("|---|---|---|---|---|")
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            w(f"| `{s.security_level_hex}` | {_md_escape(s.short_name)} | {s.seed_size} | {s.key_size} | {s.num_max_attempts} |")
        w("")

    # Services
    if spec.services:
        w("## Diagnostic Services")
        w("")
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            name = svc.short_name + (
                " _(Boot)_" if getattr(svc, "domain", "drive") == "boot" else ""
            )
            w(f"### {name} (`{svc.service_id_hex}`)")
            w("")
            if svc.description:
                w(svc.description)
                w("")
            if svc.supported_sessions:
                w(f"**Supported sessions:** {', '.join(svc.supported_sessions)}")
            if svc.required_security_levels:
                w(f"**Required security:** {', '.join(svc.required_security_levels)}")
            if show_domain:
                w(f"**Domain:** {_domain_label(getattr(svc, 'domain', 'drive'))}")
            if svc.sub_functions:
                w("")
                w("| Sub-function ID | Name |")
                w("|---|---|")
                for sf in svc.sub_functions:
                    w(f"| `{sf.sub_function_id_hex}` | {_md_escape(sf.short_name)} |")
            if svc.nrc_list:
                w("")
                w("| NRC | Name |")
                w("|---|---|")
                for nrc in svc.nrc_list:
                    w(f"| `{nrc.nrc_code_hex}` | {_md_escape(nrc.nrc_name)} |")
            w("")

    # DIDs
    if spec.dids:
        w("## Data Identifiers (DIDs)")
        w("")
        if show_domain:
            w("| DID ID | Short Name | R | W | Length (B) | Domain |")
            w("|---|---|---|---|---|---|")
        else:
            w("| DID ID | Short Name | R | W | Length (B) |")
            w("|---|---|---|---|---|")
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            r = "✓" if d.read_access else ""
            wr = "✓" if d.write_access else ""
            name = _md_escape(d.short_name) + _boot_suffix(d)
            if show_domain:
                dom = _domain_label(getattr(d, "domain", "drive"))
                w(f"| `{d.did_id_hex}` | {name} | {r} | {wr} | {d.total_byte_length} | {dom} |")
            else:
                w(f"| `{d.did_id_hex}` | {name} | {r} | {wr} | {d.total_byte_length} |")
        w("")

    # Routines
    if spec.routines:
        w("## Routine Controls")
        w("")
        if show_domain:
            w("| Routine ID | Short Name | Domain |")
            w("|---|---|---|")
        else:
            w("| Routine ID | Short Name |")
            w("|---|---|")
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            name = _md_escape(r.short_name) + _boot_suffix(r)
            if show_domain:
                dom = _domain_label(getattr(r, "domain", "drive"))
                w(f"| `{r.routine_id_hex}` | {name} | {dom} |")
            else:
                w(f"| `{r.routine_id_hex}` | {name} |")
        w("")

    # DTCs
    if spec.dtcs:
        w("## Diagnostic Trouble Codes (DTCs)")
        w("")
        w("| DTC ID | Short Name | Severity |")
        w("|---|---|---|")
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            w(f"| `{d.dtc_id_hex}` | {_md_escape(d.short_name)} | {_md_escape(d.severity)} |")
        w("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# RST renderer
# ---------------------------------------------------------------------------

def _rst_title(text: str, char: str = "=") -> str:
    return f"{text}\n{char * len(text)}\n"


def _rst_table(headers: list[str], rows: list[list[str]]) -> str:
    cols = len(headers)
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row[:cols]):
            widths[i] = max(widths[i], len(str(cell)))
    sep = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    fmt_row = lambda cells: "|" + "|".join(f" {str(c):<{w}} " for c, w in zip(cells, widths)) + "|"
    lines = [sep, fmt_row(headers), sep.replace("-", "=")]
    for row in rows:
        lines.append(fmt_row(row + [""] * (cols - len(row))))
        lines.append(sep)
    return "\n".join(lines) + "\n"


def _render_rst(spec: UdsSpecification, *, show_domain: bool = False) -> str:
    lines: list[str] = []
    w = lines.append

    def _boot_suffix(item) -> str:
        return " (Boot)" if getattr(item, "domain", "drive") == "boot" else ""

    w(_rst_title(f"{spec.ecu_name} UDS Specification", "="))
    if spec.description:
        w(spec.description)
        w("")
    w(f"**Protocol:** {spec.protocol_name}")
    w(f"**S3 Server Timeout:** {spec.s3_server} s")
    w("")

    if spec.sessions:
        w(_rst_title("Diagnostic Sessions", "-"))
        rows = []
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            base = [
                s.session_id_hex,
                s.short_name + _boot_suffix(s),
                str(s.p2_server_max),
                str(s.p2_star_server_max),
            ]
            if show_domain:
                base.append(_domain_label(getattr(s, "domain", "drive")))
            rows.append(base)
        headers = ["Session ID", "Short Name", "P2 (s)", "P2* (s)"]
        if show_domain:
            headers.append("Domain")
        w(_rst_table(headers, rows))

    if spec.services:
        w(_rst_title("Diagnostic Services", "-"))
        rows = []
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            base = [
                svc.service_id_hex,
                svc.short_name + _boot_suffix(svc),
                str(len(svc.sub_functions)),
            ]
            if show_domain:
                base.append(_domain_label(getattr(svc, "domain", "drive")))
            rows.append(base)
        headers = ["SID", "Short Name", "Sub-functions"]
        if show_domain:
            headers.append("Domain")
        w(_rst_table(headers, rows))

    if spec.dids:
        w(_rst_title("Data Identifiers (DIDs)", "-"))
        rows = []
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            base = [
                d.did_id_hex,
                d.short_name + _boot_suffix(d),
                "Yes" if d.read_access else "No",
                "Yes" if d.write_access else "No",
                str(d.total_byte_length),
            ]
            if show_domain:
                base.append(_domain_label(getattr(d, "domain", "drive")))
            rows.append(base)
        headers = ["DID ID", "Short Name", "Read", "Write", "Length (B)"]
        if show_domain:
            headers.append("Domain")
        w(_rst_table(headers, rows))

    if spec.routines:
        w(_rst_title("Routine Controls", "-"))
        rows = []
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            base = [
                r.routine_id_hex,
                r.short_name + _boot_suffix(r),
            ]
            if show_domain:
                base.append(_domain_label(getattr(r, "domain", "drive")))
            rows.append(base)
        headers = ["Routine ID", "Short Name"]
        if show_domain:
            headers.append("Domain")
        w(_rst_table(headers, rows))

    if spec.dtcs:
        w(_rst_title("Diagnostic Trouble Codes (DTCs)", "-"))
        rows = [[d.dtc_id_hex, d.short_name, d.severity]
                for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)]
        w(_rst_table(["DTC ID", "Short Name", "Severity"], rows))

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# CSV renderer
# ---------------------------------------------------------------------------

def _render_csv(
    spec: UdsSpecification,
    out_dir: Path,
    *,
    show_domain: bool = False,
) -> list[Path]:
    import csv
    written: list[Path] = []

    def _write(name: str, headers: list[str], rows: list[list]) -> None:
        p = out_dir / name
        with open(p, "w", newline="", encoding="utf-8") as f:
            cw = csv.writer(f)
            cw.writerow(headers)
            cw.writerows(rows)
        written.append(p)

    if spec.sessions:
        headers = ["session_id_hex", "short_name", "p2_server_max",
                   "p2_star_server_max", "comm_ctrl_option_mask"]
        rows = [[s.session_id_hex, s.short_name, s.p2_server_max,
                 s.p2_star_server_max, s.comm_ctrl_option_mask]
                for s in sorted(spec.sessions, key=lambda x: x.session_id)]
        if show_domain:
            headers.append("domain")
            rows = [r + [_domain_label(getattr(s, "domain", "drive"), short=True)]
                    for r, s in zip(rows, sorted(spec.sessions, key=lambda x: x.session_id))]
        _write("sessions.csv", headers, rows)

    if spec.security_levels:
        _write("security_levels.csv",
               ["security_level_hex", "short_name", "key_size", "seed_size",
                "num_max_attempts", "attempt_delay"],
               [[s.security_level_hex, s.short_name, s.key_size, s.seed_size,
                 s.num_max_attempts, s.attempt_delay]
                for s in sorted(spec.security_levels, key=lambda x: x.security_level)])

    if spec.services:
        headers = ["service_id_hex", "short_name", "supported_sessions",
                   "required_security_levels", "nrc_count", "sub_function_count"]
        rows = [[s.service_id_hex, s.short_name,
                 ";".join(s.supported_sessions),
                 ";".join(s.required_security_levels),
                 len(s.nrc_list), len(s.sub_functions)]
                for s in sorted(spec.services, key=lambda x: x.service_id)]
        if show_domain:
            headers.append("domain")
            rows = [r + [_domain_label(getattr(s, "domain", "drive"), short=True)]
                    for r, s in zip(rows, sorted(spec.services, key=lambda x: x.service_id))]
        _write("services.csv", headers, rows)

    if spec.dids:
        headers = ["did_id_hex", "short_name", "read_access", "write_access",
                   "total_byte_length", "supported_sessions",
                   "required_security_levels", "data_element_count"]
        rows = [[d.did_id_hex, d.short_name, d.read_access, d.write_access,
                 d.total_byte_length, ";".join(d.supported_sessions),
                 ";".join(d.required_security_levels), len(d.data_elements)]
                for d in sorted(spec.dids, key=lambda x: x.did_id)]
        if show_domain:
            headers.append("domain")
            rows = [r + [_domain_label(getattr(d, "domain", "drive"), short=True)]
                    for r, d in zip(rows, sorted(spec.dids, key=lambda x: x.did_id))]
        _write("dids.csv", headers, rows)
        # Data elements flattened
        de_rows = []
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            for de in d.data_elements:
                de_rows.append([d.did_id_hex, d.short_name, de.short_name,
                                 de.byte_position, de.bit_size, de.data_type,
                                 de.description, de.read_function, de.write_function,
                                 ";".join(de.global_variables)])
        if de_rows:
            _write("did_data_elements.csv",
                   ["did_id_hex", "did_short_name", "element_short_name",
                    "byte_position", "bit_size", "data_type", "description",
                    "read_function", "write_function", "global_variables"],
                   de_rows)

    if spec.routines:
        headers = ["routine_id_hex", "short_name", "start_supported",
                   "stop_supported", "result_supported", "supported_sessions",
                   "required_security_levels"]
        rows = [[r.routine_id_hex, r.short_name, r.start_supported,
                 r.stop_supported, r.result_supported,
                 ";".join(r.supported_sessions),
                 ";".join(r.required_security_levels)]
                for r in sorted(spec.routines, key=lambda x: x.routine_id)]
        if show_domain:
            headers.append("domain")
            rows = [row + [_domain_label(getattr(r, "domain", "drive"), short=True)]
                    for row, r in zip(rows, sorted(spec.routines, key=lambda x: x.routine_id))]
        _write("routines.csv", headers, rows)

    if spec.dtcs:
        _write("dtcs.csv",
               ["dtc_id_hex", "short_name", "severity", "description",
                "functional_unit", "priority", "dtc_kind"],
               [[d.dtc_id_hex, d.short_name, d.severity, d.description,
                 d.functional_unit, d.priority, d.dtc_kind]
                for d in sorted(spec.dtcs, key=lambda x: x.dtc_id)])

    logger.info("Generated %d CSV file(s) in %s", len(written), out_dir)
    return written


# ---------------------------------------------------------------------------
# TikZ session state-machine diagram
# ---------------------------------------------------------------------------

def _render_session_tikz(spec: UdsSpecification) -> str:
    sessions = sorted(spec.sessions, key=lambda s: s.session_id)
    if not sessions:
        return "% No sessions defined.\n"

    lines: list[str] = [
        r"\documentclass[tikz,border=10pt]{standalone}",
        r"\usetikzlibrary{automata,arrows.meta,positioning}",
        r"\begin{document}",
        r"\begin{tikzpicture}[",
        r"  > = {Stealth[length=6pt]},",
        r"  node distance = 2.8cm,",
        r"  state/.style = {draw, rounded rectangle, minimum width=3cm, minimum height=1cm,",
        r"                   font=\small\ttfamily, align=center},",
        r"  every edge/.style = {draw, ->, bend left=20},",
        r"]",
    ]

    # Position nodes in a row
    prev = None
    for i, s in enumerate(sessions):
        sid = s.short_name.replace(" ", "_")
        if i == 0:
            lines.append(f"  \\node[state, initial] ({sid}) {{{s.short_name}\\\\{s.session_id_hex}}};")
        else:
            prev_id = sessions[i - 1].short_name.replace(" ", "_")
            lines.append(f"  \\node[state, right of={prev_id}] ({sid}) {{{s.short_name}\\\\{s.session_id_hex}}};")
        prev = sid

    lines.append("")
    # Draw bidirectional transitions between each consecutive pair
    for i in range(len(sessions) - 1):
        a = sessions[i].short_name.replace(" ", "_")
        b = sessions[i + 1].short_name.replace(" ", "_")
        lines.append(f"  \\path ({a}) edge[bend left] node[above]{{0x10}} ({b});")
        lines.append(f"  \\path ({b}) edge[bend left] node[below]{{0x10}} ({a});")
    # Self-loops for TesterPresent-kept sessions
    for s in sessions:
        sid = s.short_name.replace(" ", "_")
        lines.append(f"  \\path ({sid}) edge[loop above] node[above]{{0x3E}} ({sid});")

    lines += [
        r"\end{tikzpicture}",
        r"\end{document}",
    ]
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# TikZ session state-transition figure (non-standalone, for inclusion in ZIP)
# ---------------------------------------------------------------------------

def _build_session_state_tikz(sessions: list, s3_server: float = 5.0) -> str:
    """Return a TikZ figure (non-standalone) for the session state-transition diagram."""
    if not sessions:
        return ""

    def _sid(s) -> str:
        return "s" + re.sub(r"[^A-Za-z0-9]", "", s.short_name)

    default_session = sessions[0]
    non_default = sessions[1:]
    n_nondft = len(non_default)

    lines: list[str] = [
        r"\begin{figure}[H]",
        r"\centering",
        r"\begin{tikzpicture}",
        r"",
        r"% Initial pseudostate",
        r"\umlstateinitial[x=0, y=0, name=init]",
        r"",
        r"% Default session state",
    ]

    default_label = _latex_escape(default_session.short_name)
    lines.append(
        f"\\begin{{umlstate}}[x=0, y=-2, name={_sid(default_session)},"
        f" width=5cm, fill=gray!8]{{{default_label}}}"
    )
    lines.append(r"\end{umlstate}")
    lines.append(r"")
    lines.append(
        f"\\draw[->, >=triangle 45, thick] (init) -- ({_sid(default_session)})"
        r"  node[pos=0.15, right, font=\small, xshift=2pt]"
        r" {\guillemotleft Power On\guillemotright};"
    )

    if non_default:
        lines.append(r"")
        lines.append(r"% Non-default session states")
        for i, sf in enumerate(non_default):
            xoff = (i - (n_nondft - 1) / 2.0) * 8
            label = _latex_escape(sf.short_name)
            lines.append(
                f"\\begin{{umlstate}}[x={xoff:.1f}, y=-6, name={_sid(sf)},"
                f" width=5cm, fill=gray!8]{{{label}}}"
            )
            lines.append(r"\end{umlstate}")

        lines.append(r"")
        lines.append(r"% Transitions: Default <-> each non-default session")
        for sf in non_default:
            sf_hex = sf.session_id_hex.replace("0x", "").replace("0X", "")
            sid = _sid(sf)
            if sf.session_id != 2:
                lines.append(
                    f"\\draw[->, >=triangle 45, thick, bend left=10] ({_sid(default_session)}) to"
                    f" node[auto, font=\\small]"
                    f" {{\\guillemotleft SF = {sf_hex}\\guillemotright}} ({sid});"
                )
            lines.append(
                f"\\draw[->, >=triangle 45, thick, bend left=10] ({sid}) to"
                f" node[auto, font=\\small]"
                f" {{\\guillemotleft SF = 01 / S3 timeout ({s3_server}\\,s)\\guillemotright}}"
                f" ({_sid(default_session)});"
            )

        if n_nondft > 1:
            lines.append(r"")
            lines.append(r"% Transitions between non-default sessions")
            for i, sf_a in enumerate(non_default):
                for sf_b in non_default[i + 1:]:
                    id_a, id_b = _sid(sf_a), _sid(sf_b)
                    hex_a = sf_a.session_id_hex.replace("0x", "").replace("0X", "")
                    hex_b = sf_b.session_id_hex.replace("0x", "").replace("0X", "")
                    lines.append(
                        f"\\draw[->, >=triangle 45, thick, bend left=10] ({id_a}) to"
                        f" node[auto, font=\\small]"
                        f" {{\\guillemotleft SF = {hex_b}\\guillemotright}} ({id_b});"
                    )
                    lines.append(
                        f"\\draw[->, >=triangle 45, thick, bend left=10] ({id_b}) to"
                        f" node[auto, font=\\small]"
                        f" {{\\guillemotleft SF = {hex_a}\\guillemotright}} ({id_a});"
                    )

        lines.append(r"")
        lines.append(r"% Self-transitions for non-default sessions (TesterPresent)")
        for sf in non_default:
            sid = _sid(sf)
            lines.append(
                f"\\umltrans[recursive=210|330|3cm, recursive direction=bottom to bottom,"
                f" arg={{TesterPresent}}, pos stereo=1.5]{{{sid}}}{{{sid}}}"
            )

    lines.append(r"")
    lines.append(r"% Self-transition for default session (rectangular loop on right)")
    lines.append(
        r"\draw[->, >=triangle 45, thick, rounded corners=5pt]"
    )
    lines.append(
        f"  ([yshift=4mm]{_sid(default_session)}.east) -- ++(1.5, 0)"
    )
    lines.append(
        r"  -- ++(0, -0.8) node[midway, right, font=\small] {TesterPresent}"
    )
    lines.append(
        f"  -- ([yshift=-4mm]{_sid(default_session)}.east);"
    )

    lines.append(r"")
    lines.append(r"\end{tikzpicture}")
    lines.append(r"\caption{Session Transition Diagram}\label{fig:session-transition}")
    lines.append(r"\end{figure}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# TikZ NRC flowchart figure (non-standalone, for inclusion in ZIP)
# ---------------------------------------------------------------------------

def _build_nrc_flowchart_tikz(service) -> str:
    """Return a TikZ figure showing the NRC check flow for one UDS service."""
    if not service.nrc_list:
        return ""

    # Filter NRC_CHECK_ORDER to only codes present in this service (preserves priority order)
    nrc_codes_set = {nrc.nrc_code for nrc in service.nrc_list}
    checks = [(code, label) for code, label in NRC_CHECK_ORDER if code in nrc_codes_set]
    if not checks:
        return ""

    sid_hex = f"{service.service_id:02X}"
    name_esc = _latex_escape(service.short_name)

    lines: list[str] = [
        r"\begin{figure}[H]",
        r"\centering",
        r"\begin{tikzpicture}[",
        r"  node distance=0.5cm,",
        r"  startstop/.style={rectangle, rounded corners, minimum width=2.2cm,",
        r"                    minimum height=0.6cm, text centered,",
        r"                    draw=black, fill=gray!12, font=\small},",
        r"  decision/.style={diamond, aspect=1.5, minimum width=0.8cm,",
        r"                   minimum height=0.8cm, inner sep=0pt,",
        r"                   draw=black, fill=white},",
        r"  nrcbox/.style={rectangle, minimum width=1.8cm, minimum height=0.5cm,",
        r"                 text centered, draw=black, fill=gray!20, font=\scriptsize},",
        r"  arrow/.style={thick,->,>=stealth},",
        r"]",
        r"",
        r"\node (start) [startstop] {Request received};",
        r"",
    ]

    prev = "start"
    for idx, (code, label) in enumerate(checks):
        nid = f"chk{idx}"
        nrc_hex = f"{code:02X}"
        lines.append(f"\\node ({nid}) [decision, below=of {prev}] {{}};")
        lines.append(
            f"\\node[left=0.1cm of {nid}, font=\\scriptsize, anchor=east, align=right]"
            f" {{{label}}};"
        )
        lines.append(
            f"\\node (nrc{idx}) [nrcbox, right=1.8cm of {nid}]"
            f" {{NRC \\hex{{{nrc_hex}}}}};"
        )
        lines.append(f"\\draw [arrow] ({prev}) -- ({nid});")
        lines.append(
            f"\\draw [arrow] ({nid}) -- node[above, font=\\scriptsize] {{No}} (nrc{idx});"
        )
        lines.append("")
        prev = nid

    last = f"chk{len(checks) - 1}"
    lines.append(f"\\node (positive) [startstop, below=of {last}] {{Positive Response}};")
    lines.append(
        f"\\draw [arrow] ({last}) -- node[right, font=\\scriptsize] {{Yes}} (positive);"
    )
    lines.append("")

    # "Yes" labels on the main path between consecutive decision nodes
    for idx in range(len(checks) - 1):
        nid = f"chk{idx}"
        next_nid = f"chk{idx + 1}"
        lines.append(
            f"\\node[font=\\scriptsize, right=2pt]"
            f" at ($({nid}.south)!0.5!({next_nid}.north)$) {{Yes}};"
        )

    lines.append(r"\end{tikzpicture}")
    lines.append(
        f"\\caption{{{name_esc} --- NRC Decision Flow}}"
        f"\\label{{fig:nrc-flow-{sid_hex.lower()}}}"
    )
    lines.append(r"\end{figure}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# DOCX renderer
# ---------------------------------------------------------------------------

def _render_docx(
    spec: UdsSpecification,
    path: Path,
    *,
    show_domain: bool = False,
) -> None:
    """Create and save a DOCX document for *spec* at *path*.

    Requires python-docx (imported lazily so the rest of the module works
    without the optional dependency installed). When ``show_domain`` is
    True an additional Domain column is appended to the session / service /
    DID / routine tables; the cell for boot-only rows is rendered in bold.
    """
    from docx import Document  # type: ignore[import]

    def _set_domain_cell(cell, item) -> None:
        """Populate ``cell`` with the domain label, bolding boot-only rows."""
        dom_value = getattr(item, "domain", "drive")
        cell.text = _domain_label(dom_value)
        if dom_value == "boot":
            for para in cell.paragraphs:
                for run in para.runs:
                    run.bold = True

    doc = Document()

    # Title
    doc.add_heading(f"{spec.ecu_name} UDS Specification", level=0)

    # Diagnostic Sessions
    if spec.sessions:
        doc.add_heading("Diagnostic Sessions", level=1)
        cols = 5 if show_domain else 4
        tbl = doc.add_table(rows=1, cols=cols)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "Session ID"
        hdr[2].text = "P2max (s)"
        hdr[3].text = "P2*max (s)"
        if show_domain:
            hdr[4].text = "Domain"
        for s in sorted(spec.sessions, key=lambda x: x.session_id):
            row = tbl.add_row().cells
            row[0].text = s.short_name
            row[1].text = s.session_id_hex
            row[2].text = str(s.p2_server_max)
            row[3].text = str(s.p2_star_server_max)
            if show_domain:
                _set_domain_cell(row[4], s)

    # Security Access Levels
    if spec.security_levels:
        doc.add_heading("Security Access Levels", level=1)
        tbl = doc.add_table(rows=1, cols=3)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "Level"
        hdr[2].text = "Key Size"
        for s in sorted(spec.security_levels, key=lambda x: x.security_level):
            row = tbl.add_row().cells
            row[0].text = s.short_name
            row[1].text = s.security_level_hex
            row[2].text = str(s.key_size)

    # Services
    if spec.services:
        doc.add_heading("Services", level=1)
        cols = 5 if show_domain else 4
        tbl = doc.add_table(rows=1, cols=cols)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "SID"
        hdr[2].text = "Supported Sessions"
        hdr[3].text = "Required Security"
        if show_domain:
            hdr[4].text = "Domain"
        for svc in sorted(spec.services, key=lambda x: x.service_id):
            row = tbl.add_row().cells
            row[0].text = svc.short_name
            row[1].text = svc.service_id_hex
            row[2].text = ", ".join(svc.supported_sessions)
            row[3].text = ", ".join(svc.required_security_levels)
            if show_domain:
                _set_domain_cell(row[4], svc)

    # Data Identifiers (DIDs)
    if spec.dids:
        doc.add_heading("Data Identifiers (DIDs)", level=1)
        cols = 6 if show_domain else 5
        tbl = doc.add_table(rows=1, cols=cols)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "DID"
        hdr[2].text = "Read"
        hdr[3].text = "Write"
        hdr[4].text = "Sessions"
        if show_domain:
            hdr[5].text = "Domain"
        for d in sorted(spec.dids, key=lambda x: x.did_id):
            row = tbl.add_row().cells
            row[0].text = d.short_name
            row[1].text = d.did_id_hex
            row[2].text = "Yes" if d.read_access else "No"
            row[3].text = "Yes" if d.write_access else "No"
            row[4].text = ", ".join(d.supported_sessions)
            if show_domain:
                _set_domain_cell(row[5], d)

    # Routines
    if spec.routines:
        doc.add_heading("Routines", level=1)
        cols = 4 if show_domain else 3
        tbl = doc.add_table(rows=1, cols=cols)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "ID"
        hdr[2].text = "Sessions"
        if show_domain:
            hdr[3].text = "Domain"
        for r in sorted(spec.routines, key=lambda x: x.routine_id):
            row = tbl.add_row().cells
            row[0].text = r.short_name
            row[1].text = r.routine_id_hex
            row[2].text = ", ".join(r.supported_sessions)
            if show_domain:
                _set_domain_cell(row[3], r)

    # DTCs
    if spec.dtcs:
        doc.add_heading("DTCs", level=1)
        tbl = doc.add_table(rows=1, cols=4)
        tbl.style = "Table Grid"
        hdr = tbl.rows[0].cells
        hdr[0].text = "Name"
        hdr[1].text = "DTC ID"
        hdr[2].text = "Severity"
        hdr[3].text = "Description"
        for d in sorted(spec.dtcs, key=lambda x: x.dtc_id):
            row = tbl.add_row().cells
            row[0].text = d.short_name
            row[1].text = d.dtc_id_hex
            row[2].text = d.severity
            row[3].text = d.description or ""

    doc.save(str(path))


# ---------------------------------------------------------------------------
# TikZ sequence diagram renderer
# ---------------------------------------------------------------------------

def _render_sequence_tikz(
    title: str,
    participants: list,
    messages: list,
) -> str:
    """Render a simple TikZ sequence diagram.

    Args:
        title:        Diagram title (used as a comment and heading node).
        participants: List of participant name strings, e.g. ["Tester", "ECU"].
        messages:     List of (from, to, label, style) tuples.
                      *style* is "" for a solid arrow or "dashed" for a dashed arrow.

    Returns:
        A standalone LaTeX document string.
    """
    n = len(participants)
    # Horizontal spacing between participant columns (cm)
    col_sep = 6.0
    # Vertical spacing between messages (cm)
    row_sep = 1.2

    lines: list[str] = [
        r"\documentclass[tikz,border=10pt]{standalone}",
        r"\usetikzlibrary{arrows.meta}",
        r"\begin{document}",
        f"% Sequence diagram: {title}",
        r"\begin{tikzpicture}[",
        r"  >=Stealth,",
        r"  participant/.style={draw, rectangle, minimum width=2.8cm, minimum height=0.8cm,",
        r"                      align=center, font=\small\bfseries},",
        r"  msg/.style={draw, ->, font=\footnotesize},",
        r"  msgnrc/.style={draw, ->, dashed, font=\footnotesize},",
        r"]",
    ]

    # Participant header boxes
    for i, p in enumerate(participants):
        x = i * col_sep
        lines.append(
            f"  \\node[participant] (p{i}) at ({x:.1f},0) {{{_latex_escape(p)}}};"
        )

    # Lifelines (vertical dashed lines)
    total_height = (len(messages) + 1) * row_sep
    for i in range(n):
        x = i * col_sep
        lines.append(
            f"  \\draw[dashed, gray] ({x:.1f},-0.4) -- ({x:.1f},-{total_height:.1f});"
        )

    # Message arrows
    part_index = {p: i for i, p in enumerate(participants)}
    for j, msg in enumerate(messages):
        src, dst, label, style = msg
        y = -(j + 1) * row_sep
        src_idx = part_index.get(src, 0)
        dst_idx = part_index.get(dst, 0)
        x1 = src_idx * col_sep
        x2 = dst_idx * col_sep
        tikz_style = "msgnrc" if style == "dashed" else "msg"
        # label above midpoint
        mid_x = (x1 + x2) / 2.0
        label_escaped = _latex_escape(label)
        lines.append(
            f"  \\draw[{tikz_style}] ({x1:.1f},{y:.2f}) -- ({x2:.1f},{y:.2f})"
            f" node[midway, above, align=center, font=\\scriptsize]{{{label_escaped}}};"
        )

    lines += [
        r"\end{tikzpicture}",
        r"\end{document}",
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bytefield DID renderer
# ---------------------------------------------------------------------------

def _render_bytefield_did(did: object) -> str:
    """Return a LaTeX bytefield snippet for a single DID.

    Args:
        did: A DID model object with attributes ``did_id_hex``, ``short_name``,
             and ``data_elements`` (list of objects with ``short_name``,
             ``byte_position``, and ``bit_size``).

    Returns:
        LaTeX string containing \\subsection* and bytefield environment.
    """
    # Determine total bit width — round up to nearest multiple of 8
    total_bits = 0
    for de in did.data_elements:
        bits = getattr(de, "bit_size", 0) or 0
        bpos = getattr(de, "byte_position", 0) or 0
        end_bit = bpos * 8 + bits
        if end_bit > total_bits:
            total_bits = end_bit
    if total_bits == 0:
        total_bits = 8
    # Round up to multiple of 8
    if total_bits % 8:
        total_bits = ((total_bits // 8) + 1) * 8

    did_name_esc = _latex_escape(str(getattr(did, "short_name", "")))
    did_hex = getattr(did, "did_id_hex", "????")

    lines: list[str] = [
        f"\\subsection*{{DID {did_hex} --- {did_name_esc}}}",
        f"\\begin{{bytefield}}[bitwidth=0.5em]{{{total_bits}}}",
        f"  \\bitheader{{0-{total_bits - 1}}} \\\\",
    ]

    # Sort data elements by byte position
    elements = sorted(
        did.data_elements,
        key=lambda de: (getattr(de, "byte_position", 0) or 0),
    )
    for de in elements:
        bits = getattr(de, "bit_size", 8) or 8
        n_words = max(1, bits // 8)
        name_esc = _latex_escape(str(getattr(de, "short_name", "")))
        bpos = getattr(de, "byte_position", 0) or 0
        lines.append(
            f"  \\wordbox{{{n_words}}}{{{name_esc} ({n_words} byte(s), offset {bpos})}} \\\\"
        )

    lines.append("\\end{bytefield}")
    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Multi-page HTML helpers for generate_html_zip()
# ---------------------------------------------------------------------------

_HTML_CSS = """
* { box-sizing: border-box; }
body { font-family: Georgia, "Times New Roman", serif; font-size: 14px; line-height: 1.7; color: #111;
       margin: 0; display: flex; min-height: 100vh; background: #fff; }
nav { width: 210px; min-width: 160px; background: #3a3a3a; color: #ddd; padding: 1.5em 1em;
      flex-shrink: 0; border-right: 1px solid #222; }
nav h2 { color: #fff; font-size: 0.95em; font-family: Georgia, serif; margin-bottom: 1em;
          border-bottom: 1px solid #555; padding-bottom: 0.4em; letter-spacing: 0.03em; }
nav ul { list-style: none; padding: 0; margin: 0; }
nav ul li { margin: 0.5em 0; }
nav ul li a { color: #ccc; text-decoration: none; font-size: 0.9em; font-family: Arial, sans-serif; }
nav ul li a:hover { color: #fff; text-decoration: underline; }
main { flex: 1; padding: 2.5em 3em; overflow-x: auto; max-width: 960px; }
h1 { font-size: 1.8em; border-bottom: 2px solid #111; padding-bottom: 0.25em; margin-bottom: 0.6em; }
h2 { font-size: 1.3em; border-bottom: 1px solid #999; padding-bottom: 0.15em; margin-top: 2em; margin-bottom: 0.6em; }
h3 { font-size: 1.05em; margin-top: 1.5em; margin-bottom: 0.3em; }
h4 { font-size: 1em; font-style: italic; margin-top: 1em; margin-bottom: 0.2em; }
table { border-collapse: collapse; margin: 0.8em 0 1.4em; font-size: 0.88em;
        font-family: Arial, Helvetica, sans-serif; width: auto; }
th { background: #e0e0e0; color: #111; font-weight: bold; padding: 6px 10px;
     border: 1px solid #999; text-align: left; }
td { padding: 5px 10px; border: 1px solid #bbb; vertical-align: top; }
tr:nth-child(even) td { background: #f5f5f5; }
caption { font-style: italic; font-size: 0.9em; margin-bottom: 0.3em; text-align: left; color: #444; }
code, .hexval { font-family: "Courier New", Courier, monospace; font-size: 0.92em; }
.badge-yes { font-weight: bold; }
.badge-no { color: #999; }
.meta { color: #555; font-size: 0.88em; margin-bottom: 1.5em; font-family: Arial, sans-serif;
        border-left: 3px solid #ccc; padding-left: 0.8em; }
nav ul.nav-sub { padding-left: 1em; margin: 0.1em 0; }
nav ul.nav-sub li { margin: 0.1em 0; }
nav ul li a.nav-current { color: #fff; font-weight: bold; }
/* NRC check-flow inline SVG (TikZ/PlantUML-style rendered diagram) */
svg.nrc-flow-svg { display: block; margin: 1em auto 1.6em;
                   max-width: 780px; width: 100%; height: auto;
                   background: #fdfdfd; border: 1px solid #ddd; border-radius: 4px; }
/* Drive / Boot domain highlight — boot-only rows. */
tr.boot-only td { background: #f5f5f5; }
tr.boot-only:nth-child(even) td { background: #efefef; }
"""


def _html_escape(text: str) -> str:
    """Escape HTML special characters."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _html_hex(value: str) -> str:
    """Render hex value as inline code."""
    v = _strip_0x(str(value))
    return f'<code class="hexval">{v}<sub>16</sub></code>'


def _relpath(from_path: str, to_path: str) -> str:
    """Compute relative URL from one HTML file path to another (POSIX slashes)."""
    from_dir = os.path.dirname(from_path) or "."
    rel = os.path.relpath(to_path.replace("/", os.sep), from_dir)
    return rel.replace(os.sep, "/")


def _build_nav_html(nav_tree: list, current_path: str) -> str:
    """Build hierarchical navigation sidebar HTML with relative links."""
    def _item(node: dict) -> str:
        path = node["path"]
        title = node["title"]
        href = _relpath(current_path, path)
        active = ' class="nav-current"' if path == current_path else ""
        link = f'<a href="{href}"{active}>{title}</a>'
        children = node.get("children", [])
        sub = (f'<ul class="nav-sub">{"".join(_item(c) for c in children)}</ul>'
               if children else "")
        return f"<li>{link}{sub}</li>"

    return "<ul>" + "".join(_item(n) for n in nav_tree) + "</ul>"


def _html_page(title: str, nav: str, body: str, css: str,
               *, mermaid_rel_path: str | None = None) -> str:
    """Wrap body in a full HTML page with nav sidebar.

    When ``mermaid_rel_path`` is given, the page also pulls in the bundled
    mermaid.min.js (relative URL from the page) and initialises it on load,
    so any ``<div class="mermaid">…</div>`` blocks in ``body`` render as
    SVG diagrams in the browser.
    """
    mermaid_script = ""
    if mermaid_rel_path:
        mermaid_script = (
            f'<script src="{mermaid_rel_path}"></script>'
            f'<script>if (window.mermaid) {{ mermaid.initialize({{startOnLoad: true, theme: "neutral", securityLevel: "loose"}}); }}</script>'
        )
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{_html_escape(title)}</title>
<style>{css}</style>
</head>
<body>
<nav>
<h2>UDS Specification</h2>
{nav}
</nav>
<main>
{body}
</main>
{mermaid_script}
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Mermaid diagram helpers (offline-rendered via bundled assets/mermaid.min.js)
# ---------------------------------------------------------------------------

def _mermaid_block(diagram: str) -> str:
    """Wrap a mermaid diagram source in the markup mermaid.js looks for."""
    return (
        '<div class="mermaid" style="margin: 1em 0; text-align: center;">\n'
        f"{diagram.strip()}\n"
        "</div>"
    )


def _mermaid_id(name: str, prefix: str = "n") -> str:
    """Sanitise a string for use as a mermaid node ID."""
    safe = re.sub(r"[^A-Za-z0-9_]", "_", str(name))
    if not safe or not safe[0].isalpha():
        safe = prefix + safe
    return safe


def _build_session_state_mermaid(sessions: list, s3_server: float = 5.0) -> str:
    """Build a mermaid stateDiagram-v2 of session transitions.

    Mirrors `_build_session_state_tikz`: default session is the entry
    state, every non-default session has a SessionControl(SF=hex) edge
    from default and an S3-timeout edge back, plus a TesterPresent
    self-loop.
    """
    if not sessions:
        return ""
    lines = ["stateDiagram-v2", "    direction LR"]
    default = sessions[0]
    non_default = sessions[1:]
    lines.append(f"    [*] --> {_mermaid_id(default.short_name, 's')}")
    lines.append(f"    {_mermaid_id(default.short_name, 's')}: {default.short_name}")
    for sf in non_default:
        node = _mermaid_id(sf.short_name, "s")
        sf_hex = sf.session_id_hex.replace("0x", "").replace("0X", "")
        lines.append(f"    {node}: {sf.short_name}")
        if sf.session_id != 2:
            lines.append(
                f"    {_mermaid_id(default.short_name, 's')} --> {node}: SF=0x{sf_hex}"
            )
        lines.append(
            f"    {node} --> {_mermaid_id(default.short_name, 's')}: "
            f"SF=01 / S3 timeout ({s3_server}s)"
        )
        lines.append(f"    {node} --> {node}: TesterPresent")
    lines.append(
        f"    {_mermaid_id(default.short_name, 's')} --> "
        f"{_mermaid_id(default.short_name, 's')}: TesterPresent"
    )
    return "\n".join(lines)


def _build_security_state_mermaid() -> str:
    """Build the standard 4-state SecurityAccess FSM (ISO 14229-1 Annex I)."""
    return (
        "stateDiagram-v2\n"
        "    direction LR\n"
        "    [*] --> A\n"
        "    A: A — All locked, no seed\n"
        "    B: B — All locked, seed sent\n"
        "    C: C — Unlocked, no seed\n"
        "    D: D — Unlocked, seed sent\n"
        "    A --> B: requestSeed (valid)\n"
        "    A --> A: requestSeed / Delay timer active (NRC 0x37)\n"
        "    B --> A: sendKey (wrong, Att<Limit) NRC 0x35\n"
        "    B --> A: sendKey (wrong, Att>=Limit) NRC 0x36\n"
        "    B --> C: sendKey (correct)\n"
        "    C --> D: requestSeed (valid)\n"
        "    D --> C: sendKey (any)\n"
        "    B --> A: Session change / ECU reset\n"
        "    C --> A: Session change / ECU reset\n"
        "    D --> A: Session change / ECU reset"
    )


def _build_nrc_flowchart_mermaid(service) -> str:
    """Build a top-down mermaid flowchart of the NRC checks for one service.

    Models the typical UDS server pipeline: each NRC is checked in order;
    if the check FAILS the corresponding negative response is sent and
    processing stops, otherwise control flows to the next check. After
    all checks pass, a Positive Response is returned.
    """
    nrc_list = list(getattr(service, "nrc_list", None) or [])
    if not nrc_list:
        return ""
    lines = ["flowchart TD", "    REQ([Request received])"]
    prev = "REQ"
    for i, nrc in enumerate(nrc_list):
        check = f"C{i}"
        nrc_node = f"N{i}"
        nrc_name = nrc.nrc_name.replace('"', "'").replace("\n", " ").replace("|", "/")
        lines.append(f"    {check}{{{nrc_name}<br/>check OK?}}")
        lines.append(f"    {nrc_node}[NRC {nrc.nrc_code_hex}: {nrc_name}]")
        lines.append(f"    {prev} --> {check}")
        lines.append(f"    {check} -- No --> {nrc_node}")
        prev = check  # 'Yes' branch of this check feeds the next one
    lines.append(f"    {prev} -- Yes --> POS([Positive Response])")
    return "\n".join(lines)


def _build_nrc_flowchart_html(service) -> str:
    """Render the NRC check flow as an inline SVG flowchart mirroring the
    TikZ version (``_build_nrc_flowchart_tikz``).

    Layout matches the TikZ ``startstop`` / ``decision`` / ``nrcbox`` style:
      - ``Request received``  : rounded-rectangle start pill (top).
      - For each NRC check    : a *diamond* (decision) on the central
                                vertical axis; the check description is
                                right-aligned to the **left** of the diamond,
                                an NRC outcome box sits to its **right** with
                                a ``No`` label on the failure branch.
      - ``Yes`` labels        : between consecutive diamonds on the main
                                downward path.
      - ``Positive Response`` : rounded-rectangle end pill (bottom).
    Inline SVG so no server-side LaTeX / Java / Node is needed.
    """
    nrc_list = list(getattr(service, "nrc_list", None) or [])
    if not nrc_list:
        return ""

    # Match TikZ priority filtering: keep only checks present in NRC_CHECK_ORDER.
    nrc_codes_set = {n.nrc_code for n in nrc_list}
    code_to_name = {n.nrc_code: n.nrc_name for n in nrc_list}
    checks: list[tuple[int, str]] = [
        (code, code_to_name.get(code) or label)
        for code, label in NRC_CHECK_ORDER if code in nrc_codes_set
    ]
    if not checks:
        return ""

    # --- Geometry (matches the TikZ visual rhythm) -----------------------
    CX        = 320   # x-center of main vertical flow (diamonds + start/end)
    DIAM_W    = 70    # diamond width (full)
    DIAM_H    = 44    # diamond height (full)
    ROW_GAP   = 26    # vertical gap between rows
    NRC_W     = 140   # NRC outcome box width (right of diamond)
    NRC_H     = 34
    NRC_GAP   = 70    # gap between diamond right vertex and NRC box left edge
    END_W     = 220   # start/end pill width
    END_H     = 40
    PAD_TOP   = 14
    LABEL_W   = 290   # space reserved for the left-side check description label
    TOTAL_W   = CX + DIAM_W // 2 + NRC_GAP + NRC_W + 20

    n = len(checks)
    TOTAL_H = (PAD_TOP + END_H + ROW_GAP
               + n * (DIAM_H + ROW_GAP)
               + END_H + PAD_TOP)

    parts: list[str] = []
    parts.append(
        f'<svg class="nrc-flow-svg" viewBox="0 0 {TOTAL_W} {TOTAL_H}" '
        f'xmlns="http://www.w3.org/2000/svg" role="img" '
        f'aria-label="NRC check decision flow">'
    )
    # Arrowhead marker (single shared definition)
    parts.append(
        '<defs>'
        '<marker id="nrc-arrow" viewBox="0 0 10 10" refX="9" refY="5" '
        'markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
        '<path d="M0,0 L10,5 L0,10 Z" fill="#222"/>'
        '</marker>'
        '</defs>'
    )

    def _pill(cy_top: int, label: str) -> None:
        x = CX - END_W // 2
        parts.append(
            f'<rect x="{x}" y="{cy_top}" width="{END_W}" height="{END_H}" '
            f'rx="6" ry="6" fill="#ebebeb" stroke="#222" stroke-width="1.4"/>'
            f'<text x="{CX}" y="{cy_top + END_H // 2 + 4}" text-anchor="middle" '
            f'font-family="Arial, sans-serif" font-size="13" '
            f'fill="#111">{_html_escape(label)}</text>'
        )

    # --- Start pill -------------------------------------------------------
    start_top = PAD_TOP
    _pill(start_top, "Request received")
    prev_bottom = start_top + END_H

    # --- Decision diamonds ------------------------------------------------
    diamond_centers: list[tuple[int, int]] = []  # (cx, cy) per check
    for idx, (code, label) in enumerate(checks):
        nrc_hex = f"{code:02X}"
        top = prev_bottom + ROW_GAP
        cy = top + DIAM_H // 2
        diamond_centers.append((CX, cy))

        # Vertical arrow from previous bottom into this diamond top
        parts.append(
            f'<line x1="{CX}" y1="{prev_bottom}" x2="{CX}" y2="{top}" '
            f'stroke="#222" stroke-width="1.4" marker-end="url(#nrc-arrow)"/>'
        )

        # Diamond (decision)
        left_x  = CX - DIAM_W // 2
        right_x = CX + DIAM_W // 2
        bottom_y = top + DIAM_H
        parts.append(
            f'<polygon points="{CX},{top} {right_x},{cy} {CX},{bottom_y} {left_x},{cy}" '
            f'fill="#ffffff" stroke="#222" stroke-width="1.4"/>'
        )

        # Check description label to the LEFT of the diamond (right-aligned)
        parts.append(
            f'<text x="{left_x - 10}" y="{cy + 4}" text-anchor="end" '
            f'font-family="Arial, sans-serif" font-size="11" fill="#222">'
            f'{_html_escape(label)}</text>'
        )

        # "No" branch: right arrow to NRC outcome box
        nrc_x = right_x + NRC_GAP
        parts.append(
            f'<line x1="{right_x}" y1="{cy}" x2="{nrc_x}" y2="{cy}" '
            f'stroke="#222" stroke-width="1.4" marker-end="url(#nrc-arrow)"/>'
        )
        parts.append(
            f'<text x="{(right_x + nrc_x) // 2}" y="{cy - 5}" '
            f'text-anchor="middle" font-family="Arial, sans-serif" '
            f'font-size="11" fill="#222">No</text>'
        )
        parts.append(
            f'<rect x="{nrc_x}" y="{cy - NRC_H // 2}" width="{NRC_W}" height="{NRC_H}" '
            f'fill="#dddddd" stroke="#222" stroke-width="1.2"/>'
            f'<text x="{nrc_x + NRC_W // 2}" y="{cy + 4}" text-anchor="middle" '
            f'font-family="Arial, sans-serif" font-size="11" fill="#111">'
            f'NRC 0x{nrc_hex}</text>'
        )

        prev_bottom = bottom_y

    # --- "Yes" labels on segments between consecutive diamonds ------------
    for i in range(len(diamond_centers) - 1):
        _, cy_a = diamond_centers[i]
        _, cy_b = diamond_centers[i + 1]
        my = (cy_a + DIAM_H // 2 + cy_b - DIAM_H // 2) // 2
        parts.append(
            f'<text x="{CX + 6}" y="{my + 4}" '
            f'font-family="Arial, sans-serif" font-size="11" fill="#222">Yes</text>'
        )

    # --- Final segment + Positive Response pill ---------------------------
    end_top = prev_bottom + ROW_GAP
    parts.append(
        f'<line x1="{CX}" y1="{prev_bottom}" x2="{CX}" y2="{end_top}" '
        f'stroke="#222" stroke-width="1.4" marker-end="url(#nrc-arrow)"/>'
    )
    parts.append(
        f'<text x="{CX + 6}" y="{(prev_bottom + end_top) // 2 + 4}" '
        f'font-family="Arial, sans-serif" font-size="11" fill="#222">Yes</text>'
    )
    _pill(end_top, "Positive Response")

    parts.append('</svg>')
    return "\n".join(parts)


def _html_table(
    headers: list,
    rows: list,
    *,
    caption: str = "",
    row_classes: Optional[list[str]] = None,
) -> str:
    """Render a simple HTML table.

    ``row_classes`` (optional) is a list parallel to ``rows`` providing the
    ``class`` attribute for each ``<tr>``. Use an empty string to omit the
    class for a given row. The list length must match ``rows`` (otherwise
    rows beyond the supplied length render without a class attribute).
    """
    lines = ["<table>"]
    if caption:
        lines.append(f"<caption>{_html_escape(caption)}</caption>")
    lines.append("<thead><tr>" + "".join(
        f"<th>{_html_escape(str(h))}</th>" for h in headers) + "</tr></thead>")
    lines.append("<tbody>")
    for idx, row in enumerate(rows):
        cls = ""
        if row_classes is not None and idx < len(row_classes) and row_classes[idx]:
            cls = f' class="{row_classes[idx]}"'
        lines.append(
            f"<tr{cls}>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>"
        )
    lines.append("</tbody></table>")
    return "\n".join(lines)


def _boot_row_classes(items: list) -> list[str]:
    """Return a list of CSS classes for each item — ``"boot-only"`` for
    items whose ``domain`` is ``"boot"``, empty string otherwise."""
    return [
        BOOT_ROW_HTML_CLASS if getattr(it, "domain", "drive") == "boot" else ""
        for it in items
    ]


def _domain_html_cell(domain: str) -> str:
    """Render a single Domain cell. Boot is wrapped in <strong> to highlight."""
    label = _html_escape(_domain_label(domain))
    return f"<strong>{label}</strong>" if domain == "boot" else label


def _render_html_index(ctx: dict) -> str:
    lines: list[str] = []
    ecu = _html_escape(ctx.get("ecu_name", ""))
    proto = _html_escape(ctx.get("protocol_name", ""))
    lines.append(f"<h1>UDS Specification &mdash; {ecu}</h1>")
    lines.append(f'<p class="meta">ECU: <strong>{ecu}</strong> | Protocol: <strong>{proto}</strong></p>')
    lines.append("<p>This document is an automatically generated UDS specification "
                 "extracted from AUTOSAR ARXML configuration.</p>")
    current = ctx.get("_current_path", "index.html")
    lines.append("<h2>Document Sections</h2><ul>")
    for path, title, desc in [
        ("sections/0_intro/index.html",      "Introduction",
         "Scope, abbreviations, reference documents"),
        ("sections/1_low_layer/index.html",  "Network Protocol Layers",
         "CanTp, CAN IDs, timing, sessions"),
        ("sections/2_high_layer/index.html", "Application Layers",
         "All UDS services, DIDs, Routines, SecurityAccess"),
        ("sections/A_annex/index.html",      "Annex",
         "Cross-reference tables (SID/DID/RID/NRC &times; sessions)"),
    ]:
        href = _relpath(current, path)
        lines.append(f'<li><a href="{href}">{title}</a> &mdash; {desc}</li>')
    lines.append("</ul>")

    # Summary stats
    services = ctx.get("services", [])
    dids = ctx.get("dids", [])
    routines = ctx.get("routines", [])
    security_levels = ctx.get("security_levels", [])
    sessions = ctx.get("sessions", [])
    stats = [
        ["Diagnostic Sessions", str(len(sessions))],
        ["Security Levels", str(len(security_levels))],
        ["UDS Services", str(len(services))],
        ["Data Identifiers (DIDs)", str(len(dids))],
        ["Routines (RIDs)", str(len(routines))],
    ]
    lines.append("<h2>Document Statistics</h2>")
    lines.append(_html_table(["Item", "Count"], stats))

    if sessions:
        rows = [
            [_html_hex(s.session_id_hex), _html_escape(s.short_name),
             _html_escape(str(s.p2_server_max) if s.p2_server_max is not None else ""),
             _html_escape(str(s.p2_star_server_max) if s.p2_star_server_max is not None else "")]
            for s in sessions
        ]
        lines.append("<h2>Diagnostic Sessions</h2>")
        lines.append(_html_table(["Session ID", "Name", "P2 max (ms)", "P2* max (ms)"], rows))

    return "\n".join(lines)


def _render_html_intro(ctx: dict) -> str:
    lines: list[str] = []
    ecu  = _html_escape(ctx.get("ecu_name", ""))
    proto = _html_escape(ctx.get("protocol_name", ""))

    # §1 Short Description
    lines.append("<h1>Introduction</h1>")
    lines.append("<h2>Short Description</h2>")
    lines.append(
        f"<p>This document specifies the UDS (Unified Diagnostic Services) "
        f"implementation requirements for the <strong>{ecu}</strong> ECU "
        f"(protocol: <strong>{proto}</strong>). "
        f"It covers all diagnostic services, data identifiers, routines, and "
        f"security mechanisms implemented in the AUTOSAR DCM.</p>"
    )
    lines.append("<h3>Definition of this specification</h3>")
    lines.append(
        "<p>This specification is generated automatically from the AUTOSAR ARXML "
        "configuration using <strong>udsxml2tex</strong>. It defines the diagnostic "
        "communication behaviour of the ECU according to ISO&nbsp;14229 (UDS) and "
        "ISO&nbsp;15765 (UDS on CAN).</p>"
    )
    lines.append("<h3>Clarification of specification</h3>")
    lines.append(
        "<p>All hexadecimal values are prefixed with <code>0x</code>. "
        "Byte fields marked <em>variable</em> depend on runtime parameters. "
        "Session names and security level names are derived from the ARXML short names.</p>"
    )

    # §2 About this document
    lines.append("<h2>About this Document</h2>")
    lines.append("<h3>Term Definitions and Abbreviations</h3>")
    abbrevs = [
        ("ADR",  "Attempt Delay Record"),
        ("CAN",  "Controller Area Network"),
        ("CanTp","CAN Transport Protocol (ISO 15765-2)"),
        ("DCM",  "Diagnostic Communication Manager (AUTOSAR)"),
        ("DEM",  "Diagnostic Event Manager (AUTOSAR)"),
        ("DID",  "Data Identifier"),
        ("DTC",  "Diagnostic Trouble Code"),
        ("ECU",  "Electronic Control Unit"),
        ("FSM",  "Finite State Machine"),
        ("NRC",  "Negative Response Code"),
        ("OSI",  "Open Systems Interconnection"),
        ("PCI",  "Protocol Control Information"),
        ("RID",  "Routine Identifier"),
        ("SID",  "Service Identifier"),
        ("UDS",  "Unified Diagnostic Services (ISO 14229)"),
    ]
    lines.append(_html_table(["Abbreviation", "Definition"], [[a, d] for a, d in abbrevs]))
    lines.append("<h3>Document Generation</h3>")
    lines.append(
        "<p>This document is generated by <strong>udsxml2tex</strong> from AUTOSAR DCM, "
        "CanTp, and DEM ARXML files. All tables and diagrams are derived automatically "
        "from the configuration data; no manual editing is required.</p>"
    )

    # §3 Context Information
    lines.append("<h2>Context Information</h2>")
    lines.append("<h3>Operational Environment</h3>")
    lines.append(
        "<p>The ECU communicates with diagnostic tools (testers) over a CAN bus using "
        "ISO&nbsp;15765-2 (CanTp) as the transport layer and ISO&nbsp;14229 (UDS) as the "
        "application layer. Physical and functional CAN addressing modes are supported.</p>"
    )
    lines.append("<h3>Use Cases</h3>")
    use_cases = [
        ("End-of-line programming",  "Flash reprogramming of ECU software and calibration data."),
        ("Field diagnostics",         "Fault code reading, clearing, and live data access by service tools."),
        ("Software download",         "In-vehicle firmware update via diagnostic tester."),
        ("Security access",           "Restricted diagnostic functions protected by seed/key authentication."),
    ]
    lines.append(_html_table(["Use Case", "Description"], [[u, d] for u, d in use_cases]))
    lines.append("<h3>Reference Documents</h3>")
    lines.append("<h4>International Standards</h4>")
    refs = [
        ("ISO 14229-1:2020", "UDS — Application layer"),
        ("ISO 14229-2:2013", "UDS — Session layer"),
        ("ISO 15765-2:2016", "UDS on CAN — Transport layer"),
        ("ISO 15765-3:2004", "UDS on CAN — Implementation"),
    ]
    lines.append(_html_table(["Document", "Title"], [[r, t] for r, t in refs]))
    lines.append("<h4>Supported Services Summary</h4>")
    lines.append("<ul>")
    for svc in ctx.get("services", []):
        lines.append(
            f"<li>{_html_hex(svc.service_id_hex)} &mdash; "
            f"{_html_escape(svc.short_name)}</li>"
        )
    lines.append("</ul>")

    return "\n".join(lines)


def _render_html_low_layer_index(ctx: dict) -> str:
    """§4 Network Protocol Layers — section overview with links to sub-pages."""
    current = ctx.get("_current_path", "sections/1_low_layer/index.html")
    lines: list[str] = []
    lines.append("<h1>Network Protocol Layers</h1>")
    lines.append(
        "<p>This section describes the communication stack layers for UDS diagnostic "
        "communication over CAN (DoCAN), following the OSI model from the data link "
        "layer through the session layer.</p>"
    )
    sub_pages = [
        ("sections/1_low_layer/2_datalink/index.html",
         "Data Link Layer",
         "CAN frame padding and addressing modes"),
        ("sections/1_low_layer/3_network/index.html",
         "Network Layer",
         "Physical and functional CAN identifiers"),
        ("sections/1_low_layer/4_transport/index.html",
         "Transport Layer",
         "ISO&nbsp;15765-2 CanTp PCI frame types and timing"),
        ("sections/1_low_layer/5_session/index.html",
         "Session Layer",
         "Diagnostic sessions, S3 timeout, and timing parameters"),
    ]
    lines.append("<ul>")
    for path, title, desc in sub_pages:
        href = _relpath(current, path)
        lines.append(f'<li><a href="{href}">{title}</a> &mdash; {desc}</li>')
    lines.append("</ul>")
    return "\n".join(lines)


def _render_html_low_datalink(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Data Link Layer</h1>")
    lines.append(
        "<p>In diagnostic communication over CAN (DoCAN), the data link layer is "
        "responsible for physical transmission of CAN frames. Unused bytes in a frame "
        "are filled with a padding byte. The default padding value is <code>0x00</code> "
        "as per ISO&nbsp;15765-2.</p>"
    )
    lines.append("<h2>CAN Frame Padding</h2>")
    pad_rows = [
        ["Standard (11-bit ID)", "0x00", "ISO 15765-2 default"],
        ["Extended (29-bit ID)", "0x00", "ISO 15765-2 default"],
    ]
    lines.append(_html_table(["Address Type", "Padding Byte", "Note"], pad_rows,
                              caption="CAN frame padding configuration"))
    lines.append("<h2>Addressing Modes</h2>")
    lines.append(
        "<p>Two CAN addressing modes are supported:</p>"
        "<ul>"
        "<li><strong>Physical addressing</strong> — unicast request from tester to a single ECU.</li>"
        "<li><strong>Functional addressing</strong> — broadcast request to all ECUs in a function group.</li>"
        "</ul>"
    )
    return "\n".join(lines)


def _render_html_low_network(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Network Layer</h1>")
    lines.append(
        "<p>The network layer handles CAN message routing via assigned CAN identifiers. "
        "Physical and functional CAN IDs are configured in the AUTOSAR CanTp / DCM "
        "configuration.</p>"
    )
    can_rx = ctx.get("can_rx_id")
    can_tx = ctx.get("can_tx_id")
    can_func = ctx.get("can_functional_id")
    if can_rx or can_tx or can_func:
        rows = []
        if can_rx:
            rows.append(["Physical Rx", "Physical request (tester to ECU)", _html_escape(str(can_rx))])
        if can_tx:
            rows.append(["Physical Tx", "Physical response (ECU to tester)", _html_escape(str(can_tx))])
        if can_func:
            rows.append(["Functional", "Functional request (broadcast)", _html_escape(str(can_func))])
        lines.append(_html_table(["Type", "Description", "CAN ID"], rows,
                                  caption="Configured CAN identifiers"))
    else:
        lines.append("<p>CAN IDs are OEM-specific. Refer to the vehicle communication matrix.</p>")
    return "\n".join(lines)


def _render_html_low_transport(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Transport Layer</h1>")
    lines.append(
        "<p>ISO&nbsp;15765-2 (CanTp) defines the transport layer for UDS on CAN. "
        "It provides segmentation and reassembly of multi-frame messages using four "
        "Protocol Control Information (PCI) frame types.</p>"
    )
    lines.append("<h2>PCI Frame Types</h2>")
    pci_rows = [
        ["SF (Single Frame)",      "A single CAN frame containing the entire message.",
         "1st byte: 0xL (L = data length)"],
        ["FF (First Frame)",       "Initial frame of a segmented message.",
         "1st byte: 0x1L, 2nd byte: lower 8 bits of length"],
        ["CF (Consecutive Frame)", "Subsequent frames of a segmented message.",
         "1st byte: 0x2S (S = sequence number 1&ndash;15)"],
        ["FC (Flow Control)",      "Receiver instructs sender to continue, wait, or stop.",
         "1st byte: 0x3F, 2nd: BS, 3rd: STmin"],
    ]
    lines.append(_html_table(["Type", "Description", "PCI Structure"], pci_rows,
                              caption="PCI byte layout in ISO 15765-2"))
    lines.append("<h2>Timing Parameters</h2>")
    timing_rows = [
        ["N_As", "Time for the sender to transmit a PDU."],
        ["N_Bs", "Time to wait for a Flow Control after sending a FF or CF block."],
        ["N_Cs", "Time to wait before sending the next CF."],
        ["N_Ar", "Time for the receiver to transmit an FC frame."],
        ["N_Br", "Time before the receiver sends an FC after receiving an FF."],
        ["N_Cr", "Time to wait for the next CF after receiving an FC."],
    ]
    lines.append(_html_table(["Parameter", "Description"], timing_rows,
                              caption="ISO 15765-2 network-layer timing parameters"))
    return "\n".join(lines)


def _render_html_low_session(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Session Layer</h1>")
    s3 = ctx.get("s3_server")
    lines.append(
        "<p>The session layer manages the lifecycle of diagnostic sessions. "
        "S3 server timeout (session keep-alive): <strong>"
        + _html_escape(str(s3) if s3 else "OEM defined")
        + "</strong>. TesterPresent (SID&nbsp;0x3E) must be sent within S3 to keep "
        "non-default sessions active.</p>"
    )
    sessions = ctx.get("sessions", [])
    if sessions:
        rows = [
            [_html_hex(s.session_id_hex), _html_escape(s.short_name),
             _html_escape(str(s.p2_server_max) if s.p2_server_max is not None else "&mdash;"),
             _html_escape(str(s.p2_star_server_max) if s.p2_star_server_max is not None else "&mdash;")]
            for s in sessions
        ]
        lines.append("<h2>Configured Sessions</h2>")
        lines.append(_html_table(
            ["Session ID", "Name", "P2 max (ms)", "P2* max (ms)"], rows,
            caption="Session timing parameters"))
    lines.append("<h2>Session Transitions</h2>")
    lines.append(
        "<p>Session transitions are triggered by DiagnosticSessionControl (SID&nbsp;0x10). "
        "After a session change or ECU reset, all SecurityAccess levels are locked "
        "(FSM returns to state&nbsp;A per ISO&nbsp;14229-1 Annex&nbsp;I).</p>"
    )
    if sessions:
        try:
            s3_value = float(s3) if s3 not in (None, "") else 5.0
        except (TypeError, ValueError):
            s3_value = 5.0
        lines.append("<h3>Session State Diagram</h3>")
        lines.append(_mermaid_block(
            _build_session_state_mermaid(sessions, s3_value)
        ))
    return "\n".join(lines)


# Keep the old monolithic function as a fallback alias (unused in generate_html_zip)
def _render_html_low_layer(ctx: dict) -> str:
    return _render_html_low_layer_index(ctx)


def _html_req_resp_tables(svc, dids: list, routines: list, security_levels: list) -> list[str]:
    """Return list of HTML strings for Request + Positive Response byte tables."""
    lines = []
    sid = svc.service_id_hex
    sid_val = int(sid, 16)
    prs_val = sid_val + 0x40
    sid_hex = _html_hex(sid)
    prs_hex = _html_hex(f"0x{prs_val:02X}")

    # Build request rows
    req_rows = [[f"1", sid_hex, f"Service Identifier (SID)"]]
    rsp_rows = [[f"1", prs_hex, f"Positive Response SID (SID+0x40)"]]

    if sid == "0x10":  # DiagnosticSessionControl
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01..0x7F"
        req_rows.append(["2", sf_vals, "Sub-function (sessionType)"])
        rsp_rows += [
            ["2", sf_vals, "Sub-function (sessionType)"],
            ["3&ndash;4", "&mdash;", "P2Server_max (ms, big-endian)"],
            ["5&ndash;6", "&mdash;", "P2*Server_max / 25 ms (big-endian)"],
        ]
    elif sid == "0x11":  # ECUReset
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01/0x02/0x03"
        req_rows.append(["2", sf_vals, "Sub-function (resetType)"])
        rsp_rows.append(["2", sf_vals, "Sub-function (resetType)"])
    elif sid == "0x14":  # ClearDiagnosticInformation
        req_rows += [
            ["2", "&mdash;", "groupOfDTC[2] (high byte)"],
            ["3", "&mdash;", "groupOfDTC[1] (mid byte)"],
            ["4", "&mdash;", "groupOfDTC[0] (low byte)"],
        ]
    elif sid == "0x19":  # ReadDTCInformation
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01..0x19"
        req_rows.append(["2", sf_vals, "Sub-function (reportType)"])
        req_rows.append(["3+", "&mdash;", "Parameters (depends on sub-function)"])
        rsp_rows.append(["2", sf_vals, "Sub-function (reportType)"])
        rsp_rows.append(["3+", "&mdash;", "DTC records (depends on sub-function)"])
    elif sid == "0x22":  # ReadDataByIdentifier
        req_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
            ["4+", "&mdash;", "dataRecord (variable length)"],
        ]
    elif sid == "0x27":  # SecurityAccess
        req_rows += [
            ["2", "0x01/0x03/...", "Sub-function (requestSeed, odd value)"],
            ["3+", "&mdash;", "SecurityAccessDataRecord (optional)"],
        ]
        rsp_rows += [
            ["2", "0x01/0x03/...", "Sub-function (requestSeed)"],
            ["3+", "&mdash;", "securitySeed (N bytes)"],
        ]
    elif sid == "0x28":  # CommunicationControl
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x00..0x03"
        req_rows += [
            ["2", sf_vals, "Sub-function (controlType)"],
            ["3", "&mdash;", "communicationType"],
        ]
        rsp_rows.append(["2", sf_vals, "Sub-function (controlType)"])
    elif sid == "0x29":  # Authentication
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01..0x0A"
        req_rows.append(["2", sf_vals, "Sub-function (authenticationTask)"])
        req_rows.append(["3+", "&mdash;", "authenticationData (depends on sub-function)"])
        rsp_rows.append(["2", sf_vals, "Sub-function (authenticationTask)"])
        rsp_rows.append(["3+", "&mdash;", "authenticationData (depends on sub-function)"])
    elif sid == "0x2E":  # WriteDataByIdentifier
        req_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
            ["4+", "&mdash;", "dataRecord (variable length)"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "dataIdentifier[1] (high byte)"],
            ["3", "&mdash;", "dataIdentifier[0] (low byte)"],
        ]
    elif sid == "0x31":  # RoutineControl
        sf_vals = "0x01 / 0x02 / 0x03"
        req_rows += [
            ["2", sf_vals, "Sub-function (routineControlType)"],
            ["3", "&mdash;", "routineIdentifier[1] (high byte)"],
            ["4", "&mdash;", "routineIdentifier[0] (low byte)"],
            ["5+", "&mdash;", "routineOptionRecord (optional)"],
        ]
        rsp_rows += [
            ["2", sf_vals, "Sub-function (routineControlType)"],
            ["3", "&mdash;", "routineIdentifier[1] (high byte)"],
            ["4", "&mdash;", "routineIdentifier[0] (low byte)"],
            ["5+", "&mdash;", "routineStatusRecord (optional)"],
        ]
    elif sid == "0x34":  # RequestDownload
        req_rows += [
            ["2", "&mdash;", "dataFormatIdentifier"],
            ["3", "&mdash;", "addressAndLengthFormatIdentifier"],
            ["4+", "&mdash;", "memoryAddress + memorySize"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "lengthFormatIdentifier"],
            ["3+", "&mdash;", "maxNumberOfBlockLength"],
        ]
    elif sid == "0x36":  # TransferData
        req_rows += [
            ["2", "&mdash;", "blockSequenceCounter"],
            ["3+", "&mdash;", "transferRequestParameterRecord"],
        ]
        rsp_rows += [
            ["2", "&mdash;", "blockSequenceCounter"],
            ["3+", "&mdash;", "transferResponseParameterRecord (optional)"],
        ]
    elif sid == "0x37":  # RequestTransferExit
        req_rows.append(["2+", "&mdash;", "transferRequestParameterRecord (optional)"])
        rsp_rows.append(["2+", "&mdash;", "transferResponseParameterRecord (optional)"])
    elif sid == "0x3E":  # TesterPresent
        req_rows.append(["2", "0x00", "Sub-function (zeroSubFunction)"])
        rsp_rows.append(["2", "0x00", "Sub-function (zeroSubFunction)"])
    elif sid == "0x85":  # ControlDTCSetting
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions) if svc.sub_functions else "0x01 / 0x02"
        req_rows += [
            ["2", sf_vals, "Sub-function (DTCSettingType)"],
            ["3+", "&mdash;", "DTCSettingControlOptionRecord (optional)"],
        ]
        rsp_rows.append(["2", sf_vals, "Sub-function (DTCSettingType)"])
    elif svc.sub_functions:
        sf_vals = " / ".join(_html_hex(sf.sub_function_id_hex) for sf in svc.sub_functions)
        req_rows.append(["2", sf_vals, "Sub-function"])
        req_rows.append(["3+", "&mdash;", "Parameters (service-specific)"])
        rsp_rows.append(["2", sf_vals, "Sub-function"])
        rsp_rows.append(["3+", "&mdash;", "Response data"])
    else:
        req_rows.append(["2+", "&mdash;", "Service-specific parameters"])
        rsp_rows.append(["2+", "&mdash;", "Service-specific response data"])

    lines.append("<h3>Request Message</h3>")
    lines.append(_html_table(["Byte", "Value", "Description"], req_rows))
    lines.append("<h3>Positive Response Message</h3>")
    lines.append(_html_table(["Byte", "Value", "Description"], rsp_rows))
    return lines


def _render_html_services(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Application Layers</h1>")

    services       = ctx.get("services", [])
    sessions       = ctx.get("sessions", [])
    dids           = ctx.get("dids", [])
    routines       = ctx.get("routines", [])
    security_levels = ctx.get("security_levels", [])
    sess_names     = [s.short_name for s in sessions]

    # ---- §5.1 Overview -------------------------------------------------------
    lines.append('<h2 id="sec-overview">Overview</h2>')
    lines.append(
        "<p>This section provides cross-reference matrices for all UDS services, "
        "negative response codes, data identifiers, and routines configured for this ECU.</p>"
    )

    # SID × session matrix
    if services:
        headers = ["SID", "Service", "Sub-functions"] + sess_names
        rows = []
        for svc in services:
            sf_count = str(len(svc.sub_functions)) if svc.sub_functions else "&mdash;"
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(svc.service_id_hex), _html_escape(svc.short_name), sf_count] + cells)
        lines.append("<h3>Supported SID and Sub-function List</h3>")
        lines.append(_html_table(headers, rows, caption="SID support per diagnostic session"))

    # NRC × SID matrix
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append('<span class="badge-yes">o</span>' if found else '<span class="badge-no">x</span>')
                rows.append(row)
            lines.append("<h3>Supported NRC List</h3>")
            lines.append(_html_table(headers, rows, caption="NRC support per SID"))

    # DID × session matrix
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">o</span>' if did.read_access else '<span class="badge-no">x</span>'
            w = '<span class="badge-yes">o</span>' if did.write_access else '<span class="badge-no">x</span>'
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + cells)
        lines.append("<h3>Supported DID List</h3>")
        lines.append(_html_table(headers, rows, caption="DID support per diagnostic session"))

    # RID × session matrix
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start  = '<span class="badge-yes">o</span>' if rt.start_supported  else '<span class="badge-no">x</span>'
            stop   = '<span class="badge-yes">o</span>' if rt.stop_supported   else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            cells  = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + cells)
        lines.append("<h3>Supported RID List</h3>")
        lines.append(_html_table(headers, rows, caption="RID support per diagnostic session"))

    # ---- Intra-page TOC for services ----------------------------------------
    if services:
        lines.append("<h2>Service Sections</h2>")
        lines.append("<ul>")
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").upper()
            lines.append(
                f'<li><a href="#sid-{sid_clean}">'
                f'{_html_escape(svc.short_name)} '
                f'({_html_hex(svc.service_id_hex)})</a></li>'
            )
        lines.append("</ul>")

    # ---- §5.x Per-service sections -------------------------------------------
    for i, svc in enumerate(services, start=2):
        sid       = _html_hex(svc.service_id_hex)
        sid_clean = svc.service_id_hex.replace("0x", "").upper()
        lines.append(
            f'<h2 id="sid-{sid_clean}">'
            f'{_html_escape(svc.short_name)} ({sid}) service</h2>'
        )

        # h3: Overview
        lines.append("<h3>Overview</h3>")
        if svc.supported_sessions:
            lines.append("<p><strong>Supported sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in svc.supported_sessions) + "</p>")
        if svc.required_security_levels:
            lines.append("<p><strong>Required security level:</strong> "
                         + ", ".join(_html_escape(s) for s in svc.required_security_levels) + "</p>")
        if svc.sub_functions:
            sf_rows = [[_html_hex(sf.sub_function_id_hex), _html_escape(sf.short_name)]
                       for sf in svc.sub_functions]
            lines.append(_html_table(["Sub-function", "Description"], sf_rows))

        # h3: Request + Positive Response byte tables
        lines.extend(_html_req_resp_tables(svc, dids, routines, security_levels))

        # h3: NRCs
        if svc.nrc_list:
            nrc_rows = [[_html_hex(nrc.nrc_code_hex), _html_escape(nrc.nrc_name)]
                        for nrc in svc.nrc_list]
            lines.append("<h3>Supported Negative Response Codes</h3>")
            lines.append(_html_table(["NRC", "Description"], nrc_rows))

        # ---- Service-specific extra sections ---------------------------------

        # SecurityAccess (0x27): security levels + FSM
        if svc.service_id_hex == "0x27" and security_levels:
            sl_rows = []
            for s in security_levels:
                sl_rows.append([
                    _html_hex(s.security_level_hex),
                    _html_escape(s.short_name),
                    str(s.num_max_attempts),
                    str(s.attempt_delay),
                    str(s.delay_time_on_boot) if s.delay_time_on_boot else "&mdash;",
                    "On" if s.attempt_counter_enabled else "Off",
                    str(s.seed_size),
                    str(s.key_size),
                    str(s.adr_size),
                    _html_escape(s.algorithm_ref) if s.algorithm_ref else "&mdash;",
                ])
            lines.append("<h3>Security Access Levels</h3>")
            lines.append(_html_table(
                ["Level", "Name", "Max Att.", "Delay (s)", "Boot Delay (s)",
                 "Counter", "Seed (B)", "Key (B)", "ADR (B)", "Algorithm"],
                sl_rows, caption="Configured security access levels"))

            lines.append("<h3>Security Access State Machine (ISO&nbsp;14229-1 Annex&nbsp;I)</h3>")
            lines.append(
                "<p>States: <strong>A</strong>&nbsp;&mdash;&nbsp;All locked, no seed; "
                "<strong>B</strong>&nbsp;&mdash;&nbsp;All locked, seed sent; "
                "<strong>C</strong>&nbsp;&mdash;&nbsp;Unlocked, no seed; "
                "<strong>D</strong>&nbsp;&mdash;&nbsp;Unlocked, seed sent.</p>"
            )
            fsm_rows = [
                ["A &rarr; B", "requestSeed: valid message, session, security level", "Positive response (seed)"],
                ["B &rarr; A", "sendKey: wrong key, Att_Cnt &lt; Att_Cnt_Limit",      "NRC&nbsp;0x35 (invalidKey)"],
                ["B &rarr; A", "sendKey: wrong key, Att_Cnt &ge; Att_Cnt_Limit",      "NRC&nbsp;0x36 (exceededAttempts) + timer"],
                ["B,C,D &rarr; A", "Session change or ECU reset",                     "&mdash; (all levels locked)"],
                ["A &rarr; A", "requestSeed: Delay_Timer still active",               "NRC&nbsp;0x37 (timeDelayNotExpired)"],
                ["B &rarr; C", "sendKey: correct key",                                "Positive response (unlocked)"],
                ["C &rarr; D", "requestSeed: valid message, session, security level", "Positive response (seed)"],
                ["D &rarr; C", "sendKey (any result)",                                "See NRC&nbsp;0x35&nbsp;/&nbsp;Positive"],
            ]
            lines.append(_html_table(
                ["Transition", "Condition", "Response / NRC"],
                fsm_rows, caption="State transitions (ISO 14229-1 Table I.2)"))

            protocol_rows = ctx.get("protocol_rows", [])
            if protocol_rows and len(protocol_rows) > 1:
                lines.append("<h3>Multi-Client Protocol Configuration (ISO&nbsp;14229-1 Annex&nbsp;J)</h3>")
                lines.append(
                    "<p>Multiple diagnostic client slots are configured. "
                    "Lower priority number = higher priority. "
                    "A higher-priority client preempts lower-priority protocols "
                    "after the preempt timeout.</p>"
                )
                pr_rows = []
                for row in protocol_rows:
                    timeout_str = f"{row.preempt_timeout:.3f}&nbsp;s" if row.preempt_timeout else "&mdash;"
                    conns = "; ".join(
                        _html_escape(c.short_name)
                        + (f" (Rx:{_html_escape(c.rx_addr)}, Tx:{_html_escape(c.tx_addr)})" if c.rx_addr else "")
                        for c in row.connections
                    ) if row.connections else "&mdash;"
                    pr_rows.append([
                        _html_escape(row.short_name),
                        _html_escape(row.protocol_type) if row.protocol_type else "&mdash;",
                        str(row.priority), timeout_str,
                        _html_escape(row.trans_type) if row.trans_type else "&mdash;",
                        conns,
                    ])
                lines.append(_html_table(
                    ["Row", "Type", "Priority", "Preempt Timeout", "Trans Type", "Connections"],
                    pr_rows))

        # ReadDataByIdentifier / WriteDataByIdentifier: DID list
        if svc.service_id_hex in ("0x22", "0x2E"):
            access_filter = "read_access" if svc.service_id_hex == "0x22" else "write_access"
            filtered_dids = [d for d in dids if getattr(d, access_filter)]
            if filtered_dids:
                label = "ReadDataByIdentifier" if svc.service_id_hex == "0x22" else "WriteDataByIdentifier"
                lines.append(f"<h3>Supported DID List ({label})</h3>")
                did_rows = []
                for did in filtered_dids:
                    cells = [
                        '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                        else '<span class="badge-no">x</span>'
                        for s in sessions
                    ]
                    did_rows.append([
                        _html_hex(did.did_id_hex),
                        _html_escape(did.short_name),
                        str(did.total_byte_length) if did.total_byte_length else "&mdash;",
                    ] + cells)
                lines.append(_html_table(
                    ["DID", "Name", "Length (B)"] + sess_names, did_rows,
                    caption=f"DIDs accessible via {_html_escape(label)}"))

                # DID data elements detail
                lines.append("<h3>DID Data Elements</h3>")
                for did in filtered_dids:
                    did_clean = did.did_id_hex.replace("0x", "").upper()
                    lines.append(
                        f'<h4 id="did-{did_clean}">'
                        f'{_html_hex(did.did_id_hex)} &mdash; {_html_escape(did.short_name)}</h4>'
                    )
                    if did.description:
                        lines.append(f'<p class="meta">{_html_escape(did.description)}</p>')
                    if did.data_elements:
                        de_rows = []
                        for de in did.data_elements:
                            de_rows.append([
                                _html_escape(de.short_name),
                                str(de.byte_position),
                                str(de.bit_size),
                                _html_escape(de.data_type or "&mdash;"),
                                _html_escape(de.unit or "&mdash;"),
                                _html_escape(de.description) if de.description else "&mdash;",
                            ])
                        lines.append(_html_table(
                            ["Name", "Byte Pos", "Bits", "Type", "Unit", "Description"],
                            de_rows))
                    has_impl = any(de.read_function or de.write_function or de.global_variables
                                   for de in did.data_elements)
                    if has_impl:
                        impl_rows = []
                        for de in did.data_elements:
                            impl_rows.append([
                                _html_escape(de.short_name),
                                _html_escape(de.read_function) if de.read_function else "&mdash;",
                                _html_escape(de.write_function) if de.write_function else "&mdash;",
                                _html_escape(", ".join(de.global_variables)) if de.global_variables else "&mdash;",
                            ])
                        lines.append(_html_table(
                            ["Element", "Read Function", "Write Function", "Variables"],
                            impl_rows, caption=f"C implementation &mdash; {_html_escape(did.short_name)}"))

        # RoutineControl (0x31): RID list
        if svc.service_id_hex == "0x31" and routines:
            lines.append("<h3>Supported RID List</h3>")
            for rt in routines:
                rid_clean = rt.routine_id_hex.replace("0x", "").upper()
                lines.append(
                    f'<h4 id="rid-{rid_clean}">'
                    f'{_html_hex(rt.routine_id_hex)} &mdash; {_html_escape(rt.short_name)}</h4>'
                )
                if rt.description:
                    lines.append(f'<p class="meta">{_html_escape(rt.description)}</p>')
                ops = []
                if rt.start_supported:  ops.append("Start (0x01)")
                if rt.stop_supported:   ops.append("Stop (0x02)")
                if rt.result_supported: ops.append("RequestResults (0x03)")
                props = []
                if ops:
                    props.append("<strong>Operations:</strong> " + ", ".join(ops))
                if rt.supported_sessions:
                    props.append("<strong>Sessions:</strong> "
                                 + ", ".join(_html_escape(s) for s in rt.supported_sessions))
                if rt.required_security_levels:
                    props.append("<strong>Security:</strong> "
                                 + ", ".join(_html_escape(s) for s in rt.required_security_levels))
                if props:
                    lines.append("<p>" + " &emsp; ".join(props) + "</p>")
                if rt.in_parameters:
                    param_rows = [
                        [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                         _html_escape(p.data_type or "&mdash;"),
                         _html_escape(p.description) if p.description else "&mdash;"]
                        for p in rt.in_parameters
                    ]
                    lines.append("<h5>Input Parameters</h5>")
                    lines.append(_html_table(["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
                if rt.out_parameters:
                    param_rows = [
                        [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                         _html_escape(p.data_type or "&mdash;"),
                         _html_escape(p.description) if p.description else "&mdash;"]
                        for p in rt.out_parameters
                    ]
                    lines.append("<h5>Output Parameters</h5>")
                    lines.append(_html_table(["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
                has_impl = rt.start_function or rt.stop_function or rt.result_function or rt.global_variables
                if has_impl:
                    impl_parts = []
                    if rt.start_function:
                        impl_parts.append(f"start: <code>{_html_escape(rt.start_function)}</code>")
                    if rt.stop_function:
                        impl_parts.append(f"stop: <code>{_html_escape(rt.stop_function)}</code>")
                    if rt.result_function:
                        impl_parts.append(f"result: <code>{_html_escape(rt.result_function)}</code>")
                    lines.append("<h5>C Implementation</h5>")
                    if impl_parts:
                        lines.append("<p><strong>Functions:</strong> " + "; ".join(impl_parts) + "</p>")
                    if rt.global_variables:
                        lines.append(
                            "<p><strong>Referenced variables:</strong> "
                            + ", ".join(f"<code>{_html_escape(v)}</code>" for v in rt.global_variables)
                            + "</p>"
                        )

    return "\n".join(lines)


def _render_html_high_overview(ctx: dict) -> str:
    """§5 Application Layers — cross-reference matrices + links to per-service pages."""
    current = ctx.get("_current_path", "sections/2_high_layer/index.html")
    lines: list[str] = []
    lines.append("<h1>Application Layers</h1>")
    lines.append(
        "<p>This section defines all UDS application-layer services implemented by "
        "this ECU. Cross-reference matrices are provided below; follow the links in "
        "the Service Index for each service&rsquo;s detailed specification.</p>"
    )

    services       = ctx.get("services", [])
    sessions       = ctx.get("sessions", [])
    dids           = ctx.get("dids", [])
    routines       = ctx.get("routines", [])
    sess_names     = [s.short_name for s in sessions]

    # Service index with per-service links
    if services:
        lines.append("<h2>Service Index</h2><ul>")
        for i, svc in enumerate(services, start=2):
            sid_clean = svc.service_id_hex.replace("0x", "").lower()
            path = f"sections/2_high_layer/sid{sid_clean}/index.html"
            href = _relpath(current, path)
            lines.append(
                f'<li><a href="{href}">'
                f'{_html_escape(svc.short_name)} '
                f'({_html_hex(svc.service_id_hex)})</a></li>'
            )
        lines.append("</ul>")

    # SID × session matrix
    if services:
        headers = ["SID", "Service", "Sub-functions"] + sess_names
        rows = []
        for svc in services:
            sf_count = str(len(svc.sub_functions)) if svc.sub_functions else "&mdash;"
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(svc.service_id_hex), _html_escape(svc.short_name), sf_count] + cells)
        lines.append("<h2>SID &times; Session Matrix</h2>")
        lines.append(_html_table(headers, rows, caption="SID support per diagnostic session"))

    # NRC × SID matrix
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append('<span class="badge-yes">o</span>' if found else '<span class="badge-no">x</span>')
                rows.append(row)
            lines.append("<h2>NRC &times; SID Matrix</h2>")
            lines.append(_html_table(headers, rows, caption="NRC support per SID"))

    # DID × session matrix
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">o</span>' if did.read_access else '<span class="badge-no">x</span>'
            w = '<span class="badge-yes">o</span>' if did.write_access else '<span class="badge-no">x</span>'
            cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + cells)
        lines.append("<h2>DID &times; Session Matrix</h2>")
        lines.append(_html_table(headers, rows, caption="DID support per diagnostic session"))

    # RID × session matrix
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start  = '<span class="badge-yes">o</span>' if rt.start_supported  else '<span class="badge-no">x</span>'
            stop   = '<span class="badge-yes">o</span>' if rt.stop_supported   else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            cells  = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + cells)
        lines.append("<h2>RID &times; Session Matrix</h2>")
        lines.append(_html_table(headers, rows, caption="RID support per diagnostic session"))

    return "\n".join(lines)


def _render_html_service_page(ctx: dict, svc, idx: int) -> str:
    """Render a single UDS service detail page."""
    sid = _html_hex(svc.service_id_hex)
    lines: list[str] = []
    lines.append(
        f"<h1>{_html_escape(svc.short_name)} ({sid}) service</h1>"
    )

    sessions        = ctx.get("sessions", [])
    dids            = ctx.get("dids", [])
    routines        = ctx.get("routines", [])
    security_levels = ctx.get("security_levels", [])
    sess_names      = [s.short_name for s in sessions]

    # Overview
    lines.append("<h2>Overview</h2>")
    if svc.supported_sessions:
        lines.append("<p><strong>Supported sessions:</strong> "
                     + ", ".join(_html_escape(s) for s in svc.supported_sessions) + "</p>")
    if svc.required_security_levels:
        lines.append("<p><strong>Required security level:</strong> "
                     + ", ".join(_html_escape(s) for s in svc.required_security_levels) + "</p>")
    if svc.sub_functions:
        sf_rows = [[_html_hex(sf.sub_function_id_hex), _html_escape(sf.short_name)]
                   for sf in svc.sub_functions]
        lines.append("<h3>Sub-functions</h3>")
        lines.append(_html_table(["Sub-function", "Description"], sf_rows))

    # Request + Positive Response byte tables
    lines.append("<h2>Message Format</h2>")
    lines.extend(_html_req_resp_tables(svc, dids, routines, security_levels))

    # NRCs
    if svc.nrc_list:
        nrc_rows = [[_html_hex(nrc.nrc_code_hex), _html_escape(nrc.nrc_name)]
                    for nrc in svc.nrc_list]
        lines.append("<h2>Supported Negative Response Codes</h2>")
        lines.append(_html_table(["NRC", "Description"], nrc_rows))
        flow_html = _build_nrc_flowchart_html(svc)
        if flow_html:
            lines.append("<h3>NRC Check Flow</h3>")
            lines.append(flow_html)

    # SecurityAccess (0x27): security levels + FSM + protocol rows
    if svc.service_id_hex == "0x27" and security_levels:
        sl_rows = []
        for s in security_levels:
            sl_rows.append([
                _html_hex(s.security_level_hex),
                _html_escape(s.short_name),
                str(s.num_max_attempts),
                str(s.attempt_delay),
                str(s.delay_time_on_boot) if s.delay_time_on_boot else "&mdash;",
                "On" if s.attempt_counter_enabled else "Off",
                str(s.seed_size),
                str(s.key_size),
                str(s.adr_size),
                _html_escape(s.algorithm_ref) if s.algorithm_ref else "&mdash;",
            ])
        lines.append("<h2>Security Access Levels</h2>")
        lines.append(_html_table(
            ["Level", "Name", "Max Att.", "Delay (s)", "Boot Delay (s)",
             "Counter", "Seed (B)", "Key (B)", "ADR (B)", "Algorithm"],
            sl_rows, caption="Configured security access levels"))

        lines.append("<h2>Security Access State Machine (ISO&nbsp;14229-1 Annex&nbsp;I)</h2>")
        lines.append(
            "<p>States: <strong>A</strong>&nbsp;&mdash;&nbsp;All locked, no seed; "
            "<strong>B</strong>&nbsp;&mdash;&nbsp;All locked, seed sent; "
            "<strong>C</strong>&nbsp;&mdash;&nbsp;Unlocked, no seed; "
            "<strong>D</strong>&nbsp;&mdash;&nbsp;Unlocked, seed sent.</p>"
        )
        fsm_rows = [
            ["A &rarr; B",     "requestSeed: valid message, session, security level", "Positive response (seed)"],
            ["B &rarr; A",     "sendKey: wrong key, Att_Cnt &lt; Att_Cnt_Limit",     "NRC&nbsp;0x35 (invalidKey)"],
            ["B &rarr; A",     "sendKey: wrong key, Att_Cnt &ge; Att_Cnt_Limit",     "NRC&nbsp;0x36 (exceededAttempts) + timer"],
            ["B,C,D &rarr; A", "Session change or ECU reset",                        "&mdash; (all levels locked)"],
            ["A &rarr; A",     "requestSeed: Delay_Timer still active",              "NRC&nbsp;0x37 (timeDelayNotExpired)"],
            ["B &rarr; C",     "sendKey: correct key",                               "Positive response (unlocked)"],
            ["C &rarr; D",     "requestSeed: valid message, session, security level", "Positive response (seed)"],
            ["D &rarr; C",     "sendKey (any result)",                               "See NRC&nbsp;0x35&nbsp;/&nbsp;Positive"],
        ]
        lines.append(_html_table(
            ["Transition", "Condition", "Response / NRC"],
            fsm_rows, caption="State transitions (ISO 14229-1 Table I.2)"))
        lines.append("<h3>State Diagram</h3>")
        lines.append(_mermaid_block(_build_security_state_mermaid()))

        protocol_rows = ctx.get("protocol_rows", [])
        if protocol_rows and len(protocol_rows) > 1:
            lines.append("<h2>Multi-Client Protocol Configuration (ISO&nbsp;14229-1 Annex&nbsp;J)</h2>")
            lines.append(
                "<p>Multiple diagnostic client slots are configured. "
                "Lower priority number = higher priority. "
                "A higher-priority client preempts lower-priority protocols "
                "after the configured preempt timeout.</p>"
            )
            pr_rows = []
            for row in protocol_rows:
                timeout_str = f"{row.preempt_timeout:.3f}&nbsp;s" if row.preempt_timeout else "&mdash;"
                conns = "; ".join(
                    _html_escape(c.short_name)
                    + (f" (Rx:{_html_escape(c.rx_addr)}, Tx:{_html_escape(c.tx_addr)})" if c.rx_addr else "")
                    for c in row.connections
                ) if row.connections else "&mdash;"
                pr_rows.append([
                    _html_escape(row.short_name),
                    _html_escape(row.protocol_type) if row.protocol_type else "&mdash;",
                    str(row.priority), timeout_str,
                    _html_escape(row.trans_type) if row.trans_type else "&mdash;",
                    conns,
                ])
            lines.append(_html_table(
                ["Row", "Type", "Priority", "Preempt Timeout", "Trans Type", "Connections"],
                pr_rows, caption="Protocol rows (ISO 14229-1 Annex J)"))

    # ReadDataByIdentifier / WriteDataByIdentifier
    if svc.service_id_hex in ("0x22", "0x2E"):
        access_filter = "read_access" if svc.service_id_hex == "0x22" else "write_access"
        filtered_dids = [d for d in dids if getattr(d, access_filter)]
        if filtered_dids:
            label = "ReadDataByIdentifier" if svc.service_id_hex == "0x22" else "WriteDataByIdentifier"
            lines.append(f"<h2>Supported DID List ({label})</h2>")
            did_rows = []
            for did in filtered_dids:
                cells = [
                    '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                    else '<span class="badge-no">x</span>'
                    for s in sessions
                ]
                did_rows.append([
                    _html_hex(did.did_id_hex),
                    _html_escape(did.short_name),
                    str(did.total_byte_length) if did.total_byte_length else "&mdash;",
                ] + cells)
            lines.append(_html_table(
                ["DID", "Name", "Length (B)"] + sess_names, did_rows,
                caption=f"DIDs accessible via {_html_escape(label)}"))

            lines.append("<h2>DID Data Elements</h2>")
            for did in filtered_dids:
                did_clean = did.did_id_hex.replace("0x", "").upper()
                lines.append(
                    f'<h3 id="did-{did_clean}">'
                    f'{_html_hex(did.did_id_hex)} &mdash; {_html_escape(did.short_name)}</h3>'
                )
                if did.description:
                    lines.append(f'<p class="meta">{_html_escape(did.description)}</p>')
                if did.data_elements:
                    de_rows = []
                    for de in did.data_elements:
                        de_rows.append([
                            _html_escape(de.short_name),
                            str(de.byte_position),
                            str(de.bit_size),
                            _html_escape(de.data_type or "&mdash;"),
                            _html_escape(de.unit or "&mdash;"),
                            _html_escape(de.description) if de.description else "&mdash;",
                        ])
                    lines.append(_html_table(
                        ["Name", "Byte Pos", "Bits", "Type", "Unit", "Description"],
                        de_rows))
                has_impl = any(de.read_function or de.write_function or de.global_variables
                               for de in did.data_elements)
                if has_impl:
                    impl_rows = []
                    for de in did.data_elements:
                        impl_rows.append([
                            _html_escape(de.short_name),
                            _html_escape(de.read_function) if de.read_function else "&mdash;",
                            _html_escape(de.write_function) if de.write_function else "&mdash;",
                            _html_escape(", ".join(de.global_variables)) if de.global_variables else "&mdash;",
                        ])
                    lines.append(_html_table(
                        ["Element", "Read Function", "Write Function", "Variables"],
                        impl_rows,
                        caption=f"C implementation &mdash; {_html_escape(did.short_name)}"))

    # RoutineControl (0x31)
    if svc.service_id_hex == "0x31" and routines:
        lines.append("<h2>Supported RID List</h2>")
        for rt in routines:
            rid_clean = rt.routine_id_hex.replace("0x", "").upper()
            lines.append(
                f'<h3 id="rid-{rid_clean}">'
                f'{_html_hex(rt.routine_id_hex)} &mdash; {_html_escape(rt.short_name)}</h3>'
            )
            if rt.description:
                lines.append(f'<p class="meta">{_html_escape(rt.description)}</p>')
            ops = []
            if rt.start_supported:  ops.append("Start (0x01)")
            if rt.stop_supported:   ops.append("Stop (0x02)")
            if rt.result_supported: ops.append("RequestResults (0x03)")
            props = []
            if ops:
                props.append("<strong>Operations:</strong> " + ", ".join(ops))
            if rt.supported_sessions:
                props.append("<strong>Sessions:</strong> "
                             + ", ".join(_html_escape(s) for s in rt.supported_sessions))
            if rt.required_security_levels:
                props.append("<strong>Security:</strong> "
                             + ", ".join(_html_escape(s) for s in rt.required_security_levels))
            if props:
                lines.append("<p>" + " &emsp; ".join(props) + "</p>")
            if rt.in_parameters:
                param_rows = [
                    [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                     _html_escape(p.data_type or "&mdash;"),
                     _html_escape(p.description) if p.description else "&mdash;"]
                    for p in rt.in_parameters
                ]
                lines.append("<h4>Input Parameters</h4>")
                lines.append(_html_table(
                    ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
            if rt.out_parameters:
                param_rows = [
                    [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                     _html_escape(p.data_type or "&mdash;"),
                     _html_escape(p.description) if p.description else "&mdash;"]
                    for p in rt.out_parameters
                ]
                lines.append("<h4>Output Parameters</h4>")
                lines.append(_html_table(
                    ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))
            has_impl = rt.start_function or rt.stop_function or rt.result_function or rt.global_variables
            if has_impl:
                impl_parts = []
                if rt.start_function:
                    impl_parts.append(f"start: <code>{_html_escape(rt.start_function)}</code>")
                if rt.stop_function:
                    impl_parts.append(f"stop: <code>{_html_escape(rt.stop_function)}</code>")
                if rt.result_function:
                    impl_parts.append(f"result: <code>{_html_escape(rt.result_function)}</code>")
                lines.append("<h4>C Implementation</h4>")
                if impl_parts:
                    lines.append("<p><strong>Functions:</strong> " + "; ".join(impl_parts) + "</p>")
                if rt.global_variables:
                    lines.append(
                        "<p><strong>Referenced variables:</strong> "
                        + ", ".join(f"<code>{_html_escape(v)}</code>" for v in rt.global_variables)
                        + "</p>"
                    )

    return "\n".join(lines)


def _render_html_security(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>SecurityAccess (SID&nbsp;0x27)</h1>")
    lines.append(
        "<p>The SecurityAccess service (ISO&nbsp;14229-1 §12.8) restricts access to sensitive "
        "diagnostic functions using a seed/key challenge-response mechanism. "
        "Each security level has independent parameters for attempt limits and delay timers.</p>"
    )

    security_levels = ctx.get("security_levels", [])
    if security_levels:
        rows = []
        for s in security_levels:
            rows.append([
                _html_hex(s.security_level_hex),
                _html_escape(s.short_name),
                str(s.num_max_attempts),
                str(s.attempt_delay),
                str(s.delay_time_on_boot) if s.delay_time_on_boot else "&mdash;",
                "On" if s.attempt_counter_enabled else "Off",
                str(s.seed_size),
                str(s.key_size),
                str(s.adr_size),
                _html_escape(s.algorithm_ref) if s.algorithm_ref else "&mdash;",
                _html_escape(s.seed_key_increment_mode) if s.seed_key_increment_mode else "&mdash;",
            ])
        lines.append("<h2>Security Access Levels</h2>")
        lines.append(_html_table(
            ["Level", "Name", "Max Attempts", "Delay (s)", "Boot Delay (s)",
             "Counter", "Seed (B)", "Key (B)", "ADR (B)", "Algorithm", "Increment"],
            rows, caption="Configured security access levels"))

    lines.append("<h2>State Machine (ISO&nbsp;14229-1 Annex&nbsp;I)</h2>")
    lines.append(
        "<p>The SecurityAccess service uses a 4-state finite state machine (FSM) to manage "
        "locking state across all configured security levels. "
        "States: <strong>A</strong>&nbsp;&mdash;&nbsp;All locked, no seed pending; "
        "<strong>B</strong>&nbsp;&mdash;&nbsp;All locked, seed sent; "
        "<strong>C</strong>&nbsp;&mdash;&nbsp;Unlocked, no seed pending; "
        "<strong>D</strong>&nbsp;&mdash;&nbsp;Unlocked, seed sent.</p>"
    )
    fsm_rows = [
        ["A &rarr; B", "requestSeed: valid message, session, security level", "Positive response (seed)"],
        ["B &rarr; A", "sendKey: wrong key, Att_Cnt &lt; Att_Cnt_Limit", "NRC&nbsp;0x35 (invalidKey)"],
        ["B &rarr; A", "sendKey: wrong key, Att_Cnt &ge; Att_Cnt_Limit", "NRC&nbsp;0x36 (exceededAttempts) + start timer"],
        ["B,C,D &rarr; A", "Session change or ECU reset", "&mdash; (all levels locked)"],
        ["A &rarr; A", "requestSeed: Delay_Timer still active", "NRC&nbsp;0x37 (timeDelayNotExpired)"],
        ["B &rarr; C", "sendKey: correct key", "Positive response (unlocked)"],
        ["C &rarr; D", "requestSeed: valid message, session, security level", "Positive response (seed)"],
        ["D &rarr; C", "sendKey (any result)", "See NRC&nbsp;0x35&nbsp;/&nbsp;Positive"],
    ]
    lines.append(_html_table(
        ["Transition", "Condition", "Response / NRC"],
        fsm_rows,
        caption="SecurityAccess state transitions (ISO 14229-1 Table I.2)"))
    lines.append("<h3>State Diagram</h3>")
    lines.append(_mermaid_block(_build_security_state_mermaid()))

    protocol_rows = ctx.get("protocol_rows", [])
    if protocol_rows:
        if len(protocol_rows) > 1:
            lines.append("<h2>Multi-Client Protocol Configuration (ISO&nbsp;14229-1 Annex&nbsp;J)</h2>")
            lines.append(
                "<p>Multiple diagnostic client slots are configured. "
                "The DCM manages concurrent requests using protocol priority and preemption "
                "as recommended by ISO&nbsp;14229-1 Annex&nbsp;J. "
                "<strong>Priority rule:</strong> lower numeric value = higher priority. "
                "A higher-priority client preempts a lower-priority active protocol after "
                "the configured preempt timeout.</p>"
            )
        else:
            lines.append("<h2>Protocol Configuration</h2>")
        rows = []
        for row in protocol_rows:
            timeout_str = f"{row.preempt_timeout:.3f}&nbsp;s" if row.preempt_timeout else "&mdash;"
            conns = "; ".join(
                _html_escape(c.short_name)
                + (f" (Rx:&nbsp;{_html_escape(c.rx_addr)}, Tx:&nbsp;{_html_escape(c.tx_addr)})"
                   if c.rx_addr else "")
                for c in row.connections
            ) if row.connections else "&mdash;"
            rows.append([
                _html_escape(row.short_name),
                _html_escape(row.protocol_type) if row.protocol_type else "&mdash;",
                str(row.priority),
                timeout_str,
                _html_escape(row.trans_type) if row.trans_type else "&mdash;",
                conns,
            ])
        lines.append(_html_table(
            ["Protocol Row", "Type", "Priority", "Preempt Timeout", "Trans Type", "Connections"],
            rows, caption="Protocol rows (ISO 14229-1 Annex J)"))

    return "\n".join(lines)


def _render_html_dids(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Data Identifiers (DIDs)</h1>")
    dids = ctx.get("dids", [])
    if not dids:
        lines.append("<p>No DIDs are configured for this ECU.</p>")
        return "\n".join(lines)

    lines.append(
        "<p>DIDs are read via SID&nbsp;0x22 (ReadDataByIdentifier) and written via "
        "SID&nbsp;0x2E (WriteDataByIdentifier). Each DID contains one or more data "
        "elements with defined byte positions and data types.</p>"
    )

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # Overview table
    headers = ["DID", "Name", "Read", "Write", "Length (B)"] + sess_names
    rows = []
    for did in dids:
        r = '<span class="badge-yes">o</span>' if did.read_access else '<span class="badge-no">x</span>'
        w = '<span class="badge-yes">o</span>' if did.write_access else '<span class="badge-no">x</span>'
        sess_cells = [
            '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
            else '<span class="badge-no">x</span>'
            for s in sessions
        ]
        rows.append([
            _html_hex(did.did_id_hex), _html_escape(did.short_name), r, w,
            str(did.total_byte_length) if did.total_byte_length else "&mdash;"
        ] + sess_cells)
    lines.append("<h2>DID Overview</h2>")
    lines.append(_html_table(headers, rows, caption="Configured Data Identifiers"))

    # Per-DID details
    lines.append("<h2>DID Details</h2>")
    for did in dids:
        did_clean = did.did_id_hex.replace("0x", "").upper()
        lines.append(
            f'<h3 id="did-{did_clean}">'
            f'{_html_hex(did.did_id_hex)} &mdash; {_html_escape(did.short_name)}</h3>'
        )
        if did.description:
            lines.append(f'<p class="meta">{_html_escape(did.description)}</p>')

        props = []
        if did.supported_sessions:
            props.append("<strong>Sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in did.supported_sessions))
        if did.required_security_levels:
            props.append("<strong>Security:</strong> "
                         + ", ".join(_html_escape(s) for s in did.required_security_levels))
        access_parts = []
        if did.read_access:
            access_parts.append("Read (0x22)")
        if did.write_access:
            access_parts.append("Write (0x2E)")
        if access_parts:
            props.append("<strong>Access:</strong> " + ", ".join(access_parts))
        if did.total_byte_length:
            props.append(f"<strong>Total length:</strong> {did.total_byte_length}&nbsp;bytes")
        if props:
            lines.append("<p>" + " &emsp; ".join(props) + "</p>")

        if did.data_elements:
            de_rows = []
            for de in did.data_elements:
                de_rows.append([
                    _html_escape(de.short_name),
                    str(de.byte_position),
                    str(de.bit_size),
                    _html_escape(de.data_type or "&mdash;"),
                    _html_escape(de.unit or "&mdash;"),
                    _html_escape(de.description) if de.description else "&mdash;",
                ])
            lines.append(_html_table(
                ["Name", "Byte Pos", "Bits", "Type", "Unit", "Description"],
                de_rows, caption=f"Data elements of {_html_escape(did.short_name)}"))

            has_impl = any(
                de.read_function or de.write_function or de.global_variables
                for de in did.data_elements
            )
            if has_impl:
                impl_rows = []
                for de in did.data_elements:
                    impl_rows.append([
                        _html_escape(de.short_name),
                        _html_escape(de.read_function) if de.read_function else "&mdash;",
                        _html_escape(de.write_function) if de.write_function else "&mdash;",
                        _html_escape(", ".join(de.global_variables)) if de.global_variables else "&mdash;",
                    ])
                lines.append(_html_table(
                    ["Data Element", "Read Function", "Write Function", "Referenced Variables"],
                    impl_rows, caption=f"C implementation &mdash; {_html_escape(did.short_name)}"))

    return "\n".join(lines)


def _render_html_routines(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Routines (RIDs)</h1>")
    routines = ctx.get("routines", [])
    if not routines:
        lines.append("<p>No routines are configured for this ECU.</p>")
        return "\n".join(lines)

    lines.append(
        "<p>Routines are controlled via SID&nbsp;0x31 (RoutineControl) with "
        "sub-functions Start&nbsp;(0x01), Stop&nbsp;(0x02), and "
        "RequestResults&nbsp;(0x03).</p>"
    )

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # Overview table
    headers = ["RID", "Name", "Start", "Stop", "Result"] + sess_names
    rows = []
    for rt in routines:
        start  = '<span class="badge-yes">o</span>' if rt.start_supported  else '<span class="badge-no">x</span>'
        stop   = '<span class="badge-yes">o</span>' if rt.stop_supported   else '<span class="badge-no">x</span>'
        result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
        sess_cells = [
            '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
            else '<span class="badge-no">x</span>'
            for s in sessions
        ]
        rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                     start, stop, result] + sess_cells)
    lines.append("<h2>Routine Overview</h2>")
    lines.append(_html_table(headers, rows, caption="Configured routines"))

    # Per-routine details
    lines.append("<h2>Routine Details</h2>")
    for rt in routines:
        rid_clean = rt.routine_id_hex.replace("0x", "").upper()
        lines.append(
            f'<h3 id="rid-{rid_clean}">'
            f'{_html_hex(rt.routine_id_hex)} &mdash; {_html_escape(rt.short_name)}</h3>'
        )
        if rt.description:
            lines.append(f'<p class="meta">{_html_escape(rt.description)}</p>')

        ops = []
        if rt.start_supported:  ops.append("Start (0x01)")
        if rt.stop_supported:   ops.append("Stop (0x02)")
        if rt.result_supported: ops.append("RequestResults (0x03)")
        props = []
        if ops:
            props.append("<strong>Operations:</strong> " + ", ".join(ops))
        if rt.supported_sessions:
            props.append("<strong>Sessions:</strong> "
                         + ", ".join(_html_escape(s) for s in rt.supported_sessions))
        if rt.required_security_levels:
            props.append("<strong>Security:</strong> "
                         + ", ".join(_html_escape(s) for s in rt.required_security_levels))
        if props:
            lines.append("<p>" + " &emsp; ".join(props) + "</p>")

        if rt.in_parameters:
            param_rows = [
                [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                 _html_escape(p.data_type or "&mdash;"), _html_escape(p.description) if p.description else "&mdash;"]
                for p in rt.in_parameters
            ]
            lines.append("<h4>Input Parameters</h4>")
            lines.append(_html_table(
                ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))

        if rt.out_parameters:
            param_rows = [
                [_html_escape(p.short_name), str(p.byte_position), str(p.bit_size),
                 _html_escape(p.data_type or "&mdash;"), _html_escape(p.description) if p.description else "&mdash;"]
                for p in rt.out_parameters
            ]
            lines.append("<h4>Output Parameters</h4>")
            lines.append(_html_table(
                ["Name", "Byte Pos", "Bits", "Type", "Description"], param_rows))

        has_impl = (rt.start_function or rt.stop_function or rt.result_function
                    or rt.global_variables)
        if has_impl:
            impl_parts = []
            if rt.start_function:
                impl_parts.append(f"start: <code>{_html_escape(rt.start_function)}</code>")
            if rt.stop_function:
                impl_parts.append(f"stop: <code>{_html_escape(rt.stop_function)}</code>")
            if rt.result_function:
                impl_parts.append(f"result: <code>{_html_escape(rt.result_function)}</code>")
            lines.append("<h4>C Implementation</h4>")
            if impl_parts:
                lines.append("<p><strong>Functions:</strong> " + "; ".join(impl_parts) + "</p>")
            if rt.global_variables:
                lines.append(
                    "<p><strong>Referenced variables:</strong> "
                    + ", ".join(f"<code>{_html_escape(v)}</code>" for v in rt.global_variables)
                    + "</p>"
                )

    return "\n".join(lines)


def _render_html_annex(ctx: dict) -> str:
    lines: list[str] = []
    lines.append("<h1>Annex</h1>")

    sessions = ctx.get("sessions", [])
    sess_names = [s.short_name for s in sessions]

    # SID table
    services = ctx.get("services", [])
    if services:
        headers = ["SID", "Description", "Sub-function"] + sess_names
        rows = []
        for svc in services:
            sid_h = _html_hex(svc.service_id_hex)
            if svc.sub_functions:
                for i, sf in enumerate(svc.sub_functions):
                    sid_cell = sid_h if i == 0 else ""
                    desc_cell = _html_escape(svc.short_name) if i == 0 else ""
                    sf_cell = f"{_html_hex(sf.sub_function_id_hex)}: {_html_escape(sf.short_name)}"
                    sess_cells = [
                        '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                        else '<span class="badge-no">x</span>'
                        for s in sessions
                    ]
                    rows.append([sid_cell, desc_cell, sf_cell] + sess_cells)
            else:
                sess_cells = [
                    '<span class="badge-yes">o</span>' if s.short_name in svc.supported_sessions
                    else '<span class="badge-no">x</span>'
                    for s in sessions
                ]
                rows.append([sid_h, _html_escape(svc.short_name), "n/a"] + sess_cells)
        lines.append("<h2>Supported SID &amp; Subfunction List</h2>")
        lines.append(_html_table(headers, rows))

    # DID table
    dids = ctx.get("dids", [])
    if dids:
        headers = ["DID", "Description", "Read (0x22)", "Write (0x2E)"] + sess_names
        rows = []
        for did in dids:
            r = '<span class="badge-yes">Yes</span>' if did.read_access else '<span class="badge-no">No</span>'
            w = '<span class="badge-yes">Yes</span>' if did.write_access else '<span class="badge-no">No</span>'
            sess_cells = [
                '<span class="badge-yes">o</span>' if s.short_name in did.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(did.did_id_hex), _html_escape(did.short_name), r, w] + sess_cells)
        lines.append("<h2>Supported DID List</h2>")
        lines.append(_html_table(headers, rows))

    # RID table
    routines = ctx.get("routines", [])
    if routines:
        headers = ["RID", "Description", "Start", "Stop", "Result"] + sess_names
        rows = []
        for rt in routines:
            start = '<span class="badge-yes">o</span>' if rt.start_supported else '<span class="badge-no">x</span>'
            stop = '<span class="badge-yes">o</span>' if rt.stop_supported else '<span class="badge-no">x</span>'
            result = '<span class="badge-yes">o</span>' if rt.result_supported else '<span class="badge-no">x</span>'
            sess_cells = [
                '<span class="badge-yes">o</span>' if s.short_name in rt.supported_sessions
                else '<span class="badge-no">x</span>'
                for s in sessions
            ]
            rows.append([_html_hex(rt.routine_id_hex), _html_escape(rt.short_name),
                         start, stop, result] + sess_cells)
        lines.append("<h2>Supported RID List</h2>")
        lines.append(_html_table(headers, rows))

    # NRC table
    if services:
        all_nrcs: dict[int, str] = {}
        for svc in services:
            for nrc in svc.nrc_list:
                if nrc.nrc_code not in all_nrcs:
                    all_nrcs[nrc.nrc_code] = nrc.nrc_name
        if all_nrcs:
            headers = ["NRC", "Description"] + [_html_hex(s.service_id_hex) for s in services]
            rows = []
            for code in sorted(all_nrcs):
                # Reconstruct the hex representation
                code_hex = f"0x{code:02X}"
                row = [_html_hex(code_hex), _html_escape(all_nrcs[code])]
                for svc in services:
                    found = any(n.nrc_code == code for n in svc.nrc_list)
                    row.append(
                        '<span class="badge-yes">o</span>' if found
                        else '<span class="badge-no">x</span>'
                    )
                rows.append(row)
            lines.append("<h2>Supported NRC List</h2>")
            lines.append(_html_table(headers, rows))

    return "\n".join(lines)
