"""Requirements Traceability Matrix (RTM) support.

Implements the ASPICE SYS.2.BP4 / SWE.1.BP6 and ISO 26262-8 §6.4.5
"bidirectional traceability" concept for udsxml2tex: a DOORS-style
CSV table where each row maps a requirement onto one or more
implementation elements of the parsed ARXML (UDS service, DID, RID,
DTC, session, security level). At generation time the matrix is
joined with the spec and rendered as a dedicated chapter in the
LaTeX/PDF / HTML / Markdown output.

CSV columns (header row required, case-insensitive):

    req_id        — mandatory; unique requirement identifier
    description   — mandatory; requirement text
    source_ref    — mandatory; bibkey from rtm_sources.yaml (or
                    a free-text reference if no sources YAML is
                    provided)
    traces_to     — mandatory; semicolon-separated implementation
                    references, each in one of these forms:
                        sid:0x10            (service)
                        sid:0x10:0x03       (service + sub-function)
                        did:0xF187          (data identifier)
                        rid:0x0203          (routine identifier)
                        dtc:0x010000        (diagnostic trouble code)
                        session:0x03        (diagnostic session)
                        security:0x01       (security level)
    verified_by   — optional; test-case ID or document section
    status        — optional; one of "verified" / "in_progress" /
                    "not_yet" / "na" (default: "not_yet")

Sources YAML schema (list of dicts):

    - bibkey:    iso14229-1
      title:     ISO 14229-1:2020 ...
      publisher: ISO
      year:      2020
"""

from __future__ import annotations

import csv
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional


@dataclass(frozen=True)
class RtmTrace:
    """One implementation-element reference parsed from `traces_to`."""

    kind: str  # one of: sid, did, rid, dtc, session, security
    primary: str  # hex string e.g. "0x10", "0xF187"
    secondary: Optional[str] = None  # sub-function hex when kind=="sid"

    def __str__(self) -> str:
        if self.secondary:
            return f"{self.kind}:{self.primary}:{self.secondary}"
        return f"{self.kind}:{self.primary}"


@dataclass
class RtmEntry:
    """One row of a requirements traceability matrix."""

    req_id: str
    description: str
    source_ref: str
    traces_to: list[RtmTrace]
    verified_by: str = ""
    status: str = "not_yet"
    # Set during match_to_spec() if any trace resolves to a real spec item.
    resolved: bool = False
    # Free-text origin of this row (e.g. file basename) for diagnostics.
    origin: str = ""


@dataclass
class RtmSource:
    """One entry from rtm_sources.yaml — a citable source."""

    bibkey: str
    title: str
    publisher: str = ""
    year: str = ""


@dataclass
class RtmDocument:
    """The full requirements-traceability dataset for a generation run."""

    entries: list[RtmEntry] = field(default_factory=list)
    sources: list[RtmSource] = field(default_factory=list)

    def coverage_pct(self) -> float:
        if not self.entries:
            return 0.0
        return 100.0 * sum(e.resolved for e in self.entries) / len(self.entries)

    def source_by_key(self, bibkey: str) -> Optional[RtmSource]:
        for s in self.sources:
            if s.bibkey == bibkey:
                return s
        return None


_TRACE_RE = re.compile(
    r"^(?P<kind>sid|did|rid|dtc|session|security)"
    r":(?P<primary>0[xX][0-9a-fA-F]+|\d+)"
    r"(?::(?P<secondary>0[xX][0-9a-fA-F]+|\d+))?$"
)


def _parse_traces(value: str) -> list[RtmTrace]:
    out: list[RtmTrace] = []
    for raw in value.split(";"):
        token = raw.strip()
        if not token:
            continue
        m = _TRACE_RE.match(token)
        if m is None:
            raise ValueError(
                f"Invalid traces_to token {token!r} — expected forms like "
                "sid:0x10, sid:0x10:0x03, did:0xF187, rid:0x0203, "
                "dtc:0x010000, session:0x03, security:0x01"
            )
        primary = m.group("primary")
        if not primary.lower().startswith("0x"):
            primary = f"0x{int(primary):X}"
        else:
            primary = "0x" + primary[2:].upper()
        secondary = m.group("secondary")
        if secondary is not None:
            if not secondary.lower().startswith("0x"):
                secondary = f"0x{int(secondary):X}"
            else:
                secondary = "0x" + secondary[2:].upper()
        out.append(RtmTrace(kind=m.group("kind"), primary=primary, secondary=secondary))
    return out


def load_rtm_csv(path: Path) -> list[RtmEntry]:
    """Parse one RTM CSV file. Header row required."""
    path = Path(path)
    entries: list[RtmEntry] = []
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            return entries
        headers_lc = {h.lower().strip(): h for h in reader.fieldnames}
        for need in ("req_id", "description", "source_ref", "traces_to"):
            if need not in headers_lc:
                raise ValueError(
                    f"RTM CSV {path.name}: missing required column {need!r}. "
                    f"Headers seen: {reader.fieldnames}"
                )
        for row_no, row in enumerate(reader, start=2):
            req_id = (row.get(headers_lc["req_id"]) or "").strip()
            if not req_id:
                continue
            description = (row.get(headers_lc["description"]) or "").strip()
            source_ref = (row.get(headers_lc["source_ref"]) or "").strip()
            traces_raw = (row.get(headers_lc["traces_to"]) or "").strip()
            try:
                traces = _parse_traces(traces_raw)
            except ValueError as exc:
                raise ValueError(f"{path.name}:{row_no}: {exc}") from None
            verified_by = (row.get(headers_lc.get("verified_by", "")) or "").strip()
            status = (
                row.get(headers_lc.get("status", "")) or "not_yet"
            ).strip() or "not_yet"
            entries.append(
                RtmEntry(
                    req_id=req_id,
                    description=description,
                    source_ref=source_ref,
                    traces_to=traces,
                    verified_by=verified_by,
                    status=status.lower(),
                    origin=path.name,
                )
            )
    return entries


def load_rtm_csvs(paths: Iterable[Path]) -> list[RtmEntry]:
    out: list[RtmEntry] = []
    for p in paths:
        out.extend(load_rtm_csv(Path(p)))
    return out


def load_rtm_sources(path: Path) -> list[RtmSource]:
    """Parse rtm_sources.yaml. Requires PyYAML."""
    import yaml  # type: ignore[import-untyped]

    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError(
            f"RTM sources file {Path(path).name}: top-level must be a list of "
            "dicts (got {type(raw).__name__})"
        )
    out: list[RtmSource] = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict) or "bibkey" not in item:
            raise ValueError(
                f"RTM sources file {Path(path).name}: entry #{i} missing "
                "'bibkey' field"
            )
        out.append(
            RtmSource(
                bibkey=str(item["bibkey"]).strip(),
                title=str(item.get("title", "")).strip(),
                publisher=str(item.get("publisher", "")).strip(),
                year=str(item.get("year", "")).strip(),
            )
        )
    return out


def match_to_spec(doc: RtmDocument, spec: object) -> RtmDocument:
    """Mark each entry's `resolved` flag based on whether at least one
    of its traces points at a real item in the parsed UdsSpecification.

    The spec is duck-typed so this works for both `UdsSpecification`
    instances and any object that exposes attribute access to the
    relevant collections; missing attributes are treated as empty.
    """

    def _hex_int(v: str) -> Optional[int]:
        try:
            return int(v, 16) if v.lower().startswith("0x") else int(v)
        except (ValueError, AttributeError):
            return None

    sids = {
        _hex_int(getattr(s, "service_id_hex", "") or "")
        for s in getattr(spec, "services", []) or []
    }
    dids = {
        _hex_int(getattr(d, "did_id_hex", "") or "")
        for d in getattr(spec, "dids", []) or []
    }
    rids = {
        _hex_int(getattr(r, "routine_id_hex", "") or "")
        for r in getattr(spec, "routines", []) or []
    }
    dtcs = {
        _hex_int(getattr(dt, "dtc_id_hex", "") or "")
        for dt in getattr(spec, "dtcs", []) or []
    }
    sessions = {
        _hex_int(getattr(s, "session_id_hex", "") or "")
        for s in getattr(spec, "sessions", []) or []
    }
    sec_levels = {
        _hex_int(getattr(s, "security_level_hex", "") or "")
        for s in getattr(spec, "security_levels", []) or []
    }

    table = {
        "sid": sids,
        "did": dids,
        "rid": rids,
        "dtc": dtcs,
        "session": sessions,
        "security": sec_levels,
    }

    for entry in doc.entries:
        resolved = False
        for tr in entry.traces_to:
            primary_int = _hex_int(tr.primary)
            if primary_int is not None and primary_int in table.get(tr.kind, set()):
                resolved = True
                break
        entry.resolved = resolved
    return doc


def load_rtm_document(
    csv_paths: Iterable[Path],
    sources_path: Optional[Path] = None,
) -> RtmDocument:
    """Convenience: load CSVs + sources into a single RtmDocument."""
    doc = RtmDocument(entries=load_rtm_csvs(csv_paths))
    if sources_path is not None:
        doc.sources = load_rtm_sources(Path(sources_path))
    return doc


__all__ = [
    "RtmTrace",
    "RtmEntry",
    "RtmSource",
    "RtmDocument",
    "load_rtm_csv",
    "load_rtm_csvs",
    "load_rtm_sources",
    "load_rtm_document",
    "match_to_spec",
]
