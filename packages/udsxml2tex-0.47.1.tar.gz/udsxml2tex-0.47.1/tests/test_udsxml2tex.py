"""Tests for udsxml2tex."""

from pathlib import Path

import pytest

from udsxml2tex import ArxmlParser, CanTpParser, TexGenerator

FIXTURES_DIR = Path(__file__).parent / "fixtures"
SAMPLE_ARXML = FIXTURES_DIR / "sample_dcm.arxml"
SAMPLE_CANTP = FIXTURES_DIR / "sample_cantp.arxml"
SAMPLE_DEM = FIXTURES_DIR / "sample_dem.arxml"


class TestArxmlParser:
    """Tests for the ARXML parser."""

    def test_parse_file_not_found(self):
        parser = ArxmlParser()
        with pytest.raises(FileNotFoundError):
            parser.parse("/nonexistent/file.arxml")

    def test_parse_sample(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec is not None
        assert len(spec.sessions) > 0
        assert len(spec.security_levels) > 0
        assert len(spec.services) > 0
        assert len(spec.dids) > 0
        assert len(spec.routines) > 0

    def test_sessions_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        session_names = [s.short_name for s in spec.sessions]
        assert "DefaultSession" in session_names
        assert "ProgrammingSession" in session_names
        assert "ExtendedSession" in session_names

        default = next(s for s in spec.sessions if s.short_name == "DefaultSession")
        assert default.session_id == 1
        assert default.session_id_hex == "0x01"

    def test_s3_server_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.s3_server == 5.0

    def test_security_levels_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.security_levels) == 2
        level_names = [s.short_name for s in spec.security_levels]
        assert "SecurityLevel_1" in level_names
        assert "SecurityLevel_2" in level_names

        sec1 = next(
            s for s in spec.security_levels if s.short_name == "SecurityLevel_1"
        )
        assert sec1.security_level == 1
        assert sec1.num_max_attempts == 3

    def test_services_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        service_ids = [s.service_id for s in spec.services]
        assert 0x10 in service_ids  # DiagnosticSessionControl
        assert 0x11 in service_ids  # ECUReset
        assert 0x14 in service_ids  # ClearDiagnosticInformation
        assert 0x19 in service_ids  # ReadDTCInformation
        assert 0x22 in service_ids  # ReadDataByIdentifier
        assert 0x27 in service_ids  # SecurityAccess
        assert 0x28 in service_ids  # CommunicationControl
        assert 0x29 in service_ids  # Authentication
        assert 0x2E in service_ids  # WriteDataByIdentifier
        assert 0x31 in service_ids  # RoutineControl
        assert 0x34 in service_ids  # RequestDownload
        assert 0x36 in service_ids  # TransferData
        assert 0x37 in service_ids  # RequestTransferExit
        assert 0x3E in service_ids  # TesterPresent
        assert 0x85 in service_ids  # ControlDTCSetting

    def test_service_names_mapped(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        session_ctrl = next(s for s in spec.services if s.service_id == 0x10)
        assert session_ctrl.short_name == "DiagnosticSessionControl"
        assert session_ctrl.positive_response_id == 0x50
        assert session_ctrl.positive_response_id_hex == "0x50"

    def test_service_sessions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        tester_present = next(s for s in spec.services if s.service_id == 0x3E)
        assert "DefaultSession" in tester_present.supported_sessions
        assert "ExtendedSession" in tester_present.supported_sessions

    def test_dids_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.dids) == 3

        vin_did = next(d for d in spec.dids if d.did_id == 0xF190)
        assert vin_did.short_name == "DID_F190_VIN"
        assert vin_did.did_id_hex == "0xF190"
        assert vin_did.read_access is True
        assert "DefaultSession" in vin_did.supported_sessions

        # Check data elements
        assert len(vin_did.data_elements) > 0

    def test_did_write_access(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        app_ver = next(d for d in spec.dids if d.did_id == 0xF101)
        assert app_ver.read_access is True
        assert app_ver.write_access is True

    def test_routines_parsed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.routines) == 4
        # Verify the first routine (EraseMemory)
        routine = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert routine.routine_id_hex == "0x0203"
        assert routine.start_supported is True
        assert routine.result_supported is True
        assert "ExtendedSession" in routine.supported_sessions
        assert "SecurityLevel_1" in routine.required_security_levels

        # Verify no duplicate sessions/security from overlapping XPath
        assert routine.supported_sessions == ["ExtendedSession"]
        assert routine.required_security_levels == ["SecurityLevel_1"]

        # Verify other routines exist
        rids = sorted(r.routine_id for r in spec.routines)
        assert rids == [0x0203, 0x0302, 0xF000, 0xFF00]

        # SelfTest has start+stop+result
        self_test = next(r for r in spec.routines if r.routine_id == 0xF000)
        assert self_test.start_supported is True
        assert self_test.stop_supported is True
        assert self_test.result_supported is True

        # CheckProgrammingPreconditions has no security
        precond = next(r for r in spec.routines if r.routine_id == 0x0302)
        assert precond.required_security_levels == []

    def test_nrc_list(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        security_svc = next(s for s in spec.services if s.service_id == 0x27)
        nrc_codes = [n.nrc_code for n in security_svc.nrc_list]
        # SecurityAccess should have specific NRCs
        assert 0x33 in nrc_codes  # securityAccessDenied
        assert 0x35 in nrc_codes  # invalidKey
        assert 0x36 in nrc_codes  # exceededNumberOfAttempts

    def test_sub_functions_parsed_from_arxml(self):
        """Sub-functions defined as DcmDsdSubService in ARXML are parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # DiagnosticSessionControl has 3 explicit sub-functions in fixture
        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert len(dsc.sub_functions) == 3
        sf_ids = [sf.sub_function_id for sf in dsc.sub_functions]
        assert sf_ids == [0x01, 0x02, 0x03]
        assert dsc.sub_functions[0].short_name == "defaultSession"
        # Check session refs parsed for sub-function
        assert "DefaultSession" in dsc.sub_functions[0].supported_sessions

    def test_sub_functions_parsed_from_arxml_ecureset(self):
        """ECUReset has 2 explicit sub-functions (hardReset, softReset)."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        ecureset = next(s for s in spec.services if s.service_id == 0x11)
        assert len(ecureset.sub_functions) == 2
        sf_names = [sf.short_name for sf in ecureset.sub_functions]
        assert "hardReset" in sf_names
        assert "softReset" in sf_names

    def test_sub_functions_standard_fallback(self):
        """Services with SubfuncAvail=true but no ARXML sub-services
        get ISO 14229-1 standard sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # TesterPresent has SubfuncAvail=true but no DcmDsdSubService
        tp = next(s for s in spec.services if s.service_id == 0x3E)
        assert len(tp.sub_functions) >= 1
        assert tp.sub_functions[0].short_name == "zeroSubFunction"
        assert tp.sub_functions[0].sub_function_id == 0x00

    def test_sub_functions_none_when_not_available(self):
        """Services with SubfuncAvail=false have no sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # RequestDownload has SubfuncAvail=false
        rd = next(s for s in spec.services if s.service_id == 0x34)
        assert len(rd.sub_functions) == 0

    def test_communication_control_parsed(self):
        """SID 0x28 CommunicationControl is parsed with sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        cc = next(s for s in spec.services if s.service_id == 0x28)
        assert cc.short_name == "CommunicationControl"
        assert cc.positive_response_id == 0x68
        assert cc.positive_response_id_hex == "0x68"
        assert "ExtendedSession" in cc.supported_sessions
        # 4 sub-functions defined in ARXML
        assert len(cc.sub_functions) == 4
        sf_ids = [sf.sub_function_id for sf in cc.sub_functions]
        assert sf_ids == [0x00, 0x01, 0x02, 0x03]
        assert cc.sub_functions[0].short_name == "enableRxAndTx"
        assert cc.sub_functions[3].short_name == "disableRxAndTx"

    def test_control_dtc_setting_parsed(self):
        """SID 0x85 ControlDTCSetting is parsed with sub-functions."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dtc = next(s for s in spec.services if s.service_id == 0x85)
        assert dtc.short_name == "ControlDTCSetting"
        assert dtc.positive_response_id == 0xC5
        assert dtc.positive_response_id_hex == "0xC5"
        assert "ExtendedSession" in dtc.supported_sessions
        # 2 sub-functions defined in ARXML
        assert len(dtc.sub_functions) == 2
        sf_ids = [sf.sub_function_id for sf in dtc.sub_functions]
        assert sf_ids == [0x01, 0x02]
        assert dtc.sub_functions[0].short_name == "on"
        assert dtc.sub_functions[1].short_name == "off"

    def test_communication_control_nrcs(self):
        """SID 0x28 should have requestOutOfRange NRC."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        cc = next(s for s in spec.services if s.service_id == 0x28)
        nrc_codes = [n.nrc_code for n in cc.nrc_list]
        assert 0x12 in nrc_codes  # subFunctionNotSupported
        assert 0x31 in nrc_codes  # requestOutOfRange
        assert 0x22 in nrc_codes  # conditionsNotCorrect

    def test_control_dtc_setting_nrcs(self):
        """SID 0x85 should have requestOutOfRange NRC."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dtc = next(s for s in spec.services if s.service_id == 0x85)
        nrc_codes = [n.nrc_code for n in dtc.nrc_list]
        assert 0x12 in nrc_codes  # subFunctionNotSupported
        assert 0x31 in nrc_codes  # requestOutOfRange
        assert 0x22 in nrc_codes  # conditionsNotCorrect

    def test_did_description_parsed(self):
        """DID descriptions should be extracted from DESC/L-2."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        vin = next(d for d in spec.dids if d.did_id == 0xF190)
        assert vin.description == "Vehicle Identification Number"

    def test_did_data_element_data_type(self):
        """DataElement data_type should be parsed from DcmDspDidDataType."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        vin = next(d for d in spec.dids if d.did_id == 0xF190)
        assert len(vin.data_elements) > 0
        assert vin.data_elements[0].data_type == "uint8_n"

    def test_did_data_function_ar44_convention_fallback(self, tmp_path):
        """AR4.4 fallback: when DcmDspDataReadFnc / DcmDspDataWriteFnc are not
        explicitly configured, DataElement.read_function /
        DataElement.write_function must be populated with the implied names
        Dcm_Read<DcmDspData.SHORT-NAME> / Dcm_Write<DcmDspData.SHORT-NAME>,
        even when the DcmDspData container uses a project-specific SHORT-NAME
        (matched via DEFINITION-REF tail)."""
        arxml = tmp_path / "ar44.arxml"
        arxml.write_text(
            """<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <AR-PACKAGES><AR-PACKAGE><SHORT-NAME>Pkg</SHORT-NAME><ELEMENTS>
    <ECUC-MODULE-CONFIGURATION-VALUES>
      <SHORT-NAME>Dcm</SHORT-NAME>
      <CONTAINERS>
        <ECUC-CONTAINER-VALUE>
          <SHORT-NAME>DcmDsp</SHORT-NAME>
          <SUB-CONTAINERS>
            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>Data_ActiveSession</SHORT-NAME>
              <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspData</DEFINITION-REF>
            </ECUC-CONTAINER-VALUE>
            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>Data_CalibrationOffset</SHORT-NAME>
              <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspData</DEFINITION-REF>
            </ECUC-CONTAINER-VALUE>
            <ECUC-CONTAINER-VALUE>
              <SHORT-NAME>DcmDspDid_F100</SHORT-NAME>
              <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspDid</DEFINITION-REF>
              <PARAMETER-VALUES>
                <ECUC-NUMERICAL-PARAM-VALUE>
                  <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidIdentifier</DEFINITION-REF>
                  <VALUE>61696</VALUE>
                </ECUC-NUMERICAL-PARAM-VALUE>
              </PARAMETER-VALUES>
              <REFERENCE-VALUES>
                <ECUC-REFERENCE-VALUE>
                  <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidRead</DEFINITION-REF>
                  <VALUE-REF>/Pkg/Dcm/DcmDspDidRead</VALUE-REF>
                </ECUC-REFERENCE-VALUE>
                <ECUC-REFERENCE-VALUE>
                  <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidWrite</DEFINITION-REF>
                  <VALUE-REF>/Pkg/Dcm/DcmDspDidWrite</VALUE-REF>
                </ECUC-REFERENCE-VALUE>
              </REFERENCE-VALUES>
              <SUB-CONTAINERS>
                <ECUC-CONTAINER-VALUE>
                  <SHORT-NAME>DcmDspDidSignal_ActiveSession</SHORT-NAME>
                  <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidSignal</DEFINITION-REF>
                  <REFERENCE-VALUES>
                    <ECUC-REFERENCE-VALUE>
                      <DEFINITION-REF>/AUTOSAR/Dcm/DcmDsp/DcmDspDid/DcmDspDidSignal/DcmDspDidDataRef</DEFINITION-REF>
                      <VALUE-REF>/Pkg/Dcm/DcmDsp/Data_ActiveSession</VALUE-REF>
                    </ECUC-REFERENCE-VALUE>
                  </REFERENCE-VALUES>
                </ECUC-CONTAINER-VALUE>
              </SUB-CONTAINERS>
            </ECUC-CONTAINER-VALUE>
          </SUB-CONTAINERS>
        </ECUC-CONTAINER-VALUE>
      </CONTAINERS>
    </ECUC-MODULE-CONFIGURATION-VALUES>
  </ELEMENTS></AR-PACKAGE></AR-PACKAGES>
</AUTOSAR>
""",
            encoding="utf-8",
        )
        parser = ArxmlParser()
        spec = parser.parse(arxml)
        did = next(d for d in spec.dids if d.did_id == 0xF100)
        assert did.data_elements
        de = did.data_elements[0]
        assert de.read_function == "Dcm_ReadData_ActiveSession"
        assert de.write_function == "Dcm_WriteData_ActiveSession"

    def test_security_extended_fields(self):
        """Security levels should parse delay, key_size, seed_size."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        sec1 = next(s for s in spec.security_levels if s.security_level == 1)
        assert sec1.attempt_delay == 10.0
        assert sec1.key_size == 4
        assert sec1.seed_size == 4

    def test_protocol_type_parsed(self):
        """DcmDslProtocolType should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.protocol_type == "UDS_ON_CAN"

    def test_dsl_buffer_sizes(self):
        """DSL buffer sizes should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.dsl_rx_buffer_size == 4095
        assert spec.dsl_tx_buffer_size == 4095

    def test_routine_description_parsed(self):
        """Routine descriptions should be extracted from DESC/L-2."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        erase = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert erase.description == "Erases a memory block"

    def test_routine_parameters_parsed(self):
        """Routine in/out parameters from DcmDspRoutineInSignal/OutSignal."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        erase = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert len(erase.in_parameters) == 2
        assert erase.in_parameters[0].short_name == "DcmDspRoutineInSignal_Address"
        assert erase.in_parameters[0].bit_size == 32
        assert erase.in_parameters[0].data_type == "uint32"
        assert erase.in_parameters[1].byte_position == 4

        assert len(erase.out_parameters) == 1
        assert erase.out_parameters[0].short_name == "DcmDspRoutineOutSignal_Status"
        assert erase.out_parameters[0].bit_size == 8

    def test_dtcs_parsed(self):
        """DTC definitions should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.dtcs) == 2
        bus_off = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert bus_off.dtc_id == 0xC07300
        assert bus_off.severity == "HIGH"
        assert bus_off.functional_unit == "Communication"
        assert bus_off.description == "CAN bus off detected"

    def test_memory_ranges_parsed(self):
        """Memory ranges should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.memory_ranges) == 1
        mr = spec.memory_ranges[0]
        assert mr.short_name == "ReadRange_Calibration"
        assert mr.start_address == 0x80000000
        assert mr.end_address == 0x8000FFFF
        assert mr.read_access is True
        assert "ExtendedSession" in mr.supported_sessions

    def test_periodic_dids_parsed(self):
        """Periodic DIDs should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.periodic_dids) == 1
        pdid = spec.periodic_dids[0]
        assert pdid.short_name == "PeriodicDID_F200"
        assert pdid.did_id == 0xF200
        assert pdid.transmission_mode == "slowRate"
        assert "ExtendedSession" in pdid.supported_sessions

    def test_io_control_dids_parsed(self):
        """IO control DIDs should be parsed from DcmDspDidControl."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.io_control_dids) == 1
        io = spec.io_control_dids[0]
        assert io.short_name == "DID_D001_OutputControl"
        assert io.did_id == 0xD001
        assert io.control_mask_size == 8
        assert io.return_control_to_ecu is True
        assert io.short_term_adjustment is True

    def test_dtc_extended_data_records(self):
        """DTC extended data records should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        busoff = [d for d in spec.dtcs if d.short_name == "DTC_BusOff"][0]
        assert len(busoff.extended_data_records) == 1
        edr = busoff.extended_data_records[0]
        assert edr.record_number == 1
        assert edr.data_size == 4
        assert edr.short_name == "ExtendedDataRecord_01"

    def test_dtc_snapshot_records(self):
        """DTC snapshot records should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        busoff = [d for d in spec.dtcs if d.short_name == "DTC_BusOff"][0]
        assert len(busoff.snapshot_records) == 1
        snap = busoff.snapshot_records[0]
        assert snap.record_number == 1
        assert snap.short_name == "SnapshotRecord_01"
        assert 0xF190 in snap.dids

    def test_did_ranges_parsed(self):
        """DID ranges should be parsed from DcmDspDidRange."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.did_ranges) == 1
        dr = spec.did_ranges[0]
        assert dr.short_name == "DidRange_Supplier"
        assert dr.lower_did == 0xFD00
        assert dr.upper_did == 0xFDFF
        assert dr.read_access is True
        assert "ExtendedSession" in dr.supported_sessions

    def test_service_nrcs_from_arxml(self):
        """Service NRCs should be read from ARXML when defined."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        svc_22 = [s for s in spec.services if s.service_id == 0x22][0]
        nrc_codes = [n.nrc_code for n in svc_22.nrc_list]
        assert 0x13 in nrc_codes
        assert 0x31 in nrc_codes
        assert 0x33 in nrc_codes
        # Should only contain the 3 NRCs from ARXML, not defaults
        assert len(svc_22.nrc_list) == 3


class TestTexGenerator:
    """Tests for the LaTeX generator."""

    def test_generate_string(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert r"\documentclass" in tex
        assert r"\begin{document}" in tex
        assert r"\end{document}" in tex
        assert "UDS Specification" in tex

    def test_generate_contains_sessions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "DefaultSession" in tex
        assert "ProgrammingSession" in tex
        assert "ExtendedSession" in tex

    def test_generate_contains_services(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "{10}" in tex
        assert "DiagnosticSessionControl" in tex
        assert "{22}" in tex
        assert "ReadDataByIdentifier" in tex

    def test_generate_contains_dids(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "{F190}" in tex
        assert "DID\\_F190\\_VIN" in tex  # LaTeX escaped underscores

    def test_generate_file(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        output = tmp_path / "test_output.tex"
        result = gen.generate(spec, output)

        assert result == output
        assert output.exists()
        content = output.read_text()
        assert r"\documentclass" in content

    def test_ecu_name_override(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        spec.ecu_name = "TestECU"

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "TestECU" in tex

    def test_structured_tex_no_empty_itemize(self, tmp_path):
        """Structured-TeX output must not emit empty `itemize` environments
        when the spec has no services in a SID category. xelatex aborts
        with `! LaTeX Error: Something's wrong--perhaps a missing \\item`
        on empty itemize blocks under `-halt-on-error`.
        Regression for the user-reported "LaTeX compilation failed
        (exit 12)" on a spec without any Upload/Download services
        (0x34–0x37)."""
        import re
        import zipfile

        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        # Drop every upload-/download-style service so the
        # corresponding category in the structured-tex short
        # description has no items to enumerate.
        spec.services = [
            s for s in spec.services
            if s.service_id not in (0x34, 0x35, 0x36, 0x37)
        ]

        gen = TexGenerator()
        out_zip = tmp_path / "structured.zip"
        gen.generate_structured_tex_zip(spec, out_zip, lang="en")

        extract_dir = tmp_path / "extracted"
        extract_dir.mkdir()
        with zipfile.ZipFile(out_zip) as zf:
            zf.extractall(extract_dir)

        # No file in the structured tex tree may contain an
        # empty itemize environment.
        empty_itemize = re.compile(
            r"\\begin\{itemize\}\s*\\end\{itemize\}", re.MULTILINE
        )
        offenders: list[str] = []
        for tex_file in extract_dir.rglob("*.tex"):
            if empty_itemize.search(tex_file.read_text(encoding="utf-8")):
                offenders.append(str(tex_file.relative_to(extract_dir)))
        assert not offenders, (
            "Empty \\begin{itemize}\\end{itemize} found in: "
            + ", ".join(offenders)
        )

    def test_latex_escape(self):
        from udsxml2tex.generator import _latex_escape

        assert _latex_escape("a&b") == r"a\&b"
        assert _latex_escape("100%") == r"100\%"
        assert _latex_escape("a_b") == r"a\_b"
        assert _latex_escape("a#b") == r"a\#b"
        assert _latex_escape("") == ""

    def test_generate_contains_sub_functions(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        # Sub-function IDs should appear in the Service Overview table
        assert "Sub-Function" in tex  # column header
        assert r"\hexval{01}" in tex  # sub-function 0x01
        assert r"\hexval{03}" in tex  # sub-function 0x03
        # Services without sub-functions should show ---
        assert "---" in tex

    def test_generate_contains_message_formats(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        # Request / positive response format sections should be present
        assert "Request Message Format" in tex
        assert "Positive Response Message Format" in tex
        # SID bytes should appear in format tables (e.g. SID 0x10 -> \hexval{10})
        assert r"\hexval{10}" in tex  # DiagnosticSessionControl request SID
        assert r"\hexval{50}" in tex  # DiagnosticSessionControl response SID
        assert r"\hexval{22}" in tex  # ReadDataByIdentifier request SID
        assert r"\hexval{62}" in tex  # ReadDataByIdentifier response SID

    def test_generate_contains_communication_control(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "CommunicationControl" in tex
        assert r"\hexval{28}" in tex or "{28}" in tex
        assert "Request Message Format" in tex  # message format table for 0x28

    def test_generate_contains_control_dtc_setting(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "ControlDTCSetting" in tex
        assert r"\hexval{85}" in tex or "{85}" in tex
        assert r"\hexval{C5}" in tex  # positive response SID

    def test_generate_contains_supported_nrc_heading(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Supported Negative Response Codes" in tex

    def test_tex_contains_dsl_config(self):
        """Template should render DSL configuration section."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "UDS\\_ON\\_CAN" in tex or "UDS_ON_CAN" in tex
        assert "4095" in tex

    def test_tex_contains_dtc_section(self):
        """Template should render DTC table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Diagnostic Trouble Codes" in tex
        assert "DTC\\_BusOff" in tex or "DTC_BusOff" in tex

    def test_tex_contains_memory_ranges(self):
        """Template should render memory ranges table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Memory Access Ranges" in tex

    def test_tex_contains_periodic_dids(self):
        """Template should render periodic DIDs table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Periodic DIDs" in tex
        assert "slowRate" in tex

    def test_tex_contains_io_control_dids(self):
        """Template should render IO control DIDs table."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "IO Control DIDs" in tex

    def test_tex_contains_security_extended_fields(self):
        """Template should render extended security fields."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Seed (B)" in tex
        assert "Key (B)" in tex
        assert "Delay" in tex

    def test_tex_contains_routine_description(self):
        """Template should render routine description."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Erases a memory block" in tex

    def test_tex_contains_did_description(self):
        """Template should render DID description."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Vehicle Identification Number" in tex

    def test_tex_contains_dtc_extended_data(self):
        """Template should render DTC extended data records."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Extended Data Records" in tex
        assert "ExtendedDataRecord" in tex

    def test_tex_contains_dtc_snapshot(self):
        """Template should render DTC snapshot records."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Snapshot Records" in tex
        assert "SnapshotRecord" in tex

    def test_tex_contains_did_ranges(self):
        """Template should render DID Ranges section."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "DID Ranges" in tex
        assert "DidRange" in tex


class TestCli:
    """Tests for the CLI interface."""

    def test_cli_help(self):
        from udsxml2tex.cli import _build_parser

        parser = _build_parser()
        assert parser.prog == "udsxml2tex"

    def test_cli_main_success(self, tmp_path):
        from udsxml2tex.cli import main

        output = tmp_path / "output.tex"
        rc = main([str(SAMPLE_ARXML), "-o", str(output)])
        assert rc == 0
        assert output.exists()

    def test_cli_main_file_not_found(self):
        from udsxml2tex.cli import main

        rc = main(["/nonexistent/file.arxml"])
        assert rc == 1

    def test_cli_ecu_name(self, tmp_path):
        from udsxml2tex.cli import main

        output = tmp_path / "output.tex"
        rc = main([str(SAMPLE_ARXML), "-o", str(output), "--ecu-name", "MyECU"])
        assert rc == 0

        content = output.read_text()
        assert "MyECU" in content


class TestCanTpParser:
    """Tests for the CanTp ARXML parser."""

    def test_parse_file_not_found(self):
        parser = CanTpParser()
        with pytest.raises(FileNotFoundError):
            parser.parse("/nonexistent/file.arxml")

    def test_parse_sample(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config is not None
        assert len(config.channels) > 0

    def test_main_function_period(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config.main_function_period == 0.01

    def test_channel_count(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        # Physical channel (1 Rx+Tx pair) + Functional channel (1 Rx only)
        assert len(config.channels) == 2

    def test_physical_channel(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        # Find the physical channel (has CanTpRxNSdu_Phys in name)
        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.bs == 8
        assert phys.stmin == 10.0
        assert phys.n_ar == 1.0
        assert phys.n_br == 0.9
        assert phys.n_cr == 1.0
        assert phys.padding_byte == 0xAA
        assert phys.padding_activation is True
        assert phys.rx_addressing_format == "STANDARD"
        assert phys.max_data_length == 8
        assert phys.channel_mode == "FULL_DUPLEX"

    def test_physical_channel_tx(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.n_as == 1.0
        assert phys.n_bs == 1.0
        assert phys.n_cs == 0.5
        assert phys.tx_addressing_format == "STANDARD"
        assert phys.tx_pdu_id == "DiagPhysTxPdu"

    def test_functional_channel(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        func = next(
            (ch for ch in config.channels if "Func" in ch.short_name), None
        )
        assert func is not None
        assert func.bs == 0
        assert func.stmin == 0.0
        assert func.rx_addressing_format == "EXTENDED"
        assert func.max_data_length == 64
        assert func.channel_mode == "HALF_DUPLEX"
        assert func.padding_byte == 0xFF

    def test_rx_pdu_ref(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.rx_pdu_id == "DiagPhysRxPdu"

    def test_padding_byte_hex(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.padding_byte_hex == "0xAA"

    def test_rx_ta_type(self):
        """TA type should be parsed from CanTpRxTaType."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.rx_ta_type == "PHYSICAL"

    def test_tx_ta_type(self):
        """Tx TA type should be parsed from CanTpTxTaType."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.tx_ta_type == "PHYSICAL"

    def test_functional_ta_type(self):
        """Functional channel TA type."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        func = next(
            (ch for ch in config.channels if "Func" in ch.short_name), None
        )
        assert func is not None
        assert func.rx_ta_type == "FUNCTIONAL"


class TestCanTpIntegration:
    """Integration tests for CanTp with ArxmlParser and TexGenerator."""

    def test_arxml_parser_detects_cantp(self):
        """ArxmlParser should detect CanTp in a CanTp-only file."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_CANTP)

        assert spec.transport_config is not None
        assert len(spec.transport_config.channels) == 2

    def test_parse_multi_dcm_and_cantp(self):
        """parse_multi should merge DCM and CanTp from separate files."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        # DCM data present
        assert len(spec.sessions) > 0
        assert len(spec.services) > 0
        assert len(spec.dids) > 0

        # CanTp data merged
        assert spec.transport_config is not None
        assert len(spec.transport_config.channels) == 2

    def test_tex_with_cantp(self):
        """Generator should include transport layer section."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Transport Layer" in tex
        assert "FULL\\_DUPLEX" in tex or "FULL_DUPLEX" in tex
        assert "{AA}" in tex

    def test_tex_without_cantp(self):
        """Generator without CanTp should show 'No CAN Transport' message."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        # DCM-only file should have no transport config
        assert spec.transport_config is None

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "No CAN Transport Protocol configuration found" in tex

    def test_generate_file_with_cantp(self, tmp_path):
        """Full pipeline: DCM + CanTp -> .tex file."""
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        spec.ecu_name = "TestECU"

        gen = TexGenerator()
        output = tmp_path / "cantp_test.tex"
        result = gen.generate(spec, output)

        assert result == output
        assert output.exists()
        content = output.read_text()
        assert "Transport Layer" in content
        assert "TestECU" in content

    def test_structured_tex_no_empty_itemize_when_cantp_module_cfg_all_false(
        self, tmp_path
    ):
        """Regression: transport.tex.j2 used to open an itemize for the
        CanTp Module Configuration subsection with only conditional items
        (read_parameter_api / dyn_id_support / generic_connection_support /
        max_channel_cnt). When the parsed ARXML had all four fields
        false/None — the case for the bundled demo sample and many real
        ECUs — the itemize was emitted empty, causing xelatex to fail
        with "! LaTeX Error: Something's wrong--perhaps a missing \\item."

        The fix wraps the subsection + itemize with a guard that ensures
        at least one item will be rendered.
        """
        import io
        import zipfile

        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        assert spec.transport_config is not None
        assert spec.transport_config.read_parameter_api is False
        assert spec.transport_config.dyn_id_support is False
        assert spec.transport_config.generic_connection_support is False
        assert spec.transport_config.max_channel_cnt is None

        zip_path = tmp_path / "spec.zip"
        TexGenerator().generate_structured_tex_zip(spec, zip_path)
        with zipfile.ZipFile(zip_path) as zf:
            transport_tex = zf.read(
                next(n for n in zf.namelist() if n.endswith("transport.tex"))
            ).decode()

        assert "CanTp Module Configuration" not in transport_tex, (
            "Subsection rendered despite all CanTp module-config flags being "
            "false/None — would produce an empty \\begin{itemize}...\\end{itemize}"
        )
        for begin_idx in [
            i for i, line in enumerate(transport_tex.splitlines())
            if "\\begin{itemize}" in line
        ]:
            tail = transport_tex.splitlines()[begin_idx:]
            end_offset = next(
                (j for j, ln in enumerate(tail) if "\\end{itemize}" in ln), None
            )
            assert end_offset is not None
            inner = tail[1:end_offset]
            assert any("\\item" in ln for ln in inner), (
                f"Empty itemize at line {begin_idx + 1} in transport.tex"
            )

    def test_cli_multi_file(self, tmp_path):
        """CLI should handle DCM + CanTp files."""
        from udsxml2tex.cli import main

        output = tmp_path / "multi.tex"
        rc = main([str(SAMPLE_ARXML), str(SAMPLE_CANTP), "-o", str(output)])
        assert rc == 0
        assert output.exists()
        content = output.read_text()
        assert "Transport Layer" in content


class TestNewFeatures:
    """Tests for the 10 new AUTOSAR R4.4 features."""

    def test_security_adr_size(self):
        """DcmDspSecurityADRSize should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        sec1 = next(s for s in spec.security_levels if s.security_level == 1)
        assert sec1.adr_size == 2

        # SecurityLevel_2 has no ADR size defined → default 0
        sec2 = next(s for s in spec.security_levels if s.security_level == 2)
        assert sec2.adr_size == 0

    def test_did_data_endianness(self):
        """DataElement endianness should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        vin = next(d for d in spec.dids if d.did_id == 0xF190)
        assert len(vin.data_elements) > 0
        assert vin.data_elements[0].endianness == "BIG_ENDIAN"

    def test_did_data_fixed_length(self):
        """DataElement fixed_length should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        vin = next(d for d in spec.dids if d.did_id == 0xF190)
        assert vin.data_elements[0].fixed_length is True

    def test_dtc_status_availability_mask(self):
        """DcmDspDtcStatusAvailabilityMask should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.dtc_status_availability_mask == 0x09

    def test_max_num_resp_pend(self):
        """DcmDslDiagRespMaxNumRespPend should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.max_num_resp_pend == 10

    def test_max_response_length(self):
        """DcmDslProtocolMaximumResponseLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.max_response_length == 4095

    def test_suppress_pos_rsp_service(self):
        """DcmDsdSidTabSuppressPosRsp should be parsed on service."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        tp = next(s for s in spec.services if s.service_id == 0x3E)
        assert tp.suppress_pos_rsp is True

        # Services without it should default to False
        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert dsc.suppress_pos_rsp is False

    def test_suppress_pos_rsp_sub_service(self):
        """DcmDsdSubServiceSuppressPosRsp should be parsed on sub-function."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dsc = next(s for s in spec.services if s.service_id == 0x10)
        sf_default = next(
            sf for sf in dsc.sub_functions if sf.sub_function_id == 0x01
        )
        assert sf_default.suppress_pos_rsp is True

        # Sub-functions without it should default to False
        sf_prog = next(
            sf for sf in dsc.sub_functions if sf.sub_function_id == 0x02
        )
        assert sf_prog.suppress_pos_rsp is False

    def test_com_control_parsed(self):
        """DcmDspComControl should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.com_control is not None
        assert len(spec.com_control.sub_nodes) == 2

        normal = next(
            n for n in spec.com_control.sub_nodes
            if n.short_name == "ComControl_Normal"
        )
        assert normal.communication_type == 1
        assert normal.subnet_number == 0

        nm = next(
            n for n in spec.com_control.sub_nodes
            if n.short_name == "ComControl_NmCom"
        )
        assert nm.communication_type == 2
        assert nm.subnet_number == 1

    def test_response_on_event_parsed(self):
        """DcmDspRoe configuration should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.response_on_event) == 1
        roe = spec.response_on_event[0]
        assert roe.short_name == "RoeEvent_DtcStatusChange"
        assert roe.event_window_time == 60
        assert roe.store_event is True
        assert roe.service_to_respond_to == 0x19
        assert roe.event_type == "onDTCStatusChange"
        assert "ExtendedSession" in roe.supported_sessions

    def test_request_file_transfer_parsed(self):
        """DcmDspRequestFileTransfer should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.request_file_transfer) == 1
        rft = spec.request_file_transfer[0]
        assert rft.short_name == "FileTransfer_Log"
        assert rft.max_file_path_length == 128
        assert rft.max_file_size == 65536
        assert "ExtendedSession" in rft.supported_sessions
        assert "SecurityLevel_1" in rft.required_security_levels

    def test_clear_dtc_notification_parsed(self):
        """DcmDspClearDTCNotification should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.clear_dtc_notifications) == 1
        notif = spec.clear_dtc_notifications[0]
        assert notif.short_name == "DcmDspClearDTCNotification_App"
        assert notif.notification_class == "App_ClearDtcNotification"


class TestNewFeaturesTemplate:
    """Tests that new features render correctly in LaTeX output."""

    def test_tex_contains_max_num_resp_pend(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Max ResponsePending" in tex or "NRC 0x78" in tex
        assert "10" in tex

    def test_tex_contains_max_response_length(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Max Response Length" in tex or "MaxResponseLength" in tex

    def test_tex_contains_dtc_status_mask(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Status Availability Mask" in tex

    def test_tex_contains_adr_size_column(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "ADR (B)" in tex

    def test_tex_contains_endianness_column(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Endianness" in tex
        assert "BIG" in tex or "BIG\\_ENDIAN" in tex

    def test_tex_contains_roe_section(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Response On Event" in tex
        assert "onDTCStatusChange" in tex or "DtcStatusChange" in tex

    def test_tex_contains_file_transfer_section(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Request File Transfer" in tex or "File Transfer" in tex
        assert "FileTransfer" in tex

    def test_tex_contains_clear_dtc_notification(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Clear DTC Notification" in tex or "ClearDTC" in tex


class TestHighMedParsing:
    """Tests for HIGH and MEDIUM priority AUTOSAR R4.4 parameter parsing."""

    # ---- Session ----
    def test_session_comm_ctrl_option_mask(self):
        """DcmDspSessionCommCtrlOptionMask should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        ext = next(s for s in spec.sessions if s.short_name == "ExtendedSession")
        assert ext.comm_ctrl_option_mask == 0x03

        # DefaultSession has no mask → default 0
        default = next(s for s in spec.sessions if s.short_name == "DefaultSession")
        assert default.comm_ctrl_option_mask == 0

    # ---- Security ----
    def test_security_num_provided_seed_attempts(self):
        """DcmDspSecurityNumProvidedSeedAttempts should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        sec1 = next(s for s in spec.security_levels if s.security_level == 1)
        assert sec1.num_provided_seed_attempts == 5

    def test_security_algorithm_ref(self):
        """DcmDspSecurityAlgorithmRef should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        sec1 = next(s for s in spec.security_levels if s.security_level == 1)
        assert sec1.algorithm_ref == "SecurityAlgorithm_AES128"

    def test_security_seed_key_increment_mode(self):
        """DcmDspSecuritySeedAndKeyTypeIncrementMode should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        sec1 = next(s for s in spec.security_levels if s.security_level == 1)
        assert sec1.seed_key_increment_mode == "SEED_KEY_INCREMENT_PER_SESSION"

    # ---- Periodic DID ----
    def test_periodic_did_update_period(self):
        """DcmDspPeriodicDidUpdatePeriod should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        pdid = spec.periodic_dids[0]
        assert pdid.update_period == 0.1

    def test_periodic_did_security_levels(self):
        """DcmDspPeriodicDidSecurityLevelRef should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        pdid = spec.periodic_dids[0]
        assert "SecurityLevel_1" in pdid.required_security_levels

    # ---- DID Range ----
    def test_did_range_has_gaps(self):
        """DcmDspDidRangeHasGaps should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dr = spec.did_ranges[0]
        assert dr.has_gaps is False

    def test_did_range_data_length(self):
        """DcmDspDidRangeDataLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dr = spec.did_ranges[0]
        assert dr.data_length == 16

    # ---- IO Control ----
    def test_io_control_option_record_size(self):
        """DcmDspDidControlOptionRecordSize should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        io = spec.io_control_dids[0]
        assert io.control_option_record_size == 2

    def test_io_control_support_on_physical(self):
        """DcmDspDidControlSupportOnPhysicalRequest should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        io = spec.io_control_dids[0]
        assert io.support_on_physical is True

    def test_io_control_support_on_functional(self):
        """DcmDspDidControlSupportOnFunctionalRequest should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        io = spec.io_control_dids[0]
        assert io.support_on_functional is True

    # ---- Routine ----
    def test_routine_max_number_of_options(self):
        """DcmDspRoutineMaxNumberOfOptions should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        rt = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert rt.max_number_of_options == 3

    def test_routine_access_type_required(self):
        """DcmDspRoutineAccessTypeRequired should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        rt = next(r for r in spec.routines if r.routine_id == 0x0203)
        assert rt.access_type_required is True

    # ---- DTC ----
    def test_dtc_manufacturer_severity(self):
        """DcmDspDtcManufacturerSeverity should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dt = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dt.manufacturer_severity == "CRITICAL"

    # ---- ROE ----
    def test_roe_max_event_map_range_identifier(self):
        """DcmDspRoeMaxEventMapRangeIdentifier should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        roe = spec.response_on_event[0]
        assert roe.max_event_map_range_identifier == 255

    def test_roe_transmission_mode(self):
        """DcmDspRoeTransmissionMode should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        roe = spec.response_on_event[0]
        assert roe.transmission_mode == "SINGLE_FRAME"

    # ---- File Transfer ----
    def test_file_transfer_format_identifier(self):
        """DcmDspRequestFileTransferFormatIdentifier should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        rft = spec.request_file_transfer[0]
        assert rft.format_identifier == 0

    def test_file_transfer_data_block_size(self):
        """DcmDspRequestFileTransferDataBlockSize should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        rft = spec.request_file_transfer[0]
        assert rft.data_block_size == 512

    def test_file_transfer_address_and_length(self):
        """AddressLength and LengthLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        rft = spec.request_file_transfer[0]
        assert rft.address_length == 4
        assert rft.length_length == 4

    # ---- ComControl ----
    def test_com_control_suppressor_rx_using_mask(self):
        """DcmDspComControlSuppressorRxUsingMask should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.com_control.suppressor_rx_using_mask is True

    # ---- Memory Range ----
    def test_memory_range_addressing_mode(self):
        """DcmDspMemoryRangeAddressingMode should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        mr = spec.memory_ranges[0]
        assert mr.addressing_mode == "LINEAR"

    def test_memory_range_length(self):
        """DcmDspMemoryRangeLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        mr = spec.memory_ranges[0]
        assert mr.memory_range_length == 65536

    # ---- Service req/resp lengths ----
    def test_service_request_min_length(self):
        """DcmDsdServiceRequestMinLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert dsc.request_min_length == 2

    def test_service_request_max_length(self):
        """DcmDsdServiceRequestMaxLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert dsc.request_max_length == 2

    def test_service_response_min_length(self):
        """DcmDsdServiceResponseMinLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert dsc.response_min_length == 6

    def test_service_response_max_length(self):
        """DcmDsdServiceResponseMaxLength should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dsc = next(s for s in spec.services if s.service_id == 0x10)
        assert dsc.response_max_length == 6

    # ---- Sub-function data_block_size ----
    def test_sub_function_data_block_size(self):
        """DcmDsdSubServiceDataBlockSize should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        dsc = next(s for s in spec.services if s.service_id == 0x10)
        sf_default = next(
            sf for sf in dsc.sub_functions if sf.sub_function_id == 0x01
        )
        assert sf_default.data_block_size == 4

    # ---- DSL Connection ----
    def test_connection_mode(self):
        """DcmDslConnectionMode should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.connection_mode == "ON_BOARD"

    def test_connection_end_of_type(self):
        """DcmDslConnectionDcmEndOfConnectionType should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.connection_end_of_type == "NORMAL"

    # ---- DcmGeneral ----
    def test_module_main_function_period(self):
        """DcmModuleMainFunctionPeriod should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.module_main_function_period == 0.01

    def test_enable_fim_trigger(self):
        """DcmEnableFimTrigger should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.enable_fim_trigger is True

    # ---- CDTC / ClearDTC ----
    def test_cdtc_status_mask(self):
        """DcmDspCDTCStatusMask should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.cdtc_status_mask == 0xFF

    def test_clear_dtc_group(self):
        """DcmDspClearDTCGroup should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert spec.clear_dtc_group == 0xFFFF33

    # ---- Dynamic DID ----
    def test_dynamic_did_parsed(self):
        """DcmDspDDDID should be parsed."""
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        assert len(spec.dynamic_dids) == 1
        dd = spec.dynamic_dids[0]
        assert dd.short_name == "DynamicDid_F300"
        assert dd.did_id == 0xF300
        assert dd.did_id_hex == "0xF300"
        assert dd.max_number_of_source_elements == 4
        assert "ExtendedSession" in dd.supported_sessions
        assert "SecurityLevel_1" in dd.required_security_levels


class TestHighMedCanTp:
    """Tests for HIGH/MEDIUM CanTp new features."""

    def test_can_fd_enabled(self):
        """CanTpCanFdEnabled should be parsed."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        assert config.can_fd_enabled is True

    def test_tx_nsa(self):
        """CanTpTxNSa should be parsed."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.tx_nsa == 0x10

    def test_tx_nta(self):
        """CanTpTxNTa should be parsed."""
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)

        phys = next(
            (ch for ch in config.channels if "Phys" in ch.short_name), None
        )
        assert phys is not None
        assert phys.tx_nta == 0x20


class TestHighMedTemplate:
    """Tests that new HIGH/MEDIUM features render correctly in LaTeX."""

    def test_tex_contains_connection_mode(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Connection Mode" in tex
        assert "ON\\_BOARD" in tex or "ON_BOARD" in tex

    def test_tex_contains_dynamic_did_section(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Dynamic DID" in tex
        assert "DynamicDid" in tex or "F300" in tex

    def test_tex_contains_dcm_general(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "DCM General" in tex or "Module Main Function Period" in tex

    def test_tex_contains_cdtc_section(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "CDTC Status Mask" in tex or "ControlDTCSetting" in tex

    def test_tex_contains_security_algorithm(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Algorithm" in tex
        assert "AES128" in tex or "SecurityAlgorithm" in tex

    def test_tex_contains_routine_max_options(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "Max Number of Options" in tex

    def test_tex_contains_can_fd(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        gen = TexGenerator()
        tex = gen.generate_string(spec)

        assert "CAN FD" in tex


class TestMediumPriorityParsing:
    """Tests for MEDIUM priority AUTOSAR params (v0.7.0)."""

    # ---- DcmDsl protocol ----
    def test_protocol_priority(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.protocol_priority == 1

    def test_protocol_trans_type(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.protocol_trans_type == "TYPE_1"

    def test_protocol_preempt_timeout(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.protocol_preempt_timeout == 2.0

    # ---- DcmDsl periodic rates ----
    def test_periodic_slow_rate(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.periodic_slow_rate == 2.0

    def test_periodic_medium_rate(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.periodic_medium_rate == 0.5

    def test_periodic_fast_rate(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.periodic_fast_rate == 0.02

    # ---- Security new fields ----
    def test_security_delay_time_on_boot(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        sec1 = next(s for s in spec.security_levels if s.short_name == "SecurityLevel_1")
        assert sec1.delay_time_on_boot == 5.0

    def test_security_attempt_counter_enabled(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        sec1 = next(s for s in spec.security_levels if s.short_name == "SecurityLevel_1")
        assert sec1.attempt_counter_enabled is True

    # ---- DTC new fields ----
    def test_dtc_aging_cycle_counter_threshold(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        dtc = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dtc.aging_cycle_counter_threshold == 40

    def test_dtc_aging_allowed(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        dtc = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dtc.aging_allowed is True

    def test_dtc_priority(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        dtc = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dtc.priority == 2

    def test_dtc_kind(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        dtc = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dtc.dtc_kind == "NON_EMISSION"

    def test_dtc_immediate_nv_storage(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        dtc = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dtc.immediate_nv_storage is True

    def test_dtc_occurrence_counter_processing(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        dtc = next(d for d in spec.dtcs if d.short_name == "DTC_BusOff")
        assert dtc.occurrence_counter_processing == "DEM_PROCESS_OCCCTR_TF"

    # ---- Memory new fields ----
    def test_memory_id_value(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        mr = next(m for m in spec.memory_ranges if m.short_name == "ReadRange_Calibration")
        assert mr.memory_id_value == 1

    def test_memory_compression_method(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.memory_compression_method == "NONE"

    def test_memory_encrypting_method(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.memory_encrypting_method == "AES_128_CBC"


class TestMediumCanTp:
    """Tests for MEDIUM priority CanTp params (v0.7.0)."""

    def test_wft_max(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        assert config.wft_max == 5

    def test_change_parm_api(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        assert config.change_parm_api is True

    def test_tc(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        assert config.tc is True


class TestMediumTemplate:
    """Tests that MEDIUM priority features render in LaTeX."""

    def test_tex_contains_protocol_priority(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Protocol Priority" in tex

    def test_tex_contains_protocol_trans_type(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Protocol Trans Type" in tex
        assert "TYPE" in tex

    def test_tex_contains_periodic_rates(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Periodic Slow Rate" in tex
        assert "Periodic Medium Rate" in tex
        assert "Periodic Fast Rate" in tex

    def test_tex_contains_security_boot_delay(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Boot Delay" in tex

    def test_tex_contains_security_counter(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Counter" in tex

    def test_tex_contains_dtc_kind(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Kind" in tex
        assert "NON" in tex

    def test_tex_contains_dtc_aging(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Aging" in tex

    def test_tex_contains_memory_id(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Mem ID" in tex

    def test_tex_contains_memory_encryption(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Memory Encrypting Method" in tex
        assert "AES" in tex

    def test_tex_contains_cantp_wftmax(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "WFTmax" in tex

    def test_tex_contains_cantp_change_parm(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Change Parameter API" in tex

    def test_tex_contains_cantp_tc(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Transmit Cancellation" in tex


class TestPhase1DcmGeneral:
    """Tests for Phase 1 DcmGeneral params (v0.8.0)."""

    def test_dev_error_detect(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.dev_error_detect is True

    def test_version_info_api(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.version_info_api is True

    def test_task_time(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.task_time == 0.005

    def test_respond_all_request(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        assert spec.respond_all_request is False


class TestPhase1CanTpGeneral:
    """Tests for Phase 1 CanTp general params (v0.8.0)."""

    def test_dev_error_detect(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        assert config.dev_error_detect is True

    def test_version_info_api(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        assert config.version_info_api is True

    def test_padding_byte(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        assert config.padding_byte == 0xCC


class TestPhase1CanTpFcDl:
    """Tests for Phase 1 CAN-FD FC DL params (v0.8.0)."""

    def test_rx_fc_dl(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        phys = next(c for c in config.channels if "Phys" in c.short_name)
        assert phys.rx_fc_dl == 12

    def test_tx_fc_dl(self):
        parser = CanTpParser()
        config = parser.parse(SAMPLE_CANTP)
        phys = next(c for c in config.channels if "Phys" in c.short_name)
        assert phys.tx_fc_dl == 16


class TestPhase1Template:
    """Tests that Phase 1 features render in LaTeX."""

    def test_tex_contains_dev_error_detect(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Development Error Detection" in tex

    def test_tex_contains_version_info_api(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Version Info API" in tex

    def test_tex_contains_task_time(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Task Time" in tex

    def test_tex_contains_respond_all_request(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Respond All Request" in tex

    def test_tex_contains_cantp_dev_error_detect(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        # CanTp section also has "Development Error Detection"
        assert tex.count("Development Error Detection") >= 2

    def test_tex_contains_cantp_version_info_api(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert tex.count("Version Info API") >= 2

    def test_tex_contains_cantp_padding_byte(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Global Padding Byte" in tex

    def test_tex_contains_fc_dl_column(self):
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "FC DL" in tex


# ============================================================================
# New feature tests
# ============================================================================


class TestArxmlValidation:
    """Tests for ARXML validation and error recovery."""

    def test_validate_file_not_found(self):
        from udsxml2tex.parser import ArxmlValidationError
        parser = ArxmlParser()
        with pytest.raises(ArxmlValidationError, match="not found"):
            parser.validate("/nonexistent/file.arxml")

    def test_validate_invalid_xml(self, tmp_path):
        from udsxml2tex.parser import ArxmlValidationError
        bad_file = tmp_path / "bad.arxml"
        bad_file.write_text("<not-closed>", encoding="utf-8")
        parser = ArxmlParser()
        with pytest.raises(ArxmlValidationError, match="XML syntax"):
            parser.validate(bad_file)

    def test_validate_not_autosar_root(self, tmp_path):
        from udsxml2tex.parser import ArxmlValidationError
        bad_file = tmp_path / "notautosar.arxml"
        bad_file.write_text('<?xml version="1.0"?><root/>', encoding="utf-8")
        parser = ArxmlParser()
        with pytest.raises(ArxmlValidationError, match="<root>"):
            parser.validate(bad_file)

    def test_validate_good_arxml_returns_warnings(self):
        parser = ArxmlParser()
        warnings = parser.validate(SAMPLE_ARXML)
        # A valid file may or may not have warnings, but should not raise
        assert isinstance(warnings, list)

    def test_parse_populates_warnings(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        # warnings should be a list (may be empty for good files)
        assert isinstance(parser.warnings, list)

    def test_error_recovery_partial_parse(self, tmp_path):
        """Even if one section is broken, other sections should still parse."""
        # Create a minimal ARXML with at least the AUTOSAR root
        arxml_content = '''<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <AR-PACKAGES>
    <AR-PACKAGE>
      <SHORT-NAME>TestEcu</SHORT-NAME>
    </AR-PACKAGE>
  </AR-PACKAGES>
</AUTOSAR>'''
        arxml_file = tmp_path / "minimal.arxml"
        arxml_file.write_text(arxml_content, encoding="utf-8")

        parser = ArxmlParser()
        spec = parser.parse(arxml_file)
        # Should produce a result (possibly empty) without crashing
        assert spec is not None


class TestLinkControlService:
    """Tests for LinkControl (0x87) support."""

    def test_link_control_in_service_names(self):
        from udsxml2tex.models import UDS_SERVICE_NAMES
        assert 0x87 in UDS_SERVICE_NAMES
        assert UDS_SERVICE_NAMES[0x87] == "LinkControl"

    def test_link_control_message_format(self):
        from udsxml2tex.models import UDS_MESSAGE_FORMATS
        assert 0x87 in UDS_MESSAGE_FORMATS
        req_rows, resp_rows = UDS_MESSAGE_FORMATS[0x87]
        # Request should start with SID 87
        assert req_rows[0][2] == "87"
        assert req_rows[0][3] is True  # is_fixed_hex
        # Response should start with C7
        assert resp_rows[0][2] == "C7"

    def test_link_control_sub_functions(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        assert 0x87 in STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x87]
        assert len(sfs) == 3
        sf_ids = [sf[0] for sf in sfs]
        assert 0x01 in sf_ids  # verifyModeTransitionWithFixedParameter
        assert 0x02 in sf_ids  # verifyModeTransitionWithSpecificParameter
        assert 0x03 in sf_ids  # transitionMode

    def test_link_control_in_service_order(self):
        from udsxml2tex.models import ISO14229_SERVICE_ORDER
        assert 0x87 in ISO14229_SERVICE_ORDER

    def test_link_control_addressing_modes(self):
        from udsxml2tex.models import STANDARD_ADDRESSING_MODES
        assert 0x87 in STANDARD_ADDRESSING_MODES


class TestNewMessageFormats:
    """Tests for newly added message formats (0x24, 0x2C, 0x84)."""

    def test_read_scaling_data_format(self):
        from udsxml2tex.models import UDS_MESSAGE_FORMATS
        assert 0x24 in UDS_MESSAGE_FORMATS
        req, resp = UDS_MESSAGE_FORMATS[0x24]
        assert req[0][2] == "24"
        assert resp[0][2] == "64"

    def test_dynamic_did_format(self):
        from udsxml2tex.models import UDS_MESSAGE_FORMATS
        assert 0x2C in UDS_MESSAGE_FORMATS
        req, resp = UDS_MESSAGE_FORMATS[0x2C]
        assert req[0][2] == "2C"
        assert resp[0][2] == "6C"

    def test_secured_data_format(self):
        from udsxml2tex.models import UDS_MESSAGE_FORMATS
        assert 0x84 in UDS_MESSAGE_FORMATS
        req, resp = UDS_MESSAGE_FORMATS[0x84]
        assert req[0][2] == "84"
        assert resp[0][2] == "C4"

    def test_dynamic_did_sub_functions(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        assert 0x2C in STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x2C]
        sf_names = [sf[1] for sf in sfs]
        assert "defineByIdentifier" in sf_names
        assert "defineByMemoryAddress" in sf_names
        assert "clearDynamicallyDefinedDataIdentifier" in sf_names


class TestReadDTCSubFunctions:
    """Tests for expanded ReadDTCInformation (0x19) sub-functions."""

    def test_0x03_snapshot_identification(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_ids = [sf[0] for sf in sfs]
        assert 0x03 in sf_ids
        sf_03 = [sf for sf in sfs if sf[0] == 0x03][0]
        assert sf_03[1] == "reportDTCSnapshotIdentification"

    def test_0x05_stored_data_by_record(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_ids = [sf[0] for sf in sfs]
        assert 0x05 in sf_ids
        sf_05 = [sf for sf in sfs if sf[0] == 0x05][0]
        assert sf_05[1] == "reportDTCStoredDataByRecordNumber"

    def test_total_sub_function_count(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        # ISO 14229-1:2020 complete list (24 sub-functions)
        assert len(sfs) == 24


class TestNrcCommonFormat:
    """Tests for NRC common format in the LaTeX template."""

    def test_tex_contains_nrc_common_table(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Negative Response Message Format" in tex
        assert "Negative Response Service Identifier" in tex
        assert "requestServiceId" in tex
        assert "negativeResponseCode" in tex
        assert r"\hexval{7F}" in tex

    def test_tex_contains_standard_nrc_table(self):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        tex = gen.generate_string(spec)
        assert "Standard Negative Response Codes" in tex
        assert "generalReject" in tex
        assert "serviceNotSupported" in tex
        assert "conditionsNotCorrect" in tex


class TestHtmlGeneration:
    """Tests for HTML output generation."""

    def test_generate_html(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        out = tmp_path / "output.html"
        result = gen.generate_html(spec, out)
        assert result.exists()
        content = result.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content
        assert spec.ecu_name in content

    def test_html_contains_services(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        out = tmp_path / "output.html"
        gen.generate_html(spec, out)
        content = out.read_text(encoding="utf-8")
        assert "UDS Services" in content
        assert "Negative Response Message Format" in content

    def test_html_contains_dids(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        out = tmp_path / "output.html"
        gen.generate_html(spec, out)
        content = out.read_text(encoding="utf-8")
        assert "Data Identifiers" in content

    def test_html_contains_nrc_standard_table(self, tmp_path):
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        gen = TexGenerator()
        out = tmp_path / "output.html"
        gen.generate_html(spec, out)
        content = out.read_text(encoding="utf-8")
        assert "Standard Negative Response Codes" in content
        assert "generalReject" in content


class TestDryRun:
    """Tests for --dry-run CLI option."""

    def test_dry_run_prints_summary(self, capsys):
        from udsxml2tex.cli import main
        exit_code = main(["--dry-run", str(SAMPLE_ARXML)])
        assert exit_code == 0
        captured = capsys.readouterr()
        # Header is "Dry Run Summary" (plain) or "udsxml2tex --dry-run" (rich)
        assert "Dry Run Summary" in captured.out or "udsxml2tex --dry-run" in captured.out
        # Inventory labels appear in both layouts
        assert ("ECU Name:" in captured.out) or ("ECU:" in captured.out)
        assert "Sessions" in captured.out
        assert "Services" in captured.out
        assert "DIDs" in captured.out

    def test_dry_run_no_output_file(self, tmp_path, capsys):
        from udsxml2tex.cli import main
        output = tmp_path / "should_not_exist.tex"
        exit_code = main(["--dry-run", "-o", str(output), str(SAMPLE_ARXML)])
        assert exit_code == 0
        assert not output.exists()


class TestPdfCompilation:
    """Tests for PDF compilation support."""

    def test_compile_pdf_no_compiler(self, tmp_path, monkeypatch):
        """compile_pdf raises FileNotFoundError if no LaTeX compiler found."""
        import shutil
        monkeypatch.setattr(shutil, "which", lambda _name: None)

        gen = TexGenerator()
        tex_file = tmp_path / "test.tex"
        tex_file.write_text("\\documentclass{article}\\begin{document}hello\\end{document}")

        with pytest.raises(FileNotFoundError, match="No LaTeX compiler"):
            gen.compile_pdf(tex_file)

    def test_compile_pdf_tex_not_found(self):
        gen = TexGenerator()
        with pytest.raises(FileNotFoundError, match="TeX file not found"):
            gen.compile_pdf("/nonexistent/file.tex")


class TestCliNewOptions:
    """Tests for new CLI options."""

    def test_html_flag_generates_html(self, tmp_path):
        from udsxml2tex.cli import main
        output = tmp_path / "output.html"
        exit_code = main(["--html", "-o", str(output), str(SAMPLE_ARXML)])
        assert exit_code == 0
        assert output.exists()
        content = output.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content

    def test_version_matches_package(self, capsys):
        from udsxml2tex.cli import main
        with pytest.raises(SystemExit) as exc_info:
            main(["--version"])
        assert exc_info.value.code == 0
        from udsxml2tex import __version__
        captured = capsys.readouterr()
        assert __version__ in captured.out


class TestVersionConsistency:
    """Tests for version consistency across the project."""

    def test_init_version(self):
        from udsxml2tex import __version__
        assert __version__ == "0.47.1"

    @pytest.mark.skipif(
        __import__("sys").version_info < (3, 11),
        reason="tomllib requires Python 3.11+",
    )
    def test_pyproject_version_matches(self):
        import tomllib
        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        with open(pyproject, "rb") as f:
            data = tomllib.load(f)
        from udsxml2tex import __version__
        assert data["project"]["version"] == __version__


class TestDemParser:
    """Tests for DEM (Diagnostic Event Manager) parsing."""

    @pytest.fixture(autouse=True)
    def parse_dem(self):
        parser = ArxmlParser()
        self.spec = parser.parse(SAMPLE_DEM)

    def test_dem_general_parsed(self):
        g = self.spec.dem_general
        assert g is not None
        assert g.status_bit_storage_test_failed is True
        assert g.status_bit_handling_tfslc == "DEM_STATUS_BIT_AGING_AND_DISPLACEMENT"
        assert g.reset_confirmed_bit_on_overflow is True
        assert g.operation_cycle_status_storage is True
        assert g.type_of_dtc_supported == "DEM_DTC_TRANSLATION_ISO14229_1"
        assert g.clear_dtc_limitation == "DEM_ALL_SUPPORTED_DTCS"
        assert g.suppression_support is True
        assert g.trigger_fim_reports is True

    def test_operation_cycles_parsed(self):
        cycles = self.spec.dem_operation_cycles
        assert len(cycles) == 3
        ign = next(c for c in cycles if c.short_name == "DemOperationCycle_Ignition")
        assert ign.cycle_id == 0
        assert ign.cycle_type == "DEM_OPCYC_IGNITION"
        assert ign.autostart is True

    def test_event_parameters_parsed(self):
        events = self.spec.dem_event_parameters
        assert len(events) == 2
        evt1 = next(e for e in events if e.event_id == 1)
        assert evt1.event_kind == "DEM_EVENT_KIND_SWC"
        assert evt1.confirmation_threshold == 2
        assert "Ignition" in evt1.operation_cycle_ref
        assert "SensorA" in evt1.dtc_ref

    def test_debounce_counter_based(self):
        evt = next(e for e in self.spec.dem_event_parameters if e.event_id == 1)
        d = evt.debounce
        assert d is not None
        assert d.algorithm == "COUNTER_BASED"
        assert d.counter_failed_threshold == 3
        assert d.counter_passed_threshold == -3
        assert d.counter_increment_step == 1
        assert d.counter_storage is True

    def test_debounce_time_based(self):
        evt = next(e for e in self.spec.dem_event_parameters if e.event_id == 2)
        d = evt.debounce
        assert d is not None
        assert d.algorithm == "TIME_BASED"
        assert d.time_failed_threshold == pytest.approx(0.5)
        assert d.time_passed_threshold == pytest.approx(1.0)

    def test_indicators_parsed(self):
        indicators = self.spec.dem_indicators
        assert len(indicators) == 2
        mil = next(i for i in indicators if i.short_name == "DemIndicator_MIL")
        assert mil.indicator_id == 0
        assert mil.behaviour == "CONTINUOUS"
        assert mil.failure_cycle_counter_threshold == 1
        assert mil.healing_cycle_counter_threshold == 3

    def test_enable_conditions_parsed(self):
        conds = self.spec.dem_enable_conditions
        assert len(conds) == 2
        batt = next(c for c in conds if "BatteryVoltage" in c.short_name)
        assert batt.condition_id == 0
        assert batt.initial_status is True

    def test_storage_conditions_parsed(self):
        conds = self.spec.dem_storage_conditions
        assert len(conds) == 1
        assert conds[0].condition_id == 0
        assert conds[0].initial_status is True

    def test_event_memory_parsed(self):
        mems = self.spec.dem_event_memories
        assert len(mems) == 1
        pm = mems[0]
        assert pm.memory_type == "PRIMARY"
        assert pm.max_number_event_entries == 40
        assert pm.displacement_strategy == "DEM_DISPLACEMENT_FULL"
        assert pm.max_number_freeze_frame_records == 3

    def test_dtc_status_availability_mask_derived(self):
        """ISO 14229-1 §11.3.5.2.2 — derived from DemGeneral flags when no
        explicit DemDtcStatusAvailabilityMask parameter is provided."""
        g = self.spec.dem_general
        assert g is not None
        # bit0 testFailed, bit1 TFTOC, bit2 pendingDTC, bit3 confirmedDTC always supported
        assert g.dtc_status_availability_mask & 0x0F == 0x0F
        # status_bit_handling_tfslc is set in fixture → bits 4 + 5 supported
        assert g.dtc_status_availability_mask & 0x30 == 0x30
        # operation_cycle_status_storage = True → bit 6 supported
        assert g.dtc_status_availability_mask & 0x40 == 0x40
        # 2 DemIndicators present → bit 7 supported
        assert g.dtc_status_availability_mask & 0x80 == 0x80
        assert g.dtc_status_availability_mask == 0xFF

    def test_dtc_format_identifier(self):
        """ISO 14229-1 §11.3.6 — derived from DemTypeOfDTCSupported."""
        g = self.spec.dem_general
        assert g is not None
        # DEM_DTC_TRANSLATION_ISO14229_1 → 0x01
        assert g.dtc_format_identifier == 0x01

    def test_dem_mask_propagated_to_spec(self):
        """When DCM does not specify the mask, DEM-derived value is used."""
        if self.spec.dtc_status_availability_mask == 0xFF:
            assert self.spec.dem_general is not None
            assert self.spec.dem_general.dtc_status_availability_mask > 0


def test_derive_dtc_status_availability_mask_helper():
    """Standalone test for derivation helper."""
    from udsxml2tex.dem_parser import derive_dtc_status_availability_mask
    assert derive_dtc_status_availability_mask() == 0x0F
    assert (
        derive_dtc_status_availability_mask(
            op_cycle_status_storage=True,
            tfslc_handling="DEM_STATUS_BIT_AGING_AND_DISPLACEMENT",
            has_indicators=True,
        )
        == 0xFF
    )
    assert derive_dtc_status_availability_mask(has_indicators=True) == 0x8F


class TestDemDtcAttributes:
    """Tests for new DemDTCAttributes fields (v0.17.0)."""

    @pytest.fixture(autouse=True)
    def parse_dem(self):
        from udsxml2tex.dem_parser import DemParser
        parser = ArxmlParser()
        self.spec = parser.parse(SAMPLE_DEM)
        DemParser().parse(SAMPLE_DEM, self.spec)

    def test_dem_dtcs_parsed(self):
        assert len(self.spec.dem_dtcs) >= 2

    def test_dtc_severity_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert dtc_a.severity == "DEM_SEVERITY_CHECK_AT_NEXT_HALT"

    def test_dtc_kind_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert "EMISSION" in dtc_a.kind

    def test_dtc_priority_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert dtc_a.priority == 2

    def test_dtc_aging_threshold_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert dtc_a.aging_cycle_counter_threshold == 40

    def test_dtc_aging_cycle_ref_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert "Ignition" in dtc_a.aging_cycle_ref

    def test_dtc_ob_dtc_value_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert dtc_a.ob_dtc_value == 0x0101

    def test_dtc_wwh_obd_class_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert dtc_a.wwh_obd_dtc_class == "DEM_WWHOBD_CLASS_A"

    def test_dtc_freeze_frame_class_ref_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert "DemFreezeFrameClass_Standard" in dtc_a.freeze_frame_class_ref

    def test_dtc_extended_data_class_ref_parsed(self):
        dtc_a = next(d for d in self.spec.dem_dtcs if "SensorA" in d.short_name)
        assert "DemExtendedDataClass_OccCounter" in dtc_a.extended_data_class_ref

    def test_dtc_b_severity_maintenance_only(self):
        dtc_b = next(d for d in self.spec.dem_dtcs if "SensorB" in d.short_name)
        assert dtc_b.severity == "DEM_SEVERITY_MAINTENANCE_ONLY"

    def test_dtc_b_no_obd_value(self):
        dtc_b = next(d for d in self.spec.dem_dtcs if "SensorB" in d.short_name)
        assert dtc_b.ob_dtc_value == 0

    def test_dtc_severity_bits_hex(self):
        from udsxml2tex.models import DemDtcEntry
        e = DemDtcEntry(short_name="X", severity="DEM_SEVERITY_CHECK_AT_NEXT_HALT")
        assert e.severity_bits_hex == "0x40"
        e2 = DemDtcEntry(short_name="Y", severity="DEM_SEVERITY_CHECK_IMMEDIATELY")
        assert e2.severity_bits_hex == "0x80"
        e3 = DemDtcEntry(short_name="Z", severity="DEM_SEVERITY_MAINTENANCE_ONLY")
        assert e3.severity_bits_hex == "0x20"


class TestDemParserDefinitionRefStyle:
    """R4.4 convention: container type is identified by DEFINITION-REF tail,
    while SHORT-NAME is an arbitrary instance identifier.

    Regression for the case where ``DemEventParameter`` and ``DemDTC`` are
    parallel sub-containers under ``DemConfigSet`` (AUTOSAR R4.4 multiplicity
    1..* / 0..*) and SHORT-NAMEs do not embed the type name.
    """

    _ARXML = """<?xml version="1.0" encoding="UTF-8"?>
<AUTOSAR xmlns="http://autosar.org/schema/r4.0">
  <AR-PACKAGES><AR-PACKAGE><SHORT-NAME>Dem</SHORT-NAME><ELEMENTS>
    <ECUC-MODULE-CONFIGURATION-VALUES><SHORT-NAME>Dem</SHORT-NAME><CONTAINERS>
      <ECUC-CONTAINER-VALUE>
        <SHORT-NAME>DemConfigSet</SHORT-NAME>
        <DEFINITION-REF DEST="ECUC-PARAM-CONF-CONTAINER-DEF">/AUTOSAR/EcucDefs/Dem/DemConfigSet</DEFINITION-REF>
        <SUB-CONTAINERS>
          <ECUC-CONTAINER-VALUE>
            <SHORT-NAME>Evt_BatteryLow</SHORT-NAME>
            <DEFINITION-REF DEST="ECUC-PARAM-CONF-CONTAINER-DEF">/AUTOSAR/EcucDefs/Dem/DemConfigSet/DemEventParameter</DEFINITION-REF>
            <PARAMETER-VALUES>
              <ECUC-NUMERICAL-PARAM-VALUE>
                <DEFINITION-REF>/AUTOSAR/EcucDefs/Dem/DemConfigSet/DemEventParameter/DemEventId</DEFINITION-REF>
                <VALUE>7</VALUE>
              </ECUC-NUMERICAL-PARAM-VALUE>
            </PARAMETER-VALUES>
            <REFERENCE-VALUES>
              <ECUC-REFERENCE-VALUE>
                <DEFINITION-REF>/AUTOSAR/EcucDefs/Dem/DemConfigSet/DemEventParameter/DemDTCRef</DEFINITION-REF>
                <VALUE-REF>/Dem/DemConfigSet/Dtc_BatteryLow</VALUE-REF>
              </ECUC-REFERENCE-VALUE>
            </REFERENCE-VALUES>
          </ECUC-CONTAINER-VALUE>
          <ECUC-CONTAINER-VALUE>
            <SHORT-NAME>Dtc_BatteryLow</SHORT-NAME>
            <DEFINITION-REF DEST="ECUC-PARAM-CONF-CONTAINER-DEF">/AUTOSAR/EcucDefs/Dem/DemConfigSet/DemDTC</DEFINITION-REF>
            <PARAMETER-VALUES>
              <ECUC-NUMERICAL-PARAM-VALUE>
                <DEFINITION-REF>/AUTOSAR/EcucDefs/Dem/DemConfigSet/DemDTC/DemDtcValue</DEFINITION-REF>
                <VALUE>0xA00101</VALUE>
              </ECUC-NUMERICAL-PARAM-VALUE>
            </PARAMETER-VALUES>
          </ECUC-CONTAINER-VALUE>
        </SUB-CONTAINERS>
      </ECUC-CONTAINER-VALUE>
    </CONTAINERS></ECUC-MODULE-CONFIGURATION-VALUES>
  </ELEMENTS></AR-PACKAGE></AR-PACKAGES>
</AUTOSAR>
"""

    @pytest.fixture(autouse=True)
    def parse_dem(self, tmp_path):
        from udsxml2tex.dem_parser import DemParser
        from udsxml2tex.models import UdsSpecification
        arxml = tmp_path / "dem_r44.arxml"
        arxml.write_text(self._ARXML, encoding="utf-8")
        self.spec = UdsSpecification()
        DemParser().parse(str(arxml), self.spec)

    def test_event_parsed_via_definition_ref(self):
        events = self.spec.dem_event_parameters
        assert len(events) == 1
        assert events[0].short_name == "Evt_BatteryLow"
        assert events[0].event_id == 7

    def test_dtc_parsed_via_definition_ref(self):
        dtcs = self.spec.dem_dtcs
        assert len(dtcs) == 1
        assert dtcs[0].short_name == "Dtc_BatteryLow"
        assert dtcs[0].dtc_value == 0xA00101

    def test_event_resolves_dtc_ref(self):
        evt = self.spec.dem_event_parameters[0]
        assert evt.dtc_ref == "Dtc_BatteryLow"


class TestDtcStatusBitDefinitions:
    """Tests for DTC_STATUS_BIT_DEFINITIONS constant (v0.17.0)."""

    def test_bit_definitions_count(self):
        from udsxml2tex.models import DTC_STATUS_BIT_DEFINITIONS
        assert len(DTC_STATUS_BIT_DEFINITIONS) == 8

    def test_bit_0_testFailed(self):
        from udsxml2tex.models import DTC_STATUS_BIT_DEFINITIONS
        bit_pos, mask, name, _desc = DTC_STATUS_BIT_DEFINITIONS[0]
        assert bit_pos == 0
        assert mask == 0x01
        assert name == "testFailed"

    def test_bit_7_warningIndicatorRequested(self):
        from udsxml2tex.models import DTC_STATUS_BIT_DEFINITIONS
        bit_pos, mask, name, _desc = DTC_STATUS_BIT_DEFINITIONS[7]
        assert bit_pos == 7
        assert mask == 0x80
        assert name == "warningIndicatorRequested"

    def test_masks_are_powers_of_two(self):
        from udsxml2tex.models import DTC_STATUS_BIT_DEFINITIONS
        for bit_pos, mask, _name, _desc in DTC_STATUS_BIT_DEFINITIONS:
            assert mask == (1 << bit_pos)


class TestResponseOnEventSubFunctions:
    """Tests for ResponseOnEvent (0x86) sub-functions (v0.17.0)."""

    def test_roe_sub_functions_present(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        assert 0x86 in STANDARD_SUB_FUNCTIONS

    def test_roe_sub_function_count(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x86]
        assert len(sfs) == 8

    def test_roe_stop_response(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x86]
        sf_00 = next(sf for sf in sfs if sf[0] == 0x00)
        assert sf_00[1] == "stopResponseOnEvent"

    def test_roe_start_response(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x86]
        sf_05 = next(sf for sf in sfs if sf[0] == 0x05)
        assert sf_05[1] == "startResponseOnEvent"


class TestReadDTCExtendedSubFunctions:
    """Tests for new ReadDTCInformation sub-functions (v0.17.0)."""

    def test_report_number_of_dtc_by_severity(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_07 = next(sf for sf in sfs if sf[0] == 0x07)
        assert sf_07[1] == "reportNumberOfDTCBySeverityMaskRecord"

    def test_report_dtc_by_severity(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_08 = next(sf for sf in sfs if sf[0] == 0x08)
        assert sf_08[1] == "reportDTCBySeverityMaskRecord"

    def test_report_severity_info(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_09 = next(sf for sf in sfs if sf[0] == 0x09)
        assert sf_09[1] == "reportSeverityInformationOfDTC"

    def test_report_first_test_failed(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_0b = next(sf for sf in sfs if sf[0] == 0x0B)
        assert sf_0b[1] == "reportFirstTestFailedDTC"

    def test_report_wwh_obd(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_42 = next(sf for sf in sfs if sf[0] == 0x42)
        assert sf_42[1] == "reportWWHOBDDTCByMaskRecord"

    def test_report_user_def_memory(self):
        from udsxml2tex.models import STANDARD_SUB_FUNCTIONS
        sfs = STANDARD_SUB_FUNCTIONS[0x19]
        sf_17 = next(sf for sf in sfs if sf[0] == 0x17)
        assert sf_17[1] == "reportUserDefMemoryDTCByStatusMask"


class TestDtcSeverityLevels:
    """Tests for DTC_SEVERITY_LEVELS constant (v0.17.0)."""

    def test_severity_levels_count(self):
        from udsxml2tex.models import DTC_SEVERITY_LEVELS
        assert len(DTC_SEVERITY_LEVELS) == 3

    def test_maintenance_only_byte(self):
        from udsxml2tex.models import DTC_SEVERITY_LEVELS
        entry = next(e for e in DTC_SEVERITY_LEVELS if e[1] == "DEM_SEVERITY_MAINTENANCE_ONLY")
        assert entry[0] == 0x20

    def test_check_immediately_byte(self):
        from udsxml2tex.models import DTC_SEVERITY_LEVELS
        entry = next(e for e in DTC_SEVERITY_LEVELS if e[1] == "DEM_SEVERITY_CHECK_IMMEDIATELY")
        assert entry[0] == 0x80


class TestDemTemplateV017:
    """Tests that v0.17.0 DEM features render correctly in LaTeX."""

    @pytest.fixture(autouse=True)
    def build_spec_and_tex(self):
        from udsxml2tex.dem_parser import DemParser
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_DEM)
        DemParser().parse(SAMPLE_DEM, spec)
        gen = TexGenerator()
        self.tex = gen.generate_string(spec)

    def test_dem_dtc_table_has_ff_class_column(self):
        assert "FF~Class" in self.tex

    def test_dem_dtc_table_has_edr_class_column(self):
        assert "EDR~Class" in self.tex

    def test_dem_dtc_freeze_frame_ref_rendered(self):
        assert "DemFreezeFrameClass" in self.tex

    def test_dem_dtc_extended_data_ref_rendered(self):
        assert "DemExtendedDataClass" in self.tex

    def test_dtc_status_bit_description_column(self):
        assert "Description" in self.tex
        assert "testFailed" in self.tex

    def test_dtc_severity_levels_rendered(self):
        # Severity levels only shown if severity mask is non-zero
        # For the sample DEM fixture the mask is 0, so no severity table
        # Just verify the tex has the DEM section
        assert "Diagnostic Event Manager" in self.tex


# =============================================================================
# v0.18.0 feature tests
# =============================================================================

class TestDemDtcSignificance:
    """Tests for DemDTCSignificance field parsing (v0.18.0)."""

    def test_dtc_significance_field_exists(self):
        from udsxml2tex.models import DemDtcEntry
        entry = DemDtcEntry(short_name="TestDTC")
        assert hasattr(entry, "dtc_significance")
        assert entry.dtc_significance == ""

    def test_dtc_significance_can_be_set(self):
        from udsxml2tex.models import DemDtcEntry
        entry = DemDtcEntry(
            short_name="TestDTC",
            dtc_significance="DEM_EVENT_SIGNIFICANCE_FAULT",
        )
        assert entry.dtc_significance == "DEM_EVENT_SIGNIFICANCE_FAULT"


class TestDtcGroupModel:
    """Tests for DtcGroup model (v0.18.0)."""

    def test_dtc_group_creation(self):
        from udsxml2tex.models import DtcGroup
        g = DtcGroup(short_name="AllDTCs", group_value=0xFFFFFF)
        assert g.short_name == "AllDTCs"
        assert g.group_value == 0xFFFFFF
        assert g.group_value_hex == "0xFFFFFF"

    def test_dtc_group_hex_property(self):
        from udsxml2tex.models import DtcGroup
        g = DtcGroup(short_name="EmissionDTCs", group_value=0x00FE00)
        assert g.group_value_hex == "0x00FE00"

    def test_dtc_group_in_spec(self):
        from udsxml2tex.models import DtcGroup, UdsSpecification
        spec = UdsSpecification()
        spec.dtc_groups.append(DtcGroup(short_name="AllDTCs", group_value=0xFFFFFF))
        assert len(spec.dtc_groups) == 1


class TestLinkControlBaudrateModel:
    """Tests for LinkControlBaudrateEntry model (v0.18.0)."""

    def test_baudrate_entry_creation(self):
        from udsxml2tex.models import LinkControlBaudrateEntry
        br = LinkControlBaudrateEntry(
            short_name="Baudrate_500k",
            baudrate_type="FIXED",
            baudrate_value=500000,
        )
        assert br.baudrate_type == "FIXED"
        assert br.baudrate_value == 500000

    def test_baudrate_entry_in_spec(self):
        from udsxml2tex.models import LinkControlBaudrateEntry, UdsSpecification
        spec = UdsSpecification()
        spec.link_control_baudrates.append(
            LinkControlBaudrateEntry(short_name="BR_500k", baudrate_type="FIXED", baudrate_value=500000)
        )
        assert len(spec.link_control_baudrates) == 1


class TestDemCombinedDtcModel:
    """Tests for DemCombinedDtcEntry model (v0.18.0)."""

    def test_combined_dtc_creation(self):
        from udsxml2tex.models import DemCombinedDtcEntry
        entry = DemCombinedDtcEntry(
            short_name="CombDTC_123",
            combined_dtc_value=0x123456,
            event_refs=["Event_A", "Event_B"],
        )
        assert entry.combined_dtc_value_hex == "0x123456"
        assert len(entry.event_refs) == 2

    def test_combined_dtc_in_spec(self):
        from udsxml2tex.models import DemCombinedDtcEntry, UdsSpecification
        spec = UdsSpecification()
        spec.dem_combined_dtcs.append(
            DemCombinedDtcEntry(short_name="Comb1", combined_dtc_value=0xABCDEF)
        )
        assert len(spec.dem_combined_dtcs) == 1


class TestMaxBlockLength:
    """Tests for max_block_length field (v0.18.0)."""

    def test_max_block_length_default_zero(self):
        from udsxml2tex.models import UdsSpecification
        spec = UdsSpecification()
        assert spec.max_block_length == 0

    def test_max_block_length_can_be_set(self):
        from udsxml2tex.models import UdsSpecification
        spec = UdsSpecification()
        spec.max_block_length = 4096
        assert spec.max_block_length == 4096


class TestTemplateV018:
    """Tests that v0.18.0 features render correctly in LaTeX."""

    @pytest.fixture(autouse=True)
    def build_spec_and_tex(self):
        from udsxml2tex.models import (
            DemCombinedDtcEntry,
            DemDtcEntry,
            DtcGroup,
            LinkControlBaudrateEntry,
            UdsSpecification,
        )
        spec = UdsSpecification()
        spec.max_block_length = 2048
        spec.dtc_groups.append(DtcGroup(short_name="AllDTCs_Group", group_value=0xFFFFFF))
        spec.link_control_baudrates.append(
            LinkControlBaudrateEntry(short_name="BR_500k", baudrate_type="FIXED", baudrate_value=500000)
        )
        spec.dem_combined_dtcs.append(
            DemCombinedDtcEntry(
                short_name="CombDTC_Test",
                combined_dtc_value=0x112233,
                event_refs=["EvtA", "EvtB"],
            )
        )
        spec.dem_dtcs.append(
            DemDtcEntry(
                short_name="DTC_SignifTest",
                dtc_value=0xABCDEF,
                dtc_significance="DEM_EVENT_SIGNIFICANCE_FAULT",
            )
        )
        gen = TexGenerator()
        self.tex = gen.generate_string(spec)

    def test_max_block_length_rendered(self):
        assert "2048" in self.tex

    def test_dtc_groups_table_rendered(self):
        assert "AllDTCs\\_Group" in self.tex or "AllDTCs_Group" in self.tex

    def test_link_control_baudrates_table_rendered(self):
        assert "500000" in self.tex

    def test_combined_dtc_table_rendered(self):
        assert "CombDTC\\_Test" in self.tex or "CombDTC_Test" in self.tex

    def test_dem_dtc_table_has_significance_column(self):
        assert "Significance" in self.tex


# ---------------------------------------------------------------------------
# Multi-ECU system tests
# ---------------------------------------------------------------------------


SAMPLE_SECONDARY = FIXTURES_DIR / "sample_secondary_dcm.arxml"


class TestMultiEcuModels:
    """Data-model tests for multi-ECU system support."""

    def test_routing_match_description_and_to_dict(self):
        from udsxml2tex.multi_ecu import RoutingMatch
        m = RoutingMatch(sids=[0x22, 0x2E], did_range=(0x2000, 0x2FFF))
        desc = m.description()
        assert "0x22" in desc
        assert "0x2E" in desc
        assert "0x2000" in desc
        d = m.to_dict()
        assert d["sids"] == ["0x22", "0x2E"]
        assert d["did_range"] == ["0x2000", "0x2FFF"]

    def test_routing_match_round_trip(self):
        from udsxml2tex.multi_ecu import RoutingMatch
        original = RoutingMatch(sids=[0x10, 0x11], rids=[0x203])
        d = original.to_dict()
        revived = RoutingMatch.from_dict(d)
        assert revived.sids == [0x10, 0x11]
        assert revived.rids == [0x203]

    def test_ecu_system_primary_secondary(self):
        from udsxml2tex.multi_ecu import EcuConfig, EcuRole, EcuSystem
        sys = EcuSystem(
            name="test",
            ecus={
                "p": EcuConfig(name="p", role=EcuRole.GATEWAY),
                "s": EcuConfig(name="s", role=EcuRole.ENDPOINT),
            },
        )
        assert sys.primary.name == "p"
        assert sys.secondary.name == "s"

    def test_ecu_system_to_dict_round_trip(self):
        from udsxml2tex.multi_ecu import (
            EcuConfig, EcuRole, EcuSystem, RoutingMatch, RoutingRule,
        )
        sys = EcuSystem(
            name="rt", ecus={
                "p": EcuConfig(name="p", role=EcuRole.GATEWAY),
                "s": EcuConfig(name="s", role=EcuRole.ENDPOINT),
            },
            routing_rules=[
                RoutingRule(from_ecu="p", to_ecu="s",
                            match=RoutingMatch(sids=[0x22])),
            ],
        )
        d = sys.to_dict()
        sys2 = EcuSystem.from_dict(d)
        assert sys2.name == "rt"
        assert len(sys2.ecus) == 2
        assert len(sys2.routing_rules) == 1


class TestMultiEcuLoader:
    """Loader tests using the bundled sample system YAML."""

    def setup_method(self):
        from udsxml2tex.multi_ecu import load_system_config
        self.config_path = FIXTURES_DIR / "_test_system.yaml"
        self.config_path.write_text(f"""
name: TestSystem
description: Inline test system
ecus:
  primary:
    role: gateway
    arxml_files:
      - {SAMPLE_ARXML.name}
  secondary:
    role: endpoint
    arxml_files:
      - {SAMPLE_SECONDARY.name}
routing:
  - from: primary
    to: secondary
    match:
      sids: [0x22]
      did_range: [0x2000, 0x2FFF]
    via: internal_can
topology:
  connections:
    - from: primary
      to: secondary
      medium: CAN
""", encoding="utf-8")
        self.system = load_system_config(self.config_path,
                                         parse_arxml=True,
                                         infer_routing=True)

    def teardown_method(self):
        if self.config_path.exists():
            self.config_path.unlink()

    def test_system_loaded(self):
        assert self.system.name == "TestSystem"
        assert set(self.system.ecus.keys()) == {"primary", "secondary"}

    def test_per_ecu_specs_populated(self):
        assert self.system.ecus["primary"].spec is not None
        assert self.system.ecus["secondary"].spec is not None
        # Secondary fixture has fewer DIDs than primary
        assert (len(self.system.ecus["primary"].spec.dids)
                > len(self.system.ecus["secondary"].spec.dids))

    def test_explicit_routing_rule_present(self):
        explicit = [r for r in self.system.routing_rules if not r.inferred]
        assert len(explicit) == 1
        assert explicit[0].from_ecu == "primary"
        assert explicit[0].to_ecu == "secondary"
        assert 0x22 in explicit[0].match.sids

    def test_topology_connection_present(self):
        assert len(self.system.topology.connections) == 1
        c = self.system.topology.connections[0]
        assert c.medium == "CAN"


class TestMultiEcuValidator:
    """Cross-ECU validator tests."""

    def setup_method(self):
        from udsxml2tex.multi_ecu import (
            EcuConfig, EcuRole, EcuSystem, RoutingMatch, RoutingRule,
        )
        from udsxml2tex import ArxmlParser
        primary_spec = ArxmlParser().parse(SAMPLE_ARXML)
        secondary_spec = ArxmlParser().parse(SAMPLE_SECONDARY)
        self.system = EcuSystem(
            name="vtest",
            ecus={
                "p": EcuConfig(name="p", role=EcuRole.GATEWAY,
                               spec=primary_spec),
                "s": EcuConfig(name="s", role=EcuRole.ENDPOINT,
                               spec=secondary_spec),
            },
        )
        # A rule pointing to a DID that doesn't exist on the target
        self.system.routing_rules.append(RoutingRule(
            from_ecu="p", to_ecu="s",
            match=RoutingMatch(dids=[0xDEAD]),
        ))

    def test_unknown_endpoint_raises_error(self):
        from udsxml2tex.multi_ecu import RoutingMatch, RoutingRule, validate_system
        self.system.routing_rules.append(RoutingRule(
            from_ecu="p", to_ecu="nonexistent", match=RoutingMatch(),
        ))
        result = validate_system(self.system)
        assert result.has_errors()
        assert any("nonexistent" in i.message for i in result.issues)

    def test_self_loop_is_error(self):
        from udsxml2tex.multi_ecu import RoutingMatch, RoutingRule, validate_system
        self.system.routing_rules.append(RoutingRule(
            from_ecu="p", to_ecu="p", match=RoutingMatch(),
        ))
        result = validate_system(self.system)
        assert result.has_errors()
        assert any("self-loop" in i.message.lower() for i in result.issues)

    def test_missing_target_did_is_warning(self):
        from udsxml2tex.multi_ecu import validate_system
        result = validate_system(self.system)
        assert any("0xDEAD" in i.message for i in result.issues)


class TestMultiEcuGenerator:
    """System integration document generator tests."""

    def setup_method(self):
        from udsxml2tex.multi_ecu import (
            EcuConfig, EcuRole, EcuSystem, RoutingMatch, RoutingRule,
        )
        from udsxml2tex import ArxmlParser
        primary_spec = ArxmlParser().parse(SAMPLE_ARXML)
        secondary_spec = ArxmlParser().parse(SAMPLE_SECONDARY)
        self.system = EcuSystem(
            name="docgen-test",
            ecus={
                "primary": EcuConfig(name="primary", role=EcuRole.GATEWAY,
                                     spec=primary_spec),
                "secondary": EcuConfig(name="secondary", role=EcuRole.ENDPOINT,
                                       spec=secondary_spec),
            },
            routing_rules=[
                RoutingRule(from_ecu="primary", to_ecu="secondary",
                            match=RoutingMatch(sids=[0x22, 0x2E])),
            ],
        )

    def test_markdown_contains_all_sections(self):
        from udsxml2tex.multi_ecu import generate_system_markdown
        md = generate_system_markdown(self.system)
        assert "ECU Roster" in md
        assert "Routing Matrix" in md
        assert "SID × ECU Coverage" in md
        assert "Cross-ECU Validation" in md
        assert "primary" in md
        assert "secondary" in md

    def test_html_renders_topology_svg(self):
        from udsxml2tex.multi_ecu import generate_system_html
        html = generate_system_html(self.system)
        assert "<svg" in html
        assert "primary" in html
        assert "secondary" in html

    def test_latex_compiles_top_level_envs(self):
        from udsxml2tex.multi_ecu import generate_system_latex
        tex = generate_system_latex(self.system)
        assert r"\documentclass" in tex
        assert r"\begin{document}" in tex
        assert r"\end{document}" in tex
        assert r"\begin{tikzpicture}" in tex


class TestMultiEcuVisualizations:
    """TikZ topology + sequence diagram tests."""

    def test_topology_tikz_standalone(self):
        from udsxml2tex.multi_ecu import (
            EcuConfig, EcuRole, EcuSystem, RoutingMatch, RoutingRule,
            generate_topology_tikz,
        )
        sys = EcuSystem(
            name="t", ecus={
                "g": EcuConfig(name="g", role=EcuRole.GATEWAY),
                "e": EcuConfig(name="e", role=EcuRole.ENDPOINT),
            },
            routing_rules=[
                RoutingRule(from_ecu="g", to_ecu="e",
                            match=RoutingMatch(sids=[0x22])),
            ],
        )
        out = generate_topology_tikz(sys)
        assert r"\documentclass" in out
        assert r"\begin{tikzpicture}" in out
        assert "Tester" in out


# ---------------------------------------------------------------------------
# Browser UI: chat endpoint
# ---------------------------------------------------------------------------


class TestChatEndpoint:
    """Tests for POST /parse session ID + POST /chat error/SSE behaviour."""

    def setup_method(self):
        pytest.importorskip("fastapi")
        pytest.importorskip("httpx")
        from fastapi.testclient import TestClient
        from udsxml2tex.webserver import _create_app
        self.client = TestClient(_create_app())
        with open(SAMPLE_ARXML, "rb") as f:
            resp = self.client.post(
                "/parse",
                files={"arxml_files": ("sample.arxml", f, "application/xml")},
            )
        assert resp.status_code == 200
        assert resp.json().get("success") is True
        self.session_id = resp.json()["session_id"]

    def test_parse_returns_session_id(self):
        assert isinstance(self.session_id, str) and len(self.session_id) >= 16

    def test_chat_unknown_session_returns_404(self):
        r = self.client.post("/chat", json={
            "session_id": "doesnotexist",
            "messages": [{"role": "user", "content": "hi"}],
        })
        assert r.status_code == 404
        assert "session" in r.json()["error"].lower()

    def test_chat_empty_messages_returns_400(self):
        r = self.client.post("/chat", json={
            "session_id": self.session_id,
            "messages": [],
        })
        assert r.status_code == 400

    def test_chat_first_message_must_be_user(self):
        r = self.client.post("/chat", json={
            "session_id": self.session_id,
            "messages": [{"role": "assistant", "content": "hi"}],
        })
        assert r.status_code == 400

    def test_chat_returns_sse_stream(self):
        # When anthropic SDK is unavailable, the stream emits an error event.
        # Either way we should get an event-stream response.
        r = self.client.post("/chat", json={
            "session_id": self.session_id,
            "messages": [{"role": "user", "content": "Test"}],
        })
        assert r.status_code == 200
        ct = r.headers.get("content-type", "")
        assert ct.startswith("text/event-stream")
        assert r.text.startswith("data:")


# ---------------------------------------------------------------------------
# LLM provider abstraction (Anthropic + OpenAI-compatible)
# ---------------------------------------------------------------------------


class TestLLMConfig:
    """LLMConfig dataclass + alias resolution + file loading."""

    def test_default_is_anthropic_sonnet(self):
        from udsxml2tex.llm_integration import LLMConfig
        cfg = LLMConfig()
        assert cfg.provider == "anthropic"
        assert cfg.model == "sonnet"
        assert cfg.resolved_model() == "claude-sonnet-4-6"
        assert cfg.resolved_structured_mode() == "json_schema"

    def test_openai_alias_expansion(self):
        from udsxml2tex.llm_integration import LLMConfig
        for alias, expected in [
            ("ollama",     "http://localhost:11434/v1"),
            ("llamacpp",   "http://localhost:8080/v1"),
            ("lmstudio",   "http://localhost:1234/v1"),
            ("vllm",       "http://localhost:8000/v1"),
            ("openrouter", "https://openrouter.ai/api/v1"),
            ("openai",     "https://api.openai.com/v1"),
        ]:
            cfg = LLMConfig(provider="openai", model="x", base_url=alias)
            assert cfg.resolved_base_url() == expected

    def test_openai_default_base_url_is_ollama(self):
        from udsxml2tex.llm_integration import LLMConfig
        cfg = LLMConfig(provider="openai", model="llama3.1:8b")
        assert cfg.resolved_base_url() == "http://localhost:11434/v1"

    def test_openai_passthrough_url(self):
        from udsxml2tex.llm_integration import LLMConfig
        cfg = LLMConfig(provider="openai", model="x",
                        base_url="https://example.test/v1")
        assert cfg.resolved_base_url() == "https://example.test/v1"

    def test_structured_mode_auto_per_provider(self):
        from udsxml2tex.llm_integration import LLMConfig
        assert LLMConfig(provider="anthropic").resolved_structured_mode() == "json_schema"
        assert LLMConfig(provider="openai").resolved_structured_mode() == "json_object"

    def test_from_dict_round_trip(self, tmp_path):
        from udsxml2tex.llm_integration import LLMConfig
        d = {
            "provider": "openai",
            "model": "llama3.1:8b",
            "base_url": "ollama",
            "api_key": "secret",
            "structured_mode": "json_object",
            "timeout": 90.0,
        }
        cfg = LLMConfig.from_dict(d)
        assert cfg.provider == "openai"
        assert cfg.model == "llama3.1:8b"
        assert cfg.timeout == 90.0
        # to_dict redacts the api_key
        out = cfg.to_dict()
        assert out["api_key"] == "***"

    def test_from_file_json(self, tmp_path):
        from udsxml2tex.llm_integration import LLMConfig
        p = tmp_path / "llm.json"
        p.write_text('{"provider":"openai","model":"qwen2:7b","base_url":"ollama"}',
                     encoding="utf-8")
        cfg = LLMConfig.from_file(p)
        assert cfg.provider == "openai"
        assert cfg.model == "qwen2:7b"

    def test_from_env(self, monkeypatch):
        from udsxml2tex.llm_integration import LLMConfig
        monkeypatch.setenv("UDSXML2TEX_LLM_PROVIDER", "openai")
        monkeypatch.setenv("UDSXML2TEX_LLM_MODEL", "llama3.1:8b")
        monkeypatch.setenv("UDSXML2TEX_LLM_BASE_URL", "ollama")
        cfg = LLMConfig.from_env()
        assert cfg.provider == "openai"
        assert cfg.model == "llama3.1:8b"
        assert cfg.resolved_base_url() == "http://localhost:11434/v1"


class TestLLMDispatch:
    """Verify each public function dispatches on cfg.provider correctly.

    These tests don't require either SDK to be installed: they probe the
    dispatch path before any network call. When a provider is selected
    but its SDK is missing, we expect ImportError; when an unknown
    provider is selected, ValueError.
    """

    def setup_method(self):
        from udsxml2tex import ArxmlParser
        self.spec = ArxmlParser().parse(SAMPLE_ARXML)

    def test_unknown_provider_raises(self):
        from udsxml2tex.llm_integration import LLMConfig, query_spec
        cfg = LLMConfig(provider="bogus")
        with pytest.raises(ValueError, match="bogus"):
            query_spec(self.spec, "test", config=cfg)

    def test_chat_stream_validates_messages(self):
        from udsxml2tex.llm_integration import LLMConfig, chat_stream
        cfg = LLMConfig(provider="bogus")  # never called — validation runs first
        with pytest.raises(ValueError, match="empty|user"):
            list(chat_stream(self.spec, [], config=cfg))
        with pytest.raises(ValueError, match="user"):
            list(chat_stream(self.spec,
                             [{"role": "assistant", "content": "x"}], config=cfg))

    def test_anthropic_sdk_missing_raises_importerror(self):
        from udsxml2tex.llm_integration import LLMConfig, query_spec, _import_anthropic
        # If anthropic is genuinely importable on this machine, skip — we only
        # want to verify the error path here.
        try:
            _import_anthropic()
            pytest.skip("anthropic SDK is installed; can't test missing-SDK path")
        except ImportError:
            pass
        with pytest.raises(ImportError, match="anthropic"):
            query_spec(self.spec, "test",
                       config=LLMConfig(provider="anthropic"))

    def test_openai_sdk_missing_raises_importerror(self):
        from udsxml2tex.llm_integration import LLMConfig, query_spec, _import_openai
        try:
            _import_openai()
            pytest.skip("openai SDK is installed; can't test missing-SDK path")
        except ImportError:
            pass
        with pytest.raises(ImportError, match="openai"):
            query_spec(self.spec, "test",
                       config=LLMConfig(provider="openai", model="x"))


class TestChatBackendOverrides:
    """POST /chat passes provider/base_url overrides through to LLMConfig."""

    def setup_method(self):
        pytest.importorskip("fastapi")
        pytest.importorskip("httpx")
        from fastapi.testclient import TestClient
        from udsxml2tex.webserver import _create_app
        self.client = TestClient(_create_app())
        with open(SAMPLE_ARXML, "rb") as f:
            resp = self.client.post(
                "/parse",
                files={"arxml_files": ("sample.arxml", f, "application/xml")},
            )
        self.session_id = resp.json()["session_id"]

    def test_chat_request_with_openai_override_streams_error_when_sdk_missing(self):
        # The endpoint should still return text/event-stream and surface the
        # ImportError as an SSE error event when the openai SDK isn't
        # installed.
        r = self.client.post("/chat", json={
            "session_id": self.session_id,
            "messages": [{"role": "user", "content": "hi"}],
            "provider": "openai",
            "base_url": "ollama",
            "model": "llama3.1:8b",
            "api_key": "ollama",
        })
        assert r.status_code == 200
        assert r.headers.get("content-type", "").startswith("text/event-stream")
        # Response is either an SSE error (no openai SDK) or a real stream
        # ("delta") when the dev env happens to have openai+a running ollama.
        assert "data:" in r.text


class TestOllamaSetup:
    """Pure-Python tests for the --bootstrap-ollama helper.

    Network, subprocess, and filesystem mutations are mocked. Real-world
    download and serve startup are exercised by `udsxml2tex --bootstrap-ollama`
    in dev/CI smoke tests, not here.
    """

    def test_detect_platform_linux_amd64(self, monkeypatch):
        from udsxml2tex import ollama_setup
        monkeypatch.setattr(ollama_setup.platform, "system", lambda: "Linux")
        monkeypatch.setattr(ollama_setup.platform, "machine", lambda: "x86_64")
        assert ollama_setup.detect_platform() == ("linux", "x86_64")

    def test_detect_platform_macos_arm64(self, monkeypatch):
        from udsxml2tex import ollama_setup
        monkeypatch.setattr(ollama_setup.platform, "system", lambda: "Darwin")
        monkeypatch.setattr(ollama_setup.platform, "machine", lambda: "arm64")
        assert ollama_setup.detect_platform() == ("darwin", "arm64")

    def test_detect_platform_windows_rejected(self, monkeypatch):
        from udsxml2tex import ollama_setup
        monkeypatch.setattr(ollama_setup.platform, "system", lambda: "Windows")
        with pytest.raises(RuntimeError, match="Windows"):
            ollama_setup.detect_platform()

    def test_archive_table_covers_supported_platforms(self):
        from udsxml2tex import ollama_setup
        for combo in (("linux", "x86_64"), ("linux", "aarch64"),
                      ("darwin", "x86_64"), ("darwin", "arm64")):
            assert combo in ollama_setup._ARCHIVE_BY_PLATFORM
            assert ollama_setup._ARCHIVE_BY_PLATFORM[combo].endswith(
                (".tar.zst", ".tgz")
            )

    def test_bootstrap_result_base_url(self):
        from udsxml2tex.ollama_setup import BootstrapResult
        r = BootstrapResult(
            ollama_path=__import__("pathlib").Path("/x/ollama"),
            serve_pid=None, serve_already_running=True,
            model="qwen2.5:7b", model_already_present=True,
            ctx_length=24576, host="127.0.0.1", port=11434,
        )
        assert r.base_url == "http://127.0.0.1:11434/v1"

    def test_find_ollama_returns_none_when_absent(self, monkeypatch):
        from udsxml2tex import ollama_setup
        monkeypatch.setattr(ollama_setup.shutil, "which", lambda _: None)
        assert ollama_setup.find_ollama() is None

    def test_find_ollama_returns_path_when_present(self, monkeypatch):
        from udsxml2tex import ollama_setup
        monkeypatch.setattr(
            ollama_setup.shutil, "which", lambda _: "/opt/ollama/bin/ollama"
        )
        assert ollama_setup.find_ollama() == \
            __import__("pathlib").Path("/opt/ollama/bin/ollama")

    def test_is_serve_running_false_on_connect_error(self, monkeypatch):
        from udsxml2tex import ollama_setup
        import urllib.error

        def _raise(*_a, **_kw):
            raise urllib.error.URLError("nope")

        monkeypatch.setattr(ollama_setup.urllib.request, "urlopen", _raise)
        assert ollama_setup.is_serve_running("127.0.0.1", 11434) is False

    def test_list_models_parses_api_tags(self, monkeypatch):
        from udsxml2tex import ollama_setup
        import io

        class _Resp:
            def __init__(self, body):
                self._body = body
            def __enter__(self):
                return io.BytesIO(self._body)
            def __exit__(self, *a):
                return False

        body = __import__("json").dumps(
            {"models": [{"name": "qwen2.5:7b"}, {"name": "llama3.1:8b"}]}
        ).encode()
        monkeypatch.setattr(
            ollama_setup.urllib.request, "urlopen", lambda *_a, **_kw: _Resp(body)
        )
        assert ollama_setup.list_models("127.0.0.1", 11434) == [
            "qwen2.5:7b", "llama3.1:8b"
        ]

    def test_bootstrap_idempotent_when_everything_present(self, monkeypatch):
        """Binary on PATH + serve up + model pulled → no side effects."""
        from udsxml2tex import ollama_setup
        from pathlib import Path

        monkeypatch.setattr(
            ollama_setup, "find_ollama", lambda: Path("/usr/bin/ollama")
        )
        monkeypatch.setattr(
            ollama_setup, "is_serve_running", lambda *_a, **_kw: True
        )
        monkeypatch.setattr(
            ollama_setup, "list_models", lambda *_a, **_kw: ["qwen2.5:7b"]
        )

        def _refuse(*_a, **_kw):
            raise AssertionError("should not be called when all present")

        monkeypatch.setattr(ollama_setup, "install_ollama", _refuse)
        monkeypatch.setattr(ollama_setup, "start_serve", _refuse)
        monkeypatch.setattr(ollama_setup, "pull_model", _refuse)

        result = ollama_setup.bootstrap(model="qwen2.5:7b")
        assert result.serve_already_running is True
        assert result.model_already_present is True
        assert result.serve_pid is None
        assert result.base_url == "http://127.0.0.1:11434/v1"

    def test_bootstrap_pulls_model_when_missing(self, monkeypatch):
        from udsxml2tex import ollama_setup
        from pathlib import Path

        pulled = []
        monkeypatch.setattr(
            ollama_setup, "find_ollama", lambda: Path("/usr/bin/ollama")
        )
        monkeypatch.setattr(
            ollama_setup, "is_serve_running", lambda *_a, **_kw: True
        )
        monkeypatch.setattr(
            ollama_setup, "list_models", lambda *_a, **_kw: []
        )
        monkeypatch.setattr(
            ollama_setup, "pull_model",
            lambda model, **_kw: pulled.append(model),
        )

        result = ollama_setup.bootstrap(model="qwen2.5:7b")
        assert pulled == ["qwen2.5:7b"]
        assert result.model_already_present is False


class TestSystemEndpoint:
    """POST /system: multi-ECU config + ARXML uploads → integration ZIP."""

    def setup_method(self):
        pytest.importorskip("fastapi")
        pytest.importorskip("httpx")
        pytest.importorskip("yaml")
        from fastapi.testclient import TestClient
        from udsxml2tex.webserver import _create_app
        self.client = TestClient(_create_app())
        self.samples_dir = Path(__import__("udsxml2tex").__path__[0]) / "samples"

    def _bundle_files(self):
        with open(self.samples_dir / "system_redundant.yaml", "rb") as fy:
            yaml_bytes = fy.read()
        files = [(
            "system_yaml",
            ("system_redundant.yaml", yaml_bytes, "text/yaml"),
        )]
        # 0.34.1+: bundled samples are split per-ECU as sample1_* (primary
        # / gateway) and sample2_* (secondary / endpoint). The redundant
        # YAML references all three ARXML kinds + both C scanners on each
        # side, so the multipart upload must include 6 ARXMLs and 4 C
        # files.
        for name in (
            "sample1_dcm.arxml", "sample1_cantp.arxml", "sample1_dem.arxml",
            "sample2_dcm.arxml", "sample2_cantp.arxml", "sample2_dem.arxml",
        ):
            with open(self.samples_dir / name, "rb") as f:
                files.append(
                    ("arxml_files", (name, f.read(), "application/xml"))
                )
        for name in ("sample1_did.c", "sample1_rid.c",
                     "sample2_did.c", "sample2_rid.c"):
            with open(self.samples_dir / name, "rb") as f:
                files.append(
                    ("c_files", (name, f.read(), "text/plain"))
                )
        return files

    def test_redundant_sample_round_trips_to_html_zip(self):
        r = self.client.post(
            "/system", files=self._bundle_files(), data={"format": "html"},
        )
        assert r.status_code == 200, r.text
        assert r.headers["content-type"].startswith("application/zip")
        assert 'filename="' in r.headers.get("content-disposition", "")

        import io, zipfile
        with zipfile.ZipFile(io.BytesIO(r.content)) as zf:
            names = zf.namelist()
        # 0.34.9: the response zip mirrors the single-ECU /generate HTML
        # output — it IS the browsable site, not an outer wrapper that
        # contains a nested system.zip. Earlier versions (0.34.7 / 0.34.8)
        # produced an outer zip with `system.zip` + `system_topology.tex`
        # inside, which forced users to double-unzip.
        assert "index.html" in names
        assert "assets/mermaid.min.js" in names
        assert any(n.startswith("sections/") for n in names)
        assert "system.zip" not in names
        assert "system_topology.tex" not in names

    def test_invalid_format_rejected(self):
        r = self.client.post(
            "/system", files=self._bundle_files(), data={"format": "xyz"},
        )
        assert r.status_code == 400
        assert "Unsupported format" in r.json().get("error", "")

    def test_missing_referenced_arxml_returns_400(self):
        # YAML refers to sample1_*/sample2_* but we deliberately upload only one.
        with open(self.samples_dir / "system_redundant.yaml", "rb") as fy:
            yaml_bytes = fy.read()
        with open(self.samples_dir / "sample1_dcm.arxml", "rb") as fa:
            dummy_arxml = fa.read()
        r = self.client.post(
            "/system",
            files=[
                ("system_yaml",
                 ("system_redundant.yaml", yaml_bytes, "text/yaml")),
                ("arxml_files",
                 ("only_one.arxml", dummy_arxml, "application/xml")),
            ],
            data={"format": "html"},
        )
        assert r.status_code == 400
        assert "wasn't uploaded" in r.json().get("error", "") \
            or "ARXML not found" in r.json().get("error", "")


class TestSystemEndpointPdfAndCScan:
    """0.33.0: /system gains format=pdf and c_files multipart."""

    def setup_method(self):
        pytest.importorskip("fastapi")
        pytest.importorskip("httpx")
        pytest.importorskip("yaml")
        from fastapi.testclient import TestClient
        from udsxml2tex.webserver import _create_app
        self.client = TestClient(_create_app())
        self.samples_dir = Path(__import__("udsxml2tex").__path__[0]) / "samples"

    def _bundle_with_c(self):
        files = []
        with open(self.samples_dir / "system_redundant.yaml", "rb") as f:
            files.append(("system_yaml",
                          ("system_redundant.yaml", f.read(), "text/yaml")))
        for n in ("sample1_dcm.arxml", "sample1_cantp.arxml", "sample1_dem.arxml",
                  "sample2_dcm.arxml", "sample2_cantp.arxml", "sample2_dem.arxml"):
            with open(self.samples_dir / n, "rb") as f:
                files.append(("arxml_files",
                              (n, f.read(), "application/xml")))
        for n in ("sample1_did.c", "sample1_rid.c",
                  "sample2_did.c", "sample2_rid.c"):
            with open(self.samples_dir / n, "rb") as f:
                files.append(("c_files", (n, f.read(), "text/plain")))
        return files

    def test_c_files_drive_scanner_through_to_routine_globals(self):
        """The /system response for the bundled YAML must encode C-scanner
        output: the primary ECU's Routine_0203_EraseMemory carries globals.

        Markdown output doesn't emit globals (no template support); the HTML
        and TeX templates do, so we assert against the inner HTML file.
        """
        r = self.client.post(
            "/system", files=self._bundle_with_c(), data={"format": "html"},
        )
        assert r.status_code == 200, r.text
        import io, zipfile
        # 0.34.9: the response IS the unified browsable site (no outer
        # wrapper). The primary ECU's RID (Routine_0203_*) page must
        # still surface scanner-derived globals (g_erase_memory) under
        # its "ECU: primary" sub-section.
        with zipfile.ZipFile(io.BytesIO(r.content)) as inner:
            html_names = [n for n in inner.namelist() if n.endswith(".html")]
            assert html_names, \
                f"No .html in response zip: {inner.namelist()}"
            joined = b"\n".join(inner.read(n) for n in html_names).decode(
                errors="ignore"
            )
        assert "g_erase_memory" in joined, (
            "Unified system HTML zip does not surface scanner-derived "
            "globals from sample1_rid.c — check that load_system_config "
            "ran the C scanners before generate_system_html_zip."
        )

    @pytest.mark.skipif(
        __import__("shutil").which("latexmk") is None
        and __import__("shutil").which("pdflatex") is None
        and __import__("shutil").which("xelatex") is None,
        reason="LaTeX toolchain not available",
    )
    def test_format_pdf_produces_valid_pdfs(self):
        r = self.client.post(
            "/system", files=self._bundle_with_c(), data={"format": "pdf"},
        )
        assert r.status_code == 200, r.text
        assert r.headers["content-type"].startswith("application/zip")
        import io, zipfile
        # 0.34.7: ONE unified PDF under system_unified/system.pdf
        # replaces per-ECU spec.pdf + system.pdf.
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            names = z.namelist()
            assert "system_unified/system.pdf" in names, names
            magic = z.read("system_unified/system.pdf")[:5]
            assert magic == b"%PDF-", \
                f"system_unified/system.pdf is not a real PDF (magic={magic!r})"

    def test_unknown_format_xyz_still_400(self):
        r = self.client.post(
            "/system", files=self._bundle_with_c(), data={"format": "xyz"},
        )
        assert r.status_code == 400

    def test_system_parse_returns_per_ecu_summary(self):
        """0.34.5: /system/parse mirrors /system but returns JSON only."""
        files = self._bundle_with_c()
        r = self.client.post("/system/parse", files=files)
        assert r.status_code == 200, r.text
        d = r.json()
        assert d.get("success") is True, d
        names = {e["name"] for e in d["ecus"]}
        assert names == {"primary", "secondary"}, names
        # Both ECUs have non-zero service / DID counts in the bundled sample.
        for ecu in d["ecus"]:
            assert ecu["service_count"] > 0, ecu
            assert ecu["session_count"] > 0, ecu
            assert "role" in ecu

    def test_system_parse_400_when_arxml_missing(self):
        """Missing-ARXML errors surface in the JSON, not as ZIP."""
        with open(self.samples_dir / "system_redundant.yaml", "rb") as fy:
            yaml_bytes = fy.read()
        with open(self.samples_dir / "sample1_dcm.arxml", "rb") as fa:
            r = self.client.post("/system/parse", files=[
                ("system_yaml",
                 ("system_redundant.yaml", yaml_bytes, "text/yaml")),
                ("arxml_files",
                 ("only_one.arxml", fa.read(), "application/xml")),
            ])
        assert r.status_code == 400
        d = r.json()
        assert d.get("success") is False
        assert "error" in d

    def test_cls_override_lands_in_unified_system_zip(self):
        """0.34.7: format=tex emits ONE unified system_unified/ tree
        (Option B — per-section ECU interleaving). A user-uploaded
        cls lands as `custom.cls` AND `udsspec.cls` (so the structured
        root.tex's `\\documentclass{...}` resolves) inside that tree."""
        sentinel = b"% udsxml2tex test sentinel cls\n"
        files = self._bundle_with_c() + [
            ("cls_file", ("udsspec.cls", sentinel, "text/plain")),
        ]
        r = self.client.post("/system", files=files, data={"format": "tex"})
        assert r.status_code == 200, r.text
        import io, zipfile
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            names = z.namelist()
            assert "system_unified/root.tex" in names, names
            assert "system_unified/custom.cls" in names, names
            assert z.read("system_unified/custom.cls") == sentinel, \
                "system_unified/custom.cls was not the upload"
            assert "system_unified/udsspec.cls" in names, names
            # Per-ECU interleaved sections live under ecus/<name>/.
            assert "system_unified/ecus/primary/sections/section.tex" in names
            assert "system_unified/ecus/secondary/sections/section.tex" in names

    def test_browser_synthesized_yaml_round_trips(self):
        """0.34.2: the multi-ECU UI can submit a YAML it built itself from
        per-purpose file slots. Anything PyYAML accepts must work end-to-end,
        independent of whether an explicit `system_redundant.yaml` was the
        source."""
        synth = (
            "name: BrowserGeneratedSystem\n"
            "ecus:\n"
            "  primary:\n"
            "    role: gateway\n"
            "    arxml_files:\n"
            "      - sample1_dcm.arxml\n"
            "      - sample1_cantp.arxml\n"
            "    dem_arxml: sample1_dem.arxml\n"
            "    did_c_files: [sample1_did.c]\n"
            "    rid_c_files: [sample1_rid.c]\n"
            "  secondary:\n"
            "    role: endpoint\n"
            "    arxml_files:\n"
            "      - sample2_dcm.arxml\n"
            "      - sample2_cantp.arxml\n"
            "    dem_arxml: sample2_dem.arxml\n"
            "    did_c_files: [sample2_did.c]\n"
            "    rid_c_files: [sample2_rid.c]\n"
        )
        files = [("system_yaml",
                  ("system.yaml", synth.encode(), "text/yaml"))]
        for n in ("sample1_dcm.arxml", "sample1_cantp.arxml",
                  "sample1_dem.arxml",
                  "sample2_dcm.arxml", "sample2_cantp.arxml",
                  "sample2_dem.arxml"):
            with open(self.samples_dir / n, "rb") as f:
                files.append(("arxml_files",
                              (n, f.read(), "application/xml")))
        for n in ("sample1_did.c", "sample1_rid.c",
                  "sample2_did.c", "sample2_rid.c"):
            with open(self.samples_dir / n, "rb") as f:
                files.append(("c_files",
                              (n, f.read(), "text/plain")))

        r = self.client.post("/system", files=files, data={"format": "html"})
        assert r.status_code == 200, r.text
        # Filename mirrors the YAML's `name:`.
        assert "BrowserGeneratedSystem" in r.headers.get(
            "content-disposition", ""
        )
        import io, zipfile
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            names = z.namelist()
        # 0.34.9: the response zip IS the browsable site itself
        # (no outer wrapper, no nested system.zip / system_topology.tex).
        assert "index.html" in names
        assert any(n.startswith("sections/") for n in names)


class TestEcuConfigCFiles:
    """0.33.0: EcuConfig gains did_c_files / rid_c_files round-trip."""

    def test_from_dict_resolves_paths(self):
        from udsxml2tex.multi_ecu.models import EcuConfig
        from pathlib import Path
        cfg = EcuConfig.from_dict(
            "primary",
            {
                "role": "gateway",
                "arxml_files": ["dcm.arxml"],
                "did_c_files": ["did.c", "did_extra.c"],
                "rid_c_files": ["rid.c"],
            },
            base_dir=Path("/sys/cfg"),
        )
        assert [str(p) for p in cfg.did_c_files] == [
            "/sys/cfg/did.c", "/sys/cfg/did_extra.c",
        ]
        assert [str(p) for p in cfg.rid_c_files] == ["/sys/cfg/rid.c"]

    def test_to_dict_omits_empty_c_lists(self):
        from udsxml2tex.multi_ecu.models import EcuConfig
        from pathlib import Path
        cfg = EcuConfig(name="ep", arxml_files=[Path("dcm.arxml")])
        d = cfg.to_dict()
        assert "did_c_files" not in d
        assert "rid_c_files" not in d

    def test_to_dict_includes_c_files_when_set(self):
        from udsxml2tex.multi_ecu.models import EcuConfig
        from pathlib import Path
        cfg = EcuConfig(
            name="primary",
            arxml_files=[Path("dcm.arxml")],
            did_c_files=[Path("/abs/did.c")],
            rid_c_files=[Path("/abs/rid.c")],
        )
        d = cfg.to_dict()
        assert d["did_c_files"] == ["/abs/did.c"]
        assert d["rid_c_files"] == ["/abs/rid.c"]


class TestSamplesEndpointIncludesSystemFiles:
    """The bundled redundant fileset (`system_redundant.yaml` + every
    sample1_* / sample2_* file it references) must be served by /samples so
    the browser UI's one-click bundle loader works."""

    def setup_method(self):
        pytest.importorskip("fastapi")
        pytest.importorskip("httpx")
        from fastapi.testclient import TestClient
        from udsxml2tex.webserver import _create_app
        self.client = TestClient(_create_app())

    def test_system_yaml_listed(self):
        r = self.client.get("/samples")
        assert r.status_code == 200
        names = {s["name"] for s in r.json()["samples"]}
        # YAML + the 11 per-ECU samples the redundant bundle relies on.
        for required in (
            "system_redundant.yaml",
            "sample1_dcm.arxml", "sample1_cantp.arxml", "sample1_dem.arxml",
            "sample1_did.c", "sample1_rid.c",
            "sample2_dcm.arxml", "sample2_cantp.arxml", "sample2_dem.arxml",
            "sample2_did.c", "sample2_rid.c",
        ):
            assert required in names, f"/samples missing {required!r}"

    def test_system_yaml_downloadable(self):
        r = self.client.get("/samples/system_redundant.yaml")
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/yaml")
        assert b"ExampleRedundantSystem" in r.content


class TestSafeBasename:
    """`_safe_basename` strips path components and rejects traversal."""

    def test_strips_directory_prefix(self):
        from udsxml2tex.webserver import _safe_basename
        assert _safe_basename("foo/bar.arxml", default=None) == "bar.arxml"

    def test_rejects_dotdot(self):
        from udsxml2tex.webserver import _safe_basename
        assert _safe_basename("..", default=None) is None

    def test_rejects_empty(self):
        from udsxml2tex.webserver import _safe_basename
        assert _safe_basename("", default="fallback.yaml") == "fallback.yaml"

    def test_rejects_nul_byte(self):
        from udsxml2tex.webserver import _safe_basename
        assert _safe_basename("a\x00b", default=None) is None


class TestSampleTargetsAreRenderable:
    """Every target in _SAMPLE_META must be wired to a UI loader.

    The Generate tab samples table renders Single-mode buttons for
    `primary` / `dem` / `cls` / `did_c` / `rid_c` and Multi-mode ECU1/ECU2
    pairs for `primary` / `dem` / `did_c` / `rid_c` (CLS is single-only,
    YAML is loaded via the multi-mode override field). A target outside
    these sets would render as an empty cell — the bug class fixed in
    0.32.1.
    """

    _UI_TARGETS = {"primary", "dem", "cls", "did_c", "rid_c", "system_yaml"}

    def test_every_meta_target_is_known(self):
        from udsxml2tex.webserver import _SAMPLE_META
        for name, meta in _SAMPLE_META.items():
            for t in meta.get("targets", []):
                assert t in self._UI_TARGETS, (
                    f"Sample {name!r} has unknown target {t!r}; "
                    f"wire it to web_ui.html's _SINGLE_BUTTONS / "
                    f"_MULTI_PER_ECU map, then add it here."
                )

    def test_every_meta_carries_modes(self):
        """0.34.3: `modes` (single/multi) drives mode-aware filtering."""
        from udsxml2tex.webserver import _SAMPLE_META
        for name, meta in _SAMPLE_META.items():
            modes = meta.get("modes")
            assert modes, f"Sample {name!r} missing 'modes' field"
            for m in modes:
                assert m in ("single", "multi"), (
                    f"Sample {name!r}: mode {m!r} is not 'single' or 'multi'"
                )


# =============================================================================
# Requirements Traceability Matrix (ASPICE SYS.2.BP4 / ISO 26262-8 §6.4.5)
# =============================================================================

class TestRtm:
    """RTM CSV / sources YAML parser + match-to-spec + template render."""

    def _write_csv(self, tmp_path, rows, *, header=None):
        from pathlib import Path
        header = header or "req_id,description,source_ref,traces_to,verified_by,status"
        path = Path(tmp_path) / "rtm.csv"
        path.write_text(header + "\n" + "\n".join(rows), encoding="utf-8")
        return path

    def test_csv_parses_minimal_row(self, tmp_path):
        from udsxml2tex.rtm import load_rtm_csv
        csv_path = self._write_csv(
            tmp_path,
            ['REQ-1,"Service 0x10",iso14229-1,sid:0x10,TC-1,verified'],
        )
        entries = load_rtm_csv(csv_path)
        assert len(entries) == 1
        e = entries[0]
        assert e.req_id == "REQ-1"
        assert e.status == "verified"
        assert e.source_ref == "iso14229-1"
        assert len(e.traces_to) == 1
        assert e.traces_to[0].kind == "sid"
        assert e.traces_to[0].primary == "0x10"
        assert e.traces_to[0].secondary is None

    def test_csv_parses_compound_traces(self, tmp_path):
        from udsxml2tex.rtm import load_rtm_csv
        csv_path = self._write_csv(
            tmp_path,
            ['REQ-2,"DSC + SA",iso14229-1,sid:0x10:0x03;security:0x01,,in_progress'],
        )
        entries = load_rtm_csv(csv_path)
        assert len(entries[0].traces_to) == 2
        assert entries[0].traces_to[0].kind == "sid"
        assert entries[0].traces_to[0].primary == "0x10"
        assert entries[0].traces_to[0].secondary == "0x03"
        assert entries[0].traces_to[1].kind == "security"
        assert entries[0].traces_to[1].primary == "0x01"

    def test_csv_rejects_invalid_trace_token(self, tmp_path):
        import pytest
        from udsxml2tex.rtm import load_rtm_csv
        csv_path = self._write_csv(
            tmp_path,
            ['REQ-3,Broken,iso14229-1,foo:bar,,not_yet'],
        )
        with pytest.raises(ValueError, match="Invalid traces_to"):
            load_rtm_csv(csv_path)

    def test_csv_missing_required_column(self, tmp_path):
        import pytest
        from udsxml2tex.rtm import load_rtm_csv
        path = tmp_path / "broken.csv"
        path.write_text("req_id,description\nREQ-1,foo\n", encoding="utf-8")
        with pytest.raises(ValueError, match="missing required column"):
            load_rtm_csv(path)

    def test_csv_decimal_traces_are_normalised_to_hex(self, tmp_path):
        from udsxml2tex.rtm import load_rtm_csv
        csv_path = self._write_csv(
            tmp_path,
            ['REQ-4,"Decimal",iso14229-1,sid:16,,verified'],
        )
        assert load_rtm_csv(csv_path)[0].traces_to[0].primary == "0x10"

    def test_match_to_spec_marks_resolved_when_sid_exists(self):
        from udsxml2tex.rtm import (
            RtmDocument, RtmEntry, RtmTrace, match_to_spec,
        )
        parser = ArxmlParser()
        spec = parser.parse(SAMPLE_ARXML)
        doc = RtmDocument(
            entries=[
                RtmEntry(
                    req_id="REQ-A",
                    description="...",
                    source_ref="iso14229-1",
                    traces_to=[RtmTrace(kind="sid", primary="0x10")],
                ),
                RtmEntry(
                    req_id="REQ-B",
                    description="...",
                    source_ref="iso14229-1",
                    traces_to=[RtmTrace(kind="sid", primary="0xFF")],
                ),
            ]
        )
        match_to_spec(doc, spec)
        assert doc.entries[0].resolved is True
        assert doc.entries[1].resolved is False
        assert 0.0 < doc.coverage_pct() < 100.0

    def test_sources_yaml_parses(self, tmp_path):
        pytest.importorskip("yaml")
        from udsxml2tex.rtm import load_rtm_sources
        path = tmp_path / "sources.yaml"
        path.write_text(
            "- bibkey: iso14229-1\n"
            "  title: ISO 14229-1:2020\n"
            "  publisher: ISO\n"
            "  year: 2020\n",
            encoding="utf-8",
        )
        sources = load_rtm_sources(path)
        assert sources[0].bibkey == "iso14229-1"
        assert sources[0].year == "2020"

    def test_structured_tex_zip_emits_rtm_section_when_doc_present(
        self, tmp_path
    ):
        """End-to-end: generate_structured_tex_zip(rtm=...) → rtm.tex
        contains the expected chapter heading, ASPICE / ISO 26262 / IEEE
        citations, requirement IDs, and resolved/unresolved markers.
        """
        import io
        import zipfile

        from udsxml2tex.rtm import (
            RtmDocument, RtmEntry, RtmSource, RtmTrace, match_to_spec,
        )
        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])
        doc = RtmDocument(
            entries=[
                RtmEntry(
                    req_id="REQ-RENDER-1",
                    description="DSC supported",
                    source_ref="iso14229-1",
                    traces_to=[RtmTrace(kind="sid", primary="0x10")],
                    status="verified",
                ),
                RtmEntry(
                    req_id="REQ-RENDER-2",
                    description="Future DID",
                    source_ref="iso14229-1",
                    traces_to=[RtmTrace(kind="did", primary="0xDEAD")],
                    status="in_progress",
                ),
            ],
            sources=[
                RtmSource(
                    bibkey="iso14229-1",
                    title="ISO 14229-1:2020 Road vehicles --- Unified diagnostic services (UDS)",
                    publisher="ISO",
                    year="2020",
                ),
            ],
        )
        match_to_spec(doc, spec)

        zip_path = tmp_path / "out.zip"
        TexGenerator().generate_structured_tex_zip(spec, zip_path, rtm=doc)
        with zipfile.ZipFile(zip_path) as zf:
            rtm_tex = zf.read(
                next(n for n in zf.namelist() if n.endswith("rtm.tex"))
            ).decode()

        assert "Requirements Traceability Matrix" in rtm_tex
        assert "Automotive SPICE" in rtm_tex
        assert "ISO 26262-8" in rtm_tex
        assert "29148" in rtm_tex
        assert "REQ-RENDER-1" in rtm_tex
        assert "REQ-RENDER-2" in rtm_tex
        assert "\\cite{iso14229-1}" in rtm_tex
        # Resolved row should NOT carry the * marker; unresolved one should.
        assert "REQ-RENDER-2" in rtm_tex
        assert "\\textsuperscript{*}" in rtm_tex
        # Bibliography section emitted.
        assert "thebibliography" in rtm_tex
        assert "\\bibitem{iso14229-1}" in rtm_tex

    def test_structured_tex_zip_skips_rtm_section_when_no_entries(
        self, tmp_path
    ):
        """The RTM template must produce an empty file (no chapter
        opened) when rtm is None or has no entries — otherwise
        section.tex.j2 would \\input{} an empty file but that's
        harmless; the assertion here is that no chapter heading leaks
        through.
        """
        import zipfile

        parser = ArxmlParser()
        spec = parser.parse_multi([SAMPLE_ARXML, SAMPLE_CANTP])

        zip_path = tmp_path / "out.zip"
        TexGenerator().generate_structured_tex_zip(spec, zip_path, rtm=None)
        with zipfile.ZipFile(zip_path) as zf:
            rtm_tex = zf.read(
                next(n for n in zf.namelist() if n.endswith("rtm.tex"))
            ).decode()
            section_tex = zf.read(
                next(n for n in zf.namelist() if n.endswith("section.tex"))
            ).decode()

        # The rtm.tex template renders to empty content (just newlines)
        # when rtm is falsy.
        assert "Requirements Traceability Matrix" not in rtm_tex
        # section.tex must NOT \input the RTM file when rtm has no entries.
        assert "B_rtm/rtm" not in section_tex

    def test_bundled_rtm_samples_load_and_match(self):
        """The bundled rtm_oem_sample.csv + rtm_supplier_sample.csv +
        rtm_sources_sample.yaml must parse cleanly against the bundled
        sample1_dcm/cantp/dem ARXMLs and produce a non-trivial
        coverage percentage."""
        import pathlib

        from udsxml2tex.rtm import load_rtm_document, match_to_spec
        samples = pathlib.Path("src/udsxml2tex/samples")
        # Skip when run outside the source tree.
        if not (samples / "rtm_oem_sample.csv").exists():
            pytest.skip("sample files not co-located with tests")
        parser = ArxmlParser()
        spec = parser.parse_multi([
            samples / "sample1_dcm.arxml",
            samples / "sample1_cantp.arxml",
            samples / "sample1_dem.arxml",
        ])
        doc = load_rtm_document(
            [samples / "rtm_oem_sample.csv",
             samples / "rtm_supplier_sample.csv"],
            samples / "rtm_sources_sample.yaml",
        )
        match_to_spec(doc, spec)
        assert len(doc.entries) >= 4
        assert any(e.resolved for e in doc.entries)
        # Some entries point at intentionally-missing items so coverage
        # should be strictly below 100%.
        assert 0.0 < doc.coverage_pct() < 100.0
