import logging
import os
import socket
from collections import namedtuple
from collections.abc import Callable
from functools import lru_cache

from rich.console import Console
from rich.highlighter import ReprHighlighter
from rich.theme import Theme

__all__ = ["theme", "config_tpl", "config_main", "console", "console_dict"]


@lru_cache
def get_style(
    style: str,
    LOGRICH_DEFAULT_FORMAT: str | None = None,
) -> str:
    """
    Получает стиль форматирования для логов

    Args:
        style (str): Название стиля
        LOGRICH_DEFAULT_FORMAT (Optional[str]): Формат по умолчанию

    Returns:
        str: Строка форматирования
    """
    LOGRICH_DEFAULT_FORMAT = LOGRICH_DEFAULT_FORMAT or os.environ.get(
        "LOGRICH_DEFAULT_FORMAT", "[reverse color(245)] DEF    [/]"
    )
    resp = config_tpl.get(style, LOGRICH_DEFAULT_FORMAT.strip('"'))
    return resp


config_main = namedtuple(
    "config_main",
    # ширина всего вывода
    # ширина вывода имени файла
    (
        "LGR_LOGRICH_ON",  # Условие работы логрича
        "LGR_RATIO_FILE_NAME",  # Доля ширины имени файла в общей ширине
        "LGR_LEVEL_MIN_WITH",  # Наименьшая ширина плашки
        "LGR_LEVEL_MAX_WITH",  # Наибольшая ширина плашки
        "LGR_RATIO_MESSAGE",  # Доля ширины основного сообщения в общей ширине
        "LGR_CONSOLE_WITH",  # Ширина консоли richlog
        "LGR_REDUCE_DEVIDER_LEN",  # На сколько нужно уменьшить разделитель
        "LGR_LEN_FILE_NAME_SECTION",  # Точная ширина контента колонки с именем файла
    ),
)


@lru_cache
def get_main_config() -> config_main:
    """
    Формирует объект с параметрами конфигурации логирования

    Returns:
        config_main: Именованный кортеж с параметрами конфигурации
    """

    def get_env_value(name: str, type_: Callable, default: int | str | bool) -> bool | str | int | None:
        """
        Получает значение из переменных окружения или использует значение по умолчанию

        Args:
            name (str): Название переменной окружения
            type_ (Callable): Тип данных для преобразования
            default (Union[int, str, bool]): Значение по умолчанию

        Returns:
            Union[bool, str, int, None]: Значение переменной или значение по умолчанию
        """
        try:
            val = type_(os.environ.get(name, default=default))
            return val
        except Exception as err:
            logging.warning(
                f"Ошибка в начальных параметрах: {err}\nБудет использовано значение по-умолчанию: {default}."
            )

    # Новое комплексное решение
    def get_terminal_width() -> int:
        """
        Получает ширину терминала с учётом Docker и префиксов сервиса

        Returns:
            int: Доступная ширина консоли
        """

        width = 0

        if get_env_value("LGR_DOCKER_ON", int, 0):
            # Пытаемся определить имя сервиса для расчёта префикса
            service_name = os.environ.get("HOSTNAME", socket.gethostname())

            # Префикс типа "api | " = len(service_name) + 3
            prefix_len = len(service_name) + 5

            # Или используем явное смещение
            width = max(105 - prefix_len, 85)

        return width

    # Используем новую функцию для получения ширины
    LGR_CONSOLE_WITH = get_terminal_width()

    # обновляет глобальнуб переменную COLUMNS
    if get_env_value("LGR_DOCKER_ON", int, 0):
        os.environ.setdefault("COLUMNS", str(LGR_CONSOLE_WITH))

    resp = config_main(
        # условие работы логрича
        LGR_LOGRICH_ON=get_env_value("LGR_LOGRICH_ON", int, True),
        # наибольшая ширина плашки
        LGR_LEVEL_MAX_WITH=get_env_value("LGR_LEVEL_MAX_WITH", int, 15),
        # наименьшая ширина плашки
        LGR_LEVEL_MIN_WITH=get_env_value("LGR_LEVEL_MIN_WITH", int, 9),
        # доля ширины имени файла в общей ширине
        LGR_RATIO_FILE_NAME=get_env_value("LGR_RATIO_FILE_NAME", int, 55),
        # доля ширины основного сообщения в общей ширине
        LGR_RATIO_MESSAGE=get_env_value("LGR_RATIO_MESSAGE", int, 100),
        # насколько нужно уменьшить разделитель - это прерывистая черта отделяющая
        # вывод не помещающийся в одной строке с плашкой
        LGR_REDUCE_DEVIDER_LEN=get_env_value("LGR_REDUCE_DEVIDER_LEN", int, 25),
        # ширина консоли richlog, ее можно установить менее ширины консоли
        LGR_CONSOLE_WITH=LGR_CONSOLE_WITH,
        # точная ширина контента колонки с именем файла
        LGR_LEN_FILE_NAME_SECTION=get_env_value("LGR_LEN_FILE_NAME_SECTION", int, 20),
    )

    return resp


config_tpl: dict[str, str] = dict(
    # https://rich.readthedocs.io/en/stable/appendix/colors.html
    # здесь значения по-умолчанию, для того, чтобы не загромождать
    # файл с переменными окружения
    LOG_LEVEL_ELAPCE_TPL="[reverse turquoise2] ELAPCE [/]",  # Уровень лога:.elapsed
    LOG_LEVEL_START_TPL="[reverse i aquamarine1] START  [/]",  # Уровень лога: start
    LOG_LEVEL_END_TPL="[reverse i green4] END    [/reverse i green4]",  # Уровень лога: end
    LOG_LEVEL_TEST_TPL="[reverse grey70] TEST   [/]",  # Уровень лога: test
    LOG_LEVEL_DATA_TPL="[reverse cornflower_blue] DATA   [/]",  # Уровень лога: data
    LOG_LEVEL_DEV_TPL="[reverse grey70] DEV    [/]",  # Уровень лога: dev
    LOG_LEVEL_INFO_TPL="[reverse blue] INFO   [/]",  # Уровень лога: info
    LOG_LEVEL_TRACE_TPL="[reverse dodger_blue2] TRACE  [/]",  # Уровень лога: trace
    LOG_LEVEL_RUN_TPL="[reverse yellow] RUN    [/]",  # Уровень лога: run
    LOG_LEVEL_GO_TPL="[reverse royal_blue1] GO     [/]",  # Уровень лога: go
    LOG_LEVEL_LIST_TPL="[reverse wheat4] LIST   [/]",  # Уровень лога: list
    LOG_LEVEL_DEBUG_TPL="[reverse #AB343A] DEBUG  [/]",  # Уровень лога: debug
    LOG_LEVEL_SUCCESS_TPL="[reverse green] SUCCS  [/]",  # Уровень лога: success
    LOG_LEVEL_LOG_TPL="[reverse chartreuse4] LOG    [/]",  # Уровень лога: log
    LOG_LEVEL_TIME_TPL="[reverse spring_green4] TIME   [/]",  # Уровень лога: time
    LOG_LEVEL_WARN_TPL="[reverse yellow] WARN   [/]",  # Уровень лога: warn
    LOG_LEVEL_WARNING_TPL="[reverse yellow] WARN   [/]",  # Уровень лога: warning
    LOG_LEVEL_FATAL_TPL="[reverse bright_red] FATAL  [/]",  # Уровень лога: fatal
    LOG_LEVEL_ERR_TPL="[reverse #ff5252] ERR    [/]",  # Уровень лога: err
    LOG_LEVEL_ERROR_TPL="[reverse #ff5252] ERROR  [/]",  # Уровень лога: error
    LOG_LEVEL_API_TPL="[reverse color(1)] API    [/]",
    LOG_LEVEL_APP_TPL="[reverse color(2)] APP    [/]",
    LOG_LEVEL_ARG_TPL="[reverse color(3)] ARG    [/]",
    LOG_LEVEL_ARR_TPL="[reverse color(4)] ARR    [/]",
    LOG_LEVEL_BIN_TPL="[reverse color(5)] BIN    [/]",
    LOG_LEVEL_BIT_TPL="[reverse color(6)] BIT    [/]",
    LOG_LEVEL_BUG_TPL="[reverse color(7)] BUG    [/]",
    LOG_LEVEL_BUS_TPL="[reverse color(8)] BUS    [/]",
    LOG_LEVEL_CPU_TPL="[reverse color(9)] CPU    [/]",
    LOG_LEVEL_DNS_TPL="[reverse color(10)] DNS    [/]",
    LOG_LEVEL_DOC_TPL="[reverse color(11)] DOC    [/]",
    LOG_LEVEL_ENV_TPL="[reverse color(12)] ENV    [/]",
    LOG_LEVEL_HEX_TPL="[reverse color(14)] HEX    [/]",
    LOG_LEVEL_IDE_TPL="[reverse color(15)] IDE    [/]",
    LOG_LEVEL_NPM_TPL="[reverse color(22)] NPM    [/]",
    LOG_LEVEL_OBJ_TPL="[reverse color(23)] OBJ    [/]",
    LOG_LEVEL_OPT_TPL="[reverse color(24)] OPT    [/]",
    LOG_LEVEL_POP_TPL="[reverse color(25)] POP    [/]",
    LOG_LEVEL_RAM_TPL="[reverse color(26)] RAM    [/]",
    LOG_LEVEL_RAW_TPL="[reverse color(27)] RAW    [/]",
    LOG_LEVEL_REF_TPL="[reverse color(28)] REF    [/]",
    LOG_LEVEL_REG_TPL="[reverse color(29)] REG    [/]",
    LOG_LEVEL_RES_TPL="[reverse color(30)] RES    [/]",
    LOG_LEVEL_ROW_TPL="[reverse color(31)] ROW    [/]",
    LOG_LEVEL_SET_TPL="[reverse color(32)] SET    [/]",
    LOG_LEVEL_SQL_TPL="[reverse color(33)] SQL    [/]",
    LOG_LEVEL_SUM_TPL="[reverse color(34)] SUM    [/]",
    LOG_LEVEL_TCP_TPL="[reverse color(35)] TCP    [/]",
    LOG_LEVEL_TMP_TPL="[reverse color(36)] TMP    [/]",
    LOG_LEVEL_TXT_TPL="[reverse color(37)] TXT    [/]",
    LOG_LEVEL_URL_TPL="[reverse color(38)] URL    [/]",
    LOG_LEVEL_USR_TPL="[reverse color(39)] USR    [/]",
    LOG_LEVEL_VAR_TPL="[reverse color(40)] VAR    [/]",
    LOG_LEVEL_WEB_TPL="[reverse color(41)] WEB    [/]",
    LOG_LEVEL_ZIP_TPL="[reverse color(42)] ZIP    [/]",
    LOG_LEVEL_ABS_TPL="[reverse color(43)] ABS    [/]",
    LOG_LEVEL_ACE_TPL="[reverse color(44)] ACE    [/]",
    LOG_LEVEL_ACT_TPL="[reverse color(45)] ACT    [/]",
    LOG_LEVEL_ADD_TPL="[reverse color(46)] ADD    [/]",
    LOG_LEVEL_AGE_TPL="[reverse color(47)] AGE    [/]",
    LOG_LEVEL_AID_TPL="[reverse color(48)] AID    [/]",
    LOG_LEVEL_AIR_TPL="[reverse color(49)] AIR    [/]",
    LOG_LEVEL_ALL_TPL="[reverse color(50)] ALL    [/]",
    LOG_LEVEL_AND_TPL="[reverse color(51)] AND    [/]",
    LOG_LEVEL_ANY_TPL="[reverse color(52)] ANY    [/]",
    LOG_LEVEL_ARC_TPL="[reverse color(53)] ARC    [/]",
    LOG_LEVEL_ARM_TPL="[reverse color(54)] ARM    [/]",
    LOG_LEVEL_ART_TPL="[reverse color(55)] ART    [/]",
    LOG_LEVEL_ASK_TPL="[reverse color(56)] ASK    [/]",
    LOG_LEVEL_BAD_TPL="[reverse color(57)] BAD    [/]",
    LOG_LEVEL_BAG_TPL="[reverse color(58)] BAG    [/]",
    LOG_LEVEL_BAN_TPL="[reverse color(59)] BAN    [/]",
    LOG_LEVEL_BAR_TPL="[reverse color(60)] BAR    [/]",
    LOG_LEVEL_BAT_TPL="[reverse color(61)] BAT    [/]",
    LOG_LEVEL_BED_TPL="[reverse color(62)] BED    [/]",
    LOG_LEVEL_BEE_TPL="[reverse color(63)] BEE    [/]",
    LOG_LEVEL_BIG_TPL="[reverse color(64)] BIG    [/]",
    LOG_LEVEL_BOX_TPL="[reverse color(65)] BOX    [/]",
    LOG_LEVEL_BOY_TPL="[reverse color(66)] BOY    [/]",
    LOG_LEVEL_BUD_TPL="[reverse color(67)] BUD    [/]",
    LOG_LEVEL_BUT_TPL="[reverse color(68)] BUT    [/]",
    LOG_LEVEL_BYE_TPL="[reverse color(69)] BYE    [/]",
    LOG_LEVEL_CAB_TPL="[reverse color(70)] CAB    [/]",
    LOG_LEVEL_CAP_TPL="[reverse color(71)] CAP    [/]",
    LOG_LEVEL_CAR_TPL="[reverse color(72)] CAR    [/]",
    LOG_LEVEL_CAT_TPL="[reverse color(73)] CAT    [/]",
    LOG_LEVEL_CUP_TPL="[reverse color(74)] CUP    [/]",
    LOG_LEVEL_DAY_TPL="[reverse color(75)] DAY    [/]",
    LOG_LEVEL_DID_TPL="[reverse color(76)] DID    [/]",
    LOG_LEVEL_DIE_TPL="[reverse color(77)] DIE    [/]",
    LOG_LEVEL_DIG_TPL="[reverse color(78)] DIG    [/]",
    LOG_LEVEL_DIM_TPL="[reverse color(79)] DIM    [/]",
    LOG_LEVEL_DOG_TPL="[reverse color(80)] DOG    [/]",
    LOG_LEVEL_DOT_TPL="[reverse color(81)] DOT    [/]",
    LOG_LEVEL_DRY_TPL="[reverse color(82)] DRY    [/]",
    LOG_LEVEL_EAR_TPL="[reverse color(83)] EAR    [/]",
    LOG_LEVEL_EAT_TPL="[reverse color(84)] EAT    [/]",
    LOG_LEVEL_EGG_TPL="[reverse color(85)] EGG    [/]",
    LOG_LEVEL_ERA_TPL="[reverse color(86)] ERA    [/]",
    LOG_LEVEL_EVE_TPL="[reverse color(87)] EVE    [/]",
    LOG_LEVEL_FAB_TPL="[reverse color(88)] FAB    [/]",
    LOG_LEVEL_FAN_TPL="[reverse color(89)] FAN    [/]",
    LOG_LEVEL_FAR_TPL="[reverse color(90)] FAR    [/]",
    LOG_LEVEL_FAT_TPL="[reverse color(91)] FAT    [/]",
    LOG_LEVEL_FAX_TPL="[reverse color(92)] FAX    [/]",
    LOG_LEVEL_FEE_TPL="[reverse color(93)] FEE    [/]",
    LOG_LEVEL_FIG_TPL="[reverse color(94)] FIG    [/]",
    LOG_LEVEL_FIN_TPL="[reverse color(95)] FIN    [/]",
    LOG_LEVEL_FIT_TPL="[reverse color(96)] FIT    [/]",
    LOG_LEVEL_FIX_TPL="[reverse color(97)] FIX    [/]",
    LOG_LEVEL_FLY_TPL="[reverse color(98)] FLY    [/]",
    LOG_LEVEL_FOG_TPL="[reverse color(99)] FOG    [/]",
    LOG_LEVEL_FOX_TPL="[reverse color(100)] FOX    [/]",
    LOG_LEVEL_FUN_TPL="[reverse color(101)] FUN    [/]",
    LOG_LEVEL_GAP_TPL="[reverse color(102)] GAP    [/]",
    LOG_LEVEL_GAS_TPL="[reverse color(103)] GAS    [/]",
    LOG_LEVEL_GEM_TPL="[reverse color(104)] GEM    [/]",
    LOG_LEVEL_GET_TPL="[reverse color(105)] GET    [/]",
    LOG_LEVEL_GUN_TPL="[reverse color(106)] GUN    [/]",
    LOG_LEVEL_GUY_TPL="[reverse color(107)] GUY    [/]",
    LOG_LEVEL_HAD_TPL="[reverse color(108)] HAD    [/]",
    LOG_LEVEL_HAS_TPL="[reverse color(109)] HAS    [/]",
    LOG_LEVEL_HAT_TPL="[reverse color(110)] HAT    [/]",
    LOG_LEVEL_HIM_TPL="[reverse color(111)] HIM    [/]",
    LOG_LEVEL_HIT_TPL="[reverse color(112)] HIT    [/]",
    LOG_LEVEL_HOP_TPL="[reverse color(113)] HOP    [/]",
    LOG_LEVEL_HOT_TPL="[reverse color(114)] HOT    [/]",
    LOG_LEVEL_ICE_TPL="[reverse color(115)] ICE    [/]",
    LOG_LEVEL_INK_TPL="[reverse color(116)] INK    [/]",
    LOG_LEVEL_ITS_TPL="[reverse color(117)] ITS    [/]",
    LOG_LEVEL_JAM_TPL="[reverse color(118)] JAM    [/]",
    LOG_LEVEL_JAW_TPL="[reverse color(119)] JAW    [/]",
    LOG_LEVEL_JET_TPL="[reverse color(120)] JET    [/]",
    LOG_LEVEL_JOB_TPL="[reverse color(121)] JOB    [/]",
    LOG_LEVEL_JOY_TPL="[reverse color(122)] JOY    [/]",
    LOG_LEVEL_KID_TPL="[reverse color(123)] KID    [/]",
    LOG_LEVEL_KIT_TPL="[reverse color(124)] KIT    [/]",
    LOG_LEVEL_LAB_TPL="[reverse color(125)] LAB    [/]",
    LOG_LEVEL_LAP_TPL="[reverse color(126)] LAP    [/]",
    LOG_LEVEL_LAW_TPL="[reverse color(127)] LAW    [/]",
    LOG_LEVEL_LED_TPL="[reverse color(128)] LED    [/]",
    LOG_LEVEL_LET_TPL="[reverse color(129)] LET    [/]",
    LOG_LEVEL_LOT_TPL="[reverse color(130)] LOT    [/]",
    LOG_LEVEL_MAN_TPL="[reverse color(131)] MAN    [/]",
    LOG_LEVEL_MAY_TPL="[reverse color(132)] MAY    [/]",
    LOG_LEVEL_MEN_TPL="[reverse color(133)] MEN    [/]",
    LOG_LEVEL_MIX_TPL="[reverse color(134)] MIX    [/]",
    LOG_LEVEL_MOB_TPL="[reverse color(135)] MOB    [/]",
    LOG_LEVEL_MOD_TPL="[reverse color(136)] MOD    [/]",
    LOG_LEVEL_NOW_TPL="[reverse color(137)] NOW    [/]",
    LOG_LEVEL_ODD_TPL="[reverse color(138)] ODD    [/]",
    LOG_LEVEL_OFF_TPL="[reverse color(139)] OFF    [/]",
    LOG_LEVEL_OLD_TPL="[reverse color(140)] OLD    [/]",
    LOG_LEVEL_ONE_TPL="[reverse color(141)] ONE    [/]",
    LOG_LEVEL_OUR_TPL="[reverse color(142)] OUR    [/]",
    LOG_LEVEL_OUT_TPL="[reverse color(143)] OUT    [/]",
    LOG_LEVEL_OWN_TPL="[reverse color(144)] OWN    [/]",
    LOG_LEVEL_PAD_TPL="[reverse color(145)] PAD    [/]",
    LOG_LEVEL_PAN_TPL="[reverse color(146)] PAN    [/]",
    LOG_LEVEL_PAY_TPL="[reverse color(147)] PAY    [/]",
    LOG_LEVEL_POD_TPL="[reverse color(148)] POD    [/]",
    LOG_LEVEL_PRO_TPL="[reverse color(149)] PRO    [/]",
    LOG_LEVEL_PUB_TPL="[reverse color(150)] PUB    [/]",
    LOG_LEVEL_RAG_TPL="[reverse color(151)] RAG    [/]",
    LOG_LEVEL_RAY_TPL="[reverse color(152)] RAY    [/]",
    LOG_LEVEL_RUB_TPL="[reverse color(153)] RUB    [/]",
    LOG_LEVEL_SAD_TPL="[reverse color(154)] SAD    [/]",
    LOG_LEVEL_SAY_TPL="[reverse color(155)] SAY    [/]",
    LOG_LEVEL_SEA_TPL="[reverse color(156)] SEA    [/]",
    LOG_LEVEL_SEE_TPL="[reverse color(157)] SEE    [/]",
    LOG_LEVEL_SIX_TPL="[reverse color(158)] SIX    [/]",
    LOG_LEVEL_SKY_TPL="[reverse color(159)] SKY    [/]",
    LOG_LEVEL_SPY_TPL="[reverse color(160)] SPY    [/]",
    LOG_LEVEL_SUB_TPL="[reverse color(161)] SUB    [/]",
    LOG_LEVEL_SUN_TPL="[reverse color(162)] SUN    [/]",
    LOG_LEVEL_TAB_TPL="[reverse color(163)] TAB    [/]",
    LOG_LEVEL_TAG_TPL="[reverse color(164)] TAG    [/]",
    LOG_LEVEL_TIP_TPL="[reverse color(165)] TIP    [/]",
    LOG_LEVEL_TOO_TPL="[reverse color(166)] TOO    [/]",
    LOG_LEVEL_TOP_TPL="[reverse color(167)] TOP    [/]",
    LOG_LEVEL_USE_TPL="[reverse color(168)] USE    [/]",
    LOG_LEVEL_WAS_TPL="[reverse color(169)] WAS    [/]",
    LOG_LEVEL_WAY_TPL="[reverse color(170)] WAY    [/]",
    LOG_LEVEL_WIN_TPL="[reverse color(171)] WIN    [/]",
    LOG_LEVEL_KEY_TPL="[reverse color(172)] KEY    [/]",
    LOG_LEVEL_LIB_TPL="[reverse color(173)] LIB    [/]",
    LOG_LEVEL_MAP_TPL="[reverse color(174)] MAP    [/]",
    LOG_LEVEL_MAX_TPL="[reverse color(175)] MAX    [/]",
    LOG_LEVEL_MIN_TPL="[reverse color(176)] MIN    [/]",
    LOG_LEVEL_NET_TPL="[reverse color(177)] NET    [/]",
)

config_tpl.update(
    **os.environ,  # override loaded values with environment variables
)

color_of_digit = "bold magenta"

theme: Theme = Theme(
    # https://www.w3schools.com/colors/colors_picker.asp
    # https://htmlcolorcodes.com/color-names/
    # https://colorscheme.ru/
    {
        "repr.brace": "bold black",  # Фигурные скобки в repr
        "repr.str": "green",  # Строки в repr
        "repr.attrib_name": "#0099ff",  # Имена атрибутов в repr
        "repr.equal": "red dim",  # Знак равенства в repr
        "repr.digit": color_of_digit,  # Цифры в repr
        "repr.digit2": color_of_digit,  # Цифры в repr (второй стиль)
        "repr.colon": "#D2691E",  # Двоеточия в repr
        "repr.quotes": "#778899",  # Кавычки в repr
        "repr.comma": "#778899",  # Запятые в repr
        "repr.key": "#08e8de",  # Ключи в repr
        "repr.bool_true": "bold blue",  # Логические значения True в repr
        "repr.none": "blue",  # None в repr
        "repr.bool_false": "yellow",  # Логические значения False в repr
        "repr.class_name": "magenta bold",  # Имена классов в repr
        "repr.string_list_tuple": "green",  # Строки в списках/кортежах
        "trace_msg": "#05a7f7",  # Сообщения трассировки
        "debug_msg": "#e64d00",  # Сообщения отладки
        "info_msg": "#33ccff",  # Информационные сообщения
        "success_msg": "green",  # Сообщения об успехе
        "warning_msg": "yellow",  # Предупреждения
        "error_msg": "#ff5050",  # Ошибки
        "critical_msg": "#de0b2e",  # Критические ошибки
    },
)


def combine_regex(*regexes: str) -> str:
    """
    Объединяет несколько регулярных выражений в одно

    Args:
        *regexes (str): Регулярные выражения для объединения

    Returns:
        str: Новое регулярное выражение с объединенными 패ternами
    """
    return "|".join(regexes)


class MyReprHighlighter(ReprHighlighter):
    """
    Подсветка вывода на основе регулярных выражений

    Этот класс наследуется от ReprHighlighter и определяет правила подсветки
    различных элементов при выводе repr() объектов.
    """

    # https://regex101.com/r/zR2hP5/1
    base_style = "repr."
    highlights = [
        r"'(?P<str>[\S\s]*)'",
        r":\s\'(?P<value>.+)\'",
        r"['](?P<string_list_tuple>\w+)[']",
        r"(?P<digit2>\d*)[\"\s,[,(](?P<digit>\d*\.?\s?-?\d*-?\.?\d+)",
        combine_regex(
            r"(?P<brace>[][{}()])",  # noqa
            r"\'(?P<key>[\w-]+)\'(?P<colon>:)",
            r"(?P<comma>,)\s",
        ),
        r"(?P<quotes>\')",
        r"(?P<equal>=)",  # noqa
        r"(?P<class_name>[A-Z].*)\(",
        r'(?P<attrib_name>[\w_]{1,50})=(?P<attrib_value>"?[\w_]+"?)?',
        r"\b(?P<bool_true>True)\b|\b(?P<bool_false>False)\b|\b(?P<none>None)\b",
    ]


console: Console = Console()

# инстанс консоли rich
console_dict: Console = Console(
    highlighter=MyReprHighlighter(),
    theme=theme,
    markup=True,
    log_time=False,
    log_path=False,
    safe_box=True,
)
