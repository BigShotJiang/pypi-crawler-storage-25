# Competition Submission Cheat Sheet / 大赛提交参考

Copy-paste these into the submission form.

---

## MCP 名称 (Name)

```
doc-translator / 文档翻译
```

## 描述 (Description)

```
文档翻译 MCP — 翻译 PPTX、PDF、DOCX、XLSX 文档，保持原始排版格式不变，并支持通过 Gemini 自动翻译图片中的文字。支持任意语言对（中英、法日等），文本翻译由用户自己的 LLM 完成，无需额外 API Key。

Document Translator MCP — translate PPTX, PDF, DOCX, XLSX documents preserving layout. Optional Gemini image translation. Any language pair, no API key needed for text.
```

## 连接方式 (Connection Method)

Select: **STDIO**

## 服务配置 (Service Config JSON)

```json
{
  "mcpServers": {
    "doc-translator": {
      "command": "uvx",
      "args": ["doc-translator-mcp"],
      "env": {
        "GEMINI_API_KEY": "<optional-google-ai-api-key>"
      }
    }
  }
}
```

## 使用说明 (Usage Instructions)

```
1. 添加上面的 MCP 配置到你的 AI 客户端（Cursor、CodeBuddy、Claude Desktop 等）
2. 告诉 AI："请帮我翻译这个文档" 并提供文件路径
3. AI 自动提取文本 → 翻译 → 重建文档，保持原始排版
4. PPTX 中有文字的图片也会自动翻译（需要 GEMINI_API_KEY）
5. 翻译结果保存在原文件旁，后缀为 _translated
6. 支持任意语言对："翻译成法语"、"translate to Japanese"

1. Add the config above to your AI client (Cursor, CodeBuddy, Claude Desktop, etc.)
2. Tell the AI: "Translate this document" with the file path
3. AI extracts text → translates → rebuilds, preserving layout
4. Images with text in PPTX are also translated (requires GEMINI_API_KEY)
5. Output saved next to original with _translated suffix
6. Any language pair: "translate to French", "翻译成日语"
```

## 工具说明 (Tool Instructions)

```
extract_document - 从文档中提取所有可翻译的文本块
Extract all translatable text blocks from a document.

extract_images - 从 PPTX 中提取图片，智能过滤图标和重复图片
Extract images from PPTX with smart filtering.

translate_images - 使用 Gemini 自动翻译图片中的文字
Translate text in images using Gemini (requires GEMINI_API_KEY).

rebuild_document - 用翻译后的文本和图片重建文档，保持原始排版
Rebuild document with translations, preserving original layout.

list_supported_formats - 列出支持的格式和工作流程
List supported formats and recommended workflow.
```

## 标签 (Tags)

```
翻译, 文档处理, PPTX, PDF, DOCX, XLSX, 多语言, AI翻译, 图片翻译
```

## 赛题主题 (Competition Theme)

Select: **效率工具** (Efficiency Tools)

---

## Checklist

- [x] Published to PyPI: https://pypi.org/project/doc-translator-mcp/
- [x] `uvx doc-translator-mcp` works out of the box
- [x] STDIO mode — direct file access, any file size
- [x] GEMINI_API_KEY optional
- [x] Bilingual README
- [ ] Logo image (512x512 PNG)
- [ ] Submit on competition platform
