"""DOCX extraction and rebuild — preserves all formatting, styles, and images."""

from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.shared import Pt


def extract_docx(file_path: Path) -> list[dict]:
    """Extract all text blocks from a DOCX file."""
    doc = Document(str(file_path))
    blocks: list[dict] = []

    # Body paragraphs
    for para_idx, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        if not text:
            continue

        style_name = para.style.name if para.style else "Normal"
        block_id = f"para_{para_idx}"
        blocks.append({
            "id": block_id,
            "text": text,
            "context": f"Paragraph {para_idx + 1} (style: {style_name})",
        })

    # Tables
    for tbl_idx, table in enumerate(doc.tables):
        for row_idx, row in enumerate(table.rows):
            for col_idx, cell in enumerate(row.cells):
                cell_text = cell.text.strip()
                if not cell_text:
                    continue
                block_id = f"tbl{tbl_idx}_r{row_idx}_c{col_idx}"
                blocks.append({
                    "id": block_id,
                    "text": cell_text,
                    "context": f"Table {tbl_idx + 1}, row {row_idx + 1} col {col_idx + 1}",
                })

    # Headers and footers
    for section_idx, section in enumerate(doc.sections):
        for hf_type, hf_obj in [
            ("header", section.header),
            ("footer", section.footer),
        ]:
            if not hf_obj or not hf_obj.paragraphs:
                continue
            for para_idx, para in enumerate(hf_obj.paragraphs):
                text = para.text.strip()
                if not text:
                    continue
                block_id = f"sec{section_idx}_{hf_type}_p{para_idx}"
                blocks.append({
                    "id": block_id,
                    "text": text,
                    "context": f"Section {section_idx + 1} {hf_type}, paragraph {para_idx + 1}",
                })

    return blocks


def rebuild_docx(
    source: Path,
    output: Path,
    translations: dict[str, str],
    summary: str,
):
    """Rebuild a DOCX with translated text, preserving formatting."""
    doc = Document(str(source))

    # Body paragraphs
    for para_idx, para in enumerate(doc.paragraphs):
        block_id = f"para_{para_idx}"
        if block_id not in translations:
            continue
        _replace_paragraph_text(para, translations[block_id])

    # Tables
    for tbl_idx, table in enumerate(doc.tables):
        for row_idx, row in enumerate(table.rows):
            for col_idx, cell in enumerate(row.cells):
                block_id = f"tbl{tbl_idx}_r{row_idx}_c{col_idx}"
                if block_id not in translations:
                    continue
                for para in cell.paragraphs:
                    _replace_paragraph_text(para, translations[block_id])
                    break

    # Headers and footers
    for section_idx, section in enumerate(doc.sections):
        for hf_type, hf_obj in [
            ("header", section.header),
            ("footer", section.footer),
        ]:
            if not hf_obj or not hf_obj.paragraphs:
                continue
            for para_idx, para in enumerate(hf_obj.paragraphs):
                block_id = f"sec{section_idx}_{hf_type}_p{para_idx}"
                if block_id not in translations:
                    continue
                _replace_paragraph_text(para, translations[block_id])

    # Insert summary at the beginning
    if summary:
        _insert_summary(doc, summary)

    doc.save(str(output))


def _insert_summary(doc: Document, summary: str):
    """Insert a summary section at the very beginning of the document."""
    # We insert paragraphs in reverse order at position 0
    from docx.oxml.ns import qn

    body = doc.element.body
    first_element = body[0] if len(body) > 0 else None

    # Create separator paragraph
    sep_para = doc.add_paragraph()
    sep_para.add_run("─" * 50)
    sep_element = sep_para._element
    body.remove(sep_element)
    if first_element is not None:
        first_element.addprevious(sep_element)

    # Create summary body
    summary_para = doc.add_paragraph()
    run = summary_para.add_run(summary)
    run.font.size = Pt(11)
    summary_element = summary_para._element
    body.remove(summary_element)
    if first_element is not None:
        first_element.addprevious(summary_element)

    # Create summary title
    title_para = doc.add_paragraph()
    title_run = title_para.add_run("Translation Summary")
    title_run.bold = True
    title_run.font.size = Pt(16)
    title_element = title_para._element
    body.remove(title_element)
    if first_element is not None:
        first_element.addprevious(title_element)


def _replace_paragraph_text(para, new_text: str):
    """Replace paragraph text while preserving the first run's formatting."""
    if not para.runs:
        para.text = new_text
        return

    first_run = para.runs[0]
    for run in para.runs[1:]:
        run._element.getparent().remove(run._element)
    first_run.text = new_text
