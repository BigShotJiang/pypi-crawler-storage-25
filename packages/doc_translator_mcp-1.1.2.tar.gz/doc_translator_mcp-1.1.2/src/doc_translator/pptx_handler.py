"""PPTX extraction and rebuild — preserves all formatting, shapes, and images."""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.util import Pt, Inches, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN


# ---------------------------------------------------------------------------
# Extraction
# ---------------------------------------------------------------------------

def extract_pptx(file_path: Path) -> list[dict]:
    """Extract all text blocks from a PPTX file with structural IDs."""
    prs = Presentation(str(file_path))
    blocks: list[dict] = []

    for slide_idx, slide in enumerate(prs.slides, start=1):
        _extract_shapes(slide.shapes, slide_idx, blocks)

    return blocks


MIN_IMAGE_BYTES = 5_000
MAX_ICON_LABEL_LEN = 20


def extract_pptx_images(file_path: Path, output_dir: Path) -> list[dict]:
    """Extract translatable images from a PPTX, saving them to output_dir.

    Filters out:
    - Tiny icons/decorations (< 5KB)
    - Labeled icons (image + short text label in the same small group)
    - Duplicate images (same blob reused across slides)

    Returns list of {id, file_path, slide, context} for each image.
    """
    prs = Presentation(str(file_path))
    output_dir.mkdir(parents=True, exist_ok=True)
    images: list[dict] = []
    seen_blobs: dict[int, str] = {}

    for slide_idx, slide in enumerate(prs.slides, start=1):
        _extract_images_from_shapes(
            slide.shapes, slide_idx, output_dir, images, seen_blobs,
            group_prefix="", parent_shapes=None,
        )

    return images


def _is_labeled_icon(shape, parent_shapes) -> bool:
    """A picture is a labeled icon if its parent group is small and contains
    a sibling text element with a short label (e.g. 'QQ', '微信', '钉钉')."""
    if parent_shapes is None:
        return False
    try:
        count = len(list(parent_shapes))
    except TypeError:
        return False
    if count > 5:
        return False
    for sibling in parent_shapes:
        if sibling is shape:
            continue
        text = _get_short_text(sibling)
        if text and 0 < len(text) <= MAX_ICON_LABEL_LEN:
            return True
    return False


def _get_short_text(shape) -> str | None:
    """Return stripped text from a shape or its immediate children."""
    if shape.has_text_frame:
        t = shape.text_frame.text.strip()
        if t:
            return t
    if shape.shape_type == 6:  # GROUP — check one level down
        for child in shape.shapes:
            if child.has_text_frame:
                t = child.text_frame.text.strip()
                if t:
                    return t
    return None


def _extract_images_from_shapes(
    shapes, slide_idx: int, output_dir: Path, images: list[dict],
    seen_blobs: dict[int, str], group_prefix: str = "",
    parent_shapes=None,
):
    for shape_idx, shape in enumerate(shapes):
        prefix = f"{group_prefix}sh{shape_idx}"

        if shape.shape_type == 13:  # PICTURE
            try:
                img = shape.image
                blob = img.blob
                if len(blob) < MIN_IMAGE_BYTES:
                    continue
                if _is_labeled_icon(shape, parent_shapes):
                    continue

                blob_hash = hash(blob)
                img_id = f"s{slide_idx}_{prefix}_img"

                if blob_hash in seen_blobs:
                    images.append({
                        "id": img_id,
                        "file_path": images[
                            next(i for i, x in enumerate(images)
                                 if x["id"] == seen_blobs[blob_hash])
                        ]["file_path"],
                        "slide": slide_idx,
                        "context": f"Slide {slide_idx}, image '{shape.name}' (duplicate of {seen_blobs[blob_hash]})",
                        "shape_index": shape_idx,
                        "duplicate_of": seen_blobs[blob_hash],
                    })
                    continue

                ext = img.content_type.split("/")[-1].replace("jpeg", "jpg")
                fname = f"{img_id}.{ext}"
                out_path = output_dir / fname
                out_path.write_bytes(blob)
                seen_blobs[blob_hash] = img_id
                images.append({
                    "id": img_id,
                    "file_path": str(out_path),
                    "slide": slide_idx,
                    "context": f"Slide {slide_idx}, image '{shape.name}'",
                    "shape_index": shape_idx,
                })
            except (ValueError, AttributeError):
                pass

        if shape.shape_type == 6:  # GROUP
            _extract_images_from_shapes(
                shape.shapes, slide_idx, output_dir, images, seen_blobs,
                group_prefix=f"{prefix}_g_", parent_shapes=shapes,
            )


def _extract_shapes(shapes, slide_idx: int, blocks: list[dict], group_prefix: str = ""):
    """Recursively extract text from shapes, including groups and tables."""
    for shape_idx, shape in enumerate(shapes):
        prefix = f"{group_prefix}sh{shape_idx}"

        if shape.has_text_frame:
            shape_name = shape.name or f"shape_{shape_idx}"
            for para_idx, para in enumerate(shape.text_frame.paragraphs):
                full_text = para.text.strip()
                if not full_text:
                    continue
                block_id = f"s{slide_idx}_{prefix}_p{para_idx}"
                blocks.append({
                    "id": block_id,
                    "text": full_text,
                    "context": f"Slide {slide_idx}, {shape_name}, paragraph {para_idx + 1}",
                })

        if shape.has_table:
            table = shape.table
            shape_name = shape.name or f"shape_{shape_idx}"
            for row_idx, row in enumerate(table.rows):
                for col_idx, cell in enumerate(row.cells):
                    cell_text = cell.text.strip()
                    if not cell_text:
                        continue
                    block_id = f"s{slide_idx}_{prefix}_tbl_r{row_idx}_c{col_idx}"
                    blocks.append({
                        "id": block_id,
                        "text": cell_text,
                        "context": f"Slide {slide_idx}, table in {shape_name}, row {row_idx + 1} col {col_idx + 1}",
                    })

        if shape.shape_type == 6:  # GROUP
            _extract_shapes(shape.shapes, slide_idx, blocks, group_prefix=f"{prefix}_g_")


# ---------------------------------------------------------------------------
# Rebuild
# ---------------------------------------------------------------------------

def rebuild_pptx(
    source: Path,
    output: Path,
    translations: dict[str, str],
    summary: str,
    image_replacements: dict[str, str] | None = None,
    image_annotations: dict[str, str] | None = None,
):
    """Rebuild a PPTX with translated text, replaced images, and/or annotations."""
    prs = Presentation(str(source))
    originals = _collect_originals(prs)

    annotation_targets: list[tuple] = []

    for slide_idx, slide in enumerate(prs.slides, start=1):
        _rebuild_shapes(slide.shapes, slide_idx, translations, originals,
                        image_replacements)
        if image_annotations:
            _collect_annotation_targets(
                slide.shapes, slide, slide_idx, image_annotations,
                annotation_targets,
            )

    for slide, shape, text in annotation_targets:
        _add_annotation_box(slide, shape, text)

    if summary:
        _add_summary_slide(prs, summary)

    prs.save(str(output))


def _rebuild_shapes(shapes, slide_idx: int, translations: dict[str, str],
                    originals: dict[str, str],
                    image_replacements: dict[str, str] | None = None,
                    group_prefix: str = ""):
    """Recursively replace text and images in shapes."""
    for shape_idx, shape in enumerate(shapes):
        prefix = f"{group_prefix}sh{shape_idx}"

        if shape.has_text_frame:
            for para_idx, para in enumerate(shape.text_frame.paragraphs):
                block_id = f"s{slide_idx}_{prefix}_p{para_idx}"
                if block_id not in translations:
                    continue
                new_text = translations[block_id]
                orig_text = originals.get(block_id, "")
                _replace_paragraph_text(para, new_text, orig_text)

        if shape.has_table:
            table = shape.table
            for row_idx, row in enumerate(table.rows):
                for col_idx, cell in enumerate(row.cells):
                    block_id = f"s{slide_idx}_{prefix}_tbl_r{row_idx}_c{col_idx}"
                    if block_id not in translations:
                        continue
                    _replace_cell_text(cell, translations[block_id])

        if shape.shape_type == 13 and image_replacements:  # PICTURE
            img_id = f"s{slide_idx}_{prefix}_img"
            if img_id in image_replacements:
                _replace_image(shape, image_replacements[img_id])

        if shape.shape_type == 6:  # GROUP
            _rebuild_shapes(shape.shapes, slide_idx, translations, originals,
                            image_replacements, group_prefix=f"{prefix}_g_")


def _replace_image(shape, new_image_path: str):
    """Replace a picture shape's image with a new file."""
    new_path = Path(new_image_path)
    if not new_path.exists():
        return

    try:
        img_blob = new_path.read_bytes()

        ext = new_path.suffix.lower()
        content_types = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".webp": "image/webp",
        }
        content_type = content_types.get(ext, "image/png")

        blip = shape._element.find(
            './/{http://schemas.openxmlformats.org/drawingml/2006/main}blip'
        )
        if blip is None:
            return

        embed_key = blip.get(
            '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed'
        )
        if not embed_key:
            return

        rel = shape.part.rels[embed_key]
        image_part_obj = rel.target_part
        image_part_obj._blob = img_blob
        image_part_obj.content_type = content_type
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Tier 1: Image annotations (caption boxes beside images)
# ---------------------------------------------------------------------------

def _collect_annotation_targets(
    shapes, slide, slide_idx: int,
    annotations: dict[str, str],
    targets: list[tuple],
    group_prefix: str = "",
):
    """Find image shapes that have annotations and collect them for captioning."""
    for shape_idx, shape in enumerate(shapes):
        prefix = f"{group_prefix}sh{shape_idx}"
        if shape.shape_type == 13:  # PICTURE
            img_id = f"s{slide_idx}_{prefix}_img"
            if img_id in annotations:
                targets.append((slide, shape, annotations[img_id]))
        if shape.shape_type == 6:  # GROUP
            _collect_annotation_targets(
                shape.shapes, slide, slide_idx, annotations, targets,
                group_prefix=f"{prefix}_g_",
            )


def _add_annotation_box(slide, image_shape, text: str):
    """Add a caption box below an image shape with translated text."""
    img_left = image_shape.left
    img_top = image_shape.top
    img_width = image_shape.width
    img_height = image_shape.height

    slide_width = Inches(10)
    slide_height = Inches(7.5)

    box_height = Inches(0.8)
    box_top = img_top + img_height + Emu(36000)  # small gap

    if box_top + box_height > slide_height:
        box_top = img_top - box_height - Emu(36000)
        if box_top < 0:
            box_top = img_top + img_height - box_height

    box_left = img_left
    box_width = img_width
    if box_width < Inches(2):
        box_width = min(Inches(4), slide_width - box_left)

    txBox = slide.shapes.add_textbox(box_left, box_top, box_width, box_height)
    tf = txBox.text_frame
    tf.word_wrap = True

    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(9)
    p.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
    p.font.italic = True

    fill = txBox.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(0xF0, 0xF4, 0xFF)

    line = txBox.line
    line.color.rgb = RGBColor(0xAA, 0xBB, 0xDD)
    line.width = Pt(0.5)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _add_summary_slide(prs: Presentation, summary: str):
    """Insert a summary slide at the beginning of the presentation."""
    layout = prs.slide_layouts[1]

    slide = prs.slides.add_slide(layout)
    slide_element = prs.slides._sldIdLst[-1]
    prs.slides._sldIdLst.remove(slide_element)
    prs.slides._sldIdLst.insert(0, slide_element)

    for shape in slide.placeholders:
        if shape.placeholder_format.idx == 0:
            shape.text = "Translation Summary"
        elif shape.placeholder_format.idx == 1:
            shape.text = summary
            for para in shape.text_frame.paragraphs:
                for run in para.runs:
                    run.font.size = Pt(14)


def _collect_originals(prs: Presentation) -> dict[str, str]:
    result = {}
    for slide_idx, slide in enumerate(prs.slides, start=1):
        _collect_shapes(slide.shapes, slide_idx, result)
    return result


def _collect_shapes(shapes, slide_idx: int, result: dict, group_prefix: str = ""):
    for shape_idx, shape in enumerate(shapes):
        prefix = f"{group_prefix}sh{shape_idx}"
        if shape.has_text_frame:
            for para_idx, para in enumerate(shape.text_frame.paragraphs):
                t = para.text.strip()
                if t:
                    result[f"s{slide_idx}_{prefix}_p{para_idx}"] = t
        if shape.shape_type == 6:
            _collect_shapes(shape.shapes, slide_idx, result, group_prefix=f"{prefix}_g_")


def _replace_cell_text(cell, new_text: str):
    """Replace all text in a table cell, removing extra paragraphs."""
    paras = cell.text_frame.paragraphs
    if not paras:
        return
    _replace_paragraph_text(paras[0], new_text, "")
    for para in list(paras[1:]):
        p_elem = para._p
        p_elem.getparent().remove(p_elem)


def _replace_paragraph_text(para, new_text: str, orig_text: str):
    """Replace paragraph text, scaling font size down if translation is longer."""
    if not para.runs:
        para.text = new_text
        return

    first_run = para.runs[0]
    orig_size = first_run.font.size

    for run in para.runs[1:]:
        run._r.getparent().remove(run._r)

    first_run.text = new_text

    if orig_size and orig_text and new_text:
        ratio = len(new_text) / max(len(orig_text), 1)
        if ratio > 1.3:
            scale = min(1.0, 1.0 / (ratio * 0.85))
            scale = max(scale, 0.5)
            new_size = int(orig_size * scale)
            first_run.font.size = new_size
