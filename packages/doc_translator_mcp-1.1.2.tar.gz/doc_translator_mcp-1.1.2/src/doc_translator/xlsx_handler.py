"""XLSX extraction and rebuild — preserves formatting, formulas, and structure."""

from __future__ import annotations

from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


def extract_xlsx(file_path: Path) -> list[dict]:
    """Extract all text cells from an XLSX file."""
    wb = load_workbook(str(file_path), data_only=False)
    blocks: list[dict] = []

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None:
                    continue
                # Skip formulas and pure numbers
                val = cell.value
                if isinstance(val, (int, float)):
                    continue
                val_str = str(val).strip()
                if not val_str:
                    continue

                col_letter = get_column_letter(cell.column)
                block_id = f"ws_{sheet_name}_r{cell.row}_c{cell.column}"
                blocks.append({
                    "id": block_id,
                    "text": val_str,
                    "context": f"Sheet '{sheet_name}', cell {col_letter}{cell.row}",
                })

    wb.close()
    return blocks


def rebuild_xlsx(
    source: Path,
    output: Path,
    translations: dict[str, str],
    summary: str,
):
    """Rebuild an XLSX with translated text, preserving formatting."""
    wb = load_workbook(str(source))

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None:
                    continue
                block_id = f"ws_{sheet_name}_r{cell.row}_c{cell.column}"
                if block_id in translations:
                    cell.value = translations[block_id]

    if summary:
        _add_summary_sheet(wb, summary)

    wb.save(str(output))
    wb.close()


def _add_summary_sheet(wb, summary: str):
    """Insert a 'Translation Summary' sheet at the beginning of the workbook."""
    ws = wb.create_sheet("Translation Summary", 0)

    ws["A1"] = "Translation Summary"
    ws["A1"].font = ws["A1"].font.copy(bold=True, size=16)
    ws.column_dimensions["A"].width = 100

    for row_idx, line in enumerate(summary.split("\n"), start=3):
        ws.cell(row=row_idx, column=1, value=line)
