"""PDF extraction and rebuild — overlays translated text preserving visual layout."""

from __future__ import annotations

from pathlib import Path

import fitz  # PyMuPDF


def extract_pdf(file_path: Path) -> list[dict]:
    """Extract text blocks from a PDF with positional metadata."""
    doc = fitz.open(str(file_path))
    blocks: list[dict] = []

    for page_idx, page in enumerate(doc, start=1):
        text_dict = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)

        for block_idx, block in enumerate(text_dict["blocks"]):
            if block["type"] != 0:  # text block
                continue

            for line_idx, line in enumerate(block["lines"]):
                line_text = ""
                for span in line["spans"]:
                    line_text += span["text"]

                line_text = line_text.strip()
                if not line_text:
                    continue

                block_id = f"p{page_idx}_b{block_idx}_l{line_idx}"
                blocks.append({
                    "id": block_id,
                    "text": line_text,
                    "context": f"Page {page_idx}, block {block_idx + 1}, line {line_idx + 1}",
                })

    doc.close()
    return blocks


def _add_summary_page(doc: fitz.Document, summary: str):
    """Insert a summary page at the beginning of the PDF."""
    first_page = doc[0]
    w, h = first_page.rect.width, first_page.rect.height

    summary_page = doc.new_page(pno=0, width=w, height=h)

    # Title
    title_rect = fitz.Rect(50, 40, w - 50, 90)
    summary_page.insert_textbox(
        title_rect,
        "Translation Summary",
        fontsize=20,
        fontname="helv",
        color=(0, 0, 0),
        align=fitz.TEXT_ALIGN_CENTER,
    )

    # Summary body
    body_rect = fitz.Rect(50, 100, w - 50, h - 50)
    summary_page.insert_textbox(
        body_rect,
        summary,
        fontsize=11,
        fontname="helv",
        color=(0.1, 0.1, 0.1),
        align=fitz.TEXT_ALIGN_LEFT,
    )


def rebuild_pdf(
    source: Path,
    output: Path,
    translations: dict[str, str],
    summary: str,
):
    """Rebuild a PDF by placing translated text over the original with matching backgrounds."""
    doc = fitz.open(str(source))

    for page_idx, page in enumerate(doc, start=1):
        text_dict = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)

        for block_idx, block in enumerate(text_dict["blocks"]):
            if block["type"] != 0:
                continue

            for line_idx, line in enumerate(block["lines"]):
                block_id = f"p{page_idx}_b{block_idx}_l{line_idx}"
                if block_id not in translations:
                    continue

                new_text = translations[block_id]
                spans = line["spans"]
                if not spans:
                    continue

                first_span = spans[0]
                last_span = spans[-1]

                x0 = first_span["bbox"][0]
                y0 = min(s["bbox"][1] for s in spans)
                x1 = last_span["bbox"][2]
                y1 = max(s["bbox"][3] for s in spans)
                rect = fitz.Rect(x0, y0, x1, y1)

                fontsize = first_span["size"]
                color = _normalize_color(first_span.get("color", 0))

                bg_color = _sample_bg_color(page, rect)

                # Cover original text with a background-matched rectangle
                page.draw_rect(rect, color=bg_color, fill=bg_color)

                # Place translated text directly — use insert_text at the
                # baseline position for reliable rendering
                baseline_y = y1 - (y1 - y0) * 0.2  # approximate baseline
                fitted_size = _fit_fontsize(new_text, fontsize, rect.width)

                page.insert_text(
                    fitz.Point(x0, baseline_y),
                    new_text,
                    fontsize=fitted_size,
                    fontname="helv",
                    color=color,
                )

    if summary:
        _add_summary_page(doc, summary)

    doc.save(str(output), garbage=4, deflate=True)
    doc.close()


def _normalize_color(color_int: int) -> tuple[float, float, float]:
    """Convert an integer color value to an RGB tuple (0-1 range)."""
    if isinstance(color_int, (list, tuple)):
        return tuple(c / 255.0 for c in color_int[:3])
    r = ((color_int >> 16) & 0xFF) / 255.0
    g = ((color_int >> 8) & 0xFF) / 255.0
    b = (color_int & 0xFF) / 255.0
    return (r, g, b)


def _luminance(color: tuple[float, float, float]) -> float:
    return 0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2]


def _fit_fontsize(text: str, original_size: float, available_width: float) -> float:
    """Shrink font size if translated text is wider than available space."""
    avg_char_width = original_size * 0.5
    estimated_width = len(text) * avg_char_width
    if estimated_width <= available_width:
        return original_size
    ratio = available_width / estimated_width
    return max(original_size * ratio, 5.0)


def _sample_bg_color(
    page: fitz.Page, rect: fitz.Rect
) -> tuple[float, float, float]:
    """Sample the background color behind a text rect by rendering a small pixmap."""
    try:
        # Render a small area around the rect (without text layer)
        clip = fitz.Rect(rect.x0, rect.y0, rect.x0 + 2, rect.y0 + 2)
        pix = page.get_pixmap(clip=clip, dpi=72)
        # Sample the pixel at (0,0) — should be the background
        pixel = pix.pixel(0, 0)
        return (pixel[0] / 255.0, pixel[1] / 255.0, pixel[2] / 255.0)
    except Exception:
        return (1.0, 1.0, 1.0)  # fallback to white
