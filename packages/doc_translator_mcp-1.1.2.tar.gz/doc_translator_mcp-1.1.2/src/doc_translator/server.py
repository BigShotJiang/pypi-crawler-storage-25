#!/usr/bin/env python3
"""
doc-translator-mcp: MCP server for extracting text from documents and
rebuilding them with translations while preserving the original layout.

Supported formats: PPTX, PDF, DOCX, XLSX

Runs locally via STDIO transport — the LLM passes file paths directly.
"""

import json
import os
import time
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from doc_translator.pptx_handler import (
    extract_pptx, rebuild_pptx, extract_pptx_images,
)
from doc_translator.pdf_handler import extract_pdf, rebuild_pdf
from doc_translator.docx_handler import extract_docx, rebuild_docx
from doc_translator.xlsx_handler import extract_xlsx, rebuild_xlsx

mcp = FastMCP(
    "doc-translator",
    instructions=(
        "Translate documents (PPTX, PDF, DOCX, XLSX) preserving original layout.\n\n"
        "Workflow (only 2 steps needed):\n"
        "1. extract_document(file_path) → get text blocks with IDs\n"
        "2. Translate all text blocks yourself, then call rebuild_document\n"
        "   with the translations JSON. Images are handled AUTOMATICALLY —\n"
        "   if GEMINI_API_KEY is configured, rebuild_document translates\n"
        "   images via Gemini without any extra steps.\n\n"
        "The server runs locally and has direct access to the user's filesystem.\n"
        "Best results with Claude. Other LLMs may work but are less tested."
    ),
)

EXTRACTORS = {
    ".pptx": extract_pptx,
    ".pdf": extract_pdf,
    ".docx": extract_docx,
    ".xlsx": extract_xlsx,
}

BUILDERS = {
    ".pptx": rebuild_pptx,
    ".pdf": rebuild_pdf,
    ".docx": rebuild_docx,
    ".xlsx": rebuild_xlsx,
}

IMAGE_EXTRACTORS = {
    ".pptx": extract_pptx_images,
}

SUPPORTED_EXTENSIONS = set(EXTRACTORS.keys())


def _resolve_path(file_path: str) -> Path:
    p = Path(file_path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"File not found: {p}")
    return p


def _get_extension(p: Path) -> str:
    ext = p.suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise ValueError(
            f"Unsupported file type '{ext}'. Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )
    return ext


# ---------------------------------------------------------------------------
# Core tools
# ---------------------------------------------------------------------------

@mcp.tool()
def extract_document(file_path: str) -> str:
    """Extract all translatable text blocks from a document.

    Supported formats: PPTX, PDF, DOCX, XLSX.

    Args:
        file_path: Absolute path to the document on disk.

    Returns JSON with text_blocks — each has id, text, and context.
    Pass the returned file_path to subsequent tools.
    """
    p = _resolve_path(file_path)
    ext = _get_extension(p)
    blocks = EXTRACTORS[ext](p)
    return json.dumps(
        {
            "file_path": str(p),
            "file_type": ext,
            "total_text_blocks": len(blocks),
            "text_blocks": blocks,
        },
        ensure_ascii=False,
        indent=2,
    )


def _get_image_mode() -> str:
    if os.environ.get("GEMINI_API_KEY"):
        return "full"
    return "annotate"


@mcp.tool()
def extract_images(file_path: str, output_dir: str = "") -> str:
    """Extract all images from a document for inspection or translation.

    Currently supports PPTX only.

    Args:
        file_path: Absolute path to the document.
        output_dir: Directory to save extracted images (auto-generated if empty).

    Returns JSON with image metadata, mode, and guidance on next steps.
    """
    p = _resolve_path(file_path)
    ext = _get_extension(p)

    if ext not in IMAGE_EXTRACTORS:
        return json.dumps({
            "error": f"Image extraction not supported for {ext}",
            "supported": list(IMAGE_EXTRACTORS.keys()),
        })

    if not output_dir:
        output_dir = str(p.parent / f"{p.stem}_images")

    out = Path(output_dir)
    images = IMAGE_EXTRACTORS[ext](p, out)

    mode = _get_image_mode()

    if mode == "full":
        guidance = (
            "GEMINI_API_KEY available. Call translate_images to automatically "
            "translate all images with embedded text. Pass the returned "
            "image_replacements to rebuild_document."
        )
    else:
        guidance = (
            "No GEMINI_API_KEY configured — automatic image translation is disabled.\n"
            "To enable it, add a Google AI API key to your MCP config:\n\n"
            '  "env": { "GEMINI_API_KEY": "<your-google-ai-api-key>" }\n\n'
            "Get a free key at https://aistudio.google.com/apikey\n\n"
            "Without a key, you can view the images yourself and pass "
            "image_annotations to rebuild_document to add caption boxes: "
            '{"image_id": "English translation of text in image", ...}'
        )

    return json.dumps(
        {
            "file_path": str(p),
            "output_dir": str(out),
            "total_images": len(images),
            "images": images,
            "mode": mode,
            "guidance": guidance,
        },
        ensure_ascii=False,
        indent=2,
    )


@mcp.tool()
def translate_images(
    file_path: str,
    target_language: str = "",
    source_language: str = "",
    output_dir: str = "",
    gemini_api_key: str = "",
    gemini_model: str = "gemini-3.1-flash-image-preview",
) -> str:
    """Translate text within images using Gemini's multimodal image generation.

    Requires a GEMINI_API_KEY (set via env var or pass directly).

    Args:
        file_path: Absolute path to the document.
        target_language: Language to translate to (default: English).
        source_language: Language to translate from (auto-detected if empty).
        output_dir: Directory for extracted/translated images.
        gemini_api_key: Google AI API key. Falls back to GEMINI_API_KEY env var.
        gemini_model: Gemini model to use.

    Returns JSON with image_replacements mapping ready for rebuild_document.
    """
    try:
        from google import genai
        from google.genai import types as genai_types
    except ImportError:
        return json.dumps({
            "error": "google-genai package not installed. Run: pip install google-genai",
        })

    api_key = gemini_api_key or os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        return json.dumps({
            "error": (
                "No Google AI API key found. Add GEMINI_API_KEY to your MCP config:\n\n"
                '  "env": { "GEMINI_API_KEY": "<your-google-ai-api-key>" }\n\n'
                "Get a free key at https://aistudio.google.com/apikey"
            ),
        })

    p = _resolve_path(file_path)
    ext = _get_extension(p)

    if ext not in IMAGE_EXTRACTORS:
        return json.dumps({
            "error": f"Image extraction not supported for {ext}",
            "supported": list(IMAGE_EXTRACTORS.keys()),
        })

    if not output_dir:
        output_dir = str(p.parent / f"{p.stem}_images")

    out_dir = Path(output_dir)
    translated_dir = out_dir / "translated"
    translated_dir.mkdir(parents=True, exist_ok=True)

    images = IMAGE_EXTRACTORS[ext](p, out_dir)
    if not images:
        return json.dumps({"message": "No images found in document.", "image_replacements": {}})

    client = genai.Client(api_key=api_key)

    if target_language and source_language:
        prompt = f"Translate all {source_language} text in this image to {target_language}. Keep the layout, colors, and design identical."
    elif target_language:
        prompt = f"Create a {target_language} version of this image. Translate all text. Keep the layout, colors, and design identical."
    else:
        prompt = "Create an English version of this image. Translate all text. Keep the layout, colors, and design identical."

    replacements = {}
    results = []

    for img_info in images:
        img_id = img_info["id"]
        img_path = Path(img_info["file_path"])

        if not img_path.exists():
            results.append({"id": img_id, "status": "skipped", "reason": "file not found"})
            continue

        try:
            img_bytes = img_path.read_bytes()

            response = client.models.generate_content(
                model=gemini_model,
                contents=[
                    prompt,
                    genai_types.Part.from_bytes(data=img_bytes, mime_type="image/png"),
                ],
                config=genai_types.GenerateContentConfig(
                    response_modalities=["Image", "Text"],
                ),
            )

            saved = False
            if response.candidates:
                for part in response.candidates[0].content.parts:
                    if (part.inline_data
                            and part.inline_data.mime_type
                            and part.inline_data.mime_type.startswith("image/")):
                        out_path = translated_dir / f"{img_id}_translated.png"
                        out_path.write_bytes(part.inline_data.data)
                        replacements[img_id] = str(out_path)
                        results.append({
                            "id": img_id,
                            "status": "translated",
                            "output": str(out_path),
                            "size_kb": len(part.inline_data.data) // 1024,
                        })
                        saved = True
                        break

            if not saved:
                results.append({"id": img_id, "status": "failed", "reason": "no image in response"})

        except Exception as e:
            results.append({"id": img_id, "status": "error", "reason": str(e)})

        time.sleep(1)

    return json.dumps(
        {
            "total_images": len(images),
            "translated": len(replacements),
            "failed": len(images) - len(replacements),
            "results": results,
            "image_replacements": replacements,
            "usage_hint": (
                "Pass the image_replacements object directly to "
                "rebuild_document's image_replacements parameter."
            ),
        },
        ensure_ascii=False,
        indent=2,
    )


def _auto_translate_images(
    file_path: Path,
    target_language: str = "English",
) -> tuple[dict[str, str], list[dict], str]:
    """Automatically extract and translate images if GEMINI_API_KEY is set.

    Returns (replacements_dict, results_list, message).
    """
    ext = file_path.suffix.lower()
    if ext not in IMAGE_EXTRACTORS:
        return {}, [], ""

    api_key = os.environ.get("GEMINI_API_KEY", "")
    if not api_key:
        images = IMAGE_EXTRACTORS[ext](file_path, file_path.parent / f"{file_path.stem}_images")
        has_images = len(images) > 0
        if has_images:
            return {}, [], (
                f"Found {len(images)} images with potential text, but GEMINI_API_KEY "
                "is not configured so images were NOT translated. "
                "To enable automatic image translation, add to your MCP config:\n\n"
                '  "env": { "GEMINI_API_KEY": "<your-google-ai-api-key>" }\n\n'
                "Get a free key at https://aistudio.google.com/apikey"
            )
        return {}, [], ""

    try:
        from google import genai
        from google.genai import types as genai_types
    except ImportError:
        return {}, [], "google-genai not installed — images not translated."

    out_dir = file_path.parent / f"{file_path.stem}_images"
    translated_dir = out_dir / "translated"
    translated_dir.mkdir(parents=True, exist_ok=True)

    images = IMAGE_EXTRACTORS[ext](file_path, out_dir)
    if not images:
        return {}, [], ""

    client = genai.Client(api_key=api_key)
    prompt = f"Create an {target_language} version of this image. Translate all text. Keep the layout, colors, and design identical."

    replacements = {}
    results = []

    for img_info in images:
        img_id = img_info["id"]
        img_path = Path(img_info["file_path"])
        if not img_path.exists():
            results.append({"id": img_id, "status": "skipped"})
            continue
        try:
            response = client.models.generate_content(
                model="gemini-2.0-flash-exp",
                contents=[
                    prompt,
                    genai_types.Part.from_bytes(
                        data=img_path.read_bytes(), mime_type="image/png",
                    ),
                ],
                config=genai_types.GenerateContentConfig(
                    response_modalities=["Image", "Text"],
                ),
            )
            saved = False
            if response.candidates:
                for part in response.candidates[0].content.parts:
                    if (part.inline_data
                            and part.inline_data.mime_type
                            and part.inline_data.mime_type.startswith("image/")):
                        out_path = translated_dir / f"{img_id}_translated.png"
                        out_path.write_bytes(part.inline_data.data)
                        replacements[img_id] = str(out_path)
                        results.append({"id": img_id, "status": "translated"})
                        saved = True
                        break
            if not saved:
                results.append({"id": img_id, "status": "failed"})
        except Exception as e:
            results.append({"id": img_id, "status": "error", "reason": str(e)})
        time.sleep(1)

    msg = f"Auto-translated {len(replacements)}/{len(images)} images via Gemini."
    return replacements, results, msg


@mcp.tool()
def rebuild_document(
    source_file_path: str,
    translations: str,
    target_language: str = "English",
    summary: str = "",
    output_file_path: str = "",
    image_replacements: str = "",
    image_annotations: str = "",
) -> str:
    """Rebuild a document with translated text. Images are handled automatically.

    For PPTX files: if GEMINI_API_KEY is configured, images containing text
    are automatically translated via Gemini — no extra steps needed.
    If no API key, the output will include a message suggesting the user add one.

    Args:
        source_file_path: Path to the original document.
        translations: JSON string mapping text_block IDs to translated strings.
                      Example: {"s1_sh0_p0": "Translated title", ...}
        target_language: Target language for image translation (default: English).
        summary: Optional summary text to insert as the first page/sheet.
        output_file_path: Optional output path. Defaults to
                          '<original_name>_translated.<ext>' next to the original.
        image_replacements: Pre-computed image replacements (skips auto-translation).
        image_annotations: JSON mapping image IDs to caption text.

    Returns JSON with output path and image translation results.
    """
    p = _resolve_path(source_file_path)
    ext = _get_extension(p)

    trans_map: dict[str, str] = json.loads(translations)

    img_map: dict[str, str] | None = None
    auto_image_msg = ""
    auto_image_results: list[dict] = []

    if image_replacements:
        img_map = json.loads(image_replacements)
    elif ext in IMAGE_EXTRACTORS:
        auto_map, auto_image_results, auto_image_msg = _auto_translate_images(
            p, target_language,
        )
        if auto_map:
            img_map = auto_map

    ann_map: dict[str, str] | None = None
    if image_annotations:
        ann_map = json.loads(image_annotations)

    if not output_file_path:
        output_file_path = str(p.with_stem(p.stem + "_translated"))

    out = Path(output_file_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    builder = BUILDERS[ext]
    if ext == ".pptx":
        builder(p, out, trans_map, summary,
                image_replacements=img_map, image_annotations=ann_map)
    else:
        builder(p, out, trans_map, summary)

    replaced_count = len(img_map) if img_map else 0
    annotated_count = len(ann_map) if ann_map else 0

    parts = [f"Translated {len(trans_map)} text blocks."]
    if replaced_count:
        parts.append(f"Replaced {replaced_count} images with translated versions.")
    if annotated_count:
        parts.append(f"Added {annotated_count} image annotations.")

    if auto_image_msg:
        parts.append("")
        parts.append("⚠️ IMAGE WARNING — PLEASE TELL THE USER:")
        parts.append(auto_image_msg)

    result = {
        "message": " ".join(parts[:3]) if not auto_image_msg else "\n".join(parts),
        "output_file": str(out),
        "translated_blocks": len(trans_map),
        "replaced_images": replaced_count,
        "annotated_images": annotated_count,
    }

    if auto_image_results:
        result["image_details"] = auto_image_results

    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
def list_supported_formats() -> str:
    """List supported document formats, image translation mode, and workflow."""
    mode = _get_image_mode()
    return json.dumps(
        {
            "supported_formats": [
                {"extension": ".pptx", "name": "PowerPoint", "image_translation": mode},
                {"extension": ".pdf", "name": "PDF", "image_translation": "none"},
                {"extension": ".docx", "name": "Word", "image_translation": "none"},
                {"extension": ".xlsx", "name": "Excel", "image_translation": "none"},
            ],
            "image_translation_mode": mode,
            "workflow": [
                "1. extract_document(file_path) → get text blocks with IDs",
                "2. Translate all text blocks yourself",
                "3. rebuild_document(file_path, translations) → done! Images auto-translated if GEMINI_API_KEY is set",
            ],
            "gemini_api_key_configured": mode == "full",
        },
        indent=2,
    )


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
