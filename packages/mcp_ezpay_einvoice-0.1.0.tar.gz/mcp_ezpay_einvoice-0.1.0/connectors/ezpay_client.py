"""ezPay e-invoice API connector.

Handles the encrypted form POST protocol:
1. Inject common fields (RespondType, Version, TimeStamp)
2. AES-256-CBC encrypt all params into PostData_
3. HTTP POST as application/x-www-form-urlencoded
4. Parse and return JSON response
"""

import time
import json
import requests

from config.settings import MERCHANT_ID, HASH_KEY, HASH_IV, get_url, get_version
from auth.ezpay_crypto import encrypt_post_data


class EzPayAPIError(Exception):
    """Error returned by the ezPay API."""

    def __init__(self, status: str, message: str):
        self.status = status
        self.message = message
        super().__init__(f"ezPay API error [{status}]: {message}")


def ezpay_post(endpoint_key: str, post_data: dict) -> dict:
    """Send encrypted POST request to ezPay API.

    Args:
        endpoint_key: Key from ENDPOINTS dict (e.g., "invoice_issue").
        post_data: Parameters for the API call (will be encrypted).

    Returns:
        Parsed response dict with keys: status, message, result.

    Raises:
        EzPayAPIError: If the API returns a non-SUCCESS status.
        ValueError: If credentials are not configured.
    """
    if not all([MERCHANT_ID, HASH_KEY, HASH_IV]):
        raise ValueError(
            "Missing ezPay credentials. Set EZPAY_MERCHANT_ID, "
            "EZPAY_HASH_KEY, and EZPAY_HASH_IV environment variables."
        )

    # Inject common fields
    post_data["RespondType"] = "JSON"
    post_data["Version"] = get_version(endpoint_key)
    post_data["TimeStamp"] = str(int(time.time()))

    # Encrypt
    encrypted = encrypt_post_data(post_data, HASH_KEY, HASH_IV)

    # POST
    url = get_url(endpoint_key)
    form_data = {
        "MerchantID_": MERCHANT_ID,
        "PostData_": encrypted,
    }

    response = requests.post(url, data=form_data, timeout=30)
    response.raise_for_status()

    resp_json = response.json()

    status = resp_json.get("Status", "")
    message = resp_json.get("Message", "")
    result_raw = resp_json.get("Result", "")

    # Parse Result if it's a JSON string
    result = result_raw
    if isinstance(result_raw, str) and result_raw:
        try:
            result = json.loads(result_raw)
        except (json.JSONDecodeError, TypeError):
            result = result_raw

    return {
        "status": status,
        "message": message,
        "result": result,
    }
