#!/usr/bin/env python3
"""E2E test runner for all ezPay e-invoice MCP tools.

Tests each tool against the ezPay test environment.
Requires valid test credentials in environment variables.

Usage:
    EZPAY_MERCHANT_ID=xxx EZPAY_HASH_KEY=xxx EZPAY_HASH_IV=xxx python tests/test_all_tools.py
"""

import sys
import os
import asyncio
import traceback
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tools.invoice_tools  # noqa: F401
from app import mcp

results = []


def run_test(name: str, fn, **kwargs):
    """Run a single tool test and record the result."""
    print(f"\n{'=' * 60}")
    print(f"TEST: {name}")
    print(f"{'=' * 60}")
    try:
        result = fn(**kwargs)
        status = result.get("status", "UNKNOWN")
        message = result.get("message", "")
        print(f"  API Status: {status}")
        print(f"  Message: {message}")
        if isinstance(result.get("result"), dict):
            for key, value in result["result"].items():
                preview = str(value)
                if len(preview) > 100:
                    preview = preview[:100] + "..."
                print(f"    {key}: {preview}")
        results.append(("PASS", name, status))
    except Exception as e:
        print(f"  FAIL: {e}")
        traceback.print_exc()
        results.append(("FAIL", name, str(e)))


def main():
    # Verify tool registration
    tools_list = asyncio.run(mcp.list_tools())
    print(f"Registered tools: {len(tools_list)}")
    for tool in tools_list:
        print(f"  - {tool.name}: {tool.description[:80] if tool.description else 'no description'}")

    print(f"\n{'#' * 60}")
    print(f"RUNNING E2E TESTS")
    print(f"{'#' * 60}")

    order_no = f"TEST{int(time.time())}"

    # Test 1: Issue a B2C invoice
    run_test("issue_invoice (B2C)", tools.invoice_tools.issue_invoice,
        merchant_order_no=order_no,
        buyer_name="Test Buyer",
        category="B2C",
        tax_type="1",
        tax_rate=5,
        amt=100,
        tax_amt=5,
        total_amt=105,
        item_name="Test Product",
        item_count="1",
        item_unit="pc",
        item_price="105",
        item_amt="105",
        print_flag="Y",
        status="1",
    )

    # Test 2: Query the invoice we just issued
    run_test("query_invoice (by order)", tools.invoice_tools.query_invoice,
        search_type="1",
        merchant_order_no=order_no,
        total_amt=105,
    )

    # Test 3: Void invoice (expected error - dummy number)
    run_test("void_invoice (expected error)", tools.invoice_tools.void_invoice,
        invoice_number="AA00000000",
        invalid_reason="Test",
    )

    # Test 4: Issue allowance (expected error - invalid invoice)
    run_test("issue_allowance (expected error)", tools.invoice_tools.issue_allowance,
        invoice_no="AA00000000",
        merchant_order_no=order_no,
        item_name="Test",
        item_count="1",
        item_unit="pc",
        item_price="50",
        item_amt="50",
        item_tax_amt="0",
        total_amt=50,
    )

    # Test 5: Trigger allowance (expected error)
    run_test("trigger_allowance (expected error)", tools.invoice_tools.trigger_allowance,
        allowance_no="A000000000000000",
        allowance_status="C",
        merchant_order_no=order_no,
        total_amt=50,
    )

    # Test 6: Void allowance (expected error)
    run_test("void_allowance (expected error)", tools.invoice_tools.void_allowance,
        allowance_no="A000000000000000",
        invalid_reason="Test",
    )

    # Test 7: Trigger invoice (expected error)
    run_test("trigger_invoice (expected error)", tools.invoice_tools.trigger_invoice,
        invoice_trans_no="0000000000000000",
        merchant_order_no=order_no,
        total_amt=105,
    )

    # Summary
    print(f"\n{'#' * 60}")
    print(f"TEST SUMMARY")
    print(f"{'#' * 60}")

    passed = sum(1 for s, _, _ in results if s == "PASS")
    failed = sum(1 for s, _, _ in results if s == "FAIL")

    for status, name, detail in results:
        icon = "+" if status == "PASS" else "X"
        print(f"  [{icon}] {name} ({detail})")

    print(f"\nTotal: {len(results)} | Passed: {passed} | Failed: {failed}")
    print(f"\nNote: 'expected error' tests pass if they get a valid API response")
    print(f"(even with error status) — this proves encryption and connectivity work.")

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
