#!/usr/bin/env python3
"""Unit tests for ezPay AES encryption and CheckCode generation."""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from auth.ezpay_crypto import encrypt_post_data, generate_check_code


def test_encrypt_post_data():
    """Test AES encryption produces valid hex output."""
    hash_key = "abcdefghijklmnopqrstuvwxyzabcdef"
    hash_iv = "1234567891234567"

    data = {
        "RespondType": "JSON",
        "Version": "1.4",
        "TimeStamp": "1444963784",
        "TransNum": "",
        "MerchantOrderNo": "201409170000001",
        "BuyerName": "王大品",
        "BuyerUBN": "54352706",
        "BuyerAddress": "台北市南港區南港路二段97號8樓",
        "BuyerEmail": "54352706@pay2go.com",
        "Category": "B2B",
        "TaxType": "1",
        "TaxRate": "5",
        "Amt": "490",
        "TaxAmt": "10",
        "TotalAmt": "500",
        "CarrierType": "",
        "CarrierNum": "",
        "LoveCode": "",
        "PrintFlag": "Y",
        "ItemName": "商品一|商品二",
        "ItemCount": "1|2",
        "ItemUnit": "個|個",
        "ItemPrice": "300|100",
        "ItemAmt": "300|200",
        "Comment": "備註",
        "CreateStatusTime": "",
        "Status": "1",
    }

    result = encrypt_post_data(data, hash_key, hash_iv)

    assert result, "Encrypted result should not be empty"
    assert all(c in "0123456789abcdef" for c in result), "Result should be hex"
    assert len(result) % 2 == 0, "Hex string should have even length"
    print(f"  Encryption output length: {len(result)} chars")
    print(f"  PASS: encrypt_post_data produces valid hex output")


def test_generate_check_code():
    """Test CheckCode generation with known values from ezPay docs appendix 2."""
    hash_key = "abcdefghijklmnopqrstuvwxyzabcdef"
    hash_iv = "1234567891234567"

    params = {
        "MerchantID": "3622183",
        "MerchantOrderNo": "201409170000001",
        "InvoiceTransNo": "14061313541640927",
        "TotalAmt": "500",
        "RandomNum": "0142",
    }

    result = generate_check_code(params, hash_key, hash_iv)

    expected = "303AB800650B724733B5D91CBCE075D9EA09E4CDE9CD33461D45F07D5EC7EECB"
    assert result == expected, f"Expected {expected}, got {result}"
    print(f"  CheckCode: {result}")
    print(f"  PASS: generate_check_code matches expected value")


def main():
    print("=" * 60)
    print("Testing ezPay Crypto")
    print("=" * 60)

    tests = [test_encrypt_post_data, test_generate_check_code]
    passed = 0
    failed = 0

    for test in tests:
        print(f"\n{test.__name__}:")
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"  FAIL: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n{'=' * 60}")
    print(f"Results: {passed} passed, {failed} failed")
    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
