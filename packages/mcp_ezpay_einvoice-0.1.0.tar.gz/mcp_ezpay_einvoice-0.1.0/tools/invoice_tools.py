"""ezPay E-Invoice MCP tools.

Provides 7 AI-callable tools for the full Taiwan e-invoice lifecycle:
issue, trigger, void invoices; issue, trigger, void allowances; query.
"""

from typing import Optional
from pydantic import Field
from pydantic.fields import FieldInfo
from app import mcp
from connectors.ezpay_client import ezpay_post


def _val(v, default=""):
    """Resolve a parameter value, handling FieldInfo defaults from direct calls."""
    if v is None or isinstance(v, FieldInfo):
        return default
    return v


@mcp.tool()
def issue_invoice(
    merchant_order_no: str = Field(description="Custom order number (alphanumeric/underscore, max 20 chars). Must be unique per merchant."),
    buyer_name: str = Field(description="Buyer name. B2B: company name (max 60 chars, padded with UBN if short). B2C: person name or identifier (max 30 chars)."),
    category: str = Field(description="Invoice category: 'B2B' (buyer is business) or 'B2C' (buyer is individual)."),
    tax_type: str = Field(description="Tax type: '1'=taxable, '2'=zero-rate, '3'=tax-free, '9'=mixed (B2C only)."),
    tax_rate: float = Field(description="Tax rate as integer percentage without %. E.g., 5 for 5%. Use 0 for zero-rate or tax-free."),
    amt: int = Field(description="Sales amount (excluding tax). When TaxType=9, equals AmtSales+AmtZero+AmtFree."),
    tax_amt: int = Field(description="Tax amount."),
    total_amt: int = Field(description="Total invoice amount (tax included). Must equal amt + tax_amt."),
    item_name: str = Field(description="Product name(s). Multiple items separated by '|'. E.g., 'Product A|Product B'."),
    item_count: str = Field(description="Product quantity(s). Multiple items separated by '|'. E.g., '1|2'."),
    item_unit: str = Field(description="Product unit(s). Max 2 Chinese or 6 English chars each. Multiple separated by '|'. E.g., 'pc|pc'."),
    item_price: str = Field(description="Product unit price(s). B2B: pre-tax price. B2C: tax-included price. Multiple separated by '|'."),
    item_amt: str = Field(description="Product subtotal(s) (count * price). Multiple separated by '|'."),
    print_flag: str = Field(description="Print paper invoice: 'Y'=print, 'N'=no print. B2B must be 'Y'. B2C: 'Y' if no carrier and no donation."),
    status: str = Field(default="1", description="Issue mode: '1'=immediate, '0'=deferred (needs trigger), '3'=scheduled (needs CreateStatusTime)."),
    buyer_ubn: Optional[str] = Field(default=None, description="Buyer's tax ID number (8 digits). Required for B2B, optional for B2C."),
    buyer_email: Optional[str] = Field(default=None, description="Buyer's email. Required when CarrierType=2 (ezPay carrier)."),
    buyer_address: Optional[str] = Field(default=None, description="Buyer's address."),
    carrier_type: Optional[str] = Field(default=None, description="B2C only. Carrier type: '0'=phone barcode, '1'=citizen digital cert, '2'=ezPay carrier. Empty if no carrier."),
    carrier_num: Optional[str] = Field(default=None, description="Carrier number. Required when CarrierType is set. Phone barcode: /+7 chars. Citizen cert: 2 uppercase+14 digits."),
    love_code: Optional[str] = Field(default=None, description="B2C only. Donation code (3-7 digits). If set, CarrierType must be empty."),
    comment: Optional[str] = Field(default=None, description="Invoice comment (max 200 chars)."),
    create_status_time: Optional[str] = Field(default=None, description="Scheduled issue date (YYYY-MM-DD). Required when status='3'."),
    trans_num: Optional[str] = Field(default=None, description="ezPay transaction number. For linking with ezPay payment flow."),
    customs_clearance: Optional[str] = Field(default=None, description="Customs clearance mark for zero-rate tax: '1'=non-customs, '2'=customs export."),
    amt_sales: Optional[int] = Field(default=None, description="Taxable sales amount. Required when TaxType='9' (mixed)."),
    amt_zero: Optional[int] = Field(default=None, description="Zero-rate sales amount. Required when TaxType='9' (mixed)."),
    amt_free: Optional[int] = Field(default=None, description="Tax-free sales amount. Required when TaxType='9' (mixed)."),
    item_tax_type: Optional[str] = Field(default=None, description="Per-item tax type for mixed (TaxType=9): '1'=taxable, '2'=zero, '3'=free. Separated by '|'."),
    kiosk_print_flag: Optional[str] = Field(default=None, description="Allow Kiosk printing when CarrierType=2. '1'=enable after winning lottery."),
) -> dict:
    """Issue an e-invoice through ezPay platform. Supports B2B (business) and B2C (individual) invoices with multiple items, tax types, and carrier options."""
    post_data = {
        "MerchantOrderNo": _val(merchant_order_no),
        "BuyerName": _val(buyer_name),
        "Category": _val(category),
        "BuyerUBN": _val(buyer_ubn),
        "BuyerAddress": _val(buyer_address),
        "BuyerEmail": _val(buyer_email),
        "CarrierType": _val(carrier_type),
        "CarrierNum": _val(carrier_num),
        "LoveCode": _val(love_code),
        "TaxType": _val(tax_type),
        "TaxRate": str(_val(tax_rate, 0)),
        "CustomsClearance": _val(customs_clearance),
        "Amt": str(_val(amt, 0)),
        "AmtSales": str(amt_sales) if isinstance(amt_sales, int) else "",
        "AmtZero": str(amt_zero) if isinstance(amt_zero, int) else "",
        "AmtFree": str(amt_free) if isinstance(amt_free, int) else "",
        "TaxAmt": str(_val(tax_amt, 0)),
        "TotalAmt": str(_val(total_amt, 0)),
        "ItemName": _val(item_name),
        "ItemCount": _val(item_count),
        "ItemUnit": _val(item_unit),
        "ItemPrice": _val(item_price),
        "ItemAmt": _val(item_amt),
        "ItemTaxType": _val(item_tax_type),
        "PrintFlag": _val(print_flag),
        "Comment": _val(comment),
        "CreateStatusTime": _val(create_status_time),
        "Status": _val(status, "1"),
        "TransNum": _val(trans_num),
    }

    kpf = _val(kiosk_print_flag)
    if kpf:
        post_data["KioskPrintFlag"] = kpf

    return ezpay_post("invoice_issue", post_data)


@mcp.tool()
def trigger_invoice(
    invoice_trans_no: str = Field(description="ezPay invoice transaction number from the original issue response."),
    merchant_order_no: str = Field(description="Custom order number used when the invoice was originally issued."),
    total_amt: int = Field(description="Total invoice amount (must match the original invoice)."),
) -> dict:
    """Trigger a deferred or scheduled invoice for immediate issuance. Use this after issuing an invoice with status='0' (deferred) or status='3' (scheduled) to actually issue it."""
    post_data = {
        "InvoiceTransNo": _val(invoice_trans_no),
        "MerchantOrderNo": _val(merchant_order_no),
        "TotalAmt": str(_val(total_amt, 0)),
    }
    return ezpay_post("invoice_touch_issue", post_data)


@mcp.tool()
def void_invoice(
    invoice_number: str = Field(description="Invoice number to void (10 chars, e.g., 'AB12345678')."),
    invalid_reason: str = Field(description="Reason for voiding (max 6 Chinese chars or 20 English chars)."),
) -> dict:
    """Void an issued invoice. Can only void invoices within the allowed period (before the 14th of the next odd month)."""
    post_data = {
        "InvoiceNumber": _val(invoice_number),
        "InvalidReason": _val(invalid_reason),
    }
    return ezpay_post("invoice_invalid", post_data)


@mcp.tool()
def issue_allowance(
    invoice_no: str = Field(description="Invoice number to issue allowance against (10 chars)."),
    merchant_order_no: str = Field(description="Custom order number from the original invoice."),
    item_name: str = Field(description="Allowance item name(s). Multiple separated by '|'."),
    item_count: str = Field(description="Allowance item count(s). Multiple separated by '|'."),
    item_unit: str = Field(description="Allowance item unit(s). Multiple separated by '|'."),
    item_price: str = Field(description="Allowance item price(s). Can be pre-tax or tax-included. Multiple separated by '|'."),
    item_amt: str = Field(description="Allowance item subtotal(s). Multiple separated by '|'."),
    item_tax_amt: str = Field(description="Allowance item tax amount(s). If ItemPrice is tax-included, set to '0'. Multiple separated by '|'."),
    total_amt: int = Field(description="Total allowance amount."),
    status: str = Field(default="1", description="Allowance confirmation mode: '0'=pending (needs trigger to confirm), '1'=immediate confirmation."),
    buyer_email: Optional[str] = Field(default=None, description="Buyer's email for allowance notification."),
    tax_type_for_mixed: Optional[str] = Field(default=None, description="Tax type when original invoice is mixed (TaxType=9): '1'=taxable, '2'=zero-rate, '3'=tax-free."),
) -> dict:
    """Issue an allowance (credit note / partial refund) against an existing invoice."""
    post_data = {
        "InvoiceNo": _val(invoice_no),
        "MerchantOrderNo": _val(merchant_order_no),
        "ItemName": _val(item_name),
        "ItemCount": _val(item_count),
        "ItemUnit": _val(item_unit),
        "ItemPrice": _val(item_price),
        "ItemAmt": _val(item_amt),
        "ItemTaxAmt": _val(item_tax_amt),
        "TaxTypeForMixed": _val(tax_type_for_mixed),
        "TotalAmt": str(_val(total_amt, 0)),
        "BuyerEmail": _val(buyer_email),
        "Status": _val(status, "1"),
    }

    return ezpay_post("allowance_issue", post_data)


@mcp.tool()
def trigger_allowance(
    allowance_no: str = Field(description="Allowance number from the original issue allowance response."),
    allowance_status: str = Field(description="Action to take: 'C'=confirm allowance, 'D'=cancel allowance."),
    merchant_order_no: str = Field(description="Custom order number from the original invoice."),
    total_amt: int = Field(description="Total allowance amount (must match)."),
) -> dict:
    """Confirm or cancel a pending allowance. Only applies to allowances issued with status='0' (pending)."""
    post_data = {
        "AllowanceNo": _val(allowance_no),
        "AllowanceStatus": _val(allowance_status),
        "MerchantOrderNo": _val(merchant_order_no),
        "TotalAmt": str(_val(total_amt, 0)),
    }
    return ezpay_post("allowance_touch_issue", post_data)


@mcp.tool()
def void_allowance(
    allowance_no: str = Field(description="Allowance number to void."),
    invalid_reason: str = Field(description="Reason for voiding (max 6 Chinese chars or 20 English chars)."),
) -> dict:
    """Void a confirmed allowance."""
    post_data = {
        "AllowanceNo": _val(allowance_no),
        "InvalidReason": _val(invalid_reason),
    }
    return ezpay_post("allowance_invalid", post_data)


@mcp.tool()
def query_invoice(
    search_type: str = Field(default="0", description="Search method: '0'=by invoice number + random number (default), '1'=by order number + amount."),
    invoice_number: Optional[str] = Field(default=None, description="Invoice number (required when SearchType='0')."),
    random_num: Optional[str] = Field(default=None, description="4-digit random number from invoice issue response (required when SearchType='0')."),
    merchant_order_no: Optional[str] = Field(default=None, description="Custom order number (required when SearchType='1')."),
    total_amt: Optional[int] = Field(default=None, description="Total invoice amount (required when SearchType='1')."),
    display_flag: Optional[str] = Field(default=None, description="Display mode: '1'=show on ezPay web page, '2'=return query result URL. Omit to get data as JSON response."),
) -> dict:
    """Query invoice details. Search by invoice number + random number, or by order number + amount."""
    post_data = {
        "SearchType": _val(search_type, "0"),
        "MerchantOrderNo": _val(merchant_order_no),
        "TotalAmt": str(total_amt) if isinstance(total_amt, int) else "",
        "InvoiceNumber": _val(invoice_number),
        "RandomNum": _val(random_num),
    }

    df = _val(display_flag)
    if df:
        post_data["DisplayFlag"] = df

    return ezpay_post("invoice_search", post_data)
