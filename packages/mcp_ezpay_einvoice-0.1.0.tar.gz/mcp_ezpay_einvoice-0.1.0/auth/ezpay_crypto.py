"""ezPay AES-256-CBC encryption and CheckCode verification.

Implements the encryption protocol described in the ezPay e-invoice API spec
(Appendix 1 & 2): URL-encode -> PKCS7 pad -> AES-256-CBC -> hex.
"""

import hashlib
import urllib.parse
from Crypto.Cipher import AES


def _pkcs7_pad(data: bytes, block_size: int = 32) -> bytes:
    """PKCS7 padding to specified block size."""
    pad_len = block_size - (len(data) % block_size)
    return data + bytes([pad_len] * pad_len)


def encrypt_post_data(data_dict: dict, hash_key: str, hash_iv: str) -> str:
    """Encrypt post data using AES-256-CBC as per ezPay spec.

    1. URL-encode the dict to a query string
    2. PKCS7 pad to 32-byte blocks
    3. AES-256-CBC encrypt
    4. Hex-encode the ciphertext

    Args:
        data_dict: Parameters to encrypt.
        hash_key: 32-char AES key (merchant's HashKey).
        hash_iv: 16-char AES IV (merchant's HashIV).

    Returns:
        Hex-encoded ciphertext string.
    """
    query_string = urllib.parse.urlencode(data_dict)
    padded = _pkcs7_pad(query_string.encode("utf-8"))
    cipher = AES.new(hash_key.encode("utf-8"), AES.MODE_CBC, hash_iv.encode("utf-8"))
    encrypted = cipher.encrypt(padded)
    return encrypted.hex()


def generate_check_code(params: dict, hash_key: str, hash_iv: str) -> str:
    """Generate CheckCode for response verification (Appendix 2).

    1. Sort params alphabetically by key, build query string
    2. Prepend HashIV=... & append &HashKey=...
    3. SHA256 hash, return uppercase hex

    Args:
        params: Dict with keys: InvoiceTransNo, MerchantID,
                MerchantOrderNo, RandomNum, TotalAmt.
        hash_key: Merchant's HashKey.
        hash_iv: Merchant's HashIV.

    Returns:
        Uppercase SHA256 hex string.
    """
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    query_string = urllib.parse.urlencode(sorted_params)
    check_string = f"HashIV={hash_iv}&{query_string}&HashKey={hash_key}"
    return hashlib.sha256(check_string.encode("utf-8")).hexdigest().upper()
