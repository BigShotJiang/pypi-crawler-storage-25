"""ezPay E-Invoice API configuration.

Reads merchant credentials from environment variables and provides
endpoint URL resolution for test/production environments.
"""

import os

MERCHANT_ID = os.environ.get("EZPAY_MERCHANT_ID", "")
HASH_KEY = os.environ.get("EZPAY_HASH_KEY", "")
HASH_IV = os.environ.get("EZPAY_HASH_IV", "")
IS_PRODUCTION = os.environ.get("EZPAY_IS_PRODUCTION", "false").lower() == "true"

_TEST_BASE = "https://cinv.ezpay.com.tw"
_PROD_BASE = "https://inv.ezpay.com.tw"

BASE_URL = _PROD_BASE if IS_PRODUCTION else _TEST_BASE

# Endpoint paths and their API versions
ENDPOINTS = {
    "invoice_issue":          {"path": "/Api/invoice_issue",          "version": "1.5"},
    "invoice_touch_issue":    {"path": "/Api/invoice_touch_issue",    "version": "1.0"},
    "invoice_invalid":        {"path": "/Api/invoice_invalid",        "version": "1.0"},
    "allowance_issue":        {"path": "/Api/allowance_issue",        "version": "1.3"},
    "allowance_touch_issue":  {"path": "/Api/allowance_touch_issue",  "version": "1.0"},
    "allowance_invalid":      {"path": "/Api/allowanceInvalid",       "version": "1.0"},
    "invoice_search":         {"path": "/Api/invoice_search",         "version": "1.3"},
}


def get_url(endpoint_key: str) -> str:
    """Get full URL for an endpoint."""
    return f"{BASE_URL}{ENDPOINTS[endpoint_key]['path']}"


def get_version(endpoint_key: str) -> str:
    """Get API version for an endpoint."""
    return ENDPOINTS[endpoint_key]["version"]
