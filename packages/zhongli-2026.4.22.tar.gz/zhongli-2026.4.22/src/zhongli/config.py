"""Classes and methods to control configuration of zhongli."""

import sys
from pathlib import Path

import msgspec
from httpx import AsyncClient
from loguru import logger as log
from longwei import APClient

from zhongli import USER_AGENT

CONFIG_CACHE_EXPIRE = 3600  # one hour


class Fediverse(msgspec.Struct):
    """Config values for Fediverse account to cross post to."""

    domain_name: str
    api_token: str


class FenLiu(msgspec.Struct):
    """Config values for FenLiu v0.4 integration (required)."""

    base_url: str
    api_key: str  # pragma: allowlist secret
    random_selection: bool = False
    prefer_topical: bool = False
    topical_only: bool = False
    skip_missing_alt_text: bool = False


class Configuration(msgspec.Struct):
    """Config for bot - FenLiu mode only."""

    fediverse: Fediverse
    fenliu: FenLiu
    run_continuously: bool
    delay_between_posts: int
    reblog_sensitive: bool = False
    max_reblog: int = 5
    cache_db_path: Path = Path("cache.db")


async def determine_config(config_path: Path) -> Configuration:
    """Determine configuration to use."""
    if config_path.exists():
        with config_path.open(mode="rb") as config_file:
            config_content = config_file.read()
            config = msgspec.toml.decode(config_content, type=Configuration)

    else:
        config = await create_default_config()
        log.debug(f"{config=}")
        with config_path.open(mode="wb") as config_file:
            config_file.write(msgspec.toml.encode(config))
        print("Please review your config file, adjust as needed, and run zhongli again.")
        sys.exit(0)

    return config


async def create_default_config() -> Configuration:
    """Create default configuration."""
    domain_name = input("Please enter the url for your Fediverse instance: ")

    async with AsyncClient(http2=True, timeout=30) as client:
        client_id, client_secret = await APClient.create_app(
            instance_url=domain_name,
            user_agent=USER_AGENT,
            client=client,
        )
        auth_url = await APClient.generate_authorization_url(
            instance_url=domain_name,
            client_id=client_id,
            user_agent=USER_AGENT,
        )

        print("Please go to the following URL and follow the prompts to authorize zhongli to use your account:")
        print(f"{auth_url}")
        auth_code = input("Please provide the authorization token provided by your instance: ")

        auth_token = await APClient.validate_authorization_code(
            client=client,
            instance_url=domain_name,
            authorization_code=auth_code,
            client_id=client_id,
            client_secret=client_secret,
        )

    return Configuration(
        fediverse=Fediverse(
            domain_name=domain_name,
            api_token=auth_token,
        ),
        run_continuously=False,
        delay_between_posts=300,
        max_reblog=5,
        reblog_sensitive=False,
        fenliu=FenLiu(
            base_url="http://localhost:8000",
            api_key="your-fenliu-api-key",  # pragma: allowlist secret
        ),
    )
