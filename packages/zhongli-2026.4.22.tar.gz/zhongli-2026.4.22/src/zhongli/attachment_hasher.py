"""Compute hashes for attachments to detect duplicates."""

import hashlib
from io import BytesIO
from pathlib import Path
from typing import Final

import httpx
from loguru import logger as log
from longwei import APClient

try:
    import imagehash
    from PIL import Image

    IMAGEHASH_AVAILABLE = True
except ImportError:
    IMAGEHASH_AVAILABLE = False

# Default maximum size to download for hashing (100 MB)
# This can be overridden by instance configuration
DEFAULT_MAX_DOWNLOAD_SIZE: Final[int] = 100 * 1024 * 1024

# Default image MIME types that support perceptual hashing
# This can be overridden by instance configuration
DEFAULT_IMAGE_MIME_TYPES: Final[set[str]] = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
}


class AttachmentHasher:
    """Compute content and perceptual hashes for attachments."""

    def __init__(
        self,
        client: httpx.AsyncClient,
        instance: APClient | None = None,
        dhash_size: int = 8,
    ) -> None:
        """Initialize hasher with HTTP client and optional instance configuration.

        Args:
            client: AsyncClient for downloading attachments
            instance: ActivityPub instance (used to get max_att_size and supported_mime_types)
                     If None, uses default values
            dhash_size: Size parameter for dHash — produces dhash_size² bits.
                       Default 8 gives 64-bit hashes (16 hex chars).

        """
        self.client = client
        self.instance = instance
        self.dhash_size = dhash_size

        # Set max download size from instance or use default
        if instance and hasattr(instance, "max_att_size") and instance.max_att_size:
            self.max_download_size = instance.max_att_size
        else:
            self.max_download_size = DEFAULT_MAX_DOWNLOAD_SIZE

        # Set supported image types from instance or use defaults
        if instance and hasattr(instance, "supported_mime_types") and instance.supported_mime_types:
            # Filter to only image types that we can compute dHash for
            self.image_mime_types = {
                mime_type
                for mime_type in instance.supported_mime_types
                if mime_type.startswith("image/") and mime_type in DEFAULT_IMAGE_MIME_TYPES
            }
            # If instance has no image types in defaults, use defaults
            if not self.image_mime_types:
                self.image_mime_types = DEFAULT_IMAGE_MIME_TYPES
        else:
            self.image_mime_types = DEFAULT_IMAGE_MIME_TYPES

    async def hash_attachment(
        self,
        url: str,
        media_type: str | None = None,
    ) -> tuple[str | None, str | None]:
        """Compute SHA-256 and dHash for an attachment.

        Args:
            url: URL of attachment to hash
            media_type: MIME type of attachment (optional, helps optimize)

        Returns:
            Tuple of (content_hash, dhash) where either can be None if unavailable.
            content_hash is always attempted, dhash only for images.

        """
        try:
            media_type = self._resolve_media_type(url, media_type)
            log.debug(f"Starting hash computation for attachment: url={url}, media_type={media_type}")
            if IMAGEHASH_AVAILABLE and self._is_supported_image_type(media_type):
                return await self._hash_image(url)
            return await self._hash_non_image(url)
        except Exception as error:
            log.warning(f"Error hashing attachment {url}: {error}")
            return None, None

    def _resolve_media_type(self, url: str, media_type: str | None) -> str | None:
        """Infer MIME type from URL when not provided or ambiguous."""
        if not media_type or media_type == "image":
            inferred = self._infer_mime_type_from_url(url)
            if inferred:
                log.debug(f"Inferred media_type from URL: {inferred}")
                return inferred
        return media_type

    async def _hash_image(self, url: str) -> tuple[str | None, str | None]:
        """Download and hash an image attachment (accumulates bytes for dHash)."""
        content = await self._download_image(url)
        if not content:
            log.debug(f"Failed to download image {url}")
            return None, None
        log.debug(f"Downloaded {len(content)} bytes from {url}")
        content_hash = hashlib.sha256(content).hexdigest()
        log.debug(f"Computed content hash for {url}: {content_hash[:16]}...")
        dhash = await self._compute_dhash(content)
        log.debug(f"Computed dHash for {url}: {dhash}")
        return content_hash, dhash

    async def _hash_non_image(self, url: str) -> tuple[str | None, str | None]:
        """Stream and SHA-256 hash a non-image attachment (no byte accumulation)."""
        log.debug(f"Streaming SHA-256 for non-image attachment: url={url}")
        content_hash = await self._stream_sha256(url)
        if not content_hash:
            log.debug(f"Failed to stream attachment {url}")
            return None, None
        return content_hash, None

    async def _download_image(self, url: str) -> bytes | None:
        """Download image content with size limit, accumulating bytes for dHash.

        Args:
            url: URL to download

        Returns:
            File content as bytes, or None if download fails or exceeds limit.

        """
        try:
            log.debug(f"Downloading image from {url}")
            async with self.client.stream("GET", url, follow_redirects=True) as response:
                log.debug(f"Response status: {response.status_code}")
                response.raise_for_status()

                content = b""
                async for chunk in response.aiter_bytes(chunk_size=8192):
                    content += chunk
                    if len(content) > self.max_download_size:
                        log.warning(
                            f"Attachment {url} exceeds max size ({self.max_download_size} bytes), skipping hash"
                        )
                        return None

                log.debug(f"Successfully downloaded {len(content)} bytes from {url}")
                return content

        except httpx.HTTPStatusError as error:
            log.warning(f"HTTP error downloading attachment {url}: {error.response.status_code}")
            return None
        except httpx.HTTPError as error:
            log.warning(f"Failed to download attachment {url}: {error}")
            return None

    async def _stream_sha256(self, url: str) -> str | None:
        """Stream attachment into SHA-256 without accumulating bytes.

        Used for non-image attachments where dHash is not needed.

        Args:
            url: URL to download

        Returns:
            SHA-256 hex digest, or None if download fails or exceeds limit.

        """
        try:
            log.debug(f"Streaming attachment for SHA-256 from {url}")
            async with self.client.stream("GET", url, follow_redirects=True) as response:
                log.debug(f"Response status: {response.status_code}")
                response.raise_for_status()

                hasher = hashlib.sha256()
                byte_count = 0
                async for chunk in response.aiter_bytes(chunk_size=8192):
                    byte_count += len(chunk)
                    if byte_count > self.max_download_size:
                        log.warning(
                            f"Attachment {url} exceeds max size ({self.max_download_size} bytes), skipping hash"
                        )
                        return None
                    hasher.update(chunk)

                digest = hasher.hexdigest()
                log.debug(f"Streamed {byte_count} bytes from {url}, SHA-256: {digest[:16]}...")
                return digest

        except httpx.HTTPStatusError as error:
            log.warning(f"HTTP error downloading attachment {url}: {error.response.status_code}")
            return None
        except httpx.HTTPError as error:
            log.warning(f"Failed to download attachment {url}: {error}")
            return None

    def _infer_mime_type_from_url(self, url: str) -> str | None:
        """Infer MIME type from file extension in URL.

        Args:
            url: URL of the attachment

        Returns:
            MIME type string if extension is recognized, None otherwise.

        """
        # Extract file extension from URL (ignore query parameters)
        path = url.split("?", maxsplit=1)[0]
        suffix = Path(path).suffix.lower()

        # Map common image extensions to MIME types
        mime_map = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".gif": "image/gif",
            ".webp": "image/webp",
        }

        return mime_map.get(suffix)

    def _is_supported_image_type(self, media_type: str | None) -> bool:
        """Check if media type is a supported image type for dHash.

        Args:
            media_type: MIME type of the media

        Returns:
            True if the media type is in the supported image types, False otherwise.

        """
        if not media_type:
            return False
        return media_type in self.image_mime_types

    async def _compute_dhash(self, content: bytes) -> str | None:
        """Compute difference hash (dHash) for image content.

        Args:
            content: Image file content as bytes

        Returns:
            dHash string, or None if computation fails.

        """
        if not IMAGEHASH_AVAILABLE:
            log.debug("imagehash not available for dHash computation")
            return None

        try:
            log.debug("Opening image for dHash computation")
            image = Image.open(BytesIO(content))
            dhash = imagehash.dhash(image, hash_size=self.dhash_size)
            log.debug(f"Successfully computed dHash: {dhash}")
            return str(dhash)

        except Exception as error:
            log.warning(f"Error computing dHash: {error}")
            return None
