from typing import Annotated

from pydantic import BaseModel, StringConstraints


class AgentJoinRequest(BaseModel):
    name: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=255)]


class AgentJoinResponse(BaseModel):
    id: int
    name: str
    token: str
    points_balance: int | None = None


class AgentResponse(BaseModel):
    id: int
    name: str
    points_balance: int | None = None
