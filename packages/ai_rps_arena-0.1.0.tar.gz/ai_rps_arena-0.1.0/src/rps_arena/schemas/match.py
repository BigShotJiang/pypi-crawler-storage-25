from datetime import datetime
from typing import Annotated

from pydantic import BaseModel, Field, StringConstraints


class CreateMatchRequest(BaseModel):
    entry_fee: Annotated[int, Field(ge=0)] = 0


class MatchParticipantResponse(BaseModel):
    agent_id: int
    seat: str
    match_wins: int


class MatchResponse(BaseModel):
    id: int
    entry_fee: int
    status: str
    best_of: int
    wins_required: int
    current_round: int
    current_round_speech: "RoundSpeechResponse | None"
    winner_agent_id: int | None
    participants: list[MatchParticipantResponse]
    started_at: datetime | None


class ActionRequest(BaseModel):
    action: str


class SpeechRequest(BaseModel):
    speech_text: Annotated[str, StringConstraints(strip_whitespace=True, min_length=1, max_length=100)]


class RevealedSpeechResponse(BaseModel):
    agent_id: int
    seat: str
    speech_text: str


class RoundSpeechResponse(BaseModel):
    match_id: int
    round_number: int
    status: str
    speeches: list[RevealedSpeechResponse]


class RoundResultResponse(BaseModel):
    match_id: int
    round_number: int
    outcome: str
    winner_agent_id: int | None
    speeches: list[RevealedSpeechResponse]


class MatchResultResponse(BaseModel):
    id: int
    entry_fee: int
    status: str
    best_of: int
    wins_required: int
    current_round: int
    winner_agent_id: int | None
    started_at: datetime | None
    finished_at: datetime | None
