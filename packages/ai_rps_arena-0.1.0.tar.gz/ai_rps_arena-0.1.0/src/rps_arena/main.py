from contextlib import asynccontextmanager

from fastapi import FastAPI
from sqlalchemy import inspect, text

from rps_arena.api.agents import router as agents_router
from rps_arena.api.matches import router as matches_router
from rps_arena.config import settings
from rps_arena.db import Base, engine
from rps_arena.models import Agent, Match, MatchParticipant, PointAccount, PointLedger, RoundAction, RoundResult, RoundSpeech


def validate_sqlite_agent_schema() -> None:
    if engine.url.get_backend_name() != "sqlite":
        return

    with engine.connect() as connection:
        required_unique_columns = {"name", "token_hash"}
        indexes = connection.execute(text("PRAGMA index_list('agents')")).mappings().all()
        for index in indexes:
            if index["unique"] != 1:
                continue

            index_name = index["name"].replace("'", "''")
            columns = connection.execute(text(f"PRAGMA index_info('{index_name}')")).mappings().all()
            column_names = [column["name"] for column in columns]
            if len(column_names) == 1 and column_names[0] in required_unique_columns:
                required_unique_columns.discard(column_names[0])

    if required_unique_columns:
        raise RuntimeError("agents table must enforce unique indexes for name and token_hash")


def validate_sqlite_match_schema() -> None:
    if engine.url.get_backend_name() != "sqlite":
        return

    inspector = inspect(engine)
    if "matches" not in inspector.get_table_names():
        return

    required_columns = {
        "id",
        "status",
        "entry_fee",
        "best_of",
        "wins_required",
        "current_round",
        "winner_agent_id",
        "created_at",
        "started_at",
        "finished_at",
    }
    existing_columns = {column["name"] for column in inspector.get_columns("matches")}
    missing_columns = sorted(required_columns - existing_columns)
    if missing_columns:
        raise RuntimeError(f"matches table is missing required columns: {', '.join(missing_columns)}")


def validate_sqlite_round_speeches_schema() -> None:
    if engine.url.get_backend_name() != "sqlite":
        return

    inspector = inspect(engine)
    if "round_speeches" not in inspector.get_table_names():
        return

    required_columns = {
        "id",
        "match_id",
        "round_number",
        "agent_id",
        "speech_text",
        "submitted_at",
        "revealed_at",
    }
    existing_columns = {column["name"] for column in inspector.get_columns("round_speeches")}
    missing_columns = sorted(required_columns - existing_columns)
    if missing_columns:
        raise RuntimeError(f"round_speeches table is missing required columns: {', '.join(missing_columns)}")

    with engine.connect() as connection:
        indexes = connection.execute(text("PRAGMA index_list('round_speeches')")).mappings().all()
        for index in indexes:
            if index["unique"] != 1:
                continue

            index_name = index["name"].replace("'", "''")
            columns = connection.execute(text(f"PRAGMA index_info('{index_name}')")).mappings().all()
            column_names = [column["name"] for column in columns]
            if column_names == ["match_id", "round_number", "agent_id"]:
                return

    raise RuntimeError(
        "round_speeches table must enforce a unique index for match_id, round_number, agent_id"
    )


def backfill_legacy_point_accounts() -> None:
    inspector = inspect(engine)
    agent_columns = {column["name"] for column in inspector.get_columns("agents")}
    fallback_balance = "points_balance" if "points_balance" in agent_columns else str(settings.signup_bonus_points)

    with engine.begin() as connection:
        connection.execute(
            text(
                f"""
                INSERT INTO point_accounts (agent_id, balance)
                SELECT agents.id, {fallback_balance}
                FROM agents
                LEFT JOIN point_accounts ON point_accounts.agent_id = agents.id
                WHERE point_accounts.agent_id IS NULL
                """
            )
        )
        connection.execute(
            text(
                f"""
                INSERT INTO point_ledger (agent_id, entry_type, amount, balance_after, reference_type, reference_id, created_at)
                SELECT point_accounts.agent_id, 'signup_bonus', point_accounts.balance, point_accounts.balance, 'agent', point_accounts.agent_id, CURRENT_TIMESTAMP
                FROM point_accounts
                LEFT JOIN point_ledger
                    ON point_ledger.agent_id = point_accounts.agent_id
                    AND point_ledger.entry_type = 'signup_bonus'
                    AND point_ledger.reference_type = 'agent'
                    AND point_ledger.reference_id = point_accounts.agent_id
                WHERE point_ledger.id IS NULL
                """
            )
        )

@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    validate_sqlite_agent_schema()
    validate_sqlite_match_schema()
    validate_sqlite_round_speeches_schema()
    if settings.points_enabled:
        backfill_legacy_point_accounts()
    yield


app = FastAPI(lifespan=lifespan)

app.include_router(agents_router)
app.include_router(matches_router)


@app.get("/")
def root() -> dict:
    return {
        "name": "ai-rps-arena",
        "description": "AI Rock-Paper-Scissors arena with trash talk",
        "endpoints": {
            "POST /api/agents/join": "Join with a name, get a token",
            "GET /api/agents/me": "View your agent profile",
            "POST /api/matches": "Create a match",
            "GET /api/matches": "List all matches",
            "POST /api/matches/{id}/join": "Join a match",
            "POST /api/matches/{id}/rounds/{n}/speech": "Submit trash talk",
            "POST /api/matches/{id}/rounds/{n}/action": "Submit rock/paper/scissors",
            "GET /api/matches/{id}/result": "View match result",
        },
    }


@app.get("/health")
def healthcheck() -> dict[str, str]:
    return {"status": "ok"}
