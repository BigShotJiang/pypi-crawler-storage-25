from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import text, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from rps_arena.api.deps import get_current_agent, get_db
from rps_arena.config import settings
from rps_arena.errors import match_already_joined_error, match_full_error, match_not_found_error, match_not_open_error
from rps_arena.models.agent import Agent
from rps_arena.models.match import Match, MatchParticipant, RoundSpeech
from rps_arena.schemas.match import (
    ActionRequest,
    CreateMatchRequest,
    MatchParticipantResponse,
    MatchResponse,
    MatchResultResponse,
    RoundSpeechResponse,
    RoundResultResponse,
    SpeechRequest,
)
from rps_arena.services.matches import (
    get_match_or_404,
    get_pending_round_result,
    get_round_speech_response,
    get_revealed_round_speeches,
    get_round_result_or_404,
    submit_action,
    submit_speech,
)
from rps_arena.services.points import apply_points

router = APIRouter(prefix="/api/matches", tags=["matches"])


def build_match_response(db: Session, match: Match) -> MatchResponse:
    participants = sorted(
        [
            MatchParticipantResponse(
                agent_id=participant.agent_id,
                seat=participant.seat,
                match_wins=participant.match_wins,
            )
            for participant in match_participants(match)
        ],
        key=lambda participant: participant.seat,
    )
    current_round_speech = None
    has_current_round_speech = (
        db.query(RoundSpeech)
        .filter_by(match_id=match.id, round_number=match.current_round)
        .first()
        is not None
    )
    if has_current_round_speech:
        current_round_speech = get_round_speech_response(db, match.id, match.current_round)
    return MatchResponse(
        id=match.id,
        entry_fee=match.entry_fee,
        status=match.status,
        best_of=match.best_of,
        wins_required=match.wins_required,
        current_round=match.current_round,
        current_round_speech=current_round_speech,
        winner_agent_id=match.winner_agent_id,
        participants=participants,
        started_at=match.started_at,
    )


def match_participants(match: Match) -> list[MatchParticipant]:
    return getattr(match, "participants", [])


def populate_match_participants(db: Session, match: Match) -> Match:
    match.participants = (
        db.query(MatchParticipant)
        .filter_by(match_id=match.id)
        .order_by(MatchParticipant.seat)
        .all()
    )
    return match


@router.get("", response_model=list[MatchResponse])
def list_matches(db: Session = Depends(get_db)) -> list[MatchResponse]:
    matches = db.query(Match).order_by(Match.id).all()
    return [build_match_response(db, populate_match_participants(db, match)) for match in matches]


@router.get("/{match_id}", response_model=MatchResponse)
def get_match(match_id: int, db: Session = Depends(get_db)) -> MatchResponse:
    match = populate_match_participants(db, get_match_or_404(db, match_id))
    return build_match_response(db, match)


@router.post("", response_model=MatchResponse, status_code=status.HTTP_201_CREATED)
def create_match(
    payload: CreateMatchRequest,
    db: Session = Depends(get_db),
) -> MatchResponse:
    match = Match(
        entry_fee=payload.entry_fee,
        status="open",
        best_of=3,
        wins_required=2,
        current_round=1,
        winner_agent_id=None,
    )
    db.add(match)
    db.commit()
    db.refresh(match)
    return build_match_response(db, match)


@router.post("/{match_id}/join", response_model=MatchResponse)
def join_match(
    match_id: int,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
) -> MatchResponse:
    match = db.get(Match, match_id, populate_existing=True)
    if match is None:
        raise match_not_found_error()
    if match.status != "open":
        raise match_not_open_error()

    if db.query(MatchParticipant).filter_by(match_id=match_id, agent_id=agent.id).first() is not None:
        raise match_already_joined_error()

    try:
        seat_row = db.execute(
            text(
                """
                INSERT INTO match_participants (match_id, agent_id, seat, match_wins)
                SELECT :match_id, :agent_id,
                    CASE participant_count
                        WHEN 0 THEN 'A'
                        WHEN 1 THEN 'B'
                    END,
                    0
                FROM (
                    SELECT COUNT(*) AS participant_count
                    FROM match_participants
                    WHERE match_id = :match_id
                ) participant_state
                WHERE EXISTS (
                    SELECT 1 FROM matches WHERE id = :match_id AND status = 'open'
                )
                AND NOT EXISTS (
                    SELECT 1 FROM match_participants WHERE match_id = :match_id AND agent_id = :agent_id
                )
                AND participant_count < 2
                RETURNING seat
                """
            ),
            {"match_id": match_id, "agent_id": agent.id},
        )
        seat = seat_row.scalar_one_or_none()
        if seat is None:
            current_match = db.get(Match, match_id, populate_existing=True)
            if current_match is None:
                raise match_not_found_error()
            if current_match.status != "open":
                raise match_not_open_error()
            if db.query(MatchParticipant).filter_by(match_id=match_id, agent_id=agent.id).first() is not None:
                raise match_already_joined_error()
            raise match_full_error()

        if settings.points_enabled:
            apply_points(db, agent.id, -match.entry_fee, "entry_fee", "match", match.id)
        if seat == "B":
            started_at = datetime.now(UTC)
            status_result = db.execute(
                update(Match)
                .where(Match.id == match.id)
                .where(Match.status == "open")
                .values(status="in_progress", started_at=started_at)
            )
            if status_result.rowcount != 1:
                raise match_not_open_error()
        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except IntegrityError:
        db.rollback()
        current_match = db.get(Match, match_id, populate_existing=True)
        if current_match is None:
            raise match_not_found_error()
        if current_match.status != "open":
            raise match_not_open_error()
        if db.query(MatchParticipant).filter_by(match_id=match_id, agent_id=agent.id).first() is not None:
            raise match_already_joined_error()
        raise match_full_error()

    db.refresh(match)
    return build_match_response(db, populate_match_participants(db, match))


def build_match_result_response(match: Match) -> MatchResultResponse:
    return MatchResultResponse(
        id=match.id,
        entry_fee=match.entry_fee,
        status=match.status,
        best_of=match.best_of,
        wins_required=match.wins_required,
        current_round=match.current_round,
        winner_agent_id=match.winner_agent_id,
        started_at=match.started_at,
        finished_at=match.finished_at,
    )


def build_round_result_response(
    db: Session,
    match_id: int,
    round_number: int,
    outcome: str,
    winner_agent_id: int | None,
) -> RoundResultResponse:
    return RoundResultResponse(
        match_id=match_id,
        round_number=round_number,
        outcome=outcome,
        winner_agent_id=winner_agent_id,
        speeches=get_revealed_round_speeches(db, match_id, round_number),
    )


@router.post("/{match_id}/rounds/{round_number}/action", response_model=RoundResultResponse)
def submit_match_action(
    match_id: int,
    round_number: int,
    payload: ActionRequest,
    response: Response,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
) -> RoundResultResponse:
    match = get_match_or_404(db, match_id)
    round_result = submit_action(db, match, agent.id, round_number, payload.action)
    if round_result is None:
        response.status_code = status.HTTP_202_ACCEPTED
        return build_round_result_response(db, match_id, round_number, "pending", None)

    return build_round_result_response(
        db,
        round_result.match_id,
        round_result.round_number,
        round_result.outcome,
        round_result.winner_agent_id,
    )


@router.post("/{match_id}/rounds/{round_number}/speech", response_model=RoundSpeechResponse)
def submit_match_speech(
    match_id: int,
    round_number: int,
    payload: SpeechRequest,
    response: Response,
    agent: Agent = Depends(get_current_agent),
    db: Session = Depends(get_db),
) -> RoundSpeechResponse:
    match = get_match_or_404(db, match_id)
    speech_response = submit_speech(db, match, agent.id, round_number, payload.speech_text)
    if speech_response.status == "pending":
        response.status_code = status.HTTP_202_ACCEPTED
    return speech_response


@router.get("/{match_id}/result", response_model=MatchResultResponse)
def get_match_result(match_id: int, db: Session = Depends(get_db)) -> MatchResultResponse:
    return build_match_result_response(get_match_or_404(db, match_id))


@router.get("/{match_id}/rounds/{round_number}/result", response_model=RoundResultResponse)
def get_round_result(match_id: int, round_number: int, db: Session = Depends(get_db)) -> RoundResultResponse:
    round_result = get_pending_round_result(db, match_id, round_number)
    if round_result is None:
        round_result = get_round_result_or_404(db, match_id, round_number)
    return build_round_result_response(
        db,
        round_result.match_id,
        round_result.round_number,
        round_result.outcome,
        round_result.winner_agent_id,
    )
