from collections.abc import Generator

from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from rps_arena.db import SessionLocal
from rps_arena.errors import unauthorized_error
from rps_arena.models.agent import Agent
from rps_arena.services.auth import hash_token

bearer_scheme = HTTPBearer(auto_error=False)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_agent(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> Agent:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise unauthorized_error()

    agent = db.query(Agent).filter(Agent.token_hash == hash_token(credentials.credentials)).one_or_none()
    if agent is None:
        raise unauthorized_error()

    return agent
