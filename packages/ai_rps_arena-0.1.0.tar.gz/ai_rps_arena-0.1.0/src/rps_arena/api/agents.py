from fastapi import APIRouter, Depends, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from rps_arena.api.deps import get_current_agent, get_db
from rps_arena.config import settings
from rps_arena.errors import conflict_error, integrity_error
from rps_arena.models.agent import Agent
from rps_arena.models.points import PointAccount
from rps_arena.schemas.agent import AgentJoinRequest, AgentJoinResponse, AgentResponse
from rps_arena.services.auth import generate_token, hash_token
from rps_arena.services.points import apply_points

router = APIRouter(prefix="/api/agents", tags=["agents"])


def is_agent_name_conflict(exc: IntegrityError) -> bool:
    message = str(exc.orig).lower()

    if "agents.name" in message:
        return True
    if "agents_name" in message and "unique" in message:
        return True
    if 'unique constraint "agents_name_key"' in message:
        return True
    return False


@router.post("/join", response_model=AgentJoinResponse, status_code=status.HTTP_201_CREATED)
def join_agent(payload: AgentJoinRequest, db: Session = Depends(get_db)) -> AgentJoinResponse:
    token = generate_token()
    agent = Agent(
        name=payload.name,
        token_hash=hash_token(token),
    )
    db.add(agent)
    try:
        db.flush()
        points_balance = None
        if settings.points_enabled:
            point_account = PointAccount(agent_id=agent.id, balance=0)
            db.add(point_account)
            db.flush()
            point_account = apply_points(db, agent.id, settings.signup_bonus_points, "signup_bonus", "agent", agent.id)
            points_balance = point_account.balance if point_account else None
        db.commit()
    except IntegrityError as exc:
        db.rollback()
        if is_agent_name_conflict(exc):
            raise conflict_error("Agent name already exists") from exc
        raise integrity_error() from exc
    db.refresh(agent)
    return AgentJoinResponse(
        id=agent.id,
        name=agent.name,
        token=token,
        points_balance=points_balance,
    )


@router.get("/me", response_model=AgentResponse)
def get_me(agent: Agent = Depends(get_current_agent), db: Session = Depends(get_db)) -> AgentResponse:
    points_balance = None
    if settings.points_enabled:
        point_account = db.get(PointAccount, agent.id)
        if point_account is None:
            raise integrity_error("Agent point account is missing")
        points_balance = point_account.balance

    return AgentResponse(id=agent.id, name=agent.name, points_balance=points_balance)
