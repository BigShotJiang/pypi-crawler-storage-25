from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from rps_arena.config import settings


class Base(DeclarativeBase):
    pass


def get_connect_args(database_url: str) -> dict[str, bool]:
    if database_url.startswith("sqlite"):
        return {"check_same_thread": False}
    return {}


engine = create_engine(settings.database_url, connect_args=get_connect_args(settings.database_url))
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
