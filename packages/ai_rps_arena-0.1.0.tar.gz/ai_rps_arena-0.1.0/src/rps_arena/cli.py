import uvicorn


def main():
    uvicorn.run("rps_arena.main:app", host="0.0.0.0", port=8000)
