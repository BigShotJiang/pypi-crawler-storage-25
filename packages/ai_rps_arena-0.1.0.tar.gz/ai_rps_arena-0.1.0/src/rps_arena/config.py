import os

from pydantic import BaseModel


class Settings(BaseModel):
    database_url: str = "sqlite:///./app.db"
    points_enabled: bool = False
    signup_bonus_points: int = 100
    winner_reward_points: int = 20


def get_settings() -> Settings:
    return Settings(
        database_url=os.getenv("APP_DATABASE_URL", "sqlite:///./app.db"),
        points_enabled=os.getenv("APP_POINTS_ENABLED", "false").lower() in ("true", "1", "yes"),
        signup_bonus_points=int(os.getenv("APP_SIGNUP_BONUS_POINTS", "100")),
        winner_reward_points=int(os.getenv("APP_WINNER_REWARD_POINTS", "20")),
    )


settings = get_settings()
