from datetime import UTC, datetime

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from rps_arena.config import settings
from rps_arena.errors import api_error, match_not_found_error, not_found_error
from rps_arena.models.match import Match, MatchParticipant, RoundAction, RoundResult, RoundSpeech
from rps_arena.schemas.match import RevealedSpeechResponse, RoundSpeechResponse
from rps_arena.services.points import apply_points
from rps_arena.services.rps import VALID_ACTIONS, resolve_round


def get_match_or_404(db: Session, match_id: int) -> Match:
    match = db.get(Match, match_id)
    if match is None:
        raise match_not_found_error()
    return match


def get_round_result_or_404(db: Session, match_id: int, round_number: int) -> RoundResult:
    get_match_or_404(db, match_id)
    round_result = db.query(RoundResult).filter_by(match_id=match_id, round_number=round_number).one_or_none()
    if round_result is None:
        raise not_found_error("Round result not found")
    return round_result


def get_pending_round_result(db: Session, match_id: int, round_number: int) -> RoundResult | None:
    get_match_or_404(db, match_id)
    round_result = db.query(RoundResult).filter_by(match_id=match_id, round_number=round_number).one_or_none()
    if round_result is not None:
        return round_result

    if db.query(RoundAction).filter_by(match_id=match_id, round_number=round_number).first() is None:
        return None

    return RoundResult(match_id=match_id, round_number=round_number, outcome="pending", winner_agent_id=None)


def get_match_participants(db: Session, match_id: int) -> list[MatchParticipant]:
    return (
        db.query(MatchParticipant)
        .filter_by(match_id=match_id)
        .order_by(MatchParticipant.seat)
        .all()
    )


def get_round_speech_response(db: Session, match_id: int, round_number: int) -> RoundSpeechResponse:
    participants = get_match_participants(db, match_id)
    speeches = (
        db.query(RoundSpeech)
        .filter_by(match_id=match_id, round_number=round_number)
        .order_by(RoundSpeech.submitted_at, RoundSpeech.id)
        .all()
    )
    if len(speeches) < 2 or any(speech.revealed_at is None for speech in speeches):
        return RoundSpeechResponse(match_id=match_id, round_number=round_number, status="pending", speeches=[])

    seat_by_agent_id = {participant.agent_id: participant.seat for participant in participants}
    revealed_speeches = [
        RevealedSpeechResponse(
            agent_id=speech.agent_id,
            seat=seat_by_agent_id[speech.agent_id],
            speech_text=speech.speech_text,
        )
        for speech in sorted(speeches, key=lambda item: seat_by_agent_id[item.agent_id])
    ]
    return RoundSpeechResponse(
        match_id=match_id,
        round_number=round_number,
        status="revealed",
        speeches=revealed_speeches,
    )


def get_revealed_round_speeches(db: Session, match_id: int, round_number: int) -> list[RevealedSpeechResponse]:
    return get_round_speech_response(db, match_id, round_number).speeches


def validate_speech_text(speech_text: str) -> str:
    normalized_speech_text = speech_text.strip()
    if not normalized_speech_text:
        raise api_error("INVALID_SPEECH_TEXT", "Speech text must not be blank", 400)
    if len(normalized_speech_text) > 100:
        raise api_error("INVALID_SPEECH_TEXT", "Speech text must be 100 characters or fewer", 400)
    return normalized_speech_text


def handle_submit_action_integrity_error(
    db: Session,
    match_id: int,
    round_number: int,
    agent_id: int,
) -> RoundResult:
    db.rollback()

    round_result = db.query(RoundResult).filter_by(match_id=match_id, round_number=round_number).one_or_none()
    if round_result is not None:
        return round_result

    duplicate_action = (
        db.query(RoundAction)
        .filter_by(match_id=match_id, round_number=round_number, agent_id=agent_id)
        .one_or_none()
    )
    if duplicate_action is not None:
        raise api_error("ROUND_ALREADY_SUBMITTED", "Action already submitted", 400)

    raise


def handle_submit_speech_integrity_error(
    db: Session,
    match_id: int,
    round_number: int,
    agent_id: int,
) -> RoundSpeechResponse:
    db.rollback()

    duplicate_speech = (
        db.query(RoundSpeech)
        .filter_by(match_id=match_id, round_number=round_number, agent_id=agent_id)
        .one_or_none()
    )
    if duplicate_speech is not None:
        raise api_error("ROUND_SPEECH_ALREADY_SUBMITTED", "Speech already submitted", 400)

    return get_round_speech_response(db, match_id, round_number)


def settle_round(db: Session, match_id: int, round_number: int) -> RoundResult | None:
    round_result = db.query(RoundResult).filter_by(match_id=match_id, round_number=round_number).one_or_none()
    if round_result is not None:
        return round_result

    match = db.get(Match, match_id)
    participants = get_match_participants(db, match_id)
    actions = db.query(RoundAction).filter_by(match_id=match_id, round_number=round_number).all()
    if len(actions) < 2:
        return None

    action_by_agent = {item.agent_id: item.action for item in actions}
    outcome = resolve_round(action_by_agent[participants[0].agent_id], action_by_agent[participants[1].agent_id])
    winner_agent_id = None
    if outcome == "agent_a_win":
        participants[0].match_wins += 1
        winner_agent_id = participants[0].agent_id
    elif outcome == "agent_b_win":
        participants[1].match_wins += 1
        winner_agent_id = participants[1].agent_id

    round_result = RoundResult(
        match_id=match_id,
        round_number=round_number,
        outcome=outcome,
        winner_agent_id=winner_agent_id,
    )
    db.add(round_result)

    match_winner = next((participant for participant in participants if participant.match_wins >= match.wins_required), None)
    if match_winner is not None:
        match.status = "finished"
        match.winner_agent_id = match_winner.agent_id
        match.finished_at = datetime.now(UTC)
        if settings.points_enabled:
            apply_points(db, match_winner.agent_id, settings.winner_reward_points, "match_reward", "match", match_id)
    elif round_number >= match.best_of:
        match.status = "finished"
        match.finished_at = datetime.now(UTC)
    elif match.current_round == round_number:
        match.current_round += 1

    db.commit()
    db.refresh(round_result)
    return round_result


def reconcile_pending_round(db: Session, match_id: int, round_number: int, agent_id: int) -> RoundResult | None:
    round_result = db.query(RoundResult).filter_by(match_id=match_id, round_number=round_number).one_or_none()
    if round_result is not None:
        return round_result

    actions = db.query(RoundAction).filter_by(match_id=match_id, round_number=round_number).all()
    if len(actions) < 2:
        return None

    try:
        return settle_round(db, match_id, round_number)
    except IntegrityError:
        return handle_submit_action_integrity_error(db, match_id, round_number, agent_id)


def submit_action(db: Session, match: Match, agent_id: int, round_number: int, action: str) -> RoundResult | None:
    match_id = match.id

    if match.status != "in_progress":
        raise api_error("MATCH_NOT_IN_PROGRESS", "Match is not in progress", 400)
    if round_number != match.current_round:
        raise api_error("INVALID_ROUND", "Round is not open", 400)
    if action not in VALID_ACTIONS:
        raise api_error("INVALID_ACTION", "Action must be rock, paper, or scissors", 400)

    participants = get_match_participants(db, match.id)
    if not any(participant.agent_id == agent_id for participant in participants):
        raise api_error("FORBIDDEN", "Agent is not a participant", 403)
    if not get_revealed_round_speeches(db, match.id, round_number):
        raise api_error(
            "ROUND_SPEECH_NOT_REVEALED",
            "Both speeches must be revealed first",
            400,
        )
    if db.query(RoundAction).filter_by(match_id=match.id, round_number=round_number, agent_id=agent_id).first() is not None:
        raise api_error("ROUND_ALREADY_SUBMITTED", "Action already submitted", 400)

    try:
        db.add(RoundAction(match_id=match_id, round_number=round_number, agent_id=agent_id, action=action))
        db.flush()

        actions = db.query(RoundAction).filter_by(match_id=match_id, round_number=round_number).all()
        if len(actions) < 2:
            db.commit()
            return reconcile_pending_round(db, match_id, round_number, agent_id)

        return settle_round(db, match_id, round_number)
    except IntegrityError:
        return handle_submit_action_integrity_error(db, match_id, round_number, agent_id)


def submit_speech(db: Session, match: Match, agent_id: int, round_number: int, speech_text: str) -> RoundSpeechResponse:
    normalized_speech_text = validate_speech_text(speech_text)

    if match.status != "in_progress":
        raise api_error("MATCH_NOT_IN_PROGRESS", "Match is not in progress", 400)
    if round_number != match.current_round:
        raise api_error("INVALID_ROUND", "Round is not open", 400)

    participants = get_match_participants(db, match.id)
    if not any(participant.agent_id == agent_id for participant in participants):
        raise api_error("FORBIDDEN", "Agent is not a participant", 403)
    if db.query(RoundSpeech).filter_by(match_id=match.id, round_number=round_number, agent_id=agent_id).first() is not None:
        raise api_error("ROUND_SPEECH_ALREADY_SUBMITTED", "Speech already submitted", 400)

    try:
        db.add(
            RoundSpeech(
                match_id=match.id,
                round_number=round_number,
                agent_id=agent_id,
                speech_text=normalized_speech_text,
            )
        )
        db.flush()

        speeches = db.query(RoundSpeech).filter_by(match_id=match.id, round_number=round_number).all()
        if len(speeches) == 2:
            revealed_at = datetime.now(UTC)
            for speech in speeches:
                speech.revealed_at = revealed_at

        db.commit()
        return get_round_speech_response(db, match.id, round_number)
    except IntegrityError:
        return handle_submit_speech_integrity_error(db, match.id, round_number, agent_id)
