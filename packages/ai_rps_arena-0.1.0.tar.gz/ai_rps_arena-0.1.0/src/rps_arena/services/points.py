from sqlalchemy import select, update
from sqlalchemy.orm import Session

from rps_arena.config import settings
from rps_arena.errors import insufficient_points_error, integrity_error
from rps_arena.models.points import PointAccount, PointLedger


def apply_points(
    db: Session,
    agent_id: int,
    amount: int,
    entry_type: str,
    reference_type: str,
    reference_id: int,
) -> PointAccount | None:
    if not settings.points_enabled:
        return None

    update_statement = update(PointAccount).where(PointAccount.agent_id == agent_id)
    if amount < 0:
        update_statement = update_statement.where(PointAccount.balance >= -amount)

    result = db.execute(update_statement.values(balance=PointAccount.balance + amount))
    if result.rowcount != 1:
        account_exists = db.execute(
            select(PointAccount.agent_id).where(PointAccount.agent_id == agent_id)
        ).scalar_one_or_none()
        if account_exists is None:
            raise integrity_error("Agent point account is missing")
        raise insufficient_points_error()

    point_account = db.get(PointAccount, agent_id, populate_existing=True)
    if point_account is None:
        raise integrity_error("Agent point account is missing")

    db.add(
        PointLedger(
            agent_id=agent_id,
            entry_type=entry_type,
            amount=amount,
            balance_after=point_account.balance,
            reference_type=reference_type,
            reference_id=reference_id,
        )
    )
    db.flush()
    return point_account
