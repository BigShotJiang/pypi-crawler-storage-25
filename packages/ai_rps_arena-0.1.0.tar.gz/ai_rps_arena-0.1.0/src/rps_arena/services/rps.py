VALID_ACTIONS = {"rock", "paper", "scissors"}


def resolve_round(action_a: str, action_b: str) -> str:
    if action_a == action_b:
        return "draw"

    if (action_a, action_b) in {("rock", "scissors"), ("paper", "rock"), ("scissors", "paper")}:
        return "agent_a_win"

    return "agent_b_win"
