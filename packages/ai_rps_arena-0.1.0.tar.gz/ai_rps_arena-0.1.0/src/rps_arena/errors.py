from fastapi import HTTPException, status


def api_error(
    code: str,
    message: str,
    status_code: int,
    headers: dict[str, str] | None = None,
) -> HTTPException:
    return HTTPException(status_code=status_code, detail={"code": code, "message": message}, headers=headers)


def unauthorized_error(message: str = "Invalid or missing token") -> HTTPException:
    return api_error(
        code="UNAUTHORIZED",
        message=message,
        status_code=status.HTTP_401_UNAUTHORIZED,
        headers={"WWW-Authenticate": "Bearer"},
    )


def conflict_error(message: str) -> HTTPException:
    return api_error(code="AGENT_NAME_EXISTS", message=message, status_code=status.HTTP_409_CONFLICT)


def integrity_error(message: str = "Could not register agent") -> HTTPException:
    return api_error(code="INTEGRITY_ERROR", message=message, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR)


def insufficient_points_error(message: str = "Agent does not have enough points") -> HTTPException:
    return api_error(code="INSUFFICIENT_POINTS", message=message, status_code=status.HTTP_400_BAD_REQUEST)


def match_already_joined_error(message: str = "Agent already joined this match") -> HTTPException:
    return api_error(code="MATCH_ALREADY_JOINED", message=message, status_code=status.HTTP_400_BAD_REQUEST)


def match_full_error(message: str = "Match already has two participants") -> HTTPException:
    return api_error(code="MATCH_FULL", message=message, status_code=status.HTTP_400_BAD_REQUEST)


def match_not_open_error(message: str = "Match is not open") -> HTTPException:
    return api_error(code="MATCH_NOT_OPEN", message=message, status_code=status.HTTP_400_BAD_REQUEST)


def match_not_found_error(message: str = "Match not found") -> HTTPException:
    return api_error(code="MATCH_NOT_FOUND", message=message, status_code=status.HTTP_404_NOT_FOUND)


def not_found_error(message: str) -> HTTPException:
    return api_error(code="NOT_FOUND", message=message, status_code=status.HTTP_404_NOT_FOUND)
