import importlib
import hashlib
import sqlite3
import sys

from fastapi.testclient import TestClient
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError


def test_healthcheck(client, app_modules, database_path):
    response = client.get("/health")

    config_module, _, _ = app_modules
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
    assert config_module.settings.database_url == f"sqlite:///{database_path}"
    assert database_path.exists()


def test_app_startup_raises_when_db_bootstrap_fails(app_modules, monkeypatch):
    _, db_module, main_module = app_modules

    def fail_create_all(*args, **kwargs):
        raise RuntimeError("db unavailable")

    monkeypatch.setattr(db_module.Base.metadata, "create_all", fail_create_all)

    try:
        with TestClient(main_module.app):
            pass
    except RuntimeError as exc:
        assert str(exc) == "db unavailable"
    else:
        raise AssertionError("Expected startup to fail when schema bootstrap fails")


def test_app_startup_raises_when_agent_token_hash_is_not_unique(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                token_hash TEXT NOT NULL
            )
            """
        )

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    main_module = importlib.import_module("rps_arena.main")

    try:
        with TestClient(main_module.app):
            pass
    except RuntimeError as exc:
        assert str(exc) == "agents table must enforce unique indexes for name and token_hash"
    else:
        raise AssertionError("Expected startup to fail when token_hash uniqueness is missing")


def test_app_startup_raises_when_agent_name_is_not_unique(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                token_hash TEXT NOT NULL UNIQUE
            )
            """
        )

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    main_module = importlib.import_module("rps_arena.main")

    try:
        with TestClient(main_module.app):
            pass
    except RuntimeError as exc:
        assert str(exc) == "agents table must enforce unique indexes for name and token_hash"
    else:
        raise AssertionError("Expected startup to fail when name uniqueness is missing")


def test_app_startup_raises_when_legacy_matches_schema_is_missing_required_columns(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                token_hash TEXT NOT NULL UNIQUE,
                created_at DATETIME NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE point_accounts (
                agent_id INTEGER PRIMARY KEY,
                balance INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE point_ledger (
                id INTEGER PRIMARY KEY,
                agent_id INTEGER NOT NULL,
                entry_type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                balance_after INTEGER NOT NULL,
                reference_type TEXT NOT NULL,
                reference_id INTEGER NOT NULL,
                created_at DATETIME NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE matches (
                id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                entry_fee INTEGER NOT NULL,
                best_of INTEGER NOT NULL,
                wins_required INTEGER NOT NULL,
                current_round INTEGER NOT NULL,
                created_at DATETIME NOT NULL,
                started_at DATETIME,
                finished_at DATETIME
            )
            """
        )

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    main_module = importlib.import_module("rps_arena.main")

    try:
        with TestClient(main_module.app):
            pass
    except RuntimeError as exc:
        assert str(exc) == "matches table is missing required columns: winner_agent_id"
    else:
        raise AssertionError("Expected startup to fail when matches schema is outdated")


def test_app_startup_raises_when_legacy_round_speeches_schema_is_missing_required_columns(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                token_hash TEXT NOT NULL UNIQUE,
                created_at DATETIME NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE point_accounts (
                agent_id INTEGER PRIMARY KEY,
                balance INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE point_ledger (
                id INTEGER PRIMARY KEY,
                agent_id INTEGER NOT NULL,
                entry_type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                balance_after INTEGER NOT NULL,
                reference_type TEXT NOT NULL,
                reference_id INTEGER NOT NULL,
                created_at DATETIME NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE matches (
                id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                entry_fee INTEGER NOT NULL,
                best_of INTEGER NOT NULL,
                wins_required INTEGER NOT NULL,
                current_round INTEGER NOT NULL,
                winner_agent_id INTEGER,
                created_at DATETIME NOT NULL,
                started_at DATETIME,
                finished_at DATETIME
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE round_speeches (
                id INTEGER PRIMARY KEY,
                match_id INTEGER NOT NULL,
                round_number INTEGER NOT NULL,
                agent_id INTEGER NOT NULL,
                speech_text TEXT NOT NULL
            )
            """
        )

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    main_module = importlib.import_module("rps_arena.main")

    try:
        with TestClient(main_module.app):
            pass
    except RuntimeError as exc:
        assert str(exc) == "round_speeches table is missing required columns: revealed_at, submitted_at"
    else:
        raise AssertionError("Expected startup to fail when round_speeches schema is outdated")


def test_app_startup_raises_when_legacy_round_speeches_schema_is_missing_unique_constraint(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                token_hash TEXT NOT NULL UNIQUE,
                created_at DATETIME NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE point_accounts (
                agent_id INTEGER PRIMARY KEY,
                balance INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE point_ledger (
                id INTEGER PRIMARY KEY,
                agent_id INTEGER NOT NULL,
                entry_type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                balance_after INTEGER NOT NULL,
                reference_type TEXT NOT NULL,
                reference_id INTEGER NOT NULL,
                created_at DATETIME NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE matches (
                id INTEGER PRIMARY KEY,
                status TEXT NOT NULL,
                entry_fee INTEGER NOT NULL,
                best_of INTEGER NOT NULL,
                wins_required INTEGER NOT NULL,
                current_round INTEGER NOT NULL,
                winner_agent_id INTEGER,
                created_at DATETIME NOT NULL,
                started_at DATETIME,
                finished_at DATETIME
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE round_speeches (
                id INTEGER PRIMARY KEY,
                match_id INTEGER NOT NULL,
                round_number INTEGER NOT NULL,
                agent_id INTEGER NOT NULL,
                speech_text TEXT NOT NULL,
                submitted_at DATETIME NOT NULL,
                revealed_at DATETIME
            )
            """
        )

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    main_module = importlib.import_module("rps_arena.main")

    try:
        with TestClient(main_module.app):
            pass
    except RuntimeError as exc:
        assert str(exc) == (
            "round_speeches table must enforce a unique index for match_id, round_number, agent_id"
        )
    else:
        raise AssertionError("Expected startup to fail when round_speeches uniqueness is missing")


def test_app_startup_backfills_legacy_point_accounts_from_points_balance(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                token_hash TEXT NOT NULL UNIQUE,
                points_balance INTEGER NOT NULL
            )
            """
        )
        connection.execute(
            "INSERT INTO agents (id, name, token_hash, points_balance) VALUES (1, 'alpha', 'hash', 42)"
        )

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    db_module = importlib.import_module("rps_arena.db")
    main_module = importlib.import_module("rps_arena.main")

    with TestClient(main_module.app):
        pass

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )

    assert point_accounts == [(1, 42)]
    assert point_ledger == [(1, "signup_bonus", 42, 42, "agent", 1)]


def test_app_startup_backfills_legacy_point_accounts_with_signup_bonus_when_old_balance_missing(database_path):
    with sqlite3.connect(database_path) as connection:
        connection.execute(
            """
            CREATE TABLE agents (
                id INTEGER PRIMARY KEY,
                name TEXT NOT NULL UNIQUE,
                token_hash TEXT NOT NULL UNIQUE
            )
            """
        )
        connection.execute("INSERT INTO agents (id, name, token_hash) VALUES (1, 'alpha', 'hash')")

    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.points",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    db_module = importlib.import_module("rps_arena.db")
    main_module = importlib.import_module("rps_arena.main")

    with TestClient(main_module.app):
        pass

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )

    assert point_accounts == [(1, 100)]
    assert point_ledger == [(1, "signup_bonus", 100, 100, "agent", 1)]

def test_get_connect_args_only_sets_sqlite_flag(app_modules):
    _, db_module, _ = app_modules

    assert db_module.get_connect_args("sqlite:///./app.db") == {"check_same_thread": False}
    assert db_module.get_connect_args("postgresql://example/db") == {}


def test_agent_model_requires_unique_token_hash(app_modules):
    _, _, _ = app_modules

    from rps_arena.models.agent import Agent

    assert Agent.__table__.c.token_hash.unique is True
    assert "points_balance" not in Agent.__table__.c


def test_point_account_model_stores_agent_balance(app_modules):
    _, _, _ = app_modules

    from rps_arena.models.points import PointAccount

    assert PointAccount.__table__.c.agent_id.primary_key is True
    assert PointAccount.__table__.c.balance.nullable is False


def test_join_agent_returns_token_and_signup_bonus(client):
    response = client.post("/api/agents/join", json={"name": "alpha"})

    assert response.status_code == 201
    body = response.json()

    assert body["id"] == 1
    assert body["name"] == "alpha"
    assert body["points_balance"] == 100
    assert isinstance(body["token"], str)
    assert body["token"]


def test_join_agent_rejects_names_longer_than_255_chars(client):
    response = client.post("/api/agents/join", json={"name": "a" * 256})

    assert response.status_code == 422


def test_join_agent_rejects_empty_or_whitespace_only_names(client):
    empty_response = client.post("/api/agents/join", json={"name": ""})
    whitespace_response = client.post("/api/agents/join", json={"name": "   "})

    assert empty_response.status_code == 422
    assert whitespace_response.status_code == 422


def test_join_agent_generates_unique_plaintext_key_but_stores_only_hash(client, app_modules):
    _, db_module, _ = app_modules

    first_response = client.post("/api/agents/join", json={"name": "alpha"})
    second_response = client.post("/api/agents/join", json={"name": "bravo"})

    first_token = first_response.json()["token"]
    second_token = second_response.json()["token"]

    with db_module.SessionLocal() as session:
        stored_hashes = [row[0] for row in session.execute(text("SELECT token_hash FROM agents ORDER BY id"))]
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))

    assert first_response.status_code == 201
    assert second_response.status_code == 201
    assert first_token != second_token
    assert stored_hashes == [
        hashlib.sha256(first_token.encode("utf-8")).hexdigest(),
        hashlib.sha256(second_token.encode("utf-8")).hexdigest(),
    ]
    assert first_token not in stored_hashes
    assert second_token not in stored_hashes
    assert point_accounts == [(1, 100), (2, 100)]


def test_join_agent_rejects_duplicate_names_with_api_error(client):
    first_response = client.post("/api/agents/join", json={"name": "alpha"})
    second_response = client.post("/api/agents/join", json={"name": "alpha"})

    assert first_response.status_code == 201
    assert second_response.status_code == 409
    assert second_response.json() == {
        "detail": {"code": "AGENT_NAME_EXISTS", "message": "Agent name already exists"}
    }


def test_join_agent_detects_duplicate_names_from_non_sqlite_integrity_error(app_modules, monkeypatch):
    _, db_module, main_module = app_modules

    def fail_commit(self):
        raise IntegrityError(
            'INSERT INTO agents (name, token_hash, points_balance) VALUES (%(name)s, %(token_hash)s, %(points_balance)s)',
            {"name": "alpha", "token_hash": "hash", "points_balance": 100},
            Exception('duplicate key value violates unique constraint "agents_name_key"'),
        )

    monkeypatch.setattr(db_module.SessionLocal.class_, "commit", fail_commit)

    with TestClient(main_module.app, raise_server_exceptions=False) as client:
        response = client.post("/api/agents/join", json={"name": "alpha"})

    assert response.status_code == 409
    assert response.json() == {
        "detail": {"code": "AGENT_NAME_EXISTS", "message": "Agent name already exists"}
    }


def test_join_agent_does_not_mislabel_other_integrity_errors(app_modules, monkeypatch):
    _, db_module, main_module = app_modules

    def fail_commit(self):
        raise IntegrityError(
            "INSERT INTO agents ...",
            {},
            sqlite3.IntegrityError("UNIQUE constraint failed: agents.token_hash"),
        )

    monkeypatch.setattr(db_module.SessionLocal.class_, "commit", fail_commit)

    with TestClient(main_module.app, raise_server_exceptions=False) as client:
        response = client.post("/api/agents/join", json={"name": "alpha"})

    assert response.status_code == 500
    assert response.json() == {
        "detail": {"code": "INTEGRITY_ERROR", "message": "Could not register agent"}
    }


def test_join_agent_does_not_mislabel_postgres_token_hash_duplicate_as_name_conflict(app_modules, monkeypatch):
    _, db_module, main_module = app_modules

    def fail_commit(self):
        raise IntegrityError(
            'INSERT INTO agents (name, token_hash) VALUES (%(name)s, %(token_hash)s)',
            {"name": "alpha", "token_hash": "hash"},
            Exception('duplicate key value violates unique constraint "agents_token_hash_key"'),
        )

    monkeypatch.setattr(db_module.SessionLocal.class_, "commit", fail_commit)

    with TestClient(main_module.app, raise_server_exceptions=False) as client:
        response = client.post("/api/agents/join", json={"name": "alpha"})

    assert response.status_code == 500
    assert response.json() == {
        "detail": {"code": "INTEGRITY_ERROR", "message": "Could not register agent"}
    }


def test_get_current_agent_returns_agent_profile_for_valid_bearer_token(client):
    registration = client.post("/api/agents/join", json={"name": "alpha"})
    token = registration.json()["token"]

    response = client.get("/api/agents/me", headers={"Authorization": f"Bearer {token}"})

    assert response.status_code == 200
    assert response.json() == {
        "id": 1,
        "name": "alpha",
        "points_balance": 100,
    }


def test_get_current_agent_rejects_missing_bearer_token(client):
    response = client.get("/api/agents/me")

    assert response.status_code == 401
    assert response.json() == {
        "detail": {"code": "UNAUTHORIZED", "message": "Invalid or missing token"}
    }
    assert response.headers["www-authenticate"] == "Bearer"


def test_get_current_agent_rejects_invalid_bearer_token(client):
    client.post("/api/agents/join", json={"name": "alpha"})

    response = client.get("/api/agents/me", headers={"Authorization": "Bearer not-a-real-key"})

    assert response.status_code == 401
    assert response.json() == {
        "detail": {"code": "UNAUTHORIZED", "message": "Invalid or missing token"}
    }
    assert response.headers["www-authenticate"] == "Bearer"
