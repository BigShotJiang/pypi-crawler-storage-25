from sqlalchemy import text

from conftest import auth_headers, setup_started_match


def reveal_round_speeches(client, alpha, beta, match, round_number, alpha_speech, beta_speech):
    first = client.post(
        f"/api/matches/{match['id']}/rounds/{round_number}/speech",
        json={"speech_text": alpha_speech},
        headers=auth_headers(alpha["token"]),
    )
    second = client.post(
        f"/api/matches/{match['id']}/rounds/{round_number}/speech",
        json={"speech_text": beta_speech},
        headers=auth_headers(beta["token"]),
    )

    assert first.status_code == 202
    assert second.status_code == 200


def test_round_result_includes_revealed_speeches(client):
    alpha, beta, match = setup_started_match(client)

    reveal_round_speeches(client, alpha, beta, match, 1, "I will throw rock.", "No, you won't.")

    client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    round_response = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "scissors"},
        headers=auth_headers(beta["token"]),
    )
    round_result = client.get(f"/api/matches/{match['id']}/rounds/1/result")

    expected_speeches = [
        {"agent_id": alpha["id"], "seat": "A", "speech_text": "I will throw rock."},
        {"agent_id": beta["id"], "seat": "B", "speech_text": "No, you won't."},
    ]
    assert round_response.status_code == 200
    assert round_response.json()["speeches"] == expected_speeches
    assert round_result.status_code == 200
    assert round_result.json()["speeches"] == expected_speeches


def test_get_round_result_returns_pending_response_after_first_action(client):
    alpha, beta, match = setup_started_match(client)

    reveal_round_speeches(client, alpha, beta, match, 1, "I will throw rock.", "No, you won't.")

    first_action = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    round_result = client.get(f"/api/matches/{match['id']}/rounds/1/result")

    assert first_action.status_code == 202
    assert round_result.status_code == 200
    assert round_result.json() == {
        "match_id": match["id"],
        "round_number": 1,
        "outcome": "pending",
        "winner_agent_id": None,
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "I will throw rock."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "No, you won't."},
        ],
    }


def test_match_finishes_when_agent_reaches_two_wins(client, app_modules):
    _, db_module, _ = app_modules
    alpha, beta, match = setup_started_match(client)

    reveal_round_speeches(client, alpha, beta, match, 1, "Rock first.", "Trying scissors.")

    client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "scissors"},
        headers=auth_headers(beta["token"]),
    )
    reveal_round_speeches(client, alpha, beta, match, 2, "Paper closes it.", "Rock anyway.")
    client.post(
        f"/api/matches/{match['id']}/rounds/2/action",
        json={"action": "paper"},
        headers=auth_headers(alpha["token"]),
    )
    round_two = client.post(
        f"/api/matches/{match['id']}/rounds/2/action",
        json={"action": "rock"},
        headers=auth_headers(beta["token"]),
    )

    assert round_two.status_code == 200
    assert round_two.json()["winner_agent_id"] == alpha["id"]

    result = client.get(f"/api/matches/{match['id']}/result")
    round_result = client.get(f"/api/matches/{match['id']}/rounds/2/result")

    assert result.status_code == 200
    assert result.json()["status"] == "finished"
    assert result.json()["winner_agent_id"] == alpha["id"]
    assert result.json()["finished_at"] is not None

    assert round_result.status_code == 200
    assert round_result.json() == {
        "match_id": match["id"],
        "round_number": 2,
        "outcome": "agent_a_win",
        "winner_agent_id": alpha["id"],
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "Paper closes it."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "Rock anyway."},
        ],
    }

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )
        match_row = session.execute(
            text("SELECT status, current_round, winner_agent_id, finished_at FROM matches WHERE id = :match_id"),
            {"match_id": match["id"]},
        ).one()

    assert point_accounts == [(1, 110), (2, 90)]
    assert point_ledger == [
        (1, "signup_bonus", 100, 100, "agent", 1),
        (2, "signup_bonus", 100, 100, "agent", 2),
        (1, "entry_fee", -10, 90, "match", 1),
        (2, "entry_fee", -10, 90, "match", 1),
        (1, "match_reward", 20, 110, "match", 1),
    ]
    assert match_row[0] == "finished"
    assert match_row[1] == 2
    assert match_row[2] == alpha["id"]
    assert match_row[3] is not None


def test_finished_match_detail_still_includes_final_round_speech(client):
    alpha, beta, match = setup_started_match(client)

    reveal_round_speeches(client, alpha, beta, match, 1, "Rock first.", "Trying scissors.")
    client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "scissors"},
        headers=auth_headers(beta["token"]),
    )

    reveal_round_speeches(client, alpha, beta, match, 2, "Paper closes it.", "Rock anyway.")
    client.post(
        f"/api/matches/{match['id']}/rounds/2/action",
        json={"action": "paper"},
        headers=auth_headers(alpha["token"]),
    )
    final_action = client.post(
        f"/api/matches/{match['id']}/rounds/2/action",
        json={"action": "rock"},
        headers=auth_headers(beta["token"]),
    )
    assert final_action.status_code == 200

    detail = client.get(f"/api/matches/{match['id']}")

    assert detail.status_code == 200
    assert detail.json()["status"] == "finished"
    assert detail.json()["current_round"] == 2
    assert detail.json()["current_round_speech"] == {
        "match_id": match["id"],
        "round_number": 2,
        "status": "revealed",
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "Paper closes it."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "Rock anyway."},
        ],
    }


def test_match_detail_includes_updated_participant_match_wins(client):
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "Rock first.", "Trying scissors.")

    client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    round_one = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "scissors"},
        headers=auth_headers(beta["token"]),
    )
    assert round_one.status_code == 200

    detail = client.get(f"/api/matches/{match['id']}")

    assert detail.status_code == 200
    assert detail.json()["participants"] == [
        {"agent_id": alpha["id"], "seat": "A", "match_wins": 1},
        {"agent_id": beta["id"], "seat": "B", "match_wins": 0},
    ]


def test_match_list_and_detail_include_current_round_speech_when_submitted(client):
    alpha, beta, match = setup_started_match(client)

    first_speech = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "Opening line."},
        headers=auth_headers(alpha["token"]),
    )
    assert first_speech.status_code == 202

    list_response = client.get("/api/matches")
    detail_response = client.get(f"/api/matches/{match['id']}")

    expected_pending_speech = {
        "match_id": match["id"],
        "round_number": 1,
        "status": "pending",
        "speeches": [],
    }
    assert list_response.status_code == 200
    assert list_response.json()[0]["current_round_speech"] == expected_pending_speech
    assert detail_response.status_code == 200
    assert detail_response.json()["current_round_speech"] == expected_pending_speech

    second_speech = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "Counterpoint."},
        headers=auth_headers(beta["token"]),
    )
    assert second_speech.status_code == 200

    updated_detail = client.get(f"/api/matches/{match['id']}")

    assert updated_detail.status_code == 200
    assert updated_detail.json()["current_round_speech"] == {
        "match_id": match["id"],
        "round_number": 1,
        "status": "revealed",
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "Opening line."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "Counterpoint."},
        ],
    }


def test_submit_action_rejects_duplicate_round_submission(client):
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "Rock first.", "Trying scissors.")

    first = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    duplicate = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "paper"},
        headers=auth_headers(alpha["token"]),
    )

    assert first.status_code == 202
    assert duplicate.status_code == 400
    assert duplicate.json() == {
        "detail": {"code": "ROUND_ALREADY_SUBMITTED", "message": "Action already submitted"}
    }


def test_get_round_result_returns_match_not_found_for_unknown_match(client):
    response = client.get("/api/matches/999/rounds/1/result")

    assert response.status_code == 404
    assert response.json() == {
        "detail": {"code": "MATCH_NOT_FOUND", "message": "Match not found"}
    }


def test_submit_action_returns_existing_round_result_after_concurrent_settlement(client, app_modules):
    _, db_module, _ = app_modules
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "Rock first.", "Trying scissors.")

    from sqlalchemy.exc import IntegrityError

    from rps_arena.models.match import Match, MatchParticipant, RoundAction, RoundResult
    from rps_arena.services.matches import submit_action

    first = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    assert first.status_code == 202

    stale_session = db_module.SessionLocal()
    original_commit = stale_session.commit
    injected_result = False

    def commit_with_concurrent_settlement():
        nonlocal injected_result
        if not injected_result:
            injected_result = True
            stale_session.rollback()
            with db_module.SessionLocal() as fresh_session:
                fresh_match = fresh_session.get(Match, match["id"])
                participants = (
                    fresh_session.query(MatchParticipant)
                    .filter_by(match_id=match["id"])
                    .order_by(MatchParticipant.seat)
                    .all()
                )
                participants[0].match_wins = 1
                fresh_match.current_round = 2
                fresh_session.add(
                    RoundAction(match_id=match["id"], round_number=1, agent_id=beta["id"], action="scissors")
                )
                fresh_session.add(
                    RoundResult(
                        match_id=match["id"],
                        round_number=1,
                        outcome="agent_a_win",
                        winner_agent_id=alpha["id"],
                    )
                )
                fresh_session.commit()
            raise IntegrityError("insert into round_results", {}, Exception("round_results unique conflict"))

        return original_commit()

    stale_session.commit = commit_with_concurrent_settlement
    try:
        stale_match = stale_session.get(Match, match["id"])

        round_result = submit_action(stale_session, stale_match, beta["id"], 1, "scissors")

        assert round_result is not None
        assert round_result.match_id == match["id"]
        assert round_result.round_number == 1
        assert round_result.outcome == "agent_a_win"
        assert round_result.winner_agent_id == alpha["id"]
    finally:
        stale_session.close()


def test_submit_action_reconciles_pending_commit_when_peer_action_commits_concurrently(client, app_modules):
    _, db_module, _ = app_modules
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "Rock first.", "Trying scissors.")

    from rps_arena.models.match import Match, RoundAction, RoundResult
    from rps_arena.services.matches import submit_action

    stale_session = db_module.SessionLocal()
    original_commit = stale_session.commit
    injected_peer_action = False

    def commit_with_concurrent_peer_action():
        nonlocal injected_peer_action
        if not injected_peer_action:
            injected_peer_action = True
            original_commit()
            with db_module.SessionLocal() as fresh_session:
                fresh_session.add(
                    RoundAction(match_id=match["id"], round_number=1, agent_id=beta["id"], action="scissors")
                )
                fresh_session.commit()

            return None

        return original_commit()

    stale_session.commit = commit_with_concurrent_peer_action
    try:
        stale_match = stale_session.get(Match, match["id"])

        round_result = submit_action(stale_session, stale_match, alpha["id"], 1, "rock")

        assert round_result is not None
        assert round_result.match_id == match["id"]
        assert round_result.round_number == 1
        assert round_result.outcome == "agent_a_win"
        assert round_result.winner_agent_id == alpha["id"]
    finally:
        stale_session.close()

    with db_module.SessionLocal() as session:
        round_result_row = session.query(RoundResult).filter_by(match_id=match["id"], round_number=1).one()
        match_row = session.execute(
            text("SELECT current_round, winner_agent_id, finished_at FROM matches WHERE id = :match_id"),
            {"match_id": match["id"]},
        ).one()

    assert round_result_row.outcome == "agent_a_win"
    assert round_result_row.winner_agent_id == alpha["id"]
    assert match_row == (2, None, None)


def test_match_finishes_after_best_of_three_all_draws(client):
    alpha, beta, match = setup_started_match(client)

    speeches_by_round = {
        1: ("Rock one.", "Rock one too."),
        2: ("Rock two.", "Rock two too."),
        3: ("Rock three.", "Rock three too."),
    }

    for round_number in (1, 2, 3):
        reveal_round_speeches(client, alpha, beta, match, round_number, *speeches_by_round[round_number])
        first = client.post(
            f"/api/matches/{match['id']}/rounds/{round_number}/action",
            json={"action": "rock"},
            headers=auth_headers(alpha["token"]),
        )
        second = client.post(
            f"/api/matches/{match['id']}/rounds/{round_number}/action",
            json={"action": "rock"},
            headers=auth_headers(beta["token"]),
        )

        assert first.status_code == 202
        assert second.status_code == 200
        assert second.json()["outcome"] == "draw"

    result = client.get(f"/api/matches/{match['id']}/result")

    assert result.status_code == 200
    assert result.json()["status"] == "finished"
    assert result.json()["current_round"] == 3
    assert result.json()["winner_agent_id"] is None
    assert result.json()["finished_at"] is not None
