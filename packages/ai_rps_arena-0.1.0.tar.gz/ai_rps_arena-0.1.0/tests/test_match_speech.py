import pytest
from fastapi import HTTPException

from conftest import auth_headers, setup_started_match


def test_first_speech_submission_stays_hidden_until_other_agent_speaks(client):
    alpha, _, match = setup_started_match(client)

    response = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "I will throw rock."},
        headers=auth_headers(alpha["token"]),
    )

    assert response.status_code == 202
    assert response.json() == {
        "match_id": match["id"],
        "round_number": 1,
        "status": "pending",
        "speeches": [],
    }


def test_second_speech_submission_reveals_both_messages(client):
    alpha, beta, match = setup_started_match(client)

    first = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "I will throw rock."},
        headers=auth_headers(alpha["token"]),
    )
    response = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "No, you won't."},
        headers=auth_headers(beta["token"]),
    )

    assert first.status_code == 202
    assert response.status_code == 200
    assert response.json() == {
        "match_id": match["id"],
        "round_number": 1,
        "status": "revealed",
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "I will throw rock."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "No, you won't."},
        ],
    }


def test_speech_text_is_trimmed_and_limited_to_100_chars(client):
    alpha, beta, match = setup_started_match(client)

    empty_response = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": " " * 5},
        headers=auth_headers(alpha["token"]),
    )
    max_length_response = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "x" * 101},
        headers=auth_headers(alpha["token"]),
    )
    trimmed_response = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "  Mind games.  "},
        headers=auth_headers(alpha["token"]),
    )
    reveal_response = client.post(
        f"/api/matches/{match['id']}/rounds/1/speech",
        json={"speech_text": "Counterpoint."},
        headers=auth_headers(beta["token"]),
    )

    assert empty_response.status_code == 422
    assert max_length_response.status_code == 422
    assert trimmed_response.status_code == 202
    assert trimmed_response.json() == {
        "match_id": match["id"],
        "round_number": 1,
        "status": "pending",
        "speeches": [],
    }
    assert reveal_response.status_code == 200
    assert reveal_response.json()["speeches"] == [
        {"agent_id": alpha["id"], "seat": "A", "speech_text": "Mind games."},
        {"agent_id": beta["id"], "seat": "B", "speech_text": "Counterpoint."},
    ]


@pytest.mark.parametrize(
    ("speech_text", "expected_message"),
    [
        (" " * 5, "Speech text must not be blank"),
        ("x" * 101, "Speech text must be 100 characters or fewer"),
    ],
)
def test_submit_speech_rejects_invalid_text_before_persisting(client, app_modules, speech_text, expected_message):
    _, db_module, _ = app_modules
    alpha, _, match = setup_started_match(client)

    from rps_arena.models.match import Match, RoundSpeech
    from rps_arena.services.matches import submit_speech

    with db_module.SessionLocal() as session:
        service_match = session.get(Match, match["id"])

        with pytest.raises(HTTPException) as exc_info:
            submit_speech(session, service_match, alpha["id"], 1, speech_text)

        assert exc_info.value.status_code == 400
        assert exc_info.value.detail == {
            "code": "INVALID_SPEECH_TEXT",
            "message": expected_message,
        }
        assert session.query(RoundSpeech).filter_by(match_id=match["id"], round_number=1).count() == 0
