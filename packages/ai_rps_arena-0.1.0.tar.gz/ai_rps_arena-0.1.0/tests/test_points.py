from sqlalchemy import text


def test_join_agent_records_signup_bonus_in_point_ledger(client, app_modules):
    _, db_module, _ = app_modules

    response = client.post("/api/agents/join", json={"name": "alpha"})

    assert response.status_code == 201

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )

    assert point_accounts == [(1, 100)]
    assert point_ledger == [(1, "signup_bonus", 100, 100, "agent", 1)]
