import pytest
from fastapi import HTTPException

from conftest import auth_headers, setup_started_match


def reveal_round_speeches(client, alpha, beta, match, round_number, alpha_speech, beta_speech):
    first = client.post(
        f"/api/matches/{match['id']}/rounds/{round_number}/speech",
        json={"speech_text": alpha_speech},
        headers=auth_headers(alpha["token"]),
    )
    second = client.post(
        f"/api/matches/{match['id']}/rounds/{round_number}/speech",
        json={"speech_text": beta_speech},
        headers=auth_headers(beta["token"]),
    )

    assert first.status_code == 202
    assert second.status_code == 200


def test_submit_action_rejects_until_round_speeches_are_revealed(client):
    alpha, _, match = setup_started_match(client)

    response = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )

    assert response.status_code == 400
    assert response.json() == {
        "detail": {
            "code": "ROUND_SPEECH_NOT_REVEALED",
            "message": "Both speeches must be revealed first",
        }
    }


def test_second_action_submission_settles_round(client):
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "I will throw rock.", "No, you won't.")

    first = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    second = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "scissors"},
        headers=auth_headers(beta["token"]),
    )

    assert first.status_code == 202
    assert first.json() == {
        "match_id": match["id"],
        "round_number": 1,
        "outcome": "pending",
        "winner_agent_id": None,
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "I will throw rock."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "No, you won't."},
        ],
    }
    assert second.status_code == 200
    assert second.json()["winner_agent_id"] == alpha["id"]


def test_draw_advances_to_next_round_without_winner(client):
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "Rock incoming.", "Matching you.")

    first = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(alpha["token"]),
    )
    response = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers=auth_headers(beta["token"]),
    )

    assert first.status_code == 202
    assert response.status_code == 200
    assert response.json() == {
        "match_id": match["id"],
        "round_number": 1,
        "outcome": "draw",
        "winner_agent_id": None,
        "speeches": [
            {"agent_id": alpha["id"], "seat": "A", "speech_text": "Rock incoming."},
            {"agent_id": beta["id"], "seat": "B", "speech_text": "Matching you."},
        ],
    }


def test_submit_action_turns_concurrent_duplicate_insert_into_domain_error(client, app_modules):
    _, db_module, _ = app_modules
    alpha, beta, match = setup_started_match(client)
    reveal_round_speeches(client, alpha, beta, match, 1, "I will throw rock.", "No, you won't.")

    from rps_arena.models.match import Match, RoundAction
    from rps_arena.services.matches import submit_action

    stale_session = db_module.SessionLocal()
    original_flush = stale_session.flush
    injected_duplicate = False

    def flush_with_concurrent_duplicate(*args, **kwargs):
        nonlocal injected_duplicate
        if not injected_duplicate:
            injected_duplicate = True
            with db_module.SessionLocal() as fresh_session:
                fresh_session.add(
                    RoundAction(match_id=match["id"], round_number=1, agent_id=alpha["id"], action="rock")
                )
                fresh_session.commit()

        return original_flush(*args, **kwargs)

    stale_session.flush = flush_with_concurrent_duplicate
    try:
        stale_match = stale_session.get(Match, match["id"])

        with pytest.raises(HTTPException) as exc_info:
            submit_action(stale_session, stale_match, alpha["id"], 1, "rock")

        assert exc_info.value.status_code == 400
        assert exc_info.value.detail == {
            "code": "ROUND_ALREADY_SUBMITTED",
            "message": "Action already submitted",
        }
    finally:
        stale_session.close()
