from sqlalchemy import text


def join_agent(client, name: str) -> dict:
    response = client.post("/api/agents/join", json={"name": name})
    assert response.status_code == 201
    return response.json()


def auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def test_create_match_is_unauthenticated_and_does_not_charge_points(client, app_modules):
    _, db_module, _ = app_modules
    agent = join_agent(client, "alpha")

    response = client.post("/api/matches", json={"entry_fee": 25})

    assert response.status_code == 201
    assert response.json() == {
        "id": 1,
        "entry_fee": 25,
        "status": "open",
        "best_of": 3,
        "wins_required": 2,
        "current_round": 1,
        "current_round_speech": None,
        "winner_agent_id": None,
        "participants": [],
        "started_at": None,
    }

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )
        participants = list(
            session.execute(text("SELECT match_id, agent_id, seat FROM match_participants ORDER BY id"))
        )

    assert agent["points_balance"] == 100
    assert point_accounts == [(1, 100)]
    assert point_ledger == [(1, "signup_bonus", 100, 100, "agent", 1)]
    assert participants == []


def test_two_agents_can_join_match_and_second_join_starts_match(client, app_modules):
    _, db_module, _ = app_modules
    alpha = join_agent(client, "alpha")
    beta = join_agent(client, "beta")

    match = client.post("/api/matches", json={"entry_fee": 10}).json()

    first = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(alpha["token"]))
    second = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(beta["token"]))

    assert first.status_code == 200
    assert first.json() == {
        "id": 1,
        "entry_fee": 10,
        "status": "open",
        "best_of": 3,
        "wins_required": 2,
        "current_round": 1,
        "current_round_speech": None,
        "winner_agent_id": None,
        "participants": [{"agent_id": 1, "seat": "A", "match_wins": 0}],
        "started_at": None,
    }

    assert second.status_code == 200
    assert second.json()["status"] == "in_progress"
    assert second.json()["current_round_speech"] is None
    assert second.json()["winner_agent_id"] is None
    assert second.json()["participants"] == [
        {"agent_id": 1, "seat": "A", "match_wins": 0},
        {"agent_id": 2, "seat": "B", "match_wins": 0},
    ]
    assert second.json()["started_at"] is not None

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )
        participants = list(
            session.execute(text("SELECT match_id, agent_id, seat FROM match_participants ORDER BY seat"))
        )
        match_row = session.execute(
            text("SELECT status, current_round, winner_agent_id, started_at FROM matches WHERE id = 1")
        ).one()

    assert point_accounts == [(1, 90), (2, 90)]
    assert point_ledger == [
        (1, "signup_bonus", 100, 100, "agent", 1),
        (2, "signup_bonus", 100, 100, "agent", 2),
        (1, "entry_fee", -10, 90, "match", 1),
        (2, "entry_fee", -10, 90, "match", 1),
    ]
    assert participants == [(1, 1, "A"), (1, 2, "B")]
    assert match_row[0] == "in_progress"
    assert match_row[1] == 1
    assert match_row[2] is None
    assert match_row[3] is not None


def test_join_rejects_agent_without_enough_points(client, app_modules):
    _, db_module, _ = app_modules
    poor = join_agent(client, "poor")
    match = client.post("/api/matches", json={"entry_fee": 999}).json()

    response = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(poor["token"]))

    assert response.status_code == 400
    assert response.json() == {
        "detail": {"code": "INSUFFICIENT_POINTS", "message": "Agent does not have enough points"}
    }

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )
        participants = list(session.execute(text("SELECT match_id, agent_id, seat FROM match_participants ORDER BY id")))
        match_row = session.execute(text("SELECT status, started_at FROM matches WHERE id = 1")).one()

    assert point_accounts == [(1, 100)]
    assert point_ledger == [(1, "signup_bonus", 100, 100, "agent", 1)]
    assert participants == []
    assert match_row == ("open", None)


def test_list_and_detail_matches_include_participants(client):
    alpha = join_agent(client, "alpha")
    beta = join_agent(client, "beta")

    first_match = client.post("/api/matches", json={"entry_fee": 10})
    second_match = client.post("/api/matches", json={"entry_fee": 25})
    assert first_match.status_code == 201
    assert second_match.status_code == 201

    first_match_id = first_match.json()["id"]
    second_match_id = second_match.json()["id"]

    client.post(f"/api/matches/{second_match_id}/join", headers=auth_headers(alpha["token"]))
    client.post(f"/api/matches/{second_match_id}/join", headers=auth_headers(beta["token"]))

    list_response = client.get("/api/matches")
    detail_response = client.get(f"/api/matches/{second_match_id}")

    assert list_response.status_code == 200
    assert list_response.json() == [
        {
            "id": first_match_id,
            "entry_fee": 10,
            "status": "open",
            "best_of": 3,
            "wins_required": 2,
            "current_round": 1,
            "current_round_speech": None,
            "winner_agent_id": None,
            "participants": [],
            "started_at": None,
        },
        {
            "id": second_match_id,
            "entry_fee": 25,
            "status": "in_progress",
            "best_of": 3,
            "wins_required": 2,
            "current_round": 1,
            "current_round_speech": None,
            "winner_agent_id": None,
            "participants": [
                {"agent_id": alpha["id"], "seat": "A", "match_wins": 0},
                {"agent_id": beta["id"], "seat": "B", "match_wins": 0},
            ],
            "started_at": list_response.json()[1]["started_at"],
        },
    ]

    assert detail_response.status_code == 200
    assert detail_response.json() == {
        "id": second_match_id,
        "entry_fee": 25,
        "status": "in_progress",
        "best_of": 3,
        "wins_required": 2,
        "current_round": 1,
        "current_round_speech": None,
        "winner_agent_id": None,
        "participants": [
            {"agent_id": alpha["id"], "seat": "A", "match_wins": 0},
            {"agent_id": beta["id"], "seat": "B", "match_wins": 0},
        ],
        "started_at": list_response.json()[1]["started_at"],
    }


def test_match_detail_returns_match_not_found_for_unknown_id(client):
    response = client.get("/api/matches/999")

    assert response.status_code == 404
    assert response.json() == {
        "detail": {"code": "MATCH_NOT_FOUND", "message": "Match not found"}
    }


def test_join_rejects_nonexistent_match_with_match_not_found_code(client):
    alpha = join_agent(client, "alpha")

    response = client.post("/api/matches/999/join", headers=auth_headers(alpha["token"]))

    assert response.status_code == 404
    assert response.json() == {
        "detail": {"code": "MATCH_NOT_FOUND", "message": "Match not found"}
    }


def test_join_rejects_duplicate_agent_full_match_and_non_open_match(client, app_modules):
    _, db_module, _ = app_modules
    alpha = join_agent(client, "alpha")
    beta = join_agent(client, "beta")
    gamma = join_agent(client, "gamma")

    match = client.post("/api/matches", json={"entry_fee": 10}).json()

    first_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(alpha["token"]))
    assert first_join.status_code == 200

    duplicate_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(alpha["token"]))
    assert duplicate_join.status_code == 400
    assert duplicate_join.json() == {
        "detail": {"code": "MATCH_ALREADY_JOINED", "message": "Agent already joined this match"}
    }

    second_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(beta["token"]))
    assert second_join.status_code == 200

    full_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(gamma["token"]))
    assert full_join.status_code == 400
    assert full_join.json() == {
        "detail": {"code": "MATCH_NOT_OPEN", "message": "Match is not open"}
    }

    another_match = client.post("/api/matches", json={"entry_fee": 15}).json()
    with db_module.SessionLocal() as session:
        session.execute(text("UPDATE matches SET status = 'cancelled' WHERE id = :match_id"), {"match_id": another_match["id"]})
        session.commit()

    closed_join = client.post(f"/api/matches/{another_match['id']}/join", headers=auth_headers(gamma["token"]))
    assert closed_join.status_code == 400
    assert closed_join.json() == {
        "detail": {"code": "MATCH_NOT_OPEN", "message": "Match is not open"}
    }


def test_join_match_rejects_stale_second_join_without_charging_loser(client, app_modules):
    _, db_module, _ = app_modules
    alpha = join_agent(client, "alpha")
    beta = join_agent(client, "beta")
    gamma = join_agent(client, "gamma")

    match = client.post("/api/matches", json={"entry_fee": 25}).json()

    from rps_arena.api.matches import join_match
    from rps_arena.errors import match_not_open_error
    from rps_arena.models.agent import Agent
    from rps_arena.models.match import Match

    client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(alpha["token"]))

    stale_session = db_module.SessionLocal()
    fresh_session = db_module.SessionLocal()
    try:
        stale_joiner = stale_session.get(Agent, 3)
        stale_match = stale_session.get(Match, 1)
        assert stale_match.status == "open"

        fresh_session.execute(
            text("INSERT INTO match_participants (match_id, agent_id, seat, match_wins) VALUES (1, 2, 'B', 0)")
        )
        fresh_session.execute(
            text("UPDATE matches SET status = 'in_progress', started_at = CURRENT_TIMESTAMP WHERE id = 1")
        )
        fresh_session.execute(text("UPDATE point_accounts SET balance = 75 WHERE agent_id = 2"))
        fresh_session.execute(
            text(
                "INSERT INTO point_ledger (agent_id, entry_type, amount, balance_after, reference_type, reference_id, created_at) VALUES (2, 'entry_fee', -25, 75, 'match', 1, CURRENT_TIMESTAMP)"
            )
        )
        fresh_session.commit()

        try:
            join_match(1, stale_joiner, stale_session)
        except Exception as exc:
            response = match_not_open_error()
            assert exc.status_code == response.status_code
            assert exc.detail == response.detail
            stale_session.rollback()
        else:
            raise AssertionError("Expected stale second join attempt to be rejected")
    finally:
        stale_session.close()
        fresh_session.close()

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )
        participants = list(session.execute(text("SELECT match_id, agent_id, seat FROM match_participants ORDER BY seat")))
        match_row = session.execute(text("SELECT status FROM matches WHERE id = 1")).one()

    assert point_accounts == [(1, 75), (2, 75), (3, 100)]
    assert point_ledger == [
        (1, "signup_bonus", 100, 100, "agent", 1),
        (2, "signup_bonus", 100, 100, "agent", 2),
        (3, "signup_bonus", 100, 100, "agent", 3),
        (1, "entry_fee", -25, 75, "match", 1),
        (2, "entry_fee", -25, 75, "match", 1),
    ]
    assert participants == [(1, 1, "A"), (1, 2, "B")]
    assert match_row == ("in_progress",)


def test_second_join_rolls_back_participant_and_points_if_status_changes_before_start(client, app_modules):
    _, db_module, _ = app_modules
    alpha = join_agent(client, "alpha")
    beta = join_agent(client, "beta")

    match = client.post("/api/matches", json={"entry_fee": 25}).json()
    first_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(alpha["token"]))
    assert first_join.status_code == 200

    from rps_arena.api.matches import join_match
    from rps_arena.errors import match_not_open_error
    from rps_arena.models.agent import Agent

    join_session = db_module.SessionLocal()
    original_execute = join_session.execute
    forced_zero_rowcount = False

    class ZeroRowcountResult:
        rowcount = 0

    def execute_with_failed_status_flip(statement, *args, **kwargs):
        nonlocal forced_zero_rowcount
        if not forced_zero_rowcount and getattr(statement, "table", None) is not None:
            if getattr(statement.table, "name", None) == "matches":
                forced_zero_rowcount = True
                return ZeroRowcountResult()

        result = original_execute(statement, *args, **kwargs)
        return result

    join_session.execute = execute_with_failed_status_flip
    try:
        beta_agent = join_session.get(Agent, 2)
        try:
            join_match(1, beta_agent, join_session)
        except Exception as exc:
            response = match_not_open_error()
            assert exc.status_code == response.status_code
            assert exc.detail == response.detail
            join_session.rollback()
        else:
            raise AssertionError("Expected second join to roll back when status changes before start")
    finally:
        join_session.close()

    with db_module.SessionLocal() as session:
        point_accounts = list(session.execute(text("SELECT agent_id, balance FROM point_accounts ORDER BY agent_id")))
        point_ledger = list(
            session.execute(
                text(
                    "SELECT agent_id, entry_type, amount, balance_after, reference_type, reference_id FROM point_ledger ORDER BY id"
                )
            )
        )
        participants = list(session.execute(text("SELECT match_id, agent_id, seat FROM match_participants ORDER BY seat")))
        match_row = session.execute(text("SELECT status, started_at FROM matches WHERE id = 1")).one()

    assert point_accounts == [(1, 75), (2, 100)]
    assert point_ledger == [
        (1, "signup_bonus", 100, 100, "agent", 1),
        (2, "signup_bonus", 100, 100, "agent", 2),
        (1, "entry_fee", -25, 75, "match", 1),
    ]
    assert participants == [(1, 1, "A")]
    assert match_row == ("open", None)
