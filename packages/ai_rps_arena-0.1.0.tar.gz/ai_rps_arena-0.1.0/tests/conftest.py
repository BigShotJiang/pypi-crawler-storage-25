import importlib
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def database_path(tmp_path, monkeypatch) -> Path:
    db_path = tmp_path / "test.db"
    monkeypatch.setenv("APP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("APP_POINTS_ENABLED", "true")
    return db_path


@pytest.fixture
def app_modules(database_path):
    for module_name in (
        "rps_arena.main",
        "rps_arena.db",
        "rps_arena.config",
        "rps_arena.api",
        "rps_arena.api.deps",
        "rps_arena.api.agents",
        "rps_arena.api.matches",
        "rps_arena.models",
        "rps_arena.models.agent",
        "rps_arena.models.match",
        "rps_arena.models.points",
        "rps_arena.schemas.common",
        "rps_arena.schemas.agent",
        "rps_arena.schemas.match",
        "rps_arena.services.matches",
        "rps_arena.services.points",
        "rps_arena.services.rps",
        "rps_arena.services.auth",
        "rps_arena.errors",
    ):
        sys.modules.pop(module_name, None)

    config_module = importlib.import_module("rps_arena.config")
    db_module = importlib.import_module("rps_arena.db")
    main_module = importlib.import_module("rps_arena.main")
    return config_module, db_module, main_module


@pytest.fixture
def client(app_modules):
    _, _, main_module = app_modules
    with TestClient(main_module.app) as test_client:
        yield test_client


def auth_headers(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def join_agent(client: TestClient, name: str) -> dict:
    response = client.post("/api/agents/join", json={"name": name})
    assert response.status_code == 201
    return response.json()


def setup_started_match(client: TestClient) -> tuple[dict, dict, dict]:
    alpha = join_agent(client, "alpha")
    beta = join_agent(client, "beta")
    match_response = client.post("/api/matches", json={"entry_fee": 10})
    assert match_response.status_code == 201
    match = match_response.json()

    first_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(alpha["token"]))
    second_join = client.post(f"/api/matches/{match['id']}/join", headers=auth_headers(beta["token"]))
    assert first_join.status_code == 200
    assert second_join.status_code == 200

    return alpha, beta, match
