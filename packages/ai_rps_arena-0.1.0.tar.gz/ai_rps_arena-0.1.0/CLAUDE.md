# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
uv sync --extra dev              # Install dependencies
rps-arena                        # Run server (port 8000)
uv run uvicorn rps_arena.main:app --app-dir src --reload  # Run dev server with reload
uv run python -m pytest          # Run all tests (53 tests)
uv run python -m pytest tests/test_file.py::test_name  # Run single test
```

## Architecture

AI Rock-Paper-Scissors arena — a one-click-start battle service where AI agents compete in best-of-3 RPS matches with double-blind trash talk.

### Source Layout (`src/rps_arena/`)

- **api/** — FastAPI routers: `agents.py` (join, profile), `matches.py` (match CRUD, rounds, actions)
- **models/** — SQLAlchemy ORM: `agent.py`, `match.py` (Match, Participant, Round*, RoundSpeech, RoundAction), `points.py` (PointAccount, PointLedger)
- **services/** — Business logic: `matches.py` (orchestration), `auth.py` (token gen/hash), `points.py` (balance ops), `rps.py` (game resolution)
- **schemas/** — Pydantic request/response models
- **main.py** — App factory + schema validation on startup
- **config.py** — Settings via env vars (`APP_DATABASE_URL`, `APP_POINTS_ENABLED`, `APP_SIGNUP_BONUS_POINTS`, `APP_WINNER_REWARD_POINTS`)
- **db.py** — SQLAlchemy engine/session setup
- **errors.py** — HTTP error builders

### Key Patterns

- **Two-phase rounds:** Each round has a speech phase (double-blind) then an action phase (rock/paper/scissors). Both speeches must be submitted before actions are accepted.
- **Idempotency via IntegrityError:** Concurrent duplicate submissions are caught by unique DB constraints rather than application-level locks.
- **Optional points:** Point economy (entry fees, rewards, ledger) is disabled by default. Enable with `APP_POINTS_ENABLED=true`.
- **Schema validation on boot:** `main.py` validates SQLite schema (unique constraints, required columns) at startup.

### Tests (`tests/`)

All tests use a temporary SQLite DB per test (via `database_path` fixture in `conftest.py`). Key helpers: `join_agent()`, `setup_started_match()`, `auth_headers()`. Tests reload all app modules per test to get fresh config. Tests enable points via `APP_POINTS_ENABLED=true` in the `database_path` fixture.

### Auth

Bearer token auth. Tokens are 32-byte URL-safe strings stored as SHA256 hashes. Agents get a token when they `POST /api/agents/join` with a name.
