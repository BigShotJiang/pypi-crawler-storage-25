# AI RPS Platform Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a backend-only AI agent rock-paper-scissors platform with agent registration, API key auth, 1v1 best-of-3 matches, point deductions, and winner rewards.

**Architecture:** Use a single FastAPI service with SQLAlchemy models and a SQLite database for the MVP. Match state is stored in relational tables, while the fixed rock-paper-scissors rule is implemented as a small synchronous service that resolves a round as soon as both agents submit an action.

**Tech Stack:** Python 3.13, FastAPI, SQLAlchemy 2.x, Pydantic v2, pytest, httpx, SQLite

---

## File Structure

**Create**
- `pyproject.toml`
- `README.md`
- `src/app/__init__.py`
- `src/app/main.py`
- `src/app/config.py`
- `src/app/db.py`
- `src/app/errors.py`
- `src/app/models/__init__.py`
- `src/app/models/agent.py`
- `src/app/models/points.py`
- `src/app/models/match.py`
- `src/app/schemas/__init__.py`
- `src/app/schemas/common.py`
- `src/app/schemas/agent.py`
- `src/app/schemas/match.py`
- `src/app/api/__init__.py`
- `src/app/api/deps.py`
- `src/app/api/agents.py`
- `src/app/api/matches.py`
- `src/app/services/__init__.py`
- `src/app/services/auth.py`
- `src/app/services/points.py`
- `src/app/services/rps.py`
- `src/app/services/matches.py`
- `tests/conftest.py`
- `tests/test_agents.py`
- `tests/test_points.py`
- `tests/test_match_join.py`
- `tests/test_match_actions.py`
- `tests/test_match_results.py`

**Responsibilities**
- `main.py`: create FastAPI app, include routers, create tables on startup for local MVP
- `db.py`: engine, session factory, declarative base
- `errors.py`: application errors and API error response helpers
- `models/agent.py`: `Agent` model
- `models/points.py`: `PointAccount` and `PointLedger` models
- `models/match.py`: `Match`, `MatchParticipant`, `RoundAction`, `RoundResult` models
- `schemas/agent.py`: request and response schemas for registration and auth-bound agent reads
- `schemas/match.py`: request and response schemas for join, action submission, match and round results
- `api/deps.py`: DB session and current-agent dependency
- `api/agents.py`: `/api/agents/*`
- `api/matches.py`: `/api/matches/*`
- `services/auth.py`: API key generation, hashing, lookup
- `services/points.py`: signup bonus, entry fee deduction, reward payout, ledger writing
- `services/rps.py`: action validation and winner resolution
- `services/matches.py`: join flow, auto-start, submit action, round settlement, match finish
- `tests/*`: route-level integration tests and focused service assertions

### Task 1: Scaffold the service and test harness

**Files:**
- Create: `pyproject.toml`
- Create: `README.md`
- Create: `src/app/__init__.py`
- Create: `src/app/main.py`
- Create: `src/app/config.py`
- Create: `src/app/db.py`
- Create: `tests/conftest.py`
- Test: `tests/test_agents.py`

- [ ] **Step 1: Initialize git so later commit steps work**

Run: `git init`
Expected: `Initialized empty Git repository`

- [ ] **Step 2: Write the failing smoke test for the health endpoint**

```python
# tests/test_agents.py
def test_healthcheck(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
```

- [ ] **Step 3: Add project metadata and dependencies**

```toml
# pyproject.toml
[project]
name = "rps-arena"
version = "0.1.0"
requires-python = ">=3.13"
dependencies = [
  "fastapi>=0.116,<0.117",
  "uvicorn>=0.35,<0.36",
  "sqlalchemy>=2.0,<2.1",
  "pydantic>=2.11,<2.12",
]

[project.optional-dependencies]
dev = [
  "pytest>=8.3,<8.4",
  "httpx>=0.28,<0.29",
]

[tool.pytest.ini_options]
pythonpath = ["src"]
```

- [ ] **Step 4: Create the minimal app and DB bootstrap**

```python
# src/app/config.py
from pydantic import BaseModel


class Settings(BaseModel):
    database_url: str = "sqlite:///./app.db"
    signup_bonus_points: int = 100
    winner_reward_points: int = 20


settings = Settings()
```

```python
# src/app/db.py
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from app.config import settings


class Base(DeclarativeBase):
    pass


engine = create_engine(settings.database_url, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
```

```python
# src/app/main.py
from fastapi import FastAPI

from app.db import Base, engine

app = FastAPI()


@app.on_event("startup")
def create_tables() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/health")
def healthcheck() -> dict[str, str]:
    return {"status": "ok"}
```

```python
# tests/conftest.py
import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client():
    with TestClient(app) as test_client:
        yield test_client
```

- [ ] **Step 5: Run the smoke test to verify it passes**

Run: `pytest tests/test_agents.py::test_healthcheck -v`
Expected: `PASSED`

- [ ] **Step 6: Commit the scaffold**

```bash
git add pyproject.toml README.md src tests
git commit -m "chore: scaffold fastapi service"
```

### Task 2: Implement agent registration and API key authentication

**Files:**
- Create: `src/app/errors.py`
- Create: `src/app/models/agent.py`
- Create: `src/app/models/__init__.py`
- Create: `src/app/schemas/common.py`
- Create: `src/app/schemas/agent.py`
- Create: `src/app/api/__init__.py`
- Create: `src/app/api/deps.py`
- Create: `src/app/api/agents.py`
- Create: `src/app/services/auth.py`
- Modify: `src/app/main.py`
- Modify: `tests/conftest.py`
- Test: `tests/test_agents.py`

- [ ] **Step 1: Write the failing registration and `/me` tests**

```python
# tests/test_agents.py
def test_register_agent_returns_api_key(client):
    response = client.post("/api/agents/register", json={"name": "alpha"})
    body = response.json()

    assert response.status_code == 201
    assert body["name"] == "alpha"
    assert body["points_balance"] == 100
    assert isinstance(body["api_key"], str)
    assert len(body["api_key"]) > 10


def test_me_returns_current_agent(client):
    register = client.post("/api/agents/register", json={"name": "alpha"}).json()
    response = client.get(
        "/api/agents/me",
        headers={"Authorization": f"Bearer {register['api_key']}"},
    )

    assert response.status_code == 200
    assert response.json()["name"] == "alpha"
```

- [ ] **Step 2: Run the registration test to verify it fails**

Run: `pytest tests/test_agents.py::test_register_agent_returns_api_key -v`
Expected: FAIL with `404 Not Found`

- [ ] **Step 3: Add error helpers, agent model, schemas, and auth service**

```python
# src/app/errors.py
from fastapi import HTTPException


def api_error(code: str, message: str, status_code: int) -> HTTPException:
    return HTTPException(status_code=status_code, detail={"code": code, "message": message})
```

```python
# src/app/models/agent.py
from datetime import datetime

from sqlalchemy import DateTime, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base


class Agent(Base):
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True)
    api_key_hash: Mapped[str] = mapped_column(String(128), unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
```

```python
# src/app/models/__init__.py
from app.models.agent import Agent
```

```python
# src/app/schemas/common.py
from pydantic import BaseModel


class ErrorDetail(BaseModel):
    code: str
    message: str
```

```python
# src/app/schemas/agent.py
from pydantic import BaseModel


class RegisterAgentRequest(BaseModel):
    name: str


class AgentResponse(BaseModel):
    id: int
    name: str
    points_balance: int


class RegisterAgentResponse(AgentResponse):
    api_key: str
```

```python
# src/app/services/auth.py
import hashlib
import secrets

from sqlalchemy.orm import Session

from app.models.agent import Agent


def generate_api_key() -> str:
    return secrets.token_urlsafe(24)


def hash_api_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


def get_agent_by_api_key(db: Session, api_key: str) -> Agent | None:
    return db.query(Agent).filter(Agent.api_key_hash == hash_api_key(api_key)).one_or_none()
```

- [ ] **Step 4: Add points model stub, agent router, dependency, and wire routes into the app**

```python
# src/app/models/points.py
from sqlalchemy import ForeignKey, Integer
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base


class PointAccount(Base):
    __tablename__ = "point_accounts"

    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), primary_key=True)
    balance: Mapped[int] = mapped_column(Integer, default=0)
```

```python
# src/app/api/deps.py
from fastapi import Depends, Header
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.errors import api_error
from app.services.auth import get_agent_by_api_key


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_current_agent(authorization: str = Header(...), db: Session = Depends(get_db)):
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise api_error("UNAUTHORIZED", "Missing bearer token", 401)
    agent = get_agent_by_api_key(db, token)
    if agent is None:
        raise api_error("INVALID_API_KEY", "Invalid API key", 401)
    return agent
```

```python
# src/app/api/agents.py
from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_agent, get_db
from app.config import settings
from app.models.agent import Agent
from app.models.points import PointAccount
from app.schemas.agent import AgentResponse, RegisterAgentRequest, RegisterAgentResponse
from app.services.auth import generate_api_key, hash_api_key

router = APIRouter(prefix="/api/agents", tags=["agents"])


@router.post("/register", response_model=RegisterAgentResponse, status_code=status.HTTP_201_CREATED)
def register_agent(payload: RegisterAgentRequest, db: Session = Depends(get_db)):
    api_key = generate_api_key()
    agent = Agent(name=payload.name, api_key_hash=hash_api_key(api_key))
    db.add(agent)
    db.flush()
    account = PointAccount(agent_id=agent.id, balance=settings.signup_bonus_points)
    db.add(account)
    db.commit()
    return RegisterAgentResponse(id=agent.id, name=agent.name, api_key=api_key, points_balance=account.balance)


@router.get("/me", response_model=AgentResponse)
def get_me(agent=Depends(get_current_agent), db: Session = Depends(get_db)):
    account = db.get(PointAccount, agent.id)
    return AgentResponse(id=agent.id, name=agent.name, points_balance=account.balance)
```

```python
# src/app/main.py
from fastapi import FastAPI

from app.api.agents import router as agents_router
from app.db import Base, engine
from app.models import Agent
from app.models.points import PointAccount

app = FastAPI()
app.include_router(agents_router)


@app.on_event("startup")
def create_tables() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/health")
def healthcheck() -> dict[str, str]:
    return {"status": "ok"}
```

- [ ] **Step 5: Use an isolated SQLite file per test run**

```python
# tests/conftest.py
import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app import db as app_db
from app.config import settings


@pytest.fixture(autouse=True)
def use_test_database(tmp_path):
    settings.database_url = f"sqlite:///{tmp_path / 'test.db'}"
    test_engine = create_engine(settings.database_url, connect_args={"check_same_thread": False})
    app_db.engine = test_engine
    app_db.SessionLocal = sessionmaker(bind=test_engine, autoflush=False, autocommit=False)
    app_db.Base.metadata.create_all(bind=test_engine)
    yield
    app_db.Base.metadata.drop_all(bind=test_engine)
    if os.path.exists(tmp_path / "test.db"):
        os.remove(tmp_path / "test.db")


@pytest.fixture
def client():
    from app.main import app

    with TestClient(app) as test_client:
        yield test_client
```

- [ ] **Step 6: Run the agent tests to verify they pass**

Run: `pytest tests/test_agents.py -v`
Expected: `3 passed`

- [ ] **Step 7: Commit the agent/auth work**

```bash
git add src tests pyproject.toml
git commit -m "feat: add agent registration and auth"
```

### Task 3: Add point ledger and match joining

**Files:**
- Create: `src/app/models/match.py`
- Create: `src/app/services/points.py`
- Create: `src/app/schemas/match.py`
- Create: `src/app/api/matches.py`
- Modify: `src/app/models/points.py`
- Modify: `src/app/models/__init__.py`
- Modify: `src/app/main.py`
- Test: `tests/test_points.py`
- Test: `tests/test_match_join.py`

- [ ] **Step 1: Write the failing tests for signup ledger, join success, and insufficient points**

```python
# tests/test_points.py
def test_register_creates_signup_ledger_entry(client):
    register = client.post("/api/agents/register", json={"name": "alpha"})
    body = register.json()
    assert register.status_code == 201
    assert body["points_balance"] == 100
```

```python
# tests/test_match_join.py
def test_two_agents_can_join_match_and_match_starts(client):
    alpha = client.post("/api/agents/register", json={"name": "alpha"}).json()
    beta = client.post("/api/agents/register", json={"name": "beta"}).json()
    match = client.post("/api/matches", json={"entry_fee": 10}).json()

    first = client.post(
        f"/api/matches/{match['id']}/join",
        headers={"Authorization": f"Bearer {alpha['api_key']}"},
    )
    second = client.post(
        f"/api/matches/{match['id']}/join",
        headers={"Authorization": f"Bearer {beta['api_key']}"},
    )

    assert first.status_code == 200
    assert second.status_code == 200
    assert second.json()["status"] == "in_progress"


def test_join_rejects_agent_without_enough_points(client):
    poor = client.post("/api/agents/register", json={"name": "poor"}).json()
    match = client.post("/api/matches", json={"entry_fee": 999}).json()

    response = client.post(
        f"/api/matches/{match['id']}/join",
        headers={"Authorization": f"Bearer {poor['api_key']}"},
    )

    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "INSUFFICIENT_POINTS"
```

- [ ] **Step 2: Run the join test to verify it fails**

Run: `pytest tests/test_match_join.py::test_two_agents_can_join_match_and_match_starts -v`
Expected: FAIL with `404 Not Found`

- [ ] **Step 3: Add point ledger, match models, and schemas**

```python
# src/app/models/points.py
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base


class PointAccount(Base):
    __tablename__ = "point_accounts"

    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), primary_key=True)
    balance: Mapped[int] = mapped_column(Integer, default=0)


class PointLedger(Base):
    __tablename__ = "point_ledger"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"))
    entry_type: Mapped[str] = mapped_column(String(32))
    amount: Mapped[int] = mapped_column(Integer)
    balance_after: Mapped[int] = mapped_column(Integer)
    reference_type: Mapped[str] = mapped_column(String(32))
    reference_id: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
```

```python
# src/app/models/match.py
from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from app.db import Base


class Match(Base):
    __tablename__ = "matches"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    status: Mapped[str] = mapped_column(String(32), default="open")
    entry_fee: Mapped[int] = mapped_column(Integer)
    best_of: Mapped[int] = mapped_column(Integer, default=3)
    wins_required: Mapped[int] = mapped_column(Integer, default=2)
    current_round: Mapped[int] = mapped_column(Integer, default=1)
    winner_agent_id: Mapped[int | None] = mapped_column(ForeignKey("agents.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class MatchParticipant(Base):
    __tablename__ = "match_participants"
    __table_args__ = (
        UniqueConstraint("match_id", "agent_id"),
        UniqueConstraint("match_id", "seat"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"))
    seat: Mapped[str] = mapped_column(String(1))
    match_wins: Mapped[int] = mapped_column(Integer, default=0)
```

```python
# src/app/schemas/match.py
from pydantic import BaseModel


class CreateMatchRequest(BaseModel):
    entry_fee: int


class MatchResponse(BaseModel):
    id: int
    status: str
    entry_fee: int
    current_round: int
    best_of: int
    wins_required: int
    winner_agent_id: int | None
```

- [ ] **Step 4: Implement points service and match create/join routes**

```python
# src/app/services/points.py
from sqlalchemy.orm import Session

from app.models.points import PointAccount, PointLedger


def apply_points(db: Session, agent_id: int, amount: int, entry_type: str, reference_type: str, reference_id: int) -> PointAccount:
    account = db.get(PointAccount, agent_id)
    account.balance += amount
    ledger = PointLedger(
        agent_id=agent_id,
        entry_type=entry_type,
        amount=amount,
        balance_after=account.balance,
        reference_type=reference_type,
        reference_id=reference_id,
    )
    db.add(ledger)
    return account
```

```python
# src/app/api/matches.py
from datetime import datetime

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_agent, get_db
from app.errors import api_error
from app.models.match import Match, MatchParticipant
from app.models.points import PointAccount
from app.schemas.match import CreateMatchRequest, MatchResponse
from app.services.points import apply_points

router = APIRouter(prefix="/api/matches", tags=["matches"])


@router.post("", response_model=MatchResponse, status_code=status.HTTP_201_CREATED)
def create_match(payload: CreateMatchRequest, db: Session = Depends(get_db)):
    match = Match(entry_fee=payload.entry_fee)
    db.add(match)
    db.commit()
    db.refresh(match)
    return match


@router.post("/{match_id}/join", response_model=MatchResponse)
def join_match(match_id: int, agent=Depends(get_current_agent), db: Session = Depends(get_db)):
    match = db.get(Match, match_id)
    if match is None:
        raise api_error("MATCH_NOT_FOUND", "Match not found", 404)
    if match.status != "open":
        raise api_error("MATCH_NOT_OPEN", "Match is not open", 400)
    if db.query(MatchParticipant).filter_by(match_id=match_id, agent_id=agent.id).first():
        raise api_error("ALREADY_JOINED", "Agent already joined", 400)
    participant_count = db.query(MatchParticipant).filter_by(match_id=match_id).count()
    if participant_count >= 2:
        raise api_error("MATCH_FULL", "Match already has two participants", 400)

    account = db.get(PointAccount, agent.id)
    if account.balance < match.entry_fee:
        raise api_error("INSUFFICIENT_POINTS", "Not enough points to join this match", 400)

    seat = "A" if participant_count == 0 else "B"
    db.add(MatchParticipant(match_id=match_id, agent_id=agent.id, seat=seat))
    apply_points(db, agent.id, -match.entry_fee, "entry_fee", "match", match.id)

    if participant_count == 1:
        match.status = "in_progress"
        match.started_at = datetime.utcnow()

    db.commit()
    db.refresh(match)
    return match
```

```python
# src/app/main.py
from fastapi import FastAPI

from app.api.agents import router as agents_router
from app.api.matches import router as matches_router
from app.db import Base, engine
from app.models.agent import Agent
from app.models.match import Match, MatchParticipant
from app.models.points import PointAccount, PointLedger

app = FastAPI()
app.include_router(agents_router)
app.include_router(matches_router)


@app.on_event("startup")
def create_tables() -> None:
    Base.metadata.create_all(bind=engine)


@app.get("/health")
def healthcheck() -> dict[str, str]:
    return {"status": "ok"}
```

- [ ] **Step 5: Run the point and join tests to verify they pass**

Run: `pytest tests/test_points.py tests/test_match_join.py -v`
Expected: `3 passed`

- [ ] **Step 6: Commit the points and join flow**

```bash
git add src tests
git commit -m "feat: add points ledger and match joining"
```

### Task 4: Implement round actions and RPS settlement

**Files:**
- Modify: `src/app/models/match.py`
- Modify: `src/app/schemas/match.py`
- Create: `src/app/services/rps.py`
- Create: `src/app/services/matches.py`
- Modify: `src/app/api/matches.py`
- Modify: `tests/conftest.py`
- Test: `tests/test_match_actions.py`
- Test: `tests/test_match_results.py`

- [ ] **Step 1: Write the failing tests for action submit, round win, draw, and match finish**

```python
# tests/conftest.py
def setup_started_match(client):
    alpha = client.post("/api/agents/register", json={"name": "alpha"}).json()
    beta = client.post("/api/agents/register", json={"name": "beta"}).json()
    match = client.post("/api/matches", json={"entry_fee": 10}).json()
    client.post(f"/api/matches/{match['id']}/join", headers={"Authorization": f"Bearer {alpha['api_key']}"})
    client.post(f"/api/matches/{match['id']}/join", headers={"Authorization": f"Bearer {beta['api_key']}"})
    return alpha, beta, match
```

```python
# tests/test_match_actions.py
def test_second_action_submission_settles_round(client):
    alpha, beta, match = setup_started_match(client)
    first = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "rock"},
        headers={"Authorization": f"Bearer {alpha['api_key']}"},
    )
    second = client.post(
        f"/api/matches/{match['id']}/rounds/1/action",
        json={"action": "scissors"},
        headers={"Authorization": f"Bearer {beta['api_key']}"},
    )

    assert first.status_code == 202
    assert second.status_code == 200
    assert second.json()["winner_agent_id"] == alpha["id"]


def test_draw_advances_to_next_round_without_winner(client):
    alpha, beta, match = setup_started_match(client)
    client.post(f"/api/matches/{match['id']}/rounds/1/action", json={"action": "rock"}, headers={"Authorization": f"Bearer {alpha['api_key']}"})
    response = client.post(f"/api/matches/{match['id']}/rounds/1/action", json={"action": "rock"}, headers={"Authorization": f"Bearer {beta['api_key']}"})

    assert response.status_code == 200
    assert response.json()["outcome"] == "draw"
```

```python
# tests/test_match_results.py
def test_match_finishes_when_agent_reaches_two_wins(client):
    alpha, beta, match = setup_started_match(client)

    client.post(f"/api/matches/{match['id']}/rounds/1/action", json={"action": "rock"}, headers={"Authorization": f"Bearer {alpha['api_key']}"})
    client.post(f"/api/matches/{match['id']}/rounds/1/action", json={"action": "scissors"}, headers={"Authorization": f"Bearer {beta['api_key']}"})
    client.post(f"/api/matches/{match['id']}/rounds/2/action", json={"action": "paper"}, headers={"Authorization": f"Bearer {alpha['api_key']}"})
    client.post(f"/api/matches/{match['id']}/rounds/2/action", json={"action": "rock"}, headers={"Authorization": f"Bearer {beta['api_key']}"})

    result = client.get(f"/api/matches/{match['id']}/result")
    assert result.status_code == 200
    assert result.json()["status"] == "finished"
    assert result.json()["winner_agent_id"] == alpha["id"]
```

- [ ] **Step 2: Run one action test to verify it fails**

Run: `pytest tests/test_match_actions.py::test_second_action_submission_settles_round -v`
Expected: FAIL with `404 Not Found`

- [ ] **Step 3: Add action/result models and RPS resolution logic**

```python
# src/app/models/match.py
class RoundAction(Base):
    __tablename__ = "round_actions"
    __table_args__ = (UniqueConstraint("match_id", "round_number", "agent_id"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    round_number: Mapped[int] = mapped_column(Integer)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"))
    action: Mapped[str] = mapped_column(String(16))
    submitted_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class RoundResult(Base):
    __tablename__ = "round_results"
    __table_args__ = (UniqueConstraint("match_id", "round_number"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    match_id: Mapped[int] = mapped_column(ForeignKey("matches.id"))
    round_number: Mapped[int] = mapped_column(Integer)
    outcome: Mapped[str] = mapped_column(String(32))
    winner_agent_id: Mapped[int | None] = mapped_column(ForeignKey("agents.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
```

```python
# src/app/services/rps.py
VALID_ACTIONS = {"rock", "paper", "scissors"}


def resolve_round(action_a: str, action_b: str) -> str:
    if action_a == action_b:
        return "draw"
    if (action_a, action_b) in {("rock", "scissors"), ("scissors", "paper"), ("paper", "rock")}:
        return "agent_a_win"
    return "agent_b_win"
```

- [ ] **Step 4: Implement action submission and synchronous settlement**

```python
# src/app/services/matches.py
from datetime import datetime

from sqlalchemy.orm import Session

from app.config import settings
from app.errors import api_error
from app.models.match import Match, MatchParticipant, RoundAction, RoundResult
from app.services.points import apply_points
from app.services.rps import VALID_ACTIONS, resolve_round


def submit_action(db: Session, match: Match, agent_id: int, round_number: int, action: str):
    if match.status != "in_progress":
        raise api_error("MATCH_FINISHED", "Match is not in progress", 400)
    if round_number != match.current_round:
        raise api_error("INVALID_ROUND", "Round is not open", 400)
    if action not in VALID_ACTIONS:
        raise api_error("INVALID_ACTION", "Action must be rock, paper, or scissors", 400)
    if db.query(MatchParticipant).filter_by(match_id=match.id, agent_id=agent_id).first() is None:
        raise api_error("UNAUTHORIZED", "Agent is not a participant", 403)
    if db.query(RoundAction).filter_by(match_id=match.id, round_number=round_number, agent_id=agent_id).first():
        raise api_error("ROUND_ALREADY_SUBMITTED", "Action already submitted", 400)

    db.add(RoundAction(match_id=match.id, round_number=round_number, agent_id=agent_id, action=action))
    db.flush()
    actions = db.query(RoundAction).filter_by(match_id=match.id, round_number=round_number).all()
    if len(actions) < 2:
        db.commit()
        return None

    participants = db.query(MatchParticipant).filter_by(match_id=match.id).order_by(MatchParticipant.seat).all()
    action_map = {item.agent_id: item.action for item in actions}
    outcome = resolve_round(action_map[participants[0].agent_id], action_map[participants[1].agent_id])
    winner_agent_id = None
    if outcome == "agent_a_win":
        participants[0].match_wins += 1
        winner_agent_id = participants[0].agent_id
    elif outcome == "agent_b_win":
        participants[1].match_wins += 1
        winner_agent_id = participants[1].agent_id

    db.add(RoundResult(match_id=match.id, round_number=round_number, outcome=outcome, winner_agent_id=winner_agent_id))
    winner = next((p for p in participants if p.match_wins >= match.wins_required), None)
    if winner:
        match.status = "finished"
        match.winner_agent_id = winner.agent_id
        match.finished_at = datetime.utcnow()
        apply_points(db, winner.agent_id, settings.winner_reward_points, "match_reward", "match", match.id)
    else:
        match.current_round += 1
    db.commit()
    return db.query(RoundResult).filter_by(match_id=match.id, round_number=round_number).one()
```

```python
# src/app/schemas/match.py
from pydantic import BaseModel


class ActionRequest(BaseModel):
    action: str


class RoundResultResponse(BaseModel):
    match_id: int
    round_number: int
    outcome: str
    winner_agent_id: int | None
```

```python
# src/app/api/matches.py
from fastapi import APIRouter, Depends, Response, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_agent, get_db
from app.models.match import Match, RoundResult
from app.schemas.match import ActionRequest, MatchResponse, RoundResultResponse
from app.services.matches import submit_action


@router.post("/{match_id}/rounds/{round_number}/action", response_model=RoundResultResponse, status_code=200)
def submit_match_action(match_id: int, round_number: int, payload: ActionRequest, response: Response, agent=Depends(get_current_agent), db: Session = Depends(get_db)):
    match = db.get(Match, match_id)
    result = submit_action(db, match, agent.id, round_number, payload.action)
    if result is None:
        response.status_code = status.HTTP_202_ACCEPTED
        return {"match_id": match_id, "round_number": round_number, "outcome": "pending", "winner_agent_id": None}
    return result


@router.get("/{match_id}/result", response_model=MatchResponse)
def get_match_result(match_id: int, db: Session = Depends(get_db)):
    return db.get(Match, match_id)


@router.get("/{match_id}/rounds/{round_number}/result", response_model=RoundResultResponse)
def get_round_result(match_id: int, round_number: int, db: Session = Depends(get_db)):
    return db.query(RoundResult).filter_by(match_id=match_id, round_number=round_number).one()
```

- [ ] **Step 5: Run the round and result tests to verify they pass**

Run: `pytest tests/test_match_actions.py tests/test_match_results.py -v`
Expected: `3 passed`

- [ ] **Step 6: Commit the match settlement work**

```bash
git add src tests
git commit -m "feat: add rock paper scissors settlement"
```

### Task 5: Add match detail endpoints and final integration coverage

**Files:**
- Modify: `src/app/schemas/match.py`
- Modify: `src/app/api/matches.py`
- Modify: `tests/test_match_join.py`
- Modify: `tests/test_match_results.py`
- Create: `README.md`

- [ ] **Step 1: Write the failing tests for match detail and duplicate submission rejection**

```python
# tests/test_match_join.py
def test_match_detail_includes_participants(client):
    alpha, beta, match = setup_started_match(client)
    response = client.get(f"/api/matches/{match['id']}")

    assert response.status_code == 200
    assert len(response.json()["participants"]) == 2
```

```python
# tests/test_match_results.py
def test_duplicate_round_submission_is_rejected(client):
    alpha, beta, match = setup_started_match(client)
    client.post(f"/api/matches/{match['id']}/rounds/1/action", json={"action": "rock"}, headers={"Authorization": f"Bearer {alpha['api_key']}"})
    response = client.post(f"/api/matches/{match['id']}/rounds/1/action", json={"action": "paper"}, headers={"Authorization": f"Bearer {alpha['api_key']}"})

    assert response.status_code == 400
    assert response.json()["detail"]["code"] == "ROUND_ALREADY_SUBMITTED"
```

- [ ] **Step 2: Run the match detail test to verify it fails**

Run: `pytest tests/test_match_join.py::test_match_detail_includes_participants -v`
Expected: FAIL with `404 Not Found`

- [ ] **Step 3: Expand match response payload and expose list/detail endpoints**

```python
# src/app/schemas/match.py
from pydantic import BaseModel


class ParticipantResponse(BaseModel):
    agent_id: int
    seat: str
    match_wins: int


class MatchResponse(BaseModel):
    id: int
    status: str
    entry_fee: int
    current_round: int
    best_of: int
    wins_required: int
    winner_agent_id: int | None
    participants: list[ParticipantResponse] = []
```

```python
# src/app/api/matches.py
@router.get("", response_model=list[MatchResponse])
def list_matches(db: Session = Depends(get_db)):
    matches = db.query(Match).all()
    return [serialize_match(db, match) for match in matches]


@router.get("/{match_id}", response_model=MatchResponse)
def get_match(match_id: int, db: Session = Depends(get_db)):
    match = db.get(Match, match_id)
    return serialize_match(db, match)


def serialize_match(db: Session, match: Match) -> MatchResponse:
    participants = db.query(MatchParticipant).filter_by(match_id=match.id).order_by(MatchParticipant.seat).all()
    return MatchResponse(
        id=match.id,
        status=match.status,
        entry_fee=match.entry_fee,
        current_round=match.current_round,
        best_of=match.best_of,
        wins_required=match.wins_required,
        winner_agent_id=match.winner_agent_id,
        participants=[
            ParticipantResponse(agent_id=item.agent_id, seat=item.seat, match_wins=item.match_wins)
            for item in participants
        ],
    )
```

- [ ] **Step 4: Add a runnable README with API examples**

````md
# AI RPS Platform

## Run locally

```bash
pip install -e .[dev]
uvicorn app.main:app --reload
```

## Key endpoints

- `POST /api/agents/register`
- `GET /api/agents/me`
- `POST /api/matches`
- `POST /api/matches/{id}/join`
- `POST /api/matches/{id}/rounds/{round_number}/action`
- `GET /api/matches/{id}`
- `GET /api/matches/{id}/result`
````

- [ ] **Step 5: Run the full test suite to verify the MVP passes end to end**

Run: `pytest -v`
Expected: all tests pass with no failures

- [ ] **Step 6: Commit the detail endpoints and docs**

```bash
git add README.md src tests
git commit -m "feat: finish ai rps platform mvp api"
```

## Self-Review

### Spec coverage
- Agent registration and API key auth: covered in Task 2
- Signup bonus, entry fee, winner reward, ledger: covered in Task 3 and Task 4
- 1v1 best-of-3, first to 2 wins, draw handling: covered in Task 4
- Match create/join/detail/result APIs: covered in Task 3 and Task 5
- Duplicate action rejection and invalid action handling: covered in Task 4 and Task 5

### Placeholder scan
- No `TODO`, `TBD`, or deferred implementation markers remain
- Every task includes concrete file paths, commands, and code snippets

### Type consistency
- Match state uses `Match`, `MatchParticipant`, `RoundAction`, `RoundResult` consistently across tasks
- Auth uses `Agent`, API key hash, and bearer-token lookup consistently across tasks
- Point mutations all go through `apply_points()` consistently across tasks
