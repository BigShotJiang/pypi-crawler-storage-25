# uvx Publishing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make rps-arena installable via `uvx rps-arena` by renaming the package, adding a CLI entry point, and preparing for PyPI publishing.

**Architecture:** Rename `src/app/` to `src/rps_arena/`, update all imports across source and tests, add a `cli.py` with a `main()` that runs uvicorn, wire it up via `[project.scripts]` in pyproject.toml, and add build-system metadata for hatchling.

**Tech Stack:** Python 3.13, hatchling (build), uvicorn (server), PyPI (distribution)

---

## File Structure

| Action | Path | Responsibility |
|--------|------|---------------|
| Rename | `src/app/` → `src/rps_arena/` | All existing source files |
| Create | `src/rps_arena/cli.py` | CLI entry point for `uvx rps-arena` |
| Modify | `pyproject.toml` | Build system, scripts, metadata |
| Modify | `tests/conftest.py` | Module reload list |
| Modify | `tests/test_agents.py` | Inline imports |
| Modify | `tests/test_match_actions.py` | Inline imports |
| Modify | `tests/test_match_join.py` | Inline imports |
| Modify | `tests/test_match_results.py` | Inline imports |
| Modify | `tests/test_match_speech.py` | Inline imports |
| Modify | `CLAUDE.md` | Updated commands |

---

### Task 1: Rename package directory from `app` to `rps_arena`

**Files:**
- Rename: `src/app/` → `src/rps_arena/`

- [ ] **Step 1: Rename the directory**

```bash
mv src/app src/rps_arena
```

- [ ] **Step 2: Replace all `from app.` and `import app.` in source files**

Replace every occurrence of `from app.` with `from rps_arena.` and `import app.` with `import rps_arena.` in all `.py` files under `src/rps_arena/`. Files to update:

- `src/rps_arena/__init__.py` — no `app.` imports (just a docstring)
- `src/rps_arena/api/__init__.py` — `from app.api.agents` → `from rps_arena.api.agents`
- `src/rps_arena/api/agents.py` — 8 imports starting with `app.`
- `src/rps_arena/api/deps.py` — 4 imports
- `src/rps_arena/api/matches.py` — 7 imports
- `src/rps_arena/db.py` — 1 import
- `src/rps_arena/main.py` — 5 imports
- `src/rps_arena/models/__init__.py` — 3 imports
- `src/rps_arena/models/agent.py` — 1 import
- `src/rps_arena/models/match.py` — 1 import
- `src/rps_arena/models/points.py` — 1 import
- `src/rps_arena/services/matches.py` — 6 imports
- `src/rps_arena/services/points.py` — 3 imports

Use `replace_all` on each file: `from app.` → `from rps_arena.` (covers all patterns).

- [ ] **Step 3: Commit**

```bash
git add -A
git commit -m "refactor: rename package from app to rps_arena"
```

---

### Task 2: Update test imports and module reload list

**Files:**
- Modify: `tests/conftest.py` — module reload list, change all `"app.xxx"` to `"rps_arena.xxx"`
- Modify: `tests/test_agents.py` — inline `from app.` imports
- Modify: `tests/test_match_actions.py` — inline `from app.` imports
- Modify: `tests/test_match_join.py` — inline `from app.` imports
- Modify: `tests/test_match_results.py` — inline `from app.` imports
- Modify: `tests/test_match_speech.py` — inline `from app.` imports

- [ ] **Step 1: Update conftest.py module reload list**

In `tests/conftest.py`, the `app_modules` fixture pops and reimports modules. Replace every `"app.xxx"` string with `"rps_arena.xxx"`:

```python
# Change all these module name strings:
"app.main" → "rps_arena.main"
"app.db" → "rps_arena.db"
"app.config" → "rps_arena.config"
"app.api" → "rps_arena.api"
"app.api.deps" → "rps_arena.api.deps"
"app.api.agents" → "rps_arena.api.agents"
"app.api.matches" → "rps_arena.api.matches"
"app.models" → "rps_arena.models"
"app.models.agent" → "rps_arena.models.agent"
"app.models.match" → "rps_arena.models.match"
"app.models.points" → "rps_arena.models.points"
"app.schemas.common" → "rps_arena.schemas.common"
"app.schemas.agent" → "rps_arena.schemas.agent"
"app.schemas.match" → "rps_arena.schemas.match"
"app.services.matches" → "rps_arena.services.matches"
"app.services.points" → "rps_arena.services.points"
"app.services.rps" → "rps_arena.services.rps"
"app.services.auth" → "rps_arena.services.auth"
"app.errors" → "rps_arena.errors"
```

Also update the `importlib.import_module` calls:
```python
config_module = importlib.import_module("rps_arena.config")
db_module = importlib.import_module("rps_arena.db")
main_module = importlib.import_module("rps_arena.main")
```

- [ ] **Step 2: Update inline imports in test files**

Each test file has `from app.xxx import ...` inside test functions. Replace `from app.` with `from rps_arena.` in:

- `tests/test_agents.py` — `from app.models.agent`, `from app.models.points`
- `tests/test_match_actions.py` — `from app.models.match`, `from app.services.matches`
- `tests/test_match_join.py` — `from app.api.matches`, `from app.errors`, `from app.models.agent`, `from app.models.match`
- `tests/test_match_results.py` — `from app.models.match`, `from app.services.matches`
- `tests/test_match_speech.py` — `from app.models.match`, `from app.services.matches`

- [ ] **Step 3: Run tests**

```bash
uv run python -m pytest
```

Expected: 53 passed

- [ ] **Step 4: Commit**

```bash
git add -A
git commit -m "refactor: update all test imports from app to rps_arena"
```

---

### Task 3: Add CLI entry point

**Files:**
- Create: `src/rps_arena/cli.py`

- [ ] **Step 1: Create `src/rps_arena/cli.py`**

```python
import uvicorn


def main():
    uvicorn.run("rps_arena.main:app", host="0.0.0.0", port=8000)
```

- [ ] **Step 2: Commit**

```bash
git add src/rps_arena/cli.py
git commit -m "feat: add CLI entry point for uvx"
```

---

### Task 4: Update pyproject.toml for publishing

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Update pyproject.toml**

Replace the entire file with:

```toml
[project]
name = "rps-arena"
version = "0.1.0"
description = "AI Rock-Paper-Scissors arena with trash talk"
requires-python = ">=3.13"
license = "MIT"
readme = "README.md"
dependencies = [
  "fastapi>=0.116,<0.117",
  "uvicorn>=0.35,<0.36",
  "sqlalchemy>=2.0,<2.1",
  "pydantic>=2.11,<2.12",
]

[project.optional-dependencies]
dev = [
  "pytest>=8.3,<8.4",
  "httpx>=0.28,<0.29",
]

[project.scripts]
rps-arena = "rps_arena.cli:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.pytest.ini_options]
pythonpath = ["src"]
```

- [ ] **Step 2: Create LICENSE file**

```
MIT License

Copyright (c) 2026 johnhuang316

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

- [ ] **Step 3: Verify build works**

```bash
uv build
```

Expected: Creates `dist/rps_arena-0.1.0.tar.gz` and `dist/rps_arena-0.1.0-py3-none-any.whl`

- [ ] **Step 4: Verify CLI entry point works**

```bash
uv run rps-arena &
sleep 2
curl -s http://localhost:8000/ | python -m json.tool
kill %1
```

Expected: JSON response with service info and endpoint listing.

- [ ] **Step 5: Run tests one final time**

```bash
uv run python -m pytest
```

Expected: 53 passed

- [ ] **Step 6: Commit**

```bash
git add -A
git commit -m "feat: configure pyproject.toml for PyPI publishing via uvx"
```

---

### Task 5: Update documentation

**Files:**
- Modify: `CLAUDE.md`

- [ ] **Step 1: Update CLAUDE.md commands section**

Update the commands to reflect the new CLI:

```bash
uv sync --extra dev              # Install dependencies
rps-arena                        # Run server (port 8000)
uv run uvicorn rps_arena.main:app --app-dir src --reload  # Run dev server with reload
uv run python -m pytest          # Run all tests (53 tests)
uv run python -m pytest tests/test_file.py::test_name  # Run single test
```

Also update the `--app-dir src` command in Architecture section references from `app.main:app` to `rps_arena.main:app`.

- [ ] **Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "docs: update CLAUDE.md for rps_arena package name"
```

---

### Task 6: Publish to PyPI

- [ ] **Step 1: Publish**

```bash
uv publish
```

This will prompt for PyPI credentials (or use a token configured via `UV_PUBLISH_TOKEN`).

- [ ] **Step 2: Verify**

```bash
uvx rps-arena &
sleep 3
curl -s http://localhost:8000/
kill %1
```

Expected: Server starts, root endpoint returns JSON.

- [ ] **Step 3: Push to GitHub**

```bash
git push
```
