# Changelog

## 2.36.0 (2026-04-10)

Full Changelog: [v2.35.0...v2.36.0](https://github.com/tzafon/lightcone-python/compare/v2.35.0...v2.36.0)

### Features

* add width and height attributes ([5eab34f](https://github.com/tzafon/lightcone-python/commit/5eab34f9a01f2311b9678979adbec871cf45df9d))


### Bug Fixes

* ensure file data are only sent as 1 parameter ([a75a454](https://github.com/tzafon/lightcone-python/commit/a75a4548674dfe3a18ab0119e2d2c5667e9fd12e))

## 2.35.0 (2026-04-08)

Full Changelog: [v2.34.1...v2.35.0](https://github.com/tzafon/lightcone-python/compare/v2.34.1...v2.35.0)

### Features

* **api:** api update ([80a151d](https://github.com/tzafon/lightcone-python/commit/80a151d2b981b0bf24dd8842b2fd7b510c7104c5))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([e681aff](https://github.com/tzafon/lightcone-python/commit/e681aff03ccb6acead2f70a7eadfc21e8676ae37))

## 2.34.1 (2026-03-31)

Full Changelog: [v2.34.0...v2.34.1](https://github.com/tzafon/lightcone-python/compare/v2.34.0...v2.34.1)

### Bug Fixes

* bump deps version ([d9b5c5f](https://github.com/tzafon/lightcone-python/commit/d9b5c5fd45a1e18d1706f121a26ba6c45b6bd6b1))

## 2.34.0 (2026-03-31)

Full Changelog: [v2.33.0...v2.34.0](https://github.com/tzafon/lightcone-python/compare/v2.33.0...v2.34.0)

### Features

* **api:** manual updates ([534a4c7](https://github.com/tzafon/lightcone-python/commit/534a4c7eb43a8af453d1d018551ff146adba6c36))

## 2.33.0 (2026-03-30)

Full Changelog: [v2.32.0...v2.33.0](https://github.com/tzafon/lightcone-python/compare/v2.32.0...v2.33.0)

### Features

* **api:** api update ([bf9ea13](https://github.com/tzafon/lightcone-python/commit/bf9ea13191b2f59da5e31ed6bc3d9147b0bdc4aa))

## 2.32.0 (2026-03-27)

Full Changelog: [v2.31.0...v2.32.0](https://github.com/tzafon/lightcone-python/compare/v2.31.0...v2.32.0)

### Features

* **internal:** implement indices array format for query and form serialization ([e6e3298](https://github.com/tzafon/lightcone-python/commit/e6e32983edc4d913b8d620427fc3753d127d6b76))

## 2.31.0 (2026-03-24)

Full Changelog: [v2.30.0...v2.31.0](https://github.com/tzafon/lightcone-python/compare/v2.30.0...v2.31.0)

### Features

* **api:** api update ([72ebc24](https://github.com/tzafon/lightcone-python/commit/72ebc247254814c602bd44264f574f2bb58cb9f6))


### Bug Fixes

* sanitize endpoint path params ([1b7a3a9](https://github.com/tzafon/lightcone-python/commit/1b7a3a960878881f694cf261573181842987d63c))


### Chores

* **ci:** skip lint on metadata-only changes ([ed03ea8](https://github.com/tzafon/lightcone-python/commit/ed03ea86ea1e0fa64725c0373951cc78a9ee399b))
* **internal:** update gitignore ([ef01203](https://github.com/tzafon/lightcone-python/commit/ef01203a9cced7425ab1d81ff98322f3f66f6ce9))

## 2.30.0 (2026-03-16)

Full Changelog: [v2.29.2...v2.30.0](https://github.com/tzafon/lightcone-python/compare/v2.29.2...v2.30.0)

### Features

* truly async code execution for sdk ([3860502](https://github.com/tzafon/lightcone-python/commit/38605022a317b5045b09cbbc3cd207f6181e459e))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([c370a37](https://github.com/tzafon/lightcone-python/commit/c370a370429d5349426933a99ecb5352578278d7))
* **pydantic:** do not pass `by_alias` unless set ([2901016](https://github.com/tzafon/lightcone-python/commit/2901016797311a6ccea74efbe346718853634b87))


### Chores

* **internal:** tweak CI branches ([55e0284](https://github.com/tzafon/lightcone-python/commit/55e0284ae1c6b8ae93092d321f0ee993d6859c20))

## 2.29.2 (2026-03-13)

Full Changelog: [v2.29.1...v2.29.2](https://github.com/tzafon/lightcone-python/compare/v2.29.1...v2.29.2)

### Bug Fixes

* update v1 endpoint ([0b5ba5c](https://github.com/tzafon/lightcone-python/commit/0b5ba5cf2cbf5609e638951024499352d64cc9ce))

## 2.29.1 (2026-03-13)

Full Changelog: [v2.29.0...v2.29.1](https://github.com/tzafon/lightcone-python/compare/v2.29.0...v2.29.1)

### Bug Fixes

* clean up sync to lightcone ([d1f900b](https://github.com/tzafon/lightcone-python/commit/d1f900b8283606bbc93f42b9df9927d9eb7fa555))

## 2.29.0 (2026-03-12)

Full Changelog: [v2.28.0...v2.29.0](https://github.com/tzafon/lightcone-python/compare/v2.28.0...v2.29.0)

### Features

* **api:** api update ([5ff5be0](https://github.com/tzafon/lightcone-python/commit/5ff5be0cde80be2b023aaf9c5f20fa63d48da7e9))

## 2.28.0 (2026-03-11)

Full Changelog: [v2.27.1...v2.28.0](https://github.com/tzafon/lightcone-python/compare/v2.27.1...v2.28.0)

### Features

* add CI workflow ([8502c5f](https://github.com/tzafon/lightcone-python/commit/8502c5f659581e21ab21cc028ddb8d978a7fa099))
* **api:** api update ([59ebb1c](https://github.com/tzafon/lightcone-python/commit/59ebb1ce176814f14fcac64e427e290cd03709c3))

## 2.27.1 (2026-03-07)

Full Changelog: [v2.27.0...v2.27.1](https://github.com/tzafon/lightcone-python/compare/v2.27.0...v2.27.1)

### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([d840013](https://github.com/tzafon/lightcone-python/commit/d840013127fce6dd0b8b1c2575c5ffa5e6d0aa9c))

## 2.27.0 (2026-03-06)

Full Changelog: [v2.26.0...v2.27.0](https://github.com/tzafon/lightcone-python/compare/v2.26.0...v2.27.0)

### Features

* **api:** manual updates ([aebe480](https://github.com/tzafon/lightcone-python/commit/aebe480eabb7f03f7c4bb873b839a7a855e7d470))

## 2.26.0 (2026-03-06)

Full Changelog: [v2.25.0...v2.26.0](https://github.com/tzafon/lightcone-python/compare/v2.25.0...v2.26.0)

### Features

* **api:** api update ([3cd5c87](https://github.com/tzafon/lightcone-python/commit/3cd5c87d1fcba90b9be890645a3afd69cee04fc5))

## 2.25.0 (2026-03-06)

Full Changelog: [v2.24.0...v2.25.0](https://github.com/tzafon/lightcone-python/compare/v2.24.0...v2.25.0)

### Features

* **api:** api update ([66b52db](https://github.com/tzafon/lightcone-python/commit/66b52db50c3fbcad56e301a4dbcd516ee21bd6d2))

## 2.24.0 (2026-03-06)

Full Changelog: [v2.23.0...v2.24.0](https://github.com/tzafon/lightcone-python/compare/v2.23.0...v2.24.0)

### Features

* **api:** manual updates ([ca3cbab](https://github.com/tzafon/lightcone-python/commit/ca3cbab2e94b7433694726960f8ab4d846e9e3fd))

## 2.23.0 (2026-03-06)

Full Changelog: [v2.22.0...v2.23.0](https://github.com/tzafon/lightcone-python/compare/v2.22.0...v2.23.0)

### Features

* **api:** manual updates ([fa362b9](https://github.com/tzafon/lightcone-python/commit/fa362b955889e0c4f42cdb618b5f7543214cf0ad))
* **api:** manual updates ([3e6d9f4](https://github.com/tzafon/lightcone-python/commit/3e6d9f48799f9cbd60e6b69f6469c9d30f92a7fb))

## 2.22.0 (2026-03-04)

Full Changelog: [v2.21.0...v2.22.0](https://github.com/tzafon/lightcone-python/compare/v2.21.0...v2.22.0)

### Features

* add ComputerSession wrapper with backwards compat for computer-python SDK ([728dcad](https://github.com/tzafon/lightcone-python/commit/728dcaddb6782cc9aedcfeee0580fb8101790a00))
* **api:** manual updates ([cd4ae00](https://github.com/tzafon/lightcone-python/commit/cd4ae00c57f3ebb8665176ebaa0c4c7ac386be2e))


### Chores

* bump version ([07ac5f8](https://github.com/tzafon/lightcone-python/commit/07ac5f8863f30daf310e355747eb9dda7e329428))
* configure new SDK language ([3e58297](https://github.com/tzafon/lightcone-python/commit/3e58297a0e88fc39f7263784d32e82c26c4130c2))
* **internal:** refactor authentication internals ([b91c5a4](https://github.com/tzafon/lightcone-python/commit/b91c5a4723fb176537debb4de9aa359f17410c41))
* remove custom code ([e9c3c09](https://github.com/tzafon/lightcone-python/commit/e9c3c09d408456ec41318a4874593f7df7fc175a))
* remove custom code ([c69993f](https://github.com/tzafon/lightcone-python/commit/c69993f69b7c0a0e33b87827354b387751b5fdbc))
* sync repo ([3401770](https://github.com/tzafon/lightcone-python/commit/34017706731795384fb8847e244a75425cae20c5))
* update SDK settings ([6599499](https://github.com/tzafon/lightcone-python/commit/659949901b3afb7adcf4b6005fbd19d369f73ac0))
* update SDK settings ([50098db](https://github.com/tzafon/lightcone-python/commit/50098dbeb7701366ce741834ce65ee2cef6a51e9))
* update SDK settings ([3b1d089](https://github.com/tzafon/lightcone-python/commit/3b1d08920bb7f2dc707114145d0f3e43ba307a80))
* update SDK settings ([7fac1e8](https://github.com/tzafon/lightcone-python/commit/7fac1e8c56dd5c945e0346a62f3a4edda75fd2aa))
* update SDK settings ([612fe5f](https://github.com/tzafon/lightcone-python/commit/612fe5f7a9ba4e19111330c6bfa47cf3536a102c))
* update SDK settings ([94716f9](https://github.com/tzafon/lightcone-python/commit/94716f95586fb4ecbe3f94a60798da1902d05571))
* update SDK settings ([d226632](https://github.com/tzafon/lightcone-python/commit/d226632e4bafed0e2396182ca7a357938c7b2126))
* update SDK settings ([624d251](https://github.com/tzafon/lightcone-python/commit/624d25162b4cba106829a3d782d0f5f7b19ab8bd))
* update SDK settings ([a548b8a](https://github.com/tzafon/lightcone-python/commit/a548b8af93bdcdfecf60771cc8b91187c8ee5b74))
* update SDK settings ([81921ab](https://github.com/tzafon/lightcone-python/commit/81921ab0655fd91f87cd43eeafa254bccda4f608))
* update SDK settings ([a314497](https://github.com/tzafon/lightcone-python/commit/a314497bb7e39b9f47471cbc9cb9afe30c1809b9))
* update SDK settings ([d2d22fa](https://github.com/tzafon/lightcone-python/commit/d2d22fae86eb225077b903d8256574141476cd8d))
* update SDK settings ([43dd1d1](https://github.com/tzafon/lightcone-python/commit/43dd1d13e9d85cf6eeaff5ae6c58a72a43bd1a13))
* update SDK settings ([68228f1](https://github.com/tzafon/lightcone-python/commit/68228f1b65582987dbed9a26261e4472c47937f7))
* update SDK settings ([8ddc691](https://github.com/tzafon/lightcone-python/commit/8ddc691b463e6b42baaf77892487f2adae061660))
* update SDK settings ([9c3c640](https://github.com/tzafon/lightcone-python/commit/9c3c640acd820ed3a11df24ae8092373113c749d))
* update SDK settings ([feda606](https://github.com/tzafon/lightcone-python/commit/feda606c65be491513b9f162f3a4332be62f678b))

## 0.2.6 (2026-03-04)

Full Changelog: [v0.2.5...v0.2.6](https://github.com/tzafon/lightcone-python/compare/v0.2.5...v0.2.6)

## 0.2.5 (2026-03-04)

Full Changelog: [v0.2.4...v0.2.5](https://github.com/tzafon/lightcone-python/compare/v0.2.4...v0.2.5)

### Chores

* update SDK settings ([6599499](https://github.com/tzafon/lightcone-python/commit/659949901b3afb7adcf4b6005fbd19d369f73ac0))
* update SDK settings ([50098db](https://github.com/tzafon/lightcone-python/commit/50098dbeb7701366ce741834ce65ee2cef6a51e9))

## 0.2.4 (2026-03-04)

Full Changelog: [v0.2.3...v0.2.4](https://github.com/tzafon/lightcone-python/compare/v0.2.3...v0.2.4)

### Chores

* configure new SDK language ([3e58297](https://github.com/tzafon/lightcone-python/commit/3e58297a0e88fc39f7263784d32e82c26c4130c2))

## 0.2.3 (2026-03-04)

Full Changelog: [v0.2.2...v0.2.3](https://github.com/tzafon/lightcone-python/compare/v0.2.2...v0.2.3)

## 0.2.2 (2026-03-04)

Full Changelog: [v0.2.1...v0.2.2](https://github.com/tzafon/lightcone-python/compare/v0.2.1...v0.2.2)

### Chores

* update SDK settings ([3b1d089](https://github.com/tzafon/lightcone-python/commit/3b1d08920bb7f2dc707114145d0f3e43ba307a80))
* update SDK settings ([7fac1e8](https://github.com/tzafon/lightcone-python/commit/7fac1e8c56dd5c945e0346a62f3a4edda75fd2aa))

## 0.2.1 (2026-03-03)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/tzafon/lightcone-python/compare/v0.2.0...v0.2.1)

### Chores

* **internal:** refactor authentication internals ([b91c5a4](https://github.com/tzafon/lightcone-python/commit/b91c5a4723fb176537debb4de9aa359f17410c41))

## 0.2.0 (2026-03-03)

Full Changelog: [v0.1.2...v0.2.0](https://github.com/tzafon/lightcone-python/compare/v0.1.2...v0.2.0)

### Features

* add ComputerSession wrapper with backwards compat for computer-python SDK ([728dcad](https://github.com/tzafon/lightcone-python/commit/728dcaddb6782cc9aedcfeee0580fb8101790a00))

## 0.1.2 (2026-03-02)

Full Changelog: [v0.1.1...v0.1.2](https://github.com/tzafon/lightcone-python/compare/v0.1.1...v0.1.2)

### Chores

* remove custom code ([e9c3c09](https://github.com/tzafon/lightcone-python/commit/e9c3c09d408456ec41318a4874593f7df7fc175a))

## 0.1.1 (2026-03-02)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/tzafon/lightcone-python/compare/v0.1.0...v0.1.1)

### Chores

* remove custom code ([c69993f](https://github.com/tzafon/lightcone-python/commit/c69993f69b7c0a0e33b87827354b387751b5fdbc))

## 0.1.0 (2026-03-02)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/tzafon/lightcone-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([cd4ae00](https://github.com/tzafon/lightcone-python/commit/cd4ae00c57f3ebb8665176ebaa0c4c7ac386be2e))


### Chores

* sync repo ([3401770](https://github.com/tzafon/lightcone-python/commit/34017706731795384fb8847e244a75425cae20c5))
* update SDK settings ([612fe5f](https://github.com/tzafon/lightcone-python/commit/612fe5f7a9ba4e19111330c6bfa47cf3536a102c))
* update SDK settings ([94716f9](https://github.com/tzafon/lightcone-python/commit/94716f95586fb4ecbe3f94a60798da1902d05571))
* update SDK settings ([d226632](https://github.com/tzafon/lightcone-python/commit/d226632e4bafed0e2396182ca7a357938c7b2126))
* update SDK settings ([624d251](https://github.com/tzafon/lightcone-python/commit/624d25162b4cba106829a3d782d0f5f7b19ab8bd))
* update SDK settings ([a548b8a](https://github.com/tzafon/lightcone-python/commit/a548b8af93bdcdfecf60771cc8b91187c8ee5b74))
* update SDK settings ([81921ab](https://github.com/tzafon/lightcone-python/commit/81921ab0655fd91f87cd43eeafa254bccda4f608))
* update SDK settings ([a314497](https://github.com/tzafon/lightcone-python/commit/a314497bb7e39b9f47471cbc9cb9afe30c1809b9))
* update SDK settings ([d2d22fa](https://github.com/tzafon/lightcone-python/commit/d2d22fae86eb225077b903d8256574141476cd8d))
* update SDK settings ([43dd1d1](https://github.com/tzafon/lightcone-python/commit/43dd1d13e9d85cf6eeaff5ae6c58a72a43bd1a13))
* update SDK settings ([68228f1](https://github.com/tzafon/lightcone-python/commit/68228f1b65582987dbed9a26261e4472c47937f7))
* update SDK settings ([8ddc691](https://github.com/tzafon/lightcone-python/commit/8ddc691b463e6b42baaf77892487f2adae061660))
* update SDK settings ([9c3c640](https://github.com/tzafon/lightcone-python/commit/9c3c640acd820ed3a11df24ae8092373113c749d))
* update SDK settings ([feda606](https://github.com/tzafon/lightcone-python/commit/feda606c65be491513b9f162f3a4332be62f678b))
