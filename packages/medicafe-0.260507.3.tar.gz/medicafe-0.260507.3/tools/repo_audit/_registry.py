"""Check registry and result model."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, List, Optional

__all__ = ["Tier", "Result", "CheckSpec", "register_check", "checks_for_tier", "all_checks"]


class Tier(str, Enum):
    FAST = "fast"
    WEEKLY = "weekly"
    MONTHLY = "monthly"


@dataclass
class Result:
    check_id: str
    status: str  # ok | warn | fail
    summary: str
    details: List[str] = field(default_factory=list)

    @property
    def is_fail(self) -> bool:
        return self.status == "fail"

    @property
    def is_warn(self) -> bool:
        return self.status == "warn"


@dataclass
class CheckSpec:
    id: str
    tier: Tier
    description: str
    blocking: bool
    run: Callable[[], Result]


_REGISTRY: List[CheckSpec] = []


def register_check(check_id: str, tier: str, description: str, blocking: bool = True):
    """Decorator to register an audit check."""

    def decorator(fn: Callable[[], Result]):
        _REGISTRY.append(
            CheckSpec(
                id=check_id,
                tier=Tier(tier),
                description=description,
                blocking=blocking,
                run=fn,
            )
        )
        return fn

    return decorator


def all_checks() -> List[CheckSpec]:
    return list(_REGISTRY)


def checks_for_tier(tier_name: str, single_check: Optional[str] = None) -> List[CheckSpec]:
    if single_check:
        found = [c for c in _REGISTRY if c.id == single_check]
        if not found:
            raise ValueError("Unknown check id: {0}".format(single_check))
        return found
    if tier_name == "all":
        return list(_REGISTRY)
    tier = Tier(tier_name)
    return [c for c in _REGISTRY if c.tier == tier]


def load_registered_checks():
    """Import check modules so decorators run (side-effect registration)."""
    # pylint: disable=unused-import
    from . import checks  # noqa: F401
