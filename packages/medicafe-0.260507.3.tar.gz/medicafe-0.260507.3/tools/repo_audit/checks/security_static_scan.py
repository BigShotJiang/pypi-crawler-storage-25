"""Wrap tools/security_static_scan.py (same rules, unified reporting)."""

import importlib.util
from pathlib import Path

from .._lib import repo_root
from .._registry import Result, register_check


def _load_scan_module():
    path = repo_root() / "tools" / "security_static_scan.py"
    spec = importlib.util.spec_from_file_location("_medicafe_security_static_scan", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load security_static_scan")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@register_check(
    "security_static_scan",
    "fast",
    "Literal patterns, floating action refs on release workflow, and pinned modern requirements",
)
def run() -> Result:
    mod = _load_scan_module()
    failures = mod.collect_security_static_failures()
    if failures:
        return Result(
            check_id="security_static_scan",
            status="fail",
            summary="{0} finding(s)".format(len(failures)),
            details=failures,
        )
    return Result(
        check_id="security_static_scan",
        status="ok",
        summary="security static scan passed",
        details=[],
    )
