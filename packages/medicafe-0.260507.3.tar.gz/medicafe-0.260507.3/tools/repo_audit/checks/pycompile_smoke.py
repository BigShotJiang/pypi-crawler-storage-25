"""Byte-compile cloud orchestrator, unified-model scripts, and Layer-1 readiness stack."""

import compileall
import py_compile
from typing import List

from .._lib import repo_root
from .._registry import Result, register_check

_EXTRA_FILES = [
    "MediCafe/layer1_readiness_model.py",
    "MediCafe/cloud_readiness_recommendations.py",
    "MediCafe/cloud_readiness_artifact_tools.py",
    "MediCafe/evidence_manifest.py",
    "scripts/unified_model/run_shadow_pipeline.py",
    "scripts/unified_model/ingest_from_manifest.py",
    "scripts/unified_model/phase_c_common.py",
    "scripts/unified_model/phase_e_auto_report.py",
]


@register_check(
    "pycompile_smoke",
    "fast",
    "compileall(cloud/orchestrator) plus py_compile on curated MediCafe and unified-model paths",
)
def run() -> Result:
    root = repo_root()
    failures: List[str] = []
    orch = root / "cloud" / "orchestrator"
    if orch.is_dir():
        ok = compileall.compile_dir(str(orch), quiet=1, rx=None, ddir=None)
        if not ok:
            failures.append("compileall reported failure for cloud/orchestrator")
    else:
        failures.append("cloud/orchestrator directory missing")
    for rel in _EXTRA_FILES:
        path = root / rel
        if not path.is_file():
            failures.append("missing file: {0}".format(rel))
            continue
        try:
            py_compile.compile(str(path), doraise=True)
        except py_compile.PyCompileError as exc:
            failures.append("{0}: {1}".format(rel, exc))
    if failures:
        return Result(
            check_id="pycompile_smoke",
            status="fail",
            summary="{0} compile issue(s)".format(len(failures)),
            details=failures,
        )
    return Result(
        check_id="pycompile_smoke",
        status="ok",
        summary="py_compile / compileall smoke passed",
        details=[],
    )
