"""pip-audit against modern requirements with audit_baseline.json suppressions."""

import json
import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import List

from .._lib import python_exe, repo_root, read_text, run_subprocess
from .._registry import Result, register_check

_BASELINE = "tools/repo_audit/audit_baseline.json"


def _load_baseline() -> set:
    try:
        data = json.loads(read_text(_BASELINE))
    except (OSError, json.JSONDecodeError):
        return set()
    ignored = data.get("ignored_vulnerabilities") or []
    keys = set()
    for item in ignored:
        if isinstance(item, dict):
            pkg = (item.get("package") or "").lower()
            vid = item.get("vuln_id") or item.get("id") or ""
            keys.add((pkg, str(vid)))
    return keys


@register_check(
    "pip_audit_modern",
    "monthly",
    "pip-audit in an isolated venv; use --strict to treat findings as failures",
    blocking=False,
)
def run() -> Result:
    root = repo_root()
    orch = root / "cloud" / "orchestrator" / "requirements.txt"
    tools = root / "tools" / "requirements.txt"
    baseline = _load_baseline()
    tmp = Path(tempfile.mkdtemp(prefix="medicafe_pip_audit_"))
    try:
        rc, _, err = run_subprocess(
            [python_exe(), "-m", "venv", str(tmp)], cwd=root, timeout=120
        )
        if rc != 0:
            return Result(
                check_id="pip_audit_modern",
                status="fail",
                summary="venv creation failed",
                details=[err],
            )
        pip = tmp / ("Scripts/pip.exe" if sys.platform == "win32" else "bin/pip")
        if not pip.is_file():
            pip = tmp / "bin" / "pip"
        steps = [
            [str(pip), "install", "--upgrade", "pip"],
            [str(pip), "install", "-q", "pip-audit"],
            [str(pip), "install", "-q", "-r", str(orch), "-r", str(tools)],
        ]
        for argv in steps:
            rc, _, e2 = run_subprocess(argv, cwd=root, timeout=600)
            if rc != 0:
                return Result(
                    check_id="pip_audit_modern",
                    status="fail",
                    summary="pip-audit bootstrap failed: {0}".format(" ".join(argv[:4])),
                    details=[e2[-8000:]],
                )
        pip_audit = tmp / ("Scripts/pip-audit.exe" if sys.platform == "win32" else "bin/pip-audit")
        if not pip_audit.is_file():
            pip_audit = tmp / "bin" / "pip-audit"
        rc, out, err = run_subprocess(
            [str(pip_audit), "--format", "json", "-r", str(orch), "-r", str(tools)],
            cwd=root,
            timeout=600,
        )
        raw = (out or "").strip()
        if not raw.startswith(("{", "[")):
            raw = (err or "").strip()
        if not raw.startswith(("{", "[")):
            return Result(
                check_id="pip_audit_modern",
                status="fail",
                summary="pip-audit did not return JSON (exit {0})".format(rc),
                details=[(out or "")[:4000], (err or "")[:4000]],
            )
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            payload = None
        rows: List[dict] = []
        if isinstance(payload, list):
            rows = [r for r in payload if isinstance(r, dict)]
        elif isinstance(payload, dict):
            for dep in payload.get("dependencies") or []:
                if not isinstance(dep, dict):
                    continue
                pkg = str(dep.get("name", ""))
                for vuln in dep.get("vulns") or []:
                    if isinstance(vuln, dict):
                        row = dict(vuln)
                        row["name"] = pkg
                        rows.append(row)
        active: List[str] = []
        for row in rows:
            name = str(row.get("name", "")).lower()
            vid = str(row.get("id", row.get("vuln_id", row.get("vuln", ""))))
            if (name, vid) in baseline or (name, "") in baseline:
                continue
            active.append(json.dumps(row, sort_keys=True))
        strict = os.environ.get("REPO_AUDIT_STRICT", "").strip() in ("1", "true", "yes")
        if not active:
            return Result(
                check_id="pip_audit_modern",
                status="ok",
                summary="pip-audit: no unignored findings",
                details=[],
            )
        status = "fail" if strict else "warn"
        return Result(
            check_id="pip_audit_modern",
            status=status,
            summary="{0} pip-audit finding(s) not in baseline".format(len(active)),
            details=active[:200],
        )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
