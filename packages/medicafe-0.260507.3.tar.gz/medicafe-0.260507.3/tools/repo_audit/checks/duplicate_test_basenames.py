"""Flag duplicate test_*.py basenames under tests/ (pytest collection footguns)."""

from collections import defaultdict
from pathlib import Path
from typing import Dict, List

from .._lib import repo_root
from .._registry import Result, register_check


@register_check(
    "duplicate_test_basenames",
    "fast",
    "Same test module basename in multiple directories under tests/",
)
def run() -> Result:
    root = repo_root() / "tests"
    if not root.is_dir():
        return Result(
            check_id="duplicate_test_basenames",
            status="warn",
            summary="tests/ directory not found",
            details=[],
        )
    def _is_test_style(name: str) -> bool:
        return name.startswith("test_") or name.endswith("_test.py")

    by_base: Dict[str, List[Path]] = defaultdict(list)
    for path in root.rglob("*.py"):
        if not _is_test_style(path.name):
            continue
        by_base[path.name].append(path)
    dupes = {k: v for k, v in by_base.items() if len(v) > 1}
    if not dupes:
        return Result(
            check_id="duplicate_test_basenames",
            status="ok",
            summary="No duplicate test module basenames under tests/",
            details=[],
        )
    details: List[str] = []
    for name in sorted(dupes):
        rels = [str(p.relative_to(repo_root())) for p in sorted(dupes[name])]
        details.append("{0}: {1}".format(name, " | ".join(rels)))
    return Result(
        check_id="duplicate_test_basenames",
        status="warn",
        summary="{0} basename(s) duplicated - use pytest --ignore or rename".format(len(dupes)),
        details=details,
    )
