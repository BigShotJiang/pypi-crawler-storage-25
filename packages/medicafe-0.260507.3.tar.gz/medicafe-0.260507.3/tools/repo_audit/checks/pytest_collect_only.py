"""pytest --collect-only with AGENTS.md ignores; fails on collection errors."""

from .._lib import python_exe, repo_root, run_subprocess
from .._registry import Result, register_check

_IGNORES = [
    "tests/api_basic_test.py",
    "tests/utils/logging_comprehensive_test.py",
    "tests/api/api_factory_comprehensive_test.py",
]


@register_check(
    "pytest_collect_only",
    "fast",
    "pytest --collect-only for tests/ with standard duplicate-filename ignores",
)
def run() -> Result:
    argv = [
        python_exe(),
        "-m",
        "pytest",
        "tests/",
        "--collect-only",
        "-q",
        "--timeout",
        "30",
    ]
    for ign in _IGNORES:
        argv.extend(["--ignore", ign])
    code, out, err = run_subprocess(argv, cwd=repo_root(), timeout=180)
    blob = (out or "") + "\n" + (err or "")
    lower = blob.lower()
    if code != 0 or "error during collection" in lower or "errors during collection" in lower:
        lines = [ln for ln in blob.splitlines() if ln.strip()][-40:]
        return Result(
            check_id="pytest_collect_only",
            status="fail",
            summary="pytest collection failed (exit {0})".format(code),
            details=lines or [blob[:2000]],
        )
    return Result(
        check_id="pytest_collect_only",
        status="ok",
        summary="pytest --collect-only succeeded",
        details=[],
    )
