"""Compare modern_install.txt names with pinned modern requirements (drift warnings)."""

from typing import Dict, List, Optional

from .._lib import parse_requirement_lines, read_text
from .._registry import Result, register_check

_ORCH = "cloud/orchestrator/requirements.txt"
_TOOLS = "tools/requirements.txt"
_MODERN = "tools/repo_audit/modern_install.txt"


def _versions_by_name(rel: str) -> Dict[str, Optional[str]]:
    text = read_text(rel)
    out: Dict[str, Optional[str]] = {}
    for name, ver in parse_requirement_lines(text):
        out[name] = ver
    return out


@register_check(
    "requirements_consistency",
    "fast",
    "modern_install.txt vs cloud/tools requirement names and shared version skew",
)
def run() -> Result:
    try:
        modern_text = read_text(_MODERN)
    except OSError as exc:
        return Result(
            check_id="requirements_consistency",
            status="fail",
            summary="Missing or unreadable {0}".format(_MODERN),
            details=[str(exc)],
        )
    try:
        orch = _versions_by_name(_ORCH)
        tools = _versions_by_name(_TOOLS)
    except OSError as exc:
        return Result(
            check_id="requirements_consistency",
            status="fail",
            summary="Missing or unreadable requirements file",
            details=[str(exc)],
        )
    modern = {n for n, _ in parse_requirement_lines(modern_text) if n}
    combined_names = set(orch) | set(tools)
    details: List[str] = []
    missing = sorted(n for n in modern if n not in combined_names)
    if missing:
        details.append(
            "Packages listed in modern_install.txt but absent from both {0} and {1}: {2}".format(
                _ORCH, _TOOLS, ", ".join(missing)
            )
        )
    shared = set(orch) & set(tools)
    skew: List[str] = []
    for name in sorted(shared):
        if orch[name] and tools[name] and orch[name] != tools[name]:
            skew.append("{0}: orchestrator=={1} tools=={2}".format(name, orch[name], tools[name]))
    if skew:
        details.extend(["Shared dependency version skew:"] + skew)
    if missing or skew:
        return Result(
            check_id="requirements_consistency",
            status="warn",
            summary="Drift between modern_install and pinned modern requirements",
            details=details,
        )
    return Result(
        check_id="requirements_consistency",
        status="ok",
        summary="modern_install names are covered by cloud/tools pins; no shared skew",
        details=details,
    )
