"""Import smoke for cloud orchestrator and curated MediCafe modules."""

import os
from typing import List

from .._lib import python_exe, repo_root, run_subprocess
from .._registry import Result, register_check

_SNIPPETS = [
    "import cloud.orchestrator.main as m",
    "import MediCafe.layer1_readiness_model",
    "import MediCafe.cloud_readiness_recommendations",
]


@register_check(
    "import_smoke",
    "weekly",
    "Subprocess import checks with PYTHONPATH anchored at repo root",
    blocking=True,
)
def run() -> Result:
    root = repo_root()
    env = dict(os.environ)
    prev = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(root) + (os.pathsep + prev if prev else "")
    failures: List[str] = []
    for code in _SNIPPETS:
        argv = [python_exe(), "-c", code]
        rc, out, err = run_subprocess(argv, cwd=root, env=env, timeout=120)
        if rc != 0:
            failures.append("{0} -> exit {1}\n{2}\n{3}".format(code, rc, out, err))
    if failures:
        return Result(
            check_id="import_smoke",
            status="fail",
            summary="{0} import failure(s)".format(len(failures)),
            details=failures,
        )
    return Result(
        check_id="import_smoke",
        status="ok",
        summary="Import smoke passed",
        details=[],
    )
