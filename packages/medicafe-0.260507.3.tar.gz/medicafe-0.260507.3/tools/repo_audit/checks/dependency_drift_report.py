"""Compose outdated rows and pip-audit JSON into one Markdown-friendly block."""

from .._registry import Result, register_check


@register_check(
    "dependency_drift_report",
    "monthly",
    "Runs sibling weekly/monthly logic in-process for a single combined report",
    blocking=False,
)
def run() -> Result:
    # Import here to avoid circular imports at module load time.
    from . import outdated_pip_modern as _out
    from . import pip_audit_modern as _audit

    r_out = _out.run()
    r_audit = _audit.run()
    lines = [
        "### Outdated (`outdated_pip_modern`)",
        "status={0}: {1}".format(r_out.status, r_out.summary),
    ]
    lines.extend(r_out.details or ["(none)"])
    lines.append("")
    lines.append("### Advisories (`pip_audit_modern`)")
    lines.append("status={0}: {1}".format(r_audit.status, r_audit.summary))
    lines.extend(r_audit.details or ["(none)"])
    worst = "ok"
    if r_out.status == "fail" or r_audit.status == "fail":
        worst = "fail"
    elif r_out.status == "warn" or r_audit.status == "warn":
        worst = "warn"
    return Result(
        check_id="dependency_drift_report",
        status=worst,
        summary="Combined dependency drift view",
        details=lines,
    )
