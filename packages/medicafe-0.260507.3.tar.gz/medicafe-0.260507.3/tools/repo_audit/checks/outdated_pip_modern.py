"""pip list --outdated in an isolated venv with modern-track requirements (non-blocking)."""

import shutil
import sys
import tempfile
from pathlib import Path

from .._lib import python_exe, repo_root, run_subprocess
from .._registry import Result, register_check


def _venv_pip(venv: Path) -> Path:
    if sys.platform == "win32":
        return venv / "Scripts" / "pip.exe"
    return venv / "bin" / "pip"


@register_check(
    "outdated_pip_modern",
    "weekly",
    "Install cloud/tools requirements in a temp venv and report outdated packages",
    blocking=False,
)
def run() -> Result:
    root = repo_root()
    orch = root / "cloud" / "orchestrator" / "requirements.txt"
    tools = root / "tools" / "requirements.txt"
    if not orch.is_file() or not tools.is_file():
        return Result(
            check_id="outdated_pip_modern",
            status="fail",
            summary="Missing requirements.txt for modern track",
            details=[],
        )
    tmp = Path(tempfile.mkdtemp(prefix="medicafe_repo_audit_"))
    try:
        rc, _, err = run_subprocess(
            [python_exe(), "-m", "venv", str(tmp)], cwd=root, timeout=120
        )
        if rc != 0:
            return Result(
                check_id="outdated_pip_modern",
                status="fail",
                summary="venv creation failed",
                details=[err],
            )
        pip = _venv_pip(tmp)
        if not pip.is_file():
            pip = _venv_pip(tmp).with_name("pip")  # non-Windows without .exe
        rc, _, err = run_subprocess(
            [str(pip), "install", "--upgrade", "pip", "setuptools", "wheel"],
            cwd=root,
            timeout=300,
        )
        if rc != 0:
            return Result(
                check_id="outdated_pip_modern",
                status="fail",
                summary="pip upgrade in venv failed",
                details=[err],
            )
        rc, _, err = run_subprocess(
            [str(pip), "install", "-q", "-r", str(orch), "-r", str(tools)],
            cwd=root,
            timeout=600,
        )
        if rc != 0:
            return Result(
                check_id="outdated_pip_modern",
                status="fail",
                summary="pip install -r modern requirements failed",
                details=[err[-8000:]],
            )
        rc, out, err = run_subprocess([str(pip), "list", "--outdated"], cwd=root, timeout=120)
        if rc != 0:
            return Result(
                check_id="outdated_pip_modern",
                status="fail",
                summary="pip list --outdated failed",
                details=[err],
            )
        lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
        if not lines:
            return Result(
                check_id="outdated_pip_modern",
                status="ok",
                summary="No outdated packages in the modern venv snapshot",
                details=[],
            )
        return Result(
            check_id="outdated_pip_modern",
            status="warn",
            summary="{0} outdated package row(s)".format(len(lines)),
            details=lines[:200],
        )
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
