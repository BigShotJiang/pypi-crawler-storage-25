"""Dependabot directories exist; modern-track requirements paths are covered."""

from pathlib import Path
from typing import List

from .._lib import dependabot_pip_directories, find_requirements_files, read_text, repo_root
from .._registry import Result, register_check


def _norm_dep_dir(d: str) -> Path:
    d = d.strip().strip("\"'")
    if d.startswith("/"):
        d = d[1:]
    return repo_root() / d if d else repo_root()


@register_check(
    "dependabot_sanity",
    "fast",
    "dependabot.yml pip directories exist; requirements.txt locations are covered or exempt",
)
def run() -> Result:
    details: List[str] = []
    root = repo_root()
    try:
        text = read_text(".github/dependabot.yml")
    except OSError as exc:
        return Result(
            check_id="dependabot_sanity",
            status="fail",
            summary="Cannot read .github/dependabot.yml",
            details=[str(exc)],
        )
    pip_dirs = dependabot_pip_directories(text)
    if not pip_dirs:
        return Result(
            check_id="dependabot_sanity",
            status="fail",
            summary="No pip ecosystem entries found in dependabot.yml",
            details=[],
        )
    for d in pip_dirs:
        p = _norm_dep_dir(d)
        if not p.is_dir():
            return Result(
                check_id="dependabot_sanity",
                status="fail",
                summary="Dependabot directory missing: {0}".format(d),
                details=["Expected {0}".format(p)],
            )
    pip_roots = {_norm_dep_dir(d).resolve() for d in pip_dirs}
    exempt_roots = {root.resolve()}
    for req in find_requirements_files():
        parent = req.parent.resolve()
        if parent in exempt_roots and req.name == "requirements.txt":
            details.append(
                "Note: root requirements.txt is intentionally not on Dependabot pip (XP track)."
            )
            continue
        if parent not in pip_roots:
            return Result(
                check_id="dependabot_sanity",
                status="fail",
                summary="requirements.txt not under a Dependabot pip directory: {0}".format(
                    req.relative_to(root)
                ),
                details=["pip directories: {0}".format(sorted(str(x) for x in pip_roots))],
            )
    return Result(
        check_id="dependabot_sanity",
        status="ok",
        summary="Dependabot pip directories and requirements layout look consistent",
        details=details,
    )
