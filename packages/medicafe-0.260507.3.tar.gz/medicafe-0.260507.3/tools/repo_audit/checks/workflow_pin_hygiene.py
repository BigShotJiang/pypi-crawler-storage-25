"""Ensure GitHub Actions third-party uses: lines are pinned to full commit SHAs."""

import re
from typing import List

from .._lib import iter_workflow_paths
from .._registry import Result, register_check

_USES = re.compile(r"^\s*uses:\s*(.+?)\s*$")
_SHA = re.compile(r"^[a-f0-9]{40}$", re.I)


@register_check(
    "workflow_pin_hygiene",
    "fast",
    "Third-party workflow actions use full 40-char SHA pins (skips docker:// and local paths)",
)
def run() -> Result:
    failures: List[str] = []
    for path in iter_workflow_paths():
        text = path.read_text(encoding="utf-8", errors="replace")
        for line_no, line in enumerate(text.splitlines(), 1):
            m = _USES.match(line)
            if not m:
                continue
            spec = m.group(1).strip()
            if spec.startswith("docker://") or spec.startswith("./"):
                continue
            if "@" not in spec:
                failures.append("{0}:{1}: uses without @ ref: {2}".format(path, line_no, spec))
                continue
            action, ref = spec.rsplit("@", 1)
            if "/" not in action:
                continue
            if not _SHA.match(ref):
                failures.append(
                    "{0}:{1}: action not pinned to 40-char SHA: {2}".format(path, line_no, spec)
                )
    if failures:
        return Result(
            check_id="workflow_pin_hygiene",
            status="fail",
            summary="{0} workflow pin issue(s)".format(len(failures)),
            details=failures,
        )
    return Result(
        check_id="workflow_pin_hygiene",
        status="ok",
        summary="All workflow uses: pins look like full SHAs",
        details=[],
    )
