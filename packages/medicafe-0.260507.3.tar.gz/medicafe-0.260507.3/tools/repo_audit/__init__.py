"""Deterministic repository audit checks (registry-driven)."""

from ._registry import CheckSpec, Result, Tier, checks_for_tier, register_check

__all__ = ["CheckSpec", "Result", "Tier", "checks_for_tier", "register_check"]
