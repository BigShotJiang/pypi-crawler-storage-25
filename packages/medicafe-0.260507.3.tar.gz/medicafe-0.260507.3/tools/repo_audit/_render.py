"""Render audit results for text, Markdown, and JSON."""

import json
from typing import List

from ._registry import Result


def render_text(results: List[Result]) -> str:
    lines: List[str] = []
    for r in results:
        lines.append("[{0}] {1}: {2}".format(r.status.upper(), r.check_id, r.summary))
        for d in r.details:
            lines.append("  " + d)
    return "\n".join(lines) + ("\n" if lines else "")


def render_markdown(results: List[Result]) -> str:
    lines: List[str] = ["## Repo audit", ""]
    for r in results:
        icon = "[OK]" if r.status == "ok" else ("[WARN]" if r.status == "warn" else "[FAIL]")
        lines.append("### {0} `{1}`".format(icon, r.check_id))
        lines.append("")
        lines.append("**{0}** - {1}".format(r.status.upper(), r.summary))
        lines.append("")
        if r.details:
            lines.append("```")
            lines.extend(r.details)
            lines.append("```")
            lines.append("")
    return "\n".join(lines)


def render_json(results: List[Result]) -> str:
    payload = [
        {
            "id": r.check_id,
            "status": r.status,
            "summary": r.summary,
            "details": r.details,
        }
        for r in results
    ]
    return json.dumps(payload, indent=2)
