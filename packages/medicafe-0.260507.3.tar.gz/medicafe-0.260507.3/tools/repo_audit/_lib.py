"""Shared helpers for repo_audit checks."""

import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple


def repo_root() -> Path:
    return Path(__file__).resolve().parents[2]


def read_text(rel_path: str) -> str:
    path = repo_root() / rel_path
    return path.read_text(encoding="utf-8", errors="replace")


def iter_workflow_paths() -> List[Path]:
    wf = repo_root() / ".github" / "workflows"
    if not wf.is_dir():
        return []
    return sorted(p for p in wf.glob("*.yml") if p.is_file())


def parse_requirement_lines(text: str) -> List[Tuple[str, Optional[str]]]:
    """Return list of (canonical_name, pinned_version or None)."""
    rows: List[Tuple[str, Optional[str]]] = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Strip env markers like pyjwt[crypto]==2.12.0
        base = line.split(";")[0].strip()
        name_part = base.split("==")[0].strip().lower()
        if "[" in name_part:
            name_part = name_part.split("[", 1)[0].strip()
        ver = None
        if "==" in base:
            ver = base.split("==", 1)[1].strip().split("[", 1)[0].strip()
        rows.append((name_part, ver))
    return rows


def requirement_names_from_file(rel_path: str) -> Set[str]:
    text = read_text(rel_path)
    return {name for name, _ in parse_requirement_lines(text)}


def parse_modern_install_names(rel_path: str = "tools/repo_audit/modern_install.txt") -> Set[str]:
    names: Set[str] = set()
    for line in read_text(rel_path).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        names.add(line.split("==", 1)[0].strip().lower())
    return names


def run_subprocess(
    argv: List[str],
    cwd: Optional[Path] = None,
    env: Optional[dict] = None,
    timeout: Optional[int] = None,
) -> Tuple[int, str, str]:
    proc = subprocess.run(
        argv,
        cwd=str(cwd or repo_root()),
        env=env,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout or "", proc.stderr or ""


def dependabot_pip_directories(text: str) -> List[str]:
    """Extract pip `directory:` roots from dependabot.yml (simple block parser)."""
    dirs: List[str] = []
    lines = text.splitlines()
    in_updates = False
    current_eco = None
    for line in lines:
        if re.match(r"^updates:\s*$", line):
            in_updates = True
            continue
        if not in_updates:
            continue
        if line and not line.startswith(" ") and not line.startswith("\t"):
            break
        m_eco = re.match(r"^\s+-\s+package-ecosystem:\s*(\S+)", line)
        if m_eco:
            current_eco = m_eco.group(1).strip().strip("\"'")
            continue
        m_dir = re.match(r"^\s+directory:\s*(.+)$", line)
        if m_dir and current_eco == "pip":
            raw = m_dir.group(1).strip().strip("\"'")
            dirs.append(raw.rstrip("/") or "/")
    return dirs


def find_requirements_files() -> List[Path]:
    root = repo_root()
    found: List[Path] = []
    skip_parts = {"node_modules", ".git", ".venv", "venv", "__pycache__"}
    for path in root.rglob("requirements.txt"):
        parts = path.parts
        parts_set = set(parts)
        if parts_set & skip_parts:
            continue
        if "archive" in parts_set:
            continue
        found.append(path)
    return sorted(found)


def python_exe() -> str:
    return sys.executable or "python3"
