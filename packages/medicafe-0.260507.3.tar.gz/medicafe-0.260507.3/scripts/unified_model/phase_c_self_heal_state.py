#!/usr/bin/env python
"""
Phase C self-heal ladder state: circuit breaker, failure counts per B-sha, remediation history.
XP-compatible (Python 3.4.4, stdlib only). Mutates diagnostics_state.json and run_cursor.json.
"""
from __future__ import print_function

import calendar
import hashlib
import json
import os
import re
import shutil
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_a_common import iso_utc_now
from phase_c_common import PHASE_C_CIRCUIT_OPEN

try:
    from lab_lock import replace_safe_write
except Exception:
    replace_safe_write = None

_SELF_HEAL_HISTORY_MAX = 50
_PHASE_C_COOLDOWN_ENV = "MEDICAFE_PHASE_C_CIRCUIT_COOLDOWN_HOURS"


def _medicafe_version_string():
    try:
        from MediCafe import __version__ as _mv

        return str(_mv or "").strip() or "unknown"
    except Exception:
        return "unknown"


def _parse_iso_utc_epoch(value):
    raw = str(value or "").strip()
    if not raw:
        return None
    try:
        return int(calendar.timegm(time.strptime(raw.replace("Z", ""), "%Y-%m-%dT%H:%M:%S")))
    except Exception:
        return None


def _circuit_cooldown_hours():
    raw = str(os.environ.get(_PHASE_C_COOLDOWN_ENV, "") or "").strip()
    if not raw:
        return 24
    try:
        v = float(raw)
        return max(1.0, v)
    except Exception:
        return 24


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _safe_write_json(path, doc):
    if replace_safe_write is not None:
        try:
            replace_safe_write(path, doc)
            return True
        except Exception:
            pass
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _merge_doc(path, mutator):
    if not path:
        return False
    doc = {}
    loaded_ok = not os.path.isfile(path)
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as handle:
                raw = json.load(handle)
            if isinstance(raw, dict):
                doc = raw
                loaded_ok = True
        except Exception:
            loaded_ok = False
    if os.path.isfile(path) and not loaded_ok:
        # Same guard as ingest diagnostics / execution-handoff stamps: never replace
        # an existing state file we could not parse as a dict (would wipe lineage).
        return False
    if not os.path.isfile(path) and not doc:
        doc = {}
    try:
        mutator(doc)
    except Exception:
        return False
    doc["updated_at_utc"] = iso_utc_now()
    return _safe_write_json(path, doc)


def phase_c_circuit_is_open(lab_root):
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    return bool(st.get("phase_c_circuit_open"))


def _sha256_prefix16_and_size(script_path):
    """Return (sha256_hex_prefix_16, size_bytes) for a file; empty prefix if unreadable."""
    cur_pref = ""
    cur_sz = 0
    if not script_path or not os.path.isfile(script_path):
        return cur_pref, cur_sz
    try:
        cur_sz = int(os.path.getsize(script_path))
    except Exception:
        cur_sz = 0
    try:
        with open(script_path, "rb") as sf:
            h = hashlib.sha256()
            blk = sf.read(65536)
            while blk:
                h.update(blk)
                blk = sf.read(65536)
        cur_pref = h.hexdigest()[:16]
    except Exception:
        cur_pref = ""
    return cur_pref, cur_sz


def sync_phase_c_subprocess_script_fingerprint_from_disk(lab_root, reason, repo_root=None):
    """
    Refresh stamped Phase C ingest script fingerprint to match on-disk bytes.

    Clears deploy-time drift where Layer 1 / SHP compare last stamped SHA to the
    current ingest_from_manifest.py without requiring a successful subprocess first.

    Writes diagnostics_state.json and run_cursor.json; appends a short remediation
    history event on diagnostics_state only. Logs a stderr line when an update runs.
    """
    lab_root = str(lab_root or "").strip()
    if not lab_root:
        return False
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    st = _read_json_dict(state_path)
    cr = _read_json_dict(cursor_path)
    script_path = str(
        st.get("last_phase_c_subprocess_script_path")
        or cr.get("last_phase_c_subprocess_script_path")
        or ""
    ).strip()
    if not script_path and repo_root:
        script_path = os.path.normpath(
            os.path.join(
                str(repo_root).strip(),
                "scripts",
                "unified_model",
                "ingest_from_manifest.py",
            )
        )
    if not script_path or not os.path.isfile(script_path):
        return False
    cur_pref, cur_sz = _sha256_prefix16_and_size(script_path)
    if not cur_pref or cur_sz <= 0:
        return False
    st_pref = str(st.get("last_phase_c_subprocess_script_sha256_prefix") or "").strip()
    cr_pref = str(cr.get("last_phase_c_subprocess_script_sha256_prefix") or "").strip()
    try:
        st_sz = int(st.get("last_phase_c_subprocess_script_size_bytes") or 0)
    except (TypeError, ValueError):
        st_sz = 0
    try:
        cr_sz = int(cr.get("last_phase_c_subprocess_script_size_bytes") or 0)
    except (TypeError, ValueError):
        cr_sz = 0
    need = (
        st_pref != cur_pref
        or cr_pref != cur_pref
        or st_sz != cur_sz
        or cr_sz != cur_sz
        or (not st_pref)
        or (not cr_pref)
    )
    if not need:
        return False
    prior = (st_pref or cr_pref or "-")[:32]

    def _mut_state(doc):
        doc["last_phase_c_subprocess_script_path"] = script_path
        doc["last_phase_c_subprocess_script_sha256_prefix"] = cur_pref
        doc["last_phase_c_subprocess_script_size_bytes"] = cur_sz
        hist = doc.get("phase_c_remediation_history")
        if not isinstance(hist, list):
            hist = []
        tail = script_path
        if len(tail) > 260:
            tail = "..." + tail[-257:]
        hist.append(
            {
                "event": "phase_c_subprocess_script_fingerprint_resync",
                "at_utc": iso_utc_now(),
                "reason": str(reason or "")[:128],
                "script_path": tail,
                "prior_sha256_prefix16": prior,
                "current_sha256_prefix16": cur_pref,
                "current_size_bytes": cur_sz,
            }
        )
        doc["phase_c_remediation_history"] = hist[-_SELF_HEAL_HISTORY_MAX:]

    def _mut_cursor(doc):
        doc["last_phase_c_subprocess_script_path"] = script_path
        doc["last_phase_c_subprocess_script_sha256_prefix"] = cur_pref
        doc["last_phase_c_subprocess_script_size_bytes"] = cur_sz

    changed = _merge_doc(state_path, _mut_state)
    changed = _merge_doc(cursor_path, _mut_cursor) or changed
    if changed:
        try:
            print(
                "[SHADOW_PIPELINE] Phase C ingest script fingerprint resynced from disk "
                "(reason={0}): path={1} prior_prefix16={2} current_prefix16={3} size_bytes={4}".format(
                    str(reason or "").strip() or "-",
                    script_path,
                    prior,
                    cur_pref,
                    cur_sz,
                ),
                file=sys.stderr,
            )
        except Exception:
            pass
    return changed


def maybe_auto_reset_phase_c_circuit(lab_root):
    """
    Auto-reset open circuit when MediCafe version changes or cooldown elapsed.
    Promotes pending Phase B manifest (written under circuit) to canonical pointers.
    Returns True if a reset was applied.
    """
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    st = _read_json_dict(state_path)
    if not st.get("phase_c_circuit_open"):
        return False
    opened_ver = str(st.get("phase_c_circuit_opened_at_medicafe_version") or "").strip()
    opened_at = str(st.get("phase_c_circuit_opened_at_utc") or "").strip()
    cur_ver = _medicafe_version_string()
    now_ep = int(time.time())
    opened_ep = _parse_iso_utc_epoch(opened_at)
    cooldown = _circuit_cooldown_hours()
    # Empty opened_ver (legacy / partial stamps): still reset when deploy version differs,
    # so a ship-and-fix loop clears the circuit without manual operator reset.
    version_bump = bool(cur_ver) and opened_ver != cur_ver
    cooldown_ok = False
    if opened_ep is not None:
        cooldown_ok = (now_ep - opened_ep) >= int(cooldown * 3600)
    if not version_bump and not cooldown_ok:
        return False

    def _mut_state(doc):
        hist = doc.get("phase_c_remediation_history")
        if not isinstance(hist, list):
            hist = []
        hist.append(
            {
                "event": "circuit_auto_reset",
                "at_utc": iso_utc_now(),
                "reason": "version_bump" if version_bump else "cooldown",
                "prior_version": opened_ver,
                "current_version": cur_ver,
            }
        )
        doc["phase_c_remediation_history"] = hist[-_SELF_HEAL_HISTORY_MAX:]
        doc["phase_c_circuit_open"] = False
        doc["phase_c_circuit_opened_at_utc"] = ""
        doc["phase_c_circuit_opened_at_medicafe_version"] = ""
        doc["phase_c_self_heal_failure_count_for_b_sha"] = 0
        doc["phase_c_unresolvable_bundle_sent_at_utc"] = ""
        pend_path = str(doc.get("last_discovery_pending_manifest_path") or "").strip()
        pend_sha = str(doc.get("last_discovery_pending_manifest_sha256") or "").strip()
        if pend_path and os.path.isfile(pend_path) and pend_sha:
            doc["last_manifest_path"] = pend_path
            doc["last_manifest_sha256"] = pend_sha
        doc["last_discovery_skipped_due_to_phase_c_circuit"] = False
        doc["last_discovery_pending_manifest_path"] = ""
        doc["last_discovery_pending_manifest_sha256"] = ""
        doc["last_discovery_pending_phase_b_run_id"] = ""

    def _mut_cursor(doc):
        doc["phase_c_circuit_open"] = False
        pend_path = str(doc.get("last_discovery_pending_manifest_path") or "").strip()
        pend_sha = str(doc.get("last_discovery_pending_manifest_sha256") or "").strip()
        if pend_path and os.path.isfile(pend_path) and pend_sha:
            doc["last_manifest_path"] = pend_path
            doc["last_manifest_sha256"] = pend_sha
        doc["last_discovery_skipped_due_to_phase_c_circuit"] = False
        doc["last_discovery_pending_manifest_path"] = ""
        doc["last_discovery_pending_manifest_sha256"] = ""
        doc["last_discovery_pending_phase_b_run_id"] = ""

    changed = _merge_doc(state_path, _mut_state)
    changed = _merge_doc(cursor_path, _mut_cursor) or changed
    if changed:
        sync_phase_c_subprocess_script_fingerprint_from_disk(
            lab_root, "phase_c_circuit_auto_reset"
        )
    return changed


def sync_phase_c_self_heal_tracked_b_sha(lab_root):
    """If Phase B manifest sha changed, reset failure counter for the new lineage."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    st = _read_json_dict(state_path)
    cr = _read_json_dict(cursor_path)
    b_sha = str(st.get("last_manifest_sha256") or cr.get("last_manifest_sha256") or "").strip()
    tracked = str(st.get("phase_c_self_heal_tracked_b_sha") or "").strip()

    if not b_sha or b_sha == tracked:
        return

    def _mut(doc):
        doc["phase_c_self_heal_tracked_b_sha"] = b_sha
        doc["phase_c_self_heal_failure_count_for_b_sha"] = 0

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)


def phase_c_self_heal_failure_count(lab_root):
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    try:
        return int(st.get("phase_c_self_heal_failure_count_for_b_sha", 0) or 0)
    except Exception:
        return 0


def remediation_tier_for_failure_count(fc):
    """1=default shadow recovery, 2=forced rebuild+integrity, 3=reports quarantine+rediscover, 4=circuit."""
    try:
        n = int(fc)
    except Exception:
        n = 0
    if n >= 3:
        return 4
    return n + 1


def append_phase_c_remediation_event(lab_root, event_dict):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def _mut(doc):
        hist = doc.get("phase_c_remediation_history")
        if not isinstance(hist, list):
            hist = []
        ev = dict(event_dict) if isinstance(event_dict, dict) else {}
        ev.setdefault("at_utc", iso_utc_now())
        hist.append(ev)
        doc["phase_c_remediation_history"] = hist[-_SELF_HEAL_HISTORY_MAX:]

    _merge_doc(state_path, _mut)


def increment_phase_c_self_heal_failure(lab_root, pipeline_run_id, detail):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")

    def _mut(doc):
        try:
            fc = int(doc.get("phase_c_self_heal_failure_count_for_b_sha", 0) or 0)
        except Exception:
            fc = 0
        doc["phase_c_self_heal_failure_count_for_b_sha"] = min(fc + 1, 3)

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)
    append_phase_c_remediation_event(
        lab_root,
        {
            "event": "phase_c_failure",
            "pipeline_run_id": str(pipeline_run_id or ""),
            "detail": str(detail or "")[:500],
            "failure_count_after": phase_c_self_heal_failure_count(lab_root),
        },
    )


def reset_phase_c_self_heal_on_success(lab_root, pipeline_run_id):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")

    def _mut(doc):
        doc["phase_c_self_heal_failure_count_for_b_sha"] = 0
        doc["phase_c_circuit_open"] = False
        doc["phase_c_circuit_opened_at_utc"] = ""
        doc["phase_c_circuit_opened_at_medicafe_version"] = ""
        doc["last_discovery_skipped_due_to_phase_c_circuit"] = False

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)
    append_phase_c_remediation_event(
        lab_root,
        {"event": "phase_c_handoff_ok", "pipeline_run_id": str(pipeline_run_id or "")},
    )


def open_phase_c_circuit(lab_root, pipeline_run_id, reason):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    ver = _medicafe_version_string()
    now = iso_utc_now()

    def _mut(doc):
        doc["phase_c_circuit_open"] = True
        doc["phase_c_circuit_opened_at_utc"] = now
        doc["phase_c_circuit_opened_at_medicafe_version"] = ver
        doc["last_phase_c_error_code"] = PHASE_C_CIRCUIT_OPEN

    _merge_doc(state_path, _mut)
    _merge_doc(cursor_path, _mut)
    append_phase_c_remediation_event(
        lab_root,
        {
            "event": "circuit_opened",
            "pipeline_run_id": str(pipeline_run_id or ""),
            "reason": str(reason or "")[:300],
        },
    )


def phase_c_unresolvable_bundle_already_sent(lab_root):
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    return bool(str(st.get("phase_c_unresolvable_bundle_sent_at_utc") or "").strip())


def stamp_phase_c_unresolvable_bundle_sent(lab_root):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def _mut(doc):
        doc["phase_c_unresolvable_bundle_sent_at_utc"] = iso_utc_now()

    _merge_doc(state_path, _mut)


def stamp_phase_c_last_self_heal_telemetry(lab_root, tier_label, outcome):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def _mut(doc):
        doc["phase_c_last_self_heal_tier"] = str(tier_label or "")[:80]
        doc["phase_c_last_self_heal_outcome"] = str(outcome or "")[:200]

    _merge_doc(state_path, _mut)


def quarantine_shadow_reports_and_rediscover(lab_root, pipeline_run_id, python_exe, repo_root, env):
    """
    Move shadow report artifacts aside and re-run discover_artifacts.py subprocess.
    Does not touch upstream CSV/DOCX/DAT sources.
    """
    import subprocess

    reports_dir = os.path.join(lab_root, "reports")
    dest_parent = os.path.join(lab_root, "shadow_reports_quarantine")
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    dest = os.path.join(dest_parent, safe_rid)
    try:
        if not os.path.isdir(dest_parent):
            os.makedirs(dest_parent)
    except Exception:
        return False, "mkdir_quarantine_failed"
    try:
        if not os.path.isdir(dest):
            os.makedirs(dest)
    except Exception:
        return False, "mkdir_dest_failed"
    prefixes = (
        "artifact_manifest_",
        "ingest_write_summary_",
        "qa_canonical_summary_",
    )
    moved = 0
    if os.path.isdir(reports_dir):
        for name in os.listdir(reports_dir):
            hit = False
            for pfx in prefixes:
                if name.startswith(pfx):
                    hit = True
                    break
            if not hit:
                continue
            src = os.path.join(reports_dir, name)
            if not os.path.isfile(src):
                continue
            dst = os.path.join(dest, name)
            try:
                shutil.move(src, dst)
                moved += 1
            except Exception:
                pass

    def _clear_manifest_keys(doc):
        doc["last_manifest_path"] = ""
        doc["last_manifest_sha256"] = ""
        doc["last_ingest_manifest_path"] = ""
        doc["last_ingest_manifest_sha256"] = ""

    _merge_doc(os.path.join(lab_root, "diagnostics_state.json"), _clear_manifest_keys)
    _merge_doc(os.path.join(lab_root, "run_cursor.json"), _clear_manifest_keys)

    script_path = os.path.join(repo_root, "scripts", "unified_model", "discover_artifacts.py")
    if not os.path.isfile(script_path):
        return False, "discover_script_missing"
    proc_env = env.copy() if isinstance(env, dict) else {}
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    try:
        rc = subprocess.call([python_exe, script_path], cwd=repo_root, env=proc_env)
    except Exception:
        return False, "discover_subprocess_exception"
    if rc != 0:
        return False, "discover_exit_{0}".format(rc)
    append_phase_c_remediation_event(
        lab_root,
        {
            "event": "tier3_reports_quarantine_rediscover",
            "pipeline_run_id": str(pipeline_run_id or ""),
            "moved_file_count": moved,
        },
    )
    return True, ""


