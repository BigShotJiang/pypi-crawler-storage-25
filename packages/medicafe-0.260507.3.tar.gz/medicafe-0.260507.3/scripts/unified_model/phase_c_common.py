#!/usr/bin/env python
"""
Phase C ingest: constants, error codes, ingest-key policy, artifact-class mapping.
Single source of truth for ingest_from_manifest.py. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import os
import sqlite3
import sys

# DRY: Import from phase_a_common
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)
try:
    from phase_a_common import iso_utc_now as _iso_utc_now, run_id as _run_id
    iso_utc_now = _iso_utc_now
    run_id = _run_id
except ImportError:
    import time
    import hashlib
    import uuid
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    def run_id():
        ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
        try:
            hex_part = uuid.uuid4().hex[:8]
        except Exception:
            hex_part = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
        return "{0}-{1}".format(ts, hex_part)

INGEST_KEY_POLICY_VERSION = "ingest_key_v1"
XP_SOURCE_SYSTEM = "xp_local"

# Error codes for Phase C failure reporting
PHASE_C_MANIFEST_MISSING = "PHASE_C_MANIFEST_MISSING"
PHASE_C_MANIFEST_INVALID = "PHASE_C_MANIFEST_INVALID"
PHASE_C_INGEST_KEY_ERROR = "PHASE_C_INGEST_KEY_ERROR"
PHASE_C_UNKNOWN_ARTIFACT_CLASS = "PHASE_C_UNKNOWN_ARTIFACT_CLASS"
PHASE_C_DB_WRITE_ERROR = "PHASE_C_DB_WRITE_ERROR"
PHASE_C_STATE_WRITE_ERROR = "PHASE_C_STATE_WRITE_ERROR"
PHASE_C_LOCK_FAIL = "PHASE_C_LOCK_FAIL"
PHASE_C_CIRCUIT_OPEN = "PHASE_C_CIRCUIT_OPEN"
# Lab state on disk does not match run_ingest success (wrong MEDICAFE_LAB_DIR, partial write, or external overwrite).
PHASE_C_FINISH_INCOHERENT = "PHASE_C_FINISH_INCOHERENT"

# ingest_write_summary_*.json schema (increment when required fields change)
PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION = 1

# Bounded retry for SQLite busy/locked only (no WAL mode changes; safe defaults for XP)
PHASE_C_DB_LOCK_RETRY_DELAYS_SEC = (2, 5, 10)


_PHASE_C_SQLITE_LOCK_TOKENS = (
    "database is locked",
    "database is busy",
    "database table is locked",
    "database schema is locked",
    "database table is busy",
    "database schema is busy",
    "sqlite_busy",
    "sqlite_locked",
)


def _phase_c_sqlite_lock_message_matches(msg_lower):
    if not msg_lower:
        return False
    for token in _PHASE_C_SQLITE_LOCK_TOKENS:
        if token in msg_lower:
            return True
    return False


def phase_c_sqlite_lock_class_error(exc):
    """True for SQLite busy/lock contention only (narrow match for retries)."""
    if isinstance(exc, sqlite3.OperationalError):
        msg = str(exc).lower()
        return _phase_c_sqlite_lock_message_matches(msg)
    return False


def phase_c_operator_hint_from_db_error_detail(db_error_detail):
    """
    Short normalized hint for operators from db_error_detail (best-effort).
    Empty string when no mapping applies.
    """
    if not db_error_detail:
        return ""
    msg = str(db_error_detail).lower()
    if _phase_c_sqlite_lock_message_matches(msg):
        return "sqlite_lock_contention"
    if "readonly" in msg or "read-only" in msg:
        return "sqlite_readonly"
    if "disk i/o" in msg:
        return "sqlite_io"
    if "unable to open" in msg or "no such table" in msg:
        return "sqlite_schema_or_path"
    return ""

# artifact_class -> source_type mapping (v1)
ARTIFACT_CLASS_TO_SOURCE_TYPE = {
    "csv": "file_csv",
    "docx": "file_docx",
    "dat": "file_dat",
    "jsonl": "file_jsonl",
    "837": "file_837",
    "receipt": "file_receipt",
    "xml": "file_xml",
}

HASH_MODE_FULL = "full"
HASH_MODE_SAMPLED = "sampled"
HASH_MODE_SKIPPED_LARGE = "skipped_large"
HASH_MODE_ERROR = "error"


def artifact_class_to_source_type(artifact_class):
    """
    Map artifact_class string to source_type. Returns None for unknown class.
    """
    if not isinstance(artifact_class, str):
        return None
    return ARTIFACT_CLASS_TO_SOURCE_TYPE.get(artifact_class)


def compute_ingest_key_v1(row):
    """
    Compute deterministic ingest_key per ingest_key_v1 policy.
    Formula: sha256(source_id|artifact_class|normalized_path|mtime_epoch|size_bytes|sha256)

    Raises ValueError if required fields missing or invalid.
    """
    required = ("source_id", "artifact_class", "normalized_path", "mtime_epoch", "size_bytes", "hash_mode")
    for k in required:
        if k not in row:
            raise ValueError("Missing required field: {0}".format(k))

    source_id = str(row.get("source_id", ""))
    artifact_class = str(row.get("artifact_class", ""))
    normalized_path = str(row.get("normalized_path", ""))
    mtime_epoch = row.get("mtime_epoch")
    size_bytes = row.get("size_bytes")
    sha256_val = str(row.get("sha256", ""))
    hash_mode = str(row.get("hash_mode", ""))

    if not isinstance(mtime_epoch, (int, float)):
        raise ValueError("mtime_epoch must be int or float")
    if not isinstance(size_bytes, (int, float)):
        raise ValueError("size_bytes must be int or float")
    mtime_epoch = int(mtime_epoch)
    size_bytes = int(size_bytes)

    if hash_mode in (HASH_MODE_FULL, HASH_MODE_SAMPLED):
        if not sha256_val or not sha256_val.strip():
            raise ValueError("sha256 required when hash_mode is full or sampled")
    # sha256 may be empty for skipped_large and error

    parts = [
        source_id,
        artifact_class,
        normalized_path,
        str(mtime_epoch),
        str(size_bytes),
        sha256_val,
    ]
    raw = chr(124).join(parts)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
