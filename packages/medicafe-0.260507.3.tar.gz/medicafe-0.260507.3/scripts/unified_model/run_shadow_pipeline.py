#!/usr/bin/env python
"""
XP Shadow Pipeline orchestrator: runs A -> B -> C -> D -> E -> F.
Single authoritative path for unattended end-to-end automation.
Uses dedicated pipeline lock (shadow_pipeline.lock); does not long-hold lab/shadow.lock.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import argparse
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import time

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from lab_path_utils import resolve_lab_root
from phase_a_common import iso_utc_now, run_id
from failure_contract import build_failure_context
from phase_c_self_heal_state import (
    append_phase_c_remediation_event,
    increment_phase_c_self_heal_failure,
    maybe_auto_reset_phase_c_circuit,
    open_phase_c_circuit,
    phase_c_circuit_is_open,
    phase_c_self_heal_failure_count,
    phase_c_unresolvable_bundle_already_sent,
    quarantine_shadow_reports_and_rediscover,
    remediation_tier_for_failure_count,
    reset_phase_c_self_heal_on_success,
    stamp_phase_c_last_self_heal_telemetry,
    stamp_phase_c_unresolvable_bundle_sent,
    sync_phase_c_subprocess_script_fingerprint_from_disk,
    sync_phase_c_self_heal_tracked_b_sha,
)
from phase_c_common import (
    PHASE_C_CIRCUIT_OPEN,
    PHASE_C_DB_WRITE_ERROR,
    PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
)
try:
    from phase_c_current_attempt import (
        begin_phase_c_current_attempt,
        mark_phase_c_current_attempt_circuit_open,
        refresh_phase_c_current_attempt_from_lab,
    )
except Exception:
    begin_phase_c_current_attempt = None
    mark_phase_c_current_attempt_circuit_open = None
    refresh_phase_c_current_attempt_from_lab = None

try:
    from MediCafe import shadow_orchestrator as _shadow_orchestrator
except Exception:
    _shadow_orchestrator = None

try:
    from pipeline_exit_classification import (
        PIPELINE_INTERRUPTED_CONTROL_EVENT,
        classify_phase_exit,
    )
except Exception:
    PIPELINE_INTERRUPTED_CONTROL_EVENT = "PIPELINE_INTERRUPTED_CONTROL_EVENT"

    def classify_phase_exit(rc, from_keyboard_interrupt_parent=False):
        return {
            "interrupted": bool(from_keyboard_interrupt_parent) or rc == 130,
            "normalized_code": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "raw_rc": rc,
            "hex_rc": "",
            "classification_source": "child_exit_code",
        }


_INTERRUPT_STATE_KEYS = (
    "last_shadow_pipeline_interrupt_run_id",
    "last_shadow_pipeline_interrupt_phase",
    "last_shadow_pipeline_interrupt_code",
    "last_shadow_pipeline_interrupt_code_hex",
    "last_shadow_pipeline_interrupt_class",
    "last_shadow_pipeline_interrupt_source",
    "last_shadow_pipeline_interrupt_at_utc",
    "last_shadow_pipeline_interrupt_detail",
    "last_shadow_pipeline_interrupt_guard_note",
)

PIPELINE_LOCK_NAME = "shadow_pipeline.lock"
_PIPELINE_RUN_ID_ENV = "MEDICAFE_SHADOW_PIPELINE_RUN_ID"
_PIPELINE_PHASE_RUN_IDS_ENV = "MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON"
PHASE_C_SHADOW_RECOVERY_FAILED = "PHASE_C_SHADOW_RECOVERY_FAILED"
PHASE_C_SHADOW_RECOVERY_ACTION = "phase_c_shadow_rebuild"
PHASE_C_EXEC_HANDOFF_SCHEMA_VERSION = 1


def _workspace_root():
    return _WORKSPACE_ROOT


def _resolve_lab_root(args):
    return resolve_lab_root(args.lab_dir, _workspace_root())


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return False
    if pid_int <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            process_query_information = 0x0400
            handle = kernel32.OpenProcess(process_query_information, 0, pid_int)
            if handle:
                kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return False
    try:
        os.kill(pid_int, 0)
        return True
    except OSError:
        return False


def _parse_pipeline_lock(lock_path):
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        pid = None
        heartbeat = None
        for line in content.splitlines():
            if line.startswith("pid="):
                pid = line[4:].strip()
            elif line.startswith("heartbeat_at_utc="):
                heartbeat = line[17:].strip()
        return (pid, heartbeat)
    except Exception:
        return (None, None)


def _acquire_pipeline_lock(lab_root):
    """Acquire lab/shadow_pipeline.lock. Returns True if acquired, False if already running."""
    os.makedirs(lab_root, exist_ok=True)
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    max_retries = 2
    for attempt in range(max_retries + 1):
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            content = "pid={0}\nacquired_at_utc={1}\nheartbeat_at_utc={1}\n".format(os.getpid(), now)
            os.write(fd, content.encode("ascii"))
            os.close(fd)
            return True
        except (OSError, IOError) as e:
            errno_val = getattr(e, "errno", None)
            if errno_val not in (17, 183):
                raise
        pid, heartbeat = _parse_pipeline_lock(lock_path)
        if pid is None:
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
            except Exception:
                pass
            continue
        if _pid_running(pid):
            return False  # Never steal from a running process
        try:
            if os.path.exists(lock_path):
                os.remove(lock_path)
        except Exception:
            pass
        if attempt >= max_retries:
            return False
    return False


def _release_pipeline_lock(lab_root):
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    try:
        if os.path.exists(lock_path):
            os.remove(lock_path)
    except Exception:
        pass


def _refresh_lock_heartbeat(lab_root):
    """Update heartbeat_at_utc in the pipeline lock file. Keeps long runs from being considered stale."""
    lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
    tmp_path = lock_path + ".tmp"
    if not os.path.exists(lock_path):
        return
    try:
        with open(lock_path, "r") as f:
            content = f.read()
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        lines = []
        for line in content.splitlines():
            if line.startswith("heartbeat_at_utc="):
                lines.append("heartbeat_at_utc={0}".format(now))
            else:
                lines.append(line)
        new_content = "\n".join(lines) + "\n"
        with open(tmp_path, "w") as f:
            f.write(new_content)
        os.replace(tmp_path, lock_path)
    except Exception:
        pass
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass


def _update_pipeline_state(lab_root, rid, started_at, finished_at, ok, failed_phase=None, error_code=None,
                           skip_reason=None, heartbeat_at_utc=None, phase_run_ids=None, failure_context=None,
                           interrupted=False, interrupt_extra=None):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_shadow_pipeline_run_id"] = rid
    state["last_shadow_pipeline_started_at_utc"] = started_at
    state["last_shadow_pipeline_finished_at_utc"] = finished_at
    state["last_shadow_pipeline_ok"] = ok
    state["last_shadow_pipeline_failed_phase"] = failed_phase or ""
    state["last_shadow_pipeline_error_code"] = error_code or ""
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "completed" if ok else "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_error_code"] = error_code or ""
    ctx = failure_context or {}
    state["last_error_detail"] = ctx.get("error_detail", "") if isinstance(ctx, dict) else ""
    state["last_error_recoverability"] = ctx.get("recoverability", "") if isinstance(ctx, dict) else ""
    state["last_error_source_exception_class"] = (
        ctx.get("source_exception_class", "") if isinstance(ctx, dict) else ""
    )
    state["started_at_utc"] = started_at
    state["finished_at_utc"] = finished_at
    state["updated_at_utc"] = finished_at
    state["phase_f_report_sent"] = False
    state["phase_f_report_sent_for_run_id"] = ""
    if phase_run_ids is not None:
        state["last_shadow_pipeline_phase_run_ids"] = (
            dict(phase_run_ids) if isinstance(phase_run_ids, dict) else {}
        )
    if skip_reason:
        state["last_shadow_pipeline_skip_reason"] = skip_reason
    if heartbeat_at_utc:
        state["last_shadow_pipeline_lock_heartbeat_at_utc"] = heartbeat_at_utc
        state["heartbeat_at_utc"] = heartbeat_at_utc

    if skip_reason:
        pass
    elif ok:
        state["last_shadow_pipeline_outcome"] = "completed"
        for key in _INTERRUPT_STATE_KEYS:
            state[key] = ""
    elif interrupted:
        state["last_shadow_pipeline_outcome"] = "interrupted"
        state["pipeline_state"] = "failed"
        ex = interrupt_extra if isinstance(interrupt_extra, dict) else {}
        for key in _INTERRUPT_STATE_KEYS:
            if key in ex:
                state[key] = ex[key]
        guard = (
            "Pipeline interrupted at phase {0}; control event or break signal (see interrupt report)."
        ).format(str(failed_phase or "?"))
        state["last_shadow_pipeline_interrupt_guard_note"] = state.get(
            "last_shadow_pipeline_interrupt_guard_note") or guard
    else:
        state["last_shadow_pipeline_outcome"] = "failed"
        for key in _INTERRUPT_STATE_KEYS:
            state[key] = ""

    try:
        state.pop("last_shadow_pipeline_interrupt_restart_hint", None)
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _update_pipeline_phase_f_failure(lab_root, rid, error_code, phase_f_lock_diag_path="", failure_context=None):
    """Update only failure fields; do not touch phase_f_report_sent*."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["last_shadow_pipeline_ok"] = False
    state["last_shadow_pipeline_failed_phase"] = "F"
    state["last_shadow_pipeline_error_code"] = error_code or ""
    state["last_phase_f_lock_diag_path"] = phase_f_lock_diag_path or ""
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_error_code"] = error_code or ""
    ctx = failure_context or {}
    state["last_error_detail"] = ctx.get("error_detail", "") if isinstance(ctx, dict) else ""
    state["last_error_recoverability"] = ctx.get("recoverability", "") if isinstance(ctx, dict) else ""
    state["last_error_source_exception_class"] = (
        ctx.get("source_exception_class", "") if isinstance(ctx, dict) else ""
    )
    state["finished_at_utc"] = iso_utc_now()
    state["updated_at_utc"] = state.get("finished_at_utc")
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


PIPELINE_UNHANDLED_EXCEPTION = "PIPELINE_UNHANDLED_EXCEPTION"


def _repair_orphan_pipeline_lifecycle_state(lab_root, incoming_rid):
    """
    Recover from a prior crash between _update_pipeline_phase_marker and _update_pipeline_state.

    Symptom: pipeline_state is running/bootstrapping while active_run_id != last_shadow_pipeline_run_id
    after the current run's phase markers have been written (caller must run this only after
    _update_pipeline_phase_marker so active_run_id matches the incoming run when healthy). Stale
    ghost active_run_id from a crashed prior attempt can otherwise defer support-send jobs while
    pipeline_state says running.
    """
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.isfile(state_path):
        return
    state = {}
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
    except Exception:
        return
    if not isinstance(state, dict):
        return
    ps = str(state.get("pipeline_state", "") or "").strip().lower()
    active = str(state.get("active_run_id", "") or "").strip()
    last_rid = str(state.get("last_shadow_pipeline_run_id", "") or "").strip()
    if ps not in ("running", "bootstrapping"):
        return
    if not active:
        return
    if active == str(incoming_rid or "").strip():
        return
    if last_rid and active == last_rid:
        return
    orphan = (last_rid and active != last_rid) or (not last_rid and active)
    if not orphan:
        return

    state["pipeline_state"] = "failed"
    state["active_run_id"] = ""
    state["active_phase"] = ""
    state["last_shadow_pipeline_outcome"] = "failed"
    state["last_error_code"] = "PIPELINE_STALE_LIFECYCLE_RECOVERED"
    state["last_error_detail"] = (
        "Recovered orphan pipeline lifecycle markers (active_run_id={0} did not match "
        "last_shadow_pipeline_run_id={1}); prior run likely terminated before state flush."
    ).format(active, last_rid or "(empty)")
    state["last_error_recoverability"] = "recoverable"
    state["last_error_source_exception_class"] = "PipelineLifecycleRepair"
    state["updated_at_utc"] = iso_utc_now()
    try:
        from lab_lock import replace_safe_write

        replace_safe_write(state_path, state)
    except Exception:
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2, sort_keys=True)
        except Exception:
            pass


def _update_pipeline_phase_marker(lab_root, rid, phase_name, now_utc, phase_run_ids=None):
    """Owner-only write path for lifecycle fields during active pipeline run."""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state = {}
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception:
            pass
    state["version"] = max(2, int(state.get("version", 1) or 1))
    state["pipeline_state"] = "bootstrapping" if phase_name == "A" else "running"
    state["active_run_id"] = rid
    state["active_phase"] = phase_name
    state["started_at_utc"] = state.get("started_at_utc") or now_utc
    state["heartbeat_at_utc"] = now_utc
    state["updated_at_utc"] = now_utc
    if isinstance(phase_run_ids, dict):
        state["last_shadow_pipeline_phase_run_ids"] = dict(phase_run_ids)
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(state_path, state)
    except Exception:
        pass


def _run_phase(script_name, lab_root, python_exe, repo_root, env):
    """Run a phase script. Returns (ok, exit_code)."""
    script_path = os.path.join(repo_root, "scripts", "unified_model", script_name)
    if not os.path.exists(script_path):
        return False, -1
    proc_env = env.copy()
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    call_kwargs = {"cwd": repo_root, "env": proc_env}
    if script_name == "bootstrap_lab.py" and os.name == "nt":
        call_kwargs["creationflags"] = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    try:
        rc = subprocess.call([python_exe, script_path], **call_kwargs)
    except KeyboardInterrupt:
        if script_name == "bootstrap_lab.py":
            print(
                "Bootstrap interrupted by control event; source unknown.",
                file=sys.stderr,
            )
            return False, 130
        raise
    return (rc == 0), rc


def _stderr_tail_4k(data):
    if not data:
        return ""
    try:
        if isinstance(data, bytes):
            text = data.decode("utf-8", "replace")
        else:
            text = str(data)
    except Exception:
        text = ""
    if len(text) <= 4096:
        return text
    return text[-4096:]


def _stdout_tail_4k(data):
    return _stderr_tail_4k(data)


def _run_phase_c_subprocess_with_stderr(script_name, lab_root, python_exe, repo_root, env):
    """
    Run Phase C ingest subprocess; capture stdout/stderr tails for execution-handoff diagnostics.
    Returns (ok, exit_code, stderr_tail, exec_info_dict).
    """
    script_path = os.path.join(repo_root, "scripts", "unified_model", script_name)
    started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    t0 = time.time()
    script_sha_prefix = ""
    script_size_bytes = 0
    if os.path.isfile(script_path):
        try:
            script_size_bytes = int(os.path.getsize(script_path))
        except Exception:
            script_size_bytes = 0
        try:
            with open(script_path, "rb") as sf:
                h = hashlib.sha256()
                block = sf.read(65536)
                while block:
                    h.update(block)
                    block = sf.read(65536)
            script_sha_prefix = h.hexdigest()[:16]
        except Exception:
            script_sha_prefix = ""
    if not os.path.exists(script_path):
        return False, -1, "", {
            "script_name": script_name,
            "script_path": script_path,
            "python_exe": python_exe,
            "cwd": repo_root,
            "started_at_utc": started_at,
            "finished_at_utc": started_at,
            "elapsed_sec": 0.0,
            "return_code": -1,
            "ok": False,
            "subproc_stderr_tail": "",
            "subproc_stdout_tail": "",
            "script_sha256_prefix": script_sha_prefix,
            "script_size_bytes": script_size_bytes,
            "launch_failure_kind": "script_missing",
        }
    if script_size_bytes == 0:
        zmsg = "Phase C launch failed: script is zero bytes at {0}".format(script_path)
        return False, -1, zmsg, {
            "script_name": script_name,
            "script_path": script_path,
            "python_exe": python_exe,
            "cwd": repo_root,
            "started_at_utc": started_at,
            "finished_at_utc": started_at,
            "elapsed_sec": 0.0,
            "return_code": -1,
            "ok": False,
            "subproc_stderr_tail": zmsg,
            "subproc_stdout_tail": "",
            "script_sha256_prefix": script_sha_prefix,
            "script_size_bytes": script_size_bytes,
            "launch_failure_kind": "script_zero_bytes",
        }
    proc_env = env.copy()
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    rc = -1
    stderr_tail = ""
    stdout_tail = ""
    try:
        proc = subprocess.Popen(
            [python_exe, script_path],
            cwd=repo_root,
            env=proc_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout_data, stderr_data = proc.communicate()
        rc = proc.returncode
        if rc is None:
            rc = -1
        stderr_tail = _stderr_tail_4k(stderr_data)
        stdout_tail = _stdout_tail_4k(stdout_data)
    except KeyboardInterrupt:
        raise
    except Exception as exc:
        exc_class = exc.__class__.__name__
        exc_msg = str(exc)
        stderr_tail = _stderr_tail_4k(
            "Phase C launch failed during subprocess spawn: {0}: {1}".format(exc_class, exc_msg)
        )
        rc = -1
        spawn_exc_class = exc_class
        spawn_exc_msg = exc_msg
    else:
        spawn_exc_class = ""
        spawn_exc_msg = ""
    elapsed_sec = round(max(0.0, time.time() - t0), 3)
    finished_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    ok = rc == 0
    return ok, rc, stderr_tail, {
        "script_name": script_name,
        "script_path": script_path,
        "python_exe": python_exe,
        "cwd": repo_root,
        "started_at_utc": started_at,
        "finished_at_utc": finished_at,
        "elapsed_sec": elapsed_sec,
        "return_code": rc,
        "ok": ok,
        "subproc_stderr_tail": stderr_tail,
        "subproc_stdout_tail": stdout_tail,
        "script_sha256_prefix": script_sha_prefix,
        "script_size_bytes": script_size_bytes,
        "launch_failure_kind": "spawn_exception" if (not ok and spawn_exc_class) else "",
        "spawn_exception_class": spawn_exc_class,
        "spawn_exception_message": spawn_exc_msg,
    }


def _run_phase_c_with_timing(script_name, lab_root, python_exe, repo_root, env):
    """Run Phase C script with execution metadata and stderr tail for diagnostics."""
    ok, rc, stderr_tail, info = _run_phase_c_subprocess_with_stderr(
        script_name, lab_root, python_exe, repo_root, env
    )
    return ok, rc, info


def _read_cursor_run_id(lab_root, cursor_key):
    """Read a run_id from cursor. Returns non-empty string or empty."""
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if not os.path.exists(cursor_path):
        return ""
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            cursor = json.load(f)
        rid = cursor.get(cursor_key, "") or ""
        return str(rid).strip() if rid else ""
    except Exception:
        return ""


def _read_phase_error_code(lab_root, phase_name):
    """Read persisted phase-specific error code from diagnostics_state.json."""
    phase_key = "last_phase_{0}_error_code".format(str(phase_name or "").strip().lower())
    if not phase_key or phase_key == "last_phase__error_code":
        return ""
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.exists(state_path):
        return ""
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
        value = state.get(phase_key, "")
        return str(value).strip() if value else ""
    except Exception:
        return ""


_PHASE_CURSOR_KEYS = {"B": "last_phase_b_run_id", "C": "last_phase_c_run_id",
                      "D": "last_phase_d_run_id", "E": "last_phase_e_run_id"}

_HANDOFF_DETAIL_SUBPROC_OK_BUT_NOT_OK = (
    "Phase C subprocess exited successfully but persisted last_phase_c_ok is false "
    "(see diagnostics_state / run_cursor and ingest_write_summary for this run)."
)
_HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST = (
    "Phase C ingest manifest sha256 does not match latest Phase B manifest "
    "(last_manifest_sha256 vs last_ingest_manifest_sha256)."
)
_HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK = (
    "Phase C last_phase_c_ok disagrees between diagnostics_state and run_cursor."
)
_HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA = (
    "Phase C last_ingest_manifest_sha256 disagrees between diagnostics_state and run_cursor."
)
_HANDOFF_DETAIL_SUMMARY_SCHEMA_VERSION = (
    "Phase C canonical ingest summary summary_schema_version is missing or does not match expected contract version."
)


def _read_run_cursor(lab_root):
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    if not os.path.exists(cursor_path):
        return {}
    try:
        with open(cursor_path, "r", encoding="utf-8") as f:
            cur = json.load(f)
        if isinstance(cur, dict):
            return cur
    except Exception:
        pass
    return {}


def _read_diagnostics_state(lab_root):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    if not os.path.exists(state_path):
        return {}
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state = json.load(f)
        if isinstance(state, dict):
            return state
    except Exception:
        pass
    return {}


def _phase_c_subprocess_script_drift(lab_root, exec_info):
    """
    Compare on-disk subprocess script bytes to the fingerprint captured when the child ran.
    Returns (drift: bool, current_sha256_prefix: str, current_size: int).
    """
    exec_info = exec_info if isinstance(exec_info, dict) else {}
    path = str(exec_info.get("script_path") or "").strip()
    if not path:
        st = _read_diagnostics_state(lab_root)
        cr = _read_run_cursor(lab_root)
        path = str(st.get("last_phase_c_subprocess_script_path") or cr.get("last_phase_c_subprocess_script_path") or "").strip()
    rec_pref = str(exec_info.get("script_sha256_prefix") or "").strip()
    try:
        rec_sz = int(exec_info.get("script_size_bytes") or 0)
    except (TypeError, ValueError):
        rec_sz = 0
    if not rec_pref and rec_sz <= 0:
        return (False, "", 0)
    if not path or not os.path.isfile(path):
        return (False, "", 0)
    cur_pref = ""
    cur_sz = 0
    try:
        cur_sz = int(os.path.getsize(path))
    except Exception:
        cur_sz = 0
    try:
        with open(path, "rb") as sf:
            h = hashlib.sha256()
            block = sf.read(65536)
            while block:
                h.update(block)
                block = sf.read(65536)
        cur_pref = h.hexdigest()[:16]
    except Exception:
        cur_pref = ""
    drift = (cur_pref != rec_pref) or (cur_sz != rec_sz)
    return (drift, cur_pref, cur_sz)


def _read_phase_c_summary_for_handoff(lab_root, phase_c_run_id):
    """Read the canonical Phase C ingest summary for handoff validation."""
    phase_c_run_id = str(phase_c_run_id or "").strip()
    if not phase_c_run_id:
        return {}
    path = os.path.join(
        lab_root,
        "reports",
        "ingest_write_summary_{0}.json".format(phase_c_run_id),
    )
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _safe_json_write(path, payload):
    try:
        from lab_lock import replace_safe_write
        replace_safe_write(path, payload)
        return True
    except Exception:
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, sort_keys=True)
            return True
        except Exception:
            return False


def _phase_c_recovery_context(lab_root):
    state = _read_diagnostics_state(lab_root)
    cursor = _read_run_cursor(lab_root)
    b_sha = str(state.get("last_manifest_sha256", "") or cursor.get("last_manifest_sha256", "") or "").strip()
    c_sha = str(state.get("last_ingest_manifest_sha256", "") or cursor.get("last_ingest_manifest_sha256", "") or "").strip()
    b_run = str(state.get("last_phase_b_run_id", "") or cursor.get("last_phase_b_run_id", "") or "").strip()
    c_run = str(state.get("last_phase_c_run_id", "") or cursor.get("last_phase_c_run_id", "") or "").strip()
    manifest_path = str(state.get("last_manifest_path", "") or cursor.get("last_manifest_path", "") or "").strip()
    c_ok = state.get("last_phase_c_ok")
    if c_ok is None:
        c_ok = cursor.get("last_phase_c_ok")
    c_error = str(state.get("last_phase_c_error_code", "") or cursor.get("last_phase_c_error_code", "") or "").strip()
    return {
        "state": state,
        "cursor": cursor,
        "phase_b_run_id": b_run,
        "phase_c_run_id": c_run,
        "last_manifest_sha256": b_sha,
        "last_ingest_manifest_sha256": c_sha,
        "last_manifest_path": manifest_path,
        "last_phase_c_ok": c_ok,
        "last_phase_c_error_code": c_error,
    }


def _phase_c_shadow_recovery_needed(lab_root):
    ctx = _phase_c_recovery_context(lab_root)
    b_sha = ctx.get("last_manifest_sha256", "")
    c_sha = ctx.get("last_ingest_manifest_sha256", "")
    manifest_path = ctx.get("last_manifest_path", "")
    if not b_sha or not c_sha or b_sha == c_sha:
        if b_sha and c_sha and b_sha == c_sha:
            if ctx.get("last_phase_c_ok") is False and ctx.get("last_phase_c_error_code") == PHASE_C_DB_WRITE_ERROR:
                ctx["trigger_reason"] = "phase_c_db_write_error_for_current_manifest"
            else:
                return False, ctx
        else:
            return False, ctx
    if manifest_path and (not os.path.exists(manifest_path)):
        ctx["skip_reason"] = "current_manifest_path_missing"
        return False, ctx
    if not ctx.get("trigger_reason"):
        ctx["trigger_reason"] = "phase_c_ingest_manifest_sha_mismatch"
    return True, ctx


def _safe_shadow_db_path(lab_root):
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    try:
        lab_abs = os.path.normcase(os.path.abspath(lab_root))
        parent = os.path.normcase(os.path.abspath(os.path.dirname(db_path)))
        if parent != lab_abs:
            return ""
        if os.path.basename(db_path) != "unified_model_xp.db":
            return ""
    except Exception:
        return ""
    return db_path


def _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, payload):
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        pass
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    json_path = os.path.join(reports_dir, "phase_c_shadow_recovery_{0}.json".format(safe_rid))
    txt_path = os.path.join(reports_dir, "phase_c_shadow_recovery_{0}.txt".format(safe_rid))
    payload["report_json_path"] = json_path
    payload["report_txt_path"] = txt_path
    _safe_json_write(json_path, payload)
    try:
        lines = [
            "Phase C Shadow Recovery",
            "schema_version={0}".format(payload.get("schema_version", "")),
            "generated_at_utc={0}".format(payload.get("generated_at_utc", "")),
            "pipeline_run_id={0}".format(payload.get("pipeline_run_id", "")),
            "action={0}".format(payload.get("action", "")),
            "status={0}".format(payload.get("status", "")),
            "trigger_reason={0}".format(payload.get("trigger_reason", "")),
            "phase_b_run_id={0}".format(payload.get("phase_b_run_id", "")),
            "phase_c_run_id={0}".format(payload.get("phase_c_run_id", "")),
            "last_manifest_sha256={0}".format(payload.get("last_manifest_sha256", "")),
            "last_ingest_manifest_sha256={0}".format(payload.get("last_ingest_manifest_sha256", "")),
            "db_path={0}".format(payload.get("db_path", "")),
            "quarantined_db_path={0}".format(payload.get("quarantined_db_path", "")),
            "schema_path={0}".format(payload.get("schema_path", "")),
            "source_files_touched={0}".format(payload.get("source_files_touched", False)),
            "error_code={0}".format(payload.get("error_code", "")),
            "error_detail={0}".format(payload.get("error_detail", "")),
        ]
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass
    return json_path, txt_path


def _stamp_phase_c_shadow_recovery_state(lab_root, recovery):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    for path in (state_path, cursor_path):
        doc = {}
        loaded_ok = not os.path.exists(path)
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    doc = raw
                    loaded_ok = True
                else:
                    loaded_ok = False
            except Exception:
                loaded_ok = False
        if not loaded_ok:
            # Never replace an existing state/cursor file we could not parse as a dict;
            # doing so would wipe Phase B/C/D lineage (same hazard as execution handoff).
            continue
        doc["phase_c_shadow_recovery"] = dict(recovery)
        doc["last_phase_c_shadow_recovery_status"] = recovery.get("status", "")
        doc["last_phase_c_shadow_recovery_action"] = recovery.get("action", "")
        doc["last_phase_c_shadow_recovery_report_path"] = recovery.get("report_json_path", "")
        doc["updated_at_utc"] = recovery.get("generated_at_utc", iso_utc_now())
        _safe_json_write(path, doc)


def _quarantine_path_for_db(lab_root, pipeline_run_id, suffix):
    quarantine_dir = os.path.join(lab_root, "shadow_db_quarantine")
    try:
        if not os.path.exists(quarantine_dir):
            os.makedirs(quarantine_dir)
    except Exception:
        return ""
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    return os.path.join(quarantine_dir, "unified_model_xp_{0}_{1}{2}".format(safe_rid, stamp, suffix))


def _phase_c_recovery_retry_delays_sec():
    raw = str(os.environ.get("MEDICAFE_PHASE_C_RECOVERY_RENAME_RETRY_SEC", "") or "").strip()
    if raw:
        delays = []
        for part in raw.split(","):
            try:
                delay = float(str(part or "").strip())
            except Exception:
                delay = 0.0
            if delay > 0:
                delays.append(delay)
        if delays:
            return delays
    return [1.0, 2.0, 4.0, 8.0, 16.0, 32.0]


def _rename_with_phase_c_recovery_retries(src, dst, recovery, label):
    attempts = 0
    started = time.time()
    last_error = None
    delays = _phase_c_recovery_retry_delays_sec()
    while True:
        try:
            os.rename(src, dst)
            if attempts:
                recovery["quarantine_retry_count"] = int(recovery.get("quarantine_retry_count", 0) or 0) + attempts
                recovery["quarantine_retry_elapsed_sec"] = round(time.time() - started, 3)
                recovery["quarantine_retry_last_error"] = str(last_error or "")[:300]
            return
        except Exception as exc:
            last_error = exc
            if attempts >= len(delays):
                recovery["quarantine_retry_count"] = int(recovery.get("quarantine_retry_count", 0) or 0) + attempts
                recovery["quarantine_retry_elapsed_sec"] = round(time.time() - started, 3)
                recovery["quarantine_retry_last_error"] = str(last_error or "")[:300]
                recovery["quarantine_retry_failed_label"] = str(label or "")
                raise
            delay = delays[attempts]
            attempts += 1
            try:
                time.sleep(delay)
            except Exception:
                pass


def _run_phase_c_shadow_recovery_if_needed(lab_root, repo_root, pipeline_run_id):
    needed, ctx = _phase_c_shadow_recovery_needed(lab_root)
    if not needed:
        return True, "", "", None
    now = iso_utc_now()
    db_path = _safe_shadow_db_path(lab_root)
    schema_path = os.path.join(repo_root, "sql", "unified_relational_model_v1.sql")
    recovery = {
        "schema_version": 1,
        "generated_at_utc": now,
        "pipeline_run_id": pipeline_run_id,
        "action": PHASE_C_SHADOW_RECOVERY_ACTION,
        "status": "started",
        "trigger_reason": ctx.get("trigger_reason", ""),
        "phase_b_run_id": ctx.get("phase_b_run_id", ""),
        "phase_c_run_id": ctx.get("phase_c_run_id", ""),
        "last_manifest_sha256": ctx.get("last_manifest_sha256", ""),
        "last_ingest_manifest_sha256": ctx.get("last_ingest_manifest_sha256", ""),
        "last_manifest_path": ctx.get("last_manifest_path", ""),
        "db_path": db_path,
        "schema_path": schema_path,
        "quarantined_db_path": "",
        "quarantined_sidecars": [],
        "quarantine_retry_count": 0,
        "quarantine_retry_elapsed_sec": 0.0,
        "quarantine_retry_last_error": "",
        "quarantine_retry_failed_label": "",
        "source_files_touched": False,
        "error_code": "",
        "error_detail": "",
    }
    if not db_path:
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = "Unsafe shadow DB path; refusing recovery."
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery
    if not os.path.exists(schema_path):
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = "Schema file missing: {0}".format(schema_path)
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery
    quarantine_moves = []
    try:
        if os.path.exists(db_path):
            quarantine = _quarantine_path_for_db(lab_root, pipeline_run_id, ".db")
            if not quarantine:
                raise RuntimeError("Unable to create shadow DB quarantine directory")
            _rename_with_phase_c_recovery_retries(db_path, quarantine, recovery, "db")
            quarantine_moves.append((db_path, quarantine))
            recovery["quarantined_db_path"] = quarantine
        for suffix in ("-journal", "-wal", "-shm"):
            sidecar = db_path + suffix
            if os.path.exists(sidecar):
                q_sidecar = _quarantine_path_for_db(lab_root, pipeline_run_id, suffix)
                if q_sidecar:
                    _rename_with_phase_c_recovery_retries(sidecar, q_sidecar, recovery, suffix)
                    quarantine_moves.append((sidecar, q_sidecar))
                    recovery["quarantined_sidecars"].append(q_sidecar)
        with open(schema_path, "r", encoding="utf-8") as f:
            sql_content = f.read()
        conn = sqlite3.connect(db_path)
        try:
            conn.execute("PRAGMA foreign_keys = ON")
            conn.executescript(sql_content)
            conn.commit()
        finally:
            try:
                conn.close()
            except Exception:
                pass
        recovery["status"] = "completed"
        recovery["completed_at_utc"] = iso_utc_now()
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return True, "", "", recovery
    except Exception as e:
        # If the DB file was quarantined, sqlite3.connect created a new file at the
        # canonical path before executescript could fail. Rollback must remove that
        # partial file so the quarantined copy can move back to orig_path.
        if quarantine_moves:
            try:
                quarantined_origs = set(orig for orig, _ in quarantine_moves)
                if db_path in quarantined_origs and os.path.isfile(db_path):
                    os.remove(db_path)
            except Exception:
                pass
        for orig_path, moved_path in reversed(quarantine_moves):
            try:
                if os.path.exists(moved_path) and (not os.path.exists(orig_path)):
                    os.rename(moved_path, orig_path)
            except Exception:
                pass
        recovery["quarantined_db_path"] = ""
        recovery["quarantined_sidecars"] = []
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = str(e)[:300]
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery


def _force_phase_c_shadow_db_rebuild(lab_root, repo_root, pipeline_run_id, trigger_suffix):
    """
    Tier-2 self heal: always quarantine shadow DB and re-apply schema (plus PRAGMA integrity_check).
    """
    ctx = _phase_c_recovery_context(lab_root)
    now = iso_utc_now()
    db_path = _safe_shadow_db_path(lab_root)
    schema_path = os.path.join(repo_root, "sql", "unified_relational_model_v1.sql")
    recovery = {
        "schema_version": 1,
        "generated_at_utc": now,
        "pipeline_run_id": pipeline_run_id,
        "action": PHASE_C_SHADOW_RECOVERY_ACTION,
        "status": "started",
        "trigger_reason": "phase_c_self_heal_tier2:{0}".format(str(trigger_suffix or "").strip() or "forced"),
        "phase_b_run_id": ctx.get("phase_b_run_id", ""),
        "phase_c_run_id": ctx.get("phase_c_run_id", ""),
        "last_manifest_sha256": ctx.get("last_manifest_sha256", ""),
        "last_ingest_manifest_sha256": ctx.get("last_ingest_manifest_sha256", ""),
        "last_manifest_path": ctx.get("last_manifest_path", ""),
        "db_path": db_path,
        "schema_path": schema_path,
        "quarantined_db_path": "",
        "quarantined_sidecars": [],
        "quarantine_retry_count": 0,
        "quarantine_retry_elapsed_sec": 0.0,
        "quarantine_retry_last_error": "",
        "quarantine_retry_failed_label": "",
        "source_files_touched": False,
        "error_code": "",
        "error_detail": "",
    }
    if not db_path:
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = "Unsafe shadow DB path; refusing forced rebuild."
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery
    if not os.path.exists(schema_path):
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = "Schema file missing: {0}".format(schema_path)
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery
    quarantine_moves = []
    try:
        if os.path.exists(db_path):
            quarantine = _quarantine_path_for_db(lab_root, pipeline_run_id, ".db")
            if not quarantine:
                raise RuntimeError("Unable to create shadow DB quarantine directory")
            _rename_with_phase_c_recovery_retries(db_path, quarantine, recovery, "db")
            quarantine_moves.append((db_path, quarantine))
            recovery["quarantined_db_path"] = quarantine
        for suffix in ("-journal", "-wal", "-shm"):
            sidecar = db_path + suffix
            if os.path.exists(sidecar):
                q_sidecar = _quarantine_path_for_db(lab_root, pipeline_run_id, suffix)
                if q_sidecar:
                    _rename_with_phase_c_recovery_retries(sidecar, q_sidecar, recovery, suffix)
                    quarantine_moves.append((sidecar, q_sidecar))
                    recovery["quarantined_sidecars"].append(q_sidecar)
        with open(schema_path, "r", encoding="utf-8") as f:
            sql_content = f.read()
        conn = sqlite3.connect(db_path)
        try:
            conn.execute("PRAGMA foreign_keys = ON")
            conn.executescript(sql_content)
            conn.commit()
        finally:
            try:
                conn.close()
            except Exception:
                pass
        integrity = ""
        try:
            conn2 = sqlite3.connect(db_path)
            try:
                cur = conn2.execute("PRAGMA integrity_check")
                row = cur.fetchone()
                integrity = str(row[0]) if row else ""
            finally:
                conn2.close()
        except Exception as exc:
            integrity = "error:{0}".format(str(exc)[:200])
        recovery["integrity_check"] = integrity
        recovery["status"] = "completed"
        recovery["completed_at_utc"] = iso_utc_now()
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return True, "", "", recovery
    except Exception as e:
        if quarantine_moves:
            try:
                quarantined_origs = set(orig for orig, _ in quarantine_moves)
                if db_path in quarantined_origs and os.path.isfile(db_path):
                    os.remove(db_path)
            except Exception:
                pass
        for orig_path, moved_path in reversed(quarantine_moves):
            try:
                if os.path.exists(moved_path) and (not os.path.exists(orig_path)):
                    os.rename(moved_path, orig_path)
            except Exception:
                pass
        recovery["quarantined_db_path"] = ""
        recovery["quarantined_sidecars"] = []
        recovery["status"] = "failed"
        recovery["error_code"] = PHASE_C_SHADOW_RECOVERY_FAILED
        recovery["error_detail"] = str(e)[:300]
        _write_phase_c_shadow_recovery_report(lab_root, pipeline_run_id, recovery)
        _stamp_phase_c_shadow_recovery_state(lab_root, recovery)
        return False, recovery["error_code"], recovery["error_detail"], recovery


def _phase_c_handoff_failure(lab_root):
    """
    Return (error_code, detail) when Phase C subprocess exited 0 but persisted
    handoff (Phase B vs ingest lineage, last_phase_c_ok) is not coherent.
    Phase B manifest sha256 uses the same state-then-cursor merge as handoff snapshots.
    """
    state = _read_diagnostics_state(lab_root)
    cursor = _read_run_cursor(lab_root)
    if not state and not cursor:
        return "", ""

    c_ok_state = state.get("last_phase_c_ok")
    c_ok_cursor = cursor.get("last_phase_c_ok")
    if c_ok_state is not None and c_ok_cursor is not None and c_ok_state != c_ok_cursor:
        return ("PHASE_C_HANDOFF_INCOHERENT", _HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK)

    c_sha_state = str(state.get("last_ingest_manifest_sha256", "") or "").strip()
    c_sha_cursor = str(cursor.get("last_ingest_manifest_sha256", "") or "").strip()
    if c_sha_state and c_sha_cursor and c_sha_state != c_sha_cursor:
        return ("PHASE_C_HANDOFF_INCOHERENT", _HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA)

    c_ok = c_ok_state if c_ok_state is not None else c_ok_cursor
    b_sha = str(_merge_state_cursor_scalar(state, cursor, "last_manifest_sha256") or "").strip()
    c_sha = c_sha_state or c_sha_cursor
    recovery = state.get("phase_c_shadow_recovery")
    recovery_status = ""
    recovery_trigger = ""
    if isinstance(recovery, dict):
        recovery_status = str(recovery.get("status", "") or "").strip()
        recovery_trigger = str(recovery.get("trigger_reason", "") or "").strip()
    if recovery_status == "completed" and recovery_trigger and b_sha and c_sha and b_sha != c_sha:
        return (
            "PHASE_C_HANDOFF_INCOMPLETE",
            "Phase C shadow recovery completed, but Phase C did not persist a fresh ingest handoff for latest Phase B manifest.",
        )
    if b_sha and not c_sha_state and not c_sha_cursor:
        return (
            "PHASE_C_HANDOFF_INCOHERENT",
            "Phase C ingest manifest sha256 missing after subprocess ok (Phase B summary lineage missing or ingest did not persist).",
        )
    if b_sha and c_sha and b_sha != c_sha:
        return (
            "PHASE_C_HANDOFF_INCOHERENT",
            _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST,
        )

    c_err = str(state.get("last_phase_c_error_code", "") or "").strip()
    if c_ok_state is False or c_ok_cursor is False:
        if c_err:
            return c_err, _HANDOFF_DETAIL_SUBPROC_OK_BUT_NOT_OK
        return "PHASE_C_HANDOFF_FAILED", _HANDOFF_DETAIL_SUBPROC_OK_BUT_NOT_OK

    c_run_id = str(state.get("last_phase_c_run_id", "") or cursor.get("last_phase_c_run_id", "") or "").strip()
    diag_run_id = str(
        _merge_state_cursor_scalar(state, cursor, "last_ingest_from_manifest_diag_run_id") or ""
    ).strip()
    summary = _read_phase_c_summary_for_handoff(lab_root, c_run_id)
    if c_run_id and not summary:
        if diag_run_id and diag_run_id != c_run_id:
            return (
                "PHASE_C_HANDOFF_INCOMPLETE",
                "Phase C did not persist a fresh ingest handoff for latest Phase B manifest.",
            )
        return (
            "PHASE_C_HANDOFF_INCOHERENT",
            "Phase C canonical ingest summary is missing for last_phase_c_run_id={0}".format(c_run_id),
        )
    if summary:
        summary_ok = summary.get("ok")
        if summary_ok is not True:
            summary_error = str(summary.get("error_code", "") or "").strip()
            if summary_error:
                return summary_error, "Phase C canonical ingest summary reports ok=False."
            return "PHASE_C_HANDOFF_INCOHERENT", "Phase C canonical ingest summary reports ok=False."
        summary_schema_version = summary.get("summary_schema_version")
        if summary_schema_version != PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION:
            return (
                "PHASE_C_HANDOFF_INCOHERENT",
                "{0} expected={1} got={2}".format(
                    _HANDOFF_DETAIL_SUMMARY_SCHEMA_VERSION,
                    PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                    summary_schema_version,
                ),
            )
        summary_sha = str(summary.get("manifest_sha256", "") or "").strip()
        if c_sha_state and summary_sha and c_sha_state != summary_sha:
            return (
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical summary manifest_sha256 disagrees with diagnostics_state.",
            )
        if c_sha_cursor and summary_sha and c_sha_cursor != summary_sha:
            return (
                "PHASE_C_HANDOFF_INCOHERENT",
                "Phase C canonical summary manifest_sha256 disagrees with run_cursor.",
            )

    if b_sha and c_ok is not True:
        return (
            "PHASE_C_HANDOFF_INCOMPLETE",
            "Phase C did not persist last_phase_c_ok=True for latest Phase B manifest",
        )
    return "", ""


def _expected_phase_c_summary_path(lab_root, phase_c_run_id):
    rid = str(phase_c_run_id or "").strip()
    if not rid:
        return ""
    return os.path.join(lab_root, "reports", "ingest_write_summary_{0}.json".format(rid))


def _merge_state_cursor_scalar(state, cursor, key, as_bool_ok=False):
    st = state if isinstance(state, dict) else {}
    cr = cursor if isinstance(cursor, dict) else {}
    if as_bool_ok:
        v = st.get("last_phase_c_ok")
        if v is None:
            v = cr.get("last_phase_c_ok")
        return v
    v = st.get(key, "")
    if v is None or v == "":
        v = cr.get(key, "")
    if v is None:
        return ""
    return v


def _snapshot_phase_c_handoff_state(lab_root):
    """Point-in-time handoff slice for Phase C execution diagnostics."""
    state = _read_diagnostics_state(lab_root)
    cursor = _read_run_cursor(lab_root)
    st_path = os.path.join(lab_root, "diagnostics_state.json")
    ds_mtime_epoch = None
    if os.path.isfile(st_path):
        try:
            ds_mtime_epoch = os.path.getmtime(st_path)
        except Exception:
            ds_mtime_epoch = None
    c_run = str(_merge_state_cursor_scalar(state, cursor, "last_phase_c_run_id") or "").strip()
    summary_path = _expected_phase_c_summary_path(lab_root, c_run)
    digest = {
        "ingest_summary_exists": False,
        "ingest_summary_ok": None,
        "ingest_summary_schema_version": None,
        "ingest_summary_manifest_sha256": "",
        "ingest_summary_error_code": "",
    }
    if summary_path and os.path.isfile(summary_path):
        digest["ingest_summary_exists"] = True
        try:
            with open(summary_path, "r", encoding="utf-8") as f:
                sj = json.load(f)
            if isinstance(sj, dict):
                digest["ingest_summary_ok"] = sj.get("ok")
                digest["ingest_summary_schema_version"] = sj.get("summary_schema_version")
                digest["ingest_summary_manifest_sha256"] = str(sj.get("manifest_sha256", "") or "").strip()
                digest["ingest_summary_error_code"] = str(sj.get("error_code", "") or "").strip()
        except Exception:
            pass
    return {
        "last_phase_b_run_id": str(_merge_state_cursor_scalar(state, cursor, "last_phase_b_run_id") or "").strip(),
        "last_manifest_path": str(_merge_state_cursor_scalar(state, cursor, "last_manifest_path") or "").strip(),
        "last_manifest_sha256": str(_merge_state_cursor_scalar(state, cursor, "last_manifest_sha256") or "").strip(),
        "last_phase_c_run_id": c_run,
        "last_phase_c_ok": _merge_state_cursor_scalar(state, cursor, "", as_bool_ok=True),
        "last_phase_c_error_code": str(_merge_state_cursor_scalar(state, cursor, "last_phase_c_error_code") or "").strip(),
        "last_ingest_manifest_path": str(
            _merge_state_cursor_scalar(state, cursor, "last_ingest_manifest_path") or ""
        ).strip(),
        "last_ingest_manifest_sha256": str(
            _merge_state_cursor_scalar(state, cursor, "last_ingest_manifest_sha256") or ""
        ).strip(),
        "expected_ingest_summary_path": summary_path,
        "ingest_summary_exists": digest["ingest_summary_exists"],
        "ingest_summary_ok": digest["ingest_summary_ok"],
        "ingest_summary_schema_version": digest["ingest_summary_schema_version"],
        "ingest_summary_manifest_sha256": digest["ingest_summary_manifest_sha256"],
        "ingest_summary_error_code": digest["ingest_summary_error_code"],
        "diagnostics_state_mtime_epoch": ds_mtime_epoch,
    }


def _recovery_payload_for_phase_c_diag(recovery):
    if not isinstance(recovery, dict):
        return {
            "recovery_attempted": False,
            "recovery_status": "",
            "recovery_trigger_reason": "",
            "recovery_report_path": "",
            "recovery_error_code": "",
            "recovery_error_detail": "",
        }
    return {
        "recovery_attempted": True,
        "recovery_status": str(recovery.get("status", "") or ""),
        "recovery_trigger_reason": str(recovery.get("trigger_reason", "") or ""),
        "recovery_report_path": str(recovery.get("report_json_path", "") or ""),
        "recovery_error_code": str(recovery.get("error_code", "") or ""),
        "recovery_error_detail": str(recovery.get("error_detail", "") or ""),
    }


def _classify_phase_c_execution_blocker(recovery_ok, subproc_ok, handoff_err, handoff_detail, exec_rc, exec_info=None):
    """Map pipeline outcome to a stable blocker_class and operator-facing summary line."""
    hd = str(handoff_detail or "")
    hd_lower = hd.lower()
    he = str(handoff_err or "")
    rc = exec_rc
    try:
        rc = int(rc)
    except (TypeError, ValueError):
        rc = -1
    if he == PHASE_C_CIRCUIT_OPEN:
        return (
            "phase_c_circuit_open",
            "Phase C self-heal circuit is open; ingest was not run until auto-reset.",
        )
    if not recovery_ok:
        return (
            "phase_c_not_run_recovery_failed",
            "Phase C shadow recovery failed; ingest subprocess was not run.",
        )
    if not subproc_ok:
        launch_kind = ""
        if isinstance(exec_info, dict):
            launch_kind = str(exec_info.get("launch_failure_kind") or "").strip()
        if launch_kind == "script_missing":
            return (
                "phase_c_script_missing",
                "Phase C ingest script is missing; deployment/configuration issue prevented launch.",
            )
        if launch_kind == "script_zero_bytes":
            return (
                "phase_c_script_zero_bytes",
                "Phase C ingest script is empty (0 bytes); deployment/configuration issue prevented launch.",
            )
        if launch_kind == "spawn_exception":
            return (
                "phase_c_subprocess_spawn_exception",
                "Phase C ingest launch raised a subprocess spawn exception before execution started.",
            )
        return (
            "phase_c_subprocess_nonzero",
            "Phase C ingest subprocess exited with non-zero status (rc={0}); handoff not evaluated.".format(rc),
        )
    if not he:
        return (
            "phase_c_handoff_ok",
            "Phase C ingest subprocess exited 0 and handoff is coherent; Layer 1 may proceed when Phase D runs.",
        )
    if he == "PHASE_C_HANDOFF_INCOMPLETE" and "recovery completed" in hd:
        return (
            "phase_c_post_recovery_handoff_incomplete",
            "Phase C recovery completed, but ingest did not write a current summary for latest Phase B manifest; "
            "Layer 1 not reached.",
        )
    if "canonical ingest summary is missing" in hd:
        return (
            "phase_c_expected_summary_missing",
            "Phase C expected ingest_write_summary for last_phase_c_run_id is missing; Layer 1 not reached.",
        )
    if "expected contract version" in hd or "summary_schema_version" in hd:
        return (
            "phase_c_summary_schema_mismatch",
            "Phase C ingest summary schema version does not match the expected contract.",
        )
    if "canonical ingest summary reports ok=False" in hd:
        return (
            "phase_c_summary_reports_not_ok",
            "Phase C canonical ingest summary reports ok=False.",
        )
    if _HANDOFF_DETAIL_CURSOR_STATE_PHASE_C_OK in hd or _HANDOFF_DETAIL_CURSOR_STATE_INGEST_SHA in hd:
        return (
            "phase_c_state_cursor_disagree",
            "Phase C handoff fields disagree between diagnostics_state.json and run_cursor.json.",
        )
    if _HANDOFF_DETAIL_SHA_PHASE_B_VS_INGEST in hd or "does not match latest Phase B manifest" in hd:
        return (
            "phase_c_latest_manifest_sha_mismatch",
            "Phase B manifest sha256 does not match last persisted ingest manifest sha256.",
        )
    if "ingest manifest sha256 missing" in hd_lower:
        return (
            "phase_c_ingest_manifest_sha_missing",
            "Phase C last_ingest_manifest_sha256 is empty in both diagnostics_state and run_cursor while Phase B manifest sha is set.",
        )
    if "diagnostics_state.json mtime did not advance" in hd_lower:
        return (
            "phase_c_persist_did_not_touch_state",
            "Phase C subprocess exited 0 but diagnostics_state.json mtime did not advance "
            "(subprocess may write to a different lab path or never reached persist_phase_c_state).",
        )
    if "ingest_from_manifest_diagnostics_latest.json" in hd_lower and "missing" in hd_lower:
        return (
            "phase_c_ingest_diagnostics_missing",
            "Phase C subprocess exited 0 but ingest_from_manifest_diagnostics_latest.json is missing from reports.",
        )
    if "subprocess script drift" in hd_lower or "script fingerprint drift" in hd_lower:
        return (
            "phase_c_subprocess_script_drift",
            "Phase C ingest script on disk no longer matches the fingerprint captured when the subprocess ran.",
        )
    if "canonical summary manifest_sha256 disagrees" in hd:
        return (
            "phase_c_state_cursor_disagree",
            "Phase C ingest summary manifest_sha256 disagrees with persisted lab state.",
        )
    if he == "PHASE_C_HANDOFF_INCOMPLETE":
        return (
            "phase_c_latest_manifest_sha_mismatch",
            "Phase C did not persist a successful handoff for the latest Phase B manifest.",
        )
    if he:
        return (
            "phase_c_summary_reports_not_ok",
            hd or "Phase C handoff validation failed.",
        )
    return (
        "phase_c_handoff_ok",
        "Phase C ingest completed.",
    )


def _write_phase_c_execution_handoff_report_files(lab_root, pipeline_run_id, payload):
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        pass
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(pipeline_run_id or "unknown"))
    json_path = os.path.join(reports_dir, "phase_c_execution_handoff_{0}.json".format(safe_rid))
    txt_path = os.path.join(reports_dir, "phase_c_execution_handoff_{0}.txt".format(safe_rid))
    payload["report_json_path"] = json_path
    payload["report_txt_path"] = txt_path
    _safe_json_write(json_path, payload)
    try:
        lines = [
            "Phase C Execution / Handoff Diagnostic",
            "schema_version={0}".format(payload.get("schema_version", "")),
            "generated_at_utc={0}".format(payload.get("generated_at_utc", "")),
            "pipeline_run_id={0}".format(payload.get("pipeline_run_id", "")),
            "phase={0}".format(payload.get("phase", "")),
            "blocker_class={0}".format(payload.get("blocker_class", "")),
            "publish_failure_class={0}".format(payload.get("publish_failure_class", "")),
            "operator_summary_line={0}".format(payload.get("operator_summary_line", "")),
            "handoff_error_code={0}".format((payload.get("handoff") or {}).get("error_code", "")),
            "handoff_detail={0}".format((payload.get("handoff") or {}).get("detail", "")),
            "subprocess_return_code={0}".format((payload.get("subprocess") or {}).get("return_code", "")),
        ]
        stderr_tail = str((payload.get("subprocess") or {}).get("subproc_stderr_tail") or "")
        if stderr_tail:
            lines.append("subproc_stderr_tail={0}".format(stderr_tail.replace("\r", " ").replace("\n", " ")[:2000]))
        stdout_tail = str((payload.get("subprocess") or {}).get("subproc_stdout_tail") or "")
        if stdout_tail:
            lines.append("subproc_stdout_tail={0}".format(stdout_tail.replace("\r", " ").replace("\n", " ")[:2000]))
        persist = payload.get("persist_run_id") or {}
        if isinstance(persist, dict) and (persist.get("before") or persist.get("after")):
            lines.append(
                "persist_run_id_before={0} after={1}".format(persist.get("before", ""), persist.get("after", ""))
            )
        if "ingest_diagnostics_present" in payload:
            lines.append("ingest_diagnostics_present={0}".format(payload.get("ingest_diagnostics_present")))
        if "bootstrap_diagnostics_present" in payload:
            lines.append("bootstrap_diagnostics_present={0}".format(payload.get("bootstrap_diagnostics_present")))
        if "bootstrap_diagnostics_path" in payload:
            lines.append("bootstrap_diagnostics_path={0}".format(payload.get("bootstrap_diagnostics_path")))
        if "bootstrap_stage" in payload:
            lines.append("bootstrap_stage={0}".format(payload.get("bootstrap_stage")))
        if "bootstrap_timeline_present" in payload:
            lines.append("bootstrap_timeline_present={0}".format(payload.get("bootstrap_timeline_present")))
        if "bootstrap_timeline_stage_count" in payload:
            lines.append("bootstrap_timeline_stage_count={0}".format(payload.get("bootstrap_timeline_stage_count")))
        if "bootstrap_timeline_last_stage" in payload:
            lines.append("bootstrap_timeline_last_stage={0}".format(payload.get("bootstrap_timeline_last_stage")))
        if "bootstrap_timeline_last_elapsed_since_process_start_sec" in payload:
            lines.append("bootstrap_timeline_last_elapsed_since_process_start_sec={0}".format(
                payload.get("bootstrap_timeline_last_elapsed_since_process_start_sec")))
        tail = payload.get("bootstrap_timeline_stages_tail")
        if isinstance(tail, list) and tail:
            stages = []
            for row in tail[-8:]:
                if not isinstance(row, dict):
                    continue
                stages.append("{0}:{1}@{2}s".format(
                    row.get("stage_seq", ""),
                    row.get("stage", ""),
                    row.get("elapsed_since_process_start_sec", ""),
                ))
            if stages:
                lines.append("bootstrap_timeline_stages_tail={0}".format(" | ".join(stages)))
        if "summary_present" in payload:
            lines.append("summary_present={0}".format(payload.get("summary_present")))
        if "state_lineage_updated" in payload:
            lines.append("state_lineage_updated={0}".format(payload.get("state_lineage_updated")))
        if "cursor_lineage_updated" in payload:
            lines.append("cursor_lineage_updated={0}".format(payload.get("cursor_lineage_updated")))
        if "persist_run_id_changed" in payload:
            lines.append("persist_run_id_changed={0}".format(payload.get("persist_run_id_changed")))
        sp = payload.get("subprocess") or {}
        if isinstance(sp, dict):
            if "script_drift_detected" in sp:
                lines.append("script_drift_detected={0}".format(sp.get("script_drift_detected")))
            if sp.get("script_current_sha256_prefix"):
                lines.append("script_current_sha256_prefix={0}".format(sp.get("script_current_sha256_prefix")))
            try:
                if "script_current_size_bytes" in sp:
                    cur_sz = sp.get("script_current_size_bytes")
                    if cur_sz is not None and str(cur_sz).strip() != "":
                        lines.append("script_current_size_bytes={0}".format(cur_sz))
            except Exception:
                pass
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass
    return json_path, txt_path


def _phase_c_ingest_diag_presence(lab_root):
    """
    Return ingest diagnostics availability with bootstrap sentinel awareness.
    Finish diagnostics and bootstrap sentinel are separate artifacts.
    """
    reports_dir = os.path.join(lab_root, "reports")
    latest_path = os.path.join(reports_dir, "ingest_from_manifest_diagnostics_latest.json")
    bootstrap_latest_path = os.path.join(
        reports_dir, "ingest_from_manifest_bootstrap_latest.json"
    )
    finish_present = False
    bootstrap_present = False
    bootstrap_path = ""
    bootstrap_stage = ""
    if os.path.isfile(latest_path):
        finish_present = True
    if os.path.isfile(bootstrap_latest_path):
        stage = ""
        try:
            with open(bootstrap_latest_path, "r", encoding="utf-8") as handle:
                doc = json.load(handle)
            if isinstance(doc, dict):
                stage = str(doc.get("stage") or doc.get("bootstrap_stage") or "").strip().lower()
        except Exception:
            stage = ""
        bootstrap_present = True
        if not bootstrap_path:
            bootstrap_path = bootstrap_latest_path
        if stage:
            bootstrap_stage = stage
    return finish_present, latest_path, bootstrap_present, bootstrap_path, bootstrap_stage


def _phase_c_bootstrap_timeline_summary(lab_root, max_stages=12):
    reports_dir = os.path.join(lab_root, "reports")
    path = os.path.join(reports_dir, "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
    out = {
        "present": False,
        "path": path,
        "stage_count": 0,
        "last_stage": "",
        "last_stage_seq": 0,
        "last_elapsed_since_process_start_sec": 0.0,
        "stages_tail": [],
    }
    if not os.path.isfile(path):
        return out
    rows = []
    try:
        with open(path, "r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    doc = json.loads(line)
                except Exception:
                    continue
                if isinstance(doc, dict):
                    rows.append(doc)
    except Exception:
        return out
    out["present"] = True
    out["stage_count"] = len(rows)
    if rows:
        last = rows[-1]
        out["last_stage"] = str(last.get("stage") or "").strip()
        try:
            out["last_stage_seq"] = int(last.get("stage_seq") or 0)
        except Exception:
            out["last_stage_seq"] = 0
        try:
            out["last_elapsed_since_process_start_sec"] = float(
                last.get("elapsed_since_process_start_sec") or 0.0)
        except Exception:
            out["last_elapsed_since_process_start_sec"] = 0.0
    tail = rows[-int(max_stages or 12):]
    for row in tail:
        out["stages_tail"].append({
            "stage": str(row.get("stage") or "").strip(),
            "stage_seq": row.get("stage_seq"),
            "elapsed_since_process_start_sec": row.get("elapsed_since_process_start_sec"),
            "generated_at_utc": str(row.get("generated_at_utc") or "").strip(),
            "detail": str(row.get("detail") or "")[:256],
        })
    return out


def _stamp_phase_c_execution_handoff_state(lab_root, report_json_path, status, blocker_class, generated_at, exec_info=None):
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    for path in (state_path, cursor_path):
        doc = {}
        loaded_ok = not os.path.exists(path)
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    raw = json.load(f)
                if isinstance(raw, dict):
                    doc = raw
                    loaded_ok = True
            except Exception:
                loaded_ok = False
        if not loaded_ok:
            # Never replace an existing state/cursor file we could not parse as a dict;
            # doing so would wipe Phase B/C/D lineage and break handoff validation.
            continue
        doc["last_phase_c_execution_handoff_report_path"] = report_json_path or ""
        doc["last_phase_c_execution_handoff_status"] = status or ""
        doc["last_phase_c_execution_handoff_blocker_class"] = blocker_class or ""
        doc["last_phase_c_execution_handoff_generated_at_utc"] = generated_at or ""
        doc["updated_at_utc"] = generated_at or iso_utc_now()
        if isinstance(exec_info, dict):
            sp = str(exec_info.get("script_path") or "").strip()
            if sp:
                doc["last_phase_c_subprocess_script_path"] = sp
            pref = str(exec_info.get("script_sha256_prefix") or "").strip()
            if pref:
                doc["last_phase_c_subprocess_script_sha256_prefix"] = pref
            try:
                sz = int(exec_info.get("script_size_bytes") or 0)
            except (TypeError, ValueError):
                sz = 0
            if sz > 0:
                doc["last_phase_c_subprocess_script_size_bytes"] = sz
        _safe_json_write(path, doc)


def _write_phase_c_ingest_stderr_tail_latest(lab_root, exec_info, final_ok):
    """
    When Phase C handoff is not fully ok, persist stderr tail to reports/ so
    evidence bundles can attach a stable filename (not only JSON-in-handoff).
    """
    if final_ok:
        return
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if reports_dir and not os.path.exists(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return
    tail = ""
    if isinstance(exec_info, dict):
        tail = str(exec_info.get("subproc_stderr_tail") or "")
    body = tail if tail.strip() else "[empty]\n"
    out_path = os.path.join(reports_dir, "phase_c_ingest_stderr_tail_latest.txt")
    try:
        with open(out_path, "w", encoding="utf-8") as handle:
            handle.write(body)
            if not body.endswith("\n"):
                handle.write("\n")
    except Exception:
        pass


def _emit_phase_c_execution_handoff_report(
    lab_root,
    pipeline_run_id,
    snapshot_pre,
    recovery,
    exec_info,
    recovery_ok,
    subproc_ok,
    handoff_err,
    handoff_detail,
):
    """Write phase_c_execution_handoff_* and stamp lab state/cursor pointers."""
    snapshot_pre = snapshot_pre if isinstance(snapshot_pre, dict) else {}
    snapshot_after = _snapshot_phase_c_handoff_state(lab_root)
    exec_rc = None
    if isinstance(exec_info, dict):
        exec_rc = exec_info.get("return_code")
    blocker_class, operator_summary_line = _classify_phase_c_execution_blocker(
        recovery_ok, subproc_ok, handoff_err, handoff_detail, exec_rc, exec_info
    )
    pre_rid = str(snapshot_pre.get("last_phase_c_run_id") or "").strip()
    post_rid = str(snapshot_after.get("last_phase_c_run_id") or "").strip()
    hd_lower = str(handoff_detail or "").lower()
    summary_missing = "canonical ingest summary is missing" in hd_lower
    mt_before = snapshot_pre.get("diagnostics_state_mtime_epoch")
    mt_after = snapshot_after.get("diagnostics_state_mtime_epoch")
    (
        ingest_diagnostics_present,
        ingest_diag_latest_path,
        bootstrap_diagnostics_present,
        bootstrap_diagnostics_path,
        bootstrap_stage,
    ) = _phase_c_ingest_diag_presence(lab_root)
    bootstrap_timeline = _phase_c_bootstrap_timeline_summary(lab_root)
    summary_present = bool(snapshot_after.get("ingest_summary_exists"))
    state_doc = _read_diagnostics_state(lab_root)
    cursor_doc = _read_run_cursor(lab_root)
    state_ingest_sha = str((state_doc or {}).get("last_ingest_manifest_sha256", "") or "").strip()
    cursor_ingest_sha = str((cursor_doc or {}).get("last_ingest_manifest_sha256", "") or "").strip()
    merged_b_sha = str(snapshot_after.get("last_manifest_sha256", "") or "").strip()
    merged_ingest_sha = str(snapshot_after.get("last_ingest_manifest_sha256", "") or "").strip()
    summary_manifest_sha = str(snapshot_after.get("ingest_summary_manifest_sha256", "") or "").strip()
    # When Phase B never stamped last_manifest_sha256, handoff may still be coherent (ingest-only /
    # bootstrap workflows). Require B-vs-ingest agreement only when merged_b_sha is present.
    state_lineage_updated = bool(state_ingest_sha)
    cursor_lineage_updated = bool(cursor_ingest_sha)
    if merged_b_sha:
        state_lineage_updated = state_lineage_updated and state_ingest_sha == merged_b_sha
        cursor_lineage_updated = cursor_lineage_updated and cursor_ingest_sha == merged_b_sha
    if summary_manifest_sha:
        state_lineage_updated = state_lineage_updated and state_ingest_sha == summary_manifest_sha
        cursor_lineage_updated = cursor_lineage_updated and cursor_ingest_sha == summary_manifest_sha
    persist_run_id_changed = bool(pre_rid and post_rid and pre_rid != post_rid)
    subproc_payload = dict(exec_info) if isinstance(exec_info, dict) else {}
    drift = False
    drift_cur_pref = ""
    drift_cur_sz = 0
    if subproc_payload:
        drift, drift_cur_pref, drift_cur_sz = _phase_c_subprocess_script_drift(lab_root, exec_info)
        subproc_payload["script_drift_detected"] = drift
        subproc_payload["script_current_sha256_prefix"] = drift_cur_pref
        subproc_payload["script_current_size_bytes"] = drift_cur_sz

    # blocker_class override stack when subprocess exited 0 but handoff failed (priority 1 is strongest):
    #   1) phase_c_persist_did_not_touch_state — diagnostics_state.json mtime unchanged while handoff reports failure
    #      (skipped when the handoff detail indicates a missing canonical ingest summary — use the summary-specific blocker)
    #   2) phase_c_script_entrypoint_not_observed — no summary, no bootstrap, no finish diagnostics after rc==0
    #   3) phase_c_script_entered_but_no_finish_diag — bootstrap exists but finish diagnostics are absent
    #   4) phase_c_ingest_diagnostics_missing — fallback missing-finish-diag bucket
    #   5) phase_c_subprocess_script_drift — ingest script bytes changed vs subprocess fingerprint
    #   6) phase_c_subproc_ok_but_no_persist — last_phase_c_run_id unchanged (excluded from #1)
    if handoff_err:
        mt_override = (
            subproc_ok
            and exec_rc == 0
            and mt_before is not None
            and mt_after is not None
            and mt_before == mt_after
            and not (pre_rid and pre_rid == post_rid and not summary_missing)
            and not summary_missing
        )
        entrypoint_not_observed_override = (
            subproc_ok
            and exec_rc == 0
            and not summary_present
            and not ingest_diagnostics_present
            and not bootstrap_diagnostics_present
        )
        entered_no_finish_override = (
            subproc_ok
            and exec_rc == 0
            and not ingest_diagnostics_present
            and bootstrap_diagnostics_present
        )
        ingest_missing_override = (
            subproc_ok
            and exec_rc == 0
            and not ingest_diagnostics_present
            and not entrypoint_not_observed_override
            and not entered_no_finish_override
        )
        drift_override = subproc_ok and exec_rc == 0 and drift
        rid_stuck_override = (
            subproc_ok
            and pre_rid
            and pre_rid == post_rid
            and not summary_missing
        )
        if mt_override:
            blocker_class = "phase_c_persist_did_not_touch_state"
            operator_summary_line = (
                "Phase C subprocess exited 0 but diagnostics_state.json mtime did not advance "
                "(subprocess may write to a different lab path or never reached persist_phase_c_state)."
            )
        elif entrypoint_not_observed_override:
            blocker_class = "phase_c_script_entrypoint_not_observed"
            operator_summary_line = (
                "Phase C subprocess exited 0 but no bootstrap or finish diagnostics were observed "
                "(script entrypoint may not have executed)."
            )
        elif entered_no_finish_override:
            blocker_class = "phase_c_script_entered_but_no_finish_diag"
            operator_summary_line = (
                "Phase C subprocess exited 0 and bootstrap diagnostics were observed, "
                "but finish diagnostics were not published."
            )
        elif ingest_missing_override:
            blocker_class = "phase_c_ingest_diagnostics_missing"
            operator_summary_line = (
                "Phase C subprocess exited 0 but ingest_from_manifest_diagnostics_latest.json is missing from reports."
            )
        elif drift_override:
            blocker_class = "phase_c_subprocess_script_drift"
            operator_summary_line = (
                "Phase C ingest script on disk no longer matches the fingerprint captured when the subprocess ran."
            )
        elif rid_stuck_override:
            blocker_class = "phase_c_subproc_ok_but_no_persist"
            operator_summary_line = (
                "Phase C subprocess exited 0 but last_phase_c_run_id did not advance "
                "(ingest persist did not update lineage)."
            )
    # When circuit opens, preserve latest real-attempt root blocker class so the
    # actionable launch/root cause is not hidden by a generic circuit state.
    if str(handoff_err or "") == PHASE_C_CIRCUIT_OPEN and isinstance(exec_info, dict):
        root_blocker = str(exec_info.get("circuit_open_root_blocker_class") or "").strip()
        if root_blocker:
            blocker_class = root_blocker
            operator_summary_line = (
                "Phase C circuit is open; latest root blocker remains {0}.".format(root_blocker)
            )
    final_ok = (
        recovery_ok
        and subproc_ok
        and not (handoff_err or "")
    )
    publish_failure_class = "publish_ok"
    if subproc_ok and exec_rc == 0:
        if not ingest_diagnostics_present:
            if bootstrap_diagnostics_present:
                publish_failure_class = "finish_diagnostics_missing"
            else:
                publish_failure_class = "entrypoint_not_observed"
        elif not summary_present:
            publish_failure_class = "summary_missing"
        elif not state_lineage_updated:
            publish_failure_class = "state_lineage_missing"
        elif not cursor_lineage_updated:
            publish_failure_class = "cursor_lineage_missing"
        elif merged_b_sha and (not merged_ingest_sha or not summary_manifest_sha):
            publish_failure_class = "manifest_sha_missing"
    _write_phase_c_ingest_stderr_tail_latest(lab_root, exec_info, final_ok)
    status = "ok" if final_ok else "failed"
    generated_at = iso_utc_now()
    recovery_payload = _recovery_payload_for_phase_c_diag(recovery)
    payload = {
        "schema_version": PHASE_C_EXEC_HANDOFF_SCHEMA_VERSION,
        "generated_at_utc": generated_at,
        "pipeline_run_id": pipeline_run_id,
        "phase": "C",
        "blocker_class": blocker_class,
        "operator_summary_line": operator_summary_line,
        "status": status,
        "snapshot_before": snapshot_pre,
        "snapshot_after": snapshot_after,
        "recovery": recovery_payload,
        "subprocess": subproc_payload,
        "handoff": {
            "error_code": handoff_err or "",
            "detail": handoff_detail or "",
        },
        "persist_run_id": {"before": pre_rid, "after": post_rid},
        "persist_run_id_changed": persist_run_id_changed,
        "expected_summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
        "diagnostics_state_mtime_epoch_before": mt_before,
        "diagnostics_state_mtime_epoch_after": mt_after,
        "summary_present": summary_present,
        "ingest_diagnostics_present": ingest_diagnostics_present,
        "bootstrap_diagnostics_present": bootstrap_diagnostics_present,
        "bootstrap_diagnostics_path": bootstrap_diagnostics_path,
        "bootstrap_stage": bootstrap_stage,
        "bootstrap_timeline_present": bool(bootstrap_timeline.get("present")),
        "bootstrap_timeline_path": bootstrap_timeline.get("path", ""),
        "bootstrap_timeline_stage_count": bootstrap_timeline.get("stage_count", 0),
        "bootstrap_timeline_last_stage": bootstrap_timeline.get("last_stage", ""),
        "bootstrap_timeline_last_stage_seq": bootstrap_timeline.get("last_stage_seq", 0),
        "bootstrap_timeline_last_elapsed_since_process_start_sec": bootstrap_timeline.get(
            "last_elapsed_since_process_start_sec", 0.0),
        "bootstrap_timeline_stages_tail": bootstrap_timeline.get("stages_tail", []),
        "ingest_diagnostics_path": ingest_diag_latest_path,
        "state_lineage_updated": state_lineage_updated,
        "cursor_lineage_updated": cursor_lineage_updated,
        "publish_failure_class": publish_failure_class,
    }
    json_path, _txt = _write_phase_c_execution_handoff_report_files(lab_root, pipeline_run_id, payload)
    _stamp_phase_c_execution_handoff_state(lab_root, json_path, status, blocker_class, generated_at, exec_info)


def _safe_state_subset(state):
    if not isinstance(state, dict):
        return {}
    keys = (
        "pipeline_state", "active_run_id", "active_phase", "last_shadow_pipeline_run_id",
        "last_shadow_pipeline_ok", "last_shadow_pipeline_failed_phase", "last_shadow_pipeline_error_code",
    )
    return {k: state.get(k, "") for k in keys}


def _write_interrupt_report_files(lab_root, rid, phase_name, clf, log_excerpt=""):
    """Write JSON + text interrupt diagnostics under lab/reports."""
    reports_dir = os.path.join(lab_root, "reports")
    try:
        os.makedirs(reports_dir, exist_ok=True)
    except Exception:
        pass
    stamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    safe_rid = re.sub(r"[^A-Za-z0-9._-]+", "_", str(rid or "unknown"))
    base = "shadow_pipeline_interrupt_{0}_{1}".format(safe_rid, stamp)
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    st = {}
    try:
        if os.path.exists(state_path):
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
    except Exception:
        pass
    payload = {
        "run_id": rid,
        "failed_phase": phase_name,
        "classification": clf,
        "diagnostics_subset": _safe_state_subset(st),
        "log_excerpt": log_excerpt or "(not extracted)",
        "generated_at_utc": iso_utc_now(),
    }
    jpath = os.path.join(reports_dir, base + ".json")
    tpath = os.path.join(reports_dir, base + ".txt")
    try:
        with open(jpath, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        with open(tpath, "w", encoding="utf-8") as f:
            f.write("Shadow pipeline interrupt report\n")
            f.write("generated_at_utc={0}\n".format(payload["generated_at_utc"]))
            f.write("run_id={0}\n".format(rid))
            f.write("failed_phase={0}\n".format(phase_name))
            f.write("interrupt_code={0}\n".format((clf or {}).get("normalized_code", "")))
            f.write("raw_rc={0}\n".format((clf or {}).get("raw_rc", "")))
            f.write("hex_rc={0}\n".format((clf or {}).get("hex_rc", "")))
            f.write("restart_inference=not_implemented\n")
        for alias in ("shadow_pipeline_interrupt_latest.json", "shadow_pipeline_interrupt_latest.txt"):
            ap = os.path.join(reports_dir, alias)
            try:
                with open(ap, "w", encoding="utf-8") as f:
                    if alias.endswith(".json"):
                        json.dump(payload, f, indent=2)
                    else:
                        f.write(open(tpath, "r", encoding="utf-8").read())
            except Exception:
                pass
    except Exception:
        pass
    return jpath


def _phase_d_entity_scope_for_pipeline_env(lab_root):
    """Resolve automated Phase D entity scope; injected into Phase D subprocess env."""
    # TODO(theme5): Resolver lives in unified_rollout_policy; adjust gates there, not here.
    try:
        from scripts.unified_model import unified_rollout_policy as urp
    except Exception:
        try:
            import unified_rollout_policy as urp
        except Exception:
            return "v1"
    try:
        scope, _reasons = urp.resolve_phase_d_entity_scope_for_pipeline(lab_root)
        if scope == "v2":
            return "v2"
    except Exception:
        pass
    return "v1"


def _resolve_phase_f_package_script(repo_root, python_exe):
    """Resolve Phase F package script through the shared orchestrator resolver."""
    if _shadow_orchestrator is not None:
        try:
            return _shadow_orchestrator.resolve_phase_f_package_script(repo_root, python_exe=python_exe)
        except Exception:
            pass
    script_path = os.path.join(repo_root, "scripts", "unified_model", "package_shadow_run_report.py")
    return repo_root, script_path, []


def _ensure_import_dir(path_value):
    try:
        script_dir = os.path.dirname(os.path.abspath(path_value))
        if script_dir and script_dir not in sys.path:
            sys.path.insert(0, script_dir)
    except Exception:
        pass


def run_shadow_pipeline(lab_root):
    """
    Run A -> B -> C -> D -> E, then package/send via Phase F.
    Returns (ok, run_id, failed_phase, error_code).
    """
    rid = run_id()
    started_at = iso_utc_now()

    if not _acquire_pipeline_lock(lab_root):
        _update_pipeline_state(lab_root, rid, started_at, iso_utc_now(), False,
                              skip_reason="already_running")
        return False, rid, None, "already_running"

    python_exe = sys.executable
    repo_root = _workspace_root()
    env = os.environ.copy()
    env["target_folder"] = env.get("target_folder", "")
    env["source_folder"] = env.get("source_folder", "")
    env[_PIPELINE_RUN_ID_ENV] = rid
    env[_PIPELINE_PHASE_RUN_IDS_ENV] = json.dumps({}, sort_keys=True)
    phases = [
        ("A", "bootstrap_lab.py"),
        ("B", "discover_artifacts.py"),
        ("C", "ingest_from_manifest.py"),
        ("D", "run_qa_canonical.py"),
        ("E", "run_projection_parity.py"),
    ]

    failed_phase = None
    error_code = None
    failure_context = {}
    phase_run_ids = {}
    policy_trigger = False
    phase_f_ok = False
    interrupted_pipeline = False
    interrupt_extra = {}

    def _interrupt_extra_map(clf, phase_nm):
        fin = iso_utc_now()
        clf = clf if isinstance(clf, dict) else {}
        return {
            "last_shadow_pipeline_interrupt_run_id": rid,
            "last_shadow_pipeline_interrupt_phase": str(phase_nm or ""),
            "last_shadow_pipeline_interrupt_code": str(clf.get("raw_rc", "")),
            "last_shadow_pipeline_interrupt_code_hex": str(clf.get("hex_rc", "")),
            "last_shadow_pipeline_interrupt_class": PIPELINE_INTERRUPTED_CONTROL_EVENT,
            "last_shadow_pipeline_interrupt_source": str(clf.get("classification_source", "")),
            "last_shadow_pipeline_interrupt_at_utc": fin,
            "last_shadow_pipeline_interrupt_detail": "rc={0} hex={1}".format(
                clf.get("raw_rc", ""), clf.get("hex_rc", "")),
            "last_shadow_pipeline_interrupt_guard_note": "",
        }

    try:
        phase_name = ""
        try:
            # Owner write path updates lifecycle keys (v2 additive schema).
            _update_pipeline_phase_marker(lab_root, rid, "A", started_at, phase_run_ids=phase_run_ids)
            # After active_run_id reflects this run, stale-crash detection can safely compare to incoming_rid.
            _repair_orphan_pipeline_lifecycle_state(lab_root, rid)
            sync_phase_c_subprocess_script_fingerprint_from_disk(
                lab_root, "shadow_pipeline_bootstrap", repo_root=repo_root
            )
            for phase_name, script_name in phases:
                env[_PIPELINE_PHASE_RUN_IDS_ENV] = json.dumps(phase_run_ids, sort_keys=True)
                _update_pipeline_phase_marker(
                    lab_root,
                    rid,
                    phase_name,
                    iso_utc_now(),
                    phase_run_ids=phase_run_ids,
                )
                prior_phase_rid = ""
                if phase_name in _PHASE_CURSOR_KEYS:
                    prior_phase_rid = _read_cursor_run_id(lab_root, _PHASE_CURSOR_KEYS[phase_name])
                if phase_name == "D":
                    try:
                        from scripts.unified_model.unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
                    except Exception:
                        try:
                            from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV
                        except Exception:
                            INTERNAL_PHASE_D_ENTITY_SCOPE_ENV = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
                    env[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = _phase_d_entity_scope_for_pipeline_env(lab_root)
                handoff_err = ""
                handoff_detail = ""
                if phase_name == "C":
                    snapshot_pre = _snapshot_phase_c_handoff_state(lab_root)
                    exec_info = None
                    subproc_ok = False
                    recovery = None
                    recovery_ok = True
                    recovery_error = ""
                    recovery_detail = ""
                    phase_c_attempt_id = "{0}-phase-c".format(rid)
                    phase_c_script_path = os.path.join(repo_root, "scripts", "unified_model", script_name)
                    if begin_phase_c_current_attempt is not None:
                        try:
                            begin_phase_c_current_attempt(
                                lab_root,
                                phase_c_attempt_id,
                                "shadow_pipeline",
                                expected_manifest_path=snapshot_pre.get("last_manifest_path", ""),
                                expected_manifest_sha256=snapshot_pre.get("last_manifest_sha256", ""),
                                expected_phase_b_run_id=snapshot_pre.get("last_phase_b_run_id", ""),
                                expected_ingest_script_path=phase_c_script_path,
                            )
                        except Exception:
                            pass
                    # Clears circuit on MEDICAFE_VERSION change even when opened_at_medicafe_version was unset (legacy).
                    maybe_auto_reset_phase_c_circuit(lab_root)
                    sync_phase_c_self_heal_tracked_b_sha(lab_root)
                    fc = phase_c_self_heal_failure_count(lab_root)
                    tier = remediation_tier_for_failure_count(fc)
                    if phase_c_circuit_is_open(lab_root):
                        tier = 4
                    if tier == 4:
                        root_blocker = str(
                            _merge_state_cursor_scalar(
                                _read_diagnostics_state(lab_root),
                                _read_run_cursor(lab_root),
                                "last_phase_c_execution_handoff_blocker_class",
                            )
                            or ""
                        ).strip()
                        stamp_phase_c_last_self_heal_telemetry(lab_root, "tier4_circuit", "blocked")
                        if not phase_c_circuit_is_open(lab_root):
                            open_phase_c_circuit(lab_root, rid, "failure_count_threshold")
                        if not phase_c_unresolvable_bundle_already_sent(lab_root):
                            try:
                                from phase_e_auto_report import submit_phase_c_unresolvable_bundle

                                if submit_phase_c_unresolvable_bundle(
                                    lab_root,
                                    {"run_id": rid, "lab_root": lab_root, "error_code": PHASE_C_CIRCUIT_OPEN},
                                ):
                                    stamp_phase_c_unresolvable_bundle_sent(lab_root)
                            except Exception:
                                pass
                        if mark_phase_c_current_attempt_circuit_open is not None:
                            try:
                                mark_phase_c_current_attempt_circuit_open(
                                    lab_root,
                                    phase_c_attempt_id,
                                    "shadow_pipeline",
                                    expected_ingest_script_path=phase_c_script_path,
                                )
                            except Exception:
                                pass
                        recovery_ok = True
                        tier4_script = os.path.join(repo_root, "scripts", "unified_model", script_name)
                        t4_sha = ""
                        t4_sz = 0
                        if os.path.isfile(tier4_script):
                            try:
                                t4_sz = int(os.path.getsize(tier4_script))
                            except Exception:
                                t4_sz = 0
                            try:
                                with open(tier4_script, "rb") as sf:
                                    h = hashlib.sha256()
                                    blk = sf.read(65536)
                                    while blk:
                                        h.update(blk)
                                        blk = sf.read(65536)
                                t4_sha = h.hexdigest()[:16]
                            except Exception:
                                t4_sha = ""
                        exec_info = {
                            "script_name": script_name,
                            "script_path": tier4_script,
                            "python_exe": python_exe,
                            "cwd": repo_root,
                            "started_at_utc": iso_utc_now(),
                            "finished_at_utc": iso_utc_now(),
                            "elapsed_sec": 0.0,
                            "return_code": 0,
                            "ok": False,
                            "subproc_stderr_tail": "",
                            "subproc_stdout_tail": "",
                            "script_sha256_prefix": t4_sha,
                            "script_size_bytes": t4_sz,
                            "circuit_open_root_blocker_class": root_blocker,
                        }
                        ok = False
                        rc = 1
                        subproc_ok = False
                        handoff_err = PHASE_C_CIRCUIT_OPEN
                        handoff_detail = "Phase C self-heal circuit is open; ingest skipped until auto-reset."
                        error_code = PHASE_C_CIRCUIT_OPEN
                        failure_context = build_failure_context(
                            "C", error_code, handoff_detail, "PhaseCCircuit"
                        )
                    else:
                        if tier == 1:
                            stamp_phase_c_last_self_heal_telemetry(
                                lab_root, "tier1_shadow_recovery_if_needed", "started"
                            )
                            recovery_ok, recovery_error, recovery_detail, recovery = (
                                _run_phase_c_shadow_recovery_if_needed(lab_root, repo_root, rid)
                            )
                        elif tier == 2:
                            stamp_phase_c_last_self_heal_telemetry(lab_root, "tier2_force_db_rebuild", "started")
                            recovery_ok, recovery_error, recovery_detail, recovery = (
                                _force_phase_c_shadow_db_rebuild(lab_root, repo_root, rid, "tier2")
                            )
                        else:
                            stamp_phase_c_last_self_heal_telemetry(
                                lab_root, "tier3_quarantine_reports_rediscover", "started"
                            )
                            q_ok, q_msg = quarantine_shadow_reports_and_rediscover(
                                lab_root, rid, python_exe, repo_root, env
                            )
                            append_phase_c_remediation_event(
                                lab_root,
                                {"event": "tier3_rediscover", "ok": bool(q_ok), "detail": str(q_msg or "")[:200]},
                            )
                            if not q_ok:
                                recovery_ok = False
                                recovery_error = PHASE_C_SHADOW_RECOVERY_FAILED
                                recovery_detail = q_msg or "tier3_rediscover_failed"
                                recovery = None
                            else:
                                recovery_ok, recovery_error, recovery_detail, recovery = (
                                    _run_phase_c_shadow_recovery_if_needed(lab_root, repo_root, rid)
                                )
                        if not recovery_ok:
                            ok = False
                            rc = 1
                            failed_phase = "C"
                            error_code = recovery_error or PHASE_C_SHADOW_RECOVERY_FAILED
                            failure_context = build_failure_context(
                                "C", error_code, recovery_detail, "PhaseCShadowRecovery"
                            )
                            subproc_ok = False
                        else:
                            ok, rc, exec_info = _run_phase_c_with_timing(
                                script_name, lab_root, python_exe, repo_root, env
                            )
                            subproc_ok = ok
                else:
                    ok, rc = _run_phase(script_name, lab_root, python_exe, repo_root, env)
                _refresh_lock_heartbeat(lab_root)
                if ok and phase_name == "C":
                    handoff_err, handoff_detail = _phase_c_handoff_failure(lab_root)
                    if handoff_err:
                        ok = False
                        rc = 1
                        failed_phase = "C"
                        error_code = handoff_err
                        failure_context = build_failure_context(
                            "C", error_code, handoff_detail, "PhaseHandoff"
                        )
                if phase_name == "C":
                    _emit_phase_c_execution_handoff_report(
                        lab_root,
                        rid,
                        snapshot_pre,
                        recovery,
                        exec_info,
                        recovery_ok,
                        subproc_ok,
                        handoff_err,
                        handoff_detail,
                    )
                    if refresh_phase_c_current_attempt_from_lab is not None:
                        try:
                            refresh_phase_c_current_attempt_from_lab(
                                lab_root,
                                phase_c_attempt_id,
                                "shadow_pipeline",
                            )
                        except Exception:
                            pass
                    if ok:
                        try:
                            reset_phase_c_self_heal_on_success(lab_root, rid)
                        except Exception:
                            pass
                    else:
                        ec = str(error_code or "").strip() or str(
                            _read_phase_error_code(lab_root, "C") or ""
                        ).strip()
                        if ec != PHASE_C_CIRCUIT_OPEN:
                            try:
                                increment_phase_c_self_heal_failure(lab_root, rid, ec)
                            except Exception:
                                pass
                if phase_name in _PHASE_CURSOR_KEYS:
                    rid_val = _read_cursor_run_id(lab_root, _PHASE_CURSOR_KEYS[phase_name])
                    record_phase_rid = bool(ok)
                    if not record_phase_rid and rid_val and rid_val != prior_phase_rid:
                        # Some phases can publish their summary/cursor before surfacing a nonzero exit.
                        # Record the changed run id so Phase F packages the failing run, not stale history.
                        record_phase_rid = True
                    if rid_val and record_phase_rid:
                        phase_run_ids[phase_name] = rid_val
                        env[_PIPELINE_PHASE_RUN_IDS_ENV] = json.dumps(phase_run_ids, sort_keys=True)
                if not ok:
                    if phase_name == "C" and not error_code:
                        launch_kind = ""
                        if isinstance(exec_info, dict):
                            launch_kind = str(exec_info.get("launch_failure_kind") or "").strip()
                        if launch_kind == "script_missing":
                            error_code = "PHASE_C_SCRIPT_MISSING"
                        elif launch_kind == "script_zero_bytes":
                            error_code = "PHASE_C_SCRIPT_ZERO_BYTES"
                        elif launch_kind == "spawn_exception":
                            error_code = "PHASE_C_SPAWN_EXCEPTION"
                        if error_code:
                            exec_ctx = exec_info if isinstance(exec_info, dict) else {}
                            script_path = str(exec_ctx.get("script_path") or "").strip()
                            stderr_tail = str(exec_ctx.get("subproc_stderr_tail") or "").strip()
                            spawn_exc_class = str(exec_ctx.get("spawn_exception_class") or "").strip()
                            if launch_kind == "script_missing":
                                detail = "Phase C launch failed: ingest script is missing"
                                if script_path:
                                    detail = "{0} at {1}".format(detail, script_path)
                                if stderr_tail:
                                    detail = "{0}; {1}".format(detail, stderr_tail)
                                failure_context = build_failure_context(
                                    phase_name,
                                    error_code,
                                    detail,
                                    "LookupError",
                                )
                            elif launch_kind == "script_zero_bytes":
                                detail = "Phase C launch failed: ingest script is zero bytes"
                                if script_path:
                                    detail = "{0} at {1}".format(detail, script_path)
                                if stderr_tail:
                                    detail = "{0}; {1}".format(detail, stderr_tail)
                                failure_context = build_failure_context(
                                    phase_name,
                                    error_code,
                                    detail,
                                    "ValueError",
                                )
                            elif launch_kind == "spawn_exception":
                                detail = "Phase C launch failed during subprocess spawn"
                                if script_path:
                                    detail = "{0} for {1}".format(detail, script_path)
                                if stderr_tail:
                                    detail = "{0}; {1}".format(detail, stderr_tail)
                                elif exec_ctx.get("spawn_exception_message"):
                                    detail = "{0}; {1}".format(
                                        detail,
                                        str(exec_ctx.get("spawn_exception_message") or "").strip(),
                                    )
                                failure_context = build_failure_context(
                                    phase_name,
                                    error_code,
                                    detail,
                                    spawn_exc_class or "Exception",
                                )
                    failed_phase = phase_name
                    clf = classify_phase_exit(rc, False)
                    if clf.get("interrupted"):
                        interrupted_pipeline = True
                        error_code = PIPELINE_INTERRUPTED_CONTROL_EVENT
                        failure_context = build_failure_context(
                            phase_name,
                            error_code,
                            "Pipeline interrupted (control event); rc={0}".format(rc),
                            str(clf.get("classification_source", "ProcessExit")),
                        )
                        interrupt_extra = _interrupt_extra_map(clf, phase_name)
                        try:
                            _write_interrupt_report_files(lab_root, rid, phase_name, clf)
                        except Exception:
                            pass
                    else:
                        if not error_code:
                            phase_error = _read_phase_error_code(lab_root, phase_name)
                            if phase_error:
                                error_code = phase_error
                            else:
                                error_code = "PHASE_{0}_EXIT_{1}".format(phase_name, rc)
                            failure_context = build_failure_context(
                                phase_name, error_code, "Phase process exited with rc={0}".format(rc), "ProcessExit"
                            )
                    break
        except KeyboardInterrupt:
            interrupted_pipeline = True
            failed_phase = phase_name or "A"
            clf = classify_phase_exit(130, True)
            error_code = PIPELINE_INTERRUPTED_CONTROL_EVENT
            failure_context = build_failure_context(
                failed_phase,
                error_code,
                "Pipeline interrupted by parent KeyboardInterrupt",
                "KeyboardInterrupt",
            )
            interrupt_extra = _interrupt_extra_map(clf, failed_phase)
            try:
                _write_interrupt_report_files(lab_root, rid, failed_phase, clf)
            except Exception:
                pass
        except Exception as ex:
            interrupted_pipeline = False
            if failed_phase is None:
                failed_phase = str(phase_name or "A")
            if not error_code:
                error_code = PIPELINE_UNHANDLED_EXCEPTION
            failure_context = build_failure_context(
                failed_phase or "A",
                error_code,
                str(ex)[:800],
                ex.__class__.__name__,
            )

        finished_at = iso_utc_now()
        pipeline_ok = (failed_phase is None)
        _update_pipeline_state(
            lab_root, rid, started_at, finished_at, pipeline_ok,
            failed_phase, error_code, heartbeat_at_utc=finished_at,
            phase_run_ids=phase_run_ids, failure_context=failure_context,
            interrupted=interrupted_pipeline, interrupt_extra=interrupt_extra,
        )

        if not interrupted_pipeline:
            phase_f_repo_root, phase_f_script, phase_f_checks = _resolve_phase_f_package_script(repo_root, python_exe)
            if not os.path.exists(phase_f_script):
                pipeline_ok = False
                failed_phase = "F"
                error_code = "PHASE_F_SCRIPT_MISSING"
                checked = []
                try:
                    checked = [c.get("script_path", "") for c in phase_f_checks if c.get("script_path")]
                except Exception:
                    checked = []
                detail = "package_shadow_run_report.py missing"
                if checked:
                    detail = "{0}; checked={1}".format(detail, ", ".join(checked))
                failure_context = build_failure_context("F", error_code, detail, "LookupError")
                _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
            else:
                try:
                    _ensure_import_dir(phase_f_script)
                    from package_shadow_run_report import run_package
                except (ImportError, AttributeError):
                    pipeline_ok = False
                    failed_phase = "F"
                    error_code = "PHASE_F_ENTRYPOINT_MISSING"
                    failure_context = build_failure_context("F", error_code, "run_package import/entrypoint missing", "ImportError")
                    _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
                else:
                    try:
                        phase_f_ok, rj, rt, ix, phase_f_err, policy_trigger, phase_f_detail = run_package(
                            lab_root, pipeline_run_id=rid, run_id_source="cli", auto_report=False
                        )
                        if not phase_f_ok:
                            lock_diag = ""
                            lock_owner_running = False
                            lock_heartbeat_stale = True
                            if isinstance(phase_f_detail, dict):
                                lock_diag = phase_f_detail.get("lock_diag_path", "") or ""
                                lock_owner_running = bool(phase_f_detail.get("lock_owner_running"))
                                lock_heartbeat_stale = bool(phase_f_detail.get("lock_heartbeat_stale", True))
                            if phase_f_err == "PHASE_F_LOCK_FAIL" and lock_owner_running and not lock_heartbeat_stale:
                                # Benign contention: classify as attach/retry rather than opaque fatal.
                                pipeline_ok = True
                                failed_phase = None
                                error_code = "PHASE_F_LOCK_CONTENDED_ATTACH"
                                failure_context = build_failure_context(
                                    "F", error_code, "Lock owned by active process; attached to existing run", "SystemExit"
                                )
                                _update_pipeline_state(
                                    lab_root, rid, started_at, iso_utc_now(), True,
                                    failed_phase=None, error_code=error_code,
                                    heartbeat_at_utc=iso_utc_now(), phase_run_ids=phase_run_ids,
                                    failure_context=failure_context
                                )
                            else:
                                pipeline_ok = False
                                failed_phase = "F"
                                error_code = phase_f_err or "PHASE_F_EXIT_1"
                                detail = ""
                                exc = ""
                                if isinstance(phase_f_detail, dict):
                                    detail = str(phase_f_detail.get("error_detail", "") or "")
                                    exc = str(phase_f_detail.get("source_exception_class", "") or "")
                                failure_context = build_failure_context("F", error_code, detail, exc)
                                _update_pipeline_phase_f_failure(
                                    lab_root, rid, error_code,
                                    phase_f_lock_diag_path=lock_diag,
                                    failure_context=failure_context
                                )
                    except Exception:
                        pipeline_ok = False
                        failed_phase = "F"
                        error_code = "PHASE_F_ENTRYPOINT_MISSING"
                        failure_context = build_failure_context("F", error_code, "run_package raised unexpectedly", "Exception")
                        _update_pipeline_phase_f_failure(lab_root, rid, error_code, failure_context=failure_context)
    finally:
        _release_pipeline_lock(lab_root)

    phase_f_send_error = False
    phase_f_suppressed_post_update = False
    try:
        from phase_e_auto_report import _post_update_autofollow_covers_phase_f_report

        phase_f_suppressed_post_update = bool(_post_update_autofollow_covers_phase_f_report(lab_root))
    except Exception:
        phase_f_suppressed_post_update = False
    if policy_trigger and phase_f_ok and rj and rt and ix:
        try:
            from package_shadow_run_report import run_phase_f_report_send
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            st = {}
            try:
                if os.path.exists(state_path):
                    with open(state_path, "r", encoding="utf-8") as f:
                        st = json.load(f)
            except Exception:
                pass
            contract_parity_status = st.get("last_contract_parity_status", "") or ""
            healthy_phase_f_telemetry = (
                pipeline_ok and
                not (failed_phase or "") and
                not (error_code or "") and
                contract_parity_status == "pass"
            )
            if not healthy_phase_f_telemetry:
                run_phase_f_report_send(lab_root, rj, rt, ix, {
                    "run_id": rid,
                    "pipeline_ok": pipeline_ok,
                    "failed_phase": failed_phase or "",
                    "error_code": error_code or "",
                    "contract_parity_status": contract_parity_status,
                })
        except Exception:
            phase_f_send_error = True

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    run_fallback = True
    st_after_send = {}
    try:
        if os.path.exists(state_path):
            with open(state_path, "r", encoding="utf-8") as f:
                st_after_send = json.load(f)
            if isinstance(st_after_send, dict):
                if (
                    st_after_send.get("phase_f_report_sent") is True
                    and st_after_send.get("phase_f_report_sent_for_run_id") == rid
                ):
                    run_fallback = False
    except Exception:
        st_after_send = {}

    # run_phase_f_report_send may return False for expected non-error outcomes
    # (for example dedup suppression), so only treat explicit invocation errors
    # as send failures that should trigger Phase E fallback on healthy runs.
    # When post-update auto-follow suppresses Phase F on a healthy telemetry-only
    # run, Phase E must not duplicate that bundle; failed pipelines still need
    # Phase E because Phase F evidence was not sent.
    should_run_phase_e_fallback = (not pipeline_ok) or phase_f_send_error
    contract_fb = ""
    if isinstance(st_after_send, dict):
        contract_fb = str(st_after_send.get("last_contract_parity_status", "") or "")
    healthy_phase_f_for_fallback = (
        pipeline_ok
        and not (failed_phase or "")
        and not (error_code or "")
        and contract_fb == "pass"
    )
    if phase_f_suppressed_post_update and healthy_phase_f_for_fallback:
        should_run_phase_e_fallback = False

    if should_run_phase_e_fallback and run_fallback:
        try:
            from phase_e_auto_report import submit_phase_e_failure_report
            submit_phase_e_failure_report(lab_root, {
                "error_code": error_code or "PIPELINE_FAIL",
                "run_id": rid,
                "first_failed": failed_phase or "unknown",
                "lab_root": lab_root,
                "summary": {"phase": "pipeline", "failed_phase": failed_phase},
            })
        except Exception:
            pass

    try:
        from MediCafe.phase_c_self_heal_status import write_phase_c_self_heal_status_txt

        write_phase_c_self_heal_status_txt(lab_root)
    except Exception:
        pass

    return pipeline_ok, rid, failed_phase, error_code


def main():
    parser = argparse.ArgumentParser(description="XP Shadow Pipeline (A->B->C->D->E->F)")
    parser.add_argument("--lab-dir", help="Override lab root")
    args = parser.parse_args()
    lab_root = _resolve_lab_root(args)
    if not os.path.exists(lab_root):
        os.makedirs(lab_root, exist_ok=True)
    ok, rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
    if not ok:
        if error_code == "already_running":
            print("Pipeline skipped: prior run still active.", file=sys.stderr)
            sys.exit(0)  # Non-failure; intentional overlap guard
        print("Pipeline failed at Phase {0}: {1}".format(failed_phase, error_code), file=sys.stderr)
        sys.exit(1)
    print("Pipeline ok: {0}".format(rid))


if __name__ == "__main__":
    main()
