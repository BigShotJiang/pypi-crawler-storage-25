#!/usr/bin/env python
"""
Phase C current-attempt contract.

This file is intentionally stdlib-only and Python 3.4 compatible.  It writes a
single lab/reports/phase_c_current_attempt_latest.json document that answers the
operator/developer question: did this deployment actually attempt Phase C, and
which observable boundary was the last one reached?
"""
from __future__ import print_function

import hashlib
import json
import os
import time

try:
    from phase_a_common import iso_utc_now
except Exception:
    def iso_utc_now():
        return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


PHASE_C_CURRENT_ATTEMPT_SCHEMA_VERSION = 1
CURRENT_ATTEMPT_FILENAME = "phase_c_current_attempt_latest.json"


def _safe_str(value):
    return str(value or "").strip()


def _reports_dir(lab_root):
    return os.path.join(_safe_str(lab_root), "reports")


def phase_c_current_attempt_path(lab_root):
    return os.path.join(_reports_dir(lab_root), CURRENT_ATTEMPT_FILENAME)


def _read_json(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            doc = json.load(handle)
        if isinstance(doc, dict):
            return doc
    except Exception:
        pass
    return {}


def _write_json(path, doc):
    parent = os.path.dirname(path)
    try:
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
    except Exception:
        return False
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(doc, handle, sort_keys=True, indent=2)
            handle.write("\n")
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass
        os.rename(tmp, path)
        return True
    except Exception:
        try:
            if os.path.isfile(tmp):
                os.remove(tmp)
        except Exception:
            pass
    return False


def _file_sha256_prefix(path, prefix_len=16):
    if not path or not os.path.isfile(path):
        return ""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as handle:
            block = handle.read(65536)
            while block:
                h.update(block)
                block = handle.read(65536)
        return h.hexdigest()[:int(prefix_len or 16)]
    except Exception:
        return ""


def _mtime_epoch(path):
    if not path or not os.path.isfile(path):
        return 0.0
    try:
        return float(os.path.getmtime(path))
    except Exception:
        return 0.0


def _fresh_file(path, started_epoch):
    if not path or not os.path.isfile(path):
        return False
    try:
        started = float(started_epoch or 0.0)
    except Exception:
        started = 0.0
    if started <= 0:
        return True
    # FAT/XP-style timestamp granularity can be coarse; allow a small tolerance.
    return _mtime_epoch(path) >= (started - 2.0)


def _stamp_state_and_cursor(lab_root, attempt):
    now = _safe_str(attempt.get("phase_c_attempt_updated_at_utc")) or iso_utc_now()
    path = _safe_str(attempt.get("attempt_report_path"))
    keys = {
        "last_phase_c_current_attempt_path": path,
        "last_phase_c_current_attempt_id": _safe_str(attempt.get("phase_c_attempt_id")),
        "last_phase_c_current_attempt_source": _safe_str(attempt.get("phase_c_attempt_source")),
        "last_phase_c_current_attempt_blocker": _safe_str(attempt.get("current_blocker")),
        "last_phase_c_current_attempt_last_reached_stage": _safe_str(attempt.get("last_reached_stage")),
        "last_phase_c_current_attempt_updated_at_utc": now,
    }
    for name in ("diagnostics_state.json", "run_cursor.json"):
        state_path = os.path.join(_safe_str(lab_root), name)
        doc = _read_json(state_path)
        if not doc and os.path.isfile(state_path):
            continue
        doc.update(keys)
        doc["updated_at_utc"] = now
        _write_json(state_path, doc)


def _existing_attempt(lab_root):
    return _read_json(phase_c_current_attempt_path(lab_root))


def begin_phase_c_current_attempt(
    lab_root,
    attempt_id,
    source,
    expected_manifest_path="",
    expected_manifest_sha256="",
    expected_phase_b_run_id="",
    expected_ingest_script_path="",
    current_blocker="phase_c_attempt_started",
):
    """Create or replace the current-attempt document before Phase C work starts."""
    lab_root = _safe_str(lab_root)
    report_path = phase_c_current_attempt_path(lab_root)
    now = iso_utc_now()
    try:
        started_epoch = time.time()
    except Exception:
        started_epoch = 0.0
    payload = {
        "schema_version": PHASE_C_CURRENT_ATTEMPT_SCHEMA_VERSION,
        "phase_c_attempt_id": _safe_str(attempt_id),
        "phase_c_attempt_source": _safe_str(source),
        "phase_c_attempt_started_at_utc": now,
        "phase_c_attempt_started_epoch": started_epoch,
        "phase_c_attempt_updated_at_utc": now,
        "attempt_report_path": report_path,
        "expected_manifest_path": _safe_str(expected_manifest_path),
        "expected_manifest_sha256": _safe_str(expected_manifest_sha256),
        "expected_phase_b_run_id": _safe_str(expected_phase_b_run_id),
        "expected_ingest_script_path": _safe_str(expected_ingest_script_path),
        "expected_ingest_script_sha256_prefix": _file_sha256_prefix(expected_ingest_script_path),
        "bootstrap_seen": False,
        "bootstrap_timeline_seen": False,
        "finish_diagnostics_seen": False,
        "summary_seen": False,
        "state_cursor_publish_seen": False,
        "handoff_report_seen": False,
        "last_reached_stage": "not_entered",
        "current_blocker": _safe_str(current_blocker) or "phase_c_attempt_started",
        "bootstrap_path": os.path.join(_reports_dir(lab_root), "ingest_from_manifest_bootstrap_latest.json"),
        "bootstrap_timeline_path": os.path.join(
            _reports_dir(lab_root), "ingest_from_manifest_bootstrap_timeline_latest.jsonl"),
        "finish_diagnostics_path": os.path.join(_reports_dir(lab_root), "ingest_from_manifest_diagnostics_latest.json"),
        "summary_path": "",
        "handoff_report_path": "",
    }
    _write_json(report_path, payload)
    _stamp_state_and_cursor(lab_root, payload)
    return payload


def _summary_path_for_attempt(lab_root, state_doc, cursor_doc, finish_doc):
    reports = _reports_dir(lab_root)
    rid = _safe_str(finish_doc.get("rid") or finish_doc.get("run_id"))
    if not rid:
        rid = _safe_str(state_doc.get("last_phase_c_run_id") or cursor_doc.get("last_phase_c_run_id"))
    if rid:
        path = os.path.join(reports, "ingest_write_summary_{0}.json".format(rid))
        if os.path.isfile(path):
            return path
    return ""


def _lineage_published(state_doc, cursor_doc, expected_sha):
    expected_sha = _safe_str(expected_sha)
    state_sha = _safe_str(state_doc.get("last_ingest_manifest_sha256"))
    cursor_sha = _safe_str(cursor_doc.get("last_ingest_manifest_sha256"))
    if expected_sha:
        return bool(state_sha == expected_sha and cursor_sha == expected_sha)
    return bool(state_sha and cursor_sha and state_sha == cursor_sha)


def _classify_current_attempt(payload):
    if _safe_str(payload.get("current_blocker")) == "phase_c_circuit_open_current_attempt":
        return "circuit_open", "phase_c_circuit_open_current_attempt"
    if payload.get("handoff_report_seen"):
        blocker = _safe_str(payload.get("handoff_blocker_class"))
        status = _safe_str(payload.get("handoff_status"))
        if status == "ok" or blocker == "phase_c_handoff_ok":
            return "handoff_report", "phase_c_current_attempt_ok"
        return "handoff_report", blocker or "phase_c_handoff_failed_current_attempt"
    if payload.get("state_cursor_publish_seen"):
        return "state_cursor_publish", "phase_c_handoff_report_missing_current_attempt"
    if payload.get("summary_seen"):
        return "summary", "phase_c_publish_incoherent_current_attempt"
    if payload.get("finish_diagnostics_seen"):
        return "finish_diagnostics", "phase_c_summary_missing_current_attempt"
    if payload.get("bootstrap_timeline_seen"):
        return "bootstrap_timeline", "phase_c_script_entered_but_no_finish_diag_current_attempt"
    if payload.get("bootstrap_seen"):
        return "bootstrap", "phase_c_script_entered_but_no_finish_diag_current_attempt"
    return "not_entered", "phase_c_script_entrypoint_not_observed_current_attempt"


def refresh_phase_c_current_attempt_from_lab(lab_root, attempt_id=None, source=""):
    """Refresh the current-attempt document from lab evidence and stamp state/cursor pointers."""
    lab_root = _safe_str(lab_root)
    attempt = _existing_attempt(lab_root)
    if not attempt:
        attempt = begin_phase_c_current_attempt(
            lab_root,
            attempt_id or "unknown",
            source or "refresh",
            current_blocker="phase_c_attempt_observed_without_begin",
        )
    elif attempt_id:
        attempt["phase_c_attempt_id"] = _safe_str(attempt_id)
    if source:
        attempt["phase_c_attempt_source"] = _safe_str(source)
    reports = _reports_dir(lab_root)
    state_doc = _read_json(os.path.join(lab_root, "diagnostics_state.json"))
    cursor_doc = _read_json(os.path.join(lab_root, "run_cursor.json"))
    bootstrap_path = os.path.join(reports, "ingest_from_manifest_bootstrap_latest.json")
    timeline_path = os.path.join(reports, "ingest_from_manifest_bootstrap_timeline_latest.jsonl")
    finish_path = os.path.join(reports, "ingest_from_manifest_diagnostics_latest.json")
    finish_doc = _read_json(finish_path)
    summary_path = _summary_path_for_attempt(lab_root, state_doc, cursor_doc, finish_doc)
    handoff_path = _safe_str(
        state_doc.get("last_phase_c_execution_handoff_report_path")
        or cursor_doc.get("last_phase_c_execution_handoff_report_path")
    )
    handoff_doc = _read_json(handoff_path)
    expected_sha = _safe_str(attempt.get("expected_manifest_sha256"))
    if not expected_sha:
        expected_sha = _safe_str(state_doc.get("last_manifest_sha256") or cursor_doc.get("last_manifest_sha256"))
        attempt["expected_manifest_sha256"] = expected_sha
    attempt["phase_c_attempt_updated_at_utc"] = iso_utc_now()
    attempt["bootstrap_path"] = bootstrap_path
    attempt["bootstrap_timeline_path"] = timeline_path
    attempt["finish_diagnostics_path"] = finish_path
    attempt["summary_path"] = summary_path
    attempt["handoff_report_path"] = handoff_path if os.path.isfile(handoff_path) else ""
    started_epoch = attempt.get("phase_c_attempt_started_epoch")
    attempt["bootstrap_seen"] = bool(_fresh_file(bootstrap_path, started_epoch))
    attempt["bootstrap_timeline_seen"] = bool(_fresh_file(timeline_path, started_epoch))
    attempt["finish_diagnostics_seen"] = bool(_fresh_file(finish_path, started_epoch))
    attempt["summary_seen"] = bool(summary_path and _fresh_file(summary_path, started_epoch))
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    cursor_path = os.path.join(lab_root, "run_cursor.json")
    state_cursor_fresh = _fresh_file(state_path, started_epoch) and _fresh_file(cursor_path, started_epoch)
    attempt["state_cursor_publish_seen"] = bool(
        attempt["summary_seen"] and state_cursor_fresh and _lineage_published(state_doc, cursor_doc, expected_sha)
    )
    attempt["handoff_report_seen"] = bool(handoff_path and _fresh_file(handoff_path, started_epoch))
    attempt["bootstrap_mtime_epoch"] = _mtime_epoch(bootstrap_path)
    attempt["finish_diagnostics_mtime_epoch"] = _mtime_epoch(finish_path)
    attempt["summary_mtime_epoch"] = _mtime_epoch(summary_path)
    attempt["handoff_report_mtime_epoch"] = _mtime_epoch(handoff_path)
    if handoff_doc:
        attempt["handoff_status"] = _safe_str(handoff_doc.get("status"))
        attempt["handoff_blocker_class"] = _safe_str(handoff_doc.get("blocker_class"))
        attempt["handoff_generated_at_utc"] = _safe_str(handoff_doc.get("generated_at_utc"))
    stage, blocker = _classify_current_attempt(attempt)
    attempt["last_reached_stage"] = stage
    attempt["current_blocker"] = blocker
    attempt["attempt_report_path"] = phase_c_current_attempt_path(lab_root)
    _write_json(attempt["attempt_report_path"], attempt)
    _stamp_state_and_cursor(lab_root, attempt)
    return attempt


def mark_phase_c_current_attempt_circuit_open(lab_root, attempt_id, source, expected_ingest_script_path=""):
    payload = begin_phase_c_current_attempt(
        lab_root,
        attempt_id,
        source,
        expected_ingest_script_path=expected_ingest_script_path,
        current_blocker="phase_c_circuit_open_current_attempt",
    )
    payload["last_reached_stage"] = "circuit_open"
    payload["phase_c_attempt_updated_at_utc"] = iso_utc_now()
    _write_json(payload.get("attempt_report_path"), payload)
    _stamp_state_and_cursor(lab_root, payload)
    return payload
