#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Tests for 837 encoder output path -> included patient dicts (Theme 3 / submission ledger)."""

from __future__ import print_function

import os
import sys
import unittest

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
MEDILINK_ROOT = os.path.join(PROJECT_ROOT, "MediLink")
if MEDILINK_ROOT not in sys.path:
    sys.path.insert(0, MEDILINK_ROOT)


def _ensure_medilink_import_priority():
    """Other modules (e.g. MediLink_ClaimStatus) prepend project root; re-prioritize MediLink for flat imports."""
    try:
        sys.path.remove(MEDILINK_ROOT)
    except ValueError:
        pass
    sys.path.insert(0, MEDILINK_ROOT)


class TestProcessClaimIncludedPatients(unittest.TestCase):
    """process_claim returns (path, included_patients) matching encoded CLMs only."""

    def setUp(self):
        _ensure_medilink_import_priority()

    def test_includes_only_valid_patients_when_second_invalid_skipped(self):
        from unittest.mock import patch

        import MediLink_837p_encoder as enc

        p1 = {"CHART": "111", "file_path": "/tmp/a.dat"}
        p2 = {"CHART": "222", "file_path": "/tmp/a.dat"}

        def fake_validate(data, medi):
            if data is p2:
                return False, ["missing_field"]
            return True, []

        fake_headers = ("ISA~", "GS~", "GE~", "IEA~")

        with patch.object(enc, "validate_claim_data", side_effect=fake_validate):
            with patch.object(enc.MediLink_837p_encoder_library, "handle_validation_errors", return_value=True):
                with patch.object(enc.MediLink_837p_encoder_library, "get_output_directory", return_value="/out"):
                    with patch.object(enc, "format_single_claim", return_value="CLM~"):
                        with patch.object(
                            enc.MediLink_837p_encoder_library,
                            "create_interchange_elements",
                            return_value=fake_headers,
                        ):
                            with patch.object(enc, "write_output_file", return_value="/out/batch.x12"):
                                path, included = enc.process_claim(
                                    {"MediLink_Config": {"local_claims_path": "/out"}},
                                    "EP1",
                                    [p1, p2],
                                    {},
                                    None,
                                )
        self.assertEqual(path, "/out/batch.x12")
        self.assertEqual(len(included), 1)
        self.assertIs(included[0], p1)

    def test_empty_segments_returns_none_and_empty_list(self):
        from unittest.mock import patch

        import MediLink_837p_encoder as enc

        p1 = {"CHART": "111", "file_path": "/tmp/a.dat"}

        with patch.object(enc, "validate_claim_data", return_value=(False, ["bad"])):
            with patch.object(enc.MediLink_837p_encoder_library, "handle_validation_errors", return_value=True):
                with patch.object(enc.MediLink_837p_encoder_library, "get_output_directory", return_value="/out"):
                    path, included = enc.process_claim(
                        {"MediLink_Config": {"local_claims_path": "/out"}},
                        "EP1",
                        [p1],
                        {},
                        None,
                    )
        self.assertIsNone(path)
        self.assertEqual(included, [])


class TestConvertFilesForSubmissionShape(unittest.TestCase):
    def setUp(self):
        _ensure_medilink_import_priority()

    def test_returns_tuple_paths_and_map(self):
        from unittest.mock import patch

        import MediLink_837p_encoder as enc

        rows = [
            {"confirmed_endpoint": "E1", "CHART": "1", "file_path": "x.dat"},
            {"confirmed_endpoint": "E1", "CHART": "2", "file_path": "x.dat"},
        ]
        cfg = {
            "MediLink_Config": {
                "local_claims_path": "/claims",
                "endpoints": {"E1": {"submission_type": "batch"}},
            }
        }

        with patch.object(enc, "process_claim", return_value=("/claims/out.x12", [rows[0]])):
            paths, fmap = enc.convert_files_for_submission(rows, cfg, {}, None)
        self.assertEqual(paths, ["/claims/out.x12"])
        self.assertIn("/claims/out.x12", fmap)
        self.assertEqual(fmap["/claims/out.x12"], [rows[0]])


class TestBackfillClaimKeys(unittest.TestCase):
    def test_backfill_matches_compute_claim_key_shape(self):
        MEDILINK_ROOT = os.path.join(PROJECT_ROOT, "MediLink")
        if MEDILINK_ROOT not in sys.path:
            sys.path.insert(0, MEDILINK_ROOT)

        from MediCafe.submission_index import compute_claim_key
        from MediLink_UI import backfill_missing_claim_keys

        row = {
            "patient_id": "12345",
            "primary_insurance": "PAYERX",
            "surgery_date_iso": "2025-06-01",
            "primary_procedure_code": "66984",
        }
        backfill_missing_claim_keys([row])
        self.assertEqual(
            row.get("claim_key"),
            compute_claim_key("12345", "", "PAYERX", "2025-06-01", "66984"),
        )

    def test_backfill_uses_electronic_payer_when_present(self):
        MEDILINK_ROOT = os.path.join(PROJECT_ROOT, "MediLink")
        if MEDILINK_ROOT not in sys.path:
            sys.path.insert(0, MEDILINK_ROOT)

        from MediCafe.submission_index import compute_claim_key
        from MediLink_UI import backfill_missing_claim_keys

        row = {
            "patient_id": "12345",
            "primary_payer_id": "87726",
            "primary_insurance": "UHC MEDICARE",
            "surgery_date_iso": "2025-06-01",
            "primary_procedure_code": "66984",
        }
        backfill_missing_claim_keys([row])
        self.assertEqual(
            row.get("claim_key"),
            compute_claim_key("12345", "87726", "UHC MEDICARE", "2025-06-01", "66984"),
        )


if __name__ == "__main__":
    unittest.main()
