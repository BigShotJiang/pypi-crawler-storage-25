import json
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
UM_ROOT = os.path.join(REPO_ROOT, "scripts", "unified_model")
if UM_ROOT not in sys.path:
    sys.path.insert(0, UM_ROOT)

from xp_phase_smoke import build_smoke_result  # noqa: E402


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


class XPPhaseSmokeTests(unittest.TestCase):
    def test_smoke_reports_current_phase_c_attempt_blocker(self):
        td = tempfile.mkdtemp()
        try:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            manifest = os.path.join(td, "manifest.json")
            _write_json(manifest, {"ok": True})
            _write_json(
                os.path.join(reports, "phase_c_current_attempt_latest.json"),
                {
                    "schema_version": 1,
                    "phase_c_attempt_id": "run-phase-c",
                    "last_reached_stage": "not_entered",
                    "current_blocker": "phase_c_script_entrypoint_not_observed_current_attempt",
                },
            )
            _write_json(
                os.path.join(td, "diagnostics_state.json"),
                {
                    "last_manifest_path": manifest,
                    "last_manifest_sha256": "sha-1",
                    "last_phase_c_current_attempt_path": os.path.join(
                        reports, "phase_c_current_attempt_latest.json"),
                },
            )
            _write_json(os.path.join(td, "run_cursor.json"), {})

            result = build_smoke_result(td)
            phase_c = [row for row in result["phases"] if row["phase"] == "C"][0]
            self.assertEqual(phase_c["status"], "blocked")
            self.assertEqual(
                phase_c["blocker"],
                "phase_c_script_entrypoint_not_observed_current_attempt",
            )
            self.assertEqual(result["overall_status"], "blocked")
        finally:
            shutil.rmtree(td)

    def test_smoke_marks_interface_sha_mismatch(self):
        td = tempfile.mkdtemp()
        try:
            reports = os.path.join(td, "reports")
            os.makedirs(reports)
            _write_json(
                os.path.join(td, "diagnostics_state.json"),
                {
                    "last_manifest_sha256": "sha-b",
                    "last_ingest_manifest_sha256": "sha-c",
                },
            )
            _write_json(os.path.join(td, "run_cursor.json"), {})
            result = build_smoke_result(td)
            interfaces = [row for row in result["phases"] if row["phase"] == "interfaces"][0]
            self.assertEqual(interfaces["status"], "blocked")
            self.assertEqual(interfaces["blocker"], "phase_b_c_manifest_sha_mismatch")
        finally:
            shutil.rmtree(td)


if __name__ == "__main__":
    unittest.main()
