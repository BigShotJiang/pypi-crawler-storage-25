# -*- coding: utf-8 -*-
"""Phase C self-heal ladder pure helpers and discover circuit guard."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

from phase_c_self_heal_state import (  # noqa: E402
    append_phase_c_remediation_event,
    increment_phase_c_self_heal_failure,
    phase_c_self_heal_failure_count,
    quarantine_shadow_reports_and_rediscover,
    remediation_tier_for_failure_count,
    reset_phase_c_self_heal_on_success,
    sync_phase_c_self_heal_tracked_b_sha,
)


class TestRemediationTier(unittest.TestCase):
    def test_tier_mapping(self):
        self.assertEqual(remediation_tier_for_failure_count(0), 1)
        self.assertEqual(remediation_tier_for_failure_count(1), 2)
        self.assertEqual(remediation_tier_for_failure_count(2), 3)
        self.assertEqual(remediation_tier_for_failure_count(3), 4)
        self.assertEqual(remediation_tier_for_failure_count(99), 4)

    def test_tier_mapping_non_numeric_defaults_like_zero(self):
        self.assertEqual(remediation_tier_for_failure_count("x"), 1)
        self.assertEqual(remediation_tier_for_failure_count(None), 1)


class TestSelfHealStateMutations(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_sh_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_increment_and_reset(self):
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"version": 2, "phase_c_self_heal_failure_count_for_b_sha": 0}, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            increment_phase_c_self_heal_failure(lab, "pipe-1", "x")
            self.assertEqual(phase_c_self_heal_failure_count(lab), 1)
            increment_phase_c_self_heal_failure(lab, "pipe-2", "y")
            self.assertEqual(phase_c_self_heal_failure_count(lab), 2)
            increment_phase_c_self_heal_failure(lab, "pipe-3", "z")
            self.assertEqual(phase_c_self_heal_failure_count(lab), 3)
            increment_phase_c_self_heal_failure(lab, "pipe-4", "cap")
            self.assertEqual(phase_c_self_heal_failure_count(lab), 3)
            reset_phase_c_self_heal_on_success(lab, "pipe-ok")
            self.assertEqual(phase_c_self_heal_failure_count(lab), 0)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_increment_does_not_wipe_corrupt_diagnostics_state(self):
        """Corrupt diagnostics_state.json must not be replaced by a merged empty doc."""
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            corrupt = '{"KEEP_LINEAGE": true, NOT_JSON'
            with open(state_path, "w", encoding="utf-8") as f:
                f.write(corrupt)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"phase_c_self_heal_failure_count_for_b_sha": 0}, f)
            increment_phase_c_self_heal_failure(lab, "pipe-corrupt", "detail")
            with open(state_path, "r", encoding="utf-8") as f:
                after_state = f.read()
            self.assertIn("KEEP_LINEAGE", after_state)
            self.assertIn("NOT_JSON", after_state)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_append_event_does_not_wipe_non_dict_json_state(self):
        """A JSON array (or other non-dict) on disk must not be overwritten by merge."""
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                f.write("[]")
            append_phase_c_remediation_event(lab, {"event": "must_not_apply"})
            with open(state_path, "r", encoding="utf-8") as f:
                self.assertEqual(f.read().strip(), "[]")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_sync_tracked_b_sha_resets_counter(self):
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "last_manifest_sha256": "aaa",
                        "phase_c_self_heal_tracked_b_sha": "bbb",
                        "phase_c_self_heal_failure_count_for_b_sha": 2,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "last_manifest_sha256": "aaa"}, f)
            sync_phase_c_self_heal_tracked_b_sha(lab)
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertEqual(st.get("phase_c_self_heal_tracked_b_sha"), "aaa")
            self.assertEqual(st.get("phase_c_self_heal_failure_count_for_b_sha"), 0)
        finally:
            shutil.rmtree(lab, ignore_errors=True)


class TestDiscoverCircuitGuard(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_disc_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_persist_skips_canonical_when_circuit_open(self):
        from discover_artifacts import _persist_phase_b_state

        lab = self._lab()
        try:
            manifest = os.path.join(lab, "reports", "artifact_manifest_x.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write("{}\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "old_sha",
                        "last_manifest_path": "old_path",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {"version": 1, "last_manifest_sha256": "old_sha", "last_manifest_path": "old_path"},
                    f,
                )
            _persist_phase_b_state(
                lab,
                "b-run-1",
                True,
                None,
                manifest,
                "new_sha",
                {"dat": 1},
                {},
                {},
            )
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertEqual(cr.get("last_manifest_sha256"), "old_sha")
            self.assertEqual(cr.get("last_discovery_pending_manifest_sha256"), "new_sha")
            self.assertTrue(cr.get("last_discovery_skipped_due_to_phase_c_circuit"))
        finally:
            shutil.rmtree(lab, ignore_errors=True)


class TestDiscoverCircuitAdditionalEdges(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_disc2_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_persist_updates_canonical_when_circuit_open_but_discovery_not_ok(self):
        from discover_artifacts import _persist_phase_b_state

        lab = self._lab()
        try:
            manifest = os.path.join(lab, "reports", "artifact_manifest_x.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write("{}\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "old_sha",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "last_manifest_sha256": "old_sha"}, f)
            _persist_phase_b_state(
                lab,
                "b-run-fail",
                False,
                "PHASE_B_SOME_ERR",
                manifest,
                "would_be_new",
                {"dat": 0},
                {},
                {},
            )
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertEqual(cr.get("last_manifest_sha256"), "would_be_new")
            self.assertFalse(cr.get("last_discovery_skipped_due_to_phase_c_circuit"))
        finally:
            shutil.rmtree(lab, ignore_errors=True)


class TestRemediationHistoryCap(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_hist_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        with open(os.path.join(root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
            json.dump({"version": 2, "phase_c_remediation_history": []}, f)
        with open(os.path.join(root, "run_cursor.json"), "w", encoding="utf-8") as f:
            json.dump({"version": 1}, f)
        return root

    def test_history_truncates_at_fifty(self):
        lab = self._lab()
        try:
            for i in range(55):
                append_phase_c_remediation_event(lab, {"event": "filler_{0}".format(i), "n": i})
            with open(os.path.join(lab, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                st = json.load(f)
            hist = st.get("phase_c_remediation_history")
            self.assertIsInstance(hist, list)
            self.assertEqual(len(hist), 50)
            self.assertEqual(hist[-1].get("n"), 54)
        finally:
            shutil.rmtree(lab, ignore_errors=True)


class TestQuarantineRediscoverEdges(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_q_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        with open(os.path.join(root, "reports", "ingest_write_summary_x.json"), "w", encoding="utf-8") as f:
            f.write("{}")
        with open(os.path.join(root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
            json.dump({"version": 2, "last_manifest_sha256": "keep"}, f)
        with open(os.path.join(root, "run_cursor.json"), "w", encoding="utf-8") as f:
            json.dump({"version": 1, "last_manifest_sha256": "keep"}, f)
        return root

    def test_rediscover_returns_false_when_script_missing(self):
        lab = self._lab()
        empty_repo = tempfile.mkdtemp(prefix="mc_no_scripts_")
        try:
            ok, msg = quarantine_shadow_reports_and_rediscover(
                lab, "pipe-q", sys.executable, empty_repo, os.environ.copy(),
            )
            self.assertFalse(ok)
            self.assertEqual(msg, "discover_script_missing")
        finally:
            shutil.rmtree(lab, ignore_errors=True)
            shutil.rmtree(empty_repo, ignore_errors=True)


class TestMediCafeRemediationLadderMirror(unittest.TestCase):
    def test_medicafe_tier_matches_scripts_module(self):
        from MediCafe.phase_c_remediation_ladder import remediation_tier_for_failure_count as med_tier

        for n in range(0, 6):
            self.assertEqual(med_tier(n), remediation_tier_for_failure_count(n))
