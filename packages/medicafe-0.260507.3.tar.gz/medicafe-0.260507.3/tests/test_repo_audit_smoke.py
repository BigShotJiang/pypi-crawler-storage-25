"""Smoke tests for tools/repo_audit registry and CLI."""

import os
import subprocess
import sys


def _repo_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _tools_dir():
    return os.path.join(_repo_root(), "tools")


def test_registry_loads_and_fast_checks_are_callable():
    if sys.version_info < (3, 7):
        return
    tools = _tools_dir()
    if tools not in sys.path:
        sys.path.insert(0, tools)
    from repo_audit._registry import checks_for_tier, load_registered_checks

    load_registered_checks()
    specs = checks_for_tier("fast")
    assert specs, "expected at least one fast-tier check"
    for spec in specs:
        res = spec.run()
        assert res.check_id == spec.id
        assert res.status in ("ok", "warn", "fail")


def test_cli_fast_exits_zero_on_clean_tree():
    if sys.version_info < (3, 7):
        return
    root = _repo_root()
    cli = os.path.join(root, "tools", "repo_audit.py")
    proc = subprocess.run(
        [sys.executable, cli, "--tier", "fast", "--format", "json"],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=300,
    )
    assert proc.returncode == 0, proc.stdout + proc.stderr
