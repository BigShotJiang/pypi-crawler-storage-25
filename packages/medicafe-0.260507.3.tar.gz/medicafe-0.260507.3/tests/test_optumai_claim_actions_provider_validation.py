#!/usr/bin/env python
"""
Targeted OPTUMAI claim-actions validation tests.

These tests reproduce provider-validation 400 behavior from captured support bundles
and lock endpoint-specific fallback behavior.
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


class TestClaimSubmissionFingerprint(unittest.TestCase):
    def test_newline_joined_x12_still_fingerprints_clm_and_nm1_82(self):
        from MediCafe.claim_actions_adapter import _build_claim_submission_provider_fingerprint

        # Same pattern as MediLink_837p_encoder newline-joined segments after '~'
        pieces = [
            "ISA*00*          *00*          *ZZ*SUBMITTER       *ZZ*RECEIVER        *",
            "NM1*85*2*CLINIC*****XX*1942376918",
            "CLM*CLAIM1*450***11:B:1*Y*A*Y*Y",
            "NM1*82*1*BOLES*STEVEN****XX*1114031507",
            "LX*1",
        ]
        x12 = "~\n".join(pieces) + "~"
        fp = _build_claim_submission_provider_fingerprint(x12)
        self.assertTrue(fp["has_clm"])
        self.assertTrue(fp["has_nm1_82"])
        self.assertGreaterEqual(fp["idx_clm"], 0)
        self.assertGreaterEqual(fp["idx_nm1_82"], 0)
        self.assertGreater(fp["idx_lx"], fp["idx_nm1_82"])


class TestClaimActionsProviderValidationMapping(unittest.TestCase):
    def test_claim_submission_wrapper_query_is_available_for_schema_variant(self):
        from MediCafe.graphql_utils import build_optumai_claim_submission_request

        request = build_optumai_claim_submission_request(
            {"payerId": "87726", "x12RequestData": "ISA*00*FAKE~"},
            response_shape="response_wrapper",
        )

        self.assertEqual(request.get("operationName"), "claimSubmission")
        self.assertIn("claimSubmissionResponse", request.get("query", ""))
        self.assertIn("transactionId", request.get("query", ""))
        self.assertEqual(request["variables"]["input"]["payerId"], "87726")

    def test_transform_handles_claim_submission_response_wrapper_shape(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "data": {
                "claimSubmission": {
                    "claimSubmissionResponse": {
                        "transactionId": "8841512345678901",
                        "statusCode": "000",
                        "responseType": "837999",
                        "x12ResponseData": "ISA*999~IK5*A~AK9*A*1*1*1~",
                        "x12Response277CA": "ISA*277~STC*A1:19~",
                        "message": "Claim submitted successfully. Refer 277CA for validation outcomes.",
                    }
                }
            }
        }

        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("transactionId"), "8841512345678901")
        self.assertEqual(transformed.get("statuscode"), "000")
        self.assertEqual(transformed.get("responseType"), "837999")
        self.assertEqual(transformed.get("x12ResponseData"), "ISA*277~STC*A1:19~")

    @patch("MediCafe.claim_actions_adapter.build_optumai_headers", return_value={"providerTaxId": "123456789"})
    @patch("MediCafe.claim_actions_adapter.extract_medilink_config")
    def test_submit_retries_wrapper_query_on_direct_field_undefined(self, mock_extract, _mock_headers):
        from MediCafe.claim_actions_adapter import submit_claim_via_optumai

        mock_extract.return_value = {
            "endpoints": {
                "OPTUMAI": {
                    "api_url": "https://apigw.optum.com",
                    "submission_method": "api",
                    "additional_endpoints": {"claim_actions": "/oihub/claim/actions/v1"},
                }
            }
        }

        direct_shape_error = {
            "errors": [
                {
                    "extensions": {"classification": "ValidationError"},
                    "message": (
                        "Validation error (FieldUndefined@[claimSubmission/transactionId]) : "
                        "Field 'transactionId' in type 'ClaimSubmissionResponse' is undefined"
                    ),
                }
            ]
        }
        wrapper_success = {
            "data": {
                "claimSubmission": {
                    "claimSubmissionResponse": {
                        "transactionId": "8841512345678901",
                        "statusCode": "000",
                        "responseType": "837999",
                        "x12ResponseData": "ISA*999~IK5*A~AK9*A*1*1*1~",
                        "message": "Claim submitted successfully.",
                    }
                }
            }
        }

        mock_client = MagicMock()
        mock_client.config = {}
        mock_client.make_api_call.side_effect = [direct_shape_error, wrapper_success]

        result = submit_claim_via_optumai(mock_client, "ISA*00*FAKE~NM1*PR*2*PAYER*****PI*87726~")

        self.assertEqual(mock_client.make_api_call.call_count, 2)
        first_body = mock_client.make_api_call.call_args_list[0][1]["data"]
        second_body = mock_client.make_api_call.call_args_list[1][1]["data"]
        self.assertNotIn("claimSubmissionResponse", first_body)
        self.assertIn("claimSubmissionResponse", second_body)
        self.assertEqual(result.get("statuscode"), "000")
        self.assertEqual(result.get("transactionId"), "8841512345678901")

    def test_bundle_like_provider_sequence_error_maps_to_400(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "PA Failure - Provider with sequence no. 01 not found.",
                },
                {
                    "code": "BENEFIT VALIDATIONS",
                    "description": "We are unable to process your request at this time.",
                },
            ],
            "data": {
                "claimSubmission": {
                    "transactionId": "8872877549877339",
                    "statusCode": "000",
                    "responseType": "837999",
                }
            },
        }

        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "400")
        self.assertIn("Validation failed", transformed.get("message", ""))
        self.assertIn("reason=provider_sequence_missing", transformed.get("message", ""))
        self.assertIn("Provider with sequence no. 01 not found", transformed.get("message", ""))

    def test_provider_sequence_reason_when_not_first_error(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {
                    "code": "BENEFIT VALIDATIONS",
                    "description": "We are unable to process your request at this time.",
                },
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "PA Failure - Provider with sequence no. 01 not found.",
                },
            ],
            "data": {
                "claimSubmission": {
                    "transactionId": "8872877549877339",
                    "statusCode": "000",
                    "responseType": "837999",
                }
            },
        }

        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "400")
        self.assertIn("reason=provider_sequence_missing", transformed.get("message", ""))

    def test_duplicate_rejection_in_277ca_overrides_provider_sequence_reason(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy
        from MediCafe.claim_actions_adapter import _infer_claim_submission_error_code

        graphql_response = {
            "errors": [
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "PA Failure - Provider with sequence no. 01 not found.",
                },
            ],
            "data": {
                "claimSubmission": {
                    "transactionId": "8872177544960119",
                    "statusCode": "000",
                    "responseType": "837999",
                    "x12Response277CA": (
                        "STC*A3:54*20260406*U*450.00********"
                        "This claim appears to be a duplicate of previously submitted claim ID [FM96902899] "
                        "received for processing on [04/06/2026]. This claim has been rejected and will not be processed.~"
                    ),
                }
            },
        }

        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "400")
        self.assertIn("reason=duplicate_claim_rejected", transformed.get("message", ""))
        self.assertIn("FM96902899", transformed.get("message", ""))
        self.assertEqual(
            _infer_claim_submission_error_code(graphql_response, transformed),
            "DUPLICATE_CLAIM_REJECTED"
        )

    def test_authentication_error_outranks_earlier_validation_error(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "Generic validation message.",
                },
                {
                    "code": "UNAUTHORIZED_AUTHENTICATION_FAILED",
                    "description": "invalid_access_token",
                },
            ],
            "data": {
                "claimSubmission": {
                    "transactionId": None,
                    "statusCode": "000",
                    "responseType": None,
                }
            },
        }

        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "401")
        self.assertIn("Authentication failed", transformed.get("message", ""))

    def test_mixed_graphql_validation_errors_with_accepted_payload_classifies_success(self):
        """Real Claim Actions shape: GraphQL errors + data.claimSubmission 000 + 999 + inline 277."""
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "BENEFIT VALIDATIONS: example payer advisory text.",
                },
                {
                    "code": "BENEFIT VALIDATIONS",
                    "description": "We are unable to process your request at this time.",
                },
            ],
            "data": {
                "claimSubmission": {
                    "transactionId": "8841512345678901",
                    "statusCode": "000",
                    "responseType": "837999",
                    "message": "Claim submitted successfully. Refer 277CA for validation outcomes.",
                    "x12ResponseData": "ISA*00*          *00*          *ZZ*SUBMITTER*ZZ*PAYER*~"
                    "GS*HP*SUB*PAY*20260101*1*1*X*005010X231~"
                    "ST*999*0001*005010X231~"
                    "IK5*A~"
                    "AK9*A*1*1*1~"
                    "SE*4*0001~"
                    "GE*1*1~"
                    "IEA*1*000000001~",
                    "x12Response277CA": "ISA*00*          *00*          *ZZ*SUB*ZZ*PAY*~"
                    "ST*277*0002*005010X231~"
                    "STC*A1:19*20260101*U*1********~"
                    "SE*3*0002~",
                }
            },
        }

        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "000")
        self.assertEqual(transformed.get("transactionId"), "8841512345678901")
        self.assertIn("ST*277", transformed.get("x12ResponseData", "").upper())
        meta = transformed.get("_metadata") or {}
        self.assertTrue(meta.get("optumai_backend_validation_soft"))
        self.assertIsInstance(meta.get("optumai_graphql_warnings"), list)
        self.assertGreaterEqual(len(meta.get("optumai_graphql_warnings")), 1)

    def test_attach_optumai_backend_validation_metadata_preserves_soft_submission(self):
        from MediCafe.api_core_operations import _attach_optumai_backend_validation_metadata

        response = {
            "statuscode": "000",
            "message": "Claim submitted successfully.",
            "transactionId": "8841512345678901",
            "x12ResponseData": "ST*277~",
            "_metadata": {
                "optumai_backend_validation_soft": True,
                "optumai_graphql_warnings": [{"code": "BENEFIT VALIDATIONS", "detail": "x"}],
            },
        }
        out = _attach_optumai_backend_validation_metadata(response)
        self.assertEqual(out.get("statuscode"), "000")
        self.assertTrue((out.get("_metadata") or {}).get("optumai_backend_validation_soft"))
        self.assertNotIn("claim_submission_success", out.get("_metadata") or {})

    def test_backend_validation_flavor_maps_unsupported_feature_to_422(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "Currently not Supported for UMR",
                },
            ],
            "data": {},
        }
        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "422")
        self.assertIn("not supported", transformed.get("message", "").lower())

    def test_graphql_errors_with_null_data_do_not_raise_and_preserve_400_classification(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {
                    "code": "BACKEND_VALIDATION_FAILED",
                    "description": "PA Failure - Provider with sequence no. 01 not found.",
                }
            ],
            "data": None,
        }
        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "400")
        self.assertIn("reason=provider_sequence_missing", transformed.get("message", ""))

    def test_unsupported_outranks_earlier_generic_validation(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {"code": "BACKEND_VALIDATION_FAILED", "description": "Some generic validation issue."},
                {"code": "BACKEND_VALIDATION_FAILED", "description": "Feature currently not supported for payer."},
            ],
            "data": {},
        }
        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "422")

    def test_auth_still_outranks_unsupported_in_mixed_errors(self):
        from MediCafe.graphql_utils import transform_claim_submission_response_to_legacy

        graphql_response = {
            "errors": [
                {"code": "BACKEND_VALIDATION_FAILED", "description": "Currently not Supported for UMR"},
                {"code": "UNAUTHORIZED_AUTHENTICATION_FAILED", "description": "invalid_access_token"},
            ],
            "data": {},
        }
        transformed = transform_claim_submission_response_to_legacy(graphql_response)
        self.assertEqual(transformed.get("statuscode"), "401")

    def test_infer_claim_submission_error_code_unsupported_feature(self):
        from MediCafe.claim_actions_adapter import _infer_claim_submission_error_code

        response = {
            "errors": [
                {"code": "BACKEND_VALIDATION_FAILED", "description": "Currently not Supported for UMR"},
            ]
        }
        transformed = {
            "statuscode": "422",
            "message": "Payer-specific feature not supported: Currently not Supported for UMR",
        }
        self.assertEqual(_infer_claim_submission_error_code(response, transformed), "UNSUPPORTED_FEATURE")

    def test_infer_claim_submission_error_code_duplicate_claim_rejected(self):
        from MediCafe.claim_actions_adapter import _infer_claim_submission_error_code

        response = {"errors": [{"code": "BACKEND_VALIDATION_FAILED", "description": "PA Failure"}]}
        transformed = {
            "statuscode": "400",
            "message": (
                "Validation failed [reason=duplicate_claim_rejected]: "
                "This claim appears to be a duplicate of previously submitted claim ID [FM96902899]"
            ),
        }
        self.assertEqual(_infer_claim_submission_error_code(response, transformed), "DUPLICATE_CLAIM_REJECTED")


class TestNm182RenderingSegmentLayout(unittest.TestCase):
    def test_nm182_individual_nm102_1_when_first_name_present(self):
        from MediLink.MediLink_837p_encoder_library import create_nm1_rendering_provider_segment

        config = _build_minimal_config()
        segments = create_nm1_rendering_provider_segment(config, endpoint="OPTUMAI")
        self.assertTrue(segments)
        nm1 = segments[0]
        self.assertTrue(nm1.startswith("NM1*82*1*"))
        parts = nm1.rstrip("~").split("*")
        self.assertEqual(parts[1], "82")
        self.assertEqual(parts[2], "1")
        self.assertEqual(parts[3], "BOLES")
        self.assertEqual(parts[4], "STEVEN")
        self.assertEqual(parts[5], "")
        self.assertEqual(parts[6], "")
        self.assertEqual(parts[7], "")
        self.assertEqual(parts[8], "XX")
        self.assertEqual(parts[9], "1114031507")

    def test_nm182_org_nm102_2_when_first_name_absent(self):
        from MediLink.MediLink_837p_encoder_library import create_nm1_rendering_provider_segment

        config = _build_minimal_config()
        config["rendering_provider_first_name"] = ""
        config["rendering_provider_last_name"] = "CLINIC GROUP"
        segments = create_nm1_rendering_provider_segment(config, endpoint="OPTUMAI")
        self.assertTrue(segments)
        nm1 = segments[0]
        self.assertTrue(nm1.startswith("NM1*82*2*"))
        parts = nm1.rstrip("~").split("*")
        self.assertEqual(parts[2], "2")
        self.assertEqual(parts[3], "CLINIC GROUP")

    def test_nm182_explicit_entity_2_emits_without_first_name(self):
        from MediLink.MediLink_837p_encoder_library import create_nm1_rendering_provider_segment

        config = _build_minimal_config()
        config["rendering_provider_first_name"] = ""
        config["rendering_provider_last_name"] = "ACME CLINIC"
        config["rendering_provider_entity_type_qualifier"] = "2"
        segments = create_nm1_rendering_provider_segment(config, endpoint="OPTUMAI")
        self.assertTrue(segments)
        self.assertTrue(segments[0].startswith("NM1*82*2*ACME CLINIC*"))

    def test_prv_pe_mirrors_billing_taxonomy_only_when_optumai_flag_set(self):
        from MediLink.MediLink_837p_encoder_library import create_nm1_rendering_provider_segment

        config = _build_minimal_config_billing_taxonomy_only_for_rendering()
        config["endpoints"]["OPTUMAI"]["mirror_billing_taxonomy_to_rendering_prv_pe"] = True
        segments = create_nm1_rendering_provider_segment(config, endpoint="OPTUMAI")
        prv = [s for s in segments if s.startswith("PRV*PE*PXC*")]
        self.assertEqual(len(prv), 1)
        self.assertIn("363LA2200X", prv[0])

    def test_nm182_explicit_org_override_blanks_nm104_when_first_name_present(self):
        """NM102=2 must not carry a person first name in NM104; inherited configs may set both."""
        from MediLink.MediLink_837p_encoder_library import create_nm1_rendering_provider_segment

        config = _build_minimal_config()
        config["rendering_provider_entity_type_qualifier"] = "2"
        config["rendering_provider_last_name"] = "ACME CLINIC"
        config["rendering_provider_first_name"] = "STEVEN"
        segments = create_nm1_rendering_provider_segment(config, endpoint="OPTUMAI")
        self.assertTrue(segments)
        parts = segments[0].rstrip("~").split("*")
        self.assertEqual(parts[2], "2")
        self.assertEqual(parts[3], "ACME CLINIC")
        self.assertEqual(parts[4], "")

    def test_nm182_explicit_entity_1_without_first_name_skips_segment(self):
        from MediLink.MediLink_837p_encoder_library import create_nm1_rendering_provider_segment

        config = _build_minimal_config()
        config["rendering_provider_first_name"] = ""
        config["rendering_provider_entity_type_qualifier"] = "1"
        segments = create_nm1_rendering_provider_segment(config, endpoint="OPTUMAI")
        self.assertEqual(segments, [])


class TestClaimActionsHeaderConformance(unittest.TestCase):
    def test_required_headers_present_and_tin_normalized(self):
        from MediCafe.api_core import build_optumai_headers

        config = {
            "MediLink_Config": {
                "billing_provider_tin": "12-3456789",
            }
        }
        headers = build_optumai_headers(
            config,
            api_url="https://sandbox-apigw.optum.com",
            next_page_token="NP-1",
        )

        self.assertEqual(headers.get("Content-Type"), "application/json")
        self.assertEqual(headers.get("Accept"), "application/json")
        self.assertEqual(headers.get("providerTaxId"), "123456789")
        self.assertTrue(headers.get("x-optum-consumer-correlation-id"))
        self.assertEqual(headers.get("environment"), "sandbox")
        self.assertEqual(headers.get("nextPageToken"), "NP-1")

    def test_invalid_tin_omits_provider_tax_id(self):
        from MediCafe.api_core import build_optumai_headers

        config = {
            "MediLink_Config": {
                "billing_provider_tin": "12-3456",
            }
        }
        headers = build_optumai_headers(config, api_url="https://apigw.optum.com")
        self.assertFalse("providerTaxId" in headers)


class TestSubmitUhcClaimProviderValidationPath(unittest.TestCase):
    @patch("MediCafe.api_core.is_test_mode", return_value=None)
    @patch("MediCafe.api_core._optumai_supports_feature_for_client", return_value=(True, None, None))
    @patch("MediCafe.claim_actions_adapter.extract_payer_id_from_x12", return_value="87726")
    @patch(
        "MediCafe.claim_actions_adapter._validate_optumai_config",
        return_value=(True, None, {"claim_actions": "/oihub/claim/actions/v1"}),
    )
    @patch("MediCafe.claim_actions_adapter.submit_claim_via_optumai")
    @patch("MediCafe.core_utils.extract_medilink_config")
    def test_provider_validation_400_does_not_fallback_to_uhc(
        self,
        mock_extract,
        mock_optum_submit,
        _mock_validate,
        _mock_extract_payer,
        _mock_supports,
        _mock_test_mode,
    ):
        from MediCafe.api_core import submit_uhc_claim

        mock_extract.return_value = {
            "endpoints": {
                "OPTUMAI": {
                    "api_url": "https://apigw.optum.com",
                    "submission_method": "api",
                    "additional_endpoints": {"claim_actions": "/oihub/claim/actions/v1"},
                },
                "UHCAPI": {
                    "additional_endpoints": {
                        "claim_submission": "/Claims/api/claim-submission/v1",
                        "claim_details": "/Claims/api/claim-details/v1",
                    }
                },
            }
        }

        mock_optum_submit.return_value = {
            "statuscode": "400",
            "message": "Validation failed: PA Failure - Provider with sequence no. 01 not found.",
            "transactionId": None,
            "responseType": None,
            "x12ResponseData": None,
        }

        mock_client = MagicMock()
        mock_client.config = {}
        result = submit_uhc_claim(mock_client, "ISA*00*FAKE837")

        self.assertEqual(mock_optum_submit.call_count, 1)
        self.assertEqual(result.get("statuscode"), "400")
        self.assertIn("Provider with sequence no. 01 not found", result.get("message", ""))
        self.assertEqual(mock_client.make_api_call.call_count, 0)


class TestSubmitUhcClaimSoftGraphqlInline277(unittest.TestCase):
    @patch("MediCafe.api_core.is_test_mode", return_value=None)
    @patch("MediCafe.api_core._optumai_supports_feature_for_client", return_value=(True, None, None))
    @patch("MediCafe.claim_actions_adapter.extract_payer_id_from_x12", return_value="87726")
    @patch(
        "MediCafe.claim_actions_adapter._validate_optumai_config",
        return_value=(True, None, {"claim_actions": "/oihub/claim/actions/v1"}),
    )
    @patch("MediCafe.claim_actions_adapter.search_277ca_via_optumai")
    @patch("MediCafe.claim_actions_adapter.submit_claim_via_optumai")
    @patch("MediCafe.core_utils.extract_medilink_config")
    def test_inline_277_after_soft_graphql_success_skips_search277ca(
        self,
        mock_extract,
        mock_submit,
        mock_search277,
        _mock_validate,
        _mock_extract_payer,
        _mock_supports,
        _mock_test_mode,
    ):
        from MediCafe.api_core import submit_uhc_claim

        mock_extract.return_value = {
            "endpoints": {
                "OPTUMAI": {
                    "api_url": "https://apigw.optum.com",
                    "submission_method": "api",
                    "additional_endpoints": {"claim_actions": "/oihub/claim/actions/v1"},
                },
                "UHCAPI": {
                    "additional_endpoints": {
                        "claim_submission": "/Claims/api/claim-submission/v1",
                        "claim_details": "/Claims/api/claim-details/v1",
                    }
                },
            }
        }
        mock_submit.return_value = {
            "statuscode": "000",
            "message": "Claim submitted successfully. Refer 277CA for validation outcomes.",
            "transactionId": "8841512345678901",
            "responseType": "837277",
            "x12ResponseData": "ISA*00*FAKE~ST*277*0001*005010X231~STC*A1:19~",
            "_metadata": {
                "optumai_backend_validation_soft": True,
                "optumai_graphql_warnings": [{"code": "BENEFIT VALIDATIONS", "detail": "x"}],
            },
        }

        mock_client = MagicMock()
        mock_client.config = {}
        result = submit_uhc_claim(mock_client, "ISA*00*FAKE837")

        self.assertEqual(result.get("statuscode"), "000")
        self.assertIn("ST*277", result.get("x12ResponseData", "").upper())
        mock_search277.assert_not_called()
        self.assertEqual(mock_client.make_api_call.call_count, 0)


def _build_minimal_patient():
    return {
        "CHART": "TEST001",
        "DATE": "03-25-26",
        "AMOUNT": "450",
        "TOS": "11",
        "DIAG": "A010",
        "CODEA": "99213",
        "POS": "11",
        "MINTUES": "15",
        "LAST": "DOE",
        "FIRST": "JANE",
        "MIDDLE": "A",
        "IPOLICY": "POL123",
        "ISTREET": "1 MAIN ST",
        "ICITY": "MIAMI",
        "ISTATE": "FL",
        "IZIP": "331010000",
        "BDAY": "06-05-80",
        "SEX": "F",
        "INAME": "AARP MEDICARE COMPLETE",
        "insurance_type": "12",
        "insurance_type_source": "MANUAL",
    }


def _build_optumai_config_emit_flag_without_rendering_fields():
    """OPTUMAI with emit_rendering_provider_segment but no rendering NPI/last name (no global fallbacks)."""
    return {
        "submitter_name": "TEST BILLING",
        "submitter_tel": "3055551212",
        "billing_provider_tin": "123456789",
        "billing_provider_address": "1 CLINIC WAY",
        "billing_provider_city": "MIAMI",
        "billing_provider_state": "FL",
        "billing_provider_zip": "33101",
        "service_facility_npi": "1992735088",
        "service_facility_name": "TEST FACILITY",
        "service_facility_address": "1 CLINIC WAY",
        "service_facility_city": "MIAMI",
        "service_facility_state": "FL",
        "service_facility_zip": "33101",
        "endpoints": {
            "OPTUMAI": {
                "billing_provider_lastname": "OLIVER-VIDAUD",
                "billing_provider_firstname": "RAFAEL",
                "billing_provider_npi": "1942376918",
                "receiver_name": "OPTUM",
                "receiver_edi": "87726",
                "nm_103_value": "TEST SUBMITTER",
                "nm_109_value": "GATE9013",
                "emit_rendering_provider_segment": True,
            },
        },
    }


def _build_minimal_config_billing_taxonomy_only_for_rendering():
    """Rendering NPI/name present but only billing taxonomy set — PRV*PE must not copy billing into 2310B."""
    base = _build_minimal_config()
    del base["rendering_provider_taxonomy"]
    base["billing_provider_taxonomy"] = "363LA2200X"
    return base


def _build_minimal_config():
    return {
        "submitter_name": "TEST BILLING",
        "submitter_tel": "3055551212",
        "billing_provider_tin": "123456789",
        "billing_provider_address": "1 CLINIC WAY",
        "billing_provider_city": "MIAMI",
        "billing_provider_state": "FL",
        "billing_provider_zip": "33101",
        "service_facility_npi": "1992735088",
        "service_facility_name": "TEST FACILITY",
        "service_facility_address": "1 CLINIC WAY",
        "service_facility_city": "MIAMI",
        "service_facility_state": "FL",
        "service_facility_zip": "33101",
        "rendering_provider_npi": "1114031507",
        "rendering_provider_last_name": "BOLES",
        "rendering_provider_first_name": "STEVEN",
        "rendering_provider_taxonomy": "363LA2200X",
        "endpoints": {
            "OPTUMAI": {
                "billing_provider_lastname": "OLIVER-VIDAUD",
                "billing_provider_firstname": "RAFAEL",
                "billing_provider_npi": "1942376918",
                "receiver_name": "OPTUM",
                "receiver_edi": "87726",
                "nm_103_value": "TEST SUBMITTER",
                "nm_109_value": "GATE9013",
            },
            "AVAILITY": {
                "billing_provider_lastname": "OLIVER-VIDAUD",
                "billing_provider_firstname": "RAFAEL",
                "billing_provider_npi": "1942376918",
                "receiver_name": "AVAILITY",
                "receiver_edi": "00590",
                "nm_103_value": "TEST SUBMITTER",
                "nm_109_value": "GATE9013",
            },
        },
    }


class Test837ProviderLoopOrdering(unittest.TestCase):
    def _format_claim(self, endpoint):
        from MediLink.MediLink_837p_encoder import format_single_claim

        patient_data = _build_minimal_patient()
        config = _build_minimal_config()
        crosswalk = {
            "diagnosis_to_medisoft": {
                "A010": "A010",
            }
        }

        def _mock_payer_resolution(parsed_data, _config, _endpoint, _crosswalk, _client):
            parsed_data["payer_id"] = "87726"
            parsed_data["payer_name"] = "UNITED HEALTH CARE"
            return parsed_data

        with patch(
            "MediLink.MediLink_837p_encoder.MediLink_837p_encoder_library.payer_id_to_payer_name",
            side_effect=_mock_payer_resolution,
        ):
            return format_single_claim(patient_data, config, endpoint, 1, crosswalk, None)

    def test_optumai_places_rendering_provider_after_clm_before_service_lines(self):
        claim = self._format_claim("OPTUMAI")
        segments = [seg for seg in claim.split("\n") if seg.strip()]

        clm_idx = next(i for i, seg in enumerate(segments) if seg.startswith("CLM*"))
        rendering_idx = next(i for i, seg in enumerate(segments) if seg.startswith("NM1*82*"))
        lx_idx = next(i for i, seg in enumerate(segments) if seg.startswith("LX*"))

        self.assertLess(clm_idx, rendering_idx)
        self.assertLess(rendering_idx, lx_idx)
        self.assertTrue(any(seg.startswith("PRV*PE*PXC*363LA2200X~") for seg in segments))

    def _format_claim_with_config(self, endpoint, config):
        from MediLink.MediLink_837p_encoder import format_single_claim

        patient_data = _build_minimal_patient()
        crosswalk = {"diagnosis_to_medisoft": {"A010": "A010"}}

        def _mock_payer_resolution(parsed_data, _config, _endpoint, _crosswalk, _client):
            parsed_data["payer_id"] = "87726"
            parsed_data["payer_name"] = "UNITED HEALTH CARE"
            return parsed_data

        with patch(
            "MediLink.MediLink_837p_encoder.MediLink_837p_encoder_library.payer_id_to_payer_name",
            side_effect=_mock_payer_resolution,
        ):
            return format_single_claim(patient_data, config, endpoint, 1, crosswalk, None)

    def test_optumai_no_prv_pe_when_only_billing_taxonomy_available(self):
        config = _build_minimal_config_billing_taxonomy_only_for_rendering()
        claim = self._format_claim_with_config("OPTUMAI", config)
        self.assertIn("NM1*82*", claim)
        self.assertNotIn("PRV*PE*PXC*", claim)

    def test_availity_default_output_omits_rendering_provider_loop(self):
        claim = self._format_claim("AVAILITY")
        self.assertNotIn("NM1*82*", claim)

    def test_endpoint_differential_only_optumai_adds_rendering_loop(self):
        availity_claim = self._format_claim("AVAILITY")
        optumai_claim = self._format_claim("OPTUMAI")

        availity_segments = [seg for seg in availity_claim.split("\n") if seg.strip()]
        optumai_segments = [seg for seg in optumai_claim.split("\n") if seg.strip()]

        availity_billing = [seg for seg in availity_segments if seg.startswith("NM1*85*")]
        optumai_billing = [seg for seg in optumai_segments if seg.startswith("NM1*85*")]
        self.assertEqual(availity_billing, optumai_billing)

        self.assertFalse(any(seg.startswith("NM1*82*") for seg in availity_segments))
        self.assertTrue(any(seg.startswith("NM1*82*") for seg in optumai_segments))

    def test_optumai_emit_flag_incomplete_rendering_data_does_not_emit_nm1_82(self):
        from MediLink.MediLink_837p_encoder import format_single_claim

        patient_data = _build_minimal_patient()
        config = _build_optumai_config_emit_flag_without_rendering_fields()
        crosswalk = {"diagnosis_to_medisoft": {"A010": "A010"}}

        def _mock_payer_resolution(parsed_data, _config, _endpoint, _crosswalk, _client):
            parsed_data["payer_id"] = "87726"
            parsed_data["payer_name"] = "UNITED HEALTH CARE"
            return parsed_data

        with patch(
            "MediLink.MediLink_837p_encoder.MediLink_837p_encoder_library.payer_id_to_payer_name",
            side_effect=_mock_payer_resolution,
        ):
            claim = format_single_claim(patient_data, config, "OPTUMAI", 1, crosswalk, None)

        self.assertNotIn("NM1*82*", claim)


if __name__ == "__main__":
    unittest.main()
