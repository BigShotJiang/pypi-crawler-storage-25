# -*- coding: utf-8 -*-
from __future__ import print_function

import json
import os
import sqlite3
import tempfile
import unittest


class PhaseCDbHealthProbeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="mc_db_probe_")

    def tearDown(self):
        try:
            import shutil

            shutil.rmtree(self.tmp, ignore_errors=True)
        except Exception:
            pass

    def test_missing_db_sets_db_file_missing_flag(self):
        from MediCafe.phase_c_db_health_probe import build_phase_c_db_health_probe

        doc = build_phase_c_db_health_probe(self.tmp, None)
        self.assertIn("db_file_missing", doc.get("drift_flags") or [])

    def test_happy_path_ingest_artifact_columns(self):
        from MediCafe.phase_c_db_health_probe import build_phase_c_db_health_probe, write_phase_c_db_health_probe_latest

        db_path = os.path.join(self.tmp, "unified_model_xp.db")
        conn = sqlite3.connect(db_path)
        conn.execute(
            "CREATE TABLE ingest_artifact (ingest_key TEXT, source_system TEXT, source_type TEXT, "
            "source_ref TEXT, message_id TEXT, attachment_name TEXT, attachment_sha256 TEXT, "
            "payload_json TEXT, ingest_status TEXT)"
        )
        conn.commit()
        conn.close()

        doc = build_phase_c_db_health_probe(self.tmp, None)
        self.assertTrue(doc.get("db_exists"))
        self.assertEqual(str(doc.get("integrity_check") or "").lower(), "ok")
        self.assertTrue(doc.get("ingest_artifact_table_present"))
        self.assertTrue(doc.get("ingest_artifact_required_columns_ok"))
        self.assertFalse(doc.get("drift_flags"))

        os.makedirs(os.path.join(self.tmp, "reports"))
        path = write_phase_c_db_health_probe_latest(self.tmp, None)
        self.assertTrue(path and os.path.isfile(path))
        with open(path, "r", encoding="utf-8") as handle:
            roundtrip = json.load(handle)
        self.assertEqual(roundtrip.get("schema_version"), 1)
