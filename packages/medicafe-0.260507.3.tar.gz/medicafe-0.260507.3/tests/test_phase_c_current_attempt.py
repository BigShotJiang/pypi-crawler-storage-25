import json
import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
UM_ROOT = os.path.join(REPO_ROOT, "scripts", "unified_model")
if UM_ROOT not in sys.path:
    sys.path.insert(0, UM_ROOT)

from phase_c_current_attempt import (  # noqa: E402
    begin_phase_c_current_attempt,
    phase_c_current_attempt_path,
    refresh_phase_c_current_attempt_from_lab,
)


def _write_json(path, payload):
    parent = os.path.dirname(path)
    if parent and not os.path.isdir(parent):
        os.makedirs(parent)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)


class PhaseCCurrentAttemptTests(unittest.TestCase):
    def test_current_attempt_reports_entrypoint_not_observed(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(
                td,
                "attempt-1",
                "test",
                expected_manifest_sha256="sha-1",
            )
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-1", "test")
            self.assertEqual(doc["last_reached_stage"], "not_entered")
            self.assertEqual(
                doc["current_blocker"],
                "phase_c_script_entrypoint_not_observed_current_attempt",
            )
            with open(os.path.join(td, "diagnostics_state.json"), "r", encoding="utf-8") as handle:
                st = json.load(handle)
            self.assertEqual(
                st["last_phase_c_current_attempt_blocker"],
                "phase_c_script_entrypoint_not_observed_current_attempt",
            )
        finally:
            shutil.rmtree(td)

    def test_current_attempt_tracks_bootstrap_without_finish(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(td, "attempt-2", "test")
            reports = os.path.join(td, "reports")
            _write_json(
                os.path.join(reports, "ingest_from_manifest_bootstrap_latest.json"),
                {"stage": "main_start"},
            )
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-2", "test")
            self.assertEqual(doc["last_reached_stage"], "bootstrap")
            self.assertEqual(
                doc["current_blocker"],
                "phase_c_script_entered_but_no_finish_diag_current_attempt",
            )
        finally:
            shutil.rmtree(td)

    def test_current_attempt_tracks_successful_handoff(self):
        td = tempfile.mkdtemp()
        try:
            begin_phase_c_current_attempt(
                td,
                "attempt-3",
                "test",
                expected_manifest_sha256="sha-3",
            )
            reports = os.path.join(td, "reports")
            _write_json(os.path.join(reports, "ingest_from_manifest_diagnostics_latest.json"), {"rid": "c-3"})
            _write_json(os.path.join(reports, "ingest_write_summary_c-3.json"), {"ok": True})
            _write_json(os.path.join(reports, "phase_c_execution_handoff_r.json"), {
                "status": "ok",
                "blocker_class": "phase_c_handoff_ok",
            })
            state = {
                "last_ingest_manifest_sha256": "sha-3",
                "last_phase_c_execution_handoff_report_path": os.path.join(
                    reports, "phase_c_execution_handoff_r.json"),
            }
            _write_json(os.path.join(td, "diagnostics_state.json"), state)
            _write_json(os.path.join(td, "run_cursor.json"), {"last_ingest_manifest_sha256": "sha-3"})
            doc = refresh_phase_c_current_attempt_from_lab(td, "attempt-3", "test")
            self.assertEqual(doc["last_reached_stage"], "handoff_report")
            self.assertEqual(doc["current_blocker"], "phase_c_current_attempt_ok")
            self.assertTrue(os.path.isfile(phase_c_current_attempt_path(td)))
        finally:
            shutil.rmtree(td)


if __name__ == "__main__":
    unittest.main()
