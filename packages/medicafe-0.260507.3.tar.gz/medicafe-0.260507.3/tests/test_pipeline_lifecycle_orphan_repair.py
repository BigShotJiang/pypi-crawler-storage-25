# -*- coding: utf-8 -*-
"""Orphan pipeline_state/active_run_id repair (crash before _update_pipeline_state)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)


class TestOrphanPipelineLifecycleRepair(unittest.TestCase):
    def test_repair_clears_mismatched_active_run_id(self):
        from run_shadow_pipeline import (
            _repair_orphan_pipeline_lifecycle_state,
            _update_pipeline_phase_marker,
            iso_utc_now,
        )

        lab = tempfile.mkdtemp(prefix="mc_orch_")
        try:
            os.makedirs(os.path.join(lab, "reports"), exist_ok=True)
            sp = os.path.join(lab, "diagnostics_state.json")
            with open(sp, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "pipeline_state": "running",
                        "active_run_id": "ghost-run-2",
                        "active_phase": "C",
                        "last_shadow_pipeline_run_id": "completed-run-1",
                        "last_shadow_pipeline_outcome": "failed",
                    },
                    f,
                )
            # Real pipeline order: phase marker establishes this run as owner of active_run_id,
            # then repair clears any *remaining* ghost (marker alone overwrites ghost active_run_id).
            _update_pipeline_phase_marker(lab, "new-run-3", "A", iso_utc_now(), phase_run_ids={})
            _repair_orphan_pipeline_lifecycle_state(lab, "new-run-3")
            with open(sp, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertEqual(st.get("active_run_id"), "new-run-3")
            self.assertEqual(st.get("pipeline_state"), "bootstrapping")
            self.assertEqual(st.get("last_shadow_pipeline_run_id"), "completed-run-1")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_repair_skips_when_active_matches_incoming_rid(self):
        from run_shadow_pipeline import _repair_orphan_pipeline_lifecycle_state

        lab = tempfile.mkdtemp(prefix="mc_orch_same_")
        try:
            sp = os.path.join(lab, "diagnostics_state.json")
            with open(sp, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "pipeline_state": "running",
                        "active_run_id": "same-rid",
                        "last_shadow_pipeline_run_id": "other",
                    },
                    f,
                )
            _repair_orphan_pipeline_lifecycle_state(lab, "same-rid")
            with open(sp, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertEqual(st.get("active_run_id"), "same-rid")
            self.assertEqual(st.get("pipeline_state"), "running")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_repair_stale_ghost_when_phase_marker_did_not_apply(self):
        """If active_run_id still differs from incoming after marker, treat as orphan crash."""
        from run_shadow_pipeline import _repair_orphan_pipeline_lifecycle_state

        lab = tempfile.mkdtemp(prefix="mc_orch_stale_")
        try:
            sp = os.path.join(lab, "diagnostics_state.json")
            with open(sp, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "pipeline_state": "running",
                        "active_run_id": "ghost-run-2",
                        "active_phase": "C",
                        "last_shadow_pipeline_run_id": "completed-run-1",
                    },
                    f,
                )
            _repair_orphan_pipeline_lifecycle_state(lab, "new-run-3")
            with open(sp, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertEqual(st.get("pipeline_state"), "failed")
            self.assertEqual(st.get("active_run_id"), "")
            self.assertEqual(st.get("last_error_code"), "PIPELINE_STALE_LIFECYCLE_RECOVERED")
        finally:
            shutil.rmtree(lab, ignore_errors=True)


class TestReportDeliveryStatusLifecycleLines(unittest.TestCase):
    """get_report_delivery_status_lines: mismatch is normal while pipeline lock is live."""

    def test_anomaly_when_mismatch_and_no_live_lock(self):
        from MediCafe import cloud_readiness as cr

        lab = tempfile.mkdtemp(prefix="mc_d1_")
        try:
            sp = os.path.join(lab, "diagnostics_state.json")
            with open(sp, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_run_id": "in-flight-1",
                        "last_shadow_pipeline_run_id": "completed-0",
                    },
                    f,
                )
            lines = cr.get_report_delivery_status_lines(lab)
            self.assertTrue(
                any("Pipeline lifecycle anomaly" in line for line in lines),
                msg="\n".join(lines),
            )
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_anomaly_when_mismatch_but_lock_held_by_live_pid(self):
        from MediCafe import cloud_readiness as cr

        lab = tempfile.mkdtemp(prefix="mc_d2_")
        try:
            sp = os.path.join(lab, "diagnostics_state.json")
            with open(sp, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_run_id": "in-flight-1",
                        "last_shadow_pipeline_run_id": "completed-0",
                    },
                    f,
                )
            lock_path = os.path.join(lab, "shadow_pipeline.lock")
            with open(lock_path, "w", encoding="utf-8") as f:
                f.write("pid=1\nacquired_at_utc=2000-01-01T00:00:00Z\nheartbeat_at_utc=2000-01-01T00:00:00Z\n")
            lines = cr.get_report_delivery_status_lines(lab)
            self.assertFalse(any("Pipeline lifecycle anomaly" in line for line in lines))
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
