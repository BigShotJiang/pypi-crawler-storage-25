import json
import os
import shutil
import tempfile
import time
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

import MediCafe.submission_index as submission_index


class SubmissionIndexLookupCacheTests(unittest.TestCase):
    def _write_index(self, root):
        path = os.path.join(root, 'submission_index.jsonl')
        with open(path, 'w') as f:
            f.write(json.dumps({
                'record_type': 'submission',
                'claim_key': 'CK1',
                'submitted_claim_number': 'SCN1',
                'transactionId': 'TX1',
                'status': 'submitted',
            }) + '\n')
            f.write(json.dumps({
                'record_type': 'ack_event',
                'notes': 'ack event',
                'claim_key': 'CK1',
                'control_ids': {'transactionId': 'TX1'},
                'ack_type': '277CA',
            }) + '\n')
            f.write(json.dumps({
                'record_type': 'submission',
                'claim_key': 'CK1',
                'submitted_claim_number': 'SCN1',
                'transactionId': 'TX2',
                'status': 'resubmitted',
            }) + '\n')

    def test_lookup_apis_share_one_pass_cache(self):
        root = tempfile.mkdtemp(prefix='mc_idx_lookup_cache_')
        try:
            self._write_index(root)
            submission_index._LOOKUP_CACHE.clear()
            with patch.object(
                submission_index,
                '_build_lookup_maps',
                wraps=submission_index._build_lookup_maps
            ) as mock_build:
                first = submission_index.find_by_claim_key(root, 'CK1')
                latest = submission_index.find_by_claim_key_latest(root, 'CK1')
                by_claim = submission_index.load_latest_submissions_by_claim_key(root)
                by_scn = submission_index.load_latest_submissions_by_submitted_claim_number(root)
                by_tx = submission_index.get_submission_by_transaction_id(root, 'TX1')
                acks = submission_index.get_ack_events_by_transaction_id(root, 'TX1')

            self.assertEqual(mock_build.call_count, 1)
            self.assertEqual(first.get('status'), 'submitted')
            self.assertEqual(latest.get('status'), 'resubmitted')
            self.assertEqual(by_claim.get('CK1', {}).get('status'), 'resubmitted')
            self.assertEqual(by_scn.get('SCN1', {}).get('status'), 'resubmitted')
            self.assertEqual(by_tx.get('transactionId'), 'TX1')
            self.assertEqual(len(acks), 1)
            self.assertEqual(acks[0].get('ack_type'), '277CA')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_lookup_cache_invalidates_when_index_changes(self):
        root = tempfile.mkdtemp(prefix='mc_idx_lookup_invalidate_')
        try:
            self._write_index(root)
            submission_index._LOOKUP_CACHE.clear()
            with patch.object(
                submission_index,
                '_build_lookup_maps',
                wraps=submission_index._build_lookup_maps
            ) as mock_build:
                first = submission_index.find_by_claim_key_latest(root, 'CK1')
                self.assertEqual(first.get('status'), 'resubmitted')
                time.sleep(1.05)
                path = os.path.join(root, 'submission_index.jsonl')
                with open(path, 'a') as f:
                    f.write(json.dumps({
                        'record_type': 'submission',
                        'claim_key': 'CK1',
                        'submitted_claim_number': 'SCN1',
                        'transactionId': 'TX3',
                        'status': 'newest',
                    }) + '\n')
                latest = submission_index.find_by_claim_key_latest(root, 'CK1')

            self.assertEqual(mock_build.call_count, 2)
            self.assertEqual(latest.get('status'), 'newest')
        finally:
            shutil.rmtree(root, ignore_errors=True)

    def test_find_submission_matches_legacy_index_when_payer_slot_added(self):
        """
        Pre-upgrade rows used compute_claim_key(chart, '', insurance, dos, proc) so slot 2
        was the insurance label. Duplicate detection must still find them after electronic
        payer ids populate slot 2.
        """
        root = tempfile.mkdtemp(prefix='mc_idx_legacy_payer_')
        try:
            legacy_key = submission_index.compute_claim_key(
                '12345', '', 'UHC MEDICARE', '2025-06-01', '66984'
            )
            path = os.path.join(root, 'submission_index.jsonl')
            with open(path, 'w') as f:
                f.write(
                    json.dumps(
                        {
                            'record_type': 'submission',
                            'claim_key': legacy_key,
                            'submitted_at': '2025-06-02',
                            'endpoint': 'OPTUMEDI',
                            'receipt_file': 'r.txt',
                            'status': 'submitted',
                        }
                    )
                    + '\n'
                )
            submission_index._LOOKUP_CACHE.clear()
            hit = submission_index.find_submission_by_claim_parts(
                root,
                '12345',
                '87726',
                'UHC MEDICARE',
                '2025-06-01',
                '66984',
                prefer_latest=False,
            )
            self.assertIsNotNone(hit)
            self.assertEqual(hit.get('claim_key'), legacy_key)
        finally:
            shutil.rmtree(root, ignore_errors=True)


if __name__ == '__main__':
    unittest.main()
