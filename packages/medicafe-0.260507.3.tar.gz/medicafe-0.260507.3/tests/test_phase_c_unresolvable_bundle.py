# -*- coding: utf-8 -*-
"""Edge cases for phase_c_unresolvable auto-bundle (dedup, extra_meta)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)


class TestPhaseCUnresolvableBundle(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_unres_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        with open(os.path.join(root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
            json.dump(
                {
                    "version": 2,
                    "phase_c_circuit_open": True,
                    "phase_c_remediation_history": [{"event": "circuit_opened", "at_utc": "t"}],
                },
                f,
            )
        with open(os.path.join(root, "run_cursor.json"), "w", encoding="utf-8") as f:
            json.dump({"version": 1}, f)
        return root

    def test_submit_returns_false_when_dedup_denies(self):
        import phase_e_auto_report as pea

        lab = self._lab()
        try:
            with patch("MediCafe.error_reporter.report_dedup_try_reserve", return_value=(False, None)):
                ok = pea.submit_phase_c_unresolvable_bundle(
                    lab,
                    {"run_id": "rid-u", "lab_root": lab, "error_code": "PHASE_C_CIRCUIT_OPEN"},
                )
            self.assertFalse(ok)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_submit_passes_phase_c_unresolvable_bundle_kind(self):
        import phase_e_auto_report as pea

        lab = self._lab()
        captured = []

        def _collect(**kwargs):
            captured.append(
                {
                    "extra_meta": kwargs.get("extra_meta"),
                    "extra_files": kwargs.get("extra_files"),
                }
            )
            return os.path.join(lab, "bundle_out.zip")

        try:
            with patch("MediCafe.error_reporter.report_dedup_try_reserve", return_value=(True, None)):
                with patch("MediCafe.error_reporter.report_dedup_release_if_failed"):
                    with patch("MediCafe.error_reporter.collect_support_bundle", side_effect=_collect):
                        with patch("MediCafe.error_reporter.submit_support_bundle_email", return_value=True):
                            ok = pea.submit_phase_c_unresolvable_bundle(
                                lab,
                                {"run_id": "rid-u2", "lab_root": lab},
                            )
            self.assertTrue(ok)
            self.assertEqual(len(captured), 1)
            self.assertEqual(captured[0]["extra_meta"].get("bundle_kind"), "phase_c_unresolvable")
            self.assertEqual(captured[0]["extra_meta"].get("send_source"), "auto_phase_c_unresolvable")
            ef = captured[0]["extra_files"] or []
            names = [x[0] for x in ef]
            self.assertIn("phase_c_self_heal_status_latest.txt", names)
            self.assertIn("phase_c_remediation_history.json", names)
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
