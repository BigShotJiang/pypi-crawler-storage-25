# -*- coding: utf-8 -*-
"""Phase C circuit auto-reset (cooldown)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

import phase_c_self_heal_state as phase_c_self_heal_state  # noqa: E402

from phase_c_self_heal_state import (  # noqa: E402
    maybe_auto_reset_phase_c_circuit,
    sync_phase_c_subprocess_script_fingerprint_from_disk,
)


class TestCircuitAutoReset(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_ar_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_cooldown_clears_circuit(self):
        lab = self._lab()
        try:
            ver = "unknown"
            try:
                from MediCafe import __version__ as _v

                ver = str(_v or "").strip() or "unknown"
            except Exception:
                pass
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": ver,
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                        "phase_c_self_heal_failure_count_for_b_sha": 3,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertFalse(st.get("phase_c_circuit_open"))
            self.assertEqual(st.get("phase_c_self_heal_failure_count_for_b_sha"), 0)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_reset_when_circuit_closed(self):
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"version": 2, "phase_c_circuit_open": False}, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            self.assertFalse(maybe_auto_reset_phase_c_circuit(lab))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_reset_when_opened_at_invalid_iso_and_same_version(self):
        lab = self._lab()
        try:
            ver = "v-locked-for-test"
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": ver,
                        "phase_c_circuit_opened_at_utc": "not-an-iso-timestamp",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value=ver):
                self.assertFalse(maybe_auto_reset_phase_c_circuit(lab))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_no_reset_when_opened_in_future_relative_to_clock(self):
        lab = self._lab()
        try:
            ver = "v-same"
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": ver,
                        "phase_c_circuit_opened_at_utc": "2037-01-01T00:00:00Z",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value=ver):
                self.assertFalse(maybe_auto_reset_phase_c_circuit(lab))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_version_bump_resets_when_opened_version_stamp_missing(self):
        """Legacy circuit-open state without opened_at_medicafe_version still resets on deploy bump."""
        lab = self._lab()
        try:
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                        "phase_c_self_heal_failure_count_for_b_sha": 2,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value="v-post-deploy"):
                self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertFalse(st.get("phase_c_circuit_open"))
            self.assertEqual(st.get("phase_c_self_heal_failure_count_for_b_sha"), 0)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_version_bump_resets_even_when_opened_recently(self):
        lab = self._lab()
        try:
            manifest = os.path.join(lab, "reports", "pending_m.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write("{}\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "deploy-old",
                        "phase_c_circuit_opened_at_utc": "2035-06-01T00:00:00Z",
                        "phase_c_self_heal_failure_count_for_b_sha": 3,
                        "last_manifest_sha256": "old-state-canonical",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "pending-sha-9",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "old-canonical",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "pending-sha-9",
                    },
                    f,
                )
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value="deploy-new"):
                self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertFalse(cr.get("phase_c_circuit_open"))
            self.assertEqual(cr.get("last_manifest_sha256"), "pending-sha-9")
            self.assertEqual(cr.get("last_manifest_path"), manifest)
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertFalse(st.get("phase_c_circuit_open"))
            self.assertEqual(st.get("last_manifest_sha256"), "pending-sha-9")
            self.assertEqual(st.get("last_manifest_path"), manifest)
            self.assertEqual(st.get("last_discovery_pending_manifest_path"), "")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_auto_reset_skips_promotion_when_pending_sha_empty_but_file_exists(self):
        lab = self._lab()
        try:
            manifest = os.path.join(lab, "reports", "has_file.jsonl")
            with open(manifest, "w", encoding="utf-8") as f:
                f.write("{}\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "v-old",
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                        "last_manifest_sha256": "stay-state",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "stay-cursor",
                        "last_discovery_pending_manifest_path": manifest,
                        "last_discovery_pending_manifest_sha256": "",
                    },
                    f,
                )
            self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertEqual(st.get("last_manifest_sha256"), "stay-state")
            self.assertEqual(cr.get("last_manifest_sha256"), "stay-cursor")
            self.assertEqual(st.get("last_discovery_pending_manifest_path"), "")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_auto_reset_skips_promotion_when_pending_file_missing(self):
        lab = self._lab()
        try:
            missing = os.path.join(lab, "reports", "missing_manifest.jsonl")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "v-old",
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "phase_c_circuit_open": True,
                        "last_manifest_sha256": "stay-put",
                        "last_discovery_pending_manifest_path": missing,
                        "last_discovery_pending_manifest_sha256": "ghost-sha",
                    },
                    f,
                )
            self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertEqual(cr.get("last_manifest_sha256"), "stay-put")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_sync_fingerprint_from_disk_updates_stale_prefix(self):
        lab = self._lab()
        try:
            ingest = os.path.join(lab, "ingest_from_manifest.py")
            body = b"# fingerprint resync test\n"
            with open(ingest, "wb") as f:
                f.write(body)
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "last_phase_c_subprocess_script_path": ingest,
                        "last_phase_c_subprocess_script_sha256_prefix": "deadbeef00000000",
                        "last_phase_c_subprocess_script_size_bytes": 999,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            self.assertTrue(
                sync_phase_c_subprocess_script_fingerprint_from_disk(lab, "unit_test_stale_prefix")
            )
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            with open(cursor_path, "r", encoding="utf-8") as f:
                cr = json.load(f)
            self.assertNotEqual(st.get("last_phase_c_subprocess_script_sha256_prefix"), "deadbeef00000000")
            self.assertEqual(st.get("last_phase_c_subprocess_script_sha256_prefix"), cr.get("last_phase_c_subprocess_script_sha256_prefix"))
            self.assertEqual(st.get("last_phase_c_subprocess_script_size_bytes"), len(body))
            hist = st.get("phase_c_remediation_history") or []
            self.assertTrue(
                any(h.get("event") == "phase_c_subprocess_script_fingerprint_resync" for h in hist)
            )
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_sync_fingerprint_noop_when_prefix_matches_disk(self):
        lab = self._lab()
        try:
            ingest = os.path.join(lab, "ingest_from_manifest.py")
            body = b"# aligned\n"
            with open(ingest, "wb") as f:
                f.write(body)
            from phase_c_self_heal_state import _sha256_prefix16_and_size  # noqa: E402

            pref, sz = _sha256_prefix16_and_size(ingest)
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "last_phase_c_subprocess_script_path": ingest,
                        "last_phase_c_subprocess_script_sha256_prefix": pref,
                        "last_phase_c_subprocess_script_size_bytes": sz,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 1,
                        "last_phase_c_subprocess_script_path": ingest,
                        "last_phase_c_subprocess_script_sha256_prefix": pref,
                        "last_phase_c_subprocess_script_size_bytes": sz,
                    },
                    f,
                )
            self.assertFalse(
                sync_phase_c_subprocess_script_fingerprint_from_disk(lab, "unit_test_noop")
            )
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_circuit_auto_reset_resyncs_subprocess_script_fingerprint(self):
        lab = self._lab()
        try:
            ingest = os.path.join(lab, "ingest_from_manifest.py")
            with open(ingest, "wb") as f:
                f.write(b"v=circuit_reset_fp\n")
            state_path = os.path.join(lab, "diagnostics_state.json")
            cursor_path = os.path.join(lab, "run_cursor.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_circuit_open": True,
                        "phase_c_circuit_opened_at_medicafe_version": "v-old-fp",
                        "phase_c_circuit_opened_at_utc": "1999-01-01T00:00:00Z",
                        "last_phase_c_subprocess_script_path": ingest,
                        "last_phase_c_subprocess_script_sha256_prefix": "1111111111111111",
                        "last_phase_c_subprocess_script_size_bytes": 1,
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            with patch.object(phase_c_self_heal_state, "_medicafe_version_string", return_value="v-new-fp"):
                self.assertTrue(maybe_auto_reset_phase_c_circuit(lab))
            with open(state_path, "r", encoding="utf-8") as f:
                st = json.load(f)
            self.assertFalse(st.get("phase_c_circuit_open"))
            self.assertNotEqual(st.get("last_phase_c_subprocess_script_sha256_prefix"), "1111111111111111")
            hist = st.get("phase_c_remediation_history") or []
            self.assertTrue(any(h.get("event") == "circuit_auto_reset" for h in hist))
            self.assertTrue(
                any(h.get("event") == "phase_c_subprocess_script_fingerprint_resync" for h in hist)
            )
        finally:
            shutil.rmtree(lab, ignore_errors=True)
