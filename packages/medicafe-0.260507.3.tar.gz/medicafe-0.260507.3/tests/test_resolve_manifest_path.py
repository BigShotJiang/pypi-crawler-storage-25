# -*- coding: utf-8 -*-
"""resolve_manifest_path prefers pending Phase B manifest when circuit held canonical back."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

from ingest_from_manifest import resolve_manifest_path


class TestResolveManifestPath(unittest.TestCase):
    def test_prefers_pending_manifest_when_file_exists(self):
        lab_root = tempfile.mkdtemp(prefix="mc_rmp_")
        try:
            reports = os.path.join(lab_root, "reports")
            os.makedirs(reports)
            canonical = os.path.join(reports, "artifact_manifest_canon.jsonl")
            pending = os.path.join(reports, "artifact_manifest_pending.jsonl")
            with open(canonical, "w", encoding="utf-8") as f:
                f.write("{}\n")
            with open(pending, "w", encoding="utf-8") as f:
                f.write("{}\n")
            cursor = {
                "last_discovery_pending_manifest_path": pending,
                "last_manifest_path": canonical,
            }
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump(cursor, f)
            self.assertEqual(resolve_manifest_path(lab_root, None), pending)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_skips_pending_when_path_is_directory(self):
        lab_root = tempfile.mkdtemp(prefix="mc_rmp_dir_")
        try:
            reports = os.path.join(lab_root, "reports")
            os.makedirs(reports)
            canonical = os.path.join(reports, "artifact_manifest_canon.jsonl")
            pending_dir = os.path.join(reports, "pending_dir")
            os.makedirs(pending_dir)
            with open(canonical, "w", encoding="utf-8") as f:
                f.write("{}\n")
            cursor = {
                "last_discovery_pending_manifest_path": pending_dir,
                "last_manifest_path": canonical,
            }
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump(cursor, f)
            self.assertEqual(resolve_manifest_path(lab_root, None), canonical)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_falls_back_when_pending_missing_but_canonical_exists(self):
        lab_root = tempfile.mkdtemp(prefix="mc_rmp2_")
        try:
            reports = os.path.join(lab_root, "reports")
            os.makedirs(reports)
            canonical = os.path.join(reports, "artifact_manifest_canon.jsonl")
            with open(canonical, "w", encoding="utf-8") as f:
                f.write("{}\n")
            cursor = {
                "last_discovery_pending_manifest_path": os.path.join(reports, "nope.jsonl"),
                "last_manifest_path": canonical,
            }
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump(cursor, f)
            self.assertEqual(resolve_manifest_path(lab_root, None), canonical)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_cli_manifest_overrides_cursor(self):
        lab_root = tempfile.mkdtemp(prefix="mc_rmp3_")
        try:
            reports = os.path.join(lab_root, "reports")
            os.makedirs(reports)
            cli_path = os.path.join(reports, "cli_only.jsonl")
            pending = os.path.join(reports, "pending.jsonl")
            canonical = os.path.join(reports, "canonical.jsonl")
            for p in (cli_path, pending, canonical):
                with open(p, "w", encoding="utf-8") as f:
                    f.write("{}\n")
            cursor = {
                "last_discovery_pending_manifest_path": pending,
                "last_manifest_path": canonical,
            }
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump(cursor, f)
            self.assertEqual(resolve_manifest_path(lab_root, cli_path), cli_path)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
