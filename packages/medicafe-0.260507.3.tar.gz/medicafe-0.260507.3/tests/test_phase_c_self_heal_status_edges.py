# -*- coding: utf-8 -*-
"""Edge cases for MediCafe/phase_c_self_heal_status (format, shallow meta, writer)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)


class TestPhaseCSelfHealStatusEdges(unittest.TestCase):
    def _lab(self):
        root = tempfile.mkdtemp(prefix="mc_pc_sh_stat_")
        os.makedirs(os.path.join(root, "reports"), exist_ok=True)
        return root

    def test_format_empty_lab_root(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines

        lines = format_phase_c_self_heal_lines("")
        self.assertTrue(any("missing_lab_root" in ln for ln in lines))

    def test_format_circuit_open_only_on_cursor(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines

        lab = self._lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 2}, f)
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_circuit_open": True}, f)
            lines = format_phase_c_self_heal_lines(lab)
            self.assertTrue(any("circuit_open=yes" in ln for ln in lines))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_shallow_meta_prefers_state_over_cursor_for_failure_count(self):
        from MediCafe.phase_c_self_heal_status import shallow_phase_c_self_heal_meta

        lab = self._lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "phase_c_self_heal_failure_count_for_b_sha": 2,
                        "phase_c_last_self_heal_tier": "tier2",
                        "phase_c_last_self_heal_outcome": "done",
                    },
                    f,
                )
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1, "phase_c_self_heal_failure_count_for_b_sha": 99}, f)
            meta = shallow_phase_c_self_heal_meta(lab)
            self.assertEqual(meta.get("phase_c_attempts_for_current_b_sha"), 2)
            self.assertEqual(meta.get("phase_c_last_attempt_action"), "tier2")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_shallow_meta_non_int_failure_count_defaults_zero(self):
        from MediCafe.phase_c_self_heal_status import shallow_phase_c_self_heal_meta

        lab = self._lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {"version": 2, "phase_c_self_heal_failure_count_for_b_sha": "bogus"},
                    f,
                )
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            meta = shallow_phase_c_self_heal_meta(lab)
            self.assertEqual(meta.get("phase_c_attempts_for_current_b_sha"), 0)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_format_corrupt_diagnostics_falls_back_gracefully(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines

        lab = self._lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                f.write("{ not json")
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1, "last_manifest_sha256": "abc"}, f)
            lines = format_phase_c_self_heal_lines(lab)
            self.assertTrue(any("circuit_open=" in ln for ln in lines))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_format_long_sha_prefix_truncation(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines

        lab = self._lab()
        long_sha = "a" * 80
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "last_manifest_sha256": long_sha,
                        "phase_c_remediation_history": [{"event": "x" * 120, "at_utc": "t"}],
                    },
                    f,
                )
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            lines = format_phase_c_self_heal_lines(lab)
            tracked = [ln for ln in lines if "last_manifest_sha256_prefix=" in ln][0]
            self.assertIn("...", tracked)
            self.assertLessEqual(len(tracked), 120)
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_format_remediation_history_last_not_dict_skipped(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines

        lab = self._lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 2, "phase_c_remediation_history": ["not-a-dict", 123]}, f)
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            lines = format_phase_c_self_heal_lines(lab)
            self.assertFalse(any("last_remediation_event=" in ln for ln in lines))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_write_status_creates_reports_dir(self):
        from MediCafe.phase_c_self_heal_status import write_phase_c_self_heal_status_txt

        lab = tempfile.mkdtemp(prefix="mc_pc_sh_wr_")
        try:
            p = write_phase_c_self_heal_status_txt(lab)
            self.assertTrue(p)
            self.assertTrue(os.path.isfile(os.path.join(lab, "reports", "phase_c_self_heal_status_latest.txt")))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_write_status_custom_target(self):
        from MediCafe.phase_c_self_heal_status import write_phase_c_self_heal_status_txt

        lab = self._lab()
        try:
            target = os.path.join(lab, "custom_status.txt")
            p = write_phase_c_self_heal_status_txt(lab, target_path=target)
            self.assertEqual(p, target)
            self.assertTrue(os.path.isfile(target))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_cooldown_hours_env_reflected_in_next_action_line(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines

        lab = self._lab()
        try:
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 2}, f)
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1}, f)
            with patch.dict(os.environ, {"MEDICAFE_PHASE_C_CIRCUIT_COOLDOWN_HOURS": "6"}):
                lines = format_phase_c_self_heal_lines(lab)
            self.assertTrue(any("6h cooldown" in ln for ln in lines))
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_format_and_shallow_subprocess_drift_and_ingest_diag(self):
        import hashlib

        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines, shallow_phase_c_self_heal_meta

        lab = self._lab()
        sp = os.path.join(lab, "fake_ingest.py")
        try:
            with open(sp, "w", encoding="utf-8") as handle:
                handle.write("stable-bytes")
            h = hashlib.sha256()
            with open(sp, "rb") as handle:
                h.update(handle.read())
            pref = h.hexdigest()[:16]
            sz = os.path.getsize(sp)
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "version": 2,
                        "last_phase_c_subprocess_script_path": sp,
                        "last_phase_c_subprocess_script_sha256_prefix": pref,
                        "last_phase_c_subprocess_script_size_bytes": sz,
                    },
                    handle,
                )
            pdiag = os.path.join(lab, "reports", "ingest_from_manifest_diagnostics_latest.json")
            with open(pdiag, "w", encoding="utf-8") as handle:
                handle.write("{}")
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as handle:
                json.dump(
                    {
                        "version": 1,
                        "last_ingest_from_manifest_diag_path": pdiag,
                        "last_ingest_from_manifest_diag_at_utc": "2026-01-01T00:00:00Z",
                        "last_ingest_from_manifest_diag_run_id": "r-diag",
                    },
                    handle,
                )
            lines = format_phase_c_self_heal_lines(lab)
            self.assertTrue(any("phase_c_subprocess_script_drift=no" in ln for ln in lines))
            self.assertTrue(any("ingest_diag_present=yes" in ln for ln in lines))
            meta = shallow_phase_c_self_heal_meta(lab)
            self.assertEqual(meta.get("phase_c_subprocess_script_drift"), "no")
            self.assertTrue(meta.get("ingest_diag_present"))
            self.assertEqual(meta.get("last_ingest_from_manifest_diag_run_id"), "r-diag")
        finally:
            shutil.rmtree(lab, ignore_errors=True)

    def test_format_handoff_freshness_and_bootstrap_note(self):
        from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines, shallow_phase_c_self_heal_meta

        lab = self._lab()
        try:
            hp = os.path.join(lab, "reports", "phase_c_execution_handoff_x.json")
            with open(hp, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "schema_version": 1,
                        "pipeline_run_id": "x",
                        "generated_at_utc": "2026-01-01T00:00:00Z",
                        "snapshot_after": {
                            "last_manifest_sha256": "mb",
                            "last_ingest_manifest_sha256": "mc",
                        },
                    },
                    f,
                )
            with open(os.path.join(lab, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "version": 2,
                        "last_phase_c_execution_handoff_report_path": hp,
                        "last_manifest_sha256": "mb",
                        "last_ingest_manifest_sha256": "mc",
                    },
                    f,
                )
            with open(os.path.join(lab, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"version": 1, "active_run_id": "x"}, f)
            boot = os.path.join(lab, "reports", "ingest_from_manifest_bootstrap_latest.json")
            with open(boot, "w", encoding="utf-8") as f:
                json.dump({"stage": "early"}, f)
            current_attempt = os.path.join(lab, "reports", "phase_c_current_attempt_latest.json")
            with open(current_attempt, "w", encoding="utf-8") as f:
                json.dump({
                    "phase_c_attempt_id": "x-phase-c",
                    "last_reached_stage": "bootstrap",
                    "current_blocker": "phase_c_script_entered_but_no_finish_diag_current_attempt",
                }, f)
            lines = format_phase_c_self_heal_lines(lab)
            self.assertTrue(any("phase_c_handoff_freshness=" in ln for ln in lines))
            self.assertTrue(any("ingest_bootstrap_latest_present=yes" in ln for ln in lines))
            self.assertTrue(any("ingest_finish_diagnostics_latest_present=no" in ln for ln in lines))
            self.assertTrue(any("bootstrap sentinel" in ln for ln in lines))
            self.assertTrue(any("phase_c_current_attempt_present=yes" in ln for ln in lines))
            self.assertTrue(any("phase_c_current_attempt_last_reached_stage=bootstrap" in ln for ln in lines))
            meta = shallow_phase_c_self_heal_meta(lab)
            self.assertIn("phase_c_handoff_freshness", meta)
            self.assertEqual(str(meta.get("phase_c_handoff_comparison_run_id") or ""), "x")
            self.assertTrue(any("phase_c_handoff_comparison_run_id=" in ln for ln in lines))
            self.assertTrue(meta.get("ingest_bootstrap_latest_present"))
            self.assertFalse(meta.get("ingest_finish_diagnostics_latest_present"))
            self.assertTrue(meta.get("phase_c_current_attempt_present"))
            self.assertEqual(
                meta.get("phase_c_current_attempt_blocker"),
                "phase_c_script_entered_but_no_finish_diag_current_attempt",
            )
        finally:
            shutil.rmtree(lab, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
