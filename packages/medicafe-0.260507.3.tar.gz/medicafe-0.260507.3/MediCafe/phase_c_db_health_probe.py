# -*- coding: utf-8 -*-
"""
Read-only Phase C unified SQLite health probe (Python 3.4+).

Used by support-bundle evidence resolution and self-tests to detect obvious
DB integrity problems and ``ingest_artifact`` schema drift vs ingest expectations.
"""
from __future__ import print_function

import json
import os
import time

PHASE_C_DB_HEALTH_PROBE_SCHEMA_VERSION = 1

_INGEST_REQUIRED_COLS = frozenset(
    ("ingest_key", "source_system", "source_type", "source_ref", "payload_json", "ingest_status")
)


def _safe_str(value):
    if value is None:
        return ""
    try:
        return str(value).strip()
    except Exception:
        return ""


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception:
        return None
    return None


def resolve_unified_model_db_path(lab_root, diagnostics_state=None):
    """
    Prefer live ``db_path`` from ``phase_c_shadow_recovery`` in diagnostics when set;
    otherwise ``<lab_root>/unified_model_xp.db``.
    """
    root = _safe_str(lab_root)
    st = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    rec = st.get("phase_c_shadow_recovery")
    if isinstance(rec, dict):
        dbp = _safe_str(rec.get("db_path"))
        if dbp and os.path.isfile(dbp):
            return dbp
    if root:
        candidate = os.path.join(root, "unified_model_xp.db")
        return candidate
    return ""


def build_phase_c_db_health_probe(lab_root, diagnostics_state=None):
    """
    Return a JSON-serializable probe document (does not write files).

    ``drift_flags`` is a list of stable machine-readable codes; empty means no
    drift detected by this probe (integrity ok and ingest_artifact columns ok).
    """
    out = {
        "schema_version": PHASE_C_DB_HEALTH_PROBE_SCHEMA_VERSION,
        "generated_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "lab_root": _safe_str(lab_root),
        "db_path": "",
        "db_exists": False,
        "sqlite_lib_version": "",
        "integrity_check": "",
        "ingest_artifact_table_present": False,
        "ingest_artifact_required_columns_ok": False,
        "ingest_artifact_columns": [],
        "drift_flags": [],
        "probe_error": "",
    }
    try:
        import sqlite3
    except Exception as exc:
        out["probe_error"] = "sqlite3_import_failed:{0}".format(exc.__class__.__name__)
        out["drift_flags"].append("sqlite_unavailable")
        return out

    out["sqlite_lib_version"] = _safe_str(getattr(sqlite3, "sqlite_version", ""))

    db_path = resolve_unified_model_db_path(lab_root, diagnostics_state)
    out["db_path"] = db_path
    if not db_path:
        out["drift_flags"].append("db_path_unresolved")
        return out

    out["db_exists"] = os.path.isfile(db_path)
    if not out["db_exists"]:
        out["drift_flags"].append("db_file_missing")
        return out

    conn = None
    try:
        conn = sqlite3.connect(db_path, timeout=5.0)
        try:
            conn.execute("PRAGMA busy_timeout=5000")
        except Exception:
            pass
        cur = conn.execute("PRAGMA integrity_check")
        row = cur.fetchone()
        integrity = _safe_str(row[0]) if row else ""
        out["integrity_check"] = integrity
        if integrity.lower() != "ok":
            out["drift_flags"].append("integrity_check_failed")

        cur = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='ingest_artifact'"
        )
        out["ingest_artifact_table_present"] = cur.fetchone() is not None
        if not out["ingest_artifact_table_present"]:
            out["drift_flags"].append("ingest_artifact_missing")
        else:
            cur = conn.execute("PRAGMA table_info(ingest_artifact)")
            cols = []
            names = set()
            for r in cur.fetchall():
                if r and len(r) > 1:
                    cname = _safe_str(r[1])
                    cols.append(cname)
                    names.add(cname)
            out["ingest_artifact_columns"] = cols
            out["ingest_artifact_required_columns_ok"] = _INGEST_REQUIRED_COLS.issubset(names)
            if not out["ingest_artifact_required_columns_ok"]:
                out["drift_flags"].append("ingest_artifact_column_drift")
    except Exception as exc:
        out["probe_error"] = _safe_str("{0}:{1}".format(exc.__class__.__name__, exc))[:240]
        if "unable to open" in out["probe_error"].lower() or "not a database" in out["probe_error"].lower():
            out["drift_flags"].append("sqlite_open_or_format_failed")
        else:
            out["drift_flags"].append("sqlite_probe_exception")
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass

    return out


def write_phase_c_db_health_probe_latest(lab_root, diagnostics_state=None):
    """
    Write ``reports/phase_c_db_health_probe_latest.json`` under lab_root.

    Returns absolute path when written, else "".
    """
    root = _safe_str(lab_root)
    if not root or not os.path.isdir(root):
        return ""
    reports_dir = os.path.join(root, "reports")
    try:
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return ""

    doc = build_phase_c_db_health_probe(root, diagnostics_state)
    path = os.path.join(reports_dir, "phase_c_db_health_probe_latest.json")
    tmp_path = path + ".tmp"
    try:
        payload = json.dumps(doc, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
        with open(tmp_path, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except Exception:
                pass
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass
        os.rename(tmp_path, path)
        return path
    except Exception:
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        return ""
