#!/usr/bin/env python
"""
High-level API operation helpers extracted from MediCafe.api_core.

Each function syncs runtime globals from MediCafe.api_core at call time so
monkeypatches, shared module state, and compatibility shims remain anchored
to the public MediCafe.api_core module path.
"""
from __future__ import print_function

from functools import wraps


_LOCAL_HELPER_NAMES = set(['_api_core_module', '_sync_api_core_globals', '_with_api_core_globals'])


def _api_core_module():
    from MediCafe import api_core as _api
    return _api


def _sync_api_core_globals():
    api = _api_core_module()
    g = globals()
    for name, value in api.__dict__.items():
        if name in _LOCAL_HELPER_NAMES:
            continue
        g[name] = value


def _with_api_core_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_api_core_globals()
        return fn(*args, **kwargs)
    return _wrapped

@_with_api_core_globals
def get_claim_summary_by_provider(client, tin, first_service_date, last_service_date, payer_id, get_standard_error='false', transaction_id=None, env=None):
    """
    Unified Claims Inquiry that prefers OPTUMAI GraphQL searchClaim with
    legacy response mapping, and falls back to legacy UHCAPI REST endpoint
    to preserve current downstream flows and UI.
    """
    # Verbose input logging
    if DEBUG:
        MediLink_ConfigLoader.log("Claims Inquiry inputs: tin={} start={} end={} payer={} tx={}"
                                  .format(tin, first_service_date, last_service_date, payer_id, transaction_id),
                                  level="INFO")

    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)

    # Determine whether OPTUMAI is available/configured
    endpoints_cfg = medi.get('endpoints', {}) if isinstance(medi, dict) else {}
    optumai_cfg = endpoints_cfg.get('OPTUMAI', {}) if isinstance(endpoints_cfg, dict) else {}
    uhcapi_cfg = endpoints_cfg.get('UHCAPI', {}) if isinstance(endpoints_cfg, dict) else {}

    optumai_path = (optumai_cfg.get('additional_endpoints', {}) or {}).get('claims_inquiry')
    uhc_path = (uhcapi_cfg.get('additional_endpoints', {}) or {}).get('claim_summary_by_provider')

    optumai_api_url = optumai_cfg.get('api_url')
    use_optumai = bool(optumai_api_url and optumai_path)
    if optumai_cfg and optumai_api_url and not optumai_path:
        _log_fallback_once(
            'claims_inquiry_missing_path',
            "OPTUMAI claims inquiry not configured (missing additional_endpoints.claims_inquiry); falling back to UHCAPI.",
            level="WARNING"
        )
    elif optumai_cfg and optumai_path and not optumai_api_url:
        _log_fallback_once(
            'claims_inquiry_missing_api_url',
            "OPTUMAI claims inquiry configured but api_url missing; falling back to UHCAPI.",
            level="WARNING"
        )
    # Capability guard: disable OPTUMAI if required helpers are unavailable
    if use_optumai:
        graphql_enabled = bool(getattr(MediLink_GraphQL, 'GRAPHQL_AVAILABLE', True))
        has_build = hasattr(MediLink_GraphQL, 'build_optumai_claims_inquiry_request')
        has_transform = hasattr(MediLink_GraphQL, 'transform_claims_inquiry_response_to_legacy')
        if not (graphql_enabled and has_build and has_transform):
            _log_fallback_once(
                'claims_inquiry_missing_helpers',
                "Disabling OPTUMAI claims inquiry: GraphQL helpers unavailable/disabled. Falling back to UHCAPI.",
                level="WARNING"
            )
            use_optumai = False

    # Single routing layer: which endpoint should handle search_claim for this payer?
    payer_id_str = str(payer_id) if payer_id is not None else None
    if use_optumai and payer_id:
        route_endpoint, route_reason = resolve_operation_route(client, payer_id, 'search_claim')
        if route_endpoint != 'OPTUMAI':
            use_optumai = False
            # Pre-check reason mapping: route_reason None + UHCAPI -> unsupported_payer for OPTUMAI context
            if route_reason is None and route_endpoint == 'UHCAPI':
                pre_reason = UNSUPPORTED_PAYER
            elif route_reason in ('payer_not_supported', 'payer_not_in_defaults', 'feature_not_supported',
                                  'crosswalk_unavailable', 'search_277ca_not_supported_for_payer'):
                pre_reason = UNSUPPORTED_PAYER
            else:
                pre_reason = UNSUPPORTED_PAYER
            pre_hint = next_step_hint(pre_reason) if next_step_hint else "Check logs for details."
            if classify_routing_reason:
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', pre_reason, 'UHCAPI', pre_hint)
            if route_reason and 'not_supported' in str(route_reason):
                MediLink_ConfigLoader.log(
                    "Skipping OPTUMAI claims inquiry due to Search Claim=N for payer {}; using UHCAPI.".format(payer_id),
                    level="INFO"
                )
            elif route_reason:
                MediLink_ConfigLoader.log(
                    "Claims inquiry: routing for payer {} -> {} ({}); using UHCAPI.".format(
                        payer_id, route_endpoint or 'none', route_reason),
                    level="WARNING"
                )

    # Suppression check: skip OPTUMAI if we've previously observed suppressible failures for this payer/context
    try:
        if use_optumai and payer_id_str:
            suppressed, cached_reason, cached_hint = _check_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN)
            if suppressed:
                use_optumai = False
                hint = cached_hint or (next_step_hint(cached_reason) if next_step_hint else "Check logs for details.")
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', cached_reason, 'UHCAPI', hint)
    except Exception:
        pass

    # Build OPTUMAI GraphQL request if configured
    if use_optumai:
        try:
            # Use centralized header builder (normalizes TIN and adds all required headers)
            headers = build_optumai_headers(client.config, api_url=optumai_api_url, next_page_token=transaction_id)

            # Build searchClaimInput per partial swagger
            # Per Claims_Inquiry spec: serviceStartDate/serviceEndDate are "Conditional. Required for search by member data or provider TIN"
            search_claim_input = {
                'payerId': str(payer_id)
            }
            # Map dates MM/DD/YYYY -> expected strings for GraphQL (examples show MM/DD/YYYY and also 01/01/2025)
            # Service dates are required for provider TIN search per spec
            if first_service_date:
                search_claim_input['serviceStartDate'] = first_service_date
            else:
                # Log warning if service dates missing for provider TIN search
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_PROVIDER_SEARCH] WARNING: serviceStartDate missing for provider TIN search (payerId={}) - may cause API errors".format(payer_id),
                    level="WARNING"
                )
            if last_service_date:
                search_claim_input['serviceEndDate'] = last_service_date
            else:
                # Log warning if service dates missing for provider TIN search
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_PROVIDER_SEARCH] WARNING: serviceEndDate missing for provider TIN search (payerId={}) - may cause API errors".format(payer_id),
                    level="WARNING"
                )

            # DEBUG: Log request telemetry
            if DEBUG:
                # Mask provider TIN for security (show first 5 digits, mask last 4)
                provider_tin_masked = 'unknown'
                if headers and 'providerTaxId' in headers:
                    tin_val = str(headers.get('providerTaxId', ''))
                    if len(tin_val) >= 5:
                        provider_tin_masked = tin_val[:5] + '****'
                    else:
                        provider_tin_masked = '****'
                
                # Mask correlation ID (show first 8 chars)
                corr_id_masked = 'unknown'
                if headers and 'x-optum-consumer-correlation-id' in headers:
                    corr_val = str(headers.get('x-optum-consumer-correlation-id', ''))
                    if len(corr_val) >= 8:
                        corr_id_masked = corr_val[:8] + '...'
                    else:
                        corr_id_masked = corr_val
                
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: payerId={}, serviceStartDate={}, serviceEndDate={}, providerTaxId={}, transactionId={}, correlationId={}".format(
                        payer_id, first_service_date or 'None', last_service_date or 'None',
                        provider_tin_masked, transaction_id or 'None', corr_id_masked
                    ),
                    level="DEBUG"
                )

            # Build GraphQL body
            graphql_body = MediLink_GraphQL.build_optumai_claims_inquiry_request(search_claim_input)

            # DEBUG: Log GraphQL request structure
            if DEBUG:
                operation_name = graphql_body.get('operationName', 'unknown')
                query_length = len(str(graphql_body.get('query', '')))
                variables_summary = 'present' if graphql_body.get('variables') else 'missing'
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] REQUEST: GraphQL operationName={}, queryLength={}, variables={}".format(
                        operation_name, query_length, variables_summary
                    ),
                    level="DEBUG"
                )

            # Make the call
            response = client.make_api_call('OPTUMAI', 'POST', optumai_path, params=None, data=graphql_body, headers=headers)

            # DEBUG: Log raw HTTP response structure
            if DEBUG:
                response_type = type(response).__name__
                has_data = isinstance(response, dict) and 'data' in response
                has_errors = isinstance(response, dict) and 'errors' in response
                response_keys = list(response.keys()) if isinstance(response, dict) else []
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] RESPONSE: responseType={}, hasData={}, hasErrors={}, responseKeys={}".format(
                        response_type, has_data, has_errors, response_keys[:10] if len(response_keys) > 10 else response_keys
                    ),
                    level="DEBUG"
                )

            # Transform to legacy format
            transformed = MediLink_GraphQL.transform_claims_inquiry_response_to_legacy(response)
            status = transformed.get('statuscode') if isinstance(transformed, dict) else None
            claims = transformed.get('claims', []) if isinstance(transformed, dict) else []
            claims_count = len(claims) if isinstance(claims, list) else 0
            message = transformed.get('message', '') if isinstance(transformed, dict) else ''
            next_page_token = transformed.get('transactionId') if isinstance(transformed, dict) else None
            
            if status == '200':
                # INFO: Log success scenario
                if claims_count > 0:
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_CLAIMS_INQUIRY] SUCCESS: payerId={}, claimsCount={}, hasMoreRecords={}, nextPageToken={}, statuscode={}".format(
                            payer_id, claims_count, 'true' if next_page_token else 'false',
                            'present' if next_page_token else 'None', status
                        ),
                        level="INFO"
                    )
                else:
                    # INFO: Log no-data scenario (successful response but empty claims)
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_CLAIMS_INQUIRY] NO_DATA: payerId={}, dateRange={} to {}, statuscode={}, message=\"{}\", claimsArrayLength={}".format(
                            payer_id, first_service_date or 'None', last_service_date or 'None',
                            status, message, claims_count
                        ),
                        level="INFO"
                    )
                
                # Add note so UI can message that Optum Real is active (non-breaking)
                try:
                    transformed['data_source'] = 'OPTUMAI'
                except Exception:
                    pass
                return transformed
            
            # WARNING: Log non-200 status with error details
            error_code = 'unknown'
            error_description = message
            trace_id = 'unknown'
            
            # Try to extract error details from raw GraphQL response
            if isinstance(transformed, dict) and 'rawGraphQLResponse' in transformed:
                raw_resp = transformed.get('rawGraphQLResponse', {})
                if isinstance(raw_resp, dict) and 'errors' in raw_resp:
                    errors = raw_resp.get('errors', [])
                    if errors and isinstance(errors[0], dict):
                        first_error = errors[0]
                        error_code = first_error.get('code', first_error.get('extensions', {}).get('code', 'unknown'))
                        error_description = first_error.get('description', first_error.get('message', message))
                        trace_id = first_error.get('extensions', {}).get('traceId', 'unknown')
            
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] ERROR: payerId={}, statuscode={}, errorCode={}, errorDescription=\"{}\", traceId={}".format(
                    payer_id, status or 'unknown', error_code, error_description[:200] if error_description else 'no message', trace_id
                ),
                level="WARNING"
            )

            # Classify, suppress if applicable, log structured decision once
            if classify_routing_reason:
                reason_code, hint = classify_routing_reason(
                    None, status_code=status, error_code=error_code, error_description=error_description)
                if is_suppressible and is_suppressible(reason_code):
                    _add_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, reason_code)
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', reason_code, 'UHCAPI', hint)
            elif _optumai_error_indicates_member_required(error_code, error_description):
                _add_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, MEMBER_REQUIRED)
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', MEMBER_REQUIRED, 'UHCAPI',
                    next_step_hint(MEMBER_REQUIRED) if next_step_hint else "Use member-level search.")
             
            # DEBUG: Log full transformed response structure for non-200 cases
            if DEBUG:
                response_snippet = str(transformed)[:500] if transformed else 'None'
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] ERROR: Full response snippet (first 500 chars): {}".format(response_snippet),
                    level="DEBUG"
                )
            
            # INFO: Log fallback trigger
            MediLink_ConfigLoader.log(
                "[OPTUMAI_CLAIMS_INQUIRY] FALLBACK: reason=\"Non-200 status\", optumaiStatus={}, fallingBackTo=UHCAPI".format(
                    status or 'unknown'
                ),
                level="INFO"
            )
            
            MediLink_ConfigLoader.log(
                "OPTUMAI Claims Inquiry returned status {} ({}). Falling back to UHCAPI.".format(
                    status or 'unknown',
                    message if message else 'no message'
                ),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
            # If not 200, fall through to UHC fallback when permitted
        except Exception as e:
            # If capability guard failed upstream for any reason, handle missing attribute gracefully here too
            error_type = type(e).__name__
            error_msg = str(e)

            if classify_routing_reason:
                reason_code, hint = classify_routing_reason(e)
                if is_suppressible and is_suppressible(reason_code):
                    _add_suppression(payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, reason_code)
                _log_routing_decision_once(
                    payer_id_str, QUERY_CONTEXT_PROVIDER_TIN, 'OPTUMAI', reason_code, 'UHCAPI', hint)

            if isinstance(e, AttributeError):
                fallback_reason = "Missing GraphQL helpers"
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] FALLBACK: reason=\"{}\", fallingBackTo=UHCAPI".format(fallback_reason),
                    level="INFO"
                )
                MediLink_ConfigLoader.log(
                    "OPTUMAI disabled due to missing GraphQL helpers; falling back to UHCAPI.",
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
            else:
                fallback_reason = "Exception: {} ({})".format(error_type, error_msg[:100])
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_CLAIMS_INQUIRY] FALLBACK: reason=\"{}\", exceptionType={}, fallingBackTo=UHCAPI".format(
                        fallback_reason, error_type
                    ),
                    level="INFO"
                )
                MediLink_ConfigLoader.log(
                    "OPTUMAI Claims Inquiry failed: {}. Falling back to UHCAPI.".format(e),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )

    # Fallback to existing UHC REST behavior to preserve current flows
    endpoint_name = 'UHCAPI'
    url_extension = uhc_path or ''

    if DEBUG:
        MediLink_ConfigLoader.log("Falling back to UHCAPI claim_summary_by_provider path: {}".format(url_extension), level="INFO")

    # Normalize TIN to digits-only per swagger (Facility/Tax ID). Examples use "12345678".
    # OPTUMAI uses normalized providerTaxId; UHCAPI should match to avoid "No Data" from format mismatch.
    tin_normalized = normalize_provider_tin(tin) if tin else None
    tin_for_headers = tin_normalized if tin_normalized else str(tin).strip() if tin else ''

    headers = {
        'tin': tin_for_headers,
        'firstServiceDt': first_service_date,
        'lastServiceDt': last_service_date,
        'payerId': payer_id,
        'getStandardError': get_standard_error,
        'Accept': 'application/json'
    }
    if transaction_id:
        headers['transactionId'] = transaction_id

    return client.make_api_call(endpoint_name, 'GET', url_extension, params=None, data=None, headers=headers)

@_with_api_core_globals
def get_claim_status_by_member_data(client, payer_id, member_id=None, member_first_name=None, 
                                    member_last_name=None, member_dob=None, service_start_date=None, 
                                    service_end_date=None, patient_account_number=None):
    """
    Get claim status via OPTUMAI using member data (for post-submission lookups).
    
    Searches for claims using member information before claim number is assigned.
    Validates member data combinations per OPTUMAI spec requirements.
    
    Args:
        client: API client instance
        payer_id: Payer ID (required)
        member_id: Member ID (conditional)
        member_first_name: Member first name (conditional)
        member_last_name: Member last name (conditional)
        member_dob: Member DOB in MM/DD/YYYY format (conditional)
        service_start_date: Service start date in MM/DD/YYYY (optional)
        service_end_date: Service end date in MM/DD/YYYY (optional)
        patient_account_number: Patient account number (optional)
    
    Returns:
        dict: Legacy-compatible response format with claims, statuscode, message
    """
    # Log the request
    if DEBUG:
        MediLink_ConfigLoader.log(
            "[OPTUMAI_MEMBER_LOOKUP] Starting member-based claim search: payerId={}, memberId={}, name={} {}, dob={}".format(
                payer_id, member_id or 'None', member_first_name or '', member_last_name or '', member_dob or 'None'
            ),
            level="DEBUG"
        )
    
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    
    # Get endpoint configuration
    endpoints_cfg = medi.get('endpoints', {}) if isinstance(medi, dict) else {}
    optumai_cfg = endpoints_cfg.get('OPTUMAI', {}) if isinstance(endpoints_cfg, dict) else {}
    uhcapi_cfg = endpoints_cfg.get('UHCAPI', {}) if isinstance(endpoints_cfg, dict) else {}
    
    optumai_api_url = optumai_cfg.get('api_url')
    claims_inquiry_path = (optumai_cfg.get('additional_endpoints', {}) or {}).get('claims_inquiry')
    uhcapi_api_url = uhcapi_cfg.get('api_url')
    uhc_member_path = (uhcapi_cfg.get('additional_endpoints', {}) or {}).get('claim_summary_by_member')
    
    use_optumai = bool(optumai_api_url and claims_inquiry_path)
    if optumai_cfg and optumai_api_url and not claims_inquiry_path:
        _log_fallback_once(
            'member_claims_inquiry_missing_path',
            "OPTUMAI claims inquiry not configured (missing additional_endpoints.claims_inquiry); falling back to UHCAPI.",
            level="WARNING"
        )
    elif optumai_cfg and claims_inquiry_path and not optumai_api_url:
        _log_fallback_once(
            'member_claims_inquiry_missing_api_url',
            "OPTUMAI claims inquiry configured but api_url missing; falling back to UHCAPI.",
            level="WARNING"
        )
    
    # Single routing layer: skip OPTUMAI if payer does not support search_claim
    if use_optumai and payer_id:
        try:
            route_endpoint, route_reason = resolve_operation_route(client, payer_id, 'search_claim')
            if route_endpoint != 'OPTUMAI':
                use_optumai = False
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] Payer {} does not support search_claim on OPTUMAI ({}); using UHCAPI.".format(
                        payer_id, route_reason or 'unknown'),
                    level="WARNING"
                )
        except Exception as e:
            use_optumai = False
            MediLink_ConfigLoader.log(
                "[OPTUMAI_MEMBER_LOOKUP] Routing check failed ({}); using UHCAPI.".format(e),
                level="WARNING"
            )
    
    optumai_result = None
    if use_optumai:
        # Build full URL
        if claims_inquiry_path.startswith('http'):
            claims_inquiry_url = claims_inquiry_path
        else:
            claims_inquiry_url = optumai_api_url.rstrip('/') + '/' + claims_inquiry_path.lstrip('/')

        # Build headers using centralized builder (normalizes TIN and adds all required headers)
        headers = build_optumai_headers(client.config, api_url=optumai_api_url)

        # Build GraphQL request using member data
        # Per Claims_Inquiry spec: serviceStartDate/serviceEndDate are "Conditional. Required for search by member data or provider TIN"
        # Some payers (e.g., 87726) require service dates even for member data searches
        try:
            from MediCafe.graphql_utils import GraphQLQueryBuilder, transform_claims_inquiry_response_to_legacy
        except Exception as e:
            use_optumai = False
            MediLink_ConfigLoader.log(
                "[OPTUMAI_MEMBER_LOOKUP] GraphQL helpers unavailable ({}). Falling back to UHCAPI.".format(e),
                level="WARNING"
            )
        else:
            if not hasattr(GraphQLQueryBuilder, 'build_optumai_search_claim_by_member_request'):
                use_optumai = False
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] Missing GraphQL builder for member lookup. Falling back to UHCAPI.",
                    level="WARNING"
                )

        if use_optumai:
            input_dict = {
                'payerId': payer_id
            }
            if member_id:
                input_dict['memberId'] = member_id
            if member_first_name:
                input_dict['memberFirstName'] = member_first_name
            if member_last_name:
                input_dict['memberLastName'] = member_last_name
            if member_dob:
                input_dict['memberDateOfBirth'] = member_dob
            # Always include service dates when available (required by some payers for member data search)
            if service_start_date:
                input_dict['serviceStartDate'] = service_start_date
            if service_end_date:
                input_dict['serviceEndDate'] = service_end_date

            # Log if service dates are missing for member data search (some payers require them)
            if not service_start_date or not service_end_date:
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] INFO: service dates missing for member data search (payerId={}, hasStart={}, hasEnd={}) - some payers may require service dates".format(
                        payer_id, bool(service_start_date), bool(service_end_date)
                    ),
                    level="INFO"
                )

            # DEBUG: Log the complete input_dict being sent (mask sensitive member data)
            if DEBUG:
                masked_input = input_dict.copy()
                if 'memberId' in masked_input and masked_input['memberId']:
                    member_id_val = str(masked_input['memberId'])
                    if len(member_id_val) > 5:
                        masked_input['memberId'] = member_id_val[:5] + '***'
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] DEBUG: Input dict being sent: {}".format(masked_input),
                    level="DEBUG"
                )

            if patient_account_number:
                input_dict['patientAccountNumber'] = patient_account_number

            try:
                graphql_request = GraphQLQueryBuilder.build_optumai_search_claim_by_member_request(input_dict)
            except ValueError as e:
                MediLink_ConfigLoader.log(
                    "[OPTUMAI_MEMBER_LOOKUP] Validation error: {}".format(e),
                    level="ERROR"
                )
                graphql_request = None

            if graphql_request:
                # Log GraphQL request structure
                if DEBUG:
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_MEMBER_LOOKUP] GraphQL request: operation={}, variables={}".format(
                            graphql_request.get('operationName'), graphql_request.get('variables', {})
                        ),
                        level="DEBUG"
                    )

                # Make API call
                endpoint_name = 'OPTUMAI'
                try:
                    response = client.make_api_call(
                        endpoint_name, 'POST', claims_inquiry_url,
                        data=json.dumps(graphql_request), headers=headers
                    )

                    # Transform to legacy format
                    transformed = transform_claims_inquiry_response_to_legacy(response)

                    # Add metadata
                    transformed['data_source'] = 'OPTUMAI'
                    transformed['lookup_type'] = 'member_data'

                    # Log result
                    claims_count = len(transformed.get('claims', [])) if isinstance(transformed, dict) else 0
                    if DEBUG:
                        MediLink_ConfigLoader.log(
                            "[OPTUMAI_MEMBER_LOOKUP] RESULT: statuscode={}, claimsCount={}".format(
                                transformed.get('statuscode') if isinstance(transformed, dict) else 'unknown',
                                claims_count
                            ),
                            level="INFO"
                        )

                    optumai_result = transformed
                    if isinstance(transformed, dict) and transformed.get('claims'):
                        return transformed

                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_MEMBER_LOOKUP] FALLBACK: No claims found via OPTUMAI; attempting UHCAPI.",
                        level="INFO"
                    )

                except Exception as e:
                    MediLink_ConfigLoader.log(
                        "[OPTUMAI_MEMBER_LOOKUP] ERROR: {}. Falling back to UHCAPI.".format(e),
                        level="WARNING"
                    )

    # Fallback to UHCAPI member summary
    if not uhcapi_api_url or not uhc_member_path:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] WARNING: UHCAPI claim_summary_by_member not configured; fallback unavailable.",
            level="WARNING"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback unavailable)".format(
                optumai_result.get('message', 'No claims found')
            )
            return optumai_result
        return {
            'statuscode': '500',
            'message': 'UHCAPI claim summary by member not configured',
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    # Build UHCAPI request body
    try:
        uhc_request = _build_uhcapi_member_search_request(
            member_id, member_first_name, member_last_name, member_dob,
            service_start_date, service_end_date, patient_account_number
        )
    except ValueError as e:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] Validation error: {}".format(e),
            level="WARNING"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback validation failed: {})".format(
                optumai_result.get('message', 'No claims found'), str(e)
            )
            return optumai_result
        return {
            'statuscode': '400',
            'message': 'UHCAPI member lookup validation error: {}'.format(str(e)),
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    # Resolve provider TIN for UHCAPI headers
    provider_tin_raw = medi.get('billing_provider_tin')
    if not provider_tin_raw:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: billing_provider_tin missing from configuration",
            level="ERROR"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback unavailable: missing provider TIN)".format(
                optumai_result.get('message', 'No claims found')
            )
            return optumai_result
        return {
            'statuscode': '500',
            'message': 'Provider TIN not found in configuration',
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    tin_normalized = normalize_provider_tin(provider_tin_raw)
    tin_for_headers = tin_normalized if tin_normalized else str(provider_tin_raw).strip()
    if not tin_for_headers:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: provider TIN could not be normalized",
            level="ERROR"
        )
        if isinstance(optumai_result, dict):
            optumai_result['message'] = "{} (UHCAPI fallback unavailable: invalid provider TIN)".format(
                optumai_result.get('message', 'No claims found')
            )
            return optumai_result
        return {
            'statuscode': '500',
            'message': 'Provider TIN invalid for UHCAPI request',
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

    headers = {
        'tin': tin_for_headers,
        'payerId': payer_id,
        'getStandardError': 'false',
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }

    # DEBUG: Log UHCAPI request (mask sensitive data)
    if DEBUG:
        masked_request = uhc_request.copy() if isinstance(uhc_request, dict) else {}
        if masked_request.get('memberId'):
            member_id_val = str(masked_request.get('memberId'))
            if len(member_id_val) > 5:
                masked_request['memberId'] = member_id_val[:5] + '***'
        if masked_request.get('patientDob'):
            dob_val = str(masked_request.get('patientDob'))
            if len(dob_val) > 4:
                masked_request['patientDob'] = dob_val[:4] + '****'
        tin_masked = tin_for_headers[:5] + '****' if len(tin_for_headers) >= 5 else '****'
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] REQUEST: payerId={}, tin={}, body={}".format(
                payer_id, tin_masked, masked_request
            ),
            level="DEBUG"
        )

    try:
        response = client.make_api_call(
            'UHCAPI', 'POST', uhc_member_path, params=None, data=uhc_request, headers=headers
        )

        transformed = _transform_uhcapi_member_response_to_legacy(response)
        transformed['data_source'] = 'UHCAPI'
        transformed['lookup_type'] = 'member_data'

        claims_count = len(transformed.get('claims', [])) if isinstance(transformed, dict) else 0
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] RESULT: statuscode={}, claimsCount={}".format(
                transformed.get('statuscode') if isinstance(transformed, dict) else 'unknown',
                claims_count
            ),
            level="INFO"
        )

        return transformed
    except Exception as e:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: {}".format(e),
            level="ERROR"
        )
        return {
            'statuscode': '500',
            'message': 'UHCAPI member lookup failed: {}'.format(str(e)),
            'claims': [],
            'data_source': 'UHCAPI',
            'lookup_type': 'member_data'
        }

@_with_api_core_globals
def _build_uhcapi_member_search_request(member_id, member_first_name, member_last_name, member_dob,
                                        service_start_date, service_end_date, patient_account_number=None):
    """
    Build UHCAPI SummaryByMemberRequest payload from member data inputs.
    """
    missing_dates = []
    if not service_start_date:
        missing_dates.append('firstSrvcDt')
    if not service_end_date:
        missing_dates.append('lastSrvcDt')
    if missing_dates:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] WARNING: Missing required service dates: {}".format(", ".join(missing_dates)),
            level="WARNING"
        )
        raise ValueError("UHCAPI requires service dates (firstSrvcDt/lastSrvcDt)")

    valid_combo = (
        (member_id and member_dob) or
        (member_id and member_first_name and member_last_name) or
        (member_first_name and member_last_name and member_dob)
    )
    if not valid_combo:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] WARNING: Invalid member search combination",
            level="WARNING"
        )
        raise ValueError("Invalid member data combination for UHCAPI search")

    if patient_account_number:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] INFO: patientAccountNumber provided but not supported by UHCAPI member search",
            level="INFO"
        )

    body = {
        'firstSrvcDt': service_start_date,
        'lastSrvcDt': service_end_date
    }
    if member_id:
        body['memberId'] = member_id
    if member_first_name:
        body['patientFn'] = member_first_name
    if member_last_name:
        body['patientLn'] = member_last_name
    if member_dob:
        body['patientDob'] = member_dob
    return body

@_with_api_core_globals
def _transform_uhcapi_member_response_to_legacy(uhc_response):
    """
    Transform UHCAPI SummaryByMember response into legacy claims summary format.
    """
    try:
        if not isinstance(uhc_response, dict):
            return {
                'statuscode': '500',
                'message': 'Invalid UHCAPI response format',
                'claims': [],
                'rawUHCResponse': uhc_response
            }

        # Handle error shapes
        errors = None
        if isinstance(uhc_response.get('errors'), list) and uhc_response.get('errors'):
            errors = uhc_response.get('errors')
        elif isinstance(uhc_response.get('error'), dict):
            nested_errors = uhc_response.get('error', {}).get('errors')
            if isinstance(nested_errors, list) and nested_errors:
                errors = nested_errors

        if errors:
            first_error = errors[0] if isinstance(errors, list) else errors
            error_code = first_error.get('code') if isinstance(first_error, dict) else 'error'
            error_msg = first_error.get('message') if isinstance(first_error, dict) else str(first_error)
            message = "{}{}".format(error_code + ": " if error_code else "", error_msg or "UHCAPI error")
            return {
                'statuscode': '400',
                'message': message,
                'claims': [],
                'rawUHCResponse': uhc_response
            }

        claims = uhc_response.get('claims') or []
        legacy_claims = []
        if isinstance(claims, list):
            for claim in claims:
                member = claim.get('memberInfo') or {}
                summary = claim.get('claimSummary') or {}
                legacy_claims.append({
                    'claimNumber': claim.get('claimNumber'),
                    'claimStatus': claim.get('claimStatus'),
                    'memberInfo': {
                        'ptntFn': member.get('ptntFn'),
                        'ptntLn': member.get('ptntLn')
                    },
                    'claimSummary': {
                        'processedDt': summary.get('processedDt') or '',
                        'firstSrvcDt': summary.get('firstSrvcDt') or '',
                        'totalChargedAmt': summary.get('totalChargedAmt') or '',
                        'totalAllowdAmt': summary.get('totalAllowdAmt') or '',
                        'totalPaidAmt': summary.get('totalPaidAmt') or '',
                        'totalPtntRespAmt': summary.get('totalPtntRespAmt') or '',
                        'clmXWalkData': summary.get('clmXWalkData') or []
                    }
                })

        pagination = uhc_response.get('pagination') or {}
        has_more = bool(pagination.get('hasMore')) if isinstance(pagination, dict) else False
        transaction_id = pagination.get('transactionId') if has_more else None

        return {
            'statuscode': '200',
            'message': 'Claims found' if legacy_claims else 'No claims found',
            'claims': legacy_claims,
            'transactionId': transaction_id,
            'rawUHCResponse': uhc_response
        }
    except Exception as e:
        MediLink_ConfigLoader.log(
            "[UHCAPI_MEMBER_LOOKUP] ERROR: Failed to transform response: {}".format(e),
            level="ERROR"
        )
        return {
            'statuscode': '500',
            'message': 'Error transforming UHCAPI response: {}'.format(str(e)),
            'claims': [],
            'rawUHCResponse': uhc_response
        }

@_with_api_core_globals
def get_claim_status_by_submission_context(client, transaction_id=None, payer_id=None, 
                                           member_id=None, member_first_name=None, 
                                           member_last_name=None, member_dob=None,
                                           service_start_date=None, service_end_date=None,
                                           patient_account_number=None, lookup_type='both'):
    """
    Unified function for post-submission claim status lookups.
    
    Supports multiple lookup types:
    - 277CA lookup via transactionId (immediate confirmation after submission)
    - Claim status lookup via member data (before claim number assigned)
    - Combined lookup (both 277CA and status)
    
    Args:
        client: API client instance
        transaction_id: Transaction ID from claim submission (optional)
        payer_id: Payer ID (required for all lookups)
        member_id: Member ID (conditional for member lookup)
        member_first_name: Member first name (conditional for member lookup)
        member_last_name: Member last name (conditional for member lookup)
        member_dob: Member DOB in MM/DD/YYYY format (conditional for member lookup)
        service_start_date: Service start date in MM/DD/YYYY (optional)
        service_end_date: Service end date in MM/DD/YYYY (optional)
        patient_account_number: Patient account number (optional)
        lookup_type: Type of lookup to perform ('277ca', 'member_data', 'both')
    
    Returns:
        dict: Combined response with:
            - lookup_type: Type of lookup performed
            - ack_277ca: 277CA response (if requested and available)
            - claim_status: Claim status response (if requested and available)
            - statuscode: Overall status
            - message: Overall message
    """
    if DEBUG:
        MediLink_ConfigLoader.log(
            "[SUBMISSION_CONTEXT_LOOKUP] Starting lookup: type={}, transactionId={}, payerId={}, memberId={}".format(
                lookup_type, transaction_id or 'None', payer_id or 'None', member_id or 'None'
            ),
            level="INFO"
        )
    
    result = {
        'lookup_type': lookup_type,
        'ack_277ca': None,
        'claim_status': None,
        'statuscode': '000',
        'message': '',
    }
    
    # Perform 277CA lookup if requested
    if lookup_type in ['277ca', 'both'] and transaction_id and payer_id:
        try:
            from MediCafe.claim_actions_adapter import search_277ca_via_optumai
            
            ack_response = search_277ca_via_optumai(client, transaction_id, payer_id)
            result['ack_277ca'] = ack_response
            
            if DEBUG:
                MediLink_ConfigLoader.log(
                    "[SUBMISSION_CONTEXT_LOOKUP] 277CA lookup complete: statuscode={}".format(
                        ack_response.get('statuscode', 'unknown')
                    ),
                    level="INFO"
                )
                
        except Exception as e:
            MediLink_ConfigLoader.log(
                "[SUBMISSION_CONTEXT_LOOKUP] 277CA lookup failed: {}".format(e),
                level="WARNING"
            )
            result['ack_277ca'] = {
                'statuscode': '500',
                'message': 'Error retrieving 277CA: {}'.format(str(e))
            }
    
    # Perform member data lookup if requested
    if lookup_type in ['member_data', 'both'] and payer_id:
        # Check if we have sufficient member data
        has_member_data = (
            (member_id and member_dob) or
            (member_id and member_first_name and member_last_name) or
            (member_first_name and member_last_name and member_dob)
        )
        
        if has_member_data:
            try:
                claim_response = get_claim_status_by_member_data(
                    client, payer_id, member_id, member_first_name,
                    member_last_name, member_dob, service_start_date,
                    service_end_date, patient_account_number
                )
                result['claim_status'] = claim_response
                
                if DEBUG:
                    claims_count = len(claim_response.get('claims', []))
                    MediLink_ConfigLoader.log(
                        "[SUBMISSION_CONTEXT_LOOKUP] Member data lookup complete: {} claims found".format(claims_count),
                        level="INFO"
                    )
                    
            except Exception as e:
                MediLink_ConfigLoader.log(
                    "[SUBMISSION_CONTEXT_LOOKUP] Member data lookup failed: {}".format(e),
                    level="WARNING"
                )
                result['claim_status'] = {
                    'statuscode': '500',
                    'message': 'Error retrieving claim status: {}'.format(str(e)),
                    'claims': []
                }
        else:
            MediLink_ConfigLoader.log(
                "[SUBMISSION_CONTEXT_LOOKUP] Insufficient member data for claim status lookup",
                level="WARNING"
            )
    
    # Determine overall status
    # OPTUMAI legacy adapters may return success as either '000' or HTTP-like '200'.
    # Treat both as success to avoid false negatives when 277CA retrieval succeeded.
    optumai_success_status_codes = ('000', '200')
    if result['ack_277ca'] or result['claim_status']:
        # Set overall status based on results
        ack_obj = result.get('ack_277ca') or {}
        claim_obj = result.get('claim_status') or {}
        ack_status = str(ack_obj.get('statuscode') or '')
        claim_status_code = str(claim_obj.get('statuscode') or '')
        claim_has_results = bool(claim_obj.get('claims'))

        if result['ack_277ca'] and ack_status in optumai_success_status_codes:
            result['statuscode'] = '000'
            result['message'] = '277CA confirmation retrieved successfully'
        elif claim_has_results:
            result['statuscode'] = '000'
            result['message'] = 'Claim status retrieved successfully'
        else:
            # Preserve actionable upstream failure details instead of collapsing everything to 404.
            # Priority: explicit non-404 errors from 277CA or member-lookup responses.
            if ack_status and ack_status not in ('404',):
                result['statuscode'] = ack_status
                result['message'] = ack_obj.get('message') or '277CA lookup failed'
            elif claim_status_code and claim_status_code not in ('404', '200'):
                result['statuscode'] = claim_status_code
                result['message'] = claim_obj.get('message') or 'Claim status lookup failed'
            else:
                # No explicit hard failure; treat as no-data and include best available reason.
                result['statuscode'] = '404'
                detail_parts = []
                if ack_obj.get('message'):
                    detail_parts.append('277CA: {}'.format(ack_obj.get('message')))
                if claim_obj.get('message'):
                    detail_parts.append('Claim lookup: {}'.format(claim_obj.get('message')))
                if detail_parts:
                    result['message'] = 'No data found for the provided criteria ({})'.format('; '.join(detail_parts))
                else:
                    result['message'] = 'No data found for the provided criteria'
    else:
        result['statuscode'] = '400'
        result['message'] = 'Insufficient data to perform lookup'
    
    return result

@_with_api_core_globals
def get_eligibility(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi):
    endpoint_name = 'UHCAPI'
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    url_extension = medi.get('endpoints', {}).get(endpoint_name, {}).get('additional_endpoints', {}).get('eligibility', '')
    url_extension = url_extension + '?payerID={}&providerLastName={}&searchOption={}&dateOfBirth={}&memberId={}&npi={}'.format(
        payer_id, provider_last_name, search_option, date_of_birth, member_id, npi)
    return client.make_api_call(endpoint_name, 'GET', url_extension)

@_with_api_core_globals
def get_eligibility_v3(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, 
                       first_name=None, last_name=None, payer_label=None, payer_name=None, service_start=None, service_end=None, 
                       middle_name=None, gender=None, ssn=None, city=None, state=None, zip=None, group_number=None, 
                       service_type_code=None, provider_first_name=None, tax_id_number=None, provider_name_id=None, 
                       corporate_tax_owner_id=None, corporate_tax_owner_name=None, organization_name=None, 
                       organization_id=None, identify_service_level_deductible=True):

    # Ensure all required parameters have values
    if not all([client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi]):
        raise ValueError("All required parameters must have values: client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi")

    # Endpoint is UHCAPI for this v3 REST call
    endpoint_name = 'UHCAPI'

    # Validate payer_id strictly against UHC list
    valid_payer_ids = get_valid_payer_ids_for_endpoint(client, endpoint_name)
    if payer_id not in valid_payer_ids:
        raise ValueError("Invalid payer_id: {} for endpoint {}. Must be one of: {}".format(
            payer_id, endpoint_name, ", ".join(valid_payer_ids)))
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    url_extension = medi.get('endpoints', {}).get(endpoint_name, {}).get('additional_endpoints', {}).get('eligibility_v3', '')
    
    # Construct request body
    body = {
        "memberId": member_id,
        "lastName": last_name,
        "firstName": first_name,
        "dateOfBirth": date_of_birth,
        "payerID": payer_id,
        "payerLabel": payer_label,
        "payerName": payer_name,
        "serviceStart": service_start,
        "serviceEnd": service_end,
        "middleName": middle_name,
        "gender": gender,
        "ssn": ssn,
        "city": city,
        "state": state,
        "zip": zip,
        "groupNumber": group_number,
        "serviceTypeCode": service_type_code,
        "providerLastName": provider_last_name,
        "providerFirstName": provider_first_name,
        "taxIdNumber": tax_id_number,
        "providerNameID": provider_name_id,
        "npi": npi,
        "corporateTaxOwnerID": corporate_tax_owner_id,
        "corporateTaxOwnerName": corporate_tax_owner_name,
        "organizationName": organization_name,
        "organizationID": organization_id,
        "searchOption": search_option,
        "identifyServiceLevelDeductible": identify_service_level_deductible
    }
    
    # Remove None values from the body
    body = {k: v for k, v in body.items() if v is not None}

    # Log the request body
    MediLink_ConfigLoader.log("Request body: {}".format(json.dumps(body, indent=4)), level="DEBUG")

    return client.make_api_call(endpoint_name, 'POST', url_extension, params=None, data=body)

@_with_api_core_globals
def get_eligibility_super_connector(client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi, 
                                   first_name=None, last_name=None, payer_label=None, payer_name=None, service_start=None, service_end=None, 
                                   middle_name=None, gender=None, ssn=None, city=None, state=None, zip=None, group_number=None, 
                                   service_type_code=None, provider_first_name=None, tax_id_number=None, provider_name_id=None, 
                                   corporate_tax_owner_id=None, corporate_tax_owner_name=None, organization_name=None, 
                                   organization_id=None, identify_service_level_deductible=True):
    """
    OPTUMAI eligibility (GraphQL) that maps to the same interface as get_eligibility_v3.
    This function does not perform legacy fallback; callers should invoke legacy v3 separately if desired.
    """
    # Ensure all required parameters have values
    if not all([client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi]):
        raise ValueError("All required parameters must have values: client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi")

    # Prefer OPTUMAI endpoint if configured, otherwise fall back to legacy UHCAPI v3 (REST)
    try:
        endpoints_cfg = client.config['MediLink_Config']['endpoints']
    except Exception:
        endpoints_cfg = {}

    endpoint_name = None
    url_extension = None

    try:
        optumai_cfg = endpoints_cfg.get('OPTUMAI', {})
        optumai_additional = optumai_cfg.get('additional_endpoints', {}) if isinstance(optumai_cfg, dict) else {}
        optumai_url = optumai_additional.get('eligibility_optumai')
        if optumai_cfg and optumai_cfg.get('api_url') and optumai_url:
            endpoint_name = 'OPTUMAI'
            url_extension = optumai_url
    except Exception:
        # Safe ignore; will fall back below
        pass

    if not endpoint_name:
        # No fallback from this function; surface configuration error
        raise ValueError("OPTUMAI eligibility endpoint not configured")

    # Skip OPTUMAI when payer does not support eligibility (per optum_payer_list.payers)
    supports, crosswalk, reason = _optumai_supports_feature_for_client(
        client, payer_id, 'eligibility', 'eligibility'
    )
    if not supports:
        if reason == 'feature_not_supported':
            MediLink_ConfigLoader.log(
                "Skipping OPTUMAI eligibility due to Eligibility=N for payer {}; using get_eligibility_v3.".format(payer_id),
                level="INFO"
            )
        else:
            MediLink_ConfigLoader.log(
                "Skipping OPTUMAI eligibility (feature check unavailable); using get_eligibility_v3.",
                level="WARNING"
            )
        # If payer not in UHC list, return structured "not supported" response instead of raising
        try:
            uhc_valid = get_valid_payer_ids_for_endpoint(client, 'UHCAPI')
        except Exception:
            uhc_valid = None
        if uhc_valid is not None and payer_id not in uhc_valid:
            msg = ("Eligibility not supported for payer {} via OPTUMAI or UHCAPI."
                   .format(payer_id))
            try:
                MediLink_ConfigLoader.log(msg, level="WARNING", console_output=CONSOLE_LOGGING)
            except Exception:
                pass
            return {
                'statuscode': '501',
                'message': msg,
                'payer_id': payer_id,
                'endpoint': 'OPTUMAI'
            }
        return get_eligibility_v3(
            client, payer_id, provider_last_name, search_option, date_of_birth, member_id, npi,
            first_name=first_name, last_name=last_name, payer_label=payer_label, payer_name=payer_name,
            service_start=service_start, service_end=service_end, middle_name=middle_name, gender=gender,
            ssn=ssn, city=city, state=state, zip=zip, group_number=group_number,
            service_type_code=service_type_code, provider_first_name=provider_first_name,
            tax_id_number=tax_id_number, provider_name_id=provider_name_id,
            corporate_tax_owner_id=corporate_tax_owner_id, corporate_tax_owner_name=corporate_tax_owner_name,
            organization_name=organization_name, organization_id=organization_id,
            identify_service_level_deductible=identify_service_level_deductible)

    # Validate payer_id against the selected endpoint's list
    # - If OPTUMAI is used, allow the augmented list (includes LIFE1, WELM2, etc.).
    # - If UHCAPI fallback is used, enforce strict UHC list only.
    valid_payer_ids = get_valid_payer_ids_for_endpoint(client, endpoint_name)
    if payer_id not in valid_payer_ids:
        raise ValueError("Invalid payer_id: {} for endpoint {}. Must be one of: {}".format(
            payer_id, endpoint_name, ", ".join(valid_payer_ids)))

    if not url_extension:
        raise ValueError("Eligibility endpoint not configured for {}".format(endpoint_name))

    # Debug/trace: indicate that OPTUMAI eligibility path is active (log only, no console print)
    # Wrap in try/except to handle OSError on Windows when logging stream flush fails
    try:
        MediLink_ConfigLoader.log(
            "Eligibility using OPTUMAI endpoint with path '{}'".format(url_extension),
            level="DEBUG",
            console_output=CONSOLE_LOGGING
        )
    except (OSError, IOError):
        # Windows logging stream flush can fail with OSError [Errno 22] - ignore silently
        pass
    except Exception:
        pass
    
    # Get provider TIN from config (using existing billing_provider_tin)
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    provider_tin_raw = medi.get('billing_provider_tin')
    if not provider_tin_raw:
        raise ValueError("Provider TIN not found in configuration")
    # Normalize provider TIN to 9-digit numeric string using centralized helper
    provider_tin = normalize_provider_tin(provider_tin_raw)
    if not provider_tin:
        raise ValueError("Provider TIN normalization failed: '{}' could not be normalized".format(provider_tin_raw))
    # Validate normalized TIN is 9 digits
    if len(provider_tin) != 9:
        error_msg = "Provider TIN '{}' normalized to '{}' (not 9 digits)".format(provider_tin_raw, provider_tin)
        MediLink_ConfigLoader.log(error_msg, level="WARNING", console_output=CONSOLE_LOGGING)
        raise ValueError(error_msg)
    
    # Validate service dates format if provided (should be ISO 8601 YYYY-MM-DD)
    try:
        from datetime import datetime
    except ImportError:
        datetime = None
    
    if service_start and datetime:
        try:
            service_start_str = str(service_start).strip()
            # Validate ISO date format
            datetime.strptime(service_start_str, '%Y-%m-%d')
        except (ValueError, TypeError):
            MediLink_ConfigLoader.log(
                "Warning: service_start '{}' is not in YYYY-MM-DD format, but continuing anyway".format(
                    str(service_start)[:20]  # Limit length
                ),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Warning: Error validating service_start format: {}".format(str(e)),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
    
    if service_end and datetime:
        try:
            service_end_str = str(service_end).strip()
            # Validate ISO date format
            datetime.strptime(service_end_str, '%Y-%m-%d')
        except (ValueError, TypeError):
            MediLink_ConfigLoader.log(
                "Warning: service_end '{}' is not in YYYY-MM-DD format, but continuing anyway".format(
                    str(service_end)[:20]  # Limit length
                ),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
        except Exception as e:
            MediLink_ConfigLoader.log(
                "Warning: Error validating service_end format: {}".format(str(e)),
                level="WARNING",
                console_output=CONSOLE_LOGGING
            )
    
    # Construct GraphQL query variables using the consolidated module
    # Include service dates when provided (needed to determine active policy at time of service)
    # Only pass service dates if they have actual values (not None and not empty string)
    graphql_kwargs = {
        'member_id': member_id,
        'date_of_birth': date_of_birth,
        'payer_id': payer_id,
        'provider_last_name': provider_last_name,
        'provider_npi': npi
    }
    # Add service dates only if provided (safe to omit if None or empty)
    if service_start:
        graphql_kwargs['service_start_date'] = service_start
    if service_end:
        graphql_kwargs['service_end_date'] = service_end
    # Add group number only when available (optional disambiguator for multi-plan cases)
    if group_number:
        try:
            graphql_kwargs['group_number'] = str(group_number).strip()
        except Exception:
            # If normalization fails, skip group number rather than sending bad data
            pass
    
    graphql_variables = MediLink_GraphQL.build_eligibility_variables(**graphql_kwargs)
    
    # Validate NPI format (should be 10 digits)
    if 'providerNPI' in graphql_variables:
        npi_value = graphql_variables['providerNPI']
        if not npi_value.isdigit() or len(npi_value) != 10:
            MediLink_ConfigLoader.log("Warning: NPI '{}' is not 10 digits, but continuing anyway".format(npi_value), level="WARNING")
    
    # Build GraphQL request with actual data using consolidated module
    # OPTUMAI now uses an enriched query aligned to production schema
    try:
        if endpoint_name == 'OPTUMAI' and hasattr(MediLink_GraphQL, 'build_optumai_enriched_request'):
            graphql_body = MediLink_GraphQL.build_optumai_enriched_request(graphql_variables)
            try:
                MediLink_ConfigLoader.log("Using OPTUMAI ENRICHED GraphQL request", level="DEBUG")
            except (OSError, IOError):
                # Windows logging stream flush can fail - ignore silently
                pass
        else:
            graphql_body = MediLink_GraphQL.build_eligibility_request(graphql_variables)
            try:
                MediLink_ConfigLoader.log("Using CONSTRUCTED DATA with consolidated GraphQL module", level="INFO")
            except (OSError, IOError):
                # Windows logging stream flush can fail - ignore silently
                pass
    except Exception:
        graphql_body = MediLink_GraphQL.build_eligibility_request(graphql_variables)
        try:
            MediLink_ConfigLoader.log("Fallback to standard GraphQL request body", level="WARNING")
        except (OSError, IOError):
            # Windows logging stream flush can fail - ignore silently
            pass

    if DEBUG:
        # Compare with sample data only in debug mode.
        sample_data = MediLink_GraphQL.get_sample_eligibility_request()
        MediLink_ConfigLoader.log("Sample data structure: {}".format(json.dumps(sample_data, indent=2)), level="DEBUG")
        MediLink_ConfigLoader.log("Constructed data structure: {}".format(json.dumps(graphql_body, indent=2)), level="DEBUG")

        # Compare key differences
        sample_vars = sample_data.get('variables', {}).get('input', {})
        constructed_vars = graphql_body.get('variables', {}).get('input', {})

        # Log differences in variables
        for key in set(sample_vars.keys()) | set(constructed_vars.keys()):
            sample_val = sample_vars.get(key)
            constructed_val = constructed_vars.get(key)
            if sample_val != constructed_val:
                MediLink_ConfigLoader.log("Variable difference - {}: sample='{}', constructed='{}'".format(
                    key, sample_val, constructed_val), level="DEBUG")

        # Log the GraphQL request only in debug mode.
        MediLink_ConfigLoader.log("GraphQL request body: {}".format(json.dumps(graphql_body, indent=2)), level="DEBUG")
        MediLink_ConfigLoader.log("GraphQL variables: {}".format(json.dumps(graphql_variables, indent=2)), level="DEBUG")
    
    # Build headers - use centralized builder for OPTUMAI, legacy format for UHCAPI
    if endpoint_name == 'OPTUMAI':
        # Use centralized header builder (normalizes TIN and adds all required headers)
        try:
            optumai_cfg = endpoints_cfg.get('OPTUMAI', {})
            optumai_api_url = optumai_cfg.get('api_url')
            headers = build_optumai_headers(client.config, api_url=optumai_api_url)
        except Exception:
            # Fallback to basic headers if builder fails
            headers = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            if provider_tin:
                headers['providerTaxId'] = str(provider_tin)
    else:
        # Legacy UHCAPI headers (preserve existing behavior)
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'tin': str(provider_tin)  # Ensure TIN is a string (used for legacy UHC super connector)
        }
    
    # Remove None values from headers
    headers = {k: v for k, v in headers.items() if v is not None}
    
    # Log the final headers being sent
    MediLink_ConfigLoader.log("Final headers being sent: {}".format(json.dumps(headers, indent=2)), level="DEBUG")
    
    # Make the GraphQL API call with enhanced error diagnostics for endpoint failures
    try:
        response = client.make_api_call(endpoint_name, 'POST', url_extension, params=None, data=graphql_body, headers=headers)
    except Exception as e:
        # Check if this is a GraphQL validation error (ED270BR, BACKEND_VALIDATION_FAILED)
        error_str = str(e)
        is_validation_error = False
        validation_terms = ["BACKEND_VALIDATION_FAILED", "ED270BR", "mandatory attributes", "Bad request"]
        for term in validation_terms:
            if term in error_str:
                is_validation_error = True
                break
        
        # Enhanced diagnostics for validation errors
        if is_validation_error:
            # Log sanitized request payload for diagnostics (no PHI)
            try:
                # Extract variables from GraphQL body for diagnostics
                # Defensive check: graphql_body should be defined, but handle edge case where exception occurred during construction
                try:
                    graphql_body_ref = graphql_body
                except NameError:
                    # graphql_body not defined - exception occurred before it was created
                    graphql_body_ref = {}
                graphql_vars = graphql_body_ref.get('variables', {}).get('input', {}) if isinstance(graphql_body_ref, dict) else {}
                
                # Required fields per OPTUMAI spec
                required_fields = ['payerId', 'providerLastName', 'memberId', 'dateOfBirth']
                optional_but_important = ['providerNPI']
                
                # Check which required fields are present
                present_fields = []
                missing_fields = []
                for field in required_fields:
                    if field in graphql_vars and graphql_vars[field]:
                        present_fields.append(field)
                    else:
                        missing_fields.append(field)
                
                # Check providerTaxId header
                provider_tax_id_present = 'providerTaxId' in headers and headers.get('providerTaxId')
                
                # Build diagnostic message
                diag_parts = [
                    "GraphQL validation error (ED270BR) - Missing mandatory attributes",
                    "Required fields present: {}".format(", ".join(present_fields) if present_fields else "none"),
                    "Required fields missing: {}".format(", ".join(missing_fields) if missing_fields else "none"),
                    "providerTaxId header: {}".format("present" if provider_tax_id_present else "missing"),
                ]
                
                # Add optional field status
                if 'providerNPI' in graphql_vars and graphql_vars.get('providerNPI'):
                    diag_parts.append("providerNPI: present")
                else:
                    diag_parts.append("providerNPI: missing")
                
                # Log field values (sanitized - no full values, just presence and lengths)
                field_summary = []
                for field in required_fields + optional_but_important:
                    if field in graphql_vars:
                        val = graphql_vars[field]
                        if isinstance(val, str):
                            field_summary.append("{}: len={}".format(field, len(val)))
                        elif val:
                            field_summary.append("{}: present".format(field))
                        else:
                            field_summary.append("{}: empty".format(field))
                    else:
                        field_summary.append("{}: missing".format(field))
                
                diag_parts.append("Field summary: {}".format("; ".join(field_summary)))
                
                diagnostic_msg = " | ".join(diag_parts)
                MediLink_ConfigLoader.log(diagnostic_msg, level="WARNING", console_output=CONSOLE_LOGGING)
                
                # Also print a concise version
                try:
                    print("[Eligibility] GraphQL validation error - Missing: {} | Check logs for details".format(
                        ", ".join(missing_fields) if missing_fields else "unknown"
                    ))
                except Exception:
                    pass
            except Exception as diag_exc:
                # If diagnostics fail, log basic error
                MediLink_ConfigLoader.log(
                    "GraphQL validation error diagnostics failed: {}".format(str(diag_exc)),
                    level="WARNING",
                    console_output=CONSOLE_LOGGING
                )
        
        # Best-effort diagnostics without exposing secrets or PHI
        try:
            status = getattr(getattr(e, 'response', None), 'status_code', None)
            diag = "Eligibility request to {}{} failed".format(
                endpoint_name and (endpoint_name + " ") or "", url_extension)
            if status is not None:
                diag += " with status {}".format(status)
            if not is_validation_error:  # Don't duplicate log for validation errors
                MediLink_ConfigLoader.log(diag, level="ERROR", console_output=CONSOLE_LOGGING)
                try:
                    print("[Eligibility] Request failed (status: {}). See logs for details.".format(status))
                except Exception:
                    pass
        except Exception:
            pass

        # No fallback from this function; re-raise so callers can handle or try legacy explicitly
        raise
    
    # Transform GraphQL response to match REST API format
    # This ensures the calling code doesn't know the difference
    transformed_response = MediLink_GraphQL.transform_eligibility_response(response)

    # Post-transform sanity: if non-200, emit brief diagnostics to aid validation sessions
    try:
        sc_status = transformed_response.get('statuscode') if isinstance(transformed_response, dict) else None
        if sc_status and sc_status != '200':
            msg = transformed_response.get('message')
            MediLink_ConfigLoader.log(
                "OPTUMAI eligibility transformed response status: {} msg: {}".format(sc_status, msg),
                level="INFO",
                console_output=CONSOLE_LOGGING
            )
            raw_errs = None
            try:
                raw = transformed_response.get('rawGraphQLResponse', {})
                raw_errs = raw.get('errors')
            except Exception:
                raw_errs = None
            if raw_errs:
                try:
                    first_err = raw_errs[0]
                    code = first_err.get('code') or first_err.get('extensions', {}).get('code')
                    desc = first_err.get('description') or first_err.get('message')
                    print("[Eligibility] GraphQL error code={} desc={}".format(code, desc))
                    
                    # Enhanced diagnostics for validation errors
                    if code and ("BACKEND_VALIDATION_FAILED" in str(code) or "ED270BR" in str(desc) or "mandatory attributes" in str(desc)):
                        # Log which fields were sent vs required
                        try:
                            # Get the variables that were sent (defensive check for scope)
                            try:
                                graphql_body_ref = graphql_body
                            except NameError:
                                graphql_body_ref = {}
                            try:
                                headers_ref = headers
                            except NameError:
                                headers_ref = {}
                            
                            graphql_vars = graphql_body_ref.get('variables', {}).get('input', {}) if isinstance(graphql_body_ref, dict) else {}
                            required_fields = ['payerId', 'providerLastName', 'memberId', 'dateOfBirth']
                            
                            present = [f for f in required_fields if f in graphql_vars and graphql_vars[f]]
                            missing = [f for f in required_fields if f not in graphql_vars or not graphql_vars[f]]
                            
                            diag_msg = "Validation error details - Present: {} | Missing: {} | providerTaxId header: {}".format(
                                ", ".join(present) if present else "none",
                                ", ".join(missing) if missing else "none",
                                "present" if headers_ref.get('providerTaxId') else "missing"
                            )
                            MediLink_ConfigLoader.log(diag_msg, level="WARNING", console_output=CONSOLE_LOGGING)
                        except Exception:
                            pass  # Don't fail if diagnostics can't be generated
                except Exception:
                    pass

            # Terminal self-help hints for auth/authorization cases
            # Non-throwing hint emitter (kept outside core logic path)
            def _emit_hint_for_status(status_str):
                try:
                    trace_id = transformed_response.get('traceId')
                    trace_info = " (Trace ID: {})".format(trace_id) if trace_id else ""
                    
                    if status_str == '401':
                        hint_parts = [
                            "[Eligibility] Hint: Authentication failed{}.".format(trace_info),
                            "Verify client credentials and subscription access in OPTUMAI portal.",
                            "Note: OPTUM auto-grants scopes via subscription - scope parameter is not required in token request.",
                            "See docs/OPTUMAI_TOKEN_SCOPE_INVESTIGATION.md for troubleshooting."
                        ]
                        print(" ".join(hint_parts))
                    elif status_str == '403':
                        hint_parts = [
                            "[Eligibility] Hint: Access denied{}.".format(trace_info),
                            "Verify providerTaxId/TIN and subscription permissions/roles for endpoint.",
                            "Check that client credentials have eligibility endpoint access enabled in OPTUMAI portal."
                        ]
                        print(" ".join(hint_parts))
                except Exception:
                    pass

            try:
                _emit_hint_for_status(str(sc_status))
            except Exception:
                pass
    except Exception:
        pass
    
    return transformed_response

@_with_api_core_globals
def _detect_inline_ack_type(response_type, x12_data):
    """
    Determine inline ACK type for OPTUMAI submissions.
    Prefers responseType when present; falls back to X12 content.
    """
    if response_type:
        try:
            return str(response_type).upper()
        except Exception:
            return None
    if not x12_data:
        return None
    try:
        data_upper = str(x12_data).upper()
        if 'ST*277' in data_upper:
            return '277CA'
        if 'ST*999' in data_upper:
            return '999'
    except Exception:
        return None
    return None

@_with_api_core_globals
def _optumai_search277ca_ack_success_but_payload_empty(ack, success_status_codes):
    """
    True when search277CA returned a success statuscode but no X12 payload yet
    (backend may need a short moment before 277CA is available).
    """
    if not isinstance(ack, dict):
        return False
    code = str(ack.get('statuscode') or '')
    if code not in success_status_codes:
        return False
    return not str(ack.get('x12ResponseData') or '').strip()

@_with_api_core_globals
def _search_optumai_277ca_with_delayed_retry(client, transaction_id, payer_id, sleep_fn=None):
    """
    Call search277CA; if success with empty X12, wait 1s and call once more.
    Returns (ack_response, attempts, retried_empty_payload).
    """
    from MediCafe.claim_actions_adapter import (
        search_277ca_via_optumai,
        OPTUMAI_SUCCESS_STATUS_CODES,
    )

    if sleep_fn is None:
        sleep_fn = time.sleep
    ack = search_277ca_via_optumai(client, transaction_id, payer_id)
    attempts = 1
    retried = False
    if _optumai_search277ca_ack_success_but_payload_empty(ack, OPTUMAI_SUCCESS_STATUS_CODES):
        MediLink_ConfigLoader.log(
            "277CA search returned success with empty X12 payload; retrying after 1s.",
            level="INFO",
        )
        sleep_fn(1)
        ack = search_277ca_via_optumai(client, transaction_id, payer_id)
        attempts = 2
        retried = True
    return ack, attempts, retried


def _optumai_backend_validation_details(response):
    """
    Return sanitized validation details for OPTUMAI backend 400/validation responses.
    Does not include payload bodies or PHI-bearing request data.
    """
    details = {
        'is_validation_error': False,
        'statuscode': '',
        'error_code': '',
        'reason': '',
        'message': '',
    }
    if not isinstance(response, dict):
        return details
    statuscode = str(response.get('statuscode') or response.get('statusCode') or '').strip()
    message = str(response.get('message') or '').strip()
    msg_lower = message.lower()
    details['statuscode'] = statuscode
    details['message'] = message[:300]
    if 'reason=' in msg_lower:
        try:
            reason_part = message.split('reason=', 1)[1]
            reason_part = reason_part.split(']', 1)[0]
            details['reason'] = reason_part.strip()
        except Exception:
            details['reason'] = ''
    if (
        statuscode == '400'
        or 'validation failed' in msg_lower
        or 'backend_validation_failed' in msg_lower
        or 'ed270br' in msg_lower
        or 'mandatory attributes' in msg_lower
    ):
        details['is_validation_error'] = True
        if details.get('reason'):
            details['error_code'] = details.get('reason')
        elif 'backend_validation_failed' in msg_lower:
            details['error_code'] = 'BACKEND_VALIDATION_FAILED'
        else:
            details['error_code'] = 'VALIDATION_FAILED'
    return details


def _attach_optumai_backend_validation_metadata(response):
    if not isinstance(response, dict):
        return response
    meta_existing = response.get('_metadata') or {}
    if meta_existing.get('optumai_backend_validation_soft'):
        return response
    details = _optumai_backend_validation_details(response)
    if not details.get('is_validation_error'):
        return response
    meta = response.get('_metadata') or {}
    meta['claim_submission_success'] = False
    meta['optumai_backend_validation_error'] = True
    meta['optumai_backend_validation_details'] = details
    response['_metadata'] = meta
    try:
        MediLink_ConfigLoader.log(
            "OPTUMAI backend validation failure: statuscode={} errorCode={} reason={} message={}".format(
                details.get('statuscode') or '',
                details.get('error_code') or '',
                details.get('reason') or '',
                details.get('message') or '',
            ),
            level="WARNING"
        )
    except Exception:
        pass
    return response

@_with_api_core_globals
def submit_uhc_claim(client, x12_request_data):
    """
    Submits a UHC claim and retrieves the claim acknowledgement details.
    
    Phase 4: Routes to OPTUMAI Claim Actions adapter if configured, otherwise falls back to legacy UHCAPI.
    
    This function first submits the claim using the provided x12 837p data. If the client is in Test Mode, 
    it returns a simulated response. If Test Mode is not enabled, it submits the claim and then retrieves 
    the claim acknowledgement details using the transaction ID from the initial response.
    
    NOTE: This function uses endpoints that may not be available in the new swagger version:
    - /Claims/api/claim-submission/v1 (claim submission)
    - /Claims/api/claim-details/v1 (claim acknowledgement)
    
    If these endpoints are deprecated in the new swagger, this function will need to be updated
    to use the new available endpoints.
    
    :param client: An instance of APIClient
    :param x12_request_data: The x12 837p data as a string
    :return: The final response containing the claim acknowledgement details or a dummy response if in Test Mode
    """
    # Verbose claim submission details at DEBUG to reduce log noise (one line at INFO)
    MediLink_ConfigLoader.log(
        "Submit claim - X12 length: {}".format(len(x12_request_data) if x12_request_data else 0),
        level="INFO"
    )
    MediLink_ConfigLoader.log("=" * 80, level="DEBUG")
    MediLink_ConfigLoader.log("SUBMIT UHC CLAIM - VERBOSE DETAILS", level="DEBUG")
    MediLink_ConfigLoader.log("=" * 80, level="DEBUG")
    MediLink_ConfigLoader.log("X12 Request Data Length: {}".format(len(x12_request_data) if x12_request_data else 0), level="DEBUG")
    if x12_request_data:
        MediLink_ConfigLoader.log("X12 Request Data Preview (first 200 chars): {}".format(x12_request_data[:200]), level="DEBUG")
    MediLink_ConfigLoader.log("=" * 80, level="DEBUG")
    
    # Phase 4: Check if OPTUMAI Claim Actions is configured and route to adapter
    from MediCafe.core_utils import extract_medilink_config
    medi = extract_medilink_config(client.config)
    endpoints = medi.get('endpoints', {})
    optumai_cfg = endpoints.get('OPTUMAI', {})
    
    # Early validation: Ensure OPTUMAI configuration matches successful format before attempting
    optumai_additional = optumai_cfg.get('additional_endpoints', {}) if isinstance(optumai_cfg, dict) else {}
    optumai_claim_actions_url = optumai_additional.get('claim_actions')
    optumai_api_url = optumai_cfg.get('api_url')
    
    # Validate configuration early to ensure successful format is used on first attempt
    optumai_config_valid = False
    optumai_config_error = None
    if optumai_cfg and optumai_api_url and optumai_claim_actions_url:
        try:
            from MediCafe.claim_actions_adapter import _validate_optumai_config
            is_valid, validation_error, normalized_paths = _validate_optumai_config(optumai_cfg, required_endpoint='claim_actions')
            if is_valid:
                optumai_config_valid = True
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration validated: base_url='{}', claim_actions='{}'".format(
                        optumai_api_url.rstrip('/'), normalized_paths.get('claim_actions', optumai_claim_actions_url)
                    ),
                    level="DEBUG"
                )
            else:
                optumai_config_error = validation_error
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration validation failed: {}. Will fall back to UHCAPI.".format(validation_error),
                    level="WARNING"
                )
        except ImportError:
            # Validation function not available - log but continue with basic checks
            MediLink_ConfigLoader.log(
                "OPTUMAI validation function not available, using basic configuration checks",
                level="DEBUG"
            )
            optumai_config_valid = True  # Allow basic check to proceed
        except Exception as e:
            # Validation error - treat as configuration issue
            optumai_config_error = "Configuration validation error: {}".format(str(e))
            MediLink_ConfigLoader.log(
                "OPTUMAI configuration validation exception: {}. Will fall back to UHCAPI.".format(str(e)),
                level="WARNING"
            )
    
    if optumai_cfg and optumai_api_url and not optumai_claim_actions_url:
        _log_fallback_once(
            'claim_actions_missing_path',
            "OPTUMAI claim actions not configured (missing additional_endpoints.claim_actions); using UHCAPI submission.",
            level="WARNING"
        )
    elif optumai_cfg and optumai_claim_actions_url and not optumai_api_url:
        _log_fallback_once(
            'claim_actions_missing_api_url',
            "OPTUMAI claim actions configured but api_url missing; using UHCAPI submission.",
            level="WARNING"
        )
    
    # Track whether we attempted OPTUMAI and had to fall back
    optumai_attempted = False
    fallback_used = False

    skip_optumai_for_payer = False
    _pid = None
    try:
        from MediCafe.claim_actions_adapter import extract_payer_id_from_x12
        _pid = extract_payer_id_from_x12(x12_request_data)
        if not _pid:
            skip_optumai_for_payer = True
            MediLink_ConfigLoader.log(
                "Skipping OPTUMAI claim submission: payer ID not found in X12; using UHCAPI.",
                level="INFO"
            )
        else:
            supports, _cw, reason = _optumai_supports_feature_for_client(
                client, _pid, 'submit_with_precheck', 'claim_submission'
            )
            if not supports:
                skip_optumai_for_payer = True
                if reason == 'feature_not_supported':
                    MediLink_ConfigLoader.log(
                        "Skipping OPTUMAI claim submission due to Submit w/Pre-Check=N for payer {}; using UHCAPI.".format(_pid),
                        level="INFO"
                    )
                else:
                    MediLink_ConfigLoader.log(
                        "Skipping OPTUMAI claim submission (feature check unavailable); using UHCAPI.",
                        level="WARNING"
                    )
    except ImportError:
        pass

    # Route to OPTUMAI adapter if configured and validated (and payer supports it)
    if (optumai_api_url and optumai_claim_actions_url and optumai_config_valid
            and not skip_optumai_for_payer):
        try:
            optumai_attempted = True
            from MediCafe.claim_actions_adapter import (
                submit_claim_via_optumai,
                OPTUMAI_SUCCESS_STATUS_CODES,
                is_optumai_submit_retriable_failure,
                is_optumai_submit_pending_ack,
                is_optumai_submit_duplicate_signal,
            )
            MediLink_ConfigLoader.log("Routing claim submission to OPTUMAI Claim Actions", level="INFO")
            
            # Submit via OPTUMAI; on retriable failure (e.g. 930, 5xx), retry once and combine messages if both fail
            submission_response = submit_claim_via_optumai(client, x12_request_data)
            _attach_optumai_backend_validation_metadata(submission_response)
            statuscode = str(submission_response.get('statuscode') or '')
            fallback_reason = None
            if is_optumai_submit_retriable_failure(submission_response):
                msg1 = submission_response.get('message') or 'No message'
                MediLink_ConfigLoader.log(
                    "OPTUMAI claim submission attempt 1 failed (statuscode={}); retrying once.".format(statuscode),
                    level="INFO"
                )
                response2 = submit_claim_via_optumai(client, x12_request_data)
                _attach_optumai_backend_validation_metadata(response2)
                statuscode2 = str(response2.get('statuscode') or '')
                response2_pending_ack = is_optumai_submit_pending_ack(response2)
                duplicate_signal = is_optumai_submit_duplicate_signal(response2)

                # Duplicate/already-submitted semantics indicate probable out-of-custody state even
                # when the gateway surfaces a 4xx. Suppress fallback re-submit to avoid duplicate claims.
                if duplicate_signal:
                    MediLink_ConfigLoader.log(
                        "Detected duplicate-claim signal on OPTUMAI retry; suppressing UHCAPI fallback to avoid potential duplicate submission.",
                        level="WARNING"
                    )
                    submission_response = response2
                    _meta = submission_response.get('_metadata') or {}
                    _meta['claim_submission_success'] = False
                    _meta['resubmit_suppressed'] = True
                    _meta['resubmit_suppressed_reason'] = 'duplicate_signal'
                    _meta['response_source'] = 'optumai'
                    submission_response['_metadata'] = _meta
                elif (
                    not duplicate_signal and
                    is_optumai_submit_retriable_failure(response2)
                    or (
                        not duplicate_signal and
                        statuscode2 not in OPTUMAI_SUCCESS_STATUS_CODES
                        and not response2_pending_ack
                    )
                ):
                    msg2 = response2.get('message') or 'No message'
                    combined = "Attempt 1: {}; Attempt 2: {}".format(msg1, msg2)
                    MediLink_ConfigLoader.log(
                        "OPTUMAI claim submission retry also failed (statuscode={}). {}".format(statuscode2, combined),
                        level="WARNING"
                    )
                    submission_response = response2
                    submission_response['message'] = combined
                    fallback_used = True
                    fallback_reason = "optumai_submit_retry_exhausted"
                else:
                    submission_response = response2
                    MediLink_ConfigLoader.log("OPTUMAI claim submission succeeded on retry.", level="INFO")

            if fallback_used and fallback_reason == "optumai_submit_retry_exhausted":
                MediLink_ConfigLoader.log(
                    "OPTUMAI claim submission failed after two attempts; falling back to UHCAPI submission as attempt 3.",
                    level="WARNING"
                )
            else:

                # Check if we got inline 277CA (preferred) or need to fetch separately
                transaction_id = submission_response.get('transactionId')
                x12_response_277ca = submission_response.get('x12ResponseData')
                ack_type = _detect_inline_ack_type(submission_response.get('responseType'), x12_response_277ca)
                has_inline_277 = bool(ack_type and '277' in ack_type)
            
                # If we have inline 277CA, return it directly
                if x12_response_277ca and transaction_id and has_inline_277:
                    # Persist as unified ack event (best-effort)
                    try:
                        from MediCafe.submission_index import append_ack_event, ensure_submission_index
                        cfg, _ = MediLink_ConfigLoader.load_configuration()
                        receipts_root = extract_medilink_config(cfg).get('local_claims_path', None)
                        if receipts_root:
                            ensure_submission_index(receipts_root)
                            status_text = submission_response.get('message', '')
                            append_ack_event(
                                receipts_root,
                                '',
                                status_text,
                                'API-277',
                                'optumai',
                                {'transactionId': transaction_id},
                                'api_ack',
                                int(time.time())
                            )
                    except Exception:
                        pass
                    
                    return submission_response
            
                # If no inline 277CA but we have transaction_id, try to fetch 277CA separately
                if transaction_id and not has_inline_277:
                    submission_statuscode = str(submission_response.get('statuscode') or '')
                    if submission_statuscode not in OPTUMAI_SUCCESS_STATUS_CODES:
                        MediLink_ConfigLoader.log(
                            "Skipping 277CA fetch - submission was not successful (statuscode={}).".format(submission_statuscode),
                            level="INFO"
                        )
                        _meta = submission_response.get('_metadata') or {}
                        _meta['277ca_fetch_attempted'] = False
                        _meta['277ca_fetch_skip_reason'] = 'submission_not_successful'
                        submission_response['_metadata'] = _meta
                        return submission_response
                    if ack_type and '999' in ack_type:
                        MediLink_ConfigLoader.log(
                            "OPTUMAI submission returned 999; fetching 277CA separately.",
                            level="INFO"
                        )
                    elif x12_response_277ca:
                        MediLink_ConfigLoader.log(
                            "OPTUMAI submission returned inline ACK type '{}' (not 277CA); fetching 277CA separately.".format(ack_type or 'unknown'),
                            level="INFO"
                        )
                    try:
                        payer_id = _pid
                        if not payer_id:
                            MediLink_ConfigLoader.log(
                                "Cannot fetch 277CA - payer ID not found in X12 data. TransactionId: '{}'".format(transaction_id),
                                level="WARNING"
                            )
                            _meta = submission_response.get('_metadata') or {}
                            _meta['277ca_fetch_attempted'] = False
                            _meta['277ca_fetch_skip_reason'] = 'payer_id_not_found_in_x12'
                            submission_response['_metadata'] = _meta
                            return submission_response

                        _skip_277 = False
                        _skip_reason = None
                        supports, _cw, reason = _optumai_supports_feature_for_client(
                            client, payer_id, 'search_277ca', '277ca_fetch'
                        )
                        if not supports:
                            _skip_277 = True
                            if reason == 'feature_not_supported':
                                _skip_reason = 'search_277ca_not_supported_for_payer'
                                MediLink_ConfigLoader.log(
                                    "Skipping 277CA fetch via OPTUMAI due to Search 277CA=N for payer {}; returning submission only.".format(payer_id),
                                    level="INFO"
                                )
                            else:
                                _skip_reason = 'search_277ca_feature_check_unavailable'
                                MediLink_ConfigLoader.log(
                                    "Skipping 277CA fetch via OPTUMAI (feature check unavailable); returning submission only.",
                                    level="WARNING"
                                )
                        if _skip_277:
                            _meta = submission_response.get('_metadata') or {}
                            _meta['claim_submission_success'] = True
                            _meta['transactionId'] = transaction_id
                            _meta['response_source'] = 'optumai'
                            _meta['277ca_fetch_attempted'] = False
                            _meta['277ca_fetch_skip_reason'] = _skip_reason or 'search_277ca_not_supported_for_payer'
                            submission_response['_metadata'] = _meta
                            return submission_response

                        MediLink_ConfigLoader.log(
                            "Fetching 277CA via OPTUMAI search277CA - transactionId: '{}' (type: {}, length: {}), payerId: '{}'".format(
                                transaction_id, type(transaction_id).__name__, len(str(transaction_id)) if transaction_id else 0, payer_id
                            ),
                            level="INFO"
                        )
                        ack_response, _277_attempts, _277_retried = _search_optumai_277ca_with_delayed_retry(
                            client, transaction_id, payer_id
                        )
                        # Log the 277CA response status
                        ack_statuscode = ack_response.get('statuscode') if isinstance(ack_response, dict) else None
                        ack_message = ack_response.get('message') if isinstance(ack_response, dict) else None
                        MediLink_ConfigLoader.log(
                            "277CA search completed - statuscode: {}, message: {}".format(ack_statuscode, ack_message),
                            level="INFO"
                        )
                        # Merge transaction_id into response and add metadata (only if ack_response is a dict)
                        # This helps handle_transmission_result detect when claim submission succeeded but 277CA failed
                        if isinstance(ack_response, dict):
                            ack_response['transactionId'] = transaction_id
                            ack_status_str = str(ack_statuscode or '')
                            ack_response['_metadata'] = {
                                'claim_submission_success': True,
                                'transactionId': transaction_id,
                                '277ca_fetch_attempted': True,
                                '277ca_fetch_success': ack_status_str in OPTUMAI_SUCCESS_STATUS_CODES,
                                '277ca_error': ack_message if ack_status_str not in OPTUMAI_SUCCESS_STATUS_CODES else None,
                                '277ca_fetch_attempts': _277_attempts,
                                '277ca_fetch_retry_after_empty': bool(_277_retried),
                            }
                        else:
                            # If ack_response is not a dict, create a dict with transactionId and error info
                            MediLink_ConfigLoader.log(
                                "277CA search returned non-dict response: {}. Creating dict wrapper.".format(type(ack_response).__name__),
                                level="WARNING"
                            )
                            ack_response = {
                                'transactionId': transaction_id,
                                'x12ResponseData': None,
                                'responseType': None,
                                'statuscode': '500',
                                'message': '277CA search returned invalid response type: {}'.format(type(ack_response).__name__),
                                '_metadata': {
                                    'claim_submission_success': True,
                                    'transactionId': transaction_id,
                                    '277ca_fetch_attempted': True,
                                    '277ca_fetch_success': False,
                                    '277ca_error': 'Invalid response type from search_277ca_via_optumai'
                                }
                            }
                        return ack_response
                    except Exception as e:
                        import traceback
                        error_trace = traceback.format_exc()
                        MediLink_ConfigLoader.log(
                            "Failed to fetch 277CA via OPTUMAI: {}\nTraceback:\n{}".format(str(e), error_trace),
                            level="ERROR"
                        )
                        # Return submission response with metadata so receipt/partial-success logic sees attempted 277CA and failure
                        _meta = submission_response.get('_metadata') or {}
                        _meta['claim_submission_success'] = True
                        _meta['277ca_fetch_attempted'] = True
                        _meta['277ca_fetch_success'] = False
                        _meta['277ca_error'] = str(e)
                        submission_response['_metadata'] = _meta
                        return submission_response
            
            if not fallback_used:
                return submission_response
        except ImportError:
            # Adapter not available - fall through to legacy UHCAPI
            # This is a configuration/capability issue, not an API error
            MediLink_ConfigLoader.log("OPTUMAI adapter not available, falling back to UHCAPI", level="WARNING")
            fallback_used = True
        except ValueError as e:
            # Configuration errors (e.g., from validation) - don't fall back, fail immediately
            error_msg = str(e)
            if 'configuration' in error_msg.lower() or 'config' in error_msg.lower():
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration error (not falling back to UHCAPI): {}".format(error_msg),
                    level="ERROR"
                )
                # Return error response instead of falling back
                return {
                    'transactionId': None,
                    'x12ResponseData': None,
                    'responseType': None,
                    'statuscode': '500',
                    'message': 'OPTUMAI configuration error: {}'.format(error_msg)
                }
            else:
                # Other ValueError - treat as API error and fall back
                MediLink_ConfigLoader.log("OPTUMAI submission failed (ValueError), falling back to UHCAPI: {}".format(error_msg), level="WARNING")
                fallback_used = True
        except Exception as e:
            # Error in OPTUMAI submission - categorize error type
            error_msg = str(e)
            error_type = type(e).__name__
            
            # Check if this is a configuration-related error
            is_config_error = (
                'configuration' in error_msg.lower() or
                'config' in error_msg.lower() or
                'not configured' in error_msg.lower() or
                'missing' in error_msg.lower() and ('endpoint' in error_msg.lower() or 'path' in error_msg.lower())
            )
            
            if is_config_error:
                # Configuration errors - don't fall back, fail immediately
                MediLink_ConfigLoader.log(
                    "OPTUMAI configuration error detected (not falling back to UHCAPI): {} ({})".format(error_msg, error_type),
                    level="ERROR"
                )
                # Return error response instead of falling back
                return {
                    'transactionId': None,
                    'x12ResponseData': None,
                    'responseType': None,
                    'statuscode': '500',
                    'message': 'OPTUMAI configuration error: {}'.format(error_msg)
                }
            else:
                # API/network errors - can fall back to UHCAPI
                MediLink_ConfigLoader.log(
                    "OPTUMAI submission failed ({}), falling back to UHCAPI: {}".format(error_type, error_msg),
                    level="WARNING"
                )
                fallback_used = True
    
    # Fallback to legacy UHCAPI
    endpoint_name = 'UHCAPI'
    claim_submission_url = endpoints.get(endpoint_name, {}).get('additional_endpoints', {}).get('claim_submission', '')
    claim_details_url = endpoints.get(endpoint_name, {}).get('additional_endpoints', {}).get('claim_details', '')
 
    MediLink_ConfigLoader.log("Claim Submission URL: {}".format(claim_submission_url), level="DEBUG")
    MediLink_ConfigLoader.log("Claim Details URL: {}".format(claim_details_url), level="DEBUG")
 
    # Headers for the request
    headers = {'Content-Type': 'application/json'} 
 
    # Request body for claim submission
    claim_body = {'x12RequestData': x12_request_data}
 
    MediLink_ConfigLoader.log("Claim Body Keys: {}".format(list(claim_body.keys())), level="DEBUG")
    MediLink_ConfigLoader.log("Headers: {}".format(json.dumps(headers, indent=2)), level="DEBUG")
 
    # Check if Test Mode is enabled and return simulated response if so
    test_mode_response = is_test_mode(client, claim_body, 'claim_submission')
    if test_mode_response:
        if fallback_used:
            try:
                msg = test_mode_response.get('message', '')
                fallback_suffix = " [via UHCAPI fallback]"
                if msg:
                    if fallback_suffix not in msg:
                        test_mode_response['message'] = msg + fallback_suffix
                else:
                    test_mode_response['message'] = "UHCAPI fallback used" + fallback_suffix
            except Exception:
                pass
        return test_mode_response
 
    # Make the API call to submit the claim
    try:
        MediLink_ConfigLoader.log("Making claim submission API call...", level="INFO")
        submission_response = client.make_api_call(endpoint_name, 'POST', claim_submission_url, data=claim_body, headers=headers)
        
        # Extract the transaction ID from the submission response
        transaction_id = submission_response.get('transactionId')
        if not transaction_id:
            raise ValueError("transactionId not found in the submission response")
        
        # Log the transaction ID for traceability
        MediLink_ConfigLoader.log("UHCAPI claim submission transactionId: {}".format(transaction_id), level="INFO")
        
        # Prepare the request body for the claim acknowledgement retrieval
        acknowledgement_body = {'transactionId': transaction_id}

        def _finalize_uhc_ack_response(raw_ack_response):
            """Normalize UHC acknowledgment response shape and attach metadata for receipt compatibility."""
            if isinstance(raw_ack_response, dict):
                ack_response = raw_ack_response
            else:
                ack_response = {
                    'statuscode': '500',
                    'message': 'UHCAPI acknowledgement returned invalid response type: {}'.format(
                        type(raw_ack_response).__name__
                    ),
                    'x12ResponseData': None,
                    'responseType': None
                }

            # Preserve transaction ID from UHC submission so downstream receipt logic always has linkage
            ack_response['transactionId'] = ack_response.get('transactionId') or transaction_id

            has_x12_response = bool(ack_response.get('x12ResponseData') or ack_response.get('x12Response277CA'))
            ack_status = str(ack_response.get('statuscode') or ack_response.get('statusCode') or '')
            ack_success = has_x12_response or ack_status in ('200', '000')

            ack_meta = ack_response.get('_metadata') if isinstance(ack_response.get('_metadata'), dict) else {}
            ack_meta['claim_submission_success'] = True
            ack_meta['transactionId'] = ack_response['transactionId']
            ack_meta['277ca_fetch_attempted'] = True
            ack_meta['277ca_fetch_success'] = ack_success
            ack_meta['response_source'] = 'uhcapi'
            if not ack_success:
                ack_meta['277ca_error'] = ack_response.get('message')
            ack_response['_metadata'] = ack_meta

            # If we used fallback, append a note so receipts can reflect it
            if fallback_used:
                try:
                    msg = ack_response.get('message', '')
                    fallback_suffix = " [via UHCAPI fallback]"
                    if msg:
                        if fallback_suffix not in msg:
                            ack_response['message'] = msg + fallback_suffix
                    else:
                        ack_response['message'] = "UHCAPI fallback used" + fallback_suffix
                except Exception:
                    pass

            return ack_response
 
        # Check if Test Mode is enabled and return simulated response if so
        test_mode_response = is_test_mode(client, acknowledgement_body, 'claim_details')
        if test_mode_response:
            return _finalize_uhc_ack_response(test_mode_response)
 
        # Make the API call to retrieve the claim acknowledgement details
        acknowledgement_response = client.make_api_call(endpoint_name, 'POST', claim_details_url, data=acknowledgement_body, headers=headers)
        acknowledgement_response = _finalize_uhc_ack_response(acknowledgement_response)

        
        # Persist as unified ack event (best-effort)
        try:
            from MediCafe.submission_index import append_ack_event, ensure_submission_index
            cfg, _ = MediLink_ConfigLoader.load_configuration()
            receipts_root = extract_medilink_config(cfg).get('local_claims_path', None)
            if receipts_root:
                ensure_submission_index(receipts_root)
                status_text = ''
                try:
                    # Attempt to pull a readable status from the response
                    status_text = acknowledgement_response.get('status') or acknowledgement_response.get('message') or ''
                except Exception:
                    status_text = ''
                append_ack_event(
                    receipts_root,
                    '',  # claim_key unknown here
                    status_text,
                    'API-277',
                    'uhcapi',
                    {'transactionId': transaction_id},
                    'api_ack',
                    int(time.time())
                )
        except Exception:
            pass
        
        return acknowledgement_response
 
    except Exception as e:
        print("Error during claim processing: {}".format(e))
        raise

@_with_api_core_globals
def test_acknowledgment(client, transaction_id, config, endpoint_name='UHCAPI'):
    """
    Light-weight probe to test the claim acknowledgment endpoint (e.g., 277CA) if configured.
    - Reads endpoint URL from config['MediLink_Config']['endpoints'][endpoint_name]['ack_endpoint']
    - Posts/gets with {'transactionId': transaction_id} depending on endpoint requirement
    - Logs response; returns parsed JSON or text.

    Backward-compatible: If no ack endpoint configured, logs and returns None without failing.
    """
    try:
        ack_url = (
            config.get('MediLink_Config', {})
                  .get('endpoints', {})
                  .get(endpoint_name, {})
                  .get('ack_endpoint')
        )
        if not ack_url:
            MediLink_ConfigLoader.log("Ack endpoint not configured for {}. Skipping acknowledgment test.".format(endpoint_name), level="INFO")
            return None

        payload = {"transactionId": transaction_id}
        headers = {"Content-Type": "application/json"}
        headers = client.add_environment_headers(headers, endpoint_name) if hasattr(client, 'add_environment_headers') else headers
        MediLink_ConfigLoader.log("Testing acknowledgment endpoint: {} payload={}".format(ack_url, payload), level="DEBUG")

        # Use generic request helper if available; otherwise fall back to requests
        try:
            response = client._request('post', ack_url, data=json.dumps(payload), headers=headers)  # type: ignore[attr-defined]
        except Exception:
            import requests as _rq
            response = _rq.post(ack_url, data=json.dumps(payload), headers=headers)
        
        try:
            content = response.json()
        except Exception:
            content = getattr(response, 'text', str(response))
        MediLink_ConfigLoader.log("Ack response: {}".format(content), level="INFO")
        return content
    except Exception as e:
        MediLink_ConfigLoader.log("Ack test failed: {}".format(e), level="ERROR")
        return None
_IMPL_get_claim_summary_by_provider = get_claim_summary_by_provider
_IMPL_get_claim_status_by_member_data = get_claim_status_by_member_data
_IMPL__build_uhcapi_member_search_request = _build_uhcapi_member_search_request
_IMPL__transform_uhcapi_member_response_to_legacy = _transform_uhcapi_member_response_to_legacy
_IMPL_get_claim_status_by_submission_context = get_claim_status_by_submission_context
_IMPL_get_eligibility = get_eligibility
_IMPL_get_eligibility_v3 = get_eligibility_v3
_IMPL_get_eligibility_super_connector = get_eligibility_super_connector
_IMPL__detect_inline_ack_type = _detect_inline_ack_type
_IMPL__optumai_search277ca_ack_success_but_payload_empty = _optumai_search277ca_ack_success_but_payload_empty
_IMPL__search_optumai_277ca_with_delayed_retry = _search_optumai_277ca_with_delayed_retry
_IMPL_submit_uhc_claim = submit_uhc_claim
_IMPL_test_acknowledgment = test_acknowledgment
