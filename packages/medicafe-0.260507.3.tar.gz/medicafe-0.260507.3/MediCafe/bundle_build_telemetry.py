#!/usr/bin/env python
# pyright: reportMissingModuleSource=false
"""
In-process bundle build timing for support ZIP meta.json and run log (Python 3.4+).

No paths or PII in telemetry payloads — counts and stage labels only.
"""
from __future__ import print_function

import os
import threading
import time

SCHEMA_VERSION = 1
BUNDLE_TELEMETRY_LOG_INFO_SLOW_SEC = 45.0

_lock = threading.Lock()
_session = None

_MAX_MILESTONES = 80
_MAX_SNAPSHOT_EVENTS = 24


def _mono():
    fn = getattr(time, 'monotonic', None)
    if fn is not None:
        return fn()
    return time.time()


def _safe_str(val, max_len=160):
    s = str(val or '').strip()
    if len(s) > max_len:
        return s[:max_len]
    return s


def telemetry_session_reset():
    """Clear session (tests)."""
    global _session
    with _lock:
        _session = None


def _telemetry_flow_for_bundle_kind(bundle_kind):
    """Canonical telemetry flow label for a resolved support bundle kind (ZIP/meta slug)."""
    return _safe_str(bundle_kind, 64)


def telemetry_session_begin(extra_meta=None):
    """Start a new telemetry session (e.g. tests or legacy entry points)."""
    global _session
    em = extra_meta if isinstance(extra_meta, dict) else {}
    flow = ''
    bk_hint = _safe_str(em.get('bundle_kind') or em.get('bundle_kind_hint'), 64)
    if bk_hint:
        flow = _telemetry_flow_for_bundle_kind(bk_hint)
    elif em.get('system_health_pack'):
        flow = 'system_health_pack'
    elif em.get('run_evidence_bundle'):
        flow = 'run_evidence_bundle'
    elif em.get('cloud_health_failure'):
        flow = 'cloud_health_escalation'
    job_id = ''
    ctx = em.get('support_send_job_context')
    if isinstance(ctx, dict):
        job_id = _safe_str(ctx.get('job_id'), 64)
    send_src = _safe_str(em.get('send_source'), 160)
    tel_bk = _safe_str(em.get('telemetry_bundle_kind') or bk_hint, 64)
    with _lock:
        now = _mono()
        _session = {
            'start_mono': now,
            'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'last_milestone_mono': now,
            'milestones': [],
            'counts': {},
            'snapshot_events': [],
            'send_source': send_src,
            'flow': flow,
            'telemetry_bundle_kind': tel_bk,
            'telemetry_send_source': send_src,
            'telemetry_job_id': job_id,
        }


def telemetry_begin_collect_session(extra_meta, bundle_kind):
    """
    Always start a fresh session for this collect_support_bundle ZIP (authoritative bundle_kind).
    """
    global _session
    em = extra_meta if isinstance(extra_meta, dict) else {}
    merged = dict(em)
    if bundle_kind:
        merged['bundle_kind_hint'] = bundle_kind
    flow = _telemetry_flow_for_bundle_kind(bundle_kind)
    job_id = ''
    ctx = merged.get('support_send_job_context')
    if isinstance(ctx, dict):
        job_id = _safe_str(ctx.get('job_id'), 64)
    send_src = _safe_str(merged.get('send_source'), 160)
    tel_bk = _telemetry_flow_for_bundle_kind(bundle_kind)
    with _lock:
        now = _mono()
        _session = {
            'start_mono': now,
            'start_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'last_milestone_mono': now,
            'milestones': [],
            'counts': {},
            'snapshot_events': [],
            'send_source': send_src,
            'flow': flow,
            'telemetry_bundle_kind': tel_bk,
            'telemetry_send_source': send_src,
            'telemetry_job_id': job_id,
        }
        if bundle_kind:
            _session['counts']['bundle_kind_resolved'] = _telemetry_flow_for_bundle_kind(bundle_kind)


def telemetry_ensure_started_from_extra_meta(extra_meta, bundle_kind=''):
    """Backward-compatible name: always scopes telemetry to this bundle collect."""
    telemetry_begin_collect_session(extra_meta, bundle_kind)


def telemetry_record_milestone(name, subsystem=None):
    """Record a progress stage (heartbeat label)."""
    global _session
    label = _safe_str(name, 200)
    if not label:
        return
    now = _mono()
    with _lock:
        if _session is None:
            return
        prev = _session.get('last_milestone_mono')
        delta = None if prev is None else round(now - prev, 4)
        start = _session.get('start_mono', now)
        cumulative = round(now - start, 4)
        entry = {
            'name': label,
            'delta_sec': delta,
            'cumulative_sec': cumulative,
        }
        if subsystem:
            entry['subsystem'] = _safe_str(subsystem, 32)
        mlist = _session.setdefault('milestones', [])
        if len(mlist) < _MAX_MILESTONES:
            mlist.append(entry)
        _session['last_milestone_mono'] = now


def telemetry_merge_collect_counts(extra_files_count=0, max_log_lines=0):
    with _lock:
        if _session is None:
            return
        c = _session.setdefault('counts', {})
        try:
            c['extra_files'] = int(extra_files_count)
        except Exception:
            c['extra_files'] = extra_files_count
        try:
            c['max_log_lines'] = int(max_log_lines)
        except Exception:
            c['max_log_lines'] = max_log_lines


def telemetry_record_snapshot_build(elapsed_sec, artifact_file_count=0, cache_hit=False):
    with _lock:
        if _session is None:
            return
        ev = {
            'elapsed_sec': round(float(elapsed_sec or 0), 4),
            'artifact_file_count': int(artifact_file_count or 0),
            'cache_hit': bool(cache_hit),
        }
        lst = _session.setdefault('snapshot_events', [])
        if len(lst) < _MAX_SNAPSHOT_EVENTS:
            lst.append(ev)
        ctr = _session.setdefault('counts', {})
        if cache_hit:
            ctr['snapshot_cache_hits'] = int(ctr.get('snapshot_cache_hits', 0) or 0) + 1
        else:
            ctr['snapshot_builds'] = int(ctr.get('snapshot_builds', 0) or 0) + 1


def telemetry_finalize_for_meta(bundle_kind=''):
    """Return JSON-safe dict for meta.json; does not clear session."""
    with _lock:
        if _session is None:
            return {
                'schema_version': SCHEMA_VERSION,
                'session_active': False,
                'telemetry_bundle_kind': _telemetry_flow_for_bundle_kind(bundle_kind),
                'telemetry_send_source': '',
                'telemetry_job_id': '',
            }
        s = _session
        end = _mono()
        start = s.get('start_mono', end)
        expected_flow = _telemetry_flow_for_bundle_kind(bundle_kind)
        session_flow = _safe_str(s.get('flow', ''), 64)
        coherence = ''
        trust_timing = True
        if expected_flow and session_flow and session_flow != expected_flow:
            coherence = 'flow_mismatch'
            trust_timing = False
        total = round(end - start, 4) if trust_timing else 0.0
        counts = dict(s.get('counts') or {})
        if bundle_kind:
            counts['bundle_kind'] = _telemetry_flow_for_bundle_kind(bundle_kind)
        tel_bk = _telemetry_flow_for_bundle_kind(bundle_kind) or s.get('telemetry_bundle_kind', '')
        tel_send = _safe_str(s.get('telemetry_send_source') or s.get('send_source', ''), 160)
        tel_job = _safe_str(s.get('telemetry_job_id', ''), 64)
        milestones = list(s.get('milestones') or []) if trust_timing else []
        snapshots = list(s.get('snapshot_events') or []) if trust_timing else []
        out = {
            'schema_version': SCHEMA_VERSION,
            'session_start_utc': s.get('start_utc', '') if trust_timing else '',
            'total_build_sec': total,
            'flow': expected_flow or session_flow,
            'send_source': s.get('send_source', ''),
            'telemetry_bundle_kind': tel_bk,
            'telemetry_send_source': tel_send,
            'telemetry_job_id': tel_job,
            'milestones': milestones,
            'counts': counts,
            'snapshot_events': snapshots,
        }
        if coherence:
            out['bundle_build_telemetry_coherence'] = coherence
        if not trust_timing:
            out['timing_trusted_for_current_bundle'] = False
        return out


def resolve_bundle_telemetry_log_level(telemetry_dict):
    """Run-log level for the one-line BUNDLE_TELEMETRY summary: DEBUG by default, INFO if forced or slow build."""
    try:
        from MediCafe.MediLink_ConfigLoader import is_env_truthy
        if is_env_truthy('MEDICAFE_BUNDLE_TELEMETRY_INFO'):
            return 'INFO'
    except Exception:
        if str(os.environ.get('MEDICAFE_BUNDLE_TELEMETRY_INFO', '') or '').strip().lower() in ('1', 'true', 'yes', 'on'):
            return 'INFO'
    if isinstance(telemetry_dict, dict):
        if telemetry_dict.get('bundle_build_telemetry_coherence') == 'flow_mismatch':
            return 'DEBUG'
        try:
            total = float(telemetry_dict.get('total_build_sec', 0) or 0)
            if total >= BUNDLE_TELEMETRY_LOG_INFO_SLOW_SEC:
                return 'INFO'
        except Exception:
            pass
    return 'DEBUG'


def _is_gmail_related_milestone(name):
    n = str(name or '').lower()
    for token in ('gmail', 'sign-in', 'token', 'assembling email', 'sending email to support'):
        if token in n:
            return True
    if 'checking gmail' in n:
        return True
    return False


def format_bundle_telemetry_log_line(telemetry_dict, max_len=720):
    """Single-line ASCII summary for mc_log (prefers pre-email slow stages)."""
    if not isinstance(telemetry_dict, dict):
        return 'BUNDLE_TELEMETRY schema=1 error=invalid_dict'
    if telemetry_dict.get('bundle_build_telemetry_coherence') == 'flow_mismatch':
        parts = [
            'BUNDLE_TELEMETRY',
            'schema={0}'.format(SCHEMA_VERSION),
            'coherence=flow_mismatch',
            'kind={0}'.format(str(telemetry_dict.get('telemetry_bundle_kind') or telemetry_dict.get('flow') or '-')[:48]),
        ]
        return ' '.join(parts)[:max_len]
    if not telemetry_dict.get('session_start_utc') and not telemetry_dict.get('milestones'):
        parts = ['BUNDLE_TELEMETRY', 'schema={0}'.format(SCHEMA_VERSION), 'active=0']
        return ' '.join(parts)[:max_len]
    kind = str(
        telemetry_dict.get('telemetry_bundle_kind')
        or telemetry_dict.get('counts', {}).get('bundle_kind', '')
        or telemetry_dict.get('flow', '')
        or '-'
    )
    total = telemetry_dict.get('total_build_sec', 0)
    milestones = telemetry_dict.get('milestones') or []
    ranked = []
    for m in milestones:
        if not isinstance(m, dict):
            continue
        name = m.get('name', '')
        d = m.get('delta_sec')
        if d is not None and not _is_gmail_related_milestone(name):
            try:
                ranked.append((float(d), str(name)))
            except Exception:
                pass
    ranked.sort(key=lambda x: -x[0])
    top_parts = []
    for d, name in ranked[:3]:
        short = name.replace(' ', '_')[:40]
        top_parts.append('{0}:{1}s'.format(short, round(d, 2)))
    top_s = ','.join(top_parts) if top_parts else '-'
    snap_n = len(telemetry_dict.get('snapshot_events') or [])
    chits = telemetry_dict.get('counts', {}).get('snapshot_cache_hits', 0)
    parts = [
        'BUNDLE_TELEMETRY',
        'schema={0}'.format(SCHEMA_VERSION),
        'kind={0}'.format(kind[:48] if kind else '-'),
        'total_s={0}'.format(total),
        'top={0}'.format(top_s),
        'snap_events={0}'.format(snap_n),
        'snap_cache_hits={0}'.format(chits),
    ]
    line = ' '.join(parts)
    if len(line) > max_len:
        return line[: max_len - 3] + '...'
    return line
