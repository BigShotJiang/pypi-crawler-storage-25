#!/usr/bin/env python
"""
Bounded read-only on-prem self-test registry.

The support-bundle entry point consumes only the compact summary returned by
collect_self_test_summary(). Keep this module Python 3.4 compatible.
"""
from __future__ import print_function

import json
import os
import platform
import sys
import time


SCHEMA_VERSION = 1
REGISTRY_VERSION = 2
RISK_READ_ONLY = 'read_only'
STATUS_PASS = 'pass'
STATUS_FAIL = 'fail'
STATUS_WARNING = 'warning'

REQUIRED_CHECK_FIELDS = (
    'id',
    'title',
    'risk_class',
    'requires_network',
    'uses_patient_data',
    'writes_production_data',
    'timeout_sec',
    'artifact_paths',
)

_MAX_FAILING_IDS = 12
_MAX_WARNING_IDS = 12


def _utc_timestamp():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _safe_text(value, max_len=160):
    try:
        if value is None:
            text = ''
        elif isinstance(value, bytes):
            try:
                text = value.decode('ascii', 'ignore')
            except Exception:
                text = value.decode('utf-8', 'ignore')
        else:
            text = str(value)
    except Exception:
        text = ''
    text = text.replace('\r', ' ').replace('\n', ' ').strip()
    if len(text) > max_len:
        return text[:max_len]
    return text


def _runtime_medi(runtime_context):
    if isinstance(runtime_context, dict):
        medi = runtime_context.get('medi')
        if isinstance(medi, dict):
            return medi
        config = runtime_context.get('config')
        if isinstance(config, dict):
            medi = config.get('MediLink_Config')
            if isinstance(medi, dict):
                return medi
    return {}


def _environment_fingerprint(runtime_context=None):
    medi = _runtime_medi(runtime_context)
    local_storage_path = medi.get('local_storage_path')
    return {
        'python_version': _safe_text(sys.version.split(' ')[0], 32),
        'python_major_minor': '{0}.{1}'.format(sys.version_info[0], sys.version_info[1]),
        'platform_system': _safe_text(platform.system(), 64),
        'platform_release': _safe_text(platform.release(), 64),
        'platform_machine': _safe_text(platform.machine(), 64),
        'has_local_storage_path': bool(local_storage_path),
        'test_mode': bool(medi.get('TestMode', False)),
    }


def _check_python_runtime(runtime_context):
    if sys.version_info[0] != 3:
        return _result(STATUS_FAIL, 'python_major_version_not_3')
    if sys.version_info < (3, 4):
        return _result(STATUS_FAIL, 'python_version_below_3_4')
    return _result(STATUS_PASS, 'python_runtime_available')


def _check_local_storage_path_declared(runtime_context):
    medi = _runtime_medi(runtime_context)
    path = medi.get('local_storage_path')
    if not path:
        return _result(STATUS_WARNING, 'local_storage_path_missing')
    if not isinstance(path, str):
        return _result(STATUS_WARNING, 'local_storage_path_not_text')
    return _result(STATUS_PASS, 'local_storage_path_declared')


def _check_local_storage_path_readable(runtime_context):
    medi = _runtime_medi(runtime_context)
    path = medi.get('local_storage_path')
    if not path:
        return _result(STATUS_WARNING, 'local_storage_path_missing')
    try:
        if not os.path.isdir(path):
            return _result(STATUS_WARNING, 'local_storage_path_not_directory')
        os.listdir(path)
    except Exception as exc:
        return _result(STATUS_WARNING, 'local_storage_path_not_readable:{0}'.format(exc.__class__.__name__))
    return _result(STATUS_PASS, 'local_storage_path_readable')


def _lab_root_for_db_probe(runtime_context):
    lr = ''
    if isinstance(runtime_context, dict):
        lr = _safe_text(runtime_context.get('lab_root'), 512)
        if not lr:
            medi = runtime_context.get('medi')
            if isinstance(medi, dict):
                lr = _safe_text(medi.get('lab_root') or medi.get('MEDICAFE_LAB_DIR'), 512)
    if not lr:
        lr = _safe_text(os.environ.get('MEDICAFE_LAB_DIR'), 512)
    return lr


def _read_json_dict_lab(path):
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if isinstance(payload, dict):
            return payload
    except Exception:
        return None
    return None


def _check_unified_model_db_schema_probe(runtime_context):
    """
    Read-only unified_model_xp.db integrity + ingest_artifact column drift probe.

    Skips with warning when no lab_root is available. Missing DB file is a
    warning (installations may not have created the shadow DB yet).
    """
    lr = _lab_root_for_db_probe(runtime_context)
    if not lr or not os.path.isdir(lr):
        return _result(STATUS_WARNING, 'unified_model_db_probe_skipped_no_lab')
    try:
        from MediCafe.phase_c_db_health_probe import build_phase_c_db_health_probe
    except Exception as exc:
        return _result(STATUS_WARNING, 'probe_import_failed:{0}'.format(exc.__class__.__name__))

    st = _read_json_dict_lab(os.path.join(lr, 'diagnostics_state.json'))
    doc = build_phase_c_db_health_probe(lr, st)
    flags = [str(f) for f in (doc.get('drift_flags') or []) if f]

    if 'db_file_missing' in flags and len(flags) == 1:
        return _result(STATUS_WARNING, 'unified_model_db_missing')

    hard_fail_tokens = (
        'integrity_check_failed',
        'ingest_artifact_missing',
        'ingest_artifact_column_drift',
        'sqlite_open_or_format_failed',
        'sqlite_probe_exception',
        'sqlite_unavailable',
        'db_path_unresolved',
    )
    for token in hard_fail_tokens:
        if token in flags:
            return _result(STATUS_FAIL, 'drift:{0}'.format(','.join(flags))[:96])

    if flags:
        return _result(STATUS_WARNING, 'drift:{0}'.format(','.join(flags))[:96])

    integ = _safe_text(doc.get('integrity_check'), 32).lower()
    if integ and integ != 'ok':
        return _result(STATUS_FAIL, 'integrity_not_ok')

    return _result(STATUS_PASS, 'unified_model_db_probe_ok')


def _result(status, code=''):
    return {
        'status': status,
        'code': _safe_text(code, 96),
    }


def _make_check(check_id, title, timeout_sec, artifact_paths, runner):
    return {
        'id': check_id,
        'title': title,
        'risk_class': RISK_READ_ONLY,
        'requires_network': False,
        'uses_patient_data': False,
        'writes_production_data': False,
        'timeout_sec': timeout_sec,
        'artifact_paths': list(artifact_paths or []),
        'runner': runner,
    }


def get_default_checks():
    """Return bounded read-only checks. Callers must not mutate the result."""
    return [
        _make_check(
            'runtime.python',
            'Python runtime is supported',
            1,
            [],
            _check_python_runtime,
        ),
        _make_check(
            'config.local_storage_path.declared',
            'Local storage path is declared',
            1,
            ['local_storage_path'],
            _check_local_storage_path_declared,
        ),
        _make_check(
            'config.local_storage_path.readable',
            'Local storage path is readable',
            2,
            ['local_storage_path'],
            _check_local_storage_path_readable,
        ),
        _make_check(
            'lab.unified_model_db.schema_probe',
            'Unified model SQLite integrity and ingest_artifact schema probe',
            6,
            ['MEDICAFE_LAB_DIR', 'lab_root'],
            _check_unified_model_db_schema_probe,
        ),
    ]


def validate_check_schema(check):
    """Return a list of schema/safety errors for one check declaration."""
    errors = []
    if not isinstance(check, dict):
        return ['check_not_dict']
    for field in REQUIRED_CHECK_FIELDS:
        if field not in check:
            errors.append('missing:{0}'.format(field))
    if not _safe_text(check.get('id'), 96):
        errors.append('invalid:id')
    if not _safe_text(check.get('title'), 160):
        errors.append('invalid:title')
    if check.get('risk_class') != RISK_READ_ONLY:
        errors.append('invalid:risk_class')
    for flag in ('requires_network', 'uses_patient_data', 'writes_production_data'):
        if check.get(flag) is not False:
            errors.append('unsafe:{0}'.format(flag))
    try:
        timeout = int(check.get('timeout_sec'))
        if timeout < 1 or timeout > 10:
            errors.append('invalid:timeout_sec')
    except Exception:
        errors.append('invalid:timeout_sec')
    if not isinstance(check.get('artifact_paths'), list):
        errors.append('invalid:artifact_paths')
    if not callable(check.get('runner')):
        errors.append('missing:runner')
    return errors


def _normalize_status(value):
    text = _safe_text(value, 24).lower()
    if text in (STATUS_PASS, STATUS_FAIL, STATUS_WARNING):
        return text
    return STATUS_FAIL


def _run_one_check(check, runtime_context):
    check_id = _safe_text(check.get('id'), 96)
    started = time.time()
    schema_errors = validate_check_schema(check)
    if schema_errors:
        return {
            'id': check_id or 'unknown',
            'status': STATUS_FAIL,
            'code': 'schema_error',
            'elapsed_sec': 0,
        }
    try:
        raw = check.get('runner')(runtime_context)
    except Exception as exc:
        raw = _result(STATUS_FAIL, 'exception:{0}'.format(exc.__class__.__name__))
    elapsed = round(time.time() - started, 4)
    status = STATUS_FAIL
    code = ''
    if isinstance(raw, dict):
        status = _normalize_status(raw.get('status'))
        code = _safe_text(raw.get('code'), 96)
    timeout_sec = int(check.get('timeout_sec') or 1)
    if elapsed > timeout_sec and status == STATUS_PASS:
        status = STATUS_WARNING
        code = 'timeout_exceeded'
    return {
        'id': check_id,
        'status': status,
        'code': code,
        'elapsed_sec': elapsed,
    }


def run_self_tests(checks=None, runtime_context=None, include_results=True):
    """
    Run bounded read-only checks and return summary plus optional per-check rows.

    This runner isolates failures per check. It records timeout overruns but does
    not try to kill checks, so default checks are intentionally fast and read-only.
    """
    selected = checks if checks is not None else get_default_checks()
    results = []
    for check in selected:
        results.append(_run_one_check(check, runtime_context))

    pass_count = 0
    fail_count = 0
    warning_count = 0
    failing_ids = []
    warning_ids = []
    for result in results:
        status = result.get('status')
        if status == STATUS_PASS:
            pass_count += 1
        elif status == STATUS_WARNING:
            warning_count += 1
            if len(warning_ids) < _MAX_WARNING_IDS:
                warning_ids.append(result.get('id'))
        else:
            fail_count += 1
            if len(failing_ids) < _MAX_FAILING_IDS:
                failing_ids.append(result.get('id'))

    summary = {
        'schema_version': SCHEMA_VERSION,
        'registry_version': REGISTRY_VERSION,
        'timestamp': _utc_timestamp(),
        'check_count': len(results),
        'pass_count': pass_count,
        'fail_count': fail_count,
        'warning_count': warning_count,
        'failing_check_ids': failing_ids,
        'warning_check_ids': warning_ids,
        'environment_fingerprint': _environment_fingerprint(runtime_context),
    }
    if include_results:
        summary['results'] = results
    return summary


def collect_self_test_summary(runtime_context=None):
    """Return compact JSON-safe support-bundle metadata."""
    return run_self_tests(runtime_context=runtime_context, include_results=False)
