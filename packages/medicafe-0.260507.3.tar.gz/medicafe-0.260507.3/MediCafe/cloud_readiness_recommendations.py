﻿#!/usr/bin/env python
"""
Recommendation and bundle-assembly helpers extracted from MediCafe.cloud_readiness.
"""
from __future__ import print_function

from functools import wraps


_LOCAL_HELPER_NAMES = set(['_cloud_readiness_module', '_sync_cloud_readiness_globals', '_with_cloud_readiness_globals'])


def _cloud_readiness_module():
    from MediCafe import cloud_readiness as _cr
    return _cr


def _sync_cloud_readiness_globals():
    """Copy names from cloud_readiness into this module's globals.

    Skip this module's local helpers and skip *all* dunder names so we do not
    overwrite module identity (__name__, __file__, __loader__, …). Iterating
    cloud_readiness.__dict__ is intentional: lazy shims need the full surface.
    """
    cr = _cloud_readiness_module()
    g = globals()
    for name, value in cr.__dict__.items():
        if name in _LOCAL_HELPER_NAMES:
            continue
        if name.startswith('__') and name.endswith('__'):
            continue
        g[name] = value


def _with_cloud_readiness_globals(fn):
    @wraps(fn)
    def _wrapped(*args, **kwargs):
        _sync_cloud_readiness_globals()
        return fn(*args, **kwargs)
    return _wrapped


@_with_cloud_readiness_globals
def _build_recommendation_action_scaffold(
        recommended_action_kind,
        best_now_action_kind,
        recommended_artifact_classes=None,
        action_requires_confirmation=False,
        action_preview=None,
        action_reason_lines=None,
        preferred_when_stable_action_kind=None,
        recommended_report_kind='artifact_triage_pack',
        extra_fields=None):
    payload = {
        'recommended_action_kind': str(recommended_action_kind or '').strip(),
        'preferred_when_stable_action_kind': str(
            preferred_when_stable_action_kind
            if preferred_when_stable_action_kind is not None
            else recommended_action_kind or ''
        ).strip(),
        'best_now_action_kind': str(best_now_action_kind or '').strip(),
        'recommended_report_kind': str(recommended_report_kind or 'artifact_triage_pack').strip(),
        'recommended_artifact_classes': list(recommended_artifact_classes or []),
        'action_requires_confirmation': bool(action_requires_confirmation),
        'action_preview': action_preview if isinstance(action_preview, dict) else {},
        'action_reason_lines': list(action_reason_lines or []),
    }
    if isinstance(extra_fields, dict):
        payload.update(extra_fields)
    return payload


@_with_cloud_readiness_globals
def _load_diagnostics_state(lab_root):
    diagnostics_state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    return diagnostics_state


@_with_cloud_readiness_globals
def _diagnostics_section(diagnostics_state, key):
    section = diagnostics_state.get(key, {}) if isinstance(diagnostics_state, dict) else {}
    if not isinstance(section, dict):
        section = {}
    return section


@_with_cloud_readiness_globals
def _phase_c_bootstrap_self_heal_lines_from_layer1(layer1_model):
    """Render compact Phase C bootstrap/handoff hints for SHP."""
    if not isinstance(layer1_model, dict):
        return []
    stage = str(layer1_model.get('phase_c_bootstrap_stage', '') or '').strip()
    if not stage:
        return []
    return [
        ' - bootstrap_diagnostics_present={0}'.format(bool(layer1_model.get('phase_c_bootstrap_diagnostics_present'))),
        ' - bootstrap_stage={0}'.format(stage),
        ' - entrypoint_observed={0}'.format(bool(layer1_model.get('phase_c_entrypoint_observed'))),
        ' - finish_diagnostics_observed={0}'.format(bool(layer1_model.get('phase_c_finish_diagnostics_observed'))),
        ' - next_developer_action={0}'.format(str(layer1_model.get('phase_c_next_developer_action', '') or '').strip() or '-'),
    ]


@_with_cloud_readiness_globals
def _allow_interactive_reauth_for_send(send_source, operator_execution_mode):
    """
    Interactive reauth is only allowed for explicit operator/menu sends.
    Background queue and post-update autofollow flows must stay non-interactive.
    """
    mode = str(operator_execution_mode or '').strip().lower()
    source = str(send_source or '').strip().lower()
    if mode in ('background_queue', 'post_update_autofollow'):
        return False
    if source in ('post_update_cloud_autofollow', 'background_support_send_job'):
        return False
    return True

@_with_cloud_readiness_globals
def compute_operator_support_send_recommendation_core(
        repo_root,
        evaluation_snapshot,
        ok_snap,
        snap_msg,
        pipeline_running,
        recommendation_source_scope='latest_live_snapshot',
        recommendation_anchor_run_id='',
        recommendation_live_run_id='',
        recommendation_live_run_status='',
        provenance_extra_lines=None):
    """
    Shared recommendation computation for an explicit artifact evaluation snapshot + live context.
    """
    lab_root = resolve_lab_root(repo_root)
    pipeline_label = 'running' if pipeline_running else 'idle'
    phase_f_lines = _build_phase_f_lock_context_lines(lab_root)
    phase_f_lock_note = phase_f_lines[0] if phase_f_lines else ''

    snap = evaluation_snapshot if isinstance(evaluation_snapshot, dict) else {}
    nearest_complete = str(snap.get('nearest_complete_run_id', '') or '').strip()
    eval_run_id = str(snap.get('run_id', '') or '').strip()
    artifact_why = []
    preferred_when_stable = _preferred_when_stable_from_snapshot(
        ok_snap, snap, snap_msg, nearest_complete, artifact_why)

    why_lines = []
    if eval_run_id:
        why_lines.append('Evaluated artifact run_id={0}.'.format(eval_run_id))
    why_lines.extend(artifact_why)
    if pipeline_running:
        why_lines.append('Shadow pipeline is running; bundle contents may still be changing.')
    if phase_f_lock_note:
        why_lines.append(phase_f_lock_note)
    if isinstance(provenance_extra_lines, list):
        for line in provenance_extra_lines:
            msg = str(line or '').strip()
            if msg:
                why_lines.append(msg)

    if preferred_when_stable == 'run_evidence' and pipeline_running:
        best_now_send = 'system_health'
    else:
        best_now_send = preferred_when_stable

    if pipeline_running and preferred_when_stable == 'run_evidence':
        why_summary = (
            'Pipeline is still active; a broad System Health Pack is safer now; '
            'send run evidence after the pipeline idles.')
    elif pipeline_running:
        why_summary = 'Pipeline is still active; waiting does not change the recommended bundle type.'
    elif preferred_when_stable == 'run_evidence':
        why_summary = 'Run evidence quality supports sending the coherent B..F bundle.'
    else:
        why_summary = 'Use System Health Pack for broad lab context and migration audit.'

    summary_map = {
        'run_evidence': 'Recommended: send latest run evidence bundle (phases B..F).',
        'system_health': 'Recommended: send latest System Health Pack.',
    }
    summary_line = summary_map.get(preferred_when_stable, summary_map['system_health'])

    bundle_quality = None
    if ok_snap:
        bundle_quality = _artifact_bundle_quality(snap)

    action_payload = {
        'recommended_action_kind': 'send_bundle',
        'preferred_when_stable_action_kind': 'send_bundle',
        'best_now_action_kind': 'send_bundle',
        'recommended_report_kind': 'system_health_pack' if best_now_send == 'system_health' else 'artifact_triage_pack',
        'recommended_artifact_classes': [],
        'action_requires_confirmation': False,
        'action_preview': {},
        'action_reason_lines': [],
        'recommendation_source_scope': str(recommendation_source_scope or 'latest_live_snapshot'),
        'recommendation_anchor_run_id': str(recommendation_anchor_run_id or '').strip(),
        'recommendation_live_run_id': str(recommendation_live_run_id or '').strip(),
        'recommendation_live_run_status': str(recommendation_live_run_status or '').strip(),
        'historical_reprocess_evaluated': False,
        'historical_reprocess_available': False,
        'historical_reprocess_not_triggered_reason': '',
        'dat_smoke_evaluated': False,
        'dat_smoke_available': False,
        'dat_smoke_not_triggered_reason': '',
        'dat_smoke_state_path': '',
        'dat_smoke_last_status': '',
        'dat_smoke_last_report_path': '',
        'dat_smoke_last_assessment': '',
        'dat_smoke_cooldown_until_utc': '',
        'dat_smoke_deferred_path': '',
        'dat_smoke_deferred_reason': '',
        'dat_smoke_deferred_anchor_run_id': '',
        'dat_smoke_deferred_context_run_id': '',
        'dat_smoke_deferred_issue_code': '',
        'follow_on_action_kind': '',
        'follow_on_report_kind': '',
        'follow_on_artifact_classes': [],
        'follow_on_requires_confirmation': False,
        'follow_on_summary_line': '',
        'reply_required_for_unblock': False,
        'reply_required_issue_code': '',
        'reply_required_issue_key': '',
        'step2_run_coherence': {},
    }

    diagnostics_state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    if not isinstance(diagnostics_state, dict):
        diagnostics_state = {}
    phase_c_ok = diagnostics_state.get('last_phase_c_ok')
    phase_c_err = str(diagnostics_state.get('last_phase_c_error_code', '') or '').strip()
    live_phase_c_failed = phase_c_ok is False

    if live_phase_c_failed:
        if phase_c_err:
            phase_c_skip = (
                'Phase C ingest is not OK (error_code={0}); remediate Phase C before Phase D follow-up.'
            ).format(phase_c_err)
        else:
            phase_c_skip = (
                'Phase C ingest is not OK (no error_code recorded in diagnostics); remediate Phase C before Phase D follow-up.'
            )
        hist_candidate, hist_skip = None, 'historical reprocess not triggered: {0}'.format(phase_c_skip)
        dat_candidate, dat_skip = None, 'DAT smoke not triggered: {0}'.format(phase_c_skip)
    else:
        hist_candidate, hist_skip = _build_historical_phase_d_reprocess_recommendation(
            repo_root, snap, bundle_quality, pipeline_running)
        dat_candidate, dat_skip = _build_phase_d_dat_smoke_recommendation(
            repo_root, snap, pipeline_running
        )
    action_payload['historical_reprocess_evaluated'] = bool(hist_candidate) or bool(str(hist_skip or '').strip())
    action_payload['historical_reprocess_available'] = bool(hist_candidate)
    action_payload['historical_reprocess_not_triggered_reason'] = str(hist_skip or '')
    action_payload['dat_smoke_evaluated'] = bool(dat_candidate) or bool(str(dat_skip or '').strip())
    action_payload['dat_smoke_available'] = bool(dat_candidate)
    action_payload['dat_smoke_not_triggered_reason'] = str(dat_skip or '')

    try:
        smoke_state = read_phase_d_dat_smoke_state(repo_root)
    except Exception:
        smoke_state = {}
    if not isinstance(smoke_state, dict):
        smoke_state = {}
    action_payload['dat_smoke_state_path'] = phase_d_dat_smoke_state_path(repo_root)
    action_payload['dat_smoke_last_status'] = str(smoke_state.get('last_status', '') or '').strip()
    action_payload['dat_smoke_last_report_path'] = str(smoke_state.get('last_report_path', '') or '').strip()
    action_payload['dat_smoke_last_assessment'] = str(smoke_state.get('last_assessment', '') or '').strip()
    action_payload['dat_smoke_cooldown_until_utc'] = str(smoke_state.get('cooldown_until_utc', '') or '').strip()

    qa_full_block_candidate, qa_full_block_skip = _build_phase_d_dat_qa_full_block_recommendation(
        repo_root, snap, smoke_state, pipeline_running)
    action_payload['dat_qa_full_block_evaluated'] = bool(qa_full_block_candidate) or bool(str(qa_full_block_skip or '').strip())
    action_payload['dat_qa_full_block_available'] = bool(qa_full_block_candidate)
    action_payload['dat_qa_full_block_not_triggered_reason'] = str(qa_full_block_skip or '')

    try:
        deferred_smoke = read_operator_deferred_phase_d_dat_smoke(repo_root)
    except Exception:
        deferred_smoke = None
    if not isinstance(deferred_smoke, dict):
        deferred_smoke = {}
    if deferred_smoke:
        action_payload['dat_smoke_deferred_path'] = operator_deferred_phase_d_dat_smoke_path(repo_root)
        action_payload['dat_smoke_deferred_reason'] = str(deferred_smoke.get('reason', '') or '').strip()
        action_payload['dat_smoke_deferred_anchor_run_id'] = str(deferred_smoke.get('anchor_run_id', '') or '').strip()
        action_payload['dat_smoke_deferred_context_run_id'] = str(deferred_smoke.get('context_run_id', '') or '').strip()
        action_payload['dat_smoke_deferred_issue_code'] = str(deferred_smoke.get('issue_code', '') or '').strip()

    step2 = _step2_run_coherence_from_snapshot(snap)
    action_payload['step2_run_coherence'] = step2
    if isinstance(step2, dict):
        note = str(step2.get('alignment_note', '') or '').strip()
        if note and note != 'step2_ready':
            why_lines.append('Step 2 coherence check: {0}.'.format(note))

    reply_ctx = _qa_drop_spike_reply_context(lab_root)
    action_payload['live_operator_unblock'] = {
        'reply_required': bool(reply_ctx.get('reply_required')),
        'reply_required_issue_key': str(reply_ctx.get('issue_key', '') or ''),
        'reply_required_issue_code': str(reply_ctx.get('issue_code', '') or ''),
        'deprecation_active': bool(reply_ctx.get('deprecation_active', True)),
        'closure_mode': str(reply_ctx.get('closure_mode', '') or 'none'),
        'closure_tasks': list(reply_ctx.get('closure_tasks', []) or []),
    }
    reply_append = []
    if reply_ctx.get('reply_required'):
        action_payload['reply_required_for_unblock'] = True
        action_payload['reply_required_issue_code'] = str(reply_ctx.get('issue_code', '') or '')
        action_payload['reply_required_issue_key'] = str(reply_ctx.get('issue_key', '') or '')
        reply_append.append(
            'Reply required to unblock QA drop spike follow-up: acknowledge {0} and include remediation status in the support send.'.format(
                action_payload['reply_required_issue_code']
            )
        )
    else:
        issue_code = str(reply_ctx.get('issue_code', '') or '').strip()
        closure_mode = str(reply_ctx.get('closure_mode', '') or '').strip()
        if issue_code and closure_mode == 'embedded_auto_closure':
            action_payload['reply_required_issue_code'] = issue_code
            action_payload['reply_required_issue_key'] = str(reply_ctx.get('issue_key', '') or '')
            reply_append.append(
                'Operator-reply deprecation active: {0} is auto-embedded in recommendation context (no manual reply required).'.format(
                    issue_code
                )
            )

    chosen_candidate = None
    chosen_mode = ''
    if qa_full_block_candidate:
        chosen_candidate = qa_full_block_candidate
        chosen_mode = 'dat_qa_full_block'
    elif dat_candidate:
        chosen_candidate = dat_candidate
        chosen_mode = 'dat_smoke'
        if hist_candidate:
            hist_classes = hist_candidate.get('recommended_artifact_classes', []) if isinstance(hist_candidate.get('recommended_artifact_classes', []), list) else []
            hist_label = ', '.join([str(item) for item in hist_classes if str(item or '').strip()]) or 'historical artifacts'
            action_payload['follow_on_action_kind'] = str(hist_candidate.get('recommended_action_kind', '') or 'historical_phase_d_reprocess')
            action_payload['follow_on_report_kind'] = str(hist_candidate.get('recommended_report_kind', '') or 'artifact_triage_pack')
            action_payload['follow_on_artifact_classes'] = hist_classes
            action_payload['follow_on_requires_confirmation'] = bool(hist_candidate.get('action_requires_confirmation'))
            action_payload['follow_on_summary_line'] = 'Follow-on after DAT smoke: re-evaluate historical Phase D rejects for {0}.'.format(hist_label)
    elif hist_candidate:
        chosen_candidate = hist_candidate
        chosen_mode = 'historical'

    if chosen_candidate:
        action_payload.update(chosen_candidate)
        base_reason_lines = list(chosen_candidate.get('action_reason_lines') or [])
        follow_on_summary = str(action_payload.get('follow_on_summary_line', '') or '').strip()
        if follow_on_summary:
            base_reason_lines.append(follow_on_summary)
        action_payload['action_reason_lines'] = base_reason_lines + reply_append
        why_lines.extend(base_reason_lines)
        if chosen_mode == 'dat_smoke':
            if pipeline_running:
                why_summary = 'Pipeline is still active; queue DAT smoke and auto-run it when pipeline is idle.'
                summary_line = 'Recommended after stable: run Phase D DAT smoke for anchored DAT-lane verification.'
            else:
                why_summary = 'Anchored run indicates DAT discovery but no truthful DAT-lane exercise; run DAT smoke for focused verification.'
                summary_line = 'Recommended: run Phase D DAT smoke for anchored DAT-lane verification.'
        elif chosen_mode == 'dat_qa_full_block':
            preferred_when_stable = 'run_evidence'
            best_now_send = 'run_evidence'
            if pipeline_running:
                why_summary = 'Live pipeline state is still active, but the anchored completed run already proves a DAT QA full-block; send the anchored run evidence bundle instead of asking the operator to inspect evidence manually.'
            else:
                why_summary = 'DAT smoke or anchored telemetry shows the DAT lane is exercised and fully QA-blocked; send the anchored run evidence bundle with embedded QA context instead of asking the operator to interpret raw evidence manually.'
            summary_line = 'Recommended: send anchored run evidence bundle for the DAT QA full-block anchor.'
        else:
            classes = chosen_candidate.get('recommended_artifact_classes', []) if isinstance(chosen_candidate.get('recommended_artifact_classes', []), list) else []
            class_label = ', '.join([str(item) for item in classes if str(item or '').strip()]) or 'historical artifacts'
            if pipeline_running:
                why_summary = 'Pipeline is still active; wait for idle, then re-evaluate historical Phase D rejects under the current QA logic.'
                summary_line = 'Recommended after stable: re-evaluate historical Phase D rejects for {0}.'.format(class_label)
            else:
                why_summary = 'The evaluated run is duplicate-dominant and Phase D is not selecting historical rejects; re-evaluate those rejects under current QA logic.'
                summary_line = 'Recommended: re-evaluate historical Phase D rejects for {0}.'.format(class_label)
    elif reply_append:
        action_payload['action_reason_lines'] = reply_append

    milestone_verdict = ''
    milestone_reason = ''
    anchored_milestone_run_id = str(recommendation_anchor_run_id or '').strip()
    shadow_milestone, shadow_path = _load_phase_summary_from_snapshot(snap, 'F', prefix='shadow_run_report_')
    d_summary_for_milestone, _d_path_milestone = _load_phase_summary_from_snapshot(
        snap, 'D', prefix='qa_canonical_summary_'
    )
    if not isinstance(shadow_milestone, dict):
        shadow_milestone = {}
    if not isinstance(d_summary_for_milestone, dict):
        d_summary_for_milestone = {}
    shadow_missing = not str(shadow_path or '').strip()

    derive_verdict = None
    strict_gate_for_missing = None
    strict_gate_from_payload = None
    verdict_milestone_ready = None
    try:
        from scripts.unified_model.phase_d_milestone_gate import (
            VERDICT_MILESTONE_READY,
            derive_strict_milestone_verdict,
            strict_gate_for_missing_shadow_report,
            strict_gate_from_shadow_payload,
        )
        derive_verdict = derive_strict_milestone_verdict
        strict_gate_for_missing = strict_gate_for_missing_shadow_report
        strict_gate_from_payload = strict_gate_from_shadow_payload
        verdict_milestone_ready = VERDICT_MILESTONE_READY
    except Exception:
        try:
            from phase_d_milestone_gate import (
                VERDICT_MILESTONE_READY,
                derive_strict_milestone_verdict,
                strict_gate_for_missing_shadow_report,
                strict_gate_from_shadow_payload,
            )
            derive_verdict = derive_strict_milestone_verdict
            strict_gate_for_missing = strict_gate_for_missing_shadow_report
            strict_gate_from_payload = strict_gate_from_shadow_payload
            verdict_milestone_ready = VERDICT_MILESTONE_READY
        except Exception:
            pass

    if derive_verdict and strict_gate_for_missing and strict_gate_from_payload and verdict_milestone_ready is not None:
        try:
            if shadow_missing:
                strict_gate = strict_gate_for_missing()
            else:
                sp = dict(shadow_milestone) if isinstance(shadow_milestone, dict) else {}
                strict_gate = strict_gate_from_payload(
                    sp, lab_root=lab_root, run_id=anchored_milestone_run_id or None
                )
            milestone_verdict = derive_verdict(strict_gate, d_summary_for_milestone)
            if milestone_verdict == verdict_milestone_ready:
                milestone_reason = 'milestone criteria met for DAT lane'
            else:
                reasons = list(strict_gate.get('reasons') or [])
                detail = str(strict_gate.get('detail') or '')
                milestone_reason = '; '.join(reasons) if reasons else detail
        except Exception:
            milestone_verdict = ''
            milestone_reason = ''
    action_payload['milestone_verdict'] = milestone_verdict
    action_payload['strict_milestone_verdict'] = milestone_verdict
    action_payload['milestone_reason'] = milestone_reason
    action_payload['anchored_milestone_run_id'] = anchored_milestone_run_id

    layer1_model = {}
    try:
        from MediCafe.layer1_readiness_model import build_layer1_readiness_model as _build_layer1_model

        reports_dir_snap = ''
        if isinstance(snap, dict):
            reports_dir_snap = str(snap.get('reports_dir', '') or '').strip()
        if not reports_dir_snap:
            reports_dir_snap = os.path.join(lab_root, 'reports')
        layer1_model = _build_layer1_model(
            lab_root,
            reports_dir_snap,
            diagnostics_state,
            snapshot=snap if isinstance(snap, dict) else {},
            load_json_dict_fn=_load_json_dict,
        )
    except Exception:
        layer1_model = {}

    l1_status = str(layer1_model.get('layer1_readiness_status', '') or '').strip()
    l1_blocker = str(layer1_model.get('layer1_current_blocker', '') or '').strip()
    # Keep default send_bundle when the only gate is "no DAT in manifest" (common evaluation snapshot).
    _l1_blockers_skip_rec_override = frozenset(['dat_zero_selected'])
    bundle_rec = ''
    if isinstance(bundle_quality, dict):
        bundle_rec = str(bundle_quality.get('recommendation', '') or '').strip()
    l1_override = (
        chosen_candidate is None
        and not action_payload.get('reply_required_for_unblock')
        and l1_status == 'not_reached'
        and l1_blocker
        and l1_blocker not in _l1_blockers_skip_rec_override
        and bundle_rec != 'send_current_run'
    )
    if l1_override:
        summary_line = str(layer1_model.get('next_operator_action', '') or '').strip()
        if not summary_line:
            summary_line = 'Layer 1 did not run: resolve upstream blocker ({0}).'.format(l1_blocker)
        why_summary = summary_line
        why_lines.append('Layer 1 readiness: {0}'.format(summary_line))
        action_payload['recommended_action_kind'] = 'resolve_layer1_upstream_blocker'
        action_payload['preferred_when_stable_action_kind'] = 'resolve_layer1_upstream_blocker'
        action_payload['best_now_action_kind'] = 'resolve_layer1_upstream_blocker'
        action_payload['recommended_report_kind'] = 'system_health_pack'
        action_payload['operator_manual_review_required'] = False
        best_now_send = 'system_health'
        preferred_when_stable = 'system_health'

    out = {
        'primary_send': preferred_when_stable,
        'preferred_when_stable': preferred_when_stable,
        'best_now_send': best_now_send,
        'summary_line': summary_line,
        'why_lines': why_lines,
        'why_summary': why_summary,
        'pipeline_label': pipeline_label,
        'pipeline_running': pipeline_running,
        'phase_f_lock_note': phase_f_lock_note,
        'bundle_quality': bundle_quality,
        'nearest_complete_run_id': nearest_complete,
        'run_id': eval_run_id,
    }
    out.update(action_payload)
    if isinstance(layer1_model, dict) and layer1_model:
        out['layer1_readiness'] = layer1_model
    # Phase D resolver classification is anchored on completed-run telemetry mirrored in diagnostics;
    # cloud_health_alert_state is delivery-dedupe only and must not override issue_code here.
    try:
        diag = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
        rem = diag.get('phase_d_remediation') if isinstance(diag.get('phase_d_remediation'), dict) else {}
        if rem:
            out['phase_d_remediation'] = rem
            why_lines.extend(_artifact_tools.format_phase_d_remediation_surfaces(rem))
            out['why_lines'] = why_lines
    except Exception:
        pass
    return out

@_with_cloud_readiness_globals
def compute_operator_support_send_recommendation(repo_root, env_flag_fn=None):
    """
    Operator UX: view model for the next recommended action plus bundle choice.
    Returns legacy send fields for compatibility and richer action fields for embedded remediation flows.
    Uses the same anchored evaluation snapshot selection as System Health Pack / triage when resolvable.
    """
    lab_root = resolve_lab_root(repo_root)
    pipeline_running = is_pipeline_running(lab_root)
    state = _load_json_dict(os.path.join(lab_root, 'diagnostics_state.json'))
    env_fn = env_flag_fn if env_flag_fn is not None else _default_env_flag
    pack_context = {}
    try:
        artifacts = _collect_system_health_artifacts(repo_root, env_fn, include_delivery_status=False)
        if isinstance(artifacts, dict):
            artifacts['repo_root'] = repo_root
        reports_dir = artifacts.get('reports_dir', os.path.join(lab_root, 'reports'))
        pack_context = _build_system_health_pack_context(lab_root, reports_dir, artifacts)
    except Exception:
        pack_context = {}
    try:
        ok_sel, msg_sel, eval_snap, rec_meta = _select_evaluation_snapshot_for_recommendation(
            repo_root, pack_context)
    except Exception:
        ok_sel, msg_sel, eval_snap, rec_meta = False, '', {}, {}
    if not isinstance(eval_snap, dict):
        eval_snap = {}
    if not isinstance(rec_meta, dict):
        rec_meta = {}
    live_status = _derive_live_pipeline_status(state, pipeline_running)
    live_id = str(rec_meta.get('live_run_id', '') or '').strip()
    prov = []
    fn = rec_meta.get('fallback_note')
    if fn:
        prov.append(fn)
    nn = rec_meta.get('newer_live_context_note')
    if nn:
        prov.append(nn)
    return compute_operator_support_send_recommendation_core(
        repo_root,
        eval_snap,
        ok_sel,
        msg_sel,
        pipeline_running,
        recommendation_source_scope=str(rec_meta.get('recommendation_source_scope', '') or 'latest_live_snapshot'),
        recommendation_anchor_run_id=str(rec_meta.get('recommendation_anchor_run_id', '') or ''),
        recommendation_live_run_id=live_id,
        recommendation_live_run_status=live_status,
        provenance_extra_lines=prov or None,
    )

@_with_cloud_readiness_globals
def _write_xp_phase_smoke_latest(repo_root, lab_root):
    """
    Build the observational XP phase/interface smoke report for bundle attachment.

    This is intentionally non-interactive and does not run the pipeline.  It
    gives the developer a compact phase-boundary view in every System Health
    Pack without asking the XP operator to run a separate command.
    """
    try:
        import imp as _imp
        import json as _json
        import os as _os
    except Exception:
        return ('', '', {})
    lab_root = str(lab_root or '').strip()
    repo_root = str(repo_root or '').strip()
    if not lab_root or not repo_root:
        return ('', '', {})
    script = _os.path.join(repo_root, 'scripts', 'unified_model', 'xp_phase_smoke.py')
    if not _os.path.isfile(script):
        return ('', '', {})
    try:
        mod = _imp.load_source('_medicafe_xp_phase_smoke_bundle', script)
        result = mod.build_smoke_result(lab_root)
        reports_dir = _os.path.join(lab_root, 'reports')
        json_path = _os.path.join(reports_dir, 'xp_phase_smoke_latest.json')
        txt_path = _os.path.join(reports_dir, 'xp_phase_smoke_latest.txt')
        wrote_json = False
        wrote_txt = False
        if callable(getattr(mod, '_write_json', None)):
            wrote_json = bool(mod._write_json(json_path, result))
        else:
            if not _os.path.isdir(reports_dir):
                _os.makedirs(reports_dir)
            with open(json_path, 'w') as handle:
                _json.dump(result, handle, sort_keys=True, indent=2)
                handle.write('\n')
            wrote_json = True
        if callable(getattr(mod, '_write_txt', None)):
            mod._write_txt(txt_path, result)
            wrote_txt = _os.path.isfile(txt_path)
        return (json_path if wrote_json and _os.path.isfile(json_path) else '',
                txt_path if wrote_txt and _os.path.isfile(txt_path) else '',
                result if isinstance(result, dict) else {})
    except Exception:
        return ('', '', {})


@_with_cloud_readiness_globals
def open_latest_system_health_pack(
        repo_root,
        env_flag_fn,
        include_delivery_status=False,
        progress_callback=None,
        include_guided_patient_preview=True):
    """
    Build and return latest combined system-health pack text snapshot.
    Includes current pipeline health, latest migration-audit hints, and artifact pointers.
    """
    try:
        _emit_progress(progress_callback, 'locating latest artifacts')
        artifacts = _collect_system_health_artifacts(
            repo_root, env_flag_fn, include_delivery_status=include_delivery_status)
        if isinstance(artifacts, dict):
            artifacts['repo_root'] = repo_root
        lab_root = artifacts.get('lab_root')
        reports_dir = artifacts.get('reports_dir')
        smoke_json_path, smoke_txt_path, smoke_result = _write_xp_phase_smoke_latest(repo_root, lab_root)
        pack_context = _build_system_health_pack_context(lab_root, reports_dir, artifacts)

        _emit_progress(progress_callback, 'reading health snapshot')
        health_lines = get_health_lines(lab_root, env_flag_fn, send_escalation=False)
        hints = []
        audit_payload = _load_json_dict(artifacts.get('audit_summary_json'))
        if audit_payload:
            hints = _audit_hint_lines_from_payload(audit_payload)
        alignment = _build_system_health_alignment_notes(lab_root, reports_dir, artifacts, audit_payload)

        lines = []
        lines.append('System Health Pack')
        lines.append('generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())))
        lines.append('lab_root={0}'.format(lab_root or '(unset)'))
        lines.append('pack_anchor_run_id={0}'.format(pack_context.get('anchor_run_id', '') or '-'))
        lines.append('pack_scope={0}'.format(pack_context.get('pack_scope', '') or 'unknown'))
        if pack_context.get('active_run_id'):
            lines.append('pack_live_active_run_id={0}'.format(pack_context.get('active_run_id')))
        if pack_context.get('expected_shadow_run_id'):
            lines.append('pack_last_completed_run_id={0}'.format(pack_context.get('expected_shadow_run_id')))
        machine_ctx = _load_shadow_report_machine_context(pack_context.get('anchor_report_path') or artifacts.get('shadow_report_path'))
        if machine_ctx:
            lines.append(
                'machine_fingerprint=host:{0}, app_version:{1}, python:{2}, platform:{3}, test_mode:{4}'.format(
                    machine_ctx.get('machine_hostname', '') or '-',
                    machine_ctx.get('machine_app_version', '') or '-',
                    machine_ctx.get('machine_python_version', '') or '-',
                    machine_ctx.get('machine_platform', '') or '-',
                    machine_ctx.get('machine_test_mode', 'unknown') if machine_ctx.get('machine_test_mode') is not None else 'unknown',
                )
            )
        lines.append('')
        lines.append('Latest artifacts:')
        lines.append(' - consolidated_snapshot={0}'.format(artifacts.get('consolidated_path') or '(missing)'))
        lines.append(' - migration_audit_summary_txt={0}'.format(artifacts.get('audit_summary_txt') or '(missing)'))
        lines.append(' - migration_audit_summary_json={0}'.format(artifacts.get('audit_summary_json') or '(missing)'))
        lines.append(' - migration_audit_metrics_json={0}'.format(artifacts.get('audit_metrics_json') or '(missing)'))
        lines.append(' - shadow_run_report={0}'.format(artifacts.get('shadow_report_path') or '(missing)'))
        lines.append(' - shadow_evidence_index={0}'.format(artifacts.get('shadow_index_path') or '(missing)'))
        lines.append(' - phase_f_mismatch={0}'.format(artifacts.get('phase_f_mismatch_path') or '(missing)'))
        if artifacts.get('delivery_status_path'):
            lines.append(' - report_delivery_status={0}'.format(artifacts.get('delivery_status_path')))
        if smoke_json_path:
            lines.append(' - xp_phase_smoke_json={0}'.format(smoke_json_path))
        if smoke_txt_path:
            lines.append(' - xp_phase_smoke_txt={0}'.format(smoke_txt_path))
        if artifacts.get('consolidated_message') and not artifacts.get('consolidated_ok'):
            lines.append(' - consolidated_snapshot_refresh_error={0}'.format(artifacts.get('consolidated_message')))

        lines.append('')
        lines.extend(_build_anchor_run_snapshot_lines(pack_context))

        if _should_show_latest_live_pipeline_attempt(pack_context):
            lines.append('')
            lines.extend(_build_latest_live_pipeline_attempt_lines(pack_context))

        lines.append('')
        scope = pack_context.get('pack_scope', '') or ''
        state_for_pack = pack_context.get('state') if isinstance(pack_context.get('state'), dict) else {}
        interrupted_pack = str(state_for_pack.get('last_shadow_pipeline_outcome', '') or '').strip().lower() == 'interrupted'
        mixed_or_interrupt = scope == 'mixed_scope' or interrupted_pack
        if mixed_or_interrupt:
            lines.append('Latest completed phase summaries (from live diagnostics state):')
        elif scope == 'live_current_state':
            lines.append('Pipeline health snapshot (live current state):')
        else:
            lines.append('Pipeline health snapshot:')
        lines.extend(health_lines or [])
        lines.append('Note: phase detail rows B..E reflect per-run summary counts from the live diagnostics state file; the data plane section below is cumulative lab state.')
        if scope == 'mixed_scope':
            lines.append(
                'Note: when a newer live run differs from the anchored completed run, B..E rows above still describe the last completed phase telemetry captured in diagnostics; '
                'the anchored completed-run block above is the authoritative run-scoped evidence for the anchor run_id.'
            )
        if interrupted_pack:
            lines.append(
                'Note: the pipeline ended in an interruption; a newer live run may have ended before fresh per-phase summaries were written. Use the anchored completed-run block and Latest live pipeline attempt section for interpretation.'
            )

        lines.append('')
        lines.append('Migration audit quick hints:')
        for note in alignment.get('notes', []):
            lines.append(' - {0}'.format(note))
        for note in _build_phase_f_lock_context_lines(lab_root):
            lines.append(' - {0}'.format(note))
        if alignment.get('audit_stale'):
            lines.append(' - audit hints suppressed because audit summary is older than current completed-run evidence.')
        elif hints:
            for hint in hints:
                lines.append(' - {0}'.format(hint))
        else:
            lines.append(' - none (run migration health audit to populate hints)')
        lines.append('')
        lines.extend(_build_recent_shadow_run_actual_lines(
            reports_dir,
            limit=4,
            expected_run_id=alignment.get('expected_shadow_run_id', ''),
        ))
        recommendation = {}
        try:
            ok_ev, msg_ev, eval_snap, rec_meta = _select_evaluation_snapshot_for_recommendation(repo_root, pack_context)
            prov = []
            if isinstance(rec_meta, dict):
                if rec_meta.get('fallback_note'):
                    prov.append(rec_meta.get('fallback_note'))
                if rec_meta.get('newer_live_context_note'):
                    prov.append(rec_meta.get('newer_live_context_note'))
                pr = rec_meta.get('pipeline_running')
                if pr is None:
                    pr = is_pipeline_running(lab_root)
            else:
                pr = is_pipeline_running(lab_root)
                rec_meta = {}
            recommendation = compute_operator_support_send_recommendation_core(
                repo_root,
                eval_snap,
                ok_ev,
                msg_ev,
                pr,
                recommendation_source_scope=str(rec_meta.get('recommendation_source_scope', '') or 'latest_live_snapshot'),
                recommendation_anchor_run_id=str(rec_meta.get('recommendation_anchor_run_id', '') or ''),
                recommendation_live_run_id=str(rec_meta.get('live_run_id', '') or ''),
                recommendation_live_run_status=str(rec_meta.get('live_run_status', '') or ''),
                provenance_extra_lines=prov,
            )
            if not isinstance(recommendation, dict):
                recommendation = {}
        except Exception:
            recommendation = {}
        rec_lines = _artifact_tools.format_recommended_action_lines(recommendation)
        if rec_lines:
            lines.append('')
            lines.extend(rec_lines)
        try:
            from MediCafe.evidence_manifest import operator_evidence_contract_preview_lines as _ev_contract_preview

            _prev_lines = _ev_contract_preview(lab_root, recommendation)
        except Exception:
            _prev_lines = []
        if _prev_lines:
            lines.append('')
            lines.extend(_prev_lines)
        lines.append('')
        _emit_progress(progress_callback, 'sampling DB state')
        snap = _collect_data_plane_snapshot(lab_root)
        _emit_progress(progress_callback, 'building DB enrichment overview')
        lines.extend(_build_db_enrichment_overview_lines(lab_root, snapshot=snap, compact=True))
        _l1_model = {}
        lines.append('')
        lines.append('Layer 1 Readiness:')
        try:
            from MediCafe.layer1_readiness_model import (
                build_layer1_readiness_model as _build_layer1_readiness_model,
                format_layer1_readiness_lines as _format_layer1_readiness_lines,
            )
            _l1_model = _build_layer1_readiness_model(
                lab_root,
                reports_dir,
                state_for_pack,
                pack_context=pack_context,
                load_json_dict_fn=_load_json_dict,
            )
            lines.extend(_format_layer1_readiness_lines(_l1_model))
        except Exception as _l1_exc:
            lines.append(' - status=not_reached')
            lines.append(' - current_blocker=layer1_readiness_unavailable')
            lines.append(' - blocked_at_phase=-')
            lines.append(' - current_run_id=-')
            lines.append(' - Next_action: Retry after error building Layer 1 readiness ({0}).'.format(
                str(_l1_exc)[:120]))
        lines.append('')
        lines.append('Phase C Self-Heal Status:')
        try:
            from MediCafe.phase_c_self_heal_status import format_phase_c_self_heal_lines as _fmt_pc_sh

            lines.extend(_fmt_pc_sh(lab_root))
            lines.extend(_phase_c_bootstrap_self_heal_lines_from_layer1(_l1_model))
        except Exception as _pc_exc:
            lines.append(' - status=unavailable')
            lines.append(' - detail={0}'.format(str(_pc_exc)[:120]))
        if isinstance(smoke_result, dict) and smoke_result:
            lines.append('')
            lines.append('XP Phase Smoke:')
            lines.append(' - overall_status={0}'.format(str(smoke_result.get('overall_status', '') or '-')))
            lines.append(' - first_blocker={0}'.format(str(smoke_result.get('first_blocker', '') or '-')))
            phase_rows = smoke_result.get('phases')
            if isinstance(phase_rows, list):
                for row in phase_rows:
                    if not isinstance(row, dict):
                        continue
                    lines.append(' - {0}_status={1} blocker={2}'.format(
                        str(row.get('phase', '') or '-'),
                        str(row.get('status', '') or '-'),
                        str(row.get('blocker', '') or '-'),
                    ))
        lines.append('')
        lines.extend(_build_unified_db_readiness_lines(lab_root, snapshot=snap, diagnostics_state=state_for_pack))
        lines.append('')
        lines.append('Data plane snapshot (cumulative lab state):')
        if snap.get('ok'):
            # ``snap.get("counts", {})`` is None when the key exists with JSON null; guard like health.py.
            counts = snap.get('counts', {}) if isinstance(snap.get('counts', {}), dict) else {}
            patient_rows = _safe_int(counts.get('patient'), 0)
            patient_count = _safe_int(
                snap.get('patient_count_effective'),
                _safe_int(snap.get('patient_latest_identity_count'), patient_rows))
            qa_reject = _safe_int(
                snap.get('qa_reject_count_effective'),
                _safe_int(snap.get('qa_reject_count'), 0))
            projection_success = _safe_int(
                snap.get('projection_success_count_effective'),
                _safe_int(snap.get('projection_success_count'), 0))
            projection_reject = _safe_int(
                snap.get('projection_reject_count_effective'),
                _safe_int(snap.get('projection_reject_count'), 0))
            qa_scope = str(snap.get('qa_scope_version', '') or '').strip()
            projection_scope = str(snap.get('projection_scope_version', '') or '').strip()
            lines.append(' - db_status={0}'.format(snap.get('status', 'unknown')))
            lines.append(' - patient_count={0}'.format(patient_count))
            if patient_rows != patient_count:
                lines.append(' - patient_rows_raw={0}'.format(patient_rows))
            lines.append(' - qa_reject_count={0}'.format(qa_reject))
            lines.append(' - replay_pending_count={0}'.format(snap.get('replay_pending_count', 0)))
            lines.append(' - projection_success_count={0}'.format(projection_success))
            lines.append(' - projection_reject_count={0}'.format(projection_reject))
            if qa_scope or projection_scope:
                lines.append(
                    ' - quality_scope=qa_version:{0}, projection_version:{1}'.format(
                        qa_scope or '-',
                        projection_scope or '-'))
            lines.append(' - orphan_claim_lines={0}'.format(snap.get('orphan_claim_lines', 0)))
            opt_preview = []
            guided_preview_status = ''
            relational_count = (
                _safe_int(counts.get('coverage'), 0)
                + _safe_int(counts.get('encounter'), 0)
                + _safe_int(counts.get('claim'), 0)
                + _safe_int(counts.get('claim_line'), 0)
            )
            if include_guided_patient_preview and patient_count > 0 and relational_count <= 0:
                guided_preview_status = 'skipped_relational_depth_zero'
            elif include_guided_patient_preview:
                _emit_progress(progress_callback, 'sampling guided patient preview')
                conn = None
                timed_out = [False]
                start_time = time.time()

                def _guided_preview_progress():
                    try:
                        if time.time() - start_time > 5.0:
                            timed_out[0] = True
                            return 1
                    except Exception:
                        return 1
                    return 0

                try:
                    conn = sqlite3.connect(snap.get('db_path', ''))
                    conn.execute("PRAGMA foreign_keys = ON")
                    try:
                        conn.set_progress_handler(_guided_preview_progress, 1000)
                    except Exception:
                        pass
                    rows = _collect_patient_chain_rows(
                        conn,
                        limit=120,
                        projection_version_scope=projection_scope,
                    )
                    if timed_out[0]:
                        rows = []
                        guided_preview_status = 'skipped_timeout'
                    opts = _build_guided_patient_options(
                        rows,
                        _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json')),
                    )
                    for item in opts[:3]:
                        opt_preview.append(
                            '{0}:{1}(risk={2},missing={3})'.format(
                                item.get('code', '?'),
                                item.get('display_id', '-'),
                                item.get('risk_label', 'UNKNOWN'),
                                item.get('missing_count', 0),
                            )
                        )
                except Exception:
                    if timed_out[0]:
                        guided_preview_status = 'skipped_timeout'
                    else:
                        guided_preview_status = 'skipped_error'
                finally:
                    if conn is not None:
                        try:
                            conn.set_progress_handler(None, 0)
                        except Exception:
                            pass
                        try:
                            conn.close()
                        except Exception:
                            pass
            else:
                guided_preview_status = 'skipped_context_pack'
            if opt_preview:
                lines.append(' - guided_patient_options={0}'.format('; '.join(opt_preview)))
            else:
                lines.append(' - guided_patient_options={0}'.format(guided_preview_status or 'none'))
        else:
            lines.append(' - db_status=FAIL ({0})'.format(snap.get('error', 'unknown')))
        lines.append('')
        _emit_progress(progress_callback, 'building system health runbook')
        for line in _build_system_health_pack_runbook(
                lab_root,
                audit_payload,
                artifacts,
                state_override=pack_context.get('anchor_state'),
                pack_scope=pack_context.get('pack_scope', ''),
                anchor_run_id=pack_context.get('anchor_run_id', '')):
            lines.append(line)

        path = os.path.join(reports_dir, 'system_health_pack_latest.txt')
        _emit_progress(progress_callback, 'writing pack file')
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return (True, '', path)
    except Exception as e:
        return (False, str(e), None)

@_with_cloud_readiness_globals
def run_system_health_triage(
        repo_root,
        python_exe,
        env,
        env_flag_fn,
        scope='both',
        cloud_required=False,
        migration_stage='xp_validation'):
    """
    Run migration audit and refresh latest system-health pack in one action.
    Returns (ok, msg, data) where data has hints and generated artifact paths.
    """
    audit_ok, audit_msg, audit_data = run_migration_health_audit(
        repo_root,
        python_exe,
        env,
        scope=scope,
        write_report=True,
        cloud_required=cloud_required,
        migration_stage=migration_stage,
    )
    pack_ok, pack_msg, pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=False)

    hints = []
    if isinstance(audit_data, dict):
        hints = audit_data.get('hints', []) if isinstance(audit_data.get('hints', []), list) else []

    artifacts = []
    if pack_path:
        artifacts.append(pack_path)
    report_ok, _, report_path = open_latest_migration_health_report(repo_root)
    if report_ok and report_path:
        artifacts.append(report_path)

    overall_ok = bool(audit_ok and pack_ok)
    status_label = 'completed' if overall_ok else 'completed with issues'
    msg_parts = ['System health triage {0}.'.format(status_label)]
    if audit_msg:
        msg_parts.append(audit_msg)
    if pack_msg and not pack_ok:
        msg_parts.append(pack_msg)
    runbook = _build_system_health_triage_runbook(
        audit_ok=audit_ok,
        audit_data=audit_data if isinstance(audit_data, dict) else {},
        pack_ok=pack_ok,
        pack_path=pack_path,
        report_path=report_path if report_ok else '',
    )
    msg_parts.append('decision={0}'.format(runbook.get('decision', 'NO_GO')))
    if runbook.get('top_blocker'):
        msg_parts.append('blocker={0}'.format(runbook.get('top_blocker')))
    msg = ' '.join(msg_parts)
    return (overall_ok, msg, {
        'hints': hints,
        'artifacts': artifacts,
        'audit_ok': bool(audit_ok),
        'pack_ok': bool(pack_ok),
        'runbook': runbook,
        'runbook_lines': runbook.get('lines', []),
    })

@_with_cloud_readiness_globals
def send_latest_system_health_pack(
        repo_root,
        env_flag_fn,
        progress_callback=None,
        recommendation=None,
        send_source='manual_system_health_pack',
        operator_execution_mode='explicit_send_menu',
        frozen_recommendation=None,
        support_send_job_context=None):
    """
    Send latest consolidated system-health pack and related artifacts.
    On send failure, caller can open returned delivery_status_path for diagnostics.
    """
    lab_root = resolve_lab_root(repo_root)
    rec = recommendation if isinstance(recommendation, dict) else {}
    if not rec and isinstance(frozen_recommendation, dict):
        rec = dict(frozen_recommendation)
    delivery_path = ''
    _emit_progress(progress_callback, 'checking delivery preflight')
    preflight_diag = _collect_delivery_diagnostics()
    preflight_runbook = _build_delivery_runbook_lines(preflight_diag)
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    reports_err = _reports_dir_access_error(lab_root)
    if reports_err:
        return (False, reports_err, {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    _emit_progress(progress_callback, 'building system health pack')
    ok_pack, msg_pack, pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=True, progress_callback=progress_callback)
    if not ok_pack:
        return (False, msg_pack or 'Unable to build system health pack.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    _emit_progress(progress_callback, 'collecting attachments')
    artifacts = _collect_system_health_artifacts(
        repo_root, env_flag_fn, include_delivery_status=True)
    # The pipeline can finish while the initial pack is being built. Refresh the
    # human-readable pack after artifact collection so it describes the same
    # run state as the attachments selected below.
    _emit_progress(progress_callback, 'refreshing system health pack')
    ok_refresh, _msg_refresh, refreshed_pack_path = open_latest_system_health_pack(
        repo_root, env_flag_fn, include_delivery_status=True, progress_callback=progress_callback)
    if ok_refresh and refreshed_pack_path:
        pack_path = refreshed_pack_path
    delivery_path = artifacts.get('delivery_status_path') or ''
    reports_dir = os.path.join(lab_root, 'reports')
    pack_context = _build_system_health_pack_context(lab_root, reports_dir, artifacts)
    state_for_scope = pack_context.get('state') if isinstance(pack_context.get('state'), dict) else {}
    phase_run_ids = state_for_scope.get('last_shadow_pipeline_phase_run_ids', {})
    if not isinstance(phase_run_ids, dict):
        phase_run_ids = {}

    extra_files = []
    seen = set()
    _add_unique_file(extra_files, seen, pack_path, alias='system_health_pack_latest.txt')
    _add_unique_file(extra_files, seen, artifacts.get('consolidated_path'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_summary_txt'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_summary_json'))
    _add_unique_file(extra_files, seen, artifacts.get('audit_metrics_json'))
    _add_unique_file(extra_files, seen, artifacts.get('delivery_status_path'))

    phase_files = []
    layer1_debug_effective = False
    try:
        from MediCafe.layer1_readiness_model import (
            build_layer1_readiness_model as _build_l1_for_attach,
            STATUS_READY_TO_EVALUATE as _L1_READY,
            STATUS_EVALUATED_BLOCKED as _L1_BLOCKED,
            STATUS_EVALUATED_OK as _L1_OK,
        )
        _l1_attach_model = _build_l1_for_attach(
            lab_root,
            reports_dir,
            state_for_scope,
            pack_context=pack_context,
            load_json_dict_fn=_load_json_dict,
        )
        if isinstance(_l1_attach_model, dict):
            _l1_status = str(_l1_attach_model.get('layer1_readiness_status', '') or '').strip()
            layer1_debug_effective = (
                not bool(_l1_attach_model.get('historical_layer1_debug_only'))
                and _l1_status in (_L1_READY, _L1_BLOCKED, _L1_OK)
            )
    except Exception:
        layer1_debug_effective = False
    for phase_specs in (
            [('artifact_discovery_summary_', None)],
            [('ingest_write_summary_', None), ('phase_c_shadow_recovery_', None)],
            [('qa_canonical_summary_', None)],
            [('projection_parity_summary_', None)],
            [('shadow_run_report_', None), ('shadow_evidence_index_', '.json'), ('phase_f_mismatch_', '.txt')]):
        for row in _select_latest_evidence_files(lab_root, phase_specs):
            phase_files.append(row)
    if not phase_files and artifacts.get('phase_f_mismatch_path'):
        phase_files = [(os.path.basename(artifacts.get('phase_f_mismatch_path')), artifacts.get('phase_f_mismatch_path'))]
    for basename, fullpath in phase_files:
        _add_unique_file(extra_files, seen, fullpath, alias=basename)
        if basename.startswith('qa_canonical_summary_') and basename.endswith('.json'):
            qa_payload = _load_json_dict(fullpath)
            if layer1_debug_effective and qa_payload.get('layer1_join_debug_generated') and qa_payload.get('layer1_support_bundle_attachment_recommended'):
                for key in ('layer1_join_debug_pack_path', 'layer1_join_debug_summary_path', 'layer1_join_debug_samples_path'):
                    layer1_path = str(qa_payload.get(key, '') or '').strip()
                    if layer1_path:
                        _add_unique_file(extra_files, seen, layer1_path, alias=os.path.basename(layer1_path))

    exec_handoff_path = str(state_for_scope.get('last_phase_c_execution_handoff_report_path') or '').strip()
    if not exec_handoff_path:
        cursor_handoff = _load_json_dict(os.path.join(lab_root, 'run_cursor.json'))
        if isinstance(cursor_handoff, dict):
            exec_handoff_path = str(cursor_handoff.get('last_phase_c_execution_handoff_report_path') or '').strip()
    if exec_handoff_path and os.path.isfile(exec_handoff_path):
        _add_unique_file(extra_files, seen, exec_handoff_path, alias=os.path.basename(exec_handoff_path))
        if exec_handoff_path.endswith('.json'):
            txt_handoff = exec_handoff_path[:-5] + '.txt'
            if os.path.isfile(txt_handoff):
                _add_unique_file(extra_files, seen, txt_handoff, alias=os.path.basename(txt_handoff))

    for path in _latest_interrupt_report_paths(lab_root):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))

    for fullpath in _collect_current_state_bundle_companion_files(repo_root, lab_root):
        _add_unique_file(extra_files, seen, fullpath)

    _sh_sys = os.path.join(reports_dir, 'phase_c_self_heal_status_latest.txt')
    if os.path.isfile(_sh_sys):
        _add_unique_file(extra_files, seen, _sh_sys, alias=os.path.basename(_sh_sys))

    current_attempt_path = os.path.join(reports_dir, 'phase_c_current_attempt_latest.json')
    if os.path.isfile(current_attempt_path):
        _add_unique_file(extra_files, seen, current_attempt_path, alias=os.path.basename(current_attempt_path))

    smoke_json_path = os.path.join(reports_dir, 'xp_phase_smoke_latest.json')
    smoke_txt_path = os.path.join(reports_dir, 'xp_phase_smoke_latest.txt')
    smoke_payload = _load_json_dict(smoke_json_path)
    for _smoke_path in (smoke_json_path, smoke_txt_path):
        if os.path.isfile(_smoke_path):
            _add_unique_file(extra_files, seen, _smoke_path, alias=os.path.basename(_smoke_path))

    for support_send_audit in (
            os.path.join(reports_dir, 'support_send_stale_preflight_latest.txt'),
            os.path.join(reports_dir, 'support_send_stale_preflight_latest.json')):
        _add_unique_file(extra_files, seen, support_send_audit, alias=os.path.basename(support_send_audit))

    for ctx_name in ('diagnostics_state.json', 'run_cursor.json'):
        _add_unique_file(extra_files, seen, os.path.join(lab_root, ctx_name), alias=ctx_name)

    post_attachment = os.path.join(lab_root, 'reports', 'post_update_autofollow_diagnostic_attachment.txt')
    if os.path.isfile(post_attachment):
        _add_unique_file(extra_files, seen, post_attachment, alias='post_update_autofollow_diagnostic_attachment.txt')

    if not extra_files:
        return (False, 'No system health artifacts found to attach.', {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

    try:
        # #region agent log
        try:
            from MediCafe.debug_bundle_perf import agent_log_bundle_event
            agent_log_bundle_event(
                'before_collect_zip',
                'cloud_readiness_recommendations.send_latest_system_health_pack',
                {'bundle_kind': 'system_health', 'extra_files_count': len(extra_files)},
                hypothesis_id='H1,H2',
            )
        except Exception:
            pass
        # #endregion agent log
        l1_pack_meta = {}
        try:
            from MediCafe.layer1_readiness_model import build_layer1_readiness_model as _build_l1_pack_meta
            from MediCafe.layer1_readiness_model import shallow_layer1_readiness_meta as _shallow_l1_meta

            _l1_for_meta = _build_l1_pack_meta(
                lab_root,
                reports_dir,
                state_for_scope,
                pack_context=pack_context,
                load_json_dict_fn=_load_json_dict,
            )
            l1_pack_meta = _shallow_l1_meta(_l1_for_meta)
        except Exception:
            l1_pack_meta = {}
        extra_meta = {
            'system_health_pack': True,
            'send_source': str(send_source or 'manual_system_health_pack'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'lab_root': lab_root,
            'email_delivery_preflight': preflight_diag,
            'recommended_action_kind': str(rec.get('recommended_action_kind', '') or ''),
            'recommended_report_kind': str(rec.get('recommended_report_kind', '') or ''),
            'recommended_summary_line': str(rec.get('summary_line', '') or ''),
            'support_send_job_context': support_send_job_context if isinstance(support_send_job_context, dict) else {},
            'operator_primary_report_surface': _artifact_tools.recommendation_operator_report_surface(rec) if rec else 'system_health_pack',
            'follow_recommendation_now': _artifact_tools.recommendation_followthrough_now(rec) if rec else '',
            'follow_recommendation_when_stable': _artifact_tools.recommendation_followthrough_when_stable(rec) if rec else '',
            'context_pack_scope': str(pack_context.get('pack_scope', '') or ''),
            'context_pack_anchor_run_id': str(pack_context.get('anchor_run_id', '') or ''),
            'anchor_run_id': str(pack_context.get('anchor_run_id', '') or ''),
            'active_run_id': str(pack_context.get('active_run_id', '') or ''),
            'last_completed_run_id': str(pack_context.get('expected_shadow_run_id', '') or state_for_scope.get('last_shadow_pipeline_run_id', '') or ''),
            'phase_run_ids': phase_run_ids,
            'diagnostics_state_scope': 'lab_root_current',
            'run_cursor_scope': 'lab_root_current',
            'coherence_status': 'review_required',
            'xp_phase_smoke_present': bool(smoke_payload),
            'xp_phase_smoke_overall_status': str(smoke_payload.get('overall_status', '') or '') if isinstance(smoke_payload, dict) else '',
            'xp_phase_smoke_first_blocker': str(smoke_payload.get('first_blocker', '') or '') if isinstance(smoke_payload, dict) else '',
        }
        if l1_pack_meta:
            for _k, _v in l1_pack_meta.items():
                extra_meta[_k] = _v
        try:
            from MediCafe.phase_c_self_heal_status import shallow_phase_c_self_heal_meta as _pc_sh_meta

            _pc_meta = _pc_sh_meta(lab_root)
            if isinstance(_pc_meta, dict):
                for _k, _v in _pc_meta.items():
                    extra_meta[_k] = _v
        except Exception:
            pass
        try:
            import sys as _sys_for_l1_rb

            from MediCafe.layer1_phase_c_runbook_helper import (
                maybe_auto_attach_layer1_runbook_for_system_health_pack as _maybe_l1_rb_auto,
            )

            _maybe_l1_rb_auto(
                repo_root,
                lab_root,
                state_for_scope,
                rec,
                extra_meta,
                lambda path, alias=None: _add_unique_file(extra_files, seen, path, alias=alias),
                python_exe=_sys_for_l1_rb.executable,
                progress_callback=progress_callback,
            )
        except Exception:
            pass
        evidence_manifest_for_zip = None
        try:
            from MediCafe import evidence_manifest as _em_manifest

            scope_note = ''
            if str(pack_context.get('pack_scope', '') or '').strip() == 'mixed_scope':
                scope_note = 'mixed_scope'
            anchor_pack = str(pack_context.get('anchor_run_id', '') or '').strip()
            active_pack = str(pack_context.get('active_run_id', '') or '').strip() or anchor_pack
            _req = _em_manifest.build_evidence_request(
                'system_health_pack',
                str(send_source or 'manual_system_health_pack'),
                lab_root,
                anchor_run_id=anchor_pack,
                active_run_id=active_pack,
                recommendation_action_kind=str(rec.get('recommended_action_kind', '') or ''),
                evidence_snapshot_mixed_note=scope_note,
            )
            evidence_manifest_for_zip = _em_manifest.resolve_evidence_manifest(_req)
        except Exception:
            evidence_manifest_for_zip = None
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=extra_files,
            progress_callback=progress_callback,
            evidence_manifest=evidence_manifest_for_zip,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', {
                'delivery_status_path': delivery_path,
                'pre_send_runbook_lines': preflight_runbook,
                'delivery_diag': preflight_diag,
            })
        ok_send, msg_send, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=_allow_interactive_reauth_for_send(
                send_source=send_source,
                operator_execution_mode=operator_execution_mode,
            ),
            progress_callback=progress_callback,
        )
        return (ok_send, msg_send, {
            'zip_path': zip_path,
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })
    except Exception as e:
        return (False, 'Error: {0}'.format(e), {
            'delivery_status_path': delivery_path,
            'pre_send_runbook_lines': preflight_runbook,
            'delivery_diag': preflight_diag,
        })

@_with_cloud_readiness_globals
def send_latest_run_evidence_bundle(
        repo_root,
        progress_callback=None,
        send_source='manual_run_evidence_bundle',
        operator_execution_mode='explicit_send_menu',
        frozen_recommendation=None,
        support_send_job_context=None):
    """Send latest coherent run-scoped evidence bundle across phases B..F."""
    if collect_support_bundle is None or submit_support_bundle_email is None:
        return (False, 'Support bundle tools unavailable.', None)

    _emit_progress(progress_callback, 'building run evidence snapshot')
    ok, msg, snapshot = _build_run_artifact_snapshot(repo_root, run_id='')
    if not ok:
        return (False, msg, None)

    recommendation = {}
    if isinstance(frozen_recommendation, dict) and frozen_recommendation:
        recommendation = dict(frozen_recommendation)
    else:
        try:
            lab_root_ev = str((snapshot or {}).get('lab_root', '') or '').strip() or resolve_lab_root(repo_root)
            reports_dir_ev = str((snapshot or {}).get('reports_dir', '') or '').strip()
            artifacts_ev = _collect_system_health_artifacts(repo_root, _default_env_flag, include_delivery_status=False)
            if isinstance(artifacts_ev, dict):
                artifacts_ev['repo_root'] = repo_root
            pack_ctx_ev = _build_system_health_pack_context(lab_root_ev, reports_dir_ev, artifacts_ev if isinstance(artifacts_ev, dict) else {})
            ok_ev, msg_ev, eval_snap, rec_meta = _select_evaluation_snapshot_for_recommendation(repo_root, pack_ctx_ev)
            prov = []
            if isinstance(rec_meta, dict):
                if rec_meta.get('fallback_note'):
                    prov.append(rec_meta.get('fallback_note'))
                if rec_meta.get('newer_live_context_note'):
                    prov.append(rec_meta.get('newer_live_context_note'))
                pr_ev = rec_meta.get('pipeline_running')
                if pr_ev is None:
                    pr_ev = is_pipeline_running(lab_root_ev)
            else:
                pr_ev = is_pipeline_running(lab_root_ev)
                rec_meta = {}
            recommendation = compute_operator_support_send_recommendation_core(
                repo_root,
                eval_snap,
                ok_ev,
                msg_ev,
                pr_ev,
                recommendation_source_scope=str(rec_meta.get('recommendation_source_scope', '') or 'latest_live_snapshot'),
                recommendation_anchor_run_id=str(rec_meta.get('recommendation_anchor_run_id', '') or ''),
                recommendation_live_run_id=str(rec_meta.get('live_run_id', '') or ''),
                recommendation_live_run_status=str(rec_meta.get('live_run_status', '') or ''),
                provenance_extra_lines=prov,
            )
            if not isinstance(recommendation, dict):
                recommendation = {}
        except Exception:
            recommendation = {}

    rec_kind = str(recommendation.get('recommended_action_kind') or '').strip()
    preview_rb = recommendation.get('action_preview') if isinstance(recommendation.get('action_preview'), dict) else {}
    anchor_for_bundle = str(recommendation.get('recommendation_anchor_run_id') or preview_rb.get('anchor_run_id') or '').strip()
    if rec_kind == 'review_dat_qa_full_block':
        if not anchor_for_bundle:
            return (False, 'Run evidence bundle requires recommendation_anchor_run_id for review_dat_qa_full_block; anchor is missing.', None)
        lab_root_try = str((snapshot or {}).get('lab_root', '') or '').strip() or resolve_lab_root(repo_root)
        ok_anchor, msg_anchor, snapshot_anchor = _build_run_artifact_snapshot(repo_root, run_id=anchor_for_bundle)
        if not ok_anchor or not isinstance(snapshot_anchor, dict):
            note_path = _write_run_evidence_anchor_resolution_note(repo_root, lab_root_try, anchor_for_bundle, msg_anchor)
            err = 'Cannot resolve anchored run evidence snapshot for run_id={0}: {1}'.format(anchor_for_bundle, msg_anchor or 'unknown')
            meta = {'anchor_run_id': anchor_for_bundle, 'lineage_note_path': note_path or ''}
            return (False, err, meta)
        snapshot = snapshot_anchor

    quality = _artifact_bundle_quality(snapshot)
    runbook_lines = [
        'Run-evidence bundle quality: score={0} label={1}'.format(
            quality.get('score'), quality.get('label')),
        'Phase coverage: complete={0} partial={1} missing={2}'.format(
            quality.get('complete'), quality.get('partial'), quality.get('missing')),
        'Recommendation: {0}'.format(quality.get('recommendation')),
    ]
    if quality.get('recommendation') == 'prefer_nearest_complete' and snapshot.get('nearest_complete_run_id'):
        runbook_lines.append('Consider inspecting/sending nearest complete run_id={0}.'.format(
            snapshot.get('nearest_complete_run_id')))
        if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
            runbook_lines.append(
                'Lab diagnostics still conflict with a clean run handoff; see triage pack and diagnostics before escalating.')
    if quality.get('recommendation') == 'review_lab_state':
        runbook_lines.append(
            'Lab diagnostics conflict with a clean run handoff; see triage pack classification and diagnostics before escalating.')
    action_lines = _artifact_tools.format_recommended_action_lines(
        recommendation,
        title='Recommended next action:',
    )
    if action_lines:
        runbook_lines.extend(action_lines)
    try:
        from MediCafe.evidence_manifest import operator_evidence_contract_preview_lines as _ev_contract_preview

        _prev_rb = _ev_contract_preview(lab_root, recommendation)
    except Exception:
        _prev_rb = []
    if _prev_rb:
        runbook_lines.append('')
        runbook_lines.extend(_prev_rb)
    if rec_kind == 'review_dat_qa_full_block':
        runbook_lines.append(
            'Bundle scope: anchored run_id={0} (review_dat_qa_full_block; not latest snapshot default).'.format(
                str(snapshot.get('run_id', '') or anchor_for_bundle or '')))
        rp = preview_rb.get('qa_reject_samples_path') if isinstance(preview_rb, dict) else None
        rp = str(rp or '').strip()
        if rp and not os.path.isfile(rp):
            runbook_lines.append(
                'QA full-block: qa_reject_samples not found on disk at expected path ({0}); attach when available.'.format(rp))

    lab_root = snapshot.get('lab_root', '')
    if lab_root:
        try:
            _write_xp_phase_smoke_latest(repo_root, lab_root)
        except Exception:
            pass
    try:
        _emit_progress(progress_callback, 'writing run evidence reports')
        triage_path = _write_artifact_triage_pack(snapshot, latest_alias=False, recommended_action=recommendation)
        index_path = _write_run_artifact_index(snapshot, latest_alias=False, recommended_action=recommendation)
    except Exception as e:
        return (False, str(e), None)

    delivery_path = ''
    delivery_ok, _, delivery_candidate = open_report_delivery_status(repo_root)
    if delivery_ok and delivery_candidate:
        delivery_path = delivery_candidate

    _emit_progress(progress_callback, 'collecting attachments')
    context_attachment_path, context_pack = _collect_run_evidence_context_attachment(
        repo_root,
        snapshot,
        progress_callback=progress_callback,
    )

    extra_files = []
    seen = set()
    _add_unique_file(extra_files, seen, triage_path)
    _add_unique_file(extra_files, seen, index_path)
    _add_unique_file(extra_files, seen, delivery_path)
    if context_attachment_path:
        _add_unique_file(extra_files, seen, context_attachment_path, alias=os.path.basename(context_attachment_path))
    bundle_scope_id = str(snapshot.get('run_id', '') or '')
    for path in _phase_d_dat_smoke_report_paths_for_run_evidence(
            repo_root, lab_root, recommendation, bundle_scope_id):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    if rec_kind == 'review_dat_qa_full_block':
        for path in _review_dat_qa_full_block_forced_attachment_paths(recommendation, lab_root):
            _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in _artifact_tools.layer1_bundle_paths_for_run_evidence(snapshot, recommendation):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in _phase_d_reprocess_report_paths_for_run_evidence(
            lab_root, recommendation, str(snapshot.get('run_id', '') or '')):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in _latest_interrupt_report_paths(lab_root, bundle_run_id=str(snapshot.get('run_id', '') or '')):
        _add_unique_file(extra_files, seen, path, alias=os.path.basename(path))
    for path in snapshot.get('artifact_files', []):
        _add_unique_file(extra_files, seen, path)
    for path in snapshot.get('context_files', []):
        _add_unique_file(extra_files, seen, path)

    lab_root_rb = str(snapshot.get('lab_root', '') or '').strip()
    if lab_root_rb:
        _sh_ev = os.path.join(lab_root_rb, 'reports', 'phase_c_self_heal_status_latest.txt')
        if os.path.isfile(_sh_ev):
            _add_unique_file(extra_files, seen, _sh_ev, alias=os.path.basename(_sh_ev))
        current_attempt_ev = os.path.join(lab_root_rb, 'reports', 'phase_c_current_attempt_latest.json')
        if os.path.isfile(current_attempt_ev):
            _add_unique_file(extra_files, seen, current_attempt_ev, alias=os.path.basename(current_attempt_ev))
        for smoke_name in ('xp_phase_smoke_latest.json', 'xp_phase_smoke_latest.txt'):
            smoke_ev = os.path.join(lab_root_rb, 'reports', smoke_name)
            if os.path.isfile(smoke_ev):
                _add_unique_file(extra_files, seen, smoke_ev, alias=os.path.basename(smoke_ev))
        post_attachment = os.path.join(lab_root_rb, 'reports', 'post_update_autofollow_diagnostic_attachment.txt')
        if os.path.isfile(post_attachment):
            _add_unique_file(extra_files, seen, post_attachment, alias='post_update_autofollow_diagnostic_attachment.txt')
        for support_send_audit in (
                os.path.join(lab_root_rb, 'reports', 'support_send_stale_preflight_latest.txt'),
                os.path.join(lab_root_rb, 'reports', 'support_send_stale_preflight_latest.json')):
            _add_unique_file(extra_files, seen, support_send_audit, alias=os.path.basename(support_send_audit))

    if not extra_files:
        return (False, 'No run artifacts found to attach.', None)

    try:
        delivery_preflight = _collect_delivery_diagnostics()
        evidence_manifest_for_zip = None
        try:
            from MediCafe import evidence_manifest as _em_manifest

            anchor_rid = str(snapshot.get('run_id', '') or anchor_for_bundle or '').strip()
            _req = _em_manifest.build_evidence_request(
                'run_evidence_bundle',
                str(send_source or 'manual_run_evidence_bundle'),
                lab_root,
                anchor_run_id=anchor_rid,
                active_run_id=anchor_rid,
                recommendation_action_kind=str(rec_kind or ''),
                failed_phase=str(recommendation.get('failed_phase', '') or '').strip(),
                error_code=str(recommendation.get('error_code', '') or '').strip(),
                follow_recommendation_now=_artifact_tools.recommendation_followthrough_now(recommendation) if recommendation else '',
                operator_manual_review_required=bool(recommendation.get('operator_manual_review_required')) if recommendation else False,
                reply_required=bool(recommendation.get('reply_required')) if recommendation else False,
            )
            _manifest = _em_manifest.resolve_evidence_manifest(_req)
            evidence_manifest_for_zip = _manifest
        except Exception:
            evidence_manifest_for_zip = None
        # #region agent log
        try:
            from MediCafe.debug_bundle_perf import agent_log_bundle_event
            agent_log_bundle_event(
                'before_collect_zip',
                'cloud_readiness_recommendations.send_latest_run_evidence_bundle',
                {
                    'bundle_kind': 'run_evidence',
                    'extra_files_count': len(extra_files),
                    'artifact_paths_in_snapshot': len(snapshot.get('artifact_files', []) or []),
                },
                hypothesis_id='H1,H2',
            )
        except Exception:
            pass
        # #endregion agent log
        l1_run_meta = {}
        try:
            from MediCafe.layer1_readiness_model import build_layer1_readiness_model as _build_l1_run_meta
            from MediCafe.layer1_readiness_model import shallow_layer1_readiness_meta as _shallow_l1_run_meta

            _diag_ev = snapshot.get('diagnostics_state', {}) if isinstance(snapshot.get('diagnostics_state'), dict) else {}
            _l1_ev = _build_l1_run_meta(
                lab_root,
                str(snapshot.get('reports_dir', '') or os.path.join(lab_root, 'reports')),
                _diag_ev,
                snapshot=snapshot if isinstance(snapshot, dict) else {},
                load_json_dict_fn=_load_json_dict,
            )
            l1_run_meta = _shallow_l1_run_meta(_l1_ev)
        except Exception:
            l1_run_meta = {}
        extra_meta_run = {
            'run_evidence_bundle': True,
            'artifact_run_id': snapshot.get('run_id', ''),
            'send_source': str(send_source or 'manual_run_evidence_bundle'),
            'operator_execution_mode': str(operator_execution_mode or 'explicit_send_menu'),
            'lab_root': lab_root,
            'email_delivery_preflight': delivery_preflight,
            'diagnostics_state_scope': 'lab_root_current',
            'run_cursor_scope': 'lab_root_current',
            'log_tail_scope': 'latest_application_log',
            'recommended_action_kind': str(recommendation.get('recommended_action_kind', '') or 'send_bundle'),
            'recommended_report_kind': str(recommendation.get('recommended_report_kind', '') or ''),
            'recommended_summary_line': str(recommendation.get('summary_line', '') or ''),
            'support_send_job_context': support_send_job_context if isinstance(support_send_job_context, dict) else {},
            'operator_primary_report_surface': _artifact_tools.recommendation_operator_report_surface(recommendation) if recommendation else 'artifact_triage_pack',
            'follow_recommendation_now': _artifact_tools.recommendation_followthrough_now(recommendation) if recommendation else '',
            'follow_recommendation_when_stable': _artifact_tools.recommendation_followthrough_when_stable(recommendation) if recommendation else '',
            'context_pack_scope': str((context_pack or {}).get('pack_scope', '') or ''),
            'context_pack_anchor_run_id': str((context_pack or {}).get('anchor_run_id', '') or ''),
        }
        if l1_run_meta:
            for _rk, _rv in l1_run_meta.items():
                extra_meta_run[_rk] = _rv
        try:
            from MediCafe.phase_c_self_heal_status import shallow_phase_c_self_heal_meta as _pc_rm_ev

            _pcm_ev = _pc_rm_ev(lab_root)
            if isinstance(_pcm_ev, dict):
                for _rk, _rv in _pcm_ev.items():
                    extra_meta_run[_rk] = _rv
        except Exception:
            pass
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta_run,
            extra_files=extra_files,
            progress_callback=progress_callback,
            evidence_manifest=evidence_manifest_for_zip,
        )
        if not zip_path:
            return (False, 'Failed to create support bundle.', {
                'run_id': snapshot.get('run_id', ''),
                'bundle_quality': quality,
                'runbook_lines': runbook_lines,
                'delivery_status_path': delivery_path,
                'context_attachment_path': context_attachment_path,
            })
        ok_send, msg_send, _ = _submit_bundle_with_delivery_diagnostics(
            zip_path=zip_path,
            allow_interactive_reauth=_allow_interactive_reauth_for_send(
                send_source=send_source,
                operator_execution_mode=operator_execution_mode,
            ),
            progress_callback=progress_callback,
        )
        return (ok_send, msg_send, {
            'zip_path': zip_path,
            'run_id': snapshot.get('run_id', ''),
            'triage_path': triage_path,
            'index_path': index_path,
            'delivery_status_path': delivery_path,
            'bundle_quality': quality,
            'runbook_lines': runbook_lines,
            'context_attachment_path': context_attachment_path,
            'recommended_action_kind': str(recommendation.get('recommended_action_kind', '') or 'send_bundle'),
        })
    except Exception as e:
        return (False, 'Error: {0}'.format(e), {
            'run_id': snapshot.get('run_id', ''),
            'bundle_quality': quality,
            'runbook_lines': runbook_lines,
            'delivery_status_path': delivery_path,
            'context_attachment_path': context_attachment_path,
            'recommended_action_kind': str(recommendation.get('recommended_action_kind', '') or 'send_bundle'),
        })

@_with_cloud_readiness_globals
def _preferred_when_stable_from_snapshot(ok_snap, snap, snap_msg, nearest_complete, artifact_why_lines):
    """
    Artifact-only preference (ignores pipeline). Mutates artifact_why_lines with quality/snapshot reasons.
    Returns preferred_when_stable: run_evidence | system_health.
    """
    if not ok_snap:
        artifact_why_lines.append(
            'Latest run evidence snapshot is not available; a system-health pack gives broader lab context.')
        if snap_msg:
            artifact_why_lines.append('Detail: {0}'.format(str(snap_msg)[:240]))
        return 'system_health'

    bundle_quality = _artifact_bundle_quality(snap)
    score = int(bundle_quality.get('score', 0))
    label = str(bundle_quality.get('label', '') or '')
    rec = str(bundle_quality.get('recommendation', '') or '')

    if rec == 'review_lab_state':
        miss = int(bundle_quality.get('missing', 0) or 0)
        if miss > 0:
            msg = (
                'Lab diagnostics (pipeline state / run alignment) are not coherent with this run_id; '
                'phase coverage is incomplete (missing phases). Prefer System Health Pack or fix diagnostics before handoff.')
            if nearest_complete:
                msg += ' Latest complete run_id={0} may be more representative.'.format(nearest_complete)
            artifact_why_lines.append(msg)
        else:
            artifact_why_lines.append(
                'Run-evidence files are complete but lab diagnostics (pipeline state / run alignment) are not coherent; '
                'prefer System Health Pack or resolve diagnostics before treating the bundle as handoff-ready.')
        return 'system_health'
    if rec == 'prefer_nearest_complete' and label == 'LOW' and nearest_complete:
        artifact_why_lines.append(
            'Run-evidence quality is LOW; latest complete run_id={0} may be more representative.'.format(
                nearest_complete))
        if _artifact_tools.artifact_snapshot_coherence_blocked(snap):
            artifact_why_lines.append(
                'Lab diagnostics still conflict with a clean handoff; prefer System Health Pack evidence before treating this run bundle as coherent.')
        return 'system_health'
    if score < 45:
        artifact_why_lines.append(
            'Run-evidence quality score is low ({0}); system-health pack adds migration audit and alignment.'.format(
                score))
        return 'system_health'
    artifact_why_lines.append(
        'Run-evidence quality {0} (score {1}); sending the coherent B..F bundle is appropriate.'.format(
            label, score))
    return 'run_evidence'

@_with_cloud_readiness_globals
def _select_evaluation_snapshot_for_recommendation(repo_root, pack_context):
    """
    Choose artifact snapshot used for bundle quality + historical reprocess.
    Returns (ok, msg, snapshot, meta) where meta includes provenance hints.
    """
    lab_root = resolve_lab_root(repo_root)
    pipeline_running = is_pipeline_running(lab_root)
    state_path = os.path.join(lab_root, 'diagnostics_state.json')
    state = _load_json_dict(state_path)
    ok_l, msg_l, latest = _build_run_artifact_snapshot(repo_root, run_id='')
    if not isinstance(latest, dict):
        latest = {}
    live_id = _derive_live_run_id_for_recommendation(state, latest)
    artifact_latest_run_id = str(latest.get('run_id', '') or '').strip()
    live_status = _derive_live_pipeline_status(state, pipeline_running)
    meta = {
        'pipeline_running': pipeline_running,
        'live_run_id': live_id,
        'live_run_status': live_status,
        'recommendation_source_scope': 'latest_live_snapshot',
        'recommendation_anchor_run_id': '',
        'fallback_note': '',
        'newer_live_context_note': '',
    }
    if not pack_context or not isinstance(pack_context, dict):
        return ok_l, msg_l, latest, meta
    pack_scope = str(pack_context.get('pack_scope', '') or '')
    anchor_id = str(pack_context.get('anchor_run_id', '') or '').strip()
    if pack_scope not in ('completed_run', 'mixed_scope') or not anchor_id:
        return ok_l, msg_l, latest, meta
    if ok_l and anchor_id == artifact_latest_run_id and isinstance(latest, dict):
        ok_a, msg_a, anchor_snap = True, '', latest
    else:
        ok_a, msg_a, anchor_snap = _build_run_artifact_snapshot(repo_root, run_id=anchor_id)
    if not ok_a or not isinstance(anchor_snap, dict):
        meta['fallback_note'] = (
            'Anchored completed-run snapshot unavailable ({0}); using latest artifact snapshot for recommendation.'
        ).format(msg_a or 'missing')
        return ok_l, msg_l, latest, meta
    anchor_eval = _relax_snapshot_diagnostics_for_anchor_evaluation(anchor_snap, anchor_id)
    if _artifact_tools.artifact_snapshot_coherence_blocked(anchor_eval):
        meta['fallback_note'] = (
            'Anchored completed-run snapshot is blocked for handoff-style evaluation; using latest artifact snapshot for recommendation.'
        )
        return ok_l, msg_l, latest, meta
    meta['recommendation_source_scope'] = 'anchored_completed_run'
    meta['recommendation_anchor_run_id'] = anchor_id
    if live_id and anchor_id and live_id != anchor_id:
        note_rid = live_id
        if artifact_latest_run_id and artifact_latest_run_id != live_id:
            note_rid = '{0} (latest artifacts run_id={1})'.format(live_id, artifact_latest_run_id)
        meta['newer_live_context_note'] = (
            'Live pipeline run_id={0} (status={1}); remediation evaluation uses anchored completed run_id={2}.'
        ).format(note_rid, live_status, anchor_id)
    elif live_status in ('failed', 'running', 'pending'):
        meta['newer_live_context_note'] = (
            'Live pipeline status={0}; remediation evaluation uses anchored completed run_id={1}.'
        ).format(live_status, anchor_id)
    return True, '', anchor_eval, meta

@_with_cloud_readiness_globals
def _build_historical_phase_d_reprocess_recommendation(repo_root, snapshot, bundle_quality, pipeline_running):
    """
    Returns (candidate_dict_or_none, skip_reason_str).
    skip_reason is non-empty when evaluation ran but did not recommend historical reprocess.
    """
    if not isinstance(snapshot, dict):
        return None, ''
    if not isinstance(bundle_quality, dict):
        return None, ''
    if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
        return None, 'historical reprocess not triggered: anchored or evaluated snapshot is not coherent enough (lab state conflicts with a clean handoff).'
    shadow_payload, _shadow_path = _load_phase_summary_from_snapshot(snapshot, 'F', prefix='shadow_run_report_')
    phase_c_payload, _phase_c_path = _load_phase_summary_from_snapshot(snapshot, 'C', prefix='ingest_write_summary_')
    phase_d_payload, _phase_d_path = _load_phase_summary_from_snapshot(snapshot, 'D', prefix='qa_canonical_summary_')

    latest_phase_c_inserted = _int_or_zero(shadow_payload.get('phase_c_inserted_count'))
    if latest_phase_c_inserted <= 0:
        latest_phase_c_inserted = _int_or_zero(phase_c_payload.get('rows_inserted'))
    latest_phase_c_skipped = _int_or_zero(shadow_payload.get('phase_c_skipped_count'))
    if latest_phase_c_skipped <= 0:
        latest_phase_c_skipped = _int_or_zero(phase_c_payload.get('rows_skipped_duplicate'))
    latest_phase_d_rows_selected = None
    if 'phase_d_rows_selected' in shadow_payload:
        latest_phase_d_rows_selected = _int_or_zero(shadow_payload.get('phase_d_rows_selected'))
    elif 'rows_selected' in phase_d_payload:
        latest_phase_d_rows_selected = _int_or_zero(phase_d_payload.get('rows_selected'))
    latest_phase_d_pass = _int_or_zero(shadow_payload.get('phase_d_pass_count'))
    if latest_phase_d_pass <= 0:
        latest_phase_d_pass = _int_or_zero(phase_d_payload.get('qa_pass_count'))
    latest_phase_d_reject = _int_or_zero(shadow_payload.get('phase_d_reject_count'))
    if latest_phase_d_reject <= 0:
        latest_phase_d_reject = _int_or_zero(phase_d_payload.get('qa_reject_count'))
    qa_policy_version = str(shadow_payload.get('phase_d_qa_policy_version', '') or phase_d_payload.get('qa_policy_version', '') or '').strip()

    if _historical_reprocess_numeric_predicates is not None:
        duplicate_dominant, no_new_phase_d_movement = _historical_reprocess_numeric_predicates(
            shadow_payload, phase_c_payload, phase_d_payload)
    else:
        duplicate_dominant = latest_phase_c_skipped > 0 and latest_phase_c_skipped >= max(1, latest_phase_c_inserted)
        if latest_phase_d_rows_selected is not None:
            no_new_phase_d_movement = (latest_phase_d_rows_selected == 0)
        else:
            no_new_phase_d_movement = (
                latest_phase_d_pass == 0 and latest_phase_d_reject == 0 and latest_phase_c_skipped > 0
            )
    if not duplicate_dominant:
        return None, 'historical reprocess not triggered: Phase C is not duplicate-dominant for this evaluated run.'
    if not no_new_phase_d_movement:
        return None, 'historical reprocess not triggered: Phase D shows new pass/reject movement or row selection for this evaluated run.'

    anchored_target_classes = _normalize_phase_d_reprocess_classes(
        phase_d_payload.get('historical_reprocess_targeted_artifact_classes', [])
    )
    anchored_reject_counts = phase_d_payload.get('historical_reject_counts_by_class', {})
    if not isinstance(anchored_reject_counts, dict):
        anchored_reject_counts = {}
    anchored_pending_counts = phase_d_payload.get('pending_replay_counts_by_class', {})
    if not isinstance(anchored_pending_counts, dict):
        anchored_pending_counts = {}
    anchored_h_by_ver = phase_d_payload.get('historical_reject_counts_by_version', {})
    if not isinstance(anchored_h_by_ver, dict):
        anchored_h_by_ver = {}
    anchored_tqv = phase_d_payload.get('targeted_qa_versions', [])
    if not isinstance(anchored_tqv, list):
        anchored_tqv = []
    if not anchored_tqv:
        anchored_tqv = [str(x) for x in anchored_h_by_ver.keys() if str(x or '').strip()]
    anchored_candidate = bool(phase_d_payload.get('historical_reprocess_candidate')) and bool(anchored_target_classes)
    anchored_reject_snapshot = None
    if anchored_candidate:
        fallback_pending_counts = {}
        for artifact_class in anchored_target_classes:
            fallback_pending_counts[artifact_class] = _int_or_zero(anchored_pending_counts.get(
                artifact_class,
                anchored_reject_counts.get(artifact_class),
            ))
        anchored_reject_snapshot = {
            'ok': True,
            'qa_version': str(phase_d_payload.get('qa_policy_version', '') or qa_policy_version or ''),
            'targeted_artifact_classes': list(anchored_target_classes),
            'reject_counts_by_class': dict(anchored_reject_counts),
            'pending_replay_counts_by_class': dict(fallback_pending_counts),
            'historical_reject_counts_by_version': dict(anchored_h_by_ver),
            'targeted_qa_versions': list(anchored_tqv),
            'source': 'anchored_phase_d_summary',
        }

    lab_root = str(snapshot.get('lab_root', '') or resolve_lab_root(repo_root)).strip()
    reject_snapshot = None
    reject_snapshot_source = ''
    live_snapshot_ok = False
    live_snapshot_reason = 'historical reprocess not triggered: could not read Phase D reject snapshot from the lab database.'
    if _collect_phase_d_reject_snapshot_impl is not None:
        try:
            live_reject_snapshot = _collect_phase_d_reject_snapshot_impl(lab_root, artifact_classes=None, qa_version=None)
        except Exception:
            live_reject_snapshot = None
        if isinstance(live_reject_snapshot, dict) and live_reject_snapshot.get('ok'):
            live_target_classes = _normalize_phase_d_reprocess_classes(
                live_reject_snapshot.get('targeted_artifact_classes', [])
            )
            live_snapshot_ok = True
            if live_target_classes:
                reject_snapshot = live_reject_snapshot
                reject_snapshot_source = 'live_phase_d_reject_snapshot'
            else:
                live_snapshot_reason = 'historical reprocess not triggered: no Phase D rejects remain for dat/csv/docx in the evaluated scope.'
        else:
            live_snapshot_reason = 'historical reprocess not triggered: could not read Phase D reject snapshot from the lab database.'
    if reject_snapshot is None and anchored_reject_snapshot is not None:
        reject_snapshot = anchored_reject_snapshot
        reject_snapshot_source = str(anchored_reject_snapshot.get('source', '') or 'anchored_phase_d_summary')
    if reject_snapshot is None:
        return None, live_snapshot_reason

    target_classes = _normalize_phase_d_reprocess_classes(reject_snapshot.get('targeted_artifact_classes', []))
    if not target_classes:
        if anchored_reject_snapshot is not None:
            reject_snapshot = anchored_reject_snapshot
            reject_snapshot_source = str(anchored_reject_snapshot.get('source', '') or 'anchored_phase_d_summary')
            target_classes = _normalize_phase_d_reprocess_classes(reject_snapshot.get('targeted_artifact_classes', []))
        if not target_classes:
            if live_snapshot_ok:
                return None, 'historical reprocess not triggered: no Phase D rejects remain for dat/csv/docx in the evaluated scope.'
            return None, live_snapshot_reason

    reject_counts = reject_snapshot.get('reject_counts_by_class', {}) if isinstance(reject_snapshot.get('reject_counts_by_class', {}), dict) else {}
    pending_counts = reject_snapshot.get('pending_replay_counts_by_class', {}) if isinstance(reject_snapshot.get('pending_replay_counts_by_class', {}), dict) else {}
    filtered_reject_counts = {}
    filtered_pending_counts = {}
    for artifact_class in target_classes:
        filtered_reject_counts[artifact_class] = _int_or_zero(reject_counts.get(artifact_class))
        filtered_pending_counts[artifact_class] = _int_or_zero(pending_counts.get(artifact_class))

    reason_lines = []
    reason_lines.append(
        'Latest Phase C inserted {0} rows and skipped {1} duplicates; this run is re-reading historical artifacts rather than introducing new ones.'.format(
            latest_phase_c_inserted,
            latest_phase_c_skipped,
        )
    )
    if latest_phase_d_rows_selected is not None:
        reason_lines.append(
            'Latest Phase D selected {0} rows for the current QA version, so rerunning D alone will not revisit the historical rejects.'.format(
                latest_phase_d_rows_selected,
            )
        )
    else:
        reason_lines.append(
            'Latest Phase D shows no new pass/reject movement while Phase C is duplicate-dominant, which is consistent with already-evaluated historical artifacts.'
        )
    tqv = reject_snapshot.get('targeted_qa_versions', [])
    if not isinstance(tqv, list):
        tqv = []
    tqv_s = ', '.join([str(x) for x in tqv if str(x or '').strip()]) or 'unknown'
    reason_lines.append(
        'Phase D rejects still exist for {0} (qa_version scope includes: {1}).'.format(
            ', '.join(target_classes),
            tqv_s,
        )
    )
    if reject_snapshot_source == 'anchored_phase_d_summary':
        reason_lines.append(
            'Using anchored Phase D summary fallback for historical replay targeting because the live reject snapshot was unavailable or empty.'
        )

    h_by_ver = reject_snapshot.get('historical_reject_counts_by_version', {})
    if not isinstance(h_by_ver, dict):
        h_by_ver = {}

    preview = {
        'qa_policy_version': qa_policy_version or str(reject_snapshot.get('qa_version', '') or ''),
        'targeted_qa_versions': tqv,
        'latest_phase_c_inserted_count': latest_phase_c_inserted,
        'latest_phase_c_skipped_count': latest_phase_c_skipped,
        'latest_phase_d_rows_selected': _int_or_zero(latest_phase_d_rows_selected),
        'latest_phase_d_pass_count': latest_phase_d_pass,
        'latest_phase_d_reject_count': latest_phase_d_reject,
        'historical_reject_counts_by_class': filtered_reject_counts,
        'historical_reject_counts_by_version': dict(h_by_ver),
        'pending_replay_counts_by_class': filtered_pending_counts,
    }

    best_now_action_kind = 'historical_phase_d_reprocess'
    if pipeline_running:
        best_now_action_kind = 'wait_for_stable'

    preview_path = ''
    preview_fn = None
    try:
        from scripts.unified_model.phase_d_historical_reprocess import preview_historical_phase_d_reprocess
        preview_fn = preview_historical_phase_d_reprocess
    except Exception:
        try:
            from phase_d_historical_reprocess import preview_historical_phase_d_reprocess
            preview_fn = preview_historical_phase_d_reprocess
        except Exception:
            preview_fn = None
    anchor_rid = str(shadow_payload.get('run_id') or snapshot.get('run_id') or '').strip()
    if preview_fn:
        try:
            prv = preview_fn(lab_root, remediation_context_run_id=anchor_rid or None)
            if isinstance(prv, dict):
                preview_path = str(prv.get('report_path') or '')
        except Exception:
            preview_path = ''

    return (_build_recommendation_action_scaffold(
        recommended_action_kind='historical_phase_d_reprocess',
        preferred_when_stable_action_kind='historical_phase_d_reprocess',
        best_now_action_kind=best_now_action_kind,
        recommended_report_kind='artifact_triage_pack',
        recommended_artifact_classes=target_classes,
        action_requires_confirmation=True,
        action_preview=preview,
        action_reason_lines=reason_lines,
        extra_fields={'historical_reprocess_preview_path': preview_path},
    ), '')

@_with_cloud_readiness_globals
def _build_phase_d_dat_smoke_recommendation(repo_root, snapshot, pipeline_running):
    """
    Returns (candidate_dict_or_none, skip_reason_str).
    Recommendation is anchored-first and pure (no subprocess side effects).
    """
    if not isinstance(snapshot, dict):
        return None, ''
    if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
        return None, 'DAT smoke not triggered: anchored or evaluated snapshot is not coherent enough for recommendation.'

    lab_root = str(snapshot.get('lab_root', '') or resolve_lab_root(repo_root)).strip()
    diagnostics_state = _load_diagnostics_state(lab_root)
    remediation = _diagnostics_section(diagnostics_state, 'phase_d_remediation')
    issue_code = str(remediation.get('issue_code', '') or '').strip()

    shadow_payload, shadow_path = _load_phase_summary_from_snapshot(snapshot, 'F', prefix='shadow_run_report_')
    phase_d_payload, _phase_d_path = _load_phase_summary_from_snapshot(snapshot, 'D', prefix='qa_canonical_summary_')
    if not isinstance(shadow_payload, dict):
        shadow_payload = {}
    if not isinstance(phase_d_payload, dict):
        phase_d_payload = {}

    anchor_run_id = str(shadow_payload.get('run_id') or snapshot.get('run_id') or '').strip()
    context_run_id = _phase_d_dat_smoke_context_run_id(phase_d_payload, anchor_run_id)

    discovery = _diagnostics_section(diagnostics_state, 'last_discovery_dat_telemetry')
    phase_d_diag = _diagnostics_section(diagnostics_state, 'last_phase_d_dat_telemetry')
    phase_d_telemetry = phase_d_payload.get('dat_telemetry') if isinstance(phase_d_payload.get('dat_telemetry'), dict) else {}

    manifest_rows = None
    if 'phase_b_dat_manifest_rows_count' in shadow_payload:
        manifest_rows = _safe_int(shadow_payload.get('phase_b_dat_manifest_rows_count'), 0)
    elif str(shadow_path or '').strip():
        manifest_rows = _safe_int(shadow_payload.get('phase_b_dat_manifest_rows_count'), 0)
    else:
        manifest_rows = _safe_int(discovery.get('dat_manifest_rows_count'), 0)
    if manifest_rows <= 0:
        return None, 'DAT smoke not triggered: Phase B DAT manifest did not indicate discovered DAT rows for the anchored run.'

    selected_source = None
    dat_selected = None
    if 'phase_d_dat_selected_count' in shadow_payload:
        selected_source = 'shadow'
        dat_selected = _safe_int(shadow_payload.get('phase_d_dat_selected_count'), 0)
    elif 'dat_selected_count' in phase_d_telemetry:
        selected_source = 'phase_d_summary'
        dat_selected = _safe_int(phase_d_telemetry.get('dat_selected_count'), 0)
    elif 'phase_d_dat_selected_count' in phase_d_payload:
        selected_source = 'phase_d_summary'
        dat_selected = _safe_int(phase_d_payload.get('phase_d_dat_selected_count'), 0)
    else:
        selected_source = 'diagnostics'
        dat_selected = _safe_int(phase_d_diag.get('dat_selected_count'), 0)
    if dat_selected != 0:
        return None, 'DAT smoke not triggered: anchored Phase D already selected DAT rows (dat_selected_count={0}).'.format(dat_selected)

    blocked_stage = ''
    if 'post_medisoft_blocked_stage' in shadow_payload:
        blocked_stage = str(shadow_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    elif 'post_medisoft_blocked_stage' in phase_d_telemetry:
        blocked_stage = str(phase_d_telemetry.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    elif 'post_medisoft_blocked_stage' in phase_d_payload:
        blocked_stage = str(phase_d_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    else:
        blocked_stage = str(phase_d_diag.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    if blocked_stage not in ('', 'not_exercised'):
        return None, 'DAT smoke not triggered: post_medisoft_blocked_stage={0} indicates the lane was already exercised.'.format(blocked_stage)

    # Exclusion: truthful DAT QA full block already present in anchored telemetry.
    qa_pass = None
    qa_reject = None
    if 'phase_d_dat_qa_pass_count' in shadow_payload:
        qa_pass = _safe_int(shadow_payload.get('phase_d_dat_qa_pass_count'), 0)
    elif 'dat_qa_pass_count' in phase_d_telemetry:
        qa_pass = _safe_int(phase_d_telemetry.get('dat_qa_pass_count'), 0)
    elif 'phase_d_dat_qa_pass_count' in phase_d_payload:
        qa_pass = _safe_int(phase_d_payload.get('phase_d_dat_qa_pass_count'), 0)
    else:
        qa_pass = _safe_int(phase_d_diag.get('dat_qa_pass_count'), 0)
    if 'phase_d_dat_qa_reject_count' in shadow_payload:
        qa_reject = _safe_int(shadow_payload.get('phase_d_dat_qa_reject_count'), 0)
    elif 'dat_qa_reject_count' in phase_d_telemetry:
        qa_reject = _safe_int(phase_d_telemetry.get('dat_qa_reject_count'), 0)
    elif 'phase_d_dat_qa_reject_count' in phase_d_payload:
        qa_reject = _safe_int(phase_d_payload.get('phase_d_dat_qa_reject_count'), 0)
    else:
        qa_reject = _safe_int(phase_d_diag.get('dat_qa_reject_count'), 0)

    telemetry_indicates_dat_qa_full_block = None
    derive_strict_milestone_verdict = None
    strict_gate_from_shadow_payload = None
    strict_gate_for_missing_shadow_report = None
    VERDICT_NOT_ADVANCED = 'Not advanced'
    try:
        from scripts.unified_model.phase_d_milestone_gate import (
            VERDICT_NOT_ADVANCED as _VERDICT_NOT_ADVANCED,
            derive_strict_milestone_verdict as _derive_strict_milestone_verdict,
            strict_gate_for_missing_shadow_report as _strict_gate_for_missing_shadow_report,
            strict_gate_from_shadow_payload as _strict_gate_from_shadow_payload,
            telemetry_indicates_dat_qa_full_block as _telemetry_indicates_dat_qa_full_block,
        )
        VERDICT_NOT_ADVANCED = _VERDICT_NOT_ADVANCED
        derive_strict_milestone_verdict = _derive_strict_milestone_verdict
        strict_gate_for_missing_shadow_report = _strict_gate_for_missing_shadow_report
        strict_gate_from_shadow_payload = _strict_gate_from_shadow_payload
        telemetry_indicates_dat_qa_full_block = _telemetry_indicates_dat_qa_full_block
    except Exception:
        try:
            from phase_d_milestone_gate import (
                VERDICT_NOT_ADVANCED as _VERDICT_NOT_ADVANCED,
                derive_strict_milestone_verdict as _derive_strict_milestone_verdict,
                strict_gate_for_missing_shadow_report as _strict_gate_for_missing_shadow_report,
                strict_gate_from_shadow_payload as _strict_gate_from_shadow_payload,
                telemetry_indicates_dat_qa_full_block as _telemetry_indicates_dat_qa_full_block,
            )
            VERDICT_NOT_ADVANCED = _VERDICT_NOT_ADVANCED
            derive_strict_milestone_verdict = _derive_strict_milestone_verdict
            strict_gate_for_missing_shadow_report = _strict_gate_for_missing_shadow_report
            strict_gate_from_shadow_payload = _strict_gate_from_shadow_payload
            telemetry_indicates_dat_qa_full_block = _telemetry_indicates_dat_qa_full_block
        except Exception:
            pass

    if telemetry_indicates_dat_qa_full_block:
        if telemetry_indicates_dat_qa_full_block({
                'dat_selected_count': dat_selected,
                'dat_qa_pass_count': qa_pass,
                'dat_qa_reject_count': qa_reject,
        }):
            return None, 'DAT smoke not triggered: anchored run already shows a truthful DAT QA full-block signal.'

    strict_milestone_verdict = ''
    if derive_strict_milestone_verdict and strict_gate_from_shadow_payload and strict_gate_for_missing_shadow_report:
        try:
            if str(shadow_path or '').strip():
                strict_gate = strict_gate_from_shadow_payload(
                    shadow_payload, lab_root=lab_root, run_id=anchor_run_id or None)
            else:
                strict_gate = strict_gate_for_missing_shadow_report()
            strict_milestone_verdict = str(
                derive_strict_milestone_verdict(strict_gate, phase_d_payload if isinstance(phase_d_payload, dict) else {})
                or ''
            ).strip()
        except Exception:
            strict_milestone_verdict = ''
    if strict_milestone_verdict != VERDICT_NOT_ADVANCED:
        lbl = strict_milestone_verdict or '(unknown)'
        return None, 'DAT smoke not triggered: strict milestone verdict is {0}, not Not advanced.'.format(lbl)

    state = read_phase_d_dat_smoke_state(repo_root)
    if _phase_d_dat_smoke_state_suppressed(state, anchor_run_id, context_run_id, issue_code):
        return None, 'DAT smoke not triggered: same anchor/context/issue is in cooldown or already running.'

    reference_phase_d_summary_path = _phase_d_dat_smoke_reference_summary_for_anchor(repo_root, anchor_run_id)
    smoke_lab_root = os.path.join(repo_root, 'phase_d_dat_smoke_lab')
    expected_report_path = os.path.join(
        smoke_lab_root,
        'reports',
        'phase_d_dat_smoke_report_<smoke_pipeline_run_id>.txt',
    )
    preview = {
        'anchor_run_id': anchor_run_id,
        'phase_d_context_run_id': context_run_id,
        'remediation_issue_code': issue_code,
        'smoke_lab_root': smoke_lab_root,
        'expected_report_path': expected_report_path,
        'reference_phase_d_summary_path': reference_phase_d_summary_path,
        'smoke_reports_dir': os.path.join(smoke_lab_root, 'reports'),
        'dat_manifest_rows_count': int(manifest_rows or 0),
        'phase_d_dat_selected_count': int(dat_selected or 0),
        'post_medisoft_blocked_stage': blocked_stage,
        'strict_milestone_verdict': strict_milestone_verdict or VERDICT_NOT_ADVANCED,
        'dat_selected_source': selected_source,
    }
    reason_lines = [
        'Anchored Phase B discovered DAT rows (phase_b_dat_manifest_rows_count={0}).'.format(int(manifest_rows or 0)),
        'Anchored Phase D did not exercise DAT lane (phase_d_dat_selected_count=0).',
        'post_medisoft_blocked_stage={0}; DAT lane remains not exercised.'.format(blocked_stage or 'not_exercised'),
        'Strict milestone verdict remains {0}.'.format(strict_milestone_verdict or VERDICT_NOT_ADVANCED),
    ]
    if reference_phase_d_summary_path:
        reason_lines.append(
            'Smoke will compare against anchored main-lab Phase D summary: {0}.'.format(reference_phase_d_summary_path)
        )
    else:
        reason_lines.append(
            'Anchored main-lab Phase D summary JSON is missing; smoke will still run but reference diff is unavailable.'
        )
    best_now_action_kind = 'phase_d_dat_smoke'
    if pipeline_running:
        best_now_action_kind = 'wait_for_stable'
    return (_build_recommendation_action_scaffold(
        recommended_action_kind='phase_d_dat_smoke',
        preferred_when_stable_action_kind='phase_d_dat_smoke',
        best_now_action_kind=best_now_action_kind,
        recommended_report_kind='artifact_triage_pack',
        recommended_artifact_classes=['dat'],
        action_requires_confirmation=False,
        action_preview=preview,
        action_reason_lines=reason_lines,
    ), '')

@_with_cloud_readiness_globals
def _build_phase_d_dat_qa_full_block_recommendation(repo_root, snapshot, smoke_state, pipeline_running):
    """
    Returns (candidate_dict_or_none, skip_reason_str).
    A truthful DAT-lane full block means smoke already exercised the lane; the next operator handoff
    is the anchored run-evidence bundle with embedded QA evidence, not a manual review step or a
    suggestion to run smoke / historical backlog replay.
    """
    if not isinstance(snapshot, dict):
        return None, ''
    if _artifact_tools.artifact_snapshot_coherence_blocked(snapshot):
        return None, 'DAT QA full-block review not triggered: anchored or evaluated snapshot is not coherent enough for recommendation.'

    smoke_state = smoke_state if isinstance(smoke_state, dict) else {}
    lab_root = str(snapshot.get('lab_root', '') or resolve_lab_root(repo_root)).strip()
    reports_dir = os.path.join(lab_root, 'reports')

    diagnostics_state = _load_diagnostics_state(lab_root)
    phase_c_ok = diagnostics_state.get('last_phase_c_ok')
    phase_c_err = str(diagnostics_state.get('last_phase_c_error_code', '') or '').strip()
    if phase_c_ok is False:
        if phase_c_err:
            return None, (
                'DAT QA full-block review suppressed: Phase C ingest is not OK (error_code={0}); remediate Phase C before anchored DAT QA review.'
            ).format(phase_c_err)
        return None, (
            'DAT QA full-block review suppressed: Phase C ingest is not OK (no error_code recorded in diagnostics); '
            'remediate Phase C before anchored DAT QA review.'
        )

    remediation = _diagnostics_section(diagnostics_state, 'phase_d_remediation')
    issue_code = str(remediation.get('issue_code', '') or '').strip()

    shadow_payload, shadow_path = _load_phase_summary_from_snapshot(snapshot, 'F', prefix='shadow_run_report_')
    phase_d_payload, phase_d_path = _load_phase_summary_from_snapshot(snapshot, 'D', prefix='qa_canonical_summary_')
    if not isinstance(shadow_payload, dict):
        shadow_payload = {}
    if not isinstance(phase_d_payload, dict):
        phase_d_payload = {}
    phase_d_telemetry = phase_d_payload.get('dat_telemetry') if isinstance(phase_d_payload.get('dat_telemetry'), dict) else {}

    anchor_run_id = str(shadow_payload.get('run_id') or snapshot.get('run_id') or '').strip()
    smoke_report = _dat_smoke_report_payload_from_state(smoke_state)
    smoke_df = smoke_report.get('dat_funnel') if isinstance(smoke_report.get('dat_funnel'), dict) else {}
    smoke_anchor_run_id = str(smoke_report.get('anchor_run_id', '') or '').strip()
    smoke_assessment = str(smoke_state.get('last_assessment', '') or smoke_report.get('assessment', '') or '').strip()
    smoke_status = str(smoke_state.get('last_status', '') or '').strip().lower()

    smoke_counters_allowed = (
        smoke_status == 'completed'
        and smoke_assessment == 'dat_selected_qa_blocked'
        and bool(anchor_run_id)
        and bool(smoke_anchor_run_id)
        and smoke_anchor_run_id == anchor_run_id
    )
    has_smoke_artifact = bool(smoke_report) or bool(str(smoke_state.get('last_report_path', '') or '').strip())
    ignored_smoke_mismatch = bool(has_smoke_artifact) and not smoke_counters_allowed
    source_mismatch_note = ''
    if ignored_smoke_mismatch:
        source_mismatch_note = (
            'Smoke on disk is not used for displayed counters: require completed smoke, '
            'assessment=dat_selected_qa_blocked, and smoke anchor_run_id matching anchored run_id={0} '
            '(smoke anchor_run_id={1}). Counts below are anchored Phase D / shadow only.'
        ).format(anchor_run_id or '-', smoke_anchor_run_id or '-')
    anchored_diagnosis_source = 'smoke_corroborated' if smoke_counters_allowed else 'anchored_phase_d_shadow'

    selected = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_selected_count', 'dat_selected_count', smoke_counters_allowed=smoke_counters_allowed)
    qa_pass = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_qa_pass_count', 'dat_qa_pass_count', smoke_counters_allowed=smoke_counters_allowed)
    qa_reject = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_qa_reject_count', 'dat_qa_reject_count', smoke_counters_allowed=smoke_counters_allowed)
    canonical = _dat_metric_from_sources(
        shadow_payload, phase_d_payload, phase_d_telemetry, smoke_df,
        'phase_d_dat_canonical_record_count', 'dat_canonical_record_count', smoke_counters_allowed=smoke_counters_allowed)
    blocked_stage = str(phase_d_telemetry.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    strict_verdict = ''
    if smoke_report:
        strict_verdict = str(smoke_report.get('strict_milestone_verdict', '') or '').strip()
        if not blocked_stage:
            blocked_stage = str(smoke_df.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    if selected is None:
        selected = 0
    if qa_pass is None:
        qa_pass = 0
    if qa_reject is None:
        qa_reject = 0
    if canonical is None:
        canonical = 0
    if not blocked_stage:
        blocked_stage = str(shadow_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()

    telemetry_full_block = False
    try:
        from scripts.unified_model.phase_d_milestone_gate import telemetry_indicates_dat_qa_full_block
        telemetry_full_block = bool(telemetry_indicates_dat_qa_full_block({
            'dat_selected_count': selected,
            'dat_qa_pass_count': qa_pass,
            'dat_qa_reject_count': qa_reject,
        }))
    except Exception:
        telemetry_full_block = bool(selected > 0 and qa_pass == 0 and qa_reject > 0)

    smoke_proves_full_block = smoke_counters_allowed
    if issue_code != 'PHASE_D_DAT_QA_FULL_BLOCK' and not telemetry_full_block and not smoke_proves_full_block:
        return None, 'DAT QA full-block review not triggered: anchored telemetry does not show a truthful DAT full-block state.'

    target_run_id = str(anchor_run_id or snapshot.get('run_id') or '').strip()
    if not target_run_id:
        return None, 'DAT QA full-block review not triggered: anchored run_id is unavailable.'

    qa_summary_path = str(phase_d_path or _safe_json_pair_path(reports_dir, 'qa_canonical_summary_', target_run_id, '.json') or '').strip()
    reject_samples_path = _safe_json_pair_path(reports_dir, 'qa_reject_samples_', target_run_id, '.jsonl')
    shadow_report_path = str(shadow_path or _safe_json_pair_path(reports_dir, 'shadow_run_report_', target_run_id, '.json') or '').strip()
    smoke_report_path = str(smoke_state.get('last_report_path', '') or '').strip()
    smoke_report_json_path = _adjacent_json_path_for_text_report(smoke_report_path)

    reason_lines = []
    if smoke_proves_full_block:
        reason_lines.append(
            'Completed DAT smoke for anchor run_id={0} shows dat_selected_qa_blocked; the lane is exercised and failing at QA rather than selection.'.format(
                smoke_anchor_run_id or target_run_id
            )
        )
    else:
        reason_lines.append(
            'Anchored Phase D telemetry shows DAT rows were selected but fully QA-blocked; the lane is exercised and failing at QA rather than selection.'
        )
    if source_mismatch_note:
        reason_lines.append(source_mismatch_note)
    reason_lines.append(
        'DAT movement: selected={0}, qa_pass={1}, qa_reject={2}, canonical={3}.'.format(
            int(selected or 0), int(qa_pass or 0), int(qa_reject or 0), int(canonical or 0)
        )
    )
    if blocked_stage:
        reason_lines.append('post_medisoft_blocked_stage={0}.'.format(blocked_stage))
    if strict_verdict:
        reason_lines.append('Smoke strict milestone verdict={0}.'.format(strict_verdict))
    if smoke_counters_allowed:
        reason_lines.append(
            'Next useful step is to send the anchored run evidence bundle; the QA summary, reject samples, and matching smoke report will be attached automatically.'
        )
    elif ignored_smoke_mismatch:
        reason_lines.append(
            'Next useful step is to send the anchored run evidence bundle; the QA summary, reject samples, and shadow report will be attached automatically, and mismatched smoke on disk will be noted but not trusted.'
        )
    else:
        reason_lines.append(
            'Next useful step is to send the anchored run evidence bundle; the QA summary, reject samples, and shadow report will be attached automatically.'
        )

    preview = {
        'anchor_run_id': target_run_id,
        'smoke_anchor_run_id': smoke_anchor_run_id,
        'phase_d_context_run_id': _phase_d_dat_smoke_context_run_id(phase_d_payload, target_run_id),
        'remediation_issue_code': issue_code or 'PHASE_D_DAT_QA_FULL_BLOCK',
        'phase_d_summary_path': qa_summary_path,
        'qa_reject_samples_path': reject_samples_path,
        'shadow_run_report_path': shadow_report_path,
        'smoke_report_path': smoke_report_path,
        'smoke_report_json_path': smoke_report_json_path,
        'smoke_assessment': smoke_assessment or 'dat_selected_qa_blocked',
        'strict_milestone_verdict': strict_verdict,
        'dat_selected_count': int(selected or 0),
        'dat_qa_pass_count': int(qa_pass or 0),
        'dat_qa_reject_count': int(qa_reject or 0),
        'dat_canonical_record_count': int(canonical or 0),
        'anchored_diagnosis_source': anchored_diagnosis_source,
        'smoke_source_accepted': bool(smoke_counters_allowed),
        'ignored_smoke_mismatch': bool(ignored_smoke_mismatch),
        'source_mismatch_note': source_mismatch_note,
    }
    for _lk in (
            'layer1_join_debug_generated',
            'layer1_join_debug_pack_path',
            'layer1_join_debug_summary_path',
            'layer1_join_debug_samples_path',
            'layer1_top_blocker',
            'layer1_csv_docx_overlap_count',
            'layer1_dat_csv_overlap_count',
            'layer1_dat_keyable_count',
            'layer1_support_bundle_attachment_recommended'):
        if phase_d_payload.get(_lk) is not None:
            preview[_lk] = phase_d_payload.get(_lk)
    if phase_d_payload.get('layer1_join_debug_generated'):
        reason_lines.append(
            'Layer 1 join debug pack is developer/support-facing (preview layer1_* paths); autonomous operator wording '
            'remains Artifact Triage Pack plus Follow recommendation.')
    return ({
        'recommended_action_kind': 'review_dat_qa_full_block',
        'preferred_when_stable_action_kind': 'review_dat_qa_full_block',
        'best_now_action_kind': 'review_dat_qa_full_block',
        'recommended_report_kind': 'artifact_triage_pack',
        'recommended_artifact_classes': ['dat'],
        'action_requires_confirmation': False,
        'action_preview': preview,
        'action_reason_lines': reason_lines,
    }, '')

@_with_cloud_readiness_globals
def _qa_drop_spike_reply_context(lab_root):
    """
    Best-effort context for unresolved QA-drop style cloud alerts.
    Prefer explicit alert-state issue keys, then infer from live/anchored
    Phase F + diagnostics telemetry when the control-plane signal is absent.

    Operator-manual reply requirements are deprecated: this helper now always
    returns `reply_required=False` and emits auto-closure metadata so callers
    can embed closure details directly in generated recommendation/runbook text.

    Returns:
      {
        'reply_required': bool,  # always False (deprecated manual lane)
        'issue_key': str,
        'issue_code': str,
        'deprecation_active': bool,
        'closure_mode': str,  # one of: none, embedded_auto_closure
        'closure_tasks': [str, ...],
      }
    """
    reply_codes = (
        'PHASE_D_INVALID_EXTERNAL_ID_SKIPS_PRESENT',
        'PHASE_D_INVALID_EXTERNAL_ID_ELEVATED',
    )
    state_path = os.path.join(lab_root or '.', _HEALTH_ALERT_STATE_FILENAME)
    state = _load_json_dict(state_path)
    if isinstance(state, dict):
        issue_key = str(state.get('last_issue_key', '') or '').strip()
        issue_code = issue_key.split(':', 1)[0].strip() if issue_key else ''
        if issue_code in reply_codes:
            return {
                'reply_required': False,
                'issue_key': issue_key,
                'issue_code': issue_code,
                'deprecation_active': True,
                'closure_mode': 'embedded_auto_closure',
                'closure_tasks': [
                    'embed_issue_code_in_recommendation',
                    'embed_current_remediation_state',
                    'attach_run_evidence_bundle',
                ],
            }
        if issue_key:
            return {
                'reply_required': False,
                'issue_key': issue_key,
                'issue_code': issue_code,
                'deprecation_active': True,
                'closure_mode': 'none',
                'closure_tasks': [],
            }

    diagnostics_state = _load_diagnostics_state(lab_root)
    discovery = _diagnostics_section(diagnostics_state, 'last_discovery_dat_telemetry')
    phase_d = _diagnostics_section(diagnostics_state, 'last_phase_d_dat_telemetry')

    manifest_rows = _safe_int(discovery.get('dat_manifest_rows_count'), 0)
    dat_selected = _safe_int(phase_d.get('dat_selected_count'), 0)
    blocked_stage = str(phase_d.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    post_medisoft_status = 'exercised' if phase_d.get('post_medisoft_exercised') else 'not_exercised'

    report_run_id = str(diagnostics_state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if report_run_id:
        shadow_payload = _load_json_dict(
            os.path.join(lab_root or '.', 'reports', 'shadow_run_report_{0}.json'.format(report_run_id))
        )
        if isinstance(shadow_payload, dict):
            if 'phase_b_dat_manifest_rows_count' in shadow_payload:
                manifest_rows = _safe_int(shadow_payload.get('phase_b_dat_manifest_rows_count'), manifest_rows)
            if 'phase_d_dat_selected_count' in shadow_payload:
                dat_selected = _safe_int(shadow_payload.get('phase_d_dat_selected_count'), dat_selected)
            payload_stage = str(shadow_payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
            if payload_stage:
                blocked_stage = payload_stage
            payload_status = str(shadow_payload.get('post_medisoft_status', '') or '').strip().lower()
            if payload_status:
                post_medisoft_status = payload_status

    if post_medisoft_status == 'blocked' and blocked_stage == 'phase_d' and manifest_rows > 0 and dat_selected == 0:
        issue_code = 'QA_DROP_SPIKE_REPLY_REQUIRED'
        return {
            'reply_required': False,
            'issue_key': issue_code,
            'issue_code': issue_code,
            'deprecation_active': True,
            'closure_mode': 'embedded_auto_closure',
            'closure_tasks': [
                'embed_inferred_issue_in_recommendation',
                'embed_anchor_vs_live_provenance',
                'queue_follow_on_phase_d_action',
            ],
        }

    return {
        'reply_required': False,
        'issue_key': '',
        'issue_code': '',
        'deprecation_active': True,
        'closure_mode': 'none',
        'closure_tasks': [],
    }

@_with_cloud_readiness_globals
def _step2_run_coherence_from_snapshot(snapshot):
    """
    Build explicit Step-2 run-coherence telemetry for recommendation payloads.
    """
    snap = snapshot if isinstance(snapshot, dict) else {}
    run_id = str(snap.get('run_id', '') or '').strip()
    artifact_files = snap.get('artifact_files', []) if isinstance(snap.get('artifact_files', []), list) else []
    phase_run_ids = snap.get('phase_run_ids', {}) if isinstance(snap.get('phase_run_ids', {}), dict) else {}

    def _find_artifact(prefix, suffix):
        if not run_id:
            return ''
        target = '{0}{1}{2}'.format(prefix, run_id, suffix)
        for path in artifact_files:
            name = os.path.basename(str(path or '').strip())
            if name == target:
                return str(path or '').strip()
        return ''

    shadow_report_path = _find_artifact('shadow_run_report_', '.json')
    shadow_index_path = _find_artifact('shadow_evidence_index_', '.json')
    phase_d_payload, phase_d_summary_path = _load_phase_summary_from_snapshot(snap, 'D', prefix='qa_canonical_summary_')

    expected_phase_d_run_id = str(phase_run_ids.get('D', '') or run_id)
    observed_phase_d_run_id = str((phase_d_payload or {}).get('run_id', '') or '').strip()
    phase_d_run_id_match = bool(expected_phase_d_run_id and observed_phase_d_run_id and expected_phase_d_run_id == observed_phase_d_run_id)

    coherence_blocked = bool(_artifact_tools.artifact_snapshot_coherence_blocked(snap))
    lineage_issues = snap.get('lineage_issues', []) if isinstance(snap.get('lineage_issues', []), list) else []
    required_present = bool(shadow_report_path and shadow_index_path and phase_d_summary_path)
    alignment_ok = bool(required_present and ((not observed_phase_d_run_id) or phase_d_run_id_match) and (not coherence_blocked))

    note = ''
    first_lineage_issue = ''
    if lineage_issues:
        first_lineage_issue = str(lineage_issues[0] or '').strip()
    if first_lineage_issue.startswith('current_phase_c_missing_or_stale'):
        note = 'current_phase_c_missing_or_stale'
    elif not required_present:
        note = 'missing_required_artifacts_for_step2'
    elif coherence_blocked:
        note = 'snapshot_coherence_blocked'
    elif observed_phase_d_run_id and not phase_d_run_id_match:
        note = 'phase_d_summary_run_id_mismatch'
    else:
        note = 'step2_ready'

    return {
        'run_id': run_id,
        'shadow_run_report_path': shadow_report_path,
        'shadow_evidence_index_path': shadow_index_path,
        'phase_d_summary_path': str(phase_d_summary_path or '').strip(),
        'expected_phase_d_run_id': expected_phase_d_run_id,
        'observed_phase_d_run_id': observed_phase_d_run_id,
        'phase_d_run_id_match': phase_d_run_id_match,
        'required_artifacts_present': required_present,
        'coherence_blocked': coherence_blocked,
        'lineage_issue_count': len(lineage_issues),
        'primary_lineage_issue': first_lineage_issue,
        'alignment_ok': alignment_ok,
        'alignment_note': note,
    }

@_with_cloud_readiness_globals
def _audit_hint_lines_from_payload(payload):
    """Return compact operator hints from audit payload."""
    hints = []
    if not isinstance(payload, dict):
        return hints
    stage = str(payload.get('migration_stage', '') or '').strip().lower()
    overall = payload.get('overall', {}) if isinstance(payload.get('overall', {}), dict) else {}
    status = str(overall.get('status', '') or '').lower()
    score = overall.get('score', '?')
    exit_code = overall.get('exit_code', '?')
    hints.append('Migration audit: status={0}, score={1}, exit_code={2}'.format(status or 'unknown', score, exit_code))
    if stage:
        hints.append('Migration stage: {0}'.format(stage))
    gating = payload.get('gating', {}) if isinstance(payload.get('gating', {}), dict) else {}
    excluded = gating.get('excluded_surfaces', []) if isinstance(gating.get('excluded_surfaces', []), list) else []
    if 'cloud' in excluded:
        hints.append('Cloud surface is informational-only for this migration stage.')

    surfaces = payload.get('surfaces', {}) if isinstance(payload.get('surfaces', {}), dict) else {}
    xp = surfaces.get('xp_local', {}) if isinstance(surfaces.get('xp_local', {}), dict) else {}
    cloud = surfaces.get('cloud', {}) if isinstance(surfaces.get('cloud', {}), dict) else {}

    def _metric(surface, key):
        metrics = surface.get('metrics', []) if isinstance(surface.get('metrics', []), list) else []
        for m in metrics:
            if isinstance(m, dict) and m.get('key') == key:
                return m
        return {}

    # XP fidelity hints (manual validation cues)
    qa_ratio = _metric(xp, 'xp.phase_d_reject_ratio')
    if qa_ratio:
        val = qa_ratio.get('value')
        st = qa_ratio.get('status')
        hints.append('XP QA reject ratio: {0} ({1})'.format(val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: review latest qa_reject_samples_*.jsonl for unresolved QA rejects.')

    inv_ratio = _metric(xp, 'xp.phase_d_invalid_external_id_skip_ratio')
    if inv_ratio:
        val = inv_ratio.get('value')
        st = inv_ratio.get('status')
        hints.append('XP invalid external patient ID skip ratio: {0} ({1})'.format(val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: review rule_decision_log constraint_fail PATIENT_EXTERNAL_ID_INVALID_FORMAT and source demographics.')

    ent_scope = _metric(xp, 'xp.phase_d_entity_scope')
    if ent_scope:
        hints.append('XP Phase D entity scope: {0} ({1})'.format(
            ent_scope.get('value'), ent_scope.get('detail') or ''))

    post_medisoft = _metric(xp, 'xp.post_medisoft_status')
    if post_medisoft:
        val = str(post_medisoft.get('value', '') or '').strip().lower() or 'unknown'
        detail = str(post_medisoft.get('detail', '') or '').strip()
        if detail:
            hints.append('Post-MediSoft path: {0} ({1})'.format(val, detail))
        else:
            hints.append('Post-MediSoft path: {0}'.format(val))
        if val != 'exercised':
            hints.append('Hint: latest run did not fully exercise the DAT/post-MediSoft handoff.')

    dat_candidates = _metric(xp, 'xp.phase_b_dat_candidates_seen_count')
    dat_manifest = _metric(xp, 'xp.phase_b_dat_manifest_rows_count')
    dat_missing = _metric(xp, 'xp.phase_b_dat_configured_root_missing_count')
    dat_fallback = _metric(xp, 'xp.phase_b_dat_fallback_root_count')
    dat_empty = _metric(xp, 'xp.phase_b_dat_existing_empty_root_count')
    dat_selection = _metric(xp, 'xp.phase_b_dat_selection_mode')
    dat_selected_root = _metric(xp, 'xp.phase_b_dat_selected_root_source_id')
    dat_effective_root = _metric(xp, 'xp.phase_b_dat_effective_root_source_id')
    if dat_candidates or dat_manifest or dat_missing or dat_fallback or dat_empty or dat_selection or dat_selected_root or dat_effective_root:
        hints.append('XP DAT discovery: candidates={0}, manifest_rows={1}, missing_roots={2}, fallback_roots={3}, empty_roots={4}, selection={5}, selected_root={6}, effective_root={7}'.format(
            dat_candidates.get('value', 0) if dat_candidates else 0,
            dat_manifest.get('value', 0) if dat_manifest else 0,
            dat_missing.get('value', 0) if dat_missing else 0,
            dat_fallback.get('value', 0) if dat_fallback else 0,
            dat_empty.get('value', 0) if dat_empty else 0,
            dat_selection.get('value', '') if dat_selection else '',
            dat_selected_root.get('value', '') if dat_selected_root else '',
            dat_effective_root.get('value', '') if dat_effective_root else '',
        ))

    dat_selected = _metric(xp, 'xp.phase_d_dat_selected_count')
    dat_qa_pass = _metric(xp, 'xp.phase_d_dat_qa_pass_count')
    dat_qa_reject = _metric(xp, 'xp.phase_d_dat_qa_reject_count')
    dat_canonical = _metric(xp, 'xp.phase_d_dat_canonical_record_count')
    if dat_selected or dat_qa_pass or dat_qa_reject or dat_canonical:
        hints.append('XP DAT Phase D: selected={0}, qa_pass={1}, qa_reject={2}, canonical={3}'.format(
            dat_selected.get('value', 0) if dat_selected else 0,
            dat_qa_pass.get('value', 0) if dat_qa_pass else 0,
            dat_qa_reject.get('value', 0) if dat_qa_reject else 0,
            dat_canonical.get('value', 0) if dat_canonical else 0,
        ))

    csv_docx_join = _metric(xp, 'xp.phase_d_csv_docx_join_summary')
    if csv_docx_join and csv_docx_join.get('value') == 'tracked':
        detail = str(csv_docx_join.get('detail', '') or '').strip()
        if detail:
            hints.append('XP upstream CSV+DOCX join: {0}'.format(detail))

    projection_cov = _metric(xp, 'xp.phase_e_projection_coverage')
    if projection_cov:
        st = projection_cov.get('status')
        cov_val = projection_cov.get('value')
        if str(cov_val).lower() == 'not_applicable':
            hints.append('XP projection coverage: not_applicable (eligible_count=0)')
        else:
            hints.append('XP projection coverage: {0} ({1})'.format(cov_val, st))
        if st == 'fail':
            hints.append('Hint: potential projection drop/defer risk; inspect projection_deviation_samples_*.jsonl.')

    alignment = _metric(xp, 'xp.cursor_state_run_alignment')
    if alignment:
        st = alignment.get('status')
        align_val = alignment.get('value')
        align_detail = str(alignment.get('detail', '') or '').strip()
        if align_detail:
            hints.append('XP cursor/state run alignment: {0} ({1}; {2})'.format(align_val, st, align_detail))
        else:
            hints.append('XP cursor/state run alignment: {0} ({1})'.format(align_val, st))
        if st in ('warn', 'fail'):
            hints.append('Hint: reconcile diagnostics_state and run_cursor run IDs after standalone phase reruns.')

    parity = _metric(xp, 'xp.phase_e_contract_parity')
    if parity and str(parity.get('value', '')).lower() == 'fail':
        hints.append('Hint: contract parity failed; treat as potential data-fidelity blocker before cutover.')

    # Cloud fidelity hints
    unacked = _metric(cloud, 'cloud.unacked_queue_count')
    oldest = _metric(cloud, 'cloud.oldest_unacked_age_minutes')
    if unacked:
        hints.append('Cloud backlog: unacked={0} ({1})'.format(unacked.get('value'), unacked.get('status')))
    if oldest:
        hints.append('Cloud oldest unacked age (min): {0} ({1})'.format(oldest.get('value'), oldest.get('status')))

    unknown_codes = _metric(cloud, 'cloud.unknown_reject_code_count_cohort')
    if unknown_codes and int(unknown_codes.get('value') or 0) > 0:
        hints.append('Hint: unknown reject codes in shadow cohort; validate reject taxonomy before migration decisions.')

    machine_missing = _metric(cloud, 'cloud.machine_id_missing_count')
    if machine_missing and int(machine_missing.get('value') or 0) > 0:
        hints.append('Hint: missing machine_id records may indicate routing/data-loss risk.')

    degradations = payload.get('degradations', []) if isinstance(payload.get('degradations', []), list) else []
    cloud_degradations = [d for d in degradations if isinstance(d, dict) and d.get('surface') == 'cloud']
    if cloud_degradations:
        reasons = []
        for item in cloud_degradations:
            reason = str(item.get('reason', '') or '').strip()
            if reason:
                reasons.append(reason)
        if reasons:
            hints.append('Cloud degradation reasons: {0}'.format(','.join(reasons)))
        runbook_path = getattr(
            _runbook_tools,
            'CLOUD_DEGRADED_VALIDATION_RUNBOOK',
            'docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md',
        )
        hints.append('Runbook: {0}'.format(runbook_path))
        if stage == 'xp_validation':
            hints.append('Note: degraded collection mode active for deferred cloud scope; complete manual checks before dual-run/cutover.')
        else:
            hints.append('Note: degraded collection mode active; complete manual checks before GO decisions.')

    _REGRESSION_HINT_FINDING_CODES = frozenset((
        'XP_POST_MEDISOFT_BLOCKED',
        'XP_DAT_REGRESSION_NO_BASELINE',
        'XP_DAT_REGRESSION_QA_ALIGNMENT',
        'XP_DAT_REGRESSION_POST_MEDISOFT',
    ))
    reg_added = 0
    xp_findings = xp.get('findings', []) if isinstance(xp.get('findings', []), list) else []
    for f in xp_findings:
        if not isinstance(f, dict):
            continue
        if f.get('severity') not in ('warn', 'fail'):
            continue
        code = str(f.get('code') or '')
        if code in _REGRESSION_HINT_FINDING_CODES:
            hints.append('{0}: {1}'.format(code, f.get('message') or ''))
            reg_added += 1
    xp_metrics = xp.get('metrics', []) if isinstance(xp.get('metrics', []), list) else []
    for m in xp_metrics:
        if not isinstance(m, dict):
            continue
        mk = str(m.get('key') or '')
        if not (mk.startswith('xp.dat_regression.') or mk.startswith('xp.dat_v2.')):
            continue
        if m.get('status') not in ('warn', 'fail'):
            continue
        line = '{0}: {1} ({2})'.format(mk, m.get('value'), m.get('status'))
        det = str(m.get('detail') or '').strip()
        if det:
            line = '{0} {1}'.format(line, det)
        if len(line) > 200:
            line = line[:197] + '...'
        hints.append(line)
        reg_added += 1
    if status in ('warn', 'fail') and reg_added == 0:
        hints.append(
            'Migration audit: see full JSON for xp.dat_regression.* / xp.dat_v2.* metrics and findings.'
        )

    return _deduplicate_audit_hint_lines(hints)

@_with_cloud_readiness_globals
def _shadow_run_actual_from_payload(payload, path=''):
    """Normalize one shadow_run_report JSON payload into recent-run actual fields."""
    if not isinstance(payload, dict):
        return {}
    if _normalize_shadow_actual_impl is not None:
        norm = _normalize_shadow_actual_impl(payload, path, _safe_int)
        if norm and norm.get('run_id'):
            out = {
                'run_id': norm.get('run_id', ''),
                'generated_at_utc': norm.get('generated_at_utc', ''),
                'pipeline_status': norm.get('pipeline_status', 'unknown'),
                'post_medisoft_label': norm.get('post_medisoft_label', 'unknown'),
            }
            for k in SHADOW_ACTUAL_INT_FIELDS:
                out[k] = _safe_int(norm.get(k), 0)
            return out
    run_id = str(payload.get('run_id', '') or '').strip()
    if not run_id:
        run_id = _shadow_run_report_run_id_from_path(path)
    if not run_id:
        return {}
    pipeline_ok = bool(payload.get('pipeline_ok'))
    failed_phase = str(payload.get('failed_phase', '') or '').strip()
    error_code = str(payload.get('error_code', '') or '').strip()
    if pipeline_ok:
        pipeline_status = 'ok'
    elif failed_phase and error_code:
        pipeline_status = 'fail:{0}:{1}'.format(failed_phase, error_code)
    elif failed_phase:
        pipeline_status = 'fail:{0}'.format(failed_phase)
    elif error_code:
        pipeline_status = 'fail:{0}'.format(error_code)
    else:
        pipeline_status = 'fail'

    post_medisoft_status = str(payload.get('post_medisoft_status', '') or '').strip().lower() or 'unknown'
    blocked_stage = str(payload.get('post_medisoft_blocked_stage', '') or '').strip().lower()
    if blocked_stage:
        post_medisoft_label = '{0}({1})'.format(post_medisoft_status, blocked_stage)
    else:
        post_medisoft_label = post_medisoft_status

    out = {
        'run_id': run_id,
        'generated_at_utc': str(payload.get('generated_at_utc', '') or '').strip(),
        'pipeline_status': pipeline_status,
        'post_medisoft_label': post_medisoft_label,
    }
    for k in SHADOW_ACTUAL_INT_FIELDS:
        out[k] = _safe_int(payload.get(k), 0)
    return out

@_with_cloud_readiness_globals
def _collect_recent_shadow_run_actuals(reports_dir, limit=3):
    """Return latest shadow_run_report JSON actuals for compact trend summaries."""
    try:
        max_items = int(limit)
    except (TypeError, ValueError):
        max_items = 3
    if max_items <= 0:
        return []
    if not reports_dir or not os.path.isdir(reports_dir):
        return []
    try:
        items = os.listdir(reports_dir)
    except (IOError, OSError):
        return []

    candidates = []
    for item in items:
        if not (item.startswith('shadow_run_report_') and item.endswith('.json')):
            continue
        path = os.path.join(reports_dir, item)
        if not os.path.isfile(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except (IOError, OSError, ValueError):
            mtime = 0
        candidates.append((mtime, path))
    candidates.sort(key=lambda entry: (entry[0], entry[1]), reverse=True)

    actuals = []
    for _, path in candidates[:max_items]:
        item = _shadow_run_actual_from_payload(_load_json_dict(path), path)
        if item:
            actuals.append(item)
    return actuals

@_with_cloud_readiness_globals
def _build_system_health_pack_context(lab_root, reports_dir, artifacts):
    """Resolve completed-run anchor context while preserving live diagnostics for alignment notes."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    expected_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active_run_id = str(state.get('active_run_id', '') or '').strip()
    anchor_report_path = _select_system_health_anchor_report_path(
        reports_dir,
        artifacts,
        expected_run_id=expected_run_id,
    )
    anchor_payload, resolved_anchor_path = _load_shadow_report_payload(anchor_report_path or (artifacts or {}).get('shadow_report_path'))
    anchor_path = resolved_anchor_path or anchor_report_path
    anchor_run_id = str(anchor_payload.get('run_id', '') or '').strip()
    if not anchor_run_id:
        anchor_run_id = _shadow_run_report_run_id_from_path(anchor_path or (artifacts or {}).get('shadow_report_path'))
    if not anchor_run_id and expected_run_id:
        anchor_run_id = expected_run_id
    pack_scope = 'unknown'
    if anchor_run_id:
        pack_scope = 'completed_run'
        if active_run_id and active_run_id != anchor_run_id:
            pack_scope = 'mixed_scope'
    elif active_run_id:
        pack_scope = 'live_current_state'
    anchor_state = _merge_state_overrides(state, _shadow_report_state_overrides(anchor_payload))
    anchor_actual = {}
    if _shadow_report_has_summary_fields(anchor_payload):
        anchor_actual = _shadow_run_actual_from_payload(anchor_payload, anchor_path)
    return {
        'state': state,
        'expected_shadow_run_id': expected_run_id,
        'active_run_id': active_run_id,
        'anchor_run_id': anchor_run_id,
        'anchor_report_path': anchor_path,
        'anchor_shadow_report_payload': anchor_payload,
        'anchor_state': anchor_state,
        'anchor_actual': anchor_actual,
        'pack_scope': pack_scope,
        'selected_shadow_run_id': _shadow_run_report_run_id_from_path((artifacts or {}).get('shadow_report_path')),
    }

@_with_cloud_readiness_globals
def _build_anchor_run_snapshot_lines(pack_context):
    """Build explicit completed-run snapshot lines for mixed-scope health packs."""
    ctx = pack_context if isinstance(pack_context, dict) else {}
    lines = ['Anchored completed-run snapshot:']
    anchor_run_id = str(ctx.get('anchor_run_id', '') or '').strip()
    payload = ctx.get('anchor_shadow_report_payload', {}) if isinstance(ctx.get('anchor_shadow_report_payload', {}), dict) else {}
    actual = ctx.get('anchor_actual', {}) if isinstance(ctx.get('anchor_actual', {}), dict) else {}
    if not anchor_run_id:
        lines.append(' - none (no completed-run shadow_run_report JSON resolved)')
        return lines
    if actual:
        lines.append(
            ' - {0}: pipeline={1}, post_medisoft={2}, manifest_rows={3}, selected={4}, qa_pass={5}, qa_reject={6}, canonical={7}'.format(
                actual.get('run_id', anchor_run_id),
                actual.get('pipeline_status', 'unknown'),
                actual.get('post_medisoft_label', 'unknown'),
                actual.get('phase_b_dat_manifest_rows_count', 0),
                actual.get('phase_d_dat_selected_count', 0),
                actual.get('phase_d_dat_qa_pass_count', 0),
                actual.get('phase_d_dat_qa_reject_count', 0),
                actual.get('phase_d_dat_canonical_record_count', 0),
            )
        )
    elif ctx.get('anchor_report_path'):
        lines.append(' - run_id={0} (shadow_run_report JSON lacks summary fields)'.format(anchor_run_id))
    else:
        lines.append(' - run_id={0} (shadow_run_report JSON pending or missing)'.format(anchor_run_id))
    selection_mode = str(payload.get('phase_b_dat_selection_mode', '') or '').strip()
    selected_root = str(payload.get('phase_b_dat_selected_root_source_id', '') or '').strip()
    effective_root = str(payload.get('phase_b_dat_effective_root_source_id', '') or '').strip()
    missing_roots = _safe_int(payload.get('phase_b_dat_configured_root_missing_count'), 0)
    empty_roots = _safe_int(payload.get('phase_b_dat_existing_empty_root_count'), 0)
    fallback_roots = _safe_int(payload.get('phase_b_dat_fallback_root_count'), 0)
    if selection_mode or selected_root or effective_root or missing_roots or empty_roots or fallback_roots:
        lines.append(
            ' - dat_roots=selection:{0}, selected_root:{1}, effective_root:{2}, missing_roots:{3}, empty_roots:{4}, fallback_roots:{5}'.format(
                selection_mode or '-',
                selected_root or '-',
                effective_root or '-',
                missing_roots,
                empty_roots,
                fallback_roots,
            )
        )
    yield_counts = payload.get('phase_b_dat_root_yield_counts_by_source', {}) if isinstance(payload.get('phase_b_dat_root_yield_counts_by_source', {}), dict) else {}
    if yield_counts:
        lines.append(' - dat_root_yield_counts={0}'.format(_format_count_map(yield_counts)))
    return lines

@_with_cloud_readiness_globals
def _should_show_latest_live_pipeline_attempt(pack_context):
    ctx = pack_context if isinstance(pack_context, dict) else {}
    state = ctx.get('state') if isinstance(ctx.get('state'), dict) else {}
    anchor = str(ctx.get('anchor_run_id', '') or '').strip()
    last_completed = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active = str(state.get('active_run_id', '') or '').strip()
    live_rid = active or last_completed
    outcome = str(state.get('last_shadow_pipeline_outcome', '') or '').strip().lower()
    if outcome == 'interrupted':
        return True
    if anchor and live_rid and anchor != live_rid:
        return True
    return False

@_with_cloud_readiness_globals
def _build_latest_live_pipeline_attempt_lines(pack_context):
    """Compact live attempt context: interruption codes and anchor mismatch."""
    ctx = pack_context if isinstance(pack_context, dict) else {}
    state = ctx.get('state') if isinstance(ctx.get('state'), dict) else {}
    anchor = str(ctx.get('anchor_run_id', '') or '').strip()
    last_completed = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    active = str(state.get('active_run_id', '') or '').strip()
    live_rid = active or last_completed
    outcome = str(state.get('last_shadow_pipeline_outcome', '') or '').strip().lower()
    failed_phase = str(state.get('last_shadow_pipeline_failed_phase', '') or '').strip()
    err = str(state.get('last_shadow_pipeline_error_code', '') or state.get('last_error_code', '') or '').strip()
    hex_c = str(state.get('last_shadow_pipeline_interrupt_code_hex', '') or '').strip()
    src = str(state.get('last_shadow_pipeline_interrupt_source', '') or '').strip()
    lines = ['Latest live pipeline attempt:']
    lines.append(' - run_id={0}'.format(live_rid or '-'))
    lines.append(' - outcome={0}'.format(outcome or '-'))
    if outcome == 'interrupted':
        lines.append(' - interrupted_phase={0}'.format(failed_phase or '-'))
        lines.append(' - interrupt_code={0}'.format(err or '-'))
        if hex_c:
            lines.append(' - interrupt_code_hex={0}'.format(hex_c))
        if src:
            lines.append(' - interrupt_source={0}'.format(src))
    elif failed_phase:
        lines.append(' - failed_phase={0}'.format(failed_phase))
    if err and outcome != 'interrupted':
        lines.append(' - error_code={0}'.format(err))
    guard = str(state.get('last_shadow_pipeline_interrupt_guard_note', '') or '').strip()
    if guard:
        lines.append(' - guard_note={0}'.format(guard))
    if anchor and live_rid and anchor != live_rid:
        lines.append(' - note: differs_from_anchor_run_id={0}'.format(anchor))
    return lines

@_with_cloud_readiness_globals
def _build_system_health_alignment_notes(lab_root, reports_dir, artifacts, audit_payload):
    """Detect mixed-snapshot conditions between diagnostics state, audit, and Phase F artifacts."""
    state = _load_json_dict(os.path.join(lab_root or '.', 'diagnostics_state.json'))
    expected_run_id = str(state.get('last_shadow_pipeline_run_id', '') or '').strip()
    if not expected_run_id:
        return {'expected_shadow_run_id': '', 'notes': []}

    audit_shadow_run_id = _audit_shadow_run_id(audit_payload) if isinstance(audit_payload, dict) else ''
    selected_shadow_run_id = _shadow_run_report_run_id_from_path(artifacts.get('shadow_report_path'))
    audit_generated_epoch = _parse_iso_utc_epoch(
        audit_payload.get('generated_at_utc', '') if isinstance(audit_payload, dict) else '')
    last_phase_f_epoch = _parse_iso_utc_epoch(state.get('last_phase_f_at_utc', ''))

    notes = []
    audit_stale = False
    if audit_shadow_run_id and audit_shadow_run_id != expected_run_id:
        audit_stale = True
    elif expected_run_id and audit_generated_epoch and last_phase_f_epoch and audit_generated_epoch < last_phase_f_epoch:
        audit_stale = True
    if audit_stale:
        notes.append(
            'note: audit summary shadow_run_id={0} is older than current state last_shadow_pipeline_run_id={1}'.format(
                audit_shadow_run_id or '-', expected_run_id))
        current = _derive_current_state_post_medisoft_summary(state)
        notes.append(
            'current state: post_medisoft={0}, manifest_rows={1}, selected={2}, qa_pass={3}, qa_reject={4}, canonical={5}'.format(
                current.get('label', 'unknown'),
                current.get('manifest_rows', 0),
                current.get('selected', 0),
                current.get('qa_pass', 0),
                current.get('qa_reject', 0),
                current.get('canonical', 0),
            ))
        notes.append('hint: rerun System Health Triage after Phase F packaging settles for aligned audit hints.')

    if selected_shadow_run_id and selected_shadow_run_id != expected_run_id:
        notes.append(
            'note: latest shadow_run_report pointer run_id={0} lags current state last_shadow_pipeline_run_id={1}'.format(
                selected_shadow_run_id, expected_run_id))

    return {
        'expected_shadow_run_id': expected_run_id,
        'notes': notes,
        'audit_stale': audit_stale,
    }

@_with_cloud_readiness_globals
def _build_recent_shadow_run_actual_lines(reports_dir, limit=3, expected_run_id=''):
    """Build compact recent-run DAT/post-MediSoft actuals lines for health packs."""
    actuals = _collect_recent_shadow_run_actuals(reports_dir, limit=limit)
    lines = ['Recent run actuals:']
    pending_line = ''

    if expected_run_id and not any(str(item.get('run_id', '') or '').strip() == expected_run_id for item in actuals):
        expected_json = os.path.join(reports_dir or '.', 'shadow_run_report_{0}.json'.format(expected_run_id))
        if os.path.isfile(expected_json):
            expected_item = _shadow_run_actual_from_payload(_load_json_dict(expected_json), expected_json)
            if expected_item:
                actuals = [expected_item] + [
                    item for item in actuals if str(item.get('run_id', '') or '').strip() != expected_run_id
                ]
                actuals = actuals[:max(_safe_int(limit, 3), 1)]
        else:
            pending_line = ' - current_run={0}: pending shadow_run_report JSON finalization'.format(expected_run_id)

    if pending_line:
        lines.append(pending_line)
    if not actuals:
        if not pending_line:
            lines.append(' - none (no shadow_run_report_*.json payloads found)')
        return lines

    for item in actuals:
        suffix = ''
        if item.get('generated_at_utc'):
            suffix = ', generated_at_utc={0}'.format(item.get('generated_at_utc'))
        v2_sk = _safe_int(item.get('phase_d_dat_v2_skipped_total'), 0)
        v2_cf = _safe_int(item.get('phase_d_dat_v2_constraint_failed_total'), 0)
        v2_ins = _safe_int(item.get('phase_d_dat_v2_inserted_total'), 0)
        if v2_sk or v2_cf or v2_ins:
            suffix += ', v2_ins={0},v2_sk={1},v2_cf={2}'.format(v2_ins, v2_sk, v2_cf)
        lines.append(
            ' - {0}: pipeline={1}, post_medisoft={2}, manifest_rows={3}, selected={4}, qa_pass={5}, qa_reject={6}, canonical={7}{8}'.format(
                item.get('run_id', '?'),
                item.get('pipeline_status', 'unknown'),
                item.get('post_medisoft_label', 'unknown'),
                item.get('phase_b_dat_manifest_rows_count', 0),
                item.get('phase_d_dat_selected_count', 0),
                item.get('phase_d_dat_qa_pass_count', 0),
                item.get('phase_d_dat_qa_reject_count', 0),
                item.get('phase_d_dat_canonical_record_count', 0),
                suffix,
            )
        )

    if len(actuals) >= 2:
        latest = actuals[0]
        previous = actuals[1]
        delta_parts = []
        if latest.get('pipeline_status') != previous.get('pipeline_status'):
            delta_parts.append('pipeline:{0}->{1}'.format(
                previous.get('pipeline_status', 'unknown'),
                latest.get('pipeline_status', 'unknown'),
            ))
        if latest.get('post_medisoft_label') != previous.get('post_medisoft_label'):
            delta_parts.append('post_medisoft:{0}->{1}'.format(
                previous.get('post_medisoft_label', 'unknown'),
                latest.get('post_medisoft_label', 'unknown'),
            ))
        for label, key in (
            ('manifest_rows', 'phase_b_dat_manifest_rows_count'),
            ('selected', 'phase_d_dat_selected_count'),
            ('qa_pass', 'phase_d_dat_qa_pass_count'),
            ('qa_reject', 'phase_d_dat_qa_reject_count'),
            ('canonical', 'phase_d_dat_canonical_record_count'),
            ('v2_attempted', 'phase_d_dat_v2_payload_attempted_total'),
            ('v2_inserted', 'phase_d_dat_v2_inserted_total'),
            ('v2_skipped', 'phase_d_dat_v2_skipped_total'),
            ('v2_constraint', 'phase_d_dat_v2_constraint_failed_total'),
        ):
            delta = _safe_int(latest.get(key), 0) - _safe_int(previous.get(key), 0)
            if delta:
                delta_parts.append('{0}:{1:+d}'.format(label, delta))
        lines.append(' - delta_vs_previous={0}'.format(', '.join(delta_parts) if delta_parts else 'no_change'))
        regression_hints = _build_recent_run_regression_hints(latest, previous)
        if regression_hints:
            lines.append(' - regression_hints={0}'.format(', '.join(regression_hints)))
    return lines

@_with_cloud_readiness_globals
def _build_recent_run_regression_hints(latest, previous):
    """Return compact thresholded regression hints for latest-vs-previous run actuals."""
    hints = []
    drop_ratio_threshold = 0.25
    drop_count_threshold = 2
    latest_label = str((latest or {}).get('post_medisoft_label', '') or '').strip().lower()
    prev_label = str((previous or {}).get('post_medisoft_label', '') or '').strip().lower()
    if prev_label == 'exercised' and latest_label != 'exercised':
        hints.append('post_medisoft_regressed:{0}->{1}'.format(prev_label, latest_label or 'unknown'))

    for label, key in (
        ('manifest_rows_drop', 'phase_b_dat_manifest_rows_count'),
        ('selected_drop', 'phase_d_dat_selected_count'),
        ('qa_pass_drop', 'phase_d_dat_qa_pass_count'),
        ('canonical_drop', 'phase_d_dat_canonical_record_count'),
        ('v2_inserted_drop', 'phase_d_dat_v2_inserted_total'),
    ):
        latest_val = _safe_int((latest or {}).get(key), 0)
        prev_val = _safe_int((previous or {}).get(key), 0)
        if prev_val > latest_val:
            drop_count = prev_val - latest_val
            drop_ratio = float(drop_count) / float(max(1, prev_val))
            if drop_count < drop_count_threshold and drop_ratio < drop_ratio_threshold:
                continue
            hints.append('{0}:{1}->{2}'.format(label, prev_val, latest_val))
    return hints

@_with_cloud_readiness_globals
def _phase_d_reprocess_report_paths_for_run_evidence(lab_root, recommendation, bundle_run_id):
    """
    Attach Phase D historical reprocess preview/execution *_latest.txt only when the embedded
    recommendation calls for historical reprocess, both files exist, they agree on the same
    non-empty remediation_context_run_id= line, and that id matches bundle_run_id or
    recommendation_anchor_run_id. Reports without the line (pre-upgrade aliases) are never attached.
    """
    rec = recommendation if isinstance(recommendation, dict) else {}
    if str(rec.get('recommended_action_kind') or '').strip() != 'historical_phase_d_reprocess':
        return []
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    preview_path = os.path.join(reports_dir, 'phase_d_historical_reprocess_preview_latest.txt')
    exec_path = os.path.join(reports_dir, 'phase_d_historical_reprocess_execution_latest.txt')
    if not (os.path.isfile(preview_path) and os.path.isfile(exec_path)):
        return []
    rid_p = _parse_remediation_context_run_id_from_phase_d_report(preview_path)
    rid_e = _parse_remediation_context_run_id_from_phase_d_report(exec_path)
    if not rid_p or not rid_e or rid_p != rid_e:
        return []
    bundle = str(bundle_run_id or '').strip()
    anchor = str(rec.get('recommendation_anchor_run_id') or '').strip()
    if (bundle and rid_p == bundle) or (anchor and rid_p == anchor):
        return [preview_path, exec_path]
    return []

@_with_cloud_readiness_globals
def _latest_interrupt_report_paths(lab_root, bundle_run_id=None):
    """
    Latest interrupt alias files under lab/reports.
    When bundle_run_id is set (run evidence), only include them if JSON embeds the same run_id.
    """
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    jpath = os.path.join(reports_dir, 'shadow_pipeline_interrupt_latest.json')
    tpath = os.path.join(reports_dir, 'shadow_pipeline_interrupt_latest.txt')
    br = str(bundle_run_id or '').strip()
    if br:
        if not os.path.isfile(jpath):
            return []
        data = _load_json_dict(jpath)
        emb = str(data.get('run_id', '') or '').strip()
        if not emb or emb != br:
            return []
    paths = []
    for path in (jpath, tpath):
        if os.path.isfile(path):
            paths.append(path)
    return paths

@_with_cloud_readiness_globals
def _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle_run_id, recommendation, smoke_state, deferred_smoke, attached_paths):
    token = _artifact_tools.safe_run_token(bundle_run_id)
    path = os.path.join(reports_dir, 'run_evidence_dat_smoke_note_{0}.txt'.format(token))
    rec = recommendation if isinstance(recommendation, dict) else {}
    preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
    state = smoke_state if isinstance(smoke_state, dict) else {}
    deferred = deferred_smoke if isinstance(deferred_smoke, dict) else {}
    lines = [
        'Run Evidence DAT Smoke Note',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'bundle_run_id={0}'.format(bundle_run_id or '-'),
        'recommended_action_kind={0}'.format(str(rec.get('recommended_action_kind', '') or 'send_bundle')),
        'dat_smoke_evaluated={0}'.format(bool(rec.get('dat_smoke_evaluated'))),
        'dat_smoke_available={0}'.format(bool(rec.get('dat_smoke_available'))),
        'dat_smoke_not_triggered_reason={0}'.format(str(rec.get('dat_smoke_not_triggered_reason', '') or '-') or '-'),
        'follow_on_action_kind={0}'.format(str(rec.get('follow_on_action_kind', '') or '-')),
        'target_anchor_run_id={0}'.format(str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or bundle_run_id or '-')),
        'target_context_run_id={0}'.format(str(preview.get('phase_d_context_run_id', '') or '-')),
        'smoke_reports_dir={0}'.format(str(preview.get('smoke_reports_dir', '') or os.path.join(str(preview.get('smoke_lab_root', '') or ''), 'reports') or '-')),
        'expected_report_path={0}'.format(str(preview.get('expected_report_path', '') or '-')),
        'reference_phase_d_summary_path={0}'.format(str(preview.get('reference_phase_d_summary_path', '') or '-')),
        'state_path={0}'.format(phase_d_dat_smoke_state_path(repo_root) if repo_root else '-'),
        'state_last_status={0}'.format(str(state.get('last_status', '') or '-')),
        'state_last_report_path={0}'.format(str(state.get('last_report_path', '') or '-')),
        'state_last_assessment={0}'.format(str(state.get('last_assessment', '') or '-')),
        'state_cooldown_until_utc={0}'.format(str(state.get('cooldown_until_utc', '') or '-')),
        'deferred_path={0}'.format(operator_deferred_phase_d_dat_smoke_path(repo_root) if deferred and repo_root else '-'),
        'deferred_anchor_run_id={0}'.format(str(deferred.get('anchor_run_id', '') or '-')),
        'deferred_context_run_id={0}'.format(str(deferred.get('context_run_id', '') or '-')),
        'deferred_issue_code={0}'.format(str(deferred.get('issue_code', '') or '-')),
        'deferred_reason={0}'.format(str(deferred.get('reason', '') or '-') or '-'),
        'attached_smoke_artifact_count={0}'.format(len(attached_paths or [])),
    ]
    for item in attached_paths or []:
        lines.append('attached_smoke_artifact={0}'.format(item))
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path

@_with_cloud_readiness_globals
def _write_run_evidence_smoke_anchor_mismatch_note(
        repo_root,
        reports_dir,
        bundle_run_id,
        reviewed_anchor,
        smoke_anchor,
        last_report_path,
        smoke_status='',
        smoke_assessment='',
        detail=''):
    token = _artifact_tools.safe_run_token(bundle_run_id)
    path = os.path.join(reports_dir, 'run_evidence_smoke_anchor_mismatch_{0}.txt'.format(token))
    lines = [
        'Run Evidence Smoke Anchor Mismatch',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'bundle_run_id={0}'.format(bundle_run_id or '-'),
        'reviewed_anchor_run_id={0}'.format(reviewed_anchor or '-'),
        'smoke_report_anchor_run_id={0}'.format(smoke_anchor or '-'),
        'last_report_path={0}'.format(last_report_path or '-'),
        'smoke_state_last_status={0}'.format(str(smoke_status or '').strip() or '-'),
        'smoke_state_last_assessment={0}'.format(str(smoke_assessment or '').strip() or '-'),
    ]
    detail = str(detail or '').strip()
    if detail:
        lines.append('detail={0}'.format(detail))
    lines.append(
        'note=Smoke artifacts were not attached because the smoke report does not match the reviewed anchor. '
        'Use the anchored qa_canonical_summary and shadow_run_report for the reviewed run.'
    )
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return path
    except (IOError, OSError):
        return ''

@_with_cloud_readiness_globals
def _phase_d_dat_smoke_report_paths_for_run_evidence(repo_root, lab_root, recommendation, bundle_run_id):
    rec = recommendation if isinstance(recommendation, dict) else {}
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    if not reports_dir:
        return []
    preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
    bundle = str(bundle_run_id or '').strip()
    target_anchor = str(preview.get('anchor_run_id', '') or rec.get('recommendation_anchor_run_id', '') or bundle).strip()
    rec_kind = str(rec.get('recommended_action_kind', '') or '').strip()
    smoke_lab_root = str(preview.get('smoke_lab_root', '') or os.path.join(repo_root, 'phase_d_dat_smoke_lab')).strip()
    smoke_reports_dir = str(preview.get('smoke_reports_dir', '') or os.path.join(smoke_lab_root, 'reports')).strip()
    state = read_phase_d_dat_smoke_state(repo_root)
    if not isinstance(state, dict):
        state = {}
    deferred = read_operator_deferred_phase_d_dat_smoke(repo_root)
    if not isinstance(deferred, dict):
        deferred = {}
    paths = []
    seen = set()

    def _remember(path_value):
        path_value = str(path_value or '').strip()
        if not path_value or not os.path.isfile(path_value) or path_value in seen:
            return
        seen.add(path_value)
        paths.append(path_value)

    # Strict same-anchor smoke packaging for QA full-block review: no out-of-scope persuasive smoke files.
    if rec_kind == 'review_dat_qa_full_block':
        reviewed = str(rec.get('recommendation_anchor_run_id') or preview.get('anchor_run_id') or bundle).strip()
        last_report_path = str(state.get('last_report_path', '') or '').strip()
        report_json_path = ''
        smoke_payload = {}
        smoke_status = str(state.get('last_status', '') or '').strip().lower()
        smoke_assessment = str(state.get('last_assessment', '') or '').strip()
        if last_report_path and os.path.isfile(last_report_path):
            root, ext = os.path.splitext(last_report_path)
            if ext.lower() == '.json':
                report_json_path = last_report_path
            else:
                report_json_path = root + '.json'
        if report_json_path and os.path.isfile(report_json_path):
            smoke_payload = _load_json_dict(report_json_path)
        smoke_anchor = str((smoke_payload or {}).get('anchor_run_id', '') or '').strip()
        smoke_ok = (
            reviewed
            and smoke_anchor
            and smoke_anchor == reviewed
            and smoke_status == 'completed'
            and str(smoke_assessment or (smoke_payload or {}).get('assessment', '') or '').strip() == 'dat_selected_qa_blocked'
        )
        if not smoke_ok:
            smoke_assessment_effective = str(smoke_assessment or (smoke_payload or {}).get('assessment', '') or '').strip()
            mismatch_reasons = []
            if not reviewed:
                mismatch_reasons.append('reviewed_anchor_run_id_missing')
            if not last_report_path:
                mismatch_reasons.append('state_last_report_path_missing')
            elif not os.path.isfile(last_report_path):
                mismatch_reasons.append('state_last_report_path_not_found')
            if last_report_path and not report_json_path:
                mismatch_reasons.append('smoke_report_json_path_missing')
            elif report_json_path and not os.path.isfile(report_json_path):
                mismatch_reasons.append('smoke_report_json_not_found')
            if smoke_status != 'completed':
                mismatch_reasons.append('state_last_status={0}'.format(smoke_status or '-'))
            if smoke_assessment_effective != 'dat_selected_qa_blocked':
                mismatch_reasons.append('smoke_assessment={0}'.format(smoke_assessment_effective or '-'))
            if not smoke_anchor:
                mismatch_reasons.append('smoke_report_anchor_run_id_missing')
            elif reviewed and smoke_anchor != reviewed:
                mismatch_reasons.append(
                    'smoke_report_anchor_mismatch reviewed={0} smoke={1}'.format(reviewed, smoke_anchor)
                )
            mm = _write_run_evidence_smoke_anchor_mismatch_note(
                repo_root,
                reports_dir,
                bundle,
                reviewed,
                smoke_anchor,
                last_report_path,
                smoke_status=smoke_status,
                smoke_assessment=smoke_assessment_effective,
                detail='; '.join(mismatch_reasons) or 'smoke_not_accepted_for_review_dat_qa_full_block',
            )
            if mm:
                _remember(mm)
            return paths

        state_path = phase_d_dat_smoke_state_path(repo_root)
        if os.path.isfile(state_path):
            _remember(state_path)
        if last_report_path and os.path.isfile(last_report_path):
            _remember(last_report_path)
            root, ext = os.path.splitext(last_report_path)
            sibling = root + ('.json' if ext.lower() == '.txt' else '.txt')
            _remember(sibling)
        if smoke_reports_dir and smoke_anchor:
            sp_run = str((smoke_payload or {}).get('smoke_pipeline_run_id') or (smoke_payload or {}).get('run_id') or '').strip()
            for rid in (sp_run, smoke_anchor):
                if not rid:
                    continue
                for suffix in ('.json', '.txt'):
                    p = os.path.join(smoke_reports_dir, 'phase_d_dat_smoke_report_{0}{1}'.format(rid, suffix))
                    _remember(p)
        if reports_dir and os.path.isdir(reports_dir):
            note_path = _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle, rec, state, deferred, paths)
            _remember(note_path)
        return paths

    state_path = phase_d_dat_smoke_state_path(repo_root)
    if os.path.isfile(state_path):
        if str(rec.get('recommended_action_kind', '') or '').strip() == 'phase_d_dat_smoke' or bool(rec.get('dat_smoke_evaluated')) or str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip() or str(state.get('last_status', '') or '').strip():
            _remember(state_path)

    deferred_path = operator_deferred_phase_d_dat_smoke_path(repo_root)
    if deferred and os.path.isfile(deferred_path):
        deferred_anchor = str(deferred.get('anchor_run_id', '') or '').strip()
        if not deferred_anchor or deferred_anchor == bundle or (target_anchor and deferred_anchor == target_anchor):
            _remember(deferred_path)

    if target_anchor and smoke_reports_dir:
        for suffix in ('.json', '.txt'):
            _remember(os.path.join(smoke_reports_dir, 'phase_d_dat_smoke_report_{0}{1}'.format(target_anchor, suffix)))
            _remember(os.path.join(smoke_reports_dir, 'shadow_run_report_{0}{1}'.format(target_anchor, suffix)))

    last_report_path = str(state.get('last_report_path', '') or '').strip()
    report_json_path = ''
    if last_report_path and os.path.isfile(last_report_path):
        _remember(last_report_path)
        root, ext = os.path.splitext(last_report_path)
        sibling = root + ('.json' if ext.lower() == '.txt' else '.txt')
        _remember(sibling)
        if ext.lower() == '.json':
            report_json_path = last_report_path
        else:
            report_json_path = root + '.json'
    if report_json_path and os.path.isfile(report_json_path):
        report_payload = _load_json_dict(report_json_path)
        smoke_anchor = str(report_payload.get('anchor_run_id', '') or '').strip()
        if smoke_anchor and smoke_reports_dir:
            for suffix in ('.json', '.txt'):
                _remember(os.path.join(smoke_reports_dir, 'phase_d_dat_smoke_report_{0}{1}'.format(smoke_anchor, suffix)))
                _remember(os.path.join(smoke_reports_dir, 'shadow_run_report_{0}{1}'.format(smoke_anchor, suffix)))

    should_note = bool(
        str(rec.get('recommended_action_kind', '') or '').strip() == 'phase_d_dat_smoke'
        or bool(rec.get('dat_smoke_evaluated'))
        or str(rec.get('dat_smoke_not_triggered_reason', '') or '').strip()
        or str(state.get('last_status', '') or '').strip()
        or deferred
    )
    if should_note and reports_dir and os.path.isdir(reports_dir):
        note_path = _write_run_evidence_dat_smoke_note(repo_root, reports_dir, bundle, rec, state, deferred, paths)
        _remember(note_path)
    return paths

@_with_cloud_readiness_globals
def _write_run_evidence_context_note(reports_dir, bundle_run_id, pack_context, pack_path, pack_error=''):
    token = _artifact_tools.safe_run_token(bundle_run_id)
    path = os.path.join(reports_dir, 'run_evidence_context_note_{0}.txt'.format(token))
    lines = [
        'Run Evidence Context Note',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'bundle_run_id={0}'.format(bundle_run_id or '-'),
        'context_pack_path={0}'.format(pack_path or '(missing)'),
    ]
    if pack_error:
        lines.append('context_pack_error={0}'.format(pack_error))
    if isinstance(pack_context, dict):
        lines.append('context_pack_anchor_run_id={0}'.format(str(pack_context.get('anchor_run_id', '') or '-')))
        lines.append('context_pack_scope={0}'.format(str(pack_context.get('pack_scope', '') or 'unknown')))
        st = pack_context.get('state') if isinstance(pack_context.get('state'), dict) else {}
        anchor = str(pack_context.get('anchor_run_id', '') or '').strip()
        br = str(bundle_run_id or '').strip()
        if anchor and br and anchor != br:
            lines.append(
                'context_note=Recommendation and evidence may use anchored completed run_id={0}; bundle_run_id={1} differs.'
                .format(anchor, br))
            lines.append(
                'note=No matching anchored System Health Pack was attached because the latest health pack does not anchor to this run_id.'
            )
        if str(st.get('last_shadow_pipeline_outcome', '') or '').strip().lower() == 'interrupted':
            lines.append(
                'live_interruption=last pipeline outcome was interrupted; see shadow_pipeline_interrupt_latest.* under lab/reports if attached.'
            )
    else:
        lines.append('note=No matching anchored System Health Pack was attached because the latest health pack does not anchor to this run_id.')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines) + '\n')
    return path

@_with_cloud_readiness_globals
def _collect_run_evidence_context_attachment(repo_root, snapshot, progress_callback=None):
    reports_dir = str((snapshot or {}).get('reports_dir', '') or '').strip()
    run_id = str((snapshot or {}).get('run_id', '') or '').strip()
    if not reports_dir or not run_id:
        return ('', None)
    pack_path = ''
    pack_error = ''
    try:
        _emit_progress(progress_callback, 'building anchored context pack')
        ok_pack, msg_pack, pack_path = open_latest_system_health_pack(
            repo_root,
            _default_env_flag,
            include_delivery_status=False,
            progress_callback=None,
            include_guided_patient_preview=False,
        )
        if not ok_pack:
            pack_error = msg_pack or 'Unable to build System Health Pack.'
    except Exception as exc:
        pack_error = str(exc)
        pack_path = ''

    def _anchor_from_pack_text(path):
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                for line in handle:
                    raw = str(line or '').strip()
                    if raw.startswith('- '):
                        raw = raw[2:].strip()
                    if raw.startswith('recommendation_anchor_run_id='):
                        return raw.split('=', 1)[1].strip()
                    if raw.startswith('context_pack_anchor_run_id='):
                        return raw.split('=', 1)[1].strip()
                    if raw.startswith('anchor_run_id='):
                        return raw.split('=', 1)[1].strip()
        except Exception:
            return ''
        return ''

    pack_context = {
        'pack_scope': 'unknown',
        'anchor_run_id': '',
        'anchor_report_path': '',
        'context_source': 'system_health_pack_text',
    }
    anchor_run_id = _anchor_from_pack_text(pack_path) if pack_path else ''
    if anchor_run_id:
        pack_context['anchor_run_id'] = anchor_run_id
        pack_context['pack_scope'] = 'completed_run'
    if pack_path and anchor_run_id and anchor_run_id == run_id:
        return (pack_path, pack_context)
    if pack_path and not anchor_run_id and not pack_error:
        pack_error = 'System Health Pack anchor could not be verified from pack text without rebuilding live context.'
    note_path = _write_run_evidence_context_note(reports_dir, run_id, pack_context, pack_path, pack_error=pack_error)
    return (note_path, pack_context)

@_with_cloud_readiness_globals
def _write_run_evidence_anchor_resolution_note(repo_root, lab_root, anchor_run_id, error_detail):
    """Plain-text note when anchored run evidence snapshot cannot be built (fail-closed lineage)."""
    reports_dir = os.path.join(str(lab_root or ''), 'reports')
    if not reports_dir or not os.path.isdir(reports_dir):
        try:
            os.makedirs(reports_dir)
        except (OSError, IOError):
            return ''
    token = _artifact_tools.safe_run_token(anchor_run_id)
    path = os.path.join(reports_dir, 'run_evidence_anchor_resolution_failed_{0}.txt'.format(token))
    lines = [
        'Run Evidence Anchor Resolution Failed',
        'generated_at_utc={0}'.format(time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())),
        'requested_anchor_run_id={0}'.format(anchor_run_id or '-'),
        'detail={0}'.format(str(error_detail or '').strip() or '-'),
        'note=review_dat_qa_full_block bundles require a coherent artifact snapshot for this anchor; latest snapshot was not used as a fallback.',
    ]
    try:
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return path
    except (IOError, OSError):
        return ''

def _path_resolves_under_lab_reports(path, lab_root):
    """True if path resolves under lab_root/reports (Python 3.4-safe; avoids os.path.commonpath 3.5+)."""
    if not lab_root or not str(lab_root).strip():
        return False
    p = str(path or '').strip()
    if not p:
        return False
    try:
        base = os.path.realpath(os.path.join(str(lab_root).strip(), 'reports'))
        cand = os.path.realpath(os.path.expanduser(p))
    except (OSError, ValueError, TypeError):
        return False
    if base == cand:
        return True
    # Prefix check with separator so .../reports2 does not match .../reports
    prefix = base if base.endswith(os.sep) else (base + os.sep)
    try:
        return os.path.normcase(cand).startswith(os.path.normcase(prefix))
    except (OSError, ValueError, TypeError):
        return False


@_with_cloud_readiness_globals
def _review_dat_qa_full_block_forced_attachment_paths(recommendation, lab_root=None):
    """Explicit QA paths from action_preview when present on disk and under lab reports."""
    rec = recommendation if isinstance(recommendation, dict) else {}
    preview = rec.get('action_preview') if isinstance(rec.get('action_preview'), dict) else {}
    out = []
    for key in ('phase_d_summary_path', 'qa_reject_samples_path', 'shadow_run_report_path'):
        p = str(preview.get(key) or '').strip()
        if p and os.path.isfile(p) and _path_resolves_under_lab_reports(p, lab_root):
            out.append(p)
    for lk, lv in preview.items():
        lk_s = str(lk or '').strip()
        if not lk_s.startswith('layer1_join_debug_') or not lk_s.endswith('_path'):
            continue
        p_l1 = str(lv or '').strip()
        if p_l1 and os.path.isfile(p_l1) and _path_resolves_under_lab_reports(p_l1, lab_root):
            out.append(p_l1)
    return out
_IMPL_compute_operator_support_send_recommendation_core = compute_operator_support_send_recommendation_core
_IMPL_compute_operator_support_send_recommendation = compute_operator_support_send_recommendation
_IMPL_open_latest_system_health_pack = open_latest_system_health_pack
_IMPL_run_system_health_triage = run_system_health_triage
_IMPL_send_latest_system_health_pack = send_latest_system_health_pack
_IMPL_send_latest_run_evidence_bundle = send_latest_run_evidence_bundle
_IMPL__preferred_when_stable_from_snapshot = _preferred_when_stable_from_snapshot
_IMPL__select_evaluation_snapshot_for_recommendation = _select_evaluation_snapshot_for_recommendation
_IMPL__build_historical_phase_d_reprocess_recommendation = _build_historical_phase_d_reprocess_recommendation
_IMPL__build_phase_d_dat_smoke_recommendation = _build_phase_d_dat_smoke_recommendation
_IMPL__build_phase_d_dat_qa_full_block_recommendation = _build_phase_d_dat_qa_full_block_recommendation
_IMPL__qa_drop_spike_reply_context = _qa_drop_spike_reply_context
_IMPL__step2_run_coherence_from_snapshot = _step2_run_coherence_from_snapshot
_IMPL__audit_hint_lines_from_payload = _audit_hint_lines_from_payload
_IMPL__shadow_run_actual_from_payload = _shadow_run_actual_from_payload
_IMPL__collect_recent_shadow_run_actuals = _collect_recent_shadow_run_actuals
_IMPL__build_system_health_pack_context = _build_system_health_pack_context
_IMPL__build_anchor_run_snapshot_lines = _build_anchor_run_snapshot_lines
_IMPL__should_show_latest_live_pipeline_attempt = _should_show_latest_live_pipeline_attempt
_IMPL__build_latest_live_pipeline_attempt_lines = _build_latest_live_pipeline_attempt_lines
_IMPL__build_system_health_alignment_notes = _build_system_health_alignment_notes
_IMPL__build_recent_shadow_run_actual_lines = _build_recent_shadow_run_actual_lines
_IMPL__build_recent_run_regression_hints = _build_recent_run_regression_hints
_IMPL__phase_d_reprocess_report_paths_for_run_evidence = _phase_d_reprocess_report_paths_for_run_evidence
_IMPL__latest_interrupt_report_paths = _latest_interrupt_report_paths
_IMPL__write_run_evidence_dat_smoke_note = _write_run_evidence_dat_smoke_note
_IMPL__write_run_evidence_smoke_anchor_mismatch_note = _write_run_evidence_smoke_anchor_mismatch_note
_IMPL__phase_d_dat_smoke_report_paths_for_run_evidence = _phase_d_dat_smoke_report_paths_for_run_evidence
_IMPL__write_run_evidence_context_note = _write_run_evidence_context_note
_IMPL__collect_run_evidence_context_attachment = _collect_run_evidence_context_attachment
_IMPL__write_run_evidence_anchor_resolution_note = _write_run_evidence_anchor_resolution_note
_IMPL__review_dat_qa_full_block_forced_attachment_paths = _review_dat_qa_full_block_forced_attachment_paths
