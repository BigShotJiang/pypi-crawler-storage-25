# -*- coding: utf-8 -*-
"""
Layer 1 Phase C runbook automation: execute ordered checks/actions, record telemetry,
and submit via the same support bundle path as other MediCafe diagnostics.

Designed for operator workstations (XP track Python 3.4+). Uses plain imports
compatible with the packaged layout.

Typical usage::

    python -m MediCafe.layer1_phase_c_runbook_helper --lab-root "D:\\\\MediCafeLab"

With an optional full shadow pipeline rerun after automated checks::

    python -m MediCafe.layer1_phase_c_runbook_helper --lab-root "..." --execute-pipeline

Environment: ``MEDICAFE_LAB_DIR`` may be used instead of ``--lab-root``.

**Verbose stderr (optional):** set ``MEDICAFE_LAYER1_RUNBOOK_AUTO_VERBOSE=1`` to print
``automation_runbook_checklist_lines`` to stderr as automation finishes (launcher log),
in addition to the JSON in the telemetry file.

**Automatic attach (no operator):** when ``send_latest_system_health_pack`` runs
(including background support-send jobs), ``maybe_auto_attach_layer1_runbook_for_system_health_pack``
builds telemetry and adds it to the same ZIP if Layer 1 is blocked at Phase C
(ingest failure or manifest pending), or if the frozen recommendation is
``resolve_layer1_upstream_blocker``. Auto-attach uses ``no_blocking_waits=True``
(no lock-wait ``sleep``, no shadow pipeline subprocess) so the operator session
does not freeze during ZIP build. Set ``MEDICAFE_LAYER1_RUNBOOK_AUTO=0`` to
disable. Same-fingerprint repeats are suppressed for
``MEDICAFE_LAYER1_RUNBOOK_AUTO_COOLDOWN_SEC`` (default 3600).
"""
from __future__ import print_function

import argparse
import json
import os
import shutil
import subprocess
import sys
import time

TELEMETRY_SCHEMA_VERSION = 1

# Rows_failed at or above this value => classify as validation-scale (escalate / SHP).
_ROWS_FAILED_ESCALATION_THRESHOLD = 50


def _iso_utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _safe_ascii(text, limit=800):
    try:
        raw = str(text or "")
    except Exception:
        raw = ""
    if limit and len(raw) > limit:
        return raw[: limit - 3] + "..."
    return raw


def _read_json_dict(path):
    if not path or not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _resolve_lab_root(cli_lab_root):
    root = str(cli_lab_root or "").strip()
    if root:
        return os.path.abspath(root)
    env = str(os.environ.get("MEDICAFE_LAB_DIR", "") or "").strip()
    if env:
        return os.path.abspath(env)
    return ""


def _default_repo_root():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))


def _shadow_pipeline_script(repo_root):
    candidate = os.path.join(repo_root, "scripts", "unified_model", "run_shadow_pipeline.py")
    if os.path.isfile(candidate):
        return candidate
    return ""


def _hint_suggests_lock(text):
    low = str(text or "").lower()
    for token in (
        "locked",
        "busy",
        "winerror 32",
        "errno 32",
        "unable to open",
        "readonly",
        "read-only",
    ):
        if token in low:
            return True
    return False


def _step_ok(detail, data=None):
    return {"status": "ok", "detail": detail, "data": data or {}}


def _step_skip(detail, data=None):
    return {"status": "skipped", "detail": detail, "data": data or {}}


def _step_warn(detail, data=None):
    return {"status": "warning", "detail": detail, "data": data or {}}


def _step_err(detail, data=None):
    return {"status": "error", "detail": detail, "data": data or {}}


def _format_automation_steps_as_checklist_lines(steps):
    """
    One checklist-style line per automation step (for telemetry JSON and optional stderr).
    Status tokens align with operator checklist: [OK] [WARN] [FAIL] plus [SKIP] for skipped steps.
    """
    out = []
    mapping = {"ok": "[OK]", "skipped": "[SKIP]", "warning": "[WARN]", "error": "[FAIL]"}
    for row in steps or []:
        if not isinstance(row, dict):
            continue
        sid = _safe_ascii(str(row.get("step_id") or "").strip(), 120)
        res = row.get("result") if isinstance(row.get("result"), dict) else {}
        st = str(res.get("status") or "").strip().lower()
        tok = mapping.get(st, "[OPEN]")
        det = _safe_ascii(res.get("detail"), 220)
        elapsed = row.get("elapsed_sec")
        es = ""
        try:
            if elapsed is not None:
                es = " ({0}s)".format(elapsed)
        except Exception:
            es = ""
        if det:
            out.append("{0} {1}: {2}{3}".format(tok, sid, det, es))
        else:
            out.append("{0} {1}{2}".format(tok, sid, es))
    return out


def _layer1_runbook_auto_verbose_stderr():
    raw = os.environ.get("MEDICAFE_LAYER1_RUNBOOK_AUTO_VERBOSE")
    if raw is None or not str(raw).strip():
        return False
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "y")


def _run_step(recorder, step_id, fn):
    entry = {"step_id": step_id, "started_at_utc": _iso_utc_now()}
    t0 = time.time()
    try:
        result = fn()
    except Exception as ex:
        entry["result"] = _step_err("exception: {0}".format(_safe_ascii(ex, 400)))
    else:
        entry["result"] = result if isinstance(result, dict) else _step_ok("done")
    entry["elapsed_sec"] = round(time.time() - t0, 3)
    entry["ended_at_utc"] = _iso_utc_now()
    recorder.append(entry)
    return entry


LAYER1_RUNBOOK_AUTO_STATE_NAME = "layer1_phase_c_runbook_auto_state.json"


def _layer1_runbook_auto_enabled():
    raw = os.environ.get("MEDICAFE_LAYER1_RUNBOOK_AUTO")
    if raw is None or not str(raw).strip():
        return True
    return str(raw).strip().lower() in ("1", "true", "yes", "on", "y")


def _layer1_runbook_auto_cooldown_sec():
    try:
        return max(60, int(os.environ.get("MEDICAFE_LAYER1_RUNBOOK_AUTO_COOLDOWN_SEC", "3600")))
    except (TypeError, ValueError):
        return 3600


def _runbook_auto_state_path(lab_root):
    return os.path.join(lab_root, "reports", LAYER1_RUNBOOK_AUTO_STATE_NAME)


def _runbook_auto_fingerprint(diagnostics_state, runbook_key):
    st = diagnostics_state if isinstance(diagnostics_state, dict) else {}
    parts = [
        str(runbook_key or ""),
        str(st.get("last_phase_c_run_id") or ""),
        str(st.get("last_manifest_sha256") or ""),
        str(st.get("last_ingest_manifest_sha256") or ""),
        str(st.get("last_phase_c_ok")),
        str(st.get("last_phase_c_error_code") or ""),
        str(st.get("last_shadow_pipeline_run_id") or ""),
    ]
    return "|".join(parts)


def _runbook_auto_should_attach(lab_root, diagnostics_state, runbook_key):
    if not runbook_key or runbook_key == "unsupported":
        return False, "no_runbook"
    if not _layer1_runbook_auto_enabled():
        return False, "disabled_by_env"
    path = _runbook_auto_state_path(lab_root)
    fp = _runbook_auto_fingerprint(diagnostics_state, runbook_key)
    cooldown = _layer1_runbook_auto_cooldown_sec()
    now = time.time()
    try:
        prior = _read_json_dict(path)
        last_fp = str(prior.get("last_fingerprint") or "")
        last_ts = float(prior.get("last_submitted_epoch", 0) or 0)
        if last_fp == fp and (now - last_ts) < cooldown:
            return False, "cooldown_same_fingerprint"
    except Exception:
        pass
    return True, ""


def _runbook_auto_write_state(lab_root, diagnostics_state, runbook_key):
    path = _runbook_auto_state_path(lab_root)
    try:
        rep = os.path.dirname(path)
        if not os.path.isdir(rep):
            os.makedirs(rep)
    except Exception:
        return
    doc = {
        "last_fingerprint": _runbook_auto_fingerprint(diagnostics_state, runbook_key),
        "last_submitted_epoch": time.time(),
        "last_submitted_at_utc": _iso_utc_now(),
    }
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(doc, handle, indent=2, sort_keys=True)
            handle.write("\n")
    except Exception:
        pass


def maybe_auto_attach_layer1_runbook_for_system_health_pack(
    repo_root,
    lab_root,
    diagnostics_state,
    recommendation,
    extra_meta,
    add_unique_file,
    python_exe=None,
    progress_callback=None,
):
    """
    When Layer 1 is blocked at Phase C (manifest pending or ingest failure), run
    runbook automation steps, write telemetry JSON, attach it to this System Health
    Pack ZIP, and embed the document in ``extra_meta`` — without operator action.

    Disabled when ``MEDICAFE_LAYER1_RUNBOOK_AUTO`` is set to ``0`` / ``false``.
    Re-runs for the same lab fingerprint are suppressed for
    ``MEDICAFE_LAYER1_RUNBOOK_AUTO_COOLDOWN_SEC`` (default 3600s).

    ``add_unique_file`` must behave like ``cloud_readiness._add_unique_file`` bound
    to the caller's ``extra_files`` and ``seen`` sets: ``add_unique_file(path, alias=...)``.
    """
    if not isinstance(extra_meta, dict):
        return False, "invalid_extra_meta"
    if not callable(add_unique_file):
        return False, "invalid_add_unique_file"
    lab_root = os.path.abspath(str(lab_root or "").strip())
    repo_root = os.path.abspath(str(repo_root or _default_repo_root()).strip())
    py = str(python_exe or sys.executable).strip() or sys.executable
    rec = recommendation if isinstance(recommendation, dict) else {}
    rec_kind = str(rec.get("recommended_action_kind") or "").strip()
    layer1_model = _build_layer1_model(lab_root, diagnostics_state if isinstance(diagnostics_state, dict) else {})
    runbook_key = _detect_runbook_key(layer1_model)
    if rec_kind != "resolve_layer1_upstream_blocker" and not runbook_key:
        return False, "not_layer1_phase_c_gate"
    if not runbook_key:
        return False, "no_automatable_runbook"
    ok, skip_reason = _runbook_auto_should_attach(lab_root, diagnostics_state, runbook_key)
    if not ok:
        return False, skip_reason
    if callable(progress_callback):
        try:
            progress_callback("layer1_phase_c_runbook_automation")
        except Exception:
            pass
    try:
        doc = build_runbook_telemetry_document(
            lab_root,
            repo_root,
            py,
            execute_pipeline=False,
            wait_lock_sec=0,
            no_blocking_waits=True,
        )
    except Exception as ex:
        extra_meta["layer1_phase_c_runbook_auto_error"] = _safe_ascii(ex, 400)
        return False, "telemetry_build_failed"
    tel_path = write_telemetry_json(lab_root, doc)
    if not tel_path:
        return False, "telemetry_write_failed"
    extra_meta["layer1_phase_c_runbook_auto"] = doc
    extra_meta["layer1_phase_c_runbook_auto_path"] = os.path.basename(tel_path)
    try:
        add_unique_file(tel_path, alias=os.path.basename(tel_path))
    except Exception:
        pass
    if _layer1_runbook_auto_verbose_stderr():
        for line in doc.get("automation_runbook_checklist_lines") or []:
            try:
                print("[layer1_runbook_auto] {0}".format(line), file=sys.stderr)
            except Exception:
                pass
    _runbook_auto_write_state(lab_root, diagnostics_state, runbook_key)
    return True, "attached"


def _detect_runbook_key(layer1_model):
    from MediCafe.layer1_readiness_model import (
        LAYER1_BLOCKER_PHASE_C_INGEST_FAILED,
        LAYER1_BLOCKER_PHASE_C_MANIFEST_NOT_INGESTED,
    )

    blocker = str(layer1_model.get("layer1_current_blocker") or "").strip()
    if blocker == LAYER1_BLOCKER_PHASE_C_MANIFEST_NOT_INGESTED:
        return "phase_c_manifest_pending"
    if blocker == LAYER1_BLOCKER_PHASE_C_INGEST_FAILED:
        return "phase_c_ingest_failure"
    return ""


def _build_layer1_model(lab_root, diagnostics_state):
    reports_dir = os.path.join(lab_root, "reports")
    from MediCafe.layer1_readiness_model import build_layer1_readiness_model

    return build_layer1_readiness_model(lab_root, reports_dir, diagnostics_state, None, None)


def _execute_ingest_failure_steps(
    lab_root,
    repo_root,
    python_exe,
    execute_pipeline,
    wait_lock_sec,
    recorder,
    no_blocking_waits=False,
):
    from MediCafe import evidence_manifest as em

    lab = em.read_lab_state(lab_root)
    st = lab.get("diagnostics_state") or {}
    cr = lab.get("run_cursor") or {}

    def step_ingest_snapshot():
        info = em.resolve_phase_c_summary(lab_root, st, cr)
        snap = {
            "run_id": info.get("run_id"),
            "summary_exists": bool(info.get("exists")),
            "expected_path": info.get("expected_path"),
        }
        summ = info.get("summary") if isinstance(info.get("summary"), dict) else {}
        if summ:
            snap["ingest_ok"] = summ.get("ok")
            snap["rows_failed"] = summ.get("rows_failed")
            snap["operator_hint"] = _safe_ascii(summ.get("operator_hint"), 400)
            snap["db_error_detail"] = _safe_ascii(summ.get("db_error_detail"), 400)
        if not info.get("exists"):
            return _step_warn("ingest_write_summary missing for last_phase_c_run_id", snap)
        return _step_ok("ingest summary captured", snap)

    def step_lock_wait():
        lab2 = em.read_lab_state(lab_root)
        st2 = lab2.get("diagnostics_state") or {}
        cr2 = lab2.get("run_cursor") or {}
        info = em.resolve_phase_c_summary(lab_root, st2, cr2)
        summ = info.get("summary") if isinstance(info.get("summary"), dict) else {}
        hint = _hint_suggests_lock(summ.get("operator_hint")) or _hint_suggests_lock(summ.get("db_error_detail"))
        sec = int(wait_lock_sec or 0)
        if no_blocking_waits:
            would = sec if sec > 0 else (60 if hint else 0)
            if would > 0 or hint:
                return _step_skip(
                    "blocking wait skipped (non-interactive bundled path)",
                    {"hint_detected": bool(hint), "would_have_waited_sec": would},
                )
            return _step_skip("no lock-style hint and wait_lock_sec is 0")
        if not hint and sec <= 0:
            return _step_skip("no lock-style hint and wait_lock_sec is 0")
        sleep_sec = sec if sec > 0 else (60 if hint else 0)
        if sleep_sec <= 0:
            return _step_skip("nothing to wait")
        time.sleep(sleep_sec)
        return _step_ok("waited_sec={0}".format(sleep_sec), {"hint_detected": bool(hint)})

    def step_classify_escalation():
        lab2 = em.read_lab_state(lab_root)
        st2 = lab2.get("diagnostics_state") or {}
        cr2 = lab2.get("run_cursor") or {}
        info = em.resolve_phase_c_summary(lab_root, st2, cr2)
        summ = info.get("summary") if isinstance(info.get("summary"), dict) else {}
        try:
            rf = int(summ.get("rows_failed") or 0)
        except (TypeError, ValueError):
            rf = 0
        if rf >= _ROWS_FAILED_ESCALATION_THRESHOLD:
            return _step_warn(
                "rows_failed>={0}: treat as validation-scale; bundle will be sent for triage.".format(
                    _ROWS_FAILED_ESCALATION_THRESHOLD
                ),
                {"rows_failed": rf},
            )
        return _step_ok("rows_failed below escalation threshold", {"rows_failed": rf})

    def step_disk():
        try:
            usage = shutil.disk_usage(lab_root)
            data = {
                "total_bytes": usage.total,
                "used_bytes": usage.used,
                "free_bytes": usage.free,
            }
            free_gb = float(usage.free) / (1024.0 ** 3)
            if free_gb < 0.5:
                return _step_warn("very low free disk space on lab volume", data)
            return _step_ok("disk_usage sampled", data)
        except Exception as ex:
            return _step_err("disk_usage failed: {0}".format(_safe_ascii(ex, 200)))

    def step_writable_reports():
        reports_dir = os.path.join(lab_root, "reports")
        try:
            if not os.path.isdir(reports_dir):
                os.makedirs(reports_dir)
        except Exception as ex:
            return _step_err("cannot ensure reports dir: {0}".format(_safe_ascii(ex, 200)))
        probe = os.path.join(reports_dir, ".layer1_runbook_write_probe")
        try:
            with open(probe, "a") as handle:
                handle.write("# probe\n")
            return _step_ok("reports dir append ok", {"probe_path": probe})
        except Exception as ex:
            return _step_err("reports dir not writable: {0}".format(_safe_ascii(ex, 200)))

    def step_optional_pipeline():
        if not execute_pipeline:
            return _step_skip("--execute-pipeline not set")
        script = _shadow_pipeline_script(repo_root)
        if not script:
            return _step_err("run_shadow_pipeline.py not found under repo_root")
        env = os.environ.copy()
        env["MEDICAFE_LAB_DIR"] = lab_root
        cwd = os.path.dirname(script)
        cmd = [python_exe, script, "--lab-dir", lab_root]
        try:
            rc = subprocess.call(cmd, cwd=cwd, env=env)
        except Exception as ex:
            return _step_err("subprocess failed: {0}".format(_safe_ascii(ex, 200)))
        if rc != 0:
            return _step_warn("shadow pipeline exited non-zero", {"returncode": rc})
        return _step_ok("shadow pipeline completed", {"returncode": rc})

    def step_refresh_layer1():
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        st3 = _read_json_dict(state_path)
        m = _build_layer1_model(lab_root, st3)
        data = {
            "layer1_readiness_status": m.get("layer1_readiness_status"),
            "layer1_current_blocker": m.get("layer1_current_blocker"),
            "layer1_blocked_at_phase": m.get("layer1_blocked_at_phase"),
            "next_operator_action": _safe_ascii(m.get("next_operator_action"), 400),
        }
        return _step_ok("layer1 model refreshed from disk", data)

    order = [
        ("1_ingest_summary_snapshot", step_ingest_snapshot),
        ("2_lock_wait_optional", step_lock_wait),
        ("3_classify_rows_failed", step_classify_escalation),
        ("4_disk_space", step_disk),
        ("5_reports_writable", step_writable_reports),
        ("6_shadow_pipeline_optional", step_optional_pipeline),
        ("7_refresh_layer1_model", step_refresh_layer1),
    ]
    for sid, fn in order:
        _run_step(recorder, sid, fn)


def _execute_manifest_pending_steps(lab_root, repo_root, python_exe, execute_pipeline, recorder):
    state_path = os.path.join(lab_root, "diagnostics_state.json")

    def step_manifest_snapshot():
        st = _read_json_dict(state_path)
        data = {
            "last_manifest_sha256": str(st.get("last_manifest_sha256") or "")[:20],
            "last_ingest_manifest_sha256": str(st.get("last_ingest_manifest_sha256") or "")[:20],
            "last_phase_c_shadow_recovery_status": str(st.get("last_phase_c_shadow_recovery_status") or ""),
        }
        return _step_ok("diagnostics SHA snapshot", data)

    def step_recovery_status():
        st = _read_json_dict(state_path)
        stat = str(st.get("last_phase_c_shadow_recovery_status") or "").strip().lower()
        if stat in ("running", "in_progress", "started"):
            return _step_warn("shadow recovery still in progress per diagnostics", {"status": stat})
        return _step_ok("shadow recovery not marked in-flight", {"status": stat or "(empty)"})

    def step_optional_pipeline():
        if not execute_pipeline:
            return _step_skip("--execute-pipeline not set")
        script = _shadow_pipeline_script(repo_root)
        if not script:
            return _step_err("run_shadow_pipeline.py not found under repo_root")
        env = os.environ.copy()
        env["MEDICAFE_LAB_DIR"] = lab_root
        cwd = os.path.dirname(script)
        cmd = [python_exe, script, "--lab-dir", lab_root]
        try:
            rc = subprocess.call(cmd, cwd=cwd, env=env)
        except Exception as ex:
            return _step_err("subprocess failed: {0}".format(_safe_ascii(ex, 200)))
        if rc != 0:
            return _step_warn("shadow pipeline exited non-zero", {"returncode": rc})
        return _step_ok("shadow pipeline completed", {"returncode": rc})

    def step_refresh_layer1():
        st3 = _read_json_dict(state_path)
        m = _build_layer1_model(lab_root, st3)
        data = {
            "layer1_readiness_status": m.get("layer1_readiness_status"),
            "layer1_current_blocker": m.get("layer1_current_blocker"),
        }
        return _step_ok("layer1 model refreshed from disk", data)

    order = [
        ("1_manifest_sha_snapshot", step_manifest_snapshot),
        ("2_shadow_recovery_status", step_recovery_status),
        ("3_shadow_pipeline_optional", step_optional_pipeline),
        ("4_refresh_layer1_model", step_refresh_layer1),
    ]
    for sid, fn in order:
        _run_step(recorder, sid, fn)


def build_runbook_telemetry_document(
    lab_root,
    repo_root,
    python_exe,
    execute_pipeline,
    wait_lock_sec,
    no_blocking_waits=False,
):
    """
    Run ordered automation steps and return a JSON-serializable telemetry dict.

    Does not create bundles or send email.

    When ``no_blocking_waits`` is True (System Health Pack auto-attach), lock-wait
    sleeps are not performed, so bundle collection stays responsive. Full shadow
    pipeline subprocess still runs only when ``execute_pipeline`` is True.
    """
    lab_root = os.path.abspath(str(lab_root or "").strip())
    repo_root = os.path.abspath(str(repo_root or _default_repo_root()).strip())
    python_exe = str(python_exe or sys.executable).strip() or sys.executable
    recorder = []
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    diagnostics_state = _read_json_dict(state_path)
    layer1_before = _build_layer1_model(lab_root, diagnostics_state)
    runbook_key = _detect_runbook_key(layer1_before)

    doc = {
        "schema_version": TELEMETRY_SCHEMA_VERSION,
        "generated_at_utc": _iso_utc_now(),
        "lab_root": lab_root,
        "repo_root": repo_root,
        "runbook_key": runbook_key or "unsupported",
        "execute_pipeline": bool(execute_pipeline),
        "wait_lock_sec": int(wait_lock_sec or 0),
        "no_blocking_waits": bool(no_blocking_waits),
        "layer1_model_before": {
            "layer1_readiness_status": layer1_before.get("layer1_readiness_status"),
            "layer1_current_blocker": layer1_before.get("layer1_current_blocker"),
            "layer1_blocked_at_phase": layer1_before.get("layer1_blocked_at_phase"),
            "next_operator_action": _safe_ascii(layer1_before.get("next_operator_action"), 500),
        },
        "layer1_operator_runbook_checklist": layer1_before.get("layer1_operator_runbook_checklist") or [],
        "steps": recorder,
    }

    if runbook_key == "phase_c_ingest_failure":
        _execute_ingest_failure_steps(
            lab_root,
            repo_root,
            python_exe,
            execute_pipeline,
            wait_lock_sec,
            recorder,
            no_blocking_waits=bool(no_blocking_waits),
        )
    elif runbook_key == "phase_c_manifest_pending":
        _execute_manifest_pending_steps(lab_root, repo_root, python_exe, execute_pipeline, recorder)
    else:
        _run_step(
            recorder,
            "0_unsupported_blocker",
            lambda: _step_skip(
                "layer1_current_blocker is not phase_c_manifest_not_ingested or phase_c_ingest_failed; no automated runbook."
            ),
        )

    diagnostics_after = _read_json_dict(state_path)
    layer1_after = _build_layer1_model(lab_root, diagnostics_after)
    doc["layer1_model_after"] = {
        "layer1_readiness_status": layer1_after.get("layer1_readiness_status"),
        "layer1_current_blocker": layer1_after.get("layer1_current_blocker"),
        "layer1_blocked_at_phase": layer1_after.get("layer1_blocked_at_phase"),
        "next_operator_action": _safe_ascii(layer1_after.get("next_operator_action"), 500),
    }
    doc["layer1_operator_runbook_checklist_after"] = layer1_after.get("layer1_operator_runbook_checklist") or []
    doc["automation_runbook_checklist_lines"] = _format_automation_steps_as_checklist_lines(recorder)
    return doc


def write_telemetry_json(lab_root, doc):
    """Write telemetry under lab ``reports/``. Returns absolute path or "" on failure."""
    reports_dir = os.path.join(lab_root, "reports")
    try:
        if not os.path.isdir(reports_dir):
            os.makedirs(reports_dir)
    except Exception:
        return ""
    stamp = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    name = "layer1_phase_c_runbook_telemetry_{0}.json".format(stamp)
    path = os.path.join(reports_dir, name)
    try:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(doc, handle, indent=2, sort_keys=True)
            handle.write("\n")
        return path
    except Exception:
        return ""


def _collect_shp_style_evidence_tuples(lab_root):
    """
    Mirror ``send_latest_system_health_pack`` report picks: latest B/C/D/E/F artifacts
    under ``reports/``, plus ``layer1_join_debug_*`` when the QA summary recommends
    bundle attachment (same gates as the manual SHP send path).
    """
    out = []
    seen_paths = set()

    def _add_path(fullpath, alias):
        if not fullpath or not os.path.isfile(fullpath):
            return
        ap = os.path.normcase(os.path.abspath(fullpath))
        if ap in seen_paths:
            return
        seen_paths.add(ap)
        name = alias or os.path.basename(fullpath)
        out.append((name, fullpath))

    lab_root = os.path.abspath(str(lab_root or "").strip())
    try:
        from MediCafe.cloud_readiness_actions import _select_latest_evidence_files
    except Exception:
        return out

    phase_files = []
    for phase_specs in (
        [("artifact_discovery_summary_", None)],
        [("ingest_write_summary_", None), ("phase_c_shadow_recovery_", None)],
        [("qa_canonical_summary_", None)],
        [("projection_parity_summary_", None)],
        [
            ("shadow_run_report_", None),
            ("shadow_evidence_index_", ".json"),
            ("phase_f_mismatch_", ".txt"),
        ],
    ):
        try:
            rows = _select_latest_evidence_files(lab_root, phase_specs)
        except Exception:
            rows = []
        for row in rows:
            phase_files.append(row)

    for basename, fullpath in phase_files:
        _add_path(fullpath, basename)
        if basename.startswith("qa_canonical_summary_") and basename.endswith(".json"):
            qa_payload = _read_json_dict(fullpath)
            if qa_payload.get("layer1_join_debug_generated") and qa_payload.get(
                "layer1_support_bundle_attachment_recommended"
            ):
                for key in (
                    "layer1_join_debug_pack_path",
                    "layer1_join_debug_summary_path",
                    "layer1_join_debug_samples_path",
                ):
                    layer1_path = str(qa_payload.get(key, "") or "").strip()
                    if layer1_path:
                        _add_path(layer1_path, os.path.basename(layer1_path))

    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    exec_handoff_path = str(st.get("last_phase_c_execution_handoff_report_path") or "").strip()
    if not exec_handoff_path:
        cr = _read_json_dict(os.path.join(lab_root, "run_cursor.json"))
        if isinstance(cr, dict):
            exec_handoff_path = str(cr.get("last_phase_c_execution_handoff_report_path") or "").strip()
    if exec_handoff_path and os.path.isfile(exec_handoff_path):
        _add_path(exec_handoff_path, os.path.basename(exec_handoff_path))
        if exec_handoff_path.endswith(".json"):
            txt_handoff = exec_handoff_path[:-5] + ".txt"
            if os.path.isfile(txt_handoff):
                _add_path(txt_handoff, os.path.basename(txt_handoff))
    return out


def build_runbook_bundle_extra_files(lab_root, telemetry_path):
    """
    Extra ZIP members for runbook automation: telemetry JSON first, then SHP-style
    lab ``reports/`` companions. ``collect_support_bundle`` merges manifest attachments
    first; duplicate basenames follow manifest precedence.
    """
    lab_root = os.path.abspath(str(lab_root or "").strip())
    out = []
    seen_names = set()

    def add_named(name, path):
        if not name or not path or not os.path.isfile(path):
            return
        if name in seen_names:
            return
        seen_names.add(name)
        out.append((name, path))

    if telemetry_path and os.path.isfile(telemetry_path):
        add_named(os.path.basename(telemetry_path), telemetry_path)
    for basename, fullpath in _collect_shp_style_evidence_tuples(lab_root):
        add_named(basename, fullpath)
    return out


def submit_telemetry_via_support_bundle(
    lab_root,
    repo_root,
    telemetry_path,
    telemetry_doc,
    skip_interactive_reauth,
):
    """
    Package telemetry using ``collect_support_bundle`` + ``submit_support_bundle_email``.

    Uses ``system_health_pack`` evidence resolution (diagnostics, cursor, Phase C
    union when applicable), appends the same ``reports/`` companions as a manual
    System Health Pack (including QA-driven ``layer1_join_debug_*`` when recommended),
    and sets ``extra_meta['bundle_kind']`` to ``layer1_phase_c_runbook`` for ZIP naming.
    """
    from MediCafe import evidence_manifest as em
    from MediCafe.error_reporter import collect_support_bundle, submit_support_bundle_email

    lab_root = os.path.abspath(str(lab_root or "").strip())
    repo_root = os.path.abspath(str(repo_root or _default_repo_root()).strip())
    st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
    anchor = str(st.get("last_shadow_pipeline_run_id") or st.get("active_run_id") or "").strip()

    extra_meta = {
        "bundle_kind": "layer1_phase_c_runbook",
        "error_summary": _safe_ascii(
            "Layer1 Phase C runbook automation | runbook_key={0}".format(
                telemetry_doc.get("runbook_key") or "unknown"
            ),
            300,
        ),
        "layer1_phase_c_runbook": telemetry_doc,
    }
    extra_files = build_runbook_bundle_extra_files(lab_root, telemetry_path)

    req = em.build_evidence_request(
        "system_health_pack",
        "layer1_phase_c_runbook_helper",
        lab_root,
        anchor_run_id=anchor,
        reason="layer1_phase_c_runbook_automation",
    )
    manifest = em.resolve_evidence_manifest(req)
    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
        evidence_manifest=manifest,
    )
    if not zip_path:
        return False, "", ""
    ok = submit_support_bundle_email(
        zip_path=zip_path,
        include_traceback=False,
        skip_interactive_reauth=bool(skip_interactive_reauth),
        extra_meta=extra_meta,
        evidence_manifest=manifest,
    )
    return bool(ok), zip_path, "" if ok else "submit_support_bundle_email returned false"


def run_cli(argv=None):
    parser = argparse.ArgumentParser(description="Layer 1 Phase C runbook automation + telemetry bundle.")
    parser.add_argument("--lab-root", default="", help="Lab root (or set MEDICAFE_LAB_DIR).")
    parser.add_argument("--repo-root", default="", help="Repository root (default: parent of MediCafe package).")
    parser.add_argument("--python-exe", default=sys.executable, help="Python for shadow pipeline subprocess.")
    parser.add_argument(
        "--execute-pipeline",
        action="store_true",
        help="After checks, run scripts/unified_model/run_shadow_pipeline.py once (blocking).",
    )
    parser.add_argument(
        "--wait-lock-sec",
        type=int,
        default=0,
        help="Seconds to sleep when lock-style ingest hints apply (0 = auto 60s only when hint matches).",
    )
    parser.add_argument("--dry-run", action="store_true", help="Run steps and print telemetry path only; no bundle.")
    parser.add_argument(
        "--no-send",
        action="store_true",
        help="Build support ZIP only; do not call submit_support_bundle_email.",
    )
    parser.add_argument(
        "--allow-interactive-reauth",
        action="store_true",
        help="Pass through to submit_support_bundle_email (default skips interactive reauth).",
    )
    args = parser.parse_args(argv)

    lab_root = _resolve_lab_root(args.lab_root)
    if not lab_root or not os.path.isdir(lab_root):
        print("Invalid lab root: set --lab-root or MEDICAFE_LAB_DIR.", file=sys.stderr)
        return 2

    repo_root = str(args.repo_root or "").strip() or _default_repo_root()
    doc = build_runbook_telemetry_document(
        lab_root,
        repo_root,
        args.python_exe,
        bool(args.execute_pipeline),
        int(args.wait_lock_sec or 0),
    )
    path = write_telemetry_json(lab_root, doc)
    if not path:
        print("Failed to write telemetry JSON under reports/.", file=sys.stderr)
        return 3
    print("Telemetry: {0}".format(path))

    if args.dry_run:
        print(json.dumps(doc, indent=2, sort_keys=True))
        return 0

    if args.no_send:
        from MediCafe import evidence_manifest as em
        from MediCafe.error_reporter import collect_support_bundle

        st = _read_json_dict(os.path.join(lab_root, "diagnostics_state.json"))
        anchor = str(st.get("last_shadow_pipeline_run_id") or st.get("active_run_id") or "").strip()
        extra_meta = {
            "bundle_kind": "layer1_phase_c_runbook",
            "error_summary": _safe_ascii(
                "Layer1 Phase C runbook automation | runbook_key={0}".format(doc.get("runbook_key") or "unknown"),
                300,
            ),
            "layer1_phase_c_runbook": doc,
        }
        req = em.build_evidence_request(
            "system_health_pack",
            "layer1_phase_c_runbook_helper",
            lab_root,
            anchor_run_id=anchor,
            reason="layer1_phase_c_runbook_automation",
        )
        manifest = em.resolve_evidence_manifest(req)
        zip_path = collect_support_bundle(
            include_traceback=False,
            extra_meta=extra_meta,
            extra_files=build_runbook_bundle_extra_files(lab_root, path) or None,
            evidence_manifest=manifest,
        )
        if not zip_path:
            print("collect_support_bundle failed.", file=sys.stderr)
            return 4
        print("Bundle: {0}".format(zip_path))
        return 0

    ok, zip_path, err = submit_telemetry_via_support_bundle(
        lab_root,
        repo_root,
        path,
        doc,
        skip_interactive_reauth=not bool(args.allow_interactive_reauth),
    )
    if not ok:
        print("Bundle send failed: {0} zip={1}".format(err or "unknown", zip_path), file=sys.stderr)
        return 5
    print("Submitted bundle: {0}".format(zip_path))
    return 0


if __name__ == "__main__":
    sys.exit(run_cli())
