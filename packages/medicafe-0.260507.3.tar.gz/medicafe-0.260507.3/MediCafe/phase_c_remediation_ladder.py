# -*- coding: utf-8 -*-
"""
Phase C self-heal remediation ladder (selection constants and re-exports).

State mutations and subprocess orchestration live in:
``scripts/unified_model/phase_c_self_heal_state.py`` and ``scripts/unified_model/run_shadow_pipeline.py``.
"""
from __future__ import print_function

# Tier semantics (failure_count 0 -> tier 1, 1 -> tier 2, 2 -> tier 3, >=3 -> tier 4 circuit)
PHASE_C_SELF_HEAL_TIER_SHADOW_RECOVERY = 1
PHASE_C_SELF_HEAL_TIER_FORCE_DB_REBUILD = 2
PHASE_C_SELF_HEAL_TIER_QUARANTINE_REPORTS = 3
PHASE_C_SELF_HEAL_TIER_CIRCUIT = 4


def remediation_tier_for_failure_count(failure_count):
    """Pure selector; mirrors ``phase_c_self_heal_state.remediation_tier_for_failure_count``."""
    try:
        n = int(failure_count)
    except Exception:
        n = 0
    if n >= 3:
        return PHASE_C_SELF_HEAL_TIER_CIRCUIT
    return n + 1
