#!/usr/bin/env python
"""
Unified startup/attach orchestrator for Cloud Readiness and launcher flows.

This module centralizes policy selection and runtime decisions so callers
do not launch bootstrap ad-hoc from multiple paths.
"""
from __future__ import print_function

import os
import subprocess
import time
import json
import sys
import calendar

STATUS_STARTED_NEW = "STARTED_NEW"
STATUS_ALREADY_RUNNING = "ALREADY_RUNNING"
STATUS_READY_NOOP = "READY_NOOP"
STATUS_FAILED = "FAILED"

INTENT_ATTACH_ONLY = "ATTACH_ONLY"
INTENT_ENSURE_BASELINE = "ENSURE_BASELINE"
INTENT_START_OR_ATTACH_PIPELINE = "START_OR_ATTACH_PIPELINE"

ENTRYPOINT_STARTUP = "STARTUP"
ENTRYPOINT_MENU = "MENU"
ENTRYPOINT_MANUAL = "MANUAL"
ENTRYPOINT_HEALTH_VIEW = "HEALTH_VIEW"
ENTRYPOINT_REPORT_VIEW = "REPORT_VIEW"
ENTRYPOINT_DIAGNOSTIC = "DIAGNOSTIC"

ACTION_HEALTH_VIEW = "HEALTH_VIEW"
ACTION_REPORT_VIEW = "REPORT_VIEW"
ACTION_OPEN_REPORT = "OPEN_REPORT"
ACTION_MANUAL_FULL_PIPELINE = "MANUAL_FULL_PIPELINE"
ACTION_ENSURE_PHASE_A_ONLY = "ENSURE_PHASE_A_ONLY"
ACTION_STARTUP = "STARTUP"

ERROR_PIPELINE_ALREADY_RUNNING = "PIPELINE_ALREADY_RUNNING"
ERROR_BOOTSTRAP_ATTACHED = "BOOTSTRAP_ATTACHED_TO_EXISTING"
ERROR_READY_NOOP = "READY_NOOP"
ERROR_LOCK_RECOVERY = "FAILED_LOCK_RECOVERY"
ERROR_POLICY_PHASE_A_DISABLED = "FAILED_POLICY_PHASE_A_DISABLED"
ERROR_BOOTSTRAP_LAUNCH_FAILED = "BOOTSTRAP_LAUNCH_FAILED"
ERROR_PIPELINE_SPAWN_FAILED = "PIPELINE_SPAWN_FAILED"
try:
    _orch_scripts = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'scripts', 'unified_model'))
    if _orch_scripts not in sys.path:
        sys.path.insert(0, _orch_scripts)
    from pipeline_exit_classification import (
        PIPELINE_INTERRUPTED_CONTROL_EVENT,
        classify_phase_exit,
    )
except Exception:
    PIPELINE_INTERRUPTED_CONTROL_EVENT = "PIPELINE_INTERRUPTED_CONTROL_EVENT"

    def classify_phase_exit(rc, from_keyboard_interrupt_parent=False):
        return {
            "interrupted": bool(from_keyboard_interrupt_parent) or rc == 130,
            "hex_rc": "",
            "raw_rc": rc,
        }


# Legacy alias (same normalized code as runner).
ERROR_INTERRUPTED_UNKNOWN = PIPELINE_INTERRUPTED_CONTROL_EVENT

DEFAULT_STALE_SECONDS = 180

DEFAULT_STARTUP_AUTORUN_COOLDOWN_SECONDS = 10 * 60


def _parse_iso_utc_to_epoch(ts):
    ts_val = str(ts or "").strip()
    if not ts_val:
        return None
    try:
        parsed = time.strptime(ts_val, "%Y-%m-%dT%H:%M:%SZ")
        return calendar.timegm(parsed)
    except Exception:
        return None


def _startup_autorun_cooldown_seconds(env):
    raw = (env or {}).get("MEDICAFE_SHADOW_STARTUP_AUTORUN_COOLDOWN_SECONDS", "")
    if raw is None or str(raw).strip() == "":
        return DEFAULT_STARTUP_AUTORUN_COOLDOWN_SECONDS
    try:
        value = int(str(raw).strip())
    except Exception:
        return DEFAULT_STARTUP_AUTORUN_COOLDOWN_SECONDS
    if value < 0:
        return DEFAULT_STARTUP_AUTORUN_COOLDOWN_SECONDS
    return value


def _should_suppress_startup_autorun(action_id, entrypoint, state, env):
    action = str(action_id or "").strip().upper()
    ep = str(entrypoint or "").strip().upper()
    if action != ACTION_STARTUP or ep != ENTRYPOINT_STARTUP:
        return False, ""
    cooldown = _startup_autorun_cooldown_seconds(env)
    if cooldown <= 0:
        return False, ""
    if state.get("last_shadow_pipeline_ok") is not True:
        return False, ""
    finished_at = state.get("last_shadow_pipeline_finished_at_utc", "")
    finished_epoch = _parse_iso_utc_to_epoch(finished_at)
    if finished_epoch is None:
        return False, ""
    age = int(time.time() - finished_epoch)
    if age < 0:
        return False, ""
    if age < cooldown:
        return True, "Recent startup auto-run suppressed (last successful run finished {0}s ago).".format(age)
    return False, ""


LOCK_OUTCOME_OK = "ok"
LOCK_OUTCOME_CONTENDED_ATTACH = "contended_attach"
LOCK_OUTCOME_STALE_LOCK_RECOVERED = "stale_lock_recovered"
LOCK_OUTCOME_HARD_LOCK_FAIL = "hard_lock_fail"


def _utc_now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _to_bool(value):
    return str(value).strip().lower() in ("1", "true", "yes", "on", "y")


def _pid_running(pid):
    try:
        pid_int = int(pid)
    except (TypeError, ValueError):
        return False
    if pid_int <= 0:
        return False
    try:
        os.kill(pid_int, 0)
        return True
    except Exception:
        return False


def _parse_lock(lock_path):
    result = {"exists": False, "pid": None, "heartbeat_at_utc": None}
    if not lock_path or not os.path.exists(lock_path):
        return result
    result["exists"] = True
    try:
        with open(lock_path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if line.startswith("pid="):
                    result["pid"] = line[4:].strip()
                elif line.startswith("heartbeat_at_utc="):
                    result["heartbeat_at_utc"] = line[17:].strip()
    except Exception:
        pass
    return result


def _is_stale(lock_snapshot, stale_seconds):
    pid = lock_snapshot.get("pid")
    if pid and _pid_running(pid):
        return False
    hb = lock_snapshot.get("heartbeat_at_utc")
    if not hb:
        return True
    try:
        # Format: YYYY-MM-DDTHH:MM:SSZ
        ts = time.strptime(hb, "%Y-%m-%dT%H:%M:%SZ")
        age = time.time() - time.mktime(ts)
        return age > stale_seconds
    except Exception:
        return True


def _read_state(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _safe_list_unified_model_py(unified_model_dir, limit=20):
    """Best-effort listing of nearby scripts for missing-script diagnostics."""
    snapshot = {
        "unified_model_dir": unified_model_dir,
        "unified_model_dir_exists": os.path.isdir(unified_model_dir),
        "python_files": [],
        "python_file_count": 0,
    }
    if not snapshot["unified_model_dir_exists"]:
        return snapshot
    try:
        py_files = []
        for name in os.listdir(unified_model_dir):
            full = os.path.join(unified_model_dir, name)
            if os.path.isfile(full) and name.endswith(".py"):
                py_files.append(name)
        py_files.sort()
        snapshot["python_file_count"] = len(py_files)
        snapshot["python_files"] = py_files[:limit]
        if len(py_files) > limit:
            snapshot["truncated"] = True
    except Exception as e:
        snapshot["list_error"] = str(e)
    return snapshot


def _build_unified_model_script_trace(repo_root, script_name, python_exe=None):
    root = os.path.abspath(repo_root or os.getcwd())
    candidates = [root]
    parent = os.path.dirname(root)
    if parent and parent != root:
        candidates.append(parent)
    try:
        package_repo_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    except Exception:
        package_repo_root = ""
    package_repo_is_checkout = bool(package_repo_root) and os.path.isdir(os.path.join(package_repo_root, '.git'))
    use_package_repo_root_fallback = (
        not str(repo_root or "").strip()
        or (bool(package_repo_root) and not package_repo_is_checkout)
    )

    # Keep script discovery aligned with the interpreter used to launch scripts.
    requested_executable = os.path.abspath(str(python_exe or "").strip()) if python_exe else ""
    runtime_executable = os.path.abspath(sys.executable or "")
    executable = requested_executable or runtime_executable
    executable_dir = os.path.dirname(executable) if executable else ""
    inferred_prefix = os.path.dirname(executable_dir) if executable_dir else ""
    runtime_prefix = os.path.abspath(getattr(sys, "prefix", "") or "")

    extra_candidates = []
    if executable_dir:
        extra_candidates.extend([
            executable_dir,
            os.path.join(executable_dir, "Scripts"),
            os.path.join(executable_dir, "bin"),
            os.path.dirname(executable_dir),
        ])
    if inferred_prefix:
        extra_candidates.extend([
            inferred_prefix,
            os.path.join(inferred_prefix, "Scripts"),
            os.path.join(inferred_prefix, "bin"),
        ])
    # Retain runtime prefix as a late fallback for mixed environments.
    if runtime_prefix:
        extra_candidates.extend([
            runtime_prefix,
            os.path.join(runtime_prefix, "Scripts"),
            os.path.join(runtime_prefix, "bin"),
        ])
    for candidate in extra_candidates:
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    if use_package_repo_root_fallback and package_repo_root and package_repo_root not in candidates:
        # Fall back to the installed package location after checking repo and
        # interpreter-derived roots, but avoid masking explicit repo/prefix
        # resolution while running from a live source checkout.
        candidates.append(package_repo_root)
    checks = []
    for candidate in candidates:
        script_path = os.path.join(candidate, "scripts", "unified_model", script_name)
        unified_model_dir = os.path.join(candidate, "scripts", "unified_model")
        script_parent_dir = os.path.dirname(script_path)
        script_is_file = os.path.isfile(script_path)
        script_size_bytes = None
        if script_is_file:
            try:
                script_size_bytes = int(os.path.getsize(script_path))
            except Exception:
                script_size_bytes = None
        entry = {
            "candidate_repo_root": candidate,
            "script_path": script_path,
            "script_exists": script_is_file,
            "script_parent_dir": script_parent_dir,
            "script_parent_dir_exists": os.path.isdir(script_parent_dir),
            "script_size_bytes": script_size_bytes,
            "requested_repo_root": repo_root,
            "resolved_repo_root": root,
            "cwd": os.getcwd(),
        }
        entry.update(_safe_list_unified_model_py(unified_model_dir))
        checks.append(entry)
    return root, checks


def _find_unified_model_script(repo_root, script_name, python_exe=None):
    """Locate scripts/unified_model/{script_name} from repo_root or its parent."""
    root, checks = _build_unified_model_script_trace(repo_root, script_name, python_exe=python_exe)
    for check in checks:
        if check.get("script_exists"):
            return check.get("candidate_repo_root"), check.get("script_path"), checks
    return root, os.path.join(root, "scripts", "unified_model", script_name), checks


def resolve_unified_model_script(repo_root, script_name, python_exe=None):
    """Public resolver shared by launcher orchestration and pipeline phases."""
    return _find_unified_model_script(repo_root, script_name, python_exe=python_exe)


def resolve_phase_f_package_script(repo_root, python_exe=None):
    """Resolve the Phase F packaging script using the shared script resolver."""
    return resolve_unified_model_script(repo_root, "package_shadow_run_report.py", python_exe=python_exe)


def _format_process_launch_failure(stage_label, python_exe, script_path, cwd, exc):
    """Return a concise, operator-facing process launch failure message."""
    details = []
    if python_exe:
        details.append("python_exe={0}".format(python_exe))
    if script_path:
        details.append("script={0}".format(script_path))
    if cwd:
        details.append("cwd={0}".format(cwd))
    exc_text = str(exc) or exc.__class__.__name__
    if details:
        return "{0} failed: {1} [{2}]".format(stage_label, exc_text, "; ".join(details))
    return "{0} failed: {1}".format(stage_label, exc_text)


def _process_launch_payload(stage_label, python_exe, script_path, cwd, exc):
    winerror = None
    try:
        winerror = getattr(exc, "winerror", None)
    except Exception:
        winerror = None
    recoverability = "investigate_launch_environment"
    try:
        if winerror == 87:
            recoverability = "retry_after_fixing_python_exe_path_or_working_directory"
    except Exception:
        pass
    return {
        "stage": stage_label or "",
        "python_exe": python_exe or "",
        "script_path": script_path or "",
        "cwd": cwd or "",
        "exception_class": exc.__class__.__name__,
        "exception_message": str(exc),
        "cloud_readiness_evidence_code": "CLOUD_READINESS_STARTUP_ORCHESTRATION_FAILED",
        "winerror": winerror,
        "recoverability": recoverability,
    }


def _pipeline_launch_stage_label(action_id, entrypoint):
    action = str(action_id or "").strip().upper()
    ep = str(entrypoint or "").strip().upper()
    if action == ACTION_STARTUP or ep == ENTRYPOINT_STARTUP:
        return "Startup shadow pipeline launch"
    return "Shadow pipeline launch"


def _is_winerror_87(exc):
    try:
        if getattr(exc, "winerror", None) == 87:
            return True
    except Exception:
        pass
    try:
        if getattr(exc, "errno", None) == 87:
            return True
    except Exception:
        pass
    text = str(exc or "").lower()
    return "winerror 87" in text or "parameter is incorrect" in text


def _spawn_pipeline_process(python_exe, pipeline_script, script_repo_root, proc_env, ops):
    kwargs = {
        "cwd": script_repo_root,
        "env": proc_env,
        "stdout": (ops or {}).get("devnull"),
        "stderr": (ops or {}).get("devnull"),
    }
    try:
        subprocess.Popen([python_exe, pipeline_script], **kwargs)
        return {"ok": True, "retry_without_stdio": False, "exception": None}
    except Exception as first_exc:
        if not _is_winerror_87(first_exc):
            return {"ok": False, "retry_without_stdio": False, "exception": first_exc}
        try:
            subprocess.Popen([python_exe, pipeline_script], cwd=script_repo_root, env=proc_env)
            return {"ok": True, "retry_without_stdio": True, "exception": first_exc}
        except Exception as second_exc:
            return {
                "ok": False,
                "retry_without_stdio": True,
                "exception": second_exc,
                "first_exception": first_exc,
            }


def _result(status, error_code="", run_id="", pipeline_state="", active_phase="",
            diagnostic_path=None, report_path=None, message="", payload=None, lock_outcome=LOCK_OUTCOME_OK):
    return {
        "status": status,
        "error_code": error_code or "",
        "run_id": run_id or "",
        "pipeline_state": pipeline_state or "",
        "active_phase": active_phase or "",
        "diagnostic_path": diagnostic_path,
        "report_path": report_path,
        "message": message or "",
        "payload": payload or {},
        "lock_outcome": lock_outcome or LOCK_OUTCOME_OK,
    }


class PolicySelector(object):
    @staticmethod
    def select_intent(action_id, entrypoint, env, state_snapshot, lock_snapshot):
        del state_snapshot
        del lock_snapshot
        action = str(action_id or "").strip().upper()
        ep = str(entrypoint or "").strip().upper()
        read_only_actions = set([ACTION_HEALTH_VIEW, ACTION_REPORT_VIEW, ACTION_OPEN_REPORT])
        if action in read_only_actions:
            return INTENT_ATTACH_ONLY
        if action == ACTION_MANUAL_FULL_PIPELINE:
            return INTENT_START_OR_ATTACH_PIPELINE
        if ep == ENTRYPOINT_STARTUP and _to_bool((env or {}).get("MEDICAFE_SHADOW_AUTO_PIPELINE", "1")):
            return INTENT_START_OR_ATTACH_PIPELINE
        return INTENT_ENSURE_BASELINE


def start_or_attach_shadow_pipeline(action_id, entrypoint, repo_root=None, python_exe=None,
                                    env=None, env_flag_fn=None, ops=None):
    env = env or {}
    ops = ops or {}
    resolve_lab_root = ops.get("resolve_lab_root")
    lab_has_core = ops.get("lab_has_core_artifacts")
    write_diag = ops.get("write_bootstrap_diag")
    fail_message = ops.get("bootstrap_fail_message")
    if fail_message is None:
        fail_message = lambda code, message, diag_path=None: "{0}: {1}".format(code, message)
    if resolve_lab_root is None:
        raise ValueError("resolve_lab_root op required")
    if lab_has_core is None:
        raise ValueError("lab_has_core_artifacts op required")
    if repo_root is None:
        repo_root = os.getcwd()
    if python_exe is None:
        python_exe = "python"
    proc_env = os.environ.copy()
    proc_env.update(env)
    env_lab_root = str((env or {}).get("MEDICAFE_LAB_DIR", "") or "").strip()
    lab_root = env_lab_root if env_lab_root else resolve_lab_root(repo_root)
    proc_env["MEDICAFE_LAB_DIR"] = lab_root
    state_path = os.path.join(lab_root, "diagnostics_state.json")
    lock_path = os.path.join(lab_root, "shadow_pipeline.lock")
    state = _read_state(state_path)
    lock_snapshot = _parse_lock(lock_path)
    stale_seconds = DEFAULT_STALE_SECONDS
    if env_flag_fn is not None:
        try:
            configured = int((env or {}).get("MEDICAFE_PIPELINE_STALE_SECONDS", stale_seconds))
            if configured > 0:
                stale_seconds = configured
        except Exception:
            pass
    owner_healthy = lock_snapshot.get("exists") and not _is_stale(lock_snapshot, stale_seconds)
    intent = PolicySelector.select_intent(action_id, entrypoint, proc_env, state, lock_snapshot)

    active_run_id = state.get("active_run_id", "") or state.get("last_shadow_pipeline_run_id", "") or ""
    active_phase = state.get("active_phase", "") or state.get("last_shadow_pipeline_failed_phase", "") or ""
    pipeline_state = state.get("pipeline_state", "") or ("running" if owner_healthy else "idle")

    if owner_healthy:
        if intent == INTENT_ENSURE_BASELINE:
            return _result(STATUS_ALREADY_RUNNING, ERROR_BOOTSTRAP_ATTACHED, active_run_id,
                           pipeline_state, active_phase, message="Initialization in progress.",
                           lock_outcome=LOCK_OUTCOME_CONTENDED_ATTACH)
        return _result(STATUS_ALREADY_RUNNING, ERROR_PIPELINE_ALREADY_RUNNING, active_run_id,
                       pipeline_state, active_phase, message="Initialization in progress.",
                       lock_outcome=LOCK_OUTCOME_CONTENDED_ATTACH)

    has_lock_metadata = bool(lock_snapshot.get("pid") or lock_snapshot.get("heartbeat_at_utc"))
    stale_lock_recovered = False
    if lock_snapshot.get("exists") and has_lock_metadata and _is_stale(lock_snapshot, stale_seconds):
        try:
            os.remove(lock_path)
            stale_lock_recovered = True
        except Exception as e:
            # If lock vanished concurrently, continue; otherwise classify as lock recovery failure.
            if os.path.exists(lock_path):
                diag_path = write_diag(repo_root, lab_root, ERROR_LOCK_RECOVERY, {"exception": str(e)}) if write_diag else None
                return _result(
                    STATUS_FAILED,
                    ERROR_LOCK_RECOVERY,
                    active_run_id,
                    "failed",
                    active_phase,
                    diagnostic_path=diag_path,
                    message=fail_message(ERROR_LOCK_RECOVERY, "Failed stale-owner recovery", diag_path),
                    lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL,
                )

    lab_healthy = lab_has_core(lab_root)
    if intent == INTENT_ATTACH_ONLY:
        return _result(
            STATUS_READY_NOOP, ERROR_READY_NOOP, active_run_id, pipeline_state, active_phase, message="",
            lock_outcome=LOCK_OUTCOME_STALE_LOCK_RECOVERED if stale_lock_recovered else LOCK_OUTCOME_OK
        )

    suppress_startup, suppress_message = _should_suppress_startup_autorun(action_id, entrypoint, state, proc_env)
    if intent == INTENT_START_OR_ATTACH_PIPELINE and suppress_startup:
        return _result(
            STATUS_READY_NOOP, ERROR_READY_NOOP, active_run_id, "idle", "",
            message=suppress_message,
            lock_outcome=LOCK_OUTCOME_STALE_LOCK_RECOVERED if stale_lock_recovered else LOCK_OUTCOME_OK,
        )

    if intent == INTENT_ENSURE_BASELINE:
        if lab_healthy:
            return _result(
                STATUS_READY_NOOP, ERROR_READY_NOOP, active_run_id, "idle", "", message="",
                lock_outcome=LOCK_OUTCOME_STALE_LOCK_RECOVERED if stale_lock_recovered else LOCK_OUTCOME_OK
            )
        auto_validate_enabled = True
        if env_flag_fn is not None:
            auto_validate_enabled = env_flag_fn("MEDICAFE_PHASE_A_AUTO_VALIDATE", True)
        if not auto_validate_enabled:
            diag_path = write_diag(repo_root, lab_root, ERROR_POLICY_PHASE_A_DISABLED, {
                "action_id": action_id,
                "entrypoint": entrypoint,
            }) if write_diag else None
            return _result(
                STATUS_FAILED,
                ERROR_POLICY_PHASE_A_DISABLED,
                active_run_id,
                "failed",
                "",
                diagnostic_path=diag_path,
                message=fail_message(ERROR_POLICY_PHASE_A_DISABLED, "Phase A policy disabled while baseline is unhealthy", diag_path),
                lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
            )
        script_repo_root, bootstrap_script, bootstrap_checks = _find_unified_model_script(
            repo_root,
            "bootstrap_lab.py",
            python_exe=python_exe,
        )
        if not os.path.exists(bootstrap_script):
            missing_payload = {
                "script_name": "bootstrap_lab.py",
                "bootstrap_script": bootstrap_script,
                "script_resolution_checks": bootstrap_checks,
            }
            diag_path = write_diag(repo_root, lab_root, "BOOTSTRAP_SCRIPT_MISSING", missing_payload) if write_diag else None
            checked_paths = [c.get("script_path", "") for c in bootstrap_checks if c.get("script_path")]
            detail = "bootstrap_lab.py not found; checked: {0}".format(", ".join(checked_paths) if checked_paths else bootstrap_script)
            return _result(
                STATUS_FAILED,
                "BOOTSTRAP_SCRIPT_MISSING",
                active_run_id,
                "failed",
                "A",
                diagnostic_path=diag_path,
                message=fail_message("BOOTSTRAP_SCRIPT_MISSING", detail, diag_path),
                payload=missing_payload,
                lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
            )
        creationflags = 0
        if os.name == "nt":
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        try:
            rc = subprocess.call([python_exe, bootstrap_script], cwd=script_repo_root, env=proc_env, creationflags=creationflags)
        except KeyboardInterrupt:
            diag_path = write_diag(repo_root, lab_root, ERROR_INTERRUPTED_UNKNOWN, {}) if write_diag else None
            return _result(
                STATUS_FAILED,
                ERROR_INTERRUPTED_UNKNOWN,
                active_run_id,
                "failed",
                "A",
                diagnostic_path=diag_path,
                message=fail_message(ERROR_INTERRUPTED_UNKNOWN, "Phase A interrupted by control event; source unknown", diag_path),
                lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
            )
        except Exception as e:
            launch_label = "Phase A bootstrap launch"
            launch_payload = _process_launch_payload(launch_label, python_exe, bootstrap_script, script_repo_root, e)
            diag_path = write_diag(repo_root, lab_root, ERROR_BOOTSTRAP_LAUNCH_FAILED, launch_payload) if write_diag else None
            return _result(
                STATUS_FAILED,
                ERROR_BOOTSTRAP_LAUNCH_FAILED,
                active_run_id,
                "failed",
                "A",
                diagnostic_path=diag_path,
                message=fail_message(
                    ERROR_BOOTSTRAP_LAUNCH_FAILED,
                    _format_process_launch_failure(launch_label, python_exe, bootstrap_script, script_repo_root, e),
                    diag_path,
                ),
                payload=launch_payload,
                lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
            )
        if rc != 0:
            clf = classify_phase_exit(rc, False)
            if clf.get("interrupted"):
                diag_path = write_diag(
                    repo_root, lab_root, PIPELINE_INTERRUPTED_CONTROL_EVENT,
                    {"exit_code": rc, "hex_rc": clf.get("hex_rc", "")},
                ) if write_diag else None
                return _result(
                    STATUS_FAILED,
                    PIPELINE_INTERRUPTED_CONTROL_EVENT,
                    active_run_id,
                    "failed",
                    "A",
                    diagnostic_path=diag_path,
                    message=fail_message(
                        PIPELINE_INTERRUPTED_CONTROL_EVENT,
                        "Phase A bootstrap interrupted (control event); rc={0}".format(rc),
                        diag_path,
                    ),
                    lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
                )
            diag_path = write_diag(repo_root, lab_root, "PHASE_A_EXIT_{0}".format(rc), {"exit_code": rc}) if write_diag else None
            return _result(
                STATUS_FAILED,
                "PHASE_A_EXIT_{0}".format(rc),
                active_run_id,
                "failed",
                "A",
                diagnostic_path=diag_path,
                message=fail_message("PHASE_A_EXIT_{0}".format(rc), "Phase A bootstrap exited with code {0}".format(rc), diag_path),
                lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
            )
        return _result(
            STATUS_STARTED_NEW, "", active_run_id, "idle", "", message="",
            lock_outcome=LOCK_OUTCOME_STALE_LOCK_RECOVERED if stale_lock_recovered else LOCK_OUTCOME_OK
        )

    script_repo_root, pipeline_script, pipeline_checks = _find_unified_model_script(
        repo_root,
        "run_shadow_pipeline.py",
        python_exe=python_exe,
    )
    if not os.path.exists(pipeline_script):
        missing_payload = {
            "script_name": "run_shadow_pipeline.py",
            "pipeline_script": pipeline_script,
            "script_resolution_checks": pipeline_checks,
        }
        diag_path = write_diag(repo_root, lab_root, "PIPELINE_SCRIPT_MISSING", missing_payload) if write_diag else None
        checked_paths = [c.get("script_path", "") for c in pipeline_checks if c.get("script_path")]
        detail = "run_shadow_pipeline.py not found; checked: {0}".format(", ".join(checked_paths) if checked_paths else pipeline_script)
        return _result(
            STATUS_FAILED, "PIPELINE_SCRIPT_MISSING", active_run_id, "failed", "",
            diagnostic_path=diag_path,
            message=fail_message("PIPELINE_SCRIPT_MISSING", detail, diag_path),
            payload=missing_payload,
            lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK
        )
    spawn = _spawn_pipeline_process(python_exe, pipeline_script, script_repo_root, proc_env, ops)
    if not spawn.get("ok"):
        e = spawn.get("exception") or Exception("pipeline spawn failed")
        launch_label = _pipeline_launch_stage_label(action_id, entrypoint)
        launch_payload = _process_launch_payload(launch_label, python_exe, pipeline_script, script_repo_root, e)
        if spawn.get("retry_without_stdio"):
            launch_payload["retry_without_stdio"] = True
            first = spawn.get("first_exception")
            if first is not None:
                launch_payload["first_exception_class"] = first.__class__.__name__
                launch_payload["first_exception_message"] = str(first)
        diag_path = write_diag(repo_root, lab_root, ERROR_PIPELINE_SPAWN_FAILED, launch_payload) if write_diag else None
        return _result(
            STATUS_FAILED,
            ERROR_PIPELINE_SPAWN_FAILED,
            active_run_id,
            "failed",
            "A",
            diagnostic_path=diag_path,
            message=fail_message(
                ERROR_PIPELINE_SPAWN_FAILED,
                _format_process_launch_failure(launch_label, python_exe, pipeline_script, script_repo_root, e),
                diag_path,
            ),
            payload=launch_payload,
            lock_outcome=LOCK_OUTCOME_HARD_LOCK_FAIL if lock_snapshot.get("exists") else LOCK_OUTCOME_OK,
        )
    return _result(
        STATUS_STARTED_NEW, "", active_run_id, "running", "A", message="Initialization in progress.",
        lock_outcome=LOCK_OUTCOME_STALE_LOCK_RECOVERED if stale_lock_recovered else LOCK_OUTCOME_OK
    )

