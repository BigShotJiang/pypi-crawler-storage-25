# MediLink_Down.py
import hashlib
import json
import os
import shutil
import sys

# Add paths
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
current_dir = os.path.abspath(os.path.dirname(__file__))
if project_dir not in sys.path:
    sys.path.append(project_dir)
if current_dir not in sys.path:
    sys.path.append(current_dir)

# Use core utilities for imports
try:
    from MediCafe.core_utils import (
        get_config_loader_with_fallback,
        extract_medilink_config,
        check_internet_connection,
        get_api_client_factory,  # type: ignore[reportAttributeAccessIssue]
    )
    MediLink_ConfigLoader = get_config_loader_with_fallback()
    if MediLink_ConfigLoader is not None:
        log = MediLink_ConfigLoader.log
        load_configuration = MediLink_ConfigLoader.load_configuration
    else:
        raise ImportError("MediLink_ConfigLoader not available")
except ImportError:
    # Fallback for when core_utils is not available
    def log(message, level="INFO"):
        print("[{}] {}".format(level, message))
    def load_configuration():
        return {}, {}
    def extract_medilink_config(config):
        if isinstance(config, dict):
            return config.get('MediLink_Config', config)
        return {}
    def check_internet_connection(max_retries=3, initial_delay=1):
        return bool(False)
    def get_api_client_factory():
        return None

try:
    from MediLink_Decoder import (
        process_decoded_file,
        display_consolidated_records,
        write_records_to_csv,
        determine_file_type
    )
except ImportError:
    # Fallback if decoder not available
    process_decoded_file = None
    def display_consolidated_records(records):
        if records is None:
            return
        sys.stdout.write("{}\n".format(records))
    write_records_to_csv = None
    determine_file_type = None

try:
    from MediLink_RemittancePipeline import (
        write_jsonl,
        build_source_meta,
        build_crosswalk_lookups,
        resolve_remittance_dict,
        get_move_extensions,
        get_decode_extensions,
    )
except ImportError:
    write_jsonl = None
    build_source_meta = None
    build_crosswalk_lookups = None
    resolve_remittance_dict = None
    get_move_extensions = None
    get_decode_extensions = None

try:
    from MediLink_RemittanceIngest import ingest_decoded_records_to_canonical
except ImportError:
    ingest_decoded_records_to_canonical = None


def _compute_checksum(path):
    try:
        hasher = hashlib.sha1()
        with open(path, 'rb') as handle:
            for chunk in iter(lambda: handle.read(8192), b''):
                hasher.update(chunk)
        return "sha1:{}".format(hasher.hexdigest())
    except Exception:
        return None


def _summarize_remittance_store(storage_path):
    parsed_path = os.path.join(storage_path or '.', 'remittance_parsed.jsonl')
    ledger_path = os.path.join(storage_path or '.', 'remittance_file_ledger.jsonl')
    summary = {
        'storage_path': storage_path or '.',
        'parsed_path': parsed_path,
        'ledger_path': ledger_path,
        'parsed_exists': os.path.isfile(parsed_path),
        'ledger_exists': os.path.isfile(ledger_path),
        'parsed_rows': 0,
        'ledger_entries': 0,
        'file_derived_rows': 0,
        'claims_inquiry_rows': 0,
        'blank_patient_name_rows': 0,
        'unmatched_rows': 0,
        'rows_missing_schema_version': 0,
        'claims_inquiry_contract_gaps': 0,
    }

    if summary['ledger_exists']:
        try:
            with open(ledger_path, 'r') as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except (TypeError, ValueError):
                        continue
                    if isinstance(obj, dict):
                        summary['ledger_entries'] += 1
        except Exception:
            pass

    if not summary['parsed_exists']:
        return summary

    try:
        with open(parsed_path, 'r') as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except (TypeError, ValueError):
                    continue
                if not isinstance(rec, dict):
                    continue
                summary['parsed_rows'] += 1
                if rec.get('schema_version') in (None, ''):
                    summary['rows_missing_schema_version'] += 1
                if not str(rec.get('patient_name', '') or '').strip():
                    summary['blank_patient_name_rows'] += 1
                if str(rec.get('match_status', '') or '').strip() == 'unmatched':
                    summary['unmatched_rows'] += 1
                data_source = str(rec.get('data_source', '') or '').strip().lower()
                if data_source == 'parsed_file':
                    summary['file_derived_rows'] += 1
                elif data_source == 'claims_inquiry':
                    summary['claims_inquiry_rows'] += 1
                    if (
                        rec.get('processed_date') is None
                        or 'lookup_mode' not in rec
                        or 'claim_xwalk_data' not in rec
                        or 'document_refs' not in rec
                    ):
                        summary['claims_inquiry_contract_gaps'] += 1
    except Exception:
        pass

    return summary


def _plan_embedded_remittance_repair(storage_path, endpoint_results, force_full_repair=False):
    summary = _summarize_remittance_store(storage_path)
    reasons = []

    if force_full_repair:
        reasons.append('manual_full_sync')
    if summary.get('rows_missing_schema_version', 0):
        reasons.append(
            'rows_missing_schema_version={}'.format(summary.get('rows_missing_schema_version', 0))
        )
    if summary.get('claims_inquiry_contract_gaps', 0):
        reasons.append(
            'claims_inquiry_contract_gaps={}'.format(summary.get('claims_inquiry_contract_gaps', 0))
        )
    if summary.get('ledger_entries', 0) and summary.get('parsed_rows', 0) == 0:
        reasons.append('ledger_without_parsed_rows')

    degraded_endpoints = []
    for endpoint_key in sorted(endpoint_results or {}):
        status = _result_status((endpoint_results or {}).get(endpoint_key))
        if status == 'downloaded_no_records':
            degraded_endpoints.append(endpoint_key)
    if degraded_endpoints:
        reasons.append('downloaded_no_records={}'.format(','.join(degraded_endpoints)))

    summary['repair_recommended'] = bool(reasons)
    summary['repair_reasons'] = list(reasons)
    return {
        'should_run': bool(reasons),
        'reasons': reasons,
        'summary': summary,
    }


def _log_remittance_health_summary(summary):
    summary = summary if isinstance(summary, dict) else {}
    reasons = summary.get('repair_reasons') or []
    log(
        (
            "Remittance health summary: parsed_rows={parsed_rows} ledger_entries={ledger_entries} "
            "file_derived_rows={file_derived_rows} claims_inquiry_rows={claims_inquiry_rows} "
            "blank_patient_name_rows={blank_patient_name_rows} unmatched_rows={unmatched_rows} "
            "rows_missing_schema_version={rows_missing_schema_version} "
            "claims_inquiry_contract_gaps={claims_inquiry_contract_gaps} "
            "repair_recommended={repair_recommended} reasons={repair_reasons}"
        ).format(
            **{
                'parsed_rows': summary.get('parsed_rows', 0),
                'ledger_entries': summary.get('ledger_entries', 0),
                'file_derived_rows': summary.get('file_derived_rows', 0),
                'claims_inquiry_rows': summary.get('claims_inquiry_rows', 0),
                'blank_patient_name_rows': summary.get('blank_patient_name_rows', 0),
                'unmatched_rows': summary.get('unmatched_rows', 0),
                'rows_missing_schema_version': summary.get('rows_missing_schema_version', 0),
                'claims_inquiry_contract_gaps': summary.get('claims_inquiry_contract_gaps', 0),
                'repair_recommended': bool(reasons),
                'repair_reasons': ','.join(reasons) if reasons else 'none',
            }
        ),
        level="INFO",
    )


def _run_embedded_remittance_repair(config, reasons, silent=False):
    medi = extract_medilink_config(config)
    storage_path = medi.get('local_storage_path', '.') if isinstance(medi, dict) else '.'
    receipts_root = medi.get('local_claims_path') if isinstance(medi, dict) else None
    try:
        from MediCafe import remittance_backfill
    except ImportError as exc:
        log("Embedded remittance repair unavailable: {}".format(exc), level="WARNING")
        return {
            'attempted': True,
            'ok': False,
            'return_code': 1,
            'lines': ['Embedded remittance repair unavailable: {}'.format(exc)],
        }

    reason_text = ', '.join(reasons or ['unspecified'])
    log(
        "Running embedded remittance repair (storage={}, reasons={})".format(
            storage_path, reason_text
        ),
        level="INFO",
    )
    if not silent:
        try:
            print("\nRunning remittance repair...")
        except Exception:
            pass

    lines = []

    def _capture(line, stream='stdout'):
        text = str(line).strip()
        if not text:
            return
        lines.append(text)
        if text.startswith('ERROR'):
            level = "ERROR"
        elif text.startswith('WARNING'):
            level = "WARNING"
        else:
            level = "INFO"
        log("[Remittance Repair] {}".format(text), level=level)

    rc = 1
    try:
        rc = remittance_backfill.run_backfill(
            storage_path,
            receipts_root,
            dry_run=False,
            log_fn=_capture,
        )
    except Exception as exc:
        rc = 1
        _capture("ERROR: embedded remittance repair failed: {}".format(exc), stream='stderr')

    if not lines:
        log("[Remittance Repair] No repair output captured.", level="INFO")
    if not silent:
        try:
            if rc == 0:
                print("Remittance repair completed. See logs for rebuild summary.")
            else:
                print("Remittance repair encountered problems. See logs for details.")
        except Exception:
            pass
    return {
        'attempted': True,
        'ok': rc == 0,
        'return_code': rc,
        'lines': lines,
    }

try:
    from MediLink_DataMgmt import operate_winscp, read_text_lines_with_fallback
except ImportError:
    operate_winscp = None
    read_text_lines_with_fallback = None

try:
    from tqdm import tqdm
except ImportError:
    # Fallback for when tqdm is not available
    def tqdm(iterable, **kwargs):
        return iterable

try:
    from MediCafe.submission_index import append_submission_record as _append_submission_record, ensure_submission_index as _ensure_submission_index, append_ack_event as _append_ack_event
except ImportError:
    # Fallback if submission_index not available
    _append_submission_record = None
    _ensure_submission_index = None
    _append_ack_event = None


def _is_test_mode(config):
    medi = extract_medilink_config(config)
    return bool(medi.get('TestMode', False))


def _endpoint_text(endpoint_info, key, default=''):
    if not isinstance(endpoint_info, dict):
        return default
    value = endpoint_info.get(key)
    if value is None:
        return default
    text = str(value).strip()
    return text if text else default


def _endpoint_missing_fields(endpoint_info, fields):
    missing_fields = []
    for field in fields:
        if not _endpoint_text(endpoint_info, field):
            missing_fields.append(field)
    return missing_fields


def _infer_endpoint_transport(endpoint_info):
    if not isinstance(endpoint_info, dict):
        return 'invalid'
    submission_method = _endpoint_text(endpoint_info, 'submission_method').lower()
    if submission_method == 'api':
        return 'api'
    if submission_method == 'winscp':
        return 'winscp'
    if _endpoint_text(endpoint_info, 'session_name') or _endpoint_text(endpoint_info, 'remote_directory_down'):
        return 'winscp'
    if _endpoint_text(endpoint_info, 'token_url') or _endpoint_text(endpoint_info, 'api_url'):
        return 'api'
    if (
            _endpoint_text(endpoint_info, 'host')
            or _endpoint_text(endpoint_info, 'remote_directory')
            or _endpoint_text(endpoint_info, 'remote_directory_up')):
        return 'upload_only'
    return 'manual'


def _make_endpoint_result(transport, status, reason, details=None):
    return {
        'transport': transport,
        'status': status,
        'reason': reason,
        'details': list(details or []),
    }


def _result_status(result):
    if not isinstance(result, dict):
        return ''
    return str(result.get('status') or '').strip()


def _result_reason(result):
    if not isinstance(result, dict):
        return 'unknown'
    value = str(result.get('reason') or '').strip()
    return value if value else 'unknown'


def _result_details(result):
    if not isinstance(result, dict):
        return []
    details = result.get('details')
    if not isinstance(details, list):
        return []
    out = []
    for item in details:
        if item is None:
            continue
        text = str(item).strip()
        if text:
            out.append(text)
    return out


def _result_detail_text(result):
    details = _result_details(result)
    if details:
        return '; '.join(details)
    return _result_reason(result)


def _probe_api_endpoint(endpoint_key, endpoint_info):
    missing_fields = _endpoint_missing_fields(
        endpoint_info,
        ['api_url', 'token_url', 'client_id', 'client_secret'],
    )
    if missing_fields:
        return _make_endpoint_result(
            'api',
            'error',
            'missing_api_config',
            ["Missing API configuration field(s): {}".format(', '.join(missing_fields))],
        )

    factory = get_api_client_factory()
    if factory is None:
        return _make_endpoint_result(
            'api',
            'error',
            'api_factory_unavailable',
            ['API client factory is not available.'],
        )

    try:
        client = factory.get_client()
    except Exception as exc:
        return _make_endpoint_result(
            'api',
            'error',
            'api_client_init_failed',
            ['Failed to initialize API client: {}'.format(exc)],
        )

    if client is None or not hasattr(client, 'get_access_token'):
        return _make_endpoint_result(
            'api',
            'error',
            'api_client_invalid',
            ['API client is missing get_access_token().'],
        )

    try:
        try:
            token = client.get_access_token(endpoint_key, quiet_mode=True)
        except TypeError:
            token = client.get_access_token(endpoint_key)
    except Exception as exc:
        return _make_endpoint_result(
            'api',
            'error',
            'token_probe_exception',
            ['API token probe raised {}: {}'.format(exc.__class__.__name__, exc)],
        )

    if token:
        return _make_endpoint_result(
            'api',
            'ok',
            'token_ok',
            ['Access token acquired successfully.'],
        )

    return _make_endpoint_result(
        'api',
        'error',
        'token_failed',
        ['Failed to obtain API access token.'],
    )


def _probe_winscp_download_endpoint(config, endpoint_info, local_storage_path):
    missing_fields = _endpoint_missing_fields(
        endpoint_info,
        ['session_name', 'remote_directory_down'],
    )
    if missing_fields:
        return _make_endpoint_result(
            'winscp',
            'error',
            'missing_winscp_config',
            ["Missing WinSCP configuration field(s): {}".format(', '.join(missing_fields))],
        )

    try:
        from MediLink_DataMgmt import get_winscp_path, probe_winscp_endpoint as _probe_winscp_endpoint
    except ImportError as exc:
        return _make_endpoint_result(
            'winscp',
            'error',
            'winscp_helpers_unavailable',
            ['WinSCP helper import failed: {}'.format(exc)],
        )

    try:
        winscp_path = get_winscp_path(config)
    except Exception as exc:
        return _make_endpoint_result(
            'winscp',
            'error',
            'winscp_path_error',
            ['Could not resolve WinSCP path: {}'.format(exc)],
        )

    if not winscp_path or not os.path.exists(winscp_path):
        return _make_endpoint_result(
            'winscp',
            'error',
            'winscp_missing',
            ['WinSCP not found at: {}'.format(winscp_path)],
        )

    probe = _probe_winscp_endpoint(endpoint_info, local_storage_path, config)
    details = []
    if probe.get('detail'):
        details.append(probe.get('detail'))
    if probe.get('log_path'):
        details.append('WinSCP probe log: {}'.format(probe.get('log_path')))
    if probe.get('ok'):
        return _make_endpoint_result('winscp', 'ok', 'winscp_probe_ok', details)
    return _make_endpoint_result('winscp', 'error', 'winscp_probe_failed', details)


def _probe_endpoint_connectivity(config, endpoint_key, endpoint_info, live_check=True, internet_ok=None, local_storage_path=None):
    transport = _infer_endpoint_transport(endpoint_info)
    if transport == 'invalid':
        return _make_endpoint_result('invalid', 'error', 'invalid_structure', ['Endpoint configuration is not a dictionary.'])
    if transport == 'manual':
        return _make_endpoint_result('manual', 'skipped', 'manual_endpoint', ['Manual/non-network endpoint; no connectivity probe needed.'])
    if transport == 'upload_only':
        return _make_endpoint_result('upload_only', 'skipped', 'no_remittance_download_transport', ['Upload-only or non-remittance endpoint; no download inbox configured.'])
    if internet_ok is False:
        return _make_endpoint_result(transport, 'offline', 'offline', ['Internet connectivity check failed before probing this endpoint.'])
    if transport == 'api':
        missing_fields = _endpoint_missing_fields(
            endpoint_info,
            ['api_url', 'token_url', 'client_id', 'client_secret'],
        )
        if missing_fields:
            return _make_endpoint_result(
                'api',
                'error',
                'missing_api_config',
                ["Missing API configuration field(s): {}".format(', '.join(missing_fields))],
            )
        if _is_test_mode(config) and live_check:
            return _make_endpoint_result('api', 'test_mode', 'test_mode', ['Test mode is enabled - API token probe skipped.'])
        if not live_check:
            return _make_endpoint_result('api', 'ready', 'api_ready', ['API transport detected; token probe not requested for this flow.'])
        return _probe_api_endpoint(endpoint_key, endpoint_info)
    if _is_test_mode(config) and live_check:
        return _make_endpoint_result('winscp', 'test_mode', 'test_mode', ['Test mode is enabled - WinSCP session probe skipped.'])
    if not live_check:
        return _make_endpoint_result('winscp', 'ready', 'winscp_ready', ['WinSCP transport detected; live probe not requested for this flow.'])
    return _probe_winscp_download_endpoint(config, endpoint_info, local_storage_path or '.')


def handle_files(local_storage_path, downloaded_files, endpoint_key=None, silent=False):
    """
    Moves downloaded files to the appropriate directory and translates them to CSV format.

    Args:
        local_storage_path: Base path for local storage
        downloaded_files: List of downloaded file names
        silent: If True, suppress console output (e.g. for boot-time scan)
    """
    log("Starting to handle downloaded files.")
    
    # Set the local response directory
    local_response_directory = os.path.join(local_storage_path, "responses")
    os.makedirs(local_response_directory, exist_ok=True)
    
    file_extensions = get_move_extensions() if get_move_extensions else [
        '.era', '.277', '.277ibr', '.277ebr', '.277dpr', '.999', '.dpt', '.ebt', '.ibt', '.txt'
    ]
    
    files_moved = []
    move_errors = []
    missing_source_files = []  # Collect missing file paths for consolidated logging

    for file in downloaded_files:
        lower = file.lower()
        if any(lower.endswith(ext) for ext in file_extensions):  # Case-insensitive match
            source_path = os.path.join(local_storage_path, file)
            destination_path = os.path.join(local_response_directory, os.path.basename(file))

            if not os.path.exists(source_path):
                move_errors.append((file, destination_path, FileNotFoundError("Source file not found")))
                try:
                    abs_source = os.path.abspath(source_path)
                    missing_source_files.append(abs_source)  # Collect instead of logging immediately
                    if os.path.isdir(local_storage_path):
                        try:
                            listing = os.listdir(local_storage_path)
                            sample = listing[:20] if len(listing) > 20 else listing
                            log("Directory contents (sample): {}".format(sample), level="DEBUG")
                        except Exception:
                            pass
                except Exception:
                    pass
                continue
            try:
                shutil.move(source_path, destination_path)
                log("Moved '{}' to '{}'".format(file, local_response_directory), level="DEBUG")
                files_moved.append(destination_path)
            except Exception as e:
                move_errors.append((file, destination_path, e))
                log("Error moving file '{}' to '{}': {} (source exists: {})".format(
                    file, destination_path, e, os.path.exists(source_path)), level="DEBUG")
        else:
            log("Skipping unsupported file '{}'.".format(file), level="DEBUG")

    # Log consolidated missing source files: WARNING with count, DEBUG with full list
    if missing_source_files:
        count = len(missing_source_files)
        paths_list = ", ".join(missing_source_files)
        log("Source files do not exist: {} total".format(count), level="WARNING")
        log("Source files do not exist ({} total): {}".format(count, paths_list), level="DEBUG")

    if move_errors:
        first_msg = str(move_errors[0][2])
        hint = ""
        if move_errors[0][2] and (isinstance(move_errors[0][2], FileNotFoundError) or "No such file" in first_msg or "not exist" in first_msg.lower()):
            hint = " One or more source files were missing (e.g. already moved or WinSCP path mismatch)."
        log(
            "Error moving {} file(s) to responses (e.g. {}).{} See DEBUG for per-file details.".format(
                len(move_errors), first_msg, hint
            ),
            level="ERROR",
        )

    if not files_moved:
        log("No files were moved. Ensure that files with supported extensions exist in the download directory.", level="WARNING")
    
    # Translate the files
    consolidated_records, translated_files = translate_files(
        files_moved,
        local_response_directory,
        local_storage_path,
        endpoint_key=endpoint_key,
        silent=silent
    )
    
    return consolidated_records, translated_files

def translate_files(files, output_directory, local_storage_path, endpoint_key=None, silent=False):
    """
    Translates given files into CSV format and returns the list of translated files and consolidated records.

    Args:
        files: List of file paths to translate
        output_directory: Directory for output files
        local_storage_path: Base path for JSONL persistence (file ledger, parsed records)
        endpoint_key: Name of the endpoint that provided these files (optional)
        silent: If True, suppress console summary (e.g. for boot-time scan)
    """
    log("Translating files: {}".format(files), level="DEBUG")

    if not files:
        log("No files provided for translation. Exiting translate_files.", level="WARNING")
        return [], []

    translated_files = []
    consolidated_records = []

    decode_exts = set(get_decode_extensions() if get_decode_extensions else [
        '.era', '.277', '.277ibr', '.277ebr', '.277dpr', '.999', '.ebt', '.ibt'
    ])
    file_counts = {ext: 0 for ext in sorted(decode_exts)}

    receipts_root = None
    lookups = {'by_submitted_claim_number': {}, 'by_claim_key': {}}
    try:
        cfg, _ = load_configuration()
        medi = extract_medilink_config(cfg)
        receipts_root = medi.get('local_claims_path')
    except Exception:
        receipts_root = None
    if build_crosswalk_lookups and receipts_root:
        try:
            lookups = build_crosswalk_lookups(receipts_root)
        except Exception:
            lookups = {'by_submitted_claim_number': {}, 'by_claim_key': {}}

    for file in files:
        ext = os.path.splitext(file)[1].lower()
        if ext in decode_exts:
            file_counts[ext] += 1

            src_path = os.path.join(output_directory, os.path.basename(file))
            if not os.path.exists(src_path):
                log("Skipping translation: file not found at expected path: {}".format(os.path.abspath(src_path)), level="WARNING")
                try:
                    if os.path.isdir(output_directory):
                        listing = os.listdir(output_directory)
                        sample = listing[:15] if len(listing) > 15 else listing
                        log("Output directory contents (sample): {}".format(sample), level="DEBUG")
                except Exception:
                    pass
                continue
            if not process_decoded_file:
                log("Skipping decode: MediLink_Decoder not available (process_decoded_file)", level="WARNING")
                continue
            try:
                records = process_decoded_file(src_path, output_directory, return_records=True)
                # Annotate records with source metadata for downstream persistence
                try:
                    mtime = os.path.getmtime(src_path)
                except Exception:
                    mtime = None
                for r in records:
                    try:
                        setattr(r, 'source_file', src_path)
                        setattr(r, 'source_mtime', mtime)
                    except Exception:
                        pass

                try:
                    storage_root = local_storage_path or output_directory
                    ledger_path = os.path.join(storage_root, 'remittance_file_ledger.jsonl')
                    parsed_path = os.path.join(storage_root, 'remittance_parsed.jsonl')
                    ext = os.path.splitext(file)[1].strip('.').upper()
                    file_type_label = determine_file_type(src_path) if determine_file_type else ext
                    if not file_type_label:
                        file_type_label = ext or 'UNKNOWN'

                    checksum = _compute_checksum(src_path)

                    if (
                        ingest_decoded_records_to_canonical
                        and build_source_meta
                        and write_jsonl
                        and storage_root
                    ):
                        try:
                            source_meta = build_source_meta(
                                source_file=os.path.basename(src_path),
                                source_type=file_type_label,
                                source_endpoint=endpoint_key or '',
                                source_timestamp=int(mtime) if isinstance(mtime, (int, float)) else None,
                                data_source='parsed_file',
                                source_checksum=checksum or '',
                            )
                            normalized_records, _ingest_stats = ingest_decoded_records_to_canonical(
                                records,
                                source_meta,
                                lookups,
                                log_fn=log,
                                log_basename=os.path.basename(src_path),
                            )
                            missing_claim_number_rows = 0
                            fallback_correlated_missing_claim_rows = 0
                            try:
                                for _nr in normalized_records:
                                    if not str(_nr.get('claim_number', '') or '').strip():
                                        missing_claim_number_rows += 1
                                        if str(_nr.get('match_status', '') or '').startswith('matched'):
                                            fallback_correlated_missing_claim_rows += 1
                            except Exception:
                                missing_claim_number_rows = 0
                                fallback_correlated_missing_claim_rows = 0
                            log(
                                (
                                    "[REMITTANCE_INGEST_FILE] endpoint={endpoint} file={filename} "
                                    "decoded_records={decoded_records} normalized_records={normalized_records} "
                                    "matched_rows={matched_rows} unmatched_rows={unmatched_rows} "
                                    "patient_names_backfilled={patient_names_backfilled} "
                                    "patient_names_still_blank={patient_names_still_blank} "
                                    "missing_claim_number_rows={missing_claim_number_rows} "
                                    "fallback_correlated_missing_claim_rows={fallback_correlated_missing_claim_rows}"
                                ).format(
                                    endpoint=endpoint_key or '',
                                    filename=os.path.basename(src_path),
                                    decoded_records=len(records),
                                    normalized_records=len(normalized_records),
                                    matched_rows=_ingest_stats.get('matched_rows', 0),
                                    unmatched_rows=_ingest_stats.get('unmatched_rows', 0),
                                    patient_names_backfilled=_ingest_stats.get('patientNamesBackfilled', 0),
                                    patient_names_still_blank=_ingest_stats.get('patientNamesStillBlank', 0),
                                    missing_claim_number_rows=missing_claim_number_rows,
                                    fallback_correlated_missing_claim_rows=fallback_correlated_missing_claim_rows,
                                ),
                                level="DEBUG",
                            )
                            if records and not normalized_records:
                                log(
                                    "[REMITTANCE_INGEST_FILE] decoded rows were produced but no normalized records were persisted for {}".format(
                                        os.path.basename(src_path)
                                    ),
                                    level="WARNING",
                                )
                        except Exception as ingest_exc:
                            log(
                                "Remittance ingest failed for {}: {}".format(
                                    os.path.basename(src_path), ingest_exc
                                ),
                                level="WARNING",
                            )
                            normalized_records = []
                        write_jsonl(normalized_records, parsed_path)
                        log(
                            "Appended {} normalized remittance records to {}".format(
                                len(normalized_records), parsed_path
                            ),
                            level="DEBUG",
                        )
                    else:
                        log("Skipping remittance JSONL persistence for {} (helpers missing)".format(os.path.basename(src_path)), level="DEBUG")

                    if write_jsonl:
                        ledger_entry = {
                            'filename': os.path.basename(src_path),
                            'path': src_path,
                            'endpoint': endpoint_key or '',
                            'file_type': file_type_label,
                            'mtime': int(mtime) if isinstance(mtime, (int, float)) else None,
                            'checksum': checksum,
                            'records_count': len(records)
                        }
                        write_jsonl([ledger_entry], ledger_path)
                        log("Appended entry to remittance ledger: {}".format(os.path.basename(src_path)), level="DEBUG")
                except Exception as e:
                    log("Failed to persist remittance JSONL data for {}: {}".format(os.path.basename(src_path), e), level="WARNING")
                consolidated_records.extend(records)
                csv_file_path = os.path.join(output_directory, os.path.basename(file) + '_decoded.csv')
                translated_files.append(csv_file_path)
                log("Translated file to CSV: {}".format(csv_file_path), level="DEBUG")
            except ValueError:
                log("Unsupported file type: {}".format(file), level="WARNING")
            except Exception as e:
                log("Error processing file {}: {}".format(file, e), level="ERROR")
        else:
            log("Skipping unselected file type for '{}'.".format(file), level="DEBUG")

    log("Detected and processed file counts by type:", level="DEBUG")
    for ext, count in file_counts.items():
        log("{}: {} files detected".format(ext, count), level="DEBUG")

    # Simple, elegant summary for console UI (skipped when silent, e.g. boot-time scan)
    if not silent:
        try:
            if consolidated_records:
                total = len(consolidated_records)
                num_rejected = 0
                num_accepted = 0
                for r in consolidated_records:
                    status = getattr(r, 'status', '') if hasattr(r, 'status') else r.get('Status', '')
                    if status:
                        if ('Reject' in status) or (':' in status and status.upper().startswith('R')):
                            num_rejected += 1
                        elif ('Accept' in status) or (':' in status and status.upper().startswith('A')):
                            num_accepted += 1
                print("\nAcknowledgements Summary:")
                print("  Total records: {}".format(total))
                print("  Accepted: {}".format(num_accepted))
                print("  Rejected: {}".format(num_rejected))
                print("")
        except Exception:
            pass

    return consolidated_records, translated_files

def prompt_csv_export(records, output_directory, silent=False):
    """
    Persists ack events and optionally prompts the user to export consolidated records to a CSV file.

    Args:
        records: List of consolidated records
        output_directory: Directory for output CSV (used when not silent)
        silent: If True, only persist ack events and log; no console prompt or CSV export (e.g. boot-time scan)
    """
    if records:
        # Persist lightweight ack events into receipts index (optional, best-effort)
        try:
            config, _ = load_configuration()
            medi = extract_medilink_config(config)
            receipts_root = medi.get('local_claims_path', None)
            if receipts_root and _ensure_submission_index and _append_ack_event:
                _ensure_submission_index(receipts_root)
                for rec in records:
                    try:
                        # rec may be UnifiedRecord; convert
                        if hasattr(rec, 'to_dict'):
                            d = rec.to_dict()
                        else:
                            d = rec
                        claim_no = d.get('Claim #', '')
                        status_text = d.get('Status', '')
                        # infer ack_type by presence of fields
                        ack_type = ''
                        if d.get('Paid', '') != '' or d.get('Allowed', '') != '':
                            ack_type = 'ERA'
                        elif status_text and ':' in status_text:
                            ack_type = '277'
                        else:
                            ack_type = 'EBT'  # default for text notifications
                        # Use file metadata when available
                        file_name = os.path.basename(getattr(rec, 'source_file', '')) if hasattr(rec, 'source_file') else 'responses'
                        ts = getattr(rec, 'source_mtime', None)
                        control_ids = {}
                        if claim_no:
                            _append_ack_event(
                                receipts_root,
                                '',  # claim_key unknown here
                                status_text,
                                ack_type,
                                file_name,
                                control_ids,
                                'download_ack',
                                int(ts) if isinstance(ts, (int, float)) else None
                            )
                    except Exception:
                        continue
        except Exception:
            pass

        if silent:
            log("Boot-time scan: {} records found (export skipped).".format(len(records)), level="INFO")
            return

        user_input = input("Do you want to export the consolidated records to a CSV file? (y/n): ")
        if user_input.lower() == 'y':
            output_file_path = os.path.join(output_directory, "Consolidated_Records.csv")
            if write_records_to_csv:
                write_records_to_csv(records, output_file_path)
                log("Consolidated CSV file created at: {}".format(output_file_path), level="INFO")
            else:
                log("CSV export unavailable: write_records_to_csv not loaded.", level="WARNING")
        else:
            log("CSV export skipped by user.", level="INFO")

def main(desired_endpoint=None):
    """
    Main function for running MediLink_Down as a standalone script.
    Simplified to handle only CLI operations and delegate the actual processing to the high-level function.
    """
    log("Running MediLink_Down.main with desired_endpoint={}".format(desired_endpoint))

    if not desired_endpoint:
        log("No specific endpoint provided. Aborting operation.", level="ERROR")
        return None, None

    try:
        config, _ = load_configuration()
        medi = extract_medilink_config(config)
        endpoint_config = medi.get('endpoints', {}).get(desired_endpoint)
        if not endpoint_config:
            log("Configuration for endpoint '{}' was not found.".format(desired_endpoint), level="ERROR")
            return None, None

        transport = _infer_endpoint_transport(endpoint_config)
        if transport != 'winscp':
            log(
                "Endpoint '{}' uses {} transport; standalone remittance download only supports WinSCP inbox endpoints.".format(
                    desired_endpoint, transport
                ),
                level="ERROR",
            )
            return None, None

        local_storage_path = medi.get('local_storage_path', '.')
        log("Local storage path set to {}".format(local_storage_path))

        try:
            internet_ok = check_internet_connection()
        except Exception:
            internet_ok = False
        if not internet_ok:
            log("Internet connectivity check failed before standalone remittance download.", level="ERROR")
            return None, None

        probe_result = _probe_endpoint_connectivity(
            config,
            desired_endpoint,
            endpoint_config,
            live_check=True,
            internet_ok=internet_ok,
            local_storage_path=local_storage_path,
        )
        if _result_status(probe_result) not in ('ok', 'test_mode'):
            detail = _result_detail_text(probe_result)
            log("Connectivity probe failed for endpoint '{}': {}".format(desired_endpoint, detail), level="ERROR")
            return None, None

        consolidated_records, translated_files, meta = process_endpoint(
            desired_endpoint,
            endpoint_config,
            config,
        )

        if meta.get('status') == 'processed':
            dict_consolidated_records = [record.to_dict() for record in consolidated_records]
            display_consolidated_records(dict_consolidated_records)
            prompt_csv_export(consolidated_records, local_storage_path)
            return consolidated_records, translated_files

        log(
            "No files or displayable records were produced for endpoint: {} ({})".format(
                desired_endpoint,
                meta.get('reason', 'unknown')
            ),
            level="WARNING",
        )
        return None, None

    except Exception as e:
        log("An error occurred in MediLink_Down.main: {}".format(e), level="ERROR")
        return None, None

def check_for_new_remittances(config=None, is_boot_scan=False, force_full_repair=False):
    """
    Check for new remittance files across all configured endpoints.

    WinSCP inbox endpoints are live-probed and processed in this flow.
    API endpoints are classified correctly and reported separately so they are
    not mislabeled as missing WinSCP download configuration.
    """
    log("Starting check_for_new_remittances function")
    if not is_boot_scan:
        if force_full_repair:
            print("\nChecking for new files across all endpoints (full sync includes repair)...")
        else:
            print("\nChecking for new files across all endpoints...")
    log("Checking for new files across all endpoints...")

    if config is None:
        config, _ = load_configuration()

    medi = extract_medilink_config(config)
    if not medi or 'endpoints' not in medi:
        log("Error: Config is missing necessary sections. Aborting...", level="ERROR")
        return False

    endpoints = medi.get('endpoints')
    if not isinstance(endpoints, dict):
        log("Error: 'endpoints' is not a dictionary. Aborting...", level="ERROR")
        return False

    local_storage_path = medi.get('local_storage_path', '.')
    log("Found {} configured endpoints: {}".format(len(endpoints), list(endpoints.keys())), level="INFO")
    for endpoint_key, endpoint_info in endpoints.items():
        log(
            "Endpoint '{}': transport={}, session_name={}, remote_directory_down={}, has_filemask={}".format(
                endpoint_key,
                _infer_endpoint_transport(endpoint_info),
                endpoint_info.get('session_name', 'NOT_SET') if isinstance(endpoint_info, dict) else 'NOT_SET',
                endpoint_info.get('remote_directory_down', 'NOT_SET') if isinstance(endpoint_info, dict) else 'NOT_SET',
                isinstance(endpoint_info, dict) and 'filemask' in endpoint_info,
            ),
            level="DEBUG",
        )

    all_consolidated_records = []
    all_translated_files = []
    endpoint_results = {}

    networked_endpoints = [
        endpoint_info for endpoint_info in endpoints.values()
        if _infer_endpoint_transport(endpoint_info) in ('winscp', 'api')
    ]
    internet_ok = True
    if networked_endpoints:
        try:
            internet_ok = check_internet_connection()
        except Exception as exc:
            internet_ok = False
            log("Remittance internet connectivity preflight raised {}: {}".format(exc.__class__.__name__, exc), level="WARNING")

        if internet_ok:
            log("Remittance internet connectivity preflight succeeded.", level="INFO")
        else:
            log(
                "Remittance internet connectivity preflight failed. Networked endpoints will be marked offline.",
                level="WARNING",
            )
            if not is_boot_scan:
                print("Internet connectivity check failed before remittance sync. Networked endpoints were not contacted.")

    for endpoint_key, endpoint_info in tqdm(endpoints.items(), desc="Processing endpoints", disable=is_boot_scan):
        log("=== Processing endpoint: {} ===".format(endpoint_key), level="INFO")

        if not endpoint_info or not isinstance(endpoint_info, dict):
            log("Error: Invalid endpoint structure for {}. Skipping...".format(endpoint_key), level="ERROR")
            endpoint_results[endpoint_key] = _make_endpoint_result('invalid', 'error', 'invalid_structure', ['Endpoint configuration is not a dictionary.'])
            continue

        transport = _infer_endpoint_transport(endpoint_info)
        endpoint_name = endpoint_info.get('name', endpoint_key)

        if transport == 'api':
            result = _probe_endpoint_connectivity(
                config,
                endpoint_key,
                endpoint_info,
                live_check=False,
                internet_ok=internet_ok,
                local_storage_path=local_storage_path,
            )
            if _result_status(result) == 'ready':
                result['status'] = 'validated'
                result['reason'] = 'api_transport_no_file_sync'
                result['details'] = _result_details(result) + [
                    'API endpoint is configured, but this remittance flow does not fetch files via API.'
                ]
                log(
                    "Endpoint '{}' uses API transport; remittance file download is not part of this WinSCP inbox flow.".format(
                        endpoint_key
                    ),
                    level="DEBUG",
                )
            elif _result_status(result) == 'offline':
                log("API endpoint '{}' not contacted because internet connectivity check failed.".format(endpoint_name), level="WARNING")
            else:
                log("API endpoint '{}' is not ready: {}".format(endpoint_name, _result_detail_text(result)), level="WARNING")
            endpoint_results[endpoint_key] = result
            continue

        if transport != 'winscp':
            result = _probe_endpoint_connectivity(
                config,
                endpoint_key,
                endpoint_info,
                live_check=False,
                internet_ok=internet_ok,
                local_storage_path=local_storage_path,
            )
            log(
                "Skipping endpoint '{}': {}".format(endpoint_name, result.get('reason', 'unknown')),
                level="INFO",
            )
            endpoint_results[endpoint_key] = result
            continue

        probe_result = _probe_endpoint_connectivity(
            config,
            endpoint_key,
            endpoint_info,
            live_check=True,
            internet_ok=internet_ok,
            local_storage_path=local_storage_path,
        )
        if _result_status(probe_result) not in ('ok', 'test_mode'):
            log(
                "Skipping endpoint '{}': {}".format(
                    endpoint_name,
                    _result_detail_text(probe_result)
                ),
                level="WARNING",
            )
            endpoint_results[endpoint_key] = probe_result
            continue

        remote_directory_down = _endpoint_text(endpoint_info, 'remote_directory_down')
        log(
            "Processing endpoint: {} with remote_directory_down: {}".format(
                endpoint_key,
                remote_directory_down
            ),
            level="INFO",
        )
        consolidated_records, translated_files, process_meta = process_endpoint(
            endpoint_key,
            endpoint_info,
            config,
            silent=is_boot_scan,
        )

        endpoint_results[endpoint_key] = {
            'transport': 'winscp',
            'status': process_meta.get('status', 'processed'),
            'reason': process_meta.get('reason', 'unknown'),
            'details': list(probe_result.get('details', [])),
            'records_found': len(consolidated_records) if consolidated_records else 0,
            'files_translated': len(translated_files) if translated_files else 0,
            'files_downloaded': process_meta.get('downloaded_files', 0),
        }

        if consolidated_records:
            all_consolidated_records.extend(consolidated_records)
            log("Added {} records from endpoint {}".format(len(consolidated_records), endpoint_key), level="INFO")
        if translated_files:
            all_translated_files.extend(translated_files)
            log("Added {} translated files from endpoint {}".format(len(translated_files), endpoint_key), level="INFO")

    log("=== Endpoint Processing Summary ===", level="INFO")
    for endpoint_key, result in endpoint_results.items():
        status = result.get('status')
        transport = result.get('transport', 'unknown')
        if status == 'processed':
            log(
                "Endpoint '{}': {} records found, {} files translated (transport={}, downloaded_files={})".format(
                    endpoint_key,
                    result.get('records_found', 0),
                    result.get('files_translated', 0),
                    transport,
                    result.get('files_downloaded', 0),
                ),
                level="INFO",
            )
        elif status == 'no_files':
            log(
                "Endpoint '{}': no new downloadable remittance files found (transport={})".format(
                    endpoint_key,
                    transport,
                ),
                level="INFO",
            )
        elif status == 'validated':
            log(
                "Endpoint '{}': validated (transport={}, reason={})".format(
                    endpoint_key,
                    transport,
                    result.get('reason', 'unknown'),
                ),
                level="INFO",
            )
        else:
            log(
                "Endpoint '{}': {} ({}, transport={})".format(
                    endpoint_key,
                    status,
                    result.get('reason', 'unknown'),
                    transport,
                ),
                level="WARNING" if status in ('error', 'offline') else "INFO",
            )

    repair_plan = _plan_embedded_remittance_repair(
        local_storage_path,
        endpoint_results,
        force_full_repair=force_full_repair,
    )
    _log_remittance_health_summary(repair_plan.get('summary'))
    if repair_plan.get('should_run'):
        _run_embedded_remittance_repair(
            config,
            repair_plan.get('reasons'),
            silent=is_boot_scan,
        )
    else:
        log("Embedded remittance repair not needed after this sync.", level="INFO")

    if all_consolidated_records:
        log("Total records found across all endpoints: {}".format(len(all_consolidated_records)), level="INFO")
        if is_boot_scan:
            prompt_csv_export(all_consolidated_records, medi.get('local_storage_path', '.'), silent=True)
        else:
            display_consolidated_records(all_consolidated_records)
            prompt_csv_export(all_consolidated_records, medi.get('local_storage_path', '.'))
        return True

    log("No records to display after processing all endpoints.", level="WARNING")
    winscp_count = 0
    api_count = 0
    validated_count = 0
    no_files_count = 0
    downloaded_no_records_count = 0
    skipped_count = 0
    offline_count = 0
    error_count = 0
    for result in endpoint_results.values():
        transport = str(result.get('transport') or '').strip()
        status = _result_status(result)
        if transport == 'winscp':
            winscp_count += 1
        elif transport == 'api':
            api_count += 1
        if status == 'validated':
            validated_count += 1
        elif status == 'no_files':
            no_files_count += 1
        elif status == 'downloaded_no_records':
            downloaded_no_records_count += 1
        elif status == 'skipped':
            skipped_count += 1
        elif status == 'offline':
            offline_count += 1
        elif status == 'error':
            error_count += 1
    log(
        (
            "Remittance no-records diagnostic: endpoints={}, internet={}, "
            "winscp={}, api={}, validated={}, no_files={}, downloaded_no_records={}, "
            "skipped={}, offline={}, errors={}"
        ).format(
            len(endpoints),
            'online' if internet_ok else 'offline',
            winscp_count,
            api_count,
            validated_count,
            no_files_count,
            downloaded_no_records_count,
            skipped_count,
            offline_count,
            error_count,
        ),
        level="INFO",
    )
    if endpoint_results:
        detail_parts = []
        for endpoint_key in sorted(endpoint_results):
            result = endpoint_results[endpoint_key]
            detail_parts.append(
                "{}={}({})".format(endpoint_key, _result_status(result), _result_reason(result))
            )
        log("Remittance no-records endpoint detail: " + "; ".join(detail_parts), level="INFO")
    return False

def process_endpoint(endpoint_key, endpoint_info, config, silent=False):
    """
    Helper function to process a single WinSCP-backed remittance endpoint.

    Returns:
        tuple: (consolidated_records, translated_files, meta)
    """
    meta = {
        'status': 'error',
        'reason': 'unknown',
        'downloaded_files': 0,
        'downloaded_names': [],
    }

    def _result(records, translated_files):
        return records, translated_files, meta

    try:
        medi = extract_medilink_config(config)
        local_storage_path = medi.get('local_storage_path', '.')
        log("[Process Endpoint] Local storage path set to {}".format(local_storage_path))

        try:
            from MediLink_DataMgmt import get_winscp_path
            winscp_path = get_winscp_path(config)
            if os.path.exists(winscp_path):
                log("[Process Endpoint] WinSCP found at: {}".format(winscp_path), level="INFO")
            else:
                meta['status'] = 'error'
                meta['reason'] = 'winscp_missing'
                log("[Process Endpoint] WinSCP not found at: {}".format(winscp_path), level="ERROR")
                return _result([], [])
        except Exception as e:
            meta['status'] = 'error'
            meta['reason'] = 'winscp_path_error'
            log("[Process Endpoint] Error checking WinSCP path: {}".format(e), level="ERROR")
            return _result([], [])

        log(
            "[Process Endpoint] Endpoint config - session_name: {}, remote_directory_down: {}, filemask: {}".format(
                endpoint_info.get('session_name', 'NOT_SET'),
                endpoint_info.get('remote_directory_down', 'NOT_SET'),
                endpoint_info.get('filemask', 'NOT_SET')
            ),
            level="DEBUG",
        )

        if config.get("MediLink_Config", {}).get("TestMode", False):
            log("[Process Endpoint] Test mode is enabled - simulating download", level="WARNING")

        if not operate_winscp:
            meta['status'] = 'error'
            meta['reason'] = 'operate_winscp_unavailable'
            log("[Process Endpoint] operate_winscp unavailable (MediLink_DataMgmt import failed)", level="ERROR")
            return _result([], [])

        downloaded_files = operate_winscp("download", None, endpoint_info, local_storage_path, config)
        meta['downloaded_files'] = len(downloaded_files) if downloaded_files else 0
        meta['downloaded_names'] = list(downloaded_files or [])

        if downloaded_files:
            log("[Process Endpoint] WinSCP downloaded {} file(s).".format(len(downloaded_files)), level="INFO")
            log("[Process Endpoint] WinSCP downloaded files: {}".format(downloaded_files), level="DEBUG")
            consolidated_records, translated_files = handle_files(
                local_storage_path,
                downloaded_files,
                endpoint_key=endpoint_key,
                silent=silent
            )
            log(
                "[Process Endpoint] File processing complete - {} records, {} translated files".format(
                    len(consolidated_records) if consolidated_records else 0,
                    len(translated_files) if translated_files else 0
                ),
                level="INFO",
            )
            if consolidated_records or translated_files:
                meta['status'] = 'processed'
                meta['reason'] = 'ok'
            else:
                meta['status'] = 'downloaded_no_records'
                meta['reason'] = 'no_supported_records_after_download'
            return _result(consolidated_records, translated_files)

        meta['status'] = 'no_files'
        meta['reason'] = 'no_files_downloaded'
        log("[Process Endpoint] No files were downloaded for endpoint: {}.".format(endpoint_key), level="WARNING")

        try:
            log_filename = "winscp_download.log"
            log_path = os.path.join(local_storage_path, log_filename)
            if os.path.exists(log_path):
                log("[Process Endpoint] WinSCP log exists at: {}".format(log_path), level="INFO")
                try:
                    if read_text_lines_with_fallback:
                        lines, encoding_used, used_fallback = read_text_lines_with_fallback(
                            log_path,
                            preferred_encodings=('utf-8-sig', 'cp1252')
                        )
                    else:
                        with open(log_path, 'r', encoding='utf-8-sig', errors='replace') as f:
                            lines = f.readlines()
                        encoding_used = 'utf-8-sig+replace'
                        used_fallback = True
                    if used_fallback:
                        log(
                            "[Process Endpoint] WinSCP log decoded using fallback mode: {}".format(
                                encoding_used
                            ),
                            level="DEBUG",
                        )
                    elif encoding_used != 'utf-8-sig':
                        log(
                            "[Process Endpoint] WinSCP log decoded using fallback encoding: {}".format(
                                encoding_used
                            ),
                            level="DEBUG",
                        )
                    if lines:
                        last_lines = lines[-5:]
                        log("[Process Endpoint] Last 5 lines of WinSCP log:", level="DEBUG")
                        for line in last_lines:
                            log("[Process Endpoint] Log: {}".format(line.strip()), level="DEBUG")
                except Exception as e:
                    log("[Process Endpoint] Error reading WinSCP log: {}".format(e), level="ERROR")
            else:
                log("[Process Endpoint] WinSCP log not found at: {}".format(log_path), level="WARNING")
        except Exception as e:
            log("[Process Endpoint] Error checking WinSCP log: {}".format(e), level="ERROR")

        return _result([], [])

    except Exception as e:
        meta['status'] = 'error'
        meta['reason'] = 'exception'
        log("Error processing endpoint {}: {}".format(endpoint_key, e), level="ERROR")
        import traceback
        log("Full traceback: {}".format(traceback.format_exc()), level="DEBUG")
        return _result([], [])

def test_endpoint_connectivity(config=None, endpoint_key=None):
    """
    Test connectivity to a specific endpoint or all endpoints.

    API endpoints perform a live token probe.
    WinSCP endpoints perform a live session/directory probe.
    Manual or upload-only endpoints are classified without a network probe.
    """
    if config is None:
        config, _ = load_configuration()

    medi = extract_medilink_config(config)
    if not medi:
        log("Error: Config is missing necessary sections.", level="ERROR")
        return {}

    endpoints = medi.get('endpoints')
    if not isinstance(endpoints, dict):
        log("Error: Config is missing necessary sections.", level="ERROR")
        return {}

    results = {}
    local_storage_path = medi.get('local_storage_path', '.')

    if endpoint_key:
        if endpoint_key in endpoints:
            test_endpoints = {endpoint_key: endpoints[endpoint_key]}
        else:
            log("Error: Endpoint '{}' not found in configuration.".format(endpoint_key), level="ERROR")
            return {}
    else:
        test_endpoints = endpoints

    networked_endpoints = [
        endpoint_info for endpoint_info in test_endpoints.values()
        if _infer_endpoint_transport(endpoint_info) in ('winscp', 'api')
    ]
    internet_ok = True
    if networked_endpoints:
        try:
            internet_ok = check_internet_connection()
        except Exception as exc:
            internet_ok = False
            log("Connectivity diagnostics internet preflight raised {}: {}".format(exc.__class__.__name__, exc), level="WARNING")

    log("Testing connectivity for {} endpoint(s)...".format(len(test_endpoints)), level="INFO")

    for ep_key, ep_info in test_endpoints.items():
        log("Testing endpoint: {}".format(ep_key), level="INFO")
        results[ep_key] = _probe_endpoint_connectivity(
            config,
            ep_key,
            ep_info,
            live_check=True,
            internet_ok=internet_ok,
            local_storage_path=local_storage_path,
        )

    return results

if __name__ == "__main__":
    import sys
    
    print("=" * 60)
    print("MediLink_Down Standalone Testing Tool")
    print("=" * 60)
    print()
    
    # Check if endpoint was provided as command line argument
    if len(sys.argv) > 1:
        desired_endpoint = sys.argv[1]
        print("Testing specific endpoint: {}".format(desired_endpoint))
        print()
        main(desired_endpoint)
    else:
        # No specific endpoint provided - run connectivity diagnostics
        print("No specific endpoint provided.")
        print("Running connectivity diagnostics for all endpoints...")
        print()
        
        try:
            config, _ = load_configuration()
            connectivity_results = test_endpoint_connectivity(config)
            
            if connectivity_results:
                print("Connectivity Test Results:")
                print("-" * 40)
                
                for endpoint, result in connectivity_results.items():
                    status = result["status"]
                    details = result["details"]
                    
                    if status in ("error", "offline"):
                        print("[ERROR] {}: {}".format(endpoint, status))
                    elif status == "test_mode":
                        print("[TEST] {}: {} (Test Mode)".format(endpoint, status))
                    elif status == "skipped":
                        print("[SKIP] {}: {}".format(endpoint, status))
                    else:
                        print("[OK] {}: {}".format(endpoint, status))
                    
                    for detail in details:
                        print("    - {}".format(detail))
                    print()
                
                # Show available endpoints for testing
                medi = extract_medilink_config(config)
                endpoints = medi.get('endpoints', {})
                if endpoints:
                    print("Available endpoints for testing:")
                    print("-" * 30)
                    for endpoint in endpoints.keys():
                        print("  - {}".format(endpoint))
                    print()
                    print("To test a specific endpoint, run:")
                    print("  python MediLink_Down.py <endpoint_name>")
            else:
                print("ERROR: No connectivity test results returned.")
                
        except Exception as e:
            print("ERROR: Failed to run diagnostics: {}".format(e))
            import traceback
            traceback.print_exc()

