import g4fscript.api

if __name__ == "__main__":
    g4fscript.api.run_api(debug=True)
