from __future__ import annotations

from typing import Any, Optional

from ..compat import fetch_json, is_browser_runtime
from ..errors import MissingAuthError, ResponseError, StreamNotSupportedError
from ..providers.base_provider import AsyncGeneratorProvider, ProviderModelMixin
from ..typing import AsyncResult, Messages


class BrowserFetch(AsyncGeneratorProvider, ProviderModelMixin):
    url = "https://api.openai.com/v1"
    label = "Browser Fetch"
    working = is_browser_runtime()
    active_by_default = False
    needs_auth = True
    supports_stream = False
    supports_message_history = True
    supports_system_message = True

    default_model = "gpt-4o-mini"
    models = [
        "gpt-4o-mini",
        "gpt-4o",
        "gpt-4.1-mini",
        "gpt-4.1",
        "o4-mini",
    ]

    @staticmethod
    def _chat_endpoint(base_url: str) -> str:
        base_url = (base_url or BrowserFetch.url).rstrip("/")
        if base_url.endswith("/chat/completions"):
            return base_url
        return f"{base_url}/chat/completions"

    @staticmethod
    def _extract_content(data: dict[str, Any]) -> str:
        if "error" in data:
            error = data["error"]
            if isinstance(error, dict) and "message" in error:
                raise ResponseError(error["message"])
            raise ResponseError(error)

        choices = data.get("choices") or []
        if not choices:
            raise ResponseError(f"Invalid chat completion response: {data}")

        message = choices[0].get("message") or {}
        content = message.get("content", "")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            return "".join(
                item.get("text", "")
                for item in content
                if isinstance(item, dict) and item.get("type", "text") == "text"
            )
        return str(content)

    @classmethod
    async def create_async_generator(
        cls,
        model: str,
        messages: Messages,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        headers: Optional[dict[str, str]] = None,
        stream: bool = False,
        allow_unauthenticated: bool = False,
        **kwargs,
    ) -> AsyncResult:
        if stream:
            raise StreamNotSupportedError(f"{cls.__name__} does not support streaming in PyScript yet")

        if not api_key and not allow_unauthenticated:
            raise MissingAuthError(
                "BrowserFetch requires an api_key. Pass allow_unauthenticated=True for local CORS-enabled endpoints."
            )

        request_headers = {
            **(headers or {}),
        }
        if api_key:
            request_headers.setdefault("authorization", f"Bearer {api_key}")

        model = cls.get_model(model)
        payload = {
            "model": model,
            "messages": messages,
            "stream": False,
        }
        for key in (
            "frequency_penalty",
            "max_tokens",
            "presence_penalty",
            "reasoning_effort",
            "response_format",
            "seed",
            "stop",
            "temperature",
            "tool_choice",
            "tools",
            "top_p",
        ):
            if key in kwargs and kwargs[key] is not None:
                payload[key] = kwargs[key]

        data = await fetch_json(
            cls._chat_endpoint(base_url or cls.url),
            method="POST",
            headers=request_headers,
            json_data=payload,
        )
        yield cls._extract_content(data)
