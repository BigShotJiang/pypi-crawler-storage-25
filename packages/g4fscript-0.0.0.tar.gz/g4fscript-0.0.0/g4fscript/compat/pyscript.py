from __future__ import annotations

import json
import platform
import sys
from dataclasses import dataclass
from typing import Any, Optional


class PyScriptRuntimeError(RuntimeError):
    """Raised when a PyScript-only feature is used outside a browser runtime."""


@dataclass
class BrowserFetchResponse:
    status: int
    ok: bool
    text: str
    status_text: str = ""

    def json(self) -> Any:
        return json.loads(self.text)


def is_pyodide() -> bool:
    return sys.platform == "emscripten" or platform.machine() in {"wasm32", "wasm64"}


def is_pyscript() -> bool:
    try:
        import pyscript  # noqa: F401
    except ImportError:
        return False
    return True


def is_browser_runtime() -> bool:
    if not is_pyodide():
        return False
    try:
        import js  # noqa: F401
    except ImportError:
        return False
    return True


def _prepare_body(json_data: Any = None, body: Any = None) -> Optional[str]:
    if body is not None:
        return body if isinstance(body, str) else json.dumps(body)
    if json_data is not None:
        return json.dumps(json_data)
    return None


def _prepare_headers(headers: Optional[dict[str, str]], json_data: Any = None) -> dict[str, str]:
    prepared = dict(headers or {})
    if json_data is not None:
        prepared.setdefault("content-type", "application/json")
    return prepared


async def _fetch_with_pyscript(url: str, **options) -> BrowserFetchResponse:
    from pyscript.fetch import fetch

    response = await fetch(url, **options)
    return BrowserFetchResponse(
        status=int(response.status),
        ok=bool(response.ok),
        text=await response.text(),
        status_text=str(getattr(response, "statusText", "")),
    )


async def _fetch_with_pyodide(url: str, **options) -> BrowserFetchResponse:
    from pyodide.http import pyfetch

    response = await pyfetch(url, **options)
    return BrowserFetchResponse(
        status=int(response.status),
        ok=bool(response.ok),
        text=await response.string(),
        status_text=str(getattr(response, "status_text", "")),
    )


async def fetch_text(
    url: str,
    *,
    method: str = "GET",
    headers: Optional[dict[str, str]] = None,
    json_data: Any = None,
    body: Any = None,
) -> BrowserFetchResponse:
    request_body = _prepare_body(json_data=json_data, body=body)
    options = {
        "method": method,
        "headers": _prepare_headers(headers, json_data),
    }
    if request_body is not None:
        options["body"] = request_body

    try:
        return await _fetch_with_pyscript(url, **options)
    except ImportError:
        pass

    try:
        return await _fetch_with_pyodide(url, **options)
    except ImportError as exc:
        raise PyScriptRuntimeError(
            "Browser fetch requires PyScript or Pyodide's pyodide.http module."
        ) from exc


async def fetch_json(
    url: str,
    *,
    method: str = "GET",
    headers: Optional[dict[str, str]] = None,
    json_data: Any = None,
    body: Any = None,
) -> Any:
    response = await fetch_text(
        url,
        method=method,
        headers=headers,
        json_data=json_data,
        body=body,
    )
    if not response.ok:
        raise PyScriptRuntimeError(
            f"Fetch failed with HTTP {response.status} {response.status_text}: {response.text}"
        )
    try:
        return response.json()
    except json.JSONDecodeError as exc:
        raise PyScriptRuntimeError("Fetch response did not contain valid JSON.") from exc
