from __future__ import annotations

from .pyscript import (
    BrowserFetchResponse,
    PyScriptRuntimeError,
    fetch_json,
    fetch_text,
    is_browser_runtime,
    is_pyodide,
    is_pyscript,
)

__all__ = [
    "BrowserFetchResponse",
    "PyScriptRuntimeError",
    "fetch_json",
    "fetch_text",
    "is_browser_runtime",
    "is_pyodide",
    "is_pyscript",
]
