"""Main entry point for the g4fscript MCP server

This module provides the main entry point for running the MCP server.
"""

from .server import main

if __name__ == "__main__":
    main()
