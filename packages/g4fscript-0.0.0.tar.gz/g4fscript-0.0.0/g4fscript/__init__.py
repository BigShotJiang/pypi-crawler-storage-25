from __future__ import annotations

import importlib
import logging
import os
from typing import TYPE_CHECKING, Any, Optional, Union

from . import debug, version

if TYPE_CHECKING:
    from .models import Model
    from .providers.types import ProviderType
    from .typing import AsyncResult, CreateResult, ImageType, Messages


logger = logging.getLogger("g4fscript")
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(logging.BASIC_FORMAT))
    logger.addHandler(handler)
logger.setLevel(logging.ERROR)


_LAZY_ATTRS = {
    "AsyncClient": (".client", "AsyncClient"),
    "AsyncResult": (".typing", "AsyncResult"),
    "Client": (".client", "Client"),
    "ClientFactory": (".client", "ClientFactory"),
    "CreateResult": (".typing", "CreateResult"),
    "ImageType": (".typing", "ImageType"),
    "Messages": (".typing", "Messages"),
    "Model": (".models", "Model"),
    "Provider": (".Provider", None),
    "ProviderType": (".providers.types", "ProviderType"),
    "async_concat_chunks": (".providers.helper", "async_concat_chunks"),
    "concat_chunks": (".providers.helper", "concat_chunks"),
    "create_custom_provider": (".client", "create_custom_provider"),
    "get_async_provider_method": (".providers.base_provider", "get_async_provider_method"),
    "get_cookies": (".cookies", "get_cookies"),
    "get_model_and_provider": (".client.service", "get_model_and_provider"),
    "get_provider_method": (".providers.base_provider", "get_provider_method"),
    "set_cookies": (".cookies", "set_cookies"),
    "to_sync_generator": (".providers.asyncio", "to_sync_generator"),
}


def __getattr__(name: str) -> Any:
    try:
        module_name, attr_name = _LAZY_ATTRS[name]
    except KeyError as exc:
        raise AttributeError(f"module 'g4fscript' has no attribute {name!r}") from exc

    module = importlib.import_module(module_name, __name__)
    value = module if attr_name is None else getattr(module, attr_name)
    globals()[name] = value
    return value


class ChatCompletion:
    @staticmethod
    def _prepare_request(
        model: Union["Model", str],
        messages: "Messages",
        provider: Union["ProviderType", str, None],
        stream: bool,
        image: "ImageType",
        image_name: Optional[str],
        ignore_working: bool,
        ignore_stream: bool,
        **kwargs,
    ):
        """Shared pre-processing for sync/async create methods."""
        from .client.service import get_model_and_provider

        if image is not None:
            kwargs["media"] = [(image, image_name)]
        elif "images" in kwargs:
            kwargs["media"] = kwargs.pop("images")

        model, provider = get_model_and_provider(
            model,
            provider,
            stream,
            ignore_working,
            ignore_stream,
            has_images="media" in kwargs,
        )

        if "proxy" not in kwargs:
            proxy = os.environ.get("G4F_PROXY")
            if proxy:
                kwargs["proxy"] = proxy
        if ignore_stream:
            kwargs["ignore_stream"] = True

        return model, provider, kwargs

    @staticmethod
    def create(
        model: Union["Model", str],
        messages: "Messages",
        provider: Union["ProviderType", str, None] = None,
        stream: bool = False,
        image: "ImageType" = None,
        image_name: Optional[str] = None,
        ignore_working: bool = False,
        ignore_stream: bool = False,
        **kwargs,
    ) -> Union["CreateResult", str]:
        from .providers.base_provider import get_provider_method
        from .providers.helper import concat_chunks

        model, provider, kwargs = ChatCompletion._prepare_request(
            model,
            messages,
            provider,
            stream,
            image,
            image_name,
            ignore_working,
            ignore_stream,
            **kwargs,
        )
        method = get_provider_method(provider)
        result = method(model, messages, stream=stream, **kwargs)
        return result if stream or ignore_stream else concat_chunks(result)

    @staticmethod
    def create_async(
        model: Union["Model", str],
        messages: "Messages",
        provider: Union["ProviderType", str, None] = None,
        stream: bool = False,
        image: "ImageType" = None,
        image_name: Optional[str] = None,
        ignore_working: bool = False,
        ignore_stream: bool = False,
        **kwargs,
    ) -> "AsyncResult":
        from .providers.base_provider import get_async_provider_method
        from .providers.helper import async_concat_chunks

        model, provider, kwargs = ChatCompletion._prepare_request(
            model,
            messages,
            provider,
            stream,
            image,
            image_name,
            ignore_working,
            ignore_stream,
            **kwargs,
        )
        method = get_async_provider_method(provider)
        result = method(model, messages, stream=stream, **kwargs)
        if not stream and not ignore_stream and hasattr(result, "__aiter__"):
            result = async_concat_chunks(result)
        return result


__all__ = [
    "AsyncClient",
    "AsyncResult",
    "ChatCompletion",
    "Client",
    "ClientFactory",
    "CreateResult",
    "ImageType",
    "Messages",
    "Model",
    "Provider",
    "ProviderType",
    "async_concat_chunks",
    "concat_chunks",
    "create_custom_provider",
    "debug",
    "get_async_provider_method",
    "get_cookies",
    "get_model_and_provider",
    "get_provider_method",
    "logger",
    "set_cookies",
    "to_sync_generator",
    "version",
]
