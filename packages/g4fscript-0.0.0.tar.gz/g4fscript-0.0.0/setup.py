import os

from setuptools import find_packages, setup

current_dir = os.path.abspath(os.path.dirname(__file__))

with open(os.path.join(current_dir, 'README.md'), "r", encoding="utf-8") as f:
    long_description = f.read()

long_description = long_description.replace("[!NOTE]", "")

INSTALL_REQUIRE = [
    "requests",
    "aiohttp",
    "brotli",
    "pycryptodome",
    "nest-asyncio2",
    "pyodide-http; sys_platform == 'emscripten'",
]

NOT_EMSCRIPTEN = "sys_platform != 'emscripten'"


def desktop_only(requirement: str) -> str:
    return f"{requirement}; {NOT_EMSCRIPTEN}"


EXTRA_REQUIRE = {
    'all': [
        desktop_only("curl_cffi>=0.6.2"),
        "certifi",
        desktop_only("browser_cookie3"), # get_cookies
        "ddgs",            # web_search
        "beautifulsoup4",  # web_search and bing.create_images
        "platformdirs",
        desktop_only("aiohttp_socks"),   # proxy
        "pillow",                  # image
        "cairosvg",                # svg image
        desktop_only("werkzeug"),
        desktop_only("flask[async]"),    # gui
        desktop_only("fastapi"),         # api
        desktop_only("uvicorn"),         # api
        desktop_only("zendriver"),
        desktop_only("python-multipart"),
        desktop_only("a2wsgi"),
        "setuptools",
        "markitdown[all]",
        "python-dotenv",
        "aiofile",
        desktop_only("cloudscraper"),
        desktop_only("wasmtime"),
        "numpy",
        "PyYAML",
    ],
    'slim': [
        desktop_only("curl_cffi>=0.6.2"),
        "certifi",
        desktop_only("browser_cookie3"),
        "ddgs",           # web_search
        "beautifulsoup4", # web_search and bing.create_images
        desktop_only("aiohttp_socks"),   # proxy
        "pillow",                  # image
        desktop_only("werkzeug"),
        desktop_only("flask[async]"),    # gui
        desktop_only("fastapi"),         # api
        desktop_only("uvicorn"),         # api
        desktop_only("zendriver"),
        desktop_only("python-multipart"),
        desktop_only("a2wsgi"),
        "pypdf2",
        "python-docx",
        "python-dotenv",
        "aiofile",
        desktop_only("cloudscraper"),
        "PyYAML",
    ],
    "pyscript": [
        "pyodide-http; sys_platform == 'emscripten'",
    ],
    "image": [
        "pillow",
        "cairosvg",
        "beautifulsoup4",
    ],
    "webview": [
        desktop_only("pywebview"),
        "platformdirs",
        desktop_only("plyer"),
        desktop_only("cryptography"),
    ],
    "api": [
        "loguru", "fastapi",
        "uvicorn",
        "python-multipart",
        "a2wsgi",
        "PyYAML"
    ],
    "gui": [
        "werkzeug", "flask[async]",
        "beautifulsoup4", "pillow",
    ],
    "search": [
        "beautifulsoup4",
        "pillow",
        "ddgs",
    ],
    "local": [
        desktop_only("gpt4all")
    ],
    "files": [
        "beautifulsoup4",
        "markitdown[all]",
    ]
}

DESCRIPTION = (
    'g4fscript: a PyScript-compatible fork of gpt4free'
)

# Setting up
setup(
    name='g4fscript',
    version=os.environ.get("G4FSCRIPT_VERSION", os.environ.get("G4F_VERSION", "0.0.0")),
    author='Tekky',
    author_email='<support@g4f.ai>',
    maintainer='NacreousDawn596',
    description=DESCRIPTION,
    long_description_content_type='text/markdown',
    long_description=long_description,
    packages=find_packages(),
    package_data={
        'g4fscript': []
    },
    include_package_data=True,
    install_requires=INSTALL_REQUIRE,
    extras_require=EXTRA_REQUIRE,
    entry_points={
        'console_scripts': [
            'g4fscript=g4fscript.cli:main',
            'g4fscript-mcp=g4fscript.mcp.server:main',
        ],
    },
    url='https://github.com/NacreousDawn596/g4fscript',
    project_urls={
        'Source Code': 'https://github.com/NacreousDawn596/g4fscript',
        'Bug Tracker': 'https://github.com/NacreousDawn596/g4fscript/issues',
        'Upstream': 'https://github.com/xtekky/gpt4free',
    },
    keywords=[
        "g4fscript",
        "gpt4free",
        "gpt4free.js",
        "g4f",
        "g4f.dev",
        "javascript",
        "npm",
        "browser",
        "gpt",
        "chatgpt",
        "deepseek",
        "openai",
        "ai",
        "client",
        "sdk",
        "free",
        "ai",
        "gpt-4",
        "gpt-4o",
        "chat",
        "api",
        "browser",
        "ai",
        "ai",
        "js",
        "client",
        "text",
        "generation",
        "image",
        "generation",
        "in-browser",
        "ai",
        "frontend",
        "ai",
        "openai",
        "alternative",
        "javascript",
        "ai",
        "library",
        "nodejs",
        "prompt",
        "engineering",
        "chatbot",
        "ai",
        "integration"
    ],
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Operating System :: Unix',
        'Operating System :: MacOS :: MacOS X',
        'Operating System :: Microsoft :: Windows',
    ],
)
