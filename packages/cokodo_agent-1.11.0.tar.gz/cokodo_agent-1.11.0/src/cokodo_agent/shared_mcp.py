"""Shared MCP runtime helpers and singleton-style launcher support.

This module introduces a machine-wide shared MCP daemon (HTTP transport) and a
lightweight stdio launcher that IDEs can spawn per session. The launcher keeps
the user-facing stdio workflow while routing requests through one shared daemon.
"""

from __future__ import annotations

import importlib.metadata as importlib_metadata
import json
import os
import re
import signal
import socket
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import shutil

import anyio
import mcp.types as types
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from mcp.server.fastmcp import FastMCP

from cokodo_agent.config import COKODO_HOME_DIR
from cokodo_agent.context import (
    build_context_content,
    get_context_files,
    list_project_files,
    update_status_section,
)
from cokodo_agent.mcp_server import (
    _NO_PROJECT_MSG,
    _auto_load_cross_project,
    _build_cross_project_hint,
    _build_local_linkage_hint,
    _register_global_tools,
)

SHARED_MCP_HOST = "127.0.0.1"
SHARED_MCP_PORT = 8765
SHARED_MCP_PATH = "/mcp"
SHARED_MCP_URL = f"http://{SHARED_MCP_HOST}:{SHARED_MCP_PORT}{SHARED_MCP_PATH}"


def _active_runtime_path() -> Path:
    return COKODO_HOME_DIR / "runtime" / "active-runtime.json"


def _versions_dir() -> Path:
    return COKODO_HOME_DIR / "versions"


def _shared_state_path() -> Path:
    return COKODO_HOME_DIR / "runtime" / "shared-mcp.json"


def _daemon_log_path() -> Path:
    return COKODO_HOME_DIR / "logs" / "shared-mcp.log"


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _normalize_version_key(version: str) -> str:
    normalized = re.sub(r"[^A-Za-z0-9._-]+", "-", (version or "").strip())
    return normalized or "unknown"


def _runtime_profile_path(version: str) -> Path:
    return _versions_dir() / _normalize_version_key(version) / "runtime.json"


def current_runtime_metadata() -> dict[str, Any]:
    package_root = Path(__file__).resolve().parent
    return {
        "version": _current_version(),
        "python_executable": sys.executable,
        "package_root": str(package_root),
        "module_path": str(Path(__file__).resolve()),
        "python_path_entries": [],
        "recorded_at": _now_iso(),
        "source": "current-runtime",
    }


def _current_version() -> str:
    from cokodo_agent.config import VERSION

    return VERSION


def read_active_runtime() -> dict[str, Any] | None:
    path = _active_runtime_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def write_active_runtime(data: dict[str, Any]) -> dict[str, Any]:
    path = _active_runtime_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized = dict(data)
    normalized["recorded_at"] = _now_iso()
    path.write_text(json.dumps(normalized, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return normalized


def pin_current_runtime() -> dict[str, Any]:
    return write_active_runtime(current_runtime_metadata())


def clear_active_runtime() -> bool:
    path = _active_runtime_path()
    if not path.exists():
        return False
    try:
        path.unlink()
    except OSError:
        return False
    return True


def get_effective_runtime() -> dict[str, Any]:
    return read_active_runtime() or current_runtime_metadata()


def read_registered_runtime(version: str) -> dict[str, Any] | None:
    path = _runtime_profile_path(version)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def register_runtime_profile(data: dict[str, Any], version: str | None = None) -> dict[str, Any]:
    target_version = _normalize_version_key(version or str(data.get("version") or _current_version()))
    path = _runtime_profile_path(target_version)
    path.parent.mkdir(parents=True, exist_ok=True)
    normalized = dict(data)
    normalized["version"] = target_version
    normalized["registered_at"] = _now_iso()
    normalized["profile_path"] = str(path)
    path.write_text(json.dumps(normalized, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return normalized


def register_current_runtime() -> dict[str, Any]:
    metadata = current_runtime_metadata()
    metadata["source"] = "registered-current-runtime"
    return register_runtime_profile(metadata)


def list_registered_runtimes() -> list[dict[str, Any]]:
    versions_dir = _versions_dir()
    if not versions_dir.exists():
        return []

    items: list[dict[str, Any]] = []
    for runtime_file in sorted(versions_dir.glob("*/runtime.json")):
        try:
            data = json.loads(runtime_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        data["profile_path"] = str(runtime_file)
        items.append(data)
    return items


def switch_active_runtime(version: str) -> dict[str, Any]:
    runtime = read_registered_runtime(version)
    if runtime is None:
        raise FileNotFoundError(f"Registered runtime '{version}' not found.")
    runtime = dict(runtime)
    runtime["source"] = f"registered:{runtime.get('version', version)}"
    return write_active_runtime(runtime)


def format_registered_runtimes() -> str:
    runtimes = list_registered_runtimes()
    active = read_active_runtime()
    active_version = active.get("version") if active else None
    if not runtimes:
        return "No registered runtimes under ~/.cokodo/versions."

    lines = ["# Registered runtimes", ""]
    for item in runtimes:
        marker = "*" if item.get("version") == active_version else "-"
        lines.append(
            f"{marker} {item.get('version', '(unknown)')} "
            f"python={item.get('python_executable', '(unknown)')}"
        )
        if item.get("source"):
            lines.append(f"  source: {item['source']}")
        if item.get("registered_at"):
            lines.append(f"  registered_at: {item['registered_at']}")
        if item.get("profile_path"):
            lines.append(f"  profile: {item['profile_path']}")
    return "\n".join(lines)


def get_runtime_status_payload() -> dict[str, Any]:
    """Return machine-readable shared runtime status for MCP clients."""
    daemon = get_shared_daemon_status()
    active_runtime = read_active_runtime()
    effective_runtime = get_effective_runtime()
    return {
        "daemon": daemon,
        "active_runtime": active_runtime,
        "effective_runtime": effective_runtime,
        "current_runtime_version": _current_version(),
        "registered_runtime_count": len(list_registered_runtimes()),
    }


def list_registered_runtimes_payload() -> dict[str, Any]:
    """Return machine-readable registered runtime profiles for MCP clients."""
    runtimes = list_registered_runtimes()
    active_runtime = read_active_runtime()
    active_version = active_runtime.get("version") if active_runtime else None
    return {
        "active_version": active_version,
        "items": runtimes,
        "count": len(runtimes),
    }


def _discover_runtime_from_site_packages(
    site_packages: Path,
    python_executable: str,
    source: str,
) -> dict[str, Any]:
    distributions = list(importlib_metadata.distributions(path=[str(site_packages)]))
    target_dist = None
    for distribution in distributions:
        name = (distribution.metadata.get("Name") or "").lower()
        if name == "cokodo-agent":
            target_dist = distribution
            break
    if target_dist is None:
        raise FileNotFoundError(f"No cokodo-agent distribution found under {site_packages}")

    package_root = site_packages / "cokodo_agent"
    module_path = package_root / "__init__.py"
    return {
        "version": target_dist.version,
        "python_executable": python_executable,
        "package_root": str(package_root),
        "module_path": str(module_path),
        "python_path_entries": [str(site_packages)],
        "source": source,
    }


def install_runtime_version(
    version: str,
    python_executable: str | None = None,
) -> dict[str, Any]:
    py = python_executable or sys.executable
    version_key = _normalize_version_key(version)
    runtime_dir = _versions_dir() / version_key
    site_packages = runtime_dir / "site-packages"
    if site_packages.exists():
        shutil.rmtree(site_packages)
    site_packages.mkdir(parents=True, exist_ok=True)

    cmd = [
        py,
        "-m",
        "pip",
        "install",
        "--upgrade",
        "--target",
        str(site_packages),
        f"cokodo-agent=={version}",
    ]
    subprocess.run(cmd, check=True)

    metadata = _discover_runtime_from_site_packages(
        site_packages,
        python_executable=py,
        source="pip-target-install",
    )
    return register_runtime_profile(metadata, version=metadata["version"])


def import_runtime_from_python(
    python_executable: str,
    version_alias: str | None = None,
) -> dict[str, Any]:
    probe = (
        "import json, pathlib, importlib.metadata as im, sys; "
        "import cokodo_agent; "
        "module_path = pathlib.Path(cokodo_agent.__file__).resolve(); "
        "print(json.dumps({"
        "'version': im.version('cokodo-agent'), "
        "'python_executable': sys.executable, "
        "'package_root': str(module_path.parent), "
        "'module_path': str(module_path), "
        "'python_path_entries': [], "
        "'source': 'external-python-import'"
        "}, ensure_ascii=False))"
    )
    out = subprocess.check_output(
        [python_executable, "-c", probe],
        stderr=subprocess.STDOUT,
        text=True,
    )
    metadata = json.loads(out)
    return register_runtime_profile(metadata, version=version_alias or metadata.get("version"))


def use_runtime_version(version: str) -> tuple[dict[str, Any], str]:
    runtime = switch_active_runtime(version)
    stop_result = stop_shared_daemon()
    if stop_result.startswith("Timed out"):
        raise RuntimeError(stop_result)
    ensure_shared_daemon()
    return runtime, stop_result


def read_shared_daemon_state() -> dict[str, Any] | None:
    path = _shared_state_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def write_shared_daemon_state() -> dict[str, Any]:
    runtime = get_effective_runtime()
    path = _shared_state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {
        "pid": os.getpid(),
        "host": SHARED_MCP_HOST,
        "port": SHARED_MCP_PORT,
        "url": SHARED_MCP_URL,
        "log_path": str(_daemon_log_path()),
        "version": runtime.get("version"),
        "python_executable": runtime.get("python_executable"),
        "package_root": runtime.get("package_root"),
        "module_path": runtime.get("module_path"),
        "active_runtime_path": str(_active_runtime_path()),
        "started_at": _now_iso(),
    }
    path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return state


def clear_shared_daemon_state() -> bool:
    path = _shared_state_path()
    if not path.exists():
        return False
    try:
        path.unlink()
    except OSError:
        return False
    return True


def get_shared_daemon_status() -> dict[str, Any]:
    state = read_shared_daemon_state()
    pid = state.get("pid") if state else None
    pid_running = bool(pid) and _pid_is_running(int(pid))
    port_open = _is_shared_daemon_running()
    status = "running" if port_open else "stopped"
    if state and not port_open:
        status = "stale"
    elif state and port_open and not pid_running:
        status = "orphaned"

    return {
        "status": status,
        "pid": pid,
        "pid_running": pid_running,
        "port_open": port_open,
        "state": state,
        "url": (state or {}).get("url", SHARED_MCP_URL),
        "log_path": (state or {}).get("log_path", str(_daemon_log_path())),
    }


def format_shared_daemon_status() -> str:
    info = get_shared_daemon_status()
    active_runtime = read_active_runtime()
    effective_runtime = get_effective_runtime()
    lines = [
        "# Shared MCP daemon",
        "",
        f"- status: {info['status']}",
        f"- url: {info['url']}",
        f"- pid: {info['pid'] if info['pid'] is not None else '(unknown)'}",
        f"- pid_running: {'yes' if info['pid_running'] else 'no'}",
        f"- port_open: {'yes' if info['port_open'] else 'no'}",
        f"- state_file: {_shared_state_path()}",
        f"- log_path: {info['log_path']}",
    ]
    state = info.get("state") or {}
    if state.get("version"):
        lines.append(f"- version: {state['version']}")
    if state.get("started_at"):
        lines.append(f"- started_at: {state['started_at']}")
    lines.extend(
        [
            "",
            "# Runtime selection",
            "",
            f"- current_runtime_version: {_current_version()}",
            f"- effective_runtime_version: {effective_runtime.get('version', '(unknown)')}",
            f"- effective_python: {effective_runtime.get('python_executable', '(unknown)')}",
            f"- active_runtime_file: {_active_runtime_path()}",
            f"- active_runtime_pinned: {'yes' if active_runtime else 'no'}",
        ]
    )
    if active_runtime:
        lines.append(f"- pinned_runtime_version: {active_runtime.get('version', '(unknown)')}")
    if info["status"] == "stale":
        lines.append("")
        lines.append("State file exists but daemon port is not reachable. Use `co shared stop` to clear stale state.")
    elif info["status"] == "orphaned":
        lines.append("")
        lines.append("Port is reachable but recorded PID is not running. Another process may own the port.")
    return "\n".join(lines)


def stop_shared_daemon(timeout_seconds: float = 5.0) -> str:
    info = get_shared_daemon_status()
    pid = info.get("pid")

    if not info["port_open"] and pid is None:
        clear_shared_daemon_state()
        return "Shared MCP daemon is not running."

    if pid is None:
        return (
            "Shared MCP daemon is reachable but no PID is recorded. "
            "Please stop the owning process manually, then clear the state."
        )

    if _pid_is_running(int(pid)):
        os.kill(int(pid), getattr(signal, "SIGTERM", 15))
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if not _pid_is_running(int(pid)) and not _is_shared_daemon_running():
            clear_shared_daemon_state()
            return f"Stopped shared MCP daemon (pid {pid})."
        time.sleep(0.2)

    if not _is_shared_daemon_running():
        clear_shared_daemon_state()
        return f"Daemon port closed after terminating pid {pid}."
    return f"Timed out stopping shared MCP daemon (pid {pid})."


def _is_shared_daemon_running(timeout: float = 0.25) -> bool:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((SHARED_MCP_HOST, SHARED_MCP_PORT))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def _spawn_shared_daemon() -> None:
    runtime = get_effective_runtime()
    python_executable = runtime.get("python_executable") or sys.executable
    python_path_entries = [
        str(entry)
        for entry in (runtime.get("python_path_entries") or [])
        if entry
    ]
    log_path = _daemon_log_path()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = log_path.open("a", encoding="utf-8")

    env = os.environ.copy()
    if python_path_entries:
        existing = env.get("PYTHONPATH", "")
        env["PYTHONPATH"] = os.pathsep.join(
            python_path_entries + ([existing] if existing else [])
        )

    kwargs: dict[str, Any] = {
        "stdin": subprocess.DEVNULL,
        "stdout": log_file,
        "stderr": subprocess.STDOUT,
        "cwd": str(Path.home()),
        "close_fds": True,
        "env": env,
    }
    if sys.platform == "win32":
        kwargs["creationflags"] = (
            getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            | getattr(subprocess, "DETACHED_PROCESS", 0)
            | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        )
    else:
        kwargs["start_new_session"] = True

    try:
        subprocess.Popen(
            [
                str(python_executable),
                "-m",
                "cokodo_agent.cli",
                "serve",
                "--shared-daemon",
            ],
            **kwargs,
        )
    finally:
        log_file.close()


def ensure_shared_daemon(timeout_seconds: float = 8.0) -> None:
    if _is_shared_daemon_running():
        return

    _spawn_shared_daemon()
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if _is_shared_daemon_running():
            return
        time.sleep(0.2)

    raise RuntimeError(
        f"Shared MCP daemon did not become ready at {SHARED_MCP_URL} within {timeout_seconds:.1f}s."
    )


async def _call_shared_tool_async(
    name: str,
    arguments: dict[str, Any] | None = None,
) -> str:
    await anyio.to_thread.run_sync(ensure_shared_daemon)
    async with streamablehttp_client(
        SHARED_MCP_URL,
        terminate_on_close=False,
    ) as (read_stream, write_stream, _get_session_id):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            result = await session.call_tool(name, arguments=arguments or {})
            return _call_tool_result_to_text(result)


def call_shared_tool(
    name: str,
    arguments: dict[str, Any] | None = None,
) -> str:
    ensure_shared_daemon()
    return anyio.run(_call_shared_tool_async, name, arguments)


async def _get_shared_prompt_async(
    name: str,
    arguments: dict[str, str] | None = None,
) -> str:
    await anyio.to_thread.run_sync(ensure_shared_daemon)
    async with streamablehttp_client(
        SHARED_MCP_URL,
        terminate_on_close=False,
    ) as (read_stream, write_stream, _get_session_id):
        async with ClientSession(read_stream, write_stream) as session:
            await session.initialize()
            result = await session.get_prompt(name, arguments=arguments or {})
            texts: list[str] = []
            for message in result.messages:
                content = message.content
                if isinstance(content, types.TextContent):
                    texts.append(content.text)
            return "\n\n".join(texts)


def get_shared_prompt(
    name: str,
    arguments: dict[str, str] | None = None,
) -> str:
    ensure_shared_daemon()
    return anyio.run(_get_shared_prompt_async, name, arguments)


def _call_tool_result_to_text(result: types.CallToolResult) -> str:
    if result.content:
        texts: list[str] = []
        for item in result.content:
            if isinstance(item, types.TextContent):
                texts.append(item.text)
        if texts:
            return "\n".join(texts)
    if result.structuredContent is not None:
        return json.dumps(result.structuredContent, ensure_ascii=False, indent=2)
    if result.isError:
        return "Shared MCP tool call failed."
    return ""


def _find_agent_dir(path: Path | None = None) -> Path | None:
    target = (path or Path.cwd()).resolve()
    if target.name == ".agent" and (target / "manifest.json").exists():
        return target

    current = target
    while True:
        candidate = current / ".agent"
        if candidate.is_dir() and (candidate / "manifest.json").exists():
            return candidate
        if current.parent == current:
            return None
        current = current.parent


def resolve_current_project_id(path: Path | None = None) -> str | None:
    agent_dir = _find_agent_dir(path)
    if agent_dir is None:
        return None
    from cokodo_agent.registry import register_project

    return register_project(agent_dir)


def _resolve_registered_project(
    project: str | None,
) -> tuple[Path | None, str, str | None]:
    if not project:
        return None, "", (
            "No project specified. Start via `co serve --shared-launcher` inside a project "
            "or pass the registered project name/ID explicitly."
        )

    from cokodo_agent.registry import get_project

    proj = get_project(project)
    if proj is None:
        return None, "", f"Project '{project}' not found in local registry."

    agent_dir = Path(proj["path"]) / ".agent"
    project_name = proj.get("name", agent_dir.parent.name)
    if not agent_dir.exists():
        return None, project_name, f"Project '{project_name}' has no .agent/ directory."
    return agent_dir, project_name, None


def _build_project_context(agent_dir: Path, stack: str | None = None, task: str | None = None) -> str:
    files = get_context_files(agent_dir, stack=stack, task=task)
    if not files:
        return "No files found in manifest.json loading_strategy."

    content_map = build_context_content(agent_dir, files)
    if not content_map:
        return "No context files could be read."

    parts: list[str] = []
    for rel_path, content in content_map.items():
        parts.append(f"# {rel_path}\n\n{content}")

    cross_parts: list[str] = []
    cross_stats: dict | None = None
    try:
        cross_parts, cross_stats = _auto_load_cross_project(agent_dir)
    except Exception:
        pass
    if cross_parts:
        parts.extend(cross_parts)

    parts.append(
        "---\n\n"
        "# Session Rules\n\n"
        "Follow these rules for this session:\n\n"
        "1. Update `status.md` at checkpoints — call `update_status` after completing tasks, "
        "before git commits, when switching tasks, or when blockers change.\n"
        "2. No external CDN links — all resources must be local to the project.\n"
        "3. UTF-8 encoding — always explicitly declare UTF-8 when reading/writing files.\n"
        "4. Forward slashes — use `/` as path separator in all commands.\n"
        "5. Test data isolation — automated tests must use `autotest_` prefix.\n"
        "6. Engine/Instance separation — never put project-specific info in `core/` files.\n"
    )

    cross_project_hint = _build_cross_project_hint(agent_dir, stats=cross_stats)
    if cross_project_hint:
        parts.append(cross_project_hint)

    local_linkage_hint = _build_local_linkage_hint(agent_dir)
    if local_linkage_hint:
        parts.append(local_linkage_hint)

    return "\n---\n\n".join(parts)


def _lint_agent_dir(agent_dir: Path) -> str:
    from collections import defaultdict

    from cokodo_agent.linter import ProtocolLinter

    linter = ProtocolLinter(agent_dir)
    all_results = linter.lint_all()

    by_rule: dict[str, list[Any]] = defaultdict(list)
    for result in all_results:
        by_rule[result.rule].append(result)

    lines: list[str] = []
    total_pass = 0
    total_fail = 0
    for rule_name, rule_results in sorted(by_rule.items()):
        passed = sum(1 for result in rule_results if result.passed)
        failed = len(rule_results) - passed
        total_pass += passed
        total_fail += failed
        status = "OK" if failed == 0 else "FAIL"
        lines.append(f"[{status}] {rule_name}: {passed}/{len(rule_results)} passed")
        if failed > 0:
            for result in rule_results:
                if not result.passed:
                    lines.append(f"  x {result.file or ''}: {result.message}")

    lines.append(f"\nTotal: {total_pass}/{total_pass + total_fail} passed")
    return "\n".join(lines)


def _list_files(agent_dir: Path) -> str:
    files = list_project_files(agent_dir)
    if not files:
        return "No files found in .agent/ directory."

    lines: list[str] = []
    current_layer = ""
    for file_info in sorted(files, key=lambda item: (item["layer"], item["path"])):
        if file_info["layer"] != current_layer:
            current_layer = file_info["layer"]
            lines.append(f"\n## {current_layer}")
        lines.append(f"- {file_info['path']}: {file_info['description']}")
    return "\n".join(lines)


def _list_sops(agent_dir: Path) -> str:
    sop_dir = agent_dir / "project" / "sop"
    if not sop_dir.exists():
        return "No SOP directory found at project/sop/. No SOPs have been defined yet."

    sop_files = sorted(sop_dir.glob("*.md"))
    if not sop_files:
        return "No SOP files found in project/sop/."

    lines = ["# Available SOPs\n"]
    lines.append("Use `get_sop(name)` to read a specific SOP.\n")
    for file_path in sop_files:
        trigger = ""
        try:
            for line in file_path.read_text(encoding="utf-8").splitlines():
                if "**Trigger**:" in line:
                    trigger = line.strip().lstrip(">").strip()
                    break
        except OSError:
            pass
        lines.append(f"- **{file_path.stem}** (`project/sop/{file_path.name}`)")
        if trigger:
            lines.append(f"  {trigger}")
    return "\n".join(lines)


def _get_sop(agent_dir: Path, name: str) -> str:
    sop_dir = agent_dir / "project" / "sop"
    if not sop_dir.exists():
        return "No SOP directory found at project/sop/."

    stem = name.removesuffix(".md")
    sop_path = sop_dir / f"{stem}.md"
    if not sop_path.exists():
        candidates = [file for file in sop_dir.glob("*.md") if stem.lower() in file.stem.lower()]
        if len(candidates) == 1:
            sop_path = candidates[0]
        elif len(candidates) > 1:
            names = ", ".join(file.stem for file in candidates)
            return f"Ambiguous SOP name '{name}'. Matches: {names}. Be more specific."
        else:
            available = ", ".join(file.stem for file in sorted(sop_dir.glob("*.md")))
            return f"SOP '{name}' not found. Available: {available}"

    try:
        return sop_path.read_text(encoding="utf-8")
    except OSError as exc:
        return f"Error reading SOP '{name}': {exc}"


def _list_relations(agent_dir: Path) -> str:
    from cokodo_agent.relations import (
        check_collaborations,
        check_references,
        load_collaborations,
        load_references,
    )

    project_root = agent_dir.parent
    refs = load_references(agent_dir)
    collabs = load_collaborations(agent_dir)

    if not refs and not collabs:
        return "No cross-project relationships declared in manifest.json."

    lines: list[str] = []

    if refs:
        statuses = check_references(agent_dir, project_root)
        status_map = {status.name: status for status in statuses}

        lines.append("# References\n")
        for ref in refs:
            status = status_map.get(ref.name)
            health = "OK" if (status and status.accessible) else "INACCESSIBLE"
            source_type = status.source_type if status else "unknown"
            lines.append(f"- **{ref.name}** ({source_type}, {health})")
            if ref.description:
                lines.append(f"  {ref.description}")
            lines.append(f"  source: {ref.source}")
            if ref.scope:
                lines.append(f"  scope: {', '.join(ref.scope)}")
            lines.append(f"  use_when: {ref.use_when}")
            lines.append("")

    if collabs:
        statuses = check_collaborations(agent_dir, project_root)
        status_map = {status.name: status for status in statuses}

        lines.append("# Collaborations\n")
        for collab in collabs:
            status = status_map.get(collab.name)
            if status and status.partner_accessible:
                health = "IN_SYNC" if status.shared_files_in_sync else "DRIFTED"
            elif status:
                health = "INACCESSIBLE"
            else:
                health = "UNKNOWN"
            lines.append(f"- **{collab.name}** (role: {collab.role}, {health})")
            if collab.description:
                lines.append(f"  {collab.description}")
            lines.append(f"  partner: {collab.partner}")
            if collab.shared_scope:
                lines.append(f"  shared_scope: {', '.join(collab.shared_scope)}")
            lines.append("")

    return "\n".join(lines)


def _get_related_context(agent_dir: Path, relation: str, file: str | None = None) -> str:
    from cokodo_agent.relations import (
        get_reference_by_name,
        resolve_reference_content,
    )

    project_root = agent_dir.parent
    ref = get_reference_by_name(agent_dir, relation)
    if ref is None:
        return f"Reference '{relation}' not found. Use list_relations to see available references."

    try:
        content_map = resolve_reference_content(ref, project_root, file=file)
    except FileNotFoundError as exc:
        return f"Error: {exc}"

    if not content_map:
        return f"No matching files found in reference '{relation}'."

    parts: list[str] = []
    for rel_path, content in content_map.items():
        parts.append(f"# [ref:{relation}] {rel_path}\n\n{content}")
    return "\n---\n\n".join(parts)


def _get_collaboration_context(agent_dir: Path, collaboration: str, file: str | None = None) -> str:
    from cokodo_agent.relations import (
        get_collaboration_by_name,
        resolve_collaboration_content,
    )

    project_root = agent_dir.parent
    collab = get_collaboration_by_name(agent_dir, collaboration)
    if collab is None:
        return (
            f"Collaboration '{collaboration}' not found. "
            "Use list_relations to see available collaborations."
        )

    try:
        content_map = resolve_collaboration_content(collab, project_root, file=file)
    except FileNotFoundError as exc:
        return f"Error: {exc}"

    if not content_map:
        return f"No matching files found in collaboration '{collaboration}'."

    parts: list[str] = []
    for rel_path, content in content_map.items():
        parts.append(f"# [collab:{collaboration}] {rel_path}\n\n{content}")
    return "\n---\n\n".join(parts)


def _get_collaboration_status(agent_dir: Path, collaboration: str | None = None) -> str:
    from cokodo_agent.relations import (
        check_collaborations,
        diff_collaboration,
        get_collaboration_by_name,
        load_collaborations,
    )

    project_root = agent_dir.parent

    if collaboration:
        collab = get_collaboration_by_name(agent_dir, collaboration)
        if collab is None:
            return f"Collaboration '{collaboration}' not found."
        collabs = [collab]
    else:
        collabs = load_collaborations(agent_dir)

    if not collabs:
        return "No collaborations declared."

    statuses = check_collaborations(agent_dir, project_root)
    status_map = {status.name: status for status in statuses}

    lines: list[str] = []
    for collab in collabs:
        status = status_map.get(collab.name)
        lines.append(f"## {collab.name} (role: {collab.role})")

        if not status or not status.partner_accessible:
            lines.append("  Status: INACCESSIBLE")
            if status and status.error:
                lines.append(f"  Error: {status.error}")
            lines.append("")
            continue

        if status.shared_files_in_sync:
            lines.append("  Status: IN_SYNC")
        else:
            lines.append("  Status: DRIFTED")
            try:
                diffs = diff_collaboration(collab, project_root, agent_dir)
                for file_path, file_status in diffs.items():
                    if file_status != "in_sync":
                        lines.append(f"  - {file_path}: {file_status}")
            except FileNotFoundError:
                pass
        lines.append("")

    return "\n".join(lines)


def _list_project_events(agent_dir: Path, project_name: str, status: str | None = None) -> str:
    from cokodo_agent.events import load_event_records

    events = load_event_records(agent_dir)
    if status:
        events = [event for event in events if event.status.lower() == status.lower()]
    if not events:
        return (
            f"No events declared in {project_name}."
            " Add rows to `project/events/events-index.md` to enable local linkage."
        )

    lines = [
        f"# project/events/ — {project_name}",
        f"Path: {agent_dir / 'project' / 'events'}",
        "",
    ]
    for event in events:
        target_text = ", ".join(event.targets) if event.targets else "(none)"
        lines.extend(
            [
                f"- **{event.event}** ({event.status})",
                f"  file: {event.file}",
                f"  kind: {event.kind or '(unspecified)'}",
                f"  targets: {target_text}",
                f"  updated: {event.updated or '(unspecified)'}",
                f"  summary: {event.summary or '(no summary)'}",
                "",
            ]
        )
    return "\n".join(lines).rstrip()


def _get_project_event(agent_dir: Path, project_name: str, event: str) -> str:
    from cokodo_agent.events import read_event_file

    result = read_event_file(agent_dir, event)
    if result is None:
        return (
            f"Event '{event}' not found in {project_name}. "
            "Use `list_project_events` to inspect available event names."
        )
    record, content = result
    return (
        f"# [event:{project_name}] {record.file}\n\n"
        f"Event: {record.event}\n"
        f"Kind: {record.kind or '(unspecified)'}\n"
        f"Status: {record.status}\n"
        f"Targets: {', '.join(record.targets) if record.targets else '(none)'}\n"
        f"Updated: {record.updated or '(unspecified)'}\n\n"
        f"{content}"
    )


def _get_related_events(agent_dir: Path) -> str:
    from cokodo_agent.events import collect_related_events

    related = collect_related_events(agent_dir)
    if not related:
        return (
            "No related local events detected. "
            "Declare refs/collaborations and register rows in `project/events/events-index.md` "
            "to enable Phase 1 local linkage."
        )

    lines = ["# Related local events", ""]
    for item in related:
        target_text = ", ".join(item.event.targets) if item.event.targets else "(none)"
        lines.extend(
            [
                f"## {item.source_project} via {item.via}:{item.relation_name}",
                f"- Event: **{item.event.event}**",
                f"- File: `{item.event.file}`",
                f"- Kind: {item.event.kind or '(unspecified)'}",
                f"- Status: {item.event.status}",
                f"- Targets: {target_text}",
                f"- Updated: {item.event.updated or '(unspecified)'}",
                f"- Summary: {item.event.summary or '(no summary)'}",
                "",
            ]
        )
    return "\n".join(lines).rstrip()


def _get_impacted_projects(agent_dir: Path, project_name: str, event: str) -> str:
    from cokodo_agent.events import get_event_by_name, resolve_impacted_projects

    record = get_event_by_name(agent_dir, event)
    if record is None:
        return (
            f"Event '{event}' not found in {project_name}. "
            "Use `list_project_events` to inspect available events."
        )

    impacted = resolve_impacted_projects(agent_dir, event)
    if not impacted:
        return (
            f"No impacted related projects resolved for '{record.event}'. "
            "Check the event `Targets` column and the project's declared refs/collaborations."
        )

    lines = [f"# Impacted projects — {record.event}", ""]
    for impacted_project, via, relation_name in impacted:
        lines.append(f"- **{impacted_project}** via {via}:{relation_name}")
    return "\n".join(lines)


def _get_local_linkage_status(agent_dir: Path) -> str:
    from cokodo_agent.events import collect_related_events
    from cokodo_agent.relations import (
        check_collaborations,
        check_references,
        load_collaborations,
        load_references,
    )

    project_root = agent_dir.parent
    refs = load_references(agent_dir)
    collabs = load_collaborations(agent_dir)
    ref_statuses = check_references(agent_dir, project_root) if refs else []
    collab_statuses = check_collaborations(agent_dir, project_root) if collabs else []
    related_events = collect_related_events(agent_dir)
    active_events = [
        event for event in related_events if event.event.status.lower() not in {"resolved", "superseded"}
    ]

    lines = [
        f"# Local linkage status — {agent_dir.parent.name}",
        "",
        f"- references: {len(refs)} declared, {sum(1 for status in ref_statuses if status.accessible)} accessible",
        f"- collaborations: {len(collabs)} declared, {sum(1 for status in collab_statuses if status.partner_accessible)} accessible",
        f"- related events: {len(related_events)} total, {len(active_events)} active",
        "",
    ]

    if collab_statuses:
        lines.append("## Collaborations")
        for status in collab_statuses:
            if status.partner_accessible:
                sync = "IN_SYNC" if status.shared_files_in_sync else "DRIFTED"
                lines.append(f"- {status.name} ({status.role}) -> {sync}")
            else:
                lines.append(f"- {status.name} ({status.role}) -> INACCESSIBLE")
        lines.append("")

    if active_events:
        lines.append("## Active related events")
        for item in active_events[:10]:
            lines.append(
                f"- {item.source_project}/{item.event.file} ({item.relation_name}, {item.event.status})"
            )
        if len(active_events) > 10:
            lines.append("- ...")
    elif not refs and not collabs:
        lines.append(
            "No refs/collaborations declared yet. Use `co ref add` / `co collab add` "
            "and maintain `project/events/events-index.md` to enable Phase 1 linkage."
        )
    return "\n".join(lines).rstrip()


def _fetch_remote_references(agent_dir: Path) -> str:
    from cokodo_agent.relations import load_references
    from cokodo_agent.remote import (
        fetch_remote_source,
        is_remote_source,
        parse_remote_source,
    )

    refs = load_references(agent_dir)
    remote_refs = [ref for ref in refs if is_remote_source(ref.source)]

    if not remote_refs:
        return "No remote references declared."

    lines: list[str] = []
    for ref in remote_refs:
        try:
            parsed = parse_remote_source(ref.source)
            fetch_remote_source(parsed, force=False)
            lines.append(f"[OK] {ref.name}: cached ({parsed.owner}/{parsed.repo})")
        except (ConnectionError, FileNotFoundError, ValueError) as exc:
            lines.append(f"[FAIL] {ref.name}: {exc}")

    return "\n".join(lines)


def _check_relation_health(agent_dir: Path) -> str:
    from cokodo_agent.relations import (
        check_collaborations,
        check_references,
        load_collaborations,
        load_references,
    )

    project_root = agent_dir.parent
    refs = load_references(agent_dir)
    collabs = load_collaborations(agent_dir)

    if not refs and not collabs:
        return "No relationships declared. Nothing to check."

    lines: list[str] = []
    ok_count = 0
    fail_count = 0

    if refs:
        lines.append("## References")
        statuses = check_references(agent_dir, project_root)
        for status in statuses:
            if status.accessible:
                lines.append(f"[OK]   {status.name} -> {status.source_type} ({status.resolved_path})")
                ok_count += 1
            else:
                lines.append(f"[FAIL] {status.name}: {status.error}")
                fail_count += 1
        lines.append("")

    if collabs:
        lines.append("## Collaborations")
        statuses = check_collaborations(agent_dir, project_root)
        for status in statuses:
            if status.partner_accessible:
                sync = "in_sync" if status.shared_files_in_sync else "drifted"
                lines.append(f"[OK]   {status.name} ({status.role}) -> {sync}")
                ok_count += 1
            else:
                lines.append(f"[FAIL] {status.name} ({status.role}): {status.error}")
                fail_count += 1
        lines.append("")

    lines.append(f"\n{ok_count}/{ok_count + fail_count} relationships healthy.")
    return "\n".join(lines)


def _run_session_gate(agent_dir: Path, online: bool = False, as_json: bool = False) -> str:
    from cokodo_agent.session_init import format_json, run_session_init

    result = run_session_init(agent_dir, offline=not online)
    if as_json:
        return format_json(result)
    return result["prompt"]


def _ack_project_refresh(agent_dir: Path) -> str:
    from cokodo_agent.pending_refresh import clear_pending_refresh

    if clear_pending_refresh(agent_dir):
        return "OK: cleared .cokodo_pending_refresh.json"
    return "No pending refresh marker was set."


def _build_session_init_prompt(
    agent_dir: Path,
    stack: str | None = None,
    task: str | None = None,
) -> str:
    from cokodo_agent.config import BUNDLED_PROTOCOL_VERSION, VERSION
    from cokodo_agent.session_init import run_session_init

    files = get_context_files(agent_dir, stack=stack, task=task)
    content_map = build_context_content(agent_dir, files)

    project_name = agent_dir.parent.name
    ctx_path = agent_dir / "project" / "context.md"
    if ctx_path.exists():
        for line in ctx_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("## Project Name"):
                continue
            if line.strip() and not line.startswith("#") and not line.startswith(">") and "{{" not in line:
                project_name = line.strip()
                break

    status_data = run_session_init(agent_dir)
    prompt_lines = [
        f"# Session Init — {project_name}",
        "",
        f"- cokodo-agent: {VERSION}",
        f"- bundled protocol: {BUNDLED_PROTOCOL_VERSION}",
        "",
        status_data["prompt"],
        "",
        "# Context",
    ]
    for rel_path, content in content_map.items():
        prompt_lines.extend(["", f"## {rel_path}", "", content])
    return "\n".join(prompt_lines)


def create_shared_server() -> FastMCP:
    """Create the machine-wide shared daemon server."""

    mcp = FastMCP(
        "cokodo-shared",
        instructions=(
            "This is the machine-wide shared Cokodo MCP daemon.\n\n"
            "Project-aware tools accept an optional `project` argument that can be a registered "
            "project name or ID. When a launcher proxies requests from a workspace, it fills that "
            "argument automatically so the IDE can keep using the classic tool names.\n\n"
            "Runtime management note:\n"
            "- Use `get_runtime_status` to inspect shared daemon health, active runtime pin, and "
            "effective Python/runtime details before giving upgrade or restart advice.\n"
            "- Use `list_registered_runtimes` to inspect the local version store under `~/.cokodo/versions`.\n"
            "- These MCP runtime-management tools are read-only. To mutate runtime state (install, import, "
            "switch, restart), tell the user to use CLI commands such as `co shared install-version`, "
            "`co shared import-runtime`, `co shared switch`, `co shared use-version`, or `co shared restart`."
        ),
        host=SHARED_MCP_HOST,
        port=SHARED_MCP_PORT,
        streamable_http_path=SHARED_MCP_PATH,
    )

    @mcp.tool()
    def get_project_context(
        project: str | None = None,
        stack: str | None = None,
        task: str | None = None,
    ) -> str:
        """Load .agent/ context files for a registered project.

        Concatenates the standard set of project context files (status, context,
        tech-stack, commands, known-issues, plus task-specific extras) selected by
        the manifest loading_strategy. Auto-includes cross-project refs and local
        linkage hints. Call this first in a session.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _build_project_context(agent_dir, stack=stack, task=task)

    @mcp.tool()
    def update_status(
        project: str,
        completed_tasks: list[str] | None = None,
        new_tasks: list[str] | None = None,
        blockers: list[str] | None = None,
        session_context: str | None = None,
    ) -> str:
        """Update project/status.md at a checkpoint for the given registered project.

        Marks tasks done, appends new pending tasks, replaces blockers, and
        rewrites the Session Context block. Call after completing tasks, before
        commits, on task switches, or when blockers change.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return update_status_section(
            agent_dir,
            completed_tasks=completed_tasks,
            new_tasks=new_tasks,
            blockers=blockers,
            session_context=session_context,
        )

    @mcp.tool()
    def lint_protocol(project: str) -> str:
        """Run the protocol compliance linter on the project's .agent/ tree.

        Returns a per-rule pass/fail summary so the agent can spot missing or
        malformed required files before continuing work.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _lint_agent_dir(agent_dir)

    @mcp.tool()
    def list_files(project: str) -> str:
        """List all .agent/ files for the project with their loading layer and description.

        Use to discover what project information is available and where each file lives.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _list_files(agent_dir)

    @mcp.tool()
    def list_sops(project: str) -> str:
        """List the project's Standard Operating Procedures (project/sop/*.md).

        Each SOP is a step-by-step guide for a recurring project task (release,
        debug, git workflow, etc.). Call before any task that may have a documented
        procedure.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _list_sops(agent_dir)

    @mcp.tool()
    def get_sop(project: str, name: str) -> str:
        """Read one named SOP file (project/sop/<name>.md) for the given project.

        Use list_sops first to discover available names.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_sop(agent_dir, name)

    @mcp.tool()
    def list_relations(project: str) -> str:
        """List declared cross-project references and collaborations for the project.

        Shows refs (read-only links to other projects' .agent/ context) and
        collaborations (bidirectional shared-file partnerships) plus health hints.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _list_relations(agent_dir)

    @mcp.tool()
    def get_related_context(
        project: str,
        relation: str,
        file: str | None = None,
    ) -> str:
        """Read context from a declared reference (another local or remote project).

        Returns either a default context bundle or a single relative file under
        the related project's .agent/ tree.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_related_context(agent_dir, relation, file=file)

    @mcp.tool()
    def get_collaboration_context(
        project: str,
        collaboration: str,
        file: str | None = None,
    ) -> str:
        """Read shared context from a declared collaboration partner project.

        Returns the canonical shared files (or a single requested one) and is
        always auto-loaded with drift detection.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_collaboration_context(agent_dir, collaboration, file=file)

    @mcp.tool()
    def get_collaboration_status(
        project: str,
        collaboration: str | None = None,
    ) -> str:
        """Report collaboration partner accessibility and shared-file sync status.

        If `collaboration` is omitted, reports on every declared collaboration.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_collaboration_status(agent_dir, collaboration=collaboration)

    @mcp.tool()
    def list_project_events(
        project: str,
        status: str | None = None,
    ) -> str:
        """List events declared in the project's project/events/events-index.md.

        Events are local-machine change notices that other same-machine projects
        may need to react to. Optionally filter by status (active, resolved, ...).
        """
        agent_dir, project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _list_project_events(agent_dir, project_name, status=status)

    @mcp.tool()
    def get_project_event(project: str, event: str) -> str:
        """Read a single event markdown file from a registered local project.

        Use list_project_events first to discover available event names.
        """
        agent_dir, project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_project_event(agent_dir, project_name, event)

    @mcp.tool()
    def get_related_events(project: str) -> str:
        """Collect events from related local projects that target this project.

        Useful for spotting upstream changes that demand follow-up work here.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_related_events(agent_dir)

    @mcp.tool()
    def get_impacted_projects(project: str, event: str) -> str:
        """Resolve which related local projects are targeted by a specific event.

        Returns each impacted project together with the relation (ref/collab)
        that links it back to the source project.
        """
        agent_dir, project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_impacted_projects(agent_dir, project_name, event)

    @mcp.tool()
    def get_local_linkage_status(project: str) -> str:
        """Summarize same-machine linkage state: refs, collaborations, active events.

        Use to quickly assess the health of all local cross-project hooks.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _get_local_linkage_status(agent_dir)

    @mcp.tool()
    def fetch_remote_references(project: str) -> str:
        """Fetch or refresh all remote (git:...) references declared by the project.

        Caches remote repo content so get_related_context can serve it; skips
        cached refs that are still fresh.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _fetch_remote_references(agent_dir)

    @mcp.tool()
    def check_relation_health(project: str) -> str:
        """Verify that every declared reference and collaboration is reachable.

        Returns OK/FAIL per relationship plus a healthy/total tally for diagnosing
        broken cross-project links.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _check_relation_health(agent_dir)

    @mcp.tool()
    def session_gate(
        project: str,
        online: bool = False,
        as_json: bool = False,
    ) -> str:
        """Session gate: package update + protocol drift; call FIRST before get_project_context.

        Runs the same checks as `co session-init` and returns an instruction
        block (markdown by default, JSON if as_json=True). Set online=True to
        diff against the network release instead of the bundled snapshot.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _run_session_gate(agent_dir, online=online, as_json=as_json)

    @mcp.tool()
    def ack_project_refresh(project: str) -> str:
        """Clear the pending project-refresh marker after refreshing project/ content.

        Call once you have updated status.md Quick Reference and any scaffolded
        project files so the next session_gate stops repeating the same prompt.
        """
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _ack_project_refresh(agent_dir)

    @mcp.tool()
    def get_runtime_status() -> str:
        """Return JSON describing the shared MCP daemon runtime health.

        Includes daemon status, active runtime pin, and effective Python/runtime
        details. Read-only; use `co shared ...` CLI commands to mutate.
        """
        return json.dumps(get_runtime_status_payload(), ensure_ascii=False, indent=2)

    @mcp.tool()
    def list_registered_runtimes() -> str:
        """Return JSON listing runtimes installed in the local version store (~/.cokodo/versions).

        Read-only; use `co shared install-version` / `import-runtime` / `switch`
        to change what is registered.
        """
        return json.dumps(list_registered_runtimes_payload(), ensure_ascii=False, indent=2)

    _register_global_tools(mcp)

    @mcp.prompt()
    def session_init(
        project: str,
        stack: str | None = None,
        task: str | None = None,
    ) -> str:
        agent_dir, _project_name, error = _resolve_registered_project(project)
        if agent_dir is None:
            return error or _NO_PROJECT_MSG
        return _build_session_init_prompt(agent_dir, stack=stack, task=task)

    return mcp


def _proxy_project_arg(current_project_id: str | None, project: str | None = None) -> str | None:
    return project or current_project_id


def create_shared_launcher_server(path: Path | None = None) -> FastMCP:
    """Create a stdio MCP launcher that proxies calls into the shared daemon."""

    current_project_id = resolve_current_project_id(path)

    mcp = FastMCP(
        "cokodo-launcher",
        instructions=(
            "This launcher proxies MCP requests to the machine-wide shared Cokodo daemon. "
            "When started inside a project, current-project tools are automatically scoped "
            "to that project's registered ID.\n\n"
            "Runtime management note:\n"
            "- Prefer calling `get_runtime_status` and `list_registered_runtimes` when you need to "
            "understand shared runtime health or version-store contents.\n"
            "- These MCP runtime-management tools are read-only. For changes, direct the user to "
            "`co shared ...` CLI commands."
        ),
    )

    @mcp.tool()
    async def get_project_context(
        stack: str | None = None,
        task: str | None = None,
    ) -> str:
        """Load .agent/ context files for the current workspace project.

        Concatenates the standard set of project context files (status, context,
        tech-stack, commands, known-issues, plus task-specific extras) from this
        workspace's registered project. Auto-includes cross-project refs and local
        linkage hints. Call this first in a session.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "get_project_context",
            {"project": project, "stack": stack, "task": task},
        )

    @mcp.tool()
    async def update_status(
        completed_tasks: list[str] | None = None,
        new_tasks: list[str] | None = None,
        blockers: list[str] | None = None,
        session_context: str | None = None,
    ) -> str:
        """Update project/status.md at a checkpoint for the current workspace project.

        Marks tasks done, appends new pending tasks, replaces blockers, and
        rewrites the Session Context block. Call after completing tasks, before
        commits, on task switches, or when blockers change.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "update_status",
            {
                "project": project,
                "completed_tasks": completed_tasks,
                "new_tasks": new_tasks,
                "blockers": blockers,
                "session_context": session_context,
            },
        )

    @mcp.tool()
    async def lint_protocol() -> str:
        """Run the protocol compliance linter on the current project's .agent/ tree.

        Returns a per-rule pass/fail summary so the agent can spot missing or
        malformed required files before continuing work.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("lint_protocol", {"project": project})

    @mcp.tool()
    async def list_files() -> str:
        """List all .agent/ files for the current project with loading layer and description.

        Use to discover what project information is available and where each file lives.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("list_files", {"project": project})

    @mcp.tool()
    async def list_sops() -> str:
        """List the current project's Standard Operating Procedures (project/sop/*.md).

        Each SOP is a step-by-step guide for a recurring project task (release,
        debug, git workflow, etc.). Call before any task that may have a documented
        procedure.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("list_sops", {"project": project})

    @mcp.tool()
    async def get_sop(name: str) -> str:
        """Read one named SOP file (project/sop/<name>.md) for the current project.

        Use list_sops first to discover available names.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("get_sop", {"project": project, "name": name})

    @mcp.tool()
    async def list_relations() -> str:
        """List declared cross-project references and collaborations for the current project.

        Shows refs (read-only links to other projects' .agent/ context) and
        collaborations (bidirectional shared-file partnerships) plus health hints.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("list_relations", {"project": project})

    @mcp.tool()
    async def get_related_context(
        relation: str,
        file: str | None = None,
    ) -> str:
        """Read context from a declared reference (another local or remote project).

        Returns either a default context bundle or a single relative file under
        the related project's .agent/ tree.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "get_related_context",
            {"project": project, "relation": relation, "file": file},
        )

    @mcp.tool()
    async def get_collaboration_context(
        collaboration: str,
        file: str | None = None,
    ) -> str:
        """Read shared context from a declared collaboration partner project.

        Returns the canonical shared files (or a single requested one) and is
        always auto-loaded with drift detection.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "get_collaboration_context",
            {"project": project, "collaboration": collaboration, "file": file},
        )

    @mcp.tool()
    async def get_collaboration_status(
        collaboration: str | None = None,
    ) -> str:
        """Report collaboration partner accessibility and shared-file sync status.

        If `collaboration` is omitted, reports on every declared collaboration.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "get_collaboration_status",
            {"project": project, "collaboration": collaboration},
        )

    @mcp.tool()
    async def list_project_events(
        project: str | None = None,
        status: str | None = None,
    ) -> str:
        """List events declared in project/events/events-index.md.

        Defaults to the current workspace project; pass `project` to query another
        registered project. Optionally filter by status (active, resolved, ...).
        """
        effective_project = _proxy_project_arg(current_project_id, project)
        if effective_project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "list_project_events",
            {"project": effective_project, "status": status},
        )

    @mcp.tool()
    async def get_project_event(
        event: str,
        project: str | None = None,
    ) -> str:
        """Read a single event markdown file from the current or a named local project.

        Use list_project_events first to discover available event names.
        """
        effective_project = _proxy_project_arg(current_project_id, project)
        if effective_project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "get_project_event",
            {"project": effective_project, "event": event},
        )

    @mcp.tool()
    async def get_related_events() -> str:
        """Collect events from related local projects that target the current project.

        Useful for spotting upstream changes that demand follow-up work here.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("get_related_events", {"project": project})

    @mcp.tool()
    async def get_impacted_projects(
        event: str,
        project: str | None = None,
    ) -> str:
        """Resolve which related local projects are targeted by a specific event.

        Returns each impacted project together with the relation (ref/collab)
        that links it back to the source project. Defaults to the current project.
        """
        effective_project = _proxy_project_arg(current_project_id, project)
        if effective_project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "get_impacted_projects",
            {"project": effective_project, "event": event},
        )

    @mcp.tool()
    async def get_local_linkage_status() -> str:
        """Summarize same-machine linkage state: refs, collaborations, active events.

        Use to quickly assess the health of all local cross-project hooks.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("get_local_linkage_status", {"project": project})

    @mcp.tool()
    async def fetch_remote_references() -> str:
        """Fetch or refresh all remote (git:...) references declared by the current project.

        Caches remote repo content so get_related_context can serve it; skips
        cached refs that are still fresh.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("fetch_remote_references", {"project": project})

    @mcp.tool()
    async def check_relation_health() -> str:
        """Verify that every declared reference and collaboration is reachable.

        Returns OK/FAIL per relationship plus a healthy/total tally for diagnosing
        broken cross-project links.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("check_relation_health", {"project": project})

    @mcp.tool()
    async def session_gate(
        online: bool = False,
        as_json: bool = False,
    ) -> str:
        """Session gate: package update + protocol drift; call FIRST before get_project_context.

        Runs the same checks as `co session-init` and returns an instruction
        block (markdown by default, JSON if as_json=True). Set online=True to
        diff against the network release instead of the bundled snapshot.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async(
            "session_gate",
            {"project": project, "online": online, "as_json": as_json},
        )

    @mcp.tool()
    async def ack_project_refresh() -> str:
        """Clear the pending project-refresh marker after refreshing project/ content.

        Call once you have updated status.md Quick Reference and any scaffolded
        project files so the next session_gate stops repeating the same prompt.
        """
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        return await _call_shared_tool_async("ack_project_refresh", {"project": project})

    @mcp.tool()
    async def get_runtime_status() -> str:
        """Return JSON describing the shared MCP daemon runtime health.

        Includes daemon status, active runtime pin, and effective Python/runtime
        details. Read-only; use `co shared ...` CLI commands to mutate.
        """
        return await _call_shared_tool_async("get_runtime_status")

    @mcp.tool()
    async def list_registered_runtimes() -> str:
        """Return JSON listing runtimes installed in the local version store (~/.cokodo/versions).

        Read-only; use `co shared install-version` / `import-runtime` / `switch`
        to change what is registered.
        """
        return await _call_shared_tool_async("list_registered_runtimes")

    @mcp.tool()
    async def list_global_projects(include_invalid: bool = False) -> str:
        """List all cokodo projects registered on this machine.

        Projects are registered automatically each time any `co` command runs in
        a directory that has a .agent/ tree. Set include_invalid=True to also
        show entries whose paths no longer exist.
        """
        return await _call_shared_tool_async("list_global_projects", {"include_invalid": include_invalid})

    @mcp.tool()
    async def get_global_project_context(
        project: str,
        stack: str | None = None,
        task: str | None = None,
    ) -> str:
        """Load .agent/ context for any registered project by name or ID.

        Use list_global_projects to discover available names/IDs. Same content
        shape as get_project_context, but for a project other than the current
        workspace.
        """
        return await _call_shared_tool_async(
            "get_global_project_context",
            {"project": project, "stack": stack, "task": task},
        )

    @mcp.tool()
    async def get_global_project_status(project: str) -> str:
        """Read project/status.md for any registered project (live, not cached).

        Accepts project name or ID (4+ char prefix).
        """
        return await _call_shared_tool_async("get_global_project_status", {"project": project})

    @mcp.tool()
    async def global_search(
        query: str,
        limit: int = 20,
    ) -> str:
        """Search across all registered projects for a keyword (case-insensitive).

        Searches project names, status summaries, and key file paths. Returns up
        to `limit` matches with brief context.
        """
        return await _call_shared_tool_async("global_search", {"query": query, "limit": limit})

    @mcp.tool()
    async def list_templates(group: str = "all") -> str:
        """List bundled protocol templates exposed by the daemon.

        Optionally filter by group (e.g. 'templates', 'ci'). Use to discover
        scaffold templates before calling get_template.
        """
        return await _call_shared_tool_async("list_templates", {"group": group})

    @mcp.tool()
    async def get_template(path: str) -> str:
        """Read a single bundled template file by its relative path.

        Use list_templates first to discover valid paths.
        """
        return await _call_shared_tool_async("get_template", {"path": path})

    @mcp.tool()
    async def get_active_changes(project: str) -> str:
        """List active SDD change units for a registered project.

        Reflects project/changes/.active and the changes/<name>/ directories.
        """
        return await _call_shared_tool_async("get_active_changes", {"project": project})

    @mcp.tool()
    async def get_change(
        project: str,
        name: str,
    ) -> str:
        """Read a specific SDD change unit (project/changes/<name>/) by name.

        Use get_active_changes to discover available change names.
        """
        return await _call_shared_tool_async("get_change", {"project": project, "name": name})

    @mcp.tool()
    async def get_specs(project: str, path: str | None = None) -> str:
        """Read living specs from project/specs/ for a registered project.

        Without `path`, returns the specs index summary. With `path`, returns the
        contents of that single spec file relative to project/specs/.
        """
        return await _call_shared_tool_async("get_specs", {"project": project, "path": path})

    @mcp.prompt()
    async def session_init(
        stack: str | None = None,
        task: str | None = None,
    ) -> str:
        project = _proxy_project_arg(current_project_id)
        if project is None:
            return _NO_PROJECT_MSG
        args: dict[str, str] = {"project": project}
        if stack is not None:
            args["stack"] = stack
        if task is not None:
            args["task"] = task
        return await _get_shared_prompt_async("session_init", args)

    return mcp
