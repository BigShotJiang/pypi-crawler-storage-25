"""Cokodo Agent - AI collaboration protocol generator."""

from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("cokodo-agent")
except Exception:
    __version__ = "1.11.0"
