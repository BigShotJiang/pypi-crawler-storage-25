"""Protocol compliance linter — version label from config (see PROTOCOL_RULES_VERSION_LINE)."""

import hashlib
import json
import re
import tomllib
from pathlib import Path
from typing import Any, NamedTuple


class LintResult(NamedTuple):
    """Check result."""

    rule: str
    passed: bool
    message: str
    file: str | None = None
    line: int | None = None


class ProtocolLinter:
    """Protocol linter based on agent-protocol-rules.md."""

    VERSION_STATE_VALID_STATUSES = {
        "planning",
        "developing",
        "frozen",
        "released",
        "hotfix",
        "stable",
        "deprecated",
    }

    # Locked directories (🔒) - read-only
    LOCKED_DIRS = [
        "core",
        "adapters",
        "meta",
        "scripts",
    ]

    # Locked files at root
    LOCKED_FILES = [
        "start-here.md",
        "manifest.json",
    ]

    # Locked skills (standard skills)
    LOCKED_SKILLS = [
        "agent-governance",
        "ai-integration",
        "guardian",
        "skill-interface.md",
    ]

    # Required files in project/
    REQUIRED_PROJECT_FILES = [
        "context.md",
        "tech-stack.md",
        "known-issues.md",
        "commands.md",
        "session-journal.md",
        "status.md",   # essential layer — AI needs current project state
        "deploy.md",   # context layer — required reading for infra tasks
    ]

    # Human-readable descriptions for each required project file (used by co scaffold)
    PROJECT_FILE_DESCRIPTIONS: dict[str, str] = {
        "context.md": "Project overview, goals, and business context",
        "tech-stack.md": "Technology choices, versions, and dependencies",
        "known-issues.md": "Active bugs, workarounds, and technical debt",
        "commands.md": "Build, test, run, and deployment commands",
        "session-journal.md": "Per-session AI work log",
        "status.md": "Current phase, task board, blockers, session context",
        "deploy.md": "Deployment environments and infrastructure",
    }

    # Required SOP files in project/sop/ (stem name → description)
    REQUIRED_SOP_FILES: dict[str, str] = {
        "release.md": "Release process SOP (version bump, tag, CI trigger)",
        "debug.md": "Debugging SOP (reproduce, evidence, root cause, fix)",
        "git-workflow.md": "Git commit conventions, branch strategy, tagging rules",
        "code-review.md": "Code review strategy (review levels, domain checklists, high-risk patterns)",
    }

    # Standard directory structure
    STANDARD_DIRS = [
        "core",
        "adapters",
        "meta",
        "scripts",
        "skills",
        "project",
        "project/sop",
    ]

    # Directories to exclude when traversing (third-party/build artifacts)
    IGNORED_DIRS = (".venv", "node_modules", "__pycache__", ".git", "dist", "build")

    def __init__(self, agent_dir: Path):
        self.agent_dir = agent_dir
        self.results: list[LintResult] = []
        self.manifest = self._load_manifest()

    def _load_manifest(self) -> dict[str, object]:
        """Load manifest.json."""
        manifest_path = self.agent_dir / "manifest.json"
        if manifest_path.exists():
            result: dict[str, object] = json.loads(manifest_path.read_text(encoding="utf-8"))
            return result
        return {}

    @staticmethod
    def compute_sha256(file_path: Path) -> str:
        """Compute SHA256 hash of a file."""
        sha256 = hashlib.sha256()
        content = file_path.read_bytes()
        sha256.update(content)
        return sha256.hexdigest()

    def get_all_locked_files(self) -> list[str]:
        """Get list of all locked file paths (relative to .agent)."""
        locked_files = []

        # Root locked files (except manifest.json which contains checksums)
        for f in self.LOCKED_FILES:
            if f != "manifest.json":  # Skip manifest itself
                path = self.agent_dir / f
                if path.exists():
                    locked_files.append(f)

        # Locked directories
        for locked_dir in self.LOCKED_DIRS:
            dir_path = self.agent_dir / locked_dir
            if dir_path.exists():
                for file_path in dir_path.rglob("*"):
                    if file_path.is_file():
                        rel_path = file_path.relative_to(self.agent_dir)
                        locked_files.append(str(rel_path).replace("\\", "/"))

        # Locked skills
        skills_dir = self.agent_dir / "skills"
        if skills_dir.exists():
            for skill in self.LOCKED_SKILLS:
                skill_path = skills_dir / skill
                if skill_path.is_file():
                    locked_files.append(f"skills/{skill}")
                elif skill_path.is_dir():
                    for file_path in skill_path.rglob("*"):
                        if file_path.is_file():
                            rel_path = file_path.relative_to(self.agent_dir)
                            locked_files.append(str(rel_path).replace("\\", "/"))

        return sorted(set(locked_files))

    def generate_checksums(self) -> dict[str, str]:
        """Generate checksums for all locked files."""
        checksums = {}
        for rel_path in self.get_all_locked_files():
            file_path = self.agent_dir / rel_path
            if file_path.exists():
                checksums[rel_path] = self.compute_sha256(file_path)
        return checksums

    def lint_all(self) -> list[LintResult]:
        """Execute all checks."""
        self.check_directory_structure()
        self.check_required_files()
        self.check_integrity()
        self.check_start_here_spec()
        self.check_naming_convention()
        self.check_skills_placement()
        self.check_engine_pollution()
        self.check_internal_links()
        self.check_relations()
        self.check_changes_structure()
        self.check_version_state()
        self.check_policy()
        return self.results

    def lint_rule(self, rule: str) -> list[LintResult]:
        """Execute specific rule check."""
        rule_methods = {
            "directory-structure": self.check_directory_structure,
            "required-files": self.check_required_files,
            "integrity-violation": self.check_integrity,
            "start-here-spec": self.check_start_here_spec,
            "naming-convention": self.check_naming_convention,
            "skills-placement": self.check_skills_placement,
            "engine-pollution": self.check_engine_pollution,
            "internal-links": self.check_internal_links,
            "relations": self.check_relations,
            "changes-structure": self.check_changes_structure,
            "version-state": self.check_version_state,
            "policy": self.check_policy,
        }
        if rule in rule_methods:
            rule_methods[rule]()
        return self.results

    def check_directory_structure(self) -> None:
        """Check standard directories exist."""
        for dir_name in self.STANDARD_DIRS:
            dir_path = self.agent_dir / dir_name
            if dir_path.exists() and dir_path.is_dir():
                self.results.append(
                    LintResult(
                        "directory-structure",
                        True,
                        f"Directory exists: {dir_name}/",
                        dir_name,
                    )
                )
            else:
                self.results.append(
                    LintResult(
                        "directory-structure",
                        False,
                        f"Missing standard directory: {dir_name}/",
                        dir_name,
                    )
                )

    def check_required_files(self) -> None:
        """Check required files in project/ directory."""
        project_dir = self.agent_dir / "project"

        if not project_dir.exists():
            self.results.append(
                LintResult(
                    "required-files",
                    False,
                    "project/ directory does not exist",
                    "project",
                )
            )
            return

        for file_name in self.REQUIRED_PROJECT_FILES:
            file_path = project_dir / file_name
            if file_path.exists():
                self.results.append(
                    LintResult(
                        "required-files",
                        True,
                        "Required file exists",
                        f"project/{file_name}",
                    )
                )
            else:
                self.results.append(
                    LintResult(
                        "required-files",
                        False,
                        "Missing required file",
                        f"project/{file_name}",
                    )
                )

        # Check required SOP files in project/sop/
        sop_dir = project_dir / "sop"
        if not sop_dir.exists():
            self.results.append(
                LintResult(
                    "required-files",
                    False,
                    "Missing required directory",
                    "project/sop",
                )
            )
        else:
            for sop_name in self.REQUIRED_SOP_FILES:
                sop_path = sop_dir / sop_name
                if sop_path.exists():
                    self.results.append(
                        LintResult(
                            "required-files",
                            True,
                            "Required SOP file exists",
                            f"project/sop/{sop_name}",
                        )
                    )
                else:
                    self.results.append(
                        LintResult(
                            "required-files",
                            False,
                            "Missing required SOP file",
                            f"project/sop/{sop_name}",
                        )
                    )

        # Also check root required files
        for file_name in self.LOCKED_FILES:
            file_path = self.agent_dir / file_name
            if file_path.exists():
                self.results.append(
                    LintResult(
                        "required-files",
                        True,
                        "Required file exists",
                        file_name,
                    )
                )
            else:
                self.results.append(
                    LintResult(
                        "required-files",
                        False,
                        "Missing required file",
                        file_name,
                    )
                )

    def check_changes_structure(self) -> None:
        """If project/changes/ has subdirs, each must have standard artifacts."""
        changes_dir = self.agent_dir / "project" / "changes"
        if not changes_dir.is_dir():
            return
        from cokodo_agent.changes import validate_change_directory

        for entry in sorted(changes_dir.iterdir()):
            if not entry.is_dir() or entry.name.startswith(".") or entry.name == "README.md":
                continue
            if entry.is_file():
                continue
            missing = validate_change_directory(entry)
            if not missing:
                self.results.append(
                    LintResult(
                        "changes-structure",
                        True,
                        f"Change '{entry.name}' has all standard artifacts",
                        f"project/changes/{entry.name}",
                    )
                )
            else:
                for artifact, msg in missing:
                    self.results.append(
                        LintResult(
                            "changes-structure",
                            False,
                            msg,
                            f"project/changes/{entry.name}/{artifact}",
                        )
                    )

    @staticmethod
    def _normalize_version_note_key(key: str) -> str:
        return key.strip().lower().replace("-", "_").replace(" ", "_")

    @staticmethod
    def _is_list_of_strings(value: object) -> bool:
        return isinstance(value, list) and all(isinstance(item, str) for item in value)

    @staticmethod
    def _read_toml(path: Path) -> dict[str, Any]:
        with path.open("rb") as f:
            data = tomllib.load(f)
        return data if isinstance(data, dict) else {}

    @classmethod
    def _parse_release_note_metadata(cls, path: Path) -> dict[str, str]:
        metadata: dict[str, str] = {}
        pattern = re.compile(r"^>\s*([^:]+):\s*(.+?)\s*$")
        started = False
        for line in path.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if not started and not stripped.startswith(">"):
                continue
            if not stripped and started:
                break
            if not stripped:
                continue
            match = pattern.match(stripped)
            if not match:
                if started:
                    break
                continue
            started = True
            value = match.group(2).strip()
            if value.startswith("`") and value.endswith("`") and len(value) >= 2:
                value = value[1:-1]
            metadata[cls._normalize_version_note_key(match.group(1))] = value.strip()
        return metadata

    @classmethod
    def _parse_canonical_version(cls, path: Path) -> str | None:
        try:
            if path.suffix == ".toml":
                data = cls._read_toml(path)
                candidates = [
                    ("workspace", "package", "version"),
                    ("package", "version"),
                    ("project", "version"),
                    ("tool", "poetry", "version"),
                    ("version",),
                ]
                for candidate in candidates:
                    current: Any = data
                    for key in candidate:
                        if not isinstance(current, dict) or key not in current:
                            current = None
                            break
                        current = current[key]
                    if isinstance(current, str) and current.strip():
                        return current.strip()
                return None

            if path.suffix == ".json":
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    version = data.get("version")
                    if isinstance(version, str) and version.strip():
                        return version.strip()
                    package = data.get("package")
                    if isinstance(package, dict):
                        version = package.get("version")
                        if isinstance(version, str) and version.strip():
                            return version.strip()
                return None

            content = path.read_text(encoding="utf-8")
            if path.suffix == ".py":
                patterns = [
                    r'__version__\s*=\s*["\']([^"\']+)["\']',
                    r'\bVERSION\s*=\s*["\']([^"\']+)["\']',
                ]
                for pattern in patterns:
                    match = re.search(pattern, content)
                    if match:
                        return match.group(1).strip()
                return None

            if path.suffix == ".rs":
                patterns = [
                    r'PROTOCOL_VERSION\s*:\s*u\d+\s*=\s*(\d+)',
                    r'const\s+VERSION\s*:\s*&str\s*=\s*"([^"]+)"',
                    r'pub\s+const\s+VERSION\s*:\s*&str\s*=\s*"([^"]+)"',
                ]
                for pattern in patterns:
                    match = re.search(pattern, content)
                    if match:
                        return match.group(1).strip()
                return None
        except (OSError, json.JSONDecodeError, tomllib.TOMLDecodeError):
            return None

        return None

    def check_version_state(self) -> None:
        """Check optional machine-readable version governance state."""
        policy_path = self.agent_dir / "project" / "versioning.md"
        state_path = self.agent_dir / "project" / "version-state.toml"
        release_sop_path = self.agent_dir / "project" / "sop" / "release.md"

        if not state_path.exists():
            self.results.append(
                LintResult(
                    "version-state",
                    True,
                    "Optional version-state not enabled; skipping structured version-governance checks",
                    "project/version-state.toml",
                )
            )
            return

        if not policy_path.exists():
            self.results.append(
                LintResult(
                    "version-state",
                    False,
                    "Structured version governance requires project/versioning.md",
                    "project/versioning.md",
                )
            )

        if not release_sop_path.exists():
            self.results.append(
                LintResult(
                    "version-state",
                    False,
                    "Structured version governance requires project/sop/release.md",
                    "project/sop/release.md",
                )
            )

        try:
            state = self._read_toml(state_path)
        except (OSError, tomllib.TOMLDecodeError) as exc:
            self.results.append(
                LintResult(
                    "version-state",
                    False,
                    f"Failed to parse version-state.toml: {exc}",
                    "project/version-state.toml",
                )
            )
            return

        schema_version = state.get("schema_version")
        if not isinstance(schema_version, int):
            self.results.append(
                LintResult(
                    "version-state",
                    False,
                    "schema_version must be an integer",
                    "project/version-state.toml",
                )
            )
        elif schema_version != 1:
            self.results.append(
                LintResult(
                    "version-state",
                    False,
                    f"Unsupported schema_version {schema_version}; checker currently expects 1",
                    "project/version-state.toml",
                )
            )
        else:
            self.results.append(
                LintResult(
                    "version-state",
                    True,
                    "schema_version is valid",
                    "project/version-state.toml",
                )
            )

        tracks = state.get("tracks")
        if not isinstance(tracks, dict) or not tracks:
            self.results.append(
                LintResult(
                    "version-state",
                    False,
                    "version-state.toml must contain a non-empty [tracks] table",
                    "project/version-state.toml",
                )
            )
            return

        enabled_tracks = [
            name
            for name, track_state in tracks.items()
            if isinstance(track_state, dict) and track_state.get("enabled", True) is not False
        ]
        multi_track = len(enabled_tracks) > 1

        for track_name, track_state in tracks.items():
            if not isinstance(track_state, dict):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Track state must be a TOML table",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue

            enabled = track_state.get("enabled", True)
            if not isinstance(enabled, bool):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "enabled must be a boolean",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue

            if not enabled:
                self.results.append(
                    LintResult(
                        "version-state",
                        True,
                        f"Track '{track_name}' disabled; skipped",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue

            canonical_source = track_state.get("canonical_source")
            if not isinstance(canonical_source, str) or not canonical_source.strip():
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Missing canonical_source",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue

            canonical_path = self.agent_dir.parent / canonical_source
            if not canonical_path.exists():
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Canonical source not found: {canonical_source}",
                        canonical_source,
                    )
                )
                continue

            current_release = track_state.get("current_release")
            if not isinstance(current_release, str) or not current_release.strip():
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Missing current_release",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue
            current_release = current_release.strip()

            working_version = track_state.get("working_version")
            if not isinstance(working_version, str) or not working_version.strip():
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Missing working_version",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue
            working_version = working_version.strip()

            status = track_state.get("status")
            if not isinstance(status, str) or status not in self.VERSION_STATE_VALID_STATUSES:
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Invalid status {status!r}",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                continue

            derived_sync = track_state.get("derived_sync", [])
            if derived_sync and not self._is_list_of_strings(derived_sync):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "derived_sync must be a list of strings",
                        f"project/version-state.toml::{track_name}",
                    )
                )
            elif isinstance(derived_sync, list):
                for rel_path in derived_sync:
                    if not (self.agent_dir.parent / rel_path).exists():
                        self.results.append(
                            LintResult(
                                "version-state",
                                False,
                                f"Derived sync target not found: {rel_path}",
                                rel_path,
                            )
                        )

            for list_key in ("compatibility", "scope_refs"):
                list_value = track_state.get(list_key, [])
                if list_value and not self._is_list_of_strings(list_value):
                    self.results.append(
                        LintResult(
                            "version-state",
                            False,
                            f"{list_key} must be a list of strings",
                            f"project/version-state.toml::{track_name}",
                        )
                    )

            tag = track_state.get("tag", "")
            if status not in {"stable", "deprecated"} and (not isinstance(tag, str) or not tag.strip()):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Missing tag for active/releasable track",
                        f"project/version-state.toml::{track_name}",
                    )
                )
            elif isinstance(tag, str) and tag.strip() and multi_track and not tag.strip().startswith(f"{track_name}/"):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Multi-track project tags should be track-prefixed: expected prefix '{track_name}/'",
                        f"project/version-state.toml::{track_name}",
                    )
                )

            rollback_tag = track_state.get("rollback_tag", "")
            rollback_note = track_state.get("rollback_note", "")
            if status in {"released", "hotfix"} and not (
                isinstance(rollback_tag, str) and rollback_tag.strip()
            ) and not (isinstance(rollback_note, str) and rollback_note.strip()):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Released/hotfix track must define rollback_tag or rollback_note",
                        f"project/version-state.toml::{track_name}",
                    )
                )
            elif isinstance(rollback_tag, str) and rollback_tag.strip() and multi_track and not rollback_tag.strip().startswith(f"{track_name}/"):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Multi-track rollback_tag should be track-prefixed: expected prefix '{track_name}/'",
                        f"project/version-state.toml::{track_name}",
                    )
                )

            release_note = track_state.get("release_note", "")
            expects_release_note = status not in {"stable", "deprecated"}
            if expects_release_note and (not isinstance(release_note, str) or not release_note.strip()):
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        "Active/releasable track must define release_note",
                        f"project/version-state.toml::{track_name}",
                    )
                )
                release_note_path = None
            elif isinstance(release_note, str) and release_note.strip():
                release_note_path = self.agent_dir.parent / release_note.strip()
                if not release_note_path.exists():
                    self.results.append(
                        LintResult(
                            "version-state",
                            False,
                            f"Release note not found: {release_note.strip()}",
                            release_note.strip(),
                        )
                    )
                    release_note_path = None
            else:
                release_note_path = None

            canonical_version = self._parse_canonical_version(canonical_path)
            if canonical_version is None:
                self.results.append(
                    LintResult(
                        "version-state",
                        True,
                        f"Canonical source exists but version could not be parsed automatically: {canonical_source}",
                        canonical_source,
                    )
                )
            elif status == "released" and canonical_version != current_release:
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Released track canonical version {canonical_version} does not match current_release {current_release}",
                        canonical_source,
                    )
                )
            elif status != "released" and canonical_version not in {current_release, working_version}:
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Canonical version {canonical_version} is not one of current_release={current_release} or working_version={working_version}",
                        canonical_source,
                    )
                )
            else:
                self.results.append(
                    LintResult(
                        "version-state",
                        True,
                        f"Track '{track_name}' canonical version is consistent with state",
                        canonical_source,
                    )
                )

            if release_note_path is None:
                continue

            metadata = self._parse_release_note_metadata(release_note_path)
            if not metadata:
                self.results.append(
                    LintResult(
                        "version-state",
                        True,
                        f"Release note exists for track '{track_name}' (metadata contract not detected; content-only validation skipped)",
                        release_note_path.relative_to(self.agent_dir.parent).as_posix(),
                    )
                )
                continue

            note_track = metadata.get("track")
            if note_track and note_track != track_name:
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Release note track is {note_track!r}, expected {track_name!r}",
                        release_note_path.relative_to(self.agent_dir.parent).as_posix(),
                    )
                )

            expected_note_version = current_release if status == "released" else working_version
            note_version = metadata.get("version")
            if note_version and note_version != expected_note_version:
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Release note version is {note_version!r}, expected {expected_note_version!r}",
                        release_note_path.relative_to(self.agent_dir.parent).as_posix(),
                    )
                )

            note_canonical = metadata.get("canonical_version_source")
            if note_canonical and note_canonical != canonical_source:
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Release note canonical source is {note_canonical!r}, expected {canonical_source!r}",
                        release_note_path.relative_to(self.agent_dir.parent).as_posix(),
                    )
                )

            note_tag = metadata.get("release_tag")
            if note_tag and isinstance(tag, str) and tag.strip() and note_tag != tag.strip():
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Release note tag is {note_tag!r}, expected {tag.strip()!r}",
                        release_note_path.relative_to(self.agent_dir.parent).as_posix(),
                    )
                )

            note_rollback = metadata.get("rollback_tag")
            if note_rollback and isinstance(rollback_tag, str) and rollback_tag.strip() and note_rollback != rollback_tag.strip():
                self.results.append(
                    LintResult(
                        "version-state",
                        False,
                        f"Release note rollback tag is {note_rollback!r}, expected {rollback_tag.strip()!r}",
                        release_note_path.relative_to(self.agent_dir.parent).as_posix(),
                    )
                )

    def check_policy(self) -> None:
        """Run bundled OPA/Conftest policy packs against the project.

        Behaviour:
          - If conftest is not on PATH → emit a single passing 'skipped'
            result so offline / minimal installs do not break.
          - Otherwise evaluate each bundled pack via
            ``cokodo_agent.policies.run_conftest`` and surface one
            ``LintResult`` per pack.
        """
        # Local import to avoid a circular dependency at module load time.
        from cokodo_agent import policies as _policies

        project_root = self.agent_dir.parent
        packs = _policies.list_bundled_policies()
        if not packs:
            self.results.append(
                LintResult(
                    "policy",
                    True,
                    "No bundled policy packs found; nothing to evaluate",
                )
            )
            return

        if not _policies.conftest_available():
            self.results.append(
                LintResult(
                    "policy",
                    True,
                    f"conftest not installed; {len(packs)} pack(s) skipped (install: https://www.conftest.dev/install/)",
                )
            )
            return

        for pack in packs:
            try:
                policy_dir = _policies.bundled_policy_dir(pack)
                data = _policies.collect_data(pack, project_root)
            except (FileNotFoundError, ValueError) as exc:
                self.results.append(
                    LintResult("policy", False, f"{pack}: {exc}")
                )
                continue

            try:
                result = _policies.run_conftest(policy_dir, data, namespace=pack)
            except FileNotFoundError as exc:
                self.results.append(
                    LintResult("policy", True, f"{pack}: {exc}")
                )
                continue
            except OSError as exc:
                self.results.append(
                    LintResult("policy", False, f"{pack}: conftest failed to start ({exc})")
                )
                continue

            if result.returncode == 0:
                self.results.append(
                    LintResult("policy", True, f"{pack}: all rules passed")
                )
            else:
                summary = result.stdout.strip().splitlines()
                snippet = " | ".join(summary[-3:]) if summary else "violation"
                self.results.append(
                    LintResult(
                        "policy",
                        False,
                        f"{pack}: {snippet}",
                    )
                )

    def check_integrity(self) -> None:
        """Check integrity of locked files using SHA256 checksums."""
        checksums_obj = self.manifest.get("checksums", {})
        stored_checksums: dict[str, str] = (
            checksums_obj if isinstance(checksums_obj, dict) else {}
        )

        if not stored_checksums:
            self.results.append(
                LintResult(
                    "integrity-violation",
                    False,
                    "No checksums found in manifest.json. Run 'co update-checksums' to generate.",
                    "manifest.json",
                )
            )
            return

        locked_files = self.get_all_locked_files()

        for rel_path in locked_files:
            file_path = self.agent_dir / rel_path

            if rel_path not in stored_checksums:
                # New file not in checksums - could be unauthorized addition
                self.results.append(
                    LintResult(
                        "integrity-violation",
                        False,
                        "File not in checksums (possibly unauthorized addition)",
                        rel_path,
                    )
                )
                continue

            if not file_path.exists():
                self.results.append(
                    LintResult(
                        "integrity-violation",
                        False,
                        "Locked file missing",
                        rel_path,
                    )
                )
                continue

            current_hash = self.compute_sha256(file_path)
            expected_hash = stored_checksums[rel_path]

            if current_hash == expected_hash:
                self.results.append(
                    LintResult(
                        "integrity-violation",
                        True,
                        "Integrity verified",
                        rel_path,
                    )
                )
            else:
                self.results.append(
                    LintResult(
                        "integrity-violation",
                        False,
                        "File modified (hash mismatch)",
                        rel_path,
                    )
                )

        # Check for files in checksums that no longer exist
        for rel_path in stored_checksums:
            if rel_path not in locked_files:
                file_path = self.agent_dir / rel_path
                if not file_path.exists():
                    self.results.append(
                        LintResult(
                            "integrity-violation",
                            False,
                            "Locked file deleted",
                            rel_path,
                        )
                    )

    def check_start_here_spec(self) -> None:
        """Check start-here.md does not contain project-specific info."""
        start_here = self.agent_dir / "start-here.md"

        if not start_here.exists():
            return  # Already reported in required-files

        content = start_here.read_text(encoding="utf-8")

        # Patterns that should NOT appear in start-here.md
        forbidden_patterns = [
            (r"^#\s+[A-Z][a-zA-Z0-9_-]+\s*$", "Project name as title"),
            (r"项目概述|Project Overview", "Project overview section"),
            (r"开发状态|Development Status", "Development status"),
            (r"技术栈|Tech Stack", "Tech stack info"),
            (r"目录结构|Directory Structure", "Directory structure"),
            (r"核心数据类型|Core Data Types", "Core data types"),
            (r"常用命令|Common Commands", "Common commands"),
        ]

        found_violation = False
        for pattern, desc in forbidden_patterns:
            matches = list(re.finditer(pattern, content, re.MULTILINE))
            if matches:
                found_violation = True
                for match in matches:
                    line_num = content[: match.start()].count("\n") + 1
                    self.results.append(
                        LintResult(
                            "start-here-spec",
                            False,
                            f"Should not contain {desc}: '{match.group().strip()}'",
                            "start-here.md",
                            line_num,
                        )
                    )

        if not found_violation:
            self.results.append(
                LintResult(
                    "start-here-spec",
                    True,
                    "No project-specific content detected",
                    "start-here.md",
                )
            )

    def _is_under_ignored_dir(self, relative_path: Path) -> bool:
        """Return True if path has any ignored directory in its parts."""
        return any(part in self.IGNORED_DIRS for part in relative_path.parts)

    def check_naming_convention(self) -> None:
        """Check kebab-case naming convention for .md files."""
        # kebab-case: base name or base.template.md
        pattern = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*(\.template)?\.md$")
        exceptions = {
            "MANIFEST.json",
            "VERSION",
            "SKILL.md",
            "README.md",
            "CHANGELOG.md",
            "AGENT-GIT-PR-WORKFLOW.md",  # deliberate entry-point name (axupdater / Axlinker handoff)
        }

        for path in self.agent_dir.rglob("*.md"):
            relative = path.relative_to(self.agent_dir)
            if self._is_under_ignored_dir(relative):
                continue
            if path.name in exceptions:
                continue

            if pattern.match(path.name):
                self.results.append(
                    LintResult(
                        "naming-convention",
                        True,
                        "Follows kebab-case",
                        str(relative),
                    )
                )
            else:
                self.results.append(
                    LintResult(
                        "naming-convention",
                        False,
                        f"Should use kebab-case: {path.name}",
                        str(relative),
                    )
                )

    def check_skills_placement(self) -> None:
        """Check project-specific skills are in _project/ directory."""
        skills_dir = self.agent_dir / "skills"

        if not skills_dir.exists():
            return

        # Get all items directly under skills/
        for item in skills_dir.iterdir():
            if item.name.startswith("."):
                continue

            relative = item.relative_to(self.agent_dir)

            # Check if it's a standard skill or _project
            if item.name in self.LOCKED_SKILLS or item.name == "_project":
                self.results.append(
                    LintResult(
                        "skills-placement",
                        True,
                        "Valid skill location",
                        str(relative),
                    )
                )
            else:
                # Non-standard item in skills/ root
                self.results.append(
                    LintResult(
                        "skills-placement",
                        False,
                        f"Project skill must be in skills/_project/: {item.name}",
                        str(relative),
                    )
                )

    def check_engine_pollution(self) -> None:
        """Check for hardcoded paths in locked directories."""
        pollution_patterns = [
            (r"[A-Z]:\\\\", "Windows path"),
            (r"(?<![a-zA-Z])[A-Z]:/", "Windows path"),
            (r"/home/\w+/", "Unix home path"),
            (r"/Users/\w+/", "macOS user path"),
            (r"localhost:\d+", "Hardcoded localhost"),
            (r"127\.0\.0\.1:\d+", "Hardcoded IP"),
        ]

        for locked_dir in self.LOCKED_DIRS:
            dir_path = self.agent_dir / locked_dir
            if not dir_path.exists():
                continue

            for path in dir_path.rglob("*.md"):
                relative = path.relative_to(self.agent_dir)
                content = path.read_text(encoding="utf-8")

                found_pollution = False
                for pattern, desc in pollution_patterns:
                    matches = list(re.finditer(pattern, content, re.IGNORECASE))
                    if matches:
                        found_pollution = True
                        for match in matches:
                            line_num = content[: match.start()].count("\n") + 1
                            self.results.append(
                                LintResult(
                                    "engine-pollution",
                                    False,
                                    f"Found {desc}: {match.group()}",
                                    str(relative),
                                    line_num,
                                )
                            )

                if not found_pollution:
                    self.results.append(
                        LintResult(
                            "engine-pollution",
                            True,
                            "No pollution detected",
                            str(relative),
                        )
                    )

    @staticmethod
    def _strip_fenced_code_blocks(content: str) -> str:
        """Replace fenced code block contents with blank lines to preserve line numbers."""
        return re.sub(
            r"^```[^\n]*\n.*?^```",
            lambda m: "\n" * m.group().count("\n"),
            content,
            flags=re.MULTILINE | re.DOTALL,
        )

    # Directories whose links resolve relative to .agent/ root, not their source location
    LINK_CHECK_SKIP_DIRS = ["templates"]

    def check_internal_links(self) -> None:
        """Check internal link validity."""
        link_pattern = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")

        for path in self.agent_dir.rglob("*.md"):
            relative = path.relative_to(self.agent_dir)
            if self._is_under_ignored_dir(relative):
                continue
            if any(
                relative.parts[0] == skip_dir
                for skip_dir in self.LINK_CHECK_SKIP_DIRS
                if relative.parts
            ):
                continue

            content = path.read_text(encoding="utf-8")
            stripped = self._strip_fenced_code_blocks(content)

            for match in link_pattern.finditer(stripped):
                link_text, link_target = match.groups()

                if link_target.startswith(("http://", "https://", "#", "mailto:")):
                    continue

                if link_target.startswith("/"):
                    target_path = self.agent_dir / link_target[1:]
                else:
                    target_path = path.parent / link_target

                target_str = str(target_path)
                if "#" in target_str:
                    target_path = Path(target_str.split("#")[0])

                line_num = content[: match.start()].count("\n") + 1

                if target_path.exists():
                    self.results.append(
                        LintResult(
                            "internal-links",
                            True,
                            f"Link valid: {link_target}",
                            str(relative),
                            line_num,
                        )
                    )
                else:
                    self.results.append(
                        LintResult(
                            "internal-links",
                            False,
                            f"Broken link: {link_target}",
                            str(relative),
                            line_num,
                        )
                    )


    def check_relations(self) -> None:
        """Check that declared references and collaborations are accessible."""
        from cokodo_agent.relations import (
            check_collaborations,
            check_references,
            load_collaborations,
            load_references,
        )

        refs = load_references(self.agent_dir)
        collabs = load_collaborations(self.agent_dir)

        if not refs and not collabs:
            self.results.append(
                LintResult("relations", True, "No relations declared", None)
            )
            return

        project_root = self.agent_dir.parent

        if refs:
            statuses = check_references(self.agent_dir, project_root)
            for st in statuses:
                if st.accessible:
                    self.results.append(
                        LintResult(
                            "relations",
                            True,
                            f"Reference '{st.name}' accessible ({st.source_type})",
                            "manifest.json",
                        )
                    )
                else:
                    self.results.append(
                        LintResult(
                            "relations",
                            False,
                            f"Reference '{st.name}' inaccessible: {st.error}",
                            "manifest.json",
                        )
                    )

        if collabs:
            cstatuses = check_collaborations(self.agent_dir, project_root)
            for cst in cstatuses:
                if cst.partner_accessible:
                    sync = "in sync" if cst.shared_files_in_sync else "drifted"
                    self.results.append(
                        LintResult(
                            "relations",
                            True,
                            f"Collaboration '{cst.name}' partner accessible ({sync})",
                            "manifest.json",
                        )
                    )
                else:
                    self.results.append(
                        LintResult(
                            "relations",
                            False,
                            f"Collaboration '{cst.name}' partner inaccessible: {cst.error}",
                            "manifest.json",
                        )
                    )

        from cokodo_agent.relations import detect_circular_references

        cycles = detect_circular_references(self.agent_dir, project_root)
        if cycles:
            for cycle in cycles:
                self.results.append(
                    LintResult(
                        "relations",
                        False,
                        f"Circular reference detected: {cycle}",
                        "manifest.json",
                    )
                )
        else:
            self.results.append(
                LintResult(
                    "relations",
                    True,
                    "No circular references detected",
                    "manifest.json",
                )
            )


def update_checksums(agent_dir: Path) -> dict[str, str]:
    """Update checksums in manifest.json and return the checksums."""
    manifest_path = agent_dir / "manifest.json"

    if not manifest_path.exists():
        raise FileNotFoundError(f"manifest.json not found at {manifest_path}")

    # Load existing manifest
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    # Generate new checksums
    linter = ProtocolLinter(agent_dir)
    checksums = linter.generate_checksums()

    # Update manifest
    manifest["checksums"] = checksums

    # Write back with proper formatting
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )

    return checksums
