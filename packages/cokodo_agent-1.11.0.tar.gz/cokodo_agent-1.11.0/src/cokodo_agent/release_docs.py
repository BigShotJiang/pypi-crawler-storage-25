"""Release-documentation refresh: deterministic gate for release notes + indexes.

Generic engine-layer implementation for the `Release Documentation Refresh`
workflow. Reads `project/version-state.toml` (and per-track
`[tracks.<name>.release_docs]` blocks) and verifies, for every selected track:

* the per-track release note exists at the declared path
* the release note contains no template placeholders
  (always-rejected: ``<VERSION>``, ``<X.Y.Z>``, ``x.y.z``, ``<release-id>``,
  ``<sha256>``, ``TODO`` ; rejected unless ``allow_draft``: ``TBD``,
  ``Draft``, ``http://...``)
* declared index files link the per-track release note and only contain
  version strings allowed by the track configuration
* declared manifest files match the per-track ``manifest_pattern_template``

The implementation is intentionally Python-only and cross-platform; project
shell wrappers (PowerShell, Node, etc.) may continue to call additional
project-specific assets *after* this gate passes.
"""

from __future__ import annotations

import re
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

# Always-rejected placeholders (templates / unfilled artifact metadata).
_ALWAYS_REJECTED: tuple[tuple[str, str], ...] = (
    (r"<VERSION>", "template version placeholder"),
    (r"<release-id>", "template release-id placeholder"),
    (r"<sha256>", "template sha256 placeholder"),
    (r"<X\.Y\.Z>", "template version placeholder"),
    (r"\bX\.Y\.Z\b", "template version placeholder"),
    (r"\bx\.y\.z\b", "template version placeholder"),
    (r"\ba\.b\.c\b", "template version placeholder"),
    (r"\bTODO\b", "TODO placeholder"),
)
# Rejected only when --allow-draft is NOT set.
_DRAFT_REJECTED: tuple[tuple[str, str], ...] = (
    (r"\bTBD\b", "TBD placeholder"),
    (r"\(Draft\)", "draft marker"),
    (r"\bDraft\b", "draft marker"),
    (r"http://\.\.\.", "placeholder URL"),
)

_DEFAULT_VERSION_REGEX = r"\b\d+\.\d+\.\d+\b"


@dataclass
class TrackFinding:
    track: str
    version: str
    release_note: str
    failures: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.failures


@dataclass
class CheckResult:
    project_root: Path
    state_path: Path
    findings: list[TrackFinding] = field(default_factory=list)
    fatal_errors: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return not self.fatal_errors and all(f.passed for f in self.findings)

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "state_path": str(self.state_path),
            "fatal_errors": list(self.fatal_errors),
            "findings": [
                {
                    "track": f.track,
                    "version": f.version,
                    "release_note": f.release_note,
                    "passed": f.passed,
                    "failures": list(f.failures),
                    "notes": list(f.notes),
                }
                for f in self.findings
            ],
        }


def load_version_state(agent_dir: Path) -> dict:
    state_path = agent_dir / "project" / "version-state.toml"
    if not state_path.is_file():
        raise FileNotFoundError(f"version-state.toml not found at {state_path}")
    with state_path.open("rb") as fh:
        return tomllib.load(fh)


def _enabled_tracks(state: dict) -> list[str]:
    tracks = state.get("tracks") or {}
    enabled: list[str] = []
    for name, cfg in tracks.items():
        if isinstance(cfg, dict) and cfg.get("enabled", True):
            enabled.append(name)
    return enabled


def select_tracks(state: dict, requested: str | None) -> list[str]:
    """Return the list of tracks to check.

    ``requested`` may be ``None`` (all enabled), ``"all"`` (all enabled), or a
    declared track name.
    """
    tracks = state.get("tracks") or {}
    if requested in (None, "all"):
        chosen = _enabled_tracks(state)
        if not chosen:
            raise ValueError("no enabled track in version-state.toml")
        return chosen
    if requested not in tracks:
        raise KeyError(
            f"track '{requested}' not declared in version-state.toml; "
            f"known: {sorted(tracks.keys())}"
        )
    return [requested]


def _scan_placeholders(text: str, allow_draft: bool) -> list[str]:
    findings: list[str] = []
    for pattern, label in _ALWAYS_REJECTED:
        if re.search(pattern, text):
            findings.append(label)
    if not allow_draft:
        for pattern, label in _DRAFT_REJECTED:
            if re.search(pattern, text):
                findings.append(label)
    # de-duplicate while preserving order
    seen: set[str] = set()
    unique: list[str] = []
    for item in findings:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique


def _check_release_note(
    project_root: Path,
    track_cfg: dict,
    version: str,
    allow_draft: bool,
    finding: TrackFinding,
) -> None:
    note_rel = track_cfg.get("release_note")
    if not note_rel:
        finding.failures.append(
            "release_note path is not declared in version-state.toml"
        )
        return
    finding.release_note = note_rel
    note_path = project_root / note_rel
    if not note_path.is_file():
        finding.failures.append(f"release note missing: {note_rel}")
        return
    text = note_path.read_text(encoding="utf-8")
    for label in _scan_placeholders(text, allow_draft):
        finding.failures.append(
            f"{note_rel} contains {label} for version {version}"
        )


def _allowed_versions_for_indexes(state: dict, track_cfg: dict) -> list[str]:
    """Aggregate version strings that are legitimately allowed in index docs.

    By default the gate accepts the union of ``current_release`` and
    ``working_version`` for **every** enabled track (so a multi-track index
    doc can list each track's current+working version). Per-track override:
    ``[tracks.<name>.release_docs] allowed_versions = ["..."]``.
    """
    override = (track_cfg.get("release_docs") or {}).get("allowed_versions")
    if override:
        return list(override)
    out: list[str] = []
    for cfg in (state.get("tracks") or {}).values():
        if not isinstance(cfg, dict) or not cfg.get("enabled", True):
            continue
        for key in ("current_release", "working_version"):
            v = cfg.get(key)
            if v and v not in out:
                out.append(str(v))
    return out


def _check_index_files(
    project_root: Path,
    state: dict,
    track: str,
    track_cfg: dict,
    finding: TrackFinding,
) -> None:
    rd = track_cfg.get("release_docs") or {}
    index_files: list[str] = list(rd.get("index_files") or [])
    if not index_files:
        return
    current_release = track_cfg.get("current_release")
    note_rel = track_cfg.get("release_note") or ""
    note_basename = note_rel.rsplit("/", 1)[-1]
    version_regex = rd.get("version_regex") or _DEFAULT_VERSION_REGEX
    allowed = _allowed_versions_for_indexes(state, track_cfg)
    pattern = re.compile(version_regex)

    for rel in index_files:
        path = project_root / rel
        if not path.is_file():
            finding.failures.append(f"index file missing: {rel}")
            continue
        text = path.read_text(encoding="utf-8")
        if note_basename and note_basename not in text:
            finding.failures.append(
                f"{rel} does not link current {track} release note "
                f"({note_basename})"
            )
        elif current_release and current_release not in text:
            finding.failures.append(
                f"{rel} does not reference current {track} release "
                f"{current_release}"
            )
        for found in {m.group(0) for m in pattern.finditer(text)}:
            if found not in allowed:
                finding.failures.append(
                    f"{rel} contains stale or unexplained version string "
                    f"{found} for {track} (allowed: {', '.join(allowed) or '<none>'})"
                )


def _check_manifest_files(
    project_root: Path,
    track: str,
    track_cfg: dict,
    finding: TrackFinding,
) -> None:
    rd = track_cfg.get("release_docs") or {}
    manifest_files: list[str] = list(rd.get("manifest_files") or [])
    if not manifest_files:
        return
    template: str | None = rd.get("manifest_pattern_template")
    note_rel = track_cfg.get("release_note") or ""
    if not note_rel:
        finding.failures.append(
            f"{track}: manifest_files declared but release_note is not set"
        )
        return
    if not template:
        # default: source path simply must appear
        template = re.escape(note_rel)
        compiled = re.compile(template)
    else:
        try:
            compiled = re.compile(template.replace("%SOURCE%", re.escape(note_rel)))
        except re.error as exc:
            finding.failures.append(
                f"{track}: manifest_pattern_template is invalid regex: {exc}"
            )
            return

    for rel in manifest_files:
        path = project_root / rel
        if not path.is_file():
            finding.failures.append(f"manifest file missing: {rel}")
            continue
        text = path.read_text(encoding="utf-8")
        if not compiled.search(text):
            finding.failures.append(
                f"{rel} does not expose {note_rel} per manifest_pattern_template"
            )
        else:
            finding.notes.append(f"{rel}: {note_rel} present")


def check(
    project_root: Path,
    agent_dir: Path,
    *,
    track: str | None = None,
    version: str | None = None,
    allow_draft: bool = False,
) -> CheckResult:
    """Run the deterministic release-doc gate."""
    state_path = agent_dir / "project" / "version-state.toml"
    result = CheckResult(project_root=project_root, state_path=state_path)
    try:
        state = load_version_state(agent_dir)
    except FileNotFoundError as exc:
        result.fatal_errors.append(str(exc))
        return result

    try:
        tracks_to_check = select_tracks(state, track)
    except (KeyError, ValueError) as exc:
        result.fatal_errors.append(str(exc))
        return result

    tracks_cfg = state.get("tracks") or {}
    for name in tracks_to_check:
        cfg = tracks_cfg.get(name) or {}
        target_version = (
            version
            or cfg.get("working_version")
            or cfg.get("current_release")
            or ""
        )
        finding = TrackFinding(
            track=name,
            version=str(target_version),
            release_note=str(cfg.get("release_note") or ""),
        )
        _check_release_note(project_root, cfg, str(target_version), allow_draft, finding)
        _check_index_files(project_root, state, name, cfg, finding)
        _check_manifest_files(project_root, name, cfg, finding)
        result.findings.append(finding)
    return result


# ---------------------------------------------------------------------------
# Agent prompt rendering (used by `co release-docs refresh`)
# ---------------------------------------------------------------------------


_AGENT_PROMPT_TEMPLATE = """Run Release Documentation Refresh.

Inputs:
- track: {track}
- version: {version}
- mode: {mode}

Follow .agent/project/sop/release-doc-refresh.md and
.agent/core/workflows/release-doc-refresh-workflow.md.
Use .agent/project/status.md, version-state.toml, the active change tasks (if any),
release notes, and git diff to determine what the public docs must say before release.
Do not rely on IDE-specific commands.
"""


def render_agent_prompt(
    *,
    track: str = "all",
    version: str = "<read from version-state.toml>",
    mode: str = "audit",
) -> str:
    return _AGENT_PROMPT_TEMPLATE.format(track=track, version=version, mode=mode)


def format_findings(result: CheckResult) -> str:
    """Human-readable summary suitable for stdout."""
    lines: list[str] = []
    if result.fatal_errors:
        lines.append("Fatal errors:")
        for msg in result.fatal_errors:
            lines.append(f"  - {msg}")
        return "\n".join(lines)
    for f in result.findings:
        head = f"[{'OK' if f.passed else 'FAIL'}] track={f.track} version={f.version}"
        lines.append(head)
        if f.release_note:
            lines.append(f"  release_note: {f.release_note}")
        for failure in f.failures:
            lines.append(f"  FAIL  {failure}")
        for note in f.notes:
            lines.append(f"  note  {note}")
    if not result.findings:
        lines.append("(no tracks checked)")
    lines.append("")
    lines.append(
        f"Result: {'PASS' if result.passed else 'FAIL'} "
        f"({sum(len(f.failures) for f in result.findings)} failure(s))"
    )
    return "\n".join(lines)
