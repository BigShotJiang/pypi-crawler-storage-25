"""Internal :class:`Parbaked` kernel building block.

This module defines the :class:`Parbaked` class that wires the auth router,
admin dashboard, rate limiting, DB engine, email transport, and migrations
onto a FastAPI app. It is the **internal** assembly used by
:func:`parbaked.runtime.create_app`; it is *not* the user-facing entry point.

Users should scaffold a project with ``parbaked new`` and run it with
``parbaked dev`` (which invokes ``parbaked.runtime:create_app`` as a factory).
The public API surface — ``create_app``, ``current_user``, ``get_session``,
``ParbakedConfig``, ``User``, ``UserStatus``, ``ConsoleEmail``, ``ResendEmail``,
``EmailTransport`` — is documented in ``AGENTS.md`` under "Public API surface".
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import secrets as _secrets
import sys
from collections.abc import Callable, Iterator
from pathlib import Path

from fastapi import FastAPI
from sqlalchemy.engine import Engine
from sqlmodel import Session, SQLModel, create_engine

from parbaked.admin import build_admin_router
from parbaked.auth.deps import make_current_user
from parbaked.auth.router import build_auth_router
from parbaked.body_limit import BodySizeLimitMiddleware
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.console import ConsoleEmail
from parbaked.email.resend import ResendEmail
from parbaked.email.templates import Templates
from parbaked.hooks import Hooks, UserCallback
from parbaked.logging import configure_logging
from parbaked.migrations import apply_migrations
from parbaked.ratelimit import install_rate_limiting
from parbaked.security_headers import add_security_headers

_DEFAULT_SECRETS_PATH = Path(".parbaked.json")


class Parbaked:
    """Internal kernel assembly behind :func:`parbaked.runtime.create_app`.

    This class is **not the user-facing entry point.** It is the building
    block ``create_app()`` uses to wire the auth router, admin dashboard,
    rate limiting, DB engine, email transport, and migrations onto a
    FastAPI app. Tests and other framework internals construct it directly;
    PoC authors should not.

    **Scaffolding a new project**::

        parbaked new myapp
        cd myapp
        parbaked dev

    **Custom ASGI entry point** (e.g. gunicorn) — use ``create_app``, not
    this class::

        # wsgi.py
        from parbaked.runtime import create_app
        app = create_app()

    **Framework-internal usage** (tests, ``create_app``, advanced wiring) is
    the only context where instantiating this class directly is appropriate::

        # internal / framework code — not for end users
        from fastapi import FastAPI
        from parbaked.app import Parbaked

        app = FastAPI()
        Parbaked(app)

    Every default is overridable via keyword args, env vars (``PARBAKED_*``),
    or by writing values into ``.parbaked.json`` before first boot. The
    public API surface is the eight symbols listed in ``AGENTS.md`` under
    "Public API surface"; ``Parbaked`` itself is intentionally not among
    them.

    See ``AGENTS.md`` "Public API surface".
    """

    def __init__(
        self,
        app: FastAPI | None = None,
        *,
        config: ParbakedConfig | None = None,
        database_url: str | None = None,
        engine: Engine | None = None,
        get_session: Callable[..., Iterator[Session]] | None = None,
        email: EmailTransport | None = None,
        templates: Templates | None = None,
        secrets_file: Path | str = _DEFAULT_SECRETS_PATH,
        admin_password: str | None = None,
        banner: bool = True,
        on_signup: UserCallback | None = None,
        on_verify: UserCallback | None = None,
        on_approve: UserCallback | None = None,
        on_reject: UserCallback | None = None,
        on_delete: UserCallback | None = None,
    ) -> None:
        self._secrets_file = Path(secrets_file)
        self._generated: list[str] = []  # which secrets we auto-generated this boot
        self._from_disk: list[str] = []  # which secrets we loaded from .parbaked.json

        # ---- config -----------------------------------------------------
        self.config = config or ParbakedConfig()

        # ---- logging ---------------------------------------------------
        # Idempotent — calling Parbaked twice doesn't double-install.
        configure_logging(self.config.effective_log_format())
        stored = self._load_secrets()

        if not self.config.jwt_secret:
            self.config.jwt_secret = self._resolve_secret("jwt_secret", stored)
        if not self.config.approval_token_secret:
            self.config.approval_token_secret = self._resolve_secret(
                "approval_token_secret", stored
            )

        # Admin password: explicit arg > env > stored > generated
        env_admin = os.getenv("PARBAKED_ADMIN_PASSWORD")
        self.admin_password = (
            admin_password
            or env_admin
            or self._resolve_secret("admin_password", stored, length=18)
        )

        self._save_secrets(stored)

        # ---- production-mode safety ------------------------------------
        # When PARBAKED_ENV=production, refuse to boot with auto-generated
        # secrets and warn loudly about anything else that breaks the single-
        # instance assumption. Dev mode is unchanged.
        if self.config.env == "production":
            self._enforce_production_safety()

        # ---- DB ---------------------------------------------------------
        if engine is not None:
            self.engine = engine
        else:
            # Precedence: explicit kwarg > config.database_url
            # (TOML / .env / PARBAKED_DATABASE_URL) > built-in default.
            url = database_url or self.config.database_url
            connect_args = (
                {"check_same_thread": False} if url.startswith("sqlite") else {}
            )
            self.engine = create_engine(url, connect_args=connect_args)
        self.database_url = str(self.engine.url)

        if get_session is None:

            def _default_get_session() -> Iterator[Session]:
                with Session(self.engine) as session:
                    yield session

            self.get_session = _default_get_session
        else:
            self.get_session = get_session

        # ---- email ------------------------------------------------------
        # Opinionated: ResendEmail if an API key is configured, else
        # ConsoleEmail. Anyone wanting a different provider passes their own
        # EmailTransport in.
        if email is not None:
            self.email = email
        elif self.config.resend_key:
            self.email = ResendEmail(self.config)
        else:
            self.email = ConsoleEmail(config=self.config)

        # One-shot greppable INFO line whenever Resend is the active
        # transport (#225). The boot banner shows this visually too, but
        # operators verifying a freshly-set ``PARBAKED_RESEND_KEY`` want a
        # log line they can ``fly logs | grep resend`` against to confirm
        # the switch actually took effect.
        if isinstance(self.email, ResendEmail):
            logging.getLogger("parbaked.email").info(
                "Resend transport active, sending from %s",
                self.config.effective_mail_from(),
            )

        # ---- production-mode transport check ---------------------------
        # ``email_enabled`` flips True the moment ``admin_email`` is set,
        # even without ``resend_key``. In that state the signup / approval /
        # password-reset paths all try to send mail — but the transport is
        # ``ConsoleEmail``, which prints to stdout. On fly.io that stdout
        # goes to the log pipeline, not the admin's inbox: silent
        # misdelivery. Hard-fail the boot so the operator can't ship a
        # production app that quietly drops admin mail. (#194)
        if (
            self.config.env == "production"
            and self.config.admin_email
            and isinstance(self.email, ConsoleEmail)
        ):
            raise RuntimeError(
                "parbaked refuses to start in production with "
                f"admin_email={self.config.admin_email} but no real email "
                "transport configured. Verify / approval / password-reset "
                "emails would be printed to stdout (e.g. fly logs) instead "
                "of delivered.\n\n"
                "Set PARBAKED_RESEND_KEY to a Resend API key (or pass a "
                "custom EmailTransport via email=...) before booting.\n\n"
                "Get a free key at https://resend.com/api-keys, or run "
                "`parbaked email setup`."
            )

        # ---- assemble ---------------------------------------------------
        self.templates = templates or Templates()
        self.hooks = Hooks(
            on_signup=on_signup,
            on_verify=on_verify,
            on_approve=on_approve,
            on_reject=on_reject,
            on_delete=on_delete,
        )
        self.current_user = make_current_user(self.config, self.get_session)

        self._installed: bool = False

        if app is not None:
            self.install(app, banner=banner)

    # -- public --------------------------------------------------------

    def install(self, app: FastAPI, *, banner: bool = True) -> None:
        """Wire the auth router, admin dashboard, rate limiting, and health
        endpoint onto ``app``.

        Also creates the ``users`` table if it doesn't exist. Idempotent — safe
        to call multiple times.
        """
        if self._installed:
            return

        if self.config.auto_migrate:
            # Brings parbaked's own DB up to the latest schema before any
            # request lands. Raises if a migration fails — the boot is
            # aborted rather than serving against a partial schema (#10).
            apply_migrations(self.engine)
        else:
            # Operator opted out; the DB might be stale. Be loud so the
            # mismatch isn't a silent surprise.
            SQLModel.metadata.create_all(self.engine)
            logging.getLogger("parbaked").warning(
                "auto_migrate=False; schema migrations were NOT applied. "
                "Run `parbaked admin migrate` to bring the DB up to date."
            )

        # Cap incoming bodies so a multi-MB POST to /auth/signup
        # can't tie up memory in the JSON parser (#167). parbaked's
        # biggest legit payload — the magic-link claim body — is well
        # under 1KB; default 8KB leaves comfortable headroom. The cap is
        # tunable via ``config.max_body_kb`` (#261) for deployments
        # whose consumer routes accept larger user content.
        app.add_middleware(
            BodySizeLimitMiddleware,
            max_bytes=self.config.max_body_kb * 1024,
        )

        # Defence-in-depth response headers for HTML pages (#200). Wired
        # before the routers so it sits at the bottom of the middleware
        # stack and stamps every HTML response on the way out.
        add_security_headers(app)

        limiter = install_rate_limiting(app, self.config)
        app.include_router(
            build_auth_router(
                self.config,
                self.get_session,
                self.email,
                limiter=limiter,
                templates=self.templates,
                hooks=self.hooks,
            )
        )
        app.include_router(
            build_admin_router(
                self.config,
                self.get_session,
                self.admin_password,
                self.email,
                self.templates,
                hooks=self.hooks,
                limiter=limiter,
            )
        )

        # Health endpoint for fly.io / Cloudflare / k8s / any uptime probe.
        # Intentionally simple — just confirms the process is running and the
        # event loop is responsive. No DB ping (don't want to amplify upstream
        # outages by failing the health check too).
        @app.get("/health", include_in_schema=False)
        async def _health() -> dict[str, str]:
            return {"status": "ok"}

        self._installed = True
        if banner:
            self._print_banner()

    # -- internals -----------------------------------------------------

    def _resolve_secret(self, key: str, stored: dict, length: int = 32) -> str:
        if value := stored.get(key):
            # Persisted in .parbaked.json from a previous boot. Track so
            # production-mode safety can refuse: prod secrets must come
            # from env vars, not from a file that escapes alongside the
            # build (see #195).
            self._from_disk.append(key)
            return value
        value = _secrets.token_urlsafe(length)
        stored[key] = value
        self._generated.append(key)
        return value

    def _load_secrets(self) -> dict:
        if not self._secrets_file.exists():
            return {}
        try:
            return json.loads(self._secrets_file.read_text())
        except (OSError, json.JSONDecodeError):
            return {}

    def _save_secrets(self, data: dict) -> None:
        if not data:
            return
        # If we can't write the secrets file we'll just regenerate next boot.
        # Loud failure isn't worth blocking startup over.
        with contextlib.suppress(OSError):
            self._secrets_file.write_text(json.dumps(data, indent=2) + "\n")
            with contextlib.suppress(OSError):
                os.chmod(self._secrets_file, 0o600)
            # POSIX mode bits don't apply on Windows — ``os.chmod`` only
            # toggles the read-only bit there, leaving the file readable
            # by any user on the box. Adding a Windows-specific ACL
            # dependency (pywin32) just to plug this is overkill when
            # the env-var path already sidesteps the cached file entirely.
            # Log a one-shot warning so the operator knows. (#194)
            if sys.platform == "win32":
                logging.getLogger("parbaked").warning(
                    "Secrets cached at %s — Windows ACLs are not set, "
                    "so the file may be readable by other users on this "
                    "machine. Consider setting PARBAKED_* secrets as env "
                    "vars and deleting %s.",
                    self._secrets_file,
                    self._secrets_file,
                )

    _PROD_SECRET_HINTS = {
        "jwt_secret": "PARBAKED_JWT_SECRET",
        "approval_token_secret": "PARBAKED_APPROVAL_TOKEN_SECRET",
        "admin_password": "PARBAKED_ADMIN_PASSWORD",
    }

    def _enforce_production_safety(self) -> None:
        """Hard-fail on prod-unsafe boots; warn on prod-suspicious ones.

        Trip-wires:
        - any required secret was auto-generated → ``RuntimeError`` listing
          each unset env var with the exact ``openssl rand -hex 32`` command
        - any required secret was loaded from ``.parbaked.json`` →
          ``RuntimeError`` (#195). Persisted dev secrets defeat the
          rotation story; in prod the contract is env vars only (fly
          secrets / equivalent). The starter has no ``.dockerignore``, so
          a leftover ``.parbaked.json`` ships inside the prod image and
          silently authenticates prod traffic against dev-quality secrets.
        - more than one worker / instance detected → critical log warning
          (parbaked's in-memory rate limit + per-machine secret cache assume
          a single instance; the multi-instance failure mode is "users get
          logged out at random")
        - ``.parbaked.json`` exists in production → log warning recommending
          env-var-only secrets, since persisted secrets defeat the point of
          rotating them via env
        - ``app_url`` is plain http:// → log warning, the admin session
          cookie's ``Secure`` flag won't be set so the cookie is exposed
        """
        # In email mode (#130) the admin password is never read at
        # sign-in — the magic-link to ``admin_email`` is the credential.
        # An auto-generated value is fine; the trip-wire only matters
        # for credentials the running app would actually verify.
        # Admin mode is gated on admin_email, NOT email_enabled — same
        # fix as the login form (Devin Review on #180).
        def _is_unsafe(k: str) -> bool:
            return not (k == "admin_password" and bool(self.config.admin_email))

        unsafe_generated = [k for k in self._generated if _is_unsafe(k)]
        if unsafe_generated:
            cmds = "\n".join(
                f"  export {self._PROD_SECRET_HINTS[k]}=$(openssl rand -hex 32)"
                for k in unsafe_generated if k in self._PROD_SECRET_HINTS
            )
            raise RuntimeError(
                "parbaked refuses to start in production with auto-generated "
                f"secrets. The following were generated this boot: "
                f"{', '.join(unsafe_generated)}.\n\n"
                "Set them explicitly via environment variables (or fly "
                "secrets / equivalent) so they survive restarts AND match "
                "across machines:\n\n"
                f"{cmds}\n\n"
                "Then redeploy."
            )

        # Persisted dev secrets (#195). A pre-existing .parbaked.json from a
        # `parbaked dev` run hands the prod boot working secrets — so the
        # auto-generation trip-wire above never fires, and the container
        # ends up serving production traffic with dev-quality credentials.
        # The prod contract is env vars only.
        unsafe_persisted = [k for k in self._from_disk if _is_unsafe(k)]
        if unsafe_persisted:
            envs = ", ".join(
                self._PROD_SECRET_HINTS[k]
                for k in unsafe_persisted
                if k in self._PROD_SECRET_HINTS
            )
            raise RuntimeError(
                "parbaked refuses to start in production with secrets read "
                f"from {self._secrets_file}. The following were loaded from "
                f"disk this boot: {', '.join(unsafe_persisted)}.\n\n"
                "Production deploys must set secrets via env vars (fly "
                f"secrets / equivalent: {envs}). Persisted dev secrets "
                "defeat the rotation story and silently authenticate prod "
                "traffic with dev-quality credentials. Run `parbaked "
                "secrets` (or `parbaked push-secrets`) and remove "
                f"{self._secrets_file} before re-deploying."
            )

        # Multi-instance detection. We respect WEB_CONCURRENCY (Heroku/fly
        # convention) and the gunicorn/uvicorn --workers flag echoed into
        # the same env var. Anything other than 1 (or unset) is suspect.
        workers = os.environ.get("WEB_CONCURRENCY", "1")
        try:
            n_workers = int(workers)
        except ValueError:
            n_workers = 1
        if n_workers > 1:
            logging.getLogger("parbaked").critical(
                "parbaked is running in production with WEB_CONCURRENCY=%s. "
                "parbaked assumes a single instance — the in-memory rate "
                "limit and the .parbaked.json secret cache won't be shared "
                "between workers. Either set WEB_CONCURRENCY=1, or run a "
                "single uvicorn process behind a load balancer.",
                workers,
            )

        if self._secrets_file.exists():
            logging.getLogger("parbaked").warning(
                "parbaked is running in production but %s exists on disk. "
                "Prefer env-var-only secrets in production so they can be "
                "rotated without redeploying a new file.",
                self._secrets_file,
            )

        if self.config.app_url.startswith("http://"):
            logging.getLogger("parbaked").warning(
                "parbaked is running in production with app_url=%s. The "
                "admin session cookie's Secure flag won't be set, so the "
                "cookie can be exfiltrated over a plaintext connection. "
                "Set PARBAKED_APP_URL to your https:// origin.",
                self.config.app_url,
            )

    def _print_banner(self) -> None:
        from parbaked import __version__

        base_url = self.config.app_url.rstrip("/")
        admin_url = f"{base_url}/auth/admin"
        app_url = f"{base_url}/"
        if not self.config.email_enabled:
            email_status = "disabled (dashboard-only)"
        elif isinstance(self.email, ConsoleEmail):
            email_status = "Console (printed below)"
        elif isinstance(self.email, ResendEmail):
            # Flag the sandbox sender explicitly so an operator who left
            # PARBAKED_MAIL_FROM unset realises mail is going out from
            # Resend's shared onboarding address (#225). Easy to miss when
            # the banner just says "Resend → onboarding@resend.dev".
            mail_from = self.config.effective_mail_from()
            sandbox_tag = " (sandbox sender)" if not self.config.mail_from else ""
            email_status = f"Resend → {mail_from}{sandbox_tag}"
        else:
            email_status = type(self.email).__name__

        is_prod = self.config.env == "production"
        title = f"parbaked v{__version__} is running"
        if is_prod:
            title += " · production"

        # Build the label/value rows first so we can size the box around
        # the longest content. Each entry is the body text rendered inside
        # the "║  ...║" frame.
        #
        # Banner shape (#328): URLs are grouped by audience so an indie
        # dev's first 30 seconds doesn't mix a consumer-facing SPA mount
        # with the operator-only admin UI. The previous "Sign up at:
        # /auth/signup" row pointed at a POST JSON endpoint that 405s in
        # a browser — first click, lost trust.
        rows: list[str] = []
        has_frontend = self.config.frontend is not None
        if has_frontend:
            # Section header is left-aligned without indentation; the row
            # under it is indented to match the existing "Admin email:" /
            # "Database:" rows.
            rows.append("Frontend:")
            rows.append(f"  {'App:':<12}{app_url}")
            # Blank spacer between sections — rendered as a row of
            # padding inside the box border so the box stays rectangular.
            rows.append("")
        rows.append("Backend:")
        rows.append(f"  {'Admin UI:':<12}{admin_url}")
        # Per-mode admin badge (#130): in email mode the admin's inbox
        # IS the badge — print the address so the operator knows where
        # the sign-in link will go. In no-email mode fall back to the
        # printed password. In prod, the password is exactly the env
        # var the operator set — printing it would just be noise (and a
        # log-leak risk), so we suppress that line.
        # Admin mode is gated on admin_email, NOT email_enabled — a project
        # with resend_key (for user mail) but no admin_email still uses the
        # password gate. Devin Review on #180.
        if bool(self.config.admin_email):
            rows.append(f"  {'Admin email:':<12}{self.config.admin_email}")
        elif not is_prod:
            rows.append(f"  {'Admin pass:':<12}{self.admin_password}")
        rows.append(f"  {'Email out:':<12}{email_status}")
        rows.append(f"  {'Database:':<12}{self.database_url}")

        # Optional "Discovered:" block (#306). Only rendered when at
        # least one of ``models.py`` / ``hooks.py`` / ``routes/*.py``
        # actually contributed something — fresh ``parbaked new`` with
        # no overrides stays as terse as before. The block sits between
        # the main rows and any notes (auto-generated-secrets warning)
        # so the warning keeps the bottom-of-banner emphasis.
        discovered_rows = self._build_discovered_rows()

        # Optional dev-mode-only nudge rows. In prod, _enforce_production_safety
        # has already raised if any secret was auto-generated, so this branch
        # never fires there.
        notes: list[str] = []
        if self._generated and not is_prod:
            notes.append("⚠ Auto-generated secrets stored in .parbaked.json")
            notes.append("  Add it to .gitignore. For prod, set env vars instead.")

        # Compute the inner content width. 64 is the historical default;
        # grow when the longest row would otherwise overflow the box
        # border (long custom domains, multi-byte mail_from, etc. — #206).
        # ``len()`` on a str is the codepoint count, which matches what
        # the terminal renders for ASCII + the BMP characters parbaked
        # uses (URLs, emails, paths, the warn glyph). Wide East-Asian
        # text would still look off but isn't expected in any of these
        # fields.
        inner = 2 + max(
            (len(s) for s in (title, *rows, *discovered_rows, *notes)),
            default=0,
        )
        width = max(64, inner + 2)  # +2 for the right-side padding
        # `width - 2 - len(title)` is the title row's right-pad budget.
        # Both rows() and notes() use `.ljust(width - 2)` so they line up
        # with the border at the right.

        lines = [
            "",
            "╔" + "═" * width + "╗",
            "║  " + title + " " * (width - 2 - len(title)) + "║",
            "╠" + "═" * width + "╣",
        ]
        for row in rows:
            lines.append("║  " + row.ljust(width - 2) + "║")
        if discovered_rows:
            lines.append("║" + " " * width + "║")
            for row in discovered_rows:
                lines.append("║  " + row.ljust(width - 2) + "║")
        if notes:
            lines.append("║" + " " * width + "║")
            for note in notes:
                lines.append("║  " + note.ljust(width - 2) + "║")

        lines.append("╚" + "═" * width + "╝")
        lines.append("")
        print("\n".join(lines), flush=True)

    def _build_discovered_rows(self) -> list[str]:
        """Render the "Discovered:" sub-block for the boot banner (#306).

        Reports whatever ``runtime.create_app()`` auto-loaded — consumer
        tables from ``models.py``, lifecycle hooks from ``hooks.py``,
        route files from ``routes/``. The block is meant to collapse the
        "did my hook actually wire up?" debugging loop into a glance at
        the boot output: if you dropped a ``hooks.py`` and it's not
        listed here, parbaked didn't pick it up.

        Returns ``[]`` when ``runtime.create_app`` didn't stash a
        discovery snapshot (Parbaked constructed directly in a test, or
        nothing autoloaded) so the banner stays as compact as before
        for the no-overrides case. The "Discovered:" header line is
        included in the return so the caller can treat the rows as an
        atomic block.
        """
        snapshot = getattr(self, "_discovered", None)
        if not snapshot:
            return []
        models = snapshot.get("models") or []
        hooks = snapshot.get("hooks") or []
        route_total = snapshot.get("routes_total") or 0
        route_breakdown = snapshot.get("routes_by_subdir") or {}

        # Suppress the block entirely when nothing autoloaded — fresh
        # ``parbaked new`` with no consumer ``models.py`` / ``hooks.py``
        # / ``routes/*.py`` shouldn't pay banner real estate for empty
        # rows. The "common no-overrides case" wanted explicitly in
        # #306.
        if not models and not hooks and route_total == 0:
            return []

        rows: list[str] = ["Discovered:"]
        label_width = 10  # "models" / "hooks" / "routes" + padding
        if models:
            # Use "consumer table" / "consumer tables" — distinguishes
            # consumer-defined tables from parbaked's own (users, schema-
            # version). Drop the names too: long lists wrap the box
            # ugly, and the count + sample is what a consumer scanning
            # for "did my model autoload" actually wants.
            sample = ", ".join(models[:3])
            if len(models) > 3:
                sample += ", …"
            noun = "consumer table" if len(models) == 1 else "consumer tables"
            rows.append(f"  {'models':<{label_width}}{len(models)} {noun} ({sample})")
        if hooks:
            rows.append(f"  {'hooks':<{label_width}}{', '.join(hooks)}")
        if route_total:
            # Per-subdir breakdown only when there are non-root buckets
            # to show. A flat ``routes/index.py`` + ``routes/dashboard.py``
            # layout would otherwise render "5 (/ × 5)" which is noise.
            non_root = sorted(
                (k, v) for k, v in route_breakdown.items() if k
            )
            if non_root:
                parts = [f"/{name} × {count}" for name, count in non_root]
                rows.append(
                    f"  {'routes':<{label_width}}{route_total} ({', '.join(parts)})"
                )
            else:
                rows.append(f"  {'routes':<{label_width}}{route_total}")
        return rows
