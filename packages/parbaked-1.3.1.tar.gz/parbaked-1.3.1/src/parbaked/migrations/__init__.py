"""Forward-only schema migrations for parbaked's own DB (#10).

Why not Alembic: parbaked has its own DB (#47), one supported engine
(SQLite), and a tiny number of columns. Alembic — and the ``env.py`` /
``versions/`` / ``alembic.ini`` ecosystem around it — is far more weight
than the problem needs. The "tiny maintenance surface" principle wins.

Each migration is a callable ``up(conn)`` taking a SQLAlchemy connection.
Migrations are kept idempotent (CREATE IF NOT EXISTS, ALTER...ADD COLUMN
guarded by PRAGMA checks) so the same script can run against:

- a brand-new DB that ``create_all`` just populated to the latest schema
- a v0.7 DB with the bare ``users`` table
- a v0.8 DB that already has the new columns from ``create_all``

The :class:`SchemaVersion` table records the highest applied migration
index so we don't re-run migrations on every boot. v0.8 deployments
boot once into v0.9 and ``apply_migrations`` records the version going
forward.
"""

from __future__ import annotations

from parbaked.migrations._001_v08_columns import up as _001
from parbaked.migrations._002_is_admin import up as _002
from parbaked.migrations._003_email_lowercase import up as _003
from parbaked.migrations._004_admin_signin_nonce import up as _004
from parbaked.migrations._runner import LATEST_VERSION, apply_migrations

# Index in the list = migration version number.
#
# ``is_admin`` (added in _002 for #38) is now an orphan column as of v1.3.
# The User SQLModel no longer maps it and no code path reads it. We keep
# _002 in the chain so the column is still added on upgrade — the
# stability contract in ``docs/data-format-guarantees.md`` is forward-
# only / additive, and dropping the column would require a major-version
# bump. Same precedent as the v1.1 ``google_sub`` orphan in _001.
#
# _003 (#261) lower-cases every stored email and re-creates the unique
# email index with ``COLLATE NOCASE`` so the DB itself enforces the
# case-insensitivity that #164 introduced at the application layer.
#
# ``_004`` (added for #205) creates the single-row
# ``_parbaked_admin_signin_nonce`` table and seeds it. The table backs
# the one-shot enforcement on admin sign-in magic links — see the model
# docstring and ``parbaked.auth.tokens.verify_admin_signin_token``.
MIGRATIONS = [_001, _002, _003, _004]

__all__ = ["MIGRATIONS", "LATEST_VERSION", "apply_migrations"]
