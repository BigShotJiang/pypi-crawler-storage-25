"""First-run fly.io onboarding wizard (#82, v1.1).

Drives the path from "I just scaffolded a parbaked app" to "live URL on
fly.io" with as few decision points as possible. Detects flyctl, drives
``fly auth``, runs ``fly launch``, pushes secrets, calls
``parbaked deploy``. Caches state to ``.parbaked/deploy.json`` so the
wizard never re-fires — subsequent ``parbaked deploy`` runs go straight
to the deploy step.

The whole module assumes the indie / vibe-coder persona: each step has
one clear next action, no docs URLs to chase, no toggles. Power users
pass ``--skip-onboarding`` and the wizard is a no-op.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import secrets
import shutil
import string
import subprocess
import sys
import tempfile
import webbrowser
from datetime import UTC, datetime
from pathlib import Path

import typer

from parbaked.cli._console import console, error, info, stderr_console, success, warn

STATE_DIR = Path(".parbaked")
STATE_FILE = STATE_DIR / "deploy.json"

# fly app names: lowercase letters, digits, dashes. Suffix length 5 gives
# ~60 million combinations — comfortably collision-free for the indie
# tier (single user, a few projects). Re-using the same project name
# across machines re-rolls the suffix; the state file persists the chosen
# name on first deploy so subsequent ``parbaked deploy`` runs land on the
# same fly app.
_SUFFIX_ALPHABET = string.ascii_lowercase + string.digits
_SUFFIX_LEN = 5

_INSTALL_HINTS = {
    "darwin": "brew install flyctl",
    "win32": "winget install --id=Fly.io.flyctl",
    "linux": "curl -L https://fly.io/install.sh | sh",
}


def _install_hint() -> str:
    """OS-specific one-liner for installing flyctl."""
    return _INSTALL_HINTS.get(sys.platform, "https://fly.io/docs/flyctl/install/")


def _flyctl_present() -> bool:
    return shutil.which("fly") is not None


def _logged_in() -> bool:
    """True if ``fly auth whoami`` returns 0 (a valid session)."""
    try:
        r = subprocess.run(
            ["fly", "auth", "whoami"],
            capture_output=True,
            text=True,
            check=False,
        )
    except (FileNotFoundError, OSError):
        return False
    return r.returncode == 0


def _fly_app_exists(name: str) -> bool:
    """True if ``fly status`` finds an app with this name."""
    try:
        r = subprocess.run(
            ["fly", "status", "--app", name],
            capture_output=True,
            text=True,
            check=False,
        )
    except (FileNotFoundError, OSError):
        return False
    return r.returncode == 0


def _load_state() -> dict:
    if not STATE_FILE.exists():
        return {}
    try:
        return json.loads(STATE_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return {}


def _save_state(data: dict) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(data, indent=2) + "\n")


def already_onboarded() -> bool:
    """``True`` once ``fly_app_name`` has been cached — i.e. the wizard
    has at least claimed the fly app.

    ``parbaked deploy`` checks this and short-circuits the wizard so
    the second-and-onwards deploy is zero-prompt. If a first wizard
    run failed at the ``_step_deploy`` step (network blip, fly outage,
    image build error), ``fly_app_name`` is still cached so the user's
    retry runs the deploy step directly with the right target — no
    need to re-claim the app + re-push secrets.
    """
    return bool(_load_state().get("fly_app_name"))


def load_state() -> dict:
    """Public read of ``.parbaked/deploy.json``. Returns ``{}`` if absent.

    Other parts of parbaked (``deploy_gen``, ``destroy``) prefer the cached
    fly app name from this state over re-deriving from ``parbaked.toml`` —
    that's how the random-suffix slug survives across redeploys without
    being re-rolled each time.
    """
    return _load_state()


def _sanitise_base(base: str) -> str:
    """Lowercase + dash-collapse a project name into fly's allowed alphabet."""
    sanitised = re.sub(r"[^a-z0-9-]+", "-", base.lower()).strip("-")
    return sanitised or "parbaked-app"


def pick_fly_app_name(base: str) -> str:
    """Return the cached fly app name from state, or generate a new one.

    On first call (no state yet) builds ``<sanitised-base>-<5-char-suffix>``.
    The 5-char random suffix is the parbaked-opinionated answer to fly's
    *global* app-name uniqueness: common project names (``notepad``,
    ``todo``, ``tasks``) are nearly always taken on fly's shared
    namespace, and forcing the user to invent something unique on first
    deploy is friction we should absorb.

    On second-and-onwards calls (post-deploy state file exists) returns
    the previously chosen name verbatim so ``parbaked deploy`` redeploys
    to the same app.
    """
    cached = _load_state().get("fly_app_name")
    if cached:
        return cached
    suffix = "".join(secrets.choice(_SUFFIX_ALPHABET) for _ in range(_SUFFIX_LEN))
    return f"{_sanitise_base(base)}-{suffix}"


def _step_install_flyctl() -> None:
    if _flyctl_present():
        success("flyctl detected")
        return
    error("flyctl is required but not on PATH.")
    stderr_console.print("")
    stderr_console.print("Install it with:")
    stderr_console.print(f"  {_install_hint()}", markup=False, highlight=False)
    stderr_console.print("")
    stderr_console.print("Then re-run `parbaked init` (or `parbaked new <name> --deploy`).")
    raise typer.Exit(1)


def _step_login() -> None:
    if _logged_in():
        success("fly.io session active")
        return
    info("Not signed in to fly.io. Opening the browser for `fly auth signup`…")
    # Try signup first; fly.io routes existing users into login from the same
    # URL, so this works whether the user has an account or not.
    rc = subprocess.run(["fly", "auth", "signup"], check=False).returncode
    if rc != 0 or not _logged_in():
        error("fly auth didn't complete. Re-run when you're signed in.")
        raise typer.Exit(1)
    success("signed in")


def _step_launch(app_name: str) -> None:
    """Claim the fly app name via ``fly apps create``.

    Was previously ``fly launch --copy-config --no-deploy``, but launch
    writes a fresh ``fly.toml`` at the project root if it doesn't find
    one to copy. That file then short-circuits ``parbaked deploy``'s
    own deploy-target generator (``user_owns_deploy_files()`` returns
    True), and the resulting bare ``fly deploy`` fails because the
    launch-generated fly.toml has no ``[build]`` section + there's no
    Dockerfile at root. Caught on real-fly e2e against the user's
    account.

    ``fly apps create`` just claims the name in the user's personal
    org and stops there. No filesystem side-effects, no fly.toml
    generation — leaves the field clear for parbaked's own generator
    (which writes to ``.parbaked/build/``).
    """
    if _fly_app_exists(app_name):
        success(f"fly app `{app_name}` already exists")
        return

    info(f"Claiming fly app `{app_name}`…")
    rc = subprocess.run(
        ["fly", "apps", "create", "--name", app_name],
        check=False,
    ).returncode
    if rc != 0:
        error("fly apps create failed — see above for fly's output.")
        raise typer.Exit(1)
    success(f"fly app `{app_name}` claimed")


_PROD_SECRETS_ALL = ("jwt_secret", "approval_token_secret", "admin_password")
# In email mode (#130) the admin password is dead weight — the sign-in
# magic link from the admin inbox is the credential. Don't push the
# auto-generated dev password to fly secrets in that case; an env var
# whose value is never read just clutters the secrets list and
# misleads anyone diagnosing later.
_PROD_SECRETS_EMAIL_MODE = ("jwt_secret", "approval_token_secret")


def _select_prod_secrets() -> tuple[str, ...]:
    """Return the secret keys to push, dropping ``admin_password`` in email mode.

    Mode gate is exclusively ``admin_email`` — not ``email_enabled``.
    ``email_enabled`` is True whenever any transport is configured (e.g.
    a project sets ``resend_key`` for user-verification mail without
    setting ``admin_email`` — those still use the password gate). Devin
    Review on #180 caught this.
    """
    from parbaked.config import ParbakedConfig

    try:
        config = ParbakedConfig()
    except Exception:  # noqa: BLE001 — config errors elsewhere will surface louder
        return _PROD_SECRETS_ALL
    if bool(config.admin_email):
        return _PROD_SECRETS_EMAIL_MODE
    return _PROD_SECRETS_ALL


def _parse_env_keys(env_text: str) -> set[str]:
    """Extract KEY names from a ``.env``-style payload.

    Lenient on purpose: skips blank lines, ``#`` comments, and lines with
    no ``=``. Doesn't try to validate values — we only care which keys
    the user already supplied so we know which parbaked-required keys to
    top up.
    """
    keys: set[str] = set()
    for raw in env_text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key = line.split("=", 1)[0].strip()
        # ``export FOO=bar`` is valid in some .env dialects.
        if key.startswith("export "):
            key = key[len("export "):].strip()
        if key:
            keys.add(key)
    return keys


def _push_secrets_via_stdin(
    app_name: str, pair_tuples: list[tuple[str, str]]
) -> int:
    """Push ``KEY=VALUE`` pairs to fly secrets via stdin, never argv.

    Values on argv leak via ``/proc/<pid>/cmdline`` and ``ps``; #135
    pinned the contract that this codepath always uses stdin. Returns
    the fly CLI's exit code (or 130 on Ctrl-C).
    """
    with tempfile.NamedTemporaryFile("w", delete=False) as fh:
        for env_name, value in pair_tuples:
            fh.write(f"{env_name}={value}\n")
        tempfile_path = fh.name

    try:
        with open(tempfile_path, "rb") as fh:
            rc = subprocess.run(
                ["fly", "secrets", "import", "--app", app_name],
                stdin=fh,
                check=False,
            ).returncode
    except KeyboardInterrupt:
        rc = 130
    finally:
        Path(tempfile_path).unlink(missing_ok=True)
    return rc


def _persist_generated_secrets(
    pj: Path, stored: dict, freshly_generated: dict[str, str]
) -> None:
    """Write freshly-generated wizard secrets to ``.parbaked.json`` (#284).

    Merges into any pre-existing ``.parbaked.json`` contents (``stored``)
    rather than clobbering: a user who's been running ``parbaked dev``
    locally already has dev-side secrets there, and we want the wizard
    to add to that file, not overwrite it. ``stored`` is the same dict
    the caller already read; we extend it with the new values.

    chmod 600 mirrors what ``ParbakedApp._save_secrets`` does for the
    dev-mode path. On Windows POSIX mode bits are largely a no-op
    (the file may remain readable by other users on the box) so we
    surface the same one-shot warning the app-side path does (#194).

    Prints a "✓ Secrets written to .parbaked.json" footer with the
    generated admin password (when one was minted) so the operator can
    log in to /auth/admin without ``fly ssh``. JWT/approval-token
    values aren't echoed — they're machine-only, the operator never
    reads them.
    """
    merged = {**stored, **freshly_generated}
    try:
        pj.write_text(json.dumps(merged, indent=2) + "\n")
    except OSError as exc:
        warn(
            f"Could not write {pj}: {exc}. The admin password lives only "
            "in fly secrets — recover it with `fly ssh console -C "
            "'parbaked admin signin'`."
        )
        return
    with contextlib.suppress(OSError):
        os.chmod(pj, 0o600)
    if sys.platform == "win32":
        # Same trip-wire app.py emits on dev-mode boots — chmod 600 is a
        # no-op on Windows, so a .parbaked.json on a shared machine may
        # be readable by other users.
        logging.getLogger("parbaked").warning(
            "Secrets cached at %s — Windows ACLs are not set, so the "
            "file may be readable by other users on this machine. "
            "Consider setting PARBAKED_* secrets as env vars and "
            "deleting %s.",
            pj,
            pj,
        )
    success(f"Secrets written to {pj} (chmod 600). Keep this file safe.")
    admin_password = freshly_generated.get("admin_password")
    if admin_password:
        # markup=False + highlight=False render the value verbatim so
        # rich doesn't recolour or reformat it — operator should be able
        # to copy-paste straight into the /auth/admin login form.
        console.print(
            f"  Admin password: {admin_password}",
            markup=False,
            highlight=False,
        )


def _step_push_secrets(app_name: str) -> None:
    """Push the parbaked secrets to fly so the prod-safety check passes.

    Production-mode safety (#40) refuses to boot when any required
    secret was auto-generated on the machine. The wizard generates the
    fly.toml with ``PARBAKED_ENV=production``, so without these secrets
    the deploy crashes on boot — caught on real-fly e2e.

    Sources, in priority order:

    1. ``.env`` at project root — if present, ``fly secrets import``-ed
       verbatim. Common case is a partial ``.env`` (e.g. just
       ``PARBAKED_ADMIN_EMAIL``) copied from ``.env.example``.
    2. **Top-up** for any parbaked-required key the ``.env`` didn't
       provide: pull from ``.parbaked.json`` (auto-generated dev
       secrets from previous local ``parbaked dev`` runs) if present,
       otherwise generate a fresh ``token_urlsafe(32)``. The top-up is
       pushed in a separate ``fly secrets import`` call via stdin (#135),
       NOT merged into the user's ``.env`` on disk.
    3. If no ``.env`` at all, source the full required set from
       ``.parbaked.json`` / freshly-generated values.

    Without step 2, a ``.env`` containing only ``PARBAKED_ADMIN_EMAIL``
    (which the docs explicitly recommend) shipped an app that refused
    to boot — see #236.

    Email mode (``PARBAKED_ADMIN_EMAIL`` set) skips
    ``PARBAKED_ADMIN_PASSWORD`` entirely — the admin sign-in path uses
    a magic link to the configured inbox, the shared password is never
    read at login. See #130.

    Persistence (#284): any parbaked secret that's freshly generated by
    this run (i.e. neither in ``.env`` nor in ``.parbaked.json``) is
    written to ``.parbaked.json`` (chmod 600) AFTER the fly push
    succeeds. Without this, the operator has no way to read the admin
    password short of ``fly ssh`` — the post-deploy banner points at
    ``/auth/admin`` but the password the wizard just minted lives
    nowhere on the local box. ``.env``-sourced values are NOT mirrored
    here (the user already has them in ``.env``; mirroring would
    duplicate the secret across two on-disk locations).
    """
    required_keys = _select_prod_secrets()
    required_env_names = {f"PARBAKED_{k.upper()}" for k in required_keys}

    env_file = Path(".env")
    env_keys: set[str] = set()
    if env_file.exists():
        info(f"Pushing {env_file} to fly secrets…")
        try:
            env_text = env_file.read_text()
        except OSError:
            env_text = ""
        env_keys = _parse_env_keys(env_text)
        try:
            with env_file.open("rb") as fh:
                rc = subprocess.run(
                    ["fly", "secrets", "import", "--app", app_name],
                    stdin=fh,
                    check=False,
                ).returncode
        except KeyboardInterrupt:
            rc = 130
        if rc != 0:
            warn("fly secrets import failed — continuing without it.")
            return
        success("secrets pushed from .env")

    # Identify the parbaked-required secrets the .env didn't provide.
    # When no .env was pushed above, ``env_keys`` is empty and this set
    # equals the full required set — same behaviour as the old
    # generate-from-scratch path.
    missing_env_names = required_env_names - env_keys
    if not missing_env_names:
        return

    pj = Path(".parbaked.json")
    stored: dict = {}
    if pj.exists():
        try:
            stored = json.loads(pj.read_text())
        except (OSError, json.JSONDecodeError):
            stored = {}

    pair_tuples: list[tuple[str, str]] = []
    freshly_generated: dict[str, str] = {}
    # Preserve the canonical required-key order so the on-the-wire
    # payload is deterministic — easier to reason about in tests and in
    # ``fly secrets list`` output.
    for key in required_keys:
        env_name = f"PARBAKED_{key.upper()}"
        if env_name not in missing_env_names:
            continue
        cached_value = stored.get(key)
        if cached_value:
            value = cached_value
        else:
            value = secrets.token_urlsafe(32)
            freshly_generated[key] = value
        pair_tuples.append((env_name, value))

    if env_file.exists():
        info(
            "Topping up missing parbaked secrets "
            f"({', '.join(name for name, _ in pair_tuples)})…"
        )
    else:
        info("Pushing parbaked secrets to fly secrets…")

    rc = _push_secrets_via_stdin(app_name, pair_tuples)
    if rc != 0:
        warn(
            "fly secrets import failed — the deploy will fail prod-safety "
            "boot check. Set manually with `fly secrets set PARBAKED_JWT_SECRET=...`"
        )
        return
    success(f"secrets pushed ({', '.join(name for name, _ in pair_tuples)})")

    # Persist any freshly-generated values to .parbaked.json so the
    # operator can read them back later (the admin password being the
    # interesting one — the wizard's post-deploy banner directs them at
    # /auth/admin and they need a credential to log in). See #284.
    if freshly_generated:
        _persist_generated_secrets(pj, stored, freshly_generated)


def _step_deploy(app_name: str) -> None:
    """Hand off to the regular `parbaked deploy` code path."""
    info("Deploying… (this can take a couple of minutes)")
    from parbaked.cli.ops import deploy
    try:
        deploy()
    except typer.Exit as exc:
        if exc.exit_code != 0:
            raise


def _print_post_deploy_banner(app_name: str) -> None:
    """Show the post-deploy summary as a rich Panel.

    The pre-rich version was a hand-drawn ``─`` rule above and below five
    plaintext lines. A Panel is the rich equivalent — same boxed shape,
    plus titled border + cyan URL highlighting that matches the rest of
    the CLI's house style.
    """
    from rich.panel import Panel

    url = f"https://{app_name}.fly.dev"
    body = (
        f"  Live at:  [cyan]{url}[/cyan]\n"
        f"  Admin:    [cyan]{url}/auth/admin[/cyan]\n"
        f"  Sign up:  POST [cyan]{url}/auth/signup[/cyan]\n"
        "\n"
        "  Tail logs:    [bold]parbaked logs[/bold]\n"
        "  Re-deploy:    [bold]parbaked deploy[/bold]"
    )
    console.print("")
    console.print(Panel(body, title="Deployed", border_style="green"))


def run_wizard(
    app_name: str,
    *,
    open_browser: bool = False,
) -> None:
    """Drive the full first-run flow. Caches state on success.

    Raises ``typer.Exit`` with a non-zero code on any failure step;
    the calling CLI command should propagate that exit code.
    """
    info("Setting up your first fly.io deploy…")
    info("")
    _step_install_flyctl()
    _step_login()
    _step_launch(app_name)
    _step_push_secrets(app_name)

    # Persist ``fly_app_name`` BEFORE the deploy step — ``_step_deploy``
    # invokes ``parbaked deploy`` → ``deploy_gen.generate()``, which
    # reads ``load_state().get("fly_app_name")`` to write the right
    # ``app =`` into the generated fly.toml. Without this, the first
    # deploy regenerates fly.toml with the *unsuffixed* config app_name
    # and ``fly deploy`` targets a non-existent app. See PR #127
    # discussion. ``first_deploy_at`` is set only on success below so
    # ``already_onboarded()`` doesn't lie about a failed first run.
    _save_state({"fly_app_name": app_name})

    _step_deploy(app_name)

    _save_state({
        "fly_app_name": app_name,
        "first_deploy_at": datetime.now(UTC).isoformat(),
    })
    _print_post_deploy_banner(app_name)
    if open_browser:
        with contextlib.suppress(Exception):
            webbrowser.open(f"https://{app_name}.fly.dev")
