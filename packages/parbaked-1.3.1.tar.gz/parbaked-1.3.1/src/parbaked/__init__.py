"""parbaked — a par-baked starter for PoC apps.

The public surface is the kernel runtime::

    from parbaked import create_app, current_user, get_session, ParbakedConfig

``create_app()`` builds the kernel-runtime FastAPI app (auto-discovers
``routes/``, wires auth + admin + DB + migrations). ``current_user``
is the FastAPI dependency for gating routes on a signed-in active
user. ``get_session`` is the FastAPI dependency for opening a SQLModel
session against parbaked's database — use it in consumer routes that
read or write tables. ``ParbakedConfig`` is the pydantic-settings
object that reads ``parbaked.toml`` + ``PARBAKED_*`` env vars.

There is no embed mode. Existing FastAPI apps adopt the parbaked
shape (routes in ``routes/``, models in ``models.py``, config in
``parbaked.toml``) — see the migration guide in the README.

There are three API tiers (see ``AGENTS.md`` → "Public API surface"
and "Testing-only surface", and ``docs/data-format-guarantees.md``):

1. **Public** — the symbols re-exported here and listed in ``__all__``.
   Stable; breaking changes require a major-version bump + CHANGELOG
   recipe.
2. **Test API (stable but undocumented at the application level)** —
   ``parbaked.app.Parbaked`` (the class behind ``create_app()``; tests
   construct it directly to pass per-test ``secrets_file`` /
   ``database_url``) and ``parbaked.auth.models.SchemaVersion`` (the
   single-row migration marker; tests read it to assert migrations
   applied; ``parbaked.eject`` exports it as part of the off-boarding
   archive). Listed in ``__test_api__`` below. Won't break without a
   CHANGELOG note, but application code should use ``create_app()``.
3. **Internal** — every other module. May change without notice.
"""

__version__ = "1.3.1"

from fastapi import BackgroundTasks

from parbaked.auth.models import User, UserStatus
from parbaked.config import ParbakedConfig
from parbaked.eject import eject
from parbaked.exceptions import (
    ParbakedConfigError,
    ParbakedDeployError,
    ParbakedError,
)
from parbaked.runtime import create_app, current_user, get_session
from parbaked.webhook import verify_hmac, webhook

__all__ = [
    "BackgroundTasks",
    "ParbakedConfig",
    "ParbakedConfigError",
    "ParbakedDeployError",
    "ParbakedError",
    "User",
    "UserStatus",
    "create_app",
    "current_user",
    "eject",
    "get_session",
    "verify_hmac",
    "webhook",
]

#: Dotted paths to the **Test API** — stable for tests, but **not** part
#: of the application public surface. See the module docstring above for
#: the full three-tier contract. Listed (not re-exported) so the boundary
#: stays explicit: tests import from these paths directly.
__test_api__ = (
    "parbaked.app.Parbaked",
    "parbaked.auth.models.SchemaVersion",
)
