"""SQLModel definitions for parbaked's auth tables.

parbaked owns the ``users`` table. Consumers wanting per-user app data should
add a related table keyed on ``users.id`` rather than extending this model —
SQLModel ``table=True`` subclassing is awkward.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum
from uuid import UUID, uuid4

from sqlmodel import Field, SQLModel


class UserStatus(StrEnum):
    """Admin-approval state for a parbaked account.

    Independent of email verification: a user has both a ``status`` (this enum)
    and an ``email_verified`` flag. They can only log in when status==active.
    The admin only sees the signup *after* the user has verified their email.
    """

    pending = "pending"  # signed up, awaiting admin approval
    active = "active"    # approved, can log in
    rejected = "rejected"  # admin rejected — cannot log in


def _utcnow() -> datetime:
    return datetime.now(UTC)


class User(SQLModel, table=True):
    __tablename__ = "users"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    email: str = Field(unique=True, index=True, max_length=255)
    name: str = Field(max_length=255)
    password_hash: str
    status: UserStatus = Field(default=UserStatus.pending)
    email_verified_at: datetime | None = Field(
        default=None,
        description=(
            "When the user proved they own this email (clicked the verification "
            "link). Until then they're invisible to the admin queue."
        ),
    )
    created_at: datetime = Field(default_factory=_utcnow)
    approved_at: datetime | None = None
    revoked_at: datetime | None = Field(
        default=None,
        description=(
            "When the user's existing sessions were invalidated. Any JWT "
            "issued at or before this timestamp is rejected by current_user. "
            "Set by: admin reject (dashboard + magic-link), password reset "
            "success. Not the same as ``status == rejected`` — that blocks "
            "*new* logins; this kills *existing* sessions immediately."
        ),
    )

class SchemaVersion(SQLModel, table=True):
    """One-row table that records the highest applied migration index (#10).

    Read on every boot by :func:`parbaked.migrations.apply_migrations` —
    cheap enough that the alternative (storing it in ``.parbaked.json`` or
    a pragma) wasn't worth the divergence from the rest of the data model.
    """

    __tablename__ = "_parbaked_schema_version"

    id: int = Field(default=1, primary_key=True)
    version: int = Field(default=0)


class AdminSigninNonce(SQLModel, table=True):
    """One-row table holding the current admin-signin magic-link nonce (#205).

    The nonce is embedded in every ``parbaked-admin-signin`` JWT minted by
    :func:`parbaked.auth.tokens.create_admin_signin_token`. On a successful
    :func:`parbaked.auth.tokens.verify_admin_signin_token` call the row's
    ``nonce`` is rotated to a fresh random value — that single rotation
    invalidates the just-used token AND any other outstanding signin links
    that were minted off the same prior nonce.

    Effect: the magic link is genuinely one-shot. Replay attempts within
    the 15-minute TTL fail because the embedded ``nonce`` claim no longer
    matches the row. Same defence-in-depth as the password-reset link's
    ``_hash_fingerprint`` binding, but per-admin (parbaked has exactly
    one admin) rather than per-user.
    """

    __tablename__ = "_parbaked_admin_signin_nonce"

    id: int = Field(default=1, primary_key=True)
    nonce: str = Field(max_length=64)
