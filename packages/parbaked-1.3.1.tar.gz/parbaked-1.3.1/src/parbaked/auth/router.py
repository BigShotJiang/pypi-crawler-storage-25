"""FastAPI router builder: signup, verify, login, approve, reject, me."""

from __future__ import annotations

import logging
from collections.abc import Callable
from html import escape as _esc

from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    Form,
    Request,
    Response,
    status,
)
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, EmailStr, Field, computed_field, field_validator
from slowapi import Limiter
from sqlmodel import Session

from parbaked._clientip import client_ip
from parbaked._form_css import _FORM_CSS
from parbaked.auth.deps import make_current_user
from parbaked.auth.models import User, UserStatus
from parbaked.auth.service import (
    EmailChangeCompleteOutcome,
    EmailChangeOutcome,
    ResetOutcome,
    VerifyOutcome,
    approve_user,
    authenticate_user,
    complete_email_change,
    complete_password_reset,
    delete_user,
    reject_user,
    request_email_change,
    request_password_reset,
    signup_user,
    user_from_unverified_token,
    verify_email,
)
from parbaked.auth.tokens import (
    InvalidApprovalToken,
    InvalidPasswordResetToken,
    verify_approval_token,
    verify_password_reset_token,
)
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.templates import Templates
from parbaked.hooks import Hooks

logger = logging.getLogger("parbaked.auth")


# bcrypt silently truncates input past 72 bytes — a user typing a 100-char
# passphrase would only have the first 72 bytes hashed, so the remaining
# entropy is wasted and any prefix-match passphrase logs in. We reject up
# front rather than pre-hashing with SHA-256, because the upper bound is
# unambiguous and avoids quietly changing the hashing pipeline (#167). The
# signup path enforces this inside ``signup_user``; the reset-submit form
# still does its own check below because it surfaces a different UX (a
# 422 HTML re-render of the form rather than a JSON error).
_BCRYPT_MAX_BYTES = 72


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------


class SignupRequest(BaseModel):
    # RFC 5321 caps the full email address at 254 chars (#191). Without the
    # explicit max_length we'd happily accept multi-kilobyte addresses that
    # later choke on DB inserts or downstream email APIs.
    email: EmailStr = Field(max_length=254)
    name: str = Field(min_length=1, max_length=255)
    password: str = Field(min_length=8, max_length=128)

    @field_validator("name")
    @classmethod
    def _name_not_whitespace(cls, v: str) -> str:
        # Strip first, then re-check length. A signup with name="   " would
        # otherwise create an active account whose display name is three
        # spaces — invisible in the UI and a free phishing footprint (#191).
        stripped = v.strip()
        if not stripped:
            raise ValueError("name must not be empty or whitespace-only")
        # Reject embedded newlines and other control characters (#212). A name
        # like "Sam\nAdmin: type help" passes the basic length/empty checks but
        # garbles every plain-text email body that interpolates {user.name}
        # (the Mail.app reader sees a fake second line). HTML output is
        # _esc()'d so it's visually safe, but the plain-text rendering of
        # ``Hi {user.name},`` is broken on every client. A custom SMTP
        # transport would also be CRLF-injectable via the subject line.
        # Tab and ordinary space are the only whitespace we keep — names like
        # "von der Leyen" must still work, and a tab in display names is
        # unusual but not a vector. Everything else (newlines, NUL bytes,
        # NEL (\x85), Unicode line/paragraph separators, etc.) is out.
        for ch in stripped:
            if ch in " \t":
                continue
            cp = ord(ch)
            # ASCII control characters (C0 + DEL) + C1 controls (\x80-\x9f)
            # + any other whitespace (vertical tab, form feed, line separators).
            if cp < 0x20 or cp == 0x7f or 0x80 <= cp <= 0x9f or ch.isspace():
                raise ValueError(
                    "name must not contain newlines or control characters"
                )
        return stripped


class SignupResponse(BaseModel):
    user_id: str
    status: UserStatus
    # ``email_sent`` reflects whether the deployment is in email-mode
    # (``config.email_enabled``), NOT whether the transport actually
    # succeeded. The previous "true return of _safe_send" semantics (#88)
    # leaked enumeration: a broken Resend key meant fresh signups
    # returned False while duplicates returned True, letting an attacker
    # distinguish known-vs-unknown emails by probing one fresh address
    # to confirm the transport is broken (#179).
    #
    # Actual transport failures are still logged in the audit event
    # (``extra={'email_sent': ..., 'email_enabled': ...}``) and surface
    # as a warning in the server logs — the admin sees them, the
    # attacker doesn't.
    email_sent: bool = True


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class UserPublic(BaseModel):
    id: str
    email: EmailStr
    name: str
    status: UserStatus


class LoginResponse(BaseModel):
    # OAuth 2.0 (RFC 6749, §5.1) access-token response shape (#358). Every
    # OAuth2-shaped client library (httpx-oauth, authlib, requests-oauthlib,
    # fastapi-users' OAuth2PasswordBearer, …) keys off ``access_token`` —
    # the prior non-standard ``token`` field broke them on first try. The
    # token IS used as a Bearer credential (``Authorization: Bearer <…>``),
    # so the rename matches actual semantics. ``expires_in`` is reported in
    # seconds and is derived from ``config.jwt_expiry_days`` so consumers
    # don't have to introspect the JWT ``exp`` claim to schedule a refresh.
    access_token: str
    token_type: str = "Bearer"
    expires_in: int
    user: UserPublic

    # Deprecated alias (#366). v1.3.0a7's #358 swap was implemented as a
    # hard rename rather than the Option-B non-breaking alias the issue
    # asked for — every consumer reading ``data.token`` (parbaked's own
    # pre-a7 starter, fairshare, fairshare2, …) silently broke on
    # upgrade: login returned 200, ``data.token`` was undefined, no
    # session established. We re-expose ``token`` as a serialiser-only
    # mirror of ``access_token`` so the old code paths keep working; new
    # consumers should read ``access_token`` (OAuth2-conformant). The
    # alias is scheduled for removal in parbaked 1.4.0.
    @computed_field  # type: ignore[prop-decorator]
    @property
    def token(self) -> str:
        """Deprecated: use ``access_token``. Removed in parbaked 1.4.0."""
        return self.access_token


class ChangeEmailRequest(BaseModel):
    """Body for ``POST /auth/me/email`` (#275).

    Validates the address format + length up-front so the service layer
    never sees a bad shape. Same 254-char cap as signup / forgot-password
    so an attacker can't slip a multi-KB address past the endpoint.
    """

    new_email: EmailStr = Field(max_length=254)


class ChangeEmailResponse(BaseModel):
    """Response for ``POST /auth/me/email`` (#275).

    Returned with status 202 — the change isn't applied until the user
    clicks the verify link sent to the new address.
    """

    status: str = "verify_sent"
    new_email: EmailStr


class ForgotPasswordRequest(BaseModel):
    # Mirror the signup-side cap so an attacker can't slip a multi-KB address
    # past forgot-password to probe rate limits or send-side cost (#191).
    email: EmailStr = Field(max_length=254)


class ForgotPasswordResponse(BaseModel):
    status: str = "ok"
    # In dashboard-only mode (#74) the user must ask the app admin for
    # a reset link out-of-band — parbaked has no way to email them.
    # The boolean lets the front-end show an honest message instead of
    # the default "check your inbox" copy.
    email_enabled: bool = True


class ErrorResponse(BaseModel):
    """OpenAPI shape for FastAPI's :class:`HTTPException` default body (#186).

    Every parbaked auth route that raises ``HTTPException`` returns a
    body of the form ``{"detail": "..."}`` — this schema documents that
    so OpenAPI consumers (Stoplight, swagger-codegen, the FastAPI Swagger
    UI itself) generate accurate clients instead of treating error
    branches as untyped.
    """

    detail: str


# Re-used in ``responses=`` blocks below. Centralised so the per-route
# declarations stay terse and the prose lives in one place.
_RATE_LIMIT_RESPONSE = {
    "description": "Rate limit exceeded. See the X-RateLimit-* headers.",
    "model": ErrorResponse,
}
_UNAUTHORIZED_RESPONSE = {
    "description": "Missing or invalid credentials / bearer token.",
    "model": ErrorResponse,
}
_FORBIDDEN_RESPONSE = {
    "description": "Authenticated but the account is not eligible.",
    "model": ErrorResponse,
}
_RESET_FORM_HTML = (
    """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Reset your password</title>
<style>
"""
    + _FORM_CSS
    + """
</style>
</head>
<body>
  <form method="post" action="{action}" class="card">
    <h1>Choose a new password</h1>
    <p class="sub">For {email}</p>
    {error_html}
    <label for="password">New password</label>
    <input id="password" name="password" type="password" autofocus required minlength="8">
    <label for="confirm">Confirm password</label>
    <input id="confirm" name="confirm" type="password" required minlength="8">
    <button type="submit">Set new password</button>
  </form>
</body>
</html>
"""
)


def _render_reset_form(action_url: str, email: str, error: str | None = None) -> str:
    error_html = f'<p class="err">{_esc(error)}</p>' if error else ""
    return _RESET_FORM_HTML.format(
        action=_esc(action_url, quote=True),
        email=_esc(email),
        error_html=error_html,
    )


# ---------------------------------------------------------------------------
# Confirmation pages (admin click-through)
# ---------------------------------------------------------------------------

# Confirmation pages (verify-email, admin-approve, password-updated,
# email-change) share the starter's visual tokens — same system-ui font,
# same ``#111`` body text, same ``#b00`` red — wrapped in the same
# card-on-``#f6f7f9`` layout as ``_FORM_CSS`` so the inbox-click handoff
# is visually seamless (#294). ``.ok`` / ``.nope`` keep semantic green /
# red on the heading itself because these pages are *all* status pages
# and the colour-as-feedback is the point. The starter ``.err`` red
# (``#b00``) is reused for ``.nope`` so the two reds match across the
# kernel surface.
_PAGE_SHELL = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{title}</title>
<style>
  body {{ font-family: system-ui, -apple-system, sans-serif;
          background: #f6f7f9; color: #111; margin: 0; padding: 0;
          min-height: 100vh; display: flex; align-items: center;
          justify-content: center; line-height: 1.5; }}
  .card {{ background: white; padding: 32px; border-radius: 8px;
           border: 1px solid #e5e7eb; max-width: 24rem; width: 100%;
           box-sizing: border-box; }}
  h1 {{ font-size: 1.5rem; margin: 0 0 0.5rem 0; }}
  p  {{ margin: 0; color: #555; }}
  .ok    {{ color: #166534; }}
  .nope  {{ color: #b00; }}
</style>
</head>
<body>
  <div class="card">
    <h1 class="{cls}">{heading}</h1>
    <p>{body}</p>
  </div>
</body>
</html>
"""


def _ok_page(heading: str, body: str) -> HTMLResponse:
    """Render the success confirmation page.

    Both ``heading`` and ``body`` are HTML-escaped here so callers can pass
    raw user data (user.email, user.name) without thinking about injection.
    Anyone wanting actual markup must build their own response.
    """
    return HTMLResponse(
        _PAGE_SHELL.format(
            title=_esc(heading),
            heading=_esc(heading),
            body=_esc(body),
            cls="ok",
        )
    )


def _err_page(heading: str, body: str, status_code: int = 400) -> HTMLResponse:
    """Render the error page. Same escaping contract as :func:`_ok_page`."""
    return HTMLResponse(
        _PAGE_SHELL.format(
            title=_esc(heading),
            heading=_esc(heading),
            body=_esc(body),
            cls="nope",
        ),
        status_code=status_code,
    )


# ``user_from_unverified_token`` was lifted into ``parbaked.auth.service``
# alongside the reset orchestration (#227). Re-exported here under the old
# private name so external callers (if any) keep working; the GET reset_form
# below uses the imported name directly.


# ---------------------------------------------------------------------------
# Router builder
# ---------------------------------------------------------------------------


def build_auth_router(
    config: ParbakedConfig,
    get_session: Callable[..., Session],
    email: EmailTransport,
    *,
    limiter: Limiter | None = None,
    templates: Templates | None = None,
    hooks: Hooks | None = None,
    prefix: str = "/auth",
    tags: list[str] | None = None,
) -> APIRouter:
    """Construct the signup/login/approval router.

    Args:
        config: parbaked settings (secrets, branding, rate limits).
        get_session: FastAPI dependency yielding a SQLModel ``Session``. parbaked
            calls this via ``Depends`` — supply the same one you use elsewhere.
        email: any object implementing :class:`EmailTransport`. Use
            :class:`ConsoleEmail` for dev and tests.
        limiter: optional slowapi ``Limiter``. If omitted, rate limiting is OFF
            on these routes — fine for tests but DO NOT ship to production
            without it. Pair with :func:`install_rate_limiting`.
        templates: override the email body renderers if you want custom copy.
        prefix: URL prefix. Default ``/auth``.
        tags: OpenAPI tags. Default ``["auth"]``.
    """
    templates = templates or Templates()
    hooks = hooks or Hooks()
    current_user = make_current_user(config, get_session)
    router = APIRouter(prefix=prefix, tags=tags or ["auth"])

    # slowapi requires the decorator at definition time, so we resolve to a
    # no-op when no limiter is provided.
    def _limit(rule: str) -> Callable[[Callable], Callable]:
        if limiter is None:
            return lambda f: f
        return limiter.limit(rule)

    # ----- signup ----------------------------------------------------
    # Signup intentionally does NOT declare a 409 response: the duplicate-
    # email branch returns the same 201 + SignupResponse shape as a fresh
    # signup so the API doesn't enumerate existing accounts (#179).
    @router.post(
        "/signup",
        response_model=SignupResponse,
        status_code=status.HTTP_201_CREATED,
        responses={
            status.HTTP_429_TOO_MANY_REQUESTS: _RATE_LIMIT_RESPONSE,
        },
    )
    @_limit(config.ratelimit_signup)
    def signup(
        request: Request,
        response: Response,  # noqa: ARG001 — slowapi injects rate-limit headers
        body: SignupRequest,
        background_tasks: BackgroundTasks,
        session: Session = Depends(get_session),
    ) -> SignupResponse:
        user, reported_status, email_sent, send_verify_email = signup_user(
            body.email, body.name, body.password,
            session=session, config=config, email_transport=email,
            templates=templates, hooks=hooks,
            verify_url_prefix=prefix,
            ip=client_ip(request, config),
        )
        # HTTP path backgrounds the verify-email dispatch so the response
        # returns before the ~200-500ms Resend HTTP call completes. The
        # duplicate-email branch returns ``send_verify_email=None`` (we
        # never re-mail an existing user — see #261 item 2 / #179). CLI
        # and MCP callers don't need ``BackgroundTasks`` to invoke the
        # service; they can run the callable synchronously.
        if send_verify_email is not None:
            background_tasks.add_task(send_verify_email)
        return SignupResponse(
            user_id=str(user.id),
            status=reported_status,
            email_sent=email_sent,
        )

    # ----- verify email ---------------------------------------------
    @router.get("/verify/{token}", response_class=HTMLResponse)
    def verify(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        outcome, user = verify_email(
            token,
            session=session, config=config, email_transport=email,
            templates=templates, hooks=hooks,
            approval_url_prefix=prefix,
            ip=client_ip(request, config),
        )
        if outcome is VerifyOutcome.invalid_token:
            return _err_page(
                "Link invalid or expired",
                "Sign up again to receive a fresh verification link.",
                status_code=400,
            )
        if outcome is VerifyOutcome.user_not_found:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        # Service contract: ``verified`` and ``already_verified`` outcomes
        # always carry a non-None user. Use an explicit guard instead of
        # ``assert`` so this isn't stripped under ``python -O`` (#261 item 3).
        if user is None:
            raise RuntimeError(
                f"verify_email returned {outcome!r} without a user — service contract violated"
            )
        if outcome is VerifyOutcome.already_verified:
            return _ok_page(
                "Already verified", f"{user.email} is already verified — awaiting approval."
            )
        return _ok_page(
            "Email verified",
            f"Thanks, {user.name}. {user.email} is confirmed — an admin will "
            "approve your account shortly.",
        )

    # ----- login -----------------------------------------------------
    @router.post(
        "/login",
        response_model=LoginResponse,
        responses={
            status.HTTP_401_UNAUTHORIZED: _UNAUTHORIZED_RESPONSE,
            status.HTTP_403_FORBIDDEN: _FORBIDDEN_RESPONSE,
            status.HTTP_429_TOO_MANY_REQUESTS: _RATE_LIMIT_RESPONSE,
        },
    )
    @_limit(config.ratelimit_login)
    def login(
        request: Request,
        response: Response,  # noqa: ARG001
        body: LoginRequest,
        session: Session = Depends(get_session),
    ) -> LoginResponse:
        token, user = authenticate_user(
            body.email, body.password,
            session=session, config=config,
            ip=client_ip(request, config),
        )
        # ``expires_in`` is reported in seconds per RFC 6749 §5.1; mirrors
        # the ``exp`` claim minted in ``parbaked.auth.jwt`` from the same
        # ``config.jwt_expiry_days`` (#358).
        return LoginResponse(
            access_token=token,
            token_type="Bearer",
            expires_in=config.jwt_expiry_days * 86400,
            user=UserPublic(
                id=str(user.id), email=user.email, name=user.name, status=user.status
            ),
        )

    # ----- approve ---------------------------------------------------
    @router.get("/approve/{token}", response_class=HTMLResponse)
    def approve(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        try:
            user_id, action = verify_approval_token(token, config)
        except InvalidApprovalToken as exc:
            logger.info("approve rejected: %s", exc)
            return _err_page(
                "Link invalid or expired",
                "Use the admin dashboard to approve this signup instead.",
                status_code=400,
            )
        if action != "approve":
            return _err_page("Wrong link", "This link doesn't approve.", status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.status == UserStatus.active:
            return _ok_page("Already approved", f"{user.email} is already active.")

        approve_user(
            user, session,
            config=config, email=email, templates=templates, hooks=hooks,
            via="magic_link", ip=client_ip(request, config),
        )
        return _ok_page("Approved", f"{user.email} can now sign in.")

    # ----- reject ----------------------------------------------------
    @router.get("/reject/{token}", response_class=HTMLResponse)
    def reject(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        try:
            user_id, action = verify_approval_token(token, config)
        except InvalidApprovalToken as exc:
            logger.info("reject rejected: %s", exc)
            return _err_page(
                "Link invalid or expired",
                "Use the admin dashboard to reject this signup instead.",
                status_code=400,
            )
        if action != "reject":
            return _err_page("Wrong link", "This link doesn't reject.", status_code=400)

        user = session.get(User, user_id)
        if user is None:
            return _err_page("User no longer exists", "The signup may have been deleted.", 404)
        if user.status == UserStatus.rejected:
            return _ok_page("Already rejected", f"{user.email} was already rejected.")

        reject_user(
            user, session,
            config=config, email=email, templates=templates, hooks=hooks,
            via="magic_link", ip=client_ip(request, config),
        )
        return _ok_page("Rejected", f"{user.email} has been rejected and notified.")

    # ----- forgot password ------------------------------------------
    @router.post(
        "/forgot-password",
        response_model=ForgotPasswordResponse,
        status_code=status.HTTP_202_ACCEPTED,
        responses={
            status.HTTP_429_TOO_MANY_REQUESTS: _RATE_LIMIT_RESPONSE,
        },
    )
    @_limit(config.ratelimit_password_reset)
    def forgot_password(
        request: Request,
        response: Response,  # noqa: ARG001 — slowapi injects rate-limit headers
        body: ForgotPasswordRequest,
        session: Session = Depends(get_session),
    ) -> ForgotPasswordResponse:
        email_enabled = request_password_reset(
            body.email,
            session=session, config=config, email_transport=email,
            templates=templates,
            reset_url_prefix=prefix,
            ip=client_ip(request, config),
        )
        return ForgotPasswordResponse(email_enabled=email_enabled)

    # ----- reset form (GET) -----------------------------------------
    @router.get("/reset/{token}", response_class=HTMLResponse)
    def reset_form(
        request: Request,  # noqa: ARG001 — kept for symmetry with POST
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        # We need the user to validate the token (the fingerprint check needs
        # their current password_hash). Decode without verification first to
        # extract the subject, then verify against the live hash.
        user = user_from_unverified_token(token, session)
        if user is None:
            return _err_page(
                "Link invalid or expired",
                "Request a new password-reset email and try again.",
                status_code=400,
            )
        try:
            verify_password_reset_token(token, user.password_hash, config)
        except InvalidPasswordResetToken as exc:
            logger.info("password reset rejected: %s", exc)
            return _err_page(
                "Link invalid or expired",
                "Request a new password-reset email and try again.",
                status_code=400,
            )
        return HTMLResponse(_render_reset_form(f"{prefix}/reset/{token}", user.email))

    # ----- reset submit (POST) --------------------------------------
    @router.post("/reset/{token}", response_class=HTMLResponse)
    def reset_submit(
        request: Request,
        token: str,
        password: str = Form(..., min_length=8, max_length=128),
        confirm: str = Form(..., min_length=8, max_length=128),
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        outcome, user = complete_password_reset(
            token, password, confirm,
            session=session, config=config,
            ip=client_ip(request, config),
        )
        if outcome is ResetOutcome.invalid_token:
            return _err_page(
                "Link invalid or expired",
                "Request a new password-reset email and try again.",
                400,
            )
        # Service contract: every non-invalid_token outcome carries a
        # resolved user. Use an explicit guard instead of ``assert`` so
        # this survives ``python -O`` stripping (#261 item 3).
        if user is None:
            raise RuntimeError(
                f"complete_password_reset returned {outcome!r} without a user "
                "— service contract violated"
            )
        if outcome is ResetOutcome.password_mismatch:
            return HTMLResponse(
                _render_reset_form(
                    f"{prefix}/reset/{token}",
                    user.email,
                    error="Passwords didn't match.",
                ),
                status_code=400,
            )
        if outcome is ResetOutcome.password_too_long:
            return HTMLResponse(
                _render_reset_form(
                    f"{prefix}/reset/{token}",
                    user.email,
                    error=f"Password is too long (max {_BCRYPT_MAX_BYTES} bytes).",
                ),
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            )
        return _ok_page(
            "Password updated",
            f"{user.email} can now sign in with the new password.",
        )

    # ----- me --------------------------------------------------------
    @router.get(
        "/me",
        response_model=UserPublic,
        responses={
            status.HTTP_401_UNAUTHORIZED: _UNAUTHORIZED_RESPONSE,
        },
    )
    def me(user: User = Depends(current_user)) -> UserPublic:
        return UserPublic(id=str(user.id), email=user.email, name=user.name, status=user.status)

    # ----- delete me (GDPR Article 17 right-to-erasure, #275) -------
    @router.delete(
        "/me",
        status_code=status.HTTP_204_NO_CONTENT,
        responses={
            status.HTTP_401_UNAUTHORIZED: _UNAUTHORIZED_RESPONSE,
        },
    )
    def delete_me(
        request: Request,
        user: User = Depends(current_user),
        session: Session = Depends(get_session),
    ) -> Response:
        delete_user(
            user,
            session=session,
            config=config,
            hooks=hooks,
            ip=client_ip(request, config),
        )
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    # ----- change me/email (GDPR Article 16 rectification, #275) ----
    @router.post(
        "/me/email",
        response_model=ChangeEmailResponse,
        status_code=status.HTTP_202_ACCEPTED,
        responses={
            status.HTTP_400_BAD_REQUEST: {
                "description": "new_email matches the user's current email — no change needed.",
                "model": ErrorResponse,
            },
            status.HTTP_401_UNAUTHORIZED: _UNAUTHORIZED_RESPONSE,
            status.HTTP_409_CONFLICT: {
                "description": (
                    "Another user already owns this email, OR the deployment "
                    "is in dashboard-only / no-email mode and the verify-new-"
                    "inbox round-trip can't be completed (#305) — the admin "
                    "must rotate the email via the ``parbaked users`` CLI or "
                    "by editing the row directly."
                ),
                "model": ErrorResponse,
            },
        },
    )
    def change_email(
        request: Request,
        response: Response,  # noqa: ARG001 — slowapi compatibility (rate limit hooks)
        body: ChangeEmailRequest,
        background_tasks: BackgroundTasks,
        user: User = Depends(current_user),
        session: Session = Depends(get_session),
    ) -> ChangeEmailResponse:
        # FastAPI raises HTTPException directly so the OpenAPI 409 / 400
        # branches are reachable from the schema.
        from fastapi import HTTPException

        outcome, send_verify = request_email_change(
            user, body.new_email,
            session=session, config=config,
            email_transport=email, templates=templates,
            change_url_prefix=prefix,
            ip=client_ip(request, config),
        )
        if outcome is EmailChangeOutcome.email_disabled:
            # Pre-#305 this path returned ``status: verify_sent`` even
            # though no transport existed to send the verify-new-inbox
            # email through. See EmailChangeOutcome.email_disabled for
            # why there's no honest fallback.
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Email change requires email mode; this deployment is "
                    "running dashboard-only. Ask your admin to rotate the "
                    "email via the ``parbaked users`` CLI or by editing the "
                    "row directly."
                ),
            )
        if outcome is EmailChangeOutcome.same_email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="That's already your email.",
            )
        if outcome is EmailChangeOutcome.conflict:
            # Same shape as signup's duplicate-email defence isn't appropriate
            # here: the user is already authenticated, so there's no
            # enumeration risk — they'd see a 409 from the unique constraint
            # eventually anyway. Surface it cleanly.
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="That email is already in use.",
            )
        # outcome is EmailChangeOutcome.sent — dispatch the verify email
        # via BackgroundTasks so the 202 returns before the Resend HTTP
        # call (same pattern as the signup verify dispatch, #261 item 2).
        if send_verify is not None:
            background_tasks.add_task(send_verify)
        return ChangeEmailResponse(new_email=body.new_email)

    # ----- verify email-change (#275) ------------------------------
    @router.get("/me/email/verify/{token}", response_class=HTMLResponse)
    def verify_email_change(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> HTMLResponse:
        outcome, user = complete_email_change(
            token,
            session=session, config=config,
            email_transport=email, templates=templates,
            ip=client_ip(request, config),
        )
        if outcome is EmailChangeCompleteOutcome.invalid_token:
            return _err_page(
                "Link invalid or expired",
                "Request a new email-change verification and try again.",
                status_code=400,
            )
        if outcome is EmailChangeCompleteOutcome.user_not_found:
            return _err_page(
                "User no longer exists",
                "The account may have been deleted.",
                status_code=404,
            )
        # Service contract: changed / already_completed / conflict
        # always carry a non-None user. Guard with an explicit check
        # instead of an assert that ``python -O`` would strip (#261 item 3).
        if user is None:
            raise RuntimeError(
                f"complete_email_change returned {outcome!r} without a user — "
                "service contract violated"
            )
        if outcome is EmailChangeCompleteOutcome.already_completed:
            return _err_page(
                "Already done",
                f"Your email is already {user.email}.",
                status_code=400,
            )
        if outcome is EmailChangeCompleteOutcome.conflict:
            return _err_page(
                "Email no longer available",
                "Another account claimed that address before you confirmed. "
                "Request a different new email.",
                status_code=409,
            )
        return _ok_page(
            "Email updated",
            f"Your account email is now {user.email}. Sign in again to "
            "continue — your previous session has been revoked.",
        )

    return router
