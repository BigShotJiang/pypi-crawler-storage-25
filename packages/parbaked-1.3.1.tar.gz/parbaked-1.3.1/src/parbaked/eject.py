"""``parbaked eject`` — give me the underlying files (#60, v1.0).

Produces a self-contained ``parbaked-export/`` directory the operator
can take anywhere: PostgreSQL-compatible schema, CSV data, the
generated deploy files, the env-var contract, and a MANIFEST.md
pointing at the public Data Format Guarantees (#61).

This is the off-boarding promise. The whole product is more credible
because you can walk away.
"""

from __future__ import annotations

import csv
import logging
import re
from datetime import UTC, datetime
from decimal import Decimal
from pathlib import Path

from sqlalchemy import Enum as SAEnum
from sqlalchemy import inspect
from sqlalchemy.dialects import postgresql, sqlite
from sqlalchemy.dialects.postgresql import CreateEnumType
from sqlalchemy.schema import CreateTable
from sqlmodel import Session, SQLModel, create_engine, select

from parbaked import __version__
from parbaked.auth.models import SchemaVersion, User
from parbaked.cli.deploy_gen import generate as generate_deploy_files
from parbaked.config import ParbakedConfig
from parbaked.exceptions import EjectError

logger = logging.getLogger("parbaked.eject")

DEFAULT_OUTPUT = Path("parbaked-export")

# First line of every parbaked-generated MANIFEST.md — the sentinel that
# distinguishes a prior eject (safe to overwrite without ``--force``) from
# a user-supplied directory we shouldn't be writing into (#290). The
# ``(v1)`` is the on-disk manifest version: a future breaking change to
# the export layout bumps this to ``(v2)`` so callers parsing the manifest
# can branch deliberately.
MANIFEST_SENTINEL = "# parbaked-export (v1)"

# The parbaked-owned tables — the off-boarding archive's stability contract
# is scoped to exactly these. Eject also walks ``SQLModel.metadata.tables``
# to include consumer tables (#287), and uses this set as the single source
# of truth for which entries are framework-owned vs consumer-defined.
#
# When a future parbaked migration adds another internal table, add it here.
_PARBAKED_OWNED_TABLES = frozenset({
    "users",
    "_parbaked_schema_version",
    "_parbaked_admin_signin_nonce",  # post-#205
})

# The parbaked-owned model classes (used to drive schema.sql + CSV dumps for
# the framework-owned tables). Consumer tables are picked up dynamically from
# ``SQLModel.metadata.tables`` at eject time.
_EXPORTED_TABLES = [User, SchemaVersion]


def _collect_enum_types() -> list[SAEnum]:
    """Walk the exported tables and return each distinct SQLAlchemy
    ``Enum`` column type, in declaration order.

    Postgres needs a ``CREATE TYPE ... AS ENUM`` statement *before* any
    table DDL that references it (#165). SQLAlchemy's CreateTable
    compiler emits the column-side reference but not the type-side
    declaration, so eject would otherwise produce a schema.sql that
    fails to load with ``ERROR: type "..." does not exist``.
    """
    seen: set[str] = set()
    enums: list[SAEnum] = []
    for model in _EXPORTED_TABLES:
        for column in model.__table__.columns:
            col_type = column.type
            if isinstance(col_type, SAEnum) and col_type.name not in seen:
                seen.add(col_type.name)
                enums.append(col_type)
    return enums


def _tidy_ddl(raw: str) -> str:
    """Clean up SQLAlchemy CreateTable output for human consumption.

    Replaces leading tabs with four-space indents and strips the
    trailing whitespace SQLAlchemy emits after each column. The DDL
    is the user-facing artifact of leaving parbaked, so the polish
    matters (#165 bonus).
    """
    lines = []
    for line in raw.splitlines():
        line = line.replace("\t", "    ").rstrip()
        lines.append(line)
    return "\n".join(lines)


def _consumer_tables_in_live_db(engine) -> list:
    """Return the SQLAlchemy ``Table`` objects for consumer-defined tables
    that exist in the live DB, in metadata declaration order.

    Tables declared in ``models.py`` but not yet materialised in the DB
    (e.g. the consumer added a table after the last ``parbaked dev``
    boot) are skipped with a warning rather than crashing the export —
    eject must always succeed (#287).
    """
    live_names = set(inspect(engine).get_table_names())
    consumer = []
    for name, table in SQLModel.metadata.tables.items():
        if name in _PARBAKED_OWNED_TABLES:
            continue
        if name not in live_names:
            logger.warning(
                "Skipping consumer table %r: declared in models but missing "
                "from the live DB. Run `parbaked dev` to materialise it, "
                "then re-eject.",
                name,
            )
            continue
        consumer.append(table)
    return consumer


def _render_schema_sql(consumer_tables: list | None = None) -> str:
    """Return DDL for parbaked-owned + consumer tables.

    Parbaked-owned tables are rendered with the Postgres dialect (the
    stability contract is Postgres-compatible). Consumer tables are
    rendered with the SQLite dialect — that's the engine the live
    parbaked DB uses, and the resulting DDL can be loaded straight back
    with ``sqlite3 < schema.sql`` (#287). Enum column types get their
    ``CREATE TYPE`` statement emitted ahead of the table DDL that
    references them — without this, the dump fails to load against
    Postgres (#165).

    SQLite + MySQL accept the parbaked-owned table DDL because we
    stick to portable column types (TEXT, INTEGER, BOOLEAN, TIMESTAMP);
    they don't support ``CREATE TYPE ... AS ENUM`` and will need that
    line stripped (or replaced with a CHECK constraint) before loading.
    """
    if consumer_tables is None:
        consumer_tables = []

    chunks = []
    chunks.append("-- parbaked schema.")
    chunks.append(f"-- Generated by parbaked eject (parbaked v{__version__}).")
    chunks.append(
        "-- Parbaked-owned tables (users, _parbaked_*) are PostgreSQL-compatible; "
        "see docs/data-format-guarantees.md."
    )
    if consumer_tables:
        chunks.append(
            "-- Consumer tables (defined in your models.py) are rendered for "
            "SQLite — the engine parbaked runs against locally."
        )
    chunks.append("")

    # Enum types first — must precede any CREATE TABLE that references them.
    enum_types = _collect_enum_types()
    if enum_types:
        for enum_type in enum_types:
            ddl = str(
                CreateEnumType(enum_type).compile(dialect=postgresql.dialect())
            ).strip()
            chunks.append(ddl + ";")
        chunks.append("")

    for model in _EXPORTED_TABLES:
        ddl = str(
            CreateTable(model.__table__).compile(dialect=postgresql.dialect())
        ).strip()
        chunks.append(_tidy_ddl(ddl) + ";")
        chunks.append("")

    if consumer_tables:
        chunks.append("-- Consumer tables — defined by your application's models.py.")
        chunks.append(
            "-- parbaked makes no stability commitment about these columns; "
            "you defined them, you own them."
        )
        chunks.append("")
        for table in consumer_tables:
            ddl = str(
                CreateTable(table).compile(dialect=sqlite.dialect())
            ).strip()
            chunks.append(_tidy_ddl(ddl) + ";")
            chunks.append("")

    return "\n".join(chunks)


# OWASP CSV Injection trigger characters (#403). A cell whose first
# character is one of these is interpreted as a formula by Excel /
# LibreOffice Calc / Google Sheets on open. The eject contract
# explicitly tells operators to open users.csv, and the ``name`` field
# is reachable from the public ``/auth/signup`` endpoint — so a malicious
# signup ("=HYPERLINK(...)") would land in users.csv verbatim and
# execute when the operator opened the file. Prefix-with-apostrophe is
# OWASP's recommended mitigation; the apostrophe is consumed by the
# spreadsheet app and renders as text-only.
_CSV_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _safe_csv_cell(value: str) -> str:
    """Prefix formula-trigger characters with a single quote so the
    cell is treated as text, not a formula, when opened in Excel /
    LibreOffice Calc / Google Sheets (#403, OWASP CSV Injection).

    The single-quote prefix is consumed by the spreadsheet app and not
    visible in the rendered cell — round-trips cleanly if the file is
    re-imported by parbaked too (we strip leading apostrophes on a
    'restore' path if/when that ships).

    Applied to every cell the eject writer emits — not just the
    user-controlled ``name`` field — for defence in depth. Other
    fields (``email`` validated against RFC, role/status enums,
    timestamps) shouldn't have formula prefixes in practice, but
    a per-cell call costs nothing.
    """
    if value and value[0] in _CSV_FORMULA_PREFIXES:
        return "'" + value
    return value


def _dump_table_csv(engine, model, csv_path: Path) -> int:
    """Write every row of ``model`` to ``csv_path``. Returns row count.

    Plain UTF-8 + quoted strings. Columns are listed in declaration
    order so the file shape matches the schema DDL. Every cell is
    passed through :func:`_safe_csv_cell` so formula-trigger
    characters in user-controlled fields can't execute when the
    operator opens the file in a spreadsheet app (#403).
    """
    column_names = [c.name for c in inspect(model.__table__).columns]
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with Session(engine) as session:
        rows = session.exec(select(model)).all()
        with csv_path.open("w", newline="", encoding="utf-8") as fh:
            writer = csv.writer(fh, quoting=csv.QUOTE_NONNUMERIC)
            writer.writerow(column_names)
            for row in rows:
                writer.writerow(
                    [_serialize_cell(getattr(row, name)) for name in column_names]
                )
    return len(rows)


def _dump_consumer_table_csv(engine, table, csv_path: Path) -> int:
    """Write every row of consumer ``table`` to ``csv_path``. Returns row count.

    Mirrors :func:`_dump_table_csv` but operates on a raw SQLAlchemy
    ``Table`` (no ORM model class to ``select()`` against). Same
    UTF-8 + quoted-string encoding as ``users.csv`` so consumer data
    rides on exactly the same off-boarding format guarantees (#287).
    Same per-cell CSV-injection sanitisation as the parbaked-owned
    writer (#403) — consumer tables are an even larger surface area
    for user-controlled text columns, so the mitigation must apply
    globally.
    """
    column_names = [c.name for c in table.columns]
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with engine.connect() as conn:
        result = conn.execute(table.select())
        rows = result.mappings().all()
    with csv_path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh, quoting=csv.QUOTE_NONNUMERIC)
        writer.writerow(column_names)
        for row in rows:
            writer.writerow(
                [_serialize_cell(row[name]) for name in column_names]
            )
    return len(rows)


def _serialize_cell(value):
    """Turn a Python value into something the csv module accepts.

    datetimes go to ISO 8601 UTC strings (Postgres / SQLite both parse
    them on import). UUIDs go to canonical string form. Booleans stay
    as 0/1 so the column-type stays integer-importable. String-shaped
    cells (everything else) go through :func:`_safe_csv_cell` so any
    formula-trigger leading character (``=``, ``+``, ``-``, ``@``,
    ``\\t``, ``\\r``) is neutralised before the spreadsheet app sees
    it (#403, OWASP CSV Injection).
    """
    if value is None:
        return ""
    if isinstance(value, bool):
        return 1 if value else 0
    if isinstance(value, datetime):
        return value.isoformat()
    # Numeric values must bypass the CSV-safe-cell prefix — ``str(-5)``
    # starts with ``-`` which is a formula-trigger char, so the
    # apostrophe prefix would mangle every negative number written by
    # consumer tables (account balances, offsets, etc.). Numerics can't
    # carry a formula payload to a spreadsheet app anyway (Devin caught
    # this — #403 / #405). ``Decimal`` is the SQLAlchemy default for
    # ``Numeric(p, s)`` columns (the standard type for financial data)
    # and is NOT a subclass of ``int`` / ``float``, so it needs an
    # explicit branch.
    if isinstance(value, (int, float, Decimal)):
        return value
    return _safe_csv_cell(str(value))


def _render_env_example(config: ParbakedConfig) -> str:
    """Produce a .env.example listing every PARBAKED_* knob the deployed
    app would expect, with the in-use values commented out as starting
    points."""
    lines = [
        "# parbaked env-var contract — every knob the deployed app respected.",
        "# Lines are commented out so you can pick which to set explicitly.",
        "# Full descriptions: https://github.com/saml7n/parbaked/blob/main/AGENTS.md",
        "",
    ]
    skip = {
        # Internal / non-env-driven fields.
        "model_config",
    }
    for field_name, field in config.__class__.model_fields.items():
        if field_name in skip:
            continue
        env_name = f"PARBAKED_{field_name.upper()}"
        current = getattr(config, field_name)
        default = field.default
        # Don't leak secrets in the export — comment-only, no value.
        is_secret = any(
            tok in field_name for tok in ("secret", "password", "key", "client_secret")
        )
        if is_secret:
            lines.append(f"# {env_name}=  # secret — set explicitly")
        elif current == default:
            lines.append(f"# {env_name}={current}")
        else:
            # The deploy was using a non-default value; preserve it as a comment
            # so the operator sees exactly what the live config did.
            lines.append(f"# {env_name}={current}  # was in use")
    lines.append("")
    return "\n".join(lines)


def _render_manifest(
    config: ParbakedConfig,
    row_counts: dict[str, int],
    consumer_table_names: list[str] | None = None,
) -> str:
    consumer_table_names = consumer_table_names or []
    parbaked_rows = "\n".join(
        f"- ``data/{name}.csv`` — {count} row(s)"
        for name, count in row_counts.items()
        if name in _PARBAKED_OWNED_TABLES
    )
    if consumer_table_names:
        consumer_rows = "\n".join(
            f"- ``data/{name}.csv`` — {row_counts.get(name, 0)} row(s)"
            for name in consumer_table_names
        )
        consumer_block = f"""

### Consumer tables — defined by your ``models.py``

You defined these tables; parbaked just exported them. No
column-by-column stability contract — the shape is whatever your
models.py declared at eject time. SQLite-dialect DDL is in
``schema.sql``; reload locally with ``sqlite3 < schema.sql``.

{consumer_rows}"""
    else:
        consumer_block = ""

    return f"""\
{MANIFEST_SENTINEL}

Generated by ``parbaked eject`` on {datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")}
from parbaked **v{__version__}**.

## What's inside

- ``schema.sql`` — DDL for every table in the export. Parbaked-owned
  tables (``users``, ``_parbaked_*``) are PostgreSQL-compatible and
  work in Postgres, SQLite, MySQL. Consumer tables (defined in your
  ``models.py``) use the SQLite dialect.
- ``data/`` — one CSV per table, parbaked-owned and consumer-defined,
  UTF-8, quoted strings.

### Parbaked-owned tables

{parbaked_rows}{consumer_block}

- ``Dockerfile`` — the same image parbaked deploy was building. The
  CMD invokes ``uvicorn parbaked.runtime:create_app --factory``.
  Drop parbaked from your stack and edit it freely.
- ``fly.toml`` — fly.io deploy config with cost-cap defaults and the
  ``parbaked_data`` volume mount.
- ``.env.example`` — every ``PARBAKED_*`` knob the deployed app expected.
  Secrets are listed by name only; copy your live values from your
  secret store.

## Format details

- **Password hashes:** bcrypt, version ``2b``, cost factor 12. Round-trip
  with any bcrypt-compliant library (`bcrypt` in Python, `bcryptjs` in
  Node, etc).
- **Session tokens:** RFC 7519 JWT, HS256. Claims: ``sub`` (user UUID
  string), ``iat`` (epoch seconds), ``exp`` (epoch seconds). Signed with
  the secret from ``PARBAKED_JWT_SECRET``.
- **Magic-link tokens** (verify, approve, reset, admin sign-in) use
  the same HS256 algorithm with distinct ``aud`` claims —
  ``parbaked-verify``, ``parbaked-approval``,
  ``parbaked-password-reset``, ``parbaked-admin-signin``.
- **Audit events:** parbaked logs lifecycle events (signup, verify,
  login, approve, reject, password-reset) as one JSON object per
  stdout line under the ``parbaked.audit`` logger. There is **no
  audit-events SQL table** to export — the events are in whatever log
  shipper you were running.

## Full contract

The complete stability commitment — column-by-column schema notes,
what counts as breaking, how to import elsewhere — lives in the
parbaked repository:

  https://github.com/saml7n/parbaked/blob/main/docs/data-format-guarantees.md

Read that page before adopting parbaked, and re-read it before
migrating away. It's the same contract this export is built against.
"""


def _looks_like_prior_eject(output_dir: Path) -> bool:
    """Return True if ``output_dir`` contains a MANIFEST.md whose first
    line is the parbaked-export sentinel.

    The sentinel is :data:`MANIFEST_SENTINEL`. We compare the manifest's
    first line as a prefix match against ``"# parbaked-export"`` so a
    future version bump (``(v2)``, ``(v3)``) still recognises a prior
    eject — the gate is "this is a parbaked export," not "this is
    exactly this version of a parbaked export." (#290)
    """
    manifest = output_dir / "MANIFEST.md"
    if not manifest.is_file():
        return False
    try:
        with manifest.open("r", encoding="utf-8") as fh:
            first_line = fh.readline().rstrip("\n")
    except OSError:
        return False
    # Accept the new ``# parbaked-export (v1)`` sentinel AND the old
    # ``# parbaked export manifest`` heading from pre-#290 exports —
    # without this, an upgrade re-eject over an existing
    # ``parbaked-export/`` would be refused (#290 Devin).
    return first_line.startswith("# parbaked-export") or first_line.startswith(
        "# parbaked export manifest"
    )


def _prior_table_names(output_dir: Path) -> list[str]:
    """Return the table names listed in a prior MANIFEST.md's
    ``data/<name>.csv`` lines, in the order they appear.

    Used for the bounded stale-CSV sweep: when re-ejecting over a prior
    export, eject deletes any ``data/<old-table>.csv`` that was in the
    prior manifest but isn't in the current export. The sweep is bounded
    to filenames listed in the manifest — never a broader glob, and
    never anything outside ``data/`` (#290).
    """
    manifest = output_dir / "MANIFEST.md"
    try:
        body = manifest.read_text(encoding="utf-8")
    except OSError:
        return []
    # Manifest references each CSV as ``data/<name>.csv`` inside a
    # double-backtick code span — see ``_render_manifest``.
    names: list[str] = []
    seen: set[str] = set()
    for match in re.finditer(r"data/([A-Za-z0-9_]+)\.csv", body):
        name = match.group(1)
        if name not in seen:
            seen.add(name)
            names.append(name)
    return names


def _gate_output_dir(output_dir: Path, *, force: bool) -> None:
    """Refuse to write into a non-empty directory without consent (#290).

    Three accepted shapes:

    1. ``output_dir`` doesn't exist → caller is creating a fresh export.
    2. ``output_dir`` exists and is empty → caller pointed at a holding
       directory.
    3. ``output_dir`` exists, is non-empty, AND either has a valid
       MANIFEST.md sentinel (this is a prior eject) OR the caller
       passed ``force=True``.

    Anything else raises :class:`EjectError`. Critically, no
    ``shutil.rmtree`` runs — eject overwrites file-by-file instead, so
    a user-supplied directory's unrelated contents survive.
    """
    if not output_dir.exists():
        return
    if not output_dir.is_dir():
        raise EjectError(
            f"output_dir {output_dir!s} exists but is not a directory."
        )
    # ``iterdir`` is lazy — short-circuit on the first entry rather than
    # listing the whole tree.
    is_empty = next(output_dir.iterdir(), None) is None
    if is_empty:
        return
    if _looks_like_prior_eject(output_dir):
        return
    if force:
        return
    raise EjectError(
        f"output_dir {output_dir!s} is not empty and doesn't look like a "
        "prior parbaked-export (no MANIFEST.md with the parbaked-export "
        "sentinel). Use force=True (or --force from the CLI) to overwrite, "
        "or point at an empty path."
    )


def eject(
    output_dir: Path = DEFAULT_OUTPUT,
    *,
    config: ParbakedConfig | None = None,
    force: bool = False,
) -> Path:
    """Run the full eject. Returns the absolute path of the output dir.

    Refuses to write into a non-empty directory unless either:

    - The directory already contains a ``MANIFEST.md`` whose first line
      starts with ``# parbaked-export`` — proving it's a prior eject the
      caller intends to overwrite, OR
    - ``force=True`` — the caller has explicitly said "I know what's in
      there; overwrite it anyway."

    Empty / non-existent directories proceed without ceremony.

    Eject **never** runs ``shutil.rmtree`` on the output dir (#290).
    Files are overwritten by name. When re-ejecting over a prior export,
    a bounded sweep deletes ``data/<old-table>.csv`` for any table that
    was in the prior MANIFEST but isn't in the new export — bounded to
    ``data/``, never touching anything else.

    The export contains parbaked-owned tables (the framework's auth +
    bookkeeping) AND any consumer tables declared in ``models.py`` that
    exist in the live DB (#287) — the "walk away with your data"
    promise is meaningless if the user's actual data stays locked up.

    Eject autoloads the consumer's ``models.py`` at entry (#302) so
    ``SQLModel.metadata.tables`` contains the consumer tables before
    the metadata-walk in :func:`_consumer_tables_in_live_db`. Without
    this, callers that didn't go through ``create_app()`` (the CLI
    ``parbaked eject``, the MCP ``tool_eject``, ad-hoc scripts) would
    silently miss every consumer-defined table — the #287 fix only
    worked when ``create_app()`` had already imported models.py for
    its own create_all. A broken ``models.py`` is not fatal for the
    parbaked-owned slice of the export: log a WARNING naming the
    failure and proceed; the user still walks away with users.csv +
    schema.sql for the framework tables rather than nothing.

    Eject materialises the parbaked-owned schema if the live DB has
    never been booted (#349). On
    ``parbaked new x && cd x && parbaked eject`` the SQLite file
    doesn't exist yet and the CSV dump would crash with ``no such
    table: users``. We probe for the ``users`` table; if it's missing,
    we run ``apply_migrations`` to create it. Already-booted DBs skip
    this step, preserving the contract that consumer tables declared
    in metadata but not yet materialised in the DB are reported with
    a warning rather than silently created (#287). The
    parbaked-owned-schema parallel to the #302 autoload.
    """
    if config is None:
        config = ParbakedConfig()

    # Populate ``SQLModel.metadata.tables`` with consumer-defined
    # tables BEFORE ``_consumer_tables_in_live_db`` walks metadata
    # (#302). The CLI/MCP entry points don't go through
    # ``create_app()``, so without this call metadata only contains
    # the parbaked-owned tables and the consumer's data is silently
    # dropped from the export — exactly the failure #287's internal
    # logic was supposed to prevent.
    #
    # ``_autoload_consumer_models`` raises ``RuntimeError`` on a
    # broken models.py (matching the boot-time contract from #181).
    # In eject we degrade instead: a broken file is the consumer's
    # bug to fix, but the off-boarding archive for the parbaked-owned
    # tables shouldn't be held hostage to it.
    from parbaked.runtime import _autoload_consumer_models
    try:
        _autoload_consumer_models()
    except RuntimeError as exc:
        logger.warning(
            "Consumer tables not exported: %s. The parbaked-owned "
            "tables (users, _parbaked_*) still landed in the export; "
            "fix models.py and re-run eject to include consumer data.",
            exc,
        )

    output_dir = output_dir.resolve()
    _gate_output_dir(output_dir, force=force)

    # Capture the prior export's table list BEFORE we overwrite the
    # manifest — needed for the bounded stale-CSV sweep below.
    prior_tables = (
        _prior_table_names(output_dir) if _looks_like_prior_eject(output_dir) else []
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "data").mkdir(exist_ok=True)

    # Build engine first so we can inspect the live DB to discover which
    # consumer tables actually exist (models.py may declare tables that
    # haven't been materialised yet — skip those with a warning rather
    # than crash the export).
    engine = create_engine(config.database_url)

    # Materialise the parbaked-owned schema if the DB has never been
    # booted (#349). On ``parbaked new x && cd x && parbaked eject``,
    # the SQLite file doesn't exist and the CSV dump loop would crash
    # with ``sqlite3.OperationalError: no such table: users``. We gate
    # on the users-table existence (the same probe ``apply_migrations``
    # uses internally for its fresh-DB branch) so this is a no-op
    # against any DB that's been through ``parbaked dev`` — the
    # post-boot eject path is unchanged.
    #
    # Gating on the users-table check (rather than calling
    # ``apply_migrations`` unconditionally) is load-bearing for the
    # "consumer added a model but hasn't booted yet" contract from #287:
    # ``apply_migrations`` runs ``SQLModel.metadata.create_all``, which
    # would materialise the phantom consumer table in the live DB —
    # exactly what ``_consumer_tables_in_live_db`` is meant to detect
    # and skip with a warning. By only migrating when the parbaked
    # tables don't yet exist (the fresh-project case), we keep the
    # "phantom table" detection working for partially-booted DBs.
    from parbaked.migrations._runner import _users_table_exists
    if not _users_table_exists(engine):
        from parbaked.migrations import apply_migrations
        apply_migrations(engine)

    consumer_tables = _consumer_tables_in_live_db(engine)

    # Schema DDL — parbaked-owned + consumer.
    (output_dir / "schema.sql").write_text(_render_schema_sql(consumer_tables))

    # Data CSVs — parbaked-owned first, then consumer.
    row_counts: dict[str, int] = {}
    for model in _EXPORTED_TABLES:
        csv_path = output_dir / "data" / f"{model.__tablename__}.csv"
        row_counts[model.__tablename__] = _dump_table_csv(engine, model, csv_path)

    consumer_table_names: list[str] = []
    for table in consumer_tables:
        csv_path = output_dir / "data" / f"{table.name}.csv"
        row_counts[table.name] = _dump_consumer_table_csv(engine, table, csv_path)
        consumer_table_names.append(table.name)

    # Bounded stale-CSV sweep: only filenames the prior MANIFEST listed,
    # only inside ``data/``. Never a glob, never a parent traversal.
    current_table_names = set(row_counts.keys())
    for stale in prior_tables:
        if stale in current_table_names:
            continue
        stale_csv = output_dir / "data" / f"{stale}.csv"
        # Defence in depth: confirm the resolved path is still under
        # ``output_dir / "data"`` before unlinking. A pathological
        # manifest with ``../`` in a table name shouldn't escape.
        try:
            resolved = stale_csv.resolve()
            resolved.relative_to((output_dir / "data").resolve())
        except (OSError, ValueError):
            logger.warning(
                "Skipping stale CSV cleanup for %r: resolved path escapes data/.",
                stale,
            )
            continue
        if stale_csv.is_file():
            stale_csv.unlink()

    # Deploy targets (Dockerfile + fly.toml) — same code path as #48.
    generate_deploy_files(output_dir, config)

    # Env-var contract.
    (output_dir / ".env.example").write_text(_render_env_example(config))

    # Manifest pointing at the public Data Format Guarantees doc.
    (output_dir / "MANIFEST.md").write_text(
        _render_manifest(config, row_counts, consumer_table_names)
    )

    return output_dir
