"""Admin dashboard router.

Two sign-in paths, picked per-mode (no hybrids) — see #130:

- **Email mode** (``config.email_enabled``): the login form asks for an
  email. Submitting a matching ``admin_email`` sends a short-lived
  magic-link to that inbox. Clicking the link verifies the token, sets
  the session cookie, and redirects to ``/auth/admin``.
- **No-email mode** (the legacy default): the login form asks for the
  shared ``admin_password`` printed in the boot banner. Submitting the
  right value sets the session cookie directly.

Either way the cookie gates ``/auth/admin`` (the pending / active /
rejected dashboard) and the ``approve`` / ``reject`` action endpoints.
The session lives in an HttpOnly, SameSite=Lax cookie with a 12-hour
lifetime.

Break-glass when the admin inbox is unreachable: shell into the
deployment and run ``parbaked admin signin``. The CLI prints a one-time
signed URL using the local JWT secret — shell access IS the recovery
path, there is no shadow password.
"""

from __future__ import annotations

import secrets as _secrets
import time
from collections.abc import Callable
from html import escape as _esc
from uuid import UUID

from fastapi import APIRouter, Cookie, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from slowapi import Limiter
from sqlmodel import Session, select

from parbaked._clientip import client_ip
from parbaked._form_css import _FORM_CSS
from parbaked.auth.models import User, UserStatus
from parbaked.auth.service import (
    admin_signin_request,
    approve_user,
    reject_user,
)
from parbaked.auth.tokens import (
    InvalidAdminSession,
    InvalidAdminSigninToken,
    create_admin_session_token,
    verify_admin_session_token,
    verify_admin_signin_token,
)
from parbaked.config import ParbakedConfig
from parbaked.email.base import EmailTransport
from parbaked.email.templates import Templates
from parbaked.hooks import Hooks
from parbaked.logging import log_event

_COOKIE_NAME = "parbaked_admin_session"
_CSRF_COOKIE = "parbaked_admin_csrf"
_COOKIE_TTL_HOURS = 12

# In-memory revocation set for admin session JWTs (#200). Maps ``jti`` →
# token ``exp`` (unix seconds) so we can prune expired entries lazily.
#
# Why in-memory: parbaked is a single-instance kernel by design (see
# AGENTS.md + the production-safety check in app.py that warns on
# WEB_CONCURRENCY > 1). A process-local set is correct under that
# contract — when the process restarts every cookie is already invalid
# because the JWT secret was either rotated or the boot has wiped the
# session-cookie's iat/exp window in practice.
#
# Growth is bounded by login-rate × max TTL: at one logout per minute and
# a 12-hour TTL ceiling that's ~720 entries — well below any sane
# memory budget. Pruning on add keeps it tighter.
_revoked_jtis: dict[str, float] = {}


def _prune_expired_revocations(now: float | None = None) -> None:
    """Drop entries whose token would have already expired anyway.

    Called from the logout handler before adding a new entry so the set
    stays bounded by the *current* live-token population, not the
    cumulative all-time logout count.
    """
    now = now if now is not None else time.time()
    expired = [jti for jti, exp in _revoked_jtis.items() if exp <= now]
    for jti in expired:
        _revoked_jtis.pop(jti, None)


def _mint_csrf() -> str:
    """Fresh CSRF token. 32 random bytes is overkill on purpose."""
    return _secrets.token_urlsafe(32)


_DASHBOARD_HTML = """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>parbaked admin · {app_name}</title>
<style>
  :root {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }}
  body {{ max-width: 64rem; margin: 2rem auto; padding: 0 1.5rem; color: #111; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 0.25rem; }}
  .sub {{ color: #666; font-size: 0.875rem; margin-bottom: 2rem; }}
  h2 {{ font-size: 1.05rem; margin-top: 2rem; color: #333; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 0.9rem; }}
  th, td {{ text-align: left; padding: 0.5rem 0.75rem; border-bottom: 1px solid #eee; }}
  th {{ font-weight: 600; color: #555; background: #fafafa; }}
  td.actions {{ text-align: right; }}
  button {{ font: inherit; padding: 0.35rem 0.75rem; border-radius: 4px; border: 1px solid #ccc;
           background: white; cursor: pointer; margin-left: 0.5rem; }}
  button.approve {{ background: #15803d; color: white; border-color: #15803d; }}
  button.reject {{ background: #b91c1c; color: white; border-color: #b91c1c; }}
  .empty {{ color: #888; font-style: italic; padding: 0.5rem 0.75rem; }}
  .badge {{ font-size: 0.7rem; padding: 0.1rem 0.5rem; border-radius: 999px;
           background: #eee; color: #666; text-transform: uppercase; letter-spacing: 0.04em; }}
  .badge.pending {{ background: #fef3c7; color: #92400e; }}
  .badge.active  {{ background: #dcfce7; color: #166534; }}
  .badge.rejected {{ background: #fee2e2; color: #991b1b; }}
  .signout-form {{ display: inline; }}
  .signout-button {{ background: none; border: 0; padding: 0; margin: 0;
           color: #2563eb; cursor: pointer; font-size: inherit;
           text-decoration: underline; }}
</style>
</head>
<body>
  <h1>parbaked admin</h1>
  <div class="sub">{app_name} · {pending_summary} ·
    <form method="post" action="{logout_action}" class="signout-form">
      <input type="hidden" name="_csrf" value="{csrf}">
      <button type="submit" class="signout-button">Sign out</button>
    </form>
  </div>

  <h2>Pending</h2>
  {pending_table}

  <h2>Active</h2>
  {active_table}

  <h2>Rejected</h2>
  {rejected_table}
</body>
</html>
"""


_LOGIN_FORM_HTML = (
    """\
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>parbaked admin · sign in</title>
<style>
"""
    + _FORM_CSS
    + """
</style>
</head>
<body>
  <form method="post" action="{action}" class="card">
    <h1>parbaked admin</h1>
    <p class="sub">{sub}</p>
    {message_html}
    <input type="hidden" name="_csrf" value="{csrf}">
    <label for="{field_id}">{field_label}</label>
    <input id="{field_id}" name="{field_name}" type="{field_type}" autofocus required{field_extra}>
    <button type="submit">{submit_label}</button>
  </form>
</body>
</html>
"""
)


def _render_password_login_form(
    action_url: str, csrf: str, error: str | None = None
) -> str:
    """No-email mode: form asks for the shared admin password."""
    message_html = f'<p class="err">{_esc(error)}</p>' if error else ""
    return _LOGIN_FORM_HTML.format(
        action=_esc(action_url, quote=True),
        csrf=_esc(csrf, quote=True),
        sub="Sign in to manage signups.",
        message_html=message_html,
        field_id="password",
        field_name="password",
        field_label="Admin password",
        field_type="password",
        field_extra="",
        submit_label="Sign in",
    )


def _render_email_login_form(
    action_url: str,
    csrf: str,
    *,
    error: str | None = None,
    info: str | None = None,
) -> str:
    """Email mode: form asks for the admin email; on submit a magic link
    is mailed if the address matches ``config.admin_email``."""
    if error:
        message_html = f'<p class="err">{_esc(error)}</p>'
    elif info:
        message_html = f'<p class="ok">{_esc(info)}</p>'
    else:
        message_html = ""
    return _LOGIN_FORM_HTML.format(
        action=_esc(action_url, quote=True),
        csrf=_esc(csrf, quote=True),
        sub="Enter your admin email — we'll send a one-time sign-in link.",
        message_html=message_html,
        field_id="email",
        field_name="email",
        field_label="Your admin email",
        field_type="email",
        field_extra=' inputmode="email" autocomplete="email"',
        submit_label="Email me a sign-in link",
    )


def _render_action_row(
    user: User,
    prefix: str,
    csrf: str,
    *,
    when: str,
    actions: list[tuple[str, str, str]],
) -> str:
    """Render a dashboard row with one or more action-form buttons.

    ``actions`` is a list of ``(path_suffix, button_class, button_label)``
    tuples — each tuple becomes one ``<form>`` posting to
    ``<prefix>/<user.id>/<path_suffix>``. ``when`` is the pre-formatted
    timestamp cell (callers pick the right field — ``created_at`` for
    pending, ``approved_at`` for active, ``revoked_at`` for rejected; see
    #220).

    Escaping: ``user.name`` and ``user.email`` are user-controlled at
    signup so they must be HTML-escaped; ``prefix`` and ``csrf`` come
    from parbaked but are escaped defensively. ``user.id`` is a UUID
    (safe alphabet) and the action triple is hard-coded by the caller.
    """
    safe_prefix = _esc(prefix, quote=True)
    safe_csrf = _esc(csrf, quote=True)
    forms = "\n          ".join(
        f'<form method="post" action="{safe_prefix}/{user.id}/{path}" style="display: inline">\n'
        f'            <input type="hidden" name="_csrf" value="{safe_csrf}">\n'
        f'            <button class="{cls}" type="submit">{label}</button>\n'
        f'          </form>'
        for path, cls, label in actions
    )
    return f"""\
      <tr>
        <td>{_esc(user.name)}</td>
        <td>{_esc(user.email)}</td>
        <td>{when}</td>
        <td class="actions">
          {forms}
        </td>
      </tr>"""


def _table(rows: list[str], headers: list[str]) -> str:
    if not rows:
        return '<p class="empty">None</p>'
    header_row = "".join(f"<th>{h}</th>" for h in headers)
    body = "\n".join(rows)
    return f"<table><thead><tr>{header_row}</tr></thead><tbody>\n{body}\n</tbody></table>"


def build_admin_router(
    config: ParbakedConfig,
    get_session: Callable[..., Session],
    admin_password: str,
    email: EmailTransport,
    templates: Templates,
    *,
    hooks: Hooks | None = None,
    limiter: Limiter | None = None,
    prefix: str = "/auth/admin",
) -> APIRouter:
    hooks = hooks or Hooks()
    router = APIRouter(prefix=prefix, tags=["admin"], include_in_schema=False)
    actions_prefix = prefix  # forms POST to /auth/admin/<id>/<action>
    login_url = f"{prefix}/login"

    # slowapi requires the decorator at definition time, so we resolve to a
    # no-op when no limiter is provided (tests, framework-internal callers).
    def _limit(rule: str) -> Callable[[Callable], Callable]:
        if limiter is None:
            return lambda f: f
        return limiter.limit(rule)

    # Cookies are only marked Secure when the public URL is HTTPS — otherwise
    # browsers reject the Set-Cookie on plain http://localhost dev.
    cookie_secure = config.app_url.startswith("https://")

    def _set_csrf_cookie(response: Response, token: str) -> None:
        """Plant the CSRF cookie on a response. Same lifetime/scope as the
        session cookie — both expire together so a stale form doesn't carry
        a token whose session is already gone.
        """
        response.set_cookie(
            key=_CSRF_COOKIE,
            value=token,
            max_age=_COOKIE_TTL_HOURS * 3600,
            httponly=True,  # server-side double-submit; JS never reads it
            secure=cookie_secure,
            samesite="lax",
            path=prefix,
        )

    def _check_csrf(request: Request, form_csrf: str | None) -> None:
        """Reject the request if form ``_csrf`` doesn't match the cookie.

        This is the second leg of a double-submit cookie. SameSite=Lax on
        the session cookie is the first leg; this catches the cases Lax
        doesn't (older browsers, top-level form navigation, etc.).
        """
        cookie = request.cookies.get(_CSRF_COOKIE)
        if (
            not cookie
            or not form_csrf
            or not _secrets.compare_digest(cookie, form_csrf)
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="CSRF token missing or invalid — refresh the page and retry.",
            )

    def _set_session_cookie(response: Response) -> None:
        """Mint + plant the admin session cookie. Used by both login paths."""
        token = create_admin_session_token(config, ttl_hours=_COOKIE_TTL_HOURS)
        response.set_cookie(
            key=_COOKIE_NAME,
            value=token,
            max_age=_COOKIE_TTL_HOURS * 3600,
            httponly=True,
            secure=cookie_secure,
            samesite="lax",
            path=prefix,  # cookie scoped to the admin tree only
        )

    def _require_admin(
        request: Request,
        session_cookie: str | None = Cookie(default=None, alias=_COOKIE_NAME),
    ) -> None:
        """Check the admin session cookie. Redirect to login if missing/invalid.

        Tokens whose ``jti`` is in :data:`_revoked_jtis` (i.e. the admin
        explicitly logged out) are rejected the same way an expired
        token would be — even though the JWT's own ``exp`` may still be
        in the future. This is the defence-in-depth half of #200.
        """
        if session_cookie:
            try:
                payload = verify_admin_session_token(session_cookie, config)
                if payload.get("jti") not in _revoked_jtis:
                    return
            except InvalidAdminSession:
                pass

        # No valid cookie. For browser navigation (GET), redirect to login.
        # For mutating actions (POST), tell the client they need to sign in.
        if request.method == "GET":
            raise HTTPException(
                status_code=status.HTTP_303_SEE_OTHER,
                headers={"Location": login_url},
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin session expired — sign in again.",
        )

    # ----- login form ------------------------------------------------

    @router.get("/login", response_class=HTMLResponse)
    def login_form() -> HTMLResponse:
        csrf = _mint_csrf()
        # Mode gate is exclusively admin_email — NOT email_enabled.
        # email_enabled is True whenever any transport is configured
        # (e.g. resend_key for user-verification mail). Using it here
        # would lock the admin out if resend_key is set without
        # admin_email: form renders email-mode, no expected address to
        # match, no magic link ever mailed, password form never shown.
        # Caught by Devin Review on PR #180.
        if bool(config.admin_email):
            html = _render_email_login_form(login_url, csrf)
        else:
            html = _render_password_login_form(login_url, csrf)
        response = HTMLResponse(html)
        _set_csrf_cookie(response, csrf)
        return response

    @router.post("/login")
    @_limit(config.ratelimit_admin_login)
    def login_submit(
        request: Request,
        csrf_token: str = Form(..., alias="_csrf"),
        password: str | None = Form(default=None),
        email_addr: str | None = Form(default=None, alias="email"),
        session: Session = Depends(get_session),
    ) -> Response:
        _check_csrf(request, csrf_token)
        ip = client_ip(request, config)

        if bool(config.admin_email):
            # Email-mode sign in (#130). Whoever submits the right
            # admin email gets a magic link mailed to that inbox; the
            # link is the credential. We respond with the same "check
            # your inbox" page regardless of whether the address
            # matches — same no-enumeration discipline the
            # forgot-password endpoint has used since v0.8. The
            # matched-flag returned by the service is for the audit
            # log; we deliberately don't surface it in the response.
            admin_signin_request(
                email_addr, session,
                config=config, email_transport=email, templates=templates,
                signin_url_prefix=prefix, ip=ip,
            )
            csrf = _mint_csrf()
            response = HTMLResponse(
                _render_email_login_form(
                    login_url,
                    csrf,
                    info=(
                        "If that's the admin address, a sign-in link is on its way."
                    ),
                )
            )
            _set_csrf_cookie(response, csrf)
            return response

        # No-email mode: password login.
        if not password or not _secrets.compare_digest(password, admin_password):
            log_event(
                "admin.login.fail",
                ip=ip,
                success=False,
                extra={"reason": "bad_password"},
            )
            # Re-mint the CSRF token on the error page so the next attempt
            # has a fresh value (matches the cookie we're about to set).
            csrf = _mint_csrf()
            response = HTMLResponse(
                _render_password_login_form(
                    login_url, csrf, error="Incorrect password."
                ),
                status_code=status.HTTP_401_UNAUTHORIZED,
            )
            _set_csrf_cookie(response, csrf)
            return response
        response = RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)
        _set_session_cookie(response)
        log_event("admin.login.success", ip=ip, success=True)
        return response

    @router.get("/signin/{token}")
    def signin(
        request: Request,
        token: str,
        session: Session = Depends(get_session),
    ) -> Response:
        """Land the admin from an emailed magic link (#130).

        Verifies the audience-scoped token, sets the admin session
        cookie, and redirects to the dashboard. Reachable in both modes
        but only minted by the email-mode login submit (and by the
        ``parbaked admin signin`` break-glass CLI). A stale or forged
        link bounces back to the login form with an explanation.

        The verify rotates the per-admin signin nonce on success (#205),
        burning the just-used token and any peers. A second click of
        the same URL lands here again, fails the nonce check, and gets
        the same "invalid or expired" page.
        """
        ip = client_ip(request, config)
        try:
            verify_admin_signin_token(token, config, session)
        except InvalidAdminSigninToken as exc:
            log_event(
                "admin.signin.fail",
                ip=ip,
                success=False,
                extra={"reason": "invalid_token", "detail": str(exc)},
            )
            csrf = _mint_csrf()
            if config.email_enabled:
                html = _render_email_login_form(
                    login_url,
                    csrf,
                    error="Sign-in link is invalid or expired — request a new one.",
                )
            else:
                html = _render_password_login_form(
                    login_url,
                    csrf,
                    error="Sign-in link is invalid or expired.",
                )
            response = HTMLResponse(html, status_code=status.HTTP_400_BAD_REQUEST)
            _set_csrf_cookie(response, csrf)
            return response

        response = RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)
        _set_session_cookie(response)
        log_event("admin.signin.success", ip=ip, success=True)
        return response

    @router.post("/logout")
    def logout(
        request: Request,
        csrf_token: str = Form(..., alias="_csrf"),
        session_cookie: str | None = Cookie(default=None, alias=_COOKIE_NAME),
    ) -> Response:
        _check_csrf(request, csrf_token)
        # Server-side revoke: drop the current token's ``jti`` into the
        # in-memory revocation set so a captured cookie can't be replayed
        # after logout (#200). Best-effort — a logout request with no
        # cookie or a forged cookie still clears the client-side state.
        if session_cookie:
            try:
                payload = verify_admin_session_token(session_cookie, config)
                jti = payload.get("jti")
                exp = payload.get("exp")
                if jti and exp:
                    _prune_expired_revocations()
                    _revoked_jtis[str(jti)] = float(exp)
            except InvalidAdminSession:
                pass
        response = RedirectResponse(url=login_url, status_code=status.HTTP_303_SEE_OTHER)
        response.delete_cookie(key=_COOKIE_NAME, path=prefix)
        response.delete_cookie(key=_CSRF_COOKIE, path=prefix)
        log_event("admin.logout", ip=client_ip(request, config), success=True)
        return response

    @router.get("", response_class=HTMLResponse, dependencies=[Depends(_require_admin)])
    def dashboard(session: Session = Depends(get_session)) -> HTMLResponse:
        csrf = _mint_csrf()
        all_users = list(session.exec(select(User).order_by(User.created_at.desc())).all())
        # Unverified signups are deliberately hidden — they haven't proven they
        # own the email yet, so they're filed under "noise" until then.
        verified_pending = [
            u for u in all_users
            if u.status == UserStatus.pending and u.email_verified_at is not None
        ]
        unverified_count = sum(
            1 for u in all_users
            if u.status == UserStatus.pending and u.email_verified_at is None
        )
        active = [u for u in all_users if u.status == UserStatus.active]
        rejected = [u for u in all_users if u.status == UserStatus.rejected]

        pending_table = _table(
            [
                _render_action_row(
                    u,
                    actions_prefix,
                    csrf,
                    when=u.created_at.strftime("%Y-%m-%d %H:%M"),
                    actions=[
                        ("approve", "approve", "Approve"),
                        ("reject", "reject", "Reject"),
                    ],
                )
                for u in verified_pending
            ],
            ["Name", "Email", "Signed up", ""],
        )
        active_table = _table(
            [
                _render_action_row(
                    u,
                    actions_prefix,
                    csrf,
                    when=(u.approved_at or u.created_at).strftime("%Y-%m-%d %H:%M"),
                    actions=[("reject", "reject", "Suspend")],
                )
                for u in active
            ],
            ["Name", "Email", "Approved", ""],
        )
        rejected_table = _table(
            [
                _render_action_row(
                    u,
                    actions_prefix,
                    csrf,
                    when=(u.revoked_at or u.created_at).strftime("%Y-%m-%d %H:%M"),
                    actions=[("approve", "approve", "Restore")],
                )
                for u in rejected
            ],
            ["Name", "Email", "Rejected at", ""],
        )

        unverified_note = (
            f" · {unverified_count} unverified (hidden)" if unverified_count else ""
        )
        response = HTMLResponse(
            _DASHBOARD_HTML.format(
                app_name=_esc(config.app_name),
                pending_summary=f"{len(verified_pending)} pending{unverified_note}",
                pending_table=pending_table,  # rows already escaped per-cell
                active_table=active_table,
                rejected_table=rejected_table,
                logout_action=_esc(f"{prefix}/logout", quote=True),
                csrf=_esc(csrf, quote=True),
            )
        )
        _set_csrf_cookie(response, csrf)
        return response

    @router.post("/{user_id}/approve", dependencies=[Depends(_require_admin)])
    def approve(
        request: Request,
        user_id: UUID,
        csrf_token: str = Form(..., alias="_csrf"),
        session: Session = Depends(get_session),
    ) -> RedirectResponse:
        _check_csrf(request, csrf_token)
        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        approve_user(
            user, session,
            config=config, email=email, templates=templates, hooks=hooks,
            via="dashboard", ip=client_ip(request, config),
        )
        return RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)

    @router.post("/{user_id}/reject", dependencies=[Depends(_require_admin)])
    def reject(
        request: Request,
        user_id: UUID,
        csrf_token: str = Form(..., alias="_csrf"),
        session: Session = Depends(get_session),
    ) -> RedirectResponse:
        _check_csrf(request, csrf_token)
        user = session.get(User, user_id)
        if user is None:
            raise HTTPException(status_code=404, detail="User not found")
        reject_user(
            user, session,
            config=config, email=email, templates=templates, hooks=hooks,
            via="dashboard", ip=client_ip(request, config),
        )
        return RedirectResponse(url=prefix, status_code=status.HTTP_303_SEE_OTHER)

    return router
