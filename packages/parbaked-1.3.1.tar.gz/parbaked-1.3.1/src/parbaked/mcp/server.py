"""MCP server exposing parbaked's tools to AI agents (#81).

Tools mirror the CLI surface plus a few derived ones that LLMs find
easier to chain. Every tool returns structured data — never bare exit
codes — so the model can reason about the result.

Read-only tools (safe to call freely): ``users_list``,
``email_setup_status``, ``deploy_status``.

Mutating tools (do real work): ``scaffold``, ``add_route``,
``add_model``, ``dev``, ``users_approve``, ``deploy``.

Out of scope deliberately:
- No ``--force`` toggles exposed — destructive ops require the user.
- No OAuth-style flows (Resend / fly login) — those stay in the CLI.
- No streaming progress — synchronous from the tool's perspective.
- No multi-project orchestration — one server, one project, one cwd.
"""

from __future__ import annotations

import ast
import contextlib
import importlib.util
import json
import keyword
import os
import shutil
import socket
import subprocess
import textwrap
from collections.abc import Callable
from io import StringIO
from pathlib import Path
from typing import Any


def _have_mcp() -> bool:
    return importlib.util.find_spec("mcp") is not None


def _in_parbaked_project() -> bool:
    return Path("parbaked.toml").exists()


def _port_in_use(port: int) -> bool:
    """Return True iff something is already accepting connections on ``port``.

    Used by :func:`tool_dev` to short-circuit when an agent calls the tool
    twice in a row — without this, the second Popen succeeds but uvicorn
    inside it crashes with "address already in use", leaving the agent with
    a zombie pid and no usable signal (#184).
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("127.0.0.1", port)) == 0


# --------------------------------------------------------------------- tools


def tool_scaffold(name: str, parent: str = ".") -> dict[str, Any]:
    """``parbaked new`` over RPC. Creates a kernel-style project tree.

    Reuses ``_validate_app_name`` (#155) so agent-driven scaffolds get
    the same conservative-safe-everywhere subset as the CLI: lowercase,
    leading letter, letters/digits/hyphens only, no trailing hyphen.
    Returns a structured ``{"ok": False, "error": ...}`` on a bad
    name rather than raising — agents handle JSON, not Python
    exceptions.
    """
    import typer as _typer

    from parbaked.cli.main import _validate_app_name
    from parbaked.operations.scaffold import scaffold_project

    try:
        _validate_app_name(name)
    except _typer.BadParameter as exc:
        return {"ok": False, "error": str(exc), "name": name}
    parent_path = Path(parent).expanduser().resolve()
    cwd = Path.cwd().resolve()
    if not (parent_path == cwd or parent_path.is_relative_to(cwd)):
        return {
            "ok": False,
            "error": "scaffold parent must be inside the current working directory",
        }
    target = parent_path / name
    if target.exists():
        return {
            "ok": False,
            "error": f"directory {target} already exists",
            "path": str(target),
        }

    target.mkdir(parents=True)
    # Shared with the CLI ``new`` command (#188 item 3, #228) — one
    # implementation of the rename map / .tpl stripping / template render
    # lives in ``parbaked.operations.scaffold.scaffold_project``.
    scaffold_project(target, name)

    return {
        "ok": True,
        "path": str(target),
        "next": [
            f"cd {target}",
            "parbaked dev",
            "open http://localhost:8000/auth/admin (login: admin, password in terminal)",
        ],
    }


def tool_add_route(
    path: str,
    requires_auth: bool = False,
    http_method: str = "get",
) -> dict[str, Any]:
    """Create a routes/*.py file from ``path``. The handler body is a
    placeholder the agent fills in by editing the file.

    Supported methods: GET, POST, PUT, PATCH, DELETE (OPTIONS / HEAD are
    derived automatically by FastAPI).
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    if not path.startswith("/"):
        return {"ok": False, "error": "path must start with /"}
    method = http_method.lower()
    if method not in {"get", "post", "put", "patch", "delete"}:
        return {"ok": False, "error": f"unsupported http_method {http_method!r}"}

    # /foo/bar → routes/foo/bar.py
    parts = [p for p in path.strip("/").split("/") if p]
    if any(p == ".." for p in parts):
        return {
            "ok": False,
            "error": "route path must stay inside routes/ (no '..' components)",
        }
    routes_dir = Path("routes").resolve()
    if not parts:
        # / → routes/index.py
        rel = Path("routes/index.py")
    else:
        rel = Path("routes") / Path(*parts[:-1]) / f"{parts[-1]}.py"

    # Defence-in-depth: resolve and confirm the target stays inside routes/.
    # Catches absolute paths, symlinks, and any traversal we missed above.
    target_abs = (routes_dir.parent / rel).resolve()
    if not (target_abs == routes_dir or target_abs.is_relative_to(routes_dir)):
        return {
            "ok": False,
            "error": "route path must stay inside routes/",
        }

    if rel.exists():
        return {"ok": False, "error": f"a route already exists at {path!r}"}

    rel.parent.mkdir(parents=True, exist_ok=True)

    if requires_auth:
        body = textwrap.dedent(f'''\
            """Generated by parbaked MCP server."""

            from fastapi import APIRouter, Depends
            from parbaked import current_user

            router = APIRouter()


            @router.{method}("")
            def handler(user = Depends(current_user)):
                # TODO: fill in the handler body
                return {{"email": user.email}}
            ''')
    else:
        body = textwrap.dedent(f'''\
            """Generated by parbaked MCP server."""

            from fastapi import APIRouter

            router = APIRouter()


            @router.{method}("")
            def handler():
                # TODO: fill in the handler body
                return {{"ok": True}}
            ''')

    rel.write_text(body)
    return {
        "ok": True,
        "file": str(rel),
        "mounted_at": path,
        "method": method.upper(),
        "requires_auth": requires_auth,
    }


_SAFE_ANNOTATION_NODES: tuple[type[ast.AST], ...] = (
    ast.Name,
    ast.Subscript,
    ast.Attribute,
    ast.Constant,
    ast.BinOp,
    ast.BitOr,  # the operator inside `X | Y`
    ast.Tuple,
    ast.Load,
)


def _is_safe_annotation(value: str) -> bool:
    """Return True iff ``value`` parses as a pure type annotation.

    Anything that could execute code at import time — function calls,
    imports, decorators, multi-statement payloads — is rejected. This
    is the gate that blocks #149's RCE (a field value of ``"str; import
    os; os.system('...')"`` would otherwise be written verbatim into
    ``models.py`` and run on next boot).
    """
    try:
        tree = ast.parse(f"x: {value}", mode="exec")
    except SyntaxError:
        return False
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.AnnAssign):
        return False
    annotation = tree.body[0].annotation
    return all(
        isinstance(node, _SAFE_ANNOTATION_NODES) for node in ast.walk(annotation)
    )


def _collect_imported_names(source: str) -> set[str]:
    """Return the set of names brought into module scope by top-level imports.

    Walks the AST instead of grepping the source — a commented example
    block (``# from sqlmodel import Field, SQLModel``) used to fool the
    string-based check in ``tool_add_model``, leaving the freshly
    written ``class Note(SQLModel, ...)`` with no real import for
    ``SQLModel`` / ``Field`` / ``UUID`` and crashing the dev server on
    reload (#301).

    Imports inside ``if TYPE_CHECKING:`` blocks or function bodies are
    ignored — those don't satisfy runtime references. A malformed file
    (un-parseable Python) returns an empty set, so the caller treats
    every needed name as missing and prepends fresh imports.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return set()
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, ast.Import):
            for alias in node.names:
                names.add(alias.asname or alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for alias in node.names:
                names.add(alias.asname or alias.name)
    return names


def _import_insertion_lineno(source: str) -> int:
    """Return the 1-based line *after* which new imports should be inserted.

    The convention is "below the module docstring and any existing
    top-level imports, above the first real statement". Returns 0 if
    nothing in the file precedes the first non-import statement, which
    callers interpret as "prepend at top of file".
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return 0
    anchor = 0
    for node in tree.body:
        is_string_expr = (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        )
        if is_string_expr or isinstance(node, (ast.Import, ast.ImportFrom)):
            anchor = node.end_lineno or anchor
        else:
            break
    return anchor


def _insert_imports(source: str, imports: list[str]) -> str:
    """Insert ``imports`` (one per line, already deduped + alphabetised)
    after the module docstring and any existing top-level imports.

    Idempotent against being called twice with the same set — but the
    caller is expected to dedupe against :func:`_collect_imported_names`
    first so we only ever insert the missing names.
    """
    if not imports:
        return source
    block = "\n".join(imports) + "\n"
    anchor = _import_insertion_lineno(source)
    if anchor == 0:
        # No docstring, no existing imports — prepend at top of file.
        # Add a trailing blank line so the next statement isn't glued
        # straight onto the new import.
        return block + "\n" + source if source else block
    lines = source.splitlines(keepends=True)
    head = "".join(lines[:anchor])
    tail = "".join(lines[anchor:])
    if not head.endswith("\n"):
        head += "\n"
    # PEP-8: blank line between the module docstring and the first
    # import. If ``head`` is exactly the docstring (no existing
    # imports), seed that separator before our new import block. We
    # peek at the AST again rather than string-sniffing to stay
    # consistent with the rest of the parsing in this module.
    try:
        head_tree = ast.parse(head)
    except SyntaxError:
        head_tree = None
    head_is_docstring_only = (
        head_tree is not None
        and len(head_tree.body) == 1
        and isinstance(head_tree.body[0], ast.Expr)
        and isinstance(head_tree.body[0].value, ast.Constant)
        and isinstance(head_tree.body[0].value.value, str)
    )
    if head_is_docstring_only:
        block = "\n" + block
    # Tail may start with a blank line or jump straight to the next
    # statement. Normalise to "imports, then blank line, then tail" so
    # ruff / black don't immediately want to rewrap the result.
    if tail and not tail.startswith("\n"):
        block += "\n"
    return head + block + tail


def tool_add_model(
    name: str,
    fields: dict[str, str],
    *,
    per_user: bool = True,
) -> dict[str, Any]:
    """Append a SQLModel class to models.py.

    ``fields`` is a mapping of column name → Python type annotation,
    e.g. ``{"body": "str", "score": "int | None"}``. ``id`` is always
    added automatically.

    When ``per_user=True`` (default), a ``user_id`` column keyed to
    parbaked's ``users.id`` foreign key is also added — the per-user
    side-table convention from AGENTS.md (Note, Setting, etc.). When
    ``per_user=False``, only ``id`` is auto-added; the caller supplies
    any other columns via ``fields`` (#279). Use the False mode for
    global tables (feature_flags, app_settings, webhook_event_log).
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    if (
        not name
        or not name.isidentifier()
        or not name[0].isupper()
        or keyword.iskeyword(name)
    ):
        return {
            "ok": False,
            "error": (
                "model name must be a valid Python identifier starting "
                "with an uppercase letter, and not a reserved keyword"
            ),
        }
    if any(not k.isidentifier() for k in fields):
        return {"ok": False, "error": "every field name must be a valid Python identifier"}
    if any(not _is_safe_annotation(v) for v in fields.values()):
        return {"ok": False, "error": "invalid field annotation"}

    models_py = Path("models.py")

    field_lines = "\n".join(f"    {k}: {v}" for k, v in fields.items())
    if per_user:
        block = textwrap.dedent(f'''

            class {name}(SQLModel, table=True):
                id: int | None = Field(default=None, primary_key=True)
                user_id: UUID = Field(foreign_key="users.id")
            ''')
    else:
        # Global table — no user_id foreign key. Caller adds whatever
        # columns make sense via ``fields``.
        block = textwrap.dedent(f'''

            class {name}(SQLModel, table=True):
                id: int | None = Field(default=None, primary_key=True)
            ''')
    if field_lines:
        block += field_lines + "\n"

    # Names the freshly-rendered class block references at runtime. We
    # diff this against the imports actually present in the file (via
    # ``_collect_imported_names``) and prepend whichever are missing —
    # alphabetised, no duplicates, and only the ones this class needs.
    # ``UUID`` is intentionally absent for global tables: the rendered
    # body doesn't mention it, so dragging the import in would leave an
    # unused-import lint failure in user code.
    required_imports: dict[str, str] = {
        "Field": "from sqlmodel import Field, SQLModel",
        "SQLModel": "from sqlmodel import Field, SQLModel",
    }
    if per_user:
        required_imports["UUID"] = "from uuid import UUID"

    current = models_py.read_text() if models_py.exists() else ""
    have = _collect_imported_names(current)
    missing_statements = sorted({
        stmt for name_, stmt in required_imports.items() if name_ not in have
    })

    new_source = _insert_imports(current, missing_statements) + block

    # Compile-check before persisting — if the result isn't parseable
    # Python we surface a structured error rather than writing broken
    # source (#301 acceptance: "agent learns it didn't work rather than
    # getting a 'success' lie"). We never roll back a previously-good
    # file because we haven't written yet.
    try:
        ast.parse(new_source)
    except SyntaxError as exc:
        return {
            "ok": False,
            "error": f"generated models.py would not parse: {exc.msg} (line {exc.lineno})",
        }

    models_py.write_text(new_source)

    auto_fields = ["id", "user_id"] if per_user else ["id"]
    return {
        "ok": True,
        "file": str(models_py),
        "model": name,
        "fields": list(fields.keys()) + auto_fields,
        "per_user": per_user,
    }


def tool_users_list() -> dict[str, Any]:
    """Return every user as structured JSON. Wraps ``parbaked users list``
    but skips the formatted text — returns the same data raw.

    Shares the underlying query with the CLI surface via
    :func:`parbaked.operations.users.list_users` (#228). This tool's
    job is JSON-formatting + translating the "no users table yet"
    ``OperationalError`` into a friendly hint; the actual query lives
    in the operations layer.
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from sqlalchemy.exc import OperationalError

    from parbaked.cli._db import open_session
    from parbaked.operations.users import list_users

    session = next(open_session())
    try:
        rows = list_users(session)
    except OperationalError as exc:
        # Fresh project that's never been booted has no schema yet —
        # surface a friendly hint instead of a raw SQLAlchemy traceback.
        if "no such table" in str(exc).lower():
            return {
                "ok": False,
                "error": (
                    "users table not initialized — run `parbaked dev` once "
                    "to apply migrations"
                ),
            }
        raise
    return {
        "ok": True,
        "users": [
            {
                "id": str(u.id),
                "email": u.email,
                "name": u.name,
                "status": u.status.value,
                "email_verified": u.email_verified_at is not None,
                "created_at": u.created_at.isoformat(),
            }
            for u in rows
        ],
    }


def tool_users_show(email: str) -> dict[str, Any]:
    """Look up one user by email. Mirrors ``parbaked users show``.

    Returns the same per-row fields ``tool_users_list`` does — id,
    email, name, status, email_verified, created_at, plus the
    ``approved_at`` / ``revoked_at`` lifecycle timestamps callers
    inspecting a single user typically care about (#279). On miss
    returns ``{"ok": False, "error": "no user with email ..."}``.

    Saves the round trip of ``users_list`` + client-side filter when
    the agent already knows the address.
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from sqlalchemy.exc import OperationalError
    from sqlmodel import select

    from parbaked.auth.models import User
    from parbaked.cli._db import open_session

    session = next(open_session())
    try:
        # Emails are stored lower-cased at signup (#164); lower-case
        # the caller's argument so case variants resolve to the same
        # row — same discipline as tool_users_approve.
        user = session.exec(select(User).where(User.email == email.lower())).first()
    except OperationalError as exc:
        # Same friendly-hint translation as tool_users_list — a fresh
        # project that's never been booted has no users table yet.
        if "no such table" in str(exc).lower():
            return {
                "ok": False,
                "error": (
                    "users table not initialized — run `parbaked dev` once "
                    "to apply migrations"
                ),
            }
        raise
    if user is None:
        return {"ok": False, "error": f"no user with email {email}"}
    return {
        "ok": True,
        "user": {
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "status": user.status.value,
            "email_verified": user.email_verified_at is not None,
            "email_verified_at": (
                user.email_verified_at.isoformat()
                if user.email_verified_at is not None
                else None
            ),
            "created_at": user.created_at.isoformat(),
            "approved_at": (
                user.approved_at.isoformat() if user.approved_at is not None else None
            ),
            "revoked_at": (
                user.revoked_at.isoformat() if user.revoked_at is not None else None
            ),
        },
    }


def _mcp_safe_email_transport(config):
    """Return an EmailTransport safe to use over the MCP stdio channel.

    MCP speaks newline-delimited JSON-RPC over stdout — anything a tool
    writes to ``sys.stdout`` that isn't a valid JSON-RPC frame breaks
    the transport (#330). The default ``ConsoleEmail`` returned by
    :func:`make_email_transport` writes the rendered email straight to
    stdout, which is fine for ``parbaked dev`` but catastrophic for the
    agent surface.

    We swap it for a ``StringIO``-backed ``ConsoleEmail`` that captures
    the rendered output in-memory instead of touching stdout. Real
    transports (``ResendEmail``) are passed through unchanged — they
    don't write to stdout.

    Returns ``(transport, buffer)`` — ``buffer`` is the ``StringIO`` we
    captured into when we swapped, or ``None`` when we passed a real
    transport through. The tool surfaces the captured preview to the
    agent so audit visibility isn't lost.
    """
    from parbaked.cli._db import make_email_transport
    from parbaked.email.console import ConsoleEmail

    transport = make_email_transport(config)
    if isinstance(transport, ConsoleEmail):
        buffer = StringIO()
        return ConsoleEmail(buffer=buffer, config=config), buffer
    return transport, None


def _email_preview_from_buffer(buffer) -> str | None:
    """Return a (possibly truncated) preview of a captured email buffer.

    Caps the response at 4 KiB so a multi-attachment HTML mail doesn't
    bloat the JSON-RPC frame. ``None`` if nothing was captured (real
    transport path, or the swap didn't fire).
    """
    if buffer is None:
        return None
    text = buffer.getvalue()
    if not text:
        return None
    limit = 4096
    if len(text) > limit:
        return text[:limit] + f"\n... [truncated, full size {len(text)} bytes]"
    return text


def tool_users_approve(email: str) -> dict[str, Any]:
    """Wraps ``parbaked users approve``. Returns whether the row
    transitioned (False = was already active).

    Note: when the project is in console-email mode (no ``resend_key``
    configured), the rendered approval email is captured in-memory and
    returned in ``email_preview`` instead of being written to stdout —
    stdout is the MCP JSON-RPC transport and any non-frame bytes there
    corrupt the channel (#330).
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from sqlmodel import select

    from parbaked.auth.models import User
    from parbaked.auth.service import approve_user
    from parbaked.cli._db import load_config, open_session
    from parbaked.email.templates import Templates
    from parbaked.hooks import load_consumer_hooks

    config = load_config()
    transport, preview_buffer = _mcp_safe_email_transport(config)
    session = next(open_session())
    # Emails are stored lower-cased at signup (#164); lower-case the
    # caller's argument so case variants resolve to the same row.
    user = session.exec(select(User).where(User.email == email.lower())).first()
    if user is None:
        return {"ok": False, "error": f"no user with email {email}"}
    # Autoload the consumer's ``hooks.py`` so ``on_approve`` fires on the
    # MCP path too — fix for #356, the regression-after-#332 where the
    # CLI was patched but the MCP surface was missed. ``load_consumer_hooks``
    # lazy-imports ``parbaked.runtime`` so the FastAPI cost only lands when
    # an MCP tool actually needs it (boot stays slim).
    changed = approve_user(
        user, session,
        config=config, email=transport,
        templates=Templates(), hooks=load_consumer_hooks(), via="mcp",
    )
    response: dict[str, Any] = {
        "ok": True,
        # Return the canonical (stored, lower-cased) form, not the caller's
        # input — downstream consumers want one address per user, not one
        # per case-variant. Devin Review on PR #215.
        "email": user.email,
        "status": "active",
        "changed": changed,
    }
    preview = _email_preview_from_buffer(preview_buffer)
    if preview is not None:
        response["email_preview"] = preview
    return response


def tool_users_reject(email: str, *, no_email: bool = False) -> dict[str, Any]:
    """Reject a user by email. Symmetric to ``tool_users_approve``.

    Wraps :func:`parbaked.auth.service.reject_user` — the same function
    the CLI ``parbaked users reject`` and dashboard reject-button call,
    so the audit event, hook firing, and ``revoked_at`` rotation
    (#37) are identical across surfaces.

    Idempotent — re-rejecting a rejected user returns
    ``changed=False`` without touching the row or sending a
    duplicate notification email (#279).

    ``no_email=True`` swaps in a do-nothing transport so the rejection
    notice is suppressed. Useful when the agent is moderating a junk
    queue and doesn't want to re-send mail to addresses that are
    already obviously fake — mirrors the CLI's ``--no-email`` flag.

    When ``no_email=False`` and the project is in console-email mode,
    the rendered rejection email is captured in-memory and surfaced in
    ``email_preview`` rather than written to stdout — stdout is the MCP
    JSON-RPC transport (#330).
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from sqlmodel import select

    from parbaked.auth.models import User
    from parbaked.auth.service import reject_user
    from parbaked.cli._db import load_config, open_session
    from parbaked.email.base import EmailTransport
    from parbaked.email.templates import Templates
    from parbaked.hooks import load_consumer_hooks

    config = load_config()
    transport: EmailTransport
    preview_buffer: StringIO | None
    if no_email:
        # Local no-op transport — matches the CLI's _NullEmail. Defined
        # inline because this is the only MCP tool that needs it; if a
        # second tool ever wants the same skip-email switch we can hoist.
        class _NullTransport:
            def send(self, message):  # noqa: ARG002 — protocol stub
                return None

        transport = _NullTransport()  # type: ignore[assignment]
        preview_buffer = None
    else:
        transport, preview_buffer = _mcp_safe_email_transport(config)
    session = next(open_session())
    # Emails are stored lower-cased at signup (#164); lower-case the
    # caller's input so case variants resolve to the same row.
    user = session.exec(select(User).where(User.email == email.lower())).first()
    if user is None:
        return {"ok": False, "error": f"no user with email {email}"}
    # Autoload the consumer's ``hooks.py`` so ``on_reject`` fires on the
    # MCP path too — symmetric with the approve fix above (#356).
    changed = reject_user(
        user, session,
        config=config, email=transport,
        templates=Templates(), hooks=load_consumer_hooks(), via="mcp",
    )
    response: dict[str, Any] = {
        "ok": True,
        # Return the canonical (lower-cased, stored) email — mirrors
        # tool_users_approve so consumers get one address per user
        # regardless of caller case (Devin Review on PR #215).
        "email": user.email,
        "status": "rejected",
        "changed": changed,
    }
    preview = _email_preview_from_buffer(preview_buffer)
    if preview is not None:
        response["email_preview"] = preview
    return response


def tool_users_issue_reset(email: str) -> dict[str, Any]:
    """Mint a one-shot password-reset URL for a user. Mirrors
    ``parbaked users issue-reset`` (#280).

    Useful when the app is running in dashboard-only mode (no email
    transport), or when the real reset email bounced and the admin
    needs to hand the link to the user over a trusted channel. The
    token is bound to the user's current ``password_hash`` (via
    :func:`parbaked.auth.tokens.create_password_reset_token`) — once
    the password changes, every outstanding reset URL for that
    account fails verification.

    Returns ``{"ok": True, "url": "...", "valid_for_hours": N}``. The
    URL carries the reset token by design — that's how a magic link
    works. The agent hands the URL to the user out-of-band.

    Mirrors the CLI's ``PARBAKED_APP_URL`` warning: if the base URL
    isn't configured anywhere parbaked respects (env, ``.env``, or
    ``parbaked.toml``) we include a ``warning`` field so the caller
    can surface it. The link is generated against ``config.app_url``
    either way — same shape as the CLI.
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from sqlmodel import select

    from parbaked.auth.models import User
    from parbaked.auth.tokens import create_password_reset_token
    from parbaked.cli._db import load_config, open_session
    from parbaked.cli.ops import (
        _read_dev_port,
        _user_set_app_url,
        resolved_localhost_base_url,
    )

    config = load_config()
    # Mirror tool_admin_signin's guard: without a signing secret,
    # ``create_password_reset_token`` raises ``RuntimeError`` and the
    # MCP call surfaces as an unhandled crash instead of a structured
    # error response (#280 Devin).
    if not config.effective_approval_secret():
        return {
            "ok": False,
            "error": (
                "No JWT / approval-token secret configured. Set "
                "PARBAKED_JWT_SECRET (or PARBAKED_APPROVAL_TOKEN_SECRET) "
                "and try again."
            ),
        }
    session = next(open_session())
    # Emails are stored lower-cased at signup (#164); lower-case the
    # caller's input so case variants resolve to the same row — same
    # discipline as tool_users_approve / tool_users_reject.
    user = session.exec(select(User).where(User.email == email.lower())).first()
    if user is None:
        return {"ok": False, "error": f"no user with email {email}"}

    reset_token = create_password_reset_token(user.id, user.password_hash, config)
    # Resolve via the shared helper so the URL auto-targets a sibling
    # ``parbaked dev --port N`` via ``.parbaked/dev_port`` (#333) — same
    # behaviour as the CLI's ``users issue-reset``.
    base_url = resolved_localhost_base_url(config)
    reset_url = f"{base_url}/auth/reset/{reset_token}"

    response: dict[str, Any] = {
        "ok": True,
        "email": user.email,
        "url": reset_url,
        "valid_for_hours": config.password_reset_expiry_hours,
    }
    # Warn only when BOTH the explicit-config path AND the running-dev
    # path failed to anchor the URL — the link target is genuinely
    # ambiguous then. With ``.parbaked/dev_port`` (#333) we no longer
    # warn just because env/.env/parbaked.toml is unset.
    if not _user_set_app_url() and _read_dev_port() is None:
        response["warning"] = (
            f"Generated reset URL for {base_url}. If your dev server is "
            "running on a different host/port, set "
            "PARBAKED_APP_URL=http://localhost:<port> before calling this tool."
        )
    return response


def tool_admin_signin() -> dict[str, Any]:
    """Mint a one-shot admin sign-in URL — break-glass recovery (#280).

    Mirrors ``parbaked admin signin``. Uses the project's local JWT
    secret via :func:`parbaked.auth.tokens.create_admin_signin_token`
    so the running app verifies the URL without any additional state.

    After #205, the token is bound to the current per-admin nonce
    stored in ``_parbaked_admin_signin_nonce``; the first verify
    rotates the nonce, so the URL is genuinely one-shot — any second
    use (or any peer URL minted off the same prior nonce) fails the
    rotation check.

    Returns ``{"ok": True, "url": "...", "valid_minutes": 15}``. The
    URL carries the signin token by design — same security shape as
    the CLI command. Anyone holding the URL becomes admin until exp
    (or until another signin burns the nonce).
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from sqlmodel import Session

    from parbaked.auth.tokens import (
        _ADMIN_SIGNIN_TTL_MINUTES,
        create_admin_signin_token,
    )
    from parbaked.cli._db import load_config, open_engine

    config = load_config()
    if not config.effective_approval_secret():
        return {
            "ok": False,
            "error": (
                "No JWT / approval-token secret configured. Set "
                "PARBAKED_JWT_SECRET (or PARBAKED_APPROVAL_TOKEN_SECRET) "
                "and try again."
            ),
        }

    engine = open_engine()
    with Session(engine) as session:
        token = create_admin_signin_token(config, session)
    # Match the CLI: auto-detect a sibling ``parbaked dev``'s bound port
    # via ``.parbaked/dev_port`` so the minted URL actually resolves to
    # the running server even when ``--port`` differs from 8000 (#333).
    from parbaked.cli.ops import resolved_localhost_base_url

    base_url = resolved_localhost_base_url(config)
    url = f"{base_url}/auth/admin/signin/{token}"

    return {
        "ok": True,
        "url": url,
        "valid_minutes": _ADMIN_SIGNIN_TTL_MINUTES,
    }


def tool_eject(
    target_dir: str | None = None,
    *,
    force: bool = False,
) -> dict[str, Any]:
    """Run ``parbaked eject`` and return the produced artifact list (#280).

    Mirrors the CLI command — calls :func:`parbaked.eject` (lifted to
    the public surface per #229) to produce a self-contained
    off-boarding export: schema.sql + data/*.csv + Dockerfile +
    fly.toml + .env.example + MANIFEST.md.

    ``target_dir`` defaults to ``./parbaked-export`` (the same default
    the CLI uses). The path must stay inside cwd — defence-in-depth
    from #285. Same containment discipline as ``tool_scaffold`` (#152).

    Eject refuses to write into a non-empty directory unless either
    (a) the directory already contains a prior parbaked-export
    MANIFEST.md, or (b) ``force=True`` is passed. Eject does NOT
    ``shutil.rmtree`` the target — files are overwritten by name, so
    unrelated artifacts in the target survive (#290).

    Returns ``{"ok": True, "target": "<abs path>", "files": [...]}``
    on success, ``{"ok": False, "error": "..."}`` on a refused
    overwrite. ``files`` lists the export's artifacts —
    schema/Dockerfile/fly.toml/.env.example/MANIFEST.md plus each
    data CSV. The agent can then read MANIFEST.md or the CSVs
    directly if it wants to verify the dump shape.
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}

    from parbaked.cli._db import load_config
    from parbaked.eject import DEFAULT_OUTPUT
    from parbaked.eject import eject as _eject
    from parbaked.exceptions import EjectError

    target_path = (
        DEFAULT_OUTPUT if target_dir is None else Path(target_dir).expanduser()
    )

    # Resolve through cwd so a relative path lands inside the project,
    # an absolute path is honoured, and the containment check below
    # can reason against the resolved form. Resolve the parent because
    # the target itself may not exist yet on first call.
    target_abs = (
        target_path
        if target_path.is_absolute()
        else (Path.cwd() / target_path)
    ).resolve()
    cwd = Path.cwd().resolve()
    # Containment stays as defence-in-depth even though eject no longer
    # rmtree's the target (#290): an agent invoking ``tool_eject`` with
    # ``target_dir="."`` and ``force=True`` would otherwise scatter
    # schema.sql / Dockerfile / fly.toml / .env.example / MANIFEST.md
    # into the project root, clobbering live files. The scaffold tool's
    # containment check intentionally allows ``parent == cwd`` because
    # scaffold creates a subdirectory; eject's contract is different.
    # (#280 Devin — critical-vector belt; #290 — refuse-or-overwrite is
    # the braces.)
    if target_abs == cwd or not target_abs.is_relative_to(cwd):
        return {
            "ok": False,
            "error": (
                "eject target_dir must be a STRICT subdirectory of the "
                "current working directory — pointing at cwd itself would "
                "scatter export files across the project tree."
            ),
        }

    config = load_config()
    try:
        out = _eject(target_abs, config=config, force=force)
    except EjectError as exc:
        return {"ok": False, "error": str(exc)}

    # List the artifacts written so the agent can read / iterate without
    # an extra directory walk. Sort for determinism — the agent shouldn't
    # have to assume any particular ordering, but stable output makes
    # the tool predictable.
    files = sorted(
        str(p.relative_to(out))
        for p in out.rglob("*")
        if p.is_file()
    )
    return {
        "ok": True,
        "target": str(out),
        "files": files,
    }


def tool_email_setup_status() -> dict[str, Any]:
    """Report whether Resend is configured and which email mode is active.

    Delegates to :func:`parbaked.operations.email_status.email_status_dict`
    so this surface and the CLI's ``parbaked email status`` command
    return the exact same shape (#338).
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    from parbaked.cli._db import load_config
    from parbaked.operations.email_status import email_status_dict

    return email_status_dict(load_config())


def tool_deploy_status() -> dict[str, Any]:
    """Report whether ``parbaked deploy`` has run, with the fly URL if so."""
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    state_path = Path(".parbaked/deploy.json")
    if not state_path.exists():
        return {"ok": True, "deployed": False}
    try:
        state = json.loads(state_path.read_text())
    except json.JSONDecodeError:
        return {"ok": True, "deployed": False}
    app_name = state.get("fly_app_name")
    return {
        "ok": True,
        "deployed": bool(app_name),
        "fly_app_name": app_name,
        "url": f"https://{app_name}.fly.dev" if app_name else None,
        "first_deploy_at": state.get("first_deploy_at"),
    }


def tool_status() -> dict[str, Any]:
    """Single-screen project state. Mirrors ``parbaked status`` output (#279).

    Today an agent has to call ``email_setup_status`` AND
    ``deploy_status`` separately and reassemble the picture. This one
    returns the same data sources the CLI's :func:`parbaked.cli.main.status`
    command pulls (load_config, .parbaked/deploy.json, SchemaVersion,
    .parbaked.json key list) in a single structured dict — no
    typer.echo / rich line formatting, no walls of color codes.

    Secret values are NEVER returned — only the *names* of keys present
    in ``.parbaked.json``. Even partial values give an attacker a head
    start on brute-forcing the rest, and tooling that prints secrets is
    how secrets leak into shell history / screenshots / pair sessions.
    The CLI status command has the same discipline.
    """
    import json as _json

    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}

    from parbaked import __version__
    from parbaked.cli._db import load_config

    config = load_config()

    # Email block — same logic as tool_email_setup_status, returned as
    # a nested dict so the agent doesn't have to second-guess which
    # top-level keys are present in which mode.
    if not config.email_enabled:
        email_block: dict[str, Any] = {"mode": "disabled"}
    elif config.resend_key:
        email_block = {
            "mode": "resend",
            "from": config.effective_mail_from(),
            "admin_email": config.admin_email,
        }
    else:
        email_block = {
            "mode": "console",
            "admin_email": config.admin_email,
        }

    # Deploy block — same logic as tool_deploy_status. Always present
    # so the consumer can branch on ``deploy.deployed`` without
    # checking for key existence first.
    deploy_block: dict[str, Any] = {"deployed": False}
    state_path = Path(".parbaked/deploy.json")
    if state_path.exists():
        try:
            state = _json.loads(state_path.read_text())
        except (OSError, _json.JSONDecodeError):
            state = {}
        fly_app_name = state.get("fly_app_name")
        if fly_app_name:
            deploy_block = {
                "deployed": True,
                "fly_app_name": fly_app_name,
                "url": f"https://{fly_app_name}.fly.dev",
                "first_deploy_at": state.get("first_deploy_at"),
            }

    # Migration status — best-effort. A brand-new project that hasn't
    # booted yet has no DB. We mirror the CLI's "no DB yet" /
    # "applied N / latest M" shape but as structured fields so the
    # agent doesn't have to regex a free-form line.
    migrations_block: dict[str, Any] = {"state": "unknown"}
    try:
        from parbaked.migrations import LATEST_VERSION

        latest = LATEST_VERSION() if callable(LATEST_VERSION) else LATEST_VERSION
    except ImportError:
        latest = None
    try:
        from sqlalchemy import inspect as _sa_inspect
        from sqlmodel import Session, select

        from parbaked.auth.models import SchemaVersion
        from parbaked.cli._db import open_engine

        engine = open_engine()
        inspector = _sa_inspect(engine)
        if inspector.has_table("_parbaked_schema_version"):
            with Session(engine) as session:
                row = session.exec(select(SchemaVersion)).first()
                current = row.version if row else 0
            migrations_block = {
                "state": "applied",
                "applied": current,
                "latest": latest,
                "up_to_date": (latest is not None and current == latest),
            }
        else:
            migrations_block = {"state": "no_db"}
    except Exception as exc:  # noqa: BLE001 — status must never crash
        migrations_block = {"state": "error", "error_type": exc.__class__.__name__}

    # Secret names only — values are never returned. Same discipline as
    # the CLI's status command.
    secrets_block: dict[str, Any]
    secrets_path = Path(".parbaked.json")
    if secrets_path.exists():
        try:
            stored = _json.loads(secrets_path.read_text())
        except (OSError, _json.JSONDecodeError):
            stored = {}
        secrets_block = {"file": str(secrets_path), "names": sorted(stored.keys())}
    else:
        secrets_block = {"file": None, "names": []}

    return {
        "ok": True,
        "parbaked_version": __version__,
        "app_name": config.app_name,
        "app_url": config.app_url,
        "env": str(config.env),
        # ``database_url`` is a config field, not a secret in the
        # ``.parbaked.json`` sense — SQLite URLs are paths, Postgres
        # URLs are deploy-time configured. The CLI status prints it
        # verbatim and we mirror that.
        "database_url": str(config.database_url),
        "email": email_block,
        "deploy": deploy_block,
        "migrations": migrations_block,
        "secrets": secrets_block,
    }


def tool_dev(port: int = 8000) -> dict[str, Any]:
    """Start ``parbaked dev`` in the background. Returns the local URL.

    The dev server is left running; the agent should expect the user to
    interact with the running app and call ``deploy`` when ready.
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    # Idempotency guard (#184): if something's already listening on this
    # port, assume it's a previous ``tool_dev`` call's uvicorn and return
    # the same URLs without spawning a doomed second process.
    if _port_in_use(port):
        return {
            "ok": True,
            "url": f"http://localhost:{port}",
            "admin_url": f"http://localhost:{port}/auth/admin",
            "note": "dev server already running on this port; not respawning",
        }
    # Use Popen + DEVNULL so the MCP transport isn't blocked by stdout.
    log_path = Path(".parbaked/dev.log")
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = log_path.open("a")
    cmd = ["uvicorn", "parbaked.runtime:create_app", "--factory",
           "--port", str(port), "--host", "127.0.0.1", "--reload"]
    # Mirror `parbaked dev` (cli/ops.py): prefer `uv run uvicorn` so we
    # pin to the project pyproject + auto-recover from "no .venv yet"
    # rather than launching whatever ``uvicorn`` happens to be first on
    # $PATH.
    if shutil.which("uv") is not None:
        cmd = ["uv", "run", *cmd]
    proc = subprocess.Popen(
        cmd,
        stdout=log_file,
        stderr=subprocess.STDOUT,
        env={**os.environ, "PARBAKED_APP_URL": f"http://localhost:{port}"},
    )
    return {
        "ok": True,
        "pid": proc.pid,
        "url": f"http://localhost:{port}",
        "admin_url": f"http://localhost:{port}/auth/admin",
        "log": str(log_path),
    }


def tool_deploy() -> dict[str, Any]:
    """Run the deploy operation synchronously. Returns the live URL on
    success. This is the "ship it" tool — assumes ``parbaked init`` has
    already onboarded the project to fly.

    Pre-#228 this tool shelled out to the CLI binary
    (``subprocess.run(["parbaked", "deploy"])``) because there was no
    Python entry point for "deploy". Now both surfaces call
    :func:`parbaked.operations.deploy.run_deploy` directly so the MCP
    and CLI surfaces can't drift.
    """
    if not _in_parbaked_project():
        return {"ok": False, "error": "not in a parbaked project (no parbaked.toml)"}
    # Reuse the wizard's state to grab the fly app name.
    from parbaked.cli.deploy_wizard import _load_state, already_onboarded
    if not already_onboarded():
        return {
            "ok": False,
            "error": (
                "Project hasn't been onboarded to fly yet. Run "
                "`parbaked init` from a terminal first — it handles the "
                "fly auth + launch flow which doesn't fit cleanly into "
                "the MCP model (it opens a browser, prompts for input)."
            ),
        }
    if shutil.which("fly") is None:
        return {
            "ok": False,
            "error": (
                "flyctl is not installed. Install it from "
                "https://fly.io/docs/flyctl/install/ "
                "(or `brew install flyctl` on macOS) and try again."
            ),
        }
    from parbaked.cli._db import load_config
    from parbaked.exceptions import ParbakedError
    from parbaked.operations.deploy import run_deploy

    try:
        config = load_config()
        rc = run_deploy(config)
    except (ParbakedError, ValueError) as exc:
        # ``ValueError`` covers malformed parbaked.toml — pydantic-settings'
        # toml source raises ``tomllib.TOMLDecodeError`` (a ``ValueError``
        # subclass) on syntax errors. ``ParbakedError`` covers the
        # generator's own friendly-error path (#121, #193, #221). Devin
        # caught that narrowing to only ParbakedError dropped malformed-
        # toml back into an unhandled exception inside MCP.
        return {"ok": False, "error": str(exc)}
    if rc != 0:
        return {"ok": False, "error": f"fly deploy exited {rc}"}
    state = _load_state()
    app_name = state.get("fly_app_name", "")
    return {
        "ok": True,
        "url": f"https://{app_name}.fly.dev" if app_name else None,
        "fly_app_name": app_name,
    }


# --------------------------------------------------------------------- server


def build_server():
    """Construct a FastMCP server registering every tool.

    Lazy-imports the ``mcp`` package so the parbaked kernel install
    stays slim. Raises ``ImportError`` with a clean install hint if the
    optional extra isn't present.
    """
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as exc:
        raise ImportError(
            "parbaked MCP server requires the optional ``mcp`` extra. "
            "Install with: pip install 'parbaked[mcp]'"
        ) from exc

    from parbaked import __version__

    # FastMCP itself doesn't take ``version`` as a kwarg in current mcp
    # SDKs — but the low-level Server it wraps (``_mcp_server``) does.
    # Without this, clients see the mcp SDK's own version on Initialize
    # responses, not parbaked's. Set it via the wrapped Server so the
    # protocol surfaces the parbaked release the user installed.
    try:
        server = FastMCP("parbaked", version=__version__)  # type: ignore[call-arg]
    except TypeError:
        # Current mcp SDK: FastMCP signature doesn't accept ``version``.
        # Construct normally, then patch the underlying Server.
        server = FastMCP("parbaked")
        inner = getattr(server, "_mcp_server", None)
        if inner is not None:
            with contextlib.suppress(AttributeError):
                inner.version = __version__

    for name, (description, fn) in TOOLS.items():
        server.tool(name=name, description=description)(fn)

    return server


def run() -> None:
    """Entry point for ``parbaked mcp`` CLI command. Blocks on stdio."""
    server = build_server()
    server.run()


# Single source of truth for the MCP tool surface (#263). ``build_server``
# iterates this dict; tests import it to assert the registered set matches.
# Adding a new tool means editing one place — no parallel ``registrations``
# list to keep in sync.
TOOLS: dict[str, tuple[str, Callable[..., dict[str, Any]]]] = {
    "scaffold": ("Scaffold a new parbaked project", tool_scaffold),
    "add_route": ("Generate a routes/*.py file with an empty handler", tool_add_route),
    "add_model": (
        "Append a SQLModel table to models.py. By default (``per_user=True``) "
        "the table is keyed on users.id (per-user side-table convention). "
        "Pass ``per_user=False`` for a global table (#279).",
        tool_add_model,
    ),
    "dev": ("Start the local dev server in the background; returns the URL", tool_dev),
    "status": (
        "Single-screen project state — app config, email mode, deploy "
        "status, migration version, and the NAMES of secrets in "
        ".parbaked.json (never values). Mirrors `parbaked status` (#279).",
        tool_status,
    ),
    "users_list": ("Every parbaked user as structured JSON", tool_users_list),
    "users_show": (
        "Look up a single user by email — same fields users_list returns "
        "for that row, plus approved_at / revoked_at lifecycle timestamps "
        "(#279).",
        tool_users_show,
    ),
    "users_approve": ("Approve a pending user by email", tool_users_approve),
    "users_reject": (
        "Reject a user by email — symmetric to users_approve. Idempotent; "
        "returns changed=False if the user is already rejected (#279).",
        tool_users_reject,
    ),
    "users_issue_reset": (
        "Mint a one-shot password-reset URL for a user (mirrors "
        "`parbaked users issue-reset`). The URL carries the reset "
        "token by design — hand it to the user over a trusted "
        "channel. Bound to the user's current password_hash, so any "
        "successful reset invalidates outstanding links (#280).",
        tool_users_issue_reset,
    ),
    "admin_signin": (
        "Mint a one-shot admin sign-in URL — break-glass recovery "
        "(mirrors `parbaked admin signin`). Uses the local JWT "
        "secret + the DB-backed admin nonce (#205) so the link is "
        "genuinely one-shot — first verify burns the nonce, peer "
        "URLs minted off the same prior nonce stop working (#280).",
        tool_admin_signin,
    ),
    "eject": (
        "Run `parbaked eject` — produce a self-contained "
        "off-boarding export (schema.sql + CSVs + Dockerfile + "
        "fly.toml + .env.example + MANIFEST.md). target_dir "
        "defaults to ./parbaked-export and must stay inside cwd. "
        "Refuses to overwrite a non-empty directory unless it's a "
        "prior parbaked-export or force=True is passed; eject "
        "never rmtrees the target (#290). Returns the artifact "
        "list so the agent can read MANIFEST.md or the CSVs "
        "directly (#280).",
        tool_eject,
    ),
    "email_setup_status": ("Report current email transport mode", tool_email_setup_status),
    "deploy_status": ("Whether the project has been deployed to fly.io", tool_deploy_status),
    "deploy": ("Redeploy to fly.io (requires prior `parbaked init`)", tool_deploy),
}


# Quiet a bunch of unused-import linters that look at the module surface.
_ = contextlib
