"""Memory system for persistent agent memory."""

from __future__ import annotations

import asyncio
import json
import weakref
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from loguru import logger

from shibaclaw.helpers.helpers import ensure_dir, estimate_message_tokens, estimate_prompt_tokens, estimate_prompt_tokens_chain

if TYPE_CHECKING:
    from shibaclaw.thinkers.base import Thinker
    from shibaclaw.brain.manager import Session, PackManager


_SAVE_MEMORY_TOOL = [
    {
        "type": "function",
        "function": {
            "name": "save_memory",
            "description": "Save the memory consolidation result to persistent storage.",
            "parameters": {
                "type": "object",
                "properties": {
                    "history_entry": {
                        "type": "string",
                        "description": "A paragraph summarizing key events/decisions/topics. "
                        "Start with [YYYY-MM-DD HH:MM] [#tag1 #tag2 ...]. "
                        "Tags are topic keywords prefixed with # for grep search (e.g. #python #debugging #project-foo). "
                        "Include detail useful for grep search.",
                    },
                    "memory_update": {
                        "type": "string",
                        "description": "Deduplicated, concise Markdown fact sheet. Preserve all important facts "
                        "from current memory. Remove duplicates, redundant wording, and obsolete context. "
                        "Target: under 1500 tokens. If nothing new, return current content unchanged.",
                    },
                },
                "required": ["history_entry", "memory_update"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "update_long_term_memory",
            "description": "Update the long-term memory with new facts or refined preferences extracted from recent conversation. This does NOT summarize history, only updates the fact sheet.",
            "parameters": {
                "type": "object",
                "properties": {
                    "memory_update": {
                        "type": "string",
                        "description": "Deduplicated, concise Markdown fact sheet. Preserve all important facts "
                        "from current memory. Add new findings and remove outdated or redundant entries. "
                        "Target: under 1500 tokens. If nothing new, return the exact current content.",
                    },
                },
                "required": ["memory_update"],
            },
        },
    }
]


def _ensure_text(value: Any) -> str:
    """Normalize tool-call payload values to text for file storage."""
    return value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)


def _normalize_save_memory_args(args: Any) -> dict[str, Any] | None:
    """Normalize provider tool-call arguments to the expected dict shape."""
    if isinstance(args, str):
        args = json.loads(args)
    if isinstance(args, list):
        return args[0] if args and isinstance(args[0], dict) else None
    return args if isinstance(args, dict) else None


def _normalize_update_memory_args(args: Any) -> dict[str, Any] | None:
    """Normalize update_long_term_memory payload."""
    if isinstance(args, str):
        args = json.loads(args)
    if isinstance(args, list):
        return args[0] if args and isinstance(args[0], dict) else None
    return args if isinstance(args, dict) else None

_TOOL_CHOICE_ERROR_MARKERS = (
    "tool_choice",
    "toolchoice",
    "does not support",
    'should be ["none", "auto"]',
)


def _is_tool_choice_unsupported(content: str | None) -> bool:
    """Detect provider errors caused by forced tool_choice being unsupported."""
    text = (content or "").lower()
    return any(m in text for m in _TOOL_CHOICE_ERROR_MARKERS)


class ScentKeeper:
    """Two-layer memory: MEMORY.md (long-term facts) + HISTORY.md (grep-searchable log)."""

    _MAX_FAILURES_BEFORE_RAW_ARCHIVE = 3

    def __init__(self, workspace: Path):
        self.memory_dir = ensure_dir(workspace / "memory")
        self.memory_file = self.memory_dir / "MEMORY.md"
        self.history_file = self.memory_dir / "HISTORY.md"
        self._consecutive_failures = 0
        self._file_lock = asyncio.Lock()

    def read_long_term(self) -> str:
        if self.memory_file.exists():
            return self.memory_file.read_text(encoding="utf-8")
        return ""

    async def write_long_term(self, content: str) -> None:
        async with self._file_lock:
            self.memory_file.write_text(content, encoding="utf-8")

    async def append_history(self, entry: str) -> None:
        """Prepend new entry so most recent archives appear at the top."""
        async with self._file_lock:
            existing = ""
            if self.history_file.exists():
                existing = self.history_file.read_text(encoding="utf-8")
            new_content = entry.rstrip() + "\n\n" + existing
            self.history_file.write_text(new_content, encoding="utf-8")

    def estimate_memory_tokens(self) -> int:
        """Estimate token count of the current MEMORY.md content."""
        content = self.read_long_term()
        if not content:
            return 0
        return estimate_prompt_tokens([{"role": "user", "content": content}])

    def get_memory_context(self, max_tokens: int = 0) -> str:
        """Return long-term memory for system prompt injection.

        If *max_tokens* > 0 and the content exceeds the budget, sections
        are dropped from the bottom up (keeping headers) and a truncation
        marker is appended.
        """
        long_term = self.read_long_term()
        if not long_term:
            return ""

        if max_tokens > 0:
            tokens = estimate_prompt_tokens([{"role": "user", "content": long_term}])
            if tokens > max_tokens:
                long_term = self._truncate_to_budget(long_term, max_tokens)

        return f"## Long-term Memory\n{long_term}" if not long_term.lstrip().startswith("#") else long_term

    @staticmethod
    def _truncate_to_budget(text: str, max_tokens: int) -> str:
        """Keep Markdown sections from the top until the token budget is exhausted."""
        import re as _re
        sections = _re.split(r'(?=^## )', text, flags=_re.MULTILINE)
        kept: list[str] = []
        for section in sections:
            candidate = "\n".join(kept + [section])
            tokens = estimate_prompt_tokens([{"role": "user", "content": candidate}])
            if tokens > max_tokens and kept:
                break
            kept.append(section)
        truncated = "\n".join(kept).rstrip()
        return truncated + "\n\n[MEMORY TRUNCATED — search HISTORY.md for older context]"

    @staticmethod
    def _format_messages(messages: list[dict]) -> str:
        lines = []
        for message in messages:
            role = message.get("role", "unknown").upper()
            ts = message.get("timestamp", "?")[:16]
            
            content = message.get("content") or ""
            
            if role == "ASSISTANT" and message.get("tool_calls"):
                calls = [tc.get("function", {}).get("name", "unknown") for tc in message["tool_calls"]]
                if content:
                    content += "\n"
                content += f"[Tool Calls: {', '.join(calls)}]"
                
            if role == "TOOL" and content:
                if len(content) > 300:
                    content = content[:150] + "\n...[TRUNCATED]...\n" + content[-150:]

            # Cap user and assistant messages to keep consolidation prompts lean.
            if role in ("USER", "ASSISTANT") and len(content) > 500:
                content = content[:250] + "\n...[TRUNCATED]...\n" + content[-250:]
            
            if not content.strip():
                continue
                
            # Keep legacy 'tools_used' logic if it exists (for old traces)
            tools = f" [skunted: {', '.join(message['tools_used'])}]" if message.get("tools_used") else ""
            lines.append(f"[{ts}] {role}{tools}: {content.strip()}")
            
        return "\n".join(lines)

    async def consolidate(
        self,
        messages: list[dict],
        provider: Thinker,
        model: str,
    ) -> bool:
        """Consolidate the provided message chunk into MEMORY.md + HISTORY.md."""
        if not messages:
            return True

        current_memory = self.read_long_term()
        prompt = f"""Process this conversation and call the save_memory tool with your consolidation.

## Current Long-term Memory
{current_memory or "(empty)"}

## Conversation to Process
{self._format_messages(messages)}"""

        chat_messages = [
            {"role": "system", "content": "You are a memory consolidation Shiba. Call the save_memory tool with your consolidation of the hunt."},
            {"role": "user", "content": prompt},
        ]

        try:
            forced = {"type": "function", "function": {"name": "save_memory"}}
            response = await provider.chat_with_retry(
                messages=chat_messages,
                tools=_SAVE_MEMORY_TOOL,
                model=model,
                tool_choice=forced,
            )

            if response.finish_reason == "error" and _is_tool_choice_unsupported(
                response.content
            ):
                logger.warning("Forced tool_choice unsupported, retrying with auto")
                response = await provider.chat_with_retry(
                    messages=chat_messages,
                    tools=_SAVE_MEMORY_TOOL,
                    model=model,
                    tool_choice="auto",
                )

            if not response.has_tool_calls:
                logger.warning(
                    "Memory consolidation: Shiba did not call save_memory "
                    "(finish_reason={}, content_len={}, content_preview={})",
                    response.finish_reason,
                    len(response.content or ""),
                    (response.content or "")[:200],
                )
                return await self._fail_or_raw_archive(messages)

            args = _normalize_save_memory_args(response.tool_calls[0].arguments)
            if args is None:
                logger.warning("Memory consolidation: unexpected save_memory arguments")
                return await self._fail_or_raw_archive(messages)

            if "history_entry" not in args or "memory_update" not in args:
                logger.warning("Memory consolidation: save_memory payload missing required fields")
                return await self._fail_or_raw_archive(messages)

            entry = args["history_entry"]
            update = args["memory_update"]

            if entry is None or update is None:
                logger.warning("Memory consolidation: save_memory payload contains null required fields")
                return await self._fail_or_raw_archive(messages)

            entry = _ensure_text(entry).strip()
            if not entry:
                logger.warning("Memory consolidation: history_entry is empty after normalization")
                return await self._fail_or_raw_archive(messages)

            await self.append_history(entry)
            update = _ensure_text(update)
            if update != current_memory:
                await self.write_long_term(update)

            self._consecutive_failures = 0
            logger.info("🐕 Memory consolidation done for {} traces", len(messages))
            return True
        except Exception:
            logger.exception("Memory consolidation failed")
            return await self._fail_or_raw_archive(messages)

    async def compact_long_term(
        self,
        provider: Thinker,
        model: str,
        target_tokens: int = 1500,
    ) -> bool:
        """Compact MEMORY.md to fit within *target_tokens* by asking the LLM to deduplicate."""
        current = self.read_long_term()
        if not current:
            return True

        current_tokens = self.estimate_memory_tokens()
        if current_tokens <= target_tokens:
            return True

        logger.info(
            "🐕 Memory compaction triggered: {} tokens (target {})",
            current_tokens, target_tokens,
        )

        prompt = (
            f"Compact this long-term memory to under {target_tokens} tokens.\n"
            "Rules:\n"
            "1. Keep ALL unique, important facts (user prefs, env details, project status).\n"
            "2. Remove duplicates, verbose explanations, and resolved/obsolete items.\n"
            "3. Preserve Markdown structure with ## headings.\n"
            "4. Return ONLY the compacted Markdown — no commentary.\n\n"
            f"## Current MEMORY.md\n{current}"
        )
        chat_messages = [
            {"role": "system", "content": "You are a memory compaction assistant. Output only the compacted Markdown."},
            {"role": "user", "content": prompt},
        ]

        try:
            response = await provider.chat_with_retry(
                messages=chat_messages, tools=[], model=model,
            )
            compacted = (response.content or "").strip()

            # Validate: non-empty and actually shorter
            if not compacted:
                logger.warning("Memory compaction returned empty — skipping")
                return False

            new_tokens = estimate_prompt_tokens([{"role": "user", "content": compacted}])
            if new_tokens >= current_tokens:
                logger.warning(
                    "Memory compaction did not reduce size ({} -> {}) — skipping",
                    current_tokens, new_tokens,
                )
                return False

            await self.write_long_term(compacted)
            logger.info(
                "🐕 Memory compacted: {} -> {} tokens",
                current_tokens, new_tokens,
            )
            return True
        except Exception:
            logger.exception("Memory compaction failed")
            return False

    async def proactive_consolidate(
        self,
        messages: list[dict],
        provider: Thinker,
        model: str,
    ) -> bool:
        """Analyze recent messages for new facts and update MEMORY.md (Learning)."""
        if not messages:
            return True

        current_memory = self.read_long_term()
        prompt = f"""Review the recent interaction and update the long-term memory fact sheet.
Call update_long_term_memory relative to these rules:
1. Extract NEW facts (personal info, environment details, project status).
2. Refine existing facts if they changed.
3. Keep the file concise and structured as Markdown.
4. If NO new information is found, return the current memory unchanged.

## Current Long-term Memory
{current_memory or "(empty)"}

## Recent Interaction
{self._format_messages(messages)}"""

        chat_messages = [
            {"role": "system", "content": "You are a learning-focused Shiba. Update your long-term memory with new findings from the hunt."},
            {"role": "user", "content": prompt},
        ]

        try:
            # We use auto choice here because some providers might not support forced choice for this tool
            response = await provider.chat_with_retry(
                messages=chat_messages,
                tools=_SAVE_MEMORY_TOOL,
                model=model,
                tool_choice={"type": "function", "function": {"name": "update_long_term_memory"}},
            )

            # Fallback if forced fails or returns content instead
            if response.finish_reason == "error" or not response.has_tool_calls:
                response = await provider.chat_with_retry(
                    messages=chat_messages,
                    tools=_SAVE_MEMORY_TOOL,
                    model=model,
                    tool_choice="auto"
                )

            if not response.has_tool_calls:
                return False

            call = next((tc for tc in response.tool_calls if tc.name == "update_long_term_memory"), None)
            if not call:
                # Agent might have called save_memory instead
                call = next((tc for tc in response.tool_calls if tc.name == "save_memory"), None)
            
            if not call:
                return False

            args = _normalize_update_memory_args(call.arguments)
            if args is None or "memory_update" not in args:
                return False

            update = _ensure_text(args["memory_update"]).strip()
            if update and update != current_memory:
                await self.write_long_term(update)
                logger.info("🐕 Proactive Learning: updated long-term memory with new traces.")
            
            return True
        except Exception as e:
            logger.debug("Proactive Learning failed (swallowed): {}", e)
            return False

    async def _fail_or_raw_archive(self, messages: list[dict]) -> bool:
        """Increment failure count; after threshold, raw-archive messages and return True."""
        self._consecutive_failures += 1
        if self._consecutive_failures < self._MAX_FAILURES_BEFORE_RAW_ARCHIVE:
            return False
        await self._raw_archive(messages)
        self._consecutive_failures = 0
        return True

    async def _raw_archive(self, messages: list[dict]) -> None:
        """Fallback: dump raw messages to HISTORY.md without summaries."""
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        await self.append_history(
            f"[{ts}] [RAW] {len(messages)} messages\n"
            f"{self._format_messages(messages)}"
        )
        logger.warning(
            "🐕 Scent trail lost: raw-archived {} messages", len(messages)
        )


class PackMemory:
    """Owns consolidation policy, locking, and session offset updates."""

    _MAX_CONSOLIDATION_ROUNDS = 5

    def __init__(
        self,
        workspace: Path,
        provider: Thinker,
        model: str,
        sessions: PackManager,
        context_window_tokens: int,
        build_messages: Callable[..., list[dict[str, Any]]],
        get_tool_definitions: Callable[[], list[dict[str, Any]]],
        learning_enabled: bool = True,
        learning_interval: int = 10,
        memory_max_prompt_tokens: int = 2000,
        memory_compact_threshold_tokens: int = 1000,
        consolidation_model: str | None = None,
    ):
        self.store = ScentKeeper(workspace)
        self.provider = provider
        self.model = model
        # Cheaper model used exclusively for memory consolidation/compaction.
        # Falls back to self.model when not set.
        self.consolidation_model = consolidation_model or model
        self.sessions = sessions
        self.context_window_tokens = context_window_tokens
        self.learning_enabled = learning_enabled
        self.learning_interval = learning_interval
        self.memory_max_prompt_tokens = memory_max_prompt_tokens
        self.memory_compact_threshold_tokens = memory_compact_threshold_tokens
        self._build_messages = build_messages
        self._get_tool_definitions = get_tool_definitions
        self._locks: weakref.WeakValueDictionary[str, asyncio.Lock] = weakref.WeakValueDictionary()

    def get_lock(self, session_key: str) -> asyncio.Lock:
        """Return the shared consolidation lock for one session."""
        return self._locks.setdefault(session_key, asyncio.Lock())

    async def consolidate_messages(self, messages: list[dict[str, object]]) -> bool:
        """Archive a selected message chunk into persistent memory."""
        return await self.store.consolidate(messages, self.provider, self.consolidation_model)

    def pick_consolidation_boundary(
        self,
        session: Session,
        tokens_to_remove: int,
    ) -> tuple[int, int] | None:
        """Pick a user-turn boundary that removes enough old prompt tokens."""
        start = session.last_consolidated
        if start >= len(session.messages) or tokens_to_remove <= 0:
            return None

        removed_tokens = 0
        last_boundary: tuple[int, int] | None = None
        for idx in range(start, len(session.messages)):
            message = session.messages[idx]
            if idx > start and message.get("role") == "user":
                last_boundary = (idx, removed_tokens)
                if removed_tokens >= tokens_to_remove:
                    return last_boundary
            removed_tokens += estimate_message_tokens(message)

        return last_boundary

    def estimate_session_prompt_tokens(self, session: Session) -> tuple[int, str]:
        """Estimate current prompt size for the normal session history view."""
        history = session.get_history(max_messages=0)
        channel, chat_id = (session.key.split(":", 1) if ":" in session.key else (None, None))
        probe_messages = self._build_messages(
            history=history,
            current_message="[token-probe]",
            channel=channel,
            chat_id=chat_id,
            memory_max_prompt_tokens=self.memory_max_prompt_tokens,
        )
        return estimate_prompt_tokens_chain(
            self.provider,
            self.model,
            probe_messages,
            self._get_tool_definitions(),
        )

    async def archive_snapshot(self, messages: list[dict[str, object]]) -> bool:
        """Archive a session snapshot and then run the normal memory compaction check."""
        if not messages:
            return True
        for _ in range(self.store._MAX_FAILURES_BEFORE_RAW_ARCHIVE):
            if await self.consolidate_messages(messages):
                await self.maybe_compact_memory()
                return True
        await self.maybe_compact_memory()
        return True

    async def maybe_consolidate_by_tokens(self, session: Session) -> None:
        """Loop: archive old messages until prompt fits within half the context window."""
        if not session.messages or self.context_window_tokens <= 0:
            return

        lock = self.get_lock(session.key)
        async with lock:
            target = self.context_window_tokens // 2
            estimated, source = self.estimate_session_prompt_tokens(session)
            if estimated <= 0:
                return
            if estimated < self.context_window_tokens:
                logger.debug(
                    "Token consolidation idle {}: {}/{} via {}",
                    session.key,
                    estimated,
                    self.context_window_tokens,
                    source,
                )
                return

            for round_num in range(self._MAX_CONSOLIDATION_ROUNDS):
                if estimated <= target:
                    return

                boundary = self.pick_consolidation_boundary(session, max(1, estimated - target))
                if boundary is None:
                    logger.debug(
                        "Token consolidation: no safe boundary for {} (round {})",
                        session.key,
                        round_num,
                    )
                    return

                end_idx = boundary[0]
                chunk = session.messages[session.last_consolidated:end_idx]
                if not chunk:
                    return

                logger.info(
                    "Token consolidation round {} for {}: {}/{} via {}, chunk={} msgs",
                    round_num,
                    session.key,
                    estimated,
                    self.context_window_tokens,
                    source,
                    len(chunk),
                )
                if not await self.consolidate_messages(chunk):
                    return
                session.last_consolidated = end_idx
                self.sessions.save(session)

                estimated, source = self.estimate_session_prompt_tokens(session)
                if estimated <= 0:
                    return

    async def maybe_proactive_learn(self, session: Session) -> None:
        """Trigger background learning if interval is reached."""
        if not self.learning_enabled or self.learning_interval <= 0:
            return
        
        count = len(session.messages) - session.last_learned
        if count < self.learning_interval:
            return
        
        # Take messages from last_learned to current
        chunk = session.messages[session.last_learned:]
        if not chunk:
            return
            
        logger.debug("🐕 Proactive Learning starting for {} ({} new messages)", session.key, len(chunk))
        
        # Important: update last_learned BEFORE calling, to avoid multiple parallel triggers 
        # for the same chunk if the background task is slow.
        session.last_learned = len(session.messages)
        self.sessions.save(session)
        
        success = await self.store.proactive_consolidate(chunk, self.provider, self.consolidation_model)
        if not success:
            # If it failed, we'll try again next time (optionally roll back last_learned but 
            # let's keep it simple and skip this chunk to avoid infinite loops).
            logger.debug("🐕 Proactive Learning skipped/failed for {}", session.key)

        # After learning, check if MEMORY.md grew beyond the compact threshold
        await self.maybe_compact_memory()

    async def maybe_compact_memory(self) -> None:
        """Compact MEMORY.md if it exceeds the configured token threshold."""
        if self.memory_compact_threshold_tokens <= 0:
            return
        mem_tokens = self.store.estimate_memory_tokens()
        if mem_tokens > self.memory_compact_threshold_tokens:
            await self.store.compact_long_term(
                self.provider, self.consolidation_model,
                target_tokens=self.memory_compact_threshold_tokens,
            )
