# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
import sys
import signal
import click
import fileinput


def handle_sigint(signum, frame):
    # Send the acknowledgment explicitly to stderr
    sys.stderr.write("[SIGINT handled gracefully]\n")
    sys.stderr.flush()
    # Exit
    sys.exit(0)


# Register the signal interceptor
signal.signal(signal.SIGINT, handle_sigint)


@click.command()
@click.option('-k', '--provider-api-key', envvar='PROVIDER_API_KEY',
              default='no_key', help='Language Model API provider key.')
@click.option('-t', '--github-token', envvar='GITHUB_TOKEN',
              default='no_token', help='GitHub access token (classic).')
@click.option('-d', '--debug/--no-debug', default=False, help='Print full stack trace on errors.')
@click.option('-i', '--interactive', is_flag=True, help='Respond and stay interactive')
@click.argument('filenames', nargs=-1, type=click.Path(exists=True))
def run(provider_api_key, github_token, debug, interactive, filenames):
    """
    $ echo "...<text>..." enkasia               # Accepts messages list from the pipe
    $ ./run.py /home/user/file.txt      # Reads file.
    $ ./run.py < /home/user/file.txt    # Reads file.
    """
    raw_input = ''
    for line in fileinput.input(files=filenames or ('-',), encoding="utf-8"):
        raw_input += line
    sys.stdout.write(raw_input)
    sys.stdout.flush()
    if interactive:
        sys.stdout.write('-i option detected\n')
        sys.stdout.flush()
