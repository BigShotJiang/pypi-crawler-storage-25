"""
HealChain Python SDK v0.1.0
REST API client for HealChain — self-healing decentralized storage.

Works with Python 3.8+ using only the standard library (urllib).
Optional: install `requests` for a more ergonomic HTTP experience.
"""

from __future__ import annotations

import json
import time
import urllib.request
import urllib.error
import urllib.parse
from typing import Any, Callable, Optional, Union


# ── Constants ─────────────────────────────────────────────────────────────────

DEFAULT_API_URL       = "https://api.healchain.org"
DEFAULT_POLL_INTERVAL = 4.0    # seconds between fulfillment polls
DEFAULT_POLL_TIMEOUT  = 120.0  # seconds before giving up
DEFAULT_DATA_SHARDS   = 10
DEFAULT_PARITY_SHARDS = 4


# ── Exceptions ────────────────────────────────────────────────────────────────

class HealChainError(Exception):
    """Raised on any HealChain API or network error."""

    def __init__(
        self,
        message: str,
        *,
        status: Optional[int] = None,
        code: Optional[str] = None,
        response: Any = None,
    ):
        super().__init__(message)
        self.status   = status
        self.code     = code
        self.response = response

    def __repr__(self) -> str:
        return (
            f"HealChainError({str(self)!r}, "
            f"status={self.status}, code={self.code!r})"
        )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _to_hex(data: Union[str, bytes, bytearray]) -> str:
    """Convert string or bytes to 0x-prefixed hex."""
    if isinstance(data, str):
        if data.startswith("0x"):
            return data
        return "0x" + data.encode("utf-8").hex()
    if isinstance(data, (bytes, bytearray)):
        return "0x" + data.hex()
    raise HealChainError(
        f"store() data must be str or bytes, got {type(data).__name__}"
    )


# ── Main client ───────────────────────────────────────────────────────────────

class HealChain:
    """
    HealChain API client.

    Example::

        from healchain import HealChain

        hc = HealChain(api_url="https://api.healchain.org")

        # Store data
        result = hc.store("Hello World", label="my record")
        print(f"Stored as record #{result['record_id']} on chain {result['chain_id']}")

        # Retrieve — auto-discovers chain from GlobalRegistry
        record = hc.retrieve(result["record_id"])
        print(record["text"])
    """

    def __init__(
        self,
        api_url: str = DEFAULT_API_URL,
        *,
        api_key: Optional[str] = None,
        network: str = "auto",
        preference: str = "",
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        poll_timeout: float = DEFAULT_POLL_TIMEOUT,
        data_shards: int = DEFAULT_DATA_SHARDS,
        parity_shards: int = DEFAULT_PARITY_SHARDS,
        timeout: float = 30.0,
    ):
        """
        Args:
            api_url:       API base URL (default: https://api.healchain.org)
            api_key:       Optional API key
            network:       Default network: 'auto' or specific chain name
            preference:    'cheapest' | 'fastest' | 'redundant' | '' (auto weighted)
            poll_interval: Seconds between oracle fulfillment polls
            poll_timeout:  Max seconds to wait for oracle fulfillment
            data_shards:   Default RS data shards
            parity_shards: Default RS parity shards
            timeout:       HTTP request timeout in seconds
        """
        self.api_url       = api_url.rstrip("/")
        self.api_key       = api_key
        self.network       = network
        self.preference    = preference
        self.poll_interval = poll_interval
        self.poll_timeout  = poll_timeout
        self.data_shards   = data_shards
        self.parity_shards = parity_shards
        self.timeout       = timeout

    # ── Internal request ──────────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: Optional[dict] = None,
    ) -> Any:
        url = f"{self.api_url}{path}"
        data = json.dumps(body).encode() if body is not None else None

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "healchain-sdk-python/0.1.0",
        }
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        req = urllib.request.Request(url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            raw = exc.read()
            try:
                body_json = json.loads(raw)
                msg = body_json.get("error", str(exc))
            except Exception:
                msg = raw.decode(errors="replace") or str(exc)
            raise HealChainError(msg, status=exc.code, response=body_json if raw else None)
        except urllib.error.URLError as exc:
            raise HealChainError(
                f"Network error: {exc.reason}", code="NETWORK_ERROR"
            ) from exc

    # ── health() ──────────────────────────────────────────────────────────────

    def health(self) -> dict:
        """
        Check service health.

        Returns:
            dict with keys: status, version, geth, last_block
        """
        return self._request("GET", "/health")

    # ── store() ───────────────────────────────────────────────────────────────

    def store(
        self,
        data: Union[str, bytes, bytearray],
        *,
        label: str = "sdk upload",
        network: Optional[str] = None,
        preference: Optional[str] = None,
        data_shards: Optional[int] = None,
        parity_shards: Optional[int] = None,
        on_pending: Optional[Callable[[dict], None]] = None,
        on_fulfilled: Optional[Callable[[dict], None]] = None,
    ) -> dict:
        """
        Store data on-chain. Blocks until the oracle fulfills the request.

        Args:
            data:          Data to store (str or bytes)
            label:         Record label (default: 'sdk upload')
            network:       Override network: 'sepolia' or 'arbinetwork:       Chain name or 'auto' (default)
            preference:    'cheapest' | 'fastest' | 'redundant' | ''trum'
            data_shards:   Override RS data shards
            parity_shards: Override RS parity shards
            on_pending:    Called with {'request_id', 'tx'} when submitted
            on_fulfilled:  Called with result dict when oracle fulfills

        Returns:
            dict with keys: record_id, request_id, tx, chain_id,
                            original_size, encoded_size

        Raises:
            HealChainError: on network error or fulfillment timeout
        """
        hex_data = _to_hex(data)

        payload = {
            "data":         hex_data,
            "label":        label,
            "network":      network or self.network,
            "preference":   preference if preference is not None else self.preference,
            "dataShards":   data_shards  or self.data_shards,
            "parityShards": parity_shards or self.parity_shards,
        }

        submitted = self._request("POST", "/storeOnChain", body=payload)

        # Devnet returns synchronously
        if submitted.get("status") == "success" and "recordId" in submitted:
            return self._normalise_store(submitted)

        # Testnet: poll for oracle fulfillment
        request_id = submitted.get("requestId")
        tx         = submitted.get("tx")
        if not request_id:
            raise HealChainError(
                "No requestId returned from store", response=submitted
            )

        if on_pending:
            on_pending({"request_id": str(request_id), "tx": tx})

        return self._poll_fulfillment(request_id, tx, on_fulfilled)

    def _poll_fulfillment(
        self,
        request_id: str,
        tx: str,
        on_fulfilled: Optional[Callable[[dict], None]],
    ) -> dict:
        deadline = time.monotonic() + self.poll_timeout

        while time.monotonic() < deadline:
            time.sleep(self.poll_interval)
            try:
                status = self._request(
                    "GET",
                    f"/sepoliaStatus?requestId={urllib.parse.quote(str(request_id))}",
                )
            except HealChainError:
                continue  # transient error — keep polling

            if status.get("status") == "fulfilled":
                result = {
                    "record_id":    str(status.get("recordId", request_id)),
                    "request_id":   str(request_id),
                    "tx":           tx,
                    "chain_id":     status.get("chainId"),
                    "original_size": status.get("originalSize"),
                    "encoded_size":  status.get("encodedSize"),
                    "total_records": status.get("totalRecords"),
                }
                if on_fulfilled:
                    on_fulfilled(result)
                return result

        raise HealChainError(
            f"Oracle fulfillment timed out after {self.poll_timeout}s "
            f"(request_id={request_id})",
            code="FULFILLMENT_TIMEOUT",
        )

    @staticmethod
    def _normalise_store(resp: dict) -> dict:
        return {
            "record_id":    str(resp.get("recordId", "")),
            "request_id":   resp.get("requestId"),
            "tx":           resp.get("tx"),
            "chain_id":     resp.get("chainId"),
            "original_size": resp.get("originalSize"),
            "encoded_size":  resp.get("encodedSize"),
        }

    # ── retrieve() ────────────────────────────────────────────────────────────

    def retrieve(self, record_id: Union[str, int]) -> dict:
        """
        Retrieve a record by ID. Automatically routes to the correct chain
        via the GlobalRegistry.

        Args:
            record_id: Record ID (str or int)

        Returns:
            dict with keys: record_id, data (hex), text, bytes, chain_id

        Raises:
            HealChainError: if record not found or network error
        """
        path   = f"/retrieve?id={urllib.parse.quote(str(record_id))}"
        result = self._request("GET", path)
        return {
            "record_id": str(result.get("recordId", record_id)),
            "data":      result.get("data"),
            "text":      result.get("text"),
            "bytes":     result.get("bytes"),
            "chain_id":  result.get("chainId"),
        }

    # ── get_metadata() ────────────────────────────────────────────────────────

    def get_metadata(self, record_id: Union[str, int]) -> dict:
        """
        Get record metadata without fetching the full data payload.

        Args:
            record_id: Record ID (str or int)

        Returns:
            dict with label, owner, original_size, encoded_size,
                  data_shards, parity_shards, timestamp, data_hash
        """
        path   = f"/getMetadata?id={urllib.parse.quote(str(record_id))}"
        result = self._request("GET", path)
        return {
            "record_id":    str(result.get("recordId", record_id)),
            "label":        result.get("label"),
            "owner":        result.get("owner"),
            "original_size": result.get("originalSize"),
            "encoded_size":  result.get("encodedSize"),
            "data_shards":   result.get("dataShards"),
            "parity_shards": result.get("parityShards"),
            "timestamp":     result.get("timestamp"),
            "data_hash":     result.get("dataHash"),
        }

    # ── list() ────────────────────────────────────────────────────────────────

    def list(self, page: int = 0, limit: int = 10) -> dict:
        """
        List records with pagination.

        Args:
            page:  Page number, 0-indexed (default: 0)
            limit: Records per page, max 50 (default: 10)

        Returns:
            dict with keys: records, total, pages, page, limit
        """
        path   = f"/listRecords?page={page}&limit={limit}"
        result = self._request("GET", path)
        return {
            "records": result.get("records", []),
            "total":   result.get("total", 0),
            "pages":   result.get("pages", 1),
            "page":    result.get("page", page),
            "limit":   result.get("limit", limit),
        }

# ── get_billing_balance() ─────────────────────────────────────────────────

    def get_billing_balance(self, wallet_address: str) -> dict:
        """
        Get credit balances for a wallet address. No API key required.

        Args:
            wallet_address: Wallet address (0x...)

        Returns:
            dict with balance_usd, testnet_balance_usd, billing_active
        """
        path = f"/billing/balance?wallet={urllib.parse.quote(wallet_address)}"
        return self._request("GET", path)

    # ── create_checkout() ─────────────────────────────────────────────────────

    def create_checkout(self, wallet_address: str, amount_cents: int) -> dict:
        """
        Create a Stripe Checkout session for topping up credits.

        Args:
            wallet_address: Wallet address to credit
            amount_cents:   Amount in cents (min 500 = $5.00)

        Returns:
            dict with checkout_url, session_id, amount_usd
        """
        return self._request("POST", "/checkout/create", body={
            "wallet_address": wallet_address,
            "amount_cents":   amount_cents,
        })

    # ── request_testnet_credits() ─────────────────────────────────────────────

    def request_testnet_credits(self, wallet_address: str) -> dict:
        """
        Request free testnet credits ($1.00 per wallet per 24 hours).
        Wallet must be whitelisted during early access phase.

        Args:
            wallet_address: Wallet address to credit

        Returns:
            dict with granted_usd, balance_usd, expires_in_days
        """
        return self._request("POST", "/testnet/requestCredits", body={
            "wallet_address": wallet_address,
        })