"""
HealChain Async Python SDK — smoke tests
Run: python tests/test_async_client.py
"""

import asyncio
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from healchain import AsyncHealChain, HealChainError

from healchain import AsyncHealChain, HealChainError

API_URL = os.environ.get("HC_API_URL", "https://api.healchain.org")
API_KEY = os.environ.get("HC_API_KEY", "90eeb27b22819087f959ab4ddc73f1a389ecc84bc52ff60d83b767bf74c025b3")

passed = 0

passed = 0
failed = 0


def atest(name):
    def decorator(fn):
        global passed, failed
        try:
            asyncio.run(fn())
            print(f"  ✅ {name}")
            passed += 1
        except Exception as e:
            print(f"  ❌ {name}")
            print(f"     {e}")
            failed += 1
        return fn
    return decorator


print(f"\nHealChain Async SDK tests — {API_URL}\n")

# ── Context manager ───────────────────────────────────────────────────────────
print("async context manager")

@atest("opens and closes cleanly")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        assert hc is not None

# ── health() ──────────────────────────────────────────────────────────────────
print("\nhealth()")

@atest("returns status field")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        h = await hc.health()
        assert "status" in h

@atest("returns version field")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        h = await hc.health()
        assert isinstance(h.get("version"), str)

# ── retrieve() ────────────────────────────────────────────────────────────────
print("\nretrieve()")

@atest("retrieves record 9")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        r = await hc.retrieve(9)
        assert r["record_id"] is not None
        assert isinstance(r["bytes"], int)

@atest("returns chain_id")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        r = await hc.retrieve(9)
        assert r["chain_id"] == "421614"

@atest("raises HealChainError for missing record")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        try:
            await hc.retrieve(999999)
            assert False, "Should have raised"
        except HealChainError as e:
            assert e.status is not None

# ── retrieve_many() ───────────────────────────────────────────────────────────
print("\nretrieve_many()")

@atest("retrieves multiple records concurrently")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        results = await hc.retrieve_many([9, 9], concurrency=2)
        assert len(results) == 2
        assert all(r.get("record_id") is not None for r in results)

@atest("handles errors gracefully in retrieve_many")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        results = await hc.retrieve_many([9, 999999], concurrency=2)
        assert len(results) == 2
        # One success, one error
        has_error = any("error" in r for r in results)
        assert has_error

# ── list() ────────────────────────────────────────────────────────────────────
print("\nlist()")

@atest("returns records list")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        result = await hc.list(0, 3)
        assert isinstance(result["records"], list)
        assert isinstance(result["total"], int)

# ── get_metadata() ────────────────────────────────────────────────────────────
print("\nget_metadata()")

@atest("returns metadata fields")
async def _():
    async with AsyncHealChain(api_url=API_URL, api_key=API_KEY) as hc:
        m = await hc.get_metadata(9)
        assert "label" in m
        assert "original_size" in m

# ── network error ─────────────────────────────────────────────────────────────
print("\nerror handling")

@atest("raises HealChainError on network failure")
async def _():
    hc = AsyncHealChain(api_url="http://localhost:19999", poll_timeout=1)
    try:
        await hc.retrieve(0)
        assert False, "Should have raised"
    except HealChainError as e:
        assert e.code == "NETWORK_ERROR"

# ── Summary ───────────────────────────────────────────────────────────────────
print(f"\n{'─' * 40}")
print(f"{passed + failed} tests: {passed} passed, {failed} failed\n")
if failed > 0:
    sys.exit(1)
