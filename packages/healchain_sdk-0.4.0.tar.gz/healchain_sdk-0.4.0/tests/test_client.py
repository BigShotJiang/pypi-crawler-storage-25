"""
HealChain Python SDK — smoke tests
Run: python -m pytest tests/ -v
  or: python tests/test_client.py

Set HC_API_URL env var to override the default API endpoint.
"""

import os
import sys
import traceback

# Allow running directly without pytest
try:
    import pytest
    HAS_PYTEST = True
except ImportError:
    HAS_PYTEST = False

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from healchain import HealChain, HealChainError

API_URL = os.environ.get("HC_API_URL", "https://api.healchain.org")
API_KEY = os.environ.get("HC_API_KEY", "90eeb27b22819087f959ab4ddc73f1a389ecc84bc52ff60d83b767bf74c025b3")
hc = HealChain(api_url=API_URL, api_key=API_KEY)

# ── Simple test runner (no pytest required) ───────────────────────────────────

passed = 0
failed = 0

def test(name):
    """Decorator for standalone test functions."""
    def decorator(fn):
        global passed, failed
        try:
            fn()
            print(f"  ✅ {name}")
            passed += 1
        except Exception as e:
            print(f"  ❌ {name}")
            print(f"     {e}")
            failed += 1
        return fn
    return decorator

def assert_eq(a, b, msg=""):
    if a != b:
        raise AssertionError(msg or f"{a!r} != {b!r}")

def assert_true(condition, msg="Assertion failed"):
    if not condition:
        raise AssertionError(msg)

def assert_in(key, obj, msg=""):
    if key not in obj:
        raise AssertionError(msg or f"{key!r} not in {obj!r}")


# ── health() ──────────────────────────────────────────────────────────────────

print(f"\nHealChain Python SDK tests — {API_URL}\n")
print("health()")

@test("returns status field")
def _():
    h = hc.health()
    assert_in("status", h)

@test("returns version field")
def _():
    h = hc.health()
    assert_true(isinstance(h.get("version"), str), "version should be a string")


# ── retrieve() ────────────────────────────────────────────────────────────────

print("\nretrieve()")

@test("retrieves record 9")
def _():
    r = hc.retrieve(9)
    assert_in("record_id", r)
    assert_true(isinstance(r["bytes"], int), "bytes should be int")

@test("returns chain_id in response")
def _():
    r = hc.retrieve(9)
    assert_in("chain_id", r)
    # record 9 is on Arbitrum Sepolia
    assert_eq(r["chain_id"], "421614", f"Expected Arbitrum chain, got {r['chain_id']}")

@test("returns text field")
def _():
    r = hc.retrieve(9)
    assert_true(r.get("text") is not None, "text field missing")

@test("raises HealChainError for missing record")
def _():
    try:
        hc.retrieve(999999)
        raise AssertionError("Should have raised HealChainError")
    except HealChainError as e:
        assert_true(e.status is not None or e.code is not None,
                    "Expected status or code on error")


# ── list() ────────────────────────────────────────────────────────────────────

print("\nlist()")

@test("returns records list")
def _():
    result = hc.list(0, 5)
    assert_true(isinstance(result["records"], list), "records should be a list")
    assert_true(isinstance(result["total"], int), "total should be int")

@test("respects limit parameter")
def _():
    result = hc.list(0, 2)
    assert_true(len(result["records"]) <= 2,
                f"Expected ≤2 records, got {len(result['records'])}")

@test("returns pagination fields")
def _():
    result = hc.list(0, 5)
    for key in ("records", "total", "pages", "page", "limit"):
        assert_in(key, result)

# ── get_billing_balance() ─────────────────────────────────────────────────────
print('\nget_billing_balance()')

@test('returns balance for known wallet')
def _():
    result = hc.get_billing_balance('0x96243925D8588E332d8ff54c71936Ca2dC5f2aE2')
    assert_in('balance_usd', result)
    assert_in('testnet_balance_usd', result)

@test('returns zero for unknown wallet')
def _():
    result = hc.get_billing_balance('0x1234567890123456789012345678901234567890')
    assert_true(result.get('balance_cents') == 0, 'Expected zero balance')

# ── get_metadata() ────────────────────────────────────────────────────────────

print("\nget_metadata()")

@test("returns metadata fields")
def _():
    m = hc.get_metadata(9)
    for key in ("label", "original_size", "encoded_size", "data_shards", "parity_shards"):
        assert_in(key, m)

@test("label is a non-empty string")
def _():
    m = hc.get_metadata(9)
    assert_true(isinstance(m["label"], str) and len(m["label"]) > 0,
                f"Expected non-empty label, got: {m['label']!r}")


# ── HealChainError ────────────────────────────────────────────────────────────

print("\nHealChainError")

@test("has status attribute")
def _():
    try:
        hc.retrieve(999999)
    except HealChainError as e:
        assert_true(hasattr(e, "status"), "Missing status attribute")

@test("has code attribute")
def _():
    bad = HealChain(api_url="http://localhost:99999", poll_timeout=1)
    try:
        bad.retrieve(0)
    except HealChainError as e:
        assert_eq(e.code, "NETWORK_ERROR")

@test("to_hex handles str input")
def _():
    from healchain.client import _to_hex
    result = _to_hex("Hello")
    assert_true(result.startswith("0x"), "Should start with 0x")
    assert_eq(result, "0x48656c6c6f")

@test("to_hex handles bytes input")
def _():
    from healchain.client import _to_hex
    result = _to_hex(b"Hello")
    assert_eq(result, "0x48656c6c6f")

@test("to_hex passes through existing hex")
def _():
    from healchain.client import _to_hex
    result = _to_hex("0xdeadbeef")
    assert_eq(result, "0xdeadbeef")


# ── Summary ───────────────────────────────────────────────────────────────────

print(f"\n{'─' * 40}")
print(f"{passed + failed} tests: {passed} passed, {failed} failed\n")

if failed > 0:
    sys.exit(1)


# ── pytest compatibility ──────────────────────────────────────────────────────

def test_health_status():
    h = hc.health()
    assert "status" in h

def test_retrieve_record():
    r = hc.retrieve(9)
    assert r["chain_id"] == "421614"

def test_list_records():
    result = hc.list(0, 5)
    assert isinstance(result["records"], list)

def test_get_metadata():
    m = hc.get_metadata(9)
    assert "label" in m

def test_error_on_missing_record():
    try:
        hc.retrieve(999999)
        assert False, "Should have raised"
    except HealChainError:
        pass
