# Lattice SDK Python Library

![](https://www.anduril.com/lattice-sdk/)

[![pypi](https://img.shields.io/pypi/v/anduril-lattice-sdk)](https://pypi.python.org/pypi/anduril-lattice-sdk)

The Lattice SDK Python library provides convenient access to the Lattice SDK APIs from Python.

## Table of Contents

- [Documentation](#documentation)
- [Requirements](#requirements)
- [Installation](#installation)
- [Support](#support)
- [Reference](#reference)
- [Usage](#usage)
- [Environments](#environments)
- [Async Client](#async-client)
- [Exception Handling](#exception-handling)
- [Streaming](#streaming)
- [Pagination](#pagination)
- [Oauth Token Override](#oauth-token-override)
- [Advanced](#advanced)
  - [Access Raw Response Data](#access-raw-response-data)
  - [Retries](#retries)
  - [Timeouts](#timeouts)
  - [Custom Client](#custom-client)

## Documentation

API reference documentation is available [here](https://developer.anduril.com/).

## Requirements

To use the SDK please ensure you have the following installed:

* [Python 3](https://www.python.org/doc/versions)

## Installation

```sh
pip install anduril-lattice-sdk
```

## Support

For support with this library please reach out to your Anduril representative.

## Reference

A full reference for this library is available [here](https://github.com/anduril/lattice-sdk-python/blob/HEAD/./reference.md).

## Usage

Instantiate and use the client with the following:

```python
from anduril import Lattice

client = Lattice(
    client_id="<clientId>",
    client_secret="<clientSecret>",
)

client.entities.long_poll_entity_events(
    session_token="sessionToken",
)
```

## Environments

This SDK allows you to configure different environments for API requests.

```python
from anduril import Lattice
from anduril.environment import LatticeEnvironment

client = Lattice(
    environment=LatticeEnvironment.DEFAULT,
)
```

## Async Client

The SDK also exports an `async` client so that you can make non-blocking calls to our API. Note that if you are constructing an Async httpx client class to pass into this client, use `httpx.AsyncClient()` instead of `httpx.Client()` (e.g. for the `httpx_client` parameter of this client).

```python
import asyncio

from anduril import AsyncLattice

client = AsyncLattice(
    client_id="<clientId>",
    client_secret="<clientSecret>",
)


async def main() -> None:
    await client.entities.long_poll_entity_events(
        session_token="sessionToken",
    )


asyncio.run(main())
```

## Exception Handling

When the API returns a non-success status code (4xx or 5xx response), a subclass of the following error
will be thrown.

```python
from anduril.core.api_error import ApiError

try:
    client.entities.long_poll_entity_events(...)
except ApiError as e:
    print(e.status_code)
    print(e.body)
```

## Streaming

The SDK supports streaming responses, as well, the response will be a generator that you can loop over.

```python
from anduril import Lattice

client = Lattice(
    client_id="<clientId>",
    client_secret="<clientSecret>",
)

client.entities.stream_entities()
```

## Pagination

Paginated requests will return a `SyncPager` or `AsyncPager`, which can be used as generators for the underlying object.

```python
from anduril import Lattice

client = Lattice(
    client_id="<clientId>",
    client_secret="<clientSecret>",
)

client.objects.list_objects()
```

```python
# You can also iterate through pages and access the typed response per page
pager = client.objects.list_objects(...)
for page in pager.iter_pages():
    print(page.response)  # access the typed response for each page
    for item in page:
        print(item)
```

## Oauth Token Override

This SDK supports two authentication methods: OAuth client credentials flow (automatic token management) or direct bearer token authentication. You can choose between these options when initializing the client:

```python
from anduril import Lattice

# Option 1: Direct bearer token (bypass OAuth flow)
client = Lattice(
    ...,
    token="my-pre-generated-bearer-token",
)

# Option 2: OAuth client credentials flow (automatic token management)
client = Lattice(
    ...,
    client_id="your-client-id",
    client_secret="your-client-secret",
)
```

## Advanced

### Access Raw Response Data

The SDK provides access to raw response data, including headers, through the `.with_raw_response` property.
The `.with_raw_response` property returns a "raw" client that can be used to access the `.headers` and `.data` attributes.

```python
from anduril import Lattice

client = Lattice(...)
response = client.entities.with_raw_response.long_poll_entity_events(...)
print(response.headers)  # access the response headers
print(response.status_code)  # access the response status code
print(response.data)  # access the underlying object
```

### Retries

The SDK is instrumented with automatic retries with exponential backoff. A request will be retried as long
as the request is deemed retryable and the number of retry attempts has not grown larger than the configured
retry limit (default: 2).

Which status codes are retried depends on the `retryStatusCodes` generator configuration:

**`legacy`** (current default): retries on
- [408](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/408) (Timeout)
- [409](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/409) (Conflict)
- [429](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/429) (Too Many Requests)
- [5XX](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status#server_error_responses) (All server errors, including 500)

**`recommended`**: retries on
- [408](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/408) (Timeout)
- [409](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/409) (Conflict)
- [429](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/429) (Too Many Requests)
- [502](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/502) (Bad Gateway)
- [503](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/503) (Service Unavailable)
- [504](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/504) (Gateway Timeout)

Use the `max_retries` request option to configure this behavior.

```python
client.entities.long_poll_entity_events(..., request_options={
    "max_retries": 1
})
```

### Timeouts

The SDK defaults to a 60 second timeout. You can configure this with a timeout option at the client or request level.

```python
from anduril import Lattice

client = Lattice(..., timeout=20.0)

# Override timeout for a specific method
client.entities.long_poll_entity_events(..., request_options={
    "timeout_in_seconds": 1
})
```

### Custom Client

You can override the `httpx` client to customize it for your use-case. Some common use-cases include support for proxies
and transports.

```python
import httpx
from anduril import Lattice

client = Lattice(
    ...,
    httpx_client=httpx.Client(
        proxy="http://my.test.proxy.example.com",
        transport=httpx.HTTPTransport(local_address="0.0.0.0"),
    ),
)
```

