# This file was auto-generated from our API Definition.

import typing

from ..core.client_wrapper import AsyncClientWrapper, SyncClientWrapper
from ..core.request_options import RequestOptions
from .raw_client import AsyncRawOauthClient, RawOauthClient
from .types.get_token_response import GetTokenResponse

# this is used as the default value for optional parameters
OMIT = typing.cast(typing.Any, ...)


class OauthClient:
    def __init__(self, *, client_wrapper: SyncClientWrapper):
        self._raw_client = RawOauthClient(client_wrapper=client_wrapper)

    @property
    def with_raw_response(self) -> RawOauthClient:
        """
        Retrieves a raw implementation of this client that returns raw responses.

        Returns
        -------
        RawOauthClient
        """
        return self._raw_client

    def get_token(
        self,
        *,
        client_id: typing.Optional[str] = OMIT,
        client_secret: typing.Optional[str] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> GetTokenResponse:
        """
        Gets a new short-lived token using the specified client credentials

        Parameters
        ----------
        client_id : typing.Optional[str]
            The client identifier

        client_secret : typing.Optional[str]
            The client secret

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        GetTokenResponse
            Access token response

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.oauth.get_token()
        """
        _response = self._raw_client.get_token(
            client_id=client_id, client_secret=client_secret, request_options=request_options
        )
        return _response.data


class AsyncOauthClient:
    def __init__(self, *, client_wrapper: AsyncClientWrapper):
        self._raw_client = AsyncRawOauthClient(client_wrapper=client_wrapper)

    @property
    def with_raw_response(self) -> AsyncRawOauthClient:
        """
        Retrieves a raw implementation of this client that returns raw responses.

        Returns
        -------
        AsyncRawOauthClient
        """
        return self._raw_client

    async def get_token(
        self,
        *,
        client_id: typing.Optional[str] = OMIT,
        client_secret: typing.Optional[str] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> GetTokenResponse:
        """
        Gets a new short-lived token using the specified client credentials

        Parameters
        ----------
        client_id : typing.Optional[str]
            The client identifier

        client_secret : typing.Optional[str]
            The client secret

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        GetTokenResponse
            Access token response

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.oauth.get_token()


        asyncio.run(main())
        """
        _response = await self._raw_client.get_token(
            client_id=client_id, client_secret=client_secret, request_options=request_options
        )
        return _response.data
