# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ...core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ...core.serialization import FieldMetadata


class GetTokenResponse(UniversalBaseModel):
    access_token: str = pydantic.Field()
    """
    The access token
    """

    token_type: str = pydantic.Field()
    """
    The type of token (typically "Bearer")
    """

    expires_in: typing.Optional[int] = pydantic.Field(default=None)
    """
    Lifetime of the access token in seconds
    """

    refresh_expires_in: typing.Optional[int] = pydantic.Field(default=None)
    """
    Lifetime of the refresh token
    """

    not_before_policy: typing_extensions.Annotated[
        typing.Optional[int],
        FieldMetadata(alias="not-before-policy"),
        pydantic.Field(
            alias="not-before-policy", description="Enforce that a token cannot be used before a specific unixtime"
        ),
    ] = None
    scope: typing.Optional[str] = pydantic.Field(default=None)
    """
    The scope of the access token
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
