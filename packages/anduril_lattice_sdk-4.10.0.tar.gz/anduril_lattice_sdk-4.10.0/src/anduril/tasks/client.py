# This file was auto-generated from our API Definition.

import typing

from ..core.client_wrapper import AsyncClientWrapper, SyncClientWrapper
from ..core.request_options import RequestOptions
from ..types.agent_request import AgentRequest
from ..types.entity_ids_selector import EntityIdsSelector
from ..types.google_protobuf_any import GoogleProtobufAny
from ..types.principal import Principal
from ..types.relations import Relations
from ..types.task import Task
from ..types.task_entity import TaskEntity
from ..types.task_query_results import TaskQueryResults
from ..types.task_status import TaskStatus
from ..types.timestamp import Timestamp
from .raw_client import AsyncRawTasksClient, RawTasksClient
from .types.stream_as_agent_response import StreamAsAgentResponse
from .types.stream_manual_control_frames_response import StreamManualControlFramesResponse
from .types.stream_tasks_response import StreamTasksResponse
from .types.task_query_status_filter import TaskQueryStatusFilter
from .types.task_query_update_time_range import TaskQueryUpdateTimeRange
from .types.task_stream_request_status_filter import TaskStreamRequestStatusFilter
from .types.task_stream_request_task_type import TaskStreamRequestTaskType

# this is used as the default value for optional parameters
OMIT = typing.cast(typing.Any, ...)


class TasksClient:
    def __init__(self, *, client_wrapper: SyncClientWrapper):
        self._raw_client = RawTasksClient(client_wrapper=client_wrapper)

    @property
    def with_raw_response(self) -> RawTasksClient:
        """
        Retrieves a raw implementation of this client that returns raw responses.

        Returns
        -------
        RawTasksClient
        """
        return self._raw_client

    def create_task(
        self,
        *,
        task_id: typing.Optional[str] = OMIT,
        display_name: typing.Optional[str] = OMIT,
        description: typing.Optional[str] = OMIT,
        specification: typing.Optional[GoogleProtobufAny] = OMIT,
        author: typing.Optional[Principal] = OMIT,
        relations: typing.Optional[Relations] = OMIT,
        is_executed_elsewhere: typing.Optional[bool] = OMIT,
        initial_entities: typing.Optional[typing.Sequence[TaskEntity]] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> Task:
        """
        Creates a new Task in the system with the specified parameters.

        This method initiates a new task with a unique ID (either provided or auto-generated),
        sets the initial task state to STATUS_CREATED, and establishes task ownership. The task
        can be assigned to a specific agent through the Relations field.

        Once created, a task enters the lifecycle workflow and can be tracked, updated, and managed
        through other Tasks API endpoints.

        Parameters
        ----------
        task_id : typing.Optional[str]
            If non-empty, will set the requested Task ID, otherwise will generate a new random
            GUID. Will reject if supplied Task ID does not match [A-Za-z0-9_-.]{5,36}.

        display_name : typing.Optional[str]
            Human readable display name for this Task, should be short (<100 chars).

        description : typing.Optional[str]
            Longer, free form human readable description of this Task.

        specification : typing.Optional[GoogleProtobufAny]
            The path for the Protobuf task definition, and the complete task data.

        author : typing.Optional[Principal]

        relations : typing.Optional[Relations]
            Any relationships associated with this Task, such as a parent Task or an assignee
            this Task is designated to for execution.

        is_executed_elsewhere : typing.Optional[bool]
            If set, then the service will not trigger execution of this task on an agent. Useful
            for when ingesting tasks from an external system that is triggering execution of tasks
            on agents.

        initial_entities : typing.Optional[typing.Sequence[TaskEntity]]
            Indicates an initial set of entities that can be used to execute an entity aware
            task. For example, an entity Objective, an entity Keep In Zone, etc.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task creation was successful

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.tasks.create_task()
        """
        _response = self._raw_client.create_task(
            task_id=task_id,
            display_name=display_name,
            description=description,
            specification=specification,
            author=author,
            relations=relations,
            is_executed_elsewhere=is_executed_elsewhere,
            initial_entities=initial_entities,
            request_options=request_options,
        )
        return _response.data

    def get_task(self, task_id: str, *, request_options: typing.Optional[RequestOptions] = None) -> Task:
        """
        Retrieves a specific Task by its ID, with options to select a particular task version or view.

        This method returns detailed information about a task including its current status,
        specification, relations, and other metadata. The response includes the complete Task object
        with all associated fields.

        By default, the method returns the latest definition version of the task from the manager's
        perspective.

        Parameters
        ----------
        task_id : str
            ID of task to return

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task retrieval was successful.

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.tasks.get_task(
            task_id="taskId",
        )
        """
        _response = self._raw_client.get_task(task_id, request_options=request_options)
        return _response.data

    def update_task_status(
        self,
        task_id: str,
        *,
        status_version: typing.Optional[int] = OMIT,
        new_status: typing.Optional[TaskStatus] = OMIT,
        author: typing.Optional[Principal] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> Task:
        """
        Updates the status of a Task as it progresses through its lifecycle.

        This method allows agents or operators to report the current state of a task,
        which could include changes to task status, and error information.

        Each status update increments the task's status_version. When updating status,
        clients must provide the current version to ensure consistency. The system rejects
        updates with mismatched versions to prevent race conditions.

        Terminal states (`STATUS_DONE_OK` and `STATUS_DONE_NOT_OK`) are permanent; once a task
        reaches these states, no further updates are allowed.

        Parameters
        ----------
        task_id : str
            ID of task to update status of

        status_version : typing.Optional[int]
            The status version of the task to update. This version number increments to indicate the task's
            current stage in its status lifecycle. Specifically, whenever a task's status updates, the status
            version increments by one. Any status updates received with a lower status version number than what
            is known are considered stale and ignored.

        new_status : typing.Optional[TaskStatus]
            The new status of the task.

        author : typing.Optional[Principal]

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task status update was successful

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.tasks.update_task_status(
            task_id="taskId",
        )
        """
        _response = self._raw_client.update_task_status(
            task_id,
            status_version=status_version,
            new_status=new_status,
            author=author,
            request_options=request_options,
        )
        return _response.data

    def cancel_task(
        self,
        task_id: str,
        *,
        author: typing.Optional[Principal] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> Task:
        """
        Cancels a task by marking it for cancellation in the system.

        This method initiates task cancellation based on the task's current state:
        - If the task has not been sent to an agent, it cancels immediately and transitions the task
          to a terminal state (`STATUS_DONE_NOT_OK` with `ERROR_CODE_CANCELLED`).
        - If the task has already been sent to an agent, the cancellation request is routed to the agent.
          The agent is then responsible for deciding whether cancellation is possible or not:
          - If the task can be cancelled, the agent must use `UpdateTaskStatus` and set the task status to `STATUS_DONE_NOT_OK`.
          - If the task cannot be cancelled, the agent must use `UpdateTaskStatus` to attach a `TaskError` to the task with the error code `ERROR_CODE_REJECTED`
            and a `message` explaining why the task cannot be cancelled.

        Parameters
        ----------
        task_id : str
            The ID of task to cancel

        author : typing.Optional[Principal]
            Who or what is requesting to cancel this task.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task cancellation was successful.

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.tasks.cancel_task(
            task_id="taskId",
        )
        """
        _response = self._raw_client.cancel_task(task_id, author=author, request_options=request_options)
        return _response.data

    def query_tasks(
        self,
        *,
        page_token: typing.Optional[str] = OMIT,
        parent_task_id: typing.Optional[str] = OMIT,
        status_filter: typing.Optional[TaskQueryStatusFilter] = OMIT,
        update_time_range: typing.Optional[TaskQueryUpdateTimeRange] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> TaskQueryResults:
        """
        Searches for Tasks that match specified filtering criteria and returns matching tasks in paginated form.

        This method allows filtering tasks based on multiple criteria including:
        - Parent task relationships
        - Task status (with inclusive or exclusive filtering)
        - Update time ranges
        - Task view (manager or agent perspective)
        - Task assignee
        - Task type (via exact URL matches or prefix matching)

        Results are returned in pages. When more results are available than can be returned in a single
        response, a page_token is provided that can be used in subsequent requests to retrieve the next
        set of results.

        By default, this returns the latest task version for each matching task from the manager's perspective.

        Parameters
        ----------
        page_token : typing.Optional[str]
            If set, returns results starting from the given pageToken.

        parent_task_id : typing.Optional[str]
            If present matches Tasks with this parent Task ID.
            Note: this is mutually exclusive with all other query parameters, for example, either provide parent task ID, or
            any of the remaining parameters, but not both.

        status_filter : typing.Optional[TaskQueryStatusFilter]

        update_time_range : typing.Optional[TaskQueryUpdateTimeRange]
            If provided, only provides Tasks updated within the time range.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        TaskQueryResults
            Task query was successful

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.tasks.query_tasks()
        """
        _response = self._raw_client.query_tasks(
            page_token=page_token,
            parent_task_id=parent_task_id,
            status_filter=status_filter,
            update_time_range=update_time_range,
            request_options=request_options,
        )
        return _response.data

    def stream_tasks(
        self,
        *,
        heartbeat_interval_ms: typing.Optional[int] = OMIT,
        rate_limit: typing.Optional[int] = OMIT,
        exclude_preexisting_tasks: typing.Optional[bool] = OMIT,
        task_type: typing.Optional[TaskStreamRequestTaskType] = OMIT,
        update_start_time: typing.Optional[Timestamp] = OMIT,
        parent_task_id: typing.Optional[str] = OMIT,
        assignee: typing.Optional[Principal] = OMIT,
        status_filter: typing.Optional[TaskStreamRequestStatusFilter] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> typing.Iterator[StreamTasksResponse]:
        """
        Establishes a server streaming connection that delivers task updates in real-time using Server-Sent Events (SSE).

        The stream delivers all existing non-terminal tasks when first connected, followed by real-time
        updates for task creation and status changes. Additionally, heartbeat messages are sent periodically to maintain the connection.

        Parameters
        ----------
        heartbeat_interval_ms : typing.Optional[int]
            The time interval, in milliseconds, that determines the frequency at which to send heartbeat events. Defaults to 30000 (30 seconds).

        rate_limit : typing.Optional[int]
            The time interval, in milliseconds, after an update for a given task before another one will be sent for the same task.
            If set, value must be >= 250.

        exclude_preexisting_tasks : typing.Optional[bool]
            Optional flag to only include tasks created or updated after the stream is initiated, and not any previous preexisting tasks.
            If unset or false, the stream will include any new tasks and task updates, as well as all preexisting tasks.

        task_type : typing.Optional[TaskStreamRequestTaskType]
            Optional filter that only returns tasks with specific types. If not provided, all task types will be streamed.

        update_start_time : typing.Optional[Timestamp]
            If provided, returns tasks which have been updated since the given time.

        parent_task_id : typing.Optional[str]
            A filter for tasks with a specific parent task ID.
            Note: This filter is mutually exclusive with all other filter fields (`updateStartTime`, `assignee`, `statusFilter`, `taskType`).
            Either provide `parentTaskId` or any combination of the other filters, but not both.

        assignee : typing.Optional[Principal]
            A filter for tasks assigned to a specific principal.

        status_filter : typing.Optional[TaskStreamRequestStatusFilter]
            A filter for task statuses (inclusive or exclusive).

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Yields
        ------
        typing.Iterator[StreamTasksResponse]
            Returns a stream of task updates as they occur.

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        response = client.tasks.stream_tasks()
        for chunk in response:
            yield chunk
        """
        with self._raw_client.stream_tasks(
            heartbeat_interval_ms=heartbeat_interval_ms,
            rate_limit=rate_limit,
            exclude_preexisting_tasks=exclude_preexisting_tasks,
            task_type=task_type,
            update_start_time=update_start_time,
            parent_task_id=parent_task_id,
            assignee=assignee,
            status_filter=status_filter,
            request_options=request_options,
        ) as r:
            yield from r.data

    def listen_as_agent(
        self,
        *,
        agent_selector: typing.Optional[EntityIdsSelector] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> AgentRequest:
        """
        Establishes a server streaming connection that delivers tasks to taskable agents for execution.

        This method creates a persistent connection from Tasks API to an agent, allowing the server
        to push tasks to the agent as they become available. The agent receives a stream of tasks that
        match its selector criteria (entity IDs).

        The stream delivers three types of requests:
        - ExecuteRequest: Contains a new task for the agent to execute
        - CancelRequest: Indicates a task should be canceled
        - CompleteRequest: Indicates a task should be completed

        This is the primary method for taskable agents to receive and process tasks in real-time.
        Agents should maintain this connection and process incoming tasks according to their capabilities.

        When an agent receives a task, it should update the task status using the UpdateStatus endpoint
        to provide progress information back to Tasks API.

        This is a long polling API that will block until a new task is ready for delivery. If no new task is
        available then the server will hold on to your request for up to 5 minutes, after that 5 minute timeout
        period you will be expected to reinitiate a new request.

        Parameters
        ----------
        agent_selector : typing.Optional[EntityIdsSelector]
            Selector criteria to determine which Agent Tasks the agent receives

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        AgentRequest
            Requests for the agent to comply with.

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        client.tasks.listen_as_agent()
        """
        _response = self._raw_client.listen_as_agent(agent_selector=agent_selector, request_options=request_options)
        return _response.data

    def stream_as_agent(
        self,
        *,
        agent_selector: typing.Optional[EntityIdsSelector] = OMIT,
        heartbeat_interval_ms: typing.Optional[int] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> typing.Iterator[StreamAsAgentResponse]:
        """
        Establishes a server streaming connection that delivers tasks to taskable agents for execution
        using Server-Sent Events (SSE).

        This method creates a connection from the Tasks API to an agent that streams relevant tasks to the listener agent. The agent receives a stream of tasks that match the entities specified by the tasks' selector criteria.

        The stream delivers three types of requests:
        - `ExecuteRequest`: Contains a new task for the agent to execute
        - `CancelRequest`: Indicates a task should be canceled
        - `CompleteRequest`: Indicates a task should be completed

        Additionally, heartbeat messages are sent periodically to maintain the connection.

        This is recommended method for taskable agents to receive and process tasks in real-time.
        Agents should maintain connection to this stream and process incoming tasks according to their capabilities.

        When an agent receives a task, it should update the task status using the `UpdateStatus` endpoint
        to provide progress information back to Tasks API.

        Parameters
        ----------
        agent_selector : typing.Optional[EntityIdsSelector]
            The selector criteria to determine which tasks the agent receives.

        heartbeat_interval_ms : typing.Optional[int]
            The time interval, defined in seconds, that determines the frequency at which to send heartbeat events. Defaults to 30s.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Yields
        ------
        typing.Iterator[StreamAsAgentResponse]
            Returns a stream of tasks to the agent as they become available.

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        response = client.tasks.stream_as_agent()
        for chunk in response:
            yield chunk
        """
        with self._raw_client.stream_as_agent(
            agent_selector=agent_selector, heartbeat_interval_ms=heartbeat_interval_ms, request_options=request_options
        ) as r:
            yield from r.data

    def stream_manual_control_frames(
        self,
        task_id: str,
        *,
        heartbeat_interval_ms: typing.Optional[int] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> typing.Iterator[StreamManualControlFramesResponse]:
        """
        Establishes a server streaming connection that delivers manual control frames to agents
        using server-sent events (SSE).

        This endpoint streams manual control frames, for example, for joystick movements, for a specific task
        to the executing agent. The agent should open this stream before reporting `STATUS_EXECUTING`
        to ensure it is ready to receive control input when the operator begins sending frames.

        Each frame includes epoch and sequence metadata for handling concurrent control sessions
        and detecting stale or out-of-order frames. Heartbeat messages are sent periodically to
        maintain the connection.

        The stream terminates automatically when the task reaches a terminal state
        (`STATUS_DONE_OK` or `STATUS_DONE_NOT_OK`).

        Parameters
        ----------
        task_id : str
            The ID of the manual control task to receive frames for.

        heartbeat_interval_ms : typing.Optional[int]
            The time interval, in milliseconds, that determines the frequency at which to send heartbeat events. Defaults to 30000 (30 seconds).

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Yields
        ------
        typing.Iterator[StreamManualControlFramesResponse]
            Returns a stream of manual control frames as they are sent by the operator.

        Examples
        --------
        from anduril import Lattice

        client = Lattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )
        response = client.tasks.stream_manual_control_frames(
            task_id="taskId",
        )
        for chunk in response:
            yield chunk
        """
        with self._raw_client.stream_manual_control_frames(
            task_id, heartbeat_interval_ms=heartbeat_interval_ms, request_options=request_options
        ) as r:
            yield from r.data


class AsyncTasksClient:
    def __init__(self, *, client_wrapper: AsyncClientWrapper):
        self._raw_client = AsyncRawTasksClient(client_wrapper=client_wrapper)

    @property
    def with_raw_response(self) -> AsyncRawTasksClient:
        """
        Retrieves a raw implementation of this client that returns raw responses.

        Returns
        -------
        AsyncRawTasksClient
        """
        return self._raw_client

    async def create_task(
        self,
        *,
        task_id: typing.Optional[str] = OMIT,
        display_name: typing.Optional[str] = OMIT,
        description: typing.Optional[str] = OMIT,
        specification: typing.Optional[GoogleProtobufAny] = OMIT,
        author: typing.Optional[Principal] = OMIT,
        relations: typing.Optional[Relations] = OMIT,
        is_executed_elsewhere: typing.Optional[bool] = OMIT,
        initial_entities: typing.Optional[typing.Sequence[TaskEntity]] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> Task:
        """
        Creates a new Task in the system with the specified parameters.

        This method initiates a new task with a unique ID (either provided or auto-generated),
        sets the initial task state to STATUS_CREATED, and establishes task ownership. The task
        can be assigned to a specific agent through the Relations field.

        Once created, a task enters the lifecycle workflow and can be tracked, updated, and managed
        through other Tasks API endpoints.

        Parameters
        ----------
        task_id : typing.Optional[str]
            If non-empty, will set the requested Task ID, otherwise will generate a new random
            GUID. Will reject if supplied Task ID does not match [A-Za-z0-9_-.]{5,36}.

        display_name : typing.Optional[str]
            Human readable display name for this Task, should be short (<100 chars).

        description : typing.Optional[str]
            Longer, free form human readable description of this Task.

        specification : typing.Optional[GoogleProtobufAny]
            The path for the Protobuf task definition, and the complete task data.

        author : typing.Optional[Principal]

        relations : typing.Optional[Relations]
            Any relationships associated with this Task, such as a parent Task or an assignee
            this Task is designated to for execution.

        is_executed_elsewhere : typing.Optional[bool]
            If set, then the service will not trigger execution of this task on an agent. Useful
            for when ingesting tasks from an external system that is triggering execution of tasks
            on agents.

        initial_entities : typing.Optional[typing.Sequence[TaskEntity]]
            Indicates an initial set of entities that can be used to execute an entity aware
            task. For example, an entity Objective, an entity Keep In Zone, etc.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task creation was successful

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.tasks.create_task()


        asyncio.run(main())
        """
        _response = await self._raw_client.create_task(
            task_id=task_id,
            display_name=display_name,
            description=description,
            specification=specification,
            author=author,
            relations=relations,
            is_executed_elsewhere=is_executed_elsewhere,
            initial_entities=initial_entities,
            request_options=request_options,
        )
        return _response.data

    async def get_task(self, task_id: str, *, request_options: typing.Optional[RequestOptions] = None) -> Task:
        """
        Retrieves a specific Task by its ID, with options to select a particular task version or view.

        This method returns detailed information about a task including its current status,
        specification, relations, and other metadata. The response includes the complete Task object
        with all associated fields.

        By default, the method returns the latest definition version of the task from the manager's
        perspective.

        Parameters
        ----------
        task_id : str
            ID of task to return

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task retrieval was successful.

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.tasks.get_task(
                task_id="taskId",
            )


        asyncio.run(main())
        """
        _response = await self._raw_client.get_task(task_id, request_options=request_options)
        return _response.data

    async def update_task_status(
        self,
        task_id: str,
        *,
        status_version: typing.Optional[int] = OMIT,
        new_status: typing.Optional[TaskStatus] = OMIT,
        author: typing.Optional[Principal] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> Task:
        """
        Updates the status of a Task as it progresses through its lifecycle.

        This method allows agents or operators to report the current state of a task,
        which could include changes to task status, and error information.

        Each status update increments the task's status_version. When updating status,
        clients must provide the current version to ensure consistency. The system rejects
        updates with mismatched versions to prevent race conditions.

        Terminal states (`STATUS_DONE_OK` and `STATUS_DONE_NOT_OK`) are permanent; once a task
        reaches these states, no further updates are allowed.

        Parameters
        ----------
        task_id : str
            ID of task to update status of

        status_version : typing.Optional[int]
            The status version of the task to update. This version number increments to indicate the task's
            current stage in its status lifecycle. Specifically, whenever a task's status updates, the status
            version increments by one. Any status updates received with a lower status version number than what
            is known are considered stale and ignored.

        new_status : typing.Optional[TaskStatus]
            The new status of the task.

        author : typing.Optional[Principal]

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task status update was successful

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.tasks.update_task_status(
                task_id="taskId",
            )


        asyncio.run(main())
        """
        _response = await self._raw_client.update_task_status(
            task_id,
            status_version=status_version,
            new_status=new_status,
            author=author,
            request_options=request_options,
        )
        return _response.data

    async def cancel_task(
        self,
        task_id: str,
        *,
        author: typing.Optional[Principal] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> Task:
        """
        Cancels a task by marking it for cancellation in the system.

        This method initiates task cancellation based on the task's current state:
        - If the task has not been sent to an agent, it cancels immediately and transitions the task
          to a terminal state (`STATUS_DONE_NOT_OK` with `ERROR_CODE_CANCELLED`).
        - If the task has already been sent to an agent, the cancellation request is routed to the agent.
          The agent is then responsible for deciding whether cancellation is possible or not:
          - If the task can be cancelled, the agent must use `UpdateTaskStatus` and set the task status to `STATUS_DONE_NOT_OK`.
          - If the task cannot be cancelled, the agent must use `UpdateTaskStatus` to attach a `TaskError` to the task with the error code `ERROR_CODE_REJECTED`
            and a `message` explaining why the task cannot be cancelled.

        Parameters
        ----------
        task_id : str
            The ID of task to cancel

        author : typing.Optional[Principal]
            Who or what is requesting to cancel this task.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        Task
            Task cancellation was successful.

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.tasks.cancel_task(
                task_id="taskId",
            )


        asyncio.run(main())
        """
        _response = await self._raw_client.cancel_task(task_id, author=author, request_options=request_options)
        return _response.data

    async def query_tasks(
        self,
        *,
        page_token: typing.Optional[str] = OMIT,
        parent_task_id: typing.Optional[str] = OMIT,
        status_filter: typing.Optional[TaskQueryStatusFilter] = OMIT,
        update_time_range: typing.Optional[TaskQueryUpdateTimeRange] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> TaskQueryResults:
        """
        Searches for Tasks that match specified filtering criteria and returns matching tasks in paginated form.

        This method allows filtering tasks based on multiple criteria including:
        - Parent task relationships
        - Task status (with inclusive or exclusive filtering)
        - Update time ranges
        - Task view (manager or agent perspective)
        - Task assignee
        - Task type (via exact URL matches or prefix matching)

        Results are returned in pages. When more results are available than can be returned in a single
        response, a page_token is provided that can be used in subsequent requests to retrieve the next
        set of results.

        By default, this returns the latest task version for each matching task from the manager's perspective.

        Parameters
        ----------
        page_token : typing.Optional[str]
            If set, returns results starting from the given pageToken.

        parent_task_id : typing.Optional[str]
            If present matches Tasks with this parent Task ID.
            Note: this is mutually exclusive with all other query parameters, for example, either provide parent task ID, or
            any of the remaining parameters, but not both.

        status_filter : typing.Optional[TaskQueryStatusFilter]

        update_time_range : typing.Optional[TaskQueryUpdateTimeRange]
            If provided, only provides Tasks updated within the time range.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        TaskQueryResults
            Task query was successful

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.tasks.query_tasks()


        asyncio.run(main())
        """
        _response = await self._raw_client.query_tasks(
            page_token=page_token,
            parent_task_id=parent_task_id,
            status_filter=status_filter,
            update_time_range=update_time_range,
            request_options=request_options,
        )
        return _response.data

    async def stream_tasks(
        self,
        *,
        heartbeat_interval_ms: typing.Optional[int] = OMIT,
        rate_limit: typing.Optional[int] = OMIT,
        exclude_preexisting_tasks: typing.Optional[bool] = OMIT,
        task_type: typing.Optional[TaskStreamRequestTaskType] = OMIT,
        update_start_time: typing.Optional[Timestamp] = OMIT,
        parent_task_id: typing.Optional[str] = OMIT,
        assignee: typing.Optional[Principal] = OMIT,
        status_filter: typing.Optional[TaskStreamRequestStatusFilter] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> typing.AsyncIterator[StreamTasksResponse]:
        """
        Establishes a server streaming connection that delivers task updates in real-time using Server-Sent Events (SSE).

        The stream delivers all existing non-terminal tasks when first connected, followed by real-time
        updates for task creation and status changes. Additionally, heartbeat messages are sent periodically to maintain the connection.

        Parameters
        ----------
        heartbeat_interval_ms : typing.Optional[int]
            The time interval, in milliseconds, that determines the frequency at which to send heartbeat events. Defaults to 30000 (30 seconds).

        rate_limit : typing.Optional[int]
            The time interval, in milliseconds, after an update for a given task before another one will be sent for the same task.
            If set, value must be >= 250.

        exclude_preexisting_tasks : typing.Optional[bool]
            Optional flag to only include tasks created or updated after the stream is initiated, and not any previous preexisting tasks.
            If unset or false, the stream will include any new tasks and task updates, as well as all preexisting tasks.

        task_type : typing.Optional[TaskStreamRequestTaskType]
            Optional filter that only returns tasks with specific types. If not provided, all task types will be streamed.

        update_start_time : typing.Optional[Timestamp]
            If provided, returns tasks which have been updated since the given time.

        parent_task_id : typing.Optional[str]
            A filter for tasks with a specific parent task ID.
            Note: This filter is mutually exclusive with all other filter fields (`updateStartTime`, `assignee`, `statusFilter`, `taskType`).
            Either provide `parentTaskId` or any combination of the other filters, but not both.

        assignee : typing.Optional[Principal]
            A filter for tasks assigned to a specific principal.

        status_filter : typing.Optional[TaskStreamRequestStatusFilter]
            A filter for task statuses (inclusive or exclusive).

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Yields
        ------
        typing.AsyncIterator[StreamTasksResponse]
            Returns a stream of task updates as they occur.

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            response = await client.tasks.stream_tasks()
            async for chunk in response:
                yield chunk


        asyncio.run(main())
        """
        async with self._raw_client.stream_tasks(
            heartbeat_interval_ms=heartbeat_interval_ms,
            rate_limit=rate_limit,
            exclude_preexisting_tasks=exclude_preexisting_tasks,
            task_type=task_type,
            update_start_time=update_start_time,
            parent_task_id=parent_task_id,
            assignee=assignee,
            status_filter=status_filter,
            request_options=request_options,
        ) as r:
            async for _chunk in r.data:
                yield _chunk

    async def listen_as_agent(
        self,
        *,
        agent_selector: typing.Optional[EntityIdsSelector] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> AgentRequest:
        """
        Establishes a server streaming connection that delivers tasks to taskable agents for execution.

        This method creates a persistent connection from Tasks API to an agent, allowing the server
        to push tasks to the agent as they become available. The agent receives a stream of tasks that
        match its selector criteria (entity IDs).

        The stream delivers three types of requests:
        - ExecuteRequest: Contains a new task for the agent to execute
        - CancelRequest: Indicates a task should be canceled
        - CompleteRequest: Indicates a task should be completed

        This is the primary method for taskable agents to receive and process tasks in real-time.
        Agents should maintain this connection and process incoming tasks according to their capabilities.

        When an agent receives a task, it should update the task status using the UpdateStatus endpoint
        to provide progress information back to Tasks API.

        This is a long polling API that will block until a new task is ready for delivery. If no new task is
        available then the server will hold on to your request for up to 5 minutes, after that 5 minute timeout
        period you will be expected to reinitiate a new request.

        Parameters
        ----------
        agent_selector : typing.Optional[EntityIdsSelector]
            Selector criteria to determine which Agent Tasks the agent receives

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Returns
        -------
        AgentRequest
            Requests for the agent to comply with.

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            await client.tasks.listen_as_agent()


        asyncio.run(main())
        """
        _response = await self._raw_client.listen_as_agent(
            agent_selector=agent_selector, request_options=request_options
        )
        return _response.data

    async def stream_as_agent(
        self,
        *,
        agent_selector: typing.Optional[EntityIdsSelector] = OMIT,
        heartbeat_interval_ms: typing.Optional[int] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> typing.AsyncIterator[StreamAsAgentResponse]:
        """
        Establishes a server streaming connection that delivers tasks to taskable agents for execution
        using Server-Sent Events (SSE).

        This method creates a connection from the Tasks API to an agent that streams relevant tasks to the listener agent. The agent receives a stream of tasks that match the entities specified by the tasks' selector criteria.

        The stream delivers three types of requests:
        - `ExecuteRequest`: Contains a new task for the agent to execute
        - `CancelRequest`: Indicates a task should be canceled
        - `CompleteRequest`: Indicates a task should be completed

        Additionally, heartbeat messages are sent periodically to maintain the connection.

        This is recommended method for taskable agents to receive and process tasks in real-time.
        Agents should maintain connection to this stream and process incoming tasks according to their capabilities.

        When an agent receives a task, it should update the task status using the `UpdateStatus` endpoint
        to provide progress information back to Tasks API.

        Parameters
        ----------
        agent_selector : typing.Optional[EntityIdsSelector]
            The selector criteria to determine which tasks the agent receives.

        heartbeat_interval_ms : typing.Optional[int]
            The time interval, defined in seconds, that determines the frequency at which to send heartbeat events. Defaults to 30s.

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Yields
        ------
        typing.AsyncIterator[StreamAsAgentResponse]
            Returns a stream of tasks to the agent as they become available.

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            response = await client.tasks.stream_as_agent()
            async for chunk in response:
                yield chunk


        asyncio.run(main())
        """
        async with self._raw_client.stream_as_agent(
            agent_selector=agent_selector, heartbeat_interval_ms=heartbeat_interval_ms, request_options=request_options
        ) as r:
            async for _chunk in r.data:
                yield _chunk

    async def stream_manual_control_frames(
        self,
        task_id: str,
        *,
        heartbeat_interval_ms: typing.Optional[int] = OMIT,
        request_options: typing.Optional[RequestOptions] = None,
    ) -> typing.AsyncIterator[StreamManualControlFramesResponse]:
        """
        Establishes a server streaming connection that delivers manual control frames to agents
        using server-sent events (SSE).

        This endpoint streams manual control frames, for example, for joystick movements, for a specific task
        to the executing agent. The agent should open this stream before reporting `STATUS_EXECUTING`
        to ensure it is ready to receive control input when the operator begins sending frames.

        Each frame includes epoch and sequence metadata for handling concurrent control sessions
        and detecting stale or out-of-order frames. Heartbeat messages are sent periodically to
        maintain the connection.

        The stream terminates automatically when the task reaches a terminal state
        (`STATUS_DONE_OK` or `STATUS_DONE_NOT_OK`).

        Parameters
        ----------
        task_id : str
            The ID of the manual control task to receive frames for.

        heartbeat_interval_ms : typing.Optional[int]
            The time interval, in milliseconds, that determines the frequency at which to send heartbeat events. Defaults to 30000 (30 seconds).

        request_options : typing.Optional[RequestOptions]
            Request-specific configuration.

        Yields
        ------
        typing.AsyncIterator[StreamManualControlFramesResponse]
            Returns a stream of manual control frames as they are sent by the operator.

        Examples
        --------
        import asyncio

        from anduril import AsyncLattice

        client = AsyncLattice(
            client_id="YOUR_CLIENT_ID",
            client_secret="YOUR_CLIENT_SECRET",
        )


        async def main() -> None:
            response = await client.tasks.stream_manual_control_frames(
                task_id="taskId",
            )
            async for chunk in response:
                yield chunk


        asyncio.run(main())
        """
        async with self._raw_client.stream_manual_control_frames(
            task_id, heartbeat_interval_ms=heartbeat_interval_ms, request_options=request_options
        ) as r:
            async for _chunk in r.data:
                yield _chunk
