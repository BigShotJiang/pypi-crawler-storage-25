# This file was auto-generated from our API Definition.

import typing

import pydantic
from ...core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .task_query_status_filter_status import TaskQueryStatusFilterStatus


class TaskQueryStatusFilter(UniversalBaseModel):
    status: typing.Optional[TaskQueryStatusFilterStatus] = pydantic.Field(default=None)
    """
    Status of the Task to filter by, inclusive.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
