# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ...core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ...core.serialization import FieldMetadata


class TaskStreamRequestTaskTypeTaskTypeUrls(UniversalBaseModel):
    task_type_urls: typing_extensions.Annotated[
        typing.List[str],
        FieldMetadata(alias="taskTypeUrls"),
        pydantic.Field(alias="taskTypeUrls", description="List of exact task type URLs to match."),
    ]

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
