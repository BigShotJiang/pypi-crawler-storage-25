# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ...core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ...core.serialization import FieldMetadata
from ...types.cancel_request import CancelRequest
from ...types.complete_request import CompleteRequest
from ...types.execute_request import ExecuteRequest


class StreamAsAgentResponse_Heartbeat(UniversalBaseModel):
    """
    The stream event response.
    """

    event: typing.Literal["heartbeat"] = "heartbeat"
    timestamp: typing.Optional[str] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


class StreamAsAgentResponse_AgentRequest(UniversalBaseModel):
    """
    The stream event response.
    """

    event: typing.Literal["agent_request"] = "agent_request"
    execute_request: typing_extensions.Annotated[
        typing.Optional[ExecuteRequest], FieldMetadata(alias="executeRequest"), pydantic.Field(alias="executeRequest")
    ] = None
    cancel_request: typing_extensions.Annotated[
        typing.Optional[CancelRequest], FieldMetadata(alias="cancelRequest"), pydantic.Field(alias="cancelRequest")
    ] = None
    complete_request: typing_extensions.Annotated[
        typing.Optional[CompleteRequest],
        FieldMetadata(alias="completeRequest"),
        pydantic.Field(alias="completeRequest"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


StreamAsAgentResponse = typing_extensions.Annotated[
    typing.Union[StreamAsAgentResponse_Heartbeat, StreamAsAgentResponse_AgentRequest],
    pydantic.Field(discriminator="event"),
]
update_forward_refs(StreamAsAgentResponse_AgentRequest)
