# This file was auto-generated from our API Definition.

import typing

from ..core.api_error import ApiError
from ..entity.types.error import Error


class RequestTimeoutError(ApiError):
    def __init__(self, body: Error, headers: typing.Optional[typing.Dict[str, str]] = None):
        super().__init__(status_code=408, headers=headers, body=body)
