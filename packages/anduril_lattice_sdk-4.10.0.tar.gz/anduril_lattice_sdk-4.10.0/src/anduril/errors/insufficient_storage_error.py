# This file was auto-generated from our API Definition.

import typing

from ..core.api_error import ApiError
from ..object.types.error import Error


class InsufficientStorageError(ApiError):
    def __init__(self, body: Error, headers: typing.Optional[typing.Dict[str, str]] = None):
        super().__init__(status_code=507, headers=headers, body=body)
