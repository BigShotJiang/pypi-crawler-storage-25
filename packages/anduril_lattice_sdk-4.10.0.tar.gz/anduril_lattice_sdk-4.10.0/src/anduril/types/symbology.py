# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .mil_std2525c import MilStd2525C


class Symbology(UniversalBaseModel):
    """
    Symbology associated with an entity.
    """

    mil_std2525c: typing_extensions.Annotated[
        typing.Optional[MilStd2525C], FieldMetadata(alias="milStd2525C"), pydantic.Field(alias="milStd2525C")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
