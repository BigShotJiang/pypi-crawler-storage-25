# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .position import Position
from .quaternion import Quaternion


class EntityManagerPose(UniversalBaseModel):
    pos: typing.Optional[Position] = pydantic.Field(default=None)
    """
    Geospatial location defined by this Pose.
    """

    orientation: typing.Optional[Quaternion] = pydantic.Field(default=None)
    """
    The quaternion to transform a point in the Pose frame to the ENU frame. The Pose frame could be Body, Turret,
     etc and is determined by the context in which this Pose is used.
     The normal convention for defining orientation is to list the frames of transformation, for example
     att_gimbal_to_enu is the quaternion which transforms a point in the gimbal frame to the body frame, but
     in this case we truncate to att_enu because the Pose frame isn't defined. A potentially better name for this
     field would have been att_pose_to_enu.
    
     Implementations of this quaternion should left multiply this quaternion to transform a point from the Pose frame
     to the enu frame.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
