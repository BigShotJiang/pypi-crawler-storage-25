# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class ErrorEllipse(UniversalBaseModel):
    """
    Indicates ellipse characteristics and probability that an entity lies within the defined ellipse.
    """

    probability: typing.Optional[float] = pydantic.Field(default=None)
    """
    Defines the probability in percentage that an entity lies within the given ellipse: 0-1.
    """

    semi_major_axis_m: typing_extensions.Annotated[
        typing.Optional[float],
        FieldMetadata(alias="semiMajorAxisM"),
        pydantic.Field(
            alias="semiMajorAxisM",
            description="Defines the distance from the center point of the ellipse to the furthest distance on the perimeter in meters.",
        ),
    ] = None
    semi_minor_axis_m: typing_extensions.Annotated[
        typing.Optional[float],
        FieldMetadata(alias="semiMinorAxisM"),
        pydantic.Field(
            alias="semiMinorAxisM",
            description="Defines the distance from the center point of the ellipse to the shortest distance on the perimeter in meters.",
        ),
    ] = None
    orientation_d: typing_extensions.Annotated[
        typing.Optional[float],
        FieldMetadata(alias="orientationD"),
        pydantic.Field(
            alias="orientationD",
            description="The orientation of the semi-major relative to true north in degrees from clockwise: 0-180 due to symmetry across the semi-minor axis.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
