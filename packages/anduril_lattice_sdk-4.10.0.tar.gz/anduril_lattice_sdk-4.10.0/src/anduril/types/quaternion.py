# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel


class Quaternion(UniversalBaseModel):
    x: typing.Optional[float] = pydantic.Field(default=None)
    """
    x, y, z are vector portion, w is scalar
    """

    y: typing.Optional[float] = None
    z: typing.Optional[float] = None
    w: typing.Optional[float] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
