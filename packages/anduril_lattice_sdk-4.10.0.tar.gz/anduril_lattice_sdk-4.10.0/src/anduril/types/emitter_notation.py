# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class EmitterNotation(UniversalBaseModel):
    """
    A representation of a single emitter notation.
    """

    emitter_notation: typing_extensions.Annotated[
        typing.Optional[str], FieldMetadata(alias="emitterNotation"), pydantic.Field(alias="emitterNotation")
    ] = None
    confidence: typing.Optional[float] = pydantic.Field(default=None)
    """
    confidence as a percentage that the emitter notation in this component is accurate
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
