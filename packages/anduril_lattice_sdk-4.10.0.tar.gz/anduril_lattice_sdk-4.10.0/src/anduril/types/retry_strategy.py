# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .fixed_retry import FixedRetry


class RetryStrategy(UniversalBaseModel):
    """
    Sets an optional try strategy for tasks. Use this option to control how Lattice attempts to retry delivery of tasks to assets with intermittent access or network connectivity to your environment.
    """

    fixed_retry_strategy: typing_extensions.Annotated[
        typing.Optional[FixedRetry],
        FieldMetadata(alias="fixedRetryStrategy"),
        pydantic.Field(alias="fixedRetryStrategy"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
