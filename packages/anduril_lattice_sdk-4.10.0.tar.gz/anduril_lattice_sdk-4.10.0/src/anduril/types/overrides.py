# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs


class Overrides(UniversalBaseModel):
    """
    Metadata about entity overrides present.
    """

    override: typing.Optional[typing.List["Override"]] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


from .entity import Entity  # noqa: E402, I001
from .override import Override  # noqa: E402, I001

update_forward_refs(Overrides, Entity=Entity, Override=Override)
