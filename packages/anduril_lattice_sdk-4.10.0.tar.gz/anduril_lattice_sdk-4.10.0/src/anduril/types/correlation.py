# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .correlation_membership import CorrelationMembership
from .decorrelation import Decorrelation
from .primary_correlation import PrimaryCorrelation
from .secondary_correlation import SecondaryCorrelation


class Correlation(UniversalBaseModel):
    """
    Available for Entities that are a correlated (N to 1) set of entities. This will be present on
     each entity in the set.
    """

    primary: typing.Optional[PrimaryCorrelation] = pydantic.Field(default=None)
    """
    This entity is the primary of a correlation meaning that it serves as the representative
     entity of the correlation set.
    """

    secondary: typing.Optional[SecondaryCorrelation] = pydantic.Field(default=None)
    """
    This entity is a secondary of a correlation meaning that it will be represented by the
     primary of the correlation set.
    """

    membership: typing.Optional[CorrelationMembership] = pydantic.Field(default=None)
    """
    If present, this entity is a part of a correlation set.
    """

    decorrelation: typing.Optional[Decorrelation] = pydantic.Field(default=None)
    """
    If present, this entity was explicitly decorrelated from one or more entities.
     An entity can be both correlated and decorrelated as long as they are disjoint sets.
     An example would be if a user in the UI decides that two tracks are not actually the
     same despite an automatic correlator having correlated them. The user would then
     decorrelate the two tracks and this decorrelation would be preserved preventing the
     correlator from re-correlating them at a later time.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
