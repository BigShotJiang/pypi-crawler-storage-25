# This file was auto-generated from our API Definition.

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class DeliveryConstraints(UniversalBaseModel):
    """
    DeliveryConstraints defines when Lattice should deliver the task to the agent.
    """

    deliver_after: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="deliverAfter"),
        pydantic.Field(
            alias="deliverAfter", description="Optional earliest time the task can attempt to be delivered."
        ),
    ] = None
    deliver_before: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="deliverBefore"),
        pydantic.Field(
            alias="deliverBefore",
            description="The latest time by which the task should be delivered.\n If this deadline passes without successful delivery of the task, then the task will time\n out with DELIVERY_ERROR_CODE_TIMEOUT.\n This field is only required for tasks with retry strategies.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
