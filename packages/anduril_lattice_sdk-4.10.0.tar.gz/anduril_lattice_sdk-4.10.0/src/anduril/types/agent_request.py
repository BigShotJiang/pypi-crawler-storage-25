# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .cancel_request import CancelRequest
from .complete_request import CompleteRequest
from .execute_request import ExecuteRequest


class AgentRequest(UniversalBaseModel):
    """
    Response streamed to an agent containing task actions to perform.

    This message is streamed from Tasks API to agents and contains one of three
    possible requests: execute a task, cancel a task, or complete a task. The agent
    should process these requests according to its capabilities and report status
    updates back to Tasks API using the UpdateStatus endpoint.

    Multiple responses may be sent for different tasks, and the agent should maintain
    the connection to receive ongoing task requests. The connection may also be used
    for heartbeat messages to ensure the agent is still responsive.
    """

    execute_request: typing_extensions.Annotated[
        typing.Optional[ExecuteRequest], FieldMetadata(alias="executeRequest"), pydantic.Field(alias="executeRequest")
    ] = None
    cancel_request: typing_extensions.Annotated[
        typing.Optional[CancelRequest], FieldMetadata(alias="cancelRequest"), pydantic.Field(alias="cancelRequest")
    ] = None
    complete_request: typing_extensions.Annotated[
        typing.Optional[CompleteRequest],
        FieldMetadata(alias="completeRequest"),
        pydantic.Field(alias="completeRequest"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(AgentRequest)
