# This file was auto-generated from our API Definition.

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .allocation import Allocation
from .google_protobuf_any import GoogleProtobufAny
from .task_error import TaskError
from .task_status_status import TaskStatusStatus


class TaskStatus(UniversalBaseModel):
    """
    Comprehensive status information for a task at a given point in time.

     TaskStatus contains all status-related information for a task, including its current state,
     any error conditions, progress details, results, timing information, and resource allocations.
     This object evolves throughout a task's lifecycle, providing increasing detail as the task
     progresses from creation through execution to completion.
    """

    status: typing.Optional[TaskStatusStatus] = pydantic.Field(default=None)
    """
    Status of the task.
    """

    task_error: typing_extensions.Annotated[
        typing.Optional[TaskError],
        FieldMetadata(alias="taskError"),
        pydantic.Field(alias="taskError", description="Any errors associated with the task."),
    ] = None
    progress: typing.Optional[GoogleProtobufAny] = pydantic.Field(default=None)
    """
    Any incremental progress on the task, should be from the tasks/v* /progress folder.
    """

    result: typing.Optional[GoogleProtobufAny] = pydantic.Field(default=None)
    """
    Any final result of the task, should be from tasks/v* /result folder.
    """

    start_time: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="startTime"),
        pydantic.Field(
            alias="startTime", description="Time the task began execution, may not be known even for executing Tasks."
        ),
    ] = None
    estimate: typing.Optional[GoogleProtobufAny] = pydantic.Field(default=None)
    """
    Any estimate for how the task will progress, should be from tasks/v* /estimates folder.
    """

    allocation: typing.Optional[Allocation] = pydantic.Field(default=None)
    """
    Any allocated agents of the task.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
