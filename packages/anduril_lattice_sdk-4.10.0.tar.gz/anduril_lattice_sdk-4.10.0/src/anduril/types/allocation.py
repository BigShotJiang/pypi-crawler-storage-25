# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .agent import Agent


class Allocation(UniversalBaseModel):
    """
    Allocation contains a list of agents allocated to a task.
    """

    active_agents: typing_extensions.Annotated[
        typing.Optional[typing.List[Agent]],
        FieldMetadata(alias="activeAgents"),
        pydantic.Field(alias="activeAgents", description="Agents actively being utilized in a task."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
