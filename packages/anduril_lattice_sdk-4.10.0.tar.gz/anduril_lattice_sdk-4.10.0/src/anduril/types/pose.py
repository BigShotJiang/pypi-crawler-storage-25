# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .lla import Lla
from .quaternion import Quaternion


class Pose(UniversalBaseModel):
    pos: typing.Optional[Lla] = pydantic.Field(default=None)
    """
    Geospatial location defined by this Pose.
    """

    att_enu: typing_extensions.Annotated[
        typing.Optional[Quaternion],
        FieldMetadata(alias="attEnu"),
        pydantic.Field(
            alias="attEnu",
            description="The quaternion to transform a point in the Pose frame to the ENU frame. The Pose frame could be Body, Turret,\n etc and is determined by the context in which this Pose is used.\n The normal convention for defining orientation is to list the frames of transformation, for example\n att_gimbal_to_enu is the quaternion which transforms a point in the gimbal frame to the body frame, but\n in this case we truncate to att_enu because the Pose frame isn't defined. A potentially better name for this\n field would have been att_pose_to_enu.\n\n Implementations of this quaternion should left multiply this quaternion to transform a point from the Pose frame\n to the enu frame.\n\n Point<Pose\\> posePt{1,0,0};\n Rotation<Enu, Pose\\> attPoseToEnu{};\n Point<Enu\\> = attPoseToEnu*posePt;\n\n This transformed point represents some vector in ENU space that is aligned with the x axis of the attPoseToEnu\n matrix.\n\n An alternative matrix expression is as follows:\n ptEnu = M x ptPose",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
