# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class AlertCondition(UniversalBaseModel):
    """
    A condition which may trigger an alert.
    """

    condition_code: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="conditionCode"),
        pydantic.Field(
            alias="conditionCode",
            description="Short, machine-readable code that describes this condition. This code is intended to provide systems off-asset\n with a lookup key to retrieve more detailed information about the condition.",
        ),
    ] = None
    description: typing.Optional[str] = pydantic.Field(default=None)
    """
    Human-readable description of this condition. The description is intended for display in the UI for human
     understanding and should not be used for machine processing. If the description is fixed and the vehicle controller
     provides no dynamic substitutions, then prefer lookup based on condition_code.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
