# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .classification_information import ClassificationInformation
from .field_classification_information import FieldClassificationInformation


class Classification(UniversalBaseModel):
    """
    A component that describes an entity's security classification levels.
    """

    default: typing.Optional[ClassificationInformation] = pydantic.Field(default=None)
    """
    The default classification information which should be assumed to apply to everything in
     the entity unless a specific field level classification is present.
    """

    fields: typing.Optional[typing.List[FieldClassificationInformation]] = pydantic.Field(default=None)
    """
    The set of individual field classification information which should always precedence
     over the default classification information.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
