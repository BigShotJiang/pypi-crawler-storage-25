# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel


class ModeS(UniversalBaseModel):
    """
    Describes the Mode S codes.
    """

    id: typing.Optional[str] = pydantic.Field(default=None)
    """
    Mode S identifier which comprises of 8 alphanumeric characters.
    """

    address: typing.Optional[int] = pydantic.Field(default=None)
    """
    The Mode S ICAO aircraft address. Expected values are between 1 and 16777214 decimal. The Mode S address is
     considered unique.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
