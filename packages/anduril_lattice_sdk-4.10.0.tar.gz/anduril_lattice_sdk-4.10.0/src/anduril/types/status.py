# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class Status(UniversalBaseModel):
    """
    Contains status of entities.
    """

    platform_activity: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="platformActivity"),
        pydantic.Field(
            alias="platformActivity",
            description='A string that describes the activity that the entity is performing.\n Examples include "RECONNAISSANCE", "INTERDICTION", "RETURN TO BASE (RTB)", "PREPARING FOR LAUNCH".',
        ),
    ] = None
    role: typing.Optional[str] = pydantic.Field(default=None)
    """
    A human-readable string that describes the role the entity is currently performing. E.g. "Team Member", "Commander".
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
