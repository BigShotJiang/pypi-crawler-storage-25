# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .position import Position


class GeoLine(UniversalBaseModel):
    """
    A line shaped geo-entity.
     See https://datatracker.ietf.org/doc/html/rfc7946#section-3.1.4
    """

    positions: typing.Optional[typing.List[Position]] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
