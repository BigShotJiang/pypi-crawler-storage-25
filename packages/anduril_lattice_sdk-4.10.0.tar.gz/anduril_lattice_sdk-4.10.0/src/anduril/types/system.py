# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class System(UniversalBaseModel):
    """
    System Principal representing some autonomous system.
    """

    service_name: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="serviceName"),
        pydantic.Field(alias="serviceName", description="Name of the service associated with this System."),
    ] = None
    entity_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="entityId"),
        pydantic.Field(alias="entityId", description="The Entity ID of the System."),
    ] = None
    manages_own_scheduling: typing_extensions.Annotated[
        typing.Optional[bool],
        FieldMetadata(alias="managesOwnScheduling"),
        pydantic.Field(
            alias="managesOwnScheduling",
            description="Whether the System Principal (for example, an Asset) can own scheduling.\n This means we bypass manager-owned scheduling and defer to the system\n Principal to handle scheduling and give us status updates for the task.\n Regardless of the value defined by the client, the Task Manager will\n determine and set this value appropriately.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
