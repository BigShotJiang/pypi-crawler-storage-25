# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class GoogleProtobufAny(UniversalBaseModel):
    """
    Contains an arbitrary serialized message along with a @type that describes the type of the serialized message.
    """

    type: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="@type"),
        pydantic.Field(alias="@type", description="The type of the serialized message."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
