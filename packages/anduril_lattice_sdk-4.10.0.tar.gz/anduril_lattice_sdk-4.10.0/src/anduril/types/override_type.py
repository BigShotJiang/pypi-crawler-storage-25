# This file was auto-generated from our API Definition.

import typing

OverrideType = typing.Union[
    typing.Literal["OVERRIDE_TYPE_INVALID", "OVERRIDE_TYPE_LIVE", "OVERRIDE_TYPE_POST_EXPIRY"], typing.Any
]
