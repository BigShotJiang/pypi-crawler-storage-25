# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .cancel_request import CancelRequest
from .complete_request import CompleteRequest
from .execute_request import ExecuteRequest


class AgentTaskRequest(UniversalBaseModel):
    """
    The wrapper for a task's action requests: execute, cancel, or complete.
    """

    execute_request: typing_extensions.Annotated[
        typing.Optional[ExecuteRequest], FieldMetadata(alias="executeRequest"), pydantic.Field(alias="executeRequest")
    ] = None
    cancel_request: typing_extensions.Annotated[
        typing.Optional[CancelRequest], FieldMetadata(alias="cancelRequest"), pydantic.Field(alias="cancelRequest")
    ] = None
    complete_request: typing_extensions.Annotated[
        typing.Optional[CompleteRequest],
        FieldMetadata(alias="completeRequest"),
        pydantic.Field(alias="completeRequest"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(AgentTaskRequest)
