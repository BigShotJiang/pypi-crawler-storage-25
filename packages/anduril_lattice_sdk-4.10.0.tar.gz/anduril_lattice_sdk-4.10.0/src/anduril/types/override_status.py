# This file was auto-generated from our API Definition.

import typing

OverrideStatus = typing.Union[
    typing.Literal[
        "OVERRIDE_STATUS_INVALID",
        "OVERRIDE_STATUS_APPLIED",
        "OVERRIDE_STATUS_PENDING",
        "OVERRIDE_STATUS_TIMEOUT",
        "OVERRIDE_STATUS_REJECTED",
        "OVERRIDE_STATUS_DELETION_PENDING",
    ],
    typing.Any,
]
