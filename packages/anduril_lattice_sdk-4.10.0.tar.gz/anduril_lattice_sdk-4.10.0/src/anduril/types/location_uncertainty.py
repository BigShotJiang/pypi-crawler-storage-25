# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .entity_manager_t_mat3 import EntityManagerTMat3
from .error_ellipse import ErrorEllipse


class LocationUncertainty(UniversalBaseModel):
    """
    Uncertainty of entity position and velocity, if available.
    """

    position_enu_cov: typing_extensions.Annotated[
        typing.Optional[EntityManagerTMat3],
        FieldMetadata(alias="positionEnuCov"),
        pydantic.Field(
            alias="positionEnuCov",
            description="Positional covariance represented by the upper triangle of the covariance matrix. It is valid to populate\n only the diagonal of the matrix if the full covariance matrix is unknown.",
        ),
    ] = None
    velocity_enu_cov: typing_extensions.Annotated[
        typing.Optional[EntityManagerTMat3],
        FieldMetadata(alias="velocityEnuCov"),
        pydantic.Field(
            alias="velocityEnuCov",
            description="Velocity covariance represented by the upper triangle of the covariance matrix. It is valid to populate\n only the diagonal of the matrix if the full covariance matrix is unknown.",
        ),
    ] = None
    position_error_ellipse: typing_extensions.Annotated[
        typing.Optional[ErrorEllipse],
        FieldMetadata(alias="positionErrorEllipse"),
        pydantic.Field(
            alias="positionErrorEllipse",
            description="An ellipse that describes the certainty probability and error boundary for a given geolocation.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
