# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .system import System
from .team import Team
from .user import User


class Principal(UniversalBaseModel):
    """
    A Principal is an entity that has authority over this task.
    """

    system: typing.Optional[System] = None
    user: typing.Optional[User] = None
    team: typing.Optional[Team] = None
    on_behalf_of: typing_extensions.Annotated[
        typing.Optional["Principal"],
        FieldMetadata(alias="onBehalfOf"),
        pydantic.Field(
            alias="onBehalfOf",
            description='The Principal _this_ Principal is acting on behalf of.\n\n Likely only populated once in the nesting (i.e. the "on_behalf_of" Principal would not have another "on_behalf_of" in most cases).',
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(Principal)
