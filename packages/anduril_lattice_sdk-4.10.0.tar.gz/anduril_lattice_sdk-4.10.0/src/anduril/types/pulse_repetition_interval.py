# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .measurement import Measurement


class PulseRepetitionInterval(UniversalBaseModel):
    """
    A component that describe the length in time between two pulses
    """

    pulse_repetition_interval_s: typing_extensions.Annotated[
        typing.Optional[Measurement],
        FieldMetadata(alias="pulseRepetitionIntervalS"),
        pydantic.Field(alias="pulseRepetitionIntervalS"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
