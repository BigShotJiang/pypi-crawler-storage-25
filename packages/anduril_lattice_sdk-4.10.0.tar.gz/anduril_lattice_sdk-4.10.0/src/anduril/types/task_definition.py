# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class TaskDefinition(UniversalBaseModel):
    """
    Defines a supported task by the task specification URL of its "Any" type.
    """

    task_specification_url: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="taskSpecificationUrl"),
        pydantic.Field(
            alias="taskSpecificationUrl", description="Url path must be prefixed with `type.googleapis.com/`."
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
