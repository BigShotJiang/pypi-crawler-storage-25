# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .task_event_data_task_event import TaskEventDataTaskEvent


class TaskEventData(UniversalBaseModel):
    """
    Contains information about a task event.
    """

    task_event: typing_extensions.Annotated[
        typing.Optional[TaskEventDataTaskEvent],
        FieldMetadata(alias="taskEvent"),
        pydantic.Field(alias="taskEvent", description="The task event that occurred."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(TaskEventData)
