# This file was auto-generated from our API Definition.

import typing

DeliveryErrorCode = typing.Union[
    typing.Literal[
        "DELIVERY_ERROR_CODE_INVALID",
        "DELIVERY_ERROR_CODE_UNAVAILABLE",
        "DELIVERY_ERROR_CODE_TIMEOUT",
        "DELIVERY_ERROR_CODE_REJECTED",
    ],
    typing.Any,
]
