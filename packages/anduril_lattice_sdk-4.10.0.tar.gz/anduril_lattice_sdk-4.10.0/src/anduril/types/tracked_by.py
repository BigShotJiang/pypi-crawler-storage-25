# This file was auto-generated from our API Definition.

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .sensors import Sensors


class TrackedBy(UniversalBaseModel):
    """
    Describes the relationship between the entity being tracked ("tracked entity") and the entity that is
     performing the tracking ("tracking entity").
    """

    actively_tracking_sensors: typing_extensions.Annotated[
        typing.Optional[Sensors],
        FieldMetadata(alias="activelyTrackingSensors"),
        pydantic.Field(
            alias="activelyTrackingSensors",
            description="Sensor details of the tracking entity's sensors that were active and tracking the tracked entity. This may be\n a subset of the total sensors available on the tracking entity.",
        ),
    ] = None
    last_measurement_timestamp: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="lastMeasurementTimestamp"),
        pydantic.Field(
            alias="lastMeasurementTimestamp",
            description="Latest time that any sensor in actively_tracking_sensors detected the tracked entity.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
