# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .correlation_metadata import CorrelationMetadata
from .non_primary_membership import NonPrimaryMembership
from .primary_membership import PrimaryMembership


class CorrelationMembership(UniversalBaseModel):
    correlation_set_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="correlationSetId"),
        pydantic.Field(alias="correlationSetId", description="The ID of the correlation set this entity belongs to."),
    ] = None
    primary: typing.Optional[PrimaryMembership] = pydantic.Field(default=None)
    """
    This entity is the primary of a correlation set meaning that it serves as the representative
     entity of the correlation set.
    """

    non_primary: typing_extensions.Annotated[
        typing.Optional[NonPrimaryMembership],
        FieldMetadata(alias="nonPrimary"),
        pydantic.Field(
            alias="nonPrimary",
            description="This entity is not the primary of the correlation set. Note that there may not\n be a primary at all.",
        ),
    ] = None
    metadata: typing.Optional[CorrelationMetadata] = pydantic.Field(default=None)
    """
    Additional metadata on this correlation.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
