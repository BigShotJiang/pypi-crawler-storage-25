# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .task import Task


class TaskQueryResults(UniversalBaseModel):
    """
    Response containing tasks that match the query criteria.

    This message returns a list of Task objects that satisfy the filter conditions
    specified in the request. When there are more matching tasks than can be returned
    in a single response, a page_token is provided to retrieve the next batch in
    a subsequent request. An empty tasks list with no page_token indicates that
    there are no more matching tasks.
    """

    tasks: typing.Optional[typing.List[Task]] = None
    next_page_token: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="nextPageToken"),
        pydantic.Field(
            alias="nextPageToken",
            description="Incomplete results can be detected by a non-empty nextPageToken field in the query results. In order to retrieve \nthe next page, perform the exact same request as previously and append a pageToken field with the value of \nnextPageToken from the previous page. A new nextPageToken is provided on the following pages until all the \nresults are retrieved.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(TaskQueryResults)
