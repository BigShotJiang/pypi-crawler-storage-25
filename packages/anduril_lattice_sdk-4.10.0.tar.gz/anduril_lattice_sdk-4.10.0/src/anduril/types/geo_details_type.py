# This file was auto-generated from our API Definition.

import typing

GeoDetailsType = typing.Union[
    typing.Literal[
        "GEO_TYPE_INVALID",
        "GEO_TYPE_GENERAL",
        "GEO_TYPE_HAZARD",
        "GEO_TYPE_EMERGENCY",
        "GEO_TYPE_ENGAGEMENT_ZONE",
        "GEO_TYPE_CONTROL_AREA",
        "GEO_TYPE_BULLSEYE",
        "GEO_TYPE_ACM",
    ],
    typing.Any,
]
