# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .angle_of_arrival import AngleOfArrival
from .measurement import Measurement


class LineOfBearing(UniversalBaseModel):
    """
    A line of bearing of a signal.
    """

    angle_of_arrival: typing_extensions.Annotated[
        typing.Optional[AngleOfArrival],
        FieldMetadata(alias="angleOfArrival"),
        pydantic.Field(alias="angleOfArrival", description="The direction pointing from this entity to the detection"),
    ] = None
    range_estimate_m: typing_extensions.Annotated[
        typing.Optional[Measurement],
        FieldMetadata(alias="rangeEstimateM"),
        pydantic.Field(alias="rangeEstimateM", description="The estimated distance of the detection"),
    ] = None
    max_range_m: typing_extensions.Annotated[
        typing.Optional[Measurement],
        FieldMetadata(alias="maxRangeM"),
        pydantic.Field(alias="maxRangeM", description="The maximum distance of the detection"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
