# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .google_protobuf_any import GoogleProtobufAny
from .task_error_code import TaskErrorCode


class TaskError(UniversalBaseModel):
    """
    Error information associated with a task.

     TaskError contains structured error details, including an error code, a human-readable
     message, and optional extended error information. This structure is used when a task
     encounters problems during its lifecycle.
    """

    code: typing.Optional[TaskErrorCode] = pydantic.Field(default=None)
    """
    Error code for task error.
    """

    message: typing.Optional[str] = pydantic.Field(default=None)
    """
    Descriptive human-readable string regarding this error.
    """

    error_details: typing_extensions.Annotated[
        typing.Optional[GoogleProtobufAny],
        FieldMetadata(alias="errorDetails"),
        pydantic.Field(alias="errorDetails", description="Any additional details regarding this error."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
