# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .power_source import PowerSource


class PowerState(UniversalBaseModel):
    """
    Represents the state of power sources connected to this entity.
    """

    source_id_to_state: typing_extensions.Annotated[
        typing.Optional[typing.Dict[str, PowerSource]],
        FieldMetadata(alias="sourceIdToState"),
        pydantic.Field(
            alias="sourceIdToState",
            description="This is a map where the key is a unique id of the power source and the value is additional information about the\n power source.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
