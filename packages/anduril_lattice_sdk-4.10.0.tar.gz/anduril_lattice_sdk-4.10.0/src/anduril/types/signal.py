# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .emitter_notation import EmitterNotation
from .fixed import Fixed
from .frequency import Frequency
from .frequency_range import FrequencyRange
from .line_of_bearing import LineOfBearing
from .pulse_repetition_interval import PulseRepetitionInterval
from .scan_characteristics import ScanCharacteristics


class Signal(UniversalBaseModel):
    """
    A component that describes an entity's signal characteristics.
    """

    frequency_center: typing_extensions.Annotated[
        typing.Optional[Frequency], FieldMetadata(alias="frequencyCenter"), pydantic.Field(alias="frequencyCenter")
    ] = None
    frequency_range: typing_extensions.Annotated[
        typing.Optional[FrequencyRange], FieldMetadata(alias="frequencyRange"), pydantic.Field(alias="frequencyRange")
    ] = None
    bandwidth_hz: typing_extensions.Annotated[
        typing.Optional[float],
        FieldMetadata(alias="bandwidthHz"),
        pydantic.Field(alias="bandwidthHz", description="Indicates the bandwidth of a signal (Hz)."),
    ] = None
    signal_to_noise_ratio: typing_extensions.Annotated[
        typing.Optional[float],
        FieldMetadata(alias="signalToNoiseRatio"),
        pydantic.Field(alias="signalToNoiseRatio", description="Indicates the signal to noise (SNR) of this signal."),
    ] = None
    line_of_bearing: typing_extensions.Annotated[
        typing.Optional[LineOfBearing], FieldMetadata(alias="lineOfBearing"), pydantic.Field(alias="lineOfBearing")
    ] = None
    fixed: typing.Optional[Fixed] = None
    emitter_notations: typing_extensions.Annotated[
        typing.Optional[typing.List[EmitterNotation]],
        FieldMetadata(alias="emitterNotations"),
        pydantic.Field(alias="emitterNotations", description="Emitter notations associated with this entity."),
    ] = None
    pulse_width_s: typing_extensions.Annotated[
        typing.Optional[float],
        FieldMetadata(alias="pulseWidthS"),
        pydantic.Field(alias="pulseWidthS", description="length in time of a single pulse"),
    ] = None
    pulse_repetition_interval: typing_extensions.Annotated[
        typing.Optional[PulseRepetitionInterval],
        FieldMetadata(alias="pulseRepetitionInterval"),
        pydantic.Field(alias="pulseRepetitionInterval", description="length in time between the start of two pulses"),
    ] = None
    scan_characteristics: typing_extensions.Annotated[
        typing.Optional[ScanCharacteristics],
        FieldMetadata(alias="scanCharacteristics"),
        pydantic.Field(alias="scanCharacteristics", description="describes how a signal is observing the environment"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
