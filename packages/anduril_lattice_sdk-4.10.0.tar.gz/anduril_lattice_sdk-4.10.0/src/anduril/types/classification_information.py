# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .classification_information_level import ClassificationInformationLevel


class ClassificationInformation(UniversalBaseModel):
    """
    Represents all of the necessary information required to generate a summarized
     classification marking.

     > example: A summarized classification marking of "TOPSECRET//NOFORN//FISA"
                would be defined as: { "level": 5, "caveats": [ "NOFORN, "FISA" ] }
    """

    level: typing.Optional[ClassificationInformationLevel] = pydantic.Field(default=None)
    """
    Classification level to be applied to the information in question.
    """

    caveats: typing.Optional[typing.List[str]] = pydantic.Field(default=None)
    """
    Caveats that may further restrict how the information can be disseminated.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
