# This file was auto-generated from our API Definition.

import typing

AlertLevel = typing.Union[
    typing.Literal["ALERT_LEVEL_INVALID", "ALERT_LEVEL_ADVISORY", "ALERT_LEVEL_CAUTION", "ALERT_LEVEL_WARNING"],
    typing.Any,
]
