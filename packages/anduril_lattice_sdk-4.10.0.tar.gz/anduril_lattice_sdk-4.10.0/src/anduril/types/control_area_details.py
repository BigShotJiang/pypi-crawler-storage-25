# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .control_area_details_type import ControlAreaDetailsType


class ControlAreaDetails(UniversalBaseModel):
    """
    Determines the type of control area being represented by the geo-entity,
     in which an asset can, or cannot, operate.
    """

    type: typing.Optional[ControlAreaDetailsType] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
