# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .scan_characteristics_scan_type import ScanCharacteristicsScanType


class ScanCharacteristics(UniversalBaseModel):
    """
    A component that describes the scanning characteristics of a signal
    """

    scan_type: typing_extensions.Annotated[
        typing.Optional[ScanCharacteristicsScanType], FieldMetadata(alias="scanType"), pydantic.Field(alias="scanType")
    ] = None
    scan_period_s: typing_extensions.Annotated[
        typing.Optional[float], FieldMetadata(alias="scanPeriodS"), pydantic.Field(alias="scanPeriodS")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
