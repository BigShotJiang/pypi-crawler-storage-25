# This file was auto-generated from our API Definition.

import typing

CorrelationMetadataType = typing.Union[
    typing.Literal["CORRELATION_TYPE_INVALID", "CORRELATION_TYPE_MANUAL", "CORRELATION_TYPE_AUTOMATED"], typing.Any
]
