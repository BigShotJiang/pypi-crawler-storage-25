# This file was auto-generated from our API Definition.

from __future__ import annotations

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .aliases import Aliases
from .classification import Classification
from .correlation import Correlation
from .dimensions import Dimensions
from .geo_details import GeoDetails
from .geo_shape import GeoShape
from .group_details import GroupDetails
from .health import Health
from .indicators import Indicators
from .location import Location
from .location_uncertainty import LocationUncertainty
from .media import Media
from .mil_view import MilView
from .ontology import Ontology
from .orbit import Orbit
from .payloads import Payloads
from .power_state import PowerState
from .provenance import Provenance
from .relationships import Relationships
from .route_details import RouteDetails
from .schedules import Schedules
from .sensors import Sensors
from .signal import Signal
from .status import Status
from .supplies import Supplies
from .symbology import Symbology
from .target_priority import TargetPriority
from .task_catalog import TaskCatalog
from .tracked import Tracked
from .transponder_codes import TransponderCodes
from .visual_details import VisualDetails


class Entity(UniversalBaseModel):
    """
    The entity object represents a single known object within the Lattice operational environment. It contains
     all data associated with the entity, such as its name, ID, and other relevant components.
    """

    entity_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="entityId"),
        pydantic.Field(
            alias="entityId",
            description="A Globally Unique Identifier (GUID) for your entity. This is a required\n field.",
        ),
    ] = None
    description: typing.Optional[str] = pydantic.Field(default=None)
    """
    A human-readable entity description that's helpful for debugging purposes and human
     traceability. If this field is empty, the Entity Manager API generates one for you.
    """

    is_live: typing_extensions.Annotated[
        typing.Optional[bool],
        FieldMetadata(alias="isLive"),
        pydantic.Field(
            alias="isLive",
            description="Indicates the entity is active and should have a lifecycle state of CREATE or UPDATE.\n Set this field to true when publishing an entity.",
        ),
    ] = None
    created_time: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="createdTime"),
        pydantic.Field(
            alias="createdTime",
            description="The time when the entity was first known to the entity producer. If this field is empty, the Entity Manager API uses the\n current timestamp of when the entity is first received.\n For example, when a drone is first powered on, it might report its startup time as the created time.\n The timestamp doesn't change for the lifetime of an entity.",
        ),
    ] = None
    expiry_time: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="expiryTime"),
        pydantic.Field(
            alias="expiryTime",
            description="Future time that expires an entity and updates the is_live flag.\n For entities that are constantly updating, the expiry time also updates.\n In some cases, this may differ from is_live.\n Example: Entities with tasks exported to an external system must remain\n active even after they expire.\n This field is required when publishing a prepopulated entity.\n The expiry time must be in the future, but less than 30 days from the current time.",
        ),
    ] = None
    no_expiry: typing_extensions.Annotated[
        typing.Optional[bool],
        FieldMetadata(alias="noExpiry"),
        pydantic.Field(
            alias="noExpiry",
            description="Use noExpiry only when the entity contains information that should be available to other\n tasks or integrations beyond its immediate operational context. For example, use noExpiry\n for long-living geographical entities that maintain persistent relevance across multiple\n operations or tasks.",
        ),
    ] = None
    status: typing.Optional[Status] = pydantic.Field(default=None)
    """
    Human-readable descriptions of what the entity is currently doing.
    """

    location: typing.Optional[Location] = pydantic.Field(default=None)
    """
    Geospatial data related to the entity, including its position, kinematics, and orientation.
    """

    location_uncertainty: typing_extensions.Annotated[
        typing.Optional[LocationUncertainty],
        FieldMetadata(alias="locationUncertainty"),
        pydantic.Field(
            alias="locationUncertainty", description="Indicates uncertainty of the entity's position and kinematics."
        ),
    ] = None
    geo_shape: typing_extensions.Annotated[
        typing.Optional[GeoShape],
        FieldMetadata(alias="geoShape"),
        pydantic.Field(
            alias="geoShape",
            description="Geospatial representation of the entity, including entities that cover an area rather than a fixed point.",
        ),
    ] = None
    geo_details: typing_extensions.Annotated[
        typing.Optional[GeoDetails],
        FieldMetadata(alias="geoDetails"),
        pydantic.Field(
            alias="geoDetails",
            description="Additional details on what the geospatial area or point represents, along with visual display details.",
        ),
    ] = None
    aliases: typing.Optional[Aliases] = pydantic.Field(default=None)
    """
    Entity name displayed in the Lattice UI side panel. Also includes identifiers that other systems can use to reference the same entity.
    """

    tracked: typing.Optional[Tracked] = pydantic.Field(default=None)
    """
    If this entity is tracked by another entity, this component contains data related to how it's being tracked.
    """

    correlation: typing.Optional[Correlation] = pydantic.Field(default=None)
    """
    If this entity has been correlated or decorrelated to another one, this component contains information on the correlation or decorrelation.
    """

    mil_view: typing_extensions.Annotated[
        typing.Optional[MilView],
        FieldMetadata(alias="milView"),
        pydantic.Field(alias="milView", description="View of the entity."),
    ] = None
    ontology: typing.Optional[Ontology] = pydantic.Field(default=None)
    """
    Ontology defines an entity's categorization in Lattice, and improves data retrieval and integration. Builds a standardized representation of the entity.
    """

    sensors: typing.Optional[Sensors] = pydantic.Field(default=None)
    """
    Details an entity's available sensors.
    """

    payloads: typing.Optional[Payloads] = pydantic.Field(default=None)
    """
    Details an entity's available payloads.
    """

    power_state: typing_extensions.Annotated[
        typing.Optional[PowerState],
        FieldMetadata(alias="powerState"),
        pydantic.Field(alias="powerState", description="Details the entity's power source."),
    ] = None
    provenance: typing.Optional[Provenance] = pydantic.Field(default=None)
    """
    The primary data source provenance for this entity.
    """

    overrides: typing.Optional["Overrides"] = pydantic.Field(default=None)
    """
    Provenance of override data.
    """

    indicators: typing.Optional[Indicators] = pydantic.Field(default=None)
    """
    Describes an entity's specific characteristics and the operations that can be performed on the entity.
     For example, "simulated" informs the operator that the entity is from a simulation, and "deletable"
     informs the operator (and system) that the delete operation is valid against the entity.
    """

    target_priority: typing_extensions.Annotated[
        typing.Optional[TargetPriority],
        FieldMetadata(alias="targetPriority"),
        pydantic.Field(
            alias="targetPriority",
            description="The prioritization associated with an entity, such as if it's a threat or a high-value target.",
        ),
    ] = None
    signal: typing.Optional[Signal] = pydantic.Field(default=None)
    """
    Describes an entity's signal characteristics, primarily used when an entity is a signal of interest.
    """

    transponder_codes: typing_extensions.Annotated[
        typing.Optional[TransponderCodes],
        FieldMetadata(alias="transponderCodes"),
        pydantic.Field(
            alias="transponderCodes",
            description="A message describing any transponder codes associated with Mode 1, 2, 3, 4, 5, S, C interrogations. These are related to ADS-B modes.",
        ),
    ] = None
    data_classification: typing_extensions.Annotated[
        typing.Optional[Classification],
        FieldMetadata(alias="dataClassification"),
        pydantic.Field(
            alias="dataClassification",
            description="Describes an entity's security classification levels at an overall classification level and on a per\n field level.",
        ),
    ] = None
    task_catalog: typing_extensions.Annotated[
        typing.Optional[TaskCatalog],
        FieldMetadata(alias="taskCatalog"),
        pydantic.Field(alias="taskCatalog", description="A catalog of tasks that can be performed by an entity."),
    ] = None
    media: typing.Optional[Media] = pydantic.Field(default=None)
    """
    Media associated with an entity, such as videos, images, or thumbnails.
    """

    relationships: typing.Optional[Relationships] = pydantic.Field(default=None)
    """
    The relationships between this entity and other entities in the common operational picture (COP).
    """

    visual_details: typing_extensions.Annotated[
        typing.Optional[VisualDetails],
        FieldMetadata(alias="visualDetails"),
        pydantic.Field(
            alias="visualDetails", description="Visual details associated with the display of an entity in the client."
        ),
    ] = None
    dimensions: typing.Optional[Dimensions] = pydantic.Field(default=None)
    """
    Physical dimensions of the entity.
    """

    route_details: typing_extensions.Annotated[
        typing.Optional[RouteDetails],
        FieldMetadata(alias="routeDetails"),
        pydantic.Field(alias="routeDetails", description="Additional information about an entity's route."),
    ] = None
    schedules: typing.Optional[Schedules] = pydantic.Field(default=None)
    """
    Schedules associated with this entity.
    """

    health: typing.Optional[Health] = pydantic.Field(default=None)
    """
    Health metrics or connection status reported by the entity.
    """

    group_details: typing_extensions.Annotated[
        typing.Optional[GroupDetails],
        FieldMetadata(alias="groupDetails"),
        pydantic.Field(alias="groupDetails", description="Details for the group associated with this entity."),
    ] = None
    supplies: typing.Optional[Supplies] = pydantic.Field(default=None)
    """
    Contains relevant supply information for the entity, such as fuel.
    """

    orbit: typing.Optional[Orbit] = pydantic.Field(default=None)
    """
    Orbit information for space objects.
    """

    symbology: typing.Optional[Symbology] = pydantic.Field(default=None)
    """
    Symbology/iconography for the entity respecting an existing standard.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


from .override import Override  # noqa: E402, I001
from .overrides import Overrides  # noqa: E402, I001

update_forward_refs(Entity, Override=Override, Overrides=Overrides)
