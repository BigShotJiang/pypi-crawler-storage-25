# This file was auto-generated from our API Definition.

import typing

MilViewEnvironment = typing.Union[
    typing.Literal[
        "ENVIRONMENT_UNKNOWN",
        "ENVIRONMENT_AIR",
        "ENVIRONMENT_SURFACE",
        "ENVIRONMENT_SUB_SURFACE",
        "ENVIRONMENT_LAND",
        "ENVIRONMENT_SPACE",
    ],
    typing.Any,
]
