# This file was auto-generated from our API Definition.

import typing

OntologyTemplate = typing.Union[
    typing.Literal[
        "TEMPLATE_INVALID",
        "TEMPLATE_TRACK",
        "TEMPLATE_SENSOR_POINT_OF_INTEREST",
        "TEMPLATE_ASSET",
        "TEMPLATE_GEO",
        "TEMPLATE_SIGNAL_OF_INTEREST",
    ],
    typing.Any,
]
