# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .ontology_template import OntologyTemplate


class Ontology(UniversalBaseModel):
    """
    Ontology of the entity.
    """

    platform_type: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="platformType"),
        pydantic.Field(
            alias="platformType",
            description="A string that describes the entity's high-level type with natural language.",
        ),
    ] = None
    specific_type: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="specificType"),
        pydantic.Field(alias="specificType", description="A string that describes the entity's exact model or type."),
    ] = None
    template: typing.Optional[OntologyTemplate] = pydantic.Field(default=None)
    """
    The template used when creating this entity. Specifies minimum required components.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
