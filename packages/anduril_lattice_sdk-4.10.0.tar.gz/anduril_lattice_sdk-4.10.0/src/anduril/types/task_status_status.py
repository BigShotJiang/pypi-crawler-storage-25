# This file was auto-generated from our API Definition.

import typing

TaskStatusStatus = typing.Union[
    typing.Literal[
        "STATUS_INVALID",
        "STATUS_CREATED",
        "STATUS_SCHEDULED_IN_MANAGER",
        "STATUS_SENT",
        "STATUS_MACHINE_RECEIPT",
        "STATUS_ACK",
        "STATUS_WILCO",
        "STATUS_EXECUTING",
        "STATUS_WAITING_FOR_UPDATE",
        "STATUS_DONE_OK",
        "STATUS_DONE_NOT_OK",
        "STATUS_REPLACED",
        "STATUS_CANCEL_REQUESTED",
        "STATUS_COMPLETE_REQUESTED",
        "STATUS_VERSION_REJECTED",
    ],
    typing.Any,
]
