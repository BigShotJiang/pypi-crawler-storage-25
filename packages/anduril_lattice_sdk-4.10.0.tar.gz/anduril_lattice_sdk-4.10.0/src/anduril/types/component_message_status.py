# This file was auto-generated from our API Definition.

import typing

ComponentMessageStatus = typing.Union[
    typing.Literal[
        "HEALTH_STATUS_INVALID",
        "HEALTH_STATUS_HEALTHY",
        "HEALTH_STATUS_WARN",
        "HEALTH_STATUS_FAIL",
        "HEALTH_STATUS_OFFLINE",
        "HEALTH_STATUS_NOT_READY",
    ],
    typing.Any,
]
