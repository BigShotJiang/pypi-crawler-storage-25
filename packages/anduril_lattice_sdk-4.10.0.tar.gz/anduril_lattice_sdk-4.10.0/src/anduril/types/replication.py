# This file was auto-generated from our API Definition.

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class Replication(UniversalBaseModel):
    """
    Any metadata associated with the replication of a task.
    """

    stale_time: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="staleTime"),
        pydantic.Field(alias="staleTime", description="The time by which this task should be assumed to be stale."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
