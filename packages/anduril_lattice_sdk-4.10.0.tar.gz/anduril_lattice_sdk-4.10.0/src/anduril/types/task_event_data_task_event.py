# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .task import Task
from .task_event_data_task_event_event_type import TaskEventDataTaskEventEventType


class TaskEventDataTaskEvent(UniversalBaseModel):
    """
    The task event that occurred.
    """

    event_type: typing_extensions.Annotated[
        typing.Optional[TaskEventDataTaskEventEventType],
        FieldMetadata(alias="eventType"),
        pydantic.Field(alias="eventType", description="The type of event that occurred for this task."),
    ] = None
    task: typing.Optional[Task] = pydantic.Field(default=None)
    """
    The task associated with this event.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(TaskEventDataTaskEvent)
