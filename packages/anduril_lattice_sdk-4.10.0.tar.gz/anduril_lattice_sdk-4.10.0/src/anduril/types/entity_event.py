# This file was auto-generated from our API Definition.

from __future__ import annotations

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata
from .entity_event_event_type import EntityEventEventType


class EntityEvent(UniversalBaseModel):
    """
    Event representing some type of entity change.
    """

    event_type: typing_extensions.Annotated[
        typing.Optional[EntityEventEventType], FieldMetadata(alias="eventType"), pydantic.Field(alias="eventType")
    ] = None
    time: typing.Optional[dt.datetime] = None
    entity: typing.Optional["Entity"] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


from .entity import Entity  # noqa: E402, I001
from .override import Override  # noqa: E402, I001
from .overrides import Overrides  # noqa: E402, I001

update_forward_refs(EntityEvent, Entity=Entity, Override=Override, Overrides=Overrides)
