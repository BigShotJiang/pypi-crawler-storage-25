# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class Bandwidth(UniversalBaseModel):
    """
    Describes the bandwidth of a signal
    """

    bandwidth_hz: typing_extensions.Annotated[
        typing.Optional[float], FieldMetadata(alias="bandwidthHz"), pydantic.Field(alias="bandwidthHz")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
