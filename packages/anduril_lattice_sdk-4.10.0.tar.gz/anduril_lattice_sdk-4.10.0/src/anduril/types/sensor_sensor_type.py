# This file was auto-generated from our API Definition.

import typing

SensorSensorType = typing.Union[
    typing.Literal[
        "SENSOR_TYPE_INVALID",
        "SENSOR_TYPE_RADAR",
        "SENSOR_TYPE_CAMERA",
        "SENSOR_TYPE_TRANSPONDER",
        "SENSOR_TYPE_RF",
        "SENSOR_TYPE_GPS",
        "SENSOR_TYPE_PTU_POS",
        "SENSOR_TYPE_PERIMETER",
        "SENSOR_TYPE_SONAR",
    ],
    typing.Any,
]
