# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .bandwidth_range import BandwidthRange
from .frequency_range import FrequencyRange


class RfConfiguration(UniversalBaseModel):
    """
    Represents RF configurations supported on this sensor.
    """

    frequency_range_hz: typing_extensions.Annotated[
        typing.Optional[typing.List[FrequencyRange]],
        FieldMetadata(alias="frequencyRangeHz"),
        pydantic.Field(alias="frequencyRangeHz", description="Frequency ranges that are available for this sensor."),
    ] = None
    bandwidth_range_hz: typing_extensions.Annotated[
        typing.Optional[typing.List[BandwidthRange]],
        FieldMetadata(alias="bandwidthRangeHz"),
        pydantic.Field(alias="bandwidthRangeHz", description="Bandwidth ranges that are available for this sensor."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
