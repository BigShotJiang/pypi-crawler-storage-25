# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel


class Measurement(UniversalBaseModel):
    """
    A component that describes some measured value with error.
    """

    value: typing.Optional[float] = pydantic.Field(default=None)
    """
    The value of the measurement.
    """

    sigma: typing.Optional[float] = pydantic.Field(default=None)
    """
    Estimated one standard deviation in same unit as the value.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
