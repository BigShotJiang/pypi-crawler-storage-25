# This file was auto-generated from our API Definition.

import typing

DeliveryStateStatus = typing.Union[
    typing.Literal[
        "DELIVERY_STATUS_INVALID",
        "DELIVERY_STATUS_DELIVERED",
        "DELIVERY_STATUS_PENDING_EXECUTE",
        "DELIVERY_STATUS_PENDING_CANCEL",
        "DELIVERY_STATUS_PENDING_COMPLETE",
    ],
    typing.Any,
]
