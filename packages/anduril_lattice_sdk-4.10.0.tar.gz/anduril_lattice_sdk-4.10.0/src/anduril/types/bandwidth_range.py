# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .bandwidth import Bandwidth


class BandwidthRange(UniversalBaseModel):
    """
    A component that describes the min and max bandwidths of a sensor
    """

    minimum_bandwidth: typing_extensions.Annotated[
        typing.Optional[Bandwidth], FieldMetadata(alias="minimumBandwidth"), pydantic.Field(alias="minimumBandwidth")
    ] = None
    maximum_bandwidth: typing_extensions.Annotated[
        typing.Optional[Bandwidth], FieldMetadata(alias="maximumBandwidth"), pydantic.Field(alias="maximumBandwidth")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
