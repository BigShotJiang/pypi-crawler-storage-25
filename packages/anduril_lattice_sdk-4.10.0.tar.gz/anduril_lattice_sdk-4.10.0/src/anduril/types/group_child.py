# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel


class GroupChild(UniversalBaseModel):
    """
    A GroupChild relationship is a uni-directional relationship indicating that (1) this entity
     represents an Entity Group and (2) the related entity is a child member of this group. The presence of this
     relationship alone determines that the type of group is an Entity Group.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
