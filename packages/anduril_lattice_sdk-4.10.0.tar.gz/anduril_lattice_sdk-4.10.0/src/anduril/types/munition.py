# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class Munition(UniversalBaseModel):
    """
    Munition describes an entity's munitions stores
    """

    munition_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="munitionId"),
        pydantic.Field(alias="munitionId", description="Unique munition identifier"),
    ] = None
    name: typing.Optional[str] = pydantic.Field(default=None)
    """
    Long form name of the munition
    """

    quantity_units: typing_extensions.Annotated[
        typing.Optional[int],
        FieldMetadata(alias="quantityUnits"),
        pydantic.Field(alias="quantityUnits", description="Number of units"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
