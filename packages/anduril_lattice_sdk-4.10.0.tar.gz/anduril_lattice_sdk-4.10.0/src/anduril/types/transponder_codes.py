# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .mode5 import Mode5
from .mode_s import ModeS
from .transponder_codes_mode4interrogation_response import TransponderCodesMode4InterrogationResponse


class TransponderCodes(UniversalBaseModel):
    """
    A message describing any transponder codes associated with Mode 1, 2, 3, 4, 5, S, C interrogations.
    """

    mode1: typing.Optional[int] = pydantic.Field(default=None)
    """
    The mode 1 code assigned to military assets.
    """

    mode2: typing.Optional[int] = pydantic.Field(default=None)
    """
    The Mode 2 code assigned to military assets.
    """

    mode3: typing.Optional[int] = pydantic.Field(default=None)
    """
    The Mode 3 code assigned by ATC to the asset.
    """

    mode4interrogation_response: typing_extensions.Annotated[
        typing.Optional[TransponderCodesMode4InterrogationResponse],
        FieldMetadata(alias="mode4InterrogationResponse"),
        pydantic.Field(
            alias="mode4InterrogationResponse",
            description="The validity of the response from the Mode 4 interrogation.",
        ),
    ] = None
    mode5: typing.Optional[Mode5] = pydantic.Field(default=None)
    """
    The Mode 5 transponder codes.
    """

    mode_s: typing_extensions.Annotated[
        typing.Optional[ModeS],
        FieldMetadata(alias="modeS"),
        pydantic.Field(alias="modeS", description="The Mode S transponder codes."),
    ] = None
    mode_c_altitude_ft: typing_extensions.Annotated[
        typing.Optional[int],
        FieldMetadata(alias="modeCAltitudeFt"),
        pydantic.Field(
            alias="modeCAltitudeFt",
            description="The Mode C altitude reported by the transponder in feet. Mode C provides pressure altitude in 100-foot increments up\n to 10,000 feet MSL. Valid altitudes include 0 ft (sea level). An unset field indicates no Mode C response was received.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
