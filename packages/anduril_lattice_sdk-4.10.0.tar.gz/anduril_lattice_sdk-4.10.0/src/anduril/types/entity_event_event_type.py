# This file was auto-generated from our API Definition.

import typing

EntityEventEventType = typing.Union[
    typing.Literal[
        "EVENT_TYPE_INVALID",
        "EVENT_TYPE_CREATED",
        "EVENT_TYPE_UPDATE",
        "EVENT_TYPE_DELETED",
        "EVENT_TYPE_PREEXISTING",
        "EVENT_TYPE_POST_EXPIRY_OVERRIDE",
    ],
    typing.Any,
]
