# This file was auto-generated from our API Definition.

import typing

PayloadConfigurationPayloadOperationalState = typing.Union[
    typing.Literal[
        "PAYLOAD_OPERATIONAL_STATE_INVALID",
        "PAYLOAD_OPERATIONAL_STATE_OFF",
        "PAYLOAD_OPERATIONAL_STATE_NON_OPERATIONAL",
        "PAYLOAD_OPERATIONAL_STATE_DEGRADED",
        "PAYLOAD_OPERATIONAL_STATE_OPERATIONAL",
        "PAYLOAD_OPERATIONAL_STATE_OUT_OF_SERVICE",
        "PAYLOAD_OPERATIONAL_STATE_UNKNOWN",
    ],
    typing.Any,
]
