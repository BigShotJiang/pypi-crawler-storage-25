# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .delivery_error_code import DeliveryErrorCode


class DeliveryError(UniversalBaseModel):
    """
    DeliveryError contains an error code and message associated with task delivery.
    """

    code: typing.Optional[DeliveryErrorCode] = pydantic.Field(default=None)
    """
    Error code for Delivery error.
    """

    message: typing.Optional[str] = pydantic.Field(default=None)
    """
    Descriptive human-readable string regarding this delivery error.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
