# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class CompleteRequest(UniversalBaseModel):
    """
    The request to complete a task.
     Contains the unique ID of the task to complete.
    """

    task_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="taskId"),
        pydantic.Field(alias="taskId", description="ID of the task to complete."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
