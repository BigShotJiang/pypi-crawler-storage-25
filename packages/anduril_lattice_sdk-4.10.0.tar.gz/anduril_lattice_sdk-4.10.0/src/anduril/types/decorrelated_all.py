# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .correlation_metadata import CorrelationMetadata


class DecorrelatedAll(UniversalBaseModel):
    metadata: typing.Optional[CorrelationMetadata] = pydantic.Field(default=None)
    """
    Metadata about the decorrelation.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
