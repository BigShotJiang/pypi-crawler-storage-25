# This file was auto-generated from our API Definition.

import typing

AcmDetailsAcmType = typing.Union[typing.Literal["ACM_DETAIL_TYPE_INVALID", "ACM_DETAIL_TYPE_LANDING_ZONE"], typing.Any]
