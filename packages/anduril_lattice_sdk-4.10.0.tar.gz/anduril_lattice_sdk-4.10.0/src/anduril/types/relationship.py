# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .relationship_type import RelationshipType


class Relationship(UniversalBaseModel):
    """
    The relationship component indicates a relationship to another entity.
    """

    related_entity_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="relatedEntityId"),
        pydantic.Field(alias="relatedEntityId", description="The entity ID to which this entity is related."),
    ] = None
    relationship_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="relationshipId"),
        pydantic.Field(
            alias="relationshipId",
            description="A unique identifier for this relationship. Allows removing or updating relationships.",
        ),
    ] = None
    relationship_type: typing_extensions.Annotated[
        typing.Optional[RelationshipType],
        FieldMetadata(alias="relationshipType"),
        pydantic.Field(alias="relationshipType", description="The relationship type"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
