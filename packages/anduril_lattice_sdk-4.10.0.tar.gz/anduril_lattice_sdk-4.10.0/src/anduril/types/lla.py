# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .lla_altitude_reference import LlaAltitudeReference


class Lla(UniversalBaseModel):
    lon: typing.Optional[float] = None
    lat: typing.Optional[float] = None
    alt: typing.Optional[float] = None
    is2d: typing.Optional[bool] = None
    altitude_reference: typing_extensions.Annotated[
        typing.Optional[LlaAltitudeReference],
        FieldMetadata(alias="altitudeReference"),
        pydantic.Field(
            alias="altitudeReference",
            description="Meaning of alt.\n altitude in meters above either WGS84 or EGM96, use altitude_reference to\n determine what zero means.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
