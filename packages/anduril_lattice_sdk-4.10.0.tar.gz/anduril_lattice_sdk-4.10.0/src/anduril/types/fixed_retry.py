# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class FixedRetry(UniversalBaseModel):
    """
    Defaults to an interval of 5 seconds. If the DeliverBefore field in the task's DeliveryConstraints isn't populated, Lattice does not retry delivery and instead logs a warning.
    """

    retry_interval: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="retryInterval"),
        pydantic.Field(
            alias="retryInterval",
            description="Specifies the interval between retries. A default interval of 5 seconds is used if this field is not set.",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
