# This file was auto-generated from our API Definition.

import typing

SensorOperationalState = typing.Union[
    typing.Literal[
        "OPERATIONAL_STATE_INVALID",
        "OPERATIONAL_STATE_OFF",
        "OPERATIONAL_STATE_NON_OPERATIONAL",
        "OPERATIONAL_STATE_DEGRADED",
        "OPERATIONAL_STATE_OPERATIONAL",
        "OPERATIONAL_STATE_DENIED",
    ],
    typing.Any,
]
