# This file was auto-generated from our API Definition.

import typing

ControlAreaDetailsType = typing.Union[
    typing.Literal[
        "CONTROL_AREA_TYPE_INVALID",
        "CONTROL_AREA_TYPE_KEEP_IN_ZONE",
        "CONTROL_AREA_TYPE_KEEP_OUT_ZONE",
        "CONTROL_AREA_TYPE_DITCH_ZONE",
        "CONTROL_AREA_TYPE_LOITER_ZONE",
    ],
    typing.Any,
]
