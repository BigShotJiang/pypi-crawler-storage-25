# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .mode5mode5interrogation_response import Mode5Mode5InterrogationResponse


class Mode5(UniversalBaseModel):
    """
    Describes the Mode 5 transponder interrogation status and codes.
    """

    mode5interrogation_response: typing_extensions.Annotated[
        typing.Optional[Mode5Mode5InterrogationResponse],
        FieldMetadata(alias="mode5InterrogationResponse"),
        pydantic.Field(
            alias="mode5InterrogationResponse",
            description="The validity of the response from the Mode 5 interrogation.",
        ),
    ] = None
    mode5: typing.Optional[int] = pydantic.Field(default=None)
    """
    The Mode 5 code assigned to military assets.
    """

    mode5platform_id: typing_extensions.Annotated[
        typing.Optional[int],
        FieldMetadata(alias="mode5PlatformId"),
        pydantic.Field(alias="mode5PlatformId", description="The Mode 5 platform identification code."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
