# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .power_level import PowerLevel
from .power_source_power_status import PowerSourcePowerStatus
from .power_source_power_type import PowerSourcePowerType


class PowerSource(UniversalBaseModel):
    """
    Represents the state of a single power source that is connected to this entity.
    """

    power_status: typing_extensions.Annotated[
        typing.Optional[PowerSourcePowerStatus],
        FieldMetadata(alias="powerStatus"),
        pydantic.Field(alias="powerStatus", description="Status of the power source."),
    ] = None
    power_type: typing_extensions.Annotated[
        typing.Optional[PowerSourcePowerType],
        FieldMetadata(alias="powerType"),
        pydantic.Field(alias="powerType", description="Used to determine the type of power source."),
    ] = None
    power_level: typing_extensions.Annotated[
        typing.Optional[PowerLevel],
        FieldMetadata(alias="powerLevel"),
        pydantic.Field(
            alias="powerLevel",
            description="Power level of the system. If absent, the power level is assumed to be unknown.",
        ),
    ] = None
    messages: typing.Optional[typing.List[str]] = pydantic.Field(default=None)
    """
    Set of human-readable messages with status of the power system. Typically this would be used in an error state
     to provide additional error information. This can also be used for informational messages.
    """

    offloadable: typing.Optional[bool] = pydantic.Field(default=None)
    """
    Whether the power source is offloadable. If the value is missing (as opposed to false) then the entity does not
     report whether the power source is offloadable.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
