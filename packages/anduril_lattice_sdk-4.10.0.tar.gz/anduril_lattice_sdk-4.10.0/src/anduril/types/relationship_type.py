# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .active_target import ActiveTarget
from .group_child import GroupChild
from .group_parent import GroupParent
from .merged_from import MergedFrom
from .tracked_by import TrackedBy


class RelationshipType(UniversalBaseModel):
    """
    Determines the type of relationship between this entity and another.
    """

    tracked_by: typing_extensions.Annotated[
        typing.Optional[TrackedBy], FieldMetadata(alias="trackedBy"), pydantic.Field(alias="trackedBy")
    ] = None
    group_child: typing_extensions.Annotated[
        typing.Optional[GroupChild], FieldMetadata(alias="groupChild"), pydantic.Field(alias="groupChild")
    ] = None
    group_parent: typing_extensions.Annotated[
        typing.Optional[GroupParent], FieldMetadata(alias="groupParent"), pydantic.Field(alias="groupParent")
    ] = None
    merged_from: typing_extensions.Annotated[
        typing.Optional[MergedFrom], FieldMetadata(alias="mergedFrom"), pydantic.Field(alias="mergedFrom")
    ] = None
    active_target: typing_extensions.Annotated[
        typing.Optional[ActiveTarget], FieldMetadata(alias="activeTarget"), pydantic.Field(alias="activeTarget")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
