# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .payload import Payload


class Payloads(UniversalBaseModel):
    """
    List of payloads available for an entity.
    """

    payload_configurations: typing_extensions.Annotated[
        typing.Optional[typing.List[Payload]],
        FieldMetadata(alias="payloadConfigurations"),
        pydantic.Field(alias="payloadConfigurations"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
