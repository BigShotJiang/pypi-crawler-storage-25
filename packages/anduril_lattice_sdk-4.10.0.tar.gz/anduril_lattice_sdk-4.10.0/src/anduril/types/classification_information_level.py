# This file was auto-generated from our API Definition.

import typing

ClassificationInformationLevel = typing.Union[
    typing.Literal[
        "CLASSIFICATION_LEVELS_INVALID",
        "CLASSIFICATION_LEVELS_UNCLASSIFIED",
        "CLASSIFICATION_LEVELS_CONTROLLED_UNCLASSIFIED",
        "CLASSIFICATION_LEVELS_CONFIDENTIAL",
        "CLASSIFICATION_LEVELS_SECRET",
        "CLASSIFICATION_LEVELS_TOP_SECRET",
    ],
    typing.Any,
]
