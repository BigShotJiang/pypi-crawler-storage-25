# This file was auto-generated from our API Definition.

import typing

FieldOfViewMode = typing.Union[
    typing.Literal[
        "SENSOR_MODE_INVALID",
        "SENSOR_MODE_SEARCH",
        "SENSOR_MODE_TRACK",
        "SENSOR_MODE_WEAPON_SUPPORT",
        "SENSOR_MODE_AUTO",
        "SENSOR_MODE_MUTE",
    ],
    typing.Any,
]
