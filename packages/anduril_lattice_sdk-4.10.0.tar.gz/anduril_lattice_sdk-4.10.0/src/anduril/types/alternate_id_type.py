# This file was auto-generated from our API Definition.

import typing

AlternateIdType = typing.Union[
    typing.Literal[
        "ALT_ID_TYPE_INVALID",
        "ALT_ID_TYPE_TRACK_ID_2",
        "ALT_ID_TYPE_TRACK_ID_1",
        "ALT_ID_TYPE_SPI_ID",
        "ALT_ID_TYPE_NITF_FILE_TITLE",
        "ALT_ID_TYPE_TRACK_REPO_ALERT_ID",
        "ALT_ID_TYPE_ASSET_ID",
        "ALT_ID_TYPE_LINK16_TRACK_NUMBER",
        "ALT_ID_TYPE_LINK16_JU",
        "ALT_ID_TYPE_NCCT_MESSAGE_ID",
        "ALT_ID_TYPE_CALLSIGN",
        "ALT_ID_TYPE_MMSI_ID",
        "ALT_ID_TYPE_VMF_URN",
        "ALT_ID_TYPE_IMO_ID",
        "ALT_ID_TYPE_VMF_TARGET_NUMBER",
        "ALT_ID_TYPE_SERIAL_NUMBER",
        "ALT_ID_TYPE_REGISTRATION_ID",
        "ALT_ID_TYPE_IBS_GID",
        "ALT_ID_TYPE_DODAAC",
        "ALT_ID_TYPE_UIC",
        "ALT_ID_TYPE_NORAD_CAT_ID",
        "ALT_ID_TYPE_UNOOSA_NAME",
        "ALT_ID_TYPE_UNOOSA_ID",
    ],
    typing.Any,
]
