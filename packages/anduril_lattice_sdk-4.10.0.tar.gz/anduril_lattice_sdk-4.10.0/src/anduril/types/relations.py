# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ..core.serialization import FieldMetadata


class Relations(UniversalBaseModel):
    """
    Describes the relationships associated with this task: the system assigned to
     execute the task, and the parent task, if one exists.
    """

    assignee: typing.Optional["Principal"] = pydantic.Field(default=None)
    """
    The system, user, or team assigned to the task.
    """

    parent_task_id: typing_extensions.Annotated[
        typing.Optional[str],
        FieldMetadata(alias="parentTaskId"),
        pydantic.Field(alias="parentTaskId", description="Identifies the parent task if the task is a sub-task."),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


from .principal import Principal  # noqa: E402, I001

update_forward_refs(Relations, Principal=Principal)
