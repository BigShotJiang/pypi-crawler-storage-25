# This file was auto-generated from our API Definition.

import typing

MilViewDisposition = typing.Union[
    typing.Literal[
        "DISPOSITION_UNKNOWN",
        "DISPOSITION_FRIENDLY",
        "DISPOSITION_HOSTILE",
        "DISPOSITION_SUSPICIOUS",
        "DISPOSITION_ASSUMED_FRIENDLY",
        "DISPOSITION_NEUTRAL",
        "DISPOSITION_PENDING",
    ],
    typing.Any,
]
