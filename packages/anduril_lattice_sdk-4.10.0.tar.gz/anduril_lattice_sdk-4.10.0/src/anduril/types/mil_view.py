# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .mil_view_disposition import MilViewDisposition
from .mil_view_environment import MilViewEnvironment
from .mil_view_nationality import MilViewNationality


class MilView(UniversalBaseModel):
    """
    Provides the disposition, environment, and nationality of an Entity.
    """

    disposition: typing.Optional[MilViewDisposition] = None
    environment: typing.Optional[MilViewEnvironment] = None
    nationality: typing.Optional[MilViewNationality] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
