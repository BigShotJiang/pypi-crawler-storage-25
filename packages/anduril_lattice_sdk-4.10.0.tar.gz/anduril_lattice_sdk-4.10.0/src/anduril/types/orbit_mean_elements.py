# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .mean_keplerian_elements import MeanKeplerianElements
from .orbit_mean_elements_metadata import OrbitMeanElementsMetadata
from .tle_parameters import TleParameters


class OrbitMeanElements(UniversalBaseModel):
    """
    Orbit Mean Elements data, analogous to the Orbit Mean Elements Message in CCSDS 502.0-B-3
    """

    metadata: typing.Optional[OrbitMeanElementsMetadata] = None
    mean_keplerian_elements: typing_extensions.Annotated[
        typing.Optional[MeanKeplerianElements],
        FieldMetadata(alias="meanKeplerianElements"),
        pydantic.Field(alias="meanKeplerianElements"),
    ] = None
    tle_parameters: typing_extensions.Annotated[
        typing.Optional[TleParameters], FieldMetadata(alias="tleParameters"), pydantic.Field(alias="tleParameters")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
