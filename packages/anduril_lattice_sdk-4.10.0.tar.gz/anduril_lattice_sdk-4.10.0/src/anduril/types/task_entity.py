# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs


class TaskEntity(UniversalBaseModel):
    """
    An entity wrapper used in task definitions, with additional metadata.

     TaskEntity wraps an entity reference with additional contextual information for task execution.
     This structure allows entities to be passed to tasks with supplementary metadata that aids
     in proper task execution, while also serving as an extension point for future capabilities.
    """

    entity: typing.Optional["Entity"] = pydantic.Field(default=None)
    """
    The wrapped entity.
    """

    snapshot: typing.Optional[bool] = pydantic.Field(default=None)
    """
    Indicates that this entity was generated from a snapshot of a live entity.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


from .entity import Entity  # noqa: E402, I001
from .override import Override  # noqa: E402, I001
from .overrides import Overrides  # noqa: E402, I001

update_forward_refs(TaskEntity, Entity=Entity, Override=Override, Overrides=Overrides)
