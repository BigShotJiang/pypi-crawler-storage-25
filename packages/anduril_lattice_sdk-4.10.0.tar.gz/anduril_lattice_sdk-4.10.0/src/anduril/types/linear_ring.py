# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .geo_polygon_position import GeoPolygonPosition


class LinearRing(UniversalBaseModel):
    """
    A closed ring of points. The first and last point must be the same.
    """

    positions: typing.Optional[typing.List[GeoPolygonPosition]] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
