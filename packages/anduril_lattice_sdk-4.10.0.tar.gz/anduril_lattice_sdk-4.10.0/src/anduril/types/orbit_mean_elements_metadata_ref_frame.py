# This file was auto-generated from our API Definition.

import typing

OrbitMeanElementsMetadataRefFrame = typing.Union[
    typing.Literal["ECI_REFERENCE_FRAME_INVALID", "ECI_REFERENCE_FRAME_TEME"], typing.Any
]
