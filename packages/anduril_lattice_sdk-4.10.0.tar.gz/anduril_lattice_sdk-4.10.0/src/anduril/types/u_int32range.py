# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata


class UInt32Range(UniversalBaseModel):
    lower_bound: typing_extensions.Annotated[
        typing.Optional[int], FieldMetadata(alias="lowerBound"), pydantic.Field(alias="lowerBound")
    ] = None
    upper_bound: typing_extensions.Annotated[
        typing.Optional[int], FieldMetadata(alias="upperBound"), pydantic.Field(alias="upperBound")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
