# This file was auto-generated from our API Definition.

import typing

CorrelationMetadataReplicationMode = typing.Union[
    typing.Literal[
        "CORRELATION_REPLICATION_MODE_INVALID",
        "CORRELATION_REPLICATION_MODE_LOCAL",
        "CORRELATION_REPLICATION_MODE_GLOBAL",
    ],
    typing.Any,
]
