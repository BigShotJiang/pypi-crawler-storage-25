# This file was auto-generated from our API Definition.

import typing

TaskErrorCode = typing.Union[
    typing.Literal[
        "ERROR_CODE_INVALID", "ERROR_CODE_CANCELLED", "ERROR_CODE_REJECTED", "ERROR_CODE_TIMEOUT", "ERROR_CODE_FAILED"
    ],
    typing.Any,
]
