# This file was auto-generated from our API Definition.

import datetime as dt
import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .component_health_health import ComponentHealthHealth
from .component_message import ComponentMessage


class ComponentHealth(UniversalBaseModel):
    """
    Health of an individual component.
    """

    id: typing.Optional[str] = pydantic.Field(default=None)
    """
    Consistent internal ID for this component.
    """

    name: typing.Optional[str] = pydantic.Field(default=None)
    """
    Display name for this component.
    """

    health: typing.Optional[ComponentHealthHealth] = pydantic.Field(default=None)
    """
    Health for this component.
    """

    messages: typing.Optional[typing.List[ComponentMessage]] = pydantic.Field(default=None)
    """
    Human-readable describing the component state. These messages should be understandable by end users.
    """

    update_time: typing_extensions.Annotated[
        typing.Optional[dt.datetime],
        FieldMetadata(alias="updateTime"),
        pydantic.Field(
            alias="updateTime",
            description="The last update time for this specific component.\n If this timestamp is unset, the data is assumed to be most recent",
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
