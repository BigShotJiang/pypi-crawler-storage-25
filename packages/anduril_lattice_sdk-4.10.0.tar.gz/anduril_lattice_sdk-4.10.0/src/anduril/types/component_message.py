# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from .component_message_status import ComponentMessageStatus


class ComponentMessage(UniversalBaseModel):
    """
    A message describing the component's health status.
    """

    status: typing.Optional[ComponentMessageStatus] = pydantic.Field(default=None)
    """
    The status associated with this message.
    """

    message: typing.Optional[str] = pydantic.Field(default=None)
    """
    The human-readable content of the message.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
