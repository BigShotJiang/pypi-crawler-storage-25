# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .echelon_army_echelon import EchelonArmyEchelon


class Echelon(UniversalBaseModel):
    """
    Describes a Echelon group type.  Comprised of entities which are members of the
     same unit or echelon. Ex: A group of tanks within a armored company or that same company
     as a member of a battalion.
    """

    army_echelon: typing_extensions.Annotated[
        typing.Optional[EchelonArmyEchelon], FieldMetadata(alias="armyEchelon"), pydantic.Field(alias="armyEchelon")
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
