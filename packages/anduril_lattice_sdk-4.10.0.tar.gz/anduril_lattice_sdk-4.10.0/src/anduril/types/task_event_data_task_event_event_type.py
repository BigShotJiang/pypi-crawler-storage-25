# This file was auto-generated from our API Definition.

import typing

TaskEventDataTaskEventEventType = typing.Union[
    typing.Literal["EVENT_TYPE_INVALID", "EVENT_TYPE_CREATED", "EVENT_TYPE_UPDATE", "EVENT_TYPE_PREEXISTING"],
    typing.Any,
]
