# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from .task import Task


class ExecuteRequest(UniversalBaseModel):
    """
    The request to execute a task.
     Contains the unique ID of the task to execute.
    """

    task: typing.Optional[Task] = pydantic.Field(default=None)
    """
    The task to execute.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


update_forward_refs(ExecuteRequest)
