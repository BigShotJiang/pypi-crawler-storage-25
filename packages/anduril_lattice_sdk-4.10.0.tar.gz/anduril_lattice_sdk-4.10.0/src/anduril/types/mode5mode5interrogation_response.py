# This file was auto-generated from our API Definition.

import typing

Mode5Mode5InterrogationResponse = typing.Union[
    typing.Literal[
        "INTERROGATION_RESPONSE_INVALID",
        "INTERROGATION_RESPONSE_CORRECT",
        "INTERROGATION_RESPONSE_INCORRECT",
        "INTERROGATION_RESPONSE_NO_RESPONSE",
    ],
    typing.Any,
]
