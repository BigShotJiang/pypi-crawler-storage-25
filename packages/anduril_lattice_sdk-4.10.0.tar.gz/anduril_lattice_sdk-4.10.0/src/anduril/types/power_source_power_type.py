# This file was auto-generated from our API Definition.

import typing

PowerSourcePowerType = typing.Union[
    typing.Literal["POWER_TYPE_INVALID", "POWER_TYPE_UNKNOWN", "POWER_TYPE_GAS", "POWER_TYPE_BATTERY"], typing.Any
]
