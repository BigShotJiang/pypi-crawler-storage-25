# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .alternate_id import AlternateId


class Aliases(UniversalBaseModel):
    """
    Available for any Entities with alternate ids in other systems.
    """

    alternate_ids: typing_extensions.Annotated[
        typing.Optional[typing.List[AlternateId]],
        FieldMetadata(alias="alternateIds"),
        pydantic.Field(alias="alternateIds"),
    ] = None
    name: typing.Optional[str] = pydantic.Field(default=None)
    """
    The best available version of the entity's display name.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
