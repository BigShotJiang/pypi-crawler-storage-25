# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .high_value_target import HighValueTarget
from .threat import Threat


class TargetPriority(UniversalBaseModel):
    """
    The target prioritization associated with an entity.
    """

    high_value_target: typing_extensions.Annotated[
        typing.Optional[HighValueTarget],
        FieldMetadata(alias="highValueTarget"),
        pydantic.Field(
            alias="highValueTarget", description="Describes the target priority in relation to high value target lists."
        ),
    ] = None
    threat: typing.Optional[Threat] = pydantic.Field(default=None)
    """
    Describes whether the entity should be treated as a threat
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
