# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel


class Color(UniversalBaseModel):
    red: typing.Optional[float] = pydantic.Field(default=None)
    """
    The amount of red in the color as a value in the interval [0, 1].
    """

    green: typing.Optional[float] = pydantic.Field(default=None)
    """
    The amount of green in the color as a value in the interval [0, 1].
    """

    blue: typing.Optional[float] = pydantic.Field(default=None)
    """
    The amount of blue in the color as a value in the interval [0, 1].
    """

    alpha: typing.Optional[float] = pydantic.Field(default=None)
    """
    The fraction of this color that should be applied to the pixel. That is,
     the final pixel color is defined by the equation:
    
     `pixel color = alpha * (this color) + (1.0 - alpha) * (background color)`
    
     This means that a value of 1.0 corresponds to a solid color, whereas
     a value of 0.0 corresponds to a completely transparent color. This
     uses a wrapper message rather than a simple float scalar so that it is
     possible to distinguish between a default value and the value being unset.
     If omitted, this color object is rendered as a solid color
     (as if the alpha value had been explicitly given a value of 1.0).
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
