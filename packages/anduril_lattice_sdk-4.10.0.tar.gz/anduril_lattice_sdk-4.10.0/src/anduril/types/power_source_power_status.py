# This file was auto-generated from our API Definition.

import typing

PowerSourcePowerStatus = typing.Union[
    typing.Literal[
        "POWER_STATUS_INVALID",
        "POWER_STATUS_UNKNOWN",
        "POWER_STATUS_NOT_PRESENT",
        "POWER_STATUS_OPERATING",
        "POWER_STATUS_DISABLED",
        "POWER_STATUS_ERROR",
    ],
    typing.Any,
]
