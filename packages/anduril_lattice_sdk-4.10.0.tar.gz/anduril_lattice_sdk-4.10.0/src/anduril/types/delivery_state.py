# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .delivery_constraints import DeliveryConstraints
from .delivery_error import DeliveryError
from .delivery_state_status import DeliveryStateStatus


class DeliveryState(UniversalBaseModel):
    """
    Defines the current state of a task's delivery.
    """

    status: typing.Optional[DeliveryStateStatus] = pydantic.Field(default=None)
    """
    The current status of the delivery.
    """

    error: typing.Optional[DeliveryError] = pydantic.Field(default=None)
    """
    Errors associated with the delivery, if any.
    """

    delivery_constraints: typing_extensions.Annotated[
        typing.Optional[DeliveryConstraints],
        FieldMetadata(alias="deliveryConstraints"),
        pydantic.Field(
            alias="deliveryConstraints", description="Optional scheduling constraints for Lattice delivery of the task."
        ),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
