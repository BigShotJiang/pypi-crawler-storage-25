# This file was auto-generated from our API Definition.

import typing

import pydantic
import typing_extensions
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel
from ..core.serialization import FieldMetadata
from .task_definition import TaskDefinition


class TaskCatalog(UniversalBaseModel):
    """
    Catalog of supported tasks.
    """

    task_definitions: typing_extensions.Annotated[
        typing.Optional[typing.List[TaskDefinition]],
        FieldMetadata(alias="taskDefinitions"),
        pydantic.Field(alias="taskDefinitions"),
    ] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
