# This file was auto-generated from our API Definition.

import typing

import pydantic
from ..core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel


class GroupParent(UniversalBaseModel):
    """
    A GroupParent relationship is a uni-directional relationship indicating that this entity is a member of
     the Entity Group represented by the related entity. The presence of this relationship alone determines that
     the type of group that this entity is a member of is an Entity Group.
    """

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow
