# This file was auto-generated from our API Definition.

from __future__ import annotations

import datetime as dt
import typing

import pydantic
import typing_extensions
from ...core.pydantic_utilities import IS_PYDANTIC_V2, UniversalBaseModel, update_forward_refs
from ...core.serialization import FieldMetadata
from ...types.entity_event_event_type import EntityEventEventType


class StreamEntitiesResponse_Heartbeat(UniversalBaseModel):
    """
    The stream event response.
    """

    event: typing.Literal["heartbeat"] = "heartbeat"
    timestamp: typing.Optional[str] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


class StreamEntitiesResponse_Entity(UniversalBaseModel):
    """
    The stream event response.
    """

    event: typing.Literal["entity"] = "entity"
    event_type: typing_extensions.Annotated[
        typing.Optional[EntityEventEventType], FieldMetadata(alias="eventType"), pydantic.Field(alias="eventType")
    ] = None
    time: typing.Optional[dt.datetime] = None
    entity: typing.Optional["Entity"] = None

    if IS_PYDANTIC_V2:
        model_config: typing.ClassVar[pydantic.ConfigDict] = pydantic.ConfigDict(extra="allow", frozen=True)  # type: ignore # Pydantic v2
    else:

        class Config:
            frozen = True
            smart_union = True
            extra = pydantic.Extra.allow


StreamEntitiesResponse = typing_extensions.Annotated[
    typing.Union[StreamEntitiesResponse_Heartbeat, StreamEntitiesResponse_Entity], pydantic.Field(discriminator="event")
]
from ...types.entity import Entity  # noqa: E402, I001
from ...types.override import Override  # noqa: E402, I001
from ...types.overrides import Overrides  # noqa: E402, I001

update_forward_refs(StreamEntitiesResponse_Entity, Entity=Entity, Override=Override, Overrides=Overrides)
