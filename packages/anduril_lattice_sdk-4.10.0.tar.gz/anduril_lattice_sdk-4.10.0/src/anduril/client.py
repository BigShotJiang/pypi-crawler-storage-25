# This file was auto-generated from our API Definition.

from __future__ import annotations

import typing

import httpx
from .core.api_error import ApiError
from .core.client_wrapper import AsyncClientWrapper, SyncClientWrapper
from .core.logging import LogConfig, Logger
from .core.oauth_token_provider import AsyncOAuthTokenProvider, OAuthTokenProvider
from .environment import LatticeEnvironment

if typing.TYPE_CHECKING:
    from .entities.client import AsyncEntitiesClient, EntitiesClient
    from .oauth.client import AsyncOauthClient, OauthClient
    from .objects.client import AsyncObjectsClient, ObjectsClient
    from .tasks.client import AsyncTasksClient, TasksClient


class Lattice:
    """
    Use this class to access the different functions within the SDK. You can instantiate any number of clients with different configuration that will propagate to these functions.

    Parameters
    ----------

    base_url : typing.Optional[str]
        The base url to use for requests from the client.

    client_id : str
        The client identifier used for authentication.

    client_secret : str
        The client secret used for authentication.

    timeout : typing.Optional[float]
        The timeout to be used, in seconds, for requests. By default the timeout is 60 seconds, unless a custom httpx client is used, in which case this default is not enforced.

    max_retries : typing.Optional[int]
        The default maximum number of retries for failed requests. Defaults to 2. Per-request `max_retries` in `request_options` takes precedence over this value.

    follow_redirects : typing.Optional[bool]
        Whether the default httpx client follows redirects or not, this is irrelevant if a custom httpx client is passed in.

    httpx_client : typing.Optional[httpx.Client]
        The httpx client to use for making requests, a preconfigured client is used by default, however this is useful should you want to pass in any custom httpx configuration.

    # or ...

    base_url : typing.Optional[str]
        The base url to use for requests from the client.

    token : typing.Callable[[], str]
        Authenticate by providing a callable that returns a pre-generated bearer token. In this mode, OAuth client credentials are not required.

    timeout : typing.Optional[float]
        The timeout to be used, in seconds, for requests. By default the timeout is 60 seconds, unless a custom httpx client is used, in which case this default is not enforced.

    max_retries : typing.Optional[int]
        The default maximum number of retries for failed requests. Defaults to 2. Per-request `max_retries` in `request_options` takes precedence over this value.

    follow_redirects : typing.Optional[bool]
        Whether the default httpx client follows redirects or not, this is irrelevant if a custom httpx client is passed in.

    httpx_client : typing.Optional[httpx.Client]
        The httpx client to use for making requests, a preconfigured client is used by default, however this is useful should you want to pass in any custom httpx configuration.

    Examples
    --------
    from anduril import Lattice

    client = Lattice(
        client_id="YOUR_CLIENT_ID",
        client_secret="YOUR_CLIENT_SECRET",
    )

    # or ...

    from anduril import Lattice

    client = Lattice(
        base_url="https://yourhost.com/path/to/api",
        token="YOUR_BEARER_TOKEN",
    )
    """

    @typing.overload
    def __init__(
        self,
        *,
        base_url: typing.Optional[str] = None,
        environment: LatticeEnvironment = LatticeEnvironment.DEFAULT,
        server: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        timeout: typing.Optional[float] = None,
        max_retries: typing.Optional[int] = None,
        follow_redirects: typing.Optional[bool] = True,
        httpx_client: typing.Optional[httpx.Client] = None,
        logging: typing.Optional[typing.Union[LogConfig, Logger]] = None,
        client_id: str,
        client_secret: str,
    ): ...
    @typing.overload
    def __init__(
        self,
        *,
        base_url: typing.Optional[str] = None,
        environment: LatticeEnvironment = LatticeEnvironment.DEFAULT,
        server: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        timeout: typing.Optional[float] = None,
        max_retries: typing.Optional[int] = None,
        follow_redirects: typing.Optional[bool] = True,
        httpx_client: typing.Optional[httpx.Client] = None,
        logging: typing.Optional[typing.Union[LogConfig, Logger]] = None,
        token: typing.Callable[[], str],
    ): ...
    def __init__(
        self,
        *,
        base_url: typing.Optional[str] = None,
        environment: LatticeEnvironment = LatticeEnvironment.DEFAULT,
        server: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        client_id: typing.Optional[str] = None,
        client_secret: typing.Optional[str] = None,
        token: typing.Optional[typing.Callable[[], str]] = None,
        _token_getter_override: typing.Optional[typing.Callable[[], str]] = None,
        timeout: typing.Optional[float] = None,
        max_retries: typing.Optional[int] = None,
        follow_redirects: typing.Optional[bool] = True,
        httpx_client: typing.Optional[httpx.Client] = None,
        logging: typing.Optional[typing.Union[LogConfig, Logger]] = None,
    ):
        _defaulted_timeout = (
            timeout if timeout is not None else 60 if httpx_client is None else httpx_client.timeout.read
        )
        _defaulted_max_retries = max_retries if max_retries is not None else 2
        if server is not None:
            _server = server if server is not None else "example.developer.anduril.com"
            base_url = "https://{server}".format(server=_server)
        if token is not None:
            self._client_wrapper = SyncClientWrapper(
                base_url=_get_base_url(base_url=base_url, environment=environment),
                headers=headers,
                httpx_client=httpx_client
                if httpx_client is not None
                else httpx.Client(timeout=_defaulted_timeout, follow_redirects=follow_redirects)
                if follow_redirects is not None
                else httpx.Client(timeout=_defaulted_timeout),
                timeout=_defaulted_timeout,
                max_retries=_defaulted_max_retries,
                logging=logging,
                token=_token_getter_override if _token_getter_override is not None else token,
            )
        elif client_id is not None and client_secret is not None:
            oauth_token_provider = OAuthTokenProvider(
                client_id=client_id,
                client_secret=client_secret,
                client_wrapper=SyncClientWrapper(
                    base_url=_get_base_url(base_url=base_url, environment=environment),
                    headers=headers,
                    httpx_client=httpx_client
                    if httpx_client is not None
                    else httpx.Client(timeout=_defaulted_timeout, follow_redirects=follow_redirects)
                    if follow_redirects is not None
                    else httpx.Client(timeout=_defaulted_timeout),
                    timeout=_defaulted_timeout,
                    max_retries=_defaulted_max_retries,
                    logging=logging,
                ),
            )
            self._client_wrapper = SyncClientWrapper(
                base_url=_get_base_url(base_url=base_url, environment=environment),
                headers=headers,
                token=_token_getter_override if _token_getter_override is not None else oauth_token_provider.get_token,
                httpx_client=httpx_client
                if httpx_client is not None
                else httpx.Client(timeout=_defaulted_timeout, follow_redirects=follow_redirects)
                if follow_redirects is not None
                else httpx.Client(timeout=_defaulted_timeout),
                timeout=_defaulted_timeout,
                max_retries=_defaulted_max_retries,
                logging=logging,
            )
        else:
            raise ApiError(
                body="The client must be instantiated with either 'token' or both 'client_id' and 'client_secret'"
            )
        self._entities: typing.Optional[EntitiesClient] = None
        self._tasks: typing.Optional[TasksClient] = None
        self._objects: typing.Optional[ObjectsClient] = None
        self._oauth: typing.Optional[OauthClient] = None

    @property
    def entities(self):
        if self._entities is None:
            from .entities.client import EntitiesClient  # noqa: E402

            self._entities = EntitiesClient(client_wrapper=self._client_wrapper)
        return self._entities

    @property
    def tasks(self):
        if self._tasks is None:
            from .tasks.client import TasksClient  # noqa: E402

            self._tasks = TasksClient(client_wrapper=self._client_wrapper)
        return self._tasks

    @property
    def objects(self):
        if self._objects is None:
            from .objects.client import ObjectsClient  # noqa: E402

            self._objects = ObjectsClient(client_wrapper=self._client_wrapper)
        return self._objects

    @property
    def oauth(self):
        if self._oauth is None:
            from .oauth.client import OauthClient  # noqa: E402

            self._oauth = OauthClient(client_wrapper=self._client_wrapper)
        return self._oauth


def _make_default_async_client(
    timeout: typing.Optional[float],
    follow_redirects: typing.Optional[bool],
) -> httpx.AsyncClient:
    try:
        import httpx_aiohttp  # type: ignore[import-not-found]
    except ImportError:
        pass
    else:
        if follow_redirects is not None:
            return httpx_aiohttp.HttpxAiohttpClient(timeout=timeout, follow_redirects=follow_redirects)
        return httpx_aiohttp.HttpxAiohttpClient(timeout=timeout)

    if follow_redirects is not None:
        return httpx.AsyncClient(timeout=timeout, follow_redirects=follow_redirects)
    return httpx.AsyncClient(timeout=timeout)


class AsyncLattice:
    """
    Use this class to access the different functions within the SDK. You can instantiate any number of clients with different configuration that will propagate to these functions.

    Parameters
    ----------

    base_url : typing.Optional[str]
        The base url to use for requests from the client.

    client_id : str
        The client identifier used for authentication.

    client_secret : str
        The client secret used for authentication.

    timeout : typing.Optional[float]
        The timeout to be used, in seconds, for requests. By default the timeout is 60 seconds, unless a custom httpx client is used, in which case this default is not enforced.

    max_retries : typing.Optional[int]
        The default maximum number of retries for failed requests. Defaults to 2. Per-request `max_retries` in `request_options` takes precedence over this value.

    follow_redirects : typing.Optional[bool]
        Whether the default httpx client follows redirects or not, this is irrelevant if a custom httpx client is passed in.

    httpx_client : typing.Optional[httpx.AsyncClient]
        The httpx client to use for making requests, a preconfigured client is used by default, however this is useful should you want to pass in any custom httpx configuration.

    # or ...

    base_url : typing.Optional[str]
        The base url to use for requests from the client.

    token : typing.Callable[[], str]
        Authenticate by providing a callable that returns a pre-generated bearer token. In this mode, OAuth client credentials are not required.

    timeout : typing.Optional[float]
        The timeout to be used, in seconds, for requests. By default the timeout is 60 seconds, unless a custom httpx client is used, in which case this default is not enforced.

    max_retries : typing.Optional[int]
        The default maximum number of retries for failed requests. Defaults to 2. Per-request `max_retries` in `request_options` takes precedence over this value.

    follow_redirects : typing.Optional[bool]
        Whether the default httpx client follows redirects or not, this is irrelevant if a custom httpx client is passed in.

    httpx_client : typing.Optional[httpx.AsyncClient]
        The httpx client to use for making requests, a preconfigured client is used by default, however this is useful should you want to pass in any custom httpx configuration.

    Examples
    --------
    from anduril import AsyncLattice

    client = AsyncLattice(
        client_id="YOUR_CLIENT_ID",
        client_secret="YOUR_CLIENT_SECRET",
    )

    # or ...

    from anduril import AsyncLattice

    client = AsyncLattice(
        base_url="https://yourhost.com/path/to/api",
        token="YOUR_BEARER_TOKEN",
    )
    """

    @typing.overload
    def __init__(
        self,
        *,
        base_url: typing.Optional[str] = None,
        environment: LatticeEnvironment = LatticeEnvironment.DEFAULT,
        server: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        timeout: typing.Optional[float] = None,
        max_retries: typing.Optional[int] = None,
        follow_redirects: typing.Optional[bool] = True,
        httpx_client: typing.Optional[httpx.AsyncClient] = None,
        logging: typing.Optional[typing.Union[LogConfig, Logger]] = None,
        client_id: str,
        client_secret: str,
    ): ...
    @typing.overload
    def __init__(
        self,
        *,
        base_url: typing.Optional[str] = None,
        environment: LatticeEnvironment = LatticeEnvironment.DEFAULT,
        server: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        timeout: typing.Optional[float] = None,
        max_retries: typing.Optional[int] = None,
        follow_redirects: typing.Optional[bool] = True,
        httpx_client: typing.Optional[httpx.AsyncClient] = None,
        logging: typing.Optional[typing.Union[LogConfig, Logger]] = None,
        token: typing.Callable[[], str],
    ): ...
    def __init__(
        self,
        *,
        base_url: typing.Optional[str] = None,
        environment: LatticeEnvironment = LatticeEnvironment.DEFAULT,
        server: typing.Optional[str] = None,
        headers: typing.Optional[typing.Dict[str, str]] = None,
        client_id: typing.Optional[str] = None,
        client_secret: typing.Optional[str] = None,
        token: typing.Optional[typing.Callable[[], str]] = None,
        _token_getter_override: typing.Optional[typing.Callable[[], str]] = None,
        timeout: typing.Optional[float] = None,
        max_retries: typing.Optional[int] = None,
        follow_redirects: typing.Optional[bool] = True,
        httpx_client: typing.Optional[httpx.AsyncClient] = None,
        logging: typing.Optional[typing.Union[LogConfig, Logger]] = None,
    ):
        _defaulted_timeout = (
            timeout if timeout is not None else 60 if httpx_client is None else httpx_client.timeout.read
        )
        _defaulted_max_retries = max_retries if max_retries is not None else 2
        if server is not None:
            _server = server if server is not None else "example.developer.anduril.com"
            base_url = "https://{server}".format(server=_server)
        if token is not None:
            self._client_wrapper = AsyncClientWrapper(
                base_url=_get_base_url(base_url=base_url, environment=environment),
                headers=headers,
                httpx_client=httpx_client
                if httpx_client is not None
                else _make_default_async_client(timeout=_defaulted_timeout, follow_redirects=follow_redirects),
                timeout=_defaulted_timeout,
                max_retries=_defaulted_max_retries,
                logging=logging,
                token=_token_getter_override if _token_getter_override is not None else token,
            )
        elif client_id is not None and client_secret is not None:
            oauth_token_provider = AsyncOAuthTokenProvider(
                client_id=client_id,
                client_secret=client_secret,
                client_wrapper=AsyncClientWrapper(
                    base_url=_get_base_url(base_url=base_url, environment=environment),
                    headers=headers,
                    httpx_client=httpx_client
                    if httpx_client is not None
                    else httpx.AsyncClient(timeout=_defaulted_timeout, follow_redirects=follow_redirects)
                    if follow_redirects is not None
                    else httpx.AsyncClient(timeout=_defaulted_timeout),
                    timeout=_defaulted_timeout,
                    max_retries=_defaulted_max_retries,
                    logging=logging,
                ),
            )
            self._client_wrapper = AsyncClientWrapper(
                base_url=_get_base_url(base_url=base_url, environment=environment),
                headers=headers,
                token=_token_getter_override,
                async_token=oauth_token_provider.get_token,
                httpx_client=httpx_client
                if httpx_client is not None
                else _make_default_async_client(timeout=_defaulted_timeout, follow_redirects=follow_redirects),
                timeout=_defaulted_timeout,
                max_retries=_defaulted_max_retries,
                logging=logging,
            )
        else:
            raise ApiError(
                body="The client must be instantiated with either 'token' or both 'client_id' and 'client_secret'"
            )
        self._entities: typing.Optional[AsyncEntitiesClient] = None
        self._tasks: typing.Optional[AsyncTasksClient] = None
        self._objects: typing.Optional[AsyncObjectsClient] = None
        self._oauth: typing.Optional[AsyncOauthClient] = None

    @property
    def entities(self):
        if self._entities is None:
            from .entities.client import AsyncEntitiesClient  # noqa: E402

            self._entities = AsyncEntitiesClient(client_wrapper=self._client_wrapper)
        return self._entities

    @property
    def tasks(self):
        if self._tasks is None:
            from .tasks.client import AsyncTasksClient  # noqa: E402

            self._tasks = AsyncTasksClient(client_wrapper=self._client_wrapper)
        return self._tasks

    @property
    def objects(self):
        if self._objects is None:
            from .objects.client import AsyncObjectsClient  # noqa: E402

            self._objects = AsyncObjectsClient(client_wrapper=self._client_wrapper)
        return self._objects

    @property
    def oauth(self):
        if self._oauth is None:
            from .oauth.client import AsyncOauthClient  # noqa: E402

            self._oauth = AsyncOauthClient(client_wrapper=self._client_wrapper)
        return self._oauth


def _get_base_url(*, base_url: typing.Optional[str] = None, environment: LatticeEnvironment) -> str:
    if base_url is not None:
        return base_url
    elif environment is not None:
        return environment.value
    else:
        raise Exception("Please pass in either base_url or environment to construct the client")
