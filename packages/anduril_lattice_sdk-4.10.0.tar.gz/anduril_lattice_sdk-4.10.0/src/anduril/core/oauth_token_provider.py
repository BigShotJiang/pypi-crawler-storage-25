# This file was auto-generated from our API Definition.

import asyncio
import datetime as dt
import threading
import typing
from asyncio import Lock as asyncio_Lock
from threading import Lock as threading_Lock

from ..oauth.client import AsyncOauthClient, OauthClient
from .client_wrapper import AsyncClientWrapper, SyncClientWrapper


class OAuthTokenProvider:
    BUFFER_IN_MINUTES = 2

    def __init__(self, *, client_id: str, client_secret: str, client_wrapper: SyncClientWrapper):
        self._client_id = client_id
        self._client_secret = client_secret
        self._access_token: typing.Optional[str] = None
        self._expires_at: dt.datetime = dt.datetime.now()
        self._auth_client = OauthClient(client_wrapper=client_wrapper)
        self._lock: threading_Lock = threading.Lock()

    def get_token(self) -> str:
        if self._access_token and self._expires_at > dt.datetime.now():
            return self._access_token
        with self._lock:
            if self._access_token and self._expires_at > dt.datetime.now():
                return self._access_token
            return self._refresh()

    def _refresh(self) -> str:
        token_response = self._auth_client.get_token(client_id=self._client_id, client_secret=self._client_secret)
        self._access_token = token_response.access_token
        self._expires_at = self._get_expires_at(
            expires_in_seconds=token_response.expires_in if token_response.expires_in is not None else 3600,
            buffer_in_minutes=self.BUFFER_IN_MINUTES,
        )
        return self._access_token

    def _get_expires_at(self, *, expires_in_seconds: int, buffer_in_minutes: int):
        return dt.datetime.now() + dt.timedelta(seconds=expires_in_seconds) - dt.timedelta(minutes=buffer_in_minutes)


class AsyncOAuthTokenProvider:
    BUFFER_IN_MINUTES = 2

    def __init__(self, *, client_id: str, client_secret: str, client_wrapper: AsyncClientWrapper):
        self._client_id = client_id
        self._client_secret = client_secret
        self._access_token: typing.Optional[str] = None
        self._expires_at: dt.datetime = dt.datetime.now()
        self._auth_client = AsyncOauthClient(client_wrapper=client_wrapper)
        self._lock: asyncio_Lock = asyncio.Lock()

    async def get_token(self) -> str:
        if self._access_token and self._expires_at > dt.datetime.now():
            return self._access_token
        async with self._lock:
            if self._access_token and self._expires_at > dt.datetime.now():
                return self._access_token
            return await self._refresh()

    async def _refresh(self) -> str:
        token_response = await self._auth_client.get_token(client_id=self._client_id, client_secret=self._client_secret)
        self._access_token = token_response.access_token
        self._expires_at = self._get_expires_at(
            expires_in_seconds=token_response.expires_in if token_response.expires_in is not None else 3600,
            buffer_in_minutes=self.BUFFER_IN_MINUTES,
        )
        return self._access_token

    def _get_expires_at(self, *, expires_in_seconds: int, buffer_in_minutes: int):
        return dt.datetime.now() + dt.timedelta(seconds=expires_in_seconds) - dt.timedelta(minutes=buffer_in_minutes)
