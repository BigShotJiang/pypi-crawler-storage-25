# neuroencoder

EEG foundation model embeddings for Python.

```bash
pip install neuroencoder
```

```python
import neuroencoder as ne
from neuroencoder import MRL

images = ne.preprocess(eeg, sfreq=256, channel_names=ch_names)

model = MRL.from_pretrained()
embeddings = model.predict(images, dim=192)

ne.explore(embeddings)   # interactive Apple Embedding Atlas
ne.plot(embeddings)      # static matplotlib UMAP
```

## Model access

The MRL model is gated on HuggingFace. [Request access](https://huggingface.co/Neuroencoder/epi-embedding), then authenticate once:

```bash
huggingface-cli login
```

or export `HF_TOKEN=hf_...` before running.

## Documentation

Full docs at [docs.neuroencoder.com](https://docs.neuroencoder.com).

- [Introduction](https://docs.neuroencoder.com/introduction) — what this is
- [Quickstart](https://docs.neuroencoder.com/quickstart) — your first embedding
- [Embeddings](https://docs.neuroencoder.com/embeddings) — the MRL model end-to-end
- [Visualization](https://docs.neuroencoder.com/visualization) — Apple Embedding Atlas
- [Benchmarks](https://docs.neuroencoder.com/benchmarks) — performance on 20 clinical EEG tasks
- [API reference](https://docs.neuroencoder.com/api)

## Links

- Source: [github.com/avocardio/neuroencoder](https://github.com/avocardio/neuroencoder)
- Model weights: [huggingface.co/Neuroencoder/epi-embedding](https://huggingface.co/Neuroencoder/epi-embedding)
- Website: [neuroencoder.com](https://neuroencoder.com)
