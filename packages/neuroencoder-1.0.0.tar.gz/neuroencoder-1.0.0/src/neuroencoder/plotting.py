"""
UMAP visualization for EPI-Embedding outputs.

Three coloring modes:
  - "time" (default): sequential colormap assuming 30s epochs
  - "cluster": DBSCAN auto-clustering
  - custom array: user-provided labels or continuous values
"""

import numpy as np
from typing import Optional, Union


def plot(
    embeddings: "Union[np.ndarray, torch.Tensor]",
    color: Optional[Union[str, np.ndarray, list]] = None,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    metric: str = "cosine",
    figsize: tuple = (8, 6),
    point_size: float = 5.0,
    cmap: str = "viridis",
    title: Optional[str] = None,
    alpha: float = 0.7,
    show: bool = True,
    save: Optional[str] = None,
    ax: Optional["matplotlib.axes.Axes"] = None,
    dbscan_eps: float = 0.5,
    dbscan_min_samples: int = 10,
    return_umap: bool = False,
):
    """Plot UMAP of embeddings with flexible coloring.

    Args:
        embeddings: [N, D] embedding array (numpy or torch tensor)
        color: coloring mode:
            - None or "time": color by sequential index (default)
            - "cluster": auto-cluster via DBSCAN
            - np.ndarray or list: custom per-point values (categorical or continuous)
        n_neighbors: UMAP n_neighbors
        min_dist: UMAP min_dist
        metric: UMAP distance metric
        figsize: figure size
        point_size: scatter point size
        cmap: matplotlib colormap name
        title: plot title
        alpha: point transparency
        show: call plt.show()
        save: if set, save the figure to this path (e.g. "umap.png")
        ax: existing matplotlib axes (creates new figure if None)
        dbscan_eps: DBSCAN eps parameter (only for color="cluster")
        dbscan_min_samples: DBSCAN min_samples (only for color="cluster")
        return_umap: if True, also return the 2D UMAP coordinates

    Returns:
        fig, ax (and optionally umap_coords if return_umap=True)
    """
    import warnings
    import matplotlib.pyplot as plt
    from umap import UMAP
    import torch
    if isinstance(embeddings, torch.Tensor):
        embeddings = embeddings.detach().cpu().float().numpy()
    embeddings = np.asarray(embeddings, dtype=np.float32)

    if embeddings.ndim != 2:
        raise ValueError(f"Expected 2D embeddings [N, D], got shape {embeddings.shape}")

    N = embeddings.shape[0]

    # Compute UMAP (silence noisy n_jobs warning triggered by random_state)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=".*n_jobs value.*overridden.*")
        reducer = UMAP(n_neighbors=n_neighbors, min_dist=min_dist,
                       metric=metric, random_state=42)
        coords = reducer.fit_transform(embeddings)

    # Determine coloring
    categorical = False
    if color is None or (isinstance(color, str) and color == "time"):
        c = np.arange(N, dtype=np.float32)
        if title is None:
            title = "UMAP (colored by time)"
        colorbar_label = "Epoch index"
    elif isinstance(color, str) and color == "cluster":
        from sklearn.cluster import DBSCAN
        labels = DBSCAN(eps=dbscan_eps, min_samples=dbscan_min_samples, metric="euclidean").fit_predict(coords)
        c = labels
        categorical = True
        if title is None:
            n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
            title = f"UMAP (DBSCAN: {n_clusters} clusters)"
        colorbar_label = "Cluster"
    else:
        c = np.asarray(color)
        if c.shape[0] != N:
            raise ValueError(f"color array length {c.shape[0]} != embeddings count {N}")
        # Check if categorical (strings or integers with few unique values)
        if c.dtype.kind in ("U", "S", "O"):
            categorical = True
            colorbar_label = "Label"
        elif c.dtype.kind in ("i", "u") and len(np.unique(c)) <= 30:
            categorical = True
            colorbar_label = "Label"
        else:
            colorbar_label = "Value"
        if title is None:
            title = "UMAP (custom coloring)"

    # Create figure
    if ax is None:
        fig, ax = plt.subplots(1, 1, figsize=figsize, facecolor="white")
    else:
        fig = ax.figure

    if categorical:
        unique_labels = np.unique(c)
        colors_cycle = plt.colormaps["tab20" if len(unique_labels) > 10 else "tab10"]
        for i, label in enumerate(unique_labels):
            mask = c == label
            label_str = "noise" if (isinstance(label, (int, np.integer)) and label == -1) else str(label)
            ax.scatter(coords[mask, 0], coords[mask, 1], s=point_size, alpha=alpha,
                      color=colors_cycle(i / max(len(unique_labels), 1)),
                      label=label_str, edgecolors="none")
        if len(unique_labels) <= 20:
            ax.legend(markerscale=2, fontsize=7, loc="best", framealpha=0.8)
    else:
        sc = ax.scatter(coords[:, 0], coords[:, 1], c=c, s=point_size, alpha=alpha,
                       cmap=cmap, edgecolors="none")
        plt.colorbar(sc, ax=ax, label=colorbar_label, shrink=0.8)

    ax.set_title(title, fontsize=11)
    ax.set_xlabel("UMAP 1", fontsize=9)
    ax.set_ylabel("UMAP 2", fontsize=9)
    ax.tick_params(labelsize=8)
    ax.set_aspect("equal")
    fig.tight_layout()

    if save:
        fig.savefig(save, dpi=150, bbox_inches="tight")

    if show:
        plt.show()

    if return_umap:
        return fig, ax, coords
    return fig, ax
