"""
neuroencoder — Python SDK for the EPI-Embedding MRL model.

The MRL model is a Matryoshka-distilled version of the EPI-250k EEG
foundation model (trained on ~250,000 hours of clinical EEG). It produces
a 768-d embedding that you can truncate to 384, 192, 48, or 16 dimensions.

Usage:
    import neuroencoder as ne
    from neuroencoder import MRL

    images = ne.preprocess(eeg, sfreq=256, channel_names=ch_names)

    model = MRL.from_pretrained()
    embeddings = model.predict(images, dim=192)

    ne.explore(embeddings)
"""

__version__ = "1.0.0"

from neuroencoder.preprocessing import (
    preprocess, signal_condition, region_average, epoch, TemporalMatrix,
)
from neuroencoder.model import MRL, MRL_DIMS


def plot(embeddings, **kwargs):
    """Static matplotlib UMAP. See `neuroencoder.plotting.plot`."""
    from neuroencoder.plotting import plot as _plot
    return _plot(embeddings, **kwargs)


def explore(embeddings, **kwargs):
    """Interactive Apple Embedding Atlas (Jupyter widget).
    See `neuroencoder.atlas.explore`."""
    from neuroencoder.atlas import explore as _explore
    return _explore(embeddings, **kwargs)


def serve(embeddings, **kwargs):
    """Launch a standalone Atlas server (no Jupyter required).
    Same defaults as `explore()`. See `neuroencoder.atlas.serve`."""
    from neuroencoder.atlas import serve as _serve
    return _serve(embeddings, **kwargs)


__all__ = [
    "__version__",
    "MRL",
    "MRL_DIMS",
    "preprocess",
    "signal_condition",
    "region_average",
    "epoch",
    "TemporalMatrix",
    "plot",
    "explore",
    "serve",
]
