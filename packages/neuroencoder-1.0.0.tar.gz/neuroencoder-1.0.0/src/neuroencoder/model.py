"""
EPI-Embedding model: Hiera-Base encoder + Matryoshka projector.

Produces embeddings truncatable to [768, 384, 192, 48, 16] dimensions.
Auto-downloads weights from HuggingFace on first use.
"""

import math
from functools import partial
from typing import Tuple, Optional, Union
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F

from timm.layers import DropPath, Mlp

HF_REPO = "Neuroencoder/epi-embedding"
MRL_DIMS = [768, 384, 192, 48, 16]


# ============================================================================
# Hiera utilities (from Meta FAIR, adapted)
# ============================================================================

def _conv_nd(n: int):
    return [nn.Identity, nn.Conv1d, nn.Conv2d, nn.Conv3d][n]

def _do_pool(x: torch.Tensor, stride: int) -> torch.Tensor:
    return x.view(x.shape[0], stride, -1, x.shape[-1]).max(dim=1).values

def _do_masked_conv(x, conv, mask=None):
    if conv is None: return x
    if mask is None: return conv(x)
    if mask.shape[2:] != x.shape[2:]:
        mask = F.interpolate(mask.float(), size=x.shape[2:])
    return conv(x * mask.bool())

def _undo_windowing(x, shape, mu_shape):
    D = len(shape)
    B, C = x.shape[0], x.shape[-1]
    num_MUs = [s // mu for s, mu in zip(shape, mu_shape)]
    x = x.view(B, *num_MUs, *mu_shape, C)
    permute = [0] + sum([list(p) for p in zip(range(1, 1+D), range(1+D, 1+2*D))], []) + [len(x.shape)-1]
    return x.permute(permute).reshape(B, *shape, C)


class _Unroll(nn.Module):
    def __init__(self, input_size, patch_stride, unroll_schedule):
        super().__init__()
        self.size = [i // s for i, s in zip(input_size, patch_stride)]
        self.schedule = unroll_schedule

    def forward(self, x):
        B, _, C = x.shape
        cur_size = self.size
        x = x.view(*([B] + cur_size + [C]))
        for strides in self.schedule:
            cur_size = [i // s for i, s in zip(cur_size, strides)]
            new_shape = [B] + sum([[i, s] for i, s in zip(cur_size, strides)], []) + [C]
            x = x.view(new_shape)
            L = len(new_shape)
            permute = [0] + list(range(2, L-1, 2)) + list(range(1, L-1, 2)) + [L-1]
            x = x.permute(permute).flatten(0, len(strides))
            B *= math.prod(strides)
        return x.reshape(-1, math.prod(self.size), C)


class _Reroll(nn.Module):
    def __init__(self, input_size, patch_stride, unroll_schedule, stage_ends, q_pool):
        super().__init__()
        self.size = [i // s for i, s in zip(input_size, patch_stride)]
        self.schedule = {}
        size = self.size
        for i in range(stage_ends[-1] + 1):
            self.schedule[i] = unroll_schedule, size
            if i in stage_ends[:q_pool]:
                if len(unroll_schedule) > 0:
                    size = [n // s for n, s in zip(size, unroll_schedule[0])]
                unroll_schedule = unroll_schedule[1:]

    def forward(self, x, block_idx, mask=None):
        schedule, size = self.schedule[block_idx]
        B, N, C = x.shape
        D = len(size)
        cur_mu_shape = [1] * D
        for strides in schedule:
            x = x.view(B, *strides, N // math.prod(strides), *cur_mu_shape, C)
            L = len(x.shape)
            permute = [0, 1+D] + sum([list(p) for p in zip(range(1, 1+D), range(1+D+1, L-1))], []) + [L-1]
            x = x.permute(permute)
            for i in range(D):
                cur_mu_shape[i] *= strides[i]
            x = x.reshape(B, -1, *cur_mu_shape, C)
            N = x.shape[1]
        x = x.view(B, N, *cur_mu_shape, C)
        if mask is not None:
            return x
        return _undo_windowing(x, size, cur_mu_shape)


# ============================================================================
# Hiera core blocks
# ============================================================================

class MaskUnitAttention(nn.Module):
    def __init__(self, dim, dim_out, heads, q_stride=1, window_size=0, use_mask_unit_attn=False):
        super().__init__()
        self.dim, self.dim_out, self.heads = dim, dim_out, heads
        self.q_stride = q_stride
        self.head_dim = dim_out // heads
        self.qkv = nn.Linear(dim, 3 * dim_out)
        self.proj = nn.Linear(dim_out, dim_out)
        self.window_size = window_size
        self.use_mask_unit_attn = use_mask_unit_attn

    def forward(self, x):
        B, N, _ = x.shape
        num_windows = (N // (self.q_stride * self.window_size)) if self.use_mask_unit_attn else 1
        qkv = self.qkv(x).reshape(B, -1, num_windows, 3, self.heads, self.head_dim).permute(3, 0, 4, 2, 1, 5)
        q, k, v = qkv[0], qkv[1], qkv[2]
        if self.q_stride > 1:
            q = q.view(B, self.heads, num_windows, self.q_stride, -1, self.head_dim).max(dim=3).values
        x = F.scaled_dot_product_attention(q.contiguous(), k.contiguous(), v.contiguous())
        x = x.transpose(1, 3).reshape(B, -1, self.dim_out)
        return self.proj(x)


class HieraBlock(nn.Module):
    def __init__(self, dim, dim_out, heads, mlp_ratio=4.0, drop_path=0.0,
                 norm_layer=nn.LayerNorm, act_layer=nn.GELU, q_stride=1,
                 window_size=0, use_mask_unit_attn=False):
        super().__init__()
        self.dim, self.dim_out = dim, dim_out
        self.norm1 = norm_layer(dim)
        self.attn = MaskUnitAttention(dim, dim_out, heads, q_stride, window_size, use_mask_unit_attn)
        self.norm2 = norm_layer(dim_out)
        self.mlp = Mlp(dim_out, int(dim_out * mlp_ratio), act_layer=act_layer)
        self.drop_path = DropPath(drop_path) if drop_path > 0 else nn.Identity()
        if dim != dim_out:
            self.proj = nn.Linear(dim, dim_out)

    def forward(self, x):
        x_norm = self.norm1(x)
        if self.dim != self.dim_out:
            x = _do_pool(self.proj(x_norm), stride=self.attn.q_stride)
        x = x + self.drop_path(self.attn(x_norm))
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        return x


class PatchEmbed(nn.Module):
    def __init__(self, dim_in, dim_out, kernel, stride, padding):
        super().__init__()
        self.proj = _conv_nd(len(kernel))(dim_in, dim_out, kernel_size=kernel, stride=stride, padding=padding)

    def forward(self, x, mask=None):
        x = _do_masked_conv(x, self.proj, mask)
        return x.reshape(x.shape[0], x.shape[1], -1).transpose(2, 1)


# ============================================================================
# Hiera encoder (inference only)
# ============================================================================

class Hiera(nn.Module):
    def __init__(
        self,
        input_size=(224, 224),
        in_chans=8,
        embed_dim=96,
        num_heads=1,
        stages=(2, 3, 16, 3),
        q_pool=2,
        q_stride=(2, 2),
        mask_unit_size=(8, 8),
        mask_unit_attn=(True, True, False, False),
        dim_mul=2.0,
        head_mul=2.0,
        patch_kernel=(7, 7),
        patch_stride=(4, 4),
        patch_padding=(3, 3),
        mlp_ratio=4.0,
        drop_path_rate=0.0,
    ):
        super().__init__()
        norm_layer = partial(nn.LayerNorm, eps=1e-6)
        depth = sum(stages)
        self.patch_stride = patch_stride
        self.tokens_spatial_shape = [i // s for i, s in zip(input_size, patch_stride)]
        num_tokens = math.prod(self.tokens_spatial_shape)
        flat_mu_size = math.prod(mask_unit_size)
        flat_q_stride = math.prod(q_stride)

        self.q_pool, self.q_stride = q_pool, q_stride
        self.mu_size, self.mask_unit_size = flat_mu_size, mask_unit_size
        self.mask_spatial_shape = [i // s for i, s in zip(self.tokens_spatial_shape, mask_unit_size)]
        self.stage_ends = [sum(stages[:i]) - 1 for i in range(1, len(stages) + 1)]

        self.patch_embed = PatchEmbed(in_chans, embed_dim, patch_kernel, patch_stride, patch_padding)
        self.pos_embed = nn.Parameter(torch.zeros(1, num_tokens, embed_dim))

        self.unroll = _Unroll(input_size, patch_stride, [q_stride] * len(self.stage_ends[:-1]))
        self.reroll = _Reroll(input_size, patch_stride, [q_stride] * len(self.stage_ends[:-1]),
                              self.stage_ends, q_pool)

        q_pool_blocks = [x + 1 for x in self.stage_ends[:q_pool]]
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth)]
        cur_stage = 0
        self.blocks = nn.ModuleList()
        for i in range(depth):
            dim_out = embed_dim
            use_mua = mask_unit_attn[cur_stage]
            if i - 1 in self.stage_ends:
                dim_out = int(embed_dim * dim_mul)
                num_heads = int(num_heads * head_mul)
                cur_stage += 1
                if i in q_pool_blocks:
                    flat_mu_size //= flat_q_stride
            self.blocks.append(HieraBlock(
                dim=embed_dim, dim_out=dim_out, heads=num_heads, mlp_ratio=mlp_ratio,
                drop_path=dpr[i], norm_layer=norm_layer,
                q_stride=(flat_q_stride if i in q_pool_blocks else 1),
                window_size=flat_mu_size, use_mask_unit_attn=use_mua,
            ))
            embed_dim = dim_out

        self.encoder_norm = norm_layer(embed_dim)

        # Multi-scale fusion heads (matches MaskedAutoencoderHiera from brain_atlas).
        # Required for exact parity with the trained checkpoint's forward_encoder.
        mask_unit_spatial_shape_final = [i // s ** q_pool for i, s in zip(mask_unit_size, q_stride)]
        curr_mu_size = list(mask_unit_size)
        self.multi_scale_fusion_heads = nn.ModuleList()
        for i in self.stage_ends[:q_pool]:
            kernel = [i // s for i, s in zip(curr_mu_size, mask_unit_spatial_shape_final)]
            curr_mu_size = [i // s for i, s in zip(curr_mu_size, q_stride)]
            self.multi_scale_fusion_heads.append(
                _conv_nd(len(q_stride))(self.blocks[i].dim_out, embed_dim,
                                        kernel_size=kernel, stride=kernel)
            )
        self.multi_scale_fusion_heads.append(nn.Identity())

    @staticmethod
    def _apply_fusion_head(head, x):
        if isinstance(head, nn.Identity):
            return x
        B, num_mu = x.shape[0:2]
        permute = [0] + [len(x.shape) - 2] + list(range(1, len(x.shape) - 2))
        x = head(x.reshape(B * num_mu, *x.shape[2:]).permute(permute))
        permute = [0] + list(range(2, len(x.shape))) + [1]
        return x.permute(permute).reshape(B, num_mu, *x.shape[2:], x.shape[1])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Match MaskedAutoencoderHiera.forward_encoder with mask_ratio=0.0.

        Runs all blocks, collects intermediates at each stage end, applies
        multi-scale fusion heads, applies encoder_norm, and returns
        mean-pooled 768-d features. This matches the official inference path
        used for evaluation.
        """
        B = x.shape[0]
        num_windows = math.prod(self.mask_spatial_shape)
        # mask_ratio=0.0 -> keep all mask units
        mask = torch.ones(B, num_windows, device=x.device, dtype=torch.bool)

        x = self.patch_embed(x, mask=mask.view(B, 1, *self.mask_spatial_shape))
        x = x + self.pos_embed
        x = self.unroll(x)
        # all tokens kept (mask all ones), but go through discard for parity
        x = x[mask[..., None].tile(1, self.mu_size, x.shape[2])].view(B, -1, x.shape[-1])

        intermediates = []
        for i, blk in enumerate(self.blocks):
            x = blk(x)
            if i in self.stage_ends:
                intermediates.append(self.reroll(x, i, mask=mask))

        # Only first q_pool intermediates + the last
        intermediates = intermediates[:self.q_pool] + intermediates[-1:]

        fused = 0.0
        for head, interm in zip(self.multi_scale_fusion_heads, intermediates):
            fused = fused + self._apply_fusion_head(head, interm)
        fused = self.encoder_norm(fused)

        # Global pool across all token dims: [B, ..., D] -> [B, D]
        D = fused.shape[-1]
        return fused.reshape(B, -1, D).mean(dim=1)


# ============================================================================
# MRL Projector
# ============================================================================

class MRLProjector(nn.Module):
    """Matryoshka Representation Learning projector.

    SimCLR-style: Linear -> BatchNorm -> ReLU -> Linear.
    Output can be truncated to any of [768, 384, 192, 48, 16] dimensions.
    """
    def __init__(self, input_dim=768, hidden_dim=768, output_dim=768):
        super().__init__()
        self.projector = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim, output_dim),
        )

    def forward(self, x: torch.Tensor, dim: Optional[int] = None) -> torch.Tensor:
        x = self.projector(x)
        if dim is not None:
            x = x[:, :dim]
        return x


# ============================================================================
# MRL model
# ============================================================================

class MRL(nn.Module):
    """The MRL model: Hiera-Base encoder with Matryoshka projector.

    Distilled from EPI-250k. Produces 768-d embeddings truncatable to
    384, 192, 48, or 16 dimensions in a single forward pass.

    Usage:
        from neuroencoder import MRL
        model = MRL.from_pretrained()  # auto-downloads from HF
        embeddings = model.predict(images, dim=192)
    """
    def __init__(self):
        super().__init__()
        self.encoder = Hiera(
            input_size=(224, 224),
            in_chans=8,
            embed_dim=96,
            num_heads=1,
            stages=(2, 3, 16, 3),
            q_pool=2,
            q_stride=(2, 2),
            mask_unit_size=(8, 8),
            mask_unit_attn=(True, True, False, False),
            patch_kernel=(7, 7),
            patch_stride=(4, 4),
            patch_padding=(3, 3),
        )
        self.projector = MRLProjector(input_dim=768, hidden_dim=768, output_dim=768)

    @torch.no_grad()
    def predict(self, x: torch.Tensor, dim: int = 768) -> torch.Tensor:
        """Get embeddings from preprocessed temporal matrix images.

        The input is automatically moved to the model's device.

        Args:
            x: [B, 8, 224, 224] temporal matrix images (output of preprocess())
            dim: embedding dimension, one of [768, 384, 192, 48, 16]

        Returns:
            [B, dim] **L2-normalized** embeddings, as a torch.Tensor on the
            model's device. Call `.cpu().numpy()` for downstream sklearn use.
            Cosine similarity reduces to a dot product.
        """
        if dim not in MRL_DIMS:
            raise ValueError(f"dim must be one of {MRL_DIMS}, got {dim}")
        # Auto-move to model device — saves users a manual .to(device) call
        device = next(self.parameters()).device
        if x.device != device:
            x = x.to(device)
        was_training = self.training
        self.eval()
        h = self.encoder(x)
        emb = self.projector(h, dim=dim)
        emb = F.normalize(emb, dim=-1)
        if was_training:
            self.train()
        return emb

    def forward(self, x: torch.Tensor, dim: int = 768) -> torch.Tensor:
        """Forward pass (supports gradients). See predict() for inference."""
        h = self.encoder(x)
        return self.projector(h, dim=dim)

    def embed(
        self,
        eeg,
        sfreq: float,
        channel_names=None,
        dim: int = 192,
        filter: bool = True,
        stride_seconds=None,
    ):
        """One-call convenience: raw EEG -> L2-normalized embeddings (numpy).

        Equivalent to `model.predict(ne.preprocess(eeg, ...), dim=dim).cpu().numpy()`.

        Args:
            eeg: raw EEG `[C, T]` continuous, or `[N, C, T]` pre-epoched
            sfreq: sampling frequency in Hz
            channel_names: 10-20 names (required if `C != 8`)
            dim: embedding dimension (default 192)
            filter: apply 1-100 Hz bandpass + 50/100 Hz notch
            stride_seconds: epoch hop in seconds (default 1.0, see preprocess)

        Returns:
            `[N, dim]` numpy array of L2-normalized embeddings.
        """
        from neuroencoder.preprocessing import preprocess
        device = next(self.parameters()).device
        images = preprocess(
            eeg, sfreq=sfreq, channel_names=channel_names,
            filter=filter, stride_seconds=stride_seconds, device=str(device),
        )
        emb = self.predict(images, dim=dim)
        return emb.cpu().numpy()

    @classmethod
    def from_pretrained(
        cls,
        repo_id: str = HF_REPO,
        filename: str = "mrl.pt",
        device: Optional[str] = None,
        **kwargs,
    ) -> "MRL":
        """Load the pretrained MRL model from HuggingFace.

        Downloads weights on first call, caches locally for subsequent use.
        The model is gated — authenticate once with `huggingface-cli login`
        or pass `token="hf_..."` / set the `HF_TOKEN` environment variable.
        Request access at https://huggingface.co/Neuroencoder/epi-embedding.

        Args:
            repo_id: HuggingFace repo (default: Neuroencoder/epi-embedding)
            filename: checkpoint filename (default: mrl.pt)
            device: torch device (default: cuda if available)
            **kwargs: forwarded to huggingface_hub.hf_hub_download
                (e.g. token="hf_...")

        Returns:
            MRL model with loaded weights on the chosen device, eval mode.
        """
        from huggingface_hub import hf_hub_download

        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"

        model = cls()
        path = hf_hub_download(repo_id=repo_id, filename=filename, **kwargs)
        state_dict = torch.load(path, map_location="cpu", weights_only=True)
        model.load_state_dict(state_dict)
        model = model.to(device).eval()
        return model

    @classmethod
    def from_checkpoint(cls, path: str, device: Optional[str] = None) -> "MRL":
        """Load from a local checkpoint file.

        Handles both raw state_dicts and Lightning checkpoint formats.
        """
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"

        model = cls()
        ckpt = torch.load(path, map_location="cpu", weights_only=False)

        # Handle Lightning checkpoint format
        if "state_dict" in ckpt:
            state_dict = {}
            for k, v in ckpt["state_dict"].items():
                # Strip common prefixes from Lightning modules
                for prefix in ["model.", "eeg_encoder.", "encoder."]:
                    if k.startswith(prefix):
                        k = k[len(prefix):]
                        break
                state_dict[k] = v
            # Try loading encoder weights
            encoder_state = {k: v for k, v in state_dict.items()
                           if not k.startswith("projector.") and not k.startswith("eeg_projector.")}
            proj_state = {k.replace("eeg_projector.", "").replace("projector.", ""): v
                         for k, v in state_dict.items()
                         if k.startswith("projector.") or k.startswith("eeg_projector.")}
            model.encoder.load_state_dict(encoder_state, strict=False)
            if proj_state:
                model.projector.load_state_dict(proj_state, strict=False)
        else:
            model.load_state_dict(ckpt, strict=False)

        model = model.to(device).eval()
        return model
