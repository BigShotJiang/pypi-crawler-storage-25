"""
Interactive embedding explorer via Apple's open-source Embedding Atlas
(https://github.com/apple/embedding-atlas).
"""

import numpy as np
import pathlib
import threading
import webbrowser
from typing import Optional, Union, Sequence


_BOOT_SCRIPT_TEMPLATE = """
<script>
  // Auto-apply our defaults after Atlas loads:
  //   1. Force light theme if the page came up dark
  //   2. Pick the time_s column from the Color dropdown
  // Atlas creates the binned __ev_<col>_id column lazily on dropdown change,
  // so replaying the user action is the cleanest way to preset coloring.
  (function() {
    const targetLabel = "__COLOR_LABEL__";

    // Atlas uses Tailwind's media-query dark mode (no `.dark` class on root).
    // Detect via the OS preference itself, not via body color (we forced
    // body=white in CSS). Click the toolbar toggle once if needed.
    const wantsDark = () =>
      window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches;

    const flipToLightOnce = () => {
      if (!wantsDark()) return true;
      for (const b of document.querySelectorAll("button")) {
        const t = (b.title || "") + " " + (b.getAttribute("aria-label") || "");
        if (/light\\s*\\/\\s*dark|toggle.*theme/i.test(t)) {
          b.click();
          return true;
        }
      }
      return false;
    };

    const pickColor = () => {
      if (!targetLabel) return true;
      for (const sel of document.querySelectorAll("select")) {
        for (const opt of sel.options) {
          if (opt.label === targetLabel || opt.text === targetLabel) {
            if (sel.value !== opt.value) {
              sel.value = opt.value;
              sel.dispatchEvent(new Event("change", {bubbles: true}));
            }
            return true;
          }
        }
      }
      return false;
    };

    let themeDone = false, colorDone = false;
    let attempts = 0;
    const id = setInterval(() => {
      attempts++;
      if (!themeDone) themeDone = flipToLightOnce();
      if (!colorDone) colorDone = pickColor();
      if ((themeDone && colorDone) || attempts > 60) clearInterval(id);
    }, 200);
  })();
</script>
"""


def _make_themed_static(color_column: Optional[str] = None) -> str:
    """Copy Atlas's static dir into a temp dir and inject our auto-pick boot script."""
    import shutil, tempfile
    import embedding_atlas
    src = pathlib.Path(embedding_atlas.__file__).parent / "static"
    dst = pathlib.Path(tempfile.mkdtemp(prefix="ne_atlas_static_"))
    # Hardlink/copy the static tree
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        target = dst / rel
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, target)
    # Inject our boot script + light-theme override into index.html.
    idx = dst / "index.html"
    html = idx.read_text()

    # Hint the renderer to draw light-mode form controls (scrollbars, inputs).
    # Actual dark-mode override is done by the boot script flipping the
    # toolbar toggle - Atlas uses Tailwind media-query dark mode.
    light_css = """
<style>
  :root { color-scheme: light; }
</style>
"""
    html = html.replace("</head>", f"{light_css}\n  </head>", 1)

    if color_column:
        label = f"{color_column} (DOUBLE)"
        boot = _BOOT_SCRIPT_TEMPLATE.replace("__COLOR_LABEL__", label)
        html = html.replace("</body>", f"{boot}\n  </body>")

    idx.write_text(html)
    return str(dst)


def _build_initial_state(
    color_column: Optional[str] = "time_s",
    show_charts: bool = False,
    show_table: bool = False,
    show_embedding: bool = True,
) -> dict:
    """Build the Atlas initial_state dict that hides side panels and presets coloring."""
    state: dict = {
        "layoutStates": {
            "list": {
                "showCharts": bool(show_charts),
                "showTable": bool(show_table),
                "showEmbedding": bool(show_embedding),
            }
        }
    }
    if color_column:
        # Atlas internally bins the chosen column into __ev_<col>_id (UTINYINT).
        # Setting `category` here is what the Color dropdown writes when the
        # user picks the column; Atlas handles the binning.
        state["embeddingViewConfig"] = {"category": color_column}
    return state


def _build_dataframe(embeddings, filename, method, n_neighbors, min_dist, epoch_seconds):
    """Project + KNN + return a DataFrame with x/y/neighbors/time_s/filename columns."""
    import torch, pandas as pd
    if isinstance(embeddings, torch.Tensor):
        embeddings = embeddings.detach().cpu().float().numpy()
    embeddings = np.asarray(embeddings, dtype=np.float32)
    N = len(embeddings)

    if method == "umap":
        import warnings
        from umap import UMAP
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message=".*n_jobs value.*overridden.*")
            coords = UMAP(n_neighbors=n_neighbors, min_dist=min_dist,
                          n_components=2, random_state=42).fit_transform(embeddings)
    elif method == "tsne":
        from sklearn.manifold import TSNE
        coords = TSNE(n_components=2, random_state=42).fit_transform(embeddings)
    elif method == "pca":
        from sklearn.decomposition import PCA
        coords = PCA(n_components=2, random_state=42).fit_transform(embeddings)
    else:
        raise ValueError(f"Unknown method: {method}. Use 'umap', 'tsne', or 'pca'.")

    from sklearn.neighbors import NearestNeighbors
    k = min(n_neighbors, N - 1)
    knn = NearestNeighbors(n_neighbors=k)
    knn.fit(embeddings)
    knn_dists, knn_idx = knn.kneighbors(embeddings)
    neighbors = [{"ids": ids.tolist(), "distances": d.tolist()}
                 for ids, d in zip(knn_idx, knn_dists)]

    times = np.arange(N) * epoch_seconds
    df_data = {
        "x": coords[:, 0],
        "y": coords[:, 1],
        "neighbors": neighbors,
        "time_s": times.astype(np.float32),
    }
    if filename is not None:
        if isinstance(filename, str):
            df_data["filename"] = [filename] * N
        else:
            arr = list(filename)
            if len(arr) != N:
                raise ValueError(
                    f"filename length ({len(arr)}) != number of embeddings ({N})"
                )
            df_data["filename"] = arr
    return pd.DataFrame(df_data)


def explore(
    embeddings: "Union[np.ndarray, torch.Tensor]",
    filename: Optional[Union[str, Sequence[str]]] = None,
    method: str = "umap",
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    point_size: float = 3.0,
    epoch_seconds: float = 30.0,
    show_charts: bool = False,
    show_table: bool = False,
):
    """Interactive embedding visualization via Apple Embedding Atlas (Jupyter widget).

    Defaults: viridis time-coloring, side and bottom panels hidden.

    Args:
        embeddings: [N, D] embedding array
        filename: optional source-file label (str or per-point sequence)
        method: "umap", "tsne", or "pca"
        n_neighbors: UMAP / KNN neighbors
        min_dist: UMAP min_dist
        point_size: scatter point size
        epoch_seconds: seconds per embedding (used for the time axis)
        show_charts: show right-side charts panel (default False)
        show_table: show bottom data-table panel (default False)

    Returns:
        EmbeddingAtlasWidget rendering inline in Jupyter.
    """
    from embedding_atlas.widget import EmbeddingAtlasWidget

    df = _build_dataframe(embeddings, filename, method, n_neighbors, min_dist, epoch_seconds)
    initial_state = _build_initial_state(
        color_column="time_s",
        show_charts=show_charts,
        show_table=show_table,
    )

    return EmbeddingAtlasWidget(
        df,
        x="x",
        y="y",
        neighbors="neighbors",
        point_size=point_size,
        show_charts=show_charts,
        show_table=show_table,
        show_embedding=True,
        initial_state=initial_state,
    )


def serve(
    embeddings: "Union[np.ndarray, torch.Tensor]",
    filename: Optional[Union[str, Sequence[str]]] = None,
    method: str = "umap",
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    point_size: float = 3.0,
    epoch_seconds: float = 30.0,
    show_charts: bool = False,
    show_table: bool = False,
    host: str = "127.0.0.1",
    port: int = 5055,
    open_browser: bool = True,
) -> None:
    """Launch a standalone Atlas server (no Jupyter required).

    Same defaults as `explore()`: viridis time-coloring, panels hidden.
    Blocks until interrupted with Ctrl-C.

    Args:
        embeddings: [N, D] embedding array
        host, port: server bind address (default localhost:5055)
        open_browser: open the URL in the default browser
        (other args identical to `explore()`)
    """
    import uvicorn
    from embedding_atlas.data_source import DataSource
    from embedding_atlas.options import make_embedding_atlas_props
    from embedding_atlas.server import make_server
    from embedding_atlas.cache import sha256_hexdigest
    from embedding_atlas.version import __version__ as _ea_version

    df = _build_dataframe(embeddings, filename, method, n_neighbors, min_dist, epoch_seconds)
    # Atlas uses an internal row-index column to wire up neighbors lookups
    df = df.copy()
    df["__row_index__"] = range(len(df))

    initial_state = _build_initial_state(
        color_column="time_s",
        show_charts=show_charts,
        show_table=show_table,
    )
    props = make_embedding_atlas_props(
        row_id="__row_index__",
        x="x", y="y", neighbors="neighbors",
        point_size=point_size,
        show_charts=show_charts,
        show_table=show_table,
        show_embedding=True,
        initial_state=initial_state,
    )
    metadata = {"props": props}

    identifier = sha256_hexdigest([_ea_version, "neuroencoder", metadata], scope="DataSource")
    static = _make_themed_static(color_column="time_s")

    data_source = DataSource(identifier, df, metadata)
    # Use server-side DuckDB (matches CLI default), so queries hit the same
    # process that holds the dataframe.
    app = make_server(data_source, static_path=static, duckdb_uri="server")

    url = f"http://{host}:{port}"
    if open_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    print(f"Embedding Atlas: {url}  (Ctrl-C to stop)")
    uvicorn.run(app, host=host, port=port, log_level="warning")
