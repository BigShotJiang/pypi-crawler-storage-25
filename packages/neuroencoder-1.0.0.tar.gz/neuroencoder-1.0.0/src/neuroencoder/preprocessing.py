"""
EEG preprocessing pipeline for EPI-Embedding.

Replicates the exact temporal matrix representation from EPI-250k:
  raw EEG -> bandpass 1-100Hz -> resample 250Hz -> 30s epochs
  -> 8-region channel avg -> fold 86x86 -> min-max norm
  -> row-block permute -> resize 224x224

The user should be able to pass any (channels, time) EEG data with any
montage and we handle the rest: mismatched channel names, missing regions
zero-filled, arbitrary sample rate, arbitrary duration.

Usage:
    import neuroencoder as ne
    images = ne.preprocess(eeg, sfreq=256, channel_names=ch_names)
"""

import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional, Union, Sequence
from scipy.signal import butter, sosfiltfilt, iirnotch

TARGET_SFREQ = 250
EPOCH_SECONDS = 30
EPOCH_SAMPLES = TARGET_SFREQ * EPOCH_SECONDS  # 7500
SQUARE_SIZE = int(EPOCH_SAMPLES ** 0.5)        # 86
TARGET_SIZE = 224
BLOCK_SIZE = 32
N_BLOCKS = TARGET_SIZE // BLOCK_SIZE           # 7
SHUFFLE_PERM = [4, 1, 6, 0, 3, 5, 2]

# Canonical 8 brain regions (order matters - matches training).
REGIONS = ("Frontal", "Central", "Temporal_Left", "Temporal_Right",
           "Parietal", "Occipital", "EOG", "ECG")

# 10-20 electrode -> region mapping. Covers 10-20, 10-10, 10-5 montages.
REGION_MAP = {
    "Frontal": ["Fp1", "Fp2", "Fpz", "F1", "F2", "F3", "F4", "F5", "F6",
                "F7", "F8", "F9", "F10", "Fz", "AFz", "AF3", "AF4", "AF7", "AF8",
                "Nz", "FPz"],
    "Central": ["C1", "C2", "C3", "C4", "C5", "C6", "Cz",
                "FC1", "FC2", "FC3", "FC4", "FC5", "FC6", "FCz",
                "CP1", "CP2", "CP3", "CP4", "CP5", "CP6", "CPz"],
    "Temporal_Left": ["T3", "T5", "T7", "T9", "TP7", "TP9", "FT7", "FT9"],
    "Temporal_Right": ["T4", "T6", "T8", "T10", "TP8", "TP10", "FT8", "FT10"],
    "Parietal": ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10",
                 "Pz", "POz"],
    "Occipital": ["O1", "O2", "Oz", "PO3", "PO4", "PO7", "PO8", "Iz"],
    "EOG": ["EOG", "EOGR", "EOGL", "E1", "E2", "LOC", "ROC",
            "HEOG", "VEOG", "EOG1", "EOG2", "VEO", "HEO"],
    "ECG": ["ECG", "EKG", "ECG1", "ECG2"],
}

# Reverse lookup: normalized_name -> region_index
_NAME_TO_REGION = {}
for _idx, _region in enumerate(REGIONS):
    for _ch in REGION_MAP[_region]:
        _NAME_TO_REGION[_ch.upper()] = _idx


def _normalize_channel_name(name: str) -> str:
    """Normalize a channel name for matching.

    Strips: whitespace, hyphens, underscores, common prefixes (EEG, REF),
    reference suffixes (-REF, -LE, -AR, -LINK).
    """
    s = name.strip().upper()
    # Strip reference suffix first (-REF, -LE, etc.)
    for suffix in ("-REF", "-LE", "-AR", "-LINK", "-AVG"):
        if s.endswith(suffix):
            s = s[: -len(suffix)]
    # Remove remaining separators
    s = s.replace("-", "").replace("_", "").replace(" ", "").replace(".", "")
    # Strip EEG/REF prefixes
    for prefix in ("EEG", "REF"):
        if s.startswith(prefix) and len(s) > len(prefix):
            s = s[len(prefix):]
    return s


def _assign_channels_to_regions(channel_names: Sequence[str]) -> dict:
    """{region_idx: [channel_indices]}. Channels with no match are ignored."""
    region_channels: dict = {}
    for i, name in enumerate(channel_names):
        clean = _normalize_channel_name(str(name))
        rid = _NAME_TO_REGION.get(clean)
        if rid is not None:
            region_channels.setdefault(rid, []).append(i)
    return region_channels


def _bandpass_filter(data: np.ndarray, sfreq: float,
                     low: float = 1.0, high: float = 100.0, order: int = 4) -> np.ndarray:
    """4th-order Butterworth bandpass, zero-phase (forward-backward)."""
    nyq = sfreq / 2.0
    high_clip = min(high, nyq - 1.0)
    if high_clip <= low:
        return data
    sos = butter(order, [low / nyq, high_clip / nyq], btype="band", output="sos")
    return sosfiltfilt(sos, data, axis=-1).astype(data.dtype)


def _notch_filter(data: np.ndarray, sfreq: float,
                  freqs: Sequence[float] = (50.0, 100.0), Q: float = 30.0) -> np.ndarray:
    """IIR notch filter at specified frequencies."""
    for f0 in freqs:
        if f0 >= sfreq / 2.0:
            continue
        b, a = iirnotch(f0, Q, sfreq)
        sos = np.array([[b[0], b[1], b[2], a[0], a[1], a[2]]])
        data = sosfiltfilt(sos, data, axis=-1).astype(data.dtype)
    return data


def _resample(data: np.ndarray, sfreq_in: float, sfreq_out: float = TARGET_SFREQ) -> np.ndarray:
    """Linear resample along last axis via torch interpolation."""
    if abs(sfreq_in - sfreq_out) < 0.5:
        return data
    n_out = int(round(data.shape[-1] * sfreq_out / sfreq_in))
    t = torch.from_numpy(data).float()
    if t.ndim == 1:
        t = t.unsqueeze(0)
    t = t.unsqueeze(1)  # [C, 1, T]
    t = F.interpolate(t, size=n_out, mode="linear", align_corners=False)
    return t.squeeze(1).numpy()


def signal_condition(data: np.ndarray, sfreq: float,
                     bandpass: tuple = (1.0, 100.0),
                     notch: Sequence[float] = (50.0, 100.0)) -> tuple:
    """Bandpass + notch filter and resample to 250 Hz.

    Returns (filtered_data, 250.0).
    """
    data = np.nan_to_num(data.astype(np.float32), nan=0.0, posinf=0.0, neginf=0.0)
    data = _bandpass_filter(data, sfreq, bandpass[0], bandpass[1])
    if notch:
        data = _notch_filter(data, sfreq, notch)
    data = _resample(data, sfreq, TARGET_SFREQ)
    return data, float(TARGET_SFREQ)


def region_average(data: np.ndarray,
                   channel_names: Sequence[str],
                   warn_unmatched: bool = True) -> np.ndarray:
    """Average channels into 8 canonical brain regions.

    Missing regions (no channel maps to them) are zero-filled. This lets
    the model run on any montage: 4-channel frontal-only, 19-channel 10-20,
    256-channel HD-EEG, intracranial, etc.

    Args:
        data: [C, T] EEG
        channel_names: list of channel names (any length, any convention)
        warn_unmatched: emit a warning if zero channels match any region

    Returns:
        [8, T] region-averaged data in order:
        Frontal, Central, Temporal L/R, Parietal, Occipital, EOG, ECG.
    """
    mapping = _assign_channels_to_regions(channel_names)
    T = data.shape[-1]
    out = np.zeros((len(REGIONS), T), dtype=data.dtype)
    n_matched = 0
    for rid in range(len(REGIONS)):
        if rid in mapping:
            out[rid] = data[mapping[rid]].mean(axis=0)
            n_matched += len(mapping[rid])
    if warn_unmatched and n_matched == 0:
        warnings.warn(
            f"No channels matched any brain region out of {len(channel_names)} given. "
            f"All regions zero-filled. Check channel names match 10-20 conventions "
            f"(e.g. Fp1, C3, O2). Got: {list(channel_names)[:5]}...",
            UserWarning,
        )
    return out


def _pad_or_truncate(data: np.ndarray, target_samples: int) -> np.ndarray:
    """Pad with zeros or truncate along the last axis to target_samples."""
    T = data.shape[-1]
    if T == target_samples:
        return data
    if T > target_samples:
        return data[..., :target_samples]
    # Pad with zeros at the end
    pad_width = [(0, 0)] * (data.ndim - 1) + [(0, target_samples - T)]
    return np.pad(data, pad_width, mode="constant")


class TemporalMatrix(nn.Module):
    """Convert 8-channel EEG epochs (250 Hz, 30 s) to 224x224 temporal matrix images.

    Input:  [B, 8, 7500]
    Output: [B, 8, 224, 224]
    """

    def __init__(self):
        super().__init__()
        self.register_buffer("shuffle_perm", torch.tensor(SHUFFLE_PERM, dtype=torch.long))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, T = x.shape
        n_keep = SQUARE_SIZE * SQUARE_SIZE
        x = x[:, :, :n_keep]
        x = x.reshape(B, C, SQUARE_SIZE, SQUARE_SIZE)
        flat = x.reshape(B, C, -1)
        x_min = flat.min(dim=2, keepdim=True)[0].unsqueeze(-1)
        x_max = flat.max(dim=2, keepdim=True)[0].unsqueeze(-1)
        x = (x - x_min) / (x_max - x_min + 1e-8)
        x = F.interpolate(x, size=(TARGET_SIZE, TARGET_SIZE), mode="nearest")
        x = x.reshape(B, C, N_BLOCKS, BLOCK_SIZE, TARGET_SIZE)
        x = x[:, :, self.shuffle_perm, :, :]
        return x.reshape(B, C, TARGET_SIZE, TARGET_SIZE)


def epoch(data: np.ndarray, sfreq: float = TARGET_SFREQ,
          epoch_seconds: float = EPOCH_SECONDS,
          stride_seconds: Optional[float] = None) -> np.ndarray:
    """Segment continuous data into 30-second epochs.

    Args:
        data: `[C, T]` continuous EEG.
        sfreq: sampling frequency (Hz).
        epoch_seconds: epoch length (default 30, must match the model).
        stride_seconds: hop between successive epochs. Defaults to `1.0`
            (a near-continuous sliding window: a 30s window every 1s).
            Pass `epoch_seconds` (e.g. `30.0`) for non-overlapping epochs,
            which is what classification with epoch-level labels usually
            wants.

    Returns:
        `[N, C, samples]` array of epochs. Recordings shorter than one epoch
        are padded to one epoch. Trailing samples shorter than one epoch are
        dropped.
    """
    if stride_seconds is None:
        stride_seconds = 1.0  # Continuous sliding-window default
    if stride_seconds <= 0:
        raise ValueError(f"stride_seconds must be positive, got {stride_seconds}")

    samples = int(sfreq * epoch_seconds)
    stride = max(1, int(round(sfreq * stride_seconds)))
    C, T = data.shape

    if T < samples:
        # Pad up to one epoch
        data = np.pad(data, ((0, 0), (0, samples - T)), mode="constant")
        return data[None, :, :]

    starts = list(range(0, T - samples + 1, stride))
    if not starts:
        starts = [0]
    out = np.empty((len(starts), C, samples), dtype=data.dtype)
    for i, s in enumerate(starts):
        out[i] = data[:, s:s + samples]
    return out


def _conform_channels(data: np.ndarray,
                      channel_names: Optional[Sequence[str]]) -> np.ndarray:
    """Bring data to shape (..., 8, T) using the region-averaging rules.

    - If C == 8: assume data is already in canonical region order.
    - If channel_names provided: average by region, zero-fill missing.
    - If C != 8 and no names: warn and truncate/zero-pad to 8.
    """
    C = data.shape[-2]
    if channel_names is not None:
        if len(channel_names) != C:
            raise ValueError(
                f"channel_names length ({len(channel_names)}) != data channels ({C})."
            )
        if data.ndim == 2:
            return region_average(data, channel_names)
        # [N, C, T]
        return np.stack([region_average(d, channel_names) for d in data])
    if C == 8:
        return data
    # No names, not 8: best-effort truncate/pad and warn.
    warnings.warn(
        f"Got {C} channels without channel_names. Assuming canonical 8-region order. "
        f"Pass channel_names=[...] (10-20 names) for correct region averaging.",
        UserWarning,
    )
    if C > 8:
        return data[..., :8, :]
    T = data.shape[-1]
    if data.ndim == 2:
        out = np.zeros((8, T), dtype=data.dtype)
        out[:C] = data
        return out
    N = data.shape[0]
    out = np.zeros((N, 8, T), dtype=data.dtype)
    out[:, :C] = data
    return out


def preprocess(
    data: Union[np.ndarray, torch.Tensor],
    sfreq: float,
    channel_names: Optional[Sequence[str]] = None,
    filter: bool = True,
    stride_seconds: Optional[float] = None,
    device: Optional[str] = None,
) -> torch.Tensor:
    """Raw EEG -> temporal matrix images ready for the model.

    This single call does everything:
      1. Bandpass + notch filter (optional)
      2. Resample to 250 Hz
      3. Match channels to 8 brain regions (average or zero-fill)
      4. Segment into 30-second epochs (pad if shorter)
      5. Build temporal matrix images (224x224)

    Args:
        data: EEG data, shape `[C, T]` for continuous recordings, or
              `[N, C, T]` for pre-epoched data. C can be any number of
              channels - we average them into 8 regions.
        sfreq: sampling frequency in Hz.
        channel_names: channel names matching the 10-20 system (e.g.
              ["Fp1", "F3", "C3", ...]). Required whenever C != 8 to
              correctly average into brain regions. Unmatched channels
              are silently dropped; missing regions are zero-filled.
        filter: apply 1-100 Hz bandpass and 50/100 Hz notch filtering.
              Set False if your data is already filtered.
        stride_seconds: hop between epochs (only for continuous `[C, T]`
              input). Defaults to `1.0` (near-continuous sliding window:
              a 30s window every 1s). Pass `30.0` for non-overlapping
              epochs - typically what classification wants when each
              30s window has its own label.
        device: torch device. Defaults to CUDA if available, else CPU.

    Returns:
        torch.Tensor of shape `[N, 8, 224, 224]`.
    """
    # Tensor -> numpy
    if isinstance(data, torch.Tensor):
        data = data.detach().cpu().numpy()
    data = np.ascontiguousarray(data, dtype=np.float32)

    if data.ndim not in (2, 3):
        raise ValueError(f"Expected 2D [C, T] or 3D [N, C, T], got shape {data.shape}")

    # Always float32, no NaNs
    data = np.nan_to_num(data, nan=0.0, posinf=0.0, neginf=0.0)

    # Filter + resample. Works on 2D or 3D (filter per-epoch for 3D).
    if filter:
        if data.ndim == 2:
            data, sfreq = signal_condition(data, sfreq)
        else:
            filtered = [signal_condition(d, sfreq)[0] for d in data]
            data = np.stack(filtered)
            sfreq = float(TARGET_SFREQ)
    elif abs(sfreq - TARGET_SFREQ) > 0.5:
        # No filtering but still need to resample to 250 Hz
        if data.ndim == 2:
            data = _resample(data, sfreq)
        else:
            data = np.stack([_resample(d, sfreq) for d in data])
        sfreq = float(TARGET_SFREQ)

    # Channel matching / averaging -> (..., 8, T)
    data = _conform_channels(data, channel_names)

    # Epoch
    if data.ndim == 2:
        epochs = epoch(data, sfreq, stride_seconds=stride_seconds)  # [N, 8, T]
    else:
        # Pad/truncate each pre-epoched segment to 7500 samples
        epochs = np.stack([_pad_or_truncate(d, EPOCH_SAMPLES) for d in data])

    # Ensure exactly 7500 samples per epoch
    if epochs.shape[-1] != EPOCH_SAMPLES:
        epochs = np.stack([_pad_or_truncate(e, EPOCH_SAMPLES) for e in epochs])

    # Temporal matrix
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    t = torch.from_numpy(epochs).float().to(device)
    tm = TemporalMatrix().to(device)
    with torch.no_grad():
        images = tm(t)
    return images
