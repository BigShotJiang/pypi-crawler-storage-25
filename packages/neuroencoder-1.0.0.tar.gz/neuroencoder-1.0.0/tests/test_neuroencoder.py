"""Tests for the neuroencoder package."""

import numpy as np
import torch
import pytest


class TestPreprocessing:
    def test_temporal_matrix_shape(self):
        from neuroencoder.preprocessing import TemporalMatrix
        tm = TemporalMatrix()
        x = torch.randn(2, 8, 7500)
        out = tm(x)
        assert out.shape == (2, 8, 224, 224)

    def test_temporal_matrix_normalized(self):
        from neuroencoder.preprocessing import TemporalMatrix
        tm = TemporalMatrix()
        x = torch.randn(4, 8, 7500) * 100 + 50
        out = tm(x)
        assert out.min() >= -0.01
        assert out.max() <= 1.01

    def test_epoch_segmentation(self):
        from neuroencoder.preprocessing import epoch
        data = np.random.randn(8, 22500).astype(np.float32)  # 90 seconds
        # Default stride is 1.0s -> (90 - 30)/1 + 1 = 61 epochs
        assert epoch(data, sfreq=250).shape == (61, 8, 7500)
        # Non-overlapping: 90 / 30 = 3 epochs
        assert epoch(data, sfreq=250, stride_seconds=30.0).shape == (3, 8, 7500)

    def test_epoch_too_short_pads(self):
        """Short recordings get padded to one full epoch instead of raising."""
        from neuroencoder.preprocessing import epoch
        data = np.random.randn(8, 5000).astype(np.float32)  # 20 seconds
        epochs = epoch(data, sfreq=250)
        assert epochs.shape == (1, 8, 7500)

    def test_epoch_stride_options(self):
        """Stride controls window hop. Default is 1s (continuous)."""
        from neuroencoder.preprocessing import epoch
        data = np.random.randn(8, 60 * 250).astype(np.float32)  # 60s
        # Default 1s stride: (60-30)/1 + 1 = 31 epochs
        assert epoch(data, sfreq=250).shape[0] == 31
        # Non-overlapping: 60 / 30 = 2 epochs
        assert epoch(data, sfreq=250, stride_seconds=30.0).shape[0] == 2
        # 5-second stride: (60-30)/5 + 1 = 7 epochs
        assert epoch(data, sfreq=250, stride_seconds=5.0).shape[0] == 7

    def test_preprocess_with_stride(self):
        """preprocess() respects stride_seconds (default 1s sliding window)."""
        from neuroencoder.preprocessing import preprocess
        data = np.random.randn(8, 60 * 250).astype(np.float32)
        # Default 1s stride from 60s: 31 windows
        images = preprocess(data, sfreq=250, filter=False, device="cpu")
        assert images.shape == (31, 8, 224, 224)
        # Non-overlapping
        images = preprocess(data, sfreq=250, filter=False,
                            stride_seconds=30.0, device="cpu")
        assert images.shape == (2, 8, 224, 224)

    def test_preprocess_arbitrary_channel_count(self):
        """Should handle any channel count gracefully."""
        from neuroencoder.preprocessing import preprocess
        # 64-channel HD EEG
        ch64 = ["Fp1", "Fp2", "Fz", "F3", "F4", "F7", "F8",
                "FC1", "FC2", "FC5", "FC6",
                "C3", "C4", "Cz", "T7", "T8",
                "CP1", "CP2", "CP5", "CP6",
                "P3", "P4", "Pz", "P7", "P8",
                "PO3", "PO4", "POz", "O1", "O2", "Oz"] + [f"X{i}" for i in range(33)]
        data = np.random.randn(64, 30 * 256).astype(np.float32)
        images = preprocess(data, sfreq=256, channel_names=ch64,
                            filter=False, device="cpu")
        assert images.shape == (1, 8, 224, 224)

    def test_preprocess_few_channels_zero_fills(self):
        """Frontal-only montage should zero-fill other regions."""
        from neuroencoder.preprocessing import preprocess
        data = np.random.randn(4, 30 * 250).astype(np.float32)
        ch_names = ["Fp1", "Fp2", "F3", "F4"]
        images = preprocess(data, sfreq=250, channel_names=ch_names,
                            filter=False, device="cpu")
        assert images.shape == (1, 8, 224, 224)

    def test_preprocess_unmatched_names_warns(self):
        """Bogus channel names should warn but not crash."""
        from neuroencoder.preprocessing import preprocess
        import warnings
        data = np.random.randn(4, 30 * 250).astype(np.float32)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            images = preprocess(data, sfreq=250,
                                channel_names=["XX1", "XX2", "XX3", "XX4"],
                                filter=False, device="cpu")
        assert images.shape == (1, 8, 224, 224)
        assert any("No channels matched" in str(warning.message) for warning in w)

    def test_preprocess_short_recording_pads(self):
        """Recording shorter than 30s should still produce 1 epoch."""
        from neuroencoder.preprocessing import preprocess
        data = np.random.randn(8, 10 * 250).astype(np.float32)
        images = preprocess(data, sfreq=250, filter=False, device="cpu")
        assert images.shape == (1, 8, 224, 224)

    def test_region_average(self):
        from neuroencoder.preprocessing import region_average
        data = np.random.randn(19, 7500).astype(np.float32)
        ch_names = ["Fp1", "Fp2", "F3", "F4", "F7", "F8", "Fz",
                     "C3", "C4", "Cz",
                     "T3", "T5", "T4", "T6",
                     "P3", "P4", "Pz",
                     "O1", "O2"]
        out = region_average(data, ch_names)
        assert out.shape == (8, 7500)
        # Frontal should be average of first 7 channels
        expected_frontal = data[:7].mean(axis=0)
        np.testing.assert_allclose(out[0], expected_frontal, rtol=1e-5)

    def test_preprocess_3d_input(self):
        from neuroencoder.preprocessing import preprocess
        data = np.random.randn(2, 8, 7500).astype(np.float32)
        images = preprocess(data, sfreq=250, filter=False, device="cpu")
        assert images.shape == (2, 8, 224, 224)

    def test_preprocess_2d_input(self):
        from neuroencoder.preprocessing import preprocess
        # 60 seconds of 8-channel data at 250 Hz
        data = np.random.randn(8, 15000).astype(np.float32)
        # Default 1s stride from 60s: 31 windows
        images = preprocess(data, sfreq=250, filter=False, device="cpu")
        assert images.shape == (31, 8, 224, 224)

    def test_signal_condition(self):
        from neuroencoder.preprocessing import signal_condition
        data = np.random.randn(8, 25600).astype(np.float32)  # ~100s at 256 Hz
        out, sfreq = signal_condition(data, sfreq=256.0)
        assert sfreq == 250.0
        assert out.shape[0] == 8
        # Output should be approximately 25000 samples (100s * 250 Hz)
        assert abs(out.shape[1] - 25000) < 100


class TestModel:
    def test_hiera_forward(self):
        from neuroencoder.model import Hiera
        model = Hiera(in_chans=8)
        x = torch.randn(2, 8, 224, 224)
        with torch.no_grad():
            out = model(x)
        assert out.shape == (2, 768)

    def test_mrl_projector(self):
        from neuroencoder.model import MRLProjector
        proj = MRLProjector()
        x = torch.randn(4, 768)
        for dim in [768, 384, 192, 48, 16]:
            out = proj(x, dim=dim)
            assert out.shape == (4, dim)

    def test_mrl_predict(self):
        from neuroencoder import MRL
        model = MRL()
        x = torch.randn(2, 8, 224, 224)
        for dim in [768, 384, 192, 48, 16]:
            emb = model.predict(x, dim=dim)
            assert emb.shape == (2, dim)
            norms = emb.norm(dim=-1)
            torch.testing.assert_close(norms, torch.ones_like(norms), atol=1e-5, rtol=1e-5)

    def test_invalid_dim(self):
        from neuroencoder import MRL
        model = MRL()
        x = torch.randn(1, 8, 224, 224)
        with pytest.raises(ValueError):
            model.predict(x, dim=100)

    def test_param_count(self):
        from neuroencoder import MRL
        model = MRL()
        n_params = sum(p.numel() for p in model.parameters())
        # Hiera-Base ~51.5M + projector ~2.4M
        assert 50_000_000 < n_params < 60_000_000, f"Unexpected param count: {n_params:,}"

    def test_embed_oneliner_returns_numpy(self):
        from neuroencoder import MRL
        model = MRL()
        eeg = np.random.randn(8, 60 * 250).astype(np.float32)  # 60s, 8 ch, 250 Hz
        emb = model.embed(eeg, sfreq=250, dim=192, filter=False)
        assert isinstance(emb, np.ndarray)
        # Default 1s stride from 60s -> 31 windows; dim=192
        assert emb.shape == (31, 192)
        # L2-normalized
        norms = np.linalg.norm(emb, axis=-1)
        np.testing.assert_allclose(norms, 1.0, atol=1e-4)


class TestPlotting:
    def test_plot_time(self):
        import matplotlib
        matplotlib.use("Agg")
        from neuroencoder.plotting import plot
        embeddings = np.random.randn(100, 16).astype(np.float32)
        fig, ax = plot(embeddings, show=False)
        assert fig is not None

    def test_plot_cluster(self):
        import matplotlib
        matplotlib.use("Agg")
        from neuroencoder.plotting import plot
        embeddings = np.random.randn(100, 16).astype(np.float32)
        fig, ax = plot(embeddings, color="cluster", show=False)
        assert fig is not None

    def test_plot_custom_labels(self):
        import matplotlib
        matplotlib.use("Agg")
        from neuroencoder.plotting import plot
        embeddings = np.random.randn(50, 16).astype(np.float32)
        labels = np.array(["A"] * 25 + ["B"] * 25)
        fig, ax = plot(embeddings, color=labels, show=False)
        assert fig is not None

    def test_plot_return_umap(self):
        import matplotlib
        matplotlib.use("Agg")
        from neuroencoder.plotting import plot
        embeddings = np.random.randn(50, 16).astype(np.float32)
        fig, ax, coords = plot(embeddings, show=False, return_umap=True)
        assert coords.shape == (50, 2)


class TestTopLevelAPI:
    def test_imports(self):
        import neuroencoder as ne
        from neuroencoder import MRL, MRL_DIMS
        assert hasattr(ne, "preprocess")
        assert hasattr(ne, "plot")
        assert hasattr(ne, "explore")
        assert hasattr(ne, "serve")
        assert hasattr(ne, "TemporalMatrix")
        assert MRL_DIMS == [768, 384, 192, 48, 16]
        # Confirm we removed the convenience function in favour of MRL.predict
        assert not hasattr(ne, "predict")
        assert not hasattr(ne, "load_model")
        # EpiEmbedding alias is gone
        assert not hasattr(ne, "EpiEmbedding")

    def test_version(self):
        import neuroencoder as ne
        assert ne.__version__ == "1.0.0"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
