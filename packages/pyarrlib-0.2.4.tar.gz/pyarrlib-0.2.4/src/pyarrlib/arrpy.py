from ._checks import ArrayTypeError, check


def reverse_arr(array):
    check(array)
    return array[::-1]

def sum_arr(array):
    check(array)   
    res = 0
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else: res += i
    return res

def multiplication_arr(array):
    check(array)
    res = 1
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else:
            res *= i
    return res

def min(array):
    check(array)
    res = array[0]
    for i in array:
        if not isinstance(i, (int, float)):
            raise ArrayTypeError
        elif i < res:
            res = i
    return res

def max(array):
    check(array)
    res = array[0]
    for i in array:
        if not isinstance(i, (int, float)):
            raise ArrayTypeError
        if i > res:
            res = i 
    return res

def arifmetic_mean(array):
    check(array)
    s = sum_arr(array)
    return s / len(array)


def sort(array):
    check(array)
    def mi(array):
        min_indexes = []
        min_n = array[0]

        for i, n in enumerate(array):
            if n > min_n:
                continue
            elif n < min_n:
                min_indexes.clear()
                min_n = n
            min_indexes.append(i)

        return min_indexes, min_n

    tmp_lst = []

    while array:
        indexes, n = mi(array)
        for _ in range(len(indexes)):
            array.remove(n)
            tmp_lst.append(n)
    array[:] = tmp_lst

def same(array1, array2):
    check(array1)
    check(array2)
    s = set(array2)
    return [i for i in array1 if i in s]

def step_filter(array, step:int, first_num=0):
    check(array)
    return array[first_num::step]

def type_filter(array, type_filt:type):
    check(array)
    res = []
    types = [int, float, bool, str, list, tuple, dict, set, complex]
    if type_filt in types:
        types.remove(type_filt)
        t = tuple(types)
    else: raise TypeError
    for i in array:
        if not isinstance(i, t):
            res.append(i)
    return res

def range_arr(array, first:float |int, last:int|float):
    check(array)
    if first > last:
        return None
    res = []
    for i in array:
        if isinstance(i, (int, float)):
            if i >= first and i <= last:
                res.append(i)
    return res

def range_other(array, first, last):
    check(array)
    if first > last:
        return None
    res = []
    for i in array:
        if isinstance(i, (int, float)):
            if i <= first or i >= last:
                res.append(i)
    return res

def chunk(array, size):
    check(array)
    res = []
    a = []
    for i in range(0, len(array), size):
        res.append(array[i: i+size])
    return res

def mv(array, i1, i2):
    check(array)
    r = array[i1]
    array.remove(r)
    array.insert(i2, r)
    
def hw_times(array, key):
    check(array)
    res = 0
    for i in array:
        if i == key:
            res += 1
    return res

def not_same(array, array2):
    check(array)
    check(array2)
    big_arr = array + array2
    not_need = same(array, array2)
    for i in not_need:
        big_arr.remove(i)
        big_arr.pop()
    return big_arr