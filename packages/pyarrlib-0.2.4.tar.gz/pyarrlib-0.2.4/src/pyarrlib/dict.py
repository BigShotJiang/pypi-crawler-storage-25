from .arrpy import *

def dict_max(d: dict):
    values = list(d.values())      
    return max(*values)  

def dict_min(d: dict):
    values = list(d.values())
    return min(*values)

def is_key_value_in_dict(d:dict, key, value):
    return d.get(key) == value

def key_sum(d:dict):
    res = 0
    for i in d.values():
        if isinstance(i, (int, float)):
            res += i
    
    return res

def key_multiplication(d:dict):
    res = 1
    for i in d.values():
        if isinstance(i, (int, float)):
            res *= i
    
    return res

def same_keys(d1:dict, d2:dict):
    arr2 = [i for i in d2]
    arr1 = [i for i in d1]
    return set(arr1) & set(arr2)

def same_values(d1:dict, d2:dict):
    arr1 = [i for i in d1.values()]
    arr2 = [i for i in d2.values()]
    return set(arr1) & set(arr2)