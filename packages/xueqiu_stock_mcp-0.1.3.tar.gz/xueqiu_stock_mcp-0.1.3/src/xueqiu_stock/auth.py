"""雪球认证管理。

使用 Playwright 获取雪球 Cookie（含 JS 生成的 xq_a_token）。
首次调用自动获取，之后每 30 分钟刷新一次。
支持从现有 token 文件读取。
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path

logger = logging.getLogger(__name__)

_COOKIE_REFRESH_INTERVAL = 1800  # 30 分钟
_TOKEN_CACHE_PATH = Path.home() / ".qwenpaw" / "xueqiu_token.json"

# 反检测脚本
_STEALTH_JS = """
Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
Object.defineProperty(navigator, 'languages', {get: () => ['zh-CN', 'zh', 'en']});
delete navigator.__proto__.webdriver;
"""


class CookieManager:
    """线程安全的 Cookie 管理器。"""

    def __init__(self) -> None:
        self._cookies: dict[str, str] = {}
        self._expires_at: float = 0.0
        self._lock = asyncio.Lock()
        self._load_from_token_file()

    def _load_from_token_file(self) -> None:
        """从现有 token 文件加载 cookies。"""
        try:
            if _TOKEN_CACHE_PATH.exists():
                token_data = json.loads(_TOKEN_CACHE_PATH.read_text())
                xq_a_token = token_data.get("xq_a_token")
                if xq_a_token:
                    self._cookies = {"xq_a_token": xq_a_token}
                    self._expires_at = time.time() + _COOKIE_REFRESH_INTERVAL
                    logger.info("从 token 文件加载 Cookie 成功")
        except Exception:
            logger.warning("从 token 文件加载 Cookie 失败，将使用 Playwright 获取")

    @property
    def is_expired(self) -> bool:
        return time.time() >= self._expires_at

    def get_headers(self) -> dict[str, str]:
        """返回包含 Cookie 的请求头。"""
        cookie_str = "; ".join(f"{k}={v}" for k, v in self._cookies.items())
        return {
            "Accept": "application/json",
            "Origin": "https://xueqiu.com",
            "Referer": "https://xueqiu.com/",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
            "Cookie": cookie_str,
        }

    async def _fetch_cookies(self) -> None:
        """通过 Playwright 获取雪球 Cookie。"""
        logger.info("正在通过浏览器获取雪球 Cookie ...")
        try:
            from playwright.async_api import async_playwright
        except ImportError:
            raise RuntimeError(
                "缺少 playwright 依赖。请执行:\n"
                "  pip install playwright\n"
                "  python3 -m playwright install chromium"
            )

        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True,
                args=["--disable-blink-features=AutomationControlled"],
            )
            try:
                context = await browser.new_context(
                    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                               "AppleWebKit/537.36 (KHTML, like Gecko) "
                               "Chrome/120.0.0.0 Safari/537.36",
                    viewport={"width": 1920, "height": 1080},
                )
                page = await context.new_page()
                await page.add_init_script(_STEALTH_JS)
                await page.goto("https://xueqiu.com", wait_until="networkidle", timeout=30000)
                await page.wait_for_timeout(2000)

                cookies = await context.cookies()
                self._cookies = {c["name"]: c["value"] for c in cookies}
                self._expires_at = time.time() + _COOKIE_REFRESH_INTERVAL
                logger.info("Cookie 获取成功（%d 个）", len(self._cookies))
            finally:
                await browser.close()

    async def ensure_cookies(self) -> None:
        """确保 Cookie 有效，过期则自动刷新。"""
        if self._cookies and not self.is_expired:
            return
        async with self._lock:
            if self._cookies and not self.is_expired:
                return
            try:
                await self._fetch_cookies()
            except Exception:
                logger.exception("Cookie 获取失败")
                if not self._cookies:
                    raise

    async def refresh(self) -> None:
        """强制刷新 Cookie。"""
        async with self._lock:
            try:
                await self._fetch_cookies()
            except Exception:
                logger.exception("Cookie 刷新失败")


# ── 全局单例 ──────────────────────────────────────────────────────────────

_manager = CookieManager()


def get_manager() -> CookieManager:
    return _manager


async def ensure_cookies() -> None:
    await _manager.ensure_cookies()


async def refresh_cookies() -> None:
    await _manager.refresh()


def get_headers() -> dict[str, str]:
    return _manager.get_headers()
