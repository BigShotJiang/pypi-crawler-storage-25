"""MCP 工具定义与实现。

工具（5 个）：
    - get_stock_quote: 实时行情
    - get_kline_data: K 线 + 技术指标（含 KDJ、MA60）
    - get_minute_data: 分时数据
    - get_pankou_data: 五档盘口
    - get_financial: 财务数据（利润表/资产负债表/现金流量表）
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Any

import httpx

from .api import XueqiuAPIError, fetch_quote, fetch_kline, fetch_minute, _request, _raw_request
from .auth import get_headers, ensure_cookies
from .indicators import apply_indicators, _ALL_INDICATORS
from .rate_limiter import get_limiter
from .symbol import symbol_to_full

logger = logging.getLogger(__name__)

_CST = timezone(timedelta(hours=8))

# ── 合法 period / indicator 列表 ─────────────────────────────────────────

_VALID_PERIODS = {"1m", "5m", "15m", "30m", "60m", "120m", "day", "week", "month"}
_VALID_INDICATORS = _ALL_INDICATORS  # MA, MACD, RSI, BOLL, KDJ


# ── 财务报表字段映射（API field → 中文名）────────────────────────────────

_INCOME_FIELDS = {
    "total_revenue": "营业总收入",
    "revenue": "营业收入",
    "operating_costs": "营业总成本",
    "operating_cost": "营业成本",
    "sales_fee": "销售费用",
    "manage_fee": "管理费用",
    "financing_expenses": "财务费用",
    "rad_cost": "研发费用",
    "op": "营业利润",
    "profit_total_amt": "利润总额",
    "income_tax_expenses": "所得税费用",
    "net_profit": "净利润",
    "net_profit_atsopc": "归属母公司净利润",
    "net_profit_after_nrgal_atsolc": "扣非净利润",
    "basic_eps": "基本每股收益",
    "dlt_earnings_per_share": "稀释每股收益",
    "total_compre_income": "综合收益总额",
    "total_compre_income_atsopc": "归属母公司综合收益",
    "minority_gal": "少数股东损益",
    "other_income": "其他收益",
    "invest_income": "投资收益",
    "asset_impairment_loss": "资产减值损失",
    "credit_impairment_loss": "信用减值损失",
    "non_operating_income": "营业外收入",
    "non_operating_payout": "营业外支出",
    "operating_taxes_and_surcharge": "营业税金及附加",
    "income_from_chg_in_fv": "公允价值变动收益",
    "exchg_gain": "汇兑收益",
    "asset_disposal_income": "资产处置收益",
}

_BALANCE_FIELDS = {
    "total_assets": "总资产",
    "total_liab": "总负债",
    "asset_liab_ratio": "资产负债率",
    "total_holders_equity": "股东权益合计",
    "total_quity_atsopc": "归属母公司股东权益",
    "minority_equity": "少数股东权益",
    "currency_funds": "货币资金",
    "account_receivable": "应收账款",
    "pre_payment": "预付款项",
    "inventory": "存货",
    "fixed_asset": "固定资产",
    "intangible_assets": "无形资产",
    "goodwill": "商誉",
    "construction_in_process": "在建工程",
    "invest_property": "投资性房地产",
    "lt_equity_invest": "长期股权投资",
    "tradable_fnncl_assets": "交易性金融资产",
    "bills_receivable": "应收票据",
    "othr_receivable": "其他应收款",
    "dt_assets": "递延所得税资产",
    "shares": "股本",
    "capital_reserve": "资本公积",
    "earned_surplus": "盈余公积",
    "undstrbtd_profit": "未分配利润",
    "bond_payable": "应付债券",
    "lt_borrow": "长期借款",
    "st_borrow": "短期借款",
    "account_payable": "应付账款",
    "bills_payable": "应付票据",
    "tax_payable": "应交税费",
    "payroll_payable": "应付职工薪酬",
    "dividend_payable": "应付股利",
    "dt_liab": "递延所得税负债",
    "estimated_liab": "预计负债",
}

# 现金流量表 — 使用雪球 API 实际返回的字段名
_CASHFLOW_FIELDS = {
    # 经营活动
    "ncf_from_oa": "经营活动现金流量净额",
    "sub_total_of_ci_from_oa": "经营活动现金流入小计",
    "sub_total_of_cos_from_oa": "经营活动现金流出小计",
    "cash_paid_to_employee_etc": "支付给职工的现金",
    "payments_of_all_taxes": "支付的各项税费",
    "cash_received_of_othr_oa": "收到其他与经营活动有关的现金",
    "othrcash_paid_relating_to_oa": "支付其他与经营活动有关的现金",
    # 投资活动
    "ncf_from_ia": "投资活动现金流量净额",
    "sub_total_of_ci_from_ia": "投资活动现金流入小计",
    "sub_total_of_cos_from_ia": "投资活动现金流出小计",
    "cash_received_of_dspsl_invest": "收回投资收到的现金",
    "invest_income_cash_received": "取得投资收益收到的现金",
    "net_cash_of_disposal_assets": "处置固定资产收回的现金净额",
    "cash_received_of_othr_ia": "收到其他与投资活动有关的现金",
    "invest_paid_cash": "投资支付的现金",
    "cash_paid_for_assets": "购建固定资产支付的现金",
    "othrcash_paid_relating_to_ia": "支付其他与投资活动有关的现金",
    # 筹资活动
    "ncf_from_fa": "筹资活动现金流量净额",
    "sub_total_of_ci_from_fa": "筹资活动现金流入小计",
    "sub_total_of_cos_from_fa": "筹资活动现金流出小计",
    "cash_received_of_invest": "吸收投资收到的现金",
    "cash_received_of_borrow": "取得借款收到的现金",
    "othrcash_received_relating_to_fa": "收到其他与筹资活动有关的现金",
    "cash_paid_for_debt": "偿还债务支付的现金",
    "dividend_interest_paid": "分配股利、利润或偿付利息支付的现金",
    "othrcash_paid_relating_to_fa": "支付其他与筹资活动有关的现金",
    # 汇率及汇总
    "eff_of_exchg_chg_on_cce": "汇率变动对现金的影响",
    "ncce_and_cce": "现金及现金等价物净增加额",
    "cce_at_begin": "期初现金及现金等价物余额",
    "cce_at_end": "期末现金及现金等价物余额",
}


def _fmt_value(val: Any) -> Any:
    """格式化单个数值：大数转亿/万，保留合理精度。"""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        if abs(val) >= 1e8:
            return round(val / 1e8, 2)  # 亿元
        elif abs(val) >= 1e4:
            return round(val / 1e4, 2)  # 万元
        elif abs(val) >= 1:
            return round(val, 2)
        else:
            return round(val, 4)
    return val


def _fmt_yoy(val: Any) -> Any:
    """同比变化（小数 → 百分比字符串）。"""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return f"{val * 100:+.2f}%"
    return val


def _parse_finance_report(report: dict, field_map: dict) -> dict:
    """解析单期财务报告。

    雪球返回格式：每个字段值为 [absolute_value, yoy_change]。
    只保留字段映射中定义的字段，过滤掉 None 值字段以节省 token。
    """
    result = {
        "report_date": datetime.fromtimestamp(
            report.get("report_date", 0) / 1000, tz=_CST
        ).strftime("%Y-%m-%d"),
        "report_name": report.get("report_name", ""),
    }

    for field_key, cn_name in field_map.items():
        raw = report.get(field_key)
        if raw is None:
            continue
        if isinstance(raw, list):
            val = raw[0] if len(raw) >= 1 else None
            yoy = raw[1] if len(raw) >= 2 else None
            if val is not None:
                result[cn_name] = _fmt_value(val)
            if yoy is not None:
                result[f"{cn_name}_同比"] = _fmt_yoy(yoy)
        elif isinstance(raw, (int, float)):
            result[cn_name] = _fmt_value(raw)

    return result


# ── 工具实现 ──────────────────────────────────────────────────────────────


async def tool_get_stock_quote(symbols: str) -> str:
    """获取单只或多只股票的实时行情信息。"""
    if not symbols or not symbols.strip():
        return json.dumps(
            {"error": "symbols 参数不能为空，请提供股票代码"},
            ensure_ascii=False,
        )

    try:
        quotes = await fetch_quote(symbols)
        return json.dumps(quotes, ensure_ascii=False, indent=2)
    except XueqiuAPIError as e:
        return json.dumps(e.to_dict(), ensure_ascii=False)
    except Exception as e:
        logger.exception("get_stock_quote 异常")
        return json.dumps(
            {"error_code": "INTERNAL", "message": str(e), "suggested_action": "请稍后重试"},
            ensure_ascii=False,
        )


async def tool_get_kline_data(
    symbol: str,
    period: str = "day",
    count: int = -60,
    indicators: list[str] | None = None,
) -> str:
    """获取股票 K 线数据并附带技术指标。

    优化策略：
    - 默认只计算 MA，不计算 MACD/RSI/BOLL/KDJ（节省 50%+ token）
    - 过滤掉全为 None 的指标字段
    - count 上限 120（默认 -60）
    """
    if not symbol or not symbol.strip():
        return json.dumps({"error": "symbol 参数不能为空"}, ensure_ascii=False)

    if period not in _VALID_PERIODS:
        return json.dumps(
            {
                "error_code": "INVALID_PERIOD",
                "message": f"不支持的 K 线周期 '{period}'",
                "suggested_action": f"可选值：{', '.join(sorted(_VALID_PERIODS))}",
            },
            ensure_ascii=False,
        )

    # 限制 count 范围
    if count < -120 or count > 120:
        return json.dumps(
            {
                "error_code": "COUNT_OUT_OF_RANGE",
                "message": f"count 参数 {count} 超出范围",
                "suggested_action": "count 范围为 -120 到 120",
            },
            ensure_ascii=False,
        )

    if indicators is None:
        indicators = ["MA"]  # 默认只算 MA

    invalid_ind = [i for i in indicators if i.upper() not in _VALID_INDICATORS]
    if invalid_ind:
        return json.dumps(
            {
                "error_code": "INVALID_INDICATOR",
                "message": f"不支持的技术指标：{', '.join(invalid_ind)}",
                "suggested_action": f"可选值：{', '.join(sorted(_VALID_INDICATORS))}",
            },
            ensure_ascii=False,
        )

    try:
        full = symbol_to_full(symbol)
        klines = await fetch_kline(full, period, count)
        klines = apply_indicators(klines, indicators)

        # 清理：移除全为 None 的指标字段和无用字段
        cleaned = []
        for k in klines:
            cleaned_k = {}
            for fk, fv in k.items():
                # 跳过始终为 None 的后复权字段
                if fk in ("volume_post", "amount_post"):
                    continue
                # 跳过 None 值的指标字段
                if fv is None and fk.startswith(("ma", "macd_", "rsi_", "boll_", "kdj_")):
                    continue
                cleaned_k[fk] = fv
            cleaned.append(cleaned_k)

        return json.dumps(
            {"symbol": full, "period": period, "count": len(cleaned), "klines": cleaned},
            ensure_ascii=False,
            indent=2,
        )
    except XueqiuAPIError as e:
        return json.dumps(e.to_dict(), ensure_ascii=False)
    except Exception as e:
        logger.exception("get_kline_data 异常")
        return json.dumps(
            {"error_code": "INTERNAL", "message": str(e), "suggested_action": "请稍后重试"},
            ensure_ascii=False,
        )


async def tool_get_minute_data(symbol: str, period: str = "1d") -> str:
    """获取股票分时数据。"""
    if not symbol or not symbol.strip():
        return json.dumps({"error": "symbol 参数不能为空"}, ensure_ascii=False)

    if period not in ("1d", "5d"):
        return json.dumps(
            {
                "error_code": "INVALID_PERIOD",
                "message": f"分时周期 '{period}' 不支持",
                "suggested_action": "可选值：1d, 5d",
            },
            ensure_ascii=False,
        )

    try:
        full = symbol_to_full(symbol)
        data = await fetch_minute(full, period)

        # 精简分时数据：只保留核心字段
        items = data.get("items", [])
        cleaned_items = []
        for item in items:
            cleaned_items.append({
                "t": item.get("timestamp"),
                "p": item.get("current"),
                "v": item.get("volume"),
                "a": item.get("avg_price"),
                "chg": item.get("chg"),
                "pct": item.get("percent"),
            })

        return json.dumps(
            {
                "symbol": full,
                "last_close": data.get("last_close"),
                "items": cleaned_items,
            },
            ensure_ascii=False,
            indent=2,
        )
    except XueqiuAPIError as e:
        return json.dumps(e.to_dict(), ensure_ascii=False)
    except Exception as e:
        logger.exception("get_minute_data 异常")
        return json.dumps(
            {"error_code": "INTERNAL", "message": str(e), "suggested_action": "请稍后重试"},
            ensure_ascii=False,
        )


async def tool_get_pankou_data(symbol: str) -> str:
    """获取股票五档盘口数据。"""
    if not symbol or not symbol.strip():
        return json.dumps({"error": "symbol 参数不能为空"}, ensure_ascii=False)

    try:
        full = symbol_to_full(symbol)

        resp = await _request("/stock/realtime/pankou.json", {"symbol": full}, symbol=full)
        data = resp.get("data", resp)

        buys = []
        for i in range(1, 6):
            price = data.get(f"bp{i}")
            volume = data.get(f"bc{i}")
            if price is not None:
                buys.append({"price": price, "volume": volume})

        sells = []
        for i in range(1, 6):
            price = data.get(f"sp{i}")
            volume = data.get(f"sc{i}")
            if price is not None:
                sells.append({"price": price, "volume": volume})

        result = {
            "symbol": full,
            "current": data.get("current"),
            "buys": buys,
            "sells": sells,
            "buy_percent": data.get("buypct"),
            "sell_percent": data.get("sellpct"),
            "net_diff": data.get("diff"),
            "pankou_ratio": data.get("ratio"),
        }

        return json.dumps(result, ensure_ascii=False, indent=2)

    except XueqiuAPIError as e:
        return json.dumps(e.to_dict(), ensure_ascii=False)
    except Exception as e:
        logger.exception("get_pankou_data 异常")
        return json.dumps(
            {"error_code": "INTERNAL", "message": str(e), "suggested_action": "请稍后重试"},
            ensure_ascii=False,
        )


async def tool_get_financial(
    symbol: str,
    report_type: str = "income",
    count: int = 5,
) -> str:
    """获取公司财务报表数据（利润表/资产负债表/现金流量表）。

    优化策略：
    - 只保留有数据的字段，过滤 None 值
    - 每个字段只返回当期值 + 同比，不重复
    - 默认 3 期（减少 token 消耗）
    """
    if not symbol or not symbol.strip():
        return json.dumps({"error": "symbol 参数不能为空"}, ensure_ascii=False)

    VALID_TYPES = {"income", "balance", "cash_flow"}
    if report_type not in VALID_TYPES:
        return json.dumps(
            {
                "error_code": "INVALID_TYPE",
                "message": f"不支持的报表类型 '{report_type}'",
                "suggested_action": "可选值：income（利润表）、balance（资产负债表）、cash_flow（现金流量表）",
            },
            ensure_ascii=False,
        )

    if count < 1 or count > 10:
        return json.dumps(
            {
                "error_code": "INVALID_COUNT",
                "message": f"count 参数 {count} 超出范围",
                "suggested_action": "count 范围为 1-10",
            },
            ensure_ascii=False,
        )

    try:
        full = symbol_to_full(symbol)

        endpoint_map = {
            "income": "/v5/stock/finance/cn/income.json",
            "balance": "/v5/stock/finance/cn/balance.json",
            "cash_flow": "/v5/stock/finance/cn/cash_flow.json",
        }

        field_map = {
            "income": _INCOME_FIELDS,
            "balance": _BALANCE_FIELDS,
            "cash_flow": _CASHFLOW_FIELDS,
        }

        type_names = {
            "income": "利润表",
            "balance": "资产负债表",
            "cash_flow": "现金流量表",
        }

        endpoint = endpoint_map[report_type]
        params = {
            "symbol": full,
            "type": "all",
            "is_detail": "true",
            "count": str(count),
        }

        url = f"https://stock.xueqiu.com{endpoint}"
        resp = await _raw_request(url, params, symbol=full)
        raw = resp.json()

        data = raw.get("data", {})
        reports_raw = data.get("list", [])

        reports = []
        for r in reports_raw:
            reports.append(_parse_finance_report(r, field_map[report_type]))

        result = {
            "symbol": full,
            "type": type_names[report_type],
            "company": data.get("quote_name", ""),
            "reports": reports,
        }

        return json.dumps(result, ensure_ascii=False, indent=2)

    except httpx.HTTPStatusError as e:
        return json.dumps(
            {"error_code": f"HTTP_{e.response.status_code}", "message": str(e)},
            ensure_ascii=False,
        )
    except XueqiuAPIError as e:
        return json.dumps(e.to_dict(), ensure_ascii=False)
    except Exception as e:
        logger.exception("get_financial 异常")
        return json.dumps(
            {"error_code": "INTERNAL", "message": str(e), "suggested_action": "请稍后重试"},
            ensure_ascii=False,
        )
