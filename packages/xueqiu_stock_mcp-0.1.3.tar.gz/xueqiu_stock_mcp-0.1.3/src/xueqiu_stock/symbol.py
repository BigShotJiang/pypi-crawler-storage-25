"""股票代码解析：短代码 ↔ 完整代码（含交易所前缀）。

规则:
    600/601/603/605  → SH（沪市主板）
    000/001/002/003  → SZ（深市主板）
    300/301          → SZ（创业板）
    688/689          → SH（科创板）
    830–839/870–873  → BJ（北交所）

已含前缀的完整代码原样返回。
"""

from __future__ import annotations

# ── 前缀 → 交易所映射表 ──────────────────────────────────────────────────

_PREFIX_MAP: dict[str, str] = {
    # 沪市主板
    "600": "SH", "601": "SH", "603": "SH", "605": "SH",
    # 深市主板
    "000": "SZ", "001": "SZ", "002": "SZ", "003": "SZ",
    # 创业板
    "300": "SZ", "301": "SZ",
    # 科创板
    "688": "SH", "689": "SH",
}

# 北交所：830-839, 870-873
_BJ_PREFIXES = (
    [f"83{i}" for i in range(10)]   # 830-839
    + [f"87{i}" for i in range(4)]  # 870-873
)
for _p in _BJ_PREFIXES:
    _PREFIX_MAP[_p] = "BJ"

# 已知交易所前缀
_KNOWN_EXCHANGES = {"SH", "SZ", "BJ", "HK", "US"}


def symbol_to_full(code: str) -> str:
    """将股票短代码转换为完整代码。

    Args:
        code: 股票代码，如 '600160'、'SH600160'、'000001'

    Returns:
        完整代码，如 'SH600160'

    Raises:
        ValueError: 代码格式无效或无法推断交易所
    """
    code = code.strip().upper()

    # 已经是完整代码（带交易所前缀）
    if len(code) > 6 and code[:2] in _KNOWN_EXCHANGES:
        return code

    # 纯数字代码
    if code.isdigit() and len(code) == 6:
        prefix = code[:3]
        exchange = _PREFIX_MAP.get(prefix)
        if exchange:
            return f"{exchange}{code}"
        raise ValueError(
            f"无法推断股票代码 {code} 的交易所。"
            f"请使用完整代码，如 SH600160 或 SZ000001。"
        )

    raise ValueError(
        f"无效的股票代码格式：'{code}'。"
        f"正确格式：600160（沪市）或 000001（深市）或 SH600160。"
    )


def is_valid_symbol(code: str) -> bool:
    """检查股票代码是否有效。"""
    try:
        symbol_to_full(code)
        return True
    except ValueError:
        return False
