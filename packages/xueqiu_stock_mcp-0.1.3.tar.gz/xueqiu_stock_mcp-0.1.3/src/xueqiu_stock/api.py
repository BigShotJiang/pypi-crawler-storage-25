"""雪球 API 封装层。

统一处理：Cookie 注入、限流、重试、错误结构化。
新增 _raw_request：给 financial 等需要自定义解析的工具用。
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Any

import httpx

from .auth import get_manager, refresh_cookies
from .rate_limiter import get_limiter
from .symbol import symbol_to_full

logger = logging.getLogger(__name__)

_API_BASE = "https://stock.xueqiu.com/v5"
_MAX_RETRIES = 2
_CST = timezone(timedelta(hours=8))

# 共享 httpx 客户端（连接复用）
_http_client: httpx.AsyncClient | None = None


def _get_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.AsyncClient(
            timeout=15.0,
            limits=httpx.Limits(
                max_connections=20,
                max_keepalive_connections=10,
                keepalive_expiry=30,
            ),
        )
    return _http_client


# ── 错误类 ────────────────────────────────────────────────────────────────


class XueqiuAPIError(Exception):
    """结构化 API 错误。"""

    def __init__(
        self,
        error_code: int | str,
        message: str,
        suggested_action: str = "",
    ) -> None:
        self.error_code = error_code
        self.message = message
        self.suggested_action = suggested_action
        super().__init__(f"[{error_code}] {message}")

    def to_dict(self) -> dict[str, str]:
        return {
            "error_code": str(self.error_code),
            "message": self.message,
            "suggested_action": self.suggested_action,
        }


# ── 底层请求（带限流+重试+Cookie 自动刷新）────────────────────────────


async def _raw_request(
    url: str,
    params: dict[str, Any],
    symbol: str = "",
) -> httpx.Response:
    """发送 HTTP 请求，自动注入 Cookie、限流、重试。

    返回 httpx.Response 对象，由调用方解析。
    适用于 financial 等需要自定义解析的场景。
    """
    limiter = get_limiter()
    manager = get_manager()

    last_error: Exception | None = None
    for attempt in range(1, _MAX_RETRIES + 1):
        await limiter.acquire(symbol)
        headers = manager.get_headers()

        try:
            client = _get_client()
            resp = await client.get(url, params=params, headers=headers)

            if resp.status_code == 403:
                logger.warning("API 403，刷新 Cookie 重试 (%d/%d)", attempt, _MAX_RETRIES)
                await refresh_cookies()
                continue

            # 检查 JSON 错误码
            try:
                data = resp.json()
                error_code = data.get("error_code", 0)
            except Exception:
                # 非 JSON 响应（如 WAF HTML），直接返回
                return resp

            if error_code == "400016":
                logger.warning("Cookie 过期 (400016)，刷新重试 (%d/%d)", attempt, _MAX_RETRIES)
                await refresh_cookies()
                continue

            if error_code and error_code != 0:
                raise XueqiuAPIError(
                    error_code=error_code,
                    message=data.get("error_description", "未知错误"),
                    suggested_action="请检查股票代码是否正确，或稍后重试",
                )

            return resp

        except httpx.TimeoutException as e:
            last_error = e
            logger.warning("请求超时 (%d/%d): %s", attempt, _MAX_RETRIES, e)
            if attempt == _MAX_RETRIES:
                raise XueqiuAPIError(
                    error_code="TIMEOUT",
                    message=f"请求超时（15秒）",
                    suggested_action="请检查网络连接，或稍后重试",
                ) from e

        except httpx.HTTPStatusError as e:
            last_error = e
            logger.warning("HTTP 错误 %s (%d/%d)", e, attempt, _MAX_RETRIES)
            if attempt == _MAX_RETRIES:
                raise XueqiuAPIError(
                    error_code="HTTP_" + str(e.response.status_code),
                    message=f"HTTP 请求失败：{e.response.status_code}",
                    suggested_action="请检查网络连接，或稍后重试",
                ) from e
            await refresh_cookies()

        except httpx.HTTPError as e:
            last_error = e
            logger.warning("网络错误 (%d/%d): %s", attempt, _MAX_RETRIES, e)
            if attempt == _MAX_RETRIES:
                raise XueqiuAPIError(
                    error_code="NETWORK_ERROR",
                    message=f"网络请求失败：{e}",
                    suggested_action="请检查网络连接，或稍后重试",
                ) from e

    raise XueqiuAPIError(
        error_code="RETRY_EXHAUSTED",
        message="重试次数已用完",
        suggested_action="请稍后重试",
    )


async def _request(
    path: str,
    params: dict[str, Any],
    symbol: str = "",
) -> dict[str, Any]:
    """发送 API 请求并返回 JSON data 字段。"""
    url = f"{_API_BASE}{path}"
    resp = await _raw_request(url, params, symbol)
    return resp.json()


# ── 数据解析 ──────────────────────────────────────────────────────────────


def _parse_quote(data: dict[str, Any]) -> dict[str, Any]:
    """解析实时行情数据。"""
    q = data.get("data", data)
    quote = q.get("quote", q)
    return {
        "symbol": quote.get("symbol"),
        "name": quote.get("name"),
        "current": quote.get("current"),
        "percent": quote.get("percent"),
        "chg": quote.get("chg"),
        "open": quote.get("open"),
        "high": quote.get("high"),
        "low": quote.get("low"),
        "last_close": quote.get("last_close"),
        "volume": quote.get("volume"),
        "amount": quote.get("amount"),
        "turnover_rate": quote.get("turnover_rate"),
        "amplitude": quote.get("amplitude"),
        "volume_ratio": quote.get("volume_ratio"),
        "pe_ttm": quote.get("pe_ttm"),
        "pe_lyr": quote.get("pe_lyr"),
        "pb": quote.get("pb"),
        "market_capital": quote.get("market_capital"),
        "float_market_capital": quote.get("float_market_capital"),
        "total_shares": quote.get("total_shares"),
        "float_shares": quote.get("float_shares"),
        "eps": quote.get("eps"),
        "navps": quote.get("navps"),
        "dividend": quote.get("dividend"),
        "dividend_yield": quote.get("dividend_yield"),
        "high52w": quote.get("high52w"),
        "low52w": quote.get("low52w"),
        "limit_up": quote.get("limit_up"),
        "limit_down": quote.get("limit_down"),
        "currency": quote.get("currency"),
        "market_status": quote.get("market_status"),
        "timestamp": quote.get("timestamp"),
    }


def _parse_klines(data: dict[str, Any]) -> list[dict[str, Any]]:
    """解析 K 线原始数据。"""
    items = data.get("data", data).get("item", [])
    columns = data.get("data", data).get("column", [])
    if not columns:
        columns = ["timestamp", "volume", "open", "high", "low", "close",
                    "chg", "percent", "turnoverrate", "amount",
                    "volume_post", "amount_post"]

    klines = []
    for row in items:
        if isinstance(row, dict):
            klines.append(row)
        elif isinstance(row, list):
            klines.append(dict(zip(columns, row)))

    # 添加可读日期
    for k in klines:
        ts = k.get("timestamp")
        if ts:
            k["date"] = datetime.fromtimestamp(ts / 1000, tz=_CST).strftime("%Y-%m-%d")

    return klines


# ── 公开接口 ──────────────────────────────────────────────────────────────


async def fetch_quote(symbols: str) -> list[dict[str, Any]]:
    """获取实时行情。symbols: 逗号分隔的股票代码。"""
    code_list = [s.strip() for s in symbols.split(",") if s.strip()]
    full_codes = []
    for c in code_list:
        try:
            full_codes.append(symbol_to_full(c))
        except ValueError as e:
            raise XueqiuAPIError(
                error_code="INVALID_SYMBOL",
                message=f"股票代码 {c} 无效：{e}",
                suggested_action="请检查代码格式，如 600160 或 SH600160",
            ) from e

    results = []
    for code in full_codes:
        data = await _request("/stock/quote.json", {"symbol": code, "extend": "detail"}, symbol=code)
        results.append(_parse_quote(data))
    return results


async def fetch_kline(
    symbol: str,
    period: str = "day",
    count: int = -60,
) -> list[dict[str, Any]]:
    """获取 K 线原始数据。"""
    full = symbol_to_full(symbol)
    data = await _request(
        "/stock/chart/kline.json",
        {
            "symbol": full,
            "begin": str(int(datetime.now(tz=_CST).timestamp() * 1000)),
            "period": period,
            "type": "before",
            "count": str(count),
        },
        symbol=full,
    )
    return _parse_klines(data)


async def fetch_minute(
    symbol: str,
    period: str = "1d",
) -> dict[str, Any]:
    """获取分时数据。"""
    full = symbol_to_full(symbol)
    resp = await _request(
        "/stock/chart/minute.json",
        {"symbol": full, "period": period},
        symbol=full,
    )
    return resp.get("data", resp)
