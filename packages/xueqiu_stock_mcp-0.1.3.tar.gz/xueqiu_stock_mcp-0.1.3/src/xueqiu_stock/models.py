"""Pydantic 数据模型定义。"""

from __future__ import annotations

from pydantic import BaseModel, Field


# ── 股票行情 ──────────────────────────────────────────────────────────────


class StockQuote(BaseModel):
    """单只股票的实时行情快照。"""

    symbol: str = Field(description="完整股票代码，如 SH600160")
    name: str = Field(description="股票名称")
    current: float = Field(description="当前价格")
    percent: float = Field(description="涨跌幅 (%)")
    chg: float = Field(description="涨跌额")
    open: float = Field(description="开盘价")
    high: float = Field(description="最高价")
    low: float = Field(description="最低价")
    last_close: float = Field(description="昨收价")
    volume: int = Field(description="成交量（股）")
    amount: float = Field(description="成交额（元）")
    turnover_rate: float = Field(description="换手率 (%)")
    amplitude: float = Field(description="振幅 (%)")
    volume_ratio: float | None = Field(default=None, description="量比")
    pe_ttm: float | None = Field(default=None, description="PE (TTM)")
    pe_lyr: float | None = Field(default=None, description="PE (LYR)")
    pb: float | None = Field(default=None, description="PB")
    market_capital: float = Field(description="总市值（元）")
    float_market_capital: float = Field(description="流通市值（元）")
    total_shares: int = Field(description="总股本")
    float_shares: int = Field(description="流通股本")
    eps: float | None = Field(default=None, description="每股收益")
    navps: float | None = Field(default=None, description="每股净资产")
    dividend: float | None = Field(default=None, description="每股股息")
    dividend_yield: float | None = Field(default=None, description="股息率 (%)")
    high52w: float = Field(description="52 周最高")
    low52w: float = Field(description="52 周最低")
    limit_up: float | None = Field(default=None, description="涨停价")
    limit_down: float | None = Field(default=None, description="跌停价")
    currency: str = Field(default="CNY", description="货币")
    market_status: str = Field(description="市场状态（已收盘/交易中等）")
    timestamp: int = Field(description="数据时间戳（毫秒）")


# ── K 线 ──────────────────────────────────────────────────────────────────


class KlineBar(BaseModel):
    """单根 K 线数据。"""

    timestamp: int = Field(description="时间戳（毫秒）")
    date: str = Field(description="日期字符串")
    open: float
    high: float
    low: float
    close: float
    volume: int
    amount: float
    chg: float = Field(description="涨跌额")
    percent: float = Field(description="涨跌幅 (%)")
    turnover_rate: float = Field(description="换手率 (%)")

    # 技术指标（可选，按需填充）
    ma5: float | None = Field(default=None, description="5 日均线")
    ma10: float | None = Field(default=None, description="10 日均线")
    ma20: float | None = Field(default=None, description="20 日均线")
    macd_dif: float | None = Field(default=None, description="MACD DIF")
    macd_dea: float | None = Field(default=None, description="MACD DEA")
    macd_hist: float | None = Field(default=None, description="MACD 柱状图")
    rsi_6: float | None = Field(default=None, description="RSI(6)")
    rsi_12: float | None = Field(default=None, description="RSI(12)")
    rsi_24: float | None = Field(default=None, description="RSI(24)")
    boll_upper: float | None = Field(default=None, description="布林带上轨")
    boll_middle: float | None = Field(default=None, description="布林带中轨")
    boll_lower: float | None = Field(default=None, description="布林带下轨")


class KlineResult(BaseModel):
    """K 线查询结果。"""

    symbol: str
    period: str
    klines: list[KlineBar]


# ── 分时 ──────────────────────────────────────────────────────────────────


class MinutePoint(BaseModel):
    """单个分时数据点。"""

    timestamp: int = Field(description="时间戳（毫秒）")
    time: str = Field(description="时间 HH:mm")
    current: float = Field(description="当前价格")
    avg_price: float = Field(description="均价")
    volume: int = Field(description="成交量")
    percent: float = Field(description="涨跌幅 (%)")


class MinuteResult(BaseModel):
    """分时数据查询结果。"""

    symbol: str
    name: str
    percent: float
    chg: float
    current: float
    open: float
    high: float
    low: float
    last_close: float
    volume: int
    amount: float
    market_status: str
    minutes: list[MinutePoint]
