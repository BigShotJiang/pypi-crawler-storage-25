"""技术指标计算模块。

实现：MA、MACD、RSI、BOLL、KDJ。
纯 Python 实现，无外部依赖。
"""

from __future__ import annotations

from typing import Any


# ── MA（简单移动平均）─────────────────────────────────────────────────────


def calc_ma(values: list[float | None], period: int) -> list[float | None]:
    """计算简单移动平均线。前 period-1 个为 None。"""
    result: list[float | None] = []
    for i, v in enumerate(values):
        if i < period - 1:
            result.append(None)
        else:
            s = 0.0
            cnt = 0
            for j in range(i - period + 1, i + 1):
                if values[j] is not None:
                    s += values[j]
                    cnt += 1
            result.append(round(s / cnt, 4) if cnt == period else None)
    return result


# ── SMA（递归平滑，KDJ 用）───────────────────────────────────────────────


def _sma(values: list[float | None], period: int, weight: int = 3) -> list[float | None]:
    """计算 SMA（加权递归平滑）。
    SMA(X, N, M) = (M * X + (N - M) * prev) / N
    """
    result: list[float | None] = []
    prev: float | None = None
    for v in values:
        if v is None:
            result.append(None)
            continue
        if prev is None:
            prev = v
            result.append(round(prev, 4))
        else:
            prev = (weight * v + (period - weight) * prev) / period
            result.append(round(prev, 4))
    return result


# ── EMA（指数移动平均）────────────────────────────────────────────────────


def _ema(values: list[float | None], period: int) -> list[float | None]:
    """计算 EMA。"""
    result: list[float | None] = []
    multiplier = 2.0 / (period + 1)
    prev: float | None = None

    for i, v in enumerate(values):
        if v is None:
            result.append(None)
            continue
        if prev is None:
            if i >= period - 1:
                s = 0.0
                cnt = 0
                for j in range(i - period + 1, i + 1):
                    if values[j] is not None:
                        s += values[j]
                        cnt += 1
                if cnt == period:
                    prev = s / period
                    result.append(round(prev, 4))
                else:
                    result.append(None)
            else:
                result.append(None)
        else:
            prev = v * multiplier + prev * (1 - multiplier)
            result.append(round(prev, 4))

    return result


# ── MACD ──────────────────────────────────────────────────────────────────


def calc_macd(
    closes: list[float | None],
    fast: int = 12,
    slow: int = 26,
    signal: int = 9,
) -> dict[str, list[float | None]]:
    """计算 MACD(12,26,9)。"""
    ema_fast = _ema(closes, fast)
    ema_slow = _ema(closes, slow)

    dif: list[float | None] = []
    for f, s in zip(ema_fast, ema_slow):
        if f is not None and s is not None:
            dif.append(round(f - s, 4))
        else:
            dif.append(None)

    dea = _ema(dif, signal)

    histogram: list[float | None] = []
    for d, e in zip(dif, dea):
        if d is not None and e is not None:
            histogram.append(round((d - e) * 2, 4))
        else:
            histogram.append(None)

    return {"dif": dif, "dea": dea, "histogram": histogram}


# ── RSI（Wilder 平滑）─────────────────────────────────────────────────────


def calc_rsi(
    closes: list[float | None],
    period: int,
) -> list[float | None]:
    """计算 RSI。范围 0-100。"""
    result: list[float | None] = [None] * len(closes)

    valid_closes = [(i, c) for i, c in enumerate(closes) if c is not None]
    if len(valid_closes) < period + 1:
        return result

    gains: list[float] = []
    losses: list[float] = []
    for i in range(1, len(valid_closes)):
        _, curr = valid_closes[i]
        _, prev = valid_closes[i - 1]
        diff = curr - prev
        gains.append(max(diff, 0))
        losses.append(max(-diff, 0))

    if len(gains) < period:
        return result

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    first_idx = valid_closes[period][0]
    if avg_loss == 0:
        result[first_idx] = 100.0
    else:
        rs = avg_gain / avg_loss
        result[first_idx] = round(100 - 100 / (1 + rs), 2)

    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        idx = valid_closes[i + 1][0]
        if avg_loss == 0:
            result[idx] = 100.0
        else:
            rs = avg_gain / avg_loss
            result[idx] = round(100 - 100 / (1 + rs), 2)

    return result


# ── BOLL（布林带）─────────────────────────────────────────────────────────


def calc_boll(
    closes: list[float | None],
    period: int = 20,
    multiplier: float = 2.0,
) -> dict[str, list[float | None]]:
    """计算布林带(20,2)。"""
    middle = calc_ma(closes, period)
    upper: list[float | None] = []
    lower: list[float | None] = []

    for i, m in enumerate(middle):
        if m is None:
            upper.append(None)
            lower.append(None)
            continue

        window = closes[i - period + 1: i + 1]
        valid = [v for v in window if v is not None]
        if len(valid) != period:
            upper.append(None)
            lower.append(None)
            continue

        mean = sum(valid) / period
        variance = sum((v - mean) ** 2 for v in valid) / period
        std = variance ** 0.5

        upper.append(round(m + multiplier * std, 4))
        lower.append(round(m - multiplier * std, 4))

    return {"upper": upper, "middle": middle, "lower": lower}


# ── KDJ ───────────────────────────────────────────────────────────────────


def calc_kdj(
    closes: list[float | None],
    highs: list[float | None],
    lows: list[float | None],
    period: int = 9,
) -> dict[str, list[float | None]]:
    """计算 KDJ(9,3,3)。

    RSV = (close - lowest_N) / (highest_N - lowest_N) * 100
    K = SMA(RSV, 3, 1)  （递归平滑，weight=1）
    D = SMA(K, 3, 1)
    J = 3K - 2D

    Returns:
        {"k": [...], "d": [...], "j": [...]}
    """
    n = len(closes)
    rsv: list[float | None] = []

    for i in range(n):
        if i < period - 1:
            rsv.append(None)
            continue

        c = closes[i]
        if c is None:
            rsv.append(None)
            continue

        # 找窗口内最高/最低
        window_highs = [highs[j] for j in range(i - period + 1, i + 1) if highs[j] is not None]
        window_lows = [lows[j] for j in range(i - period + 1, i + 1) if lows[j] is not None]

        if not window_highs or not window_lows:
            rsv.append(None)
            continue

        highest = max(window_highs)
        lowest = min(window_lows)

        if highest == lowest:
            rsv.append(50.0)
        else:
            rsv.append(round((c - lowest) / (highest - lowest) * 100, 4))

    # K = SMA(RSV, 3, 1), D = SMA(K, 3, 1)
    k = _sma(rsv, 3, 1)
    d = _sma(k, 3, 1)

    j: list[float | None] = []
    for kv, dv in zip(k, d):
        if kv is not None and dv is not None:
            j.append(round(3 * kv - 2 * dv, 4))
        else:
            j.append(None)

    return {"k": k, "d": d, "j": j}


# ── 应用指标到 K 线 ───────────────────────────────────────────────────────

_ALL_INDICATORS = {"MA", "MACD", "RSI", "BOLL", "KDJ"}


def apply_indicators(
    klines: list[dict[str, Any]],
    indicators: list[str] | None = None,
) -> list[dict[str, Any]]:
    """将技术指标附加到 K 线列表。

    Args:
        klines: K 线字典列表（需含 close 字段，KDJ 额外需要 high/low）
        indicators: 要计算的指标列表，默认全部

    Returns:
        附加了指标字段的 K 线列表
    """
    if not klines:
        return klines

    if indicators is None:
        indicators = list(_ALL_INDICATORS)

    indicators_upper = [i.upper() for i in indicators]
    closes = [bar.get("close") for bar in klines]

    # MA（含 MA60）
    if "MA" in indicators_upper:
        ma5 = calc_ma(closes, 5)
        ma10 = calc_ma(closes, 10)
        ma20 = calc_ma(closes, 20)
        ma60 = calc_ma(closes, 60)
        for i, bar in enumerate(klines):
            bar["ma5"] = ma5[i]
            bar["ma10"] = ma10[i]
            bar["ma20"] = ma20[i]
            bar["ma60"] = ma60[i]

    # MACD
    if "MACD" in indicators_upper:
        macd = calc_macd(closes)
        for i, bar in enumerate(klines):
            bar["macd_dif"] = macd["dif"][i]
            bar["macd_dea"] = macd["dea"][i]
            bar["macd_hist"] = macd["histogram"][i]

    # RSI
    if "RSI" in indicators_upper:
        rsi6 = calc_rsi(closes, 6)
        rsi12 = calc_rsi(closes, 12)
        rsi24 = calc_rsi(closes, 24)
        for i, bar in enumerate(klines):
            bar["rsi_6"] = rsi6[i]
            bar["rsi_12"] = rsi12[i]
            bar["rsi_24"] = rsi24[i]

    # BOLL
    if "BOLL" in indicators_upper:
        boll = calc_boll(closes)
        for i, bar in enumerate(klines):
            bar["boll_upper"] = boll["upper"][i]
            bar["boll_middle"] = boll["middle"][i]
            bar["boll_lower"] = boll["lower"][i]

    # KDJ
    if "KDJ" in indicators_upper:
        highs = [bar.get("high") for bar in klines]
        lows = [bar.get("low") for bar in klines]
        kdj = calc_kdj(closes, highs, lows)
        for i, bar in enumerate(klines):
            bar["kdj_k"] = kdj["k"][i]
            bar["kdj_d"] = kdj["d"][i]
            bar["kdj_j"] = kdj["j"][i]

    return klines
