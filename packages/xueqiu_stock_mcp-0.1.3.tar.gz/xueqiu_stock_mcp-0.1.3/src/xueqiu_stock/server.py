"""MCP 服务入口 — 使用 FastMCP 注册五个工具。"""

from __future__ import annotations

import asyncio
import logging

from mcp.server.fastmcp import FastMCP

from .auth import ensure_cookies
from .tools import (
    tool_get_stock_quote,
    tool_get_kline_data,
    tool_get_minute_data,
    tool_get_pankou_data,
    tool_get_financial,
)

logger = logging.getLogger(__name__)

# ── 创建 MCP 服务 ─────────────────────────────────────────────────────────

mcp = FastMCP(
    "xueqiu-stock",
    instructions="基于雪球数据源的 A 股行情 MCP 服务器，提供实时行情、K 线技术指标、分时、盘口、财务数据查询",
)


# ── 注册工具 ──────────────────────────────────────────────────────────────


@mcp.tool()
async def get_stock_quote(symbols: str) -> str:
    """获取单只或多只股票的实时行情信息，包括当前价格、涨跌幅、
    成交量、PE/PB、市值等核心指标。支持批量查询（逗号分隔）。

    Args:
        symbols: 股票代码，多只用逗号分隔。支持短代码自动推断交易所：
                 600160 → SH600160，000001 → SZ000001。
    """
    return await tool_get_stock_quote(symbols)


@mcp.tool()
async def get_kline_data(
    symbol: str,
    period: str = "day",
    count: int = -60,
    indicators: str = "MA",
) -> str:
    """获取股票 K 线数据，并附带服务端计算的技术指标。
    支持 MA5/10/20/60、MACD、RSI、布林带、KDJ 等指标。

    Args:
        symbol: 股票代码（单只），如 600160
        period: K 线周期：1m/5m/15m/30m/60m/120m/day/week/month
        count: 返回根数（正数向后取，负数向前取历史），范围 -120 到 120
        indicators: 逗号分隔的技术指标，默认 "MA"，可选 MACD/RSI/BOLL/KDJ
    """
    indicator_list = [i.strip().upper() for i in indicators.split(",") if i.strip()]
    return await tool_get_kline_data(symbol, period, count, indicator_list)


@mcp.tool()
async def get_minute_data(symbol: str, period: str = "1d") -> str:
    """获取股票当日分时数据（逐分钟价格和成交量），用于绘制分时走势图。

    Args:
        symbol: 股票代码（单只），如 600160
        period: 分时周期：1d（当日）或 5d（近 5 日），默认 1d
    """
    return await tool_get_minute_data(symbol, period)


@mcp.tool()
async def get_pankou_data(symbol: str) -> str:
    """获取股票五档盘口数据（买卖五档价格和数量），用于判断短期供需。

    Args:
        symbol: 股票代码（单只），如 600160
    """
    return await tool_get_pankou_data(symbol)


@mcp.tool()
async def get_financial(
    symbol: str,
    report_type: str = "income",
    count: int = 3,
) -> str:
    """获取公司财务报表数据，包括利润表、资产负债表和现金流量表。
    每个字段包含当期值和同比变化率。

    Args:
        symbol: 股票代码（单只），如 600160
        report_type: 报表类型 — income（利润表）、balance（资产负债表）、cash_flow（现金流量表）
        count: 返回最近几期报告，范围 1-10，默认 3
    """
    return await tool_get_financial(symbol, report_type, count)


# ── 启动钩子 ──────────────────────────────────────────────────────────────


async def _startup():
    await ensure_cookies()
    logger.info("雪球 MCP 服务就绪（5 个工具）")


def _check_playwright():
    """检查 Playwright + Chromium 是否可用，缺失时给出安装指引。"""
    import subprocess
    import sys

    try:
        import playwright  # noqa: F401
    except ImportError:
        print(
            "\n"
            "╔══════════════════════════════════════════════════╗\n"
            "║  ❌ 缺少依赖: playwright                        ║\n"
            "╠══════════════════════════════════════════════════╣\n"
            "║                                                  ║\n"
            "║  请执行:                                         ║\n"
            "║                                                  ║\n"
            "║    xueqiu-stock --setup                          ║\n"
            "║                                                  ║\n"
            "║  或手动安装:                                     ║\n"
            "║    pip install playwright                        ║\n"
            "║    python3 -m playwright install chromium         ║\n"
            "║                                                  ║\n"
            "╚══════════════════════════════════════════════════╝\n",
            file=sys.stderr,
        )
        sys.exit(1)

    # 检查 Chromium 是否已安装
    try:
        result = subprocess.run(
            [sys.executable, "-c", "from playwright.sync_api import sync_playwright; "
             "p=sync_playwright().start(); p.chromium.launch(headless=True).close(); p.stop()"],
            capture_output=True, timeout=30,
        )
        if result.returncode != 0:
            raise RuntimeError("Chromium not found")
    except Exception:
        print(
            "\n"
            "╔══════════════════════════════════════════════════╗\n"
            "║  ❌ 缺少 Chromium 浏览器                        ║\n"
            "╠══════════════════════════════════════════════════╣\n"
            "║                                                  ║\n"
            "║  请执行:                                         ║\n"
            "║                                                  ║\n"
            "║    xueqiu-stock --setup                          ║\n"
            "║                                                  ║\n"
            "║  或手动:                                         ║\n"
            "║    python3 -m playwright install chromium         ║\n"
            "║                                                  ║\n"
            "╚══════════════════════════════════════════════════╝\n",
            file=sys.stderr,
        )
        sys.exit(1)


def _setup():
    """自动安装 Playwright + Chromium。"""
    import subprocess
    import sys

    print("\n🔧 雪球 MCP 环境安装\n")

    # 1. 安装 playwright
    print("[1/2] 安装 Playwright ...")
    try:
        import playwright  # noqa: F401
        print("  ✅ Playwright 已安装")
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "playwright", "-q"])
        print("  ✅ Playwright 安装完成")

    # 2. 安装 Chromium
    print("[2/2] 安装 Chromium 浏览器（约 150MB，请耐心等待）...")
    try:
        result = subprocess.run(
            [sys.executable, "-c",
             "from playwright.sync_api import sync_playwright; "
             "p=sync_playwright().start(); p.chromium.launch(headless=True).close(); p.stop()"],
            capture_output=True, timeout=30,
        )
        if result.returncode == 0:
            print("  ✅ Chromium 已就绪")
        else:
            raise RuntimeError()
    except Exception:
        subprocess.check_call([sys.executable, "-m", "playwright", "install", "chromium"])
        print("  ✅ Chromium 安装完成")

    print(
        "\n"
        "╔══════════════════════════════════════════════════╗\n"
        "║  ✅ 安装完成！                                  ║\n"
        "╠══════════════════════════════════════════════════╣\n"
        "║                                                  ║\n"
        "║  MCP 配置（添加到你的客户端配置文件中）:         ║\n"
        "║                                                  ║\n"
        '║  {                                               ║\n'
        '║    "mcpServers": {                               ║\n'
        '║      "xueqiu-stock": {                           ║\n'
        '║        "command": "xueqiu-stock"                 ║\n'
        "║      }                                           ║\n"
        "║    }                                             ║\n"
        "║  }                                               ║\n"
        "║                                                  ║\n"
        "║  重启 MCP 客户端即可使用。                       ║\n"
        "╚══════════════════════════════════════════════════╝\n"
    )


def main():
    """MCP 服务入口点。"""
    import sys

    if "--setup" in sys.argv:
        _setup()
        return

    if "--check" in sys.argv:
        _check_playwright()
        print("✅ 所有依赖就绪")
        return

    _check_playwright()
    asyncio.run(_startup())
    mcp.run()


if __name__ == "__main__":
    main()
