"""令牌桶限流器。

支持：
    - 全局请求间隔（200ms）
    - 同一 symbol 每秒最多 N 次
    - 全局每秒最多 M 次
    - symbol 桶自动清理（10 分钟未用则回收）
"""

from __future__ import annotations

import asyncio
import time


class TokenBucket:
    """单桶令牌桶限流器。"""

    def __init__(self, rate: float, capacity: float) -> None:
        self.rate = rate
        self.capacity = capacity
        self._tokens = capacity
        self._last_refill = time.monotonic()
        self._last_used = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        """获取一个令牌，阻塞直到可用。"""
        while True:
            async with self._lock:
                self._refill()
                if self._tokens >= 1:
                    self._tokens -= 1
                    self._last_used = time.monotonic()
                    return
            await asyncio.sleep(0.05)

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
        self._last_refill = now


# symbol 桶超过此时长未使用则回收
_BUCKET_TTL = 600  # 10 分钟


class RateLimiter:
    """多层限流器。"""

    def __init__(
        self,
        min_interval: float = 0.2,
        per_symbol_rate: float = 2.0,
        global_rate: float = 5.0,
    ) -> None:
        self._min_interval = min_interval
        self._global_bucket = TokenBucket(global_rate, global_rate)
        self._symbol_buckets: dict[str, TokenBucket] = {}
        self._last_request: float = 0.0
        self._interval_lock = asyncio.Lock()
        self._cleanup_counter = 0

    async def acquire(self, symbol: str = "") -> None:
        """获取请求许可。"""
        # 1. 全局间隔
        async with self._interval_lock:
            now = time.monotonic()
            wait = self._min_interval - (now - self._last_request)
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_request = time.monotonic()

        # 2. 全局令牌桶
        await self._global_bucket.acquire()

        # 3. symbol 级令牌桶
        if symbol:
            if symbol not in self._symbol_buckets:
                self._symbol_buckets[symbol] = TokenBucket(2.0, 2.0)
            await self._symbol_buckets[symbol].acquire()

        # 4. 定期清理过期桶（每 50 次请求清理一次）
        self._cleanup_counter += 1
        if self._cleanup_counter >= 50:
            self._cleanup_counter = 0
            self._cleanup_stale_buckets()

    def _cleanup_stale_buckets(self) -> None:
        """回收超过 _TTL 未使用的 symbol 桶。"""
        now = time.monotonic()
        stale = [
            k for k, v in self._symbol_buckets.items()
            if now - v._last_used > _BUCKET_TTL
        ]
        for k in stale:
            del self._symbol_buckets[k]


# ── 全局实例 ──────────────────────────────────────────────────────────────

_limiter: RateLimiter | None = None


def get_limiter() -> RateLimiter:
    global _limiter
    if _limiter is None:
        _limiter = RateLimiter()
    return _limiter
