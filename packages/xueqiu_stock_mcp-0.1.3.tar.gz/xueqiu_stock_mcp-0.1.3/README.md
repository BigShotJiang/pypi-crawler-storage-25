# 雪球 A 股 MCP 服务器

基于雪球(Xueqiu)数据源的 MCP 服务器，提供 A 股实时行情、K 线技术指标、盘口、财务数据查询。

## 一键安装

```bash
bash <(curl -sL https://raw.githubusercontent.com/user/mcp-xueqiu-stock/main/install.sh)
```

或手动安装：

```bash
pip install xueqiu-stock-mcp
python3 -m playwright install chromium
```

## 前置依赖

| 依赖 | 说明 | 安装方式 |
|------|------|----------|
| Python >= 3.10 | 运行环境 | `brew install python3` / `sudo apt install python3` |
| Playwright | 浏览器自动化（获取雪球 Cookie） | `pip install playwright` |
| Chromium | 浏览器引擎（Playwright 使用） | `python3 -m playwright install chromium` |

> **为什么需要 Chromium？** 雪球使用阿里云 WAF 保护 API，需要通过浏览器执行 JavaScript 获取认证 Cookie。Playwright + Chromium 是当前唯一可靠的方案。

## MCP 配置

```json
{
  "mcpServers": {
    "xueqiu-stock": {
      "command": "xueqiu-stock",
      "args": []
    }
  }
}
```

配置文件位置：
- **Claude Desktop**: `~/.claude/claude_desktop_config.json`
- **Cursor**: 项目根目录 `/.cursor/mcp.json`
- **VS Code**: 项目根目录 `/.vscode/mcp.json`
- **QwenPaw**: `~/.qwenpaw/config.json` → `mcp.clients`

## 提供的工具

| 工具 | 功能 |
|------|------|
| `get_stock_quote` | 实时行情（价格、涨跌幅、PE/PB、市值等） |
| `get_kline_data` | K 线数据 + 技术指标（MA/MACD/RSI/BOLL/KDJ） |
| `get_minute_data` | 分时走势（逐分钟价格和成交量） |
| `get_pankou_data` | 五档盘口（买卖五档价格和数量） |
| `get_financial` | 财务报表（利润表/资产负债表/现金流量表） |

## 故障排除

### 首次启动很慢？
Playwright 首次获取 Cookie 需要 ~10 秒，后续请求 < 1 秒。

### 报错 "缺少 playwright"？
```bash
pip install playwright
python3 -m playwright install chromium
```

### 报错 "Cookie 获取失败"？
可能是网络问题，服务会自动重试。如持续失败，检查是否能访问 xueqiu.com。

## PyPI

https://pypi.org/project/xueqiu-stock-mcp/
