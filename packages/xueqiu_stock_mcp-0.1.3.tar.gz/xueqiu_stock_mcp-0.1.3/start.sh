#!/usr/bin/env bash
# xueqiu-stock MCP 服务器启动脚本
# 自动安装依赖（如果缺失），然后启动服务

set -e

# 检查 playwright 是否已安装
if ! python3 -c "import playwright" 2>/dev/null; then
    echo "首次运行，安装 playwright ..." >&2
    pip install playwright -q
    python3 -m playwright install chromium --with-deps 2>&1 | tail -3 >&2
fi

# 启动 MCP 服务器
exec xueqiu-stock
