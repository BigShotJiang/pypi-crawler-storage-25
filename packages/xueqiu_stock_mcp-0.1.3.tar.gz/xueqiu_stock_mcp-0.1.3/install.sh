#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# 雪球 A 股 MCP 服务器 — 一键安装脚本
# 用法: curl -sL https://raw.githubusercontent.com/sunnyws/mcp-xueqiu-stock/main/install.sh | bash
# ─────────────────────────────────────────────────────────────
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()    { echo -e "${GREEN}[OK]${NC}   $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail()  { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   雪球 A 股 MCP 服务器 安装程序              ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 1. 检查 Python ──────────────────────────────────────────

info "检查 Python 环境 ..."
if command -v python3 &>/dev/null; then
    PY=$(python3 --version 2>&1)
    ok "已安装: $PY"
else
    fail "未找到 python3，请先安装 Python >= 3.10
    macOS:   brew install python3
    Ubuntu:  sudo apt install python3 python3-pip
    Windows: https://www.python.org/downloads/"
fi

# 检查 Python 版本
PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PY_MAJOR=$(echo "$PY_VER" | cut -d. -f1)
PY_MINOR=$(echo "$PY_VER" | cut -d. -f2)
if [ "$PY_MAJOR" -lt 3 ] || ([ "$PY_MAJOR" -eq 3 ] && [ "$PY_MINOR" -lt 10 ]); then
    fail "Python 版本过低 ($PY_VER)，需要 >= 3.10"
fi

# ── 2. 检查 pip ─────────────────────────────────────────────

info "检查 pip ..."
if python3 -m pip --version &>/dev/null; then
    ok "pip 可用"
else
    warn "pip 未安装，尝试安装 ..."
    python3 -m ensurepip --default-pip 2>/dev/null || \
    fail "pip 安装失败，请手动安装: python3 -m ensurepip"
    ok "pip 安装完成"
fi

# ── 3. 安装 Python 包 ───────────────────────────────────────

info "安装 xueqiu-stock-mcp ..."
python3 -m pip install xueqiu-stock-mcp -q 2>/dev/null || \
python3 -m pip install xueqiu-stock-mcp
ok "Python 包安装完成"

# ── 4. 检查/安装 Playwright + Chromium ──────────────────────

info "检查 Playwright ..."
if python3 -c "import playwright" 2>/dev/null; then
    ok "Playwright 已安装"
else
    warn "Playwright 未安装，正在安装 ..."
    python3 -m pip install playwright -q
    ok "Playwright 安装完成"
fi

info "检查 Chromium 浏览器 ..."
CHROMIUM_OK=$(python3 -c "
from playwright.sync_api import sync_playwright
try:
    with sync_playwright() as p:
        b = p.chromium.launch(headless=True)
        b.close()
        print('yes')
except:
    print('no')
" 2>/dev/null)

if [ "$CHROMIUM_OK" = "yes" ]; then
    ok "Chromium 已就绪"
else
    warn "Chromium 未安装，正在下载（约 150MB，请耐心等待）..."
    python3 -m playwright install chromium
    ok "Chromium 安装完成"
fi

# ── 5. 验证安装 ──────────────────────────────────────────────

info "验证安装 ..."
if command -v xueqiu-stock &>/dev/null; then
    ok "xueqiu-stock 命令可用"
else
    warn "xueqiu-stock 不在 PATH 中，尝试用 python3 -m xueqiu_stock 启动"
fi

# ── 6. 输出 MCP 配置 ────────────────────────────────────────

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   ✅ 安装完成！                              ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "将以下配置添加到你的 MCP 客户端配置文件中："
echo ""
echo -e "${CYAN}────────────────────────────────────────${NC}"
cat << 'EOF'
{
  "mcpServers": {
    "xueqiu-stock": {
      "command": "xueqiu-stock",
      "args": []
    }
  }
}
EOF
echo -e "${CYAN}────────────────────────────────────────${NC}"
echo ""
echo "配置文件位置："
echo "  Claude Desktop: ~/.claude/claude_desktop_config.json"
echo "  Cursor:         项目根目录/.cursor/mcp.json"
echo "  VS Code:        项目根目录/.vscode/mcp.json"
echo "  QwenPaw:        ~/.qwenpaw/config.json (mcp.clients)"
echo ""
echo "添加后重启 MCP 客户端即可使用。"
echo ""
