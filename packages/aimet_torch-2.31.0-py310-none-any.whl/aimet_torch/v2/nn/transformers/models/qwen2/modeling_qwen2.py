# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause


"""
Backwards compatibility shim for aimet_torch.v2.nn.transformers.models.qwen2.modeling_qwen2

All contents have been moved to aimet_torch.nn.transformers.models.qwen2.modeling_qwen2. This module re-exports everything
from the new location for backwards compatibility.
"""

from ......nn.transformers.models.qwen2.modeling_qwen2 import *  # pylint: disable=wildcard-import, unused-wildcard-import
