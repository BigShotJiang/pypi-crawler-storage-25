# Copyright (c) Qualcomm Technologies, Inc. and/or its subsidiaries.
# SPDX-License-Identifier: BSD-3-Clause


"""Contains Winnowing related utility functions are used by PyTorch Winnower."""

from typing import List, Set, Union
from enum import Enum

from ..connected_graph.connectedgraph_utils import CG_SPLIT
from ..utils import ModelApi


def get_one_positions_in_binary_mask(mask: List[int]) -> List[int]:
    """
    Return the indices of one positions in a binary mask.

    :param mask: a mask that contains either 0s or 1s
    :return: List of indices of positions of ones in a binary mask.
    """

    mask_one_positions = [idx for (idx, channel) in enumerate(mask) if channel]
    return mask_one_positions


def get_zero_positions_in_binary_mask(mask: List[int]) -> List[int]:
    """
    Return the indices of zero positions in a binary mask.

    :param mask: a mask that contains either 0s or 1s
    :return: List of indices of positions of zeros in a binary mask.
    """

    mask_zero_positions = [idx for (idx, channel) in enumerate(mask) if not channel]
    return mask_zero_positions


class ConnectivityType(Enum):
    """Defines the channel types"""

    null = 1
    direct = 2
    split = 3
    add = 4
    concat = 5
    skip = 6
    stop = 7


class OpConnectivity:
    """
    Class containing mappings between modules and module connectivity, for both pytorch and tensorflow.
    Class is meant to be used statically, and not instantiated.
    """

    # TODO: remove all types used in old connected graph when it is completely removed.
    pytorch_dict = {
        "Conv": ConnectivityType.null,
        "ConvTranspose": ConnectivityType.null,
        "Linear": ConnectivityType.null,
        "Gemm": ConnectivityType.null,
        "DownsampleLayer": ConnectivityType.stop,
        "Dropout": ConnectivityType.direct,
        "Dropout2d": ConnectivityType.direct,
        "Relu": ConnectivityType.direct,
        "MaxPool": ConnectivityType.direct,
        "MaxPool2d": ConnectivityType.direct,
        "AveragePool": ConnectivityType.direct,
        "AvgPool2d": ConnectivityType.direct,
        "Neg": ConnectivityType.direct,
        "BatchNorm2d": ConnectivityType.direct,
        "Flatten": ConnectivityType.direct,
        "flatten": ConnectivityType.direct,
        "ReduceMean": ConnectivityType.direct,
        "GlobalAveragePool": ConnectivityType.direct,
        "AdaptiveAvgPool2d": ConnectivityType.direct,
        "BatchNormalization": ConnectivityType.direct,
        "BatchNorm1d": ConnectivityType.direct,
        "Add": ConnectivityType.add,
        "Concat": ConnectivityType.concat,
        "Split": ConnectivityType.split,
        CG_SPLIT: ConnectivityType.split,
        "LogSoftmax": ConnectivityType.direct,
        "Gather": ConnectivityType.skip,
        "Reshape": ConnectivityType.skip,
        "ListConstruct": ConnectivityType.skip,
        "Pad": ConnectivityType.skip,
        "Mul": ConnectivityType.skip,
        "Clip": ConnectivityType.direct,
        "Upsample": ConnectivityType.skip,
        "index_select": ConnectivityType.null,
        "mean": ConnectivityType.direct,
        "floor": ConnectivityType.direct,
        "cat": ConnectivityType.concat,
        "add": ConnectivityType.add,
        "size": ConnectivityType.skip,
        "NumToTensor": ConnectivityType.skip,
        "mul": ConnectivityType.skip,
        "view": ConnectivityType.skip,
        "reshape": ConnectivityType.skip,
        "slice": ConnectivityType.skip,
        "unsqueeze": ConnectivityType.skip,
        "select": ConnectivityType.skip,
    }

    @classmethod
    def get_op_connectivity(
        cls, model_api: ModelApi, op_type: str
    ) -> Union[ConnectivityType, None]:
        """
        Get op connectivity for a module, and return None if the module is not recognized.
        :param model_api: Pytorch
        :param op_type: Type of the op, which is used to map to its connectivity
        :return: Op connectivity, or None if module is not recognized.
        """
        if model_api == ModelApi.pytorch:
            return cls.pytorch_dict.get(op_type, None)
        raise RuntimeError(f"Unsupported model_api provided: {model_api}")


def get_conv_ops_for_api(model_api: ModelApi) -> Set:
    """
    Return a set of op types that represent conv ops, based on the model api

    :param model_api: Pytorch
    """
    if model_api == ModelApi.pytorch:
        return {"Conv", "ConvTranspose"}
    raise RuntimeError(f"Unsupported model_api provided: {model_api}")


def get_linear_ops_for_api(model_api: ModelApi) -> Set:
    """
    Return a set of op types that represent linear ops, based on the model api

    :param model_api: Pytorch
    """
    if model_api == ModelApi.pytorch:
        return {"Gemm"}
    raise RuntimeError(f"Unsupported model_api provided: {model_api}")


def get_indices_among_ones_of_overlapping_ones(
    more_ones_mask: List[int], less_ones_mask: List[int]
) -> List[int]:
    """
    :param more_ones_mask: Mask that has more ones
    :param less_ones_mask: Mask that has less ones
    :return: A list of indices of where the overlapping ones occur between the two masks, where the indices are counted
    looking only at the ones in more_ones_mask.
    It is assumed that wherever less_ones_mask has a 1, more_ones_mask also has a 1 in that position
    Example:
    more_ones_mask: 1, 0, 0, 1, 1, 0, 1, 0, 1, 1
    less_ones_mask: 1, 0, 0, 0, 1, 0, 0, 0, 1, 0
                    *           *           *
    Overlapping ones are represented by the stars above.  If we are indexing using the full list, we would say that
    the overlapping ones are indexes 0, 4, and 8.  However, we only consider the indexes by looking at the positions
    in more_ones_mask that have ones.  So we can see that it is the 0th, 2nd, and 4th ones in more_ones_mask that have
    overlapping ones with less_ones_mask.  Thus the index list that is returned will be [0, 2, 4].
    """

    indices = []
    more_ones_mask_ones_index = 0
    for index, mask_item in enumerate(more_ones_mask):
        if mask_item & less_ones_mask[index]:
            indices.append(more_ones_mask_ones_index)
        if mask_item:
            more_ones_mask_ones_index += 1

    return indices


def update_winnowed_channels(original_mask: List[int], new_mask: List[int]):
    """
    Update original mask with newly winnowed channels in new_mask
    Mask lengths can be different, but the length of new mask should be equal to the number of ones in original mask.
    Ones in the original mask will be set to zeros for each zero in new_mask.
    For determining which index positions to set to zero in original mask, zeros that were already present in original
    mask are not considered.
    Example:
    Original mask: 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1
    New mask:      1, 1, 0, 0, 1, 0, 1
    New mask has 7 entries, same as number of ones in original mask.  Each channel in new mask corresponds to a one
    in the original mask.
    In new mask, 2nd, 3rd, and 5th channels are winnowed.  Thus, we set the 2nd, 3rd, and 5th ones in original mask
    to zeros.  This results in an original mask of 1, 1, 0, 0*, 0, 0, 0*, 1, 0*, 0, 0, 1 (* represents ones set to zero)
    :param original_mask: Original mask representing a running tally of masks winnowed since the very beginning
    :param new_mask: Most recent mask after the most recent round of winnowing
    :return: original masks with updated channels winnowed according to new mask
    """
    assert len(new_mask) == sum(original_mask)
    original_mask_ones_indices = get_one_positions_in_binary_mask(original_mask)
    new_mask_zero_indices = get_zero_positions_in_binary_mask(new_mask)
    for idx in new_mask_zero_indices:
        original_mask[original_mask_ones_indices[idx]] = 0
