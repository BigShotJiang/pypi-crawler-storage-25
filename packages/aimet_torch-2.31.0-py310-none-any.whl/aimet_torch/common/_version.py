__version__ = '2.31.0'
python_abi = 'cpython-310-x86_64-linux-gnu'
torch = '2.12.0+cu126'
min_glibc = None
