from typing import List,Dict
from rule.md.rules import MdTodoRules
import uuid

class MdParser:
    def parse(self, lines: List[str]) -> List[Dict]:
        tasks = []
        level_stack = {}
        md_rules = MdTodoRules()
        print(lines)
        for line in lines:
            match = md_rules.desc.match(line)    
            if not match:
                continue
            indent_level = len(match.group("indent")) // 4
            raw_content = match.group("content")

            t_ms = md_rules.tags.finditer(raw_content)
            tags = [m.group("tag") for m in t_ms]
            
            p_m = md_rules.project.search(raw_content)
            
            project = p_m.group("project") if p_m else None
            d_m = md_rules.due.search(raw_content)
            due = d_m.group("due") if d_m else None            
            uuid_match = md_rules.uuid.search(raw_content)
            task_id = uuid_match.group("uuid") if uuid_match else str(uuid.uuid4())
            is_new = not bool(uuid_match)
            clean_desc = md_rules.clean_description(raw_content)
            

            task_obj = {
                "uuid": task_id,
                "description": clean_desc,
                "status": "pending",
                "_is_new": is_new,
                "_original_line": line
            }
            
            if project: task_obj["project"] = project
            if tags: task_obj["tags"] = tags
            if due: task_obj["due"] = due
            
            if indent_level > 0:
                parent_task = level_stack.get(indent_level - 1)
                if parent_task:
                    if "depends_list" not in parent_task:
                        parent_task["depends_list"] = []
                    parent_task["depends_list"].append(task_id)
                    
            level_stack[indent_level] = task_obj
            tasks.append(task_obj)
            
            
        for t in tasks:
            if "depends_list" in t:
                t["depends"] = ",".join(t["depends_list"])
                del t["depends_list"] 
        return tasks
            
            
    def sync_file(self,lines: List[str],tasks: List[Dict]) -> tuple[List[Dict], List[str]]:
        new_lines_to_write:List[str] = []
        tasks_for_tw:List[Dict] = []
        
        task_idx = 0
        
        for line in lines:
            if line.lstrip().startswith('- ') or line.lstrip().startswith('* '):
                if task_idx < len(tasks):
                    task_obj = tasks[task_idx]
                
                
                    if task_obj.get("_is_new"):
                        clean_line = line.rstrip('\n')
                        modified_line = f"{clean_line} <!-- id:{task_obj['uuid']} -->\n"
                        new_lines_to_write.append(modified_line)
                    
                        tw_task = task_obj.copy()
                        tw_task.pop("_is_new", None)
                        tw_task.pop("_original_line", None)
                        tasks_for_tw.append(tw_task)
                    else:
                        new_lines_to_write.append(line)
                    
                    task_idx += 1
                else:
                    new_lines_to_write.append(line)
            else:
                new_lines_to_write.append(line)
        return tasks_for_tw, new_lines_to_write