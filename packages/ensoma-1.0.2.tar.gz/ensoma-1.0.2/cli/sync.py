import json
import subprocess

import typer
from typing_extensions import Annotated

from provider.md.md_parser import MdParser

app = typer.Typer(help="tmap")


@app.command(name="sync")
def sync(
    target: Annotated[str, typer.Option("--target", "-t", help="target")] = "",
):
    with open(target, "r", encoding="utf-8") as f:
        lines = f.readlines()
        md = MdParser()
        task_data = md.parse(lines)
        tasks, new_lines = md.sync_file(lines, task_data)
        print(tasks)

        process = subprocess.run(
            ["task", "rc.confirmation=off", "import", "-"],
            input=json.dumps(tasks),
            text=True,
            capture_output=True,
            check=True,
        )
        print("✅ 成功导入 Taskwarrior！")

    with open(target, "w", encoding="utf-8") as f:
        f.writelines(new_lines)
        print("📝 Markdown 文件已更新。")



if __name__ == "__main__":
    app()