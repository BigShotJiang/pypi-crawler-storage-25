import re


class MdTodoRules:
    def __init__(self):
        self.desc = re.compile(r"^(?P<indent>\s*)[-\*]\s+(?P<content>.+?)$")
        self.tags = re.compile(r"@(?P<tag>\S+)")
        self.project = re.compile(r"#(?P<project>\S+)")
        self.uuid = re.compile(r"<!--\s*id:(?P<uuid>[a-fA-F0-9\-]{36})\s*-->")
        self.due = re.compile(r"due:(?P<due>\d{4}-\d{2}-\d{2})")

    def clean_description(self, raw_content):
        text = raw_content
        text = self.tags.sub("", text)
        text = self.project.sub("", text)
        text = self.uuid.sub("", text)
        text = self.due.sub("", text)
        return text.strip()
