"""Meta-package redirect for qondor-sdk. Install `qondor-api-sdk` for the real SDK."""

raise ImportError(
    "The `qondor-sdk` name is a defensive reservation. "
    "Install `qondor-api-sdk` (https://pypi.org/project/qondor-api-sdk/) instead."
)
