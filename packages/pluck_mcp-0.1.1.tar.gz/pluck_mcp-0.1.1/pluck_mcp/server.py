"""Pluck MCP Server — exposes Pluck tools via the Model Context Protocol."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from pluck_mcp.client import IntegrationApiClient


mcp = FastMCP("Pluck MCP")
client = IntegrationApiClient()


@mcp.tool()
def ask_pluck(message: str) -> str:
    """Ask Pluck a question and get a researched answer with full knowledge graph context.

    Pluck will plan a research strategy, search the knowledge graph, and craft
    a detailed answer with citations. Use this for open-ended questions about
    your ingested documents and data.

    Args:
        message: The question or request to research.

    Returns:
        A detailed answer with citations from the knowledge graph.
    """
    return client.ask_pluck(message)


@mcp.tool()
def list_document_types() -> str:
    """List all document types discovered in the knowledge graph.

    Returns the names and counts of each document type (e.g. "Invoice",
    "Contract", "Meeting Notes") that Pluck has identified across your
    ingested documents.

    Returns:
        JSON string with document types and their counts.
    """
    return client.call_tool("list_document_types", {})


@mcp.tool()
def get_schema_fields(doc_type: str) -> str:
    """Get the schema fields for a specific document type.

    Returns the field names, types, and descriptions that Pluck has discovered
    for the given document type. Useful for understanding what structured data
    is available before querying.

    Args:
        doc_type: The document type name (e.g. "Invoice", "Contract").

    Returns:
        JSON string with field definitions for the document type.
    """
    return client.call_tool("get_schema_fields", {"doc_type": doc_type})


@mcp.tool()
def vector_search(
    query: str,
    mode: str = "chunks",
    doc_type_filter: str | None = None,
    scope_doc_id: str | None = None,
) -> str:
    """Search the knowledge graph using semantic similarity.

    Finds document chunks or full documents that are semantically similar
    to your query. Supports filtering by document type and scoping to a
    specific document.

    Args:
        query: The search query text.
        mode: Search mode — "chunks" for passage-level results or "documents" for document-level.
        doc_type_filter: Optional document type to filter results (e.g. "Invoice").
        scope_doc_id: Optional document ID to search within a single document.

    Returns:
        JSON string with ranked search results and relevance scores.
    """
    args: dict[str, object] = {"query": query, "mode": mode}
    if doc_type_filter:
        args["doc_type_filter"] = doc_type_filter
    if scope_doc_id:
        args["scope_doc_id"] = scope_doc_id
    return client.call_tool("vector_search", args)


@mcp.tool()
def query_documents(
    doc_type: str | None = None,
    order_by: str | None = None,
    order_direction: str | None = None,
    limit: int = 25,
) -> str:
    """Query documents in the knowledge graph with optional filtering and sorting.

    Returns a list of documents matching the criteria. Use this to browse
    documents by type, find recent additions, or list documents sorted by
    a schema field.

    Args:
        doc_type: Optional document type filter (e.g. "Invoice").
        order_by: Optional field name to sort by.
        order_direction: Sort direction — "asc" or "desc".
        limit: Maximum number of documents to return (1-100, default 25).

    Returns:
        JSON string with matching documents and their metadata.
    """
    args: dict[str, object] = {"limit": limit}
    if doc_type:
        args["doc_type"] = doc_type
    if order_by:
        args["order_by"] = order_by
    if order_direction:
        args["order_direction"] = order_direction
    return client.call_tool("query_documents", args)


@mcp.tool()
def get_entity_neighbors(entity_name: str, hops: int = 2) -> str:
    """Explore the knowledge graph around a specific entity.

    Returns entities and relationships within N hops of the given entity.
    Useful for understanding how concepts, people, organizations, and
    documents are connected.

    Args:
        entity_name: The name of the entity to explore (e.g. "Acme Corp").
        hops: Number of relationship hops to traverse (1-3, default 2).

    Returns:
        JSON string with neighboring entities and their relationships.
    """
    return client.get_resource(
        f"/api/v1/entities/{entity_name}/neighbors",
        params={"hops": hops},
    )


@mcp.tool()
def get_full_text(doc_id: str | None = None, chunk_id: str | None = None) -> str:
    """Retrieve the full text of a document or a specific chunk.

    Use doc_id to get an entire document with all its chunks, or chunk_id
    to get a single passage. At least one of doc_id or chunk_id must be
    provided.

    Args:
        doc_id: The document ID to retrieve.
        chunk_id: The chunk ID to retrieve.

    Returns:
        The full text content of the document or chunk with metadata.
    """
    if chunk_id:
        return client.get_resource(f"/api/v1/chunks/{chunk_id}")
    if doc_id:
        return client.get_resource(f"/api/v1/documents/{doc_id}")
    return "Error: Provide either doc_id or chunk_id."


def main() -> None:
    """Entry point for the pluck-mcp CLI command."""
    mcp.run()


if __name__ == "__main__":
    main()
