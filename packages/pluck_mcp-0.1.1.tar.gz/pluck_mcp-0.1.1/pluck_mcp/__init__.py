"""Pluck MCP Server — expose Pluck knowledge graph via the Model Context Protocol."""

__version__ = "0.1.1"
