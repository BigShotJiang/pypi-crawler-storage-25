"""Probe ONNX Runtime + system capabilities.

Returns a JSON-serialisable dict. Never raises — if anything is missing,
the relevant field is empty/null and the frontend renders a useful
"not available" message.
"""

from __future__ import annotations

import platform
import subprocess
import sys
from typing import Any


def _probe_gpus() -> list[dict[str, Any]]:
    """Detect NVIDIA GPUs via nvidia-smi.

    Returns one dict per GPU with ``name``, ``driver_version`` and
    ``memory_mb``. Returns an empty list when nvidia-smi isn't on PATH
    (no NVIDIA driver), times out, or reports a non-zero exit. The probe
    must never raise — the dialog falls back to a "CPU only" pill if the
    list is empty.
    """
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,driver_version,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return []
    if result.returncode != 0:
        return []
    gpus: list[dict[str, Any]] = []
    for line in result.stdout.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) < 3:
            continue
        try:
            memory_mb: int | None = int(parts[2])
        except ValueError:
            memory_mb = None
        gpus.append(
            {
                "name": parts[0],
                "driver_version": parts[1],
                "memory_mb": memory_mb,
            }
        )
    return gpus


def probe_capabilities() -> dict[str, Any]:
    providers: list[str] = []
    ort_version: str | None = None
    try:
        import onnxruntime as ort  # type: ignore
        providers = list(ort.get_available_providers())
        ort_version = getattr(ort, "__version__", None)
    except Exception:  # noqa: BLE001
        pass

    return {
        "providers": providers,
        "ort_version": ort_version,
        "python_version": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
        "gpus": _probe_gpus(),
    }
