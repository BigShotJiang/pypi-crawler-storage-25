"""SAM 2.1 — promptable segmentation.

The student marks what they want with point clicks and/or a single
rectangle, and SAM 2.1 returns a binary mask. Points are tagged positive
("include this") or negative ("not this"); the rectangle is an optional
box prompt that focuses the model on a region. The op runs two ONNX
models in sequence:

1. ``vision_encoder.onnx``         — once per frame; outputs three
   multi-scale image embeddings the decoder later attends over.
2. ``prompt_encoder_mask_decoder.onnx`` — once per prompt set; takes the
   embeddings plus the prompt tensors and returns three candidate masks
   with IoU scores. We keep the highest-IoU mask.

Both models run on CUDA when the bundled ``onnxruntime-gpu`` build can
reach a GPU, falling back to CPU otherwise (``make_session`` already
configures the EP preference list).

Inputs:
  - ``params["points"]`` — list of ``{x, y, positive}`` dicts in image
    coordinates (not the model's 1024-pixel canvas — we rescale).
  - ``params["box"]``    — optional ``{x, y, w, h}`` rectangle in image
    coordinates. Treated as a single combined prompt with the points.
  - ``params["threshold"]`` — float in [0, 1]. The pred-mask logits go
    through a sigmoid before this threshold; default 0.5.

Outputs:
  - ``image`` — single-channel 8-bit binary mask at the input image's
    spatial size.
  - ``preview`` — magenta contour outline on a copy of the source frame
    (matches CLIPSeg's "don't paint over the picture" style).
  - ``rows`` — ``match_pct`` (fraction of foreground pixels as a
    percentage) and ``mask_pixels`` (raw count). If no prompts are given
    or the model files are missing, returns an ``error`` row instead.

Model files live under ``~/SimpleVision/Models/sam2_1/onnx/`` once the
plugin is installed; the desktop app sets ``SIMPLEVISION_MODELS_DIR`` so
the sidecar looks there. Both the ``tiny`` and ``small`` variants write
to the same paths on disk, so this op never has to know which one is
installed.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ..inference import make_session, plugin_models_dir
from ._common import scalar, to_bgr
from ._registry import ApplyResult, op


# The vision encoder expects 1024x1024 RGB input normalised with ImageNet
# statistics (see the onnx-community preprocessor_config.json). The mask
# decoder produces 256x256 logits which we resize back to the source
# image's resolution.
_INPUT_SIZE = 1024
_MASK_SIZE = 256
_IMAGE_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
_IMAGE_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)


def _preprocess_image(bgr: np.ndarray) -> np.ndarray:
    """Resize to 1024x1024 RGB float32 NCHW with ImageNet normalisation."""
    resized = cv2.resize(bgr, (_INPUT_SIZE, _INPUT_SIZE), interpolation=cv2.INTER_LINEAR)
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    rgb = (rgb - _IMAGE_MEAN) / _IMAGE_STD
    return np.transpose(rgb, (2, 0, 1))[np.newaxis, ...].astype(np.float32)


def _build_prompts(
    points: list[dict[str, Any]],
    box: dict[str, Any] | None,
    src_w: int,
    src_h: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Pack the points / box into the three prompt tensors the decoder
    expects. Coordinates are scaled from image space to the model's
    1024-pixel canvas. Returns ``(input_points, input_labels, input_boxes)``
    with shapes ``[1, 1, N, 2] f32``, ``[1, 1, N] i64`` and
    ``[1, K, 4] f32`` respectively (N or K can be 0)."""
    sx = _INPUT_SIZE / max(1, src_w)
    sy = _INPUT_SIZE / max(1, src_h)

    if points:
        pts = np.array(
            [[p["x"] * sx, p["y"] * sy] for p in points],
            dtype=np.float32,
        ).reshape(1, 1, len(points), 2)
        lbls = np.array(
            [1 if p.get("positive", True) else 0 for p in points],
            dtype=np.int64,
        ).reshape(1, 1, len(points))
    else:
        pts = np.zeros((1, 1, 0, 2), dtype=np.float32)
        lbls = np.zeros((1, 1, 0), dtype=np.int64)

    if box:
        x1 = float(box["x"]) * sx
        y1 = float(box["y"]) * sy
        x2 = (float(box["x"]) + float(box["w"])) * sx
        y2 = (float(box["y"]) + float(box["h"])) * sy
        boxes = np.array([[[x1, y1, x2, y2]]], dtype=np.float32)
    else:
        boxes = np.zeros((1, 0, 4), dtype=np.float32)

    return pts, lbls, boxes


def _build_overlay(bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Outline the foreground regions on a copy of ``bgr``.

    Same approach as CLIPSeg: no fill tint — just a magenta contour at the
    mask boundary so the underlying photo stays readable.
    """
    out = bgr.copy()
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if contours:
        cv2.drawContours(out, contours, -1, (255, 0, 255), thickness=3)
    return out


def _error_result(image: np.ndarray, message: str) -> ApplyResult:
    h, w = image.shape[:2]
    empty = np.zeros((h, w), dtype=np.uint8)
    preview = to_bgr(image)
    return ApplyResult(
        image=empty,
        preview=preview,
        rows=[scalar("error", message)],
    )


@op("sam2")
def op_sam2(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    raw_points = params.get("points") or []
    if not isinstance(raw_points, list):
        raw_points = []
    points = [p for p in raw_points if isinstance(p, dict) and "x" in p and "y" in p]
    box = params.get("box") if isinstance(params.get("box"), dict) else None

    if not points and not box:
        return _error_result(
            image,
            "Click on the image to mark what you want, or drag a box. "
            "Alt-click adds a negative point that pushes the mask back.",
        )

    model_dir = plugin_models_dir("sam2_1")
    encoder_path = model_dir / "onnx" / "vision_encoder.onnx"
    decoder_path = model_dir / "onnx" / "prompt_encoder_mask_decoder.onnx"
    if not encoder_path.exists() or not decoder_path.exists():
        return _error_result(
            image,
            "SAM 2.1 model files not found. Install the SAM 2.1 plugin from the Plugins dialog.",
        )

    threshold = float(params.get("threshold", 0.5))
    threshold = max(0.0, min(1.0, threshold))

    bgr_full = to_bgr(image)
    h_full, w_full = bgr_full.shape[:2]

    pixel_values = _preprocess_image(bgr_full)

    encoder = make_session(str(encoder_path))
    try:
        emb_outputs = encoder.run(None, {"pixel_values": pixel_values})
    except Exception as exc:
        return _error_result(image, f"SAM 2.1 image encoder failed: {exc}")

    emb_feed = {
        "image_embeddings.0": emb_outputs[0],
        "image_embeddings.1": emb_outputs[1],
        "image_embeddings.2": emb_outputs[2],
    }

    pts, lbls, boxes = _build_prompts(points, box, w_full, h_full)

    decoder = make_session(str(decoder_path))
    try:
        iou_scores, pred_masks, _obj_logits = decoder.run(
            None,
            {
                "input_points": pts,
                "input_labels": lbls,
                "input_boxes": boxes,
                **emb_feed,
            },
        )
    except Exception as exc:
        return _error_result(image, f"SAM 2.1 mask decoder failed: {exc}")

    # pred_masks: [batch=1, num_obj=1, 3 candidates, H, W]
    # iou_scores: [batch=1, num_obj=1, 3]
    if pred_masks.ndim != 5 or iou_scores.ndim != 3:
        return _error_result(
            image,
            f"Unexpected SAM 2.1 output shape (masks={pred_masks.shape}, iou={iou_scores.shape})",
        )

    best_idx = int(np.argmax(iou_scores[0, 0]))
    logits = pred_masks[0, 0, best_idx]  # [H, W] at 256x256

    # Sigmoid → threshold → upsample back to the source frame's resolution
    # via nearest-neighbour so the binary mask stays binary.
    probs = 1.0 / (1.0 + np.exp(-logits.astype(np.float32)))
    mask_small = (probs >= threshold).astype(np.uint8) * 255
    mask_full = cv2.resize(mask_small, (w_full, h_full), interpolation=cv2.INTER_NEAREST)

    foreground = int((mask_full > 0).sum())
    total = h_full * w_full
    match_pct = (foreground / total * 100.0) if total > 0 else 0.0

    preview = _build_overlay(bgr_full, mask_full)
    rows = [
        {"metric": "match_pct", "value": round(match_pct, 2)},
        {"metric": "mask_pixels", "value": foreground},
    ]
    return ApplyResult(image=mask_full, preview=preview, rows=rows)
