"""CLIPSeg — text-conditioned segmentation.

The student types a prompt like "person" or "the green ball" and the
model produces a binary mask of where that thing is in the image. CLIPSeg
runs on CPU via ONNX Runtime, so no GPU is required.

Inputs:
  - ``params["prompt"]``   — string, mandatory. Empty/whitespace returns
    an empty mask and an ``error`` row rather than crashing.
  - ``params["threshold"]`` — float in [0, 1]. Pixels with sigmoid
    confidence above this become foreground in the binary output.
    Defaults to 0.5.
  - ``params["roi"]``      — optional ``{x, y, w, h}`` rectangle. If
    present, the model only sees that crop and the mask is placed back
    into a full-frame canvas.

Outputs:
  - ``image`` — single-channel 8-bit mask (0 / 255) at the input image's
    spatial size, so downstream binary ops (blob count, particle, etc.)
    compose naturally.
  - ``preview`` — colour overlay of the source frame with the mask
    tinted on top, for the Viewer.
  - ``rows`` — one row with ``match_pct`` (fraction of foreground pixels
    as a percentage) and ``mask_pixels`` (raw count). If the model files
    aren't downloaded yet, returns an ``error`` row instead.

Model files live under ``~/SimpleVision/Models/clipseg/`` after the
student installs the plugin from the Plugins dialog. The desktop app
sets ``SIMPLEVISION_MODELS_DIR`` so the sidecar finds them there;
pip users get the same default path automatically.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ..inference import make_session, plugin_models_dir
from ._common import scalar, to_bgr
from ._registry import ApplyResult, op


# CLIPSeg's image encoder is a ViT with 16-pixel patches; the upstream
# preprocessor resizes everything to 352x352 before feeding the model.
# These constants come from the official preprocessor_config.json.
_INPUT_SIZE = 352
_IMAGE_MEAN = np.array([0.485, 0.456, 0.406], dtype=np.float32)
_IMAGE_STD = np.array([0.229, 0.224, 0.225], dtype=np.float32)


_tokenizer: Any = None
_tokenizer_error: str | None = None


def _get_tokenizer(tokenizer_path: str) -> Any:
    """Load the BPE tokenizer once and cache it for the process lifetime."""
    global _tokenizer, _tokenizer_error
    if _tokenizer is not None:
        return _tokenizer
    if _tokenizer_error is not None:
        raise RuntimeError(_tokenizer_error)
    try:
        from tokenizers import Tokenizer
    except ImportError as exc:
        _tokenizer_error = (
            "tokenizers package not installed. Reinstall simplevision "
            f"to get text encoding support. ({exc})"
        )
        raise RuntimeError(_tokenizer_error) from exc
    _tokenizer = Tokenizer.from_file(tokenizer_path)
    return _tokenizer


def _preprocess_image(bgr: np.ndarray) -> np.ndarray:
    """Resize to 352x352 RGB float32 NCHW with ImageNet normalisation."""
    resized = cv2.resize(bgr, (_INPUT_SIZE, _INPUT_SIZE), interpolation=cv2.INTER_LINEAR)
    # OpenCV decodes as BGR; CLIPSeg's preprocessor expects RGB.
    rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
    rgb = (rgb - _IMAGE_MEAN) / _IMAGE_STD
    # HWC -> NCHW
    return np.transpose(rgb, (2, 0, 1))[np.newaxis, ...].astype(np.float32)


def _tokenize(tokenizer: Any, prompt: str) -> tuple[np.ndarray, np.ndarray]:
    """Encode ``prompt`` to (input_ids, attention_mask) as int64 numpy arrays."""
    enc = tokenizer.encode(prompt)
    input_ids = np.array([enc.ids], dtype=np.int64)
    attention_mask = np.array([enc.attention_mask], dtype=np.int64)
    return input_ids, attention_mask


def _build_overlay(bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Outline the foreground regions on a copy of ``bgr``.

    We deliberately do **not** tint the inside of the mask — students wanted
    "show me what was matched, don't paint over the rest of the picture." A
    bright magenta contour at the mask boundary is enough: every matched
    region gets a visible outline, and every other pixel is untouched so the
    underlying photo stays readable.
    """
    out = bgr.copy()
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if contours:
        cv2.drawContours(out, contours, -1, (255, 0, 255), thickness=3)
    return out


def _error_result(image: np.ndarray, message: str) -> ApplyResult:
    """Return an empty mask + a visible error row so the failure shows up in
    the editor instead of crashing the runtime."""
    h, w = image.shape[:2]
    empty = np.zeros((h, w), dtype=np.uint8)
    preview = to_bgr(image)
    return ApplyResult(
        image=empty,
        preview=preview,
        rows=[scalar("error", message)],
    )


@op("clipseg")
def op_clipseg(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    prompt = str(params.get("prompt", "")).strip()
    if not prompt:
        return _error_result(
            image,
            "Type a prompt (for example 'person' or 'red apple') to tell CLIPSeg what to look for.",
        )

    model_dir = plugin_models_dir("clipseg")
    model_path = model_dir / "onnx" / "model.onnx"
    tokenizer_path = model_dir / "tokenizer.json"
    if not model_path.exists() or not tokenizer_path.exists():
        return _error_result(
            image,
            "CLIPSeg model files not found. Install the CLIPSeg plugin from the Plugins dialog.",
        )

    try:
        tokenizer = _get_tokenizer(str(tokenizer_path))
    except RuntimeError as exc:
        return _error_result(image, str(exc))

    threshold = float(params.get("threshold", 0.5))
    threshold = max(0.0, min(1.0, threshold))

    bgr_full = to_bgr(image)
    h_full, w_full = bgr_full.shape[:2]

    # Optional ROI — feed only the cropped region to the model, then place
    # the predicted mask back into a full-frame canvas at the original
    # location so downstream ops see the full image dimensions.
    roi = params.get("roi")
    if roi:
        rx = max(0, min(int(roi.get("x", 0)), w_full - 1))
        ry = max(0, min(int(roi.get("y", 0)), h_full - 1))
        rw = max(1, min(int(roi.get("w", 1)), w_full - rx))
        rh = max(1, min(int(roi.get("h", 1)), h_full - ry))
        bgr_in = bgr_full[ry : ry + rh, rx : rx + rw]
        if bgr_in.size == 0:
            return _error_result(image, "ROI is outside the image — adjust the rectangle and try again.")
    else:
        rx = ry = 0
        rw, rh = w_full, h_full
        bgr_in = bgr_full

    pixel_values = _preprocess_image(bgr_in)
    input_ids, attention_mask = _tokenize(tokenizer, prompt)

    session = make_session(str(model_path))
    try:
        outputs = session.run(
            None,
            {
                "input_ids": input_ids,
                "pixel_values": pixel_values,
                "attention_mask": attention_mask,
            },
        )
    except Exception as exc:
        return _error_result(image, f"CLIPSeg inference failed: {exc}")

    # Output is logits of shape [num_queries, 352, 352] for a single prompt
    # (or [1, 352, 352] depending on the export). Squeeze to 2D, sigmoid,
    # threshold, then resize back to the input crop's resolution.
    logits = np.asarray(outputs[0])
    if logits.ndim == 3:
        logits_2d = logits[0]
    elif logits.ndim == 2:
        logits_2d = logits
    else:
        return _error_result(image, f"Unexpected CLIPSeg output shape {logits.shape}")

    probs = 1.0 / (1.0 + np.exp(-logits_2d.astype(np.float32)))
    mask_352 = (probs >= threshold).astype(np.uint8) * 255
    mask_crop = cv2.resize(mask_352, (rw, rh), interpolation=cv2.INTER_NEAREST)

    mask_full = np.zeros((h_full, w_full), dtype=np.uint8)
    mask_full[ry : ry + rh, rx : rx + rw] = mask_crop

    foreground = int((mask_full > 0).sum())
    total = h_full * w_full
    match_pct = (foreground / total * 100.0) if total > 0 else 0.0

    preview = _build_overlay(bgr_full, mask_full)
    rows = [
        {
            "metric": "match_pct",
            "value": round(match_pct, 2),
        },
        {
            "metric": "mask_pixels",
            "value": foreground,
        },
    ]

    return ApplyResult(image=mask_full, preview=preview, rows=rows)
