"""Shared inference helpers for ML plugin ops.

The desktop app sets ``SIMPLEVISION_MODELS_DIR`` so the sidecar can find
files under ``~/SimpleVision/Models/``. Pip users get the same default
when the env var is unset, which means a plugin op only needs to know
its plugin id to locate its weights — no path plumbing.
"""

from __future__ import annotations

import ctypes
import os
import site
import sys
from functools import lru_cache
from pathlib import Path


def _preload_cuda_libs() -> None:
    """Make the NVIDIA CUDA / cuDNN shared libs visible to ONNX Runtime.

    ``onnxruntime-gpu``'s Linux wheel ships its own ``libonnxruntime_providers_cuda.so``
    but expects the CUDA Toolkit (libcublasLt, libcudnn, etc.) to be findable
    by the dynamic loader. The NVIDIA pip packages (``nvidia-cublas-cu12``,
    ``nvidia-cudnn-cu12``, …) place the .so files under
    ``site-packages/nvidia/<comp>/lib/``, but that directory is *not* on
    LD_LIBRARY_PATH, so a plain ``import onnxruntime`` + CUDA session
    creation fails with "libcublasLt.so.12: cannot open shared object file."

    Solution: walk the pip-installed ``nvidia/*/lib`` dirs and ``dlopen``
    every .so we find with ``RTLD_GLOBAL``. Loaded that way, the symbols
    become available to libraries loaded *later* — including the CUDA
    provider that ORT lazy-loads during session creation. On non-Linux
    platforms (or when no nvidia-* wheels are installed) this is a no-op.
    """
    if sys.platform != "linux":
        return
    candidate_roots = [Path(p) for p in site.getsitepackages()]
    user_site = site.getusersitepackages()
    if user_site:
        candidate_roots.append(Path(user_site))
    seen: set[str] = set()
    for root in candidate_roots:
        nvidia_root = root / "nvidia"
        if not nvidia_root.is_dir():
            continue
        for lib_dir in nvidia_root.glob("*/lib"):
            for so in lib_dir.glob("lib*.so*"):
                key = so.name
                if key in seen:
                    continue
                seen.add(key)
                try:
                    ctypes.CDLL(str(so), mode=ctypes.RTLD_GLOBAL)
                except OSError:
                    # One missing dep shouldn't abort the rest — the
                    # CUDA EP will still surface a clear error if a
                    # required lib didn't load. Silent fallback to CPU
                    # is fine on machines without NVIDIA wheels.
                    pass


_preload_cuda_libs()

import onnxruntime as ort  # noqa: E402  (must come after the CUDA preload)


def models_dir() -> Path:
    """Root of the user's downloaded model weights."""
    raw = os.environ.get("SIMPLEVISION_MODELS_DIR")
    if raw:
        return Path(raw)
    return Path.home() / "SimpleVision" / "Models"


def plugin_models_dir(plugin_id: str) -> Path:
    """Folder where files for ``plugin_id`` are downloaded."""
    return models_dir() / plugin_id


@lru_cache(maxsize=8)
def make_session(model_path: str) -> ort.InferenceSession:
    """Cached ONNX Runtime session.

    The cache means a pipeline that hits the same op multiple times
    (e.g. on every frame in a webcam loop) loads the weights once.
    Sessions are keyed by string path so they're hashable.

    Providers are passed in preference order. ONNX Runtime walks the
    list and uses the first EP whose backing libraries are compiled
    into the loaded ``onnxruntime`` build and can be initialised on
    this machine. Naming them all is safe: an EP that isn't built in
    is silently skipped.

    - **DML** (DirectML) — Windows-only, shipped inside the
      ``onnxruntime-windowsml`` wheel the sidecar bundles on Windows.
      Talks to any DirectX 12 GPU (NVIDIA, AMD, Intel, integrated).
    - **CUDA** — Linux/macOS, shipped inside ``onnxruntime-gpu``
      together with the cu12 NVIDIA runtime wheels.
    - **CPU** — the silent fallback everywhere.
    """
    return ort.InferenceSession(
        model_path,
        providers=[
            "DmlExecutionProvider",
            "CUDAExecutionProvider",
            "CPUExecutionProvider",
        ],
    )
