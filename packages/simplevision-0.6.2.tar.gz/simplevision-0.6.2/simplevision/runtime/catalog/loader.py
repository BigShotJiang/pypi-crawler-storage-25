"""Loads the plugins catalog. v1 is a static JSON shipped with the wheel."""

from __future__ import annotations

import json
from importlib.resources import files
from typing import Any


def load_catalog() -> dict[str, Any]:
    """Return the parsed catalog JSON, including `schema_version` and `plugins`."""
    raw = files("simplevision.runtime.catalog").joinpath("plugins.json").read_text()
    return json.loads(raw)
