"""Long-lived SimpleVision sidecar request loop.

Spawned by ``sidecar_bootstrap.py``, which has already redirected fd 1 -> fd 2
and stashed the original stdout fd in $SIMPLEVISION_PROTOCOL_FD. Don't import
this module directly from Rust — Rust spawns the bootstrap.

Sessions / ML model state persist between requests so that future model ops
don't pay cold-start cost on every Run click.
"""
from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path

from . import _parse_pipeline, execute
from .server_protocol import read_message, write_message


def _open_protocol_streams():
    """Return (reader, writer) for the framed-JSON protocol.

    - reader: stdin's binary buffer (Rust writes framed requests here).
    - writer: an os.fdopen() over the dup'd fd that the bootstrap stashed.
              buffering=0 ensures a partial frame can't sit in a userspace
              buffer if the sidecar crashes mid-write.
    """
    fd_str = os.environ.get("SIMPLEVISION_PROTOCOL_FD")
    if not fd_str:
        # This module should only be reached via sidecar_bootstrap.py.
        # If the env var is missing, something has gone wrong — fail loud.
        raise RuntimeError(
            "SIMPLEVISION_PROTOCOL_FD not set; "
            "server.py must be launched via sidecar_bootstrap.py"
        )
    writer = os.fdopen(int(fd_str), "wb", buffering=0)
    return sys.stdin.buffer, writer


def serve() -> None:
    reader, writer = _open_protocol_streams()
    while True:
        try:
            msg = read_message(reader)
        except EOFError:
            return
        msg_type = msg.get("type")
        if msg_type == "ping":
            write_message(writer, {"type": "pong"})
        elif msg_type == "shutdown":
            write_message(writer, {"type": "shutdown_ack"})
            return
        elif msg_type == "capabilities":
            # Route capability queries through the long-lived sidecar so the
            # answer reflects this process's actual sys.path and loaded
            # runtime, not a separate one-shot probe with different state.
            try:
                from ._capabilities import probe_capabilities  # noqa: PLC0415
                caps = probe_capabilities()
                write_message(writer, {"type": "capabilities", "capabilities": caps})
            except Exception as exc:  # noqa: BLE001
                write_message(writer, {
                    "type": "error",
                    "code": "capabilities_failed",
                    "message": str(exc),
                    "traceback": traceback.format_exc(),
                })
        elif msg_type == "run":
            try:
                # spec arrives already-deserialized as a dict; _parse_pipeline
                # is the existing helper from simplevision/runtime/__init__.py.
                pipeline = _parse_pipeline(msg["spec"])
                frame_path = Path(msg["frame_path"])
                out_dir = Path(msg["out_dir"])
                report = execute(pipeline, frame_path, out_dir)
                write_message(writer, {"type": "report", "report": report.to_json()})
            except Exception as exc:  # noqa: BLE001 — surface to Rust
                write_message(writer, {
                    "type": "error",
                    "code": "run_failed",
                    "message": str(exc),
                    "traceback": traceback.format_exc(),
                })
        else:
            write_message(writer, {
                "type": "error",
                "code": "unknown_type",
                "message": str(msg_type),
            })


if __name__ == "__main__":
    serve()
