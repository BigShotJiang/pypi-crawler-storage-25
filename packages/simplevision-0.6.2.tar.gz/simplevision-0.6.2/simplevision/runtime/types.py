"""Type definitions and the JSON contract for the runtime.

`RunReport` is what we emit to stdout. Its shape mirrors the TS
`RunReport` in `app/src/lib/models/run.ts` so the editor can deserialise
it directly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


PIPELINE_SCHEMA_VERSION = 1


@dataclass(frozen=True)
class OutputBinding:
    """One "expose this measurement as a Python variable" binding declared
    in the editor's Output Control. Read by the student-facing
    ``simplevision`` API to populate its ``outputs`` object; ignored by
    the runtime executor itself."""

    outputId: str
    variableName: str


@dataclass(frozen=True)
class Step:
    id: str
    fnId: str
    enabled: bool
    params: dict[str, Any]
    outputs: tuple[OutputBinding, ...] = ()


@dataclass(frozen=True)
class Pipeline:
    schemaVersion: int
    name: str
    steps: tuple[Step, ...]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class StepResult:
    """Per-step result. ``rows`` is a list of dicts whose schema depends on the op:
    - blob   : { label, score, area, perim, cx, cy, circ, ok, defect? }
    - particle: { label, area, perim, circ, cx, cy, major, minor }
    - other  : { metric, value }

    ``width`` / ``height`` describe the step's output image in pixels. The
    editor uses them to size SVG overlays — without them, overlays after a
    crop or resize draw in source-frame coords and end up misaligned.
    """
    fnId: str
    timingMs: int
    outputPath: str | None
    rows: list[dict[str, Any]]
    width: int | None = None
    height: int | None = None

    def to_json(self) -> dict[str, Any]:
        return {
            "fnId": self.fnId,
            "timingMs": self.timingMs,
            "outputPath": self.outputPath,
            "rows": self.rows,
            "width": self.width,
            "height": self.height,
        }


@dataclass
class RunReport:
    status: Literal["pass", "fail"]
    totalMs: int
    results: dict[str, StepResult]

    def to_json(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "totalMs": self.totalMs,
            "results": {sid: sr.to_json() for sid, sr in self.results.items()},
        }
