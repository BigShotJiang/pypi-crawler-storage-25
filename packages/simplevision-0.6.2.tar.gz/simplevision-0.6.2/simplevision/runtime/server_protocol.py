"""Length-prefixed JSON framing for the long-lived sidecar protocol.

Each message on the wire is:
    <4-byte big-endian uint32 length><UTF-8 JSON body>

This module is intentionally small and dependency-free so it can be
imported in tests without pulling in cv2 or numpy.
"""
from __future__ import annotations

import json
import struct
from typing import Any, BinaryIO

_LEN = struct.Struct(">I")


def read_message(stream: BinaryIO) -> dict[str, Any]:
    """Read one framed message from *stream*.

    Raises EOFError if the stream ends before a complete message is read.
    """
    hdr = stream.read(4)
    if len(hdr) < 4:
        raise EOFError("short read on length header")
    (n,) = _LEN.unpack(hdr)
    body = stream.read(n)
    if len(body) < n:
        raise EOFError("short read on body")
    return json.loads(body.decode("utf-8"))


def write_message(stream: BinaryIO, msg: dict[str, Any]) -> None:
    """Write one framed message to *stream* and flush."""
    body = json.dumps(msg).encode("utf-8")
    stream.write(_LEN.pack(len(body)))
    stream.write(body)
    stream.flush()
