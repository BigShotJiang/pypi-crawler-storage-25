"""CLI wrapper used by Tauri to probe capabilities.

Usage: `python -m simplevision.runtime.capabilities_main` → prints JSON to stdout.
"""

from __future__ import annotations

import json
import sys

from ._capabilities import probe_capabilities


def main() -> int:
    json.dump(probe_capabilities(), sys.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
