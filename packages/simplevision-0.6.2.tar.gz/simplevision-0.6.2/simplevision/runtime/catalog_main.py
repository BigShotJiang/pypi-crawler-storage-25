"""CLI: print the catalog JSON to stdout."""

from __future__ import annotations

import json
import sys

from .catalog.loader import load_catalog


def main() -> int:
    json.dump(load_catalog(), sys.stdout)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
