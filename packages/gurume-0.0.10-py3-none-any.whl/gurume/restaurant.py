from __future__ import annotations

import contextlib
import re
from dataclasses import dataclass
from dataclasses import field
from enum import StrEnum
from functools import cache
from typing import Any

from bs4 import BeautifulSoup
from curl_cffi import requests

from .area_mapping import get_area_slug
from .cache import cache_set
from .cache import cached_get
from .exceptions import InvalidParameterError
from .genre_mapping import get_cuisine_slug_by_code
from .http_client import DEFAULT_IMPERSONATE
from .retry import fetch_with_retry
from .retry import fetch_with_retry_async

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/91.0.4472.124 Safari/537.36"
)
ITEM_PARSE_EXCEPTIONS = (AttributeError, TypeError, ValueError)

# Tabelog restaurant detail URLs follow `/{area}/A{area_code}/A{subarea_code}/{rst_id}/`.
# This pattern excludes magazine articles, promotional pages, and other non-restaurant links.
_RESTAURANT_URL_RE = re.compile(r"/A\d+/A\d+/\d+")


def build_search_url_and_params(
    params: dict[str, Any],
    area_slug: str | None,
    genre_code: str | None,
) -> tuple[str, dict[str, Any]]:
    """Build the Tabelog search URL and adjust params for area/genre filters.

    Area-only searches still use ``/{area_slug}/rstLst/``. Area + cuisine searches
    now require a cuisine-specific path segment (for example ``.../yakiniku/`` or
    ``.../MC0101/``) because the legacy ``LstG`` query parameter is ignored by
    current Tabelog prefecture pages.

    Args:
        params: Search params dict (mutated in place and returned).
        area_slug: Tabelog area slug like ``"tokyo"`` or ``None``.
        genre_code: Tabelog genre code like ``"RC0201"`` or ``None``.

    Returns:
        Tuple of (url, params).
    """
    url = "https://tabelog.com/rst/rstsearch"
    cuisine_slug = get_cuisine_slug_by_code(genre_code) if genre_code else None
    keyword = params.get("sk")
    if keyword:
        params.setdefault("sw", keyword)
        if genre_code:
            params["LstG"] = genre_code
        return url, params

    if area_slug and cuisine_slug:
        params.pop("sa", None)
        params.pop("LstG", None)
        return f"https://tabelog.com/{area_slug}/rstLst/{cuisine_slug}/", params

    if area_slug:
        url = f"https://tabelog.com/{area_slug}/rstLst/"
        params.pop("sa", None)
    if genre_code:
        params["LstG"] = genre_code
    return url, params


class SortType(StrEnum):
    """Search sort order."""

    STANDARD = "trend"  # Standard order, with PR店舗 first.
    RANKING = "rt"  # Ranking order.
    REVIEW_COUNT = "rvcn"  # Sort by review count.
    NEW_OPEN = "nod"  # New open.


class PriceRange(StrEnum):
    """Budget range."""

    LUNCH_UNDER_1000 = "B001"  # Lunch: up to ￥999.
    LUNCH_1000_2000 = "B002"  # Lunch: ￥1,000 to ￥1,999.
    LUNCH_2000_3000 = "B003"  # Lunch: ￥2,000 to ￥2,999.
    LUNCH_3000_4000 = "B004"  # Lunch: ￥3,000 to ￥3,999.
    LUNCH_4000_5000 = "B005"  # Lunch: ￥4,000 to ￥4,999.
    LUNCH_5000_6000 = "B006"  # Lunch: ￥5,000 to ￥5,999.
    LUNCH_6000_8000 = "B007"  # Lunch: ￥6,000 to ￥7,999.
    LUNCH_8000_10000 = "B008"  # Lunch: ￥8,000 to ￥9,999.
    LUNCH_10000_15000 = "B009"  # Lunch: ￥10,000 to ￥14,999.
    LUNCH_15000_20000 = "B010"  # Lunch: ￥15,000 to ￥19,999.
    LUNCH_20000_30000 = "B011"  # Lunch: ￥20,000 to ￥29,999.
    LUNCH_OVER_30000 = "B012"  # Lunch: ￥30,000 and up.

    DINNER_UNDER_1000 = "C001"  # Dinner: up to ￥999.
    DINNER_1000_2000 = "C002"  # Dinner: ￥1,000 to ￥1,999.
    DINNER_2000_3000 = "C003"  # Dinner: ￥2,000 to ￥2,999.
    DINNER_3000_4000 = "C004"  # Dinner: ￥3,000 to ￥3,999.
    DINNER_4000_5000 = "C005"  # Dinner: ￥4,000 to ￥4,999.
    DINNER_5000_6000 = "C006"  # Dinner: ￥5,000 to ￥5,999.
    DINNER_6000_8000 = "C007"  # Dinner: ￥6,000 to ￥7,999.
    DINNER_8000_10000 = "C008"  # Dinner: ￥8,000 to ￥9,999.
    DINNER_10000_15000 = "C009"  # Dinner: ￥10,000 to ￥14,999.
    DINNER_15000_20000 = "C010"  # Dinner: ￥15,000 to ￥19,999.
    DINNER_20000_30000 = "C011"  # Dinner: ￥20,000 to ￥29,999.
    DINNER_OVER_30000 = "C012"  # Dinner: ￥30,000 and up.


@dataclass
class Restaurant:
    """Restaurant information."""

    name: str
    url: str
    rating: float | None = None
    review_count: int | None = None
    save_count: int | None = None
    area: str | None = None
    station: str | None = None
    distance: str | None = None
    genres: list[str] = field(default_factory=list)
    description: str | None = None
    lunch_price: str | None = None
    dinner_price: str | None = None
    address: str | None = None
    phone: str | None = None
    business_hours: str | None = None
    closed_days: str | None = None
    reservation_url: str | None = None
    has_vpoint: bool = False
    has_reservation: bool = False
    image_urls: list[str] = field(default_factory=list)


@dataclass
class RestaurantSearchRequest:
    """Restaurant search request."""

    # Basic search parameters.
    area: str | None = None
    keyword: str | None = None
    genre_code: str | None = None  # Cuisine genre code, for example RC0107 for すき焼き.

    # Reservation filters.
    reservation_date: str | None = None  # YYYYMMDD
    reservation_time: str | None = None  # HHMM
    party_size: int | None = None

    # Sorting and pagination.
    sort_type: SortType = SortType.STANDARD
    page: int = 1

    # Search filters.
    price_range: PriceRange | None = None
    online_booking_only: bool = False
    seat_only: bool = False
    new_open: bool = False

    # Restaurant features.
    has_private_room: bool = False
    has_parking: bool = False
    smoking_allowed: bool = False
    card_accepted: bool = False

    def __post_init__(self) -> None:
        # Trim leading and trailing whitespace from area and keyword.
        if self.area is not None:
            self.area = self.area.strip()
        if self.keyword is not None:
            self.keyword = self.keyword.strip()

        # Validate YYYYMMDD date format.
        if self.reservation_date is not None and not re.fullmatch(r"\d{8}", self.reservation_date):
            raise InvalidParameterError(
                f"reservation_date 必須是 YYYYMMDD 格式，例如：20250715。收到：{self.reservation_date}"
            )

        # Validate HHMM time format.
        if self.reservation_time is not None and not re.fullmatch(r"\d{4}", self.reservation_time):
            raise InvalidParameterError(f"reservation_time 必須是 HHMM 格式，例如：1900。收到：{self.reservation_time}")

        # Validate party size bounds.
        if self.party_size is not None and not (1 <= self.party_size <= 100):
            raise InvalidParameterError(f"party_size 必須在 1 到 100 之間。收到：{self.party_size}")

        # Validate page number.
        if self.page < 1:
            raise InvalidParameterError(f"page 必須 >= 1。收到：{self.page}")

    def _build_params(self) -> dict[str, Any]:
        """Build search parameters."""
        params: dict[str, str] = {
            "SrtT": self.sort_type.value,
            "PG": str(self.page),
        }
        self._apply_basic_params(params)
        self._apply_reservation_params(params)
        self._apply_filter_params(params)
        self._apply_feature_params(params)
        return params

    def _apply_basic_params(self, params: dict[str, str]) -> None:
        if self.area:
            params["sa"] = self.area
        if self.keyword:
            params["sk"] = self.keyword

    def _apply_reservation_params(self, params: dict[str, str]) -> None:
        if self.reservation_date:
            params["svd"] = self.reservation_date
        if self.reservation_time:
            params["svt"] = self.reservation_time
        if self.party_size:
            params["svps"] = str(self.party_size)

    def _apply_filter_params(self, params: dict[str, str]) -> None:
        if self.price_range:
            params["LstCos"] = self.price_range.value
        if self.online_booking_only:
            params["ChkOnlineBooking"] = "1"
        if self.seat_only:
            params["ChkSeatOnly"] = "1"
        if self.new_open:
            params["ChkNewOpen"] = "1"

    def _apply_feature_params(self, params: dict[str, str]) -> None:
        if self.has_private_room:
            params["ChkRoom"] = "1"
        if self.has_parking:
            params["ChkParking"] = "1"
        if self.smoking_allowed:
            params["LstSmoking"] = "1"
        if self.card_accepted:
            params["ChkCard"] = "1"

    def _parse_restaurants(self, html: str) -> list[Restaurant]:
        """Parse restaurant information."""
        soup = BeautifulSoup(html, "lxml")
        restaurants = []

        # Check for the upstream "area not found" error message.
        error_elem = soup.find("div", class_="rstlist-notfound")
        if error_elem or "該当のエリア・駅が見つかりませんでした" in html:
            # Invalid areas otherwise fall back to national ranking; return no results instead.
            return []

        # Find restaurant list items using current and fallback selectors.
        restaurant_items = soup.find_all("div", class_="list-rst")
        if not restaurant_items:
            # Fallback selector.
            restaurant_items = soup.find_all("li", class_="list-rst")

        for item in restaurant_items:
            try:
                restaurant = self._parse_restaurant_item(item)
                if restaurant is not None:
                    restaurants.append(restaurant)
            except ITEM_PARSE_EXCEPTIONS:
                # Skip malformed items.
                continue

        return restaurants

    def _parse_restaurant_item(self, item: Any) -> Restaurant | None:
        name, url = self._parse_basic_info(item)
        if not name:
            return None

        review_count, save_count, rating = self._parse_counts(item)
        area, station, distance, genres = self._parse_area_and_genres(item)
        description = self._get_text(item.find("div", class_="list-rst__catch"))
        lunch_price, dinner_price = self._parse_prices(item)

        return Restaurant(
            name=name,
            url=url,
            rating=rating,
            review_count=review_count,
            save_count=save_count,
            area=area,
            station=station,
            distance=distance,
            genres=self._merge_genres(item, genres),
            description=description,
            lunch_price=lunch_price,
            dinner_price=dinner_price,
            has_vpoint=bool(item.find("span", class_="c-badge-tpoint")),
            has_reservation=bool(item.find("div", class_="list-rst__booking-btn")),
            image_urls=self._parse_image_urls(item),
        )

    def _parse_basic_info(self, item: Any) -> tuple[str | None, str]:
        name_elem = item.find("a", class_="list-rst__rst-name-target")
        if not name_elem:
            # Fallback: only accept href if it points to a real restaurant page.
            # Skip magazine.tabelog.com promotional items, ads, and unrelated paths.
            fallback = item.find("a", href=True)
            fallback_href = str(fallback.get("href", "")) if fallback else ""
            if fallback and _RESTAURANT_URL_RE.search(fallback_href):
                name_elem = fallback
            else:
                return None, ""

        href = name_elem.get("href", "")
        url = href if href.startswith("http") else f"https://tabelog.com{href}"
        # Skip magazine/promo items that slipped through
        if "magazine.tabelog.com" in url:
            return None, ""
        return name_elem.get_text(strip=True), url

    def _parse_counts(self, item: Any) -> tuple[int | None, int | None, float | None]:
        rating = self._parse_float(item.find("span", class_="c-rating__val"))
        review_count = self._parse_int(item.find("em", class_="list-rst__rvw-count-num"))
        save_elem = item.find("span", class_="list-rst__save-count-num") or item.find(
            "em", class_="list-rst__save-count-num"
        )
        save_count = self._parse_int(save_elem, strip_commas=True)
        return review_count, save_count, rating

    def _parse_area_and_genres(self, item: Any) -> tuple[str | None, str | None, str | None, list[str]]:
        area = None
        station = None
        distance = None
        genres: list[str] = []
        area_genre_elem = item.find(class_="list-rst__area-genre")
        if not area_genre_elem:
            return area, station, distance, genres

        area_genre_text = area_genre_elem.get_text(strip=True).strip()
        if "/" in area_genre_text:
            parts = area_genre_text.split("/")
            if len(parts) >= 2:
                area = self._strip_prefecture(parts[0].strip())
                genre_part = parts[1].strip()
                if genre_part:
                    genres = [genre_part]
            return area, station, distance, genres

        if "、" in area_genre_text:
            parts = [p.strip() for p in area_genre_text.split("、") if p.strip()]
            if parts:
                area = parts[0]
            if len(parts) >= 2:
                station_part = parts[1]
                distance_match = re.search(r"(\d+\s?m)", station_part)
                if distance_match:
                    distance = distance_match.group(1).replace(" ", "")
                station_match = re.search(r"([^\d]+駅)", station_part)
                if station_match:
                    station = station_match.group(1).strip()
            return area, station, distance, genres

        return self._strip_prefecture(area_genre_text), station, distance, genres

    def _parse_prices(self, item: Any) -> tuple[str | None, str | None]:
        lunch_price = None
        dinner_price = None
        price_elem = item.find("span", class_="list-rst__budget-val")
        if not price_elem:
            return lunch_price, dinner_price

        price_text = price_elem.get_text(strip=True)
        if "ランチ" in price_text:
            lunch_price = price_text
        elif "ディナー" in price_text:
            dinner_price = price_text
        return lunch_price, dinner_price

    def _merge_genres(self, item: Any, genres: list[str]) -> list[str]:
        genre_elem = item.find(class_="list-rst__genre")
        if not genre_elem:
            return genres

        for genre in [g.strip() for g in genre_elem.get_text(strip=True).split("、") if g.strip()]:
            if genre not in genres:
                genres.append(genre)
        return genres

    def _parse_image_urls(self, item: Any) -> list[str]:
        img_elem = item.find("img", class_="list-rst__photo-img")
        if img_elem and img_elem.get("src"):
            return [img_elem.get("src")]
        return []

    def _get_text(self, element: Any) -> str | None:
        return element.get_text(strip=True) if element else None

    def _parse_float(self, element: Any) -> float | None:
        if not element:
            return None
        with contextlib.suppress(ValueError):
            return float(element.get_text(strip=True))
        return None

    def _parse_int(self, element: Any, *, strip_commas: bool = False) -> int | None:
        if not element:
            return None
        value = element.get_text(strip=True)
        if strip_commas:
            value = value.replace(",", "")
        with contextlib.suppress(ValueError):
            return int(value)
        return None

    def _strip_prefecture(self, text: str) -> str:
        return text.split("]")[-1].strip() if "]" in text else text

    def search_sync(self, use_cache: bool = True, use_retry: bool = True) -> list[Restaurant]:
        """Run the search synchronously.

        Args:
            use_cache: Whether to use the cache. Defaults to True.
            use_retry: Whether to use retry handling. Defaults to True.

        Returns:
            List of restaurants.
        """
        params = self._build_params()
        headers = {"User-Agent": USER_AGENT}

        area_slug = get_area_slug(self.area) if self.area else None
        url, params = build_search_url_and_params(params, area_slug, self.genre_code)

        # Check cache.
        if use_cache:
            cached_html = cached_get(url, params)
            if cached_html is not None:
                return self._parse_restaurants(cached_html)

        # Execute the request with or without retry handling.
        if use_retry:
            resp = fetch_with_retry(url=url, params=params, headers=headers, timeout=30.0)
        else:
            resp = requests.get(
                url=url,
                params=params,
                headers=headers,
                timeout=30.0,
                allow_redirects=True,
                impersonate=DEFAULT_IMPERSONATE,
            )
            resp.raise_for_status()

        # Store in cache.
        if use_cache:
            cache_set(url, params, resp.text, ttl=1800.0)  # 30 minutes TTL

        return self._parse_restaurants(resp.text)

    async def search(self, use_cache: bool = True, use_retry: bool = True) -> list[Restaurant]:
        """Run the search asynchronously.

        Args:
            use_cache: Whether to use the cache. Defaults to True.
            use_retry: Whether to use retry handling. Defaults to True.

        Returns:
            List of restaurants.
        """
        params = self._build_params()
        headers = {"User-Agent": USER_AGENT}

        area_slug = get_area_slug(self.area) if self.area else None
        url, params = build_search_url_and_params(params, area_slug, self.genre_code)

        # Check cache.
        if use_cache:
            cached_html = cached_get(url, params)
            if cached_html is not None:
                return self._parse_restaurants(cached_html)

        # Execute the request with or without retry handling.
        if use_retry:
            resp = await fetch_with_retry_async(url=url, params=params, headers=headers, request_timeout=30.0)
        else:
            async with requests.AsyncSession(
                timeout=30.0,
                allow_redirects=True,
                impersonate=DEFAULT_IMPERSONATE,
            ) as client:
                resp = await client.get(
                    url=url,
                    params=params,
                    headers=headers,
                )
                resp.raise_for_status()

        # Store in cache.
        if use_cache:
            cache_set(url, params, resp.text, ttl=1800.0)  # 30 minutes TTL

        return self._parse_restaurants(resp.text)

    def do_sync(self) -> list[Restaurant]:
        """Run the search synchronously. Deprecated; use search_sync()."""
        return self.search_sync()

    async def do(self) -> list[Restaurant]:
        """Run the search asynchronously. Deprecated; use search()."""
        return await self.search()


@cache
def query_restaurants(
    area: str | None = None,
    keyword: str | None = None,
    reservation_date: str | None = None,
    reservation_time: str | None = None,
    party_size: int | None = None,
    sort_type: SortType = SortType.STANDARD,
    page: int = 1,
    price_range: PriceRange | None = None,
    online_booking_only: bool = False,
    seat_only: bool = False,
    new_open: bool = False,
    has_private_room: bool = False,
    has_parking: bool = False,
    smoking_allowed: bool = False,
    card_accepted: bool = False,
) -> list[Restaurant]:
    """Quick restaurant lookup."""
    return RestaurantSearchRequest(
        area=area,
        keyword=keyword,
        reservation_date=reservation_date,
        reservation_time=reservation_time,
        party_size=party_size,
        sort_type=sort_type,
        page=page,
        price_range=price_range,
        online_booking_only=online_booking_only,
        seat_only=seat_only,
        new_open=new_open,
        has_private_room=has_private_room,
        has_parking=has_parking,
        smoking_allowed=smoking_allowed,
        card_accepted=card_accepted,
    ).search_sync()
