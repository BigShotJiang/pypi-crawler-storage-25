"""silk._compat — backward-compatibility aliases for pre-silk names.

All of these names were renamed in the Phase 2 circuitsilk restructure.
They remain importable here during the transition period.
Import from silk.* for the current API.

Will be removed in a future major version.
"""
from silk.exceptions import CircuitError as PyNetlistError          # noqa: F401
from silk.circuit.modules import Module as PyModule                 # noqa: F401
from silk.circuit.module_test import ModuleTestbench as PyModuleTest  # noqa: F401
from silk.signals.base import Signal as PySignal                    # noqa: F401
from silk.signals.spice import NgspiceSignal as PySpiceSignal       # noqa: F401
from silk.db.integration import TrackedModule as PyTrackedNetlist   # noqa: F401
from silk.db.circuit_db import Database as CircuitDatabase          # noqa: F401
from silk.optimize.optimizer import Optimizer as CircuitOptimizer   # noqa: F401
from silk.optimize.parameter_space import Space as ParameterSpace   # noqa: F401
from silk.codegen.generator import Generator as CircuitCodeGenerator  # noqa: F401

__all__ = [
    "PyNetlistError", "PyModule", "PyModuleTest", "PySignal", "PySpiceSignal",
    "PyTrackedNetlist", "CircuitDatabase", "CircuitOptimizer", "ParameterSpace",
    "CircuitCodeGenerator",
]
