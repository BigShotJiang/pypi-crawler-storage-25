"""
Circuit Design Database with Version Control and Stage Management
Supports tracking circuits, nets, transistors, and simulation results across design stages

UPDATED: Refactored module tracking to:
- Store unique modules in separate 'modules' table
- Use junction table 'circuit_modules' to link circuits to modules
- Avoid module duplication across circuit versions
"""

import sqlite3
import json
import uuid
import hashlib
from datetime import datetime
from typing import Optional, List, Dict, Any, Tuple
from enum import Enum
from pathlib import Path


class DesignStage(Enum):
    """Design stages in the flow"""
    DEV = "dev"
    STABLE = "stable"
    POST_LAYOUT = "post_layout"
    TAPEOUT = "tapeout"


class Database:
    """Main database interface for circuit design data"""

    def __init__(self, db_path: str = "circuit_design.db"):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row  # Enable column access by name
        self._create_tables()

    def _create_tables(self):
        """Create all necessary database tables"""
        cursor = self.conn.cursor()

        # Circuit versions table - main design objects
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS circuit_versions (
                version_id TEXT PRIMARY KEY,
                circuit_name TEXT NOT NULL,
                version TEXT NOT NULL,
                stage TEXT NOT NULL CHECK(stage IN ('dev', 'stable', 'post_layout', 'tapeout')),
                is_locked BOOLEAN DEFAULT 0,
                parent_version_id TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by TEXT,
                description TEXT,
                netlist_path TEXT,
                metadata TEXT,  -- JSON string for flexible data
                simulation_summary TEXT,  -- Auto-generated summary of all simulations
                last_summary_update TIMESTAMP,
                FOREIGN KEY (parent_version_id) REFERENCES circuit_versions(version_id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS devices (
                device_id TEXT PRIMARY KEY,
                circuit_version_id TEXT NOT NULL,
                name TEXT NOT NULL,
                type TEXT NOT NULL,
                model TEXT,
                properties TEXT,  -- JSON for additional properties
                FOREIGN KEY (circuit_version_id) REFERENCES circuit_versions(version_id)
            )
        """)

        # Nets table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS nets (
                net_id TEXT PRIMARY KEY,
                circuit_version_id TEXT NOT NULL,
                name TEXT NOT NULL,
                net_type TEXT,  -- signal, power, ground, etc.
                properties TEXT,  -- JSON for additional properties
                FOREIGN KEY (circuit_version_id) REFERENCES circuit_versions(version_id)
            )
        """)

        # Simulation results table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS simulation_results (
                sim_id TEXT PRIMARY KEY,
                circuit_version_id TEXT NOT NULL,
                object_id TEXT,  -- Can reference transistor, net, or circuit
                object_type TEXT CHECK(object_type IN ('circuit', 'transistor', 'net')),
                sim_type TEXT,  -- dc, ac, tran, noise, etc.
                corner TEXT,  -- Process corner: tt, ss, ff, sf, fs, etc.
                temperature REAL,  -- Temperature in Celsius
                voltage REAL,  -- Supply voltage
                parameter TEXT NOT NULL,
                value REAL,
                value_text TEXT,  -- For non-numeric results
                unit TEXT,
                tool_name TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                conditions TEXT,  -- JSON for additional simulation conditions
                FOREIGN KEY (circuit_version_id) REFERENCES circuit_versions(version_id)
            )
        """)

        # Parasitics table (for post-layout data)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS parasitics (
                parasitic_id TEXT PRIMARY KEY,
                circuit_version_id TEXT NOT NULL,
                net_id TEXT NOT NULL,
                parasitic_type TEXT CHECK(parasitic_type IN ('resistance', 'capacitance', 'inductance')),
                value REAL,
                unit TEXT,
                from_node TEXT,
                to_node TEXT,
                extraction_tool TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (circuit_version_id) REFERENCES circuit_versions(version_id),
                FOREIGN KEY (net_id) REFERENCES nets(net_id)
            )
        """)

        # Stage releases table - snapshots for teams
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS releases (
                release_id TEXT PRIMARY KEY,
                release_name TEXT UNIQUE NOT NULL,
                stage TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                created_by TEXT,
                notes TEXT,
                status TEXT DEFAULT 'active' CHECK(status IN ('active', 'superseded', 'archived'))
            )
        """)

        # Release contents - which circuits are in each release
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS release_contents (
                release_id TEXT NOT NULL,
                circuit_version_id TEXT NOT NULL,
                PRIMARY KEY (release_id, circuit_version_id),
                FOREIGN KEY (release_id) REFERENCES releases(release_id),
                FOREIGN KEY (circuit_version_id) REFERENCES circuit_versions(version_id)
            )
        """)

        # ===== NEW MODULE TRACKING SCHEMA =====

        # Modules table - stores unique module definitions
        # A module is uniquely identified by its content hash
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS modules (
                module_id TEXT PRIMARY KEY,
                module_name TEXT NOT NULL,
                module_path TEXT NOT NULL,
                module_hash TEXT NOT NULL,
                device_count INTEGER DEFAULT 0,
                structure TEXT,  -- JSON of module structure (devices, nets, submodules)
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(module_hash)
            )
        """)

        # Junction table - links circuits to modules (many-to-many)
        # Allows same module to be reused across multiple circuit versions
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS circuit_modules (
                circuit_version_id TEXT NOT NULL,
                module_id TEXT NOT NULL,
                instance_name TEXT,  -- Instance name in the circuit (e.g., 'ldo_output_1')
                position_in_hierarchy INTEGER,  -- Order/depth in hierarchy
                PRIMARY KEY (circuit_version_id, module_id, instance_name),
                FOREIGN KEY (circuit_version_id) REFERENCES circuit_versions(version_id) ON DELETE CASCADE,
                FOREIGN KEY (module_id) REFERENCES modules(module_id) ON DELETE CASCADE
            )
        """)

        # ===== END NEW MODULE TRACKING SCHEMA =====

        # Create useful indexes
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_circuit_name_stage 
            ON circuit_versions(circuit_name, stage, created_at DESC)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_sim_results_circuit 
            ON simulation_results(circuit_version_id, parameter)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_modules_hash 
            ON modules(module_hash)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_modules_name 
            ON modules(module_name)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_circuit_modules_circuit 
            ON circuit_modules(circuit_version_id)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_circuit_modules_module 
            ON circuit_modules(module_id)
        """)

        self.conn.commit()

    # ===== MODULE MANAGEMENT METHODS =====

    def insert_or_get_module(self, module_name: str, module_path: str,
                             module_hash: str, device_count: int = 0,
                             structure: Dict = None) -> str:
        """
        Insert a new module or return existing module_id if hash already exists.
        This prevents module duplication across circuit versions.

        Args:
            module_name: Name of the module (e.g., 'ldo_output_stage')
            module_path: Hierarchical path (e.g., 'top.ldo.output')
            module_hash: Content hash of the module structure
            device_count: Number of devices in the module
            structure: Dict containing module structure (devices, nets, submodules)

        Returns:
            str: module_id (existing or newly created)
        """
        cursor = self.conn.cursor()

        # Check if module with this hash already exists
        cursor.execute("""
            SELECT module_id FROM modules WHERE module_hash = ?
        """, (module_hash,))

        row = cursor.fetchone()
        if row:
            # Module already exists, return its ID
            return row[0]

        # Module doesn't exist, create new one
        module_id = str(uuid.uuid4())
        cursor.execute("""
            INSERT INTO modules 
            (module_id, module_name, module_path, module_hash, device_count, structure)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (module_id, module_name, module_path, module_hash, device_count,
              json.dumps(structure) if structure else None))

        self.conn.commit()
        return module_id

    def link_module_to_circuit(self, circuit_version_id: str, module_id: str,
                               instance_name: str = None, position: int = 0):
        """
        Create a link between a circuit and a module in the junction table.

        Args:
            circuit_version_id: Circuit version ID
            module_id: Module ID to link
            instance_name: Instance name in the circuit (optional)
            position: Position in hierarchy (optional)
        """
        cursor = self.conn.cursor()

        # Use INSERT OR REPLACE to handle duplicates gracefully
        cursor.execute("""
            INSERT OR REPLACE INTO circuit_modules 
            (circuit_version_id, module_id, instance_name, position_in_hierarchy)
            VALUES (?, ?, ?, ?)
        """, (circuit_version_id, module_id, instance_name, position))

        self.conn.commit()

    def get_circuit_modules(self, circuit_version_id: str) -> List[Dict]:
        """
        Get all modules associated with a circuit version.

        Args:
            circuit_version_id: Circuit version ID

        Returns:
            List of dicts containing module information
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT m.module_id, m.module_name, m.module_path, m.module_hash,
                   m.device_count, m.structure, m.created_at,
                   cm.instance_name, cm.position_in_hierarchy
            FROM modules m
            JOIN circuit_modules cm ON m.module_id = cm.module_id
            WHERE cm.circuit_version_id = ?
            ORDER BY cm.position_in_hierarchy
        """, (circuit_version_id,))

        modules = []
        for row in cursor.fetchall():
            modules.append({
                'module_id': row[0],
                'module_name': row[1],
                'module_path': row[2],
                'module_hash': row[3],
                'device_count': row[4],
                'structure': json.loads(row[5]) if row[5] else None,
                'created_at': row[6],
                'instance_name': row[7],
                'position_in_hierarchy': row[8]
            })

        return modules

    def get_circuits_using_module(self, module_hash: str) -> List[Dict]:
        """
        Find all circuits that use a module with the given hash.
        Useful for impact analysis when considering module changes.

        Args:
            module_hash: Hash of the module

        Returns:
            List of circuit version info dicts
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT cv.version_id, cv.circuit_name, cv.version, cv.stage, cv.created_at
            FROM circuit_versions cv
            JOIN circuit_modules cm ON cv.version_id = cm.circuit_version_id
            JOIN modules m ON cm.module_id = m.module_id
            WHERE m.module_hash = ?
            ORDER BY cv.created_at DESC
        """, (module_hash,))

        circuits = []
        for row in cursor.fetchall():
            circuits.append({
                'version_id': row[0],
                'circuit_name': row[1],
                'version': row[2],
                'stage': row[3],
                'created_at': row[4]
            })

        return circuits

    def compare_circuit_modules(self, circuit_id_1: str, circuit_id_2: str) -> Dict[str, Any]:
        """
        Compare modules between two circuit versions to see what changed.

        Args:
            circuit_id_1: First circuit version ID
            circuit_id_2: Second circuit version ID

        Returns:
            Dict with 'added', 'removed', 'unchanged' module lists
        """
        modules_1 = {m['module_hash']: m for m in self.get_circuit_modules(circuit_id_1)}
        modules_2 = {m['module_hash']: m for m in self.get_circuit_modules(circuit_id_2)}

        hashes_1 = set(modules_1.keys())
        hashes_2 = set(modules_2.keys())

        return {
            'added': [modules_2[h] for h in (hashes_2 - hashes_1)],
            'removed': [modules_1[h] for h in (hashes_1 - hashes_2)],
            'unchanged': [modules_2[h] for h in (hashes_1 & hashes_2)]
        }

    # ===== END MODULE MANAGEMENT METHODS =====

    def create_circuit(self, name: str, version: str = "1.0",
                      stage: DesignStage = DesignStage.DEV,
                      created_by: str = "user",
                      description: str = "",
                      netlist_path: str = None,
                      metadata: Dict = None) -> str:
        """Create a new circuit version"""
        version_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO circuit_versions 
            (version_id, circuit_name, version, stage, created_by, description, 
             netlist_path, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (version_id, name, version, stage.value, created_by, description,
              netlist_path, json.dumps(metadata) if metadata else None))

        self.conn.commit()
        print(f"✓ Created circuit '{name}' version {version} at stage '{stage.value}'")
        return version_id

    def update_circuit(self, circuit_name: str, new_version: str,
                      stage: DesignStage = DesignStage.DEV,
                      created_by: str = "user",
                      description: str = "",
                      base_version: str = None) -> str:
        """Create a new version of an existing circuit"""

        # Find the base version to link from
        parent_id = None
        if base_version:
            parent = self.get_version(circuit_name, base_version)
            if parent:
                parent_id = parent['version_id']
        else:
            # Use the latest version in the same stage as parent
            parent = self.get_latest(circuit_name, stage)
            if parent:
                parent_id = parent['version_id']

        version_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO circuit_versions 
            (version_id, circuit_name, version, stage, created_by, description, parent_version_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (version_id, circuit_name, new_version, stage.value, created_by, description, parent_id))

        self.conn.commit()
        print(f"✓ Created '{circuit_name}' version {new_version} at stage '{stage.value}'")
        return version_id

    def add_device(self, circuit_version_id: str, name: str, device_type: str,
                   model: str = None, **properties) -> str:
        """Add a device (transistor, resistor, etc.) to a circuit version"""
        device_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO devices
            (device_id, circuit_version_id, name, type, model, properties)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (device_id, circuit_version_id, name, device_type, model,
              json.dumps(properties) if properties else None))

        self.conn.commit()
        return device_id

    def add_transistor(self, circuit_version_id: str, name: str,
                       transistor_type: str, width: float, length: float,
                       multiplier: int = 1, model: str = None) -> str:
        """Add a transistor device to a circuit version"""
        return self.add_device(circuit_version_id, name, transistor_type,
                               model=model, width=width, length=length,
                               multiplier=multiplier)

    def add_net(self, circuit_version_id: str, name: str, net_type: str = None,
                **properties) -> str:
        """Add a net to a circuit version"""
        net_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO nets
            (net_id, circuit_version_id, name, net_type, properties)
            VALUES (?, ?, ?, ?, ?)
        """, (net_id, circuit_version_id, name, net_type,
              json.dumps(properties) if properties else None))

        self.conn.commit()
        return net_id

    def add_simulation_result(self, circuit_version_id: str, parameter: str,
                             value: float = None, value_text: str = None,
                             unit: str = None, object_id: str = None,
                             object_type: str = 'circuit', sim_type: str = None,
                             corner: str = None, temperature: float = None,
                             voltage: float = None, tool_name: str = None,
                             conditions: Dict = None) -> str:
        """Add a simulation result"""
        sim_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO simulation_results
            (sim_id, circuit_version_id, object_id, object_type, sim_type,
             corner, temperature, voltage, parameter, value, value_text, unit,
             tool_name, conditions)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (sim_id, circuit_version_id, object_id, object_type, sim_type,
              corner, temperature, voltage, parameter, value, value_text, unit,
              tool_name, json.dumps(conditions) if conditions else None))

        self.conn.commit()
        return sim_id

    def get_simulation_results(self, circuit_version_id: str,
                              parameter: str = None,
                              corner: str = None) -> List[Dict]:
        """Get simulation results for a circuit version"""
        cursor = self.conn.cursor()

        conditions = ["circuit_version_id = ?"]
        params = [circuit_version_id]
        if parameter:
            conditions.append("parameter = ?")
            params.append(parameter)
        if corner:
            conditions.append("corner = ?")
            params.append(corner)
        where_clause = " AND ".join(conditions)
        cursor.execute(f"""
            SELECT sim_id, parameter, value, value_text, unit, sim_type,
                   corner, temperature, voltage, timestamp
            FROM simulation_results
            WHERE {where_clause}
            ORDER BY timestamp DESC
        """, params)

        return [dict(row) for row in cursor.fetchall()]

    def get_latest(self, circuit_name: str, stage: DesignStage = None) -> Optional[Dict]:
        """Get the latest version of a circuit, optionally filtered by stage"""
        cursor = self.conn.cursor()

        if stage:
            cursor.execute("""
                SELECT version_id, circuit_name, version, stage, created_at,
                       netlist_path, description, metadata
                FROM circuit_versions
                WHERE circuit_name = ? AND stage = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, (circuit_name, stage.value))
        else:
            cursor.execute("""
                SELECT version_id, circuit_name, version, stage, created_at,
                       netlist_path, description, metadata
                FROM circuit_versions
                WHERE circuit_name = ?
                ORDER BY created_at DESC
                LIMIT 1
            """, (circuit_name,))

        row = cursor.fetchone()
        if row:
            return {
                'version_id': row[0],
                'circuit_name': row[1],
                'version': row[2],
                'stage': row[3],
                'created_at': row[4],
                'netlist_path': row[5],
                'description': row[6],
                'metadata': json.loads(row[7]) if row[7] else {}
            }
        return None

    def get_version(self, circuit_name: str, version: str) -> Optional[Dict]:
        """Get a specific version of a circuit"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT version_id, circuit_name, version, stage, created_at,
                   netlist_path, description, metadata
            FROM circuit_versions
            WHERE circuit_name = ? AND version = ?
        """, (circuit_name, version))

        row = cursor.fetchone()
        if row:
            return {
                'version_id': row[0],
                'circuit_name': row[1],
                'version': row[2],
                'stage': row[3],
                'created_at': row[4],
                'netlist_path': row[5],
                'description': row[6],
                'metadata': json.loads(row[7]) if row[7] else {}
            }
        return None

    def promote_circuit(self, circuit_name: str, from_stage: DesignStage,
                       to_stage: DesignStage, new_version: str = None,
                       lock: bool = True, created_by: str = "user",
                       description: str = None) -> str:
        """Promote a circuit from one stage to another"""
        # Get latest version in source stage
        source = self.get_latest(circuit_name, from_stage)
        if not source:
            raise ValueError(f"No circuit '{circuit_name}' found in stage '{from_stage.value}'")

        # Create new version in target stage
        if new_version is None:
            new_version = f"{source['version']}.{to_stage.value}"
        if description is None:
            description = f"Promoted from {from_stage.value}"
        version_id = self.update_circuit(
            circuit_name=circuit_name,
            new_version=new_version,
            stage=to_stage,
            created_by=created_by,
            description=description,
            base_version=source['version']
        )

        if lock:
            self.lock_circuit(circuit_name, new_version)

        return version_id

    def lock_circuit(self, circuit_name: str, version: str):
        """Lock a circuit version to prevent modifications"""
        circuit = self.get_version(circuit_name, version)
        if not circuit:
            raise ValueError(f"Circuit '{circuit_name}' version '{version}' not found")

        cursor = self.conn.cursor()
        cursor.execute("""
            UPDATE circuit_versions
            SET is_locked = 1
            WHERE version_id = ?
        """, (circuit['version_id'],))

        self.conn.commit()
        print(f"✓ Locked circuit '{circuit_name}' version {version}")

    def get_circuit_by_id(self, version_id: str) -> Optional[Dict]:
        """
        Get circuit information by version_id

        Args:
            version_id: Unique version ID

        Returns:
            dict: Circuit info or None if not found
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT version_id, circuit_name, version, stage, created_at,
                   netlist_path, description, metadata
            FROM circuit_versions
            WHERE version_id = ?
        """, (version_id,))

        row = cursor.fetchone()
        if row:
            return {
                'version_id': row[0],
                'circuit_name': row[1],
                'version': row[2],
                'stage': row[3],
                'created_at': row[4],
                'netlist_path': row[5],
                'description': row[6],
                'metadata': json.loads(row[7]) if row[7] else {}
            }
        return None

    def get_circuit_by_version_id(self, version_id: str) -> Optional[Dict]:
        """
        Get circuit by its unique version_id (alias for get_circuit_by_id)

        Args:
            version_id: Unique version ID

        Returns:
            dict: Circuit info or None if not found
        """
        return self.get_circuit_by_id(version_id)

    def get_all_circuit_versions(self, circuit_name: str, order_by: str = 'created_at') -> List[Dict]:
        """
        Get all versions of a circuit

        Args:
            circuit_name: Name of the circuit
            order_by: Column to order by ('created_at', 'version', 'stage')

        Returns:
            list: List of circuit info dicts
        """
        valid_order = ['created_at', 'version', 'stage']
        if order_by not in valid_order:
            order_by = 'created_at'

        cursor = self.conn.cursor()
        cursor.execute(f"""
            SELECT version_id, circuit_name, version, stage, created_at,
                   netlist_path, description, metadata
            FROM circuit_versions
            WHERE circuit_name = ?
            ORDER BY {order_by} DESC
        """, (circuit_name,))

        circuits = []
        for row in cursor.fetchall():
            circuits.append({
                'version_id': row[0],
                'circuit_name': row[1],
                'version': row[2],
                'stage': row[3],
                'created_at': row[4],
                'netlist_path': row[5],
                'description': row[6],
                'metadata': json.loads(row[7]) if row[7] else {}
            })

        return circuits

    def get_most_simulated_circuit(self, circuit_name: str) -> Optional[Dict]:
        """
        Get the circuit version with the highest run count

        Args:
            circuit_name: Name of the circuit

        Returns:
            dict: Circuit info with highest run_count or None if not found
        """
        circuits = self.get_all_circuit_versions(circuit_name)

        if not circuits:
            return None

        # Find circuit with max run_count
        max_runs = 0
        most_simulated = circuits[0]

        for circuit in circuits:
            run_count = circuit['metadata'].get('run_count', 0)
            if run_count > max_runs:
                max_runs = run_count
                most_simulated = circuit

        return most_simulated

    def create_release(self, release_name: str, stage: DesignStage,
                      circuit_names: List[str] = None,
                      created_by: str = "user", notes: str = "") -> str:
        """Create a release snapshot of circuits at a stage"""
        release_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO releases
            (release_id, release_name, stage, created_by, notes)
            VALUES (?, ?, ?, ?, ?)
        """, (release_id, release_name, stage.value, created_by, notes))

        # Add circuits to release
        if circuit_names:
            for name in circuit_names:
                circuit = self.get_latest(name, stage)
                if circuit:
                    cursor.execute("""
                        INSERT INTO release_contents
                        (release_id, circuit_version_id)
                        VALUES (?, ?)
                    """, (release_id, circuit['version_id']))

        self.conn.commit()
        print(f"✓ Created release '{release_name}' at stage '{stage.value}'")
        return release_id

    def list_circuits(self, stage: DesignStage = None) -> List[Dict]:
        """List all circuits, optionally filtered by stage"""
        cursor = self.conn.cursor()

        if stage:
            cursor.execute("""
                SELECT circuit_name, version, stage, created_at, description
                FROM circuit_versions
                WHERE stage = ?
                ORDER BY circuit_name, created_at DESC
            """, (stage.value,))
        else:
            cursor.execute("""
                SELECT circuit_name, version, stage, created_at, description
                FROM circuit_versions
                ORDER BY circuit_name, created_at DESC
            """)

        return [dict(row) for row in cursor.fetchall()]

    def get_circuit_summary(self, circuit_name: str, version: str = None) -> Dict:
        """Get a complete summary of a circuit including components and results"""
        if version:
            circuit = self.get_version(circuit_name, version)
        else:
            circuit = self.get_latest(circuit_name)

        if not circuit:
            return None

        cursor = self.conn.cursor()

        # Get devices
        cursor.execute("""
            SELECT device_id, name, type, model, properties
            FROM devices
            WHERE circuit_version_id = ?
        """, (circuit['version_id'],))
        devices = [dict(row) for row in cursor.fetchall()]

        # Get nets
        cursor.execute("""
            SELECT name, net_type
            FROM nets
            WHERE circuit_version_id = ?
        """, (circuit['version_id'],))
        nets = [dict(row) for row in cursor.fetchall()]

        # Get simulation results
        sim_results = self.get_simulation_results(circuit['version_id'])

        # Get modules
        modules = self.get_circuit_modules(circuit['version_id'])

        return {
            'circuit': circuit,
            'devices': devices,
            'nets': nets,
            'modules': modules,
            'simulation_results': sim_results
        }

    def update_simulation_summary(self, circuit_version_id: str) -> str:
        """Generate and cache a formatted summary of all simulation results"""
        cursor = self.conn.cursor()

        # Get all unique parameters
        cursor.execute("""
            SELECT DISTINCT parameter, unit
            FROM simulation_results
            WHERE circuit_version_id = ?
            ORDER BY parameter
        """, (circuit_version_id,))

        parameters = cursor.fetchall()

        if not parameters:
            return ""

        summary_lines = []
        summary_lines.append("=== SIMULATION SUMMARY ===")
        summary_lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        summary_lines.append("")

        for param, unit in parameters:
            # Get results for this parameter across corners
            cursor.execute("""
                SELECT corner, temperature, voltage, value, sim_type
                FROM simulation_results
                WHERE circuit_version_id = ? AND parameter = ?
                ORDER BY 
                    CASE corner
                        WHEN 'tt' THEN 1
                        WHEN 'ss' THEN 2
                        WHEN 'ff' THEN 3
                        WHEN 'sf' THEN 4
                        WHEN 'fs' THEN 5
                        ELSE 6
                    END,
                    temperature,
                    voltage
            """, (circuit_version_id, param))

            results = cursor.fetchall()

            if not results:
                continue

            unit_str = f" {unit}" if unit else ""

            # If multiple corners, show range
            if len(results) > 1:
                values = [r[3] for r in results if r[3] is not None]
                if values:
                    min_val = min(values)
                    max_val = max(values)
                    summary_lines.append(f"{param:20s}: {min_val:.3g} to {max_val:.3g}{unit_str} ({len(results)} corners)")

                    # Show each corner
                    for corner, temp, volt, value, sim_type in results:
                        corner_str = corner or "nominal"
                        conditions = []
                        if temp is not None:
                            conditions.append(f"{temp}°C")
                        if volt is not None:
                            conditions.append(f"{volt}V")
                        cond_str = f" @ {', '.join(conditions)}" if conditions else ""
                        summary_lines.append(f"  └─ {corner_str:8s}{cond_str:20s}: {value:.3g}{unit_str}")
            else:
                # Single result
                corner, temp, volt, value, sim_type = results[0]
                if value is not None:
                    corner_str = corner or "nominal"
                    conditions = []
                    if temp is not None:
                        conditions.append(f"{temp}°C")
                    if volt is not None:
                        conditions.append(f"{volt}V")
                    cond_str = f" @ {', '.join(conditions)}" if conditions else ""
                    summary_lines.append(f"{param:20s}: {value:.3g}{unit_str} ({corner_str}{cond_str})")

            summary_lines.append("")

        # Get pass/fail status if available
        cursor.execute("""
            SELECT parameter, value_text
            FROM simulation_results
            WHERE circuit_version_id = ? AND value_text IS NOT NULL
        """, (circuit_version_id,))

        status_results = cursor.fetchall()
        if status_results:
            summary_lines.append("=== STATUS ===")
            for param, status in status_results:
                summary_lines.append(f"{param:20s}: {status}")
            summary_lines.append("")

        summary_text = "\n".join(summary_lines)

        # Update the circuit version
        cursor.execute("""
            UPDATE circuit_versions
            SET simulation_summary = ?, last_summary_update = CURRENT_TIMESTAMP
            WHERE version_id = ?
        """, (summary_text, circuit_version_id))

        self.conn.commit()

        return summary_text

    def get_simulation_summary(self, circuit_version_id: str) -> str:
        """Get the cached simulation summary for a circuit"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT simulation_summary, last_summary_update
            FROM circuit_versions
            WHERE version_id = ?
        """, (circuit_version_id,))

        row = cursor.fetchone()
        if row and row[0]:
            return row[0]
        else:
            # Generate if doesn't exist
            return self.update_simulation_summary(circuit_version_id)

    def add_parasitic(self, circuit_version_id: str, net_id: str,
                     parasitic_type: str, value: float, unit: str,
                     from_node: str = None, to_node: str = None,
                     extraction_tool: str = None) -> str:
        """Add parasitic data (for post-layout)"""
        parasitic_id = str(uuid.uuid4())

        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO parasitics
            (parasitic_id, circuit_version_id, net_id, parasitic_type,
             value, unit, from_node, to_node, extraction_tool)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (parasitic_id, circuit_version_id, net_id, parasitic_type,
              value, unit, from_node, to_node, extraction_tool))

        self.conn.commit()
        return parasitic_id

    def get_latest_circuit(self, circuit_name: str) -> Optional[Dict]:
        """
        Get the most recently created circuit version by circuit name
        (Alias for get_latest for backward compatibility)
        """
        return self.get_latest(circuit_name)

    def get_latest_circuit_by_version(self, circuit_name: str) -> Optional[Dict]:
        """
        Get the circuit with the highest version number

        Args:
            circuit_name: Name of the circuit

        Returns:
            dict: Circuit info or None if not found
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT version_id, circuit_name, version, stage, created_at,
                   netlist_path, description, metadata
            FROM circuit_versions
            WHERE circuit_name = ?
            ORDER BY version DESC
            LIMIT 1
        """, (circuit_name,))

        row = cursor.fetchone()
        if row:
            return {
                'version_id': row[0],
                'circuit_name': row[1],
                'version': row[2],
                'stage': row[3],
                'created_at': row[4],
                'netlist_path': row[5],
                'description': row[6],
                'metadata': json.loads(row[7]) if row[7] else {}
            }
        return None

    def get_all_circuits_at_stage(self, stage: DesignStage) -> List[Dict]:
        """Get all circuits at a specific stage (latest version of each)"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT circuit_name FROM circuit_versions
            WHERE stage = ?
        """, (stage.value,))

        circuit_names = [row[0] for row in cursor.fetchall()]
        return [self.get_latest(name, stage) for name in circuit_names]

    def get_corners_for_parameter(self, circuit_version_id: str,
                                  parameter: str) -> List[Dict]:
        """Get results for a specific parameter across all corners"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT corner, temperature, voltage, value, unit, timestamp
            FROM simulation_results
            WHERE circuit_version_id = ? AND parameter = ?
            ORDER BY corner, temperature, voltage
        """, (circuit_version_id, parameter))

        return [dict(row) for row in cursor.fetchall()]

    def get_corner_summary(self, circuit_version_id: str) -> Dict:
        """Get a summary of all corners simulated"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT corner, temperature, voltage
            FROM simulation_results
            WHERE circuit_version_id = ?
            ORDER BY corner, temperature, voltage
        """, (circuit_version_id,))

        corners = {}
        for row in cursor.fetchall():
            corner = row[0] or "nominal"
            temp = row[1]
            volt = row[2]

            key = corner
            if temp is not None or volt is not None:
                conditions = []
                if temp is not None:
                    conditions.append(f"{temp}°C")
                if volt is not None:
                    conditions.append(f"{volt}V")
                key = f"{corner} ({', '.join(conditions)})"

            if corner not in corners:
                corners[corner] = []
            corners[corner].append({
                'corner': corner,
                'temperature': temp,
                'voltage': volt,
                'display_name': key
            })

        return corners

    def close(self):
        """Close database connection"""
        self.conn.close()


if __name__ == "__main__":
    # Example usage
    db = CircuitDatabase("example_updated.db")

    # Create a circuit in dev stage
    amp_id = db.create_circuit(
        name="amplifier",
        version="1.0",
        stage=DesignStage.DEV,
        created_by="designer1",
        description="Initial differential amplifier design"
    )

    # Add some devices
    db.add_device(amp_id, "M1", "nmos", model="sky130_fd_pr__nfet_01v8",
                  width=10e-6, length=180e-9)
    db.add_device(amp_id, "M2", "nmos", model="sky130_fd_pr__nfet_01v8",
                  width=10e-6, length=180e-9)
    db.add_device(amp_id, "M3", "pmos", model="sky130_fd_pr__pfet_01v8",
                  width=20e-6, length=180e-9)

    # Create a module with a hash
    module_hash = hashlib.sha256("output_stage_v1".encode()).hexdigest()
    module_id = db.insert_or_get_module(
        module_name="output_stage",
        module_path="amplifier.output",
        module_hash=module_hash,
        device_count=2,
        structure={'devices': ['M4', 'M5'], 'nets': ['out', 'gnd']}
    )

    # Link module to circuit
    db.link_module_to_circuit(amp_id, module_id, instance_name="output_1", position=0)

    # Add simulation results
    db.add_simulation_result(amp_id, "gain", value=45.2, unit="dB", sim_type="ac")
    db.add_simulation_result(amp_id, "bandwidth", value=1e9, unit="Hz", sim_type="ac")

    # Create version 2 with same module
    amp_id_v2 = db.create_circuit(
        name="amplifier",
        version="1.1",
        stage=DesignStage.DEV,
        created_by="designer1",
        description="Updated amplifier - same output stage"
    )

    # Reuse the same module (no duplication!)
    db.link_module_to_circuit(amp_id_v2, module_id, instance_name="output_1", position=0)

    print("\n" + "="*60)
    print("MODULE REUSE DEMONSTRATION")
    print("="*60)

    # Show modules for both circuits
    print(f"\nModules in version 1.0:")
    for m in db.get_circuit_modules(amp_id):
        print(f"  - {m['module_name']} (hash: {m['module_hash'][:16]}...)")

    print(f"\nModules in version 1.1:")
    for m in db.get_circuit_modules(amp_id_v2):
        print(f"  - {m['module_name']} (hash: {m['module_hash'][:16]}...)")

    print(f"\nCircuits using output_stage module:")
    for c in db.get_circuits_using_module(module_hash):
        print(f"  - {c['circuit_name']} v{c['version']} [{c['stage']}]")

    # Compare modules between versions
    comparison = db.compare_circuit_modules(amp_id, amp_id_v2)
    print(f"\nModule comparison:")
    print(f"  Unchanged: {len(comparison['unchanged'])} modules")
    print(f"  Added: {len(comparison['added'])} modules")
    print(f"  Removed: {len(comparison['removed'])} modules")

    db.close()
# Backward-compat alias
CircuitDatabase = Database
