"""
Interactive CLI for Circuit Design Database
Easy data entry interface for circuits, transistors, nets, and simulation results
"""

from silk.db.circuit_db import CircuitDatabase, DesignStage
from typing import Optional, List
import sys


class CircuitCLI:
    """Interactive command-line interface for circuit database"""
    
    def __init__(self, db_path: str = "circuit_design.db"):
        self.db = CircuitDatabase(db_path)
        self.current_circuit = None
        self.current_version_id = None
        
    def run(self):
        """Main interactive loop"""
        print("\n" + "="*60)
        print("  Circuit Design Database - Interactive Interface")
        print("="*60)
        
        while True:
            self._print_status()
            self._print_menu()
            
            try:
                choice = input("\nEnter choice: ").strip()
                
                if choice == "0":
                    print("\nGoodbye!")
                    break
                elif choice == "1":
                    self._create_circuit_wizard()
                elif choice == "2":
                    self._select_circuit()
                elif choice == "3":
                    self._add_transistor_wizard()
                elif choice == "4":
                    self._add_net_wizard()
                elif choice == "5":
                    self._add_simulation_result_wizard()
                elif choice == "6":
                    self._view_circuit_summary()
                elif choice == "7":
                    self._promote_circuit_wizard()
                elif choice == "8":
                    self._list_all_circuits()
                elif choice == "9":
                    self._create_release_wizard()
                elif choice == "10":
                    self._update_circuit_wizard()
                elif choice == "11":
                    self._add_parasitic_wizard()
                elif choice == "12":
                    self._view_corner_analysis()
                else:
                    print("Invalid choice. Please try again.")
                    
            except KeyboardInterrupt:
                print("\n\nInterrupted. Goodbye!")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}")
                
        self.db.close()
    
    def _print_status(self):
        """Print current working context"""
        print("\n" + "-"*60)
        if self.current_circuit:
            circuit = self.db.get_latest(self.current_circuit)
            if circuit:
                print(f"📍 Current: {circuit['circuit_name']} "
                      f"v{circuit['version']} [{circuit['stage']}]")
            else:
                print(f"📍 Current: {self.current_circuit} (no versions found)")
        else:
            print("📍 No circuit selected")
        print("-"*60)
    
    def _print_menu(self):
        """Print main menu"""
        print("\n┌─ Main Menu ─────────────────────────────────────────────┐")
        print("│ CIRCUIT MANAGEMENT:                                     │")
        print("│  1. Create new circuit                                  │")
        print("│  2. Select existing circuit                             │")
        print("│  10. Update circuit (new version)                       │")
        print("│                                                         │")
        print("│ ADD COMPONENTS (requires circuit selected):             │")
        print("│  3. Add transistor                                      │")
        print("│  4. Add net                                             │")
        print("│  5. Add simulation result                               │")
        print("│  11. Add parasitic (post-layout)                        │")
        print("│                                                         │")
        print("│ VIEW & MANAGE:                                          │")
        print("│  6. View circuit summary                                │")
        print("│  12. View corner analysis                               │")
        print("│  7. Promote circuit to next stage                       │")
        print("│  8. List all circuits                                   │")
        print("│  9. Create release snapshot                             │")
        print("│                                                         │")
        print("│  0. Exit                                                │")
        print("└─────────────────────────────────────────────────────────┘")
    
    def _create_circuit_wizard(self):
        """Wizard for creating a new circuit"""
        print("\n" + "="*60)
        print("  CREATE NEW CIRCUIT")
        print("="*60)
        
        name = input("Circuit name: ").strip()
        if not name:
            print("❌ Name cannot be empty")
            return
        
        version = input("Version [1.0]: ").strip() or "1.0"
        
        print("\nStage options:")
        for i, stage in enumerate(DesignStage, 1):
            print(f"  {i}. {stage.value}")
        stage_choice = input("Stage [1]: ").strip() or "1"
        stages = list(DesignStage)
        stage = stages[int(stage_choice)-1] if stage_choice.isdigit() else DesignStage.DEV
        
        created_by = input("Created by [user]: ").strip() or "user"
        description = input("Description: ").strip()
        
        version_id = self.db.create_circuit(
            name=name,
            version=version,
            stage=stage,
            created_by=created_by,
            description=description
        )
        
        self.current_circuit = name
        self.current_version_id = version_id
        
        print(f"\n✓ Circuit created with ID: {version_id}")
    
    def _select_circuit(self):
        """Select an existing circuit to work with"""
        print("\n" + "="*60)
        print("  SELECT CIRCUIT")
        print("="*60)
        
        circuits = self.db.list_circuits()
        if not circuits:
            print("No circuits found in database.")
            return
        
        # Get unique circuit names
        names = sorted(set(c['circuit_name'] for c in circuits))
        
        print("\nAvailable circuits:")
        for i, name in enumerate(names, 1):
            print(f"  {i}. {name}")
        
        choice = input("\nSelect circuit number: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(names):
            self.current_circuit = names[int(choice)-1]
            
            # Get latest version
            circuit = self.db.get_latest(self.current_circuit)
            if circuit:
                self.current_version_id = circuit['version_id']
                print(f"\n✓ Selected: {self.current_circuit} "
                      f"v{circuit['version']} [{circuit['stage']}]")
        else:
            print("❌ Invalid selection")
    
    def _add_transistor_wizard(self):
        """Wizard for adding a transistor"""
        if not self._check_circuit_selected():
            return
        
        print("\n" + "="*60)
        print("  ADD TRANSISTOR")
        print("="*60)
        
        name = input("Transistor name (e.g., M1): ").strip()
        if not name:
            print("❌ Name cannot be empty")
            return
        
        print("\nType options: 1=nmos, 2=pmos, 3=nfet, 4=pfet")
        type_choice = input("Type [1]: ").strip() or "1"
        types = ["nmos", "pmos", "nfet", "pfet"]
        trans_type = types[int(type_choice)-1] if type_choice.isdigit() else "nmos"
        
        width_str = input("Width (µm): ").strip()
        width = float(width_str) * 1e-6 if width_str else None
        
        length_str = input("Length (nm): ").strip()
        length = float(length_str) * 1e-9 if length_str else None
        
        mult_str = input("Multiplier [1]: ").strip() or "1"
        multiplier = int(mult_str)
        
        model = input("Model name (optional): ").strip() or None
        
        transistor_id = self.db.add_transistor(
            circuit_version_id=self.current_version_id,
            name=name,
            transistor_type=trans_type,
            width=width,
            length=length,
            multiplier=multiplier,
            model=model
        )
        
        print(f"\n✓ Transistor {name} added")
    
    def _add_net_wizard(self):
        """Wizard for adding a net"""
        if not self._check_circuit_selected():
            return
        
        print("\n" + "="*60)
        print("  ADD NET")
        print("="*60)
        
        name = input("Net name: ").strip()
        if not name:
            print("❌ Name cannot be empty")
            return
        
        print("\nType options: 1=signal, 2=power, 3=ground, 4=clock")
        type_choice = input("Type [1]: ").strip() or "1"
        types = ["signal", "power", "ground", "clock"]
        net_type = types[int(type_choice)-1] if type_choice.isdigit() else "signal"
        
        net_id = self.db.add_net(
            circuit_version_id=self.current_version_id,
            name=name,
            net_type=net_type
        )
        
        print(f"\n✓ Net {name} added")
    
    def _add_simulation_result_wizard(self):
        """Wizard for adding simulation results"""
        if not self._check_circuit_selected():
            return
        
        print("\n" + "="*60)
        print("  ADD SIMULATION RESULT")
        print("="*60)
        
        print("\nSimulation type: 1=dc, 2=ac, 3=tran, 4=noise, 5=other")
        sim_choice = input("Type [1]: ").strip() or "1"
        sim_types = ["dc", "ac", "tran", "noise", "other"]
        sim_type = sim_types[int(sim_choice)-1] if sim_choice.isdigit() else "dc"
        
        parameter = input("Parameter name (e.g., gain, bandwidth): ").strip()
        if not parameter:
            print("❌ Parameter cannot be empty")
            return
        
        # Corner information
        print("\nCorner (optional): 1=tt, 2=ss, 3=ff, 4=sf, 5=fs, 6=other, [blank]=none")
        corner_choice = input("Corner: ").strip()
        corners_map = {"1": "tt", "2": "ss", "3": "ff", "4": "sf", "5": "fs"}
        corner = corners_map.get(corner_choice) if corner_choice in corners_map else None
        if corner_choice == "6":
            corner = input("Enter corner name: ").strip() or None
        
        temperature = None
        voltage = None
        if corner:
            temp_str = input("Temperature (°C) [optional]: ").strip()
            temperature = float(temp_str) if temp_str else None
            
            volt_str = input("Supply voltage (V) [optional]: ").strip()
            voltage = float(volt_str) if volt_str else None
        
        value_str = input("Value (leave empty for text result): ").strip()
        value = float(value_str) if value_str else None
        
        value_text = None
        if value is None:
            value_text = input("Text value: ").strip()
        
        unit = input("Unit (e.g., dB, Hz, V): ").strip() or None
        tool_name = input("Tool name [spice]: ").strip() or "spice"
        
        sim_id = self.db.add_simulation_result(
            circuit_version_id=self.current_version_id,
            parameter=parameter,
            value=value,
            value_text=value_text,
            corner=corner,
            temperature=temperature,
            voltage=voltage,
            sim_type=sim_type,
            unit=unit,
            tool_name=tool_name
        )
        
        print(f"\n✓ Simulation result added for {parameter}")
        if corner:
            print(f"  Corner: {corner}", end="")
            if temperature:
                print(f" @ {temperature}°C", end="")
            if voltage:
                print(f", {voltage}V", end="")
            print()
    
    def _add_parasitic_wizard(self):
        """Wizard for adding parasitic data"""
        if not self._check_circuit_selected():
            return
        
        print("\n" + "="*60)
        print("  ADD PARASITIC (Post-Layout)")
        print("="*60)
        
        # First, list available nets
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT net_id, name FROM nets
            WHERE circuit_version_id = ?
        """, (self.current_version_id,))
        nets = cursor.fetchall()
        
        if not nets:
            print("❌ No nets found. Add nets first.")
            return
        
        print("\nAvailable nets:")
        for i, (net_id, name) in enumerate(nets, 1):
            print(f"  {i}. {name}")
        
        net_choice = input("Select net number: ").strip()
        if not net_choice.isdigit() or int(net_choice) < 1 or int(net_choice) > len(nets):
            print("❌ Invalid selection")
            return
        
        net_id = nets[int(net_choice)-1][0]
        
        print("\nParasitic type: 1=resistance, 2=capacitance, 3=inductance")
        type_choice = input("Type [2]: ").strip() or "2"
        types = ["resistance", "capacitance", "inductance"]
        para_type = types[int(type_choice)-1] if type_choice.isdigit() else "capacitance"
        
        value_str = input("Value: ").strip()
        value = float(value_str) if value_str else 0
        
        # Suggest units based on type
        if para_type == "resistance":
            default_unit = "ohm"
        elif para_type == "capacitance":
            default_unit = "fF"
        else:
            default_unit = "pH"
        
        unit = input(f"Unit [{default_unit}]: ").strip() or default_unit
        
        from_node = input("From node (optional): ").strip() or None
        to_node = input("To node (optional): ").strip() or None
        tool = input("Extraction tool [StarRC]: ").strip() or "StarRC"
        
        para_id = self.db.add_parasitic(
            circuit_version_id=self.current_version_id,
            net_id=net_id,
            parasitic_type=para_type,
            value=value,
            unit=unit,
            from_node=from_node,
            to_node=to_node,
            extraction_tool=tool
        )
        
        print(f"\n✓ Parasitic added ({value} {unit})")
    
    def _view_circuit_summary(self):
        """View complete circuit summary"""
        if not self._check_circuit_selected():
            return
        
        summary = self.db.get_circuit_summary(self.current_circuit)
        if not summary:
            print("❌ Circuit not found")
            return
        
        circuit = summary['circuit']
        
        print("\n" + "="*60)
        print(f"  CIRCUIT SUMMARY: {circuit['circuit_name']}")
        print("="*60)
        print(f"Version:     {circuit['version']}")
        print(f"Stage:       {circuit['stage']}")
        print(f"Created:     {circuit['created_at']}")
        print(f"Created by:  {circuit['created_by']}")
        print(f"Locked:      {'Yes' if circuit['is_locked'] else 'No'}")
        if circuit['description']:
            print(f"Description: {circuit['description']}")
        
        print(f"\n📌 TRANSISTORS ({len(summary['transistors'])})")
        print("-" * 60)
        if summary['transistors']:
            for t in summary['transistors']:
                print(f"  {t['name']:8s} {t['type']:6s}  "
                      f"W={t['width']*1e6:.2f}µm L={t['length']*1e9:.1f}nm "
                      f"M={t['multiplier']}")
        else:
            print("  (none)")
        
        print(f"\n🔌 NETS ({len(summary['nets'])})")
        print("-" * 60)
        if summary['nets']:
            for n in summary['nets']:
                print(f"  {n['name']:20s} [{n['net_type']}]")
        else:
            print("  (none)")
        
        # Show simulation summary if available
        sim_summary = self.db.get_simulation_summary(circuit['version_id'])
        if sim_summary:
            print(f"\n📊 SIMULATION SUMMARY")
            print("-" * 60)
            print(sim_summary)
        else:
            print(f"\n📊 SIMULATION RESULTS ({len(summary['simulation_results'])})")
            print("-" * 60)
            if summary['simulation_results']:
                for r in summary['simulation_results'][:10]:  # Show first 10
                    val_str = f"{r['value']}" if r['value'] else r['value_text']
                    unit_str = f" {r['unit']}" if r['unit'] else ""
                    corner_str = f" [{r['corner']}]" if r.get('corner') else ""
                    print(f"  {r['parameter']:20s} = {val_str}{unit_str}{corner_str} "
                          f"[{r['sim_type']}, {r['tool_name']}]")
                if len(summary['simulation_results']) > 10:
                    print(f"  ... and {len(summary['simulation_results'])-10} more")
            else:
                print("  (none)")
    
    def _promote_circuit_wizard(self):
        """Wizard for promoting circuit to next stage"""
        if not self._check_circuit_selected():
            return
        
        circuit = self.db.get_latest(self.current_circuit)
        current_stage = DesignStage(circuit['stage'])
        
        print("\n" + "="*60)
        print("  PROMOTE CIRCUIT")
        print("="*60)
        print(f"Current stage: {current_stage.value}")
        
        print("\nAvailable stages:")
        stages = list(DesignStage)
        for i, stage in enumerate(stages, 1):
            marker = " (current)" if stage == current_stage else ""
            print(f"  {i}. {stage.value}{marker}")
        
        stage_choice = input("\nPromote to stage: ").strip()
        if not stage_choice.isdigit() or int(stage_choice) < 1 or int(stage_choice) > len(stages):
            print("❌ Invalid selection")
            return
        
        to_stage = stages[int(stage_choice)-1]
        
        if to_stage == current_stage:
            print("❌ Cannot promote to same stage")
            return
        
        new_version = input(f"New version [{circuit['version']}-{to_stage.value}]: ").strip()
        lock = input("Lock this version? [Y/n]: ").strip().lower() != 'n'
        description = input("Description: ").strip()
        
        version_id = self.db.promote_circuit(
            circuit_name=self.current_circuit,
            from_stage=current_stage,
            to_stage=to_stage,
            new_version=new_version if new_version else None,
            lock=lock,
            description=description
        )
        
        self.current_version_id = version_id
        print(f"\n✓ Circuit promoted to {to_stage.value}")
    
    def _update_circuit_wizard(self):
        """Create a new version of the current circuit"""
        if not self._check_circuit_selected():
            return
        
        circuit = self.db.get_latest(self.current_circuit)
        
        print("\n" + "="*60)
        print("  UPDATE CIRCUIT (New Version)")
        print("="*60)
        print(f"Current version: {circuit['version']}")
        
        new_version = input("New version number: ").strip()
        if not new_version:
            print("❌ Version cannot be empty")
            return
        
        description = input("What changed: ").strip()
        
        version_id = self.db.update_circuit(
            circuit_name=self.current_circuit,
            new_version=new_version,
            stage=DesignStage(circuit['stage']),
            description=description
        )
        
        self.current_version_id = version_id
        print(f"\n✓ Created version {new_version}")
    
    def _list_all_circuits(self):
        """List all circuits in the database"""
        print("\n" + "="*60)
        print("  ALL CIRCUITS")
        print("="*60)
        
        circuits = self.db.list_circuits()
        if not circuits:
            print("No circuits found.")
            return
        
        current_name = None
        for c in circuits:
            if c['circuit_name'] != current_name:
                print(f"\n📦 {c['circuit_name']}")
                current_name = c['circuit_name']
            
            locked = "🔒" if c.get('is_locked') else "  "
            desc = f" - {c['description']}" if c.get('description') else ""
            print(f"  {locked} v{c['version']:8s} [{c['stage']:12s}] "
                  f"{c['created_at']}{desc}")
    
    def _create_release_wizard(self):
        """Create a release snapshot"""
        print("\n" + "="*60)
        print("  CREATE RELEASE SNAPSHOT")
        print("="*60)
        
        release_name = input("Release name (e.g., schematic_freeze_oct2025): ").strip()
        if not release_name:
            print("❌ Name cannot be empty")
            return
        
        print("\nStage for this release:")
        stages = list(DesignStage)
        for i, stage in enumerate(stages, 1):
            print(f"  {i}. {stage.value}")
        
        stage_choice = input("Stage [2=stable]: ").strip() or "2"
        stage = stages[int(stage_choice)-1] if stage_choice.isdigit() else DesignStage.STABLE
        
        # Get circuits at this stage
        circuits = self.db.get_all_circuits_at_stage(stage)
        
        print(f"\nCircuits at stage '{stage.value}':")
        if circuits:
            for c in circuits:
                print(f"  • {c['circuit_name']} v{c['version']}")
        else:
            print("  (none)")
        
        include_all = input("\nInclude all circuits at this stage? [Y/n]: ").strip().lower() != 'n'
        
        circuit_names = None
        if include_all and circuits:
            circuit_names = [c['circuit_name'] for c in circuits]
        
        notes = input("Release notes: ").strip()
        
        release_id = self.db.create_release(
            release_name=release_name,
            stage=stage,
            circuit_names=circuit_names,
            notes=notes
        )
        
        print(f"\n✓ Release created: {release_name}")
    
    def _check_circuit_selected(self) -> bool:
        """Check if a circuit is currently selected"""
        if not self.current_circuit or not self.current_version_id:
            print("❌ No circuit selected. Use option 1 or 2 first.")
            return False
        return True
    
    def _view_corner_analysis(self):
        """View corner analysis for current circuit"""
        if not self._check_circuit_selected():
            return
        
        print("\n" + "="*60)
        print("  CORNER ANALYSIS")
        print("="*60)
        
        # Get corner summary
        corner_summary = self.db.get_corner_summary(self.current_version_id)
        
        if not corner_summary:
            print("No corner data available.")
            return
        
        print(f"\nCircuit: {self.current_circuit}")
        print(f"\nCorners simulated: {len(corner_summary)}")
        for corner, conditions in corner_summary.items():
            print(f"  • {corner}")
            for cond in conditions:
                if cond['temperature'] or cond['voltage']:
                    details = []
                    if cond['temperature']:
                        details.append(f"T={cond['temperature']}°C")
                    if cond['voltage']:
                        details.append(f"V={cond['voltage']}V")
                    print(f"    - {', '.join(details)}")
        
        # Ask which parameter to analyze
        print("\n" + "-"*60)
        
        # Get unique parameters
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT parameter
            FROM simulation_results
            WHERE circuit_version_id = ?
            ORDER BY parameter
        """, (self.current_version_id,))
        
        parameters = [row[0] for row in cursor.fetchall()]
        
        if not parameters:
            print("No simulation parameters found.")
            return
        
        print("\nAvailable parameters:")
        for i, param in enumerate(parameters, 1):
            print(f"  {i}. {param}")
        
        choice = input("\nSelect parameter to analyze (or Enter for all): ").strip()
        
        if choice and choice.isdigit() and 1 <= int(choice) <= len(parameters):
            param = parameters[int(choice)-1]
            self._show_corner_details(param)
        else:
            # Show all parameters
            for param in parameters:
                self._show_corner_details(param)
    
    def _show_corner_details(self, parameter: str):
        """Show corner details for a specific parameter"""
        corner_results = self.db.get_corners_for_parameter(
            self.current_version_id, parameter
        )
        
        if not corner_results:
            return
        
        print(f"\n{parameter}:")
        print("-" * 60)
        
        values = [r['value'] for r in corner_results if r['value'] is not None]
        
        if values:
            min_val = min(values)
            max_val = max(values)
            unit = corner_results[0]['unit'] or ""
            
            print(f"  Range: {min_val:.3g} to {max_val:.3g} {unit}")
            print(f"  Spread: {max_val - min_val:.3g} {unit} "
                  f"({(max_val-min_val)/((max_val+min_val)/2)*100:.1f}%)")
            print()
            
            for r in corner_results:
                corner = r['corner'] or "nominal"
                conditions = []
                if r['temperature']:
                    conditions.append(f"{r['temperature']}°C")
                if r['voltage']:
                    conditions.append(f"{r['voltage']}V")
                cond_str = f" @ {', '.join(conditions)}" if conditions else ""
                
                val = r['value']
                unit_str = f" {r['unit']}" if r['unit'] else ""
                print(f"  {corner:8s}{cond_str:25s}: {val:.3g}{unit_str}")


def main():
    """Entry point for the CLI"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Circuit Design Database CLI")
    parser.add_argument("--db", default="circuit_design.db",
                       help="Database file path (default: circuit_design.db)")
    
    args = parser.parse_args()
    
    cli = CircuitCLI(args.db)
    cli.run()


if __name__ == "__main__":
    main()
