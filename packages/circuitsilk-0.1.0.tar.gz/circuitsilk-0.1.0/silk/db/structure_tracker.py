"""
Circuit Structure Tracker
Intelligent tracking of circuit structure with change detection and run counting.

This module handles:
- Automatic structure extraction from PyNetlist
- Change detection (only store if structure changed)
- Run counting for each unique structure
- Complete transistor and net capture
- PyModule filtering (exclude testbench)
- Module-level change tracking with individual module hashes
"""

import hashlib
import json
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any


class CircuitStructureTracker:
    """
    Tracks circuit structure with intelligent change detection

    Features:
    - Extracts structure from PyNetlist PyModule elements
    - Computes structure hash for change detection
    - Tracks run count per unique structure
    - Stores complete transistor parameters and connections
    - Tracks individual module changes via module hashes
    """

    def __init__(self, database, circuit_id: Optional[str], debug: bool = False):
        """
        Initialize structure tracker

        Args:
            database: CircuitDatabase instance
            circuit_id: Circuit version ID from database (can be None initially)
            debug: Print debug information
        """
        self.db = database
        self.circuit_id = circuit_id  # Can be None, will be set later
        self.debug = debug

        # Cache of last stored structure
        self._last_structure_hash = None
        self._current_run_count = 0
        self._last_module_hashes = {}  # Track previous module hashes

        # Load existing structure hash if available
        if circuit_id:
            self._load_last_structure()

    def _load_last_structure(self):
        """Load the last stored structure hash and run count"""
        # Query database for last structure
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT metadata FROM circuit_versions
            WHERE version_id = ?
        """, (self.circuit_id,))

        row = cursor.fetchone()
        if row and row[0]:
            try:
                metadata = json.loads(row[0])
                self._last_structure_hash = metadata.get('structure_hash')
                self._current_run_count = metadata.get('run_count', 0)
                self._last_module_hashes = metadata.get('module_hashes', {})
            except (json.JSONDecodeError, TypeError):
                pass

    def extract_structure(self, netlist) -> Dict[str, Any]:
        """
        Extract complete circuit structure from PyNetlist

        Handles PyNetlist's dict-based elem_dict structure:
        elem_dict[name] = {'device': <object>, 'type': 'd' or 'm'}

        Recursively extracts devices from PyModule instances.
        Captures all devices (transistors, resistors, capacitors, etc.)
        Only captures PyModule elements (not testbench sources, etc.)

        Args:
            netlist: PyNetlist instance

        Returns:
            dict: Complete structure including devices, nets, hierarchy, and modules with hashes
        """
        structure = {
            'transistors': [],  # Keep name for compatibility (contains all devices)
            'nets': [],
            'hierarchy': [],
            'parameters': [],
            'modules': {}  # Track modules: {module_path: {devices: [...], hash: '...', device_count: N}}
        }

        if self.debug:
            print("\n🔍 Extracting circuit structure...")

        # Track which devices we've already added to avoid duplicates
        processed_devices = set()

        # Extract devices and subcircuits from elem_dict
        for elem_name, elem_entry in netlist.elem_dict.items():
            if self.debug:
                print(f"  Examining element: {elem_name}")

            # Handle dict-based structure: elem_dict[name] = {'device': obj, 'type': 'd'/'m'}
            if isinstance(elem_entry, dict):
                elem_data = elem_entry.get('device')
                elem_type = elem_entry.get('type')

                if self.debug:
                    print(f"    Dict entry: type='{elem_type}', device={type(elem_data).__name__}")

                if elem_type == 'm':
                    # This is a module
                    module_info = self._extract_module_info(elem_name, elem_data, netlist)
                    if module_info:
                        structure['hierarchy'].append(module_info)
                        if self.debug:
                            print(f"    ✓ Added module: {elem_name}")

                    # Recursively extract devices from inside the module
                    self._extract_from_module(elem_data, structure, prefix=elem_name, processed=processed_devices)

                elif elem_type == 'd':
                    # This is a device (transistor, resistor, etc.)
                    if elem_name not in processed_devices:
                        device_info = self._extract_transistor_info(elem_name, elem_data, netlist)
                        if device_info:
                            structure['transistors'].append(device_info)
                            processed_devices.add(elem_name)
                            if self.debug:
                                print(f"    ✓ Added device: {elem_name}")

            else:
                # Handle direct object (old style, for compatibility)
                if self.debug:
                    print(f"    Direct object: {type(elem_entry).__name__}")

                if self._is_pymodule(elem_entry):
                    # This is a subcircuit/module
                    module_info = self._extract_module_info(elem_name, elem_entry, netlist)
                    if module_info:
                        structure['hierarchy'].append(module_info)
                        if self.debug:
                            print(f"    ✓ Added module: {elem_name}")

                    # Recursively extract devices from inside the module
                    self._extract_from_module(elem_entry, structure, prefix=elem_name, processed=processed_devices)

                elif self._is_transistor(elem_entry):
                    # This is a device at top level
                    if elem_name not in processed_devices:
                        device_info = self._extract_transistor_info(elem_name, elem_entry, netlist)
                        if device_info:
                            structure['transistors'].append(device_info)
                            processed_devices.add(elem_name)
                            if self.debug:
                                print(f"    ✓ Added device: {elem_name}")

        # Extract nets from net_dict
        for net_name, net_data in netlist.net_dict.items():
            net_info = self._extract_net_info(net_name, net_data)
            structure['nets'].append(net_info)

        # Process module_dict to track individual module structures and hashes
        # This is ONLY for module hash tracking, not for device extraction
        if hasattr(netlist, 'module_dict'):
            if self.debug:
                print(f"\n  Computing module hashes ({len(netlist.module_dict)} modules)...")

            for module_name, module_entry in netlist.module_dict.items():
                if self.debug:
                    print(f"    Processing module_dict['{module_name}']")

                # module_dict uses dict structure: {'device': obj, 'defined': bool}
                if isinstance(module_entry, dict):
                    module_device = module_entry.get('device')
                    if module_device:
                        # Extract module structure (for hash computation only)
                        module_structure = self._extract_module_structure(module_device, module_name)

                        # Compute hash for this module
                        module_hash = self._compute_module_hash(module_structure)

                        # Store module info with hash
                        structure['modules'][module_name] = {
                            'devices': module_structure['devices'],
                            'nets': module_structure['nets'],
                            'submodules': module_structure['submodules'],
                            'hash': module_hash,
                            'device_count': len(module_structure['devices'])
                        }

                        if self.debug:
                            print(f"      ✓ Module '{module_name}' - {len(module_structure['devices'])} devices, hash: {module_hash[:16]}...")

        if self.debug:
            print(f"\n📊 Structure summary:")
            print(f"  Devices: {len(structure['transistors'])}")
            print(f"  Nets: {len(structure['nets'])}")
            print(f"  Hierarchy: {len(structure['hierarchy'])}")
            print(f"  Modules: {len(structure['modules'])}")

        return structure

    def _extract_from_module(self, module, structure: Dict, prefix: str = "", processed: set = None):
        """
        Recursively extract devices and nets from inside a PyModule

        Handles both dict-based and direct object structures.
        Captures all devices (type='d') - transistors, resistors, capacitors, etc.

        Args:
            module: PyModule instance
            structure: Structure dict to populate
            prefix: Hierarchical prefix for naming (e.g., "ldo_top.stage1")
            processed: Set of already processed device names to avoid duplicates
        """
        if processed is None:
            processed = set()

        if self.debug:
            print(f"    → Recursing into module: {prefix}")

        # Check if module has elem_dict (circuit elements)
        if hasattr(module, 'elem_dict'):
            if self.debug:
                print(f"      Module has elem_dict with {len(module.elem_dict)} elements")

            for elem_name, elem_entry in module.elem_dict.items():
                full_name = f"{prefix}.{elem_name}" if prefix else elem_name

                if self.debug:
                    print(f"      Examining: {full_name}")

                # Handle dict-based structure: {'device': obj, 'type': 'd'/'m'}
                if isinstance(elem_entry, dict):
                    elem_data = elem_entry.get('device')
                    elem_type = elem_entry.get('type')

                    if self.debug:
                        print(f"        Dict entry: type='{elem_type}', device={type(elem_data).__name__}")

                    if elem_type == 'm':
                        # Nested module - recurse further
                        self._extract_from_module(elem_data, structure, prefix=full_name, processed=processed)

                    elif elem_type == 'd':
                        # Found a device! (transistor, resistor, etc.)
                        if full_name not in processed:
                            device_info = self._extract_transistor_info(full_name, elem_data, None)
                            if device_info:
                                structure['transistors'].append(device_info)
                                processed.add(full_name)
                                if self.debug:
                                    print(f"        ✓ Added device: {full_name}")

                else:
                    # Handle direct object (old style)
                    if self.debug:
                        print(f"        Direct object: {type(elem_entry).__name__}")

                    if self._is_pymodule(elem_entry):
                        # Nested module - recurse further
                        self._extract_from_module(elem_entry, structure, prefix=full_name, processed=processed)

                    elif self._is_transistor(elem_entry):
                        # Found a device!
                        if full_name not in processed:
                            device_info = self._extract_transistor_info(full_name, elem_entry, None)
                            if device_info:
                                structure['transistors'].append(device_info)
                                processed.add(full_name)
                                if self.debug:
                                    print(f"        ✓ Added device: {full_name}")
        else:
            if self.debug:
                print(f"      Module has no elem_dict")

        # Also extract nets from module if available
        if hasattr(module, 'net_dict'):
            for net_name, net_data in module.net_dict.items():
                # Check if net already in structure (avoid duplicates)
                if not any(n['name'] == net_name for n in structure['nets']):
                    net_info = self._extract_net_info(net_name, net_data)
                    structure['nets'].append(net_info)
                    if self.debug:
                        print(f"        ✓ Added net: {net_name}")

    def _is_pymodule(self, elem_data) -> bool:
        """Check if element is a PyModule (subcircuit)"""
        # Check if it's a PyModule instance
        return type(elem_data).__name__ == 'PyModule' or \
               hasattr(elem_data, 'moduleNames') or \
               hasattr(elem_data, 'elem_dict')

    def _is_transistor(self, elem_data) -> bool:
        """
        Check if element is a device (transistor, resistor, capacitor, etc.)

        For PyNetlist, we capture all devices - the type='d' check is done
        at the caller level, so this just validates the device object.
        """
        # If it has deviceType attribute (original detection)
        if hasattr(elem_data, 'deviceType'):
            return True

        # If it has parameters (common for all devices)
        if hasattr(elem_data, 'parameters'):
            return True

        # If it has pin_list (PyNetlist devices have this)
        if hasattr(elem_data, 'pin_list'):
            return True

        # Default: assume it's a device if we got here
        # (caller already filtered by type='d')
        return True

    def _extract_transistor_info(self, name: str, device, netlist) -> Optional[Dict]:
        """
        Extract complete device information (transistor, resistor, capacitor, etc.)

        Returns dict with:
        - name
        - type (if available, e.g., 'nmos', 'pmos', 'resistor')
        - all parameters (w, l, m, r, c, etc.)
        - all net connections
        - model (if available)
        """
        try:
            info = {
                'name': name,
                'type': 'device',  # Default type
                'parameters': {},
                'nets': {}
            }

            # Try to get device type (various possible attribute names)
            if hasattr(device, 'deviceType'):
                info['type'] = device.deviceType
            elif hasattr(device, 'device_type'):
                info['type'] = device.device_type
            elif hasattr(device, 'type'):
                info['type'] = device.type
            elif hasattr(device, 'pdk_device'):
                # Use pdk_device as type if nothing else available
                info['type'] = device.pdk_device
            elif hasattr(device, 'model'):
                # Use model as type
                info['type'] = device.model

            # Extract all parameters - try multiple formats

            # Format 1: param_list (PyNetlist PDKDevice style)
            if hasattr(device, 'param_list'):
                for param_name, param_obj in device.param_list.items():
                    try:
                        # param_list[p].value.value (double .value!)
                        if hasattr(param_obj, 'value'):
                            if hasattr(param_obj.value, 'value'):
                                # Double nested: param_list[p].value.value
                                info['parameters'][param_name] = param_obj.value.value
                            else:
                                # Single nested: param_list[p].value
                                info['parameters'][param_name] = param_obj.value
                        else:
                            # Direct value
                            info['parameters'][param_name] = param_obj
                    except Exception as e:
                        if self.debug:
                            print(f"      Warning: Could not extract parameter {param_name}: {e}")

            # Format 2: parameters dict
            elif hasattr(device, 'parameters'):
                for param_name, param_value in device.parameters.items():
                    # Handle ModuleVariable or direct values
                    if hasattr(param_value, 'value'):
                        info['parameters'][param_name] = param_value.value
                    else:
                        info['parameters'][param_name] = param_value

            # Extract net connections

            # Format 1: pin_list (PyNetlist style)
            if hasattr(device, 'pin_list'):
                for pin_name, pin_obj in device.pin_list.items():
                    if hasattr(pin_obj, 'net'):
                        info['nets'][pin_name] = pin_obj.net

            # Format 2: nets dict
            elif hasattr(device, 'nets'):
                for terminal, net_name in device.nets.items():
                    info['nets'][terminal] = net_name

            # Add model if available
            if hasattr(device, 'model'):
                info['model'] = device.model
            elif hasattr(device, 'pdk_device'):
                info['model'] = device.pdk_device

            return info

        except Exception as e:
            if self.debug:
                print(f"    ⚠️  Error extracting device {name}: {e}")
            return None

    def _extract_module_info(self, name: str, module, netlist) -> Optional[Dict]:
        """
        Extract module/subcircuit information

        Returns dict with:
        - instance_name
        - module_type
        - port_connections
        - parameters
        """
        try:
            info = {
                'instance_name': name,
                'module_type': None,
                'ports': {},
                'parameters': {}
            }

            # Get module name
            if hasattr(module, 'module_name'):
                info['module_type'] = module.module_name

            # Get port connections
            if hasattr(module, 'nets'):
                info['ports'] = dict(module.nets)

            # Get parameters if any
            if hasattr(module, 'parameters'):
                for param_name, param_value in module.parameters.items():
                    if hasattr(param_value, 'value'):
                        info['parameters'][param_name] = param_value.value
                    else:
                        info['parameters'][param_name] = param_value

            return info

        except Exception as e:
            if self.debug:
                print(f"    ⚠️  Error extracting module {name}: {e}")
            return None

    def _extract_net_info(self, name: str, net_data) -> Dict:
        """Extract net information"""
        # Classify net type
        net_type = 'signal'  # default

        name_lower = name.lower()
        if 'vdd' in name_lower or 'vcc' in name_lower or 'vpwr' in name_lower:
            net_type = 'power'
        elif 'gnd' in name_lower or 'vss' in name_lower or name == '0':
            net_type = 'ground'

        return {
            'name': name,
            'type': net_type
        }

    def _extract_module_structure(self, module, prefix: str = "") -> Dict:
        """
        Extract structure of a single module (for module hash computation)

        Args:
            module: PyModule instance
            prefix: Module path prefix

        Returns:
            dict: {
                'devices': [list of device info],
                'nets': [list of net names],
                'submodules': {name: hash}
            }
        """
        module_struct = {
            'devices': [],
            'nets': [],
            'submodules': {}
        }

        # Extract devices from this module
        if hasattr(module, 'elem_dict'):
            for elem_name, elem_entry in module.elem_dict.items():
                if isinstance(elem_entry, dict):
                    elem_data = elem_entry.get('device')
                    elem_type = elem_entry.get('type')

                    if elem_type == 'd':
                        # Device
                        device_info = self._extract_transistor_info(elem_name, elem_data, None)
                        if device_info:
                            module_struct['devices'].append(device_info)

                    elif elem_type == 'm':
                        # Submodule - recursively get its hash
                        sub_struct = self._extract_module_structure(elem_data, elem_name)
                        sub_hash = self._compute_module_hash(sub_struct)
                        module_struct['submodules'][elem_name] = sub_hash

        # Extract nets
        if hasattr(module, 'net_dict'):
            module_struct['nets'] = list(module.net_dict.keys())

        return module_struct

    def _compute_module_hash(self, module_structure: Dict) -> str:
        """
        Compute hash of a single module structure

        Hash is based on:
        - Device names, types, parameters (sorted)
        - Net names (sorted)
        - Submodule hashes (sorted)

        Args:
            module_structure: Dict from _extract_module_structure()

        Returns:
            str: SHA256 hash of module
        """
        # Sort devices by name
        sorted_devices = sorted(
            module_structure.get('devices', []),
            key=lambda x: x.get('name', '')
        )

        # Sort nets
        sorted_nets = sorted(module_structure.get('nets', []))

        # Sort submodules by name
        sorted_submodules = dict(sorted(module_structure.get('submodules', {}).items()))

        canonical = json.dumps({
            'devices': sorted_devices,
            'nets': sorted_nets,
            'submodules': sorted_submodules
        }, sort_keys=True, default=str)

        hash_obj = hashlib.sha256(canonical.encode('utf-8'))
        return hash_obj.hexdigest()

    def _extract_parameters(self, module_name: str, module_data) -> List[Dict]:
        """Extract module-level parameters"""
        params = []

        if hasattr(module_data, 'parameters'):
            for param_name, param_value in module_data.parameters.items():
                params.append({
                    'module': module_name,
                    'name': param_name,
                    'value': param_value.value if hasattr(param_value, 'value') else param_value
                })

        return params

    def compute_structure_hash(self, structure: Dict) -> Tuple[str, Dict[str, str]]:
        """
        Compute hash of structure for change detection

        Hash is based on:
        - Device names, types, parameters, and connections (sorted)
        - Net names and types (sorted)
        - Hierarchy (sorted)
        - Module hashes (sorted) - NEW!

        Order-independent: Same devices in different order = same hash

        Args:
            structure: Structure dict from extract_structure()

        Returns:
            tuple: (structure_hash: str, module_hashes: Dict[str, str])
        """
        # Create a copy to avoid modifying original
        import copy
        sorted_structure = copy.deepcopy(structure)

        # Sort all lists by a consistent key to ensure order independence

        # Sort transistors by name
        if 'transistors' in sorted_structure:
            sorted_structure['transistors'] = sorted(
                sorted_structure['transistors'],
                key=lambda x: x.get('name', '')
            )

        # Sort nets by name
        if 'nets' in sorted_structure:
            sorted_structure['nets'] = sorted(
                sorted_structure['nets'],
                key=lambda x: x.get('name', '')
            )

        # Sort hierarchy by instance name
        if 'hierarchy' in sorted_structure:
            sorted_structure['hierarchy'] = sorted(
                sorted_structure['hierarchy'],
                key=lambda x: x.get('instance_name', '')
            )

        # Sort parameters by module and name
        if 'parameters' in sorted_structure:
            sorted_structure['parameters'] = sorted(
                sorted_structure['parameters'],
                key=lambda x: (x.get('module', ''), x.get('name', ''))
            )

        # Create canonical representations
        canonical_transistors = json.dumps(sorted_structure.get('transistors', []), sort_keys=True, default=str)
        canonical_nets = json.dumps(sorted_structure.get('nets', []), sort_keys=True, default=str)
        canonical_hierarchy = json.dumps(sorted_structure.get('hierarchy', []), sort_keys=True, default=str)

        # NEW: Include module hashes in overall structure hash
        module_hashes = {path: data['hash'] for path, data in sorted_structure.get('modules', {}).items()}
        canonical_modules = json.dumps(module_hashes, sort_keys=True)

        # Combine all canonical representations
        combined_data = (
            canonical_transistors +
            canonical_nets +
            canonical_hierarchy +
            canonical_modules  # Include module hashes in overall hash
        )

        # Compute overall structure hash
        structure_hash = hashlib.sha256(combined_data.encode()).hexdigest()

        if self.debug:
            print(f"\n🔐 Structure hash computation:")
            print(f"  Devices: {len(sorted_structure.get('transistors', []))}")
            print(f"  Nets: {len(sorted_structure.get('nets', []))}")
            print(f"  Modules: {len(module_hashes)}")
            print(f"  Hash: {structure_hash[:16]}...")

        return structure_hash, module_hashes

    def _compare_module_hashes(self, current_modules: Dict) -> Dict[str, bool]:
        """
        Compare current module hashes with stored hashes to detect module-level changes

        Args:
            current_modules: Dict of current modules with their hashes

        Returns:
            Dict[module_name: changed (bool)]
        """
        if not current_modules:
            return {}

        module_changes = {}

        for module_name, module_data in current_modules.items():
            current_hash = module_data.get('hash')
            previous_hash = self._last_module_hashes.get(module_name)

            # Module changed if hash is different or module is new
            module_changes[module_name] = (current_hash != previous_hash)

            if self.debug and module_changes[module_name]:
                if previous_hash is None:
                    print(f"  🆕 Module '{module_name}' is NEW")
                else:
                    print(f"  ⚠️  Module '{module_name}' has CHANGED")
                    print(f"      Old hash: {previous_hash[:16]}...")
                    print(f"      New hash: {current_hash[:16]}...")

        # Check for deleted modules
        for old_module_name in self._last_module_hashes:
            if old_module_name not in current_modules:
                module_changes[old_module_name] = True
                if self.debug:
                    print(f"  🗑️  Module '{old_module_name}' was DELETED")

        return module_changes

    def has_structure_changed(self, current_hash: str) -> bool:
        """
        Check if structure has changed from last stored version

        Args:
            current_hash: Hash of current structure

        Returns:
            bool: True if structure changed or this is first run
        """
        if self._last_structure_hash is None:
            if self.debug:
                print("  → First run, structure is new")
            return True

        changed = (current_hash != self._last_structure_hash)

        if self.debug:
            if changed:
                print(f"  → Structure changed!")
                print(f"    Last: {self._last_structure_hash[:16]}...")
                print(f"    Current: {current_hash[:16]}...")
            else:
                print(f"  → Structure unchanged (hash: {current_hash[:16]}...)")

        return changed

    def store_structure(self, structure: Dict, structure_hash: str, module_hashes: Dict[str, str] = None):
        """
        Store structure in database

        Args:
            structure: Structure dict from extract_structure()
            structure_hash: Hash of structure
            module_hashes: Dict of module hashes (optional, will be extracted if not provided)
        """
        # If module_hashes not provided, extract from structure
        if module_hashes is None:
            module_hashes = {}
            for module_path, module_data in structure.get('modules', {}).items():
                if isinstance(module_data, dict):
                    module_hashes[module_path] = module_data.get('hash', '')
        if self.debug:
            print("\n💾 Storing structure in database...")
            print(f"  circuit_id: {self.circuit_id}")
            print(f"  devices in structure: {len(structure.get('transistors', []))}")

        # Store all devices (transistors, resistors, capacitors, etc.)
        device_count = 0

        for device in structure['transistors']:  # Note: 'transistors' list contains all devices
            device_type = device.get('type', 'device')
            model = device.get('model', device_type)

            # Store ALL parameters as JSON
            properties = device['parameters']
            properties_json = json.dumps(properties, default=str)

            # Check if already exists
            cursor = self.db.conn.cursor()
            cursor.execute("""
                SELECT device_id FROM devices
                WHERE circuit_version_id = ? AND name = ?
            """, (self.circuit_id, device['name']))

            existing = cursor.fetchone()

            if existing:
                # Update existing
                self.db.conn.execute("""
                    UPDATE devices
                    SET type = ?, model = ?, properties = ?
                    WHERE circuit_version_id = ? AND name = ?
                """, (
                    device_type,
                    model,
                    properties_json,
                    self.circuit_id,
                    device['name']
                ))
            else:
                # Insert new
                device_id = str(uuid.uuid4())
                cursor.execute("""
                    INSERT INTO devices 
                    (device_id, circuit_version_id, name, type, model, properties)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    device_id,
                    self.circuit_id,
                    device['name'],
                    device_type,
                    model,
                    properties_json
                ))

            device_count += 1

        # Store nets
        net_count = 0
        for net in structure['nets']:
            # Check if already exists
            cursor = self.db.conn.cursor()
            cursor.execute("""
                SELECT net_id FROM nets
                WHERE circuit_version_id = ? AND name = ?
            """, (self.circuit_id, net['name']))

            if not cursor.fetchone():
                self.db.add_net(
                    circuit_version_id=self.circuit_id,
                    name=net['name'],
                    net_type=net['type']
                )
                net_count += 1

        # Store modules using new schema (independent modules table + junction table)
        module_count = 0
        if self.debug:
            print(f"\n  📦 Storing modules...")
            print(f"     Modules to store: {len(structure.get('modules', {}))}")

        for position, (module_name, module_data) in enumerate(structure.get('modules', {}).items()):
            if isinstance(module_data, dict):
                module_hash = module_data.get('hash', '')
                device_count_in_module = module_data.get('device_count', 0)

                if self.debug:
                    print(f"     Processing module: {module_name} (hash: {module_hash[:16]}...)")

                # Prepare module structure as JSON
                module_structure = {
                    'devices': module_data.get('devices', []),
                    'nets': module_data.get('nets', []),
                    'submodules': module_data.get('submodules', {})
                }

                try:
                    # Use new database method: insert_or_get_module
                    # This checks if module with same hash exists, returns existing or creates new
                    module_id = self.db.insert_or_get_module(
                        module_name=module_name,
                        module_path=module_name,  # Use module_name as path for now
                        module_hash=module_hash,
                        device_count=device_count_in_module,
                        structure=module_structure
                    )

                    # Link module to circuit using junction table
                    self.db.link_module_to_circuit(
                        circuit_version_id=self.circuit_id,
                        module_id=module_id,
                        instance_name=module_name,
                        position=position
                    )

                    if self.debug:
                        print(f"       ✓ Module '{module_name}' linked to circuit (reused if hash exists)")

                    module_count += 1

                except Exception as e:
                    # modules table doesn't exist or other error
                    if self.debug:
                        print(f"  ⚠️  Could not store module '{module_name}': {e}")

                    # If it's a table doesn't exist error, stop trying
                    if "no such table" in str(e).lower():
                        if self.debug:
                            print(f"      (modules table doesn't exist - stopping module storage)")
                        break  # Don't try to insert more modules
                    # Otherwise, continue with next module (maybe this specific module had an issue)

        # Update metadata with structure hash, module hashes, and run count
        self._update_metadata(structure_hash, module_hashes)

        # Update cache
        self._last_structure_hash = structure_hash
        self._last_module_hashes = module_hashes

        if self.debug:
            print(f"  ✓ Stored {device_count} devices")
            print(f"  ✓ Stored {net_count} new nets")
            if module_count > 0:
                print(f"  ✓ Stored {module_count} modules in database")
            if module_hashes:
                print(f"  ✓ Tracked {len(module_hashes)} module hashes in metadata")

        self.db.conn.commit()

    def increment_run_count(self):
        """Increment run count for unchanged structure"""
        self._current_run_count += 1
        self._update_run_count()

        if self.debug:
            print(f"  ✓ Incremented run count to {self._current_run_count}")

    def _update_changed_modules(self, structure: Dict, module_changes: Dict[str, bool]):
        """
        Update only the modules that have changed in the database.

        This is called when the overall structure hasn't changed but individual
        modules have changed (edge case, but we handle it for robustness).

        Args:
            structure: Full structure dict with modules
            module_changes: Dict indicating which modules changed
        """
        if self.debug:
            print("\n  📦 Updating changed modules...")

        modules_updated = 0

        for position, (module_name, has_changed) in enumerate(module_changes.items()):
            if not has_changed:
                continue  # Skip unchanged modules

            # Get module data from structure
            module_data = structure.get('modules', {}).get(module_name)
            if not module_data:
                continue

            module_hash = module_data.get('hash', '')
            device_count_in_module = module_data.get('device_count', 0)

            # Prepare module structure as JSON
            module_structure = {
                'devices': module_data.get('devices', []),
                'nets': module_data.get('nets', []),
                'submodules': module_data.get('submodules', {})
            }

            try:
                # Use new database method: insert_or_get_module
                module_id = self.db.insert_or_get_module(
                    module_name=module_name,
                    module_path=module_name,
                    module_hash=module_hash,
                    device_count=device_count_in_module,
                    structure=module_structure
                )

                # Link module to circuit (will replace if already exists due to INSERT OR REPLACE)
                self.db.link_module_to_circuit(
                    circuit_version_id=self.circuit_id,
                    module_id=module_id,
                    instance_name=module_name,
                    position=position
                )

                if self.debug:
                    print(f"    ✓ Updated module '{module_name}' (hash: {module_hash[:16]}...)")

                modules_updated += 1

            except Exception as e:
                if self.debug:
                    print(f"    ⚠️  Could not update module '{module_name}': {e}")

        if modules_updated > 0:
            self.db.conn.commit()

            # Update module hashes in metadata
            current_module_hashes = {name: data['hash'] for name, data in structure.get('modules', {}).items()}
            self._last_module_hashes = current_module_hashes

            # Update metadata to reflect new module hashes
            cursor = self.db.conn.cursor()
            cursor.execute("""
                SELECT metadata FROM circuit_versions
                WHERE version_id = ?
            """, (self.circuit_id,))

            row = cursor.fetchone()
            metadata = {}

            if row and row[0]:
                try:
                    metadata = json.loads(row[0])
                except (json.JSONDecodeError, TypeError):
                    pass

            metadata['module_hashes'] = current_module_hashes
            metadata['last_module_update'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            cursor.execute("""
                UPDATE circuit_versions
                SET metadata = ?
                WHERE version_id = ?
            """, (json.dumps(metadata), self.circuit_id))

            self.db.conn.commit()

            if self.debug:
                print(f"  ✓ Updated {modules_updated} module(s) in database")

    def _update_metadata(self, structure_hash: str, module_hashes: Dict[str, str] = None):
        """
        Update circuit metadata with structure hash, module hashes, and run count

        Args:
            structure_hash: Hash of entire circuit structure
            module_hashes: Dict mapping module paths to their hashes
        """
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT metadata FROM circuit_versions
            WHERE version_id = ?
        """, (self.circuit_id,))

        row = cursor.fetchone()
        metadata = {}

        if row and row[0]:
            try:
                metadata = json.loads(row[0])
            except (json.JSONDecodeError, TypeError):
                pass

        # Update metadata
        metadata['structure_hash'] = structure_hash
        metadata['run_count'] = 1  # Reset to 1 on structure change
        metadata['last_structure_update'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Store module hashes
        if module_hashes:
            metadata['module_hashes'] = module_hashes

        # Store back
        cursor.execute("""
            UPDATE circuit_versions
            SET metadata = ?
            WHERE version_id = ?
        """, (json.dumps(metadata), self.circuit_id))

        self._current_run_count = 1

    def _update_run_count(self):
        """Update run count in metadata"""
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT metadata FROM circuit_versions
            WHERE version_id = ?
        """, (self.circuit_id,))

        row = cursor.fetchone()
        metadata = {}

        if row and row[0]:
            try:
                metadata = json.loads(row[0])
            except (json.JSONDecodeError, TypeError):
                pass

        metadata['run_count'] = self._current_run_count
        metadata['last_run'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        cursor.execute("""
            UPDATE circuit_versions
            SET metadata = ?
            WHERE version_id = ?
        """, (json.dumps(metadata), self.circuit_id))

        self.db.conn.commit()

    def _find_circuit_by_hash(self, circuit_name: str, structure_hash: str) -> Optional[str]:
        """
        Find existing circuit_id with matching structure hash

        Args:
            circuit_name: Circuit name to search within
            structure_hash: Structure hash to match

        Returns:
            str: circuit_id (version_id) if found, None otherwise
        """
        cursor = self.db.conn.cursor()
        cursor.execute("""
            SELECT version_id, metadata
            FROM circuit_versions
            WHERE circuit_name = ?
        """, (circuit_name,))

        import json
        for row in cursor.fetchall():
            version_id = row[0]
            metadata_str = row[1]

            if metadata_str:
                try:
                    metadata = json.loads(metadata_str)
                    if metadata.get('structure_hash') == structure_hash:
                        return version_id
                except (json.JSONDecodeError, TypeError):
                    pass

        return None

    def track_and_store_if_changed_OLD(self, netlist) -> Tuple[bool, str, Dict[str, bool]]:
        """
        Main entry point: Extract structure, check for changes, store if changed

        Logic:
        1. Compute structure hash
        2. Check if this hash exists in database for this circuit
        3. If exists → switch to that circuit_id and increment run_count
        4. If new → store structure in current circuit_id
        5. Compare module hashes to detect which modules changed

        Args:
            netlist: PyNetlist instance

        Returns:
            tuple: (structure_changed: bool, structure_hash: str, module_changes: Dict[str, bool])
        """
        if self.debug:
            print("\n" + "="*60)
            print("CIRCUIT STRUCTURE TRACKING")
            print("="*60)

        # Extract current structure
        structure = self.extract_structure(netlist)

        # Compute hash and get module hashes
        structure_hash, module_hashes = self.compute_structure_hash(structure)

        # Compare module hashes to detect changes
        module_changes = self._compare_module_hashes(structure.get('modules', {}))

        # Report module changes
        if self.debug and module_changes:
            changed_modules = [m for m, changed in module_changes.items() if changed]
            if changed_modules:
                print(f"\n📦 Module changes detected: {len(changed_modules)} module(s)")
                for module_name in changed_modules:
                    print(f"    • {module_name}")

        # Get circuit name from netlist
        circuit_name = getattr(netlist, 'circuit_name', None)

        if circuit_name:
            # Check if this hash already exists for this circuit
            existing_circuit_id = self._find_circuit_by_hash(circuit_name, structure_hash)

            if existing_circuit_id and existing_circuit_id != self.circuit_id:
                # Hash exists - delete the newly created empty circuit and switch to existing
                if self.debug:
                    print(f"  ✓ Found existing circuit with same hash: {existing_circuit_id}")
                    print(f"    Deleting empty circuit: {self.circuit_id}")

                # Delete the empty circuit entry
                cursor = self.db.conn.cursor()
                cursor.execute("""
                    DELETE FROM circuit_versions 
                    WHERE version_id = ?
                """, (self.circuit_id,))
                self.db.conn.commit()

                # Switch to existing circuit
                self.circuit_id = existing_circuit_id

                # Load its run count and module hashes
                self._load_last_structure()

                # Increment run count
                self.increment_run_count()

                print(f"✓ Structure matches existing circuit, run count: {self._current_run_count}")

                if self.debug:
                    print("="*60 + "\n")

                return False, structure_hash, {}  # Not changed, using existing

        # No existing circuit with this hash - check if structure changed from last stored
        changed = self.has_structure_changed(structure_hash)

        if changed:
            # Store new structure
            self.store_structure(structure, structure_hash, module_hashes)
            print(f"✓ Circuit structure stored (hash: {structure_hash[:16]}...)")

            # Report which modules changed
            if module_changes:
                changed_count = sum(1 for c in module_changes.values() if c)
                if changed_count > 0:
                    print(f"  → {changed_count} module(s) changed")
        else:
            # Structure unchanged, but check if individual modules changed
            # (This can happen in edge cases or if modules are tracked separately)
            if module_changes and any(module_changes.values()):
                # Some modules changed - update them in the database
                self._update_changed_modules(structure, module_changes)
                changed_count = sum(1 for c in module_changes.values() if c)
                print(f"✓ Structure unchanged, but {changed_count} module(s) updated")

            # Just increment run count
            self.increment_run_count()
            print(f"✓ Structure unchanged, run count: {self._current_run_count}")

        if self.debug:
            print("="*60 + "\n")

        return changed, structure_hash, module_changes

    def get_run_count(self) -> int:
        """Get current run count"""
        return self._current_run_count

    def get_structure_hash(self) -> Optional[str]:
        """Get current structure hash"""
        return self._last_structure_hash

    def get_module_changes(self) -> Dict[str, bool]:
        """Get dictionary of module changes from last run"""
        return self._last_module_hashes


# Example usage
if __name__ == "__main__":
    print("""
Circuit Structure Tracker - Usage Example

# In PyNetlist, after building circuit but before simulation:

from circuitdb import CircuitDatabase
from circuit_structure_tracker import CircuitStructureTracker

# Assuming you have a PyNetlist instance with tracking enabled
netlist = PyNetlist(..., circuit_name="ldo", db_path="designs.db")
netlist.create_circuit_version("LDO v1.0")

# Build your circuit
netlist.addElement(...)
netlist.addSource(...)

# Track structure automatically
tracker = CircuitStructureTracker(netlist.db, netlist.circuit_id, debug=True)
changed, hash_val, module_changes = tracker.track_and_store_if_changed(netlist)

if changed:
    print("New structure detected and stored!")
    if module_changes:
        changed_modules = [m for m, c in module_changes.items() if c]
        print(f"  {len(changed_modules)} module(s) changed: {changed_modules}")
else:
    print(f"Structure unchanged, run #{tracker.get_run_count()}")

# Continue with simulation...
netlist.runSimulator()
    """)