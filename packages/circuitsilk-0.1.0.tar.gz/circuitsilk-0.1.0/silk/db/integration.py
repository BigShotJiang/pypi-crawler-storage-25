"""
PyTrackedNetlist - Transparent Integration with Circuit Database

This module provides a drop-in replacement for PyNetlist that automatically
tracks circuits, simulations, and results in the circuit database.

Usage:
    from circuit_db_integration import PyTrackedNetlist, DesignStage
    
    netlist = PyTrackedNetlist(
        'PDK_skywater130', dirFolder, fname, pdkDetails=pdk130,
        circuit_name="ldo_nmos",
        version="1.0",
        stage=DesignStage.DEV,
        db_path="designs.db"
    )
"""

from silk.db.circuit_db import CircuitDatabase, DesignStage
import os
from typing import Dict, Tuple, Optional, Any


class TrackedModule:
    """
    Wrapper for PyNetlist that adds database tracking
    
    This is designed to be a drop-in replacement that wraps your existing
    PyNetlist class without requiring changes to PyNetlist itself.
    """
    
    def __init__(self, pdk_type, dir_folder, file_name, 
                 pdkDetails=None,
                 circuit_name: str = None,
                 version: str = "1.0",
                 stage: DesignStage = DesignStage.DEV,
                 db_path: str = "designs.db",
                 enable_tracking: bool = True,
                 auto_track_components: bool = False,
                 created_by: str = "user"):
        """
        Initialize PyTrackedNetlist
        
        Args:
            pdk_type: PDK type (e.g., 'PDK_skywater130')
            dir_folder: Directory for simulation files
            file_name: Netlist filename
            pdkDetails: PDK details object
            circuit_name: Name for circuit in database
            version: Version string (e.g., "1.0", "2.0")
            stage: Design stage (DesignStage.DEV, .STABLE, etc.)
            db_path: Path to SQLite database file
            enable_tracking: Enable/disable database tracking
            auto_track_components: Automatically track transistors/nets
            created_by: Who is creating this version
        """
        # Import PyNetlist here to avoid circular dependencies
        try:
            import silk.circuit.netlist as pn
            self._netlist = pn.PyNetlist(pdk_type, dir_folder, file_name,
                                         pdkDetails=pdkDetails)
        except ImportError:
            raise ImportError("PyNetlist module not found. Make sure silk.circuit.netlist is accessible.")
        
        # Tracking configuration
        self.tracking_enabled = enable_tracking
        self.auto_track_components = auto_track_components
        self.circuit_name = circuit_name or "unnamed_circuit"
        self.version = version
        self.stage = stage
        self.created_by = created_by
        
        # Database connection
        self.db = None
        self.circuit_id = None
        
        if self.tracking_enabled:
            self.db = CircuitDatabase(db_path)
            print(f"📊 Database tracking enabled: {db_path}")
        
        # Simulation metadata
        self._current_corner = "tt"
        self._current_temp = None
        self._current_voltage = None
        
        # Component tracking
        self._tracked_components = []
    
    def __getattr__(self, name):
        """
        Forward all other method calls to the wrapped PyNetlist instance
        This allows PyTrackedNetlist to act as a transparent wrapper
        """
        return getattr(self._netlist, name)
    
    # =========================================================================
    # Database Integration Methods
    # =========================================================================
    
    def create_circuit_version(self, description: str = "", 
                              netlist_path: str = None) -> str:
        """
        Create a circuit version in the database
        
        Call this ONCE before running simulations.
        
        Args:
            description: Description of this circuit version
            netlist_path: Path to netlist file (auto-detected if None)
            
        Returns:
            circuit_id: Database ID for this circuit version
        """
        if not self.tracking_enabled:
            print("⚠️  Tracking disabled, circuit not created in database")
            return None
        
        # Auto-detect netlist path
        if netlist_path is None:
            netlist_path = os.path.join(
                getattr(self._netlist, 'dirFolder', '..'),
                getattr(self._netlist, 'fileName', 'circuit.cir')
            )
        
        self.circuit_id = self.db.create_circuit(
            name=self.circuit_name,
            version=self.version,
            stage=self.stage,
            created_by=self.created_by,
            description=description,
            netlist_path=netlist_path
        )
        
        print(f"✓ Created circuit '{self.circuit_name}' v{self.version} "
              f"at stage '{self.stage.value}'")
        
        return self.circuit_id
    
    def store_results(self, results_dict: Dict[str, Tuple[float, str]], 
                     corner: str = None,
                     temperature: float = None,
                     voltage: float = None,
                     sim_type: str = "tran",
                     tool_name: str = "ngspice") -> None:
        """
        Store simulation results in the database
        
        Args:
            results_dict: Dictionary of {parameter: (value, unit)}
                         Example: {'gain': (45.2, 'dB'), 'power': (2.3, 'mW')}
            corner: Process corner (overrides auto-detected)
            temperature: Temperature in °C (overrides auto-detected)
            voltage: Supply voltage in V (overrides auto-detected)
            sim_type: Simulation type ('dc', 'ac', 'tran', 'noise')
            tool_name: Simulator name
            
        Example:
            results = {
                'quiescent_current': (100e-6, 'A'),
                'output_voltage': (1.8, 'V'),
                'settling_time': (200e-9, 's')
            }
            netlist.store_results(results, corner='tt', temperature=27)
        """
        if not self.tracking_enabled:
            print("⚠️  Tracking disabled, results not stored")
            return
        
        if self.circuit_id is None:
            print("⚠️  No circuit created. Call create_circuit_version() first!")
            return
        
        # Use provided values or fall back to auto-detected
        corner = corner or self._current_corner
        temperature = temperature or self._current_temp
        voltage = voltage or self._current_voltage
        
        # Store each result
        for param, (value, unit) in results_dict.items():
            self.db.add_simulation_result(
                circuit_version_id=self.circuit_id,
                parameter=param,
                value=value,
                unit=unit,
                corner=corner,
                temperature=temperature,
                voltage=voltage,
                sim_type=sim_type,
                tool_name=tool_name
            )
        
        # Print confirmation
        corner_str = f"{corner}" if corner else "nominal"
        temp_str = f"@{temperature}°C" if temperature else ""
        volt_str = f", {voltage}V" if voltage else ""
        
        print(f"✓ Stored {len(results_dict)} results for {self.circuit_name} "
              f"[{corner_str}{temp_str}{volt_str}]")
    
    def store_result(self, parameter: str, value: float, unit: str,
                    corner: str = None, temperature: float = None,
                    voltage: float = None, sim_type: str = "tran",
                    tool_name: str = "ngspice") -> None:
        """
        Store a single simulation result (convenience method)
        
        Args:
            parameter: Parameter name (e.g., 'gain', 'power')
            value: Numeric value
            unit: Unit string (e.g., 'dB', 'mW')
            corner: Process corner
            temperature: Temperature in °C
            voltage: Supply voltage in V
            sim_type: Simulation type
            tool_name: Simulator name
        """
        self.store_results(
            {parameter: (value, unit)},
            corner=corner,
            temperature=temperature,
            voltage=voltage,
            sim_type=sim_type,
            tool_name=tool_name
        )
    
    def store_pass_fail(self, spec_name: str, status: str,
                       details: str = "") -> None:
        """
        Store a pass/fail result
        
        Args:
            spec_name: Name of specification
            status: "PASS" or "FAIL"
            details: Additional details
        """
        if not self.tracking_enabled or self.circuit_id is None:
            return
        
        value_text = f"{status}"
        if details:
            value_text += f" ({details})"
        
        self.db.add_simulation_result(
            circuit_version_id=self.circuit_id,
            parameter=f"spec_{spec_name}",
            value_text=value_text
        )
    
    def set_corner(self, corner: str, temperature: float = None, 
                   voltage: float = None) -> None:
        """
        Set the current corner for subsequent result storage
        
        Args:
            corner: Corner name ('tt', 'ss', 'ff', 'sf', 'fs')
            temperature: Temperature in °C
            voltage: Supply voltage in V
        """
        self._current_corner = corner
        if temperature is not None:
            self._current_temp = temperature
        if voltage is not None:
            self._current_voltage = voltage
        
        print(f"📍 Set corner: {corner}", end="")
        if temperature:
            print(f" @ {temperature}°C", end="")
        if voltage:
            print(f", {voltage}V", end="")
        print()
    
    def view_summary(self) -> str:
        """
        View the automatic simulation summary
        
        Returns:
            Summary text
        """
        if not self.tracking_enabled or self.circuit_id is None:
            print("⚠️  No circuit to summarize")
            return None
        
        summary = self.db.get_simulation_summary(self.circuit_id)
        print(summary)
        return summary
    
    def promote(self, to_stage: str, new_version: str = None,
               lock: bool = True, description: str = "") -> str:
        """
        Promote circuit to next design stage
        
        Args:
            to_stage: Target stage ('stable', 'post_layout', 'tapeout')
            new_version: New version number (auto-generated if None)
            lock: Lock the promoted version (recommended)
            description: Description of promotion
            
        Returns:
            New circuit_id
        """
        if not self.tracking_enabled or self.circuit_id is None:
            print("⚠️  Cannot promote: no circuit in database")
            return None
        
        stage_map = {
            'stable': DesignStage.STABLE,
            'post_layout': DesignStage.POST_LAYOUT,
            'tapeout': DesignStage.TAPEOUT
        }
        
        if to_stage not in stage_map:
            print(f"⚠️  Invalid stage: {to_stage}")
            return None
        
        new_id = self.db.promote_circuit(
            circuit_name=self.circuit_name,
            from_stage=self.stage,
            to_stage=stage_map[to_stage],
            new_version=new_version,
            lock=lock,
            created_by=self.created_by,
            description=description or f"Promoted from {self.stage.value}"
        )
        
        print(f"✓ Promoted to {to_stage}")
        
        return new_id
    
    def add_transistor(self, name: str, transistor_type: str,
                      width: float, length: float, 
                      multiplier: int = 1, model: str = None) -> None:
        """
        Manually add a transistor to the database
        
        Args:
            name: Transistor name (e.g., 'M1', 'nmos_input_p')
            transistor_type: Type ('nmos', 'pmos', 'nfet', 'pfet')
            width: Width in meters
            length: Length in meters
            multiplier: Number of parallel devices
            model: Model name
        """
        if not self.tracking_enabled or self.circuit_id is None:
            return
        
        self.db.add_transistor(
            circuit_version_id=self.circuit_id,
            name=name,
            transistor_type=transistor_type,
            width=width,
            length=length,
            multiplier=multiplier,
            model=model
        )
    
    def add_net(self, name: str, net_type: str = "signal") -> None:
        """
        Manually add a net to the database
        
        Args:
            name: Net name (e.g., 'vdd', 'vout')
            net_type: Type ('signal', 'power', 'ground', 'clock')
        """
        if not self.tracking_enabled or self.circuit_id is None:
            return
        
        self.db.add_net(
            circuit_version_id=self.circuit_id,
            name=name,
            net_type=net_type
        )
    
    def get_corner_summary(self) -> Dict:
        """Get summary of all corners simulated"""
        if not self.tracking_enabled or self.circuit_id is None:
            return {}
        
        return self.db.get_corner_summary(self.circuit_id)
    
    def get_corners_for_parameter(self, parameter: str) -> list:
        """Get all corner results for a specific parameter"""
        if not self.tracking_enabled or self.circuit_id is None:
            return []
        
        return self.db.get_corners_for_parameter(self.circuit_id, parameter)
    
    def export_to_json(self, output_file: str) -> None:
        """
        Export this circuit to JSON for Git
        
        Args:
            output_file: Path to output JSON file
        """
        if not self.tracking_enabled or self.circuit_id is None:
            print("⚠️  Cannot export: no circuit in database")
            return
        
        from circuit_import import CircuitExporter
        exporter = CircuitExporter(self.db)
        exporter.export_to_json(
            self.circuit_name,
            output_file,
            version=self.version
        )
        
        print(f"✓ Exported to {output_file}")
    
    def close(self) -> None:
        """Close database connection"""
        if self.db:
            self.db.close()
            print("✓ Database connection closed")


# Convenience function for backward compatibility
def create_tracked_netlist(*args, **kwargs):
    """
    Create a PyTrackedNetlist instance
    
    This is a convenience function for cleaner imports.
    """
    return PyTrackedNetlist(*args, **kwargs)


# Example usage
if __name__ == "__main__":
    print("""
PyTrackedNetlist - Integration Example

Usage:
    from circuit_db_integration import PyTrackedNetlist, DesignStage
    
    # Create tracked netlist
    netlist = PyTrackedNetlist(
        'PDK_skywater130', dirFolder, fname, pdkDetails=pdk130,
        circuit_name="my_circuit",
        version="1.0",
        stage=DesignStage.DEV,
        db_path="designs.db"
    )
    
    # Create circuit in database
    netlist.create_circuit_version(
        description="Initial design"
    )
    
    # Build netlist (your existing code)
    netlist.addElement(...)
    netlist.addSource(...)
    
    # Run simulation (your existing code)
    netlist.runSimulator()
    
    # Store results
    results = {
        'gain': (45.2, 'dB'),
        'power': (2.3, 'mW')
    }
    netlist.store_results(results, corner='tt', temperature=27)
    
    # View summary
    netlist.view_summary()
    
    # Promote when ready
    netlist.promote('stable', lock=True)
    
    # Close database
    netlist.close()
    """)

# Backward-compat alias
PyTrackedNetlist = TrackedModule
