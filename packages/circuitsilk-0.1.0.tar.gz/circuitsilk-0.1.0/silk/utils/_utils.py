# Shared formatting utilities for silk


def _fmt(value) -> str:
    """Format a value with SI suffix for SPICE output.

    Strings pass through unchanged. Numbers are formatted with the appropriate
    SI suffix (k, Meg, G, T for large; m, u, n, p, f for small).
    """
    if isinstance(value, str):
        return value
    if value == 0:
        return '0'
    negative = value < 0
    abs_val = abs(value)
    for threshold, suffix in [
        (1e12, 'T'), (1e9, 'G'), (1e6, 'Meg'), (1e3, 'k'),
        (1, ''), (1e-3, 'm'), (1e-6, 'u'), (1e-9, 'n'), (1e-12, 'p'), (1e-15, 'f'),
    ]:
        if abs_val >= threshold:
            mantissa = abs_val / threshold if threshold != 1 else abs_val
            formatted = f'{mantissa:g}{suffix}'
            return f'-{formatted}' if negative else formatted
    formatted = f'{abs_val:g}'
    return f'-{formatted}' if negative else formatted
