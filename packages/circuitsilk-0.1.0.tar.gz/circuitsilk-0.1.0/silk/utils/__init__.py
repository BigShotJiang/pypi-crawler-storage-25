"""silk.utils — shared formatting utilities."""
from silk.utils._utils import _fmt as format_spice_value

__all__ = ["format_spice_value"]
