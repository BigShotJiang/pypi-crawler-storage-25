"""SkyWater 130nm open-source PDK implementation for PyNetlist.

Corner models are sections within a single sky130.lib.spice file
(tt, ss, ff, sf, fs) rather than separate files per corner.
"""

from .basepdk import (BasePDK, UNIT_PDK, UNIT_SI, ValidationError,
                      PDKDevice, ParameterConstraint, Pin)

# Re-export so existing imports from pynetlist.pdk.skywater130 keep working
__all__ = [
    'PDK_skywater130',
    'UNIT_PDK', 'UNIT_SI',
    'PDKDevice', 'ParameterConstraint', 'Pin', 'ValidationError',
]


class PDK_skywater130(BasePDK):
    """SkyWater 130nm open-source PDK.

    Uses the standard PyNetlist YAML schema.  W and L are in µm by default
    (``unit_mode=UNIT_PDK``); pass ``unit_mode=UNIT_SI`` to supply values in
    SI metres and have them converted automatically.

    Args:
        modelList:        Path to the sky130 device YAML file.
        libraryLocation:  Path to sky130.lib.spice.
        unit_mode:        ``UNIT_PDK`` (default, µm) or ``UNIT_SI`` (metres).
        debug:            Print verbose loading and netlist output.
    """

    def __init__(self, modelList, libraryLocation, unit_mode=UNIT_PDK, debug=False):
        super().__init__(modelList, libraryLocation, unit_mode=unit_mode, debug=debug)

    def getCornerPath(self, corner: str) -> str:
        """sky130 uses a single lib file with named sections per corner."""
        return self.libraryLocation
