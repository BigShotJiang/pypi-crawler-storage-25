"""Base PDK class and shared data structures for PyNetlist PDK implementations.

All PDK classes should inherit from BasePDK. The standard PyNetlist YAML schema
is parsed here; subclasses override initializeDeviceList() for other formats and
getCornerPath() for corner-specific model file handling.
"""

import yaml
from dataclasses import dataclass
from typing import Dict, Optional

from silk.exceptions import PyNetlistError, DuplicateNameError, UndeclaredNetError, SimulationError, PDKError

# ---------------------------------------------------------------------------
# Unit mode constants — pass as unit_mode= to any PDK constructor
# ---------------------------------------------------------------------------

UNIT_PDK = 'pdk'
# Use PDK-native units as declared in the YAML (e.g. µm for W/L in sky130).
# This is the default. A notice is printed at PDK initialisation time.

UNIT_SI = 'si'
# Pass values in SI metres. The PDK automatically converts to PDK-native units
# before writing the netlist and before range checking.

# Conversion factors: SI metres → PDK unit suffix
_SI_TO_PDK_SCALE = {
    'u': 1e6,    # metres → micrometres
    'n': 1e9,    # metres → nanometres
    'p': 1e12,   # metres → picofarads (capacitors)
    'm': 1e3,    # metres → millimetres
}


# ---------------------------------------------------------------------------
# Shared data structures
# ---------------------------------------------------------------------------

class ValidationError(Exception):
    """Raised for invalid PDK configuration or out-of-range parameter values."""
    pass


@dataclass
class Pin:
    name: str           # short name as used in the netlist (e.g. 'd', 'g')
    net_name: str       # descriptive name from the YAML (e.g. 'drain', 'gate')
    net: Optional[str] = None   # actual net connection, set at instantiation


@dataclass
class ParameterConstraint:
    minval: str
    maxval: str         # '-1' means unbounded
    value: None         # filled when the device is instantiated
    unit: Optional[str] = None

    def __post_init__(self):
        self.minval = self._normalize(self.minval)
        self.maxval = self._normalize(self.maxval)
        # Infer unit from minval suffix if not explicitly provided
        if self.unit is None and isinstance(self.minval, str):
            for suffix in ['u', 'n', 'p', 'm']:
                if self.minval.endswith(suffix):
                    self.unit = suffix
                    break

    def _normalize(self, value) -> str:
        if isinstance(value, (int, float)):
            return str(value)
        return value

    def validate_value(self, value, param_name: str) -> None:
        """Validate *value* (already in PDK-native units) against constraints.

        Checks:
        - Dimensionless parameters (no unit, e.g. multiplier 'm') must be integers.
        - Value must be >= minval (when minval != -1).
        - Value must be <= maxval (when maxval != -1).

        Prints a WARNING for each violation; does not raise so simulation can
        still proceed.
        """
        try:
            fval = float(value)
        except (ValueError, TypeError):
            print(f"WARNING: Could not validate '{param_name}={value}' — not numeric")
            return

        unit_str = f" {self.unit}" if self.unit else ""

        # Dimensionless parameters (no unit) must be integers
        if self.unit is None:
            if fval != int(fval):
                print(f"WARNING: '{param_name}' must be an integer, got {value}")

        # Minimum bound
        if self.minval not in ('-1', None):
            try:
                if fval < float(self.minval):
                    print(f"WARNING: '{param_name}={fval}{unit_str}' "
                          f"is below minimum {self.minval}{unit_str}")
            except ValueError:
                pass

        # Maximum bound (-1 means unbounded)
        if self.maxval not in ('-1', None):
            try:
                max_f = float(self.maxval)
                if max_f != -1 and fval > max_f:
                    print(f"WARNING: '{param_name}={fval}{unit_str}' "
                          f"exceeds maximum {self.maxval}{unit_str}")
            except ValueError:
                pass


@dataclass
class PDKDevice:
    device_name: str
    pdk_device: str
    param_list: Dict[str, ParameterConstraint]
    pin_list: Dict[str, Pin]

    @classmethod
    def from_dict(cls, name: str, data: dict) -> 'PDKDevice':
        """Create a PDKDevice from the standard PyNetlist YAML schema."""
        param_list = {}
        for param_name, constraints in data['paramList'].items():
            param_list[param_name] = ParameterConstraint(
                minval=str(constraints['minval']),
                maxval=str(constraints['maxval']),
                unit=constraints.get('unit'),
                value=None
            )
        pin_list = {}
        for pin_short, pin_full in data['pinList'].items():
            pin_list[pin_short] = Pin(name=pin_short, net_name=pin_full, net=None)

        return cls(
            device_name=name,
            pdk_device=data['PDKDevice'],
            param_list=param_list,
            pin_list=pin_list
        )


# ---------------------------------------------------------------------------
# Base PDK class
# ---------------------------------------------------------------------------

class BasePDK:
    """Base class for all PyNetlist PDK implementations.

    Provides standard YAML parsing, unit mode handling, parameter validation,
    and SPICE netlist entry generation. Subclasses implement PDK-specific
    behaviour by overriding:

    - ``initializeDeviceList()``  — for non-standard source formats
    - ``getCornerPath(corner)``   — for corner-specific model file paths
    """

    def __init__(self, modelList, libraryLocation, unit_mode=UNIT_PDK, debug=False):
        self.modelList = modelList
        self.libraryLocation = libraryLocation
        self.unit_mode = unit_mode
        self.debug = debug
        self.modelNames = []
        self._devices = {}
        self.count_devices_used = 0
        self.count_devices_instantiated = 0
        self.devices_used_list = []
        self.modelCount = 0

        self.initializeDeviceList()

        if unit_mode == UNIT_PDK:
            print(f"Unit mode: PDK defaults — dimensions in PDK-native units per YAML "
                  f"(e.g. µm for W/L in sky130). Pass unit_mode=UNIT_SI for SI metres.")

    # ------------------------------------------------------------------
    # Device loading
    # ------------------------------------------------------------------

    def initializeDeviceList(self):
        """Load device definitions from the PDK source file.

        Default implementation parses the standard PyNetlist YAML schema.
        Override to support other formats (Liberty, JSON, vendor YAML, etc.)
        — populate ``self._devices`` with ``PDKDevice`` objects and call
        ``setattr(self, device_name, device)`` for each one.
        """
        self._parse_standard_yaml(self.modelList)

    def _parse_standard_yaml(self, yaml_path: str) -> None:
        """Parse the standard PyNetlist YAML device schema.

        Populates ``self._devices``, ``self.modelNames``, and creates a named
        attribute on the PDK instance for each device (e.g. ``pdk.nmos1p8``).
        Also populates ``self._device_classes`` with dynamically-created
        :class:`AnalogElement` subclasses (used by the new instantiation API).
        """
        from silk.elements.factory import make_device_class

        self._device_classes = {}

        with open(yaml_path, 'r') as f:
            try:
                config_data = yaml.safe_load(f)
                if self.debug:
                    print(config_data)
                for device_name, device_data in config_data.items():
                    device = PDKDevice.from_dict(device_name, device_data)
                    self._devices[device_name] = device   # internal: keep PDKDevice
                    cls = make_device_class(device_name, device_data, is_pdk=True)
                    self._device_classes[device_name] = cls
                    setattr(self, device_name, cls)       # public: expose the class
            except yaml.YAMLError as e:
                raise ValidationError(f"Error parsing YAML: {e}")
            except KeyError as e:
                raise ValidationError(f"Missing required field in YAML: {e}")

        model_names = list(self._devices.keys())
        if len(set(model_names)) != len(model_names):
            raise PDKError('Error: device defined multiple times in YAML.')
        self.modelNames = model_names

        if self.debug:
            print(f'PDK loaded: {len(model_names)} devices ({", ".join(model_names)})')

    # ------------------------------------------------------------------
    # Corner support
    # ------------------------------------------------------------------

    def getCornerPath(self, corner: str) -> str:
        """Return the model file path/section for a given process corner.

        Default behaviour: return ``libraryLocation`` unchanged — the corner
        name is used as the ``.lib`` section identifier (e.g. ``tt``, ``ss``).
        Override in subclasses that use a separate model file per corner.
        """
        return self.libraryLocation

    # ------------------------------------------------------------------
    # Netlist generation
    # ------------------------------------------------------------------

    def generateNetlistEntry(self, name, details):
        """Generate a SPICE subcircuit instance line for a device.

        Applies unit conversion when ``unit_mode=UNIT_SI`` and validates
        each parameter value against the PDK constraints before writing.
        """
        str_netlist = 'XM' + name + ' '

        for p in details['device'].pin_list:
            str_netlist += details['device'].pin_list[p].net + ' '

        str_netlist += details['device'].pdk_device + ' '

        str_param = ''
        for p, constraint in details['device'].param_list.items():
            if self.debug:
                print(p)

            raw = constraint.value
            param_val = raw.value if hasattr(raw, 'value') else raw

            # Convert SI metres → PDK units if requested
            if self.unit_mode == UNIT_SI and constraint.unit in _SI_TO_PDK_SCALE:
                try:
                    param_val = float(param_val) * _SI_TO_PDK_SCALE[constraint.unit]
                except (ValueError, TypeError):
                    pass  # symbolic/ModuleVariable — skip conversion

            # Validate in PDK units
            constraint.validate_value(param_val, p)

            str_param += f'{p}={param_val} '

        str_netlist += str_param
        if self.debug:
            print(str_netlist)

        return str_netlist + '\n'
