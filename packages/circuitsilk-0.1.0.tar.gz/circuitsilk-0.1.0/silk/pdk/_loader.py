import os as _os

from silk.pdk.basepdk import UNIT_PDK, UNIT_SI  # noqa: F401


_SKY130_NAMES = frozenset({'sky130', 'skywater130', 'skywater_130'})


def load_pdk(name: str, pdk_root: str = None):
    """Load a named PDK with automatic path resolution.

    Parameters
    ----------
    name : str
        PDK short name.  Accepted values: ``'sky130'``, ``'skywater130'``,
        ``'skywater_130'``.
    pdk_root : str, optional
        Root of the PDK installation.  Falls back to the ``PDK_ROOT``
        environment variable, then ``~/pdk``.

    Returns
    -------
    PDK_skywater130
        A fully initialised PDK instance.

    Examples
    --------
    ::

        from silk import load_pdk
        pdk = load_pdk('sky130')                         # uses $PDK_ROOT or ~/pdk
        pdk = load_pdk('sky130', pdk_root='/opt/sky130') # explicit root
    """
    if name not in _SKY130_NAMES:
        raise ValueError(
            f"Unknown PDK {name!r}.  Supported names: {sorted(_SKY130_NAMES)}"
        )

    if pdk_root is None:
        pdk_root = _os.environ.get('PDK_ROOT', _os.path.expanduser('~/pdk'))

    lib_path = _os.path.join(
        pdk_root,
        'libraries', 'sky130_fd_pr', 'latest', 'models', 'sky130.lib.spice'
    )
    yaml_path = _os.path.join(
        _os.path.dirname(__file__), 'data', 'skywater_130_device_details.yaml'
    )

    from silk.pdk.skywater130 import PDK_skywater130
    return PDK_skywater130(yaml_path, lib_path)
