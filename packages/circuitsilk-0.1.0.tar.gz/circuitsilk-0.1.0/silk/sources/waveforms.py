"""silk waveform shape classes for SPICE source definitions."""

# Source classes for PyNetlist
# Each class represents one SPICE source element and owns its SPICE generation.
#
# Import via:
#   from pynetlist import sources
#   ckt.addSource(sources.VoltageSource('vdd', positive='vdd', negative='gnd', dc=1.8))

from silk.elements.factory import ParamDescriptor


# ---------------------------------------------------------------------------
# Waveform classes (used as arguments to VoltageSource / CurrentSource)
# ---------------------------------------------------------------------------

class Pulse:
    """PULSE(V1 V2 TD TR TF PW PER NP)"""
    def __init__(self, v1, v2, td=0, tr=0, tf=0, pw=0, per=0, np=None):
        self.v1  = v1
        self.v2  = v2
        self.td  = td
        self.tr  = tr
        self.tf  = tf
        self.pw  = pw
        self.per = per
        self.np  = np   # number of pulses; None = unlimited (omitted from SPICE line)

    def to_spice(self):
        parts = [self.v1, self.v2, self.td, self.tr, self.tf, self.pw, self.per]
        if self.np is not None:
            parts.append(self.np)
        return 'PULSE(' + ' '.join(str(p) for p in parts) + ')'


class Sine:
    """SIN(VO VA FREQ TD THETA PHASE)"""
    def __init__(self, voffset, vampl, freq, td=0, theta=0, phase=0):
        self.voffset = voffset
        self.vampl   = vampl
        self.freq    = freq
        self.td      = td
        self.theta   = theta
        self.phase   = phase   # degrees; omitted from SPICE line if 0

    def to_spice(self):
        parts = [self.voffset, self.vampl, self.freq, self.td, self.theta]
        if self.phase != 0:
            parts.append(self.phase)
        return 'SIN(' + ' '.join(str(p) for p in parts) + ')'


class Exponential:
    """EXP(V1 V2 TD1 TAU1 TD2 TAU2)"""
    def __init__(self, v1, v2, td1=0, tau1=0, td2=0, tau2=0):
        self.v1   = v1
        self.v2   = v2
        self.td1  = td1
        self.tau1 = tau1
        self.td2  = td2
        self.tau2 = tau2

    def to_spice(self):
        parts = [self.v1, self.v2, self.td1, self.tau1, self.td2, self.tau2]
        return 'EXP(' + ' '.join(str(p) for p in parts) + ')'


class SFFM:
    """SFFM(VO VA FC MDI FS PHASEC PHASES)  — Single-Frequency FM"""
    def __init__(self, vo, va, fc, mdi, fs, phasec=0, phases=0):
        self.vo     = vo
        self.va     = va
        self.fc     = fc
        self.mdi    = mdi
        self.fs     = fs
        self.phasec = phasec   # carrier phase in degrees; omitted if 0
        self.phases = phases   # signal phase in degrees; omitted if 0

    def to_spice(self):
        parts = [self.vo, self.va, self.fc, self.mdi, self.fs]
        if self.phasec != 0 or self.phases != 0:
            parts += [self.phasec, self.phases]
        return 'SFFM(' + ' '.join(str(p) for p in parts) + ')'

SingleFrequencyFM = SFFM


class AM:
    """AM(VA VO MF FC TD PHASES)  — Amplitude Modulated"""
    def __init__(self, va, vo, mf, fc, td=0, phases=0):
        self.va     = va
        self.vo     = vo
        self.mf     = mf
        self.fc     = fc
        self.td     = td
        self.phases = phases   # degrees; omitted if 0

    def to_spice(self):
        parts = [self.va, self.vo, self.mf, self.fc, self.td]
        if self.phases != 0:
            parts.append(self.phases)
        return 'AM(' + ' '.join(str(p) for p in parts) + ')'

AmplitudeModulated = AM


class TransientNoise:
    """TRNOISE(NA NT NALPHA NAMP RTSAM RTSCAPT RTSEMT)

    White noise only:   TransientNoise(na='20n', nt='0.5n')
    White + 1/f:        TransientNoise(na='20n', nt='0.5n', nalpha=1.1, namp='12p')
    Full (+ RTS):       TransientNoise(na=0, nt='10p', nalpha=1.1, namp='12p',
                                       rtsam='15m', rtscapt='22u', rtsemt='50u')
    """
    def __init__(self, na, nt, nalpha=0, namp=0, rtsam=0, rtscapt=0, rtsemt=0):
        self.na      = na
        self.nt      = nt
        self.nalpha  = nalpha
        self.namp    = namp
        self.rtsam   = rtsam    # RTS amplitude; omit RTS params if all zero
        self.rtscapt = rtscapt  # trap capture time
        self.rtsemt  = rtsemt   # trap emission time

    def to_spice(self):
        parts = [self.na, self.nt, self.nalpha, self.namp]
        if self.rtsam != 0 or self.rtscapt != 0 or self.rtsemt != 0:
            parts += [self.rtsam, self.rtscapt, self.rtsemt]
        return 'TRNOISE(' + ' '.join(str(p) for p in parts) + ')'


class RandomSource:
    """TRRANDOM(TYPE TS TD PARAM1 PARAM2)

    type: 1=Uniform, 2=Gaussian, 3=Exponential, 4=Poisson
    """
    def __init__(self, type, ts, td=0, param1=1, param2=0):
        self.type   = type
        self.ts     = ts
        self.td     = td
        self.param1 = param1
        self.param2 = param2

    def to_spice(self):
        parts = [self.type, self.ts, self.td, self.param1, self.param2]
        return 'TRRANDOM(' + ' '.join(str(p) for p in parts) + ')'


# ---------------------------------------------------------------------------
