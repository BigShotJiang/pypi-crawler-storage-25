"""silk source element classes (VoltageSource, CurrentSource, controlled sources)."""

from silk.elements.factory import ParamDescriptor
from silk.sources.waveforms import Pulse, Sine, Exponential, SFFM, AM, TransientNoise, RandomSource

# Base class
# ---------------------------------------------------------------------------

class SourceBase:
    """Base class for all SPICE sources."""
    def __init__(self, name):
        self.name = name

    def to_spice(self):
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Independent sources
# ---------------------------------------------------------------------------

class VoltageSource(SourceBase):
    """Independent voltage source.

    Example::

        sources.VoltageSource('vdd', positive='vdd', negative='gnd', dc=1.8)
        sources.VoltageSource('vin', positive='in', negative='gnd', dc=0,
                               pulse=sources.Pulse(v1=0, v2=1.8, tr='1n', tf='1n',
                                                   pw='50n', per='100n'))

    Class-level param descriptors enable the attribute-access variable API::

        vdd = sources.VoltageSource.dc.variable(name='vdd', value=1.8, bounds=(1.6, 2.0))
    """
    _param_names = ('dc', 'ac')
    # Non-data descriptors: class access returns ParamAccessor; instance access
    # is shadowed by instance.__dict__ entries set in __init__ (self.dc = dc).
    dc = ParamDescriptor('dc')
    ac = ParamDescriptor('ac')

    def __init__(self, name, positive, negative,
                 dc=0, ac=0,
                 pwl=None, pwl_r=None, pwl_td=None,
                 pulse=None, sine=None, exponential=None,
                 sffm=None, am=None, trnoise=None, trrandom=None):
        super().__init__(name)
        self.positive    = positive
        self.negative    = negative
        self.dc          = dc
        self.ac          = ac
        self.pwl         = pwl       # flat list of time-value pairs, or 'file=path'
        self.pwl_r       = pwl_r     # repeat time point (voltage sources only)
        self.pwl_td      = pwl_td    # global PWL delay (voltage sources only)
        self.pulse       = pulse     # Pulse object or None
        self.sine        = sine      # Sine object or None
        self.exponential = exponential  # Exponential object or None
        self.sffm        = sffm     # SFFM object or None
        self.am          = am       # AM object or None
        self.trnoise     = trnoise  # TransientNoise object or None
        self.trrandom    = trrandom # RandomSource object or None

    def to_spice(self):
        prefix = 'V' + self.name
        pos = self.positive
        neg = self.negative

        # Determine transient waveform (first set wins; mutually exclusive)
        waveform_str = None
        if self.pulse is not None:
            waveform_str = self.pulse.to_spice()
        elif self.sine is not None:
            waveform_str = self.sine.to_spice()
        elif self.exponential is not None:
            waveform_str = self.exponential.to_spice()
        elif self.sffm is not None:
            waveform_str = self.sffm.to_spice()
        elif self.am is not None:
            waveform_str = self.am.to_spice()
        elif self.trnoise is not None:
            waveform_str = self.trnoise.to_spice()
        elif self.trrandom is not None:
            waveform_str = self.trrandom.to_spice()

        if waveform_str is not None:
            # Single SPICE line: Vname pos neg [DC val] [AC val] WAVEFORM(...)
            parts = [prefix, pos, neg]
            if self.dc != 0:
                parts.append(f'DC {self.dc}V')
            if self.ac != 0:
                parts.append(f'AC {self.ac}V')
            parts.append(waveform_str)
            return ' '.join(parts) + '\n'

        if self.pwl is not None:
            # PWL: use series-element trick so dc acts as a DC offset added during transient.
            # pos → [PWL element] → internal_node → [DC element] → neg
            # V(pos, neg) = PWL_value + dc  during transient simulation.
            lines = []
            internal_node = pos + '_pdc_' + prefix
            pwl_line = prefix + '_pwl ' + pos + ' ' + internal_node + ' PWL('
            if isinstance(self.pwl, str) and self.pwl.startswith('file='):
                with open(self.pwl.split('file=')[1], 'r') as f:
                    pwl_line += f.read().rstrip()
            else:
                pwl_line += ' '.join(str(v) for v in self.pwl)
            pwl_line += ')'
            if self.pwl_r is not None:
                pwl_line += f' r={self.pwl_r}'
            if self.pwl_td is not None:
                pwl_line += f' td={self.pwl_td}'
            lines.append(pwl_line)
            dc_line = prefix + '_dc ' + internal_node + ' ' + neg + ' DC ' + str(self.dc) + 'V'
            if self.ac != 0:
                dc_line += ' AC ' + str(self.ac) + 'V'
            lines.append(dc_line)
            return '\n'.join(lines) + '\n'

        # DC / AC only — single line
        parts = [prefix, pos, neg, f'DC {self.dc}V']
        if self.ac != 0:
            parts.append(f'AC {self.ac}V')
        return ' '.join(parts) + '\n'


class CurrentSource(SourceBase):
    """Independent current source.

    Positive current flows from positive node, through the source, into negative node.

    Example::

        sources.CurrentSource('ibias', positive='vb', negative='gnd', dc=100e-6)

    Class-level param descriptors enable the attribute-access variable API::

        ibias = sources.CurrentSource.dc.variable(name='ibias', value=100e-6)
    """
    _param_names = ('dc', 'ac')
    dc = ParamDescriptor('dc')
    ac = ParamDescriptor('ac')

    def __init__(self, name, positive, negative,
                 dc=0, ac=0,
                 pwl=None, pulse=None, sine=None, exponential=None,
                 sffm=None, am=None, trnoise=None, trrandom=None):
        super().__init__(name)
        self.positive    = positive
        self.negative    = negative
        self.dc          = dc
        self.ac          = ac
        self.pwl         = pwl        # note: pwl_r and pwl_td not supported for current sources
        self.pulse       = pulse
        self.sine        = sine
        self.exponential = exponential
        self.sffm        = sffm
        self.am          = am
        self.trnoise     = trnoise
        self.trrandom    = trrandom

    def to_spice(self):
        prefix = 'I' + self.name
        pos = self.positive
        neg = self.negative

        # Transient waveform (first set wins; mutually exclusive)
        waveform_str = None
        if self.pwl is not None:
            if isinstance(self.pwl, str) and self.pwl.startswith('file='):
                with open(self.pwl.split('file=')[1], 'r') as f:
                    waveform_str = 'PWL(' + f.read().rstrip() + ')'
            else:
                waveform_str = 'PWL(' + ' '.join(str(v) for v in self.pwl) + ')'
        elif self.pulse is not None:
            waveform_str = self.pulse.to_spice()
        elif self.sine is not None:
            waveform_str = self.sine.to_spice()
        elif self.exponential is not None:
            waveform_str = self.exponential.to_spice()
        elif self.sffm is not None:
            waveform_str = self.sffm.to_spice()
        elif self.am is not None:
            waveform_str = self.am.to_spice()
        elif self.trnoise is not None:
            waveform_str = self.trnoise.to_spice()
        elif self.trrandom is not None:
            waveform_str = self.trrandom.to_spice()

        # Single SPICE line: Iname pos neg DC val [AC val] [WAVEFORM(...)]
        parts = [prefix, pos, neg, f'DC {self.dc}A']
        if self.ac != 0:
            parts.append(f'AC {self.ac}A')
        if waveform_str is not None:
            parts.append(waveform_str)
        return ' '.join(parts) + '\n'


# ---------------------------------------------------------------------------
# Dependent (controlled) sources
# ---------------------------------------------------------------------------

class VoltageControlledVoltageSource(SourceBase):
    """Linear VCVS — E element.  Vout = gain * V(ctrl_pos, ctrl_neg)

    Example::

        sources.VoltageControlledVoltageSource('eamp',
            out_pos='vout', out_neg='gnd', ctrl_pos='vin', ctrl_neg='gnd', gain=10)
    """
    def __init__(self, name, out_pos, out_neg, ctrl_pos, ctrl_neg, gain):
        super().__init__(name)
        self.out_pos  = out_pos
        self.out_neg  = out_neg
        self.ctrl_pos = ctrl_pos
        self.ctrl_neg = ctrl_neg
        self.gain     = gain

    def to_spice(self):
        return (f'E{self.name} {self.out_pos} {self.out_neg} '
                f'{self.ctrl_pos} {self.ctrl_neg} {self.gain}\n')

VCVS = VoltageControlledVoltageSource


class VoltageControlledCurrentSource(SourceBase):
    """Linear VCCS — G element.  Iout = gm * V(ctrl_pos, ctrl_neg)  [gm in Siemens]

    Example::

        sources.VoltageControlledCurrentSource('gm1',
            out_pos='iout', out_neg='gnd', ctrl_pos='vin', ctrl_neg='gnd', gm=0.01)
    """
    def __init__(self, name, out_pos, out_neg, ctrl_pos, ctrl_neg, gm):
        super().__init__(name)
        self.out_pos  = out_pos
        self.out_neg  = out_neg
        self.ctrl_pos = ctrl_pos
        self.ctrl_neg = ctrl_neg
        self.gm       = gm

    def to_spice(self):
        return (f'G{self.name} {self.out_pos} {self.out_neg} '
                f'{self.ctrl_pos} {self.ctrl_neg} {self.gm}\n')

VCCS = VoltageControlledCurrentSource


class CurrentControlledVoltageSource(SourceBase):
    """Linear CCVS — H element.  Vout = transresistance * I(ctrl_vname)

    ctrl_vname is the name of a zero-valued ammeter voltage source that the
    controlling current flows through.  The caller is responsible for placing
    that source in the circuit.

    Example::

        sources.CurrentControlledVoltageSource('htrans',
            out_pos='vout', out_neg='gnd', transresistance=1000, ctrl_vname='vmeas')
    """
    def __init__(self, name, out_pos, out_neg, transresistance, ctrl_vname):
        super().__init__(name)
        self.out_pos         = out_pos
        self.out_neg         = out_neg
        self.transresistance = transresistance
        self.ctrl_vname      = ctrl_vname

    def to_spice(self):
        return (f'H{self.name} {self.out_pos} {self.out_neg} '
                f'{self.ctrl_vname} {self.transresistance}\n')

CCVS = CurrentControlledVoltageSource


class CurrentControlledCurrentSource(SourceBase):
    """Linear CCCS — F element.  Iout = gain * I(ctrl_vname)

    ctrl_vname is the name of a zero-valued ammeter voltage source that the
    controlling current flows through.

    Example::

        sources.CurrentControlledCurrentSource('fmir',
            out_pos='icopy', out_neg='gnd', gain=2, ctrl_vname='vmeas')
    """
    def __init__(self, name, out_pos, out_neg, gain, ctrl_vname):
        super().__init__(name)
        self.out_pos    = out_pos
        self.out_neg    = out_neg
        self.gain       = gain
        self.ctrl_vname = ctrl_vname

    def to_spice(self):
        return (f'F{self.name} {self.out_pos} {self.out_neg} '
                f'{self.ctrl_vname} {self.gain}\n')

CCCS = CurrentControlledCurrentSource


# ---------------------------------------------------------------------------
# Behavioral sources
# ---------------------------------------------------------------------------

class BehavioralVoltage(SourceBase):
    """Behavioral voltage source — B element with V=expression.

    Expression may reference node voltages v(n), v(n1,n2), branch currents
    i(vname), math functions, and special variables time / temper / hertz.
    Parameters are referenced as {param_name}.

    Example::

        sources.BehavioralVoltage('bdiff', positive='vd', negative='gnd',
                                   expression='v(inp)-v(inn)')
        sources.BehavioralVoltage('bclamp', positive='vc', negative='gnd',
                                   expression='v(in) < {Vlo} ? {Vlo} : v(in) > {Vhi} ? {Vhi} : v(in)')
    """
    def __init__(self, name, positive, negative, expression):
        super().__init__(name)
        self.positive   = positive
        self.negative   = negative
        self.expression = expression

    def to_spice(self):
        return f'B{self.name} {self.positive} {self.negative} V={{{self.expression}}}\n'


class BehavioralCurrent(SourceBase):
    """Behavioral current source — B element with I=expression.

    Example::

        sources.BehavioralCurrent('bgm', positive='io', negative='gnd',
                                   expression='0.01*v(vin,gnd)')
    """
    def __init__(self, name, positive, negative, expression):
        super().__init__(name)
        self.positive   = positive
        self.negative   = negative
        self.expression = expression

    def to_spice(self):
        return f'B{self.name} {self.positive} {self.negative} I={{{self.expression}}}\n'
