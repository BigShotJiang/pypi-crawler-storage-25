"""silk.sources — analog source elements and waveform shapes."""
from silk.sources.waveforms import (
    Pulse, Sine, Exponential, SFFM, AM, AmplitudeModulated,
    TransientNoise, RandomSource,
)
from silk.sources.classes import (
    SourceBase,
    VoltageSource, CurrentSource,
    VoltageControlledVoltageSource, VoltageControlledCurrentSource,
    CurrentControlledVoltageSource, CurrentControlledCurrentSource,
    BehavioralVoltage, BehavioralCurrent,
)

SingleFrequencyFM = SFFM
VCVS = VoltageControlledVoltageSource
VCCS = VoltageControlledCurrentSource
CCVS = CurrentControlledVoltageSource
CCCS = CurrentControlledCurrentSource

__all__ = [
    'Pulse', 'Sine', 'Exponential', 'SFFM', 'AM', 'TransientNoise', 'RandomSource',
    'SourceBase', 'VoltageSource', 'CurrentSource',
    'VoltageControlledVoltageSource', 'VoltageControlledCurrentSource',
    'CurrentControlledVoltageSource', 'CurrentControlledCurrentSource',
    'BehavioralVoltage', 'BehavioralCurrent',
    'VCVS', 'VCCS', 'CCVS', 'CCCS',
]
