"""CircuitCodeGenerator — generates runnable PyNetlist Python code from a
circuit description dict produced by a GUI.

Circuit description format
--------------------------
The GUI passes a dict (or JSON file) with this structure::

    {
      // Required
      "circuit_name": "diff_pair",          // used for file name and comments
      "pdk": "sky130",                       // "sky130" is the only supported PDK today

      // Optional — defaults shown
      "output_dir": "./sim",                 // where to write the netlist file
      "corner": "tt",                        // tt | ss | ff | sf | fs

      // Devices from the PDK (pdk.nmos1p8, pdk.pmos1p8, etc.)
      "devices": [
        {
          "type":     "nmos1p8",             // key in PDK schema
          "instance": "mn1",                 // Python variable + SPICE instance name
          "nets":     {"d": "vout", "g": "vin", "s": "gnd", "b": "gnd"},
          "params":   {"w": 2.0, "l": 0.15, "m": 1}
        }
      ],

      // Ideal elements (elements.resistor, elements.vsource, etc.)
      "ideal_elements": [
        {
          "type":     "vsource",
          "instance": "vdd",
          "nets":     {"p": "vdd", "n": "gnd"},
          "params":   {"dc": 1.8}
        }
      ],

      // Simulation — pick one type
      "simulation": {
        "type":  "Transient",               // Transient | AC | DC | Noise
        "step":  1e-9,                      // Transient: time step
        "stop":  100e-9                     // Transient: stop time

        // AC:   "variation": "dec", "points": 10, "fstart": 1, "fstop": 1e9
        // DC:   "source": "vdd", "start": 0, "stop": 1.8, "step": 0.01
        // Noise: "output": "vout", "ref": "0", "source": "vin",
        //        "variation": "dec", "points": 10, "fstart": 1, "fstop": 1e9
      }
    }

Generated code structure
------------------------
::

    # --- imports ---
    import os
    from silk.circuit.netlist import PyNetlist
    from silk.pdk.skywater130 import PDK_skywater130
    from silk.simulation import analysis
    from silk.elements import elements   # if ideal elements are used

    # --- PDK setup ---
    _pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))
    pdk = PDK_skywater130(...)

    # --- circuit ---
    ckt = PyNetlist(...)

    # --- devices ---
    mn1 = pdk.nmos1p8('mn1', d='vout', g='vin', s='gnd', b='gnd', w=2.0, l=0.15, m=1)
    ...
    ckt.add(mn1, ...)

    # --- ideal elements ---
    vdd = elements.vsource('vdd', p='vdd', n='gnd', dc=1.8)
    ckt.add(vdd)

    # --- simulation ---
    ckt.addSimType(analysis.Transient(step=1e-9, stop=100e-9))
    ckt.simulate(corner='tt')
"""

from __future__ import annotations

import json
import textwrap
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Data classes — typed representation of the circuit description
# ---------------------------------------------------------------------------

@dataclass
class DeviceSpec:
    """One placed device instance."""
    type: str                          # e.g. 'nmos1p8'
    instance: str                      # e.g. 'mn1'
    nets: dict[str, str]               # {pin_name: net_name}
    params: dict[str, Any]             # {param_name: value}


@dataclass
class SourceSpec:
    """One independent source instance (VoltageSource or CurrentSource).

    ``waveform`` is an optional dict with a ``type`` key (the waveform class
    name, e.g. ``'Pulse'``) and the remaining keys matching the waveform
    constructor's keyword arguments.  ``pwl`` is a flat list of time-value
    pairs and is handled separately from ``waveform``.

    Example (DC bias)::

        {"type": "VoltageSource", "instance": "vbias",
         "positive": "vb", "negative": "gnd", "dc": 1.2}

    Example (pulse excitation)::

        {"type": "VoltageSource", "instance": "vin",
         "positive": "vin", "negative": "gnd", "dc": 0,
         "waveform": {"type": "Pulse",
                      "v1": 0, "v2": 1.8, "td": 0,
                      "tr": 1e-9, "tf": 1e-9, "pw": 10e-9, "per": 20e-9}}

    Example (PWL)::

        {"type": "VoltageSource", "instance": "vpwl",
         "positive": "vin", "negative": "gnd",
         "pwl": [0, 0, 1e-9, 1.8, 2e-9, 0]}
    """
    type: str                          # 'VoltageSource' | 'CurrentSource'
    instance: str
    positive: str
    negative: str
    dc: float = 0
    ac: float = 0
    waveform: dict = field(default_factory=dict)   # {type: 'Pulse', v1: 0, ...}
    pwl: list = field(default_factory=list)        # flat [t0,v0, t1,v1, ...]


@dataclass
class CircuitSpec:
    """Full circuit description — the GUI's output, the generator's input."""
    circuit_name: str
    pdk: str = 'sky130'
    output_dir: str = './sim'
    corner: str = 'tt'
    ports: dict[str, str] = field(default_factory=dict)  # {net: 'input'|'output'|'inout'|None}
    devices: list[DeviceSpec] = field(default_factory=list)
    ideal_elements: list[DeviceSpec] = field(default_factory=list)
    sources: list[SourceSpec] = field(default_factory=list)
    simulation: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict) -> 'CircuitSpec':
        """Build a CircuitSpec from the GUI's dict/JSON payload."""
        devices = [
            DeviceSpec(
                type=dev['type'],
                instance=dev['instance'],
                nets=dev.get('nets', {}),
                params=dev.get('params', {}),
            )
            for dev in d.get('devices', [])
        ]
        ideal = [
            DeviceSpec(
                type=elem['type'],
                instance=elem['instance'],
                nets=elem.get('nets', {}),
                params=elem.get('params', {}),
            )
            for elem in d.get('ideal_elements', [])
        ]
        srcs = [
            SourceSpec(
                type=src['type'],
                instance=src['instance'],
                positive=src['positive'],
                negative=src['negative'],
                dc=src.get('dc', 0),
                ac=src.get('ac', 0),
                waveform=src.get('waveform', {}),
                pwl=src.get('pwl', []),
            )
            for src in d.get('sources', [])
        ]
        return cls(
            circuit_name=d.get('circuit_name', 'my_circuit'),
            pdk=d.get('pdk', 'sky130'),
            output_dir=d.get('output_dir', './sim'),
            corner=d.get('corner', 'tt'),
            ports=d.get('ports', {}),
            devices=devices,
            ideal_elements=ideal,
            sources=srcs,
            simulation=d.get('simulation', {}),
        )

    @classmethod
    def from_json(cls, json_str: str) -> 'CircuitSpec':
        return cls.from_dict(json.loads(json_str))

    @classmethod
    def from_json_file(cls, path: str) -> 'CircuitSpec':
        with open(path) as f:
            return cls.from_dict(json.load(f))


# ---------------------------------------------------------------------------
# Code generator
# ---------------------------------------------------------------------------

_PDK_CONSTRUCTORS = {
    'sky130': (
        "PDK_skywater130("
        "'silk/pdk/data/skywater_130_device_details.yaml',\n"
        "                      libraryLocation=_lib_path)"
    ),
}

_PDK_IMPORTS = {
    'sky130': "from silk.pdk.skywater130 import PDK_skywater130",
}

_PDK_LIB_PATHS = {
    'sky130': (
        "f\"{_pdk_root}/skywater-pdk/libraries/"
        "sky130_fd_pr/latest/models/sky130.lib.spice\""
    ),
}


def _fmt_value(v: Any) -> str:
    """Format a parameter value for Python source code."""
    if isinstance(v, float):
        # Use scientific notation for very small/large values
        if v != 0 and (abs(v) < 1e-3 or abs(v) >= 1e6):
            return f'{v:g}'
        return repr(v)
    return repr(v)


def _sim_code(sim: dict) -> str:
    """Generate the addSimType line from a simulation dict."""
    sim_type = sim.get('type', 'Transient')

    if sim_type == 'Transient':
        step = _fmt_value(sim.get('step', 1e-9))
        stop = _fmt_value(sim.get('stop', 100e-9))
        return f"ckt.addSimType(analysis.Transient(step={step}, stop={stop}))"

    if sim_type == 'AC':
        variation = repr(sim.get('variation', 'dec'))
        points    = sim.get('points', 10)
        fstart    = _fmt_value(sim.get('fstart', 1))
        fstop     = _fmt_value(sim.get('fstop', 1e9))
        return f"ckt.addSimType(analysis.AC({variation}, {points}, {fstart}, {fstop}))"

    if sim_type == 'DC':
        src   = repr(sim.get('source', 'vdd'))
        start = _fmt_value(sim.get('start', 0))
        stop  = _fmt_value(sim.get('stop', 1.8))
        step  = _fmt_value(sim.get('step', 0.01))
        return (f"ckt.addSimType(analysis.DC("
                f"source={src}, start={start}, stop={stop}, step={step}))")

    if sim_type == 'Noise':
        out       = repr(sim.get('output', 'vout'))
        ref       = repr(sim.get('ref', '0'))
        source    = repr(sim.get('source', 'vin'))
        variation = repr(sim.get('variation', 'dec'))
        points    = sim.get('points', 10)
        fstart    = _fmt_value(sim.get('fstart', 1))
        fstop     = _fmt_value(sim.get('fstop', 1e9))
        return (f"ckt.addSimType(analysis.Noise("
                f"{out}, {ref}, {source}, {variation}, {points}, {fstart}, {fstop}))")

    return f"# Unknown simulation type: {sim_type}"


def _device_line(dev: DeviceSpec, source: str) -> str:
    """Generate the instantiation line for one device."""
    net_args   = ', '.join(f"{k}='{v}'" for k, v in dev.nets.items())
    param_args = ', '.join(f"{k}={_fmt_value(v)}" for k, v in dev.params.items())
    all_args   = ', '.join(filter(None, [net_args, param_args]))
    return f"{dev.instance} = {source}.{dev.type}('{dev.instance}', {all_args})"


# Maps waveform class name → kwarg name on VoltageSource / CurrentSource
_WAVEFORM_KWARG = {
    'Pulse':          'pulse',
    'Sine':           'sine',
    'Exponential':    'exponential',
    'SFFM':           'sffm',
    'AM':             'am',
    'TransientNoise': 'trnoise',
    'RandomSource':   'trrandom',
}


def _source_line(src: 'SourceSpec') -> str:
    """Generate the instantiation line for a VoltageSource or CurrentSource."""
    args = [f"positive='{src.positive}'", f"negative='{src.negative}'"]
    if src.dc != 0:
        args.append(f'dc={_fmt_value(src.dc)}')
    if src.ac != 0:
        args.append(f'ac={_fmt_value(src.ac)}')
    if src.pwl:
        pairs = ', '.join(_fmt_value(v) for v in src.pwl)
        args.append(f'pwl=[{pairs}]')
    if src.waveform:
        wf_type = src.waveform.get('type', '')
        wf_params = {k: v for k, v in src.waveform.items() if k != 'type'}
        wf_args = ', '.join(f'{k}={_fmt_value(v)}' for k, v in wf_params.items())
        kwarg = _WAVEFORM_KWARG.get(wf_type, wf_type.lower())
        args.append(f'{kwarg}=sources.{wf_type}({wf_args})')
    return f"{src.instance} = sources.{src.type}('{src.instance}', {', '.join(args)})"


class Generator:
    """Generates a complete runnable PyNetlist Python script from a
    :class:`CircuitSpec` (or plain dict).

    Parameters
    ----------
    indent : int
        Indentation width for generated code (default 4).

    Examples
    --------
    ::

        gen = CircuitCodeGenerator()
        code = gen.generate(spec_dict)
        print(code)

        # Or save directly:
        gen.generate_to_file(spec_dict, 'my_circuit.py')
    """

    def __init__(self, indent: int = 4):
        self.indent = indent

    def generate(self, spec: 'dict | CircuitSpec') -> str:
        """Generate Python source code from a circuit spec.

        When spec.ports is non-empty, emits a Module (subcircuit) definition.
        When spec.ports is empty, emits a standalone PyNetlist simulation script.
        """
        if isinstance(spec, dict):
            spec = CircuitSpec.from_dict(spec)
        if spec.ports:
            return self._generate_module(spec)
        return self._generate_netlist(spec)

    def _generate_netlist(self, spec: 'CircuitSpec') -> str:
        """Generate a standalone PyNetlist simulation script."""

        lines = []

        # ------------------------------------------------------------------
        # Imports
        # ------------------------------------------------------------------
        lines.append(f'"""Generated by PyNetlist CircuitCodeGenerator')
        lines.append(f'Circuit: {spec.circuit_name}')
        lines.append(f'PDK:     {spec.pdk}')
        lines.append(f'Corner:  {spec.corner}')
        lines.append('"""')
        lines.append('')
        lines.append('import os')
        lines.append('from silk.circuit.netlist import PyNetlist')

        pdk_import = _PDK_IMPORTS.get(spec.pdk)
        if pdk_import:
            lines.append(pdk_import)

        lines.append('from silk.simulation import analysis')

        if spec.ideal_elements:
            lines.append('from silk.elements import elements')
        if spec.sources:
            lines.append('from silk import sources')

        lines.append('')

        # ------------------------------------------------------------------
        # PDK setup
        # ------------------------------------------------------------------
        lines.append('# --- PDK setup ---')
        lines.append("_pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))")
        lib_path = _PDK_LIB_PATHS.get(spec.pdk, '"path/to/pdk.lib.spice"')
        lines.append(f'_lib_path = {lib_path}')
        pdk_ctor = _PDK_CONSTRUCTORS.get(spec.pdk, 'BasePDK(...)')
        lines.append(f'pdk = {pdk_ctor}')
        lines.append('')

        # ------------------------------------------------------------------
        # Circuit object
        # ------------------------------------------------------------------
        fname = spec.circuit_name.replace(' ', '_') + '.cir'
        lines.append('# --- circuit ---')
        lines.append(
            f"ckt = PyNetlist('PDK_{spec.pdk}', '{spec.output_dir}', '{fname}', "
            f"pdkDetails=pdk)"
        )
        lines.append('')

        # ------------------------------------------------------------------
        # PDK devices
        # ------------------------------------------------------------------
        if spec.devices:
            lines.append('# --- PDK devices ---')
            instance_names = []
            for dev in spec.devices:
                lines.append(_device_line(dev, 'pdk'))
                instance_names.append(dev.instance)
            lines.append(f"ckt.add({', '.join(instance_names)})")
            lines.append('')

        # ------------------------------------------------------------------
        # Ideal elements
        # ------------------------------------------------------------------
        if spec.ideal_elements:
            lines.append('# --- ideal elements ---')
            instance_names = []
            for elem in spec.ideal_elements:
                lines.append(_device_line(elem, 'elements'))
                instance_names.append(elem.instance)
            lines.append(f"ckt.add({', '.join(instance_names)})")
            lines.append('')

        # ------------------------------------------------------------------
        # Sources
        # ------------------------------------------------------------------
        if spec.sources:
            lines.append('# --- sources ---')
            for src in spec.sources:
                lines.append(_source_line(src))
                lines.append(f'ckt.addSource({src.instance})')
            lines.append('')

        # ------------------------------------------------------------------
        # Simulation
        # ------------------------------------------------------------------
        lines.append('# --- simulation ---')
        if spec.simulation:
            lines.append(_sim_code(spec.simulation))
        lines.append(f"ckt.simulate(corner='{spec.corner}')")
        lines.append('')

        # ------------------------------------------------------------------
        # Results loading stub
        # ------------------------------------------------------------------
        lines.append('# --- load results ---')
        lines.append('# ckt.getSignalNames()            # list available signals')
        lines.append("# sig = ckt.loadSignal('v(out)')  # load a waveform")
        lines.append("# sig.plot()                      # plot it")
        lines.append('')

        return '\n'.join(lines)

    def _generate_module(self, spec: 'CircuitSpec') -> str:
        """Generate a Module (subcircuit) definition when spec.ports is non-empty."""
        import os as _os
        lines = []
        lines.append(f'"""Generated subcircuit: {spec.circuit_name}"""')
        lines.append('')
        lines.append('import os')
        lines.append('from silk import Module')
        pdk_import = _PDK_IMPORTS.get(spec.pdk)
        if pdk_import:
            lines.append(pdk_import)
        if spec.ideal_elements:
            lines.append('from silk.elements import elements')
        if spec.sources:
            lines.append('from silk import sources')
        lines.append('')
        lines.append('# --- PDK setup ---')
        lines.append("_pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))")
        lib_path = _PDK_LIB_PATHS.get(spec.pdk, '"path/to/pdk.lib.spice"')
        lines.append(f'_lib_path = {lib_path}')
        pdk_ctor = _PDK_CONSTRUCTORS.get(spec.pdk, 'BasePDK(...)')
        lines.append(f'pdk = {pdk_ctor}')
        lines.append('')
        fname = spec.circuit_name.replace(' ', '_') + '.cir'
        lines.append('# --- module definition ---')
        lines.append(
            f"mod = Module('PDK_{spec.pdk}', './subckt', '{fname}', pdkDetails=pdk)"
        )
        lines.append(f"mod.defineModuleName('{spec.circuit_name}')")
        ports_dict = repr(spec.ports)
        lines.append(f"mod.defineModuleNets({ports_dict})")
        lines.append('')
        if spec.devices:
            lines.append('# --- PDK devices ---')
            names = []
            for dev in spec.devices:
                lines.append(_device_line(dev, 'pdk'))
                names.append(dev.instance)
            lines.append(f"mod.add({', '.join(names)})")
            lines.append('')
        if spec.ideal_elements:
            lines.append('# --- ideal elements ---')
            names = []
            for elem in spec.ideal_elements:
                lines.append(_device_line(elem, 'elements'))
                names.append(elem.instance)
            lines.append(f"mod.add({', '.join(names)})")
            lines.append('')
        if spec.sources:
            lines.append('# --- sources ---')
            for src in spec.sources:
                lines.append(_source_line(src))
                lines.append(f'mod.addSource({src.instance})')
            lines.append('')
        return '\n'.join(lines)

    def generate_to_file(self, spec: dict | CircuitSpec, path: str) -> None:
        """Write generated code to a file.

        Parameters
        ----------
        spec : dict or CircuitSpec
            Circuit description.
        path : str
            Output file path (e.g. ``'my_circuit.py'``).
        """
        code = self.generate(spec)
        with open(path, 'w') as f:
            f.write(code)


# ---------------------------------------------------------------------------
# CLI:  python -m silk.codegen.generator  circuit_spec.json
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description='Generate PyNetlist Python code from a circuit spec JSON file.')
    parser.add_argument('spec', help='Path to circuit spec JSON file')
    parser.add_argument('-o', '--output', default='-',
                        help='Output .py file (default: stdout)')
    args = parser.parse_args()

    spec = CircuitSpec.from_json_file(args.spec)
    gen  = CircuitCodeGenerator()
    code = gen.generate(spec)

    if args.output == '-':
        print(code)
    else:
        gen.generate_to_file(spec, args.output)
        print(f'Code written to {args.output}', file=sys.stderr)

# Backward-compat alias
CircuitCodeGenerator = Generator
