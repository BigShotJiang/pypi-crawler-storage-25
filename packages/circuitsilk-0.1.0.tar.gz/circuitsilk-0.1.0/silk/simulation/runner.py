"""silk.simulation.runner — NgspiceRunner: subprocess wrapper for ngspice.

Owns the ngspice invocation and raw-file loading. PyNetlist delegates to
this class so the simulation backend is independently testable and replaceable.
"""
import subprocess
import ngspice_read.ngspice_read as ngr
from silk.exceptions import SimulationError


class NgspiceRunner:
    """Runs an ngspice simulation from a netlist file and loads the results.

    Parameters
    ----------
    netlist_path : str
        Absolute path to the SPICE netlist file.
    results_dir : str
        Directory where rawfile.raw and output.log are written.
    debug : bool
        Print progress messages when True.
    """

    def __init__(self, netlist_path: str, results_dir: str, debug: bool = False):
        self.netlist_path = netlist_path
        self.rawfile_path = results_dir + '/rawfile.raw'
        self.logfile_path = results_dir + '/output.log'
        self.debug = debug
        self._results = None

    def run(self) -> None:
        """Run ngspice in batch mode. Raises SimulationError on failure."""
        if self.debug:
            print(f'Starting simulation with file {self.netlist_path}')
            print(f'Saving results in {self.rawfile_path}')
        result = subprocess.run(
            ['ngspice', '-b', '-r', self.rawfile_path,
             '-o', self.logfile_path, self.netlist_path]
        )
        if result.returncode != 0:
            error_lines = []
            try:
                with open(self.logfile_path) as f:
                    for line in f:
                        if any(kw in line for kw in ('Error', 'error', 'ERROR', 'fatal')):
                            error_lines.append(line.rstrip())
            except OSError:
                pass
            detail = '\n  '.join(error_lines) if error_lines else '(no error lines found)'
            raise SimulationError(
                f"ngspice simulation failed (exit code {result.returncode})."
                f" See {self.logfile_path} for full output.\n  {detail}"
            )

    def load(self):
        """Parse the raw file. Returns the ngspice_read result object."""
        results = ngr.ngspice_read(self.rawfile_path)
        results.readfile(self.rawfile_path)
        self._results = results
        return results

    @property
    def results(self):
        """The loaded simulation results, or None if load() has not been called."""
        return self._results
