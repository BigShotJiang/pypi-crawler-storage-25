# Simulation setup types (Transient, AC, DC, Noise, …).
# Signal classes live in silk.signals.

from silk.utils._utils import _fmt


class AnalysisBase:
    """Base class for typed analysis commands"""
    def to_spice(self) -> str:
        raise NotImplementedError


class Transient(AnalysisBase):
    """Transient analysis command"""
    def __init__(self, step, stop, start=0):
        self.step = step
        self.stop = stop
        self.start = start

    def to_spice(self):
        parts = ['.tran', _fmt(self.step), _fmt(self.stop)]
        if self.start != 0:
            parts.append(_fmt(self.start))
        return ' '.join(parts) + '\n'


class AC(AnalysisBase):
    """AC frequency sweep analysis command"""
    VARIATIONS = ('dec', 'oct', 'lin')

    def __init__(self, variation, points, fstart, fstop):
        if variation not in self.VARIATIONS:
            raise ValueError(f'variation must be one of {self.VARIATIONS}')
        self.variation = variation
        self.points = points
        self.fstart = fstart
        self.fstop = fstop

    def to_spice(self):
        return f'.ac {self.variation} {self.points} {_fmt(self.fstart)} {_fmt(self.fstop)}\n'


class DC(AnalysisBase):
    """DC sweep analysis command"""
    def __init__(self, source, start, stop, step):
        self.source = source
        self.start = start
        self.stop = stop
        self.step = step

    def to_spice(self):
        return f'.dc {self.source} {_fmt(self.start)} {_fmt(self.stop)} {_fmt(self.step)}\n'


class Noise(AnalysisBase):
    """Noise analysis command"""
    VARIATIONS = ('dec', 'oct', 'lin')

    def __init__(self, output, ref, source, variation, points, fstart, fstop):
        if variation not in self.VARIATIONS:
            raise ValueError(f'variation must be one of {self.VARIATIONS}')
        self.output = output
        self.ref = ref
        self.source = source
        self.variation = variation
        self.points = points
        self.fstart = fstart
        self.fstop = fstop

    def to_spice(self):
        return (f'.noise v({self.output},{self.ref}) {self.source} '
                f'{self.variation} {self.points} {_fmt(self.fstart)} {_fmt(self.fstop)}\n')


