"""AnalogElement — base class for all dynamically-generated device instances."""


class AnalogElement:
    """Base class for all analog device instances.

    Subclasses are created at runtime by :func:`make_device_class` from YAML
    device specs.  Each subclass has named constructor arguments matching its
    pin and parameter names from the YAML.

    Class-level attributes (set by the factory)
    -------------------------------------------
    _pin_names : tuple
        Ordered pin names, e.g. ``('d', 'g', 's', 'b')``.
    _param_names : tuple
        Ordered parameter names, e.g. ``('m', 'w', 'l')``.
    _param_defaults : dict
        Default value per parameter (may be None for required params).
    _param_constraints : dict
        ``DeviceParamConstraint`` per parameter for validation.
    _spice_prefix : str
        SPICE element prefix: ``'XM'``, ``'R'``, ``'C'``, ``'V'``, etc.
    _pdk_device : str
        PDK model name (e.g. ``'sky130_fd_pr__nfet_01v8'``), or ``''`` for
        ideal elements.
    _device_type_name : str
        YAML key for this device, e.g. ``'nmos1p8'`` or ``'resistor'``.
    _is_pdk_device : bool
        ``True`` for PDK devices, ``False`` for ideal elements.

    Instance attributes
    -------------------
    name : str
        Instance name (e.g. ``'mn1'``).
    nets : dict
        Maps pin name → connected net string.
    params : dict
        Maps param name → value (numeric, string, or ``ModuleVariable``).
    layout : dict
        Optional layout hint annotations.
    """

    # Class-level defaults — overridden by factory-created subclasses
    _pin_names: tuple = ()
    _param_names: tuple = ()
    _param_defaults: dict = {}
    _param_constraints: dict = {}
    _spice_prefix: str = 'X'
    _pdk_device: str = ''
    _device_type_name: str = ''
    _is_pdk_device: bool = True
    # Backward-compat attribute used by circuit_elements.py
    device_name: str = ''

    def __init__(self, name: str, **kwargs):
        # Use object.__setattr__ to bypass our custom __setattr__ during init
        object.__setattr__(self, 'name', name)
        object.__setattr__(self, 'nets', {})
        object.__setattr__(self, 'params', {})
        object.__setattr__(self, 'layout', {})

    def __setattr__(self, name, value):
        """Allow direct pin/param assignment: ``mn1.w = 2.0``, ``mn1.d = 'vout'``."""
        if name in ('name', 'nets', 'params', 'layout'):
            object.__setattr__(self, name, value)
        elif name in self.__class__._param_names:
            self.params[name] = value
        elif name in self.__class__._pin_names:
            self.nets[name] = value
        else:
            object.__setattr__(self, name, value)

    def validate(self):
        """Validate parameter values against PDK constraints (no-op on base)."""
        pass

    def to_spice(self) -> str:
        """Return the SPICE netlist line for this element."""
        raise NotImplementedError(
            f'{self.__class__.__name__}.to_spice() not implemented. '
            'Use a factory-created subclass.'
        )

    @classmethod
    def variable(cls, param, *, name, value=None, **kwargs):
        """Create a ModuleVariable pre-populated from PDK constraints for *param*.

        Parameters
        ----------
        param : str
            Parameter name (must be in ``cls._param_names``).
        name : str
            Variable name — required to avoid silent clashes in ParameterSpace.
        value : float, optional
            Initial / nominal value.
        **kwargs
            Passed through to ``ModuleVariable``.  ``bounds`` and
            ``resolution`` override the auto-derived PDK values when supplied.

        Returns
        -------
        ModuleVariable
        """
        if param not in cls._param_names:
            valid = ', '.join(cls._param_names) if cls._param_names else '(none)'
            raise ValueError(
                f'{cls.__name__}.variable(): unknown param {param!r}. '
                f'Valid params: {valid}'
            )

        if name is None:
            name = param

        constraint = cls._param_constraints.get(param)

        # Auto-derive bounds from PDK constraint (lower from minval; upper always None)
        if 'bounds' not in kwargs:
            bounds = None
            if constraint is not None and constraint.minval is not None:
                try:
                    lo = float(constraint.minval)
                    bounds = (lo, None)
                except (ValueError, TypeError):
                    pass
            kwargs['bounds'] = bounds

        # Auto-derive resolution from PDK constraint
        if 'resolution' not in kwargs:
            res = None
            if constraint is not None and constraint.resolution is not None:
                try:
                    res = float(constraint.resolution)
                except (ValueError, TypeError):
                    pass
            if res is not None:
                kwargs['resolution'] = res

        from silk.circuit.modules import ModuleVariable
        return ModuleVariable(name, value=value, **kwargs)

    def scale(self, factor: float):
        """Scale device width by *factor* (stub — override in subclass)."""
        pass

    def __repr__(self):
        return f'{self.__class__.__name__}({self.name!r})'
