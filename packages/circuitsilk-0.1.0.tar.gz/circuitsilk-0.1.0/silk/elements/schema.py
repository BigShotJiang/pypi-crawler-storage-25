"""Device schema export — machine-readable device specs for GUI code generators.

Usage
-----
From a PDK::

    from silk.pdk import PDK_skywater130
    from silk import export_schema
    import json

    pdk = PDK_skywater130(...)
    schema = export_schema(pdk)
    print(json.dumps(schema, indent=2))

From the ideal element library::

    from silk.elements import elements
    from silk import export_schema
    import json

    schema = export_schema(elements)
    print(json.dumps(schema, indent=2))

From the command line (writes to stdout)::

    python -m silk.elements.schema --pdk silk/pdk/data/skywater_130_device_details.yaml
    python -m silk.elements.schema --elements

Schema format
-------------
The top-level dict maps device names to device spec dicts::

    {
      "nmos1p8": {
        "name": "nmos1p8",
        "is_pdk_device": true,
        "pdk_model": "sky130_fd_pr__nfet_01v8",
        "spice_prefix": "XM",
        "category": "transistor",
        "pins": [
          {"name": "d", "description": "drain"},
          ...
        ],
        "parameters": [
          {"name": "w", "default": "0.42", "unit": "u", "min": "0.42", "max": "-1"},
          ...
        ]
      },
      ...
    }

The ``category`` field is set to ``"transistor"`` / ``"resistor"`` / etc.
based on the YAML ``category`` field (ideal elements) or inferred from the
device name prefix for PDK devices.

GUI code-generation hint
-------------------------
Given a device spec, a code generator can produce::

    mn1 = pdk.nmos1p8('mn1', d='vout', g='vin', s='gnd', b='gnd',
                       w=2.0, l=0.15, m=1)
    ckt.add(mn1)
"""

import json
from typing import Union

from silk.elements.base import AnalogElement


# ---------------------------------------------------------------------------
# Per-class schema
# ---------------------------------------------------------------------------

def device_schema(cls) -> dict:
    """Return a JSON-serialisable schema dict for a single device class.

    Parameters
    ----------
    cls : type
        An :class:`AnalogElement` subclass (e.g. ``pdk.nmos1p8``).

    Returns
    -------
    dict
        Keys: ``name``, ``is_pdk_device``, ``pdk_model``, ``spice_prefix``,
        ``category``, ``pins``, ``parameters``.
    """
    if not (isinstance(cls, type) and issubclass(cls, AnalogElement)):
        raise TypeError(f"Expected an AnalogElement subclass, got {cls!r}")

    pins = []
    for pin_name in cls._pin_names:
        desc = cls._pin_descriptions.get(pin_name, pin_name) \
               if hasattr(cls, '_pin_descriptions') else pin_name
        pins.append({"name": pin_name, "description": desc})

    parameters = []
    for param_name in cls._param_names:
        constraint = cls._param_constraints.get(param_name)
        entry = {"name": param_name}
        if constraint:
            entry["default"] = constraint.default
            entry["unit"]    = constraint.unit
            entry["min"]     = constraint.minval
            entry["max"]     = constraint.maxval
        else:
            entry["default"] = None
            entry["unit"]    = None
            entry["min"]     = None
            entry["max"]     = None
        parameters.append(entry)

    category = getattr(cls, '_category', None) or _infer_category(cls)

    # Code generation template — shows the GUI the exact Python line to emit.
    # Placeholders use {{name}} syntax (double-braces = literal { } in f-string).
    def _pin_placeholder(p):
        n = p["name"]
        return f'{n}={{net_{n}}}'

    def _param_placeholder(p):
        n = p["name"]
        return f'{n}={{param_{n}}}'

    pin_args   = ', '.join(_pin_placeholder(p) for p in pins)
    param_args = ', '.join(_param_placeholder(p) for p in parameters)
    all_args   = ', '.join(filter(None, [pin_args, param_args]))
    source     = 'pdk' if cls._is_pdk_device else 'elements'
    code_template = (
        "{instance_name} = " + source + "." + cls._device_type_name +
        "('{instance_name}', " + all_args + ")"
    )

    return {
        "name":           cls._device_type_name,
        "is_pdk_device":  cls._is_pdk_device,
        "pdk_model":      cls._pdk_device or None,
        "spice_prefix":   cls._spice_prefix,
        "category":       category,
        "pins":           pins,
        "parameters":     parameters,
        "code_template":  code_template,
    }


def _infer_category(cls) -> str:
    """Guess a category string from the device name when not set in YAML."""
    name = cls._device_type_name.lower()
    if 'nmos' in name or 'pmos' in name or 'fet' in name or 'bjt' in name:
        return 'transistor'
    if 'res' in name or name.startswith('r'):
        return 'passive'
    if 'cap' in name or name.startswith('c'):
        return 'passive'
    if 'ind' in name or name.startswith('l'):
        return 'passive'
    if 'vsource' in name or 'isource' in name:
        return 'source'
    if 'diode' in name:
        return 'diode'
    return 'other'


# ---------------------------------------------------------------------------
# Module schema
# ---------------------------------------------------------------------------

def module_schema(module) -> dict:
    """Return a JSON-serialisable schema dict for a Module (subcircuit).

    Parameters
    ----------
    module : Module
        A Module instance with defineModuleName() and defineModuleNets() called.

    Returns
    -------
    dict
        Keys: ``name``, ``type``, ``is_pdk_device``, ``pdk_model``,
        ``spice_prefix``, ``category``, ``pins``, ``devices``,
        ``code_template``.

    Examples
    --------
    ::

        ldo = Module(...)
        ldo.defineModuleName('ldo')
        ldo.defineModuleNets({'vin': 'input', 'vout': 'output', 'gnd': None})
        schema = module_schema(ldo)
        print(json.dumps(schema, indent=2))
    """
    name = module.module_name or 'unnamed_module'

    pins = []
    if module.pin_list:
        for pin_name, pin in module.pin_list.items():
            direction = getattr(pin, 'direction', None)
            pins.append({"name": pin_name, "direction": direction})

    devices = list(module.elem_dict.keys())

    pin_dict_repr = repr({p["name"]: p["direction"] for p in pins})
    code_template = (
        f"mod = Module(...)\n"
        f"mod.defineModuleName('{name}')\n"
        f"mod.defineModuleNets({pin_dict_repr})"
    )

    return {
        "name":          name,
        "type":          "module",
        "is_pdk_device": False,
        "pdk_model":     None,
        "spice_prefix":  "X",
        "category":      "module",
        "pins":          pins,
        "devices":       devices,
        "code_template": code_template,
    }


# ---------------------------------------------------------------------------
# Library-level schema export
# ---------------------------------------------------------------------------

def export_schema(source, include_metadata: bool = True) -> dict:
    """Export a JSON-serialisable schema for all devices in a PDK or library.

    Parameters
    ----------
    source : BasePDK | ElementLibrary
        A loaded PDK object (``PDK_skywater130``) or ``ElementLibrary``.
        Any object that exposes AnalogElement subclasses as attributes works.
    include_metadata : bool
        If ``True`` (default), include a ``_meta`` key with source info.

    Returns
    -------
    dict
        Maps device names to their schema dicts. Top-level ``_meta`` key
        contains source information when ``include_metadata=True``.

    Examples
    --------
    >>> schema = export_schema(pdk)
    >>> print(json.dumps(schema['nmos1p8'], indent=2))
    """
    # Check if source is a Module instance
    try:
        from silk.circuit.modules import Module as _Module
        if isinstance(source, _Module):
            name = source.module_name or 'unnamed_module'
            result = {name: module_schema(source)}
            if include_metadata:
                result['_meta'] = {
                    'source_type': 'Module',
                    'device_count': 1,
                    'format_version': '1.0',
                }
            return result
    except ImportError:
        pass

    result = {}

    # Collect all AnalogElement subclasses exposed as attributes
    device_names = getattr(source, 'device_names', None) \
                   or getattr(source, 'modelNames', [])

    for name in device_names:
        cls = getattr(source, name, None)
        if cls is None or not (isinstance(cls, type) and issubclass(cls, AnalogElement)):
            continue
        result[name] = device_schema(cls)

    if include_metadata:
        result['_meta'] = {
            'source_type': type(source).__name__,
            'device_count': len(result),
            'format_version': '1.0',
        }

    return result


def export_schema_json(source, indent: int = 2, **kwargs) -> str:
    """Return the schema as a formatted JSON string.

    Parameters
    ----------
    source : BasePDK | ElementLibrary
        See :func:`export_schema`.
    indent : int
        JSON indentation level (default 2).
    """
    return json.dumps(export_schema(source, **kwargs), indent=indent)


# ---------------------------------------------------------------------------
# CLI entry point:  python -m silk.elements.schema [options]
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    import argparse
    import sys
    import os

    parser = argparse.ArgumentParser(
        description='Export PyNetlist device schema as JSON.')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        '--pdk',
        metavar='YAML_PATH',
        help='Path to PDK YAML file (e.g. pynetlist/pdk/data/skywater_130_device_details.yaml)',
    )
    group.add_argument(
        '--elements',
        action='store_true',
        help='Export the ideal element library (analog_devices.yaml)',
    )
    parser.add_argument(
        '--output', '-o',
        metavar='FILE',
        default='-',
        help='Output file path (default: stdout)',
    )
    parser.add_argument(
        '--indent',
        type=int,
        default=2,
        help='JSON indentation (default: 2)',
    )
    args = parser.parse_args()

    if args.pdk:
        from silk.pdk.basepdk import BasePDK
        source = BasePDK(args.pdk, libraryLocation='')
    else:
        from silk.elements import elements as source  # noqa: F811

    schema_json = export_schema_json(source, indent=args.indent)

    if args.output == '-':
        print(schema_json)
    else:
        with open(args.output, 'w') as f:
            f.write(schema_json)
        print(f'Schema written to {args.output}', file=sys.stderr)
