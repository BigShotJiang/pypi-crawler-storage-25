"""ElementLibrary — loads ideal analog elements from analog_devices.yaml."""

import os
import yaml

from silk.elements.factory import make_device_class

_DEFAULT_YAML = os.path.join(os.path.dirname(__file__), 'analog_devices.yaml')


class ElementLibrary:
    """Loads ideal analog element classes from a YAML file.

    After construction, each device is accessible as a class attribute::

        from silk.elements import elements
        r1 = elements.resistor('r1', p='vout', n='gnd', value=1e3)
        v1 = elements.vsource('vdd', p='vdd', n='gnd', dc=1.8)

    Parameters
    ----------
    yaml_path : str, optional
        Path to the device YAML file.  Defaults to the bundled
        ``analog_devices.yaml``.
    """

    def __init__(self, yaml_path=None):
        if yaml_path is None:
            yaml_path = _DEFAULT_YAML

        with open(yaml_path, 'r') as f:
            config = yaml.safe_load(f)

        self._device_classes = {}
        self.device_names = []

        for device_name, spec in config.items():
            cls = make_device_class(device_name, spec, is_pdk=False)
            self._device_classes[device_name] = cls
            setattr(self, device_name, cls)
            self.device_names.append(device_name)

    def __repr__(self):
        return f'ElementLibrary({self.device_names})'
