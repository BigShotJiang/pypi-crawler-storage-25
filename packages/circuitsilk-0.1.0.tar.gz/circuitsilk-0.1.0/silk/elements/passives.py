# Native passive element classes for PyNetlist
# Resistor, Capacitor, Inductor with SI-formatted SPICE output

from silk.utils._utils import _fmt


def _validate_net(name, field):
    if not isinstance(name, str) or not name.strip():
        raise ValueError(f'{field} must be a non-empty string, got {name!r}')


def _validate_name(name):
    if not isinstance(name, str) or not name.strip():
        raise ValueError(f'name must be a non-empty string, got {name!r}')


def _validate_value(value, field):
    if isinstance(value, str):
        if not value.strip():
            raise ValueError(f'{field} must be a non-empty string value, got {value!r}')
    elif isinstance(value, (int, float)):
        if value < 0:
            raise ValueError(f'{field} must be >= 0, got {value}')
    else:
        raise TypeError(
            f'{field} must be a number or a SPICE value string (e.g. 1e3 or "1k"), '
            f'got {type(value).__name__!r}'
        )


class PassiveBase:
    def __init__(self, name: str, pos: str, neg: str, value):
        _validate_name(name)
        _validate_net(pos, 'pos')
        _validate_net(neg, 'neg')
        self.name  = name
        self.pos   = pos
        self.neg   = neg
        self.value = value

    def to_spice(self) -> str:
        raise NotImplementedError


class Resistor(PassiveBase):
    def __init__(self, name: str, pos: str, neg: str, resistance=None, *, res=None):
        value = resistance if resistance is not None else res
        if value is None:
            raise ValueError(
                "Resistor requires a value: use resistance=<value> or res=<value>"
            )
        _validate_value(value, 'resistance')
        super().__init__(name, pos, neg, value)
        self.resistance = value

    def to_spice(self) -> str:
        return f'R{self.name} {self.pos} {self.neg} {_fmt(self.resistance)}\n'


class Capacitor(PassiveBase):
    def __init__(self, name: str, pos: str, neg: str, capacitance=None, *, cap=None):
        value = capacitance if capacitance is not None else cap
        if value is None:
            raise ValueError(
                "Capacitor requires a value: use capacitance=<value> or cap=<value>"
            )
        _validate_value(value, 'capacitance')
        super().__init__(name, pos, neg, value)
        self.capacitance = value

    def to_spice(self) -> str:
        return f'C{self.name} {self.pos} {self.neg} {_fmt(self.capacitance)}\n'


class Inductor(PassiveBase):
    def __init__(self, name: str, pos: str, neg: str, inductance=None, *, ind=None):
        value = inductance if inductance is not None else ind
        if value is None:
            raise ValueError(
                "Inductor requires a value: use inductance=<value> or ind=<value>"
            )
        _validate_value(value, 'inductance')
        super().__init__(name, pos, neg, value)
        self.inductance = value

    def to_spice(self) -> str:
        return f'L{self.name} {self.pos} {self.neg} {_fmt(self.inductance)}\n'
