"""make_device_class — creates Python classes from YAML device specs."""

from dataclasses import dataclass, field
from typing import Optional

from silk.utils._utils import _fmt
from silk.elements.base import AnalogElement


# ---------------------------------------------------------------------------
# Lightweight parameter constraint for factory-generated classes
# ---------------------------------------------------------------------------

@dataclass
class DeviceParamConstraint:
    """Parameter constraint for factory-generated device classes.

    Lighter than the PDK's ``ParameterConstraint`` — no min/max validation
    logic; just holds default, unit, and optional bounds for display.
    """
    default: object = None       # default value (None = required)
    unit: Optional[str] = None
    minval: Optional[str] = None
    maxval: Optional[str] = None
    resolution: Optional[str] = None


# ---------------------------------------------------------------------------
# Attribute-access helpers for param descriptors
# ---------------------------------------------------------------------------

class ParamAccessor:
    """Returned when a ParamDescriptor is accessed on a class.

    Carries the constraint metadata and exposes ``.variable()`` to create
    a pre-configured :class:`~silk.circuit.modules.ModuleVariable`.

    Example::

        pdk.nmos1p8.w  →  ParamAccessor for param 'w'
        pdk.nmos1p8.w.variable(name='w_n', value=1.0)  →  ModuleVariable
    """

    def __init__(self, owner_cls, param_name, constraint=None):
        self._cls = owner_cls
        self._param = param_name
        self._constraint = constraint

    def variable(self, *, name, value=None, **kwargs):
        """Create a ModuleVariable configured from PDK constraints for this param.

        Parameters
        ----------
        name : str
            Variable name — required to avoid silent clashes in ParameterSpace.
        value : float, optional
            Nominal / initial value.
        **kwargs
            Forwarded to :class:`~silk.circuit.modules.ModuleVariable`.
            Caller-supplied ``bounds`` and ``resolution`` override PDK values.
        """
        from silk.circuit.modules import ModuleVariable
        _name = name
        c = self._constraint
        if 'bounds' not in kwargs:
            bounds = None
            if c is not None and c.minval is not None:
                try:
                    bounds = (float(c.minval), None)
                except (ValueError, TypeError):
                    pass
            kwargs['bounds'] = bounds
        if 'resolution' not in kwargs and c is not None and c.resolution is not None:
            try:
                kwargs['resolution'] = float(c.resolution)
            except (ValueError, TypeError):
                pass
        return ModuleVariable(_name, value=value, **kwargs)

    def __repr__(self):
        return f'ParamAccessor({self._cls.__name__}.{self._param})'


class ParamDescriptor:
    """Non-data descriptor placed on device/source classes for each param name.

    - Class access  ``(MyDevice.w)``  → :class:`ParamAccessor` with constraint metadata.
    - Instance access ``(mn.w)``      → ``mn.params.get('w')`` for :class:`AnalogElement`
                                        instances (params live in the ``params`` dict,
                                        not in ``instance.__dict__``, so the descriptor
                                        is always invoked for instance access).
                                        For sources, ``self.dc = value`` in ``__init__``
                                        stores the value in ``instance.__dict__['dc']``
                                        which shadows the descriptor automatically
                                        (non-data descriptor — no ``__set__``).
    """

    def __init__(self, param_name, constraint=None):
        self._param = param_name
        self._constraint = constraint

    def __get__(self, obj, objtype=None):
        if obj is None:
            # Class-level access: return the accessor
            return ParamAccessor(objtype, self._param, self._constraint)
        # Instance-level access: return current value from params dict
        # (sources store values in __dict__ and shadow this descriptor automatically)
        if hasattr(obj, 'params') and isinstance(getattr(obj, 'params', None), dict):
            return obj.params.get(self._param)
        return obj.__dict__.get(self._param)

    def __repr__(self):
        return f'ParamDescriptor({self._param!r})'


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_pin_names(spec: dict) -> tuple:
    """Extract pin names from a YAML spec, handling dict and list formats."""
    pins = spec.get('pinList', [])
    if isinstance(pins, dict):
        return tuple(pins.keys())
    return tuple(pins)


def _build_pin_descriptions(spec: dict) -> dict:
    """Extract {pin_name: description} from a YAML spec.

    Returns an empty dict for list-format pinLists (no descriptions).
    """
    pins = spec.get('pinList', [])
    if isinstance(pins, dict):
        return dict(pins)   # {d: drain, g: gate, ...}
    return {}               # list format has no descriptions


def _build_constraints(spec: dict) -> dict:
    """Build {param_name: DeviceParamConstraint} from a YAML spec.

    Handles both:
    - PDK format:  ``paramList: {name: {minval, maxval, unit}}``
    - Ideal format: ``paramConstraints: [{name, default, unit}]``
    """
    if 'paramList' in spec:
        result = {}
        for name, data in spec['paramList'].items():
            result[name] = DeviceParamConstraint(
                default=data.get('minval'),   # use minval as the default
                unit=data.get('unit'),
                minval=str(data['minval']),
                maxval=str(data['maxval']),
            )
        return result

    if 'paramConstraints' in spec:
        result = {}
        for entry in spec['paramConstraints']:
            result[entry['name']] = DeviceParamConstraint(
                default=entry.get('default'),
                unit=entry.get('unit'),
            )
        return result

    return {}


def _render_param(val) -> str:
    """Format a parameter value for SPICE output.

    Handles plain numbers, strings, and ``ModuleVariable`` objects
    (duck-typed via ``.value``).

    Raises
    ------
    ValueError
        If a ``ModuleVariable`` has no value assigned yet.
    """
    if hasattr(val, 'value'):  # ModuleVariable duck-type
        v = val.value
        if v is None:
            raise ValueError('Parameter has no value assigned (ModuleVariable.value is None)')
        return _fmt(v) if isinstance(v, (int, float)) else str(v)
    if isinstance(val, (int, float)):
        return _fmt(val)
    return str(val)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def make_device_class(device_name: str, spec: dict, is_pdk: bool = True):
    """Create a Python class for a device from its YAML spec.

    Parameters
    ----------
    device_name : str
        YAML key for the device (e.g. ``'nmos1p8'``, ``'resistor'``).
    spec : dict
        Parsed YAML entry for this device.
    is_pdk : bool
        ``True`` for PDK devices (default SPICE prefix ``XM``),
        ``False`` for ideal elements (prefix from YAML ``spice_prefix``).

    Returns
    -------
    type
        A subclass of :class:`AnalogElement` with a constructor whose
        keyword arguments match the device's pins and parameters.
    """
    pin_names         = _build_pin_names(spec)
    pin_descriptions  = _build_pin_descriptions(spec)
    param_constraints = _build_constraints(spec)
    param_names       = tuple(param_constraints.keys())
    param_defaults    = {p: c.default for p, c in param_constraints.items()}
    pdk_device_str    = spec.get('PDKDevice', '')
    category          = spec.get('category', '')
    # Default prefix: XM for PDK subcircuit devices, from YAML for ideal
    spice_prefix      = spec.get('spice_prefix', 'XM' if is_pdk else 'X')

    # ------------------------------------------------------------------
    # __init__ for the generated class
    # ------------------------------------------------------------------

    def __init__(self, name, **kwargs):
        AnalogElement.__init__(self, name)

        # Resolve nets — every pin must be supplied
        for pin in self.__class__._pin_names:
            if pin not in kwargs:
                raise TypeError(
                    f"{self.__class__.__name__}() missing required net for pin '{pin}'"
                )
            self.nets[pin] = kwargs.pop(pin)

        # Resolve params — use defaults where available
        for p, constraint in self.__class__._param_constraints.items():
            if p in kwargs:
                self.params[p] = kwargs.pop(p)
            elif constraint.default is not None:
                self.params[p] = constraint.default
            else:
                raise TypeError(
                    f"{self.__class__.__name__}() missing required parameter '{p}'"
                )

        if kwargs:
            raise TypeError(
                f"{self.__class__.__name__}() got unexpected keyword arguments: "
                f"{list(kwargs.keys())}"
            )

    # ------------------------------------------------------------------
    # to_spice for the generated class
    # ------------------------------------------------------------------

    def to_spice(self):
        prefix   = self.__class__._spice_prefix
        pdk_dev  = self.__class__._pdk_device
        net_str  = ' '.join(self.nets[p] for p in self.__class__._pin_names)
        param_str = ' '.join(
            f'{p}={_render_param(self.params[p])}'
            for p in self.__class__._param_names
        )
        if pdk_dev:
            # PDK subcircuit: XMmn1 vout vin gnd gnd sky130_... w=2u l=150n
            line = f'{prefix}{self.name} {net_str} {pdk_dev}'
            if param_str:
                line += f' {param_str}'
        else:
            # Ideal element: Rr1 vout gnd 1k   (single value, no name=val)
            # For single-param ideal elements, emit value directly
            if len(self.__class__._param_names) == 1:
                p = self.__class__._param_names[0]
                # vsource/isource: V/I prefix, DC keyword
                if prefix in ('V', 'I'):
                    line = f'{prefix}{self.name} {net_str} DC {_render_param(self.params[p])}'
                else:
                    line = f'{prefix}{self.name} {net_str} {_render_param(self.params[p])}'
            else:
                line = f'{prefix}{self.name} {net_str}'
                if param_str:
                    line += f' {param_str}'
        return line + '\n'

    # ------------------------------------------------------------------
    # Build the class with type()
    # ------------------------------------------------------------------

    cls = type(device_name, (AnalogElement,), {
        '__init__':            __init__,
        'to_spice':            to_spice,
        '_pin_names':          pin_names,
        '_pin_descriptions':   pin_descriptions,
        '_param_names':        param_names,
        '_param_defaults':     param_defaults,
        '_param_constraints':  param_constraints,
        '_spice_prefix':       spice_prefix,
        '_pdk_device':         pdk_device_str,
        '_device_type_name':   device_name,
        '_is_pdk_device':      is_pdk,
        '_category':           category,
        'device_name':         device_name,   # backward-compat attribute
    })

    # Add a ParamDescriptor for each param so that MyDevice.w returns a
    # ParamAccessor (and mn.w returns mn.params.get('w') via the descriptor).
    for pname, constraint in param_constraints.items():
        setattr(cls, pname, ParamDescriptor(pname, constraint))

    return cls
