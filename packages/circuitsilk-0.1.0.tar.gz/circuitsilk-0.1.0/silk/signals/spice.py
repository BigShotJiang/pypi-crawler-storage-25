"""NgspiceSignal — ngspice-specific waveform signal."""

from silk.signals.base import Signal
from silk.exceptions import SimulationError


# X-axis signal names used by ngspice rawfiles
_XAXIS_NAMES = {'time', 'frequency'}


@Signal.register('ngspice')
class NgspiceSignal(Signal):
    """Waveform signal loaded from an ngspice simulation.

    Registered as ``'ngspice'`` in the :class:`Signal` registry.
    ``netlist.py`` calls :meth:`Signal.load` which dispatches here
    automatically — no simulator-specific code lives in the netlist layer.

    Parameters
    ----------
    name : str
        Signal name, e.g. ``'v(out)'``.
    type : str
        Physical type string from the rawfile, e.g. ``'voltage'``.
    xlabel : str
        X-axis label (``'time'`` for transient, ``'frequency'`` for AC).
    ylabel : str
        Y-axis label.
    xvalues : array-like
        Independent-axis values (time or frequency array).
    yvalues : array-like
        Dependent-axis values.
    """

    def __init__(self, name, type, xlabel, ylabel, xvalues, yvalues):  # noqa: A002
        super().__init__(name, type, xlabel, ylabel, xvalues, yvalues)

    @classmethod
    def from_rawfile(cls, rawdata, signal_name: str, signal_type: str = 'V'):
        """Extract a single signal from an ngspice rawfile result object.

        Parameters
        ----------
        rawdata : ngspice_read result
            The object returned by ``ngr.ngspice_read()`` after
            ``readfile()`` has been called.
        signal_name : str
            The bare signal name to find, e.g. ``'out'`` (without the
            ``v(...)`` wrapper).
        signal_type : str
            ``'V'`` for voltage, ``'I'`` for current.  Case-insensitive.

        Returns
        -------
        NgspiceSignal

        Raises
        ------
        SimulationError
            If the requested signal is not found in the rawfile.
        """
        xlabel = None
        xvals  = None
        ylabel = None
        yvals  = None
        ysig_type = None

        sigName_type    = None
        sigName_reduced = None

        for i in range(rawdata.nvars):
            sig_name = rawdata.vectors[i].name

            # X-axis detection (time, frequency, …)
            if sig_name.lower() in _XAXIS_NAMES:
                xlabel = sig_name
                xvals  = rawdata.vectors[i].data
                continue

            # Parse "v(out)" → type="v", reduced="out"
            parts = sig_name.split('(')
            if len(parts) != 2:
                continue
            sigName_type    = parts[0]
            sigName_reduced = parts[1].rstrip(')')

            if (sigName_reduced == signal_name
                    and sigName_type.lower() == signal_type.lower()):
                ylabel    = sigName_type
                yvals     = rawdata.vectors[i].data
                ysig_type = rawdata.vectors[i].type

        if xvals is None or yvals is None:
            raise SimulationError(
                f'Signal {signal_name!r} (type={signal_type!r}) not found '
                f'in rawfile. Last parsed: type={sigName_type!r}, '
                f'name={sigName_reduced!r}'
            )

        return cls(signal_name, ysig_type, xlabel, ylabel, xvals, yvals)


# Backward-compat alias
PySpiceSignal = NgspiceSignal
