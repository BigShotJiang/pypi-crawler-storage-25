"""silk.signals.metrics — analog circuit performance metrics.

All functions take Signal objects with numpy x/y arrays.
AC signals have complex y (magnitude + phase from ngspice).
Transient signals have real y.

Usage::

    from silk.signals.metrics import dc_gain_dB, bandwidth_3dB, phase_margin

    gain = dc_gain_dB(ac_sig)
    bw   = bandwidth_3dB(ac_sig)
    pm   = phase_margin(ac_sig)
"""
import numpy as np
from silk.signals.base import Signal


def dc_gain_dB(sig: Signal) -> float:
    """Peak magnitude in dB from an AC frequency-response signal.

    Parameters
    ----------
    sig : Signal
        AC simulation signal with complex y-values.

    Returns
    -------
    float
        20 * log10(max(|y|))
    """
    return float(20.0 * np.log10(np.max(np.abs(sig.y))))


def gain_at_freq(sig: Signal, freq: float) -> float:
    """Linear gain magnitude at the frequency closest to *freq*.

    Parameters
    ----------
    sig : Signal
        AC simulation signal.
    freq : float
        Target frequency in Hz.

    Returns
    -------
    float
        |y| at the nearest sample.
    """
    idx = int(np.argmin(np.abs(sig.x - freq)))
    return float(np.abs(sig.y[idx]))


def bandwidth_3dB(sig: Signal) -> float:
    """3 dB bandwidth: highest frequency where |gain| >= peak / sqrt(2).

    Parameters
    ----------
    sig : Signal
        AC simulation signal.

    Returns
    -------
    float
        Frequency in Hz (same units as sig.x). Returns 0 if not found.
    """
    peak = np.max(np.abs(sig.y))
    threshold = peak / np.sqrt(2.0)
    above = np.where(np.abs(sig.y) >= threshold)[0]
    if len(above) == 0:
        return 0.0
    return float(sig.x[above[-1]])


def unity_gain_freq(sig: Signal) -> float:
    """Frequency where |gain| first crosses 1 (0 dB), interpolated.

    Parameters
    ----------
    sig : Signal
        AC simulation signal.

    Returns
    -------
    float
        Frequency in Hz. Returns 0 if gain never reaches 0 dB.
    """
    mag = np.abs(sig.y)
    for i in range(len(mag) - 1):
        if (mag[i] >= 1.0 >= mag[i + 1]) or (mag[i] <= 1.0 <= mag[i + 1]):
            f0, f1 = float(sig.x[i]), float(sig.x[i + 1])
            m0, m1 = float(mag[i]), float(mag[i + 1])
            if m1 == m0:
                return f0
            t = (1.0 - m0) / (m1 - m0)
            # interpolate in log-frequency space
            return float(np.exp(np.log(f0) + t * (np.log(f1) - np.log(f0))))
    return 0.0


def phase_at_freq(sig: Signal, freq: float) -> float:
    """Phase in degrees at the frequency closest to *freq*.

    Parameters
    ----------
    sig : Signal
        AC simulation signal with complex y-values.
    freq : float
        Target frequency in Hz.

    Returns
    -------
    float
        Phase in degrees at the nearest sample.
    """
    idx = int(np.argmin(np.abs(sig.x - freq)))
    return float(np.degrees(np.angle(sig.y[idx])))


def phase_margin(sig: Signal) -> float:
    """Phase margin in degrees: 180 + phase(f_unity_gain).

    Parameters
    ----------
    sig : Signal
        AC simulation signal with complex y-values.

    Returns
    -------
    float
        Phase margin in degrees. Returns NaN if unity-gain frequency is 0.
    """
    f_ugf = unity_gain_freq(sig)
    if f_ugf == 0.0:
        return float('nan')
    ph = phase_at_freq(sig, f_ugf)
    return float(180.0 + ph)


def gain_margin(sig: Signal) -> float:
    """Gain margin in dB: -20*log10(|gain(f_180deg)|).

    Finds the first frequency where phase crosses -180 degrees.

    Parameters
    ----------
    sig : Signal
        AC simulation signal with complex y-values.

    Returns
    -------
    float
        Gain margin in dB. Returns NaN if phase never reaches -180 degrees.
    """
    phase_deg = np.degrees(np.angle(sig.y))
    for i in range(len(phase_deg) - 1):
        if phase_deg[i] > -180.0 >= phase_deg[i + 1]:
            mag = float(np.abs(sig.y[i]))
            if mag == 0.0:
                return float('inf')
            return float(-20.0 * np.log10(mag))
    return float('nan')


def cmrr_dB(vdiff: Signal, vcm: Signal) -> float:
    """CMRR in dB: 20*log10(|diff_gain / cm_gain|) at the first sample.

    Parameters
    ----------
    vdiff : Signal
        Differential-mode AC gain signal.
    vcm : Signal
        Common-mode AC gain signal.

    Returns
    -------
    float
        CMRR in dB. Returns inf if common-mode gain is zero.
    """
    diff_mag = float(np.abs(vdiff.y[0]))
    cm_mag   = float(np.abs(vcm.y[0]))
    if cm_mag == 0.0:
        return float('inf')
    return float(20.0 * np.log10(diff_mag / cm_mag))


def integrated_noise(sig: Signal, f1: float, f2: float) -> float:
    """RMS integrated noise between f1 and f2 Hz.

    Parameters
    ----------
    sig : Signal
        Noise simulation signal. sig.y is noise spectral density in V/sqrt(Hz).
    f1, f2 : float
        Integration band in Hz.

    Returns
    -------
    float
        RMS noise voltage over the band. Returns 0 if fewer than 2 samples in band.
    """
    mask = (sig.x >= f1) & (sig.x <= f2)
    x = sig.x[mask]
    psd = np.abs(sig.y[mask]) ** 2   # power spectral density
    if len(x) < 2:
        return 0.0
    return float(np.sqrt(np.trapezoid(psd, x)))
