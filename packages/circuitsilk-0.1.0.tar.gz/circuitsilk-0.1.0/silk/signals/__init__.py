"""silk.signals — waveform signal objects and analysis metrics."""
from silk.signals.base import Signal, PySignal
from silk.signals.spice import NgspiceSignal, PySpiceSignal
from silk.signals import metrics
from silk.signals.metrics import (
    dc_gain_dB, bandwidth_3dB, unity_gain_freq,
    phase_margin, gain_margin, cmrr_dB, integrated_noise,
    gain_at_freq, phase_at_freq,
)

__all__ = [
    "Signal", "NgspiceSignal", "PySignal", "PySpiceSignal", "metrics",
    "dc_gain_dB", "bandwidth_3dB", "unity_gain_freq",
    "phase_margin", "gain_margin", "cmrr_dB", "integrated_noise",
    "gain_at_freq", "phase_at_freq",
]
