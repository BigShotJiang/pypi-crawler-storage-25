"""Signal — simulator-agnostic base class for waveform signals."""

import numpy as np


class Signal:
    """Base class for simulation waveform signals.

    Subclass this for each simulator backend (ngspice, Spectre, Xyce, …).
    Subclasses are responsible for loading data from their native format via
    ``from_rawfile()`` and must register themselves with
    ``@Signal.register('simulator_name')``.

    This class provides the shared interface: arithmetic operators, ``plot()``,
    and attribute access (``x``, ``y``, ``name``, ``xlabel``, ``ylabel``).

    Parameters
    ----------
    name : str
        Signal name, e.g. ``'v(out)'``.
    type : str
        Physical type, e.g. ``'voltage'``, ``'current'``.
    xlabel : str
        Label for the x-axis (``'time'``, ``'frequency'``, …).
    ylabel : str
        Label for the y-axis.
    xvalues : array-like
        Independent-axis values.
    yvalues : array-like
        Dependent-axis values (same length as *xvalues*).
    """

    _registry: dict = {}

    def __init__(self, name, type, xlabel, ylabel, xvalues, yvalues):  # noqa: A002
        self.name   = name
        self.type   = type
        self.xlabel = xlabel
        self.ylabel = ylabel
        self.x      = np.asarray(xvalues)
        self.y      = np.asarray(yvalues)

    # ------------------------------------------------------------------
    # Simulator registry
    # ------------------------------------------------------------------

    @classmethod
    def register(cls, simulator_name: str):
        """Class decorator that registers a signal subclass for a simulator.

        Usage::

            @Signal.register('ngspice')
            class NgspiceSignal(Signal):
                @classmethod
                def from_rawfile(cls, rawdata, signal_name, signal_type):
                    ...
        """
        def decorator(subclass):
            cls._registry[simulator_name] = subclass
            return subclass
        return decorator

    @classmethod
    def load(cls, simulator: str, rawdata, signal_name: str, signal_type: str = 'V'):
        """Load a signal from simulator output data.

        Looks up the registered signal class for *simulator* and delegates
        to its ``from_rawfile()`` method.  Adding a new simulator requires
        only a new subclass — this method and ``netlist.py`` never change.

        Parameters
        ----------
        simulator : str
            Simulator name, e.g. ``'ngspice'``.
        rawdata : object
            Raw simulation result object (format is simulator-specific).
        signal_name : str
            Signal name to extract, e.g. ``'out'``.
        signal_type : str
            Signal type to extract: ``'V'`` for voltage, ``'I'`` for current.

        Returns
        -------
        Signal
            An instance of the registered subclass for *simulator*.

        Raises
        ------
        ValueError
            If no signal class is registered for *simulator*.
        """
        signal_cls = cls._registry.get(simulator)
        if signal_cls is None:
            registered = list(cls._registry.keys())
            raise ValueError(
                f'No signal class registered for simulator {simulator!r}. '
                f'Registered simulators: {registered}'
            )
        return signal_cls.from_rawfile(rawdata, signal_name, signal_type)

    # ------------------------------------------------------------------
    # Arithmetic operators
    # ------------------------------------------------------------------

    def __add__(self, other):
        self._check_compatible(other)
        return self._new(
            self.name + '+' + other.name,
            self.type,
            self.x,
            self.y + other.y,
        )

    def __sub__(self, other):
        self._check_compatible(other)
        return self._new(
            self.name + '-' + other.name,
            self.type,
            self.x,
            self.y - other.y,
        )

    def __mul__(self, other):
        self._check_xlabels(other)
        self._check_xvalues(other)
        new_type = self.type + '*' + other.type
        return self._new(
            self.name + '*' + other.name,
            new_type,
            self.x,
            self.y * other.y,
        )

    # ------------------------------------------------------------------
    # Plotting
    # ------------------------------------------------------------------

    def plot(self, ax=None, **kwargs):
        """Plot the signal on *ax* (creates one if not provided)."""
        if ax is None:
            import matplotlib.pyplot as plt
            ax = plt.gca()
        ax.plot(self.x, self.y, **kwargs)
        ax.set_xlabel(self.xlabel)
        ax.set_ylabel(self.ylabel)
        return ax

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _new(self, name, sig_type, x, y):
        """Return a new instance of the same concrete class."""
        obj = object.__new__(type(self))
        Signal.__init__(obj, name, sig_type, self.xlabel, sig_type, x, y)
        return obj

    def _check_compatible(self, other):
        self._check_xlabels(other)
        self._check_types(other)
        self._check_xvalues(other)

    def _check_xlabels(self, other):
        if self.xlabel != other.xlabel:
            raise ValueError(
                f'Signals have different x-labels: '
                f'{self.xlabel!r} vs {other.xlabel!r}'
            )

    def _check_types(self, other):
        if self.type != other.type:
            raise ValueError(
                f'Signals have different types: '
                f'{self.type!r} vs {other.type!r}'
            )

    def _check_xvalues(self, other):
        if np.std(self.x - other.x) > 0:
            raise ValueError(
                'X-values in both signals do not match. '
                'Interpolation needed (feature not included yet).'
            )


# Backward-compat alias
PySignal = Signal
