"""Joint parameter space over multiple ModuleVariable objects.

ParameterSpace collects N ModuleVariable objects and operates on them
jointly: generating correlated design points, interfacing with external
optimizers, and applying suggested points back to the variables.

The per-variable ModuleVariable.sample() method handles 1-D sampling;
ParameterSpace handles the multi-dimensional case where stratification
and quasi-random sequences must be coordinated across variables.
"""

import math
import random
import itertools
from typing import Dict, List, Optional, Tuple, Union

from silk.circuit.modules import ModuleVariable, VarType, Distribution


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _first_n_primes(n: int) -> List[int]:
    """Return the first n prime numbers (used as Halton sequence bases)."""
    primes = []
    candidate = 2
    while len(primes) < n:
        if all(candidate % p != 0 for p in primes):
            primes.append(candidate)
        candidate += 1
    return primes


def _halton(k: int, base: int) -> float:
    """k-th element of the Halton sequence with the given prime base."""
    r, denom = 0.0, 1.0
    while k:
        denom *= base
        k, remainder = divmod(k, base)
        r += remainder / denom
    return r


# ---------------------------------------------------------------------------
# ParameterSpace
# ---------------------------------------------------------------------------

class Space:
    """Joint parameter space over N :class:`ModuleVariable` objects.

    Parameters
    ----------
    variables : list of ModuleVariable or dict {name: ModuleVariable}
        The variables that define the space.  When a list is passed the
        variable's ``.name`` attribute is used as the key; duplicate names
        raise ``ValueError``.
    groups : list of lists of ModuleVariable, optional
        Correlation groups.  Variables in the same group share the same
        stratum permutation in LHS and the same sequence in Sobol — they
        advance together through the design space rather than being sampled
        independently.  Multiple groups are supported; a variable not listed
        in any group is treated as its own independent group.

        Example — ``w_n`` and ``w_p`` correlated, ``l`` independent::

            space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])

        Multiple groups::

            space = ParameterSpace([w_n, w_p, l, vdd],
                                   groups=[[w_n, w_p], [l, vdd]])

    Examples
    --------
    Basic construction and joint sampling::

        from silk import ModuleVariable, VarType
        from silk.optimize import Space

        w = ModuleVariable('w', bounds=(0.5e-6, 20e-6))
        l = ModuleVariable('l', bounds=(0.15e-6, 2e-6))
        m = ModuleVariable('m', bounds=(1, 32), var_type=VarType.INTEGER)

        space = ParameterSpace([w, l, m])
        points = space.sample(50, method='lhs')  # 50 joint design points
        space.apply(points[0])                   # sets w.value, l.value, m.value
    """

    def __init__(
        self,
        variables: Union[List[ModuleVariable], Dict[str, ModuleVariable]],
        groups: Optional[List[List[ModuleVariable]]] = None,
    ) -> None:
        if isinstance(variables, dict):
            self._vars: Dict[str, ModuleVariable] = dict(variables)
        elif isinstance(variables, list):
            seen: set = set()
            self._vars = {}
            for v in variables:
                if v.name in seen:
                    raise ValueError(
                        f"Duplicate variable name '{v.name}' in ParameterSpace"
                    )
                seen.add(v.name)
                self._vars[v.name] = v
        else:
            raise TypeError("variables must be a list or dict of ModuleVariable")

        if len(self._vars) == 0:
            raise ValueError("ParameterSpace requires at least one variable")

        # Build group map: var_name -> group_id
        # Variables in the same group share sampling permutations.
        self._group_map: Dict[str, int] = {}
        next_group = 0
        if groups:
            for group in groups:
                for var in group:
                    if var.name not in self._vars:
                        raise ValueError(
                            f"Variable '{var.name}' in groups= is not in this "
                            f"ParameterSpace. Add it to the variables list first."
                        )
                    if var.name in self._group_map:
                        raise ValueError(
                            f"Variable '{var.name}' appears in more than one group."
                        )
                    self._group_map[var.name] = next_group
                next_group += 1
        # Ungrouped variables each get their own independent group id
        for name in self._vars:
            if name not in self._group_map:
                self._group_map[name] = next_group
                next_group += 1

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def names(self) -> List[str]:
        """Variable names in insertion order."""
        return list(self._vars.keys())

    @property
    def size(self) -> int:
        """Number of variables in the space."""
        return len(self._vars)

    def __len__(self) -> int:
        return self.size

    def __repr__(self) -> str:
        return f"ParameterSpace({self.names})"

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    def sample(self, n: int, method: str = 'random') -> List[Dict[str, object]]:
        """Generate *n* joint design points.

        Parameters
        ----------
        n : int
            Number of design points.  For ``method='grid'`` this is the
            number of points **per variable** — total output is ``n^D``
            dicts where D is the number of numeric variables.
        method : str
            ``'random'``  — independent random draws per variable.

            ``'lhs'``     — Latin Hypercube Sampling; each variable is
            independently stratified into *n* equal-width strata, with one
            sample per stratum.  Strata are shuffled independently so
            variables are not rank-correlated.

            ``'sobol'``   — Halton low-discrepancy sequence; variable *d*
            uses the *d*-th prime as its base.  Provides better space
            coverage than random for small *n*.  CATEGORICAL and NORMAL
            variables fall back to random draws.

            ``'grid'``    — Full factorial cross-product.  For D numeric
            variables and *n* points each, produces ``n^D`` total dicts.
            **Use with caution for D > 3.**

        Returns
        -------
        list of dict
            Each dict maps variable names to sampled values.
        """
        if n == 0:
            return []
        if method == 'lhs':
            return self._sample_lhs(n)
        if method == 'sobol':
            return self._sample_sobol(n)
        if method == 'grid':
            return self._sample_grid(n)
        if method == 'random':
            return self._sample_random(n)
        raise ValueError(
            f"Unknown sampling method '{method}'. "
            "Choose from: 'random', 'lhs', 'sobol', 'grid'."
        )

    # ------------------------------------------------------------------
    # Internal sampling methods
    # ------------------------------------------------------------------

    def _discrete_values(self, var) -> List[float]:
        """Enumerate all valid grid points for a resolution-constrained variable.

        Returns a list ``[lo, lo+res, lo+2*res, ...]`` clipped to ``[lo, hi]``.
        This is the actual realizable set the sampler should draw from.
        """
        lo, hi = var.bounds
        res = var.resolution
        n = int(round((hi - lo) / res)) + 1
        vals = []
        for i in range(n):
            v = lo + i * res
            if v > hi + res * 1e-9:
                break
            ndigits = max(0, -int(math.floor(math.log10(res)))) + 2
            vals.append(round(v, ndigits))
        return vals

    def _group_permutations(self, n: int) -> Dict[int, List[int]]:
        """Return one shuffled permutation of [0..n-1] per group id.

        Variables sharing a group id will receive the same permutation,
        making them advance through strata in lockstep.
        """
        group_ids = set(self._group_map.values())
        return {gid: random.sample(range(n), n) for gid in group_ids}

    def _sample_random(self, n: int) -> List[Dict[str, object]]:
        """Random sampling — grouped variables share the same draw order."""
        # For random, sharing the permutation means applying the same index
        # shuffle so grouped variables are drawn from matching positions.
        perms = self._group_permutations(n)
        cols: Dict[str, list] = {}
        for name, var in self._vars.items():
            gid = self._group_map[name]
            perm = perms[gid]
            if var.resolution is not None and var.enforce_resolution and var.bounds is not None:
                discrete = self._discrete_values(var)
                full = [random.choice(discrete) for _ in range(n)]
                cols[name] = [full[perm[i]] for i in range(n)]
            else:
                full = var.sample(n, 'random')
                cols[name] = [full[perm[i]] for i in range(n)]
        return [{name: cols[name][i] for name in self.names} for i in range(n)]

    def _sample_lhs(self, n: int) -> List[Dict[str, object]]:
        """Latin Hypercube Sampling — stratifies over the discrete grid when
        resolution is set.  Variables in the same group share the same stratum
        permutation so they advance through the design space in lockstep."""
        perms = self._group_permutations(n)
        cols: Dict[str, list] = {}
        for name, var in self._vars.items():
            if var.var_type == VarType.CATEGORICAL:
                cols[name] = var.sample(n, 'random')
                continue
            if var.bounds is None:
                raise ValueError(
                    f"Variable '{name}' has no bounds. "
                    "Set bounds=(min, max) before sampling."
                )
            strata = perms[self._group_map[name]]
            if var.resolution is not None and var.enforce_resolution:
                discrete = self._discrete_values(var)
                nd = len(discrete)
                col = []
                for s in strata:
                    idx = int((s + random.random()) / n * nd)
                    col.append(discrete[min(idx, nd - 1)])
                cols[name] = col
            else:
                col = []
                for s in strata:
                    u = (s + random.random()) / n
                    col.append(self._scale_to_var(u, var))
                cols[name] = col

        return [{name: cols[name][i] for name in self.names} for i in range(n)]

    def _sample_sobol(self, n: int) -> List[Dict[str, object]]:
        """Halton low-discrepancy sequence — variables in the same group use
        the same prime base so they follow the same sequence."""
        # Assign one prime per group (not per variable)
        group_ids = sorted(set(self._group_map.values()))
        n_groups = len(group_ids)
        primes = _first_n_primes(n_groups)
        group_prime = {gid: primes[i] for i, gid in enumerate(group_ids)}

        cols: Dict[str, list] = {}
        for name, var in self._vars.items():
            if var.var_type == VarType.CATEGORICAL or var.distribution == Distribution.NORMAL:
                cols[name] = var.sample(n, 'random')
                continue
            if var.bounds is None:
                raise ValueError(
                    f"Variable '{name}' has no bounds. "
                    "Set bounds=(min, max) before sampling."
                )
            base = group_prime[self._group_map[name]]
            if var.resolution is not None and var.enforce_resolution:
                discrete = self._discrete_values(var)
                nd = len(discrete)
                col = [discrete[min(int(_halton(k + 1, base) * nd), nd - 1)]
                       for k in range(n)]
            else:
                col = [self._scale_to_var(_halton(k + 1, base), var) for k in range(n)]
            cols[name] = col

        return [{name: cols[name][i] for name in self.names} for i in range(n)]

    def _sample_grid(self, n: int) -> List[Dict[str, object]]:
        """Full factorial cross-product.  When resolution is set and no explicit
        step is provided, uses the resolution as the grid step."""
        per_var = []
        for name, var in self._vars.items():
            if var.var_type == VarType.CATEGORICAL:
                vals = list(var.categories)
            elif var.resolution is not None and var.enforce_resolution and var.step is None:
                # Use the discrete grid — select n evenly-spaced values from it
                discrete = self._discrete_values(var)
                if len(discrete) <= n:
                    vals = discrete
                else:
                    indices = [int(i * (len(discrete) - 1) / (n - 1)) for i in range(n)]
                    vals = [discrete[i] for i in indices]
            else:
                vals = var.sample(n, 'grid')
            per_var.append((name, vals))

        return [
            {name: val for (name, _), val in zip(per_var, combo)}
            for combo in itertools.product(*[vals for _, vals in per_var])
        ]

    # ------------------------------------------------------------------
    # Value scaling (uniform [0,1] → variable domain)
    # ------------------------------------------------------------------

    def _scale_to_var(self, u: float, var: ModuleVariable):
        """Map a uniform [0,1] sample *u* to the variable's domain."""
        lo, hi = var.bounds
        if var.distribution == Distribution.LOG_UNIFORM:
            if lo <= 0:
                raise ValueError(
                    f"Variable '{var.name}' has LOG_UNIFORM distribution "
                    "but bounds[0] <= 0."
                )
            log_lo, log_hi = math.log(lo), math.log(hi)
            val = math.exp(log_lo + u * (log_hi - log_lo))
        else:
            val = lo + u * (hi - lo)

        if var.var_type == VarType.INTEGER:
            val = int(round(val))
        return var._snap(val)

    # ------------------------------------------------------------------
    # Apply a point to variables
    # ------------------------------------------------------------------

    def apply(self, point: Dict[str, object]) -> None:
        """Set each variable's value from *point*.

        Parameters
        ----------
        point : dict
            Mapping of ``{variable_name: value}``.

        Raises
        ------
        KeyError
            If a key in *point* is not a variable in this space.
        """
        for name, val in point.items():
            if name not in self._vars:
                raise KeyError(
                    f"Unknown variable '{name}' — not in this ParameterSpace"
                )
            self._vars[name].value = val

    # ------------------------------------------------------------------
    # Optimizer interface
    # ------------------------------------------------------------------

    def to_bounds(self) -> List[Tuple[float, float]]:
        """Return ``[(lo, hi), ...]`` in variable name order.

        For CATEGORICAL variables returns ``(0, len(categories) - 1)`` as
        integer index bounds — a common convention for mixed-integer
        optimizers.  The caller is responsible for encoding/decoding
        category indices.

        Raises
        ------
        ValueError
            If any non-categorical variable has no bounds set.
        """
        result = []
        for name, var in self._vars.items():
            if var.var_type == VarType.CATEGORICAL:
                result.append((0, len(var.categories) - 1))
            elif var.bounds is None:
                raise ValueError(
                    f"Variable '{name}' has no bounds. "
                    "Set bounds=(min, max) before calling to_bounds()."
                )
            else:
                result.append(var.bounds)
        return result

    def to_list(self, point: Dict[str, object]) -> List[object]:
        """Convert a ``{name: value}`` dict to an ordered flat list.

        Order matches :attr:`names`.
        """
        return [point[name] for name in self.names]

    def from_list(self, values: List[object]) -> Dict[str, object]:
        """Convert an ordered flat list back to a ``{name: value}`` dict.

        Parameters
        ----------
        values : list
            Must have the same length as :attr:`size`.

        Raises
        ------
        ValueError
            If length of *values* does not match the number of variables.
        """
        if len(values) != self.size:
            raise ValueError(
                f"Expected {self.size} values, got {len(values)}"
            )
        return dict(zip(self.names, values))

    # ------------------------------------------------------------------
    # Validation and clipping
    # ------------------------------------------------------------------

    def validate(self, point: Dict[str, object]) -> bool:
        """Return ``True`` if every value in *point* is valid for its variable."""
        return all(
            self._vars[name].validate(val)
            for name, val in point.items()
            if name in self._vars
        )

    def clip(self, point: Dict[str, object]) -> Dict[str, object]:
        """Return a new dict with each value clipped to its variable's bounds.

        Does not mutate *point*.
        """
        return {
            name: self._vars[name].clip(val) if name in self._vars else val
            for name, val in point.items()
        }

# Backward-compat alias
ParameterSpace = Space
