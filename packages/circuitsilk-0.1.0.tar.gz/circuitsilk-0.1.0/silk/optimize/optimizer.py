"""CircuitOptimizer — evaluation harness for circuit design optimization.

CircuitOptimizer wraps a PyModuleTest and a ParameterSpace into a single
callable ``evaluate(point) → record``.  Any optimizer — scipy, scikit-optimize,
CMA-ES, or an AI agent — drives the search by calling evaluate() and reading
the returned record.

Design principles
-----------------
- **Thin glue layer**: no optimizer logic lives here; this class only defines
  the evaluation protocol and failure logging.
- **Every call is logged**: successes and failures alike, each with a unique
  status tag so they can be filtered and analysed separately later.
- **Objectives and constraints are declared separately** from metrics.
  add_metric() (on PyModuleTest) measures things; add_objective() and
  add_constraint() (on CircuitOptimizer) tell the optimizer what to optimise
  and what counts as feasible.

Failure taxonomy
----------------
``'parameter_error'``   space.apply() failed — bad point, out of bounds.
``'netlist_error'``     PyNetlistError raised during netlist generation.
``'simulation_failure'``SimulationError raised — ngspice exited non-zero.
``'metric_error'``      Simulation succeeded but one or more metric
                        extractors raised (stored as "Error: ..." strings
                        in the metrics dict by PyModuleTest).
``'success'``           All steps completed; ``feasible`` flag set by
                        evaluating constraints.
"""

import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from silk.optimize.parameter_space import ParameterSpace
from silk.circuit.module_test import PyModuleTest
from silk.exceptions import PyNetlistError, SimulationError


class Optimizer:
    """Evaluation harness for circuit design optimization.

    Parameters
    ----------
    test : PyModuleTest
        The testbench that runs simulations and extracts metrics.
        Must have ``add_module_under_test()`` already called and at
        least one metric registered.
    space : ParameterSpace
        The joint parameter space.  Variables in the space must be
        linked to the circuit's device parameters via
        ``updateElement()`` before calling ``evaluate()``.

    Examples
    --------
    Basic setup::

        from silk.optimize import Optimizer

        opt = Optimizer(test, space)
        opt.add_objective('gain_dB',      minimize=False)
        opt.add_objective('power_uW',     minimize=True)
        opt.add_constraint('phase_margin', min=45.0)
        opt.add_constraint('power_uW',     max=500.0)

        # Single evaluation
        record = opt.evaluate({'w_n': 2.0, 'l': 0.3})
        print(record['status'], record['metrics'], record['feasible'])

        # DOE sweep — continues through failures
        history = opt.sweep(n=50, method='lhs', corner='tt')
        successes = [r for r in history if r['status'] == 'success']
    """

    def __init__(self, test: PyModuleTest, space: ParameterSpace) -> None:
        self.test  = test
        self.space = space

        self._objectives:  Dict[str, Dict]   = {}
        self._constraints: Dict[str, Dict]   = {}
        self._history:     List[Dict]        = []

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def add_objective(self, name: str, minimize: bool = True) -> 'CircuitOptimizer':
        """Designate a metric as an optimization objective.

        Parameters
        ----------
        name : str
            Must match a metric name registered via
            ``test.add_metric(name, extractor)``.
        minimize : bool
            ``True``  to minimize (e.g. power, settling time).
            ``False`` to maximize (e.g. gain, bandwidth).

        Returns
        -------
        self — for method chaining.
        """
        self._objectives[name] = {'minimize': minimize}
        return self

    def add_constraint(
        self,
        name: str,
        min: Optional[float] = None,
        max: Optional[float] = None,
    ) -> 'CircuitOptimizer':
        """Add a feasibility constraint on a metric.

        A point is feasible only when *all* constraints are satisfied.
        Constraints are checked after a successful simulation; failed
        evaluations are marked ``feasible=None``.

        Parameters
        ----------
        name : str
            Metric name to constrain.
        min : float, optional
            Lower bound (inclusive).  ``None`` means unbounded below.
        max : float, optional
            Upper bound (inclusive).  ``None`` means unbounded above.

        Returns
        -------
        self — for method chaining.
        """
        self._constraints[name] = {'min': min, 'max': max}
        return self

    # ------------------------------------------------------------------
    # Single evaluation
    # ------------------------------------------------------------------

    def evaluate(self, point: Dict[str, Any], corner: str = 'tt') -> Dict:
        """Apply *point*, run the testbench, and return a logged record.

        Always appends to :attr:`history` — regardless of success or
        failure — with a unique ``status`` tag for later filtering.

        Parameters
        ----------
        point : dict
            ``{variable_name: value}`` mapping.  Will be applied to the
            ParameterSpace (and through it, to the circuit's device
            parameters).
        corner : str
            Process corner forwarded to ``PyModuleTest.run()``.

        Returns
        -------
        dict
            Record with keys:

            ``id``         Monotonically increasing evaluation index.
            ``params``     Copy of *point*.
            ``corner``     Corner used.
            ``status``     One of the failure-taxonomy strings above.
            ``metrics``    Dict of metric values, or ``None`` on early failure.
            ``feasible``   ``True``/``False`` for successes; ``None`` otherwise.
            ``error``      Error message string, or ``None``.
            ``error_type`` Exception class name, or ``None``.
            ``timestamp``  Unix timestamp at evaluation start.
        """
        record: Dict[str, Any] = {
            'id':         len(self._history),
            'params':     dict(point),
            'corner':     corner,
            'status':     None,
            'metrics':    None,
            'feasible':   None,
            'error':      None,
            'error_type': None,
            'timestamp':  time.time(),
        }

        # Step 1 — apply parameters
        try:
            self.space.apply(point)
        except (KeyError, ValueError) as exc:
            record['status']     = 'parameter_error'
            record['error']      = str(exc)
            record['error_type'] = type(exc).__name__
            self._history.append(record)
            return record

        # Step 2 — run simulation and extract metrics
        try:
            result = self.test.run(corner=corner)
            metrics = result['metrics']
        except SimulationError as exc:
            record['status']     = 'simulation_failure'
            record['error']      = str(exc)
            record['error_type'] = 'SimulationError'
            self._history.append(record)
            return record
        except PyNetlistError as exc:
            record['status']     = 'netlist_error'
            record['error']      = str(exc)
            record['error_type'] = type(exc).__name__
            self._history.append(record)
            return record
        except Exception as exc:
            # Unexpected error — still log it uniquely
            record['status']     = 'unexpected_error'
            record['error']      = str(exc)
            record['error_type'] = type(exc).__name__
            self._history.append(record)
            return record

        # Step 3 — detect metric extraction failures
        # PyModuleTest stores "Error: ..." strings for failed extractors
        failed = {k: v for k, v in metrics.items()
                  if isinstance(v, str) and v.startswith('Error:')}
        if failed:
            record['status']     = 'metric_error'
            record['metrics']    = metrics
            record['error']      = '; '.join(f"{k}: {v}" for k, v in failed.items())
            record['error_type'] = 'MetricExtractionError'
            self._history.append(record)
            return record

        # Step 4 — success: check feasibility
        record['status']   = 'success'
        record['metrics']  = metrics
        record['feasible'] = self._check_feasible(metrics)
        self._history.append(record)
        return record

    # ------------------------------------------------------------------
    # Batch sweep
    # ------------------------------------------------------------------

    def sweep(
        self,
        n: int,
        method: str = 'lhs',
        corner: str = 'tt',
        max_failures: Optional[int] = None,
    ) -> List[Dict]:
        """Evaluate *n* jointly sampled design points.

        Continues through failures by default.  Set *max_failures* to
        abort early if too many consecutive problems occur — useful when
        a bad region of parameter space causes systematic ngspice crashes.

        Parameters
        ----------
        n : int
            Number of design points (for ``method='grid'`` this is
            points per variable — see :meth:`ParameterSpace.sample`).
        method : str
            Sampling method passed to :meth:`ParameterSpace.sample`.
        corner : str
            Process corner for every evaluation.
        max_failures : int, optional
            Stop the sweep early if the cumulative failure count across
            all status types reaches this limit.  ``None`` (default)
            means run all *n* points regardless of failures.

        Returns
        -------
        list of dict
            The records added during this sweep (subset of
            :attr:`history`).  May be shorter than *n* if *max_failures*
            was reached.
        """
        points   = self.space.sample(n, method=method)
        records: List[Dict] = []
        failures = 0

        for pt in points:
            rec = self.evaluate(pt, corner=corner)
            records.append(rec)
            if rec['status'] != 'success':
                failures += 1
                if max_failures is not None and failures >= max_failures:
                    break

        return records

    # ------------------------------------------------------------------
    # Feasibility
    # ------------------------------------------------------------------

    def feasible(self, metrics: Dict[str, Any]) -> bool:
        """Return ``True`` if *metrics* satisfies all declared constraints."""
        return self._check_feasible(metrics)

    def _check_feasible(self, metrics: Dict[str, Any]) -> bool:
        for name, bounds in self._constraints.items():
            val = metrics.get(name)
            if val is None or isinstance(val, str):
                return False  # missing or errored metric → infeasible
            if bounds['min'] is not None and val < bounds['min']:
                return False
            if bounds['max'] is not None and val > bounds['max']:
                return False
        return True

    # ------------------------------------------------------------------
    # History accessors
    # ------------------------------------------------------------------

    @property
    def history(self) -> List[Dict]:
        """All evaluation records in chronological order."""
        return self._history

    @property
    def successes(self) -> List[Dict]:
        """Records with ``status == 'success'``."""
        return [r for r in self._history if r['status'] == 'success']

    @property
    def failures(self) -> List[Dict]:
        """Records with any non-success status."""
        return [r for r in self._history if r['status'] != 'success']

    @property
    def best(self) -> Optional[Dict]:
        """Best feasible record by the first declared objective.

        Returns ``None`` if no feasible successes exist yet or no
        objective has been declared.
        """
        if not self._objectives:
            return None
        obj_name, obj_cfg = next(iter(self._objectives.items()))
        candidates = [r for r in self.successes if r.get('feasible')]
        if not candidates:
            return None
        return min(candidates,
                   key=lambda r: (r['metrics'][obj_name]
                                  if obj_cfg['minimize']
                                  else -r['metrics'][obj_name]))

    def summary(self) -> Dict[str, Any]:
        """Return a summary dict of the optimization run so far."""
        total    = len(self._history)
        by_status: Dict[str, int] = {}
        for r in self._history:
            by_status[r['status']] = by_status.get(r['status'], 0) + 1
        return {
            'total_evaluations': total,
            'by_status':         by_status,
            'feasible_count':    sum(1 for r in self.successes if r.get('feasible')),
            'best':              self.best,
        }

    # ------------------------------------------------------------------
    # AI / surrogate interface
    # ------------------------------------------------------------------

    def to_ai_context(self) -> Dict[str, Any]:
        """Return structured context for an AI optimizer or surrogate model.

        The returned dict contains everything an LLM or agent needs to
        suggest the next parameter point:

        - ``variables``   : bounds, type, distribution per variable
        - ``objectives``  : name → minimize/maximize
        - ``constraints`` : name → min/max bounds
        - ``history``     : recent evaluation records (params + metrics + status)
        - ``best``        : best feasible point so far
        - ``summary``     : counts by status

        Pass this to an AI agent as structured input::

            ctx       = opt.to_ai_context()
            suggested = ai_agent.suggest(ctx)   # {name: value} dict
            record    = opt.evaluate(suggested)
        """
        return {
            'variables': {
                name: {
                    'bounds':       var.bounds,
                    'var_type':     var.var_type,
                    'distribution': var.distribution,
                    'current_value': var.value,
                }
                for name, var in self.space._vars.items()
            },
            'objectives':  dict(self._objectives),
            'constraints': dict(self._constraints),
            'history':     [
                {k: r[k] for k in ('id', 'params', 'corner', 'status',
                                   'metrics', 'feasible')}
                for r in self._history
            ],
            'best':    self.best,
            'summary': self.summary(),
        }

    def to_training_data(self) -> Tuple[List[List], List[List]]:
        """Return ``(X, y)`` from successful evaluations for surrogate modeling.

        X : list of lists (one row per success, columns in ``space.names`` order)
        y : list of lists (one row per success, columns in objective name order)

        If numpy is available the lists are converted to ``numpy.ndarray``.

        Only successful evaluations are included; failures are excluded.
        Use ``history`` directly if you need failure data.
        """
        obj_names = list(self._objectives.keys())
        var_names = self.space.names

        X_rows = []
        y_rows = []
        for r in self.successes:
            X_rows.append([r['params'].get(n) for n in var_names])
            y_rows.append([r['metrics'].get(n) for n in obj_names])

        try:
            import numpy as np
            return np.array(X_rows, dtype=float), np.array(y_rows, dtype=float)
        except ImportError:
            return X_rows, y_rows

# Backward-compat alias
CircuitOptimizer = Optimizer
