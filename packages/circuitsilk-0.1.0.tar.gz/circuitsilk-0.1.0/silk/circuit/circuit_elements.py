# Python based circuit element manager
# Created by Manar El-Chammas
# Shared functionality for managing circuit elements between PyModule and PyNetlist
# This includes devices, nets, and module instantiation

import copy
from enum import Enum

from silk.exceptions import PyNetlistError, DuplicateNameError, UndeclaredNetError, SimulationError, PDKError
from silk.elements.base import AnalogElement


class ElementType(str, Enum):
    DEVICE = 'd'
    MODULE = 'm'
    PRIMITIVE = 'p'


class PyCircuitElements:
    """Manages circuit elements (devices, nets, modules) - shared between PyModule and PyNetlist"""

    def __init__(self, pdkDetails, debug=False, strict_nets=False):
        self.pdkDetails = pdkDetails
        self.debug = debug
        self.strict_nets = strict_nets

        # Element storage
        self.elem_dict = {}  # Dictionary of all elements
        self.net_dict = {}  # Dictionary of all nets
        self.module_dict = {}  # Dictionary of all modules (subcircuit definitions)

        # Type lists
        self.moduleNames = ['module']
        self.primitiveNames = []

    def addElement(self, elemDevice, elemName, nets=None, parameters=None):  # noqa: C901
        """Add element to circuit.

        Args:
            elemDevice: Device class (new-style), device instance (new-style),
                        PDKDevice (old-style), or PyModule to add.
            elemName: Unique name for this instance.
            nets: Dictionary or list of net connections.
            parameters: Dictionary or list of parameter values.
        """
        # Check if name already exists
        if elemName in self.elem_dict.keys():
            raise DuplicateNameError(f'ERROR: Name {elemName} already exists in netlist')

        # ------------------------------------------------------------------
        # Three-way detection: new-style class, new-style instance, old-style
        # ------------------------------------------------------------------

        if isinstance(elemDevice, type) and issubclass(elemDevice, AnalogElement):
            # New-style: elemDevice IS the class (e.g. addElement(pdk.nmos1p8, ...))
            # Build a PDKDevice proxy from the internal _devices dict for
            # backward-compat SPICE generation via generateNetlistEntry.
            elemType = elemDevice._device_type_name
            if elemType not in self.pdkDetails.modelNames:
                raise PyNetlistError(
                    f'ERROR: Device {elemType!r} not found in PDK.'
                )
            # Deepcopy the internal PDKDevice (not the class)
            new_device = copy.deepcopy(self.pdkDetails._devices[elemType])
            element = {
                'type': ElementType.DEVICE,
                'device': new_device,
                'typeName': elemType,
                '_new_style': False,   # uses old generateNetlistEntry path
            }
            self.elem_dict[elemName] = element
            # Apply nets and parameters via existing methods
            if nets is not None:
                _apply_connections(self, elemName, nets)
            if parameters is not None:
                _apply_parameters(self, elemName, parameters)
            return

        if isinstance(elemDevice, AnalogElement):
            # New-style: elemDevice is already an instance
            # Store directly — spice_netlister calls instance.to_spice()
            self._add_analog_element(elemDevice)
            return

        # ------------------------------------------------------------------
        # Old-style path (PDKDevice / PyModule) — unchanged
        # ------------------------------------------------------------------

        elemType = elemDevice.device_name

        if elemType in self.pdkDetails.modelNames:
            if self.debug:
                print('Element Name found in pdk')
            entryType = ElementType.DEVICE
        elif elemType in self.moduleNames:
            if self.debug:
                print('Element Name found in custom module list')
            entryType = ElementType.MODULE

            # Track module definitions
            if elemDevice.module_name not in self.module_dict.keys():
                self.module_dict[elemDevice.module_name] = {
                    'device': copy.deepcopy(elemDevice),
                    'defined': False,
                    'numberInstantiated': 1
                }
            else:
                self.module_dict[elemDevice.module_name]['numberInstantiated'] += 1

        elif elemType in self.primitiveNames:
            if self.debug:
                print('Element Name found in primitive list')
            entryType = ElementType.PRIMITIVE
        else:
            raise PyNetlistError(f'ERROR: Element name not found in PDK. Please create {elemName} before adding it to the netlist.')

        # Get original device and copy it
        if entryType == ElementType.DEVICE:
            original_device = self.pdkDetails._devices.get(elemType)
            if original_device is None:
                # Fallback: getattr on PDK (handles edge cases)
                original_device = getattr(self.pdkDetails, elemType)
        elif entryType == ElementType.MODULE:
            original_device = elemDevice

        new_device = copy.deepcopy(original_device)

        # Create element entry
        element = {
            'type': entryType,
            'device': new_device,
            'typeName': new_device.device_name
        }

        # Get pins and parameters
        if element['type'] == ElementType.DEVICE:
            pins = new_device.pin_list
            params = new_device.param_list
        elif element['type'] == ElementType.MODULE:
            pins = new_device.pin_list
            params = []

        if self.debug:
            print(element)

        self.elem_dict[elemName] = element

        # Handle net connections
        if nets is not None:
            _apply_connections(self, elemName, nets)

        # Handle parameters
        if parameters is not None:
            _apply_parameters(self, elemName, parameters)

    def _add_analog_element(self, device: AnalogElement):
        """Store a factory-created AnalogElement instance in elem_dict.

        Called by :meth:`add` and by :meth:`addElement` when passed an instance.
        SPICE generation uses ``instance.to_spice()`` directly.
        """
        name = device.name
        if name in self.elem_dict:
            raise DuplicateNameError(f'ERROR: Name {name!r} already exists in netlist')

        # Register nets
        for pin in device._pin_names:
            net = device.nets.get(pin)
            if net:
                if net not in self.net_dict:
                    if self.strict_nets:
                        raise UndeclaredNetError(
                            f'ERROR: net "{net}" is not declared. '
                            f'Call addNet("{net}") before connecting it.'
                        )
                    self.addNet(net)

        self.elem_dict[name] = {
            'type': ElementType.DEVICE,
            'device': device,
            'typeName': device._device_type_name,
            '_new_style': True,
        }

    def addNet(self, netname, parameters=[]):
        """Add net name to circuit. Parameters can be things like max and min voltage"""
        if netname in self.net_dict.keys():
            if self.debug:
                print(f'Net {netname} already exists. No need to re-add it.')
            return

        self.net_dict[netname] = parameters

    def connectElement(self, elemName, pins, nets, _skipCheck=False):
        """Connect defined element to a set of nets

        Args:
            elemName: Name of element to connect
            pins: List of pin names
            nets: List of net names (must match length of pins)
            _skipCheck: Internal flag to skip existence check
        """
        if elemName not in self.elem_dict.keys() and not _skipCheck:
            raise PyNetlistError('ERROR: Element does not exist. Run addElement first.')

        # Get element info
        elemType = self.elem_dict[elemName]['type']
        typeName = self.elem_dict[elemName]['typeName']
        elemDevice = self.elem_dict[elemName]['device']

        if elemType == ElementType.DEVICE:
            pinlist = elemDevice.pin_list
        elif elemType == ElementType.MODULE:
            pinlist = elemDevice.pin_list
        else:
            print('This part is not complete yet.')
            return

        # Connect pins to nets
        for idx, p in enumerate(pins):
            # Add net if it doesn't exist
            if nets[idx] not in self.net_dict.keys():
                if self.strict_nets:
                    raise UndeclaredNetError(
                        f'ERROR: net "{nets[idx]}" is not declared. '
                        f'Call addNet("{nets[idx]}") before connecting it, '
                        f'or use strict_nets=False to allow automatic net registration.'
                    )
                self.addNet(nets[idx])
                if self.debug:
                    print(f'WARNING: net {nets[idx]} is undefined. addNet has been run in the background.')

            # Check pin exists
            if p not in pinlist.keys():
                raise PyNetlistError(f'ERROR: Pin {p} is not in defined pins for element {elemName}')

            # Make the connection
            pinlist[p].net = nets[idx]

        elemDevice.pin_list = pinlist
        self.elem_dict[elemName]['device'] = elemDevice

    def updateElement(self, elemName, params, paramValues, _skipCheck=False):
        """Update parameter values in element

        Args:
            elemName: Name of element to update
            params: List of parameter names
            paramValues: List of parameter values (must match length of params)
            _skipCheck: Internal flag to skip existence check
        """
        if elemName not in self.elem_dict.keys() and not _skipCheck:
            raise PyNetlistError('ERROR: Element does not exist. Run addElement first.')

        if len(params) != len(paramValues):
            raise PyNetlistError(f'ERROR: params length ({len(params)}) does not match paramValues length ({len(paramValues)})')

        # Get element info
        entry = self.elem_dict[elemName]
        elemType = entry['type']
        elemDevice = entry['device']

        # New-style AnalogElement instance — update params dict directly
        if entry.get('_new_style'):
            for idx, p in enumerate(params):
                elemDevice.params[p] = paramValues[idx]
            return

        if elemType == ElementType.DEVICE:
            pass  # fall through to old-style logic below
        else:
            print('This part is not complete yet.')
            return

        tempParams = elemDevice.param_list

        # Import ModuleVariable here to avoid circular import
        from silk.circuit.modules import ModuleVariable

        for idx, p in enumerate(params):
            # Check if value is already a ModuleVariable or needs to be wrapped
            if isinstance(paramValues[idx], (int, float)):
                modVar = ModuleVariable(name=p)
                modVar.value = paramValues[idx]
            else:
                modVar = paramValues[idx]

            tempParams[p].value = modVar

        elemDevice.param_list = tempParams
        self.elem_dict[elemName]['device'] = elemDevice


# ---------------------------------------------------------------------------
# Module-level helpers used by addElement
# ---------------------------------------------------------------------------

def _apply_connections(circuit, elemName, nets):
    """Apply net connections to a newly-added element.

    ``nets`` may be:
    - a dict ``{pin: net}``
    - a list of ``(pin, net)`` tuples
    - a positional list ``[net, net, ...]`` matched by pin_list order
    """
    elemDevice = circuit.elem_dict[elemName]['device']

    if isinstance(nets, dict):
        pins = list(nets.keys())
        net_values = list(nets.values())
    elif nets and isinstance(nets[0], (tuple, list)):
        # List of (pin, net) tuples
        pins = [p for p, n in nets]
        net_values = [n for p, n in nets]
    else:
        # Positional list — match by pin_list order
        pins = list(elemDevice.pin_list.keys())
        net_values = list(nets)

    circuit.connectElement(elemName, pins, net_values, _skipCheck=True)


def _apply_parameters(circuit, elemName, parameters):
    """Apply parameter values to a newly-added element.

    ``parameters`` may be:
    - a dict ``{param: value}``
    - a list of ``(param, value)`` tuples
    - a positional list ``[value, value, ...]`` matched by param_list order
    """
    elemDevice = circuit.elem_dict[elemName]['device']

    if isinstance(parameters, dict):
        params = list(parameters.keys())
        param_values = list(parameters.values())
    elif parameters and isinstance(parameters[0], (tuple, list)):
        # List of (param, value) tuples
        params = [p for p, v in parameters]
        param_values = [v for p, v in parameters]
    else:
        params = list(elemDevice.param_list.keys())
        param_values = list(parameters)

    circuit.updateElement(elemName, params, param_values, _skipCheck=True)