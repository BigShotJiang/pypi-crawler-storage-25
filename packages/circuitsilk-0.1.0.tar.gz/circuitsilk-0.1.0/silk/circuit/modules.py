# Module class - UPDATED VERSION
# This includes the devices in the module
# It should also allow for defined verification tasks, constraints, etc.

import os
import copy
import math
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple, Union
from silk.circuit.circuit_elements import PyCircuitElements, ElementType
# PyModuleTest is imported lazily in create_test() to avoid circular imports
from silk.circuit.spice_netlister import PySpiceNetlister
from silk.exceptions import PyNetlistError, DuplicateNameError, UndeclaredNetError, SimulationError, PDKError


class VarType:
    CONTINUOUS   = 'continuous'
    INTEGER      = 'integer'
    CATEGORICAL  = 'categorical'


class Distribution:
    UNIFORM      = 'uniform'
    LOG_UNIFORM  = 'log_uniform'
    NORMAL       = 'normal'


class Module():

    def __init__(self, PDKname, dirFolder, netlistname, pdkDetails, debug=False, strict_nets=False):
        self.PDKname = PDKname
        self.netlistname = dirFolder + '/' + netlistname
        self.dirFolder = dirFolder
        self.debug = debug

        self.device_name = 'module'  # This is for the addElement in pyNetlist

        # This is used for instantiation in the netlist
        self.module_name = None
        self.pin_list = None

        # Load PDK details
        self.pdkDetails = pdkDetails

        # ===== NEW: Use PyCircuitElements for element management =====
        self._element_mgr = PyCircuitElements(pdkDetails, debug=debug, strict_nets=strict_nets)

        # Expose element manager's dictionaries for backward compatibility
        self.elem_dict = self._element_mgr.elem_dict
        self.net_dict = self._element_mgr.net_dict
        self.module_dict = self._element_mgr.module_dict
        self.moduleNames = self._element_mgr.moduleNames
        self.primitiveNames = self._element_mgr.primitiveNames
        # ============================================================

        # NEW: Create netlister for SPICE generation
        self.netlister = PySpiceNetlister(pdkDetails)

        self.passives_dict = {}  # Dictionary of passive elements (R, C, L)

        self.outputFileAvailable = False
        self.simResultsLoaded = False
        self.sim_xaxis_values = ['time', 'frequency']
        self.customList_list = []

        # Simulation state (populated when Module is used as top-level netlist)
        self.sigSources_dict = {}
        self.simAnalysis_dict = {}
        self.simAnalysis_types = ['transient', 'ac', 'dc']
        self.simulator = 'ngspice'
        self.resultsFile = None
        self._runner = None
        self.circuit_name = None
        self.strict_nets = strict_nets

        # ===== NEW: Test management =====
        self._tests = {}  # Dictionary of test_name -> PyModuleTest
        # ================================

    def defineModuleName(self, name: str):
        self.module_name = name

    def defineModuleNets(self, pin_dict):
        if self.pin_list is None:
            self.pin_list = {}
        for p, direction in pin_dict.items():
            self.pin_list[p] = ModulePin(name=p, direction=direction)

    # ===== UPDATED: Delegate to PyCircuitElements =====
    def add(self, *devices):
        """Add one or more factory-created AnalogElement instances to the module."""
        for device in devices:
            self._element_mgr._add_analog_element(device)

    def addElement(self, elemDevice, elemName, nets=None, parameters=None):
        """Add element to module - delegates to PyCircuitElements"""
        return self._element_mgr.addElement(elemDevice, elemName, nets, parameters)

    def addNet(self, netname, parameters=[]):
        """Add net to module."""
        if netname in self.net_dict:
            print(f'Note: net {netname} already exists, skipping.')
            return
        self._element_mgr.addNet(netname, parameters)

    def connectElement(self, elemName, pins, nets, _skipCheck=False):
        """Connect element to nets - delegates to PyCircuitElements"""
        return self._element_mgr.connectElement(elemName, pins, nets, _skipCheck)

    def updateElement(self, elemName, params, paramValues, _skipCheck=False):
        """Update element parameters - delegates to PyCircuitElements"""
        return self._element_mgr.updateElement(elemName, params, paramValues, _skipCheck)

    def addPassive(self, passive):
        """Add a passive element (Resistor, Capacitor, or Inductor) to the module.

        Args:
            passive: A PassiveBase instance from silk.elements.passives
                     (Resistor, Capacitor, or Inductor)
        """
        from silk.elements.passives import PassiveBase
        if not isinstance(passive, PassiveBase):
            raise PyNetlistError(
                'ERROR: addPassive() requires a PassiveBase instance (Resistor, Capacitor, or Inductor). '
                f'Got {type(passive).__name__}.'
            )

        if passive.name in self.passives_dict:
            raise DuplicateNameError(f'ERROR: Passive element name "{passive.name}" already exists in module.')

        # Register nets (raise if strict_nets is True and net not declared)
        for net in (passive.pos, passive.neg):
            if net not in self.net_dict:
                if self.strict_nets:
                    raise UndeclaredNetError(
                        f'ERROR: net "{net}" is not declared. '
                        f'Call addNet("{net}") before adding a passive that references it.'
                    )
                self.net_dict[net] = []

        self.passives_dict[passive.name] = passive

    # ==================================================

    # ===== Simulation methods (used when Module is a top-level netlist) =====

    def addSource(self, source):
        """Add a voltage/current source to the circuit."""
        from silk.sources import SourceBase
        if not isinstance(source, SourceBase):
            raise PyNetlistError(
                f'addSource() requires a SourceBase instance. Got {type(source).__name__}.'
            )
        name = source.name
        if name in self.sigSources_dict:
            raise DuplicateNameError(f'Source name "{name}" already exists.')
        for net in self._source_nets(source):
            if net not in self.net_dict:
                if self.strict_nets:
                    raise UndeclaredNetError(f'net "{net}" not declared.')
                self.net_dict[net] = []
        self.sigSources_dict[name] = source
        if self.debug:
            print(f'Added source: {type(source).__name__} "{name}"')

    def _source_nets(self, source):
        """Return all net names referenced by a source."""
        from silk.sources import (VoltageSource, CurrentSource,
                                   VoltageControlledVoltageSource, VoltageControlledCurrentSource,
                                   CurrentControlledVoltageSource, CurrentControlledCurrentSource,
                                   BehavioralVoltage, BehavioralCurrent)
        if isinstance(source, (VoltageSource, CurrentSource, BehavioralVoltage, BehavioralCurrent)):
            return [source.positive, source.negative]
        elif isinstance(source, (VoltageControlledVoltageSource, VoltageControlledCurrentSource)):
            return [source.out_pos, source.out_neg, source.ctrl_pos, source.ctrl_neg]
        elif isinstance(source, (CurrentControlledVoltageSource, CurrentControlledCurrentSource)):
            return [source.out_pos, source.out_neg]
        return []

    def addSimType(self, simType, details=None):
        """Set the simulation type and parameters."""
        from silk.simulation.analysis import AnalysisBase
        if isinstance(simType, AnalysisBase):
            type_key = type(simType).__name__.lower()
            self.simAnalysis_dict[type_key] = simType
            return
        if self.debug:
            print(f'Simulation type = {simType}, with details = {details}')
        if simType not in self.simAnalysis_types:
            raise PyNetlistError(f'Unknown simulation type {simType!r}.')
        if len(details) != len(self.getSimTypeDetails(simType)):
            raise PyNetlistError('Incorrect number of simulation details.')
        self.simAnalysis_dict[simType] = {}
        for idx, d in enumerate(self.getSimTypeDetails(simType)):
            self.simAnalysis_dict[simType][d] = details[idx]

    def getSimTypeDetails(self, simType):
        if simType == 'transient':
            return ['tstep', 'tstop']

    def addCustomLine(self, line):
        """Add a raw SPICE line to the netlist."""
        self.customList_list.append(line)

    def netlistHeader(self, header):
        """Set an optional netlist header comment (overwrites this attribute)."""
        self.netlistHeader = header

    def updateNet(self, netname, parameters=[]):
        """Update a net's parameters."""
        if netname not in self.net_dict:
            raise PyNetlistError(f'Net "{netname}" does not exist.')
        self.net_dict[netname] = parameters

    def printElements(self):
        """Print all defined elements."""
        print(f'Elements ({len(self.elem_dict)} devices, {len(self.sigSources_dict)} sources):')
        for k, v in self.elem_dict.items():
            type_name = v.get('typeName', v.get('type', '?')) if isinstance(v, dict) else type(v).__name__
            print(f'  [{type_name}] {k}')
        for k, v in self.sigSources_dict.items():
            src_type = type(v).__name__
            nets = []
            if hasattr(v, 'positive') and hasattr(v, 'negative'):
                nets = [v.positive, v.negative]
            elif hasattr(v, 'out_pos') and hasattr(v, 'out_neg'):
                nets = [v.out_pos, v.out_neg]
            print(f'  [{src_type}] {k}  nets={nets}')

    def printNets(self):
        """Print all defined nets."""
        net_names = list(self.net_dict.keys())
        print(f'Nets ({len(net_names)}): {", ".join(net_names)}')

    def getOutputSignalList(self):
        """Print available output signals (requires simulation results loaded)."""
        if not self.outputFileAvailable:
            raise SimulationError('File not loaded. Run loadFile first.')
        print('List of signals')

    def updateSource(self, sourceName, params, paramValues, _skipCheck=False):
        """Update source parameters (supports both SourceBase and legacy dict sources)."""
        if sourceName not in self.sigSources_dict and not _skipCheck:
            raise PyNetlistError(f'Source "{sourceName}" does not exist.')
        source = self.sigSources_dict[sourceName]
        _SOURCE_PARAMS = ['dc', 'ac', 'pwl', 'pulse', 'sine']
        if isinstance(source, dict):
            # Legacy dict-based source
            src_params = source.get('params', [None] * len(_SOURCE_PARAMS))
            for p, v in zip(params, paramValues):
                if p in _SOURCE_PARAMS:
                    src_params[_SOURCE_PARAMS.index(p)] = v
            source['params'] = src_params
        else:
            # SourceBase object
            for p, v in zip(params, paramValues):
                if hasattr(source, p):
                    setattr(source, p, v)

    def connectSource(self, sourceName, pins, nets, _skipCheck=False):
        """Connect source to nets (supports both SourceBase and legacy dict sources)."""
        if sourceName not in self.sigSources_dict and not _skipCheck:
            raise PyNetlistError(f'Source "{sourceName}" does not exist.')
        for net in nets:
            if net not in self.net_dict:
                raise UndeclaredNetError(f'Net "{net}" is undefined.')
        source = self.sigSources_dict[sourceName]
        _SOURCE_PINS = ['positive', 'negative']
        if isinstance(source, dict):
            pin_nets = source.get('pinNets', ['', ''])
            for p, net in zip(pins, nets):
                if p in _SOURCE_PINS:
                    pin_nets[_SOURCE_PINS.index(p)] = net
            source['pinNets'] = pin_nets
        else:
            for p, net in zip(pins, nets):
                if hasattr(source, p):
                    setattr(source, p, net)

    def loadFile(self, dataFile, simulatorType='ngspice'):
        self.dataFile = dataFile

    def getSignalNames(self):
        if not self.simResultsLoaded:
            raise SimulationError('Simulation results not loaded.')
        return [self.simResultsAll.vectors[i].name for i in range(self.simResultsAll.nvars)]

    def loadSignal(self, signalName, signalType='V'):
        if not self.simResultsLoaded:
            raise SimulationError('ERROR:  Simulation Results are not Loaded')
        from silk.signals.spice import NgspiceSignal as PySignal
        return PySignal.load(self.simulator, self.simResultsAll, signalName, signalType)

    def runSimulator(self, auto_track_structure=False):
        """Run ngspice on the generated netlist."""
        from silk.simulation.runner import NgspiceRunner
        self.resultsFile = self.dirFolder + '/' + 'rawfile.raw'
        self._runner = NgspiceRunner(
            netlist_path=self.netlistname,
            results_dir=self.dirFolder,
            debug=self.debug,
        )
        self._runner.run()

    def readRawFile(self):
        if not hasattr(self, '_runner') or self._runner is None:
            from silk.simulation.runner import NgspiceRunner
            self._runner = NgspiceRunner(
                netlist_path=self.netlistname,
                results_dir=self.dirFolder,
                debug=self.debug,
            )
            self._runner.rawfile_path = self.dataFile
        results = self._runner.load()
        self.simResultsAll = results
        self.simResultsLoaded = True

    def simulate(self, corner='tt', auto_track_structure=False):
        """Generate netlist, run ngspice, and load results.

        Returns self for chaining: ``sig = mod.simulate().loadSignal('vout')``
        """
        self.generateNetlist(corner=corner)
        self.runSimulator(auto_track_structure=auto_track_structure)
        self.loadFile(f'{self.dirFolder}/rawfile.raw')
        self.readRawFile()
        return self

    def variables(self):
        """Return all ModuleVariable objects bound to this circuit."""
        seen = set()
        result = []
        for entry in self._element_mgr.elem_dict.values():
            device = entry.get('device') if isinstance(entry, dict) else entry
            if hasattr(device, 'params'):
                for val in device.params.values():
                    if isinstance(val, ModuleVariable) and id(val) not in seen:
                        seen.add(id(val))
                        result.append(val)
        for src in self.sigSources_dict.values():
            for param in getattr(src.__class__, '_param_names', ()):
                val = getattr(src, param, None)
                if isinstance(val, ModuleVariable) and id(val) not in seen:
                    seen.add(id(val))
                    result.append(val)
        return result

    # ==================================================

    # ===== NEW: Test management methods =====
    def create_test(self, name='default_test'):
        """Create a new test for this module

        Args:
            name: Name for the test

        Returns:
            PyModuleTest instance that can be configured

        Example:
            test = module.create_test('transient')
            test.add_module_under_test({'vdd': 'vdd', 'gnd': '0'})
            test.addSource('voltage', 'supply', nets={'positive': 'vdd', 'negative': '0'},
                          parameters={'dc': 3.3})
            test.add_metric('avg_power', lambda nr: calculate_power(nr))
        """
        from silk.circuit.module_test import ModuleTestbench as PyModuleTest
        test = PyModuleTest(self, name)
        self._tests[name] = test
        return test

    def run_test(self, name='default_test', **config):
        """Run a specific test

        Args:
            name: Name of test to run
            **config: Additional configuration (e.g., corner='ff')

        Returns:
            Dictionary with test results and metrics
        """
        if name not in self._tests:
            raise ValueError(f"No test '{name}' for module {self.module_name}. Available: {list(self._tests.keys())}")

        test = self._tests[name]
        return test.run(**config)

    def run_all_tests(self, recursive=True, **config):
        """Run all tests for this module and optionally submodules

        Args:
            recursive: If True, also run tests on submodules
            **config: Additional configuration passed to tests

        Returns:
            Dictionary mapping test names to results
        """
        results = {}

        # Run this module's tests
        for test_name, test in self._tests.items():
            print(f"\n{'=' * 60}")
            print(f"Running test: {self.module_name}.{test_name}")
            print(f"{'=' * 60}")
            try:
                results[f"{self.module_name}.{test_name}"] = test.run(**config)
                print(f"✓ Test {test_name} completed successfully")
            except Exception as e:
                print(f"✗ Test {test_name} failed: {e}")
                results[f"{self.module_name}.{test_name}"] = {'error': str(e)}

        # Recursively test submodules
        if recursive:
            for module_name, module_info in self.module_dict.items():
                submodule = module_info['device']
                if isinstance(submodule, PyModule) and submodule.has_tests():
                    print(f"\n--- Testing submodule: {module_name} ---")
                    sub_results = submodule.run_all_tests(recursive=True, **config)
                    results.update(sub_results)

        return results

    def list_tests(self):
        """List all tests registered for this module"""
        return list(self._tests.keys())

    def has_tests(self):
        """Check if this module has any tests"""
        return len(self._tests) > 0

    def get_all_testable_modules(self, include_self=True):
        """Get list of all modules (including submodules) that have tests

        Args:
            include_self: Whether to include this module in the list

        Returns:
            List of dictionaries with module info and test names
        """
        testable = []

        if include_self and self.has_tests():
            testable.append({
                'module': self.module_name,
                'tests': self.list_tests()
            })

        # Check submodules
        for module_name, module_info in self.module_dict.items():
            submodule = module_info['device']
            if isinstance(submodule, PyModule):
                testable.extend(submodule.get_all_testable_modules(include_self=True))

        return testable

    # ========================================

    def generateSubckt(self, whichLine):
        """Generate subcircuit definition line"""
        if whichLine == 0:
            strsubckt = '.subckt ' + self.module_name + ' '
            for p in self.pin_list:
                strsubckt += p + ' '
        else:
            strsubckt = '.ends'
        return strsubckt + '\n'

    def generateNetlist(self, corner='tt', subckt=None):
        """Generate SPICE netlist.

        If ``module_name`` is set, generates a ``.subckt`` block and returns
        the SPICE string without writing to disk (subcircuit mode).

        If ``module_name`` is None, generates a complete top-level simulation
        netlist, writes it to ``self.netlistname``, and returns None.

        Parameters
        ----------
        corner : str
            Process corner (used only in top-level mode).
        """
        # subckt kwarg: explicit True/False overrides auto-detect
        # subckt=None (default) → auto-detect via module_name
        is_subckt = (subckt is True) or (subckt is None and self.module_name is not None)
        if subckt is False and self.module_name is not None:
            raise ValueError(
                "Module.generateNetlist(subckt=False) is not valid when module_name is set. "
                "Use generateNetlist() or generateNetlist(subckt=True) for subcircuit mode."
            )

        if is_subckt:
            # Subcircuit mode — return .subckt string
            str_module = self.netlister.generate_module_definitions(self.module_dict)
            str_module += self.generateSubckt(0)
            str_module += self.netlister.generate_device_instances(self.elem_dict)
            str_module += self.netlister.generate_passives(self.passives_dict)
            str_module += self.generateSubckt(1)
            return str_module
        else:
            # Top-level simulation mode — write to file
            circuit_name = self.circuit_name or self.netlistname.split('/')[-1]
            netlist_content = self.netlister.generate_complete_netlist(
                circuit_name=circuit_name,
                corner=corner,
                module_dict=self.module_dict,
                elem_dict=self.elem_dict,
                sigSources_dict=self.sigSources_dict,
                SigSourceDetails=None,
                simAnalysis_dict=self.simAnalysis_dict,
                customList_list=self.customList_list,
                dirFolder=self.dirFolder,
                passives_dict=self.passives_dict,
            )
            with open(self.netlistname, 'w') as f:
                f.write(netlist_content)
            return None

    def generateNetlistEntry(self, instanceName):
        """Generate the instantiation line for this module"""
        str_entry = 'x' + instanceName + ' '
        device = self
        pin_list = device.pin_list

        for p in pin_list:
            if pin_list[p].net == None:
                raise PyNetlistError('ERROR: In module instantiation {}, net for pin {} is undefined'.format(instanceName, p))
            str_entry += pin_list[p].net + ' '

        str_entry += device.module_name + '\n'
        return str_entry

    def export_schema(self) -> dict:
        """Return a JSON-serialisable schema for this module's external interface.

        Includes port names, directions, and device instance names.
        Suitable for GUI canvas rendering and code generation.

        Returns
        -------
        dict
            See :func:`silk.elements.schema.module_schema` for format.

        Example::

            ldo.defineModuleName('ldo')
            ldo.defineModuleNets({'vin': 'input', 'vout': 'output'})
            schema = ldo.export_schema()
            print(json.dumps(schema, indent=2))
        """
        from silk.elements.schema import module_schema
        return module_schema(self)


@dataclass
class ModulePin:
    name: str
    net: Optional[str] = None
    direction: Optional[str] = None   # 'input' | 'output' | 'inout' | None


class ModuleVariable():
    """Represents a circuit variable that can be shared between components.

    Parameters
    ----------
    name : str
        Parameter name (used in SPICE .param lines).
    value : float, optional
        Nominal / initial value.
    range : float, optional
        Legacy half-width range (kept for backward compatibility).
    bounds : tuple (min, max), optional
        Hard bounds for the parameter.  Required for sample() and validate().
    var_type : str, optional
        One of VarType.CONTINUOUS (default), VarType.INTEGER, VarType.CATEGORICAL.
    distribution : str, optional
        Sampling distribution — Distribution.UNIFORM (default), LOG_UNIFORM, or NORMAL.
    step : float, optional
        Grid step size used by the 'grid' sampling method (sweep spacing).
    resolution : float, optional
        Manufacturing / simulation grid — the smallest increment the parameter
        can take.  When set and enforce_resolution=True, all sampled and
        assigned values are snapped to the nearest valid grid point.
        Example: resolution=0.005 for Sky130 µm dimensions.
    enforce_resolution : bool, optional
        If False the resolution is stored for documentation but not applied,
        allowing continuous optimisers to work without snapping.  Default True.
    categories : list, optional
        Allowed values when var_type=VarType.CATEGORICAL.
    """

    def __init__(
        self,
        name: str,
        value: Optional[float] = None,
        range: Optional[float] = None,
        *,
        bounds: Optional[Tuple[float, float]] = None,
        var_type: str = VarType.CONTINUOUS,
        distribution: str = Distribution.UNIFORM,
        step: Optional[float] = None,
        resolution: Optional[float] = None,
        enforce_resolution: bool = True,
        categories: Optional[List] = None,
    ):
        self.name               = name
        self.range              = range
        self.bounds             = bounds
        self.var_type           = var_type
        self.distribution       = distribution
        self.step               = step
        self.resolution         = resolution
        self.enforce_resolution = enforce_resolution
        self.categories         = categories
        self.sweep_values = None
        self.sweep_index  = 0
        self._value       = value

    def __repr__(self):
        return f"Variable(name='{self.name}', value={self.value})"

    # ------------------------------------------------------------------
    # value property — unchanged semantics, backward-compatible
    # ------------------------------------------------------------------

    @property
    def value(self) -> Optional[float]:
        """Return current value, either static or from sweep."""
        if self.sweep_values is not None:
            return self.sweep_values[self.sweep_index]
        return self._value

    @value.setter
    def value(self, val):
        self._value = self._snap(val) if val is not None else val
        self.sweep_values = None

    # ------------------------------------------------------------------
    # Validation and clipping
    # ------------------------------------------------------------------

    def _snap(self, val: float) -> float:
        """Snap *val* to the nearest resolution grid point.

        Returns *val* unchanged if resolution is None or enforce_resolution
        is False.  Always clips to bounds after snapping.
        """
        if self.resolution is None or not self.enforce_resolution:
            return val
        lo = self.bounds[0] if self.bounds else 0.0
        steps = round((val - lo) / self.resolution)
        snapped = lo + steps * self.resolution
        # Clip to bounds
        if self.bounds:
            snapped = max(self.bounds[0], min(self.bounds[1], snapped))
        # Round away float drift (e.g. 0.42 + 3*0.005 = 0.43500000000000006)
        ndigits = max(0, -int(math.floor(math.log10(self.resolution)))) + 2
        return round(snapped, ndigits)

    def validate(self, val) -> bool:
        """Return True if *val* is a legal value for this variable.

        For CATEGORICAL: must be in self.categories.
        For INTEGER/CONTINUOUS with bounds: must be within [min, max].
        """
        if self.var_type == VarType.CATEGORICAL:
            return self.categories is not None and val in self.categories
        if self.bounds is not None:
            lo, hi = self.bounds
            return lo <= val <= hi
        return True

    def clip(self, val):
        """Return *val* clipped to bounds and snapped to resolution grid."""
        if self.var_type == VarType.CATEGORICAL:
            return val  # no numeric clipping for categoricals
        if self.bounds is not None:
            lo, hi = self.bounds
            val = max(lo, min(hi, val))
        if self.var_type == VarType.INTEGER:
            val = int(round(val))
        return self._snap(val)

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    def sample(self, n: int, method: str = 'random') -> List:
        """Generate *n* sample values for this variable.

        Parameters
        ----------
        n : int
            Number of samples.
        method : str
            'random'    — uniform or log-uniform random samples within bounds.
            'grid'      — evenly spaced grid (uses step if set, else n points).
            'log_grid'  — logarithmically spaced grid (requires bounds > 0).
            'lhs'       — Latin Hypercube Sampling (stratified random).
            'sobol'     — low-discrepancy quasi-random (van der Corput sequence,
                          production code should use scipy.stats.qmc.Sobol).

        Returns
        -------
        list of sampled values (float or int depending on var_type).
        """
        if self.var_type == VarType.CATEGORICAL:
            if not self.categories:
                raise ValueError(f"Variable '{self.name}' has no categories defined")
            return [random.choice(self.categories) for _ in range(n)]

        if self.bounds is None:
            raise ValueError(
                f"Variable '{self.name}' has no bounds — set bounds=(min, max) before sampling"
            )
        lo, hi = self.bounds

        if method == 'grid':
            values = self._grid_samples(lo, hi, n)
        elif method == 'log_grid':
            values = self._log_grid_samples(lo, hi, n)
        elif method == 'lhs':
            values = self._lhs_samples(lo, hi, n)
        elif method == 'sobol':
            values = self._sobol_samples(lo, hi, n)
        else:  # 'random'
            values = self._random_samples(lo, hi, n)

        if self.var_type == VarType.INTEGER:
            values = [int(round(v)) for v in values]
        return values

    # ------------------------------------------------------------------
    # Internal sampling helpers
    # ------------------------------------------------------------------

    def _random_samples(self, lo, hi, n):
        if self.distribution == Distribution.LOG_UNIFORM:
            log_lo, log_hi = math.log(lo), math.log(hi)
            return [math.exp(random.uniform(log_lo, log_hi)) for _ in range(n)]
        elif self.distribution == Distribution.NORMAL:
            mu    = (lo + hi) / 2
            sigma = (hi - lo) / 6  # 3-sigma covers the range
            return [max(lo, min(hi, random.gauss(mu, sigma))) for _ in range(n)]
        else:  # UNIFORM
            return [random.uniform(lo, hi) for _ in range(n)]

    def _grid_samples(self, lo, hi, n):
        if self.step is not None:
            vals = []
            v = lo
            while v <= hi + 1e-12:
                vals.append(v)
                v += self.step
            return vals[:n] if len(vals) > n else vals
        if n == 1:
            return [lo]
        step = (hi - lo) / (n - 1)
        return [lo + i * step for i in range(n)]

    def _log_grid_samples(self, lo, hi, n):
        if lo <= 0:
            raise ValueError("log_grid requires bounds[0] > 0")
        if n == 1:
            return [lo]
        log_lo, log_hi = math.log(lo), math.log(hi)
        step = (log_hi - log_lo) / (n - 1)
        return [math.exp(log_lo + i * step) for i in range(n)]

    def _lhs_samples(self, lo, hi, n):
        """Latin Hypercube Sampling — one point per stratum."""
        strata = [(i / n, (i + 1) / n) for i in range(n)]
        random.shuffle(strata)
        raw = [random.uniform(s[0], s[1]) for s in strata]
        if self.distribution == Distribution.LOG_UNIFORM:
            log_lo, log_hi = math.log(lo), math.log(hi)
            return [math.exp(log_lo + u * (log_hi - log_lo)) for u in raw]
        return [lo + u * (hi - lo) for u in raw]

    def _sobol_samples(self, lo, hi, n):
        """Van der Corput sequence (base-2) — deterministic low-discrepancy."""
        def vdc(k):
            r, denom = 0.0, 1.0
            while k:
                denom *= 2
                k, remainder = divmod(k, 2)
                r += remainder / denom
            return r
        raw = [vdc(i + 1) for i in range(n)]
        if self.distribution == Distribution.LOG_UNIFORM:
            log_lo, log_hi = math.log(lo), math.log(hi)
            return [math.exp(log_lo + u * (log_hi - log_lo)) for u in raw]
        return [lo + u * (hi - lo) for u in raw]
# Backward-compat alias
PyModule = Module
