"""silk.circuit.spec_report — SpecReport: structured pass/fail spec checking.

Usage::

    report = testbench.run(corner='tt')
    print(report.summary())
    assert report.passed
"""
import math
from dataclasses import dataclass
from typing import Any


_OPS = {
    '>':  lambda v, t: v > t,
    '>=': lambda v, t: v >= t,
    '<':  lambda v, t: v < t,
    '<=': lambda v, t: v <= t,
    '==': lambda v, t: math.isclose(v, t, rel_tol=1e-9),
}


@dataclass
class SpecResult:
    """Result of a single spec check."""
    name: str
    metric_name: str
    op: str
    target: float
    value: Any       # actual measured value; float on success, str on extraction error
    passed: bool


class SpecReport:
    """Structured pass/fail report from a ModuleTestbench run.

    Created by ModuleTestbench.run() — do not instantiate directly.

    Attributes
    ----------
    test_name : str
    module_name : str
    metrics : dict
        All extracted metric values {name: value}.
    passed : bool
        True if all checked specs passed (or no specs were checked).
    results : list[SpecResult]
        Individual spec check results.

    Examples
    --------
    ::

        report = tb.run(corner='tt')
        print(report.summary())
        if not report.passed:
            for r in report.results:
                if not r.passed:
                    print(f"FAIL: {r.name} — got {r.value}, need {r.op} {r.target}")
    """

    def __init__(self, test_name: str, module_name: str, metrics: dict):
        self.test_name   = test_name
        self.module_name = module_name
        self.metrics     = dict(metrics)
        self._results: list[SpecResult] = []

    def check(self, name: str, metric_name: str, op: str, target: float) -> 'SpecReport':
        """Evaluate one spec against the measured metrics.

        Parameters
        ----------
        name : str
            Human-readable spec name, e.g. ``'DC gain > 60 dB'``.
        metric_name : str
            Key into self.metrics dict.
        op : str
            Comparison operator: ``'>'``, ``'>='``, ``'<'``, ``'<='``, ``'=='``.
        target : float
            Target value.

        Returns
        -------
        SpecReport
            self, for chaining.
        """
        value = self.metrics.get(metric_name)
        if value is None or isinstance(value, str):
            passed = False
        else:
            fn = _OPS.get(op)
            if fn is None:
                raise ValueError(f"Unknown operator {op!r}. Valid operators: {list(_OPS)}")
            try:
                passed = fn(float(value), float(target))
            except (TypeError, ValueError):
                passed = False
        self._results.append(SpecResult(name, metric_name, op, target, value, passed))
        return self

    @property
    def passed(self) -> bool:
        """True if all checked specs passed (or no specs were checked)."""
        return all(r.passed for r in self._results)

    @property
    def results(self) -> list:
        """List of SpecResult objects, one per check() call."""
        return list(self._results)

    def summary(self) -> str:
        """Return a human-readable pass/fail table string."""
        status = 'PASS' if self.passed else 'FAIL'
        lines = [
            f"SpecReport [{self.test_name}] — {status}",
            f"  Module: {self.module_name}",
            "",
        ]
        if not self._results:
            lines.append("  (no specs checked)")
        else:
            for r in self._results:
                mark = 'PASS' if r.passed else 'FAIL'
                lines.append(
                    f"  [{mark}]  {r.name}: "
                    f"{r.metric_name} {r.op} {r.target} "
                    f"(measured: {r.value!r})"
                )
        return '\n'.join(lines)

    def __repr__(self) -> str:
        return (
            f"SpecReport(test={self.test_name!r}, "
            f"passed={self.passed}, "
            f"specs={len(self._results)})"
        )


class CornerResults:
    """Collection of SpecReports from a multi-corner run.

    Attributes
    ----------
    reports : dict[str, SpecReport]
        Mapping of corner name → SpecReport.
    passed : bool
        True only if every corner passed all its specs.

    Examples
    --------
    ::

        results = tb.run_corners()
        if not results.passed:
            for corner, report in results.items():
                if not report.passed:
                    print(f"{corner}: {report.summary()}")
    """

    def __init__(self, reports: dict):
        self.reports = dict(reports)

    @property
    def passed(self) -> bool:
        """True if every corner's SpecReport passed."""
        return all(r.passed for r in self.reports.values())

    def summary(self) -> str:
        """One-line per corner pass/fail table."""
        overall = 'PASS' if self.passed else 'FAIL'
        lines = [f'CornerResults — {overall}']
        for corner, report in self.reports.items():
            mark = 'PASS' if report.passed else 'FAIL'
            lines.append(f'  [{mark}]  corner={corner}')
        return '\n'.join(lines)

    def __repr__(self) -> str:
        return f'CornerResults(corners={list(self.reports)}, passed={self.passed})'

    def __getitem__(self, corner: str) -> 'SpecReport':
        return self.reports[corner]

    def __iter__(self):
        return iter(self.reports)

    def items(self):
        return self.reports.items()

    def keys(self):
        return self.reports.keys()

    def values(self):
        return self.reports.values()
