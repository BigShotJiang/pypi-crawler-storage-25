"""silk.circuit.netlist — backward-compatible PyNetlist class.

PyNetlist is now a thin subclass of Module that adds optional legacy DB
tracking.  All circuit-definition and simulation capability lives in Module.

New code should use Module (or silk.Module) directly.
"""
from silk.circuit.modules import Module
from silk.exceptions import PyNetlistError, SimulationError


class PyNetlist(Module):
    """Backward-compatible simulation class.

    Identical to :class:`~silk.circuit.modules.Module` plus optional legacy
    database tracking.  Prefer ``Module`` for new code.

    Parameters
    ----------
    PDKname, dirFolder, netlistname, pdkDetails : str / PDK object
        Passed directly to Module.
    debug : bool
        Verbose output.
    circuit_name, version, stage, db_path, enable_tracking : optional
        Legacy database tracking parameters.  Pass ``db_path`` and
        ``circuit_name`` together to enable tracking.
    strict_nets : bool
        Raise on undeclared nets (default False).
    """

    def __init__(self, PDKname, dirFolder, netlistname, pdkDetails, debug=False,
                 circuit_name=None, version='1.0', stage='dev',
                 db_path=None, enable_tracking=None, strict_nets=False):
        super().__init__(PDKname, dirFolder, netlistname, pdkDetails, debug=debug,
                         strict_nets=strict_nets)
        self.circuit_name = circuit_name
        self._setup_tracking(circuit_name, version, stage, db_path, enable_tracking)

    # ------------------------------------------------------------------
    # Legacy DB tracking — use TrackedModule for new code
    # ------------------------------------------------------------------

    def _setup_tracking(self, circuit_name, version, stage, db_path, enable_tracking):
        """Setup optional database tracking."""
        if enable_tracking is None:
            enable_tracking = bool(circuit_name and db_path)
        self._tracker = None
        self._tracking_enabled = False
        if enable_tracking:
            try:
                from silk.db.circuit_db import CircuitDatabase, DesignStage
                self.db = CircuitDatabase(db_path)
                self.circuit_name = circuit_name
                self.version = version
                self.stage = stage
                self.circuit_id = None
                self._tracking_enabled = True
                print(f"Database tracking enabled: {db_path}")
            except ImportError:
                print("circuitdb not available, install for tracking")
                self._tracking_enabled = False

    def runSimulator(self, auto_track_structure=True):
        """Run ngspice, with optional structure tracking before simulation."""
        if auto_track_structure and self._tracking_enabled:
            if not hasattr(self, '_structure_tracker') or self._structure_tracker is None:
                raise RuntimeError(
                    "Structure tracking enabled but create_circuit_version() not called."
                )
            if self.debug:
                print("\n🔄 Auto-tracking structure before simulation...")
            self.track_structure()
        # Delegate to Module's runSimulator (auto_track_structure already handled above)
        super().runSimulator(auto_track_structure=False)

    def create_circuit_version(self, description="", netlist_path=None):
        """Store circuit metadata for later use by track_structure()."""
        if not self._tracking_enabled:
            return None
        self._circuit_description = description
        self._circuit_netlist_path = netlist_path or self.netlistname
        self.circuit_id = None
        self._initialize_structure_tracker()
        print(f"Circuit info stored: '{self.circuit_name}' v{self.version}")
        return None

    def store_results(self, results_dict, corner="tt", temperature=None, voltage=None):
        """Store simulation results in the database."""
        if hasattr(self, '_tracking_enabled') and self._tracking_enabled:
            if not self.circuit_id:
                print("Call create_circuit_version() first")
                return
            for param, (value, unit) in results_dict.items():
                self.db.add_simulation_result(
                    self.circuit_id, param, value=value, unit=unit,
                    corner=corner, temperature=temperature, voltage=voltage
                )
            print(f"Stored {len(results_dict)} results")

    def view_summary(self):
        """View simulation summary from database."""
        if hasattr(self, '_tracking_enabled') and self._tracking_enabled:
            if self.circuit_id:
                summary = self.db.get_simulation_summary(self.circuit_id)
                print(summary)

    def _initialize_structure_tracker(self):
        if self._tracking_enabled:
            try:
                from silk.db.structure_tracker import CircuitStructureTracker
                self._structure_tracker = CircuitStructureTracker(
                    self.db, self.circuit_id, debug=self.debug
                )
                if self.debug:
                    print("Structure tracker initialized")
            except ImportError as e:
                raise PyNetlistError(f"CircuitStructureTracker not available: {e}")
        else:
            self._structure_tracker = None

    def track_structure(self):
        """Track circuit structure with automatic change detection."""
        if not self._tracking_enabled:
            return None, None
        if not hasattr(self, '_structure_tracker') or self._structure_tracker is None:
            raise RuntimeError(
                "Structure tracking enabled but create_circuit_version() not called."
            )
        structure = self._structure_tracker.extract_structure(self)
        structure_hash, module_hashes = self._structure_tracker.compute_structure_hash(structure)
        if self.debug:
            print(f"Computed structure hash: {structure_hash[:16]}...")
        existing_circuit_id = self._structure_tracker._find_circuit_by_hash(
            self.circuit_name, structure_hash
        )
        if existing_circuit_id:
            print("Found existing circuit with matching structure")
            self.circuit_id = existing_circuit_id
            self._structure_tracker.circuit_id = existing_circuit_id
            self._structure_tracker._load_last_structure()
            self._structure_tracker.increment_run_count()
            return False, structure_hash
        if not self.circuit_id:
            from silk.db.circuit_db import DesignStage
            stage_map = {
                'dev': DesignStage.DEV,
                'stable': DesignStage.STABLE,
                'post_layout': DesignStage.POST_LAYOUT,
                'tapeout': DesignStage.TAPEOUT,
            }
            description = getattr(self, '_circuit_description', '')
            netlist_path = getattr(self, '_circuit_netlist_path', self.netlistname)
            self.circuit_id = self.db.create_circuit(
                name=self.circuit_name,
                version=self.version,
                stage=stage_map.get(self.stage, DesignStage.DEV),
                description=description,
                netlist_path=netlist_path,
            )
            print(f"Created new circuit '{self.circuit_name}' v{self.version}")
            self._structure_tracker.circuit_id = self.circuit_id
        self._structure_tracker.store_structure(structure, structure_hash, module_hashes)
        print(f"Circuit structure stored (hash: {structure_hash[:16]}...)")
        return True, structure_hash

    def get_structure_info(self):
        """Get current circuit structure tracking info."""
        if not self._tracking_enabled or not self._structure_tracker:
            return None
        return {
            'hash': self._structure_tracker.get_structure_hash(),
            'run_count': self._structure_tracker.get_run_count(),
        }

    def print_structure(self):
        """Pretty print the current circuit structure."""
        if not self._tracking_enabled or not self._structure_tracker:
            print("Structure tracking not enabled")
            return
        structure = self._structure_tracker.extract_structure(self)
        print("\n" + "=" * 70)
        print(f"  CIRCUIT STRUCTURE: {self.circuit_name} v{self.version}")
        print("=" * 70)
        print(f"\nTRANSISTORS ({len(structure['transistors'])})")
        print("-" * 70)
        if structure['transistors']:
            for t in structure['transistors']:
                params = t['parameters']
                w, l, m = params.get('w', 0), params.get('l', 0), params.get('m', 1)
                print(f"  {t['name']:20s} {t['type']:6s}  W={w:7.3f}um  L={l:6.3f}um  m={m:3d}")
                if t['nets']:
                    connections = [f"{k}={v}" for k, v in sorted(t['nets'].items())]
                    print("    - " + ", ".join(connections))
                if t.get('model'):
                    print(f"       Model: {t['model']}")
        else:
            print("  (none)")
        print(f"\nNETS ({len(structure['nets'])})")
        print("-" * 70)
        if structure['nets']:
            nets_by_type = {}
            for n in structure['nets']:
                nets_by_type.setdefault(n['type'], []).append(n['name'])
            for net_type in ['power', 'ground', 'clock', 'signal']:
                if net_type in nets_by_type:
                    print(f"  {net_type.upper()}: {', '.join(sorted(nets_by_type[net_type]))}")
        else:
            print("  (none)")
        if structure.get('hierarchy'):
            print(f"\nHIERARCHY ({len(structure['hierarchy'])})")
            print("-" * 70)
            for h in structure['hierarchy']:
                print(f"  {h['instance_name']:25s} (type: {h['module_type']})")
                for port, net in sorted(h.get('ports', {}).items()):
                    print(f"    - {port:20s} -> {net}")
        if structure.get('parameters'):
            print(f"\nPARAMETERS ({len(structure['parameters'])})")
            print("-" * 70)
            for p in structure['parameters']:
                print(f"  {p['module']}.{p['name']:20s} = {p['value']}")
        info = self.get_structure_info()
        if info:
            print(f"\nTRACKING INFO")
            print(f"  Structure hash:  {info['hash'][:32]}...")
            print(f"  Run count:       {info['run_count']}")
        print("=" * 70 + "\n")

    def get_latest_circuit(self, circuit_name=None):
        """Get most recent circuit from database."""
        if not self._tracking_enabled:
            return None
        return self.db.get_latest_circuit(circuit_name or self.circuit_name)

    def get_all_versions(self, circuit_name=None):
        """Get all versions of circuit from database."""
        if not self._tracking_enabled:
            return []
        return self.db.get_all_circuit_versions(circuit_name or self.circuit_name)


# Legacy helper classes — kept for backward compat

class DevicePrimitives:
    def __init__(self, deviceType, connections=[], properties=[]):
        self.deviceType_list = ['capacitor', 'inductor', 'resistor']
        if deviceType not in self.deviceType_list:
            raise PyNetlistError('Device type does not exist')
        self.deviceType = deviceType
        self.terminal_p = self.terminal_n = self.propertyVal = self.propertyUnit = self.pins = None

    def setPropertiesResistor(self, terminal_p, terminal_n, propertyVal):
        self.terminal_p, self.terminal_n = terminal_p, terminal_n
        self.propertyVal, self.propertyUnit = propertyVal, 'ohms'
        self.pins = [terminal_p, terminal_n]

    def setPropertiesCapacitor(self, terminal_p, terminal_n, propertyVal):
        self.terminal_p, self.terminal_n = terminal_p, terminal_n
        self.propertyVal, self.propertyUnit = propertyVal, 'farads'

    def setPropertiesInductor(self, terminal_p, terminal_n, propertyVal):
        self.terminal_p, self.terminal_n = terminal_p, terminal_n
        self.propertyVal, self.propertyUnit = propertyVal, 'henrys'


class Modules:
    def __init__(self, name):
        self.name = name
