# SpecReport is imported lazily in run() to avoid circular imports
# Python based module test class
# Created by Manar El-Chammas
# Provides testbench capabilities for PyModule testing
# Each PyModule can have multiple tests with different testbenches and metrics

class ModuleTestbench:
    """A test for a PyModule - wraps a PyNetlist with testbench and metrics"""

    def __init__(self, module, name='default_test', cache=False):
        """Create a test for a module

        Args:
            module: PyModule instance to test
            name: Name for this test
            cache: If True, cache SpecReport results keyed by (circuit fingerprint,
                   corner). Subsequent run() calls with the same corner return the
                   cached report without re-simulating. Call clear_cache() to
                   invalidate.
        """
        self.module = module
        self.test_name = name
        self._metrics = []
        self._specs = []
        self._module_added = False
        self.netlist = None
        self._cache_enabled = cache
        self._cache = {}   # {(fingerprint, corner_str): SpecReport}

    def _create_netlist(self):
        """Internal: Create a Module instance to serve as the testbench netlist."""
        from silk.circuit.modules import Module
        self.netlist = Module(
            self.module.PDKname,
            self.module.dirFolder,
            f"test_{self.module.module_name}_{self.test_name}.cir",
            self.module.pdkDetails,
        )

    def add_module_under_test(self, port_mapping):
        """Add the module being tested to the netlist

        Args:
            port_mapping: Dictionary mapping module ports to testbench nets
                         Example: {'vdd': 'vdd', 'gnd': '0', 'in': 'vin', 'out': 'vout'}

        Returns:
            self (for method chaining)
        """
        if self._module_added:
            raise ValueError(f"Module already added to test {self.test_name}")

        # Create netlist if needed
        if self.netlist is None:
            self._create_netlist()

        # Add module as DUT
        self.netlist.addElement(self.module, 'dut', nets=port_mapping)
        self._module_added = True
        return self

    # Delegate testbench setup methods to netlist

    def addSource(self, source):
        """Add a source to the testbench.

        Args:
            source: A source object from silk.sources
                    (VoltageSource, CurrentSource, VCVS, etc.)

        Returns:
            self (for method chaining)

        Example::

            from silk import sources
            test.addSource(sources.VoltageSource('vdd', positive='vdd', negative='0', dc=3.3))
        """
        if self.netlist is None:
            self._create_netlist()

        self.netlist.addSource(source)
        return self

    def addPassive(self, passive):
        """Add a passive element (Resistor, Capacitor, or Inductor) to the testbench.

        Args:
            passive: A PassiveBase instance from silk.elements.passives
                     (Resistor, Capacitor, or Inductor)

        Returns:
            self (for method chaining)

        Example::

            from pynetlist import passives
            test.addPassive(passives.Capacitor('cload', pos='vout', neg='0', capacitance=100e-12))
        """
        if self.netlist is None:
            self._create_netlist()

        self.netlist.addPassive(passive)
        return self

    def addCustomLine(self, line):
        """Add a raw SPICE line to the testbench.

        Args:
            line: SPICE line to add, e.g., '.param vbias=0.9'

        Returns:
            self (for method chaining)
        """
        if self.netlist is None:
            self._create_netlist()

        self.netlist.addCustomLine(line)
        return self

    def addSimType(self, simType, params=None):
        """Set simulation type and parameters.

        Accepts either a typed analysis object or the legacy string form.

        Args:
            simType: A typed analysis object (Transient, AC, DC, Noise) **or**
                     a string such as 'transient', 'ac', 'dc'.
            params:  Required when simType is a string; ignored for typed objects.
                     - transient: [step_time, stop_time]
                     - ac:        ['dec', points_per_decade, fstart, fstop]
                     - dc:        [source_name, start, stop, step]

        Returns:
            self (for method chaining)

        Examples::

            from pynetlist import analysis
            # Typed form (preferred)
            test.addSimType(analysis.Transient(step=10e-9, stop=50e-6))
            test.addSimType(analysis.AC(variation='dec', points=10, fstart=1, fstop=1e9))

            # Legacy string form (still supported)
            test.addSimType('transient', [10e-9, 50e-6])
        """
        if self.netlist is None:
            self._create_netlist()

        self.netlist.addSimType(simType, params)
        return self

    def add_metric(self, name, extractor_func):
        """Add a metric to extract after simulation

        Args:
            name: Name of the metric
            extractor_func: Function that takes sim_results (PyNetlist) and returns metric value
                           Example: lambda nr: np.mean(nr.loadSignal('vout').y)

        Returns:
            self (for method chaining)
        """
        self._metrics.append({
            'name': name,
            'extractor': extractor_func
        })
        return self


    def add_spec(self, name: str, metric_name: str, op: str, target: float):
        """Declare a pass/fail specification evaluated after run().

        Parameters
        ----------
        name : str
            Human-readable spec label, e.g. 'DC gain > 60 dB'.
        metric_name : str
            Must match a metric name added via add_metric().
        op : str
            Comparison operator: '>', '>=', '<', '<=', or '=='.
        target : float
            Target value.

        Returns
        -------
        self  (for chaining)

        Example::

            tb.add_metric('gain_dB', lambda ckt: dc_gain_dB(ckt.loadSignal('vout')))
            tb.add_spec('DC gain > 60 dB', 'gain_dB', '>', 60.0)
            report = tb.run()
            print(report.summary())
        """
        self._specs.append({'name': name, 'metric': metric_name, 'op': op, 'target': target})
        return self

    def _fingerprint(self) -> str:
        """Return a short fingerprint of current circuit + spec state.

        The fingerprint changes when devices are added/removed or specs change,
        automatically invalidating cached results that would no longer be valid.
        """
        import hashlib
        import json
        parts = sorted(self.module.elem_dict.keys())
        spec_parts = [(s['name'], s['metric'], s['op'], str(s['target']))
                      for s in self._specs]
        payload = json.dumps({'devices': parts, 'specs': spec_parts}, sort_keys=True)
        return hashlib.sha256(payload.encode()).hexdigest()[:16]

    def _simulate(self, corner: str):
        """Run simulation for *corner* and return a SpecReport.

        This is the inner implementation; ``run()`` calls it (bypassing for
        cache hits when caching is enabled).
        """
        from silk.circuit.spec_report import SpecReport
        print(f"  Simulating {self.test_name} (corner={corner})...")
        self.netlist.simulate(corner=corner)
        print(f"  Extracting metrics...")
        metrics = {}
        for metric in self._metrics:
            try:
                metrics[metric['name']] = metric['extractor'](self.netlist)
            except Exception as e:
                print(f"    Warning: error extracting metric '{metric['name']}': {e}")
                metrics[metric['name']] = f"Error: {e}"
        report = SpecReport(
            test_name=self.test_name,
            module_name=self.module.module_name,
            metrics=metrics,
        )
        for s in self._specs:
            report.check(s['name'], s['metric'], s['op'], s['target'])
        # Preserve legacy .sim_results attribute for signal loading
        report.sim_results = self.netlist
        return report

    def run(self, corner='tt'):
        """Run the test: simulate and extract metrics.

        Args:
            corner: Process corner — plain string (``'tt'``) or
                    :class:`~silk.simulation.corner.Corner` enum value.

        Returns:
            :class:`~silk.circuit.spec_report.SpecReport`
        """
        if not self._module_added:
            raise ValueError(f"Must call add_module_under_test() before running test {self.test_name}")
        if self.netlist is None:
            raise ValueError(f"Netlist not created for test {self.test_name}")

        corner_str = str(corner)
        if self._cache_enabled:
            key = (self._fingerprint(), corner_str)
            if key in self._cache:
                return self._cache[key]
            report = self._simulate(corner_str)
            self._cache[key] = report
            return report
        return self._simulate(corner_str)

    def clear_cache(self):
        """Clear all cached simulation results."""
        self._cache = {}

    def run_corners(self, corners=('tt', 'ff', 'ss', 'sf', 'fs')):
        """Run simulation across multiple corners.

        Parameters
        ----------
        corners : iterable of str, optional
            Corner names to simulate.  Default: ``('tt', 'ff', 'ss', 'sf', 'fs')``.

        Returns
        -------
        CornerResults
            Dict-like object mapping corner name → :class:`~silk.circuit.spec_report.SpecReport`.
            ``result.passed`` is True only if every corner passed all specs.

        Example::

            results = tb.run_corners()
            if not results.passed:
                for corner, report in results.items():
                    if not report.passed:
                        print(f"{corner}: {report.summary()}")
        """
        from silk.circuit.spec_report import CornerResults
        reports = {corner: self.run(corner=corner) for corner in corners}
        return CornerResults(reports)

# Backward-compat alias
PyModuleTest = ModuleTestbench
