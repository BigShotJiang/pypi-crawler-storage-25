"""
Example: New Factory API — Direct Device Instantiation
=======================================================

Demonstrates the new pdk.<device>(...) / ckt.add() API introduced in the
device-class-refactor.  Devices are instantiated directly as Python objects
rather than being added by name/type string.

Key features shown:
  - pdk.nmos1p8('mn1', d=..., g=..., ...)  — direct instantiation
  - ckt.add(mn1, mp1, ...)                  — unified add() method
  - elements.resistor('r1', ...)             — ideal passive elements
  - mn1.w = 2.0                              — direct attribute assignment
  - mn1.to_spice()                           — inspect SPICE line directly
"""

import os
from silk.circuit.netlist import PyNetlist
from silk.pdk import PDK_skywater130
from silk.elements import elements
from silk import sources
from silk.simulation import analysis

# ---------------------------------------------------------------------------
# PDK yaml path
# ---------------------------------------------------------------------------
_examples_dir = os.path.dirname(os.path.abspath(__file__))
_yaml_path = os.path.join(_examples_dir, '..', 'pdk', 'data', 'skywater_130_device_details.yaml')

# ---------------------------------------------------------------------------
# PDK setup
# ---------------------------------------------------------------------------

_pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))
pdk_lib = f"{_pdk_root}/skywater-pdk/libraries/sky130_fd_pr/latest/models/sky130.lib.spice"

pdk = PDK_skywater130(
    _yaml_path,
    libraryLocation=pdk_lib,
)

# ---------------------------------------------------------------------------
# 1. Direct device instantiation
# ---------------------------------------------------------------------------

# Each PDK device is now a Python class with named constructor arguments.
# Pins and parameters are keyword arguments — IDE autocomplete works on them.
mn1 = pdk.nmos1p8('mn1', d='voutn', g='vinp', s='tail', b='gnd', w=4.0, l=0.15, m=2)
mn2 = pdk.nmos1p8('mn2', d='voutp', g='vinn', s='tail', b='gnd', w=4.0, l=0.15, m=2)
mp1 = pdk.pmos1p8('mp1', d='voutp', g='voutp', s='vdd', b='vdd', w=4.0, l=0.15, m=1)
mp2 = pdk.pmos1p8('mp2', d='voutn', g='voutp', s='vdd', b='vdd', w=4.0, l=0.15, m=1)
mn_tail = pdk.nmos1p8('mn_tail', d='tail', g='vbias', s='gnd', b='gnd', w=8.0, l=0.5, m=4)

# Inspect the SPICE line for any device before adding to circuit
print("mn1 SPICE:", mn1.to_spice().strip())

# ---------------------------------------------------------------------------
# 2. Direct attribute assignment — update a parameter without reconstructing
# ---------------------------------------------------------------------------

# After instantiation you can update parameters or nets directly:
mn1.w = 6.0          # width changed from 4.0 to 6.0
mn1.d = 'voutn_new'  # reconnect drain to a different net

print("After update  mn1.params['w']:", mn1.params['w'])
print("After update  mn1.nets['d']  :", mn1.nets['d'])

# Reset to original for the circuit below
mn1.w = 4.0
mn1.d = 'voutn'

# ---------------------------------------------------------------------------
# 3. Ideal passive elements from ElementLibrary
# ---------------------------------------------------------------------------

# elements.<device>(...) — process-independent SPICE primitives
r_load = elements.resistor('r_load', p='voutp', n='vdd', value=10e3)
c_load = elements.capacitor('c_load', p='voutp', n='gnd', value=100e-15)
vdd    = elements.vsource('vdd',    p='vdd',   n='gnd', dc=1.8)
vinn   = elements.vsource('vinn',   p='vinn',  n='gnd', dc=0.9)
vinp   = elements.vsource('vinp',   p='vinp',  n='gnd', dc=0.9)
vbias  = elements.vsource('vbias',  p='vbias', n='gnd', dc=0.6)

print("Resistor SPICE:", r_load.to_spice().strip())
print("VSource  SPICE:", vdd.to_spice().strip())

# ---------------------------------------------------------------------------
# 4. Build the circuit with ckt.add()
# ---------------------------------------------------------------------------

dir_folder = 'testSpice'
os.makedirs(dir_folder, exist_ok=True)
fname      = 'diffpair_factory.cir'

ckt = PyNetlist('PDK_skywater130', dir_folder, fname, pdkDetails=pdk)

# Add all devices in one call — no elemName string needed, name is on the instance
ckt.add(mn1, mn2, mp1, mp2, mn_tail,
        r_load, c_load,
        vdd, vinn, vinp, vbias)

print("\nElements in circuit:", list(ckt.elem_dict.keys()))
print("Nets auto-registered:", sorted(ckt.net_dict.keys()))

# ---------------------------------------------------------------------------
# 5. Add simulation and generate netlist
# ---------------------------------------------------------------------------

ckt.addSimType(analysis.Transient(step=1e-9, stop=50e-9))

ckt.generateNetlist(corner='tt')

print("\nNetlist written.  Run ckt.simulate() to invoke ngspice.")
print("(Requires ngspice + SkyWater PDK installed at PDK_ROOT)")
