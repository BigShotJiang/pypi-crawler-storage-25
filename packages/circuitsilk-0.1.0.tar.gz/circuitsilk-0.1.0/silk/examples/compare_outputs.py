"""
Compare simulation outputs: legacy PyNetlist path vs silk path
==============================================================
Historical migration-verification script.  Both paths now go through the
same silk.* implementation; the ``run_pynetlist`` function uses the
backward-compat shim at ``silk.circuit.netlist.PyNetlist`` while
``run_silk`` uses the same class under the canonical name.

This script is retained for regression testing only.  For new circuits
use silk.Module directly — see silk/examples/factory_api_example.py.

Usage: python -m silk.examples.compare_outputs
  or:  python silk/examples/compare_outputs.py
"""

import os
import tempfile
import numpy as np

_pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))
_pdk_lib = f"{_pdk_root}/skywater-pdk/libraries/sky130_fd_pr/latest/models/sky130.lib.spice"

# ── Legacy path: PyNetlist via silk compat layer ──────────────────────────
def run_pynetlist(tmp_dir):
    from silk.circuit.netlist import PyNetlist as pn_PyNetlist
    from silk.pdk import PDK_skywater130
    from silk import sources
    from silk.simulation import analysis

    import os as _os
    _examples_dir = _os.path.dirname(_os.path.abspath(__file__))
    _yaml = _os.path.join(_examples_dir, '..', 'pdk', 'data', 'skywater_130_device_details.yaml')

    pdk130 = PDK_skywater130(_yaml, libraryLocation=_pdk_lib)

    ckt = pn_PyNetlist('PDK_skywater130', tmp_dir, 'cmp_pynetlist.cir', pdkDetails=pdk130)

    mn_p = pdk130.nmos1p8('nmos_input_p', d='voutn', g='vinp', s='0', b='0', w=1.0, l=0.35, m=5)
    mn_n = pdk130.nmos1p8('nmos_input_n', d='voutp', g='vinn', s='0', b='0', w=1.0, l=0.35, m=5)
    mp_p = pdk130.pmos1p8('pmos_load_p',  d='voutn', g='voutp', s='vdd', b='vdd', w=1.0, l=0.35)
    mp_n = pdk130.pmos1p8('pmos_load_n',  d='voutp', g='voutp', s='vdd', b='vdd', w=1.0, l=0.35)
    ckt.add(mn_p, mn_n, mp_p, mp_n)
    ckt.addSource(sources.VoltageSource('supply', positive='vdd', negative='0', dc=5, ac=1))
    ckt.addSimType(analysis.Transient(step=1e-9, stop=100e-9))

    ckt.simulate(corner='tt')
    return ckt.loadSignal('vdd')

# ── New: silk ─────────────────────────────────────────────────────────────
def run_silk(tmp_dir):
    from silk.circuit.netlist import PyNetlist
    from silk.pdk import PDK_skywater130
    from silk import sources
    from silk.simulation import analysis

    import os as _os
    _examples_dir = _os.path.dirname(_os.path.abspath(__file__))
    _yaml = _os.path.join(_examples_dir, '..', 'pdk', 'data', 'skywater_130_device_details.yaml')

    pdk130 = PDK_skywater130(_yaml, libraryLocation=_pdk_lib)

    ckt = PyNetlist('PDK_skywater130', tmp_dir, 'cmp_silk.cir', pdkDetails=pdk130)

    mn_p = pdk130.nmos1p8('nmos_input_p', d='voutn', g='vinp', s='0', b='0', w=1.0, l=0.35, m=5)
    mn_n = pdk130.nmos1p8('nmos_input_n', d='voutp', g='vinn', s='0', b='0', w=1.0, l=0.35, m=5)
    mp_p = pdk130.pmos1p8('pmos_load_p',  d='voutn', g='voutp', s='vdd', b='vdd', w=1.0, l=0.35)
    mp_n = pdk130.pmos1p8('pmos_load_n',  d='voutp', g='voutp', s='vdd', b='vdd', w=1.0, l=0.35)
    ckt.add(mn_p, mn_n, mp_p, mp_n)
    ckt.addSource(sources.VoltageSource('supply', positive='vdd', negative='0', dc=5, ac=1))
    ckt.addSimType(analysis.Transient(step=1e-9, stop=100e-9))

    ckt.simulate(corner='tt')
    return ckt.loadSignal('vdd')


if __name__ == '__main__':
    print('Running differential pair simulation...')
    print()

    with tempfile.TemporaryDirectory() as tmp_pn, tempfile.TemporaryDirectory() as tmp_silk:
        print('[1/2] Running PyNetlist simulation...')
        try:
            sig_pn = run_pynetlist(tmp_pn)
            print(f'      vdd signal: {len(sig_pn.y)} points, mean={np.mean(sig_pn.y):.4f} V')
        except Exception as e:
            print(f'      FAILED: {e}')
            sig_pn = None

        print('[2/2] Running silk simulation...')
        try:
            sig_sk = run_silk(tmp_silk)
            print(f'      vdd signal: {len(sig_sk.y)} points, mean={np.mean(sig_sk.y):.4f} V')
        except Exception as e:
            print(f'      FAILED: {e}')
            sig_sk = None

    print()
    if sig_pn is not None and sig_sk is not None:
        pn_arr = np.array(sig_pn.y)
        sk_arr = np.array(sig_sk.y)
        if len(pn_arr) == len(sk_arr):
            max_diff = np.max(np.abs(pn_arr - sk_arr))
            rel_diff = max_diff / (np.max(np.abs(pn_arr)) + 1e-12)
            print(f'Max absolute difference: {max_diff:.2e} V')
            print(f'Max relative difference: {rel_diff:.2e}')
            if rel_diff < 1e-6:
                print('PASS — outputs are numerically identical')
            else:
                print('WARN — outputs differ (check above)')
        else:
            print(f'Point count differs: PyNetlist={len(pn_arr)}, silk={len(sk_arr)}')
            print('This is expected if ngspice produces slightly different output; check manually.')
    elif sig_pn is None and sig_sk is None:
        print('Both simulations failed (ngspice may not be available).')
    else:
        print('One simulation failed — cannot compare.')
