"""
Differential Pair Example
=========================

Demonstrates the factory-based device API introduced in the device-class-refactor.
Uses the silk API.

  - pdk.<device>('name', pin=net, ..., param=value)  — direct instantiation
  - ckt.add(...)                                      — unified add method
  - mn.w = value                                      — direct attribute assignment

The old addElement() API still works as a drop-in if preferred.
"""

from silk.circuit.netlist import PyNetlist
import os

from silk.pdk import PDK_skywater130
from silk import sources, analysis

# ---------------------------------------------------------------------------
# PDK yaml path
# ---------------------------------------------------------------------------
_examples_dir = os.path.dirname(os.path.abspath(__file__))
_yaml_path = os.path.join(_examples_dir, '..', 'pdk', 'data', 'skywater_130_device_details.yaml')

# ---------------------------------------------------------------------------
# PDK setup
# ---------------------------------------------------------------------------
_pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))
pdk_lib_location = f"{_pdk_root}/skywater-pdk/libraries/sky130_fd_pr/latest/models/sky130.lib.spice"
pdk130 = PDK_skywater130(_yaml_path, libraryLocation=pdk_lib_location, debug=True)

fname = 'example.cir'
dirFolder = 'testSpice'
os.makedirs(dirFolder, exist_ok=True)

# ---------------------------------------------------------------------------
# 1. Instantiate devices directly using the factory API
# ---------------------------------------------------------------------------

# NMOS input pair: differential inputs vinp/vinn, drains to voutp/voutn
mn_input_p = pdk130.nmos1p8('nmos_input_p',
                             d='voutn', g='vinp', s='0', b='0',
                             w=1.0, l=0.35, m=5)

mn_input_n = pdk130.nmos1p8('nmos_input_n',
                             d='voutp', g='vinn', s='0', b='0',
                             w=1.0, l=0.35, m=5)

# PMOS current-mirror load
mp_load_p = pdk130.pmos1p8('pmos_load_p',
                            d='voutn', g='voutp', s='vdd', b='vdd',
                            w=1.0, l=0.35)

mp_load_n = pdk130.pmos1p8('pmos_load_n',
                            d='voutp', g='voutp', s='vdd', b='vdd',
                            w=1.0, l=0.35)

# ---------------------------------------------------------------------------
# 2. Build circuit with ckt.add()
# ---------------------------------------------------------------------------

main_netlist = PyNetlist('PDK_skywater130', dirFolder, fname, pdkDetails=pdk130)

main_netlist.add(mn_input_p, mn_input_n, mp_load_p, mp_load_n)

# ---------------------------------------------------------------------------
# 3. Direct attribute assignment — adjust a parameter without reconstruction
# ---------------------------------------------------------------------------

# Example: widen NMOS pair after initial instantiation
# mn_input_p.w = 2.0
# mn_input_n.w = 2.0

# ---------------------------------------------------------------------------
# 4. Sources and simulation
# ---------------------------------------------------------------------------

main_netlist.addSource(sources.VoltageSource('supply', positive='vdd', negative='0', dc=5, ac=1))

main_netlist.addSimType(analysis.Transient(step=1e-9, stop=100e-9))

main_netlist.printElements()
main_netlist.printNets()

# ---------------------------------------------------------------------------
# 5. Simulate and read results
# ---------------------------------------------------------------------------

# simulate() runs generateNetlist() → ngspice → loadFile() in sequence.
# It raises SimulationError if ngspice fails, so optimization loops can
# catch it without the process exiting.
main_netlist.simulate(corner='tt')
main_netlist.getSignalNames()
vdd = main_netlist.loadSignal('vdd')

y = vdd + vdd

print(vdd.name)
print(vdd.type)
print(vdd.xlabel)
print(vdd.ylabel)
print(vdd.x)
print(vdd.y)
