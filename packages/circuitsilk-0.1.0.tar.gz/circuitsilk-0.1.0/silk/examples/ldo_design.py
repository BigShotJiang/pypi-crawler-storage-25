"""
Parameterized LDO Design

Consolidates the 6 main_ldo_*.py scripts into a single reusable class.
Original files archived in archive/ldo_designs/.

Devices are instantiated directly via the factory API and added with
ldo.add() — pins and parameters are named keyword arguments, parameters
can be updated by direct attribute assignment (e.g. nmos_output.w = 12.0).
"""

from silk.circuit.netlist import PyNetlist
from silk import Module
from silk.pdk import PDK_skywater130 as pdk
from silk import sources
from silk.elements import passives
from silk.simulation import analysis
import matplotlib
for _backend in ['TkAgg', 'Qt5Agg', 'QtAgg', 'GTK4Agg', 'GTK3Agg']:
    try:
        matplotlib.use(_backend)
        break
    except Exception:
        continue
import matplotlib.pyplot as plt


class LDODesign:
    """Parameterized NMOS-output LDO regulator design."""

    # All W/L values in µm (PDK-native units for sky130)
    DEFAULT_PARAMS = {
        'm_input_diff_pair': 5,
        'm_pmos_load': 5,
        'm_input_bias': 2,
        'm_output_bias_ratio': 10,
        'm_nmos_output_ratio': 200,
        'input_width': 2.0,
        'input_length': 0.5,
        'load_width': 2.0,
        'load_length': 0.5,
        'output_width': 10.0,
        'output_length': 0.15,
        'bias_width': 2.0,
        'bias_length': 1.0,
        'vdd': 3.3,
        'vref': 1.0,
    }

    def __init__(self, pdk_instance, dir_folder, fname, params=None):
        self.pdk = pdk_instance
        self.dir_folder = dir_folder
        self.fname = fname
        self.params = dict(self.DEFAULT_PARAMS)
        if params:
            self.params.update(params)

    def build(self):
        """Build the LDO subcircuit module and return it."""
        p = self.params

        m_output_bias = p['m_input_bias'] * p['m_output_bias_ratio']
        m_nmos_output = p['m_nmos_output_ratio']

        ldo = Module('PDK_skywater130', self.dir_folder, self.fname,
                     pdkDetails=self.pdk)
        ldo.defineModuleName('ldo_nmos')
        ldo.defineModuleNets({'vdd': None, 'gnd': None, 'vin': None, 'vout': None, 'vnbias': None})

        # Diff pair
        nmos_input_p = self.pdk.nmos1p8('nmos_input_p',
                                         d='vpmos_mirror', g='vin', s='vdiffdrain', b='gnd',
                                         w=p['input_width'], l=p['input_length'],
                                         m=p['m_input_diff_pair'])
        nmos_input_n = self.pdk.nmos1p8('nmos_input_n',
                                         d='vst1_out', g='vout', s='vdiffdrain', b='gnd',
                                         w=p['input_width'], l=p['input_length'],
                                         m=p['m_input_diff_pair'])

        # Active load
        pmos_load_p = self.pdk.pmos1p8('pmos_load_p',
                                        d='vpmos_mirror', g='vpmos_mirror', s='vdd', b='vdd',
                                        w=p['load_width'], l=p['load_length'],
                                        m=p['m_pmos_load'])
        pmos_load_n = self.pdk.pmos1p8('pmos_load_n',
                                        d='vst1_out', g='vpmos_mirror', s='vdd', b='vdd',
                                        w=p['load_width'], l=p['load_length'],
                                        m=p['m_pmos_load'])

        # Bias current source
        nmos_bias_diffpair = self.pdk.nmos1p8('nmos_bias_diffpair',
                                               d='vdiffdrain', g='vnbias', s='gnd', b='gnd',
                                               w=p['bias_width'], l=p['bias_length'],
                                               m=p['m_input_bias'])

        # Output NMOS
        nmos_output = self.pdk.nmos1p8('nmos_output',
                                        d='vdd', g='vst1_out', s='vout', b='gnd',
                                        w=p['output_width'], l=p['output_length'],
                                        m=m_nmos_output)

        # Output bias
        nmos_bias_output = self.pdk.nmos1p8('nmos_bias_output',
                                             d='vout', g='vnbias', s='gnd', b='gnd',
                                             w=p['bias_width'], l=p['bias_length'],
                                             m=m_output_bias)

        # Bias diode
        nmos_bias_diode = self.pdk.nmos1p8('nmos_bias_diode',
                                            d='vnbias', g='vnbias', s='gnd', b='gnd',
                                            w=p['bias_width'], l=p['bias_length'], m=1)

        ldo.add(nmos_input_p, nmos_input_n,
                pmos_load_p, pmos_load_n,
                nmos_bias_diffpair,
                nmos_output,
                nmos_bias_output,
                nmos_bias_diode)

        return ldo


if __name__ == '__main__':
    import os
    _examples_dir = os.path.dirname(os.path.abspath(__file__))
    _yaml_path = os.path.join(_examples_dir, '..', 'pdk', 'data', 'skywater_130_device_details.yaml')

    _pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))
    pdk_lib_location = f"{_pdk_root}/skywater-pdk/libraries/sky130_fd_pr/latest/models/sky130.lib.spice"
    pdk130 = pdk(_yaml_path, libraryLocation=pdk_lib_location)

    dir_folder = 'testSpice'
    os.makedirs(dir_folder, exist_ok=True)
    fname = 'ldo_example.cir'

    output_dir = os.path.join(os.path.dirname(__file__), 'output')
    os.makedirs(output_dir, exist_ok=True)
    db_path = os.path.join(output_dir, 'ldo_design.db')

    # Build the LDO subcircuit
    ldo_design = LDODesign(pdk130, dir_folder, fname)
    subckt_ldo = ldo_design.build()

    # Top-level netlist
    main_netlist = PyNetlist('PDK_skywater130', dir_folder, fname,
                             pdkDetails=pdk130,
                             circuit_name="ldo_nmos",
                             db_path=db_path)

    main_netlist.create_circuit_version("Initial LDO design")

    # Add LDO module instance
    main_netlist.addElement(
        subckt_ldo, 'ldo_top',
        nets={
            'vdd':    'vdd3',
            'gnd':    '0',
            'vin':    'vin_ldo',
            'vout':   'vldo_out',
            'vnbias': 'vnbias',
        }
    )

    # Sources
    main_netlist.addSource(sources.CurrentSource(
        'biascurrent', positive='vdd3', negative='vnbias', dc=100e-6))

    main_netlist.addSource(sources.VoltageSource(
        'supply', positive='vdd3', negative='0', dc=3.3, ac=1))

    main_netlist.addSource(sources.VoltageSource(
        'ldo_input', positive='vin_ldo', negative='0', dc=1.8,
        pwl=[0, 0, 99e-9, 0, 100e-9, 0.1, 199e-9, 0.1, 200e-9, 0]))

    main_netlist.addSource(sources.CurrentSource(
        'ldo_load_current', positive='0', negative='vldo_out'))

    main_netlist.addPassive(passives.Capacitor('load', pos='vldo_out', neg='0', capacitance=100e-12))
    main_netlist.addSimType(analysis.Transient(step=10e-9, stop=50e-6))

    main_netlist.printElements()
    main_netlist.printNets()

    # simulate() replaces the old four-step sequence:
    #   generateNetlist() → runSimulator() → loadFile() → readRawFile()
    # It raises SimulationError if ngspice fails, so optimization loops can
    # catch it without the process exiting.
    main_netlist.simulate(corner='tt')
    main_netlist.getSignalNames()

    vdd         = main_netlist.loadSignal('vdd3')
    vdd_current = main_netlist.loadSignal('vsupply', signalType='I')
    bias_node   = main_netlist.loadSignal('vnbias')
    vst1_out    = main_netlist.loadSignal('xldo_top.vst1_out')
    vldo_out    = main_netlist.loadSignal('vldo_out')
    vldo_input  = main_netlist.loadSignal('vin_ldo')

    plots = [
        ('Supply',       vdd.x,         vdd.y,         None),
        ('Supply Current', vdd_current.x, vdd_current.y, None),
        ('Bias Voltage', bias_node.x,   bias_node.y,   [0, 2]),
        ('LDO St1 Output', vst1_out.x,  vst1_out.y,   [0, 4]),
        ('LDO Output',   vldo_out.x,    vldo_out.y,    [1, 2]),
        ('LDO Input',    vldo_input.x,  vldo_input.y,  None),
    ]

    for title, x, y, ylim in plots:
        fig, ax = plt.subplots()
        ax.plot(x, y)
        ax.set_title(title)
        if ylim:
            ax.set_ylim(ylim)

    plt.show()
