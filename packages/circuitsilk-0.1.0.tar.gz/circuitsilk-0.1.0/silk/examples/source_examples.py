"""
Source Examples

Demonstrates all source types in silk.sources with a single transient
simulation.  Each source drives a simple resistive (or RC) load; output node
voltages are captured and plotted.

Circuit topology
----------------
Independent V/I sources  → 1 kΩ resistor → GND
Controlled sources        share a common 1 MHz sine control input
Behavioral sources        operate on independent sine inputs
"""

import matplotlib
for _backend in ['TkAgg', 'Qt5Agg', 'QtAgg', 'GTK4Agg', 'GTK3Agg']:
    try:
        matplotlib.use(_backend)
        break
    except Exception:
        continue
import matplotlib.pyplot as plt

from silk.circuit.netlist import PyNetlist
from silk.pdk import PDK_skywater130 as pdk
from silk import sources
from silk.elements import passives
from silk.simulation import analysis
import os

# ---------------------------------------------------------------------------
# PDK yaml path
# ---------------------------------------------------------------------------
_examples_dir = os.path.dirname(os.path.abspath(__file__))
_yaml_path = os.path.join(_examples_dir, '..', 'pdk', 'data', 'skywater_130_device_details.yaml')

# ---------------------------------------------------------------------------
# PDK setup
# ---------------------------------------------------------------------------
_pdk_root = os.environ.get('PDK_ROOT', os.path.expanduser('~/pdk'))
pdk_lib = (f"{_pdk_root}/skywater-pdk/libraries/sky130_fd_pr/latest"
           f"/models/sky130.lib.spice")
pdk130 = pdk(_yaml_path, libraryLocation=pdk_lib)

dir_folder = 'testSpice'
os.makedirs(dir_folder, exist_ok=True)

# ---------------------------------------------------------------------------
# Build netlist
# ---------------------------------------------------------------------------
nt = PyNetlist('PDK_skywater130', dir_folder, 'source_examples.cir',
               pdkDetails=pdk130)

# ── 1. Pulse voltage source ─────────────────────────────────────────────────
nt.addSource(sources.VoltageSource('pulse',
    positive='n_pulse', negative='0',
    pulse=sources.Pulse(v1=0, v2=1.8,
                        td=100e-9, tr=10e-9, tf=10e-9,
                        pw=200e-9, per=500e-9)))
nt.addPassive(passives.Resistor('pulse', pos='n_pulse', neg='0', resistance=1e3))

# ── 2. Sine voltage source ───────────────────────────────────────────────────
nt.addSource(sources.VoltageSource('sine',
    positive='n_sine', negative='0',
    sine=sources.Sine(voffset=0, vampl=1.0, freq=1e6)))
nt.addPassive(passives.Resistor('sine', pos='n_sine', neg='0', resistance=1e3))

# ── 3. Exponential voltage source ────────────────────────────────────────────
#   Rise: starts at 100 ns, τ = 50 ns
#   Fall: starts at 400 ns, τ = 100 ns
nt.addSource(sources.VoltageSource('exp',
    positive='n_exp', negative='0',
    exponential=sources.Exponential(v1=0, v2=1.8,
                                    td1=100e-9, tau1=50e-9,
                                    td2=400e-9, tau2=100e-9)))
nt.addPassive(passives.Resistor('exp', pos='n_exp', neg='0', resistance=1e3))

# ── 4. PWL voltage source ────────────────────────────────────────────────────
nt.addSource(sources.VoltageSource('pwl',
    positive='n_pwl', negative='0',
    pwl=[0, 0,
         100e-9, 0,
         200e-9, 1.8,
         600e-9, 1.8,
         700e-9, 0,
         1e-6,   0]))
nt.addPassive(passives.Resistor('pwl', pos='n_pwl', neg='0', resistance=1e3))

# ── 5. SFFM — Single-Frequency FM ───────────────────────────────────────────
#   Carrier 1 MHz, modulating signal 100 kHz, modulation index = 2
nt.addSource(sources.VoltageSource('sffm',
    positive='n_sffm', negative='0',
    sffm=sources.SFFM(vo=0, va=1.0, fc=1e6, mdi=2, fs=100e3)))
nt.addPassive(passives.Resistor('sffm', pos='n_sffm', neg='0', resistance=1e3))

# ── 6. AM — Amplitude Modulation ─────────────────────────────────────────────
#   Carrier 1 MHz, modulating signal 100 kHz
nt.addSource(sources.VoltageSource('am',
    positive='n_am', negative='0',
    am=sources.AM(va=1.0, vo=0.5, mf=100e3, fc=1e6)))
nt.addPassive(passives.Resistor('am', pos='n_am', neg='0', resistance=1e3))

# ── 7. TransientNoise ────────────────────────────────────────────────────────
#   White noise 10 mV rms, 1 ns correlation time.
#   RC filter (R=100 Ω, C=1 nF) smooths the waveform for visibility.
nt.addSource(sources.VoltageSource('noise',
    positive='n_noise_src', negative='0',
    trnoise=sources.TransientNoise(na='10m', nt='1n')))
nt.addPassive(passives.Resistor('noise_r', pos='n_noise_src', neg='n_noise', resistance=100))
nt.addPassive(passives.Capacitor('noise_c', pos='n_noise', neg='0', capacitance=1e-9))

# ── 8. RandomSource — Gaussian ───────────────────────────────────────────────
#   Type 2 = Gaussian, new value every 10 ns, std = 1 V
nt.addSource(sources.VoltageSource('rand',
    positive='n_rand', negative='0',
    trrandom=sources.RandomSource(type=2, ts='10n', param1=1.0)))
nt.addPassive(passives.Resistor('rand', pos='n_rand', neg='0', resistance=1e3))

# ── 9. DC current source ─────────────────────────────────────────────────────
#   1 mA through 1 kΩ → 1 V at n_ibias
nt.addSource(sources.CurrentSource('ibias',
    positive='n_ibias', negative='0', dc=1e-3))
nt.addPassive(passives.Resistor('ibias', pos='n_ibias', neg='0', resistance=1e3))

# ── 10. Pulse current source ─────────────────────────────────────────────────
nt.addSource(sources.CurrentSource('ipulse',
    positive='n_ipulse', negative='0',
    pulse=sources.Pulse(v1=0, v2=1e-3,
                        td=100e-9, tr=10e-9, tf=10e-9,
                        pw=200e-9, per=500e-9)))
nt.addPassive(passives.Resistor('ipulse', pos='n_ipulse', neg='0', resistance=1e3))

# ── 11. VCVS — gain = 2 ──────────────────────────────────────────────────────
#   Common control input: sine 0.5 V amplitude, 0.5 V offset
nt.addSource(sources.VoltageSource('ctrl',
    positive='n_ctrl', negative='0',
    sine=sources.Sine(voffset=0.5, vampl=0.5, freq=1e6)))
nt.addPassive(passives.Resistor('ctrl', pos='n_ctrl', neg='0', resistance=10e3))

nt.addSource(sources.VCVS('eamp',
    out_pos='n_vcvs', out_neg='0',
    ctrl_pos='n_ctrl', ctrl_neg='0',
    gain=2))

# ── 12. VCCS — gm = 1 mA/V, R_load = 1 kΩ ───────────────────────────────────
#   Output voltage = gm × R_load × v(n_ctrl) = 1 × v(n_ctrl)
nt.addSource(sources.VCCS('gm1',
    out_pos='n_vccs', out_neg='0',
    ctrl_pos='n_ctrl', ctrl_neg='0',
    gm=1e-3))
nt.addPassive(passives.Resistor('vccs', pos='n_vccs', neg='0', resistance=1e3))

# ── 13. CCVS — transresistance = 1 kΩ ───────────────────────────────────────
#   Input sine through 1 kΩ → 0 V ammeter → measures current.
#   V_out = R_trans × I_in = 1k × (V_in / 1k) = V_in  (unity gain)
nt.addSource(sources.VoltageSource('ctrl_ccvs',
    positive='n_ctrl_ccvs', negative='0',
    sine=sources.Sine(voffset=0.5, vampl=0.5, freq=1e6)))
nt.addPassive(passives.Resistor('ccvs_in', pos='n_ctrl_ccvs', neg='n_ccvs_amm', resistance=1e3))
nt.addSource(sources.VoltageSource('ammeter_ccvs',
    positive='n_ccvs_amm', negative='0', dc=0))  # 0 V ammeter
nt.addSource(sources.CCVS('htrans',
    out_pos='n_ccvs', out_neg='0',
    transresistance=1000, ctrl_vname='Vammeter_ccvs'))

# ── 14. CCCS — gain = 2 ──────────────────────────────────────────────────────
#   I_out = 2 × I_in;  V_out = I_out × R_load = 2 × V_ctrl / 1k × 1k = 2 × V_ctrl
nt.addSource(sources.VoltageSource('ctrl_cccs',
    positive='n_ctrl_cccs', negative='0',
    sine=sources.Sine(voffset=0.5, vampl=0.5, freq=1e6)))
nt.addPassive(passives.Resistor('cccs_in', pos='n_ctrl_cccs', neg='n_cccs_amm', resistance=1e3))
nt.addSource(sources.VoltageSource('ammeter_cccs',
    positive='n_cccs_amm', negative='0', dc=0))  # 0 V ammeter
nt.addSource(sources.CCCS('fmir',
    out_pos='n_cccs', out_neg='0',
    gain=2, ctrl_vname='Vammeter_cccs'))
nt.addPassive(passives.Resistor('cccs_out', pos='n_cccs', neg='0', resistance=1e3))

# ── 15. BehavioralVoltage — differential ─────────────────────────────────────
#   V_out = V(n_ba) − V(n_bb)
nt.addSource(sources.VoltageSource('bsrc_a',
    positive='n_ba', negative='0',
    sine=sources.Sine(voffset=0, vampl=1.0, freq=1e6)))
nt.addSource(sources.VoltageSource('bsrc_b',
    positive='n_bb', negative='0',
    sine=sources.Sine(voffset=0, vampl=0.7, freq=1e6, phase=45)))
nt.addPassive(passives.Resistor('ba', pos='n_ba', neg='0', resistance=10e3))
nt.addPassive(passives.Resistor('bb', pos='n_bb', neg='0', resistance=10e3))
nt.addSource(sources.BehavioralVoltage('bdiff',
    positive='n_bdiff', negative='0',
    expression='v(n_ba)-v(n_bb)'))

# ── 16. BehavioralCurrent — transconductance gm = 1 mA/V ─────────────────────
#   I_out = 1 mA/V × V_in;  V_out = I_out × 1 kΩ  →  V_out = V_in  (unity gain)
nt.addSource(sources.VoltageSource('bI_in',
    positive='n_bi_in', negative='0',
    sine=sources.Sine(voffset=0, vampl=1.0, freq=1e6)))
nt.addPassive(passives.Resistor('bi_in', pos='n_bi_in', neg='0', resistance=10e3))
nt.addSource(sources.BehavioralCurrent('bgm',
    positive='n_bgm', negative='0',
    expression='1e-3*v(n_bi_in)'))
nt.addPassive(passives.Resistor('bgm', pos='n_bgm', neg='0', resistance=1e3))

# ---------------------------------------------------------------------------
# Simulate: 1 ns step, 5 µs total
# ---------------------------------------------------------------------------
nt.addSimType(analysis.Transient(step=1e-9, stop=5e-6))

# simulate() replaces the old four-step sequence:
#   generateNetlist() → runSimulator() → loadFile() → readRawFile()
# It raises SimulationError if ngspice fails, so optimization loops can
# catch it without the process exiting.
nt.simulate(corner='tt')
nt.getSignalNames()

# ---------------------------------------------------------------------------
# Load signals
# ---------------------------------------------------------------------------
s_pulse      = nt.loadSignal('n_pulse')
s_sine       = nt.loadSignal('n_sine')
s_exp        = nt.loadSignal('n_exp')
s_pwl        = nt.loadSignal('n_pwl')
s_sffm       = nt.loadSignal('n_sffm')
s_am         = nt.loadSignal('n_am')
s_noise      = nt.loadSignal('n_noise')
s_rand       = nt.loadSignal('n_rand')
s_ibias      = nt.loadSignal('n_ibias')
s_ipulse     = nt.loadSignal('n_ipulse')
s_ctrl       = nt.loadSignal('n_ctrl')
s_vcvs       = nt.loadSignal('n_vcvs')
s_vccs       = nt.loadSignal('n_vccs')
s_ctrl_ccvs  = nt.loadSignal('n_ctrl_ccvs')
s_ccvs       = nt.loadSignal('n_ccvs')
s_ctrl_cccs  = nt.loadSignal('n_ctrl_cccs')
s_cccs       = nt.loadSignal('n_cccs')
s_ba         = nt.loadSignal('n_ba')
s_bb         = nt.loadSignal('n_bb')
s_bdiff      = nt.loadSignal('n_bdiff')
s_bi_in      = nt.loadSignal('n_bi_in')
s_bgm        = nt.loadSignal('n_bgm')

# ---------------------------------------------------------------------------
# Plot — 4×4 grid, one panel per source type
# ---------------------------------------------------------------------------
fig, axes = plt.subplots(4, 4, figsize=(16, 12))
fig.suptitle('silk Source Types — Transient Response', fontsize=14)


def us(x):
    """Seconds → microseconds."""
    return [v * 1e6 for v in x]


def panel(ax, title, x, traces, ylim=None):
    """traces: list of (label, y_array) tuples."""
    for label, y in traces:
        ax.plot(us(x), y, label=label or None, linewidth=0.8)
    ax.set_title(title, fontsize=9)
    ax.set_xlabel('Time (µs)', fontsize=7)
    ax.set_ylabel('V', fontsize=7)
    ax.tick_params(labelsize=7)
    if any(t[0] for t in traces):
        ax.legend(fontsize=6)
    if ylim:
        ax.set_ylim(ylim)


# Row 0 — basic waveform types
panel(axes[0, 0], 'Pulse',       s_pulse.x,  [('', s_pulse.y)],  ylim=[-0.2, 2.0])
panel(axes[0, 1], 'Sine',        s_sine.x,   [('', s_sine.y)],   ylim=[-1.2, 1.2])
panel(axes[0, 2], 'Exponential', s_exp.x,    [('', s_exp.y)],    ylim=[-0.2, 2.0])
panel(axes[0, 3], 'PWL',         s_pwl.x,    [('', s_pwl.y)],    ylim=[-0.2, 2.0])

# Row 1 — modulated and stochastic
panel(axes[1, 0], 'SFFM (FM)', s_sffm.x,  [('', s_sffm.y)],  ylim=[-1.2, 1.2])
panel(axes[1, 1], 'AM',        s_am.x,    [('', s_am.y)],    ylim=[-0.2, 1.8])
panel(axes[1, 2], 'Noise (filtered)', s_noise.x, [('', s_noise.y)])
panel(axes[1, 3], 'Random (Gaussian)', s_rand.x, [('', s_rand.y)])

# Row 2 — current sources and voltage-controlled sources
panel(axes[2, 0], 'DC CurrentSource',    s_ibias.x,  [('', s_ibias.y)],   ylim=[0.8, 1.2])
panel(axes[2, 1], 'Pulse CurrentSource', s_ipulse.x, [('', s_ipulse.y)],  ylim=[-0.2, 2.0])
panel(axes[2, 2], 'VCVS (gain=2)',       s_ctrl.x,
      [('ctrl', s_ctrl.y), ('out ×2', s_vcvs.y)])
panel(axes[2, 3], 'VCCS (gm=1mA/V)',     s_ctrl.x,
      [('ctrl', s_ctrl.y), ('out', s_vccs.y)])

# Row 3 — current-controlled and behavioral sources
panel(axes[3, 0], 'CCVS (Rtr=1kΩ)', s_ctrl_ccvs.x,
      [('ctrl', s_ctrl_ccvs.y), ('out', s_ccvs.y)])
panel(axes[3, 1], 'CCCS (gain=2)',   s_ctrl_cccs.x,
      [('ctrl', s_ctrl_cccs.y), ('out', s_cccs.y)])
panel(axes[3, 2], 'BehavioralV (A−B)', s_ba.x,
      [('A', s_ba.y), ('B', s_bb.y), ('A−B', s_bdiff.y)])
panel(axes[3, 3], 'BehavioralI (gm=1mA/V)', s_bi_in.x,
      [('in', s_bi_in.y), ('out', s_bgm.y)])

plt.tight_layout()
plt.show()
