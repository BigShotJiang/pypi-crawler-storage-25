"""silk — analog circuit design automation framework.

Install:  pip install circuitsilk
Import:   import silk  /  from silk import Module

Quick start::

    from silk import Module, ModuleTestbench
    from silk.pdk import PDK_skywater130
    from silk.simulation import Transient

"""
# Core circuit objects
from silk.circuit import Module, ModuleTestbench, ModuleVariable, VarType, Distribution, CornerResults
from silk.circuit import export_schema, module_schema, export_schema_json

# PDK
from silk.pdk import BasePDK, PDK_skywater130, UNIT_PDK, UNIT_SI, load_pdk

# Simulation analysis types and corner objects
from silk.simulation import Transient, AC, DC, Noise, Corner

# Signals
from silk.signals import Signal, NgspiceSignal

# Optimization
from silk.optimize import Space, Variable, Optimizer

# Database
from silk.db import Database, TrackedModule, DesignStage

# Sources
from silk import sources

# Code generation
from silk.codegen import Generator

# Exceptions
from silk.exceptions import (
    CircuitError,
    DuplicateNameError,
    UndeclaredNetError,
    SimulationError,
    PDKError,
)

__version__ = "0.1.0"

__all__ = [
    # circuit
    "Module", "ModuleTestbench", "ModuleVariable", "VarType", "Distribution", "CornerResults",
    "export_schema", "module_schema", "export_schema_json",
    # pdk
    "BasePDK", "PDK_skywater130", "UNIT_PDK", "UNIT_SI", "load_pdk",
    # simulation
    "Transient", "AC", "DC", "Noise", "Corner",
    # signals
    "Signal", "NgspiceSignal",
    # optimize
    "Space", "Variable", "Optimizer",
    # db
    "Database", "TrackedModule", "DesignStage",
    # sources
    "sources",
    # codegen
    "Generator",
    # exceptions
    "CircuitError", "DuplicateNameError", "UndeclaredNetError",
    "SimulationError", "PDKError",
]
