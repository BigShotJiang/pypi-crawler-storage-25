"""silk.exceptions — exception hierarchy."""


class CircuitError(Exception):
    """Base exception for all silk errors."""


class DuplicateNameError(CircuitError):
    """Raised when an element, net, source, or passive name already exists."""


class UndeclaredNetError(CircuitError):
    """Raised in strict_nets mode when a net has not been declared."""


class SimulationError(CircuitError):
    """Raised when simulation results are missing or a signal cannot be found."""


class PDKError(CircuitError):
    """Raised for PDK configuration errors (e.g., duplicate device in YAML)."""


# Backward-compat alias
PyNetlistError = CircuitError

__all__ = [
    "CircuitError", "DuplicateNameError", "UndeclaredNetError",
    "SimulationError", "PDKError", "PyNetlistError",
]
