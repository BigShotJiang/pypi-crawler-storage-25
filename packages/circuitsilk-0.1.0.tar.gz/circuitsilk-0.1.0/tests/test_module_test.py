from silk.circuit.spec_report import SpecReport
"""
Tests for PyModuleTest — testbench creation, source/sim delegation,
metric extraction, and run() lifecycle.
"""

import os
import sys
import pytest
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from silk.circuit.module_test import PyModuleTest
from silk.circuit.modules import PyModule
from silk import sources


# ---------------------------------------------------------------------------
# Helper: create a configured module for testing
# ---------------------------------------------------------------------------

@pytest.fixture
def configured_module(pdk, tmp_dir):
    """A PyModule with name, pins, and devices — ready for PyModuleTest."""
    mod = PyModule('PDK_skywater130', tmp_dir, 'dut.cir', pdkDetails=pdk)
    mod.defineModuleName('test_inv')
    mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})

    mod.addElement(pdk.nmos1p8, 'mn',
                   nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                   parameters={'w': 1, 'l': 0.15, 'm': 1})
    mod.addElement(pdk.pmos1p8, 'mp',
                   nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                   parameters={'w': 2, 'l': 0.15, 'm': 1})
    return mod


# ---------------------------------------------------------------------------
# Constructor tests
# ---------------------------------------------------------------------------

class TestPyModuleTestConstructor:

    def test_create_via_module(self, configured_module):
        """create_test() on a PyModule returns a PyModuleTest instance."""
        test = configured_module.create_test('basic')
        assert isinstance(test, PyModuleTest)

    def test_direct_constructor(self, configured_module):
        """PyModuleTest can be created directly with module and name."""
        test = PyModuleTest(configured_module, 'direct')
        assert test.test_name == 'direct'
        assert test.module is configured_module

    def test_default_name(self, configured_module):
        """Default test name is 'default_test'."""
        test = PyModuleTest(configured_module)
        assert test.test_name == 'default_test'

    def test_metrics_initially_empty(self, configured_module):
        """Metrics list starts empty."""
        test = PyModuleTest(configured_module, 'mt')
        assert test._metrics == []

    def test_netlist_initially_none(self, configured_module):
        """Internal netlist is None until add_module_under_test or addSource."""
        test = PyModuleTest(configured_module, 'mt')
        assert test.netlist is None

    def test_module_not_added_initially(self, configured_module):
        """_module_added is False initially."""
        test = PyModuleTest(configured_module, 'mt')
        assert test._module_added is False


# ---------------------------------------------------------------------------
# add_module_under_test tests
# ---------------------------------------------------------------------------

class TestAddModuleUnderTest:

    def test_sets_module_added_flag(self, configured_module):
        """add_module_under_test sets _module_added to True."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        assert test._module_added is True

    def test_creates_internal_netlist(self, configured_module):
        """add_module_under_test creates the internal PyNetlist."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        assert test.netlist is not None

    def test_dut_in_netlist_elem_dict(self, configured_module):
        """The DUT instance appears in the internal netlist's elem_dict."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        assert 'dut' in test.netlist.elem_dict

    def test_returns_self_for_chaining(self, configured_module):
        """add_module_under_test returns self for method chaining."""
        test = configured_module.create_test('t1')
        result = test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        assert result is test

    def test_double_add_raises(self, configured_module):
        """Calling add_module_under_test twice raises ValueError."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        with pytest.raises(ValueError, match="already added"):
            test.add_module_under_test({
                'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
            })


# ---------------------------------------------------------------------------
# addSource delegation tests
# ---------------------------------------------------------------------------

class TestAddSourceDelegation:

    def test_source_in_internal_netlist(self, configured_module):
        """addSource() creates a source in the internal netlist."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        test.addSource(sources.VoltageSource('vsup', positive='vdd', negative='0', dc=1.8))

        assert 'vsup' in test.netlist.sigSources_dict

    def test_source_returns_self(self, configured_module):
        """addSource returns self for chaining."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        result = test.addSource(sources.VoltageSource('vsup', positive='vdd', negative='0', dc=1.8))
        assert result is test

    def test_source_before_add_module_creates_netlist(self, configured_module):
        """addSource before add_module_under_test creates the internal netlist."""
        test = configured_module.create_test('t1')
        test.addSource(sources.VoltageSource('vsup', positive='', negative='', dc=1.8))
        assert test.netlist is not None
        assert 'vsup' in test.netlist.sigSources_dict


# ---------------------------------------------------------------------------
# addSimType delegation tests
# ---------------------------------------------------------------------------

class TestAddSimTypeDelegation:

    def test_simtype_in_internal_netlist(self, configured_module):
        """addSimType() populates the internal netlist's simAnalysis_dict."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        test.addSimType('transient', ['1n', '100n'])

        assert 'transient' in test.netlist.simAnalysis_dict

    def test_simtype_returns_self(self, configured_module):
        """addSimType returns self for chaining."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        result = test.addSimType('transient', ['1n', '100n'])
        assert result is test


# ---------------------------------------------------------------------------
# addCustomLine delegation tests
# ---------------------------------------------------------------------------

class TestAddCustomLineDelegation:

    def test_custom_line_delegated(self, configured_module):
        """addCustomLine() appends to internal netlist's customList_list."""
        test = configured_module.create_test('t1')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        test.addCustomLine('cload vout 0 10p')
        assert 'cload vout 0 10p' in test.netlist.customList_list

    def test_custom_line_returns_self(self, configured_module):
        """addCustomLine returns self for chaining."""
        test = configured_module.create_test('t1')
        result = test.addCustomLine('rload out vdd 1k')
        assert result is test


# ---------------------------------------------------------------------------
# add_metric tests
# ---------------------------------------------------------------------------

class TestAddMetric:

    def test_metric_added_to_list(self, configured_module):
        """add_metric() appends to the _metrics list."""
        test = configured_module.create_test('t1')
        test.add_metric('vout_avg', lambda nr: 1.0)
        assert len(test._metrics) == 1
        assert test._metrics[0]['name'] == 'vout_avg'

    def test_multiple_metrics(self, configured_module):
        """Multiple metrics can be added."""
        test = configured_module.create_test('t1')
        test.add_metric('m1', lambda nr: 1.0)
        test.add_metric('m2', lambda nr: 2.0)
        assert len(test._metrics) == 2

    def test_metric_returns_self(self, configured_module):
        """add_metric returns self for chaining."""
        test = configured_module.create_test('t1')
        result = test.add_metric('m1', lambda nr: 1.0)
        assert result is test

    def test_metric_extractor_stored(self, configured_module):
        """The extractor function is stored and callable."""
        func = lambda nr: 42
        test = configured_module.create_test('t1')
        test.add_metric('answer', func)
        assert test._metrics[0]['extractor'] is func


# ---------------------------------------------------------------------------
# run() tests
# ---------------------------------------------------------------------------

class TestRun:

    def _setup_test(self, configured_module):
        """Helper to set up a fully configured test."""
        test = configured_module.create_test('run_test')
        test.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        test.addSource(sources.VoltageSource('vsup', positive='vdd', negative='0', dc=1.8))
        test.addSource(sources.VoltageSource('vin_src', positive='vin', negative='0', dc=0.9))
        test.addSimType('transient', ['1n', '100n'])
        return test

    def test_run_without_module_raises(self, configured_module):
        """run() without add_module_under_test raises ValueError."""
        test = configured_module.create_test('t1')
        with pytest.raises(ValueError, match="add_module_under_test"):
            test.run()

    def test_run_with_mock_returns_dict(self, configured_module, mock_ngspice):
        """run() with mocked simulation returns a result dict with expected keys."""
        test = self._setup_test(configured_module)

        # Mock loadFile and readRawFile since we don't have real sim output
        test.netlist.loadFile = MagicMock()
        test.netlist.readRawFile = MagicMock()

        result = test.run(corner='tt')

        assert isinstance(result, SpecReport)
        assert result.test_name == 'run_test'
        assert result.module_name == 'test_inv'
        assert hasattr(result, 'metrics')
        assert hasattr(result, 'sim_results')

    def test_run_calls_generate_and_simulate(self, configured_module, mock_ngspice):
        """run() calls generateNetlist and runSimulator."""
        test = self._setup_test(configured_module)

        test.netlist.loadFile = MagicMock()
        test.netlist.readRawFile = MagicMock()

        test.run(corner='tt')

        # Verify ngspice was called
        assert mock_ngspice['called']

        # Verify netlist file was generated
        assert os.path.isfile(test.netlist.netlistname)

    def test_run_extracts_metrics(self, configured_module, mock_ngspice):
        """run() calls each metric extractor with the netlist object."""
        test = self._setup_test(configured_module)

        extractor_called = {'called': False, 'arg': None}

        def mock_extractor(nr):
            extractor_called['called'] = True
            extractor_called['arg'] = nr
            return 42.0

        test.add_metric('test_metric', mock_extractor)

        test.netlist.loadFile = MagicMock()
        test.netlist.readRawFile = MagicMock()

        result = test.run(corner='tt')

        assert extractor_called['called']
        assert extractor_called['arg'] is test.netlist
        assert result.metrics['test_metric'] == 42.0

    def test_run_handles_metric_error(self, configured_module, mock_ngspice):
        """run() gracefully handles metric extraction errors."""
        test = self._setup_test(configured_module)

        def bad_extractor(nr):
            raise RuntimeError("metric failed")

        test.add_metric('bad_metric', bad_extractor)

        test.netlist.loadFile = MagicMock()
        test.netlist.readRawFile = MagicMock()

        result = test.run(corner='tt')

        # Should contain error string, not raise
        assert 'Error' in str(result.metrics['bad_metric'])

    def test_run_with_different_corner(self, configured_module, mock_ngspice):
        """run() passes corner parameter to generateNetlist."""
        test = self._setup_test(configured_module)

        test.netlist.loadFile = MagicMock()
        test.netlist.readRawFile = MagicMock()

        test.run(corner='ff')

        # Verify the netlist file contains 'ff' corner
        content = open(test.netlist.netlistname).read()
        assert 'ff' in content


# ---------------------------------------------------------------------------
# has_tests / run_all_tests via PyModule tests
# ---------------------------------------------------------------------------

class TestModuleTestIntegration:

    def test_has_tests_via_module(self, configured_module):
        """has_tests() returns True after create_test()."""
        configured_module.create_test('t1')
        assert configured_module.has_tests() is True

    def test_run_all_tests_runs_all(self, configured_module, mock_ngspice):
        """run_all_tests() runs all defined tests and returns results dict."""
        test1 = configured_module.create_test('test_a')
        test1.add_module_under_test({
            'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
        })
        test1.addSource(sources.VoltageSource('vsup', positive='vdd', negative='0', dc=1.8))
        test1.addSimType('transient', ['1n', '100n'])

        # Mock loadFile/readRawFile on the internal netlist
        test1.netlist.loadFile = MagicMock()
        test1.netlist.readRawFile = MagicMock()

        results = configured_module.run_all_tests(recursive=False)

        assert isinstance(results, dict)
        # Key format is "module_name.test_name"
        expected_key = f"{configured_module.module_name}.test_a"
        assert expected_key in results

    def test_run_test_nonexistent_raises(self, configured_module):
        """run_test() with unknown name raises ValueError."""
        with pytest.raises(ValueError, match="No test"):
            configured_module.run_test('nonexistent')

    def test_get_all_testable_modules(self, configured_module):
        """get_all_testable_modules() includes module with tests."""
        configured_module.create_test('t1')
        testable = configured_module.get_all_testable_modules()
        assert len(testable) == 1
        assert testable[0]['module'] == configured_module.module_name
        assert 't1' in testable[0]['tests']

    def test_get_all_testable_modules_empty(self, configured_module):
        """get_all_testable_modules() returns empty when no tests defined."""
        testable = configured_module.get_all_testable_modules()
        assert len(testable) == 0


# ---------------------------------------------------------------------------
# Method chaining test
# ---------------------------------------------------------------------------

class TestMethodChaining:

    def test_full_chain(self, configured_module):
        """All builder methods support chaining."""
        test = configured_module.create_test('chain')
        result = (
            test
            .add_module_under_test({
                'in': 'vin', 'out': 'vout', 'vdd': 'vdd', 'gnd': '0'
            })
            .addSource(sources.VoltageSource('vsup', positive='vdd', negative='0', dc=1.8))
            .addSimType('transient', ['1n', '100n'])
            .addCustomLine('cload vout 0 10p')
            .add_metric('dummy', lambda nr: 0)
        )
        assert result is test


# ---------------------------------------------------------------------------
# Lazy netlist creation in addSimType / run() guard (lines 105, 144)
# ---------------------------------------------------------------------------

class TestLazyNetlistCreation:

    def test_addSimType_before_add_module_creates_netlist(self, configured_module):
        """addSimType() with netlist=None triggers lazy _create_netlist()."""
        test = configured_module.create_test('lazy_sim')
        assert test.netlist is None
        test.addSimType('transient', ['1n', '100n'])
        assert test.netlist is not None
        assert 'transient' in test.netlist.simAnalysis_dict

    def test_run_raises_when_module_added_but_netlist_none(self, configured_module):
        """run() raises ValueError when _module_added=True but netlist is None."""
        test = configured_module.create_test('no_netlist')
        test._module_added = True  # bypass normal setup
        # netlist stays None
        with pytest.raises(ValueError):
            test.run(corner='tt')


# ---------------------------------------------------------------------------
# TestRunCorners
# ---------------------------------------------------------------------------

def _make_spec_report(corner):
    """Helper: return a passing SpecReport for the given corner."""
    r = SpecReport(test_name=corner, module_name='inv', metrics={'gain': 65.0})
    r.check('Gain > 60', 'gain', '>', 60.0)
    return r


class TestRunCorners:

    def test_run_corners_returns_corner_results(self, configured_module):
        """run_corners() returns a CornerResults object."""
        from silk.circuit.spec_report import CornerResults
        from unittest.mock import patch
        test = configured_module.create_test('c1')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners(corners=('tt', 'ff'))
        assert isinstance(result, CornerResults)

    def test_run_corners_keys(self, configured_module):
        """run_corners() dict keys match the requested corners."""
        from unittest.mock import patch
        test = configured_module.create_test('c2')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners(corners=('tt', 'ff'))
        assert set(result.keys()) == {'tt', 'ff'}

    def test_run_corners_default_five(self, configured_module):
        """Default corners are tt, ff, ss, sf, fs."""
        from unittest.mock import patch
        test = configured_module.create_test('c3')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners()
        assert set(result.keys()) == {'tt', 'ff', 'ss', 'sf', 'fs'}

    def test_run_corners_values_are_spec_reports(self, configured_module):
        """Each value in run_corners() result is a SpecReport."""
        from unittest.mock import patch
        test = configured_module.create_test('c4')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners(corners=('tt',))
        assert all(isinstance(r, SpecReport) for r in result.values())

    def test_run_corners_passed_all_pass(self, configured_module):
        """CornerResults.passed is True when all corners pass."""
        from unittest.mock import patch
        test = configured_module.create_test('c5')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners(corners=('tt', 'ff'))
        assert result.passed is True

    def test_run_corners_passed_one_fail(self, configured_module):
        """CornerResults.passed is False when any corner fails."""
        from silk.circuit.spec_report import SpecReport as SR
        from unittest.mock import patch

        def make_failing(corner):
            r = SR(test_name=corner, module_name='inv', metrics={'gain': 50.0})
            r.check('Gain > 60', 'gain', '>', 60.0)
            return r

        test = configured_module.create_test('c6')
        with patch.object(test, 'run', side_effect=make_failing):
            result = test.run_corners(corners=('tt',))
        assert result.passed is False

    def test_run_corners_getitem(self, configured_module):
        """CornerResults[corner] returns the SpecReport for that corner."""
        from unittest.mock import patch
        test = configured_module.create_test('c7')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners(corners=('tt',))
        assert result['tt'].passed is True

    def test_corner_results_summary_contains_pass(self, configured_module):
        """CornerResults.summary() contains PASS when all pass."""
        from unittest.mock import patch
        test = configured_module.create_test('c8')
        with patch.object(test, 'run', side_effect=_make_spec_report):
            result = test.run_corners(corners=('tt',))
        assert 'PASS' in result.summary()

    def test_corner_results_importable_from_silk(self):
        from silk import CornerResults
        assert CornerResults is not None
