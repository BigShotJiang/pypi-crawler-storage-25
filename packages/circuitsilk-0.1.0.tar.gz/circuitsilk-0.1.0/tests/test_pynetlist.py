"""
Tests for PyNetlist — the main netlist class integrating elements, sources,
netlist generation, and simulation invocation.
"""

import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import silk.circuit.netlist as pn
from silk import sources
from silk.exceptions import PyNetlistError


def _make_fake_circuit_db_module():
    """Return a MagicMock module with a DesignStage enum for test injection."""
    from unittest.mock import MagicMock
    from enum import Enum

    class DesignStage(Enum):
        DEV = 'dev'
        STABLE = 'stable'
        POST_LAYOUT = 'post_layout'
        TAPEOUT = 'tapeout'

    fake = MagicMock()
    fake.DesignStage = DesignStage
    return fake


# ---------------------------------------------------------------------------
# Fixtures that include the 'm' parameter (required by generateNetlistEntry)
# ---------------------------------------------------------------------------

@pytest.fixture
def full_param_netlist(pdk, tmp_dir):
    """PyNetlist with devices that have all params (w, l, m) set."""
    ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'full.cir', pdkDetails=pdk)
    ckt.addNet('vdd')
    ckt.addNet('gnd')
    ckt.addNet('in')
    ckt.addNet('out')

    ckt.addElement(pdk.nmos1p8, 'mn1',
                   nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                   parameters={'w': 1, 'l': 0.15, 'm': 1})
    ckt.addElement(pdk.pmos1p8, 'mp1',
                   nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                   parameters={'w': 2, 'l': 0.15, 'm': 1})

    ckt.addSource(sources.VoltageSource('vdd_supply', positive='vdd', negative='gnd', dc=1.8))
    ckt.addSource(sources.VoltageSource('vin', positive='in', negative='gnd', dc=0.9))
    ckt.addSimType('transient', ['1n', '100n'])

    return ckt


# ---------------------------------------------------------------------------
# Constructor tests
# ---------------------------------------------------------------------------

class TestPyNetlistConstructor:

    def test_instance_attributes(self, pdk, tmp_dir):
        """Constructor sets dirFolder, netlistname, PDKname, and empty dicts."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'ctor.cir', pdkDetails=pdk)

        assert ckt.dirFolder == tmp_dir
        assert ckt.netlistname == os.path.join(tmp_dir, 'ctor.cir')
        assert ckt.PDKname == 'PDK_skywater130'
        assert isinstance(ckt.elem_dict, dict) and len(ckt.elem_dict) == 0
        assert isinstance(ckt.net_dict, dict)
        assert isinstance(ckt.sigSources_dict, dict) and len(ckt.sigSources_dict) == 0
        assert isinstance(ckt.simAnalysis_dict, dict) and len(ckt.simAnalysis_dict) == 0
        assert isinstance(ckt.customList_list, list) and len(ckt.customList_list) == 0

    def test_pdk_details_attached(self, empty_netlist, pdk):
        """PDK details object is stored on the instance."""
        assert empty_netlist.pdkDetails is pdk

    def test_tracking_disabled_by_default(self, empty_netlist):
        """Database tracking is off when no circuit_name/db_path given."""
        assert empty_netlist._tracking_enabled is False


# ---------------------------------------------------------------------------
# addElement tests
# ---------------------------------------------------------------------------

class TestAddElement:

    def test_element_appears_in_elem_dict(self, empty_netlist, pdk):
        """After addElement, the element name exists in elem_dict."""
        empty_netlist.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15, 'm': 1},
        )
        assert 'mn1' in empty_netlist.elem_dict

    def test_element_has_correct_type(self, empty_netlist, pdk):
        """Device elements have type 'd'."""
        empty_netlist.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15, 'm': 1},
        )
        assert empty_netlist.elem_dict['mn1']['type'] == 'd'

    def test_element_has_correct_typename(self, empty_netlist, pdk):
        """Element typeName matches the PDK device name."""
        empty_netlist.addElement(
            pdk.pmos1p8, 'mp1',
            nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
            parameters={'w': 2, 'l': 0.15, 'm': 1},
        )
        assert empty_netlist.elem_dict['mp1']['typeName'] == pdk.pmos1p8.device_name

    def test_duplicate_name_exits(self, basic_netlist, pdk):
        """Adding an element with a duplicate name raises PyNetlistError."""
        with pytest.raises(PyNetlistError):
            basic_netlist.addElement(
                pdk.nmos1p8, 'mn1',
                nets={'d': 'x', 'g': 'x', 's': 'x', 'b': 'x'},
            )

    def test_nets_auto_created(self, empty_netlist, pdk):
        """Nets passed in addElement are auto-added to net_dict."""
        empty_netlist.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
        )
        for net_name in ('out', 'in', 'gnd'):
            assert net_name in empty_netlist.net_dict


# ---------------------------------------------------------------------------
# addSource tests
# ---------------------------------------------------------------------------

class TestAddSource:

    def test_source_appears_in_dict(self, basic_netlist):
        """After addSource, source name exists in sigSources_dict."""
        basic_netlist.addSource(
            sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8)
        )
        assert 'vsup' in basic_netlist.sigSources_dict

    def test_source_type_stored(self, basic_netlist):
        """Source entry records the correct type."""
        basic_netlist.addSource(
            sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8)
        )
        assert isinstance(basic_netlist.sigSources_dict['vsup'], sources.VoltageSource)

    def test_duplicate_source_exits(self, basic_netlist):
        """Adding a source with a duplicate name raises PyNetlistError."""
        basic_netlist.addSource(sources.VoltageSource('v1', positive='vdd', negative='gnd', dc=1.8))
        with pytest.raises(PyNetlistError):
            basic_netlist.addSource(sources.VoltageSource('v1', positive='vdd', negative='gnd', dc=1.0))

    def test_invalid_source_type_exits(self, basic_netlist):
        """Passing a non-source object raises PyNetlistError."""
        with pytest.raises(PyNetlistError):
            basic_netlist.addSource('not_a_source')

    def test_source_dc_parameter(self, basic_netlist):
        """DC parameter value is stored correctly."""
        basic_netlist.addSource(
            sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=3.3)
        )
        src = basic_netlist.sigSources_dict['vsup']
        assert src.dc == 3.3


# ---------------------------------------------------------------------------
# addNet tests
# ---------------------------------------------------------------------------

class TestAddNet:

    def test_net_appears_in_dict(self, empty_netlist):
        """addNet creates an entry in net_dict."""
        empty_netlist.addNet('vdd')
        assert 'vdd' in empty_netlist.net_dict

    def test_duplicate_net_no_error(self, empty_netlist):
        """Adding the same net twice does not raise; it's a no-op."""
        empty_netlist.addNet('vdd')
        empty_netlist.addNet('vdd')  # should not error
        assert 'vdd' in empty_netlist.net_dict


# ---------------------------------------------------------------------------
# addSimType tests
# ---------------------------------------------------------------------------

class TestAddSimType:

    def test_transient_sim_added(self, empty_netlist):
        """addSimType('transient', ...) populates simAnalysis_dict."""
        empty_netlist.addSimType('transient', ['1n', '100n'])
        assert 'transient' in empty_netlist.simAnalysis_dict
        assert empty_netlist.simAnalysis_dict['transient']['tstep'] == '1n'
        assert empty_netlist.simAnalysis_dict['transient']['tstop'] == '100n'

    def test_invalid_sim_type_exits(self, empty_netlist):
        """An unrecognised sim type raises PyNetlistError."""
        with pytest.raises(PyNetlistError):
            empty_netlist.addSimType('monte_carlo', ['100'])

    def test_wrong_detail_count_exits(self, empty_netlist):
        """Wrong number of detail parameters raises PyNetlistError."""
        with pytest.raises(PyNetlistError):
            empty_netlist.addSimType('transient', ['1n'])  # needs 2 params


# ---------------------------------------------------------------------------
# addCustomLine tests
# ---------------------------------------------------------------------------

class TestAddCustomLine:

    def test_custom_line_stored(self, empty_netlist):
        """addCustomLine appends to customList_list."""
        empty_netlist.addCustomLine('cload out 0 10p')
        assert 'cload out 0 10p' in empty_netlist.customList_list

    def test_multiple_custom_lines(self, empty_netlist):
        """Multiple custom lines are all stored in order."""
        empty_netlist.addCustomLine('rload out vdd 1k')
        empty_netlist.addCustomLine('cload out 0 10p')
        assert len(empty_netlist.customList_list) == 2
        assert empty_netlist.customList_list[0] == 'rload out vdd 1k'


# ---------------------------------------------------------------------------
# generateNetlist tests
# ---------------------------------------------------------------------------

class TestGenerateNetlist:

    def test_file_written_to_disk(self, full_param_netlist):
        """generateNetlist() writes a file at the expected path."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        assert os.path.isfile(ckt.netlistname)

    def test_file_contains_device_names(self, full_param_netlist):
        """Generated netlist contains the device instance names."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read()
        assert 'mn1' in content
        assert 'mp1' in content

    def test_file_contains_lib_include(self, full_param_netlist):
        """Generated netlist contains a .lib include directive."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read()
        assert '.lib' in content.lower()

    def test_file_contains_simulation_command(self, full_param_netlist):
        """Generated netlist contains the transient simulation command."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read()
        assert '.tran' in content.lower() or 'tran' in content.lower()

    def test_corner_tt_in_lib_line(self, full_param_netlist):
        """Corner 'tt' appears in the .lib line."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read()
        assert 'tt' in content

    def test_corner_ff_in_lib_line(self, full_param_netlist):
        """Corner 'ff' appears in the .lib line when specified."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='ff')
        content = open(ckt.netlistname).read()
        assert 'ff' in content

    def test_corner_ss_in_lib_line(self, full_param_netlist):
        """Corner 'ss' appears in the .lib line when specified."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='ss')
        content = open(ckt.netlistname).read()
        assert 'ss' in content

    def test_file_contains_end_directive(self, full_param_netlist):
        """Generated netlist contains an .end directive."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read().lower()
        assert '.end' in content

    # ------------------------------------------------------------------
    # simulate() convenience method
    # ------------------------------------------------------------------

    def test_simulate_writes_netlist_file(self, full_param_netlist, monkeypatch):
        """simulate() writes the netlist file (generateNetlist step fires)."""
        ckt = full_param_netlist

        # Stub out the parts that need ngspice
        monkeypatch.setattr(ckt, 'runSimulator', lambda **kw: None)
        monkeypatch.setattr(ckt, 'loadFile',     lambda path: None)
        monkeypatch.setattr(ckt, 'readRawFile',  lambda: None)

        ckt.simulate(corner='tt')
        assert os.path.isfile(ckt.netlistname)

    def test_simulate_returns_self(self, full_param_netlist, monkeypatch):
        """simulate() returns the same PyNetlist instance for chaining."""
        ckt = full_param_netlist
        monkeypatch.setattr(ckt, 'runSimulator', lambda **kw: None)
        monkeypatch.setattr(ckt, 'loadFile',     lambda path: None)
        monkeypatch.setattr(ckt, 'readRawFile',  lambda: None)

        result = ckt.simulate(corner='tt')
        assert result is ckt

    def test_simulate_corner_forwarded(self, full_param_netlist, monkeypatch):
        """simulate() forwards the corner argument to generateNetlist."""
        ckt = full_param_netlist
        captured = {}

        original_generate = ckt.generateNetlist
        def capturing_generate(corner='tt'):
            captured['corner'] = corner
            original_generate(corner=corner)
        monkeypatch.setattr(ckt, 'generateNetlist', capturing_generate)
        monkeypatch.setattr(ckt, 'runSimulator',    lambda **kw: None)
        monkeypatch.setattr(ckt, 'loadFile',        lambda path: None)
        monkeypatch.setattr(ckt, 'readRawFile',     lambda: None)

        ckt.simulate(corner='ss')
        assert captured['corner'] == 'ss'

    def test_simulate_calls_all_steps(self, full_param_netlist, monkeypatch):
        """simulate() invokes generateNetlist, runSimulator, loadFile, readRawFile."""
        ckt = full_param_netlist
        calls = []

        original_gen = ckt.generateNetlist
        monkeypatch.setattr(ckt, 'generateNetlist', lambda corner='tt': (calls.append('generate'), original_gen(corner=corner)))
        monkeypatch.setattr(ckt, 'runSimulator',    lambda **kw:        calls.append('run'))
        monkeypatch.setattr(ckt, 'loadFile',        lambda path:        calls.append('load'))
        monkeypatch.setattr(ckt, 'readRawFile',     lambda:             calls.append('read'))

        ckt.simulate(corner='tt')
        assert calls == ['generate', 'run', 'load', 'read']

    def test_custom_line_in_output(self, full_param_netlist):
        """Custom lines appear in the generated netlist."""
        ckt = full_param_netlist
        ckt.addCustomLine('cload out 0 10p')
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read()
        assert 'cload out 0 10p' in content

    def test_source_names_in_output(self, full_param_netlist):
        """Source names appear in the generated netlist."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        content = open(ckt.netlistname).read()
        assert 'vdd_supply' in content
        assert 'vin' in content


# ---------------------------------------------------------------------------
# runSimulator tests
# ---------------------------------------------------------------------------

class TestRunSimulator:

    def test_run_calls_ngspice(self, full_param_netlist, mock_ngspice):
        """runSimulator() calls os.system with a command containing 'ngspice'."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator()
        assert mock_ngspice['called']
        assert 'ngspice' in mock_ngspice['command']

    def test_run_command_contains_netlist_path(self, full_param_netlist, mock_ngspice):
        """The ngspice command includes the netlist file path."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator()
        assert ckt.netlistname in mock_ngspice['command']

    def test_run_sets_results_file(self, full_param_netlist, mock_ngspice):
        """After runSimulator(), resultsFile attribute is set."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator()
        assert hasattr(ckt, 'resultsFile')
        assert 'rawfile.raw' in ckt.resultsFile

    def test_run_command_contains_raw_flag(self, full_param_netlist, mock_ngspice):
        """The ngspice command includes -r for raw file output."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator()
        assert '-r' in mock_ngspice['command']

    def test_run_command_contains_batch_flag(self, full_param_netlist, mock_ngspice):
        """The ngspice command includes -b for batch mode."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator()
        assert '-b' in mock_ngspice['command']


# ---------------------------------------------------------------------------
# printElements / printNets tests
# ---------------------------------------------------------------------------

class TestPrintMethods:

    def test_print_elements_no_error(self, basic_netlist, capsys):
        """printElements() runs without error and produces output."""
        basic_netlist.printElements()
        captured = capsys.readouterr()
        assert 'mn1' in captured.out
        assert 'mp1' in captured.out

    def test_print_nets_no_error(self, basic_netlist, capsys):
        """printNets() runs without error and produces output."""
        basic_netlist.printNets()
        captured = capsys.readouterr()
        assert 'vdd' in captured.out
        assert 'gnd' in captured.out


# ---------------------------------------------------------------------------
# Full flow integration test
# ---------------------------------------------------------------------------

class TestFullFlow:

    def test_add_generate_run(self, pdk, tmp_dir, mock_ngspice):
        """Full flow: create netlist → add elements → sources → sim → generate → run."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'flow.cir', pdkDetails=pdk)

        ckt.addNet('vdd')
        ckt.addNet('gnd')
        ckt.addNet('in')
        ckt.addNet('out')

        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15, 'm': 1})

        ckt.addElement(pdk.pmos1p8, 'mp1',
                       nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                       parameters={'w': 2, 'l': 0.15, 'm': 1})

        ckt.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))

        ckt.addSource(sources.VoltageSource('vin', positive='in', negative='gnd', dc=0.9))

        ckt.addSimType('transient', ['1n', '100n'])

        ckt.generateNetlist(corner='tt')
        assert os.path.isfile(ckt.netlistname)

        ckt.runSimulator()
        assert mock_ngspice['called']
        assert mock_ngspice['call_count'] == 1

    def test_multiple_simulations_increment_count(self, full_param_netlist, mock_ngspice):
        """Running the simulator multiple times increments the call count."""
        ckt = full_param_netlist
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator()
        ckt.runSimulator()
        assert mock_ngspice['call_count'] == 2


# ---------------------------------------------------------------------------
# netlistHeader tests
# ---------------------------------------------------------------------------

class TestNetlistHeader:

    def test_set_header(self, empty_netlist):
        """netlistHeader() sets the header attribute."""
        empty_netlist.netlistHeader('My Test Circuit')
        assert empty_netlist.netlistHeader == 'My Test Circuit'


# ---------------------------------------------------------------------------
# addSource — additional coverage for uncovered branches
# ---------------------------------------------------------------------------

class TestAddSourceBranches:

    def test_source_with_no_nets_and_no_params(self, basic_netlist):
        """Adding a VoltageSource with default dc=0 and empty strings for nets."""
        basic_netlist.addSource(sources.VoltageSource('vsup', positive='', negative=''))
        src = basic_netlist.sigSources_dict['vsup']
        assert isinstance(src, sources.VoltageSource)
        assert src.dc == 0

    def test_source_with_nets(self, basic_netlist):
        """Adding a VoltageSource with explicit nets."""
        basic_netlist.addSource(
            sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8)
        )
        src = basic_netlist.sigSources_dict['vsup']
        assert src.positive == 'vdd'
        assert src.negative == 'gnd'

    def test_source_current_type(self, basic_netlist):
        """Adding a CurrentSource stores correctly."""
        basic_netlist.addSource(
            sources.CurrentSource('ibias', positive='vb', negative='gnd', dc=100e-6)
        )
        src = basic_netlist.sigSources_dict['ibias']
        assert isinstance(src, sources.CurrentSource)
        assert src.dc == 100e-6

    def test_source_debug_mode(self, pdk, tmp_dir, capsys):
        """Adding a source with debug=True prints debug info."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'dbg.cir',
                           pdkDetails=pdk, debug=True)
        ckt.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))
        captured = capsys.readouterr()
        assert 'Added source' in captured.out


# ---------------------------------------------------------------------------
# updateSource / connectSource error paths
# ---------------------------------------------------------------------------

class TestUpdateSourceErrors:

    def test_update_nonexistent_source(self, basic_netlist):
        """updateSource raises PyNetlistError for nonexistent source."""
        with pytest.raises(PyNetlistError):
            basic_netlist.updateSource('nonexistent', ['dc'], [1.0])

    def test_connect_nonexistent_source(self, basic_netlist):
        """connectSource raises PyNetlistError for nonexistent source."""
        with pytest.raises(PyNetlistError):
            basic_netlist.connectSource('nonexistent', ['positive'], ['vdd'])

    def test_connect_source_undefined_net(self, basic_netlist):
        """connectSource raises an error when net is undefined or source format is incompatible."""
        basic_netlist.addSource(sources.VoltageSource('vsup', positive='', negative=''))
        with pytest.raises(Exception):
            basic_netlist.connectSource('vsup', ['positive'], ['undefined_net'])


# ---------------------------------------------------------------------------
# updateNet tests
# ---------------------------------------------------------------------------

class TestUpdateNet:

    def test_update_existing_net(self, empty_netlist):
        """updateNet updates parameters of an existing net."""
        empty_netlist.addNet('vdd')
        empty_netlist.updateNet('vdd', ['max_voltage=1.8'])
        assert empty_netlist.net_dict['vdd'] == ['max_voltage=1.8']

    def test_update_nonexistent_net(self, empty_netlist):
        """updateNet raises PyNetlistError for a nonexistent net."""
        with pytest.raises(PyNetlistError):
            empty_netlist.updateNet('nonexistent', ['param=1'])


# ---------------------------------------------------------------------------
# loadFile / getOutputSignalList / getSignalNames / loadSignal error paths
# ---------------------------------------------------------------------------

class TestLoadAndSignalErrors:

    def test_load_file_sets_datafile(self, empty_netlist):
        """loadFile stores the dataFile attribute."""
        empty_netlist.loadFile('/some/path/data.raw')
        assert empty_netlist.dataFile == '/some/path/data.raw'

    def test_get_signal_names_without_results(self, empty_netlist):
        """getSignalNames raises PyNetlistError when results not loaded."""
        with pytest.raises(PyNetlistError, match='not loaded'):
            empty_netlist.getSignalNames()

    def test_load_signal_without_results(self, empty_netlist):
        """loadSignal raises PyNetlistError when results not loaded."""
        with pytest.raises(PyNetlistError, match='not Loaded'):
            empty_netlist.loadSignal('out')


# ---------------------------------------------------------------------------
# DevicePrimitives tests
# ---------------------------------------------------------------------------

class TestDevicePrimitives:

    def test_create_resistor(self):
        """DevicePrimitives creates a resistor."""
        dp = pn.DevicePrimitives('resistor')
        assert dp.deviceType == 'resistor'
        assert dp.terminal_p is None

    def test_create_capacitor(self):
        """DevicePrimitives creates a capacitor."""
        dp = pn.DevicePrimitives('capacitor')
        assert dp.deviceType == 'capacitor'

    def test_create_inductor(self):
        """DevicePrimitives creates an inductor."""
        dp = pn.DevicePrimitives('inductor')
        assert dp.deviceType == 'inductor'

    def test_invalid_device_type(self):
        """DevicePrimitives raises PyNetlistError for invalid type."""
        with pytest.raises(PyNetlistError):
            pn.DevicePrimitives('transformer')

    def test_set_properties_resistor(self):
        """setPropertiesResistor sets all properties."""
        dp = pn.DevicePrimitives('resistor')
        dp.setPropertiesResistor('node_a', 'node_b', 1000)
        assert dp.terminal_p == 'node_a'
        assert dp.terminal_n == 'node_b'
        assert dp.propertyVal == 1000
        assert dp.propertyUnit == 'ohms'
        assert dp.pins == ['node_a', 'node_b']

    def test_set_properties_capacitor(self):
        """setPropertiesCapacitor sets all properties."""
        dp = pn.DevicePrimitives('capacitor')
        dp.setPropertiesCapacitor('top', 'bot', 1e-12)
        assert dp.propertyVal == 1e-12
        assert dp.propertyUnit == 'farads'

    def test_set_properties_inductor(self):
        """setPropertiesInductor sets all properties."""
        dp = pn.DevicePrimitives('inductor')
        dp.setPropertiesInductor('a', 'b', 1e-9)
        assert dp.propertyVal == 1e-9
        assert dp.propertyUnit == 'henrys'


# ---------------------------------------------------------------------------
# Modules class tests
# ---------------------------------------------------------------------------

class TestModulesClass:

    def test_create_module(self):
        """Modules class stores a name."""
        m = pn.Modules('my_module')
        assert m.name == 'my_module'


# ---------------------------------------------------------------------------
# Tracking disabled paths
# ---------------------------------------------------------------------------

class TestTrackingDisabled:

    def test_create_circuit_version_disabled(self, empty_netlist):
        """create_circuit_version returns None when tracking disabled."""
        assert empty_netlist.create_circuit_version() is None

    def test_store_results_disabled(self, empty_netlist):
        """store_results does nothing when tracking disabled."""
        empty_netlist.store_results({'gain': (10.0, 'dB')})  # should not raise

    def test_view_summary_disabled(self, empty_netlist):
        """view_summary does nothing when tracking disabled."""
        empty_netlist.view_summary()  # should not raise

    def test_track_structure_disabled(self, empty_netlist):
        """track_structure returns (None, None) when tracking disabled."""
        result = empty_netlist.track_structure()
        assert result == (None, None)

    def test_get_structure_info_disabled(self, empty_netlist):
        """get_structure_info returns None when tracking disabled."""
        assert empty_netlist.get_structure_info() is None

    def test_print_structure_disabled(self, empty_netlist, capsys):
        """print_structure prints warning when tracking disabled."""
        empty_netlist.print_structure()
        captured = capsys.readouterr()
        assert 'not enabled' in captured.out

    def test_get_latest_circuit_disabled(self, empty_netlist):
        """get_latest_circuit returns None when tracking disabled."""
        assert empty_netlist.get_latest_circuit() is None

    def test_get_all_versions_disabled(self, empty_netlist):
        """get_all_versions returns [] when tracking disabled."""
        assert empty_netlist.get_all_versions() == []


# ---------------------------------------------------------------------------
# addSimType — ac simulation
# ---------------------------------------------------------------------------

class TestAddSimTypeAc:

    def test_ac_sim_type(self, empty_netlist):
        """addSimType('ac', ...) is accepted (it's in simAnalysis_types)."""
        # ac is listed in simAnalysis_types but getSimTypeDetails may not
        # handle it — this tests the validation path
        # getSimTypeDetails returns None for 'ac', so len(None) will fail
        # This means ac details validation will error — test that path
        with pytest.raises((PyNetlistError, TypeError)):
            empty_netlist.addSimType('ac', ['dec', '10', '1', '1meg'])


# ---------------------------------------------------------------------------
# connectElement / updateElement delegation
# ---------------------------------------------------------------------------

class TestElementDelegation:

    def test_connect_element(self, basic_netlist):
        """connectElement delegates to _element_mgr."""
        # mn1 already exists in basic_netlist
        # Update a connection
        basic_netlist.addNet('new_drain')
        basic_netlist.connectElement('mn1', ['d'], ['new_drain'])
        elem = basic_netlist.elem_dict['mn1']
        # The device's pin 'd' should now be connected to 'new_drain'
        assert elem['device'].pin_list['d'].net == 'new_drain'

    def test_update_element(self, basic_netlist):
        """updateElement delegates to _element_mgr."""
        basic_netlist.updateElement('mn1', ['w'], [2.0])
        elem = basic_netlist.elem_dict['mn1']
        w_param = elem['device'].param_list['w']
        # param_list values are ParameterConstraint objects; .value is a Variable with .value
        assert w_param.value.value == 2.0


# ---------------------------------------------------------------------------
# addNet duplicate (via PyNetlist's own addNet, not _element_mgr)
# ---------------------------------------------------------------------------

class TestAddNetOwn:

    def test_add_net_duplicate_prints_message(self, empty_netlist, capsys):
        """The local addNet prints a message for duplicates."""
        # The first addNet might go through _element_mgr, the second through
        # the local one on line 310
        empty_netlist.addNet('vdd')
        empty_netlist.addNet('vdd')
        captured = capsys.readouterr()
        assert 'already exists' in captured.out

    def test_add_net_stores_parameters(self, empty_netlist):
        """addNet stores parameters in net_dict."""
        empty_netlist.addNet('vdd', ['max=1.8'])
        assert empty_netlist.net_dict['vdd'] == ['max=1.8']


# ---------------------------------------------------------------------------
# printElements with sources
# ---------------------------------------------------------------------------

class TestPrintElementsWithSources:

    def test_print_elements_includes_sources(self, basic_netlist, capsys):
        """printElements also prints sources."""
        basic_netlist.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))
        basic_netlist.printElements()
        captured = capsys.readouterr()
        assert 'vsup' in captured.out


# ---------------------------------------------------------------------------
# generateNetlist_OLD tests
# ---------------------------------------------------------------------------
# _setup_tracking with tracking enabled (mocked)
# ---------------------------------------------------------------------------

class TestSetupTracking:

    def test_tracking_enabled_with_params(self, pdk, tmp_dir):
        """When circuit_name and db_path provided, tracking is enabled."""
        db_file = os.path.join(tmp_dir, 'test.db')
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir',
                           pdkDetails=pdk,
                           circuit_name='test_ckt',
                           db_path=db_file,
                           enable_tracking=True)
        # May be True or False depending on whether circuit_db is importable
        # but the code path should not raise
        assert isinstance(ckt._tracking_enabled, bool)

    def test_tracking_import_error(self, pdk, tmp_dir, monkeypatch):
        """When circuit_db import fails, tracking is disabled gracefully."""
        import sys
        monkeypatch.setitem(sys.modules, 'silk.db.circuit_db', None)

        db_file = os.path.join(tmp_dir, 'test.db')
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir',
                           pdkDetails=pdk,
                           circuit_name='test_ckt',
                           db_path=db_file,
                           enable_tracking=True)
        assert ckt._tracking_enabled is False


# ---------------------------------------------------------------------------
# readRawFile (mocked ngspice_read)
# ---------------------------------------------------------------------------

class TestReadRawFile:

    def test_read_raw_file_sets_results(self, empty_netlist, monkeypatch):
        """readRawFile loads simulation results."""
        from unittest.mock import MagicMock

        mock_results = MagicMock()
        mock_results.nvars = 2
        mock_results.vectors = [MagicMock(), MagicMock()]

        import ngspice_read.ngspice_read as ngr
        monkeypatch.setattr(ngr, 'ngspice_read', lambda f: mock_results)

        empty_netlist.dataFile = '/fake/data.raw'
        empty_netlist.readRawFile()

        assert empty_netlist.simResultsLoaded is True
        assert empty_netlist.simResultsAll is mock_results


# ---------------------------------------------------------------------------
# loadSignal with mocked results
# ---------------------------------------------------------------------------

class TestLoadSignalWithResults:

    def test_load_signal_finds_signal(self, empty_netlist):
        """loadSignal returns a PySpiceSignal when signal exists."""
        from unittest.mock import MagicMock
        import numpy as np

        # Create mock results
        mock_results = MagicMock()
        mock_results.nvars = 2

        time_vec = MagicMock()
        time_vec.name = 'time'
        time_vec.data = np.linspace(0, 1e-6, 10)
        time_vec.type = 'time'

        vout_vec = MagicMock()
        vout_vec.name = 'v(out)'
        vout_vec.data = np.ones(10) * 0.9
        vout_vec.type = 'voltage'

        mock_results.vectors = [time_vec, vout_vec]

        empty_netlist.simResultsLoaded = True
        empty_netlist.simResultsAll = mock_results

        sig = empty_netlist.loadSignal('out', 'v')
        assert sig.name == 'out'

    def test_load_signal_not_found(self, empty_netlist):
        """loadSignal raises PyNetlistError when signal not found."""
        from unittest.mock import MagicMock
        import numpy as np

        mock_results = MagicMock()
        mock_results.nvars = 2

        time_vec = MagicMock()
        time_vec.name = 'time'
        time_vec.data = np.linspace(0, 1e-6, 10)
        time_vec.type = 'time'

        other_vec = MagicMock()
        other_vec.name = 'v(other)'
        other_vec.data = np.ones(10)
        other_vec.type = 'voltage'

        mock_results.vectors = [time_vec, other_vec]

        empty_netlist.simResultsLoaded = True
        empty_netlist.simResultsAll = mock_results

        with pytest.raises(PyNetlistError, match='not found'):
            empty_netlist.loadSignal('out', 'v')


# ---------------------------------------------------------------------------
# getSignalNames with mocked results
# ---------------------------------------------------------------------------

class TestGetSignalNames:

    def test_get_signal_names(self, empty_netlist, capsys):
        """getSignalNames returns list of signal names."""
        from unittest.mock import MagicMock

        mock_results = MagicMock()
        mock_results.nvars = 2

        vec1 = MagicMock()
        vec1.name = 'time'
        vec2 = MagicMock()
        vec2.name = 'v(out)'

        mock_results.vectors = [vec1, vec2]

        empty_netlist.simResultsLoaded = True
        empty_netlist.simResultsAll = mock_results

        names = empty_netlist.getSignalNames()
        assert 'time' in names
        assert 'v(out)' in names


# ---------------------------------------------------------------------------
# getOutputSignalList error path
# ---------------------------------------------------------------------------

class TestGetOutputSignalList:

    def test_raises_when_file_not_loaded(self, empty_netlist):
        """getOutputSignalList raises PyNetlistError when no file loaded."""
        with pytest.raises(PyNetlistError, match='not loaded'):
            empty_netlist.getOutputSignalList()

    def test_prints_when_file_available(self, empty_netlist, capsys):
        """getOutputSignalList prints when file is available."""
        empty_netlist.outputFileAvailable = True
        empty_netlist.getOutputSignalList()
        captured = capsys.readouterr()
        assert 'List of signals' in captured.out


# ---------------------------------------------------------------------------
# Tracking-enabled paths with mocked database
# ---------------------------------------------------------------------------

class TestTrackingEnabled:

    @pytest.fixture
    def tracked_netlist(self, pdk, tmp_dir):
        """Create a netlist with tracking enabled via direct attribute setting."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        # Manually enable tracking to avoid import issues
        ckt._tracking_enabled = True
        ckt.circuit_name = 'test_ckt'
        ckt.version = '1.0'
        ckt.stage = 'dev'
        ckt.circuit_id = None
        ckt._tracker = None
        return ckt

    def test_create_circuit_version_stores_info(self, tracked_netlist, monkeypatch):
        """create_circuit_version stores description when tracking enabled."""
        from unittest.mock import MagicMock
        # Mock _initialize_structure_tracker to avoid import issues
        monkeypatch.setattr(tracked_netlist, '_initialize_structure_tracker', lambda: None)
        tracked_netlist.create_circuit_version(description='test desc')
        assert tracked_netlist._circuit_description == 'test desc'

    def test_store_results_without_circuit_id(self, tracked_netlist, capsys):
        """store_results warns when circuit_id not set."""
        tracked_netlist.store_results({'gain': (10.0, 'dB')})
        captured = capsys.readouterr()
        assert 'create_circuit_version' in captured.out

    def test_store_results_with_circuit_id(self, tracked_netlist):
        """store_results stores results when circuit_id is set."""
        from unittest.mock import MagicMock
        tracked_netlist.circuit_id = 42
        tracked_netlist.db = MagicMock()
        tracked_netlist.store_results({'gain': (10.0, 'dB')}, corner='tt', temperature=27)
        tracked_netlist.db.add_simulation_result.assert_called_once()

    def test_view_summary_with_circuit_id(self, tracked_netlist):
        """view_summary calls db.get_simulation_summary."""
        from unittest.mock import MagicMock
        tracked_netlist.circuit_id = 42
        tracked_netlist.db = MagicMock()
        tracked_netlist.db.get_simulation_summary.return_value = "Summary text"
        tracked_netlist.view_summary()
        tracked_netlist.db.get_simulation_summary.assert_called_once_with(42)

    def test_get_latest_circuit_enabled(self, tracked_netlist):
        """get_latest_circuit calls db when tracking enabled."""
        from unittest.mock import MagicMock
        tracked_netlist.db = MagicMock()
        tracked_netlist.db.get_latest_circuit.return_value = {'id': 1}
        result = tracked_netlist.get_latest_circuit()
        tracked_netlist.db.get_latest_circuit.assert_called_once_with('test_ckt')
        assert result == {'id': 1}

    def test_get_all_versions_enabled(self, tracked_netlist):
        """get_all_versions calls db when tracking enabled."""
        from unittest.mock import MagicMock
        tracked_netlist.db = MagicMock()
        tracked_netlist.db.get_all_circuit_versions.return_value = [{'id': 1}]
        result = tracked_netlist.get_all_versions()
        assert result == [{'id': 1}]

    def test_get_structure_info_no_tracker(self, tracked_netlist):
        """get_structure_info returns None when no structure tracker."""
        tracked_netlist._structure_tracker = None
        result = tracked_netlist.get_structure_info()
        assert result is None

    def test_get_structure_info_with_tracker(self, tracked_netlist):
        """get_structure_info returns dict when tracker is set."""
        from unittest.mock import MagicMock
        tracker = MagicMock()
        tracker.get_structure_hash.return_value = 'abc123'
        tracker.get_run_count.return_value = 5
        tracked_netlist._structure_tracker = tracker
        result = tracked_netlist.get_structure_info()
        assert result == {'hash': 'abc123', 'run_count': 5}

    def test_print_structure_no_tracker(self, tracked_netlist, capsys):
        """print_structure warns when no tracker."""
        tracked_netlist._structure_tracker = None
        tracked_netlist.print_structure()
        captured = capsys.readouterr()
        assert 'not enabled' in captured.out


# ---------------------------------------------------------------------------
# runSimulator with tracking enabled
# ---------------------------------------------------------------------------

class TestRunSimulatorTracking:

    def test_run_simulator_with_tracking(self, full_param_netlist, mock_ngspice):
        """runSimulator calls track_structure when tracking enabled."""
        from unittest.mock import MagicMock
        ckt = full_param_netlist
        ckt._tracking_enabled = True
        ckt._structure_tracker = MagicMock()
        ckt.track_structure = MagicMock()
        ckt.generateNetlist(corner='tt')
        ckt.runSimulator(auto_track_structure=True)
        ckt.track_structure.assert_called_once()


# ---------------------------------------------------------------------------
# Lines 500–508: runSimulator failure path (ngspice returns non-zero)
# ---------------------------------------------------------------------------

class TestRunSimulatorFailure:

    def test_ngspice_nonzero_raises_simulation_error(self, full_param_netlist, monkeypatch):
        """When ngspice exits with non-zero code, runSimulator raises SimulationError."""
        import subprocess
        from unittest.mock import MagicMock
        from silk.exceptions import SimulationError

        def fake_run_fail(cmd, **kwargs):
            mock_result = MagicMock()
            mock_result.returncode = 1
            try:
                o_idx = cmd.index('-o')
                log_path = cmd[o_idx + 1]
                import os
                os.makedirs(os.path.dirname(log_path), exist_ok=True)
                with open(log_path, 'w') as f:
                    f.write('Error: something went wrong\nother line\n')
            except (ValueError, IndexError):
                pass
            return mock_result

        monkeypatch.setattr(subprocess, 'run', fake_run_fail)

        full_param_netlist.generateNetlist(corner='tt')
        with pytest.raises(SimulationError, match='ngspice simulation failed'):
            full_param_netlist.runSimulator()

    def test_ngspice_nonzero_no_log_file(self, full_param_netlist, monkeypatch):
        """When ngspice fails and no log file exists, OSError is swallowed and SimulationError raised."""
        import subprocess
        from unittest.mock import MagicMock
        from silk.exceptions import SimulationError

        def fake_run_fail(cmd, **kwargs):
            mock_result = MagicMock()
            mock_result.returncode = 2
            # Do NOT create the log file — exercises the OSError branch
            return mock_result

        monkeypatch.setattr(subprocess, 'run', fake_run_fail)

        full_param_netlist.generateNetlist(corner='tt')
        with pytest.raises(SimulationError, match='ngspice simulation failed'):
            full_param_netlist.runSimulator()

    def test_ngspice_failure_error_lines_in_message(self, full_param_netlist, monkeypatch):
        """Error lines from the log file appear in the SimulationError message."""
        import subprocess
        from unittest.mock import MagicMock
        import os
        from silk.exceptions import SimulationError

        def fake_run_fail(cmd, **kwargs):
            mock_result = MagicMock()
            mock_result.returncode = 1
            try:
                o_idx = cmd.index('-o')
                log_path = cmd[o_idx + 1]
                os.makedirs(os.path.dirname(log_path), exist_ok=True)
                with open(log_path, 'w') as f:
                    f.write('ERROR: undefined device\nfatal error\n')
            except (ValueError, IndexError):
                pass
            return mock_result

        monkeypatch.setattr(subprocess, 'run', fake_run_fail)

        full_param_netlist.generateNetlist(corner='tt')
        with pytest.raises(SimulationError) as exc_info:
            full_param_netlist.runSimulator()
        assert 'undefined device' in str(exc_info.value)


# ---------------------------------------------------------------------------
# Lines 615–633: store_results() — detailed coverage
# ---------------------------------------------------------------------------

class TestStoreResultsDetailed:

    @pytest.fixture
    def tracked_netlist(self, pdk, tmp_dir):
        import silk.circuit.netlist as pn
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_name = 'test_ckt'
        ckt.version = '1.0'
        ckt.stage = 'dev'
        ckt.circuit_id = None
        return ckt

    def test_store_results_tracking_disabled_is_noop(self, empty_netlist):
        """store_results is a no-op (no error) when tracking disabled."""
        # _tracking_enabled is False on empty_netlist
        empty_netlist.store_results({'gain': (10.0, 'dB')})  # should not raise

    def test_store_results_no_circuit_id_prints_warning(self, tracked_netlist, capsys):
        """store_results warns when circuit_id is None."""
        tracked_netlist.circuit_id = None
        tracked_netlist.store_results({'gain': (10.0, 'dB')})
        captured = capsys.readouterr()
        assert 'create_circuit_version' in captured.out

    def test_store_results_calls_db_multiple_params(self, tracked_netlist):
        """store_results calls add_simulation_result for each param."""
        from unittest.mock import MagicMock
        tracked_netlist.circuit_id = 10
        tracked_netlist.db = MagicMock()

        tracked_netlist.store_results(
            {'gain': (10.0, 'dB'), 'bw': (1e6, 'Hz')},
            corner='ss',
            temperature=85,
            voltage=1.8,
        )
        assert tracked_netlist.db.add_simulation_result.call_count == 2

    def test_store_results_prints_count(self, tracked_netlist, capsys):
        """store_results prints how many results were stored."""
        from unittest.mock import MagicMock
        tracked_netlist.circuit_id = 10
        tracked_netlist.db = MagicMock()

        tracked_netlist.store_results({'gain': (10.0, 'dB'), 'bw': (1e6, 'Hz')})
        captured = capsys.readouterr()
        assert '2' in captured.out


# ---------------------------------------------------------------------------
# Lines 644–708: view_summary(), _initialize_structure_tracker() error paths,
#               track_structure() RuntimeError when tracker not initialized
# ---------------------------------------------------------------------------

class TestViewSummaryNoCircuitId:

    def test_view_summary_no_circuit_id_is_noop(self, pdk, tmp_dir):
        """view_summary does nothing when circuit_id is None (no error)."""
        import silk.circuit.netlist as pn
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_id = None
        ckt.view_summary()  # should not raise

    def test_view_summary_tracking_disabled_noop(self, empty_netlist):
        """view_summary is a no-op when tracking disabled."""
        empty_netlist.view_summary()  # should not raise


class TestInitializeStructureTrackerErrors:

    def test_initialize_tracker_tracking_disabled_sets_none(self, empty_netlist):
        """_initialize_structure_tracker sets _structure_tracker=None when disabled."""
        # tracking is disabled on empty_netlist
        empty_netlist._initialize_structure_tracker()
        assert empty_netlist._structure_tracker is None

    def test_initialize_tracker_import_error_raises_system_exit(self, pdk, tmp_dir, monkeypatch):
        """_initialize_structure_tracker raises PyNetlistError when import fails."""
        import silk.circuit.netlist as pn

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_id = None
        ckt.db = None
        ckt.debug = False

        import sys
        monkeypatch.setitem(sys.modules, 'silk.db.structure_tracker', None)

        with pytest.raises(PyNetlistError):
            ckt._initialize_structure_tracker()

    def test_initialize_tracker_enabled_success(self, pdk, tmp_dir, monkeypatch):
        """_initialize_structure_tracker sets _structure_tracker when import succeeds."""
        import silk.circuit.netlist as pn
        from unittest.mock import MagicMock

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_id = None
        ckt.db = MagicMock()
        ckt.debug = False

        mock_tracker = MagicMock()
        mock_tracker_class = MagicMock(return_value=mock_tracker)

        import sys
        from unittest.mock import MagicMock as _MM
        fake_st_module = _MM()
        fake_st_module.CircuitStructureTracker = mock_tracker_class
        monkeypatch.setitem(sys.modules, 'silk.db.structure_tracker', fake_st_module)

        ckt._initialize_structure_tracker()
        assert ckt._structure_tracker is mock_tracker


class TestTrackStructureRuntimeError:

    def test_track_structure_no_tracker_raises(self, pdk, tmp_dir):
        """track_structure raises RuntimeError when tracker not initialized."""
        import silk.circuit.netlist as pn
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        # _structure_tracker not set at all (hasattr returns False)
        with pytest.raises(RuntimeError, match='create_circuit_version'):
            ckt.track_structure()

    def test_track_structure_tracker_none_raises(self, pdk, tmp_dir):
        """track_structure raises RuntimeError when _structure_tracker is None."""
        import silk.circuit.netlist as pn
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt._structure_tracker = None
        with pytest.raises(RuntimeError, match='create_circuit_version'):
            ckt.track_structure()

    def test_run_simulator_no_tracker_raises(self, full_param_netlist, monkeypatch, mock_ngspice):
        """runSimulator raises RuntimeError when tracking enabled but no tracker set."""
        full_param_netlist._tracking_enabled = True
        # Deliberately leave _structure_tracker unset
        if hasattr(full_param_netlist, '_structure_tracker'):
            del full_param_netlist._structure_tracker

        full_param_netlist.generateNetlist(corner='tt')
        with pytest.raises(RuntimeError, match='create_circuit_version'):
            full_param_netlist.runSimulator(auto_track_structure=True)

    def test_run_simulator_tracker_none_raises(self, full_param_netlist, mock_ngspice):
        """runSimulator raises RuntimeError when _structure_tracker is None."""
        full_param_netlist._tracking_enabled = True
        full_param_netlist._structure_tracker = None

        full_param_netlist.generateNetlist(corner='tt')
        with pytest.raises(RuntimeError, match='create_circuit_version'):
            full_param_netlist.runSimulator(auto_track_structure=True)


# ---------------------------------------------------------------------------
# Lines 750–830: track_structure() with mocked tracker — full flow
# ---------------------------------------------------------------------------

class TestTrackStructureWithMockedTracker:

    @pytest.fixture
    def tracked_netlist_with_tracker(self, pdk, tmp_dir):
        """Netlist with tracking enabled and a mocked structure tracker."""
        import silk.circuit.netlist as pn
        from unittest.mock import MagicMock

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'tracked.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_name = 'my_amp'
        ckt.version = '2.0'
        ckt.stage = 'dev'
        ckt.circuit_id = None
        ckt._circuit_description = 'test description'
        ckt._circuit_netlist_path = ckt.netlistname

        mock_tracker = MagicMock()
        mock_tracker.extract_structure.return_value = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': []}
        mock_tracker.compute_structure_hash.return_value = ('a' * 64, {})
        mock_tracker._find_circuit_by_hash.return_value = None  # no existing circuit
        mock_tracker._current_run_count = 1

        ckt._structure_tracker = mock_tracker
        return ckt

    def test_track_structure_creates_new_circuit(self, tracked_netlist_with_tracker, monkeypatch):
        """track_structure creates a new DB circuit when hash not found."""
        import sys
        from unittest.mock import MagicMock

        ckt = tracked_netlist_with_tracker
        mock_db = MagicMock()
        mock_db.create_circuit.return_value = 99
        ckt.db = mock_db

        monkeypatch.setitem(sys.modules, 'silk.db.circuit_db',
                            _make_fake_circuit_db_module())

        result_changed, result_hash = ckt.track_structure()
        assert result_changed is True
        assert result_hash == 'a' * 64
        mock_db.create_circuit.assert_called_once()

    def test_track_structure_reuses_existing_circuit(self, tracked_netlist_with_tracker):
        """track_structure reuses an existing circuit when hash matches."""
        from unittest.mock import MagicMock

        ckt = tracked_netlist_with_tracker
        # Make the tracker find an existing circuit by hash
        ckt._structure_tracker._find_circuit_by_hash.return_value = 77

        result_changed, result_hash = ckt.track_structure()
        assert result_changed is False
        assert ckt.circuit_id == 77

    def test_track_structure_reuse_increments_run_count(self, tracked_netlist_with_tracker):
        """When structure matches, increment_run_count is called."""
        ckt = tracked_netlist_with_tracker
        ckt._structure_tracker._find_circuit_by_hash.return_value = 55

        ckt.track_structure()
        ckt._structure_tracker.increment_run_count.assert_called_once()

    def test_track_structure_reuse_loads_last_structure(self, tracked_netlist_with_tracker):
        """When structure matches, _load_last_structure is called."""
        ckt = tracked_netlist_with_tracker
        ckt._structure_tracker._find_circuit_by_hash.return_value = 55

        ckt.track_structure()
        ckt._structure_tracker._load_last_structure.assert_called_once()

    def test_track_structure_stores_structure_when_new(self, tracked_netlist_with_tracker, monkeypatch):
        """track_structure calls store_structure when creating a new circuit."""
        import sys
        from unittest.mock import MagicMock

        ckt = tracked_netlist_with_tracker
        mock_db = MagicMock()
        mock_db.create_circuit.return_value = 42
        ckt.db = mock_db

        monkeypatch.setitem(sys.modules, 'silk.db.circuit_db',
                            _make_fake_circuit_db_module())

        ckt.track_structure()
        ckt._structure_tracker.store_structure.assert_called_once()

    def test_track_structure_with_existing_circuit_id(self, tracked_netlist_with_tracker):
        """track_structure skips create_circuit when circuit_id already set."""
        from unittest.mock import MagicMock

        ckt = tracked_netlist_with_tracker
        ckt.circuit_id = 100  # already set
        mock_db = MagicMock()
        ckt.db = mock_db

        ckt.track_structure()
        # No create_circuit call should happen since circuit_id is already set
        mock_db.create_circuit.assert_not_called()

    def test_track_structure_stage_mapping(self, pdk, tmp_dir, monkeypatch):
        """track_structure maps stage strings to DesignStage enum values."""
        import sys
        import silk.circuit.netlist as pn
        from unittest.mock import MagicMock

        monkeypatch.setitem(sys.modules, 'silk.db.circuit_db',
                            _make_fake_circuit_db_module())

        for stage_str in ('dev', 'stable', 'post_layout', 'tapeout'):
            ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, f'{stage_str}.cir', pdkDetails=pdk)
            ckt._tracking_enabled = True
            ckt.circuit_name = 'test'
            ckt.version = '1.0'
            ckt.stage = stage_str
            ckt.circuit_id = None
            ckt._circuit_description = ''
            ckt._circuit_netlist_path = ckt.netlistname

            mock_tracker = MagicMock()
            mock_tracker.extract_structure.return_value = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': []}
            mock_tracker.compute_structure_hash.return_value = ('b' * 64, {})
            mock_tracker._find_circuit_by_hash.return_value = None
            ckt._structure_tracker = mock_tracker

            mock_db = MagicMock()
            mock_db.create_circuit.return_value = 1
            ckt.db = mock_db

            ckt.track_structure()
            mock_db.create_circuit.assert_called_once()

    def test_track_structure_unknown_stage_defaults_to_dev(self, pdk, tmp_dir, monkeypatch):
        """track_structure uses DEV stage when stage string is unrecognised."""
        import sys
        import silk.circuit.netlist as pn
        from unittest.mock import MagicMock
        from enum import Enum

        class DesignStage(Enum):
            DEV = 'dev'
            STABLE = 'stable'
            POST_LAYOUT = 'post_layout'
            TAPEOUT = 'tapeout'

        fake_cdb = MagicMock()
        fake_cdb.DesignStage = DesignStage
        monkeypatch.setitem(sys.modules, 'silk.db.circuit_db', fake_cdb)

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'unk.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_name = 'test'
        ckt.version = '1.0'
        ckt.stage = 'unknown_stage'
        ckt.circuit_id = None
        ckt._circuit_description = ''
        ckt._circuit_netlist_path = ckt.netlistname

        mock_tracker = MagicMock()
        mock_tracker.extract_structure.return_value = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': []}
        mock_tracker.compute_structure_hash.return_value = ('c' * 64, {})
        mock_tracker._find_circuit_by_hash.return_value = None
        ckt._structure_tracker = mock_tracker

        mock_db = MagicMock()
        mock_db.create_circuit.return_value = 5
        ckt.db = mock_db

        ckt.track_structure()

        _, kwargs = mock_db.create_circuit.call_args
        assert kwargs['stage'] == DesignStage.DEV


# ---------------------------------------------------------------------------
# printElements / printNets — additional output format coverage (lines 329–342)
# ---------------------------------------------------------------------------

class TestPrintMethodsFormat:

    def test_print_elements_shows_count(self, basic_netlist, capsys):
        """printElements() header includes device and source counts."""
        basic_netlist.printElements()
        captured = capsys.readouterr()
        assert 'Elements' in captured.out
        assert 'devices' in captured.out
        assert 'sources' in captured.out

    def test_print_elements_empty_netlist(self, empty_netlist, capsys):
        """printElements() on empty netlist shows zero counts."""
        empty_netlist.printElements()
        captured = capsys.readouterr()
        assert '0 devices' in captured.out
        assert '0 sources' in captured.out

    def test_print_nets_shows_count(self, basic_netlist, capsys):
        """printNets() header includes net count."""
        basic_netlist.printNets()
        captured = capsys.readouterr()
        assert 'Nets' in captured.out
        assert '4' in captured.out  # basic_netlist has vdd, gnd, in, out

    def test_print_nets_empty_netlist(self, empty_netlist, capsys):
        """printNets() on empty netlist shows zero count."""
        empty_netlist.printNets()
        captured = capsys.readouterr()
        assert 'Nets (0)' in captured.out

    def test_print_elements_shows_source_nets(self, basic_netlist, capsys):
        """printElements() shows net connections for sources."""
        basic_netlist.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))
        basic_netlist.printElements()
        captured = capsys.readouterr()
        assert 'vsup' in captured.out


# ---------------------------------------------------------------------------
# addSimType debug print — line 348
# ---------------------------------------------------------------------------

class TestAddSimTypeDebug:

    def test_debug_print_on_add_sim_type(self, pdk, tmp_dir, capsys):
        """addSimType() emits debug line when debug=True."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'dbg.cir',
                           pdkDetails=pdk, debug=True)
        ckt.addSimType('transient', ['1n', '100n'])
        captured = capsys.readouterr()
        assert 'transient' in captured.out
        assert '1n' in captured.out


# ---------------------------------------------------------------------------
# print_structure — lines 750–830
# ---------------------------------------------------------------------------

class TestPrintStructure:

    def _make_tracked_ckt(self, pdk, tmp_dir):
        """Return a PyNetlist with a fully-mocked structure tracker."""
        from unittest.mock import MagicMock
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'struct.cir', pdkDetails=pdk)
        ckt._tracking_enabled = True
        ckt.circuit_name = 'test_ckt'
        ckt.version = '1.0'

        mock_tracker = MagicMock()
        mock_tracker.get_structure_hash.return_value = 'a' * 64
        mock_tracker.get_run_count.return_value = 3
        ckt._structure_tracker = mock_tracker
        return ckt

    def test_print_structure_disabled_shows_warning(self, pdk, tmp_dir, capsys):
        """print_structure() warns when tracking is disabled."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'ntrack.cir', pdkDetails=pdk)
        ckt._tracking_enabled = False
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'not enabled' in captured.out

    def test_print_structure_no_transistors(self, pdk, tmp_dir, capsys):
        """print_structure() handles empty transistor list gracefully."""
        ckt = self._make_tracked_ckt(pdk, tmp_dir)
        ckt._structure_tracker.extract_structure.return_value = {
            'transistors': [],
            'nets': [],
            'hierarchy': [],
            'parameters': [],
        }
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'TRANSISTORS' in captured.out
        assert '(none)' in captured.out

    def test_print_structure_with_transistors(self, pdk, tmp_dir, capsys):
        """print_structure() displays transistor info when present."""
        ckt = self._make_tracked_ckt(pdk, tmp_dir)
        ckt._structure_tracker.extract_structure.return_value = {
            'transistors': [{
                'name': 'mn1', 'type': 'nmos',
                'nets': {'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                'parameters': {'w': 1.0, 'l': 0.15, 'm': 1},
                'model': 'sky130_fd_pr__nfet_01v8',
            }],
            'nets': [],
            'hierarchy': [],
            'parameters': [],
        }
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'mn1' in captured.out
        assert 'nmos' in captured.out
        assert 'sky130_fd_pr__nfet_01v8' in captured.out

    def test_print_structure_with_nets(self, pdk, tmp_dir, capsys):
        """print_structure() groups nets by type and displays them."""
        ckt = self._make_tracked_ckt(pdk, tmp_dir)
        ckt._structure_tracker.extract_structure.return_value = {
            'transistors': [],
            'nets': [
                {'name': 'vdd', 'type': 'power'},
                {'name': 'gnd', 'type': 'ground'},
                {'name': 'clk', 'type': 'clock'},
                {'name': 'sig', 'type': 'signal'},
            ],
            'hierarchy': [],
            'parameters': [],
        }
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'POWER' in captured.out
        assert 'GROUND' in captured.out
        assert 'CLOCK' in captured.out
        assert 'SIGNAL' in captured.out

    def test_print_structure_with_hierarchy(self, pdk, tmp_dir, capsys):
        """print_structure() shows hierarchy when modules are present."""
        ckt = self._make_tracked_ckt(pdk, tmp_dir)
        ckt._structure_tracker.extract_structure.return_value = {
            'transistors': [],
            'nets': [],
            'hierarchy': [{
                'instance_name': 'xinv1',
                'module_type': 'inv_cell',
                'ports': {'in': 'a', 'out': 'b'},
                'parameters': {'w': 2},
            }],
            'parameters': [],
        }
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'HIERARCHY' in captured.out
        assert 'xinv1' in captured.out

    def test_print_structure_with_parameters(self, pdk, tmp_dir, capsys):
        """print_structure() shows parameters section when present."""
        ckt = self._make_tracked_ckt(pdk, tmp_dir)
        ckt._structure_tracker.extract_structure.return_value = {
            'transistors': [],
            'nets': [],
            'hierarchy': [],
            'parameters': [{'module': 'top', 'name': 'gain', 'value': 10}],
        }
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'PARAMETERS' in captured.out
        assert 'gain' in captured.out

    def test_print_structure_shows_hash_info(self, pdk, tmp_dir, capsys):
        """print_structure() shows tracking hash info via get_structure_info()."""
        ckt = self._make_tracked_ckt(pdk, tmp_dir)
        ckt._structure_tracker.extract_structure.return_value = {
            'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [],
        }
        ckt.print_structure()
        captured = capsys.readouterr()
        assert 'TRACKING INFO' in captured.out
        assert 'Run count' in captured.out


# ---------------------------------------------------------------------------
# Coverage gap: _source_nets() for dependent (controlled) sources — lines 234-237
# ---------------------------------------------------------------------------

class TestSourceNetsControlledSources:

    def test_vcvs_nets_registered(self, empty_netlist):
        """VCVS source registers all four net names (out_pos, out_neg, ctrl_pos, ctrl_neg)."""
        src = sources.VoltageControlledVoltageSource(
            'eamp', out_pos='vout', out_neg='gnd', ctrl_pos='vin', ctrl_neg='gnd', gain=10
        )
        empty_netlist.addSource(src)
        # _source_nets should return the four nets, and addSource registers them
        assert 'eamp' in empty_netlist.sigSources_dict

    def test_vccs_nets_registered(self, empty_netlist):
        """VCCS source registers all four net names."""
        src = sources.VoltageControlledCurrentSource(
            'gm1', out_pos='iout', out_neg='gnd', ctrl_pos='vin', ctrl_neg='gnd', gm=0.01
        )
        empty_netlist.addSource(src)
        assert 'gm1' in empty_netlist.sigSources_dict

    def test_ccvs_nets_registered(self, empty_netlist):
        """CCVS source registers out_pos and out_neg (two-net branch, line 237)."""
        src = sources.CurrentControlledVoltageSource(
            'htrans', out_pos='vout', out_neg='gnd', transresistance=1000, ctrl_vname='vmeas'
        )
        empty_netlist.addSource(src)
        assert 'htrans' in empty_netlist.sigSources_dict

    def test_cccs_nets_registered(self, empty_netlist):
        """CCCS source registers out_pos and out_neg."""
        src = sources.CurrentControlledCurrentSource(
            'fmir', out_pos='icopy', out_neg='gnd', gain=2, ctrl_vname='vmeas'
        )
        empty_netlist.addSource(src)
        assert 'fmir' in empty_netlist.sigSources_dict

    def test_vcvs_four_nets_in_net_dict(self, empty_netlist):
        """Adding a VCVS registers all four referenced nets into net_dict."""
        src = sources.VoltageControlledVoltageSource(
            'etest', out_pos='out_p', out_neg='out_n', ctrl_pos='ctrl_p', ctrl_neg='ctrl_n', gain=5
        )
        empty_netlist.addSource(src)
        for net in ('out_p', 'out_n', 'ctrl_p', 'ctrl_n'):
            assert net in empty_netlist.net_dict

    def test_ccvs_two_nets_in_net_dict(self, empty_netlist):
        """Adding a CCVS registers out_pos and out_neg into net_dict."""
        src = sources.CurrentControlledVoltageSource(
            'h1', out_pos='vo_p', out_neg='vo_n', transresistance=500, ctrl_vname='vmeas'
        )
        empty_netlist.addSource(src)
        assert 'vo_p' in empty_netlist.net_dict
        assert 'vo_n' in empty_netlist.net_dict


# ---------------------------------------------------------------------------
# Coverage gap: addNet delegating method on PyNetlist itself — line 256
# ---------------------------------------------------------------------------

class TestAddNetDelegate:

    def test_addnet_via_netlist(self, empty_netlist):
        """PyNetlist.addNet() delegates to element manager and adds to net_dict."""
        empty_netlist.addNet('mynet')
        assert 'mynet' in empty_netlist.net_dict

    def test_addnet_returns_none_for_duplicate(self, empty_netlist):
        """PyNetlist.addNet() for a duplicate net does not raise."""
        empty_netlist.addNet('dupnet')
        empty_netlist.addNet('dupnet')  # should not raise
        assert 'dupnet' in empty_netlist.net_dict


# ---------------------------------------------------------------------------
# Coverage gap: updateSource() old API — lines 271-287
# ---------------------------------------------------------------------------

class TestUpdateSource:

    def _inject_legacy_source(self, ckt, name):
        """Inject a legacy dict-format source entry for testing old API paths."""
        # sigParams order: ['dc', 'ac', 'pwl', 'pulse', 'sine']
        ckt.sigSources_dict[name] = {
            'type': 'VoltageSource',
            'pinNets': ['vdd', 'gnd'],
            'params': [1.8, None, None, None, None],
        }

    def test_update_source_modifies_params(self, empty_netlist):
        """updateSource() modifies a parameter value in a legacy dict-format source (lines 271-287)."""
        self._inject_legacy_source(empty_netlist, 'vsrc_legacy')
        empty_netlist.updateSource('vsrc_legacy', ['dc'], [3.3])
        assert empty_netlist.sigSources_dict['vsrc_legacy']['params'][0] == 3.3

    def test_update_source_missing_raises_exit(self, empty_netlist):
        """updateSource() raises PyNetlistError when source does not exist."""
        with pytest.raises(PyNetlistError):
            empty_netlist.updateSource('nonexistent', ['dc'], [1.8])


# ---------------------------------------------------------------------------
# Coverage gap: connectSource() old API — lines 302-307
# ---------------------------------------------------------------------------

class TestConnectSource:

    def _inject_legacy_source(self, ckt, name):
        """Inject a legacy dict-format source entry for testing old API paths."""
        ckt.sigSources_dict[name] = {
            'type': 'VoltageSource',
            'pinNets': ['', ''],
            'params': [1.8, None, None, None, None],
        }

    def test_connect_source_updates_pin_nets(self, empty_netlist):
        """connectSource() updates pin nets in a legacy dict-format source (lines 302-307)."""
        empty_netlist.addNet('vdd')
        empty_netlist.addNet('gnd')
        self._inject_legacy_source(empty_netlist, 'vsrc_conn')
        empty_netlist.connectSource('vsrc_conn', ['positive', 'negative'], ['vdd', 'gnd'])
        assert empty_netlist.sigSources_dict['vsrc_conn']['pinNets'][0] == 'vdd'
        assert empty_netlist.sigSources_dict['vsrc_conn']['pinNets'][1] == 'gnd'

    def test_connect_source_missing_source_raises_exit(self, empty_netlist):
        """connectSource() raises PyNetlistError when source does not exist."""
        with pytest.raises(PyNetlistError):
            empty_netlist.connectSource('nonexistent', ['positive'], ['vdd'])

    def test_connect_source_undefined_net_raises_exit(self, empty_netlist):
        """connectSource() raises PyNetlistError when net is not in net_dict."""
        self._inject_legacy_source(empty_netlist, 'vsrc_nonet')
        with pytest.raises(PyNetlistError):
            empty_netlist.connectSource('vsrc_nonet', ['positive'], ['undefined_net'])


# ---------------------------------------------------------------------------
# Coverage gap: printElements() non-dict element branch — lines 338-339
# ---------------------------------------------------------------------------

class TestPrintElementsControlledSources:

    def test_print_elements_with_vcvs_source(self, empty_netlist, capsys):
        """printElements() handles a VCVS source (uses out_pos/out_neg branch, line 338-339)."""
        src = sources.VoltageControlledVoltageSource(
            'eprint', out_pos='outp', out_neg='outn', ctrl_pos='ctrlp', ctrl_neg='ctrln', gain=2
        )
        empty_netlist.addSource(src)
        empty_netlist.printElements()
        out = capsys.readouterr().out
        assert 'eprint' in out

    def test_print_elements_with_ccvs_source(self, empty_netlist, capsys):
        """printElements() handles a CCVS source (uses out_pos/out_neg branch)."""
        src = sources.CurrentControlledVoltageSource(
            'hprint', out_pos='vp', out_neg='vn', transresistance=100, ctrl_vname='vctrl'
        )
        empty_netlist.addSource(src)
        empty_netlist.printElements()
        out = capsys.readouterr().out
        assert 'hprint' in out


# ---------------------------------------------------------------------------
# Coverage gap: runSimulator() debug=True branch — line 490
# ---------------------------------------------------------------------------

class TestRunSimulatorDebug:

    def test_run_simulator_debug_true_no_crash(self, pdk, tmp_dir, mock_ngspice):
        """runSimulator() with debug=True prints tracking message without crashing."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'debug_sim.cir', pdkDetails=pdk, debug=True)
        ckt.addNet('vdd')
        ckt.addNet('gnd')
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'vdd', 'g': 'gnd', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15, 'm': 1},
        )
        ckt.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))
        ckt.addSimType('transient', ['1n', '100n'])
        ckt.generateNetlist(corner='tt')
        # With no tracking enabled, debug=True path at line 490 is skipped (tracking not enabled).
        # Run anyway to ensure no crash.
        ckt.runSimulator(auto_track_structure=False)
        assert mock_ngspice['called']

    def test_run_simulator_debug_true_with_tracking_prints_message(
        self, pdk, tmp_dir, mock_ngspice, capsys
    ):
        """runSimulator() with debug=True and tracking enabled prints auto-tracking message (line 490)."""
        ckt = pn.PyNetlist(
            'PDK_skywater130', tmp_dir, 'debug_track.cir',
            pdkDetails=pdk, debug=True,
            circuit_name='debug_circ', db_path=':memory:',
        )
        ckt.addNet('vdd')
        ckt.addNet('gnd')
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'vdd', 'g': 'gnd', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15, 'm': 1},
        )
        ckt.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))
        ckt.addSimType('transient', ['1n', '100n'])
        ckt.generateNetlist(corner='tt')
        ckt.create_circuit_version(description='debug test')
        capsys.readouterr()  # clear setup output
        ckt.runSimulator(auto_track_structure=True)
        out = capsys.readouterr().out
        assert 'Auto-tracking' in out or 'tracking' in out.lower()


# ---------------------------------------------------------------------------
# Coverage gap: debug prints in _initialize_structure_tracker (line 629)
# and track_structure (line 662)
# ---------------------------------------------------------------------------

class TestDebugTrackingPrints:

    def test_initialize_structure_tracker_debug_prints(self, pdk, tmp_dir, capsys):
        """_initialize_structure_tracker with debug=True prints 'Structure tracker initialized' (line 629)."""
        ckt = pn.PyNetlist(
            'PDK_skywater130', tmp_dir, 'dbg_tracker.cir',
            pdkDetails=pdk, debug=True,
            circuit_name='dbg_circ', db_path=':memory:',
        )
        capsys.readouterr()  # clear init output
        ckt.create_circuit_version(description='test init debug')
        out = capsys.readouterr().out
        assert 'Structure tracker initialized' in out

    def test_track_structure_debug_prints_hash(self, pdk, tmp_dir, capsys):
        """track_structure() with debug=True prints the computed structure hash (line 662)."""
        ckt = pn.PyNetlist(
            'PDK_skywater130', tmp_dir, 'dbg_hash.cir',
            pdkDetails=pdk, debug=True,
            circuit_name='dbg_hash_circ', db_path=':memory:',
        )
        ckt.addNet('vdd')
        ckt.addNet('gnd')
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'vdd', 'g': 'gnd', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15, 'm': 1},
        )
        ckt.create_circuit_version(description='test hash debug')
        capsys.readouterr()  # clear setup output
        ckt.track_structure()
        out = capsys.readouterr().out
        assert 'Computed structure hash' in out or 'structure hash' in out.lower()


# ---------------------------------------------------------------------------
# strict_nets tests
# ---------------------------------------------------------------------------

class TestStrictNets:

    def test_default_is_false_auto_registers_nets(self, pdk, tmp_dir):
        """Default strict_nets=False: addElement with undeclared nets does not raise."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'default.cir', pdkDetails=pdk)
        # No addNet calls — should succeed silently
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15},
        )
        assert 'mn1' in ckt.elem_dict
        for net in ('out', 'in', 'gnd'):
            assert net in ckt.net_dict

    def test_explicit_false_auto_registers_nets(self, pdk, tmp_dir):
        """Explicit strict_nets=False: addElement with undeclared nets does not raise."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'explicit_false.cir',
                           pdkDetails=pdk, strict_nets=False)
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'undeclared_net', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15},
        )
        assert 'undeclared_net' in ckt.net_dict

    def test_strict_true_addelement_undeclared_net_raises(self, pdk, tmp_dir):
        """strict_nets=True: addElement with undeclared net raises PyNetlistError."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'strict.cir',
                           pdkDetails=pdk, strict_nets=True)
        with pytest.raises(PyNetlistError, match='mystery_net'):
            ckt.addElement(
                pdk.nmos1p8, 'mn1',
                nets={'d': 'mystery_net', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                parameters={'w': 1, 'l': 0.15},
            )

    def test_strict_true_addelement_predeclared_nets_succeeds(self, pdk, tmp_dir):
        """strict_nets=True: addElement succeeds when all nets are pre-declared."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'strict_ok.cir',
                           pdkDetails=pdk, strict_nets=True)
        for net in ('out', 'in', 'gnd'):
            ckt.addNet(net)
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15},
        )
        assert 'mn1' in ckt.elem_dict

    def test_strict_true_addsource_undeclared_net_raises(self, pdk, tmp_dir):
        """strict_nets=True: addSource with undeclared net raises PyNetlistError."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'strict_src.cir',
                           pdkDetails=pdk, strict_nets=True)
        with pytest.raises(PyNetlistError, match='undeclared_vdd'):
            ckt.addSource(
                sources.VoltageSource('vsup', positive='undeclared_vdd', negative='gnd', dc=1.8)
            )

    def test_strict_true_addsource_predeclared_nets_succeeds(self, pdk, tmp_dir):
        """strict_nets=True: addSource succeeds when all nets are pre-declared."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'strict_src_ok.cir',
                           pdkDetails=pdk, strict_nets=True)
        ckt.addNet('vdd')
        ckt.addNet('gnd')
        ckt.addSource(
            sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8)
        )
        assert 'vsup' in ckt.sigSources_dict

    def test_strict_true_addnet_then_addelement_succeeds(self, pdk, tmp_dir):
        """strict_nets=True: round-trip addNet then addElement works."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'strict_rt.cir',
                           pdkDetails=pdk, strict_nets=True)
        for net in ('vdd', 'gnd', 'in', 'out'):
            ckt.addNet(net)
        ckt.addElement(
            pdk.pmos1p8, 'mp1',
            nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
            parameters={'w': 2, 'l': 0.15},
        )
        assert 'mp1' in ckt.elem_dict

    def test_strict_nets_flag_stored_true(self, pdk, tmp_dir):
        """strict_nets=True is stored on the instance."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'flag_true.cir',
                           pdkDetails=pdk, strict_nets=True)
        assert ckt.strict_nets is True

    def test_strict_nets_flag_stored_false(self, pdk, tmp_dir):
        """strict_nets=False is stored on the instance."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'flag_false.cir',
                           pdkDetails=pdk, strict_nets=False)
        assert ckt.strict_nets is False

    def test_error_message_contains_net_name(self, pdk, tmp_dir):
        """PyNetlistError message contains the offending net name."""
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'strict_msg.cir',
                           pdkDetails=pdk, strict_nets=True)
        with pytest.raises(PyNetlistError, match='net_alpha'):
            ckt.addElement(
                pdk.nmos1p8, 'mn1',
                nets={'d': 'net_alpha', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                parameters={'w': 1, 'l': 0.15},
            )
