"""
Tests for typed analysis classes in pynetlist.core.analysis:
  _fmt(), AnalysisBase, Transient, AC, DC, Noise

Also tests the object-based path in PyNetlist.addSimType().
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from silk.simulation.analysis import (
    _fmt, AnalysisBase, Transient, AC, DC, Noise,
)


# ---------------------------------------------------------------------------
# _fmt() tests  (same function, defined independently in analysis.py)
# ---------------------------------------------------------------------------

class TestFmt:

    def test_string_passthrough(self):
        assert _fmt('100p') == '100p'

    def test_zero(self):
        assert _fmt(0) == '0'

    def test_one_kilo(self):
        assert _fmt(1000) == '1k'

    def test_one_point_five_kilo(self):
        assert _fmt(1500) == '1.5k'

    def test_one_meg(self):
        assert _fmt(1e6) == '1Meg'

    def test_one_nano(self):
        assert _fmt(1e-9) == '1n'

    def test_hundred_pico(self):
        assert _fmt(100e-12) == '100p'

    def test_negative_milli(self):
        assert _fmt(-1e-3) == '-1m'

    def test_femto(self):
        """1e-15 maps to the femto suffix."""
        assert _fmt(1e-15) == '1f'


# ---------------------------------------------------------------------------
# AnalysisBase
# ---------------------------------------------------------------------------

class TestAnalysisBase:

    def test_raises_not_implemented(self):
        """AnalysisBase.to_spice() raises NotImplementedError."""
        base = AnalysisBase()
        with pytest.raises(NotImplementedError):
            base.to_spice()


# ---------------------------------------------------------------------------
# Transient
# ---------------------------------------------------------------------------

class TestTransient:

    def test_basic_transient(self):
        """Transient(1e-9, 5e-6) produces correct .tran line."""
        assert Transient(1e-9, 5e-6).to_spice() == '.tran 1n 5u\n'

    def test_transient_with_nonzero_start(self):
        """Transient with start != 0 includes the start value."""
        result = Transient(1e-9, 5e-6, start=1e-7).to_spice()
        assert '.tran' in result
        assert '1n' in result
        assert '5u' in result
        assert '100n' in result  # 1e-7 -> 100n

    def test_transient_with_zero_start_omits_start(self):
        """Transient with start=0 does NOT include start in output."""
        result = Transient(1e-9, 5e-6, start=0).to_spice()
        parts = result.strip().split()
        # .tran step stop  — exactly 3 tokens
        assert len(parts) == 3

    def test_transient_default_start_omits_start(self):
        """Transient default start=0 gives exactly 3 tokens."""
        result = Transient(1e-9, 5e-6).to_spice()
        parts = result.strip().split()
        assert len(parts) == 3


# ---------------------------------------------------------------------------
# AC
# ---------------------------------------------------------------------------

class TestAC:

    def test_basic_ac_dec(self):
        """AC('dec', 10, 1e3, 1e9) produces correct .ac line."""
        assert AC('dec', 10, 1e3, 1e9).to_spice() == '.ac dec 10 1k 1G\n'

    def test_ac_oct_variation(self):
        """AC with 'oct' variation is accepted."""
        result = AC('oct', 5, 100, 1e6).to_spice()
        assert '.ac oct' in result

    def test_ac_lin_variation(self):
        """AC with 'lin' variation is accepted."""
        result = AC('lin', 100, 1e3, 1e6).to_spice()
        assert '.ac lin' in result

    def test_ac_invalid_variation_raises_value_error(self):
        """AC raises ValueError for an invalid variation string."""
        with pytest.raises(ValueError):
            AC('invalid', 10, 1e3, 1e9)


# ---------------------------------------------------------------------------
# DC
# ---------------------------------------------------------------------------

class TestDC:

    def test_basic_dc_sweep(self):
        """DC('vin', -1.8, 1.8, 0.01) produces correct .dc line."""
        assert DC('vin', -1.8, 1.8, 0.01).to_spice() == '.dc vin -1.8 1.8 10m\n'

    def test_dc_source_name_in_output(self):
        """DC to_spice() includes the source name."""
        result = DC('vsupply', 0, 3.3, 0.1).to_spice()
        assert 'vsupply' in result

    def test_dc_contains_start_stop_step(self):
        """DC to_spice() contains start, stop, step values."""
        result = DC('vin', 0, 1.8, 0.01).to_spice()
        assert '0' in result
        assert '1.8' in result
        assert '10m' in result


# ---------------------------------------------------------------------------
# Noise
# ---------------------------------------------------------------------------

class TestNoise:

    def test_basic_noise(self):
        """Noise produces correct .noise line."""
        result = Noise('out', '0', 'vin', 'dec', 100, 1, 1e9).to_spice()
        assert result.startswith('.noise v(out,0) vin dec 100 ')
        assert '1G' in result
        assert result.endswith('\n')

    def test_noise_contains_output_ref(self):
        """Noise to_spice() contains output and reference nodes."""
        result = Noise('vout', 'gnd', 'vsrc', 'dec', 10, 1e3, 1e9).to_spice()
        assert 'v(vout,gnd)' in result

    def test_noise_contains_source(self):
        """Noise to_spice() contains the source name."""
        result = Noise('out', '0', 'vsrc', 'dec', 10, 1e3, 1e9).to_spice()
        assert 'vsrc' in result

    def test_noise_invalid_variation_raises_value_error(self):
        """Noise raises ValueError for an invalid variation string."""
        with pytest.raises(ValueError):
            Noise('out', '0', 'vin', 'bad', 100, 1, 1e9)


# ---------------------------------------------------------------------------
# addSimType() object-based path on PyNetlist
# ---------------------------------------------------------------------------

class TestAddSimTypeObjectPath:

    def test_transient_object_stored_under_transient_key(self, pdk, tmp_dir):
        """addSimType(Transient(...)) stores under key 'transient'."""
        import silk.circuit.netlist as pn

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'sim_tran.cir', pdkDetails=pdk)
        t = Transient(1e-9, 5e-6)
        ckt.addSimType(t)
        assert 'transient' in ckt.simAnalysis_dict
        assert ckt.simAnalysis_dict['transient'] is t

    def test_ac_object_stored_under_ac_key(self, pdk, tmp_dir):
        """addSimType(AC(...)) stores under key 'ac'."""
        import silk.circuit.netlist as pn

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'sim_ac.cir', pdkDetails=pdk)
        a = AC('dec', 10, 1e3, 1e9)
        ckt.addSimType(a)
        assert 'ac' in ckt.simAnalysis_dict
        assert ckt.simAnalysis_dict['ac'] is a

    def test_dc_object_stored_under_dc_key(self, pdk, tmp_dir):
        """addSimType(DC(...)) stores under key 'dc'."""
        import silk.circuit.netlist as pn

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'sim_dc.cir', pdkDetails=pdk)
        d = DC('vin', 0, 1.8, 0.01)
        ckt.addSimType(d)
        assert 'dc' in ckt.simAnalysis_dict
        assert ckt.simAnalysis_dict['dc'] is d

    def test_old_string_api_still_works(self, pdk, tmp_dir):
        """Old string-based addSimType('transient', [...]) still functions."""
        import silk.circuit.netlist as pn

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'sim_legacy.cir', pdkDetails=pdk)
        ckt.addSimType('transient', ['1n', '100n'])
        assert 'transient' in ckt.simAnalysis_dict
        assert ckt.simAnalysis_dict['transient']['tstep'] == '1n'
        assert ckt.simAnalysis_dict['transient']['tstop'] == '100n'
