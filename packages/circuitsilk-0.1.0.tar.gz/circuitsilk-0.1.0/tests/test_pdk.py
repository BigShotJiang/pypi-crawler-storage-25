"""
Tests for skywater130_pdk_v2.PDK_skywater130 and related dataclasses.

Covers YAML loading, device attributes, modelNames, Pin/ParameterConstraint/PDKDevice
dataclasses, generateNetlistEntry(), deep copy independence, and error paths.
"""

import copy
import pytest

from silk.pdk.skywater130 import PDK_skywater130, PDKDevice, Pin, ParameterConstraint, ValidationError
from silk.exceptions import PyNetlistError


# ---------------------------------------------------------------------------
# Constructor / YAML loading
# ---------------------------------------------------------------------------

class TestPDKLoading:

    def test_constructor_loads_yaml(self, pdk):
        """PDK constructor loads YAML without raising."""
        assert pdk is not None

    def test_bad_yaml_path_raises(self, tmp_dir):
        """Passing a non-existent YAML path raises an error."""
        with pytest.raises(Exception):
            PDK_skywater130('/nonexistent/path.yaml', libraryLocation='/fake')

    def test_model_names_populated(self, pdk):
        """modelNames list is populated after loading."""
        assert isinstance(pdk.modelNames, list)
        assert len(pdk.modelNames) > 0

    def test_model_names_contains_expected_devices(self, pdk):
        """modelNames includes core device types from YAML."""
        expected = ['nmos1p8', 'pmos1p8', 'res_hpo', 'cap_mim1']
        for name in expected:
            assert name in pdk.modelNames, f"{name} not in modelNames"


# ---------------------------------------------------------------------------
# Device attributes
# ---------------------------------------------------------------------------

class TestPDKDeviceAttributes:

    def test_nmos1p8_attribute_exists(self, pdk):
        """pdk.nmos1p8 attribute exists and is an AnalogElement subclass (Phase 2+)."""
        from silk.elements.base import AnalogElement
        assert hasattr(pdk, 'nmos1p8')
        assert isinstance(pdk.nmos1p8, type)
        assert issubclass(pdk.nmos1p8, AnalogElement)

    def test_pmos1p8_attribute_exists(self, pdk):
        """pdk.pmos1p8 attribute exists and is an AnalogElement subclass (Phase 2+)."""
        from silk.elements.base import AnalogElement
        assert hasattr(pdk, 'pmos1p8')
        assert isinstance(pdk.pmos1p8, type)
        assert issubclass(pdk.pmos1p8, AnalogElement)

    def test_device_has_pin_names(self, pdk):
        """Each device class has correct _pin_names tuple."""
        cls = pdk.nmos1p8
        assert set(cls._pin_names) == {'d', 'g', 's', 'b'}

    def test_device_has_param_names(self, pdk):
        """Each device class has correct _param_names tuple."""
        cls = pdk.nmos1p8
        assert 'w' in cls._param_names
        assert 'l' in cls._param_names
        assert 'm' in cls._param_names

    def test_device_pdk_device_name(self, pdk):
        """Device class stores correct _pdk_device string."""
        assert pdk.nmos1p8._pdk_device == 'sky130_fd_pr__nfet_01v8'
        assert pdk.pmos1p8._pdk_device == 'sky130_fd_pr__pfet_01v8'

    def test_resistor_has_two_pin_device(self, pdk):
        """Resistor device class has a/b pin names."""
        cls = pdk.res_hpo
        assert 'a' in cls._pin_names
        assert 'b' in cls._pin_names

    def test_internal_devices_still_pdk_device(self, pdk):
        """pdk._devices still holds PDKDevice objects for backward compat."""
        assert isinstance(pdk._devices['nmos1p8'], PDKDevice)


# ---------------------------------------------------------------------------
# Pin dataclass
# ---------------------------------------------------------------------------

class TestPin:

    def test_pin_has_name(self):
        """Pin dataclass has name attribute."""
        p = Pin(name='d', net_name='drain')
        assert p.name == 'd'

    def test_pin_has_net_name(self):
        """Pin dataclass has net_name attribute."""
        p = Pin(name='g', net_name='gate')
        assert p.net_name == 'gate'

    def test_pin_net_defaults_to_none(self):
        """Pin.net defaults to None."""
        p = Pin(name='s', net_name='source')
        assert p.net is None

    def test_pin_net_assignable(self):
        """Pin.net can be assigned a net string."""
        p = Pin(name='d', net_name='drain', net='vdd')
        assert p.net == 'vdd'


# ---------------------------------------------------------------------------
# ParameterConstraint dataclass
# ---------------------------------------------------------------------------

class TestParameterConstraint:

    def test_has_minval_maxval_value(self):
        """ParameterConstraint has minval, maxval, value attributes."""
        pc = ParameterConstraint(minval='0.15', maxval='-1', value=None, unit='u')
        assert pc.minval == '0.15'
        assert pc.maxval == '-1'
        assert pc.value is None

    def test_unit_extracted_from_minval(self):
        """Unit is auto-extracted from minval suffix when not provided."""
        pc = ParameterConstraint(minval='0.42u', maxval='-1', value=None)
        assert pc.unit == 'u'

    def test_numeric_values_normalized(self):
        """Numeric minval/maxval are normalized to strings."""
        pc = ParameterConstraint(minval=1, maxval=100, value=None)
        assert pc.minval == '1'
        assert pc.maxval == '100'


# ---------------------------------------------------------------------------
# PDKDevice.from_dict
# ---------------------------------------------------------------------------

class TestPDKDeviceFromDict:

    def test_from_dict_creates_device(self):
        """PDKDevice.from_dict constructs a device from a minimal dict."""
        data = {
            'PDKDevice': 'sky130_fd_pr__nfet_01v8',
            'paramList': {
                'w': {'minval': '0.42', 'maxval': '-1', 'unit': 'u'},
                'l': {'minval': '0.15', 'maxval': '-1', 'unit': 'u'},
            },
            'pinList': {
                'd': 'drain',
                'g': 'gate',
                's': 'source',
                'b': 'bulk',
            }
        }
        dev = PDKDevice.from_dict('test_nmos', data)
        assert dev.device_name == 'test_nmos'
        assert dev.pdk_device == 'sky130_fd_pr__nfet_01v8'
        assert 'w' in dev.param_list
        assert 'l' in dev.param_list
        assert isinstance(dev.pin_list['d'], Pin)
        assert dev.pin_list['d'].net_name == 'drain'

    def test_from_dict_pin_objects(self):
        """from_dict creates Pin objects with correct attributes."""
        data = {
            'PDKDevice': 'test_dev',
            'paramList': {'m': {'minval': '1', 'maxval': '-1'}},
            'pinList': {'a': 'anode', 'k': 'cathode'},
        }
        dev = PDKDevice.from_dict('diode', data)
        assert dev.pin_list['a'].name == 'a'
        assert dev.pin_list['a'].net_name == 'anode'
        assert dev.pin_list['a'].net is None


# ---------------------------------------------------------------------------
# Deep copy independence
# ---------------------------------------------------------------------------

class TestDeviceDeepCopy:

    def test_deep_copy_independent(self, pdk):
        """Two deep copies of the same PDK device are independent."""
        dev1 = copy.deepcopy(pdk._devices['nmos1p8'])
        dev2 = copy.deepcopy(pdk._devices['nmos1p8'])

        # Modify pin on dev1
        dev1.pin_list['d'].net = 'out'

        # dev2 should not be affected
        assert dev2.pin_list['d'].net is None

    def test_deep_copy_param_independent(self, pdk):
        """Modifying param on one copy doesn't affect the other."""
        dev1 = copy.deepcopy(pdk._devices['nmos1p8'])
        dev2 = copy.deepcopy(pdk._devices['nmos1p8'])

        dev1.param_list['w'].value = 42
        assert dev2.param_list['w'].value is None


# ---------------------------------------------------------------------------
# generateNetlistEntry
# ---------------------------------------------------------------------------

class TestGenerateNetlistEntry:

    def test_returns_string(self, pdk):
        """generateNetlistEntry returns a string."""
        dev = copy.deepcopy(pdk._devices['nmos1p8'])
        # Set up pin connections
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        # Set parameter values (need ModuleVariable-like objects)
        from unittest.mock import MagicMock
        for param_name, constraint in dev.param_list.items():
            mock_val = MagicMock()
            mock_val.value = 1.0
            constraint.value = mock_val

        details = {'device': dev}
        result = pdk.generateNetlistEntry('N1', details)
        assert isinstance(result, str)

    def test_contains_instance_name(self, pdk):
        """generateNetlistEntry output contains the instance name."""
        dev = copy.deepcopy(pdk._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        from unittest.mock import MagicMock
        for param_name, constraint in dev.param_list.items():
            mock_val = MagicMock()
            mock_val.value = 1.0
            constraint.value = mock_val

        details = {'device': dev}
        result = pdk.generateNetlistEntry('N1', details)
        assert 'XMN1' in result

    def test_contains_pdk_device_name(self, pdk):
        """generateNetlistEntry output contains the PDK device name."""
        dev = copy.deepcopy(pdk._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        from unittest.mock import MagicMock
        for param_name, constraint in dev.param_list.items():
            mock_val = MagicMock()
            mock_val.value = 1.0
            constraint.value = mock_val

        details = {'device': dev}
        result = pdk.generateNetlistEntry('N1', details)
        assert 'sky130_fd_pr__nfet_01v8' in result


# ---------------------------------------------------------------------------
# BasePDK __init__ paths — UNIT_SI notice, debug=True
# ---------------------------------------------------------------------------

class TestBasePDKInit:

    def test_unit_pdk_prints_notice(self, pdk_yaml_path, capsys):
        """UNIT_PDK mode prints a startup notice about native units."""
        from silk.pdk.skywater130 import PDK_skywater130, UNIT_PDK

        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib', unit_mode=UNIT_PDK)
        out = capsys.readouterr().out
        assert 'Unit mode' in out or 'PDK' in out or 'native' in out or 'µm' in out

    def test_unit_si_no_pdk_notice(self, pdk_yaml_path, capsys):
        """UNIT_SI mode does not print the PDK-native units startup notice."""
        from silk.pdk.skywater130 import PDK_skywater130, UNIT_SI

        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib', unit_mode=UNIT_SI)
        out = capsys.readouterr().out
        # The PDK-native notice is only printed for UNIT_PDK
        assert 'Unit mode: PDK defaults' not in out

    def test_debug_true_prints_device_summary(self, pdk_yaml_path, capsys):
        """debug=True prints the loaded device summary after YAML parsing."""
        from silk.pdk.skywater130 import PDK_skywater130

        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib', debug=True)
        out = capsys.readouterr().out
        # _parse_standard_yaml prints 'PDK loaded: N devices (...)' when debug=True
        assert 'PDK loaded' in out
        assert 'nmos1p8' in out

    def test_debug_true_prints_raw_config(self, pdk_yaml_path, capsys):
        """debug=True also prints the raw config_data dict."""
        from silk.pdk.skywater130 import PDK_skywater130

        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib', debug=True)
        out = capsys.readouterr().out
        # config_data is a dict; its repr contains 'PDKDevice'
        assert 'PDKDevice' in out


# ---------------------------------------------------------------------------
# BasePDK.getCornerPath — base implementation returns libraryLocation
# ---------------------------------------------------------------------------

class TestGetCornerPath:

    def test_base_get_corner_path_returns_library_location(self, pdk_yaml_path):
        """BasePDK.getCornerPath returns libraryLocation unchanged."""
        from silk.pdk.basepdk import BasePDK

        lib = '/some/path/sky130.lib.spice'
        pdk = BasePDK(pdk_yaml_path, libraryLocation=lib)
        assert pdk.getCornerPath('tt') == lib
        assert pdk.getCornerPath('ss') == lib
        assert pdk.getCornerPath('ff') == lib


# ---------------------------------------------------------------------------
# generateNetlistEntry — UNIT_SI conversion and dimensionless integer param
# ---------------------------------------------------------------------------

class TestGenerateNetlistEntryUnitSI:

    def _make_details(self, pdk, param_values):
        """Helper: deep-copy nmos1p8, set pin nets and param values."""
        import copy
        dev = copy.deepcopy(pdk._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        for p, val in param_values.items():
            dev.param_list[p].value = val
        return {'device': dev}

    def test_unit_si_w_converted_to_um(self, pdk_yaml_path, capsys):
        """UNIT_SI mode multiplies W (metres) by 1e6 to get µm."""
        from silk.pdk.skywater130 import PDK_skywater130, UNIT_SI

        pdk_si = PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib',
                                 unit_mode=UNIT_SI)
        # 0.42e-6 m == 0.42 µm — expected converted value is 0.42
        details = self._make_details(pdk_si, {'w': 0.42e-6, 'l': 0.15e-6, 'm': 1})
        result = pdk_si.generateNetlistEntry('N1', details)
        # 0.42e-6 * 1e6 = 0.42
        assert 'w=0.42' in result

    def test_unit_si_l_converted_to_um(self, pdk_yaml_path, capsys):
        """UNIT_SI mode multiplies L (metres) by 1e6 to get µm."""
        from silk.pdk.skywater130 import PDK_skywater130, UNIT_SI

        pdk_si = PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib',
                                 unit_mode=UNIT_SI)
        details = self._make_details(pdk_si, {'w': 0.42e-6, 'l': 0.15e-6, 'm': 1})
        result = pdk_si.generateNetlistEntry('N1', details)
        # 0.15e-6 * 1e6 = 0.15
        assert 'l=0.15' in result

    def test_unit_pdk_no_conversion(self, pdk_yaml_path):
        """UNIT_PDK mode does not scale W/L values."""
        from silk.pdk.skywater130 import PDK_skywater130, UNIT_PDK

        pdk_pdk = PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib',
                                  unit_mode=UNIT_PDK)
        details = self._make_details(pdk_pdk, {'w': 1.0, 'l': 0.15, 'm': 1})
        result = pdk_pdk.generateNetlistEntry('N1', details)
        assert 'w=1.0' in result
        assert 'l=0.15' in result


class TestGenerateNetlistEntryDimensionless:

    def test_dimensionless_integer_param_no_warning(self, pdk, capsys):
        """Dimensionless param 'm' with integer value produces no warning."""
        import copy
        dev = copy.deepcopy(pdk._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        dev.param_list['w'].value = 1.0
        dev.param_list['l'].value = 0.15
        dev.param_list['m'].value = 2   # integer — valid

        details = {'device': dev}
        pdk.generateNetlistEntry('N1', details)
        out = capsys.readouterr().out
        assert 'WARNING' not in out

    def test_dimensionless_param_in_netlist(self, pdk):
        """Dimensionless param 'm' appears in generated netlist string."""
        import copy
        dev = copy.deepcopy(pdk._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        dev.param_list['w'].value = 1.0
        dev.param_list['l'].value = 0.15
        dev.param_list['m'].value = 3

        details = {'device': dev}
        result = pdk.generateNetlistEntry('N1', details)
        assert 'm=3' in result


# ---------------------------------------------------------------------------
# generateNetlistEntry debug=True path
# ---------------------------------------------------------------------------

class TestGenerateNetlistEntryDebug:

    def test_debug_prints_param_names_and_netlist(self, pdk_yaml_path, capsys):
        """debug=True in generateNetlistEntry prints param names and the entry."""
        import copy
        from silk.pdk.skywater130 import PDK_skywater130

        pdk_debug = PDK_skywater130(pdk_yaml_path, libraryLocation='/fake/lib',
                                    debug=True)
        capsys.readouterr()  # clear init output

        dev = copy.deepcopy(pdk_debug._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        dev.param_list['w'].value = 1.0
        dev.param_list['l'].value = 0.15
        dev.param_list['m'].value = 1

        details = {'device': dev}
        pdk_debug.generateNetlistEntry('N1', details)
        out = capsys.readouterr().out
        # debug=True should print param names ('w', 'l', 'm') and the entry line
        assert 'w' in out
        assert 'XMN1' in out


# ---------------------------------------------------------------------------
# ParameterConstraint.validate_value — warning paths
# ---------------------------------------------------------------------------

class TestParameterConstraintValidateValue:

    def test_maxval_bounded_no_warning_within_range(self, capsys):
        """No warning when value is within bounded maxval."""
        pc = ParameterConstraint(minval='0.15', maxval='10.0', value=None, unit='u')
        pc.validate_value(5.0, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' not in out

    def test_maxval_bounded_warns_above_max(self, capsys):
        """Warning printed when value exceeds bounded maxval != '-1'."""
        pc = ParameterConstraint(minval='0.15', maxval='2.0', value=None, unit='u')
        pc.validate_value(5.0, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' in out
        assert 'exceeds maximum' in out

    def test_maxval_minus1_unbounded_no_warning(self, capsys):
        """No warning when maxval='-1' (unbounded) regardless of value."""
        pc = ParameterConstraint(minval='0.15', maxval='-1', value=None, unit='u')
        pc.validate_value(999.0, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' not in out

    def test_dimensionless_non_integer_warns(self, capsys):
        """Dimensionless param (no unit) with non-integer value prints warning."""
        pc = ParameterConstraint(minval='1', maxval='-1', value=None, unit=None)
        pc.validate_value(1.5, 'm')
        out = capsys.readouterr().out
        assert 'WARNING' in out
        assert 'integer' in out

    def test_dimensionless_integer_no_warn(self, capsys):
        """Dimensionless param with exact integer value does not warn."""
        pc = ParameterConstraint(minval='1', maxval='-1', value=None, unit=None)
        pc.validate_value(2, 'm')
        out = capsys.readouterr().out
        assert 'WARNING' not in out

    def test_below_minval_warns(self, capsys):
        """Warning printed when value is below minval."""
        pc = ParameterConstraint(minval='0.42', maxval='-1', value=None, unit='u')
        pc.validate_value(0.1, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' in out
        assert 'below minimum' in out

    def test_at_minval_no_warn(self, capsys):
        """No warning when value equals minval exactly."""
        pc = ParameterConstraint(minval='0.42', maxval='-1', value=None, unit='u')
        pc.validate_value(0.42, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' not in out

    def test_non_numeric_value_warns(self, capsys):
        """Non-numeric value prints a validation warning."""
        pc = ParameterConstraint(minval='0.15', maxval='-1', value=None, unit='u')
        pc.validate_value('not_a_number', 'w')
        out = capsys.readouterr().out
        assert 'WARNING' in out

# ---------------------------------------------------------------------------
# ParameterConstraint.validate_value — maxval bound
# ---------------------------------------------------------------------------

class TestParameterConstraintMaxval:

    def test_above_maxval_warns(self, capsys):
        """Warning printed when value exceeds maxval."""
        pc = ParameterConstraint(minval='0.15', maxval='10.0', value=None, unit='u')
        pc.validate_value(15.0, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' in out
        assert 'exceeds maximum' in out

    def test_at_maxval_no_warn(self, capsys):
        """No warning when value equals maxval exactly."""
        pc = ParameterConstraint(minval='0.15', maxval='10.0', value=None, unit='u')
        pc.validate_value(10.0, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' not in out

    def test_maxval_minus_one_unbounded(self, capsys):
        """maxval='-1' means unbounded — no warning for any large value."""
        pc = ParameterConstraint(minval='0.15', maxval='-1', value=None, unit='u')
        pc.validate_value(1000.0, 'w')
        out = capsys.readouterr().out
        assert 'WARNING' not in out


# ---------------------------------------------------------------------------
# BasePDK — UNIT_SI mode and debug output
# ---------------------------------------------------------------------------

class TestBasePDKUnitMode:

    def test_unit_pdk_prints_notice(self, pdk_yaml_path, capsys):
        """UNIT_PDK mode prints a unit notice on construction."""
        from silk.pdk.basepdk import UNIT_PDK
        from silk.pdk.skywater130 import PDK_skywater130
        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake', unit_mode=UNIT_PDK)
        out = capsys.readouterr().out
        assert 'PDK' in out or 'unit' in out.lower()

    def test_unit_si_no_notice(self, pdk_yaml_path, capsys):
        """UNIT_SI mode does not print a PDK unit notice."""
        from silk.pdk.basepdk import UNIT_SI
        from silk.pdk.skywater130 import PDK_skywater130
        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake', unit_mode=UNIT_SI)
        out = capsys.readouterr().out
        assert 'PDK defaults' not in out

    def test_debug_prints_device_list(self, pdk_yaml_path, capsys):
        """debug=True prints loaded device names during construction."""
        from silk.pdk.skywater130 import PDK_skywater130
        PDK_skywater130(pdk_yaml_path, libraryLocation='/fake', debug=True)
        out = capsys.readouterr().out
        assert 'PDK loaded' in out

    def test_unit_si_scales_width(self, pdk_yaml_path):
        """UNIT_SI mode converts W in metres to PDK microns in netlist output."""
        import copy
        from silk.pdk.basepdk import UNIT_SI
        from silk.pdk.skywater130 import PDK_skywater130

        pdk_si = PDK_skywater130(pdk_yaml_path, libraryLocation='/fake', unit_mode=UNIT_SI)
        device = copy.deepcopy(pdk_si._devices['nmos1p8'])
        for pin_name, pin in device.pin_list.items():
            pin.net = 'net_' + pin_name
        # Set W to 2e-6 m (2 µm in SI), plain values matching existing test pattern
        device.param_list['w'].value = 2e-6
        device.param_list['l'].value = 0.15e-6
        device.param_list['m'].value = 1

        result = pdk_si.generateNetlistEntry('mn1', {'device': device})
        # 2e-6 * 1e6 = 2.0 µm
        assert 'w=2.0' in result


class TestBasePDKGetCornerPath:

    def test_get_corner_path_returns_library_location(self, pdk):
        """getCornerPath() returns the libraryLocation unchanged."""
        result = pdk.getCornerPath('tt')
        assert result == pdk.libraryLocation

    def test_get_corner_path_same_for_all_corners(self, pdk):
        """getCornerPath() returns the same path regardless of corner."""
        assert pdk.getCornerPath('tt') == pdk.getCornerPath('ss')
        assert pdk.getCornerPath('ff') == pdk.getCornerPath('sf')


# ---------------------------------------------------------------------------
# Coverage gaps in basepdk.py
# ---------------------------------------------------------------------------

class TestParameterConstraintValidateValueEdgeCases:
    """Target lines 101-102 and 111-112: ValueError in minval/maxval float()."""

    def test_minval_non_numeric_string_no_crash(self, capsys):
        """validate_value does not crash when minval is a non-numeric string (line 101-102)."""
        pc = ParameterConstraint(minval='auto', maxval='-1', value=None, unit='u')
        # Should not raise — the except ValueError branch on line 101-102 silently passes
        pc.validate_value(0.5, 'w')
        # No crash is the assertion; no WARNING for minval since minval not parseable

    def test_maxval_non_numeric_string_no_crash(self, capsys):
        """validate_value does not crash when maxval is a non-numeric string (line 111-112)."""
        pc = ParameterConstraint(minval='0.15', maxval='unbounded', value=None, unit='u')
        # Should not raise — the except ValueError branch on line 111-112 silently passes
        pc.validate_value(999.0, 'w')
        # No crash is the assertion


class TestParseStandardYamlErrorPaths:
    """Target lines 207-210 (YAMLError, KeyError) and 214 (duplicate device)."""

    def test_yaml_error_raises_validation_error(self, tmp_path):
        """_parse_standard_yaml raises ValidationError for invalid YAML (line 207-208)."""
        bad_yaml = tmp_path / 'bad.yaml'
        bad_yaml.write_text(': : : invalid: yaml: {{{\n')
        from silk.pdk.basepdk import BasePDK, ValidationError as PDKValidationError
        with pytest.raises(PDKValidationError, match='Error parsing YAML'):
            BasePDK(str(bad_yaml), libraryLocation='/fake')

    def test_missing_key_raises_validation_error(self, tmp_path):
        """_parse_standard_yaml raises ValidationError for missing YAML key (line 209-210)."""
        # Valid YAML but missing required 'PDKDevice' key
        incomplete_yaml = tmp_path / 'incomplete.yaml'
        incomplete_yaml.write_text(
            'mydevice:\n'
            '  paramList:\n'
            '    w:\n'
            '      minval: "0.42"\n'
            '      maxval: "-1"\n'
            '  pinList:\n'
            '    d: drain\n'
            # Note: 'PDKDevice' key intentionally missing
        )
        from silk.pdk.basepdk import BasePDK, ValidationError as PDKValidationError
        with pytest.raises(PDKValidationError, match='Missing required field'):
            BasePDK(str(incomplete_yaml), libraryLocation='/fake')


class TestGenerateNetlistEntrySymbolicParam:
    """Target lines 262-263: except (ValueError, TypeError) in SI conversion."""

    def test_symbolic_param_skips_si_conversion(self, pdk_yaml_path):
        """SI conversion is skipped for non-numeric (symbolic) param values (line 262-263)."""
        import copy
        from silk.pdk.skywater130 import PDK_skywater130, UNIT_SI

        pdk_si = PDK_skywater130(pdk_yaml_path, libraryLocation='/fake', unit_mode=UNIT_SI)
        dev = copy.deepcopy(pdk_si._devices['nmos1p8'])
        for pin_name, pin in dev.pin_list.items():
            pin.net = 'net_' + pin_name
        # Use a symbolic string that cannot be converted to float
        dev.param_list['w'].value = '{w_param}'
        dev.param_list['l'].value = 0.15e-6
        dev.param_list['m'].value = 1

        # Should not raise — ValueError/TypeError branch at line 262-263 catches it
        result = pdk_si.generateNetlistEntry('N1', {'device': dev})
        assert isinstance(result, str)
        assert '{w_param}' in result


class TestDuplicateDeviceInYaml:
    """Target line 214: raise PyNetlistError when duplicate device name in YAML."""

    def test_duplicate_device_raises_system_exit(self, tmp_path):
        """_parse_standard_yaml raises PyNetlistError for duplicate device names (line 214).

        Note: YAML itself merges duplicate keys so they become a single entry.
        We simulate the duplicate condition by patching _devices after load.
        """
        from unittest.mock import patch
        from silk.pdk.basepdk import BasePDK

        # We need a valid YAML, then monkeypatch list() to return a list with duplicates
        # Actually the easiest path: subclass and inject duplicate into _devices after parse
        # But the check is: len(set(model_names)) != len(model_names)
        # Since dict keys are always unique, this check can never be True with standard parsing.
        # The only way to reach line 214 is if _devices has duplicate keys — which a dict cannot.
        # Therefore this line is structurally dead code and cannot be covered. Skip.
        pytest.skip("Line 214 is structurally unreachable: dict keys are always unique")
