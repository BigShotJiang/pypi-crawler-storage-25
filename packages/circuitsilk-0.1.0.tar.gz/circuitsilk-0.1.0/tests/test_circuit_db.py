"""
Tests for circuit_db.CircuitDatabase and DesignStage.

All tests use in-memory SQLite via the in_memory_db and db_with_circuit fixtures.
"""

import pytest

from silk.db.circuit_db import CircuitDatabase, DesignStage


# ---------------------------------------------------------------------------
# DesignStage enum
# ---------------------------------------------------------------------------

class TestDesignStage:

    def test_dev_value(self):
        """DesignStage.DEV has value 'dev'."""
        assert DesignStage.DEV.value == 'dev'

    def test_stable_value(self):
        """DesignStage.STABLE has value 'stable'."""
        assert DesignStage.STABLE.value == 'stable'

    def test_post_layout_value(self):
        """DesignStage.POST_LAYOUT has value 'post_layout'."""
        assert DesignStage.POST_LAYOUT.value == 'post_layout'

    def test_tapeout_value(self):
        """DesignStage.TAPEOUT has value 'tapeout'."""
        assert DesignStage.TAPEOUT.value == 'tapeout'

    def test_all_stages_present(self):
        """All four design stages exist in the enum."""
        members = [s.name for s in DesignStage]
        assert set(members) == {'DEV', 'STABLE', 'POST_LAYOUT', 'TAPEOUT'}


# ---------------------------------------------------------------------------
# create_circuit
# ---------------------------------------------------------------------------

class TestCreateCircuit:

    def test_returns_string_id(self, in_memory_db):
        """create_circuit returns a string circuit_id."""
        cid = in_memory_db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        assert isinstance(cid, str)
        assert len(cid) > 0

    def test_circuit_appears_in_db(self, in_memory_db):
        """Created circuit is retrievable from the database."""
        cid = in_memory_db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        info = in_memory_db.get_circuit_by_id(cid)
        assert info is not None
        assert info['circuit_name'] == 'amp'
        assert info['version'] == '1.0'
        assert info['stage'] == 'dev'

    def test_circuit_with_description(self, in_memory_db):
        """Circuit description is stored correctly."""
        cid = in_memory_db.create_circuit(
            name='ldo', version='2.0', stage=DesignStage.STABLE,
            description='Low dropout regulator'
        )
        info = in_memory_db.get_circuit_by_id(cid)
        assert info['description'] == 'Low dropout regulator'


# ---------------------------------------------------------------------------
# get_circuit_by_id (aliased as get_circuit_info in the task)
# ---------------------------------------------------------------------------

class TestGetCircuitInfo:

    def test_returns_dict_with_expected_keys(self, db_with_circuit):
        """get_circuit_by_id returns dict with standard keys."""
        db, circuit_id = db_with_circuit
        info = db.get_circuit_by_id(circuit_id)
        expected_keys = {'version_id', 'circuit_name', 'version', 'stage',
                         'created_at', 'netlist_path', 'description', 'metadata'}
        assert expected_keys.issubset(set(info.keys()))

    def test_returns_none_for_invalid_id(self, in_memory_db):
        """get_circuit_by_id returns None for nonexistent ID."""
        assert in_memory_db.get_circuit_by_id('nonexistent-uuid') is None

    def test_alias_matches(self, db_with_circuit):
        """get_circuit_by_version_id is an alias that returns same result."""
        db, circuit_id = db_with_circuit
        assert db.get_circuit_by_version_id(circuit_id) == db.get_circuit_by_id(circuit_id)


# ---------------------------------------------------------------------------
# add_simulation_result
# ---------------------------------------------------------------------------

class TestAddSimulationResult:

    def test_returns_sim_id(self, db_with_circuit):
        """add_simulation_result returns a sim_id string."""
        db, cid = db_with_circuit
        sid = db.add_simulation_result(circuit_version_id=cid, parameter='gain', value=42.5, unit='dB')
        assert isinstance(sid, str)
        assert len(sid) > 0

    def test_result_appears_in_db(self, db_with_circuit):
        """Stored simulation result is retrievable."""
        db, cid = db_with_circuit
        db.add_simulation_result(circuit_version_id=cid, parameter='gain', value=42.5, unit='dB')
        results = db.get_simulation_results(cid)
        assert len(results) >= 1
        assert any(r['parameter'] == 'gain' for r in results)

    def test_result_with_corner_temperature_voltage(self, db_with_circuit):
        """Corner, temperature, and voltage are stored correctly."""
        db, cid = db_with_circuit
        db.add_simulation_result(
            circuit_version_id=cid, parameter='power', value=2.3, unit='mW',
            corner='ff', temperature=85.0, voltage=1.98
        )
        results = db.get_simulation_results(cid, parameter='power')
        assert len(results) == 1
        r = results[0]
        assert r['corner'] == 'ff'
        assert r['temperature'] == 85.0
        assert r['voltage'] == 1.98

    def test_multiple_results_for_same_circuit(self, db_with_circuit):
        """Multiple simulation results for same circuit are all retrievable."""
        db, cid = db_with_circuit
        db.add_simulation_result(circuit_version_id=cid, parameter='gain', value=42.5, unit='dB')
        db.add_simulation_result(circuit_version_id=cid, parameter='bandwidth', value=1e6, unit='Hz')
        db.add_simulation_result(circuit_version_id=cid, parameter='power', value=2.3, unit='mW')
        results = db.get_simulation_results(cid)
        assert len(results) == 3

    def test_multiple_corners_stored_independently(self, db_with_circuit):
        """Same parameter at different corners stored as separate records."""
        db, cid = db_with_circuit
        for corner in ['tt', 'ff', 'ss']:
            db.add_simulation_result(
                circuit_version_id=cid, parameter='gain', value=42.5,
                unit='dB', corner=corner
            )
        results = db.get_simulation_results(cid, parameter='gain')
        assert len(results) == 3
        corners = {r['corner'] for r in results}
        assert corners == {'tt', 'ff', 'ss'}

    def test_corner_filter_returns_only_matching_corner(self, db_with_circuit):
        """Filtering by corner returns only results for that corner."""
        db, cid = db_with_circuit
        for corner in ['tt', 'ff', 'ss']:
            db.add_simulation_result(
                circuit_version_id=cid, parameter='gain', value=42.5,
                unit='dB', corner=corner
            )
        results = db.get_simulation_results(cid, corner='tt')
        assert len(results) == 1
        assert results[0]['corner'] == 'tt'


# ---------------------------------------------------------------------------
# insert_or_get_module
# ---------------------------------------------------------------------------

class TestInsertOrGetModule:

    def test_first_call_inserts(self, in_memory_db):
        """First call with a new hash creates a module and returns its ID."""
        mid = in_memory_db.insert_or_get_module(
            module_name='inv', module_path='top.inv',
            module_hash='abc123', device_count=2
        )
        assert isinstance(mid, str)
        assert len(mid) > 0

    def test_second_call_returns_same_id(self, in_memory_db):
        """Second call with same hash returns the existing module_id."""
        mid1 = in_memory_db.insert_or_get_module(
            module_name='inv', module_path='top.inv',
            module_hash='abc123', device_count=2
        )
        mid2 = in_memory_db.insert_or_get_module(
            module_name='inv', module_path='top.inv',
            module_hash='abc123', device_count=2
        )
        assert mid1 == mid2

    def test_different_hash_creates_new(self, in_memory_db):
        """Different hash creates a new module with different ID."""
        mid1 = in_memory_db.insert_or_get_module(
            module_name='inv', module_path='top.inv',
            module_hash='hash_a', device_count=2
        )
        mid2 = in_memory_db.insert_or_get_module(
            module_name='inv_v2', module_path='top.inv',
            module_hash='hash_b', device_count=3
        )
        assert mid1 != mid2


# ---------------------------------------------------------------------------
# link_module_to_circuit
# ---------------------------------------------------------------------------

class TestLinkModuleToCircuit:

    def test_link_created(self, db_with_circuit):
        """link_module_to_circuit creates a junction record in DB."""
        db, cid = db_with_circuit
        mid = db.insert_or_get_module(
            module_name='buffer', module_path='top.buf',
            module_hash='buf_hash', device_count=4
        )
        db.link_module_to_circuit(cid, mid, instance_name='buf_0')
        modules = db.get_circuit_modules(cid)
        assert len(modules) == 1
        assert modules[0]['module_name'] == 'buffer'
        assert modules[0]['instance_name'] == 'buf_0'

    def test_multiple_links(self, db_with_circuit):
        """Multiple modules can be linked to the same circuit."""
        db, cid = db_with_circuit
        mid1 = db.insert_or_get_module('mod_a', 'top.a', 'ha', 2)
        mid2 = db.insert_or_get_module('mod_b', 'top.b', 'hb', 3)
        db.link_module_to_circuit(cid, mid1, instance_name='a_0')
        db.link_module_to_circuit(cid, mid2, instance_name='b_0')
        modules = db.get_circuit_modules(cid)
        assert len(modules) == 2


# ---------------------------------------------------------------------------
# db_with_circuit fixture
# ---------------------------------------------------------------------------

class TestDBWithCircuit:

    def test_circuit_id_is_valid(self, db_with_circuit):
        """db_with_circuit fixture provides a valid circuit_id."""
        db, circuit_id = db_with_circuit
        assert isinstance(circuit_id, str)
        assert len(circuit_id) > 0

    def test_circuit_id_reusable(self, db_with_circuit):
        """circuit_id from fixture can be used to query the database."""
        db, circuit_id = db_with_circuit
        info = db.get_circuit_by_id(circuit_id)
        assert info is not None
        assert info['circuit_name'] == 'test_inverter'


# ---------------------------------------------------------------------------
# get_circuits_using_module
# ---------------------------------------------------------------------------

class TestGetCircuitsUsingModule:

    def test_returns_circuits_using_module(self, db_with_circuit):
        """Returns circuits that use a module with the given hash."""
        db, cid = db_with_circuit
        mid = db.insert_or_get_module('buf', 'top.buf', 'hash_xyz', 2)
        db.link_module_to_circuit(cid, mid, instance_name='buf_0')
        circuits = db.get_circuits_using_module('hash_xyz')
        assert len(circuits) == 1
        assert circuits[0]['version_id'] == cid
        assert circuits[0]['circuit_name'] == 'test_inverter'

    def test_returns_empty_for_unused_hash(self, in_memory_db):
        """Returns empty list when no circuit uses the module hash."""
        assert db.get_circuits_using_module('nonexistent') == [] if (db := in_memory_db) else True

    def test_multiple_circuits_using_same_module(self, in_memory_db):
        """Multiple circuits using the same module are all returned."""
        db = in_memory_db
        cid1 = db.create_circuit(name='amp1', version='1.0', stage=DesignStage.DEV)
        cid2 = db.create_circuit(name='amp2', version='1.0', stage=DesignStage.DEV)
        mid = db.insert_or_get_module('shared', 'top.shared', 'shared_hash', 3)
        db.link_module_to_circuit(cid1, mid, instance_name='s0')
        db.link_module_to_circuit(cid2, mid, instance_name='s0')
        circuits = db.get_circuits_using_module('shared_hash')
        assert len(circuits) == 2
        names = {c['circuit_name'] for c in circuits}
        assert names == {'amp1', 'amp2'}


# ---------------------------------------------------------------------------
# compare_circuit_modules
# ---------------------------------------------------------------------------

class TestCompareCircuitModules:

    def test_identical_modules(self, in_memory_db):
        """Two circuits with the same module show it as unchanged."""
        db = in_memory_db
        cid1 = db.create_circuit(name='c1', version='1.0', stage=DesignStage.DEV)
        cid2 = db.create_circuit(name='c2', version='1.0', stage=DesignStage.DEV)
        mid = db.insert_or_get_module('mod', 'top.mod', 'h1', 2)
        db.link_module_to_circuit(cid1, mid, instance_name='m0')
        db.link_module_to_circuit(cid2, mid, instance_name='m0')
        result = db.compare_circuit_modules(cid1, cid2)
        assert len(result['unchanged']) == 1
        assert len(result['added']) == 0
        assert len(result['removed']) == 0

    def test_added_module(self, in_memory_db):
        """Module in circuit 2 but not circuit 1 shows as added."""
        db = in_memory_db
        cid1 = db.create_circuit(name='c1', version='1.0', stage=DesignStage.DEV)
        cid2 = db.create_circuit(name='c2', version='1.0', stage=DesignStage.DEV)
        mid = db.insert_or_get_module('mod_new', 'top.new', 'h_new', 1)
        db.link_module_to_circuit(cid2, mid, instance_name='m0')
        result = db.compare_circuit_modules(cid1, cid2)
        assert len(result['added']) == 1
        assert len(result['removed']) == 0

    def test_removed_module(self, in_memory_db):
        """Module in circuit 1 but not circuit 2 shows as removed."""
        db = in_memory_db
        cid1 = db.create_circuit(name='c1', version='1.0', stage=DesignStage.DEV)
        cid2 = db.create_circuit(name='c2', version='1.0', stage=DesignStage.DEV)
        mid = db.insert_or_get_module('mod_old', 'top.old', 'h_old', 1)
        db.link_module_to_circuit(cid1, mid, instance_name='m0')
        result = db.compare_circuit_modules(cid1, cid2)
        assert len(result['removed']) == 1
        assert len(result['added']) == 0


# ---------------------------------------------------------------------------
# update_circuit
# ---------------------------------------------------------------------------

class TestUpdateCircuit:

    def test_update_with_base_version(self, in_memory_db):
        """update_circuit with explicit base_version links parent."""
        db = in_memory_db
        cid1 = db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        cid2 = db.update_circuit('amp', '2.0', stage=DesignStage.DEV, base_version='1.0')
        info = db.get_circuit_by_id(cid2)
        assert info is not None
        assert info['version'] == '2.0'

    def test_update_without_base_version(self, in_memory_db):
        """update_circuit without base_version uses latest as parent."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        cid2 = db.update_circuit('amp', '2.0', stage=DesignStage.DEV)
        info = db.get_circuit_by_id(cid2)
        assert info is not None
        assert info['version'] == '2.0'


# ---------------------------------------------------------------------------
# add_device / add_net
# ---------------------------------------------------------------------------

class TestAddDevice:

    def test_add_device_returns_id(self, db_with_circuit):
        """add_device returns a device_id string."""
        db, cid = db_with_circuit
        did = db.add_device(cid, 'M1', 'nmos', model='sky130_nfet', width=10e-6, length=180e-9)
        assert isinstance(did, str) and len(did) > 0

    def test_add_device_without_properties(self, db_with_circuit):
        """add_device works without extra properties."""
        db, cid = db_with_circuit
        did = db.add_device(cid, 'R1', 'resistor')
        assert isinstance(did, str)

    def test_add_transistor_returns_id(self, db_with_circuit):
        """add_transistor returns a device_id and stores transistor data."""
        db, cid = db_with_circuit
        did = db.add_transistor(cid, 'M2', 'nmos', width=5e-6, length=180e-9, multiplier=2)
        assert isinstance(did, str) and len(did) > 0


class TestAddNet:

    def test_add_net_returns_id(self, db_with_circuit):
        """add_net returns a net_id string."""
        db, cid = db_with_circuit
        nid = db.add_net(cid, 'vdd', net_type='power')
        assert isinstance(nid, str) and len(nid) > 0

    def test_add_net_without_properties(self, db_with_circuit):
        """add_net works without type or properties."""
        db, cid = db_with_circuit
        nid = db.add_net(cid, 'sig_out')
        assert isinstance(nid, str)


# ---------------------------------------------------------------------------
# get_latest (various branches)
# ---------------------------------------------------------------------------

class TestGetLatest:

    def test_get_latest_with_stage(self, in_memory_db):
        """get_latest with stage filter returns correct circuit."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        result = db.get_latest('amp', DesignStage.DEV)
        assert result is not None
        assert result['circuit_name'] == 'amp'

    def test_get_latest_without_stage(self, in_memory_db):
        """get_latest without stage returns the most recent version."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        result = db.get_latest('amp')
        assert result is not None
        assert result['circuit_name'] == 'amp'

    def test_get_latest_returns_none_for_unknown(self, in_memory_db):
        """get_latest returns None for nonexistent circuit."""
        assert in_memory_db.get_latest('nonexistent') is None


# ---------------------------------------------------------------------------
# get_version
# ---------------------------------------------------------------------------

class TestGetVersion:

    def test_get_version_found(self, in_memory_db):
        """get_version returns circuit info for existing name+version."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        result = db.get_version('amp', '1.0')
        assert result is not None
        assert result['version'] == '1.0'

    def test_get_version_not_found(self, in_memory_db):
        """get_version returns None for nonexistent version."""
        assert in_memory_db.get_version('amp', '99.0') is None


# ---------------------------------------------------------------------------
# promote_circuit / lock_circuit
# ---------------------------------------------------------------------------

class TestPromoteCircuit:

    def test_promote_success(self, in_memory_db):
        """promote_circuit creates a new version in the target stage."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        new_id = db.promote_circuit('amp', DesignStage.DEV, DesignStage.STABLE)
        info = db.get_circuit_by_id(new_id)
        assert info['stage'] == 'stable'

    def test_promote_no_source_raises(self, in_memory_db):
        """promote_circuit raises ValueError if source circuit not found."""
        with pytest.raises(ValueError, match="No circuit"):
            in_memory_db.promote_circuit('ghost', DesignStage.DEV, DesignStage.STABLE)


class TestLockCircuit:

    def test_lock_success(self, in_memory_db):
        """lock_circuit locks an existing circuit version."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.lock_circuit('amp', '1.0')
        # Verify via raw SQL
        cursor = db.conn.cursor()
        cursor.execute("SELECT is_locked FROM circuit_versions WHERE circuit_name='amp'")
        assert cursor.fetchone()[0] == 1

    def test_lock_not_found_raises(self, in_memory_db):
        """lock_circuit raises ValueError for nonexistent circuit."""
        with pytest.raises(ValueError, match="not found"):
            in_memory_db.lock_circuit('ghost', '1.0')


# ---------------------------------------------------------------------------
# get_all_circuit_versions
# ---------------------------------------------------------------------------

class TestGetAllCircuitVersions:

    def test_returns_all_versions(self, in_memory_db):
        """Returns all versions of a circuit."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.create_circuit(name='amp', version='2.0', stage=DesignStage.STABLE)
        versions = db.get_all_circuit_versions('amp')
        assert len(versions) == 2

    def test_returns_empty_for_unknown(self, in_memory_db):
        """Returns empty list for nonexistent circuit."""
        assert in_memory_db.get_all_circuit_versions('ghost') == []

    def test_invalid_order_by_defaults(self, in_memory_db):
        """Invalid order_by falls back to created_at."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        versions = db.get_all_circuit_versions('amp', order_by='invalid')
        assert len(versions) == 1


# ---------------------------------------------------------------------------
# get_most_simulated_circuit
# ---------------------------------------------------------------------------

class TestGetMostSimulatedCircuit:

    def test_returns_circuit_with_most_runs(self, in_memory_db):
        """Returns the circuit version with the highest run_count in metadata."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV, metadata={'run_count': 5})
        db.create_circuit(name='amp', version='2.0', stage=DesignStage.DEV, metadata={'run_count': 15})
        result = db.get_most_simulated_circuit('amp')
        assert result is not None
        assert result['metadata']['run_count'] == 15

    def test_returns_none_for_unknown(self, in_memory_db):
        """Returns None for nonexistent circuit name."""
        assert in_memory_db.get_most_simulated_circuit('ghost') is None

    def test_no_metadata_defaults_zero(self, in_memory_db):
        """Circuits without run_count metadata default to 0."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        result = db.get_most_simulated_circuit('amp')
        assert result is not None


# ---------------------------------------------------------------------------
# create_release
# ---------------------------------------------------------------------------

class TestCreateRelease:

    def test_create_empty_release(self, in_memory_db):
        """Creates a release with no circuits."""
        db = in_memory_db
        rid = db.create_release('v1.0-release', DesignStage.STABLE, notes='First release')
        assert isinstance(rid, str) and len(rid) > 0

    def test_create_release_with_circuits(self, in_memory_db):
        """Creates a release with circuit contents."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.STABLE)
        db.create_circuit(name='ldo', version='1.0', stage=DesignStage.STABLE)
        rid = db.create_release('v1.0-release', DesignStage.STABLE, circuit_names=['amp', 'ldo'])
        assert isinstance(rid, str) and len(rid) > 0

    def test_release_with_missing_circuit_skips(self, in_memory_db):
        """Release creation skips circuits that don't exist at that stage."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.STABLE)
        rid = db.create_release('v1.0-release', DesignStage.STABLE, circuit_names=['amp', 'ghost'])
        assert isinstance(rid, str)


# ---------------------------------------------------------------------------
# list_circuits
# ---------------------------------------------------------------------------

class TestListCircuits:

    def test_list_all(self, in_memory_db):
        """list_circuits without filter returns all circuits."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.create_circuit(name='ldo', version='1.0', stage=DesignStage.STABLE)
        result = db.list_circuits()
        assert len(result) == 2

    def test_list_by_stage(self, in_memory_db):
        """list_circuits with stage filter returns only matching circuits."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.create_circuit(name='ldo', version='1.0', stage=DesignStage.STABLE)
        result = db.list_circuits(stage=DesignStage.DEV)
        assert len(result) == 1
        assert result[0]['circuit_name'] == 'amp'


# ---------------------------------------------------------------------------
# get_circuit_summary
# ---------------------------------------------------------------------------

class TestGetCircuitSummary:

    def test_summary_with_all_data(self, in_memory_db):
        """Summary includes devices, nets, modules, and simulation results."""
        db = in_memory_db
        cid = db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.add_device(cid, 'M1', 'nmos', model='nfet')
        db.add_net(cid, 'vdd', net_type='power')
        mid = db.insert_or_get_module('buf', 'top.buf', 'hbuf', 1)
        db.link_module_to_circuit(cid, mid, instance_name='b0')
        db.add_simulation_result(cid, parameter='gain', value=40.0, unit='dB')
        summary = db.get_circuit_summary('amp', '1.0')
        assert summary is not None
        assert len(summary['devices']) == 1
        assert len(summary['nets']) == 1
        assert len(summary['modules']) == 1
        assert len(summary['simulation_results']) == 1

    def test_summary_latest_version(self, in_memory_db):
        """Summary without version uses latest."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        summary = db.get_circuit_summary('amp')
        assert summary is not None
        assert summary['circuit']['version'] == '1.0'

    def test_summary_returns_none_for_unknown(self, in_memory_db):
        """get_circuit_summary returns None for nonexistent circuit."""
        assert in_memory_db.get_circuit_summary('ghost') is None


# ---------------------------------------------------------------------------
# update_simulation_summary / get_simulation_summary
# ---------------------------------------------------------------------------

class TestSimulationSummary:

    def test_empty_summary(self, db_with_circuit):
        """update_simulation_summary returns empty string when no results."""
        db, cid = db_with_circuit
        summary = db.update_simulation_summary(cid)
        assert summary == ""

    def test_single_result_summary(self, db_with_circuit):
        """Summary for single result includes parameter name and value."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=42.0, unit='dB',
                                 corner='tt', temperature=27.0, voltage=1.8)
        summary = db.update_simulation_summary(cid)
        assert 'gain' in summary
        assert 'SIMULATION SUMMARY' in summary

    def test_multi_corner_summary(self, db_with_circuit):
        """Summary for multi-corner results shows range."""
        db, cid = db_with_circuit
        for corner, val in [('tt', 42.0), ('ss', 38.0), ('ff', 46.0)]:
            db.add_simulation_result(cid, parameter='gain', value=val, unit='dB',
                                     corner=corner, temperature=27.0, voltage=1.8)
        summary = db.update_simulation_summary(cid)
        assert '3 corners' in summary
        assert '38' in summary
        assert '46' in summary

    def test_summary_with_pass_fail_status(self, db_with_circuit):
        """Summary includes pass/fail status results."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain_check', value_text='PASS')
        summary = db.update_simulation_summary(cid)
        assert 'STATUS' in summary
        assert 'PASS' in summary

    def test_get_simulation_summary_cached(self, db_with_circuit):
        """get_simulation_summary returns cached summary after update."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=42.0, unit='dB', corner='tt')
        db.update_simulation_summary(cid)
        cached = db.get_simulation_summary(cid)
        assert 'gain' in cached

    def test_get_simulation_summary_generates_if_missing(self, db_with_circuit):
        """get_simulation_summary auto-generates if not cached."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='bw', value=1e6, unit='Hz', corner='tt')
        result = db.get_simulation_summary(cid)
        assert 'bw' in result

    def test_summary_no_conditions(self, db_with_circuit):
        """Summary works when temperature and voltage are None."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='offset', value=0.5, unit='mV', corner='tt')
        summary = db.update_simulation_summary(cid)
        assert 'offset' in summary

    def test_summary_single_result_no_value(self, db_with_circuit):
        """Summary handles a single result where value is None (value_text only)."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='status', value=None, value_text='OK', corner='tt')
        summary = db.update_simulation_summary(cid)
        assert 'STATUS' in summary


# ---------------------------------------------------------------------------
# add_parasitic
# ---------------------------------------------------------------------------

class TestAddParasitic:

    def test_add_parasitic_returns_id(self, db_with_circuit):
        """add_parasitic returns a parasitic_id string."""
        db, cid = db_with_circuit
        nid = db.add_net(cid, 'out', net_type='signal')
        pid = db.add_parasitic(cid, nid, 'capacitance', 1.5e-15, 'F',
                               from_node='out', to_node='gnd', extraction_tool='magic')
        assert isinstance(pid, str) and len(pid) > 0


# ---------------------------------------------------------------------------
# get_latest_circuit / get_latest_circuit_by_version
# ---------------------------------------------------------------------------

class TestLatestCircuitAliases:

    def test_get_latest_circuit_alias(self, in_memory_db):
        """get_latest_circuit is an alias for get_latest."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        result = db.get_latest_circuit('amp')
        assert result is not None
        assert result['circuit_name'] == 'amp'

    def test_get_latest_circuit_by_version(self, in_memory_db):
        """get_latest_circuit_by_version returns highest version."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.create_circuit(name='amp', version='2.0', stage=DesignStage.STABLE)
        result = db.get_latest_circuit_by_version('amp')
        assert result is not None
        assert result['version'] == '2.0'

    def test_get_latest_circuit_by_version_none(self, in_memory_db):
        """get_latest_circuit_by_version returns None for unknown circuit."""
        assert in_memory_db.get_latest_circuit_by_version('ghost') is None


# ---------------------------------------------------------------------------
# get_all_circuits_at_stage
# ---------------------------------------------------------------------------

class TestGetAllCircuitsAtStage:

    def test_returns_latest_of_each(self, in_memory_db):
        """Returns latest version of each circuit at the given stage."""
        db = in_memory_db
        db.create_circuit(name='amp', version='1.0', stage=DesignStage.DEV)
        db.create_circuit(name='ldo', version='1.0', stage=DesignStage.DEV)
        result = db.get_all_circuits_at_stage(DesignStage.DEV)
        assert len(result) == 2
        names = {c['circuit_name'] for c in result}
        assert names == {'amp', 'ldo'}

    def test_empty_stage(self, in_memory_db):
        """Returns empty list when no circuits at the stage."""
        assert in_memory_db.get_all_circuits_at_stage(DesignStage.TAPEOUT) == []


# ---------------------------------------------------------------------------
# get_corners_for_parameter
# ---------------------------------------------------------------------------

class TestGetCornersForParameter:

    def test_returns_corner_results(self, db_with_circuit):
        """Returns results across corners for a parameter."""
        db, cid = db_with_circuit
        for corner in ['tt', 'ss', 'ff']:
            db.add_simulation_result(cid, parameter='gain', value=40.0, unit='dB', corner=corner)
        results = db.get_corners_for_parameter(cid, 'gain')
        assert len(results) == 3

    def test_empty_for_unknown_param(self, db_with_circuit):
        """Returns empty list for nonexistent parameter."""
        db, cid = db_with_circuit
        assert db.get_corners_for_parameter(cid, 'nonexistent') == []


# ---------------------------------------------------------------------------
# get_corner_summary
# ---------------------------------------------------------------------------

class TestGetCornerSummary:

    def test_corner_summary_with_conditions(self, db_with_circuit):
        """Corner summary groups results by corner with conditions."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=42.0, unit='dB',
                                 corner='tt', temperature=27.0, voltage=1.8)
        db.add_simulation_result(cid, parameter='gain', value=38.0, unit='dB',
                                 corner='ss', temperature=85.0, voltage=1.62)
        summary = db.get_corner_summary(cid)
        assert 'tt' in summary
        assert 'ss' in summary

    def test_corner_summary_without_conditions(self, db_with_circuit):
        """Corner summary handles results with no temperature/voltage."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=42.0, unit='dB', corner='tt')
        summary = db.get_corner_summary(cid)
        assert 'tt' in summary

    def test_corner_summary_empty(self, db_with_circuit):
        """Corner summary is empty dict when no results exist."""
        db, cid = db_with_circuit
        assert db.get_corner_summary(cid) == {}

    def test_corner_summary_null_corner(self, db_with_circuit):
        """Corner summary handles null corner as 'nominal'."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=42.0, unit='dB')
        summary = db.get_corner_summary(cid)
        assert 'nominal' in summary


# ---------------------------------------------------------------------------
# update_simulation_summary
# ---------------------------------------------------------------------------

class TestUpdateSimulationSummary:

    def test_empty_results_returns_empty_string(self, db_with_circuit):
        """update_simulation_summary returns empty string when no results exist."""
        db, cid = db_with_circuit
        result = db.update_simulation_summary(cid)
        assert result == ""

    def test_single_result_produces_summary(self, db_with_circuit):
        """update_simulation_summary with one result produces a formatted summary."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=42.5, unit='dB', corner='tt')
        summary = db.update_simulation_summary(cid)
        assert 'gain' in summary
        assert '42.5' in summary

    def test_multi_corner_shows_range(self, db_with_circuit):
        """update_simulation_summary with multiple corners shows min-to-max range."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain', value=40.0, unit='dB', corner='ss')
        db.add_simulation_result(cid, parameter='gain', value=45.0, unit='dB', corner='ff')
        db.add_simulation_result(cid, parameter='gain', value=42.5, unit='dB', corner='tt')
        summary = db.update_simulation_summary(cid)
        assert 'gain' in summary
        assert 'to' in summary  # shows range "40 to 45"

    def test_summary_includes_status_text(self, db_with_circuit):
        """update_simulation_summary includes value_text (pass/fail) in summary."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='gain_check', value=None,
                                 value_text='PASS', unit=None)
        summary = db.update_simulation_summary(cid)
        assert 'STATUS' in summary
        assert 'PASS' in summary

    def test_get_simulation_summary_calls_update_if_empty(self, db_with_circuit):
        """get_simulation_summary generates summary when none cached."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='bw', value=1e6, unit='Hz')
        # Call get_simulation_summary which internally calls update if not cached
        result = db.get_simulation_summary(cid)
        assert 'bw' in result

    def test_multi_corner_with_conditions_shows_corner_detail(self, db_with_circuit):
        """Multi-corner summary shows each corner's individual value."""
        db, cid = db_with_circuit
        db.add_simulation_result(cid, parameter='power', value=2.3, unit='mW',
                                 corner='tt', temperature=27.0, voltage=1.8)
        db.add_simulation_result(cid, parameter='power', value=3.1, unit='mW',
                                 corner='ff', temperature=85.0, voltage=1.98)
        summary = db.update_simulation_summary(cid)
        assert 'power' in summary
        assert 'tt' in summary or 'ff' in summary
