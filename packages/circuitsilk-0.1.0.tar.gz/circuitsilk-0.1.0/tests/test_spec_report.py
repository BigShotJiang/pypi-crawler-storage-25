"""Tests for SpecReport and ModuleTestbench.add_spec()."""
import pytest
from silk.circuit.spec_report import SpecReport, SpecResult


class TestSpecReportCheck:
    def setup_method(self):
        self.report = SpecReport('tb', 'ldo', {'gain_dB': 65.0, 'bw': 1e6, 'pm': 55.0})

    def test_passing_spec_greater_than(self):
        self.report.check('Gain > 60 dB', 'gain_dB', '>', 60.0)
        assert self.report.results[-1].passed

    def test_failing_spec_greater_than(self):
        self.report.check('Gain > 70 dB', 'gain_dB', '>', 70.0)
        assert not self.report.results[-1].passed

    def test_passing_spec_less_than(self):
        self.report.check('BW < 2 MHz', 'bw', '<', 2e6)
        assert self.report.results[-1].passed

    def test_failing_spec_less_than(self):
        self.report.check('BW < 500 kHz', 'bw', '<', 500e3)
        assert not self.report.results[-1].passed

    def test_passing_spec_gte(self):
        self.report.check('PM >= 45', 'pm', '>=', 45.0)
        assert self.report.results[-1].passed

    def test_passing_spec_eq(self):
        self.report.check('Exact', 'gain_dB', '==', 65.0)
        assert self.report.results[-1].passed

    def test_missing_metric_fails(self):
        self.report.check('Unknown metric', 'nonexistent', '>', 0.0)
        assert not self.report.results[-1].passed

    def test_error_string_metric_fails(self):
        report = SpecReport('t', 'm', {'gain': 'Error: sim failed'})
        report.check('Gain > 60', 'gain', '>', 60.0)
        assert not report.results[-1].passed

    def test_invalid_op_raises(self):
        with pytest.raises(ValueError, match='Unknown operator'):
            self.report.check('Bad op', 'gain_dB', '!=', 60.0)

    def test_chaining(self):
        result = (
            self.report
            .check('Gain > 60', 'gain_dB', '>', 60.0)
            .check('PM > 45', 'pm', '>', 45.0)
        )
        assert result is self.report
        assert len(self.report.results) == 2


class TestSpecReportPassed:
    def test_all_pass(self):
        report = SpecReport('t', 'm', {'gain': 65.0, 'pm': 55.0})
        report.check('G', 'gain', '>', 60.0).check('PM', 'pm', '>', 45.0)
        assert report.passed

    def test_one_fail(self):
        report = SpecReport('t', 'm', {'gain': 55.0, 'pm': 55.0})
        report.check('G', 'gain', '>', 60.0).check('PM', 'pm', '>', 45.0)
        assert not report.passed

    def test_no_specs_passes(self):
        report = SpecReport('t', 'm', {'gain': 65.0})
        assert report.passed


class TestSpecReportSummary:
    def test_summary_contains_pass(self):
        report = SpecReport('tb', 'ldo', {'gain': 65.0})
        report.check('Gain > 60', 'gain', '>', 60.0)
        s = report.summary()
        assert 'PASS' in s
        assert 'tb' in s
        assert 'ldo' in s

    def test_summary_contains_fail(self):
        report = SpecReport('tb', 'ldo', {'gain': 50.0})
        report.check('Gain > 60', 'gain', '>', 60.0)
        s = report.summary()
        assert 'FAIL' in s

    def test_summary_no_specs(self):
        report = SpecReport('tb', 'ldo', {})
        assert 'no specs' in report.summary()

    def test_repr(self):
        report = SpecReport('tb', 'ldo', {'gain': 65.0})
        report.check('G', 'gain', '>', 60.0)
        r = repr(report)
        assert 'SpecReport' in r
        assert 'passed=True' in r


class TestSpecResultDataclass:
    def test_fields(self):
        r = SpecResult('name', 'metric', '>', 60.0, 65.0, True)
        assert r.name == 'name'
        assert r.metric_name == 'metric'
        assert r.op == '>'
        assert r.target == 60.0
        assert r.value == 65.0
        assert r.passed is True


class TestModuleTestbenchAddSpec:
    def test_add_spec_returns_self(self, tmp_path):
        """add_spec() is chainable."""
        from silk.circuit.modules import Module
        from silk.circuit.module_test import ModuleTestbench

        pdk_yaml = '/home/lazarus/python-dev/silk/silk/pdk/data/skywater_130_device_details.yaml'
        try:
            from silk.pdk.skywater130 import PDK_skywater130
            pdk = PDK_skywater130(pdk_yaml, libraryLocation='/dev/null')
        except Exception:
            pytest.skip('PDK not available')

        mod = Module('PDK_skywater130', str(tmp_path), 'test.cir', pdkDetails=pdk)
        mod.defineModuleName('inv')
        mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})

        tb = ModuleTestbench(mod, 'test')
        result = tb.add_metric('gain', lambda ckt: 65.0)
        assert result is tb
        result2 = tb.add_spec('Gain > 60', 'gain', '>', 60.0)
        assert result2 is tb
        assert len(tb._specs) == 1

    def test_specs_stored(self, tmp_path):
        from silk.circuit.modules import Module
        from silk.circuit.module_test import ModuleTestbench

        pdk_yaml = '/home/lazarus/python-dev/silk/silk/pdk/data/skywater_130_device_details.yaml'
        try:
            from silk.pdk.skywater130 import PDK_skywater130
            pdk = PDK_skywater130(pdk_yaml, libraryLocation='/dev/null')
        except Exception:
            pytest.skip('PDK not available')

        mod = Module('PDK_skywater130', str(tmp_path), 'test.cir', pdkDetails=pdk)
        mod.defineModuleName('inv')
        mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})

        tb = ModuleTestbench(mod)
        tb.add_spec('Gain > 60', 'gain_dB', '>', 60.0)
        tb.add_spec('PM >= 45', 'pm', '>=', 45.0)
        assert len(tb._specs) == 2
        assert tb._specs[0]['op'] == '>'
        assert tb._specs[1]['target'] == 45.0


class TestImportPaths:
    def test_spec_report_importable_from_silk_circuit(self):
        from silk.circuit import SpecReport, SpecResult
        assert SpecReport is not None
        assert SpecResult is not None

    def test_spec_report_importable_directly(self):
        from silk.circuit.spec_report import SpecReport
        assert SpecReport is not None
