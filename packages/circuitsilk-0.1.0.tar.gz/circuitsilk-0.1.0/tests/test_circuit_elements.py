"""
Tests for PyCircuitElements — the shared mixin managing elem_dict, net_dict, and module_dict.

Covers addElement(), addNet(), connectElement(), updateElement(), deep copy isolation,
and error paths (duplicate names, invalid pins, nonexistent elements).
"""

import pytest
import copy

from silk.exceptions import PyNetlistError


# ---------------------------------------------------------------------------
# addElement basics
# ---------------------------------------------------------------------------

class TestAddElement:

    def test_add_device_element_populates_elem_dict(self, pdk, empty_netlist):
        """Adding a device element stores it in elem_dict with correct type."""
        ckt = empty_netlist
        ckt.addElement(
            pdk.nmos1p8, 'mn1',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15},
        )
        assert 'mn1' in ckt.elem_dict
        assert ckt.elem_dict['mn1']['type'] == 'd'

    def test_add_device_element_stores_device_name(self, pdk, empty_netlist):
        """The stored element records the device type name from the PDK."""
        ckt = empty_netlist
        ckt.addElement(pdk.pmos1p8, 'mp1',
                       nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                       parameters={'w': 2, 'l': 0.15})
        assert ckt.elem_dict['mp1']['typeName'] == pdk.pmos1p8.device_name

    def test_add_multiple_elements(self, basic_netlist):
        """basic_netlist fixture adds two elements; both should be present."""
        assert 'mn1' in basic_netlist.elem_dict
        assert 'mp1' in basic_netlist.elem_dict
        assert len(basic_netlist.elem_dict) == 2

    def test_duplicate_element_name_exits(self, pdk, empty_netlist):
        """Adding an element with a duplicate name raises PyNetlistError."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15})
        with pytest.raises(PyNetlistError):
            ckt.addElement(pdk.nmos1p8, 'mn1',
                           nets={'d': 'out2', 'g': 'in2', 's': 'gnd', 'b': 'gnd'},
                           parameters={'w': 1, 'l': 0.15})

    def test_unknown_device_type_exits(self, pdk, empty_netlist):
        """Adding an element with an unrecognized device type raises PyNetlistError."""
        class FakeDevice:
            device_name = 'nonexistent_device_xyz'
        with pytest.raises(PyNetlistError):
            empty_netlist.addElement(FakeDevice(), 'bad1',
                                     nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'})

    def test_add_module_element(self, pdk, empty_netlist, basic_module):
        """Adding a module element stores it with type 'm' and populates module_dict."""
        ckt = empty_netlist
        ckt.addElement(
            basic_module, 'xinv1',
            nets={'in': 'sig_in', 'out': 'sig_out', 'vdd': 'vdd', 'gnd': 'gnd'},
        )
        assert 'xinv1' in ckt.elem_dict
        assert ckt.elem_dict['xinv1']['type'] == 'm'
        assert basic_module.module_name in ckt.module_dict

    def test_add_module_increments_instantiation_count(self, pdk, empty_netlist, basic_module):
        """Instantiating the same module twice increments numberInstantiated."""
        ckt = empty_netlist
        ckt.addElement(basic_module, 'xinv1',
                       nets={'in': 'a', 'out': 'b', 'vdd': 'vdd', 'gnd': 'gnd'})
        ckt.addElement(basic_module, 'xinv2',
                       nets={'in': 'c', 'out': 'd', 'vdd': 'vdd', 'gnd': 'gnd'})
        assert ckt.module_dict[basic_module.module_name]['numberInstantiated'] == 2


# ---------------------------------------------------------------------------
# addNet
# ---------------------------------------------------------------------------

class TestAddNet:

    def test_add_net_creates_entry(self, empty_netlist):
        """addNet creates a new key in net_dict."""
        empty_netlist.addNet('vdd')
        assert 'vdd' in empty_netlist.net_dict

    def test_add_duplicate_net_is_noop(self, empty_netlist):
        """Adding the same net twice does not raise and keeps original entry."""
        empty_netlist.addNet('vdd', [1.8])
        empty_netlist.addNet('vdd', [3.3])
        # Original parameters should be preserved
        assert empty_netlist.net_dict['vdd'] == [1.8]

    def test_net_dict_populated_by_basic_netlist(self, basic_netlist):
        """basic_netlist fixture explicitly adds vdd, gnd, in, out nets."""
        for net in ['vdd', 'gnd', 'in', 'out']:
            assert net in basic_netlist.net_dict


# ---------------------------------------------------------------------------
# Auto-creation of nets (lazy net creation)
# ---------------------------------------------------------------------------

class TestLazyNetCreation:

    def test_connecting_element_auto_creates_nets(self, pdk, empty_netlist):
        """When addElement is called with nets that don't exist yet, they are auto-created."""
        ckt = empty_netlist
        # Don't call addNet first — nets should be auto-created
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'auto_out', 'g': 'auto_in', 's': 'auto_gnd', 'b': 'auto_gnd'})
        assert 'auto_out' in ckt.net_dict
        assert 'auto_in' in ckt.net_dict
        assert 'auto_gnd' in ckt.net_dict


# ---------------------------------------------------------------------------
# connectElement
# ---------------------------------------------------------------------------

class TestConnectElement:

    def test_connect_element_updates_pin_net(self, pdk, empty_netlist):
        """connectElement updates the pin's net attribute on the stored device."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'})
        # Re-connect drain to a different net
        ckt.connectElement('mn1', ['d'], ['new_out'])
        pin_list = ckt.elem_dict['mn1']['device'].pin_list
        assert pin_list['d'].net == 'new_out'

    def test_connect_nonexistent_element_exits(self, empty_netlist):
        """Connecting to a nonexistent element raises PyNetlistError."""
        with pytest.raises(PyNetlistError):
            empty_netlist.connectElement('does_not_exist', ['d'], ['out'])

    def test_connect_wrong_pin_name_exits(self, pdk, empty_netlist):
        """Connecting to a nonexistent pin name raises PyNetlistError."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'})
        with pytest.raises(PyNetlistError):
            ckt.connectElement('mn1', ['nonexistent_pin'], ['some_net'])


# ---------------------------------------------------------------------------
# updateElement
# ---------------------------------------------------------------------------

class TestUpdateElement:

    def test_update_element_changes_parameter(self, pdk, empty_netlist):
        """updateElement modifies parameter values on the stored device."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15})
        ckt.updateElement('mn1', ['w'], [5])
        param_list = ckt.elem_dict['mn1']['device'].param_list
        assert param_list['w'].value.value == 5

    def test_update_nonexistent_element_exits(self, empty_netlist):
        """Updating a nonexistent element raises PyNetlistError."""
        with pytest.raises(PyNetlistError):
            empty_netlist.updateElement('ghost', ['w'], [1])


# ---------------------------------------------------------------------------
# Deep copy isolation
# ---------------------------------------------------------------------------

class TestDeepCopyIsolation:

    def test_elements_are_deep_copied(self, pdk, empty_netlist):
        """Modifying the original PDK device after addElement doesn't affect the stored copy."""
        ckt = empty_netlist
        original_device = pdk.nmos1p8
        ckt.addElement(original_device, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15})
        # The stored device should be a separate copy
        stored_device = ckt.elem_dict['mn1']['device']
        assert stored_device is not original_device

    def test_two_instances_independent(self, pdk, empty_netlist):
        """Two instances of the same device type have independent parameters."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out1', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15})
        ckt.addElement(pdk.nmos1p8, 'mn2',
                       nets={'d': 'out2', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 10, 'l': 0.3})
        w1 = ckt.elem_dict['mn1']['device'].param_list['w'].value.value
        w2 = ckt.elem_dict['mn2']['device'].param_list['w'].value.value
        assert w1 != w2
        assert w1 == 1
        assert w2 == 10


# ---------------------------------------------------------------------------
# elem_dict / net_dict contents after operations
# ---------------------------------------------------------------------------

class TestDictContents:

    def test_elem_dict_keys_match_added_elements(self, basic_netlist):
        """elem_dict keys exactly match the set of added element names."""
        assert set(basic_netlist.elem_dict.keys()) == {'mn1', 'mp1'}

    def test_net_dict_contains_all_connected_nets(self, basic_netlist):
        """net_dict contains all nets that were explicitly added or auto-created."""
        expected = {'vdd', 'gnd', 'in', 'out'}
        assert expected.issubset(set(basic_netlist.net_dict.keys()))

    def test_element_has_device_key(self, basic_netlist):
        """Each element entry has a 'device' key with the device object."""
        for name, elem in basic_netlist.elem_dict.items():
            assert 'device' in elem
            assert 'type' in elem
            assert 'typeName' in elem


# ---------------------------------------------------------------------------
# Debug mode
# ---------------------------------------------------------------------------

class TestDebugMode:

    def test_add_element_debug_prints(self, pdk, tmp_dir, capsys):
        """addElement with debug=True prints debug messages (old-style PDKDevice path)."""
        import silk.circuit.netlist as pn
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'dbg.cir',
                           pdkDetails=pdk, debug=True)
        # Use PDKDevice directly (old-style) to exercise the debug print branch
        ckt.addElement(pdk._devices['nmos1p8'], 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15, 'm': 1})
        captured = capsys.readouterr()
        assert 'Element Name found in pdk' in captured.out

    def test_add_module_debug_prints(self, pdk, tmp_dir, basic_module, capsys):
        """Adding a module element with debug=True prints module debug messages."""
        import silk.circuit.netlist as pn
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'dbg.cir',
                           pdkDetails=pdk, debug=True)
        ckt.addElement(basic_module, 'xinv',
                       nets={'in': 'a', 'out': 'b', 'vdd': 'vdd', 'gnd': 'gnd'})
        captured = capsys.readouterr()
        assert 'Element Name found in custom module list' in captured.out

    def test_add_net_debug_duplicate(self, pdk, tmp_dir, capsys):
        """addNet with debug=True prints message for duplicate net."""
        from silk.circuit.circuit_elements import PyCircuitElements
        mgr = PyCircuitElements(pdk, debug=True)
        mgr.addNet('vdd')
        mgr.addNet('vdd')  # duplicate
        captured = capsys.readouterr()
        assert 'already exists' in captured.out

    def test_connect_debug_auto_net_warning(self, pdk, tmp_dir, capsys):
        """connectElement with debug=True warns about auto-created nets."""
        from silk.circuit.circuit_elements import PyCircuitElements
        mgr = PyCircuitElements(pdk, debug=True)
        mgr.addElement(pdk.nmos1p8, 'mn1')
        # Connect to a net that doesn't exist yet
        mgr.connectElement('mn1', ['d'], ['auto_new_net'])
        captured = capsys.readouterr()
        assert 'undefined' in captured.out or 'addNet' in captured.out


# ---------------------------------------------------------------------------
# List-style nets and parameters
# ---------------------------------------------------------------------------

class TestListStyleArgs:

    def test_add_element_with_list_nets(self, pdk, empty_netlist):
        """addElement accepts list-of-tuples style nets."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets=[('d', 'out'), ('g', 'in'), ('s', 'gnd'), ('b', 'gnd')],
                       parameters={'w': 1, 'l': 0.15})
        pin_list = ckt.elem_dict['mn1']['device'].pin_list
        assert pin_list['d'].net == 'out'
        assert pin_list['g'].net == 'in'

    def test_add_element_with_list_params(self, pdk, empty_netlist):
        """addElement accepts list-of-tuples style parameters."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters=[('w', 2), ('l', 0.3)])
        param_list = ckt.elem_dict['mn1']['device'].param_list
        assert param_list['w'].value.value == 2
        assert param_list['l'].value.value == 0.3


# ---------------------------------------------------------------------------
# Primitive element type
# ---------------------------------------------------------------------------

class TestPrimitiveElement:

    def test_add_primitive_element_hits_primitive_branch(self, pdk, tmp_dir, capsys):
        """Adding a primitive element triggers the primitive branch (debug print) but
        fails because the source code doesn't set original_device for primitives."""
        from silk.circuit.circuit_elements import PyCircuitElements
        mgr = PyCircuitElements(pdk, debug=True)
        mgr.primitiveNames.append('resistor')

        class FakePrimitive:
            device_name = 'resistor'
            pin_list = {}
            param_list = {}

        # The primitive path is incomplete in source - it hits line 68-70 but
        # then fails at line 80 because original_device is never assigned
        with pytest.raises(UnboundLocalError):
            mgr.addElement(FakePrimitive(), 'r1')
        captured = capsys.readouterr()
        assert 'Element Name found in primitive list' in captured.out


# ---------------------------------------------------------------------------
# connectElement edge cases
# ---------------------------------------------------------------------------

class TestConnectElementEdgeCases:

    def test_connect_primitive_type_prints_incomplete(self, pdk, tmp_dir, capsys):
        """connectElement on PRIMITIVE type prints 'not complete' message."""
        from silk.circuit.circuit_elements import PyCircuitElements, ElementType
        mgr = PyCircuitElements(pdk)
        # Manually inject a fake primitive element to bypass addElement bug
        mgr.elem_dict['r1'] = {
            'type': ElementType.PRIMITIVE,
            'device': type('FakeDev', (), {'pin_list': {}, 'param_list': {}})(),
            'typeName': 'resistor',
        }
        mgr.connectElement('r1', ['a'], ['net1'])
        captured = capsys.readouterr()
        assert 'not complete' in captured.out


# ---------------------------------------------------------------------------
# updateElement edge cases
# ---------------------------------------------------------------------------

class TestUpdateElementEdgeCases:

    def test_params_length_mismatch_exits(self, pdk, empty_netlist):
        """updateElement exits when params and paramValues have different lengths."""
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15})
        with pytest.raises(PyNetlistError, match='params length'):
            ckt.updateElement('mn1', ['w', 'l'], [5])  # 2 params, 1 value

    def test_update_non_device_type_prints_incomplete(self, pdk, tmp_dir, capsys):
        """updateElement on non-DEVICE type prints 'not complete' message."""
        from silk.circuit.circuit_elements import PyCircuitElements, ElementType
        mgr = PyCircuitElements(pdk)
        # Manually inject a fake primitive element
        mgr.elem_dict['r1'] = {
            'type': ElementType.PRIMITIVE,
            'device': type('FakeDev', (), {'pin_list': {}, 'param_list': {}})(),
            'typeName': 'resistor',
        }
        mgr.updateElement('r1', ['val'], [100])
        captured = capsys.readouterr()
        assert 'not complete' in captured.out

    def test_update_element_with_module_variable(self, pdk, empty_netlist):
        """updateElement accepts a ModuleVariable directly as paramValue."""
        from silk.circuit.modules import ModuleVariable
        ckt = empty_netlist
        ckt.addElement(pdk.nmos1p8, 'mn1',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15})
        mv = ModuleVariable('w', value=7.5)
        ckt.updateElement('mn1', ['w'], [mv])
        param_list = ckt.elem_dict['mn1']['device'].param_list
        assert param_list['w'].value is mv


# ---------------------------------------------------------------------------
# New-style class addElement — class not in PDK raises error (line 60)
# ---------------------------------------------------------------------------

class TestNewStyleClassDeviceNotInPDK:

    def test_new_style_class_not_in_pdk_raises(self, pdk, empty_netlist):
        """addElement with a new-style class whose type is not in PDK raises PyNetlistError (line 60)."""
        from silk.elements.factory import make_device_class
        from silk.elements.base import AnalogElement

        spec = {
            'PDKDevice': 'nonexistent_pdk_device',
            'pinList': ['a', 'b'],
            'paramList': {},
        }
        FakeCls = make_device_class('totally_fake_device', spec, is_pdk=True)
        # FakeCls is a class (subclass of AnalogElement) whose type is not in PDK
        with pytest.raises(PyNetlistError):
            empty_netlist.addElement(FakeCls, 'fake1',
                                     nets={'a': 'na', 'b': 'nb'})


# ---------------------------------------------------------------------------
# New-style AnalogElement instance path (lines 82-83)
# ---------------------------------------------------------------------------

class TestNewStyleInstancePath:

    def test_add_analog_element_instance_directly(self, pdk, empty_netlist):
        """addElement with an AnalogElement instance goes through _add_analog_element (lines 82-83)."""
        from silk.elements.factory import make_device_class

        spec = {
            'PDKDevice': 'sky130_fd_pr__nfet_01v8',
            'pinList': {'d': 'drain', 'g': 'gate', 's': 'source', 'b': 'bulk'},
            'paramList': {
                'w': {'minval': 1.0, 'maxval': 10.0, 'unit': 'u'},
                'l': {'minval': 0.15, 'maxval': 1.0, 'unit': 'u'},
            },
        }
        NMOSCls = make_device_class('nmos1p8', spec, is_pdk=True)
        instance = NMOSCls('mn_inst', d='vout', g='vin', s='gnd', b='gnd', w=2.0, l=0.15)

        # Pass an instance (not the class) — should call _add_analog_element
        empty_netlist.addElement(instance, 'mn_inst')
        assert 'mn_inst' in empty_netlist.elem_dict
        assert empty_netlist.elem_dict['mn_inst']['_new_style'] is True


# ---------------------------------------------------------------------------
# Positional list parameters in _apply_parameters (lines 341-342)
# ---------------------------------------------------------------------------

class TestPositionalListParameters:

    def test_positional_list_parameters(self, pdk, empty_netlist):
        """addElement with a plain positional list for parameters applies them in order (lines 341-342)."""
        ckt = empty_netlist
        # pin_list order for nmos1p8 is d, g, s, b
        # param_list order is w, l (and m if present)
        # Use positional list: values in param_list key order
        # First let's figure out param order
        device_copy = pdk._devices.get('nmos1p8')
        import copy
        dev_copy = copy.deepcopy(device_copy)
        param_order = list(dev_copy.param_list.keys())

        # Build positional values matching order
        param_vals = []
        defaults = {'w': 3.0, 'l': 0.15, 'm': 1}
        for p in param_order:
            param_vals.append(defaults.get(p, 1))

        ckt.addElement(
            pdk.nmos1p8, 'mn_pos',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters=param_vals,  # positional list, not dict or tuples
        )
        assert 'mn_pos' in ckt.elem_dict


# ---------------------------------------------------------------------------
# updateElement on MODULE type → "not complete" (lines 265-267)
# ---------------------------------------------------------------------------

class TestUpdateElementNewStyle:

    def test_update_new_style_element_params(self, pdk, empty_netlist):
        """updateElement on a _new_style AnalogElement updates params dict directly (lines 265-267)."""
        from silk.elements.factory import make_device_class

        spec = {
            'PDKDevice': 'sky130_fd_pr__nfet_01v8',
            'pinList': {'d': 'drain', 'g': 'gate', 's': 'source', 'b': 'bulk'},
            'paramList': {
                'w': {'minval': 1.0, 'maxval': 10.0, 'unit': 'u'},
                'l': {'minval': 0.15, 'maxval': 1.0, 'unit': 'u'},
            },
        }
        NMOSCls = make_device_class('nmos1p8', spec, is_pdk=True)
        mn1 = NMOSCls('mn_ns', d='out', g='in', s='gnd', b='gnd', w=1.0, l=0.15)

        # Add via addElement(instance) to mark as _new_style
        empty_netlist.addElement(mn1, 'mn_ns')
        assert empty_netlist.elem_dict['mn_ns']['_new_style'] is True

        # Now update via updateElement — should go through _new_style branch
        empty_netlist.updateElement('mn_ns', ['w'], [5.0])
        assert empty_netlist.elem_dict['mn_ns']['device'].params['w'] == 5.0


class TestFallbackGetAttr:

    def test_getattr_fallback_when_device_not_in_devices_dict(self, pdk, empty_netlist):
        """addElement uses getattr(pdk, elemType) fallback when _devices.get() returns None (line 122).

        We patch the _devices dict to return None for a specific device, forcing the fallback
        to use getattr(pdkDetails, elemType).
        """
        from silk.circuit.circuit_elements import PyCircuitElements

        # Get the real old-style PDKDevice for nmos1p8
        real_old_device = pdk._devices['nmos1p8']
        # Set up a custom PDK-like object where _devices.get() returns None
        # but getattr() still works
        import copy

        class FakePDK:
            """Minimal PDK-like that has nmos1p8 as attr but _devices returns None for it."""
            modelNames = ['nmos1p8']
            moduleNames = ['module']
            primitiveNames = []
            _devices = {}  # empty — so .get() returns None

        fake_pdk = FakePDK()
        # Set the attribute directly so getattr(fake_pdk, 'nmos1p8') works
        setattr(fake_pdk, 'nmos1p8', copy.deepcopy(real_old_device))

        mgr = PyCircuitElements(fake_pdk)
        mgr.addElement(
            real_old_device,  # old-style PDKDevice
            'mn_fallback',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 1, 'l': 0.15, 'm': 1},
        )
        assert 'mn_fallback' in mgr.elem_dict


class TestUpdateElementModuleType:

    def test_update_module_type_prints_not_complete(self, pdk, tmp_dir, capsys, basic_module):
        """updateElement on MODULE-typed element prints 'not complete' (lines 265-267)."""
        from silk.circuit.circuit_elements import PyCircuitElements, ElementType
        import copy

        mgr = PyCircuitElements(pdk)
        mgr.elem_dict['xinv'] = {
            'type': ElementType.MODULE,
            'device': basic_module,
            'typeName': 'module',
        }
        mgr.updateElement('xinv', ['some_param'], [42])
        captured = capsys.readouterr()
        assert 'not complete' in captured.out
