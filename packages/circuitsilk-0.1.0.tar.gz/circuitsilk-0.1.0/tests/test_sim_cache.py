"""Tests for ModuleTestbench simulation result caching."""
import pytest
from unittest.mock import patch
from silk.circuit.spec_report import SpecReport


def _make_report(corner):
    r = SpecReport(test_name=str(corner), module_name='inv', metrics={'gain': 65.0})
    r.check('Gain > 60', 'gain', '>', 60.0)
    return r


def _make_tb(tmp_path, name='test', cache=False):
    """Return a ModuleTestbench with guards bypassed (no real simulation needed)."""
    from silk.circuit.modules import Module
    from silk.circuit.module_test import ModuleTestbench
    from unittest.mock import MagicMock
    pdk_yaml = '/home/lazarus/python-dev/silk/silk/pdk/data/skywater_130_device_details.yaml'
    try:
        from silk.pdk.skywater130 import PDK_skywater130
        pdk = PDK_skywater130(pdk_yaml, libraryLocation='/dev/null')
    except Exception:
        pytest.skip('PDK not available')
    mod = Module('PDK_skywater130', str(tmp_path), 'test.cir', pdkDetails=pdk)
    mod.defineModuleName('inv')
    mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})
    tb = ModuleTestbench(mod, name, cache=cache)
    # Bypass run() guards — tests that call run() patch _simulate anyway
    tb._module_added = True
    tb.netlist = MagicMock()
    return tb


class TestSimCacheConstruction:
    def test_cache_disabled_by_default(self, tmp_path):
        tb = _make_tb(tmp_path)
        assert tb._cache_enabled is False
        assert tb._cache == {}

    def test_cache_enabled_constructor(self, tmp_path):
        tb = _make_tb(tmp_path, cache=True)
        assert tb._cache_enabled is True

    def test_cache_starts_empty(self, tmp_path):
        tb = _make_tb(tmp_path, cache=True)
        assert len(tb._cache) == 0


class TestSimCacheHitMiss:
    def test_cache_hit_skips_simulation(self, tmp_path):
        """Second run() with same corner skips simulation, returns cached report."""
        tb = _make_tb(tmp_path, cache=True)
        with patch.object(tb, '_simulate', side_effect=_make_report) as mock_sim:
            r1 = tb.run(corner='tt')
            r2 = tb.run(corner='tt')
            assert mock_sim.call_count == 1
        assert r1 is r2

    def test_cache_miss_different_corners(self, tmp_path):
        """Different corners produce separate cache entries."""
        tb = _make_tb(tmp_path, cache=True)
        with patch.object(tb, '_simulate', side_effect=_make_report) as mock_sim:
            tb.run(corner='tt')
            tb.run(corner='ff')
            assert mock_sim.call_count == 2

    def test_no_cache_always_simulates(self, tmp_path):
        """Without cache, run() always calls _simulate."""
        tb = _make_tb(tmp_path, cache=False)
        with patch.object(tb, '_simulate', side_effect=_make_report) as mock_sim:
            tb.run(corner='tt')
            tb.run(corner='tt')
            assert mock_sim.call_count == 2

    def test_cache_stores_report(self, tmp_path):
        """After run(), the cache has one entry."""
        tb = _make_tb(tmp_path, cache=True)
        with patch.object(tb, '_simulate', side_effect=_make_report):
            tb.run(corner='tt')
        assert len(tb._cache) == 1


class TestSimCacheClear:
    def test_clear_cache_empties_dict(self, tmp_path):
        tb = _make_tb(tmp_path, cache=True)
        with patch.object(tb, '_simulate', side_effect=_make_report):
            tb.run(corner='tt')
        assert len(tb._cache) > 0
        tb.clear_cache()
        assert tb._cache == {}

    def test_after_clear_simulates_again(self, tmp_path):
        """After clear_cache(), next run() simulates again."""
        tb = _make_tb(tmp_path, cache=True)
        with patch.object(tb, '_simulate', side_effect=_make_report) as mock_sim:
            tb.run(corner='tt')
            tb.clear_cache()
            tb.run(corner='tt')
            assert mock_sim.call_count == 2


class TestSimCacheCornerObject:
    def test_corner_object_hits_cache(self, tmp_path):
        """Corner enum and matching string share the same cache entry."""
        from silk.simulation.corner import Corner
        tb = _make_tb(tmp_path, cache=True)
        with patch.object(tb, '_simulate', side_effect=_make_report) as mock_sim:
            tb.run(corner=Corner.TT)
            tb.run(corner='tt')   # should hit cache
            assert mock_sim.call_count == 1


class TestSimCacheFingerprint:
    def test_fingerprint_is_string(self, tmp_path):
        tb = _make_tb(tmp_path)
        fp = tb._fingerprint()
        assert isinstance(fp, str)
        assert len(fp) > 0

    def test_fingerprint_same_state(self, tmp_path):
        """Same module state → same fingerprint."""
        tb = _make_tb(tmp_path)
        assert tb._fingerprint() == tb._fingerprint()

    def test_fingerprint_changes_with_spec(self, tmp_path):
        """Adding a spec changes the fingerprint."""
        tb = _make_tb(tmp_path)
        fp1 = tb._fingerprint()
        tb.add_spec('Gain > 60', 'gain', '>', 60.0)
        fp2 = tb._fingerprint()
        assert fp1 != fp2
