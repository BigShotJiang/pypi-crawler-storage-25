"""
Tests for PyModules.PyModule — subcircuit definition, element management,
netlist generation, and hierarchical composition.
"""

import os
import sys
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from silk.circuit.modules import PyModule, ModulePin, ModuleVariable
from silk import sources
from silk.exceptions import PyNetlistError


# ---------------------------------------------------------------------------
# Fixture with all params (w, l, m) set — needed for netlist generation
# ---------------------------------------------------------------------------

@pytest.fixture
def full_param_module(pdk, tmp_dir):
    """Module with all device parameters set including 'm'."""
    mod = PyModule('PDK_skywater130', tmp_dir, 'mod_full.cir', pdkDetails=pdk)
    mod.defineModuleName('inv_cell')
    mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})

    mod.addElement(pdk.nmos1p8, 'mn',
                   nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                   parameters={'w': 1, 'l': 0.15, 'm': 1})
    mod.addElement(pdk.pmos1p8, 'mp',
                   nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                   parameters={'w': 2, 'l': 0.15, 'm': 1})
    return mod


# ---------------------------------------------------------------------------
# Constructor tests
# ---------------------------------------------------------------------------

class TestPyModuleConstructor:

    def test_instance_attributes(self, pdk, tmp_dir):
        """Constructor sets device_name, dirFolder, and empty dicts."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)

        assert mod.device_name == 'module'
        assert mod.dirFolder == tmp_dir
        assert mod.module_name is None
        assert mod.pin_list is None
        assert isinstance(mod.elem_dict, dict)
        assert len(mod.elem_dict) == 0

    def test_pdk_stored(self, pdk, tmp_dir):
        """PDK details are stored on the instance."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        assert mod.pdkDetails is pdk


# ---------------------------------------------------------------------------
# defineModuleName tests
# ---------------------------------------------------------------------------

class TestDefineModuleName:

    def test_sets_module_name(self, pdk, tmp_dir):
        """defineModuleName() sets the module_name attribute."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleName('my_inv')
        assert mod.module_name == 'my_inv'

    def test_overwrite_module_name(self, pdk, tmp_dir):
        """Calling defineModuleName() again overwrites the previous name."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleName('first')
        mod.defineModuleName('second')
        assert mod.module_name == 'second'


# ---------------------------------------------------------------------------
# defineModuleNets tests
# ---------------------------------------------------------------------------

class TestDefineModuleNets:

    def test_pin_list_populated(self, pdk, tmp_dir):
        """defineModuleNets() creates pin_list with correct port names."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})

        assert mod.pin_list is not None
        assert set(mod.pin_list.keys()) == {'in', 'out', 'vdd', 'gnd'}

    def test_pins_are_modulepin_instances(self, pdk, tmp_dir):
        """Each pin in pin_list is a ModulePin dataclass."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleNets({'a': None, 'b': None})

        for pin in mod.pin_list.values():
            assert isinstance(pin, ModulePin)
            assert pin.net is None  # no net assigned yet

    def test_pin_name_matches_key(self, pdk, tmp_dir):
        """ModulePin.name matches its dictionary key."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleNets({'x': None})
        assert mod.pin_list['x'].name == 'x'


# ---------------------------------------------------------------------------
# addElement inside module tests
# ---------------------------------------------------------------------------

class TestModuleAddElement:

    def test_element_in_module_elem_dict(self, basic_module, pdk):
        """Elements added to the module appear in its elem_dict."""
        # basic_module already has 'mn' and 'mp'
        assert 'mn' in basic_module.elem_dict
        assert 'mp' in basic_module.elem_dict

    def test_element_type_is_device(self, basic_module):
        """Elements from PDK are typed as 'd' (device)."""
        assert basic_module.elem_dict['mn']['type'] == 'd'
        assert basic_module.elem_dict['mp']['type'] == 'd'

    def test_add_additional_element(self, basic_module, pdk):
        """Can add more elements after initial fixture setup."""
        basic_module.addElement(
            pdk.nmos1p8, 'mn2',
            nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
            parameters={'w': 0.5, 'l': 0.15},
        )
        assert 'mn2' in basic_module.elem_dict


# ---------------------------------------------------------------------------
# generateNetlistEntry tests
# ---------------------------------------------------------------------------

class TestGenerateNetlistEntry:

    def test_starts_with_x(self, basic_module):
        """generateNetlistEntry() output starts with 'x' (subcircuit instance prefix)."""
        # First connect the module pins to nets
        for pin_name in basic_module.pin_list:
            basic_module.pin_list[pin_name].net = pin_name

        entry = basic_module.generateNetlistEntry('inst1')
        assert entry.startswith('x')

    def test_contains_instance_name(self, basic_module):
        """Output contains the instance name."""
        for pin_name in basic_module.pin_list:
            basic_module.pin_list[pin_name].net = pin_name

        entry = basic_module.generateNetlistEntry('inst1')
        assert 'inst1' in entry

    def test_contains_module_name(self, basic_module):
        """Output contains the module name."""
        for pin_name in basic_module.pin_list:
            basic_module.pin_list[pin_name].net = pin_name

        entry = basic_module.generateNetlistEntry('inst1')
        assert basic_module.module_name in entry

    def test_contains_net_names(self, basic_module):
        """Output contains the connected net names."""
        basic_module.pin_list['in'].net = 'sig_in'
        basic_module.pin_list['out'].net = 'sig_out'
        basic_module.pin_list['vdd'].net = 'vdd'
        basic_module.pin_list['gnd'].net = 'gnd'

        entry = basic_module.generateNetlistEntry('u1')
        assert 'sig_in' in entry
        assert 'sig_out' in entry

    def test_undefined_pin_exits(self, basic_module):
        """If any pin has no net assigned, generateNetlistEntry raises PyNetlistError."""
        # Leave pins unconnected (net = None)
        basic_module.pin_list['in'].net = None
        basic_module.pin_list['out'].net = 'out'
        basic_module.pin_list['vdd'].net = 'vdd'
        basic_module.pin_list['gnd'].net = 'gnd'

        with pytest.raises(PyNetlistError):
            basic_module.generateNetlistEntry('inst_bad')


# ---------------------------------------------------------------------------
# generateNetlist(subckt=True) tests
# ---------------------------------------------------------------------------

class TestGenerateNetlistSubckt:

    def test_contains_subckt_keyword(self, full_param_module):
        """Output contains '.subckt' when subckt=True."""
        output = full_param_module.generateNetlist(subckt=True)
        assert '.subckt' in output

    def test_contains_ends_keyword(self, full_param_module):
        """Output contains '.ends' when subckt=True."""
        output = full_param_module.generateNetlist(subckt=True)
        assert '.ends' in output

    def test_contains_module_name(self, full_param_module):
        """Output contains the module name in the .subckt line."""
        output = full_param_module.generateNetlist(subckt=True)
        assert full_param_module.module_name in output

    def test_contains_pin_names(self, full_param_module):
        """Output contains the pin names in the .subckt header."""
        output = full_param_module.generateNetlist(subckt=True)
        for pin_name in full_param_module.pin_list:
            assert pin_name in output


# ---------------------------------------------------------------------------
# generateSubckt tests
# ---------------------------------------------------------------------------

class TestGenerateSubckt:

    def test_subckt_start_line(self, basic_module):
        """generateSubckt(0) produces .subckt header with module name."""
        line = basic_module.generateSubckt(0)
        assert line.startswith('.subckt')
        assert basic_module.module_name in line

    def test_subckt_end_line(self, basic_module):
        """generateSubckt(1) produces .ends line."""
        line = basic_module.generateSubckt(1)
        assert '.ends' in line


# ---------------------------------------------------------------------------
# Module used in parent PyNetlist tests
# ---------------------------------------------------------------------------

class TestModuleInParentNetlist:

    def test_module_instance_in_parent_elem_dict(self, basic_module, pdk, tmp_dir):
        """After adding a module to a PyNetlist, elem_dict contains the instance."""
        import silk.circuit.netlist as pn

        # Connect module pins
        for pin_name in basic_module.pin_list:
            basic_module.pin_list[pin_name].net = pin_name

        parent = pn.PyNetlist('PDK_skywater130', tmp_dir, 'parent.cir', pdkDetails=pdk)
        parent.addNet('in')
        parent.addNet('out')
        parent.addNet('vdd')
        parent.addNet('gnd')

        parent.addElement(
            basic_module, 'u1',
            nets={'in': 'in', 'out': 'out', 'vdd': 'vdd', 'gnd': 'gnd'},
        )

        assert 'u1' in parent.elem_dict
        assert parent.elem_dict['u1']['type'] == 'm'

    def test_module_appears_in_parent_netlist_output(self, full_param_module, pdk, tmp_dir):
        """Module subcircuit definition appears in the parent's generated netlist."""
        import silk.circuit.netlist as pn

        for pin_name in full_param_module.pin_list:
            full_param_module.pin_list[pin_name].net = pin_name

        parent = pn.PyNetlist('PDK_skywater130', tmp_dir, 'parent2.cir', pdkDetails=pdk)
        parent.addNet('in')
        parent.addNet('out')
        parent.addNet('vdd')
        parent.addNet('gnd')

        parent.addElement(
            full_param_module, 'u1',
            nets={'in': 'in', 'out': 'out', 'vdd': 'vdd', 'gnd': 'gnd'},
        )

        parent.addSource(sources.VoltageSource('vsup', positive='vdd', negative='gnd', dc=1.8))
        parent.addSimType('transient', ['1n', '100n'])
        parent.generateNetlist(corner='tt')

        content = open(parent.netlistname).read()
        assert '.subckt' in content
        assert full_param_module.module_name in content


# ---------------------------------------------------------------------------
# ModulePin dataclass tests
# ---------------------------------------------------------------------------

class TestModulePin:

    def test_default_net_is_none(self):
        """ModulePin net defaults to None."""
        pin = ModulePin(name='a')
        assert pin.name == 'a'
        assert pin.net is None

    def test_net_assignable(self):
        """ModulePin net can be assigned."""
        pin = ModulePin(name='a')
        pin.net = 'vdd'
        assert pin.net == 'vdd'


# ---------------------------------------------------------------------------
# ModuleVariable tests
# ---------------------------------------------------------------------------

from silk.circuit.modules import VarType, Distribution


class TestModuleVariable:

    def test_basic_creation(self):
        """ModuleVariable stores name and value."""
        mv = ModuleVariable('width', value=1.0)
        assert mv.name == 'width'
        assert mv.value == 1.0

    def test_repr(self):
        """ModuleVariable __repr__ contains name and value."""
        mv = ModuleVariable('length', value=0.15)
        r = repr(mv)
        assert 'length' in r
        assert '0.15' in r

    def test_value_setter_clears_sweep(self):
        """Setting value clears any sweep_values."""
        mv = ModuleVariable('w', value=1.0)
        mv.sweep_values = [1, 2, 3]
        mv.value = 5.0
        assert mv.sweep_values is None
        assert mv.value == 5.0

    def test_sweep_values_override_value(self):
        """When sweep_values is set, value property returns sweep element."""
        mv = ModuleVariable('w', value=1.0)
        mv.sweep_values = [10, 20, 30]
        mv.sweep_index = 1
        assert mv.value == 20

    # ------------------------------------------------------------------
    # Backward-compat: range kwarg still accepted
    # ------------------------------------------------------------------

    def test_range_kwarg_still_works(self):
        mv = ModuleVariable('w', value=2.0, range=0.5)
        assert mv.range == 0.5
        assert mv.value == 2.0

    # ------------------------------------------------------------------
    # New constructor fields
    # ------------------------------------------------------------------

    def test_bounds_stored(self):
        mv = ModuleVariable('w', value=1.0, bounds=(0.5, 4.0))
        assert mv.bounds == (0.5, 4.0)

    def test_var_type_integer(self):
        mv = ModuleVariable('nfin', value=4, var_type=VarType.INTEGER)
        assert mv.var_type == VarType.INTEGER

    def test_distribution_log_uniform(self):
        mv = ModuleVariable('w', value=1.0, bounds=(0.1, 10.0),
                            distribution=Distribution.LOG_UNIFORM)
        assert mv.distribution == Distribution.LOG_UNIFORM

    def test_step_stored(self):
        mv = ModuleVariable('nfin', value=4, bounds=(1, 20),
                            var_type=VarType.INTEGER, step=1)
        assert mv.step == 1

    def test_categories_stored(self):
        mv = ModuleVariable('corner', var_type=VarType.CATEGORICAL,
                            categories=['tt', 'ss', 'ff'])
        assert mv.categories == ['tt', 'ss', 'ff']

    # ------------------------------------------------------------------
    # validate()
    # ------------------------------------------------------------------

    def test_validate_within_bounds(self):
        mv = ModuleVariable('w', bounds=(0.5, 4.0))
        assert mv.validate(1.0) is True

    def test_validate_at_boundary(self):
        mv = ModuleVariable('w', bounds=(0.5, 4.0))
        assert mv.validate(0.5) is True
        assert mv.validate(4.0) is True

    def test_validate_outside_bounds(self):
        mv = ModuleVariable('w', bounds=(0.5, 4.0))
        assert mv.validate(5.0) is False

    def test_validate_no_bounds_always_true(self):
        mv = ModuleVariable('w', value=99.0)
        assert mv.validate(99.0) is True
        assert mv.validate(-1e6) is True

    def test_validate_categorical_valid(self):
        mv = ModuleVariable('corner', var_type=VarType.CATEGORICAL,
                            categories=['tt', 'ss', 'ff'])
        assert mv.validate('tt') is True

    def test_validate_categorical_invalid(self):
        mv = ModuleVariable('corner', var_type=VarType.CATEGORICAL,
                            categories=['tt', 'ss', 'ff'])
        assert mv.validate('fs') is False

    # ------------------------------------------------------------------
    # clip()
    # ------------------------------------------------------------------

    def test_clip_within_bounds_unchanged(self):
        mv = ModuleVariable('w', bounds=(0.5, 4.0))
        assert mv.clip(1.5) == 1.5

    def test_clip_below_min(self):
        mv = ModuleVariable('w', bounds=(0.5, 4.0))
        assert mv.clip(0.1) == 0.5

    def test_clip_above_max(self):
        mv = ModuleVariable('w', bounds=(0.5, 4.0))
        assert mv.clip(10.0) == 4.0

    def test_clip_integer_rounds(self):
        mv = ModuleVariable('nfin', bounds=(1, 20), var_type=VarType.INTEGER)
        assert mv.clip(3.7) == 4
        assert isinstance(mv.clip(3.7), int)

    def test_clip_no_bounds_unchanged(self):
        mv = ModuleVariable('w')
        assert mv.clip(999.0) == 999.0

    # ------------------------------------------------------------------
    # sample() — count and range
    # ------------------------------------------------------------------

    def test_sample_random_count(self):
        mv = ModuleVariable('w', bounds=(1.0, 5.0))
        s = mv.sample(10, method='random')
        assert len(s) == 10

    def test_sample_random_in_bounds(self):
        mv = ModuleVariable('w', bounds=(1.0, 5.0))
        s = mv.sample(50, method='random')
        assert all(1.0 <= v <= 5.0 for v in s)

    def test_sample_grid_endpoints(self):
        mv = ModuleVariable('w', bounds=(1.0, 5.0))
        s = mv.sample(5, method='grid')
        assert s[0] == pytest.approx(1.0)
        assert s[-1] == pytest.approx(5.0)
        assert len(s) == 5

    def test_sample_log_grid_positive(self):
        mv = ModuleVariable('w', bounds=(1e-9, 1e-6), distribution=Distribution.LOG_UNIFORM)
        s = mv.sample(4, method='log_grid')
        assert len(s) == 4
        assert all(9.9e-10 <= v <= 1.01e-6 for v in s)

    def test_sample_lhs_count_and_range(self):
        mv = ModuleVariable('w', bounds=(0.0, 10.0))
        s = mv.sample(8, method='lhs')
        assert len(s) == 8
        assert all(0.0 <= v <= 10.0 for v in s)

    def test_sample_sobol_count_and_range(self):
        mv = ModuleVariable('w', bounds=(0.0, 1.0))
        s = mv.sample(8, method='sobol')
        assert len(s) == 8
        assert all(0.0 <= v <= 1.0 for v in s)

    def test_sample_integer_returns_ints(self):
        mv = ModuleVariable('nfin', bounds=(1, 20), var_type=VarType.INTEGER)
        s = mv.sample(10, method='random')
        assert all(isinstance(v, int) for v in s)
        assert all(1 <= v <= 20 for v in s)

    def test_sample_categorical(self):
        mv = ModuleVariable('corner', var_type=VarType.CATEGORICAL,
                            categories=['tt', 'ss', 'ff'])
        s = mv.sample(6)
        assert len(s) == 6
        assert all(v in ['tt', 'ss', 'ff'] for v in s)

    def test_sample_no_bounds_raises(self):
        mv = ModuleVariable('w', value=1.0)
        with pytest.raises(ValueError, match='bounds'):
            mv.sample(5)

    def test_sample_categorical_no_categories_raises(self):
        mv = ModuleVariable('x', var_type=VarType.CATEGORICAL)
        with pytest.raises(ValueError, match='categories'):
            mv.sample(3)

    def test_sample_lhs_stratified(self):
        """LHS should cover all strata — at least one point per stratum."""
        mv = ModuleVariable('w', bounds=(0.0, 1.0))
        n = 10
        s = sorted(mv.sample(n, method='lhs'))
        for i in range(n):
            lo, hi = i / n, (i + 1) / n
            assert any(lo <= v < hi + 1e-12 for v in s), f"stratum [{lo},{hi}] not covered"

    def test_sample_grid_with_step(self):
        mv = ModuleVariable('nfin', bounds=(1, 5), var_type=VarType.INTEGER, step=1)
        s = mv.sample(100, method='grid')
        assert set(s) == {1, 2, 3, 4, 5}

    def test_sample_log_uniform_random(self):
        """Log-uniform random samples should cluster more at small values."""
        mv = ModuleVariable('w', bounds=(1e-3, 1.0),
                            distribution=Distribution.LOG_UNIFORM)
        s = mv.sample(200, method='random')
        assert all(1e-3 <= v <= 1.0 for v in s)


# ---------------------------------------------------------------------------
# Test management on PyModule
# ---------------------------------------------------------------------------

class TestModuleTestManagement:

    def test_has_tests_initially_false(self, basic_module):
        """Module has no tests initially."""
        assert basic_module.has_tests() is False

    def test_list_tests_initially_empty(self, basic_module):
        """list_tests() returns empty list initially."""
        assert basic_module.list_tests() == []

    def test_create_test_returns_test(self, basic_module):
        """create_test() returns a PyModuleTest instance."""
        from silk.circuit.module_test import PyModuleTest
        test = basic_module.create_test('my_test')
        assert isinstance(test, PyModuleTest)

    def test_has_tests_after_create(self, basic_module):
        """has_tests() returns True after create_test()."""
        basic_module.create_test('t1')
        assert basic_module.has_tests() is True

    def test_list_tests_after_create(self, basic_module):
        """list_tests() includes created test name."""
        basic_module.create_test('tran_test')
        assert 'tran_test' in basic_module.list_tests()

    def test_run_test_nonexistent_raises(self, basic_module):
        """run_test() raises ValueError for unknown test name."""
        with pytest.raises(ValueError, match="No test 'missing'"):
            basic_module.run_test('missing')

    def test_run_test_calls_test_run(self, basic_module, monkeypatch):
        """run_test() delegates to the test's run() method."""
        test_obj = basic_module.create_test('my_test')
        called = {}
        monkeypatch.setattr(test_obj, 'run', lambda **kw: called.update(kw) or {'status': 'ok'})
        result = basic_module.run_test('my_test', corner='ff')
        assert result == {'status': 'ok'}
        assert called.get('corner') == 'ff'

    def test_run_all_tests_captures_exception(self, basic_module, monkeypatch):
        """run_all_tests() catches exceptions and records error."""
        basic_module.defineModuleName('test_mod')
        test_obj = basic_module.create_test('fail_test')
        monkeypatch.setattr(test_obj, 'run', lambda **kw: (_ for _ in ()).throw(RuntimeError('boom')))
        results = basic_module.run_all_tests(recursive=False)
        key = 'test_mod.fail_test'
        assert key in results
        assert 'error' in results[key]
        assert 'boom' in results[key]['error']

    def test_run_all_tests_recursive_with_submodule(self, pdk, tmp_dir, monkeypatch):
        """run_all_tests(recursive=True) includes submodule tests."""
        from silk.circuit.modules import PyModule

        # Create a submodule with a test
        sub = PyModule('PDK_skywater130', tmp_dir, 'sub.cir', pdkDetails=pdk)
        sub.defineModuleName('sub_mod')
        sub.defineModuleNets({'a': None, 'b': None})
        test_obj = sub.create_test('sub_test')
        monkeypatch.setattr(test_obj, 'run', lambda **kw: {'passed': True})

        # Create parent and add submodule as an element
        parent = PyModule('PDK_skywater130', tmp_dir, 'parent.cir', pdkDetails=pdk)
        parent.defineModuleName('parent_mod')
        parent.defineModuleNets({'a': None, 'b': None})
        parent.addElement(sub, 'xsub', nets={'a': 'net_a', 'b': 'net_b'})

        results = parent.run_all_tests(recursive=True)
        assert 'sub_mod.sub_test' in results
        assert results['sub_mod.sub_test']['passed'] is True

    def test_get_all_testable_modules_with_submodule(self, pdk, tmp_dir):
        """get_all_testable_modules() finds testable submodules."""
        from silk.circuit.modules import PyModule

        sub = PyModule('PDK_skywater130', tmp_dir, 'sub.cir', pdkDetails=pdk)
        sub.defineModuleName('sub_mod')
        sub.defineModuleNets({'a': None, 'b': None})
        sub.create_test('sub_test')

        parent = PyModule('PDK_skywater130', tmp_dir, 'parent.cir', pdkDetails=pdk)
        parent.defineModuleName('parent_mod')
        parent.defineModuleNets({'a': None, 'b': None})
        parent.addElement(sub, 'xsub', nets={'a': 'net_a', 'b': 'net_b'})

        testable = parent.get_all_testable_modules(include_self=True)
        module_names = [t['module'] for t in testable]
        assert 'sub_mod' in module_names


# ---------------------------------------------------------------------------
# PyModuleTest API — addPassive() and addSimType() typed form
# ---------------------------------------------------------------------------

class TestPyModuleTestAPI:

    def _make_test(self, basic_module):
        """Create a bare PyModuleTest without adding a module under test."""
        from silk.circuit.module_test import PyModuleTest
        t = PyModuleTest(basic_module, 'api_test')
        t._create_netlist()
        return t

    def test_addPassive_stores_in_netlist(self, basic_module):
        """addPassive() delegates to the underlying netlist's passives_dict."""
        from silk.elements import passives
        t = self._make_test(basic_module)
        cap = passives.Capacitor('cload', pos='vout', neg='0', capacitance=100e-12)
        t.addPassive(cap)
        assert 'cload' in t.netlist.passives_dict

    def test_addPassive_returns_self(self, basic_module):
        """addPassive() returns self for chaining."""
        from silk.elements import passives
        t = self._make_test(basic_module)
        result = t.addPassive(passives.Resistor('rbias', pos='a', neg='b', resistance=1e3))
        assert result is t

    def test_addPassive_invalid_type_raises(self, basic_module):
        """addPassive() with a non-passive raises PyNetlistError."""
        t = self._make_test(basic_module)
        with pytest.raises(PyNetlistError):
            t.addPassive('not_a_passive')

    def test_addSimType_typed_transient(self, basic_module):
        """addSimType() accepts a Transient object."""
        from silk.simulation import analysis
        t = self._make_test(basic_module)
        t.addSimType(analysis.Transient(step=10e-9, stop=50e-6))
        assert 'transient' in t.netlist.simAnalysis_dict

    def test_addSimType_typed_ac(self, basic_module):
        """addSimType() accepts an AC object."""
        from silk.simulation import analysis
        t = self._make_test(basic_module)
        t.addSimType(analysis.AC(variation='dec', points=10, fstart=1, fstop=1e9))
        assert 'ac' in t.netlist.simAnalysis_dict

    def test_addSimType_legacy_string_still_works(self, basic_module):
        """addSimType() still accepts the legacy (string, list) form."""
        t = self._make_test(basic_module)
        t.addSimType('transient', [10e-9, 50e-6])
        assert 'transient' in t.netlist.simAnalysis_dict

    def test_addSimType_returns_self(self, basic_module):
        """addSimType() returns self for chaining."""
        from silk.simulation import analysis
        t = self._make_test(basic_module)
        result = t.addSimType(analysis.Transient(step=1e-9, stop=1e-6))
        assert result is t


# ---------------------------------------------------------------------------
# Module delegation methods (addNet, connectElement, updateElement)
# ---------------------------------------------------------------------------

class TestModuleDelegation:

    def test_add_net_delegation(self, basic_module):
        """addNet() on module delegates to _element_mgr."""
        basic_module.addNet('new_net')
        assert 'new_net' in basic_module._element_mgr.net_dict

    def test_connect_element_delegation(self, basic_module):
        """connectElement() on module delegates to _element_mgr."""
        # Reconnect mn's drain to a new net
        basic_module.connectElement('mn', ['d'], ['new_drain'])
        pin_list = basic_module.elem_dict['mn']['device'].pin_list
        assert pin_list['d'].net == 'new_drain'

    def test_update_element_delegation(self, basic_module):
        """updateElement() on module delegates to _element_mgr."""
        basic_module.updateElement('mn', ['w'], [5])
        param_list = basic_module.elem_dict['mn']['device'].param_list
        assert param_list['w'].value.value == 5


# ---------------------------------------------------------------------------
# generateNetlist subckt=False guard
# ---------------------------------------------------------------------------

class TestGenerateNetlistGuard:

    def test_raises_when_subckt_false(self, pdk, tmp_dir):
        """generateNetlist() raises ValueError when called without subckt=True."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleName('inv')
        mod.defineModuleNets({'a': None, 'b': None})
        with pytest.raises(ValueError, match='subckt=True'):
            mod.generateNetlist(subckt=False)

    def test_default_arg_generates_subckt(self, pdk, tmp_dir):
        """generateNetlist() with no args auto-generates subckt when module_name is set."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleName('inv')
        mod.defineModuleNets({'a': None, 'b': None})
        output = mod.generateNetlist()
        assert '.subckt' in output


# ---------------------------------------------------------------------------
# PyModule.add() — AnalogElement instance method (lines 83-84)
# ---------------------------------------------------------------------------

class TestPyModuleAdd:

    def test_add_analog_element_instance(self, pdk, tmp_dir):
        """PyModule.add() stores a factory-created AnalogElement in elem_dict."""
        from silk.elements.factory import make_device_class

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_add.cir', pdkDetails=pdk)
        mod.defineModuleName('test_add')
        mod.defineModuleNets({'a': None, 'b': None})

        spec = {
            'PDKDevice': 'sky130_fd_pr__nfet_01v8',
            'pinList': {'d': 'drain', 'g': 'gate', 's': 'source', 'b': 'bulk'},
            'paramList': {
                'w': {'minval': 1.0, 'maxval': 10.0, 'unit': 'u'},
                'l': {'minval': 0.15, 'maxval': 1.0, 'unit': 'u'},
            },
        }
        NMOSCls = make_device_class('nmos1p8', spec, is_pdk=True)
        mn1 = NMOSCls('mn1', d='a', g='b', s='gnd', b='gnd', w=1.0, l=0.15)

        mod.add(mn1)
        assert 'mn1' in mod.elem_dict

    def test_add_multiple_instances(self, pdk, tmp_dir):
        """PyModule.add(*devices) accepts multiple devices at once."""
        from silk.elements.factory import make_device_class

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_add2.cir', pdkDetails=pdk)
        mod.defineModuleName('test_add2')
        mod.defineModuleNets({'a': None, 'b': None})

        spec = {
            'PDKDevice': 'sky130_fd_pr__nfet_01v8',
            'pinList': {'d': 'drain', 'g': 'gate', 's': 'source', 'b': 'bulk'},
            'paramList': {
                'w': {'minval': 1.0, 'maxval': 10.0, 'unit': 'u'},
                'l': {'minval': 0.15, 'maxval': 1.0, 'unit': 'u'},
            },
        }
        NMOSCls = make_device_class('nmos1p8', spec, is_pdk=True)
        mn1 = NMOSCls('mn_a', d='a', g='b', s='gnd', b='gnd', w=1.0, l=0.15)
        mn2 = NMOSCls('mn_b', d='b', g='a', s='gnd', b='gnd', w=2.0, l=0.15)

        mod.add(mn1, mn2)
        assert 'mn_a' in mod.elem_dict
        assert 'mn_b' in mod.elem_dict


# ---------------------------------------------------------------------------
# PyModule.addPassive() (lines 109-124)
# ---------------------------------------------------------------------------

class TestPyModuleAddPassive:

    def test_addPassive_stores_resistor(self, pdk, tmp_dir):
        """addPassive() on PyModule stores a Resistor in passives_dict."""
        from silk.elements.passives import Resistor

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_pass.cir', pdkDetails=pdk)
        mod.defineModuleName('mod_with_passives')
        mod.defineModuleNets({'in': None, 'out': None})

        r1 = Resistor('rload', pos='out', neg='gnd', resistance=10e3)
        mod.addPassive(r1)
        assert 'rload' in mod.passives_dict
        assert mod.passives_dict['rload'] is r1

    def test_addPassive_auto_registers_nets(self, pdk, tmp_dir):
        """addPassive() on PyModule auto-registers nets in net_dict."""
        from silk.elements.passives import Capacitor

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_pass2.cir', pdkDetails=pdk)
        mod.defineModuleName('mod_cap')
        mod.defineModuleNets({'in': None, 'out': None})

        cap = Capacitor('cload', pos='out', neg='gnd', capacitance=1e-12)
        mod.addPassive(cap)
        assert 'out' in mod.net_dict
        assert 'gnd' in mod.net_dict

    def test_addPassive_duplicate_name_raises(self, pdk, tmp_dir):
        """addPassive() on PyModule raises DuplicateNameError for duplicate name."""
        from silk.elements.passives import Resistor
        from silk.exceptions import DuplicateNameError

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_dup.cir', pdkDetails=pdk)
        mod.defineModuleName('mod_dup')
        mod.defineModuleNets({'a': None})

        mod.addPassive(Resistor('r1', pos='a', neg='gnd', resistance=1e3))
        with pytest.raises(DuplicateNameError):
            mod.addPassive(Resistor('r1', pos='a', neg='gnd', resistance=2e3))

    def test_addPassive_invalid_type_raises(self, pdk, tmp_dir):
        """addPassive() with non-passive raises PyNetlistError."""
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_bad.cir', pdkDetails=pdk)
        mod.defineModuleName('mod_bad')
        mod.defineModuleNets({'a': None})

        with pytest.raises(PyNetlistError):
            mod.addPassive('not_a_passive')

    def test_addPassive_passive_in_netlist_output(self, pdk, tmp_dir):
        """addPassive() on PyModule includes passive in generateNetlist output."""
        from silk.elements.passives import Resistor

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod_netlist.cir', pdkDetails=pdk)
        mod.defineModuleName('mod_with_r')
        mod.defineModuleNets({'in': None, 'out': None})

        mod.addElement(pdk.nmos1p8, 'mn',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15, 'm': 1})
        mod.addPassive(Resistor('rload', pos='out', neg='gnd', resistance=10e3))

        netlist_str = mod.generateNetlist(subckt=True)
        assert 'Rrload' in netlist_str


# ---------------------------------------------------------------------------
# ModuleVariable — uncovered distribution branches
# ---------------------------------------------------------------------------

class TestModuleVariableGridAndLogGridEdgeCases:

    def test_grid_n_equals_1_returns_lo(self):
        """_grid_samples with n=1 returns [lo] (line 457)."""
        mv = ModuleVariable('w', bounds=(1.0, 5.0))
        s = mv.sample(1, method='grid')
        assert s == [1.0]

    def test_log_grid_n_equals_1_returns_lo(self):
        """_log_grid_samples with n=1 returns [lo] (line 465)."""
        mv = ModuleVariable('w', bounds=(1e-9, 1e-6))
        s = mv.sample(1, method='log_grid')
        assert len(s) == 1
        assert abs(s[0] - 1e-9) < 1e-20

    def test_log_grid_lo_zero_raises(self):
        """_log_grid_samples with lo <= 0 raises ValueError (line 463)."""
        mv = ModuleVariable('w', bounds=(0.0, 1.0))
        with pytest.raises(ValueError, match='log_grid'):
            mv.sample(5, method='log_grid')

    def test_clip_categorical_returns_val_unchanged(self):
        """clip() for CATEGORICAL type returns val unchanged (line 376)."""
        mv = ModuleVariable('corner', var_type=VarType.CATEGORICAL,
                            categories=['tt', 'ss', 'ff'])
        # CATEGORICAL clip just returns the value
        assert mv.clip('tt') == 'tt'
        assert mv.clip('outside_cats') == 'outside_cats'


class TestModuleVariableDistributions:

    def test_normal_distribution_samples_in_range(self):
        """_random_samples with NORMAL distribution produces clipped values."""
        mv = ModuleVariable('w', bounds=(1.0, 5.0), distribution=Distribution.NORMAL)
        s = mv.sample(100, method='random')
        assert len(s) == 100
        assert all(1.0 <= v <= 5.0 for v in s)

    def test_log_uniform_random_samples_in_range(self):
        """_random_samples with LOG_UNIFORM distribution produces values in range."""
        mv = ModuleVariable('w', bounds=(1e-9, 1e-6), distribution=Distribution.LOG_UNIFORM)
        s = mv.sample(50, method='random')
        assert len(s) == 50
        assert all(9.9e-10 <= v <= 1.01e-6 for v in s)

    def test_lhs_log_uniform_samples_in_range(self):
        """_lhs_samples with LOG_UNIFORM distribution produces values in range (lines 476-477)."""
        mv = ModuleVariable('w', bounds=(1e-3, 1.0), distribution=Distribution.LOG_UNIFORM)
        s = mv.sample(20, method='lhs')
        assert len(s) == 20
        assert all(9.9e-4 <= v <= 1.01 for v in s)

    def test_sobol_log_uniform_samples_in_range(self):
        """_sobol_samples with LOG_UNIFORM distribution produces values in range (lines 491-492)."""
        mv = ModuleVariable('w', bounds=(1e-3, 1.0), distribution=Distribution.LOG_UNIFORM)
        s = mv.sample(8, method='sobol')
        assert len(s) == 8
        assert all(9.9e-4 <= v <= 1.01 for v in s)


# ---------------------------------------------------------------------------
# ModuleVariable.validate() with categorical None categories (lines 442-444)
# ---------------------------------------------------------------------------

class TestModuleVariableValidateCategoricalEdge:

    def test_validate_categorical_with_none_categories_returns_false(self):
        """validate() for CATEGORICAL with categories=None returns False (line 442-444)."""
        mv = ModuleVariable('corner', var_type=VarType.CATEGORICAL, categories=None)
        # categories is None → condition `self.categories is not None and val in self.categories`
        # → False (short-circuits on None)
        assert mv.validate('tt') is False


# ---------------------------------------------------------------------------
# Old netlist methods (for coverage of legacy code paths)
# ---------------------------------------------------------------------------
