"""
Tests for pynetlist.core.signals — PySignal registry and PySpiceSignal.from_rawfile().

Covers:
- PySignal.load() with unknown and registered simulators
- PySignal.register() decorator with a custom subclass
- PySpiceSignal.from_rawfile() success paths (voltage, current)
- PySpiceSignal.from_rawfile() error paths (not found, malformed names)
- Case-insensitive signal type matching
- Inheritance chain assertions
- Arithmetic on PySpiceSignal returns PySpiceSignal

Does NOT duplicate arithmetic/plot/error tests already in test_analysis.py.
"""

import pytest
import numpy as np
from unittest.mock import MagicMock

from silk.signals import PySignal, PySpiceSignal
from silk.exceptions import SimulationError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_rawdata(signals):
    """Build a mock ngspice rawdata object.

    Parameters
    ----------
    signals : list of (name, data, type)
        Each tuple becomes one vector on the mock object.
    """
    raw = MagicMock()
    raw.nvars = len(signals)
    vecs = []
    for name, data, sig_type in signals:
        v = MagicMock()
        v.name = name
        v.data = np.asarray(data)
        v.type = sig_type
        vecs.append(v)
    raw.vectors = vecs
    return raw


def _make_transient_rawdata():
    """Return a minimal transient rawdata with time, v(out), and i(drain)."""
    t = np.linspace(0, 1e-6, 50)
    return make_rawdata([
        ('time',    t,                   'time'),
        ('v(out)',  np.sin(t * 1e6),     'voltage'),
        ('i(drain)', np.ones(50) * 1e-3, 'current'),
    ])


# ---------------------------------------------------------------------------
# PySignal registry — load() dispatch
# ---------------------------------------------------------------------------

class TestPySignalLoad:

    def test_unknown_simulator_raises_value_error(self):
        """load() raises ValueError when the simulator name is not registered."""
        raw = make_rawdata([('time', [0, 1], 'time')])
        with pytest.raises(ValueError):
            PySignal.load('nonexistent_sim', raw, 'out')

    def test_error_message_lists_registered_simulators(self):
        """ValueError from load() mentions registered simulator names."""
        raw = make_rawdata([('time', [0, 1], 'time')])
        with pytest.raises(ValueError, match='ngspice'):
            PySignal.load('bad_sim', raw, 'out')

    def test_ngspice_dispatches_to_pyspice_signal(self):
        """load('ngspice', ...) returns a PySpiceSignal instance."""
        raw = _make_transient_rawdata()
        sig = PySignal.load('ngspice', raw, 'out', 'V')
        assert isinstance(sig, PySpiceSignal)

    def test_ngspice_load_returns_pysignal(self):
        """PySpiceSignal returned by load() is also an instance of PySignal."""
        raw = _make_transient_rawdata()
        sig = PySignal.load('ngspice', raw, 'out', 'V')
        assert isinstance(sig, PySignal)


# ---------------------------------------------------------------------------
# PySignal.register() decorator
# ---------------------------------------------------------------------------

class TestPySignalRegister:

    def test_custom_subclass_is_retrievable_via_load(self):
        """A class decorated with @PySignal.register() is found by load()."""
        sentinel_data = np.array([42.0])

        @PySignal.register('test_sim_xyz')
        class _TestSim(PySignal):
            @classmethod
            def from_rawfile(cls, rawdata, signal_name, signal_type='V'):
                return cls(signal_name, 'voltage', 'time', 'voltage',
                           sentinel_data, sentinel_data)

        raw = make_rawdata([])
        sig = PySignal.load('test_sim_xyz', raw, 'dummy')
        assert isinstance(sig, _TestSim)
        np.testing.assert_array_equal(sig.y, sentinel_data)

        # Clean up so we don't pollute other tests
        del PySignal._registry['test_sim_xyz']

    def test_register_stores_subclass_in_registry(self):
        """@PySignal.register() adds the class to PySignal._registry."""
        @PySignal.register('test_sim_abc')
        class _Dummy(PySignal):
            @classmethod
            def from_rawfile(cls, rawdata, signal_name, signal_type='V'):
                pass

        assert PySignal._registry.get('test_sim_abc') is _Dummy
        del PySignal._registry['test_sim_abc']


# ---------------------------------------------------------------------------
# PySpiceSignal.from_rawfile() — success paths
# ---------------------------------------------------------------------------

class TestFromRawfileSuccess:

    def test_extracts_voltage_signal_y_values(self):
        """from_rawfile() extracts correct y-values for a voltage signal."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'V')
        expected_y = raw.vectors[1].data
        np.testing.assert_array_equal(sig.y, expected_y)

    def test_extracts_voltage_signal_x_values(self):
        """from_rawfile() sets x-values from the time vector."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'V')
        np.testing.assert_array_equal(sig.x, raw.vectors[0].data)

    def test_extracted_signal_name(self):
        """from_rawfile() uses the bare signal name (without v(...) wrapper)."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'V')
        assert sig.name == 'out'

    def test_extracts_current_signal(self):
        """from_rawfile() extracts a current signal when signal_type='I'."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'drain', 'I')
        expected_y = raw.vectors[2].data
        np.testing.assert_array_equal(sig.y, expected_y)

    def test_current_signal_type_attribute(self):
        """Extracted current signal has type attribute from rawfile vector."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'drain', 'I')
        assert sig.type == 'current'

    def test_returns_pyspice_signal_instance(self):
        """from_rawfile() returns a PySpiceSignal (not just PySignal)."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'V')
        assert type(sig) is PySpiceSignal

    def test_returned_signal_is_pysignal_instance(self):
        """PySpiceSignal from from_rawfile() is also an instance of PySignal."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'V')
        assert isinstance(sig, PySignal)

    def test_default_signal_type_is_voltage(self):
        """from_rawfile() defaults to signal_type='V' when not specified."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out')
        np.testing.assert_array_equal(sig.y, raw.vectors[1].data)


# ---------------------------------------------------------------------------
# PySpiceSignal.from_rawfile() — error paths
# ---------------------------------------------------------------------------

class TestFromRawfileErrors:

    def test_missing_signal_raises_simulation_error(self):
        """from_rawfile() raises SimulationError when signal is not found."""
        raw = _make_transient_rawdata()
        with pytest.raises(SimulationError):
            PySpiceSignal.from_rawfile(raw, 'nonexistent_net', 'V')

    def test_error_message_includes_signal_name(self):
        """SimulationError message contains the requested signal name."""
        raw = _make_transient_rawdata()
        with pytest.raises(SimulationError, match='nonexistent_net'):
            PySpiceSignal.from_rawfile(raw, 'nonexistent_net', 'V')

    def test_wrong_type_raises_simulation_error(self):
        """from_rawfile() raises SimulationError when type doesn't match."""
        raw = _make_transient_rawdata()
        # 'out' exists as voltage, not current
        with pytest.raises(SimulationError):
            PySpiceSignal.from_rawfile(raw, 'out', 'I')

    def test_malformed_signal_name_is_skipped(self):
        """Vectors with no '(' in name are silently skipped (not matched)."""
        # Include a malformed vector name alongside valid ones
        t = np.linspace(0, 1e-6, 10)
        raw = make_rawdata([
            ('time',         t,              'time'),
            ('malformed',    np.zeros(10),   'voltage'),   # no '(' — skipped
            ('v(good)',      np.ones(10),    'voltage'),
        ])
        # 'good' should be found normally despite malformed sibling
        sig = PySpiceSignal.from_rawfile(raw, 'good', 'V')
        np.testing.assert_array_equal(sig.y, np.ones(10))

    def test_malformed_only_signals_raise_simulation_error(self):
        """When all non-xaxis vectors are malformed, SimulationError is raised."""
        t = np.linspace(0, 1e-6, 10)
        raw = make_rawdata([
            ('time',       t,            'time'),
            ('malformed1', np.zeros(10), 'voltage'),
            ('alsobroken', np.zeros(10), 'voltage'),
        ])
        with pytest.raises(SimulationError):
            PySpiceSignal.from_rawfile(raw, 'out', 'V')


# ---------------------------------------------------------------------------
# Case-insensitive signal type matching
# ---------------------------------------------------------------------------

class TestCaseInsensitiveTypeMatch:

    def test_lowercase_v_matches_voltage_signal(self):
        """signal_type='v' (lowercase) matches v(out) vector."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'v')
        np.testing.assert_array_equal(sig.y, raw.vectors[1].data)

    def test_uppercase_I_matches_current_signal(self):
        """signal_type='I' (uppercase) matches i(drain) vector."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'drain', 'I')
        np.testing.assert_array_equal(sig.y, raw.vectors[2].data)

    def test_lowercase_i_matches_current_signal(self):
        """signal_type='i' (lowercase) matches i(drain) vector."""
        raw = _make_transient_rawdata()
        sig = PySpiceSignal.from_rawfile(raw, 'drain', 'i')
        np.testing.assert_array_equal(sig.y, raw.vectors[2].data)

    def test_mixed_case_type_in_rawfile(self):
        """Vector with uppercase type prefix (V(out)) is matched case-insensitively."""
        t = np.linspace(0, 1e-6, 10)
        raw = make_rawdata([
            ('time',   t,           'time'),
            ('V(out)', np.ones(10), 'voltage'),   # uppercase prefix
        ])
        sig = PySpiceSignal.from_rawfile(raw, 'out', 'V')
        np.testing.assert_array_equal(sig.y, np.ones(10))


# ---------------------------------------------------------------------------
# Inheritance chain
# ---------------------------------------------------------------------------

class TestInheritanceChain:

    def test_pyspice_signal_is_subclass_of_pysignal(self):
        """PySpiceSignal is a subclass of PySignal."""
        assert issubclass(PySpiceSignal, PySignal)

    def test_instance_is_pyspice_signal_and_pysignal(self, sample_signal):
        """A PySpiceSignal instance satisfies isinstance checks for both classes."""
        assert isinstance(sample_signal, PySpiceSignal)
        assert isinstance(sample_signal, PySignal)

    def test_arithmetic_result_is_pyspice_signal(self, sample_signal_pair):
        """Adding two PySpiceSignal instances yields a PySpiceSignal (not base PySignal)."""
        sig1, sig2 = sample_signal_pair
        result = sig1 + sig2
        assert type(result) is PySpiceSignal

    def test_arithmetic_result_is_pysignal(self, sample_signal_pair):
        """Result of arithmetic on PySpiceSignal is also an instance of PySignal."""
        sig1, sig2 = sample_signal_pair
        result = sig1 + sig2
        assert isinstance(result, PySignal)
