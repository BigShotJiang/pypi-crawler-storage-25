"""
Tests for PySpiceNetlister — SPICE text generation from circuit data dicts.

Covers generate_header(), generate_pdk_include(), generate_device_instances(),
generate_module_definitions(), generate_analysis_commands(), generate_control_block(),
and generate_complete_netlist().
"""

import pytest

from silk.exceptions import PyNetlistError


@pytest.fixture
def fully_connected_netlist(pdk, tmp_dir):
    """
    A PyNetlist with all device parameters (including 'm') set, so
    generate_device_instances / generateNetlistEntry won't fail on unset params.
    """
    import silk.circuit.netlist as pn

    ckt = pn.PyNetlist(
        'PDK_skywater130', tmp_dir, 'full_circuit.cir', pdkDetails=pdk,
    )
    ckt.addNet('vdd'); ckt.addNet('gnd'); ckt.addNet('in'); ckt.addNet('out')

    ckt.addElement(pdk.nmos1p8, 'mn1',
                   nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                   parameters={'w': 1, 'l': 0.15, 'm': 1})
    ckt.addElement(pdk.pmos1p8, 'mp1',
                   nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                   parameters={'w': 2, 'l': 0.15, 'm': 1})
    return ckt


# ---------------------------------------------------------------------------
# generate_header
# ---------------------------------------------------------------------------

class TestGenerateHeader:

    def test_header_contains_circuit_name(self, netlister):
        """generate_header() output includes the provided circuit name."""
        header = netlister.generate_header('my_amplifier')
        assert 'my_amplifier' in header

    def test_header_contains_default_name(self, netlister):
        """generate_header() with no args uses 'circuit' as default."""
        header = netlister.generate_header()
        assert 'circuit' in header

    def test_header_is_comment(self, netlister):
        """Header lines should be SPICE comments (start with ***)."""
        header = netlister.generate_header('test')
        for line in header.strip().split('\n'):
            assert line.startswith('***')


# ---------------------------------------------------------------------------
# generate_pdk_include
# ---------------------------------------------------------------------------

class TestGeneratePdkInclude:

    def test_pdk_include_contains_corner(self, netlister):
        """generate_pdk_include() output contains the specified corner string."""
        result = netlister.generate_pdk_include('tt')
        assert 'tt' in result

    def test_pdk_include_ff_corner(self, netlister):
        """generate_pdk_include() with 'ff' corner."""
        result = netlister.generate_pdk_include('ff')
        assert 'ff' in result

    def test_pdk_include_contains_lib_directive(self, netlister):
        """Output contains .lib directive."""
        result = netlister.generate_pdk_include('ss')
        assert '.lib' in result

    def test_pdk_include_contains_library_path(self, netlister, pdk):
        """Output contains the PDK library file path."""
        result = netlister.generate_pdk_include('tt')
        assert pdk.libraryLocation in result


# ---------------------------------------------------------------------------
# generate_device_instances
# ---------------------------------------------------------------------------

class TestGenerateDeviceInstances:

    def test_device_instances_contain_element_names(self, netlister, fully_connected_netlist):
        """Output contains the instance names of added elements."""
        result = netlister.generate_device_instances(fully_connected_netlist.elem_dict)
        assert 'mn1' in result
        assert 'mp1' in result

    def test_device_instances_contain_net_names(self, netlister, fully_connected_netlist):
        """Output contains the net names that elements are connected to."""
        result = netlister.generate_device_instances(fully_connected_netlist.elem_dict)
        assert 'out' in result
        assert 'gnd' in result

    def test_device_instances_nonempty(self, netlister, fully_connected_netlist):
        """Output is a non-empty string when elements exist."""
        result = netlister.generate_device_instances(fully_connected_netlist.elem_dict)
        assert len(result.strip()) > 0

    def test_device_instances_empty_dict(self, netlister):
        """Empty elem_dict produces empty string."""
        result = netlister.generate_device_instances({})
        assert result == ''

    def test_device_instance_undefined_pin_exits(self, netlister):
        """Element with an undefined (net=None) pin raises PyNetlistError."""
        from unittest.mock import MagicMock
        from silk.circuit.circuit_elements import ElementType

        mock_pin = MagicMock()
        mock_pin.net = None  # undefined pin

        mock_device = MagicMock()
        mock_device.pin_list = {'drain': mock_pin}

        elem_dict = {'md1': {'device': mock_device, 'type': ElementType.DEVICE}}
        with pytest.raises(PyNetlistError):
            netlister.generate_device_instances(elem_dict)

    def test_device_instances_unknown_type_emits_blank(self, netlister, pdk, tmp_dir):
        """Element with unknown type produces only the comment line, no device line."""
        from unittest.mock import MagicMock

        mock_device = MagicMock()
        mock_device.pin_list = {}

        elem_dict = {
            'xunknown': {
                'device': mock_device,
                'type': 'unknown_type',  # neither DEVICE nor MODULE
            }
        }
        result = netlister.generate_device_instances(elem_dict)
        # Comment line is emitted but no device instantiation line
        assert 'xunknown' in result
        assert 'Connections' in result


# ---------------------------------------------------------------------------
# generate_module_definitions
# ---------------------------------------------------------------------------

class TestGenerateModuleDefinitions:

    def test_module_definitions_empty(self, netlister):
        """Empty module_dict produces empty string."""
        result = netlister.generate_module_definitions({})
        assert result == ''

    def test_module_definitions_debug_prints(self, pdk, tmp_dir, capsys):
        """With debug=True on PDK, generate_module_definitions prints module names."""
        from silk.circuit.modules import PyModule
        from silk.circuit.spice_netlister import PySpiceNetlister
        import silk.circuit.netlist as pn

        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleName('debug_cell')
        mod.defineModuleNets({'a': None, 'b': None})
        mod.addElement(pdk.nmos1p8, 'mn',
                       nets={'d': 'a', 'g': 'b', 's': 'b', 'b': 'b'},
                       parameters={'w': 1, 'l': 0.15, 'm': 1})

        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'top.cir', pdkDetails=pdk)
        ckt.addElement(mod, 'xinst', nets={'a': 'na', 'b': 'nb'})

        pdk.debug = True
        nl = PySpiceNetlister(pdk)
        nl.generate_module_definitions(ckt.module_dict)
        pdk.debug = False

        captured = capsys.readouterr()
        assert 'debug_cell' in captured.out

    def test_module_definitions_contain_subckt(self, pdk, tmp_dir):
        """Module definitions contain .subckt block for the module."""
        from silk.circuit.modules import PyModule
        from silk.circuit.spice_netlister import PySpiceNetlister
        import silk.circuit.netlist as pn

        # Create module with all params set
        mod = PyModule('PDK_skywater130', tmp_dir, 'mod.cir', pdkDetails=pdk)
        mod.defineModuleName('inv_cell')
        mod.defineModuleNets({'in': None, 'out': None, 'vdd': None, 'gnd': None})
        mod.addElement(pdk.nmos1p8, 'mn',
                       nets={'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'},
                       parameters={'w': 1, 'l': 0.15, 'm': 1})
        mod.addElement(pdk.pmos1p8, 'mp',
                       nets={'d': 'out', 'g': 'in', 's': 'vdd', 'b': 'vdd'},
                       parameters={'w': 2, 'l': 0.15, 'm': 1})

        # Create top-level netlist and add module
        ckt = pn.PyNetlist('PDK_skywater130', tmp_dir, 'top.cir', pdkDetails=pdk)
        ckt.addElement(mod, 'xinv1',
                       nets={'in': 'a', 'out': 'b', 'vdd': 'vdd', 'gnd': 'gnd'})

        nl = PySpiceNetlister(pdk)
        result = nl.generate_module_definitions(ckt.module_dict)
        assert '.subckt' in result
        assert 'inv_cell' in result
        assert '.ends' in result


# ---------------------------------------------------------------------------
# generate_analysis_commands
# ---------------------------------------------------------------------------

class TestGenerateAnalysisCommands:

    def test_transient_analysis_list_format(self, netlister):
        """Transient analysis with list format produces .tran directive."""
        sim_dict = {'transient': ['1n', '100n']}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.tran' in result
        assert '1n' in result
        assert '100n' in result

    def test_transient_analysis_dict_format(self, netlister):
        """Transient analysis with dict format produces .tran directive."""
        sim_dict = {'transient': {'tstep': '1n', 'tstop': '100n'}}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.tran' in result
        assert '1n' in result

    def test_ac_analysis_list_format(self, netlister):
        """AC analysis with list format produces .ac directive."""
        sim_dict = {'ac': ['dec', 10, 1, '1g']}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.ac' in result
        assert 'dec' in result
        assert '1g' in result

    def test_ac_analysis_dict_format(self, netlister):
        """AC analysis with dict format produces .ac directive."""
        sim_dict = {'ac': {'type': 'dec', 'points': 10, 'fstart': 1, 'fstop': '1g'}}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.ac' in result
        assert 'dec' in result

    def test_dc_analysis_list_format(self, netlister):
        """DC analysis with list format produces .dc directive."""
        sim_dict = {'dc': ['vsweep', 0, 1.8, 0.01]}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.dc' in result
        assert 'vsweep' in result

    def test_dc_analysis_dict_format(self, netlister):
        """DC analysis with dict format produces .dc directive."""
        sim_dict = {'dc': {'source': 'vin', 'start': 0, 'stop': 3.3, 'step': 0.1}}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.dc' in result
        assert 'vin' in result
        assert '3.3' in result

    def test_unknown_sim_type(self, netlister):
        """Unknown simulation type is emitted as a generic SPICE directive."""
        sim_dict = {'op': {}}
        result = netlister.generate_analysis_commands(sim_dict)
        assert '.op' in result

    def test_empty_analysis_dict(self, netlister):
        """Empty sim dict produces empty string."""
        result = netlister.generate_analysis_commands({})
        assert result == ''


# ---------------------------------------------------------------------------
# generate_control_block
# ---------------------------------------------------------------------------

class TestGenerateControlBlock:

    def test_control_block_contains_run(self, netlister):
        """Control block contains 'run' command."""
        result = netlister.generate_control_block('/tmp/sim')
        assert 'run' in result

    def test_control_block_contains_write(self, netlister):
        """Control block contains 'write' command."""
        result = netlister.generate_control_block('/tmp/sim')
        assert 'write' in result

    def test_control_block_contains_output_path(self, netlister):
        """Control block contains the specified output directory path."""
        result = netlister.generate_control_block('/my/output/dir')
        assert '/my/output/dir' in result

    def test_control_block_has_control_endc(self, netlister):
        """Control block has .control and .endc directives."""
        result = netlister.generate_control_block('/tmp')
        assert '.control' in result
        assert '.endc' in result

    def test_control_block_has_end(self, netlister):
        """Control block ends with .end."""
        result = netlister.generate_control_block('/tmp')
        assert '.end' in result


# ---------------------------------------------------------------------------
# generate_complete_netlist
# ---------------------------------------------------------------------------

class TestGenerateCompleteNetlist:

    def test_complete_netlist_is_nonempty(self, netlister, fully_connected_netlist, tmp_dir):
        """generate_complete_netlist() returns a non-empty string."""
        result = netlister.generate_complete_netlist(
            circuit_name='test_ckt',
            corner='tt',
            module_dict={},
            elem_dict=fully_connected_netlist.elem_dict,
            sigSources_dict={},
            SigSourceDetails=None,
            simAnalysis_dict={},
            customList_list=[],
            dirFolder=tmp_dir,
        )
        assert len(result) > 0

    def test_complete_netlist_contains_key_spice_keywords(self, netlister, fully_connected_netlist, tmp_dir):
        """Complete netlist contains essential SPICE keywords."""
        result = netlister.generate_complete_netlist(
            circuit_name='inverter',
            corner='tt',
            module_dict={},
            elem_dict=fully_connected_netlist.elem_dict,
            sigSources_dict={},
            SigSourceDetails=None,
            simAnalysis_dict={'transient': ['1n', '100n']},
            customList_list=[],
            dirFolder=tmp_dir,
        )
        assert '.lib' in result
        assert '.tran' in result
        assert '.control' in result
        assert '.end' in result
        assert 'inverter' in result

    def test_complete_netlist_contains_corner(self, netlister, fully_connected_netlist, tmp_dir):
        """Complete netlist includes the specified corner in the .lib line."""
        result = netlister.generate_complete_netlist(
            circuit_name='test',
            corner='ff',
            module_dict={},
            elem_dict=fully_connected_netlist.elem_dict,
            sigSources_dict={},
            SigSourceDetails=None,
            simAnalysis_dict={},
            customList_list=[],
            dirFolder=tmp_dir,
        )
        assert 'ff' in result

    def test_complete_netlist_contains_device_names(self, netlister, fully_connected_netlist, tmp_dir):
        """Complete netlist includes device instance names."""
        result = netlister.generate_complete_netlist(
            circuit_name='test',
            corner='tt',
            module_dict={},
            elem_dict=fully_connected_netlist.elem_dict,
            sigSources_dict={},
            SigSourceDetails=None,
            simAnalysis_dict={},
            customList_list=[],
            dirFolder=tmp_dir,
        )
        assert 'mn1' in result
        assert 'mp1' in result
