"""Tests for silk.signals.metrics — analog performance metric functions."""
import math
import numpy as np
import pytest
from silk.signals.base import Signal
from silk.signals.metrics import (
    dc_gain_dB, gain_at_freq, bandwidth_3dB, unity_gain_freq,
    phase_at_freq, phase_margin, gain_margin, cmrr_dB, integrated_noise,
)


def _make_sig(x, y, name='test'):
    """Helper: build a Signal from numpy arrays."""
    return Signal(name, 'voltage', 'frequency', 'V', x, y)


def _ac_sig(freqs, magnitudes, phases_deg=None):
    """Build a complex AC signal."""
    if phases_deg is None:
        phases_deg = np.zeros_like(magnitudes)
    y = np.array(magnitudes) * np.exp(1j * np.radians(phases_deg))
    return _make_sig(np.array(freqs, dtype=float), y)


class TestDcGainDB:
    def test_flat_gain_of_10(self):
        sig = _ac_sig([1, 10, 100], [10, 10, 10])
        assert math.isclose(dc_gain_dB(sig), 20.0, rel_tol=1e-6)

    def test_flat_gain_of_100(self):
        sig = _ac_sig([1, 10, 100], [100, 100, 100])
        assert math.isclose(dc_gain_dB(sig), 40.0, rel_tol=1e-6)

    def test_peak_is_taken(self):
        sig = _ac_sig([1, 10, 100], [1, 100, 1])
        assert math.isclose(dc_gain_dB(sig), 40.0, rel_tol=1e-6)

    def test_unity_gain(self):
        sig = _ac_sig([1, 10, 100], [1, 1, 1])
        assert math.isclose(dc_gain_dB(sig), 0.0, abs_tol=1e-9)


class TestGainAtFreq:
    def test_exact_match(self):
        sig = _ac_sig([1.0, 10.0, 100.0], [5.0, 10.0, 2.0])
        assert math.isclose(gain_at_freq(sig, 10.0), 10.0, rel_tol=1e-6)

    def test_nearest_sample(self):
        sig = _ac_sig([1.0, 10.0, 100.0], [5.0, 10.0, 2.0])
        # 9.0 is closer to 10.0 than to 1.0
        assert math.isclose(gain_at_freq(sig, 9.0), 10.0, rel_tol=1e-6)


class TestBandwidth3dB:
    def test_single_pole_rolloff(self):
        # Gain of 1 at f=0 rolling off, 3dB point at f=1
        freqs = np.logspace(-1, 2, 200)
        mag = 1.0 / np.sqrt(1 + (freqs / 1.0) ** 2)
        sig = _ac_sig(freqs, mag)
        bw = bandwidth_3dB(sig)
        assert math.isclose(bw, 1.0, rel_tol=0.05)

    def test_flat_gain_returns_last_freq(self):
        freqs = [1.0, 10.0, 100.0]
        sig = _ac_sig(freqs, [10.0, 10.0, 10.0])
        assert bandwidth_3dB(sig) == 100.0


class TestUnityGainFreq:
    def test_crosses_at_known_freq(self):
        freqs = np.array([1.0, 10.0, 100.0, 1000.0])
        mag   = np.array([10.0, 2.0, 0.5, 0.1])
        sig = _ac_sig(freqs, mag)
        ugf = unity_gain_freq(sig)
        assert 10.0 < ugf < 100.0

    def test_gain_always_above_1_returns_0(self):
        sig = _ac_sig([1, 10, 100], [10, 5, 2])
        assert unity_gain_freq(sig) == 0.0

    def test_gain_always_below_1_returns_0(self):
        sig = _ac_sig([1, 10, 100], [0.1, 0.05, 0.01])
        assert unity_gain_freq(sig) == 0.0


class TestPhaseAtFreq:
    def test_known_phase(self):
        freqs = [1.0, 10.0, 100.0]
        mag   = [1.0, 1.0, 1.0]
        phases = [0.0, -45.0, -90.0]
        sig = _ac_sig(freqs, mag, phases)
        assert math.isclose(phase_at_freq(sig, 10.0), -45.0, abs_tol=1e-6)


class TestPhaseMargin:
    def test_typical_amplifier(self):
        # Unity gain at 10 Hz, phase = -120 deg → PM = 60 deg
        freqs = np.array([1.0, 10.0, 100.0])
        mag   = np.array([10.0, 1.0, 0.1])
        phases= np.array([-60.0, -120.0, -160.0])
        sig = _ac_sig(freqs, mag, phases)
        pm = phase_margin(sig)
        assert math.isclose(pm, 60.0, rel_tol=0.05)

    def test_no_ugf_returns_nan(self):
        sig = _ac_sig([1, 10, 100], [0.1, 0.05, 0.01])
        assert math.isnan(phase_margin(sig))


class TestGainMargin:
    def test_positive_gain_margin(self):
        # Phase goes from -135 to -200 (crosses -180 between i=1 and i=2)
        # gain at phase crossing is between 2.0 and 0.5 — unstable system has negative GM
        # Stable system: phase crosses -180 when gain < 1
        freqs = np.array([1.0, 10.0, 100.0, 1000.0])
        mag   = np.array([10.0, 0.2, 0.05, 0.01])   # gain already < 1 at phase crossing
        phases= np.array([-90.0, -135.0, -180.0, -200.0])
        sig = _ac_sig(freqs, mag, phases)
        gm = gain_margin(sig)
        # triggers at i=1: phase -135 > -180, phase -180 >= -180. gain=0.2
        # GM = -20*log10(0.2) = 13.98 dB (positive = stable)
        assert gm > 0

    def test_negative_gain_margin_unstable(self):
        # Gain > 1 when phase crosses -180 → negative GM (unstable)
        freqs = np.array([1.0, 10.0, 100.0, 1000.0])
        mag   = np.array([10.0, 2.0, 0.5, 0.1])
        phases= np.array([-90.0, -135.0, -180.0, -200.0])
        sig = _ac_sig(freqs, mag, phases)
        gm = gain_margin(sig)
        assert gm < 0   # unstable: gain > 1 at -180 phase

    def test_phase_never_reaches_180_returns_nan(self):
        sig = _ac_sig([1, 10, 100], [10, 5, 2], [0, -45, -90])
        assert math.isnan(gain_margin(sig))


class TestCmrrDB:
    def test_typical_cmrr(self):
        diff = _ac_sig([1, 10], [1000, 1000])
        cm   = _ac_sig([1, 10], [1, 1])
        assert math.isclose(cmrr_dB(diff, cm), 60.0, rel_tol=1e-6)

    def test_zero_cm_gain_returns_inf(self):
        diff = _ac_sig([1, 10], [100, 100])
        cm   = _ac_sig([1, 10], [0, 0])
        assert cmrr_dB(diff, cm) == float('inf')


class TestIntegratedNoise:
    def test_white_noise(self):
        # Flat 1 nV/sqrt(Hz) noise from 1 Hz to 100 Hz → RMS = 1e-9 * sqrt(99) ≈ 9.95 nV
        freqs = np.linspace(1.0, 100.0, 1000)
        psd   = np.full_like(freqs, 1e-9)
        sig = _make_sig(freqs, psd)
        result = integrated_noise(sig, 1.0, 100.0)
        expected = 1e-9 * np.sqrt(99.0)
        assert math.isclose(result, expected, rel_tol=0.01)

    def test_out_of_band_returns_zero(self):
        freqs = np.array([1.0, 10.0, 100.0])
        sig = _make_sig(freqs, np.array([1e-9, 1e-9, 1e-9]))
        assert integrated_noise(sig, 200.0, 1000.0) == 0.0


class TestImports:
    def test_importable_from_silk_signals(self):
        from silk.signals import dc_gain_dB, bandwidth_3dB, phase_margin
        assert callable(dc_gain_dB)

    def test_metrics_module_importable(self):
        from silk.signals import metrics
        assert hasattr(metrics, 'dc_gain_dB')
        assert hasattr(metrics, 'phase_margin')
        assert hasattr(metrics, 'integrated_noise')
