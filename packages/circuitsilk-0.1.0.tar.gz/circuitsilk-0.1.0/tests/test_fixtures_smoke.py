"""Smoke tests to verify all conftest fixtures instantiate correctly."""


def test_tmp_dir(tmp_dir):
    assert isinstance(tmp_dir, str)


def test_pdk(pdk):
    assert 'nmos1p8' in pdk.modelNames
    assert 'pmos1p8' in pdk.modelNames
    assert hasattr(pdk, 'nmos1p8')
    assert hasattr(pdk, 'pmos1p8')


def test_empty_netlist(empty_netlist):
    assert len(empty_netlist.elem_dict) == 0
    assert len(empty_netlist.sigSources_dict) == 0


def test_basic_netlist(basic_netlist):
    assert 'mn1' in basic_netlist.elem_dict
    assert 'mp1' in basic_netlist.elem_dict
    assert len(basic_netlist.elem_dict) == 2


def test_netlist_with_sources(netlist_with_sources):
    assert 'vdd_supply' in netlist_with_sources.sigSources_dict
    assert 'vin' in netlist_with_sources.sigSources_dict
    assert 'transient' in netlist_with_sources.simAnalysis_dict


def test_sample_signal(sample_signal):
    assert sample_signal.name == 'v(out)'
    assert len(sample_signal.x) == 100


def test_sample_signal_pair(sample_signal_pair):
    sig1, sig2 = sample_signal_pair
    assert sig1.name == 'v(out)'
    assert sig2.name == 'v(ref)'


def test_in_memory_db(in_memory_db):
    assert in_memory_db is not None


def test_db_with_circuit(db_with_circuit):
    db, circuit_id = db_with_circuit
    assert circuit_id is not None


def test_basic_module(basic_module):
    assert basic_module.module_name == 'inv_cell'
    assert 'mn' in basic_module.elem_dict
    assert 'mp' in basic_module.elem_dict




def test_netlister(netlister):
    header = netlister.generate_header('test')
    assert 'test' in header


def test_mock_ngspice(mock_ngspice, tmp_dir):
    import subprocess
    subprocess.run(['ngspice', '-b', '-r', f'{tmp_dir}/raw.raw', '-o', f'{tmp_dir}/out.log', 'test.cir'])
    assert mock_ngspice['called']
    assert 'ngspice' in mock_ngspice['command']
