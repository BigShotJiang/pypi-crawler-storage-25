"""Tests for CircuitSpec ports field and Generator subcircuit mode (Phase 4 Gap 1 & 2)."""
import pytest
from silk.codegen import Generator, CircuitSpec, DeviceSpec


class TestCircuitSpecPorts:
    def test_ports_field_defaults_empty(self):
        spec = CircuitSpec(circuit_name='test')
        assert spec.ports == {}

    def test_ports_field_set_directly(self):
        spec = CircuitSpec(circuit_name='ldo', ports={'vin': 'input', 'vout': 'output'})
        assert spec.ports == {'vin': 'input', 'vout': 'output'}

    def test_from_dict_parses_ports(self):
        d = {'circuit_name': 'ldo', 'ports': {'vin': 'input', 'vout': 'output', 'gnd': 'inout'}}
        spec = CircuitSpec.from_dict(d)
        assert spec.ports == {'vin': 'input', 'vout': 'output', 'gnd': 'inout'}

    def test_from_dict_no_ports_key(self):
        spec = CircuitSpec.from_dict({'circuit_name': 'x'})
        assert spec.ports == {}

    def test_from_dict_empty_ports(self):
        spec = CircuitSpec.from_dict({'circuit_name': 'x', 'ports': {}})
        assert spec.ports == {}


class TestGeneratorNoPortsEmitsNetlist:
    def test_no_ports_emits_pynetlist(self):
        spec = CircuitSpec(circuit_name='tb', simulation={'type': 'transient', 'step': '1n', 'stop': '1u'})
        code = Generator().generate(spec)
        assert 'PyNetlist' in code

    def test_no_ports_does_not_emit_module_class(self):
        spec = CircuitSpec(circuit_name='tb')
        code = Generator().generate(spec)
        assert 'defineModuleName' not in code
        assert 'defineModuleNets' not in code

    def test_no_ports_from_dict(self):
        code = Generator().generate({'circuit_name': 'sim'})
        assert 'PyNetlist' in code


class TestGeneratorWithPortsEmitsModule:
    def test_with_ports_emits_module(self):
        spec = CircuitSpec(circuit_name='ldo', ports={'vin': 'input', 'vout': 'output'})
        code = Generator().generate(spec)
        assert 'Module' in code

    def test_with_ports_emits_define_module_name(self):
        spec = CircuitSpec(circuit_name='ldo', ports={'vin': 'input', 'vout': 'output'})
        code = Generator().generate(spec)
        assert "defineModuleName('ldo')" in code

    def test_with_ports_emits_define_module_nets(self):
        spec = CircuitSpec(circuit_name='buf', ports={'a': 'input', 'z': 'output'})
        code = Generator().generate(spec)
        assert 'defineModuleNets' in code
        assert "'a': 'input'" in code
        assert "'z': 'output'" in code

    def test_with_ports_does_not_emit_pynetlist(self):
        spec = CircuitSpec(circuit_name='buf', ports={'a': 'input', 'z': 'output'})
        code = Generator().generate(spec)
        assert 'PyNetlist(' not in code

    def test_with_ports_from_dict(self):
        d = {'circuit_name': 'buf', 'ports': {'a': 'input', 'z': 'output'}}
        code = Generator().generate(d)
        assert 'Module' in code
        assert 'defineModuleName' in code

    def test_with_ports_includes_pdk_setup(self):
        spec = CircuitSpec(circuit_name='ldo', ports={'vin': 'input', 'vout': 'output'})
        code = Generator().generate(spec)
        assert 'PDK_skywater130' in code
        assert 'pdk =' in code

    def test_with_ports_none_direction(self):
        """Ports with None direction (unspecified) should still work."""
        spec = CircuitSpec(circuit_name='buf', ports={'a': None, 'z': None})
        code = Generator().generate(spec)
        assert 'defineModuleNets' in code
