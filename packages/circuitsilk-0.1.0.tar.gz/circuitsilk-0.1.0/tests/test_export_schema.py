"""Tests for export_schema() Module support (GUI Gap 4) and defineModuleNets direction (Gap 3)."""
import json
import pytest
from silk.circuit.modules import Module, ModulePin
from silk.elements.schema import module_schema, export_schema


# ---- Fixtures ----

@pytest.fixture
def pdk(tmp_path):
    pdk_yaml = '/home/lazarus/python-dev/silk/silk/pdk/data/skywater_130_device_details.yaml'
    try:
        from silk.pdk.skywater130 import PDK_skywater130
        return PDK_skywater130(pdk_yaml, libraryLocation='/dev/null')
    except Exception:
        pytest.skip('PDK not available')

@pytest.fixture
def simple_module(pdk, tmp_path):
    mod = Module('PDK_skywater130', str(tmp_path), 'ldo.cir', pdkDetails=pdk)
    mod.defineModuleName('ldo')
    mod.defineModuleNets({
        'vin':  'input',
        'vout': 'output',
        'vdd':  'inout',
        'gnd':  None,
    })
    return mod


# ---- Gap 3: defineModuleNets stores direction ----

class TestModulePinDirection:
    def test_direction_stored(self, simple_module):
        assert simple_module.pin_list['vin'].direction == 'input'
        assert simple_module.pin_list['vout'].direction == 'output'
        assert simple_module.pin_list['vdd'].direction == 'inout'
        assert simple_module.pin_list['gnd'].direction is None

    def test_none_value_compat(self, pdk, tmp_path):
        """Old-style {net: None} still works."""
        mod = Module('PDK_skywater130', str(tmp_path), 'x.cir', pdkDetails=pdk)
        mod.defineModuleName('buf')
        mod.defineModuleNets({'a': None, 'z': None})
        assert mod.pin_list['a'].direction is None

    def test_modulepin_has_direction_attribute(self):
        pin = ModulePin(name='x')
        assert hasattr(pin, 'direction')
        assert pin.direction is None


# ---- Gap 4: module_schema() ----

class TestModuleSchema:
    def test_schema_name(self, simple_module):
        s = module_schema(simple_module)
        assert s['name'] == 'ldo'

    def test_schema_type_is_module(self, simple_module):
        s = module_schema(simple_module)
        assert s['type'] == 'module'

    def test_schema_not_pdk_device(self, simple_module):
        s = module_schema(simple_module)
        assert s['is_pdk_device'] is False

    def test_schema_category(self, simple_module):
        s = module_schema(simple_module)
        assert s['category'] == 'module'

    def test_schema_pins_count(self, simple_module):
        s = module_schema(simple_module)
        assert len(s['pins']) == 4

    def test_schema_pin_names(self, simple_module):
        s = module_schema(simple_module)
        names = [p['name'] for p in s['pins']]
        assert 'vin' in names
        assert 'vout' in names

    def test_schema_pin_directions(self, simple_module):
        s = module_schema(simple_module)
        by_name = {p['name']: p['direction'] for p in s['pins']}
        assert by_name['vin'] == 'input'
        assert by_name['vout'] == 'output'
        assert by_name['vdd'] == 'inout'
        assert by_name['gnd'] is None

    def test_schema_devices_empty(self, simple_module):
        s = module_schema(simple_module)
        assert s['devices'] == []

    def test_schema_has_code_template(self, simple_module):
        s = module_schema(simple_module)
        assert 'code_template' in s
        assert 'ldo' in s['code_template']
        assert 'defineModuleName' in s['code_template']

    def test_schema_json_serialisable(self, simple_module):
        s = module_schema(simple_module)
        json_str = json.dumps(s)
        assert json_str  # no exception


# ---- export_schema() accepts Module ----

class TestExportSchemaModule:
    def test_export_schema_with_module(self, simple_module):
        result = export_schema(simple_module)
        assert 'ldo' in result

    def test_export_schema_module_entry(self, simple_module):
        result = export_schema(simple_module)
        assert result['ldo']['type'] == 'module'

    def test_export_schema_module_meta(self, simple_module):
        result = export_schema(simple_module)
        assert '_meta' in result
        assert result['_meta']['source_type'] == 'Module'

    def test_export_schema_module_no_meta(self, simple_module):
        result = export_schema(simple_module, include_metadata=False)
        assert '_meta' not in result


# ---- Module.export_schema() instance method ----

class TestModuleExportSchemaMethod:
    def test_instance_method_exists(self, simple_module):
        assert hasattr(simple_module, 'export_schema')
        assert callable(simple_module.export_schema)

    def test_instance_method_returns_schema(self, simple_module):
        s = simple_module.export_schema()
        assert s['name'] == 'ldo'
        assert s['type'] == 'module'

    def test_instance_method_json_serialisable(self, simple_module):
        s = simple_module.export_schema()
        json.dumps(s)  # no exception


# ---- silk-level exports ----

class TestSilkExports:
    def test_export_schema_importable_from_silk(self):
        from silk import export_schema
        assert callable(export_schema)

    def test_module_schema_importable_from_silk(self):
        from silk import module_schema
        assert callable(module_schema)
