"""
Tests for pynetlist.db.structure_tracker.CircuitStructureTracker.

Uses in-memory SQLite via CircuitDatabase to avoid touching disk.
PyNetlist instances are replaced with lightweight SimpleNamespace mocks.
"""

import pytest
from types import SimpleNamespace

from silk.db.circuit_db import CircuitDatabase, DesignStage
from silk.db.structure_tracker import CircuitStructureTracker


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_mock_netlist(elem_dict=None, net_dict=None, module_dict=None):
    """Build a minimal netlist-like object accepted by extract_structure."""
    nl = SimpleNamespace()
    nl.elem_dict = elem_dict if elem_dict is not None else {}
    nl.net_dict = net_dict if net_dict is not None else {}
    nl.module_dict = module_dict if module_dict is not None else {}
    return nl


def make_device(device_type='nmos', parameters=None, nets=None):
    """Build a minimal device object."""
    dev = SimpleNamespace()
    dev.deviceType = device_type
    dev.parameters = parameters if parameters is not None else {'w': 1e-6, 'l': 0.15e-6}
    dev.nets = nets if nets is not None else {'d': 'drain', 'g': 'gate', 's': 'source', 'b': 'gnd'}
    return dev


def make_module_obj(elem_dict=None, net_dict=None, module_name='my_module'):
    """Build a minimal PyModule-like object."""
    mod = SimpleNamespace()
    mod.elem_dict = elem_dict if elem_dict is not None else {}
    mod.net_dict = net_dict if net_dict is not None else {}
    mod.module_name = module_name
    mod.nets = {}
    mod.parameters = {}
    return mod


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def db():
    d = CircuitDatabase(':memory:')
    yield d
    d.close()


@pytest.fixture
def circuit_id(db):
    return db.create_circuit(
        name='test_amp',
        version='1.0',
        stage=DesignStage.DEV,
        description='test circuit'
    )


@pytest.fixture
def tracker(db, circuit_id):
    return CircuitStructureTracker(db, circuit_id)


@pytest.fixture
def tracker_no_id(db):
    return CircuitStructureTracker(db, None)


# ---------------------------------------------------------------------------
# __init__ tests
# ---------------------------------------------------------------------------

class TestInit:

    def test_no_circuit_id_hash_is_none(self, db):
        """Tracker with circuit_id=None starts with no stored hash."""
        t = CircuitStructureTracker(db, None)
        assert t.get_structure_hash() is None

    def test_no_circuit_id_run_count_zero(self, db):
        """Tracker with circuit_id=None starts with run count 0."""
        t = CircuitStructureTracker(db, None)
        assert t.get_run_count() == 0

    def test_with_circuit_id_does_not_crash(self, db, circuit_id):
        """Initializing with a real circuit_id does not raise."""
        t = CircuitStructureTracker(db, circuit_id)
        assert t is not None

    def test_with_circuit_id_hash_is_none_initially(self, db, circuit_id):
        """Fresh circuit has no structure hash stored."""
        t = CircuitStructureTracker(db, circuit_id)
        assert t.get_structure_hash() is None

    def test_debug_true_does_not_crash(self, db, circuit_id):
        """debug=True initializes without errors."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        assert t is not None

    def test_circuit_id_stored(self, db, circuit_id):
        """circuit_id attribute is stored correctly."""
        t = CircuitStructureTracker(db, circuit_id)
        assert t.circuit_id == circuit_id


# ---------------------------------------------------------------------------
# extract_structure tests
# ---------------------------------------------------------------------------

class TestExtractStructure:

    def test_empty_netlist_returns_dict(self, tracker):
        """extract_structure on empty netlist returns a dict."""
        nl = make_mock_netlist()
        result = tracker.extract_structure(nl)
        assert isinstance(result, dict)

    def test_empty_netlist_has_required_keys(self, tracker):
        """Result always contains transistors and nets keys."""
        nl = make_mock_netlist()
        result = tracker.extract_structure(nl)
        assert 'transistors' in result
        assert 'nets' in result
        assert 'hierarchy' in result
        assert 'modules' in result

    def test_empty_netlist_transistors_list_empty(self, tracker):
        """No elements means empty transistors list."""
        nl = make_mock_netlist()
        result = tracker.extract_structure(nl)
        assert result['transistors'] == []

    def test_empty_netlist_nets_list_empty(self, tracker):
        """No nets means empty nets list."""
        nl = make_mock_netlist()
        result = tracker.extract_structure(nl)
        assert result['nets'] == []

    def test_one_device_type_d_appears_in_transistors(self, tracker):
        """A dict-based type='d' element is added to transistors list."""
        dev = make_device('nmos')
        nl = make_mock_netlist(
            elem_dict={'M1': {'device': dev, 'type': 'd'}}
        )
        result = tracker.extract_structure(nl)
        assert len(result['transistors']) == 1
        assert result['transistors'][0]['name'] == 'M1'

    def test_device_type_field_captured(self, tracker):
        """Device type attribute is captured from deviceType."""
        dev = make_device('pmos')
        nl = make_mock_netlist(
            elem_dict={'M2': {'device': dev, 'type': 'd'}}
        )
        result = tracker.extract_structure(nl)
        assert result['transistors'][0]['type'] == 'pmos'

    def test_device_parameters_captured(self, tracker):
        """Device parameters dict is captured."""
        dev = make_device(parameters={'w': 2e-6, 'l': 0.18e-6})
        nl = make_mock_netlist(
            elem_dict={'M3': {'device': dev, 'type': 'd'}}
        )
        result = tracker.extract_structure(nl)
        params = result['transistors'][0]['parameters']
        assert params.get('w') == 2e-6
        assert params.get('l') == 0.18e-6

    def test_device_nets_captured(self, tracker):
        """Device net connections are captured."""
        dev = make_device(nets={'d': 'vout', 'g': 'vin', 's': 'gnd', 'b': 'gnd'})
        nl = make_mock_netlist(
            elem_dict={'M4': {'device': dev, 'type': 'd'}}
        )
        result = tracker.extract_structure(nl)
        nets = result['transistors'][0]['nets']
        assert nets.get('d') == 'vout'

    def test_net_dict_captured(self, tracker):
        """Nets from net_dict are included in nets list."""
        nl = make_mock_netlist(net_dict={'vout': {}, 'gnd': {}})
        result = tracker.extract_structure(nl)
        net_names = [n['name'] for n in result['nets']]
        assert 'vout' in net_names
        assert 'gnd' in net_names

    def test_net_type_power_classified(self, tracker):
        """Net named vdd is classified as power."""
        nl = make_mock_netlist(net_dict={'vdd': {}})
        result = tracker.extract_structure(nl)
        vdd_net = result['nets'][0]
        assert vdd_net['type'] == 'power'

    def test_net_type_ground_classified(self, tracker):
        """Net named gnd is classified as ground."""
        nl = make_mock_netlist(net_dict={'gnd': {}})
        result = tracker.extract_structure(nl)
        gnd_net = result['nets'][0]
        assert gnd_net['type'] == 'ground'

    def test_net_type_signal_classified(self, tracker):
        """Net named vout is classified as signal."""
        nl = make_mock_netlist(net_dict={'vout': {}})
        result = tracker.extract_structure(nl)
        sig_net = result['nets'][0]
        assert sig_net['type'] == 'signal'

    def test_module_type_m_goes_to_hierarchy(self, tracker):
        """A dict-based type='m' element is added to hierarchy list."""
        mod = make_module_obj()
        nl = make_mock_netlist(
            elem_dict={'U1': {'device': mod, 'type': 'm'}}
        )
        result = tracker.extract_structure(nl)
        assert len(result['hierarchy']) == 1
        assert result['hierarchy'][0]['instance_name'] == 'U1'

    def test_multiple_devices_all_captured(self, tracker):
        """Multiple devices are all captured without duplicates."""
        dev1 = make_device('nmos')
        dev2 = make_device('pmos')
        nl = make_mock_netlist(
            elem_dict={
                'M1': {'device': dev1, 'type': 'd'},
                'M2': {'device': dev2, 'type': 'd'},
            }
        )
        result = tracker.extract_structure(nl)
        assert len(result['transistors']) == 2

    def test_module_dict_entry_populates_modules(self, tracker):
        """module_dict entry (dict with 'device') populates structure['modules']."""
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'amp_core': {'device': mod, 'defined': True}}
        )
        result = tracker.extract_structure(nl)
        assert 'amp_core' in result['modules']

    def test_module_dict_entry_has_hash(self, tracker):
        """Each module in structure['modules'] has a hash key."""
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'amp_core': {'device': mod, 'defined': True}}
        )
        result = tracker.extract_structure(nl)
        assert 'hash' in result['modules']['amp_core']

    def test_debug_mode_extract_does_not_crash(self, db, circuit_id):
        """extract_structure with debug=True prints but does not raise."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        nl = make_mock_netlist(
            elem_dict={'M1': {'device': make_device(), 'type': 'd'}},
            net_dict={'vout': {}}
        )
        result = t.extract_structure(nl)
        assert isinstance(result, dict)

    def test_module_devices_recursively_extracted(self, tracker):
        """Devices inside a module elem_dict are recursively extracted."""
        inner_dev = make_device('nmos')
        mod = make_module_obj(
            elem_dict={'Minner': {'device': inner_dev, 'type': 'd'}}
        )
        nl = make_mock_netlist(
            elem_dict={'U1': {'device': mod, 'type': 'm'}}
        )
        result = tracker.extract_structure(nl)
        names = [d['name'] for d in result['transistors']]
        assert 'U1.Minner' in names


# ---------------------------------------------------------------------------
# compute_structure_hash tests
# ---------------------------------------------------------------------------

class TestComputeStructureHash:

    def _simple_structure(self):
        return {
            'transistors': [{'name': 'M1', 'type': 'nmos', 'parameters': {'w': 1e-6}, 'nets': {}}],
            'nets': [{'name': 'vout', 'type': 'signal'}],
            'hierarchy': [],
            'parameters': [],
            'modules': {}
        }

    def test_returns_tuple(self, tracker):
        """compute_structure_hash returns a 2-tuple."""
        s = self._simple_structure()
        result = tracker.compute_structure_hash(s)
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_hash_is_string(self, tracker):
        """First element of tuple is a string."""
        s = self._simple_structure()
        h, _ = tracker.compute_structure_hash(s)
        assert isinstance(h, str)

    def test_module_hashes_is_dict(self, tracker):
        """Second element is a dict."""
        s = self._simple_structure()
        _, mh = tracker.compute_structure_hash(s)
        assert isinstance(mh, dict)

    def test_deterministic_same_input(self, tracker):
        """Same structure always produces the same hash."""
        s = self._simple_structure()
        h1, _ = tracker.compute_structure_hash(s)
        h2, _ = tracker.compute_structure_hash(s)
        assert h1 == h2

    def test_different_structures_produce_different_hashes(self, tracker):
        """Different structures produce different hashes."""
        s1 = self._simple_structure()
        s2 = self._simple_structure()
        s2['transistors'][0]['parameters']['w'] = 99e-6
        h1, _ = tracker.compute_structure_hash(s1)
        h2, _ = tracker.compute_structure_hash(s2)
        assert h1 != h2

    def test_order_independent_transistors(self, tracker):
        """Transistors in different order produce the same hash."""
        t1 = {'name': 'M1', 'type': 'nmos', 'parameters': {}, 'nets': {}}
        t2 = {'name': 'M2', 'type': 'pmos', 'parameters': {}, 'nets': {}}
        s_a = {'transistors': [t1, t2], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        s_b = {'transistors': [t2, t1], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h_a, _ = tracker.compute_structure_hash(s_a)
        h_b, _ = tracker.compute_structure_hash(s_b)
        assert h_a == h_b

    def test_empty_structure_hash_stable(self, tracker):
        """Empty structure always hashes to the same value."""
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h1, _ = tracker.compute_structure_hash(s)
        h2, _ = tracker.compute_structure_hash(s)
        assert h1 == h2

    def test_adding_transistor_changes_hash(self, tracker):
        """Adding a transistor changes the structure hash."""
        base = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        with_t = {
            'transistors': [{'name': 'M1', 'type': 'nmos', 'parameters': {}, 'nets': {}}],
            'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}
        }
        h_base, _ = tracker.compute_structure_hash(base)
        h_with, _ = tracker.compute_structure_hash(with_t)
        assert h_base != h_with

    def test_module_hashes_included_in_overall(self, tracker):
        """Module hashes are extracted into the returned module_hashes dict."""
        s = {
            'transistors': [],
            'nets': [],
            'hierarchy': [],
            'parameters': [],
            'modules': {'core': {'hash': 'abc123', 'devices': [], 'nets': [], 'submodules': {}}}
        }
        _, mh = tracker.compute_structure_hash(s)
        assert 'core' in mh
        assert mh['core'] == 'abc123'


# ---------------------------------------------------------------------------
# has_structure_changed tests
# ---------------------------------------------------------------------------

class TestHasStructureChanged:

    def test_no_prior_hash_returns_true(self, tracker_no_id):
        """has_structure_changed returns True when no hash is stored."""
        assert tracker_no_id.has_structure_changed('somehash') is True

    def test_debug_unchanged_does_not_crash(self, db, circuit_id):
        """has_structure_changed with debug=True, unchanged hash, prints without error (lines 705-710)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = t.compute_structure_hash(s)
        t.store_structure(s, h, mh)
        # Should print "Structure unchanged" debug message
        result = t.has_structure_changed(h)
        assert result is False

    def test_debug_changed_does_not_crash(self, db, circuit_id):
        """has_structure_changed with debug=True, changed hash, prints without error."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = t.compute_structure_hash(s)
        t.store_structure(s, h, mh)
        result = t.has_structure_changed('completelydifferenthash')
        assert result is True

    def test_same_hash_returns_false_after_store(self, tracker):
        """has_structure_changed returns False when hash matches stored hash."""
        structure = {
            'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}
        }
        h, mh = tracker.compute_structure_hash(structure)
        tracker.store_structure(structure, h, mh)
        assert tracker.has_structure_changed(h) is False

    def test_different_hash_returns_true_after_store(self, tracker):
        """has_structure_changed returns True when hash differs from stored."""
        structure = {
            'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}
        }
        h, mh = tracker.compute_structure_hash(structure)
        tracker.store_structure(structure, h, mh)
        assert tracker.has_structure_changed('completelydifferenthash') is True


# ---------------------------------------------------------------------------
# store_structure / get_structure_hash tests
# ---------------------------------------------------------------------------

class TestStoreStructure:

    def _empty_structure(self):
        return {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}

    def test_stored_hash_is_retrievable(self, tracker):
        """After store_structure, get_structure_hash returns the stored hash."""
        s = self._empty_structure()
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        assert tracker.get_structure_hash() == h

    def test_store_with_device(self, tracker):
        """store_structure with a transistor does not raise."""
        dev = make_device()
        nl = make_mock_netlist(elem_dict={'M1': {'device': dev, 'type': 'd'}})
        t = tracker
        s = t.extract_structure(nl)
        h, mh = t.compute_structure_hash(s)
        t.store_structure(s, h, mh)  # Should not raise
        assert t.get_structure_hash() == h

    def test_store_with_net(self, tracker):
        """store_structure with a net does not raise."""
        nl = make_mock_netlist(net_dict={'vout': {}})
        s = tracker.extract_structure(nl)
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        assert tracker.get_structure_hash() == h

    def test_store_with_module_hashes_none(self, tracker):
        """store_structure with module_hashes=None extracts from structure."""
        s = self._empty_structure()
        h, _ = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, None)  # module_hashes=None
        assert tracker.get_structure_hash() == h

    def test_store_updates_last_structure_hash_cache(self, tracker):
        """After store_structure, internal cache _last_structure_hash matches."""
        s = self._empty_structure()
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        assert tracker._last_structure_hash == h

    def test_store_with_modules_stores_module_in_db(self, tracker):
        """store_structure with modules dict stores the module via DB (lines 810-857)."""
        mod = make_module_obj(
            elem_dict={'M1': {'device': make_device(), 'type': 'd'}},
            net_dict={'out': {}, 'gnd': {}},
        )
        nl = make_mock_netlist(
            module_dict={'amp_core': {'device': mod, 'defined': True}}
        )
        s = tracker.extract_structure(nl)
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)  # Should store the module in DB
        assert tracker.get_structure_hash() == h

    def test_store_with_module_hashes_none_and_modules_present(self, tracker):
        """store_structure with None module_hashes extracts them from structure dict (lines 727-728)."""
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'core': {'device': mod, 'defined': True}}
        )
        s = tracker.extract_structure(nl)
        h, _ = tracker.compute_structure_hash(s)
        # Pass None for module_hashes when modules are non-empty
        tracker.store_structure(s, h, None)  # Should extract module_hashes from structure
        assert tracker.get_structure_hash() == h

    def test_store_with_modules_debug_mode(self, db, circuit_id):
        """store_structure with modules and debug=True prints without crashing."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'core': {'device': mod, 'defined': True}}
        )
        s = t.extract_structure(nl)
        h, mh = t.compute_structure_hash(s)
        t.store_structure(s, h, mh)
        assert t.get_structure_hash() == h

    def test_store_existing_device_updates_in_place(self, tracker):
        """store_structure updates existing device records rather than inserting duplicates (line 756)."""
        dev = make_device('nmos')
        nl = make_mock_netlist(elem_dict={'M1': {'device': dev, 'type': 'd'}})
        s = tracker.extract_structure(nl)
        h, mh = tracker.compute_structure_hash(s)

        # First store
        tracker.store_structure(s, h, mh)

        # Second store of same structure (UPDATE path for device)
        tracker.store_structure(s, h, mh)  # Should not crash even if device already exists


# ---------------------------------------------------------------------------
# increment_run_count / get_run_count tests
# ---------------------------------------------------------------------------

class TestRunCount:

    def test_initial_run_count_is_zero(self, tracker_no_id):
        """Run count starts at 0 when no circuit_id."""
        assert tracker_no_id.get_run_count() == 0

    def test_increment_increases_by_one(self, tracker):
        """increment_run_count increases count by 1."""
        # First store structure so metadata row exists
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        # After store, run_count is reset to 1
        before = tracker.get_run_count()
        tracker.increment_run_count()
        assert tracker.get_run_count() == before + 1

    def test_increment_twice(self, tracker):
        """Calling increment_run_count twice gives count + 2."""
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        before = tracker.get_run_count()
        tracker.increment_run_count()
        tracker.increment_run_count()
        assert tracker.get_run_count() == before + 2

    def test_increment_run_count_debug_mode(self, db, circuit_id):
        """increment_run_count with debug=True prints without crashing (lines 871-883)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = t.compute_structure_hash(s)
        t.store_structure(s, h, mh)
        before = t.get_run_count()
        t.increment_run_count()
        assert t.get_run_count() == before + 1

    def test_store_resets_run_count_to_one(self, tracker):
        """store_structure resets internal run count to 1."""
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        assert tracker.get_run_count() == 1


# ---------------------------------------------------------------------------
# _find_circuit_by_hash tests
# ---------------------------------------------------------------------------

class TestFindCircuitByHash:

    def test_not_found_returns_none(self, tracker):
        """_find_circuit_by_hash returns None for unknown hash."""
        result = tracker._find_circuit_by_hash('test_amp', 'nonexistenthash')
        assert result is None

    def test_found_returns_circuit_id(self, tracker, circuit_id):
        """_find_circuit_by_hash returns circuit_id after storing structure."""
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        found = tracker._find_circuit_by_hash('test_amp', h)
        assert found == circuit_id

    def test_find_circuit_by_hash_malformed_json(self, db, circuit_id):
        """_find_circuit_by_hash with malformed JSON metadata returns None (lines 1081-1082)."""
        # Inject malformed JSON
        cursor = db.conn.cursor()
        cursor.execute(
            "UPDATE circuit_versions SET metadata = ? WHERE version_id = ?",
            ('NOT VALID JSON', circuit_id)
        )
        db.conn.commit()

        t = CircuitStructureTracker(db, circuit_id)
        # Should not raise, just return None
        result = t._find_circuit_by_hash('test_amp', 'anyhash')
        assert result is None

    def test_wrong_circuit_name_returns_none(self, tracker, circuit_id):
        """_find_circuit_by_hash with wrong circuit name returns None."""
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)
        found = tracker._find_circuit_by_hash('wrong_circuit', h)
        assert found is None


# ---------------------------------------------------------------------------
# Hash change detection end-to-end tests
# ---------------------------------------------------------------------------

class TestHashChangeDetection:

    def test_hash_changes_when_transistor_added(self, tracker):
        """Adding a transistor produces a different hash."""
        base = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        dev = make_device()
        nl_with = make_mock_netlist(elem_dict={'M1': {'device': dev, 'type': 'd'}})
        s_with = tracker.extract_structure(nl_with)

        h_base, _ = tracker.compute_structure_hash(base)
        h_with, _ = tracker.compute_structure_hash(s_with)
        assert h_base != h_with

    def test_hash_stable_across_two_empty_extractions(self, tracker):
        """Two extractions of the same empty netlist produce equal hashes."""
        nl = make_mock_netlist()
        s1 = tracker.extract_structure(nl)
        s2 = tracker.extract_structure(nl)
        h1, _ = tracker.compute_structure_hash(s1)
        h2, _ = tracker.compute_structure_hash(s2)
        assert h1 == h2

    def test_full_workflow_change_detected(self, tracker):
        """Full workflow: store empty structure, then changed structure is detected."""
        empty = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h_empty, mh = tracker.compute_structure_hash(empty)
        tracker.store_structure(empty, h_empty, mh)

        dev = make_device()
        nl = make_mock_netlist(elem_dict={'M1': {'device': dev, 'type': 'd'}})
        s_new = tracker.extract_structure(nl)
        h_new, _ = tracker.compute_structure_hash(s_new)

        assert tracker.has_structure_changed(h_new) is True

    def test_full_workflow_no_change_detected(self, tracker):
        """Full workflow: store structure, then same structure shows no change."""
        dev = make_device()
        nl = make_mock_netlist(
            elem_dict={'M1': {'device': dev, 'type': 'd'}},
            net_dict={'vout': {}, 'gnd': {}}
        )
        s = tracker.extract_structure(nl)
        h, mh = tracker.compute_structure_hash(s)
        tracker.store_structure(s, h, mh)

        # Extract again from same netlist
        s2 = tracker.extract_structure(nl)
        h2, _ = tracker.compute_structure_hash(s2)
        assert tracker.has_structure_changed(h2) is False


# ---------------------------------------------------------------------------
# _load_last_structure: reload stored hash from metadata (lines 66-72)
# ---------------------------------------------------------------------------

class TestGetModuleChanges:

    def test_get_module_changes_returns_last_hashes(self, tracker):
        """get_module_changes() returns the _last_module_hashes dict (line 1203)."""
        tracker._last_module_hashes = {'m1': 'hash1', 'm2': 'hash2'}
        result = tracker.get_module_changes()
        assert result == {'m1': 'hash1', 'm2': 'hash2'}

    def test_get_module_changes_empty_initially(self, tracker_no_id):
        """get_module_changes() returns empty dict initially."""
        assert tracker_no_id.get_module_changes() == {}


class TestLoadLastStructure:

    def test_reload_hash_after_new_tracker(self, db, circuit_id):
        """A new tracker for the same circuit_id reloads the stored structure hash."""
        t1 = CircuitStructureTracker(db, circuit_id)
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = t1.compute_structure_hash(s)
        t1.store_structure(s, h, mh)

        # Create a second tracker for the same circuit — it should load the hash
        t2 = CircuitStructureTracker(db, circuit_id)
        assert t2.get_structure_hash() == h

    def test_update_metadata_with_malformed_existing_json(self, db, circuit_id):
        """_update_metadata handles malformed existing JSON silently (lines 1004-1005)."""
        # Inject malformed JSON into circuit metadata
        cursor = db.conn.cursor()
        cursor.execute(
            "UPDATE circuit_versions SET metadata = ? WHERE version_id = ?",
            ('NOT VALID JSON {{{', circuit_id)
        )
        db.conn.commit()

        t = CircuitStructureTracker(db, circuit_id)
        # Now call _update_metadata — it should read the bad JSON, catch the exception,
        # and write a fresh metadata dict
        t._update_metadata('testhash123', {})
        # Verify the metadata was written successfully
        assert t._current_run_count == 1

    def test_update_run_count_with_malformed_json(self, db, circuit_id):
        """_update_run_count handles malformed existing JSON silently (lines 1039-1040)."""
        # First store a valid structure to set up metadata
        t = CircuitStructureTracker(db, circuit_id)
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = t.compute_structure_hash(s)
        t.store_structure(s, h, mh)

        # Now corrupt the metadata
        cursor = db.conn.cursor()
        cursor.execute(
            "UPDATE circuit_versions SET metadata = ? WHERE version_id = ?",
            ('INVALID JSON', circuit_id)
        )
        db.conn.commit()

        # increment_run_count calls _update_run_count — should not crash
        t.increment_run_count()
        assert t.get_run_count() == 2

    def test_malformed_json_metadata_does_not_crash(self, db, circuit_id):
        """_load_last_structure with malformed JSON in metadata silently ignores it (lines 71-72)."""
        # Inject malformed JSON into circuit metadata
        cursor = db.conn.cursor()
        cursor.execute(
            "UPDATE circuit_versions SET metadata = ? WHERE version_id = ?",
            ('NOT VALID JSON {{{', circuit_id)
        )
        db.conn.commit()

        # Creating a new tracker should not raise even with malformed JSON
        t = CircuitStructureTracker(db, circuit_id)
        assert t.get_structure_hash() is None  # Failed to load → None

    def test_reload_run_count_after_new_tracker(self, db, circuit_id):
        """A new tracker for the same circuit_id reloads the run count from metadata."""
        t1 = CircuitStructureTracker(db, circuit_id)
        s = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        h, mh = t1.compute_structure_hash(s)
        t1.store_structure(s, h, mh)
        t1.increment_run_count()  # run_count is now 2

        t2 = CircuitStructureTracker(db, circuit_id)
        assert t2.get_run_count() == 2


# ---------------------------------------------------------------------------
# _is_pymodule and _is_transistor helper methods (lines 298, 310-323)
# ---------------------------------------------------------------------------

class TestHelperMethods:

    def test_is_pymodule_with_elem_dict(self, tracker):
        """_is_pymodule returns True for object with elem_dict."""
        obj = make_module_obj()
        assert tracker._is_pymodule(obj) is True

    def test_is_pymodule_with_module_names(self, tracker):
        """_is_pymodule returns True for object with moduleNames attribute."""
        from types import SimpleNamespace
        obj = SimpleNamespace()
        obj.moduleNames = ['module']
        assert tracker._is_pymodule(obj) is True

    def test_is_pymodule_false_for_plain_device(self, tracker):
        """_is_pymodule returns False for a plain device object."""
        dev = make_device()
        # Plain device has no elem_dict or moduleNames → False
        assert tracker._is_pymodule(dev) is False

    def test_is_transistor_with_deviceType(self, tracker):
        """_is_transistor returns True for object with deviceType."""
        dev = make_device('nmos')
        assert tracker._is_transistor(dev) is True

    def test_is_transistor_with_pin_list(self, tracker):
        """_is_transistor returns True for object with pin_list."""
        from types import SimpleNamespace
        obj = SimpleNamespace()
        obj.pin_list = {}
        assert tracker._is_transistor(obj) is True

    def test_is_transistor_default_true(self, tracker):
        """_is_transistor defaults to True (caller already filtered by type='d')."""
        from types import SimpleNamespace
        obj = SimpleNamespace()  # No deviceType, parameters, or pin_list
        assert tracker._is_transistor(obj) is True


# ---------------------------------------------------------------------------
# _extract_transistor_info: various attribute formats (lines 348-412)
# ---------------------------------------------------------------------------

class TestExtractTransistorInfo:

    def test_device_type_from_device_type_attr(self, tracker):
        """_extract_transistor_info uses device.device_type when deviceType absent."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.device_type = 'resistor'
        dev.parameters = {}
        dev.nets = {}
        info = tracker._extract_transistor_info('R1', dev, None)
        assert info is not None
        assert info['type'] == 'resistor'

    def test_device_type_from_pdk_device(self, tracker):
        """_extract_transistor_info uses pdk_device as type when no other type attr."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.pdk_device = 'sky130_nfet'
        dev.parameters = {}
        dev.nets = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info is not None
        assert info['type'] == 'sky130_nfet'

    def test_device_model_attr_captured(self, tracker):
        """_extract_transistor_info captures model attribute."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.model = 'sky130_nfet'
        dev.parameters = {}
        dev.nets = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info is not None
        assert info.get('model') == 'sky130_nfet'

    def test_parameters_dict_format(self, tracker):
        """_extract_transistor_info handles parameters dict directly."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.deviceType = 'resistor'
        dev.parameters = {'r': 10e3}
        dev.nets = {'p': 'vout', 'n': 'gnd'}
        info = tracker._extract_transistor_info('R1', dev, None)
        assert info['parameters']['r'] == 10e3

    def test_parameters_with_value_attr(self, tracker):
        """_extract_transistor_info unpacks parameters with .value attribute."""
        from types import SimpleNamespace

        class ParamVal:
            value = 5e3

        dev = SimpleNamespace()
        dev.deviceType = 'resistor'
        dev.parameters = {'r': ParamVal()}
        dev.nets = {}
        info = tracker._extract_transistor_info('R1', dev, None)
        assert info['parameters']['r'] == 5e3

    def test_nets_dict_format(self, tracker):
        """_extract_transistor_info handles nets dict directly."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.deviceType = 'nmos'
        dev.nets = {'d': 'out', 'g': 'in', 's': 'gnd', 'b': 'gnd'}
        dev.parameters = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info['nets']['d'] == 'out'

    def test_device_type_from_type_attr(self, tracker):
        """_extract_transistor_info uses device.type when no deviceType/device_type/pdk_device."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.type = 'capacitor'
        dev.parameters = {}
        dev.nets = {}
        info = tracker._extract_transistor_info('C1', dev, None)
        assert info is not None
        assert info['type'] == 'capacitor'

    def test_exception_in_extract_returns_none(self, tracker):
        """_extract_transistor_info returns None when an unexpected error occurs."""
        class BrokenDevice:
            @property
            def deviceType(self):
                raise RuntimeError("broken!")
            parameters = {}
            nets = {}

        info = tracker._extract_transistor_info('broken', BrokenDevice(), None)
        # Either returns None (debug mode off) or a partially filled dict
        # With debug=False and an exception, should return None
        assert info is None

    def test_param_list_double_value_format(self, tracker):
        """_extract_transistor_info extracts param_list with double .value (lines 366-368)."""
        from types import SimpleNamespace

        class DoubleNested:
            class Inner:
                value = 2.0
            value = Inner()

        dev = SimpleNamespace()
        dev.deviceType = 'nmos'
        dev.param_list = {'w': DoubleNested()}
        dev.pin_list = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info['parameters']['w'] == 2.0

    def test_param_list_single_value_format(self, tracker):
        """_extract_transistor_info extracts param_list with single .value (line 371)."""
        from types import SimpleNamespace

        class SingleValue:
            value = 0.15  # Not nested — value itself is a plain number

        dev = SimpleNamespace()
        dev.deviceType = 'nmos'
        dev.param_list = {'l': SingleValue()}
        dev.pin_list = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info['parameters']['l'] == 0.15

    def test_param_list_direct_value_format(self, tracker):
        """_extract_transistor_info extracts param_list with direct value (line 374)."""
        from types import SimpleNamespace

        dev = SimpleNamespace()
        dev.deviceType = 'nmos'
        dev.param_list = {'m': 1}  # Direct integer, no .value attr
        dev.pin_list = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info['parameters']['m'] == 1

    def test_param_list_exception_with_debug(self, db, circuit_id):
        """_extract_transistor_info with param_list error prints debug warning (lines 375-377)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        from types import SimpleNamespace

        class BrokenParam:
            @property
            def value(self):
                raise RuntimeError("broken param!")

        dev = SimpleNamespace()
        dev.deviceType = 'nmos'
        dev.param_list = {'bad': BrokenParam()}
        dev.pin_list = {}
        # Should not raise, but debug print
        info = t._extract_transistor_info('M1', dev, None)
        assert info is not None  # Still returns device info

    def test_pdk_device_captured_as_model(self, tracker):
        """_extract_transistor_info uses pdk_device as model when no model attr."""
        from types import SimpleNamespace
        dev = SimpleNamespace()
        dev.pdk_device = 'sky130_fd_pr__nfet_01v8'
        dev.parameters = {}
        dev.nets = {}
        info = tracker._extract_transistor_info('M1', dev, None)
        assert info.get('model') == 'sky130_fd_pr__nfet_01v8'


# ---------------------------------------------------------------------------
# _compare_module_hashes (lines 658-685)
# ---------------------------------------------------------------------------

class TestExtractModuleStructure:

    def test_module_with_submodule_gets_hash(self, tracker):
        """_extract_module_structure with a submodule computes its hash (lines 495-509)."""
        inner_dev = make_device('nmos')
        sub = make_module_obj(
            elem_dict={'Mn': {'device': inner_dev, 'type': 'd'}},
            net_dict={'out': {}, 'gnd': {}},
            module_name='subcell',
        )
        outer = make_module_obj(
            elem_dict={'Usub': {'device': sub, 'type': 'm'}},
            net_dict={'vdd': {}, 'gnd': {}},
            module_name='top_cell',
        )

        mod_struct = tracker._extract_module_structure(outer, 'top')
        assert 'Usub' in mod_struct['submodules']
        # The submodule hash should be a non-empty string
        assert isinstance(mod_struct['submodules']['Usub'], str)
        assert len(mod_struct['submodules']['Usub']) > 0


class TestCompareModuleHashes:

    def test_new_module_shows_as_changed(self, tracker):
        """New module (not in previous hashes) shows as changed."""
        modules = {'amp_core': {'hash': 'newhash', 'devices': []}}
        changes = tracker._compare_module_hashes(modules)
        assert 'amp_core' in changes
        assert changes['amp_core'] is True  # new module → changed

    def test_unchanged_module_shows_not_changed(self, tracker):
        """Module with same hash as stored shows as unchanged."""
        # Simulate stored module hash
        tracker._last_module_hashes = {'amp_core': 'existinghash'}
        modules = {'amp_core': {'hash': 'existinghash'}}
        changes = tracker._compare_module_hashes(modules)
        assert changes['amp_core'] is False

    def test_changed_module_detected(self, tracker):
        """Module with different hash shows as changed."""
        tracker._last_module_hashes = {'amp_core': 'oldhash'}
        modules = {'amp_core': {'hash': 'newhash'}}
        changes = tracker._compare_module_hashes(modules)
        assert changes['amp_core'] is True

    def test_deleted_module_shows_as_changed(self, tracker):
        """Module present in stored hashes but not in current (alongside another current module) shows as changed."""
        tracker._last_module_hashes = {'old_module': 'oldhash', 'remaining': 'rhash'}
        # old_module is absent but remaining is still present (non-empty current_modules required)
        modules = {'remaining': {'hash': 'rhash'}}
        changes = tracker._compare_module_hashes(modules)
        assert changes.get('old_module') is True

    def test_empty_modules_returns_empty_dict(self, tracker):
        """_compare_module_hashes with empty current modules returns {}."""
        tracker._last_module_hashes = {}
        changes = tracker._compare_module_hashes({})
        assert changes == {}

    def test_debug_mode_compare_does_not_crash(self, db, circuit_id):
        """_compare_module_hashes with debug=True prints without error."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        t._last_module_hashes = {'m': 'old'}
        changes = t._compare_module_hashes({'m': {'hash': 'new'}})
        assert 'm' in changes

    def test_debug_mode_new_module(self, db, circuit_id):
        """_compare_module_hashes with debug=True on new module prints 'NEW' message."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        t._last_module_hashes = {}
        changes = t._compare_module_hashes({'new_mod': {'hash': 'abc'}})
        assert changes['new_mod'] is True

    def test_debug_mode_deleted_module(self, db, circuit_id):
        """_compare_module_hashes with debug=True on deleted module prints 'DELETED' message."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        t._last_module_hashes = {'old_m': 'oldhash', 'other': 'hash2'}
        changes = t._compare_module_hashes({'other': {'hash': 'hash2'}})
        assert changes.get('old_m') is True


# ---------------------------------------------------------------------------
# _extract_parameters (lines 555-565)
# ---------------------------------------------------------------------------

class TestExtractModuleInfo:

    def test_module_with_parameters_extracted(self, tracker):
        """_extract_module_info extracts module parameters (lines 443-446)."""
        from types import SimpleNamespace

        class Param:
            value = 10.0

        mod = SimpleNamespace()
        mod.module_name = 'test_mod'
        mod.nets = {}
        mod.parameters = {'gain': Param(), 'bias': 5.0}
        info = tracker._extract_module_info('U1', mod, None)
        assert info is not None
        assert info['parameters']['gain'] == 10.0
        assert info['parameters']['bias'] == 5.0

    def test_module_exception_returns_none(self, tracker):
        """_extract_module_info returns None on exception (lines 450-453)."""
        class BrokenModule:
            @property
            def module_name(self):
                raise RuntimeError("broken module!")

        info = tracker._extract_module_info('U_bad', BrokenModule(), None)
        assert info is None

    def test_module_exception_debug_mode(self, db, circuit_id):
        """_extract_module_info with debug=True prints error on exception."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)

        class BrokenModule:
            @property
            def module_name(self):
                raise RuntimeError("debug error!")

        info = t._extract_module_info('U_debug', BrokenModule(), None)
        assert info is None


class TestExtractParameters:

    def test_no_parameters_attr_returns_empty(self, tracker):
        """_extract_parameters returns [] when module has no parameters attr."""
        from types import SimpleNamespace
        mod = SimpleNamespace()  # no parameters attr
        result = tracker._extract_parameters('amp', mod)
        assert result == []

    def test_extracts_plain_value(self, tracker):
        """_extract_parameters extracts plain values directly."""
        from types import SimpleNamespace
        mod = SimpleNamespace()
        mod.parameters = {'gain': 10.0}
        result = tracker._extract_parameters('amp', mod)
        assert len(result) == 1
        assert result[0]['name'] == 'gain'
        assert result[0]['value'] == 10.0

    def test_extracts_value_attr(self, tracker):
        """_extract_parameters unpacks .value from parameter objects."""
        from types import SimpleNamespace

        class Param:
            value = 42.5

        mod = SimpleNamespace()
        mod.parameters = {'bw': Param()}
        result = tracker._extract_parameters('amp', mod)
        assert result[0]['value'] == 42.5


# ---------------------------------------------------------------------------
# _update_changed_modules (lines 896-982)
# ---------------------------------------------------------------------------

class TestUpdateChangedModules:

    def _make_structure_with_module(self):
        """Helper to build a structure dict with one module."""
        return {
            'transistors': [],
            'nets': [],
            'hierarchy': [],
            'parameters': [],
            'modules': {
                'amp_core': {
                    'hash': 'newhash123',
                    'device_count': 2,
                    'devices': [{'name': 'M1', 'type': 'nmos', 'parameters': {}, 'nets': {}}],
                    'nets': ['vout', 'gnd'],
                    'submodules': {},
                }
            }
        }

    def test_update_changed_modules_does_not_raise(self, tracker):
        """_update_changed_modules with a changed module does not raise."""
        s = self._make_structure_with_module()
        module_changes = {'amp_core': True}
        tracker._update_changed_modules(s, module_changes)  # Should not raise

    def test_update_unchanged_module_skipped(self, tracker):
        """_update_changed_modules skips modules where has_changed=False."""
        s = self._make_structure_with_module()
        module_changes = {'amp_core': False}
        # Call with no-change flag — should not insert anything
        tracker._update_changed_modules(s, module_changes)
        # No exception = pass

    def test_update_changed_modules_skips_missing_module_data(self, tracker):
        """_update_changed_modules skips modules where module_data is None (line 908)."""
        # module_changes says 'absent_mod' changed, but structure['modules'] doesn't have it
        s = {
            'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [],
            'modules': {}  # 'absent_mod' not in modules
        }
        module_changes = {'absent_mod': True}
        # Should not raise, just skip
        tracker._update_changed_modules(s, module_changes)

    def test_update_changed_modules_debug_mode(self, db, circuit_id):
        """_update_changed_modules with debug=True prints without crashing."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        s = {
            'transistors': [],
            'nets': [],
            'hierarchy': [],
            'parameters': [],
            'modules': {
                'core': {
                    'hash': 'hash_debug',
                    'device_count': 1,
                    'devices': [],
                    'nets': ['gnd'],
                    'submodules': {},
                }
            }
        }
        module_changes = {'core': True}
        t._update_changed_modules(s, module_changes)  # Should not raise

    def test_update_changed_modules_stores_module(self, tracker):
        """_update_changed_modules inserts module into DB."""
        s = self._make_structure_with_module()
        module_changes = {'amp_core': True}
        tracker._update_changed_modules(s, module_changes)
        # Module should now be linked to circuit
        modules = tracker.db.get_circuit_modules(tracker.circuit_id)
        module_names = [m['module_name'] for m in modules]
        assert 'amp_core' in module_names


# ---------------------------------------------------------------------------
# track_and_store_if_changed_OLD (lines 1103-1191)
# ---------------------------------------------------------------------------

class TestTrackAndStoreIfChangedOLD:

    def test_first_call_stores_and_returns_changed_true(self, tracker):
        """First call to track_and_store_if_changed_OLD returns changed=True."""
        dev = make_device('nmos')
        nl = make_mock_netlist(
            elem_dict={'M1': {'device': dev, 'type': 'd'}},
            net_dict={'vout': {}, 'gnd': {}}
        )
        changed, h, module_changes = tracker.track_and_store_if_changed_OLD(nl)
        assert changed is True
        assert isinstance(h, str)

    def test_second_call_unchanged_returns_false(self, tracker):
        """Second call with same netlist returns changed=False."""
        dev = make_device('nmos')
        nl = make_mock_netlist(
            elem_dict={'M1': {'device': dev, 'type': 'd'}},
            net_dict={'vout': {}, 'gnd': {}}
        )
        tracker.track_and_store_if_changed_OLD(nl)  # First call
        changed, h, module_changes = tracker.track_and_store_if_changed_OLD(nl)  # Second call
        assert changed is False

    def test_changed_netlist_returns_true(self, tracker):
        """Modified netlist returns changed=True after initial store."""
        nl1 = make_mock_netlist(net_dict={'gnd': {}})
        tracker.track_and_store_if_changed_OLD(nl1)

        dev = make_device('pmos')
        nl2 = make_mock_netlist(
            elem_dict={'M2': {'device': dev, 'type': 'd'}},
            net_dict={'vdd': {}, 'gnd': {}}
        )
        changed, h, module_changes = tracker.track_and_store_if_changed_OLD(nl2)
        assert changed is True

    def test_debug_mode_does_not_crash(self, db, circuit_id):
        """track_and_store_if_changed_OLD with debug=True prints but does not raise."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        nl = make_mock_netlist()
        changed, h, _ = t.track_and_store_if_changed_OLD(nl)
        assert isinstance(h, str)

    def test_debug_mode_with_changed_module_prints_module_changes(self, db, circuit_id):
        """track_and_store_if_changed_OLD with debug=True and changed modules prints module info (lines 1119-1123)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)

        # First call with a module
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'core': {'device': mod, 'defined': True}}
        )
        t.track_and_store_if_changed_OLD(nl)

        # Inject stale module hash to force module change detection
        t._last_module_hashes['core'] = 'old_stale_hash'

        # Second call: same structure → but module hash differs
        # The debug path at 1119-1123 should run if module_changes is non-empty
        changed, h, module_changes = t.track_and_store_if_changed_OLD(nl)
        # module_changes should reflect the 'core' module changed
        assert 'core' in module_changes

    def test_unchanged_structure_with_changed_modules_calls_update(self, tracker):
        """track_and_store_if_changed_OLD: structure unchanged but module hashes changed (lines 1178-1182)."""
        # First call to store a structure with a module
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'core': {'device': mod, 'defined': True}}
        )
        tracker.track_and_store_if_changed_OLD(nl)  # First call stores structure

        # Now simulate that _last_module_hashes differs from current
        # (inject a stale hash to fake module change detection)
        tracker._last_module_hashes['core'] = 'old_hash_that_differs'

        # Second call: same netlist → same structure hash → unchanged
        # But module hash differs → should call _update_changed_modules
        changed, h, module_changes = tracker.track_and_store_if_changed_OLD(nl)
        assert changed is False  # Structure unchanged

    def test_returns_module_changes_dict(self, tracker):
        """track_and_store_if_changed_OLD returns module_changes as a dict."""
        mod = make_module_obj()
        nl = make_mock_netlist(
            module_dict={'amp_core': {'device': mod, 'defined': True}}
        )
        _, _, module_changes = tracker.track_and_store_if_changed_OLD(nl)
        assert isinstance(module_changes, dict)

    def test_reuse_existing_circuit_debug_mode(self, db, circuit_id):
        """track_and_store_if_changed_OLD reuse path with debug=True prints (lines 1119-1136)."""
        t1 = CircuitStructureTracker(db, circuit_id, debug=True)
        nl = make_mock_netlist(net_dict={'gnd': {}})
        nl.circuit_name = 'test_amp'
        t1.track_and_store_if_changed_OLD(nl)

        from silk.db.circuit_db import DesignStage
        new_cid = db.create_circuit(name='test_amp', version='3.0', stage=DesignStage.DEV)
        t2 = CircuitStructureTracker(db, new_cid, debug=True)
        nl2 = make_mock_netlist(net_dict={'gnd': {}})
        nl2.circuit_name = 'test_amp'
        changed2, h2, _ = t2.track_and_store_if_changed_OLD(nl2)
        assert changed2 is False

    def test_reuse_existing_circuit_when_hash_matches(self, db, circuit_id):
        """If same hash exists for circuit_name, reuses that circuit_id."""
        t = CircuitStructureTracker(db, circuit_id)
        nl = make_mock_netlist(net_dict={'gnd': {}})
        nl.circuit_name = 'test_amp'  # Must match the circuit name in DB

        # First call stores structure
        changed1, h1, _ = t.track_and_store_if_changed_OLD(nl)
        assert changed1 is True

        # Create a NEW circuit (different ID) for same circuit name
        from silk.db.circuit_db import DesignStage
        new_cid = db.create_circuit(name='test_amp', version='2.0', stage=DesignStage.DEV)
        t2 = CircuitStructureTracker(db, new_cid)
        # Give the new netlist same circuit_name
        nl2 = make_mock_netlist(net_dict={'gnd': {}})
        nl2.circuit_name = 'test_amp'

        # Second tracker should detect existing hash and reuse
        changed2, h2, _ = t2.track_and_store_if_changed_OLD(nl2)
        assert changed2 is False  # reuses existing


# ---------------------------------------------------------------------------
# _extract_from_module: old-style (non-dict) elements (lines 263-293)
# ---------------------------------------------------------------------------

class TestExtractFromModuleOldStyle:

    def test_non_dict_module_element_extracted(self, tracker):
        """_extract_from_module handles non-dict elem_dict entries (old-style)."""
        from types import SimpleNamespace

        # Old-style: elem_dict values are direct objects, not dicts
        inner_dev = make_device('pmos')
        # Don't put a 'type' wrapper — put the raw device
        mod = make_module_obj(elem_dict={'Mp': inner_dev})

        structure = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        tracker._extract_from_module(mod, structure, prefix='U1', processed=set())
        # The device has deviceType, so _is_transistor → True → should be extracted
        names = [d['name'] for d in structure['transistors']]
        assert 'U1.Mp' in names

    def test_non_dict_device_in_top_level_netlist(self, tracker):
        """extract_structure handles non-dict (old-style) device at top level."""
        dev = make_device('nmos')
        # Old-style: elem_dict value is a direct device object, not a dict
        nl = make_mock_netlist(elem_dict={'M_old': dev})
        result = tracker.extract_structure(nl)
        names = [d['name'] for d in result['transistors']]
        assert 'M_old' in names

    def test_non_dict_module_at_top_level(self, tracker):
        """extract_structure handles non-dict (old-style) module at top level."""
        mod = make_module_obj()
        nl = make_mock_netlist(elem_dict={'U_old': mod})
        result = tracker.extract_structure(nl)
        hier_names = [h['instance_name'] for h in result['hierarchy']]
        assert 'U_old' in hier_names

    def test_non_dict_device_debug_mode(self, db, circuit_id):
        """extract_structure with debug=True handles non-dict device without crashing."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        dev = make_device('nmos')
        nl = make_mock_netlist(elem_dict={'M_debug': dev})
        result = t.extract_structure(nl)
        assert any(d['name'] == 'M_debug' for d in result['transistors'])

    def test_extract_from_module_deduplicates_nets(self, tracker):
        """_extract_from_module doesn't add duplicate nets to structure['nets'] (lines 289-293)."""
        # First add 'gnd' to the structure nets manually
        structure = {
            'transistors': [],
            'nets': [{'name': 'gnd', 'type': 'ground'}],  # already present
            'hierarchy': [], 'parameters': [], 'modules': {}
        }
        dev = make_device('nmos')
        mod = make_module_obj(
            elem_dict={'M1': {'device': dev, 'type': 'd'}},
            net_dict={'gnd': {}, 'out': {}},  # 'gnd' is already in structure
        )
        tracker._extract_from_module(mod, structure, prefix='U1', processed=set())
        # 'gnd' should not be duplicated; 'out' should be added
        net_names = [n['name'] for n in structure['nets']]
        assert net_names.count('gnd') == 1
        assert 'out' in net_names

    def test_extract_from_module_debug_with_dict_device(self, db, circuit_id):
        """_extract_from_module with debug=True and dict-style device prints debug (lines 225-266)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        inner_dev = make_device('nmos')
        mod = make_module_obj(
            elem_dict={'M1': {'device': inner_dev, 'type': 'd'}},
            net_dict={'out': {}},
        )
        structure = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        t._extract_from_module(mod, structure, prefix='U1', processed=set())
        assert any(d['name'] == 'U1.M1' for d in structure['transistors'])

    def test_extract_from_module_debug_nested_module(self, db, circuit_id):
        """_extract_from_module with debug=True and nested module prints debug (line 251)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        inner_dev = make_device('nmos')
        inner_mod = make_module_obj(
            elem_dict={'Mn': {'device': inner_dev, 'type': 'd'}}
        )
        outer_mod = make_module_obj(
            elem_dict={'Usub': {'device': inner_mod, 'type': 'm'}}
        )
        structure = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        t._extract_from_module(outer_mod, structure, prefix='TOP', processed=set())
        names = [d['name'] for d in structure['transistors']]
        assert 'TOP.Usub.Mn' in names

    def test_extract_from_module_no_elem_dict_debug(self, db, circuit_id):
        """_extract_from_module with debug=True and module with no elem_dict (line 283)."""
        t = CircuitStructureTracker(db, circuit_id, debug=True)
        from types import SimpleNamespace
        # Module with no elem_dict
        mod = SimpleNamespace()
        mod.net_dict = {'gnd': {}}  # has net_dict
        structure = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        t._extract_from_module(mod, structure, prefix='U_empty', processed=set())
        # Should add nets from net_dict
        net_names = [n['name'] for n in structure['nets']]
        assert 'gnd' in net_names

    def test_non_dict_module_in_module_recurses(self, tracker):
        """_extract_from_module recurses into non-dict PyModule sub-elements."""
        from types import SimpleNamespace

        inner_dev = make_device('nmos')
        inner_mod = make_module_obj(elem_dict={'Mn': inner_dev})

        # Old-style: elem_dict value is a PyModule-like object directly
        outer_mod = make_module_obj(elem_dict={'U2': inner_mod})

        structure = {'transistors': [], 'nets': [], 'hierarchy': [], 'parameters': [], 'modules': {}}
        tracker._extract_from_module(outer_mod, structure, prefix='TOP', processed=set())
        names = [d['name'] for d in structure['transistors']]
        assert 'TOP.U2.Mn' in names
