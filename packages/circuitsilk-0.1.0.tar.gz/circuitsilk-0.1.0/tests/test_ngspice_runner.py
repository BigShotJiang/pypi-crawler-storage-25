"""Tests for NgspiceRunner — mocks subprocess so no ngspice binary needed."""
import pytest
from unittest.mock import patch, MagicMock
from silk.simulation.runner import NgspiceRunner
from silk.exceptions import SimulationError


class TestNgspiceRunnerRun:
    def test_run_success(self, tmp_path):
        runner = NgspiceRunner(
            netlist_path=str(tmp_path / 'test.spi'),
            results_dir=str(tmp_path),
        )
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            runner.run()  # should not raise
        mock_run.assert_called_once()

    def test_run_failure_raises_simulation_error(self, tmp_path):
        runner = NgspiceRunner(
            netlist_path=str(tmp_path / 'test.spi'),
            results_dir=str(tmp_path),
        )
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=1)
            with pytest.raises(SimulationError, match='ngspice simulation failed'):
                runner.run()

    def test_run_extracts_error_lines_from_log(self, tmp_path):
        log = tmp_path / 'output.log'
        log.write_text('normal line\nError: something broke\n')
        runner = NgspiceRunner(
            netlist_path=str(tmp_path / 'test.spi'),
            results_dir=str(tmp_path),
        )
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=1)
            with pytest.raises(SimulationError, match='something broke'):
                runner.run()

    def test_correct_command_built(self, tmp_path):
        runner = NgspiceRunner(
            netlist_path='/path/to/netlist.spi',
            results_dir=str(tmp_path),
        )
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            runner.run()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == 'ngspice'
        assert '-b' in cmd
        assert '/path/to/netlist.spi' in cmd


class TestNgspiceRunnerAttributes:
    def test_importable_from_silk_simulation(self):
        from silk.simulation import NgspiceRunner
        assert NgspiceRunner is not None

    def test_results_none_before_load(self, tmp_path):
        runner = NgspiceRunner(str(tmp_path / 'test.spi'), str(tmp_path))
        assert runner.results is None

    def test_rawfile_path_set_correctly(self, tmp_path):
        runner = NgspiceRunner('netlist.spi', str(tmp_path))
        assert runner.rawfile_path == str(tmp_path) + '/rawfile.raw'

    def test_logfile_path_set_correctly(self, tmp_path):
        runner = NgspiceRunner('netlist.spi', str(tmp_path))
        assert runner.logfile_path == str(tmp_path) + '/output.log'
