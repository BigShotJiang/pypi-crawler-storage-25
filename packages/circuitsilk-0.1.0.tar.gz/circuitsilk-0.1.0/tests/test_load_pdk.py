"""Tests for load_pdk() convenience function."""
import os
import pytest
from silk.pdk import load_pdk
from silk.pdk.skywater130 import PDK_skywater130


class TestLoadPdkSignature:
    def test_unknown_pdk_raises_value_error(self):
        with pytest.raises(ValueError, match='Unknown PDK'):
            load_pdk('tsmc28')

    def test_sky130_alias_sky130(self):
        pdk = load_pdk('sky130', pdk_root='/dev/null')
        assert isinstance(pdk, PDK_skywater130)

    def test_sky130_alias_skywater130(self):
        pdk = load_pdk('skywater130', pdk_root='/dev/null')
        assert isinstance(pdk, PDK_skywater130)

    def test_sky130_alias_skywater_130(self):
        pdk = load_pdk('skywater_130', pdk_root='/dev/null')
        assert isinstance(pdk, PDK_skywater130)

    def test_pdk_root_kwarg_sets_lib_path(self, tmp_path):
        pdk = load_pdk('sky130', pdk_root=str(tmp_path))
        assert str(tmp_path) in pdk.libraryLocation

    def test_pdk_root_env_var_used(self, monkeypatch, tmp_path):
        monkeypatch.setenv('PDK_ROOT', str(tmp_path))
        pdk = load_pdk('sky130')
        assert str(tmp_path) in pdk.libraryLocation

    def test_pdk_root_defaults_to_home_pdk(self, monkeypatch):
        monkeypatch.delenv('PDK_ROOT', raising=False)
        pdk = load_pdk('sky130')
        home_pdk = os.path.expanduser('~/pdk')
        assert home_pdk in pdk.libraryLocation

    def test_yaml_path_is_bundled(self):
        pdk = load_pdk('sky130', pdk_root='/dev/null')
        assert os.path.isfile(pdk.modelList)

    def test_importable_from_silk(self):
        from silk import load_pdk as lp
        assert callable(lp)

    def test_importable_from_silk_pdk(self):
        from silk.pdk import load_pdk as lp
        assert callable(lp)
