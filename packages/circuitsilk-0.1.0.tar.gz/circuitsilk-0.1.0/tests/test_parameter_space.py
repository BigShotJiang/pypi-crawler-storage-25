"""
Tests for ParameterSpace — joint multi-variable parameter space.
"""

import math
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from silk.circuit.modules import ModuleVariable, VarType, Distribution
from silk.optimize.parameter_space import ParameterSpace


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def cont_vars():
    """Two continuous bounded variables."""
    w = ModuleVariable('w', bounds=(0.5e-6, 20e-6))
    l = ModuleVariable('l', bounds=(0.15e-6, 2e-6))
    return w, l


@pytest.fixture
def mixed_space():
    """Continuous + integer + categorical."""
    w    = ModuleVariable('w',    bounds=(0.5e-6, 20e-6))
    nfin = ModuleVariable('nfin', bounds=(1, 32), var_type=VarType.INTEGER)
    cor  = ModuleVariable('corner', var_type=VarType.CATEGORICAL,
                          categories=['tt', 'ss', 'ff'])
    return ParameterSpace([w, nfin, cor])


# ---------------------------------------------------------------------------
# Constructor
# ---------------------------------------------------------------------------

class TestParameterSpaceConstructor:

    def test_from_list_of_variables(self, cont_vars):
        w, l = cont_vars
        ps = ParameterSpace([w, l])
        assert ps.names == ['w', 'l']

    def test_from_dict_of_variables(self, cont_vars):
        w, l = cont_vars
        ps = ParameterSpace({'w': w, 'l': l})
        assert ps.size == 2

    def test_list_with_duplicate_names_raises(self, cont_vars):
        w, _ = cont_vars
        w2 = ModuleVariable('w', bounds=(1.0, 5.0))
        with pytest.raises(ValueError, match='Duplicate'):
            ParameterSpace([w, w2])

    def test_empty_list_raises(self):
        with pytest.raises(ValueError, match='at least one'):
            ParameterSpace([])

    def test_empty_dict_raises(self):
        with pytest.raises(ValueError, match='at least one'):
            ParameterSpace({})

    def test_wrong_type_raises(self):
        with pytest.raises(TypeError):
            ParameterSpace("w")

    def test_names_preserves_order(self):
        names = ['e', 'a', 'c', 'b', 'd']
        vars_ = [ModuleVariable(n, bounds=(0.0, 1.0)) for n in names]
        ps = ParameterSpace(vars_)
        assert ps.names == names

    def test_size_property(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        assert ps.size == 2
        assert len(ps) == 2

    def test_repr_contains_names(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        r = repr(ps)
        assert 'w' in r and 'l' in r


# ---------------------------------------------------------------------------
# Random sampling
# ---------------------------------------------------------------------------

class TestSampleRandom:

    def test_returns_n_dicts(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        pts = ps.sample(10)
        assert len(pts) == 10
        assert all(isinstance(p, dict) for p in pts)

    def test_dict_keys_match_names(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        for p in ps.sample(5):
            assert set(p.keys()) == set(ps.names)

    def test_values_within_bounds(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        w_var, l_var = cont_vars
        for p in ps.sample(50):
            assert 0.5e-6 <= p['w'] <= 20e-6
            assert 0.15e-6 <= p['l'] <= 2e-6

    def test_integer_var_returns_ints(self):
        ps = ParameterSpace([ModuleVariable('n', bounds=(1, 20),
                                            var_type=VarType.INTEGER)])
        for p in ps.sample(20):
            assert isinstance(p['n'], int)

    def test_categorical_var_in_categories(self):
        cats = ['tt', 'ss', 'ff']
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=cats)])
        for p in ps.sample(20):
            assert p['c'] in cats

    def test_log_uniform_in_bounds(self):
        ps = ParameterSpace([ModuleVariable('w', bounds=(1e-9, 1e-6),
                                            distribution=Distribution.LOG_UNIFORM)])
        for p in ps.sample(50):
            assert 1e-9 <= p['w'] <= 1e-6

    def test_n_zero_returns_empty(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        assert ps.sample(0) == []

    def test_unknown_method_raises(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        with pytest.raises(ValueError, match='Unknown sampling method'):
            ps.sample(5, method='bayes')


# ---------------------------------------------------------------------------
# LHS sampling
# ---------------------------------------------------------------------------

class TestSampleLHS:

    def test_returns_n_dicts(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        assert len(ps.sample(8, 'lhs')) == 8

    def test_dict_keys_correct(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        for p in ps.sample(6, 'lhs'):
            assert set(p.keys()) == set(ps.names)

    def test_values_within_bounds(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        for p in ps.sample(20, 'lhs'):
            assert 0.5e-6 <= p['w'] <= 20e-6
            assert 0.15e-6 <= p['l'] <= 2e-6

    def test_each_var_covers_all_strata(self):
        """Each variable independently has one sample per stratum."""
        ps = ParameterSpace([ModuleVariable('w', bounds=(0.0, 1.0)),
                             ModuleVariable('l', bounds=(0.0, 1.0))])
        n = 10
        pts = ps.sample(n, 'lhs')
        lo, hi = 0.0, 1.0
        for name in ps.names:
            vals = sorted(p[name] for p in pts)
            for i in range(n):
                stratum_lo = lo + i * (hi - lo) / n
                stratum_hi = lo + (i + 1) * (hi - lo) / n
                assert any(stratum_lo <= v <= stratum_hi + 1e-12 for v in vals), \
                    f"{name}: stratum [{stratum_lo:.2f}, {stratum_hi:.2f}] not covered"

    def test_vars_not_identical_rank_order(self):
        """With enough samples the two variables' strata orderings differ."""
        ps = ParameterSpace([ModuleVariable('w', bounds=(0.0, 1.0)),
                             ModuleVariable('l', bounds=(0.0, 1.0))])
        n = 20
        pts = ps.sample(n, 'lhs')
        rank_w = sorted(range(n), key=lambda i: pts[i]['w'])
        rank_l = sorted(range(n), key=lambda i: pts[i]['l'])
        assert rank_w != rank_l, "LHS variables should not be perfectly correlated"

    def test_categorical_falls_back_to_random(self):
        cats = ['tt', 'ss', 'ff']
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=cats)])
        for p in ps.sample(10, 'lhs'):
            assert p['c'] in cats

    def test_log_uniform_within_bounds(self):
        ps = ParameterSpace([ModuleVariable('w', bounds=(1e-9, 1e-6),
                                            distribution=Distribution.LOG_UNIFORM)])
        for p in ps.sample(20, 'lhs'):
            assert 9e-10 <= p['w'] <= 1.01e-6

    def test_integer_var_returns_ints(self):
        ps = ParameterSpace([ModuleVariable('n', bounds=(1, 20),
                                            var_type=VarType.INTEGER)])
        for p in ps.sample(10, 'lhs'):
            assert isinstance(p['n'], int)

    def test_unbounded_var_raises(self):
        ps = ParameterSpace([ModuleVariable('w')])
        with pytest.raises(ValueError, match="'w'"):
            ps.sample(5, 'lhs')


# ---------------------------------------------------------------------------
# Sobol (Halton) sampling
# ---------------------------------------------------------------------------

class TestSampleSobol:

    def test_returns_n_dicts(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        assert len(ps.sample(8, 'sobol')) == 8

    def test_values_within_bounds(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        for p in ps.sample(20, 'sobol'):
            assert 0.5e-6 <= p['w'] <= 20e-6
            assert 0.15e-6 <= p['l'] <= 2e-6

    def test_two_vars_use_different_sequences(self):
        """w (base-2) and l (base-3) produce different sequences."""
        ps = ParameterSpace([ModuleVariable('w', bounds=(0.0, 1.0)),
                             ModuleVariable('l', bounds=(0.0, 1.0))])
        pts = ps.sample(8, 'sobol')
        w_vals = [p['w'] for p in pts]
        l_vals = [p['l'] for p in pts]
        assert w_vals != l_vals

    def test_low_discrepancy_property(self):
        """For n=16, each stratum [i/16, (i+1)/16] covered for each var."""
        ps = ParameterSpace([ModuleVariable('w', bounds=(0.0, 1.0))])
        n = 16
        pts = ps.sample(n, 'sobol')
        vals = sorted(p['w'] for p in pts)
        for i in range(n):
            lo, hi = i / n, (i + 1) / n
            assert any(lo <= v <= hi + 1e-12 for v in vals), \
                f"Stratum [{lo:.3f},{hi:.3f}] not covered"

    def test_categorical_falls_back_to_random(self):
        cats = ['tt', 'ss', 'ff']
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=cats)])
        for p in ps.sample(10, 'sobol'):
            assert p['c'] in cats

    def test_log_uniform_within_bounds(self):
        ps = ParameterSpace([ModuleVariable('w', bounds=(1e-9, 1e-6),
                                            distribution=Distribution.LOG_UNIFORM)])
        for p in ps.sample(16, 'sobol'):
            assert 9e-10 <= p['w'] <= 1.01e-6

    def test_unbounded_var_raises(self):
        ps = ParameterSpace([ModuleVariable('w')])
        with pytest.raises(ValueError, match="'w'"):
            ps.sample(5, 'sobol')


# ---------------------------------------------------------------------------
# Grid sampling
# ---------------------------------------------------------------------------

class TestSampleGrid:

    def test_total_count_is_n_power_d(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        pts = ps.sample(3, 'grid')
        assert len(pts) == 3 ** 2

    def test_single_var_returns_n_dicts(self):
        ps = ParameterSpace([ModuleVariable('w', bounds=(0.0, 1.0))])
        assert len(ps.sample(5, 'grid')) == 5

    def test_dict_keys_correct(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        for p in ps.sample(2, 'grid'):
            assert set(p.keys()) == set(ps.names)

    def test_endpoints_covered(self):
        ps = ParameterSpace([ModuleVariable('w', bounds=(1.0, 5.0))])
        pts = ps.sample(5, 'grid')
        w_vals = [p['w'] for p in pts]
        assert min(w_vals) == pytest.approx(1.0)
        assert max(w_vals) == pytest.approx(5.0)

    def test_categorical_uses_all_categories(self):
        cats = ['tt', 'ss', 'ff']
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=cats)])
        pts = ps.sample(10, 'grid')  # n ignored for categorical
        assert set(p['c'] for p in pts) == set(cats)

    def test_integer_var_returns_ints(self):
        ps = ParameterSpace([ModuleVariable('n', bounds=(1, 5),
                                            var_type=VarType.INTEGER)])
        for p in ps.sample(5, 'grid'):
            assert isinstance(p['n'], int)


# ---------------------------------------------------------------------------
# apply()
# ---------------------------------------------------------------------------

class TestApply:

    def test_sets_variable_values(self, cont_vars):
        w, l = cont_vars
        ps = ParameterSpace([w, l])
        ps.apply({'w': 1.5e-6, 'l': 0.3e-6})
        assert w.value == pytest.approx(1.5e-6)
        assert l.value == pytest.approx(0.3e-6)

    def test_unknown_key_raises(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        with pytest.raises(KeyError, match='unknown'):
            ps.apply({'unknown': 1.0})

    def test_partial_point_sets_only_given_keys(self, cont_vars):
        w, l = cont_vars
        w.value = 1.0e-6
        l.value = 0.5e-6
        ps = ParameterSpace([w, l])
        ps.apply({'w': 2.0e-6})
        assert w.value == pytest.approx(2.0e-6)
        assert l.value == pytest.approx(0.5e-6)  # unchanged

    def test_apply_then_sample_uses_new_value(self, cont_vars):
        w, l = cont_vars
        ps = ParameterSpace([w, l])
        ps.apply({'w': 3.0e-6, 'l': 1.0e-6})
        assert w.value == pytest.approx(3.0e-6)


# ---------------------------------------------------------------------------
# Optimizer interface
# ---------------------------------------------------------------------------

class TestOptimizerInterface:

    def test_to_bounds_returns_list_of_tuples(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        b = ps.to_bounds()
        assert b == [(0.5e-6, 20e-6), (0.15e-6, 2e-6)]

    def test_to_bounds_order_matches_names(self):
        a = ModuleVariable('a', bounds=(0.0, 1.0))
        b = ModuleVariable('b', bounds=(10.0, 20.0))
        ps = ParameterSpace([a, b])
        bounds = ps.to_bounds()
        assert bounds[0] == (0.0, 1.0)
        assert bounds[1] == (10.0, 20.0)

    def test_to_bounds_unbounded_raises(self):
        ps = ParameterSpace([ModuleVariable('w')])
        with pytest.raises(ValueError, match="'w'"):
            ps.to_bounds()

    def test_to_bounds_categorical_returns_index_range(self):
        cats = ['tt', 'ss', 'ff']
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=cats)])
        assert ps.to_bounds() == [(0, 2)]

    def test_to_list_preserves_names_order(self):
        a = ModuleVariable('a', bounds=(0.0, 1.0))
        b = ModuleVariable('b', bounds=(0.0, 1.0))
        ps = ParameterSpace([a, b])
        lst = ps.to_list({'b': 0.9, 'a': 0.1})
        # names order is ['a', 'b']
        assert lst == [0.1, 0.9]

    def test_from_list_roundtrip(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        point = {'w': 3e-6, 'l': 0.5e-6}
        assert ps.from_list(ps.to_list(point)) == point

    def test_from_list_wrong_length_raises(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        with pytest.raises(ValueError, match='Expected 2'):
            ps.from_list([1.0])

    def test_roundtrip_categorical(self):
        cats = ['tt', 'ss', 'ff']
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=cats)])
        point = {'c': 'ss'}
        assert ps.from_list(ps.to_list(point)) == point


# ---------------------------------------------------------------------------
# validate() and clip()
# ---------------------------------------------------------------------------

class TestValidateAndClip:

    def test_validate_valid_point(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        assert ps.validate({'w': 5e-6, 'l': 0.5e-6}) is True

    def test_validate_out_of_bounds(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        assert ps.validate({'w': 100e-6, 'l': 0.5e-6}) is False

    def test_validate_categorical_valid(self):
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=['tt', 'ss', 'ff'])])
        assert ps.validate({'c': 'tt'}) is True

    def test_validate_categorical_invalid(self):
        ps = ParameterSpace([ModuleVariable('c', var_type=VarType.CATEGORICAL,
                                            categories=['tt', 'ss', 'ff'])])
        assert ps.validate({'c': 'fs'}) is False

    def test_clip_above_max(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        clipped = ps.clip({'w': 100e-6, 'l': 0.5e-6})
        assert clipped['w'] == pytest.approx(20e-6)

    def test_clip_below_min(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        clipped = ps.clip({'w': 0.1e-6, 'l': 0.5e-6})
        assert clipped['w'] == pytest.approx(0.5e-6)

    def test_clip_valid_unchanged(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        point = {'w': 5e-6, 'l': 0.5e-6}
        clipped = ps.clip(point)
        assert clipped['w'] == pytest.approx(5e-6)
        assert clipped['l'] == pytest.approx(0.5e-6)

    def test_clip_integer_rounds(self):
        ps = ParameterSpace([ModuleVariable('n', bounds=(1, 20),
                                            var_type=VarType.INTEGER)])
        clipped = ps.clip({'n': 3.7})
        assert clipped['n'] == 4
        assert isinstance(clipped['n'], int)

    def test_clip_does_not_mutate_input(self, cont_vars):
        ps = ParameterSpace(list(cont_vars))
        point = {'w': 100e-6, 'l': 0.5e-6}
        ps.clip(point)
        assert point['w'] == 100e-6  # original unchanged


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:

    def test_single_variable_all_methods(self):
        ps = ParameterSpace([ModuleVariable('w', bounds=(0.0, 1.0))])
        for method in ('random', 'lhs', 'sobol', 'grid'):
            pts = ps.sample(4, method)
            assert len(pts) >= 1
            assert all('w' in p for p in pts)

    def test_all_categorical_space_random(self):
        ps = ParameterSpace([
            ModuleVariable('c1', var_type=VarType.CATEGORICAL, categories=['a', 'b']),
            ModuleVariable('c2', var_type=VarType.CATEGORICAL, categories=['x', 'y', 'z']),
        ])
        pts = ps.sample(10, 'random')
        assert len(pts) == 10
        assert all(p['c1'] in ['a', 'b'] for p in pts)

    def test_all_categorical_lhs_fallback(self):
        ps = ParameterSpace([
            ModuleVariable('c', var_type=VarType.CATEGORICAL, categories=['tt', 'ff']),
        ])
        pts = ps.sample(6, 'lhs')
        assert all(p['c'] in ['tt', 'ff'] for p in pts)

    def test_mixed_types_sample_random(self, mixed_space):
        pts = mixed_space.sample(20, 'random')
        for p in pts:
            assert 0.5e-6 <= p['w'] <= 20e-6
            assert isinstance(p['nfin'], int)
            assert 1 <= p['nfin'] <= 32
            assert p['corner'] in ['tt', 'ss', 'ff']

    def test_mixed_types_sample_lhs(self, mixed_space):
        pts = mixed_space.sample(10, 'lhs')
        assert len(pts) == 10
        for p in pts:
            assert p['corner'] in ['tt', 'ss', 'ff']
            assert isinstance(p['nfin'], int)


# ---------------------------------------------------------------------------
# Public export
# ---------------------------------------------------------------------------

class TestPublicExport:

    def test_importable_from_package(self):
        from silk.optimize.parameter_space import ParameterSpace as PS
        assert PS is ParameterSpace

    def test_importable_from_core(self):
        from silk.optimize.parameter_space import ParameterSpace as PS
        assert PS is ParameterSpace

    def test_var_type_and_distribution_importable_from_package(self):
        from silk.optimize.parameter_space import VarType, Distribution
        assert VarType.CONTINUOUS == 'continuous'
        assert Distribution.LOG_UNIFORM == 'log_uniform'


class TestParameterSpaceGroups:
    """Tests for the groups= correlated-variable feature."""

    @pytest.fixture
    def three_vars(self):
        w_n = ModuleVariable('w_n', bounds=(0.42, 20.0))
        w_p = ModuleVariable('w_p', bounds=(0.42, 20.0))
        l   = ModuleVariable('l',   bounds=(0.15, 1.0))
        return w_n, w_p, l

    def test_no_groups_still_works(self, three_vars):
        w_n, w_p, l = three_vars
        space = ParameterSpace([w_n, w_p, l])
        pts = space.sample(10, method='lhs')
        assert len(pts) == 10
        assert set(pts[0].keys()) == {'w_n', 'w_p', 'l'}

    def test_single_group_correct_size(self, three_vars):
        w_n, w_p, l = three_vars
        space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])
        pts = space.sample(12, method='lhs')
        assert len(pts) == 12

    def test_multiple_groups(self, three_vars):
        w_n, w_p, l = three_vars
        vdd = ModuleVariable('vdd', bounds=(1.6, 2.0))
        space = ParameterSpace([w_n, w_p, l, vdd], groups=[[w_n, w_p], [l, vdd]])
        pts = space.sample(10, method='lhs')
        assert len(pts) == 10
        assert set(pts[0].keys()) == {'w_n', 'w_p', 'l', 'vdd'}

    def test_grouped_vars_share_rank_order_lhs(self, three_vars):
        """w_n and w_p in same group should have identical rank ordering."""
        w_n, w_p, l = three_vars
        space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])
        pts = space.sample(20, method='lhs')
        wn_vals = [p['w_n'] for p in pts]
        wp_vals = [p['w_p'] for p in pts]
        # Same rank ordering means argsort of both columns is identical
        wn_ranks = sorted(range(20), key=lambda i: wn_vals[i])
        wp_ranks = sorted(range(20), key=lambda i: wp_vals[i])
        assert wn_ranks == wp_ranks

    def test_ungrouped_var_is_independent(self, three_vars):
        """l is not grouped with w_n/w_p — its rank order should differ."""
        w_n, w_p, l = three_vars
        import random as _random
        space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])
        _random.seed(42)
        pts = space.sample(20, method='lhs')
        wn_vals = [p['w_n'] for p in pts]
        l_vals  = [p['l']   for p in pts]
        wn_ranks = sorted(range(20), key=lambda i: wn_vals[i])
        l_ranks  = sorted(range(20), key=lambda i: l_vals[i])
        assert wn_ranks != l_ranks  # independent — very unlikely to match

    def test_variable_not_in_space_raises(self, three_vars):
        w_n, w_p, l = three_vars
        outsider = ModuleVariable('outsider', bounds=(0.0, 1.0))
        with pytest.raises(ValueError, match="not in this ParameterSpace"):
            ParameterSpace([w_n, w_p, l], groups=[[w_n, outsider]])

    def test_variable_in_two_groups_raises(self, three_vars):
        w_n, w_p, l = three_vars
        with pytest.raises(ValueError, match="more than one group"):
            ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p], [w_n, l]])

    def test_groups_sobol(self, three_vars):
        w_n, w_p, l = three_vars
        space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])
        pts = space.sample(12, method='sobol')
        assert len(pts) == 12
        wn_ranks = sorted(range(12), key=lambda i: pts[i]['w_n'])
        wp_ranks = sorted(range(12), key=lambda i: pts[i]['w_p'])
        assert wn_ranks == wp_ranks

    def test_groups_random(self, three_vars):
        w_n, w_p, l = three_vars
        space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])
        pts = space.sample(12, method='random')
        assert len(pts) == 12

    def test_groups_grid(self, three_vars):
        """Groups are respected when using grid sampling."""
        w_n, w_p, l = three_vars
        space = ParameterSpace([w_n, w_p, l], groups=[[w_n, w_p]])
        pts = space.sample(3, method='grid')
        assert len(pts) == 3 ** 3
        for p in pts:
            assert 'w_n' in p and 'w_p' in p and 'l' in p

    # ------------------------------------------------------------------
    # Discrete (resolution-constrained) variables in group sampling
    # (lines 248-250, 273-279, 310-312, 329-334)
    # ------------------------------------------------------------------

    @pytest.fixture
    def discrete_var(self):
        """A variable with resolution set — snaps to a finite grid."""
        return ModuleVariable('w_d', bounds=(0.0, 1.0), resolution=0.1,
                              enforce_resolution=True)

    @pytest.fixture
    def discrete_space(self, discrete_var):
        """ParameterSpace with one discrete and one continuous variable."""
        cont = ModuleVariable('x', bounds=(0.0, 1.0))
        return ParameterSpace([discrete_var, cont])

    def test_discrete_random_values_on_grid(self, discrete_space):
        """Random sampling of a resolution-constrained var stays on the grid
        (covers lines 248-250)."""
        pts = discrete_space.sample(20, method='random')
        for p in pts:
            # Each value should be a multiple of 0.1 (within floating-point tolerance)
            assert abs(p['w_d'] % 0.1) < 1e-9 or abs(p['w_d'] % 0.1 - 0.1) < 1e-9, \
                f"Value {p['w_d']} is not on the resolution grid"

    def test_discrete_lhs_values_on_grid(self, discrete_space):
        """LHS sampling of a resolution-constrained var stays on the grid
        (covers lines 273-279)."""
        pts = discrete_space.sample(10, method='lhs')
        for p in pts:
            assert abs(p['w_d'] % 0.1) < 1e-9 or abs(p['w_d'] % 0.1 - 0.1) < 1e-9, \
                f"Value {p['w_d']} is not on the resolution grid"

    def test_discrete_sobol_values_on_grid(self):
        """Sobol sampling of a resolution-constrained var stays on the grid
        (covers lines 310-312)."""
        v = ModuleVariable('w_d', bounds=(0.0, 1.0), resolution=0.1,
                           enforce_resolution=True)
        ps = ParameterSpace([v])
        pts = ps.sample(10, method='sobol')
        for p in pts:
            assert abs(p['w_d'] % 0.1) < 1e-9 or abs(p['w_d'] % 0.1 - 0.1) < 1e-9, \
                f"Value {p['w_d']} is not on the resolution grid"

    def test_discrete_grid_uses_evenly_spaced_subset_when_grid_larger(self):
        """Grid sampling picks n evenly-spaced values when discrete set > n
        (covers lines 329-334)."""
        # resolution=0.01 over [0,1] gives 101 discrete values; request n=5
        v = ModuleVariable('w_d', bounds=(0.0, 1.0), resolution=0.01,
                           enforce_resolution=True)
        ps = ParameterSpace([v])
        pts = ps.sample(5, method='grid')
        # Should get exactly 5 values
        assert len(pts) == 5
        vals = [p['w_d'] for p in pts]
        # Each value should be on the 0.01 grid
        for val in vals:
            assert abs(val % 0.01) < 1e-9 or abs(val % 0.01 - 0.01) < 1e-9

    def test_discrete_grid_uses_all_values_when_grid_smaller_or_equal(self):
        """Grid sampling uses all discrete values when set size <= n
        (covers the else-branch of lines 329-334)."""
        # resolution=0.25 over [0,1] gives 5 discrete values; request n=10
        v = ModuleVariable('w_d', bounds=(0.0, 1.0), resolution=0.25,
                           enforce_resolution=True)
        ps = ParameterSpace([v])
        pts = ps.sample(10, method='grid')
        # discrete values are [0.0, 0.25, 0.50, 0.75, 1.0] → 5 points
        assert len(pts) == 5

    def test_discrete_grouped_random_values_on_grid(self, three_vars):
        """Grouped discrete vars in random sampling produce on-grid values
        (covers lines 248-250 with groups)."""
        w_n, w_p, l = three_vars
        # Make w_n discrete
        w_n_d = ModuleVariable('w_n', bounds=(0.5, 2.0), resolution=0.5,
                               enforce_resolution=True)
        w_p_d = ModuleVariable('w_p', bounds=(0.5, 2.0), resolution=0.5,
                               enforce_resolution=True)
        space = ParameterSpace([w_n_d, w_p_d, l], groups=[[w_n_d, w_p_d]])
        pts = space.sample(8, method='random')
        for p in pts:
            assert abs(p['w_n'] % 0.5) < 1e-9 or abs(p['w_n'] % 0.5 - 0.5) < 1e-9


# ---------------------------------------------------------------------------
# _scale_to_var LOG_UNIFORM with lo <= 0 raises (line 353)
# ---------------------------------------------------------------------------

class TestScaleToVarLogUniformError:

    def test_log_uniform_lo_zero_raises(self):
        """LOG_UNIFORM with bounds[0] == 0 raises ValueError in _scale_to_var
        (covers line 353)."""
        v = ModuleVariable('x', bounds=(0.0, 1.0),
                           distribution=Distribution.LOG_UNIFORM)
        ps = ParameterSpace([v])
        with pytest.raises(ValueError, match="LOG_UNIFORM"):
            ps.sample(5, method='lhs')

    def test_log_uniform_lo_negative_raises(self):
        """LOG_UNIFORM with bounds[0] < 0 raises ValueError."""
        v = ModuleVariable('x', bounds=(-1.0, 1.0),
                           distribution=Distribution.LOG_UNIFORM)
        ps = ParameterSpace([v])
        with pytest.raises(ValueError, match="LOG_UNIFORM"):
            ps.sample(5, method='sobol')
