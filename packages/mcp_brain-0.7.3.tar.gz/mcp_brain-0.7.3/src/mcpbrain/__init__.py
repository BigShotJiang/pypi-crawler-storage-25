"""MCP: Multi-agent Cognitive Processing Framework."""

__version__ = "0.7.3"
