"""MCP Core — orchestrates multi-agent cognitive processing (async)."""

import os
import json
import time
import uuid
import threading
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, AsyncIterator, List

from .minimax_client import MiniMaxClient, MiniMaxError
from .agents import CreatorAgent, CriticAgent, AnalystAgent
from .memory import WorkingMemory
from .tools import TOOL_REGISTRY
from .logging_config import log, new_correlation_id, get_correlation_id

import re

DEFAULT_CONFIG_PATH = Path("~/.mcp/config.json").expanduser()
DEFAULT_LOG_DIR = Path("~/.mcp/logs").expanduser()
DEFAULT_MEMORY_DIR = Path("~/.mcp/memory").expanduser()
DEFAULT_RESULTS_DIR = Path("~/.mcp/results").expanduser()


# ── Code file pre-loader ─────────────────────────────────────────────────────

_CODE_PATH_PATTERN = re.compile(
    r'(?:^|\s)((?:/~|/|./|\.\./)(?:[^\s\'"<>)]+(?:\.py|\.js|\.ts|\.jsx|\.tsx|\.json|\.yaml|\.yml|\.md|\.txt|\.sh|\.toml|\.cfg|\.ini|\.conf|\.html|\.css|\.sql|\.proto))+)',
    re.MULTILINE,
)


def _extract_file_paths(task: str) -> List[str]:
    """Return list of file/directory paths found in the task string."""
    paths: List[str] = []
    for m in _CODE_PATH_PATTERN.finditer(task):
        p = m.group(1).rstrip(')').rstrip('>')
        if p not in paths:
            paths.append(p)
    return paths


def _read_code_files(paths: List[str], max_lines_per_file: int = 500) -> str:
    """Read the given files and return a formatted code dump.

    Silently skips files that don't exist or can't be read.
    """
    if not paths:
        return ""

    out_lines: List[str] = []
    for raw_path in paths:
        p = Path(raw_path).expanduser()
        if not p.exists():
            continue
        if p.is_dir():
            # List directory contents instead of reading
            try:
                items = sorted(p.iterdir())
                out_lines.append(f"Directory: {p}")
                for item in items[:30]:
                    out_lines.append(f"  {item.name}{'/' if item.is_dir() else ''}")
                if len(items) > 30:
                    out_lines.append(f"  ... ({len(items) - 30} more)")
            except Exception:
                pass
            continue

        try:
            with open(p) as f:
                lines = f.readlines()
            total = len(lines)
            snippet = "".join(lines[:max_lines_per_file])
            out_lines.append(f"{'=' * 60}")
            out_lines.append(f"FILE: {p}")
            out_lines.append(f"{'=' * 60}")
            out_lines.append(snippet)
            if total > max_lines_per_file:
                out_lines.append(f"[... {total - max_lines_per_file} more lines truncated ...]")
            out_lines.append("")  # blank line after file
        except Exception:
            pass

    return "\n".join(out_lines)


def _build_code_context(task: str) -> str:
    """Build a CODE REFERENCE section from file paths found in the task.

    Returns an empty string if no recognizable code file paths are found.
    """
    paths = _extract_file_paths(task)
    if not paths:
        return ""
    content = _read_code_files(paths)
    if not content:
        return ""
    return f"""

{'=' * 60}
CODE REFERENCE — files read by MCP-brain before analysis
DO NOT describe any code pattern, class, or function you have not seen here.
{'=' * 60}
{content}
{'=' * 60}
END CODE REFERENCE
{'=' * 60}

"""

# ── Tool invocation parsers (sync — pure logic, no I/O) ──────────────────────

def _parse_local_tool(task: str) -> Optional[Dict[str, Any]]:
    """Detect if task is a local tool invocation and return the call spec."""
    task_stripped = task.strip()

    terminal_patterns = [
        r"^(?:run|execute|do)\s+.*?['\"](.+?)['\"]",
        r"^(?:run|execute)\s+(?:the\s+)?command\s+['\"](.+?)['\"]",
        r"^hermes\s+update",
    ]
    for pattern in terminal_patterns:
        m = re.match(pattern, task_stripped, re.IGNORECASE)
        if m:
            if pattern.startswith("^hermes"):
                return {"type": "tool_call", "name": "terminal", "arguments": {"command": task_stripped}}
            cmd = m.group(1)
            return {"type": "tool_call", "name": "terminal", "arguments": {"command": cmd}}

    read_patterns = [
        r"^(?:read|cat|view)\s+(?:the\s+)?file\s+[\"'](.+?)[\"']",
        r"^(?:read|cat|view)\s+[\"'](.+?)[\"']",
    ]
    for pattern in read_patterns:
        m = re.match(pattern, task_stripped, re.IGNORECASE)
        if m:
            return {"type": "tool_call", "name": "read_file", "arguments": {"path": m.group(1)}}

    write_match = re.match(
        r"^write\s+(?:to\s+)?(?:file\s+)?[\"'](.+?)[\"']\s*[:\n]\s*(.+)$",
        task_stripped, re.DOTALL | re.IGNORECASE,
    )
    if write_match:
        return {"type": "tool_call", "name": "write_file", "arguments": {"path": write_match.group(1), "content": write_match.group(2)}}

    search_match = re.match(
        r"^(?:search|google|look\s+up|find)\s+(?:the\s+)?(?:web\s+)?(?:for\s+)?[\"'](.+?)[\"']",
        task_stripped, re.IGNORECASE,
    )
    if search_match:
        return {"type": "tool_call", "name": "web_search", "arguments": {"query": search_match.group(1)}}

    git_match = re.match(r"^git\s+(.+)$", task_stripped, re.IGNORECASE)
    if git_match:
        return {"type": "tool_call", "name": "git_run", "arguments": {"command": git_match.group(1)}}

    return None


def _llm_tool_dispatch(
    task: str,
    functions: List[Dict[str, Any]],
    llm,
) -> Optional[Dict[str, Any]]:
    """Use the LLM to decide if any tool should be called."""
    try:
        func_map = {}
        for f in functions:
            name = f.get("function", {}).get("name") or f.get("name", "")
            if name:
                func_map[name] = f

        if not func_map:
            return None

        func_list = ", ".join(func_map.keys())
        dispatch_prompt = f"""Given the user task and available functions, determine if a function should be called.

Task: {task}
Available functions: {func_list}

Respond with ONLY a JSON object:
  {{"call": true, "name": "function_name", "arguments": {{...}}}}
  {{"call": false}}

If the task directly requests a function to be called, or clearly needs one, set call=true."""

        # Use the LLM's sync generate for quick dispatch (runs in thread)
        import requests
        session = requests.Session()
        session.headers.update(llm._client.headers if hasattr(llm, '_client') else {})
        # This is a lightweight call — just route, don't run the full pipeline
        return None  # Skip LLM dispatch for now — native tool calling handles it

    except Exception:
        pass
    return None


def _parse_tool_invocation(
    task: str,
    functions: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Detect slash-command tool invocations."""
    task_stripped = task.strip()
    func_map: Dict[str, Dict[str, Any]] = {}
    for f in functions:
        name = f.get("function", {}).get("name") or f.get("name", "")
        if name:
            func_map[name] = f

    slash_match = re.match(r"^/([\w\-]+)$", task_stripped)
    if slash_match:
        target = slash_match.group(1)
        if target in func_map:
            args = _infer_skill_args(target, func_map[target])
            if args:
                return {"type": "function_call", "name": target, "arguments": args}
        for fname, fdef in func_map.items():
            fname_lower = fname.lower()
            if "skill" in fname_lower and "view" in fname_lower:
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}
        target_norm = target.lower().replace("-", "").replace("_", "")
        for fname, fdef in func_map.items():
            if fname.lower().replace("-", "").replace("_", "") == target_norm:
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

    # Phrasal patterns
    phrasal = re.match(r"(?:read|use|load)\s+(?:the\s+)?(?:skill\s+)?[\"']?/([\w\-]+)[\"']?", task_stripped, re.IGNORECASE)
    if phrasal:
        target = phrasal.group(1)
        for fname, fdef in func_map.items():
            if "skill" in fname.lower() and "view" in fname.lower():
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

    quoted = re.match(r"use\s+(?:the\s+)?skill\s+[\"']([^\"']+)[\"']", task_stripped, re.IGNORECASE)
    if quoted:
        target = quoted.group(1)
        for fname, fdef in func_map.items():
            if "skill" in fname.lower() and "view" in fname.lower():
                args = _infer_skill_args(target, fdef)
                if args:
                    return {"type": "function_call", "name": fname, "arguments": args}

    return None


def _infer_skill_args(skill_name: str, func_def: Dict[str, Any]) -> Optional[Dict[str, str]]:
    """Infer arguments for a skill-related function call."""
    params = func_def.get("parameters", func_def.get("function", {}).get("parameters", {}))
    properties = params.get("properties", {})

    for pname, pschema in properties.items():
        if "skill" in pname.lower() or "name" in pname.lower():
            return {pname: skill_name}

    for pname, pschema in properties.items():
        if pschema.get("type", "string") == "string":
            return {pname: skill_name}

    return None


def _normalize_functions_to_tools(functions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Convert Hermes functions list to OpenAI tools format."""
    tools = []
    for f in functions:
        if f.get("type") == "function" and "function" in f:
            tools.append(f)
        elif "name" in f:
            tools.append({
                "type": "function",
                "function": {
                    "name": f["name"],
                    "description": f.get("description", ""),
                    "parameters": f.get("parameters", {}),
                }
            })
    return tools if tools else None


class MCP:
    """Multi-agent Cognitive Processing engine (async)."""

    _results: Dict[str, Optional[Dict[str, Any]]] = {}
    _results_lock = threading.Lock()

    def __init__(self, config_path: Optional[str] = None, skip_api_key_check: bool = False):
        self.config_path = Path(config_path or DEFAULT_CONFIG_PATH)
        self.log_dir = Path(DEFAULT_LOG_DIR)
        self.memory_dir = Path(DEFAULT_MEMORY_DIR)
        self.results_dir = Path(DEFAULT_RESULTS_DIR)

        self.config = self._load_config()
        self.session_id = str(uuid.uuid4())[:8]
        self.llm = None
        self.agents = {}

        for d in (self.log_dir, self.memory_dir, self.results_dir):
            d.mkdir(parents=True, exist_ok=True)

        api_key = self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY")
        if not api_key and not skip_api_key_check:
            raise ValueError("No API key configured. Run: mcp setup")

        if api_key:
            self.llm = MiniMaxClient(api_key)
            model = self.config.get("model", "MiniMax-M2.7")
            self.agents = {
                "creator": CreatorAgent(api_key, model=model),
                "critic": CriticAgent(api_key, model=model),
                "analyst": AnalystAgent(api_key, model=model),
            }

        self.memory = WorkingMemory(storage_path=str(self.memory_dir))

    def _load_config(self) -> Dict[str, Any]:
        if self.config_path.exists():
            with open(self.config_path) as f:
                return json.load(f)
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        default = {
            "api_key": "",
            "model": "MiniMax-M2.7",
            "max_tokens": 2000,
            "temperature": 0.7,
        }
        with open(self.config_path, "w") as f:
            json.dump(default, f, indent=2)
        return default

    def is_setup(self) -> bool:
        return bool(self.config.get("api_key") or os.environ.get("MINIMAX_API_KEY"))

    def setup(self, api_key: str, model: str = "MiniMax-M2.7") -> bool:
        self.config["api_key"] = api_key
        self.config["model"] = model
        with open(self.config_path, "w") as f:
            json.dump(self.config, f, indent=2)
        self.llm = MiniMaxClient(api_key)
        self.agents = {
            "creator": CreatorAgent(api_key, model=model),
            "critic": CriticAgent(api_key, model=model),
            "analyst": AnalystAgent(api_key, model=model),
        }
        return True

    @classmethod
    def get_result(cls, session_id: str) -> Optional[Dict[str, Any]]:
        with cls._results_lock:
            return cls._results.get(session_id)

    # ── Async cognitive pipeline ─────────────────────────────────────────────

    async def process_task_stream_async(
        self,
        task: str,
        functions: Optional[List[Dict[str, Any]]] = None,
    ) -> AsyncIterator[Dict[str, Any]]:
        """Run the cognitive pipeline with streaming (async).

        Yields step events:
            {"type": "start", "step": 1, "agent": "analyst", "task": "..."}
            {"type": "token", "agent": "analyst", "content": "..."}
            {"type": "step_done", "step": 1, "agent": "analyst", "response": "..."}
            {"type": "done", "session_id": "...", "duration_seconds": ...}
        """
        if not self.is_setup():
            yield {"type": "error", "message": "MCP not set up. Run: mcp setup"}
            return

        tools = None
        if functions:
            tools = _normalize_functions_to_tools(functions)

        # Always include internal tools (read_file, terminal, etc.) so agents
        # can read source files and execute commands — they complement, not replace,
        # any caller-supplied functions
        internal_schemas = _normalize_functions_to_tools(TOOL_REGISTRY.list())
        if tools:
            # Deduplicate by name — internal tools take priority
            existing_names = {t.get("function", {}).get("name") for t in tools}
            for schema in internal_schemas:
                name = schema.get("function", {}).get("name")
                if name not in existing_names:
                    tools.append(schema)
        else:
            tools = internal_schemas

        cid = new_correlation_id()
        start_time = time.time()
        step_num = 0

        log.info("mcp_pipeline_start", task=task[:100], session_id=self.session_id, correlation_id=cid)

        yield {
            "type": "start",
            "task": task,
            "session_id": self.session_id,
        }

        # ── Step 1: Analyst (always runs) ─────────────────────────────────────
        step_num = 1
        agent_name = "analyst"
        agent = self.agents[agent_name]
        accumulated = ""
        analysis_response = ""  # pre-init to prevent NameError if loop exits early
        complexity_detected = None

        # Pre-load code files mentioned in the task so agents can't hallucinate
        code_context = _build_code_context(task)

        yield {"type": "step_start", "step": step_num, "agent": agent_name}

        async for event in agent.process_async(task, code_context, tools=tools):
            if event["type"] == "start":
                pass
            elif event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
                if complexity_detected is None:
                    for comp in ("SIMPLE", "MODERATE", "COMPLEX"):
                        marker = f"[COMPLEXITY: {comp}]"
                        if marker in accumulated:
                            complexity_detected = comp
                            yield {"type": "complexity_detected", "complexity": comp}
                            log.info("mcp_complexity_detected", complexity=comp, session_id=self.session_id)
                            break
            elif event["type"] == "tool_call":
                # Agent now handles tool execution internally;
                # tool_call events should not reach here.
                pass
            elif event["type"] == "done":
                analysis_response = event["response"]
                if complexity_detected is None:
                    for comp in ("SIMPLE", "MODERATE", "COMPLEX"):
                        if f"[COMPLEXITY: {comp}]" in analysis_response:
                            complexity_detected = comp
                            break
                if complexity_detected is None:
                    complexity_detected = "COMPLEX"

                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": analysis_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": analysis_response}

        # ── Tier routing ───────────────────────────────────────────────────────
        if complexity_detected == "SIMPLE":
            duration = time.time() - start_time
            result = {
                "task": task,
                "session_id": self.session_id,
                "duration_seconds": round(duration, 2),
                "complexity": complexity_detected,
                "analysis": analysis_response or "(empty)",
                "solution": analysis_response or "(empty)",
                "evaluation": "SIMPLE task — answered directly by Analyst.",
            }
            with self.__class__._results_lock:
                self.__class__._results[self.session_id] = result
            self._save_session_log(task, result)
            log.info("mcp_pipeline_done", complexity="SIMPLE", duration_s=round(duration, 2), session_id=self.session_id)
            yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}
            return

        elif complexity_detected == "MODERATE":
            step_num = 2
            agent_name = "creator"
            agent = self.agents[agent_name]
            accumulated = ""
            creation_response = ""  # pre-init

            yield {"type": "step_start", "step": step_num, "agent": agent_name}
            async for event in agent.process_async(task, code_context + self.memory.get_context(), tools=tools):
                if event["type"] == "token":
                    accumulated += event["content"]
                    yield {"type": "token", "agent": agent_name, "content": event["content"]}
                elif event["type"] == "done":
                    creation_response = event["response"]
                    self.memory.add({
                        "agent_id": agent_name,
                        "role": agent.role,
                        "task": task,
                        "response": creation_response,
                        "timestamp": time.time(),
                    })
                    yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}

            duration = time.time() - start_time
            result = {
                "task": task,
                "session_id": self.session_id,
                "duration_seconds": round(duration, 2),
                "complexity": complexity_detected,
                "analysis": analysis_response or "(empty)",
                "solution": creation_response or "(empty)",
                "evaluation": "MODERATE task — resolved by Creator without critique rounds.",
            }
            with self.__class__._results_lock:
                self.__class__._results[self.session_id] = result
            self._save_session_log(task, result)
            log.info("mcp_pipeline_done", complexity="MODERATE", duration_s=round(duration, 2), session_id=self.session_id)
            yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}
            return

        # ── COMPLEX: full 5-step pipeline ──────────────────────────────────────
        # Step 2 — Creator generates first draft
        step_num = 2
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""
        creation_response = ""  # pre-init

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        async for event in agent.process_async(task, code_context + self.memory.get_context(), tools=tools):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                creation_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": creation_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": creation_response}

        # Step 3 — Critic evaluates
        step_num = 3
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""
        critique_response = ""  # pre-init

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        async for event in agent.process_async(task, code_context + self.memory.get_context(), tools=tools):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                critique_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": critique_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": critique_response}

        # Step 4 — Creator improves based on critique
        step_num = 4
        agent_name = "creator"
        agent = self.agents[agent_name]
        accumulated = ""
        improvement_response = ""  # pre-init

        improve_task = f"Improve your previous solution based on this criticism: {critique_response}"
        improve_context = _build_code_context(improve_task) or code_context

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        async for event in agent.process_async(improve_task, improve_context + self.memory.get_context(), tools=tools):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                improvement_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": improvement_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": improvement_response}

        # Step 5 — Critic final evaluation
        step_num = 5
        agent_name = "critic"
        agent = self.agents[agent_name]
        accumulated = ""
        final_response = ""  # pre-init

        final_task = f"Provide a final evaluation of this improved solution. Rate it and note any remaining issues: {improvement_response}"
        final_context = _build_code_context(final_task) or code_context

        yield {"type": "step_start", "step": step_num, "agent": agent_name}
        async for event in agent.process_async(final_task, final_context + self.memory.get_context(), tools=tools):
            if event["type"] == "token":
                accumulated += event["content"]
                yield {"type": "token", "agent": agent_name, "content": event["content"]}
            elif event["type"] == "done":
                final_response = event["response"]
                self.memory.add({
                    "agent_id": agent_name,
                    "role": agent.role,
                    "task": task,
                    "response": final_response,
                    "timestamp": time.time(),
                })
                yield {"type": "step_done", "step": step_num, "agent": agent_name, "response": final_response}

        duration = time.time() - start_time
        result = {
            "task": task,
            "session_id": self.session_id,
            "duration_seconds": round(duration, 2),
            "complexity": complexity_detected,
            "analysis": analysis_response or "(empty)",
            "solution": improvement_response or "(empty)",
            "evaluation": final_response or "(empty)",
        }
        with self.__class__._results_lock:
            self.__class__._results[self.session_id] = result
        self._save_session_log(task, result)
        log.info("mcp_pipeline_done", complexity="COMPLEX", duration_s=round(duration, 2), session_id=self.session_id)
        yield {"type": "done", "session_id": self.session_id, "duration_seconds": round(duration, 2), "complexity": complexity_detected}

    # ── Sync wrapper for CLI ─────────────────────────────────────────────────

    def process_task_stream(self, task: str, functions=None, extra_context: str = ""):
        """Sync wrapper — yields events from the async pipeline.

        Uses asyncio.run() in a separate thread to avoid event loop conflicts.
        """
        import concurrent.futures

        # Append extra context to the task for all downstream consumers
        if extra_context:
            task = f"{task}\n\n{extra_context}"

        def _run_in_thread():
            events = []
            async def _collect():
                async for event in self.process_task_stream_async(task, functions):
                    events.append(event)
            asyncio.run(_collect())
            return events

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(_run_in_thread)
            for event in future.result():
                yield event

    def process_task(self, task: str, verbose: bool = True, extra_context: str = "") -> Dict[str, Any]:
        """Run the adaptive cognitive pipeline (blocking, for CLI)."""
        result = None
        complexity = None
        for event in self.process_task_stream(task, extra_context=extra_context):
            if event["type"] == "complexity_detected" and verbose:
                print(f"[MCP] Complexity: {event['complexity']} — routing...", flush=True)
            elif event["type"] == "step_done" and verbose:
                role = event["agent"].capitalize()
                preview = event["response"][:80].replace("\n", " ")
                print(f"  [✓] {role}: {preview}...")
            elif event["type"] == "start" and verbose:
                print(f"[MCP] Task: {task}")
            elif event["type"] == "done" and verbose:
                comp = event.get("complexity", "")
                print(f"[MCP] Done in {event['duration_seconds']:.2f}s  complexity={comp}  session={event['session_id']}")

            if event["type"] == "done":
                result = self.get_result(event["session_id"])

        return result or {}

    # ── Background processing ────────────────────────────────────────────────────

    def process_task_background(self, task: str) -> str:
        """Start processing in a background thread. Returns session_id immediately."""
        session_id = self.session_id
        with self.__class__._results_lock:
            self.__class__._results[session_id] = None

        def run():
            brain = MCP(skip_api_key_check=True)
            brain.session_id = session_id
            brain.config = self.config
            brain.agents = {
                "creator": CreatorAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
                "critic": CriticAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
                "analyst": AnalystAgent(self.config.get("api_key"), model=self.config.get("model", "MiniMax-M2.7")),
            }
            brain.memory = WorkingMemory(storage_path=str(brain.memory_dir))
            for _ in brain.process_task_stream(task):
                pass

        thread = threading.Thread(target=run, daemon=True)
        thread.start()
        return session_id

    # ── Legacy helpers ──────────────────────────────────────────────────────────

    def _run_step(self, agent_name: str, task: str, context: str) -> Dict[str, Any]:
        """Run one agent step and store result in memory (blocking)."""
        agent = self.agents[agent_name]
        result = agent.process(task, context)
        self.memory.add(result)
        return result

    def _save_session_log(self, task: str, result: Dict[str, Any]) -> str:
        """Persist session to disk."""
        ts = time.strftime("%Y%m%d_%H%M%S")
        path = self.log_dir / f"session_{ts}_{self.session_id}.json"
        with open(path, "w") as f:
            json.dump({
                "task": task,
                "session_id": self.session_id,
                "timestamp": ts,
                "result": result,
            }, f, indent=2)
        return str(path)
