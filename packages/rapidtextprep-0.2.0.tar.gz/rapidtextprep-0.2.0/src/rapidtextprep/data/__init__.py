"""Package data for rapidtextprep."""
