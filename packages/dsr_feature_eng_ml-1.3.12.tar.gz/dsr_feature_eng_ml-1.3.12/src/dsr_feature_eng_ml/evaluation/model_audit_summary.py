"""Audit summary model and export utilities."""

from __future__ import annotations

import dataclasses
import inspect
import logging
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Mapping

import numpy as np
import pandas as pd
from cloudpathlib import AnyPath
from dsr_files.csv_handler import save_csv
from dsr_files.excel_handler import ExcelSheetConfig, save_excel
from dsr_files.joblib_handler import save_joblib
from dsr_files.json_handler import save_json
from dsr_files.utils import PathLike
from dsr_utils.enums import StringCase
from dsr_utils.formatting import (
    BoolFormat,
    BoolRepresentation,
    CurrencyFormat,
    CurrencySymbolPosition,
    DataFormat,
    DataScale,
    DateTimeFormat,
    EnumFormat,
    FloatFormat,
    FormatConfig,
    FormatType,
    IntegerFormat,
    NumericScale,
    PercentageFormat,
    StringFormat,
    TextAlignment,
    ValueDescFormat,
    format_as_grid,
    format_label_value_pairs,
)
from dsr_utils.strings import (
    convert_list_to_case,
    func_for_string_conv,
    to_original_string,
)

from dsr_feature_eng_ml.enums import ModelType, TaskType
from dsr_feature_eng_ml.models import ModelSpecification
from dsr_feature_eng_ml.prefs_instance import prefs

from .audit_pdf_renderer import AuditPDFRenderer
from .schema import DataSplits, FeatureMetadata, ModelConfiguration

if TYPE_CHECKING:
    from cloudpathlib import CloudPath
    from dsr_files.enums import FileType

# Constants for Anomaly Reporting
AUDIT_ANOMALY_ACTUAL_COL = "_audit_Actual"
AUDIT_ANOMALY_PREDICTED_COL = "_audit_Predicted"
AUDIT_ANOMALY_ABS_ERROR_COL = "_audit_Abs_Error"
AUDIT_ANOMALY_ACTUAL_COL_HEADER = "Actual"
AUDIT_ANOMALY_PREDICTED_COL_HEADER = "Predicted"
AUDIT_ANOMALY_ABS_ERROR_COL_HEADER = "Abs_Error"

logger = logging.getLogger(__name__)


def _coerce_format_config(
    value: FormatConfig | Mapping[str, Any] | None,
    fallback: FormatConfig,
) -> FormatConfig:
    """Normalize a formatter object or mapping into a FormatConfig instance."""
    if value is None:
        return fallback

    if isinstance(value, FormatConfig):
        return value

    if not isinstance(value, Mapping):
        logger.warning(
            "Unsupported formatter override %r (%s); using %s.",
            value,
            type(value).__name__,
            type(fallback).__name__,
        )
        return fallback

    cfg = dict(value)
    type_value = cfg.pop("type", cfg.pop("format_type", None))

    format_class_map: dict[str, type[FormatConfig]] = {
        "CurrencyFormat": CurrencyFormat,
        "PercentageFormat": PercentageFormat,
        "IntegerFormat": IntegerFormat,
        "FloatFormat": FloatFormat,
        "ValueDescFormat": ValueDescFormat,
        "DateTimeFormat": DateTimeFormat,
        "DataFormat": DataFormat,
        "StringFormat": StringFormat,
        "EnumFormat": EnumFormat,
        "BoolFormat": BoolFormat,
    }
    format_type_map: dict[FormatType, type[FormatConfig]] = {
        FormatType.CURRENCY: CurrencyFormat,
        FormatType.PERCENTAGE: PercentageFormat,
        FormatType.INTEGER: IntegerFormat,
        FormatType.FLOAT: FloatFormat,
        FormatType.VALUE_DESC: ValueDescFormat,
        FormatType.DATETIME: DateTimeFormat,
        FormatType.DATA: DataFormat,
        FormatType.STRING: StringFormat,
        FormatType.ENUM: EnumFormat,
        FormatType.BOOL: BoolFormat,
    }

    format_cls = type(fallback)
    if isinstance(type_value, str):
        format_cls = format_class_map.get(type_value, format_cls)
    elif isinstance(type_value, FormatType):
        format_cls = format_type_map.get(type_value, format_cls)

    enum_fields: dict[str, type[Enum]] = {
        "numeric_scale": NumericScale,
        "data_scale": DataScale,
        "alignment": TextAlignment,
        "currency_symbol_position": CurrencySymbolPosition,
        "bool_representation": BoolRepresentation,
    }
    for field_name, enum_cls in enum_fields.items():
        if field_name not in cfg:
            continue
        enum_value = cfg[field_name]
        if isinstance(enum_value, str):
            try:
                cfg[field_name] = enum_cls[enum_value]
            except KeyError:
                logger.warning(
                    "Invalid %s '%s' for %s; keeping raw value.",
                    field_name,
                    enum_value,
                    format_cls.__name__,
                )

    accepted = set(inspect.signature(format_cls.__init__).parameters)
    accepted.discard("self")
    kwargs = {k: v for k, v in cfg.items() if k in accepted}

    try:
        return format_cls(**kwargs)
    except Exception:
        logger.exception(
            "Unable to build %s from mapping %s; using %s.",
            format_cls.__name__,
            value,
            type(fallback).__name__,
        )
        return fallback


class ModelAuditSummary:
    """
    Aggregate audit results, metrics, and export helpers.

    Acts as the primary data model for the final audit report, capturing
    performance across all models, anomaly context, and data distribution stats.
    """

    @dataclass
    class ModelPredictions:
        """Container for validation/test predictions and probabilities."""

        preds_val: pd.Series | None = None
        probs_val: pd.DataFrame | None = None
        preds_test: pd.Series | None = None
        probs_test: pd.DataFrame | None = None

    # --- Internal Attribute Declarations ---
    _features_to_fit_set: set[FeatureMetadata]
    _results: list[ModelConfiguration]
    _row_loss_pct: float = 0.0

    # --- Properties ---
    # Using public attributes for these reduces boilerplate while maintaining V1.2.0 style

    @property
    def random_state(self) -> int | None:
        """Return random state from splits or global preferences."""
        return self.data_splits.random_state if self.data_splits else prefs.random_state

    @property
    def row_loss_pct(self) -> float:
        """Percentage of rows lost during preprocessing."""
        return self._row_loss_pct

    @row_loss_pct.setter
    def row_loss_pct(self, val: float) -> None:
        """Allow manual or computed updates to row loss percentage."""
        self._row_loss_pct = float(val)

    def __init__(
        self,
        data_splits: DataSplits,
        results: list[ModelConfiguration] | None = None,
        audit_timestamp: str = "",
        dataset_name: str = "Unknown Dataset",
        original_row_count: int = 0,
        cleaned_row_count: int = 0,
        dropped_row_count: int = 0,
        train_row_count: int = 0,
        val_row_count: int = 0,
        test_row_count: int = 0,
        top_n_importance: int = 1,
        count_numeric_scale: NumericScale = NumericScale.AUTO,
        pdf_feature_importance_chart_limit: int = 12,
        anomaly_table_max_columns: int | None = None,
        anomaly_table_show_notes: bool = True,
        duration: float = 0.0,
        features: dict[str, FeatureMetadata] | None = None,
        top_n_anomalies: int = 5,
        anomaly_display_map: dict[str, str] | None = None,
        actual_value_fmt: FormatConfig | None = None,
        predicted_value_fmt: FormatConfig | None = None,
        abs_error_fmt: FormatConfig | None = None,
        error_pct_fmt: FormatConfig | None = None,
        anomaly_data: pd.DataFrame | None = None,
        anomaly_dynamic_features: list[str] | None = None,
        anomaly_threshold: float = prefs.anomaly_threshold,
        anomaly_risk_concentration_threshold: float = prefs.anomaly_risk_concentration_threshold,
        model_accuracy_limit: float = prefs.model_accuracy_limit,
        model_acceptable_limit: float = prefs.model_acceptable_limit,
        model_stability_limit: float = prefs.model_stability_limit,
        model_efficiency_threshold: int = prefs.model_efficiency_threshold,
        drift_threshold: float = prefs.drift_threshold,
    ) -> None:
        """Initialize the audit summary container."""
        self.data_splits = data_splits
        self.results = results or []
        self.dataset_name = dataset_name
        self.original_row_count = original_row_count
        self.cleaned_row_count = cleaned_row_count
        self.dropped_row_count = dropped_row_count
        self.train_row_count = train_row_count
        self.val_row_count = val_row_count
        self.test_row_count = test_row_count
        self.processed_row_count = train_row_count + val_row_count
        self.top_n_importance = top_n_importance
        self.count_numeric_scale = count_numeric_scale
        self.pdf_feature_importance_chart_limit = int(
            pdf_feature_importance_chart_limit
        )
        self.anomaly_table_max_columns = (
            int(anomaly_table_max_columns)
            if anomaly_table_max_columns is not None
            else None
        )
        self.anomaly_table_show_notes = bool(anomaly_table_show_notes)
        self.duration = duration
        self.features = features or {}
        self.top_n_anomalies = top_n_anomalies
        self.anomaly_display_map = anomaly_display_map or {}
        self.actual_value_fmt = _coerce_format_config(actual_value_fmt, StringFormat())
        self.predicted_value_fmt = _coerce_format_config(
            predicted_value_fmt, StringFormat()
        )
        self.abs_error_fmt = _coerce_format_config(abs_error_fmt, FloatFormat())
        self.error_pct_fmt = _coerce_format_config(error_pct_fmt, FloatFormat())
        self.anomaly_data = anomaly_data
        self.anomaly_dynamic_features = anomaly_dynamic_features or []
        self.anomaly_threshold = anomaly_threshold
        self.anomaly_risk_concentration_threshold = anomaly_risk_concentration_threshold
        self.model_accuracy_limit = model_accuracy_limit
        self.model_acceptable_limit = model_acceptable_limit
        self.model_stability_limit = model_stability_limit
        self.model_efficiency_threshold = model_efficiency_threshold
        self.drift_threshold = drift_threshold

        # Initialize Audit Timestamp
        if not audit_timestamp:
            ts_fmt = DateTimeFormat(
                date_format="%Y%m%d", time_format="%H%M%S", separator="_"
            )
            self.audit_timestamp = ts_fmt.format_value(datetime.now())
        else:
            self.audit_timestamp = audit_timestamp

        # Sort features for consistent reporting
        self.features_used = sorted(
            list(self.features.values()), key=lambda fm: fm.name.lower()
        )

        self.solid_color_palette = prefs.get_solid_palette()
        self.light_color_palette = prefs.get_light_palette()

        # Internal state initialization
        self._init_features_to_fit_set()

    def _init_features_to_fit_set(self) -> None:
        """Initialize the features-to-fit set, expanding OHE columns where needed.

        Replicates the OHE-expansion logic from ``ModelAuditor._resolve_features_to_fit_set``
        so that a restored snapshot produces the same expanded column names that were
        used during training (e.g. ``DOLocationID_71`` instead of ``DOLocationID``).
        """
        target_column = self.data_splits.target_column
        available_columns = self.data_splits.train_features.columns
        available_set = set(available_columns)

        resolved: set[FeatureMetadata] = set()

        for feature in self.features.values():
            if not feature.is_used_in_fit or feature.name == target_column:
                continue

            if feature.name in available_set:
                resolved.add(feature)
                continue

            encoded_columns = sorted(
                col for col in available_columns if col.startswith(f"{feature.name}_")
            )
            for i, encoded_col in enumerate(encoded_columns, start=1):
                resolved.add(
                    FeatureMetadata(
                        name=encoded_col,
                        id=f"{feature.id}_{i:02d}",
                        position=available_columns.tolist().index(encoded_col),
                        short_name=feature.short_name,
                        formatter=feature.formatter,
                        description=feature.description,
                        is_used_in_fit=True,
                        parent_name=feature.name,
                    )
                )

        if resolved:
            self._features_to_fit_set = resolved
            return

        self._features_to_fit_set = FeatureMetadata.dict_to_set(
            feature_dict=self.features,
            target_column=target_column,
        )

    def resolve_feature(self, col_name: str) -> FeatureMetadata | None:
        """Look up FeatureMetadata by name, falling back to parent for OHE columns.

        When one-hot encoding produces columns like ``DOLocationID_71``, this
        method finds the parent ``DOLocationID`` entry so formatters and short
        names are available even for encoded variants.
        """
        if col_name in self.features:
            return self.features[col_name]
        for key in self.features:
            if col_name.startswith(f"{key}_"):
                return self.features[key]
        return None

    @property
    def features_to_fit_set(self) -> set[FeatureMetadata]:
        """Set of features eligible for model fitting."""
        return self._features_to_fit_set

    def __setstate__(self, state: dict[str, Any]) -> None:
        """
        Restore state from a serialized snapshot.

        Prediction artifacts are no longer recomputed eagerly on unpickle.
        This keeps snapshot reload cheap for operations like export
        regeneration that only need persisted summary metadata.
        """
        self.__dict__.update(state)

        if "pdf_feature_importance_chart_limit" not in self.__dict__:
            self.pdf_feature_importance_chart_limit = 12
        if "count_numeric_scale" not in self.__dict__:
            self.count_numeric_scale = NumericScale.AUTO
        if "anomaly_table_max_columns" not in self.__dict__:
            self.anomaly_table_max_columns = None
        if "anomaly_table_show_notes" not in self.__dict__:
            self.anomaly_table_show_notes = True

        # Ensure feature set is initialized after state restoration.
        self._init_features_to_fit_set()

    def _hydrate_prediction_artifacts_for_config(
        self,
        config: ModelConfiguration,
        include_test: bool = True,
    ) -> ModelConfiguration:
        """
        Recompute missing prediction artifacts for a single configuration.

        Persisted scalar metrics are preserved; only missing prediction and
        probability outputs are backfilled.
        """
        needs_val = config.has_val_set_evaluation_scores and config.preds_val is None
        needs_test = (
            include_test
            and config.has_test_set_evaluation_scores
            and config.preds_test is None
        )
        if not (needs_val or needs_test):
            return config

        print(f"Hydrating prediction artifacts: {config.model_type.name}")
        model_spec = ModelSpecification.create_model_from_config(config)
        if model_spec is None:
            return config

        current_cfg = config

        if needs_val:
            val_res = model_spec.fit_and_evaluate_val(
                data_splits=self.data_splits,
                id=config.id,
                features_to_fit_set=self.features_to_fit_set,
                score_cv=config.score_cv,
                use_combined_data=config.use_combined_data,
                filter_outliers=config.filter_outliers,
                outlier_count=config.outlier_count,
            )
            current_cfg = dataclasses.replace(
                current_cfg,
                preds_val=val_res.preds_val,
                probs_val=val_res.probs_val,
            )

        if needs_test:
            test_res = model_spec.evaluate_test_set_performance(
                data_splits=self.data_splits,
                config=current_cfg,
                features_to_fit_set=self.features_to_fit_set,
            )
            current_cfg = dataclasses.replace(
                current_cfg,
                preds_test=test_res.preds_test,
                probs_test=test_res.probs_test,
            )

        return current_cfg

    def hydrate_missing_prediction_artifacts(self, include_test: bool = True) -> None:
        """
        Recompute missing prediction artifacts for all loaded configurations.

        Parameters
        ----------
        include_test : bool, default True
            If True, backfill both validation and test prediction artifacts.
            If False, only validation artifacts are hydrated.
        """
        self.results = [
            self._hydrate_prediction_artifacts_for_config(
                config,
                include_test=include_test,
            )
            for config in self.results
        ]

    def ensure_anomaly_context(self) -> None:
        """
        Ensure anomaly context is available for export/reporting.

        Most modern snapshots already persist anomaly data. Older snapshots may
        require the winning model's validation predictions to be rehydrated
        before anomaly context can be reconstructed.
        """
        if self.anomaly_data is not None:
            return
        if not self.results:
            return

        best_config = self.best_overall_model
        if best_config is None:
            return

        for index, config in enumerate(self.results):
            if config is best_config:
                self.results[index] = self._hydrate_prediction_artifacts_for_config(
                    config,
                    include_test=False,
                )
                break

        self.capture_anomaly_context()

    @classmethod
    def from_joblib(cls, filepath: Path) -> ModelAuditSummary:
        """
        Load a saved audit summary from a joblib file.

        Parameters
        ----------
        filepath : Path
            The location of the .joblib file.

        Returns
        -------
        ModelAuditSummary
            The hydrated summary instance.
        """
        from dsr_files.joblib_handler import load_joblib

        print(f"Loading audit snapshot: {filepath}")
        loaded_data, _ = load_joblib(filepath=filepath)

        if not isinstance(loaded_data, cls):
            raise TypeError(
                f"File at {filepath} contains {type(loaded_data)}, "
                f"expected {cls.__name__}"
            )

        stem = filepath.stem
        if stem.startswith("Audit_State_"):
            loaded_data.audit_timestamp = stem.removeprefix("Audit_State_")

        return loaded_data

    def add_model_configuration(self, config: ModelConfiguration) -> None:
        """Append a completed model configuration to the results list."""
        self.results.append(config)

        # Emit a compact progress signal so callers can distinguish between
        # model loop completion and later summary/export processing.
        logger.info(
            "Recorded model result #%s: %s (val=%s)",
            len(self.results),
            config.model_type.name,
            (
                prefs.score_format.format_value(config.score_val)
                if config.score_val is not None
                else "N/A"
            ),
        )

    @property
    def best_overall_model(self) -> ModelConfiguration | None:
        """
        Return the highest scoring model based on ModelConfiguration sorting.
        """
        if not self.results:
            return None
        # Uses the __lt__ implementation from ModelConfiguration
        return max(self.results)

    def _calculate_row_counts(self) -> None:
        """Derive row counts and data loss metrics from current splits."""
        ds = self.data_splits
        self.train_row_count = len(ds.train_features)
        self.val_row_count = len(ds.val_features)
        self.test_row_count = len(ds.test_features)

        self.processed_row_count = self.train_row_count + self.val_row_count
        self.cleaned_row_count = self.processed_row_count + self.test_row_count

        self.dropped_row_count = ds.original_row_count - self.cleaned_row_count

        if ds.original_row_count > 0:
            self.row_loss_pct = (self.dropped_row_count / ds.original_row_count) * 100
        else:
            self.row_loss_pct = 0.0

    def get_state(self, include_preds: bool = False) -> dict[str, Any]:
        """
        Export the full audit snapshot as a serializable dictionary.

        Parameters
        ----------
        include_preds : bool, default False
            If True, converts large prediction arrays into lists for the export.

        Returns
        -------
        dict[str, Any]
            A nested dictionary of metadata, aggregate stats, and per-model results.
        """
        if include_preds:
            self.hydrate_missing_prediction_artifacts()
        else:
            self.ensure_anomaly_context()

        # Calculate aggregate compute metrics
        total_cpu = sum(res.total_duration for res in self.results)
        max_ram = max((res.actual_peak_gb for res in self.results), default=0.0)
        total_fits = sum(res.num_candidates * res.cv for res in self.results)

        # Calculate average efficiency (rows/sec) safely
        eff_list = [
            res.efficiency(data_splits=self.data_splits) for res in self.results
        ]
        valid_eff = [e for e in eff_list if e > 0]
        avg_efficiency = float(np.mean(valid_eff)) if valid_eff else 0.0

        return {
            "metadata": {
                "timestamp": self.audit_timestamp,
                "dataset_name": self.dataset_name,
                "duration_seconds": self.duration,
                "count_numeric_scale": self.count_numeric_scale.name,
                "row_counts": {
                    "train": self.train_row_count,
                    "val": self.val_row_count,
                    "test": self.test_row_count,
                    "original": self.original_row_count,
                    "cleaned": self.cleaned_row_count,
                    "dropped": self.dropped_row_count,
                    "row_loss_pct": self.row_loss_pct,
                    "processed": self.processed_row_count,
                },
                "anomalies": {
                    "threshold": self.anomaly_threshold,
                    "display_map": self.anomaly_display_map,
                    "top_n": self.top_n_anomalies,
                    "dynamic_features": self.anomaly_dynamic_features,
                    "formats": {
                        "actual": self.actual_value_fmt.to_dict(),
                        "predicted": self.predicted_value_fmt.to_dict(),
                        "abs_error": self.abs_error_fmt.to_dict(),
                    },
                    # DataFrame conversion to list of records for JSON
                    "data": (
                        self.anomaly_data.to_dict(orient="records")
                        if self.anomaly_data is not None
                        else []
                    ),
                },
                "aggregate_stats": {
                    "total_cpu_time": total_cpu,
                    "peak_ram_gb": max_ram,
                    "total_cv_fits": total_fits,
                    "avg_rows_per_sec": avg_efficiency,
                },
                "model_limits": {
                    "accuracy_min": self.model_accuracy_limit,
                    "acceptable_min": self.model_acceptable_limit,
                    "stability_min": self.model_stability_limit,
                    "efficiency_min": self.model_efficiency_threshold,
                },
                "features": {k: f.to_dict() for k, f in self.features.items()},
            },
            "results": [
                res.to_dict(include_preds=include_preds) for res in self.results
            ],
        }

    def create_metadata(self) -> None:
        """
        Compute and finalize metadata describing the audit dataset and results.

        This method synchronizes row counts, loss percentages, and feature sets
        to ensure all reporting properties are accurate before export.
        """
        # 1. Update features-to-fit set in case metadata was added late
        self._init_features_to_fit_set()

        # 2. Recalculate row counts and data loss metrics
        # This handles the row_loss_pct assignment through the @setter logic
        self._calculate_row_counts()

        # 3. Guard against early calls before models have finished
        if len(self.results) == 0:
            return

    def capture_anomaly_context(self) -> None:
        """
        Identify anomalous rows and high-kurtosis features for audit context.

        Analyzes the best-performing model to extract anomalies and identifies
        features with the most extreme distributions to aid in error analysis.
        For regression, anomalies are rows whose absolute residual exceeds the
        ``anomaly_threshold`` percentile. For classification, anomalies are
        misclassified rows.
        """
        config = self.best_overall_model
        if config is None:
            return

        # 1. Calculate Absolute Errors
        y_val = self.data_splits.val_target
        preds_val = (
            config.preds_val
            if config.preds_val is not None
            else pd.Series(dtype="float64")
        )

        # Flatten and align to ensure matching indices.
        if config.task_type == TaskType.CLASSIFICATION:
            y_aligned = y_val.to_numpy().flatten().astype(str)
            p_aligned = preds_val.to_numpy().flatten().astype(str)
            abs_errors = (y_aligned != p_aligned).astype(np.float64)

            # For classification, anomalies are misclassifications.
            anomaly_mask = abs_errors > 0.0
        else:
            abs_errors = np.abs(
                y_val.to_numpy().flatten() - preds_val.to_numpy().flatten()
            )

            # 2. Extract Anomaly Mask
            # We use a percentile-based threshold (e.g., top 5% of errors).
            threshold = np.percentile(abs_errors, self.anomaly_threshold)
            anomaly_mask = abs_errors >= threshold

        # 3. Build Anomaly DataFrame (Inverting Scaling for Readability)
        anomalies_scaled = self.data_splits.val_features.iloc[anomaly_mask].copy()
        anomalies = self.data_splits.inverse_transform_df(anomalies_scaled)

        anomalies[AUDIT_ANOMALY_ACTUAL_COL] = y_val.iloc[anomaly_mask].values
        anomalies[AUDIT_ANOMALY_PREDICTED_COL] = preds_val.iloc[anomaly_mask].values
        anomalies[AUDIT_ANOMALY_ABS_ERROR_COL] = abs_errors[anomaly_mask]

        # 4. Identify High-Kurtosis Features (Dynamic Context)
        # Only numeric columns support kurtosis calculations
        numeric_df = self.data_splits.val_features.select_dtypes(include=[np.number])
        dynamic_features = (
            numeric_df
            .kurt()
            .sort_values(ascending=False)
            .index[: self.top_n_importance]
            .tolist()
        )

        # 5. Store Results Sorted by Error Magnitude
        self.anomaly_data = anomalies.sort_values(
            AUDIT_ANOMALY_ABS_ERROR_COL, ascending=False
        )
        self.anomaly_dynamic_features = dynamic_features

    def get_summary_data(
        self,
        config: ModelConfiguration,
        key_case: StringCase = StringCase.ORIGINAL,
    ) -> dict[str, Any]:
        """
        Build a flat summary record for a single model configuration.

        Parameters
        ----------
        config : ModelConfiguration
            The specific run to summarize.
        key_case : StringCase, default ORIGINAL
            The casing convention to apply to the dictionary keys.
        """
        # Ensure scores are non-null for the summary
        train_s = config.score_train or 0.0
        val_s = config.score_val or 0.0
        clean_s = config.score_val_cleaned or 0.0

        # Mapping key display labels
        keys = [
            "ID",
            "Model",
            "Strategy",
            "Available RAM",
            "Est Peak RAM",
            "Actual Peak RAM",
            "Memory Risk",
            "Sampling %",
            "n_jobs",
            "Val Score",
            "Cleaned Score",
            "Duration",
            "Efficiency",
            "Train Score",
            "Gap",
            "Status",
            "Train Mean",
            "Train Std",
            "Train Median",
            "Train Skew",
            "Train Kurt",
            "Val Mean",
            "Val Std",
            "Val Median",
            "Val Skew",
            "Val Kurt",
            "Mean Delta",
            "Std Delta",
            "Quality Score",
            "Drift Index",
        ]

        # Apply casing transformation
        if key_case != StringCase.ORIGINAL:
            keys = convert_list_to_case(keys, key_case)
            conv_f = func_for_string_conv(key_case)
        else:
            conv_f = to_original_string

        values = [
            config.id,
            conv_f(config.model_type.value),
            conv_f(config.balancing_strategy.value),
            config.available_gb,
            config.estimated_peak_gb,
            config.actual_peak_gb,
            config.memory_risk_triggered,
            config.sampling_factor,
            config.concurrent_workers,
            val_s,
            clean_s,
            config.total_duration,
            config.efficiency(self.data_splits),
            train_s,
            config.gap,
            conv_f(config.model_generalization.value),
            config.train_mean,
            config.train_std,
            config.train_median,
            config.train_skew,
            config.train_kurtosis,
            config.val_mean,
            config.val_std,
            config.val_median,
            config.val_skew,
            config.val_kurtosis,
            config.mean_delta,
            config.std_delta,
            config.quality_score,
            config.drift_index,
        ]

        return dict(zip(keys, values))

    def get_leaderboard(self) -> str:
        """Generate the console-friendly leaderboard summary."""
        state = self.get_state(include_preds=False)
        meta = state["metadata"]
        counts = meta["row_counts"]

        i_fmt = IntegerFormat()
        dur_fmt = DateTimeFormat(use_duration_format=True)
        ram_fmt = DataFormat(
            data_scale=DataScale.GB, precision=2, include_space_before_scale=True
        )

        duration_seconds = float(meta["duration_seconds"])
        peak_ram_val = float(meta["aggregate_stats"]["peak_ram_gb"])

        # `peak_ram_gb` is stored in GB; convert to bytes for DataFormat,
        # which handles scaling when configured with DataScale.GB.
        peak_ram_bytes = peak_ram_val * DataScale.GB.get_size()

        # 1. Build Metadata Header
        header_pairs = [
            ("Timestamp", meta["timestamp"]),
            ("Dataset", meta["dataset_name"]),
            (
                "Rows (T/V/Te)",
                f"{i_fmt.format_value(counts['train'])} / "
                f"{i_fmt.format_value(counts['val'])} / "
                f"{i_fmt.format_value(counts['test'])}",
            ),
            ("Duration", dur_fmt.format_value(duration_seconds)),
            ("Peak RAM", ram_fmt.format_value(peak_ram_bytes)),
        ]

        grid_pad = max((len(f.name) for f in self.features_used), default=10) + 4
        feat_grid = format_as_grid(
            input=[f.name for f in self.features_used],
            cols=3,
            padding=grid_pad,
            indent=4,
        )

        header = (
            f"\n{'=' * prefs.report_width}\n"
            f"AUDIT SNAPSHOT: {self.dataset_name}\n"
            f"{'-' * prefs.report_width}\n"
            f"{format_label_value_pairs(header_pairs, padding=4)}\n"
            f"Features Analyzed:\n{feat_grid}\n"
            f"{'-' * prefs.report_width}\n"
        )

        # 2. Build Results Table
        summary_list = [self.get_summary_data(cfg) for cfg in self.results]
        df = pd.DataFrame(summary_list).sort_values("Val Score", ascending=False)

        # Truncate columns for console display to prevent wrapping
        display_cols = [
            "ID",
            "Model",
            "Val Score",
            "Cleaned Score",
            "Gap",
            "Status",
            "Efficiency",
        ]
        return (
            header
            + df[display_cols].to_string(index=False)
            + f"\n{'=' * prefs.report_width}\n"
        )

    def get_best_by_type(self, model_type: ModelType) -> ModelConfiguration | None:
        """
        Retrieve the highest-scoring configuration for a specific model type.

        Parameters
        ----------
        model_type : ModelType
            The specific architecture to filter for (e.g., ModelType.RANDOM_FOREST).

        Returns
        -------
        ModelConfiguration | None
            The top-performing instance of that type, or None if not found.
        """
        # Filter results for the requested type
        typed_results = [r for r in self.results if r.model_type == model_type]

        if not typed_results:
            return None

        # Returns the max based on ModelConfiguration's __lt__ (score_val)
        return max(typed_results)

    def _extract_preds_and_probs(self) -> list[ModelPredictions]:
        """
        Detach prediction/probability arrays from results for memory-safe serialization.

        Returns
        -------
        list[ModelPredictions]
            A list of prediction containers aligned index-for-index with the results list.
        """
        new_results: list[ModelConfiguration] = []
        model_predictions: list[ModelAuditSummary.ModelPredictions] = []

        for config in self.results:
            # 1. Capture the arrays in the side-car container
            model_predictions.append(
                ModelAuditSummary.ModelPredictions(
                    preds_val=config.preds_val,
                    probs_val=config.probs_val,
                    preds_test=config.preds_test,
                    probs_test=config.probs_test,
                )
            )

            # 2. Clear the arrays from the main config to reduce object size
            new_results.append(
                dataclasses.replace(
                    config,
                    preds_val=None,
                    probs_val=None,
                    preds_test=None,
                    probs_test=None,
                )
            )

        self.results = new_results
        return model_predictions

    def _restore_preds_and_probs(
        self, model_predictions: list[ModelPredictions]
    ) -> None:
        """
        Reattach prediction/probability arrays to results after serialization tasks.

        Parameters
        ----------
        model_predictions : list[ModelPredictions]
            The list of prediction containers to re-merge into the results.
        """
        # Ensure we are iterating based on the current results length to maintain alignment
        new_results: list[ModelConfiguration] = []

        for index, config in enumerate(self.results):
            # We use index-based lookup to match the 'side-car' list back to the configs
            pred_set = model_predictions[index]

            new_results.append(
                dataclasses.replace(
                    config,
                    preds_val=pred_set.preds_val,
                    probs_val=pred_set.probs_val,
                    preds_test=pred_set.preds_test,
                    probs_test=pred_set.probs_test,
                )
            )

        self.results = new_results

    def _export_fitted_models(
        self,
        output_dir: PathLike,
        filename: str,
        fitted_models: Mapping[str, Any],
    ) -> Path | CloudPath:
        """Export per-model fitted estimator bundles and a manifest file."""
        model_output_dir = AnyPath(output_dir) / "models"
        model_output_dir.mkdir(parents=True, exist_ok=True)

        model_records: list[dict[str, Any]] = []
        best_id = (
            self.best_overall_model.id if self.best_overall_model is not None else None
        )

        for config in self.results:
            estimator = fitted_models.get(config.id)
            if estimator is None:
                raise RuntimeError(
                    "MODEL export requested but no fitted estimator was provided "
                    f"for model id '{config.id}'."
                )
            if not callable(getattr(estimator, "predict", None)):
                raise RuntimeError(
                    f"Fitted estimator for model id '{config.id}' does not expose predict()."
                )

            model_slug = "".join(
                c.lower() if c.isalnum() else "_" for c in config.model_type.value
            ).strip("_")
            artifact_stem = f"{filename}_{config.id}_{model_slug}_model"

            artifact_payload = {
                "audit_timestamp": self.audit_timestamp,
                "dataset_name": self.dataset_name,
                "model_id": config.id,
                "model_type": config.model_type.name,
                "task_type": config.task_type.name,
                "scoring": config.scoring.name,
                "model_params": config.params_dict,
                "estimator": estimator,
            }
            artifact_path, _ = save_joblib(
                artifact_payload, model_output_dir, artifact_stem
            )

            model_records.append({
                "model_id": config.id,
                "model_type": config.model_type.name,
                "score_val": config.score_val,
                "score_cv": config.score_cv,
                "score_test": config.score_test,
                "is_best": config.id == best_id,
                "artifact_path": str(artifact_path),
            })

        manifest = {
            "metadata": {
                "audit_id": f"{filename}",
                "audit_timestamp": self.audit_timestamp,
                "dataset_name": self.dataset_name,
                "exported_models": len(model_records),
                "best_model_id": best_id,
            },
            "models": model_records,
        }

        manifest_path, _ = save_json(
            manifest, model_output_dir, f"{filename}_model_artifacts_manifest"
        )
        return manifest_path

    def export_results(
        self,
        prefix: str,
        file_type: FileType,
        path: PathLike,
        path_is_full_path: bool = False,
        append_timestamp_to_save_path: bool = False,
        report_title: str = "Model Audit Report",
        fitted_models: Mapping[str, Any] | None = None,
    ) -> Path | CloudPath:
        """
        Export audit results to CSV, JSON, JOBLIB, Excel, or PDF.

        Parameters
        ----------
        prefix : str
            Filename prefix (e.g., "Audit_State").
        file_type : FileType
            A single FileType or bitmask of types to generate.
        path : PathLike
            Output directory or full file path.
        path_is_full_path : bool, default False
            If True, treats 'path' as the final destination file.
        append_timestamp_to_save_path : bool, default False
            Append audit timestamp to the output directory.
        report_title : str, default "Model Audit Report"
            The title applied to PDF/Excel report headers.
        fitted_models : Mapping[str, Any], optional
            Mapping of model id to fitted estimator. Required when
            ``FileType.MODEL`` is requested.

        Returns
        -------
        Path | CloudPath
            The path to the primary file generated.
        """
        from dsr_files.enums import FileType
        from dsr_files.json_handler import to_JSON_safe

        # 1. Resolve Pathing and Filenames
        if not path_is_full_path:
            output_dir = AnyPath(path)
            if append_timestamp_to_save_path:
                output_dir = output_dir / self.audit_timestamp
            filename = f"{prefix}_{self.audit_timestamp}"
        else:
            full_path_obj = AnyPath(path)
            output_dir = full_path_obj.parent
            filename = full_path_obj.stem

        output_dir.mkdir(parents=True, exist_ok=True)
        full_path = Path()

        # 2. Prepare Payload (Lightweight for JSON/CSV/Excel)
        export_payload = self.get_state(include_preds=False)
        metadata = export_payload["metadata"]
        anomalies = metadata["anomalies"]

        # Flattened metadata for tabular exports (CSV/Excel)
        meta_flat = {
            "audit_id": f"{prefix}_{self.audit_timestamp}",
            "timestamp": metadata["timestamp"],
            **metadata["row_counts"],
            **metadata["aggregate_stats"],
            "features_json": to_JSON_safe(metadata["features"]),
        }

        # --- CSV Export Logic ---
        if FileType.CSV in file_type:
            # Metadata Summary
            save_csv(
                pd.DataFrame(list(meta_flat.items())),
                output_dir,
                f"{filename}_metadata",
                header=False,
            )

            # Anomaly Context
            save_csv(
                pd.DataFrame([anomalies["display_map"]]),
                output_dir,
                f"{filename}_anomaly_map",
                header=False,
            )
            save_csv(
                pd.DataFrame(anomalies["data"]), output_dir, f"{filename}_anomaly_data"
            )
            save_csv(
                pd.DataFrame([anomalies["dynamic_features"]]),
                output_dir,
                f"{filename}_dynamic_features",
                header=False,
            )

            # Main Results (Leaderboard)
            full_path, _ = save_csv(
                pd.DataFrame(export_payload["results"]), output_dir, filename
            )

        # --- JSON Export Logic ---
        if FileType.JSON in file_type:
            full_path, _ = save_json(export_payload, output_dir, filename)

        # --- JOBLIB Export Logic (Full State) ---
        if FileType.JOBLIB in file_type:
            # Extract large arrays to optimize disk write, then restore
            preds_sidecar = self._extract_preds_and_probs()
            full_path, _ = save_joblib(self, output_dir, filename)
            self._restore_preds_and_probs(preds_sidecar)

        # --- EXCEL Export Logic ---
        if FileType.EXCEL in file_type:
            sheets = [
                ExcelSheetConfig(
                    pd.DataFrame(list(meta_flat.items())), "Audit Summary", header=False
                ),
                ExcelSheetConfig(
                    pd.DataFrame(export_payload["results"]), "Leaderboard"
                ),
                ExcelSheetConfig(pd.DataFrame(anomalies["data"]), "Anomaly Log"),
                ExcelSheetConfig(
                    pd.DataFrame(metadata["features"]).T, "Feature Metadata", index=True
                ),
            ]
            full_path, _ = save_excel(sheets, output_dir, filename)

        # --- PDF Export Logic ---
        if FileType.PDF in file_type:
            # Deep-dive PDF pages (for every model) require validation
            # predictions/probabilities. Restored snapshots may omit these
            # artifacts, so rehydrate them before rendering.
            self.hydrate_missing_prediction_artifacts(include_test=False)
            renderer = AuditPDFRenderer(summary=self, report_title=report_title)
            pdf_doc = renderer.render()
            full_path = pdf_doc.save(output_dir=output_dir, filename=filename)

        # --- MODEL Export Logic (Direct fitted estimator bundles) ---
        if FileType.MODEL in file_type:
            if fitted_models is None:
                raise RuntimeError(
                    "FileType.MODEL export requires fitted_models mapping "
                    "(model_id -> fitted estimator)."
                )
            full_path = self._export_fitted_models(
                output_dir=output_dir,
                filename=filename,
                fitted_models=fitted_models,
            )

        return full_path

    def evaluate_test_model(
        self, index: int, joblib_fullpath: PathLike | None = None
    ) -> None:
        """
        Evaluate a single model on the test set and optionally persist state.

        Parameters
        ----------
        index : int
            Index of the model configuration in the results list.
        joblib_fullpath : PathLike, optional
            Path to update the .joblib snapshot immediately after evaluation.
        """
        if index >= len(self.results):
            print(
                f"Error: Index {index} is out of bounds for results (len={len(self.results)})"
            )
            return

        config = self.results[index]
        print(
            f"Evaluating Test Set performance for {config.model_type.value} [ID: {config.id}]"
        )

        # 1. Hydrate the specific model architecture from its frozen config
        model = ModelSpecification.create_model_from_config(config)

        if model:
            # 2. Run test evaluation and update the results entry
            self.results[index] = model.evaluate_test_set_performance(
                data_splits=self.data_splits,
                config=config,
                features_to_fit_set=self.features_to_fit_set,
            )

            # 3. Optional Persistence
            if joblib_fullpath:
                from dsr_files.enums import FileType

                self.export_results(
                    prefix="Audit_State",
                    file_type=FileType.JOBLIB,
                    path=joblib_fullpath,
                    append_timestamp_to_save_path=False,
                    path_is_full_path=True,
                )
                print(
                    f"Audit snapshot updated on disk: {AnyPath(joblib_fullpath).name}"
                )
        else:
            print(
                f"Warning: Unable to instantiate {config.model_type.name} specification."
            )

    def evaluate_test_models(
        self, indexes: list[int], joblib_fullpath: PathLike | None = None
    ) -> None:
        """
        Evaluate a specific list of model indices on the test set.

        Parameters
        ----------
        indexes : list[int]
            List of result indices to process.
        joblib_fullpath : PathLike, optional
            Path to update the .joblib snapshot after each evaluation.
        """
        for index in indexes:
            self.evaluate_test_model(index=index, joblib_fullpath=joblib_fullpath)

    def evaluate_all_test_models(self, joblib_fullpath: PathLike | None = None) -> None:
        """
        Evaluate every model in the results list on the test set.

        Parameters
        ----------
        joblib_fullpath : PathLike, optional
            Path to update the .joblib snapshot during the process.
        """
        # Iterate over all indices in the current results list
        all_indices = list(range(len(self.results)))
        self.evaluate_test_models(indexes=all_indices, joblib_fullpath=joblib_fullpath)
