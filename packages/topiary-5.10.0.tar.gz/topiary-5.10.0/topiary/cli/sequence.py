# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


"""
Commandline arguments related to translated variant protein sequences.
"""


def add_sequence_args(arg_parser):
    sequence_group = arg_parser.add_argument_group(
        title="Protein Sequence Options",
        description="Parameters related to the mutant protein sequence",
    )

    sequence_group.add_argument(
        "--padding-around-mutation",
        default=None,
        help="".join(
            [
                "How many extra amino acids to include on either side of a mutation.",
                "Default is determined by epitope lengths but can be overridden to ",
                "predict wildtype epitopes in a larger context around a mutant residue.",
            ]
        ),
        type=int,
    )

    return sequence_group
