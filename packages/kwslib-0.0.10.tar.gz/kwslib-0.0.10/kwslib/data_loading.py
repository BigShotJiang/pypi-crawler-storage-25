"""Data loading utilities for dataset split workflows."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Dict, Tuple

import numpy as np

from .minio_client import SplitFilesClient
from .utils.load_npz_files import load_npz_files


class SplitDataLoader:
    """Download NPZ split files and materialize train/test arrays."""

    def __init__(self, api_client, files_client: SplitFilesClient):
        self.api = api_client
        self.files_client = files_client

    def _split_dir(self, base_dir: str, split_id: int, prefix: str) -> Path:
        out = Path(base_dir) / f"{prefix}_split_{split_id}"
        out.mkdir(parents=True, exist_ok=True)
        return out

    def _list_npz_files(self, split_id: int):
        files_info = self.files_client.list_files(split_id=split_id, file_type="npz")
        return files_info.get("files", [])

    def download_and_load_data(
        self,
        train_split_id: int,
        test_split_id: int,
        base_dir: str = "data",
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
        train_files = self._list_npz_files(train_split_id)
        test_files = self._list_npz_files(test_split_id)

        train_dir = self._split_dir(base_dir, train_split_id, "train")
        test_dir = self._split_dir(base_dir, test_split_id, "test")

        with ThreadPoolExecutor(max_workers=2) as executor:
            train_future = executor.submit(
                self.files_client.download_all_npz,
                split_id=train_split_id,
                output_dir=str(train_dir),
                skip_existing=True,
            )
            test_future = executor.submit(
                self.files_client.download_all_npz,
                split_id=test_split_id,
                output_dir=str(test_dir),
                skip_existing=True,
            )
            train_future.result()
            test_future.result()

        x_train, y_train, label_to_id = load_npz_files(
            str(train_dir),
            api_client=self.api,
            file_info_map=train_files,
        )
        x_test, y_test, label_to_id = load_npz_files(
            str(test_dir),
            api_client=self.api,
            file_info_map=test_files,
            label_to_id=label_to_id,
        )
        return x_train, y_train, x_test, y_test, label_to_id

    def download_and_load_data_zip(
        self,
        train_split_id: int,
        test_split_id: int,
        base_dir: str = "data",
        keep_zip: bool = False,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, Dict[str, int]]:
        train_files = self._list_npz_files(train_split_id)
        test_files = self._list_npz_files(test_split_id)

        base = Path(base_dir)
        base.mkdir(parents=True, exist_ok=True)

        train_dir = self._split_dir(str(base), train_split_id, "train")
        test_dir = self._split_dir(str(base), test_split_id, "test")

        train_zip = base / f"train_split_{train_split_id}.zip"
        test_zip = base / f"test_split_{test_split_id}.zip"

        self.files_client.download_all_files_zip(split_id=train_split_id, file_type="npz", output_path=str(train_zip))
        self.files_client.download_all_files_zip(split_id=test_split_id, file_type="npz", output_path=str(test_zip))

        import zipfile

        with zipfile.ZipFile(train_zip, "r") as zip_file:
            zip_file.extractall(train_dir)
        with zipfile.ZipFile(test_zip, "r") as zip_file:
            zip_file.extractall(test_dir)

        if not keep_zip:
            train_zip.unlink(missing_ok=True)
            test_zip.unlink(missing_ok=True)

        x_train, y_train, label_to_id = load_npz_files(
            str(train_dir),
            api_client=self.api,
            file_info_map=train_files,
        )
        x_test, y_test, label_to_id = load_npz_files(
            str(test_dir),
            api_client=self.api,
            file_info_map=test_files,
            label_to_id=label_to_id,
        )

        return x_train, y_train, x_test, y_test, label_to_id


# Backward-compatible alias
DataLoader = SplitDataLoader
