"""Model/experiment/metrics/artifact orchestration operations."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import requests

from .split_ops import KWSSession
from .standards.metrics import build_metrics_payload

logger = logging.getLogger(__name__)


class ModelManager:
    """Manage model init/model/experiment/runs and push metrics/artifacts."""

    def __init__(self, session: KWSSession):
        self._session = session
        self._api = session.api

    def register_run(
        self,
        model_name: str,
        num_classes: int,
        experiment_name: str,
        train_split_id: int,
        config: Dict[str, Any],
        *,
        model_init_id: Optional[int] = None,
        model_init_type: Optional[str] = None,
        model_description: Optional[str] = None,
        experiment_description: Optional[str] = None,
        git_commit: str = "manual-run",
        wait_job_timeout: int = 120,
        label_to_id: Optional[Dict[str, int]] = None,
        run_mode: str = "sync",
    ) -> Tuple[int, int]:
        api = self._api
        if model_init_id is not None:
            try:
                model_init = api.models.get_model_init(model_init_id)
            except requests.HTTPError as e:
                if e.response is not None and e.response.status_code == 404:
                    inits = api.models.list_model_inits(page=1, page_size=500)
                    items = inits.get("items", [])
                    model_init = next((m for m in items if (m.get("model_init_id") or m.get("id")) == model_init_id), {})
                    if not model_init:
                        raise ValueError(f"model_init_id={model_init_id} không tồn tại trong danh sách.")
                else:
                    raise
            model_init_raw = model_init.get("model_init_id") or model_init.get("id")
            if model_init_raw is None:
                raise ValueError("Missing model_init_id in model-init response")
            model_init_id = int(model_init_raw)
        else:
            if not model_init_type:
                raise ValueError("Cần model_init_id hoặc model_init_type")
            inits = api.models.list_model_inits(page=1, page_size=100)
            items = inits.get("items", [])
            model_init = next((m for m in items if m.get("type") == model_init_type), {})
            if not model_init:
                model_init = api.models.create_model_init(
                    name=f"{model_init_type} Architecture",
                    type=model_init_type,
                )
            model_init_raw = model_init.get("model_init_id") or model_init.get("id")
            if model_init_raw is None:
                raise ValueError("Missing model_init_id in model-init response")
            model_init_id = int(model_init_raw)

        models = api.models.list(page=1, page_size=100, name=model_name)
        model_items = models.get("items", [])
        model_obj = next((m for m in model_items if m.get("name") == model_name), None)
        if not model_obj:
            model_obj = api.models.create(
                name=model_name,
                model_init_id=model_init_id,
                num_classes=num_classes,
                description=model_description or f"{model_name}",
            )
        model_id_raw = model_obj.get("models_id") or model_obj.get("id")
        if model_id_raw is None:
            raise ValueError("Missing model_id in model response")
        model_id = int(model_id_raw)

        exps = api.experiments.list(page=1, page_size=100)
        exp_items = exps.get("items", [])
        exp_obj = next((e for e in exp_items if e.get("name") == experiment_name), None)
        if not exp_obj:
            exp_obj = api.experiments.create(
                name=experiment_name,
                description=experiment_description or experiment_name,
            )
        experiment_id_raw = exp_obj.get("experiments_id") or exp_obj.get("id")
        if experiment_id_raw is None:
            raise ValueError("Missing experiment_id in experiment response")
        experiment_id = int(experiment_id_raw)

        run_config = {**config, "label_to_id": label_to_id} if label_to_id is not None else config

        def _create_run_sync_fallback() -> int:
            sync_run = api.experiments.create_run_sync(
                experiment_id=experiment_id,
                model_id=model_id,
                dataset_split_id=train_split_id,
                config=run_config,
                git_commit=git_commit,
            )
            sync_run_id_raw = sync_run.get("experiment_runs_id") or sync_run.get("id")
            if sync_run_id_raw is None:
                raise ValueError("Missing experiment_run_id in sync run response")
            sync_run_id = int(sync_run_id_raw)
            logger.info("Đã tạo run đồng bộ: experiment_run_id=%s.", sync_run_id)
            return sync_run_id

        run_mode_normalized = run_mode.strip().lower()
        if run_mode_normalized not in {"sync", "async", "auto"}:
            raise ValueError("run_mode must be one of: 'sync', 'async', 'auto'")

        experiment_run_id: Optional[int] = None
        job_id: Optional[str] = None

        if run_mode_normalized == "sync":
            experiment_run_id = _create_run_sync_fallback()
        elif run_mode_normalized == "auto":
            try:
                experiment_run_id = _create_run_sync_fallback()
            except requests.HTTPError as exc:
                status_code = exc.response.status_code if exc.response is not None else None
                if status_code in {404, 405}:
                    logger.warning(
                        "create_run_sync unavailable (HTTP %s). Fallback to async create_run.",
                        status_code,
                    )
                    run_resp = api.experiments.create_run(
                        experiment_id=experiment_id,
                        model_id=model_id,
                        dataset_split_id=train_split_id,
                        config=run_config,
                        git_commit=git_commit,
                    )
                    job_id = run_resp.get("job_id")
                    async_run_id = run_resp.get("experiment_run_id") or run_resp.get("id")
                    if async_run_id is not None:
                        experiment_run_id = int(async_run_id)
                else:
                    raise
        else:
            run_resp = api.experiments.create_run(
                experiment_id=experiment_id,
                model_id=model_id,
                dataset_split_id=train_split_id,
                config=run_config,
                git_commit=git_commit,
            )
            job_id = run_resp.get("job_id")
            async_run_id = run_resp.get("experiment_run_id") or run_resp.get("id")
            if async_run_id is not None:
                experiment_run_id = int(async_run_id)

        if job_id:
            status = api.jobs.wait_for_completion(job_id, timeout=wait_job_timeout)
            if status.get("status") != "failed":
                status_run_id = (
                    status.get("experiment_run_id")
                    or status.get("run_id")
                    or (status.get("result") or {}).get("experiment_run_id")
                    or (status.get("result") or {}).get("id")
                )
                if status_run_id is not None:
                    experiment_run_id = int(status_run_id)

        if experiment_run_id is None:
            experiment_run_id = _create_run_sync_fallback()

        return model_id, experiment_run_id

    def push_metrics(
        self,
        model_id: int,
        dataset_split_id: int,
        experiment_run_id: int,
        metrics: Dict[str, Any],
        require_standard: bool = True,
        fill_missing_with_none: bool = True,
    ) -> int:
        payload = build_metrics_payload(
            model_id=model_id,
            dataset_split_id=dataset_split_id,
            experiment_run_id=experiment_run_id,
            metrics=metrics,
            require_standard=require_standard,
            fill_missing_with_none=fill_missing_with_none,
        )
        resp = self._api.metrics.create(payload=payload)
        metric_id_raw = resp.get("metrics_id") or resp.get("id")
        if metric_id_raw is None:
            raise ValueError("Missing metrics_id in metrics response")
        return int(metric_id_raw)

    def push_artifact(
        self,
        model_id: int,
        run_id: int,
        file_path: Union[str, Path],
        artifact_type: str = "tflite",
        framework: str = "generic",
        target_device: str = "CPU",
        is_default: bool = True,
        storage_path: Optional[str] = None,
        prototypes_path: Optional[Union[str, Path]] = None,
    ) -> int:
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File không tồn tại: {path}")
        if prototypes_path is not None and not Path(prototypes_path).exists():
            raise FileNotFoundError(f"File prototype không tồn tại: {prototypes_path}")
        art = self._api.artifacts.upload(
            file_path=path,
            model_id=model_id,
            run_id=run_id,
            artifact_type=artifact_type,
            framework=framework,
            target_device=target_device,
            is_default=is_default,
            storage_path=storage_path,
            prototypes_path=prototypes_path,
        )
        artifact_id_raw = art.get("model_artifacts_id") or art.get("id")
        if artifact_id_raw is None:
            raise ValueError("Missing artifact id in artifact response")
        return int(artifact_id_raw)

    def compare_metrics(
        self,
        model_ids: List[int],
        split_id: int,
    ) -> Any:
        return self._api.metrics.compare_metrics(model_ids=model_ids, split_id=split_id)


__all__ = ["ModelManager"]
